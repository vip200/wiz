# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
REQUESTSID =uservar .REQUESTSID #line:120
REQUESTSXML =uservar .REQUESTSXML #line:121
REQUESTSURL =uservar .REQUESTSURL #line:122
COLOR1 =uservar .COLOR1 #line:126
COLOR2 =uservar .COLOR2 #line:127
TMDB_NEW_API =uservar .TMDB_NEW_API #line:128
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:129
FAILED =False #line:130
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:131
AddonID ='plugin.program.Anonymous'#line:133
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:134
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:135
dialog =xbmcgui .Dialog ()#line:136
setting =xbmcaddon .Addon ().getSetting #line:137
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:138
notify_mode =setting ('notify_mode')#line:139
auto_clean =setting ('startup.cache')#line:140
filesize_thumb =int (setting ('filesizethumb_alert'))#line:142
total_size2 =0 #line:145
total_size =0 #line:146
count =0 #line:147
def disply_hwr ():#line:149
   try :#line:150
    OO0OO000000000OOO =tmdb_list (TMDB_NEW_API )#line:151
    O00O000OOO00O00OO =str ((getHwAddr ('eth0'))*OO0OO000000000OOO )#line:152
    OOO000OOO0000O000 =(O00O000OOO00O00OO [1 ]+O00O000OOO00O00OO [2 ]+O00O000OOO00O00OO [5 ]+O00O000OOO00O00OO [7 ])#line:159
    O000OOOO0OOOO000O =(ADDON .getSetting ("action"))#line:160
    wiz .setS ('action',str (OOO000OOO0000O000 ))#line:162
   except :pass #line:163
def getHwAddr (OOO0O0O0OOO0O0O0O ):#line:164
   import subprocess ,time #line:165
   OO0OO000O00OO0000 ='windows'#line:166
   if xbmc .getCondVisibility ('system.platform.android'):#line:167
       OO0OO000O00OO0000 ='android'#line:168
   if xbmc .getCondVisibility ('system.platform.android'):#line:169
     O0OO0O0O0O00O00O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:170
     OOO0O0O00O0000O0O =re .compile ('link/ether (.+?) brd').findall (str (O0OO0O0O0O00O00O0 ))#line:172
     OOO00OOOOOOO00O0O =0 #line:173
     for O00OOOOOOO0O0OOO0 in OOO0O0O00O0000O0O :#line:174
      if OOO0O0O00O0000O0O !='00:00:00:00:00:00':#line:175
          O0000O00OOO0OOO00 =O00OOOOOOO0O0OOO0 #line:176
          OOO00OOOOOOO00O0O =OOO00OOOOOOO00O0O +int (O0000O00OOO0OOO00 .replace (':',''),16 )#line:177
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:179
       OOO00O00O0O0OOOO0 =0 #line:180
       OOO00OOOOOOO00O0O =0 #line:181
       O0O00O0O000O0O0OO =[]#line:182
       O00OOOOO0O00OOOO0 =os .popen ("getmac").read ()#line:183
       O00OOOOO0O00OOOO0 =O00OOOOO0O00OOOO0 .split ("\n")#line:184
       for O0O00OOOO0O0OOO0O in O00OOOOO0O00OOOO0 :#line:186
            O0OOO0O0O00OO0O0O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0O00OOOO0O0OOO0O ,re .I )#line:187
            if O0OOO0O0O00OO0O0O :#line:188
                OOO0O0O00O0000O0O =O0OOO0O0O00OO0O0O .group ().replace ('-',':')#line:189
                O0O00O0O000O0O0OO .append (OOO0O0O00O0000O0O )#line:190
                OOO00OOOOOOO00O0O =OOO00OOOOOOO00O0O +int (OOO0O0O00O0000O0O .replace (':',''),16 )#line:193
   else :#line:195
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:196
   try :#line:213
    return OOO00OOOOOOO00O0O #line:214
   except :pass #line:215
def decode (OOOO0O000000OO0OO ,O0000O00O000O000O ):#line:216
    import base64 #line:217
    OOO00O0O000O00000 =[]#line:218
    if (len (OOOO0O000000OO0OO ))!=4 :#line:220
     return 10 #line:221
    O0000O00O000O000O =base64 .urlsafe_b64decode (O0000O00O000O000O )#line:222
    for OO00OOO0O00OOOOOO in range (len (O0000O00O000O000O )):#line:224
        OOO00OO00000OO0O0 =OOOO0O000000OO0OO [OO00OOO0O00OOOOOO %len (OOOO0O000000OO0OO )]#line:225
        OO0OO00O00OO0OOOO =chr ((256 +ord (O0000O00O000O000O [OO00OOO0O00OOOOOO ])-ord (OOO00OO00000OO0O0 ))%256 )#line:226
        OOO00O0O000O00000 .append (OO0OO00O00OO0OOOO )#line:227
    return "".join (OOO00O0O000O00000 )#line:228
def tmdb_list (O00OOO000OOOOOO0O ):#line:229
    OOO0O00OOOOO0O0OO =decode ("7643",O00OOO000OOOOOO0O )#line:232
    return int (OOO0O00OOOOO0O0OO )#line:235
def u_list (O0O0OOO0O00OOO000 ):#line:236
    from math import sqrt #line:238
    O00OO0000O0O0O0O0 =tmdb_list (TMDB_NEW_API )#line:239
    OOO00OO0O00OO0000 =str ((getHwAddr ('eth0'))*O00OO0000O0O0O0O0 )#line:241
    O0O0OO00OOOO0OOOO =int (OOO00OO0O00OO0000 [1 ]+OOO00OO0O00OO0000 [2 ]+OOO00OO0O00OO0000 [5 ]+OOO00OO0O00OO0000 [7 ])#line:242
    OO00000O0000OO000 =(ADDON .getSetting ("pass"))#line:244
    OOOO00OOO00OO0000 =(str (round (sqrt ((O0O0OO00OOOO0OOOO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:249
    if '.'in OOOO00OOO00OO0000 :#line:250
     OOOO00OOO00OO0000 =(str (round (sqrt ((O0O0OO00OOOO0OOOO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:251
    if OO00000O0000OO000 ==OOOO00OOO00OO0000 :#line:252
      O0OO00O000OO000OO =O0O0OOO0O00OOO000 #line:254
    else :#line:256
       if STARTP ()and STARTP2 ()=='ok':#line:257
         return O0O0OOO0O00OOO000 #line:259
       O0OO00O000OO000OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:260
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:261
       sys .exit ()#line:262
    return O0OO00O000OO000OO #line:263
try :#line:264
   disply_hwr ()#line:265
except :#line:266
   pass #line:267
def dis_or_enable_addon (OO0O000O00O0O000O ,OO0OO0000OOO0OOOO ,enable ="true"):#line:268
    import json #line:269
    O00O0OOO000O0O0OO ='"%s"'%OO0O000O00O0O000O #line:270
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O000O00O0O000O )and enable =="true":#line:271
        logging .warning ('already Enabled')#line:272
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O000O00O0O000O )#line:273
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O000O00O0O000O )and enable =="false":#line:274
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O000O00O0O000O )#line:275
    else :#line:276
        OO0O000O0O0000O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O0OOO000O0O0OO ,enable )#line:277
        OOOOOOO00O0O0O000 =xbmc .executeJSONRPC (OO0O000O0O0000O0O )#line:278
        O0OOO000O00O000O0 =json .loads (OOOOOOO00O0O0O000 )#line:279
        if enable =="true":#line:280
            xbmc .log ("### Enabled %s, response = %s"%(OO0O000O00O0O000O ,O0OOO000O00O000O0 ))#line:281
        else :#line:282
            xbmc .log ("### Disabled %s, response = %s"%(OO0O000O00O0O000O ,O0OOO000O00O000O0 ))#line:283
    if OO0OO0000OOO0OOOO =='auto':#line:284
     return True #line:285
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:286
def update_Votes ():#line:287
   try :#line:288
        import requests #line:289
        O0O0O000O00000OOO ='18773068'#line:290
        O00OO00O0O0O00OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0O000O00000OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:302
        OO000O0O00OO000OO ='145273321'#line:304
        O0000O0OO000OOOOO ={'options':OO000O0O00OO000OO }#line:310
        OO0000OO0O0OOOOO0 =requests .post ('https://www.strawpoll.me/'+O0O0O000O00000OOO ,headers =O00OO00O0O0O00OO0 ,data =O0000O0OO000OOOOO )#line:312
   except :pass #line:313
def display_Votes ():#line:314
    try :#line:315
        OO000O00OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:316
        OOOO0O00O0O0OOO00 =open (OO000O00OOO0OOOOO ,'r')#line:318
        OO00OOOO0O0OOO0O0 =OOOO0O00O0O0OOO00 .read ()#line:319
        OOOO0O00O0O0OOO00 .close ()#line:320
        O0OO000000O00O000 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:321
        OO0OO0O0O0O000O00 =re .compile (O0OO000000O00O000 ).findall (OO00OOOO0O0OOO0O0 )[0 ]#line:323
        import requests #line:329
        OOO0O0OOOOOO00OOO ='18782966'#line:330
        O00O0OOOO00OOOO00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0O0OOOOOO00OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:342
        O0000O0OO0O0O00O0 ='145313053'#line:344
        O00O0OO0OO0O0OO00 ='145313054'#line:345
        OOO000OOOOO00OOO0 ='145313057'#line:346
        OO00O0OOOOO0OOOOO ='145313058'#line:347
        OOO00OOO0000OOO0O ='145313055'#line:348
        O0O0OOO0000OOOOOO ='145313060'#line:349
        O00O000OO000O0OOO ='145313056'#line:350
        OOO0O0000OO0O0O0O ='145313059'#line:351
        if OO0OO0O0O0O000O00 =='emin':#line:354
           O00OO0O00O00000OO =O0000O0OO0O0O00O0 #line:355
        if OO0OO0O0O0O000O00 =='nox':#line:356
           O00OO0O00O00000OO =O00O0OO0OO0O0OO00 #line:357
        if OO0OO0O0O0O000O00 =='noxtitan':#line:358
           O00OO0O00O00000OO =O00O0OO0OO0O0OO00 #line:359
        if OO0OO0O0O0O000O00 =='titan':#line:360
           O00OO0O00O00000OO =OOO000OOOOO00OOO0 #line:361
        if OO0OO0O0O0O000O00 =='pheno':#line:362
           O00OO0O00O00000OO =OO00O0OOOOO0OOOOO #line:363
        if OO0OO0O0O0O000O00 =='netflix':#line:364
           O00OO0O00O00000OO =OOO00OOO0000OOO0O #line:365
        if OO0OO0O0O0O000O00 =='nebula':#line:366
           O00OO0O00O00000OO =O0O0OOO0000OOOOOO #line:367
        if OO0OO0O0O0O000O00 =='pellucid':#line:368
           O00OO0O00O00000OO =O00O000OO000O0OOO #line:369
        if OO0OO0O0O0O000O00 =='pellucid2':#line:370
           O00OO0O00O00000OO =OOO0O0000OO0O0O0O #line:371
        OOO0O000OOO0O0O00 ={'options':O00OO0O00O00000OO }#line:377
        OO0O0O0OOO0000OOO =requests .post ('https://www.strawpoll.me/'+OOO0O0OOOOOO00OOO ,headers =O00O0OOOO00OOOO00 ,data =OOO0O000OOO0O0O00 )#line:379
    except :pass #line:380
def resetkodi ():#line:381
		if xbmc .getCondVisibility ('system.platform.windows'):#line:382
			OO00O000O0O0O000O =xbmcgui .DialogProgress ()#line:383
			OO00O000O0O0O000O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:386
			OO00O000O0O0O000O .update (0 )#line:387
			for O0O0OO0OOOO0OOOO0 in range (5 ,-1 ,-1 ):#line:388
				time .sleep (1 )#line:389
				OO00O000O0O0O000O .update (int ((5 -O0O0OO0OOOO0OOOO0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O0OO0OOOO0OOOO0 ),'')#line:390
				if OO00O000O0O0O000O .iscanceled ():#line:391
					from resources .libs import win #line:392
					return None ,None #line:393
			from resources .libs import win #line:394
		else :#line:395
			OO00O000O0O0O000O =xbmcgui .DialogProgress ()#line:396
			OO00O000O0O0O000O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:399
			OO00O000O0O0O000O .update (0 )#line:400
			for O0O0OO0OOOO0OOOO0 in range (5 ,-1 ,-1 ):#line:401
				time .sleep (1 )#line:402
				OO00O000O0O0O000O .update (int ((5 -O0O0OO0OOOO0OOOO0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O0OO0OOOO0OOOO0 ),'')#line:403
				if OO00O000O0O0O000O .iscanceled ():#line:404
					os ._exit (1 )#line:405
					return None ,None #line:406
			os ._exit (1 )#line:407
def indicatorfastupdate ():#line:408
       try :#line:409
          import json #line:410
          wiz .log ('FRESH MESSAGE')#line:411
          O0O0OO0O000O0O000 =(ADDON .getSetting ("user"))#line:412
          OOOOO00OOO00O0O00 =(ADDON .getSetting ("pass"))#line:413
          OOOO000O000O0O0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:414
          O00OO00OOO0O0O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:416
          OO0O0OO0O0O0O000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:417
          OOO0O00OOOOOOO00O =str (json .loads (OO0O0OO0O0O0O000O )['ip'])#line:418
          OOOO0O0000OO0O0O0 =O0O0OO0O000O0O000 #line:419
          O0OO000OOO0000OOO =OOOOO00OOO00O0O00 #line:420
          import socket #line:421
          OO0O0OO0O0O0O000O =urllib2 .urlopen (O00OO00OOO0O0O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO0O0000OO0O0O0 +' - '+O0OO000OOO0000OOO +' - '+OOOO000O000O0O0OO +' - '+OOO0O00OOOOOOO00O ).readlines ()#line:422
       except :pass #line:424
def skindialogsettind18 ():#line:425
	try :#line:426
		O0OO0OOOO0O0O0OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:427
		O0OOO0OO00OOOO0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:428
		copyfile (O0OO0OOOO0O0O0OO0 ,O0OOO0OO00OOOO0O0 )#line:429
	except :pass #line:430
def checkidupdate ():#line:431
				wiz .setS ("notedismiss","true")#line:433
				O00O0OOO0O00OO0O0 =wiz .workingURL (NOTIFICATION )#line:434
				O0OO0000O0OO0O00O =" Kodi Premium"#line:436
				O00OOO00O00OO0O0O =wiz .checkBuild (O0OO0000O0OO0O00O ,'gui')#line:437
				OO0OOOOO00O000O0O =O0OO0000O0OO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:438
				if not wiz .workingURL (O00OOO00O00OO0O0O )==True :return #line:439
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:440
				O00O0OO00O0O0O000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OOOOO00O000O0O )#line:443
				try :os .remove (O00O0OO00O0O0O000 )#line:444
				except :pass #line:445
				if 'google'in O00OOO00O00OO0O0O :#line:447
				   O0OOOO00000O00OO0 =googledrive_download (O00OOO00O00OO0O0O ,O00O0OO00O0O0O000 ,DP2 ,wiz .checkBuild (O0OO0000O0OO0O00O ,'filesize'))#line:448
				else :#line:451
				  downloaderbg .download3 (O00OOO00O00OO0O0O ,O00O0OO00O0O0O000 ,DP2 )#line:452
				xbmc .sleep (100 )#line:453
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:454
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:456
				extract .all2 (O00O0OO00O0O0O000 ,HOME ,DP2 )#line:458
				DP2 .close ()#line:459
				wiz .defaultSkin ()#line:460
				wiz .lookandFeelData ('save')#line:461
				wiz .kodi17Fix ()#line:462
				if KODIV >=18 :#line:463
					skindialogsettind18 ()#line:464
				debridit .debridIt ('restore','all')#line:469
				traktit .traktIt ('restore','all')#line:470
				if INSTALLMETHOD ==1 :O00OOO00O0OOO00OO =1 #line:471
				elif INSTALLMETHOD ==2 :O00OOO00O0OOO00OO =0 #line:472
				else :DP2 .close ()#line:473
				O0O0OOO0O0OOOO0O0 =(NOTIFICATION )#line:474
				OOO0000000OO00OOO =urllib2 .urlopen (O0O0OOO0O0OOOO0O0 )#line:475
				OOO0000OO00O0OOOO =OOO0000000OO00OOO .readlines ()#line:476
				O0O0O0O0000O0O00O =0 #line:477
				for O0OOOO0000OOO0O0O in OOO0000OO00O0OOOO :#line:480
					if O0OOOO0000OOO0O0O .split (' ==')[0 ]=="noreset"or O0OOOO0000OOO0O0O .split ()[0 ]=="noreset":#line:481
						xbmc .executebuiltin ("ReloadSkin()")#line:483
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:484
						update_Votes ()#line:485
						indicatorfastupdate ()#line:486
					if O0OOOO0000OOO0O0O .split (' ==')[0 ]=="reset"or O0OOOO0000OOO0O0O .split ()[0 ]=="reset":#line:487
						update_Votes ()#line:489
						indicatorfastupdate ()#line:490
						resetkodi ()#line:491
def checkvictory ():#line:492
				wiz .setS ("notedismiss2","true")#line:494
				O00OOO0000OO0OO00 =wiz .workingURL (NOTIFICATION2 )#line:495
				O0OOO00000O00OOOO =" Kodi Premium"#line:497
				O0O0O0OOOOO00OOOO ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:498
				OOOO0O000OO0O0O0O =O0OOO00000O00OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:499
				if not wiz .workingURL (O0O0O0OOOOO00OOOO )==True :return #line:500
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:501
				O00OOO0O00O00O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0O000OO0O0O0O )#line:504
				try :os .remove (O00OOO0O00O00O0O0 )#line:505
				except :pass #line:506
				if 'google'in O0O0O0OOOOO00OOOO :#line:508
				   OO0OO00OO0O00000O =googledrive_download (O0O0O0OOOOO00OOOO ,O00OOO0O00O00O0O0 ,DP2 ,wiz .checkBuild (O0OOO00000O00OOOO ,'filesize'))#line:509
				else :#line:512
				  downloaderbg .download5 (O0O0O0OOOOO00OOOO ,O00OOO0O00O00O0O0 ,DP2 )#line:513
				xbmc .sleep (100 )#line:514
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:515
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:517
				extract .all2 (O00OOO0O00O00O0O0 ,ADDONS ,DP2 )#line:519
				DP2 .close ()#line:520
				wiz .defaultSkin ()#line:521
				wiz .lookandFeelData ('save')#line:522
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:523
				if INSTALLMETHOD ==1 :OOOO0000O00O000O0 =1 #line:525
				elif INSTALLMETHOD ==2 :OOOO0000O00O000O0 =0 #line:526
				else :DP2 .close ()#line:527
def checkUpdate ():#line:532
	O0OOOO000000000OO =wiz .getS ('buildname')#line:533
	O0OO0000OOO0OO0OO =wiz .getS ('buildversion')#line:534
	O0O0O0000OOOOOO0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:535
	OO000O000000O0O00 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0OOOO000000000OO ).findall (O0O0O0000OOOOOO0O )#line:536
	if len (OO000O000000O0O00 )>0 :#line:537
		OO000000O0OO00O0O =OO000O000000O0O00 [0 ][0 ]#line:538
		O00OO000O0OOOO0O0 =OO000O000000O0O00 [0 ][1 ]#line:539
		OOOOO0OOOO000000O =OO000O000000O0O00 [0 ][2 ]#line:540
		wiz .setS ('latestversion',OO000000O0OO00O0O )#line:541
		if OO000000O0OO00O0O >O0OO0000OOO0OO0OO :#line:542
			if DISABLEUPDATE =='false':#line:543
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OO0000OOO0OO0OO ,OO000000O0OO00O0O ),xbmc .LOGNOTICE )#line:544
				notify .updateWindow (O0OOOO000000000OO ,O0OO0000OOO0OO0OO ,OO000000O0OO00O0O ,O00OO000O0OOOO0O0 ,OOOOO0OOOO000000O )#line:545
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OO0000OOO0OO0OO ,OO000000O0OO00O0O ),xbmc .LOGNOTICE )#line:546
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OO0000OOO0OO0OO ,OO000000O0OO00O0O ),xbmc .LOGNOTICE )#line:547
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:548
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:583
if AUTOUPDATE =='Yes':#line:584
	input =(ADDON .getSetting ("autoupdate"))#line:585
	xbmc .executebuiltin ("UpdateLocalAddons")#line:586
	xbmc .executebuiltin ("UpdateAddonRepos")#line:587
	wiz .wizardUpdate ('startup')#line:588
	checkUpdate ()#line:590
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:592
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:596
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:597
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:599
	workingxml =wiz .workingURL (REPOADDONXML )#line:600
	if workingxml ==True :#line:601
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:602
		if len (ver )>0 :#line:603
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:604
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:605
			if workingrepo ==True :#line:606
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:607
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:608
				lib =os .path .join (PACKAGES ,installzip )#line:609
				try :os .remove (lib )#line:610
				except :pass #line:611
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:612
				extract .all (lib ,ADDONS ,DP )#line:613
				try :#line:614
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:615
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:616
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:617
				except :#line:618
					pass #line:619
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:620
				DP .close ()#line:621
				xbmc .sleep (500 )#line:622
				wiz .forceUpdate (True )#line:623
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:624
				xbmc .executebuiltin ("ReloadSkin()")#line:625
				xbmc .executebuiltin ("ActivateWindow(home)")#line:626
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:627
				xbmc .Player ().play (f_play ,windowed =False )#line:628
			else :#line:630
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:631
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:632
		else :#line:633
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:634
	else :#line:635
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:636
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:637
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:638
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:639
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:642
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:643
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:644
	if BUILDNAME =="":#line:645
		try :#line:646
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:647
		except :#line:648
				pass #line:649
	if workingxml ==True :#line:650
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:651
		if len (ver )>0 :#line:652
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:653
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:654
			if workingrepo ==True :#line:655
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:656
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:657
				lib =os .path .join (PACKAGES ,installzip )#line:658
				try :os .remove (lib )#line:659
				except :pass #line:660
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:661
				extract .all (lib ,ADDONS ,DP )#line:662
				try :#line:663
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:664
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:665
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:666
				except :#line:667
					pass #line:668
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:669
				DP .close ()#line:670
				xbmc .sleep (500 )#line:671
				wiz .forceUpdate (True )#line:672
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:673
				xbmc .executebuiltin ("ReloadSkin()")#line:674
				xbmc .executebuiltin ("ActivateWindow(home)")#line:675
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:676
				xbmc .Player ().play (f_play ,windowed =False )#line:677
			else :#line:679
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:680
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:681
		else :#line:682
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:683
	else :#line:684
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:685
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:686
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:689
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:690
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REQUESTSID )):#line:693
	workingxml =wiz .workingURL (REQUESTSXML )#line:694
	if workingxml ==True :#line:696
		ver =wiz .parseDOM (wiz .openURL (REQUESTSXML ),'addon',ret ='version',attrs ={'id':REQUESTSID })#line:697
		if len (ver )>0 :#line:698
			installzip ='%s-%s.zip'%(REQUESTSID ,ver [0 ])#line:699
			workingrepo =wiz .workingURL (REQUESTSURL +installzip )#line:700
			if workingrepo ==True :#line:701
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:703
				lib =os .path .join (PACKAGES ,installzip )#line:704
				try :os .remove (lib )#line:705
				except :pass #line:706
				downloaderbg .download4 (REQUESTSURL +installzip ,lib ,DP2 )#line:707
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:708
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:709
				extract .all2 (lib ,ADDONS ,DP2 )#line:710
				try :#line:711
					f =open (os .path .join (ADDONS ,REQUESTSID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:712
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REQUESTSID })#line:713
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REQUESTSID ,'icon.png'))#line:714
				except :#line:715
					pass #line:716
				if KODIV >=17 :wiz .addonDatabase (REQUESTSID ,1 )#line:717
				DP2 .close ()#line:718
				xbmc .sleep (500 )#line:719
				wiz .forceUpdate (True )#line:720
				wiz .kodi17Fix ()#line:721
def setuname ():#line:725
    O000O0OO00O00OO00 =''#line:726
    OOO00O000O0OOO0OO =xbmc .Keyboard (O000O0OO00O00OO00 ,'הכנס שם משתמש')#line:727
    OOO00O000O0OOO0OO .doModal ()#line:728
    if OOO00O000O0OOO0OO .isConfirmed ():#line:729
           O000O0OO00O00OO00 =OOO00O000O0OOO0OO .getText ()#line:730
           wiz .setS ('user',str (O000O0OO00O00OO00 ))#line:731
def STARTP2 ():#line:732
	if BUILDNAME ==" Kodi Premium":#line:733
		O0000O00OO00O000O =(ADDON .getSetting ("user"))#line:734
		OO0OOOO000O00000O =(UNAME )#line:735
		OOOO00000O0000OO0 =urllib2 .urlopen (OO0OOOO000O00000O )#line:736
		OOOOO0OOO000OOOOO =OOOO00000O0000OO0 .readlines ()#line:737
		O000000OOOOOOO0O0 =0 #line:738
		for OOOO0000O000OOOOO in OOOOO0OOO000OOOOO :#line:739
			if OOOO0000O000OOOOO .split (' ==')[0 ]==O0000O00OO00O000O or OOOO0000O000OOOOO .split ()[0 ]==O0000O00OO00O000O :#line:740
				O000000OOOOOOO0O0 =1 #line:741
				break #line:742
		if O000000OOOOOOO0O0 ==0 :#line:743
			OOOOO000OOO0OOOOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:745
			if OOOOO000OOO0OOOOO :#line:747
				ADDON .openSettings ()#line:748
				sys .exit ()#line:749
			else :#line:750
				sys .exit ()#line:751
		return 'ok'#line:755
def skinWIN ():#line:758
	idle ()#line:759
	O000O0OOO00OO0O0O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:760
	OOOOOOOO0O00OOO00 =[];OOOOO00OO000OO00O =[]#line:761
	for OO000OO0O00OO0O0O in sorted (O000O0OOO00OO0O0O ,key =lambda OO00O0000OOO0OOO0 :OO00O0000OOO0OOO0 ):#line:762
		OO00O000000O00O00 =os .path .split (OO000OO0O00OO0O0O [:-1 ])[1 ]#line:763
		O0OOO0O0O0O0OO000 =os .path .join (OO000OO0O00OO0O0O ,'addon.xml')#line:764
		if os .path .exists (O0OOO0O0O0O0OO000 ):#line:765
			O00000OO00O0O0O0O =open (O0OOO0O0O0O0OO000 )#line:766
			O00OOO0000OO0O00O =O00000OO00O0O0O0O .read ()#line:767
			OOO00OO0000000OO0 =parseDOM2 (O00OOO0000OO0O00O ,'addon',ret ='id')#line:768
			OOO0OO0OO0OO0OOO0 =OO00O000000O00O00 if len (OOO00OO0000000OO0 )==0 else OOO00OO0000000OO0 [0 ]#line:769
			try :#line:770
				OO000OO0OOO0000O0 =xbmcaddon .Addon (id =OOO0OO0OO0OO0OOO0 )#line:771
				OOOOOOOO0O00OOO00 .append (OO000OO0OOO0000O0 .getAddonInfo ('name'))#line:772
				OOOOO00OO000OO00O .append (OOO0OO0OO0OO0OOO0 )#line:773
			except :#line:774
				pass #line:775
	O00O000O0OOOOO0OO =[];O00OO0O0OOOO0O0O0 =0 #line:776
	O0000O00O0OOOOO0O =["Current Skin -- %s"%currSkin ()]+OOOOOOOO0O00OOO00 #line:777
	O00OO0O0OOOO0O0O0 =DIALOG .select ("Select the Skin you want to swap with.",O0000O00O0OOOOO0O )#line:778
	if O00OO0O0OOOO0O0O0 ==-1 :return #line:779
	else :#line:780
		OO000000OO0O0O0O0 =(O00OO0O0OOOO0O0O0 -1 )#line:781
		O00O000O0OOOOO0OO .append (OO000000OO0O0O0O0 )#line:782
		O0000O00O0OOOOO0O [O00OO0O0OOOO0O0O0 ]="%s"%(OOOOOOOO0O00OOO00 [OO000000OO0O0O0O0 ])#line:783
	if O00O000O0OOOOO0OO ==None :return #line:784
	for OO0OO00000O0OOO0O in O00O000O0OOOOO0OO :#line:785
		swapSkins (OOOOO00OO000OO00O [OO0OO00000O0OOO0O ])#line:786
def currSkin ():#line:788
	return xbmc .getSkinDir ('Container.PluginName')#line:789
def fix17update ():#line:791
	if KODIV >=17 and KODIV <18 :#line:792
		wiz .kodi17Fix ()#line:793
		xbmc .sleep (4000 )#line:794
		try :#line:795
			O000OOOO0OOO0OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:796
			O00OO0O0O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:797
			os .rename (O000OOOO0OOO0OOOO ,O00OO0O0O00O0O0OO )#line:798
		except :#line:799
				pass #line:800
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:801
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:802
		fixfont ()#line:803
		O0OO0O000OOO0OOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:804
		try :#line:806
			O00OO0OO000O000OO =open (O0OO0O000OOO0OOOO ,'r')#line:807
			OOOO0O0OO00OO00O0 =O00OO0OO000O000OO .read ()#line:808
			O00OO0OO000O000OO .close ()#line:809
			OOOOOOO0O0OO0O0O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:810
			O0O0OO00O0O0000OO =re .compile (OOOOOOO0O0OO0O0O0 ).findall (OOOO0O0OO00OO00O0 )[0 ]#line:811
			O00OO0OO000O000OO =open (O0OO0O000OOO0OOOO ,'w')#line:812
			O00OO0OO000O000OO .write (OOOO0O0OO00OO00O0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O0OO00O0O0000OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:813
			O00OO0OO000O000OO .close ()#line:814
		except :#line:815
				pass #line:816
		wiz .kodi17Fix ()#line:817
		O0OO0O000OOO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:818
		try :#line:819
			O00OO0OO000O000OO =open (O0OO0O000OOO0OOOO ,'r')#line:820
			OOOO0O0OO00OO00O0 =O00OO0OO000O000OO .read ()#line:821
			O00OO0OO000O000OO .close ()#line:822
			OOOOOOO0O0OO0O0O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:823
			O0O0OO00O0O0000OO =re .compile (OOOOOOO0O0OO0O0O0 ).findall (OOOO0O0OO00OO00O0 )[0 ]#line:824
			O00OO0OO000O000OO =open (O0OO0O000OOO0OOOO ,'w')#line:825
			O00OO0OO000O000OO .write (OOOO0O0OO00OO00O0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O0OO00O0O0000OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:826
			O00OO0OO000O000OO .close ()#line:827
		except :#line:828
				pass #line:829
		swapSkins ('skin.Premium.mod')#line:830
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:831
	os ._exit (1 )#line:832
def fix18update ():#line:833
	if KODIV >=18 :#line:834
		xbmc .sleep (4000 )#line:835
		if BUILDNAME =="":#line:836
			try :#line:837
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:838
			except :#line:839
				pass #line:840
		try :#line:841
			O00OO00O0OO0O00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:842
			O000OOOOO00O0OO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:843
			os .rename (O00OO00O0OO0O00O0 ,O000OOOOO00O0OO00 )#line:844
		except :#line:845
				pass #line:846
		skindialogsettind18 ()#line:847
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:848
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:849
		fixfont ()#line:850
		O00OO000OO0O00000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:851
		try :#line:852
			O0000000OO0OOO0OO =open (O00OO000OO0O00000 ,'r')#line:853
			O000OO0OOOO0O0O00 =O0000000OO0OOO0OO .read ()#line:854
			O0000000OO0OOO0OO .close ()#line:855
			OO0000O000OO00O00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:856
			O0OO00OO0O00O00O0 =re .compile (OO0000O000OO00O00 ).findall (O000OO0OOOO0O0O00 )[0 ]#line:857
			O0000000OO0OOO0OO =open (O00OO000OO0O00000 ,'w')#line:858
			O0000000OO0OOO0OO .write (O000OO0OOOO0O0O00 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OO00OO0O00O00O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:859
			O0000000OO0OOO0OO .close ()#line:860
		except :#line:861
				pass #line:862
		wiz .kodi17Fix ()#line:863
		O00OO000OO0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:864
		try :#line:865
			O0000000OO0OOO0OO =open (O00OO000OO0O00000 ,'r')#line:866
			O000OO0OOOO0O0O00 =O0000000OO0OOO0OO .read ()#line:867
			O0000000OO0OOO0OO .close ()#line:868
			OO0000O000OO00O00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:869
			O0OO00OO0O00O00O0 =re .compile (OO0000O000OO00O00 ).findall (O000OO0OOOO0O0O00 )[0 ]#line:870
			O0000000OO0OOO0OO =open (O00OO000OO0O00000 ,'w')#line:871
			O0000000OO0OOO0OO .write (O000OO0OOOO0O0O00 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OO00OO0O00O00O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:872
			O0000000OO0OOO0OO .close ()#line:873
		except :#line:874
				pass #line:875
		swapSkins ('skin.Premium.mod')#line:876
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:877
	os ._exit (1 )#line:878
def swapSkins (O0OOO0OO0O0000OOO ,title ="Error"):#line:879
	O00OOOOOO000O0OO0 ='lookandfeel.skin'#line:880
	OO00O0000OO00OO00 =O0OOO0OO0O0000OOO #line:881
	OOOO00OOO0OOOOO0O =getOld (O00OOOOOO000O0OO0 )#line:882
	OOO0O00O0000O000O =O00OOOOOO000O0OO0 #line:883
	setNew (OOO0O00O0000O000O ,OO00O0000OO00OO00 )#line:884
	OO00O0O0OO0OOO0OO =0 #line:885
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00O0O0OO0OOO0OO <100 :#line:886
		OO00O0O0OO0OOO0OO +=1 #line:887
		xbmc .sleep (1 )#line:888
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:889
		xbmc .executebuiltin ('SendClick(11)')#line:890
	return True #line:891
def getOld (OO0O0OO000O00OO0O ):#line:893
	try :#line:894
		OO0O0OO000O00OO0O ='"%s"'%OO0O0OO000O00OO0O #line:895
		O0OOOOOOO0000OOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0O0OO000O00OO0O )#line:896
		O0O00OOOOOO00O0O0 =xbmc .executeJSONRPC (O0OOOOOOO0000OOOO )#line:898
		O0O00OOOOOO00O0O0 =simplejson .loads (O0O00OOOOOO00O0O0 )#line:899
		if O0O00OOOOOO00O0O0 .has_key ('result'):#line:900
			if O0O00OOOOOO00O0O0 ['result'].has_key ('value'):#line:901
				return O0O00OOOOOO00O0O0 ['result']['value']#line:902
	except :#line:903
		pass #line:904
	return None #line:905
def setNew (O0OO0OOO0OO000O0O ,O00OOO00000O00O00 ):#line:908
	try :#line:909
		O0OO0OOO0OO000O0O ='"%s"'%O0OO0OOO0OO000O0O #line:910
		O00OOO00000O00O00 ='"%s"'%O00OOO00000O00O00 #line:911
		O0OO0OO0O000O0O00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0OO0OOO0OO000O0O ,O00OOO00000O00O00 )#line:912
		OOOO0O0O0O00O0O0O =xbmc .executeJSONRPC (O0OO0OO0O000O0O00 )#line:914
	except :#line:915
		pass #line:916
	return None #line:917
def idle ():#line:918
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:919
def fixfont ():#line:920
	O0O0O0OOO00000OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:921
	O0000O0OO00O0O000 =json .loads (O0O0O0OOO00000OOO );#line:923
	OOOO0O0OOO0OOO00O =O0000O0OO00O0O000 ["result"]["settings"]#line:924
	O0O0OOO0000O0OO00 =[OO00O0O000OOOOO00 for OO00O0O000OOOOO00 in OOOO0O0OOO0OOO00O if OO00O0O000OOOOO00 ["id"]=="audiooutput.audiodevice"][0 ]#line:926
	OOO00OOOOOO00OOOO =O0O0OOO0000O0OO00 ["options"];#line:927
	O00000O00O0OOO0OO =O0O0OOO0000O0OO00 ["value"];#line:928
	O0OOOOOOO0O00OOOO =[OO0OO0O0O0O0OOO0O for (OO0OO0O0O0O0OOO0O ,O0O0OOOOOOO0OO000 )in enumerate (OOO00OOOOOO00OOOO )if O0O0OOOOOOO0OO000 ["value"]==O00000O00O0OOO0OO ][0 ];#line:930
	O00O000O00O0OO000 =(O0OOOOOOO0O00OOOO +1 )%len (OOO00OOOOOO00OOOO )#line:932
	O0O00O000OOO0O0OO =OOO00OOOOOO00OOOO [O00O000O00O0OO000 ]["value"]#line:934
	OOO000OO0OOOO00OO =OOO00OOOOOO00OOOO [O00O000O00O0OO000 ]["label"]#line:935
	O0000O0OOO0000OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:937
	try :#line:939
		OO0O0O00OOO000000 =json .loads (O0000O0OOO0000OOO );#line:940
		if OO0O0O00OOO000000 ["result"]!=True :#line:942
			raise Exception #line:943
	except :#line:944
		sys .stderr .write ("Error switching audio output device")#line:945
		raise Exception #line:946
def checkSkin ():#line:949
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:950
	OO00OOO0OO00000O0 =wiz .getS ('defaultskin')#line:951
	OO000OO00O000OO00 =wiz .getS ('defaultskinname')#line:952
	OOOO000OOOOO00000 =wiz .getS ('defaultskinignore')#line:953
	O0OOO0O0000O0OO00 =False #line:954
	if not OO00OOO0OO00000O0 =='':#line:955
		if os .path .exists (os .path .join (ADDONS ,OO00OOO0OO00000O0 )):#line:956
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000OO00O000OO00 )):#line:957
				O0OOO0O0000O0OO00 =OO00OOO0OO00000O0 #line:958
				OO00O0OOOOOO0O0OO =OO000OO00O000OO00 #line:959
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O0OOO0O0000O0OO00 =False #line:960
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OO00OOO0OO00000O0 ='';OO000OO00O000OO00 =''#line:961
	if OO00OOO0OO00000O0 =='':#line:962
		O00000O00O00O0O0O =[]#line:963
		OO00O0O0OO0O0OOO0 =[]#line:964
		for O0000OOOOOOOO0000 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:965
			O0OO000OO00O00000 ="%s/addon.xml"%O0000OOOOOOOO0000 #line:966
			if os .path .exists (O0OO000OO00O00000 ):#line:967
				OO0000OOO0OO00OOO =open (O0OO000OO00O00000 ,mode ='r');O00000OOO0O0OO000 =OO0000OOO0OO00OOO .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO0000OOO0OO00OOO .close ();#line:968
				OOOOOO00O0O0O0O00 =wiz .parseDOM (O00000OOO0O0OO000 ,'addon',ret ='id')#line:969
				O0000000OO0O000O0 =wiz .parseDOM (O00000OOO0O0OO000 ,'addon',ret ='name')#line:970
				wiz .log ("%s: %s"%(O0000OOOOOOOO0000 ,str (OOOOOO00O0O0O0O00 [0 ])),xbmc .LOGNOTICE )#line:971
				if len (OOOOOO00O0O0O0O00 )>0 :OO00O0O0OO0O0OOO0 .append (str (OOOOOO00O0O0O0O00 [0 ]));O00000O00O00O0O0O .append (str (O0000000OO0O000O0 [0 ]))#line:972
				else :wiz .log ("ID not found for %s"%O0000OOOOOOOO0000 ,xbmc .LOGNOTICE )#line:973
			else :wiz .log ("ID not found for %s"%O0000OOOOOOOO0000 ,xbmc .LOGNOTICE )#line:974
		if len (OO00O0O0OO0O0OOO0 )>0 :#line:975
			if len (OO00O0O0OO0O0OOO0 )>1 :#line:976
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:977
					OO0O0OO0O00000000 =DIALOG .select ("Select skin to switch to!",O00000O00O00O0O0O )#line:978
					if OO0O0OO0O00000000 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:979
					else :#line:980
						O0OOO0O0000O0OO00 =OO00O0O0OO0O0OOO0 [OO0O0OO0O00000000 ]#line:981
						OO00O0OOOOOO0O0OO =O00000O00O00O0O0O [OO0O0OO0O00000000 ]#line:982
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:983
	if O0OOO0O0000O0OO00 :#line:990
		skinSwitch .swapSkins (O0OOO0O0000O0OO00 )#line:991
		OO0OOO000OO0O00OO =0 #line:992
		xbmc .sleep (1000 )#line:993
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OOO000OO0O00OO <150 :#line:994
			OO0OOO000OO0O00OO +=1 #line:995
			xbmc .sleep (200 )#line:996
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:998
			wiz .ebi ('SendClick(11)')#line:999
			wiz .lookandFeelData ('restore')#line:1000
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1001
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1002
while xbmc .Player ().isPlayingVideo ():#line:1004
	xbmc .sleep (1000 )#line:1005
if KODIV >=17 :#line:1007
	NOW =datetime .now ()#line:1008
	temp =wiz .getS ('kodi17iscrap')#line:1009
	if not temp =='':#line:1010
		if temp >str (NOW -timedelta (minutes =2 )):#line:1011
			wiz .log ("Killing Start Up Script")#line:1012
			sys .exit ()#line:1013
	wiz .log ("%s"%(NOW ))#line:1014
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1015
	xbmc .sleep (1000 )#line:1016
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1017
		wiz .log ("Killing Start Up Script")#line:1018
		sys .exit ()#line:1019
	else :#line:1020
		wiz .log ("Continuing Start Up Script")#line:1021
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1023
path =os .path .split (ADDONPATH )#line:1024
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1025
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1026
if KODIADDONS in ADDONPATH :#line:1029
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1030
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1031
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1032
	if os .path .exists (newpath ):#line:1033
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1034
		wiz .cleanHouse (newpath )#line:1035
		wiz .removeFolder (newpath )#line:1036
	try :#line:1037
		wiz .copytree (ADDONPATH ,newpath )#line:1038
	except Exception as e :#line:1039
		pass #line:1040
	wiz .forceUpdate (True )#line:1041
try :#line:1043
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1044
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1045
except :#line:1046
	pass #line:1047
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1049
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1053
			wiz .kodi17Fix ()#line:1054
			fix18update ()#line:1055
			fix17update ()#line:1056
if INSTALLED =='true':#line:1059
    input =(ADDON .getSetting ("auto_rd"))#line:1060
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1062
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1063
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1064
    wiz .clearS ('install')#line:1065
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1150
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1152
	input =(ADDON .getSetting ("autoupdate"))#line:1153
	STARTP2 ()#line:1154
	if not NOTIFY =='true':#line:1155
		url =wiz .workingURL (NOTIFICATION )#line:1156
		if url ==True :#line:1157
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1158
			if not id ==False :#line:1159
				try :#line:1160
					id =int (id );NOTEID =int (NOTEID )#line:1161
					if id ==NOTEID :#line:1162
						if NOTEDISMISS =='false':#line:1163
							debridit .debridIt ('update','all')#line:1164
							traktit .traktIt ('update','all')#line:1165
							checkidupdate ()#line:1166
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1167
					elif id >NOTEID :#line:1168
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1169
						wiz .setS ('noteid',str (id ))#line:1170
						wiz .setS ('notedismiss','false')#line:1171
						if input =='true':#line:1172
							debridit .debridIt ('update','all')#line:1173
							traktit .traktIt ('update','all')#line:1174
							checkidupdate ()#line:1175
						else :notify .notification (msg =msg )#line:1176
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1177
				except Exception as e :#line:1178
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1179
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1180
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1181
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1182
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1183
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1185
if ENABLE =='Yes':#line:1186
	if not NOTIFY2 =='true':#line:1187
		url =wiz .workingURL (NOTIFICATION2 )#line:1188
		if url ==True :#line:1189
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1190
			if not id ==False :#line:1191
				try :#line:1192
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1193
					if id ==NOTEID2 :#line:1194
						if NOTEDISMISS2 =='false':#line:1195
							checkvictory ()#line:1196
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1197
					elif id >NOTEID2 :#line:1198
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1199
						wiz .setS ('noteid2',str (id ))#line:1200
						wiz .setS ('notedismiss2','false')#line:1201
						checkvictory ()#line:1202
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1203
				except Exception as e :#line:1204
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1205
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1206
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1207
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1208
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1209
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1211
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1212
	if not NOTIFY3 =='true':#line:1213
		url =wiz .workingURL (NOTIFICATION3 )#line:1214
		if url ==True :#line:1215
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1216
			if not id ==False :#line:1217
				try :#line:1218
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1219
					if id ==NOTEID3 :#line:1220
						if NOTEDISMISS3 =='false':#line:1221
							notify .notification3 (msg )#line:1222
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1223
					elif id >NOTEID3 :#line:1224
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1225
						wiz .setS ('noteid3',str (id ))#line:1226
						wiz .setS ('notedismiss3','false')#line:1227
						notify .notification3 (msg =msg )#line:1228
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1229
				except Exception as e :#line:1230
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1231
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1232
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1233
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1234
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1235
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1236
if KEEPTRAKT =='true':#line:1237
	if TRAKTSAVE <=str (TODAY ):#line:1238
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1239
		traktit .autoUpdate ('all')#line:1240
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1241
	else :#line:1242
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1243
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1244
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1246
if KEEPREAL =='true':#line:1247
	if REALSAVE <=str (TODAY ):#line:1248
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1249
		debridit .autoUpdate ('all')#line:1250
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1251
	else :#line:1252
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1253
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1254
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1256
if KEEPLOGIN =='true':#line:1257
	if LOGINSAVE <=str (TODAY ):#line:1258
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1259
		loginit .autoUpdate ('all')#line:1260
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1261
	else :#line:1262
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1263
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1264
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1266
if AUTOCLEANUP =='true':#line:1267
	service =False #line:1268
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1269
	feq =int (float (AUTOFEQ ))#line:1270
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1271
		service =True #line:1272
		next_run =days [feq ]#line:1273
		wiz .setS ('nextautocleanup',str (next_run ))#line:1274
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1275
	if service ==True :#line:1276
		AUTOCACHE =wiz .getS ('clearcache')#line:1277
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1278
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1279
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1280
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1281
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1282
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1283
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1284
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1285
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1286
wiz .setS ('kodi17iscrap','')#line:1288
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1357
	count =0 #line:1358
	for f in filenames :#line:1359
		count +=1 #line:1360
		fp =os .path .join (dirpath ,f )#line:1361
		total_size +=os .path .getsize (fp )#line:1362
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1363
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1370
	for f2 in filenames2 :#line:1371
		fp2 =os .path .join (dirpath2 ,f2 )#line:1372
		total_size2 +=os .path .getsize (fp2 )#line:1373
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1374
if int (total_sizetext2 )>filesize_thumb :#line:1376
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1377
	if choice2 ==1 :#line:1378
		maintenance .deleteThumbnails ()#line:1379
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1381
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1382
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1384
time .sleep (3 )#line:1385
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1387
        display_Votes ()#line:1388
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1390
        file .write (str ('Done'))#line:1392
        file .close ()#line:1393
tele =(ADDON .getSetting ("auto_tele"))#line:1398
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1400
    if tele =='true':#line:1402
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:1403
