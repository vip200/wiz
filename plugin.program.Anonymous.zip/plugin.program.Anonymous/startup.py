# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
REQUESTSID =uservar .REQUESTSID #line:120
REQUESTSXML =uservar .REQUESTSXML #line:121
REQUESTSURL =uservar .REQUESTSURL #line:122
COLOR1 =uservar .COLOR1 #line:126
COLOR2 =uservar .COLOR2 #line:127
TMDB_NEW_API =uservar .TMDB_NEW_API #line:128
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:129
FAILED =False #line:130
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:131
AddonID ='plugin.program.Anonymous'#line:133
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:134
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:135
dialog =xbmcgui .Dialog ()#line:136
setting =xbmcaddon .Addon ().getSetting #line:137
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:138
notify_mode =setting ('notify_mode')#line:139
auto_clean =setting ('startup.cache')#line:140
filesize_thumb =int (setting ('filesizethumb_alert'))#line:142
total_size2 =0 #line:145
total_size =0 #line:146
count =0 #line:147
def infobuild ():#line:148
	O0O0O0OO00OOOO0OO =wiz .workingURL (NOTIFICATION )#line:149
	if O0O0O0OO00OOOO0OO ==True :#line:150
		try :#line:151
			O0OOOO00OO0OO0O0O ,O0O000O0OOO000OO0 =wiz .splitNotify (NOTIFICATION )#line:152
			if O0OOOO00OO0OO0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:153
			if STARTP2 ()=='ok':#line:154
				notify .updateinfo (O0O000O0OOO000OO0 ,True )#line:155
		except Exception as OO0O00O0OO0O00O0O :#line:156
			wiz .log ("Error on Notifications Window: %s"%str (OO0O00O0OO0O00O0O ),xbmc .LOGERROR )#line:157
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:158
def disply_hwr ():#line:159
   try :#line:160
    OO0O000000OOOOO00 =tmdb_list (TMDB_NEW_API )#line:161
    O0OOO0O00OOO0O00O =str ((getHwAddr ('eth0'))*OO0O000000OOOOO00 )#line:162
    O000000O0OOO0O0O0 =(O0OOO0O00OOO0O00O [1 ]+O0OOO0O00OOO0O00O [2 ]+O0OOO0O00OOO0O00O [5 ]+O0OOO0O00OOO0O00O [7 ])#line:169
    O0O00OO000O00OO00 =(ADDON .getSetting ("action"))#line:170
    wiz .setS ('action',str (O000000O0OOO0O0O0 ))#line:172
   except :pass #line:173
def getHwAddr (O0OOOO0000OO0OOO0 ):#line:174
   import subprocess ,time #line:175
   O0000O0000O0OOO00 ='windows'#line:176
   if xbmc .getCondVisibility ('system.platform.android'):#line:177
       O0000O0000O0OOO00 ='android'#line:178
   if xbmc .getCondVisibility ('system.platform.android'):#line:179
     O000000OO0000O00O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:180
     OOOOOO0OO0O0O0OOO =re .compile ('link/ether (.+?) brd').findall (str (O000000OO0000O00O ))#line:182
     O000O0O0OO0O000O0 =0 #line:183
     for O000O0O00OO00O0OO in OOOOOO0OO0O0O0OOO :#line:184
      if OOOOOO0OO0O0O0OOO !='00:00:00:00:00:00':#line:185
          OO0OO00OO00OO0000 =O000O0O00OO00O0OO #line:186
          O000O0O0OO0O000O0 =O000O0O0OO0O000O0 +int (OO0OO00OO00OO0000 .replace (':',''),16 )#line:187
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:189
       O0O0OO0OO00O00O00 =0 #line:190
       O000O0O0OO0O000O0 =0 #line:191
       OOOO00O0OO0O00OO0 =[]#line:192
       OO0OO00OOO0000O00 =os .popen ("getmac").read ()#line:193
       OO0OO00OOO0000O00 =OO0OO00OOO0000O00 .split ("\n")#line:194
       for O0OO00OO00O0OOO0O in OO0OO00OOO0000O00 :#line:196
            O0O0O00OOOOO00OO0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OO00OO00O0OOO0O ,re .I )#line:197
            if O0O0O00OOOOO00OO0 :#line:198
                OOOOOO0OO0O0O0OOO =O0O0O00OOOOO00OO0 .group ().replace ('-',':')#line:199
                OOOO00O0OO0O00OO0 .append (OOOOOO0OO0O0O0OOO )#line:200
                O000O0O0OO0O000O0 =O000O0O0OO0O000O0 +int (OOOOOO0OO0O0O0OOO .replace (':',''),16 )#line:203
   else :#line:205
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:206
   try :#line:223
    return O000O0O0OO0O000O0 #line:224
   except :pass #line:225
def decode (O000O00000OO0O00O ,OO000OOO0OO0OO000 ):#line:226
    import base64 #line:227
    OO0O000OOO0000OO0 =[]#line:228
    if (len (O000O00000OO0O00O ))!=4 :#line:230
     return 10 #line:231
    OO000OOO0OO0OO000 =base64 .urlsafe_b64decode (OO000OOO0OO0OO000 )#line:232
    for OO00OOO0OO0O00OO0 in range (len (OO000OOO0OO0OO000 )):#line:234
        O00O0OO00OOO000O0 =O000O00000OO0O00O [OO00OOO0OO0O00OO0 %len (O000O00000OO0O00O )]#line:235
        O0OOOOO0OOO00OOOO =chr ((256 +ord (OO000OOO0OO0OO000 [OO00OOO0OO0O00OO0 ])-ord (O00O0OO00OOO000O0 ))%256 )#line:236
        OO0O000OOO0000OO0 .append (O0OOOOO0OOO00OOOO )#line:237
    return "".join (OO0O000OOO0000OO0 )#line:238
def tmdb_list (O0000OO00O00O00O0 ):#line:239
    O00O000O0OO00O00O =decode ("7643",O0000OO00O00O00O0 )#line:242
    return int (O00O000O0OO00O00O )#line:245
def u_list (O0O0O0OOOOOO00OO0 ):#line:246
    from math import sqrt #line:248
    OO00OOO0OO00OOO00 =tmdb_list (TMDB_NEW_API )#line:249
    O00OOO0OO0OOOO000 =str ((getHwAddr ('eth0'))*OO00OOO0OO00OOO00 )#line:251
    OO0OO00O000OOO0O0 =int (O00OOO0OO0OOOO000 [1 ]+O00OOO0OO0OOOO000 [2 ]+O00OOO0OO0OOOO000 [5 ]+O00OOO0OO0OOOO000 [7 ])#line:252
    O0O0OO0O000OOO000 =(ADDON .getSetting ("pass"))#line:254
    OOO0000OO0O00O00O =(str (round (sqrt ((OO0OO00O000OOO0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:259
    if '.'in OOO0000OO0O00O00O :#line:260
     OOO0000OO0O00O00O =(str (round (sqrt ((OO0OO00O000OOO0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:261
    if O0O0OO0O000OOO000 ==OOO0000OO0O00O00O :#line:262
      OO0OO0OO000O0O0OO =O0O0O0OOOOOO00OO0 #line:264
    else :#line:266
       if STARTP ()and STARTP2 ()=='ok':#line:267
         return O0O0O0OOOOOO00OO0 #line:269
       OO0OO0OO000O0O0OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:270
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:271
       sys .exit ()#line:272
    return OO0OO0OO000O0O0OO #line:273
try :#line:274
   disply_hwr ()#line:275
except :#line:276
   pass #line:277
def dis_or_enable_addon (OO00O0O0O00OOOO00 ,O0OOO00OO00OO0OOO ,enable ="true"):#line:278
    import json #line:279
    O0O0OO0O0OOOOOOO0 ='"%s"'%OO00O0O0O00OOOO00 #line:280
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00O0O0O00OOOO00 )and enable =="true":#line:281
        logging .warning ('already Enabled')#line:282
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00O0O0O00OOOO00 )#line:283
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00O0O0O00OOOO00 )and enable =="false":#line:284
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00O0O0O00OOOO00 )#line:285
    else :#line:286
        O00O0OO000O0O00OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O0OO0O0OOOOOOO0 ,enable )#line:287
        OO000OOOO00OO00OO =xbmc .executeJSONRPC (O00O0OO000O0O00OO )#line:288
        O00OOOO0O0O00O000 =json .loads (OO000OOOO00OO00OO )#line:289
        if enable =="true":#line:290
            xbmc .log ("### Enabled %s, response = %s"%(OO00O0O0O00OOOO00 ,O00OOOO0O0O00O000 ))#line:291
        else :#line:292
            xbmc .log ("### Disabled %s, response = %s"%(OO00O0O0O00OOOO00 ,O00OOOO0O0O00O000 ))#line:293
    if O0OOO00OO00OO0OOO =='auto':#line:294
     return True #line:295
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:296
def update_Votes ():#line:297
   try :#line:298
        import requests #line:299
        O00O00O0O0000O0O0 ='18773068'#line:300
        OOOO000O0OOO00OOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O00O0O0000O0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:312
        OOOO00O00000000OO ='145273321'#line:314
        O000O00O00O00O00O ={'options':OOOO00O00000000OO }#line:320
        O00OO000000O0O0O0 =requests .post ('https://www.strawpoll.me/'+O00O00O0O0000O0O0 ,headers =OOOO000O0OOO00OOO ,data =O000O00O00O00O00O )#line:322
   except :pass #line:323
def display_Votes ():#line:324
    try :#line:325
        OO00O0O0000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:326
        O0OOO0OOO0O000OO0 =open (OO00O0O0000OO0O00 ,'r')#line:328
        OOOOO0000OO0OOOO0 =O0OOO0OOO0O000OO0 .read ()#line:329
        O0OOO0OOO0O000OO0 .close ()#line:330
        O000O000000000OOO ='<setting id="HomeS" type="string">(.+?)</setting>'#line:331
        O0O00OO0000OO00O0 =re .compile (O000O000000000OOO ).findall (OOOOO0000OO0OOOO0 )[0 ]#line:333
        import requests #line:339
        OO0O000OOOO0O00OO ='18782966'#line:340
        O000O0OOO0000O00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O000OOOO0O00OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:352
        O0O00O00O00OO0O00 ='145313053'#line:354
        OO000000O0O00OOOO ='145313054'#line:355
        OOO0OO00OOOOO0O0O ='145313057'#line:356
        OO0OOO00OO0OO00OO ='145313058'#line:357
        OOO000O000000OOOO ='145313055'#line:358
        O00OO000OOOO0OOOO ='145313060'#line:359
        O00O0O0000OOO00OO ='145313056'#line:360
        O00OO000O00OOOOO0 ='145313059'#line:361
        if O0O00OO0000OO00O0 =='emin':#line:364
           O0000O00OO0OO00O0 =O0O00O00O00OO0O00 #line:365
        if O0O00OO0000OO00O0 =='nox':#line:366
           O0000O00OO0OO00O0 =OO000000O0O00OOOO #line:367
        if O0O00OO0000OO00O0 =='noxtitan':#line:368
           O0000O00OO0OO00O0 =OO000000O0O00OOOO #line:369
        if O0O00OO0000OO00O0 =='titan':#line:370
           O0000O00OO0OO00O0 =OOO0OO00OOOOO0O0O #line:371
        if O0O00OO0000OO00O0 =='pheno':#line:372
           O0000O00OO0OO00O0 =OO0OOO00OO0OO00OO #line:373
        if O0O00OO0000OO00O0 =='netflix':#line:374
           O0000O00OO0OO00O0 =OOO000O000000OOOO #line:375
        if O0O00OO0000OO00O0 =='nebula':#line:376
           O0000O00OO0OO00O0 =O00OO000OOOO0OOOO #line:377
        if O0O00OO0000OO00O0 =='pellucid':#line:378
           O0000O00OO0OO00O0 =O00O0O0000OOO00OO #line:379
        if O0O00OO0000OO00O0 =='pellucid2':#line:380
           O0000O00OO0OO00O0 =O00OO000O00OOOOO0 #line:381
        O00O000O0000O0OOO ={'options':O0000O00OO0OO00O0 }#line:387
        OO0O0OOOOOO00O000 =requests .post ('https://www.strawpoll.me/'+OO0O000OOOO0O00OO ,headers =O000O0OOO0000O00O ,data =O00O000O0000O0OOO )#line:389
    except :pass #line:390
def resetkodi ():#line:391
		if xbmc .getCondVisibility ('system.platform.windows'):#line:392
			OO000O0000OOOO00O =xbmcgui .DialogProgress ()#line:393
			OO000O0000OOOO00O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:396
			OO000O0000OOOO00O .update (0 )#line:397
			for OO000O0OOO00O0O00 in range (5 ,-1 ,-1 ):#line:398
				time .sleep (1 )#line:399
				OO000O0000OOOO00O .update (int ((5 -OO000O0OOO00O0O00 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO000O0OOO00O0O00 ),'')#line:400
				if OO000O0000OOOO00O .iscanceled ():#line:401
					from resources .libs import win #line:402
					return None ,None #line:403
			from resources .libs import win #line:404
		else :#line:405
			OO000O0000OOOO00O =xbmcgui .DialogProgress ()#line:406
			OO000O0000OOOO00O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:409
			OO000O0000OOOO00O .update (0 )#line:410
			for OO000O0OOO00O0O00 in range (5 ,-1 ,-1 ):#line:411
				time .sleep (1 )#line:412
				OO000O0000OOOO00O .update (int ((5 -OO000O0OOO00O0O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO000O0OOO00O0O00 ),'')#line:413
				if OO000O0000OOOO00O .iscanceled ():#line:414
					os ._exit (1 )#line:415
					return None ,None #line:416
			os ._exit (1 )#line:417
def indicatorfastupdate ():#line:418
       try :#line:419
          import json #line:420
          wiz .log ('FRESH MESSAGE')#line:421
          OOO0OO0O00OO0OOOO =(ADDON .getSetting ("user"))#line:422
          O00OO00O0O0O00OOO =(ADDON .getSetting ("pass"))#line:423
          O000000OOO0O00O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:424
          OO0OOOOOOO0000O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:426
          O000000O00O0000O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:427
          OO00O0O0O0OO000OO =str (json .loads (O000000O00O0000O0 )['ip'])#line:428
          O0O00OOO0OO0000O0 =OOO0OO0O00OO0OOOO #line:429
          OO00O00OO00O00OOO =O00OO00O0O0O00OOO #line:430
          import socket #line:431
          O000000O00O0000O0 =urllib2 .urlopen (OO0OOOOOOO0000O00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O00OOO0OO0000O0 +' - '+OO00O00OO00O00OOO +' - '+O000000OOO0O00O00 +' - '+OO00O0O0O0OO000OO ).readlines ()#line:432
       except :pass #line:434
def skindialogsettind18 ():#line:435
	try :#line:436
		OO0O0O0O00OOO000O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:437
		OOOO0O0O0O00O00OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:438
		copyfile (OO0O0O0O00OOO000O ,OOOO0O0O0O00O00OO )#line:439
	except :pass #line:440
def checkidupdate ():#line:441
				wiz .setS ("notedismiss","true")#line:443
				O000OO0OO0O00O000 =wiz .workingURL (NOTIFICATION )#line:444
				OO0O0000O000OOOOO =" Kodi Premium"#line:446
				O000OOO0OO0O0O00O =wiz .checkBuild (OO0O0000O000OOOOO ,'gui')#line:447
				O000O00OO0O0OOO00 =OO0O0000O000OOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:448
				if not wiz .workingURL (O000OOO0OO0O0O00O )==True :return #line:449
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:450
				OOOO0O000O0OO00OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000O00OO0O0OOO00 )#line:453
				try :os .remove (OOOO0O000O0OO00OO )#line:454
				except :pass #line:455
				if 'google'in O000OOO0OO0O0O00O :#line:457
				   O0O0OO0OOOO0O000O =googledrive_download (O000OOO0OO0O0O00O ,OOOO0O000O0OO00OO ,DP2 ,wiz .checkBuild (OO0O0000O000OOOOO ,'filesize'))#line:458
				else :#line:461
				  downloaderbg .download3 (O000OOO0OO0O0O00O ,OOOO0O000O0OO00OO ,DP2 )#line:462
				xbmc .sleep (100 )#line:463
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:464
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:466
				extract .all2 (OOOO0O000O0OO00OO ,HOME ,DP2 )#line:468
				DP2 .close ()#line:469
				wiz .defaultSkin ()#line:470
				wiz .lookandFeelData ('save')#line:471
				wiz .kodi17Fix ()#line:472
				if KODIV >=18 :#line:473
					skindialogsettind18 ()#line:474
				debridit .debridIt ('restore','all')#line:479
				traktit .traktIt ('restore','all')#line:480
				if INSTALLMETHOD ==1 :OOO00OOOOO0O0000O =1 #line:481
				elif INSTALLMETHOD ==2 :OOO00OOOOO0O0000O =0 #line:482
				else :DP2 .close ()#line:483
				OO000O0OOOOO0O0O0 =(NOTIFICATION2 )#line:484
				O00O0OOOO00OOO00O =urllib2 .urlopen (OO000O0OOOOO0O0O0 )#line:485
				O000000OOOOOOO000 =O00O0OOOO00OOO00O .readlines ()#line:486
				O00OO0000O0OOOOOO =0 #line:487
				for OOOOOOOO0O0O000O0 in O000000OOOOOOO000 :#line:490
					if OOOOOOOO0O0O000O0 .split (' ==')[0 ]=="noreset"or OOOOOOOO0O0O000O0 .split ()[0 ]=="noreset":#line:491
						xbmc .executebuiltin ("ReloadSkin()")#line:493
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:494
						OO0O0O00OOOOOO0O0 =(ADDON .getSetting ("message"))#line:495
						if OO0O0O00OOOOOO0O0 =='true':#line:496
							infobuild ()#line:497
						update_Votes ()#line:498
						indicatorfastupdate ()#line:499
					if OOOOOOOO0O0O000O0 .split (' ==')[0 ]=="reset"or OOOOOOOO0O0O000O0 .split ()[0 ]=="reset":#line:500
						update_Votes ()#line:502
						indicatorfastupdate ()#line:503
						resetkodi ()#line:504
def checkvictory ():#line:505
				wiz .setS ("notedismiss2","true")#line:507
				OO00O0O000O000O0O =wiz .workingURL (NOTIFICATION2 )#line:508
				OO00O0O0O0O0O00OO =" Kodi Premium"#line:510
				OOOOO0O00OO000O00 ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:511
				O000OOOO0O000000O =OO00O0O0O0O0O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:512
				if not wiz .workingURL (OOOOO0O00OO000O00 )==True :return #line:513
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:514
				OO00O0OOO00OO00OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000OOOO0O000000O )#line:517
				try :os .remove (OO00O0OOO00OO00OO )#line:518
				except :pass #line:519
				if 'google'in OOOOO0O00OO000O00 :#line:521
				   O0OO0OOO0OOOO0OO0 =googledrive_download (OOOOO0O00OO000O00 ,OO00O0OOO00OO00OO ,DP2 ,wiz .checkBuild (OO00O0O0O0O0O00OO ,'filesize'))#line:522
				else :#line:525
				  downloaderbg .download5 (OOOOO0O00OO000O00 ,OO00O0OOO00OO00OO ,DP2 )#line:526
				xbmc .sleep (100 )#line:527
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:528
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:530
				extract .all2 (OO00O0OOO00OO00OO ,ADDONS ,DP2 )#line:532
				DP2 .close ()#line:533
				wiz .defaultSkin ()#line:534
				wiz .lookandFeelData ('save')#line:535
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:536
				if INSTALLMETHOD ==1 :O00OO000O0000OO0O =1 #line:538
				elif INSTALLMETHOD ==2 :O00OO000O0000OO0O =0 #line:539
				else :DP2 .close ()#line:540
def checkUpdate ():#line:545
	OOOOOOOO000O0O00O =wiz .getS ('buildname')#line:546
	OO00O00OO0000O000 =wiz .getS ('buildversion')#line:547
	OO00OO00OO0O000O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:548
	O0000OOO0O0000000 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOOOOOOO000O0O00O ).findall (OO00OO00OO0O000O0 )#line:549
	if len (O0000OOO0O0000000 )>0 :#line:550
		OOO0O0O0O00O0O000 =O0000OOO0O0000000 [0 ][0 ]#line:551
		OO00O000OO0O0O00O =O0000OOO0O0000000 [0 ][1 ]#line:552
		OOO0OOOO0000000O0 =O0000OOO0O0000000 [0 ][2 ]#line:553
		wiz .setS ('latestversion',OOO0O0O0O00O0O000 )#line:554
		if OOO0O0O0O00O0O000 >OO00O00OO0000O000 :#line:555
			if DISABLEUPDATE =='false':#line:556
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OO00O00OO0000O000 ,OOO0O0O0O00O0O000 ),xbmc .LOGNOTICE )#line:557
				notify .updateWindow (OOOOOOOO000O0O00O ,OO00O00OO0000O000 ,OOO0O0O0O00O0O000 ,OO00O000OO0O0O00O ,OOO0OOOO0000000O0 )#line:558
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OO00O00OO0000O000 ,OOO0O0O0O00O0O000 ),xbmc .LOGNOTICE )#line:559
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OO00O00OO0000O000 ,OOO0O0O0O00O0O000 ),xbmc .LOGNOTICE )#line:560
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:561
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:596
if AUTOUPDATE =='Yes':#line:597
	input =(ADDON .getSetting ("autoupdate"))#line:598
	xbmc .executebuiltin ("UpdateLocalAddons")#line:599
	xbmc .executebuiltin ("UpdateAddonRepos")#line:600
	wiz .wizardUpdate ('startup')#line:601
	checkUpdate ()#line:603
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:605
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:609
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:610
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:612
	workingxml =wiz .workingURL (REPOADDONXML )#line:613
	if workingxml ==True :#line:614
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:615
		if len (ver )>0 :#line:616
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:617
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:618
			if workingrepo ==True :#line:619
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:620
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:621
				lib =os .path .join (PACKAGES ,installzip )#line:622
				try :os .remove (lib )#line:623
				except :pass #line:624
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:625
				extract .all (lib ,ADDONS ,DP )#line:626
				try :#line:627
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:628
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:629
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:630
				except :#line:631
					pass #line:632
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:633
				DP .close ()#line:634
				xbmc .sleep (500 )#line:635
				wiz .forceUpdate (True )#line:636
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:637
				xbmc .executebuiltin ("ReloadSkin()")#line:638
				xbmc .executebuiltin ("ActivateWindow(home)")#line:639
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:640
				xbmc .Player ().play (f_play ,windowed =False )#line:641
			else :#line:643
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:644
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:645
		else :#line:646
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:647
	else :#line:648
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:649
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:650
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:651
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:652
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:655
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:656
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:657
	if BUILDNAME =="":#line:658
		try :#line:659
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:660
		except :#line:661
				pass #line:662
	if workingxml ==True :#line:663
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:664
		if len (ver )>0 :#line:665
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:666
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:667
			if workingrepo ==True :#line:668
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:669
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:670
				lib =os .path .join (PACKAGES ,installzip )#line:671
				try :os .remove (lib )#line:672
				except :pass #line:673
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:674
				extract .all (lib ,ADDONS ,DP )#line:675
				try :#line:676
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:677
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:678
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:679
				except :#line:680
					pass #line:681
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:682
				DP .close ()#line:683
				xbmc .sleep (500 )#line:684
				wiz .forceUpdate (True )#line:685
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:686
				xbmc .executebuiltin ("ReloadSkin()")#line:687
				xbmc .executebuiltin ("ActivateWindow(home)")#line:688
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:689
				xbmc .Player ().play (f_play ,windowed =False )#line:690
			else :#line:692
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:693
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:694
		else :#line:695
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:696
	else :#line:697
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:698
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:699
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:702
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:703
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REQUESTSID )):#line:706
	workingxml =wiz .workingURL (REQUESTSXML )#line:707
	if workingxml ==True :#line:709
		ver =wiz .parseDOM (wiz .openURL (REQUESTSXML ),'addon',ret ='version',attrs ={'id':REQUESTSID })#line:710
		if len (ver )>0 :#line:711
			installzip ='%s-%s.zip'%(REQUESTSID ,ver [0 ])#line:712
			workingrepo =wiz .workingURL (REQUESTSURL +installzip )#line:713
			if workingrepo ==True :#line:714
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:716
				lib =os .path .join (PACKAGES ,installzip )#line:717
				try :os .remove (lib )#line:718
				except :pass #line:719
				downloaderbg .download4 (REQUESTSURL +installzip ,lib ,DP2 )#line:720
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:721
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:722
				extract .all2 (lib ,ADDONS ,DP2 )#line:723
				try :#line:724
					f =open (os .path .join (ADDONS ,REQUESTSID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:725
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REQUESTSID })#line:726
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REQUESTSID ,'icon.png'))#line:727
				except :#line:728
					pass #line:729
				if KODIV >=17 :wiz .addonDatabase (REQUESTSID ,1 )#line:730
				DP2 .close ()#line:731
				xbmc .sleep (500 )#line:732
				wiz .forceUpdate (True )#line:733
				wiz .kodi17Fix ()#line:734
def setuname ():#line:738
    O0OOO0OOOOOO000O0 =''#line:739
    OOO0OOOOO00000OO0 =xbmc .Keyboard (O0OOO0OOOOOO000O0 ,'הכנס שם משתמש')#line:740
    OOO0OOOOO00000OO0 .doModal ()#line:741
    if OOO0OOOOO00000OO0 .isConfirmed ():#line:742
           O0OOO0OOOOOO000O0 =OOO0OOOOO00000OO0 .getText ()#line:743
           wiz .setS ('user',str (O0OOO0OOOOOO000O0 ))#line:744
def STARTP2 ():#line:745
	if BUILDNAME ==" Kodi Premium":#line:746
		O0O000O000OOO00O0 =(ADDON .getSetting ("user"))#line:747
		O000O0O0O00OOO00O =(UNAME )#line:748
		O0000O0OOOOOO0O00 =urllib2 .urlopen (O000O0O0O00OOO00O )#line:749
		O0O0OOOO0O0O0OO00 =O0000O0OOOOOO0O00 .readlines ()#line:750
		OO0OOO0OOOO000O0O =0 #line:751
		for OO0000000OO0OO0O0 in O0O0OOOO0O0O0OO00 :#line:752
			if OO0000000OO0OO0O0 .split (' ==')[0 ]==O0O000O000OOO00O0 or OO0000000OO0OO0O0 .split ()[0 ]==O0O000O000OOO00O0 :#line:753
				OO0OOO0OOOO000O0O =1 #line:754
				break #line:755
		if OO0OOO0OOOO000O0O ==0 :#line:756
			O00OO0OOO000OO0OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:758
			if O00OO0OOO000OO0OO :#line:760
				ADDON .openSettings ()#line:761
				sys .exit ()#line:762
			else :#line:763
				sys .exit ()#line:764
		return 'ok'#line:768
def skinWIN ():#line:771
	idle ()#line:772
	OO00O00OO0000OO00 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:773
	O00O00O0OOO0OO0OO =[];OOO0OO0OOO0O00O00 =[]#line:774
	for O00OO0OOO0000OOO0 in sorted (OO00O00OO0000OO00 ,key =lambda O0O0O0000O0OOO0O0 :O0O0O0000O0OOO0O0 ):#line:775
		O00O00000O0O0O00O =os .path .split (O00OO0OOO0000OOO0 [:-1 ])[1 ]#line:776
		OO0OOO0OO000O0000 =os .path .join (O00OO0OOO0000OOO0 ,'addon.xml')#line:777
		if os .path .exists (OO0OOO0OO000O0000 ):#line:778
			O0OO0OOOO00OOO0O0 =open (OO0OOO0OO000O0000 )#line:779
			OOO000OOOOO0OO0OO =O0OO0OOOO00OOO0O0 .read ()#line:780
			O0O0000OO0O00OOOO =parseDOM2 (OOO000OOOOO0OO0OO ,'addon',ret ='id')#line:781
			O0000OOOOOOO00OOO =O00O00000O0O0O00O if len (O0O0000OO0O00OOOO )==0 else O0O0000OO0O00OOOO [0 ]#line:782
			try :#line:783
				O0OO0O0O000OO0O00 =xbmcaddon .Addon (id =O0000OOOOOOO00OOO )#line:784
				O00O00O0OOO0OO0OO .append (O0OO0O0O000OO0O00 .getAddonInfo ('name'))#line:785
				OOO0OO0OOO0O00O00 .append (O0000OOOOOOO00OOO )#line:786
			except :#line:787
				pass #line:788
	O0OOOOOOOO00OOOOO =[];OOO00000O0O0000OO =0 #line:789
	OO00O0OO0O0O0OOO0 =["Current Skin -- %s"%currSkin ()]+O00O00O0OOO0OO0OO #line:790
	OOO00000O0O0000OO =DIALOG .select ("Select the Skin you want to swap with.",OO00O0OO0O0O0OOO0 )#line:791
	if OOO00000O0O0000OO ==-1 :return #line:792
	else :#line:793
		O0O0OOO000OO0OOOO =(OOO00000O0O0000OO -1 )#line:794
		O0OOOOOOOO00OOOOO .append (O0O0OOO000OO0OOOO )#line:795
		OO00O0OO0O0O0OOO0 [OOO00000O0O0000OO ]="%s"%(O00O00O0OOO0OO0OO [O0O0OOO000OO0OOOO ])#line:796
	if O0OOOOOOOO00OOOOO ==None :return #line:797
	for O000OO000O00O0OOO in O0OOOOOOOO00OOOOO :#line:798
		swapSkins (OOO0OO0OOO0O00O00 [O000OO000O00O0OOO ])#line:799
def currSkin ():#line:801
	return xbmc .getSkinDir ('Container.PluginName')#line:802
def fix17update ():#line:804
	if KODIV >=17 and KODIV <18 :#line:805
		wiz .kodi17Fix ()#line:806
		xbmc .sleep (4000 )#line:807
		try :#line:808
			O00OO000OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:809
			OO0O0O0OO00O00O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:810
			os .rename (O00OO000OOOOO0OO0 ,OO0O0O0OO00O00O0O )#line:811
		except :#line:812
				pass #line:813
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:814
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:815
		fixfont ()#line:816
		O0OOOOOO0000OOOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:817
		try :#line:819
			O0O0000OOOOOOO0OO =open (O0OOOOOO0000OOOO0 ,'r')#line:820
			O0O0OO0O0OOO00000 =O0O0000OOOOOOO0OO .read ()#line:821
			O0O0000OOOOOOO0OO .close ()#line:822
			OOO0OOOOO000OO0O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:823
			OO0OO00OO00O00O00 =re .compile (OOO0OOOOO000OO0O0 ).findall (O0O0OO0O0OOO00000 )[0 ]#line:824
			O0O0000OOOOOOO0OO =open (O0OOOOOO0000OOOO0 ,'w')#line:825
			O0O0000OOOOOOO0OO .write (O0O0OO0O0OOO00000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0OO00OO00O00O00 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:826
			O0O0000OOOOOOO0OO .close ()#line:827
		except :#line:828
				pass #line:829
		wiz .kodi17Fix ()#line:830
		O0OOOOOO0000OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:831
		try :#line:832
			O0O0000OOOOOOO0OO =open (O0OOOOOO0000OOOO0 ,'r')#line:833
			O0O0OO0O0OOO00000 =O0O0000OOOOOOO0OO .read ()#line:834
			O0O0000OOOOOOO0OO .close ()#line:835
			OOO0OOOOO000OO0O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:836
			OO0OO00OO00O00O00 =re .compile (OOO0OOOOO000OO0O0 ).findall (O0O0OO0O0OOO00000 )[0 ]#line:837
			O0O0000OOOOOOO0OO =open (O0OOOOOO0000OOOO0 ,'w')#line:838
			O0O0000OOOOOOO0OO .write (O0O0OO0O0OOO00000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0OO00OO00O00O00 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:839
			O0O0000OOOOOOO0OO .close ()#line:840
		except :#line:841
				pass #line:842
		swapSkins ('skin.Premium.mod')#line:843
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:844
	os ._exit (1 )#line:845
def fix18update ():#line:846
	if KODIV >=18 :#line:847
		xbmc .sleep (4000 )#line:848
		if BUILDNAME =="":#line:849
			try :#line:850
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:851
			except :#line:852
				pass #line:853
		try :#line:854
			O0OOOO0000OOOO00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:855
			OOOO00OO0OOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:856
			os .rename (O0OOOO0000OOOO00O ,OOOO00OO0OOOOO0OO )#line:857
		except :#line:858
				pass #line:859
		skindialogsettind18 ()#line:860
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:861
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:862
		fixfont ()#line:863
		O00O00OO0OO0O0O0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:864
		try :#line:865
			O000O00OO000O0000 =open (O00O00OO0OO0O0O0O ,'r')#line:866
			OOO0000OO00OO000O =O000O00OO000O0000 .read ()#line:867
			O000O00OO000O0000 .close ()#line:868
			OO00O0OO0O000O0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:869
			OOO0O0O0O0000OOO0 =re .compile (OO00O0OO0O000O0O0 ).findall (OOO0000OO00OO000O )[0 ]#line:870
			O000O00OO000O0000 =open (O00O00OO0OO0O0O0O ,'w')#line:871
			O000O00OO000O0000 .write (OOO0000OO00OO000O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOO0O0O0O0000OOO0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:872
			O000O00OO000O0000 .close ()#line:873
		except :#line:874
				pass #line:875
		wiz .kodi17Fix ()#line:876
		O00O00OO0OO0O0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:877
		try :#line:878
			O000O00OO000O0000 =open (O00O00OO0OO0O0O0O ,'r')#line:879
			OOO0000OO00OO000O =O000O00OO000O0000 .read ()#line:880
			O000O00OO000O0000 .close ()#line:881
			OO00O0OO0O000O0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:882
			OOO0O0O0O0000OOO0 =re .compile (OO00O0OO0O000O0O0 ).findall (OOO0000OO00OO000O )[0 ]#line:883
			O000O00OO000O0000 =open (O00O00OO0OO0O0O0O ,'w')#line:884
			O000O00OO000O0000 .write (OOO0000OO00OO000O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOO0O0O0O0000OOO0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:885
			O000O00OO000O0000 .close ()#line:886
		except :#line:887
				pass #line:888
		swapSkins ('skin.Premium.mod')#line:889
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:890
	os ._exit (1 )#line:891
def swapSkins (OO00O000OOOO00000 ,title ="Error"):#line:892
	O00O0OOOO0O00OO0O ='lookandfeel.skin'#line:893
	OO00OO0O0OOO0OOOO =OO00O000OOOO00000 #line:894
	O0O00000OOOO0000O =getOld (O00O0OOOO0O00OO0O )#line:895
	O0000O0O0000000OO =O00O0OOOO0O00OO0O #line:896
	setNew (O0000O0O0000000OO ,OO00OO0O0OOO0OOOO )#line:897
	OOOO0OOO0O0O00O0O =0 #line:898
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0OOO0O0O00O0O <100 :#line:899
		OOOO0OOO0O0O00O0O +=1 #line:900
		xbmc .sleep (1 )#line:901
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:902
		xbmc .executebuiltin ('SendClick(11)')#line:903
	return True #line:904
def getOld (O0O00O0OO00OO0O0O ):#line:906
	try :#line:907
		O0O00O0OO00OO0O0O ='"%s"'%O0O00O0OO00OO0O0O #line:908
		O0OO000OOOOO0OO00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O00O0OO00OO0O0O )#line:909
		O0000OOO00OOOOOOO =xbmc .executeJSONRPC (O0OO000OOOOO0OO00 )#line:911
		O0000OOO00OOOOOOO =simplejson .loads (O0000OOO00OOOOOOO )#line:912
		if O0000OOO00OOOOOOO .has_key ('result'):#line:913
			if O0000OOO00OOOOOOO ['result'].has_key ('value'):#line:914
				return O0000OOO00OOOOOOO ['result']['value']#line:915
	except :#line:916
		pass #line:917
	return None #line:918
def setNew (O0O000OO00000O0OO ,OOOOO0OO0O00O0OO0 ):#line:921
	try :#line:922
		O0O000OO00000O0OO ='"%s"'%O0O000OO00000O0OO #line:923
		OOOOO0OO0O00O0OO0 ='"%s"'%OOOOO0OO0O00O0OO0 #line:924
		O000OOOOOOO000O00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O000OO00000O0OO ,OOOOO0OO0O00O0OO0 )#line:925
		OO00OO0O000O0O0O0 =xbmc .executeJSONRPC (O000OOOOOOO000O00 )#line:927
	except :#line:928
		pass #line:929
	return None #line:930
def idle ():#line:931
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:932
def fixfont ():#line:933
	OO000000O0O0O00O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:934
	OO0OOO00O0OO000O0 =json .loads (OO000000O0O0O00O0 );#line:936
	OOOO0OOOOO000OOOO =OO0OOO00O0OO000O0 ["result"]["settings"]#line:937
	OO000000OOO0O00O0 =[OOO0O00OO00000OOO for OOO0O00OO00000OOO in OOOO0OOOOO000OOOO if OOO0O00OO00000OOO ["id"]=="audiooutput.audiodevice"][0 ]#line:939
	OOO00OO0OOO0OOO0O =OO000000OOO0O00O0 ["options"];#line:940
	OOOOOOOO0OOOOO000 =OO000000OOO0O00O0 ["value"];#line:941
	OO0OO000OO00OO00O =[OOO00OOO00O0OO0OO for (OOO00OOO00O0OO0OO ,O00O00O0OO00OOO0O )in enumerate (OOO00OO0OOO0OOO0O )if O00O00O0OO00OOO0O ["value"]==OOOOOOOO0OOOOO000 ][0 ];#line:943
	OO00O0O0OO0OOOOO0 =(OO0OO000OO00OO00O +1 )%len (OOO00OO0OOO0OOO0O )#line:945
	OOOO0OO0O000OOO0O =OOO00OO0OOO0OOO0O [OO00O0O0OO0OOOOO0 ]["value"]#line:947
	O00000O0000OOO0O0 =OOO00OO0OOO0OOO0O [OO00O0O0OO0OOOOO0 ]["label"]#line:948
	OOOO0OO0O0OOO000O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:950
	try :#line:952
		O0OO0OOO0O0O0OOOO =json .loads (OOOO0OO0O0OOO000O );#line:953
		if O0OO0OOO0O0O0OOOO ["result"]!=True :#line:955
			raise Exception #line:956
	except :#line:957
		sys .stderr .write ("Error switching audio output device")#line:958
		raise Exception #line:959
def checkSkin ():#line:962
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:963
	OO0O0O00OOOO000OO =wiz .getS ('defaultskin')#line:964
	O00O0O0000O0OOO00 =wiz .getS ('defaultskinname')#line:965
	O0OOOOO0OOO000O0O =wiz .getS ('defaultskinignore')#line:966
	O000000000O00O000 =False #line:967
	if not OO0O0O00OOOO000OO =='':#line:968
		if os .path .exists (os .path .join (ADDONS ,OO0O0O00OOOO000OO )):#line:969
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O0000O0OOO00 )):#line:970
				O000000000O00O000 =OO0O0O00OOOO000OO #line:971
				O0O000O0000O0O0O0 =O00O0O0000O0OOO00 #line:972
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O000000000O00O000 =False #line:973
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OO0O0O00OOOO000OO ='';O00O0O0000O0OOO00 =''#line:974
	if OO0O0O00OOOO000OO =='':#line:975
		OOO0000000O0OO0OO =[]#line:976
		O0OOOOO00OO0OO0O0 =[]#line:977
		for O000O0OOO0O0O0OO0 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:978
			OOOOO0O00O00O0000 ="%s/addon.xml"%O000O0OOO0O0O0OO0 #line:979
			if os .path .exists (OOOOO0O00O00O0000 ):#line:980
				OO000O0OO0O000O00 =open (OOOOO0O00O00O0000 ,mode ='r');O0O0O00O0O00OO000 =OO000O0OO0O000O00 .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO000O0OO0O000O00 .close ();#line:981
				O0OOO0OOOOOOOO000 =wiz .parseDOM (O0O0O00O0O00OO000 ,'addon',ret ='id')#line:982
				O0O0O00O0O000O0O0 =wiz .parseDOM (O0O0O00O0O00OO000 ,'addon',ret ='name')#line:983
				wiz .log ("%s: %s"%(O000O0OOO0O0O0OO0 ,str (O0OOO0OOOOOOOO000 [0 ])),xbmc .LOGNOTICE )#line:984
				if len (O0OOO0OOOOOOOO000 )>0 :O0OOOOO00OO0OO0O0 .append (str (O0OOO0OOOOOOOO000 [0 ]));OOO0000000O0OO0OO .append (str (O0O0O00O0O000O0O0 [0 ]))#line:985
				else :wiz .log ("ID not found for %s"%O000O0OOO0O0O0OO0 ,xbmc .LOGNOTICE )#line:986
			else :wiz .log ("ID not found for %s"%O000O0OOO0O0O0OO0 ,xbmc .LOGNOTICE )#line:987
		if len (O0OOOOO00OO0OO0O0 )>0 :#line:988
			if len (O0OOOOO00OO0OO0O0 )>1 :#line:989
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:990
					OO000OOO0000O0OOO =DIALOG .select ("Select skin to switch to!",OOO0000000O0OO0OO )#line:991
					if OO000OOO0000O0OOO ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:992
					else :#line:993
						O000000000O00O000 =O0OOOOO00OO0OO0O0 [OO000OOO0000O0OOO ]#line:994
						O0O000O0000O0O0O0 =OOO0000000O0OO0OO [OO000OOO0000O0OOO ]#line:995
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:996
	if O000000000O00O000 :#line:1003
		skinSwitch .swapSkins (O000000000O00O000 )#line:1004
		OOO0OOO0OOOOOOOOO =0 #line:1005
		xbmc .sleep (1000 )#line:1006
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0OOO0OOOOOOOOO <150 :#line:1007
			OOO0OOO0OOOOOOOOO +=1 #line:1008
			xbmc .sleep (200 )#line:1009
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1011
			wiz .ebi ('SendClick(11)')#line:1012
			wiz .lookandFeelData ('restore')#line:1013
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1014
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1015
while xbmc .Player ().isPlayingVideo ():#line:1017
	xbmc .sleep (1000 )#line:1018
if KODIV >=17 :#line:1020
	NOW =datetime .now ()#line:1021
	temp =wiz .getS ('kodi17iscrap')#line:1022
	if not temp =='':#line:1023
		if temp >str (NOW -timedelta (minutes =2 )):#line:1024
			wiz .log ("Killing Start Up Script")#line:1025
			sys .exit ()#line:1026
	wiz .log ("%s"%(NOW ))#line:1027
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1028
	xbmc .sleep (1000 )#line:1029
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1030
		wiz .log ("Killing Start Up Script")#line:1031
		sys .exit ()#line:1032
	else :#line:1033
		wiz .log ("Continuing Start Up Script")#line:1034
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1036
path =os .path .split (ADDONPATH )#line:1037
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1038
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1039
if KODIADDONS in ADDONPATH :#line:1042
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1043
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1044
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1045
	if os .path .exists (newpath ):#line:1046
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1047
		wiz .cleanHouse (newpath )#line:1048
		wiz .removeFolder (newpath )#line:1049
	try :#line:1050
		wiz .copytree (ADDONPATH ,newpath )#line:1051
	except Exception as e :#line:1052
		pass #line:1053
	wiz .forceUpdate (True )#line:1054
try :#line:1056
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1057
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1058
except :#line:1059
	pass #line:1060
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1062
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1066
			wiz .kodi17Fix ()#line:1067
			fix18update ()#line:1068
			fix17update ()#line:1069
if INSTALLED =='true':#line:1072
    input =(ADDON .getSetting ("auto_rd"))#line:1073
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1075
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1076
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1077
    wiz .clearS ('install')#line:1078
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1163
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1165
	input =(ADDON .getSetting ("autoupdate"))#line:1166
	STARTP2 ()#line:1167
	if not NOTIFY =='true':#line:1168
		url =wiz .workingURL (NOTIFICATION )#line:1169
		if url ==True :#line:1170
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1171
			if not id ==False :#line:1172
				try :#line:1173
					id =int (id );NOTEID =int (NOTEID )#line:1174
					if id ==NOTEID :#line:1175
						if NOTEDISMISS =='false':#line:1176
							debridit .debridIt ('update','all')#line:1177
							traktit .traktIt ('update','all')#line:1178
							checkidupdate ()#line:1179
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1180
					elif id >NOTEID :#line:1181
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1182
						wiz .setS ('noteid',str (id ))#line:1183
						wiz .setS ('notedismiss','false')#line:1184
						if input =='true':#line:1185
							debridit .debridIt ('update','all')#line:1186
							traktit .traktIt ('update','all')#line:1187
							checkidupdate ()#line:1188
						else :notify .notification (msg =msg )#line:1189
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1190
				except Exception as e :#line:1191
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1192
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1193
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1194
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1195
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1196
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1198
if ENABLE =='No':#line:1199
	if not NOTIFY2 =='true':#line:1200
		url =wiz .workingURL (NOTIFICATION2 )#line:1201
		if url ==True :#line:1202
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1203
			if not id ==False :#line:1204
				try :#line:1205
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1206
					if id ==NOTEID2 :#line:1207
						if NOTEDISMISS2 =='false':#line:1208
							checkvictory ()#line:1209
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1210
					elif id >NOTEID2 :#line:1211
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1212
						wiz .setS ('noteid2',str (id ))#line:1213
						wiz .setS ('notedismiss2','false')#line:1214
						checkvictory ()#line:1215
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1216
				except Exception as e :#line:1217
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1218
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1219
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1220
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1221
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1222
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1224
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1225
	if not NOTIFY3 =='true':#line:1226
		url =wiz .workingURL (NOTIFICATION3 )#line:1227
		if url ==True :#line:1228
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1229
			if not id ==False :#line:1230
				try :#line:1231
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1232
					if id ==NOTEID3 :#line:1233
						if NOTEDISMISS3 =='false':#line:1234
							notify .notification3 (msg )#line:1235
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1236
					elif id >NOTEID3 :#line:1237
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1238
						wiz .setS ('noteid3',str (id ))#line:1239
						wiz .setS ('notedismiss3','false')#line:1240
						notify .notification3 (msg =msg )#line:1241
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1242
				except Exception as e :#line:1243
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1244
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1245
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1246
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1247
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1248
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1249
if KEEPTRAKT =='true':#line:1250
	if TRAKTSAVE <=str (TODAY ):#line:1251
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1252
		traktit .autoUpdate ('all')#line:1253
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1254
	else :#line:1255
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1256
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1257
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1259
if KEEPREAL =='true':#line:1260
	if REALSAVE <=str (TODAY ):#line:1261
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1262
		debridit .autoUpdate ('all')#line:1263
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1264
	else :#line:1265
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1266
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1267
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1269
if KEEPLOGIN =='true':#line:1270
	if LOGINSAVE <=str (TODAY ):#line:1271
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1272
		loginit .autoUpdate ('all')#line:1273
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1274
	else :#line:1275
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1276
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1277
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1279
if AUTOCLEANUP =='true':#line:1280
	service =False #line:1281
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1282
	feq =int (float (AUTOFEQ ))#line:1283
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1284
		service =True #line:1285
		next_run =days [feq ]#line:1286
		wiz .setS ('nextautocleanup',str (next_run ))#line:1287
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1288
	if service ==True :#line:1289
		AUTOCACHE =wiz .getS ('clearcache')#line:1290
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1291
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1292
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1293
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1294
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1295
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1296
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1297
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1298
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1299
wiz .setS ('kodi17iscrap','')#line:1301
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1370
	count =0 #line:1371
	for f in filenames :#line:1372
		count +=1 #line:1373
		fp =os .path .join (dirpath ,f )#line:1374
		total_size +=os .path .getsize (fp )#line:1375
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1376
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1383
	for f2 in filenames2 :#line:1384
		fp2 =os .path .join (dirpath2 ,f2 )#line:1385
		total_size2 +=os .path .getsize (fp2 )#line:1386
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1387
if int (total_sizetext2 )>filesize_thumb :#line:1389
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1390
	if choice2 ==1 :#line:1391
		maintenance .deleteThumbnails ()#line:1392
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1394
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1395
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1397
time .sleep (3 )#line:1398
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1400
        display_Votes ()#line:1401
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1403
        file .write (str ('Done'))#line:1405
        file .close ()#line:1406
tele =(ADDON .getSetting ("auto_tele"))#line:1411
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1413
    if tele =='true':#line:1415
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:1416
