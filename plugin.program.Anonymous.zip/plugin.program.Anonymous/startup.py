# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
REQUESTSID =uservar .REQUESTSID #line:120
REQUESTSXML =uservar .REQUESTSXML #line:121
REQUESTSURL =uservar .REQUESTSURL #line:122
COLOR1 =uservar .COLOR1 #line:126
COLOR2 =uservar .COLOR2 #line:127
TMDB_NEW_API =uservar .TMDB_NEW_API #line:128
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:129
FAILED =False #line:130
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:131
AddonID ='plugin.program.Anonymous'#line:133
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:134
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:135
dialog =xbmcgui .Dialog ()#line:136
setting =xbmcaddon .Addon ().getSetting #line:137
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:138
notify_mode =setting ('notify_mode')#line:139
auto_clean =setting ('startup.cache')#line:140
filesize_thumb =int (setting ('filesizethumb_alert'))#line:142
total_size2 =0 #line:145
total_size =0 #line:146
count =0 #line:147
def disply_hwr ():#line:149
   try :#line:150
    O00OO00000000OO00 =tmdb_list (TMDB_NEW_API )#line:151
    OOO00O0OOOO0OOO0O =str ((getHwAddr ('eth0'))*O00OO00000000OO00 )#line:152
    OO00OO0OOOOOOOO00 =(OOO00O0OOOO0OOO0O [1 ]+OOO00O0OOOO0OOO0O [2 ]+OOO00O0OOOO0OOO0O [5 ]+OOO00O0OOOO0OOO0O [7 ])#line:159
    O0O0OO0OO00OOOO0O =(ADDON .getSetting ("action"))#line:160
    wiz .setS ('action',str (OO00OO0OOOOOOOO00 ))#line:162
   except :pass #line:163
def getHwAddr (OOOO00OO0O0OOOOO0 ):#line:164
   import subprocess ,time #line:165
   OOOOOO000OOOOO000 ='windows'#line:166
   if xbmc .getCondVisibility ('system.platform.android'):#line:167
       OOOOOO000OOOOO000 ='android'#line:168
   if xbmc .getCondVisibility ('system.platform.android'):#line:169
     OOO0O0O00OOO00O0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:170
     O000OOO0O00OO000O =re .compile ('link/ether (.+?) brd').findall (str (OOO0O0O00OOO00O0O ))#line:172
     O00000O0O0OOO0OOO =0 #line:173
     for O0OOOO000000O0000 in O000OOO0O00OO000O :#line:174
      if O000OOO0O00OO000O !='00:00:00:00:00:00':#line:175
          OO00O0OO0OOOO0O00 =O0OOOO000000O0000 #line:176
          O00000O0O0OOO0OOO =O00000O0O0OOO0OOO +int (OO00O0OO0OOOO0O00 .replace (':',''),16 )#line:177
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:179
       O0000OOO0OO0OO0OO =0 #line:180
       O00000O0O0OOO0OOO =0 #line:181
       OOO00O0O000OOOO00 =[]#line:182
       OOOO000OO000O0O0O =os .popen ("getmac").read ()#line:183
       OOOO000OO000O0O0O =OOOO000OO000O0O0O .split ("\n")#line:184
       for OOO00OO00O0000O00 in OOOO000OO000O0O0O :#line:186
            O00O00OOOO0O0OOO0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO00OO00O0000O00 ,re .I )#line:187
            if O00O00OOOO0O0OOO0 :#line:188
                O000OOO0O00OO000O =O00O00OOOO0O0OOO0 .group ().replace ('-',':')#line:189
                OOO00O0O000OOOO00 .append (O000OOO0O00OO000O )#line:190
                O00000O0O0OOO0OOO =O00000O0O0OOO0OOO +int (O000OOO0O00OO000O .replace (':',''),16 )#line:193
   else :#line:195
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:196
   try :#line:213
    return O00000O0O0OOO0OOO #line:214
   except :pass #line:215
def decode (OOOO0000000OO0O00 ,OOOO0O0000OO00000 ):#line:216
    import base64 #line:217
    OOOOO0OO0OOOO000O =[]#line:218
    if (len (OOOO0000000OO0O00 ))!=4 :#line:220
     return 10 #line:221
    OOOO0O0000OO00000 =base64 .urlsafe_b64decode (OOOO0O0000OO00000 )#line:222
    for O0000OO0OOO00OO0O in range (len (OOOO0O0000OO00000 )):#line:224
        OOO0OO00000OO000O =OOOO0000000OO0O00 [O0000OO0OOO00OO0O %len (OOOO0000000OO0O00 )]#line:225
        OO0OOO0000OOO000O =chr ((256 +ord (OOOO0O0000OO00000 [O0000OO0OOO00OO0O ])-ord (OOO0OO00000OO000O ))%256 )#line:226
        OOOOO0OO0OOOO000O .append (OO0OOO0000OOO000O )#line:227
    return "".join (OOOOO0OO0OOOO000O )#line:228
def tmdb_list (O00000OO000OO00O0 ):#line:229
    O0OO0O00000O0OOOO =decode ("7643",O00000OO000OO00O0 )#line:232
    return int (O0OO0O00000O0OOOO )#line:235
def u_list (OO00OO000O0000O00 ):#line:236
    from math import sqrt #line:238
    OO0OOO0O0O00O0O0O =tmdb_list (TMDB_NEW_API )#line:239
    OOOO0OOO00O000O00 =str ((getHwAddr ('eth0'))*OO0OOO0O0O00O0O0O )#line:241
    O00000OOOO00O0OOO =int (OOOO0OOO00O000O00 [1 ]+OOOO0OOO00O000O00 [2 ]+OOOO0OOO00O000O00 [5 ]+OOOO0OOO00O000O00 [7 ])#line:242
    O00O0OOOOO0O0000O =(ADDON .getSetting ("pass"))#line:244
    OO0O0OO0000OOO000 =(str (round (sqrt ((O00000OOOO00O0OOO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:249
    if '.'in OO0O0OO0000OOO000 :#line:250
     OO0O0OO0000OOO000 =(str (round (sqrt ((O00000OOOO00O0OOO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:251
    if O00O0OOOOO0O0000O ==OO0O0OO0000OOO000 :#line:252
      OOOO0O00O000OO000 =OO00OO000O0000O00 #line:254
    else :#line:256
       if STARTP ()and STARTP2 ()=='ok':#line:257
         return OO00OO000O0000O00 #line:259
       OOOO0O00O000OO000 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:260
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:261
       sys .exit ()#line:262
    return OOOO0O00O000OO000 #line:263
try :#line:264
   disply_hwr ()#line:265
except :#line:266
   pass #line:267
def dis_or_enable_addon (OOO0OOOOO0O0O0000 ,OOO0000O0OOO0O00O ,enable ="true"):#line:268
    import json #line:269
    OO0000O0O0OOO0OO0 ='"%s"'%OOO0OOOOO0O0O0000 #line:270
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0OOOOO0O0O0000 )and enable =="true":#line:271
        logging .warning ('already Enabled')#line:272
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0OOOOO0O0O0000 )#line:273
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0OOOOO0O0O0000 )and enable =="false":#line:274
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0OOOOO0O0O0000 )#line:275
    else :#line:276
        OO0000000OO0OO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0000O0O0OOO0OO0 ,enable )#line:277
        O0O0000O000000OO0 =xbmc .executeJSONRPC (OO0000000OO0OO00O )#line:278
        O00OOO0000OO00OOO =json .loads (O0O0000O000000OO0 )#line:279
        if enable =="true":#line:280
            xbmc .log ("### Enabled %s, response = %s"%(OOO0OOOOO0O0O0000 ,O00OOO0000OO00OOO ))#line:281
        else :#line:282
            xbmc .log ("### Disabled %s, response = %s"%(OOO0OOOOO0O0O0000 ,O00OOO0000OO00OOO ))#line:283
    if OOO0000O0OOO0O00O =='auto':#line:284
     return True #line:285
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:286
def update_Votes ():#line:287
   try :#line:288
        import requests #line:289
        OO0O0O0OOO0OOOOO0 ='18773068'#line:290
        O0000O000000O0OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O0O0OOO0OOOOO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:302
        O0O0OO0000OOOO000 ='145273321'#line:304
        OO00OO00O000O0OO0 ={'options':O0O0OO0000OOOO000 }#line:310
        O00OO000OO0000O00 =requests .post ('https://www.strawpoll.me/'+OO0O0O0OOO0OOOOO0 ,headers =O0000O000000O0OO0 ,data =OO00OO00O000O0OO0 )#line:312
   except :pass #line:313
def display_Votes ():#line:314
    try :#line:315
        OO0O0O0O0OOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:316
        OOOO0O0O0O00O0OOO =open (OO0O0O0O0OOOO0OO0 ,'r')#line:318
        O00O00OOOO0OO0OOO =OOOO0O0O0O00O0OOO .read ()#line:319
        OOOO0O0O0O00O0OOO .close ()#line:320
        O0O0000O00OOO0OO0 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:321
        OOO0000000O0O0000 =re .compile (O0O0000O00OOO0OO0 ).findall (O00O00OOOO0OO0OOO )[0 ]#line:323
        import requests #line:329
        OOOOO0O00OOOOO0O0 ='18773133'#line:330
        OOO00000000OO000O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOOO0O00OOOOO0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:342
        O000O0O0O0000OOOO ='145273605'#line:344
        O0000O000O00OO00O ='145273606'#line:345
        OOOOOOO0OO0000O0O ='145273607'#line:346
        OO00O0OO00000OOOO ='145273608'#line:347
        O00OO0O0OOOO0OO00 ='145273609'#line:348
        O0O0O0000OO0O0000 ='145273610'#line:349
        O0O00OO0O0000OOO0 ='145273611'#line:350
        O00OO0O00000OOOO0 ='145273612'#line:351
        if OOO0000000O0O0000 =='emin':#line:354
           OO00OO00000OO00O0 =O000O0O0O0000OOOO #line:355
        if OOO0000000O0O0000 =='nox':#line:356
           OO00OO00000OO00O0 =O0000O000O00OO00O #line:357
        if OOO0000000O0O0000 =='noxtitan':#line:358
           OO00OO00000OO00O0 =O0000O000O00OO00O #line:359
        if OOO0000000O0O0000 =='titan':#line:360
           OO00OO00000OO00O0 =OOOOOOO0OO0000O0O #line:361
        if OOO0000000O0O0000 =='pheno':#line:362
           OO00OO00000OO00O0 =OO00O0OO00000OOOO #line:363
        if OOO0000000O0O0000 =='netflix':#line:364
           OO00OO00000OO00O0 =O00OO0O0OOOO0OO00 #line:365
        if OOO0000000O0O0000 =='nebula':#line:366
           OO00OO00000OO00O0 =O0O0O0000OO0O0000 #line:367
        if OOO0000000O0O0000 =='pellucid':#line:368
           OO00OO00000OO00O0 =O0O00OO0O0000OOO0 #line:369
        if OOO0000000O0O0000 =='pellucid2':#line:370
           OO00OO00000OO00O0 =O00OO0O00000OOOO0 #line:371
        O0O000OOO0O000O0O ={'options':OO00OO00000OO00O0 }#line:377
        O00OO0OOO000OOO0O =requests .post ('https://www.strawpoll.me/'+OOOOO0O00OOOOO0O0 ,headers =OOO00000000OO000O ,data =O0O000OOO0O000O0O )#line:379
    except :pass #line:380
def indicatorfastupdate ():#line:381
       try :#line:382
          import json #line:383
          wiz .log ('FRESH MESSAGE')#line:384
          O0OO00O0O00O0O000 =(ADDON .getSetting ("user"))#line:385
          O000O0O00OOO0O00O =(ADDON .getSetting ("pass"))#line:386
          OOO00OOOO00OO000O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:387
          OO0OO00OO0OOO000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:389
          OO0O0OOOOOO00000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:390
          O00O0OOOO0O000OO0 =str (json .loads (OO0O0OOOOOO00000O )['ip'])#line:391
          O00000O000OO0OO0O =O0OO00O0O00O0O000 #line:392
          OOOO00O00O000O00O =O000O0O00OOO0O00O #line:393
          import socket #line:394
          OO0O0OOOOOO00000O =urllib2 .urlopen (OO0OO00OO0OOO000O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00000O000OO0OO0O +' - '+OOOO00O00O000O00O +' - '+OOO00OOOO00OO000O +' - '+O00O0OOOO0O000OO0 ).readlines ()#line:395
       except :pass #line:397
def skindialogsettind18 ():#line:398
	try :#line:399
		O0OOO000OO000OO0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:400
		O0O00O0OO00O000O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:401
		copyfile (O0OOO000OO000OO0O ,O0O00O0OO00O000O0 )#line:402
	except :pass #line:403
def checkidupdate ():#line:404
				wiz .setS ("notedismiss","true")#line:406
				OO000O0O0OO0OOO00 =wiz .workingURL (NOTIFICATION )#line:407
				O000O0OO00O0OO000 =" Kodi Premium"#line:409
				O0O000OOOOOO0O0O0 =wiz .checkBuild (O000O0OO00O0OO000 ,'gui')#line:410
				OOOOO0000O0OO00O0 =O000O0OO00O0OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:411
				if not wiz .workingURL (O0O000OOOOOO0O0O0 )==True :return #line:412
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:413
				OOOO000O0O000OOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO0000O0OO00O0 )#line:416
				try :os .remove (OOOO000O0O000OOOO )#line:417
				except :pass #line:418
				if 'google'in O0O000OOOOOO0O0O0 :#line:420
				   O00000OO0000O0OO0 =googledrive_download (O0O000OOOOOO0O0O0 ,OOOO000O0O000OOOO ,DP2 ,wiz .checkBuild (O000O0OO00O0OO000 ,'filesize'))#line:421
				else :#line:424
				  downloaderbg .download3 (O0O000OOOOOO0O0O0 ,OOOO000O0O000OOOO ,DP2 )#line:425
				xbmc .sleep (100 )#line:426
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:427
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:429
				extract .all2 (OOOO000O0O000OOOO ,HOME ,DP2 )#line:431
				DP2 .close ()#line:432
				wiz .defaultSkin ()#line:433
				wiz .lookandFeelData ('save')#line:434
				wiz .kodi17Fix ()#line:435
				if KODIV >=18 :#line:436
					skindialogsettind18 ()#line:437
				xbmc .executebuiltin ("ReloadSkin()")#line:438
				update_Votes ()#line:439
				indicatorfastupdate ()#line:440
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:441
				debridit .debridIt ('restore','all')#line:442
				traktit .traktIt ('restore','all')#line:443
				if INSTALLMETHOD ==1 :O0O0O00OOO0OO0OOO =1 #line:444
				elif INSTALLMETHOD ==2 :O0O0O00OOO0OO0OOO =0 #line:445
				else :DP2 .close ()#line:446
def checkUpdate ():#line:452
	O000O000000OO0000 =wiz .getS ('buildname')#line:453
	O00O000OO0O00O00O =wiz .getS ('buildversion')#line:454
	O00OO0OO0O0OO0OOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:455
	OO00O0000O00OO000 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O000O000000OO0000 ).findall (O00OO0OO0O0OO0OOO )#line:456
	if len (OO00O0000O00OO000 )>0 :#line:457
		O0000OO0O0O0000OO =OO00O0000O00OO000 [0 ][0 ]#line:458
		OO0O000000OOOO0OO =OO00O0000O00OO000 [0 ][1 ]#line:459
		O00000OO000OO0O0O =OO00O0000O00OO000 [0 ][2 ]#line:460
		wiz .setS ('latestversion',O0000OO0O0O0000OO )#line:461
		if O0000OO0O0O0000OO >O00O000OO0O00O00O :#line:462
			if DISABLEUPDATE =='false':#line:463
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00O000OO0O00O00O ,O0000OO0O0O0000OO ),xbmc .LOGNOTICE )#line:464
				notify .updateWindow (O000O000000OO0000 ,O00O000OO0O00O00O ,O0000OO0O0O0000OO ,OO0O000000OOOO0OO ,O00000OO000OO0O0O )#line:465
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00O000OO0O00O00O ,O0000OO0O0O0000OO ),xbmc .LOGNOTICE )#line:466
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00O000OO0O00O00O ,O0000OO0O0O0000OO ),xbmc .LOGNOTICE )#line:467
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:468
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:503
if AUTOUPDATE =='Yes':#line:504
	input =(ADDON .getSetting ("autoupdate"))#line:505
	xbmc .executebuiltin ("UpdateLocalAddons")#line:506
	xbmc .executebuiltin ("UpdateAddonRepos")#line:507
	wiz .wizardUpdate ('startup')#line:508
	checkUpdate ()#line:510
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:512
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:516
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:517
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:519
	workingxml =wiz .workingURL (REPOADDONXML )#line:520
	if workingxml ==True :#line:521
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:522
		if len (ver )>0 :#line:523
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:524
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:525
			if workingrepo ==True :#line:526
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:527
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:528
				lib =os .path .join (PACKAGES ,installzip )#line:529
				try :os .remove (lib )#line:530
				except :pass #line:531
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:532
				extract .all (lib ,ADDONS ,DP )#line:533
				try :#line:534
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:535
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:536
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:537
				except :#line:538
					pass #line:539
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:540
				DP .close ()#line:541
				xbmc .sleep (500 )#line:542
				wiz .forceUpdate (True )#line:543
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:544
				xbmc .executebuiltin ("ReloadSkin()")#line:545
				xbmc .executebuiltin ("ActivateWindow(home)")#line:546
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:547
				xbmc .Player ().play (f_play ,windowed =False )#line:548
			else :#line:550
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:551
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:552
		else :#line:553
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:554
	else :#line:555
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:556
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:557
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:558
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:559
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:562
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:563
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:564
	if BUILDNAME =="":#line:565
		try :#line:566
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:567
		except :#line:568
				pass #line:569
	if workingxml ==True :#line:570
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:571
		if len (ver )>0 :#line:572
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:573
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:574
			if workingrepo ==True :#line:575
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:576
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:577
				lib =os .path .join (PACKAGES ,installzip )#line:578
				try :os .remove (lib )#line:579
				except :pass #line:580
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:581
				extract .all (lib ,ADDONS ,DP )#line:582
				try :#line:583
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:584
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:585
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:586
				except :#line:587
					pass #line:588
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:589
				DP .close ()#line:590
				xbmc .sleep (500 )#line:591
				wiz .forceUpdate (True )#line:592
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:593
				xbmc .executebuiltin ("ReloadSkin()")#line:594
				xbmc .executebuiltin ("ActivateWindow(home)")#line:595
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:596
				xbmc .Player ().play (f_play ,windowed =False )#line:597
			else :#line:599
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:600
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:601
		else :#line:602
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:603
	else :#line:604
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:605
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:606
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:609
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:610
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REQUESTSID )):#line:613
	workingxml =wiz .workingURL (REQUESTSXML )#line:614
	if workingxml ==True :#line:616
		ver =wiz .parseDOM (wiz .openURL (REQUESTSXML ),'addon',ret ='version',attrs ={'id':REQUESTSID })#line:617
		if len (ver )>0 :#line:618
			installzip ='%s-%s.zip'%(REQUESTSID ,ver [0 ])#line:619
			workingrepo =wiz .workingURL (REQUESTSURL +installzip )#line:620
			if workingrepo ==True :#line:621
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:623
				lib =os .path .join (PACKAGES ,installzip )#line:624
				try :os .remove (lib )#line:625
				except :pass #line:626
				downloaderbg .download4 (REQUESTSURL +installzip ,lib ,DP2 )#line:627
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:628
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:629
				extract .all2 (lib ,ADDONS ,DP2 )#line:630
				try :#line:631
					f =open (os .path .join (ADDONS ,REQUESTSID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:632
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REQUESTSID })#line:633
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REQUESTSID ,'icon.png'))#line:634
				except :#line:635
					pass #line:636
				if KODIV >=17 :wiz .addonDatabase (REQUESTSID ,1 )#line:637
				DP2 .close ()#line:638
				xbmc .sleep (500 )#line:639
				wiz .forceUpdate (True )#line:640
				wiz .kodi17Fix ()#line:641
def setuname ():#line:645
    OO0000O0OO0O0OO00 =''#line:646
    O0000O000OO0OOOO0 =xbmc .Keyboard (OO0000O0OO0O0OO00 ,'הכנס שם משתמש')#line:647
    O0000O000OO0OOOO0 .doModal ()#line:648
    if O0000O000OO0OOOO0 .isConfirmed ():#line:649
           OO0000O0OO0O0OO00 =O0000O000OO0OOOO0 .getText ()#line:650
           wiz .setS ('user',str (OO0000O0OO0O0OO00 ))#line:651
def STARTP2 ():#line:652
	if BUILDNAME ==" Kodi Premium":#line:653
		OO0000OOOO0O0OO00 =(ADDON .getSetting ("user"))#line:654
		O00OOO000OO0O00O0 =(UNAME )#line:655
		O0O0O0OOOOOO0O0OO =urllib2 .urlopen (O00OOO000OO0O00O0 )#line:656
		O0OOOO0OO0O00000O =O0O0O0OOOOOO0O0OO .readlines ()#line:657
		OO0OO0OOOO0OOOOOO =0 #line:658
		for OOOO00OOOOO0OO00O in O0OOOO0OO0O00000O :#line:659
			if OOOO00OOOOO0OO00O .split (' ==')[0 ]==OO0000OOOO0O0OO00 or OOOO00OOOOO0OO00O .split ()[0 ]==OO0000OOOO0O0OO00 :#line:660
				OO0OO0OOOO0OOOOOO =1 #line:661
				break #line:662
		if OO0OO0OOOO0OOOOOO ==0 :#line:663
			O000O0OO0O0O0O00O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:665
			if O000O0OO0O0O0O00O :#line:667
				ADDON .openSettings ()#line:668
				sys .exit ()#line:669
			else :#line:670
				sys .exit ()#line:671
		return 'ok'#line:675
def skinWIN ():#line:678
	idle ()#line:679
	OO0OO000OO0OOOOO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:680
	OOOOO00OOOOOO0OOO =[];O0000OOO0OOOO00O0 =[]#line:681
	for OO00O000O0O0OOO0O in sorted (OO0OO000OO0OOOOO0 ,key =lambda OO000OO0O00O0OO00 :OO000OO0O00O0OO00 ):#line:682
		OOOOOO0OOO0O0000O =os .path .split (OO00O000O0O0OOO0O [:-1 ])[1 ]#line:683
		O00000O00OO000O0O =os .path .join (OO00O000O0O0OOO0O ,'addon.xml')#line:684
		if os .path .exists (O00000O00OO000O0O ):#line:685
			OOOOO00000000O000 =open (O00000O00OO000O0O )#line:686
			O0000000OO0000O00 =OOOOO00000000O000 .read ()#line:687
			O000000O0OOOO0OOO =parseDOM2 (O0000000OO0000O00 ,'addon',ret ='id')#line:688
			OOOOO0OO0OO00O0O0 =OOOOOO0OOO0O0000O if len (O000000O0OOOO0OOO )==0 else O000000O0OOOO0OOO [0 ]#line:689
			try :#line:690
				OOOO0O00OOOO00OO0 =xbmcaddon .Addon (id =OOOOO0OO0OO00O0O0 )#line:691
				OOOOO00OOOOOO0OOO .append (OOOO0O00OOOO00OO0 .getAddonInfo ('name'))#line:692
				O0000OOO0OOOO00O0 .append (OOOOO0OO0OO00O0O0 )#line:693
			except :#line:694
				pass #line:695
	OOO00O00OO0O00OO0 =[];OOO000000O0OOO0O0 =0 #line:696
	O0OOO0O00OOOOO000 =["Current Skin -- %s"%currSkin ()]+OOOOO00OOOOOO0OOO #line:697
	OOO000000O0OOO0O0 =DIALOG .select ("Select the Skin you want to swap with.",O0OOO0O00OOOOO000 )#line:698
	if OOO000000O0OOO0O0 ==-1 :return #line:699
	else :#line:700
		O0OO0O000OOO00O0O =(OOO000000O0OOO0O0 -1 )#line:701
		OOO00O00OO0O00OO0 .append (O0OO0O000OOO00O0O )#line:702
		O0OOO0O00OOOOO000 [OOO000000O0OOO0O0 ]="%s"%(OOOOO00OOOOOO0OOO [O0OO0O000OOO00O0O ])#line:703
	if OOO00O00OO0O00OO0 ==None :return #line:704
	for OO0OOOOO0OOO0O0OO in OOO00O00OO0O00OO0 :#line:705
		swapSkins (O0000OOO0OOOO00O0 [OO0OOOOO0OOO0O0OO ])#line:706
def currSkin ():#line:708
	return xbmc .getSkinDir ('Container.PluginName')#line:709
def fix17update ():#line:711
	if KODIV >=17 and KODIV <18 :#line:712
		wiz .kodi17Fix ()#line:713
		xbmc .sleep (4000 )#line:714
		try :#line:715
			OOOOO000OOO0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:716
			O00OOOO0O0OO0O00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:717
			os .rename (OOOOO000OOO0O0OO0 ,O00OOOO0O0OO0O00O )#line:718
		except :#line:719
				pass #line:720
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:721
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:722
		fixfont ()#line:723
		O0000O0OOO0O0O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:724
		try :#line:726
			OOOOOOOOO0OOOOOO0 =open (O0000O0OOO0O0O0OO ,'r')#line:727
			OO0O00OOO00O0O00O =OOOOOOOOO0OOOOOO0 .read ()#line:728
			OOOOOOOOO0OOOOOO0 .close ()#line:729
			O0OOOOO0000O00O0O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:730
			O0O0O0O0O0OO00O0O =re .compile (O0OOOOO0000O00O0O ).findall (OO0O00OOO00O0O00O )[0 ]#line:731
			OOOOOOOOO0OOOOOO0 =open (O0000O0OOO0O0O0OO ,'w')#line:732
			OOOOOOOOO0OOOOOO0 .write (OO0O00OOO00O0O00O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O0O0O0O0OO00O0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:733
			OOOOOOOOO0OOOOOO0 .close ()#line:734
		except :#line:735
				pass #line:736
		wiz .kodi17Fix ()#line:737
		O0000O0OOO0O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:738
		try :#line:739
			OOOOOOOOO0OOOOOO0 =open (O0000O0OOO0O0O0OO ,'r')#line:740
			OO0O00OOO00O0O00O =OOOOOOOOO0OOOOOO0 .read ()#line:741
			OOOOOOOOO0OOOOOO0 .close ()#line:742
			O0OOOOO0000O00O0O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:743
			O0O0O0O0O0OO00O0O =re .compile (O0OOOOO0000O00O0O ).findall (OO0O00OOO00O0O00O )[0 ]#line:744
			OOOOOOOOO0OOOOOO0 =open (O0000O0OOO0O0O0OO ,'w')#line:745
			OOOOOOOOO0OOOOOO0 .write (OO0O00OOO00O0O00O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O0O0O0O0OO00O0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:746
			OOOOOOOOO0OOOOOO0 .close ()#line:747
		except :#line:748
				pass #line:749
		swapSkins ('skin.Premium.mod')#line:750
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:751
	os ._exit (1 )#line:752
def fix18update ():#line:753
	if KODIV >=18 :#line:754
		xbmc .sleep (4000 )#line:755
		if BUILDNAME =="":#line:756
			try :#line:757
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:758
			except :#line:759
				pass #line:760
		try :#line:761
			O00OO000OO0OO0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:762
			OO0OOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:763
			os .rename (O00OO000OO0OO0OOO ,OO0OOOOOOOOOOO0OO )#line:764
		except :#line:765
				pass #line:766
		skindialogsettind18 ()#line:767
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:768
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:769
		fixfont ()#line:770
		OOOO0O00OO00O0O0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:771
		try :#line:772
			O00OOO0000OO0OO0O =open (OOOO0O00OO00O0O0O ,'r')#line:773
			OO0000000OOO0O000 =O00OOO0000OO0OO0O .read ()#line:774
			O00OOO0000OO0OO0O .close ()#line:775
			OO00OOOOOOOO00000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:776
			OO0OOOOO00O000OOO =re .compile (OO00OOOOOOOO00000 ).findall (OO0000000OOO0O000 )[0 ]#line:777
			O00OOO0000OO0OO0O =open (OOOO0O00OO00O0O0O ,'w')#line:778
			O00OOO0000OO0OO0O .write (OO0000000OOO0O000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0OOOOO00O000OOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:779
			O00OOO0000OO0OO0O .close ()#line:780
		except :#line:781
				pass #line:782
		wiz .kodi17Fix ()#line:783
		OOOO0O00OO00O0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:784
		try :#line:785
			O00OOO0000OO0OO0O =open (OOOO0O00OO00O0O0O ,'r')#line:786
			OO0000000OOO0O000 =O00OOO0000OO0OO0O .read ()#line:787
			O00OOO0000OO0OO0O .close ()#line:788
			OO00OOOOOOOO00000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:789
			OO0OOOOO00O000OOO =re .compile (OO00OOOOOOOO00000 ).findall (OO0000000OOO0O000 )[0 ]#line:790
			O00OOO0000OO0OO0O =open (OOOO0O00OO00O0O0O ,'w')#line:791
			O00OOO0000OO0OO0O .write (OO0000000OOO0O000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0OOOOO00O000OOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:792
			O00OOO0000OO0OO0O .close ()#line:793
		except :#line:794
				pass #line:795
		swapSkins ('skin.Premium.mod')#line:796
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:797
	os ._exit (1 )#line:798
def swapSkins (O0O00O0OOO0OOOOO0 ,title ="Error"):#line:799
	OO00OOOOO0O0OO0OO ='lookandfeel.skin'#line:800
	OO0OOOOOO00O0O0OO =O0O00O0OOO0OOOOO0 #line:801
	OO0O0000OOO000OO0 =getOld (OO00OOOOO0O0OO0OO )#line:802
	O0O0000OOOOO0OO0O =OO00OOOOO0O0OO0OO #line:803
	setNew (O0O0000OOOOO0OO0O ,OO0OOOOOO00O0O0OO )#line:804
	O0OO0000OOO0O0000 =0 #line:805
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO0000OOO0O0000 <100 :#line:806
		O0OO0000OOO0O0000 +=1 #line:807
		xbmc .sleep (1 )#line:808
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:809
		xbmc .executebuiltin ('SendClick(11)')#line:810
	return True #line:811
def getOld (O0000OOO0OOO0OO0O ):#line:813
	try :#line:814
		O0000OOO0OOO0OO0O ='"%s"'%O0000OOO0OOO0OO0O #line:815
		O0O0O0OO0000000OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0000OOO0OOO0OO0O )#line:816
		O00OO0OOOOO0OO0O0 =xbmc .executeJSONRPC (O0O0O0OO0000000OO )#line:818
		O00OO0OOOOO0OO0O0 =simplejson .loads (O00OO0OOOOO0OO0O0 )#line:819
		if O00OO0OOOOO0OO0O0 .has_key ('result'):#line:820
			if O00OO0OOOOO0OO0O0 ['result'].has_key ('value'):#line:821
				return O00OO0OOOOO0OO0O0 ['result']['value']#line:822
	except :#line:823
		pass #line:824
	return None #line:825
def setNew (OOOO0OOOO0O0O00OO ,O00OOOO0O0OOOO00O ):#line:828
	try :#line:829
		OOOO0OOOO0O0O00OO ='"%s"'%OOOO0OOOO0O0O00OO #line:830
		O00OOOO0O0OOOO00O ='"%s"'%O00OOOO0O0OOOO00O #line:831
		OO0OOOOO0O0OOOO0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOO0OOOO0O0O00OO ,O00OOOO0O0OOOO00O )#line:832
		O000O0OO0OO000OOO =xbmc .executeJSONRPC (OO0OOOOO0O0OOOO0O )#line:834
	except :#line:835
		pass #line:836
	return None #line:837
def idle ():#line:838
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:839
def fixfont ():#line:840
	O0000OO00O00O0O0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:841
	OO0OO0OOOO0O00O00 =json .loads (O0000OO00O00O0O0O );#line:843
	OOOOOOO0OO0OO00OO =OO0OO0OOOO0O00O00 ["result"]["settings"]#line:844
	OOO0O0O00O0OO0OO0 =[OO0O0OO00OO0000O0 for OO0O0OO00OO0000O0 in OOOOOOO0OO0OO00OO if OO0O0OO00OO0000O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:846
	O0O0OO0OOOO000O0O =OOO0O0O00O0OO0OO0 ["options"];#line:847
	O00OOO0O0OO00OO0O =OOO0O0O00O0OO0OO0 ["value"];#line:848
	O00000O0OOOO00O0O =[O0O0O0000O000000O for (O0O0O0000O000000O ,OOO0OO0000OOO00O0 )in enumerate (O0O0OO0OOOO000O0O )if OOO0OO0000OOO00O0 ["value"]==O00OOO0O0OO00OO0O ][0 ];#line:850
	OO0000OOOOOOO0OOO =(O00000O0OOOO00O0O +1 )%len (O0O0OO0OOOO000O0O )#line:852
	O0O0OOO0O0OOO0OOO =O0O0OO0OOOO000O0O [OO0000OOOOOOO0OOO ]["value"]#line:854
	O000OO0OOOOO00OOO =O0O0OO0OOOO000O0O [OO0000OOOOOOO0OOO ]["label"]#line:855
	OO0OOO00O00O0OO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:857
	try :#line:859
		OO000O00O00000O00 =json .loads (OO0OOO00O00O0OO0O );#line:860
		if OO000O00O00000O00 ["result"]!=True :#line:862
			raise Exception #line:863
	except :#line:864
		sys .stderr .write ("Error switching audio output device")#line:865
		raise Exception #line:866
def checkSkin ():#line:869
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:870
	O0OO00000O0000000 =wiz .getS ('defaultskin')#line:871
	O00O0OOOOOO000O00 =wiz .getS ('defaultskinname')#line:872
	O0000O00OO0OOO000 =wiz .getS ('defaultskinignore')#line:873
	OO000OOO00O00O000 =False #line:874
	if not O0OO00000O0000000 =='':#line:875
		if os .path .exists (os .path .join (ADDONS ,O0OO00000O0000000 )):#line:876
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0OOOOOO000O00 )):#line:877
				OO000OOO00O00O000 =O0OO00000O0000000 #line:878
				OO0O0OOOO0O0OO000 =O00O0OOOOOO000O00 #line:879
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');OO000OOO00O00O000 =False #line:880
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O0OO00000O0000000 ='';O00O0OOOOOO000O00 =''#line:881
	if O0OO00000O0000000 =='':#line:882
		O0OO0O0OO000OO000 =[]#line:883
		OO0000O0O00O0O00O =[]#line:884
		for O0OO0O00O0O000O0O in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:885
			OO00O0000000OO0OO ="%s/addon.xml"%O0OO0O00O0O000O0O #line:886
			if os .path .exists (OO00O0000000OO0OO ):#line:887
				OO0O0O0O0000O0O0O =open (OO00O0000000OO0OO ,mode ='r');OO00OOOO000OO00OO =OO0O0O0O0000O0O0O .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO0O0O0O0000O0O0O .close ();#line:888
				O000O00OOOOO00O0O =wiz .parseDOM (OO00OOOO000OO00OO ,'addon',ret ='id')#line:889
				O000O0OO0OO00O00O =wiz .parseDOM (OO00OOOO000OO00OO ,'addon',ret ='name')#line:890
				wiz .log ("%s: %s"%(O0OO0O00O0O000O0O ,str (O000O00OOOOO00O0O [0 ])),xbmc .LOGNOTICE )#line:891
				if len (O000O00OOOOO00O0O )>0 :OO0000O0O00O0O00O .append (str (O000O00OOOOO00O0O [0 ]));O0OO0O0OO000OO000 .append (str (O000O0OO0OO00O00O [0 ]))#line:892
				else :wiz .log ("ID not found for %s"%O0OO0O00O0O000O0O ,xbmc .LOGNOTICE )#line:893
			else :wiz .log ("ID not found for %s"%O0OO0O00O0O000O0O ,xbmc .LOGNOTICE )#line:894
		if len (OO0000O0O00O0O00O )>0 :#line:895
			if len (OO0000O0O00O0O00O )>1 :#line:896
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:897
					OOOOO000O000O0OOO =DIALOG .select ("Select skin to switch to!",O0OO0O0OO000OO000 )#line:898
					if OOOOO000O000O0OOO ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:899
					else :#line:900
						OO000OOO00O00O000 =OO0000O0O00O0O00O [OOOOO000O000O0OOO ]#line:901
						OO0O0OOOO0O0OO000 =O0OO0O0OO000OO000 [OOOOO000O000O0OOO ]#line:902
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:903
	if OO000OOO00O00O000 :#line:910
		skinSwitch .swapSkins (OO000OOO00O00O000 )#line:911
		O0O0OO0OO0OO0000O =0 #line:912
		xbmc .sleep (1000 )#line:913
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OO0OO0OO0000O <150 :#line:914
			O0O0OO0OO0OO0000O +=1 #line:915
			xbmc .sleep (200 )#line:916
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:918
			wiz .ebi ('SendClick(11)')#line:919
			wiz .lookandFeelData ('restore')#line:920
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:921
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:922
while xbmc .Player ().isPlayingVideo ():#line:924
	xbmc .sleep (1000 )#line:925
if KODIV >=17 :#line:927
	NOW =datetime .now ()#line:928
	temp =wiz .getS ('kodi17iscrap')#line:929
	if not temp =='':#line:930
		if temp >str (NOW -timedelta (minutes =2 )):#line:931
			wiz .log ("Killing Start Up Script")#line:932
			sys .exit ()#line:933
	wiz .log ("%s"%(NOW ))#line:934
	wiz .setS ('kodi17iscrap',str (NOW ))#line:935
	xbmc .sleep (1000 )#line:936
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:937
		wiz .log ("Killing Start Up Script")#line:938
		sys .exit ()#line:939
	else :#line:940
		wiz .log ("Continuing Start Up Script")#line:941
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:943
path =os .path .split (ADDONPATH )#line:944
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:945
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:946
if KODIADDONS in ADDONPATH :#line:949
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:950
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:951
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:952
	if os .path .exists (newpath ):#line:953
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:954
		wiz .cleanHouse (newpath )#line:955
		wiz .removeFolder (newpath )#line:956
	try :#line:957
		wiz .copytree (ADDONPATH ,newpath )#line:958
	except Exception as e :#line:959
		pass #line:960
	wiz .forceUpdate (True )#line:961
try :#line:963
	mybuilds =xbmc .translatePath (MYBUILDS )#line:964
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:965
except :#line:966
	pass #line:967
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:969
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:973
			wiz .kodi17Fix ()#line:974
			fix18update ()#line:975
			fix17update ()#line:976
if INSTALLED =='true':#line:979
    input =(ADDON .getSetting ("auto_rd"))#line:980
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:982
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:983
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:984
    wiz .clearS ('install')#line:985
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1070
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1072
	input =(ADDON .getSetting ("autoupdate"))#line:1073
	STARTP2 ()#line:1074
	if not NOTIFY =='true':#line:1075
		url =wiz .workingURL (NOTIFICATION )#line:1076
		if url ==True :#line:1077
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1078
			if not id ==False :#line:1079
				try :#line:1080
					id =int (id );NOTEID =int (NOTEID )#line:1081
					if id ==NOTEID :#line:1082
						if NOTEDISMISS =='false':#line:1083
							debridit .debridIt ('update','all')#line:1084
							traktit .traktIt ('update','all')#line:1085
							checkidupdate ()#line:1086
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1087
					elif id >NOTEID :#line:1088
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1089
						wiz .setS ('noteid',str (id ))#line:1090
						wiz .setS ('notedismiss','false')#line:1091
						if input =='true':#line:1092
							debridit .debridIt ('update','all')#line:1093
							traktit .traktIt ('update','all')#line:1094
							checkidupdate ()#line:1095
						else :notify .notification (msg =msg )#line:1096
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1097
				except Exception as e :#line:1098
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1099
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1100
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1101
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1102
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1103
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1105
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:1106
	if not NOTIFY2 =='true':#line:1107
		url =wiz .workingURL (NOTIFICATION2 )#line:1108
		if url ==True :#line:1109
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1110
			if not id ==False :#line:1111
				try :#line:1112
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1113
					if id ==NOTEID2 :#line:1114
						if NOTEDISMISS2 =='false':#line:1115
							notify .notification2 (msg )#line:1116
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1117
					elif id >NOTEID2 :#line:1118
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1119
						wiz .setS ('noteid2',str (id ))#line:1120
						wiz .setS ('notedismiss2','false')#line:1121
						notify .notification2 (msg =msg )#line:1122
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1123
				except Exception as e :#line:1124
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1125
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1126
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1127
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1128
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1129
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1131
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1132
	if not NOTIFY3 =='true':#line:1133
		url =wiz .workingURL (NOTIFICATION3 )#line:1134
		if url ==True :#line:1135
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1136
			if not id ==False :#line:1137
				try :#line:1138
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1139
					if id ==NOTEID3 :#line:1140
						if NOTEDISMISS3 =='false':#line:1141
							notify .notification3 (msg )#line:1142
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1143
					elif id >NOTEID3 :#line:1144
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1145
						wiz .setS ('noteid3',str (id ))#line:1146
						wiz .setS ('notedismiss3','false')#line:1147
						notify .notification3 (msg =msg )#line:1148
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1149
				except Exception as e :#line:1150
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1151
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1152
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1153
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1154
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1155
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1156
if KEEPTRAKT =='true':#line:1157
	if TRAKTSAVE <=str (TODAY ):#line:1158
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1159
		traktit .autoUpdate ('all')#line:1160
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1161
	else :#line:1162
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1163
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1164
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1166
if KEEPREAL =='true':#line:1167
	if REALSAVE <=str (TODAY ):#line:1168
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1169
		debridit .autoUpdate ('all')#line:1170
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1171
	else :#line:1172
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1173
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1174
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1176
if KEEPLOGIN =='true':#line:1177
	if LOGINSAVE <=str (TODAY ):#line:1178
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1179
		loginit .autoUpdate ('all')#line:1180
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1181
	else :#line:1182
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1183
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1184
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1186
if AUTOCLEANUP =='true':#line:1187
	service =False #line:1188
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1189
	feq =int (float (AUTOFEQ ))#line:1190
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1191
		service =True #line:1192
		next_run =days [feq ]#line:1193
		wiz .setS ('nextautocleanup',str (next_run ))#line:1194
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1195
	if service ==True :#line:1196
		AUTOCACHE =wiz .getS ('clearcache')#line:1197
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1198
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1199
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1200
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1201
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1202
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1203
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1204
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1205
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1206
wiz .setS ('kodi17iscrap','')#line:1208
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1277
	count =0 #line:1278
	for f in filenames :#line:1279
		count +=1 #line:1280
		fp =os .path .join (dirpath ,f )#line:1281
		total_size +=os .path .getsize (fp )#line:1282
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1283
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1290
	for f2 in filenames2 :#line:1291
		fp2 =os .path .join (dirpath2 ,f2 )#line:1292
		total_size2 +=os .path .getsize (fp2 )#line:1293
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1294
if int (total_sizetext2 )>filesize_thumb :#line:1296
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1297
	if choice2 ==1 :#line:1298
		maintenance .deleteThumbnails ()#line:1299
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1301
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1302
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1304
time .sleep (3 )#line:1305
if not os .path .exists (os .path .join (ADDONDATA ,'4.1.0')):#line:1307
        display_Votes ()#line:1308
        file =open (os .path .join (ADDONDATA ,'4.1.0'),'w')#line:1310
        file .write (str ('Done'))#line:1312
        file .close ()#line:1313
