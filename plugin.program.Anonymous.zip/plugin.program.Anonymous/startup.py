# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
global teleupdate #line:32
teleupdate =False #line:33
ADDON_ID =uservar .ADDON_ID #line:34
ADDONTITLE =uservar .ADDONTITLE #line:35
ADDON =wiz .addonId (ADDON_ID )#line:36
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:37
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:38
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:39
DIALOG =xbmcgui .Dialog ()#line:40
DP =xbmcgui .DialogProgress ()#line:41
DP2 =xbmcgui .DialogProgressBG ()#line:42
HOME =xbmc .translatePath ('special://home/')#line:43
PROFILE =xbmc .translatePath ('special://profile/')#line:44
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:45
ADDONS =os .path .join (HOME ,'addons')#line:46
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:51
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:52
ICON =os .path .join (ADDONPATH ,'icon.png')#line:53
ART =os .path .join (ADDONPATH ,'resources','art')#line:54
SKIN =xbmc .getSkinDir ()#line:55
BUILDNAME =wiz .getS ('buildname')#line:56
DEFAULTSKIN =wiz .getS ('defaultskin')#line:57
DEFAULTNAME =wiz .getS ('defaultskinname')#line:58
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:59
BUILDVERSION =wiz .getS ('buildversion')#line:60
BUILDLATEST =wiz .getS ('latestversion')#line:61
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:62
DISABLEUPDATE =wiz .getS ('disableupdate')#line:63
AUTOCLEANUP =wiz .getS ('autoclean')#line:64
AUTOCACHE =wiz .getS ('clearcache')#line:65
AUTOPACKAGES =wiz .getS ('clearpackages')#line:66
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:67
AUTOFEQ =wiz .getS ('autocleanfeq')#line:68
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:69
TRAKTSAVE =wiz .getS ('traktlastsave')#line:70
REALSAVE =wiz .getS ('debridlastsave')#line:71
LOGINSAVE =wiz .getS ('loginlastsave')#line:72
INSTALLMETHOD =wiz .getS ('installmethod')#line:73
KEEPTRAKT =wiz .getS ('keeptrakt')#line:74
KEEPREAL =wiz .getS ('keepdebrid')#line:75
KEEPLOGIN =wiz .getS ('keeplogin')#line:76
INSTALLED =wiz .getS ('installed')#line:77
EXTRACT =wiz .getS ('extract')#line:78
EXTERROR =wiz .getS ('errors')#line:79
NOTIFY =wiz .getS ('notify')#line:80
NOTEDISMISS =wiz .getS ('notedismiss')#line:81
NOTEID =wiz .getS ('noteid')#line:82
NOTIFY2 =wiz .getS ('notify2')#line:83
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:84
NOTEID2 =wiz .getS ('noteid2')#line:85
NOTIFY3 =wiz .getS ('notify3')#line:86
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:87
NOTEID3 =wiz .getS ('noteid3')#line:88
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:89
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:90
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:91
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:92
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:93
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:94
TODAY =date .today ()#line:95
TOMORROW =TODAY +timedelta (days =1 )#line:96
TWODAYS =TODAY +timedelta (days =2 )#line:97
THREEDAYS =TODAY +timedelta (days =3 )#line:98
ONEWEEK =TODAY +timedelta (days =7 )#line:99
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:100
EXCLUDES =uservar .EXCLUDES #line:101
SPEEDFILE =speedtest .SPEEDFILE #line:102
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:103
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:104
NOTIFICATION =uservar .NOTIFICATION #line:105
NOTIFICATION2 =uservar .NOTIFICATION2 #line:106
NOTIFICATION3 =uservar .NOTIFICATION3 #line:107
ENABLE =uservar .ENABLE #line:108
UNAME =speedtest .UNAME #line:109
HEADERMESSAGE =uservar .HEADERMESSAGE #line:110
AUTOUPDATE =uservar .AUTOUPDATE #line:111
WIZARDFILE =uservar .WIZARDFILE #line:112
AUTOINSTALL =uservar .AUTOINSTALL #line:113
REPOID =uservar .REPOID #line:114
REPOADDONXML =uservar .REPOADDONXML #line:115
REPOZIPURL =uservar .REPOZIPURL #line:116
REPOID18 =uservar .REPOID18 #line:117
REPOADDONXML18 =uservar .REPOADDONXML18 #line:118
REPOZIPURL18 =uservar .REPOZIPURL18 #line:119
REQUESTSID =uservar .REQUESTSID #line:121
REQUESTSXML =uservar .REQUESTSXML #line:122
REQUESTSURL =uservar .REQUESTSURL #line:123
COLOR1 =uservar .COLOR1 #line:127
COLOR2 =uservar .COLOR2 #line:128
TMDB_NEW_API =uservar .TMDB_NEW_API #line:129
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:130
FAILED =False #line:131
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:132
AddonID ='plugin.program.Anonymous'#line:134
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:135
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:136
dialog =xbmcgui .Dialog ()#line:137
setting =xbmcaddon .Addon ().getSetting #line:138
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:139
notify_mode =setting ('notify_mode')#line:140
auto_clean =setting ('startup.cache')#line:141
filesize_thumb =int (setting ('filesizethumb_alert'))#line:143
total_size2 =0 #line:146
total_size =0 #line:147
count =0 #line:148
def infobuild ():#line:149
	O0O00000O0O000O0O =wiz .workingURL (NOTIFICATION )#line:150
	if O0O00000O0O000O0O ==True :#line:151
		try :#line:152
			OOOOO0OO00OO0O0OO ,OO00O0O0O0O0OO0OO =wiz .splitNotify (NOTIFICATION )#line:153
			if OOOOO0OO00OO0O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:154
			if STARTP2 ()=='ok':#line:155
				notify .updateinfo (OO00O0O0O0O0OO0OO ,True )#line:156
		except Exception as OO0OOOO000000OO00 :#line:157
			wiz .log ("Error on Notifications Window: %s"%str (OO0OOOO000000OO00 ),xbmc .LOGERROR )#line:158
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:159
def disply_hwr ():#line:160
   try :#line:161
    OO000OOOO0OO0OOO0 =tmdb_list (TMDB_NEW_API )#line:162
    O0O00000OOO00O00O =str ((getHwAddr ('eth0'))*OO000OOOO0OO0OOO0 )#line:163
    O0OO0OOOOO00OOOO0 =(O0O00000OOO00O00O [1 ]+O0O00000OOO00O00O [2 ]+O0O00000OOO00O00O [5 ]+O0O00000OOO00O00O [7 ])#line:170
    O0OOOOO0OOO00OOO0 =(ADDON .getSetting ("action"))#line:171
    wiz .setS ('action',str (O0OO0OOOOO00OOOO0 ))#line:173
   except :pass #line:174
def getHwAddr (O0OOO0O0O0O000OO0 ):#line:175
   import subprocess ,time #line:176
   OO00OO00OO0000OOO ='windows'#line:177
   if xbmc .getCondVisibility ('system.platform.android'):#line:178
       OO00OO00OO0000OOO ='android'#line:179
   if xbmc .getCondVisibility ('system.platform.android'):#line:180
     OO00OOOO000OOOOOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:181
     OO00O000O0O0000OO =re .compile ('link/ether (.+?) brd').findall (str (OO00OOOO000OOOOOO ))#line:183
     OO00OOOO000O0OOO0 =0 #line:184
     for OOO000OOOO0O0O000 in OO00O000O0O0000OO :#line:185
      if OO00O000O0O0000OO !='00:00:00:00:00:00':#line:186
          O0O0000OO0O00OOO0 =OOO000OOOO0O0O000 #line:187
          OO00OOOO000O0OOO0 =OO00OOOO000O0OOO0 +int (O0O0000OO0O00OOO0 .replace (':',''),16 )#line:188
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:190
       OO000OOO0OO0OO0OO =0 #line:191
       OO00OOOO000O0OOO0 =0 #line:192
       OOOOO0OOOOO000000 =[]#line:193
       OO00OO00O00OOO0O0 =os .popen ("getmac").read ()#line:194
       OO00OO00O00OOO0O0 =OO00OO00O00OOO0O0 .split ("\n")#line:195
       for OOO0OO00O0OOOO00O in OO00OO00O00OOO0O0 :#line:197
            O0O0000OO0OOO00O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0OO00O0OOOO00O ,re .I )#line:198
            if O0O0000OO0OOO00O0 :#line:199
                OO00O000O0O0000OO =O0O0000OO0OOO00O0 .group ().replace ('-',':')#line:200
                OOOOO0OOOOO000000 .append (OO00O000O0O0000OO )#line:201
                OO00OOOO000O0OOO0 =OO00OOOO000O0OOO0 +int (OO00O000O0O0000OO .replace (':',''),16 )#line:204
   else :#line:206
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:207
   try :#line:224
    return OO00OOOO000O0OOO0 #line:225
   except :pass #line:226
def decode (OOOO0OO000OOOO00O ,OO0OO0OO0OOO0O0O0 ):#line:227
    import base64 #line:228
    OO00O00O00OOOO0OO =[]#line:229
    if (len (OOOO0OO000OOOO00O ))!=4 :#line:231
     return 10 #line:232
    OO0OO0OO0OOO0O0O0 =base64 .urlsafe_b64decode (OO0OO0OO0OOO0O0O0 )#line:233
    for O0O000000O0000000 in range (len (OO0OO0OO0OOO0O0O0 )):#line:235
        O0O0OO0O00000000O =OOOO0OO000OOOO00O [O0O000000O0000000 %len (OOOO0OO000OOOO00O )]#line:236
        O000OOO0000000000 =chr ((256 +ord (OO0OO0OO0OOO0O0O0 [O0O000000O0000000 ])-ord (O0O0OO0O00000000O ))%256 )#line:237
        OO00O00O00OOOO0OO .append (O000OOO0000000000 )#line:238
    return "".join (OO00O00O00OOOO0OO )#line:239
def tmdb_list (O0000OO00O0O00O0O ):#line:240
    O00OOO000OO00O000 =decode ("7643",O0000OO00O0O00O0O )#line:243
    return int (O00OOO000OO00O000 )#line:246
def u_list (OO00O0OOOOOO0O00O ):#line:247
    from math import sqrt #line:249
    O0O0O0O00O00000OO =tmdb_list (TMDB_NEW_API )#line:250
    O0000OO00O0O0OO00 =str ((getHwAddr ('eth0'))*O0O0O0O00O00000OO )#line:252
    O0OOOO00O0OO000OO =int (O0000OO00O0O0OO00 [1 ]+O0000OO00O0O0OO00 [2 ]+O0000OO00O0O0OO00 [5 ]+O0000OO00O0O0OO00 [7 ])#line:253
    OOO00O0O00O0000OO =(ADDON .getSetting ("pass"))#line:255
    O0O0OOOO0O00OOO00 =(str (round (sqrt ((O0OOOO00O0OO000OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:260
    if '.'in O0O0OOOO0O00OOO00 :#line:261
     O0O0OOOO0O00OOO00 =(str (round (sqrt ((O0OOOO00O0OO000OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:262
    if OOO00O0O00O0000OO ==O0O0OOOO0O00OOO00 :#line:263
      O0O0O0O0O0OO000OO =OO00O0OOOOOO0O00O #line:265
    else :#line:267
       if STARTP ()and STARTP2 ()=='ok':#line:268
         return OO00O0OOOOOO0O00O #line:270
       O0O0O0O0O0OO000OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:271
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:272
       sys .exit ()#line:273
    return O0O0O0O0O0OO000OO #line:274
try :#line:275
   disply_hwr ()#line:276
except :#line:277
   pass #line:278
def dis_or_enable_addon (OOO0OO00O00OO0O0O ,OOOO00OOOOOO00OOO ,enable ="true"):#line:279
    import json #line:280
    OOO00O00OO0OOOOO0 ='"%s"'%OOO0OO00O00OO0O0O #line:281
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0OO00O00OO0O0O )and enable =="true":#line:282
        logging .warning ('already Enabled')#line:283
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0OO00O00OO0O0O )#line:284
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0OO00O00OO0O0O )and enable =="false":#line:285
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0OO00O00OO0O0O )#line:286
    else :#line:287
        OOOOOO0O00O0O000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO00O00OO0OOOOO0 ,enable )#line:288
        OOO00OOO0000O0OOO =xbmc .executeJSONRPC (OOOOOO0O00O0O000O )#line:289
        O0OOOOO0OO00O0OOO =json .loads (OOO00OOO0000O0OOO )#line:290
        if enable =="true":#line:291
            xbmc .log ("### Enabled %s, response = %s"%(OOO0OO00O00OO0O0O ,O0OOOOO0OO00O0OOO ))#line:292
        else :#line:293
            xbmc .log ("### Disabled %s, response = %s"%(OOO0OO00O00OO0O0O ,O0OOOOO0OO00O0OOO ))#line:294
    if OOOO00OOOOOO00OOO =='auto':#line:295
     return True #line:296
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:297
def update_Votes ():#line:298
   try :#line:299
        import requests #line:300
        OO000O0OOO00OO000 ='18773068'#line:301
        O000O0OO0000OO0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO000O0OOO00OO000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:313
        O0OO0OO00O000OOO0 ='145273321'#line:315
        O0OO00OO0O00OO0OO ={'options':O0OO0OO00O000OOO0 }#line:321
        OOO0OO0O0000OO000 =requests .post ('https://www.strawpoll.me/'+OO000O0OOO00OO000 ,headers =O000O0OO0000OO0O0 ,data =O0OO00OO0O00OO0OO )#line:323
   except :pass #line:324
def display_Votes ():#line:325
    try :#line:326
        OO0000O000O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:327
        O0000O000OOOOOO00 =open (OO0000O000O0OO0O0 ,'r')#line:329
        OO0O000O0000OO000 =O0000O000OOOOOO00 .read ()#line:330
        O0000O000OOOOOO00 .close ()#line:331
        O0O0OOO0O0OOO00O0 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:332
        OOOOO00OOO0OOO0OO =re .compile (O0O0OOO0O0OOO00O0 ).findall (OO0O000O0000OO000 )[0 ]#line:334
        import requests #line:340
        OOO0O0000000O0OOO ='18782966'#line:341
        OO0OO00OO00000OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0O0000000O0OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:353
        OOOO0O0000000OOO0 ='145313053'#line:355
        O00O0OOOOOO00O0OO ='145313054'#line:356
        O0OO00OO00OO00OOO ='145313057'#line:357
        OO00OOOOOO0000000 ='145313058'#line:358
        O0O000OO00O0O0O0O ='145313055'#line:359
        OOOOOO00000O0O0OO ='145313060'#line:360
        OOOO00OOO0O0OOOO0 ='145313056'#line:361
        O00OO00OOOOOO0O0O ='145313059'#line:362
        if OOOOO00OOO0OOO0OO =='emin':#line:365
           OO0OOO00O000000O0 =OOOO0O0000000OOO0 #line:366
        if OOOOO00OOO0OOO0OO =='nox':#line:367
           OO0OOO00O000000O0 =O00O0OOOOOO00O0OO #line:368
        if OOOOO00OOO0OOO0OO =='noxtitan':#line:369
           OO0OOO00O000000O0 =O00O0OOOOOO00O0OO #line:370
        if OOOOO00OOO0OOO0OO =='titan':#line:371
           OO0OOO00O000000O0 =O0OO00OO00OO00OOO #line:372
        if OOOOO00OOO0OOO0OO =='pheno':#line:373
           OO0OOO00O000000O0 =OO00OOOOOO0000000 #line:374
        if OOOOO00OOO0OOO0OO =='netflix':#line:375
           OO0OOO00O000000O0 =O0O000OO00O0O0O0O #line:376
        if OOOOO00OOO0OOO0OO =='nebula':#line:377
           OO0OOO00O000000O0 =OOOOOO00000O0O0OO #line:378
        if OOOOO00OOO0OOO0OO =='pellucid':#line:379
           OO0OOO00O000000O0 =OOOO00OOO0O0OOOO0 #line:380
        if OOOOO00OOO0OOO0OO =='pellucid2':#line:381
           OO0OOO00O000000O0 =O00OO00OOOOOO0O0O #line:382
        O0O00OOOO0OOO0000 ={'options':OO0OOO00O000000O0 }#line:388
        OOOOO00O000000000 =requests .post ('https://www.strawpoll.me/'+OOO0O0000000O0OOO ,headers =OO0OO00OO00000OO0 ,data =O0O00OOOO0OOO0000 )#line:390
    except :pass #line:391
def resetkodi ():#line:392
		if xbmc .getCondVisibility ('system.platform.windows'):#line:393
			O00OO0OO0OO0OOO0O =xbmcgui .DialogProgress ()#line:394
			O00OO0OO0OO0OOO0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:397
			O00OO0OO0OO0OOO0O .update (0 )#line:398
			for O0O00O000OOOOOOOO in range (5 ,-1 ,-1 ):#line:399
				time .sleep (1 )#line:400
				O00OO0OO0OO0OOO0O .update (int ((5 -O0O00O000OOOOOOOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O00O000OOOOOOOO ),'')#line:401
				if O00OO0OO0OO0OOO0O .iscanceled ():#line:402
					from resources .libs import win #line:403
					return None ,None #line:404
			from resources .libs import win #line:405
		else :#line:406
			O00OO0OO0OO0OOO0O =xbmcgui .DialogProgress ()#line:407
			O00OO0OO0OO0OOO0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:410
			O00OO0OO0OO0OOO0O .update (0 )#line:411
			for O0O00O000OOOOOOOO in range (5 ,-1 ,-1 ):#line:412
				time .sleep (1 )#line:413
				O00OO0OO0OO0OOO0O .update (int ((5 -O0O00O000OOOOOOOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O00O000OOOOOOOO ),'')#line:414
				if O00OO0OO0OO0OOO0O .iscanceled ():#line:415
					os ._exit (1 )#line:416
					return None ,None #line:417
			os ._exit (1 )#line:418
def indicatorfastupdate ():#line:419
       try :#line:420
          import json #line:421
          wiz .log ('FRESH MESSAGE')#line:422
          OOO0OOOO0O0O0O000 =(ADDON .getSetting ("user"))#line:423
          OO000O0OOOO0O0OO0 =(ADDON .getSetting ("pass"))#line:424
          O00OOO0O0OO0O0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:425
          OOOO0OOOO0OO0O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:427
          OO0000OO000000OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:428
          O00OOO0O0O00O0O00 =str (json .loads (OO0000OO000000OOO )['ip'])#line:429
          O00O0OOOOO0OOOO00 =OOO0OOOO0O0O0O000 #line:430
          OOOO0O00OOOO0O0O0 =OO000O0OOOO0O0OO0 #line:431
          import socket #line:432
          OO0000OO000000OOO =urllib2 .urlopen (OOOO0OOOO0OO0O000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00O0OOOOO0OOOO00 +' - '+OOOO0O00OOOO0O0O0 +' - '+O00OOO0O0OO0O0000 +' - '+O00OOO0O0O00O0O00 ).readlines ()#line:433
       except :pass #line:435
def skindialogsettind18 ():#line:436
	try :#line:437
		O0OO00OOOOO0000OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:438
		O0OOO00OO00OOO0OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:439
		copyfile (O0OO00OOOOO0000OO ,O0OOO00OO00OOO0OO )#line:440
	except :pass #line:441
def checkidupdate ():#line:442
				O0OOOOOOOOOO00OO0 =True #line:443
				wiz .setS ("notedismiss","true")#line:444
				O000O00O0O00000OO =wiz .workingURL (NOTIFICATION )#line:445
				OOOO0000O0OOO000O =" Kodi Premium"#line:447
				OOOOOOO0OOO0OOO0O =wiz .checkBuild (OOOO0000O0OOO000O ,'gui')#line:448
				OOO00OOOO0OO00O00 =OOOO0000O0OOO000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:449
				if not wiz .workingURL (OOOOOOO0OOO0OOO0O )==True :return #line:450
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:451
				OOOOO00OO0OO0O000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO00OOOO0OO00O00 )#line:454
				try :os .remove (OOOOO00OO0OO0O000 )#line:455
				except :pass #line:456
				if 'google'in OOOOOOO0OOO0OOO0O :#line:458
				   O0OOO00OOO0OO0OOO =googledrive_download (OOOOOOO0OOO0OOO0O ,OOOOO00OO0OO0O000 ,DP2 ,wiz .checkBuild (OOOO0000O0OOO000O ,'filesize'))#line:459
				else :#line:462
				  downloaderbg .download3 (OOOOOOO0OOO0OOO0O ,OOOOO00OO0OO0O000 ,DP2 )#line:463
				xbmc .sleep (100 )#line:464
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:465
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:467
				extract .all2 (OOOOO00OO0OO0O000 ,HOME ,DP2 )#line:469
				DP2 .close ()#line:470
				wiz .defaultSkin ()#line:471
				wiz .lookandFeelData ('save')#line:472
				wiz .kodi17Fix ()#line:473
				if KODIV >=18 :#line:474
					skindialogsettind18 ()#line:475
				debridit .debridIt ('restore','all')#line:480
				traktit .traktIt ('restore','all')#line:481
				if INSTALLMETHOD ==1 :O0O00O0OOO0000OO0 =1 #line:482
				elif INSTALLMETHOD ==2 :O0O00O0OOO0000OO0 =0 #line:483
				else :DP2 .close ()#line:484
				O0OO0OOOOO0O0O0O0 =(NOTIFICATION2 )#line:485
				OOO0000OO000OO00O =urllib2 .urlopen (O0OO0OOOOO0O0O0O0 )#line:486
				O0O00O000000O0O0O =OOO0000OO000OO00O .readlines ()#line:487
				OOOO0O0OOOO0O0O00 =0 #line:488
				for OOOO000O0000OOOOO in O0O00O000000O0O0O :#line:491
					if OOOO000O0000OOOOO .split (' ==')[0 ]=="noreset"or OOOO000O0000OOOOO .split ()[0 ]=="noreset":#line:492
						xbmc .executebuiltin ("ReloadSkin()")#line:494
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:495
						OO0000OOO00O0O0OO =(ADDON .getSetting ("message"))#line:496
						if OO0000OOO00O0O0OO =='true':#line:497
							infobuild ()#line:498
						update_Votes ()#line:499
						indicatorfastupdate ()#line:500
					if OOOO000O0000OOOOO .split (' ==')[0 ]=="reset"or OOOO000O0000OOOOO .split ()[0 ]=="reset":#line:501
						update_Votes ()#line:503
						indicatorfastupdate ()#line:504
						resetkodi ()#line:505
def checkvictory ():#line:506
				wiz .setS ("notedismiss2","true")#line:508
				OO0OO000OOOOOO000 =wiz .workingURL (NOTIFICATION2 )#line:509
				O00O00OOOO0OO0OO0 =" Kodi Premium"#line:511
				OOO0OOOO00000O0OO ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:512
				O0O0OO00OOO0000O0 =O00O00OOOO0OO0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:513
				if not wiz .workingURL (OOO0OOOO00000O0OO )==True :return #line:514
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:515
				OOOO000000OO0OOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0OO00OOO0000O0 )#line:518
				try :os .remove (OOOO000000OO0OOO0 )#line:519
				except :pass #line:520
				if 'google'in OOO0OOOO00000O0OO :#line:522
				   OOO0OO00O000000OO =googledrive_download (OOO0OOOO00000O0OO ,OOOO000000OO0OOO0 ,DP2 ,wiz .checkBuild (O00O00OOOO0OO0OO0 ,'filesize'))#line:523
				else :#line:526
				  downloaderbg .download5 (OOO0OOOO00000O0OO ,OOOO000000OO0OOO0 ,DP2 )#line:527
				xbmc .sleep (100 )#line:528
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:529
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:531
				extract .all2 (OOOO000000OO0OOO0 ,ADDONS ,DP2 )#line:533
				DP2 .close ()#line:534
				wiz .defaultSkin ()#line:535
				wiz .lookandFeelData ('save')#line:536
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:537
				if INSTALLMETHOD ==1 :O0OOO00O0OO00000O =1 #line:539
				elif INSTALLMETHOD ==2 :O0OOO00O0OO00000O =0 #line:540
				else :DP2 .close ()#line:541
def checkUpdate ():#line:546
	O0O00000O0OOO0O00 =wiz .getS ('buildname')#line:547
	OO00O0O0OOOOO00O0 =wiz .getS ('buildversion')#line:548
	OOOOO0OOO00OOO00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:549
	OOO00OOOOOO00000O =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0O00000O0OOO0O00 ).findall (OOOOO0OOO00OOO00O )#line:550
	if len (OOO00OOOOOO00000O )>0 :#line:551
		O0OO0OO00000O0OOO =OOO00OOOOOO00000O [0 ][0 ]#line:552
		O000O0O0O0OO00OO0 =OOO00OOOOOO00000O [0 ][1 ]#line:553
		OO000OO0OO00OOO0O =OOO00OOOOOO00000O [0 ][2 ]#line:554
		wiz .setS ('latestversion',O0OO0OO00000O0OOO )#line:555
		if O0OO0OO00000O0OOO >OO00O0O0OOOOO00O0 :#line:556
			if DISABLEUPDATE =='false':#line:557
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OO00O0O0OOOOO00O0 ,O0OO0OO00000O0OOO ),xbmc .LOGNOTICE )#line:558
				notify .updateWindow (O0O00000O0OOO0O00 ,OO00O0O0OOOOO00O0 ,O0OO0OO00000O0OOO ,O000O0O0O0OO00OO0 ,OO000OO0OO00OOO0O )#line:559
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OO00O0O0OOOOO00O0 ,O0OO0OO00000O0OOO ),xbmc .LOGNOTICE )#line:560
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OO00O0O0OOOOO00O0 ,O0OO0OO00000O0OOO ),xbmc .LOGNOTICE )#line:561
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:562
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:597
if AUTOUPDATE =='Yes':#line:598
	input =(ADDON .getSetting ("autoupdate"))#line:599
	xbmc .executebuiltin ("UpdateLocalAddons")#line:600
	xbmc .executebuiltin ("UpdateAddonRepos")#line:601
	wiz .wizardUpdate ('startup')#line:602
	checkUpdate ()#line:604
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:606
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:610
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:611
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:613
	workingxml =wiz .workingURL (REPOADDONXML )#line:614
	if workingxml ==True :#line:615
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:616
		if len (ver )>0 :#line:617
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:618
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:619
			if workingrepo ==True :#line:620
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:621
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:622
				lib =os .path .join (PACKAGES ,installzip )#line:623
				try :os .remove (lib )#line:624
				except :pass #line:625
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:626
				extract .all (lib ,ADDONS ,DP )#line:627
				try :#line:628
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:629
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:630
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:631
				except :#line:632
					pass #line:633
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:634
				DP .close ()#line:635
				xbmc .sleep (500 )#line:636
				wiz .forceUpdate (True )#line:637
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:638
				xbmc .executebuiltin ("ReloadSkin()")#line:639
				xbmc .executebuiltin ("ActivateWindow(home)")#line:640
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:641
				xbmc .Player ().play (f_play ,windowed =False )#line:642
			else :#line:644
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:645
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:646
		else :#line:647
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:648
	else :#line:649
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:650
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:651
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:652
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:653
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:656
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:657
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:658
	if BUILDNAME =="":#line:659
		try :#line:660
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:661
		except :#line:662
				pass #line:663
	if workingxml ==True :#line:664
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:665
		if len (ver )>0 :#line:666
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:667
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:668
			if workingrepo ==True :#line:669
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:670
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:671
				lib =os .path .join (PACKAGES ,installzip )#line:672
				try :os .remove (lib )#line:673
				except :pass #line:674
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:675
				extract .all (lib ,ADDONS ,DP )#line:676
				try :#line:677
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:678
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:679
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:680
				except :#line:681
					pass #line:682
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:683
				DP .close ()#line:684
				xbmc .sleep (500 )#line:685
				wiz .forceUpdate (True )#line:686
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:687
				xbmc .executebuiltin ("ReloadSkin()")#line:688
				xbmc .executebuiltin ("ActivateWindow(home)")#line:689
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:690
				xbmc .Player ().play (f_play ,windowed =False )#line:691
			else :#line:693
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:694
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:695
		else :#line:696
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:697
	else :#line:698
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:699
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:700
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:703
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:704
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REQUESTSID )):#line:707
	workingxml =wiz .workingURL (REQUESTSXML )#line:708
	if workingxml ==True :#line:710
		ver =wiz .parseDOM (wiz .openURL (REQUESTSXML ),'addon',ret ='version',attrs ={'id':REQUESTSID })#line:711
		if len (ver )>0 :#line:712
			installzip ='%s-%s.zip'%(REQUESTSID ,ver [0 ])#line:713
			workingrepo =wiz .workingURL (REQUESTSURL +installzip )#line:714
			if workingrepo ==True :#line:715
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:717
				lib =os .path .join (PACKAGES ,installzip )#line:718
				try :os .remove (lib )#line:719
				except :pass #line:720
				downloaderbg .download4 (REQUESTSURL +installzip ,lib ,DP2 )#line:721
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:722
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:723
				extract .all2 (lib ,ADDONS ,DP2 )#line:724
				try :#line:725
					f =open (os .path .join (ADDONS ,REQUESTSID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:726
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REQUESTSID })#line:727
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REQUESTSID ,'icon.png'))#line:728
				except :#line:729
					pass #line:730
				if KODIV >=17 :wiz .addonDatabase (REQUESTSID ,1 )#line:731
				DP2 .close ()#line:732
				xbmc .sleep (500 )#line:733
				wiz .forceUpdate (True )#line:734
				wiz .kodi17Fix ()#line:735
def setuname ():#line:739
    O00OO0O0O00000OO0 =''#line:740
    O000OO0000OO00OO0 =xbmc .Keyboard (O00OO0O0O00000OO0 ,'הכנס שם משתמש')#line:741
    O000OO0000OO00OO0 .doModal ()#line:742
    if O000OO0000OO00OO0 .isConfirmed ():#line:743
           O00OO0O0O00000OO0 =O000OO0000OO00OO0 .getText ()#line:744
           wiz .setS ('user',str (O00OO0O0O00000OO0 ))#line:745
def STARTP2 ():#line:746
	if BUILDNAME ==" Kodi Premium":#line:747
		OO0O00000O000OO0O =(ADDON .getSetting ("user"))#line:748
		OOOO0OO0O0000000O =(UNAME )#line:749
		OO00OOOO000000O0O =urllib2 .urlopen (OOOO0OO0O0000000O )#line:750
		OOO0O00OO0O00O0O0 =OO00OOOO000000O0O .readlines ()#line:751
		O00O0O00000OO000O =0 #line:752
		for O00OO0O0O0OO00O00 in OOO0O00OO0O00O0O0 :#line:753
			if O00OO0O0O0OO00O00 .split (' ==')[0 ]==OO0O00000O000OO0O or O00OO0O0O0OO00O00 .split ()[0 ]==OO0O00000O000OO0O :#line:754
				O00O0O00000OO000O =1 #line:755
				break #line:756
		if O00O0O00000OO000O ==0 :#line:757
			OOO00000O00OOO000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:759
			if OOO00000O00OOO000 :#line:761
				ADDON .openSettings ()#line:762
				sys .exit ()#line:763
			else :#line:764
				sys .exit ()#line:765
		return 'ok'#line:769
def skinWIN ():#line:772
	idle ()#line:773
	O00OO0000OOOO0000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:774
	O000O00O0OOOOOOO0 =[];OO0OO0OOOOOOO000O =[]#line:775
	for O0O0O000O000000OO in sorted (O00OO0000OOOO0000 ,key =lambda O0O0O0OO0OOO0O0OO :O0O0O0OO0OOO0O0OO ):#line:776
		O0OOOO0O000O000O0 =os .path .split (O0O0O000O000000OO [:-1 ])[1 ]#line:777
		O0OOOO0OOO000000O =os .path .join (O0O0O000O000000OO ,'addon.xml')#line:778
		if os .path .exists (O0OOOO0OOO000000O ):#line:779
			O0O000OOOO000OOOO =open (O0OOOO0OOO000000O )#line:780
			O00OOOO0OO00O00OO =O0O000OOOO000OOOO .read ()#line:781
			O00OOOO000OOO00O0 =parseDOM2 (O00OOOO0OO00O00OO ,'addon',ret ='id')#line:782
			O000O00O0O00OO0O0 =O0OOOO0O000O000O0 if len (O00OOOO000OOO00O0 )==0 else O00OOOO000OOO00O0 [0 ]#line:783
			try :#line:784
				O00O0O00OO0O0O0OO =xbmcaddon .Addon (id =O000O00O0O00OO0O0 )#line:785
				O000O00O0OOOOOOO0 .append (O00O0O00OO0O0O0OO .getAddonInfo ('name'))#line:786
				OO0OO0OOOOOOO000O .append (O000O00O0O00OO0O0 )#line:787
			except :#line:788
				pass #line:789
	O0O000OOOO0000OO0 =[];O0OO00O0000000000 =0 #line:790
	OO0000OO00OOO000O =["Current Skin -- %s"%currSkin ()]+O000O00O0OOOOOOO0 #line:791
	O0OO00O0000000000 =DIALOG .select ("Select the Skin you want to swap with.",OO0000OO00OOO000O )#line:792
	if O0OO00O0000000000 ==-1 :return #line:793
	else :#line:794
		OO0O000OO0O0O0000 =(O0OO00O0000000000 -1 )#line:795
		O0O000OOOO0000OO0 .append (OO0O000OO0O0O0000 )#line:796
		OO0000OO00OOO000O [O0OO00O0000000000 ]="%s"%(O000O00O0OOOOOOO0 [OO0O000OO0O0O0000 ])#line:797
	if O0O000OOOO0000OO0 ==None :return #line:798
	for O0O0O000000O00OO0 in O0O000OOOO0000OO0 :#line:799
		swapSkins (OO0OO0OOOOOOO000O [O0O0O000000O00OO0 ])#line:800
def currSkin ():#line:802
	return xbmc .getSkinDir ('Container.PluginName')#line:803
def fix17update ():#line:805
	if KODIV >=17 and KODIV <18 :#line:806
		wiz .kodi17Fix ()#line:807
		xbmc .sleep (4000 )#line:808
		try :#line:809
			O0O0O0O00O000OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:810
			O00OOO0000OOO000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:811
			os .rename (O0O0O0O00O000OOO0 ,O00OOO0000OOO000O )#line:812
		except :#line:813
				pass #line:814
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:815
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:816
		fixfont ()#line:817
		O000O0O00OO0OO0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:818
		try :#line:820
			OOO0OOO000OO0OOO0 =open (O000O0O00OO0OO0O0 ,'r')#line:821
			O00O00O00OOOO00OO =OOO0OOO000OO0OOO0 .read ()#line:822
			OOO0OOO000OO0OOO0 .close ()#line:823
			OOO00OOO00O0000OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:824
			O0O0O00O00O00OOO0 =re .compile (OOO00OOO00O0000OO ).findall (O00O00O00OOOO00OO )[0 ]#line:825
			OOO0OOO000OO0OOO0 =open (O000O0O00OO0OO0O0 ,'w')#line:826
			OOO0OOO000OO0OOO0 .write (O00O00O00OOOO00OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O0O00O00O00OOO0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:827
			OOO0OOO000OO0OOO0 .close ()#line:828
		except :#line:829
				pass #line:830
		wiz .kodi17Fix ()#line:831
		O000O0O00OO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:832
		try :#line:833
			OOO0OOO000OO0OOO0 =open (O000O0O00OO0OO0O0 ,'r')#line:834
			O00O00O00OOOO00OO =OOO0OOO000OO0OOO0 .read ()#line:835
			OOO0OOO000OO0OOO0 .close ()#line:836
			OOO00OOO00O0000OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:837
			O0O0O00O00O00OOO0 =re .compile (OOO00OOO00O0000OO ).findall (O00O00O00OOOO00OO )[0 ]#line:838
			OOO0OOO000OO0OOO0 =open (O000O0O00OO0OO0O0 ,'w')#line:839
			OOO0OOO000OO0OOO0 .write (O00O00O00OOOO00OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O0O00O00O00OOO0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:840
			OOO0OOO000OO0OOO0 .close ()#line:841
		except :#line:842
				pass #line:843
		swapSkins ('skin.Premium.mod')#line:844
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:845
	os ._exit (1 )#line:846
def fix18update ():#line:847
	if KODIV >=18 :#line:848
		xbmc .sleep (4000 )#line:849
		if BUILDNAME =="":#line:850
			try :#line:851
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:852
			except :#line:853
				pass #line:854
		try :#line:855
			O0000O00OO000O00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:856
			O00000OO0OOOO0O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:857
			os .rename (O0000O00OO000O00O ,O00000OO0OOOO0O00 )#line:858
		except :#line:859
				pass #line:860
		skindialogsettind18 ()#line:861
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:862
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:863
		fixfont ()#line:864
		O0O00OOOOO00OO0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:865
		try :#line:866
			OOOO0OOOO000O0O0O =open (O0O00OOOOO00OO0OO ,'r')#line:867
			OOO0O000O0OOO00OO =OOOO0OOOO000O0O0O .read ()#line:868
			OOOO0OOOO000O0O0O .close ()#line:869
			O0OOOOOO00O0O00O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:870
			OO0O00OOOO0O00OO0 =re .compile (O0OOOOOO00O0O00O0 ).findall (OOO0O000O0OOO00OO )[0 ]#line:871
			OOOO0OOOO000O0O0O =open (O0O00OOOOO00OO0OO ,'w')#line:872
			OOOO0OOOO000O0O0O .write (OOO0O000O0OOO00OO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0O00OOOO0O00OO0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:873
			OOOO0OOOO000O0O0O .close ()#line:874
		except :#line:875
				pass #line:876
		wiz .kodi17Fix ()#line:877
		O0O00OOOOO00OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:878
		try :#line:879
			OOOO0OOOO000O0O0O =open (O0O00OOOOO00OO0OO ,'r')#line:880
			OOO0O000O0OOO00OO =OOOO0OOOO000O0O0O .read ()#line:881
			OOOO0OOOO000O0O0O .close ()#line:882
			O0OOOOOO00O0O00O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:883
			OO0O00OOOO0O00OO0 =re .compile (O0OOOOOO00O0O00O0 ).findall (OOO0O000O0OOO00OO )[0 ]#line:884
			OOOO0OOOO000O0O0O =open (O0O00OOOOO00OO0OO ,'w')#line:885
			OOOO0OOOO000O0O0O .write (OOO0O000O0OOO00OO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0O00OOOO0O00OO0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:886
			OOOO0OOOO000O0O0O .close ()#line:887
		except :#line:888
				pass #line:889
		swapSkins ('skin.Premium.mod')#line:890
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:891
	os ._exit (1 )#line:892
def swapSkins (O0OO00000O0O0OOOO ,title ="Error"):#line:893
	O000OOO0OOOOOOO0O ='lookandfeel.skin'#line:894
	O00000000OO00O000 =O0OO00000O0O0OOOO #line:895
	OO000O00OO0OO0OOO =getOld (O000OOO0OOOOOOO0O )#line:896
	OO0O0OO0OOO0OO0O0 =O000OOO0OOOOOOO0O #line:897
	setNew (OO0O0OO0OOO0OO0O0 ,O00000000OO00O000 )#line:898
	O0OOOO0OOOO000O0O =0 #line:899
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOO0OOOO000O0O <100 :#line:900
		O0OOOO0OOOO000O0O +=1 #line:901
		xbmc .sleep (1 )#line:902
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:903
		xbmc .executebuiltin ('SendClick(11)')#line:904
	return True #line:905
def getOld (O000OOOO0OO00O0O0 ):#line:907
	try :#line:908
		O000OOOO0OO00O0O0 ='"%s"'%O000OOOO0OO00O0O0 #line:909
		O0OO0O00O0OOO00O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O000OOOO0OO00O0O0 )#line:910
		OO0000O00O0OOO00O =xbmc .executeJSONRPC (O0OO0O00O0OOO00O0 )#line:912
		OO0000O00O0OOO00O =simplejson .loads (OO0000O00O0OOO00O )#line:913
		if OO0000O00O0OOO00O .has_key ('result'):#line:914
			if OO0000O00O0OOO00O ['result'].has_key ('value'):#line:915
				return OO0000O00O0OOO00O ['result']['value']#line:916
	except :#line:917
		pass #line:918
	return None #line:919
def setNew (O0OO0O00OOO0OOOOO ,O0OO0O0OO000OO0OO ):#line:922
	try :#line:923
		O0OO0O00OOO0OOOOO ='"%s"'%O0OO0O00OOO0OOOOO #line:924
		O0OO0O0OO000OO0OO ='"%s"'%O0OO0O0OO000OO0OO #line:925
		OOO0O0000O00OOOO0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0OO0O00OOO0OOOOO ,O0OO0O0OO000OO0OO )#line:926
		O00OO00O00000OO0O =xbmc .executeJSONRPC (OOO0O0000O00OOOO0 )#line:928
	except :#line:929
		pass #line:930
	return None #line:931
def idle ():#line:932
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:933
def fixfont ():#line:934
	OOOOO000O000O0000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:935
	O0OOOO00O00OO00O0 =json .loads (OOOOO000O000O0000 );#line:937
	OOOOO0OO000OOO0O0 =O0OOOO00O00OO00O0 ["result"]["settings"]#line:938
	O0000O00000OOO000 =[OOOOO0O00OO000O00 for OOOOO0O00OO000O00 in OOOOO0OO000OOO0O0 if OOOOO0O00OO000O00 ["id"]=="audiooutput.audiodevice"][0 ]#line:940
	O0O000000OOO0000O =O0000O00000OOO000 ["options"];#line:941
	O000O0000OO00O0O0 =O0000O00000OOO000 ["value"];#line:942
	O0O0O000O0000000O =[O0O0OOO0O0O0OOO00 for (O0O0OOO0O0O0OOO00 ,OO0OOO0O0O0O00OO0 )in enumerate (O0O000000OOO0000O )if OO0OOO0O0O0O00OO0 ["value"]==O000O0000OO00O0O0 ][0 ];#line:944
	OO0OOOOO0OO00OO00 =(O0O0O000O0000000O +1 )%len (O0O000000OOO0000O )#line:946
	O0O0O0000OOO0O00O =O0O000000OOO0000O [OO0OOOOO0OO00OO00 ]["value"]#line:948
	O00OO0O0OOO000O00 =O0O000000OOO0000O [OO0OOOOO0OO00OO00 ]["label"]#line:949
	OO0O0O000OO000000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:951
	try :#line:953
		O0O00OOO000000000 =json .loads (OO0O0O000OO000000 );#line:954
		if O0O00OOO000000000 ["result"]!=True :#line:956
			raise Exception #line:957
	except :#line:958
		sys .stderr .write ("Error switching audio output device")#line:959
		raise Exception #line:960
def checkSkin ():#line:963
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:964
	O000O0OO0O00000OO =wiz .getS ('defaultskin')#line:965
	OO0OOO0000OOOOO0O =wiz .getS ('defaultskinname')#line:966
	OOOOO00OO0O0OOO00 =wiz .getS ('defaultskinignore')#line:967
	OO0O0OOOOOO000O00 =False #line:968
	if not O000O0OO0O00000OO =='':#line:969
		if os .path .exists (os .path .join (ADDONS ,O000O0OO0O00000OO )):#line:970
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOO0000OOOOO0O )):#line:971
				OO0O0OOOOOO000O00 =O000O0OO0O00000OO #line:972
				OOO0O000O0OO00OO0 =OO0OOO0000OOOOO0O #line:973
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');OO0O0OOOOOO000O00 =False #line:974
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O000O0OO0O00000OO ='';OO0OOO0000OOOOO0O =''#line:975
	if O000O0OO0O00000OO =='':#line:976
		OOO0000O00O0O0OO0 =[]#line:977
		O0OOO00O00000OOOO =[]#line:978
		for OO0OOOOO0000000O0 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:979
			OO0OO0OO0OO0O0O0O ="%s/addon.xml"%OO0OOOOO0000000O0 #line:980
			if os .path .exists (OO0OO0OO0OO0O0O0O ):#line:981
				OO000O0O0OO000000 =open (OO0OO0OO0OO0O0O0O ,mode ='r');OO000OO0OOOO0000O =OO000O0O0OO000000 .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO000O0O0OO000000 .close ();#line:982
				O00O000OOO000O00O =wiz .parseDOM (OO000OO0OOOO0000O ,'addon',ret ='id')#line:983
				O000OOOOOO000OOOO =wiz .parseDOM (OO000OO0OOOO0000O ,'addon',ret ='name')#line:984
				wiz .log ("%s: %s"%(OO0OOOOO0000000O0 ,str (O00O000OOO000O00O [0 ])),xbmc .LOGNOTICE )#line:985
				if len (O00O000OOO000O00O )>0 :O0OOO00O00000OOOO .append (str (O00O000OOO000O00O [0 ]));OOO0000O00O0O0OO0 .append (str (O000OOOOOO000OOOO [0 ]))#line:986
				else :wiz .log ("ID not found for %s"%OO0OOOOO0000000O0 ,xbmc .LOGNOTICE )#line:987
			else :wiz .log ("ID not found for %s"%OO0OOOOO0000000O0 ,xbmc .LOGNOTICE )#line:988
		if len (O0OOO00O00000OOOO )>0 :#line:989
			if len (O0OOO00O00000OOOO )>1 :#line:990
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:991
					O000OOOO000OOOO00 =DIALOG .select ("Select skin to switch to!",OOO0000O00O0O0OO0 )#line:992
					if O000OOOO000OOOO00 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:993
					else :#line:994
						OO0O0OOOOOO000O00 =O0OOO00O00000OOOO [O000OOOO000OOOO00 ]#line:995
						OOO0O000O0OO00OO0 =OOO0000O00O0O0OO0 [O000OOOO000OOOO00 ]#line:996
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:997
	if OO0O0OOOOOO000O00 :#line:1004
		skinSwitch .swapSkins (OO0O0OOOOOO000O00 )#line:1005
		OO0OO00OO0O0OOOOO =0 #line:1006
		xbmc .sleep (1000 )#line:1007
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OO00OO0O0OOOOO <150 :#line:1008
			OO0OO00OO0O0OOOOO +=1 #line:1009
			xbmc .sleep (200 )#line:1010
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:1012
			wiz .ebi ('SendClick(11)')#line:1013
			wiz .lookandFeelData ('restore')#line:1014
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:1015
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:1016
while xbmc .Player ().isPlayingVideo ():#line:1018
	xbmc .sleep (1000 )#line:1019
if KODIV >=17 :#line:1021
	NOW =datetime .now ()#line:1022
	temp =wiz .getS ('kodi17iscrap')#line:1023
	if not temp =='':#line:1024
		if temp >str (NOW -timedelta (minutes =2 )):#line:1025
			wiz .log ("Killing Start Up Script")#line:1026
			sys .exit ()#line:1027
	wiz .log ("%s"%(NOW ))#line:1028
	wiz .setS ('kodi17iscrap',str (NOW ))#line:1029
	xbmc .sleep (1000 )#line:1030
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:1031
		wiz .log ("Killing Start Up Script")#line:1032
		sys .exit ()#line:1033
	else :#line:1034
		wiz .log ("Continuing Start Up Script")#line:1035
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:1037
path =os .path .split (ADDONPATH )#line:1038
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:1039
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:1040
if KODIADDONS in ADDONPATH :#line:1043
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:1044
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:1045
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:1046
	if os .path .exists (newpath ):#line:1047
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:1048
		wiz .cleanHouse (newpath )#line:1049
		wiz .removeFolder (newpath )#line:1050
	try :#line:1051
		wiz .copytree (ADDONPATH ,newpath )#line:1052
	except Exception as e :#line:1053
		pass #line:1054
	wiz .forceUpdate (True )#line:1055
try :#line:1057
	mybuilds =xbmc .translatePath (MYBUILDS )#line:1058
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1059
except :#line:1060
	pass #line:1061
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1063
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1067
			wiz .kodi17Fix ()#line:1068
			fix18update ()#line:1069
			fix17update ()#line:1070
if INSTALLED =='true':#line:1073
    input =(ADDON .getSetting ("auto_rd"))#line:1074
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1076
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1077
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1078
    wiz .clearS ('install')#line:1079
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1164
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1166
	input =(ADDON .getSetting ("autoupdate"))#line:1167
	STARTP2 ()#line:1168
	if not NOTIFY =='true':#line:1169
		url =wiz .workingURL (NOTIFICATION )#line:1170
		if url ==True :#line:1171
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1172
			if not id ==False :#line:1173
				try :#line:1174
					id =int (id );NOTEID =int (NOTEID )#line:1175
					if id ==NOTEID :#line:1176
						if NOTEDISMISS =='false':#line:1177
							debridit .debridIt ('update','all')#line:1178
							traktit .traktIt ('update','all')#line:1179
							checkidupdate ()#line:1180
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1181
					elif id >NOTEID :#line:1182
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1183
						wiz .setS ('noteid',str (id ))#line:1184
						wiz .setS ('notedismiss','false')#line:1185
						if input =='true':#line:1186
							debridit .debridIt ('update','all')#line:1187
							traktit .traktIt ('update','all')#line:1188
							checkidupdate ()#line:1189
						else :notify .notification (msg =msg )#line:1190
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1191
				except Exception as e :#line:1192
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1193
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1194
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1195
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1196
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1197
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1199
if ENABLE =='No':#line:1200
	if not NOTIFY2 =='true':#line:1201
		url =wiz .workingURL (NOTIFICATION2 )#line:1202
		if url ==True :#line:1203
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1204
			if not id ==False :#line:1205
				try :#line:1206
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1207
					if id ==NOTEID2 :#line:1208
						if NOTEDISMISS2 =='false':#line:1209
							checkvictory ()#line:1210
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1211
					elif id >NOTEID2 :#line:1212
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1213
						wiz .setS ('noteid2',str (id ))#line:1214
						wiz .setS ('notedismiss2','false')#line:1215
						checkvictory ()#line:1216
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1217
				except Exception as e :#line:1218
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1219
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1220
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1221
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1222
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1223
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1225
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1226
	if not NOTIFY3 =='true':#line:1227
		url =wiz .workingURL (NOTIFICATION3 )#line:1228
		if url ==True :#line:1229
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1230
			if not id ==False :#line:1231
				try :#line:1232
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1233
					if id ==NOTEID3 :#line:1234
						if NOTEDISMISS3 =='false':#line:1235
							notify .notification3 (msg )#line:1236
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1237
					elif id >NOTEID3 :#line:1238
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1239
						wiz .setS ('noteid3',str (id ))#line:1240
						wiz .setS ('notedismiss3','false')#line:1241
						notify .notification3 (msg =msg )#line:1242
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1243
				except Exception as e :#line:1244
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1245
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1246
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1247
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1248
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1249
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1250
if KEEPTRAKT =='true':#line:1251
	if TRAKTSAVE <=str (TODAY ):#line:1252
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1253
		traktit .autoUpdate ('all')#line:1254
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1255
	else :#line:1256
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1257
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1258
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1260
if KEEPREAL =='true':#line:1261
	if REALSAVE <=str (TODAY ):#line:1262
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1263
		debridit .autoUpdate ('all')#line:1264
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1265
	else :#line:1266
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1267
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1268
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1270
if KEEPLOGIN =='true':#line:1271
	if LOGINSAVE <=str (TODAY ):#line:1272
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1273
		loginit .autoUpdate ('all')#line:1274
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1275
	else :#line:1276
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1277
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1278
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1280
if AUTOCLEANUP =='true':#line:1281
	service =False #line:1282
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1283
	feq =int (float (AUTOFEQ ))#line:1284
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1285
		service =True #line:1286
		next_run =days [feq ]#line:1287
		wiz .setS ('nextautocleanup',str (next_run ))#line:1288
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1289
	if service ==True :#line:1290
		AUTOCACHE =wiz .getS ('clearcache')#line:1291
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1292
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1293
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1294
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1295
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1296
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1297
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1298
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1299
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1300
wiz .setS ('kodi17iscrap','')#line:1302
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1371
	count =0 #line:1372
	for f in filenames :#line:1373
		count +=1 #line:1374
		fp =os .path .join (dirpath ,f )#line:1375
		total_size +=os .path .getsize (fp )#line:1376
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1377
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1384
	for f2 in filenames2 :#line:1385
		fp2 =os .path .join (dirpath2 ,f2 )#line:1386
		total_size2 +=os .path .getsize (fp2 )#line:1387
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1388
if int (total_sizetext2 )>filesize_thumb :#line:1390
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1391
	if choice2 ==1 :#line:1392
		maintenance .deleteThumbnails ()#line:1393
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1395
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1396
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1398
time .sleep (3 )#line:1399
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1401
        display_Votes ()#line:1402
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1404
        file .write (str ('Done'))#line:1406
        file .close ()#line:1407
tele =(ADDON .getSetting ("auto_tele"))#line:1412
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1414
    if tele =='true':#line:1416
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:1417
