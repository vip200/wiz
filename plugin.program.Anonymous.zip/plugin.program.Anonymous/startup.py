# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
REQUESTSID =uservar .REQUESTSID #line:120
REQUESTSXML =uservar .REQUESTSXML #line:121
REQUESTSURL =uservar .REQUESTSURL #line:122
COLOR1 =uservar .COLOR1 #line:126
COLOR2 =uservar .COLOR2 #line:127
TMDB_NEW_API =uservar .TMDB_NEW_API #line:128
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:129
FAILED =False #line:130
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:131
AddonID ='plugin.program.Anonymous'#line:133
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:134
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:135
dialog =xbmcgui .Dialog ()#line:136
setting =xbmcaddon .Addon ().getSetting #line:137
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:138
notify_mode =setting ('notify_mode')#line:139
auto_clean =setting ('startup.cache')#line:140
filesize_thumb =int (setting ('filesizethumb_alert'))#line:142
total_size2 =0 #line:145
total_size =0 #line:146
count =0 #line:147
def disply_hwr ():#line:149
   try :#line:150
    OOOO00000O000O00O =tmdb_list (TMDB_NEW_API )#line:151
    O0O0OO0OOOOOO0OO0 =str ((getHwAddr ('eth0'))*OOOO00000O000O00O )#line:152
    OOO0OOOO0OO00O00O =(O0O0OO0OOOOOO0OO0 [1 ]+O0O0OO0OOOOOO0OO0 [2 ]+O0O0OO0OOOOOO0OO0 [5 ]+O0O0OO0OOOOOO0OO0 [7 ])#line:159
    OOOO0O00OOO00O0O0 =(ADDON .getSetting ("action"))#line:160
    wiz .setS ('action',str (OOO0OOOO0OO00O00O ))#line:162
   except :pass #line:163
def getHwAddr (OOOO0OO0OOOO00O0O ):#line:164
   import subprocess ,time #line:165
   OOOO0O00O0O000O00 ='windows'#line:166
   if xbmc .getCondVisibility ('system.platform.android'):#line:167
       OOOO0O00O0O000O00 ='android'#line:168
   if xbmc .getCondVisibility ('system.platform.android'):#line:169
     O0O0OOO0OOO000000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:170
     OO0O0O000O00OO000 =re .compile ('link/ether (.+?) brd').findall (str (O0O0OOO0OOO000000 ))#line:172
     OOOOO0000OOO0OOO0 =0 #line:173
     for O0OOOOOOOOO0O0OOO in OO0O0O000O00OO000 :#line:174
      if OO0O0O000O00OO000 !='00:00:00:00:00:00':#line:175
          OO00O00O000O0O0OO =O0OOOOOOOOO0O0OOO #line:176
          OOOOO0000OOO0OOO0 =OOOOO0000OOO0OOO0 +int (OO00O00O000O0O0OO .replace (':',''),16 )#line:177
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:179
       OOOO000OO0OOO00O0 =0 #line:180
       OOOOO0000OOO0OOO0 =0 #line:181
       O00O00O00OOO0OOOO =[]#line:182
       O0OOO00OO0O00OOOO =os .popen ("getmac").read ()#line:183
       O0OOO00OO0O00OOOO =O0OOO00OO0O00OOOO .split ("\n")#line:184
       for O0OOO00OOO0000O0O in O0OOO00OO0O00OOOO :#line:186
            OO000000000OOO0O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OOO00OOO0000O0O ,re .I )#line:187
            if OO000000000OOO0O0 :#line:188
                OO0O0O000O00OO000 =OO000000000OOO0O0 .group ().replace ('-',':')#line:189
                O00O00O00OOO0OOOO .append (OO0O0O000O00OO000 )#line:190
                OOOOO0000OOO0OOO0 =OOOOO0000OOO0OOO0 +int (OO0O0O000O00OO000 .replace (':',''),16 )#line:193
   else :#line:195
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:196
   try :#line:213
    return OOOOO0000OOO0OOO0 #line:214
   except :pass #line:215
def decode (OO0OOO00OO0OO00O0 ,O00OOOOOOOOO0O000 ):#line:216
    import base64 #line:217
    OOOO00O0O00000O0O =[]#line:218
    if (len (OO0OOO00OO0OO00O0 ))!=4 :#line:220
     return 10 #line:221
    O00OOOOOOOOO0O000 =base64 .urlsafe_b64decode (O00OOOOOOOOO0O000 )#line:222
    for O0O00OO00OO0O00O0 in range (len (O00OOOOOOOOO0O000 )):#line:224
        O0O0O00O00OOO0O00 =OO0OOO00OO0OO00O0 [O0O00OO00OO0O00O0 %len (OO0OOO00OO0OO00O0 )]#line:225
        OO0OO00000O0OOO00 =chr ((256 +ord (O00OOOOOOOOO0O000 [O0O00OO00OO0O00O0 ])-ord (O0O0O00O00OOO0O00 ))%256 )#line:226
        OOOO00O0O00000O0O .append (OO0OO00000O0OOO00 )#line:227
    return "".join (OOOO00O0O00000O0O )#line:228
def tmdb_list (OOO0OOOOOOOO00OOO ):#line:229
    O0OO000O0O000O000 =decode ("7643",OOO0OOOOOOOO00OOO )#line:232
    return int (O0OO000O0O000O000 )#line:235
def u_list (OOOO0OOOOOO00OO0O ):#line:236
    from math import sqrt #line:238
    O0000OOO0OO0O00O0 =tmdb_list (TMDB_NEW_API )#line:239
    O0O00OO000O00000O =str ((getHwAddr ('eth0'))*O0000OOO0OO0O00O0 )#line:241
    O0O000OO0OO0000O0 =int (O0O00OO000O00000O [1 ]+O0O00OO000O00000O [2 ]+O0O00OO000O00000O [5 ]+O0O00OO000O00000O [7 ])#line:242
    O000O00O0O00000OO =(ADDON .getSetting ("pass"))#line:244
    OOO0OO0OO000OOO0O =(str (round (sqrt ((O0O000OO0OO0000O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:249
    if '.'in OOO0OO0OO000OOO0O :#line:250
     OOO0OO0OO000OOO0O =(str (round (sqrt ((O0O000OO0OO0000O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:251
    if O000O00O0O00000OO ==OOO0OO0OO000OOO0O :#line:252
      O0O0OO0000OOO0OOO =OOOO0OOOOOO00OO0O #line:254
    else :#line:256
       if STARTP ()and STARTP2 ()=='ok':#line:257
         return OOOO0OOOOOO00OO0O #line:259
       O0O0OO0000OOO0OOO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:260
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:261
       sys .exit ()#line:262
    return O0O0OO0000OOO0OOO #line:263
try :#line:264
   disply_hwr ()#line:265
except :#line:266
   pass #line:267
def dis_or_enable_addon (OO000OOO00O000O0O ,OOOO00O0O0O000000 ,enable ="true"):#line:268
    import json #line:269
    O0O0O0000OOOO0O0O ='"%s"'%OO000OOO00O000O0O #line:270
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000OOO00O000O0O )and enable =="true":#line:271
        logging .warning ('already Enabled')#line:272
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO000OOO00O000O0O )#line:273
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000OOO00O000O0O )and enable =="false":#line:274
        return xbmc .log ("### Skipped %s, reason = not installed"%OO000OOO00O000O0O )#line:275
    else :#line:276
        OOOO0OOOO0000OO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O0O0000OOOO0O0O ,enable )#line:277
        OO0O0O000OO0OOOOO =xbmc .executeJSONRPC (OOOO0OOOO0000OO0O )#line:278
        O0O0000O0OO000O00 =json .loads (OO0O0O000OO0OOOOO )#line:279
        if enable =="true":#line:280
            xbmc .log ("### Enabled %s, response = %s"%(OO000OOO00O000O0O ,O0O0000O0OO000O00 ))#line:281
        else :#line:282
            xbmc .log ("### Disabled %s, response = %s"%(OO000OOO00O000O0O ,O0O0000O0OO000O00 ))#line:283
    if OOOO00O0O0O000000 =='auto':#line:284
     return True #line:285
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:286
def update_Votes ():#line:287
   try :#line:288
        import requests #line:289
        O0OOO00000O0O00OO ='18773068'#line:290
        OO000000OOO0OO0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOO00000O0O00OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:302
        OOO0OO0OO0OO00OOO ='145273321'#line:304
        OOO0OOOO0OOOO00OO ={'options':OOO0OO0OO0OO00OOO }#line:310
        O0O000O0OOOOO000O =requests .post ('https://www.strawpoll.me/'+O0OOO00000O0O00OO ,headers =OO000000OOO0OO0O0 ,data =OOO0OOOO0OOOO00OO )#line:312
   except :pass #line:313
def display_Votes ():#line:314
    try :#line:315
        O0O000OOO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:316
        OO0O00OO0OOOO0000 =open (O0O000OOO0OOOOOOO ,'r')#line:318
        OOOO00OO00O0O00OO =OO0O00OO0OOOO0000 .read ()#line:319
        OO0O00OO0OOOO0000 .close ()#line:320
        OOOOO00OOOO0OO000 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:321
        O0OOO0OO000000OOO =re .compile (OOOOO00OOOO0OO000 ).findall (OOOO00OO00O0O00OO )[0 ]#line:323
        import requests #line:329
        O00O00000O000O0OO ='18782966'#line:330
        OO0000OO00OOO0O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O00000O000O0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:342
        OOOOO0OOO0OOO0OO0 ='145313053'#line:344
        O0O0OO00OOOOO00OO ='145313054'#line:345
        OO0OOOOO0OOO0O0O0 ='145313057'#line:346
        O00OOOOOOOOO0O0OO ='145313058'#line:347
        OOOOOO0000O00O0OO ='145313055'#line:348
        O0OO00OOOO00O00OO ='145313060'#line:349
        OOOO0O0O00OO0O0O0 ='145313056'#line:350
        O000OOOOOOO00O0O0 ='145313059'#line:351
        if O0OOO0OO000000OOO =='emin':#line:354
           OOOOO0OO0O00000OO =OOOOO0OOO0OOO0OO0 #line:355
        if O0OOO0OO000000OOO =='nox':#line:356
           OOOOO0OO0O00000OO =O0O0OO00OOOOO00OO #line:357
        if O0OOO0OO000000OOO =='noxtitan':#line:358
           OOOOO0OO0O00000OO =O0O0OO00OOOOO00OO #line:359
        if O0OOO0OO000000OOO =='titan':#line:360
           OOOOO0OO0O00000OO =OO0OOOOO0OOO0O0O0 #line:361
        if O0OOO0OO000000OOO =='pheno':#line:362
           OOOOO0OO0O00000OO =O00OOOOOOOOO0O0OO #line:363
        if O0OOO0OO000000OOO =='netflix':#line:364
           OOOOO0OO0O00000OO =OOOOOO0000O00O0OO #line:365
        if O0OOO0OO000000OOO =='nebula':#line:366
           OOOOO0OO0O00000OO =O0OO00OOOO00O00OO #line:367
        if O0OOO0OO000000OOO =='pellucid':#line:368
           OOOOO0OO0O00000OO =OOOO0O0O00OO0O0O0 #line:369
        if O0OOO0OO000000OOO =='pellucid2':#line:370
           OOOOO0OO0O00000OO =O000OOOOOOO00O0O0 #line:371
        O0O00OO0O0O0O00OO ={'options':OOOOO0OO0O00000OO }#line:377
        O0000OOOOOOOOOOO0 =requests .post ('https://www.strawpoll.me/'+O00O00000O000O0OO ,headers =OO0000OO00OOO0O0O ,data =O0O00OO0O0O0O00OO )#line:379
    except :pass #line:380
def indicatorfastupdate ():#line:381
       try :#line:382
          import json #line:383
          wiz .log ('FRESH MESSAGE')#line:384
          O00OO0OO00OO0O0O0 =(ADDON .getSetting ("user"))#line:385
          O00O0OOOOO0O00O00 =(ADDON .getSetting ("pass"))#line:386
          OO0000OO0O0OO0OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:387
          O0O0OOO0O00O0O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:389
          O0000OO00OOOOO0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:390
          O0OO0OOO0O000OO00 =str (json .loads (O0000OO00OOOOO0OO )['ip'])#line:391
          O0O0OOO0O00O00O00 =O00OO0OO00OO0O0O0 #line:392
          O00O00000O0O0OO00 =O00O0OOOOO0O00O00 #line:393
          import socket #line:394
          O0000OO00OOOOO0OO =urllib2 .urlopen (O0O0OOO0O00O0O000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0OOO0O00O00O00 +' - '+O00O00000O0O0OO00 +' - '+OO0000OO0O0OO0OOO +' - '+O0OO0OOO0O000OO00 ).readlines ()#line:395
       except :pass #line:397
def skindialogsettind18 ():#line:398
	try :#line:399
		O0O00O0O0OOOOOOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:400
		O000OOOOOO000000O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:401
		copyfile (O0O00O0O0OOOOOOO0 ,O000OOOOOO000000O )#line:402
	except :pass #line:403
def checkidupdate ():#line:404
				wiz .setS ("notedismiss","true")#line:406
				O0O000OOOO000O0O0 =wiz .workingURL (NOTIFICATION )#line:407
				OO00O0O00O0O0000O =" Kodi Premium"#line:409
				OO000OOOOOOO0O0OO =wiz .checkBuild (OO00O0O00O0O0000O ,'gui')#line:410
				O00000O0OOO0000OO =OO00O0O00O0O0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:411
				if not wiz .workingURL (OO000OOOOOOO0O0OO )==True :return #line:412
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:413
				OO0OOO0000O0OO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00000O0OOO0000OO )#line:416
				try :os .remove (OO0OOO0000O0OO00O )#line:417
				except :pass #line:418
				if 'google'in OO000OOOOOOO0O0OO :#line:420
				   O0O00O0O0O000OO00 =googledrive_download (OO000OOOOOOO0O0OO ,OO0OOO0000O0OO00O ,DP2 ,wiz .checkBuild (OO00O0O00O0O0000O ,'filesize'))#line:421
				else :#line:424
				  downloaderbg .download3 (OO000OOOOOOO0O0OO ,OO0OOO0000O0OO00O ,DP2 )#line:425
				xbmc .sleep (100 )#line:426
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:427
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:429
				extract .all2 (OO0OOO0000O0OO00O ,HOME ,DP2 )#line:431
				DP2 .close ()#line:432
				wiz .defaultSkin ()#line:433
				wiz .lookandFeelData ('save')#line:434
				wiz .kodi17Fix ()#line:435
				if KODIV >=18 :#line:436
					skindialogsettind18 ()#line:437
				xbmc .executebuiltin ("ReloadSkin()")#line:438
				update_Votes ()#line:439
				indicatorfastupdate ()#line:440
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:441
				debridit .debridIt ('restore','all')#line:442
				traktit .traktIt ('restore','all')#line:443
				if INSTALLMETHOD ==1 :OO00O00OO0OOOO0O0 =1 #line:444
				elif INSTALLMETHOD ==2 :OO00O00OO0OOOO0O0 =0 #line:445
				else :DP2 .close ()#line:446
def checkvictory ():#line:447
				wiz .setS ("notedismiss2","true")#line:449
				O0OO0OOOO00O0O000 =wiz .workingURL (NOTIFICATION2 )#line:450
				OO00OO00O0OO00000 =" Kodi Premium"#line:452
				O00OOOOO00OO00OO0 ='aHR0cHM6Ly9naXRodWIuY29tL3ZpcDIwMC92aWN0b3J5L2Jsb2IvbWFzdGVyL3BsdWdpbi52aWRlby5hbGxtb3ZpZXNpbi56aXA/cmF3PXRydWU='.decode ('base64')#line:453
				O0OOOO0O00O000O00 =OO00OO00O0OO00000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:454
				if not wiz .workingURL (O00OOOOO00OO00OO0 )==True :return #line:455
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:456
				O0OO000O00O00OO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOO0O00O000O00 )#line:459
				try :os .remove (O0OO000O00O00OO0O )#line:460
				except :pass #line:461
				if 'google'in O00OOOOO00OO00OO0 :#line:463
				   O0000OOOOOO0OOO00 =googledrive_download (O00OOOOO00OO00OO0 ,O0OO000O00O00OO0O ,DP2 ,wiz .checkBuild (OO00OO00O0OO00000 ,'filesize'))#line:464
				else :#line:467
				  downloaderbg .download5 (O00OOOOO00OO00OO0 ,O0OO000O00O00OO0O ,DP2 )#line:468
				xbmc .sleep (100 )#line:469
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:470
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:472
				extract .all2 (O0OO000O00O00OO0O ,ADDONS ,DP2 )#line:474
				DP2 .close ()#line:475
				wiz .defaultSkin ()#line:476
				wiz .lookandFeelData ('save')#line:477
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ההרחבה עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:478
				if INSTALLMETHOD ==1 :O0O0O00O00O000O00 =1 #line:480
				elif INSTALLMETHOD ==2 :O0O0O00O00O000O00 =0 #line:481
				else :DP2 .close ()#line:482
def checkUpdate ():#line:487
	OOO0OO00OO00000OO =wiz .getS ('buildname')#line:488
	O0OOO0OO000O00OOO =wiz .getS ('buildversion')#line:489
	O0OO0O000O0O00000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:490
	OOOO000000000OOOO =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOO0OO00OO00000OO ).findall (O0OO0O000O0O00000 )#line:491
	if len (OOOO000000000OOOO )>0 :#line:492
		O00O0O00O00OOOO0O =OOOO000000000OOOO [0 ][0 ]#line:493
		OOOOOOO0OOO00O00O =OOOO000000000OOOO [0 ][1 ]#line:494
		OO0OO0OOOO000O00O =OOOO000000000OOOO [0 ][2 ]#line:495
		wiz .setS ('latestversion',O00O0O00O00OOOO0O )#line:496
		if O00O0O00O00OOOO0O >O0OOO0OO000O00OOO :#line:497
			if DISABLEUPDATE =='false':#line:498
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OOO0OO000O00OOO ,O00O0O00O00OOOO0O ),xbmc .LOGNOTICE )#line:499
				notify .updateWindow (OOO0OO00OO00000OO ,O0OOO0OO000O00OOO ,O00O0O00O00OOOO0O ,OOOOOOO0OOO00O00O ,OO0OO0OOOO000O00O )#line:500
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OOO0OO000O00OOO ,O00O0O00O00OOOO0O ),xbmc .LOGNOTICE )#line:501
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OOO0OO000O00OOO ,O00O0O00O00OOOO0O ),xbmc .LOGNOTICE )#line:502
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:503
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:538
if AUTOUPDATE =='Yes':#line:539
	input =(ADDON .getSetting ("autoupdate"))#line:540
	xbmc .executebuiltin ("UpdateLocalAddons")#line:541
	xbmc .executebuiltin ("UpdateAddonRepos")#line:542
	wiz .wizardUpdate ('startup')#line:543
	checkUpdate ()#line:545
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:547
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:551
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:552
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:554
	workingxml =wiz .workingURL (REPOADDONXML )#line:555
	if workingxml ==True :#line:556
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:557
		if len (ver )>0 :#line:558
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:559
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:560
			if workingrepo ==True :#line:561
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:562
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:563
				lib =os .path .join (PACKAGES ,installzip )#line:564
				try :os .remove (lib )#line:565
				except :pass #line:566
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:567
				extract .all (lib ,ADDONS ,DP )#line:568
				try :#line:569
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:570
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:571
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:572
				except :#line:573
					pass #line:574
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:575
				DP .close ()#line:576
				xbmc .sleep (500 )#line:577
				wiz .forceUpdate (True )#line:578
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:579
				xbmc .executebuiltin ("ReloadSkin()")#line:580
				xbmc .executebuiltin ("ActivateWindow(home)")#line:581
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:582
				xbmc .Player ().play (f_play ,windowed =False )#line:583
			else :#line:585
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:586
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:587
		else :#line:588
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:589
	else :#line:590
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:591
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:592
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:593
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:594
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:597
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:598
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:599
	if BUILDNAME =="":#line:600
		try :#line:601
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:602
		except :#line:603
				pass #line:604
	if workingxml ==True :#line:605
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:606
		if len (ver )>0 :#line:607
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:608
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:609
			if workingrepo ==True :#line:610
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:611
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:612
				lib =os .path .join (PACKAGES ,installzip )#line:613
				try :os .remove (lib )#line:614
				except :pass #line:615
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:616
				extract .all (lib ,ADDONS ,DP )#line:617
				try :#line:618
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:619
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:620
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:621
				except :#line:622
					pass #line:623
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:624
				DP .close ()#line:625
				xbmc .sleep (500 )#line:626
				wiz .forceUpdate (True )#line:627
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:628
				xbmc .executebuiltin ("ReloadSkin()")#line:629
				xbmc .executebuiltin ("ActivateWindow(home)")#line:630
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:631
				xbmc .Player ().play (f_play ,windowed =False )#line:632
			else :#line:634
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:635
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:636
		else :#line:637
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:638
	else :#line:639
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:640
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:641
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:644
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:645
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REQUESTSID )):#line:648
	workingxml =wiz .workingURL (REQUESTSXML )#line:649
	if workingxml ==True :#line:651
		ver =wiz .parseDOM (wiz .openURL (REQUESTSXML ),'addon',ret ='version',attrs ={'id':REQUESTSID })#line:652
		if len (ver )>0 :#line:653
			installzip ='%s-%s.zip'%(REQUESTSID ,ver [0 ])#line:654
			workingrepo =wiz .workingURL (REQUESTSURL +installzip )#line:655
			if workingrepo ==True :#line:656
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:658
				lib =os .path .join (PACKAGES ,installzip )#line:659
				try :os .remove (lib )#line:660
				except :pass #line:661
				downloaderbg .download4 (REQUESTSURL +installzip ,lib ,DP2 )#line:662
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:663
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:664
				extract .all2 (lib ,ADDONS ,DP2 )#line:665
				try :#line:666
					f =open (os .path .join (ADDONS ,REQUESTSID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:667
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REQUESTSID })#line:668
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REQUESTSID ,'icon.png'))#line:669
				except :#line:670
					pass #line:671
				if KODIV >=17 :wiz .addonDatabase (REQUESTSID ,1 )#line:672
				DP2 .close ()#line:673
				xbmc .sleep (500 )#line:674
				wiz .forceUpdate (True )#line:675
				wiz .kodi17Fix ()#line:676
def setuname ():#line:680
    OOOO0O0OOO00O00OO =''#line:681
    OOOOO0O0O00OO0O0O =xbmc .Keyboard (OOOO0O0OOO00O00OO ,'הכנס שם משתמש')#line:682
    OOOOO0O0O00OO0O0O .doModal ()#line:683
    if OOOOO0O0O00OO0O0O .isConfirmed ():#line:684
           OOOO0O0OOO00O00OO =OOOOO0O0O00OO0O0O .getText ()#line:685
           wiz .setS ('user',str (OOOO0O0OOO00O00OO ))#line:686
def STARTP2 ():#line:687
	if BUILDNAME ==" Kodi Premium":#line:688
		O0OO0000OO00000O0 =(ADDON .getSetting ("user"))#line:689
		O000O00OO0000O00O =(UNAME )#line:690
		O0OO00O0OO000OO00 =urllib2 .urlopen (O000O00OO0000O00O )#line:691
		O000OO000000000OO =O0OO00O0OO000OO00 .readlines ()#line:692
		OOOOOO0OOOOO0OOOO =0 #line:693
		for O00O00OOOOO0OO0O0 in O000OO000000000OO :#line:694
			if O00O00OOOOO0OO0O0 .split (' ==')[0 ]==O0OO0000OO00000O0 or O00O00OOOOO0OO0O0 .split ()[0 ]==O0OO0000OO00000O0 :#line:695
				OOOOOO0OOOOO0OOOO =1 #line:696
				break #line:697
		if OOOOOO0OOOOO0OOOO ==0 :#line:698
			OO0O000OOO000000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:700
			if OO0O000OOO000000O :#line:702
				ADDON .openSettings ()#line:703
				sys .exit ()#line:704
			else :#line:705
				sys .exit ()#line:706
		return 'ok'#line:710
def skinWIN ():#line:713
	idle ()#line:714
	O000OO0000O00O0O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:715
	OO0OO00OOO0OOOOOO =[];O0000000O0O0OOOO0 =[]#line:716
	for OO00OOO0O000OOO00 in sorted (O000OO0000O00O0O0 ,key =lambda O0000O000OOO00OO0 :O0000O000OOO00OO0 ):#line:717
		OOOO000000OOOOO00 =os .path .split (OO00OOO0O000OOO00 [:-1 ])[1 ]#line:718
		O0OO00OO0O0O0OO00 =os .path .join (OO00OOO0O000OOO00 ,'addon.xml')#line:719
		if os .path .exists (O0OO00OO0O0O0OO00 ):#line:720
			O0OO0O00OOO0OO0OO =open (O0OO00OO0O0O0OO00 )#line:721
			O0O0000O0O000OOOO =O0OO0O00OOO0OO0OO .read ()#line:722
			OO0O0OO000OO00O00 =parseDOM2 (O0O0000O0O000OOOO ,'addon',ret ='id')#line:723
			O00O0O0OOOOOOO0O0 =OOOO000000OOOOO00 if len (OO0O0OO000OO00O00 )==0 else OO0O0OO000OO00O00 [0 ]#line:724
			try :#line:725
				O00O0OO00O0O000OO =xbmcaddon .Addon (id =O00O0O0OOOOOOO0O0 )#line:726
				OO0OO00OOO0OOOOOO .append (O00O0OO00O0O000OO .getAddonInfo ('name'))#line:727
				O0000000O0O0OOOO0 .append (O00O0O0OOOOOOO0O0 )#line:728
			except :#line:729
				pass #line:730
	OO0O00O0OO0OOO0O0 =[];OO0000OO0OOO000OO =0 #line:731
	O00OO0O00OO0OOO0O =["Current Skin -- %s"%currSkin ()]+OO0OO00OOO0OOOOOO #line:732
	OO0000OO0OOO000OO =DIALOG .select ("Select the Skin you want to swap with.",O00OO0O00OO0OOO0O )#line:733
	if OO0000OO0OOO000OO ==-1 :return #line:734
	else :#line:735
		O00OOOO00OOOO000O =(OO0000OO0OOO000OO -1 )#line:736
		OO0O00O0OO0OOO0O0 .append (O00OOOO00OOOO000O )#line:737
		O00OO0O00OO0OOO0O [OO0000OO0OOO000OO ]="%s"%(OO0OO00OOO0OOOOOO [O00OOOO00OOOO000O ])#line:738
	if OO0O00O0OO0OOO0O0 ==None :return #line:739
	for O0OOO0OOO000OOO0O in OO0O00O0OO0OOO0O0 :#line:740
		swapSkins (O0000000O0O0OOOO0 [O0OOO0OOO000OOO0O ])#line:741
def currSkin ():#line:743
	return xbmc .getSkinDir ('Container.PluginName')#line:744
def fix17update ():#line:746
	if KODIV >=17 and KODIV <18 :#line:747
		wiz .kodi17Fix ()#line:748
		xbmc .sleep (4000 )#line:749
		try :#line:750
			OOOO00OOO0O00O00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:751
			O000OOOO0O00O00OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:752
			os .rename (OOOO00OOO0O00O00O ,O000OOOO0O00O00OO )#line:753
		except :#line:754
				pass #line:755
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:756
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:757
		fixfont ()#line:758
		O0O00O00000O000O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:759
		try :#line:761
			O0O00O0000000O0O0 =open (O0O00O00000O000O0 ,'r')#line:762
			O00OOO0O0O0OOO00O =O0O00O0000000O0O0 .read ()#line:763
			O0O00O0000000O0O0 .close ()#line:764
			O0000O00OOO000O00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:765
			OO0OO00OOO0OO0OO0 =re .compile (O0000O00OOO000O00 ).findall (O00OOO0O0O0OOO00O )[0 ]#line:766
			O0O00O0000000O0O0 =open (O0O00O00000O000O0 ,'w')#line:767
			O0O00O0000000O0O0 .write (O00OOO0O0O0OOO00O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0OO00OOO0OO0OO0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:768
			O0O00O0000000O0O0 .close ()#line:769
		except :#line:770
				pass #line:771
		wiz .kodi17Fix ()#line:772
		O0O00O00000O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:773
		try :#line:774
			O0O00O0000000O0O0 =open (O0O00O00000O000O0 ,'r')#line:775
			O00OOO0O0O0OOO00O =O0O00O0000000O0O0 .read ()#line:776
			O0O00O0000000O0O0 .close ()#line:777
			O0000O00OOO000O00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:778
			OO0OO00OOO0OO0OO0 =re .compile (O0000O00OOO000O00 ).findall (O00OOO0O0O0OOO00O )[0 ]#line:779
			O0O00O0000000O0O0 =open (O0O00O00000O000O0 ,'w')#line:780
			O0O00O0000000O0O0 .write (O00OOO0O0O0OOO00O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0OO00OOO0OO0OO0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:781
			O0O00O0000000O0O0 .close ()#line:782
		except :#line:783
				pass #line:784
		swapSkins ('skin.Premium.mod')#line:785
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:786
	os ._exit (1 )#line:787
def fix18update ():#line:788
	if KODIV >=18 :#line:789
		xbmc .sleep (4000 )#line:790
		if BUILDNAME =="":#line:791
			try :#line:792
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:793
			except :#line:794
				pass #line:795
		try :#line:796
			O000OOOO00O000000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:797
			OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:798
			os .rename (O000OOOO00O000000 ,OOO000O0O0O00OO00 )#line:799
		except :#line:800
				pass #line:801
		skindialogsettind18 ()#line:802
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:803
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:804
		fixfont ()#line:805
		O0OO0O0OO00OOO0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:806
		try :#line:807
			O00000O00OOOO00O0 =open (O0OO0O0OO00OOO0O0 ,'r')#line:808
			O00OOOOO000OOOO0O =O00000O00OOOO00O0 .read ()#line:809
			O00000O00OOOO00O0 .close ()#line:810
			O0OO0000O00O00OOO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:811
			OO0O0O0OOO00000O0 =re .compile (O0OO0000O00O00OOO ).findall (O00OOOOO000OOOO0O )[0 ]#line:812
			O00000O00OOOO00O0 =open (O0OO0O0OO00OOO0O0 ,'w')#line:813
			O00000O00OOOO00O0 .write (O00OOOOO000OOOO0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0O0O0OOO00000O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:814
			O00000O00OOOO00O0 .close ()#line:815
		except :#line:816
				pass #line:817
		wiz .kodi17Fix ()#line:818
		O0OO0O0OO00OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:819
		try :#line:820
			O00000O00OOOO00O0 =open (O0OO0O0OO00OOO0O0 ,'r')#line:821
			O00OOOOO000OOOO0O =O00000O00OOOO00O0 .read ()#line:822
			O00000O00OOOO00O0 .close ()#line:823
			O0OO0000O00O00OOO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:824
			OO0O0O0OOO00000O0 =re .compile (O0OO0000O00O00OOO ).findall (O00OOOOO000OOOO0O )[0 ]#line:825
			O00000O00OOOO00O0 =open (O0OO0O0OO00OOO0O0 ,'w')#line:826
			O00000O00OOOO00O0 .write (O00OOOOO000OOOO0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0O0O0OOO00000O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:827
			O00000O00OOOO00O0 .close ()#line:828
		except :#line:829
				pass #line:830
		swapSkins ('skin.Premium.mod')#line:831
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:832
	os ._exit (1 )#line:833
def swapSkins (OOOOO000OO00O0O00 ,title ="Error"):#line:834
	OO00O00OO00000O00 ='lookandfeel.skin'#line:835
	OOO000OO0OOOO0O00 =OOOOO000OO00O0O00 #line:836
	OOO00O00O0O0OO0O0 =getOld (OO00O00OO00000O00 )#line:837
	OOO0O00OO00O0O000 =OO00O00OO00000O00 #line:838
	setNew (OOO0O00OO00O0O000 ,OOO000OO0OOOO0O00 )#line:839
	OO0000O0000O0000O =0 #line:840
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0000O0000O0000O <100 :#line:841
		OO0000O0000O0000O +=1 #line:842
		xbmc .sleep (1 )#line:843
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:844
		xbmc .executebuiltin ('SendClick(11)')#line:845
	return True #line:846
def getOld (O0OOO0OOOO000OOO0 ):#line:848
	try :#line:849
		O0OOO0OOOO000OOO0 ='"%s"'%O0OOO0OOOO000OOO0 #line:850
		OOOO0O00O0OO00O0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOO0OOOO000OOO0 )#line:851
		O00OO00O00O0O0O00 =xbmc .executeJSONRPC (OOOO0O00O0OO00O0O )#line:853
		O00OO00O00O0O0O00 =simplejson .loads (O00OO00O00O0O0O00 )#line:854
		if O00OO00O00O0O0O00 .has_key ('result'):#line:855
			if O00OO00O00O0O0O00 ['result'].has_key ('value'):#line:856
				return O00OO00O00O0O0O00 ['result']['value']#line:857
	except :#line:858
		pass #line:859
	return None #line:860
def setNew (O00OOOOO000O000O0 ,OO000000000OOO000 ):#line:863
	try :#line:864
		O00OOOOO000O000O0 ='"%s"'%O00OOOOO000O000O0 #line:865
		OO000000000OOO000 ='"%s"'%OO000000000OOO000 #line:866
		O000000OOO0O0OO00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00OOOOO000O000O0 ,OO000000000OOO000 )#line:867
		O00O0000OOO00OOO0 =xbmc .executeJSONRPC (O000000OOO0O0OO00 )#line:869
	except :#line:870
		pass #line:871
	return None #line:872
def idle ():#line:873
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:874
def fixfont ():#line:875
	OOO0OO000O0O000OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:876
	O0OO000O0O0O0O00O =json .loads (OOO0OO000O0O000OO );#line:878
	O000OO0O0O0000OO0 =O0OO000O0O0O0O00O ["result"]["settings"]#line:879
	O0OOO00OO0O0O0O0O =[OOOO0O0O0O00OO00O for OOOO0O0O0O00OO00O in O000OO0O0O0000OO0 if OOOO0O0O0O00OO00O ["id"]=="audiooutput.audiodevice"][0 ]#line:881
	O00OO0O0OO0O00OOO =O0OOO00OO0O0O0O0O ["options"];#line:882
	O0000OO00O00O000O =O0OOO00OO0O0O0O0O ["value"];#line:883
	OOOOO000OOOO0OOO0 =[OOO000O000O00OO00 for (OOO000O000O00OO00 ,OO0O0O000OO0OOOO0 )in enumerate (O00OO0O0OO0O00OOO )if OO0O0O000OO0OOOO0 ["value"]==O0000OO00O00O000O ][0 ];#line:885
	OOOO0O00OO0O00OOO =(OOOOO000OOOO0OOO0 +1 )%len (O00OO0O0OO0O00OOO )#line:887
	OO0O00OO0OO000O0O =O00OO0O0OO0O00OOO [OOOO0O00OO0O00OOO ]["value"]#line:889
	O00000OOOOO0OOOO0 =O00OO0O0OO0O00OOO [OOOO0O00OO0O00OOO ]["label"]#line:890
	OOO000O00O00O00OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:892
	try :#line:894
		OOO0OOOOOOO000OOO =json .loads (OOO000O00O00O00OO );#line:895
		if OOO0OOOOOOO000OOO ["result"]!=True :#line:897
			raise Exception #line:898
	except :#line:899
		sys .stderr .write ("Error switching audio output device")#line:900
		raise Exception #line:901
def checkSkin ():#line:904
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:905
	OO0OO0O000O0000O0 =wiz .getS ('defaultskin')#line:906
	O0O000O0OO0000OOO =wiz .getS ('defaultskinname')#line:907
	O000O00O0O0O0OO00 =wiz .getS ('defaultskinignore')#line:908
	O0OOOO00000OO0O0O =False #line:909
	if not OO0OO0O000O0000O0 =='':#line:910
		if os .path .exists (os .path .join (ADDONS ,OO0OO0O000O0000O0 )):#line:911
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O000O0OO0000OOO )):#line:912
				O0OOOO00000OO0O0O =OO0OO0O000O0000O0 #line:913
				OO00OOOO00OOO00O0 =O0O000O0OO0000OOO #line:914
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O0OOOO00000OO0O0O =False #line:915
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OO0OO0O000O0000O0 ='';O0O000O0OO0000OOO =''#line:916
	if OO0OO0O000O0000O0 =='':#line:917
		O0000O0OO00OOOO00 =[]#line:918
		O0O000O0OOO00O000 =[]#line:919
		for OOO000O00O0O0O000 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:920
			O0O00O0OO0O00O0OO ="%s/addon.xml"%OOO000O00O0O0O000 #line:921
			if os .path .exists (O0O00O0OO0O00O0OO ):#line:922
				OO00O0O0OOO0O0O00 =open (O0O00O0OO0O00O0OO ,mode ='r');O00OO0OO0O0OOOOOO =OO00O0O0OOO0O0O00 .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO00O0O0OOO0O0O00 .close ();#line:923
				O0OO00OO000O0O000 =wiz .parseDOM (O00OO0OO0O0OOOOOO ,'addon',ret ='id')#line:924
				OO0OO000OOOOOOO0O =wiz .parseDOM (O00OO0OO0O0OOOOOO ,'addon',ret ='name')#line:925
				wiz .log ("%s: %s"%(OOO000O00O0O0O000 ,str (O0OO00OO000O0O000 [0 ])),xbmc .LOGNOTICE )#line:926
				if len (O0OO00OO000O0O000 )>0 :O0O000O0OOO00O000 .append (str (O0OO00OO000O0O000 [0 ]));O0000O0OO00OOOO00 .append (str (OO0OO000OOOOOOO0O [0 ]))#line:927
				else :wiz .log ("ID not found for %s"%OOO000O00O0O0O000 ,xbmc .LOGNOTICE )#line:928
			else :wiz .log ("ID not found for %s"%OOO000O00O0O0O000 ,xbmc .LOGNOTICE )#line:929
		if len (O0O000O0OOO00O000 )>0 :#line:930
			if len (O0O000O0OOO00O000 )>1 :#line:931
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:932
					O0O00O0OOO00O0O00 =DIALOG .select ("Select skin to switch to!",O0000O0OO00OOOO00 )#line:933
					if O0O00O0OOO00O0O00 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:934
					else :#line:935
						O0OOOO00000OO0O0O =O0O000O0OOO00O000 [O0O00O0OOO00O0O00 ]#line:936
						OO00OOOO00OOO00O0 =O0000O0OO00OOOO00 [O0O00O0OOO00O0O00 ]#line:937
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:938
	if O0OOOO00000OO0O0O :#line:945
		skinSwitch .swapSkins (O0OOOO00000OO0O0O )#line:946
		OO00O0OOO0OO00O0O =0 #line:947
		xbmc .sleep (1000 )#line:948
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00O0OOO0OO00O0O <150 :#line:949
			OO00O0OOO0OO00O0O +=1 #line:950
			xbmc .sleep (200 )#line:951
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:953
			wiz .ebi ('SendClick(11)')#line:954
			wiz .lookandFeelData ('restore')#line:955
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:956
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:957
while xbmc .Player ().isPlayingVideo ():#line:959
	xbmc .sleep (1000 )#line:960
if KODIV >=17 :#line:962
	NOW =datetime .now ()#line:963
	temp =wiz .getS ('kodi17iscrap')#line:964
	if not temp =='':#line:965
		if temp >str (NOW -timedelta (minutes =2 )):#line:966
			wiz .log ("Killing Start Up Script")#line:967
			sys .exit ()#line:968
	wiz .log ("%s"%(NOW ))#line:969
	wiz .setS ('kodi17iscrap',str (NOW ))#line:970
	xbmc .sleep (1000 )#line:971
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:972
		wiz .log ("Killing Start Up Script")#line:973
		sys .exit ()#line:974
	else :#line:975
		wiz .log ("Continuing Start Up Script")#line:976
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:978
path =os .path .split (ADDONPATH )#line:979
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:980
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:981
if KODIADDONS in ADDONPATH :#line:984
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:985
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:986
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:987
	if os .path .exists (newpath ):#line:988
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:989
		wiz .cleanHouse (newpath )#line:990
		wiz .removeFolder (newpath )#line:991
	try :#line:992
		wiz .copytree (ADDONPATH ,newpath )#line:993
	except Exception as e :#line:994
		pass #line:995
	wiz .forceUpdate (True )#line:996
try :#line:998
	mybuilds =xbmc .translatePath (MYBUILDS )#line:999
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:1000
except :#line:1001
	pass #line:1002
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:1004
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:1008
			wiz .kodi17Fix ()#line:1009
			fix18update ()#line:1010
			fix17update ()#line:1011
if INSTALLED =='true':#line:1014
    input =(ADDON .getSetting ("auto_rd"))#line:1015
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:1017
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:1018
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:1019
    wiz .clearS ('install')#line:1020
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1105
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1107
	input =(ADDON .getSetting ("autoupdate"))#line:1108
	STARTP2 ()#line:1109
	if not NOTIFY =='true':#line:1110
		url =wiz .workingURL (NOTIFICATION )#line:1111
		if url ==True :#line:1112
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1113
			if not id ==False :#line:1114
				try :#line:1115
					id =int (id );NOTEID =int (NOTEID )#line:1116
					if id ==NOTEID :#line:1117
						if NOTEDISMISS =='false':#line:1118
							debridit .debridIt ('update','all')#line:1119
							traktit .traktIt ('update','all')#line:1120
							checkidupdate ()#line:1121
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1122
					elif id >NOTEID :#line:1123
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1124
						wiz .setS ('noteid',str (id ))#line:1125
						wiz .setS ('notedismiss','false')#line:1126
						if input =='true':#line:1127
							debridit .debridIt ('update','all')#line:1128
							traktit .traktIt ('update','all')#line:1129
							checkidupdate ()#line:1130
						else :notify .notification (msg =msg )#line:1131
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1132
				except Exception as e :#line:1133
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1134
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1135
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1136
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1137
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1138
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1140
if ENABLE =='Yes':#line:1141
	if not NOTIFY2 =='true':#line:1142
		url =wiz .workingURL (NOTIFICATION2 )#line:1143
		if url ==True :#line:1144
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1145
			if not id ==False :#line:1146
				try :#line:1147
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1148
					if id ==NOTEID2 :#line:1149
						if NOTEDISMISS2 =='false':#line:1150
							checkvictory ()#line:1151
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1152
					elif id >NOTEID2 :#line:1153
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1154
						wiz .setS ('noteid2',str (id ))#line:1155
						wiz .setS ('notedismiss2','false')#line:1156
						checkvictory ()#line:1157
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1158
				except Exception as e :#line:1159
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1160
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1161
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1162
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1163
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1164
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1166
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1167
	if not NOTIFY3 =='true':#line:1168
		url =wiz .workingURL (NOTIFICATION3 )#line:1169
		if url ==True :#line:1170
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1171
			if not id ==False :#line:1172
				try :#line:1173
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1174
					if id ==NOTEID3 :#line:1175
						if NOTEDISMISS3 =='false':#line:1176
							notify .notification3 (msg )#line:1177
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1178
					elif id >NOTEID3 :#line:1179
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1180
						wiz .setS ('noteid3',str (id ))#line:1181
						wiz .setS ('notedismiss3','false')#line:1182
						notify .notification3 (msg =msg )#line:1183
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1184
				except Exception as e :#line:1185
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1186
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1187
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1188
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1189
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1190
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1191
if KEEPTRAKT =='true':#line:1192
	if TRAKTSAVE <=str (TODAY ):#line:1193
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1194
		traktit .autoUpdate ('all')#line:1195
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1196
	else :#line:1197
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1198
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1199
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1201
if KEEPREAL =='true':#line:1202
	if REALSAVE <=str (TODAY ):#line:1203
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1204
		debridit .autoUpdate ('all')#line:1205
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1206
	else :#line:1207
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1208
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1209
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1211
if KEEPLOGIN =='true':#line:1212
	if LOGINSAVE <=str (TODAY ):#line:1213
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1214
		loginit .autoUpdate ('all')#line:1215
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1216
	else :#line:1217
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1218
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1219
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1221
if AUTOCLEANUP =='true':#line:1222
	service =False #line:1223
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1224
	feq =int (float (AUTOFEQ ))#line:1225
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1226
		service =True #line:1227
		next_run =days [feq ]#line:1228
		wiz .setS ('nextautocleanup',str (next_run ))#line:1229
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1230
	if service ==True :#line:1231
		AUTOCACHE =wiz .getS ('clearcache')#line:1232
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1233
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1234
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1235
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1236
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1237
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1238
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1239
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1240
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1241
wiz .setS ('kodi17iscrap','')#line:1243
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1312
	count =0 #line:1313
	for f in filenames :#line:1314
		count +=1 #line:1315
		fp =os .path .join (dirpath ,f )#line:1316
		total_size +=os .path .getsize (fp )#line:1317
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1318
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1325
	for f2 in filenames2 :#line:1326
		fp2 =os .path .join (dirpath2 ,f2 )#line:1327
		total_size2 +=os .path .getsize (fp2 )#line:1328
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1329
if int (total_sizetext2 )>filesize_thumb :#line:1331
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1332
	if choice2 ==1 :#line:1333
		maintenance .deleteThumbnails ()#line:1334
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1336
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1337
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1339
time .sleep (3 )#line:1340
if not os .path .exists (os .path .join (ADDONDATA ,'4.2.0'))and not BUILDNAME =="":#line:1342
        display_Votes ()#line:1343
        file =open (os .path .join (ADDONDATA ,'4.2.0'),'w')#line:1345
        file .write (str ('Done'))#line:1347
        file .close ()#line:1348
tele =(ADDON .getSetting ("auto_tele"))#line:1353
if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:1355
    if tele =='true':#line:1357
        xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)")#line:1358
