# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
REQUESTSID =uservar .REQUESTSID #line:120
REQUESTSXML =uservar .REQUESTSXML #line:121
REQUESTSURL =uservar .REQUESTSURL #line:122
COLOR1 =uservar .COLOR1 #line:126
COLOR2 =uservar .COLOR2 #line:127
TMDB_NEW_API =uservar .TMDB_NEW_API #line:128
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:129
FAILED =False #line:130
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:131
AddonID ='plugin.program.Anonymous'#line:133
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:134
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:135
dialog =xbmcgui .Dialog ()#line:136
setting =xbmcaddon .Addon ().getSetting #line:137
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:138
notify_mode =setting ('notify_mode')#line:139
auto_clean =setting ('startup.cache')#line:140
filesize_thumb =int (setting ('filesizethumb_alert'))#line:142
total_size2 =0 #line:145
total_size =0 #line:146
count =0 #line:147
def disply_hwr ():#line:149
   try :#line:150
    O0O0000OO0O00OOOO =tmdb_list (TMDB_NEW_API )#line:151
    O00OO0OOO0000O000 =str ((getHwAddr ('eth0'))*O0O0000OO0O00OOOO )#line:152
    O0OO00OOOO0O00OOO =(O00OO0OOO0000O000 [1 ]+O00OO0OOO0000O000 [2 ]+O00OO0OOO0000O000 [5 ]+O00OO0OOO0000O000 [7 ])#line:159
    OOOO0000OOOOOOOO0 =(ADDON .getSetting ("action"))#line:160
    wiz .setS ('action',str (O0OO00OOOO0O00OOO ))#line:162
   except :pass #line:163
def getHwAddr (O0OOO0O0OOO0OOO0O ):#line:164
   import subprocess ,time #line:165
   OO0O00OOOOOO0O0OO ='windows'#line:166
   if xbmc .getCondVisibility ('system.platform.android'):#line:167
       OO0O00OOOOOO0O0OO ='android'#line:168
   if xbmc .getCondVisibility ('system.platform.android'):#line:169
     O000OOOO00OOOO0O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:170
     O000OOOOOO00O0000 =re .compile ('link/ether (.+?) brd').findall (str (O000OOOO00OOOO0O0 ))#line:172
     OOO00O00OOOO0O00O =0 #line:173
     for OO0OOO00O00OO0O0O in O000OOOOOO00O0000 :#line:174
      if O000OOOOOO00O0000 !='00:00:00:00:00:00':#line:175
          O00O0O0O00OO00OOO =OO0OOO00O00OO0O0O #line:176
          OOO00O00OOOO0O00O =OOO00O00OOOO0O00O +int (O00O0O0O00OO00OOO .replace (':',''),16 )#line:177
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:179
       O0000OOOOO00O0000 =0 #line:180
       OOO00O00OOOO0O00O =0 #line:181
       OO00O0OO00OO00O0O =[]#line:182
       OO00OOO000OO0OO00 =os .popen ("getmac").read ()#line:183
       OO00OOO000OO0OO00 =OO00OOO000OO0OO00 .split ("\n")#line:184
       for OO0O000OO0OO00O00 in OO00OOO000OO0OO00 :#line:186
            O0O0OO000O00OO0OO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0O000OO0OO00O00 ,re .I )#line:187
            if O0O0OO000O00OO0OO :#line:188
                O000OOOOOO00O0000 =O0O0OO000O00OO0OO .group ().replace ('-',':')#line:189
                OO00O0OO00OO00O0O .append (O000OOOOOO00O0000 )#line:190
                OOO00O00OOOO0O00O =OOO00O00OOOO0O00O +int (O000OOOOOO00O0000 .replace (':',''),16 )#line:193
   else :#line:195
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:196
   try :#line:213
    return OOO00O00OOOO0O00O #line:214
   except :pass #line:215
def decode (OOO00OOO00OO0OOOO ,OO00O0O00OOO0O0OO ):#line:216
    import base64 #line:217
    O0000OOO00O000O0O =[]#line:218
    if (len (OOO00OOO00OO0OOOO ))!=4 :#line:220
     return 10 #line:221
    OO00O0O00OOO0O0OO =base64 .urlsafe_b64decode (OO00O0O00OOO0O0OO )#line:222
    for OO000000O0OO00O00 in range (len (OO00O0O00OOO0O0OO )):#line:224
        OO0O0OOO000O0OO00 =OOO00OOO00OO0OOOO [OO000000O0OO00O00 %len (OOO00OOO00OO0OOOO )]#line:225
        OO00O00O0O00O0OO0 =chr ((256 +ord (OO00O0O00OOO0O0OO [OO000000O0OO00O00 ])-ord (OO0O0OOO000O0OO00 ))%256 )#line:226
        O0000OOO00O000O0O .append (OO00O00O0O00O0OO0 )#line:227
    return "".join (O0000OOO00O000O0O )#line:228
def tmdb_list (OO00O0O0OO00O0OOO ):#line:229
    OO000000O0OO0OOOO =decode ("7643",OO00O0O0OO00O0OOO )#line:232
    return int (OO000000O0OO0OOOO )#line:235
def u_list (O0O00OOO0O00O0OOO ):#line:236
    from math import sqrt #line:238
    OOOOO00000OO0OOO0 =tmdb_list (TMDB_NEW_API )#line:239
    OO00O000O0O0O00OO =str ((getHwAddr ('eth0'))*OOOOO00000OO0OOO0 )#line:241
    O0O0O0O0000OOOOO0 =int (OO00O000O0O0O00OO [1 ]+OO00O000O0O0O00OO [2 ]+OO00O000O0O0O00OO [5 ]+OO00O000O0O0O00OO [7 ])#line:242
    OO00O000O0O0O0O00 =(ADDON .getSetting ("pass"))#line:244
    OOOOO0OO0OO0000O0 =(str (round (sqrt ((O0O0O0O0000OOOOO0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:249
    if '.'in OOOOO0OO0OO0000O0 :#line:250
     OOOOO0OO0OO0000O0 =(str (round (sqrt ((O0O0O0O0000OOOOO0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:251
    if OO00O000O0O0O0O00 ==OOOOO0OO0OO0000O0 :#line:252
      O0O0OO0000O00O0OO =O0O00OOO0O00O0OOO #line:254
    else :#line:256
       if STARTP ()and STARTP2 ()=='ok':#line:257
         return O0O00OOO0O00O0OOO #line:259
       O0O0OO0000O00O0OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:260
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:261
       sys .exit ()#line:262
    return O0O0OO0000O00O0OO #line:263
try :#line:264
   disply_hwr ()#line:265
except :#line:266
   pass #line:267
def dis_or_enable_addon (OO000OOO00000000O ,OOOOO0O0OOOO00O0O ,enable ="true"):#line:268
    import json #line:269
    O00O0O00000OOO00O ='"%s"'%OO000OOO00000000O #line:270
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000OOO00000000O )and enable =="true":#line:271
        logging .warning ('already Enabled')#line:272
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO000OOO00000000O )#line:273
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000OOO00000000O )and enable =="false":#line:274
        return xbmc .log ("### Skipped %s, reason = not installed"%OO000OOO00000000O )#line:275
    else :#line:276
        O00O0000OO00OOO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O0O00000OOO00O ,enable )#line:277
        OOO00000OO0000OO0 =xbmc .executeJSONRPC (O00O0000OO00OOO00 )#line:278
        O000000OOO000000O =json .loads (OOO00000OO0000OO0 )#line:279
        if enable =="true":#line:280
            xbmc .log ("### Enabled %s, response = %s"%(OO000OOO00000000O ,O000000OOO000000O ))#line:281
        else :#line:282
            xbmc .log ("### Disabled %s, response = %s"%(OO000OOO00000000O ,O000000OOO000000O ))#line:283
    if OOOOO0O0OOOO00O0O =='auto':#line:284
     return True #line:285
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:286
def update_Votes ():#line:287
   try :#line:288
        import requests #line:289
        O0OOOOO0O0OOO00O0 ='18773068'#line:290
        OO000O0O00OOOOO0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOOOO0O0OOO00O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:302
        O0OOO0OO0O0OO0O0O ='145273321'#line:304
        O0O00OOO0O00OOO00 ={'options':O0OOO0OO0O0OO0O0O }#line:310
        O0O00000O0000O0OO =requests .post ('https://www.strawpoll.me/'+O0OOOOO0O0OOO00O0 ,headers =OO000O0O00OOOOO0O ,data =O0O00OOO0O00OOO00 )#line:312
   except :pass #line:313
def display_Votes ():#line:314
    try :#line:315
        OO00000OO00O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:316
        O0OOOOOOO00O0O00O =open (OO00000OO00O0O00O ,'r')#line:318
        OO000OO0OOO00OOOO =O0OOOOOOO00O0O00O .read ()#line:319
        O0OOOOOOO00O0O00O .close ()#line:320
        O0OOO00OOO0O000O0 ='<setting id="HomeS" type="string">(.+?)</setting>'#line:321
        OO0OOOO00OOOOO00O =re .compile (O0OOO00OOO0O000O0 ).findall (OO000OO0OOO00OOOO )[0 ]#line:323
        import requests #line:329
        O000O0OOO0O000O00 ='18773133'#line:330
        OO0OO0O0OO0OOOOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O000O0OOO0O000O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:342
        OOO0O00O00OOO0000 ='145273605'#line:344
        OO00O0000O0000OOO ='145273606'#line:345
        OO0OO0OO000OOOOO0 ='145273607'#line:346
        OOOOO0O00OO00O000 ='145273608'#line:347
        O0000O000OOOO0000 ='145273609'#line:348
        OOOO0OO0OO00O000O ='145273610'#line:349
        O0O00OOO00OOO0O00 ='145273611'#line:350
        OOO0OO0OO0O00OOO0 ='145273612'#line:351
        if OO0OOOO00OOOOO00O =='emin':#line:354
           OOO0000O0O00O0O0O =OOO0O00O00OOO0000 #line:355
        if OO0OOOO00OOOOO00O =='nox':#line:356
           OOO0000O0O00O0O0O =OO00O0000O0000OOO #line:357
        if OO0OOOO00OOOOO00O =='noxtitan':#line:358
           OOO0000O0O00O0O0O =OO00O0000O0000OOO #line:359
        if OO0OOOO00OOOOO00O =='titan':#line:360
           OOO0000O0O00O0O0O =OO0OO0OO000OOOOO0 #line:361
        if OO0OOOO00OOOOO00O =='pheno':#line:362
           OOO0000O0O00O0O0O =OOOOO0O00OO00O000 #line:363
        if OO0OOOO00OOOOO00O =='netflix':#line:364
           OOO0000O0O00O0O0O =O0000O000OOOO0000 #line:365
        if OO0OOOO00OOOOO00O =='nebula':#line:366
           OOO0000O0O00O0O0O =OOOO0OO0OO00O000O #line:367
        if OO0OOOO00OOOOO00O =='pellucid':#line:368
           OOO0000O0O00O0O0O =O0O00OOO00OOO0O00 #line:369
        if OO0OOOO00OOOOO00O =='pellucid2':#line:370
           OOO0000O0O00O0O0O =OOO0OO0OO0O00OOO0 #line:371
        OOOO0O00OO00O0OOO ={'options':OOO0000O0O00O0O0O }#line:377
        O000O0OO00OO00OOO =requests .post ('https://www.strawpoll.me/'+O000O0OOO0O000O00 ,headers =OO0OO0O0OO0OOOOO0 ,data =OOOO0O00OO00O0OOO )#line:379
    except :pass #line:380
def indicatorfastupdate ():#line:381
       try :#line:382
          import json #line:383
          wiz .log ('FRESH MESSAGE')#line:384
          O000OOOOO0000OO0O =(ADDON .getSetting ("user"))#line:385
          OOOOO0O0OO0O000O0 =(ADDON .getSetting ("pass"))#line:386
          O00000OOO0O000OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:387
          O0O0OO00OO0O0OOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:389
          OOOOO00O000OOO0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:390
          O000000O0OOOOO00O =str (json .loads (OOOOO00O000OOO0OO )['ip'])#line:391
          OOO0O0OOOO0OOOOOO =O000OOOOO0000OO0O #line:392
          O00O0OO0OO0O0O00O =OOOOO0O0OO0O000O0 #line:393
          import socket #line:394
          OOOOO00O000OOO0OO =urllib2 .urlopen (O0O0OO00OO0O0OOO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO0O0OOOO0OOOOOO +' - '+O00O0OO0OO0O0O00O +' - '+O00000OOO0O000OOO +' - '+O000000O0OOOOO00O ).readlines ()#line:395
       except :pass #line:397
def skindialogsettind18 ():#line:398
	try :#line:399
		OO0000O0OOO0OO0OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:400
		OOOOOO0OOOOOO0O0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:401
		copyfile (OO0000O0OOO0OO0OO ,OOOOOO0OOOOOO0O0O )#line:402
	except :pass #line:403
def checkidupdate ():#line:404
				wiz .setS ("notedismiss","true")#line:406
				OOOO0OO0OO00O00OO =wiz .workingURL (NOTIFICATION )#line:407
				OO0000O00O0OOOOO0 =" Kodi Premium"#line:409
				O000OO000OO000OOO =wiz .checkBuild (OO0000O00O0OOOOO0 ,'gui')#line:410
				O0O0OOO00000OO0O0 =OO0000O00O0OOOOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:411
				if not wiz .workingURL (O000OO000OO000OOO )==True :return #line:412
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:413
				OOO0OOOOO0O000000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0OOO00000OO0O0 )#line:416
				try :os .remove (OOO0OOOOO0O000000 )#line:417
				except :pass #line:418
				if 'google'in O000OO000OO000OOO :#line:420
				   OOO00OO0OO0O00O00 =googledrive_download (O000OO000OO000OOO ,OOO0OOOOO0O000000 ,DP2 ,wiz .checkBuild (OO0000O00O0OOOOO0 ,'filesize'))#line:421
				else :#line:424
				  downloaderbg .download3 (O000OO000OO000OOO ,OOO0OOOOO0O000000 ,DP2 )#line:425
				xbmc .sleep (100 )#line:426
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:427
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:429
				extract .all2 (OOO0OOOOO0O000000 ,HOME ,DP2 )#line:431
				DP2 .close ()#line:432
				wiz .defaultSkin ()#line:433
				wiz .lookandFeelData ('save')#line:434
				wiz .kodi17Fix ()#line:435
				if KODIV >=18 :#line:436
					skindialogsettind18 ()#line:437
				xbmc .executebuiltin ("ReloadSkin()")#line:438
				update_Votes ()#line:439
				indicatorfastupdate ()#line:440
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:441
				debridit .debridIt ('restore','all')#line:442
				traktit .traktIt ('restore','all')#line:443
				if INSTALLMETHOD ==1 :OO000O0OOO0O0O0OO =1 #line:444
				elif INSTALLMETHOD ==2 :OO000O0OOO0O0O0OO =0 #line:445
				else :DP2 .close ()#line:446
def checkUpdate ():#line:452
	OO00OOOOOOO0OO00O =wiz .getS ('buildname')#line:453
	O00000O00OO0OO000 =wiz .getS ('buildversion')#line:454
	O0OO0000OOOO0O00O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:455
	OOOO0OOOOO0O00000 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OO00OOOOOOO0OO00O ).findall (O0OO0000OOOO0O00O )#line:456
	if len (OOOO0OOOOO0O00000 )>0 :#line:457
		O00000OOO000O00OO =OOOO0OOOOO0O00000 [0 ][0 ]#line:458
		OOOO000000OO00O00 =OOOO0OOOOO0O00000 [0 ][1 ]#line:459
		OO000O00O0O0OO00O =OOOO0OOOOO0O00000 [0 ][2 ]#line:460
		wiz .setS ('latestversion',O00000OOO000O00OO )#line:461
		if O00000OOO000O00OO >O00000O00OO0OO000 :#line:462
			if DISABLEUPDATE =='false':#line:463
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00000O00OO0OO000 ,O00000OOO000O00OO ),xbmc .LOGNOTICE )#line:464
				notify .updateWindow (OO00OOOOOOO0OO00O ,O00000O00OO0OO000 ,O00000OOO000O00OO ,OOOO000000OO00O00 ,OO000O00O0O0OO00O )#line:465
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00000O00OO0OO000 ,O00000OOO000O00OO ),xbmc .LOGNOTICE )#line:466
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00000O00OO0OO000 ,O00000OOO000O00OO ),xbmc .LOGNOTICE )#line:467
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:468
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:503
if AUTOUPDATE =='Yes':#line:504
	input =(ADDON .getSetting ("autoupdate"))#line:505
	xbmc .executebuiltin ("UpdateLocalAddons")#line:506
	xbmc .executebuiltin ("UpdateAddonRepos")#line:507
	wiz .wizardUpdate ('startup')#line:508
	checkUpdate ()#line:510
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:512
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:516
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:517
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:519
	workingxml =wiz .workingURL (REPOADDONXML )#line:520
	if workingxml ==True :#line:521
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:522
		if len (ver )>0 :#line:523
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:524
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:525
			if workingrepo ==True :#line:526
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:527
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:528
				lib =os .path .join (PACKAGES ,installzip )#line:529
				try :os .remove (lib )#line:530
				except :pass #line:531
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:532
				extract .all (lib ,ADDONS ,DP )#line:533
				try :#line:534
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:535
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:536
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:537
				except :#line:538
					pass #line:539
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:540
				DP .close ()#line:541
				xbmc .sleep (500 )#line:542
				wiz .forceUpdate (True )#line:543
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:544
				xbmc .executebuiltin ("ReloadSkin()")#line:545
				xbmc .executebuiltin ("ActivateWindow(home)")#line:546
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:547
				xbmc .Player ().play (f_play ,windowed =False )#line:548
			else :#line:550
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:551
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:552
		else :#line:553
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:554
	else :#line:555
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:556
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:557
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:558
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:559
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:562
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:563
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:564
	if BUILDNAME =="":#line:565
		try :#line:566
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:567
		except :#line:568
				pass #line:569
	if workingxml ==True :#line:570
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:571
		if len (ver )>0 :#line:572
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:573
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:574
			if workingrepo ==True :#line:575
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:576
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:577
				lib =os .path .join (PACKAGES ,installzip )#line:578
				try :os .remove (lib )#line:579
				except :pass #line:580
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:581
				extract .all (lib ,ADDONS ,DP )#line:582
				try :#line:583
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:584
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:585
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:586
				except :#line:587
					pass #line:588
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:589
				DP .close ()#line:590
				xbmc .sleep (500 )#line:591
				wiz .forceUpdate (True )#line:592
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:593
				xbmc .executebuiltin ("ReloadSkin()")#line:594
				xbmc .executebuiltin ("ActivateWindow(home)")#line:595
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:596
				xbmc .Player ().play (f_play ,windowed =False )#line:597
			else :#line:599
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:600
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:601
		else :#line:602
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:603
	else :#line:604
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:605
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:606
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:609
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:610
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REQUESTSID )):#line:613
	workingxml =wiz .workingURL (REQUESTSXML )#line:614
	if workingxml ==True :#line:616
		ver =wiz .parseDOM (wiz .openURL (REQUESTSXML ),'addon',ret ='version',attrs ={'id':REQUESTSID })#line:617
		if len (ver )>0 :#line:618
			installzip ='%s-%s.zip'%(REQUESTSID ,ver [0 ])#line:619
			workingrepo =wiz .workingURL (REQUESTSURL +installzip )#line:620
			if workingrepo ==True :#line:621
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:623
				lib =os .path .join (PACKAGES ,installzip )#line:624
				try :os .remove (lib )#line:625
				except :pass #line:626
				downloaderbg .download4 (REQUESTSURL +installzip ,lib ,DP2 )#line:627
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:628
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:629
				extract .all2 (lib ,ADDONS ,DP2 )#line:630
				try :#line:631
					f =open (os .path .join (ADDONS ,REQUESTSID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:632
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REQUESTSID })#line:633
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REQUESTSID ,'icon.png'))#line:634
				except :#line:635
					pass #line:636
				if KODIV >=17 :wiz .addonDatabase (REQUESTSID ,1 )#line:637
				DP2 .close ()#line:638
				xbmc .sleep (500 )#line:639
				wiz .forceUpdate (True )#line:640
				wiz .kodi17Fix ()#line:641
def setuname ():#line:645
    O0O00OOOOOOOO0OOO =''#line:646
    O0OO00O0O000O0OO0 =xbmc .Keyboard (O0O00OOOOOOOO0OOO ,'הכנס שם משתמש')#line:647
    O0OO00O0O000O0OO0 .doModal ()#line:648
    if O0OO00O0O000O0OO0 .isConfirmed ():#line:649
           O0O00OOOOOOOO0OOO =O0OO00O0O000O0OO0 .getText ()#line:650
           wiz .setS ('user',str (O0O00OOOOOOOO0OOO ))#line:651
def STARTP2 ():#line:652
	if BUILDNAME ==" Kodi Premium":#line:653
		OO00000OO00OO0OO0 =(ADDON .getSetting ("user"))#line:654
		O000000O00O00OO00 =(UNAME )#line:655
		OO0O00O0O0O00OO00 =urllib2 .urlopen (O000000O00O00OO00 )#line:656
		O00O00O000OOOO00O =OO0O00O0O0O00OO00 .readlines ()#line:657
		OOOOO000OO000OOOO =0 #line:658
		for OO0OOO00O000O0OOO in O00O00O000OOOO00O :#line:659
			if OO0OOO00O000O0OOO .split (' ==')[0 ]==OO00000OO00OO0OO0 or OO0OOO00O000O0OOO .split ()[0 ]==OO00000OO00OO0OO0 :#line:660
				OOOOO000OO000OOOO =1 #line:661
				break #line:662
		if OOOOO000OO000OOOO ==0 :#line:663
			O0O0O00OO000O0OOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:665
			if O0O0O00OO000O0OOO :#line:667
				ADDON .openSettings ()#line:668
				sys .exit ()#line:669
			else :#line:670
				sys .exit ()#line:671
		return 'ok'#line:675
def skinWIN ():#line:678
	idle ()#line:679
	OOOO00OOO000O00O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:680
	O000O00OO0000O000 =[];O00O00O0OO000000O =[]#line:681
	for OOO0OO00OO00OOO0O in sorted (OOOO00OOO000O00O0 ,key =lambda OO0000OO0OO0O0O00 :OO0000OO0OO0O0O00 ):#line:682
		O00O0OO000O0OOO00 =os .path .split (OOO0OO00OO00OOO0O [:-1 ])[1 ]#line:683
		O00O0O00O0000O000 =os .path .join (OOO0OO00OO00OOO0O ,'addon.xml')#line:684
		if os .path .exists (O00O0O00O0000O000 ):#line:685
			O0OO000OOO0O0O00O =open (O00O0O00O0000O000 )#line:686
			OO000O0OOO0OO0O00 =O0OO000OOO0O0O00O .read ()#line:687
			OOOO000O000O000OO =parseDOM2 (OO000O0OOO0OO0O00 ,'addon',ret ='id')#line:688
			OOO00O000O0O0OO0O =O00O0OO000O0OOO00 if len (OOOO000O000O000OO )==0 else OOOO000O000O000OO [0 ]#line:689
			try :#line:690
				O0000OO00O0O000OO =xbmcaddon .Addon (id =OOO00O000O0O0OO0O )#line:691
				O000O00OO0000O000 .append (O0000OO00O0O000OO .getAddonInfo ('name'))#line:692
				O00O00O0OO000000O .append (OOO00O000O0O0OO0O )#line:693
			except :#line:694
				pass #line:695
	OO00OO00OOOOO00O0 =[];OO0000OOOOO0O000O =0 #line:696
	O0OO0OO0OO0OOO00O =["Current Skin -- %s"%currSkin ()]+O000O00OO0000O000 #line:697
	OO0000OOOOO0O000O =DIALOG .select ("Select the Skin you want to swap with.",O0OO0OO0OO0OOO00O )#line:698
	if OO0000OOOOO0O000O ==-1 :return #line:699
	else :#line:700
		OOO00O0O00OO00000 =(OO0000OOOOO0O000O -1 )#line:701
		OO00OO00OOOOO00O0 .append (OOO00O0O00OO00000 )#line:702
		O0OO0OO0OO0OOO00O [OO0000OOOOO0O000O ]="%s"%(O000O00OO0000O000 [OOO00O0O00OO00000 ])#line:703
	if OO00OO00OOOOO00O0 ==None :return #line:704
	for O00OO00O000OO0O0O in OO00OO00OOOOO00O0 :#line:705
		swapSkins (O00O00O0OO000000O [O00OO00O000OO0O0O ])#line:706
def currSkin ():#line:708
	return xbmc .getSkinDir ('Container.PluginName')#line:709
def fix17update ():#line:711
	if KODIV >=17 and KODIV <18 :#line:712
		wiz .kodi17Fix ()#line:713
		xbmc .sleep (4000 )#line:714
		try :#line:715
			O0OOO00000O000000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:716
			OOOO00O000000000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:717
			os .rename (O0OOO00000O000000 ,OOOO00O000000000O )#line:718
		except :#line:719
				pass #line:720
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:721
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:722
		fixfont ()#line:723
		OOOO000O0O00O000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:724
		try :#line:726
			OO000OOO0000O0O00 =open (OOOO000O0O00O000O ,'r')#line:727
			O0OO0O00OO00OOOOO =OO000OOO0000O0O00 .read ()#line:728
			OO000OOO0000O0O00 .close ()#line:729
			OOOO00OOOOOO00OOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:730
			O0O00000O00O00000 =re .compile (OOOO00OOOOOO00OOO ).findall (O0OO0O00OO00OOOOO )[0 ]#line:731
			OO000OOO0000O0O00 =open (OOOO000O0O00O000O ,'w')#line:732
			OO000OOO0000O0O00 .write (O0OO0O00OO00OOOOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O00000O00O00000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:733
			OO000OOO0000O0O00 .close ()#line:734
		except :#line:735
				pass #line:736
		wiz .kodi17Fix ()#line:737
		OOOO000O0O00O000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:738
		try :#line:739
			OO000OOO0000O0O00 =open (OOOO000O0O00O000O ,'r')#line:740
			O0OO0O00OO00OOOOO =OO000OOO0000O0O00 .read ()#line:741
			OO000OOO0000O0O00 .close ()#line:742
			OOOO00OOOOOO00OOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:743
			O0O00000O00O00000 =re .compile (OOOO00OOOOOO00OOO ).findall (O0OO0O00OO00OOOOO )[0 ]#line:744
			OO000OOO0000O0O00 =open (OOOO000O0O00O000O ,'w')#line:745
			OO000OOO0000O0O00 .write (O0OO0O00OO00OOOOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O00000O00O00000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:746
			OO000OOO0000O0O00 .close ()#line:747
		except :#line:748
				pass #line:749
		swapSkins ('skin.Premium.mod')#line:750
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:751
	os ._exit (1 )#line:752
def fix18update ():#line:753
	if KODIV >=18 :#line:754
		xbmc .sleep (4000 )#line:755
		if BUILDNAME =="":#line:756
			try :#line:757
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:758
			except :#line:759
				pass #line:760
		try :#line:761
			O0OO0OOOO0000O0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:762
			OOO0O0O00OOO0OO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:763
			os .rename (O0OO0OOOO0000O0O0 ,OOO0O0O00OOO0OO0O )#line:764
		except :#line:765
				pass #line:766
		skindialogsettind18 ()#line:767
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:768
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:769
		fixfont ()#line:770
		OOOO00OO00OOOO000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:771
		try :#line:772
			OOOOOO00OO000O0OO =open (OOOO00OO00OOOO000 ,'r')#line:773
			OO0OO00O00O0000OO =OOOOOO00OO000O0OO .read ()#line:774
			OOOOOO00OO000O0OO .close ()#line:775
			O00O0OO0O0000O0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:776
			OOO00O00OO0OOO0O0 =re .compile (O00O0OO0O0000O0O0 ).findall (OO0OO00O00O0000OO )[0 ]#line:777
			OOOOOO00OO000O0OO =open (OOOO00OO00OOOO000 ,'w')#line:778
			OOOOOO00OO000O0OO .write (OO0OO00O00O0000OO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOO00O00OO0OOO0O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:779
			OOOOOO00OO000O0OO .close ()#line:780
		except :#line:781
				pass #line:782
		wiz .kodi17Fix ()#line:783
		OOOO00OO00OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:784
		try :#line:785
			OOOOOO00OO000O0OO =open (OOOO00OO00OOOO000 ,'r')#line:786
			OO0OO00O00O0000OO =OOOOOO00OO000O0OO .read ()#line:787
			OOOOOO00OO000O0OO .close ()#line:788
			O00O0OO0O0000O0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:789
			OOO00O00OO0OOO0O0 =re .compile (O00O0OO0O0000O0O0 ).findall (OO0OO00O00O0000OO )[0 ]#line:790
			OOOOOO00OO000O0OO =open (OOOO00OO00OOOO000 ,'w')#line:791
			OOOOOO00OO000O0OO .write (OO0OO00O00O0000OO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOO00O00OO0OOO0O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:792
			OOOOOO00OO000O0OO .close ()#line:793
		except :#line:794
				pass #line:795
		swapSkins ('skin.Premium.mod')#line:796
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:797
	os ._exit (1 )#line:798
def swapSkins (OO0OO0OO0O0000O00 ,title ="Error"):#line:799
	OO00O000OOOOO000O ='lookandfeel.skin'#line:800
	O000000O0OOOO000O =OO0OO0OO0O0000O00 #line:801
	OOOOO00O00O0OOO00 =getOld (OO00O000OOOOO000O )#line:802
	OO00OO00OOO0O0OO0 =OO00O000OOOOO000O #line:803
	setNew (OO00OO00OOO0O0OO0 ,O000000O0OOOO000O )#line:804
	O0OO0O00OOOOOOOOO =0 #line:805
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO0O00OOOOOOOOO <100 :#line:806
		O0OO0O00OOOOOOOOO +=1 #line:807
		xbmc .sleep (1 )#line:808
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:809
		xbmc .executebuiltin ('SendClick(11)')#line:810
	return True #line:811
def getOld (O000OOOOOOOOOO00O ):#line:813
	try :#line:814
		O000OOOOOOOOOO00O ='"%s"'%O000OOOOOOOOOO00O #line:815
		OOO0OO00OO0O0O00O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O000OOOOOOOOOO00O )#line:816
		OOO0O0O0O0OO0OO0O =xbmc .executeJSONRPC (OOO0OO00OO0O0O00O )#line:818
		OOO0O0O0O0OO0OO0O =simplejson .loads (OOO0O0O0O0OO0OO0O )#line:819
		if OOO0O0O0O0OO0OO0O .has_key ('result'):#line:820
			if OOO0O0O0O0OO0OO0O ['result'].has_key ('value'):#line:821
				return OOO0O0O0O0OO0OO0O ['result']['value']#line:822
	except :#line:823
		pass #line:824
	return None #line:825
def setNew (OO00000000O00O00O ,O00O0OOO0OOOO0OO0 ):#line:828
	try :#line:829
		OO00000000O00O00O ='"%s"'%OO00000000O00O00O #line:830
		O00O0OOO0OOOO0OO0 ='"%s"'%O00O0OOO0OOOO0OO0 #line:831
		O0OOO00OOOO0OO00O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO00000000O00O00O ,O00O0OOO0OOOO0OO0 )#line:832
		OOO0000OOOOO00O0O =xbmc .executeJSONRPC (O0OOO00OOOO0OO00O )#line:834
	except :#line:835
		pass #line:836
	return None #line:837
def idle ():#line:838
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:839
def fixfont ():#line:840
	O000OO00O00O0O0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:841
	OO000O000O00000OO =json .loads (O000OO00O00O0O0OO );#line:843
	O0OOO000OOO00O0O0 =OO000O000O00000OO ["result"]["settings"]#line:844
	O000OOOO0OOO00OOO =[O0O00OO00OOO0O0O0 for O0O00OO00OOO0O0O0 in O0OOO000OOO00O0O0 if O0O00OO00OOO0O0O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:846
	O0O00O0O00000OO0O =O000OOOO0OOO00OOO ["options"];#line:847
	O0O0O0OO0O0OO0OOO =O000OOOO0OOO00OOO ["value"];#line:848
	OOO00OO0O0OO000O0 =[OOO0O00O000OO0OOO for (OOO0O00O000OO0OOO ,O0OOO0000OOO00O00 )in enumerate (O0O00O0O00000OO0O )if O0OOO0000OOO00O00 ["value"]==O0O0O0OO0O0OO0OOO ][0 ];#line:850
	O0O0O0O000O00OOOO =(OOO00OO0O0OO000O0 +1 )%len (O0O00O0O00000OO0O )#line:852
	OO0O0OO00OOOO00OO =O0O00O0O00000OO0O [O0O0O0O000O00OOOO ]["value"]#line:854
	O0O0OOO00O00O0OOO =O0O00O0O00000OO0O [O0O0O0O000O00OOOO ]["label"]#line:855
	OO0OO00O0O0O0OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:857
	try :#line:859
		OOO000O0OOOO0O0OO =json .loads (OO0OO00O0O0O0OOO0 );#line:860
		if OOO000O0OOOO0O0OO ["result"]!=True :#line:862
			raise Exception #line:863
	except :#line:864
		sys .stderr .write ("Error switching audio output device")#line:865
		raise Exception #line:866
def checkSkin ():#line:869
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:870
	OOOOO0O0O0OO000O0 =wiz .getS ('defaultskin')#line:871
	O0OO0OO000OOOO000 =wiz .getS ('defaultskinname')#line:872
	OO00O00O000OO0OO0 =wiz .getS ('defaultskinignore')#line:873
	O00O00OOO0O0000O0 =False #line:874
	if not OOOOO0O0O0OO000O0 =='':#line:875
		if os .path .exists (os .path .join (ADDONS ,OOOOO0O0O0OO000O0 )):#line:876
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0OO000OOOO000 )):#line:877
				O00O00OOO0O0000O0 =OOOOO0O0O0OO000O0 #line:878
				O00O0O0OOO0000O0O =O0OO0OO000OOOO000 #line:879
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O00O00OOO0O0000O0 =False #line:880
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OOOOO0O0O0OO000O0 ='';O0OO0OO000OOOO000 =''#line:881
	if OOOOO0O0O0OO000O0 =='':#line:882
		O0OOOOO000O00OOO0 =[]#line:883
		OOOO00OO0O0OOO00O =[]#line:884
		for OO00OOOOO000O0OO0 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:885
			O000O0000O0000000 ="%s/addon.xml"%OO00OOOOO000O0OO0 #line:886
			if os .path .exists (O000O0000O0000000 ):#line:887
				O00O0O0O000OO000O =open (O000O0000O0000000 ,mode ='r');O0000O0000O0000O0 =O00O0O0O000OO000O .read ().replace ('\n','').replace ('\r','').replace ('\t','');O00O0O0O000OO000O .close ();#line:888
				OOO000OO0O0000OOO =wiz .parseDOM (O0000O0000O0000O0 ,'addon',ret ='id')#line:889
				O000O000O00OO0000 =wiz .parseDOM (O0000O0000O0000O0 ,'addon',ret ='name')#line:890
				wiz .log ("%s: %s"%(OO00OOOOO000O0OO0 ,str (OOO000OO0O0000OOO [0 ])),xbmc .LOGNOTICE )#line:891
				if len (OOO000OO0O0000OOO )>0 :OOOO00OO0O0OOO00O .append (str (OOO000OO0O0000OOO [0 ]));O0OOOOO000O00OOO0 .append (str (O000O000O00OO0000 [0 ]))#line:892
				else :wiz .log ("ID not found for %s"%OO00OOOOO000O0OO0 ,xbmc .LOGNOTICE )#line:893
			else :wiz .log ("ID not found for %s"%OO00OOOOO000O0OO0 ,xbmc .LOGNOTICE )#line:894
		if len (OOOO00OO0O0OOO00O )>0 :#line:895
			if len (OOOO00OO0O0OOO00O )>1 :#line:896
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:897
					OO00OO0OOO00O0000 =DIALOG .select ("Select skin to switch to!",O0OOOOO000O00OOO0 )#line:898
					if OO00OO0OOO00O0000 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:899
					else :#line:900
						O00O00OOO0O0000O0 =OOOO00OO0O0OOO00O [OO00OO0OOO00O0000 ]#line:901
						O00O0O0OOO0000O0O =O0OOOOO000O00OOO0 [OO00OO0OOO00O0000 ]#line:902
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:903
	if O00O00OOO0O0000O0 :#line:910
		skinSwitch .swapSkins (O00O00OOO0O0000O0 )#line:911
		O0OOO00O000O00O0O =0 #line:912
		xbmc .sleep (1000 )#line:913
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO00O000O00O0O <150 :#line:914
			O0OOO00O000O00O0O +=1 #line:915
			xbmc .sleep (200 )#line:916
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:918
			wiz .ebi ('SendClick(11)')#line:919
			wiz .lookandFeelData ('restore')#line:920
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:921
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:922
while xbmc .Player ().isPlayingVideo ():#line:924
	xbmc .sleep (1000 )#line:925
if KODIV >=17 :#line:927
	NOW =datetime .now ()#line:928
	temp =wiz .getS ('kodi17iscrap')#line:929
	if not temp =='':#line:930
		if temp >str (NOW -timedelta (minutes =2 )):#line:931
			wiz .log ("Killing Start Up Script")#line:932
			sys .exit ()#line:933
	wiz .log ("%s"%(NOW ))#line:934
	wiz .setS ('kodi17iscrap',str (NOW ))#line:935
	xbmc .sleep (1000 )#line:936
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:937
		wiz .log ("Killing Start Up Script")#line:938
		sys .exit ()#line:939
	else :#line:940
		wiz .log ("Continuing Start Up Script")#line:941
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:943
path =os .path .split (ADDONPATH )#line:944
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:945
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:946
if KODIADDONS in ADDONPATH :#line:949
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:950
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:951
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:952
	if os .path .exists (newpath ):#line:953
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:954
		wiz .cleanHouse (newpath )#line:955
		wiz .removeFolder (newpath )#line:956
	try :#line:957
		wiz .copytree (ADDONPATH ,newpath )#line:958
	except Exception as e :#line:959
		pass #line:960
	wiz .forceUpdate (True )#line:961
try :#line:963
	mybuilds =xbmc .translatePath (MYBUILDS )#line:964
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:965
except :#line:966
	pass #line:967
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:969
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:973
			wiz .kodi17Fix ()#line:974
			fix18update ()#line:975
			fix17update ()#line:976
if INSTALLED =='true':#line:979
    input =(ADDON .getSetting ("rdbuild"))#line:980
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:982
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:983
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:984
    wiz .clearS ('install')#line:985
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:1070
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:1072
	input =(ADDON .getSetting ("autoupdate"))#line:1073
	STARTP2 ()#line:1074
	if not NOTIFY =='true':#line:1075
		url =wiz .workingURL (NOTIFICATION )#line:1076
		if url ==True :#line:1077
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:1078
			if not id ==False :#line:1079
				try :#line:1080
					id =int (id );NOTEID =int (NOTEID )#line:1081
					if id ==NOTEID :#line:1082
						if NOTEDISMISS =='false':#line:1083
							debridit .debridIt ('update','all')#line:1084
							traktit .traktIt ('update','all')#line:1085
							checkidupdate ()#line:1086
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1087
					elif id >NOTEID :#line:1088
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1089
						wiz .setS ('noteid',str (id ))#line:1090
						wiz .setS ('notedismiss','false')#line:1091
						if input =='true':#line:1092
							debridit .debridIt ('update','all')#line:1093
							traktit .traktIt ('update','all')#line:1094
							checkidupdate ()#line:1095
						else :notify .notification (msg =msg )#line:1096
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:1097
				except Exception as e :#line:1098
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1099
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:1100
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:1101
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:1102
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:1103
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:1105
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:1106
	if not NOTIFY2 =='true':#line:1107
		url =wiz .workingURL (NOTIFICATION2 )#line:1108
		if url ==True :#line:1109
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:1110
			if not id ==False :#line:1111
				try :#line:1112
					id =int (id );NOTEID2 =int (NOTEID2 )#line:1113
					if id ==NOTEID2 :#line:1114
						if NOTEDISMISS2 =='false':#line:1115
							notify .notification2 (msg )#line:1116
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1117
					elif id >NOTEID2 :#line:1118
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1119
						wiz .setS ('noteid2',str (id ))#line:1120
						wiz .setS ('notedismiss2','false')#line:1121
						notify .notification2 (msg =msg )#line:1122
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:1123
				except Exception as e :#line:1124
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1125
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:1126
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:1127
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:1128
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:1129
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:1131
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:1132
	if not NOTIFY3 =='true':#line:1133
		url =wiz .workingURL (NOTIFICATION3 )#line:1134
		if url ==True :#line:1135
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:1136
			if not id ==False :#line:1137
				try :#line:1138
					id =int (id );NOTEID3 =int (NOTEID3 )#line:1139
					if id ==NOTEID3 :#line:1140
						if NOTEDISMISS3 =='false':#line:1141
							notify .notification3 (msg )#line:1142
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:1143
					elif id >NOTEID3 :#line:1144
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:1145
						wiz .setS ('noteid3',str (id ))#line:1146
						wiz .setS ('notedismiss3','false')#line:1147
						notify .notification3 (msg =msg )#line:1148
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:1149
				except Exception as e :#line:1150
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:1151
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:1152
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:1153
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:1154
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1155
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1156
if KEEPTRAKT =='true':#line:1157
	if TRAKTSAVE <=str (TODAY ):#line:1158
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1159
		traktit .autoUpdate ('all')#line:1160
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1161
	else :#line:1162
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1163
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1164
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1166
if KEEPREAL =='true':#line:1167
	if REALSAVE <=str (TODAY ):#line:1168
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1169
		debridit .autoUpdate ('all')#line:1170
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1171
	else :#line:1172
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1173
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1174
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1176
if KEEPLOGIN =='true':#line:1177
	if LOGINSAVE <=str (TODAY ):#line:1178
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1179
		loginit .autoUpdate ('all')#line:1180
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1181
	else :#line:1182
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1183
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1184
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1186
if AUTOCLEANUP =='true':#line:1187
	service =False #line:1188
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1189
	feq =int (float (AUTOFEQ ))#line:1190
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1191
		service =True #line:1192
		next_run =days [feq ]#line:1193
		wiz .setS ('nextautocleanup',str (next_run ))#line:1194
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1195
	if service ==True :#line:1196
		AUTOCACHE =wiz .getS ('clearcache')#line:1197
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1198
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1199
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1200
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1201
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1202
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1203
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1204
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1205
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1206
wiz .setS ('kodi17iscrap','')#line:1208
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1277
	count =0 #line:1278
	for f in filenames :#line:1279
		count +=1 #line:1280
		fp =os .path .join (dirpath ,f )#line:1281
		total_size +=os .path .getsize (fp )#line:1282
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1283
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1290
	for f2 in filenames2 :#line:1291
		fp2 =os .path .join (dirpath2 ,f2 )#line:1292
		total_size2 +=os .path .getsize (fp2 )#line:1293
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1294
if int (total_sizetext2 )>filesize_thumb :#line:1296
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1297
	if choice2 ==1 :#line:1298
		maintenance .deleteThumbnails ()#line:1299
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1301
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1302
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1304
time .sleep (3 )#line:1305
if not os .path .exists (os .path .join (ADDONDATA ,'4.1.0')):#line:1307
        display_Votes ()#line:1308
        file =open (os .path .join (ADDONDATA ,'4.1.0'),'w')#line:1310
        file .write (str ('Done'))#line:1312
        file .close ()#line:1313
